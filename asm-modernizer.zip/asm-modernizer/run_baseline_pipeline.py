#!/usr/bin/env python3
"""Throwaway driver: run the full analysis pipeline on temp/asm with NO LLM calls.

Baseline generation for the new backward-traversal build. Runs the Celery task
eagerly (in-process, no worker/broker needed) so output lands in
jobs/<JOB_ID>/output/ exactly like a real API project, minus the LLM steps.
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from api.tasks.pipeline_task import run_full_pipeline  # noqa: E402

JOB_ID = "baseline-temp-asm"
SRC = str(ROOT / "temp" / "asm")

options = {
    "source_path": SRC,
    "skip_business_summary": True,   # no business-summary LLM
    "no_coverage_review": True,      # no LLM coverage reviewer
    "stop_after_step": 7,            # skip step 8 (LLM chain summaries)
}

print(f"[driver] launching pipeline job={JOB_ID}", flush=True)
print(f"[driver] source={SRC}", flush=True)
print(f"[driver] options={options}", flush=True)

result = run_full_pipeline.apply(args=[JOB_ID, options]).get()

print(f"[driver] DONE result={result}", flush=True)
