# optimised-run

Running the v4 VBT pipeline + trace endpoints with the parallelization tuning
introduced in this PR. Defaults are conservative and match an 8-core / 16 GB
laptop envelope (≤ 7 GB RSS, 4–6 cores busy at peak).

## What changed (TL;DR)

The two APIs you call to (and the only ones tuned here) are:

- `POST /v1/jobs/vbt/pipeline` — runs universe → analysis → vbt_precompute.
- `POST /v1/jobs/vbt/trace` — runs the trace once the KB has been precomputed.

Internally:

- `vbt/precompute/asm_db.py`, `vbt/precompute/setter_map_db.py`,
  `vbt/precompute/cpp_setter_map_db.py`, `vbt/precompute/cpp_file_writes_db.py`
  now fan out their per-file work through `vbt.precompute.parallel.parallel_map`
  (ProcessPool). The parent still writes blobs serially (sqlite single-writer).
- `vbt/precompute_db.py` prints a `[VDB] <substep>: <secs>s` line per substep
  to `job.log` so post-mortem profiling is grep-friendly.
- `universe_builder.py:_populate_asm_usage_locations` replaces the per-entry
  `O(L²)` `_add_location_if_missing` list-scan with a per-entry seen-set memo
  (`O(1)` per add). Output is identical.
- `api/tasks/analysis_task.py` Phase 4 emission now uses `ProcessPoolExecutor`
  (was `ThreadPoolExecutor`, GIL-bound). `_EMIT_MAX_WORKERS` is now env-tunable
  via `ASM_EMIT_MAX_WORKERS` (default 4).

The trace engine code is unchanged in behaviour — its dep-var route warming
was already parallel-ready; the only thing that flips it on is the
`VBT_DEPVAR_WORKERS` env var (the engine guarantees byte-identical output for
any worker count, see comment at `vbt/depvars/recurse.py:1434-1440`).

## Recommended env (8-core / 16 GB laptop)

Add to `.env` alongside the existing required vars (`JWT_SECRET_KEY`,
`REDIS_URL`, …). All four are optional — defaults work but are not tuned for
the laptop envelope.

```
# Trace-side parallelism (dep-var route warming)
VBT_DEPVAR_WORKERS=4
# Precompute-side ProcessPool (modifier index, setter maps, file_writes, cfg)
VBT_WORKERS=4
VBT_MEM_BUDGET_FRACTION=0.40
# Phase 4 (analysis: blueprint emission) ProcessPool cap
ASM_EMIT_MAX_WORKERS=4
# Run one trace at a time so its fork-pool doesn't double-book CPUs
CELERY_CONCURRENCY=1
```

On a bigger server (e.g. 32-core / 128 GB) raise `VBT_WORKERS=12`,
`ASM_EMIT_MAX_WORKERS=8`, `VBT_MEM_BUDGET_FRACTION=0.60`, and
`CELERY_CONCURRENCY` to whatever your shared workload allows.

## Running the stack

Docker (compose) — unchanged from before:

```
docker compose up -d redis api worker
```

Host mode (no docker) — minimal:

```
# 0. venv + deps
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.txt

# 1. redis (any 7.x; the compose file maps it to host port 6380)
docker run -d --name asm-redis -p 127.0.0.1:6380:6379 redis:7-alpine \
  redis-server --save "" --appendonly no
# point .env at it: REDIS_URL=redis://127.0.0.1:6380

# 2. one-shot DB init (first run only)
.venv/bin/python -c "from dotenv import load_dotenv; load_dotenv(); \
                     from api.db import create_tables; create_tables()"

# 3. API + worker (separate terminals or backgrounded)
.venv/bin/python -m uvicorn api.app:app --host 127.0.0.1 --port 8000
.venv/bin/python -m celery -A api.tasks.celery_app worker -c 1 --loglevel=info
```

## Calling the APIs

Same shape as before (no API contract change):

```bash
TOKEN=$(curl -s -X POST http://localhost:8000/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"alice","password":"YourPass"}' | jq -r .access_token)

# 1) Parser pipeline
curl -X POST http://localhost:8000/v1/jobs/vbt/pipeline \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{
    "kb_name": "my-kb",
    "datasource_username": "alice",
    "source_path": "/absolute/path/to/asm/sources",
    "asm_only": false, "cpp_only": false,
    "exclude": [], "search_paths": [], "macro_libs": [],
    "no_coverage_review": true,
    "skip_business_summary": true,
    "cache_in_job_dir": true,
    "rebuild": false,
    "cfg_warm": true,
    "workers": 0
  }'
# response includes job_id; poll /v1/jobs/vbt/{job_id}/status until "success"
# kb_id == job_id of the pipeline.

# 2) Trace
curl -X POST http://localhost:8000/v1/jobs/vbt/trace \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{
    "kb_id": "<pipeline-job-id>",
    "variable": "softCardValue",
    "language": "cpp",
    "chain": [
      {"stem": "aa71", "type": "asm"},
      {"stem": "dw730000", "type": "cpp", "function": "DW73"},
      {"stem": "dw710000", "type": "cpp",
       "function": "callPlasticAuthenticationComponentInterface"}
    ],
    "trace_options": {
      "max_paths": 512, "max_routes": 2000,
      "max_route_len": 32, "max_call_depth": 32,
      "max_dep_var_depth": 3, "progress": true
    }
  }'
```

## Reading the per-substep timings

After a pipeline run, `<JOBS_BASE_DIR>/<job_id>/job.log` contains:

```
  [VDB] ensure_call_graph: 0.00s
  [VDB] preload_resolvers: 0.38s
  [VDB] file_call_graph: 0.07s
  ...
  [VDB] asm_blueprints: 1.04s          <- parallelized
  [VDB] asm_setter_map: 0.80s          <- parallelized
  [VDB] cpp_setter_map: 0.82s          <- parallelized
  [VDB] cpp_file_writes: 0.32s         <- parallelized
  ...
```

Grep with `grep '\[VDB\]' job.log`.

## What's still serial (next-pass targets)

- `universe_builder.UniverseBuilder.build` Phase 1/3 (ASM file processing)
  is still a serial loop. The C++ phase right below it already uses a fork pool
  (see `_cpp_file_subprocess_worker`); a mirrored ASM worker (with SIGALRM set
  in each child) is the highest-leverage remaining win for ASM-heavy corpora.
- `cache/file_cache.py` is imported but functionally unused — it's consulted
  only as a write-guard, never as a read short-circuit. Wiring it correctly
  would make incremental re-runs near-free.

## Output equivalence

Every change in this PR was validated against a 19-case gold trace set
(`softCardValue`, `workArea`, `cidRecord`, `addresses`, plus 9 ASM cases:
`EB0U000_xh80`, `WB1ERLOG_xh80`, `AJ84TPTR_aj84`, `WB1S1_xh88`,
`WB1DTAREA_xh80`, `WRKYEAR_ae48`, `WB1WRK1_xh93`, `REGSAV_ae48`,
`EB0U000_aa71__xh80`, plus 5 must-stay-empty consistency checks). Every wave's
output was sha256-of-sorted-JSON-equal to the gold set. Manual source
verification confirmed setter line numbers and guard conditions match real
source code (e.g. `softCardValue` setter at `dw710000.cpp:1002`, condition
`(@CASVIS1 & X'01') == X'01'` at `aa71.asm:2008-2010`).
