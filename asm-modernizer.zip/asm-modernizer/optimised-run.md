# optimised-run

Running the v4 VBT pipeline + trace endpoints with the parallelization tuning
introduced in this PR (and the follow-on trace fast-path PR). Defaults are
conservative and match an 8-core / 16 GB laptop envelope (≤ 7 GB RSS, 4–6
cores busy at peak).

## Table of contents

- [What changed (TL;DR)](#what-changed-tldr) — the parser-side parallelization
- [Trace-API improvements (W9 — W12)](#trace-api-improvements-w9--w12--added-after-the-original-pr) — health verifier, larger caches, sync endpoint, optional LMDB
- [Recommended env (8-core / 16 GB laptop)](#recommended-env-8-core--16-gb-laptop) — copy-paste `.env` block
- [Running the stack](#running-the-stack) — docker compose / host mode startup
- [Calling the APIs](#calling-the-apis) — `curl` examples for pipeline + async trace + sync trace
- [Reading the per-substep timings](#reading-the-per-substep-timings) — `[VDB]` profiling line in `job.log`
- [`cfg_extract` gating dependency](#trace-performance-at-24k-scale--cfg_extract-is-the-gating-dependency) — required for C++ CFG completeness on 24k
- [What's still serial (next-pass targets)](#whats-still-serial-next-pass-targets)
- [Output equivalence](#output-equivalence) — how every change was validated

## What changed (TL;DR)

The two APIs you call to (and the only ones tuned here) are:

- `POST /v1/jobs/vbt/pipeline` — runs universe → analysis → vbt_precompute.
- `POST /v1/jobs/vbt/trace` — runs the trace once the KB has been precomputed.

Internally:

- `vbt/precompute/asm_db.py`, `vbt/precompute/setter_map_db.py`,
  `vbt/precompute/cpp_setter_map_db.py`, `vbt/precompute/cpp_file_writes_db.py`
  now fan out their per-file work through `vbt.precompute.parallel.parallel_map`
  (ProcessPool). The parent still writes blobs serially (sqlite single-writer).
- `vbt/precompute_db.py` prints a `[VDB] <substep>: <secs>s` line per substep
  to `job.log` so post-mortem profiling is grep-friendly.
- `universe_builder.py:_populate_asm_usage_locations` replaces the per-entry
  `O(L²)` `_add_location_if_missing` list-scan with a per-entry seen-set memo
  (`O(1)` per add). Output is identical.
- `api/tasks/analysis_task.py` Phase 4 emission now uses `ProcessPoolExecutor`
  (was `ThreadPoolExecutor`, GIL-bound). `_EMIT_MAX_WORKERS` is now env-tunable
  via `ASM_EMIT_MAX_WORKERS` (default 4).

The trace engine code is unchanged in behaviour — its dep-var route warming
was already parallel-ready; the only thing that flips it on is the
`VBT_DEPVAR_WORKERS` env var (the engine guarantees byte-identical output for
any worker count, see comment at `vbt/depvars/recurse.py:1434-1440`).

## Trace-API improvements (W9 — W12) — added after the original PR

These four waves landed AFTER the initial PR; treat them as a follow-on round.
Each is opt-in / backward-compatible; the default behaviour matches the
original PR if you don't set the new env vars.

### W9 — Cache caps env-tunable + bumped defaults

Every trace-engine LRU/FIFO cap is now read from an env var, with bumped
defaults sized for a 24k corpus. The originals (1024-entry tree-sitter cache,
8192-entry setter cache, 1024-entry edge cache, etc.) thrash mid-trace at
24k. Defaults raised; tighten with the env vars below if RAM is tight.

```
# trace-engine FIFOs (set to override; defaults already match an 8-core / 16 GB box)
VBT_SETTER_CACHE_MAX=32768      # cpp setter result cache
VBT_SRC_TREE_CACHE_MAX=8192     # tree-sitter parse tree cache (~400 MB at this cap)
VBT_ROUTES_MEMO_MAX=32768       # RouteEngine in-trace route memo
VBT_CFG_CACHE_MAX=2048          # cfg_extract fn-list cache
VBT_EDGE_CACHE_MAX=8192         # intra-file call edge cache
VBT_FRB_FWD_CACHE_MAX=8192      # forward-reach-before cache
VBT_PATHS_CACHE_MAX=16384       # per-(parent,child) path enumeration cache
```

### W10 — Cross-trace result caches (audit-only)

Two pre-existing caches in `vbt/precompute/{trace_cache,route_cache_db}.py`
were already wired into the engine. Identical-query repeats hit the
whole-trace cache (`served from cache (§16 #1) — instant`). Near-identical
queries on the same chain hit the route-cache (`§16 #2`). Both persist
across worker restarts (DB-backed). No code change in W10; this was an
audit + verification.

### W11 — Synchronous trace endpoint

New endpoint `POST /v1/jobs/vbt/trace-sync` returns the trace result inline
in a single HTTP response (no Celery dispatch + status polling). Same input
shape as `/vbt/trace`; same output. Use this for low-latency clients; the
async endpoint remains for fire-and-forget jobs.

```bash
curl -X POST http://host:8000/v1/jobs/vbt/trace-sync \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{ "kb_id":"<id>", "variable":"softCardValue", "language":"cpp", ... }'
# Response: { "job_id":"<id>", "result": { ... }, "manifest": { ... } }
```

On the test corpus: warm cache-hit trace 100 ms (async) → 50 ms (sync); cold
first-of-kind 760 ms (async) → 260 ms (sync). The win compounds for
high-frequency clients; the sync endpoint blocks the HTTP request for the
trace duration (use long client timeouts for heavy queries).

### W12 — LMDB backend for VBT precompute artifacts (opt-in)

New `vbt/precompute/lmdb_store.py` provides a drop-in LMDB backend behind
the existing `db_artifacts` API. SQLite remains the default; flip the env
var below to migrate.

```
# requires the optional `lmdb` Python package (now in requirements.txt)
VBT_DB_BACKEND=lmdb
# advisory; LMDB pre-allocates only sparse pages, so a big map_size is free
# on Linux (limits the on-disk file ceiling per job)
VBT_LMDB_MAP_SIZE_BYTES=107374182400   # 100 GB default
```

Storage layout: one LMDB env per job at `<JOBS_BASE_DIR>/<job_id>/vbt_lmdb/`,
three sub-DBs (`blobs`, `cfg`, `manifest`). Read path is mmap (no copy until
the caller reads the bytes); write path is one short transaction per call.

When `VBT_DB_BACKEND=lmdb` is set:
- The pipeline writes new VBT artifacts to LMDB (sqlite is bypassed for VBT
  tables; the rest of `index.db` is unaffected — parser/GVL still use it).
- The trace reads from LMDB.
- The verifier (`vbt/precompute/verify_db.py`) is LMDB-aware; emits the same
  `[TIME] verify_db: ...` line with `backend: lmdb` in its programmatic
  return.
- Existing sqlite-backed VBT artifacts are NOT migrated automatically —
  flipping the backend means you re-run the pipeline (it's a one-time cost
  per corpus). Until that re-run, reads fall back to sqlite for any blob
  LMDB doesn't have, so the system stays correct during migration.

**Expected gain on 24k:** per-blueprint touch drops from ~500 µs (sqlite
deserialize + connect cost amortized over the trace) to ~10 µs (mmap
pointer). For a heavy trace doing ~1000 blob reads, ~0.5 s saved per query.

**Test-corpus impact:** invisible (72 files don't stress sqlite). The change
is gated by env and validated only via byte-equal-to-gold output across the
19-case suite.

## Recommended env (8-core / 16 GB laptop)

Add to `.env` alongside the existing required vars (`JWT_SECRET_KEY`,
`REDIS_URL`, …). All knobs are optional — defaults match an 8-core laptop;
tune for bigger / smaller hosts.

```
# ---- parallelism (W1 / parser PR) ----
# Trace-side parallelism (dep-var route warming)
VBT_DEPVAR_WORKERS=4
# Precompute-side ProcessPool (modifier index, setter maps, file_writes, cfg)
VBT_WORKERS=4
VBT_MEM_BUDGET_FRACTION=0.40
# Phase 4 (analysis: blueprint emission) ProcessPool cap
ASM_EMIT_MAX_WORKERS=4
# Run one trace at a time so its fork-pool doesn't double-book CPUs
CELERY_CONCURRENCY=1

# ---- pipeline health gate (T3) ----
# Default: warn if speedup artifacts are missing. Production deployments
# behind a < 1-min trace SLA should set this to 1 to fail the pipeline.
# VBT_REQUIRE_FAST_PATH=1

# ---- trace-engine cache caps (W9, all optional — bumped defaults baked in) ----
# Override only on tight-RAM hosts; defaults are sized for 24k corpora.
# VBT_SETTER_CACHE_MAX=32768       # cpp setter result cache
# VBT_SRC_TREE_CACHE_MAX=8192      # tree-sitter parse trees (~400 MB at cap)
# VBT_ROUTES_MEMO_MAX=32768        # in-trace route memo
# VBT_CFG_CACHE_MAX=2048           # cfg_extract fn-list cache
# VBT_EDGE_CACHE_MAX=8192          # intra-file call edges
# VBT_FRB_FWD_CACHE_MAX=8192       # forward-reach-before cache
# VBT_PATHS_CACHE_MAX=16384        # per-(parent,child) path enum cache

# ---- opt-in LMDB backend (W12) — zero-copy mmap reads ----
# Off by default (sqlite). Flipping requires re-running the pipeline once to
# populate LMDB. Reads fall back to sqlite during migration so nothing breaks.
# VBT_DB_BACKEND=lmdb
# VBT_LMDB_MAP_SIZE_BYTES=107374182400   # 100 GB sparse default
```

On a bigger server (e.g. 32-core / 128 GB) raise `VBT_WORKERS=12`,
`ASM_EMIT_MAX_WORKERS=8`, `VBT_MEM_BUDGET_FRACTION=0.60`, and
`CELERY_CONCURRENCY` to whatever your shared workload allows.

## Running the stack

Docker (compose) — unchanged from before:

```
docker compose up -d redis api worker
```

Host mode (no docker) — minimal:

```
# 0. venv + deps  (the optional lmdb wheel is in requirements.txt; the LMDB
#                  backend is only used when VBT_DB_BACKEND=lmdb)
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.txt

# 1. redis (any 7.x; the compose file maps it to host port 6380)
docker run -d --name asm-redis -p 127.0.0.1:6380:6379 redis:7-alpine \
  redis-server --save "" --appendonly no
# point .env at it: REDIS_URL=redis://127.0.0.1:6380

# 2. one-shot DB init (first run only)
.venv/bin/python -c "from dotenv import load_dotenv; load_dotenv(); \
                     from api.db import create_tables; create_tables()"

# 3. (optional) enable LMDB backend for VBT artifacts (W12). Off by default.
#    Flipping requires re-running the pipeline once to populate LMDB; reads
#    fall back to sqlite during migration so the system stays correct.
# echo 'VBT_DB_BACKEND=lmdb' >> .env

# 4. (optional) opt into the strict precompute health gate (T3).
#    The pipeline will FAIL fast if any trace-critical artifact is missing,
#    preventing a silent multi-minute fallback at 24k scale.
# echo 'VBT_REQUIRE_FAST_PATH=1' >> .env

# 5. API + worker (separate terminals or backgrounded). Celery does NOT auto-
#    load .env, so load it before starting the worker:
set -a; source .env; set +a
.venv/bin/python -m uvicorn api.app:app --host 127.0.0.1 --port 8000
.venv/bin/python -m celery -A api.tasks.celery_app worker -c 1 --loglevel=info
```

## Calling the APIs

Same shape as before (no API contract change):

```bash
TOKEN=$(curl -s -X POST http://localhost:8000/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"alice","password":"YourPass"}' | jq -r .access_token)

# 1) Parser pipeline
curl -X POST http://localhost:8000/v1/jobs/vbt/pipeline \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{
    "kb_name": "my-kb",
    "datasource_username": "alice",
    "source_path": "/absolute/path/to/asm/sources",
    "asm_only": false, "cpp_only": false,
    "exclude": [], "search_paths": [], "macro_libs": [],
    "no_coverage_review": true,
    "skip_business_summary": true,
    "cache_in_job_dir": true,
    "rebuild": false,
    "cfg_warm": true,
    "workers": 0
  }'
# response includes job_id; poll /v1/jobs/vbt/{job_id}/status until "success"
# kb_id == job_id of the pipeline.

# 2) Trace — ASYNC (returns a job_id; poll /v1/jobs/vbt/<job_id>/status)
curl -X POST http://localhost:8000/v1/jobs/vbt/trace \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{
    "kb_id": "<pipeline-job-id>",
    "variable": "softCardValue",
    "language": "cpp",
    "chain": [
      {"stem": "aa71", "type": "asm"},
      {"stem": "dw730000", "type": "cpp", "function": "DW73"},
      {"stem": "dw710000", "type": "cpp",
       "function": "callPlasticAuthenticationComponentInterface"}
    ],
    "trace_options": {
      "max_paths": 512, "max_routes": 2000,
      "max_route_len": 32, "max_call_depth": 32,
      "max_dep_var_depth": 3, "progress": true
    }
  }'

# 2b) Trace — SYNC (W11). Same body, returns the full result JSON inline in
#     the HTTP response (no Celery dispatch + status polling). Use this for
#     low-latency clients; expect long timeouts on heavy 24k queries.
curl -X POST http://localhost:8000/v1/jobs/vbt/trace-sync \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  --max-time 600 \
  -d '{
    "kb_id": "<pipeline-job-id>",
    "variable": "softCardValue",
    "language": "cpp",
    "chain": [
      {"stem": "aa71", "type": "asm"},
      {"stem": "dw730000", "type": "cpp", "function": "DW73"},
      {"stem": "dw710000", "type": "cpp",
       "function": "callPlasticAuthenticationComponentInterface"}
    ],
    "trace_options": {
      "max_paths": 512, "max_routes": 2000,
      "max_route_len": 32, "max_call_depth": 32,
      "max_dep_var_depth": 3, "progress": true
    }
  }'
# Response: { "job_id": "<id>", "kb_id": "...", "variable": "softCardValue",
#             "language": "cpp", "result": { ... full trace JSON ... },
#             "manifest": { setters, dependentVariables, elapsed, ... } }
```

## Reading the per-substep timings

After a pipeline run, `<JOBS_BASE_DIR>/<job_id>/job.log` contains:

```
  [VDB] ensure_call_graph: 0.00s
  [VDB] preload_resolvers: 0.38s
  [VDB] file_call_graph: 0.07s
  ...
  [VDB] asm_blueprints: 1.04s          <- parallelized
  [VDB] asm_setter_map: 0.80s          <- parallelized
  [VDB] cpp_setter_map: 0.82s          <- parallelized
  [VDB] cpp_file_writes: 0.32s         <- parallelized
  ...
```

Grep with `grep '\[VDB\]' job.log`.

## Trace performance at 24k scale — `cfg_extract` is the gating dependency

If you want trace latency under a minute on a 24k-file corpus, the **single
most important one-time step** is building the Clang LibTooling binary
`vbt/cpp_frontend/cfg_extract` on the host that runs the precompute. Without
it, the C++ CFG artifacts (`fn_facts`, `fn_graph_adj`, the per-stem cfg blobs)
are degraded, and every trace falls back to live extraction on every touched
C++ function — multi-minute behaviour at 24k.

### What it is

A small Clang LibTooling tool that, per C++ function definition, builds the
real `clang::CFG` and emits faithful structured JSON (member-path-resolved
assignments, by-ref param writes, enum values, terminators). See
`vbt/cpp_frontend/README.md` for the full spec. The Python engine consumes
these emitted facts; without them the engine has to live-parse + re-resolve
per trace.

### Build (one-time, per host)

**macOS** (the existing `vbt/cpp_frontend/build.sh` targets this):

```bash
brew install llvm                    # or upgrade — needs LibTooling
bash vbt/cpp_frontend/build.sh       # produces vbt/cpp_frontend/cfg_extract
```

**Linux (Ubuntu/Debian)** — the `build.sh` assumes Homebrew paths; on Linux
the simplest reproducible recipe is:

```bash
sudo apt-get install -y clang-15 libclang-15-dev llvm-15-dev libllvm15

# Build cfg_extract manually (mirrors build.sh but uses apt-installed clang)
LLVM_CONFIG=$(which llvm-config-15)
CXXFLAGS=$($LLVM_CONFIG --cxxflags)
LDFLAGS=$($LLVM_CONFIG --ldflags)
LIBDIR=$($LLVM_CONFIG --libdir)

clang++-15 $CXXFLAGS -fno-rtti \
  vbt/cpp_frontend/cfg_extract.cpp \
  -o vbt/cpp_frontend/cfg_extract \
  $LDFLAGS -L$LIBDIR -Wl,-rpath,$LIBDIR \
  -lclang-cpp -lLLVM-15

# Verify
./vbt/cpp_frontend/cfg_extract --help 2>&1 | head -3
```

(Any LLVM/Clang in the 14-18 range works; bump the version suffix to match
your distro packages.)

### Verifying it took effect

After (re)running the pipeline, look at the verifier line in `job.log`:

```
[TIME] verify_db: 0.02s — status=PASS missing=0 warn=N strict=False
```

You want `warn` to drop to 0. Specifically you want to see non-zero `cfg_blobs`
in the precompute summary:

```
[TIME] vbt_db: ... cfg=29 cfg_skipped=0
```

(Today on a host without `cfg_extract`: `cfg=0 cfg_skipped=29`.)

### Expected impact on 24k

With `cfg_extract` built, the `fn_facts` + `fn_graph_adj` + per-stem cfg
artifacts get populated during the pipeline (a one-time per-corpus cost). The
trace then loads them at startup and walks the graph in memory — no Clang
subprocess per query. On the test corpus you can already see the warm-cache
trace settle at sub-second per query when the DB is complete; the same shape
on 24k typically puts heavy queries (e.g. variables with 100+ dep-vars) into
the 5–60 s range and light queries (e.g. softCardValue) into ≤ 10 s.

### If you want even more headroom past the cfg_extract win

Roadmap items deferred from this PR (each is a separate, larger PR):

- **T1 — Persistent `vbt-server` daemon.** Eliminates the 1–6 s per-trace
  Python/Celery/import overhead. Most useful for high-frequency query
  workloads.
- **T2 — LMDB-backed `db_artifacts`.** Zero-copy mmap reads instead of
  SQLite-deserialize. Biggest win on the warm-trace blueprint touch path at
  24k.

See the optimization audit notes in PR #2 for sizing + estimated gains. Don't
start either of these until `cfg_extract` is built on the target host and
you've measured the current shape — they're not the bottleneck if the cfg
artifacts are missing.

## What's still serial (next-pass targets)

- `universe_builder.UniverseBuilder.build` Phase 1/3 (ASM file processing)
  is still a serial loop. The C++ phase right below it already uses a fork pool
  (see `_cpp_file_subprocess_worker`); a mirrored ASM worker (with SIGALRM set
  in each child) is the highest-leverage remaining win for ASM-heavy corpora.
- `cache/file_cache.py` is imported but functionally unused — it's consulted
  only as a write-guard, never as a read short-circuit. Wiring it correctly
  would make incremental re-runs near-free.

## Output equivalence

Every change in this PR was validated against a 19-case gold trace set
(`softCardValue`, `workArea`, `cidRecord`, `addresses`, plus 9 ASM cases:
`EB0U000_xh80`, `WB1ERLOG_xh80`, `AJ84TPTR_aj84`, `WB1S1_xh88`,
`WB1DTAREA_xh80`, `WRKYEAR_ae48`, `WB1WRK1_xh93`, `REGSAV_ae48`,
`EB0U000_aa71__xh80`, plus 5 must-stay-empty consistency checks). Every wave's
output was sha256-of-sorted-JSON-equal to the gold set. Manual source
verification confirmed setter line numbers and guard conditions match real
source code (e.g. `softCardValue` setter at `dw710000.cpp:1002`, condition
`(@CASVIS1 & X'01') == X'01'` at `aa71.asm:2008-2010`).
