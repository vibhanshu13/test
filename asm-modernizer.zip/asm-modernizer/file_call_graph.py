#!/usr/bin/env python3
"""
file_call_graph.py — Build a file-level call graph for HLASM and C++ files.

Produces a directed graph where fileA → fileB means fileA contains an
instruction that transfers control to fileB.

Cross-module instructions detected:
  ASM:  ENTRC (subroutine call), ENTNC/ENTDC (no-return transfer), CREEC/CREMC (async spawn),
        SWISC (ISC-routed dispatch), FUNCTION (macro wrapper → ENTDC, target = args[1])
  C++:  CALL_ALIAS (wrapper → ASM), CALL (direct alias, filtered to ASM targets only)

Usage:
    # Recommended: both sources for complete coverage
    python3 file_call_graph.py \\
        --asm-dir temp/asm/ \\
        --blueprint-dir temp/output_latest/asm/ \\
        --output call_graph.json

    # Blueprint only (relies on parser having ENTNC/CREEC in call_graph.edges)
    python3 file_call_graph.py --blueprint-dir temp/output_latest/asm/

    # DOT graph for Graphviz visualization
    python3 file_call_graph.py \\
        --asm-dir temp/asm/ \\
        --blueprint-dir temp/output_latest/asm/ \\
        --format dot --output flow.dot

At least one of --asm-dir or --blueprint-dir is required.
"""

import argparse
import json
import os
import re
import sys
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, TimeoutError as _FuturesTimeoutError, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from api.utils.indirection import extract_indirection

from backward_traversal.glossary.instructions import CROSS_FILE_CALL_OPCODES
from blueprint_io import iter_flow, load_blueprint

# Cap at 8 workers: each concurrently loads call_graph+blocks+subroutines
# (~5–20 MB per blueprint).  32 workers × 20 MB = 640 MB RSS spike; 8 × 20 MB = 160 MB.
_SCAN_WORKERS = min(8, (os.cpu_count() or 4))
_BP_IO_TIMEOUT = 60.0  # max seconds to wait for a single blueprint/source file read


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FUNCTION_MACRO: str = "FUNCTION"
# FUNCTION needs special arg[1] extraction (target = args[1], not args[0])
ASM_CROSS_MODULE: Set[str] = CROSS_FILE_CALL_OPCODES - {FUNCTION_MACRO}
CPP_ALWAYS_CROSS: Set[str] = {"CALL_ALIAS"}

# Instruction type for C++ header #include dependency edges (Gap 4).
CPP_INCLUDE_INSTR: str = "INCLUDE"

# C++ function names that are platform infrastructure (stdlib / TPF API).
# Unresolved CALL edges to these targets are dropped even from C++ sources;
# all other unresolved C++ CALL edges are preserved as external edges (Gap 3).
_CPP_STDLIB_NOISE: frozenset = frozenset({
    # C standard library
    "memcpy", "memset", "memcmp", "memmove",
    "strlen", "strcmp", "strcpy", "strcat", "strncpy", "strncmp",
    "sprintf", "snprintf", "printf", "fprintf", "sscanf",
    "malloc", "calloc", "realloc", "free",
    "exit", "abort", "atexit",
    "time", "localtime", "strftime", "mktime",
    "atoi", "atol", "atof", "strtol", "strtod",
    # TPF platform APIs — control / level / register operations
    "crusa", "levtest", "flipc", "getcc", "relcc", "ecbptr",
    "fiwhc", "filuc", "rcunc", "face_facs",
    "wtopc", "wtopc_insert_header",
    "attac", "evntc", "evnwc", "glob",
    # TPF database / file-I/O APIs
    "dfred", "dfdel", "dfmod", "dfkey", "dfret", "dfins",
    "df_nbrkeys", "df_setkey", "df_setkey_bool", "df_setkey_char",
    "df_ok", "df_test", "dfkey2",
    # TPF heap / memory APIs
    "tpf_decb_create", "tpf_eheap_locate", "tpf_eheap_free", "tpf_eheap_alloc",
})

# Pattern for ASM module names: uppercase letter followed by 3-5 uppercase/digit chars
# Examples: DA78, XH72, NB81, DE70, AC71
ASM_MODULE_RE = re.compile(r"^[A-Z][A-Z0-9]{3,5}$")

# Opcode-to-call_type mapping for informational output
INSTRUCTION_CALL_TYPE = {
    "ENTRC":    "subroutine_call",
    "ENTNC":    "no_return_call",
    "ENTDC":    "no_return_call",
    "CREEC":    "async_spawn",
    "CREMC":    "async_spawn",
    "CREDC":    "async_spawn",
    "CRETC":    "async_spawn",
    "CREXC":    "async_spawn",
    "CRESC":    "sync_spawn",
    "SWISC":    "isc_route",
    "EXSR":     "subroutine_call",
    "FUNCTION": "no_return_call",  # expands to ENTDC
    "CALLC":    "subroutine_call",  # IBM z/TPF typed C call from ASM
    "CALLCPP":  "subroutine_call",  # project convention C++ call from ASM
    "CLINKC":   "subroutine_call",  # IBM C-linkage call to BAL function
    "CALL_ALIAS": "subroutine_call",
    "CALL":     "subroutine_call",
    "INCLUDE":  "include_dependency",  # C++ #include header dependency (Gap 4)
}

# DOT graph color/style per instruction
DOT_EDGE_STYLE = {
    "ENTRC":      {"color": "blue",      "style": "solid"},
    "ENTNC":      {"color": "red",       "style": "solid"},
    "ENTDC":      {"color": "red",       "style": "dashed"},
    "CREEC":      {"color": "purple",    "style": "dashed"},
    "CREMC":      {"color": "purple",    "style": "dotted"},
    "CREDC":      {"color": "purple",    "style": "dashed"},  # deferred async spawn
    "CRETC":      {"color": "purple",    "style": "dashed"},  # timer-initiated async
    "CREXC":      {"color": "purple",    "style": "dotted"},  # low-priority deferred
    "CRESC":      {"color": "brown",     "style": "solid"},   # synchronous spawn/wait
    "SWISC":      {"color": "darkgreen", "style": "dashed"},
    "EXSR":       {"color": "blue",      "style": "solid"},   # cross-file subroutine
    "FUNCTION":   {"color": "red",       "style": "dashed"},  # same as ENTDC
    "CALLC":      {"color": "orange",    "style": "solid"},   # ASM→C call
    "CALLCPP":    {"color": "orange",    "style": "solid"},   # ASM→C++ call
    "CLINKC":     {"color": "blue",      "style": "solid"},   # C-linkage subroutine call
    "CALL_ALIAS": {"color": "orange",    "style": "solid"},
    "CALL":       {"color": "orange",    "style": "dashed"},
    "INCLUDE":    {"color": "gray",      "style": "dotted"},  # C++ #include (Gap 4)
}


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class EdgeDetail:
    """One specific call site — a single cross-module instruction in a file."""
    source_stem: str       # e.g. "da76"
    target_module: str     # e.g. "DA78" (raw module name from operand)
    instruction: str       # "ENTRC", "ENTNC", "CREEC", "CALL_ALIAS", "CALL"
    line: int
    source_file: str       # e.g. "da76.asm"
    source_block: str      # routine/block name, or "" when from raw ASM scan
    call_type: str = ""    # serialized call_type string
    # Opaque indirect-call envelope.  None for direct calls.  Carries
    # is_indirect / indirect_via / is_virtual_dispatch / cha_base_class plus
    # any future Phase-2 fields without requiring schema migration.
    indirection: Optional[Dict[str, Any]] = None

    def dedup_key(self) -> Tuple:
        return (self.source_stem, self.target_module, self.instruction, self.line)


@dataclass
class FileEdge:
    """Aggregated edge between two files (possibly external)."""
    source_stem: str
    target_stem: Optional[str]   # None if target is external / unresolved
    target_module: str            # raw module name (may differ from target_stem)
    is_internal: bool
    call_sites: List[EdgeDetail] = field(default_factory=list)

    @property
    def instructions(self) -> List[str]:
        seen: Set[str] = set()
        result = []
        for s in self.call_sites:
            if s.instruction not in seen:
                seen.add(s.instruction)
                result.append(s.instruction)
        return result


@dataclass
class CallGraph:
    """File-level call graph."""
    file_edges: List[FileEdge]
    all_asm_stems: Set[str]
    all_cpp_stems: Set[str]
    warnings: List[str]
    all_header_stems: Set[str] = field(default_factory=set)

    @property
    def all_stems(self) -> Set[str]:
        return self.all_asm_stems | self.all_cpp_stems

    @property
    def internal_edges(self) -> List[FileEdge]:
        return [e for e in self.file_edges if e.is_internal]

    @property
    def external_edges(self) -> List[FileEdge]:
        return [e for e in self.file_edges if not e.is_internal]


# ---------------------------------------------------------------------------
# Operand extraction helpers
# ---------------------------------------------------------------------------

def _extract_operand_target(operand_str: str) -> str:
    """Extract the first module name token from an operand string.

    Handles:
      "DA78"                    → "DA78"
      "XH72 CONTINUE XH81 ..."  → "XH72"  (inline comment stripped)
      "GA71,D0,R"               → "GA71"  (CREEC pattern)
    """
    return operand_str.strip().split()[0].split(",")[0] if operand_str.strip() else ""


# ---------------------------------------------------------------------------
# Source 1: Raw ASM text scan
# ---------------------------------------------------------------------------

def scan_asm_file(path: Path, stem: str) -> List[EdgeDetail]:
    """Scan a raw HLASM file for ENTRC/ENTNC/CREEC instructions.

    This is the most complete source — catches code in unlabeled entry
    sections before the first labeled block, which JSON blueprints may miss.

    HLASM column layout:
      Col 1-8:  Label (optional) — blank col 1 means no label
      Col 10+:  Opcode
      Col 16+:  Operands
    """
    edges: List[EdgeDetail] = []
    seen: Set[Tuple] = set()

    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return edges

    for line_num, raw in enumerate(text.splitlines(), 1):
        stripped = raw.lstrip()
        # Skip blank lines and comment lines
        if not stripped or stripped.startswith("*"):
            continue

        # Determine opcode position based on whether col 1 is blank
        tokens = raw.split()
        if not tokens:
            continue

        if raw[0] == " ":
            # No label: first token is the opcode
            opcode = tokens[0].upper()
            operand_str = tokens[1] if len(tokens) > 1 else ""
        else:
            # Label in col 1: second token is the opcode
            opcode = tokens[1].upper() if len(tokens) > 1 else ""
            operand_str = tokens[2] if len(tokens) > 2 else ""

        is_function_macro = (opcode == FUNCTION_MACRO)
        if opcode not in ASM_CROSS_MODULE and not is_function_macro:
            continue

        if is_function_macro:
            # FUNCTION CIPS,LU84  →  args: ["CIPS", "LU84"]  →  target = "LU84" (second token)
            parts = operand_str.split(",")
            target = parts[1].split()[0] if len(parts) > 1 else ""
            effective_opcode = "FUNCTION"
        else:
            target = _extract_operand_target(operand_str)
            effective_opcode = opcode

        if not target or not target[0].isalpha():
            continue

        target_upper = target.upper()
        key = (stem, target_upper, effective_opcode, line_num)
        if key not in seen:
            seen.add(key)
            edges.append(EdgeDetail(
                source_stem=stem,
                target_module=target_upper,
                instruction=effective_opcode,
                line=line_num,
                source_file=path.name,
                source_block="",
                call_type=INSTRUCTION_CALL_TYPE.get(effective_opcode, ""),
            ))

    return edges


# ---------------------------------------------------------------------------
# Source 2: Blueprint JSON scan (ASM files)
# ---------------------------------------------------------------------------

def _scan_flow_items(flow: list, stem: str, source_file: str,
                     block_id: str, seen: Set[Tuple]) -> List[EdgeDetail]:
    """Extract cross-module edges from a block/subroutine flow list."""
    edges = []
    for item in flow or []:
        inst = str(item.get("inst", "")).upper()
        is_function = (inst == FUNCTION_MACRO)
        if inst not in ASM_CROSS_MODULE and not is_function:
            continue
        args = item.get("args") or []
        if is_function:
            # FUNCTION args: [msg_code, target_segment, ...]  e.g. ["CIPS", "LU84"]
            operand_str = args[1] if len(args) > 1 else ""
        else:
            operand_str = args[0] if args else ""
        target = _extract_operand_target(operand_str) if operand_str else ""
        if not target or not target[0].isalpha():
            continue
        target_upper = target.upper()
        line_num = int(item.get("line") or 0)
        key = (stem, target_upper, inst, line_num)
        if key not in seen:
            seen.add(key)
            edges.append(EdgeDetail(
                source_stem=stem,
                target_module=target_upper,
                instruction=inst,
                line=line_num,
                source_file=source_file,
                source_block=block_id,
                call_type=INSTRUCTION_CALL_TYPE.get(inst, ""),
            ))
    return edges


def scan_blueprint_asm(path: Path, stem: str) -> List[EdgeDetail]:
    """Extract cross-module edges from an .asm.json blueprint file.

    Sources (in order, with deduplication):
      1. call_graph.edges where instruction in ASM_CROSS_MODULE
      2. blocks[].flow  as fallback (catches edges the call_graph may miss)
      3. subroutines[].flow as fallback
    """
    try:
        blueprint = load_blueprint(
            path, skip_global_lineage=True, keys={"call_graph", "blocks", "subroutines"}
        )
    except (OSError, json.JSONDecodeError):
        return []

    source_file = path.name.replace(".json", "")  # "da76.asm"
    edges: List[EdgeDetail] = []
    seen: Set[Tuple] = set()

    # Set of all instructions we care about from call_graph.edges
    _ASM_EDGES_WANTED = ASM_CROSS_MODULE | {FUNCTION_MACRO}

    # Source 1: call_graph.edges
    for edge in blueprint.get("call_graph", {}).get("edges", []):
        inst = str(edge.get("instruction", "")).upper()
        if inst not in _ASM_EDGES_WANTED:
            continue
        target = edge.get("target") or ""
        if not target or not str(target)[0].isalpha():
            continue
        target_upper = str(target).split()[0].split(",")[0].upper()
        line_num = int(edge.get("line") or 0)
        key = (stem, target_upper, inst, line_num)
        if key not in seen:
            seen.add(key)
            edges.append(EdgeDetail(
                source_stem=stem,
                target_module=target_upper,
                instruction=inst,
                line=line_num,
                source_file=source_file,
                source_block=str(edge.get("source", "")),
                call_type=str(edge.get("call_type", INSTRUCTION_CALL_TYPE.get(inst, ""))),
                indirection=extract_indirection(edge),
            ))

    # Source 2: blocks[].flow (fallback)
    for block in blueprint.get("blocks", []):
        block_id = str(block.get("id", ""))
        edges.extend(_scan_flow_items(list(iter_flow(block)),
                                      stem, source_file, block_id, seen))

    # Source 3: subroutines[].flow (fallback)
    for sub in blueprint.get("subroutines", []):
        sub_id = str(sub.get("id", ""))
        edges.extend(_scan_flow_items(list(iter_flow(sub)),
                                      stem, source_file, sub_id, seen))

    return edges


# ---------------------------------------------------------------------------
# Source 3: Blueprint JSON scan (C++ files)
# ---------------------------------------------------------------------------

def scan_blueprint_cpp(path: Path, stem: str) -> List[EdgeDetail]:
    """Extract cross-module edges from a .cpp.json blueprint file.

    CALL_ALIAS edges → always C++ → ASM (include all)
    CALL edges      → may be C++ → C++ or C++ → ASM
                      - Gap 2: suppressed when target is a key in symbol_aliases
                        (the CALL_ALIAS for the same site already captures it)
                      - All other CALL edges pass to CallGraphBuilder.build()
                        which applies Gap 1 / Gap 3 logic for unresolved ones
    INCLUDE edges   → Gap 4: emitted from file_dependencies.edges whose evidence
                      has dependency_type == "cpp_include"
    """
    try:
        blueprint = load_blueprint(
            path,
            skip_global_lineage=True,
            keys={"call_graph", "symbol_aliases", "file_dependencies"},
        )
    except (OSError, json.JSONDecodeError):
        return []

    source_file = path.name.replace(".json", "")  # "dx740200.cpp"
    edges: List[EdgeDetail] = []
    seen: Set[Tuple] = set()

    # Gap 2: build the set of C++ wrapper names that already have a CALL_ALIAS.
    # symbol_aliases = { cpp_name: asm_alias, ... }  e.g. {"initCCR": "AI71"}
    symbol_aliases = blueprint.get("symbol_aliases") or {}
    alias_cpp_names: Set[str] = {k.lower() for k in symbol_aliases}

    for edge in blueprint.get("call_graph", {}).get("edges", []):
        inst = str(edge.get("instruction", "")).upper()
        target = edge.get("target") or ""
        if not target:
            continue
        target_upper = str(target).split()[0].split(",")[0].upper()

        if inst in CPP_ALWAYS_CROSS:
            pass  # always include CALL_ALIAS
        elif inst == "CALL":
            # Fix 3: suppress local-variable invocations (lambdas, unresolved fp vars).
            # The analyzer marks these edges with is_local_var=True in the blueprint.
            if edge.get("is_local_var"):
                continue
            # Indirect calls with a RESOLVED target (FP traced through fp_sources,
            # CHA-expanded vtable, etc.) are preserved here; the envelope on the
            # EdgeDetail records that the call site was indirect.  Unresolved
            # indirect calls (target=None) are already dropped by the
            # ``if not target: continue`` check at the top of this loop.
            #
            # Skip dot-access (obj.method) and arrow-access (ptr->method) forms.
            # With Fix 2/4 these are now transformed to FQNs in _iter_callsites(), so
            # raw dot/arrow forms that still appear here were not resolved and should be
            # dropped as before.
            if ("." in target and "::" not in target) or "->" in target:
                continue
            # Gap 2: suppress phantom CALL when a CALL_ALIAS already captures this
            # target.  The C++ wrapper name (e.g. "initCCR") is in symbol_aliases
            # iff it was declared with asm("AI71"), guaranteeing a CALL_ALIAS edge.
            if target_upper.lower() in alias_cpp_names:
                continue
        else:
            continue

        line_num = int(edge.get("line") or 0)
        key = (stem, target_upper, inst, line_num)
        if key not in seen:
            seen.add(key)
            edges.append(EdgeDetail(
                source_stem=stem,
                target_module=target_upper,
                instruction=inst,
                line=line_num,
                source_file=source_file,
                source_block=str(edge.get("source", "")),
                call_type=str(edge.get("call_type", INSTRUCTION_CALL_TYPE.get(inst, ""))),
                indirection=extract_indirection(edge),
            ))

    # Gap 4: emit INCLUDE edges from file_dependencies populated by CFamilyAnalyzer.
    # Each edge whose evidence contains dependency_type == "cpp_include" becomes an
    # INCLUDE EdgeDetail with the header basename as the target module.
    for dep_edge in (blueprint.get("file_dependencies") or {}).get("edges") or []:
        evidence_list = dep_edge.get("evidence") or []
        if not any(ev.get("dependency_type") == "cpp_include" for ev in evidence_list):
            continue
        to_file = dep_edge.get("to_file") or ""
        if not to_file:
            continue
        header_name = Path(to_file).name  # basename only — machine-independent
        key = (stem, header_name, CPP_INCLUDE_INSTR, 0)
        if key not in seen:
            seen.add(key)
            edges.append(EdgeDetail(
                source_stem=stem,
                target_module=header_name,
                instruction=CPP_INCLUDE_INSTR,
                line=0,
                source_file=source_file,
                source_block="",
                call_type=INSTRUCTION_CALL_TYPE.get(CPP_INCLUDE_INSTR, ""),
            ))

    return edges


# ---------------------------------------------------------------------------
# CallGraphBuilder
# ---------------------------------------------------------------------------

def _derive_stem(path: Path) -> str:
    """Derive file stem from a path.

    Examples:
      "da76.asm.json" → "da76"
      "dx740200.cpp.json" → "dx740200"
      "cctestshared.hpp.json" → "cctestshared"
      "da76.asm" → "da76"
    """
    name = path.name
    for suffix in (".asm.json", ".cpp.json", ".hpp.json", ".h.json", ".asm", ".cpp"):
        if name.endswith(suffix):
            return name[: -len(suffix)].lower()
    return path.stem.lower()


class CallGraphBuilder:
    """Discovers files, scans for cross-module calls, and resolves targets."""

    def __init__(
        self,
        asm_dir: Optional[Path] = None,
        blueprint_dir: Optional[Path] = None,
        recursive: bool = False,
    ):
        self.asm_dir = asm_dir
        self.blueprint_dir = blueprint_dir
        self.recursive = recursive
        self.warnings: List[str] = []

    def _glob(self, directory: Path, pattern: str) -> List[Path]:
        if self.recursive:
            return sorted(directory.rglob(pattern))
        return sorted(directory.glob(pattern))

    def _build_stem_universe(self) -> Tuple[Set[str], Set[str], Set[str]]:
        """Return (asm_stems, cpp_stems, header_stems) from all discoverable files.

        header_stems is a subset of cpp_stems (hpp blueprints contribute to both).
        Including header stems in cpp_stems allows inline header-only functions
        (e.g. computeChecksum in cctestshared.hpp) to resolve as internal edges.
        """
        asm_stems: Set[str] = set()
        cpp_stems: Set[str] = set()
        header_stems: Set[str] = set()

        if self.blueprint_dir and self.blueprint_dir.exists():
            for p in self._glob(self.blueprint_dir, "*.asm.json"):
                asm_stems.add(_derive_stem(p))
            for p in self._glob(self.blueprint_dir, "*.cpp.json"):
                cpp_stems.add(_derive_stem(p))
            for p in self._glob(self.blueprint_dir, "*.hpp.json"):
                stem = _derive_stem(p)
                header_stems.add(stem)
                cpp_stems.add(stem)  # also in cpp_stems so _resolve() can find them

        if self.asm_dir and self.asm_dir.exists():
            for p in self._glob(self.asm_dir, "*.asm"):
                asm_stems.add(_derive_stem(p))

        return asm_stems, cpp_stems, header_stems

    def _resolve(self, target_module: str, all_stems: Set[str]) -> Optional[str]:
        """Resolve a module name to a known file stem (case-insensitive)."""
        lower = target_module.lower()
        return lower if lower in all_stems else None

    def _build_cpp_lookup_maps(self) -> Tuple[Dict[str, str], Dict[str, str]]:
        """Build two lookup maps from all .cpp.json blueprints.

        Returns:
          cpp_fn_to_stem:    C++ function name (asm_entry_point_map values) → cpp stem
                             Used to resolve C++→C++ CALL edges (target is a C++ fn name).
          asm_entry_to_stem: ASM entry-point name (asm_entry_point_map keys) → cpp stem
                             Used to resolve ASM→C++ and C++→C++ CALL_ALIAS edges
                             where the target is an ASM-callable alias like "XH89" or "AI71".
        """
        cpp_fn_to_stem: Dict[str, str] = {}
        asm_entry_to_stem: Dict[str, str] = {}
        if not (self.blueprint_dir and self.blueprint_dir.exists()):
            return cpp_fn_to_stem, asm_entry_to_stem

        def _load_one(p: Path) -> Tuple[str, Dict[str, str], Dict[str, str]]:
            stem = _derive_stem(p)
            _asm: Dict[str, str] = {}
            _fn: Dict[str, str] = {}
            try:
                bp = load_blueprint(
                    p, skip_global_lineage=True, keys={"asm_entry_point_map", "symbols"}
                )
            except Exception:
                return stem, _asm, _fn
            for asm_name, fn_name in (bp.get("asm_entry_point_map") or {}).items():
                _asm[asm_name.lower()] = stem
                _fn_lower = fn_name.lower()
                _fn[_fn_lower] = stem
                # G09: register class-name prefix so synthetic ctor calls resolve
                if "::" in _fn_lower:
                    _fn.setdefault(_fn_lower.rsplit("::", 1)[0], stem)
                # C19: tree-sitter may register "ClassName::operator" (no parens) for
                # operator() definitions; the analyzer yields "ClassName::operator()"
                # so register both forms.
                if _fn_lower.endswith("::operator"):
                    _fn.setdefault(_fn_lower + "()", stem)
            for name, sym in bp.get("symbols", {}).get("global_symbols", {}).items():
                if (sym.get("type") or "") == "entry":
                    _name_lower = name.lower()
                    _fn[_name_lower] = stem
                    _asm[_name_lower] = stem
                    # G09: register class-name prefix so synthetic ctor calls resolve
                    if "::" in _name_lower:
                        _fn.setdefault(_name_lower.rsplit("::", 1)[0], stem)
                    # C19: same operator() registration for global_symbols path
                    if _name_lower.endswith("::operator"):
                        _fn.setdefault(_name_lower + "()", stem)
            return stem, _asm, _fn

        # Load both *.cpp.json and *.hpp.json so inline header-only functions
        # (e.g. computeChecksum in cctestshared.hpp) resolve as internal edges.
        cpp_files = list(self._glob(self.blueprint_dir, "*.cpp.json"))
        cpp_files += list(self._glob(self.blueprint_dir, "*.hpp.json"))
        with ThreadPoolExecutor(max_workers=_SCAN_WORKERS) as pool:
            _lm_futures = {pool.submit(_load_one, p): p for p in cpp_files}
            for fut in as_completed(_lm_futures):
                try:
                    _stem, _asm, _fn = fut.result(timeout=_BP_IO_TIMEOUT)
                except (_FuturesTimeoutError, Exception):
                    continue
                for k, v in _asm.items():
                    asm_entry_to_stem.setdefault(k, v)
                for k, v in _fn.items():
                    cpp_fn_to_stem.setdefault(k, v)
        return cpp_fn_to_stem, asm_entry_to_stem

    def _build_global_subclasses(self) -> Dict[str, List[str]]:
        """Build a global base→[subclasses] map by merging class_bases from all blueprints.

        Enables cross-TU CHA: a subclass defined in a different .cpp file can be
        found when its base class is called via a pointer/reference in another file.
        """
        global_subclasses: Dict[str, List[str]] = {}
        if not (self.blueprint_dir and self.blueprint_dir.exists()):
            return global_subclasses
        for p in self._glob(self.blueprint_dir, "*.cpp.json"):
            try:
                bp = load_blueprint(p, skip_global_lineage=True, keys={"class_bases"})
            except Exception:
                continue
            for derived, bases in (bp.get("class_bases") or {}).items():
                for base in (bases or []):
                    if base and derived not in global_subclasses.get(base, []):
                        global_subclasses.setdefault(base, []).append(derived)
        return global_subclasses

    def build(self) -> CallGraph:
        asm_stems, cpp_stems, header_stems = self._build_stem_universe()
        all_stems = asm_stems | cpp_stems

        if not all_stems:
            self.warnings.append(
                "No files found. Check --asm-dir and --blueprint-dir arguments."
            )
            return CallGraph([], set(), set(), self.warnings)

        # Build lookup maps for C++ entry-point resolution
        cpp_fn_to_stem, asm_entry_to_stem = self._build_cpp_lookup_maps()

        # P11: Build global subclass map for cross-TU CHA expansion.
        global_subclasses = self._build_global_subclasses()

        # Collect all raw EdgeDetail objects — parallel I/O-bound scan.
        all_edges: List[EdgeDetail] = []
        global_seen: Set[Tuple] = set()

        def _merge(edge_lists):
            """Merge per-file EdgeDetail lists into all_edges with deduplication."""
            for edges in edge_lists:
                for ed in edges:
                    if ed.dedup_key() not in global_seen:
                        global_seen.add(ed.dedup_key())
                        all_edges.append(ed)

        # --- ASM blueprint scan (parallel) ---
        # Results are merged immediately as each future completes rather than
        # accumulated into a list first — for 14 K files this avoids holding
        # all 14 K per-file EdgeDetail lists in memory simultaneously before
        # _merge() is called.
        if self.blueprint_dir and self.blueprint_dir.exists():
            asm_bp_files = self._glob(self.blueprint_dir, "*.asm.json")
            with ThreadPoolExecutor(max_workers=_SCAN_WORKERS) as pool:
                _bp_futures = {
                    pool.submit(scan_blueprint_asm, p, _derive_stem(p)): p
                    for p in asm_bp_files
                }
                for _f in as_completed(_bp_futures):
                    try:
                        _merge([_f.result(timeout=_BP_IO_TIMEOUT)])
                    except _FuturesTimeoutError:
                        pass
                    except Exception:
                        pass

            # --- C++ blueprint scan (parallel) ---
            cpp_bp_files = self._glob(self.blueprint_dir, "*.cpp.json")
            with ThreadPoolExecutor(max_workers=_SCAN_WORKERS) as pool:
                _cpp_futures = {
                    pool.submit(scan_blueprint_cpp, p, _derive_stem(p)): p
                    for p in cpp_bp_files
                }
                for _f in as_completed(_cpp_futures):
                    try:
                        _merge([_f.result(timeout=_BP_IO_TIMEOUT)])
                    except _FuturesTimeoutError:
                        pass
                    except Exception:
                        pass

        # --- Raw ASM scan (parallel — supplements blueprint, catches unlabeled entry code) ---
        if self.asm_dir and self.asm_dir.exists():
            asm_src_files = self._glob(self.asm_dir, "*.asm")
            with ThreadPoolExecutor(max_workers=_SCAN_WORKERS) as pool:
                _asm_futures = {
                    pool.submit(scan_asm_file, p, _derive_stem(p)): p
                    for p in asm_src_files
                }
                for _f in as_completed(_asm_futures):
                    try:
                        _merge([_f.result(timeout=_BP_IO_TIMEOUT)])
                    except _FuturesTimeoutError:
                        pass
                    except Exception:
                        pass

        # Resolve targets and group into FileEdge objects
        # Key: (source_stem, resolved_target_stem_or_module)
        edge_map: Dict[Tuple[str, str], FileEdge] = {}

        for ed in all_edges:
            resolved = self._resolve(ed.target_module, all_stems)

            if resolved is None:
                lower = ed.target_module.lower()
                for lookup in (cpp_fn_to_stem, asm_entry_to_stem):
                    candidate = lookup.get(lower)
                    if candidate is not None and candidate != ed.source_stem:
                        resolved = candidate
                        break

            # Namespace-qualified call: strip all namespace prefixes and retry.
            # e.g. "TxShared::sharedEntry" → strip "TxShared::" → look up "sharedentry".
            if resolved is None and "::" in ed.target_module:
                tail = ed.target_module.split("::")[-1].lower()
                if tail:
                    for lookup in (cpp_fn_to_stem, asm_entry_to_stem):
                        candidate = lookup.get(tail)
                        if candidate is not None and candidate != ed.source_stem:
                            resolved = candidate
                            break

            if resolved is None and ed.instruction == "CALL":
                if ed.source_stem in cpp_stems:
                    lower = ed.target_module.lower()
                    # Drop targets that aren't valid identifiers (e.g. "-" artefacts).
                    if not ed.target_module or not ed.target_module[0].isalpha():
                        continue
                    # Drop same-file internal calls (target defined in this very file).
                    if (cpp_fn_to_stem.get(lower) == ed.source_stem
                            or asm_entry_to_stem.get(lower) == ed.source_stem):
                        continue
                    # Drop known platform / stdlib noise — checked BEFORE ASM_MODULE_RE
                    # so short names like CRUSA, GLOB, FREE, TIME (which happen to match
                    # the ASM module name pattern) are still suppressed correctly.
                    if lower in _CPP_STDLIB_NOISE:
                        continue
                    # Gap 1: extern "C" func called by bare ASM module name without
                    # asm() qualifier (e.g. NB81, YK11, VP18). Keep as external ASM edge.
                    if ASM_MODULE_RE.match(ed.target_module):
                        pass  # fall through to emit as external edge
                    # Gap 3: cross-DLL C++ business-logic call (e.g. callInquiryMonitor,
                    # applyManReAge). Keep as external C++ call edge.
                    else:
                        pass  # fall through to emit as external edge
                else:
                    continue  # unresolved CALL from non-C++ source — drop (unchanged)

            target_key = resolved if resolved is not None else ed.target_module
            map_key = (ed.source_stem, target_key)

            if map_key not in edge_map:
                edge_map[map_key] = FileEdge(
                    source_stem=ed.source_stem,
                    target_stem=resolved,
                    target_module=ed.target_module if resolved is None else resolved,
                    is_internal=(resolved is not None),
                )
            # If multiple call sites resolve to the same (source, target) pair but
            # with different raw module names (e.g., DA78 and DA78X both → da78),
            # keep the raw name from the first site; subsequent sites just add their
            # EdgeDetail to the same FileEdge.
            edge_map[map_key].call_sites.append(ed)

        # P11: Cross-TU CHA expansion.
        # For each unresolved FQN edge (e.g. "BaseT::vfunc" → external),
        # check if any known subclasses from other blueprints override the method.
        if global_subclasses:
            # Build a lowercase index so matching is case-insensitive
            # (target_module values may be uppercased by the scanner).
            gs_lower: Dict[str, List[str]] = {}
            for base, subs in global_subclasses.items():
                gs_lower.setdefault(base.lower(), []).extend(subs)
            for fEdge in list(edge_map.values()):
                if fEdge.is_internal:
                    continue  # already resolved; no cross-TU expansion needed
                for ed in list(fEdge.call_sites):
                    if "::" not in ed.target_module:
                        continue
                    parts = ed.target_module.split("::")
                    base_class_lower = parts[0].lower()
                    method_name = parts[-1].lower()
                    for subclass in gs_lower.get(base_class_lower, []):
                        sc_fqn_lower = f"{subclass.lower()}::{method_name}"
                        # Try full FQN lookup first, then tail-only
                        sc_resolved = (
                            cpp_fn_to_stem.get(sc_fqn_lower)
                            or cpp_fn_to_stem.get(method_name)
                        )
                        if sc_resolved and sc_resolved != ed.source_stem:
                            sc_map_key = (ed.source_stem, sc_resolved)
                            if sc_map_key not in edge_map:
                                edge_map[sc_map_key] = FileEdge(
                                    source_stem=ed.source_stem,
                                    target_stem=sc_resolved,
                                    target_module=sc_resolved,
                                    is_internal=True,
                                )
                            edge_map[sc_map_key].call_sites.append(ed)

        file_edges = list(edge_map.values())
        return CallGraph(file_edges, asm_stems, cpp_stems, self.warnings, header_stems)


# ---------------------------------------------------------------------------
# Output formatters
# ---------------------------------------------------------------------------

def format_json(graph: CallGraph, include_external: bool = True) -> str:
    """Produce JSON call graph output."""
    # Build node list (deduplicated)
    node_ids: Dict[str, dict] = {}
    for stem in sorted(graph.all_asm_stems):
        node_ids[stem] = {"id": stem, "type": "asm", "file": stem + ".asm"}
    for stem in sorted(graph.all_cpp_stems - graph.all_header_stems):
        node_ids[stem] = {"id": stem, "type": "cpp", "file": stem + ".cpp"}
    for stem in sorted(graph.all_header_stems):
        node_ids[stem] = {"id": stem, "type": "header", "file": stem + ".hpp"}

    if include_external:
        for fe in graph.file_edges:
            if not fe.is_internal:
                node_ids.setdefault(fe.target_module, {
                    "id": fe.target_module,
                    "type": "external",
                    "file": None,
                })

    # Build edge list
    edges_out = []
    for fe in sorted(graph.file_edges,
                     key=lambda e: (e.source_stem, e.target_stem or e.target_module)):
        if not include_external and not fe.is_internal:
            continue

        call_sites_out = []
        edge_has_indirect = False
        for cs in sorted(fe.call_sites, key=lambda c: c.line):
            cs_dict: Dict[str, Any] = {
                "source_block": cs.source_block,
                "target_module": cs.target_module,
                "instruction": cs.instruction,
                "call_type": cs.call_type,
                "line": cs.line,
                "source_file": cs.source_file,
            }
            if cs.indirection:
                cs_dict["indirection"] = dict(cs.indirection)
                edge_has_indirect = True
            call_sites_out.append(cs_dict)

        edge_out: Dict[str, Any] = {
            "source": fe.source_stem,
            "target": fe.target_stem if fe.is_internal else fe.target_module,
            "is_internal": fe.is_internal,
            "instructions": fe.instructions,
            "call_sites": call_sites_out,
        }
        # Edge-level summary flag — true when any call_site is indirect.
        # Lets graph-walking consumers filter without iterating call_sites.
        if edge_has_indirect:
            edge_out["has_indirect_call"] = True
        edges_out.append(edge_out)

    internal_count = sum(1 for fe in graph.file_edges if fe.is_internal)
    external_count = sum(1 for fe in graph.file_edges if not fe.is_internal)
    unresolved_modules = {fe.target_module for fe in graph.file_edges if not fe.is_internal}

    output = {
        "metadata": {
            "generator": "file_call_graph.py",
            "blueprint_dir": str(graph.__dict__.get("_blueprint_dir", "")),
            "asm_dir": str(graph.__dict__.get("_asm_dir", "")),
            "known_asm_files": sorted(graph.all_asm_stems),
            "known_cpp_files": sorted(graph.all_cpp_stems - graph.all_header_stems),
            "known_header_files": sorted(graph.all_header_stems),
        },
        "nodes": list(node_ids.values()),
        "edges": edges_out,
        "warnings": graph.warnings,
        "summary": {
            "internal_edge_count": internal_count,
            "external_edge_count": external_count,
            "unresolved_module_count": len(unresolved_modules),
        },
    }
    return json.dumps(output, separators=(",", ":"))


def format_dot(graph: CallGraph, include_external: bool = True) -> str:
    """Produce Graphviz DOT format call graph."""
    lines = [
        "digraph file_call_graph {",
        "    rankdir=LR;",
        "    node [fontname=Courier];",
        "    edge [fontname=Courier, fontsize=10];",
        "",
        "    // Known ASM file nodes",
    ]

    for stem in sorted(graph.all_asm_stems):
        lines.append(
            f'    "{stem}" [shape=box, style=filled, fillcolor=lightblue, '
            f'label="{stem}.asm"];'
        )

    cpp_only_stems = graph.all_cpp_stems - graph.all_header_stems
    if cpp_only_stems:
        lines.append("")
        lines.append("    // Known C++ file nodes")
        for stem in sorted(cpp_only_stems):
            lines.append(
                f'    "{stem}" [shape=box, style=filled, fillcolor=lightgreen, '
                f'label="{stem}.cpp"];'
            )
    if graph.all_header_stems:
        lines.append("")
        lines.append("    // Known C++ header nodes")
        for stem in sorted(graph.all_header_stems):
            lines.append(
                f'    "{stem}" [shape=box, style=filled, fillcolor=palegreen, '
                f'label="{stem}.hpp"];'
            )

    if include_external:
        ext_modules = {
            fe.target_module for fe in graph.file_edges if not fe.is_internal
        }
        if ext_modules:
            lines.append("")
            lines.append("    // External module nodes")
            for mod in sorted(ext_modules):
                lines.append(
                    f'    "{mod}" [shape=ellipse, style=filled, fillcolor=lightyellow, '
                    f'label="{mod}\\n(external)"];'
                )

    # Aggregate edges by (source, target, instruction) for cleaner graph
    edge_counts: Dict[Tuple[str, str, str], int] = defaultdict(int)
    edge_targets: Dict[Tuple[str, str, str], str] = {}
    for fe in graph.file_edges:
        if not include_external and not fe.is_internal:
            continue
        target_id = fe.target_stem if fe.is_internal else fe.target_module
        for inst in fe.instructions:
            key = (fe.source_stem, target_id, inst)
            edge_counts[key] += sum(1 for cs in fe.call_sites if cs.instruction == inst)
            edge_targets[key] = target_id

    if edge_counts:
        lines.append("")
        lines.append("    // Edges")
        for (src, tgt, inst), count in sorted(edge_counts.items()):
            style = DOT_EDGE_STYLE.get(inst, {"color": "black", "style": "solid"})
            label = inst if count == 1 else f"{inst} x{count}"
            lines.append(
                f'    "{src}" -> "{tgt}" '
                f'[label="{label}", color={style["color"]}, style={style["style"]}];'
            )

    lines.append("}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="file_call_graph.py",
        description=(
            "Build a file-level call graph for HLASM and C++ files.\n"
            "At least one of --asm-dir or --blueprint-dir is required."
        ),
    )
    p.add_argument(
        "--asm-dir",
        metavar="DIR",
        help="Directory of raw .asm files (recommended for complete ENTNC/CREEC coverage)",
    )
    p.add_argument(
        "--blueprint-dir",
        metavar="DIR",
        help="Directory of .asm.json and .cpp.json blueprint files",
    )
    p.add_argument(
        "--format",
        choices=["json", "dot"],
        default="json",
        help="Output format: json (default) or dot (Graphviz)",
    )
    p.add_argument(
        "--recursive",
        action="store_true",
        help="Search directories recursively for files",
    )
    p.add_argument(
        "--output",
        metavar="FILE",
        help="Write output to FILE instead of stdout",
    )
    p.add_argument(
        "--no-include-external",
        action="store_true",
        help="Suppress external (unresolved) module nodes from output",
    )
    return p


def main() -> int:
    args = build_arg_parser().parse_args()

    if not args.asm_dir and not args.blueprint_dir:
        print(
            "error: at least one of --asm-dir or --blueprint-dir is required",
            file=sys.stderr,
        )
        return 1

    asm_dir = Path(args.asm_dir).resolve() if args.asm_dir else None
    blueprint_dir = Path(args.blueprint_dir).resolve() if args.blueprint_dir else None

    if asm_dir and not asm_dir.exists():
        print(f"error: --asm-dir not found: {asm_dir}", file=sys.stderr)
        return 1
    if blueprint_dir and not blueprint_dir.exists():
        print(f"error: --blueprint-dir not found: {blueprint_dir}", file=sys.stderr)
        return 1

    builder = CallGraphBuilder(
        asm_dir=asm_dir,
        blueprint_dir=blueprint_dir,
        recursive=args.recursive,
    )
    graph = builder.build()

    # Attach dir info for metadata output
    graph.__dict__["_blueprint_dir"] = str(blueprint_dir) if blueprint_dir else ""
    graph.__dict__["_asm_dir"] = str(asm_dir) if asm_dir else ""

    if not graph.all_stems:
        print(
            "error: no .asm or .json files found. "
            "Check --asm-dir and --blueprint-dir paths.",
            file=sys.stderr,
        )
        return 1

    include_external = not args.no_include_external

    if args.format == "dot":
        output = format_dot(graph, include_external=include_external)
    else:
        output = format_json(graph, include_external=include_external)

    if graph.warnings:
        for w in graph.warnings:
            print(f"warning: {w}", file=sys.stderr)

    if args.output:
        out_path = Path(args.output)
        out_path.write_text(output, encoding="utf-8")
        print(f"Wrote {args.format} call graph to: {out_path}", file=sys.stderr)
    else:
        print(output)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
