# VBT Setter Conditions Reachability

A standalone CLI tool to query variable setters across the codebase using the precomputed `index.db` (zero disk/source reads) and extract the **exact reachability conditions** (control flow guards) required to reach those setters within their target C++ functions or ASM blocks.

| Artifact | Path |
|----------|------|
| Standalone CLI | `find_setter_conditions.py` (repo root) |
| Unit Tests | `vbt/tests/test_setter_conditions.py` |

---

## Features

1. **Auto-Language Detection**: Checks the modifier index to dynamically determine if the input variable is C++ or Assembly.
2. **Precomputed Database Lookups**: Uses the precomputed `asm_setter_map` and `cpp_setter_map` in the DB for $O(1)$ setter site retrieval.
3. **Database-Backed Overrides (Zero Disk Reads)**: Intercepts source and blueprint file requests using database overrides (`install_source_override` and `install_asm_blueprint_override`). If the precompute is warm, the script extracts conditions entirely from SQLite blobs without reading the local file system.
4. **Detailed Guard Extraction**:
   * **C++**: Performs heuristic backward brace tracking to identify nested scopes (`if`, `while`, `for` loops) enclosing the setter.
   * **ASM**: Resolves intra-block triggering compares and branches (`CLC` / `BNE`, `TM` / `JZ`, etc.) and block-entry guards recursively.

---

## How It Works

* **C++ Conditions**:
  For C++ setter sites, the script walks backward from the setter's line number in the source file, tracking nesting level braces (`{` and `}`). It captures all parent `if`, `while`, and `for` condition headers (innermost first) that guard execution flow leading to that setter.
* **ASM Conditions**:
  For ASM setter sites, the script identifies the basic block enclosing the setter line. It walks backward through the block's control flow to identify Trigger + Branch pairs (such as a comparison instruction setting the condition code followed by a conditional branch). It then recursively walks predecessor blocks in the CFG to trace entry conditions.

---

## CLI Usage

Run the tool using the repository's virtual environment:

```bash
# Auto-detect language and find conditions for C++ variable 'softCardValue'
env/bin/python3 find_setter_conditions.py --variable softCardValue

# Auto-detect language and find conditions for ASM variable 'LWRAW_LSTACTDT'
env/bin/python3 find_setter_conditions.py --variable LWRAW_LSTACTDT

# Restrict the search to a specific file stem (e.g. yb07)
env/bin/python3 find_setter_conditions.py --variable LWRAW_LSTACTDT --stem yb07

# Explicitly specify the language to bypass auto-detection
env/bin/python3 find_setter_conditions.py --variable softCardValue --language cpp
```

### Options

| Flag | Default | Description |
|------|---------|-------------|
| `--job-id` | `b58d8432-73e0-42d1-89a9-2ceebc47c6d2` | Precomputed Job ID whose SQLite index holds the cache |
| `--variable` | *Required* | Variable name to query |
| `--stem` | `None` | Optional stem filename to filter setter locations |
| `--language` | `None` | Optional language indicator (`cpp` or `asm`). Auto-detected if omitted. |

---

## Example Output

### C++ Setter Conditions
```
Setter Site #13: dw780000.cpp @ line 481
  Context: inside function/block 'selectCidDbRecord15'
  Code: plasticAuth.process.transactionInds.softCardValue
  Reachability Conditions (innermost first):
    - line 478: if (if (lwrCommon.process.cid.cidioReturnCode == CidioReturn::NoCidRecord) {)
```

### ASM Setter Conditions
```
Setter Site #1: ai75.asm @ line 662
  Context: inside function/block 'AI75'
  Code: ZAP
  Reachability Conditions:
    - line 612 [LTGR]: R4 != 0
    - line 614 [CLC]: LWRAW_HDRI == =C'AW'
```

---

## Testing

Run the pytest unit tests to ensure that overrides and condition extraction for both languages function correctly:

```bash
env/bin/pytest vbt/tests/test_setter_conditions.py
```
