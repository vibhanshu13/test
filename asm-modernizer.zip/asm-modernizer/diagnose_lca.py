#!/usr/bin/env python3
import sys
import os
import time
from pathlib import Path
from collections import deque

# Ensure workspace root is in path
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

# 1. TRIPWIRES to guarantee zero file reads of source code or blueprints
import vbt.cpp_frontend.wrapper as _w
import backward_traversal.utils.blueprint_utils as _bu
import vbt.setters.cpp_setters as _cs
import vbt.setters.asm_setters as _as
import vbt.precompute.resolvers_db as _rd

def tripwire(name):
    def _boom(*args, **kwargs):
        raise AssertionError(f"TRIPWIRE TRIGGERED: '{name}' tried to read from filesystem!")
    return _boom

_w.run_cfg_extract = tripwire("run_cfg_extract")
_bu.load_json = tripwire("load_json")
_cs.find_cpp_setters_in_file = tripwire("find_cpp_setters_in_file")
_as.find_asm_setters_in_file = tripwire("find_asm_setters_in_file")
_rd.preload_resolvers = tripwire("preload_resolvers")

# Patch load_cpp_setters to tolerate schema changes / missing keys in older DBs
import vbt.precompute.cpp_setter_map_db as csm
real_load_cpp_setters = csm.load_cpp_setters

def patched_load_cpp_setters(job_id: str, stem: str, variable: str, fp=None):
    key = (job_id, stem)
    m = csm._LOADED.get(key, 0)
    if m == 0:
        payload = csm.DA.read_blob(job_id, f"{csm.CPP_SETTER_MAP_ARTIFACT}:{stem}")
        m = csm.DA.loads_gz(payload) if payload is not None else None
        csm._LOADED[key] = m
    if m is not None:
        rows = m.get(variable)
        if rows is not None:
            for d in rows:
                for field_name in csm._SS_FIELDS:
                    if field_name not in d:
                        if field_name in ("is_not_set", "constant_source", "prior_value_required", "is_declaration"):
                            d[field_name] = False
                        else:
                            d[field_name] = None
    return real_load_cpp_setters(job_id, stem, variable, fp)

csm.load_cpp_setters = patched_load_cpp_setters

# Also tripwire standard open for reading source or blueprint files
import builtins
real_open = builtins.open
def guarded_open(file, mode="r", *args, **kwargs):
    path_str = str(file)
    if "r" in mode or mode == "rb":
        # Block opening source code and blueprint JSONs
        if any(path_str.endswith(ext) for ext in (".cpp", ".hpp", ".mac", ".asm", ".json")) and "index.db" not in path_str:
            raise AssertionError(f"TRIPWIRE TRIGGERED: tried to read file '{path_str}'!")
    return real_open(file, mode, *args, **kwargs)
builtins.open = guarded_open

print("[✓] Tripwires active. Absolutely no source/blueprint file reads will be permitted.")

# 2. Find precomputed VBT job
from vbt.tests._lca_corpus import find_chain_facts_job
job_info = find_chain_facts_job()
if job_info:
    job_id, bp_dir, src_dir = job_info
else:
    # Hardcoded fallback for this machine
    job_id = "b58d8432-73e0-42d1-89a9-2ceebc47c6d2"
    bp_dir = PROJECT_ROOT / "jobs" / job_id / "output" / "asm 5"
    src_dir = PROJECT_ROOT / "datasource" / "asm7_admin" / "asm 7_version_0" / "asm 5"
    if not (bp_dir.is_dir() and src_dir.is_dir()):
        print("Error: Fallback VBT job directories not found.")
        sys.exit(1)
print(f"[✓] Using precomputed job: {job_id}")

from vbt.lca_trace import (
    _db_only_setter_lca_context, _bfs, _reverse_adjacency, _node_id, _verified_common_ancestor
)

PA_ENTRY = ("dw710000", "callPlasticAuthenticationComponentInterface")

def find_shortest_path(start, end, fwd):
    if start == end:
        return [start]
    q = deque([[start]])
    seen = {start}
    while q:
        path = q.popleft()
        node = path[-1]
        for nxt in fwd.get(node, ()):
            if nxt == end:
                return path + [nxt]
            if nxt not in seen:
                seen.add(nxt)
                q.append(path + [nxt])
    return None

def diagnose_variable(variable: str, language: str, check_order: bool = False):
    print(f"\n==================================================")
    print(f"Diagnosing Variable: '{variable}' ({language.upper()})")
    print(f"==================================================")
    
    t_start = time.perf_counter()
    with _db_only_setter_lca_context(
        job_id, variable, language,
        blueprint_dir=str(bp_dir), asm_dir=str(src_dir),
        allow_unattributed_setters=True, allow_missing_forced_lca=True
    ) as inputs:
        adj = inputs.adj
        node_types = inputs.node_types
        setter_nodes = inputs.setter_nodes
        
        print(f"Discovered setter nodes ({len(setter_nodes)}):")
        for node in sorted(setter_nodes):
            nid = _node_id(node[0], node[1], node_types.get(node[0], "asm"))
            print(f"  - {nid}")
            
        if not setter_nodes:
            print("  (No setter nodes found)")
            return
            
        # Build forward adjacency list
        fwd = {k: {(cs, cf) for (cs, cf, _l, _c) in v} for k, v in adj.items()}
        rev = _reverse_adjacency(adj)
        
        # Ancestors of PA Entry
        anc_pa = _bfs(PA_ENTRY, rev)
        # Nodes reachable forward from PA Entry
        reachable_from_pa = _bfs(PA_ENTRY, fwd)
        
        print("\nReachability Analysis from PA Entry Point:")
        print(f"  PA Entry: {_node_id(PA_ENTRY[0], PA_ENTRY[1], 'cpp')}")
        
        for S in sorted(setter_nodes):
            snid = _node_id(S[0], S[1], node_types.get(S[0], "asm"))
            print(f"\n  Setter: {snid}")
            
            # Check 1: Is it called under the PA process?
            called_under_pa = S in reachable_from_pa
            print(f"    - Reachable forward from PA entry: {'YES' if called_under_pa else 'NO'}")
            
            # Check 2: Shared ancestor / Common LCA
            anc_s = _bfs(S, rev)
            shared_ancestors = anc_s & anc_pa
            print(f"    - Shares common ancestors with PA: {'YES' if shared_ancestors else 'NO'}")
            if shared_ancestors:
                ancestor_names = sorted(_node_id(n[0], n[1], node_types.get(n[0], 'asm')) for n in shared_ancestors)
                print(f"      Shared Ancestor Nodes: {', '.join(ancestor_names)}")
                # Find deepest shared ancestor
                anc_dict = {PA_ENTRY: anc_pa, S: anc_s}
                lca = _verified_common_ancestor([PA_ENTRY, S], anc_dict, fwd, {PA_ENTRY, S})
                if lca is None:
                    # If E reaches S, E is a common ancestor
                    lca = PA_ENTRY if S in reachable_from_pa else None
                
                lca_str = _node_id(lca[0], lca[1], node_types.get(lca[0], 'asm')) if lca else "unknown/root"
                print(f"    - Lowest Common Ancestor (LCA): {lca_str}")
                
                # Check 3: Static call order check (Only computed/checked when flag is set)
                if check_order:
                    if lca == PA_ENTRY:
                        print("    - Static Call Order: PA Entry is called first (it is an ancestor of the Setter)")
                    elif lca == S:
                        print("    - Static Call Order: Setter is called first (it is an ancestor of PA Entry)")
                    elif lca is not None:
                        # Both branch from LCA
                        path_to_pa = find_shortest_path(lca, PA_ENTRY, fwd)
                        path_to_s = find_shortest_path(lca, S, fwd)
                        if path_to_pa and len(path_to_pa) > 1 and path_to_s and len(path_to_s) > 1:
                            a1 = path_to_pa[1]
                            b1 = path_to_s[1]
                            
                            # Look up line numbers in LCA's adjacency
                            line_pa = None
                            line_s = None
                            for (cs, cf, line, _cross) in adj.get(lca, ()):
                                if cs == a1[0] and cf == a1[1]:
                                    line_pa = line
                                if cs == b1[0] and cf == b1[1]:
                                    line_s = line
                                    
                            if line_pa is not None and line_s is not None:
                                if line_pa < line_s:
                                    print(f"    - Static Call Order: Branch to PA Entry is initiated first (line {line_pa} vs line {line_s} in LCA)")
                                elif line_s < line_pa:
                                    print(f"    - Static Call Order: Branch to Setter is initiated first (line {line_s} vs line {line_pa} in LCA)")
                                else:
                                    print(f"    - Static Call Order: Both branches initiated at same location/line {line_pa} in LCA")
                            else:
                                print("    - Static Call Order: Branches diverge from LCA, but direct call site lines could not be resolved in the call graph")
                        else:
                            print("    - Static Call Order: Divergent paths from LCA could not be mapped")
                    else:
                        print("    - Static Call Order: No LCA found (diverge at root)")
                        
    t_end = time.perf_counter()
    print(f"Time taken: {(t_end - t_start) * 1000:.2f} ms")


def find_test_cases():
    from vbt.precompute.modifier_index import get_modifier_index
    from vbt.precompute.graph_db import load_fn_graph_adj
    from vbt.precompute import db_artifacts as DA
    from vbt.lca_trace import strict_load_resolvers
    
    prev = DA.is_load_only()
    try:
        DA.set_load_only(True)
        strict_load_resolvers(job_id, bp_dir, src_dir)
        midx = get_modifier_index(bp_dir, src_dir)
        adj = load_fn_graph_adj(job_id)
    finally:
        DA.set_load_only(prev)
        
    fwd = {k: {(cs, cf) for (cs, cf, _l, _c) in v} for k, v in adj.items()}
    reachable_from_pa = _bfs(PA_ENTRY, fwd)
    reachable_stems = {node[0] for node in reachable_from_pa}
    
    pos_cpp, neg_cpp = None, None
    pos_asm, neg_asm = None, None
    
        # Find C++ variables
    pos_cpp = "softCardValue"
    for var, stems in sorted(midx.cpp.items()):
        has_pos = any(s in reachable_stems for s in stems)
        if not has_pos and not neg_cpp:
            neg_cpp = var
            break
            
    # Find ASM variables
    for var, stems in sorted(midx.asm.items()):
        has_pos = any(s in reachable_stems for s in stems)
        if has_pos and not pos_asm:
            pos_asm = var
        elif not has_pos and not neg_asm:
            neg_asm = var
        if pos_asm and neg_asm:
            break
            
    # Fallback to defaults if needed
    if not pos_cpp: pos_cpp = "softCardValue"
    if not neg_cpp: neg_cpp = "OnlineSourceInd"
    if not pos_asm: pos_asm = "LWRAW_LSTACTDT"
    if not neg_asm: neg_asm = "BOGUS_ASM_VAR"
    
    return pos_cpp, neg_cpp, pos_asm, neg_asm


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="VBT LCA Reachability Diagnostic Tool")
    parser.add_argument("--check-order", action="store_true", help="Enable static call order checking")
    args = parser.parse_args()

    pos_cpp, neg_cpp, pos_asm, neg_asm = find_test_cases()
    
    print("\n--- POSITIVE C++ VARIABLE ---")
    diagnose_variable(pos_cpp, "cpp", check_order=args.check_order)
    
    print("\n--- NEGATIVE C++ VARIABLE ---")
    diagnose_variable(neg_cpp, "cpp", check_order=args.check_order)
    
    print("\n--- POSITIVE ASM VARIABLE ---")
    diagnose_variable(pos_asm, "asm", check_order=args.check_order)
    
    print("\n--- NEGATIVE ASM VARIABLE ---")
    diagnose_variable(neg_asm, "asm", check_order=args.check_order)
