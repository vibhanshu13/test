"""LLM enrichment layer for variable lineage graph explorer.

Single-call enrichment: given a set of variable names and raw condition strings,
returns business names + descriptions for variables, and readable English
translations for conditions.  Falls back to code names on any LLM failure so
the UI always renders.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, List, Optional

from llm.caller import call_llm

logger = logging.getLogger(__name__)

_VAR_SYSTEM = (
    "You are a senior business analyst documenting an IBM mainframe/z-TPF system. "
    "You translate cryptic assembly/C++ variable names into clear business terminology. "
    "Variable names are often abbreviated (e.g. LWRPO = 'Last Work Return Process Output', "
    "WK_RRC = 'Work Return Code', LG1OSI = 'Online Source Indicator'). "
    "Infer meaning from the name structure, common mainframe conventions, and any context given. "
    "Be concise and specific. Never make up capabilities beyond what the name implies."
)

_COND_SYSTEM = (
    "You are a senior business analyst translating IBM mainframe assembly and C++ guard conditions "
    "into plain English questions. "
    "Assembly TM (Test under Mask) = bitwise test; BZ/BNZ = branch-if-zero/non-zero; "
    "CLI = Compare Logical Immediate; BE/BNE = branch-equal/not-equal; "
    "CLC = Compare Logical Characters. "
    "Translate each condition into a single concise question an analyst would ask "
    "(e.g. 'TM aa71,BIT3 / BZ' → 'if the Authorization Flag (aa71) bit 3 is clear?'). "
    "Keep each translation under 15 words."
)


def _safe_json(text: str) -> Optional[dict]:
    """Extract first JSON object from LLM output."""
    text = text.strip()
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if not m:
        return None
    try:
        return json.loads(m.group())
    except Exception:
        return None


def _enrich_variables_chunk(names: List[str], context: str = "") -> Dict[str, Dict[str, str]]:
    """Enrich ONE batch of variable names in a single LLM call."""
    var_list = "\n".join(f"- {n}" for n in names)
    ctx_line = f"\nContext: {context}" if context else ""
    prompt = (
        f"Provide a business name (2–5 words, Title Case) and a 1-sentence description "
        f"for each variable below.{ctx_line}\n\n"
        f"Variables:\n{var_list}\n\n"
        f"Return ONLY a JSON object:\n"
        f'{{"LWRPO": {{"name": "Work Return Code", "description": "Controls transaction outcome"}}, ...}}\n'
        f"Keys must exactly match the variable names listed above."
    )
    try:
        raw = call_llm(prompt, system_prompt=_VAR_SYSTEM)
        parsed = _safe_json(raw)
        if parsed and isinstance(parsed, dict):
            result: Dict[str, Dict[str, str]] = {}
            for n in names:
                entry = parsed.get(n) or parsed.get(n.upper()) or parsed.get(n.lower()) or {}
                result[n] = {
                    "name": str(entry.get("name") or n),
                    "description": str(entry.get("description") or ""),
                }
            return result
    except Exception as exc:
        logger.warning("var_lineage_enricher: variable chunk enrichment failed: %s", exc)
    return {n: {"name": n, "description": ""} for n in names}


def _run_batches(items: List, batch: int, worker) -> List:
    """Run worker(chunk) over batches CONCURRENTLY (LLM calls are I/O-bound;
    call_llm has its own process-wide concurrency semaphore). Returns the list
    of per-batch results in order."""
    from concurrent.futures import ThreadPoolExecutor
    chunks = [items[i:i + batch] for i in range(0, len(items), batch)]
    if len(chunks) <= 1:
        return [worker(c) for c in chunks]
    with ThreadPoolExecutor(max_workers=min(6, len(chunks))) as pool:
        return list(pool.map(worker, chunks))


def enrich_variables(names: List[str], context: str = "") -> Dict[str, Dict[str, str]]:
    """Return {var_name: {name, description}} for EVERY variable in names.

    Chunks into batches of 40 (run concurrently) so large dependency sets
    (50+ vars) all get a business name instead of silently truncating. Falls
    back to the code name per variable on LLM failure.
    """
    if not names:
        return {}

    uniq = list(dict.fromkeys(n for n in names if n))
    result: Dict[str, Dict[str, str]] = {}
    for d in _run_batches(uniq, 40, lambda c: _enrich_variables_chunk(c, context)):
        result.update(d)
    return result


def _enrich_conditions_chunk(unique: List[str]) -> Dict[str, str]:
    """Translate ONE batch of raw conditions in a single LLM call."""
    cond_list = "\n".join(f"{i+1}. {c}" for i, c in enumerate(unique))
    prompt = (
        f"Translate each assembly/C++ condition below to a plain English question.\n\n"
        f"Conditions:\n{cond_list}\n\n"
        f"Return ONLY a JSON object where each key is the EXACT original condition string "
        f"(verbatim, including all punctuation) and the value is the English translation:\n"
        f'{{"TM aa71,BIT3 / BZ": "if the Authorization Flag bit 3 is clear?", ...}}'
    )
    try:
        raw = call_llm(prompt, system_prompt=_COND_SYSTEM)
        parsed = _safe_json(raw)
        if parsed and isinstance(parsed, dict):
            # Match by exact key, else by index fallback (LLMs sometimes reorder
            # or lightly reformat long expression keys).
            values = list(parsed.values())
            result: Dict[str, str] = {}
            for i, c in enumerate(unique):
                v = parsed.get(c)
                if v is None and i < len(values) and len(parsed) == len(unique):
                    v = values[i]
                result[c] = str(v or c)
            return result
    except Exception as exc:
        logger.warning("var_lineage_enricher: condition chunk enrichment failed: %s", exc)
    return {c: c for c in unique}


def enrich_conditions(raw_conditions: List[str]) -> Dict[str, str]:
    """Return {raw_condition: readable_english} for EVERY unique condition.

    Chunks into batches of 25 so all conditions get a plain-English translation
    instead of silently truncating at 40. Falls back to the raw string per
    condition on failure.
    """
    if not raw_conditions:
        return {}

    unique = list(dict.fromkeys(c for c in raw_conditions if c))
    result: Dict[str, str] = {}
    for d in _run_batches(unique, 25, _enrich_conditions_chunk):
        result.update(d)
    return result


def enrich_path(files: List[str], variable: str) -> Dict[str, str]:
    """Return {name, description} for a call-chain path to a setter.

    Falls back to a generic label on failure.
    """
    if not files:
        return {"name": "Direct Setter", "description": ""}

    chain = " → ".join(files)
    prompt = (
        f"An IBM mainframe execution path: {chain}\n"
        f"This path leads to where the variable '{variable}' is set.\n\n"
        f"Provide:\n"
        f"1. A business name for this path (2–5 words, Title Case)\n"
        f"2. A 1–2 sentence business description of what this execution path represents\n\n"
        f"Return ONLY JSON: {{\"name\": \"...\", \"description\": \"...\"}}"
    )
    try:
        raw = call_llm(
            prompt,
            system_prompt=(
                "You are a business analyst naming IBM mainframe execution paths. "
                "Give a concise, meaningful business label and description."
            ),
        )
        parsed = _safe_json(raw)
        if parsed:
            return {
                "name": str(parsed.get("name") or chain),
                "description": str(parsed.get("description") or ""),
            }
    except Exception as exc:
        logger.warning("var_lineage_enricher: path enrichment failed: %s", exc)

    return {"name": f"Path via {files[0]}" if files else "Direct", "description": ""}


def enrich_paths(paths: List[List[str]], variable: str) -> List[Dict[str, str]]:
    """Batch-name multiple call-chain paths in a SINGLE LLM call.

    `paths` is a list of file chains (each a list of file stems). Returns a list
    of {name, description}, index-aligned with the input. Falls back to generic
    labels on failure.
    """
    if not paths:
        return []

    def _fallback(files: List[str]) -> Dict[str, str]:
        return {
            "name": f"Path via {files[0]}" if files else "Direct Setter",
            "description": "",
        }

    listing = "\n".join(
        f'{i}. {" → ".join(files) if files else "(direct)"}'
        for i, files in enumerate(paths)
    )
    prompt = (
        f"The variable '{variable}' is set along {len(paths)} distinct IBM mainframe "
        f"execution paths. Each path is an ordered chain of program files.\n\n"
        f"Paths:\n{listing}\n\n"
        f"For EACH path, give a business name (2–5 words, Title Case) and a "
        f"1-sentence business description of what that execution path represents.\n\n"
        f"Return ONLY a JSON object keyed by the path index (as a string):\n"
        f'{{"0": {{"name": "...", "description": "..."}}, "1": {{"name": "...", "description": "..."}}}}'
    )
    try:
        raw = call_llm(
            prompt,
            system_prompt=(
                "You are a business analyst naming IBM mainframe execution paths. "
                "Give concise, meaningful business labels and descriptions."
            ),
        )
        parsed = _safe_json(raw)
        if parsed and isinstance(parsed, dict):
            result: List[Dict[str, str]] = []
            for i, files in enumerate(paths):
                entry = parsed.get(str(i)) or parsed.get(i) or {}
                chain = " → ".join(files)
                result.append({
                    "name": str(entry.get("name") or chain or "Direct Setter"),
                    "description": str(entry.get("description") or ""),
                })
            return result
    except Exception as exc:
        logger.warning("var_lineage_enricher: batch path enrichment failed: %s", exc)

    return [_fallback(files) for files in paths]


def enrich_value(variable: str, raw_value: str, conditions: List[str]) -> str:
    """Return a business-readable description of what value is assigned.

    E.g. "X'01'" → "the Active status flag (X'01')"
    Falls back to raw_value on failure.
    """
    if not raw_value:
        return raw_value

    cond_ctx = f"when: {'; '.join(conditions[:3])}" if conditions else ""
    prompt = (
        f"Variable: {variable}\n"
        f"Raw assigned value: {raw_value}\n"
        f"{cond_ctx}\n\n"
        f"Describe the value in plain English (under 10 words). "
        f"Include the raw value in parentheses. "
        f"E.g.: 'the Active status (X'01')' or 'Success code (0)'. "
        f"Return ONLY the short phrase, no JSON."
    )
    try:
        result = call_llm(
            prompt,
            system_prompt="Translate a mainframe variable assignment value to plain English.",
        ).strip()
        if result and len(result) < 80:
            return result
    except Exception as exc:
        logger.warning("var_lineage_enricher: value enrichment failed: %s", exc)

    return raw_value


def collect_all_vars(enriched_tree: dict, max_depth: int = 3) -> List[str]:
    """Collect all unique variable names from an enriched lineage tree."""
    seen: set = set()
    result: List[str] = []

    def _add(name: str):
        if name and name not in seen:
            seen.add(name)
            result.append(name)

    def _walk(node: dict, depth: int):
        if depth > max_depth:
            return
        _add(node.get("variable", ""))
        for s in node.get("setters", []):
            for dep in s.get("dependent_variables", []):
                _add(dep.get("name", ""))
                lin = dep.get("lineage") or {}
                _walk(lin, depth + 1)

    _walk(enriched_tree, 0)
    return [v for v in result if v]


def collect_all_conditions(enriched_tree: dict, max_depth: int = 3) -> List[str]:
    """Collect all unique raw condition strings from an enriched lineage tree."""
    seen: set = set()
    result: List[str] = []

    def _add(raw: str):
        r = str(raw or "").strip()
        if r and r not in seen:
            seen.add(r)
            result.append(r)

    def _walk_callers(callers: list, depth: int):
        if depth > 5:
            return
        for c in callers or []:
            for cond in c.get("call_conditions", []):
                _add(cond.get("raw", ""))
            _walk_callers(c.get("callers", []), depth + 1)

    def _walk(node: dict, depth: int):
        if depth > max_depth:
            return
        for s in node.get("setters", []):
            for cond in s.get("conditions", []):
                _add(cond.get("raw", ""))
            _walk_callers(s.get("reached_via", []), 0)
            for dep in s.get("dependent_variables", []):
                lin = dep.get("lineage") or {}
                _walk(lin, depth + 1)

    _walk(enriched_tree, 0)
    return result


def enrich_lineage_tree(
    variable: str,
    enriched_tree: dict,
    *,
    context: str = "",
) -> dict:
    """Batch-enrich an enriched lineage tree: business names + readable conditions.

    Returns {variables: {name: {name, description}}, conditions: {raw: readable}}.
    Callers inject these into the response payload.
    """
    all_vars = collect_all_vars(enriched_tree)
    all_conds = collect_all_conditions(enriched_tree)

    var_enrichment = enrich_variables(all_vars, context=context)
    cond_enrichment = enrich_conditions(all_conds)

    return {"variables": var_enrichment, "conditions": cond_enrichment}
