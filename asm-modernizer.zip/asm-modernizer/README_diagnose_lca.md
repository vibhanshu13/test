# VBT LCA Reachability Diagnostic Tool

This tool diagnoses whether the setters for any variable (ASM or C++) share a Lowest Common Ancestor (LCA) or call paths with the **Plastic Authentication** entry point (`dw710000::callPlasticAuthenticationComponentInterface`).

It operates **strictly from the precomputed `index.db`** (using VBT precompute artifacts), requiring **zero source file or blueprint reads**.

---

## Prerequisites

1. **Virtual Environment:** Use the project's virtual environment python interpreter (`env/bin/python`).
2. **Precomputed Database:** The job directory must contain a fully completed precomputed `index.db` (e.g., job `b58d8432-73e0-42d1-89a9-2ceebc47c6d2`).

---

## How to Run

### 1. Default (Fast) Mode
Runs the reachability and LCA checks without computing call order:
```bash
env/bin/python diagnose_lca.py
```

### 2. Call Order Mode
Resolves the static execution call order of the branches leading from the LCA to the PA Entry Point and the Setter:
```bash
env/bin/python diagnose_lca.py --check-order
```
*Note: To optimize performance, order computation is completely bypassed when this flag is omitted.*

---

## Verification & File-Read Protection

To guarantee that the diagnostic check does not touch any source code files or blueprint JSON files, the script sets up active **tripwires** on entry:
* It patches tree-sitter wrappers (`run_cfg_extract`), blueprint JSON loaders (`load_json`), and file-based setter scanners.
* It wraps the standard Python `builtins.open` to raise an `AssertionError` if any read operation is attempted on files ending with `.cpp`, `.hpp`, `.mac`, `.asm`, or `.json` (while still allowing SQLite reads to `index.db`).

If any operation attempts a filesystem read, the script immediately crashes with a `TRIPWIRE TRIGGERED` error.

---

## Output Description

For each variable tested, the script prints:
1. **Discovered Setter Nodes:** The containing function nodes (C++) or file stems (ASM) where the variable is modified.
2. **PA Entry Point:** The reference entry point (`dw710000::callPlasticAuthenticationComponentInterface`).
3. **Reachability Analysis:**
   * **Reachable forward from PA entry:** Whether the Plastic Authentication entry point has a forward call path reaching the setter.
   * **Shares common ancestors with PA:** Whether they share callers in the call graph (with their shared node names listed).
   * **Lowest Common Ancestor (LCA):** The deepest shared caller node (e.g., `dp710200::processPlasticAuth`).
   * **Static Call Order (Enabled with `--check-order`):** Explains whether the PA entry point is called first, the setter is called first, or how they branch sequentially from their LCA (using their direct call-site line numbers or block ranks inside the LCA).

---

## Code Reference
* Diagnostic script: [diagnose_lca.py](file:///Users/prathamgupta/Documents/asm-modernizer/diagnose_lca.py)
* Underlying VBT DB-only logic: [vbt/lca_trace.py](file:///Users/prathamgupta/Documents/asm-modernizer/vbt/lca_trace.py)
