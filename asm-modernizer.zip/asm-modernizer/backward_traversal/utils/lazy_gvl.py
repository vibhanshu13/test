"""Lazy, streaming proxy for the global_variable_lineage graph.

Problem
-------
``global_variable_lineage.json`` can be 3–4 GB on large codebases.  Loading it
eagerly (the old behaviour) allocates 10–15 GB of Python objects and OOMs
containers with ≤ 12 GB RAM.

Solution
--------
``LazyGVL`` is a drop-in replacement for the ``gvl`` dict that callers receive
from ``bp.get("global_variable_lineage")``.  Instead of holding the parsed data
in memory it returns ``_StreamingIterable`` objects when asked for ``"nodes"``
or ``"edges"``.  Each ``for item in iterable`` causes exactly ONE streaming
pass over the corresponding section of the file — peak RAM stays O(one_item).

``_StreamingIterable`` has ``__bool__ = True`` so the common idiom
    ``for n in (gvl.get("nodes") or []):``
    keeps working transparently.

GVL path discovery
------------------
The path to ``global_variable_lineage.json`` is stored at ``bp["_gvl_path"]``
by ``backward_traversal.utils.blueprint_utils._load_json_cached``.  Callers
obtain a ``LazyGVL`` with::

    from backward_traversal.utils.lazy_gvl import make_lazy_gvl
    gvl = make_lazy_gvl(bp)

msgpack support
---------------
In large codebases (≥ 28 K files) the GVL is written as msgpack (binary),
not JSON.  ``_is_msgpack_file`` detects the format by inspecting the first
byte.  On first access a compact ``.midx`` sidecar JSON is built in one scan
(``_build_msgpack_gvl_sidecar``), storing the byte-offset of each top-level
array so that every subsequent streaming pass can ``seek()`` directly to the
right position — peak RAM is still O(one_item).

The ``.midx`` sidecar is invalidated automatically when the GVL is newer than
the sidecar file.  ``make_lazy_gvl`` caches ``LazyGVL`` instances per path so
the one-time sidecar build happens at most once per process.

BFS size guard (cpp_backward_tracer.py)
---------------------------------------
The C++ backward BFS builds a full reverse-edge index over ALL GVL edges.  For
a 3.9 GB GVL this index would be 10+ GB — worse than eager loading.  A size
guard in ``cpp_backward_tracer.py`` checks ``gvl.file_size_bytes`` and skips
BFS when the file exceeds ``ASM_GVL_BFS_MAX_MB`` (default 512 MB), emitting a
warning instead of OOM-killing the process.
"""
from __future__ import annotations

import json
import logging
import os
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional

logger = logging.getLogger(__name__)

# ── shared edge-column helpers ────────────────────────────────────────────────

_EDGE_COLS_BASE = (
    "source, target, relation, file, line, expression, "
    "operation_type, transformation, symbolic_identity, "
    "access_identity, file_label, field_offset, dsect"
)


def _has_cc_column(con) -> bool:
    """Check whether gvl_edges has the ``conditional_context`` column."""
    try:
        cols = {r[1] for r in con.execute("PRAGMA table_info(gvl_edges)")}
        return "conditional_context" in cols
    except Exception:
        return False


def _parse_cc(raw):
    """Parse a ``conditional_context`` JSON string from the DB.

    Returns the parsed value on success, ``None`` on failure or empty input.
    All edge-reading code paths use this to ensure consistent behaviour —
    parse errors are never silently swallowed.
    """
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        logger.debug("conditional_context JSON parse error (raw=%r)", raw[:120] if isinstance(raw, str) else raw)
        return None


# ── persistent connection helper ───────────────────────────────────────────────


# Configurable mmap window for GVL database connections.
# Default 2 GB (up from 256 MB) to improve I/O for large GVL databases.
# For an 8 GB GVL DB, 2 GB maps ~25% of the file; higher values can improve
# BFS performance by reducing page-fault overhead.
_GVL_MMAP_BYTES: int = int(os.environ.get("ASM_GVL_MMAP_MB", "2048")) * 1024 * 1024


def _open_persistent_connection(db_path: str):
    """Open a SQLite connection with performance PRAGMAs for read-heavy workloads.

    Mirrors the PRAGMAs set by ``api.index_db.engine._apply_sqlite_pragmas`` but
    for raw ``sqlite3`` connections outside SQLAlchemy.  The connection uses
    ``check_same_thread=False`` because ``_DbReverseIndex`` / ``_DbNodeLookup``
    instances are used within a single Celery worker fork (single-threaded).
    """
    import sqlite3
    con = sqlite3.connect(db_path, check_same_thread=False)
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("PRAGMA journal_mode=WAL")
    cur.execute("PRAGMA synchronous=NORMAL")
    cur.execute("PRAGMA cache_size=-65536")      # 64 MB page cache
    cur.execute("PRAGMA temp_store=MEMORY")
    cur.execute(f"PRAGMA mmap_size={_GVL_MMAP_BYTES}")  # configurable via ASM_GVL_MMAP_MB
    cur.execute("PRAGMA busy_timeout=5000")
    cur.close()
    return con


# ── msgpack detection ──────────────────────────────────────────────────────────

# msgpack fixmap  : 0x80–0x8f  (map with up to 15 keys)
# msgpack map16   : 0xde
# msgpack map32   : 0xdf
_MSGPACK_MAP_FIRST_BYTES = frozenset(range(0x80, 0x90)) | {0xDE, 0xDF}


def _is_msgpack_file(path: str) -> bool:
    """Return True when *path* starts with a msgpack map header byte."""
    try:
        with open(path, "rb") as f:
            b = f.read(1)
            return bool(b) and b[0] in _MSGPACK_MAP_FIRST_BYTES
    except Exception:
        return False


# ── msgpack sidecar ────────────────────────────────────────────────────────────

def _build_msgpack_gvl_sidecar(gvl_path: str) -> Optional[Dict[str, Any]]:
    """Return a byte-offset index for the top-level arrays in *gvl_path*.

    Schema::

        {
          "nodes": {"offset": <int>, "count": <int>},
          "edges": {"offset": <int>, "count": <int>}
        }

    *offset* is the byte position of the **first array element** (i.e. the
    position returned by ``Unpacker.tell()`` immediately after
    ``read_array_header()``).  *count* is the array length.

    The index is persisted to ``<gvl_path>.midx`` and reused on subsequent
    calls as long as the sidecar mtime ≥ GVL mtime.  Returns ``None`` when
    the build fails (e.g. msgpack not installed, corrupt file).

    Requires msgpack >= 1.0.0 for ``Unpacker.tell()`` and ``Unpacker.skip()``.
    """
    sidecar_path = gvl_path + ".midx"

    # ── load existing sidecar if still valid ──────────────────────────────────
    try:
        if os.path.exists(sidecar_path) and (
            os.path.getmtime(sidecar_path) >= os.path.getmtime(gvl_path)
        ):
            with open(sidecar_path, encoding="utf-8") as f:
                idx = json.load(f)
            if isinstance(idx, dict) and idx:
                return idx
    except Exception:
        pass

    # ── build sidecar with a single sequential scan ───────────────────────────
    try:
        import msgpack as _msgpack  # type: ignore[import]
    except ImportError:
        logger.warning(
            "msgpack not installed — cannot stream binary GVL at %s", gvl_path
        )
        return None

    logger.info(
        "Building msgpack GVL sidecar for %s (one-time full-file scan)…", gvl_path
    )
    index: Dict[str, Any] = {}
    try:
        with open(gvl_path, "rb") as f:
            up = _msgpack.Unpacker(f, raw=False, strict_map_key=False)
            map_len = up.read_map_header()
            for _ in range(map_len):
                key = up.unpack()             # top-level key  (e.g. "nodes")
                arr_len = up.read_array_header()
                offset = up.tell()            # bytes consumed = first element start
                index[str(key)] = {"offset": int(offset), "count": int(arr_len)}
                logger.info(
                    "  GVL sidecar: key=%r  count=%d  offset=%d", key, arr_len, offset
                )
                # Skip all items to advance stream to the next key.
                # skip() reads only format bytes (no full decode) — faster than unpack().
                for _ in range(arr_len):
                    up.skip()
    except AttributeError as exc:
        # tell() / skip() unavailable — msgpack < 1.0.0
        logger.warning(
            "msgpack >= 1.0.0 required for GVL streaming (got: %s). "
            "Install with: pip install 'msgpack>=1.0.0'",
            exc,
        )
        return None
    except Exception as exc:
        logger.warning("msgpack sidecar build failed for %s: %s", gvl_path, exc)
        return index if index else None

    # ── persist sidecar ───────────────────────────────────────────────────────
    try:
        with open(sidecar_path, "w", encoding="utf-8") as f:
            json.dump(index, f)
        logger.info("GVL sidecar written to %s", sidecar_path)
    except Exception as exc:
        logger.debug("Could not persist GVL sidecar %s: %s", sidecar_path, exc)

    return index


# ── msgpack streaming ──────────────────────────────────────────────────────────

def _stream_msgpack_array(
    gvl_path: str, offset: int, count: int
) -> Generator[Any, None, None]:
    """Yield *count* decoded msgpack items from *gvl_path* starting at byte *offset*.

    *offset* must equal the value returned by ``Unpacker.tell()`` right after
    ``read_array_header()`` — the first byte of the first array element.
    Seeking to that position in a fresh file handle and constructing a new
    ``Unpacker`` is equivalent to reading from that logical position.
    """
    try:
        import msgpack as _msgpack  # type: ignore[import]
    except ImportError:
        return

    with open(gvl_path, "rb") as f:
        f.seek(offset)
        up = _msgpack.Unpacker(f, raw=False, strict_map_key=False)
        for _ in range(count):
            yield up.unpack()


# ── streaming iterables ────────────────────────────────────────────────────────

class _StreamingIterable:
    """Stream a JSON array key from disk one item at a time.

    Each ``__iter__`` call starts a fresh streaming pass — memory stays
    O(one_item) regardless of how many times the caller iterates.
    """

    __slots__ = ("_path", "_key")

    def __init__(self, path: Path, key: str) -> None:
        self._path = path
        self._key = key

    def __iter__(self) -> Generator[Any, None, None]:
        from backward_traversal.utils.stream_json import stream_json_array
        return stream_json_array(str(self._path), self._key)

    def __bool__(self) -> bool:
        # Always truthy so ``gvl.get("nodes") or []`` uses this iterable.
        return True


class _MsgpackStreamingIterable:
    """Stream a msgpack array from a pre-computed byte offset one item at a time.

    Each ``__iter__`` call seeks to *offset* and streams exactly *count* items.
    """

    __slots__ = ("_path", "_offset", "_count")

    def __init__(self, path: str, offset: int, count: int) -> None:
        self._path = path
        self._offset = offset
        self._count = count

    def __iter__(self) -> Generator[Any, None, None]:
        return _stream_msgpack_array(self._path, self._offset, self._count)

    def __bool__(self) -> bool:
        return True


# ── IndexDbGVL ────────────────────────────────────────────────────────────────

class _DbIterable:
    """Streams gvl_nodes or gvl_edges rows from index.db one row at a time."""

    __slots__ = ("_db_path", "_job_id", "_kind")

    def __init__(self, db_path: str, job_id: str, kind: str) -> None:
        self._db_path = db_path
        self._job_id = job_id
        self._kind = kind  # "nodes" or "edges"

    def __iter__(self) -> Generator[Any, None, None]:
        import sqlite3
        import json as _json
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            cur = conn.cursor()
            if self._kind == "nodes":
                cur.execute(
                    "SELECT node_id, kind, name, extra_json FROM gvl_nodes WHERE job_id = ?",
                    (self._job_id,),
                )
                for row in cur:
                    node: Dict[str, Any] = {
                        "id": row["node_id"],
                        "kind": row["kind"],
                        "name": row["name"],
                    }
                    if row["extra_json"]:
                        try:
                            node.update(_json.loads(row["extra_json"]))
                        except Exception:
                            pass
                    yield node
            else:
                _cc = _has_cc_column(conn)
                _select = f"SELECT {_EDGE_COLS_BASE}"
                if _cc:
                    _select += ", conditional_context"
                cur.execute(f"{_select} FROM gvl_edges WHERE job_id = ?", (self._job_id,))
                for row in cur:
                    edge = {k: row[k] for k in row.keys() if row[k] is not None}
                    if _cc and "conditional_context" in edge:
                        parsed = _parse_cc(edge["conditional_context"])
                        if parsed is not None:
                            edge["conditional_context"] = parsed
                        else:
                            edge.pop("conditional_context", None)
                    yield edge
        finally:
            conn.close()

    def __bool__(self) -> bool:
        return True


class IndexDbGVL:
    """Dict-like proxy for global_variable_lineage backed by index.db.

    Drop-in fallback for ``LazyGVL`` when ``global_variable_lineage.json`` is
    absent.  Reads ``gvl_nodes`` and ``gvl_edges`` from the SQLite index DB that
    the pipeline writes to ``{job_dir}/index.db``.  Returns re-iterable
    ``_DbIterable`` objects that stream rows from the DB on each iteration
    instead of materialising the full table into a Python list (which would
    consume hundreds of MB for large codebases).
    """

    __slots__ = ("_db_path", "_job_id", "_exists", "_nodes_cache", "_edges_cache")

    def __init__(self, db_path: Path, job_id: str) -> None:
        self._db_path: Optional[Path] = db_path
        self._job_id = job_id
        self._exists = bool(db_path and db_path.exists())
        self._nodes_cache: Optional[Any] = None
        self._edges_cache: Optional[Any] = None

    def _load_nodes(self) -> Any:
        if self._nodes_cache is None:
            self._nodes_cache = _DbIterable(str(self._db_path), self._job_id, "nodes")
        return self._nodes_cache

    def _load_edges(self) -> Any:
        if self._edges_cache is None:
            self._edges_cache = _DbIterable(str(self._db_path), self._job_id, "edges")
        return self._edges_cache

    def get(self, key: str, default: Any = None) -> Any:
        if not self._exists or key not in ("nodes", "edges"):
            return default
        return self._load_nodes() if key == "nodes" else self._load_edges()

    def __getitem__(self, key: str) -> Any:
        val = self.get(key)
        if val is None:
            raise KeyError(key)
        return val

    def __contains__(self, key: object) -> bool:
        return self._exists and key in ("nodes", "edges")

    def __bool__(self) -> bool:
        return self._exists

    @property
    def file_size_bytes(self) -> int:
        """Estimate GVL size from edge row count.

        DB-backed GVL has no file on disk, so approximate from the number
        of ``gvl_edges`` rows.  ~300 bytes per edge is a conservative
        estimate that accounts for Python dict overhead during any full-
        materialisation path.  The ``_DbReverseIndex`` itself is lazy
        (LRU-cached per-target), so this estimate is mainly used by the
        ``_GVL_BFS_MAX_BYTES`` guard in ``cpp_backward_tracer`` for
        operational monitoring and extreme-scale protection.
        """
        try:
            con = _open_persistent_connection(str(self._db_path))
            count = con.execute(
                "SELECT COUNT(*) FROM gvl_edges WHERE job_id=?",
                (self._job_id,),
            ).fetchone()[0]
            return count * 300
        except Exception:
            return 0

    def make_reverse_index(self) -> "_DbReverseIndex":
        """Return a lazy per-target reverse index backed by this DB."""
        return _DbReverseIndex(str(self._db_path), self._job_id)

    def make_node_lookup(self) -> "_DbNodeLookup":
        """Return a lazy per-node-id lookup backed by this DB."""
        return _DbNodeLookup(str(self._db_path), self._job_id)

    def __repr__(self) -> str:
        if self._db_path:
            return f"IndexDbGVL({self._db_path.name}, job={self._job_id})"
        return "IndexDbGVL(unavailable)"


def find_gvl_db_path(blueprint_path: Path) -> Optional[tuple]:
    """Locate index.db relative to *blueprint_path*.

    Blueprints live at ``{job_dir}/output/asm/{file}.cpp.json`` (3 levels up)
    or ``{job_dir}/output/{file}.cpp.json`` (2 levels up).  Returns
    ``(db_path, job_id)`` when found, else ``None``.
    """
    for levels_up in (2, 3):
        candidate = blueprint_path
        for _ in range(levels_up):
            candidate = candidate.parent
        db = candidate / "index.db"
        if db.exists() and db.stat().st_size > 0:
            return db, candidate.name
    return None


# ── LazyGVL ────────────────────────────────────────────────────────────────────

class LazyGVL:
    """Dict-like proxy for global_variable_lineage that never loads the full
    file into memory.

    Supports ``gvl.get(key)``, ``key in gvl``, and ``bool(gvl)`` — the
    operations used by callers in the backward traversal.

    Automatically detects whether the GVL is JSON or msgpack and routes
    streaming through the appropriate path.
    """

    __slots__ = ("_path", "_exists", "_is_mp", "_msgpack_idx")

    def __init__(self, gvl_path: Optional[Path]) -> None:
        self._path: Optional[Path] = gvl_path
        self._exists: bool = bool(gvl_path and gvl_path.exists())
        self._is_mp: bool = False
        self._msgpack_idx: Optional[Dict[str, Any]] = None
        if self._exists and self._path is not None:
            self._is_mp = _is_msgpack_file(str(self._path))

    # ── dict-like interface ───────────────────────────────────────────────────

    def get(self, key: str, default: Any = None) -> Any:
        if not self._exists or key not in ("nodes", "edges"):
            return default

        if self._is_mp:
            # Build / load msgpack sidecar index lazily on first access.
            if self._msgpack_idx is None:
                self._msgpack_idx = _build_msgpack_gvl_sidecar(
                    str(self._path)  # type: ignore[arg-type]
                )
            if not self._msgpack_idx:
                return default
            entry = self._msgpack_idx.get(key)
            if entry is None:
                return default
            return _MsgpackStreamingIterable(
                str(self._path),  # type: ignore[arg-type]
                entry["offset"],
                entry["count"],
            )

        # JSON path (original behaviour)
        return _StreamingIterable(self._path, key)  # type: ignore[arg-type]

    def __getitem__(self, key: str) -> Any:
        val = self.get(key)
        if val is None:
            raise KeyError(key)
        return val

    def __contains__(self, key: object) -> bool:
        return self._exists and key in ("nodes", "edges")

    def __bool__(self) -> bool:
        return self._exists

    # ── extra helpers ─────────────────────────────────────────────────────────

    @property
    def path(self) -> Optional[Path]:
        """Filesystem path of the GVL file, or None when unavailable."""
        return self._path

    @property
    def file_size_bytes(self) -> int:
        """On-disk size in bytes; 0 when the file is unavailable."""
        if not self._exists or self._path is None:
            return 0
        try:
            return os.path.getsize(str(self._path))
        except OSError:
            return 0

    def __repr__(self) -> str:  # pragma: no cover
        if self._path:
            mb = self.file_size_bytes / (1024 ** 2)
            fmt = "msgpack" if self._is_mp else "json"
            return f"LazyGVL({self._path.name}, {mb:.0f} MB, {fmt})"
        return "LazyGVL(unavailable)"


# ── factory ───────────────────────────────────────────────────────────────────

# Cache LazyGVL instances by resolved absolute path so the (potentially slow)
# one-time msgpack sidecar build happens at most once per process per GVL file.
_LAZY_GVL_CACHE: Dict[str, LazyGVL] = {}


def find_gvl_path(blueprint_path: Path) -> Optional[Path]:
    """Locate ``global_variable_lineage.json`` relative to *blueprint_path*.

    Searches the blueprint's own directory first, then one level up (for
    layouts such as ``output/asm/<file>.cpp.json``).
    """
    candidates = [
        blueprint_path.parent / "global_variable_lineage.json",
        blueprint_path.parent.parent / "global_variable_lineage.json",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


# ── DB-backed GVL (fallback when JSON/msgpack file has been deleted) ───────────

class _DbNodeIterable:
    """Yield GVL node dicts from the index DB gvl_nodes table."""

    __slots__ = ("_db_path", "_job_id")

    def __init__(self, db_path: str, job_id: str) -> None:
        self._db_path = db_path
        self._job_id = job_id

    def __iter__(self) -> Generator[Any, None, None]:
        import sqlite3
        con = sqlite3.connect(self._db_path)
        con.row_factory = sqlite3.Row
        try:
            cur = con.execute(
                "SELECT node_id, kind, name, extra_json FROM gvl_nodes WHERE job_id=?",
                (self._job_id,),
            )
            while True:
                row = cur.fetchone()
                if row is None:
                    break
                node: Dict[str, Any] = {
                    "id":   row["node_id"],
                    "kind": row["kind"],
                    "name": row["name"],
                }
                extra = row["extra_json"]
                if extra:
                    try:
                        node.update(json.loads(extra))
                    except Exception:
                        pass
                yield node
        finally:
            con.close()

    def __bool__(self) -> bool:
        return True


class _DbEdgeIterable:
    """Yield GVL edge dicts from the index DB gvl_edges table."""

    __slots__ = ("_db_path", "_job_id")

    def __init__(self, db_path: str, job_id: str) -> None:
        self._db_path = db_path
        self._job_id = job_id

    def __iter__(self) -> Generator[Any, None, None]:
        import sqlite3
        con = sqlite3.connect(self._db_path)
        con.row_factory = sqlite3.Row
        try:
            cc_ok = _has_cc_column(con)
            _select = f"SELECT {_EDGE_COLS_BASE}"
            if cc_ok:
                _select += ", conditional_context"
            cur = con.execute(f"{_select} FROM gvl_edges WHERE job_id=?", (self._job_id,))
            while True:
                row = cur.fetchone()
                if row is None:
                    break
                edge = {k: row[k] for k in row.keys() if row[k] is not None}
                if cc_ok and "conditional_context" in edge:
                    parsed = _parse_cc(edge["conditional_context"])
                    if parsed is not None:
                        edge["conditional_context"] = parsed
                    else:
                        edge.pop("conditional_context", None)
                yield edge
        finally:
            con.close()

    def __bool__(self) -> bool:
        return True


class _DbReverseIndex:
    """On-demand reverse-index backed by index.db (lazy, per-target).

    Replaces the pre-built in-memory ``target → [edges]`` dict when a
    DB-backed GVL is in use.  Each ``get(target)`` issues one indexed SELECT
    on the ``ix_gvl_edges_job_tgt`` index — O(1) DB lookup instead of loading
    the full GVL into memory.  Results are cached per target so repeated BFS
    visits to the same variable pay the round-trip only once.

    The cache is bounded (LRU, default 2000 entries) to prevent unbounded
    growth when a ``_DbReverseIndex`` is reused across many seeds in
    ``trace_cpp_variable_backward_multi``.  Evicted targets are re-queried
    from the DB on next access (indexed, O(log N)).
    """

    __slots__ = ("_db_path", "_job_id", "_cache", "_max_cache", "_has_cc", "_con")

    _DEFAULT_MAX_CACHE = 5000

    def __init__(self, db_path: str, job_id: str, *, max_cache: int = _DEFAULT_MAX_CACHE) -> None:
        self._db_path = db_path
        self._job_id = job_id
        self._cache: OrderedDict[str, List[Any]] = OrderedDict()
        self._max_cache = max_cache
        self._has_cc: Optional[bool] = None
        self._con = None  # lazy; opened on first get()

    def _ensure_con(self):
        """Return the persistent connection, opening it lazily on first call."""
        if self._con is None:
            self._con = _open_persistent_connection(self._db_path)
            self._has_cc = _has_cc_column(self._con)
        return self._con

    def get(self, target: str, default: Any = None) -> Any:
        if target in self._cache:
            self._cache.move_to_end(target)
            result = self._cache[target]
            return result if result else default
        con = self._ensure_con()
        _select = f"SELECT {_EDGE_COLS_BASE}"
        if self._has_cc:
            _select += ", conditional_context"
        cur = con.execute(
            f"{_select} FROM gvl_edges WHERE job_id=? AND target=?",
            (self._job_id, target),
        )
        rows: List[Any] = []
        for row in cur:
            e: Dict[str, Any] = {k: row[k] for k in row.keys() if row[k] is not None}
            if self._has_cc and "conditional_context" in e:
                parsed = _parse_cc(e["conditional_context"])
                if parsed is not None:
                    e["conditional_context"] = parsed
                else:
                    e.pop("conditional_context", None)
            rows.append(e)
        self._cache[target] = rows
        if len(self._cache) > self._max_cache:
            self._cache.popitem(last=False)
        return rows if rows else default

    def prefetch(self, targets: list) -> None:
        """Batch-fetch edges for multiple targets in a single SQL query.

        Populates the cache for all *targets* that are not already cached.
        Targets that have no edges in the DB get an empty-list cache entry
        (so subsequent ``get()`` calls return immediately without a DB hit).

        Called from the BFS loop in ``cpp_backward_tracer`` to amortize
        per-target DB round-trips into bulk ``WHERE target IN (...)`` queries.
        """
        uncached = [t for t in targets if t not in self._cache]
        if not uncached:
            return
        con = self._ensure_con()
        _select = f"SELECT {_EDGE_COLS_BASE}"
        if self._has_cc:
            _select += ", conditional_context"
        # Pre-initialize all targets to [] so misses are also cached.
        for t in uncached:
            self._cache[t] = []
        # Chunk to stay within SQLite variable limit (999).
        chunk_size = 200
        for i in range(0, len(uncached), chunk_size):
            chunk = uncached[i : i + chunk_size]
            placeholders = ", ".join("?" for _ in chunk)
            sql = (
                f"{_select} FROM gvl_edges "
                f"WHERE job_id = ? AND target IN ({placeholders})"
            )
            params = [self._job_id] + chunk
            for row in con.execute(sql, params):
                e: Dict[str, Any] = {k: row[k] for k in row.keys() if row[k] is not None}
                if self._has_cc and "conditional_context" in e:
                    parsed = _parse_cc(e["conditional_context"])
                    if parsed is not None:
                        e["conditional_context"] = parsed
                    else:
                        e.pop("conditional_context", None)
                tgt = e.get("target", "")
                if tgt in self._cache:
                    self._cache[tgt].append(e)
        # Evict oldest entries if cache exceeds limit.
        while len(self._cache) > self._max_cache:
            self._cache.popitem(last=False)

    def close(self) -> None:
        """Close the persistent connection and clear the cache."""
        if self._con is not None:
            try:
                self._con.close()
            except Exception:
                pass
            self._con = None

    def __del__(self) -> None:
        self.close()


class _DbNodeLookup:
    """On-demand node lookup backed by index.db (lazy, per-node-id).

    Replaces the pre-built in-memory ``{node_id: node_dict}`` dict when a
    DB-backed GVL is in use.  Each ``get(node_id)`` issues one indexed SELECT
    on the ``ix_gvl_nodes_job_node`` index — O(log N) lookup instead of loading
    ALL GVL nodes into memory (250 MB – 1.1 GB for large codebases).

    The BFS in ``cpp_backward_tracer`` visits at most ``max_nodes`` (default
    300) unique nodes, so only ~300 lookups are needed.  An LRU cache of 1000
    entries ensures repeated visits never re-query the DB.  Increased from 500
    to 1000 to accommodate cross-dep_var reuse when the same reverse index
    is shared across 200+ dep_vars.
    """

    __slots__ = ("_db_path", "_job_id", "_cache", "_max_cache", "_con")

    _DEFAULT_MAX_CACHE = 1000

    def __init__(self, db_path: str, job_id: str, *, max_cache: int = _DEFAULT_MAX_CACHE) -> None:
        self._db_path = db_path
        self._job_id = job_id
        self._cache: OrderedDict[str, Optional[Dict[str, Any]]] = OrderedDict()
        self._max_cache = max_cache
        self._con = None  # lazy; opened on first get()

    def _ensure_con(self):
        """Return the persistent connection, opening it lazily on first call."""
        if self._con is None:
            self._con = _open_persistent_connection(self._db_path)
        return self._con

    def get(self, node_id: str, default: Any = None) -> Any:
        if node_id in self._cache:
            self._cache.move_to_end(node_id)
            result = self._cache[node_id]
            return result if result is not None else default
        con = self._ensure_con()
        cur = con.execute(
            "SELECT node_id, kind, name, extra_json FROM gvl_nodes "
            "WHERE job_id=? AND node_id=?",
            (self._job_id, node_id),
        )
        row = cur.fetchone()
        if row is None:
            node = None
        else:
            node: Dict[str, Any] = {
                "id": row["node_id"],
                "kind": row["kind"],
                "name": row["name"],
            }
            extra = row["extra_json"]
            if extra:
                try:
                    node.update(json.loads(extra))
                except Exception:
                    pass
        self._cache[node_id] = node
        if len(self._cache) > self._max_cache:
            self._cache.popitem(last=False)
        return node if node is not None else default

    def close(self) -> None:
        """Close the persistent connection and clear the cache."""
        if self._con is not None:
            try:
                self._con.close()
            except Exception:
                pass
            self._con = None

    def __del__(self) -> None:
        self.close()


class DbLazyGVL:
    """LazyGVL backed by the index DB when the GVL file has been deleted.

    Presents the same ``get(key)`` / ``__bool__`` interface as ``LazyGVL``
    so all callers work transparently.  Returns re-iterable streaming
    iterables that query the DB on each iteration instead of materialising
    all rows into a Python list.

    ``file_size_bytes`` returns 0 (no file) — the BFS size guard in
    ``cpp_backward_tracer.py`` will treat this as a small GVL and proceed
    with the full BFS, which is correct because the DB only stores the
    ingested data (already bounded in size).
    """

    __slots__ = ("_db_path", "_job_id", "_has_data", "_nodes_cache", "_edges_cache")

    def __init__(self, db_path: str, job_id: str) -> None:
        self._db_path = db_path
        self._job_id = job_id
        self._has_data: Optional[bool] = None  # lazy check
        self._nodes_cache: Optional[Any] = None
        self._edges_cache: Optional[Any] = None

    def _check_has_data(self) -> bool:
        if self._has_data is None:
            try:
                import sqlite3
                con = sqlite3.connect(self._db_path)
                count = con.execute(
                    "SELECT COUNT(*) FROM gvl_nodes WHERE job_id=?", (self._job_id,)
                ).fetchone()[0]
                con.close()
                self._has_data = count > 0
            except Exception:
                self._has_data = False
        return bool(self._has_data)

    def get(self, key: str, default: Any = None) -> Any:
        if key == "nodes" and self._check_has_data():
            if self._nodes_cache is None:
                self._nodes_cache = _DbNodeIterable(self._db_path, self._job_id)
            return self._nodes_cache
        if key == "edges" and self._check_has_data():
            if self._edges_cache is None:
                self._edges_cache = _DbEdgeIterable(self._db_path, self._job_id)
            return self._edges_cache
        return default

    def __getitem__(self, key: str) -> Any:
        val = self.get(key)
        if val is None:
            raise KeyError(key)
        return val

    def __contains__(self, key: object) -> bool:
        return key in ("nodes", "edges") and self._check_has_data()

    def __bool__(self) -> bool:
        return self._check_has_data()

    @property
    def path(self) -> Optional[Path]:
        return None

    @property
    def file_size_bytes(self) -> int:
        """Estimate GVL size from edge row count (~300 bytes/edge)."""
        try:
            con = _open_persistent_connection(str(self._db_path))
            count = con.execute(
                "SELECT COUNT(*) FROM gvl_edges WHERE job_id=?",
                (self._job_id,),
            ).fetchone()[0]
            return count * 300
        except Exception:
            return 0

    def query_edges(
        self,
        *,
        source: Optional[str] = None,
        target: Optional[str] = None,
        relation: Optional[str] = None,
        file: Optional[str] = None,
    ) -> List[Any]:
        """Filtered edge query using DB indexes.

        Pushes ``source``, ``target``, ``relation``, and/or ``file`` filters
        directly to SQLite so only matching rows are loaded.  At least one
        filter should be provided to avoid a full table scan; when called
        without any filter it falls back to the fully-cached ``get("edges")``.

        Use this instead of ``gvl.get("edges")`` in hot paths where a known
        filter can dramatically reduce the result set (e.g. ``relation="arg_bind"``
        cuts the scan to a small fraction of total edges).
        """
        if source is None and target is None and relation is None and file is None:
            return self.get("edges") or []
        import sqlite3
        parts: List[str] = ["job_id=?"]
        params: List[Any] = [self._job_id]
        if source is not None:
            parts.append("source=?")
            params.append(source)
        if target is not None:
            parts.append("target=?")
            params.append(target)
        if relation is not None:
            parts.append("relation=?")
            params.append(relation)
        if file is not None:
            parts.append("file=?")
            params.append(file)
        con = sqlite3.connect(self._db_path)
        con.row_factory = sqlite3.Row
        try:
            cc_ok = _has_cc_column(con)
            _cols = _EDGE_COLS_BASE + (", conditional_context" if cc_ok else "")
            sql = f"SELECT {_cols} FROM gvl_edges WHERE {' AND '.join(parts)}"
            results: List[Any] = []
            for row in con.execute(sql, params):
                e: Dict[str, Any] = {k: row[k] for k in row.keys() if row[k] is not None}
                if cc_ok and "conditional_context" in e:
                    parsed = _parse_cc(e["conditional_context"])
                    if parsed is not None:
                        e["conditional_context"] = parsed
                    else:
                        e.pop("conditional_context", None)
                results.append(e)
        finally:
            con.close()
        return results

    def make_reverse_index(self) -> "_DbReverseIndex":
        """Return a lazy per-target reverse index backed by this DB.

        Preferred over building the full in-memory ``target → [edges]`` dict
        for large codebases — peak RAM is O(BFS frontier) not O(all edges).
        """
        return _DbReverseIndex(self._db_path, self._job_id)

    def make_node_lookup(self) -> "_DbNodeLookup":
        """Return a lazy per-node-id lookup backed by this DB.

        Preferred over building the full in-memory ``{node_id: node_dict}``
        dict for large codebases — peak RAM is O(BFS visited) not O(all nodes).
        """
        return _DbNodeLookup(self._db_path, self._job_id)

    def __repr__(self) -> str:  # pragma: no cover
        return f"DbLazyGVL(job={self._job_id})"


# Cache key prefix for DB-backed GVL to avoid collision with file-based keys.
_DB_GVL_CACHE_PREFIX = "db:"


def find_index_db(blueprint_path: Path) -> Optional[tuple]:
    """Locate ``index.db`` and extract the job_id from the path hierarchy.

    Walks up from *blueprint_path* looking for a sibling ``index.db``.
    Returns ``(db_path_str, job_id_str)`` on success, ``None`` if not found.

    Expected layout::

        /var/asm-jobs/{job_id}/output/asm/<file>.cpp.json
        /var/asm-jobs/{job_id}/index.db
    """
    p = blueprint_path.parent
    for _ in range(5):  # walk up at most 5 levels
        candidate = p / "index.db"
        if candidate.exists() and candidate.stat().st_size > 0:
            return str(candidate), p.name
        p = p.parent
    return None


def make_lazy_gvl(bp: dict, blueprint_path: Optional[Path] = None) -> "LazyGVL | DbLazyGVL":
    """Build (or retrieve from cache) a GVL proxy for the given blueprint.

    Priority order (highest to lowest):

    1. ``bp["_gvl_db_path"]`` / ``bp["_gvl_job_id"]`` — explicitly injected DB
       path (set by blueprint_utils when the GVL file is absent).
    2. ``index.db`` discovered via ``find_index_db(blueprint_path)`` when
       *blueprint_path* is provided — **DB is always preferred over the GVL
       JSON file** so that traversal reads from the compact SQLite store rather
       than loading multi-GB JSON into RAM.
    3. ``bp["_gvl_path"]`` file — the original GVL JSON, used only when no DB
       is available.
    4. GVL JSON discovered via ``find_gvl_path(blueprint_path)`` — last resort.

    Returns a falsy ``LazyGVL(None)`` only when neither the DB nor the file
    can be found.
    """
    # Priority 1: explicitly injected DB path (set when GVL file is deleted).
    raw_db = bp.get("_gvl_db_path")
    raw_job = bp.get("_gvl_job_id")
    if raw_db and raw_job:
        db_p = Path(str(raw_db))
        if db_p.exists():
            logger.debug(
                "GVL: using injected index.db at %s (job=%s)", db_p, raw_job,
            )
            return IndexDbGVL(db_p, str(raw_job))

    # Priority 2: DB discovered from blueprint path — preferred over multi-GB
    # GVL JSON file when blueprint_path is provided.
    if blueprint_path is not None:
        db_info = find_index_db(blueprint_path)
        if db_info:
            db_path, job_id = db_info
            cache_key = f"{_DB_GVL_CACHE_PREFIX}{db_path}:{job_id}"
            if cache_key in _LAZY_GVL_CACHE:
                return _LAZY_GVL_CACHE[cache_key]  # type: ignore[return-value]
            inst_db = DbLazyGVL(db_path, job_id)
            if inst_db:
                logger.debug(
                    "GVL: using index.db at %s (job=%s) instead of GVL file",
                    db_path, job_id,
                )
                _LAZY_GVL_CACHE[cache_key] = inst_db  # type: ignore[assignment]
                return inst_db

    # Derive job_id for file-backed LazyGVL so find_cpp_seed_nodes can use DB index.
    _file_job_id: Optional[str] = None
    if blueprint_path is not None:
        try:
            from api.index_db.engine import job_id_from_path
            _file_job_id = job_id_from_path(blueprint_path)
        except Exception:
            pass

    # Priority 3: GVL JSON file from blueprint _gvl_path key.
    raw = bp.get("_gvl_path")
    if raw:
        p = Path(str(raw))
        if p.exists():
            cache_key = str(p.resolve())
            if cache_key in _LAZY_GVL_CACHE:
                return _LAZY_GVL_CACHE[cache_key]
            inst = LazyGVL(p)
            if _file_job_id:
                inst._job_id = _file_job_id  # type: ignore[attr-defined]
            _LAZY_GVL_CACHE[cache_key] = inst
            return inst

    # Priority 4: GVL JSON file discovered via path traversal.
    if blueprint_path is not None:
        p2 = find_gvl_path(blueprint_path)
        if p2:
            cache_key = str(p2.resolve())
            if cache_key in _LAZY_GVL_CACHE:
                return _LAZY_GVL_CACHE[cache_key]
            inst = LazyGVL(p2)
            if _file_job_id:
                inst._job_id = _file_job_id  # type: ignore[attr-defined]
            _LAZY_GVL_CACHE[cache_key] = inst
            return inst

    return LazyGVL(None)  # falsy — GVL unavailable
