"""Variable-name resolution via the pre-built variable_identity_index.json."""

from __future__ import annotations

import json
from pathlib import Path
from typing import ClassVar, Dict, List, Optional, Tuple

# Blueprint utils imported lazily inside methods to avoid circular imports.
# resolve_cpp_blueprint and load_json are imported on first use.

# ── module constants ─────────────────────────────────────────────────────────

_CPP_ALIAS_CACHE_MAX = 128   # per-instance C++ alias map cache ceiling (T6)
_ARG_BIND_CACHE_MAX  = 256   # per-instance arg_bind / struct-canonical cache (T10/T11)


# ── module-level helpers ─────────────────────────────────────────────────────

def _parse_arg_bind_target(target_str: str) -> Tuple[Optional[str], Optional[int]]:
    """Parse ``call_arg:funcName#N`` into ``(funcName, N)`` or ``(None, None)``.

    arg_bind edges in the GVL use ``call_arg:funcName#argIndex`` as the target.
    N is the 0-based argument position.
    Returns ``(None, None)`` if the string does not match the expected format.
    """
    if not target_str.startswith("call_arg:"):
        return None, None
    rest = target_str[len("call_arg:"):]
    if "#" not in rest:
        return None, None
    func_name, _, idx_str = rest.rpartition("#")
    try:
        return func_name, int(idx_str)
    except (ValueError, TypeError):
        return None, None


class VariableNameResolver:
    """Resolve what a variable is called inside a target file using the identity index.

    The index is loaded once per process (class-level cache keyed by absolute path).

    T6: C++ fallback via ``field_asm_aliases`` in the target C++ blueprint.
        Case A — ASM name  → C++ field name (reverse lookup).
        Case B — C++ field → ASM name       (forward lookup).

    T10: Case C — pure C++→C++ rename via ``arg_bind`` parameter binding.
        Uses ``arg_bind`` edges in the source GVL to find which argument position
        the dep_var occupies, then finds the parameter name at that position in
        the target GVL.

    T11: Case D — struct field canonical matching via ``(enclosing_type, field_name)``.
        Uses ``metadata.enclosing_type`` already emitted by the parser on all
        ``struct_field``-kind GVL nodes to match fields across files even when the
        pointer variable name or field name differs.
    """

    _cache: ClassVar[Dict[str, Optional[Dict]]] = {}
    _INDEX_CACHE_MAX: ClassVar[int] = 16  # max unique index files held in-memory

    def __init__(self, blueprint_dir: Path) -> None:
        self._path: Optional[Path] = self._find_index_path(blueprint_dir)
        self._job_id: Optional[str] = (
            self._derive_job_id(self._path)
            or self._derive_job_id(blueprint_dir)  # fallback: derive from blueprint_dir when index file was deleted after DB ingest
        )
        self._index: Optional[Dict] = None
        self._index_loaded: bool = False
        self._blueprint_dir: Optional[Path] = blueprint_dir          # T6
        self._cpp_alias_cache: Dict[str, Dict] = {}                   # T6
        self._arg_bind_cache: Dict[Tuple[str, str, str], Optional[str]] = {}  # T10 Case C
        self._struct_canonical_cache: Dict[Tuple[str, str, str], Optional[str]] = {}  # T11 Case D (FIX-new-4)

    @classmethod
    def from_path(
        cls,
        path_str: str,
        blueprint_dir: Optional[Path] = None,
    ) -> "VariableNameResolver":
        """Reconstruct from a stored path string (e.g., from session msgpack state).

        ``blueprint_dir`` is optional; pass it so Cases A/B/C/D can function.
        """
        inst: "VariableNameResolver" = object.__new__(cls)
        inst._path = Path(path_str) if path_str else None
        inst._job_id = cls._derive_job_id(inst._path)
        inst._index = None
        inst._index_loaded = False
        inst._blueprint_dir = blueprint_dir                           # T6
        inst._cpp_alias_cache = {}                                    # T6
        inst._arg_bind_cache = {}                                     # T10 Case C
        inst._struct_canonical_cache = {}                             # T11 Case D (FIX-new-4)
        return inst

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def resolve(
        self,
        variable: str,
        target_stem: str,
        source_stem: Optional[str] = None,   # T10/T11: caller file stem
    ) -> Optional[str]:
        """Return the leaf name of *variable* in *target_stem*, or None if unknown.

        Resolution order:
        1. ASM identity index lookup (existing behaviour).
        2. Case A — ASM name → C++ field name via ``field_asm_aliases`` reverse
           lookup in the *target* C++ blueprint (T6).
        3. Case B — C++ field → ASM name via ``field_asm_aliases`` forward lookup
           in the *target* C++ blueprint (T6).
        4. Case C — pure C++→C++ rename via ``arg_bind`` parameter binding (T10);
           only runs when ``source_stem`` is provided.
        5. Case D — struct field canonical matching via
           ``(enclosing_type, field_name)`` (T11); only runs when ``source_stem``
           is provided and Case C found nothing.

        ``source_stem=None`` leaves all existing call-sites unchanged — Cases C
        and D are never reached, so behaviour is identical to before T10/T11.
        """
        # ── ASM index lookup — DB-first, JSON fallback ────────────────────
        # DB path: indexed lookup via variable_identity_files (no JSON parsing).
        if self._job_id:
            try:
                from api.index_db.readers import get_canonical_key, get_variable_file_node_id
                _ck = get_canonical_key(self._job_id, variable.upper())
                if _ck:
                    _node_id = get_variable_file_node_id(
                        self._job_id, _ck, target_stem,
                    )
                    if _node_id:
                        return _node_id.split(":")[-1] if ":" in _node_id else _node_id
            except Exception:
                pass  # fall through to JSON index

        index = self._get_index()
        if index:
            canonical_key = (index.get("by_name") or {}).get(variable.upper())
            if canonical_key:
                entry = (index.get("by_identity") or {}).get(canonical_key) or {}
                node_id = (entry.get("files") or {}).get(target_stem)
                if node_id:
                    return node_id.split(":")[-1] if ":" in node_id else node_id

        # ── Case A (T6): ASM name → C++ field name ────────────────────────
        alias_map = self._get_cpp_alias_map(target_stem)
        if alias_map:
            cpp_fields = alias_map.get(str(variable).upper())
            if cpp_fields:
                return cpp_fields[0]

        # ── Case B (T6): C++ field → ASM name ────────────────────────────
        if self._blueprint_dir:
            try:
                from backward_traversal.utils.blueprint_utils import (
                    load_json,
                    resolve_cpp_blueprint,
                )
                bp_path = resolve_cpp_blueprint(target_stem, self._blueprint_dir)
                if bp_path:
                    bp = load_json(bp_path)
                    asm_name = (bp.get("field_asm_aliases") or {}).get(variable)
                    if asm_name:
                        return str(asm_name)
            except Exception:
                pass

        # ── Cases C + D only run when we have a source_stem ───────────────
        if source_stem and source_stem != target_stem:
            # Case C (T10): arg_bind parameter binding
            result = self._resolve_via_arg_bind(variable, source_stem, target_stem)
            if result is not None:
                return result

            # Case D (T11): struct canonical matching via (enclosing_type, field_name)
            result = self._resolve_via_struct_canonical(variable, source_stem, target_stem)
            if result is not None:
                return result

            # Case D-ext (T12): file-scope variable canonical matching via
            # metadata.canonical_name (only present when parser >= T12 commit).
            result = self._resolve_via_variable_canonical(variable, source_stem, target_stem)
            if result is not None:
                return result

        return None

    @property
    def index_path(self) -> Optional[str]:
        """Absolute path string of the index file, or None if not found."""
        return str(self._path.resolve()) if self._path else None

    # ------------------------------------------------------------------
    # T6 — C++ alias-map cache
    # ------------------------------------------------------------------

    def _get_cpp_alias_map(self, stem: str) -> Dict[str, List[str]]:
        """Return ``{ASM_NAME_UPPER: [cpp_field, ...]}`` for the given C++ stem.

        Result is cached with FIFO eviction at ``_CPP_ALIAS_CACHE_MAX`` entries.
        """
        if stem in self._cpp_alias_cache:
            return self._cpp_alias_cache[stem]
        if not self._blueprint_dir:
            return {}
        try:
            from backward_traversal.utils.blueprint_utils import (
                load_json,
                resolve_cpp_blueprint,
            )
            bp_path = resolve_cpp_blueprint(stem, self._blueprint_dir)
            if not bp_path:
                self._cpp_alias_cache[stem] = {}
                return {}
            bp = load_json(bp_path)
        except Exception:
            self._cpp_alias_cache[stem] = {}
            return {}

        alias_map: Dict[str, List[str]] = {}
        for cpp_field, asm_name in (bp.get("field_asm_aliases") or {}).items():
            key = str(asm_name).upper()
            if key:
                alias_map.setdefault(key, []).append(str(cpp_field))

        if len(self._cpp_alias_cache) >= _CPP_ALIAS_CACHE_MAX:
            self._cpp_alias_cache.pop(next(iter(self._cpp_alias_cache)))
        self._cpp_alias_cache[stem] = alias_map
        return alias_map

    # ------------------------------------------------------------------
    # T10 — arg_bind parameter binding (Case C)
    # ------------------------------------------------------------------

    def _resolve_via_arg_bind(
        self,
        dep_var: str,
        source_stem: str,
        target_stem: str,
    ) -> Optional[str]:
        """Case C: pure C++→C++ rename via ``arg_bind`` edges.

        Looks for ``arg_bind`` edges in ``source_stem``'s GVL where the source
        node ends with ``::dep_var``, extracts the callee function name and
        argument index from the ``call_arg:funcName#N`` target, then finds the
        N-th parameter of that function in ``target_stem``'s GVL.

        Result is cached in ``_arg_bind_cache`` (shared with T11 Case D).
        Returns ``None`` on any exception or when no match is found.
        """
        cache_key = (dep_var, source_stem, target_stem)
        if cache_key in self._arg_bind_cache:
            return self._arg_bind_cache[cache_key]

        result = self._resolve_via_arg_bind_uncached(dep_var, source_stem, target_stem)

        if len(self._arg_bind_cache) >= _ARG_BIND_CACHE_MAX:
            self._arg_bind_cache.pop(next(iter(self._arg_bind_cache)))
        self._arg_bind_cache[cache_key] = result
        return result

    def _resolve_via_arg_bind_uncached(
        self,
        dep_var: str,
        source_stem: str,
        target_stem: str,
    ) -> Optional[str]:
        if not self._blueprint_dir:
            return None
        try:
            from backward_traversal.utils.blueprint_utils import (
                load_json,
                resolve_cpp_blueprint,
            )
            src_bp_path = resolve_cpp_blueprint(source_stem, self._blueprint_dir)
            if not src_bp_path:
                return None
            from backward_traversal.utils.lazy_gvl import make_lazy_gvl as _mkgvl
            src_gvl = _mkgvl(load_json(src_bp_path), blueprint_path=src_bp_path)

            tgt_bp_path = resolve_cpp_blueprint(target_stem, self._blueprint_dir)
            if not tgt_bp_path:
                return None
            tgt_gvl = _mkgvl(load_json(tgt_bp_path), blueprint_path=tgt_bp_path)
        except Exception:
            return None

        dep_var_lower = dep_var.lower()

        for edge in (src_gvl.get("edges") or []):
            if str(edge.get("relation", "")).lower() != "arg_bind":
                continue
            src_node = str(edge.get("source", "")).lower()
            # Match node ids ending with ::dep_var, :dep_var, or ->dep_var.
            # NEW-C: the "->" form is needed for struct-field dep_vars whose GVL
            # node ID ends with "->fieldName" (e.g. "struct_field:fn::ptr->cmSystem").
            # Without it, Case C returns None for every struct-field dep_var.
            # ISSUE-7: apply the same len>=4 guard used in Strategy 5 and the
            # fallback to the "->" suffix check — prevents matching every struct
            # field named "id", "cnt", etc. when dep_var is a short name.
            if not (src_node.endswith(f"::{dep_var_lower}")
                    or src_node.endswith(f":{dep_var_lower}")
                    or (len(dep_var_lower) >= 4 and src_node.endswith(f"->{dep_var_lower}"))):
                continue

            callee_fn, arg_idx = _parse_arg_bind_target(str(edge.get("target", "")))
            if callee_fn is None or arg_idx is None:
                continue

            # Find the arg_idx-th parameter of callee_fn in target GVL.
            # Parameter nodes use id = "parameter:funcName::paramName" and carry
            # metadata.enclosing_function.  They should be sorted by
            # metadata.parameter_position (0-based) when that field is present so
            # that the N-th entry reliably corresponds to argument position N
            # regardless of the order the GVL builder emitted them (GAP-013).
            callee_fn_lower = callee_fn.lower()
            params = [
                n for n in (tgt_gvl.get("nodes") or [])
                if str(n.get("kind", "")).lower() == "parameter"
                and str((n.get("metadata") or {}).get("enclosing_function") or "").lower()
                   == callee_fn_lower
            ]
            # GAP-013: sort by parameter_position when the metadata is present.
            # Fall back to iteration order only when none of the nodes carry the
            # field (older parser output without parameter_position metadata).
            if any(
                (n.get("metadata") or {}).get("parameter_position") is not None
                for n in params
            ):
                params = sorted(
                    params,
                    key=lambda n: int(
                        (n.get("metadata") or {}).get("parameter_position", 99999)
                    ),
                )
            if 0 <= arg_idx < len(params):
                param_node = params[arg_idx]
                # name may be "funcName::paramName" — take the last segment
                param_name = str(param_node.get("name") or "")
                if "::" in param_name:
                    param_name = param_name.split("::")[-1]
                elif ":" in param_name:
                    param_name = param_name.split(":")[-1]
                return param_name or None

        return None

    # ------------------------------------------------------------------
    # T11 — struct canonical matching (Case D)
    # ------------------------------------------------------------------

    def _resolve_via_struct_canonical(
        self,
        dep_var: str,
        source_stem: str,
        target_stem: str,
    ) -> Optional[str]:
        """Case D: struct field canonical matching via ``(enclosing_type, field_name)``.

        Uses ``metadata.enclosing_type`` (already present on all ``struct_field``
        GVL nodes) as the canonical key to match the same field across files even
        when the pointer variable name differs.

        Returns the terminal field name in the target file if the field name is
        *different* there; returns ``None`` when the names already match (Strategy 5
        in ``find_cpp_seed_nodes`` handles the same-name case without help from
        the resolver).

        FIX-new-4: uses its own ``_struct_canonical_cache`` instead of sharing
        ``_arg_bind_cache`` with Case C.  Previously, a Case C miss cached ``None``
        under the same key, causing Case D to return ``None`` immediately without
        running its own lookup.
        """
        cache_key = (dep_var, source_stem, target_stem)
        if cache_key in self._struct_canonical_cache:
            return self._struct_canonical_cache[cache_key]

        result = self._resolve_via_struct_canonical_uncached(dep_var, source_stem, target_stem)

        if len(self._struct_canonical_cache) >= _ARG_BIND_CACHE_MAX:
            self._struct_canonical_cache.pop(next(iter(self._struct_canonical_cache)))
        self._struct_canonical_cache[cache_key] = result
        return result

    def _resolve_via_struct_canonical_uncached(
        self,
        dep_var: str,
        source_stem: str,
        target_stem: str,
    ) -> Optional[str]:
        if not self._blueprint_dir:
            return None
        try:
            from backward_traversal.utils.blueprint_utils import (
                load_json,
                resolve_cpp_blueprint,
            )
            src_bp_path = resolve_cpp_blueprint(source_stem, self._blueprint_dir)
            tgt_bp_path = resolve_cpp_blueprint(target_stem, self._blueprint_dir)
            if not src_bp_path or not tgt_bp_path:
                return None
            from backward_traversal.utils.lazy_gvl import make_lazy_gvl as _mkgvl
            src_gvl = _mkgvl(load_json(src_bp_path), blueprint_path=src_bp_path)
            tgt_gvl = _mkgvl(load_json(tgt_bp_path), blueprint_path=tgt_bp_path)
        except Exception:
            return None

        dep_lower = dep_var.lower()

        # Step 1 — find enclosing_type for dep_var in source GVL
        src_etype: Optional[str] = None
        for node in (src_gvl.get("nodes") or []):
            if str(node.get("kind", "")).lower() != "struct_field":
                continue
            nid   = str(node.get("id", ""))
            fname = nid.split("->")[-1].split("::")[-1].strip().lower()
            nname = str(node.get("name") or "").strip().lower()
            if fname == dep_lower or nname == dep_lower:
                meta = node.get("metadata") or {}
                etype = str(meta.get("enclosing_type") or "").strip().lower()
                if etype:
                    src_etype = etype
                    break

        if not src_etype:
            return None   # not a struct field or no type info — Case D cannot help

        # Collect ALL field names for this struct type in the source GVL.
        # NEW-ISSUE-1 fix: needed in Step 2 to distinguish genuinely renamed fields
        # from fields that are unchanged (different from dep_lower but still present
        # in the source struct).  Without this set, iterating target fields with
        # etype==src_etype would collect ALL non-dep_lower fields as candidates —
        # making every multi-field struct return None due to the ambiguity guard.
        src_field_names: Set[str] = set()
        for node in (src_gvl.get("nodes") or []):
            if str(node.get("kind", "")).lower() != "struct_field":
                continue
            meta = node.get("metadata") or {}
            if str(meta.get("enclosing_type") or "").strip().lower() != src_etype:
                continue
            nid = str(node.get("id", ""))
            fn = nid.split("->")[-1].split("::")[-1].strip().lower()
            if not fn:
                fn = str(node.get("name") or "").strip().lower()
            if fn:
                src_field_names.add(fn)

        # Step 2 — build canonical map for target GVL and look up the match
        # Inline _build_struct_canonical_map to avoid import of cpp_lineage_utils here
        tgt_map: Dict[Tuple[str, str], List[str]] = {}
        for node in (tgt_gvl.get("nodes") or []):
            if str(node.get("kind", "")).lower() != "struct_field":
                continue
            meta  = node.get("metadata") or {}
            etype = str(meta.get("enclosing_type") or "").strip().lower()
            if not etype:
                continue
            nid   = str(node.get("id", ""))
            fname = nid.split("->")[-1].split("::")[-1].strip().lower()
            if not fname:
                fname = str(node.get("name") or "").strip().lower()
            if fname:
                tgt_map.setdefault((etype, fname), []).append(nid)

        # NEW-BUG-2: tgt_map keys are (etype, TARGET_fname).  Looking up
        # (src_etype, dep_lower) treats the SOURCE field name as if it were the
        # TARGET field name — which is exactly wrong when the field was renamed.
        # Fix: try the exact key first (same-name case); if absent, collect only
        # target fields that are absent from the source struct (i.e. genuine renames).
        # Return None when the result is ambiguous (multiple renamed fields).
        exact_matches = tgt_map.get((src_etype, dep_lower))
        if exact_matches:
            # Same field name in target; Strategy 5 already handles this.
            return None

        # Collect target fields of this struct type that:
        #   (a) differ from dep_lower, AND
        #   (b) are NOT present in the source struct's field set (so are genuinely
        #       new or renamed, not just other unchanged fields of the same struct).
        # NEW-ISSUE-1 fix: filtering by src_field_names prevents unchanged sibling
        # fields from polluting renamed_candidates in multi-field structs.
        renamed_candidates: List[str] = []
        for (etype, fname), nids in tgt_map.items():
            if etype != src_etype or fname == dep_lower:
                continue
            if fname in src_field_names:
                continue  # field exists in source too — not a rename
            for nid in nids:
                tgt_f = nid.split("->")[-1].split("::")[-1].strip()
                if not tgt_f:
                    tgt_f = fname
                if tgt_f.lower() != dep_lower:
                    renamed_candidates.append(tgt_f)

        # Only resolve when the match is unambiguous.
        return renamed_candidates[0] if len(renamed_candidates) == 1 else None

    def _resolve_via_variable_canonical(
        self,
        dep_var: str,
        source_stem: str,
        target_stem: str,
    ) -> Optional[str]:
        """T12 extension of Case D — resolve file-scope variable renames via
        ``metadata.canonical_name``.

        This covers the rare case where two C++ translation units share the same
        linker-level global variable but use different local names
        (e.g. ``g_systemLimit`` in fileA vs ``systemLimitCap`` in fileB declared
        with ``extern``).

        Resolution steps:
        1. Scan *source_stem*'s GVL for a ``variable``-kind node whose name/id
           terminal matches *dep_var* and has ``metadata.canonical_name``.
        2. Scan *target_stem*'s GVL for a ``variable``-kind node with the same
           ``metadata.canonical_name``.
        3. Return the target node's terminal name when it differs from *dep_var*;
           return ``None`` when names already match (Strategy 5 handles that).

        Returns ``None`` on any exception or when ``canonical_name`` is absent
        (e.g. local variables, parser older than T12 commit).
        """
        if not self._blueprint_dir:
            return None
        try:
            from backward_traversal.utils.blueprint_utils import (
                load_json,
                resolve_cpp_blueprint,
            )
            src_bp_path = resolve_cpp_blueprint(source_stem, self._blueprint_dir)
            tgt_bp_path = resolve_cpp_blueprint(target_stem, self._blueprint_dir)
            if not src_bp_path or not tgt_bp_path:
                return None
            from backward_traversal.utils.lazy_gvl import make_lazy_gvl as _mkgvl
            src_gvl = _mkgvl(load_json(src_bp_path), blueprint_path=src_bp_path)
            tgt_gvl = _mkgvl(load_json(tgt_bp_path), blueprint_path=tgt_bp_path)
        except Exception:
            return None

        dep_lower = dep_var.lower()

        # Step 1 — find canonical_name for dep_var in source GVL
        src_canonical: Optional[str] = None
        for node in (src_gvl.get("nodes") or []):
            if str(node.get("kind", "")).lower() != "variable":
                continue
            nid   = str(node.get("id",   "") or "").split("::")[-1].strip().lower()
            nname = str(node.get("name", "") or "").strip().lower()
            if nid != dep_lower and nname != dep_lower:
                continue
            meta = node.get("metadata") or {}
            cn = str(meta.get("canonical_name") or "").strip().lower()
            if cn:
                src_canonical = cn
                break

        if not src_canonical:
            return None   # node absent or parser pre-T12 — Case D extension cannot help

        # Step 2 — find matching variable node in target GVL
        for node in (tgt_gvl.get("nodes") or []):
            if str(node.get("kind", "")).lower() != "variable":
                continue
            meta = node.get("metadata") or {}
            tgt_canonical = str(meta.get("canonical_name") or "").strip().lower()
            if tgt_canonical != src_canonical:
                continue
            # Found a canonical match — return the target node's terminal name.
            tgt_name = str(node.get("name", "") or "").strip()
            # Strip any qualifier prefix (e.g. "funcName::varName" → "varName")
            tgt_terminal = tgt_name.split("::")[-1].strip()
            return tgt_terminal if tgt_terminal.lower() != dep_lower else None

        return None

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _get_index(self) -> Optional[Dict]:
        if not self._index_loaded:
            self._index_loaded = True
            if self._path is not None:
                key = str(self._path.resolve())
                if key not in VariableNameResolver._cache:
                    # Evict oldest entry when cache is at capacity (FIFO)
                    if len(VariableNameResolver._cache) >= VariableNameResolver._INDEX_CACHE_MAX:
                        VariableNameResolver._cache.pop(next(iter(VariableNameResolver._cache)))
                    try:
                        VariableNameResolver._cache[key] = json.loads(
                            self._path.read_text(encoding="utf-8")
                        )
                    except Exception:
                        VariableNameResolver._cache[key] = None
                self._index = VariableNameResolver._cache[key]
            else:
                # Only warn when neither the JSON file nor the index DB is available.
                # After a successful pipeline run the JSON file is deleted once it has
                # been ingested into the index DB — so _path=None + _job_id=<valid> is
                # the normal state.  The DB path in resolve() handles lookups fine.
                if not self._job_id:
                    import logging as _logging
                    _logging.getLogger(__name__).warning(
                        "VariableNameResolver: variable_identity_index.json not found "
                        "(blueprint_dir=%s). Cross-file name translation will fall back "
                        "to the original variable name for every lookup. Re-run the "
                        "pipeline or verify that blueprint_dir is set correctly.",
                        getattr(self, "_blueprint_dir", "<unknown>"),
                    )
        return self._index

    @staticmethod
    def _find_index_path(blueprint_dir: Path) -> Optional[Path]:
        for candidate in (
            blueprint_dir.parent / "variable_identity_index.json",
            blueprint_dir / "variable_identity_index.json",
        ):
            if candidate.exists():
                return candidate
        return None

    @staticmethod
    def _derive_job_id(path: Optional[Path]) -> Optional[str]:
        """Derive job_id from the identity index path (inside jobs/{job_id}/...)."""
        if path is None:
            return None
        try:
            from api.index_db.engine import job_id_from_path
            return job_id_from_path(path)
        except Exception:
            return None
