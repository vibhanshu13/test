"""Utilities for extracting C++ lineage bridge data from cpp.json blueprints.

Consumed by the backward-only runner when the traversal chain crosses into a
C++ upstream file.  No side effects — pure helpers over the blueprint dicts
that are already in memory.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple


# ── helpers ─────────────────────────────────────────────────────────────────

def _safe_str(v: Any) -> str:
    return str(v or "")


_REG_RE = re.compile(r"\bR(\d+)\b", re.IGNORECASE)


def _extract_reg_num(text: str) -> Optional[str]:
    """Return the first register number (e.g. 'R7') found in text, or None."""
    m = _REG_RE.search(text)
    if not m:
        return None
    num = int(m.group(1))
    if num > 15:
        return None
    return f"R{num}"


def _field_components(text: str) -> List[str]:
    """Normalize a field path into lowercase identifier components."""
    return [part.lower() for part in re.split(r"[^A-Za-z0-9$_@]+", _safe_str(text)) if part]


# ── public API ───────────────────────────────────────────────────────────────

def reverse_field_alias_map(bp: Dict[str, Any]) -> Dict[str, List[str]]:
    """Invert field_asm_aliases: ASM_NAME → [StructName.fieldName, ...].

    bp is the raw parsed cpp.json blueprint dict.
    """
    rev: Dict[str, List[str]] = {}
    for cpp_field, asm_name in (bp.get("field_asm_aliases") or {}).items():
        key = _safe_str(asm_name).upper()
        if key:
            rev.setdefault(key, []).append(str(cpp_field))
    return rev


def extract_asm_field_aliases(
    bp: Dict[str, Any],
    variable: str,
    transitive_vars: Iterable[str] = (),
) -> Dict[str, List[str]]:
    """Return the reverse-alias mapping filtered to the variables we care about.

    Returns: { "WK_CMO": ["Da7gl.cmSystem", ...], "LG1OSI": [...], ... }
    Only ASM names that match variable or any entry in transitive_vars are kept.
    """
    wanted: Set[str] = {_safe_str(variable).upper()}
    for v in transitive_vars:
        s = _safe_str(v).strip().upper()
        if s:
            wanted.add(s)

    rev = reverse_field_alias_map(bp)
    return {k: v for k, v in rev.items() if k in wanted}


def extract_tpf_regs_slots(
    gvl: Dict[str, Any],
    callee: str,
) -> Dict[str, Dict[str, Any]]:
    """Scan global_variable_lineage edges for TPF_regs passthrough at the given callee.

    Looks for edges of the form:
        struct_field:*::regs.rN  →  register:arg@<CALLEE>:RN    rel=assign
        struct_field:*::regs->rN →  parameter:arg@<CALLEE>:RN   rel=assign

    Returns:
        {
          "R7": {
            "cpp_sources": ["struct_field:globalLimitsUpdate::regs.r7", ...],
            "call_sites":  [{"file": "...", "line": 76, "expression": "..."}, ...]
          },
          ...
        }
    """
    if not callee or not gvl:
        return {}

    callee_upper = _safe_str(callee).upper()
    slots: Dict[str, Dict[str, Any]] = {}

    for e in (gvl.get("edges") or []):
        target = _safe_str(e.get("target"))
        # Match: "register:arg@<CALLEE>:R<N>" or "parameter:arg@<CALLEE>:R<N>"
        # P3-4: use exact segment match instead of substring to avoid false positives
        # when callee_upper is a prefix of another callee name.
        # Target format is "TYPE:ARG@CALLEE:REG" — split and check segment [1] exactly.
        target_parts = target.upper().split(":")
        if len(target_parts) < 3 or target_parts[1] != f"ARG@{callee_upper}":
            continue

        # Extract register number from the last segment (e.g. "R7")
        reg = _extract_reg_num(target_parts[-1])
        if reg is None:
            continue

        entry = slots.setdefault(reg, {"cpp_sources": [], "call_sites": []})

        source = _safe_str(e.get("source"))
        if source and source not in entry["cpp_sources"]:
            entry["cpp_sources"].append(source)

        line = e.get("line")
        if line is not None:
            cs = {
                "file": _safe_str(e.get("file")),
                "line": int(line),
                "expression": _safe_str(e.get("expression")),  # P3-2: full expr; truncate at serialization
            }
            if cs not in entry["call_sites"]:
                entry["call_sites"].append(cs)

    return slots


# P41: REGNA macro region names → CE1USA canonical ECB field.
# REGNA declares EB0USER–EB7USER as 64-byte sub-regions of the CE1USA area.
# When an ASM variable is an EBnUSER region name, the corresponding C++ node
# accesses ecbptr()->ce1usa (possibly with a byte offset).  Strategy 6 maps
# these ASM region names so they reach the correct C++ seed node.
_REGNA_REGION_NAMES: frozenset = frozenset({
    "EB0USER", "EB1USER", "EB2USER", "EB3USER",
    "EB4USER", "EB5USER", "EB6USER", "EB7USER",
})
_REGNA_CE1USA_ALIAS: str = "ce1usa"

# P29: ALASW application-level switch/work area → CE1ALASW ECB pointer field.
# ASM code establishes ALASW addressability via "USING ALASW,Rx" and accesses
# fields directly by their DSECT names (e.g. ALAFLAG1, ALAFLAG2).
# C++ accesses the same bytes via ecbptr()->ce1alasw->alaflag1.  Strategy 5
# handles most ALASW fields via ->fieldname suffix matching.  Strategy 8 is a
# fallback for the ECB pointer itself ("CE1ALASW") and for ALASW-named DSECTs
# when the only GVL node is the struct-level ce1alasw pointer node.
_ALASW_ECB_POINTER: str = "ce1alasw"
_ALASW_DSECT_NAMES: frozenset = frozenset({"ALASW", "CE1ALASW"})


def find_cpp_seed_nodes(
    gvl: Dict[str, Any],
    variable: str,
    asm_field_aliases: Dict[str, List[str]],
    tpf_regs_slots: Dict[str, Dict[str, Any]],
    *,
    file_stem: Optional[str] = None,
    skip_scan_fallback: bool = False,
) -> List[str]:
    """Return global_variable_lineage node IDs that are C++ entry points for variable.

    Eight discovery strategies (combined, deduplicated):

    1. Nodes whose metadata.asm_alias == variable (scoped and unscoped).
    2. Nodes whose id/name suffix matches a field path surfaced via
       asm_field_aliases (e.g. Da7gl.cmSystem → *::da7gl->cmSystem).
       P26: trailing digit-only components (array index suffixes like [3] → "3")
       are stripped before suffix comparison so array element nodes match.
    3. Source of a global_lineage_stitch:cpp_field_to_asm edge that points at
       the ASM memory node for variable.  Uses exact suffix match (FIX 9):
       the target's terminal component must equal var_upper, not merely contain
       it — prevents false-positive seeds for short names like "R7" matching
       "R7G" or "R7_STORE".
    4. cpp_sources from tpf_regs_slots — C++ struct_field nodes that write
       the register slot used by the callee.
    5. Direct name / ID match for normalized dep_var names (FIX 11, FIX 21):
       matches nodes by exact name equality or id suffix (::name, :name, ->name).
       The ->name form finds struct fields regardless of the pointer variable
       prefix, so "cmSystem" matches both "da7gl->cmSystem" and "record->cmSystem".
       P26: also checks base form with [N] array notation stripped.
    6. P41 — REGNA region names (EB0USER–EB7USER) → ce1usa alias lookup.
       REGNA declares named 64-byte sub-regions within CE1USA.  ASM code uses
       region names while C++ accesses ecbptr()->ce1usa directly (with offsets).
       When variable is an EBnUSER name, search for nodes matching "ce1usa" so
       that the C++ GVL backward trace starts at the correct ECB field node.
    7. P28 — @MMU-prefixed GLOBZ global storage variables.  Strips leading "@"
       and matches GVL nodes by the stripped name (C++ uses tpfglbl.mmufoo).
    8. P29 — ALASW application-level work area ECB pointer.  When the variable
       is "ALASW" or "CE1ALASW" (the struct-level DSECT name rather than an
       individual field), search for GVL nodes matching "ce1alasw" so that the
       backward trace reaches the ECB pointer field node.
    """
    # ── DB-backed fast path ────────────────────────────────────────────────
    # When the cpp_seed_keys index exists, use it instead of scanning the
    # full GVL.  Only applicable when asm_field_aliases and tpf_regs_slots
    # are empty (the dep_var path always passes {} for both — Strategies 2
    # and 4 are never triggered).
    if not asm_field_aliases and not tpf_regs_slots:
        try:
            from api.index_db.readers import get_cpp_seed_node_ids
            _job_id = getattr(gvl, "_job_id", None)
            if _job_id:
                db_seeds = get_cpp_seed_node_ids(
                    _job_id, variable, file_stem=file_stem,
                )
                if db_seeds is not None:  # None = index unavailable
                    if db_seeds:
                        return db_seeds  # Non-empty — use DB result
                    # DB returned [] — fall through to scan-based fallback.
                    # The DB index may not cover every variable (short names,
                    # edge cases, stale index).  Let Strategies 1-8 try.
                    #
                    # Opt C: When skip_scan_fallback=True (dep_var path), return
                    # empty immediately.  For the dep_var path, Strategies 2 & 4
                    # are disabled (empty asm_field_aliases/tpf_regs_slots) and
                    # Strategies 1, 3, 5, 6, 7, 8 are fully indexed in the DB.
                    # The scan can never find seeds the DB missed.
                    if skip_scan_fallback:
                        import logging as _logging
                        _logging.getLogger(__name__).debug(
                            "find_cpp_seed_nodes: DB returned 0 seeds for '%s'%s "
                            "(skip_scan_fallback=True — returning empty)",
                            _safe_str(variable).upper(),
                            f" in file_stem={file_stem}" if file_stem else "",
                        )
                        return []
                    import logging as _logging
                    _logging.getLogger(__name__).debug(
                        "find_cpp_seed_nodes: DB index returned 0 seeds for '%s'%s, "
                        "falling through to scan",
                        _safe_str(variable).upper(),
                        f" in file_stem={file_stem}" if file_stem else "",
                    )
        except Exception:
            pass  # fall through to scan

    # ── Original scan-based logic (fallback) ───────────────────────────────
    var_upper = _safe_str(variable).upper()
    var_lower = var_upper.lower()
    seeds: List[str] = []
    seen: Set[str] = set()

    def _add(nid: str) -> None:
        s = _safe_str(nid).strip()
        if s and s not in seen:
            seen.add(s)
            seeds.append(s)

    # Pre-compute alias_paths for Strategy 2 (avoids recomputing inside loop).
    alias_paths = [
        _field_components(field_path)
        for field_paths in asm_field_aliases.values()
        for field_path in field_paths
        if _field_components(field_path)
    ]

    # GAP-034 skip kinds for Strategy 5.
    # "parameter" was previously skipped here, but parameters are valid seeds:
    #   - Output parameters (*ptr written inside the callee) have assign edges
    #     in their defining file — _filter_seeds_to_file keeps them correctly.
    #   - Input parameters have no assign edges in the modifier file, so
    #     _filter_seeds_to_file drops them (stem_seen_anywhere guard), and
    #     _scope_cpp_trace_to_file removes any stray cross-file setter edges.
    # Keeping parameter seeds enables cross-file traversal where the variable
    # is a function parameter of the called (modifier) file.
    _STRATEGY5_SKIP_KINDS: Set[str] = {"call_arg", "return_value", "register"}

    # ── Single pass over nodes (Strategies 1, 2, 5) ──────────────────────────
    # Previously three separate loops; merged into one so that streaming
    # LazyGVL iterables only cause a single disk pass over the "nodes" section.
    for n in (gvl.get("nodes") or []):
        meta = n.get("metadata") or {}
        nid = _safe_str(n.get("id"))
        name = _safe_str(n.get("name"))
        nid_str = nid or name

        # Strategy 1: metadata.asm_alias
        alias = _safe_str(meta.get("asm_alias")).upper()
        if alias == var_upper:
            _add(nid_str)
            continue  # no need to check other strategies for this node

        # Strategy 2: field alias suffix match
        # P26: also try with trailing digit-only components stripped so that C++ array
        # node IDs like "cyclicallimitsbyse[3]" (→ parts ["cyclicallimitsbyse","3"])
        # match the alias path ["cyclicallimitsbyse"] derived from asm_field_aliases.
        if alias_paths:
            id_parts = _field_components(nid)
            name_parts = _field_components(name)
            # Strip trailing digit-only components (array index suffixes from [N] notation)
            id_parts_nodigit = id_parts[:]
            while id_parts_nodigit and id_parts_nodigit[-1].isdigit():
                id_parts_nodigit = id_parts_nodigit[:-1]
            name_parts_nodigit = name_parts[:]
            while name_parts_nodigit and name_parts_nodigit[-1].isdigit():
                name_parts_nodigit = name_parts_nodigit[:-1]
            matched = False
            for alias_parts in alias_paths:
                alen = len(alias_parts)
                if ((len(id_parts) >= alen and id_parts[-alen:] == alias_parts)
                        or (len(name_parts) >= alen and name_parts[-alen:] == alias_parts)
                        or (len(id_parts_nodigit) >= alen and id_parts_nodigit[-alen:] == alias_parts)
                        or (len(name_parts_nodigit) >= alen and name_parts_nodigit[-alen:] == alias_parts)):
                    _add(nid_str)
                    matched = True
                    break
            if matched:
                continue

        # Strategy 5 (FIX 11 + FIX 21): direct name or normalized ID match.
        # GAP-034: skip transient-node kinds.
        # P26: also strip array index notation [N] from nid/nname before comparison
        # so that GVL nodes like "lg1cycl[3]" match the ASM variable "LG1CYCL".
        n_kind = _safe_str(meta.get("kind") or n.get("kind") or "").lower()
        if n_kind and n_kind in _STRATEGY5_SKIP_KINDS:
            continue
        nname = name.lower()
        nid_lower = nid.lower()
        # Base forms with array index notation stripped (P26)
        nid_base = nid_lower.split("[")[0]
        nname_base = nname.split("[")[0]
        if (nname == var_lower
                or nname_base == var_lower
                or nid_lower == var_lower
                or nid_base == var_lower
                or nid_lower.endswith(f"::{var_lower}")
                or nid_base.endswith(f"::{var_lower}")
                or nid_lower.endswith(f":{var_lower}")
                or nid_base.endswith(f":{var_lower}")
                # GAP-012: raised ->name threshold from 4 → 6 chars.
                or (len(var_lower) >= 6 and nid_lower.endswith(f"->{var_lower}"))
                or (len(var_lower) >= 6 and nid_base.endswith(f"->{var_lower}"))
                # Dot-notation struct field paths (e.g. plasticAuth.process.transactionInds.softCardValue).
                # C++ struct member access via '.' produces node IDs ending with .fieldname rather than
                # ::fieldname or ->fieldname.  Apply the same ≥6 char guard to limit false positives.
                or (len(var_lower) >= 6 and nid_lower.endswith(f".{var_lower}"))
                or (len(var_lower) >= 6 and nid_base.endswith(f".{var_lower}"))):
            _add(nid_str)

    # Strategy 3: cpp_field_to_asm stitching edges → source is the C++ node.
    # FIX 9: exact suffix match on target terminal component.
    # Single pass over edges (iterable may be a streaming LazyGVL).
    for e in (gvl.get("edges") or []):
        expr = _safe_str(e.get("expression"))
        if "cpp_field_to_asm" not in expr:
            continue
        tgt_raw = _safe_str(e.get("target"))
        tgt_terminal = tgt_raw.split(":")[-1].upper()
        if tgt_terminal != var_upper:
            continue
        _add(_safe_str(e.get("source")))

    # Strategy 4: TPF_regs cpp_sources (no GVL access — pre-computed dict)
    for slot_data in tpf_regs_slots.values():
        for src in (slot_data.get("cpp_sources") or []):
            _add(str(src))

    # Strategy 6 (P41): REGNA region name → CE1USA node lookup.
    # EB0USER–EB7USER are REGNA-declared 64-byte sub-regions of the CE1USA ECB
    # field.  C++ accesses the same bytes via ecbptr()->ce1usa (possibly with a
    # byte offset), so the GVL node will carry the name "ce1usa", not "eb0user".
    # When Strategies 1-5 found nothing and the variable is an EBnUSER name,
    # fall back to searching for the ce1usa node so the backward trace has a
    # starting point in the C++ GVL.
    if not seeds and var_upper in _REGNA_REGION_NAMES:
        for n in (gvl.get("nodes") or []):
            nid = _safe_str(n.get("id")).lower()
            nname = _safe_str(n.get("name")).lower()
            if (nname == _REGNA_CE1USA_ALIAS
                    or nid == _REGNA_CE1USA_ALIAS
                    or nid.endswith(f"::{_REGNA_CE1USA_ALIAS}")
                    or nid.endswith(f":{_REGNA_CE1USA_ALIAS}")
                    or nid.endswith(f"->{_REGNA_CE1USA_ALIAS}")):
                sid = _safe_str(n.get("id") or n.get("name") or "").strip()
                if sid:
                    _add(sid)

    # Strategy 7 (P28): @MMU-prefixed global storage variables (GLOBZ / TPFGLB).
    # GLOBZ declares a base register over the z/TPF global storage area; DSECT symbols
    # within the COPY TPFGLB source have names beginning with "@MMU" (e.g. @MMUFOO).
    # In C++ the same field is accessed as tpfglbl.mmufoo (without the "@" prefix).
    # Strategy 5 won't match because the GVL node name is "mmufoo" while the ASM
    # variable is "@MMUFOO".  When Strategies 1-6 all fail and the name starts with "@",
    # try matching GVL nodes by the name with the leading "@" stripped (length ≥ 4 to
    # avoid spurious matches on very short tokens like "@X").
    if not seeds and var_upper.startswith("@"):
        stripped_lower = var_lower.lstrip("@")
        if len(stripped_lower) >= 4:
            for n in (gvl.get("nodes") or []):
                nid = _safe_str(n.get("id")).lower()
                nname = _safe_str(n.get("name")).lower()
                if (nname == stripped_lower
                        or nid == stripped_lower
                        or nid.endswith(f"::{stripped_lower}")
                        or nid.endswith(f":{stripped_lower}")
                        or nid.endswith(f"->{stripped_lower}")):
                    sid = _safe_str(n.get("id") or n.get("name") or "").strip()
                    if sid:
                        _add(sid)

    # Strategy 8 (P29): ALASW DSECT/struct name → ce1alasw ECB pointer node.
    # When the variable is "ALASW" or "CE1ALASW" (the DSECT name itself, not an
    # individual field within it), Strategies 1–7 typically find no seed because the
    # GVL has a node for the ECB pointer field "ce1alasw" rather than for the struct
    # type "Alasw".  Fall back to searching for ce1alasw nodes so the backward trace
    # reaches the ECB pointer field from which all ALASW field accesses originate.
    if not seeds and var_upper in _ALASW_DSECT_NAMES:
        for n in (gvl.get("nodes") or []):
            nid = _safe_str(n.get("id")).lower()
            nname = _safe_str(n.get("name")).lower()
            if (nname == _ALASW_ECB_POINTER
                    or nid == _ALASW_ECB_POINTER
                    or nid.endswith(f"::{_ALASW_ECB_POINTER}")
                    or nid.endswith(f":{_ALASW_ECB_POINTER}")
                    or nid.endswith(f"->{_ALASW_ECB_POINTER}")):
                sid = _safe_str(n.get("id") or n.get("name") or "").strip()
                if sid:
                    _add(sid)

    # C2.1 fix: warn when all strategies fail so the empty trace is not silent.
    if not seeds:
        import logging as _logging
        _logging.getLogger(__name__).warning(
            "find_cpp_seed_nodes: no seed nodes found for '%s' after all 8 strategies — "
            "C++ backward BFS will be empty. Verify that the GVL contains nodes with "
            "asm_alias, cpp_field_to_asm edges, or a direct name/id match for this variable.",
            var_upper,
        )
    return seeds



def build_chain_neighbor_set(
    selected_chain: List[str],
    call_graph_path: Path,
    max_hops: int = 2,
) -> Set[str]:
    """Return all file stems reachable within *max_hops* of any stem in
    *selected_chain* via the ``file_call_graph``.

    Used by T9 to bound the T8 candidate scan to files that are actually nearby
    in the call graph, limiting I/O to O(30) typical neighbours instead of
    O(N_cpp_files) at a 10K-file codebase.

    The graph is treated as **undirected** for reachability — a stem is included
    whether it calls a chain file or is called by one.

    Fallback: if *call_graph_path* does not exist or cannot be read, returns
    ``set(selected_chain)`` (no filtering beyond the chain itself).  This is
    safe — T8 then operates only on chain files, which already have blueprints
    loaded.

    Memory: streams the "edges" array from ``file_call_graph.json`` one item at
    a time via ``stream_json_array`` so that the full 100–200 MB file is never
    held in RAM as a Python dict.
    """
    if not call_graph_path or not call_graph_path.exists():
        return set(selected_chain)

    # Build adjacency index: stem → {neighbour stems} (undirected).
    # Stream edges rather than loading the whole file (can be 100–200 MB).
    adjacency: Dict[str, Set[str]] = {}
    try:
        from backward_traversal.utils.stream_json import stream_json_array
        for edge in stream_json_array(str(call_graph_path), "edges"):
            src = str(edge.get("source", "") or "").strip()
            tgt = str(edge.get("target", "") or "").strip()
            if src and tgt:
                adjacency.setdefault(src, set()).add(tgt)
                adjacency.setdefault(tgt, set()).add(src)
    except Exception:
        return set(selected_chain)   # fallback: no graph-distance filtering

    # Multi-source BFS: seed from all chain stems simultaneously
    visited: Set[str] = set(selected_chain)
    frontier: Set[str] = set(selected_chain)
    for _ in range(max_hops):
        next_frontier: Set[str] = set()
        for stem in frontier:
            for neighbour in adjacency.get(stem, set()):
                if neighbour not in visited:
                    visited.add(neighbour)
                    next_frontier.add(neighbour)
        frontier = next_frontier
        if not frontier:
            break

    return visited


def find_cpp_files_for_dep_var(
    dep_var: str,
    blueprint_dir: Path,
    file_type_map: Dict[str, str],
    max_scan: int = 0,
    neighbor_set: Optional[Set[str]] = None,
) -> List[str]:
    """Scan C++ blueprints outside the selected chain for *dep_var* seeds.

    Returns a list of file stems whose GVL contains at least one seed node for
    *dep_var* (Strategy 1–5 via ``find_cpp_seed_nodes``).

    **PRODUCTION WARNING:** ``max_scan > 0`` without ``neighbor_set`` filtering
    causes O(max_dep_vars × max_scan) blueprint reads per call.  At 10K+ files
    with ``max_scan=50``: ~27GB disk I/O — do **not** enable without T9.
    Use ``build_chain_neighbor_set()`` to build *neighbor_set* before the dep_var
    BFS loop and pass it here.

    Parameters
    ----------
    dep_var:
        Normalized C++ field name (FIX 11/21 stripped).
    blueprint_dir:
        Directory containing ``*.cpp.json`` blueprints.
    file_type_map:
        ``{stem: "cpp" | "asm"}`` mapping from the call graph payload.
    max_scan:
        Maximum number of C++ blueprints to inspect.  Default **0** (disabled).
        FIX 18: do not raise above 0 without either (a) a small codebase (≤500
        C++ files) or (b) *neighbor_set* built via ``build_chain_neighbor_set()``.
    neighbor_set:
        When provided (T9), only candidates inside this set are scanned.
        Limits inspection to ≤ ``max_hops``-hop neighbours of the selected chain
        — typically 5–30 files — regardless of *max_scan*.
    """
    if max_scan <= 0:
        return []

    # ── DB fast path: skip blueprint loading entirely ──────────────────────
    try:
        from api.index_db.readers import get_cpp_seed_candidate_files
        from api.index_db.engine import job_id_from_path
        _job_id = job_id_from_path(blueprint_dir)
        if _job_id:
            db_stems = get_cpp_seed_candidate_files(
                _job_id, dep_var,
                neighbor_set=neighbor_set,
                limit=max_scan,
            )
            if db_stems is not None:  # None = index unavailable
                cpp_set = {s for s, t in file_type_map.items() if t == "cpp"}
                db_stems = [s for s in db_stems if s in cpp_set]
                return db_stems
    except Exception:
        pass  # fall through to scan

    # ── Original blueprint-scanning logic (fallback) ───────────────────────
    from backward_traversal.utils.blueprint_utils import load_json, resolve_cpp_blueprint

    candidates = [s for s, t in file_type_map.items() if t == "cpp"]
    if neighbor_set is not None:
        candidates = [s for s in candidates if s in neighbor_set]
    candidates = sorted(candidates)[:max_scan]

    found: List[str] = []
    # Local cache: same (gvl instance, dep_var) pair scanned at most once.
    _local_seed_cache: Dict[tuple, list] = {}
    for stem in candidates:
        bp_path = resolve_cpp_blueprint(stem, blueprint_dir)
        if not bp_path:
            continue
        try:
            bp = load_json(bp_path)   # hits FIX 5 LRU cache
        except Exception:
            continue
        from backward_traversal.utils.lazy_gvl import make_lazy_gvl
        gvl = make_lazy_gvl(bp, bp_path)
        _ck = (id(gvl), dep_var.lower())
        if _ck in _local_seed_cache:
            seeds = _local_seed_cache[_ck]
        else:
            seeds = find_cpp_seed_nodes(gvl, dep_var, {}, {})
            _local_seed_cache[_ck] = seeds
        if seeds:
            found.append(stem)

    return found
