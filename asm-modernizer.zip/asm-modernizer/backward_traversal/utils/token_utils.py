"""Token normalization and dependent-variable filtering for backward-only mode."""

from __future__ import annotations

import re
from typing import Iterable, List, Optional, Set

from backward_traversal.glossary.instructions import REGISTERS


# HLASM attribute references (L'sym, K'sym, ...): a single UNPAIRED apostrophe that,
# unlike a literal delimiter (C'ab', X'FF'), never closes. Any quote-aware scan over
# HLASM operand text must skip it or it sticks "inside a string" for the rest of the
# line (same rule as vbt.conditions.asm_conditions._operand_head).
ATTRIBUTE_LETTERS = "LKDINOST"


def split_asm_operands(s: str, *, on_whitespace: bool = False) -> List[str]:
    """Split an HLASM operand string on TOP-LEVEL separators only.

    A comma inside parentheses is part of ONE operand — base-displacement
    ``9(4,R5)``, execute/index forms ``0(R6,R7)`` — as is anything inside a
    quoted literal (``C'a,b'``). A naive ``split(",")`` shears those into
    fragments (``9(4`` / ``R5)``) whose normalized tails then leak as fake
    dependent variables (the base register ``RGC`` out of ``9(4,RGC)``).

    ``on_whitespace=True`` additionally splits on top-level blanks (the
    dep-var harvesting contract, which historically split on ``[,\\s]+``);
    whitespace runs are collapsed, while comma positions are preserved
    (``A,,B`` keeps its empty slot — positional operands like the TM mask
    depend on it). Quote handling skips unpaired attribute-reference
    apostrophes (see ATTRIBUTE_LETTERS); a degenerate unterminated quote
    stops splitting for the rest of the string — the safe direction.
    """
    out: List[str] = []
    buf: List[str] = []
    depth = 0
    in_q = False
    for i, ch in enumerate(s):
        if ch == "'":
            if not (not in_q and i > 0 and s[i - 1] in ATTRIBUTE_LETTERS
                    and not (i >= 2 and (s[i - 2].isalnum() or s[i - 2] in "@#$_"))):
                in_q = not in_q
        elif not in_q:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth = max(0, depth - 1)
            elif depth == 0 and ch == ",":
                out.append("".join(buf))
                buf = []
                continue
            elif depth == 0 and on_whitespace and ch.isspace():
                if buf:
                    out.append("".join(buf))
                    buf = []
                continue
        buf.append(ch)
    if buf or not on_whitespace:
        out.append("".join(buf))
    return out


def normalize_token(token: str) -> str:
    token = token.strip().split()[0].upper() if token.strip() else ""
    if re.match(r"^[A-Z0-9#$@_]", token):
        token = re.split(r"[+(]", token, maxsplit=1)[0]
    # GAP-024: include $ in the allowed boundary characters so HLASM variable names
    # that begin or end with $ (e.g. $WK_CMO, WK_CMO$) are not silently truncated.
    token = re.sub(r"^[^A-Z0-9_@$#]+|[^A-Z0-9_@$#]+$", "", token)
    return token


def looks_like_register_token(tok: str) -> bool:
    u = tok.upper()
    if u in REGISTERS:
        return True
    # GAP-023: removed R[A-Z] pattern — names like RB, RC, RA, RACK, RATE etc. are
    # valid HLASM variable names, not registers.  Only Rnn (numeric suffix) forms
    # with n > 15 are legitimately "register-like" out-of-range values.
    m = re.match(r"^R(\d+)$", u)
    return bool(m) and int(m.group(1)) > 15


def is_dep_var_candidate(
    raw_arg: str,
    skip_var: str = "",
    constant_symbols: Optional[Set[str]] = None,
) -> bool:
    raw = str(raw_arg or "")
    if raw.startswith("="):
        return False
    # Reject self-defining literals from raw operand text before normalization
    # so tokens like "C' '" do not collapse to "C" and leak as dep-vars.
    if "'" in raw:
        return False

    paren = re.search(r"\(([^,)]+)", raw.upper())
    if paren and looks_like_register_token(paren.group(1).strip()):
        # Fix #2 (audit §5/§3e): reject only when the pre-paren portion is NOT a
        # valid HLASM symbol.  USING-based forms SYMBOL(Rn) and SYMBOL+d(Rn) carry a
        # real storage label before the base register (normalize_token strips the
        # paren suffix correctly).  Pure displacement forms like 4(R3), 0(R13),
        # (R13), R13(R13) have no label and must still be rejected.
        _before = re.split(r"[+\(]", raw.upper(), maxsplit=1)[0]
        _is_symbol = (
            bool(_before)
            and not _before.isdigit()
            and not looks_like_register_token(_before)
            and bool(re.match(r"^[A-Z@$_#]", _before))
        )
        if not _is_symbol:
            return False
        # _is_symbol True: fall through to the normalize_token path below.

    tok = normalize_token(raw)
    if not tok:
        return False
    if looks_like_register_token(tok):
        return False
    if "'" in tok:
        return False
    if tok.isdigit():
        return False
    if "#" in tok:
        return False
    if not re.match(r"^[A-Z@$_][A-Z0-9@$_]*$", tok):
        return False
    if skip_var and tok == skip_var.upper():
        return False
    if constant_symbols and tok in constant_symbols:
        return False
    return True


def looks_like_equ_constant(tok: str) -> bool:
    """Heuristic: True for tokens that look like EQU constants from COPY members.

    COPY members may define EQU symbols that are absent from the blueprint's
    constant_symbols set.  When used as the source operand for IMMEDIATE_OPERAND_SETTER_INST
    instructions, these should be flagged as constant_source.

    Matches:
      - Tokens starting with '#' (e.g. #ACPDBOK, #C400)
      - Tokens containing '#' (e.g. LG#C400)
      - Single hex-digit tokens (A–F standing alone, unlikely variable names)
    """
    if not tok:
        return False
    u = tok.strip().upper()
    if not u:
        return False
    if u.startswith("#") or "#" in u:
        return True
    # Single hex-digit letter (A–F) used as an EQU constant name
    if len(u) == 1 and u in "ABCDEF":
        return True
    return False


def dep_vars_from_args(
    args: Iterable[str],
    skip_var: str = "",
    constant_symbols: Optional[Set[str]] = None,
) -> List[str]:
    out: List[str] = []
    seen: Set[str] = set()
    for arg in args:
        if not is_dep_var_candidate(
            str(arg),
            skip_var=skip_var,
            constant_symbols=constant_symbols,
        ):
            continue
        tok = normalize_token(str(arg))
        if not tok or tok in seen:
            continue
        seen.add(tok)
        out.append(tok)
    return out
