"""
counterpart_resolver.py

Global ASM<->CPP variable counterpart resolver.

Given a variable name and its language ("asm" or "cpp"), returns ranked
CounterpartCandidate objects in the OTHER language, sourced from the
field_asm_aliases tables embedded in every *.cpp.json blueprint.

Certainty signal: the naming convention cc<stem>.hpp <-> <stem>.mac means
that when the cc-header that provided a mapping has a base-name whose ASM
source file exists in the KB, the mapping is "high" confidence.  Otherwise
confidence falls to "medium" (cc-header present but no matching ASM source)
or "low" (other mapping types).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class CounterpartCandidate:
    counterpart_name: str          # ASM_VAR (upper) or "Struct.field" cpp form
    counterpart_language: str      # "asm" | "cpp"  — always != input language
    home_stem: str                 # blueprint stem where the counterpart lives
    cc_header: str                 # cc-header basename that supplied the mapping
    cpp_field: Optional[str]       # qualified "Struct.field" (present for both directions)
    mapping_via: str               # "cc_hpp_comment" | "ecb_control_block" | "glob_runtime"
    certainty: float               # 0.0–1.0
    certainty_label: str           # "high" | "medium" | "low"
    confidence_strategy: str       # "naming_convention" | "cc_hpp_comment" | …


@dataclass
class _CcAliasIndex:
    # cpp_stem -> { "Struct.field": "ASM_VAR" }
    by_cpp_stem: Dict[str, Dict[str, str]] = field(default_factory=dict)
    # cpp_stem -> { "Struct.field": "ccXXXX.hpp" }
    sources_by_cpp_stem: Dict[str, Dict[str, str]] = field(default_factory=dict)
    # ASM_VAR_UPPER -> [(cpp_stem, "Struct.field", "ccXXXX.hpp"), ...]
    asm_to_cpp: Dict[str, List[Tuple[str, str, str]]] = field(default_factory=dict)
    # lowercased stems that exist as ASM blueprints
    asm_stems_present: Set[str] = field(default_factory=set)


# Module-level cache: (blueprint_dir_str, graph_file_str) -> _CcAliasIndex
_INDEX_CACHE: Dict[Tuple[str, str], _CcAliasIndex] = {}

# Certainty ranking for sorting
_CERTAINTY_RANK = {"high": 3, "medium": 2, "low": 1}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _cc_stem_to_mac_stem(cc_header: str) -> str:
    """Strip leading 'cc' and '.hpp' suffix.  ccda7gl.hpp -> da7gl."""
    name = Path(cc_header).stem        # removes .hpp
    if name.lower().startswith("cc"):
        return name[2:]
    return name


def _certainty_for_cc_header(
    cc_header: str,
    asm_stems_present: Set[str],
) -> Tuple[float, str, str]:
    """(certainty_float, certainty_label, confidence_strategy) for a cc-header."""
    if not cc_header:
        return 0.40, "low", "unknown_source"
    mac_stem = _cc_stem_to_mac_stem(cc_header).lower()
    if mac_stem in asm_stems_present:
        return 0.95, "high", "naming_convention"
    return 0.65, "medium", "cc_hpp_comment"


# ---------------------------------------------------------------------------
# Index builder
# ---------------------------------------------------------------------------

def build_cc_alias_index(blueprint_dir: Path, graph_file: Path) -> _CcAliasIndex:
    """Build (or return cached) global ASM<->CPP alias index for this KB.

    Reads field_asm_aliases / field_asm_alias_sources from every *.cpp.json
    blueprint and compiles forward + reverse mapping tables.  Module-level
    cache keyed by (blueprint_dir, graph_file) — blueprints are read-only
    during a run so the cache is never stale.
    """
    key = (str(blueprint_dir.resolve()), str(graph_file.resolve()))
    if key in _INDEX_CACHE:
        return _INDEX_CACHE[key]

    from backward_traversal.utils.blueprint_utils import load_json
    from backward_traversal.utils.cpp_lineage_utils import reverse_field_alias_map

    idx = _CcAliasIndex()

    # Build asm_stems_present from the call-graph node list
    try:
        graph_payload = load_json(graph_file)
        for node in graph_payload.get("nodes", []):
            nid = str(node.get("id") or "").lower().strip()
            ntype = str(node.get("type") or "").lower()
            if ntype == "asm" and nid:
                idx.asm_stems_present.add(nid)
    except Exception as exc:
        logger.warning("build_cc_alias_index: could not read graph_file %s: %s", graph_file, exc)

    # Also collect from *.asm.json / *.mac.json files on disk (belt-and-suspenders)
    for bp_path in blueprint_dir.glob("*.asm.json"):
        # "da78.asm.json" -> stem "da78.asm" -> removesuffix(".asm") -> "da78"
        idx.asm_stems_present.add(bp_path.name.removesuffix(".asm.json").lower())
    for bp_path in blueprint_dir.glob("*.mac.json"):
        idx.asm_stems_present.add(bp_path.name.removesuffix(".mac.json").lower())

    # Walk all cpp blueprints and collect field_asm_aliases
    for bp_path in sorted(blueprint_dir.glob("*.cpp.json")):
        cpp_stem = bp_path.name.removesuffix(".cpp.json")
        try:
            bp = load_json(bp_path)
        except Exception as exc:
            logger.debug("build_cc_alias_index: skipping %s: %s", bp_path, exc)
            continue

        aliases: Dict[str, str] = bp.get("field_asm_aliases") or {}
        sources: Dict[str, str] = bp.get("field_asm_alias_sources") or {}

        if not aliases:
            continue

        idx.by_cpp_stem[cpp_stem] = dict(aliases)
        idx.sources_by_cpp_stem[cpp_stem] = dict(sources)

        # Populate reverse map: ASM_VAR_UPPER -> [(cpp_stem, cpp_field, cc_header)]
        rev = reverse_field_alias_map(bp)
        for asm_name_upper, cpp_fields in rev.items():
            if not asm_name_upper:
                continue
            entry_list = idx.asm_to_cpp.setdefault(asm_name_upper, [])
            for cpp_field in cpp_fields:
                cc_header = sources.get(cpp_field, "")
                triple = (cpp_stem, cpp_field, cc_header)
                if triple not in entry_list:
                    entry_list.append(triple)

    _INDEX_CACHE[key] = idx
    return idx


def invalidate_index_cache() -> None:
    """Clear the module-level index cache (useful in tests / after re-parsing)."""
    _INDEX_CACHE.clear()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def resolve_counterpart(
    variable: str,
    language: str,
    blueprint_dir: Path,
    graph_file: Path,
    home_stem: Optional[str] = None,
) -> List[CounterpartCandidate]:
    """Return ranked counterpart candidates in the OTHER language.

    Parameters
    ----------
    variable:
        Variable name. For ASM: uppercase name (e.g. "LG1OSI").
        For CPP: bare field name or qualified "Struct.field" form.
    language:
        "asm" | "cpp" — the language of *variable*.
    blueprint_dir:
        Directory containing *.cpp.json / *.asm.json blueprints.
    graph_file:
        Path to file_call_graph.json.
    home_stem:
        The file stem where *variable* lives (scoping hint for CPP->ASM).

    Returns
    -------
    List of CounterpartCandidate, sorted best-first (highest certainty, then
    lexicographic home_stem for determinism).  Empty list if no mapping found.
    """
    language = str(language or "").lower().strip()
    if language not in ("asm", "cpp"):
        logger.warning("resolve_counterpart: unknown language %r, treating as asm", language)
        language = "asm"

    idx = build_cc_alias_index(blueprint_dir, graph_file)

    if language == "asm":
        candidates = _resolve_asm_to_cpp(variable, idx)
    else:
        candidates = _resolve_cpp_to_asm(variable, idx, home_stem)

    # Language guard: only keep candidates in the OTHER language
    target_lang = "cpp" if language == "asm" else "asm"
    candidates = [c for c in candidates if c.counterpart_language == target_lang]

    # Sort: highest certainty first, then home_stem lexicographically for determinism
    candidates.sort(
        key=lambda c: (-_CERTAINTY_RANK.get(c.certainty_label, 0), c.home_stem),
    )

    return candidates


# ---------------------------------------------------------------------------
# Direction implementations
# ---------------------------------------------------------------------------

def _resolve_asm_to_cpp(variable: str, idx: _CcAliasIndex) -> List[CounterpartCandidate]:
    """Return CPP candidates for an ASM variable (via global reverse map)."""
    var_upper = str(variable or "").upper().strip()
    if not var_upper:
        return []

    raw_entries = idx.asm_to_cpp.get(var_upper, [])
    if not raw_entries:
        return []

    candidates: List[CounterpartCandidate] = []
    for cpp_stem, cpp_field, cc_header in raw_entries:
        certainty, certainty_label, confidence_strategy = _certainty_for_cc_header(
            cc_header, idx.asm_stems_present
        )
        candidates.append(CounterpartCandidate(
            counterpart_name=cpp_field,          # qualified "Struct.field"
            counterpart_language="cpp",
            home_stem=cpp_stem,
            cc_header=cc_header,
            cpp_field=cpp_field,
            mapping_via="cc_hpp_comment",
            certainty=certainty,
            certainty_label=certainty_label,
            confidence_strategy=confidence_strategy,
        ))

    return candidates


def _resolve_cpp_to_asm(
    variable: str,
    idx: _CcAliasIndex,
    home_stem: Optional[str],
) -> List[CounterpartCandidate]:
    """Return ASM candidates for a CPP variable.

    variable may be a bare field name ("onlineSrcInd") or qualified
    ("CasGLRec.onlineSrcInd"). Matching is case-insensitive on the field tail.
    """
    query = str(variable or "").strip()
    needle = query.split(".")[-1].lower()
    if not needle:
        return []

    candidates: List[CounterpartCandidate] = []
    seen: Set[Tuple[str, str]] = set()

    # Try home_stem first (priority), then all others
    stems_ordered: List[str] = []
    if home_stem and home_stem in idx.by_cpp_stem:
        stems_ordered.append(home_stem)
    for s in sorted(idx.by_cpp_stem.keys()):
        if s not in stems_ordered:
            stems_ordered.append(s)

    for cpp_stem in stems_ordered:
        aliases = idx.by_cpp_stem.get(cpp_stem, {})
        sources = idx.sources_by_cpp_stem.get(cpp_stem, {})

        for cpp_field, asm_name in aliases.items():
            field_part = cpp_field.split(".", 1)[-1].lower()
            if field_part != needle and cpp_field.lower() != query.lower():
                continue

            asm_upper = str(asm_name).upper()
            dedup_key = (asm_upper, cpp_stem)
            if dedup_key in seen:
                continue
            seen.add(dedup_key)

            cc_header = sources.get(cpp_field, "")
            certainty, certainty_label, confidence_strategy = _certainty_for_cc_header(
                cc_header, idx.asm_stems_present
            )

            # home_stem hint for the ASM counterpart: derive from cc-header convention
            asm_home = _cc_stem_to_mac_stem(cc_header).lower() if cc_header else cpp_stem

            candidates.append(CounterpartCandidate(
                counterpart_name=asm_upper,
                counterpart_language="asm",
                home_stem=asm_home,
                cc_header=cc_header,
                cpp_field=cpp_field,
                mapping_via="cc_hpp_comment",
                certainty=certainty,
                certainty_label=certainty_label,
                confidence_strategy=confidence_strategy,
            ))

    return candidates
