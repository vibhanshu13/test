"""Filesystem and blueprint helpers for backward-only mode."""

from __future__ import annotations

import json
import os
import re
import time
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from backward_traversal.glossary.instructions import HLASM_BUILTIN_SYMBOLS

try:
    from blueprint_io import iter_flow
except ImportError:
    import sys as _sys
    import os as _os
    _sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.dirname(__file__))))
    from blueprint_io import iter_flow


def discover_blueprint_dir() -> Optional[Path]:
    cwd = Path.cwd()
    for candidate in [
        cwd / "temp" / "output_latest" / "asm",
        cwd / "output" / "asm",
        cwd / "temp" / "parser_run",
    ]:
        if candidate.exists() and (list(candidate.glob("*.cpp.json")) or list(candidate.glob("*.asm.json"))):
            return candidate
    return None


def discover_asm_dir(blueprint_dir: Path) -> Optional[Path]:
    for candidate in [
        blueprint_dir.parent.parent / "asm",
        blueprint_dir.parent / "asm",
        blueprint_dir,
    ]:
        if candidate.exists() and (list(candidate.glob("*.asm")) or list(candidate.glob("*.cpp"))):
            return candidate
    return None


def discover_graph_file(blueprint_dir: Optional[Path]) -> Optional[Path]:
    candidates: List[Path] = []
    if blueprint_dir:
        candidates += [
            blueprint_dir / "file_call_graph.json",
            blueprint_dir.parent / "file_call_graph.json",
        ]
    cwd = Path.cwd()
    candidates += [
        cwd / "temp" / "output_latest" / "file_call_graph.json",
        cwd / "output" / "file_call_graph.json",
        cwd / "file_call_graph.json",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def _read_text_with_retry(
    path: Path,
    *,
    encoding: str = "utf-8",
    errors: Optional[str] = None,
    attempts: int = 5,
    sleep_seconds: float = 0.2,
) -> str:
    """Read file text with retry for transient filesystem timeouts.

    T12: when a VBT source override is installed (index.db-backed), serve the bytes from it
    instead of disk — replicating ``read_text``'s universal-newline translation so every caller
    (raw-line fetch, constant scan, block-source slicing) is byte-identical to the disk read.
    """
    ov = source_override_bytes(path)
    if ov is not None:
        text = ov.decode(encoding) if errors is None else ov.decode(encoding, errors)
        return text.replace("\r\n", "\n").replace("\r", "\n")
    last_exc: Optional[Exception] = None
    for i in range(max(1, attempts)):
        try:
            if errors is None:
                return path.read_text(encoding=encoding)
            return path.read_text(encoding=encoding, errors=errors)
        except (TimeoutError, OSError) as exc:
            last_exc = exc
            if i >= attempts - 1:
                break
            time.sleep(sleep_seconds * (i + 1))
    if last_exc is not None:
        raise last_exc
    raise RuntimeError(f"Failed to read file: {path}")


_BP_CACHE_SIZE_ENV = "ASM_BP_CACHE_SIZE"
_BP_CACHE_RAM_MB_ENV = "ASM_BP_CACHE_RAM_MB"
# Decoded (in-RAM) size per blueprint. The previous 15 MB was ~3-4x the MEASURED in-RAM size of a
# typical blueprint (corpus avg ≈ 4 MB; parsed/disk expansion 3-46x measured), so the default cache
# held only ~68 slots and used ~270 MB of its 1 GB budget while THRASHING (re-parsing a blueprint on
# every caller-walk node when the working set exceeds 68 — the dominant cost of building a hub setter's
# multi-thousand-node caller forest at 22k scale). Right-sizing the estimate uses the budget that was
# being wasted: ~256 slots at the default 1 GB, with RAM still bounded by the budget. For a 22k corpus
# whose forest working set is larger, RAISE the budget: ASM_BP_CACHE_RAM_MB=4096 → ~1024 slots.
_BP_ESTIMATED_SIZE_MB = 4


def _compute_cache_maxsize() -> int:
    """Compute LRU cache maxsize from environment.

    Priority:
    1. ``ASM_BP_CACHE_SIZE`` — explicit slot count (backwards compatible).
    2. ``ASM_BP_CACHE_RAM_MB`` — RAM budget in MB; slots = budget // 4 MB (measured per-bp in-RAM size).
    3. Default 1 GB budget → ~256 slots (uses the budget instead of wasting it; bounds cache RAM ≈ 1 GB).

    Worst-case cache RAM stays at the configurable ceiling (default 1 GB). On a 22k codebase whose hub
    setters have large caller forests, bump ``ASM_BP_CACHE_RAM_MB`` (e.g. 4096 → ~1024 slots) to hold the
    forest's blueprint working set and avoid per-node re-parse thrash.
    """
    if _BP_CACHE_SIZE_ENV in os.environ:
        return max(1, int(os.environ[_BP_CACHE_SIZE_ENV]))
    budget_mb = int(os.environ.get(_BP_CACHE_RAM_MB_ENV, "1024"))
    return max(8, budget_mb // _BP_ESTIMATED_SIZE_MB)


def _make_bp_cache():
    """Build the LRU-cached blueprint loader.

    Cache size defaults to a 1 GB RAM budget (~256 blueprints) and is
    configurable via environment variables::

        ASM_BP_CACHE_RAM_MB=4096  # 4 GB → ~1024 slots (recommended for 22k hub setters)
        ASM_BP_CACHE_SIZE=256     # explicit slot count (overrides budget)
    """
    maxsize = _compute_cache_maxsize()

    @lru_cache(maxsize=maxsize)
    def _load_json_cached(path_str: str) -> Dict[str, Any]:
        path = Path(path_str)
        try:
            from blueprint_io import load_blueprint
            # PERF-001 (extended): skip global_variable_lineage injection for ALL
            # blueprints.  On large codebases global_variable_lineage.json can be
            # 3–4 GB; loading it as a Python dict allocates 10–15 GB and OOMs
            # containers.  The backward traversal now uses LazyGVL (lazy streaming)
            # instead of holding the whole graph in RAM.  The GVL file path is
            # stored at bp["_gvl_path"] so callers can build a LazyGVL on demand.
            bp = load_blueprint(path, skip_global_lineage=True)
        except ImportError:
            bp = json.loads(_read_text_with_retry(path, encoding="utf-8"))

        # Inject the GVL file path for lazy consumers (LazyGVL / make_lazy_gvl).
        # Only search when the key is absent so the dict is mutated at most once.
        if "_gvl_path" not in bp:
            from backward_traversal.utils.lazy_gvl import find_gvl_path, find_gvl_db_path
            _gp = find_gvl_path(path)
            if _gp is not None:
                bp["_gvl_path"] = str(_gp)
            else:
                # GVL file missing — fall back to index.db if available.
                _db_result = find_gvl_db_path(path)
                if _db_result is not None:
                    _db_path, _job_id = _db_result
                    bp["_gvl_db_path"] = str(_db_path)
                    bp["_gvl_job_id"] = _job_id

        return bp

    return _load_json_cached


_load_json_cached = _make_bp_cache()

# VBT DB-backed precompute (DB_PRECOMPUTE_PLAN.md T7): an optional, decoupled override that
# lets a caller serve a blueprint dict from elsewhere (e.g. index.db) instead of disk. ``None``
# by default → ZERO effect on the legacy path. The callback receives the path string and
# returns a dict to use, or ``None`` to fall through to the normal LRU/disk load. Decoupled via
# a callback so this shared util imports neither vbt/ nor api.index_db.
_BP_OVERRIDE = None  # type: Optional[Any]


def set_blueprint_override(fn) -> None:
    """Install a ``fn(path_str) -> Optional[dict]`` consulted by ``load_json`` before disk."""
    global _BP_OVERRIDE
    _BP_OVERRIDE = fn


def clear_blueprint_override() -> None:
    global _BP_OVERRIDE
    _BP_OVERRIDE = None


# VBT DB-backed source text (DB_PRECOMPUTE_PLAN.md T9): an optional, decoupled override that
# serves a source file's RAW BYTES from elsewhere (e.g. index.db) instead of disk. ``None`` by
# default → ZERO effect. ``fn(path_str) -> Optional[bytes]``; returns ``None`` to let the caller
# run its own (unchanged) read. Raw bytes so each consumer applies ITS current decode (text
# slicers) or uses the bytes directly (tree-sitter), keeping output byte-identical.
_SOURCE_OVERRIDE = None  # type: Optional[Any]


def set_source_override(fn) -> None:
    global _SOURCE_OVERRIDE
    _SOURCE_OVERRIDE = fn


def clear_source_override() -> None:
    global _SOURCE_OVERRIDE
    _SOURCE_OVERRIDE = None


def source_override_bytes(path) -> "Optional[bytes]":
    """Raw bytes for ``path`` from the installed source override, or ``None`` (no override /
    miss / error) so the caller falls back to its own disk read."""
    if _SOURCE_OVERRIDE is None:
        return None
    try:
        return _SOURCE_OVERRIDE(str(path))
    except Exception:
        return None


def load_json(path: Path) -> Dict[str, Any]:
    """Load a JSON blueprint, caching the result by absolute path.

    The cache size defaults to 1024 and is configurable via the
    ASM_BP_CACHE_SIZE environment variable (read once at module import time).
    Blueprints are read-only during a run, so the cache is never stale.

    A VBT-installed override (``set_blueprint_override``) is consulted first; when it returns a
    dict that dict is used as-is, otherwise the normal LRU/disk load runs (unchanged).
    """
    if _BP_OVERRIDE is not None:
        try:
            d = _BP_OVERRIDE(str(path))
            if d is not None:
                return d
        except Exception:
            pass
    return _load_json_cached(str(path))


def get_blueprint_cache_info() -> Optional[object]:
    """Return the lru_cache statistics object for the blueprint loader (GAP-011).

    Callers can inspect ``.hits``, ``.misses``, ``.currsize``, and ``.maxsize``
    to detect cache pressure and emit an operational warning.  Returns ``None``
    when the cache is unavailable (should not happen in normal operation).
    """
    try:
        return _load_json_cached.cache_info()
    except Exception:
        return None


def clear_blueprint_cache() -> None:
    """Clear the LRU blueprint cache to release memory between phases.

    Call this after Pass 1a (extend_modifier_sites scan) completes so that
    blueprints loaded only for the lightweight setter-site scan are evicted
    before Pass 1b / Pass 2, freeing up to ``maxsize × 15 MB`` of RAM.
    """
    try:
        _load_json_cached.cache_clear()
    except Exception:
        pass


def clear_constant_symbols_cache() -> None:
    """Clear the constant-symbols cache to release memory between BFS batches.

    The ``_constant_symbols_cache`` dict grows unbounded as files are scanned.
    Clearing it between batches keeps peak RAM proportional to batch size
    rather than total visited files.
    """
    _constant_symbols_cache.clear()


@lru_cache(maxsize=2048)
def resolve_asm_blueprint(stem: str, blueprint_dir: Path) -> Optional[Path]:
    stem = str(stem).strip()
    for p in [
        blueprint_dir / f"{stem}.asm.json",
        blueprint_dir / f"{stem.lower()}.asm.json",
        blueprint_dir / f"{stem}.mac.json",
        blueprint_dir / f"{stem.lower()}.mac.json",
    ]:
        if p.exists():
            return p
    return None


@lru_cache(maxsize=2048)
def resolve_cpp_blueprint(stem: str, blueprint_dir: Path) -> Optional[Path]:
    stem = str(stem).strip()
    for p in [blueprint_dir / f"{stem}.cpp.json", blueprint_dir / f"{stem.lower()}.cpp.json"]:
        if p.exists():
            return p
    return None


def resolve_file_type(stem: str, blueprint_dir: Path, file_type_map: Dict[str, str]) -> str:
    stem_norm = str(stem).strip()
    stem_lower = stem_norm.lower()
    t = file_type_map.get(stem_norm) or file_type_map.get(stem_lower) or file_type_map.get(stem_norm.upper())
    if t in {"asm", "cpp"}:
        return t
    if resolve_asm_blueprint(stem_norm, blueprint_dir):
        return "asm"
    if resolve_cpp_blueprint(stem_norm, blueprint_dir):
        return "cpp"
    return "unknown"


@lru_cache(maxsize=2048)
def resolve_source_file(stem: str, file_type: str, blueprint_dir: Path, asm_dir: Optional[Path]) -> Optional[Path]:
    ext = "asm" if file_type == "asm" else "cpp"
    candidates: List[Path] = []
    if asm_dir:
        candidates.append(asm_dir / f"{stem}.{ext}")
    candidates += [
        blueprint_dir.parent.parent / "asm" / f"{stem}.{ext}",
        blueprint_dir.parent / "asm" / f"{stem}.{ext}",
        blueprint_dir / f"{stem}.{ext}",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


# ── Raw source line access (caching + optional on-disk offset index) ──────────
# PERF: fetch_raw_line was previously an UNCACHED full-file read + splitlines on
# *every* call.  It has 17 call sites, many inside per-setter / per-block loops
# that run D×F times across the dep_var BFS → cost was O(call_sites × filesize).
# Two memory-safe layers fix this without risking a small (16 GB) box:
#   1. _read_lines_cached — a *bounded* LRU that splits each file once and shares
#      the immutable result across all callers (default path; byte-identical to
#      the old splitlines() behaviour, so accuracy is unchanged).
#   2. _loff_lookup — an OPTIONAL on-disk byte-offset sidecar "<file>.loff" that
#      lets us seek to one line in O(1) memory, so huge generated files are never
#      held in RAM.  Sidecars are opt-in: build them with
#      scripts/build_line_offset_index.py.  When absent, layer 1 is used.
_LINE_CACHE_SIZE = int(os.environ.get("ASM_LINE_CACHE_SIZE", "512"))
_LOFF_SUFFIX = ".loff"
_LOFF_MAGIC = b"LOFF1\n"


@lru_cache(maxsize=_LINE_CACHE_SIZE)
def _read_lines_cached(path_str: str) -> tuple:
    """Read+split a source file once; cached by absolute path (bounded LRU).

    Returns an immutable tuple of physical lines (``str.splitlines()`` semantics,
    matching the previous fetch_raw_line behaviour exactly).  Source files are
    read-only during a backward run, so the cache is never stale.  Bounded by
    ``ASM_LINE_CACHE_SIZE`` (default 512 slots) to cap RAM on small servers.
    """
    text = _read_text_with_retry(Path(path_str), encoding="utf-8", errors="replace")
    return tuple(text.splitlines())


def clear_line_cache() -> None:
    """Evict the raw-line cache (call between BFS batches to bound peak RAM)."""
    try:
        _read_lines_cached.cache_clear()
    except Exception:
        pass


def get_line_cache_info() -> Optional[object]:
    """Return the raw-line LRU stats object (``.hits``/`.misses`/`.currsize`)."""
    try:
        return _read_lines_cached.cache_info()
    except Exception:
        return None


def _loff_lookup(src_path: Path, line_no: int) -> Optional[str]:
    """Read a single 1-based line via the on-disk offset sidecar, O(1) memory.

    Sidecar layout: ``_LOFF_MAGIC`` then little-endian uint64 offsets, where
    ``offsets[i]`` is the byte offset at which line ``i+1`` begins.  Returns
    ``None`` when no sidecar exists, the magic mismatches, or the line is out of
    range — callers then fall back to the bounded line cache.
    """
    if line_no < 1:
        return None
    loff = Path(str(src_path) + _LOFF_SUFFIX)
    if not loff.exists():
        return None
    try:
        import struct
        with open(loff, "rb") as fh:
            if fh.read(len(_LOFF_MAGIC)) != _LOFF_MAGIC:
                return None
            fh.seek(len(_LOFF_MAGIC) + (line_no - 1) * 8)
            buf = fh.read(16)  # offsets[line_no-1] and offsets[line_no]
        if len(buf) < 8:
            return None
        start = struct.unpack_from("<Q", buf, 0)[0]
        end = struct.unpack_from("<Q", buf, 8)[0] if len(buf) >= 16 else None
        with open(src_path, "rb") as sf:
            sf.seek(start)
            raw = sf.read((end - start) if end is not None else 1 << 20)
        return raw.split(b"\n", 1)[0].decode("utf-8", errors="replace").rstrip()
    except Exception:
        return None


def fetch_raw_line(file_field: str, line_no: int, asm_dir: Optional[Path]) -> Optional[str]:
    candidates: List[Path] = [Path(file_field)]
    if asm_dir:
        candidates.append(asm_dir / Path(file_field).name)

    for path in candidates:
        if not path.exists():
            continue
        # Layer 2: O(1)-memory seek via offset sidecar when one was built.
        via_loff = _loff_lookup(path, line_no)
        if via_loff is not None:
            return via_loff
        # Layer 1: bounded, shared line cache (default; identical to old behaviour).
        try:
            lines = _read_lines_cached(str(path))
            if 1 <= line_no <= len(lines):
                return lines[line_no - 1].rstrip()
        except Exception:
            continue
    return None


def resolve_ex_target(bp_data: Dict[str, Any], label: str) -> Optional[Dict[str, Any]]:
    """Resolve an EX/EXRL target label to its first flow entry.

    EX R3,MYMVC executes the instruction at label MYMVC.  The label is
    typically a standalone block whose single flow entry is the target
    instruction (e.g. MVC DEST,SRC).  Returns the first flow entry dict
    of the matching block, or None if the label cannot be resolved.
    """
    if not label:
        return None
    label_upper = str(label).strip().upper()
    for block in bp_data.get("blocks") or []:
        block_id = str(block.get("id") or "").strip().upper()
        if block_id == label_upper:
            entries = list(iter_flow(block))
            if entries:
                return entries[0]
    return None


def build_asm_block_source_index(blueprint_data: Dict[str, Any], asm_file: Optional[Path]) -> Dict[str, str]:
    if not asm_file or not asm_file.exists():
        return {}
    try:
        src_lines = _read_text_with_retry(asm_file, encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return {}

    index: Dict[str, str] = {}
    for block in blueprint_data.get("blocks", []):
        block_id = block.get("id")
        if not block_id:
            continue
        lines_in_flow = [e.get("line") for e in iter_flow(block) if e.get("line")]
        if not lines_in_flow:
            continue
        start = min(lines_in_flow)
        end = max(lines_in_flow)
        index[block_id] = "\n".join(src_lines[start - 1 : end])
    return index


def extract_single_block_source(
    bp_data: Dict[str, Any],
    asm_file: Optional[Path],
    block_id: str,
    _source_cache: Optional[Dict[str, List[str]]] = None,
) -> Optional[str]:
    """Extract source text for a single ASM block by *block_id*.

    Unlike ``build_asm_block_source_index`` which iterates every block in the
    blueprint, this function locates only the requested block — faster when the
    caller needs just one or two blocks from a large file.

    *_source_cache* is an optional ``{str(asm_file): [lines]}`` dict.  When
    provided the file is read at most once and the cached lines are reused for
    subsequent calls with different *block_id* values in the same file.
    """
    if not asm_file or not asm_file.exists():
        return None
    cache_key = str(asm_file)
    if _source_cache is not None and cache_key in _source_cache:
        src_lines = _source_cache[cache_key]
    else:
        try:
            src_lines = _read_text_with_retry(
                asm_file, encoding="utf-8", errors="replace"
            ).splitlines()
        except Exception:
            return None
        if _source_cache is not None:
            _source_cache[cache_key] = src_lines

    block_id_upper = str(block_id).strip().upper()
    for block in bp_data.get("blocks", []):
        bid = str(block.get("id") or "").strip().upper()
        if bid != block_id_upper:
            continue
        lines_in_flow = [e.get("line") for e in iter_flow(block) if e.get("line")]
        if not lines_in_flow:
            return None
        start = min(lines_in_flow)
        end = max(lines_in_flow)
        return "\n".join(src_lines[start - 1 : end])
    return None


_CONST_LABEL_RE = re.compile(r"^\s*([A-Za-z@$_#][A-Za-z0-9@$_#]*)\s+(DC|EQU)\b", re.IGNORECASE)

# PERF-OPT-4: cache constant symbols by (blueprint_path, asm_file_path) to avoid
# redundant source-file reads and regex scans when the same file is traced for
# multiple dep_vars.  Bounded to 256 entries to prevent unbounded memory growth
# on 22K-file codebases where 100K+ unique (bp, asm) pairs are possible.
from collections import OrderedDict as _OrderedDict
_constant_symbols_cache: _OrderedDict = _OrderedDict()
_CONSTANT_CACHE_MAX = 256


def collect_constant_symbols(
    blueprint_data: Dict[str, Any],
    asm_file: Optional[Path] = None,
    *,
    bp_path: Optional[Path] = None,
) -> Set[str]:
    """Collect constant-like symbols for dep-var filtering.

    Priority:
    1) Symbol table entries marked as constant-like (`dc`, `equ`, etc.)
    2) Fallback source scan for labeled `DC` / `EQU`

    HLASM assembler-defined built-in symbols (SPACE, LOW, HIGH, …) are always
    included so they never leak as dep_vars regardless of the source file.

    When *bp_path* is provided the result is cached by
    ``(bp_path, asm_file)`` so repeated calls for different dep_vars
    in the same file are free.
    """
    if bp_path is not None:
        _cache_key = (str(bp_path), str(asm_file) if asm_file else None)
        cached = _constant_symbols_cache.get(_cache_key)
        if cached is not None:
            _constant_symbols_cache.move_to_end(_cache_key)  # LRU refresh
            return cached

    out: Set[str] = set(HLASM_BUILTIN_SYMBOLS)

    symbols = (blueprint_data.get("symbols") or {})
    constant_types = {"dc", "equ", "literal", "constant"}

    def _is_constant_type(stype: str) -> bool:
        return stype in constant_types or stype.startswith("dc")

    global_symbols = symbols.get("global_symbols") or {}
    if isinstance(global_symbols, dict):
        for name, meta in global_symbols.items():
            if not name:
                continue
            m = meta or {}
            stype = str(m.get("type") or "").strip().lower()
            if _is_constant_type(stype):
                out.add(str(name).upper())

    local_symbols = symbols.get("local_symbols") or {}
    if isinstance(local_symbols, dict):
        for name, meta in local_symbols.items():
            if not name:
                continue
            m = meta or {}
            stype = str(m.get("type") or "").strip().lower()
            if _is_constant_type(stype):
                out.add(str(name).upper())

    if asm_file is not None and asm_file.exists():
        try:
            _ov = source_override_bytes(asm_file)   # T9: serve from DB when installed
            if _ov is not None:
                lines = _ov.decode("utf-8", "replace").splitlines()
            else:
                lines = _read_text_with_retry(asm_file, encoding="utf-8", errors="replace").splitlines()
        except Exception:
            lines = []

        for raw in lines:
            line = str(raw or "")
            if not line.strip():
                continue
            if line.lstrip().startswith("*"):
                continue
            m = _CONST_LABEL_RE.match(line)
            if not m:
                continue
            label = str(m.group(1) or "").upper()
            if label:
                out.add(label)

    if bp_path is not None:
        _constant_symbols_cache[_cache_key] = out
        # Evict oldest entries to bound memory on large codebases.
        while len(_constant_symbols_cache) > _CONSTANT_CACHE_MAX:
            _constant_symbols_cache.popitem(last=False)
    return out
