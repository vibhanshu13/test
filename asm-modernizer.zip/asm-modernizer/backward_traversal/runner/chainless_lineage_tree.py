"""Value + RELEVANT-condition backward lineage tree (the "logic" of a variable).

Answers, for a variable: *in what conditions does it get each value, what are its
dependent variables, and under what conditions do THOSE get their values* —
recursively.

Unlike the function-wide guard dump, conditions here are the **relevant** path
guards: each C++ assign/define edge in the per-file ``variable_lineage`` carries
its own ``conditional_context`` (the enclosing if/loop chain).  We use that
directly, so every setter lists only the conditions that actually gate it.

A lineage node:
    {var, file, line, value, conditions:[...],
     condition_deps:[<recursive lineage>...],      # vars in the guards
     value_deps:[<recursive lineage>...]}          # the RHS var (if not a literal)

Bounded by ``max_depth`` and cycle-guarded by variable name.  Spans files (a var
may be set in several files) so it is inherently cross-file / cross-caller.
"""

from __future__ import annotations

import logging
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

_SETTER_RELATIONS = {"assign", "define"}
# A C++ *variable* operand: starts lowercase (camelCase), optional member access.
# Enum/type constants look like ``Type::Value`` (start uppercase) and are excluded.
_VAR_RE = re.compile(r"(?<![:\w])([a-z][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)")


def _cond_dict_to_str(c: Any) -> str:
    """Convert a condition dict from _extract_block_conditions_before_line to a
    ``"test / branch"`` guard string compatible with the rest of this module.

    ASM condition dicts have keys: type, line, test, branch (or note).
    GVL conditions are already strings — returned unchanged.
    """
    if not isinstance(c, dict):
        return str(c)
    test = c.get("test") or ""
    branch = c.get("branch") or ""
    note = c.get("note") or ""
    if test and branch:
        return f"{test} / {branch}"
    if note:
        return note
    return str(c)


def _dedup_conds(conds: list) -> list:
    """Deduplicate a condition list (strings or dicts) using dict.fromkeys."""
    return list(dict.fromkeys(conds))


def _terminal(node_id: str) -> str:
    s = str(node_id or "")
    for sep in ("::", "->", "."):
        if sep in s:
            s = s.split(sep)[-1]
    return s.strip()


def _func_from_return_node(node_id: str) -> str:
    """Extract ``<func>`` from a return-value node ``...return@<func>``."""
    s = str(node_id or "")
    if "return@" not in s:
        return ""
    return s.split("return@")[-1].split(":")[0].split(".")[0].strip()


def _ret_method_terminal(node_id: str) -> str:
    """The terminal method name of a return node, ignoring class qualifier.

    ``return@CardPolicy::classify`` -> ``classify``; ``return@validateCardNbr``
    -> ``validateCardNbr``.  Matching descent on this terminal is the CHA
    over-approximation: ``return@classify`` reaches EVERY override's return
    across the class hierarchy (never misses a virtual target), which is the
    sound behaviour for statically-undecidable dispatch.
    """
    s = str(node_id or "")
    if "return@" not in s:
        return ""
    s = s.split("return@")[-1].split("(")[0]
    return s.split("::")[-1].split(".")[0].strip()


def _terminal_path(node_id: str) -> str:
    """The member-access path of a node, stripped of its ``kind:scope::`` prefix.

    ``struct_field:SCOPE::a.b.c.field`` -> ``a.b.c.field``.
    """
    s = str(node_id or "")
    if "::" in s:
        s = s.split("::")[-1]
    elif ":" in s:
        s = s.split(":")[-1]
    return s.strip()


def _load_pfl(stem: str, blueprint_dir: Path, cache: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if stem in cache:
        return cache[stem]
    pfl = None
    try:
        from backward_traversal.utils.blueprint_utils import load_json, resolve_cpp_blueprint
        bp_path = resolve_cpp_blueprint(stem, blueprint_dir)
        if bp_path:
            bp = load_json(bp_path)
            pfl = {"lineage": bp.get("variable_lineage") or {}, "bp": bp}
    except Exception:
        pfl = None
    cache[stem] = pfl
    # 22k OOM guard: each stem entry pins a FULL parsed blueprint (a strong ref that defeats the
    # load_json LRU — the two budgets otherwise stack into GBs). Cap the stem entries with FIFO
    # eviction; the reserved "_*" sub-caches (e.g. _bridge_sites) are bounded elsewhere and skipped.
    # Byte-identical: an evicted stem is simply reloaded (same DB/LRU bytes) on the next miss.
    if len(cache) > 264:
        _stems = [k for k in cache if not str(k).startswith("_")]
        for _k in _stems[:-256]:
            cache.pop(_k, None)
    return pfl


def _file_type(stem: str, blueprint_dir: Path) -> Optional[str]:
    """'cpp' | 'asm' | None for a stem (a stem may have both; cpp preferred)."""
    if (blueprint_dir / f"{stem}.cpp.json").exists():
        return "cpp"
    if (blueprint_dir / f"{stem}.asm.json").exists() or (blueprint_dir / f"{stem}.mac.json").exists():
        return "asm"
    return None


def _candidate_files(var: str, blueprint_dir: Path, graph_file: Path,
                     job_id: Optional[str]) -> List[Tuple[str, str]]:
    """Candidate (stem, file_type) pairs that may set ``var`` — ASM and C++.

    Seeds from the variable_modifier_index when available (cheap), else globs.
    """
    out: List[Tuple[str, str]] = []
    # A return@<func> pseudo-variable (function-descent, reqs 5/6): the function
    # may live in any C++ file, so scan all C++ blueprints for its return edges.
    if var.startswith("return@"):
        return [(p.name[: -len(".cpp.json")], "cpp") for p in blueprint_dir.glob("*.cpp.json")]
    if job_id:
        try:
            from api.index_db.readers import get_modifier_files
            fb = graph_file.parent / "variable_modifier_index.json"
            stems = get_modifier_files(job_id, var, fallback_path=fb if fb.exists() else None)
            for s in (stems or []):
                ft = _file_type(s, blueprint_dir)
                if ft:
                    out.append((s, ft))
            if out:
                return out
        except Exception:
            pass
    seen: Set[str] = set()
    for suf, ft in ((".cpp.json", "cpp"), (".asm.json", "asm"), (".mac.json", "asm")):
        for p in blueprint_dir.glob(f"*{suf}"):
            stem = p.name[: -len(suf)]
            if stem not in seen:
                seen.add(stem)
                out.append((stem, ft))
    return out


# The C/C++ language keywords + builtin type names — these look like lowercase
# identifiers but are never variables.  This is the *language* reserved set (not
# any project's symbols), so it stays generic across any codebase.  Library
# function names (memcmp, strcmp, …) are NOT listed: they're excluded generically
# by the ``name(`` call check, not by name.
_CXX_NONVARS = frozenset({
    "sizeof", "char", "int", "long", "short", "void", "unsigned", "signed",
    "const", "static", "return", "if", "else", "for", "while", "do", "switch",
    "case", "default", "break", "continue", "struct", "union", "enum", "class",
    "bool", "true", "false", "float", "double", "new", "delete", "this",
    "nullptr", "null", "and", "or", "not", "typedef", "volatile", "register",
    "goto", "extern", "inline", "namespace", "using", "template", "typename",
})


def extract_condition_vars(cond: str) -> List[str]:
    """Variable operands referenced in a guard condition (terminal names).

    Excludes enum/type constants (``Type::Value``), function names, literals, and
    C/C++ keywords/builtin types (``char``, ``sizeof`` …) which are not variables.
    """
    text = str(cond or "")
    out: List[str] = []
    seen: Set[str] = set()
    for m in _VAR_RE.finditer(text):
        tok = m.group(1)
        end = m.end()
        # Skip ``name::`` (a type/namespace prefix) and ``name(`` (a function call).
        nxt = text[end:end + 2]
        if nxt.startswith("::") or text[end:end + 1] == "(":
            continue
        term = tok.split(".")[-1]
        if term.lower() in _CXX_NONVARS or tok.lower() in _CXX_NONVARS:
            continue
        if term and term not in seen:
            seen.add(term)
            out.append(term)
    return out


def _direct_equality_constraint(cond: str, var: str):
    """Return the constraint ONLY when ``var`` is the direct ==/!= operand of the
    whole condition (``var == Value`` / ``var != Value``), else None.

    Guards specific-value pruning against false matches: ``getCoreblocks(*p)==0``
    or ``memcmp(x+35,"W110",4)==0`` must NOT prune ``p``/``x`` — the comparison
    operand there is the call/``memcmp`` result, not the variable."""
    from backward_traversal.runner.chainless_dep_resolver import extract_constraint
    s = str(cond or "").strip()
    while s.startswith("(") and s.endswith(")"):
        s = s[1:-1].strip()
    v = re.escape(var)
    # var (optionally member-qualified, ending in our terminal) is the LHS, then
    # ==/!=, then a value — and the var is NOT wrapped in a call/index/arith expr.
    m = re.match(rf"^[A-Za-z_][\w.]*\b{v}\s*(==|!=)\s*([^=].*)$", s)
    if not m:
        m2 = re.match(rf"^{v}\s*(==|!=)\s*([^=].*)$", s)
        if not m2:
            return None
        m = m2
    # reject when the LHS contains a call/index/arithmetic (not a pure lvalue)
    lhs = s[: s.index(m.group(1))]
    if any(ch in lhs for ch in "()[]+-*/&,"):
        return None
    con = extract_constraint(s)
    return con if (con.operator in ("==", "!=") and con.constant) else None


def _reverse_file_adj(graph_file: Path, job_id: Optional[str]) -> Dict[str, Set[str]]:
    """{callee_stem_upper: {caller_stems}} from the file-level call graph."""
    try:
        from backward_traversal.runner.chainless_runner import _load_graph_payload
        payload = _load_graph_payload(graph_file, job_id)
    except Exception:
        return {}
    radj: Dict[str, Set[str]] = {}
    for e in (payload.get("edges") or []):
        src = str(e.get("source") or "").strip()
        tgt = str(e.get("target") or "").strip().upper()
        if src and tgt:
            radj.setdefault(tgt, set()).add(src)
        for cs in (e.get("call_sites") or []):
            tm = str(cs.get("target_module") or "").strip().upper()
            if src and tm:
                radj.setdefault(tm, set()).add(src)
    return radj


def _conditions_at(stem: str, scope: str, line: int, blueprint_dir: Path,
                   pfl_cache: Dict[str, Any]) -> List[str]:
    """Guard conditions active at (scope, line) in a caller.

    Collects ALL conditional_context entries from lineage edges in the same
    function scope whose line is at or before the call site.  This captures
    both syntactically-enclosing conditions (nested ifs) and guard-clause
    style early-return conditions that precede the call without wrapping it.
    Results are deduplicated preserving first-occurrence order.
    """
    entry = _load_pfl(stem, blueprint_dir, pfl_cache)
    if not entry:
        return []
    # PERF: memoize by (scope, line) on the cached pfl entry. A heavy variable's per-route
    # build asks for the SAME (scope, line) guards thousands of times (1316 setter-tuples share
    # routes/functions); without this memo each call re-iterates the whole file's lineage edges
    # — the single dominant cost of per-route entry building. Deterministic ⇒ byte-identical.
    # A fresh list is returned each call so callers may consume/transform it freely.
    memo = entry.get("_cond_at_memo")
    if memo is None:
        memo = {}
        entry["_cond_at_memo"] = memo
    mkey = (scope, int(line or 0))
    collected = memo.get(mkey)
    if collected is None:
        lineage = entry.get("lineage") or {}
        collected = []
        seen: set = set()
        for e in (lineage.get("edges") or []):
            if str(e.get("scope") or "") != scope:
                continue
            cc = e.get("conditional_context")
            if not cc:
                continue
            e_line = int(e.get("line") or 0)
            # Skip edges after the call site — those conditions don't gate the call.
            if line and e_line > line:
                continue
            for c in cc:
                if not c:
                    continue
                # Normalise whitespace for deduplication so "x  ==  1" and "x == 1"
                # collapse to the same key (keep the first-seen form for display).
                norm = " ".join(str(c).split())
                if norm not in seen:
                    seen.add(norm)
                    collected.append(str(c))
        memo[mkey] = collected
    return list(collected)


_CASE_RE = re.compile(r"^\s*case\s+(.+?):?\s*$")
_BARE_VAR_RE = re.compile(r"^\(?\s*([A-Za-z_][\w.]*)\s*\)?$")


def _case_index(entry: Dict[str, Any]) -> Dict[str, List[Any]]:
    """Per-file ``{scope: sorted[(line, case_value)]}`` index, built once and
    cached on the loaded blueprint entry.  Avoids re-scanning every edge of a
    file on each call hop — important at 22k-file scale where a caller function
    may host many call sites."""
    idx = entry.get("_case_index")
    if idx is None:
        idx = {}
        for e in (entry.get("lineage") or {}).get("edges") or []:
            for cc in (e.get("conditional_context") or []):
                m = _CASE_RE.match(str(cc))
                if m:
                    idx.setdefault(str(e.get("scope") or ""), []).append(
                        (int(e.get("line") or 0), m.group(1).strip()))
        for sc in idx:
            idx[sc].sort()
        entry["_case_index"] = idx
    return idx


def _governing_case(entry: Dict[str, Any], scope: str, call_line: int) -> Optional[str]:
    """The ``case <Value>`` label governing ``call_line`` in a ``switch`` (the
    nearest preceding ``case`` in the same scope).  ``switch(task)`` emits the
    discriminant ``(task)`` on the call edge and ``case <Value>`` on a separate
    use-edge at the case line; this recovers the value so the guard can be
    reconstructed as ``<discriminant> == <Value>``.  O(cases-in-scope) via the
    cached index — no per-hop full-file scan."""
    best_val: Optional[str] = None
    for ln, val in _case_index(entry).get(scope, []):
        if ln <= call_line:
            best_val = val
        else:
            break
    return best_val


def _reconstruct_switch_conditions(
    conds: List[str], entry: Dict[str, Any], scope: str, call_line: int
) -> List[str]:
    """Rewrite a bare switch discriminant ``(task)`` into ``task == <caseValue>``
    using the governing ``case`` label, so caller guards carry the specific value
    that routes to the callee (enables specific-value pruning of the dep)."""
    out: List[str] = []
    for c in conds:
        m = _BARE_VAR_RE.match(str(c))
        if m:
            case_val = _governing_case(entry, scope, call_line)
            if case_val:
                out.append(f"{m.group(1)} == {case_val}")
                continue
        out.append(c)
    return list(dict.fromkeys(out))


def callers_of_function(
    callee_fn: str, callee_stem: str, blueprint_dir: Path, graph_file: Path,
    job_id: Optional[str], pfl_cache: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Find function-level callers of ``callee_fn`` and the condition of each call.

    Uses ``arg_bind`` edges (``target = call_arg:<callee_fn>#idx``) to locate
    call sites; the caller function is the edge's ``scope`` and the call line is
    its ``line``.  Candidate caller files = the callee's own file (intra-file
    calls) plus the file-level call-graph reverse-adjacency callers of the
    callee's stem.  Generic — no variable/function-specific logic.
    """
    radj = _reverse_file_adj(graph_file, job_id)
    cand: Set[str] = {callee_stem} | {s for s in radj.get(callee_stem.upper(), set())}
    pat = f"call_arg:{callee_fn}#"
    out: List[Dict[str, Any]] = []
    seen: Set[Any] = set()
    for stem in sorted(cand):
        entry = _load_pfl(stem, blueprint_dir, pfl_cache)
        if not entry:
            continue
        for e in (entry.get("lineage") or {}).get("edges") or []:
            if str(e.get("relation", "")).lower() != "arg_bind":
                continue
            if not str(e.get("target", "")).startswith(pat):
                continue
            caller_fn = str(e.get("scope") or "")
            line = int(e.get("line") or 0)
            key = (stem, caller_fn, line)
            if not caller_fn or key in seen:
                continue
            seen.add(key)
            # Use the edge's own conditions if present (post parser-emit), else derive.
            conds = list(dict.fromkeys(e.get("conditional_context") or [])) or \
                _conditions_at(stem, caller_fn, line, blueprint_dir, pfl_cache)
            # A switch(discriminant)/case routing to this callee is emitted as a
            # bare ``(discriminant)`` guard; recover the governing case value so
            # the guard is the specific ``discriminant == caseValue`` that gates
            # the call (and prunes the dep to the on-path value).
            conds = _reconstruct_switch_conditions(conds, entry, caller_fn, line)
            out.append({
                "caller_function": caller_fn, "caller_file": stem,
                "call_line": line, "callee_function": callee_fn,
                "call_conditions": conds,
            })
    return out


def _setters_in_file(var: str, stem: str, pfl_entry: Dict[str, Any]) -> List[Dict[str, Any]]:
    """All assign/define sites of ``var`` in one file, with value + relevant conditions.

    Handles a ``return@<func>`` pseudo-variable (function-descent, reqs 5/6): its
    "setters" are the function's return statements — assign edges whose target is
    the ``return@<func>`` node — so we recover what a called function returns and
    under what conditions.
    """
    lineage = pfl_entry.get("lineage") or {}
    bp = pfl_entry.get("bp") or {}
    is_return = var.startswith("return@")
    if is_return:
        func = var[len("return@"):]
        func_term = func.split("::")[-1].split(".")[0].strip()  # CHA terminal match
        seeds = None  # match by target return-method terminal (all overrides)
    else:
        try:
            from backward_traversal.utils.cpp_lineage_utils import (
                extract_asm_field_aliases,
                find_cpp_seed_nodes,
            )
        except Exception:  # pragma: no cover
            return []
        seeds = set(find_cpp_seed_nodes(lineage, var, extract_asm_field_aliases(bp, var), {}) or [])
        if not seeds:
            return []
    sites: List[Dict[str, Any]] = []
    real_lines: Set[int] = set()           # lines with a modeled-value setter
    literal_lines: Dict[int, Dict[str, Any]] = {}  # line -> unmodeled-literal write
    for e in (lineage.get("edges") or []):
        if str(e.get("relation", "")).lower() not in _SETTER_RELATIONS:
            continue
        tgt = str(e.get("target", ""))
        if is_return:
            # Match the return-method terminal so every override in the class
            # hierarchy is reached (CHA over-approximation), not just an exact
            # qualified name.
            if _ret_method_terminal(tgt) != func_term:
                continue
            # Skip self-referential return edges (return@f -> return@f) — noise.
            if _ret_method_terminal(str(e.get("source", ""))) == func_term:
                continue
        elif tgt not in seeds:
            continue
        conds = list(dict.fromkeys(e.get("conditional_context") or []))
        src = str(e.get("source") or "")
        value = _terminal(src)
        ln = int(e.get("line") or 0)
        cvars = sorted({v for c in conds for v in extract_condition_vars(c)
                        if v.upper() != var.upper()})
        # Filter structural noise: the GVL models a member lvalue
        # (a.b.c.var) as a chain of nodes, producing define/assign edges whose
        # source terminal is the variable itself or one of its parent path
        # components (e.g. "various").  Those are not real value assignments.
        tgt_components = {c for c in re.split(r"[.:>-]+", _terminal_path(tgt)) if c}
        # Function-call RHS (x = f(...)): descend into the function (reqs 5/6).
        rfunc = _func_from_return_node(src)
        if rfunc:
            value = f"{rfunc}()"
            value_dep = f"return@{rfunc}"
        else:
            if not value or value.upper() == var.upper() or value in tgt_components:
                # No modeled value source.  An ASSIGN to the var here is still a
                # real write whose RHS the GVL didn't model as a node — typically
                # a numeric literal (``x = 0x00`` clean-slate init).  Don't drop
                # the setter site; record it with the value surfaced as an
                # unmodeled literal (never fabricated) so completeness holds.
                if str(e.get("relation", "")).lower() == "assign" and not is_return:
                    literal_lines.setdefault(ln, {
                        "file": stem, "file_type": "cpp", "line": ln,
                        "value": "(literal)", "value_unresolved": True,
                        "scope": str(e.get("scope") or ""), "target": tgt,
                        "value_source": src, "value_dep": None,
                        "conditions": conds, "condition_vars": cvars,
                    })
                continue
            # RHS is a variable (lowercase terminal) → data-flow value dep.
            value_dep = value if value[:1].islower() else None
        real_lines.add(ln)
        sites.append({
            "file": stem, "file_type": "cpp", "line": ln, "value": value,
            "scope": str(e.get("scope") or ""), "target": tgt,
            "value_source": src, "value_dep": value_dep,
            "conditions": conds, "condition_vars": cvars,
        })
    # Add unmodeled-literal writes only for lines with no modeled-value setter
    # (so an enum/var setter at a line is never shadowed by a literal placeholder).
    for ln, site in literal_lines.items():
        if ln not in real_lines:
            sites.append(site)
    # De-dup identical (line,value) sites.
    uniq: Dict[Any, Dict[str, Any]] = {}
    for s in sites:
        uniq[(s["line"], s["value"], tuple(s["conditions"]))] = s
    return list(uniq.values())


def _asm_setters_in_file(
    var: str, stem: str, blueprint_dir: Path, asm_dir: Optional[Path]
) -> List[Dict[str, Any]]:
    """ASM setters of ``var`` with value + RELEVANT TRIGGER/BRANCH conditions.

    Reuses the same functions the chain-based module used: ``_find_scoped_setter_sites``
    (values, constant_source, prior_value, implicit setters, flipc/hardware) and
    ``_extract_block_conditions_before_line`` (the relevant guard pairs).  Fully
    generic — no variable-specific logic.
    """
    try:
        from backward_traversal.runner.backward_only_runner import (
            _extract_block_conditions_before_line,
            _find_scoped_setter_sites,
        )
        from backward_traversal.utils.blueprint_utils import (
            collect_constant_symbols,
            load_json,
            resolve_asm_blueprint,
        )
        from backward_traversal.utils.token_utils import dep_vars_from_args
    except Exception:  # pragma: no cover
        return []
    bp_path = resolve_asm_blueprint(stem, blueprint_dir)
    if not bp_path:
        return []
    try:
        bp = load_json(bp_path)
    except Exception:
        return []
    all_blocks = {str(b.get("id") or "") for b in (bp.get("blocks") or []) if b.get("id")}
    if not all_blocks:
        return []
    asm_file = (asm_dir / f"{stem}.asm") if asm_dir else bp_path
    try:
        consts = collect_constant_symbols(bp, asm_file)
    except Exception:
        consts = set()
    try:
        sites, _w = _find_scoped_setter_sites(var, bp, asm_file, all_blocks, asm_dir,
                                              constant_symbols=consts)
    except Exception:
        return []
    out: List[Dict[str, Any]] = []
    for s in sites:
        routine = str(s.get("routine") or "")
        line = int(s.get("line") or 0)
        try:
            conds = [_cond_dict_to_str(c)
                     for c in _extract_block_conditions_before_line(bp, routine, line, str(bp_path))]
        except Exception:
            conds = []
        value = str(s.get("setter_expression") or s.get("implicit_target") or "")
        # Condition variables: operands of the TRIGGER half of each guard pair.
        cond_vars: List[str] = []
        for c in conds:
            trig = str(c).split("/")[0]
            parts = trig.split(None, 1)
            if len(parts) == 2:
                args = [a.strip() for a in parts[1].split(",")]
                cond_vars.extend(dep_vars_from_args(args, skip_var=var, constant_symbols=consts))
        out.append({
            "file": stem, "file_type": "asm", "line": line, "value": value, "scope": routine,
            "instruction": str(s.get("instruction") or ""),
            "raw_line": str(s.get("raw_line") or ""),
            "value_source": value, "value_dep": None,  # full dep set comes from the ASM tracer
            "conditions": _dedup_conds(conds),
            "condition_vars": sorted({v for v in cond_vars if v.upper() != var.upper()}),
            "constant_source": bool(s.get("constant_source")),
            "prior_value_required": bool(s.get("prior_value_required")),
            "implicit_target": s.get("implicit_target"),
            "call_type": s.get("call_type"),
        })
    return out


def _tracer_dep_vars(var: str, stem: str, ft: str, site: Dict[str, Any],
                     blueprint_dir: Path, asm_dir: Optional[Path],
                     pfl_cache: Dict[str, Any]) -> List[str]:
    """Dependent variables for a setter via the FULL existing tracers — so all
    edge cases (register backtracking, indirect calls, special setter patterns,
    bridge registers, shared-variable handling) are covered, not re-derived.

    Sound memo: the tracer's result depends only on (var, stem, file_type, line,
    seed/scope) and the read-only blueprint — never on traversal order — so
    caching it is safe and removes the dominant repeated cost.
    """
    tmemo = pfl_cache.setdefault("__tracer_memo__", {})
    # PER-SETTER key: deps belong to the specific assignment, not the variable
    # file-wide (a constant assignment has no value deps even if the variable is
    # computed elsewhere in the file).  The per-site tracers give per-setter deps
    # with register backtracking / indirect / bridge-reg handling.
    tkey = (var.upper(), stem, ft, site.get("line"), site.get("scope"), site.get("target"))
    if tkey in tmemo:
        return tmemo[tkey]
    result = _filter_dep_noise(
        var, _tracer_dep_vars_uncached(var, stem, ft, site, blueprint_dir, asm_dir, pfl_cache))
    tmemo[tkey] = result
    return result


# Tokens that are values/types/path-fragments, never real dependency variables.
def _filter_dep_noise(var: str, deps: List[str]) -> List[str]:
    out: List[str] = []
    vu = var.upper()
    for d in deps:
        ds = str(d)
        term = ds.split("bridge:")[-1].split(".")[-1].split("::")[-1].strip()
        if not term:
            continue
        tu = term.upper()
        if tu == vu:                       # the variable itself
            continue
        if "::" in ds and not ds.startswith("bridge:"):  # Type::Constant enum literal
            continue
        if term in ("various", "process", "data", "value"):  # generic struct-path fragments
            continue
        out.append(ds if ds.startswith("bridge:") else term)
    return list(dict.fromkeys(out))


def _tracer_dep_vars_uncached(var: str, stem: str, ft: str, site: Dict[str, Any],
                              blueprint_dir: Path, asm_dir: Optional[Path],
                              pfl_cache: Dict[str, Any]) -> List[str]:
    """Complete per-(variable,file) dep set, via the EXISTING per-hop COMPONENTS
    (``_build_modifier_*_payload``) — which already aggregate the full tracer
    output (register backtracking, indirect, bridge regs, special patterns,
    counterpart/seed resolution).  Reused, not re-derived; one call per file."""
    try:
        if ft == "asm":
            if site.get("constant_source"):
                return []   # constant assignment → no value deps (correct per-setter)
            from backward_traversal.tracing.asm_backward_tracer import trace_asm_call_site_backward
            from backward_traversal.utils.blueprint_utils import resolve_asm_blueprint
            bp_path = resolve_asm_blueprint(stem, blueprint_dir)
            if not bp_path:
                return []
            asm_file = (asm_dir / f"{stem}.asm") if asm_dir else bp_path
            call_site = {"routine": site.get("scope"), "line": site.get("line"),
                         "instruction": site.get("instruction"), "raw_line": site.get("raw_line"),
                         "constant_source": site.get("constant_source")}
            res = trace_asm_call_site_backward(var, bp_path, asm_file, call_site)
            return list(dict.fromkeys(res.get("dep_vars") or []))
        else:
            # A constant/enum assignment (RHS not a variable) has no value deps;
            # skip the (expensive) tracer entirely — correctness AND perf.
            if not site.get("value_dep") or not site.get("target"):
                return []
            from backward_traversal.tracing.cpp_backward_tracer import trace_cpp_variable_backward
            entry = _load_pfl(stem, blueprint_dir, pfl_cache)
            pfl = (entry or {}).get("lineage") or {}
            res = trace_cpp_variable_backward(
                site["target"], pfl, before_line=int(site.get("line") or 0) + 1,
                per_file_lineage=pfl, variable_name=var)
            deps = list(res.get("dep_vars") or [])
            deps += [f"bridge:{r}" for r in (res.get("bridge_registers") or [])]
            return list(dict.fromkeys(deps))
    except Exception:
        return []


def asm_callers_of(
    callee_stem: str, blueprint_dir: Path, graph_file: Path,
    job_id: Optional[str], pfl_cache: Dict[str, Any], asm_dir: Optional[Path],
) -> List[Dict[str, Any]]:
    """Callers of an ASM file (and the condition each call is made under).

    Uses the file-level call-graph reverse-adjacency to find candidate caller
    stems, the cross-file bridges (asm→asm / cpp→asm) to VERIFY the call sites,
    and ``_extract_block_conditions_before_line`` (TRIGGER+BRANCH) to capture the
    guard each call is made under.  Generic — mirrors the chain module's logic.
    """
    try:
        from backward_traversal.bridge.cross_file_bridge_backward import (
            find_asm_callers, find_cpp_to_asm_callers,
        )
        from backward_traversal.runner.backward_only_runner import _extract_block_conditions_before_line
        from backward_traversal.utils.blueprint_utils import load_json, resolve_asm_blueprint
    except Exception:  # pragma: no cover
        return []
    radj = _reverse_file_adj(graph_file, job_id)
    out: List[Dict[str, Any]] = []
    seen: Set[Any] = set()
    for cstem in sorted(radj.get(callee_stem.upper(), set())):
        ft = _file_type(cstem, blueprint_dir)
        try:
            if ft == "asm":
                sites = find_asm_callers(cstem, callee_stem, blueprint_dir, asm_dir) or []
            elif ft == "cpp":
                sites = find_cpp_to_asm_callers(cstem, callee_stem, blueprint_dir, asm_dir) or []
            else:
                continue
        except Exception:
            sites = []
        for s in sites:
            routine = str(s.get("routine") or s.get("function") or "")
            line = int(s.get("line") or 0)
            key = (cstem, routine, line)
            if not routine or key in seen:
                continue
            seen.add(key)
            conds: List[str] = []
            if ft == "asm":
                cbp = resolve_asm_blueprint(cstem, blueprint_dir)
                if cbp:
                    try:
                        conds = [_cond_dict_to_str(c)
                                 for c in _extract_block_conditions_before_line(
                                     load_json(cbp), routine, line, str(cbp))]
                    except Exception:
                        conds = []
            else:
                conds = _conditions_at(cstem, routine, line, blueprint_dir, pfl_cache)
            out.append({
                "caller_function": routine, "caller_file": cstem,
                "call_line": line, "callee_function": callee_stem,
                "call_conditions": _dedup_conds(conds),
                "instruction": s.get("instruction"),
            })
    return out


def build_caller_chain(
    fn: str, stem: str, blueprint_dir: Path, graph_file: Path, *,
    job_id: Optional[str], max_caller_depth: int, _depth: int,
    _visited: Set[str], pfl_cache: Dict[str, Any], asm_dir: Optional[Path] = None,
) -> List[Dict[str, Any]]:
    """Recursive: callers of ``fn`` (with the condition each call is made under),
    then callers-of-callers — the inter-procedural reachability conditions.

    Language-aware: ASM callees resolve callers via the call graph + bridges +
    TRIGGER/BRANCH guards; C++ callees via ``arg_bind`` + per-line conditions."""
    if not fn:
        return []
    if max_caller_depth and _depth >= max_caller_depth:
        return []
    callee_ft = _file_type(stem, blueprint_dir)
    if callee_ft == "asm":
        level = asm_callers_of(stem, blueprint_dir, graph_file, job_id, pfl_cache, asm_dir)
    else:
        level = callers_of_function(fn, stem, blueprint_dir, graph_file, job_id, pfl_cache)
    out: List[Dict[str, Any]] = []
    for c in level:
        cfn = c["caller_function"]
        node = dict(c)
        if cfn.upper() in _visited:
            node["cycle"] = True
            out.append(node)
            continue
        node["callers"] = build_caller_chain(
            cfn, c["caller_file"], blueprint_dir, graph_file, job_id=job_id,
            max_caller_depth=max_caller_depth, _depth=_depth + 1,
            _visited=_visited | {cfn.upper()}, pfl_cache=pfl_cache, asm_dir=asm_dir,
        )
        out.append(node)
    return out


def _value_matches_constraint(value: str, operator: str, constant: str) -> bool:
    """Whether a setter ``value`` satisfies a guard constraint (terminal compare).

    Used for specific-value pruning: a call gated by ``task == GlobalLimitsUpdate``
    keeps only the ``task`` setters whose value IS ``GlobalLimitsUpdate``; ``!=``
    drops the matching ones.  Compares terminals (ignores ``Type::`` qualifier)."""
    v = _terminal(value).upper()
    k = _terminal(constant).upper()
    if not v or not k:
        return True  # can't compare -> conservative keep (never falsely prune)
    if operator == "==":
        return v == k
    if operator == "!=":
        return v != k
    return True


def _prune_to_constraint(lineage: Dict[str, Any], operator: str, constant: str) -> Dict[str, Any]:
    """Return a copy of a cond-dep lineage keeping only setters whose value
    satisfies the guard (specific-value setters).  Pruned count is recorded, not
    silently dropped; nothing is deleted from the original cached lineage."""
    import copy
    out = copy.deepcopy(lineage)
    setters = out.get("setters", [])
    kept = [s for s in setters if _value_matches_constraint(s.get("value", ""), operator, constant)]
    pruned = len(setters) - len(kept)
    out["setters"] = kept
    out["value_constraint"] = f"{operator} {constant}"
    if pruned:
        out["pruned_setters"] = pruned  # off-path values (other switch cases)
    return out


def _attach_call_condition_deps(
    callers: List[Dict[str, Any]], blueprint_dir: Path, graph_file: Path, *,
    job_id: Optional[str], asm_dir: Optional[Path], max_depth: int, _depth: int,
    _visited: Set[str], pfl_cache: Dict[str, Any], ccd_cache: Dict[str, Any],
    max_ccd_depth: int = 5, _ccd_depth: int = 0,
) -> None:
    """Attach ``call_condition_deps`` to every hop in a caller tree.

    For each caller hop, extract the variables named in its ``call_conditions``
    and build their value+condition lineage — the same treatment a setter's own
    condition variables get.  Crucially this is **specific-value pruned**: when a
    call is gated by ``var == Value`` (e.g. a ``switch(task)`` ``case
    GlobalLimitsUpdate`` routing to the callee), only the ``var`` setters that
    assign ``Value`` are kept — the off-path values (other switch cases) are
    pruned, so the lineage stays on the path that actually reaches the setter.
    ``_trace_callers=False`` keeps these bounded (no caller re-expansion); each
    unique variable is traced once via ``ccd_cache`` then constraint-filtered.

    ``max_ccd_depth`` caps how many levels of nested caller trees are expanded
    (0 = unlimited).  ``_ccd_depth`` tracks the current recursion depth."""
    if max_ccd_depth > 0 and _ccd_depth >= max_ccd_depth:
        return
    for c in callers or []:
        cvars: List[str] = []
        for cc in c.get("call_conditions", []):
            cvars.extend(extract_condition_vars(str(cc)))
        deps: List[Dict[str, Any]] = []
        for cv in dict.fromkeys(cvars):
            if cv.upper() in _visited:
                continue
            key = cv.upper()
            if key not in ccd_cache:
                ccd_cache[key] = build_lineage(
                    cv, blueprint_dir, graph_file, job_id=job_id, asm_dir=asm_dir,
                    max_depth=max_depth, max_caller_depth=1,
                    _depth=_depth + 1, _visited=_visited, _pfl_cache=pfl_cache,
                    _trace_callers=False, _ccd_cache=ccd_cache,
                )
            base = ccd_cache[key]
            # Specific-value prune ONLY when the variable is the direct ==/!=
            # operand of a guard (``task == GlobalLimitsUpdate``).  A constraint
            # buried in a call/memcmp (``getCoreblocks(*p)==0``) must not prune.
            con = None
            for cc in c.get("call_conditions", []):
                cand = _direct_equality_constraint(str(cc), cv)
                if cand:
                    con = cand
                    break
            deps.append(_prune_to_constraint(base, con.operator, con.constant) if con else base)
        c["call_condition_deps"] = deps
        _attach_call_condition_deps(
            c.get("callers", []), blueprint_dir, graph_file, job_id=job_id,
            asm_dir=asm_dir, max_depth=max_depth, _depth=_depth, _visited=_visited,
            pfl_cache=pfl_cache, ccd_cache=ccd_cache,
            max_ccd_depth=max_ccd_depth, _ccd_depth=_ccd_depth + 1,
        )


def build_lineage(
    var: str,
    blueprint_dir: Path,
    graph_file: Path,
    *,
    job_id: Optional[str] = None,
    asm_dir: Optional[Path] = None,
    max_depth: int = 3,
    max_caller_depth: int = 2,
    _depth: int = 0,
    _visited: Optional[Set[str]] = None,
    _pfl_cache: Optional[Dict[str, Any]] = None,
    _trace_callers: bool = True,
    _ccd_cache: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Recursive value+condition lineage for ``var``.  ``max_depth`` 0 = unlimited.

    Each setter also gets ``reached_via``: the inter-procedural conditions — who
    calls the setter's function, under what condition, recursively up the call
    chain (``max_caller_depth``; 0 = unlimited)."""
    blueprint_dir = Path(blueprint_dir)
    graph_file = Path(graph_file)
    if _visited is None:
        _visited = set()
    if _pfl_cache is None:
        _pfl_cache = {}
        # Silence the expected "no seed nodes" chatter from seed resolution — a
        # dep that is an ASM-mapped field or a terminal simply has no C++ setter,
        # which we represent as an empty lineage (not an error).
        logging.getLogger("backward_traversal.utils.cpp_lineage_utils").setLevel(logging.ERROR)

    key = var.upper()
    node: Dict[str, Any] = {"var": var, "setters": [], "truncated": False}
    if key in _visited:
        node["cycle"] = True
        return node
    if max_depth and _depth >= max_depth:
        node["truncated"] = True
        return node
    _visited = _visited | {key}

    _t0 = time.monotonic()
    if _depth == 0:
        logger.info("[LINEAGE] build_lineage — var=%s — start", var)

    all_sites: List[Dict[str, Any]] = []
    for stem, ft in _candidate_files(var, blueprint_dir, graph_file, job_id):
        if ft == "asm":
            all_sites.extend(_asm_setters_in_file(var, stem, blueprint_dir, asm_dir))
        else:
            entry = _load_pfl(stem, blueprint_dir, _pfl_cache)
            if entry:
                all_sites.extend(_setters_in_file(var, stem, entry))

    # Cross-language: also search the variable's COUNTERPART in the other
    # language (reusing the existing counterpart resolver — e.g. an ASM field is
    # set via its C++ counterpart, or vice versa).  One hop, only at the top
    # level, to stay bounded — mirrors the enumerator's counterpart policy.
    node["counterparts"] = []
    if _depth == 0:
        try:
            from backward_traversal.utils.counterpart_resolver import resolve_counterpart
            for lang in ("asm", "cpp"):
                for cand in resolve_counterpart(var, lang, blueprint_dir, graph_file)[:4]:
                    cp = cand.counterpart_name
                    node["counterparts"].append({
                        "name": cp, "language": cand.counterpart_language,
                        "certainty": cand.certainty_label, "via": "cc_header",
                    })
                    cp_term = cp.split(".")[-1]
                    for stem, ft in _candidate_files(cp_term, blueprint_dir, graph_file, job_id):
                        new = (_asm_setters_in_file(cp_term, stem, blueprint_dir, asm_dir)
                               if ft == "asm" else
                               (_setters_in_file(cp_term, stem, _load_pfl(stem, blueprint_dir, _pfl_cache))
                                if _load_pfl(stem, blueprint_dir, _pfl_cache) else []))
                        for s in new:
                            s["counterpart_of"] = var
                            all_sites.append(s)
        except Exception:
            pass
    # De-dup setter sites discovered via both direct + counterpart search.
    _seen_sites: Set[Any] = set()
    _dedup: List[Dict[str, Any]] = []
    for s in all_sites:
        k = (s.get("file"), s.get("line"), s.get("value"), tuple(s.get("conditions") or []))
        if k not in _seen_sites:
            _seen_sites.add(k)
            _dedup.append(s)
    all_sites = _dedup

    if _depth == 0:
        logger.info("[LINEAGE] Collected %d setter sites — %.1fs",
                    len(all_sites), time.monotonic() - _t0)

    if _ccd_cache is None:
        _ccd_cache = {}
    for _si, s in enumerate(all_sites):
        reached_via = build_caller_chain(       # inter-procedural call conditions
            s.get("scope", ""), s["file"], blueprint_dir, graph_file,
            job_id=job_id, max_caller_depth=max_caller_depth, _depth=0,
            _visited={s.get("scope", "").upper()}, pfl_cache=_pfl_cache, asm_dir=asm_dir,
        ) if _trace_callers else []
        # Trace the VARIABLES inside each caller's call-conditions — symmetric with
        # the setter's own condition_deps.  This is what surfaces e.g. the `task`
        # dispatcher's value-logic (``task = GlobalLimitsUpdate`` when input
        # message+35 == "C400") up a cross-language caller chain.  Bounded:
        # call-condition deps don't re-expand callers (``_trace_callers=False``)
        # and each unique var is traced once via ``_ccd_cache``.  Only at the ROOT
        # (``_depth == 0``): the doc use-case is the queried variable's own caller
        # guards; doing it for every recursive dep multiplies caller-chain work
        # combinatorially (a real perf cliff on deep variables / 22k corpora).
        if _trace_callers and _depth == 0:
            _attach_call_condition_deps(
                reached_via, blueprint_dir, graph_file, job_id=job_id, asm_dir=asm_dir,
                max_depth=max_depth, _depth=_depth, _visited=_visited,
                pfl_cache=_pfl_cache, ccd_cache=_ccd_cache,
            )
        setter = {
            "file": s["file"], "line": s["line"], "value": s["value"],
            "function": s.get("scope", ""),
            "conditions": s["conditions"],          # intra-function (relevant path) guards
            "reached_via": reached_via,
            "condition_deps": [], "value_deps": [],
        }
        if s.get("value_unresolved"):
            setter["value_unresolved"] = True       # RHS literal not modeled by parser
        if s.get("counterpart_of"):
            setter["counterpart_of"] = s["counterpart_of"]
        # Recurse on the variables IN the conditions (specific-value / guard deps).
        for cv in s["condition_vars"]:
            setter["condition_deps"].append(
                build_lineage(cv, blueprint_dir, graph_file, job_id=job_id, asm_dir=asm_dir,
                              max_depth=max_depth, max_caller_depth=max_caller_depth,
                              _depth=_depth + 1, _visited=_visited, _pfl_cache=_pfl_cache)
            )
        # Value/data-flow deps: the COMPLETE per-(variable,file) dep set from the
        # existing components (register backtracking, indirect, bridge regs,
        # special patterns, counterpart/seed resolution).  Cached per file (one
        # component call), deduped against the guard deps, recursed cross-file
        # (and cross-language via the dep components' own counterpart handling).
        seen_dep: Set[str] = {d["var"].upper() for d in setter["condition_deps"]}
        full_deps = _tracer_dep_vars(var, s["file"], s.get("file_type", "cpp"), s,
                                     blueprint_dir, asm_dir, _pfl_cache)
        if s.get("value_dep") and s["value_dep"] not in full_deps:
            full_deps = [s["value_dep"]] + full_deps
        for dv in full_deps:
            term = dv.split("bridge:")[-1]
            if term.upper() in seen_dep:
                continue
            seen_dep.add(term.upper())
            setter["value_deps"].append(
                build_lineage(term, blueprint_dir, graph_file, job_id=job_id,
                              asm_dir=asm_dir, max_depth=max_depth,
                              max_caller_depth=max_caller_depth, _depth=_depth + 1,
                              _visited=_visited, _pfl_cache=_pfl_cache)
            )
        node["setters"].append(setter)
        if _depth == 0:
            logger.info("[LINEAGE] Processed setter %d/%d from %s — %.1fs",
                        _si + 1, len(all_sites), s.get("file", "?"),
                        time.monotonic() - _t0)

    # Union may-alias: a sibling union member shares this variable's storage, so
    # writing it may change this value (over-approximation — never misses).  It's
    # a property of the variable (applies to all its setters), so it lives at the
    # node level.  Reads the parser's ``union_members`` map via cha_resolver; a
    # tested no-op until a C++ re-ingest populates that map.
    node["may_alias_deps"] = []
    if not var.startswith("return@"):
        try:
            from backward_traversal.runner.cha_resolver import union_may_alias_siblings
            sibs: List[str] = []
            seen_sib: Set[str] = set()
            for stem, ft in _candidate_files(var, blueprint_dir, graph_file, job_id):
                if ft != "cpp":
                    continue
                entry = _load_pfl(stem, blueprint_dir, _pfl_cache)
                bp = (entry or {}).get("bp") or {}
                found, _marker = union_may_alias_siblings(bp, var)
                for m in found:
                    if m.upper() != key and m.upper() not in seen_sib:
                        seen_sib.add(m.upper())
                        sibs.append(m)
            for sib in sibs:
                if sib.upper() in _visited:
                    continue
                node["may_alias_deps"].append(
                    build_lineage(sib, blueprint_dir, graph_file, job_id=job_id,
                                  asm_dir=asm_dir, max_depth=max_depth,
                                  max_caller_depth=max_caller_depth, _depth=_depth + 1,
                                  _visited=_visited, _pfl_cache=_pfl_cache)
                )
        except Exception:
            pass
    if _depth == 0:
        n_conds = sum(1 for s in node["setters"] if s.get("conditions"))
        logger.info("[LINEAGE] Done — %d setters, %d with conditions — %.1fs",
                    len(node["setters"]), n_conds, time.monotonic() - _t0)
    return node


def _value_kind(value: str) -> str:
    v = str(value or "").strip()
    if not v:
        return "unknown"
    if "::" in v:
        return "enum"                       # Type::Value
    if v[:1].isdigit() or v.startswith(("=", "X'", "0x", "C'", "P'")):
        return "literal"
    if v[:1].isupper() or v.startswith(("LG#", "@")):
        return "constant"                   # named ASM/enum constant
    if v[:1].islower():
        return "variable"
    return "computed"


def enrich_for_explainability(
    node: Dict[str, Any], blueprint_dir: Path, graph_file: Path,
    *, asm_dir: Optional[Path] = None, job_id: Optional[str] = None,
    _cache: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Transform a raw lineage node into an explainability-ready structure.

    Pure presentation over the already-built lineage (no new traversal except
    cheap deterministic terminal classification on leaves).  Each setter gets:
    value + value_kind, structured conditions (raw+operator+constant), a unified
    ``dependent_variables`` list (each tagged kind=conditional_guard|data_flow
    with a ``why`` and its recursive lineage), ``reached_via`` caller conditions,
    and — for leaf variables with no setters — a terminal classification
    (input/db_record/constant/system) via the existing classifier.
    """
    from backward_traversal.runner.chainless_dep_resolver import extract_constraint
    if _cache is None:
        _cache = {}

    var = node.get("var", "")
    setters = node.get("setters", [])
    out: Dict[str, Any] = {"variable": var, "setters": []}

    # Leaf (no setters discovered) → terminal classification (reuse, deterministic).
    if not setters and not node.get("cycle") and not node.get("truncated"):
        out["terminal"] = _classify_terminal(var, blueprint_dir, asm_dir, graph_file, _cache)
    if node.get("cycle"):
        out["cycle"] = True
    if node.get("truncated"):
        out["truncated"] = True
    if node.get("counterparts"):
        out["counterparts"] = node["counterparts"]
    # Union may-alias siblings — a variable-level relation (alternate storage
    # writers), surfaced alongside counterparts rather than per-setter.
    if node.get("may_alias_deps"):
        out["may_alias"] = [
            {"name": d["var"], "kind": "may_alias",
             "why": "shares storage with this variable (union member); writing it may change this value",
             "lineage": enrich_for_explainability(d, blueprint_dir, graph_file,
                                                  asm_dir=asm_dir, job_id=job_id, _cache=_cache)}
            for d in node["may_alias_deps"]
        ]

    for s in setters:
        conds = [_structure_condition(c, extract_constraint) for c in s.get("conditions", [])]
        deps: List[Dict[str, Any]] = []
        for d in s.get("condition_deps", []):
            deps.append({"name": d["var"], "kind": "conditional_guard",
                         "why": "gates whether this value is assigned",
                         "lineage": enrich_for_explainability(d, blueprint_dir, graph_file,
                                                              asm_dir=asm_dir, job_id=job_id, _cache=_cache)})
        for d in s.get("value_deps", []):
            deps.append({"name": d["var"], "kind": "data_flow",
                         "why": "the assigned value is derived from it",
                         "lineage": enrich_for_explainability(d, blueprint_dir, graph_file,
                                                              asm_dir=asm_dir, job_id=job_id, _cache=_cache)})
        entry = {
            "file": s.get("file"), "line": s.get("line"), "function": s.get("function"),
            "value": s.get("value"),
            "value_kind": "literal" if s.get("value_unresolved") else _value_kind(s.get("value", "")),
            "conditions": conds,
            "dependent_variables": deps,
            "reached_via": _enrich_callers(s.get("reached_via", []), extract_constraint,
                                           blueprint_dir, graph_file, asm_dir, job_id, _cache),
        }
        if s.get("value_unresolved"):
            # The site is a real write to a constant whose literal RHS the parser
            # does not model as a node (e.g. ``= 0x00`` init) — surfaced, not dropped.
            entry["value_unresolved"] = True
        out["setters"].append(entry)
    return out


def _structure_condition(cond: str, extract_constraint) -> Dict[str, Any]:
    c = extract_constraint(str(cond))
    return {"raw": c.raw, "operator": c.operator, "constant": c.constant,
            "variables": extract_condition_vars(str(cond))}


def _enrich_callers(callers: List[Dict[str, Any]], extract_constraint,
                    blueprint_dir: Path, graph_file: Path, asm_dir: Optional[Path],
                    job_id: Optional[str], cache: Dict[str, Any]) -> List[Dict[str, Any]]:
    out = []
    for c in callers:
        # The variables inside each call-condition, traced (specific-value pruned)
        # — e.g. why the caller routes here: ``task == GlobalLimitsUpdate`` set
        # only when input message+35 == "C400".  Symmetric with a setter's deps.
        ccd = []
        for d in c.get("call_condition_deps", []):
            entry = {"name": d.get("var"), "kind": "caller_guard",
                     "why": "the caller reaches this callee only when this variable holds the gating value",
                     "lineage": enrich_for_explainability(d, blueprint_dir, graph_file,
                                                          asm_dir=asm_dir, job_id=job_id, _cache=cache)}
            if d.get("value_constraint"):
                entry["value_constraint"] = d["value_constraint"]
            if d.get("pruned_setters"):
                entry["pruned_off_path_setters"] = d["pruned_setters"]
            ccd.append(entry)
        out.append({
            "caller_function": c.get("caller_function"), "caller_file": c.get("caller_file"),
            "call_line": c.get("call_line"),
            "call_conditions": [_structure_condition(x, extract_constraint)
                                for x in c.get("call_conditions", [])],
            "call_condition_deps": ccd,
            "cycle": c.get("cycle", False),
            "callers": _enrich_callers(c.get("callers", []), extract_constraint,
                                       blueprint_dir, graph_file, asm_dir, job_id, cache),
        })
    return out


def _classify_terminal(var: str, blueprint_dir: Path, asm_dir: Optional[Path],
                       graph_file: Path, cache: Dict[str, Any]) -> Dict[str, Any]:
    ck = ("term", var.upper())
    if ck in cache:
        return cache[ck]
    role: Dict[str, Any] = {"role": "unknown"}
    try:
        from backward_traversal.enrichment.terminal_classifier import classify_terminal_variables
        res = classify_terminal_variables([(var, None, None, None)], blueprint_dir, asm_dir,
                                          graph_file, use_llm=False)
        if res:
            role = {k: res[0].get(k) for k in ("var_name", "role", "confidence", "evidence")
                    if k in res[0]}
    except Exception:
        pass
    cache[ck] = role
    return role


def flatten_summary(node: Dict[str, Any]) -> Dict[str, Any]:
    """Compact stats for quick inspection / assertions."""
    setters = node.get("setters", [])
    return {
        "var": node["var"],
        "n_setters": len(setters),
        "files": sorted({s["file"] for s in setters}),
        "values": sorted({s["value"] for s in setters if s["value"]}),
        "n_with_conditions": sum(1 for s in setters if s["conditions"]),
    }
