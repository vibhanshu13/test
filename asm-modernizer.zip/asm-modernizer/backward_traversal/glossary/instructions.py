"""Backward-only instruction glossary (isolated from legacy/simple pipelines)."""

# SETTER_INST — authoritative 65-member set per SETTER_INST_COMPLETE.md audit
# (IBM z/Architecture PoO SA22-7832-12).  THIS SET MUST STAY BYTE-FOR-BYTE
# IDENTICAL to the copies in trace_lineage.py (stage-1) and process/instructions.py
# (stage-3).  A storage-destination instruction belongs here; register-destination
# loads (L/LR/LG/IC/ICM/LA…) live in REGISTER_LOAD_FROM_MEM / REGISTER_COPY_FROM_REG /
# REGISTER_LOAD_ADDRESS instead.  Removed vs. legacy: register loads, AH/AHI/AR/AG…,
# CVB (data-flow inverted), TRT (operand unchanged), API/SPI (phantom mnemonics).
SETTER_INST = {
    "AGSI", "ALGSI", "ALSI", "AP", "ASI",
    "CVD", "CVDG", "CVDY",
    "DP", "ED", "EDMK",
    "MP", "MVC", "MVCIN", "MVGHI", "MVHHI", "MVHI", "MVI", "MVIY", "MVN", "MVO", "MVZ",
    "NC", "NI", "NIY",
    "OC", "OI", "OIY",
    "PACK", "PKA", "PKU",
    "SP", "SRP", "ST", "STC", "STCK", "STCKF", "STCM", "STCMH", "STCMY",
    "STCY", "STEY", "STFLE", "STG", "STGRL", "STH", "STHRL", "STHY",
    "STM", "STMG", "STMH", "STMY", "STRL", "STRV", "STRVG", "STRVH", "STY",
    # UNPK self-op (UNPK FIELD(L1),FIELD(L2)) is a known gap: normalize_token cannot
    # distinguish length-differing same-base operands, so the source dep is filtered.
    "TR", "UNPK", "UNPKA", "UNPKU",
    "XC", "XI", "XIY",
    "ZAP",
    # MVCL / MVCP / MVCS omitted (GAP-006): their destination operand is a register
    # holding the buffer address, not a named variable (see REGISTER_INDIRECT_MOVE_INST).
}

TRIGGER_INST = {
    "CLC", "CLI", "CLIY", "TM", "TMY", "CP", "LTR", "C", "CR", "CH", "CL", "CLR",
    # Y-displacement forms
    "CLM", "CLMY",
    # GAP-026: 64-bit z/Architecture compare variants
    "CGR", "CG", "CGF",                 # 64-bit compare register / memory
    "CGHI", "CHI", "CFI",              # compare halfword/fullword immediate
    "CLGR", "CLG", "CLFI", "CLGFI",   # compare logical 64-bit / immediate
    "LTGR",                            # load-and-test 64-bit (LTR already present above)
    # GAP-CC-LOAD: Load-and-Test from memory (PoO §7-152/153).  args[0]=register
    # (dest), args[1]=memory (source).  dep_vars_from_args filters the register,
    # leaving the memory field as the dependency.
    "LT", "LTG",
    # GAP-CC-ICM: Insert Characters under Mask (PoO §7-144) sets CC.
    # args[0]=reg, args[1]=mask (literal), args[2]=memory source.
    "ICM",
    # GAP-CC-TRT: Translate and Test (PoO §7-228) scans input string via translate
    # table and sets CC.  args[0]=input string (dep), args[1]=table (suppress via
    # MASK_TRIGGER_AT_ARG1).
    "TRT",
    # GAP-CC-CLCL: Compare Logical Characters Long / Extended (PoO §7-69/70).
    # Register-indirect comparison; register operands resolved via backtracking.
    "CLCL", "CLCLE",
    # GAP-027: logical self-ops used as zero-tests in HLASM
    # OC field,field / NC field,field set CC=0 when field is all zeros; typically
    # followed by BZ/BNZ to guard cross-file calls.  Functionally equivalent to
    # CLC field,ZEROS but written without a ZEROS constant label.
    "OC", "NC",
}

# Trigger instructions whose args[1] is ALWAYS a constant (bitmask for TM/TMY,
# comparand for CLI/CLIY, translate table for TRT), never a data-flow variable.
# The TRIGGER branch of _collect_dep_vars harvests only args[0] for these.
MASK_TRIGGER_AT_ARG1 = {"TM", "TMY", "CLI", "CLIY", "TRT"}

BRANCH_INST = {
    "B", "BE", "BNE", "BZ", "BNZ", "BH", "BNH", "BM", "BNM", "BO", "BNO", "BP", "BNP", "BCT",
    # 64-bit count and index-loop branches (z/Architecture PoP)
    "BCTG",
    "BXH", "BXLE", "BXHG", "BXLEG",
    # Relative branch forms
    "BRCT", "BRCTG", "BRXH", "BRXLE",
    "J", "JE", "JNE", "JZ", "JNZ", "JH", "JNH", "JL", "JNL", "JM", "JNM", "JO", "JNO", "JP", "JNP",
"JXHG", "JXLE", "BC",
    # GAP-021: z/Architecture extended branch mnemonics (RIL/RIC forms of BC/BCL)
    "BRC", "BRCL",
    # GAP-BCTR (audit BRANCH_INST_findings.md): BCTR removed — it is RR-format
    # (BCTR R1,R2); its operand is a register, never a label, and the dominant
    # `BCTR Rx,0` form never branches (PoO §7-49).  Leaving it here poisoned CFG
    # construction (`args[-1]` yielded '0'/a register).  The label-bearing count
    # branch BCT stays above.
}

SUBROUTINE_CALL_OPCODES = {
    "BAS", "BAL", "BASR",
    "BALR",   # Branch and Link Register — used for register-based indirect subroutine calls
    # GAP-022: z/Architecture relative-branch subroutine call forms
    "BRAS",   # Branch Relative and Save (RIL short, like BAS but PC-relative)
    "BRASL",  # Branch Relative and Save Long (RIL long)
    # GAP-JAS: z/Architecture 64-bit relative-branch subroutine call forms (RIL encoding).
    # Functionally identical to BAS/BRAS but use a 31-bit PC-relative offset instead of
    # base+displacement.  Seen in ae48.asm: JAS R14,UA80COV1 / JAS R6,LEAPYEAR.
    "JAS",    # Jump and Save (RIL-b short — 31-bit offset)
    "JASL",   # Jump and Save Long (RIL-b long — 32-bit offset)
}
SUBROUTINE_INST = set(SUBROUTINE_CALL_OPCODES)

# GAP-006: register-indirect move instructions excluded from SETTER_INST.
# Their destination is a register pair holding the buffer address, not a named variable.
# When encountered in scope_blocks, emit a warning rather than silently skipping.
REGISTER_INDIRECT_MOVE_INST = {"MVCL", "MVCP", "MVCS"}

# EX/EXRL execute a target instruction at a label (e.g. EX R3,MYMVC runs
# MYMVC MVC DEST,SRC).  The EX OR modifies only the length byte (bits 8-15
# of the target instruction), NOT operand addresses, so dep_vars are those
# of the target instruction.  Previously tagged as static_analysis_limit.
EXECUTE_INST = {"EX", "EXRL"}

# Return-like operations used only for backward-only subroutine anchor heuristics.
# These are intentionally broad because different asm sources use different return idioms.
# GAP-006/Case-6: EXITC is NOT a subroutine return — it terminates the entire ECB with no
# continuation.  Grouping it with BR/BACKC caused _return_anchor_lines_from_source to treat
# a hard program-exit as a subroutine boundary, creating false return edges.  EXITC now lives
# in PROGRAM_EXIT_OPCODES so callers can handle it separately.
RETURN_OPCODES = {
    "BR", "BCR", "PR", "BSM", "BASR", "BACKC", "RETURN",
}

# GAP-006/Case-6: Hard program-exit opcodes that terminate the ECB with no return to any caller.
# Must NOT be used as subroutine return anchors or fallthrough-prevention markers.
PROGRAM_EXIT_OPCODES = {"EXITC"}

# Cross-file call opcodes that transfer control to another segment.
# ENTNC/ENTDC are non-returning, CREEC/CREMC are async spawns, but all are
# cross-file call opcodes for purposes of file_call_graph.json edge collection.
# Their semantic differences are captured by CallType in call_graph_builder.py
# and by the separate NON_RETURNING_CALL_OPCODES / ASYNC_CALL_OPCODES sets below.
# P33: CALLC is IBM's preferred typed C call from ASM (z/TPF).
# GAP-037: EXSR (Execute Subroutine) is a z/TPF cross-file call opcode used widely in
# legacy mainframe code. Without it all EXSR calls were silently skipped.
# ENTRY is an HLASM assembler directive that marks a label as externally callable.
# It is NOT a call opcode and must not be treated as a cross-file edge source (GAP-014).
CROSS_FILE_CALL_OPCODES = {"ENTRC", "ENTNC", "ENTDC", "CREEC", "CREMC", "CREDC", "CRETC", "CREXC", "CRESC",
                           "SWISC", "EXSR", "FUNCTION", "CALLC", "CALLCPP", "CLINKC"}
CROSS_FILE_INST = CROSS_FILE_CALL_OPCODES

# GAP-Case-7: Non-returning cross-file calls.  ENTDC drops all previous programs from the ECB
# (no continuation back to caller).  ENTNC chains to another segment with no expected return.
# Neither must generate a backward return edge in the CFG or Phase-2 path construction.
NON_RETURNING_CALL_OPCODES = {"ENTDC", "ENTNC"}

# GAP-Case-3: Async ECB-creation calls.  CREEC/CREMC/CREDC spawn an independent new ECB and
# return immediately to the next instruction in the creator — the spawned segment never returns
# to its creator.  Treating these as synchronous ENTRC calls contaminated Phase-2 paths and
# Phase-3 scope with code from a parallel, unrelated execution.
ASYNC_CALL_OPCODES = {"CREEC", "CREMC", "CREDC", "CRETC", "CREXC"}

# CRESC creates a synchronous entry and suspends the current ECB until the spawned entry
# completes.  Unlike CREEC/CREMC/CREDC (fire-and-forget), the caller blocks — semantically
# a blocking call that creates a new execution context.
SYNC_SPAWN_CALL_OPCODES = {"CRESC"}

# IBM-documented program linkage macros for C-callable BAL functions.
# CLINKC = call linkage (cross-file call), RLINKC = return linkage, SLINKC = save/prologue.
LINKAGE_MGMT_OPCODES = {"CLINKC", "RLINKC", "SLINKC"}

# GAP-Case-4: Macro-style calls with non-standard control flow.  TMSMA performs a table
# operation and transfers to the label given by RTA=, which is a data area adjacent to the
# continuation label — continuation falls through naturally and needs no extra CFG edge.
# Listed here so phases can assign role "MACRO_CALL" instead of treating TMSMA as opaque.
MACRO_CALL_OPCODES = {"TMSMA"}

# ── Instruction categories for shared-variable pattern classification ─────────
# These sets are used by the backward traversal to classify instructions that
# participate in cross-language shared-variable patterns (P7–P44).  They are
# informational annotations and do NOT directly control setter/trigger detection.

# P37: FLIPC Dn,Dm — swaps content of data levels n and m.  After FLIPC the
# block previously at CE1CRn is accessible via CE1CRm and vice versa.
LEVEL_SWAP_INST: set = {"FLIPC"}

# P14, P39: GETCC/GETFC — allocate a core or file data level block; result
# pointer returned in R14 (GETCC) or R14/R1 (GETFC).
LEVEL_ALLOC_INST: set = {"GETCC", "GETFC", "MALOC"}

# Pattern H: CALOC — heap (non-ECB-level) block allocation; result in R1.
# Distinct from LEVEL_ALLOC_INST because CALOC does not operate on ECB data
# levels — it allocates raw heap memory outside the data-level framework.
HEAP_ALLOC_INST: set = {"CALOC"}

# P16, P40: RELCC/RELFC/RCRFC — release core level, file level, or combined.
LEVEL_RELEASE_INST: set = {"RELCC", "RELFC", "RCRFC", "FREEC",
    "CRUSA",   # GAP-P16: CRUSA Sn=level is a multi-level shorthand for RELCC
}

# P15: DETAC/ATTAC — transfer ownership of a data level between programs.
LEVEL_TRANSFER_INST: set = {"DETAC", "ATTAC"}

# P38: LEVTA/LEVTB — test whether a data level is occupied.  Result in R15.
LEVEL_TEST_INST: set = {"LEVTA", "LEVTB"}

# P43: FIWHC/FINHC/FINDC/FINWC — find-with-hold or find-no-hold on a file;
# combines database I/O with data-level allocation; result pointer in R14.
FILE_FIND_INST: set = {"FIWHC", "FINHC", "FINDC", "FINWC", "FILEC"}

# P44: DBWAIT — wait for a previously issued prefetch to complete.
DB_SYNC_INST: set = {"DBWAIT"}

# P36: TXBGC/TXCMC/TXRBC/TXSPC/TXRSC — transaction lifecycle macros.
# These control commit-scope visibility, not data flow between variables.
TRANSACTION_INST: set = {"TXBGC", "TXCMC", "TXRBC", "TXSPC", "TXRSC"}

REGISTERS = {f"R{i}" for i in range(16)}

# z/TPF standard register EQUates: the alternate names TPF programs address the same
# 16 GPRs by (globally defined by the standard register macro, so a same-named DATA
# symbol could not even assemble). Observed in a real corpus both as base registers
# (``0(L'TYPE0100,RGC)``) and — before this filter — as fake terminal lineage nodes
# classified "constant" purely because register EQUs sit in the EQU table. EXACT
# names only, per GAP-023: no R[A-Z]-style pattern (RB/RACK/RATE are valid HLASM
# variable names). RG0-RG7 + RGA-RGF + RAC + RDA is the complete 16-name set.
TPF_REGISTER_EQUATES = (
    {f"RG{i}" for i in range(8)} | {f"RG{c}" for c in "ABCDEF"} | {"RAC", "RDA"}
)
REGISTERS |= TPF_REGISTER_EQUATES

# Maps instruction names to the argument index that holds the memory destination.
# Defaults to 0 (first operand) for every instruction not listed here.
# Mirrors trace_lineage.DEST_ARG_INDEX_BY_INST.
DEST_ARG_INDEX_BY_INST = {
    "ST":    1,  # ST   Rsrc, mem    → mem is args[1]
    "STH":   1,  # STH  Rsrc, mem    → mem is args[1]
    "STC":   1,  # STC  Rsrc, mem    → mem is args[1]
    "CVD":   1,  # CVD  Rsrc, mem    → mem is args[1]
    "CVDG":  1,  # CVDG Rsrc, mem    → mem is args[1]  (E32E RXY)
    "CVDY":  1,  # CVDY Rsrc, mem    → mem is args[1]  (E326 RXY)
    "STM":   2,  # STM  Rlo, Rhi, mem  → mem is args[2]
    "STMG":  2,  # STMG Rlo, Rhi, mem  → mem is args[2] (64-bit equivalent of STM)
    "STMH":  2,  # STMH Rlo, Rhi, mem  → mem is args[2]  (EB26 RSY)
    "STMY":  2,  # STMY Rlo, Rhi, mem  → mem is args[2]  (EB90 RSY)
    "STCM":  2,  # STCM Rsrc, mask, mem → mem is args[2]
    "STCMH": 2,  # STCMH Rsrc, mask, mem → mem is args[2]  (EB2C RSY)
    "STCMY": 2,  # STCMY Rsrc, mask, mem → mem is args[2]  (EB2D RSY)
    # GAP-026: 64-bit store variants have the same operand layout as their 32-bit counterparts
    "STG":   1,  # STG  Rsrc, mem    → mem is args[1]
    "STY":   1,  # STY  Rsrc, mem    → mem is args[1]
    "STHY":  1,  # STHY Rsrc, mem    → mem is args[1]
    "STCY":  1,  # STCY Rsrc, mem    → mem is args[1]
    "STGRL": 1,  # STGRL Rsrc, mem   → mem is args[1]
    "STRL":  1,  # STRL  Rsrc, label → label is args[1]  (C4F RIL)
    "STHRL": 1,  # STHRL Rsrc, label → label is args[1]  (C47 RIL)
    "STRV":  1,  # STRV  Rsrc, mem   → mem is args[1]  (E33E RXY byte-reversed)
    "STRVG": 1,  # STRVG Rsrc, mem   → mem is args[1]  (E32F RXY byte-reversed)
    "STRVH": 1,  # STRVH Rsrc, mem   → mem is args[1]  (E33F RXY byte-reversed)
    "STEY":  1,  # STEY  FPRsrc, mem → mem is args[1]  (ED66 RXY short FP store)
}

# GAP-REG: Maps memory-to-register load instructions to the source memory operand index.
# LA / LAY intentionally excluded — they load addresses, not variable values.
REGISTER_LOAD_FROM_MEM = {
    "L":   1,   # L   Rd, mem
    "LH":  1,   # LH  Rd, mem
    "LG":  1,   # LG  Rd, mem (64-bit)
    "LGF": 1,   # LGF Rd, mem
    "LY":  1,   # LY  Rd, mem (RXY)
    "LHY": 1,   # LHY Rd, mem (RXY)
    "IC":  1,   # IC  Rd, mem (insert char)
    "ICM": 2,   # ICM Rd, mask, mem → args[2]
    # C4.2 fix: additional 64-bit and test-and-load variants
    "LGH": 1,   # LGH Rd, mem (Load Halfword Long — 16-bit, sign-extend to 64-bit)
    "LT":  1,   # LT  Rd, mem (Load and Test — 32-bit, also sets CC)
    "LTG": 1,   # LTG Rd, mem (Load and Test Long — 64-bit, also sets CC)
    # Moved out of SETTER_INST (audit §8 step 1): 64-bit load-relative-long are
    # register-destination loads, not storage setters.
    "LGFRL": 1, # LGFRL Rd, label (load 32→64 from PC-relative storage)
    "LGRL":  1, # LGRL  Rd, label (load 64-bit from PC-relative storage)
}

# GAP-REG: Maps register-to-register copy instructions to the source register operand index.
REGISTER_COPY_FROM_REG = {
    "LR":   1,  # LR   Rd, Rs
    "LGR":  1,  # LGR  Rd, Rs (64-bit)
    "LGFR":  1,  # LGFR  Rd, Rs
    "LLGFR": 1,  # LLGFR Rd, Rs (zero-extend Rs into Rd; 64-bit register-to-register copy)
    "LTGR":  1,  # LTGR  Rd, Rs (Load and Test Long Register — sets CC and copies Rs → Rd)
    "LTR":   1,  # LTR   Rd, Rs (Load and Test Register — sets CC and copies Rs → Rd)
}

# GAP-REG: Load-address instructions place an effective address (not a stored value)
# into a register.  Excluded from SETTER_INST (their dest is a register); tracked here
# so register-aware back-tracking can still recognise them as address producers.
REGISTER_LOAD_ADDRESS = {
    "LA":  1,   # LA  Rd, addr  (RX)
    "LAY": 1,   # LAY Rd, addr  (RXY long-displacement)
}

# EQU-COPY-MEMBER BYPASS (audit §5 Fix #3 / §6): per-instruction source-argument
# suppression indexes into the ORIGINAL args[] list (before dest removal).  Covers
# operand positions that are ALWAYS functional constants (immediates, masks, shift
# counts, translate tables), never data-flow variables.  Literal forms (X'nn',
# B'nnnn', digit) are already blocked by token_utils; this table covers symbolic
# EQU names from COPY members that escape those filters.
#   NI/OI/XI §7-25/180/142, MVI §7-163, MVIY/NIY/OIY/XIY §7-163/25/180/142 (SIY),
#   ASI/AGSI/ALSI/ALGSI §7-21, MVHI/MVHHI/MVGHI §7-163 (SIL), STCM/STCMH/STCMY §7-212/213,
#   TR §7-225 (256-byte translate table), SRP §8-12 (shift count + rounding digit).
SRC_ARG_SUPPRESS_BY_INST: dict = {
    "NI":    frozenset({1}),
    "OI":    frozenset({1}),
    "XI":    frozenset({1}),
    "MVI":   frozenset({1}),
    "MVIY":  frozenset({1}),
    "NIY":   frozenset({1}),
    "OIY":   frozenset({1}),
    "XIY":   frozenset({1}),
    "ASI":   frozenset({1}),
    "AGSI":  frozenset({1}),
    "ALSI":  frozenset({1}),
    "ALGSI": frozenset({1}),
    "MVHI":  frozenset({1}),
    "MVHHI": frozenset({1}),
    "MVGHI": frozenset({1}),
    "STCM":  frozenset({1}),
    "STCMH": frozenset({1}),
    "STCMY": frozenset({1}),
    "TR":    frozenset({1}),
    "SRP":   frozenset({1, 2}),
}

# GAP-028: SI/SIY/SIL-format instructions whose second operand (args[1]) is
# ALWAYS a compile-time immediate constant.  EQU labels used as masks/immediates
# for these instructions (e.g. LG#C400 in "OI LG1OSI,LG#C400") may come from
# COPY members that the blueprint parser doesn't capture in the symbol table.
# Rather than failing the constant-source check, we recognise these instructions
# directly: if the setter_expression is derived from args[1] for one of these
# instructions, it must be a constant regardless of whether it appears in
# collect_constant_symbols().
# Excluded:
#   STCM/STCMH/STCMY — mask at args[1] is constant, but source (reg) determines value
#   TR               — translate table constant but output depends on input bytes
#   SRP              — shift count constant but output depends on input decimal value
IMMEDIATE_OPERAND_SETTER_INST: frozenset = frozenset({
    "NI", "OI", "XI",           # SS/SI: logical immediate (AND/OR/XOR byte)
    "NIY", "OIY", "XIY",        # SIY: long-displacement variants
    "MVI",                       # SI: Move Immediate — pure constant store
    "MVIY",                      # SIY: long-displacement MVI
    "ASI", "AGSI",               # SIY: Add Immediate (32/64-bit signed)
    "ALSI", "ALGSI",             # SIY: Add Logical with Signed Immediate
    "MVHI", "MVHHI", "MVGHI",   # SIL: Move Halfword Immediate (16-bit signed constant)
})

# HLASM assembler-defined absolute built-in symbols.  These resolve to fixed byte
# values (e.g. SPACE=X'40') and must never appear as dep_vars regardless of the
# instruction that references them.  Unioned into constant_symbols at build time.
HLASM_BUILTIN_SYMBOLS = {
    "SPACE", "LOW", "HIGH", "NULL", "NL", "LF", "CR", "HT", "VT", "FF",
    "BS", "BEL", "ESC", "DEL", "SUB",
}

# P14: Allocation macros that implicitly store the result in a specific register.
# GETCC/GETFC macro expansion loads the allocated block pointer into R14.
# FILE_FIND_INST macros (FIWHC, FINHC, etc.) also return the allocated file block in R14.
# CALOC heap allocation stores the block address in R1 (not R14).
# Used by _backtrack_register_dep_vars to recognise implicit register producers.
ALLOC_RESULT_REG = {
    "GETCC": "R14", "GETFC": "R14", "MALOC": "R14",
    "FIWHC": "R14", "FINHC": "R14", "FINDC": "R14", "FINWC": "R14",
    # Pattern H: CALOC ESIZE=Rx,COUNT=R1 — heap block address returned in R1
    "CALOC": "R1",
}

# P17-P18: DB context instructions that implicitly set R3 to the SW00SR / context address.
# DBOPN opens a file and returns the switch-word address in R3; DBIFB/DBRED/DBIFD similarly.
# Used by _backtrack_register_dep_vars to recognise implicit R3 producers.
DB_CONTEXT_REG = {
    "DBOPN": "R3", "DBIFB": "R3", "DBRED": "R3", "DBIFD": "R3",
    "DBSPA": "R3", "DBCLS": "R3",
}

# P14/P15/P16: Level designator (D0–DF) → canonical ECB field name mappings.
# Shared between backward_only_runner.py (setter-site detection) and
# asm_backward_tracer.py (_backtrack_register_dep_vars) without circular imports.
LEVEL_TO_CE1CR = {
    "D0": "CE1CR0", "D1": "CE1CR1", "D2": "CE1CR2", "D3": "CE1CR3",
    "D4": "CE1CR4", "D5": "CE1CR5", "D6": "CE1CR6", "D7": "CE1CR7",
    "D8": "CE1CR8", "D9": "CE1CR9", "DA": "CE1CRA", "DB": "CE1CRB",
    "DC": "CE1CRC", "DD": "CE1CRD", "DE": "CE1CRE", "DF": "CE1CRF",
}
LEVEL_TO_CE1DT = {
    "D0": "CE1DT0", "D1": "CE1DT1", "D2": "CE1DT2", "D3": "CE1DT3",
    "D4": "CE1DT4", "D5": "CE1DT5", "D6": "CE1DT6", "D7": "CE1DT7",
    "D8": "CE1DT8", "D9": "CE1DT9", "DA": "CE1DTA", "DB": "CE1DTB",
    "DC": "CE1DTC", "DD": "CE1DTD", "DE": "CE1DTE", "DF": "CE1DTF",
}

# P19: DB-managed work area macros that implicitly set a specific named field.
# DBSPA REF=file allocates an initialized work area and stores its address in SW00WKA
# (accessible as file->sw00wka in C++ or via USING SW00SR,R3 in ASM).
# P17/P18: All DB I/O macros (DBOPN, DBRED, DBCLS, DBMOD, DBWRT, DBDLT, DBIFB,
# DBIFD) write their completion/error return code into SW00RTN on every invocation.
# Code tests SW00RTN after each DB operation (e.g. CLI SW00RTN,#ACPDBOK).
DB_MANAGED_FIELD_WRITES = {
    "DBSPA": "SW00WKA",   # P19: DBSPA implicitly writes SW00WKA in the open DB context
    # P17: DB open/read/write/close all write their return code to SW00RTN
    "DBOPN": "SW00RTN",   "DBRED": "SW00RTN",   "DBCLS": "SW00RTN",
    "DBMOD": "SW00RTN",   "DBWRT": "SW00RTN",   "DBDLT": "SW00RTN",
    # P18: DBIFB/DBIFD retrieve an open-file context; also write SW00RTN
    "DBIFB": "SW00RTN",   "DBIFD": "SW00RTN",
}

# P42: Macros that always write to a fixed ECB result field regardless of operands.
# TMSMA (Table Management System Macro) always writes its return code to EBL8URTN.
MACRO_FIXED_RESULT_FIELD = {
    "TMSMA": "EBL8URTN",  # TMSMA table lookup writes result/return-code to EBL8URTN
}

# P9: CREEC/CREMC/CREDC pass initial parameter block addresses as R14=/R15= keyword args
# within the call instruction itself (not as preceding register pre-loads).
# _collect_pre_call_dep_vars extracts these to surface the named parameter areas as dep_vars.
CREEC_PARAM_KEYWORDS: frozenset = frozenset({"R14", "R15"})

# P20: DB key-list instructions.  DBKEY KEYLIST=VAR fills the named key list work area.
# DBSETK fills key list fields; the base is a register (not a named variable), so only
# DBKEY (which takes a named KEYLIST=VAR operand) is captured here.
DB_KEYLIST_INST = {"DBKEY"}

# P8/P30: Cross-file call instructions that may be preceded by register pre-loads.
# These are the same as CROSS_FILE_CALL_OPCODES but listed separately so
# _collect_pre_call_dep_vars can import them without circular dependencies on CROSS_FILE_INST.
PRE_CALL_OPCODES = {
    "ENTRC", "ENTNC", "ENTDC", "CALLC", "CREEC", "CREMC", "CREDC",
    "EXSR", "FUNCTION",
    # GAP-PRECALL (audit): the async/sync-spawn family CRETC/CREXC/CRESC also
    # carries R14=/R15= parameter-block keywords, like CREEC/CREMC/CREDC above,
    # so pre-call register dep-vars must be harvested for them too.
    "CRETC", "CREXC", "CRESC",
}
