"""Backward call-site tracing for ASM upstream files (isolated mode)."""

from __future__ import annotations

import os
import re
from collections import deque
import bisect
from functools import lru_cache
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional, Set, Tuple

from backward_traversal.glossary.instructions import (
    ASYNC_CALL_OPCODES,
    ALLOC_RESULT_REG,
    BRANCH_INST,
    CROSS_FILE_INST,
    DB_CONTEXT_REG,
    DEST_ARG_INDEX_BY_INST,
    EXECUTE_INST,
    MACRO_CALL_OPCODES,
    NON_RETURNING_CALL_OPCODES,
    LEVEL_TO_CE1CR,
    MASK_TRIGGER_AT_ARG1,
    REGISTER_COPY_FROM_REG,
    REGISTER_LOAD_FROM_MEM,
    RETURN_OPCODES,
    SETTER_INST,
    SRC_ARG_SUPPRESS_BY_INST,
    SUBROUTINE_INST,
    REGISTER_INDIRECT_MOVE_INST,
    TRIGGER_INST,
)
from backward_traversal.glossary.special_cases import classify_setter, PATTERN_NEXT_INSTS
from backward_traversal.utils.blueprint_utils import (
    build_asm_block_source_index,
    collect_constant_symbols,
    load_json,
    resolve_ex_target,
)
from backward_traversal.utils.subroutine_resolution import (
    extract_subroutine_target,
    normalize_subroutine_target,
    resolve_subroutine_target,
)
from backward_traversal.utils.token_utils import (
    dep_vars_from_args, is_dep_var_candidate, looks_like_register_token, normalize_token,
)

try:
    from blueprint_io import iter_flow
except ImportError:
    import sys as _sys
    import os as _os
    _sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.dirname(__file__))))
    from blueprint_io import iter_flow


DEFAULT_MAX_SUBROUTINE_DEPTH = 4  # Case-5: z/TPF programs use WB1DS1-WB1DS4 (4 save slots)
DEFAULT_MAX_SUBROUTINE_NODES = 400
DEFAULT_MAX_TRACE_NODES = 5000
# Issue-10: configurable margin (in source lines) for GAP-003 pruning.
# Blocks whose line range falls within this margin of the subroutine's
# declared bounds are kept rather than pruned.
_GAP_003_MARGIN = int(os.environ.get("GAP_003_MARGIN", "50"))


def _inst_to_role(inst: str, fallback: str) -> str:
    u = str(inst or "").upper()
    mapping = {
        "CLC": "COMPARE",
        "CLI": "COMPARE_IMMEDIATE",
        "TM": "TEST_MASK",
        "CP": "COMPARE_PACKED",
        "LTR": "TEST_REGISTER",
        "C": "COMPARE",
        "CR": "COMPARE_REGISTERS",
        "CH": "COMPARE_HALFWORD",
        "CL": "COMPARE_LOGICAL",
        "CLR": "COMPARE_LOGICAL_REGISTERS",
        "B": "BRANCH",
        "BE": "BRANCH_EQUAL",
        "BNE": "BRANCH_NOT_EQUAL",
        "BZ": "BRANCH_ZERO",
        "BNZ": "BRANCH_NOT_ZERO",
        "BH": "BRANCH_HIGH",
        "BNH": "BRANCH_NOT_HIGH",
        "BM": "BRANCH_MINUS",
        "BNM": "BRANCH_NOT_MINUS",
        "BO": "BRANCH_OVERFLOW",
        "BNO": "BRANCH_NO_OVERFLOW",
        "BP": "BRANCH_PLUS",
        "BNP": "BRANCH_NOT_PLUS",
        "J": "JUMP",
        "JE": "JUMP_EQUAL",
        "JNE": "JUMP_NOT_EQUAL",
        "JXHG": "JUMP_INDEX_HIGH",
        "JXLE": "JUMP_INDEX_LOW_EQUAL",
        "BAS": "SUBROUTINE_CALL",
        "BAL": "SUBROUTINE_CALL",
        "ENTRC": "CROSS_FILE_CALL",
        "SWISC": "CROSS_FILE_CALL",
        "FUNCTION": "CROSS_FILE_CALL",
        # Case-7: non-returning cross-file calls — no backward return edge
        "ENTNC": "NON_RETURNING_CALL",
        "ENTDC": "NON_RETURNING_CALL",
        # Case-3: async ECB creation — spawns independent ECB, returns to next inst
        "CREEC": "ASYNC_SPAWN",
        "CREMC": "ASYNC_SPAWN",
        "CREDC": "ASYNC_SPAWN",
        # Case-4: macro-style call with non-standard control flow
        "TMSMA": "MACRO_CALL",
        # P33: CALLC is IBM's preferred typed cross-language call (CPROC/UPROC)
        "CALLC": "CROSS_FILE_CALL",
    }
    return mapping.get(u, fallback)


def _merge_relevant_line(existing: List[Dict[str, Any]], line: Dict[str, Any]) -> bool:
    if any(e.get("line") == line.get("line") and e.get("role") == line.get("role") for e in existing):
        return False
    existing.append(line)
    return True


def _ensure_node(node_data: Dict[str, Dict[str, Any]], block_id: str) -> None:
    if block_id not in node_data:
        node_data[block_id] = {"relevant_lines": [], "dependent_vars": set()}


def _add_edge(edge_scopes: Dict[Tuple[str, str, str], Set[str]], src: str, tgt: str, edge_type: str, scope: str) -> None:
    key = (src, tgt, edge_type)
    if key not in edge_scopes:
        edge_scopes[key] = set()
    edge_scopes[key].add(scope)


def _sorted_graph_nodes(
    node_data: Dict[str, Dict[str, Any]],
    block_source_index: Dict[str, str],
) -> List[Dict[str, Any]]:
    nodes = []
    for block_id, data in node_data.items():
        rel = sorted(data["relevant_lines"], key=lambda x: (int(x.get("line") or 0), str(x.get("role") or "")))
        nodes.append(
            {
                "id": block_id,
                "code": block_source_index.get(block_id, ""),
                "relevant_code_lines": rel,
                "dependent_variables": sorted(data["dependent_vars"]),
            }
        )
    return sorted(nodes, key=lambda n: str(n.get("id", "")))


def _sorted_graph_edges(edge_scopes: Dict[Tuple[str, str, str], Set[str]]) -> List[Dict[str, Any]]:
    edges = [
        {
            "source": src,
            "target": tgt,
            "type": edge_type,
            "direction": ["backward"],
            "scopes": sorted(scopes),
        }
        for (src, tgt, edge_type), scopes in edge_scopes.items()
    ]
    return sorted(edges, key=lambda e: (e["source"], e["target"], e["type"]))


def _register_relevant_line(
    node_data: Dict[str, Dict[str, Any]],
    block_id: str,
    line_payload: Dict[str, Any],
    trace_state: Dict[str, Any],
    local_counter: Optional[Dict[str, int]] = None,
) -> bool:
    """Add a relevant line with global/local node caps; returns False when capped."""
    _ensure_node(node_data, block_id)
    added = _merge_relevant_line(node_data[block_id]["relevant_lines"], line_payload)
    if not added:
        return True

    if local_counter is not None:
        local_counter["count"] += 1
        if local_counter["count"] > int(local_counter.get("limit") or 0):
            local_counter["capped"] = True
            return False

    trace_state["total_trace_nodes"] += 1
    if trace_state["total_trace_nodes"] > int(trace_state.get("max_trace_nodes") or DEFAULT_MAX_TRACE_NODES):
        trace_state["global_capped"] = True
        return False
    return True


def _edge_add(
    edges: Dict[str, List[Tuple[str, str]]],
    src: str,
    tgt: str,
    edge_type: str,
) -> None:
    if not src or not tgt:
        return
    edges.setdefault(src, []).append((tgt, edge_type))


def _last_flow_entry(block: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    flow = [e for e in iter_flow(block) if int(e.get("line") or 0) > 0]
    if not flow:
        return None
    flow = sorted(flow, key=lambda e: int(e.get("line") or 0))
    return flow[-1]


def _extract_branch_target_from_flow(
    inst: str,
    args: List[str],
    detail: str,
) -> str:
    if inst not in BRANCH_INST:
        return ""
    # Issue-4/12: improved target extraction.
    # 1) Try last arg (the common case: separate operands)
    raw_target = str(args[-1] if args else "").strip()
    result = normalize_subroutine_target(raw_target) if raw_target else ""
    if result and not looks_like_register_token(result):
        return result
    # 2) For combined operands like "15,TARGET" or mask instructions (BC mask,target),
    #    try the LAST comma-segment from the full detail/args string.
    combined = detail if detail else ",".join(str(a) for a in args)
    if combined:
        last_seg = combined.split(",")[-1].strip()
        result = normalize_subroutine_target(last_seg)
        if result and not looks_like_register_token(result):
            return result
    # 3) Try each arg from right to left for the first non-register symbol.
    for a in reversed(args):
        sym = normalize_subroutine_target(str(a).strip())
        if sym and not looks_like_register_token(sym):
            return sym
    return ""


def _build_cfg_maps(
    block_map: Dict[str, Dict[str, Any]],
    bp_data: Optional[Dict[str, Any]] = None,
) -> Tuple[Dict[str, List[Tuple[str, str]]], Dict[str, List[Tuple[str, str]]]]:
    """Build a robust in-file CFG using incoming metadata + flow-derived branch/fallthrough edges."""
    outgoing: Dict[str, List[Tuple[str, str]]] = {bid: [] for bid in block_map.keys()}

    # Issue-4/12: case-insensitive lookup map for block IDs so that targets
    # with different casing (e.g. "Aa710a58" vs "AA710A58") still resolve.
    _block_upper: Dict[str, str] = {bid.upper(): bid for bid in block_map}

    def _resolve_block(target: str) -> str:
        """Resolve a target to a block_map key, with case-insensitive fallback."""
        if target in block_map:
            return target
        return _block_upper.get(target.upper(), "")

    # 1) Existing incoming-branch metadata from parser.
    for tgt_id, block in block_map.items():
        for inc in (block.get("incoming_branches") or []):
            src_id = str(inc.get("source") or "").strip()
            edge_type = str(inc.get("type") or "BRANCH").upper()
            src_id = _resolve_block(src_id) if src_id else ""
            if not src_id or edge_type not in {"BRANCH", "FALLTHROUGH"}:
                continue
            _edge_add(outgoing, src_id, tgt_id, edge_type)

    # 2) Flow-derived explicit branch edges (covers missing parser incoming links).
    for src_id, block in block_map.items():
        for entry in iter_flow(block):
            inst = str(entry.get("inst") or "").upper()
            args = [str(a) for a in (entry.get("args") or [])]
            detail = ", ".join(args) if args else str(entry.get("detail") or "")
            target = _extract_branch_target_from_flow(inst, args, detail)
            if target:
                resolved = _resolve_block(target)
                if resolved:
                    _edge_add(outgoing, src_id, resolved, "BRANCH")

    # 2b) Issue-4/12: Supplement with call_graph.edges from the blueprint parser
    # (Pass 3).  The parser has richer context for operand parsing and may
    # resolve targets that flow-derived extraction missed.
    if bp_data:
        cg_edges = (bp_data.get("call_graph") or {}).get("edges") or []
        for cge in cg_edges:
            if str(cge.get("call_type") or "").lower() != "branch":
                continue
            src = _resolve_block(str(cge.get("source") or "").strip())
            tgt_raw = str(cge.get("target") or "").strip()
            tgt = _resolve_block(normalize_subroutine_target(tgt_raw)) if tgt_raw else ""
            if not tgt:
                tgt = _resolve_block(tgt_raw)
            if src and tgt:
                _edge_add(outgoing, src, tgt, "BRANCH")

    # 3) Fallthrough completion by line ordering.
    bounds: List[Tuple[int, int, str]] = []
    for bid, block in block_map.items():
        lr = _flow_line_bounds(block)
        if not lr:
            continue
        bounds.append((lr[0], lr[1], bid))
    bounds = sorted(bounds, key=lambda x: (x[0], x[1], x[2]))

    # GAP-002: collect every flow line across all blocks so we can detect whether
    # a gap between two adjacent blocks contains executable content belonging to a
    # third block.  Adjacent pairs in sorted order have only non-block lines
    # (DS/DC/COPY/comments) between them in well-formed blueprints; suppress
    # fallthrough only when a known flow line actually falls inside the gap.
    all_exec_lines_sorted: List[int] = sorted(
        int(e.get("line") or 0)
        for b in block_map.values()
        for e in iter_flow(b)
        if int(e.get("line") or 0) > 0
    )

    ret_ops = {str(op).upper() for op in RETURN_OPCODES}
    # Case-7: ENTDC/ENTNC drop the caller from the ECB — no continuation to next instruction.
    no_return_call_ops = {str(op).upper() for op in NON_RETURNING_CALL_OPCODES}
    unconditional_no_fallthrough = {"B", "J"} | ret_ops | no_return_call_ops
    for idx in range(len(bounds) - 1):
        _, cur_end, cur_id = bounds[idx]
        next_start, _, next_id = bounds[idx + 1]
        gap = int(next_start) - int(cur_end)
        if gap < 1:
            continue
        # GAP-002: replaced hard 12-line cap — only suppress when executable
        # content from another block is proven to occupy the gap.
        # O(log N) bisect instead of O(N) linear scan.
        _lo = bisect.bisect_right(all_exec_lines_sorted, int(cur_end))
        _hi = bisect.bisect_left(all_exec_lines_sorted, int(next_start))
        if _lo < _hi:  # at least one exec line strictly between cur_end and next_start
            continue
        last = _last_flow_entry(block_map.get(cur_id, {}))
        if last is None:
            # GAP-002: synthetic/macro-only block with no positive-line flow entries;
            # no unconditional terminator can be confirmed — allow fallthrough.
            _edge_add(outgoing, cur_id, next_id, "FALLTHROUGH")
            continue
        last_inst = str(last.get("inst") or "").upper()
        if last_inst in unconditional_no_fallthrough:
            continue
        _edge_add(outgoing, cur_id, next_id, "FALLTHROUGH")

    for src in list(outgoing.keys()):
        outgoing[src] = sorted(set(outgoing[src]), key=lambda t: (t[0], t[1]))

    incoming: Dict[str, List[Tuple[str, str]]] = {bid: [] for bid in block_map.keys()}
    for src, outs in outgoing.items():
        for tgt, edge_type in outs:
            incoming.setdefault(tgt, []).append((src, edge_type))
    for tgt in list(incoming.keys()):
        incoming[tgt] = sorted(set(incoming[tgt]), key=lambda t: (t[0], t[1]))
    return outgoing, incoming


def _flow_line_bounds(block: Dict[str, Any]) -> Optional[Tuple[int, int]]:
    lines = sorted(int(e.get("line") or 0) for e in iter_flow(block) if int(e.get("line") or 0) > 0)
    if not lines:
        return None
    return (lines[0], lines[-1])


def _backtrack_register_dep_vars(
    reg_name: str,
    start_block: str,
    before_line: int,
    block_map: Dict[str, Dict[str, Any]],
    cfg_incoming: Dict[str, List[Tuple[str, str]]],
    constant_symbols: Optional[Set[str]] = None,
    max_reg_hops: int = 3,
    max_block_depth: int = 5,
    _seen_regs: Optional[frozenset] = None,
) -> List[str]:
    """Walk backward through CFG blocks to find memory sources loaded into a register.

    GAP-REG: closes the register-chain dep_var gap where a setter uses a register
    as its source (e.g. L R5,WKVAR → ST R5,TARGET_VAR) and the dep_var WKVAR is
    invisible to dep_vars_from_args because R5 is filtered as a register token.
    """
    if max_reg_hops <= 0:
        return []
    reg_upper = str(reg_name or "").strip().upper()
    if not looks_like_register_token(reg_upper):
        return []
    seen_regs: frozenset = (_seen_regs or frozenset()) | {reg_upper}
    results: List[str] = []
    bfs_queue: Deque[Tuple[str, Optional[int]]] = deque([(start_block, before_line)])
    visited_blocks: Set[str] = set()
    depth = 0
    while bfs_queue and depth <= max_block_depth:
        next_level: List[Tuple[str, Optional[int]]] = []
        while bfs_queue:
            cur_bid, scan_before = bfs_queue.popleft()
            if cur_bid in visited_blocks:
                continue
            visited_blocks.add(cur_bid)
            block = block_map.get(cur_bid)
            if not block:
                continue
            flow = [
                e for e in iter_flow(block)
                if int(e.get("line") or 0) > 0
                and (scan_before is None or int(e.get("line") or 0) < scan_before)
            ]
            flow_sorted_desc = sorted(flow, key=lambda e: int(e.get("line") or 0), reverse=True)
            found_assignment_in_block = False
            for entry in flow_sorted_desc:
                inst = str(entry.get("inst") or "").upper()
                e_args = [str(a) for a in (entry.get("args") or [])]
                if inst in REGISTER_LOAD_FROM_MEM:
                    dest_idx = 0
                    src_idx = REGISTER_LOAD_FROM_MEM[inst]
                    if dest_idx < len(e_args) and normalize_token(e_args[dest_idx]) == reg_upper:
                        if src_idx < len(e_args):
                            raw_src = e_args[src_idx]
                            mem_src = normalize_token(raw_src)
                            if mem_src and is_dep_var_candidate(raw_src, constant_symbols=constant_symbols):
                                if mem_src not in results:
                                    results.append(mem_src)
                        found_assignment_in_block = True
                        break
                if inst in REGISTER_COPY_FROM_REG:
                    dest_idx = 0
                    src_idx = REGISTER_COPY_FROM_REG[inst]
                    if dest_idx < len(e_args) and normalize_token(e_args[dest_idx]) == reg_upper:
                        if src_idx < len(e_args):
                            src_reg = normalize_token(e_args[src_idx])
                            if src_reg and src_reg not in seen_regs and looks_like_register_token(src_reg):
                                child_deps = _backtrack_register_dep_vars(
                                    reg_name=src_reg,
                                    start_block=cur_bid,
                                    before_line=int(entry.get("line") or 0),
                                    block_map=block_map,
                                    cfg_incoming=cfg_incoming,
                                    constant_symbols=constant_symbols,
                                    max_reg_hops=max_reg_hops - 1,
                                    max_block_depth=max_block_depth,
                                    _seen_regs=seen_regs,
                                )
                                for dep in child_deps:
                                    if dep not in results:
                                        results.append(dep)
                        found_assignment_in_block = True
                        break
                # GAP-006 address-arithmetic: LA/LAY/LAE load a symbol address into a
                # register.  args[0] = destination register, args[1] = address operand
                # (e.g. "WKBUF" or "WKBUF(R3)").  normalize_token strips the (Rx) suffix
                # so we can extract the symbol name directly.  The base register Ry is
                # also backtracked so computed addresses like "0(R3)" resolve to the
                # underlying buffer that R3 points at.
                #
                # GAP-006 multi-hop arithmetic: when LA Rx, offset(Rx) is a self-
                # modification (dest == base), the register is both the source and
                # destination — the instruction only adjusts the address by a constant
                # offset.  In that case we must NOT stop the backward search because
                # the original memory load that set Rx is still earlier in the block.
                if inst in {"LA", "LAY", "LAE"}:
                    if len(e_args) >= 1 and normalize_token(e_args[0]) == reg_upper:
                        raw_addr = e_args[1] if len(e_args) >= 2 else ""
                        sym = normalize_token(raw_addr)
                        # Accept if sym is a named symbol, not a register or literal.
                        if sym and not looks_like_register_token(sym) and not sym.isdigit():
                            if sym not in results:
                                results.append(sym)
                        # Extract and backtrack the base register: "WKBUF(R3)" → R3.
                        _paren_open = raw_addr.find("(")
                        _paren_close = raw_addr.rfind(")")
                        _is_self_mod = False
                        if _paren_open >= 0 and _paren_close > _paren_open:
                            _base = raw_addr[_paren_open + 1:_paren_close].strip().upper()
                            if _base and looks_like_register_token(_base):
                                if _base == reg_upper:
                                    # Self-modification LA Rx, N(Rx): the register is
                                    # both source and dest (address displacement only).
                                    # Do NOT mark found_assignment_in_block — continue
                                    # scanning backward to find the original load of Rx.
                                    _is_self_mod = True
                                elif _base not in seen_regs:
                                    child_deps = _backtrack_register_dep_vars(
                                        reg_name=_base,
                                        start_block=cur_bid,
                                        before_line=int(entry.get("line") or 0),
                                        block_map=block_map,
                                        cfg_incoming=cfg_incoming,
                                        constant_symbols=constant_symbols,
                                        max_reg_hops=max_reg_hops - 1,
                                        max_block_depth=max_block_depth,
                                        _seen_regs=seen_regs,
                                    )
                                    for dep in child_deps:
                                        if dep not in results:
                                            results.append(dep)
                        if not _is_self_mod:
                            found_assignment_in_block = True
                            break
                        # For self-modification, fall through to continue scanning
                        # earlier entries in flow_sorted_desc without breaking.
                # GAP-006 in-place arithmetic (A, AH, S, SH, AR, ALR, SLR, SR):
                # these instructions modify a register's value but do not establish
                # where the register was originally loaded.  When Rx is the destination,
                # continue scanning backward to find the prior load/copy of Rx.
                if inst in {"A", "AH", "AR", "AL", "ALR", "S", "SH", "SR", "SL", "SLR",
                            "N", "NR", "O", "OR", "X", "XR"}:
                    if e_args and normalize_token(e_args[0]) == reg_upper:
                        # In-place arithmetic on our target register: don't stop,
                        # keep looking backward for the original load.
                        continue
                # GAP-I: BR Rx / BCR mask,Rx (non-return, non-NOP indirect dispatch).
                # The branch register is *consumed* here — it is not redefined — so
                # we annotate that the register's value flows into an indirect dispatch
                # point but do NOT break (continue scanning backward to find the load).
                if inst in {"BR", "BCR"} and e_args:
                    _br_reg_tok: Optional[str] = None
                    if inst == "BR":
                        _br_reg_tok = normalize_token(e_args[0])
                    elif len(e_args) >= 2:
                        _br_mask_str = e_args[0].strip()
                        # BCR 0,Rx is a NOP — skip.
                        if _br_mask_str != "0":
                            _br_reg_tok = normalize_token(e_args[1])
                    if (
                        _br_reg_tok
                        and _br_reg_tok == reg_upper
                        and _br_reg_tok not in ("R14", "R10", "14", "10")
                    ):
                        br_line = int(entry.get("line") or 0)
                        synthetic = (
                            f"indirect_call@{reg_upper}:{br_line}"
                            if br_line else f"indirect_call@{reg_upper}"
                        )
                        if synthetic not in results:
                            results.append(synthetic)
                        # BR does not define reg_upper — continue backward to find
                        # the LOAD instruction that actually set this register.
                # GAP-P14: GETCC/GETFC/MALOC implicitly load the allocated block pointer
                # into R14.  When backtracking R14 and we encounter one of these allocation
                # macros, emit the corresponding CE1CRn field as the dep_var source so that
                # the allocation chain is surfaced to the caller.
                # GAP-P43: FIWHC/FINHC/FINDC/FINWC use LEVEL=Dn keyword syntax rather than
                # the positional Dn form used by GETCC.  Fall back to keyword arg extraction
                # when the direct lookup fails so "FINHC LEVEL=DE,..." emits CE1CRE.
                if inst in ALLOC_RESULT_REG and ALLOC_RESULT_REG[inst] == reg_upper:
                    # GAP-H: CALOC operands are ESIZE=Rx,COUNT=R1 — no ECB data-level
                    # designator exists.  Emit a synthetic dep_var that mirrors the
                    # forward-pass alloc@heap:<line> node so the allocation is visible
                    # in the backward chain instead of terminating silently.
                    if inst == "CALOC":
                        alloc_line = int(entry.get("line") or 0)
                        synthetic = f"alloc@heap:{alloc_line}" if alloc_line else "alloc@heap"
                        if synthetic not in results:
                            results.append(synthetic)
                        found_assignment_in_block = True
                        break
                    alloc_args = [str(a).strip().upper() for a in e_args]
                    level_key: Optional[str] = None
                    if alloc_args:
                        level_key = alloc_args[0]  # positional form: GETCC D2
                        if not LEVEL_TO_CE1CR.get(level_key):
                            # keyword form: FINHC LEVEL=DE,... → extract "DE"
                            _kw = "LEVEL="
                            for _a in alloc_args:
                                if _a.startswith(_kw):
                                    level_key = _a[len(_kw):]
                                    break
                    if level_key:
                        ce1cr = LEVEL_TO_CE1CR.get(level_key)
                        if ce1cr and ce1cr not in results:
                            results.append(ce1cr)
                    found_assignment_in_block = True
                    break
                # GAP-P17: DBOPN/DBIFB/DBRED/DBIFD implicitly set R3 to the SW00SR
                # (switch-word) context address.  Emit a synthetic dep_var label so the
                # caller sees that R3 was produced by a DB context instruction rather
                # than by a named memory load; the label encodes the source instruction.
                if inst in DB_CONTEXT_REG and DB_CONTEXT_REG[inst] == reg_upper:
                    synthetic = f"DB_CONTEXT_{inst}"
                    if synthetic not in results:
                        results.append(synthetic)
                    found_assignment_in_block = True
                    break
            if not found_assignment_in_block:
                for src_bid, edge_type in cfg_incoming.get(cur_bid, []):
                    if edge_type in {"BRANCH", "FALLTHROUGH"} and src_bid not in visited_blocks:
                        next_level.append((src_bid, None))
        bfs_queue = deque(next_level)
        depth += 1
    return results


def _return_line_map(bp_data: Dict[str, Any]) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for edge in (bp_data.get("call_graph", {}) or {}).get("edges", []):
        if str(edge.get("call_type") or "").lower() != "return":
            continue
        src = str(edge.get("source") or "").strip()
        line = int(edge.get("line") or 0)
        if not src or line <= 0:
            continue
        out[src] = max(out.get(src, 0), line)
    return out


def _build_subroutine_cfg_region(
    bp_data: Dict[str, Any],
    block_map: Dict[str, Dict[str, Any]],
    cfg_outgoing: Dict[str, List[Tuple[str, str]]],
    entry_block: str,
    line_start: Optional[int] = None,
    line_end: Optional[int] = None,
) -> Dict[str, Any]:
    """Build a generic subroutine region by CFG reachability from entry block.

    line_start / line_end are the subroutine's declared source-line bounds from the
    resolver.  When provided, blocks whose entire flow-line range falls outside
    [line_start, line_end] are pruned from the region (GAP-003) so that shared
    error-handler blocks reached via out-of-range branches are excluded.
    """
    warnings: List[str] = []
    if entry_block not in block_map:
        return {
            "region_blocks": set(),
            "anchor_blocks": [],
            "anchor_lines": [],
            "start_line": None,
            "end_line": None,
            "warnings": [f"Resolved subroutine block '{entry_block}' not found in CFG blocks."],
        }

    region: Set[str] = set()
    queue: Deque[str] = deque([entry_block])
    while queue:
        cur = queue.popleft()
        if cur in region:
            continue
        region.add(cur)
        for nxt, edge_type in cfg_outgoing.get(cur, []):
            if edge_type in {"BRANCH", "FALLTHROUGH"} and nxt not in region:
                queue.append(nxt)

    # GAP-003: prune blocks that fall entirely outside the subroutine's declared
    # line range (plus a configurable margin) so that shared handlers
    # (B ERR_HANDLER) pulled in by the unconstrained BFS do not contaminate
    # this subroutine's region.  The margin (GAP_003_MARGIN env var, default
    # 50) prevents over-pruning when subroutine bounds are slightly off.
    if line_start is not None or line_end is not None:
        margin = _GAP_003_MARGIN
        pruned: Set[str] = set()
        for bid in list(region):
            b_bounds = _flow_line_bounds(block_map.get(bid, {}))
            if b_bounds is None:
                continue  # no line info — keep conservatively
            b_lo, b_hi = b_bounds
            if line_end is not None and b_lo > int(line_end) + margin:
                pruned.add(bid)
            elif line_start is not None and b_hi < int(line_start) - margin:
                pruned.add(bid)
        if pruned:
            warnings.append(
                f"[GAP-003] Pruned {len(pruned)} out-of-range block(s) from "
                f"'{entry_block}' region (sub range [{line_start},{line_end}]): "
                + ", ".join(sorted(pruned))
            )
            region -= pruned

    ret_line_map = _return_line_map(bp_data)
    explicit_return_blocks = sorted(b for b in region if b in ret_line_map)

    # Issue-11: when no explicit RETURN edges exist in the blueprint,
    # inspect the last instruction of each sink block to detect RETURN-like
    # opcodes (BR, BCR, PR, BACKC, etc.) as a heuristic fallback.
    if not explicit_return_blocks:
        for b in sorted(region):
            last = _last_flow_entry(block_map.get(b, {}))
            if last:
                last_inst = str(last.get("inst") or "").upper()
                if last_inst in RETURN_OPCODES:
                    last_line = int(last.get("line") or 0)
                    ret_line_map[b] = max(ret_line_map.get(b, 0), last_line)
                    explicit_return_blocks.append(b)
        explicit_return_blocks = sorted(set(explicit_return_blocks))

    sink_blocks: List[str] = []
    for b in sorted(region):
        has_out_in_region = any((nxt in region) for (nxt, et) in cfg_outgoing.get(b, []) if et in {"BRANCH", "FALLTHROUGH"})
        if not has_out_in_region:
            sink_blocks.append(b)

    if explicit_return_blocks:
        anchor_blocks = explicit_return_blocks
    elif sink_blocks:
        anchor_blocks = sink_blocks
        warnings.append(
            f"No explicit RETURN edge in CFG region for '{entry_block}'; using terminal sinks as anchors."
        )
    else:
        anchor_blocks = [entry_block]
        warnings.append(
            f"CFG region for '{entry_block}' has no explicit return/sink anchor; using entry block anchor."
        )

    anchor_lines: List[int] = []
    for b in anchor_blocks:
        line = ret_line_map.get(b, 0)
        if line <= 0:
            bounds = _flow_line_bounds(block_map.get(b, {}))
            line = bounds[1] if bounds else 0
        if line > 0:
            anchor_lines.append(line)

    line_bounds = [
        _flow_line_bounds(block_map[b])
        for b in region
        if b in block_map
    ]
    mins = [x[0] for x in line_bounds if x]
    maxs = [x[1] for x in line_bounds if x]
    start_line = min(mins) if mins else None
    end_line = max(maxs) if maxs else None

    return {
        "region_blocks": region,
        "anchor_blocks": anchor_blocks,
        "anchor_lines": sorted(set(anchor_lines)),
        "start_line": start_line,
        "end_line": end_line,
        "warnings": warnings,
    }


# ── CFG map cache ─────────────────────────────────────────────────────────────
# _build_cfg_maps is O(N_blocks × N_flow_entries) and was previously rebuilt on
# every backward_reachable_blocks / trace_asm_call_site_backward call, even for
# the same blueprint.  Cache it keyed on the absolute blueprint path so all
# callers within one process share a single build per file.
#
# Cache size matches the blueprint LRU (ASM_CFG_CACHE_SIZE, default 1024).
# The returned dicts are read-only across all callers; no mutations are made to
# block_map, cfg_outgoing, or cfg_incoming after they leave this function.

_CFG_CACHE_SIZE = int(os.environ.get("ASM_CFG_CACHE_SIZE", "1024"))


@lru_cache(maxsize=_CFG_CACHE_SIZE)
def _get_file_cfg_maps(
    bp_path_str: str,
) -> Tuple[Dict[str, Any], Dict[str, List[Tuple[str, str]]], Dict[str, List[Tuple[str, str]]]]:
    """Return ``(block_map, cfg_outgoing, cfg_incoming)`` for a blueprint, cached by path.

    Eliminates the repeated O(N) rebuild inside ``backward_reachable_blocks`` and
    ``trace_asm_call_site_backward`` when the same file is visited multiple times
    during a single backward-only run (e.g., at every dep_var BFS iteration).
    """
    bp_data = load_json(Path(bp_path_str))
    blocks = bp_data.get("blocks", [])
    block_map: Dict[str, Any] = {str(b.get("id", "")): b for b in blocks}
    cfg_outgoing, cfg_incoming = _build_cfg_maps(block_map, bp_data)
    return block_map, cfg_outgoing, cfg_incoming


def _backward_reachable_blocks_impl(
    bp_data: Dict[str, Any],
    start_block: str,
    expand_subroutine_callers: bool = False,
    max_caller_expansions: int = 200,
    bp_path: Optional[str] = None,
    before_line: int = 0,   # NEW: restrict sub expansion in start_block
) -> Set[str]:
    """Return all blocks reachable backward from start_block plus subroutine bodies on that path.

    Hybrid BFS (every block, regardless of mode):
    - BAS/BAL instructions in any visited block enqueue the subroutine target in forward mode
    - backward mode: also follow cfg_incoming predecessors
    - forward mode: also follow cfg_outgoing BRANCH/FALLTHROUGH successors
    Subroutine expansion is fully recursive — nested BAS/BAL inside subroutine bodies are expanded too.
    Cycle prevention: reachable set prevents revisiting any block.

    GAP-018: when expand_subroutine_callers=True, alternate callers of each subroutine that enters
    scope are also enqueued in backward mode so their predecessor code paths contribute to scope.
    max_caller_expansions caps the total number of alternate-caller blocks added to prevent
    uncontrolled scope explosion in files with many shared subroutines.
    GAP-033: raised default cap from 50 → 200.  With 50, files that share subroutines
    among many callers (e.g. 5 subroutines × 40 callers each) hit the cap after the
    first ~1-2 subroutines and miss scope coverage from the rest.  200 gives adequate
    headroom for typical HLASM files without enabling unbounded scope explosion.

    bp_path: when supplied, the CFG maps are loaded from the module-level LRU cache
    (_get_file_cfg_maps) instead of being rebuilt from bp_data, eliminating repeated
    O(N_blocks) allocations across multiple calls for the same file.
    """
    if bp_path is not None:
        block_map, cfg_outgoing, cfg_incoming = _get_file_cfg_maps(bp_path)
    else:
        blocks = bp_data.get("blocks", [])
        block_map = {str(b.get("id", "")): b for b in blocks}
        cfg_outgoing, cfg_incoming = _build_cfg_maps(block_map, bp_data)

    if start_block not in block_map:
        return set()

    # GAP-018: precompute reverse caller index so that when a subroutine enters scope
    # we can quickly find all other blocks in this file that call the same subroutine.
    # BAS/BAL do not appear in cfg_incoming (no CFG edge is built for calls), so we
    # must scan the blocks explicitly.  Only built when the feature is requested.
    sub_callers: Dict[str, List[str]] = {}
    if expand_subroutine_callers:
        for bid, blk in block_map.items():
            for entry in iter_flow(blk):
                inst = str(entry.get("inst", "")).upper()
                if inst not in SUBROUTINE_INST:
                    continue
                e_args = [str(a) for a in (entry.get("args") or [])]
                e_detail = ", ".join(e_args) if e_args else str(entry.get("detail") or "")
                e_target = extract_subroutine_target(e_args, e_detail)
                if not e_target:
                    continue
                e_resolved = resolve_subroutine_target(bp_data, e_target)
                e_label = str(e_resolved.get("resolved_label") or "")
                if e_label and e_label in block_map:
                    sub_callers.setdefault(e_label, []).append(bid)

    reachable: Set[str] = set()
    # GAP-003: queue carries (block_id, mode, fwd_line_lo, fwd_line_hi).
    # When entering forward mode for a subroutine body, the resolved line range
    # is propagated so that successors outside that range are pruned, preventing
    # shared error-handler blocks from leaking into scope_blocks.
    queue: Deque[Tuple[str, str, Optional[int], Optional[int]]] = deque(
        [(start_block, "backward", None, None)]
    )
    caller_expansions_done: int = 0

    while queue:
        cur, mode, fwd_lo, fwd_hi = queue.popleft()
        if cur in reachable or cur not in block_map:
            continue
        reachable.add(cur)

        block = block_map[cur]
        for entry in iter_flow(block):
            inst = str(entry.get("inst", "")).upper()
            # Restrict to lines before before_line when in the start block
            if cur == start_block and before_line:
                e_line = int(entry.get("line") or 0)
                if e_line and e_line >= before_line:
                    continue
            if inst not in SUBROUTINE_INST:
                continue
            args = [str(a) for a in (entry.get("args") or [])]
            detail = ", ".join(args) if args else str(entry.get("detail") or "")
            sub_target = extract_subroutine_target(args, detail)
            if not sub_target:
                continue
            resolved = resolve_subroutine_target(bp_data, sub_target)
            resolved_label = str(resolved.get("resolved_label") or "")
            if resolved_label and resolved_label in block_map and resolved_label not in reachable:
                # GAP-003: pass the subroutine's resolved line range into forward mode
                # so out-of-range successors are pruned.  Skip range guard when
                # confidence is block_fallback (range may be unreliable).
                _conf = str(resolved.get("resolution_confidence") or "")
                _reliable = "block_fallback" not in _conf
                _sub_lo: Optional[int] = resolved.get("start_line") if _reliable else None
                _sub_hi: Optional[int] = resolved.get("end_line") if _reliable else None
                queue.append((resolved_label, "forward", _sub_lo, _sub_hi))
                # GAP-018: enqueue other callers of this subroutine in backward mode
                # so that code paths preceding those call sites contribute to scope.
                if expand_subroutine_callers and caller_expansions_done < max_caller_expansions:
                    for alt_caller in sub_callers.get(resolved_label, []):
                        if alt_caller not in reachable:
                            queue.append((alt_caller, "backward", None, None))
                            caller_expansions_done += 1
                            if caller_expansions_done >= max_caller_expansions:
                                break

        if mode == "forward":
            for nxt, edge_type in cfg_outgoing.get(cur, []):
                if edge_type not in {"BRANCH", "FALLTHROUGH"} or nxt in reachable:
                    continue
                # GAP-003: prune successors outside the subroutine's line range
                # (with configurable margin to avoid over-pruning).
                if fwd_lo is not None or fwd_hi is not None:
                    nxt_bounds = _flow_line_bounds(block_map.get(nxt, {}))
                    if nxt_bounds is not None:
                        nxt_lo, nxt_hi = nxt_bounds
                        if fwd_hi is not None and nxt_lo > int(fwd_hi) + _GAP_003_MARGIN:
                            continue  # entirely beyond subroutine end + margin
                        if fwd_lo is not None and nxt_hi < int(fwd_lo) - _GAP_003_MARGIN:
                            continue  # entirely before subroutine start - margin
                queue.append((nxt, "forward", fwd_lo, fwd_hi))
        else:
            for src, edge_type in cfg_incoming.get(cur, []):
                if edge_type in {"BRANCH", "FALLTHROUGH"} and src not in reachable:
                    queue.append((src, "backward", None, None))

    return reachable


# PERF: memoize the BFS *result set* (not just the CFG maps) keyed on the inputs
# that fully determine it.  In the D×F dep_var BFS the same (file, start_block)
# scope is recomputed many times; this collapses those to one BFS per distinct
# key.  Engaged only when bp_path is supplied (bp_data is then deterministic from
# the path, so the key is stable); the CLI/no-path branch stays uncached.  A
# frozenset is cached and a fresh set() copy returned, so no caller can mutate the
# cached value.  Bounded by _CFG_CACHE_SIZE.  Disable with ASM_BRB_MEMO=0.
_BRB_MEMO_ON = os.environ.get("ASM_BRB_MEMO", "1") != "0"


@lru_cache(maxsize=_CFG_CACHE_SIZE)
def _backward_reachable_blocks_cached(
    bp_path_str: str,
    start_block: str,
    expand_subroutine_callers: bool,
    max_caller_expansions: int,
    before_line: int,
) -> frozenset:
    bp_data = load_json(Path(bp_path_str))
    return frozenset(
        _backward_reachable_blocks_impl(
            bp_data,
            start_block,
            expand_subroutine_callers=expand_subroutine_callers,
            max_caller_expansions=max_caller_expansions,
            bp_path=bp_path_str,
            before_line=before_line,
        )
    )


def backward_reachable_blocks(
    bp_data: Dict[str, Any],
    start_block: str,
    expand_subroutine_callers: bool = False,
    max_caller_expansions: int = 200,
    bp_path: Optional[str] = None,
    before_line: int = 0,
) -> Set[str]:
    """Memoized facade over :func:`_backward_reachable_blocks_impl`.

    Semantics are identical to the impl.  When ``bp_path`` is provided the result
    set is cached (and a fresh copy returned each call); otherwise the impl runs
    uncached.  Set ``ASM_BRB_MEMO=0`` to bypass the cache entirely.
    """
    if bp_path is not None and _BRB_MEMO_ON:
        return set(
            _backward_reachable_blocks_cached(
                str(bp_path),
                start_block,
                bool(expand_subroutine_callers),
                int(max_caller_expansions),
                int(before_line),
            )
        )
    return _backward_reachable_blocks_impl(
        bp_data,
        start_block,
        expand_subroutine_callers=expand_subroutine_callers,
        max_caller_expansions=max_caller_expansions,
        bp_path=bp_path,
        before_line=before_line,
    )


def _parse_raw_operands(raw_line: str, inst: str) -> List[str]:
    """Extract operand tokens from a raw HLASM line given the known instruction.

    Used as a fallback when the blueprint flow entry has args=None (e.g. MVC).
    Returns a list of operand strings split on top-level commas.
    """
    upper = raw_line.upper()
    inst_upper = inst.upper()
    idx = upper.find(inst_upper)
    if idx < 0:
        return []
    after_inst = raw_line[idx + len(inst):].lstrip()
    tokens = after_inst.split()
    if not tokens:
        return []
    operands_str = tokens[0]
    result: List[str] = []
    depth = 0
    cur: List[str] = []
    for ch in operands_str:
        if ch == "(":
            depth += 1
            cur.append(ch)
        elif ch == ")":
            depth -= 1
            cur.append(ch)
        elif ch == "," and depth == 0:
            result.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    if cur:
        result.append("".join(cur))
    return result


def _collect_dep_vars(
    inst: str,
    args: List[str],
    variable: str,
    constant_symbols: Optional[Set[str]] = None,
    *,
    var_field: str = "",
    extra_suppress_indexes: Optional[Set[int]] = None,
) -> List[str]:
    # Trigger instructions: every operand that isn't the traced variable is a dep.
    if inst in TRIGGER_INST:
        # MASK_TRIGGER (TM/TMY/CLI/CLIY): args[1] is always a constant bitmask /
        # comparand (PoO §7-223, §7-74), never a data variable — harvest only args[0].
        if inst in MASK_TRIGGER_AT_ARG1:
            return dep_vars_from_args(args[:1], skip_var=variable, constant_symbols=constant_symbols)
        return dep_vars_from_args(args, skip_var=variable, constant_symbols=constant_symbols)

    # GAP-001: SETTER_INST whose LHS equals the traced variable — harvest sources.
    # Use DEST_ARG_INDEX_BY_INST to find which argument is the destination; every
    # other argument is a potential data source that becomes a dep_var.
    if inst in SETTER_INST:
        dest_idx = DEST_ARG_INDEX_BY_INST.get(inst, 0)
        # GAP-035: columnar flow format stores destination variable in the 'var'
        # field (var_field) with args=None.  Fall back to var_field when args is
        # empty so that setter sites in modern blueprints are not silently missed.
        _lhs_args_match = dest_idx < len(args) and normalize_token(args[dest_idx]) == variable.upper()
        _lhs_var_match = not args and str(var_field).strip().upper() == variable.upper()
        if _lhs_args_match or _lhs_var_match:
            # Audit §5 Fix #3 / §6: drop source-argument positions that are always
            # functional constants (immediate masks, shift counts, translate tables)
            # so COPY-member EQU names never leak as dep_vars.  Static per-instruction
            # suppression is unioned with any pattern-supplied extra indexes.
            _suppress = set(SRC_ARG_SUPPRESS_BY_INST.get(inst, frozenset()))
            if extra_suppress_indexes:
                _suppress |= set(extra_suppress_indexes)
            src_args = [a for i, a in enumerate(args) if i != dest_idx and i not in _suppress]
            return dep_vars_from_args(src_args, skip_var=variable, constant_symbols=constant_symbols)

    return []


def _collect_special_case_dep_vars(
    flow_entries: List[Dict[str, Any]],
    entry_index: int,
    variable: str,
    constant_symbols: Optional[Set[str]] = None,
    *,
    cfg_outgoing: Optional[Dict[str, List[Tuple[str, str]]]] = None,
    block_map: Optional[Dict[str, Dict[str, Any]]] = None,
    cur_block: str = "",
    resolved_inst: str = "",
    resolved_args: Optional[List[str]] = None,
) -> Tuple[Dict[str, Any], List[str]]:
    """Return (verdict, special_deps) for the flow entry at entry_index.

    `verdict` is the dict produced by special_cases.classify_setter (skip /
    suppress / prior-value flags + optional role override).  `special_deps` are the
    dep_vars harvested from the pattern's explicit dep_arg_indexes (e.g. the source
    byte of an MVC propagation idiom).

    When the caller has already resolved an EX/EXRL target, pass the resolved
    instruction and args via `resolved_inst` / `resolved_args` so that
    classify_setter evaluates the actual target instruction rather than "EX".
    """
    entry = flow_entries[entry_index] or {}
    inst = str(entry.get("inst") or "").upper()
    args = [str(a) for a in (entry.get("args") or [])]

    # Override with caller-resolved EX/EXRL values when provided.
    if resolved_inst:
        inst = resolved_inst
    if resolved_args is not None:
        args = resolved_args

    # GAP-009: when this is the last flow entry in its basic block, peek at the
    # first instruction of the CFG successor block(s).  This detects cross-block
    # idioms such as OC VAR,VAR (last in block A) followed by BZ TARGET (first in
    # block B), which cannot be matched by reading entry_index+1 alone.
    # GAP-009b: when there are multiple successors (e.g. the block also has an
    # indirect/computed branch edge), scan ALL successor blocks' first instructions
    # for a CC-sensitive branch (BZ/BNZ/JZ/JNZ).  Preferring such a branch over
    # silence prevents oc_self_noop from firing falsely and suppressing FIELD as a
    # dep_var when the programmer's intent is a zero-test.
    next_inst = ""
    if entry_index + 1 < len(flow_entries):
        next_inst = str((flow_entries[entry_index + 1] or {}).get("inst") or "").upper()
    elif (cfg_outgoing is not None and block_map is not None and cur_block):
        successors = [
            s for s, et in cfg_outgoing.get(cur_block, [])
            if et in {"BRANCH", "FALLTHROUGH"}
        ]
        if len(successors) == 1:
            succ_flow = list(iter_flow(block_map.get(successors[0], {})))
            if succ_flow:
                next_inst = str((succ_flow[0] or {}).get("inst") or "").upper()
        elif len(successors) > 1:
            # Multiple successors: scan all of them for a CC-sensitive branch
            # that directly consumes the condition code set by OC/NC/etc.
            # PATTERN_NEXT_INSTS is derived from SPECIAL_DEPENDENCY_PATTERNS so
            # new zero-test patterns with novel branch mnemonics are picked up
            # automatically without any manual sync here.
            for _succ_bid in successors:
                _succ_flow = list(iter_flow(block_map.get(_succ_bid, {})))
                if _succ_flow:
                    _fi = str((_succ_flow[0] or {}).get("inst") or "").upper()
                    if _fi in PATTERN_NEXT_INSTS:
                        next_inst = _fi
                        break

    verdict = classify_setter(inst, args, next_inst=next_inst)

    dep_args = [
        args[idx]
        for idx in tuple(verdict.get("dep_arg_indexes") or ())
        if 0 <= int(idx) < len(args)
    ]
    # When the pattern designates explicit dep_arg_indexes AND marks
    # prior_value_required (e.g. UNPK FIELD(4),FIELD(8) with different
    # lengths), bypass skip_var so the source dep is not filtered out
    # even though it normalizes to the same token as the target.
    _skip = variable if not (verdict.get("prior_value_required") and dep_args) else ""
    special_deps = dep_vars_from_args(
        dep_args, skip_var=_skip, constant_symbols=constant_symbols
    )
    return verdict, special_deps


def _trace_subroutine_expansion(
    *,
    variable: str,
    bp_data: Dict[str, Any],
    block_map: Dict[str, Dict[str, Any]],
    block_source_index: Dict[str, str],
    call_inst: str,
    call_args: List[str],
    call_detail: str,
    call_line: int,
    caller_block: str,
    parent_scope: str,
    max_depth: int,
    depth_level: int,
    max_subroutine_depth: int,
    max_subroutine_nodes: int,
    trace_state: Dict[str, Any],
    cycle_keys: Set[Tuple[str, str, int, str]],
    cfg_outgoing: Dict[str, List[Tuple[str, str]]],
    cfg_incoming: Dict[str, List[Tuple[str, str]]],
    constant_symbols: Optional[Set[str]],
    asm_file,
) -> Dict[str, Any]:
    sub_target = extract_subroutine_target(call_args, call_detail)
    resolved = resolve_subroutine_target(bp_data, sub_target, asm_file=asm_file)
    warnings: List[str] = list(resolved.get("warnings", []))

    sub_label = str(resolved.get("resolved_label") or "")
    confidence = str(resolved.get("resolution_confidence") or "unresolved")
    sub_start = resolved.get("start_line")
    sub_end = resolved.get("end_line")
    anchors = list(resolved.get("return_anchor_lines") or [])

    if depth_level > max_subroutine_depth:
        return {
            "line": call_line,
            "caller_block": caller_block,
            "call_instruction": call_inst,
            "target": sub_target,
            "resolved_subroutine": sub_label or None,
            "resolution_confidence": confidence,
            "start_line": sub_start,
            "end_line": sub_end,
            "return_anchor_lines": anchors,
            "call_graph": {"nodes": [], "edges": []},
            "subroutine_expansions": [],
            "warnings": warnings + [f"Subroutine depth cap reached at line {call_line}."],
            "capped": True,
        }

    if not sub_label:
        # C7.2 fix: include caller_block and line in the warning so that
        # unresolved subroutine targets can be traced back to specific blocks,
        # not just a count in subroutine_summary.unresolved.
        warnings.append(
            f"[C7.2] Unresolved subroutine target '{sub_target}' at line {call_line} "
            f"in block '{caller_block}' (confidence={confidence}). "
            "Expansion skipped — verify the label exists in the ASM source."
        )
        return {
            "line": call_line,
            "caller_block": caller_block,
            "call_instruction": call_inst,
            "target": sub_target,
            "resolved_subroutine": sub_label or None,
            "resolution_confidence": confidence,
            "start_line": sub_start,
            "end_line": sub_end,
            "return_anchor_lines": anchors,
            "call_graph": {"nodes": [], "edges": []},
            "subroutine_expansions": [],
            "warnings": warnings,
            "capped": False,
        }

    expansion_scope = f"{parent_scope}>{sub_label}:{call_line}"
    # GAP-036: asm_file may be None when source is absent; use empty string as safe stem.
    _asm_stem = str(asm_file.stem).lower() if asm_file is not None else ""
    cycle_key = (_asm_stem, sub_label.upper(), int(call_line or 0), expansion_scope)
    if cycle_key in cycle_keys:
        return {
            "line": call_line,
            "caller_block": caller_block,
            "call_instruction": call_inst,
            "target": sub_target,
            "resolved_subroutine": sub_label,
            "resolution_confidence": confidence,
            "start_line": sub_start,
            "end_line": sub_end,
            "return_anchor_lines": anchors,
            "call_graph": {"nodes": [], "edges": []},
            "subroutine_expansions": [],
            "warnings": warnings + [f"Cycle prevented for subroutine '{sub_label}' at line {call_line}."],
            "capped": False,
        }
    cycle_keys.add(cycle_key)

    # GAP-003: pass the resolver's declared line bounds so out-of-range blocks
    # (shared error handlers, cleanup routines) are pruned from the region.
    # GAP-019: when confidence == "block_fallback" / "normalized_block_fallback",
    # the resolver's line bounds come from a single entry block only; passing
    # them here would cause GAP-003 pruning to remove legitimate sibling blocks
    # of the same subroutine.  Use unconstrained BFS instead so that the full
    # region is discovered, then anchor_lines from the region overwrite the
    # narrow resolver anchors at the `anchors = anchor_lines or anchors` merge.
    _is_block_fallback = confidence in {"block_fallback", "normalized_block_fallback"}
    region_meta = _build_subroutine_cfg_region(
        bp_data, block_map, cfg_outgoing, sub_label,
        line_start=None if _is_block_fallback else sub_start,
        line_end=None if _is_block_fallback else sub_end,
    )
    warnings.extend(list(region_meta.get("warnings") or []))
    region_blocks: Set[str] = set(region_meta.get("region_blocks") or set())
    anchor_blocks: List[str] = list(region_meta.get("anchor_blocks") or [])
    anchor_lines = list(region_meta.get("anchor_lines") or [])

    if not region_blocks:
        return {
            "line": call_line,
            "caller_block": caller_block,
            "call_instruction": call_inst,
            "target": sub_target,
            "resolved_subroutine": sub_label,
            "resolution_confidence": confidence,
            "start_line": sub_start,
            "end_line": sub_end,
            "return_anchor_lines": anchors,
            "call_graph": {"nodes": [], "edges": []},
            "subroutine_expansions": [],
            "warnings": sorted(set(str(w) for w in warnings if w)),
            "capped": False,
        }

    sub_start = region_meta.get("start_line")
    sub_end = region_meta.get("end_line")
    anchors = anchor_lines or anchors

    node_data: Dict[str, Dict[str, Any]] = {}
    edge_scopes: Dict[Tuple[str, str, str], Set[str]] = {}
    nested_expansions: List[Dict[str, Any]] = []
    local_counter = {"count": 0, "limit": int(max_subroutine_nodes), "capped": False}
    seen_states: Set[Tuple[str, int]] = set()

    queue: Deque[Tuple[str, int]] = deque()
    for bid in anchor_blocks:
        if bid not in region_blocks or bid not in block_map:
            continue
        queue.append((bid, 0))
    if not queue:
        queue = deque([(sub_label, 0)]) if sub_label in region_blocks else deque()
    capped = False

    while queue:
        cur_block, depth = queue.popleft()
        if depth > max_depth:
            continue
        state_key = (cur_block, depth)
        if state_key in seen_states:
            continue
        seen_states.add(state_key)

        block = block_map.get(cur_block)
        if not block:
            continue
        if cur_block not in region_blocks:
            continue

        _ensure_node(node_data, cur_block)

        flow_entries = list(iter_flow(block))
        for entry_index, entry in enumerate(flow_entries):
            inst = str(entry.get("inst", "")).upper()
            e_line = int(entry.get("line") or 0)
            if e_line <= 0:
                continue

            args = [str(a) for a in (entry.get("args") or [])]
            # EX/EXRL expansion: resolve the target instruction at the label
            # and substitute inst/args for role/dep classification.
            if inst in EXECUTE_INST:
                _ex_label = args[1] if len(args) > 1 else ""
                _ex_resolved = resolve_ex_target(bp_data, normalize_token(_ex_label))
                if _ex_resolved:
                    inst = str(_ex_resolved.get("inst") or "").upper()
                    args = [str(a) for a in (_ex_resolved.get("args") or [])]
                else:
                    continue  # cannot resolve EX target
            detail = ", ".join(args) if args else str(entry.get("detail") or "")
            verdict, special_deps = _collect_special_case_dep_vars(
                flow_entries,
                entry_index,
                variable,
                constant_symbols=constant_symbols,
                cfg_outgoing=cfg_outgoing,
                block_map=block_map,
                cur_block=cur_block,
                resolved_inst=inst,
                resolved_args=args,
            )

            # Audit §3a/§3b/§3d: value-preserving / spec-exception self-ops are NOT
            # setter sites — do not record them or harvest deps; surface any warning.
            if verdict.get("skip_setter_site"):
                _w = verdict.get("warn")
                if _w:
                    warnings.append(_w)
                continue

            role: Optional[str] = None
            if inst in TRIGGER_INST:
                role = _inst_to_role(inst, "CONDITION_CHECK")
            elif verdict.get("role") == "CONDITION_CHECK":
                role = "CONDITION_CHECK"
            elif inst in BRANCH_INST:
                role = _inst_to_role(inst, "BRANCH_STEP")
            elif inst in SUBROUTINE_INST:
                role = "SUBROUTINE_CALL"
            elif inst in CROSS_FILE_INST:
                role = "CROSS_FILE_CALL"
            elif inst in NON_RETURNING_CALL_OPCODES:
                role = "NON_RETURNING_CALL"
            elif inst in ASYNC_CALL_OPCODES:
                role = "ASYNC_SPAWN"
            elif inst in MACRO_CALL_OPCODES:
                role = "MACRO_CALL"
            elif inst in SETTER_INST:
                # GAP-001: record setter steps whose LHS is the traced variable so
                # the data-flow chain (MVC WK_TEMP,X → MVC VAR,WK_TEMP → CLC) is
                # visible in relevant_code_lines.
                dest_idx = DEST_ARG_INDEX_BY_INST.get(inst, 0)
                _entry_var = str(entry.get("var") or "").strip().upper()
                # GAP-035: fall back to flow entry's 'var' field when args is empty
                # (columnar blueprint format stores dest variable in 'var' with args=None).
                _setter_hit = (
                    (dest_idx < len(args) and normalize_token(args[dest_idx]) == variable.upper())
                    or (not args and _entry_var == variable.upper())
                )
                if _setter_hit:
                    role = "SETTER_STEP"

            if role is not None:
                _payload = {
                    "line": e_line,
                    "inst": inst,
                    "role": role,
                    "detail": detail,
                }
                if verdict.get("prior_value_required"):
                    _payload["prior_value_required"] = True
                ok = _register_relevant_line(
                    node_data=node_data,
                    block_id=cur_block,
                    line_payload=_payload,
                    trace_state=trace_state,
                    local_counter=local_counter,
                )
                if not ok:
                    capped = True
                    break

                # SETTER_NO_DEPS (e.g. SP FIELD,FIELD): record the site but harvest no
                # source dep_vars.
                if not verdict.get("suppress_dep_vars"):
                    for dep in _collect_dep_vars(
                        inst,
                        args,
                        variable,
                        constant_symbols=constant_symbols,
                        var_field=str(entry.get("var") or ""),
                        extra_suppress_indexes=verdict.get("suppress_src_indexes"),
                    ):
                        node_data[cur_block]["dependent_vars"].add(dep)
                for dep in special_deps:
                    node_data[cur_block]["dependent_vars"].add(dep)
                # GAP-REG: back-track register operands found in TRIGGER_INST and
                # in SETTER_INST whose LHS matches the traced variable.
                _sub_flow_reg_args: List[str] = []
                if inst in TRIGGER_INST:
                    _sub_flow_reg_args = [a for a in args if looks_like_register_token(normalize_token(a))]
                elif inst in SETTER_INST and role == "SETTER_STEP":
                    _sub_fl_dest_idx = DEST_ARG_INDEX_BY_INST.get(inst, 0)
                    _sub_flow_reg_args = [
                        a for i, a in enumerate(args)
                        if i != _sub_fl_dest_idx and looks_like_register_token(normalize_token(a))
                    ]
                for _sub_fl_reg_arg in _sub_flow_reg_args:
                    for dep in _backtrack_register_dep_vars(
                        reg_name=normalize_token(_sub_fl_reg_arg),
                        start_block=cur_block,
                        before_line=e_line,
                        block_map=block_map,
                        cfg_incoming=cfg_incoming,
                        constant_symbols=constant_symbols,
                    ):
                        node_data[cur_block]["dependent_vars"].add(dep)
            # GAP-006 partial fix: register-indirect MVCL/MVCP/MVCS — attempt to
            # resolve the destination/source buffer names by back-tracking any
            # register-like operand through the CFG.  MVCL R0,R2: R0 = dest addr
            # register, R2 = source addr register.  MVCP/MVCS use D(L,B) notation;
            # the base-register B may appear as a register-like token in args[].
            if inst in REGISTER_INDIRECT_MOVE_INST:
                _movi_backtracked: List[str] = []
                _movi_regs_to_track: List[str] = []
                for _movi_arg in args:
                    _movi_reg = normalize_token(_movi_arg)
                    if not looks_like_register_token(_movi_reg):
                        continue
                    _movi_regs_to_track.append(_movi_reg)
                    # MVCL uses register pairs: also backtrack the odd register
                    # (R1 for R0, R3 for R2) to capture length dependencies.
                    if inst == "MVCL":
                        _m = re.match(r"^R(\d+)$", _movi_reg)
                        if _m:
                            _even_n = int(_m.group(1))
                            if _even_n % 2 == 0 and _even_n + 1 <= 15:
                                _movi_regs_to_track.append(f"R{_even_n + 1}")
                for _movi_reg in _movi_regs_to_track:
                    for dep in _backtrack_register_dep_vars(
                        reg_name=_movi_reg,
                        start_block=cur_block,
                        before_line=e_line,
                        block_map=block_map,
                        cfg_incoming=cfg_incoming,
                        constant_symbols=constant_symbols,
                        max_reg_hops=10,  # GAP-006: address chains for block moves can be longer
                    ):
                        node_data[cur_block]["dependent_vars"].add(dep)
                        _movi_backtracked.append(dep)
                _register_relevant_line(
                    node_data=node_data,
                    block_id=cur_block,
                    line_payload={
                        "line": e_line,
                        "inst": inst,
                        "role": "REGISTER_INDIRECT_MOVE",
                        "detail": detail,
                    },
                    trace_state=trace_state,
                    local_counter=local_counter,
                )
                # Issue-13: when backtracking fails, emit a synthetic dep_var
                # so the dependency gap is visible in the trace rather than
                # silently lost.  The synthetic name encodes the instruction,
                # register, block, and line for diagnostic traceability.
                if not _movi_backtracked and _movi_regs_to_track:
                    _synth = f"__unresolved_{inst}@{_movi_regs_to_track[0]}:{cur_block}:{e_line}"
                    node_data[cur_block]["dependent_vars"].add(_synth)
                    _movi_backtracked.append(_synth)
                warnings.append(
                    f"[GAP-006] Register-indirect {inst} at line {e_line} in block "
                    f"{cur_block}: "
                    + (
                        f"backtracked register operands → {_movi_backtracked}"
                        if _movi_backtracked
                        else "destination register could not be resolved to a named variable"
                    )
                )
            if inst in SUBROUTINE_INST:
                nested = _trace_subroutine_expansion(
                    variable=variable,
                    bp_data=bp_data,
                    block_map=block_map,
                    block_source_index=block_source_index,
                    call_inst=inst,
                    call_args=args,
                    call_detail=detail,
                    call_line=e_line,
                    caller_block=cur_block,
                    parent_scope=expansion_scope,
                    max_depth=max_depth,
                    depth_level=depth_level + 1,
                    max_subroutine_depth=max_subroutine_depth,
                    max_subroutine_nodes=max_subroutine_nodes,
                    trace_state=trace_state,
                    cycle_keys=cycle_keys,
                    cfg_outgoing=cfg_outgoing,
                    cfg_incoming=cfg_incoming,
                    constant_symbols=constant_symbols,
                    asm_file=asm_file,
                )
                nested_expansions.append(nested)
                if nested.get("warnings"):
                    warnings.extend(nested.get("warnings", []))
            if trace_state.get("global_capped"):
                capped = True
                break

        if capped:
            break

        for src, edge_type in cfg_incoming.get(cur_block, []):
            if not src:
                continue
            src_block = block_map.get(src)
            if not src_block:
                continue
            if src not in region_blocks:
                continue
            if edge_type not in {"BRANCH", "FALLTHROUGH"}:
                continue
            _ensure_node(node_data, src)
            _add_edge(edge_scopes, cur_block, src, edge_type, expansion_scope)
            queue.append((src, depth + 1))

    if local_counter.get("capped"):
        capped = True
        warnings.append(
            f"Subroutine '{sub_label}' capped at {max_subroutine_nodes} relevant lines."
        )
    if trace_state.get("global_capped"):
        capped = True
        warnings.append(
            f"Trace node cap reached ({trace_state.get('max_trace_nodes')})."
        )

    # Deterministic nested ordering.
    nested_expansions = sorted(
        nested_expansions,
        key=lambda x: (
            str(x.get("resolved_subroutine") or ""),
            int(x.get("line") or 0),
            str(x.get("resolution_confidence") or ""),
        ),
    )

    return {
        "line": call_line,
        "caller_block": caller_block,
        "call_instruction": call_inst,
        "target": sub_target,
        "resolved_subroutine": sub_label,
        "resolution_confidence": confidence,
        "start_line": sub_start,
        "end_line": sub_end,
        "return_anchor_lines": anchors,
        "call_graph": {
            "nodes": _sorted_graph_nodes(node_data, block_source_index),
            "edges": _sorted_graph_edges(edge_scopes),
        },
        "subroutine_expansions": nested_expansions,
        "warnings": sorted(set(str(w) for w in warnings if w)),
        "capped": bool(capped),
    }


def trace_asm_call_site_backward(
    variable: str,
    blueprint_path,
    asm_file,
    call_site: Dict[str, Any],
    max_depth: int = 8,
    max_subroutine_depth: int = DEFAULT_MAX_SUBROUTINE_DEPTH,
    max_subroutine_nodes: int = DEFAULT_MAX_SUBROUTINE_NODES,
    max_trace_nodes_per_site: int = DEFAULT_MAX_TRACE_NODES,
) -> Dict[str, Any]:
    # Issue-5: setter source is a compile-time constant — no runtime dep_vars to trace.
    if call_site.get("constant_source"):
        return {
            "call_site": call_site,
            "call_graph": {"nodes": [], "edges": []},
            "dep_vars": [],
            "subroutine_expansions": [],
            "warnings": [],
            "constant_source": True,
        }

    bp_data = load_json(blueprint_path)
    block_source_index = build_asm_block_source_index(bp_data, asm_file)
    constant_symbols = collect_constant_symbols(bp_data, asm_file=asm_file)

    block_map, cfg_outgoing, cfg_incoming = _get_file_cfg_maps(str(blueprint_path))

    start_block = str(call_site.get("routine") or "")
    call_line = int(call_site.get("line") or 0)
    call_inst = str(call_site.get("instruction") or "").upper()
    call_raw = str(call_site.get("raw_line") or f"{call_inst} {call_site.get('target_entry_point', '')}").strip()
    scope = f"{start_block}:{call_line}"

    warnings: List[str] = []
    if not start_block or start_block not in block_map:
        return {
            "call_site": call_site,
            "call_graph": {"nodes": [], "edges": []},
            "dep_vars": [],
            "subroutine_expansions": [],
            "warnings": [f"Call-site block '{start_block}' not found in blueprint"],
        }

    node_data: Dict[str, Dict[str, Any]] = {}
    edge_scopes: Dict[Tuple[str, str, str], Set[str]] = {}
    subroutine_expansions: List[Dict[str, Any]] = []
    cycle_keys: Set[Tuple[str, str, int, str]] = set()
    trace_state: Dict[str, Any] = {
        "total_trace_nodes": 0,
        "max_trace_nodes": int(max_trace_nodes_per_site),
        "global_capped": False,
    }

    queue: Deque[Tuple[str, int]] = deque([(start_block, 0)])
    visited: Set[str] = set()
    capped = False

    while queue:
        cur_block, depth = queue.popleft()
        if cur_block in visited or depth > max_depth:
            continue
        visited.add(cur_block)

        block = block_map.get(cur_block)
        if not block:
            continue

        _ensure_node(node_data, cur_block)

        if cur_block == start_block and call_line:
            ok = _register_relevant_line(
                node_data=node_data,
                block_id=cur_block,
                line_payload={
                    "line": call_line,
                    "inst": call_inst,
                    "role": "CALL_SITE",
                    "detail": call_raw,
                },
                trace_state=trace_state,
            )
            if not ok:
                warnings.append(f"Trace node cap reached ({max_trace_nodes_per_site}) while recording call-site line.")
                capped = True
                break
            # Collect dep_vars from the CALL_SITE line only when the call instruction is a trigger opcode.
            call_site_args: List[str] = []
            for entry in iter_flow(block):
                if int(entry.get("line") or 0) == call_line:
                    call_site_args = [str(a) for a in (entry.get("args") or [])]
                    break
            if not call_site_args and call_raw:
                call_site_args = _parse_raw_operands(call_raw, call_inst)
            # Audit §5 Fix #1: _collect_dep_vars already performs the dest-aware,
            # suppression-aware source harvest for SETTER_INST, gated on the dest
            # operand matching the traced variable.  The previous fixed `args[1:]`
            # slice here had NO LHS guard and leaked the dest field itself (e.g.
            # FIELDNAME in `ST R5,FIELDNAME`, or WK_REGS in `STM R14,R7,WK_REGS`)
            # as a spurious dep_var for unrelated traced variables — removed.
            for dep in _collect_dep_vars(call_inst, call_site_args, variable, constant_symbols=constant_symbols):
                node_data[cur_block]["dependent_vars"].add(dep)
            # GAP-REG: back-track register operands from SETTER_INST source args and
            # TRIGGER_INST operands at the call-site line.
            _cs_reg_args: List[str] = []
            if call_inst in TRIGGER_INST:
                _cs_reg_args = [a for a in call_site_args if looks_like_register_token(normalize_token(a))]
            elif call_inst in SETTER_INST:
                _cs_dest_idx = DEST_ARG_INDEX_BY_INST.get(call_inst, 0)
                _cs_reg_args = [
                    a for i, a in enumerate(call_site_args)
                    if i != _cs_dest_idx and looks_like_register_token(normalize_token(a))
                ]
            for _cs_reg in _cs_reg_args:
                for dep in _backtrack_register_dep_vars(
                    reg_name=normalize_token(_cs_reg),
                    start_block=cur_block,
                    before_line=call_line,
                    block_map=block_map,
                    cfg_incoming=cfg_incoming,
                    constant_symbols=constant_symbols,
                ):
                    node_data[cur_block]["dependent_vars"].add(dep)

        flow_entries = list(iter_flow(block))
        for entry_index, entry in enumerate(flow_entries):
            inst = str(entry.get("inst", "")).upper()
            e_line = int(entry.get("line") or 0)
            if cur_block == start_block and call_line and e_line >= call_line:
                continue

            args = [str(a) for a in (entry.get("args") or [])]
            # EX/EXRL expansion: resolve the target instruction at the label
            # and substitute inst/args for role/dep classification.
            if inst in EXECUTE_INST:
                _ex_label = args[1] if len(args) > 1 else ""
                _ex_resolved = resolve_ex_target(bp_data, normalize_token(_ex_label))
                if _ex_resolved:
                    inst = str(_ex_resolved.get("inst") or "").upper()
                    args = [str(a) for a in (_ex_resolved.get("args") or [])]
                else:
                    continue  # cannot resolve EX target
            detail = ", ".join(args) if args else str(entry.get("detail") or "")
            verdict, special_deps = _collect_special_case_dep_vars(
                flow_entries,
                entry_index,
                variable,
                constant_symbols=constant_symbols,
                cfg_outgoing=cfg_outgoing,
                block_map=block_map,
                cur_block=cur_block,
                resolved_inst=inst,
                resolved_args=args,
            )

            # Audit §3a/§3b/§3d: value-preserving / spec-exception self-ops are NOT
            # setter sites — do not record them or harvest deps; surface any warning.
            if verdict.get("skip_setter_site"):
                _w = verdict.get("warn")
                if _w:
                    warnings.append(_w)
                continue

            role: Optional[str] = None
            if inst in TRIGGER_INST:
                role = _inst_to_role(inst, "CONDITION_CHECK")
            elif verdict.get("role") == "CONDITION_CHECK":
                role = "CONDITION_CHECK"
            elif inst in BRANCH_INST:
                role = _inst_to_role(inst, "BRANCH_STEP")
            elif inst in SUBROUTINE_INST:
                role = "SUBROUTINE_CALL"
            elif inst in CROSS_FILE_INST:
                role = "CROSS_FILE_CALL"
            elif inst in NON_RETURNING_CALL_OPCODES:
                role = "NON_RETURNING_CALL"
            elif inst in ASYNC_CALL_OPCODES:
                role = "ASYNC_SPAWN"
            elif inst in MACRO_CALL_OPCODES:
                role = "MACRO_CALL"
            elif inst in SETTER_INST:
                # GAP-001: record setter steps whose LHS is the traced variable so
                # the data-flow chain (MVC WK_TEMP,X → MVC VAR,WK_TEMP → CLC) is
                # visible in relevant_code_lines.
                dest_idx = DEST_ARG_INDEX_BY_INST.get(inst, 0)
                _entry_var2 = str(entry.get("var") or "").strip().upper()
                # GAP-035: same columnar-format fallback as main trace loop above.
                _setter_hit2 = (
                    (dest_idx < len(args) and normalize_token(args[dest_idx]) == variable.upper())
                    or (not args and _entry_var2 == variable.upper())
                )
                if _setter_hit2:
                    role = "SETTER_STEP"

            if role is not None:
                _payload = {
                    "line": e_line,
                    "inst": inst,
                    "role": role,
                    "detail": detail,
                }
                if verdict.get("prior_value_required"):
                    _payload["prior_value_required"] = True
                ok = _register_relevant_line(
                    node_data=node_data,
                    block_id=cur_block,
                    line_payload=_payload,
                    trace_state=trace_state,
                )
                if not ok:
                    warnings.append(f"Trace node cap reached ({max_trace_nodes_per_site}) while tracing {start_block}.")
                    capped = True
                    break

                # SETTER_NO_DEPS (e.g. SP FIELD,FIELD): record the site but harvest no
                # source dep_vars.
                if not verdict.get("suppress_dep_vars"):
                    for dep in _collect_dep_vars(
                        inst,
                        args,
                        variable,
                        constant_symbols=constant_symbols,
                        var_field=str(entry.get("var") or ""),
                        extra_suppress_indexes=verdict.get("suppress_src_indexes"),
                    ):
                        node_data[cur_block]["dependent_vars"].add(dep)
                for dep in special_deps:
                    node_data[cur_block]["dependent_vars"].add(dep)
                # GAP-REG: back-track register operands found in TRIGGER_INST and
                # in SETTER_INST whose LHS matches the traced variable.
                _flow_reg_args: List[str] = []
                if inst in TRIGGER_INST:
                    _flow_reg_args = [a for a in args if looks_like_register_token(normalize_token(a))]
                elif inst in SETTER_INST and role == "SETTER_STEP":
                    _fl_dest_idx = DEST_ARG_INDEX_BY_INST.get(inst, 0)
                    _flow_reg_args = [
                        a for i, a in enumerate(args)
                        if i != _fl_dest_idx and looks_like_register_token(normalize_token(a))
                    ]
                for _fl_reg_arg in _flow_reg_args:
                    for dep in _backtrack_register_dep_vars(
                        reg_name=normalize_token(_fl_reg_arg),
                        start_block=cur_block,
                        before_line=e_line,
                        block_map=block_map,
                        cfg_incoming=cfg_incoming,
                        constant_symbols=constant_symbols,
                    ):
                        node_data[cur_block]["dependent_vars"].add(dep)
            # GAP-006 partial fix: same register back-tracking as the subroutine
            # expansion path above — iterate all register-like args and call
            # _backtrack_register_dep_vars on each.
            if inst in REGISTER_INDIRECT_MOVE_INST:
                _movi_backtracked: List[str] = []
                _movi_regs_to_track: List[str] = []
                for _movi_arg in args:
                    _movi_reg = normalize_token(_movi_arg)
                    if not looks_like_register_token(_movi_reg):
                        continue
                    _movi_regs_to_track.append(_movi_reg)
                    # MVCL uses register pairs: also backtrack the odd register
                    # (R1 for R0, R3 for R2) to capture length dependencies.
                    if inst == "MVCL":
                        _m = re.match(r"^R(\d+)$", _movi_reg)
                        if _m:
                            _even_n = int(_m.group(1))
                            if _even_n % 2 == 0 and _even_n + 1 <= 15:
                                _movi_regs_to_track.append(f"R{_even_n + 1}")
                for _movi_reg in _movi_regs_to_track:
                    for dep in _backtrack_register_dep_vars(
                        reg_name=_movi_reg,
                        start_block=cur_block,
                        before_line=e_line,
                        block_map=block_map,
                        cfg_incoming=cfg_incoming,
                        constant_symbols=constant_symbols,
                        max_reg_hops=10,  # GAP-006: extended for multi-hop arithmetic chains
                    ):
                        node_data[cur_block]["dependent_vars"].add(dep)
                        _movi_backtracked.append(dep)
                _register_relevant_line(
                    node_data=node_data,
                    block_id=cur_block,
                    line_payload={
                        "line": e_line,
                        "inst": inst,
                        "role": "REGISTER_INDIRECT_MOVE",
                        "detail": detail,
                    },
                    trace_state=trace_state,
                )
                # Issue-13: when backtracking fails, emit a synthetic dep_var
                # so the dependency gap is visible in the trace rather than
                # silently lost.  The synthetic name encodes the instruction,
                # register, block, and line for diagnostic traceability.
                if not _movi_backtracked and _movi_regs_to_track:
                    _synth = f"__unresolved_{inst}@{_movi_regs_to_track[0]}:{cur_block}:{e_line}"
                    node_data[cur_block]["dependent_vars"].add(_synth)
                    _movi_backtracked.append(_synth)
                warnings.append(
                    f"[GAP-006] Register-indirect {inst} at line {e_line} in block "
                    f"{cur_block}: "
                    + (
                        f"backtracked register operands → {_movi_backtracked}"
                        if _movi_backtracked
                        else "destination register could not be resolved to a named variable"
                    )
                )
            if inst in SUBROUTINE_INST:
                expansion = _trace_subroutine_expansion(
                    variable=variable,
                    bp_data=bp_data,
                    block_map=block_map,
                    block_source_index=block_source_index,
                    call_inst=inst,
                    call_args=args,
                    call_detail=detail,
                    call_line=e_line,
                    caller_block=cur_block,
                    parent_scope=scope,
                    max_depth=max_depth,
                    depth_level=1,
                    max_subroutine_depth=max_subroutine_depth,
                    max_subroutine_nodes=max_subroutine_nodes,
                    trace_state=trace_state,
                    cycle_keys=cycle_keys,
                    cfg_outgoing=cfg_outgoing,
                    cfg_incoming=cfg_incoming,
                    constant_symbols=constant_symbols,
                    asm_file=asm_file,
                )
                subroutine_expansions.append(expansion)
                if expansion.get("warnings"):
                    warnings.extend(expansion.get("warnings", []))
            if trace_state.get("global_capped"):
                capped = True
                break

        if capped:
            break

        for src, edge_type in cfg_incoming.get(cur_block, []):
            if not src:
                continue
            if edge_type not in {"BRANCH", "FALLTHROUGH"}:
                continue
            _ensure_node(node_data, src)
            _add_edge(edge_scopes, cur_block, src, edge_type, scope)
            if src not in visited:
                queue.append((src, depth + 1))

    if trace_state.get("global_capped"):
        warnings.append(f"Trace node cap reached ({max_trace_nodes_per_site}).")

    subroutine_expansions = sorted(
        subroutine_expansions,
        key=lambda x: (
            int(x.get("line") or 0),
            str(x.get("resolved_subroutine") or ""),
            str(x.get("resolution_confidence") or ""),
        ),
    )

    # Flat dep_vars: union of all per-node dependent_variables for convenience.
    _flat_dep_vars: List[str] = sorted({
        dv
        for nd in node_data.values()
        for dv in (nd.get("dependent_vars") or set())
        if dv
    })

    return {
        "call_site": call_site,
        "call_graph": {
            "nodes": _sorted_graph_nodes(node_data, block_source_index),
            "edges": _sorted_graph_edges(edge_scopes),
        },
        "dep_vars": _flat_dep_vars,
        "subroutine_expansions": subroutine_expansions,
        "warnings": sorted(set(str(w) for w in warnings if w)),
    }


def merge_call_graphs(graphs: List[Dict[str, Any]]) -> Dict[str, Any]:
    node_data: Dict[str, Dict[str, Any]] = {}
    edge_data: Dict[Tuple[str, str, str], Dict[str, Any]] = {}

    for g in graphs:
        for n in (g.get("nodes") or []):
            bid = str(n.get("id") or "")
            if not bid:
                continue
            if bid not in node_data:
                node_data[bid] = {
                    "id": bid,
                    "code": n.get("code") or "",
                    "relevant_code_lines": [],
                    "dependent_variables": set(),
                }
            if not node_data[bid]["code"] and n.get("code"):
                node_data[bid]["code"] = n.get("code")
            for rl in (n.get("relevant_code_lines") or []):
                _merge_relevant_line(node_data[bid]["relevant_code_lines"], rl)
            for dv in (n.get("dependent_variables") or []):
                node_data[bid]["dependent_variables"].add(str(dv))

        for e in (g.get("edges") or []):
            key = (str(e.get("source") or ""), str(e.get("target") or ""), str(e.get("type") or ""))
            if key not in edge_data:
                edge_data[key] = {
                    "source": key[0],
                    "target": key[1],
                    "type": key[2],
                    "direction": set(),
                    "scopes": set(),
                }
            for d in (e.get("direction") or []):
                edge_data[key]["direction"].add(str(d))
            for s in (e.get("scopes") or []):
                edge_data[key]["scopes"].add(str(s))

    nodes_out = []
    for _, data in node_data.items():
        nodes_out.append(
            {
                "id": data["id"],
                "code": data["code"],
                "relevant_code_lines": sorted(data["relevant_code_lines"], key=lambda x: (int(x.get("line") or 0), str(x.get("role") or ""))),
                "dependent_variables": sorted(data["dependent_variables"]),
            }
        )

    edges_out = []
    for _, data in edge_data.items():
        edges_out.append(
            {
                "source": data["source"],
                "target": data["target"],
                "type": data["type"],
                "direction": sorted(data["direction"]),
                "scopes": sorted(data["scopes"]),
            }
        )

    return {
        "nodes": sorted(nodes_out, key=lambda n: str(n.get("id") or "")),
        "edges": sorted(edges_out, key=lambda e: (e["source"], e["target"], e["type"])),
    }
