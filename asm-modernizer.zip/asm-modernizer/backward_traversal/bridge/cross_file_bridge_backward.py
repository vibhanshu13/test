"""Isolated cross-file call-site bridge for backward-only traversal."""

from __future__ import annotations

import logging
from itertools import groupby as _groupby
from typing import Any, Dict, List, Optional, Set

from pathlib import Path

from backward_traversal.utils.blueprint_utils import fetch_raw_line, load_json

logger = logging.getLogger(__name__)

# Per-blueprint index of call_graph.edges grouped by UPPER(target). Built once per parsed blueprint
# dict and reused across every (caller, callee) bridge call, replacing the linear edges scan that
# find_asm_callers did per call (the dominant per-edge cost in walk_callers' ASM-hub closure). Keyed
# by id(bp) with a held-ref identity re-check (mirrors chainless_reachability._REV_ADJ_MEMO) so an
# LRU-recycled id can never return a stale index. Byte-identical: groups preserve the ORIGINAL edge
# order, so a single-target lookup yields exactly the filtered linear scan. Bounded (FIFO).
_EDGE_BY_TARGET_MEMO: Dict[int, tuple] = {}
_EDGE_BY_TARGET_MEMO_MAX = 512


def _edges_by_target(bp: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    """``UPPER(edge.target) -> [edges]`` over ``bp.call_graph.edges``, original order. Memoized per bp."""
    k = id(bp)
    hit = _EDGE_BY_TARGET_MEMO.get(k)
    if hit is not None and hit[0] is bp:   # identity re-check guards id reuse after LRU eviction
        return hit[1]
    idx: Dict[str, List[Dict[str, Any]]] = {}
    for edge in ((bp.get("call_graph", {}) or {}).get("edges", []) or []):
        idx.setdefault(str(edge.get("target") or "").upper(), []).append(edge)
    if len(_EDGE_BY_TARGET_MEMO) >= _EDGE_BY_TARGET_MEMO_MAX:
        _EDGE_BY_TARGET_MEMO.pop(next(iter(_EDGE_BY_TARGET_MEMO)))
    _EDGE_BY_TARGET_MEMO[k] = (bp, idx)    # hold the bp ref so its id stays valid while cached
    return idx

# Like _edges_by_target but each bucket entry carries the edge's ORIGINAL position in call_graph.edges.
# Used by the cross-language bridges (find_asm_to_cpp / find_cpp_to_asm) whose output is emitted in raw
# EDGE ORDER with no final sort: collecting matches across several callee entry points then re-sorting
# by orig_idx reproduces that exact scan order — and hence the exact (source,line) first-occurrence
# dedup — so the index is byte-identical. Kept separate from _edges_by_target so the two proven
# consumers (find_asm_callers, find_cpp_to_cpp) are untouched. Bounded FIFO, identity re-check on id.
_EDGE_ENUM_MEMO: Dict[int, tuple] = {}
_EDGE_ENUM_MEMO_MAX = 512


def _edges_by_target_enum(bp: Dict[str, Any]) -> Dict[str, List[tuple]]:
    """``UPPER(edge.target) -> [(orig_idx, edge)]`` over ``bp.call_graph.edges``. Memoized per bp."""
    k = id(bp)
    hit = _EDGE_ENUM_MEMO.get(k)
    if hit is not None and hit[0] is bp:
        return hit[1]
    idx: Dict[str, List[tuple]] = {}
    for i, edge in enumerate(((bp.get("call_graph", {}) or {}).get("edges", []) or [])):
        idx.setdefault(str(edge.get("target") or "").upper(), []).append((i, edge))
    if len(_EDGE_ENUM_MEMO) >= _EDGE_ENUM_MEMO_MAX:
        _EDGE_ENUM_MEMO.pop(next(iter(_EDGE_ENUM_MEMO)))
    _EDGE_ENUM_MEMO[k] = (bp, idx)
    return idx


try:
    from blueprint_io import iter_flow
except ImportError:
    import sys as _sys
    import os as _os
    _sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.dirname(__file__))))
    from blueprint_io import iter_flow


def _safe_load(bp_path: Path) -> Optional[Dict[str, Any]]:
    if not bp_path.exists():
        return None
    try:
        return load_json(bp_path)
    except Exception:
        return None


def find_cpp_to_cpp_callers(
    caller_stem: str,
    callee_stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path] = None,
) -> List[Dict[str, Any]]:
    callee_bp = _safe_load(blueprint_dir / f"{callee_stem}.cpp.json")
    caller_bp = _safe_load(blueprint_dir / f"{caller_stem}.cpp.json")
    if not callee_bp or not caller_bp:
        return []

    callee_functions = set((callee_bp.get("asm_entry_point_map") or {}).values())
    if not callee_functions:
        # NEW-E: match find_cpp_to_asm_callers which checks {"entry","csect","public"}.
        for name, sym in (callee_bp.get("symbols", {}).get("global_symbols", {}) or {}).items():
            if str((sym or {}).get("type") or "").strip().lower() in {"entry", "csect", "public"}:
                callee_functions.add(name)

    if not callee_functions:
        return []

    # Source 1: the caller's call_graph.edges, indexed by UPPER(target) so a hub caller's full edge
    # list is scanned ONCE per parsed bp (built + memoized) instead of re-scanned for every callee it
    # is a candidate caller of — the C++ analogue of find_asm_callers' Fix-C index. Byte-identical by
    # construction: the output below is `sorted(call_pairs, key=_dedup_key)` (a target-inclusive key),
    # so call_pairs ORDER is irrelevant except among exact-key ties — and exact-key ties share a target,
    # hence the same index bucket, where original edge order is preserved. The raw-case re-check below
    # (`target not in callee_functions`) reproduces the original filter exactly (index keys are UPPER,
    # so it also drops any case-mismatch the original scan would have skipped). Iterating the unique
    # UPPER keys visits each matching edge exactly once (one target → one bucket).
    _idx = _edges_by_target(caller_bp)
    _matched_edges = [e for _tu in {str(t).upper() for t in callee_functions}
                      for e in _idx.get(_tu, [])]
    call_pairs: List[Dict[str, Any]] = []
    for edge in _matched_edges:
        target = edge.get("target") or ""
        if target not in callee_functions:
            continue
        line_no = edge.get("line")
        file_field = edge.get("file", "")
        raw_line = None
        if line_no is not None and file_field:
            raw_line = fetch_raw_line(file_field, int(line_no), asm_dir)  # ISSUE-2: pass asm_dir
        from api.utils.indirection import merge_indirection
        pair = {
            "caller_function": edge.get("source"),
            "callee_function": target,
            "line": line_no,
            "file": file_field,
            "instruction": edge.get("instruction"),
            "call_type": edge.get("call_type"),
            "raw_line": raw_line,
        }
        merge_indirection(pair, edge)
        call_pairs.append(pair)

    def _dedup_key(p: Dict[str, Any]) -> tuple:
        # C5.1 fix: include line number so calls between the same function pair
        # at different source lines are never collapsed as duplicates.
        return (p.get("caller_function"), p.get("callee_function"), p.get("file"), p.get("line"))

    deduped: List[Dict[str, Any]] = []
    for _, group in _groupby(sorted(call_pairs, key=_dedup_key), key=_dedup_key):
        cluster: List[Dict[str, Any]] = []
        for site in sorted(group, key=lambda p: (p.get("line") or 0)):
            if not cluster:
                cluster.append(site)
                continue
            last_line = cluster[-1].get("line") or 0
            this_line = site.get("line") or 0
            if abs(this_line - last_line) <= 3:
                callee_name = site.get("callee_function") or ""
                existing_raw = cluster[-1].get("raw_line") or ""
                candidate_raw = site.get("raw_line") or ""
                if callee_name and callee_name in candidate_raw and callee_name not in existing_raw:
                    cluster[-1] = site
            else:
                cluster.append(site)
        deduped.extend(cluster)

    return deduped



def _extract_flow_target(item: Dict[str, Any]) -> str:
    """Extract the target module token from a blocks[].flow item."""
    inst = str(item.get("inst") or "").upper()
    args = item.get("args") or []
    # Case-2 fix: FUNCTION macro format is "FUNCTION <name>,<seg>[,options...]".
    # args[0] = 4-char runtime lookup key (DC CL4'&NAME'), args[1] = segment entered.
    # Previous code (GAP-025 comment) used args[0] and thus resolved to the lookup key
    # instead of the actual callee segment, producing wrong or nonexistent edges.
    if inst == "FUNCTION":
        raw = str(args[1]) if len(args) > 1 else ""
    else:
        raw = str(args[0]) if args else ""
    tok = raw.strip().split()[0].split(",")[0] if raw.strip() else ""
    tok_upper = tok.upper()
    # Detect register-indirect form: "(R0)" ... "(R15)".
    # These cannot be statically resolved; return "" to avoid emitting a false edge.
    if tok_upper.startswith("(") and tok_upper.endswith(")"):
        inner = tok_upper[1:-1]
        import re as _re
        if _re.match(r"^R\d{1,2}$", inner) and int(inner[1:]) <= 15:
            return ""  # register-indirect: cannot statically resolve
    return tok_upper


# Per-bp index of blocks[].flow call sites keyed by UPPER(_extract_flow_target(item)) — the Source-2
# scan every bridge does. Built ONCE per parsed bp (id-keyed, held-ref re-check, FIFO-bounded) and
# reused across the closure's many bridge calls, instead of re-scanning every block per call (the
# 2.7M-iter_flow hot spot in a cold trace). Each entry carries (seq, block_id, item); seq = the global
# block-then-flow position, so the SET-matching bridges re-sort matches to that exact order. Byte-
# identical: the same items in the same order — every bridge keeps its own inst filter + (block,line)
# seen-dedup, which the index does NOT apply. Empty-target ("" — register-indirect / no target) items
# are never matched by any bridge, so they are not indexed (seq still advances to keep positions exact).
_FLOW_BY_TARGET_MEMO: Dict[int, tuple] = {}
_FLOW_BY_TARGET_MEMO_MAX = 512


def _flow_by_target(bp: Dict[str, Any]) -> Dict[str, List[tuple]]:
    """``UPPER(flow target) -> [(seq, block_id, item)]`` over ``bp.blocks[].flow``, block-then-flow order."""
    k = id(bp)
    hit = _FLOW_BY_TARGET_MEMO.get(k)
    if hit is not None and hit[0] is bp:
        return hit[1]
    idx: Dict[str, List[tuple]] = {}
    seq = 0
    for block in (bp.get("blocks") or []):
        block_id = str(block.get("id") or "")
        if not block_id:
            continue
        for item in iter_flow(block):
            tgt = _extract_flow_target(item)
            if tgt:
                idx.setdefault(tgt, []).append((seq, block_id, item))
            seq += 1
    if len(_FLOW_BY_TARGET_MEMO) >= _FLOW_BY_TARGET_MEMO_MAX:
        _FLOW_BY_TARGET_MEMO.pop(next(iter(_FLOW_BY_TARGET_MEMO)))
    _FLOW_BY_TARGET_MEMO[k] = (bp, idx)
    return idx


def find_asm_callers(
    caller_stem: str,
    callee_stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path] = None,
) -> List[Dict[str, Any]]:
    bp = _safe_load(blueprint_dir / f"{caller_stem}.asm.json")
    if not bp:
        bp = _safe_load(blueprint_dir / f"{caller_stem}.mac.json")
    if not bp:
        return []

    from backward_traversal.glossary.instructions import (
        ASYNC_CALL_OPCODES, CROSS_FILE_INST, NON_RETURNING_CALL_OPCODES,
    )
    # Include ENTDC/ENTNC and CREEC family even though they were removed from CROSS_FILE_INST:
    # they are still cross-file transfers whose call sites must be discoverable.
    # The runner's _is_followable_cross_file_call() decides whether to follow them.
    cross_inst = {str(i).upper() for i in CROSS_FILE_INST | NON_RETURNING_CALL_OPCODES | ASYNC_CALL_OPCODES}
    callee_upper = callee_stem.upper()
    call_sites: List[Dict[str, Any]] = []
    seen: set = set()  # (routine, line)

    # Source 1: call_graph.edges — indexed by UPPER(target) so a hub caller's full edge list is
    # scanned ONCE (built per bp), not re-scanned per (caller, callee). Byte-identical: the index
    # group is exactly the edges the filtered linear scan yielded, in the same order.
    for edge in _edges_by_target(bp).get(callee_upper, []):
        line_no = edge.get("line")
        file_field = edge.get("file", "")
        raw_line = None
        if line_no is not None and file_field:
            raw_line = fetch_raw_line(file_field, int(line_no), asm_dir)
        key = (edge.get("source"), line_no)
        if key in seen:
            continue
        seen.add(key)
        from api.utils.indirection import merge_indirection
        _site = {
            "routine": edge.get("source"),
            "line": line_no,
            "instruction": edge.get("instruction"),
            "call_type": edge.get("call_type"),
            "raw_line": raw_line,
        }
        merge_indirection(_site, edge)
        call_sites.append(
            _site
        )

    # Source 2: blocks[].flow (catches calls missing from call_graph) — via the per-bp flow index, so
    # the block scan is built once and reused across the closure, not repeated per call. Byte-identical:
    # index[callee_upper] is exactly the matching items in block-then-flow order; the inst filter and
    # the (block,line) seen-dedup are unchanged.
    for _seq, block_id, item in _flow_by_target(bp).get(callee_upper, ()):
        inst = str(item.get("inst") or "").upper()
        if inst not in cross_inst:
            continue
        line_no = item.get("line")
        key = (block_id, line_no)
        if key in seen:
            continue
        seen.add(key)
        file_field = ""
        raw_line = None
        if line_no is not None and asm_dir:
            src = asm_dir / f"{caller_stem}.asm"
            if src.exists():
                raw_line = fetch_raw_line(str(src), int(line_no), asm_dir)
        call_sites.append(
            {
                "routine": block_id,
                "line": line_no,
                "instruction": inst,
                "call_type": None,
                "raw_line": raw_line,
            }
        )

    # C5.2 fix: warn when asm_dir is absent so callers know raw_line will be None.
    if asm_dir is None and any(cs.get("line") is not None for cs in call_sites):
        logger.warning(
            "find_asm_callers %s→%s: asm_dir not provided — raw_line will be None "
            "for %d call site(s). Pass asm_dir to enable source line extraction.",
            caller_stem, callee_stem,
            sum(1 for cs in call_sites if cs.get("line") is not None),
        )
    return call_sites


def find_asm_to_cpp_callers(
    caller_stem: str,
    callee_stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path] = None,
) -> List[Dict[str, Any]]:
    cpp_bp = _safe_load(blueprint_dir / f"{callee_stem}.cpp.json")
    asm_bp = _safe_load(blueprint_dir / f"{caller_stem}.asm.json")
    if not asm_bp:
        asm_bp = _safe_load(blueprint_dir / f"{caller_stem}.mac.json")
    if not cpp_bp or not asm_bp:
        return []

    asm_map: Dict[str, str] = (cpp_bp.get("asm_entry_point_map") or {})
    asm_names_upper: Dict[str, str] = {k.upper(): v for k, v in asm_map.items()}

    if not asm_names_upper:
        gs = (cpp_bp.get("symbols", {}) or {}).get("global_symbols", {}) or {}
        for name, sym in gs.items():
            if (sym.get("type") or "") == "entry":
                asm_names_upper.setdefault(name.upper(), name)

    if not asm_names_upper:
        return []

    from backward_traversal.glossary.instructions import (
        ASYNC_CALL_OPCODES, CROSS_FILE_INST, NON_RETURNING_CALL_OPCODES,
    )
    cross_inst = {str(i).upper() for i in CROSS_FILE_INST | NON_RETURNING_CALL_OPCODES | ASYNC_CALL_OPCODES}
    call_sites: List[Dict[str, Any]] = []
    seen: set = set()  # (routine, line)

    # Source 1: call_graph.edges, indexed by UPPER(target) (built+memoized per bp) so a hub caller's
    # full edge list is scanned ONCE, not re-scanned per callee. Output is raw edge order (no final
    # sort), so matches across the callee's entry points are re-sorted by orig_idx → exact scan order →
    # exact (source,line) first-occurrence dedup. Byte-identical. asm_names_upper keys are UPPER, so
    # every collected edge satisfies the original `target_upper not in asm_names_upper` filter (each
    # edge sits in exactly one bucket; the keys are unique → each match collected once).
    _enum = _edges_by_target_enum(asm_bp)
    _matched = sorted((p for _tu in asm_names_upper for p in _enum.get(_tu, [])),
                      key=lambda p: p[0])
    for _oi, edge in _matched:
        target_raw = edge.get("target") or ""
        target_upper = target_raw.upper()
        line_no = edge.get("line")
        file_field = edge.get("file", "")
        raw_line = None
        if line_no is not None and file_field:
            raw_line = fetch_raw_line(file_field, int(line_no), asm_dir)
        key = (edge.get("source"), line_no)
        if key in seen:
            continue
        seen.add(key)
        from api.utils.indirection import merge_indirection
        _site = {
            "routine": edge.get("source"),
            "line": line_no,
            "instruction": edge.get("instruction"),
            "call_type": edge.get("call_type"),
            "raw_line": raw_line,
            "target_entry_point": target_raw,
            "cpp_function": asm_names_upper[target_upper],
        }
        merge_indirection(_site, edge)
        call_sites.append(_site)

    # Source 2: blocks[].flow via the per-bp flow index — collect items whose target is one of the
    # callee's entry points, re-sorted by seq back to the original block-then-flow order so the inst
    # filter + (block,line) seen-dedup reproduce the linear scan exactly. Byte-identical.
    _matched = sorted((t for _tu in asm_names_upper for t in _flow_by_target(asm_bp).get(_tu, ())),
                      key=lambda t: t[0])
    for _seq, block_id, item in _matched:
        inst = str(item.get("inst") or "").upper()
        if inst not in cross_inst:
            continue
        flow_target = _extract_flow_target(item)
        line_no = item.get("line")
        key = (block_id, line_no)
        if key in seen:
            continue
        seen.add(key)
        raw_line = None
        if line_no is not None and asm_dir:
            src = asm_dir / f"{caller_stem}.asm"
            if src.exists():
                raw_line = fetch_raw_line(str(src), int(line_no), asm_dir)
        call_sites.append(
            {
                "routine": block_id,
                "line": line_no,
                "instruction": inst,
                "call_type": None,
                "raw_line": raw_line,
                "target_entry_point": flow_target,
                "cpp_function": asm_names_upper[flow_target],
            }
        )

    return call_sites


def find_cpp_to_asm_callers(
    cpp_stem: str,
    asm_stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path] = None,
) -> List[Dict[str, Any]]:
    """Find call sites in a C++ file that call into an ASM file.

    Mirrors find_asm_to_cpp_callers but in the reverse direction: scans the
    C++ blueprint's call_graph.edges for calls to any known entry point of the
    ASM callee.

    The output key is "function" (not "caller_function") to match the
    find_cpp_callers() convention consumed by _build_cpp_upstream_payload().

    Parameters
    ----------
    cpp_stem:
        The C++ caller file stem (e.g. "dx740200").
    asm_stem:
        The ASM callee file stem (e.g. "dx7402a0").
    blueprint_dir:
        Directory containing both .cpp.json and .asm.json blueprints.
    asm_dir:
        Optional source directory used to fetch raw source lines.
    """
    cpp_bp = _safe_load(blueprint_dir / f"{cpp_stem}.cpp.json")
    asm_bp = _safe_load(blueprint_dir / f"{asm_stem}.asm.json")
    if not asm_bp:
        asm_bp = _safe_load(blueprint_dir / f"{asm_stem}.mac.json")
    if not cpp_bp or not asm_bp:
        return []

    # Build the set of known entry-point symbols for the ASM callee (uppercased).
    # Start with the stem itself — guarantees every edge find_cpp_callers() finds
    # today is also found here (backward-compatible with simple stem matching).
    asm_entry_points: Set[str] = {asm_stem.upper()}

    # Add keys from asm_entry_point_map if the ASM blueprint carries it.
    for key in (asm_bp.get("asm_entry_point_map") or {}):
        asm_entry_points.add(str(key).upper())

    # Fallback: if asm_entry_point_map added nothing new, scan global_symbols.
    # Check type in {"entry", "csect", "public"} — all represent callable entry
    # points in z/OS object code.
    if len(asm_entry_points) <= 1:
        gs = (asm_bp.get("symbols") or {}).get("global_symbols") or {}
        if isinstance(gs, dict):
            for name, sym in gs.items():
                stype = str((sym or {}).get("type") or "").strip().lower()
                if stype in {"entry", "csect", "public"}:
                    asm_entry_points.add(str(name).upper())

    call_sites: List[Dict[str, Any]] = []
    seen: set = set()  # (source_function, line) dedup key

    # Source 1: indexed by UPPER(target) (built+memoized per bp) — same byte-identical re-sort-to-edge-
    # order scheme as find_asm_to_cpp. asm_entry_points is a set of UPPERs, so every collected edge
    # satisfies the original `target.upper() not in asm_entry_points` filter; matches re-sorted by
    # orig_idx reproduce the exact scan order and (source,line) first-occurrence dedup.
    _enum = _edges_by_target_enum(cpp_bp)
    _matched = sorted((p for _tu in asm_entry_points for p in _enum.get(_tu, [])),
                      key=lambda p: p[0])
    for _oi, edge in _matched:
        line_no = edge.get("line")
        file_field = edge.get("file", "")
        raw_line = None
        if line_no is not None and file_field:
            raw_line = fetch_raw_line(file_field, int(line_no), asm_dir)
        key = (edge.get("source"), line_no)
        if key in seen:
            continue
        seen.add(key)
        from api.utils.indirection import merge_indirection
        _site = {
            "function":           edge.get("source"),       # matches find_cpp_callers() key
            "line":               line_no,
            "instruction":        edge.get("instruction"),
            "call_type":          edge.get("call_type"),
            "raw_line":           raw_line,
            "target_entry_point": edge.get("target"),
        }
        merge_indirection(_site, edge)
        call_sites.append(_site)

    # Source 2: blocks[].flow via the per-bp flow index — items whose target is an ASM entry point,
    # re-sorted by seq back to the original block-then-flow order. No inst pre-filter (mirrors the
    # original), so the (block,line) seen-dedup reproduces the linear scan exactly. Byte-identical.
    _matched = sorted((t for _tu in asm_entry_points for t in _flow_by_target(cpp_bp).get(_tu, ())),
                      key=lambda t: t[0])
    for _seq, block_id, item in _matched:
        flow_target = _extract_flow_target(item)
        line_no = item.get("line")
        key = (block_id, line_no)
        if key in seen:
            continue
        seen.add(key)
        raw_line = None
        if line_no is not None and asm_dir:
            src = asm_dir / f"{cpp_stem}.cpp"
            if src.exists():
                raw_line = fetch_raw_line(str(src), int(line_no), asm_dir)
        call_sites.append({
            "function":           block_id,
            "line":               line_no,
            "instruction":        str(item.get("inst") or "").upper(),
            "call_type":          None,
            "raw_line":           raw_line,
            "target_entry_point": flow_target,
        })

    return call_sites
