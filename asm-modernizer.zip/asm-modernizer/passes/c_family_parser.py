"""C/C++ parser using tree-sitter (optional)."""

import re
from pathlib import Path
from typing import Optional, List, Tuple, Dict, Set, TYPE_CHECKING

if TYPE_CHECKING:
    from passes.c_line_metadata_collector import CLineMetadataCollector

from models.c_family import (
    CTranslationUnit,
    CFunction,
    CCall,
    CAssignment,
    CReturn,
    CDeclaration,
    CCondition,
    CMacroDefinition,
)


# Memory-write intrinsics that semantically assign to their first argument.
# Matching calls synthesize an extra CAssignment alongside the existing CCall
# so lineage analysis sees the write. See fixes/phase1_memcpy_as_assignment/.
MEMORY_WRITE_INTRINSICS: Dict[str, Dict[str, object]] = {
    "memcpy":   {"target_arg": 0, "source_arg": 1},
    "memmove":  {"target_arg": 0, "source_arg": 1},
    "memset":   {"target_arg": 0, "source_arg": 1, "source_is_literal": True},
    "strcpy":   {"target_arg": 0, "source_arg": 1},
    "strncpy":  {"target_arg": 0, "source_arg": 1},
    "sprintf":  {"target_arg": 0, "source_args": "rest_from_2"},
    "snprintf": {"target_arg": 0, "source_args": "rest_from_3"},
    "strftime": {"target_arg": 0, "source_arg": 3},
}


class CFamilyParser:
    """Parse C/C++ source files using tree-sitter if available."""

    def __init__(self, language: str):
        self.language = language
        self.available = False
        self.parser = None
        self._numeric_literal_re = re.compile(
            r"^[+-]?(?:"
            r"0[xX][0-9A-Fa-f]+"
            r"|0[bB][01]+"
            r"|0[0-7]+"
            r"|(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?"
            r")(?:[uUlLfF]+)?$"
        )
        self._c_style_cast_prefix_re = re.compile(
            r"^\(\s*[A-Za-z_][A-Za-z0-9_:\s*&<>,]*\)\s*"
        )
        self._non_symbol_identifiers: Set[str] = {
            "if", "for", "while", "switch", "return",
            "sizeof", "alignof", "typeid",
            "static_cast", "reinterpret_cast", "const_cast", "dynamic_cast",
            "true", "false", "nullptr",
            "const", "volatile", "unsigned", "signed", "long", "short",
            "int", "char", "float", "double", "bool", "auto", "void",
        }
        self._init_parser()

    def _init_parser(self) -> None:
        # Try new per-language package API (tree-sitter >= 0.22, tree-sitter-c/cpp)
        try:
            from tree_sitter import Parser, Language
            lang_name = self.language.lower()
            if lang_name in ("cpp", "c++"):
                import tree_sitter_cpp as _ts_lang
            elif lang_name == "c":
                import tree_sitter_c as _ts_lang
            else:
                raise ImportError(f"No per-language package for: {lang_name}")
            lang_obj = Language(_ts_lang.language())
            try:
                self.parser = Parser(lang_obj)
            except TypeError:
                self.parser = Parser()
                if hasattr(self.parser, "set_language"):
                    self.parser.set_language(lang_obj)
                else:
                    self.parser.language = lang_obj
            self.available = True
            return
        except Exception:
            pass

        # Fallback: legacy tree_sitter_languages monolith (tree-sitter <= 0.21)
        try:
            from tree_sitter import Parser
            from tree_sitter_languages import get_language
            parser = Parser()
            language = get_language(self.language)
            if hasattr(parser, "set_language"):
                parser.set_language(language)
            else:
                parser.language = language
            self.parser = parser
            self.available = True
            return
        except Exception:
            pass

        try:
            from tree_sitter_languages import get_parser
            self.parser = get_parser(self.language)
            self.available = True
        except Exception:
            self.available = False

    def _normalize_space(self, text: Optional[str]) -> Optional[str]:
        if text is None:
            return None
        normalized = re.sub(r"\s+", " ", text).strip()
        return normalized or None

    def _is_non_symbol_identifier(self, identifier: Optional[str]) -> bool:
        token = (identifier or "").strip()
        if not token:
            return True
        return token in self._non_symbol_identifiers

    def _dedupe_list(self, values: List[str]) -> List[str]:
        seen: Set[str] = set()
        result: List[str] = []
        for value in values:
            token = (value or "").strip()
            if not token or token in seen:
                continue
            seen.add(token)
            result.append(token)
        return result

    def _classify_declaration_type(
        self,
        storage_tokens: List[str],
        qualifier_tokens: List[str],
        kind: str,
        scope: Optional[str],
        linkage: Optional[str] = None,
    ) -> str:
        lowered_storage = [token.lower() for token in storage_tokens]
        lowered_qualifiers = [token.lower() for token in qualifier_tokens]

        for token in ("typedef", "extern", "static", "thread_local", "auto", "register", "mutable"):
            if token in lowered_storage:
                return token

        if linkage:
            return "extern_linkage"
        if kind == "parameter":
            return "parameter"
        if kind == "member":
            return "member"
        if kind == "function":
            return "function_declaration"
        if "const" in lowered_qualifiers:
            return "const"
        if scope == "local_static":
            return "local_static"
        if scope in ("global", "static"):
            return "global"
        if scope == "extern":
            return "extern"
        return "local"

    def _extract_decl_base_type_from_statement(self, statement: str, name: Optional[str] = None) -> Optional[str]:
        if not statement:
            return None
        text = statement.strip().rstrip(";").strip()
        text = re.sub(r"\s*=\s*.*$", "", text).strip()
        if name:
            text = re.sub(rf"\b{re.escape(name)}\b.*$", "", text).strip()
        text = re.sub(r"\(\s*\*\s*[A-Za-z_]\w*\s*\)", "", text)
        text = re.sub(r"[*&\[\]()]", " ", text)
        text = self._normalize_space(text) or ""
        return text or None

    def _extract_preprocessor_definitions_from_text(
        self,
        text: str,
        file_path: Path,
    ) -> List[CMacroDefinition]:
        definitions: List[CMacroDefinition] = []
        lines = text.splitlines()
        index = 0
        while index < len(lines):
            raw = lines[index]
            stripped = raw.lstrip()
            if not stripped.startswith("#"):
                index += 1
                continue
            if not re.match(r"^#\s*define\b", stripped):
                index += 1
                continue

            logical = stripped
            end_index = index
            while logical.rstrip().endswith("\\") and end_index + 1 < len(lines):
                end_index += 1
                logical = logical.rstrip()[:-1] + "\n" + lines[end_index].lstrip()

            match = re.match(
                r"^#\s*define\s+([A-Za-z_]\w*)\s*(\(([^)]*)\))?\s*(.*)$",
                logical,
                flags=re.DOTALL,
            )
            if match:
                name = match.group(1)
                params_text = match.group(3) or ""
                params = [part.strip() for part in params_text.split(",") if part.strip()]
                body = (match.group(4) or "").strip() or None
                definitions.append(CMacroDefinition(
                    name=name,
                    line=index + 1,
                    body=body,
                    parameters=params,
                    kind="function" if params else "object",
                    file=str(file_path),
                ))
            index = end_index + 1

        return definitions

    def parse(self, file_path: Path, text: str,
              line_collector: Optional["CLineMetadataCollector"] = None) -> CTranslationUnit:
        unit = CTranslationUnit(file_path=file_path, language=self.language)
        unit.symbol_aliases = self._extract_symbol_aliases(text)
        unit.field_asm_aliases, unit.field_asm_alias_sources = (
            self._extract_field_asm_aliases(text, file_path)
        )
        # Pattern C fix: if this is a .cpp/.c file, scan for #include "cc*.hpp"
        # directives and merge field_asm_aliases from those headers so that
        # struct definitions annotated in cc*.hpp are visible to the stitcher
        # even when the headers are not separately processed.
        if Path(file_path).suffix.lower() in (".cpp", ".c", ".cxx", ".cc"):
            include_re = re.compile(
                r'#\s*include\s+[<"]([^>"]*\bcc[^>"]*\.h(?:pp)?)[>"]',
                re.IGNORECASE,
            )
            for m in include_re.finditer(text):
                header_name = m.group(1)
                # Try the header relative to the same directory as the .cpp file.
                for candidate in (
                    Path(file_path).parent / header_name,
                    Path(file_path).parent / Path(header_name).name,
                ):
                    if candidate.is_file():
                        try:
                            header_text = candidate.read_text(encoding="utf-8", errors="replace")
                            h_aliases, h_sources = self._extract_field_asm_aliases(
                                header_text, candidate
                            )
                            unit.field_asm_aliases.update(h_aliases)
                            unit.field_asm_alias_sources.update(h_sources)
                        except OSError:
                            pass
                        break
        unit.enum_values = self._extract_enum_values(text, file_path)
        unit.globals_used = self._extract_glob_globals(text)
        unit.macro_definitions = self._extract_preprocessor_definitions_from_text(text, file_path)
        text_bytes = text.encode("utf8")

        if not self.available or not self.parser:
            unit.parse_errors.append("tree_sitter_unavailable")
            self._parse_with_regex_fallback(unit, text)
            self._merge_regex_conditions(unit, text, file_path)
            return unit

        try:
            tree = self.parser.parse(bytes(text, "utf8"))
        except Exception:
            unit.parse_errors.append("tree_sitter_parse_error")
            self._parse_with_regex_fallback(unit, text)
            self._merge_regex_conditions(unit, text, file_path)
            return unit
        root = tree.root_node

        def node_text(node) -> str:
            return text_bytes[node.start_byte:node.end_byte].decode("utf8", errors="replace")

        def extract_identifier(node) -> Optional[str]:
            if node is None:
                return None
            if node.type == "identifier":
                return node_text(node)
            if node.type == "field_identifier":
                return node_text(node)
            if node.type in ("qualified_identifier", "namespace_identifier"):
                return node_text(node)
            # D05: destructor_name node — preserve "~" prefix (e.g. "~BetaObj")
            # so destructor calls like obj.~BetaObj() keep the tilde in func_name.
            if node.type == "destructor_name":
                return node_text(node)

            # Try to find an identifier child
            for child in node.children:
                ident = extract_identifier(child)
                if ident:
                    return ident

            return None

        def extract_identifiers(node) -> List[str]:
            if node is None:
                return []
            identifiers = []
            if node.type in ("identifier", "field_identifier"):
                identifiers.append(node_text(node))
            for child in node.children:
                identifiers.extend(extract_identifiers(child))
            return identifiers

        def extract_string_literals(node) -> List[str]:
            if node is None:
                return []
            values: List[str] = []
            if node.type in ("string_literal", "concatenated_string"):
                text_value = node_text(node).strip()
                if text_value:
                    values.append(text_value)
            for child in node.children:
                values.extend(extract_string_literals(child))
            return values

        def extract_parameter_names(function_declarator) -> List[str]:
            if function_declarator is None:
                return []
            param_list = find_first(function_declarator, ("parameter_list",))
            if param_list is None:
                return []

            params: List[str] = []
            for child in param_list.children:
                if child.type != "parameter_declaration":
                    continue
                declarator = child.child_by_field_name("declarator")
                name = extract_identifier(declarator) if declarator else extract_identifier(child)
                if name and name != "void":
                    params.append(name)
            return dedupe(params)

        def extract_parameter_declarations(function_declarator, current_function: Optional[str], linkage: Optional[str]) -> List[CDeclaration]:
            if function_declarator is None:
                return []
            param_list = find_first(function_declarator, ("parameter_list",))
            if param_list is None:
                return []

            declarations: List[CDeclaration] = []
            for child in param_list.children:
                if child.type != "parameter_declaration":
                    continue
                declarator = child.child_by_field_name("declarator")
                name = extract_identifier(declarator) if declarator else extract_identifier(child)
                if not name or name == "void":
                    continue

                type_node = child.child_by_field_name("type")
                type_text = normalize_text(node_text(type_node)) if type_node else None
                storage_tokens: List[str] = []
                qualifier_tokens: List[str] = []
                for param_child in child.children:
                    if param_child.type == "storage_class_specifier":
                        token = normalize_text(node_text(param_child))
                        if token:
                            storage_tokens.append(token)
                    elif param_child.type == "type_qualifier":
                        token = normalize_text(node_text(param_child))
                        if token:
                            qualifier_tokens.append(token)
                declaration_type = self._classify_declaration_type(
                    storage_tokens=storage_tokens,
                    qualifier_tokens=qualifier_tokens,
                    kind="parameter",
                    scope="local",
                    linkage=linkage,
                )
                declarations.append(CDeclaration(
                    name=name,
                    kind="parameter",
                    line=child.start_point[0] + 1,
                    function=current_function,
                    scope="local",
                    storage_class=storage_tokens[0] if storage_tokens else None,
                    declaration_type=declaration_type,
                    data_type=type_text,
                    expression=node_text(child),
                    metadata={
                        "qualifiers": dedupe(qualifier_tokens),
                        "storage_tokens": dedupe(storage_tokens),
                        "linkage": linkage,
                    },
                ))

            return declarations

        def extract_pointer_terms(node) -> List[str]:
            if node is None:
                return []
            terms = []
            if node.type == "pointer_expression":
                text_value = node_text(node).strip()
                if text_value.startswith("*"):
                    terms.append(text_value.replace(" ", ""))
            for child in node.children:
                terms.extend(extract_pointer_terms(child))
            return terms

        def dedupe(values: List[str]) -> List[str]:
            seen = set()
            result = []
            for value in values:
                if value and value not in seen:
                    seen.add(value)
                    result.append(value)
            return result

        def normalize_text(value: Optional[str]) -> Optional[str]:
            if value is None:
                return None
            normalized = re.sub(r"\s+", " ", value).strip()
            return normalized or None

        def declaration_specifiers(
            declaration_node,
            linkage: Optional[str] = None,
            kind: str = "variable",
            scope: Optional[str] = None,
        ) -> Dict[str, object]:
            storage_tokens: List[str] = []
            qualifier_tokens: List[str] = []
            type_parts: List[str] = []
            for child in declaration_node.children:
                if child.type in (";", ",", "init_declarator", "identifier", "field_identifier"):
                    continue
                if child.type in ("function_declarator", "declarator", "pointer_declarator", "array_declarator", "reference_declarator"):
                    continue
                text_value = normalize_text(node_text(child))
                if not text_value:
                    continue
                if child.type == "storage_class_specifier":
                    storage_tokens.append(text_value)
                    continue
                if child.type == "type_qualifier":
                    qualifier_tokens.append(text_value)
                    continue
                if child.type in ("attribute_specifier", "ms_declspec_modifier"):
                    continue
                type_parts.append(text_value)

            data_type = normalize_text(" ".join(type_parts)) or None
            declaration_type = self._classify_declaration_type(
                storage_tokens=storage_tokens,
                qualifier_tokens=qualifier_tokens,
                kind=kind,
                scope=scope,
                linkage=linkage,
            )
            storage_class = storage_tokens[0] if storage_tokens else ("extern" if linkage else None)
            return {
                "data_type": data_type,
                "storage_class": storage_class,
                "declaration_type": declaration_type,
                "qualifiers": dedupe(qualifier_tokens),
                "storage_tokens": dedupe(storage_tokens),
            }

        def declared_identifiers_from_declaration(declaration_node) -> List[str]:
            names: List[str] = []
            for child in declaration_node.children:
                if child.type in (
                    "primitive_type",
                    "type_identifier",
                    "sized_type_specifier",
                    "type_qualifier",
                    "storage_class_specifier",
                    "struct_specifier",
                    "union_specifier",
                    "enum_specifier",
                    "attribute_specifier",
                    "qualified_identifier",
                    "namespace_identifier",
                    ";",
                    ",",
                ):
                    continue
                if child.type == "init_declarator":
                    declarator = child.child_by_field_name("declarator")
                    name = extract_identifier(declarator) if declarator else extract_identifier(child)
                    if name:
                        names.append(name)
                    continue
                if child.type == "function_declarator":
                    continue
                name = extract_identifier(child)
                if name:
                    names.append(name)
            return dedupe(names)

        def extract_type_alias(node) -> Optional[Tuple[str, str]]:
            if node.type == "type_definition":
                alias_name = None
                target_parts: List[str] = []
                for child in node.children:
                    if child.type == "type_identifier":
                        alias_name = normalize_text(node_text(child))
                        continue
                    if child.type in ("typedef", ";"):
                        continue
                    text_value = normalize_text(node_text(child))
                    if text_value:
                        target_parts.append(text_value)
                target = normalize_text(" ".join(target_parts))
                if alias_name and target:
                    return alias_name, target
            if node.type == "alias_declaration":
                declaration_text = normalize_text(node_text(node)) or ""
                alias_match = re.match(r"^using\s+([A-Za-z_]\w*)\s*=\s*(.+?)\s*;?$", declaration_text)
                if alias_match:
                    alias_name = normalize_text(alias_match.group(1))
                    target = normalize_text(alias_match.group(2))
                    if alias_name and target:
                        return alias_name, target

                alias_node = node.child_by_field_name("name")
                value_node = node.child_by_field_name("value")
                if alias_node is None:
                    alias_node = find_first(node, ("type_identifier",))
                if value_node is None:
                    for child in node.children:
                        if child.type in ("type_descriptor", "type_identifier", "qualified_identifier") and child is not alias_node:
                            value_node = child
                            break
                alias_name = normalize_text(node_text(alias_node)) if alias_node else None
                target = normalize_text(node_text(value_node)) if value_node else None
                if alias_name and target:
                    return alias_name, target
            return None

        def extract_access_path(node) -> Optional[str]:
            if node is None:
                return None
            if node.type == "field_expression":
                argument = node.child_by_field_name("argument")
                field = node.child_by_field_name("field")
                base = extract_access_path(argument) or extract_identifier(argument)
                field_name = extract_identifier(field)
                operator = "->" if "->" in node_text(node) else "."
                if base and field_name:
                    return f"{base}{operator}{field_name}"
            if node.type == "subscript_expression":
                argument = node.child_by_field_name("argument")
                index = node.child_by_field_name("index")
                base = extract_access_path(argument) or extract_identifier(argument)
                index_text = node_text(index).strip() if index else ""
                if base:
                    return f"{base}[{index_text}]"
            if node.type in ("identifier", "qualified_identifier", "field_identifier"):
                return node_text(node)
            return extract_identifier(node)

        def find_first(node, types: Tuple[str, ...]):
            if node is None:
                return None
            if node.type in types:
                return node
            for child in node.children:
                found = find_first(child, types)
                if found is not None:
                    return found
            return None

        def return_value_node(return_node):
            """Get return expression node across C/C++ grammar variants."""
            if return_node is None:
                return None
            value = return_node.child_by_field_name("argument")
            if value is not None:
                return value
            value = return_node.child_by_field_name("value")
            if value is not None:
                return value
            for child in return_node.children:
                text_value = node_text(child).strip()
                if text_value == "return":
                    continue
                if getattr(child, "is_named", False):
                    return child
            return None

        def extract_callable_name(func_node) -> Tuple[Optional[str], bool]:
            if func_node is None:
                return None, False
            if func_node.type in ("identifier", "qualified_identifier"):
                return node_text(func_node), False
            full = node_text(func_node).strip()
            if "<" in full and ">" in full and "(" not in full:
                return full, False
            if func_node.type == "field_expression":
                name = extract_access_path(func_node)
                return name, "->" in name if name else True
            if func_node.type in ("pointer_expression", "parenthesized_expression"):
                full_inner = node_text(func_node).strip().strip("()")
                # G05: member-pointer dereference — (obj.*mfp) or (ptr->*mfp)
                _mpe = re.match(
                    r'^([A-Za-z_][A-Za-z0-9_.\->]*?)\s*(->?\*)\s*([A-Za-z_][A-Za-z0-9_]*)$',
                    full_inner
                )
                if _mpe:
                    _sep = "->*" if "->" in _mpe.group(2) else ".*"
                    return f"{_mpe.group(1)}{_sep}{_mpe.group(3)}", True
                ident = extract_identifier(func_node)
                if ident:
                    return ident, True
            ident = extract_identifier(func_node)
            if ident:
                return ident, func_node.type != "identifier"
            return full, True

        def extract_call_arguments(call_node) -> Tuple[List[str], List[str]]:
            args: List[str] = []
            address_of_args: List[str] = []
            if call_node is None:
                return args, address_of_args

            args_node = call_node.child_by_field_name("arguments")
            if args_node is None:
                return args, address_of_args

            for child in args_node.children:
                if not getattr(child, "is_named", False):
                    continue
                arg_text = node_text(child).strip()
                if not arg_text:
                    continue
                candidate = ""
                if child.type == "call_expression":
                    nested_args = child.child_by_field_name("arguments")
                    if nested_args is not None:
                        for nested in nested_args.children:
                            if not getattr(nested, "is_named", False):
                                continue
                            nested_candidate = (extract_access_path(nested) or extract_identifier(nested) or "").strip()
                            if nested_candidate:
                                candidate = nested_candidate
                                break
                if not candidate:
                    access = extract_access_path(child)
                    ident = extract_identifier(child)
                    candidate = (access or ident or arg_text).strip()
                args.append(candidate)

                normalized = arg_text.lstrip()
                if normalized.startswith("&"):
                    base = normalized[1:].strip()
                    if base.startswith("(") and base.endswith(")"):
                        base = base[1:-1].strip()
                    if base:
                        address_of_args.append(base)

            return args, dedupe(address_of_args)

        def extract_template_suffix(template_node) -> str:
            if template_node is None:
                return ""
            params = template_node.child_by_field_name("parameters")
            if params is None:
                return "<template>"
            content = node_text(params).strip()
            if content.startswith("<") and content.endswith(">"):
                return content
            return "<template>"

        def with_template(name: Optional[str], template_suffix: Optional[str]) -> Optional[str]:
            if not name:
                return name
            if template_suffix and "<" not in name:
                return f"{name}{template_suffix}"
            return name

        def resolve_alias(name: Optional[str]) -> Optional[str]:
            if not name:
                return name
            if name in unit.symbol_aliases:
                return unit.symbol_aliases[name]
            tail = name.split("::")[-1]
            if tail in unit.symbol_aliases:
                return unit.symbol_aliases[tail]
            return name

        def alias_for(name: Optional[str]) -> Optional[str]:
            if not name:
                return None
            if name in unit.symbol_aliases:
                return unit.symbol_aliases[name]
            tail = name.split("::")[-1]
            if tail in unit.symbol_aliases:
                return unit.symbol_aliases[tail]
            return None

        def infer_scope_storage(declaration_node, current_function: Optional[str]) -> Tuple[str, Optional[str]]:
            storage = None
            for child in declaration_node.children:
                if child.type == "storage_class_specifier":
                    value = node_text(child).strip()
                    if value in ("static", "extern"):
                        storage = value
                        break
            if current_function:
                if storage == "static":
                    return "local_static", storage
                return "local", storage
            if storage == "static":
                return "static", storage
            if storage == "extern":
                return "extern", storage
            return "global", storage

        def determine_target(left_node) -> Tuple[Optional[str], str, int, Optional[str], Optional[str]]:
            if left_node is None:
                return None, "variable", 0, None, None

            left_text = node_text(left_node).strip()
            pointer_depth = 0
            while left_text.startswith("*"):
                pointer_depth += 1
                left_text = left_text[1:].strip()

            if left_node.type == "subscript_expression":
                return node_text(left_node).strip(), "array_element", pointer_depth, extract_access_path(left_node.child_by_field_name("argument")), None
            if left_node.type == "field_expression":
                access = extract_access_path(left_node) or node_text(left_node).strip()
                argument = left_node.child_by_field_name("argument")
                field = left_node.child_by_field_name("field")
                return access, "struct_field", pointer_depth, extract_access_path(argument) or extract_identifier(argument), extract_identifier(field)
            if left_node.type == "pointer_expression" or node_text(left_node).strip().startswith("*"):
                target_name = extract_access_path(left_node) or extract_identifier(left_node) or node_text(left_node).strip()
                return target_name, "memory", max(1, pointer_depth), None, None
            return extract_identifier(left_node) or node_text(left_node).strip(), "variable", pointer_depth, None, None

        # -----------------------------------------------------------------------
        # GAP-B/F: ECB arithmetic constant-propagation
        # -----------------------------------------------------------------------
        # Per-function map of simple integer constants seen so far in the parse
        # walk.  Populated from both init_declarator initializers and bare
        # assignment_expression RHS literals.  Keyed as {func_name: {var: int}}.
        _ecb_const_map: Dict[Optional[str], Dict[str, int]] = {}

        # Matches: *(T*)([optional inner cast] [&]ECB_EXPR + OFFSET_TOKEN)
        # Group 1 = base ECB expression, Group 2 = offset token (var or literal).
        _ECB_ARITH_RE = re.compile(
            r'^\*\s*\([^)]+\*\s*\)'    # *(T*)
            r'\s*\(\s*'                 # (
            r'(?:\([^)]+\*\s*\)\s*)?'  # optional inner cast, e.g. (char*)
            r'&?\s*'                    # optional address-of
            r'([^+]+?)'                 # base ECB expression — no '+' allowed
            r'\s*\+\s*'                 # +
            r'(\w+)'                    # offset token (variable name or literal)
            r'\s*\)',                   # )
            re.DOTALL,
        )
        # Lightweight guard: base must reference a known ECB region to avoid
        # rewriting unrelated pointer arithmetic.
        _ECB_BASE_GUARD = re.compile(
            r'(?:ecbptr|ce1[a-z0-9]|ebw[0-9a-f]|ebx[0-9a-f]|ebsw|ebr[0-9])',
            re.IGNORECASE,
        )

        def _try_int_literal(value_node) -> Optional[int]:
            """Return the integer value of a simple numeric literal node, else None."""
            if value_node is None:
                return None
            vtype = getattr(value_node, "type", "")
            vtext = node_text(value_node).strip()
            # Handle unary minus: -4
            if vtype == "unary_expression" and vtext.startswith("-"):
                inner = vtext[1:].strip().rstrip("uUlLfF")
                try:
                    return -int(inner, 0)
                except (ValueError, TypeError):
                    return None
            # Direct integer / number literals.
            if vtype in ("number_literal", "integer_literal") or re.match(
                r'^(?:0[xX][0-9A-Fa-f]+|0[bB][01]+|\d+)[uUlLfF]*$', vtext
            ):
                try:
                    return int(vtext.rstrip("uUlLfF"), 0)
                except (ValueError, TypeError):
                    return None
            return None

        def _resolve_ecb_arith_cast(
            raw_lhs: str,
            func: Optional[str],
        ) -> Optional[Tuple[str, str]]:
            """Rewrite *(T*)(&ecbptr()->FIELD + N) → ("ecbptr()->FIELD[N]", "array_element").

            When the offset token is a variable, looks it up in ``_ecb_const_map``
            for the current function.  Returns None when the pattern does not
            match, the base is not an ECB expression, or the offset is unknown.
            """
            m = _ECB_ARITH_RE.match(raw_lhs)
            if not m:
                return None
            base_expr = m.group(1).strip()
            offset_tok = m.group(2).strip()
            # Guard: base expression must be ECB-related.
            if not _ECB_BASE_GUARD.search(base_expr):
                return None
            # Resolve offset to an integer constant.
            try:
                offset_int: int = int(offset_tok, 0)
            except (ValueError, TypeError):
                offset_int = (_ecb_const_map.get(func) or {}).get(offset_tok)  # type: ignore[assignment]
                if offset_int is None:
                    return None
            return f"{base_expr}[{offset_int}]", "array_element"

        # -----------------------------------------------------------------------
        # GAP-G: per-function variable→class type map for virtual dispatch
        # -----------------------------------------------------------------------
        # Tracks declared types of pointer/reference variables so that arrow
        # calls like ``obj->method()`` can be rewritten to the FQN
        # ``DeclaredClass::method`` that CHA needs for cross-TU expansion.
        # Only simple, statically visible declarations are tracked; factory
        # returns with ``auto`` or unknown types remain unresolved (inherent
        # static-analysis limit).
        _var_type_map: Dict[Optional[str], Dict[str, str]] = {}

        # Known C++ primitive type stems — not class names.
        _CPP_PRIMITIVES = frozenset({
            "int", "long", "short", "char", "unsigned", "signed",
            "float", "double", "void", "bool", "size_t", "auto",
            "uint8_t", "uint16_t", "uint32_t", "uint64_t",
            "int8_t",  "int16_t",  "int32_t",  "int64_t",
            "uintptr_t", "intptr_t", "ptrdiff_t", "nullptr_t",
        })

        def _extract_class_from_type(type_text: Optional[str]) -> Optional[str]:
            """Return bare class name from a C++ type string, or None for primitives.

            Strips ``const``, ``volatile``, ``struct``, ``class``, pointer (``*``)
            and reference (``&``) markers.  Returns None for primitive types, empty
            names, template instantiations, and multi-word types like "unsigned int".
            """
            if not type_text:
                return None
            name = type_text.strip()
            for kw in ("const ", "volatile ", "struct ", "class ", "typename "):
                while name.startswith(kw):
                    name = name[len(kw):]
                while name.endswith(" " + kw.strip()):
                    name = name[: -len(kw)].rstrip()
            name = name.rstrip("*& \t").strip()
            if not name or " " in name:
                return None
            # Reject template instantiations
            if "<" in name or ">" in name:
                return None
            # Must be a valid C++ identifier (namespace-qualified allowed)
            if not re.match(r'^[A-Za-z_][A-Za-z0-9_:]*$', name):
                return None
            # Reject known primitives (check just the last component)
            if name.split("::")[-1].lower() in _CPP_PRIMITIVES:
                return None
            return name

        # Stack of enclosing condition expressions, pushed on entry to
        # if/while/for/switch nodes and popped after children are processed.
        # Used to populate CAssignment.conditional_context.
        _condition_stack: List[str] = []

        # Inverted conditions from early-return guards (`if (cond) return;`).
        # These are NOT enclosing conditions but prerequisites: code that follows
        # an early-return guard is only reached when NOT(cond).  They are appended
        # to _condition_stack when the early-return if completes, and removed when
        # the enclosing compound_statement finishes.
        # Each entry: (inverted_condition_text, depth_at_push)
        _guard_conditions: List[str] = []
        _compound_depth: List[int] = []   # tracks guard count per compound_statement

        # Stack of case-value lists for nested switch statements.
        # Each entry is a list of case values seen so far in that switch,
        # so that when we enter a default: block we can emit NOT IN {val1, val2, ...}.
        _switch_cases_stack: List[List[str]] = []

        def walk(
            node,
            current_function: Optional[str],
            current_template_suffix: Optional[str] = None,
            current_linkage: Optional[str] = None,
            current_type: Optional[str] = None,
        ):
            _pushed_condition = False
            _else_swapped = False
            _else_is_elif = False
            _else_saved: Optional[str] = None
            if node.type == "template_declaration":
                current_template_suffix = extract_template_suffix(node)

            if node.type in ("struct_specifier", "class_specifier", "union_specifier"):
                type_name_node = node.child_by_field_name("name")
                if type_name_node is None:
                    for child in node.children:
                        if child.type == "type_identifier":
                            type_name_node = child
                            break
                type_name = normalize_text(node_text(type_name_node)) if type_name_node else None
                if type_name:
                    current_type = type_name
                    # Mark unions so field_declaration records their members for
                    # may_alias (writing one member may change reads of any other).
                    if node.type == "union_specifier":
                        unit.union_members.setdefault(type_name, [])
                    # Fix 4: Extract base classes from base_class_clause for CHA.
                    # tree-sitter-cpp >= 0.23.4 exposes base_class_clause as a
                    # positional child rather than a named field; fall back to
                    # child-by-type so both old and new grammars are handled.
                    base_clause = node.child_by_field_name("base_class_clause") or next(
                        (c for c in node.children if c.type == "base_class_clause"), None
                    )
                    if base_clause:
                        for base_child in base_clause.named_children:
                            base_text = node_text(base_child).strip()
                            # Strip access specifier prefixes ("public", "private", "protected", "virtual")
                            for prefix in ("public ", "private ", "protected ", "virtual "):
                                while base_text.startswith(prefix):
                                    base_text = base_text[len(prefix):]
                            base_text = base_text.strip()
                            if base_text and base_text not in ("public", "private", "protected", "virtual"):
                                unit.class_bases.setdefault(type_name, []).append(base_text)

            if node.type in ("type_definition", "alias_declaration"):
                alias = extract_type_alias(node)
                if alias:
                    alias_name, target = alias
                    unit.type_aliases[alias_name] = target

            # Named enums declared at file / namespace / function scope expose
            # their enumerators as `member` declarations (the C++ analog of the
            # struct-nested `enum Type { Add, Delete }` case, which is already
            # captured via the field_declaration path). We gate on
            # ``current_type is None`` so we don't double-emit enumerators that
            # the field_declaration handler already produces for struct/class
            # member enums.
            if node.type == "enum_specifier" and current_type is None:
                enum_name_node = node.child_by_field_name("name") or next(
                    (c for c in node.children if c.type == "type_identifier"), None
                )
                enum_name = normalize_text(node_text(enum_name_node)) if enum_name_node else None
                enum_body = find_first(node, ("enumerator_list",))
                if enum_name and enum_body is not None:  # skip anonymous enums
                    for enumerator in enum_body.children:
                        if enumerator.type != "enumerator":
                            continue
                        ident_node = enumerator.child_by_field_name("name") or next(
                            (c for c in enumerator.children if c.type == "identifier"), None
                        )
                        member_name = node_text(ident_node) if ident_node else None
                        if not member_name:
                            continue
                        unit.declarations.append(CDeclaration(
                            name=member_name,
                            kind="member",
                            line=enumerator.start_point[0] + 1,
                            function=current_function,
                            scope=enum_name,
                            storage_class="enum",
                            declaration_type="const",
                            data_type=f"enum {enum_name}",
                            expression=node_text(enumerator),
                            metadata={
                                "enclosing_type": enum_name,
                                "linkage": current_linkage,
                                "introduced_via": "enumerator",
                            },
                        ))

            if node.type == "linkage_specification":
                linkage_literal = find_first(node, ("string_literal",))
                linkage_text = normalize_text(node_text(linkage_literal)) if linkage_literal else None
                if linkage_text:
                    current_linkage = linkage_text.strip('"')

            # Hook: Track conditionals (if/while/for/switch/do-while/range-for)
            if node.type in ("if_statement", "while_statement", "for_statement",
                             "switch_statement", "do_statement", "for_range_loop"):
                if line_collector:
                    line_collector.record_line(str(file_path), node.start_point[0] + 1)
                    condition_node = node.child_by_field_name("condition")
                    condition_text = node_text(condition_node) if condition_node else ""
                    condition_type = node.type.replace("_statement", "").replace("_loop", "")
                    line_collector.push_condition(condition_text, condition_type)

                # Phase 5b — capture every comparison expression inside the
                # condition so its operands become lineage use-edges.
                cond_node = node.child_by_field_name("condition")
                # for_range_loop has no "condition" field; use "right" (the container).
                if cond_node is None and node.type == "for_range_loop":
                    cond_node = node.child_by_field_name("right")
                self._collect_comparisons_into_unit(
                    unit, cond_node, file_path, current_function,
                    node.start_point[0] + 1,
                )

                # Track enclosing condition for CAssignment.conditional_context.
                _cond_text = (node_text(cond_node) or "").strip() if cond_node else ""
                if _cond_text:
                    _condition_stack.append(_cond_text)
                    _pushed_condition = True
                # Maintain case-value accumulator for this switch level.
                if node.type == "switch_statement":
                    _switch_cases_stack.append([])

                # Range-based for: emit CAssignment(target=loop_var, sources=[container]).
                if node.type == "for_range_loop":
                    _rfr_decl = node.child_by_field_name("declarator")
                    _rfr_right = node.child_by_field_name("right")
                    _rfr_var = extract_identifier(_rfr_decl) if _rfr_decl else None
                    if _rfr_var and _rfr_right:
                        _rfr_sources = dedupe(extract_identifiers(_rfr_right))
                        _rfr_access = extract_access_path(_rfr_right)
                        if _rfr_access and _rfr_access not in _rfr_sources:
                            _rfr_sources.append(_rfr_access)
                        unit.assignments.append(CAssignment(
                            target=_rfr_var,
                            target_kind="variable",
                            sources=_rfr_sources,
                            line=node.start_point[0] + 1,
                            expression=node_text(node).split("{")[0].strip() if "{" in (node_text(node) or "") else node_text(node),
                            function=current_function,
                            scope="local",
                            conditional_context=list(_condition_stack) if _condition_stack else None,
                        ))

            # Track compound_statement depth for guard condition scoping.
            if node.type == "compound_statement":
                _compound_depth.append(len(_guard_conditions))

            # Phase 5b — capture `case VALUE:` labels as equality-style
            # conditions. The implicit comparison is against the enclosing
            # switch expression but we only need the VALUE side for enum
            # resolution.
            if node.type == "case_statement":
                self._record_case_condition(
                    unit, node, file_path, current_function,
                )
                # Also push a specific case condition onto _condition_stack so
                # assignments/calls inside this case block inherit it.
                # The enclosing switch_statement already pushed its discriminant
                # as _condition_stack[-1].  We form: "discriminant == case_value".
                if _condition_stack:
                    case_value_node = node.child_by_field_name("value")
                    _case_val = node_text(case_value_node).strip() if case_value_node else ""
                    _sw_raw = _condition_stack[-1].strip()
                    _sw_expr = _sw_raw[1:-1].strip() if (_sw_raw.startswith("(") and _sw_raw.endswith(")")) else _sw_raw
                    if _case_val:
                        # Named case: accumulate the value and push the equality condition.
                        if _switch_cases_stack:
                            _switch_cases_stack[-1].append(_case_val)
                        _cond_text = f"({_sw_expr} == {_case_val})"
                        _condition_stack.append(_cond_text)
                        _pushed_condition = True
                    else:
                        # Default case: push NOT IN {val1, val2, ...} if we have seen cases.
                        _collected = _switch_cases_stack[-1] if _switch_cases_stack else []
                        if _collected:
                            _vals_str = ", ".join(_collected)
                            _cond_text = f"({_sw_expr} NOT IN {{{_vals_str}}})"
                            _condition_stack.append(_cond_text)
                            _pushed_condition = True

            # Track explicit else headers (e.g., "} else {") as control lines.
            if node.type == "else_clause":
                if line_collector:
                    line_collector.record_line(str(file_path), node.start_point[0] + 1)
                # Polarity fix: assignments in an else/else-if branch must NOT
                # carry the enclosing if-condition unchanged (polarity flip).
                #
                # plain else { setter }:
                #   replace the parent if's condition with NOT(cond) — the
                #   setter fires exactly when cond is false.
                #
                # else if(cond_B) { setter }:
                #   the parent's cond_A and cond_B are mutually exclusive.
                #   Keeping NOT(cond_A) alongside cond_B is redundant.  Instead
                #   we POP cond_A entirely — the inner if_statement will push
                #   cond_B, giving a clean chain with no redundant NOT.
                #   On exit we restore cond_A so the enclosing if_statement's
                #   own pop still finds it.
                _parent = node.parent
                if _parent is not None and _parent.type == "if_statement":
                    _pc_node = _parent.child_by_field_name("condition")
                    _pc_text = (node_text(_pc_node) or "").strip() if _pc_node else ""
                    if _pc_text and _condition_stack and _condition_stack[-1] == _pc_text:
                        _first_named = next(
                            (c for c in node.named_children if c.type != "comment"),
                            None,
                        )
                        _else_is_elif = (
                            _first_named is not None
                            and _first_named.type == "if_statement"
                        )
                        _else_saved = _condition_stack[-1]
                        if _else_is_elif:
                            _condition_stack.pop()   # inner if will push cond_B
                        else:
                            # De-negate if already a NOT(...) guard to avoid
                            # double-negation; otherwise prepend NOT.
                            if _pc_text.startswith("NOT(") and _pc_text.endswith(")"):
                                _negated = _pc_text[3:]  # strips "NOT", keeps "(..."
                            else:
                                _negated = f"NOT{_pc_text}"
                            _condition_stack[-1] = _negated
                        _else_swapped = True

            if node.type == "function_definition":
                func_name = None
                func_declarator = None
                for child in node.children:
                    # When the return type is a pointer/reference (e.g.
                    # `static Foo* bar(...)`), tree-sitter wraps the
                    # function_declarator inside a pointer_declarator /
                    # reference_declarator. Descend to find it so the function
                    # is registered and its parameters/locals are scoped.
                    if child.type in (
                        "function_declarator", "declarator", "identifier",
                        "pointer_declarator", "reference_declarator",
                    ):
                        candidate = find_first(child, ("function_declarator",)) or child
                        func_declarator = candidate
                        func_name = extract_identifier(candidate)
                        if func_name:
                            break

                if func_name:
                    func_name = with_template(func_name, current_template_suffix)
                    unit.functions.append(CFunction(
                        name=func_name,
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1
                    ))
                    alias = resolve_alias(func_name)
                    if alias and alias != func_name:
                        unit.function_aliases[func_name] = alias
                    current_function = func_name

                    # Hook: Enter function in line collector
                    if line_collector:
                        line_collector.enter_function(func_name, node.start_point[0] + 1, node.end_point[0] + 1)
                        body_node = node.child_by_field_name("body")
                        header_end_line = (
                            body_node.start_point[0] + 1
                            if body_node is not None
                            else node.start_point[0] + 1
                        )
                        line_collector.record_span(
                            str(file_path),
                            node.start_point[0] + 1,
                            header_end_line,
                        )

                    for param_decl in extract_parameter_declarations(func_declarator, current_function, current_linkage):
                        unit.declarations.append(param_decl)
                        # GAP-G: record parameter type for virtual dispatch resolution.
                        _cls = _extract_class_from_type(param_decl.data_type)
                        if _cls and param_decl.name:
                            _var_type_map.setdefault(current_function, {})[param_decl.name] = _cls

            if node.type == "call_expression":
                func_node = node.child_by_field_name("function")
                func_name, call_is_indirect = extract_callable_name(func_node)
                # GAP-G: rewrite "obj->method" to "ClassName::method" when the
                # declared type of obj is statically visible, giving CHA the FQN
                # it needs for cross-TU virtual-dispatch expansion.
                if func_name and "->" in func_name and current_function:
                    _arrow_parts = func_name.split("->", 1)
                    _receiver = _arrow_parts[0].strip()
                    _method = _arrow_parts[1].strip()
                    if (
                        _method
                        and "::" not in _receiver
                        and re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', _receiver)
                    ):
                        _resolved_cls = _var_type_map.get(current_function, {}).get(_receiver)
                        if _resolved_cls:
                            func_name = f"{_resolved_cls}::{_method}"
                            call_is_indirect = True  # virtual dispatch
                if func_name:
                    func_name = with_template(func_name, current_template_suffix)
                    asm_target = alias_for(func_name)
                    args, address_of_args = extract_call_arguments(node)
                    unit.calls.append(CCall(
                        function=func_name,
                        line=node.start_point[0] + 1,
                        enclosing_function=current_function,
                        asm_target=asm_target,
                        call_is_indirect=call_is_indirect,
                        args=args,
                        address_of_args=address_of_args,
                        conditional_context=list(_condition_stack) if _condition_stack else None,
                    ))

                    # D05: explicit destructor call — obj.~ClassName() → dep on ClassName's TU
                    # Reuses __new_ prefix; analyzer resolves ClassName → file stem.
                    if current_function and func_name:
                        _dtor_m = re.search(r'~([A-Za-z_][A-Za-z0-9_]*)$', func_name)
                        if _dtor_m:
                            unit.calls.append(CCall(
                                function=f"__new_{_dtor_m.group(1)}",
                                line=node.start_point[0] + 1,
                                enclosing_function=current_function,
                                call_is_indirect=False,
                                conditional_context=list(_condition_stack) if _condition_stack else None,
                            ))

                    # Hook: Record line for call expression
                    if line_collector:
                        line_collector.record_span(
                            str(file_path),
                            node.start_point[0] + 1,
                            node.end_point[0] + 1,
                        )

                    # Phase 1: memcpy/memset/strcpy/... also write to arg[0].
                    # Synthesize a CAssignment so lineage records the memory
                    # write; CCall above is preserved.
                    intrinsic_spec = MEMORY_WRITE_INTRINSICS.get(func_name)
                    if intrinsic_spec is not None:
                        args_container = node.child_by_field_name("arguments")
                        intrinsic_arg_nodes = (
                            [c for c in args_container.children if getattr(c, "is_named", False)]
                            if args_container is not None
                            else []
                        )
                        target_idx = int(intrinsic_spec["target_arg"])  # type: ignore[arg-type]
                        if len(intrinsic_arg_nodes) > target_idx:
                            target_node = intrinsic_arg_nodes[target_idx]
                            # Strip leading '&' so memcpy(&s->f, ...) analyses
                            # as s->f (the written-through struct field).
                            if (
                                target_node.type == "pointer_expression"
                                and node_text(target_node).lstrip().startswith("&")
                            ):
                                inner = target_node.child_by_field_name("argument")
                                if inner is not None:
                                    target_node = inner
                            (
                                intrinsic_target,
                                intrinsic_target_kind,
                                intrinsic_pointer_depth,
                                intrinsic_target_base,
                                intrinsic_target_field,
                            ) = determine_target(target_node)

                            intrinsic_sources: List[str] = []
                            if intrinsic_spec.get("source_is_literal"):
                                lit_idx = int(intrinsic_spec["source_arg"])  # type: ignore[arg-type]
                                if len(intrinsic_arg_nodes) > lit_idx:
                                    lit_text = node_text(intrinsic_arg_nodes[lit_idx]).strip()
                                    if lit_text:
                                        intrinsic_sources.append(lit_text)
                            elif "source_arg" in intrinsic_spec:
                                si = int(intrinsic_spec["source_arg"])  # type: ignore[arg-type]
                                if len(intrinsic_arg_nodes) > si:
                                    src_node = intrinsic_arg_nodes[si]
                                    intrinsic_sources.extend(extract_identifiers(src_node))
                                    intrinsic_sources.extend(extract_string_literals(src_node))
                                    access = extract_access_path(src_node)
                                    if access and access not in intrinsic_sources:
                                        intrinsic_sources.append(access)
                            elif "source_args" in intrinsic_spec:
                                directive = intrinsic_spec["source_args"]
                                if directive == "rest_from_2":
                                    start = 2
                                elif directive == "rest_from_3":
                                    start = 3
                                else:
                                    start = 1
                                for src_node in intrinsic_arg_nodes[start:]:
                                    intrinsic_sources.extend(extract_identifiers(src_node))
                                    intrinsic_sources.extend(extract_string_literals(src_node))
                                    access = extract_access_path(src_node)
                                    if access and access not in intrinsic_sources:
                                        intrinsic_sources.append(access)

                            intrinsic_sources = dedupe(intrinsic_sources)

                            if intrinsic_target:
                                unit.assignments.append(CAssignment(
                                    target=intrinsic_target,
                                    target_kind=intrinsic_target_kind,
                                    sources=intrinsic_sources,
                                    line=node.start_point[0] + 1,
                                    expression=node_text(node),
                                    function=current_function,
                                    call_function=func_name,
                                    call_asm_target=None,
                                    call_is_indirect=False,
                                    scope="local" if current_function else "global",
                                    pointer_depth=intrinsic_pointer_depth,
                                    target_base=intrinsic_target_base,
                                    target_field=intrinsic_target_field,
                                    operation_type=func_name,
                                    conditional_context=list(_condition_stack) if _condition_stack else None,
                                ))

            # G08: operator overloading — emit synthetic CCall("__opover_{op}_{left_var}")
            # for binary expressions using arithmetic/bitwise operators, so the analyzer can
            # resolve e.g. `a + b` → BetaVector::operator+ when `a` has a known class type.
            if node.type == "binary_expression" and current_function:
                _op_n = node.child_by_field_name("operator")
                _left_n = node.child_by_field_name("left")
                if _op_n and _left_n:
                    _op = node_text(_op_n).strip()
                    _ARITH_OPS = frozenset({
                        "+", "-", "*", "/", "%", "&", "|", "^", "<<", ">>",
                        "==", "!=", "<", ">", "<=", ">=",   # N04: comparison operators
                    })
                    if _op in _ARITH_OPS:
                        _lid = extract_identifier(_left_n)
                        if _lid:
                            unit.calls.append(CCall(
                                function=f"__opover_{_op}_{_lid}",
                                line=node.start_point[0] + 1,
                                enclosing_function=current_function,
                                call_is_indirect=False,
                                conditional_context=list(_condition_stack) if _condition_stack else None,
                            ))

            # N06: subscript operator — obj[i] → emit __opover_[]_obj for operator[] resolution
            if node.type == "subscript_expression" and current_function:
                _sub_arg = node.child_by_field_name("argument")
                if _sub_arg:
                    _lid = extract_identifier(_sub_arg)
                    if _lid:
                        unit.calls.append(CCall(
                            function=f"__opover_[]_{_lid}",
                            line=node.start_point[0] + 1,
                            enclosing_function=current_function,
                            call_is_indirect=False,
                            conditional_context=list(_condition_stack) if _condition_stack else None,
                        ))

            # N08: unary operators — emit __opover_{op}_{var} for -, +, ~, !
            # * and & are excluded to avoid pointer-dereference / address-of noise.
            if node.type == "unary_expression" and current_function:
                _UNARY_OPS = frozenset({"-", "+", "~", "!"})
                _op = None
                _arg_n = None
                for _ch in node.children:
                    if _op is None and not _ch.is_named:
                        _op = node_text(_ch).strip()
                    elif _arg_n is None and _ch.is_named:
                        _arg_n = _ch
                if _op in _UNARY_OPS and _arg_n:
                    _lid = extract_identifier(_arg_n)
                    if _lid:
                        unit.calls.append(CCall(
                            function=f"__opover_{_op}_{_lid}",
                            line=node.start_point[0] + 1,
                            enclosing_function=current_function,
                            call_is_indirect=False,
                            conditional_context=list(_condition_stack) if _condition_stack else None,
                        ))

            # N10: exception handler — catch (BetaException& e) → dependency on BetaException
            # Reuses __new_ prefix so the existing __new_ analyzer handler resolves it.
            if node.type == "catch_clause" and current_function:
                for _ch in node.children:
                    if _ch.type == "parameter_declaration":
                        _type_n = None
                        for _sub in _ch.children:
                            if _sub.type in ("type_identifier", "qualified_identifier"):
                                _type_n = _sub
                                break
                        if _type_n:
                            _cname = re.sub(r'<.*', '', node_text(_type_n)).strip()
                            if _cname and re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', _cname):
                                unit.calls.append(CCall(
                                    function=f"__new_{_cname}",
                                    line=node.start_point[0] + 1,
                                    enclosing_function=current_function,
                                    call_is_indirect=False,
                                    conditional_context=list(_condition_stack) if _condition_stack else None,
                                ))
                        break  # only one catch parameter per clause

            # H03: C++98 exception specification — void f() throw(BetaException)
            # Reuses __new_ prefix so existing analyzer handler resolves ExType → defining TU.
            if node.type == "throw_specifier" and current_function:
                for _ch in node.children:
                    if _ch.type in ("type_identifier", "qualified_identifier"):
                        _cname = re.sub(r'<.*', '', node_text(_ch)).strip()
                        if _cname and re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', _cname):
                            unit.calls.append(CCall(
                                function=f"__new_{_cname}",
                                line=node.start_point[0] + 1,
                                enclosing_function=current_function,
                                call_is_indirect=False,
                                conditional_context=list(_condition_stack) if _condition_stack else None,
                            ))

            # H01: direct throw statement — throw ExType() / throw ExType
            # tree-sitter-cpp: "value" is not a named field; use named_children[0].
            if node.type == "throw_statement" and current_function:
                _val = (node.child_by_field_name("value")
                        or (node.named_children[0] if node.named_children else None))
                if _val is not None:
                    _type_node = None
                    if _val.type == "call_expression":
                        _fn_node = _val.child_by_field_name("function")
                        if _fn_node and _fn_node.type in (
                            "identifier", "qualified_identifier", "type_identifier"
                        ):
                            _type_node = _fn_node
                    elif _val.type in ("identifier", "type_identifier", "qualified_identifier"):
                        _type_node = _val
                    if _type_node:
                        _cname = re.sub(r'<.*', '', node_text(_type_node)).strip()
                        if _cname and re.match(
                            r'^[A-Za-z_][A-Za-z0-9_]*(::[A-Za-z_][A-Za-z0-9_]*)*$', _cname
                        ):
                            unit.calls.append(CCall(
                                function=f"__new_{_cname}",
                                line=node.start_point[0] + 1,
                                enclosing_function=current_function,
                                call_is_indirect=False,
                            ))

            # FR01: friend function declaration — friend void betaDirect(CxWork* w)
            # Emit a CCall so build() can resolve betaDirect via cpp_fn_to_stem → defining TU.
            # Depth-first search: friend_declaration → declaration → function_declarator → identifier
            if node.type == "friend_declaration":
                def _find_fn_ident(n):
                    if n.type == "function_declarator":
                        for _c in n.children:
                            if _c.type in ("identifier", "qualified_identifier"):
                                return _c
                        return None
                    for _c in n.children:
                        _r = _find_fn_ident(_c)
                        if _r:
                            return _r
                    return None
                _ident = _find_fn_ident(node)
                if _ident:
                    _fname = re.sub(r'<.*', '', node_text(_ident)).strip()
                    if _fname and re.match(
                        r'^[A-Za-z_][A-Za-z0-9_]*(::[A-Za-z_][A-Za-z0-9_]*)*$', _fname
                    ):
                        unit.calls.append(CCall(
                            function=_fname,
                            line=node.start_point[0] + 1,
                            enclosing_function=current_function or "(global_init)",
                            call_is_indirect=False,
                            conditional_context=list(_condition_stack) if _condition_stack else None,
                        ))

            # N03: heap constructor — new ClassName(args) → emit __new_ClassName
            if node.type == "new_expression" and current_function:
                _type_n = node.child_by_field_name("type")
                if _type_n is None:
                    for _ch in node.children:
                        if _ch.type in ("type_identifier", "qualified_identifier", "template_type"):
                            _type_n = _ch
                            break
                if _type_n:
                    _cname = re.sub(r'<.*', '', node_text(_type_n)).strip()
                    if _cname and re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', _cname):
                        unit.calls.append(CCall(
                            function=f"__new_{_cname}",
                            line=node.start_point[0] + 1,
                            enclosing_function=current_function,
                            call_is_indirect=False,
                            conditional_context=list(_condition_stack) if _condition_stack else None,
                        ))

            if node.type == "assignment_expression":
                left = node.child_by_field_name("left")
                right = node.child_by_field_name("right")
                target, target_kind, pointer_depth, target_base, target_field = determine_target(left)
                # GAP-B/F: record bare-variable integer assignments for ECB const-prop.
                if target_kind == "variable" and target and right and current_function:
                    _iv = _try_int_literal(right)
                    if _iv is not None:
                        _ecb_const_map.setdefault(current_function, {})[target] = _iv
                # GAP-B/F: rewrite ECB arithmetic pointer casts when offset is known.
                if target_kind == "memory" and left is not None:
                    _resolved_ecb = _resolve_ecb_arith_cast(node_text(left).strip(), current_function)
                    if _resolved_ecb is not None:
                        target, target_kind = _resolved_ecb
                        target_base, target_field = None, None
                call_function = None
                call_asm_target = None
                call_is_indirect = False
                sources = dedupe(extract_identifiers(right)) if right else []
                sources.extend(extract_string_literals(right))
                sources.extend(extract_pointer_terms(right))
                access_source = extract_access_path(right) if right else None
                if access_source and access_source not in sources:
                    sources.append(access_source)
                if right:
                    call_expr = find_first(right, ("call_expression",))
                    if call_expr:
                        func_node = call_expr.child_by_field_name("function")
                        call_function, call_is_indirect = extract_callable_name(func_node)
                        call_function = with_template(call_function, current_template_suffix)
                        call_asm_target = alias_for(call_function)
                call_args: List[str] = []
                call_address_of_args: List[str] = []
                if right:
                    call_expr = find_first(right, ("call_expression",))
                    if call_expr:
                        call_args, call_address_of_args = extract_call_arguments(call_expr)
                operator_text = node_text(node)
                # Compound assignments depend on previous target value.
                if target and "=" in operator_text and not operator_text.strip().startswith(f"{target} ="):
                    sources.append(target)
                    # N05: emit synthetic operator overload call for compound assignment
                    if current_function and left:
                        _comp_ops = ("+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<=", ">>=")
                        _comp_op = next((op for op in _comp_ops if op in operator_text), None)
                        if _comp_op:
                            _llid = extract_identifier(left)
                            if _llid:
                                unit.calls.append(CCall(
                                    function=f"__opover_{_comp_op}_{_llid}",
                                    line=node.start_point[0] + 1,
                                    enclosing_function=current_function,
                                    call_is_indirect=False,
                                    conditional_context=list(_condition_stack) if _condition_stack else None,
                                ))
                # N09: plain '=' copy assignment → emit __opover_=_{lid}
                # Analyzer A7 filters primitives via var_type+_CPP_TYPE_KEYWORDS,
                # so only class-typed LHS variables produce a cross-file edge.
                if target and operator_text.strip().startswith(f"{target} =") and current_function and left:
                    _llid = extract_identifier(left)
                    if _llid:
                        unit.calls.append(CCall(
                            function=f"__opover_=_{_llid}",
                            line=node.start_point[0] + 1,
                            enclosing_function=current_function,
                            call_is_indirect=False,
                            conditional_context=list(_condition_stack) if _condition_stack else None,
                        ))
                sources = dedupe(sources)
                # Ternary condition annotation: detect conditional_expression
                # (cond ? a : b) in the RHS and distinguish condition identifiers
                # from data identifiers.  Condition vars are appended to
                # conditional_context so downstream can create use edges.
                _ternary_cond_ctx = list(_condition_stack) if _condition_stack else []
                if right:
                    _ternary_node = find_first(right, ("conditional_expression",))
                    if _ternary_node:
                        _tern_cond = _ternary_node.child_by_field_name("condition")
                        if _tern_cond:
                            _tern_cond_text = node_text(_tern_cond).strip()
                            if _tern_cond_text:
                                _ternary_cond_ctx.append(f"ternary({_tern_cond_text})")
                if target:
                    unit.assignments.append(CAssignment(
                        target=target,
                        target_kind=target_kind,
                        sources=sources,
                        line=node.start_point[0] + 1,
                        expression=node_text(node),
                        function=current_function,
                        call_function=call_function,
                        call_asm_target=call_asm_target,
                        call_is_indirect=call_is_indirect,
                        call_args=call_args,
                        call_address_of_args=call_address_of_args,
                        scope="local" if current_function else "global",
                        pointer_depth=pointer_depth,
                        target_base=target_base,
                        target_field=target_field,
                        conditional_context=_ternary_cond_ctx if _ternary_cond_ctx else None,
                    ))

                    # Hook: Record line for assignment
                    if line_collector:
                        line_collector.record_span(
                            str(file_path),
                            node.start_point[0] + 1,
                            node.end_point[0] + 1,
                        )

            if node.type == "init_declarator":
                declaration_node = node.parent
                declarator = node.child_by_field_name("declarator")
                value = node.child_by_field_name("value")
                target = extract_identifier(declarator) if declarator else extract_access_path(declarator)
                scope, storage_class = infer_scope_storage(declaration_node, current_function) if declaration_node else ("local" if current_function else "global", None)
                decl_spec = declaration_specifiers(
                    declaration_node,
                    linkage=current_linkage,
                    kind="variable",
                    scope=scope,
                ) if declaration_node else {
                    "data_type": None,
                    "storage_class": storage_class,
                    "declaration_type": self._classify_declaration_type([], [], "variable", scope, current_linkage),
                    "qualifiers": [],
                    "storage_tokens": [],
                }
                initializer_text = normalize_text(node_text(value)) if value else None

                # Structured bindings: auto [a, b] = expr; — emit one
                # CAssignment per bound name so each gets its own lineage edge.
                if declarator and declarator.type == "structured_binding_declarator":
                    _sb_names = [
                        node_text(ch).strip()
                        for ch in declarator.children
                        if ch.type == "identifier"
                    ]
                    if _sb_names and value:
                        _sb_sources = dedupe(extract_identifiers(value))
                        _sb_sources.extend(extract_string_literals(value))
                        _sb_sources.extend(extract_pointer_terms(value))
                        _sb_access = extract_access_path(value)
                        if _sb_access and _sb_access not in _sb_sources:
                            _sb_sources.append(_sb_access)
                        _sb_sources = dedupe(_sb_sources)
                        _sb_ctx = list(_condition_stack) if _condition_stack else None
                        for _sb_name in _sb_names:
                            if _sb_name:
                                unit.assignments.append(CAssignment(
                                    target=_sb_name,
                                    target_kind="variable",
                                    sources=_sb_sources,
                                    line=node.start_point[0] + 1,
                                    expression=node_text(node),
                                    function=current_function,
                                    scope=scope,
                                    storage_class=storage_class,
                                    conditional_context=_sb_ctx,
                                ))
                        target = None  # skip downstream single-target emission
                # GAP-B/F: record integer-literal initializers for ECB const-prop.
                if target and value and current_function:
                    _iv = _try_int_literal(value)
                    if _iv is not None:
                        _ecb_const_map.setdefault(current_function, {})[target] = _iv
                # GAP-G: record declared class type for virtual dispatch resolution.
                if target and current_function:
                    _cls = _extract_class_from_type(decl_spec.get("data_type"))
                    if _cls:
                        _var_type_map.setdefault(current_function, {})[target] = _cls
                related_symbols = dedupe((extract_identifiers(value) if value else []) + (extract_string_literals(value) if value else []))
                if target:
                    unit.declarations.append(CDeclaration(
                        name=target,
                        kind="variable",
                        line=node.start_point[0] + 1,
                        function=current_function,
                        scope=scope,
                        storage_class=storage_class or decl_spec.get("storage_class"),
                        declaration_type=str(decl_spec.get("declaration_type") or "local"),
                        data_type=decl_spec.get("data_type"),
                        initial_value=initializer_text,
                        expression=node_text(node),
                        initializer_sources=related_symbols,
                        related_symbols=related_symbols,
                        metadata={
                            "qualifiers": decl_spec.get("qualifiers", []),
                            "storage_tokens": decl_spec.get("storage_tokens", []),
                            "linkage": current_linkage,
                        },
                    ))
                sources = dedupe(extract_identifiers(value)) if value else []
                sources.extend(extract_string_literals(value))
                sources.extend(extract_pointer_terms(value))
                access_source = extract_access_path(value) if value else None
                if access_source and access_source not in sources:
                    sources.append(access_source)
                call_function = None
                call_asm_target = None
                call_is_indirect = False
                if value:
                    call_expr = find_first(value, ("call_expression",))
                    if call_expr:
                        func_node = call_expr.child_by_field_name("function")
                        call_function, call_is_indirect = extract_callable_name(func_node)
                        call_function = with_template(call_function, current_template_suffix)
                        call_asm_target = alias_for(call_function)
                call_args: List[str] = []
                call_address_of_args: List[str] = []
                if value:
                    call_expr = find_first(value, ("call_expression",))
                    if call_expr:
                        call_args, call_address_of_args = extract_call_arguments(call_expr)
                sources = dedupe(sources)
                # Ternary condition annotation for init_declarator.
                _init_ternary_ctx = list(_condition_stack) if _condition_stack else []
                if value:
                    _init_ternary_node = find_first(value, ("conditional_expression",))
                    if _init_ternary_node:
                        _init_tern_cond = _init_ternary_node.child_by_field_name("condition")
                        if _init_tern_cond:
                            _init_tern_text = node_text(_init_tern_cond).strip()
                            if _init_tern_text:
                                _init_ternary_ctx.append(f"ternary({_init_tern_text})")
                if target and value:
                    unit.assignments.append(CAssignment(
                        target=target,
                        target_kind="variable",
                        sources=sources,
                        line=node.start_point[0] + 1,
                        expression=node_text(node),
                        function=current_function,
                        call_function=call_function,
                        call_asm_target=call_asm_target,
                        call_is_indirect=call_is_indirect,
                        call_args=call_args,
                        call_address_of_args=call_address_of_args,
                        scope=scope,
                        storage_class=storage_class,
                        conditional_context=_init_ternary_ctx if _init_ternary_ctx else None,
                    ))

                # Hook: Record line for declaration with initializer
                if line_collector and target:
                    line_collector.record_span(
                        str(file_path),
                        node.start_point[0] + 1,
                        node.end_point[0] + 1,
                    )

            if node.type == "declaration":
                scope, storage_class = infer_scope_storage(node, current_function)
                decl_spec = declaration_specifiers(
                    node,
                    linkage=current_linkage,
                    kind="variable",
                    scope=scope,
                )
                has_init = False
                for child in node.children:
                    if child.type == "init_declarator":
                        has_init = True
                        break
                function_decl_names: List[str] = []
                for child in node.children:
                    if child.type == "function_declarator":
                        name = extract_identifier(child)
                        if name:
                            function_decl_names.append(name)
                        continue
                    func_decl = find_first(child, ("function_declarator",))
                    if func_decl is not None:
                        name = extract_identifier(func_decl)
                        if name:
                            function_decl_names.append(name)

                if function_decl_names:
                    for name in dedupe(function_decl_names):
                        decl_name = with_template(name, current_template_suffix)
                        decl_alias = alias_for(decl_name)
                        if decl_alias and decl_alias != decl_name:
                            unit.function_aliases[decl_name] = decl_alias
                        unit.declarations.append(CDeclaration(
                            name=decl_name,
                            kind="function",
                            line=node.start_point[0] + 1,
                            function=current_function,
                            scope=scope,
                            storage_class=storage_class,
                            declaration_type=self._classify_declaration_type(
                                decl_spec.get("storage_tokens", []),
                                decl_spec.get("qualifiers", []),
                                "function",
                                scope,
                                current_linkage,
                            ),
                            data_type=decl_spec.get("data_type"),
                            expression=node_text(node),
                            metadata={
                                "qualifiers": decl_spec.get("qualifiers", []),
                                "storage_tokens": decl_spec.get("storage_tokens", []),
                                "linkage": current_linkage,
                            },
                        ))
                elif not has_init:
                    identifiers = declared_identifiers_from_declaration(node)
                    for ident in identifiers:
                        unit.declarations.append(CDeclaration(
                            name=ident,
                            kind="variable",
                            line=node.start_point[0] + 1,
                            function=current_function,
                            scope=scope,
                            storage_class=storage_class,
                            declaration_type=self._classify_declaration_type(
                                decl_spec.get("storage_tokens", []),
                                decl_spec.get("qualifiers", []),
                                "variable",
                                scope,
                                current_linkage,
                            ),
                            data_type=decl_spec.get("data_type"),
                            expression=node_text(node),
                            metadata={
                                "qualifiers": decl_spec.get("qualifiers", []),
                                "storage_tokens": decl_spec.get("storage_tokens", []),
                                "linkage": current_linkage,
                            },
                        ))

                # Hook: capture declaration lines even when they are not assignments/calls.
                if line_collector:
                    line_collector.record_span(
                        str(file_path),
                        node.start_point[0] + 1,
                        node.end_point[0] + 1,
                    )

            # Struct/class field declarations are common in headers and should be
            # represented in line metadata for scope/context lookups.
            if node.type == "field_declaration":
                field_spec = declaration_specifiers(
                    node,
                    linkage=current_linkage,
                    kind="member",
                    scope=current_type or "member",
                )
                for field_name in dedupe(extract_identifiers(node)):
                    # Record union membership for may_alias.
                    if current_type and current_type in unit.union_members:
                        if field_name not in unit.union_members[current_type]:
                            unit.union_members[current_type].append(field_name)
                    unit.declarations.append(CDeclaration(
                        name=field_name,
                        kind="member",
                        line=node.start_point[0] + 1,
                        function=current_function,
                        scope=current_type or "member",
                        storage_class=field_spec.get("storage_class"),
                        declaration_type=self._classify_declaration_type(
                            field_spec.get("storage_tokens", []),
                            field_spec.get("qualifiers", []),
                            "member",
                            current_type or "member",
                            current_linkage,
                        ),
                        data_type=field_spec.get("data_type"),
                        expression=node_text(node),
                        metadata={
                            "qualifiers": field_spec.get("qualifiers", []),
                            "storage_tokens": field_spec.get("storage_tokens", []),
                            "linkage": current_linkage,
                            "enclosing_type": current_type,
                        },
                    ))
                if line_collector:
                    line_collector.record_span(
                        str(file_path),
                        node.start_point[0] + 1,
                        node.end_point[0] + 1,
                    )

            # Track compile-time assertions in headers as significant lines.
            if node.type == "static_assert_declaration":
                if line_collector:
                    line_collector.record_span(
                        str(file_path),
                        node.start_point[0] + 1,
                        node.end_point[0] + 1,
                    )

            if node.type == "update_expression":
                arg = node.child_by_field_name("argument")
                target = extract_identifier(arg) if arg else None
                if target:
                    unit.assignments.append(CAssignment(
                        target=target,
                        target_kind="variable",
                        sources=[target],
                        line=node.start_point[0] + 1,
                        expression=node_text(node),
                        function=current_function,
                        scope="local" if current_function else "global",
                        conditional_context=list(_condition_stack) if _condition_stack else None,
                    ))
                    # N08: emit operator++/operator-- synthetic call for overload resolution
                    if current_function:
                        _upd_op = "++" if "++" in node_text(node) else "--"
                        unit.calls.append(CCall(
                            function=f"__opover_{_upd_op}_{target}",
                            line=node.start_point[0] + 1,
                            enclosing_function=current_function,
                            call_is_indirect=False,
                            conditional_context=list(_condition_stack) if _condition_stack else None,
                        ))
                    if line_collector:
                        line_collector.record_span(
                            str(file_path),
                            node.start_point[0] + 1,
                            node.end_point[0] + 1,
                        )

            if node.type == "return_statement":
                value = return_value_node(node)
                sources = dedupe(extract_identifiers(value)) if value else []
                sources.extend(extract_string_literals(value))
                sources.extend(extract_pointer_terms(value))
                access_source = extract_access_path(value) if value else None
                if access_source and access_source not in sources:
                    sources.append(access_source)
                sources = dedupe(sources)
                unit.returns.append(CReturn(
                    function=current_function,
                    line=node.start_point[0] + 1,
                    sources=sources,
                    expression=node_text(node)
                ))

                # Hook: Record line for return statement
                if line_collector:
                    line_collector.record_span(
                        str(file_path),
                        node.start_point[0] + 1,
                        node.end_point[0] + 1,
                    )

            # Lambda capture tracking: [&x, y] creates data dependencies
            # from enclosing scope to lambda body.
            if node.type == "lambda_expression" and current_function:
                _capture_list = None
                for _lch in node.children:
                    if _lch.type == "lambda_capture_specifier":
                        _capture_list = _lch
                        break
                if _capture_list is not None:
                    _cap_text = node_text(_capture_list).strip()
                    # Strip surrounding []
                    _cap_inner = _cap_text[1:-1].strip() if _cap_text.startswith("[") and _cap_text.endswith("]") else _cap_text
                    if _cap_inner in ("&", "="):
                        # Default capture: detect identifiers used inside lambda
                        # body that are defined in enclosing scope.
                        _body = node.child_by_field_name("body")
                        if _body:
                            _lambda_ids = dedupe(extract_identifiers(_body))
                            for _lid in _lambda_ids:
                                if _lid and _lid not in self._non_symbol_identifiers:
                                    unit.assignments.append(CAssignment(
                                        target=f"lambda::{_lid}",
                                        target_kind="variable",
                                        sources=[_lid],
                                        line=node.start_point[0] + 1,
                                        expression=f"lambda_capture({_lid})",
                                        function=current_function,
                                        scope="local",
                                        conditional_context=list(_condition_stack) if _condition_stack else None,
                                    ))
                    elif _cap_inner:
                        # Explicit captures: [&x, y, &z]
                        for _cap_item in _cap_inner.split(","):
                            _cap_item = _cap_item.strip()
                            if not _cap_item:
                                continue
                            _cap_var = _cap_item.lstrip("&").strip()
                            if _cap_var and re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', _cap_var):
                                unit.assignments.append(CAssignment(
                                    target=f"lambda::{_cap_var}",
                                    target_kind="variable",
                                    sources=[_cap_var],
                                    line=node.start_point[0] + 1,
                                    expression=f"lambda_capture({_cap_var})",
                                    function=current_function,
                                    scope="local",
                                    conditional_context=list(_condition_stack) if _condition_stack else None,
                                ))

            # Process children
            for child in node.children:
                walk(child, current_function, current_template_suffix, current_linkage, current_type)

            # Hook: Pop conditional after processing children
            if node.type in ("if_statement", "while_statement", "for_statement",
                             "switch_statement", "case_statement",
                             "do_statement", "for_range_loop"):
                if line_collector and node.type not in ("case_statement",):
                    line_collector.pop_condition()
                if _pushed_condition:
                    _condition_stack.pop()
                if node.type == "switch_statement" and _switch_cases_stack:
                    _switch_cases_stack.pop()

                # Early-return guard detection: if this if_statement's only
                # consequence is a return/break/continue, it is a guard.
                # Subsequent siblings in the same block only execute when
                # NOT(cond), so push the inverted condition.
                if node.type == "if_statement" and _pushed_condition is False:
                    # Only fires when we pushed a condition (otherwise no guard)
                    pass
                elif node.type == "if_statement":
                    _cons = node.child_by_field_name("consequence")
                    _alt = node.child_by_field_name("alternative")
                    if _cons is not None and _alt is None:
                        # Single-branch if (no else) — check if the block
                        # unconditionally exits (last statement is a return/
                        # break/continue/throw, regardless of how many statements
                        # precede it).  Code after this if only runs when NOT(cond).
                        _body_nodes = [c for c in _cons.children
                                       if c.is_named and c.type != "comment"]
                        if _body_nodes and _body_nodes[-1].type in (
                            "return_statement", "break_statement",
                            "continue_statement", "throw_statement",
                        ):
                            # Recover the condition we just popped.
                            _cond_node = node.child_by_field_name("condition")
                            _guard_cond = (node_text(_cond_node) or "").strip() if _cond_node else ""
                            if _guard_cond:
                                _guard_conditions.append(f"NOT{_guard_cond}")
                                _condition_stack.append(f"NOT{_guard_cond}")

            # Restore the enclosing if-condition on exit so the parent
            # if_statement's own pop finds it exactly once.
            if node.type == "else_clause" and _else_swapped:
                if _else_is_elif:
                    # We popped cond_A on entry; the inner if_statement pushed
                    # and popped cond_B, so the stack is now one shorter than
                    # before.  Put cond_A back so the outer if can pop it.
                    _condition_stack.append(_else_saved)
                else:
                    # Compute the negated form that was pushed on entry (mirrors
                    # the de-negation logic above) and swap back to the original.
                    if _else_saved.startswith("NOT(") and _else_saved.endswith(")"):
                        _pushed_neg = _else_saved[3:]  # was de-negated on entry
                    else:
                        _pushed_neg = f"NOT{_else_saved}"
                    if _condition_stack and _condition_stack[-1] == _pushed_neg:
                        _condition_stack[-1] = _else_saved

            # When leaving a compound_statement, remove guard conditions that
            # were pushed while inside it — they only apply to siblings, not outer code.
            if node.type == "compound_statement" and _compound_depth:
                _saved = _compound_depth.pop()
                while len(_guard_conditions) > _saved:
                    _gc = _guard_conditions.pop()
                    try:
                        _condition_stack.remove(_gc)
                    except ValueError:
                        pass

            # Hook: Exit function after processing all children
            if node.type == "function_definition":
                if line_collector:
                    line_collector.exit_function()

        walk(root, None, None, None, None)
        # Phase 5b — regex fallback / supplement. Runs even when tree-sitter
        # ran successfully so that parser environments without full AST
        # coverage still capture comparisons. Duplicates are filtered by key.
        self._merge_regex_conditions(unit, text, file_path)
        return unit

    def _parse_with_regex_fallback(self, unit: CTranslationUnit, text: str) -> None:
        """Best-effort parser used when tree-sitter is unavailable.

        The fallback intentionally captures only core constructs required by
        downstream lineage/call-graph passes: function boundaries, parameters,
        declarations, assignments, returns, and function calls.
        """
        clean = self._strip_comments_preserve_layout(text)
        seen_call_keys: Set[Tuple[Optional[str], str, int, Tuple[str, ...]]] = set()
        function_ranges: List[Tuple[int, int]] = []

        idx = 0
        while idx < len(clean):
            if clean[idx] != "{":
                idx += 1
                continue

            close_idx = self._find_matching(clean, idx, "{", "}")
            if close_idx < 0:
                idx += 1
                continue

            sig_start = max(clean.rfind(";", 0, idx), clean.rfind("}", 0, idx), clean.rfind("{", 0, idx)) + 1
            signature = clean[sig_start:idx].strip()
            func_name, params_text = self._extract_signature_name_and_params(signature)
            if not func_name:
                idx = close_idx + 1
                continue

            start_line = self._line_number_at(clean, sig_start)
            end_line = self._line_number_at(clean, close_idx)
            unit.functions.append(CFunction(name=func_name, start_line=start_line, end_line=end_line))

            alias = self._alias_for(func_name, unit.symbol_aliases)
            if alias and alias != func_name:
                unit.function_aliases[func_name] = alias

            for param in self._split_args(params_text):
                param_name = self._extract_param_name(param)
                if not param_name:
                    continue
                data_type = self._extract_decl_base_type_from_statement(param, param_name)
                unit.declarations.append(CDeclaration(
                    name=param_name,
                    kind="parameter",
                    line=start_line,
                    function=func_name,
                    scope="local",
                    declaration_type="parameter",
                    data_type=data_type,
                    expression=param,
                ))

            body = clean[idx + 1:close_idx]
            self._parse_fallback_function_body(
                unit=unit,
                body=body,
                function_name=func_name,
                body_start_line=start_line + 1,
                seen_call_keys=seen_call_keys,
            )
            function_ranges.append((idx, close_idx))
            idx = close_idx + 1

        global_text = self._mask_ranges_preserve_newlines(clean, function_ranges)
        for statement, line_no in self._iter_semicolon_statements(global_text, 1):
            stmt = statement.strip()
            if not stmt or stmt.startswith("#"):
                continue
            # Global variable declarations with initializers: "Type varName = initVal;"
            # These are skipped by _extract_signature_name_and_params (which returns None
            # for statements containing "="), so we handle them first.
            stmt_no_semi = stmt.rstrip(";")
            assign = self._split_assignment(stmt_no_semi)
            if assign:
                lhs, rhs, _op = assign
                g_target, g_kind, *_ = self._extract_assignment_target(lhs)
                if g_target and self._looks_like_declaration_lhs(lhs, g_target):
                    sources = self._extract_expression_sources(rhs)
                    storage = self._extract_storage_class(stmt)
                    scope_val = "extern" if storage == "extern" else ("static" if storage == "static" else "global")
                    unit.declarations.append(CDeclaration(
                        name=g_target,
                        kind="variable",
                        line=line_no,
                        function=None,
                        scope=scope_val,
                        storage_class=storage,
                        declaration_type=self._classify_declaration_type(
                            [storage] if storage else [],
                            ["const"] if re.search(r"\bconst\b", lhs) else [],
                            "variable",
                            scope_val,
                            None,
                        ),
                        data_type=self._extract_decl_base_type_from_statement(lhs, g_target),
                        initial_value=rhs.strip() or None,
                        expression=stmt,
                        initializer_sources=sources,
                        related_symbols=sources,
                    ))
                    continue  # handled as variable declaration; skip function-declaration path
            name, _ = self._extract_signature_name_and_params(stmt_no_semi)
            if not name:
                continue
            storage = self._extract_storage_class(stmt)
            scope = "extern" if storage == "extern" else ("static" if storage == "static" else "global")
            unit.declarations.append(CDeclaration(
                name=name,
                kind="function",
                line=line_no,
                function=None,
                scope=scope,
                storage_class=storage,
                declaration_type=self._classify_declaration_type(
                    [storage] if storage else [],
                    [],
                    "function",
                    scope,
                    None,
                ),
                data_type=self._extract_decl_base_type_from_statement(stmt, name),
                expression=stmt,
            ))
            alias = self._alias_for(name, unit.symbol_aliases)
            if alias and alias != name:
                unit.function_aliases[name] = alias

        # Best-effort type-alias capture for fallback mode.
        for line in clean.splitlines():
            typedef_match = re.match(r"^\s*typedef\s+(.+?)\s+([A-Za-z_]\w*)\s*;\s*$", line)
            if typedef_match:
                target = self._normalize_space(typedef_match.group(1))
                alias = self._normalize_space(typedef_match.group(2))
                if alias and target:
                    unit.type_aliases[alias] = target
                continue
            using_match = re.match(r"^\s*using\s+([A-Za-z_]\w*)\s*=\s*(.+?)\s*;\s*$", line)
            if using_match:
                alias = self._normalize_space(using_match.group(1))
                target = self._normalize_space(using_match.group(2))
                if alias and target:
                    unit.type_aliases[alias] = target

        # P08/P11: Extract class/struct inheritance for CHA.
        # Matches "struct Derived : public Base" and "class D : public A, private B"
        _inherit_re = re.compile(
            r'(?:struct|class)\s+(\w+)\s*:([^{;]+)', re.MULTILINE
        )
        _base_token_re = re.compile(
            r'(?:(?:public|private|protected|virtual)\s+)*([A-Za-z_]\w*(?:::[A-Za-z_]\w*)*)' 
        )
        for inh_m in _inherit_re.finditer(clean):
            derived_cls = inh_m.group(1).strip()
            bases_text  = inh_m.group(2)
            for base_m in _base_token_re.finditer(bases_text):
                base = base_m.group(1).strip()
                if base and base not in ('public', 'private', 'protected', 'virtual'):
                    unit.class_bases.setdefault(derived_cls, []).append(base)

    def _extract_statement_conditions(self, stmt: str) -> Optional[List[str]]:
        """Extract the chain of enclosing condition expressions from a statement.

        The regex fallback bundles ``if (cond) { assign; }`` as a single
        semicolon-terminated statement.  This helper peels off leading
        ``if/while/for/switch (...)`` headers and returns their condition
        expressions so they can be attached to ``CAssignment.conditional_context``.

        For switch/case, the switch discriminant is emitted first, then the
        specific case value as ``discriminant == VALUE`` so callers see both
        the switch variable and the matched branch.

        Example: ``if (x > 0) { if (y) { a = 1`` → ``["x > 0", "y"]``
        Example: ``switch (tc) { case A::B: stmt`` → ``["tc", "tc == A::B"]``
        """
        conditions: List[str] = []
        text = stmt.strip()
        cond_re = re.compile(r"^(if|while|for|switch)\s*\(")
        case_re = re.compile(r"^case\s+([^:]+?):\s*")
        pos = 0
        last_switch_expr: Optional[str] = None
        _switch_seen_cases: List[str] = []  # case values seen in current switch

        while pos < len(text):
            stripped = text[pos:].lstrip()
            if not stripped:
                break
            # Skip leading closing braces from previously emitted block ends
            # (the regex fallback may bundle `} while (...) { assign;` together).
            if stripped[0] == "}":
                pos += len(text[pos:]) - len(stripped) + 1  # skip whitespace + '}'
                last_switch_expr = None  # reset when leaving a switch block
                continue
            # After a switch, check for `case VALUE:` or `default:` before more if/switch.
            if last_switch_expr is not None:
                cm = case_re.match(stripped)
                if cm:
                    case_val = cm.group(1).strip()
                    if case_val:
                        _switch_seen_cases.append(case_val)
                        conditions.append(f"({last_switch_expr} == {case_val})")
                    else:
                        # default: — emit NOT IN if we saw specific cases
                        if _switch_seen_cases:
                            _vals = ", ".join(_switch_seen_cases)
                            conditions.append(f"({last_switch_expr} NOT IN {{{_vals}}})")
                    skip = len(text[pos:]) - len(stripped) + cm.end()
                    pos += skip
                    continue
                # Also match bare `default:`
                _def_m = re.match(r"^default\s*:\s*", stripped)
                if _def_m:
                    if _switch_seen_cases:
                        _vals = ", ".join(_switch_seen_cases)
                        conditions.append(f"({last_switch_expr} NOT IN {{{_vals}}})")
                    skip = len(text[pos:]) - len(stripped) + _def_m.end()
                    pos += skip
                    continue
            m = cond_re.match(stripped)
            if not m:
                break
            abs_pos = pos + (len(text[pos:]) - len(stripped))
            paren_open = abs_pos + m.end() - 1  # position of '('
            paren_close = self._find_matching(text, paren_open, "(", ")")
            if paren_close < 0:
                break
            cond_text = text[paren_open + 1: paren_close].strip()
            kw = m.group(1)
            # Advance past `) {` (or `return;` for early-return guard detection)
            next_pos = paren_close + 1
            after_paren = text[next_pos:].lstrip()
            # Early-return guard: `if (cond) return;` or `if (cond) { return; }`
            # The NOT(cond) is then a prerequisite for the following statements.
            _is_early_return = False
            if kw == "if":
                _early_re = re.compile(
                    r"^(return|break|continue|throw)\b[^;]*;", re.DOTALL
                )
                # bare form: if (c) return;
                if _early_re.match(after_paren):
                    _is_early_return = True
                # braced form: if (c) { return; }
                elif after_paren.startswith("{"):
                    _brace_close = self._find_matching(text, next_pos + (len(text[next_pos:]) - len(after_paren)), "{", "}")
                    if _brace_close > 0:
                        _inner = text[next_pos + (len(text[next_pos:]) - len(after_paren)) + 1: _brace_close].strip()
                        if _early_re.match(_inner):
                            _is_early_return = True

            if cond_text:
                if _is_early_return:
                    # Early-return guard: NOT(cond) is a prereq for following code.
                    conditions.append(f"NOT({cond_text})")
                    last_switch_expr = None
                else:
                    conditions.append(cond_text)
                    if kw == "switch":
                        last_switch_expr = cond_text
                        _switch_seen_cases = []  # reset case list for this switch
                    else:
                        last_switch_expr = None

            while next_pos < len(text) and text[next_pos] in " \t\n\r{":
                next_pos += 1
            pos = next_pos

        return conditions if conditions else None

    def _parse_fallback_function_body(
        self,
        unit: CTranslationUnit,
        body: str,
        function_name: str,
        body_start_line: int,
        seen_call_keys: Set[Tuple[Optional[str], str, int, Tuple[str, ...]]],
    ) -> None:
        for statement, line_no in self._iter_semicolon_statements(body, body_start_line):
            stmt = statement.strip()
            if not stmt:
                continue

            stmt_no_semicolon = stmt[:-1].strip() if stmt.endswith(";") else stmt

            # Extract enclosing conditions from the statement text.  The regex
            # fallback bundles ``if (cond) { assign;`` as a single statement so
            # the condition must be extracted from the text, not from line numbers.
            _stmt_conditions = self._extract_statement_conditions(stmt)

            # update expressions (++x / x--)
            update_target = self._extract_update_target(stmt_no_semicolon)
            if update_target:
                unit.assignments.append(CAssignment(
                    target=update_target,
                    target_kind="variable",
                    sources=[update_target],
                    line=line_no,
                    expression=stmt,
                    function=function_name,
                    scope="local",
                    conditional_context=_stmt_conditions,
                ))

            # returns
            if re.match(r"^\s*return\b", stmt_no_semicolon):
                expr = re.sub(r"^\s*return\b", "", stmt_no_semicolon, count=1).strip()
                sources = self._extract_expression_sources(expr)
                unit.returns.append(CReturn(
                    function=function_name,
                    line=line_no,
                    sources=sources,
                    expression=stmt,
                ))
                self._append_calls_from_expression(
                    expr=expr,
                    unit=unit,
                    line_no=line_no,
                    function_name=function_name,
                    seen_call_keys=seen_call_keys,
                    conditional_context=_stmt_conditions,
                )
                continue

            # assignments / initialized declarations
            assign = self._split_assignment(stmt_no_semicolon)
            if assign:
                lhs, rhs, _operator = assign
                target, target_kind, pointer_depth, target_base, target_field = self._extract_assignment_target(lhs)
                if target:
                    sources = self._extract_expression_sources(rhs)
                    call = self._first_call_in_expression(rhs)
                    call_function = call["function"] if call else None
                    call_args = call["args"] if call else []
                    call_address_of_args = call["address_of_args"] if call else []
                    call_is_indirect = bool(call and call["is_indirect"])
                    call_asm_target = self._alias_for(call_function, unit.symbol_aliases)
                    unit.assignments.append(CAssignment(
                        target=target,
                        target_kind=target_kind,
                        sources=sources,
                        line=line_no,
                        expression=stmt,
                        function=function_name,
                        call_function=call_function,
                        call_asm_target=call_asm_target,
                        call_is_indirect=call_is_indirect,
                        call_args=call_args,
                        call_address_of_args=call_address_of_args,
                        scope="local",
                        pointer_depth=pointer_depth,
                        target_base=target_base,
                        target_field=target_field,
                        conditional_context=_stmt_conditions,
                    ))
                    if self._looks_like_declaration_lhs(lhs, target):
                        base_type = self._extract_decl_base_type_from_statement(lhs, target)
                        declaration_type = self._classify_declaration_type(
                            [self._extract_storage_class(lhs)] if self._extract_storage_class(lhs) else [],
                            ["const"] if re.search(r"\bconst\b", lhs) else [],
                            "variable",
                            "local",
                            None,
                        )
                        unit.declarations.append(CDeclaration(
                            name=target,
                            kind="variable",
                            line=line_no,
                            function=function_name,
                            scope="local",
                            storage_class=self._extract_storage_class(lhs),
                            declaration_type=declaration_type,
                            data_type=base_type,
                            initial_value=rhs.strip() or None,
                            expression=stmt,
                            initializer_sources=sources,
                            related_symbols=sources,
                        ))
                self._append_calls_from_expression(
                    expr=rhs,
                    unit=unit,
                    line_no=line_no,
                    function_name=function_name,
                    seen_call_keys=seen_call_keys,
                    conditional_context=_stmt_conditions,
                )
                continue

            # local declarations without initializer
            decl_name = self._extract_local_declaration_name(stmt_no_semicolon)
            if decl_name:
                storage = self._extract_storage_class(stmt_no_semicolon)
                scope = "local_static" if storage == "static" else "local"
                declaration_type = self._classify_declaration_type(
                    [storage] if storage else [],
                    ["const"] if re.search(r"\bconst\b", stmt_no_semicolon) else [],
                    "variable",
                    scope,
                    None,
                )
                unit.declarations.append(CDeclaration(
                    name=decl_name,
                    kind="variable",
                    line=line_no,
                    function=function_name,
                    scope=scope,
                    storage_class=storage,
                    declaration_type=declaration_type,
                    data_type=self._extract_decl_base_type_from_statement(stmt_no_semicolon, decl_name),
                    expression=stmt,
                ))

            # H01: throw statement in regex fallback — emit __new_ExType for cross-file dep.
            _throw_m = re.match(r'^\s*throw\s+([A-Za-z_][A-Za-z0-9_:]*)', stmt_no_semicolon)
            if _throw_m:
                _tname = re.sub(r'<.*', '', _throw_m.group(1)).strip()
                _CPP_KWS = {"new", "delete", "this", "nullptr", "true", "false",
                            "const", "static", "volatile", "unsigned", "signed"}
                if _tname and _tname not in _CPP_KWS and re.match(r'^[A-Za-z_][A-Za-z0-9_:]*$', _tname):
                    _k = (function_name, f"__new_{_tname}", line_no, ())
                    if _k not in seen_call_keys:
                        seen_call_keys.add(_k)
                        unit.calls.append(CCall(
                            function=f"__new_{_tname}",
                            line=line_no,
                            enclosing_function=function_name,
                            call_is_indirect=False,
                        ))

            # standalone calls
            self._append_calls_from_expression(
                expr=stmt_no_semicolon,
                unit=unit,
                line_no=line_no,
                function_name=function_name,
                seen_call_keys=seen_call_keys,
                conditional_context=_stmt_conditions,
            )

    def _append_calls_from_expression(
        self,
        expr: str,
        unit: CTranslationUnit,
        line_no: int,
        function_name: Optional[str],
        seen_call_keys: Set[Tuple[Optional[str], str, int, Tuple[str, ...]]],
        conditional_context: Optional[List[str]] = None,
    ) -> None:
        for call in self._extract_calls(expr):
            key = (function_name, call["function"], line_no, tuple(call["args"]))
            if key in seen_call_keys:
                continue
            seen_call_keys.add(key)
            unit.calls.append(CCall(
                function=call["function"],
                line=line_no,
                enclosing_function=function_name,
                asm_target=self._alias_for(call["function"], unit.symbol_aliases),
                call_is_indirect=call["is_indirect"],
                args=call["args"],
                address_of_args=call["address_of_args"],
                conditional_context=conditional_context,
            ))

            # Phase 1 (regex fallback mirror of tree-sitter path): synthesize
            # CAssignment for memcpy/memset/strcpy/... — same semantics, same
            # CAssignment shape as the AST path above.
            self._append_memory_write_assignment(
                call=call,
                unit=unit,
                line_no=line_no,
                function_name=function_name,
                expression=expr,
                conditional_context=conditional_context,
            )

    def _append_memory_write_assignment(
        self,
        call: Dict[str, object],
        unit: CTranslationUnit,
        line_no: int,
        function_name: Optional[str],
        expression: str,
        conditional_context: Optional[List[str]] = None,
    ) -> None:
        """If `call` is a memory-write intrinsic, emit a CAssignment for arg[0]."""
        func_name = str(call.get("function") or "")
        spec = MEMORY_WRITE_INTRINSICS.get(func_name)
        if spec is None:
            return

        args = list(call.get("args") or [])  # type: ignore[arg-type]
        target_idx = int(spec["target_arg"])  # type: ignore[arg-type]
        if len(args) <= target_idx:
            return

        raw_target = (args[target_idx] or "").strip()
        # Strip a leading address-of so memcpy(&s->f, ...) analyses as s->f.
        if raw_target.startswith("&"):
            raw_target = raw_target[1:].strip()
            if raw_target.startswith("(") and raw_target.endswith(")"):
                raw_target = raw_target[1:-1].strip()
        if not raw_target:
            return

        target, target_kind, pointer_depth, target_base, target_field = (
            self._extract_assignment_target(raw_target)
        )
        if not target:
            return

        sources: List[str] = []
        if spec.get("source_is_literal"):
            lit_idx = int(spec["source_arg"])  # type: ignore[arg-type]
            if len(args) > lit_idx:
                lit_text = (args[lit_idx] or "").strip()
                if lit_text:
                    sources.append(lit_text)
        elif "source_arg" in spec:
            si = int(spec["source_arg"])  # type: ignore[arg-type]
            if len(args) > si:
                sources.extend(self._extract_expression_sources(args[si] or ""))
        elif "source_args" in spec:
            directive = spec["source_args"]
            if directive == "rest_from_2":
                start = 2
            elif directive == "rest_from_3":
                start = 3
            else:
                start = 1
            for src in args[start:]:
                sources.extend(self._extract_expression_sources(src or ""))

        sources = self._dedupe_list(sources)

        unit.assignments.append(CAssignment(
            target=target,
            target_kind=target_kind,
            sources=sources,
            line=line_no,
            expression=expression,
            function=function_name,
            call_function=func_name,
            call_asm_target=None,
            call_is_indirect=False,
            scope="local" if function_name else "global",
            pointer_depth=pointer_depth,
            target_base=target_base,
            target_field=target_field,
            operation_type=func_name,
            conditional_context=conditional_context,
        ))

    def _strip_comments_preserve_layout(self, text: str) -> str:
        def replace_block(match) -> str:
            chunk = match.group(0)
            return "".join("\n" if ch == "\n" else " " for ch in chunk)

        stripped = re.sub(r"/\*.*?\*/", replace_block, text, flags=re.DOTALL)
        stripped = re.sub(r"//[^\n]*", lambda m: " " * len(m.group(0)), stripped)
        return stripped

    def _line_number_at(self, text: str, idx: int) -> int:
        if idx <= 0:
            return 1
        return text.count("\n", 0, idx) + 1

    def _mask_ranges_preserve_newlines(self, text: str, ranges: List[Tuple[int, int]]) -> str:
        if not ranges:
            return text
        chars = list(text)
        for start, end in ranges:
            for i in range(start, min(end + 1, len(chars))):
                if chars[i] != "\n":
                    chars[i] = " "
        return "".join(chars)

    def _find_matching(self, text: str, start: int, open_ch: str, close_ch: str) -> int:
        depth = 0
        quote: Optional[str] = None
        escape = False
        for i in range(start, len(text)):
            ch = text[i]
            if quote:
                if escape:
                    escape = False
                    continue
                if ch == "\\":
                    escape = True
                    continue
                if ch == quote:
                    quote = None
                continue
            if ch in ("'", '"'):
                quote = ch
                continue
            if ch == open_ch:
                depth += 1
            elif ch == close_ch:
                depth -= 1
                if depth == 0:
                    return i
        return -1

    def _extract_signature_name_and_params(self, signature: str) -> Tuple[Optional[str], str]:
        if not signature or "(" not in signature or ")" not in signature:
            return None, ""
        close_idx = signature.rfind(")")
        open_idx = close_idx
        depth = 0
        while open_idx >= 0:
            ch = signature[open_idx]
            if ch == ")":
                depth += 1
            elif ch == "(":
                depth -= 1
                if depth == 0:
                    break
            open_idx -= 1
        if open_idx < 0:
            return None, ""

        before = signature[:open_idx].strip()
        if not before:
            return None, ""
        # C19/N04+: operator overloads — the identifier regex can't match symbols
        # like +, ==, (), []. Detect "ClassName::operator<sym>" explicitly.
        _op_m = re.search(
            r'([A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*::operator\S*)\s*$',
            before
        )
        if _op_m:
            return _op_m.group(1), signature[open_idx + 1:close_idx]
        name_match = re.search(r"([A-Za-z_~][A-Za-z0-9_~:]*)\s*$", before)
        if not name_match:
            return None, ""
        name = name_match.group(1)
        if name in {"if", "for", "while", "switch", "catch", "return", "sizeof"}:
            return None, ""
        params = signature[open_idx + 1:close_idx]
        return name, params

    def _split_args(self, args_text: str) -> List[str]:
        args: List[str] = []
        current: List[str] = []
        paren = bracket = brace = angle = 0
        quote: Optional[str] = None
        escape = False

        for ch in args_text:
            if quote:
                current.append(ch)
                if escape:
                    escape = False
                    continue
                if ch == "\\":
                    escape = True
                    continue
                if ch == quote:
                    quote = None
                continue

            if ch in ("'", '"'):
                quote = ch
                current.append(ch)
                continue

            if ch == "(":
                paren += 1
            elif ch == ")":
                paren = max(paren - 1, 0)
            elif ch == "[":
                bracket += 1
            elif ch == "]":
                bracket = max(bracket - 1, 0)
            elif ch == "{":
                brace += 1
            elif ch == "}":
                brace = max(brace - 1, 0)
            elif ch == "<":
                angle += 1
            elif ch == ">":
                angle = max(angle - 1, 0)

            if ch == "," and not (paren or bracket or brace or angle):
                arg = "".join(current).strip()
                if arg:
                    args.append(arg)
                current = []
                continue
            current.append(ch)

        tail = "".join(current).strip()
        if tail:
            args.append(tail)
        return args

    def _extract_param_name(self, param: str) -> Optional[str]:
        text = param.strip()
        if not text or text == "void" or text == "...":
            return None
        text = re.sub(r"\s*=\s*.*$", "", text).strip()
        fn_ptr = re.search(r"\(\s*\*\s*([A-Za-z_]\w*)\s*\)", text)
        if fn_ptr:
            return fn_ptr.group(1)
        text = re.sub(r"\[[^\]]*\]", "", text).strip()
        match = re.search(r"([A-Za-z_]\w*)\s*$", text)
        if not match:
            return None
        candidate = match.group(1)
        if self._is_non_symbol_identifier(candidate):
            return None
        return candidate

    def _iter_semicolon_statements(self, text: str, base_line: int) -> List[Tuple[str, int]]:
        statements: List[Tuple[str, int]] = []
        current: List[str] = []
        paren_depth = 0
        quote: Optional[str] = None
        escape = False
        line_no = base_line
        statement_line = base_line

        for ch in text:
            if not current and not ch.isspace():
                statement_line = line_no
            current.append(ch)

            if quote:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == quote:
                    quote = None
            else:
                if ch in ("'", '"'):
                    quote = ch
                elif ch == "(":
                    paren_depth += 1
                elif ch == ")":
                    paren_depth = max(paren_depth - 1, 0)
                elif ch == ";" and paren_depth == 0:
                    statement = "".join(current).strip()
                    if statement:
                        statements.append((statement, statement_line))
                    current = []
            if ch == "\n":
                line_no += 1

        return statements

    def _extract_storage_class(self, statement: str) -> Optional[str]:
        if re.search(r"\btypedef\b", statement):
            return "typedef"
        if re.search(r"\bthread_local\b", statement):
            return "thread_local"
        if re.search(r"\bstatic\b", statement):
            return "static"
        if re.search(r"\bextern\b", statement):
            return "extern"
        if re.search(r"\bregister\b", statement):
            return "register"
        if re.search(r"\bauto\b", statement):
            return "auto"
        return None

    def _is_numeric_literal(self, token: str) -> bool:
        value = (token or "").strip()
        if not value:
            return False
        return bool(self._numeric_literal_re.fullmatch(value))

    def _replace_with_layout_spaces(self, text: str, start: int, end: int) -> str:
        if start < 0 or end <= start or start >= len(text):
            return text
        chars = list(text)
        limit = min(end, len(chars))
        for idx in range(start, limit):
            if chars[idx] != "\n":
                chars[idx] = " "
        return "".join(chars)

    def _strip_string_literals_preserve_layout(self, text: str) -> str:
        stripped = text
        for match in re.finditer(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', text):
            stripped = self._replace_with_layout_spaces(stripped, match.start(), match.end())
        return stripped

    def _strip_c_style_casts_preserve_layout(self, text: str) -> str:
        pattern = re.compile(r"\(\s*[A-Za-z_][A-Za-z0-9_:\s*&<>,]*\)\s*(?=[^)\s])")
        stripped = text
        for match in pattern.finditer(text):
            stripped = self._replace_with_layout_spaces(stripped, match.start(), match.end())
        return stripped

    def _strip_numeric_literals_preserve_layout(self, text: str) -> str:
        numeric_pattern = re.compile(
            r"(?<![A-Za-z_])(?:"
            r"[+-]?0[xX][0-9A-Fa-f]+"
            r"|[+-]?0[bB][01]+"
            r"|[+-]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?"
            r")(?:[uUlLfF]+)?"
        )
        stripped = text
        for match in numeric_pattern.finditer(text):
            stripped = self._replace_with_layout_spaces(stripped, match.start(), match.end())
        return stripped

    def _unwrap_balanced_parentheses(self, text: str) -> str:
        value = (text or "").strip()
        if not value:
            return ""
        while value.startswith("(") and value.endswith(")"):
            close_idx = self._find_matching(value, 0, "(", ")")
            if close_idx != len(value) - 1:
                break
            value = value[1:-1].strip()
            if not value:
                break
        return value

    def _strip_leading_c_style_casts(self, text: str) -> str:
        value = (text or "").strip()
        if not value:
            return ""
        while True:
            match = self._c_style_cast_prefix_re.match(value)
            if not match:
                break
            value = value[match.end():].lstrip()
        return value

    def _split_assignment(self, statement: str) -> Optional[Tuple[str, str, str]]:
        if not statement:
            return None

        paren = bracket = brace = 0
        quote: Optional[str] = None
        escape = False
        idx = 0
        while idx < len(statement):
            ch = statement[idx]
            if quote:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == quote:
                    quote = None
                idx += 1
                continue

            if ch in ("'", '"'):
                quote = ch
                idx += 1
                continue

            if ch == "(":
                paren += 1
                idx += 1
                continue
            if ch == ")":
                paren = max(paren - 1, 0)
                idx += 1
                continue
            if ch == "[":
                bracket += 1
                idx += 1
                continue
            if ch == "]":
                bracket = max(bracket - 1, 0)
                idx += 1
                continue
            if ch == "{":
                brace += 1
                idx += 1
                continue
            if ch == "}":
                brace = max(brace - 1, 0)
                idx += 1
                continue

            if paren or bracket or brace:
                idx += 1
                continue

            op = ""
            three = statement[idx:idx + 3]
            two = statement[idx:idx + 2]
            if three in ("<<=", ">>="):
                op = three
            elif two in ("+=", "-=", "*=", "/=", "%=", "&=", "|=", "^="):
                op = two
            elif ch == "=":
                prev = statement[idx - 1] if idx > 0 else ""
                nxt = statement[idx + 1] if idx + 1 < len(statement) else ""
                if prev not in "<>!" and nxt != "=":
                    op = "="

            if op:
                lhs = statement[:idx].strip()
                rhs = statement[idx + len(op):].strip()
                if lhs and rhs:
                    return lhs, rhs, op
                return None

            idx += 1

        return None

    def _extract_assignment_target(
        self, lhs: str
    ) -> Tuple[Optional[str], str, int, Optional[str], Optional[str]]:
        text = lhs.strip()
        pointer_depth = 0
        while text.startswith("*"):
            pointer_depth += 1
            text = text[1:].strip()

        compact = re.sub(r"\s+", "", text)
        if not compact:
            return None, "variable", pointer_depth, None, None

        if "[" in compact and "]" in compact:
            base = compact.split("[", 1)[0]
            return compact, "array_element", pointer_depth, base, None
        if "->" in compact:
            base, field = compact.rsplit("->", 1)
            return compact, "struct_field", pointer_depth, base, field
        if "." in compact:
            base, field = compact.rsplit(".", 1)
            return compact, "struct_field", pointer_depth, base, field
        if pointer_depth > 0:
            return compact, "memory", pointer_depth, None, None

        fn_ptr = re.search(r"\(\s*\*\s*([A-Za-z_]\w*)\s*\)$", text)
        if fn_ptr:
            return fn_ptr.group(1), "variable", pointer_depth, None, None

        text = re.sub(r"\[[^\]]*\]", "", text).strip()
        ident = re.search(r"([A-Za-z_]\w*)\s*$", text)
        if ident:
            return ident.group(1), "variable", pointer_depth, None, None
        return None, "variable", pointer_depth, None, None

    def _looks_like_declaration_lhs(self, lhs: str, target: str) -> bool:
        if not target:
            return False
        if any(tok in lhs for tok in ("->", ".", "[", "]")):
            return False
        pos = lhs.rfind(target)
        if pos <= 0:
            return False
        prefix = lhs[:pos].strip()
        if not prefix:
            return False
        if any(op in prefix for op in ("+", "-", "/", "%", "!", "=", "?")):
            return False
        # Reject standalone ":" (ternary operator colon) but allow "::" (scope resolution)
        # so that types like std::function<...> are correctly recognised as declaration LHS.
        if re.search(r'(?<!:):(?!:)', prefix):
            return False
        return True

    def _extract_local_declaration_name(self, statement: str) -> Optional[str]:
        if "(" in statement and ")" in statement:
            return None
        if "=" in statement:
            return None
        text = statement.strip()
        if not text:
            return None
        text = re.sub(r"\[[^\]]*\]", "", text).strip()
        match = re.search(r"([A-Za-z_]\w*)\s*$", text)
        if not match:
            return None
        name = match.group(1)
        if self._is_non_symbol_identifier(name):
            return None
        if name.startswith("asm_"):
            return None
        return name

    def _extract_update_target(self, statement: str) -> Optional[str]:
        prefix = re.search(r"(?:\+\+|--)\s*([A-Za-z_]\w*)", statement)
        if prefix:
            return prefix.group(1)
        suffix = re.search(r"([A-Za-z_]\w*)\s*(?:\+\+|--)", statement)
        if suffix:
            return suffix.group(1)
        return None

    def _extract_expression_sources(self, expression: str) -> List[str]:
        if not expression:
            return []
        sources: List[str] = []
        seen = set()

        def add(value: str) -> None:
            token = value.strip()
            if not token or token in seen:
                return
            seen.add(token)
            sources.append(token)

        for lit in re.findall(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', expression):
            add(lit)

        expression_for_symbols = self._strip_string_literals_preserve_layout(expression)
        expression_for_symbols = self._strip_c_style_casts_preserve_layout(expression_for_symbols)

        for ptr in re.findall(r"\*[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?", expression_for_symbols):
            add(ptr.replace(" ", ""))

        for access in re.findall(
            r"[A-Za-z_][A-Za-z0-9_]*(?:(?:->|\.)[A-Za-z_][A-Za-z0-9_]*|\[[^\]]+\])+",
            expression_for_symbols,
        ):
            add(access.replace(" ", ""))

        identifier_scan_text = self._strip_numeric_literals_preserve_layout(expression_for_symbols)
        for ident in re.findall(r"[A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*", identifier_scan_text):
            if self._is_non_symbol_identifier(ident):
                continue
            add(ident)

        return sources

    def _extract_calls(self, expression: str) -> List[Dict[str, object]]:
        calls: List[Dict[str, object]] = []
        idx = 0
        # C/C++ type keywords can never be valid call targets — without this filter, a
        # declarator like "unsigned member_size(...)" or "struct Foo(...)" backtracks to
        # the type keyword ("unsigned"/"struct") instead of the real name, and that
        # keyword then flows through the call graph as if it were a callee module (it
        # ends up flagged as a "missing" file with no blueprint downstream).
        type_keywords = {
            "void", "int", "char", "short", "long", "unsigned", "signed",
            "float", "double", "bool", "auto", "struct", "class", "union",
            "enum", "nullptr", "true", "false", "const", "volatile",
        }
        keywords = {"if", "for", "while", "switch", "return", "sizeof", "alignof",
                    "typeid"} | type_keywords
        cast_prefixes = ("static_cast<", "reinterpret_cast<", "const_cast<", "dynamic_cast<")
        cast_keywords = {"static_cast", "reinterpret_cast", "const_cast", "dynamic_cast"}

        while idx < len(expression):
            if expression[idx] != "(":
                idx += 1
                continue

            j = idx - 1
            while j >= 0 and expression[j].isspace():
                j -= 1
            end = j
            while j >= 0 and (expression[j].isalnum() or expression[j] in "_:~>.<-*"):
                j -= 1
            token = expression[j + 1:end + 1].strip()
            token = token.lstrip("&*")
            if not token or token in keywords:
                # P16: detect (*var)(args) indirect dereference-call pattern.
                # e.g. (*fp_ptr)(wa) → CCall(function='fp_ptr', is_indirect=True)
                # When the token is empty, check if the char before this '(' is ')'.
                # If so, find the matching '(' going backward, check content is '*identifier'.
                if not token and end >= 0 and expression[end] == ')':
                    depth, k = 1, end - 1
                    while k >= 0 and depth > 0:
                        if expression[k] == ')':
                            depth += 1
                        elif expression[k] == '(':
                            depth -= 1
                        k -= 1
                    if depth == 0:
                        inner = expression[k + 2:end].strip()
                        deref_m = re.match(r'^\*\s*([A-Za-z_][A-Za-z0-9_]*)\s*$', inner)
                        if deref_m:
                            deref_var = deref_m.group(1)
                            close_idx = self._find_matching(expression, idx, '(', ')')
                            if close_idx >= 0:
                                raw_args = self._split_args(expression[idx + 1:close_idx])
                                a_args = [self._normalize_call_arg(r) for r in raw_args]
                                calls.append({
                                    'function': deref_var,
                                    'args': [a for a in a_args if a],
                                    'address_of_args': [],
                                    'is_indirect': True,
                                })
                                idx = close_idx + 1
                                continue
                idx += 1
                continue
            if token in cast_keywords:
                idx += 1
                continue
            if token.startswith(cast_prefixes):
                idx += 1
                continue

            close_idx = self._find_matching(expression, idx, "(", ")")
            if close_idx < 0:
                idx += 1
                continue

            args_text = expression[idx + 1:close_idx]
            raw_args = self._split_args(args_text)
            args: List[str] = []
            address_of_args: List[str] = []
            for raw in raw_args:
                normalized = self._normalize_call_arg(raw)
                if not normalized:
                    continue
                args.append(normalized)
                stripped = raw.strip()
                if stripped.startswith("&"):
                    address_token = self._normalize_call_arg(stripped[1:].strip())
                    if address_token:
                        address_of_args.append(address_token)

            calls.append({
                "function": token,
                "args": args,
                "address_of_args": address_of_args,
                "is_indirect": ("->" in token or "." in token or token.startswith("*")),
            })
            idx = close_idx + 1
        return calls

    def _first_call_in_expression(self, expression: str) -> Optional[Dict[str, object]]:
        calls = self._extract_calls(expression)
        if not calls:
            return None
        return calls[0]

    def _normalize_call_arg(self, value: str) -> str:
        arg = value.strip()
        if not arg:
            return ""

        arg = self._unwrap_balanced_parentheses(arg)

        cast_match = re.match(
            r"^(?:static_cast|reinterpret_cast|const_cast|dynamic_cast)\s*<[^>]+>\s*\((.*)\)$",
            arg,
        )
        if cast_match:
            return self._normalize_call_arg(cast_match.group(1))

        arg = self._strip_leading_c_style_casts(arg)
        arg = self._unwrap_balanced_parentheses(arg)
        if not arg:
            return ""

        if re.fullmatch(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', arg):
            return arg
        if self._is_numeric_literal(arg):
            return arg

        nested_call = self._first_call_in_expression(arg)
        if nested_call and nested_call.get("args"):
            return str(nested_call["args"][0])

        access = re.search(r"[A-Za-z_][A-Za-z0-9_]*(?:(?:->|\.)[A-Za-z_][A-Za-z0-9_]*|\[[^\]]+\])+", arg)
        if access:
            return access.group(0).replace(" ", "")

        ident = re.search(r"&?\**\s*([A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*)", arg)
        if ident:
            prefix = ""
            stripped = arg.lstrip()
            while stripped.startswith(("*", "&")):
                prefix += stripped[0]
                stripped = stripped[1:].lstrip()
            return f"{prefix}{ident.group(1)}"

        return arg

    def _alias_for(self, name: Optional[str], symbol_aliases: Dict[str, str]) -> Optional[str]:
        if not name:
            return None
        if name in symbol_aliases:
            return symbol_aliases[name]
        tail = name.split("::")[-1]
        return symbol_aliases.get(tail)

    def _extract_field_asm_aliases(
        self, text: str, file_path: Path
    ) -> Tuple[Dict[str, str], Dict[str, str]]:
        """Extract C++ struct-field to ASM-name mappings from trailing `// XXX` comments.

        Only scans headers whose filename starts with 'cc' (case-insensitive).
        Returns a tuple `(aliases, sources)` where:
          - aliases: {"StructName.fieldName": "ASM_NAME", ...}
          - sources: {"StructName.fieldName": "<header basename>", ...}
        The second dict lets downstream consumers say *which* cc*.hpp supplied
        the mapping (needed when aliases are collected from transitively
        included headers). Basename is used so output is machine-independent.
        """
        if not Path(file_path).name.lower().startswith("cc"):
            # For non-cc files (e.g. .cpp), scan for #include "cc*.hpp"
            # directives and extract aliases from each reachable header.
            _inc_re = re.compile(r'^\s*#\s*include\s*"([^"]+)"', re.MULTILINE)
            _merged_aliases: Dict[str, str] = {}
            _merged_sources: Dict[str, str] = {}
            _base_dir = Path(file_path).parent
            for _m in _inc_re.finditer(text):
                _inc_name = _m.group(1)
                if not Path(_inc_name).name.lower().startswith("cc"):
                    continue
                # Try path as written, then bare basename in the same directory.
                for _candidate in (
                    _base_dir / _inc_name,
                    _base_dir / Path(_inc_name).name,
                ):
                    if _candidate.exists():
                        try:
                            _a, _s = self._extract_field_asm_aliases(
                                _candidate.read_text(encoding="utf-8", errors="replace"),
                                _candidate,
                            )
                            _merged_aliases.update(_a)
                            _merged_sources.update(_s)
                        except Exception:
                            pass
                        break
            return _merged_aliases, _merged_sources

        cleaned_text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)

        # Keep trailing `// ...` only on lines whose pre-comment text ends in ';'
        # (field-mapping lines). This strips struct-header inline comments like
        # `struct Da7gl   // HUBLIM` while preserving `char x; // WK_X`.
        kept_lines = []
        for raw in cleaned_text.split("\n"):
            idx = raw.find("//")
            if idx < 0:
                kept_lines.append(raw)
                continue
            before = raw[:idx]
            if before.rstrip().endswith(";"):
                kept_lines.append(raw)
            else:
                kept_lines.append(before)
        text_clean = "\n".join(kept_lines)

        struct_open_re = re.compile(r"\bstruct(?:\s+([A-Za-z_]\w*))?\s*\{")
        close_with_member_re = re.compile(
            r"\}\s*([A-Za-z_]\w*)\s*(?:\[[^\]]*\])*\s*;\s*//\s*(.*?)\s*$"
        )
        field_line_re = re.compile(r"^\s*(.*?)\s*;\s*//\s*(.*?)\s*$")
        field_name_re = re.compile(r"([A-Za-z_]\w*)\s*(?:\[[^\]]*\])*\s*$")
        asm_token_re = re.compile(
            r"^([A-Za-z@#$_][A-Za-z0-9@#$_]{0,15})(?:\s+R\d{2,4}[A-Z]?)*\s*$"
        )
        revision_re = re.compile(r"^R\d{2,4}[A-Z]?$")

        # Map global char-position of each `{` opening a struct to its name
        # (None for anonymous). Regex spans newlines so `struct Da7gl\n{` matches.
        struct_opens: Dict[int, Optional[str]] = {}
        for m in struct_open_re.finditer(text_clean):
            struct_opens[m.end() - 1] = m.group(1)

        aliases: Dict[str, str] = {}
        sources: Dict[str, str] = {}
        header_basename = Path(file_path).name
        # Stack: str (named struct) | None (anon struct) | False (non-struct brace)
        stack: List = []

        pos = 0
        for raw_line in text_clean.split("\n"):
            line_start = pos
            pos += len(raw_line) + 1

            close_m = close_with_member_re.search(raw_line)
            handled_close = False
            if close_m and stack:
                member_name = close_m.group(1)
                comment = close_m.group(2)
                top = stack[-1]
                if top is None or top is False:
                    stack.pop()
                    parent = next(
                        (s for s in reversed(stack) if isinstance(s, str)), None
                    )
                    if parent:
                        token_m = asm_token_re.match(comment)
                        if token_m and not revision_re.match(token_m.group(1)):
                            key = f"{parent}.{member_name}"
                            aliases[key] = token_m.group(1).upper()
                            sources[key] = header_basename
                    handled_close = True
                elif isinstance(top, str):
                    stack.pop()
                    handled_close = True

            if handled_close:
                continue

            for i, ch in enumerate(raw_line):
                if ch == "{":
                    gp = line_start + i
                    stack.append(struct_opens.get(gp, False))
                elif ch == "}":
                    if stack:
                        stack.pop()

            if (
                stack
                and isinstance(stack[-1], str)
                and "{" not in raw_line
                and "}" not in raw_line
            ):
                fm = field_line_re.match(raw_line)
                if fm:
                    body, comment = fm.group(1), fm.group(2)
                    token_m = asm_token_re.match(comment.strip())
                    if token_m and not revision_re.match(token_m.group(1)):
                        name_m = field_name_re.search(body)
                        if name_m:
                            parent = stack[-1]
                            key = f"{parent}.{name_m.group(1)}"
                            aliases[key] = token_m.group(1).upper()
                            sources[key] = header_basename

        return aliases, sources

    _ENUM_BODY_RE = re.compile(
        r"\benum\s+([A-Za-z_]\w*)\s*\{([^{}]*)\}\s*;",
        re.DOTALL,
    )
    _ENUM_MEMBER_LINE_RE = re.compile(
        r"^\s*([A-Za-z_]\w*)\s*(?:=\s*(.+?))?\s*$"
    )

    def _extract_enum_values(
        self, text: str, file_path: Path
    ) -> Dict[str, Dict[str, str]]:
        """Extract named-enum members and their literal values.

        Returns ``{identifier: {"enum_type": <name>, "value": <literal_str>}}``.

        - Char literals (``'A'``), integer literals (``42``), and hex
          literals (``0x80``) are kept verbatim — no constant folding.
        - Implicit values auto-increment per the C enum rule: start at 0
          unless the last explicit integer value was different.
        - Anonymous enums (``enum { FOO = 1 }``) are skipped.
        - Only scanned once per parse() call; see plan §4.
        """
        # Strip block comments to avoid commented-out enums polluting the index.
        cleaned = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)

        result: Dict[str, Dict[str, str]] = {}
        for match in self._ENUM_BODY_RE.finditer(cleaned):
            enum_name = match.group(1)
            body = match.group(2)
            # Split body on commas — but respect trailing comment stripping.
            # Drop inline `//` comments on each member line first.
            body = re.sub(r"//[^\n]*", "", body)
            members = [seg.strip() for seg in body.split(",") if seg.strip()]
            running_int: Optional[int] = -1  # so next implicit is 0
            for member in members:
                m = self._ENUM_MEMBER_LINE_RE.match(member)
                if not m:
                    continue
                ident = m.group(1)
                raw_val = (m.group(2) or "").strip()
                if raw_val:
                    value_str = raw_val
                    # Try to track the running integer counter for auto-increment.
                    try:
                        if raw_val.lower().startswith("0x"):
                            running_int = int(raw_val, 16)
                        elif raw_val.lstrip("+-").isdigit():
                            running_int = int(raw_val)
                        else:
                            # char-literal or other — reset counter so later
                            # implicit members aren't mis-numbered.
                            running_int = None
                    except ValueError:
                        running_int = None
                else:
                    if running_int is None:
                        # No reliable counter — skip rather than emit wrong data.
                        continue
                    running_int += 1
                    value_str = str(running_int)
                result[ident] = {"enum_type": enum_name, "value": value_str}
        return result

    _COMPARISON_OPS = {"==", "!=", "<", ">", "<=", ">="}
    _COND_KEYWORD_RE = re.compile(r"\b(if|while|for)\b")
    _CASE_LABEL_RE = re.compile(r"\bcase\s+([^:\n]+?)\s*:")
    # Comparison: identifier/member/arrow chain  OP  identifier/member/arrow
    # chain (or literal). Captures one comparison at a time — the caller
    # iterates finditer() to gather all of them inside a condition body.
    _COMPARISON_RE = re.compile(
        r"(?P<lhs>(?:\w+(?:\s*(?:->|\.)\s*\w+)*))"
        r"\s*(?P<op>==|!=|<=|>=|<|>)\s*"
        r"(?P<rhs>(?:\w+(?:\s*(?:->|\.)\s*\w+)*|'[^']*'|\"[^\"]*\"|0[xX][0-9a-fA-F]+|\d+))"
    )
    _IDENT_TAIL_RE = re.compile(r"[A-Za-z_]\w*$")

    def _node_raw_text(self, node) -> str:
        """Decode tree-sitter node text; returns empty string on failure."""
        try:
            raw = getattr(node, "text", b"")
            if isinstance(raw, (bytes, bytearray)):
                return raw.decode("utf-8", errors="replace")
            if isinstance(raw, str):
                return raw
        except Exception:
            pass
        return ""

    def _collect_identifiers(self, node) -> List[str]:
        """Recursively collect bare identifier tokens under `node`, skipping
        function-call targets (so `foo(x)` yields ['x'], not ['foo','x'])."""
        if node is None:
            return []
        out: List[str] = []
        try:
            t = node.type
        except Exception:
            return out
        if t in ("call_expression",):
            arg_node = node.child_by_field_name("arguments")
            if arg_node:
                out.extend(self._collect_identifiers(arg_node))
            return out
        if t in ("identifier", "field_identifier"):
            txt = self._node_raw_text(node)
            if txt:
                out.append(txt)
            return out
        for child in getattr(node, "children", []) or []:
            out.extend(self._collect_identifiers(child))
        return out

    def _collect_comparisons_into_unit(
        self,
        unit: CTranslationUnit,
        node,
        file_path: Path,
        current_function: Optional[str],
        fallback_line: int,
    ) -> None:
        """Walk a condition subtree (the ``condition`` child of an
        if/while/for) and, for every binary_expression whose operator is a
        comparison, record a CCondition with both operand identifiers.

        Logical `&&` / `||` are traversed through — each side is inspected.
        Parenthesized / cast-wrapped operands are handled via recursion into
        their children.
        """
        if node is None:
            return
        stack = [node]
        while stack:
            n = stack.pop()
            if n is None:
                continue
            try:
                nt = n.type
            except Exception:
                continue
            if nt == "binary_expression":
                op_txt = ""
                op_child = n.child_by_field_name("operator")
                if op_child is not None:
                    op_txt = self._node_raw_text(op_child)
                if not op_txt:
                    # Some grammars expose the operator inline — inspect
                    # token children for the op symbol.
                    for child in n.children:
                        ct = self._node_raw_text(child)
                        if ct in self._COMPARISON_OPS or ct in ("&&", "||"):
                            op_txt = ct
                            break
                if op_txt in self._COMPARISON_OPS:
                    left = n.child_by_field_name("left")
                    right = n.child_by_field_name("right")
                    operands = self._collect_identifiers(left) + self._collect_identifiers(right)
                    expression = self._node_raw_text(n).strip() or ""
                    line = (n.start_point[0] + 1) if hasattr(n, "start_point") else fallback_line
                    if operands:
                        unit.conditions.append(CCondition(
                            function=current_function,
                            scope=current_function,
                            line=line,
                            expression=expression,
                            operator=op_txt,
                            operands=list(dict.fromkeys(operands)),
                        ))
                elif op_txt in ("&&", "||"):
                    # Traverse into both sides to find nested comparisons.
                    stack.extend(n.children)
                else:
                    # Not a comparison — still traverse children in case a
                    # nested comparison exists.
                    stack.extend(n.children)
            else:
                # Anything else — keep walking.
                stack.extend(getattr(n, "children", []) or [])

    def _record_case_condition(
        self,
        unit: CTranslationUnit,
        case_node,
        file_path: Path,
        current_function: Optional[str],
    ) -> None:
        """Record a `case VALUE:` label as a condition with operator='case'.

        The operand is the case value's identifier(s). Phase 5b treats this
        as an equality comparison against the enclosing switch expression
        for lineage-purposes — we emit use-edges on the case value."""
        value_node = case_node.child_by_field_name("value")
        if value_node is None:
            # Some grammars put the value as the first non-keyword child.
            for child in case_node.children:
                ct = getattr(child, "type", "")
                if ct and ct not in ("case", ":", "default"):
                    value_node = child
                    break
        if value_node is None:
            return
        operands = self._collect_identifiers(value_node)
        if not operands:
            return
        expression = f"case {self._node_raw_text(value_node).strip()}"
        line = (case_node.start_point[0] + 1) if hasattr(case_node, "start_point") else 0
        unit.conditions.append(CCondition(
            function=current_function,
            scope=current_function,
            line=line,
            expression=expression,
            operator="case",
            operands=list(dict.fromkeys(operands)),
        ))

    def _extract_conditions_regex(
        self,
        text: str,
        file_path: Path,
        functions: List[CFunction],
    ) -> List[CCondition]:
        """Regex-based fallback for conditional-comparison extraction.

        Used when tree-sitter is unavailable (or as belt-and-braces along
        with it). Recognises comparison operators inside ``if``/``while``/
        ``for`` conditions and inside ``case VALUE:`` labels. Enclosing
        function is looked up via line-range against ``unit.functions``.

        Returns a list of ``CCondition``. Duplicates across tree-sitter and
        regex paths are filtered at the call site.
        """
        # Strip block and line comments first (keep newlines to preserve line numbers).
        def _blank_comment(m: re.Match) -> str:
            return "".join("\n" if ch == "\n" else " " for ch in m.group(0))
        cleaned = re.sub(r"/\*.*?\*/", _blank_comment, text, flags=re.DOTALL)
        cleaned = re.sub(r"//[^\n]*", lambda m: " " * len(m.group(0)), cleaned)

        # Line-offset map for O(1) line lookup.
        line_starts = [0]
        for i, ch in enumerate(cleaned):
            if ch == "\n":
                line_starts.append(i + 1)

        def line_of(pos: int) -> int:
            # Binary search for insertion point.
            lo, hi = 0, len(line_starts) - 1
            while lo < hi:
                mid = (lo + hi + 1) // 2
                if line_starts[mid] <= pos:
                    lo = mid
                else:
                    hi = mid - 1
            return lo + 1  # 1-indexed line number

        def function_at(line: int) -> Optional[str]:
            for fn in functions:
                if fn.start_line <= line <= fn.end_line:
                    return fn.name
            return None

        def extract_condition_body(start: int) -> Tuple[Optional[str], int]:
            """Given position *start* just past `if`/`while`/`for` keyword,
            return the parenthesized condition text and the position after
            the closing paren. Returns (None, start) if no `(` follows."""
            i = start
            while i < len(cleaned) and cleaned[i] in " \t":
                i += 1
            if i >= len(cleaned) or cleaned[i] != "(":
                return None, start
            depth = 0
            j = i
            while j < len(cleaned):
                if cleaned[j] == "(":
                    depth += 1
                elif cleaned[j] == ")":
                    depth -= 1
                    if depth == 0:
                        return cleaned[i + 1:j], j + 1
                j += 1
            return None, start

        def bare_identifier(token: str) -> Optional[str]:
            """Extract the bare trailing identifier from a member chain —
            e.g. ``da7gl->cmSystem`` → ``cmSystem``, ``Y`` → ``Y``. Literals
            (chars, strings, hex, decimal) return None."""
            token = token.strip()
            if not token:
                return None
            if token[0] in ("'", '"') or token[:2] in ("0x", "0X") or token[0].isdigit():
                return None
            m = self._IDENT_TAIL_RE.search(token)
            return m.group(0) if m else None

        results: List[CCondition] = []
        seen: Set[Tuple[str, int, str]] = set()

        # if / while / for
        for kw in self._COND_KEYWORD_RE.finditer(cleaned):
            body, _ = extract_condition_body(kw.end())
            if not body:
                continue
            kw_name = kw.group(1)
            body_scan = body
            # For `for` statements the middle section between ';' is the
            # condition — isolate it if we can.
            if kw_name == "for":
                segments = body.split(";")
                if len(segments) >= 2:
                    body_scan = segments[1]
            # Find every comparison in the condition body.
            for cm in self._COMPARISON_RE.finditer(body_scan):
                lhs_raw = cm.group("lhs")
                rhs_raw = cm.group("rhs")
                op = cm.group("op")
                if op not in self._COMPARISON_OPS:
                    continue
                lhs_ident = bare_identifier(lhs_raw)
                rhs_ident = bare_identifier(rhs_raw)
                operands = [o for o in (lhs_ident, rhs_ident) if o]
                if not operands:
                    continue
                # Line = line of the keyword + offset into body (best effort).
                line = line_of(kw.start())
                # Build a readable expression. Use the matched text directly.
                expr = f"{lhs_raw.strip()} {op} {rhs_raw.strip()}"
                key = (str(file_path), line, expr)
                if key in seen:
                    continue
                seen.add(key)
                results.append(CCondition(
                    function=function_at(line),
                    scope=function_at(line),
                    line=line,
                    expression=expr,
                    operator=op,
                    operands=list(dict.fromkeys(operands)),
                ))

        # case VALUE:
        for cm in self._CASE_LABEL_RE.finditer(cleaned):
            value_raw = cm.group(1).strip()
            ident = bare_identifier(value_raw)
            if not ident:
                continue
            line = line_of(cm.start())
            expr = f"case {value_raw}"
            key = (str(file_path), line, expr)
            if key in seen:
                continue
            seen.add(key)
            results.append(CCondition(
                function=function_at(line),
                scope=function_at(line),
                line=line,
                expression=expr,
                operator="case",
                operands=[ident],
            ))

        return results

    def _merge_regex_conditions(
        self, unit: CTranslationUnit, text: str, file_path: Path
    ) -> None:
        """Merge regex-extracted conditions into `unit.conditions`, skipping
        any (file, line, expression) key already present (e.g. from the
        tree-sitter path)."""
        existing: Set[Tuple[str, int, str]] = {
            (str(file_path), c.line, c.expression) for c in unit.conditions
        }
        regex_conds = self._extract_conditions_regex(text, file_path, unit.functions)
        for c in regex_conds:
            key = (str(file_path), c.line, c.expression)
            if key not in existing:
                existing.add(key)
                unit.conditions.append(c)

    _GLOB_CALL_RE = re.compile(
        r"\bglob\s*\(\s*_([A-Za-z_]\w*)\s*\)"
    )

    def _extract_glob_globals(self, text: str) -> List[str]:
        """Phase 7 — pull the uppercased ASM global name out of every
        ``glob(_name)`` call site.

        Strips block + line comments first so commented-out examples
        don't pollute the index. Duplicates are removed, order follows
        first appearance."""
        cleaned = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
        cleaned = re.sub(r"//[^\n]*", "", cleaned)
        out: List[str] = []
        seen: Set[str] = set()
        for m in self._GLOB_CALL_RE.finditer(cleaned):
            name = m.group(1).upper()
            if name not in seen:
                seen.add(name)
                out.append(name)
        return out

    def _extract_symbol_aliases(self, text: str) -> dict:
        """Extract C/C++ to ASM symbol aliases from pragma map / asm labels."""
        aliases = {}
        # Strip comments to avoid false positives from documentation/examples.
        stripped = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
        stripped = re.sub(r"//.*", "", stripped)

        # z/TPF: #pragma map(cppName,"ASMNAME")
        pragma_re = re.compile(
            r'#\s*pragma\s+map\s*\(\s*([A-Za-z_]\w*)\s*,\s*"([^"]+)"\s*\)',
            re.IGNORECASE
        )
        for match in pragma_re.finditer(stripped):
            aliases[match.group(1)] = match.group(2)

        # z/Linux style: extern "C" void foo(...) asm("ASMNAME");
        # Keep this local to a single declaration by stopping at ;/{.
        # This tolerates trailing qualifiers/attributes between asm(...) and ;/{.
        declaration_re = re.compile(
            r'\b(?P<name>[A-Za-z_]\w*(?:::[A-Za-z_]\w*)*)\s*'
            r'\([^;{}]*?\)(?P<trailer>[^;{}]*)(?:;|\{)',
            re.IGNORECASE | re.MULTILINE | re.DOTALL,
        )
        asm_re = re.compile(
            r'(?:__asm__|asm)\s*\(\s*"([^"]+)"\s*\)',
            re.IGNORECASE | re.MULTILINE | re.DOTALL,
        )
        for decl in declaration_re.finditer(stripped):
            asm_match = asm_re.search(decl.group("trailer") or "")
            if not asm_match:
                continue
            name = decl.group("name")
            alias = asm_match.group(1)
            aliases[name] = alias

            # Also index by unqualified tail so lookups for ns::foo and foo both work.
            tail = name.split("::")[-1]
            aliases.setdefault(tail, alias)

        return aliases
