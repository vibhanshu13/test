#!/usr/bin/env python3
import sys
import time
import argparse
import sqlite3
from pathlib import Path

# Set up repository imports
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from vbt.engine import Hop, Endpoint, RouteEngine, resolve_aliases
from vbt.precompute.db_artifacts import set_load_only
from vbt.precompute.resolvers_db import preload_resolvers
from vbt.precompute.graph_db import preload_route_graph, preload_cpp_call_edges
from vbt.precompute.route_cache_db import preload_route_cache
from vbt.setters.asm_setters import set_asm_setter_map_job, find_asm_setters_in_file
from vbt.setters.cpp_setters import set_cpp_setter_map_job, set_cpp_file_writes_job, find_cpp_setters_in_file
from vbt.precompute.fn_facts_db import set_fn_facts_job
from vbt.reach.cpp_routes import enumerate_cpp_paths

def get_file_type_from_db(db_path: Path, stem: str) -> str:
    """Query index.db to determine if the stem is cpp or asm without filesystem reads."""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        # Look for the blueprint artifact keys
        cursor.execute("SELECT artifact FROM vbt_artifact_blob WHERE artifact LIKE ?", (f"bp:{stem}.%",))
        row = cursor.fetchone()
        conn.close()
        if row:
            art = row[0]
            if ".cpp.json" in art or ".hpp.json" in art:
                return "cpp"
            elif ".asm.json" in art or ".mac.json" in art:
                return "asm"
    except Exception:
        pass
    return "cpp"  # Fallback

def main():
    parser = argparse.ArgumentParser(description="Find reachable setters for multiple variables from a given stem/function completely from index.db.")
    parser.add_argument("--job-id", default="b58d8432-73e0-42d1-89a9-2ceebc47c6d2", help="Precomputed Job ID in jobs/ folder")
    parser.add_argument("--stem", default="dw710000", help="Starting file stem")
    parser.add_argument("--function", default="callPlasticAuthenticationComponentInterface", help="Starting C++ function name (or block_id for ASM)")
    parser.add_argument("variables", nargs="*", help="Variables to query (comma-separated or multiple arguments)")
    
    args = parser.parse_args()

    # Determine query variables
    query_variables = []
    for var in args.variables:
        query_variables.extend([v.strip() for v in var.split(",") if v.strip()])

    if not query_variables:
        # Prompt if empty
        var_input = input("Enter variables (comma-separated): ").strip()
        query_variables = [v.strip() for v in var_input.split(",") if v.strip()]

    if not query_variables:
        print("Error: No variables specified.")
        return

    job_id = args.job_id
    db_path = ROOT / "jobs" / job_id / "index.db"
    blueprint_dir = ROOT / "jobs" / job_id / "output" / "asm 5"
    asm_dir = ROOT / "datasource" / "asm7_admin" / "asm 7_version_0" / "asm 5"
    graph_file = blueprint_dir / "file_call_graph.json"

    if not db_path.is_file():
        print(f"Error: index.db not found at {db_path}")
        return

    # Determine file type of the starting stem
    file_type = get_file_type_from_db(db_path, args.stem)
    func_arg = args.function if file_type == "cpp" else None
    tail_ep = Endpoint(args.stem, file_type, func_arg)

    print(f"Initializing precomputed context from {db_path.name}...")
    t_start = time.perf_counter()

    # Configure database overrides and load-only behavior
    set_load_only(True)
    preload_resolvers(job_id, blueprint_dir, asm_dir)
    
    route = RouteEngine(blueprint_dir, graph_file, asm_dir, job_id=job_id)
    preload_route_graph(route, job_id, blueprint_dir, graph_file)
    preload_cpp_call_edges(route, job_id, blueprint_dir, asm_dir)
    preload_route_cache(route, job_id)

    set_asm_setter_map_job(job_id)
    set_cpp_setter_map_job(job_id)
    set_cpp_file_writes_job(job_id)
    set_fn_facts_job(job_id)

    from vbt.precompute.modifier_index import get_modifier_index
    midx = get_modifier_index(blueprint_dir, asm_dir)
    
    # Pre-solve reachable files from the starting stem
    reachable_files = route.forward_reachable_files(tail_ep)

    t_init = time.perf_counter() - t_start
    print(f"Loaded database index in {t_init * 1000:.2f} ms")
    print(f"Querying reachability from stem '{args.stem}' (type: {file_type}, function/block: '{args.function}')\n")

    # Run query for each variable
    for variable in query_variables:
        t_var_start = time.perf_counter()
        
        # 1. Resolve aliases
        alias_set = resolve_aliases(variable, "cpp", asm_dir)
        targets = [(variable, "cpp")] + [(a.name, a.language) for a in alias_set.aliases]

        # 2. Gather matching candidate setters in forward-reachable files
        setters = []
        for name, lang in targets:
            stems = sorted(midx.files_for(name, lang))
            pruned_stems = sorted(set(stems) & reachable_files)
            for stem in pruned_stems:
                if lang == "cpp":
                    tail_name = name.split(".")[-1].split("->")[-1]
                    root_fp = [name] if ("." in name or "->" in name) else None
                    setters += find_cpp_setters_in_file(tail_name, asm_dir / f"{stem}.cpp", full_paths=root_fp)
                else:
                    setters += find_asm_setters_in_file(name, stem, blueprint_dir, asm_dir)

        # 3. Check reachability path
        reachable_setters = []
        for s in setters:
            child = Endpoint(s.file_stem, s.language, s.function)
            reachable = False
            
            # Enumerate unified call paths
            cpp_paths, _ = enumerate_cpp_paths(route, {}, asm_dir, tail_ep, s, max_paths=64, max_depth=16)
            if cpp_paths:
                reachable = True
            else:
                r = route.routes(tail_ep, child)
                if r.get("reachable"):
                    reachable = True
            
            if reachable:
                reachable_setters.append(s)

        t_var = time.perf_counter() - t_var_start
        print(f"=== Variable: '{variable}' (took {t_var * 1000:.2f} ms) ===")
        print(f"Aliases searched: {[t[0] for t in targets]}")
        if not reachable_setters:
            print("  No reachable setters found.")
        else:
            for idx, s in enumerate(reachable_setters, 1):
                func_name = s.function if s.language == "cpp" else s.block_id
                code = getattr(s, "lhs_path", getattr(s, "instruction", "")) or s.lhs_chain
                print(f"  {idx}. {s.file_stem}.{s.language} @ line {s.line} inside {func_name}: {code}")
        print()

if __name__ == "__main__":
    main()
