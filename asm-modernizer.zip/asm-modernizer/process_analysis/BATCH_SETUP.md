# Hierarchical Walkthrough — Batch Generation Setup (fresh system)

How to bring up a new machine (or a fresh DB) and run the **batch API** that
pre-generates every walkthrough card with LLM calls, so each later card click is
a pure cache read.

See `HIERWALK_DATA_GUIDE.md` for what the walkthrough is and how inputs resolve.

---

## The batch API

Kick off (returns immediately with a `task_id`):

```
POST /demo/v1/projects/default/processes/<process>/hierwalk/batch?workers=8
→ 202 {"task_id":"…","started":true,"mode":"celery"|"threading"}
```

Poll until `status` is `done` (or `failed`):

```
GET /demo/v1/projects/default/processes/<process>/hierwalk/batch/status/<task_id>
→ {"status":"done","all_generated":true,
   "result":{"status":"completed","total_nodes":N,"generated":N,"skipped_cached":0,"failed":[]}}
```

- `<process>` — e.g. `plastic_authentication`. (`default` is the project segment;
  the walkthrough is project-free, so the value is ignored.)
- **Resumable**: re-dispatch after a failure/crash → resumes from its checkpoint
  (each node's `decomposed` flag), regenerating only what's missing.
- **Idempotent**: a fully-generated process returns `already_complete`,
  `generated:0`, makes **no** LLM calls.
- **`?restart=true`** wipes the substrate + all cards and regenerates from scratch.

---

## Fresh-system setup

### 1. Code + Python env + deps

```bash
git checkout <branch>
python3 -m venv env
env/bin/pip install -r requirements.txt -r requirements-api.txt
```

### 2. `.env` at the repo root (LLM key is mandatory)

```
GEMINI_API_KEY=<your key>            # REQUIRED — batch makes Gemini calls
LLM_MODEL_NAME=gemini-2.5-pro
REDIS_URL=redis://localhost:6379/0    # only if Redis is not on the default
```

Without `GEMINI_API_KEY`, every card fails.

### 3. Input files on disk (per process you want to generate)

The walkthrough reads three things — they must exist:

| Input | Location |
|---|---|
| Process definition | `data/processes/<process>/file_graph.json` (+ `metadata.json`) |
| Parser blueprints | `temp/output_latest/asm/<file>.json` (one per file in `file_graph`) |
| Source code | the path each file uses in `file_graph.json` |

If these are absent, the build 404s / produces an empty tree. This is the most
commonly missed step on a fresh box.

### 4. Database — auto-created, or reset explicitly

The DB (`process_analysis/backend/knowledge.db`) is created with the latest
schema on backend startup (`init_schema()` runs in the FastAPI lifespan). On a
truly fresh box, just starting the server (step 7) is enough.

For a guaranteed clean slate:

```bash
python3 process_analysis/scripts/reset_db.py --yes
```

### 5. Redis (for the optimised Celery path)

```bash
redis-server          # must be reachable at redis://localhost:6379
```

Celery uses three logical DBs: `/0` status, `/1` broker, `/2` result backend.

### 6. Celery worker — MUST set `PYTHONPATH` to the repo root

```bash
PYTHONPATH=$(pwd) env/bin/celery -A process_analysis.backend.celery_app worker \
    -Q q_llm -c 8 --loglevel=info
```

> The task imports the top-level `llm` package. Without the repo root on
> `PYTHONPATH` the worker dies with `ModuleNotFoundError: No module named 'llm'`.

### 7. Backend API server

```bash
env/bin/uvicorn process_analysis.backend.app:app --port 8010 --host 127.0.0.1
```

### 8. Run it

```bash
# kick off
curl -X POST "http://localhost:8010/demo/v1/projects/default/processes/plastic_authentication/hierwalk/batch?workers=8"
# poll (use the task_id from the response)
curl "http://localhost:8010/demo/v1/projects/default/processes/plastic_authentication/hierwalk/batch/status/<task_id>"
```

---

## Minimum without Redis/Celery

If Redis/Celery are not running, the same `POST …/batch` call transparently
falls back to a background thread (`mode:"threading"`) and you poll the same
status endpoint. You then only need steps **1, 2, 3, 7** (env + inputs +
uvicorn). You lose Celery's durability/scaling — fine for small/demo runs, use
the full Celery path for large processes.

---

## Ready checklist

- [ ] `GEMINI_API_KEY` in `.env`
- [ ] `data/processes/<p>/file_graph.json` + `temp/output_latest/asm/*.json` + source present
- [ ] Redis running (for Celery path)
- [ ] Celery worker up **with `PYTHONPATH=$(pwd)`** on queue `q_llm`
- [ ] uvicorn on :8010
- [ ] `POST …/hierwalk/batch` → poll status → `done`
