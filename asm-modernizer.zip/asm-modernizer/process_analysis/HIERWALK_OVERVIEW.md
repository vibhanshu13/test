# Hier Walk — Overview

What the hier walk does now, end to end: build a focused call hierarchy for a
process, explain it as business activities, and extract + classify its important
variables. This is the map; the linked docs are the detail.

| Topic | Detail doc |
|-------|-----------|
| Inputs the walk reads | `HIERWALK_DATA_GUIDE.md` |
| Batch API (run everything) | `HIERWALK_BATCH_API.md` |
| Variable finding approach | `../docs/VARIABLE_FINDING_APPROACH.md` |

---

## The problem it solves

The hier walk does a top‑down BFS from a process's entry point. On a real client
knowledge base that BFS reaches **~3000 files** for a process the client says is
**~200** — it was walking into every reachable db/util/infra file. We also needed,
for a process like Plastic Authentication, the **important variables** and what is
input vs output vs key‑business — not just block‑by‑block noise.

Three capabilities were added:

1. **Relevance gate** — stop walking into off‑process files.
2. **Variable map** — extract + classify the process's variables.
3. **Flags** to turn each on/off, on both the build and batch paths.

---

## 1. Relevance gate (the "util‑stop")

Decides **per file** whether the walk recurses into it or stops at it as a pruned
leaf — judged against *this* process, so the same db helper can be core for one
process and noise for another.

- **On demand from source.** Each file is judged from its OWN code (never the
  stored blueprint summary), against a process profile generated on demand from
  the seed entry's source.
- **Layered:** seed (entry always kept) → path/extension plumbing (`/util/`,
  `/db/`, `.mac/.cpy`) → LLM relevance judge (`core` / `supporting` / `utility` /
  `irrelevant`) → deterministic keyword fallback if no API key.
- **Self‑limiting:** a pruned file's children are never enqueued, so on a huge
  scope only files hanging off the relevant core ever get judged — bounding the
  walk *and* the LLM spend.
- **Memory:** verdicts cached in `hier_file_relevance`, content‑hashed on the
  source so they self‑invalidate when code changes.
- **Modes:** `llm` (default) · `deterministic` (no LLM) · `off` (walk everything).
- **Report:** `GET …/hierwalk/relevance-report?format=json|md` — every file the
  walk **stopped** at, why, and which routine called into it.

Validated on 10‑ and 20‑file plastic sets: all genuinely‑core files kept, 0 false
prunes. (The 3000→200 trim is the client‑KB case, not reproducible in‑repo.)

---

## 2. Variable map (two passes)

Identifies a process's important variables, what happens to them, and classifies
them. See `../docs/VARIABLE_FINDING_APPROACH.md` for the full method.

- **Pass 1 — extract (per kept file, on demand).** From real source: business
  name, raw identifier, io‑direction, what happens, importance, **components**
  (sub‑values a record/area packs), **decisions_driven**. **Anchored** — a
  variable is dropped unless its raw identifier actually appears in the source
  (no hallucinations).
- **Aggregate (deterministic).** Merge across files → read/write files, fan‑in,
  components, decision_count, alias forms, evidence.
- **Pass 2 — classify (whole process).** Multi‑label **input / output /
  key_business**, with tightened definitions + deterministic guards (a produced
  result/flag can't be `input`; granular flags aren't `key_business`).
- **Score (deterministic, 0–100).**
  - **`packing_score`** + `rich/moderate/atomic` — *how much a variable carries &
    drives* (components + decisions + aliases + reach).
  - **`process_importance`** + **`importance_rank`** — *how important to the
    end‑to‑end process*; business‑led (role dominates, internal/plumbing capped).
  - one‑line **`why_important`** (LLM) for the top‑ranked variables.

**Output** — `data/processes/<p>/variables.json` (and the API): leads with a
ranked **`top_variables`** block, plus `by_class`, `by_packing`, and full
per‑variable detail. Cached in `hier_variable`.

Validated on the 20‑file plastic set: 222 vars, all anchored; top = Card Security
Code, Transaction Return Code (the decision), Fraud Indicator, referral flag,
expiry, amount — the true business headline.

---

## 3. How to run (one shot)

```
# Build everything for a process — substrate + cards + variable map
POST /demo/v1/projects/default/processes/<p>/hierwalk/batch?variables=true&workers=8
# poll
GET  /demo/v1/projects/default/processes/<p>/hierwalk/batch/status/<task_id>
```

Batch flags (full contract in `HIERWALK_BATCH_API.md`):

| Flag | Effect |
|------|--------|
| `relevance=llm\|deterministic\|off` | the util‑stop mode |
| `full=true` | shorthand for `relevance=off` (walk everything) |
| `variables=true` | also build the variable map + `variables.json` |
| `restart=true` | regenerate from scratch |

Other endpoints: `POST …/hierwalk/build` (sync single build, same `full`/`relevance`),
`GET …/hierwalk/relevance-report`, `POST …/hierwalk/variables/build`,
`GET …/hierwalk/variables?class=input|output|key_business`.

---

## Where things live

| Code | Purpose |
|------|---------|
| `backend/hierwalk/builder.py` | deterministic call substrate + relevance gate wiring |
| `backend/hierwalk/relevance.py` | the relevance gate + relevance report |
| `backend/hierwalk/variables.py` | two‑pass variable map (extract → aggregate → classify → score) |
| `backend/hierwalk/subprocess.py` | business‑activity decomposition (the visible cards) |
| `backend/hierwalk/store.py` | SQLite cache (nodes, relevance, variables) |
| `backend/routes/hierwalk.py` | all hierwalk endpoints |
| `scripts/validate_varmap.py` | correctness checks for the variable map |

| Tables (in `backend/knowledge.db`) | Holds |
|------|-------|
| `hier_walk_node` / `hier_subprocess` / `hier_walk_meta` | the walk + business cards |
| `hier_file_relevance` / `hier_process_profile` | relevance "memory" + process profile |
| `hier_variable` | the variable map (incl. packing/importance in `extras_json`) |

---

## Caveats

- The DB (`knowledge.db`), `variables.json`, and the input corpus
  (`temp/output_latest/asm/`, `temp/plastic_files/`) are **gitignored** — a clone
  has the code but regenerates the data and needs the corpus + `GEMINI_API_KEY`
  shared out of band.
- Scale (3000→200) is proven on mechanics, not at client scale (no infra‑heavy KB
  in‑repo).
- Re‑scoring/re‑ranking variables is deterministic — tuning costs no LLM calls
  (only `why_important` does).
