"""Thorough correctness validation of the hierwalk variable map.

Run: PYTHONPATH=$(pwd) python3 tmp/validate_varmap.py <process>

Checks, per variable:
  1. ANCHOR: every raw_identifier actually occurs in the source of the files
     listed in its evidence (no hallucinated variables).
  2. IO CONSISTENCY: read_files ∪ write_files ⊆ files in evidence; io_direction
     matches the read/write file sets.
  3. CLASSIFICATION SANITY: labels ⊆ {input,output,key_business}; an 'input'
     should have reads; an 'output' should have writes (warn if not).
  4. NO DUPES: var_id unique; business names not trivially duplicated.
  5. JSON: variables.json exists, parses, matches the DB count.
Prints a PASS/FAIL summary + the full classified listing for human eyeballing.
"""
import json, re, sys
from pathlib import Path

from process_analysis.backend.hierwalk import store, source as src, paths

NORM = re.compile(r"[^a-z0-9]+")
def norm(s): return NORM.sub("", (s or "").lower())

proc = sys.argv[1] if len(sys.argv) > 1 else "plastic_authentication_full"
vs = store.all_variables(proc)
print(f"=== validating {proc}: {len(vs)} variables ===\n")

# cache file source (normalised) per file
_srccache = {}
def file_norm_src(f):
    if f not in _srccache:
        _srccache[f] = norm(src.file_source_head(f, 100000))
    return _srccache[f]

anchor_fail, io_fail, cls_fail, warns = [], [], [], []
seen_ids = set()
for v in vs:
    vid = v["var_id"]
    if vid in seen_ids: cls_fail.append(f"DUP var_id {vid}")
    seen_ids.add(vid)
    ev_files = {e["file"] for e in (v.get("evidence") or [])}

    # 1. anchor: each raw id appears in at least one evidence file's source
    for raw in v.get("raw_identifiers") or []:
        if not any(norm(raw) in file_norm_src(f) for f in ev_files):
            anchor_fail.append(f"{vid}: raw '{raw}' not found in evidence sources {[Path(f).name for f in ev_files]}")

    # 2. io consistency
    rw = set(v.get("read_files") or []) | set(v.get("write_files") or [])
    if not rw <= ev_files:
        io_fail.append(f"{vid}: read/write files not subset of evidence files")
    io = v.get("io_direction")
    has_r, has_w = bool(v.get("read_files")), bool(v.get("write_files"))
    expect = "read_write" if has_r and has_w else ("written" if has_w else "read")
    if io != expect:
        io_fail.append(f"{vid}: io_direction={io} but reads={has_r} writes={has_w} (expect {expect})")

    # 3. classification sanity
    labels = v.get("classification") or []
    for l in labels:
        if l not in ("input", "output", "key_business"):
            cls_fail.append(f"{vid}: bad label {l}")
    if "input" in labels and not has_r:
        warns.append(f"{vid}: labelled input but no read_files")
    if "output" in labels and not has_w:
        warns.append(f"{vid}: labelled output but no write_files")

# 6. packing/importance fields present + sane
score_fail = []
ranks = []
for v in vs:
    pi = v.get("process_importance"); ps = v.get("packing_score")
    if not isinstance(pi, int) or not (0 <= pi <= 100):
        score_fail.append(f"{v['var_id']}: bad process_importance {pi}")
    if not isinstance(ps, int) or not (0 <= ps <= 100):
        score_fail.append(f"{v['var_id']}: bad packing_score {ps}")
    if v.get("packing") not in ("rich", "moderate", "atomic"):
        score_fail.append(f"{v['var_id']}: bad packing {v.get('packing')}")
    ranks.append(v.get("importance_rank"))
if sorted(r for r in ranks if r) != list(range(1, len(vs) + 1)):
    score_fail.append("importance_rank is not a 1..N permutation")

# 5. json file
jpath = paths.file_graph_path(proc).parent / "variables.json"
json_ok = jpath.exists()
top_ok = False
if json_ok:
    jd = json.loads(jpath.read_text())
    json_ok = len(jd.get("variables") or []) == len(vs)
    tv = jd.get("top_variables") or []
    top_ok = bool(tv) and tv[0].get("rank") == 1 and "why_important" in tv[0]

def show(title, items):
    print(f"[{'PASS' if not items else 'FAIL'}] {title}: {len(items)} issue(s)")
    for i in items[:12]:
        print("     -", i)

show("anchor (no hallucinated vars)", anchor_fail)
show("io-direction consistency", io_fail)
show("classification labels valid", cls_fail)
show("packing/importance scores sane (0-100, rank perm)", score_fail)
print(f"[{'PASS' if json_ok else 'FAIL'}] variables.json exists & count matches DB")
print(f"[{'PASS' if top_ok else 'FAIL'}] top_variables present, ranked, with why_important")
print(f"[WARN] {len(warns)} soft warnings")
for w in warns[:12]: print("     -", w)

print("\n=== TOP 15 by process_importance ===")
for v in sorted(vs, key=lambda x: x.get('importance_rank') or 1e9)[:15]:
    cls = ",".join(v.get("classification") or []) or "-"
    print(f"  #{v.get('importance_rank'):<2} imp{v.get('process_importance'):>3} "
          f"pack:{(v.get('packing') or '?')[:4]:4}({v.get('packing_score')}) "
          f"comp{v.get('component_count') or 0} dec{v.get('decision_count') or 0} "
          f"[{cls}] {v['business_name']}")

print("\n=== full classified listing ===")
by = {"input": [], "output": [], "key_business": [], "(unlabelled)": []}
for v in vs:
    ls = v.get("classification") or ["(unlabelled)"]
    for l in ls: by.setdefault(l, []).append(v["business_name"])
for k in ("input", "output", "key_business", "(unlabelled)"):
    print(f"\n## {k} ({len(by.get(k,[]))})")
    for n in by.get(k, []): print("   -", n)
