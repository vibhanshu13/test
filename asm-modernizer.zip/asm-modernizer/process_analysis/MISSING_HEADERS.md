# Missing C++ headers (temp/asm corpus)

Headers `#include`d anywhere in the corpus but **not present** in `temp/asm/`. Missing types here cause Clang to truncate function CFGs at the first unresolved-type construct (`switch`/etc.), hiding downstream calls, guards, and routes from the engine.

- **395** distinct missing headers total
- **320** "core" headers (excludes the 75-file `cr21aeXX.hpp` auto-generated family — bring `cr21ae.hpp` + that family together)
- Std/SDK headers (ctype.h, math.h, stdio.h, stdlib.h, string.h, time.h) are excluded — the toolchain SDK provides them.
- **Iterate:** these are the headers visible *now*. Once added, re-run the scan — the newly-added headers may reference a next wave.

## Priority handoff list — 65 unique (softCardValue 51 + high-impact 17, deduped)

The two priority sets merged and de-duplicated (overlap: `isocm.hpp`, `amxdecim.hpp`, `assdec.hpp`). Ordered by whole-codebase reach (files that `#include` it). `softCardValue` = needed to fully trace softCardValue setters/paths; `high-impact` = unblocks the most files corpus-wide. **`casind.hpp` + `cashref.hpp` are the critical pair** that un-truncate `dw710000::processACreditTransaction`'s hidden gate-3 path.

| # | header | files referencing | scope |
|---:|:---|---:|:---|
| 1 | `isocm.hpp` | 22 | softCardValue + high-impact |
| 2 | `casinq.hpp` | 20 | high-impact |
| 3 | `dateapi.hpp` | 19 | high-impact |
| 4 | `amxdecim.hpp` | 17 | softCardValue + high-impact |
| 5 | `assdec.hpp` | 16 | softCardValue + high-impact |
| 6 | `paydbapi.hpp` | 15 | high-impact |
| 7 | `payach.hpp` | 13 | high-impact |
| 8 | `cclb5b5.hpp` | 10 | high-impact |
| 9 | `ccpvawk.hpp` | 10 | high-impact |
| 10 | `ccpvcac.hpp` | 10 | high-impact |
| 11 | `gnsioapi.hpp` | 10 | high-impact |
| 12 | `p111api.hpp` | 10 | high-impact |
| 13 | `ccaindb.hpp` | 9 | high-impact |
| 14 | `ccl4t4t.hpp` | 9 | high-impact |
| 15 | `linkmsgp.hpp` | 9 | high-impact |
| 16 | `sedbutil.hpp` | 9 | high-impact |
| 17 | `bigend_t.hpp` | 8 | high-impact |
| 18 | `ccln6n6.hpp` | 8 | softCardValue |
| 19 | `idecimal.hpp` | 8 | softCardValue |
| 20 | `ccl7z7z.hpp` | 6 | softCardValue |
| 21 | `casind.hpp` | 5 | softCardValue |
| 22 | `ccl6k6k.hpp` | 5 | softCardValue |
| 23 | `paprep.hpp` | 5 | softCardValue |
| 24 | `amexse.hpp` | 4 | softCardValue |
| 25 | `cclwrpa.hpp` | 4 | softCardValue |
| 26 | `txnsourc.hpp` | 4 | softCardValue |
| 27 | `cccr41ae.hpp` | 3 | softCardValue |
| 28 | `cclwroe.hpp` | 3 | softCardValue |
| 29 | `cclwrpv.hpp` | 3 | softCardValue |
| 30 | `airdata.hpp` | 2 | softCardValue |
| 31 | `casres.hpp` | 2 | softCardValue |
| 32 | `cccr21oe.hpp` | 2 | softCardValue |
| 33 | `cclwrgl.hpp` | 2 | softCardValue |
| 34 | `glsupp.hpp` | 2 | softCardValue |
| 35 | `lrechdr.hpp` | 2 | softCardValue |
| 36 | `authrel.hpp` | 1 | softCardValue |
| 37 | `cashref.hpp` | 1 | softCardValue |
| 38 | `casresa.hpp` | 1 | softCardValue |
| 39 | `ccciditm.hpp` | 1 | softCardValue |
| 40 | `cccr54ae.hpp` | 1 | softCardValue |
| 41 | `cccriiae.hpp` | 1 | softCardValue |
| 42 | `ccl1t1t.hpp` | 1 | softCardValue |
| 43 | `ccll1l1.hpp` | 1 | softCardValue |
| 44 | `cclvwvw.hpp` | 1 | softCardValue |
| 45 | `cclw9w9.hpp` | 1 | softCardValue |
| 46 | `cclwmas.hpp` | 1 | softCardValue |
| 47 | `cclwra0.hpp` | 1 | softCardValue |
| 48 | `cclwra3.hpp` | 1 | softCardValue |
| 49 | `cclwra4.hpp` | 1 | softCardValue |
| 50 | `cclwra5.hpp` | 1 | softCardValue |
| 51 | `cclwrad.hpp` | 1 | softCardValue |
| 52 | `cclwrav.hpp` | 1 | softCardValue |
| 53 | `cclwrba.hpp` | 1 | softCardValue |
| 54 | `cclwrcn.hpp` | 1 | softCardValue |
| 55 | `cclwreg.hpp` | 1 | softCardValue |
| 56 | `cclwrem.hpp` | 1 | softCardValue |
| 57 | `cclwrg1.hpp` | 1 | softCardValue |
| 58 | `cclwrg5.hpp` | 1 | softCardValue |
| 59 | `cclwrip.hpp` | 1 | softCardValue |
| 60 | `cclwrrd.hpp` | 1 | softCardValue |
| 61 | `cclwrsh.hpp` | 1 | softCardValue |
| 62 | `cclwrts.hpp` | 1 | softCardValue |
| 63 | `cclwrwa.hpp` | 1 | softCardValue |
| 64 | `cclwrwc.hpp` | 1 | softCardValue |
| 65 | `termidhd.hpp` | 1 | softCardValue |

## Top impact (most source files unblocked)

| files | header |
|---:|:---|
| 60 | `tpfapi.h` |
| 52 | `tpfglbl.h` |
| 39 | `tpfregs.h` |
| 22 | `c_eb0eb.h` |
| 22 | `isocm.hpp` |
| 21 | `cdf.h` |
| 20 | `casinq.hpp` |
| 19 | `dateapi.hpp` |
| 17 | `amxdecim.hpp` |
| 17 | `c_globz.h` |
| 17 | `tpfio.h` |
| 16 | `assdec.hpp` |
| 15 | `c_stck.h` |
| 15 | `paydbapi.hpp` |
| 15 | `tpfeq.h` |
| 14 | `sysapi.h` |
| 13 | `payach.hpp` |
| 10 | `c_decb.h` |
| 10 | `cclb5b5.hpp` |
| 10 | `ccpvawk.hpp` |
| 10 | `ccpvcac.hpp` |
| 10 | `gnsioapi.hpp` |
| 10 | `p111api.hpp` |
| 10 | `types.h` |
| 9 | `c_cdfapi.h` |
| 9 | `ccaindb.hpp` |
| 9 | `ccl4t4t.hpp` |
| 9 | `linkmsgp.hpp` |
| 9 | `sedbutil.hpp` |
| 8 | `bigend_t.hpp` |

## z/TPF system headers (.h) — 21

`a2e.h`, `c_cdfapi.h`, `c_decb.h`, `c_eb0eb.h`, `c_globz.h`, `c_mi0mi.h`, `c_node.h`, `c_stck.h`, `c_stdhd.h`, `cdev.h`, `cdf.h`, `cmpswp.h`, `sysapi.h`, `sysdef.h`, `syslog.h`, `tpfapi.h`, `tpfeq.h`, `tpfglbl.h`, `tpfio.h`, `tpfregs.h`, `types.h`

## Domain headers (.hpp) — 299

`aavdbapi.hpp`, `acumac.hpp`, `adecimal.hpp`, `airdata.hpp`, `al21api.hpp`, `amapi.hpp`, `amexse.hpp`, `amxdecim.hpp`, `ar41api.hpp`, `ar41hdr.hpp`, `as48api.hpp`, `assdec.hpp`, `authrel.hpp`, `authsanc.hpp`, `autores.hpp`, `axlogc.hpp`, `bigend_t.hpp`, `bp28hdr.hpp`, `c111api.hpp`, `cas91api.hpp`, `cashapi.hpp`, `cashref.hpp`, `casind.hpp`, `casinq.hpp`, `casmaint.hpp`, `casres.hpp`, `casresa.hpp`, `ccaceapi.hpp`, `ccaddbm.hpp`, `ccaindb.hpp`, `ccainio.hpp`, `ccask.hpp`, `ccbmcapi.hpp`, `ccbr61ae.hpp`, `ccbr65ae.hpp`, `ccciditm.hpp`, `cccr0r0.hpp`, `cccr21oe.hpp`, `cccr26ae.hpp`, `cccr27ae.hpp`, `cccr28ae.hpp`, `cccr2cae.hpp`, `cccr41ae.hpp`, `cccr54ae.hpp`, `cccr81ae.hpp`, `cccr86ae.hpp`, `cccracae.hpp`, `cccrcnae.hpp`, `cccre0ae.hpp`, `cccriiae.hpp`, `cccrj2ae.hpp`, `cccrnmae.hpp`, `ccdatwk.hpp`, `ccdname.hpp`, `ccdnvar.hpp`, `ccdr40ae.hpp`, `cceadata.hpp`, `cceapdm.hpp`, `ccebapp.hpp`, `cceloga.hpp`, `ccfirapi.hpp`, `ccfobio.hpp`, `ccfr17ae.hpp`, `ccfrrdae.hpp`, `cchubg2.hpp`, `cchubgl.hpp`, `cciscfa.hpp`, `cckeydb.hpp`, `ccl0000.hpp`, `ccl0atb.hpp`, `ccl0k0k.hpp`, `ccl1t1t.hpp`, `ccl3d3d.hpp`, `ccl3t3t.hpp`, `ccl4t4t.hpp`, `ccl5l5l.hpp`, `ccl5z5z.hpp`, `ccl6a6a.hpp`, `ccl6c6c.hpp`, `ccl6k6k.hpp`, `ccl6y6y.hpp`, `ccl7a7a.hpp`, `ccl7kng.hpp`, `ccl7kqq.hpp`, `ccl7p7p.hpp`, `ccl7z7z.hpp`, `ccl8u8u.hpp`, `ccl8y8y.hpp`, `cclaoao.hpp`, `cclb5b5.hpp`, `ccldfdf.hpp`, `ccldydy.hpp`, `ccle2e2.hpp`, `ccle3e3.hpp`, `ccle8e8.hpp`, `ccleeee.hpp`, `ccli1i1.hpp`, `ccli4i4.hpp`, `ccliaia.hpp`, `cclikik.hpp`, `cclj1j1.hpp`, `cclj2j2.hpp`, `ccll1l1.hpp`, `ccll9l9.hpp`, `ccln6n6.hpp`, `cclococ.hpp`, `cclofof.hpp`, `cclplpl.hpp`, `cclpmpm.hpp`, `cclqqtbl.hpp`, `cclspsp.hpp`, `cclt4t4.hpp`, `cclvwvw.hpp`, `cclvyvy.hpp`, `cclvzvz.hpp`, `cclw9w9.hpp`, `cclwmas.hpp`, `cclwra0.hpp`, `cclwra3.hpp`, `cclwra4.hpp`, `cclwra5.hpp`, `cclwrad.hpp`, `cclwrau.hpp`, `cclwrav.hpp`, `cclwraw.hpp`, `cclwrba.hpp`, `cclwrcn.hpp`, `cclwrcz.hpp`, `cclwrdl.hpp`, `cclwrdw.hpp`, `cclwreg.hpp`, `cclwrem.hpp`, `cclwrf3.hpp`, `cclwrg1.hpp`, `cclwrg5.hpp`, `cclwrga.hpp`, `cclwrgl.hpp`, `cclwrgm.hpp`, `cclwrip.hpp`, `cclwrle.hpp`, `cclwrnd.hpp`, `cclwrng.hpp`, `cclwrnm.hpp`, `cclwroe.hpp`, `cclwrpa.hpp`, `cclwrpq.hpp`, `cclwrpv.hpp`, `cclwrrd.hpp`, `cclwrrf.hpp`, `cclwrse.hpp`, `cclwrsh.hpp`, `cclwrts.hpp`, `cclwrvp.hpp`, `cclwrwa.hpp`, `cclwrwc.hpp`, `cclwwww.hpp`, `cclx1x1.hpp`, `cclx3x3.hpp`, `cclxwxw.hpp`, `ccly3y3.hpp`, `cclyfyf.hpp`, `cclygyg.hpp`, `cclyyyy.hpp`, `cclzrzr.hpp`, `ccmqdll.hpp`, `ccnm0tr.hpp`, `ccnmgns.hpp`, `ccondot.hpp`, `ccor6hae.hpp`, `ccor6iae.hpp`, `ccpb0pb.hpp`, `ccpvawk.hpp`, `ccpvcac.hpp`, `ccregna.hpp`, `ccsvarapi.hpp`, `ccsvpapi.hpp`, `ccta4a4.hpp`, `cctk0db.hpp`, `cctmshdr.hpp`, `cctprpr.hpp`, `ccwctwk.hpp`, `ccyk2k2.hpp`, `ccyy5y5.hpp`, `cdf.hpp`, `chiputil.hpp`, `ciumchdr.hpp`, `clciapi.hpp`, `cmseapi.hpp`, `commreq.hpp`, `convert.hpp`, `corecarv.hpp`, `corpvar.hpp`, `cr41ae50.hpp`, `cscapi.hpp`, `currency.hpp`, `dacapi.hpp`, `dateapi.hpp`, `ds72dec.hpp`, `ds72int.hpp`, `dw70int.hpp`, `ealmmn.hpp`, `eap.hpp`, `ebcdic_t.hpp`, `ecapi.hpp`, `emdbapi.hpp`, `enrolapi.hpp`, `expcrypt.hpp`, `faser.hpp`, `faxmlapi.hpp`, `fimapi.hpp`, `fobproc.hpp`, `gbm_uav.hpp`, `gcdglxx.hpp`, `getrca.hpp`, `glenums.hpp`, `glfunctn.hpp`, `glsupp.hpp`, `gn04hdr.hpp`, `gnsdapi.hpp`, `gnsioapi.hpp`, `gnsmapi.hpp`, `idecimal.hpp`, `ikyapi.hpp`, `inmaiapi.hpp`, `isocm.hpp`, `isocmdbapi.hpp`, `js01hdr.hpp`, `keydbase.hpp`, `kmhapi.hpp`, `l7z7z.hpp`, `linkmsgp.hpp`, `linksapi.hpp`, `lm1api.hpp`, `lmpdtlg.hpp`, `lrechdr.hpp`, `lwray.hpp`, `lwrcc.hpp`, `lwrcv.hpp`, `lwrcz.hpp`, `lwrga.hpp`, `lwrip.hpp`, `lwrle.hpp`, `lwrne.hpp`, `lwrp1.hpp`, `lwrpi.hpp`, `lwrrf.hpp`, `lwrs5.hpp`, `lwrs6.hpp`, `lwrs7.hpp`, `lwrs8.hpp`, `lwrsp.hpp`, `lwrtg.hpp`, `lwrvc.hpp`, `maintsup.hpp`, `mcdbapi.hpp`, `mldbapi.hpp`, `ngstgapi.hpp`, `ngstrapi.hpp`, `nm00hdr.hpp`, `ns51hdr.hpp`, `ns52hdr.hpp`, `num_ebcdic_t.hpp`, `oneecurr.hpp`, `oneemisc.hpp`, `oneesvc1.hpp`, `oneexapi.hpp`, `oneexinq.hpp`, `oneexint.hpp`, `otblapi.hpp`, `ovrmaint.hpp`, `p111api.hpp`, `pa_counters.hpp`, `pacidio.hpp`, `packed_t.hpp`, `paprep.hpp`, `parseair.hpp`, `payach.hpp`, `payc219.hpp`, `paydbapi.hpp`, `payvrapi.hpp`, `pininf.hpp`, `rantdac.hpp`, `rdmapi.hpp`, `rg03paya.hpp`, `rg03pymt.hpp`, `rg03rtrn.hpp`, `rg71misc.hpp`, `rx71hdr.hpp`, `sedbutil.hpp`, `spdelapi.hpp`, `stcdsapi.hpp`, `stdio.hpp`, `suppapi.hpp`, `termidhd.hpp`, `tpfcvglb.hpp`, `trkapi.hpp`, `txnsourc.hpp`, `ubpayapi.hpp`, `xmldata.hpp`

## `cr21aeXX.hpp` auto-generated family — 75

All included only by `cr21ae.hpp` (segment/overlay variants). Bring as a set:

`cr21ae50.hpp`, `cr21ae55.hpp`, `cr21ae57.hpp`, `cr21ae58.hpp`, `cr21ae5a.hpp`, `cr21ae5c.hpp`, `cr21ae5e.hpp`, `cr21ae5f.hpp`, `cr21ae60.hpp`, `cr21ae61.hpp`, `cr21ae62.hpp`, `cr21ae63.hpp`, `cr21ae65.hpp`, `cr21ae66.hpp`, `cr21ae68.hpp`, `cr21ae6b.hpp`, `cr21ae6d.hpp`, `cr21ae6f.hpp`, `cr21ae70.hpp`, `cr21ae71.hpp`, `cr21ae72.hpp`, `cr21ae75.hpp`, `cr21ae76.hpp`, `cr21ae77.hpp`, `cr21ae78.hpp`, `cr21ae79.hpp`, `cr21ae7a.hpp`, `cr21ae7b.hpp`, `cr21ae7d.hpp`, `cr21ae7e.hpp`, `cr21ae80.hpp`, `cr21ae84.hpp`, `cr21ae85.hpp`, `cr21ae86.hpp`, `cr21ae90.hpp`, `cr21ae91.hpp`, `cr21ae92.hpp`, `cr21ae93.hpp`, `cr21ae94.hpp`, `cr21ae95.hpp`, `cr21ae96.hpp`, `cr21ae97.hpp`, `cr21aea0.hpp`, `cr21aea5.hpp`, `cr21aea6.hpp`, `cr21aea7.hpp`, `cr21aea8.hpp`, `cr21aea9.hpp`, `cr21aeaa.hpp`, `cr21aeab.hpp`, `cr21aeac.hpp`, `cr21aead.hpp`, `cr21aeae.hpp`, `cr21aeaf.hpp`, `cr21aeb0.hpp`, `cr21aeb3.hpp`, `cr21aeb6.hpp`, `cr21aeb8.hpp`, `cr21aeba.hpp`, `cr21aebc.hpp`, `cr21aebd.hpp`, `cr21aec0.hpp`, `cr21aec1.hpp`, `cr21aec5.hpp`, `cr21aec6.hpp`, `cr21aed0.hpp`, `cr21aed1.hpp`, `cr21aed5.hpp`, `cr21aed6.hpp`, `cr21aed9.hpp`, `cr21aee0.hpp`, `cr21aee5.hpp`, `cr21aee6.hpp`, `cr21aee7.hpp`, `cr21aee8.hpp`
