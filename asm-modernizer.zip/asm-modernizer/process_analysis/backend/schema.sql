-- explanability_demo SQLite schema (DESIGN.md §11)
-- Idempotent: every CREATE uses IF NOT EXISTS.

-- Projects table — top-level namespace for all data.
CREATE TABLE IF NOT EXISTS project (
    id          TEXT PRIMARY KEY,
    name        TEXT,
    description TEXT,
    created_at  TEXT NOT NULL
);

-- ─── Core pipeline tables (existing, enriched) ─────────────────────────────

CREATE TABLE IF NOT EXISTS process (
    project_id               TEXT NOT NULL DEFAULT 'default',
    name                     TEXT NOT NULL,
    title                    TEXT,
    description              TEXT,
    icon                     TEXT,
    file_count               INTEGER,
    edge_count               INTEGER,
    summary_short            TEXT,
    summary_long             TEXT,
    key_steps_json           TEXT,
    key_variables_top10_json TEXT,
    build_phase              TEXT,           -- idle / blocks / files / process / done / failed
    build_blocks_done        INTEGER DEFAULT 0,
    build_blocks_total       INTEGER DEFAULT 0,
    template_version         TEXT,
    content_hash             TEXT,
    updated_at               TEXT,
    PRIMARY KEY (project_id, name)
);

CREATE TABLE IF NOT EXISTS file (
    project_id               TEXT NOT NULL DEFAULT 'default',
    process                  TEXT NOT NULL,
    path                     TEXT NOT NULL,
    kind                     TEXT,               -- asm | cpp | mac | hpp
    purpose                  TEXT,
    narrative                TEXT,
    key_variables_json       TEXT,
    key_callees_json         TEXT,
    -- Phase 2 enrichments (deterministic from Phase 1)
    touches_persistence      INTEGER DEFAULT 0,  -- any io_site row in this file
    touches_storage_lifecycle INTEGER DEFAULT 0,
    is_callc_bridge          INTEGER DEFAULT 0,  -- file contains CALLC or CPROC declaration
    content_hash             TEXT,
    template_version         TEXT,
    PRIMARY KEY (project_id, process, path)
);

CREATE TABLE IF NOT EXISTS block (
    project_id               TEXT NOT NULL DEFAULT 'default',
    process                  TEXT NOT NULL,
    file_path                TEXT NOT NULL,
    block_id                 TEXT NOT NULL,
    kind                     TEXT,             -- asm_block | cpp_function
    line_start               INTEGER,
    line_end                 INTEGER,
    purpose                  TEXT,
    behavior                 TEXT,
    calls_json               TEXT,             -- [{target, reason_business_language}]
    variables_touched_json   TEXT,             -- [{name, role, purpose}]
    -- Phase 2 enrichments (deterministic from Phase 1)
    touches_persistence      INTEGER DEFAULT 0,
    touches_storage_lifecycle INTEGER DEFAULT 0,
    inside_commit_scope      INTEGER,          -- commit_scope_id or NULL
    incoming_guards_json     TEXT,             -- [guard_id, ...]
    outgoing_guards_json     TEXT,             -- [guard_id, ...]
    is_callc_bridge          INTEGER DEFAULT 0,
    content_hash             TEXT,
    template_version         TEXT,
    PRIMARY KEY (project_id, process, file_path, block_id)
);

CREATE TABLE IF NOT EXISTS variable (
    project_id         TEXT NOT NULL DEFAULT 'default',
    process            TEXT NOT NULL,
    name               TEXT NOT NULL,
    origin             TEXT,                 -- asm-runtime | cpp
    kind               TEXT,
    declaration_file   TEXT NOT NULL,
    declaration_line   INTEGER NOT NULL,
    data_type          TEXT,
    scope              TEXT,
    purpose            TEXT,
    PRIMARY KEY (project_id, process, name, declaration_file, declaration_line)
);

-- ─── FTS5 BM25 index (existing) ──────────────────────────────────────────────

CREATE VIRTUAL TABLE IF NOT EXISTS chunk_fts USING fts5(
    chunk_id,
    project_id,
    process,
    kind,
    file_path,
    block_id,
    context_prefix,
    body,
    tokenize = 'porter unicode61'
);

-- ─── Legacy tables (retained for backward compat) ────────────────────────────

CREATE TABLE IF NOT EXISTS investigation_message (
    project_id   TEXT NOT NULL DEFAULT 'default',
    flow_id      TEXT NOT NULL,
    iteration    INTEGER NOT NULL,
    direction    TEXT NOT NULL,             -- setter | usage
    variable     TEXT NOT NULL,
    process      TEXT NOT NULL,
    text         TEXT NOT NULL,
    sources_json TEXT,
    created_at   TEXT NOT NULL,
    PRIMARY KEY (flow_id, iteration)
);

CREATE TABLE IF NOT EXISTS conversation_message (
    project_id      TEXT NOT NULL DEFAULT 'default',
    conversation_id TEXT NOT NULL,
    idx             INTEGER NOT NULL,
    role            TEXT NOT NULL,          -- user | assistant
    text            TEXT NOT NULL,
    sources_json    TEXT,
    created_at      TEXT NOT NULL,
    PRIMARY KEY (conversation_id, idx)
);

-- ─── Phase 1 static foundation (new) ─────────────────────────────────────────

-- Call edges — one row per call edge.
CREATE TABLE IF NOT EXISTS call_edge (
    edge_id            TEXT PRIMARY KEY,
    process            TEXT NOT NULL,
    from_file          TEXT NOT NULL,
    from_block         TEXT,
    to_file            TEXT NOT NULL,
    to_block           TEXT,
    call_type          TEXT NOT NULL,        -- ENTRC / ENTNC / ENTDC / CREEC / CREMC / CREDC /
                                             -- CRETC / CREXC / CRESC / SWISC / FUNCTION / CALLC /
                                             -- CALL_ALIAS / CALL / INDIRECT / virtual_dispatch_cha /
                                             -- cpp-method / lambda / template-call /
                                             -- indirect-resolved / indirect-table-dispatch /
                                             -- indirect-llm-resolved / indirect-llm-low-confidence /
                                             -- indirect-unresolved
    source_line        INTEGER,
    source_language    TEXT NOT NULL,        -- asm | cpp
    target_language    TEXT NOT NULL,        -- asm | cpp
    is_cross_language  INTEGER NOT NULL DEFAULT 0,
    is_async           INTEGER NOT NULL DEFAULT 0,  -- true for CREEC/CREMC/CREDC/CREXC/CRETC
    is_suspend         INTEGER NOT NULL DEFAULT 0,  -- true for CRESC / system()
    indirection_json   TEXT,                 -- JSON from envelope_from_fields(); NULL for direct calls
    llm_rationale      TEXT                  -- for indirect-llm-resolved / indirect-llm-low-confidence
);
CREATE INDEX IF NOT EXISTS ix_call_edge_process ON call_edge(process, from_file);
CREATE INDEX IF NOT EXISTS ix_call_edge_target  ON call_edge(process, to_file, to_block);

-- Call edge guards — conditions on call edges.
CREATE TABLE IF NOT EXISTS call_edge_guard (
    guard_id         TEXT PRIMARY KEY,
    edge_id          TEXT NOT NULL,
    guard_kind       TEXT NOT NULL,         -- aif / cmp-branch / tm-branch / cpp-if / cpp-switch-case / etc.
    guard_expression TEXT,
    when_value       TEXT,                  -- true | false | case=X
    source_file      TEXT NOT NULL,
    source_line      INTEGER,
    condition_human  TEXT                   -- LLM-rendered business phrasing (post-Phase-3 pass)
);
CREATE INDEX IF NOT EXISTS ix_guard_edge ON call_edge_guard(edge_id);

-- I/O sites — hybrid detection (Layer 1/2/3).
CREATE TABLE IF NOT EXISTS io_site (
    io_id              TEXT PRIMARY KEY,
    process            TEXT NOT NULL,
    file               TEXT NOT NULL,
    block              TEXT NOT NULL,
    op_type            TEXT NOT NULL,        -- DBRED / DBWRT / DBADD / DBMOD / DBDEL / ...
    op_category        TEXT NOT NULL,        -- READ / WRITE / UPDATE / INSERT / DELETE /
                                             -- HOLD / KEY-STATE / OPEN / CLOSE / LOCK /
                                             -- FILE-READ / FILE-WRITE / FILE-READ-ALLOC / ...
    target_record      TEXT,
    target_ref         TEXT,                 -- REF= operand
    key_operand        TEXT,
    keys_active        TEXT,                 -- JSON snapshot of active DBKEY state
    hold_state         TEXT,                 -- HOLD / NOHOLD / DETAC / null
    prefetch           INTEGER DEFAULT 0,
    commit_scope_id    INTEGER,
    storage_alloc      TEXT,                 -- SW00WKA / GETCC-pointer / null
    source_line        INTEGER,
    source_language    TEXT NOT NULL,        -- asm | cpp
    detection_layer    TEXT NOT NULL,        -- L1-hard / L2-heuristic / L3-llm
    confidence         REAL NOT NULL DEFAULT 1.0,
    evidence           TEXT,                 -- JSON
    validated          INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_io_site_process ON io_site(process, file, block);
CREATE INDEX IF NOT EXISTS ix_io_site_record  ON io_site(process, target_record);

-- Variables involved in I/O sites.
CREATE TABLE IF NOT EXISTS io_site_variable (
    io_id         TEXT NOT NULL,
    variable_name TEXT NOT NULL,
    role          TEXT NOT NULL,            -- input | output | key
    PRIMARY KEY (io_id, variable_name, role)
);

-- DB subfile sessions — chains of io_site rows between DBOPN and DBCLS.
CREATE TABLE IF NOT EXISTS subfile_session (
    session_id     INTEGER PRIMARY KEY,
    process        TEXT NOT NULL,
    target_record  TEXT NOT NULL,
    target_ref     TEXT NOT NULL,
    open_io_id     TEXT NOT NULL,           -- DBOPN site
    close_io_id    TEXT,                    -- DBCLS site (NULL if unclosed)
    hold_state     TEXT,
    detac          INTEGER DEFAULT 0,
    prefetch       INTEGER DEFAULT 0,
    ops_count      INTEGER,
    commit_scope_id INTEGER
);

-- Storage lifecycle — GETCC/RELCC/DETAC/ATTAC and equivalents.
CREATE TABLE IF NOT EXISTS storage_lifecycle (
    event_id          TEXT PRIMARY KEY,
    process           TEXT NOT NULL,
    file              TEXT NOT NULL,
    block             TEXT NOT NULL,
    source_line       INTEGER,
    source_language   TEXT NOT NULL,
    op                TEXT NOT NULL,        -- GETCC / RELCC / GETFC / RELFC / RCRFC /
                                            -- DETAC / ATTAC / FINDC / FINHC / FINWC / FIWHC / FILEC
    level             TEXT,                 -- D0..DF or DECB
    size_class        TEXT,                 -- L0/L1/L2/L4
    pointer_register  TEXT,                 -- typically R14 after GETCC
    paired_event_id   TEXT                  -- matching release event, if found
);
CREATE INDEX IF NOT EXISTS ix_storage_lifecycle_process ON storage_lifecycle(process, file, block);

-- Commit scopes — TXBGC/TXCMC/TXRBC and equivalents.
CREATE TABLE IF NOT EXISTS commit_scope (
    scope_id        INTEGER PRIMARY KEY,
    process         TEXT NOT NULL,
    begin_file      TEXT NOT NULL,
    begin_block     TEXT NOT NULL,
    begin_line      INTEGER,
    end_file        TEXT,
    end_block       TEXT,
    end_line        INTEGER,
    end_kind        TEXT,                   -- commit | rollback | suspend | unclosed
    source_language TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_commit_scope_process ON commit_scope(process);

-- Variable aliases — cross-language, ECB, struct-field, register-bridge mappings.
CREATE TABLE IF NOT EXISTS variable_alias (
    process      TEXT NOT NULL,
    variable_a   TEXT NOT NULL,
    variable_b   TEXT NOT NULL,
    alias_kind   TEXT NOT NULL,             -- cpp-asm / ecb-field / struct-field /
                                            -- equivalent-5layer / register-bridge /
                                            -- getcc-pointer / dbifb-context
    PRIMARY KEY (process, variable_a, variable_b, alias_kind)
);

-- ECB field aliases.
CREATE TABLE IF NOT EXISTS ecb_alias (
    process    TEXT NOT NULL,
    ecb_field  TEXT NOT NULL,
    asm_name   TEXT,
    cpp_name   TEXT,
    offset     INTEGER,
    PRIMARY KEY (process, ecb_field)
);

-- ─── Utility detection (Phase 1c) ────────────────────────────────────────────

-- Block-level utility classifications (7-layer hybrid, §4.1.2).
CREATE TABLE IF NOT EXISTS block_utility_classification (
    process             TEXT NOT NULL,
    file                TEXT NOT NULL,
    block               TEXT NOT NULL,
    utility_confidence  REAL NOT NULL,
    detection_layer     TEXT NOT NULL,      -- L0 / L1 / L2 / L3 / L3.5-llm-utility /
                                            -- L3.5-llm-business / L4 / override
    signals_json        TEXT,
    llm_rationale       TEXT,
    l35_trigger         TEXT,               -- l2-ambiguous | io-site-safety-net | NULL
    content_hash        TEXT,
    PRIMARY KEY (process, file, block)
);

-- Cross-process call index for Layer 3 generic detection.
CREATE TABLE IF NOT EXISTS cross_process_call_index (
    callee_file    TEXT NOT NULL,
    callee_block   TEXT NOT NULL,
    caller_process TEXT NOT NULL,
    caller_file    TEXT NOT NULL,
    caller_block   TEXT NOT NULL,
    PRIMARY KEY (callee_file, callee_block, caller_process, caller_file, caller_block)
);
CREATE INDEX IF NOT EXISTS ix_xproc_callee ON cross_process_call_index(callee_file, callee_block);

-- ─── Phase 3 — Top-down walk ─────────────────────────────────────────────────

-- Walk nodes — one entry per node in the Phase 3 top-down walk.
CREATE TABLE IF NOT EXISTS walk_node (
    process              TEXT NOT NULL,
    walk_id              INTEGER NOT NULL,
    file                 TEXT NOT NULL,
    block                TEXT NOT NULL,
    parent_walk_id       INTEGER,
    status               TEXT NOT NULL,     -- process-entry / data-path / validation /
                                            -- data-transformation / persistence-read /
                                            -- persistence-write / error-handling /
                                            -- logging / infrastructure / skipped-utility /
                                            -- async-spawn / cross-language-bridge /
                                            -- scope-boundary / revisited-in-context-X
    block_tag            TEXT,              -- same as status, alias for Phase 4/5 references
    role_in_process      TEXT,
    inputs_consumed      TEXT,              -- JSON list of variable names
    outputs_produced     TEXT,              -- JSON list of variable names
    transformations      TEXT,              -- JSON list
    condition_to_reach   TEXT,              -- guard_id chain
    commit_scope_id      INTEGER,
    depth                INTEGER,
    content_hash         TEXT,
    PRIMARY KEY (process, walk_id)
);
CREATE INDEX IF NOT EXISTS ix_walk_node_file  ON walk_node(process, file, block);
CREATE INDEX IF NOT EXISTS ix_walk_node_status ON walk_node(process, status);

-- Walk truncation log — records when walk cap was hit.
CREATE TABLE IF NOT EXISTS walk_truncation (
    process          TEXT NOT NULL,
    truncation_kind  TEXT NOT NULL,         -- max-nodes | max-depth | cycle | indirect-unresolved
    walk_id          INTEGER,               -- walk node that was not expanded
    skipped_block_ids TEXT,                 -- JSON list
    reason           TEXT,
    created_at       TEXT NOT NULL,
    PRIMARY KEY (process, truncation_kind, walk_id)
);

-- ─── Phase 4 — Variable context ──────────────────────────────────────────────

-- Variable context — 1-level-up/down snapshot + 6-question LLM synthesis.
CREATE TABLE IF NOT EXISTS variable_context (
    process                   TEXT NOT NULL,
    name                      TEXT NOT NULL,
    declaration_file          TEXT NOT NULL,
    declaration_line          INTEGER NOT NULL,
    -- Step 1 anchor scan
    anchor_blocks_json        TEXT,  -- [{block_id, role, guards, io_ops, commit_scope, storage_lifecycle}]
    -- Step 2 (1 level down)
    down_contexts_json        TEXT,  -- [{edge_type, lang_pair, callee_file, callee_block,
                                     --   what_happens, conditions, io_ops, flows, checks, mandatory}]
    -- Step 3 (1 level up)
    up_contexts_json          TEXT,  -- [{edge_type, lang_pair, caller_file, caller_block,
                                     --   how_set, conditions_for_setting, mandatory,
                                     --   business_context, flow_context}]
    -- Step 4 LLM output — 6-question framework
    purpose                   TEXT,  -- Q1
    computation_source        TEXT,  -- Q2
    availability              TEXT,  -- Q3: always | conditional | entry-point-only | not-determined
    availability_condition    TEXT,  -- Q3
    persistence_effects_json  TEXT,  -- Q4: [{op, target, role, mandatory, depth}]
    flow_variations_json      TEXT,  -- Q5: [{condition, branch}]
    business_flow_context     TEXT,  -- Q6
    coverage_json             TEXT,  -- {q1..q6: full|partial|not_found}
    generated_at              TEXT,
    content_hash              TEXT,
    PRIMARY KEY (process, name, declaration_file, declaration_line)
);
CREATE INDEX IF NOT EXISTS ix_var_ctx_process ON variable_context(process, name);

-- Variable classification — multi-label (one row per label).
CREATE TABLE IF NOT EXISTS variable_classification (
    process       TEXT NOT NULL,
    variable      TEXT NOT NULL,
    label         TEXT NOT NULL,            -- business / process-io / persistence /
                                            -- control / infrastructure
    confidence    REAL,
    evidence_json TEXT,
    is_unused     INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (process, variable, label)
);

-- Variable meaning — derived from variable_context.purpose (no extra LLM call).
-- NOTE: populated by pipeline as: INSERT OR REPLACE FROM variable_context.purpose
CREATE TABLE IF NOT EXISTS variable_meaning (
    process      TEXT NOT NULL,
    variable     TEXT NOT NULL,
    meaning      TEXT NOT NULL,
    generated_at TEXT NOT NULL,
    PRIMARY KEY (process, variable)
);

-- ─── Phase 5 — Synthesis artifacts ──────────────────────────────────────────

-- Flow enumeration — one row per flow from entry to a producer node.
CREATE TABLE IF NOT EXISTS process_flow (
    flow_id        TEXT PRIMARY KEY,
    process        TEXT NOT NULL,
    output_kind    TEXT NOT NULL,           -- process-return / ecb-global / persistence-write /
                                            -- persistence-read / async / queue-message /
                                            -- scope-commit / storage-handoff / error
    output_target  TEXT,                    -- e.g. LM1M1 / WA1_STAT / queue-name
    output_io_id   TEXT,
    trigger_summary TEXT,                   -- LLM-generated business summary
    path_json      TEXT NOT NULL,           -- ordered list of walk_id + analysis
    guards_json    TEXT,
    commit_scope_id INTEGER,
    truncated      INTEGER NOT NULL DEFAULT 0,
    content_hash   TEXT
);
CREATE INDEX IF NOT EXISTS ix_process_flow_process ON process_flow(process);

-- Per-commit-scope narrative and key variables (Phase 5, artifact #6).
CREATE TABLE IF NOT EXISTS commit_scope_narrative (
    process            TEXT NOT NULL,
    scope_id           INTEGER NOT NULL,
    narrative          TEXT NOT NULL,       -- LLM-generated business narrative
    key_variables_json TEXT NOT NULL,       -- [{name, role, significance}] ranked
    generated_at       TEXT NOT NULL,
    content_hash       TEXT NOT NULL,
    PRIMARY KEY (process, scope_id)
);

-- Process-level synthesised artifacts — input-spec, output-spec, persistence-summary, etc.
CREATE TABLE IF NOT EXISTS process_artifact (
    process       TEXT NOT NULL,
    artifact_kind TEXT NOT NULL,            -- input-spec / output-spec / persistence-summary /
                                            -- commit-scope-summary / narrative-executive-summary /
                                            -- narrative-e2e-flows / narrative-variable-landscape /
                                            -- narrative-persistence-footprint / complexity_metrics /
                                            -- gemini_cache
    payload_json  TEXT NOT NULL,
    generated_at  TEXT NOT NULL,
    content_hash  TEXT,
    PRIMARY KEY (process, artifact_kind)
);

-- Payload lineage chains (Phase 5, artifact #8).
CREATE TABLE IF NOT EXISTS payload_lineage (
    process              TEXT NOT NULL,
    lineage_id           TEXT PRIMARY KEY,  -- e.g. C400::WA1_DATE::F1
    root_variable        TEXT NOT NULL,
    flow_id              TEXT NOT NULL,
    steps_json           TEXT NOT NULL,     -- [{step_num, file, block, role, vars_in, vars_out, summary}]
    terminal_kind        TEXT NOT NULL,     -- persistence-write / process-return / async-spawn / ecb-write
    terminal_target      TEXT,
    terminal_io_site_id  TEXT,
    content_hash         TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_payload_lineage_root ON payload_lineage(process, root_variable);
CREATE INDEX IF NOT EXISTS ix_payload_lineage_flow ON payload_lineage(process, flow_id);

-- Process walkthrough cards — card-paginated business-language description (§4.5.3).
CREATE TABLE IF NOT EXISTS process_narrative_card (
    process                    TEXT NOT NULL,
    card_id                    TEXT NOT NULL,          -- e.g. C400::card-007
    ordinal                    INTEGER NOT NULL,        -- 0-based linear order
    section                    TEXT NOT NULL,           -- opening|setup|main|branch|persistence|async|cleanup|closing
    section_ordinal            INTEGER NOT NULL,        -- 0-based within section
    title                      TEXT NOT NULL,
    body                       TEXT NOT NULL,
    bridge_to_next             TEXT,
    key_variables_json         TEXT,                   -- [{business_name, why_it_matters}]
    conditions_json            TEXT,                   -- [{condition, outcomes}]
    io_events_json             TEXT,                   -- [{what_happens, business_target, why, transaction_context}]
    visualization_payload_json TEXT NOT NULL,          -- {focus_blocks, focus_edges, focus_variables, focus_io_events, neighbour_hint}
    source_block_ids_json      TEXT NOT NULL,          -- audit: which walk_node rows this card covers
    untranslated_tokens_json   TEXT,                   -- audit: tokens that fell through to filler phrases
    -- §4.5.3 hard constraint #3: each card self-contained
    previous_card_title        TEXT,                   -- title of card N-1 (denormalised; "" for first card)
    next_card_title            TEXT,                   -- title of card N+1 (denormalised; "" for last card)
    next_segment_hint          TEXT,                   -- Stage 1 deterministic hint for what comes next
    guards_summary_json        TEXT,                   -- list of {condition_human, when_value} for guards in segment
    role_summary               TEXT,                   -- deterministic role-mix summary of segment
    total_cards                INTEGER NOT NULL,
    total_sections             INTEGER NOT NULL,
    generated_at               TEXT NOT NULL,
    content_hash               TEXT NOT NULL,
    PRIMARY KEY (process, card_id)
);
CREATE INDEX IF NOT EXISTS ix_narrative_card_ord     ON process_narrative_card(process, ordinal);
CREATE INDEX IF NOT EXISTS ix_narrative_card_section ON process_narrative_card(process, section, section_ordinal);

-- Business names for files, blocks, and DB records (Phase 2).
CREATE TABLE IF NOT EXISTS entity_business_name (
    process       TEXT NOT NULL,
    entity_type   TEXT NOT NULL,           -- file | block | record
    entity_id     TEXT NOT NULL,           -- file_path / file::block / target_record value
    business_name TEXT NOT NULL,
    content_hash  TEXT NOT NULL,
    PRIMARY KEY (process, entity_type, entity_id)
);

-- Process metadata — human-authored entry points, overrides, limits.
CREATE TABLE IF NOT EXISTS process_meta (
    process               TEXT PRIMARY KEY,
    entry_json            TEXT,            -- single object or list (§7)
    inputs_declared_json  TEXT,
    outputs_declared_json TEXT,
    domain_types_json     TEXT,
    utility_overrides_json TEXT,
    limits_json           TEXT,            -- {max_walk_nodes, max_walk_depth}
    updated_at            TEXT NOT NULL,
    updated_by            TEXT
);

-- Cross-process spawn edges.
CREATE TABLE IF NOT EXISTS process_to_process_edge (
    edge_id              TEXT PRIMARY KEY,
    source_process       TEXT NOT NULL,
    source_walk_id       INTEGER NOT NULL,
    target_process       TEXT NOT NULL,
    call_type            TEXT NOT NULL,    -- CREEC / CREMC / CREDC / CRETC / CREXC / CRESC / SIPCC
    requires_manual_review INTEGER NOT NULL DEFAULT 0,
    payload_variables_json TEXT,
    content_hash         TEXT
);

-- ─── Embedding tables (§11.5) ─────────────────────────────────────────────────

-- Chunk embeddings for hybrid BM25 + ANN retrieval.
CREATE TABLE IF NOT EXISTS chunk_embedding (
    chunk_id       TEXT PRIMARY KEY,
    process        TEXT NOT NULL,
    kind           TEXT NOT NULL,           -- block | file | process | variable
    file_path      TEXT,
    block_id       TEXT,
    context_prefix TEXT NOT NULL,
    body           TEXT NOT NULL,
    embedding      BLOB,                    -- float32 BLOB via pgvector.sqlite
    content_hash   TEXT NOT NULL,
    built_at       TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_chunk_emb_process ON chunk_embedding(process);

-- Variable context embeddings for few-shot classification.
CREATE TABLE IF NOT EXISTS variable_context_embedding (
    process          TEXT NOT NULL,
    name             TEXT NOT NULL,
    declaration_file TEXT NOT NULL,
    declaration_line INTEGER NOT NULL,
    embedding        BLOB,
    content_hash     TEXT NOT NULL,
    PRIMARY KEY (process, name, declaration_file, declaration_line)
);

-- Block embeddings for few-shot utility detection.
CREATE TABLE IF NOT EXISTS block_embedding (
    process      TEXT NOT NULL,
    file         TEXT NOT NULL,
    block        TEXT NOT NULL,
    embedding    BLOB,
    content_hash TEXT NOT NULL,
    PRIMARY KEY (process, file, block)
);

-- ─── Chat (§11, §13.5) ───────────────────────────────────────────────────────

-- Chat session memory — turn-by-turn history for multi-turn coherence.
CREATE TABLE IF NOT EXISTS chat_session (
    session_id  TEXT NOT NULL,
    process     TEXT NOT NULL,
    turn_index  INTEGER NOT NULL,
    role        TEXT NOT NULL,              -- user | assistant | tool_result
    content     TEXT NOT NULL,
    tool_calls  TEXT,                       -- JSON array of {name, args, result}
    created_at  TEXT NOT NULL,
    PRIMARY KEY (session_id, turn_index)
);
CREATE INDEX IF NOT EXISTS ix_chat_session_process ON chat_session(process, session_id);

-- ─── Hierarchical Walkthrough (self-contained; no dependency on Phase 1–5 tables) ──
-- A top-down call hierarchy rooted at the process entry, built deterministically
-- from parser blueprints + file_graph.json. Business-language explanations are
-- generated lazily per node and cached. See backend/hierwalk/.

-- One row per canonical node = "<file>::<function>". Deterministic, no LLM.
-- Project-free: the hierarchy is keyed only by (process, node_id). A given
-- process name always maps to the same code, so the cache is global — no
-- per-project/per-job partitioning.
CREATE TABLE IF NOT EXISTS hier_walk_node (
    process        TEXT NOT NULL,
    node_id        TEXT NOT NULL,             -- "<file_rel>::<function>"
    file           TEXT NOT NULL,             -- repo-relative source file
    function       TEXT NOT NULL,             -- function / routine name
    language       TEXT,                      -- cpp | asm
    line_start     INTEGER,
    line_end       INTEGER,
    is_utility     INTEGER NOT NULL DEFAULT 0, -- deterministic pre-tag (1 = helper/plumbing)
    utility_reason TEXT,                       -- which rule fired (name-pattern / fan-in / external)
    ambiguous      INTEGER NOT NULL DEFAULT 0, -- cross-file target could not be resolved uniquely
    depth          INTEGER,                    -- min depth from entry (root = 0)
    child_ids_json TEXT,                       -- ordered (call-site line) list of child node_ids
    parent_ids_json TEXT,                      -- caller node_ids (for graph / breadcrumb)
    content_hash   TEXT,                       -- sha256(source slice + child ids + template)
    PRIMARY KEY (process, node_id)
);
CREATE INDEX IF NOT EXISTS ix_hier_walk_node_proc ON hier_walk_node(process);

-- Business-process decomposition tree (the VISIBLE hierarchy). Each row is a
-- business activity, NOT a function: it may span several routines (code_refs).
-- node_id is a path ("root", "root/0", "root/0/2", …) so children are stable
-- and cacheable. title/summary are written when the PARENT is decomposed;
-- overview_bullets + children are written when THIS node is decomposed.
CREATE TABLE IF NOT EXISTS hier_subprocess (
    process             TEXT NOT NULL,
    node_id             TEXT NOT NULL,         -- path id, root = "root"
    parent_id           TEXT,                  -- NULL for root
    child_order         INTEGER DEFAULT 0,     -- sibling order under parent
    title               TEXT,                  -- business name (no identifiers)
    summary             TEXT,                  -- one-line business summary (card)
    overview_bullets_json TEXT,                -- business bullets: what happens here
    key_variables_json  TEXT,                  -- [{name, role}] key business data items
    code_refs_json      TEXT,                  -- hidden: substrate function node_ids
    is_leaf             INTEGER NOT NULL DEFAULT 0,  -- no further decomposition possible
    decomposed          INTEGER NOT NULL DEFAULT 0,  -- children generated yet? (= checkpoint flag)
    content_hash        TEXT,                  -- sha256(code_refs source + template)
    generated_at        TEXT,
    PRIMARY KEY (process, node_id)
);
CREATE INDEX IF NOT EXISTS ix_hier_subprocess_proc ON hier_subprocess(process);
CREATE INDEX IF NOT EXISTS ix_hier_subprocess_parent ON hier_subprocess(process, parent_id, child_order);

-- One row per process — build summary / pointers.
CREATE TABLE IF NOT EXISTS hier_walk_meta (
    process       TEXT NOT NULL,
    root_node_id  TEXT,
    node_count    INTEGER,
    max_depth     INTEGER,
    built_at      TEXT,
    PRIMARY KEY (process)
);

-- Relevance gate "memory": one verdict per (process, file). Decides whether the
-- hier walk recurses into a file or stops at it as a pruned leaf. Generated
-- ON DEMAND from the file's own source (never the blueprint business_summary),
-- judged against the process profile below. content_hash over the on-demand
-- source digest → self-invalidates when the source changes.
CREATE TABLE IF NOT EXISTS hier_file_relevance (
    process       TEXT NOT NULL,
    file          TEXT NOT NULL,             -- repo-relative source file
    verdict       TEXT NOT NULL,             -- core | supporting | utility | irrelevant
    score         REAL NOT NULL DEFAULT 0,   -- 0..1 relevance to the process
    recurse       INTEGER NOT NULL DEFAULT 1,-- 1 = walk into it, 0 = prune at leaf
    layer         TEXT,                      -- seed | L0-path | L1-db | L2-name | L3-llm | fallback
    reason        TEXT,                      -- one-line rationale
    content_hash  TEXT,                      -- sha256(source digest) → cache invalidation
    decided_at    TEXT,
    PRIMARY KEY (process, file)
);
CREATE INDEX IF NOT EXISTS ix_hier_file_relevance_proc ON hier_file_relevance(process);

-- Process "profile" generated ON DEMAND from the seed entry source (one LLM call
-- per process, cached). Gives the relevance judge the domain context it scores
-- every file against. content_hash over the seed source → self-invalidates.
CREATE TABLE IF NOT EXISTS hier_process_profile (
    process       TEXT NOT NULL,
    summary       TEXT,                      -- what this process does (on-demand)
    keywords_json TEXT,                      -- domain keywords for fallback scoring
    content_hash  TEXT,
    generated_at  TEXT,
    PRIMARY KEY (process)
);

-- Hierwalk variable map. Pass 1 extracts important variables ON DEMAND from each
-- kept file's real source (never blueprint variable_lineage — it's empty); Pass 2
-- classifies them across the whole process into input/output/key_business. One
-- row per (process, var_id). Pass-1 evidence + Pass-2 labels live together.
CREATE TABLE IF NOT EXISTS hier_variable (
    process            TEXT NOT NULL,
    var_id             TEXT NOT NULL,         -- canonical slug of the business name
    business_name      TEXT NOT NULL,
    raw_identifiers_json TEXT,                -- ["cscVal","PA_CSC", …] as seen in code
    classification_json TEXT,                 -- subset of ["input","output","key_business"]
    io_direction       TEXT,                  -- read | written | computed | read_write
    what_happens       TEXT,                  -- one-line: what happens to it across the process
    importance         TEXT,                  -- high | medium | low
    read_files_json    TEXT,                  -- files that read it
    write_files_json   TEXT,                  -- files that write/compute it
    fan_in             INTEGER DEFAULT 0,     -- distinct files touching it
    evidence_json      TEXT,                  -- [{file, function, line_start, line_end, io}]
    extras_json        TEXT,                  -- packing/importance: {components, component_count,
                                              --   decision_count, alias_count, packing, packing_score,
                                              --   process_importance, importance_rank, why_important}
    pass2_done         INTEGER NOT NULL DEFAULT 0,
    generated_at       TEXT,
    PRIMARY KEY (process, var_id)
);
CREATE INDEX IF NOT EXISTS ix_hier_variable_proc ON hier_variable(process);

-- ─── Indices (project_id indices created in db.py after ALTER TABLE migrations) ──
