"""The single LLM entry point for the process_analysis subsystem.

DESIGN RULE (DESIGN.md §8.5): every LLM interaction in
``process_analysis/`` goes through ``call_llm_json`` (or its raw companion
``call_llm_text``). Both delegate to the central
``llm.caller.call_llm(prompt, system_prompt=None) -> str``, which always uses
Gemini 2.5 Pro (per ``settings.LLM_MODEL_NAME``).

Why this wrapper at all (vs. importing ``call_llm`` directly):
  * Forces structured JSON output via a uniform parse-or-retry loop.
  * Sanitizes common Gemini quirks (markdown code fences around JSON, BOM,
    leading/trailing prose).
  * Centralizes the "schema hint" instruction so we can swap prompt templates
    later in one place.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, Optional, Sequence, Type, TypeVar

from pydantic import BaseModel, ValidationError

from llm.caller import call_llm as _call_llm   # the ONLY allowed Gemini call


_TModel = TypeVar("_TModel", bound=BaseModel)

logger = logging.getLogger(__name__)

_FENCE_RE = re.compile(r"^\s*```(?:json|JSON)?\s*\n?(.*?)\n?\s*```\s*$", re.DOTALL)


# ---------------------------------------------------------------------------
# Raw text passthrough
# ---------------------------------------------------------------------------

def call_llm_text(prompt: str, *, system_prompt: Optional[str] = None) -> str:
    """Plain-text Gemini call. Use ``call_llm_json`` for structured output."""
    return _call_llm(prompt, system_prompt=system_prompt)


# ---------------------------------------------------------------------------
# JSON with retry
# ---------------------------------------------------------------------------

class LLMJSONError(RuntimeError):
    """Raised when ``call_llm_json`` exhausts retries without valid JSON."""


def _strip_fences(text: str) -> str:
    """Remove ```json fences``` Gemini sometimes adds despite instructions.

    Handles both complete fences (```json ... ```) and truncated responses
    where the closing fence is missing (common when Gemini hits output limits).
    """
    text = text.strip().lstrip("﻿")  # strip BOM if any
    m = _FENCE_RE.match(text)
    if m:
        return m.group(1).strip()
    # Truncated fence: opening ```json without closing ``` (output limit hit).
    # Strip the opening marker so _find_balanced_json can extract the JSON.
    _OPEN_FENCE_RE = re.compile(r"^\s*```(?:json|JSON)?\s*\n?", re.MULTILINE)
    m2 = _OPEN_FENCE_RE.match(text)
    if m2:
        return text[m2.end():]
    return text


def _find_balanced_json(text: str) -> Optional[str]:
    """Best-effort: find the first balanced {...} or [...] block in ``text``.

    Useful when Gemini prepends explanatory prose despite "JSON only" instructions.
    Tries ``{...}`` first (preferred); falls back to ``[...]`` only when the match
    is at least 20 chars (avoids picking up incidental brackets like ``[4]`` from
    JSON path keys in truncated responses).
    """
    text = text.strip()
    for opener, closer in (("{", "}"), ("[", "]")):
        start = text.find(opener)
        if start == -1:
            continue
        depth = 0
        in_str = False
        esc = False
        for i in range(start, len(text)):
            c = text[i]
            if esc:
                esc = False
                continue
            if c == "\\":
                esc = True
                continue
            if c == '"':
                in_str = not in_str
                continue
            if in_str:
                continue
            if c == opener:
                depth += 1
            elif c == closer:
                depth -= 1
                if depth == 0:
                    candidate = text[start : i + 1]
                    # For [...] matches, require at least 20 chars to avoid
                    # picking up incidental brackets like [4] or [12] from
                    # JSON path keys (e.g. "setters[4].description") in
                    # truncated responses where the outer {} is unbalanced.
                    if opener == "[" and len(candidate) < 20:
                        break
                    return candidate
    return None


def _repair_truncated_json(text: str) -> Optional[str]:
    """Best-effort repair of truncated JSON from Gemini output-limit cutoffs.

    When a ``{...`` block is unbalanced because the response was truncated mid-
    stream, this function:
      1. Finds the last position where a valid JSON value ended (after a ``"``,
         ``}``, ``]``, digit, ``true``, ``false``, or ``null``).
      2. Trims trailing partial tokens (unfinished strings, keys).
      3. Closes any open ``{`` and ``[`` to produce parseable JSON.

    Returns the repaired JSON string, or None if repair is not feasible.
    """
    text = text.strip()
    if not text or text[0] != "{":
        return None

    # Find the last position that looks like a completed JSON value.
    # Walk backwards past whitespace/partial tokens to find a clean cut point.
    # Valid end-of-value chars: " } ] digit or e/l (true/false/null endings)
    cut = len(text)
    # Strip any trailing incomplete string (opened " without closing ")
    # by counting quotes: if odd, the last string is unterminated.
    quote_count = text.count('"')
    if quote_count % 2 == 1:
        # Unterminated string — find last opening quote and cut before it
        last_q = text.rfind('"')
        cut = last_q

    # Now trim back to the last complete key:value boundary.
    # Look for the last comma or colon that precedes a complete value.
    trimmed = text[:cut].rstrip()

    # Remove any trailing comma, colon, or partial key
    while trimmed and trimmed[-1] in (',', ':', ' ', '\n', '\r', '\t'):
        trimmed = trimmed[:-1]

    if not trimmed:
        return None

    # If we trimmed to something ending with a valid JSON value char, try to close it
    # Count open braces and brackets
    depth_brace = 0
    depth_bracket = 0
    in_s = False
    esc2 = False
    for c in trimmed:
        if esc2:
            esc2 = False
            continue
        if c == '\\':
            esc2 = True
            continue
        if c == '"':
            in_s = not in_s
            continue
        if in_s:
            continue
        if c == '{':
            depth_brace += 1
        elif c == '}':
            depth_brace -= 1
        elif c == '[':
            depth_bracket += 1
        elif c == ']':
            depth_bracket -= 1

    if depth_brace <= 0 and depth_bracket <= 0:
        return None  # nothing to repair

    # Close open brackets/braces
    repaired = trimmed + (']' * max(0, depth_bracket)) + ('}' * max(0, depth_brace))

    try:
        json.loads(repaired)
        return repaired
    except json.JSONDecodeError:
        return None


def call_llm_json(
    prompt: str,
    *,
    schema_hint: str,
    required_keys: Optional[Sequence[str]] = None,
    system_prompt: Optional[str] = None,
    max_retries: int = 3,
) -> Any:
    """Call the LLM, expect JSON, parse-or-retry — and optionally validate shape.

    Args:
        prompt: The user prompt body (without schema instructions — those are
                appended automatically).
        schema_hint: A textual description of the expected JSON shape. Will be
                appended to ``prompt`` inside a strict "return ONLY JSON"
                envelope.
        required_keys: If provided, the parsed result MUST be a dict containing
                all of these top-level keys. If a key is missing the call is
                retried with an explanation appended to the prompt. This is the
                cheapest correctness gate against partial-object outputs
                (observed empirically with Gemini on long C++ source).
        system_prompt: Optional system instruction (passed through to
                ``llm.caller.call_llm``).
        max_retries: Total attempts including the first. Must be >= 1.

    Returns:
        The parsed JSON object (dict or list).

    Raises:
        LLMJSONError: If parsing/shape-validation fails after ``max_retries`` attempts.
    """
    if max_retries < 1:
        raise ValueError("max_retries must be >= 1")

    envelope = (
        f"{prompt}\n\n"
        f"---\n"
        f"Return ONLY a JSON value matching this schema, with no prose, no "
        f"markdown fences, no commentary, no explanation. JSON only.\n\n"
        f"SCHEMA:\n{schema_hint}\n"
    )

    last_error: str = ""
    last_raw: str = ""

    for attempt in range(1, max_retries + 1):
        if attempt == 1:
            full_prompt = envelope
        else:
            # Re-prompt with the parse error so the model self-corrects.
            full_prompt = (
                f"{envelope}\n\n"
                f"PREVIOUS ATTEMPT FAILED to parse. Error:\n  {last_error}\n"
                f"Previous output (first 400 chars):\n  {last_raw[:400]}\n\n"
                f"Return ONLY a valid JSON value. JSON only."
            )

        try:
            raw = _call_llm(full_prompt, system_prompt=system_prompt)
        except Exception as exc:  # noqa: BLE001  — surface LLM transport failures verbatim
            last_error = f"LLM call raised: {exc!r}"
            last_raw = ""
            logger.warning("call_llm_json attempt %d/%d: %s", attempt, max_retries, last_error)
            continue

        last_raw = raw
        if not raw or not raw.strip():
            last_error = "LLM returned an empty response (possible content safety block)"
            logger.warning("call_llm_json attempt %d/%d: %s", attempt, max_retries, last_error)
            continue
        candidate = _strip_fences(raw)
        parsed: Any
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError as exc:
            balanced = _find_balanced_json(candidate)
            if balanced:
                try:
                    parsed = json.loads(balanced)
                except json.JSONDecodeError as exc2:
                    last_error = f"JSONDecodeError on balanced extraction: {exc2.msg} at pos {exc2.pos}"
                    logger.warning("call_llm_json attempt %d/%d: %s", attempt, max_retries, last_error)
                    continue
            else:
                # Last resort: try to repair truncated JSON
                repaired = _repair_truncated_json(candidate)
                if repaired:
                    parsed = json.loads(repaired)
                    logger.info("call_llm_json attempt %d/%d: repaired truncated JSON", attempt, max_retries)
                else:
                    last_error = f"JSONDecodeError: {exc.msg} at pos {exc.pos}; no balanced block found"
                    logger.warning("call_llm_json attempt %d/%d: %s", attempt, max_retries, last_error)
                    continue

        # Shape validation
        if required_keys is not None:
            if not isinstance(parsed, dict):
                last_error = (
                    f"Top-level JSON is {type(parsed).__name__}, expected an object "
                    f"with keys {list(required_keys)}"
                )
                logger.warning("call_llm_json attempt %d/%d: %s", attempt, max_retries, last_error)
                continue
            missing = [k for k in required_keys if k not in parsed]
            if missing:
                last_error = (
                    f"Top-level JSON object is missing required keys: {missing}. "
                    f"Present keys: {sorted(parsed.keys())}"
                )
                logger.warning("call_llm_json attempt %d/%d: %s", attempt, max_retries, last_error)
                continue

        return parsed

    raise LLMJSONError(
        f"Failed to obtain valid JSON after {max_retries} attempts. "
        f"Last error: {last_error}. Last raw (truncated): {last_raw[:300]!r}"
    )


# ---------------------------------------------------------------------------
# Pydantic-typed convenience (Q-P4a, approved 2026-05-27)
# ---------------------------------------------------------------------------

def call_llm_model(
    prompt: str,
    model: Type[_TModel],
    *,
    schema_hint: Optional[str] = None,
    system_prompt: Optional[str] = None,
    max_retries: int = 3,
) -> _TModel:
    """Like ``call_llm_json`` but returns a validated Pydantic model instance.

    Treats ``pydantic.ValidationError`` as a soft error: the next attempt is
    re-prompted with the field-level error messages so the model can
    self-correct. ``LLMJSONError`` after exhausted retries.

    ``schema_hint`` is optional — when omitted, we derive it from the
    Pydantic model's ``model_json_schema()`` so the LLM sees the same
    structural contract Pydantic will enforce.
    """
    if max_retries < 1:
        raise ValueError("max_retries must be >= 1")

    if schema_hint is None:
        schema_hint = (
            "A JSON OBJECT matching this Pydantic JSON Schema:\n"
            + json.dumps(model.model_json_schema(), indent=2)
        )

    envelope = (
        f"{prompt}\n\n"
        f"---\n"
        f"Return ONLY a JSON value matching this schema, with no prose, no "
        f"markdown fences, no commentary, no explanation. JSON only.\n\n"
        f"SCHEMA:\n{schema_hint}\n"
    )

    last_error: str = ""
    last_raw: str = ""

    for attempt in range(1, max_retries + 1):
        if attempt == 1:
            full_prompt = envelope
        else:
            full_prompt = (
                f"{envelope}\n\n"
                f"PREVIOUS ATTEMPT FAILED. Validation error:\n  {last_error}\n"
                f"Previous output (first 400 chars):\n  {last_raw[:400]}\n\n"
                f"Return ONLY a valid JSON object that matches the schema. JSON only."
            )

        try:
            raw = _call_llm(full_prompt, system_prompt=system_prompt)
        except Exception as exc:  # noqa: BLE001
            last_error = f"LLM transport: {exc!r}"
            last_raw = ""
            logger.warning("call_llm_model attempt %d/%d: %s", attempt, max_retries, last_error)
            continue

        last_raw = raw
        if not raw or not raw.strip():
            last_error = "LLM returned an empty response (possible content safety block)"
            logger.warning("call_llm_model attempt %d/%d: %s", attempt, max_retries, last_error)
            continue
        candidate = _strip_fences(raw)
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError as exc:
            balanced = _find_balanced_json(candidate)
            if balanced:
                try:
                    parsed = json.loads(balanced)
                except json.JSONDecodeError as exc2:
                    last_error = f"JSONDecodeError on balanced extraction: {exc2.msg} at pos {exc2.pos}"
                    logger.warning("call_llm_model attempt %d/%d: %s", attempt, max_retries, last_error)
                    continue
            else:
                # Last resort: try to repair truncated JSON
                repaired = _repair_truncated_json(candidate)
                if repaired:
                    parsed = json.loads(repaired)
                    logger.info("call_llm_model attempt %d/%d: repaired truncated JSON", attempt, max_retries)
                else:
                    last_error = f"JSONDecodeError: {exc.msg} at pos {exc.pos}; no balanced block found"
                    logger.warning("call_llm_model attempt %d/%d: %s", attempt, max_retries, last_error)
                    continue

        # Unwrap common LLM quirks before Pydantic validation:
        # • double-encoded JSON: model returned a JSON string instead of an object
        # • single-element list wrapping: model wrapped the object in an array
        # • multi-element list of dicts: model split the object across array items
        # • flat list of strings: model returned only the summary bullets as a JSON array
        if isinstance(parsed, str):
            try:
                parsed = json.loads(parsed)
            except json.JSONDecodeError:
                pass
        if isinstance(parsed, list):
            if len(parsed) == 1 and isinstance(parsed[0], dict):
                parsed = parsed[0]
            elif len(parsed) > 1 and all(isinstance(x, dict) for x in parsed):
                # Merge multiple dicts into one. Gemini sometimes splits
                # {"bt": {...}, "names": {...}} across list elements like
                # [{"bt": {...}}, {"names": {...}}]. For dict-valued keys,
                # merge recursively; for others, later values win.
                merged: Dict[str, Any] = {}
                for item in parsed:
                    for k, v in item.items():
                        if k in merged and isinstance(merged[k], dict) and isinstance(v, dict):
                            merged[k].update(v)
                        else:
                            merged[k] = v
                parsed = merged
            elif all(isinstance(x, str) for x in parsed):
                parsed = {"summary": parsed}
            else:
                # Unrecognised list shape (e.g. [4] from an incidental bracket
                # in a truncated response). Treat as a parse failure and retry.
                last_error = (
                    f"Parsed JSON is a non-dict list that could not be unwrapped: "
                    f"{repr(parsed)[:100]}"
                )
                logger.warning("call_llm_model attempt %d/%d: %s", attempt, max_retries, last_error)
                continue

        try:
            return model.model_validate(parsed)
        except ValidationError as vexc:
            # Compact, model-friendly error message.
            last_error = "Pydantic validation error: " + "; ".join(
                f"{'.'.join(str(p) for p in e['loc'])}: {e['msg']}" for e in vexc.errors()
            )
            logger.warning("call_llm_model attempt %d/%d: %s [type=%s repr=%s]",
                           attempt, max_retries, last_error, type(parsed).__name__, repr(parsed)[:200])
            continue

    raise LLMJSONError(
        f"Failed to obtain a {model.__name__} after {max_retries} attempts. "
        f"Last error: {last_error}. Last raw (truncated): {last_raw[:300]!r}"
    )
