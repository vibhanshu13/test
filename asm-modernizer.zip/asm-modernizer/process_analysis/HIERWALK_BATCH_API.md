# Hierwalk Batch API

Everything needed to run the hier-walk batch endpoint: what it does, what must
be on disk, the parameters, and the 202 + poll contract.

```
POST /demo/v1/projects/{project_id}/processes/{process}/hierwalk/batch
```

> `{project_id}` is accepted for URL compatibility but **ignored** — the hier
> walk is project-free (keyed by `process` only). Use `default`.

---

## What it does

One call pre-generates the whole walkthrough for a process, in the background:

1. **Builds the call substrate** (deterministic) — the top-down call hierarchy
   from the process entry point, with the **relevance gate** (the "util-stop")
   deciding which files to walk into vs. stop at.
2. **Decomposes every business card** (one LLM call per node, resumable).
3. *(optional)* **Builds the variable map** — important variables classified as
   input / output / key-business, written to `variables.json`.

It returns immediately with a `task_id`; you poll a status endpoint until done.
Work is **resumable & idempotent** (checkpoint = each node's `decomposed` flag):
re-dispatching after a failure resumes; when everything is already generated the
result is `already_complete` with no LLM calls.

---

## Prerequisites

**On disk** (per process `<p>`):

| What | Where |
|------|-------|
| Process definition (entry point + file scope + cross-file edges) | `data/processes/<p>/file_graph.json` |
| Business title | `data/processes/<p>/metadata.json` |
| Parser blueprints (one per file) | `temp/output_latest/asm/<name>.json` |
| Source files | the path each file uses in `file_graph.json` (resolved from repo root) |

**Environment** (`.env` at repo root):
```
GEMINI_API_KEY=<key>          # required — the batch makes LLM calls
LLM_MODEL_NAME=gemini-2.5-pro # default
```

**Services:**
- Backend on port 8010:
  ```
  env/bin/uvicorn process_analysis.backend.app:app --port 8010 --host 127.0.0.1
  ```
- **Celery worker + Redis** (preferred path). If absent, the same call
  transparently falls back to an in-process background **thread** (`mode:"threading"`)
  — same poll contract.
  ```
  redis-server                                   # redis://localhost:6379
  PYTHONPATH=$(pwd) celery -A process_analysis.backend.celery_app worker \
      -Q q_llm -c 4 --loglevel=info
  ```

---

## Parameters (query string — there is NO JSON body)

| Param | Type | Default | Meaning |
|-------|------|---------|---------|
| `restart` | bool | `false` | Wipe the substrate + all cards (+ variables) and regenerate from scratch |
| `workers` | int (1–16) | `4` | Parallel LLM workers per level |
| `relevance` | `llm` \| `deterministic` \| `off` | `llm` | The **util-stop**. `llm` = LLM judges each reached file core/utility; `deterministic` = path/name/db heuristics only (no LLM); `off` = no pruning, walk **every** reachable file |
| `full` | bool | `false` | Shorthand for `relevance=off`. Overrides `relevance` |
| `variables` | bool | `false` | Also build the two-pass variable map → writes `variables.json` |

**Notes**
- Any non-default `relevance`/`full` **forces a rebuild** (the substrate is
  mode-dependent), so it implies `restart` for the substrate step.
- Invalid `relevance` → `400`.

---

## Response — `202 Accepted`

```json
{
  "process": "plastic_authentication",
  "task_id": "9f1c…",
  "started": true,
  "mode": "celery",        // "celery" | "threading"
  "detail": ""
}
```

---

## Poll for completion

```
GET /demo/v1/projects/{project_id}/processes/{process}/hierwalk/batch/status/{task_id}
```

```json
{
  "task_id": "9f1c…",
  "status": "running",          // pending | running | done | failed | not_found
  "process": "plastic_authentication",
  "all_generated": false,        // true ⇒ no need to hit again
  "progress": { "level": "2", "generated": "5", "skipped": "0", "total": "12", "failed": "0" },
  "result": null,                // populated when status = done
  "error": null
}
```

When `status: "done"`:

```json
{
  "status": "done",
  "all_generated": true,
  "result": {
    "status": "completed",        // already_complete | completed | incomplete
    "total_nodes": 67,
    "generated": 67,
    "skipped_cached": 0,
    "failed": [],
    "variables": {                // present only when variables=true
      "files_scanned": 18,
      "variables": 222,
      "by_class": { "input": 65, "output": 41, "key_business": 19 },
      "packing":  { "rich": 5, "moderate": 25, "atomic": 192 },
      "json_path": "data/processes/<p>/variables.json"
    }
  }
}
```

The full per-variable detail is written to `variables.json` (see next section) —
the status only carries the counts.

---

## The variable map (`variables=true`)

When `variables=true`, after the cards the batch runs a **two-pass** variable
build and writes `data/processes/<p>/variables.json`. Each variable is extracted
**on demand from real source** (anchored — it's dropped unless its raw identifier
actually appears in the code) and classified across the whole process. See
`../docs/VARIABLE_FINDING_APPROACH.md` for the method.

`variables.json` shape:

```jsonc
{
  "process": "...",
  "process_summary": "...",
  "top_variables": [ /* top 25 by process_importance, ranked */ ],
  "by_class":   { "input": [...], "output": [...], "key_business": [...] },
  "by_packing": { "rich": [...], "moderate": [...], "atomic": [...] },
  "variables": [ /* every variable, ordered by importance_rank */ ]
}
```

Per-variable fields:

| Field | Meaning |
|-------|---------|
| `business_name`, `raw_identifiers` | plain name + the code identifiers it goes by |
| `classification` | multi-label: `input` / `output` / `key_business` (or none) |
| `io_direction`, `read_files`, `write_files`, `fan_in` | where it's read vs written, and across how many files |
| `components`, `component_count` | sub-values it bundles (a record/area packs many; a flag packs none) |
| `decision_count` | how many decisions/branches hinge on it |
| **`packing_score`** (0–100) + **`packing`** (`rich`/`moderate`/`atomic`) | **how much the variable carries & drives** |
| **`process_importance`** (0–100) + **`importance_rank`** (1 = top) | **how important it is to the end-to-end process** |
| `why_important` | one-line role across the whole process (top-ranked vars) |
| `evidence` | the files/routines + io that justify it |

### How the two scores are computed (deterministic, after the two passes)

Both are derived from the aggregated evidence and normalised **relative to the
top variable** in this process, so they read as "compared to the rest".

- **`packing_score`** = how much substance it holds & drives:
  ```
  packing_raw   = 3·component_count + 2·decision_count + 1·alias_count + 1·fan_in
  packing_score = round(100 · packing_raw / max(packing_raw))
  ```
  Components weigh most (packing is mostly about substructure). Labelled
  `rich ≥ 60`, `moderate ≥ 25`, else `atomic`.

- **`process_importance`** = how business-central it is end-to-end. It is
  **business-led**: the `classification` role dominates (key_business > output >
  input), with `fan_in` + `decision_count` + `component_count` as secondary
  signals. **Unlabelled / internal** variables are capped so plumbing (pointer
  tables, return-code aggregates) can never outrank the real business values.
  `importance_rank` then orders the whole list (1 = most important).

The two are independent: a variable can be `rich` (packs a lot) yet only
mid-importance — e.g. an error-indicator container that bundles many flags but
isn't the business headline.

Because scoring is deterministic, the weights can be re-tuned and re-run with **no
LLM calls** (only `why_important` needs the model).

---

## Examples

```bash
BASE=http://localhost:8010/demo/v1/projects/default/processes/plastic_authentication/hierwalk

# Default: LLM util-stop, cards only
curl -X POST "$BASE/batch?workers=8"
# → 202 {"task_id":"<id>", …}

# Poll
curl "$BASE/batch/status/<id>"

# Go FULL (no util-stop) AND build the variable map
curl -X POST "$BASE/batch?full=true&variables=true&workers=8"

# Keep util-stop, also build variables, from scratch
curl -X POST "$BASE/batch?relevance=llm&variables=true&restart=true"
```

---

## Related endpoints

| Endpoint | Purpose |
|----------|---------|
| `POST …/hierwalk/build?full=&relevance=` | Synchronous single build (substrate + root card) |
| `GET  …/hierwalk/relevance-report?format=json\|md` | Files the walk **stopped** at (pruned) and why |
| `POST …/hierwalk/variables/build` | Build only the variable map (substrate must exist) |
| `GET  …/hierwalk/variables?class=input\|output\|key_business` | Read the variable map |
| `GET  …/hierwalk/status` | Is it built? root id, node count, depth |

See `HIERWALK_DATA_GUIDE.md` for the underlying inputs and
`../docs/VARIABLE_FINDING_APPROACH.md` for the variable-map approach.
