"""Enqueue (or eagerly run) the VBT precompute for job b58d8432.

Usage:
    env/bin/python3 enqueue_vbt_precompute.py          # enqueue to Celery worker
    env/bin/python3 enqueue_vbt_precompute.py --eager   # run in-process, no worker
"""
import sys

from api.tasks.vbt_precompute_task import run_vbt_precompute

JOB_ID = "b58d8432-73e0-42d1-89a9-2ceebc47c6d2"
OPTIONS = {
    "blueprint_dir": "jobs/b58d8432-73e0-42d1-89a9-2ceebc47c6d2/output",
    "asm_dir": "datasource/pgupta/asm 7_version_0/asm 5",
    # cache_in_job_dir=True (default) -> VBT_CACHE_DIR = <bp>/vbt_cache
    # cfg_warm=True (default), require_db_precompute=True (default)
}

if "--eager" in sys.argv:
    # Runs the whole precompute in THIS process — no Celery worker needed.
    res = run_vbt_precompute.apply(args=[JOB_ID, OPTIONS]).get()
    print("done:", res.get("status"), "elapsed:", res.get("elapsed"))
else:
    r = run_vbt_precompute.delay(JOB_ID, OPTIONS)
    print("enqueued task id:", r.id)
