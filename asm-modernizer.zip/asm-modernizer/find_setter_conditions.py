#!/usr/bin/env python3
import sys
import time
import argparse
from pathlib import Path

# Setup repository imports
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from vbt.engine import resolve_aliases
from vbt.precompute.db_artifacts import set_load_only
from vbt.precompute.resolvers_db import preload_resolvers
from vbt.setters.asm_setters import set_asm_setter_map_job, find_asm_setters_in_file
from vbt.setters.cpp_setters import set_cpp_setter_map_job, set_cpp_file_writes_job, find_cpp_setters_in_file
from vbt.precompute.fn_facts_db import set_fn_facts_job
from vbt.precompute.modifier_index import get_modifier_index

# Import source and blueprint DB overrides
from vbt.precompute.source_db import install_source_override
from vbt.precompute.asm_db import install_asm_blueprint_override
from backward_traversal.utils.blueprint_utils import load_json, resolve_asm_blueprint

# Import condition helpers
from find_call_conditions import _count_braces, _extract_if_header
from get_call_conditions import _asm_call_site_conditions

def get_cpp_conditions_for_setter(src_path: Path, setter_line: int) -> list:
    """Extract enclosing scopes (if/while/for) from C++ source, supporting DB overrides."""
    from backward_traversal.utils.blueprint_utils import source_override_bytes
    ov = source_override_bytes(src_path)
    if ov is not None:
        try:
            lines = ov.decode("utf-8", "replace").splitlines()
        except Exception:
            return []
    else:
        try:
            lines = src_path.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception:
            return []
            
    if not (1 <= setter_line <= len(lines)):
        return []
        
    depth = 0
    conds = []
    # Start scanning from the line immediately above the setter
    for i in range(setter_line - 2, -1, -1):
        opens, closes = _count_braces(lines[i])
        net = closes - opens
        if net > 0:
            depth += net
            continue
        if net < 0:
            opens_consumed = -net
            for _ in range(opens_consumed):
                if depth == 0:
                    hdr = _extract_if_header(lines, i)
                    if hdr:
                        conds.append(hdr)
                else:
                    depth -= 1
    return conds

def main():
    parser = argparse.ArgumentParser(description="Find variables and print the conditions to reach their setters.")
    parser.add_argument("--job-id", default="b58d8432-73e0-42d1-89a9-2ceebc47c6d2", help="Precomputed Job ID in jobs/ folder")
    parser.add_argument("--variable", required=True, help="Variable to trace conditions for")
    parser.add_argument("--stem", help="Optional: restrict search to this stem file")
    parser.add_argument("--language", choices=["cpp", "asm"], help="Language of the variable (cpp or asm). If omitted, auto-detected.")
    args = parser.parse_args()
    
    job_id = args.job_id
    blueprint_dir = ROOT / "jobs" / job_id / "output" / "asm 5"
    asm_dir = ROOT / "datasource" / "asm7_admin" / "asm 7_version_0" / "asm 5"
    
    db_path = ROOT / "jobs" / job_id / "index.db"
    if not db_path.is_file():
        print(f"Error: index.db not found at {db_path}", file=sys.stderr)
        return
        
    print(f"Initializing database fast-paths and overrides for Job ID: {job_id}...")
    set_load_only(True)
    
    # Preload VBT resolvers & setter maps
    preload_resolvers(job_id, blueprint_dir, asm_dir)
    set_asm_setter_map_job(job_id)
    set_cpp_setter_map_job(job_id)
    set_cpp_file_writes_job(job_id)
    set_fn_facts_job(job_id)
    
    # Install the lazy DB overrides for raw source and blueprint file requests
    src_override_ok = install_source_override(job_id, asm_dir)
    bp_override_ok = install_asm_blueprint_override(job_id, blueprint_dir)
    print(f"DB overrides installed: Source={src_override_ok}, Blueprints={bp_override_ok}")
    
    midx = get_modifier_index(blueprint_dir, asm_dir)
    
    # 1. Resolve aliases
    detected_lang = args.language
    if not detected_lang:
        cpp_files = midx.files_for(args.variable, "cpp")
        asm_files = midx.files_for(args.variable, "asm")
        if cpp_files and not asm_files:
            detected_lang = "cpp"
        elif asm_files and not cpp_files:
            detected_lang = "asm"
        else:
            # Check if name exists as key in midx tables
            tail = args.variable.split(".")[-1].split("->")[-1]
            if tail.lower() in midx.cpp:
                detected_lang = "cpp"
            elif args.variable.upper() in midx.asm:
                detected_lang = "asm"
            else:
                detected_lang = "cpp" # default fallback
                
    alias_set = resolve_aliases(args.variable, detected_lang, asm_dir)
    targets = [(args.variable, detected_lang)] + [(a.name, a.language) for a in alias_set.aliases]
    print(f"Auto-detected/selected language: '{detected_lang}'")
    print(f"Searching setters for variable '{args.variable}' and its resolved aliases: {[t[0] for t in targets]}")
    
    # 2. Gather matching candidate setters
    setters = []
    for name, lang in targets:
        stems = sorted(midx.files_for(name, lang))
        if args.stem:
            stems = [s for s in stems if s == args.stem]
            
        for stem in stems:
            if lang == "cpp":
                tail_name = name.split(".")[-1].split("->")[-1]
                root_fp = [name] if ("." in name or "->" in name) else None
                found = find_cpp_setters_in_file(tail_name, asm_dir / f"{stem}.cpp", full_paths=root_fp)
                setters.extend(found)
            else:
                found = find_asm_setters_in_file(name, stem, blueprint_dir, asm_dir)
                setters.extend(found)
                
    if not setters:
        print("No setters found in database for the queried variable/aliases.")
        return
        
    print(f"Found {len(setters)} setter sites. Extracting reachability conditions...")
    print("=" * 80)
    
    for idx, s in enumerate(setters, 1):
        print(f"\nSetter Site #{idx}: {s.file_stem}.{s.language} @ line {s.line}")
        func_name = s.function if s.language == "cpp" else s.block_id
        print(f"  Context: inside function/block '{func_name}'")
        code = getattr(s, "lhs_path", getattr(s, "instruction", "")) or s.lhs_chain
        print(f"  Code: {code}")
        
        if s.language == "cpp":
            src_file = asm_dir / f"{s.file_stem}.cpp"
            conds = get_cpp_conditions_for_setter(src_file, s.line)
            if not conds:
                print("  Reachability Conditions: Unconditional (no enclosing branches found)")
            else:
                print("  Reachability Conditions (innermost first):")
                for c in conds:
                    print(f"    - line {c['line']}: {c['keyword']} ({c['text']})")
        else:
            # For ASM, load the blueprint via override-aware load_json
            bp_path = resolve_asm_blueprint(s.file_stem, blueprint_dir)
            if bp_path:
                bp = load_json(bp_path)
                # Walk the basic blocks and get the guard conditions
                conds = _asm_call_site_conditions(bp, s.line)
                if not conds:
                    print("  Reachability Conditions: Unconditional (or no active triggering branches)")
                else:
                    print("  Reachability Conditions:")
                    for c in conds:
                        opcode_str = f" [{c['opcode']}]" if c.get('opcode') else ""
                        print(f"    - line {c['line_no']}{opcode_str}: {c['condition']}")
            else:
                print("  Error: Could not resolve blueprint for ASM stem.")
                
    print("\n" + "=" * 80)

if __name__ == "__main__":
    main()
