"""Multi-file analysis orchestrator."""
import gc
import hashlib
import logging
import multiprocessing
import os
import pickle
import shutil
import signal
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional
from multi_file.single_file_analyzer import SingleFileAnalyzer, FileAnalysisResult
from multi_file.symbol_registry import GlobalSymbolRegistry
from cache.file_cache import FileAnalysisCache
from models.symbol import SymbolType
from macro_library import MacroLibrary, PerFileOverrideView
from passes.macro_collector import MacroCollector
from passes.macro_expansion_pass import MacroExpansionPass
from passes.call_graph_builder import CallGraphBuilderPass
from models.variable_lineage import VariableLineageGraph

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lineage graph lazy-load helpers
# ---------------------------------------------------------------------------

def _lineage_key(file_path: Path) -> str:
    return hashlib.md5(str(file_path).encode()).hexdigest() + ".pkl"


def _fadvise_dontneed(fd: int) -> None:
    """Drop page cache for *fd* (POSIX_FADV_DONTNEED).

    After every pickle write/read the kernel retains the pages in the page
    cache, counting them against the cgroup memory limit.  Calling this after
    each dump/load tells the kernel those pages are not needed soon so they
    can be reclaimed immediately rather than accumulating across many files.
    No-op on macOS / Windows where os.posix_fadvise is unavailable.
    """
    try:
        os.posix_fadvise(fd, 0, 0, 4)  # 4 = POSIX_FADV_DONTNEED
    except Exception:
        pass


def _dump_lineage(graph, cache_dir: Path, file_path: Path) -> None:
    try:
        dest = cache_dir / _lineage_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(graph, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        print(f"WARNING: Could not cache lineage for {file_path.name}: {exc}", flush=True)


def _load_lineage(cache_dir: Path, file_path: Path):
    try:
        src = cache_dir / _lineage_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        print(f"WARNING: Could not reload lineage for {file_path.name}: {exc}", flush=True)
        return None


def _evict_lineage(file_results, cache_dir: Path) -> int:
    evicted = 0
    for fr in file_results:
        graph = fr.analysis_context.get_metadata("variable_lineage")
        if graph is not None:
            _dump_lineage(graph, cache_dir, fr.file_path)
            fr.analysis_context.metadata.pop("variable_lineage", None)
            evicted += 1
    return evicted


def _restore_lineage(file_results, cache_dir: Path) -> int:
    restored = 0
    for fr in file_results:
        graph = _load_lineage(cache_dir, fr.file_path)
        if graph is not None:
            fr.analysis_context.add_metadata("variable_lineage", graph)
            restored += 1
    return restored


# ---------------------------------------------------------------------------
# Statements cache helpers — evict to disk after Phase 1, lazy-reload only
# during Phase 2.75 macro expansion, then delete.  For 14 K+ ASM files,
# Statement lists can total 5–8 GB held simultaneously.
# ---------------------------------------------------------------------------

def _stmt_key(file_path: Path) -> str:
    return hashlib.md5(str(file_path).encode()).hexdigest() + "_stmts.pkl"


def _dump_statements(stmts, cache_dir: Path, file_path: Path) -> None:
    try:
        dest = cache_dir / _stmt_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(stmts, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        _log.warning("Could not cache statements for %s: %s", file_path.name, exc)


def _load_statements(cache_dir: Path, file_path: Path):
    try:
        src = cache_dir / _stmt_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        _log.warning("Could not reload statements for %s: %s", file_path.name, exc)
        return None


# ---------------------------------------------------------------------------
# block_analysis cache helpers — evict to disk after Phase 1, reload per-file
# at blueprint emission time.  Saves 0.6–1.5 GB across 15 K files.
# ---------------------------------------------------------------------------

def _block_key(file_path: Path) -> str:
    return hashlib.md5(str(file_path).encode()).hexdigest() + "_block.pkl"


def _dump_block(block, cache_dir: Path, file_path: Path) -> None:
    try:
        dest = cache_dir / _block_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(block, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        _log.warning("Could not cache block_analysis for %s: %s", file_path.name, exc)


def _load_block(cache_dir: Path, file_path: Path):
    try:
        src = cache_dir / _block_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        _log.warning("Could not reload block_analysis for %s: %s", file_path.name, exc)
        return None


# ---------------------------------------------------------------------------
# line_metadata_index cache helpers — same pattern as block_analysis.
# Saves 0.6–3 GB across 15 K files.
# ---------------------------------------------------------------------------

def _lmi_key(file_path: Path) -> str:
    return hashlib.md5(str(file_path).encode()).hexdigest() + "_lmi.pkl"


def _dump_lmi(lmi, cache_dir: Path, file_path: Path) -> None:
    try:
        dest = cache_dir / _lmi_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(lmi, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        _log.warning("Could not cache line_metadata_index for %s: %s", file_path.name, exc)


def _load_lmi(cache_dir: Path, file_path: Path):
    try:
        src = cache_dir / _lmi_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        _log.warning("Could not reload line_metadata_index for %s: %s", file_path.name, exc)
        return None


# ---------------------------------------------------------------------------
# macro_expansions cache helpers — same pattern as statements / lineage.
# ---------------------------------------------------------------------------

def _me_key(file_path: Path) -> str:
    return hashlib.md5(str(file_path).encode()).hexdigest() + "_me.pkl"


def _dump_macro_expansions(expansions, cache_dir: Path, file_path: Path) -> None:
    try:
        dest = cache_dir / _me_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(expansions, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        _log.warning("Could not cache macro_expansions for %s: %s", file_path.name, exc)


def _load_macro_expansions(cache_dir: Path, file_path: Path):
    try:
        src = cache_dir / _me_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        _log.warning("Could not reload macro_expansions for %s: %s", file_path.name, exc)
        return None


# ---------------------------------------------------------------------------
# Compact symbol cache helpers — evict symbol_table.all_symbols per-batch as
# lightweight (name, symbol_type_value) string tuples instead of full Symbol
# objects.  For 30K files this saves ~4.5 GB during Phase 1 batch collection.
# _build_global_registry and _link_call_graphs stream from these compact files.
# Consumers only check key existence — empty lists in the registry are fine.
# ---------------------------------------------------------------------------

def _sym_compact_key(file_path: Path) -> str:
    return hashlib.md5(str(file_path).encode()).hexdigest() + "_symc.pkl"


def _dump_sym_compact(sym_compact, cache_dir: Path, file_path: Path) -> None:
    try:
        dest = cache_dir / _sym_compact_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(sym_compact, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        _log.warning("Could not cache sym_compact for %s: %s", file_path.name, exc)


def _load_sym_compact(cache_dir: Path, file_path: Path):
    try:
        src = cache_dir / _sym_compact_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        _log.warning("Could not reload sym_compact for %s: %s", file_path.name, exc)
        return None


# ---------------------------------------------------------------------------
# Module-level worker function — must be at module scope for ProcessPoolExecutor
# pickling to work with the 'spawn' start method (macOS default, Python 3.10+).
# ---------------------------------------------------------------------------

def _worker_init() -> None:
    """Initializer for ProcessPoolExecutor workers.

    - Raises the nice value so analysis subprocesses yield CPU to the OS
      and the Celery parent under contention (no effect on Windows).
    - Ignores SIGINT so Ctrl-C in the parent doesn't cascade to workers;
      the executor's context-manager shutdown handles clean exit instead.
    """
    try:
        os.nice(5)
    except OSError:
        pass  # nice() not supported (Windows, some sandboxes)
    signal.signal(signal.SIGINT, signal.SIG_IGN)


def _analyze_asm_batch(
    batch: List[Path],
    search_paths: List[Path],
    universe_asm_names: set,
    universe_cpp_names: set,
    cache_dir: Path,
    file_timeout: int = 300,
) -> List[FileAnalysisResult]:
    """Analyze a batch of ASM files in a worker process.

    Creates its own SingleFileAnalyzer and FileAnalysisCache instances —
    nothing is shared with the main process or other workers.

    ``file_timeout`` caps per-file analysis at that many seconds via SIGALRM
    (Unix only).  A file that exceeds the limit is skipped with a warning so
    one pathological file cannot stall an entire batch at 100 % CPU.
    """
    analyzer = SingleFileAnalyzer(search_paths)
    cache = FileAnalysisCache(cache_dir)
    results = []

    _has_alarm = hasattr(signal, "SIGALRM")  # False on Windows

    def _alarm_handler(signum, frame):
        raise TimeoutError("per-file analysis timeout")

    if _has_alarm:
        signal.signal(signal.SIGALRM, _alarm_handler)

    for file_path in batch:
        try:
            if _has_alarm and file_timeout > 0:
                signal.alarm(file_timeout)
            file_content = file_path.read_text(encoding="latin-1")
            result = analyzer.analyze(file_path, file_content)
            if _has_alarm and file_timeout > 0:
                signal.alarm(0)  # cancel alarm on success
        except TimeoutError:
            print(f"[timeout] Skipping {file_path.name} — exceeded {file_timeout}s per-file limit")
            continue
        except Exception as exc:
            print(f"[error] Skipping {file_path.name} — {type(exc).__name__}: {exc}")
            if _has_alarm:
                signal.alarm(0)
            continue

        if not cache.retrieve(str(file_path), file_content):
            cache.store(str(file_path), file_content, {
                "exports": result.exports,
                "imports": result.imports,
                "sections": result.sections,
            })
        if universe_asm_names:
            result.analysis_context.set_variable_names("asm", universe_asm_names)
        if universe_cpp_names:
            result.analysis_context.set_variable_names("cpp", universe_cpp_names)
        # Clear variable_names before returning to parent — the parent already
        # owns the universe; pickling them back for every result duplicates
        # 3–5 GB of heap across 14 K files (mirrors _analyze_mixed_batch).
        result.analysis_context.variable_names = {"asm": set(), "cpp": set()}
        results.append(result)

    if _has_alarm:
        signal.alarm(0)  # safety: ensure no pending alarm escapes

    return results


@dataclass
class MultiFileAnalysisResult:
    """Result of analyzing multiple files."""
    file_results: List[FileAnalysisResult]
    global_registry: Optional[GlobalSymbolRegistry]
    unresolved_externals: List[str]
    # Paths to on-disk caches for metadata evicted during Phase 1.
    # The emission layer reloads from these dirs per-file at emit time.
    # None when the orchestrator ran without eviction (e.g. tiny corpora).
    lineage_cache_dir: Optional[Path] = None
    block_cache_dir: Optional[Path] = None
    lmi_cache_dir: Optional[Path] = None
    macro_exp_cache_dir: Optional[Path] = None


class MultiFileOrchestrator:
    """Orchestrates two-phase multi-file analysis."""

    def __init__(
        self,
        cache_dir: Path,
        search_paths: List[Path],
        macro_libs: Optional[List[Path]] = None,
        universe_asm_names=None,
        universe_cpp_names=None
    ):
        """
        Initialize multi-file orchestrator.

        Args:
            cache_dir: Directory for caching analysis results
            search_paths: Directories to search for COPY includes
            macro_libs: Optional explicit macro library files
            universe_asm_names: Set of ASM variable names from universe
            universe_cpp_names: Set of C++ variable names from universe
        """
        self.cache = FileAnalysisCache(cache_dir)
        self.analyzer = SingleFileAnalyzer(search_paths)
        self.search_paths = search_paths
        self.macro_libs = macro_libs if macro_libs else []
        self.universe_asm_names = universe_asm_names if universe_asm_names else set()
        self.universe_cpp_names = universe_cpp_names if universe_cpp_names else set()

    def analyze_files(
        self,
        file_paths: List[Path],
        analysis_workers: int = 1,
        batch_size: int = 20,
        file_timeout: int = 300,
    ) -> MultiFileAnalysisResult:
        """
        Analyze multiple assembly files.

        Phase 1: Analyze each file independently — parallel when analysis_workers > 1.
                 Files are grouped into batches of `batch_size`; each batch runs in a
                 separate worker process via ProcessPoolExecutor.
        Phase 2: Build global registry and resolve cross-file references (sequential).
        Phase 2.5: Collect macro definitions (sequential).
        Phase 2.75: Expand macros (sequential).

        Args:
            file_paths: List of assembly files to analyze
            analysis_workers: Number of worker processes for Phase 1 (1 = sequential)
            batch_size: Files per worker batch
            file_timeout: Per-file SIGALRM timeout in seconds (0 = disabled, Unix only)

        Returns:
            Combined analysis results
        """
        # Phase 1: Individual file analysis
        batches = [
            file_paths[i : i + batch_size]
            for i in range(0, len(file_paths), batch_size)
        ]

        print(
            f"Phase 1: per-file batch analysis — {len(file_paths)} file(s), "
            f"{len(batches)} batch(es), {analysis_workers} worker(s), batch_size={batch_size}",
            flush=True,
        )
        print(
            "  Parsing each file for symbols, call-graph nodes, and variable-lineage edges.",
            flush=True,
        )

        file_results: List[FileAnalysisResult] = []

        # ------------------------------------------------------------------
        # Heavy metadata eviction caches (mirrors MixedLanguageOrchestrator).
        #
        # Without eviction, 14 K+ ASM files accumulate:
        #   statements            5–8 GB   (Statement lists, needed only in Phase 2.75)
        #   variable_lineage      4–6 GB   (per-file graphs, needed in Phase 2.75 + emit)
        #   block_analysis        0.6–1.5 GB (emit-time only)
        #   line_metadata_index   0.6–3 GB   (emit-time only)
        # Total: up to ~18 GB peak → OOM on ≤ 16 GB hosts.
        #
        # Each object is serialised to its own cache dir immediately after its
        # batch completes, reloaded lazily only when needed, then freed.
        # ------------------------------------------------------------------
        _lineage_dir = self.cache.cache_dir / "lineage_cache"
        _lineage_dir.mkdir(parents=True, exist_ok=True)

        _statements_dir = self.cache.cache_dir / "statements_cache"
        _statements_dir.mkdir(parents=True, exist_ok=True)

        _block_cache_dir = self.cache.cache_dir / "block_cache"
        _block_cache_dir.mkdir(parents=True, exist_ok=True)

        _lmi_cache_dir = self.cache.cache_dir / "lmi_cache"
        _lmi_cache_dir.mkdir(parents=True, exist_ok=True)

        _macro_exp_dir = self.cache.cache_dir / "macro_exp_cache"
        _macro_exp_dir.mkdir(parents=True, exist_ok=True)

        # Compact symbol cache — symbol_table.all_symbols evicted per-batch as
        # (name, symbol_type_value) tuples to save ~4.5 GB during Phase 1.
        _sym_compact_dir = self.cache.cache_dir / "sym_compact_cache"
        _sym_compact_dir.mkdir(parents=True, exist_ok=True)

        def _evict_batch_heavy_metadata(batch_results):
            """Evict large per-file objects to disk as each batch arrives.

            All files in the batch are evicted concurrently via a ThreadPoolExecutor.
            Each file writes to its own uniquely-named pickle file so there is no
            shared mutable state between threads.  Pickle I/O releases the GIL so
            threads achieve real parallelism for the disk-write portions.
            ANALYSIS_WORKERS is not affected.
            """
            def _evict_one(_r):
                # Statements (ASM) — needed only in Phase 2.75 macro expansion.
                if _r.analysis_context.statements:
                    _dump_statements(
                        _r.analysis_context.statements, _statements_dir, _r.file_path
                    )
                    _r.analysis_context.statements = []
                # variable_lineage — needed in Phase 2.75 + optional emit.
                _graph = _r.analysis_context.metadata.get("variable_lineage")
                if _graph is not None:
                    _dump_lineage(_graph, _lineage_dir, _r.file_path)
                    _r.analysis_context.metadata.pop("variable_lineage", None)
                # block_analysis — needed only at emit time.
                _block = _r.analysis_context.metadata.get("block_analysis")
                if _block is not None:
                    _dump_block(_block, _block_cache_dir, _r.file_path)
                    _r.analysis_context.metadata.pop("block_analysis", None)
                # line_metadata_index — needed only at emit time.
                _lmi = getattr(_r.analysis_context, "line_metadata_index", None)
                if _lmi is not None:
                    _dump_lmi(_lmi, _lmi_cache_dir, _r.file_path)
                    _r.analysis_context.line_metadata_index = None
                # symbol_table.all_symbols → compact (name, type_value) tuples.
                # Saves ~4.5 GB across 30K files during Phase 1.
                _st = _r.symbol_table
                if _st is not None:
                    _syms = getattr(_st, "all_symbols", None)
                    if _syms:
                        _dump_sym_compact(
                            [(s.name, s.symbol_type.value) for s in _syms],
                            _sym_compact_dir,
                            _r.file_path,
                        )
                        _st.all_symbols = []

            _n_evict = min(len(batch_results), 8)
            if _n_evict <= 1:
                for _r in batch_results:
                    _evict_one(_r)
            else:
                with ThreadPoolExecutor(max_workers=_n_evict) as _evict_pool:
                    list(_evict_pool.map(_evict_one, batch_results))

        if analysis_workers > 1 and len(batches) > 1:
            # Parallel path — each batch runs in a separate worker process.
            # Phase 2 is order-independent so result ordering within file_results
            # does not matter (confirmed in plan: _build_global_registry,
            # _link_call_graphs, and _stitch_variable_lineage are all order-independent).
            #
            # Celery ForkPoolWorker runs as a daemon process; Python normally
            # prevents daemon processes from spawning children.  Temporarily
            # clear the daemon flag so ProcessPoolExecutor can fork workers,
            # then restore it afterwards.
            # Force 'fork' context on macOS/Linux to avoid pickling the
            # AuthenticationString when spawning children from within a
            # Celery ForkPoolWorker (Python 3.10+ defaults to 'spawn').
            try:
                _mp_ctx = multiprocessing.get_context("fork")
            except ValueError:
                _mp_ctx = None  # Windows fallback

            _proc = multiprocessing.current_process()
            _was_daemon = _proc.daemon
            if _was_daemon:
                _proc.daemon = False
            try:
                _executor_kwargs = {
                    "max_workers": analysis_workers,
                    "initializer": _worker_init,
                }
                if _mp_ctx is not None:
                    _executor_kwargs["mp_context"] = _mp_ctx
                with ProcessPoolExecutor(**_executor_kwargs) as executor:
                    futures = [
                        executor.submit(
                            _analyze_asm_batch,
                            batch,
                            self.search_paths,
                            self.universe_asm_names,
                            self.universe_cpp_names,
                            self.cache.cache_dir,
                            file_timeout,
                        )
                        for batch in batches
                    ]
                    for future in as_completed(futures):
                        _batch = future.result()
                        _evict_batch_heavy_metadata(_batch)
                        file_results.extend(_batch)
            finally:
                if _was_daemon:
                    _proc.daemon = True
        else:
            # Sequential path — used for single-worker mode or small jobs.
            for batch in batches:
                _batch = _analyze_asm_batch(
                    batch,
                    self.search_paths,
                    self.universe_asm_names,
                    self.universe_cpp_names,
                    self.cache.cache_dir,
                    file_timeout,
                )
                _evict_batch_heavy_metadata(_batch)
                file_results.extend(_batch)

        # Safety-net: evict any lineage graph that slipped through the per-batch
        # eviction (e.g. a file that had no lineage during batch but got one
        # added), then force a GC cycle.
        _leftover = _evict_lineage(file_results, _lineage_dir)
        gc.collect()
        print(
            f"Lazy-load: lineage graphs offloaded to disk per-batch "
            f"({_leftover} leftover evicted now — phases 2–2.75 run lighter).",
            flush=True,
        )

        # Phase 2: Cross-file resolution
        print(
            f"Phase 2: cross-file resolution — building global EXTRN/ENTRY registry and "
            f"linking call-graph edges across {len(file_results)} file(s).",
            flush=True,
        )
        global_registry = self._build_global_registry(file_results, sym_compact_dir=_sym_compact_dir)
        unresolved_externals = self._find_unresolved_externals(global_registry)

        # Link call graph edges across files
        self._link_call_graphs(file_results, global_registry, sym_compact_dir=_sym_compact_dir)

        # Merge data flow information across files
        merged_data_flow = self._merge_data_flow(file_results, global_registry)

        # Clear data_flow_tracker and resolved_indirect_calls — consumed above
        # by _merge_data_flow; not needed in Phase 2.5, 2.75, or emission.
        # For 14 K ASM files: data_flow_tracker ≈ 2.2 GB, resolved_indirect_calls
        # ≈ 550 MB → clearing frees ~2.75 GB before macro expansion.
        # For 30 K files these scale to ~5.5 GB.  gc.collect() alone does not
        # return pages to the OS — malloc_trim(0) forces glibc to release the
        # freed heap pages so the cgroup counter actually drops before Phase 2.75.
        for _fr in file_results:
            _fr.analysis_context.metadata.pop("data_flow_tracker", None)
            _fr.analysis_context.metadata.pop("resolved_indirect_calls", None)
        gc.collect()
        try:
            import ctypes as _ct_p2
            for _libc_p2 in ("libc.so.6", "libc.so", "libSystem.B.dylib", "libc.dylib"):
                try:
                    _ct_p2.CDLL(_libc_p2).malloc_trim(0)
                    break
                except Exception:
                    pass
        except Exception:
            pass

        # Free GlobalSymbolRegistry immediately — all three consumers
        # (_find_unresolved_externals, _link_call_graphs, _merge_data_flow)
        # have finished.  The registry is dict/list overhead pointing to Symbol
        # objects already in file_results (~50 MB for 30 K files); freeing it
        # here and trimming ensures no stale references persist into Phase 2.5.
        # analysis_task.py sets result.global_registry = None anyway (line ~1153).
        global_registry = None
        gc.collect()
        try:
            import ctypes as _ct_reg
            for _libc_reg in ("libc.so.6", "libc.so", "libSystem.B.dylib", "libc.dylib"):
                try:
                    _ct_reg.CDLL(_libc_reg).malloc_trim(0)
                    break
                except Exception:
                    pass
        except Exception:
            pass

        # Phase 2.5: Macro collection
        print(
            f"Phase 2.5: macro collection — auto-discovering macro definitions "
            f"from {len(self.search_paths)} search path(s).",
            flush=True,
        )
        macro_collector = MacroCollector(self.search_paths)

        # Auto-discover macros
        macro_library = macro_collector.auto_discover()

        # Add explicit macro libraries (override auto-discovered)
        if self.macro_libs:
            macro_library = macro_collector.collect_from_files(
                self.macro_libs,
                macro_library
            )

        # Phase 2.75: Macro expansion (per-file with inline macros)
        _p275_expandable = sum(
            1 for fr in file_results
            if not fr.analysis_context.get_metadata("is_macro_library")
        )
        print(
            f"Phase 2.75: macro expansion — expanding macros in {_p275_expandable} ASM file(s), "
            f"rebuilding expanded call graphs.",
            flush=True,
        )

        # Per-file SIGALRM timeout for macro expansion (same guard as Phase 1).
        # A recursive or excessively complex macro definition can cause expand_all()
        # to loop indefinitely.  The alarm fires after file_timeout seconds and the
        # file is skipped, so one pathological file cannot hang the entire pipeline.
        _has_sigalrm = hasattr(signal, "SIGALRM")

        class _MacroTimeout(BaseException):  # BaseException so expand()'s except Exception cannot swallow it
            pass

        def _macro_alarm(signum, frame):
            raise _MacroTimeout()

        _p275_count = 0
        for file_result in file_results:
            if file_result.analysis_context.get_metadata("is_macro_library"):
                continue
            print(
                f"Phase 2.75: [{_p275_count + 1}/{_p275_expandable}] "
                f"{file_result.file_path.name}",
                flush=True,
            )
            # Lazy-load statements from disk (evicted during Phase 1 batch
            # collection to reduce the sustained memory footprint).
            _p275_stmts = _load_statements(_statements_dir, file_result.file_path)
            if _p275_stmts is not None:
                file_result.analysis_context.statements = _p275_stmts
            # Lazy-load: restore this file's lineage graph for annotation,
            # then evict it again immediately after.
            _p275_lineage = _load_lineage(_lineage_dir, file_result.file_path)
            if _p275_lineage is not None:
                file_result.analysis_context.add_metadata("variable_lineage", _p275_lineage)
            if _has_sigalrm:
                signal.signal(signal.SIGALRM, _macro_alarm)
                signal.alarm(file_timeout)
            try:
                inline_library = macro_collector.collect_inline_macros(file_result.file_path)
                per_file_library = PerFileOverrideView(macro_library, inline_library.get_all_macros())

                macro_pass = MacroExpansionPass(per_file_library)
                expansions = macro_pass.expand_all(file_result.analysis_context)
                macro_pass.update_context(file_result.analysis_context, expansions)
                self._annotate_lineage_macro_parents(file_result.analysis_context)

                # Build expanded call graphs for macro expansions
                call_graph_builder = CallGraphBuilderPass()
                call_graph_builder.build_expanded_graphs(file_result.analysis_context)

                # Re-persist the annotated lineage and evict from memory.
                _updated_lineage = file_result.analysis_context.get_metadata("variable_lineage")
                if _updated_lineage is not None:
                    _dump_lineage(_updated_lineage, _lineage_dir, file_result.file_path)
                    file_result.analysis_context.metadata.pop("variable_lineage", None)

                # Explicitly release per-iteration temporaries so their memory is
                # reclaimable before the next file.  Without this, Python's cyclic GC
                # may not collect analysis_context-referencing objects promptly across
                # thousands of files, causing RSS to grow until the OS OOM-kills the worker.
                del inline_library, per_file_library, macro_pass, expansions, call_graph_builder

                # Evict full macro_expansions to disk; replace with lightweight stubs.
                # Phase 5 stitcher only reads expansion_status + parameters — stubs
                # satisfy that.  Full objects reloaded per-file at emission time.
                _full_exps = getattr(file_result.analysis_context, "macro_expansions", None)
                if _full_exps:
                    _dump_macro_expansions(_full_exps, _macro_exp_dir, file_result.file_path)
                    from types import SimpleNamespace as _NS
                    file_result.analysis_context.macro_expansions = [
                        _NS(
                            expansion_status=e.expansion_status,
                            parameters=getattr(e, "parameters", {}),
                        )
                        for e in _full_exps
                    ]
                    del _full_exps
            except _MacroTimeout:
                file_result.analysis_context.metadata.pop("variable_lineage", None)
                print(
                    f"Phase 2.75: WARNING — macro expansion timed out after {file_timeout}s "
                    f"for {file_result.file_path.name}, skipping.",
                    flush=True,
                )
            except Exception as exc:
                file_result.analysis_context.metadata.pop("variable_lineage", None)
                print(
                    f"Phase 2.75: WARNING — macro expansion failed for "
                    f"{file_result.file_path.name}: {type(exc).__name__}: {exc}",
                    flush=True,
                )
            finally:
                if _has_sigalrm:
                    signal.alarm(0)  # disarm regardless of outcome
                # Evict statements now that macro expansion is done — they are
                # not needed for blueprint emission (json_emitter reads
                # block_analysis + line_metadata_index, not raw statements).
                file_result.analysis_context.statements = []
                # Free inline macro cache entry — each file is processed once.
                macro_collector._inline_macro_cache.pop(
                    file_result.file_path.resolve(), None
                )

            _p275_count += 1
            if _p275_count % 50 == 0:
                gc.collect()

        print(
            f"Phase 2.75: macro expansion complete — {_p275_count} file(s) processed.",
            flush=True,
        )

        # Delete statements cache — no longer needed after Phase 2.75.
        try:
            if _statements_dir.exists():
                shutil.rmtree(_statements_dir, ignore_errors=True)
                _log.info("Phase 2.75: statements cache cleaned up — %s", _statements_dir)
        except Exception:
            pass

        # Final GC sweep after the loop.
        gc.collect()

        # Lineage graphs, block_analysis, and line_metadata_index remain on
        # disk.  The emission layer in analysis_task.py reloads them per-file
        # via the cache dirs returned below — no bulk restore needed here.
        return MultiFileAnalysisResult(
            file_results=file_results,
            global_registry=None,  # freed above after _merge_data_flow
            unresolved_externals=unresolved_externals,
            lineage_cache_dir=_lineage_dir,
            block_cache_dir=_block_cache_dir,
            lmi_cache_dir=_lmi_cache_dir,
            macro_exp_cache_dir=_macro_exp_dir,
        )

    def _annotate_lineage_macro_parents(self, context) -> None:
        """Backfill macro parent ids on lineage edges matching macro invocation lines."""
        graph = context.get_metadata("variable_lineage")
        if not isinstance(graph, VariableLineageGraph):
            return
        expansions = getattr(context, "macro_expansions", None)
        if not expansions:
            return

        line_to_parent = {}
        for expansion in expansions:
            if expansion.expansion_status != "success":
                continue
            if expansion.invocation_line is None or not expansion.macro_name:
                continue
            parent_id = f"{expansion.macro_name}@{expansion.invocation_file}:{expansion.invocation_line}"
            line_to_parent[expansion.invocation_line] = parent_id

        if not line_to_parent:
            return

        for edge in graph.edges:
            if edge.macro_expansion_parent:
                continue
            parent = line_to_parent.get(edge.line)
            if parent:
                edge.macro_expansion_parent = parent

    def _build_global_registry(
        self,
        file_results: List[FileAnalysisResult],
        sym_compact_dir: Optional[Path] = None,
    ) -> GlobalSymbolRegistry:
        """Build global symbol registry from all files."""
        registry = GlobalSymbolRegistry()

        if sym_compact_dir is not None:
            # Stream compact (name, type_value) tuples from disk per-file.
            # Registry lists are empty — callers only need key existence checks.
            for result in file_results:
                sym_compact = _load_sym_compact(sym_compact_dir, result.file_path) or []
                for name, stype_val in sym_compact:
                    if stype_val == SymbolType.ENTRY.value:
                        registry.entries.setdefault(name, [])
                    elif stype_val == SymbolType.EXTRN.value:
                        registry.extrns.setdefault(name, [])
                    elif stype_val == SymbolType.WXTRN.value:
                        registry.wxtrns.setdefault(name, [])
        else:
            for result in file_results:
                for symbol in result.symbol_table.all_symbols:
                    if symbol.symbol_type == SymbolType.ENTRY:
                        registry.add_entry(symbol)
                    elif symbol.symbol_type == SymbolType.EXTRN:
                        registry.add_extrn(symbol)
                    elif symbol.symbol_type == SymbolType.WXTRN:
                        registry.add_wxtrn(symbol)

        return registry

    def _find_unresolved_externals(self, registry: GlobalSymbolRegistry) -> List[str]:
        """Find EXTRN symbols with no matching ENTRY."""
        unresolved = []

        for extrn_name, extrn_list in registry.extrns.items():
            if extrn_name not in registry.entries:
                unresolved.append(extrn_name)

        return unresolved

    def _link_call_graphs(
        self,
        file_results: List,
        registry: GlobalSymbolRegistry,
        sym_compact_dir: Optional[Path] = None,
    ) -> None:
        """
        Link call graph edges across files by resolving EXTRN targets.

        For each call graph node that references an external symbol:
        - Resolve it using the global registry
        - Update the node's file field with the target file
        - Mark unresolved nodes as external

        Args:
            file_results: List of FileAnalysisResult objects
            registry: Global symbol registry with ENTRY/EXTRN resolution
            sym_compact_dir: If set, stream (name, type_value) from disk instead
                             of reading symbol_table.all_symbols (which was evicted).
        """
        # Pass 1: build ENTRY name → file path map.
        symbol_to_file = {}
        for result in file_results:
            if sym_compact_dir is not None:
                sym_compact = _load_sym_compact(sym_compact_dir, result.file_path) or []
                for name, stype_val in sym_compact:
                    if stype_val == SymbolType.ENTRY.value:
                        symbol_to_file[name] = result.file_path
            else:
                for symbol in result.symbol_table.all_symbols:
                    if symbol.symbol_type == SymbolType.ENTRY:
                        symbol_to_file[symbol.name] = result.file_path

        # Pass 2: mutate call_graph.nodes using per-file EXTRN/WXTRN names.
        for result in file_results:
            if not result.call_graph:
                continue

            if sym_compact_dir is not None:
                sym_compact = _load_sym_compact(sym_compact_dir, result.file_path) or []
                file_extrns = {
                    name for name, stype_val in sym_compact
                    if stype_val in (SymbolType.EXTRN.value, SymbolType.WXTRN.value)
                }
            else:
                file_extrns = {
                    symbol.name
                    for symbol in result.symbol_table.all_symbols
                    if symbol.symbol_type in (SymbolType.EXTRN, SymbolType.WXTRN)
                }

            for node_name, node in result.call_graph.nodes.items():
                if node_name in file_extrns:
                    if node_name in symbol_to_file:
                        node.file = str(symbol_to_file[node_name])
                        node.is_external = False
                    else:
                        node.is_external = True
                        node.file = None
                    continue

                if node.file:
                    continue

    def _merge_data_flow(self, file_results: List, registry: GlobalSymbolRegistry) -> dict:
        """
        Merge data flow information across files.

        Collects resolved indirect calls from all files and validates them
        using the global symbol registry.

        Args:
            file_results: List of FileAnalysisResult objects
            registry: Global symbol registry

        Returns:
            Dictionary with merged data flow information
        """
        all_resolved_calls = []
        validated_calls = []
        unresolved_targets = []

        # Collect all resolved indirect calls from all files
        for result in file_results:
            resolved_calls = result.analysis_context.get_metadata("resolved_indirect_calls")
            if not resolved_calls:
                resolved_calls = []

            for call in resolved_calls:
                # Add source file information
                call["source_file"] = str(result.file_path)
                all_resolved_calls.append(call)

                # Validate target using global registry
                target_symbol = call.get("target")
                if target_symbol:
                    if target_symbol in registry.entries:
                        # Found in global registry - validated
                        validated_calls.append(call)
                    else:
                        # Not found - external or unresolved
                        unresolved_targets.append({
                            "symbol": target_symbol,
                            "calling_routine": call.get("routine"),
                            "source_file": call["source_file"]
                        })

        # Build merged data flow summary
        merged_data_flow = {
            "total_resolved_calls": len(all_resolved_calls),
            "validated_calls": len(validated_calls),
            "unresolved_targets": len(unresolved_targets),
            "all_calls": all_resolved_calls,
            "unresolved_details": unresolved_targets
        }

        # Store in first file's context for accessibility
        # (In a more complete implementation, this would be in a global metadata store)
        if file_results:
            file_results[0].analysis_context.add_metadata("merged_data_flow", merged_data_flow)

        return merged_data_flow
