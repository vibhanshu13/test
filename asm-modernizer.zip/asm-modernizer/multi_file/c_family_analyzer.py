"""Single file analyzer for C/C++ sources."""

import logging
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Iterable, Tuple, Set
import re

_log = logging.getLogger(__name__)
_SLOW_FILE_THRESHOLD: float = float(os.environ.get("SLOW_FILE_THRESHOLD_SECONDS", "10"))
from models.analysis_context import AnalysisContext
from models.symbol import SymbolTable, Symbol, SymbolType
from models.provenance import StatementProvenance
from models.call_graph import CallGraph, CallType
from models.line_metadata import (
    LineMetadataIndex,
    LineMetadata,
    CodeblockContext,
    ConditionalContext,
    CallContext,
)
from models.file_dependency import FileDependencyGraph, DependencyEvidence, DependencyType
from passes.c_family_parser import CFamilyParser
from passes.c_line_metadata_collector import CLineMetadataCollector
from passes.line_metadata_enricher import LineMetadataEnricher
from passes.variable_lineage_builder import VariableLineageBuilder


@dataclass
class CFileAnalysisResult:
    file_path: Path
    exports: List[str]
    imports: List[str]
    sections: List[str]
    symbol_table: SymbolTable
    call_graph: Optional[CallGraph]
    analysis_context: AnalysisContext


class CFamilyAnalyzer:
    """Analyzes a single C/C++ file."""

    def __init__(self, language: str, search_paths: Optional[List[Path]] = None):
        self.language = language
        self.parser = CFamilyParser(language)
        self.lineage_builder = VariableLineageBuilder()
        self.search_paths = [Path(p).resolve() for p in (search_paths or [])]
        self._cast_prefixes = (
            "static_cast<",
            "reinterpret_cast<",
            "const_cast<",
            "dynamic_cast<",
        )
        self._symbol_re = re.compile(r"^[A-Za-z_~][A-Za-z0-9_~:<>.,]*$")
        self._level_re = re.compile(r"^LEVEL_?(\d+)$", re.IGNORECASE)
        self._d_level_re = re.compile(r"^D([0-9A-Fa-f])$", re.IGNORECASE)
        self._integer_literal_re = re.compile(r"^[+-]?(?:0[xX][0-9A-Fa-f]+|\d+)(?:[uUlL]+)?$")
        self._c_block_comment_re = re.compile(r"/\*.*?\*/", re.DOTALL)
        self._include_re = re.compile(r'^\s*#\s*include\s*"([^"]+)"', re.MULTILINE)
        self._include_any_re = re.compile(
            r'^\s*#\s*include\s*(?:"([^"]+)"|<([^>]+)>)', re.MULTILINE
        )
        self._access_specifier_re = re.compile(r"^(?:public|private|protected)\s*:\s*$")
        self._brace_only_re = re.compile(r"^[{}]+\s*;?\s*$")
        # Per-instance cache for _collect_include_field_asm_aliases.
        # Maps resolved include file path -> (text, inc_aliases, inc_sources).
        # Multiple .cpp files that include the same cc*.hpp headers (common when
        # all files in a batch share 94 cc*.hpp includes) hit this cache and avoid
        # repeated read_text + _extract_field_asm_aliases calls.
        self._field_asm_alias_file_cache: Dict[Path, Tuple[str, dict, dict]] = {}

    def _extract_level_number(self, target: str, args: List[str]) -> Optional[int]:
        """Extract numeric level from get_level(<level>, ...) calls."""
        if not self._is_get_level_target(target):
            return None
        if not args:
            return None
        return self._parse_level_token(args[0] or "")

    def _is_get_level_target(self, target: str) -> bool:
        if not target:
            return False
        tail = target.split("::")[-1].strip()
        tail = re.sub(r"^[\s*&()]+|[\s*&()]+$", "", tail)
        tail = re.sub(r"<[^>]+>$", "", tail).strip()
        return tail.lower() == "get_level"

    def _parse_level_token(self, token: str) -> Optional[int]:
        if not token:
            return None
        cleaned = self._c_block_comment_re.sub("", token)
        cleaned = re.sub(r"//.*", "", cleaned).strip()
        if not cleaned:
            return None

        while cleaned.startswith("(") and cleaned.endswith(")"):
            cleaned = cleaned[1:-1].strip()
            if not cleaned:
                return None

        compact = re.sub(r"\s+", "", cleaned)
        if not compact:
            return None

        level_match = self._level_re.match(compact)
        if level_match:
            return int(level_match.group(1))

        d_level_match = self._d_level_re.match(compact)
        if d_level_match:
            return int(d_level_match.group(1), 16)

        if self._integer_literal_re.match(compact):
            normalized = re.sub(r"(?i)[uUlL]+$", "", compact)
            try:
                return int(normalized, 0)
            except ValueError:
                return None

        return None

    def _is_linkable_external_symbol(self, name: str, is_indirect: bool) -> bool:
        """Return True only for names that can be resolved as external link symbols."""
        if not name or is_indirect:
            return False
        lowered = name.lower()
        if lowered.startswith(self._cast_prefixes):
            return False
        if "->" in name:
            return False
        if any(ch in name for ch in (" ", "(", ")", "[", "]", "&", "*")):
            return False
        if "." in name and "::" not in name:
            # Method/field access on an object instance, not a link symbol.
            return False
        return bool(self._symbol_re.match(name))

    def _asm_alias_for(self, name: Optional[str], symbol_aliases: dict) -> Optional[str]:
        """Resolve ASM alias for a callable when declared with pragma map/asm label."""
        if not name:
            return None
        if name in symbol_aliases:
            return symbol_aliases[name]
        tail = name.split("::")[-1]
        return symbol_aliases.get(tail)

    def _resolve_local_include(self, including_file: Path, include_name: str) -> Optional[Path]:
        """Resolve a quoted include using local file dir, configured search paths, and siblings."""
        include_path = Path(include_name)
        candidates: List[Path] = []

        if include_path.is_absolute():
            candidates.append(include_path)
        else:
            candidates.append(including_file.parent / include_path)
            for search_path in self.search_paths:
                candidates.append(search_path / include_path)

            # Heuristic for layouts like <root>/cpp + <root>/hpp.
            if "/" not in include_name and "\\" not in include_name:
                parent = including_file.parent.parent
                try:
                    for sibling in parent.iterdir():
                        if sibling.is_dir():
                            candidates.append(sibling / include_path.name)
                except Exception:
                    pass

        for candidate in candidates:
            try:
                resolved = candidate.resolve()
            except Exception:
                continue
            if resolved.exists() and resolved.is_file():
                return resolved
        return None

    def _collect_include_symbol_aliases(self, file_path: Path, file_content: str) -> dict:
        """Collect symbol aliases from recursively included quoted local headers."""
        aliases = {}
        queue: List[Tuple[Path, str]] = [(file_path.resolve(), file_content)]
        visited: Set[Path] = {file_path.resolve()}

        while queue:
            current_file, current_content = queue.pop(0)
            for include_name in self._include_re.findall(current_content):
                resolved = self._resolve_local_include(current_file, include_name)
                if not resolved or resolved in visited:
                    continue
                visited.add(resolved)
                try:
                    include_text = resolved.read_text(errors="replace")
                except Exception:
                    continue

                include_aliases = self.parser._extract_symbol_aliases(include_text)
                for name, alias in include_aliases.items():
                    aliases.setdefault(name, alias)
                queue.append((resolved, include_text))

        return aliases

    def _collect_include_enum_values(
        self, file_path: Path, file_content: str
    ) -> Dict[str, Dict[str, str]]:
        """Collect enum value mappings from recursively included headers.

        Walks both quoted and angle-bracket includes (no cc* gate — enums
        can live in any header). First-writer-wins if the same identifier
        appears in multiple headers; rare in practice.
        """
        enums: Dict[str, Dict[str, str]] = {}
        queue: List[Tuple[Path, str]] = [(file_path.resolve(), file_content)]
        visited: Set[Path] = {file_path.resolve()}

        while queue:
            current_file, current_content = queue.pop(0)
            for quoted, angled in self._include_any_re.findall(current_content):
                include_name = quoted or angled
                if not include_name:
                    continue
                resolved = self._resolve_local_include(current_file, include_name)
                if not resolved or resolved in visited:
                    continue
                visited.add(resolved)
                try:
                    include_text = resolved.read_text(errors="replace")
                except Exception:
                    continue
                inc_enums = self.parser._extract_enum_values(include_text, resolved)
                for ident, rec in inc_enums.items():
                    enums.setdefault(ident, rec)
                queue.append((resolved, include_text))

        return enums

    def _collect_include_field_asm_aliases(
        self, file_path: Path, file_content: str
    ) -> Tuple[dict, dict]:
        """Collect struct-field→ASM-name aliases from recursively included cc*.hpp headers.

        Walks both quoted and angle-bracket includes. The gate inside
        CFamilyParser._extract_field_asm_aliases ensures only cc*.hpp files
        contribute mappings — non-cc headers silently yield ({}, {}).

        Returns (aliases, sources) where sources[key] is the cc*.hpp basename
        that supplied the mapping.
        """
        aliases: dict = {}
        sources: dict = {}
        queue: List[Tuple[Path, str]] = [(file_path.resolve(), file_content)]
        visited: Set[Path] = {file_path.resolve()}

        while queue:
            current_file, current_content = queue.pop(0)
            for quoted, angled in self._include_any_re.findall(current_content):
                include_name = quoted or angled
                if not include_name:
                    continue
                resolved = self._resolve_local_include(current_file, include_name)
                if not resolved or resolved in visited:
                    continue
                visited.add(resolved)

                cached = self._field_asm_alias_file_cache.get(resolved)
                if cached is not None:
                    include_text, inc_aliases, inc_sources = cached
                    _log.debug(
                        "_collect_include_field_asm_aliases cache hit: %s", resolved.name
                    )
                else:
                    try:
                        include_text = resolved.read_text(errors="replace")
                    except Exception:
                        continue
                    inc_aliases, inc_sources = self.parser._extract_field_asm_aliases(
                        include_text, resolved
                    )
                    self._field_asm_alias_file_cache[resolved] = (
                        include_text, inc_aliases, inc_sources
                    )

                for key, asm_name in inc_aliases.items():
                    if key not in aliases:
                        aliases[key] = asm_name
                        sources[key] = inc_sources.get(key, resolved.name)
                queue.append((resolved, include_text))

        return aliases, sources

    def _strip_comments_preserve_layout(self, text: str) -> str:
        def replace_block(match: re.Match[str]) -> str:
            chunk = match.group(0)
            return "".join("\n" if ch == "\n" else " " for ch in chunk)

        stripped = re.sub(r"/\*.*?\*/", replace_block, text, flags=re.DOTALL)
        stripped = re.sub(r"//[^\n]*", lambda m: " " * len(m.group(0)), stripped)
        return stripped

    def _build_exclusion_map(self, file_content: str) -> dict:
        raw_lines = file_content.splitlines()
        clean_lines = self._strip_comments_preserve_layout(file_content).splitlines()
        max_len = max(len(raw_lines), len(clean_lines))

        reasons = {}
        in_preprocessor_continuation = False
        for idx in range(max_len):
            line_no = idx + 1
            raw = raw_lines[idx] if idx < len(raw_lines) else ""
            clean = clean_lines[idx] if idx < len(clean_lines) else ""
            raw_stripped = raw.strip()
            clean_stripped = clean.strip()

            reason = None
            if raw_stripped == "":
                reason = "blank_line"
            elif in_preprocessor_continuation:
                reason = "preprocessor_line"
            elif clean_stripped == "":
                reason = "comment_line"
            elif clean_stripped.startswith("#"):
                reason = "preprocessor_line"
            elif self._brace_only_re.fullmatch(clean_stripped):
                reason = "structural_brace_line"
            elif self._access_specifier_re.fullmatch(clean_stripped):
                reason = "access_specifier_line"

            reasons[line_no] = reason

            if in_preprocessor_continuation:
                in_preprocessor_continuation = raw.rstrip().endswith("\\")
            elif clean_stripped.startswith("#"):
                in_preprocessor_continuation = raw.rstrip().endswith("\\")
            else:
                in_preprocessor_continuation = False

        return reasons

    def _enclosing_function_for_line(self, unit, line_no: int) -> Optional[str]:
        # Prefer the narrowest function range if multiple ranges include the line.
        best_name: Optional[str] = None
        best_span: Optional[int] = None
        for func in unit.functions:
            if func.start_line <= line_no <= func.end_line:
                span = func.end_line - func.start_line
                if best_span is None or span < best_span:
                    best_span = span
                    best_name = func.name
        return best_name

    def _backfill_line_metadata(
        self,
        file_path: Path,
        file_content: str,
        unit,
        line_metadata_index: LineMetadataIndex,
    ) -> None:
        exclusion_map = self._build_exclusion_map(file_content)
        file_str = str(file_path)

        for line_no, reason in exclusion_map.items():
            if reason is not None:
                continue
            if line_metadata_index.get(file_str, line_no):
                continue

            enclosing_function = self._enclosing_function_for_line(unit, line_no)
            metadata = LineMetadata(
                file=file_str,
                line_number=line_no,
                codeblock=CodeblockContext(
                    enclosing_function=enclosing_function,
                    enclosing_section=None,
                    enclosing_routine=None,
                    in_executable_block=enclosing_function is not None,
                ),
                conditional=ConditionalContext(
                    is_conditional=False,
                    depth=0,
                    active_conditions=[],
                    condition_types=[],
                ),
                calls=CallContext(
                    calls_functions=[],
                    calls_routines=[],
                    invokes_macros=[],
                ),
                is_comment=False,
            )
            line_metadata_index.add(metadata)

    def _iter_callsites(self, unit) -> Iterable[Tuple[str, str, Optional[str], bool, int, List[str]]]:
        """Yield normalized callsite tuples from parser outputs.

        Returns tuples of:
            (source_function, callee_name, asm_alias, is_indirect, line_no, args)

        Fix 1 — Function-pointer resolution: When a local variable is called and
        the variable was initialised with a single function-name identifier (e.g.
        ``SharedFn sfp = sharedEntry;  sfp(wa);``), yield the resolved function
        instead of the variable name.

        Fix 2 — Object method FQN: ``obj.method()`` is transformed to the fully-
        qualified ``TypeName::method`` so the existing namespace-stripping logic in
        build() can resolve it to the correct file.

        Fix 4 — CHA virtual dispatch: ``ptr->method()`` is transformed to the FQN
        of the declared pointer type AND all known subclasses (Class Hierarchy
        Analysis), each yielded as a separate edge candidate.
        """
        seen = set()

        # ── Pre-computation ────────────────────────────────────────────────────

        # C/C++ type keywords that can never be valid call targets.
        # tree-sitter sometimes parses typedef/cast expressions as calls, e.g.
        # ``typedef void (*SharedFn)(TestWorkArea*);`` → CCall(function='void').
        # Moved to top so it can be used in fp_sources filtering below.
        _CPP_TYPE_KEYWORDS: frozenset = frozenset({
            "void", "int", "char", "short", "long", "unsigned", "signed",
            "float", "double", "bool", "auto", "struct", "class", "union",
            "enum", "nullptr", "true", "false", "const", "volatile",
            # C++ control-flow keywords that tree-sitter may emit as call targets
            # (e.g. catch/throw/try/delete appearing in call_expression nodes)
            "catch", "throw", "try", "delete", "new", "return",
        })

        # Pre-pass: build filter sets used when populating fp_sources.
        # local_prim_vars: local variables with primitive types (e.g. `int cond`) —
        #   prevents ternary condition identifiers from entering FP sources (G03).
        # all_type_names: typedef/using alias names (e.g. CxFnPtr) —
        #   prevents type-alias identifiers from being treated as function sources.
        _PRIM_TYPE_PREFIXES = frozenset({
            "int", "char", "short", "long", "unsigned", "signed",
            "float", "double", "bool", "size_t", "ptrdiff_t",
            "uint8_t", "uint16_t", "uint32_t", "uint64_t",
            "int8_t", "int16_t", "int32_t", "int64_t",
        })
        all_type_names: frozenset = frozenset(unit.type_aliases.keys())
        local_prim_vars: set = set()
        for _d in unit.declarations:
            if not _d.name or not _d.function:
                continue
            _dt_m = re.match(r'^[A-Za-z_][A-Za-z0-9_]*', _d.data_type or "")
            if _dt_m and _dt_m.group().lower() in _PRIM_TYPE_PREFIXES:
                local_prim_vars.add(_d.name)

        # G04: pre-compute local variable names per function scope.
        # Used in P15 to distinguish between a global FP variable being assigned
        # inside a function body (e.g. `g_nodecl_fp = betaDirect`) and a genuinely
        # local variable.  We can't rely on unit.declarations for the global var
        # because the parser may not emit a CDeclaration for typedef-pointer globals.
        _local_var_names_by_fn: Dict[str, set] = {}
        for _d in unit.declarations:
            if _d.name and _d.function:
                _local_var_names_by_fn.setdefault(_d.function, set()).add(_d.name)

        # Fix 1: Build function-pointer sources map.
        # { fn_scope → { var_name → [assigned_func_names] } }
        # G02/G03: allow multiple sources when all are plain identifiers (array inits,
        #   ternary after filtering condition vars from local_prim_vars).
        # G05: allow qualified identifiers (A::B) so member-pointer inits like
        #   `BetaMFP mfp = &BetaObject::handle` are captured.
        _IDENT_PAT = re.compile(
            r'^[A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_~]*)*$'
        )
        fp_sources: Dict[str, Dict[str, List[str]]] = {}
        for decl in unit.declarations:
            if not decl.initializer_sources or not decl.name:
                continue
            srcs = [s for s in decl.initializer_sources
                    if s
                    and _IDENT_PAT.match(s)
                    and s not in local_prim_vars     # G03: exclude ternary cond vars
                    and s not in all_type_names      # exclude typedef/alias names
                    and s.lower() not in _CPP_TYPE_KEYWORDS]
            if srcs:
                scope_key = decl.function or "(global)"
                existing = fp_sources.setdefault(scope_key, {}).setdefault(decl.name, [])
                for _src in srcs:
                    if _src not in existing:
                        existing.append(_src)
        # P15: Accumulate post-init single-identifier re-assignments to tracked fp vars.
        # Example: RegFnPtr fp = func1; fp = func2; fp(wa) → resolves to BOTH func1 and func2.
        # Only accumulates when the variable is already in fp_sources (was declaration-initialized)
        # and the re-assignment RHS is a single plain identifier (not a call or expression).
        for asgn in (unit.assignments or []):
            if (getattr(asgn, 'call_function', None)  # skip call-assignments: fp = getFunc()
                    or not getattr(asgn, 'target', None)
                    or not getattr(asgn, 'sources', None)):
                continue
            scope_key = getattr(asgn, 'function', None) or "(global)"
            existing = fp_sources.get(scope_key, {}).get(asgn.target)
            if existing is None:
                # G04: seed fp_sources["(global)"] for any assignment whose target is
                # not a locally-declared variable in the current function (i.e. it must
                # be a global or external FP variable assigned inside this function body).
                # We cannot rely on unit.declarations containing the global declaration
                # because the parser may not emit a CDeclaration for typedef-pointer
                # globals (e.g. `CxFnPtr g_nodecl_fp;` at file scope).
                _local_names = _local_var_names_by_fn.get(scope_key, set())
                if asgn.target not in _local_names:
                    fp_sources.setdefault("(global)", {})[asgn.target] = []
                    existing = fp_sources["(global)"][asgn.target]
                else:
                    continue  # local variable not tracked as FP; skip
            srcs = [s for s in asgn.sources
                    if s and re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', s)]
            if len(srcs) == 1 and len(asgn.sources) == 1 and srcs[0] not in existing:
                existing.append(srcs[0])


        # Fix 2 + 4: Build variable-type map from all declarations.
        # { fn_scope → { var_name_lower → clean_type_string } }
        # Skip function declarations: their data_type is the return type, not the
        # type of an object that can have methods called on it.
        var_type: Dict[str, Dict[str, str]] = {}
        for decl in unit.declarations:
            if decl.kind in ("function", "member"):
                continue
            if not decl.data_type or not decl.name:
                continue
            raw_type = (decl.data_type or "").strip()
            # Resolve typedef/using aliases
            resolved_type = unit.type_aliases.get(raw_type, raw_type)
            # Strip trailing pointer/reference qualifiers: "Foo *" → "Foo"
            clean_type = re.sub(r'[\s*&]+$', '', resolved_type).strip()
            # Strip leading const/volatile/static/extern qualifiers
            for qual in ("const ", "volatile ", "static ", "extern "):
                while clean_type.startswith(qual):
                    clean_type = clean_type[len(qual):]
            clean_type = clean_type.strip()
            if clean_type:
                scope_key = decl.function or "(global)"
                var_type.setdefault(scope_key, {})[decl.name.lower()] = clean_type

        # Fix 4: Build reverse class hierarchy map (base → [subclasses]) from
        # the class_bases dict populated by the parser during walk().
        subclasses: Dict[str, List[str]] = {}
        for derived, bases in (getattr(unit, "class_bases", None) or {}).items():
            for base in bases:
                subclasses.setdefault(base, []).append(derived)

        # G01: struct-field FP sources { scope → { "TypeName::field" → [func_names] } }
        # Handles: struct D { CxFnPtr fn; }; D d; d.fn=betaDirect; d.fn(w) → betaDirect.
        # Must be built after var_type so we can resolve the base object's class name.
        field_fp_sources: Dict[str, Dict[str, List[str]]] = {}
        for _a in (unit.assignments or []):
            if (_a.target_kind != "struct_field"
                    or not _a.target_field or not _a.target_base):
                continue
            _fsrcs = [s for s in (_a.sources or [])
                      if s and re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', s)
                      and s.lower() not in _CPP_TYPE_KEYWORDS]
            if not _fsrcs:
                continue
            _fscope = _a.function or "(global)"
            _btype = (var_type.get(_fscope, {}).get(_a.target_base.lower())
                      or var_type.get("(global)", {}).get(_a.target_base.lower()))
            if not _btype:
                continue
            _fkey = f"{_btype}::{_a.target_field}"
            _fex = field_fp_sources.setdefault(_fscope, {}).setdefault(_fkey, [])
            for _fs in _fsrcs:
                if _fs not in _fex:
                    _fex.append(_fs)

        # ── Primary source: explicit call_expression captures ──────────────────
        for call in unit.calls:
            source = call.enclosing_function or "(global)"
            target = (call.function or "").strip()
            if not target:
                continue
            # Filter parser artifacts: type keywords are never real call targets.
            if target.lower() in _CPP_TYPE_KEYWORDS:
                continue

            # N01: global-scope qualifier "::func()" → strip leading "::" before other checks
            if target.startswith("::"):
                target = target[2:]
                if not target:
                    continue

            # N03: heap constructor — parser emits "__new_ClassName" for `new ClassName(...)`
            if target.startswith("__new_"):
                _nclass = target[len("__new_"):]
                _nk = (source, _nclass, call.line, False)
                if _nk not in seen:
                    seen.add(_nk)
                    yield source, _nclass, None, False, call.line, []
                continue

            # G05: member function pointer call — parser emits "obj.*mfp" or "ptr->*mfp".
            # Extract the FP variable name (after .* or ->*) and resolve via fp_sources.
            if ".*" in target or "->*" in target:
                _g05_sep = "->*" if "->*" in target else ".*"
                _g05_fp_var = target[target.find(_g05_sep) + len(_g05_sep):].strip()
                if _g05_fp_var and re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', _g05_fp_var):
                    _g05_resolved = (fp_sources.get(source, {}).get(_g05_fp_var, [])
                                     or fp_sources.get("(global)", {}).get(_g05_fp_var, []))
                    if _g05_resolved:
                        seen.add((source, target, call.line, True))
                        for _g05_rt in _g05_resolved:
                            _g05_rk = (source, _g05_rt, call.line, False)
                            if _g05_rk not in seen:
                                seen.add(_g05_rk)
                                yield source, _g05_rt, None, False, call.line, list(call.args or [])
                continue  # always skip raw "obj.*mfp" form

            # Fix 2: dot-accessor method call (obj.method()) → FQN TypeName::method
            if "." in target and "::" not in target:
                dot_idx = target.rfind(".")
                obj_name = target[:dot_idx].strip()
                # N02: strip pointer-dereference syntax — (*ptr).method() → ptr
                # Mirrors Fix 4: ptr_name = ... .strip("*()")
                obj_name = obj_name.strip("*()")
                method_name = target[dot_idx + 1:].strip()
                if obj_name and method_name:
                    vt = var_type.get(source, {}).get(obj_name.lower())
                    if vt:
                        fqn = f"{vt}::{method_name}"
                        # G01: if this FQN is a struct-field FP, yield resolved func(s) instead
                        _ffield_fps = (field_fp_sources.get(source, {}).get(fqn, [])
                                       or field_fp_sources.get("(global)", {}).get(fqn, []))
                        if _ffield_fps:
                            seen.add((source, fqn, call.line, False))
                            for _rt in _ffield_fps:
                                _rk = (source, _rt, call.line, False)
                                if _rk not in seen:
                                    seen.add(_rk)
                                    yield source, _rt, None, False, call.line, list(call.args or [])
                            continue  # skip normal FQN yield
                        fqn_key = (source, fqn, call.line, False)
                        if fqn_key not in seen:
                            seen.add(fqn_key)
                            yield source, fqn, None, False, call.line, list(call.args or [])
                        # P08-CHA: also emit for every known subclass (mirrors arrow path).
                        # Applies to reference variables and abstract base pointers
                        # accessed via dot notation.
                        for sc in subclasses.get(vt, []):
                            sc_fqn = f"{sc}::{method_name}"
                            sc_key = (source, sc_fqn, call.line, False)
                            if sc_key not in seen:
                                seen.add(sc_key)
                                yield source, sc_fqn, None, False, call.line, list(call.args or [])
                # Always skip the raw "obj.method" form (whether type was known or not)
                continue

            # Fix 4: arrow-accessor method call (ptr->method()) → FQN + CHA candidates
            if "->" in target:
                arrow_idx = target.find("->")
                ptr_name = target[:arrow_idx].strip().strip("*()")
                method_name = target[arrow_idx + 2:].strip()
                if ptr_name and method_name:
                    vt = var_type.get(source, {}).get(ptr_name.lower())
                    if vt:
                        clean_vt = re.sub(r'[\s*&]+$', '', vt).strip()
                        # Emit edge for the declared pointer type
                        fqn = f"{clean_vt}::{method_name}"
                        fqn_key = (source, fqn, call.line, False)
                        if fqn_key not in seen:
                            seen.add(fqn_key)
                            yield source, fqn, None, False, call.line, list(call.args or [])
                        # CHA: also emit for every known subclass of the declared type
                        for sc in subclasses.get(clean_vt, []):
                            sc_fqn = f"{sc}::{method_name}"
                            sc_key = (source, sc_fqn, call.line, False)
                            if sc_key not in seen:
                                seen.add(sc_key)
                                yield source, sc_fqn, None, False, call.line, list(call.args or [])
                # Always skip the raw "ptr->method" form
                continue

            # G08: operator overloading — parser emits CCall(function="__opover_+_a") for `a + b`
            if target.startswith("__opover_"):
                rest = target[len("__opover_"):]
                sep_pos = rest.rfind("_")
                if sep_pos > 0:
                    op_str, left_id = rest[:sep_pos], rest[sep_pos + 1:]
                    left_type = var_type.get(source, {}).get(left_id.lower())
                    if left_type and left_type.lower() not in _CPP_TYPE_KEYWORDS:
                        op_fqn = f"{left_type}::operator{op_str}"
                        op_key = (source, op_fqn, call.line, False)
                        if op_key not in seen:
                            seen.add(op_key)
                            yield source, op_fqn, None, False, call.line, []
                continue  # always skip the raw __opover_ marker

            # Fix 1: Try to resolve plain-identifier calls that are function-pointer variables.
            # If the identifier was initialised with a single known function name, yield that
            # resolved function instead of the variable name.
            # Also check the global scope "(global)" so that module-level FP declarations
            # (e.g. ``RegFnPtr g_fp = target;`` at file scope) are resolved when called
            # from inside any function in the same translation unit.
            if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', target):
                resolved_fps = (
                    fp_sources.get(source, {}).get(target, [])
                    or fp_sources.get("(global)", {}).get(target, [])
                )
                if resolved_fps:
                    # Mark the original variable key seen so the CAssignment fallback
                    # (end of this method) cannot re-emit the variable name as a raw target.
                    seen.add((source, target, call.line, bool(call.call_is_indirect)))
                    for rt in resolved_fps:
                        r_key = (source, rt, call.line, False)
                        if r_key not in seen:
                            seen.add(r_key)
                            yield source, rt, call.asm_target, False, call.line, list(call.args or [])
                    continue  # Resolved; skip original variable-name yield
                # P12: Functor/callable-object call — if the variable has a known
                # non-primitive class type, emit TypeName::operator() as FQN instead
                # of yielding the raw identifier (which Fix 3 would suppress as local var).
                if not resolved_fps:
                    vtype = var_type.get(source, {}).get(target.lower())
                    if vtype and vtype.lower() not in _CPP_TYPE_KEYWORDS:
                        op_fqn = f"{vtype}::operator()"
                        op_key = (source, op_fqn, call.line, False)
                        if op_key not in seen:
                            seen.add(op_key)
                            yield source, op_fqn, None, False, call.line, list(call.args or [])
                        continue  # suppress raw identifier yield; operator() FQN handles it

            # Standard case (includes unresolved is_indirect calls)
            key = (source, target, call.line, bool(call.call_is_indirect))
            if key in seen:
                continue
            seen.add(key)
            yield source, target, call.asm_target, bool(call.call_is_indirect), call.line, list(call.args or [])

        # ── Fallback source: assignments/init-declarators that retain call metadata ──
        # This keeps call graph emission robust across grammar shape differences.
        for assignment in unit.assignments:
            target = (assignment.call_function or "").strip()
            if not target:
                continue
            source = assignment.function or "(global)"
            key = (source, target, assignment.line, bool(assignment.call_is_indirect))
            if key in seen:
                continue
            seen.add(key)
            yield (
                source,
                target,
                assignment.call_asm_target,
                bool(assignment.call_is_indirect),
                assignment.line,
                list(assignment.call_args or []),
            )

        # G09: yield synthetic constructor call for each non-primitive local variable declaration.
        # "BetaObject obj;" → (source, "BetaObject", ...) so build() resolves to the defining file
        # via the class-name prefix registered in file_call_graph.py (Change C1).
        for _decl in unit.declarations:
            if _decl.kind != "variable" or not _decl.function:
                continue
            _raw = (_decl.data_type or "").strip()
            _ctype = re.sub(r'[\s*&<>].*$', '', unit.type_aliases.get(_raw, _raw)).strip()
            for _q in ("const ", "volatile ", "static ", "extern "):
                while _ctype.startswith(_q):
                    _ctype = _ctype[len(_q):]
            _ctype = _ctype.strip()
            if (not _ctype
                    or _ctype.lower() in _CPP_TYPE_KEYWORDS
                    or not re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', _ctype)):
                continue
            _ck = (_decl.function, _ctype, _decl.line, False)
            if _ck in seen:
                continue
            seen.add(_ck)
            yield _decl.function, _ctype, None, False, _decl.line, []

        # N07: yield synthetic constructor calls for global-scope class instances.
        # "BetaObject g_global_beta_obj;" at file scope → cx_alpha depends on cx_beta.
        # "(global_init)" is stored as source_block metadata only; the source FILE stem
        # is always derived from the blueprint path — using this placeholder is safe.
        for _decl in unit.declarations:
            if _decl.kind != "variable" or _decl.function:
                continue  # skip locals (already handled by G09 above)
            _raw = (_decl.data_type or "").strip()
            _ctype = re.sub(r'[\s*&<>].*$', '', unit.type_aliases.get(_raw, _raw)).strip()
            for _q in ("const ", "volatile ", "static ", "extern "):
                while _ctype.startswith(_q):
                    _ctype = _ctype[len(_q):]
            _ctype = _ctype.strip()
            if (not _ctype
                    or _ctype.lower() in _CPP_TYPE_KEYWORDS
                    or not re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', _ctype)):
                continue
            _gk = ("(global_init)", _ctype, _decl.line, False)
            if _gk in seen:
                continue
            seen.add(_gk)
            yield "(global_init)", _ctype, None, False, _decl.line, []

        # RT01: Return type dependency — "BetaObject* factory()" means this file depends on
        # BetaObject's TU via the return type, even when no local variable is constructed.
        # Uses the same yield format as G09/N07: type name resolves via cpp_fn_to_stem.
        for _fdecl in unit.declarations:
            if _fdecl.kind != "function" or not _fdecl.data_type or not _fdecl.name:
                continue
            _raw_rt = (_fdecl.data_type or "").strip()
            _rtype = re.sub(r'[\s*&<>].*$', '', unit.type_aliases.get(_raw_rt, _raw_rt)).strip()
            for _q in ("const ", "volatile ", "static ", "extern "):
                while _rtype.startswith(_q):
                    _rtype = _rtype[len(_q):]
            _rtype = _rtype.strip()
            if (not _rtype or _rtype.lower() in _CPP_TYPE_KEYWORDS
                    or not re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', _rtype)):
                continue
            _rtk = (_fdecl.name, _rtype, _fdecl.line, False)
            if _rtk not in seen:
                seen.add(_rtk)
                yield _fdecl.name, _rtype, None, False, _fdecl.line, []

    def _extract_include_dependencies(
        self, file_path: Path, file_content: str
    ) -> FileDependencyGraph:
        """Build a FileDependencyGraph from #include directives in this file.

        Scans both quoted (#include "foo.hpp") and angle-bracket (#include <foo.h>)
        forms.  Block comments are stripped first so commented-out includes are
        not recorded.  Edges use DependencyType.CPP_INCLUDE; all header targets
        are marked is_external=True (they are not analysis-set .cpp files).
        """
        graph = FileDependencyGraph()
        src = str(file_path)
        stripped = self._c_block_comment_re.sub("", file_content)
        for quoted, angled in self._include_any_re.findall(stripped):
            include_name = quoted or angled
            if not include_name:
                continue
            basename = Path(include_name).name
            evidence = DependencyEvidence(
                dependency_type=DependencyType.CPP_INCLUDE,
                source_file=src,
                source_line=0,
                details=(
                    f"#include <{include_name}>" if angled
                    else f'#include "{include_name}"'
                ),
            )
            graph.add_node(src, is_external=False)
            graph.add_node(basename, is_external=True)
            graph.add_edge(from_file=src, to_file=basename, evidence=evidence)
        return graph

    def analyze(self, file_path: Path, file_content: str) -> CFileAnalysisResult:
        _t0 = time.perf_counter()
        _log.debug("CFamilyAnalyzer.analyze start: %s", file_path)
        context = AnalysisContext(file_path=file_path)
        symbol_table = context.symbol_table

        # Create line metadata collector
        line_collector = CLineMetadataCollector()

        # Parse with line collector
        unit = self.parser.parse(file_path, file_content, line_collector=line_collector)
        include_aliases = self._collect_include_symbol_aliases(file_path, file_content)
        for name, alias in include_aliases.items():
            unit.symbol_aliases.setdefault(name, alias)
        include_field_aliases, include_field_sources = (
            self._collect_include_field_asm_aliases(file_path, file_content)
        )
        for key, asm_name in include_field_aliases.items():
            if key not in unit.field_asm_aliases:
                unit.field_asm_aliases[key] = asm_name
                unit.field_asm_alias_sources[key] = include_field_sources.get(key, "")
        # Phase 5 — pull enum definitions from included headers.
        include_enum_values = self._collect_include_enum_values(file_path, file_content)
        for ident, rec in include_enum_values.items():
            unit.enum_values.setdefault(ident, rec)
        context.add_metadata("c_family_unit", unit)
        if unit.parse_errors:
            context.add_metadata("c_family_parse_errors", unit.parse_errors)
        symbol_aliases = getattr(unit, "symbol_aliases", {}) or {}

        # Symbols: treat functions as ENTRY
        defined_functions = set()
        for func in unit.functions:
            defined_functions.add(func.name)
            provenance = StatementProvenance(
                statement_id=f"C_{func.name}_{func.start_line}",
                original_file=str(file_path),
                original_line=func.start_line
            )
            symbol_table.add_symbol(Symbol(
                name=func.name,
                symbol_type=SymbolType.ENTRY,
                file=str(file_path),
                provenance=provenance,
                asm_name=self._asm_alias_for(func.name, symbol_aliases),
            ))
            alias = unit.function_aliases.get(func.name)
            if alias and alias != func.name:
                defined_functions.add(alias)
                symbol_table.add_symbol(Symbol(
                    name=alias,
                    symbol_type=SymbolType.ENTRY,
                    file=str(file_path),
                    provenance=provenance
                ))

        # Call graph
        call_graph = CallGraph()
        for func in unit.functions:
            call_graph.add_node(func.name, file=str(file_path), node_kind="function")

        for decl in unit.declarations:
            if decl.kind != "function":
                continue
            if not decl.name or decl.name in defined_functions:
                continue
            if decl.storage_class == "static":
                continue
            if decl.scope not in ("global", "extern", None):
                continue
            call_graph.add_node(decl.name, is_external=True, file=str(file_path), node_kind="function")
            decl_asm_alias = self._asm_alias_for(decl.name, symbol_aliases)
            provenance = StatementProvenance(
                statement_id=f"C_DECL_{decl.name}_{decl.line}",
                original_file=str(file_path),
                original_line=decl.line
            )
            symbol_table.add_symbol(Symbol(
                name=decl.name,
                symbol_type=SymbolType.EXTRN,
                file=str(file_path),
                provenance=provenance,
                asm_name=decl_asm_alias,
            ))
            if decl_asm_alias and decl_asm_alias != decl.name and decl_asm_alias not in defined_functions:
                call_graph.add_node(decl_asm_alias, is_external=True, file=str(file_path), node_kind="function")
                symbol_table.add_symbol(Symbol(
                    name=decl_asm_alias,
                    symbol_type=SymbolType.EXTRN,
                    file=str(file_path),
                    provenance=provenance,
                ))

        local_symbols_by_function = {}
        for decl in unit.declarations:
            if not decl.function:
                continue
            if decl.scope not in ("local", "local_static"):
                continue
            local_symbols_by_function.setdefault(decl.function, set()).add(decl.name)

        for source, target, parsed_asm_target, is_indirect, call_line, call_args in self._iter_callsites(unit):
            asm_target = parsed_asm_target or self._asm_alias_for(target, symbol_aliases)
            call_graph.add_node(
                source,
                file=str(file_path),
                node_kind="function" if source != "(global)" else "global",
            )
            is_local_callable = target in local_symbols_by_function.get(source, set())
            is_linkable_external = (
                target not in defined_functions
                and not is_local_callable
                and self._is_linkable_external_symbol(target, is_indirect)
            )
            if is_linkable_external:
                call_graph.add_node(target, is_external=True, file=str(file_path), node_kind="function")
                provenance = StatementProvenance(
                    statement_id=f"C_CALL_{target}_{call_line}",
                    original_file=str(file_path),
                    original_line=call_line
                )
                symbol_table.add_symbol(Symbol(
                    name=target,
                    symbol_type=SymbolType.EXTRN,
                    file=str(file_path),
                    provenance=provenance,
                    asm_name=asm_target,
                ))
            elif target in defined_functions:
                call_graph.add_node(target, file=str(file_path), node_kind="function")

            if asm_target and asm_target != target:
                call_graph.add_node(asm_target, is_external=True, file=str(file_path), node_kind="function")
                provenance = StatementProvenance(
                    statement_id=f"C_CALL_ALIAS_{target}_{call_line}",
                    original_file=str(file_path),
                    original_line=call_line
                )
                symbol_table.add_symbol(Symbol(
                    name=asm_target,
                    symbol_type=SymbolType.EXTRN,
                    file=str(file_path),
                    provenance=provenance,
                ))
            call_graph.add_edge(
                source=source,
                target=target,
                call_type=CallType.CALL,
                instruction="CALL",
                file=str(file_path),
                line=call_line,
                is_indirect=is_indirect,
                level_number=self._extract_level_number(target, call_args),
                # Fix 3: mark local-variable calls (lambdas, unresolved fp vars) so that
                # file_call_graph.py can suppress them as spurious external edges.
                is_local_var=is_local_callable,
            )
            if asm_target and asm_target != target:
                call_graph.add_edge(
                    source=source,
                    target=asm_target,
                    call_type=CallType.SUBROUTINE_CALL,
                    instruction="CALL_ALIAS",
                    file=str(file_path),
                    line=call_line,
                    is_indirect=is_indirect,
                )

        context.add_metadata("call_graph", call_graph)

        # Gap 4: populate file_dependency_graph from #include directives so that
        # the blueprint's file_dependencies section is non-empty for C++ files.
        dep_graph = self._extract_include_dependencies(file_path, file_content)
        context.add_metadata("file_dependency_graph", dep_graph)

        # Variable lineage
        self.lineage_builder.process_c_family(unit, context)

        # Build line metadata index
        line_metadata_index = LineMetadataIndex()
        for metadata in line_collector.metadata_list:
            line_metadata_index.add(metadata)
        self._backfill_line_metadata(file_path, file_content, unit, line_metadata_index)
        context.line_metadata_index = line_metadata_index

        # Enrich line metadata with call information from CallGraph
        if call_graph and line_metadata_index:
            enricher = LineMetadataEnricher(call_graph, line_metadata_index)
            enricher.enrich_all()

        exports = [func.name for func in unit.functions]
        imports = [sym.name for sym in symbol_table.all_symbols if sym.symbol_type == SymbolType.EXTRN]

        _elapsed = time.perf_counter() - _t0
        if _elapsed >= _SLOW_FILE_THRESHOLD:
            _log.warning(
                "CFamilyAnalyzer.analyze slow file (%.1fs): %s", _elapsed, file_path
            )
        else:
            _log.debug(
                "CFamilyAnalyzer.analyze done in %.3fs: %s", _elapsed, file_path
            )

        return CFileAnalysisResult(
            file_path=file_path,
            exports=exports,
            imports=imports,
            sections=[],
            symbol_table=symbol_table,
            call_graph=call_graph,
            analysis_context=context
        )
