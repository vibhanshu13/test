"""Mixed-language multi-file orchestrator (ASM + C/C++)."""

import gc
import hashlib
import logging
import multiprocessing
import os
import pickle
import signal
import time
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional
import re

_log = logging.getLogger(__name__)

# Fraction of cgroup memory limit at which per-file skipping kicks in.
_MEM_SKIP_RATIO = 0.90


def _rss_ratio() -> float:
    """Return non-reclaimable memory / cgroup_memory_limit as a float in [0, 1].

    The cgroup memory.current counter includes page cache (file-backed pages)
    which the kernel reclaims before OOM-killing the process.  Using the raw
    counter as the skip threshold is overly conservative — evicted pickle
    files (lineage, statements, sym_compact, etc.) can accumulate 5–8 GB of
    reclaimable page cache, causing Phase 4 to skip files even when real
    Python heap is only 4–5 GB.

    This function subtracts inactive_file (immediately reclaimable page
    cache) from the raw usage to get the non-reclaimable portion.  Falls
    back to the raw ratio when memory.stat is unavailable (older kernels /
    cgroup v1 setups).
    """
    for limit_path, usage_path, stat_path in (
        (
            "/sys/fs/cgroup/memory.max",
            "/sys/fs/cgroup/memory.current",
            "/sys/fs/cgroup/memory.stat",
        ),
        (
            "/sys/fs/cgroup/memory/memory.limit_in_bytes",
            "/sys/fs/cgroup/memory/memory.usage_in_bytes",
            "/sys/fs/cgroup/memory/memory.stat",
        ),
    ):
        try:
            raw = open(limit_path).read().strip()
            if raw in ("max", ""):
                continue
            limit = int(raw)
            if limit >= (1 << 62):
                continue
            usage = int(open(usage_path).read().strip())
            # Subtract reclaimable page cache so the ratio reflects actual
            # Python heap pressure, not transient file-cache accumulation.
            # inactive_file pages are dropped by the kernel before OOM.
            try:
                inactive_file = 0
                for _line in open(stat_path):
                    if _line.startswith("inactive_file "):
                        inactive_file = int(_line.split()[1])
                        break
                usage = max(0, usage - inactive_file)
            except Exception:
                pass
            return usage / limit
        except Exception:
            continue
    return 0.0


# ---------------------------------------------------------------------------
# Lineage graph lazy-load helpers
# ---------------------------------------------------------------------------

def _lineage_key(file_path: Path) -> str:
    """Stable filename for the pickled lineage of *file_path*."""
    return hashlib.md5(str(file_path).encode()).hexdigest() + ".pkl"


# ---------------------------------------------------------------------------
# Statements cache helpers — mirrors the lineage helpers above.
#
# ASM FileAnalysisResult objects carry a `context.statements` list that holds
# every parsed Statement for the file.  For 11 K+ ASM files this list can
# total 5–8 GB of heap across all results simultaneously.  We serialise each
# file's statements to disk immediately after the batch worker returns them,
# reload per-file only for the Phase-4 macro expansion window, then discard.
# ---------------------------------------------------------------------------

def _fadvise_dontneed(fd: int) -> None:
    """Drop page cache for *fd* (POSIX_FADV_DONTNEED).

    After every pickle write the kernel retains the written pages in the page
    cache, counting them against the cgroup memory limit.  Calling this after
    each dump/load tells the kernel those pages are not needed soon, so they
    can be reclaimed immediately rather than accumulating across 15 K+ files.
    No-op on macOS / Windows where posix_fadvise is unavailable.
    """
    try:
        os.posix_fadvise(fd, 0, 0, 4)  # 4 = POSIX_FADV_DONTNEED
    except Exception:
        pass


def _drop_page_cache(cache_dirs) -> int:
    """Call POSIX_FADV_DONTNEED on every file in *cache_dirs*.

    A single per-file fadvise call after write/read is advisory — the kernel
    may defer page reclaim until memory pressure arrives.  This bulk sweep
    forces immediate reclaim of all cached pages across one or more cache
    directories, which is necessary before long-running phases (e.g. Phase 4
    macro expansion) where accumulated page cache from Phase 1 evictions can
    push cgroup usage above the OOM-skip threshold even though real Python
    heap is well within limits.

    Returns the number of files processed.
    """
    evicted = 0
    for cache_dir in cache_dirs:
        if cache_dir is None or not cache_dir.exists():
            continue
        for fpath in cache_dir.iterdir():
            try:
                with open(fpath, "rb") as fh:
                    _fadvise_dontneed(fh.fileno())
                evicted += 1
            except Exception:
                pass
    return evicted


def _stmt_key(file_path: Path) -> str:
    """Stable filename for the pickled statements of *file_path*."""
    return hashlib.md5(str(file_path).encode()).hexdigest() + "_stmts.pkl"


# ---------------------------------------------------------------------------
# Call-graph cache helpers — used to persist ASM call_graphs before they are
# evicted from memory at Phase 5 pre-stitch.  The emission layer reloads each
# graph one-at-a-time so that per-file blueprint output contains the real
# call_graph rather than an empty {"nodes": {}, "edges": []}.
# ---------------------------------------------------------------------------

def _cg_key(file_path: Path) -> str:
    """Stable filename for the pickled call_graph of *file_path*."""
    return hashlib.md5(str(file_path).encode()).hexdigest() + "_cg.pkl"


def _dump_call_graph(call_graph, cache_dir: Path, file_path: Path) -> None:
    """Pickle *call_graph* to *cache_dir*. Silently skips on error."""
    try:
        dest = cache_dir / _cg_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(call_graph, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        _log.warning("Could not cache call_graph for %s: %s", file_path.name, exc)


def _load_call_graph(cache_dir: Path, file_path: Path):
    """Unpickle and return the call_graph for *file_path*, or None on miss."""
    try:
        src = cache_dir / _cg_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        _log.warning("Could not reload call_graph for %s: %s", file_path.name, exc)
        return None


# ---------------------------------------------------------------------------
# Compact symbol cache helpers — evict symbol_table.all_symbols per-batch as
# lightweight (name, symbol_type_value) string tuples instead of full Symbol
# objects.  For 30K files this saves ~4.5 GB during Phase 1 batch collection
# (Symbol objects carry file, line, section, and other attributes totalling
# ~1–2 KB each; a compact tuple is ~100 bytes).
#
# _build_global_registry and _link_call_graphs both read from these compact
# files instead of in-memory symbol_table.all_symbols.
# Consumers (_find_unresolved_externals, _link_call_graphs) only check key
# existence or iterate names — they never access Symbol object attributes —
# so empty lists in the registry are sufficient.
# ---------------------------------------------------------------------------

def _sym_compact_key(file_path: Path) -> str:
    """Stable filename for the pickled compact symbol list of *file_path*."""
    return hashlib.md5(str(file_path).encode()).hexdigest() + "_symc.pkl"


def _dump_sym_compact(sym_compact, cache_dir: Path, file_path: Path) -> None:
    """Pickle *sym_compact* [(name, type_value), ...] to *cache_dir*."""
    try:
        dest = cache_dir / _sym_compact_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(sym_compact, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        _log.warning("Could not cache sym_compact for %s: %s", file_path.name, exc)


def _load_sym_compact(cache_dir: Path, file_path: Path):
    """Unpickle and return compact symbol list for *file_path*, or None on miss."""
    try:
        src = cache_dir / _sym_compact_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        _log.warning("Could not reload sym_compact for %s: %s", file_path.name, exc)
        return None


def _dump_statements(stmts, cache_dir: Path, file_path: Path) -> None:
    """Pickle *stmts* to *cache_dir*. Silently skips on error."""
    try:
        dest = cache_dir / _stmt_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(stmts, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        _log.warning("Could not cache statements for %s: %s", file_path.name, exc)


def _load_statements(cache_dir: Path, file_path: Path):
    """Unpickle and return the statements for *file_path*, or None on miss."""
    try:
        src = cache_dir / _stmt_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        _log.warning("Could not reload statements for %s: %s", file_path.name, exc)
        return None


# ---------------------------------------------------------------------------
# C-family unit cache helpers — mirrors the statements helpers above.
#
# C/C++ FileAnalysisResult objects carry an analysis_context.metadata entry
# "c_family_unit" (a CFamilyUnit object containing structs, field mappings,
# enum values, symbol aliases).  For 3–4 K C/C++ files these objects can
# total 1–2 GB of heap across all results simultaneously.  We serialise each
# file's unit to disk immediately after the batch worker returns it, reload
# per-file only for the Phase-5 stitching window + emission, then discard.
# ---------------------------------------------------------------------------

def _unit_key(file_path: Path) -> str:
    """Stable filename for the pickled c_family_unit of *file_path*."""
    return hashlib.md5(str(file_path).encode()).hexdigest() + "_unit.pkl"


def _dump_unit(unit, cache_dir: Path, file_path: Path) -> None:
    """Pickle *unit* to *cache_dir*. Silently skips on error."""
    try:
        dest = cache_dir / _unit_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(unit, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        _log.warning("Could not cache c_family_unit for %s: %s", file_path.name, exc)


def _load_unit(cache_dir: Path, file_path: Path):
    """Unpickle and return the c_family_unit for *file_path*, or None on miss."""
    try:
        src = cache_dir / _unit_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        _log.warning("Could not reload c_family_unit for %s: %s", file_path.name, exc)
        return None


# ---------------------------------------------------------------------------
# block_analysis cache helpers — same pattern as statements and unit caches.
#
# ASM FileAnalysisResult objects carry context.metadata["block_analysis"]
# (a BlockAnalysisResult with FlowItem lists for every block/subroutine).
# For large ASM files this can be 40–100 KB per file, totalling 0.6–1.5 GB
# across 15 K files.  Evict per-batch; reload per-file at emission time.
# ---------------------------------------------------------------------------

def _block_key(file_path: Path) -> str:
    """Stable filename for the pickled block_analysis of *file_path*."""
    return hashlib.md5(str(file_path).encode()).hexdigest() + "_block.pkl"


def _dump_block(block, cache_dir: Path, file_path: Path) -> None:
    """Pickle *block* to *cache_dir*. Silently skips on error."""
    try:
        dest = cache_dir / _block_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(block, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        _log.warning("Could not cache block_analysis for %s: %s", file_path.name, exc)


def _load_block(cache_dir: Path, file_path: Path):
    """Unpickle and return the block_analysis for *file_path*, or None on miss."""
    try:
        src = cache_dir / _block_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        _log.warning("Could not reload block_analysis for %s: %s", file_path.name, exc)
        return None


# ---------------------------------------------------------------------------
# line_metadata_index cache helpers — same pattern.
#
# AnalysisContext carries a .line_metadata_index field (LineMetadataIndex
# object) with per-line codeblock/conditional/call context.  For a
# 2 K–10 K line file this can be 40–200 KB; totals 0.6–3 GB across 15 K files.
# Evict per-batch; reload per-file at emission time.
# ---------------------------------------------------------------------------

def _lmi_key(file_path: Path) -> str:
    """Stable filename for the pickled line_metadata_index of *file_path*."""
    return hashlib.md5(str(file_path).encode()).hexdigest() + "_lmi.pkl"


def _dump_lmi(lmi, cache_dir: Path, file_path: Path) -> None:
    """Pickle *lmi* to *cache_dir*. Silently skips on error."""
    try:
        dest = cache_dir / _lmi_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(lmi, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        _log.warning("Could not cache line_metadata_index for %s: %s", file_path.name, exc)


def _load_lmi(cache_dir: Path, file_path: Path):
    """Unpickle and return the line_metadata_index for *file_path*, or None on miss."""
    try:
        src = cache_dir / _lmi_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        _log.warning("Could not reload line_metadata_index for %s: %s", file_path.name, exc)
        return None


def _dump_lineage(graph, cache_dir: Path, file_path: Path) -> None:
    """Pickle *graph* to *cache_dir*. Silently skips on error."""
    try:
        dest = cache_dir / _lineage_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(graph, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        _log.warning("Could not cache lineage for %s: %s", file_path.name, exc)


def _load_lineage(cache_dir: Path, file_path: Path):
    """Unpickle and return the lineage graph for *file_path*, or None on miss."""
    try:
        src = cache_dir / _lineage_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        _log.warning("Could not reload lineage for %s: %s", file_path.name, exc)
        return None


# ---------------------------------------------------------------------------
# macro_expansions cache helpers — same pattern as statements / lineage.
#
# After Phase 4 (macro expansion), each FileAnalysisResult's analysis_context
# holds a context.macro_expansions list of ExpansionResult objects.  Each
# object contains ExpandedInstruction lists and an expanded_call_graph dict,
# totalling ~1–3 MB per ASM file.  For 11 K+ files this accumulates
# 11–33 GB before Phase 5 (stitching) even starts.
#
# Fix: evict the full ExpansionResult list to disk after per-file processing,
# replace with lightweight stubs that satisfy the GlobalLineageStitcher
# (which only reads expansion_status and parameters), then reload full objects
# per-file during blueprint emission.
# ---------------------------------------------------------------------------

def _me_key(file_path: Path) -> str:
    """Stable filename for the pickled macro_expansions of *file_path*."""
    return hashlib.md5(str(file_path).encode()).hexdigest() + "_me.pkl"


def _dump_macro_expansions(expansions, cache_dir: Path, file_path: Path) -> None:
    """Pickle *expansions* to *cache_dir*. Silently skips on error."""
    try:
        dest = cache_dir / _me_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(expansions, fh, protocol=pickle.HIGHEST_PROTOCOL)
            _fadvise_dontneed(fh.fileno())
    except Exception as exc:
        _log.warning("Could not cache macro_expansions for %s: %s", file_path.name, exc)


def _load_macro_expansions(cache_dir: Path, file_path: Path):
    """Unpickle and return the macro_expansions for *file_path*, or None on miss."""
    try:
        src = cache_dir / _me_key(file_path)
        if not src.exists():
            return None
        with open(src, "rb") as fh:
            data = pickle.load(fh)
            _fadvise_dontneed(fh.fileno())
        return data
    except Exception as exc:
        _log.warning("Could not reload macro_expansions for %s: %s", file_path.name, exc)
        return None


def _evict_lineage(file_results, cache_dir: Path) -> int:
    """Serialize all lineage graphs to *cache_dir* and free them from memory.

    Returns the number of graphs evicted.
    """
    evicted = 0
    for fr in file_results:
        graph = fr.analysis_context.get_metadata("variable_lineage")
        if graph is not None:
            _dump_lineage(graph, cache_dir, fr.file_path)
            fr.analysis_context.metadata.pop("variable_lineage", None)
            evicted += 1
    return evicted


def _restore_lineage(file_results, cache_dir: Path) -> int:
    """Reload all lineage graphs from *cache_dir* back into their contexts.

    Returns the number of graphs restored.
    """
    restored = 0
    for fr in file_results:
        graph = _load_lineage(cache_dir, fr.file_path)
        if graph is not None:
            fr.analysis_context.add_metadata("variable_lineage", graph)
            restored += 1
    return restored

from multi_file.single_file_analyzer import SingleFileAnalyzer, FileAnalysisResult
from multi_file.c_family_analyzer import CFamilyAnalyzer, CFileAnalysisResult
from multi_file.makefile_analyzer import MakefileAnalyzer
from multi_file.symbol_registry import GlobalSymbolRegistry
from cache.file_cache import FileAnalysisCache
from models.symbol import SymbolType
from passes.macro_collector import MacroCollector
from passes.macro_expansion_pass import MacroExpansionPass
from passes.call_graph_builder import CallGraphBuilderPass
from passes.global_lineage_stitcher import GlobalLineageStitcher
from macro_library import MacroLibrary, PerFileOverrideView
from models.variable_lineage import VariableLineageGraph


# Extension sets used both by the class and the module-level worker function.
_ASM_EXTS  = {".asm", ".mac", ".s", ".cpy", ".copy"}
_C_EXTS    = {".c"}
_CPP_EXTS  = {".cc", ".cpp", ".cxx", ".hpp", ".h"}
_MAKE_EXTS = {".mak"}
_MAKE_NAMES = {"Makefile", "makefile", "GNUmakefile"}


# ---------------------------------------------------------------------------
# Module-level worker function — must be at module scope for ProcessPoolExecutor
# pickling to work with the 'spawn' start method (macOS default, Python 3.10+).
# ---------------------------------------------------------------------------

def _worker_init() -> None:
    """Initializer for ProcessPoolExecutor workers (mirrors orchestrator.py).

    - Raises the nice value so analysis subprocesses yield CPU to the OS
      and the Celery parent under contention (no effect on Windows).
    - Ignores SIGINT so Ctrl-C in the parent doesn't cascade to workers.
    """
    try:
        os.nice(5)
    except OSError:
        pass
    signal.signal(signal.SIGINT, signal.SIG_IGN)


def _analyze_mixed_batch(
    batch: List[Path],
    search_paths: List[Path],
    universe_asm_names: set,
    universe_cpp_names: set,
    cache_dir: Path,
    file_timeout: int = 300,
) -> List[FileAnalysisResult]:
    """Analyze a mixed-language batch (ASM/C/C++/Make) in a worker process.

    Creates its own per-language analyzer instances — nothing is shared with
    the main process or other workers.

    A SIGALRM-based per-file timeout (file_timeout seconds) is applied on
    Unix so that a single pathological file cannot hang the entire batch.
    Files that exceed the timeout are logged and skipped; processing continues
    with the remaining files in the batch.  (SIGALRM is not available on
    Windows — the guard is silently bypassed there.)
    """
    asm_analyzer  = SingleFileAnalyzer(search_paths)
    c_analyzer    = CFamilyAnalyzer("c",   search_paths=search_paths)
    cpp_analyzer  = CFamilyAnalyzer("cpp", search_paths=search_paths)
    make_analyzer = MakefileAnalyzer()

    _has_sigalrm = hasattr(signal, "SIGALRM")

    class _FileTimeout(Exception):
        pass

    def _alarm_handler(signum, frame):
        raise _FileTimeout()

    results: List[FileAnalysisResult] = []
    for file_path in batch:
        suffix = file_path.suffix.lower()

        # --- per-file timeout: arm ---
        if _has_sigalrm:
            signal.signal(signal.SIGALRM, _alarm_handler)
            signal.alarm(file_timeout)

        try:
            file_content = file_path.read_text(encoding="latin-1")

            if suffix in _ASM_EXTS:
                result = asm_analyzer.analyze(file_path, file_content)
            elif suffix in _C_EXTS:
                result = c_analyzer.analyze(file_path, file_content)
            elif suffix in _CPP_EXTS:
                result = cpp_analyzer.analyze(file_path, file_content)
            elif suffix in _MAKE_EXTS or file_path.name in _MAKE_NAMES:
                result = make_analyzer.analyze(file_path, file_content)
            else:
                continue

            if suffix in _ASM_EXTS | _C_EXTS | _CPP_EXTS:
                if universe_asm_names:
                    result.analysis_context.set_variable_names("asm", universe_asm_names)
                if universe_cpp_names:
                    result.analysis_context.set_variable_names("cpp", universe_cpp_names)

            # Clear variable_names before returning to parent.
            # These are identical across all files (drawn from the shared universe)
            # but IPC-pickle + parent-unpack creates a full per-result copy of
            # all ~1 700 name strings.  For 15 K files that is ~3–5 GB of wasted
            # heap.  The parent already owns the universe; it does not need them
            # back in the result.
            result.analysis_context.variable_names = {"asm": set(), "cpp": set()}

            # Clear metadata fields that are only consumed by the pure-ASM
            # MultiFileOrchestrator path, NOT this MixedLanguageOrchestrator:
            #
            #   data_flow_tracker     — DataFlowTracker object set by
            #                           passes/data_flow_tracker.py; consumed
            #                           only in orchestrator.py (pure-ASM path).
            #                           ~200 KB/ASM file × 11 K files ≈ 2.2 GB.
            #
            #   resolved_indirect_calls — dict of resolved call targets; set by
            #                             the same pass; consumed only in
            #                             orchestrator.py:_merge_data_flow().
            #                             ~50 KB/file × 11 K ≈ 550 MB.
            #
            # Clearing them here prevents ~2.3 GB of wasted heap in the parent.
            result.analysis_context.metadata.pop("data_flow_tracker", None)
            result.analysis_context.metadata.pop("resolved_indirect_calls", None)

            results.append(result)

        except _FileTimeout:
            _log.warning(
                "_analyze_mixed_batch: file timed out after %ds, skipping: %s",
                file_timeout, file_path,
            )
        except Exception as exc:
            _log.error(
                "_analyze_mixed_batch: error analyzing %s: %s: %s",
                file_path, type(exc).__name__, exc,
            )
        finally:
            # --- per-file timeout: disarm ---
            if _has_sigalrm:
                signal.alarm(0)

    return results


@dataclass
class MixedAnalysisResult:
    file_results: List[FileAnalysisResult]
    global_registry: Optional[GlobalSymbolRegistry]
    unresolved_externals: List[str]
    global_lineage: Optional[VariableLineageGraph] = None
    # Paths to on-disk caches for metadata that was evicted during Phase 1
    # batch collection to reduce peak RSS.  The emission layer (_emit_one_file
    # in analysis_task.py) reloads from these dirs per-file at emit time.
    # None when the orchestrator ran without eviction (e.g. small corpora).
    block_cache_dir: Optional[Path] = None
    lmi_cache_dir: Optional[Path] = None
    # macro_expansions eviction cache — full ExpansionResult objects are evicted
    # per-file during Phase 4 and reloaded per-file at blueprint emission time.
    macro_exp_cache_dir: Optional[Path] = None
    # c_family_unit eviction cache — full CFamilyUnit objects stay on disk
    # after Phase 5 stitching (only compact stubs are loaded into contexts
    # for the stitcher).  The emission layer reloads full units per-file.
    unit_cache_dir: Optional[Path] = None
    # symbol_table eviction cache — symbol_tables are saved here before Phase 5
    # stitching (to free 2–5 GB of heap) and reloaded per-file at emission time.
    sym_cache_dir: Optional[Path] = None
    # call_graph eviction cache — ASM call_graphs are serialised here before
    # Phase 5 pre-stitch eviction and reloaded per-file at blueprint emission
    # time so that per-file blueprints contain real call_graph data.
    call_graph_cache_dir: Optional[Path] = None
    # lineage cache — per-file variable_lineage graphs are serialised here
    # during Phase 1 batch collection and Phase 4 macro annotation, then
    # reloaded one-at-a-time at blueprint emission time so that each blueprint
    # contains real variable_lineage data.
    lineage_cache_dir: Optional[Path] = None


class MixedLanguageOrchestrator:
    """Orchestrates analysis across assembly and C/C++ files."""

    ASM_EXTENSIONS = {".asm", ".mac", ".s", ".cpy", ".copy"}
    C_EXTENSIONS = {".c"}
    CPP_EXTENSIONS = {".cc", ".cpp", ".cxx", ".hpp", ".h"}
    MAKE_EXTENSIONS = {".mak"}
    MAKEFILE_NAMES = {"makefile", "Makefile", "GNUmakefile"}

    def __init__(self, cache_dir: Path, search_paths: List[Path], macro_libs: Optional[List[Path]] = None,
                 universe_asm_names=None, universe_cpp_names=None):
        self.cache = FileAnalysisCache(cache_dir)
        self.asm_analyzer = SingleFileAnalyzer(search_paths)
        self.c_analyzer = CFamilyAnalyzer("c", search_paths=search_paths)
        self.cpp_analyzer = CFamilyAnalyzer("cpp", search_paths=search_paths)
        self.make_analyzer = MakefileAnalyzer()
        self.search_paths = search_paths
        self.macro_libs = macro_libs if macro_libs else []
        self.universe_asm_names = universe_asm_names if universe_asm_names else set()
        self.universe_cpp_names = universe_cpp_names if universe_cpp_names else set()
        self._include_re = re.compile(r'^\s*#\s*include\s*"([^"]+)"', re.MULTILINE)

    def analyze_files(
        self,
        file_paths: List[Path],
        analysis_workers: int = 1,
        batch_size: int = 20,
        file_timeout: int = 300,
    ) -> MixedAnalysisResult:
        file_paths = self._expand_with_local_headers(file_paths)

        # Phase 1: Individual file analysis
        batches = [
            file_paths[i : i + batch_size]
            for i in range(0, len(file_paths), batch_size)
        ]

        _log.info(
            "Phase 1: per-file batch analysis — %d files, %d batch(es), %d worker(s), batch_size=%d",
            len(file_paths), len(batches), analysis_workers, batch_size,
        )
        print(
            f"[{time.strftime('%H:%M:%S')}] Phase 1: per-file batch analysis — "
            f"{len(file_paths)} file(s) across {len(batches)} batch(es), "
            f"{analysis_workers} worker(s), batch_size={batch_size}",
            flush=True,
        )
        print(
            f"[{time.strftime('%H:%M:%S')}]   Parsing each file: symbols, call-graph nodes, "
            f"variable-lineage edges, EXTRN/ENTRY declarations.",
            flush=True,
        )

        file_results: List[FileAnalysisResult] = []

        # ------------------------------------------------------------------
        # Heavy metadata eviction caches.
        #
        # Batch workers clear variable_names, data_flow_tracker, and
        # resolved_indirect_calls before returning.  However several large
        # objects still accumulate in the parent as results arrive:
        #
        #   statements (ASM files)   — all parsed Statement objects, 5–8 GB
        #                              across 15 K files.  Evict to disk;
        #                              reload one-at-a-time in Phase 4 (macro
        #                              expansion) where they are needed.
        #
        #   c_family_unit (C/C++)    — parsed struct/field/alias AST objects,
        #                              ~400 KB each × 3–4 K files ≈ 1–2 GB.
        #                              Evict to disk; bulk-reload before Phase 5
        #                              stitching and keep through blueprint emission.
        # ------------------------------------------------------------------
        _statements_dir = self.cache.cache_dir / "statements_cache"
        _statements_dir.mkdir(parents=True, exist_ok=True)

        _unit_cache_dir = self.cache.cache_dir / "unit_cache"
        _unit_cache_dir.mkdir(parents=True, exist_ok=True)

        # block_analysis and line_metadata_index (emit-time only) cache dirs.
        # These objects are needed only for JSON blueprint emission (json_emitter.py)
        # and are not used in any cross-file resolution phase (2, 4, or 5).
        # Evicting them per-batch saves 0.6–1.5 GB per cache across 15 K files.
        _block_cache_dir = self.cache.cache_dir / "block_cache"
        _block_cache_dir.mkdir(parents=True, exist_ok=True)

        _lmi_cache_dir = self.cache.cache_dir / "lmi_cache"
        _lmi_cache_dir.mkdir(parents=True, exist_ok=True)

        # macro_expansions eviction cache — created before Phase 4 (used there)
        # but declared alongside other cache dirs for clarity.  Full
        # ExpansionResult lists are evicted here per-file; lightweight stubs
        # remain in contexts for Phase 5 stitching.
        _macro_exp_dir = self.cache.cache_dir / "macro_exp_cache"
        _macro_exp_dir.mkdir(parents=True, exist_ok=True)

        # Lineage cache is created here (before the batch loop) so that
        # variable_lineage graphs can be evicted to disk AS EACH BATCH ARRIVES
        # rather than only after all batches have been collected.  For 15 K
        # files, variable_lineage graphs can total 4–6 GB; holding them all in
        # RAM simultaneously is the primary cause of OOM during Phase 1 batch
        # collection.  Phase 4 (macro annotation) already handles lazy reload
        # from this same directory, so early eviction is fully transparent.
        _lineage_dir = self.cache.cache_dir / "lineage_cache"
        _lineage_dir.mkdir(parents=True, exist_ok=True)

        # call_graph cache — ASM call_graphs are serialised here before Phase 5
        # eviction and reloaded per-file at blueprint emission time.
        _call_graph_cache_dir = self.cache.cache_dir / "call_graph_cache"
        _call_graph_cache_dir.mkdir(parents=True, exist_ok=True)

        # Compact symbol cache — symbol_table.all_symbols is evicted per-batch
        # as (name, symbol_type_value) tuples to save ~4.5 GB during Phase 1.
        # _build_global_registry and _link_call_graphs stream from this dir.
        _sym_compact_dir = self.cache.cache_dir / "sym_compact_cache"
        _sym_compact_dir.mkdir(parents=True, exist_ok=True)

        def _evict_batch_heavy_metadata(batch_results):
            # Each file's eviction is independent — different output files, different
            # FileAnalysisResult objects.  Run all files in the batch concurrently
            # using a thread pool: pickle I/O releases the GIL so threads give real
            # parallelism for the disk-write portions without touching ANALYSIS_WORKERS.
            def _evict_one(_r):
                # Statements (ASM files only) — needed only in Phase 2.75.
                if _r.analysis_context.statements:
                    _dump_statements(
                        _r.analysis_context.statements,
                        _statements_dir,
                        _r.file_path,
                    )
                    _r.analysis_context.statements = []
                # c_family_unit (C/C++ files only) — Phase 5 stitching + emit.
                _unit = _r.analysis_context.metadata.get("c_family_unit")
                if _unit is not None:
                    _dump_unit(_unit, _unit_cache_dir, _r.file_path)
                    _r.analysis_context.metadata.pop("c_family_unit", None)
                # variable_lineage (ALL files) — Phase 4 + emit.
                _graph = _r.analysis_context.metadata.get("variable_lineage")
                if _graph is not None:
                    _dump_lineage(_graph, _lineage_dir, _r.file_path)
                    _r.analysis_context.metadata.pop("variable_lineage", None)
                # block_analysis (ALL files) — emit only.
                _block = _r.analysis_context.metadata.get("block_analysis")
                if _block is not None:
                    _dump_block(_block, _block_cache_dir, _r.file_path)
                    _r.analysis_context.metadata.pop("block_analysis", None)
                # line_metadata_index (ALL files) — emit only.
                _lmi = getattr(_r.analysis_context, "line_metadata_index", None)
                if _lmi is not None:
                    _dump_lmi(_lmi, _lmi_cache_dir, _r.file_path)
                    _r.analysis_context.line_metadata_index = None
                # symbol_table.all_symbols → compact (name, type_value) tuples.
                # Saves ~4.5 GB across 30K files; Phase 2 streams from disk.
                _st = _r.symbol_table
                if _st is not None:
                    _syms = getattr(_st, "all_symbols", None)
                    if _syms:
                        _dump_sym_compact(
                            [(s.name, s.symbol_type.value) for s in _syms],
                            _sym_compact_dir,
                            _r.file_path,
                        )
                        _st.all_symbols = []

            _n_evict = min(len(batch_results), 8)
            if _n_evict <= 1:
                for _r in batch_results:
                    _evict_one(_r)
            else:
                with ThreadPoolExecutor(max_workers=_n_evict) as _evict_pool:
                    list(_evict_pool.map(_evict_one, batch_results))

        if analysis_workers > 1 and len(batches) > 1:
            # On macOS/Python ≥ 3.10 the default multiprocessing start method
            # is 'spawn', which tries to pickle the process AuthenticationString
            # — forbidden inside a Celery ForkPoolWorker.  Force 'fork' so the
            # child inherits the parent's address space without pickling.
            # Falls back to the default context on platforms where 'fork' is
            # unavailable (e.g. Windows).
            try:
                _mp_ctx = multiprocessing.get_context("fork")
            except ValueError:
                _mp_ctx = None  # use default context on Windows

            # Celery ForkPoolWorker runs as a daemon process; Python normally
            # prevents daemon processes from spawning children.  Temporarily
            # clear the daemon flag so ProcessPoolExecutor can fork workers,
            # then restore it afterwards.
            _proc = multiprocessing.current_process()
            _was_daemon = _proc.daemon
            if _was_daemon:
                _proc.daemon = False
            try:
                _executor_kwargs = {
                    "max_workers": analysis_workers,
                    "initializer": _worker_init,
                }
                if _mp_ctx is not None:
                    _executor_kwargs["mp_context"] = _mp_ctx
                with ProcessPoolExecutor(**_executor_kwargs) as executor:
                    futures = [
                        executor.submit(
                            _analyze_mixed_batch,
                            batch,
                            self.search_paths,
                            self.universe_asm_names,
                            self.universe_cpp_names,
                            self.cache.cache_dir,
                            file_timeout,
                        )
                        for batch in batches
                    ]
                    for future in as_completed(futures):
                        _batch = future.result()
                        _evict_batch_heavy_metadata(_batch)
                        file_results.extend(_batch)
            finally:
                if _was_daemon:
                    _proc.daemon = True
        else:
            for batch in batches:
                _batch = _analyze_mixed_batch(
                    batch,
                    self.search_paths,
                    self.universe_asm_names,
                    self.universe_cpp_names,
                    self.cache.cache_dir,
                    file_timeout,
                )
                _evict_batch_heavy_metadata(_batch)
                file_results.extend(_batch)

        # ------------------------------------------------------------------
        # Lineage graphs were already evicted to disk per-batch inside
        # _evict_batch_heavy_metadata above.  Run a safety-net eviction pass
        # for any graph that slipped through (e.g. sequential path or resize),
        # then force a GC cycle to reclaim any fragmentation.
        # ------------------------------------------------------------------
        _leftover = _evict_lineage(file_results, _lineage_dir)
        gc.collect()
        _log.info(
            "Lazy-load: per-batch lineage eviction done; leftover=%d evicted now → %s",
            _leftover, _lineage_dir,
        )
        print(
            f"[{time.strftime('%H:%M:%S')}] Lazy-load: lineage graphs offloaded to disk "
            f"(per-batch; {_leftover} leftover evicted now — phases 2–4 run lighter).",
            flush=True,
        )

        _log.info("Phase 2: cross-file resolution — %d file results", len(file_results))
        print(
            f"[{time.strftime('%H:%M:%S')}] Phase 2: cross-file resolution — "
            f"building global EXTRN/ENTRY registry and linking call-graph edges "
            f"across {len(file_results)} file(s).",
            flush=True,
        )
        global_registry = self._build_global_registry(file_results, sym_compact_dir=_sym_compact_dir)
        unresolved_externals = self._find_unresolved_externals(global_registry)

        self._link_call_graphs(file_results, sym_compact_dir=_sym_compact_dir)

        # Free top-level symbol_table and call_graph from every FileAnalysisResult.
        # These fields were only needed by _build_global_registry and
        # _link_call_graphs above.  For 50K files they total 2–10 GB of heap
        # that would otherwise remain live through macro expansion, stitching,
        # and the context checkpoint save.
        # Note: analysis_context.symbol_table / analysis_context.call_graph
        # remain intact (they are separate attributes on the context object
        # used by json_emitter.py at blueprint emission time).
        # symbol_table and call_graph on each FileAnalysisResult are no longer
        # needed after cross-file resolution (_link_call_graphs, _find_unresolved_externals).
        # For 30K+ files they can total 2–10 GB.  gc.collect() alone does not
        # return pages to the OS — malloc_trim(0) forces glibc to release them
        # so the cgroup counter actually drops before macro expansion.
        for _fr in file_results:
            _fr.symbol_table = None
            _fr.call_graph = None
        gc.collect()
        try:
            import ctypes as _ct_p2
            for _libc_p2 in ("libc.so.6", "libc.so", "libSystem.B.dylib", "libc.dylib"):
                try:
                    _ct_p2.CDLL(_libc_p2).malloc_trim(0)
                    break
                except Exception:
                    pass
        except Exception:
            pass

        # Free GlobalSymbolRegistry immediately — only consumers were
        # _find_unresolved_externals (line 791) and _build_global_registry.
        # _link_call_graphs above does NOT take it as an argument.
        # The registry is dict/list overhead pointing to Symbol objects already
        # in file_results (~50 MB); freeing it here and trimming ensures no
        # stale references persist into macro expansion and lineage stitching.
        global_registry = None
        gc.collect()
        try:
            import ctypes as _ct_reg
            for _libc_reg in ("libc.so.6", "libc.so", "libSystem.B.dylib", "libc.dylib"):
                try:
                    _ct_reg.CDLL(_libc_reg).malloc_trim(0)
                    break
                except Exception:
                    pass
        except Exception:
            pass

        # Macro collection and expansion for assembly-only contexts
        _log.info("Phase 2.5: macro collection — %d search path(s)", len(self.search_paths))
        print(
            f"[{time.strftime('%H:%M:%S')}] Phase 2.5: macro collection — "
            f"auto-discovering macro definitions from {len(self.search_paths)} search path(s).",
            flush=True,
        )
        macro_collector = MacroCollector(self.search_paths)
        macro_library = macro_collector.auto_discover()
        if self.macro_libs:
            macro_library = macro_collector.collect_from_files(self.macro_libs, macro_library)

        # Pre-Phase-4 page cache sweep.
        #
        # During Phase 1 batch analysis, ~30 K pickle files were written to
        # cache dirs (lineage, statements, sym_compact, block, lmi, unit).
        # POSIX_FADV_DONTNEED is called after each individual write/read, but
        # the kernel treats it as a hint and may defer reclaim while RAM is
        # plentiful.  By Phase 4, these files can occupy 5–8 GB of reclaimable
        # page cache, pushing cgroup memory.current above the 90% skip
        # threshold even though real Python heap is only 4–5 GB.
        #
        # Sweeping all cache dirs here forces immediate reclaim so Phase 4
        # starts with the page-cache slate clean (~35% cgroup vs ~89%).
        # sym_compact_dir and lineage_dir are also swept even though Phase 4
        # re-reads them (statements, lineage): per-file fadvise-after-read
        # keeps pages from re-accumulating during the expansion loop.
        _p4_cache_dirs = [
            _sym_compact_dir,
            _lineage_dir,
            _statements_dir,
            _block_cache_dir,
            _lmi_cache_dir,
            _unit_cache_dir,
            _macro_exp_dir,
        ]
        _p4_swept = _drop_page_cache(_p4_cache_dirs)
        _log.info(
            "Pre-Phase-4 page-cache sweep: %d cache file(s) fadvised DONTNEED "
            "across %d dir(s) — cgroup reclaimable should drop ~5–8 GB.",
            _p4_swept, len(_p4_cache_dirs),
        )
        print(
            f"[{time.strftime('%H:%M:%S')}] Pre-Phase-4 page-cache sweep: "
            f"{_p4_swept} files fadvised — freeing ~5–8 GB reclaimable cache.",
            flush=True,
        )

        # Phase 4: Macro expansion — pre-filter to ASM non-library files so we
        # know the total count upfront for accurate progress/ETA reporting.
        _p4_asm_results = [
            fr for fr in file_results
            if fr.file_path.suffix.lower() in self.ASM_EXTENSIONS
            and not fr.analysis_context.get_metadata("is_macro_library")
        ]
        _p4_total = len(_p4_asm_results)
        _p4_start = time.time()
        _log.info("Phase 4: macro expansion starting for %d ASM file(s)", _p4_total)
        print(
            f"[{time.strftime('%H:%M:%S')}] Phase 4: macro expansion — "
            f"{_p4_total} ASM file(s)",
            flush=True,
        )

        # Per-file SIGALRM timeout for macro expansion (same guard as Phase 1).
        # A recursive or excessively complex macro definition can cause expand_all()
        # to loop indefinitely.  The alarm fires after file_timeout seconds and the
        # file is skipped, so one pathological file cannot hang the entire pipeline.
        _has_sigalrm = hasattr(signal, "SIGALRM")

        class _MacroTimeout(BaseException):  # BaseException so expand()'s except Exception cannot swallow it
            pass

        def _macro_alarm(signum, frame):
            raise _MacroTimeout()

        # Scale the memory-check interval with corpus size.
        # Small corpora (≤1 K files): check every 50 files (low overhead).
        # Large corpora (50 K files): check every 10 files so the guard fires
        # before 100 × 2–3 MB/file = 200–300 MB accumulates undetected.
        _p4_check_interval = max(10, min(50, _p4_total // 100))
        # Periodic in-loop cache sweep — every 500 files re-sweep the dirs
        # that Phase 4 reads AND writes to prevent page cache from
        # re-accumulating during the expansion loop.
        # _macro_exp_dir is included because each file's full ExpansionResult
        # list is dumped here after processing; the kernel may keep those pages
        # in active_file cache between the per-file fadvise hint and actual
        # reclaim, inflating cgroup usage.
        _p4_sweep_interval = 500

        for _p4_idx, file_result in enumerate(_p4_asm_results, 1):
            # Periodic page-cache sweep — re-drop pages from dirs read/written
            # during Phase 4 (statements, lineage, macro_exp) so they don't
            # accumulate back faster than fadvise-after-read/write can clear them.
            if _p4_idx % _p4_sweep_interval == 0:
                _drop_page_cache([_statements_dir, _lineage_dir, _macro_exp_dir])
            # Memory guard — checked every _p4_check_interval files to
            # amortise syscall cost while still catching memory pressure early.
            # If cgroup non-reclaimable usage exceeds _MEM_SKIP_RATIO of the
            # limit, skip this file's macro expansion rather than risking
            # SIGKILL.  The file retains its Phase 1 blueprint; it just won't
            # have expanded macros.
            if _p4_idx % _p4_check_interval == 0:
                _ratio = _rss_ratio()
                if _ratio > _MEM_SKIP_RATIO:
                    _log.warning(
                        "Phase 4: memory at %.1f%% of cgroup limit (threshold %.0f%%) — "
                        "skipping macro expansion for %s (%d/%d).",
                        _ratio * 100, _MEM_SKIP_RATIO * 100,
                        file_result.file_path.name, _p4_idx, _p4_total,
                    )
                    print(
                        f"[{time.strftime('%H:%M:%S')}] Phase 4: MEM-SKIP "
                        f"({_ratio*100:.0f}% > {_MEM_SKIP_RATIO*100:.0f}%) — "
                        f"skipping {file_result.file_path.name} ({_p4_idx}/{_p4_total})",
                        flush=True,
                    )
                    continue

            _log.info(
                "Phase 4: [%d/%d] expanding macros in %s",
                _p4_idx, _p4_total, file_result.file_path.name,
            )
            print(
                f"[{time.strftime('%H:%M:%S')}] Phase 4: [{_p4_idx}/{_p4_total}] "
                f"{file_result.file_path.name}",
                flush=True,
            )
            # Lazy-load statements from disk (evicted during Phase 1 batch
            # collection to reduce the sustained memory footprint).
            _p4_stmts = _load_statements(_statements_dir, file_result.file_path)
            if _p4_stmts is not None:
                file_result.analysis_context.statements = _p4_stmts
            # Lazy-load: restore this file's lineage graph for annotation,
            # then evict it again immediately after — keeps only 1 graph in RAM.
            _p4_lineage = _load_lineage(_lineage_dir, file_result.file_path)
            if _p4_lineage is not None:
                file_result.analysis_context.add_metadata("variable_lineage", _p4_lineage)
            if _has_sigalrm:
                signal.signal(signal.SIGALRM, _macro_alarm)
                signal.alarm(file_timeout)
            try:
                inline_library = macro_collector.collect_inline_macros(file_result.file_path)
                per_file_library = PerFileOverrideView(macro_library, inline_library.get_all_macros())

                macro_pass = MacroExpansionPass(per_file_library)
                expansions = macro_pass.expand_all(file_result.analysis_context)
                macro_pass.update_context(file_result.analysis_context, expansions)
                self._annotate_lineage_macro_parents(file_result.analysis_context)

                call_graph_builder = CallGraphBuilderPass()
                call_graph_builder.build_expanded_graphs(file_result.analysis_context)

                # Re-persist the (now annotated) lineage graph and evict from memory.
                _updated_lineage = file_result.analysis_context.get_metadata("variable_lineage")
                if _updated_lineage is not None:
                    _dump_lineage(_updated_lineage, _lineage_dir, file_result.file_path)
                    file_result.analysis_context.metadata.pop("variable_lineage", None)

                # Explicitly release per-iteration temporaries so their memory is
                # reclaimable before the next file.  Without this, Python's cyclic GC
                # may not collect analysis_context-referencing objects promptly across
                # thousands of files, causing RSS to grow until the OS OOM-kills the worker.
                del inline_library, per_file_library, macro_pass, expansions, call_graph_builder

                # Evict full macro_expansions to disk; replace with lightweight stubs.
                # Phase 5 stitcher only reads expansion_status + parameters — stubs
                # satisfy that.  Full objects are reloaded per-file at emission time.
                # Without eviction, ExpansionResult objects accumulate 1–3 MB per file
                # across 11 K+ files, causing OOM before Phase 5 starts.
                _full_exps = getattr(file_result.analysis_context, "macro_expansions", None)
                if _full_exps:
                    _dump_macro_expansions(_full_exps, _macro_exp_dir, file_result.file_path)
                    from types import SimpleNamespace as _NS
                    file_result.analysis_context.macro_expansions = [
                        _NS(
                            expansion_status=e.expansion_status,
                            parameters=getattr(e, "parameters", {}),
                        )
                        for e in _full_exps
                    ]
                    del _full_exps
            except _MacroTimeout:
                file_result.analysis_context.metadata.pop("variable_lineage", None)
                _log.warning(
                    "Phase 4: macro expansion timed out after %ds, skipping: %s",
                    file_timeout, file_result.file_path.name,
                )
                print(
                    f"[{time.strftime('%H:%M:%S')}] Phase 4: WARNING — macro expansion timed out "
                    f"after {file_timeout}s for {file_result.file_path.name}, skipping.",
                    flush=True,
                )
            except Exception as exc:
                file_result.analysis_context.metadata.pop("variable_lineage", None)
                _log.error(
                    "Phase 4: macro expansion failed for %s: %s: %s",
                    file_result.file_path.name, type(exc).__name__, exc,
                )
            finally:
                if _has_sigalrm:
                    signal.alarm(0)  # disarm regardless of outcome
                # Evict statements again now that macro expansion is done.
                file_result.analysis_context.statements = []
                # Free the inline macro cache entry — each file appears exactly once
                # in Phase 4, so the cached MacroLibrary is never reused.  Without
                # this, _inline_macro_cache accumulates one entry per ASM file,
                # consuming 200–1100 MB of RAM unnecessarily.
                macro_collector._inline_macro_cache.pop(
                    file_result.file_path.resolve(), None
                )

            if _p4_idx % 50 == 0 or _p4_idx == _p4_total:
                _elapsed = time.time() - _p4_start
                _rate = _p4_idx / _elapsed if _elapsed > 0 else 0
                _remaining = _p4_total - _p4_idx
                _eta_s = _remaining / _rate if _rate > 0 else 0
                print(
                    f"[{time.strftime('%H:%M:%S')}] Phase 4: {_p4_idx}/{_p4_total} files "
                    f"({_p4_idx * 100 // _p4_total}%) — "
                    f"{_rate:.1f} files/s — ETA {_eta_s / 60:.1f} min",
                    flush=True,
                )
                # Break any lingering reference cycles every 50 files, then
                # call malloc_trim so glibc returns freed heap pages to the OS.
                # Without malloc_trim the cgroup counter stays high even after
                # gc.collect() frees Python objects, causing false-positive
                # 90%-threshold triggers that skip files unnecessarily.
                gc.collect()
                try:
                    import ctypes as _ct_p4
                    for _lib_p4 in ("libc.so.6", "libc.so", "libSystem.B.dylib", "libc.dylib"):
                        try:
                            _ct_p4.CDLL(_lib_p4).malloc_trim(0)
                            break
                        except Exception:
                            pass
                except Exception:
                    pass

        _p4_elapsed = time.time() - _p4_start
        _log.info(
            "Phase 4: macro expansion done in %.1fs (%.1f files/s)",
            _p4_elapsed,
            _p4_total / _p4_elapsed if _p4_elapsed > 0 else 0,
        )

        # Clean up statements cache — no longer needed after Phase 4.
        try:
            import shutil as _shutil
            if _statements_dir.exists():
                _shutil.rmtree(_statements_dir, ignore_errors=True)
                _log.info("Phase 4: statements cache cleaned up — %s", _statements_dir)
        except Exception:
            pass

        # Free Phase-4-only objects — no longer needed before Phase 5.
        #
        # macro_library / macro_collector can hold 1–2 GB (auto-discover cache +
        # per-macro AST objects for all macro files in the corpus).  Freeing them
        # before the C/C++ unit reload in Phase 5 pre-stitch reduces peak RSS by
        # 1–2 GB, which is critical when 3 K+ unit files are loaded simultaneously.
        #
        # _p4_asm_results is a filtered view of file_results (just references); del
        # frees the list object but not the underlying FileAnalysisResult data.
        try:
            del macro_library, macro_collector
        except NameError:
            pass
        try:
            del _p4_asm_results
        except NameError:
            pass

        # Run a full GC cycle and release freed glibc pages to the OS before
        # the Phase 5 unit stub reload.  Without malloc_trim, pages freed
        # during Phase 4 (macro_library, _p4_asm_results, etc.) stay in
        # glibc's internal free-lists and do not count as available to the
        # OS — the cgroup memory counter stays high even though Python's live
        # heap is smaller.  Trimming first lets the OS reclaim those pages
        # before we load the unit stubs, reducing the pre-stitch peak.
        gc.collect()
        try:
            import ctypes as _ct
            for _n in ("libc.so.6", "libc.so", "libSystem.B.dylib", "libc.dylib"):
                try:
                    _ct.CDLL(_n).malloc_trim(0)
                    break
                except Exception:
                    pass
        except Exception:
            pass

        # Evict macro expansion cache files from the kernel page cache before
        # Phase 5 stitching.  Phase 4 re-reads these files during annotation,
        # populating page cache even though they were fadvised on write.
        # With 11K+ files at ~500 KB each this can amount to 4–6 GB of cgroup
        # usage that is entirely unreachable to the stitcher — evicting it now
        # can drop cgroup by 3–5 GB before the lineage merge starts, allowing
        # significantly more contexts to be stitched before the 88% guard fires.
        for _evict_dir in (_macro_exp_dir,):
            if _evict_dir is not None and _evict_dir.exists():
                _evicted = 0
                for _ef in _evict_dir.iterdir():
                    try:
                        with open(_ef, "rb") as _efh:
                            _fadvise_dontneed(_efh.fileno())
                        _evicted += 1
                    except Exception:
                        pass
                if _evicted:
                    _log.info(
                        "Pre-stitch page-cache eviction: %d file(s) in %s",
                        _evicted, _evict_dir.name,
                    )

        # ------------------------------------------------------------------
        # Reload c_family_unit stubs before Phase 5 stitching.
        #
        # c_family_unit objects were evicted to disk during Phase 1 batch
        # collection to keep the accumulated-results heap under control.
        #
        # Memory fix for 50K+ file corpora:
        #   Previously, full units were reloaded into every context here
        #   (10–20 GB simultaneously for a large mixed corpus), then the disk
        #   cache was deleted, forcing json_emitter.py to rely on the in-memory
        #   copies.  For large corpora this caused SIGKILL before stitching
        #   even started.
        #
        #   Now we load each unit, extract ONLY the 4 attributes that
        #   GlobalLineageStitcher actually reads (field_asm_aliases,
        #   field_asm_alias_sources, symbol_aliases, functions), and free the
        #   full unit immediately.  The stitcher's interface is unchanged —
        #   context.get_metadata("c_family_unit") returns the stub which
        #   exposes the same attribute names.
        #
        #   The full unit objects remain on disk in _unit_cache_dir.  The
        #   emission layer (_emit_one_file → _reload_evicted_metadata) reloads
        #   each full unit once per file at blueprint-write time, so at most
        #   one full unit is in memory per emission worker thread.
        #
        # Savings: ~400 KB/file → ~5–20 KB/file × N C++ files
        #   15K files: 6 GB → ~150 MB
        #   50K files: 20 GB → ~500 MB
        # ------------------------------------------------------------------
        from types import SimpleNamespace as _UnitNS
        _c_family_exts = self.C_EXTENSIONS | self.CPP_EXTENSIONS
        _reloaded_units = 0
        for _fr in file_results:
            if _fr.file_path.suffix.lower() in _c_family_exts:
                _unit = _load_unit(_unit_cache_dir, _fr.file_path)
                if _unit is not None:
                    # Build a lightweight stub containing only what the
                    # GlobalLineageStitcher accesses.  Pre-filter assignments
                    # to get_level call sites only (the only assignments the
                    # stitcher reads) to avoid copying thousands of entries.
                    _stub = _UnitNS(
                        field_asm_aliases=dict(
                            getattr(_unit, "field_asm_aliases", {}) or {}
                        ),
                        field_asm_alias_sources=dict(
                            getattr(_unit, "field_asm_alias_sources", {}) or {}
                        ),
                        symbol_aliases=dict(
                            getattr(_unit, "symbol_aliases", {}) or {}
                        ),
                        # Stitcher only reads .name from function objects.
                        functions=[
                            _UnitNS(name=f.name)
                            for f in (getattr(_unit, "functions", []) or [])
                        ],
                        # Only get_level assignments are used by
                        # _find_cpp_get_level_receivers; pre-filter here.
                        assignments=[
                            a for a in (getattr(_unit, "assignments", []) or [])
                            if "get_level" in (
                                getattr(a, "expression", "") or ""
                            ).lower()
                        ],
                    )
                    _fr.analysis_context.add_metadata("c_family_unit", _stub)
                    del _unit  # free full unit immediately after stub extraction
                    _reloaded_units += 1
        _log.info(
            "Phase 5 pre-stitch: loaded %d c_family_unit stub(s) — "
            "full units kept on disk at %s for per-file emission reload",
            _reloaded_units, _unit_cache_dir,
        )
        if _reloaded_units:
            print(
                f"[{time.strftime('%H:%M:%S')}] Phase 5: loaded {_reloaded_units} C/C++ unit "
                f"stubs (~5–20 KB/file) for stitching. Full units (~400 KB/file) kept on "
                f"disk and reloaded one-at-a-time during blueprint emission.",
                flush=True,
            )

        # Do NOT delete the unit disk cache here — full units are reloaded
        # per-file during blueprint emission (_emit_one_file calls
        # _reload_evicted_metadata which reads from unit_cache_dir).
        # The cache is passed back via MixedAnalysisResult.unit_cache_dir
        # and included in the emission manifest for the resumable path.

        # Free ASM call_graphs before Phase 5 stitching.
        #
        # GlobalLineageStitcher._collect_cpp_level_buffers() only reads call_graphs
        # from C/C++ contexts (it skips any context without a c_family_unit, which
        # covers all ASM files).  Keeping call_graphs for 15K ASM files in memory
        # through Phase 5 wastes ~50–150 KB per file (= 0.75–2.3 GB total) without
        # providing any benefit.  Freeing them here, immediately before stitching,
        # lowers the pre-merge RSS baseline and allows more contexts to be stitched
        # before the 88% memory guard fires.
        _c_family_exts = self.C_EXTENSIONS | self.CPP_EXTENSIONS
        _n_cg_freed = 0
        for _fr in file_results:
            if _fr.file_path.suffix.lower() not in _c_family_exts:
                _cg = _fr.analysis_context.metadata.pop("call_graph", None)
                if _cg is not None:
                    _dump_call_graph(_cg, _call_graph_cache_dir, _fr.file_path)
                    _n_cg_freed += 1
        if _n_cg_freed:
            gc.collect()
            try:
                import ctypes as _ct3
                for _libc3 in ("libc.so.6", "libc.so", "libSystem.B.dylib", "libc.dylib"):
                    try:
                        _ct3.CDLL(_libc3).malloc_trim(0)
                        break
                    except Exception:
                        pass
            except Exception:
                pass
            _log.info(
                "Phase 5 pre-stitch: freed call_graphs from %d ASM context(s); "
                "trimmed heap before lineage merge.",
                _n_cg_freed,
            )
            print(
                f"[{time.strftime('%H:%M:%S')}] Phase 5 pre-stitch: freed {_n_cg_freed} ASM "
                f"call_graph(s) from memory (not needed by stitcher).",
                flush=True,
            )

        _log.info(
            "Phase 5: variable lineage stitching — %d contexts (streaming from disk)",
            len(file_results),
        )
        print(
            f"[{time.strftime('%H:%M:%S')}] Phase 5: variable lineage stitching — "
            f"merging {len(file_results)} per-file lineage graph(s) into a single global graph "
            f"(graphs streamed from disk one at a time; no bulk reload).",
            flush=True,
        )
        # Create the symbol_table cache dir before Phase 5 stitching.
        # The stitcher saves each context's symbol_table here (after using it for
        # ENTRY/EXTRN collection in Phase 1) then nulls it to free 2–5 GB of heap
        # before the lineage-merge phase.  The emission layer reloads per-file.
        _sym_cache_dir = self.cache.cache_dir / "sym_cache"
        _sym_cache_dir.mkdir(parents=True, exist_ok=True)

        # Pass _lineage_dir so the stitcher streams each graph from disk during
        # Phase 2 merge rather than needing them all reloaded simultaneously.
        # Pass _sym_cache_dir so the stitcher saves symbol_tables before freeing them.
        self._stitch_variable_lineage(
            file_results,
            lineage_cache_dir=_lineage_dir,
            sym_cache_dir=_sym_cache_dir,
        )

        return MixedAnalysisResult(
            file_results=file_results,
            global_registry=None,  # freed above after _link_call_graphs
            unresolved_externals=unresolved_externals,
            global_lineage=self._collect_global_lineage(file_results),
            block_cache_dir=_block_cache_dir,
            lmi_cache_dir=_lmi_cache_dir,
            macro_exp_cache_dir=_macro_exp_dir,
            unit_cache_dir=_unit_cache_dir,
            sym_cache_dir=_sym_cache_dir,
            call_graph_cache_dir=_call_graph_cache_dir,
            lineage_cache_dir=_lineage_dir,
        )

    def _expand_with_local_headers(self, file_paths: List[Path]) -> List[Path]:
        """Expand input set with quoted local headers reachable from C/C++ files."""
        expanded: List[Path] = []
        seen = set()
        for file_path in file_paths:
            resolved = file_path.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            expanded.append(resolved)

        idx = 0
        c_family_exts = self.C_EXTENSIONS | self.CPP_EXTENSIONS
        while idx < len(expanded):
            source_file = expanded[idx]
            idx += 1
            if source_file.suffix.lower() not in c_family_exts:
                continue
            try:
                content = source_file.read_text(errors="replace")
            except Exception:
                continue

            for include_name in self._include_re.findall(content):
                resolved_header = self._resolve_local_include(source_file, include_name)
                if not resolved_header:
                    continue
                if resolved_header.suffix.lower() not in c_family_exts:
                    continue
                if resolved_header in seen:
                    continue
                seen.add(resolved_header)
                expanded.append(resolved_header)

        return expanded

    def _resolve_local_include(self, including_file: Path, include_name: str) -> Optional[Path]:
        """Resolve a quoted include using local file, search paths, and sibling dirs."""
        include_path = Path(include_name)
        candidates: List[Path] = []

        if include_path.is_absolute():
            candidates.append(include_path)
        else:
            candidates.append(including_file.parent / include_path)
            for search_path in self.search_paths:
                candidates.append(search_path / include_path)

            # Heuristic for layouts like final_test_data/cpp + final_test_data/hpp.
            if "/" not in include_name and "\\" not in include_name:
                parent = including_file.parent.parent
                try:
                    for sibling in parent.iterdir():
                        if sibling.is_dir():
                            candidates.append(sibling / include_path.name)
                except Exception:
                    pass

        for candidate in candidates:
            try:
                resolved = candidate.resolve()
            except Exception:
                continue
            if resolved.exists() and resolved.is_file():
                return resolved
        return None

    def _build_global_registry(
        self,
        file_results: List[FileAnalysisResult],
        sym_compact_dir: Optional[Path] = None,
    ) -> GlobalSymbolRegistry:
        registry = GlobalSymbolRegistry()

        if sym_compact_dir is not None:
            # Stream compact (name, type_value) tuples from disk per-file.
            # Registry lists are empty (no Symbol objects) — callers only check
            # key existence via .entries/.extrns/.wxtrns dicts.
            for result in file_results:
                sym_compact = _load_sym_compact(sym_compact_dir, result.file_path) or []
                for name, stype_val in sym_compact:
                    if stype_val == SymbolType.ENTRY.value:
                        registry.entries.setdefault(name, [])
                    elif stype_val == SymbolType.EXTRN.value:
                        registry.extrns.setdefault(name, [])
                    elif stype_val == SymbolType.WXTRN.value:
                        registry.wxtrns.setdefault(name, [])
        else:
            for result in file_results:
                for symbol in result.symbol_table.all_symbols:
                    if symbol.symbol_type == SymbolType.ENTRY:
                        registry.add_entry(symbol)
                    elif symbol.symbol_type == SymbolType.EXTRN:
                        registry.add_extrn(symbol)
                    elif symbol.symbol_type == SymbolType.WXTRN:
                        registry.add_wxtrn(symbol)

        return registry

    def _find_unresolved_externals(self, registry: GlobalSymbolRegistry) -> List[str]:
        unresolved = []
        for extrn_name in registry.extrns.keys():
            if extrn_name not in registry.entries:
                unresolved.append(extrn_name)
        return unresolved

    def _link_call_graphs(
        self,
        file_results: List[FileAnalysisResult],
        sym_compact_dir: Optional[Path] = None,
    ) -> None:
        # Pass 1: build ENTRY name → file path map.
        symbol_to_file = {}
        for result in file_results:
            if sym_compact_dir is not None:
                sym_compact = _load_sym_compact(sym_compact_dir, result.file_path) or []
                for name, stype_val in sym_compact:
                    if stype_val == SymbolType.ENTRY.value:
                        symbol_to_file[name] = str(result.file_path)
            else:
                for symbol in result.symbol_table.all_symbols:
                    if symbol.symbol_type == SymbolType.ENTRY:
                        symbol_to_file[symbol.name] = str(result.file_path)

        # Pass 2: mutate call_graph.nodes using per-file EXTRN/WXTRN names.
        for result in file_results:
            call_graph = result.call_graph
            if not call_graph:
                continue
            if sym_compact_dir is not None:
                sym_compact = _load_sym_compact(sym_compact_dir, result.file_path) or []
                file_extrns = {
                    name for name, stype_val in sym_compact
                    if stype_val in (SymbolType.EXTRN.value, SymbolType.WXTRN.value)
                }
            else:
                file_extrns = {
                    symbol.name
                    for symbol in result.symbol_table.all_symbols
                    if symbol.symbol_type in (SymbolType.EXTRN, SymbolType.WXTRN)
                }

            for node_name, node in call_graph.nodes.items():
                if node_name in file_extrns:
                    if node_name in symbol_to_file:
                        node.file = symbol_to_file[node_name]
                        node.is_external = False
                    else:
                        node.is_external = True
                        node.file = None
                    continue
                if node.file:
                    continue
                if node_name in symbol_to_file:
                    node.file = symbol_to_file[node_name]
                else:
                    node.is_external = True

    def _stitch_variable_lineage(
        self,
        file_results: List[FileAnalysisResult],
        lineage_cache_dir: Optional[Path] = None,
        sym_cache_dir: Optional[Path] = None,
    ) -> None:
        contexts = {
            str(result.file_path): result.analysis_context
            for result in file_results
        }

        lineage_loader = None
        if lineage_cache_dir is not None:
            # Build a str→Path map once so the closure doesn't hold file_results.
            _fp_map = {str(r.file_path): r.file_path for r in file_results}

            def lineage_loader(file_path_str: str):  # noqa: E306
                fp = _fp_map.get(file_path_str)
                return _load_lineage(lineage_cache_dir, fp) if fp is not None else None

        stitcher = GlobalLineageStitcher()
        global_graph = stitcher.process_contexts(
            contexts, lineage_loader=lineage_loader, sym_cache_dir=sym_cache_dir,
        )
        for result in file_results:
            result.analysis_context.add_metadata("global_variable_lineage", global_graph)

    def _collect_global_lineage(self, file_results: List[FileAnalysisResult]) -> Optional[VariableLineageGraph]:
        if not file_results:
            return None
        context = file_results[0].analysis_context
        return context.get_metadata("global_variable_lineage")

    def _annotate_lineage_macro_parents(self, context) -> None:
        graph = context.get_metadata("variable_lineage")
        if not isinstance(graph, VariableLineageGraph):
            return
        expansions = getattr(context, "macro_expansions", None)
        if not expansions:
            return

        line_to_parent = {}
        for expansion in expansions:
            if expansion.expansion_status != "success":
                continue
            if expansion.invocation_line is None or not expansion.macro_name:
                continue
            parent_id = f"{expansion.macro_name}@{expansion.invocation_file}:{expansion.invocation_line}"
            line_to_parent[expansion.invocation_line] = parent_id

        if not line_to_parent:
            return

        for edge in graph.edges:
            if edge.macro_expansion_parent:
                continue
            parent = line_to_parent.get(edge.line)
            if parent:
                edge.macro_expansion_parent = parent
