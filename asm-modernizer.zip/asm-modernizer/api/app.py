"""FastAPI application entry point."""

from __future__ import annotations

import logging
import time
from contextlib import asynccontextmanager
from typing import Any, Callable, Dict

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.staticfiles import StaticFiles

from api.config import settings
from api.db import create_tables
from api.logging_config import configure_logging
from api.routes import auth, chat, conversations, jobs, knowledge_base, pipeline, processes, tasks, upload, variable_graph
from api.routes import chainless_lineage
from api.routes import setter_analysis
from api.routes import chain_setter_analysis
from api.routes import var_lineage
from api.routes import vbt
# from api.routes import analysis, universe, lineage, modifiers, callgraph  # disabled for now

configure_logging()
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan: ensure the jobs base directory exists."""
    settings.JOBS_BASE_DIR.mkdir(parents=True, exist_ok=True)
    settings.DATASOURCE_DIR.mkdir(parents=True, exist_ok=True)
    create_tables()
    logger.info("Jobs base directory: %s", settings.JOBS_BASE_DIR)
    logger.info("Datasource directory: %s", settings.DATASOURCE_DIR)
    yield
    # Shutdown — nothing to clean up here; workers handle their own resources.


app = FastAPI(
    title="ZENFLOW API",
    version="1.0.0",
    description=(
        "REST API for the z/TPF assembly code static analysis tool. "
        "All long-running operations are executed asynchronously via Celery workers."
    ),
    lifespan=lifespan,
)

# CORS — allow frontend origins (configure CORS_ORIGINS in .env for production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Compress large JSON responses
app.add_middleware(GZipMiddleware, minimum_size=1024)


@app.middleware("http")
async def _log_requests(request: Request, call_next: Callable) -> Response:
    """Log every HTTP request with method, path, user, status and elapsed time."""
    start = time.monotonic()
    response = await call_next(request)
    elapsed_ms = (time.monotonic() - start) * 1000
    user = "anonymous"
    try:
        from api.auth import decode_access_token
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            payload = decode_access_token(auth_header[7:])
            if payload:
                user = payload.get("sub", "anonymous")
    except Exception:
        pass
    logger.info(
        "HTTP %s %s — user=%s status=%d elapsed=%.0fms",
        request.method,
        request.url.path,
        user,
        response.status_code,
        elapsed_ms,
    )
    return response


# ---------------------------------------------------------------------------
# Route registration
# ---------------------------------------------------------------------------

app.include_router(jobs.router, prefix="/v1/jobs", tags=["jobs"])
# app.include_router(analysis.router, prefix="/v1/jobs", tags=["analysis"])
# app.include_router(universe.router, prefix="/v1/jobs", tags=["universe"])
# app.include_router(lineage.router, prefix="/v1/jobs", tags=["lineage"])
# app.include_router(modifiers.router, prefix="/v1/jobs", tags=["modifiers"])
# app.include_router(callgraph.router, prefix="/v1/jobs", tags=["callgraph"])
app.include_router(pipeline.router, prefix="/v1/jobs", tags=["pipeline"])
app.include_router(processes.router, prefix="/v1/jobs", tags=["processes"])
app.include_router(variable_graph.router, prefix="/v1/jobs", tags=["variable-graph"])
app.include_router(tasks.router, prefix="/v1/tasks", tags=["tasks"])
app.include_router(upload.router, prefix="/v1/codebases", tags=["codebases"])
app.include_router(auth.router, prefix="/v1/auth", tags=["auth"])
app.include_router(knowledge_base.router, prefix="/v1/knowledge-bases", tags=["knowledge-bases"])
app.include_router(chat.router,          prefix="/v1/chat",            tags=["chat"])
app.include_router(conversations.router, prefix="/v1/knowledge-bases", tags=["conversations"])
app.include_router(chainless_lineage.router, prefix="/v1/knowledge-bases", tags=["chainless-lineage"])
app.include_router(setter_analysis.router, prefix="/v1/knowledge-bases", tags=["setter-analysis"])
app.include_router(chain_setter_analysis.router, prefix="/v1/knowledge-bases", tags=["chain-setter-analysis"])
app.include_router(var_lineage.router, prefix="/v1/knowledge-bases", tags=["var-lineage"])
app.include_router(vbt.router, prefix="/v1/jobs", tags=["vbt"])


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

@app.get("/", include_in_schema=False)
async def serve_ui():
    """Redirect bare root to the chat UI."""
    from fastapi.responses import FileResponse
    import pathlib
    return FileResponse(pathlib.Path(__file__).parent / "static" / "index.html")


@app.get("/v1/health", tags=["health"], summary="Health check")
async def health() -> Dict[str, Any]:
    """
    Return the health status of the API and its dependencies.

    Checks Redis connectivity and reports the number of active workers
    via Celery's inspect interface (best-effort; empty dict if no workers
    are reachable within the timeout).
    """
    redis_ok = False
    redis_error: str = ""
    worker_info: Dict[str, Any] = {}

    # Check Redis
    try:
        from api.storage.workspace import get_metadata_client
        client = get_metadata_client()
        client.ping()
        redis_ok = True
    except Exception as exc:
        redis_error = str(exc)
        logger.warning("Redis health check failed: %s", exc)

    # Query active Celery workers (non-blocking, 1-second timeout)
    try:
        from api.tasks.celery_app import celery_app
        inspect = celery_app.control.inspect(timeout=1.0)
        active = inspect.active()
        if active:
            worker_info = {
                "worker_count": len(active),
                "workers": list(active.keys()),
            }
        else:
            worker_info = {"worker_count": 0, "workers": []}
    except Exception as exc:
        logger.debug("Could not inspect Celery workers: %s", exc)
        worker_info = {"worker_count": None, "note": "Could not reach workers"}

    status_str = "ok" if redis_ok else "degraded"

    return {
        "status": status_str,
        "redis": {
            "ok": redis_ok,
            "error": redis_error or None,
        },
        "celery": worker_info,
        "version": app.version,
    }
