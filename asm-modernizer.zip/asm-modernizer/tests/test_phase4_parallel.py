"""Phase 4 (macro expansion) serial-vs-parallel equivalence.

Phase 4 is parallelised across worker processes (mirroring the Phase 1 batch
pool).  Each ASM file is expanded independently: its statements + lineage are
loaded from disk, macros are expanded, and the updated lineage + full
ExpansionResult list are written back to disk; only lightweight stubs return to
the parent.  This test guards that the parallel path produces byte-for-byte the
same result as the in-process serial path.

Run with `OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES` on macOS (fork after import).
"""
import os
import shutil
import tempfile
from collections import Counter
from pathlib import Path

import pytest

os.environ.setdefault("OBJC_DISABLE_INITIALIZE_FORK_SAFETY", "YES")

from multi_file.mixed_orchestrator import MixedLanguageOrchestrator

_ROOT = Path(__file__).resolve().parent.parent
_SAMPLE = _ROOT / "datasource/alice/asm_sample_version_0/asm 6 1"
_EXTS = {".asm", ".mac", ".cpp", ".hpp", ".h", ".c"}

pytestmark = pytest.mark.skipif(
    not _SAMPLE.is_dir(), reason="sample ASM corpus not available"
)


def _run(workers):
    files = sorted(p for p in _SAMPLE.iterdir() if p.suffix.lower() in _EXTS)
    cache = Path(tempfile.mkdtemp(prefix=f"p4test_{workers}_"))
    try:
        orch = MixedLanguageOrchestrator(cache_dir=cache, search_paths=[_SAMPLE])
        res = orch.analyze_files(
            list(files), analysis_workers=workers, batch_size=20, file_timeout=120
        )
        # Per-file macro-expansion fingerprint: count + status multiset.
        per_file = {}
        for fr in res.file_results:
            exps = getattr(fr.analysis_context, "macro_expansions", None) or []
            per_file[fr.file_path.name] = (
                len(exps),
                dict(Counter(getattr(e, "expansion_status", None) for e in exps)),
            )
        me_dir = cache / "macro_exp_cache"
        me_files = sorted(p.name for p in me_dir.glob("*")) if me_dir.exists() else []
        return per_file, set(me_files)
    finally:
        shutil.rmtree(cache, ignore_errors=True)


def test_phase4_serial_matches_parallel():
    serial, serial_me = _run(workers=1)
    parallel, parallel_me = _run(workers=4)

    # Some files in the sample actually produce expansions — otherwise the test
    # would pass vacuously and prove nothing.
    assert any(count > 0 for count, _ in serial.values()), "no expansions produced"

    assert serial == parallel, "parallel macro-expansion result differs from serial"
    assert serial_me == parallel_me, "macro_exp_cache filesets differ"
