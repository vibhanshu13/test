"""Regression guard: C/C++ type keywords must never be recorded as call targets.

Root cause: CFamilyParser._extract_calls() backtracks from every "(" over an
identifier-shaped charset with no type-keyword filter, so a functional-style cast
like ``unsigned(x)`` or ``long(y)`` was indistinguishable from a real call and got
recorded as CCall(function='unsigned'). Those bogus "calls" flow into the call graph,
which never has a blueprint/source file for a keyword — so they surface downstream
(api/tasks/vbt_lineage_task.py's _audit_connections / _missing_candidates) as fake
"missing module" definition-site guesses attached to unrelated unresolved variables.
"""
from passes.c_family_parser import CFamilyParser


def _calls(expr):
    return [c["function"] for c in CFamilyParser("cpp")._extract_calls(expr)]


def test_functional_cast_keywords_are_not_calls():
    assert _calls("unsigned(x) + 1") == []
    assert _calls("long(y) - short(z)") == []
    assert _calls("(unsigned)x + (long)y") == []


def test_real_calls_still_extracted():
    assert _calls("foo(a, b)") == ["foo"]
    assert _calls("isdigit(c)") == ["isdigit"]
    assert _calls("strstr(a, b)") == ["strstr"]
    assert _calls("obj.method(x)") == ["obj.method"]
