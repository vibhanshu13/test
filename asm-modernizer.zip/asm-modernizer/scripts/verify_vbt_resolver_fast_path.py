#!/usr/bin/env python3
"""Verify the VBT resolver fast path for a client trace.

Checks the condition needed to avoid the .hpp/.mac resolver-read storm:

  * resolver artifacts are present and shaped correctly for the job_id
  * name_alias is non-empty when cc*.hpp files exist
  * source artifact is present
  * install_source_override(job_id, asm_dir) succeeds
  * sample .hpp/.mac source blobs are served by the override for this asm_dir
  * preload_resolvers() can populate resolver caches without opening .hpp/.mac

Example:
  env/bin/python scripts/verify_vbt_resolver_fast_path.py \
    --job-id 45dba9c9-b32c-4391-b80e-c46a7809f743 \
    --blueprint-dir /path/to/jobs/.../output/asm \
    --asm-dir /path/to/client/source \
    --exercise-query softCardValue --language cpp
"""

from __future__ import annotations

import argparse
import builtins
import io
import os
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


class Check:
    def __init__(self) -> None:
        self.errors: List[str] = []
        self.warnings: List[str] = []

    def ok(self, msg: str) -> None:
        print(f"[OK]   {msg}")

    def warn(self, msg: str) -> None:
        self.warnings.append(msg)
        print(f"[WARN] {msg}")

    def fail(self, msg: str) -> None:
        self.errors.append(msg)
        print(f"[FAIL] {msg}")


@contextmanager
def count_hpp_mac_opens() -> Iterable[List[str]]:
    """Count content opens of .hpp/.mac, mirroring the trace interceptor signal."""
    real_builtin_open = builtins.open
    real_io_open = io.open
    hits: List[str] = []

    def patched_open(file, *args, **kwargs):
        try:
            path = os.fspath(file)
            mode = args[0] if args else kwargs.get("mode", "r")
            if (
                isinstance(path, str)
                and (path.endswith(".hpp") or path.endswith(".mac"))
                and "w" not in mode
                and "a" not in mode
                and "x" not in mode
            ):
                hits.append(path)
        except Exception:
            pass
        return real_builtin_open(file, *args, **kwargs)

    builtins.open = patched_open
    io.open = patched_open
    try:
        yield hits
    finally:
        builtins.open = real_builtin_open
        io.open = real_io_open


def _sample_sources(asm_dir: Path, limit: int) -> List[Path]:
    out: List[Path] = []
    for pat in ("*.hpp", "*.mac"):
        out.extend(sorted(asm_dir.glob(pat))[:limit])
    return out[: max(0, limit * 2)]


def _load_artifact(job_id: str, artifact: str) -> Tuple[bool, Optional[object], Optional[str]]:
    from vbt.precompute import db_artifacts as DA

    if not DA.manifest_present(job_id, artifact):
        return False, None, "manifest missing"
    blob = DA.read_blob(job_id, artifact)
    if blob is None:
        return False, None, "blob missing"
    try:
        return True, DA.loads_gz(blob), None
    except Exception as exc:
        return False, None, f"blob decode failed: {exc}"


def _check_artifacts(chk: Check, job_id: str, blueprint_dir: Path, asm_dir: Path) -> None:
    from vbt.precompute import db_artifacts as DA
    from vbt.precompute.resolvers_db import (
        CONST_ARTIFACT,
        MEMBERSHIP_ARTIFACT,
        MODIFIER_ARTIFACT,
        NAME_ALIAS_ARTIFACT,
    )
    from vbt.precompute.source_db import SOURCE_MANIFEST

    previous = DA.is_load_only()
    DA.set_load_only(True)
    try:
        has_cc = any(asm_dir.glob("cc*.hpp"))

        ok, name_alias, err = _load_artifact(job_id, NAME_ALIAS_ARTIFACT)
        if not ok:
            chk.fail(f"{NAME_ALIAS_ARTIFACT}: {err}")
        elif not isinstance(name_alias, dict):
            chk.fail(f"{NAME_ALIAS_ARTIFACT}: decoded payload is not a dict")
        else:
            units = name_alias.get("units")
            maps = name_alias.get("maps")
            if not isinstance(units, list) or not isinstance(maps, list):
                chk.fail(f"{NAME_ALIAS_ARTIFACT}: expected list fields units/maps")
            elif has_cc and not units:
                chk.fail(f"{NAME_ALIAS_ARTIFACT}: 0 units, but cc*.hpp files exist in asm_dir")
            elif len(units) != len(maps):
                chk.fail(f"{NAME_ALIAS_ARTIFACT}: units/maps length mismatch ({len(units)} vs {len(maps)})")
            else:
                chk.ok(f"{NAME_ALIAS_ARTIFACT}: {len(units)} units, {len(maps)} maps")

        ok, membership, err = _load_artifact(job_id, MEMBERSHIP_ARTIFACT)
        if not ok:
            chk.fail(f"{MEMBERSHIP_ARTIFACT}: {err}")
        elif not isinstance(membership, dict):
            chk.fail(f"{MEMBERSHIP_ARTIFACT}: decoded payload is not a dict")
        else:
            required = ("cpp", "asm", "tail_structs", "sym_dsect")
            missing = [k for k in required if k not in membership]
            if missing:
                chk.fail(f"{MEMBERSHIP_ARTIFACT}: missing keys {missing}")
            else:
                chk.ok(
                    f"{MEMBERSHIP_ARTIFACT}: cpp={len(membership.get('cpp') or {})} "
                    f"asm={len(membership.get('asm') or {})} "
                    f"tail_structs={len(membership.get('tail_structs') or {})} "
                    f"sym_dsect={len(membership.get('sym_dsect') or {})}"
                )

        for art in (CONST_ARTIFACT, MODIFIER_ARTIFACT):
            if DA.manifest_present(job_id, art):
                chk.ok(f"{art}: manifest present")
            else:
                chk.warn(f"{art}: manifest missing; not the .hpp/.mac resolver storm, but trace may cold-build elsewhere")

        if DA.manifest_present(job_id, SOURCE_MANIFEST):
            chk.ok(f"{SOURCE_MANIFEST}: manifest present")
        else:
            chk.fail(f"{SOURCE_MANIFEST}: manifest missing; source_override cannot be installed")

        if not blueprint_dir.exists():
            chk.fail(f"blueprint_dir does not exist: {blueprint_dir}")
        elif not any(blueprint_dir.glob("*.json")):
            chk.warn(f"blueprint_dir has no *.json files: {blueprint_dir}")
        else:
            chk.ok(f"blueprint_dir exists: {blueprint_dir}")

        if not asm_dir.exists():
            chk.fail(f"asm_dir does not exist: {asm_dir}")
        elif not (list(asm_dir.glob("*.hpp")) or list(asm_dir.glob("*.mac"))):
            chk.warn(f"asm_dir has no .hpp/.mac files: {asm_dir}")
        else:
            chk.ok(f"asm_dir exists with .hpp/.mac files: {asm_dir}")
    finally:
        DA.set_load_only(previous)


def _check_source_override(chk: Check, job_id: str, asm_dir: Path, sample_limit: int) -> None:
    from backward_traversal.utils.blueprint_utils import (
        clear_source_override,
        source_override_bytes,
    )
    from vbt.precompute import db_artifacts as DA
    from vbt.precompute.source_db import install_source_override

    previous = DA.is_load_only()
    DA.set_load_only(True)
    clear_source_override()
    try:
        installed = install_source_override(job_id, asm_dir)
        if not installed:
            chk.fail("install_source_override(job_id, asm_dir) returned False")
            return
        chk.ok("install_source_override(job_id, asm_dir) returned True")

        samples = _sample_sources(asm_dir, sample_limit)
        if not samples:
            chk.warn("no .hpp/.mac samples found for source_override byte check")
            return

        missing: List[str] = []
        mismatched: List[str] = []
        for path in samples:
            try:
                disk = path.read_bytes()
            except OSError as exc:
                chk.warn(f"could not read local sample {path}: {exc}")
                continue
            via_override = source_override_bytes(path)
            if via_override is None:
                missing.append(path.name)
            elif via_override != disk:
                mismatched.append(path.name)

        if missing:
            chk.fail(f"source_override missing sample blobs: {missing[:10]}")
        if mismatched:
            chk.fail(f"source_override sample bytes differ from disk: {mismatched[:10]}")
        if not missing and not mismatched:
            chk.ok(f"source_override served {len(samples)} sampled .hpp/.mac file(s) with byte parity")
    finally:
        clear_source_override()
        DA.set_load_only(previous)


def _check_preload_no_disk_open(
    chk: Check,
    job_id: str,
    blueprint_dir: Path,
    asm_dir: Path,
    exercise_query: Optional[str],
    language: str,
    home_hint: Optional[str],
) -> None:
    from backward_traversal.utils.blueprint_utils import clear_source_override
    from vbt.precompute import db_artifacts as DA
    from vbt.precompute.resolvers_db import preload_resolvers
    from vbt.precompute.source_db import install_source_override
    from vbt.resolve import membership as MB
    from vbt.resolve import name_resolver as NR

    previous = DA.is_load_only()
    DA.set_load_only(True)
    clear_source_override()
    NR.clear_cache()
    MB._CACHE.clear()
    try:
        install_source_override(job_id, asm_dir)
        with count_hpp_mac_opens() as hits:
            preload_resolvers(job_id, blueprint_dir, asm_dir)
            if exercise_query:
                aliases = NR.resolve(exercise_query, language, asm_dir, home_hint=home_hint)
                resolver = MB.get_membership_resolver(blueprint_dir, asm_dir)
                resolver.resolve(exercise_query, language, exercise_query)
            else:
                aliases = None

        if hits:
            chk.fail(
                "resolver preload/query opened .hpp/.mac on disk; first hits: "
                + ", ".join(hits[:10])
            )
        else:
            msg = "preload_resolvers opened zero .hpp/.mac files"
            if exercise_query and aliases is not None:
                msg += f"; query aliases={len(aliases.aliases)}"
            chk.ok(msg)

        unit_cache_key = str(asm_dir.resolve())
        units = NR._UNIT_CACHE.get(unit_cache_key)
        if units is None:
            chk.fail("name_resolver _UNIT_CACHE was not populated for asm_dir")
        else:
            chk.ok(f"name_resolver _UNIT_CACHE populated with {len(units)} unit(s)")

        mb_key = (str(Path(blueprint_dir)), str(Path(asm_dir)))
        mb = MB._CACHE.get(mb_key)
        if mb is None:
            chk.fail("membership resolver cache was not populated for blueprint_dir/asm_dir")
        elif not getattr(mb, "_built", False):
            chk.fail("membership resolver cache exists but _built is False")
        else:
            chk.ok("membership resolver cache populated and built")
    finally:
        clear_source_override()
        NR.clear_cache()
        MB._CACHE.clear()
        DA.set_load_only(previous)


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--job-id", required=True, help="precompute job_id / kb_id in index.db")
    ap.add_argument("--blueprint-dir", required=True, type=Path)
    ap.add_argument("--asm-dir", required=True, type=Path)
    ap.add_argument("--sample-limit", type=int, default=5, help="sample this many .hpp and .mac files")
    ap.add_argument("--exercise-query", help="optional variable to resolve after preload")
    ap.add_argument("--language", default="cpp", choices=("cpp", "asm"), help="language for --exercise-query")
    ap.add_argument("--home-hint", help="optional home_hint for the query")
    args = ap.parse_args(argv)

    chk = Check()
    job_id = args.job_id
    blueprint_dir = args.blueprint_dir
    asm_dir = args.asm_dir

    print("=== VBT resolver fast-path verification ===")
    print(f"job_id       : {job_id}")
    print(f"blueprint_dir: {blueprint_dir}")
    print(f"asm_dir      : {asm_dir}")
    print()

    _check_artifacts(chk, job_id, blueprint_dir, asm_dir)
    print()
    _check_source_override(chk, job_id, asm_dir, args.sample_limit)
    print()
    _check_preload_no_disk_open(
        chk,
        job_id,
        blueprint_dir,
        asm_dir,
        args.exercise_query,
        args.language,
        args.home_hint,
    )

    print()
    if chk.errors:
        print(f"RESULT: FAIL ({len(chk.errors)} error(s), {len(chk.warnings)} warning(s))")
        return 2
    if chk.warnings:
        print(f"RESULT: PASS with warnings ({len(chk.warnings)} warning(s))")
        return 0
    print("RESULT: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
