#!/usr/bin/env python3
"""One-shot precompute for the VBT engine on a codebase (with timing).

Runs, in order, everything the engine needs *before* you can trace variables:

  Step 0  (--build-frontend / auto if missing): compile the Clang LibTooling
          ``cfg_extract`` binary (needs LLVM; one-time per machine).
  Step 2  Regenerate ``file_call_graph.json`` from the blueprints (CallGraphBuilder).
  Step 3  Build + persist the modifier/function index (var/fn -> files).
  Step 4  Build the enum / EQU-DC constant-value resolver index.

Step 1 (parser blueprints: ``.asm.json`` / ``.cpp.json`` …) is the EXISTING analysis
pipeline and must already exist in ``--blueprint-dir`` — this script does NOT run it.

All outputs are cached (call graph on disk next to the blueprints; the index under
``vbt/.cache/`` or ``$VBT_CACHE_DIR``), so re-running is near-instant unless sources
change or you pass ``--rebuild``.

Usage:
    python -m vbt.precompute_all \\
        --blueprint-dir jobs/<kb>/output \\
        --asm-dir       /path/to/source \\
        [--graph out/file_call_graph.json] [--build-frontend] [--rebuild]
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path


def _step(label: str, fn):
    t0 = time.monotonic()
    result = fn()
    print(f"  [{time.monotonic() - t0:8.1f}s] {label}", flush=True)
    return result


def main() -> int:
    ap = argparse.ArgumentParser(prog="vbt.precompute_all", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--blueprint-dir", required=True, type=Path,
                    help="dir with parser blueprints (.asm.json/.cpp.json/.mac.json/.hpp.json)")
    ap.add_argument("--asm-dir", required=True, type=Path,
                    help="dir with source files (.asm/.mac/.cpp/.hpp)")
    ap.add_argument("--graph", type=Path, default=None,
                    help="output path for file_call_graph.json (default: <blueprint-dir>/file_call_graph.json)")
    ap.add_argument("--build-frontend", action="store_true",
                    help="force (re)build the cfg_extract LibTooling binary")
    ap.add_argument("--rebuild", action="store_true",
                    help="ignore caches and rebuild call graph + indexes from scratch")
    ap.add_argument("--no-cfg-warm", action="store_true",
                    help="skip Step 5 (parallel pre-warm of the Clang cfg cache). "
                         "Cfg-warm is the biggest 22k win — leave it on unless debugging.")
    ap.add_argument("--no-source-lint", action="store_true",
                    help="skip Step 6 (report functions commented out by an unterminated /** "
                         "doc comment — an extraction defect; report-only, never edits source).")
    a = ap.parse_args()

    bp, src = a.blueprint_dir, a.asm_dir
    if not bp.is_dir():
        sys.exit(f"--blueprint-dir not found: {bp}")
    if not src.is_dir():
        sys.exit(f"--asm-dir not found: {src}")

    n_bp = sum(1 for _ in bp.glob("*.asm.json")) + sum(1 for _ in bp.glob("*.cpp.json")) \
        + sum(1 for _ in bp.glob("*.mac.json")) + sum(1 for _ in bp.glob("*.hpp.json"))
    n_src = sum(1 for _ in src.glob("*.cpp")) + sum(1 for _ in src.glob("*.asm")) \
        + sum(1 for _ in src.glob("*.mac")) + sum(1 for _ in src.glob("*.hpp"))
    print("=== VBT precompute ===")
    print(f"  blueprints : {n_bp}  ({bp})")
    print(f"  source     : {n_src}  ({src})")
    if n_bp == 0:
        sys.exit("No blueprints found — run the parser (Step 1) first to produce "
                 ".asm.json/.cpp.json blueprints in --blueprint-dir.")

    cache = Path(__file__).resolve().parent / ".cache"
    if a.rebuild and cache.exists():
        shutil.rmtree(cache, ignore_errors=True)
        print("  [rebuild] cleared vbt/.cache")

    t_total = time.monotonic()

    # ---- Step 0: cfg_extract binary -------------------------------------------------
    binary = Path(__file__).resolve().parent / "cpp_frontend" / "cfg_extract"
    if a.build_frontend or not binary.exists():
        def _build():
            subprocess.run(["bash", str(binary.parent / "build.sh")], check=True)
        try:
            _step("Step 0: build cfg_extract (LibTooling)", _build)
        except (subprocess.CalledProcessError, FileNotFoundError) as exc:
            sys.exit(f"Step 0 failed to build cfg_extract: {exc}\n"
                     f"Install LLVM (brew install llvm) and retry, or build manually:\n"
                     f"  bash {binary.parent / 'build.sh'}")
    else:
        print(f"  [   skip ] Step 0: cfg_extract present ({binary})")

    # ---- Step 2: file_call_graph.json ----------------------------------------------
    from vbt.precompute.call_graph import ensure_call_graph
    gf = _step("Step 2: file_call_graph.json",
               lambda: ensure_call_graph(bp, src, out_path=a.graph, rebuild=a.rebuild))

    # ---- Step 3: modifier + function index -----------------------------------------
    from vbt.precompute.modifier_index import get_modifier_index
    idx = _step("Step 3: modifier + function index", lambda: get_modifier_index(bp, src))

    # ---- Step 4: enum / EQU-DC const resolver --------------------------------------
    from vbt.resolve.const_resolver import get_const_resolver
    cr = _step("Step 4: enum/const resolver", lambda: get_const_resolver(bp, src))

    # ---- Step 5: cfg-warm (parallel Clang pre-pass over all cpp sources) ------------
    # The dominant cold-start cost at 22k files is one Clang subprocess per cpp
    # file. Run them in parallel up front so every {key}.json lands in the disk
    # cfg cache (each worker writes its own file atomically — race-safe), then
    # traces hit the cache instead of re-shelling out. Default-on; --no-cfg-warm
    # opts out. Skipped when the binary is absent (Step 0 failed/declined).
    n_warmed = 0
    if a.no_cfg_warm:
        print("  [   skip ] Step 5: cfg-warm (--no-cfg-warm)")
    elif not binary.exists():
        print("  [   skip ] Step 5: cfg-warm (cfg_extract binary missing)")
    else:
        from vbt.precompute.parallel import parallel_map, plan_workers
        from vbt.cpp_frontend.wrapper import warm_cfg_cache

        cpp_paths = [str(p) for p in sorted(src.glob("*.cpp"))]
        plan = plan_workers()

        def _warm():
            if not cpp_paths:
                return 0
            print(f"           cfg-warm: {len(cpp_paths)} cpp files, "
                  f"{plan.worker_count} workers (batch {plan.batch_size}, "
                  f"mem cap {plan.per_proc_mem_cap_mb} MB)", flush=True)
            results = parallel_map(warm_cfg_cache, cpp_paths, plan=plan)
            return sum(1 for ok in results if ok)

        n_warmed = _step("Step 5: cfg-warm (parallel cfg cache)", _warm)
        print(f"           cfg-warm: {n_warmed}/{len(cpp_paths)} files warmed",
              flush=True)

    # ---- Step 6: source lint (functions swallowed by unterminated /** comments) -----
    # An extraction defect in the source can drop a doc comment's closing ``*/``, which
    # lexically comments out the following function — invisible to BOTH frontends, so it
    # surfaces as ``externalCall`` in traces. Report-only (never edits source); the fix
    # belongs to the extraction pipeline. Cheap, parallel, non-fatal.
    n_swallowed = 0
    if a.no_source_lint:
        print("  [   skip ] Step 6: source lint (--no-source-lint)")
    else:
        from vbt.precompute.source_lint import scan_dir, format_report, write_json

        def _lint():
            findings = scan_dir(src)
            if findings:
                print(format_report(findings), flush=True)
                cache.mkdir(parents=True, exist_ok=True)
                write_json(findings, cache / "source_lint.json")
            return findings

        findings = _step("Step 6: source lint (unterminated /** comments)", _lint)
        n_swallowed = len(findings)

    # ---- Summary -------------------------------------------------------------------
    try:
        g = json.loads(Path(gf).read_text())
        n_nodes, n_edges = len(g.get("nodes", [])), len(g.get("edges", []))
    except Exception:
        n_nodes = n_edges = -1
    print("\n=== precompute complete ===")
    print(f"  call graph     : {n_nodes} nodes, {n_edges} edges  -> {gf}")
    print(f"  modifier index : asm_vars={len(idx.asm)} cpp_fields={len(idx.cpp)} functions={len(idx.functions)}")
    print(f"  const resolver : cpp_enum={len(cr.cpp_enum)} asm_const={len(cr.asm_const)}")
    print(f"  cfg warmed     : {n_warmed} files")
    print(f"  source lint    : {n_swallowed} function(s) commented out by unterminated /**"
          + (f"  -> {cache / 'source_lint.json'}" if n_swallowed else ""))
    print(f"  cache dir      : {cache}")
    print(f"  TOTAL          : {time.monotonic() - t_total:.1f}s")
    print("\nReady. Trace a variable with vbt.engine.trace_root_variable("
          "variable, language, chain, blueprint_dir=..., asm_dir=..., graph_file=...).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
