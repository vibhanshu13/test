# Verification Prompt Phase 1 - Reachable Setters Suspect Generation

> Paste everything below into Copilot / agent mode inside the client repo checkout.
> This is Phase 1 only. Do not make final correctness claims in this phase.

---

## Parameters

Before running commands, fill or verify these values:

```text
kb_id: <kb_id>                         # repo default in find_reachable_setters.py may be b58d8432-73e0-42d1-89a9-2ceebc47c6d2
entry_stem: <stem>                     # repo default may be dw710000
entry_function: <function>             # repo default may be callPlasticAuthenticationComponentInterface
production_output_json: <path>         # saved output from asm.vbt_reachable_setters over the 221 variables
asm_dir: <source dir>
blueprint_dir: jobs/<kb_id>/output
```

If any parameter cannot be found from local context, report it as a blocker before doing expensive work.

Do not infer the 221-variable set from casual source greps. Prefer, in order:

1. variables present in `production_output_json`;
2. an explicit variable-list artifact from the task request, if present;
3. a user-provided variable list.

If the production output is unavailable, stop after DB readiness and report the missing artifact. A cap-raised diff without the original 221-variable baseline is not a valid Phase 1 result.

---

## Role

You are a meticulous static-analysis auditor. Your job in this phase is to generate a high-quality suspect set for the VBT reachable-setters audit. Do not certify missed or extra setters yet. A site is only a suspect until Phase 2 independently validates both facts:

1. the source site really writes this variable's storage;
2. a concrete hop-by-hop valid path exists from `entry_stem::entry_function` to that setter.

Use `vbt/PROMPT_verify_reachable_setters.md` as the master audit spec for definitions, failure buckets, and output terminology.

---

## Phase 1 Scope

Do exactly these things:

1. Read and summarize the algorithm of record.
2. Verify DB readiness and DB-only parity prerequisites.
3. Reproduce or load the saved production baseline.
4. Locate or create an audit-only cap-raised harness.
5. Run the cap-raised differential rerun.
6. Produce a suspect report, not a final correctness report.

Do not modify production code. Temporary audit-only scripts are allowed if clearly named and kept out of production paths.

Hard stop: when the suspect report is produced, stop. Do not continue into source-write validation, path proof, or final correctness claims unless the user explicitly starts Phase 2.

---

## Files To Read First

Read these in order and state the relevant contract for each:

```text
vbt/README_reachable_setters.md
api/tasks/vbt_reachable_setters_task.py
find_reachable_setters.py
vbt/engine.py
vbt/reach/route.py
vbt/reach/cpp_routes.py
vbt/setters/cpp_setters.py
vbt/setters/asm_setters.py
check_db_readiness.py
```

After reading, restate the algorithm of record in your own words, including:

```text
reachable_files = route.forward_reachable_files(entry)
targets = [(V, "cpp")] + resolve_aliases(V, "cpp", asm_dir).aliases
midx.files_for(name, lang) intersected with reachable_files
setter detection by C++/ASM setter scanners
reachability confirmation by:
  enumerate_cpp_paths(..., max_paths=64, max_depth=16)
  OR route.routes(...)
```

Explicitly note that both reachability checks are bounded and that `truncated` from `enumerate_cpp_paths` is not used as an escalation signal by the production task.

---

## Test 0 - DB Readiness

Run:

```bash
env/bin/python3 check_db_readiness.py --job-id <kb_id>
env/bin/python3 -m vbt.precompute.verify_db --job-id <kb_id>
```

If the second command is unavailable or fails because the module is not present, report that and continue only if the required artifacts are present.

For this audit, required artifacts include:

```text
modifier_index
name_alias
membership
file_call_graph
cpp_call_edges
const
reverse_adj
forward_file_adj
fn_graph_adj
fn_facts
asm_setter_map:%
cpp_setter_map:%
cpp_file_writes:%
vbt_cfg_blob / CFG blobs, if used by this repo version
```

`READY-WITH-WARNINGS` is acceptable only if you clearly label the run as allowing fallback and record every fallback that can affect output.

---

## Test C - Cap-Raised Differential Rerun

The point of Phase 1 is to isolate likely false negatives caused by caps, fan-out, stale route cache, or bounded fallback behavior.

If `verify_reachable_setters_capraised.py` exists at the repo root, use it:

```bash
env/bin/python3 verify_reachable_setters_capraised.py \
  --job-id <kb_id> --stem <entry_stem> --function <entry_function> \
  --baseline <production_output_json> \
  --blueprint-dir "jobs/<kb_id>/output" --asm-dir "<asm_dir>" \
  --out capraised_diff.json
```

If that harness is absent, create `tmp_verify_reachable_setters_capraised.py` as an audit-only scratch harness. Base it on `find_reachable_setters.py` or monkeypatch the same logic. Change only audit knobs:

```text
enumerate_cpp_paths(..., max_paths=512, max_depth=64)
RouteEngine(..., max_routes=<raised>, max_len=<raised>)
skip/prevent preload_route_cache
clear route._routes_memo before raised-route checks
optionally raise dense-graph DFS budgets
do not patch production task code
```

Note: raising `_ENTRY_FANOUT_CAP` only exercises fan-out if the function graph is rebuilt live. In load-only mode, precomputed `fn_graph_adj` already baked in the original cap. Report which mode you used.

Pin the run:

```text
same index.db
same entry point
same 221-variable set
same source tree
only caps/cache behavior changed
```

Record the `index.db` path and hash.

---

## Required JSON Shapes

The baseline production output must normalize to this shape:

```json
{
  "variables": {
    "variableName": [
      {
        "file_stem": "abc123",
        "language": "cpp",
        "line": 123,
        "function": "functionOrBlock",
        "code": "lhs_or_instruction"
      }
    ]
  }
}
```

The cap-raised harness must write this minimum shape:

```json
{
  "inputs": {
    "job_id": "...",
    "stem": "...",
    "function": "...",
    "baseline": "...",
    "blueprint_dir": "...",
    "asm_dir": "...",
    "index_db": "...",
    "index_db_sha256": "...",
    "variables": ["..."]
  },
  "caps": {
    "harness_prod_caps": {
      "cpp_max_paths": 64,
      "cpp_max_depth": 16,
      "route_max_routes": 200,
      "route_max_len": 16,
      "preload_routes": true
    },
    "raised_caps": {
      "cpp_max_paths": 512,
      "cpp_max_depth": 64,
      "route_max_routes": 2000,
      "route_max_len": 64,
      "preload_routes": false
    }
  },
  "baseline": {"variableName": []},
  "harness_prod_caps": {"variableName": []},
  "raised_caps": {"variableName": []},
  "diffs": {
    "new_vs_baseline": {"variableName": []},
    "gone_vs_baseline": {"variableName": []},
    "changed_counts_vs_baseline": {"variableName": {"before": 0, "after": 1, "delta": 1}},
    "new_vs_harness_prod_caps": {"variableName": []},
    "gone_vs_harness_prod_caps": {"variableName": []},
    "changed_counts_vs_harness_prod_caps": {"variableName": {"before": 0, "after": 1, "delta": 1}}
  },
  "zero_reported_setters": ["variableName"]
}
```

Normalize setter identity as:

```text
file_stem | language | line | function | code
```

Do not compare raw object identity, unstable ordering, elapsed times, debug fields, or path-enumeration diagnostics.

---

## Required Phase 1 Output

Produce a report with these sections:

1. `inputs`: resolved `kb_id`, `entry_stem`, `entry_function`, `production_output_json`, `asm_dir`, `blueprint_dir`, `index.db` hash.
2. `pipeline summary`: short algorithm-of-record restatement.
3. `readiness`: required artifacts present/missing and any fallback warnings.
4. `harness`: whether an existing harness or `tmp_verify_reachable_setters_capraised.py` was used; exact command; cap values; whether route cache was disabled/cleared.
5. `new_vs_baseline`: setters found only by the cap-raised run, grouped by variable.
6. `gone_vs_baseline`: setters present in production output but absent from the cap-raised run, grouped by variable.
7. `changed_counts`: per-variable count deltas.
8. `zero_reported_setters`: variables with zero production setters.
9. `high_priority_phase2_targets`: variables/sites to validate first, with reason:
   - appeared only with raised caps
   - disappeared under cap-raised rerun
   - zero production setters
   - top-N by reported setter count
   - route/file-level-only or function-path-missing suspect, if the harness can bucket this
10. `caveats`: anything that prevents treating the suspect list as complete.

Use `candidate` language throughout. Do not label any site as a confirmed missed setter or confirmed extra setter in Phase 1.
