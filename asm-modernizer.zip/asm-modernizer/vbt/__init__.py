"""VBT — Variable Backward Trace.

A modular engine that finds where (and under what conditions) a variable is set
in a mixed HLASM/C++ z/TPF codebase, recursively for dependent variables.

No kb_id / job_id dependency. Consumes source files + a lightweight precompute,
reusing existing battle-ready logic read-only where provably correct (see SPEC.md).
"""
