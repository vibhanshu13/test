"""DB-only LCA chain trace (vbt/lca_trace.py).

Derive everything from a single variable (+ language, optional domain, prune):

    variable → its setters → call-graph LCA(s) of those setters → all root→LCA chains
    → drop chains whose node-set is a strict subset of another → (optional) conservatively
    drop chains provably unreachable via if/else/switch/CLI/TM.

STRICTLY index.db ONLY (req #8): every read is an ``index.db`` artifact — NO source /
blueprint / disk / subprocess / live-scan fallback. A missing/stale required artifact
HARD-FAILS with ``DbArtifactMissing`` ("rerun precompute"). The variable-trace flow
(``engine.trace_root_variable``) is NOT touched — this is an independent module that
reuses the proven LCA/feasibility algorithms (git ``c17a8f4``) read DB-only.

Output is the CHAINS only: ``{chains, truncated, warnings}``; a chain is an ordered list
of hops, ``{"file": stem, "function": fn}`` for C++ and ``{"file": stem}`` for ASM.
Internal diagnostics go to a separate debug payload only when ``debug=True``.
"""
from __future__ import annotations

import logging
import time
from collections import deque
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple

from vbt.precompute import db_artifacts as DA
from vbt.precompute.chain_facts_db import (
    DbArtifactMissing,
    ASM_SETTERS_FULL_COVERAGE_ARTIFACT, CPP_SETTER_MAP_COVERAGE_ARTIFACT,
    CHAIN_FACTS_ARTIFACT, CHAIN_FACTS_VERSION, COVERAGE_VERSION,
    OK, EMPTY, FAILED,
    set_asm_setters_full_job, get_asm_setters_full,
    set_chain_facts_job, get_chain_facts, load_coverage, chain_facts_verdict,
)

logger = logging.getLogger("vbt.lca_trace")

# A function-graph node: (file_stem, function). For ASM, function == file_stem.
Node = Tuple[str, str]

# #3/#12: plastic-auth forces a fixed LCA node (skip the LCA computation).
DOMAIN_FORCED_LCA: Dict[str, Tuple[str, str, str]] = {
    "plastic_authentication": ("dw710000", "cpp", "callPlasticAuthenticationComponentInterface"),
}


class ForcedLcaAbsent(DbArtifactMissing):
    """The domain-forced LCA node is absent from the call graph (plastic-auth must-have path)."""


class UnattributedSetter(DbArtifactMissing):
    """A C++ setter line could not be attributed to a (stem, fn) node in the call graph."""


# --------------------------------------------------------------------------- #
# logging (#9): per-phase start/end + counts
# --------------------------------------------------------------------------- #
class _Phase:
    def __init__(self, name: str):
        self.name = name
        self.t0 = 0.0

    def __enter__(self):
        self.t0 = time.perf_counter()
        logger.info("[lca_trace] %s — start", self.name)
        return self

    def __exit__(self, *exc):
        logger.info("[lca_trace] %s — done (%.3fs)", self.name, time.perf_counter() - self.t0)
        return False


def _log(msg: str) -> None:
    logger.info("[lca_trace] %s", msg)


# --------------------------------------------------------------------------- #
# node helpers (from c17a8f4 discover.py — verbatim semantics)
# --------------------------------------------------------------------------- #
def _node_id(stem: str, fn: str, lang: str) -> str:
    return f"{stem}::{fn}" if lang == "cpp" else stem


def _bfs(start: Node, adj: Dict[Node, Set[Node]]) -> Set[Node]:
    """Nodes reachable from ``start`` over ``adj`` (INCLUDING start)."""
    seen: Set[Node] = {start}
    dq: deque = deque([start])
    while dq:
        cur = dq.popleft()
        for nxt in adj.get(cur, ()):  # type: ignore[arg-type]
            if nxt not in seen:
                seen.add(nxt)
                dq.append(nxt)
    return seen


def _reverse_adjacency(adj_full: Dict[Node, Set[Tuple[str, str, int, bool]]]) -> Dict[Node, Set[Node]]:
    rev: Dict[Node, Set[Node]] = {}
    for caller, edges in adj_full.items():
        for (cs, cf, _line, _cross) in edges:
            rev.setdefault((cs, cf), set()).add(caller)
    return rev


# --------------------------------------------------------------------------- #
# step 2/3 — LCA(s) over the setter NODES (reproduce discover.py::lca_roots, #5)
# --------------------------------------------------------------------------- #
def lca_roots(setter_nodes: Sequence[Node], adj_full: Dict[Node, Set[Tuple[str, str, int, bool]]],
              node_types: Dict[str, str], *, max_verify: int = 600) -> List[Tuple[Node, List[Node]]]:
    """Lowest common ancestor(s) of the setter NODES over the function graph. Returns a list of
    ``(lca_node, covered_setter_nodes)``. Faithful reproduction of c17a8f4 ``lca_roots`` — Phase A
    greedy SCC-safe grouping (sorted tie-break), Phase B verified common ancestor consolidation."""
    nodes = sorted(set(setter_nodes))
    if not nodes:
        return []

    fwd: Dict[Node, Set[Node]] = {
        k: {(cs, cf) for (cs, cf, _l, _c) in v} for k, v in adj_full.items()
    }
    rev = _reverse_adjacency(adj_full)
    anc: Dict[Node, Set[Node]] = {n: _bfs(n, rev) for n in nodes}
    node_set = set(nodes)

    if len(nodes) == 1:
        return [(nodes[0], [nodes[0]])]

    # ---- Phase A: who-reaches-whom among setter nodes (A reaches B iff A ∈ anc[B]) ----
    reaches: Dict[Node, Set[Node]] = {n: {n} for n in nodes}
    for b in nodes:
        for a in anc[b] & node_set:
            reaches[a].add(b)

    remaining: Set[Node] = set(nodes)
    groups: List[Tuple[Node, Set[Node]]] = []
    for n in sorted(nodes, key=lambda x: (-len(reaches[x]), x)):
        if n not in remaining:
            continue
        grp = reaches[n] & remaining
        groups.append((n, grp))
        remaining -= grp

    # ---- Phase B: consolidate multi groups under a common ancestor node ----
    if len(groups) <= 1:
        tail, cov = groups[0]
        return [(tail, sorted(cov))]

    reps = [g[0] for g in groups]
    anc_ancestor = _verified_common_ancestor(reps, anc, fwd, node_set, max_verify=max_verify)
    if anc_ancestor is not None:
        all_cov = set().union(*(g[1] for g in groups))
        return [(anc_ancestor, sorted(all_cov))]

    out = [(tail, sorted(cov)) for tail, cov in groups]
    out.sort(key=lambda r: (-len(r[1]), _node_id(r[0][0], r[0][1], node_types.get(r[0][0], "asm"))))
    return out


def _verified_common_ancestor(reps: Sequence[Node], anc: Dict[Node, Set[Node]],
                              fwd: Dict[Node, Set[Node]], setter_nodes: Set[Node],
                              *, max_verify: int = 600) -> Optional[Node]:
    """The deepest node reaching every rep (or None) — c17a8f4 verbatim."""
    cand: Optional[Set[Node]] = None
    for r in reps:
        a = anc.get(r)
        if a is None:
            return None
        cand = set(a) if cand is None else (cand & a)
    if not cand:
        return None
    cand -= set(reps)
    cand -= setter_nodes
    if not cand:
        return None
    cand_l = sorted(cand)[:max_verify]
    desc_count = {c: len(_bfs(c, fwd) & cand) for c in cand_l}
    cand_l.sort(key=lambda c: (desc_count[c], c))
    return cand_l[0] if cand_l else None


# --------------------------------------------------------------------------- #
# step 4 — root→LCA chains (reproduce discover.py::chains_to_lca, #6) + truncation
# --------------------------------------------------------------------------- #
def chains_to_lca(lca_node: Node, adj_full: Dict[Node, Set[Tuple[str, str, int, bool]]],
                  node_types: Dict[str, str], *, max_depth: Optional[int] = None,
                  max_chains: int = 200) -> Tuple[List[List[str]], bool]:
    """MAXIMAL root→LCA chains over the function graph. Returns (chains, truncated). Reverse-BFS
    to global roots (nodes with no caller), callers sorted, shortest-first; per-LCA cap +
    work_cap = max(4000, max_chains*200) + optional max_depth — c17a8f4 ``chains_to_lca`` + a
    truncation flag (#6)."""
    radj: Dict[Node, Set[Node]] = {}
    for caller, edges in adj_full.items():
        for (cs, cf, _l, _c) in edges:
            radj.setdefault((cs, cf), set()).add(caller)

    def nid(n: Node) -> str:
        return _node_id(n[0], n[1], node_types.get(n[0], "asm"))

    results: List[List[str]] = []
    q: deque = deque([(lca_node, (lca_node,), frozenset((lca_node,)))])
    work = 0
    work_cap = max(4000, max_chains * 200)
    truncated = False
    while q and len(results) < max_chains:
        node, path_rev, visited = q.popleft()
        work += 1
        if work > work_cap:
            truncated = True
            break
        callers = sorted(c for c in radj.get(node, ()) if c not in visited)
        if not callers or (max_depth is not None and len(path_rev) - 1 >= max_depth):
            results.append([nid(n) for n in reversed(path_rev)])   # maximal / capped
        else:
            for c in callers:
                q.append((c, path_rev + (c,), visited | {c}))
    if q and len(results) >= max_chains:
        truncated = True
    if not results:
        results = [[nid(lca_node)]]
    return results, truncated


def _subset_prune(chains: List[List[str]]) -> Tuple[List[List[str]], int]:
    """Drop any chain whose NODE SET is a strict subset of another's (set containment, #5/Step 5)."""
    sets = [frozenset(c) for c in chains]
    keep: List[List[str]] = []
    dropped = 0
    for i, ci in enumerate(chains):
        si = sets[i]
        if any(j != i and si < sets[j] for j in range(len(chains))):
            dropped += 1
            continue
        keep.append(ci)
    return keep, dropped


# --------------------------------------------------------------------------- #
# strict, blob-only resolver loader (#11): raises on any miss, never source-builds
# --------------------------------------------------------------------------- #
def strict_load_resolvers(precompute_job_id: str, bp: Path, src: Path) -> None:
    """Reconstruct the name-alias / membership / const / modifier caches from their DB blobs ONLY
    (the existing ``_load_*_artifact`` reconstructors are blob-only — no source read), raising
    ``DbArtifactMissing`` on any blob miss. NEVER calls ``preload_resolvers`` (whose non-load-only
    path can source-build, and whose load-only path warn-and-continues → a later query would
    lazy-build from source = a DB-only violation)."""
    from vbt.precompute import resolvers_db as R
    specs = [
        (R.NAME_ALIAS_ARTIFACT, lambda a: R._load_name_alias_artifact(src, a)),
        (R.MEMBERSHIP_ARTIFACT, lambda a: R._load_membership_artifact(bp, src, a)),
        (R.CONST_ARTIFACT, lambda a: R._load_const_artifact(bp, src, a)),
        (R.MODIFIER_ARTIFACT, lambda a: R._load_modifier_artifact(bp, src, a)),
    ]
    for art, load in specs:
        payload = DA.read_blob(precompute_job_id, art)
        if payload is None:
            raise DbArtifactMissing(
                f"resolver artifact {art!r} absent for kb {precompute_job_id} — rerun VBT precompute "
                f"(`python -m vbt.precompute_db`)")
        load(DA.loads_gz(payload))


# --------------------------------------------------------------------------- #
# artifact validation (#10): manifest presence + version ONLY (DB-only, no file stat)
# --------------------------------------------------------------------------- #
def _require(job_id: str, artifact: str, version: int) -> None:
    row = DA.read_manifest(job_id, artifact)
    if row is None:
        raise DbArtifactMissing(
            f"required artifact {artifact!r} ABSENT for kb {job_id} — rerun VBT precompute "
            f"(`python -m vbt.precompute_db` then `python -m vbt.precompute.chain_facts_db {job_id}`)")
    if int(row.get("version", -1)) != version:
        raise DbArtifactMissing(
            f"required artifact {artifact!r} is STALE for kb {job_id} (have v{row.get('version')}, "
            f"need v{version}) — rerun VBT precompute")


# --------------------------------------------------------------------------- #
# C++ setter attribution (#4-review): stored fn validated vs graph, else fn_facts
# --------------------------------------------------------------------------- #
def _line_to_fn(starts: Sequence[Tuple[int, str]], line: int) -> Optional[str]:
    """Nearest-preceding-start attribution (mirrors fn_attr.line_to_function over fn_facts starts)."""
    best: Optional[Tuple[int, str]] = None
    for (ln, name) in starts:
        if ln <= line and (best is None or ln > best[0]):
            best = (ln, name)
    return best[1] if best else None


def _attribute_cpp(stem: str, site, graph_nodes: Set[Node]) -> Optional[Node]:
    """(stem, fn) for a C++ setter site, or None if unattributed. Stored function IFF it's a graph
    node; else re-attribute via fn_facts nearest-preceding-start (a missing DB fact is NOT a live
    fallback → unattributed); never fabricate (stem, stem)."""
    fn = (getattr(site, "function", None) or getattr(site, "block_id", None) or "").split("::")[-1]
    if fn and (stem, fn) in graph_nodes:
        return (stem, fn)
    from vbt.precompute.fn_facts_db import get_fn_facts
    facts = get_fn_facts(stem)            # (starts, local) | None (armed via set_fn_facts_job)
    if facts is not None:
        fn2 = _line_to_fn(facts[0], int(getattr(site, "line", 0) or 0))
        if fn2 and (stem, fn2) in graph_nodes:
            return (stem, fn2)
    return None


# --------------------------------------------------------------------------- #
# core
# --------------------------------------------------------------------------- #
def trace_variable_to_lca_chains(
    precompute_job_id: str,
    variable: str,
    language: str,
    *,
    job_id: Optional[str] = None,
    domain: Optional[str] = None,
    prune: bool = False,
    candidate_stems: Optional[Sequence[str]] = None,
    home_hint: Optional[str] = None,
    allow_missing_forced_lca: bool = False,
    allow_unattributed_setters: bool = False,
    max_chains_per_lca: int = 200,
    max_chain_depth: Optional[int] = None,
    max_feasibility_checks: int = 32,
    blueprint_dir: Optional[str] = None,
    asm_dir: Optional[str] = None,
    graph_file: Optional[str] = None,
    debug: bool = False,
) -> Dict[str, Any]:
    """variable → LCA(s) → root→LCA chains, FULLY DB-only. See module docstring.

    ``precompute_job_id`` keys all ``index.db`` reads; ``job_id`` is the (separate) output job id
    (informational here — the task writes output under it). Returns ``{chains, truncated, warnings}``
    (+ ``_debug`` when ``debug=True``)."""
    t_start = time.perf_counter()
    bp = Path(blueprint_dir) if blueprint_dir else Path(".")
    src = Path(asm_dir) if asm_dir else Path(".")

    # ---- bootstrap: clear hooks (Celery-safe), arm DB-only, validate artifacts (#10/#13) ----
    from vbt.precompute import db_artifacts as _DA
    from vbt.setters.asm_setters import set_asm_setter_map_job
    from vbt.setters.cpp_setters import set_cpp_setter_map_job, set_cpp_file_writes_job
    from vbt.precompute.fn_facts_db import set_fn_facts_job

    prev_load_only = _DA.is_load_only()
    # CLEAR every hook at entry (mirror engine.py:842-868) so a prior task can't leak state in.
    try:
        from backward_traversal.utils.blueprint_utils import clear_blueprint_override, clear_source_override
        from vbt.precompute.cfg_db import clear_cfg_db
        from vbt.conditions.cpp_conditions import clear_cpp_conditions_cache
        clear_blueprint_override(); clear_source_override(); clear_cfg_db()
        clear_cpp_conditions_cache()       # bound the AST/CFG condition memo per trace
    except Exception:
        pass
    set_asm_setter_map_job(None); set_cpp_setter_map_job(None)
    set_cpp_file_writes_job(None); set_fn_facts_job(None)
    set_asm_setters_full_job(None); set_chain_facts_job(None)

    warnings: List[Dict[str, Any]] = []
    try:
        _DA.set_load_only(True)
        # touch the DB engine early so a totally-absent index.db fails clearly.
        try:
            from api.index_db.engine import get_engine
            get_engine(precompute_job_id)
        except DbArtifactMissing:
            raise
        except Exception as exc:
            raise DbArtifactMissing(f"index.db unavailable for kb {precompute_job_id}: {exc}")

        with _Phase("artifact validation"):
            from vbt.precompute.graph_db import (
                FN_GRAPH_ADJ_ARTIFACT, FN_GRAPH_ADJ_VERSION,
                REVERSE_ADJ_ARTIFACT, ROUTE_GRAPH_VERSION)
            from vbt.precompute.resolvers_db import (
                NAME_ALIAS_ARTIFACT, MEMBERSHIP_ARTIFACT, CONST_ARTIFACT,
                MODIFIER_ARTIFACT, RESOLVERS_VERSION)
            from vbt.precompute.fn_facts_db import FN_FACTS_ARTIFACT
            _require(precompute_job_id, FN_GRAPH_ADJ_ARTIFACT, FN_GRAPH_ADJ_VERSION)
            _require(precompute_job_id, REVERSE_ADJ_ARTIFACT, ROUTE_GRAPH_VERSION)
            _require(precompute_job_id, MODIFIER_ARTIFACT, RESOLVERS_VERSION)
            _require(precompute_job_id, NAME_ALIAS_ARTIFACT, RESOLVERS_VERSION)
            _require(precompute_job_id, MEMBERSHIP_ARTIFACT, RESOLVERS_VERSION)
            _require(precompute_job_id, CONST_ARTIFACT, RESOLVERS_VERSION)
            _require(precompute_job_id, FN_FACTS_ARTIFACT, 1)   # fn_facts manifest version is literal 1
            _require(precompute_job_id, CPP_SETTER_MAP_COVERAGE_ARTIFACT, COVERAGE_VERSION)
            _require(precompute_job_id, ASM_SETTERS_FULL_COVERAGE_ARTIFACT, COVERAGE_VERSION)
            if prune:
                _require(precompute_job_id, CHAIN_FACTS_ARTIFACT, CHAIN_FACTS_VERSION)

        # ---- arm DB-only lookups (no live fallback armed: NOT set_asm_setter_map_job) ----
        strict_load_resolvers(precompute_job_id, bp, src)
        set_cpp_setter_map_job(precompute_job_id)        # load_cpp_setters is DB-only
        set_asm_setters_full_job(precompute_job_id)      # COMPLETE ASM map (#15), NOT the legacy map
        set_fn_facts_job(precompute_job_id)              # C++ attribution fallback
        if prune:
            set_chain_facts_job(precompute_job_id)

        from vbt.precompute.graph_db import load_fn_graph_adj, load_reverse_adj
        from vbt.precompute.cpp_setter_map_db import load_cpp_setters
        from vbt.resolve.name_resolver import resolve as resolve_aliases
        from vbt.precompute.modifier_index import get_modifier_index

        adj = load_fn_graph_adj(precompute_job_id)
        if adj is None:
            raise DbArtifactMissing(f"fn_graph_adj blob absent for kb {precompute_job_id}")
        rev_res = load_reverse_adj(precompute_job_id)
        if rev_res is None:
            raise DbArtifactMissing(f"reverse_adj blob absent for kb {precompute_job_id}")
        node_types = rev_res[1]                            # stem -> "cpp" | "asm" (DB-only)
        # every node that exists in the graph (as caller OR callee) — for attribution validation.
        graph_nodes: Set[Node] = set(adj.keys())
        for outs in adj.values():
            for (cs, cf, _l, _c) in outs:
                graph_nodes.add((cs, cf))

        cpp_cov = load_coverage(precompute_job_id, CPP_SETTER_MAP_COVERAGE_ARTIFACT) or {}
        asm_cov = load_coverage(precompute_job_id, ASM_SETTERS_FULL_COVERAGE_ARTIFACT) or {}

        # ---- Step 1: setters across the high-certainty alias set (DB-only) ----
        with _Phase("alias resolution"):
            alias_set = resolve_aliases(variable, language, src, home_hint=home_hint)
        targets = [(variable, language)] + [(a.name, a.language) for a in alias_set.aliases]
        _log(f"targets: {targets}")
        midx = get_modifier_index(bp, src)

        setter_nodes: Set[Node] = set()
        setter_diag: List[Dict[str, Any]] = []
        excluded = 0
        with _Phase("setter discovery"):
            for name, lang in targets:
                own = (lang == language)
                stems = (list(candidate_stems) if (own and candidate_stems)
                         else sorted(midx.files_for(name, lang)))
                for stem in stems:
                    if lang == "cpp":
                        status = cpp_cov.get(stem)
                        if status is None or status == FAILED:
                            raise DbArtifactMissing(
                                f"cpp_setter_map coverage for stem {stem!r} is "
                                f"{status or 'ABSENT'} (kb {precompute_job_id}) — incomplete precompute; "
                                f"rerun `python -m vbt.precompute.chain_facts_db {precompute_job_id}`")
                        if status == EMPTY:
                            continue                       # built fine, no setters here
                        tail = name.split(".")[-1].split("->")[-1]
                        root_fp = [name] if ("." in name or "->" in name) else None
                        sites = load_cpp_setters(precompute_job_id, stem, tail, root_fp)
                        if sites is None:
                            raise DbArtifactMissing(
                                f"cpp_setter_map coverage says OK for stem {stem!r} but its blob is "
                                f"missing (kb {precompute_job_id}) — drift; rerun precompute")
                        for s in sites:
                            node = _attribute_cpp(stem, s, graph_nodes)
                            if node is None:
                                if allow_unattributed_setters:
                                    excluded += 1
                                    warnings.append({"code": "unattributed_setter", "file": stem,
                                                     "line": int(getattr(s, "line", 0) or 0)})
                                    continue
                                raise UnattributedSetter(
                                    f"C++ setter of {name!r} at {stem}:{getattr(s,'line',0)} cannot be "
                                    f"attributed to a (stem,fn) node in fn_graph_adj — pass "
                                    f"allow_unattributed_setters=true to exclude it")
                            setter_nodes.add(node)
                            setter_diag.append({"var": name, "node": _node_id(node[0], node[1], "cpp"),
                                                "line": int(getattr(s, "line", 0) or 0)})
                    else:  # ASM — COMPLETE map (#15), coverage rule (#4); NEVER live-scans
                        status = asm_cov.get(stem)
                        if status is None or status == FAILED:
                            raise DbArtifactMissing(
                                f"asm_setters_full coverage for stem {stem!r} is "
                                f"{status or 'ABSENT'} (kb {precompute_job_id}) — incomplete precompute; "
                                f"rerun `python -m vbt.precompute.chain_facts_db {precompute_job_id}`")
                        if status == EMPTY:
                            continue
                        sites = get_asm_setters_full(stem, name)
                        if not sites:
                            continue                       # OK stem, var absent ⇒ genuinely no setter
                        setter_nodes.add((stem, stem))
                        setter_diag.append({"var": name, "node": stem,
                                            "line": int(getattr(sites[0], "line", 0) or 0)})
        _log(f"setter nodes: {sorted(_node_id(n[0], n[1], node_types.get(n[0],'asm')) for n in setter_nodes)} "
             f"(excluded {excluded})")

        # ---- Step 2/3: LCA(s) or plastic-auth forced LCA ----
        lca_list: List[Tuple[Node, List[Node]]] = []
        forced = False
        if domain in DOMAIN_FORCED_LCA:
            forced = True
            fstem, _flang, ffn = DOMAIN_FORCED_LCA[domain]
            fnode: Node = (fstem, ffn)
            with _Phase(f"plastic-auth forced LCA {fstem}::{ffn} (LCA computation SKIPPED)"):
                if fnode not in graph_nodes:
                    if allow_missing_forced_lca:
                        warnings.append({"code": "forced_lca_absent",
                                         "node": f"{fstem}::{ffn}"})
                        _log("forced LCA absent — returning zero chains (allow_missing_forced_lca)")
                        return _finish([], False, warnings, t_start, debug, setter_diag,
                                       setter_nodes, node_types, [], excluded, prune, [])
                    raise ForcedLcaAbsent(
                        f"forced LCA {fstem}::{ffn} for domain {domain!r} is absent from the call "
                        f"graph of kb {precompute_job_id} — pass allow_missing_forced_lca=true to "
                        f"return zero chains instead")
                lca_list = [(fnode, sorted(setter_nodes))]
        else:
            with _Phase("LCA computation"):
                lca_list = lca_roots(sorted(setter_nodes), adj, node_types)
        _log(f"LCAs: {[_node_id(n[0], n[1], node_types.get(n[0],'asm')) for n, _ in lca_list]}")

        # ---- Step 4/5/6: chains, subset prune, conservative prune ----
        all_chains: List[List[str]] = []
        truncated = False
        pruned_diag: List[Dict[str, Any]] = []
        facts = get_chain_facts() if prune else None
        if prune and facts is None:
            raise DbArtifactMissing(f"chain_facts blob absent for kb {precompute_job_id} (prune=true)")

        for lca_node, _cov in lca_list:
            with _Phase(f"chains for LCA {_node_id(lca_node[0], lca_node[1], node_types.get(lca_node[0],'asm'))}"):
                chains, trunc = chains_to_lca(lca_node, adj, node_types,
                                              max_depth=max_chain_depth, max_chains=max_chains_per_lca)
                truncated = truncated or trunc
                chains, n_sub = _subset_prune(chains)
                if n_sub:
                    _log(f"subset prune dropped {n_sub} chain(s)")
                if prune:
                    kept: List[List[str]] = []
                    checked = 0
                    for ch in sorted(chains, key=len):
                        if checked >= max_feasibility_checks:
                            kept.append(ch)                 # over budget → unknown → keep
                            truncated = True
                            continue
                        checked += 1
                        v = chain_facts_verdict(ch, facts)
                        if v.infeasible:
                            pruned_diag.append({"chain": ch, "reason": v.reason})
                        else:
                            kept.append(ch)
                    if pruned_diag:
                        _log(f"conservative prune dropped {len(chains) - len(kept)} chain(s)")
                    chains = kept
                all_chains.extend(chains)

        return _finish(all_chains, truncated, warnings, t_start, debug, setter_diag,
                       setter_nodes, node_types, lca_list, excluded, prune, pruned_diag)
    finally:
        # #13: reset every global this fn touched so a Celery worker can't leak DB-only state.
        _DA.set_load_only(prev_load_only)
        set_cpp_setter_map_job(None)
        set_asm_setters_full_job(None)
        set_fn_facts_job(None)
        set_chain_facts_job(None)


def _to_hops(chain: List[str], node_types: Dict[str, str]) -> List[Dict[str, Any]]:
    hops: List[Dict[str, Any]] = []
    for node in chain:
        if "::" in node:
            stem, fn = node.split("::", 1)
        else:
            stem, fn = node, None
        if node_types.get(stem, "asm") == "cpp":
            hops.append({"file": stem, "function": fn})
        else:
            hops.append({"file": stem})
    return hops


def _finish(chains: List[List[str]], truncated: bool, warnings: List[Dict[str, Any]],
            t_start: float, debug: bool, setter_diag, setter_nodes, node_types,
            lca_list, excluded: int, prune: bool, pruned_diag) -> Dict[str, Any]:
    hop_chains = [_to_hops(ch, node_types) for ch in chains]
    out: Dict[str, Any] = {"chains": hop_chains, "truncated": truncated, "warnings": warnings}
    if excluded:
        out["excludedSetterCount"] = excluded
    if debug:
        out["_debug"] = {
            "setters": setter_diag,
            "setterNodes": sorted(_node_id(n[0], n[1], node_types.get(n[0], "asm")) for n in setter_nodes),
            "lcas": [_node_id(n[0], n[1], node_types.get(n[0], "asm")) for n, _ in lca_list],
            "prunedChains": pruned_diag,
            "excludedSetterCount": excluded,
            "dbOnly": True,
            "prune": prune,
            "rawChains": chains,
            "elapsedSec": round(time.perf_counter() - t_start, 3),
        }
    return out


# --------------------------------------------------------------------------- #
# CLI (req #10) — Celery-backed via the FastAPI endpoint; dev-only --local in-process
# --------------------------------------------------------------------------- #
def _cli(argv=None) -> int:
    import argparse
    import json
    import sys
    import time as _time

    ap = argparse.ArgumentParser(prog="vbt.lca_trace",
                                 description="DB-only LCA chain trace (variable → LCA → chains).")
    ap.add_argument("--kb-id", required=True, help="knowledge base / precompute job id")
    ap.add_argument("--variable", required=True)
    ap.add_argument("--language", default="asm", choices=["asm", "cpp"])
    ap.add_argument("--domain", default=None, help="e.g. plastic_authentication (forces LCA)")
    ap.add_argument("--prune", action="store_true", help="conservatively drop provably-dead chains")
    ap.add_argument("--allow-missing-forced-lca", action="store_true")
    ap.add_argument("--allow-unattributed-setters", action="store_true")
    ap.add_argument("--max-chains-per-lca", type=int, default=200)
    ap.add_argument("--max-chain-depth", type=int, default=None)
    ap.add_argument("--max-feasibility-checks", type=int, default=32)
    ap.add_argument("--debug", action="store_true", help="also emit lca_trace.debug.json")
    ap.add_argument("--out", default=None, help="write the chains JSON here (default: stdout)")
    # transport
    ap.add_argument("--api-base", default="http://localhost:8000")
    ap.add_argument("--token", default=None, help="bearer token (else use --username/--password)")
    ap.add_argument("--username", "--email", dest="username", default=None)
    ap.add_argument("--password", default=None)
    ap.add_argument("--wait", action="store_true", help="poll until the job finishes")
    ap.add_argument("--poll-interval", type=float, default=2.0)
    ap.add_argument("--timeout", type=float, default=600.0)
    ap.add_argument("--local", action="store_true",
                    help="dev-only: run the core in-process (no API/Celery/auth)")
    a = ap.parse_args(argv)

    trace_options = {
        "max_chains_per_lca": a.max_chains_per_lca,
        "max_chain_depth": a.max_chain_depth,
        "max_feasibility_checks": a.max_feasibility_checks,
    }

    # ---- dev-only --local: run the core directly (no API/Celery), reading index.db ----
    if a.local:
        from api.config import settings
        from api.tasks._task_utils import find_blueprint_dir
        from api.storage.workspace import WorkspaceManager
        bp = find_blueprint_dir(settings.JOBS_BASE_DIR / a.kb_id / "output") or \
            (settings.JOBS_BASE_DIR / a.kb_id / "output")
        src = (WorkspaceManager(a.kb_id).get_pipeline_options() or {}).get("source_path") or ""
        result = trace_variable_to_lca_chains(
            a.kb_id, a.variable, a.language, domain=a.domain, prune=a.prune,
            allow_missing_forced_lca=a.allow_missing_forced_lca,
            allow_unattributed_setters=a.allow_unattributed_setters,
            max_chains_per_lca=a.max_chains_per_lca, max_chain_depth=a.max_chain_depth,
            max_feasibility_checks=a.max_feasibility_checks,
            blueprint_dir=str(bp), asm_dir=str(src), debug=a.debug)
        public = {k: result[k] for k in ("chains", "truncated", "warnings") if k in result}
        if "excludedSetterCount" in result:
            public["excludedSetterCount"] = result["excludedSetterCount"]
        payload = json.dumps(public, indent=2)
        if a.out:
            Path(a.out).write_text(payload)
            print(f"wrote {a.out} — {len(public['chains'])} chains", file=sys.stderr)
        else:
            print(payload)
        return 0

    # ---- API mode: POST /vbt/lca-trace → poll → download lca_trace.json ----
    import requests
    base = a.api_base.rstrip("/")
    token = a.token
    if not token:
        if not (a.username and a.password):
            ap.error("API mode needs --token OR --username/--password (or use --local)")
        r = requests.post(f"{base}/v1/auth/login",
                          json={"username": a.username, "password": a.password}, timeout=30)
        r.raise_for_status()
        token = r.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    body = {"kb_id": a.kb_id, "variable": a.variable, "language": a.language,
            "domain": a.domain, "prune": a.prune,
            "allow_missing_forced_lca": a.allow_missing_forced_lca,
            "allow_unattributed_setters": a.allow_unattributed_setters,
            "debug": a.debug, "trace_options": trace_options}
    r = requests.post(f"{base}/v1/jobs/vbt/lca-trace", json=body, headers=headers, timeout=60)
    r.raise_for_status()
    job_id = r.json()["job_id"]
    print(f"dispatched job {job_id}", file=sys.stderr)

    if not a.wait:
        print(json.dumps({"job_id": job_id}))
        return 0

    deadline = None  # wall-clock loop bounded by --timeout via a counter (no Date.now in script ok here)
    elapsed = 0.0
    status_str = "pending"
    while elapsed < a.timeout:
        sr = requests.get(f"{base}/v1/jobs/vbt/{job_id}/status", headers=headers, timeout=30)
        sr.raise_for_status()
        status_str = sr.json().get("status", "pending")
        if status_str in ("success", "failed", "expired"):
            break
        _time.sleep(a.poll_interval)
        elapsed += a.poll_interval
    if status_str != "success":
        meta = requests.get(f"{base}/v1/jobs/vbt/{job_id}/status", headers=headers, timeout=30).json()
        print(f"job {job_id} ended status={status_str}: {meta.get('error')}", file=sys.stderr)
        return 1

    res = requests.get(f"{base}/v1/jobs/{job_id}/results", headers=headers, timeout=30)
    res.raise_for_status()
    files = res.json().get("files", [])
    target = next((f for f in files if f.get("name") == "lca_trace.json"), None)
    if not target:
        print(f"job {job_id} produced no lca_trace.json (files={[f.get('name') for f in files]})",
              file=sys.stderr)
        return 1
    dl = requests.get(f"{base}/v1/jobs/{job_id}/files/{target['path']}", headers=headers, timeout=60)
    dl.raise_for_status()
    content = dl.content.decode("utf-8")
    if a.out:
        Path(a.out).write_text(content)
        print(f"wrote {a.out}", file=sys.stderr)
    else:
        print(content)
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
