"""vbt.uiexport — turn VBT trace output into per-variable JSON fixtures that
match the Zenflow Setter-Analysis "table" UI contract.

Pipeline (see vbt/SPEC.md and the plan):
    trace_softCardValue_d3/  ──structural──►  per-variable dict (facts + .t sides,
                                              {b,t}/business_name placeholders empty)
                             ──prose────────►  same dict, empty slots filled by Gemini
                             ──emit─────────►  <frontend>/src/api/mocks/generated/*.json
                                               + generatedSetterTables.js manifest

The structural + prose layers are source-agnostic and are reused unchanged by the
future on-demand API (fed by engine.trace_root_variable instead of the on-disk
trace, cached in a DB instead of disk).
"""
