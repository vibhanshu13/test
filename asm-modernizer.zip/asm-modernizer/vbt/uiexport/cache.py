"""Disk cache for the Gemini PROSE layer of vbt.uiexport.

The prose layer is the only expensive (LLM-burning) stage of the
trace → UI-JSON pipeline. Re-running the generator for a variable whose
*structural* (pre-fill) shape has not changed should be free, so we cache the
fully-FILLED dict keyed by the variable name and a stable hash of the pre-fill
structural dict.

Cache key derivation (the contract used by ``prose.fill_prose``):
  • ``struct_hash`` is computed over the PRE-FILL structural dict — the facts +
    empty placeholders the structural layer emitted, BEFORE any prose was
    written. Two pre-fill structs that are byte-identical after canonical
    JSON serialisation (sorted keys) share a hash, so the same facts always
    reuse the same filled result regardless of dict ordering.
  • The stored artefact is the FILLED dict (facts + prose), so a cache hit
    skips Gemini entirely.

Stored at ``<cache_dir>/<variable>.<struct_hash[:12]>.json``.
"""
from __future__ import annotations

import hashlib
import json
import logging
import re
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Filesystem-safe variable stem (mirror the dependentVariables/<name>.json stem
# rule: a variable name is the file stem). Anything outside this set is replaced
# so a pathological raw variable name can never escape the cache directory.
_SAFE_STEM_RE = re.compile(r"[^A-Za-z0-9_.+-]")


def _safe_stem(variable: str) -> str:
    """Return a filesystem-safe stem for *variable* (never empty, never traversal)."""
    stem = _SAFE_STEM_RE.sub("_", (variable or "").strip())
    # Collapse any leading dots so we can never produce a hidden / parent path.
    stem = stem.lstrip(".") or "_var"
    return stem


class ProseCache:
    """Content-addressed cache of FILLED per-variable UI dicts.

    A single instance is cheap; pass it into ``prose.fill_prose(cache=...)`` and
    it will short-circuit the LLM on a hit. Thread-safety is not required here —
    each variable maps to its own file and writes are atomic (temp + rename).
    """

    def __init__(self, cache_dir: Path):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ #
    # Hashing
    # ------------------------------------------------------------------ #
    @staticmethod
    def struct_hash(prefill_struct: dict) -> str:
        """Stable SHA-256 hex of the PRE-FILL structural dict.

        Canonicalises with ``json.dumps(..., sort_keys=True)`` so the hash is
        invariant to key ordering and whitespace. ``default=str`` makes the
        serialisation total even if a non-JSON-native value sneaks in (it would
        still hash deterministically). The full hex digest is returned; callers
        that want a short key slice it (the filename uses ``[:12]``).
        """
        # ``member_of`` / ``counterpart`` are purely-structural facts (which struct/
        # DSECT a variable belongs to + its cross-language twin) that do NOT influence
        # the prose. Exclude them from the hash so adding them never invalidates cached
        # prose — a regen that only GAINS membership still hits the existing cache.
        if isinstance(prefill_struct, dict) and (
            "member_of" in prefill_struct or "counterpart" in prefill_struct
        ):
            prefill_struct = {k: v for k, v in prefill_struct.items()
                              if k not in ("member_of", "counterpart")}
        canonical = json.dumps(
            prefill_struct,
            sort_keys=True,
            ensure_ascii=False,
            separators=(",", ":"),
            default=str,
        )
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    # ------------------------------------------------------------------ #
    # Paths
    # ------------------------------------------------------------------ #
    def _path(self, variable: str, struct_hash: str) -> Path:
        return self.cache_dir / f"{_safe_stem(variable)}.{struct_hash[:12]}.json"

    # ------------------------------------------------------------------ #
    # Get / put
    # ------------------------------------------------------------------ #
    def get(self, variable: str, struct_hash: str) -> Optional[dict]:
        """Return the cached FILLED dict for (variable, struct_hash), or None."""
        path = self._path(variable, struct_hash)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:  # corrupt / partial file — treat as a miss
            logger.warning("ProseCache: ignoring unreadable cache file %s: %s", path, exc)
            return None

    def put(self, variable: str, struct_hash: str, filled: dict) -> None:
        """Store the FILLED dict for (variable, struct_hash). Atomic write."""
        path = self._path(variable, struct_hash)
        tmp = path.with_suffix(path.suffix + ".tmp")
        try:
            tmp.write_text(
                json.dumps(filled, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            tmp.replace(path)  # atomic on POSIX
        except Exception as exc:
            logger.warning("ProseCache: failed to write cache file %s: %s", path, exc)
            # Best-effort cleanup of the temp file.
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:
                pass
