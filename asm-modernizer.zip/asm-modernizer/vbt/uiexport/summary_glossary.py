"""Plain-language glossary + humaniser for the Summary view (build_summary.py).

Goal (product owner's words): conditions must be "not vague and not technical".
So: keep REAL values and the root variable name VERBATIM, but translate the
machine predicate into a precise business sentence. Nothing here invents facts —
every entry maps a predicate/enum we actually saw in the trace to its business
meaning. Unknown predicates fall back to a light literal cleanup (never dropped,
never guessed).

Scope: authored for `softCardValue`'s real condition set (the plastic-auth /
CID-database decision logic). The deterministic fallbacks keep it usable for any
variable; extend the maps to raise quality for new variables.
"""
from __future__ import annotations

import re
from typing import Dict, List


# --------------------------------------------------------------------------- #
# Domain-TERM glossary — short plain definitions for jargon that appears in the
# rendered conditions/values. The UI underlines these terms and shows the
# definition on hover, so conditions stay concise. (Edit freely — these are the
# product team's terms.)  "CID = Cardholder Identification" is corroborated by
# the trace's own field docs (numberOfCidRecords, cidDbSelect).
# --------------------------------------------------------------------------- #
GLOSSARY_TERMS: Dict[str, str] = {
    "CID record": "A record in the cardholder-identification (CID) database — the "
                  "stored card-security details the presented card is matched against.",
    "CID records": "Records in the cardholder-identification (CID) database — the "
                   "stored card-security details the presented card is matched against.",
    "CID": "Cardholder Identification — the card-security identification system / database.",
    "4CSC": "4-digit Card Security Code — the 4-digit code on the card; matched statically or dynamically during authentication.",
    "5CSC": "5-digit Card Security Code — the security value read from a swiped card.",
    "4DBC": "A 4-digit card-security code used in authentication (entered by keying or read from a swipe).",
    "effective date": "The date a stored card record becomes valid (takes effect).",
    "Express Pay": "A contactless / tokenised fast-payment transaction type.",
    "Carver": "The core card-authentication engine the transaction is routed through.",
    "balance-transfer": "A transaction that moves a balance from another account, routed differently.",
}


def glossary_terms() -> List[Dict[str, str]]:
    """Term → definition list (longest terms first so the UI matches greedily)."""
    items = sorted(GLOSSARY_TERMS.items(), key=lambda kv: -len(kv[0]))
    return [{"term": k, "definition": v} for k, v in items]


# --------------------------------------------------------------------------- #
# Root variable + file boxes
# --------------------------------------------------------------------------- #
ROOT = {
    "business_name": "Soft Card Value",
    "what_it_is": (
        "The label the card-authentication step puts on each transaction. It "
        "records HOW the card was presented — typed in (keyed), swiped, or "
        "contactless Express Pay — and WHETHER its security details matched. "
        "Later pricing and fraud-check steps read this label to decide what to do."
    ),
    "summary": (
        "It is decided in two places. A fast Express-Pay path sets it the moment "
        "the transaction is recognised as Express Pay. Everything else falls to "
        "the CID-database matching step, which produces one of 25 detailed "
        "outcomes based on how the card was entered and what matched."
    ),
}

BOX_NAMES = {
    "dw710000": "Credit Authorization (Plastic Auth)",
    "dw780000": "CID Database Record Matching",
    "aa71": "Transaction Intake",
    "dw730000": "Carver / CID-Inquiry Gateway",
}

# One-line, product-facing "what this box decides".
BOX_SUMMARIES = {
    "dw710000": (
        "The fast path. If the transaction carries a wallet payment-token or is "
        "flagged Express Pay, the value is set to Express Pay — no card lookup needed."
    ),
    "dw780000": (
        "The main path. After the card's CID records are looked up, the outcome "
        "depends on how the card was entered (keyed / swiped / with a security "
        "code) and what matched (expiration date, 4CSC, effective date)."
    ),
}


def box_summary(stem: str) -> str:
    return BOX_SUMMARIES.get(stem, "")


# Family bucket for an outcome value (for grouping the distinct-values list).
def value_family(value: str) -> str:
    m = value.split("::")[-1]
    if m.startswith("ExpressPay"):
        return "Express Pay"
    if m.startswith("Keyed"):
        return "Keyed entry"
    if m.startswith("Swipe"):
        return "Swiped entry"
    return "Other"


# --------------------------------------------------------------------------- #
# Enum clauses — full sentences for both polarities. Used when an enum compare
# reads as a complete state ("the card was swiped"), so we don't prefix a
# variable subject. (positive, negated).
# --------------------------------------------------------------------------- #
ENUM_CLAUSE = {
    # how the card was presented / which DB lookup mode (cidDbSelect)
    "PaMessage::ManualCardNumberOnly":
        ("the card number only was keyed (no expiry, no security code)",
         "the entry mode was not card-number-only"),
    "PaMessage::ManualExpirationDateOnly":
        ("the card number + expiration date were keyed",
         "the entry mode was not card + expiration date"),
    "PaMessage::Manual4dbcOnly":
        ("the card number + 4-digit security code (4DBC) were keyed",
         "the entry mode was not card + 4-digit security code"),
    "PaMessage::MagneticSwipe":
        ("the card was swiped (magnetic stripe)",
         "the card was not swiped"),
    "PaMessage::SwipeWith4dbc":
        ("the card was swiped and a 4-digit security code (4DBC) was entered",
         "the card was not swiped with a 4-digit security code"),
    "PaMessage::PreviousInquiry4dbc":
        ("a previous 4DBC inquiry result was reused",
         "no previous 4DBC inquiry result was reused"),
    # CID database lookup result (cidioReturnCode)
    "CidioReturn::NoCidRecord":
        ("no matching CID record was found in the database",
         "a matching CID record was found in the database"),
    "CidioReturn::CardNumberAndExpirationDateMatch":
        ("a record matched on both card number and expiration date",
         "no record matched on both card number and expiration date"),
    "CidioReturn::CidRecordFound":
        ("a matching CID record was found",
         "no matching CID record was found"),
    # match indicator (effective-date resolution) (MatchCidInd)
    "MatchCidInd::InitialIndicator":
        ("no effective-date match was found",
         "an effective-date match was found"),
    "MatchCidInd::SingleEffectiveDateMatch":
        ("exactly one stored record matched on effective date",
         "it was not a single effective-date match"),
    "MatchCidInd::MultipleEffectiveDateMatch":
        ("more than one stored record matched on effective date",
         "it was not a multiple effective-date match"),
    "MatchCidInd::BestCreateDateNoEffectiveDateMatch":
        ("no effective-date match, so the best create-date record was used",
         "the best create-date fallback was not used"),
    # dynamic 4CSC
    "Dynamic4cscMatchIndicators::Dynamic4cscMatchFound":
        ("a dynamic 4CSC match was found",
         "no dynamic 4CSC match was found"),
    "Dynamic4cscMatchIndicators::FundingTrxnMatchedATokenDCID":
        ("a funding transaction matched a tokenised dynamic CID",
         "no funding transaction matched a tokenised dynamic CID"),
    # transaction code
    "CasTransactionCode::CreditRequest":
        ("the transaction is a credit authorization request",
         "the transaction is not a credit authorization request"),
    "CasTransactionCode::AddNegative":
        ("the transaction is an add-to-negative-file request",
         "the transaction is not an add-to-negative-file request"),
    "CasTransactionCode::PostAuthorization":
        ("the transaction is a post-authorization",
         "the transaction is not a post-authorization"),
    "CasTransactionCode::Reversal":
        ("the transaction is a reversal",
         "the transaction is not a reversal"),
    "CasTransactionCode::WorkedFromReferralQue":
        ("the transaction is a worked-from-referral request",
         "the transaction is not a worked-from-referral request"),
    "CasTransactionCode::ForceEntryToRefer":
        ("the transaction is a force-entry-to-referral request",
         "the transaction is not a force-entry-to-referral request"),
    "CasTransactionCode::ForceEntryToAA":
        ("the transaction is a force-entry-to-account request",
         "the transaction is not a force-entry-to-account request"),
    "CasTransactionCode::AuthorizerStatusCode":
        ("the transaction is an authorizer-status-code request",
         "the transaction is not an authorizer-status-code request"),
}

# Simple value words for subject-based renders ("<subject> is on").
ENUM_LABELS = {
    "Pa::Off": "off",
    "Pa::On": "on",
    "Pa::Good": "valid",
    "Cas::On": "on",
    "SecurityCodeLength::Keyed4dbc": "a keyed 4-digit security code",
    "Fuzzy4cscLogic::CscAllZeroesWithCIDrecord": "an all-zero security code against a CID record",
}


# --------------------------------------------------------------------------- #
# Outcome value (SoftCardValueDetail::*) → business label
# --------------------------------------------------------------------------- #
VALUE_LABELS = {
    "SoftCardValueDetail::ExpressPayTransaction":
        "Express Pay transaction",
    "SoftCardValueDetail::KeyedCardNumberOnlyTransaction":
        "Keyed — card number only",
    "SoftCardValueDetail::KeyedTransactionWithExpDateNoMatchExpDate":
        "Keyed with expiration date — expiration date did NOT match",
    "SoftCardValueDetail::KeyedTransactionWithExpDateMatchExpDate":
        "Keyed with expiration date — expiration date matched",
    "SoftCardValueDetail::KeyedTransactionWith4cscNoMatch4csc":
        "Keyed with 4CSC — 4CSC did NOT match",
    "SoftCardValueDetail::KeyedTransactionWith4cscAndExpDateMatchDynamic4cscAndExpDate":
        "Keyed with 4CSC + expiration date — dynamic 4CSC and expiration date matched",
    "SoftCardValueDetail::KeyedTransactionWith4cscAndExpDateMatch4cscAndExpDate":
        "Keyed with 4CSC + expiration date — 4CSC and expiration date matched",
    "SoftCardValueDetail::KeyedTransactionWith4cscAndExpDateMatchDynamic4cscAndNoMatchExpDate":
        "Keyed with 4CSC + expiration date — dynamic 4CSC matched, expiration date did not",
    "SoftCardValueDetail::KeyedTransactionWith4cscAndExpDateMatch4cscNoMatchExpDate":
        "Keyed with 4CSC + expiration date — 4CSC matched, expiration date did not",
    "SoftCardValueDetail::KeyedTransactionWith4cscMatchedDynamic4csc":
        "Keyed with 4CSC — dynamic 4CSC matched",
    "SoftCardValueDetail::KeyedTransactionWith4cscMatched4csc":
        "Keyed with 4CSC — 4CSC matched",
    "SoftCardValueDetail::KeyedTransactionWith4cscInstantAccountMatchNoTempCIDrecord":
        "Keyed with 4CSC — instant-account match, no temporary CID record",
    "SoftCardValueDetail::SwipeTransactionNoMatch5csc":
        "Swipe — 5CSC did NOT match",
    "SoftCardValueDetail::SwipeTransactionMatch5cscNoEffDateMatch":
        "Swipe — 5CSC matched, no effective-date match",
    "SoftCardValueDetail::SwipeTransactionMatch5cscMatchEffDate":
        "Swipe — 5CSC matched, single effective-date match",
    "SoftCardValueDetail::SwipeTransactionMatch5cscMatchMultipleEffDateBestCreateDate":
        "Swipe — 5CSC matched, multiple effective-date matches (best create date used)",
    "SoftCardValueDetail::SwipeTransactionMatch5cscNoMatchEffDateBestCreateDate":
        "Swipe — 5CSC matched, no effective-date match (best create date used)",
    "SoftCardValueDetail::SwipeTransactionWith4cscMatch5cscButNot4cscNoEffDateMatch":
        "Swipe + 4CSC — 5CSC matched but 4CSC did not, no effective-date match",
    "SoftCardValueDetail::SwipeTransactionWith4cscMatch5cscButNot4cscMatchEffDate":
        "Swipe + 4CSC — 5CSC matched but 4CSC did not, single effective-date match",
    "SoftCardValueDetail::SwipeTransactionWith4cscMatch5cscButNot4cscMatchMultipleEffDateBestCreateDate":
        "Swipe + 4CSC — 5CSC matched but 4CSC did not, multiple effective-date matches (best create date)",
    "SoftCardValueDetail::SwipeTransactionWith4cscMatch5cscButNot4cscNoMatchEffDateBestCreateDate":
        "Swipe + 4CSC — 5CSC matched but 4CSC did not, no effective-date match (best create date)",
    "SoftCardValueDetail::SwipeTransactionWith4cscMatch5cscand4cscNoEffDateMatch":
        "Swipe + 4CSC — both 5CSC and 4CSC matched, no effective-date match",
    "SoftCardValueDetail::SwipeTransactionWith4cscMatch5cscand4cscMatchEffDate":
        "Swipe + 4CSC — both 5CSC and 4CSC matched, single effective-date match",
    "SoftCardValueDetail::SwipeTransactionWith4cscMatch5cscand4cscMatchMultipleEffDateBestCreateDate":
        "Swipe + 4CSC — both 5CSC and 4CSC matched, multiple effective-date matches (best create date)",
    "SoftCardValueDetail::SwipeTransactionWith4cscMatch5cscand4cscNoMatchEffDateBestCreateDate":
        "Swipe + 4CSC — both 5CSC and 4CSC matched, no effective-date match (best create date)",
    "SoftCardValueDetail::SwipeTransactionWith4cscNoMatch5csc":
        "Swipe + 4CSC — 5CSC did NOT match",
}


# --------------------------------------------------------------------------- #
# Dependent-variable business names + descriptions + value sets
# --------------------------------------------------------------------------- #
VAR_INFO = {
    "@CASVIS1": ("CAS Vision Global Switch", "A system-wide switch indicating CID-inquiry processing is enabled."),
    "L7DSTS": ("Transaction Status Flag", "Status bits on the incoming request; bit X'40' marks an 8001 CID-inquiry."),
    "carverActive": ("Carver Engine Active", "Whether the Carver card-authentication engine is switched on."),
    "cidInquiryActive": ("CID Inquiry Active", "Whether CID-inquiry processing is switched on."),
    "transactionCode": ("Transaction Code", "The kind of financial transaction being processed (e.g. credit request)."),
    "tableCollectedIndicator": ("Tables Collected Indicator", "Whether the pricing/fee tables have already been gathered."),
    "exitIndicator": ("Exit Indicator", "Signals that processing should stop early."),
    "gnaBalXferInd": ("Balance-Transfer Indicator", "Flags a balance-transfer / GNA transaction."),
    "specialRoutingMember": ("Special Routing Member", "Flags a specially-routed transaction."),
    "linkSourceArea": ("Link Source Area", "Work area holding the source link for the transaction."),
    "lstknpoa": ("Wallet Payment Token Present", "Marks that the link carries a wallet payment token ('Y')."),
    "expressPay": ("Express Pay Flag", "Marks the transaction as Express Pay."),
    "allCidRecords": ("CID Record Buffer", "The buffer of cardholder-ID records returned from the database."),
    "numberOfCidRecords": ("Number of CID Records", "How many CID records the database returned."),
    "cidDbSelect": ("CID Database Lookup Mode", "Which method is used to look up the cardholder-ID record (card-number-only, expiry, 4DBC, swipe…)."),
    "cidioReturnCode": ("CID Lookup Result", "The result of the cardholder-ID database lookup (no record, found, matched…)."),
    "MatchCidInd": ("CID Match Indicator", "The effective-date match outcome for the selected CID record."),
    "inputExpDateNumeric": ("Expiration Date Entered", "Whether a numeric expiration date was entered."),
    "priorExpirationDateMatch": ("Prior Expiration-Date Match", "Whether the entered expiration date matched a stored one."),
    "lwrpoDynamicCidMatchResponseInd": ("Dynamic 4CSC Match Result", "The outcome of the dynamic 4CSC matching logic."),
    "softCardValue": ("Soft Card Value", "The value being decided here (guards against re-setting it)."),
    "instantAccountExistsInd": ("Instant Account Exists", "Whether an instant-account record exists for the card."),
    "cr21FilePointer": ("CR21 File Pointer", "Pointer to the CR21 instant-account file record."),
    "cr21Lrec80": ("CR21 Record", "The CR21 instant-account file record."),
    "workArea": ("Work Area", "Scratch work area for the matching routine."),
    "securityCode": ("Security Code", "The card security code length/value entered."),
    "fuzzy4cscMatchResult": ("Fuzzy 4CSC Match Result", "Outcome of approximate 4CSC matching."),
}

# Known value sets a variable can take (for the dep-var section) — business labels.
VAR_VALUES = {
    "cidDbSelect": [
        "card number only", "card + expiration date", "card + 4-digit code (4DBC)",
        "magnetic swipe", "swipe + 4DBC",
    ],
    "cidioReturnCode": [
        "no CID record", "card + expiration-date match", "CID record found",
    ],
    "MatchCidInd": [
        "no match yet", "single effective-date match",
        "multiple effective-date matches", "best create-date (no effective-date match)",
    ],
    "transactionCode": ["credit authorization request", "add-to-negative"],
}


GLOSSARY = {
    "root": ROOT,
    "var_values": VAR_VALUES,
}


# --------------------------------------------------------------------------- #
# Condition humaniser — exact-match map first, then structural fallbacks.
# Keyed on the whitespace-normalised predicate. Each entry is (positive, negated)
# so a `!(...)` wrapper flips to the right plain sentence.
# --------------------------------------------------------------------------- #
def _n(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip())


# (positive phrasing, negated phrasing)
EXACT: Dict[str, tuple] = {
    _n("(@CASVIS1 & X'01') == X'01'"):
        ("CID inquiry is switched on for the system",
         "CID inquiry is switched off for the system"),
    _n("(L7DSTS & X'40') == X'40'"):
        ("the request is a CID-inquiry transaction",
         "the request is not a CID-inquiry transaction"),
    _n("(casVision1->carverActive == 1) && (casVision1->cidInquiryActive == 1)"):
        ("the Carver engine and CID-inquiry processing are both active",
         "the Carver engine or CID-inquiry processing is not active"),
    _n("!(registers.r1 <= 0)"):
        ("the plastic-authentication work area was located",
         "the plastic-authentication work area was not located"),
    _n("(addresses->plasticAuthOnlyArea != 0) && (addresses->commonWorkArea != 0) && (addresses->isoArea != 0) && (addresses->bcis != 0) && (addresses->ccr != 0)"):
        ("all required work areas are present (plastic-auth, common, ISO, BCIS, CCR)",
         "a required work area is missing"),
    _n("lwrCommon.process.links.transactionCode == CasTransactionCode::CreditRequest"):
        ("the transaction is a credit authorization request",
         "the transaction is not a credit authorization request"),
    # SWITCH on tableCollectedIndicator: only the DEFAULT branch routes to CID
    # validation (the path to the softCardValue setters). NotCollected / Atm /
    # TablesCollected are their own explicit cases — so this is NOT "not
    # collected"; it is "none of the explicitly-handled values".
    _n("plasticAuth.process.various.tableCollectedIndicator (default case)"):
        ("the tables-collected status routes to CID validation "
         "(it is not “not collected”, “ATM”, or “already collected”)",
         "the tables-collected status does not route to CID validation"),
    _n("plasticAuth.process.various.exitIndicator == Pa::Off"):
        ("processing has not been told to exit early",
         "processing has been told to exit early"),
    _n("!((lwrCommon.process.links.gnaBalXferInd & 0x08) || (lwrCommon.process.links.gnaBalXferInd & 0x10) || (lwrCommon.specialRoutingMember & 0x10))"):
        ("the transaction is not a balance-transfer and is not specially routed",
         "the transaction is a balance-transfer or is specially routed"),
    _n("linkSourceArea != 0"):
        ("a link-source area is attached to the transaction",
         "no link-source area is attached"),
    _n("linkSourceArea->lstknpoa == 'Y'"):
        ("the transaction carries a wallet payment-token",
         "the transaction does not carry a wallet payment-token"),
    _n("lwrCommon.process.various.expressPay == Cas::On"):
        ("the transaction is flagged as Express Pay",
         "the transaction is not flagged as Express Pay"),
    _n("!((&allCidRecords) == 0)"):
        ("the CID-record buffer is available",
         "the CID-record buffer is not available"),
    _n("numberOfCidRecords == 0"):
        ("no CID records were returned from the database",
         "at least one CID record was returned from the database"),
    _n("memcmp(instantAccountExistsInd,\"A\",1)==0"):
        ("an instant account exists for this card",
         "no instant account exists for this card"),
    _n("addresses > 0"):
        ("the address work area is available",
         "the address work area is not available"),
    _n("cr21FilePointer != NULL"):
        ("the CR21 instant-account file record was located",
         "the CR21 instant-account file record was not located"),
    _n("!(DF_ER(cr21FilePointer))"):
        ("the CR21 file read succeeded",
         "the CR21 file read failed"),
    _n("workArea == 0"):
        ("the work area was not allocated",
         "the work area is available"),
    _n("(lwrCommon.process.links.securityCode.length == SecurityCodeLength::Keyed4dbc) && (plasticAuth.CIDstatusCodeInfo.fuzzy4cscMatchResult != Fuzzy4cscLogic::CscAllZeroesWithCIDrecord)"):
        ("a 4-digit security code was keyed and the 4CSC was not an all-zeros match against a CID record",
         "the 4-digit security code / 4CSC fuzzy-match precondition did not hold"),
    _n("addresses->gnaVariablesNewItem"):
        ("the account has a GNA (new-item) work area",
         "the account has no GNA (new-item) work area"),
    _n("cr21Lrec80"):
        ("the CR21 instant-account record was read",
         "the CR21 instant-account record was not read"),
    _n("plasticAuth.process.transactionInds.inputExpDateNumeric == Pa::On"):
        ("an expiration date was entered",
         "no expiration date was entered"),
    _n("plasticAuth.process.transactionInds.priorExpirationDateMatch == Pa::On"):
        ("the entered expiration date matched a stored one",
         "the entered expiration date did not match a stored one"),
    _n("memcmp(instantAccountExistsInd,\"A\",1)==0"):
        ("an instant account exists for this card",
         "no instant account exists for this card"),
}

# --------------------------------------------------------------------------- #
# Business vs PLUMBING classification.  Plumbing = pointer/null/work-area/file
# checks that are implementation detail, not a business decision — a product
# person should never see them in the primary view.  Matched on normalised raw
# (also inside a !(...) wrapper).
# --------------------------------------------------------------------------- #
_PLUMBING_EXACT = {_n(x) for x in [
    "linkSourceArea != 0",
    "!((&allCidRecords) == 0)",
    "(&allCidRecords) == 0",
    "workArea == 0",
    "!(workArea == 0)",
    "addresses > 0",
    "addresses->gnaVariablesNewItem",
    "cr21FilePointer != NULL",
    "DF_ER(cr21FilePointer)",
    "!(DF_ER(cr21FilePointer))",
    "cr21Lrec80",
    "!(registers.r1 <= 0)",
    "registers.r1 <= 0",
    "(addresses->plasticAuthOnlyArea != 0) && (addresses->commonWorkArea != 0) && (addresses->isoArea != 0) && (addresses->bcis != 0) && (addresses->ccr != 0)",
    "(lwrCommon.process.links.securityCode.length == SecurityCodeLength::Keyed4dbc) && (plasticAuth.CIDstatusCodeInfo.fuzzy4cscMatchResult != Fuzzy4cscLogic::CscAllZeroesWithCIDrecord)",
]}

_PLUMBING_RE = re.compile(
    r"\(&\w+\)\s*==\s*0|!=\s*NULL|==\s*NULL|\bDF_ER\(|registers\.r\d+|"
    r"->\s*\w*[Ww]ork[Aa]rea|\bworkArea\b"
)

# A function-call predicate (identifier directly followed by "(") that we have
# no clean translation for is implementation detail, not a business rule. Note:
# grouping parens like "(a->b == 1)" do NOT match (no identifier before the "(").
_FUNC_RE = re.compile(r"\b[A-Za-z_]\w*\(")


def condition_kind(raw: str) -> str:
    key = _n(raw)
    inner = key
    m = _NEG_RE.match(key)
    if m:
        inner = _n(m.group(1))
    if key in _PLUMBING_EXACT or inner in _PLUMBING_EXACT:
        return "plumbing"
    if key in EXACT or inner in EXACT:
        return "business"            # we have a curated plain translation
    if _PLUMBING_RE.search(key):
        return "plumbing"
    if _FUNC_RE.search(key):
        return "plumbing"            # untranslated function-call predicate
    return "business"


_NEG_RE = re.compile(r"^!\s*\((.*)\)$", re.S)


def humanize_condition(raw: str) -> str:
    """Translate one machine predicate into a precise business sentence."""
    if not raw:
        return ""
    key = _n(raw)

    # 1) exact authored map (handles its own polarity)
    if key in EXACT:
        return EXACT[key][0]

    # 2) outer negation → return the right-polarity clause
    m = _NEG_RE.match(key)
    if m:
        inner = _n(m.group(1))
        if inner in EXACT:
            return EXACT[inner][1]
        if _DYN_RE.search(inner):
            return "no dynamic 4CSC match was found (neither directly nor via a tokenised dynamic CID)"
        # flip the comparator so _structural yields the negated enum clause
        flipped = _flip_cmp(inner)
        if flipped:
            s = _structural(flipped)
            if s:
                return s
        pos = _structural(inner)
        if pos:
            return _negate_sentence(pos)
        return f"NOT ({_light_clean(inner)})"

    # 3) OR-of-enum checks on the dynamic-4CSC indicator (line 445 form)
    o = _or_of_dynamic4csc(key)
    if o:
        return o

    # 4) structural enum / comparison patterns
    s = _structural(key)
    if s:
        return s

    # 5) safe literal fallback (never fabricate)
    return _light_clean(key)


_CMP_RE = re.compile(r"^([@A-Za-z_][\w.\->\[\]]*)\s*(==|!=)\s*([A-Za-z_][\w:]*\s*[\w:]*)$")


def _strip_parens(pred: str) -> str:
    pred = pred.strip()
    while pred.startswith("(") and pred.endswith(")"):
        depth = 0
        ok = True
        for i, ch in enumerate(pred):
            depth += (ch == "(") - (ch == ")")
            if depth == 0 and i != len(pred) - 1:
                ok = False
                break
        if ok:
            pred = pred[1:-1].strip()
        else:
            break
    return pred


def _structural(pred: str) -> str:
    """Handle `<path> ==/!= <Enum::Member>` and the softCardValue self-guard."""
    pred = _strip_parens(pred)
    m = _CMP_RE.match(pred)
    if m:
        path, op, rhs = m.group(1), m.group(2), re.sub(r"\s+", "", m.group(3))
        var = _tail(path)

        # self-reference guard: softCardValue != SoftCardValueDetail::X
        if var == "softCardValue" and rhs.startswith("SoftCardValueDetail::"):
            outcome = humanize_value(rhs)
            return (f"the value is not already set to “{outcome}”" if op == "!="
                    else f"the value is already set to “{outcome}”")

        # full-clause enum (reads as a complete state, no subject prefix)
        if rhs in ENUM_CLAUSE:
            pos, neg = ENUM_CLAUSE[rhs]
            return pos if op == "==" else neg

        # subject-based value word ("<subject> is on")
        bn = VAR_INFO.get(var, (None,))[0]
        subject = bn or var
        rhs_h = ENUM_LABELS.get(rhs, _light_clean(rhs))
        verb = "is" if op == "==" else "is not"
        return f"{subject} {verb} {rhs_h}"
    return ""


_DYN_RE = re.compile(
    r"lwrpoDynamicCidMatchResponseInd\s*==\s*Dynamic4cscMatchIndicators::Dynamic4cscMatchFound.*"
    r"lwrpoDynamicCidMatchResponseInd\s*==\s*Dynamic4cscMatchIndicators::FundingTrxnMatchedATokenDCID",
    re.S,
)


def _or_of_dynamic4csc(pred: str) -> str:
    if _DYN_RE.search(pred):
        return "a dynamic 4CSC match was found (directly or via a tokenised dynamic CID)"
    return ""


def _flip_cmp(pred: str) -> str:
    """Flip a simple top-level == / != so the negation reads naturally."""
    p = _strip_parens(pred)
    if "&&" in p or "||" in p:
        return ""
    if "==" in p:
        return p.replace("==", "!=", 1)
    if "!=" in p:
        return p.replace("!=", "==", 1)
    return ""


def _negate_sentence(s: str) -> str:
    if " is not " in s:
        return s.replace(" is not ", " is ", 1)
    if " is " in s:
        return s.replace(" is ", " is not ", 1)
    return "it is NOT the case that " + s


# --------------------------------------------------------------------------- #
# Real comparison value — the verbatim RHS the predicate compares against, kept
# EXACTLY (the no-code builder needs the literal value). Returns "" when the
# predicate has no single literal/enum comparand.
# --------------------------------------------------------------------------- #
# Real comparand values worth showing to a builder: enums, quoted chars/strings,
# hex masks. Bare 0/1 (null/flag checks) are NOT meaningful "values" — skipped.
_RHS_RE = re.compile(r"(==|!=)\s*([A-Za-z_][\w]*::\s*[\w]+|'[^']*'|\"[^\"]*\"|0x[0-9A-Fa-f]+)")


def real_value_in(raw: str) -> str:
    if not raw:
        return ""
    vals = []
    first_op = None
    for m in _RHS_RE.finditer(raw):
        if first_op is None:
            first_op = m.group(1)
        v = re.sub(r"\s+", "", m.group(2))
        if v not in vals:
            vals.append(v)
    if not vals:
        return ""
    s = ", ".join(vals)
    # Polarity-aware so the chip never contradicts the plain. NET negation =
    # outer !(…) XOR inner !=  — so `!(X != Y)` (double negative) is POSITIVE
    # ("is a credit authorization request" → no ≠), while `!(X == Y)` and a bare
    # `X != Y` are negative ("≠ Y").
    outer_neg = bool(_NEG_RE.match(_n(raw)))
    net_neg = outer_neg ^ (first_op == "!=")
    return ("≠ " + s) if net_neg else s


def _tail(path: str) -> str:
    return re.split(r"\.|->", path)[-1].split("[")[0]


def _light_clean(pred: str) -> str:
    """Last-resort: make a raw predicate marginally more readable without
    inventing meaning (used only when nothing authored matches)."""
    s = pred
    s = s.replace("&&", " and ").replace("||", " or ")
    s = re.sub(r"[A-Za-z_][\w.]*\.([A-Za-z_]\w*)", r"\1", s)  # keep tail of paths
    s = s.replace("==", " equals ").replace("!=", " is not ")
    s = re.sub(r"\s+", " ", s).strip()
    return s


# --------------------------------------------------------------------------- #
# Value + variable accessors
# --------------------------------------------------------------------------- #
def humanize_value(value: str) -> str:
    if not value:
        return ""
    v = value.strip()
    if v in VALUE_LABELS:
        return VALUE_LABELS[v]
    # split CamelCase member of an Enum::Member into spaced words as a fallback
    member = v.split("::")[-1]
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", member)
    spaced = re.sub(r"(?<=[A-Z])(?=[A-Z][a-z])", " ", spaced)
    return spaced


_VAR_CODE_RE = re.compile(r"@?[A-Za-z_]\w*(?:(?:->|\.)[A-Za-z_]\w*)*")


def variable_codes_in(raw: str) -> List[str]:
    """Pull the dependent-variable CODES (tail names) a predicate references,
    restricted to ones we have business info for (keeps the dep-var list clean)."""
    if not raw:
        return []
    out = []
    seen = set()
    # ASM-style @SYMBOLS and bare upper symbols
    for tok in re.findall(r"@?[A-Z][A-Z0-9_]{2,}", raw):
        if tok in VAR_INFO and tok not in seen:
            seen.add(tok); out.append(tok)
    # C++ member paths → tail
    for m in _VAR_CODE_RE.finditer(raw):
        tail = _tail(m.group(0))
        if tail in VAR_INFO and tail not in seen:
            seen.add(tail); out.append(tail)
    return out


def var_business_name(code: str) -> str:
    return VAR_INFO.get(code, (None,))[0] or ""


def var_what_it_is(code: str) -> str:
    info = VAR_INFO.get(code)
    return info[1] if info and len(info) > 1 else ""


def box_business_name(stem: str, func: str = None) -> str:
    return BOX_NAMES.get(stem) or (func or stem)
