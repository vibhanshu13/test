"""Shared contract for vbt.uiexport — the EXACT per-variable JSON shape the
Zenflow Setter-Analysis table view consumes, plus the field-ownership rules that
divide work between the deterministic `structural` layer and the Gemini `prose`
layer.

This shape mirrors `Zenflow_Frontend/src/api/mocks/setterAnalysisTableFixtures.js`
(the `ROOT` / `LS4CSCRES` / `inputVar()` objects) 1:1. The view reads it in
`Zenflow_Frontend/src/Pages/Projects/SetterAnalysisTableView.jsx`:
  - every prose field is a plain string OR a {b, t} pair; `tx(v, mode)` returns
    `v.t` only when mode === "technical", else `v.b` (so BOTH sides must be filled).
  - a condition row's `dependent_variables[].id` and a setter's
    `dependent_variables[].variable` are passed to `onPickVariable(...)`, which
    re-fetches `/table` with that value as the new rootId. Therefore EVERY such
    id/variable MUST be the raw variable name that keys another generated JSON
    file (== `dependentVariables/<name>.json` stem). No business labels as ids.
  - a variable is rendered as a terminal "input variable" when `setters == []`;
    that card reads `data.origin` (a {b,t}), NOT `description`.
  - an OR-group condition is `{ n, type:"any", note:{b,t}, any:[<leaf cond>...] }`;
    leaf conditions inside `any[]` carry NO `n`. A normal condition is a leaf with `n`.

────────────────────────────────────────────────────────────────────────────
FIELD OWNERSHIP (who fills what)
────────────────────────────────────────────────────────────────────────────
STRUCTURAL (deterministic, from the trace — NEVER invents):
  variable, location, file, kind, function, sets, n, id, dependent_variables[].id,
  source_code, call_site.{location,code}, setter_source.{location,code},
  rule.t           (the raw condition text, e.g. "(@CASVIS1 & X'01') == X'01'"),
  assigned_value.t (the raw enum/literal, e.g. "SoftCardValueDetail::ExpressPayTransaction").
  → All other {b,t} sides and business_name fields are left EMPTY placeholders:
      a {b,t} object is emitted as {"b": "", "t": ""} (or with .t prefilled, .b "").
      a business_name is emitted as "".

PROSE (Gemini — fills ONLY empty slots, never restructures):
  business_name (variable / file / dep var), description.{b,t}, name.{b,t},
  note.{b,t}, what_it_is.{b,t}, role.{b,t}, inquiry_path.description/long_description.{b,t},
  call_site.note.{b,t}, rule.b, assigned_value.b.
  Business prose renders names as "Business Name (CODE)"; technical prose may use
  files/routines/enums/raw conditions. The `.t` side, where structural prefilled
  it from a real fact, is kept as ground truth (prose may not contradict it).

The prose layer is a GENERIC slot-walker: it descends the dict, finds every {b,t}
with an empty side and every "" business_name, gathers them with their local
context, asks Gemini to fill them (batched per variable / per setter subtree),
and writes back ONLY the empty sides. It does not need these Pydantic classes at
runtime; they exist to VALIDATE the final emitted JSON (the --no-llm contract
test and the post-prose check both validate against `VariableTable` /
`TerminalInputTable`).
"""
from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict

# Empty-placeholder sentinels the structural layer emits.
EMPTY_BT = {"b": "", "t": ""}


def is_empty_bt_side(value: str | None) -> bool:
    """A {b,t} side counts as an unfilled slot when it is None or blank."""
    return value is None or value == ""


class BT(BaseModel):
    """A business/technical prose pair. Either side may be a placeholder ("")."""
    model_config = ConfigDict(extra="forbid")
    b: str = ""
    t: str = ""


class DepRef(BaseModel):
    """A condition-cell dependent-variable reference: {name (label), id (raw var)}."""
    model_config = ConfigDict(extra="forbid")
    name: str
    id: str


class Condition(BaseModel):
    """A single condition row.

    Two shapes share one permissive model (the view branches on
    `c.type === "any" || Array.isArray(c.any)`):
      • leaf  : { n?, rule, location, dependent_variables, source_code, description }
      • OR-grp: { n, type:"any", note, any:[<leaf without n> ...] }
    """
    model_config = ConfigDict(extra="ignore")
    n: Optional[Union[int, str]] = None
    rule: Optional[BT] = None
    location: Optional[str] = None
    dependent_variables: List[DepRef] = []
    source_code: Optional[str] = None
    description: Optional[BT] = None
    # OR-group only:
    type: Optional[Literal["any"]] = None
    note: Optional[BT] = None
    any: Optional[List["Condition"]] = None


class CallSite(BaseModel):
    """Source for the caller→callee hand-off into the next file in a path."""
    model_config = ConfigDict(extra="ignore")
    location: str
    code: str
    note: Optional[BT] = None


class SetterSource(BaseModel):
    """Source for the actual assignment statement (last file in a path)."""
    model_config = ConfigDict(extra="ignore")
    location: str
    code: str


class SourceSpanLine(BaseModel):
    """One line of the source view (or a gap marker between non-adjacent blocks)."""
    model_config = ConfigDict(extra="ignore")
    n: Optional[int] = None  # source line number (None for a gap marker)
    code: str = ""           # verbatim source (asm change-ref tag stripped, indent kept)
    hl: bool = False         # highlight: a condition line or the call/setter line
    gap: bool = False        # True = separator between non-adjacent blocks


class SourceSpan(BaseModel):
    """Relevant window for a file step: first-condition → call/setter line, every
    line in between, with condition + call/setter lines flagged `hl`."""
    model_config = ConfigDict(extra="ignore")
    file: str
    start: int
    end: int
    lines: List[SourceSpanLine]


class FileStep(BaseModel):
    """One file inside a path (or the inquiry-path flow).

    `kind="cpp"` is identified by (function, file); `kind="asm"` by file only.
    The LAST file in a path has `sets=True` + `assigned_value` + `setter_source`;
    every upstream file has `call_site` (the hop into the next file). Within ANY
    one file ALL `conditions` must hold.
    """
    model_config = ConfigDict(extra="ignore")
    file: str
    kind: Literal["asm", "cpp"]
    function: Optional[str] = None
    business_name: str = ""
    # Optional per-file purpose blurb (filled for inquiry-path files so the UI can
    # show what each file in the flow does, e.g. aa71 / dw730000 / dw710000).
    description: Optional[BT] = None
    sets: Optional[bool] = None
    assigned_value: Optional[BT] = None
    conditions: List[Condition] = []
    call_site: Optional[CallSite] = None
    setter_source: Optional[SetterSource] = None
    # Relevant-window source (first condition → call/setter line, lines highlighted).
    source_span: Optional[SourceSpan] = None
    # When the SAME value is assigned at multiple sites in this file+function (paths
    # identical until the assignment), the setter step carries `sites` instead of a
    # single setter_source/conditions: the value is set if ANY site's conditions hold.
    sites: Optional[List["SetterSite"]] = None


class SetterSite(BaseModel):
    """One assignment site of a clubbed value: its line, the source statement, the
    guard-conjunction for THIS site, and its source-span. Sites are OR-ed."""
    model_config = ConfigDict(extra="ignore")
    location: Optional[str] = None
    code: str = ""
    conditions: List[Condition] = []
    source_span: Optional[SourceSpan] = None


class Path(BaseModel):
    """One route to a setter: an ordered list of files; the last file sets the value."""
    model_config = ConfigDict(extra="ignore")
    id: str
    name: BT
    description: Optional[BT] = None
    files: List[FileStep]


class DepVar(BaseModel):
    """A dependent variable surfaced on a setter (clickable → drills into its table).

    `variable` MUST be the raw name that keys another generated JSON file.
    """
    model_config = ConfigDict(extra="ignore")
    variable: str
    business_name: str = ""
    what_it_is: BT
    role: BT
    # How the dep var is used in this setter: "value_logic" (referenced in the
    # setter-site conditions that select the value) or "reachability" (referenced
    # only upstream — gates the route from the root program to the setter site).
    dependency_type: str = ""
    # True when this dep var is itself SET somewhere (its own table has setters),
    # vs a terminal input. Drives ordering: setter-having vars sort first.
    has_setters: bool = False


class InquiryPath(BaseModel):
    """The variable's canonical file flow, shown once at the top of the view."""
    model_config = ConfigDict(extra="ignore")
    name: str = "Inquiry Path"
    description: BT
    long_description: BT
    files: List[FileStep]


class TerminalOrigin(BaseModel):
    """Provenance for a TERMINAL entity (read here, never set): the exact site the
    trace recorded the read at, plus the verbatim source chunk there. Surfaced from
    the terminal node's own `foundAt` + `relevantCodeChunk` so terminal-input
    provenance is visible (previously dropped). All fields structural facts."""
    model_config = ConfigDict(extra="ignore")
    # The qualified path of the terminal entity (e.g. "allCidRecordWorkArea.numberOfCidRecords").
    qualified: str = ""
    location: str = ""  # "dw780000.cpp:218"
    code: str = ""      # verbatim relevantCodeChunk at that site


class VariableTable(BaseModel):
    """Top-level payload for a variable that IS set somewhere (has setters).

    Served at GET /v1/knowledge-bases/{kb}/setter-analysis/setters/{variable}/table
    and stored as generated/<variable>.json keyed by `variable` in
    GENERATED_SETTER_TABLES.
    """
    model_config = ConfigDict(extra="ignore")
    variable: str
    business_name: str = ""
    description: BT
    inquiry_path: InquiryPath
    setters: List[Setter]
    # Optional variable-level union of dep vars (the view also derives this from
    # setters); the LWRPO ROOT fixture omits it, so default empty.
    dependent_variables: List[DepVar] = []
    # When this short name ALSO aliases a terminal entity (a same-tail read with no
    # setters) in addition to the setter-having ones, its read-site provenance is
    # carried here so it is not lost behind the setter cards. Empty list otherwise.
    terminal_origins: List[TerminalOrigin] = []
    # Cross-language identity facts (structural; UI shows them ONLY when present).
    #   member_of:   the struct (C++) / DSECT-mac (ASM) this variable belongs to —
    #                {language, kind, name}.
    #   counterpart: its high-certainty cross-language twin — {name, language,
    #                memberOf:{...}}. Both absent/None when nothing resolves.
    member_of: Optional[Dict[str, Any]] = None
    counterpart: Optional[Dict[str, Any]] = None


class Setter(BaseModel):
    """One clubbed logical setter: (file, function, value), reachable via paths[]."""
    model_config = ConfigDict(extra="ignore")
    id: str
    index: int
    description: BT
    assigned_value: BT
    # The resolved literal the code stores (e.g. "'Z'"), from the const-resolver.
    # Empty when unresolved. Shown appended to the SETS TO chip in both modes.
    resolved_value: str = ""
    location: str
    paths: List[Path]
    dependent_variables: List[DepVar] = []
    # The fully-qualified trace path of the entity this setter belongs to, when the
    # variable's short tail name aliases SEVERAL distinct trace entities (e.g.
    # `allCidRecords.numberOfCidRecords` vs a plain local `numberOfCidRecords`). The
    # UI keys/clicks by the short name, so this disambiguates which entity each setter
    # actually mutates. Empty when the name maps to a single entity (no ambiguity).
    qualified: str = ""


class TerminalInputTable(BaseModel):
    """Top-level payload for a terminal INPUT variable (read here, never set).

    Matches the fixture `inputVar()` helper. The view shows the "Input variable"
    card and reads `origin` (NOT description).
    """
    model_config = ConfigDict(extra="ignore")
    variable: str
    business_name: str
    terminal: Literal[True] = True
    description: BT
    origin: BT
    setters: List = []
    # The read-site(s) the trace recorded for this terminal input (foundAt +
    # verbatim code chunk). Carried so terminal-input provenance is visible; the
    # prose layer still fills `origin.b`. Empty when the trace gave no foundAt.
    terminal_origins: List[TerminalOrigin] = []
    # Cross-language identity facts (structural; UI shows them ONLY when present).
    member_of: Optional[Dict[str, Any]] = None
    counterpart: Optional[Dict[str, Any]] = None


# Resolve forward references (VariableTable references Setter defined below it).
VariableTable.model_rebuild()
Condition.model_rebuild()
