"""Gemini PROSE layer for vbt.uiexport.

The deterministic `structural` layer produces a final-shape dict that matches
``vbt.uiexport.models`` but leaves every prose field as an EMPTY placeholder:
each ``{b,t}`` pair has an empty side (``.b`` always, ``.t`` only when the
structural layer had no raw fact for it), and every ``business_name`` is ``""``.

This module fills ONLY those empty slots, via Gemini, and writes back without
ever clobbering a fact:

  • FIELD OWNERSHIP (models.py):
      STRUCTURAL owns:  variable, location, file, kind, function, sets, n, id,
                        dependent_variables[].id/variable, source_code,
                        call_site.{location,code}, setter_source.{location,code},
                        rule.t, assigned_value.t.
      PROSE fills:      business_name (variable/file/depvar), description.{b,t},
                        name.{b,t}, note.{b,t}, what_it_is.{b,t}, role.{b,t},
                        inquiry_path.description/long_description.{b,t},
                        call_site.note.{b,t}, rule.b, assigned_value.b, origin.{b,t}.

  • NON-EMPTY .t SIDES ARE GROUND TRUTH. Prose may read them as context and must
    NOT contradict them, and we NEVER overwrite a non-empty side on write-back
    (see ``_apply_bt`` — it only writes a side that ``is_empty_bt_side``).

Design (generic, decoupled from the nested pydantic model):
  ``collect_slots(struct)`` walks the dict and yields one ``Slot`` per fillable
  target, capturing a stable JSON path key and the LOCAL context (nearest file /
  function, the raw fact text, what the field IS). ``fill_prose(struct, ...)``
  either (a) fills deterministically with ``no_llm=True`` so the UI renders with
  ZERO Gemini calls, or (b) batches the slots — one call for the variable-level
  slots and one call PER SETTER subtree — asks Gemini (via
  ``process_analysis.backend.llm.call_llm_model`` with a Pydantic response model)
  for a ``{path_key: {...}}`` map, and writes back only the empty sides. The
  final dict is validated against ``models.VariableTable`` / ``TerminalInputTable``.

A ``ProseCache`` (cache.py) keyed on a stable hash of the PRE-FILL struct makes
re-fills free.
"""
from __future__ import annotations

import json
import logging
import re
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict

from vbt.uiexport import models
from vbt.uiexport.cache import ProseCache

# REUSE VERBATIM the lineage-explainer register + carve-out rules.
from llm.lineage_explainer import (
    _BUSINESS_ONLY_RULE,
    _BUSINESS_SYSTEM_PROMPT,
    _COMPLETENESS_RULE,
    _DESIGN_RULE,
    _PURE_BUSINESS_SYSTEM_PROMPT,
)

logger = logging.getLogger(__name__)


# ===========================================================================
# Cross-variable dedup cache
# ===========================================================================

class CrossVarCache:
    """Thread-safe in-memory cache for cross-variable prose dedup.

    Keyed on (kind, field, t_fact, context_sans_variable) so identical
    conditions across different variables reuse the same LLM result.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._store: Dict[tuple, Any] = {}

    def get(self, key: tuple) -> Optional[Any]:
        with self._lock:
            return self._store.get(key)

    def put(self, key: tuple, value: Any) -> None:
        with self._lock:
            self._store[key] = value

    def __len__(self) -> int:
        with self._lock:
            return len(self._store)


# ===========================================================================
# Slot model
# ===========================================================================

@dataclass
class Slot:
    """One fillable target in the structural dict.

    kind:
      "bt"   — a {b,t} object that has at least one empty side. The model is
               asked for {"b": ..., "t": ...}; only empty sides are written.
      "name" — a business_name == "". The model is asked for a plain string.

    path: a stable dotted/bracketed JSON path key, e.g.
          "setters[0].paths[1].files[2].conditions[0].rule".
    field: WHAT this field is (e.g. "condition rule", "path name",
           "dep var what_it_is", "inquiry_path long_description").
    t_fact: for bt slots, the existing .t side (a ground-truth fact, may be "").
            For name slots, the raw name being humanised.
    context: local context dict (file / function / raw code / location / value).
    batch: which call this slot belongs to — "variable" or "setter:<i>".
    """
    kind: str
    path: str
    field: str
    t_fact: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    batch: str = "variable"


# ===========================================================================
# Slot walker
# ===========================================================================

def _join(base: str, key: str) -> str:
    """Join a base JSON path with a field key (no leading dot at the root)."""
    return f"{base}.{key}" if base else key


def _is_bt(obj: Any) -> bool:
    """True when *obj* looks like a {b,t} prose pair."""
    return isinstance(obj, dict) and set(obj.keys()) <= {"b", "t"} and ("b" in obj or "t" in obj)


def _bt_has_empty_side(obj: dict) -> bool:
    return models.is_empty_bt_side(obj.get("b")) or models.is_empty_bt_side(obj.get("t"))


def _ctx(
    *,
    variable: str = "",
    file: str = "",
    function: str = "",
    raw: str = "",
    location: str = "",
    value_t: str = "",
    member: str = "",
) -> Dict[str, Any]:
    """Build a compact, non-empty-only local context dict for a slot."""
    out: Dict[str, Any] = {}
    if variable:
        out["variable"] = variable
    if file:
        out["file"] = file
    if function:
        out["function"] = function
    if raw:
        out["raw"] = raw
    if location:
        out["location"] = location
    if value_t:
        out["value_t"] = value_t
    if member:
        out["member"] = member
    return out


def _add_bt_slot(
    slots: List[Slot],
    parent: dict,
    key: str,
    path: str,
    field_desc: str,
    batch: str,
    base_ctx: Dict[str, Any],
) -> None:
    """If parent[key] is a {b,t} with an empty side, append a bt Slot."""
    obj = parent.get(key)
    if _is_bt(obj) and _bt_has_empty_side(obj):
        slots.append(
            Slot(
                kind="bt",
                path=_join(path, key),
                field=field_desc,
                t_fact=obj.get("t") or "",
                context=base_ctx,
                batch=batch,
            )
        )


def _add_name_slot(
    slots: List[Slot],
    parent: dict,
    path: str,
    field_desc: str,
    batch: str,
    base_ctx: Dict[str, Any],
) -> None:
    """If parent['business_name'] == '', append a name Slot (raw name = t_fact).

    Prefer `file` over `variable`: a FILE business_name must be labelled by its
    own file identity, not the root variable. The variable/dep-var name slots
    carry no `file` in their context, so they still resolve to the variable name.
    """
    if parent.get("business_name", None) == "":
        _f = base_ctx.get("file")
        _fn = base_ctx.get("function")
        if _f and _fn:
            # C++ file step: a distinct label PER FUNCTION (several functions can
            # live in one file — they must not collapse to one shared name).
            raw_name = f"{_f}::{_fn}"
        else:
            raw_name = _f or base_ctx.get("variable") or ""
        slots.append(
            Slot(
                kind="name",
                path=_join(path, "business_name"),
                field=field_desc,
                t_fact=raw_name,
                context=base_ctx,
                batch=batch,
            )
        )


def _walk_file_step(
    slots: List[Slot],
    fstep: dict,
    path: str,
    batch: str,
    variable: str,
) -> None:
    """Collect slots inside one FileStep (used by both inquiry_path and paths)."""
    file = fstep.get("file", "") or ""
    function = fstep.get("function", "") or ""
    # Summarise this file's own checks so the LLM can write an ACCURATE per-file
    # label + description (not the generic variable name).
    _cond_texts = []
    _all_conds = list(fstep.get("conditions", []) or [])
    for _site in fstep.get("sites", []) or []:   # merged multi-site setter step
        _all_conds += list(_site.get("conditions", []) or [])
    for _c in _all_conds:
        if _c.get("any"):
            _cond_texts += [(a.get("rule") or {}).get("t", "") for a in _c["any"]]
        else:
            _cond_texts.append((_c.get("rule") or {}).get("t", ""))
    _cond_summary = "; ".join(t for t in _cond_texts if t)[:600]
    base_ctx = _ctx(variable=variable, file=file, function=function, raw=_cond_summary)

    # file-level business_name (short label for what THIS file does in the flow)
    _add_name_slot(slots, fstep, path, "file step business_name (short label for what this file/routine does)", batch, base_ctx)

    # per-file purpose blurb (present on inquiry-path files): what this file does
    if _is_bt(fstep.get("description")):
        _add_bt_slot(slots, fstep, "description", path,
                     "file purpose (what this file/routine does in the inquiry flow)", batch, base_ctx)

    # assigned_value (last file in a path that sets the value)
    av = fstep.get("assigned_value")
    if _is_bt(av):
        ss = fstep.get("setter_source") or {}
        _sites = fstep.get("sites") or []
        if _sites:  # multi-site: summarise the assignment statements + lines
            _raw = "; ".join((s.get("code") or "") for s in _sites)[:400]
            _loc = ", ".join((s.get("location") or "") for s in _sites)
        else:
            _raw, _loc = (ss.get("code") or ""), (ss.get("location") or "")
        av_ctx = _ctx(variable=variable, file=file, function=function, raw=_raw, location=_loc)
        _add_bt_slot(slots, fstep, "assigned_value", path, "assigned value", batch, av_ctx)

    # call_site.note (hop into the next file)
    cs = fstep.get("call_site")
    if isinstance(cs, dict):
        cs_path = f"{path}.call_site"
        cs_ctx = _ctx(
            variable=variable,
            file=file,
            function=function,
            raw=(cs.get("code") or ""),
            location=(cs.get("location") or ""),
        )
        _add_bt_slot(slots, cs, "note", cs_path, "call-site note (caller→callee hand-off)", batch, cs_ctx)

    # conditions
    for ci, cond in enumerate(fstep.get("conditions", []) or []):
        _walk_condition(slots, cond, f"{path}.conditions[{ci}]", batch, variable, file, function)

    # sites (merged multi-site setter step): each site's own guard-conjunction
    for si, site in enumerate(fstep.get("sites", []) or []):
        for ci, cond in enumerate(site.get("conditions", []) or []):
            _walk_condition(
                slots, cond, f"{path}.sites[{si}].conditions[{ci}]",
                batch, variable, file, function,
            )


def _walk_condition(
    slots: List[Slot],
    cond: dict,
    path: str,
    batch: str,
    variable: str,
    file: str,
    function: str,
) -> None:
    """Collect slots inside one Condition (leaf or OR-group)."""
    raw_rule = ""
    rule = cond.get("rule")
    if _is_bt(rule):
        raw_rule = rule.get("t") or ""
    base_ctx = _ctx(
        variable=variable,
        file=file,
        function=function,
        raw=(cond.get("source_code") or raw_rule),
        location=(cond.get("location") or ""),
    )

    # leaf rule (.t is the raw condition fact; only .b is fillable normally)
    _add_bt_slot(slots, cond, "rule", path, "condition rule", batch, base_ctx)
    # leaf / OR-group description + note
    _add_bt_slot(slots, cond, "description", path, "condition description", batch, base_ctx)
    _add_bt_slot(slots, cond, "note", path, "OR-group note (what the group of alternatives means)", batch, base_ctx)

    # OR-group: recurse into any[] (leaf conditions without n)
    for ai, leaf in enumerate(cond.get("any", []) or []):
        _walk_condition(slots, leaf, f"{path}.any[{ai}]", batch, variable, file, function)


def _collect_condition_rules(node: Any, acc: List[dict]) -> None:
    """Recursively gather every leaf Condition dict reachable under *node*.

    Walks file-steps' conditions / sites[].conditions / OR-group any[], plus the
    inquiry_path and every setter path. Each accumulated entry is the raw condition
    dict (it carries `rule.t`, `source_code`, `dependent_variables[].id`).
    """
    if isinstance(node, dict):
        # A Condition is identified by the presence of a `rule` or `any`/`dependent_variables`.
        if _is_bt(node.get("rule")) or "any" in node or "dependent_variables" in node:
            if _is_bt(node.get("rule")) or node.get("source_code"):
                acc.append(node)
        for v in node.values():
            _collect_condition_rules(v, acc)
    elif isinstance(node, list):
        for v in node:
            _collect_condition_rules(v, acc)


def _dep_var_facts(scope: Any, dep_name: str) -> str:
    """Verbatim FACTS that ground a dependent variable's business naming.

    Scans *scope* (the setter subtree, or the whole struct for variable-level dep
    vars) for the conditions that actually reference this dep var — matched either
    by a condition's ``dependent_variables[].id`` OR by the raw token appearing in
    the condition's verbatim rule/source text — and returns the distinct condition
    texts (with the assigned values they gate, when present). This is what forces
    the model to derive the name from the REAL tests on the variable instead of
    free-associating a product concept from an opaque token like ``@CASVIS1``.
    """
    if not dep_name:
        return ""
    bare = dep_name.lstrip("@&#$").strip()
    # A word-boundary-ish match on either the full token or its bare form, so an
    # ASM-sigil name (@CASVIS1) still matches `CASVIS1` inside the rule text.
    pat = re.compile(
        r"(?<![A-Za-z0-9_])(?:" + re.escape(dep_name) + r"|" + re.escape(bare) + r")(?![A-Za-z0-9_])"
    )

    conds: List[dict] = []
    _collect_condition_rules(scope, conds)

    facts: List[str] = []
    seen: set = set()
    for c in conds:
        ids = {(d.get("id") or "") for d in (c.get("dependent_variables") or [])}
        ids |= {(d.get("id") or "").lstrip("@&#$") for d in (c.get("dependent_variables") or [])}
        rule_t = ((c.get("rule") or {}).get("t") if _is_bt(c.get("rule")) else "") or ""
        src = c.get("source_code") or ""
        referenced = (
            dep_name in ids or bare in ids
            or bool(pat.search(rule_t)) or bool(pat.search(src))
        )
        if not referenced:
            continue
        fact = rule_t or src
        fact = fact.strip()
        if fact and fact not in seen:
            seen.add(fact)
            facts.append(fact)
    return "; ".join(facts[:12])[:600]


def _walk_dep_var(slots: List[Slot], dv: dict, path: str, batch: str,
                  scope: Any = None) -> None:
    """Collect slots inside one DepVar.

    *scope* is the surrounding subtree (the setter dict for setter-level dep vars,
    the whole struct for variable-level ones). It is mined for the verbatim
    condition texts that actually reference this dep var, so the naming slot is
    GROUNDED in real facts (preventing a fabricated business name from an opaque
    token).
    """
    raw = dv.get("variable", "") or ""
    facts = _dep_var_facts(scope, raw) if scope is not None else ""
    # `raw` ensures the model sees the real identifier; `raw=facts` carries the
    # actual condition texts the variable participates in.
    base_ctx = _ctx(variable=raw, raw=facts)
    _add_name_slot(slots, dv, path, "dependent-variable business_name", batch, base_ctx)
    _add_bt_slot(slots, dv, "what_it_is", path, "dep var what_it_is", batch, base_ctx)
    _add_bt_slot(slots, dv, "role", path, "dep var role (how it influences the setter)", batch, base_ctx)


def collect_slots(struct: dict) -> List[Slot]:
    """Walk the final-shape struct; produce a Slot for each fillable target.

    Returns slots in a stable order (variable-level first, then per setter), each
    tagged with its ``batch`` so the LLM path can group them into bounded calls.
    """
    slots: List[Slot] = []
    variable = struct.get("variable", "") or ""

    # ---- Terminal INPUT variable shape -----------------------------------
    if struct.get("terminal") is True:
        _add_name_slot(slots, struct, "", "variable business_name", "variable", _ctx(variable=variable))
        _add_bt_slot(slots, struct, "description", "", "variable description", "variable", _ctx(variable=variable))
        _add_bt_slot(slots, struct, "origin", "", "terminal input origin (where its value comes from)",
                     "variable", _ctx(variable=variable))
        return slots

    # ---- Variable that IS set (VariableTable) ----------------------------
    var_ctx = _ctx(variable=variable)
    _add_name_slot(slots, struct, "", "variable business_name", "variable", var_ctx)
    # Ground the description in the ACTUAL set of values this variable takes (so the
    # LLM doesn't guess the variable's purpose). List the distinct assigned values +
    # resolved literals and the functions that set it.
    _vals, _seen = [], set()
    for _s in struct.get("setters", []) or []:
        _av = _s.get("assigned_value") or {}
        _t = _av.get("t") if _is_bt(_av) else ""
        _rv = _s.get("resolved_value") or ""
        if _t and _t not in _seen:
            _seen.add(_t)
            _vals.append(f"{_t}{(' (' + _rv + ')') if _rv else ''}")
    _setfns = []
    for _s in struct.get("setters", []) or []:
        for _p in _s.get("paths", []) or []:
            for _f in _p.get("files", []) or []:
                if _f.get("sets"):
                    _fn = _f.get("function") or _f.get("file")
                    if _fn and _fn not in _setfns:
                        _setfns.append(_fn)
    _desc_raw = (
        ("Set to one of these distinct values (enum (resolved-literal)): "
         + "; ".join(_vals[:40]) + ". " if _vals else "")
        + ("Assigned in: " + ", ".join(_setfns[:12]) + "." if _setfns else "")
    )[:900]
    _add_bt_slot(
        slots, struct, "description", "",
        "variable description — a CONCISE 1-2 sentence summary of what this variable "
        "IS and the KIND of outcomes it classifies (e.g. how the card was entered and "
        "how its security codes/expiry matched). Do NOT enumerate every value or use "
        "bullet lists — the individual values are shown separately. Be precise and "
        "grounded in the listed values; do not invent a purpose it doesn't have",
        "variable", _ctx(variable=variable, raw=_desc_raw),
    )

    # inquiry_path
    ip = struct.get("inquiry_path")
    if isinstance(ip, dict):
        _add_bt_slot(slots, ip, "description", "inquiry_path", "inquiry_path short description",
                     "variable", var_ctx)
        _add_bt_slot(slots, ip, "long_description", "inquiry_path", "inquiry_path long description",
                     "variable", var_ctx)
        for fi, fstep in enumerate(ip.get("files", []) or []):
            _walk_file_step(slots, fstep, f"inquiry_path.files[{fi}]", "variable", variable)

    # variable-level dependent_variables (optional union). Mine the WHOLE struct
    # for the conditions that reference each dep var (they live under the setters).
    for di, dv in enumerate(struct.get("dependent_variables", []) or []):
        _walk_dep_var(slots, dv, f"dependent_variables[{di}]", "variable", scope=struct)

    # setters — one batch per setter subtree
    for si, setter in enumerate(struct.get("setters", []) or []):
        batch = f"setter:{si}"
        spath = f"setters[{si}]"
        s_loc = setter.get("location", "") or ""
        s_av = setter.get("assigned_value") or {}
        s_av_t = s_av.get("t") if _is_bt(s_av) else ""
        s_ctx = _ctx(variable=variable, location=s_loc, value_t=(s_av_t or ""))

        _add_bt_slot(slots, setter, "description", spath, "setter description", batch, s_ctx)
        _add_bt_slot(slots, setter, "assigned_value", spath, "setter assigned value", batch, s_ctx)

        for pi, p in enumerate(setter.get("paths", []) or []):
            ppath = f"{spath}.paths[{pi}]"
            # Per-PATH context so multiple paths of one setter get DISTINCT names:
            # include the route's function chain + the final setter-site guard/line
            # (paths to the same value often differ only at the last guard, e.g.
            # set @1002 when lstknpoa=='Y' vs @1033 when expressPay==On).
            pfiles = p.get("files", []) or []
            _chain = " -> ".join(
                (f.get("file", "") + ("::" + f["function"] if f.get("function") else ""))
                for f in pfiles
            )
            _last = pfiles[-1] if pfiles else {}
            _guards = []
            for _c in _last.get("conditions", []) or []:
                if _c.get("any"):
                    _guards += [(a.get("rule") or {}).get("t", "") for a in _c["any"]]
                else:
                    _guards.append((_c.get("rule") or {}).get("t", ""))
            _site = (_last.get("setter_source") or {}).get("location", "") or s_loc
            # The setter lives in the LAST step's function (e.g. processACreditTransaction),
            # NOT the entry function (callPlasticAuthenticationComponentInterface). Name it
            # explicitly so prose attributes the assignment to the right function.
            _setter_fn = _last.get("function", "") or ""
            p_ctx = _ctx(
                variable=variable, location=_site, value_t=(s_av_t or ""),
                function=_setter_fn,
                raw=("route " + _chain
                     + " | the value is SET in function "
                     + (_setter_fn or "(unknown)") + " at " + _site
                     + (" when " + "; ".join(g for g in _guards if g) if any(_guards) else ""))[:500],
            )
            _add_bt_slot(slots, p, "name", ppath,
                         "path name (short label distinguishing THIS route + setter-site from the setter's other paths)",
                         batch, p_ctx)
            _add_bt_slot(slots, p, "description", ppath, "path description", batch, p_ctx)
            for fi, fstep in enumerate(p.get("files", []) or []):
                _walk_file_step(slots, fstep, f"{ppath}.files[{fi}]", batch, variable)

        for di, dv in enumerate(setter.get("dependent_variables", []) or []):
            # Scope = THIS setter subtree: the dep var's grounding facts are the
            # conditions on this setter's paths/sites that reference it.
            _walk_dep_var(slots, dv, f"{spath}.dependent_variables[{di}]", batch, scope=setter)

    return slots


# ===========================================================================
# JSON-path write-back (mirror of collect_slots' path keys)
# ===========================================================================

_TOKEN_RE = re.compile(r"([A-Za-z_]\w*)(\[(\d+)\])?")


def _resolve_parent(struct: dict, path: str) -> tuple[Any, str]:
    """Resolve a dotted/bracketed path to (container, final_key).

    Path grammar: ``name`` | ``name[idx]`` segments joined by '.'.
    The final segment names the field to set on the returned container.
    """
    segments = path.split(".")
    cur: Any = struct
    # All but the last segment descend.
    for seg in segments[:-1]:
        m = _TOKEN_RE.fullmatch(seg)
        if not m:
            raise KeyError(f"bad path segment {seg!r} in {path!r}")
        name, _, idx = m.groups()
        cur = cur[name]
        if idx is not None:
            cur = cur[int(idx)]
    # Final segment: may itself carry an index (rare; not used by our keys) but
    # in practice the final key is a plain field name.
    last = segments[-1]
    m = _TOKEN_RE.fullmatch(last)
    if not m:
        raise KeyError(f"bad final segment {last!r} in {path!r}")
    name, _, idx = m.groups()
    if idx is not None:
        cur = cur[name]
        return cur, int(idx)  # type: ignore[return-value]
    return cur, name


def _apply_bt(struct: dict, path: str, b: Optional[str], t: Optional[str]) -> None:
    """Write back a {b,t} fill, NEVER overwriting a non-empty side."""
    parent, key = _resolve_parent(struct, path)
    obj = parent[key]
    if not _is_bt(obj):
        return
    if models.is_empty_bt_side(obj.get("b")) and b:
        obj["b"] = b
    if models.is_empty_bt_side(obj.get("t")) and t:
        obj["t"] = t


def _apply_name(struct: dict, path: str, name: Optional[str]) -> None:
    """Write back a business_name fill, only if currently empty."""
    if not name:
        return
    parent, key = _resolve_parent(struct, path)
    if parent.get(key, None) == "":
        parent[key] = name


# ===========================================================================
# Deterministic (no-LLM) fill
# ===========================================================================

_ACRONYM_RE = re.compile(r"[_\s]+")
_CAMEL_RE = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")


def humanize(raw: str) -> str:
    """Turn a raw variable/file name into a readable business-ish label.

    Deterministic, no LLM. Handles snake_case, camelCase, dotted file stems,
    and namespaced C++ enums. Used by the --no-llm contract path and as the
    fallback for any slot Gemini leaves blank.
    """
    if not raw:
        return ""
    s = raw.strip()
    # Drop a leading namespace / enum qualifier (Foo::Bar -> Bar).
    if "::" in s:
        s = s.split("::")[-1]
    # File stem: drop extension (foo.asm -> foo).
    if "." in s and not s.replace(".", "").isdigit():
        s = s.rsplit(".", 1)[0]
    s = _CAMEL_RE.sub(" ", s)
    s = _ACRONYM_RE.sub(" ", s)
    s = s.strip()
    if not s:
        return raw
    # Title-case words, but preserve fully-upper tokens (codes like LG1OSI, C400).
    words = []
    for w in s.split(" "):
        if w.isupper() and len(w) > 1:
            words.append(w)
        else:
            words.append(w[:1].upper() + w[1:])
    return " ".join(words)


def _humanize_fact_for_b(fact: str, slot: Slot) -> str:
    """Produce a business-side (.b) label from a technical fact and slot context.

    Uses the slot's ``field`` descriptor and ``context`` (variable, file,
    function) to produce something meaningfully different from the raw
    technical fact that goes into ``.t``.
    """
    ctx = slot.context
    field = slot.field

    # Helpers — pull humanized names from context when available.
    var_h = humanize(ctx.get("variable", "")) or ctx.get("variable", "")
    fn_h = humanize(ctx.get("function", "")) or ctx.get("function", "")
    file_h = humanize(ctx.get("file", "")) or ctx.get("file", "")

    # Condition rules: raw code expressions like (@CASVIS1 & X'01') == X'01'
    # — humanize() won't help; build a descriptive label from context.
    if "condition rule" in field:
        if fn_h:
            return f"Condition in {fn_h}" + (f" ({file_h})" if file_h else "")
        if file_h:
            return f"Condition in {file_h}"
        return f"Condition for {var_h}" if var_h else "(condition)"

    # Condition / OR-group descriptions and notes.
    if "condition description" in field or "OR-group" in field:
        if fn_h:
            return f"Branch check in {fn_h}" + (f" ({file_h})" if file_h else "")
        if file_h:
            return f"Branch check in {file_h}"
        return f"Branch check for {var_h}" if var_h else "(branch)"

    # File-level descriptions (inquiry_path files, path files).
    if "file description" in field or "file purpose" in field or "inquiry_path" in field:
        if fn_h and file_h:
            return f"Processing in {fn_h} ({file_h})"
        if file_h:
            return f"Processing in {file_h}"
        return f"Processing step for {var_h}" if var_h else "(processing step)"

    # Call-site notes (caller→callee handoff).
    if "call-site" in field:
        if fn_h:
            return f"Handoff from {fn_h}" + (f" ({file_h})" if file_h else "")
        return f"Call-site in {file_h}" if file_h else "(call-site)"

    # Variable-level description.
    if "variable description" in field:
        h = humanize(fact)
        if h and h != fact:
            return h
        return f"{var_h} variable" if var_h else "(variable)"

    # Terminal input origin.
    if "origin" in field:
        return f"Source of {var_h}" if var_h else "(origin)"

    # Assigned values, path names/descriptions, and everything else:
    # try humanize() — it strips :: qualifiers, splits camelCase, etc.
    h = humanize(fact)
    if h and h != fact:
        return h

    # Fallback: use field description as a stub.
    return f"({field})" if field else fact


def _no_llm_fill(struct: dict, slots: List[Slot]) -> None:
    """Fill every slot deterministically so the UI renders without Gemini.

    bt slots:  produce a humanized/descriptive .b (business) side that
               differs from the raw technical .t side. NEVER overwrites
               an existing non-empty value.
    name slots: humanize the raw name.
    """
    for slot in slots:
        if slot.kind == "name":
            label = humanize(slot.t_fact) or slot.t_fact or "(unnamed)"
            _apply_name(struct, slot.path, label)
            continue

        # bt
        parent, key = _resolve_parent(struct, slot.path)
        obj = parent[key]
        if not _is_bt(obj):
            continue
        cur_b, cur_t = obj.get("b") or "", obj.get("t") or ""
        # Deterministic stub derived from the field + the strongest fact at hand.
        fact = cur_t or slot.t_fact or slot.context.get("raw") or slot.context.get("value_t") or ""
        stub = fact if fact else f"({slot.field})"
        new_b = cur_b if cur_b else _humanize_fact_for_b(fact, slot)
        new_t = cur_t if cur_t else (fact or stub)
        _apply_bt(struct, slot.path, new_b, new_t)


# ===========================================================================
# LLM fill — response models + prompt
# ===========================================================================

class _BTFill(BaseModel):
    model_config = ConfigDict(extra="ignore")
    b: str = ""
    t: str = ""


class _ProseFillResponse(BaseModel):
    """Gemini's response for one batch.

    bt: map path_key -> {b,t}
    names: map path_key -> business name string
    """
    model_config = ConfigDict(extra="ignore")
    bt: Dict[str, _BTFill] = {}
    names: Dict[str, str] = {}


# Combine the pure-business register with the technical-token carve-out so a
# single structured call can produce BOTH the business `.b` and the technical
# `.t` sides correctly. Built once at import time.
_PROSE_SYSTEM_PROMPT = (
    _PURE_BUSINESS_SYSTEM_PROMPT
    + "\n\n────────────────────────────────────────────────────────\n"
    + "DUAL-REGISTER OUTPUT — you produce TWO sides for each prose slot:\n"
    + "  • the BUSINESS side ('b'): obey ALL the business-only rules above —\n"
    + "    name every variable as 'Business Name (CODE)', describe operations as\n"
    + "    business actions, keep concrete business values, NO file stems / opcodes /\n"
    + "    raw statements / routine names.\n"
    + "  • the TECHNICAL side ('t'): here, AND ONLY here, the carve-out below applies —\n"
    + "    you MAY use file names, routine/function names, enum tokens, and the raw\n"
    + "    condition / statement text. Be precise and terse.\n\n"
    + "TECHNICAL-SIDE CARVE-OUT (from the technical register):\n"
    + _DESIGN_RULE
    + "\n\n" + _COMPLETENESS_RULE
    + "\n\n" + _BUSINESS_ONLY_RULE
    + "\n\nCRITICAL CONSISTENCY RULES:\n"
    + "  1. The 't' side must NEVER contradict any fact given to you. When a slot\n"
    + "     already carries a technical fact ('t_fact'), your 't' must be consistent\n"
    + "     with it (you may elaborate, never contradict).\n"
    + "  2. business_name values are SHORT Title-Case labels (no code, no prose).\n"
    + "  3. Return EXACTLY the path keys you were given — no more, no fewer.\n"
    + "  4. GROUNDED NAMING — NEVER invent a business meaning for an identifier you\n"
    + "     were not given facts for. Every business name (a 'name' slot, or a\n"
    + "     variable named inside prose) must be derived ONLY from the actual\n"
    + "     identifier and the verbatim facts provided for it (its 'grounding_facts',\n"
    + "     'raw_name', 't_fact', or 'context.raw' — the real condition texts /\n"
    + "     assigned values). DO NOT free-associate a product concept from the\n"
    + "     token's spelling. In particular, an opaque ASM-style name (sigil-prefixed\n"
    + "     like @CASVIS1, or a terse mnemonic) carries NO inherent product meaning:\n"
    + "     if the facts are bitwise tests of a status byte (e.g. `TM @CASVIS1,X'01'`,\n"
    + "     `(@CASVIS1 & X'01')==X'01'`), the variable is an INDICATOR/STATUS-FLAG\n"
    + "     byte — name it neutrally as such (e.g. 'CAS Vision Indicator (@CASVIS1)'),\n"
    + "     and NEVER read it as a result/value field (do not call it a 'CVV2 Result'),\n"
    + "     and NEVER invent an instruction (e.g. a `CLC ...,C'M'`) or match codes that\n"
    + "     do not appear in the facts. When the facts are insufficient to establish a\n"
    + "     specific business meaning, stay literal/neutral — do not guess.\n"
    + "  5. FAITHFUL CONDITIONS — when you describe a comparison/predicate, restate the\n"
    + "     ACTUAL operator and the ACTUAL constant/enum FAITHFULLY; never flip its\n"
    + "     polarity or meaning. An equality against a 'not-found' / negative / error\n"
    + "     enum means exactly that. Examples:\n"
    + "       • `cidioReturnCode == CidioReturn::NoCidRecord` → 'when NO CID record was\n"
    + "         found (no match)', NEVER 'a successful read'.\n"
    + "       • `== Success` / `== 0` (a success/zero return) → 'succeeded'.\n"
    + "       • `!= X` reads as 'is NOT X', `== X` reads as 'IS X'.\n"
    + "     If the enum/constant name encodes a negative or absence (No*, Not*, Missing,\n"
    + "     Invalid, Error, Fail), the condition is TRUE in that negative case — say so;\n"
    + "     do not describe the opposite. Read enum tokens literally; do not assume a\n"
    + "     comparison tests for success unless the constant actually denotes success.\n"
)


def _slot_payload(slot: Slot) -> Dict[str, Any]:
    """Compact JSON-serialisable view of a slot for the prompt."""
    p: Dict[str, Any] = {"path": slot.path, "is": slot.field, "kind": slot.kind}
    if slot.kind == "bt":
        p["t_fact"] = slot.t_fact            # ground truth — DO NOT contradict
        p["needs"] = (
            ["b", "t"] if models.is_empty_bt_side(slot.t_fact) else ["b"]
        )
    else:
        # NAME slot. The model must derive the business name from the REAL
        # identifier (`raw_name`) plus the actual facts the variable participates
        # in (`grounding_facts`) — NEVER by free-associating a product concept
        # from an opaque token. When the token is opaque and the facts don't
        # reveal a clear meaning, it must stay literal/neutral, not invent one.
        p["raw_name"] = slot.t_fact
        _facts = (slot.context or {}).get("raw") or ""
        if _facts:
            p["grounding_facts"] = _facts
    if slot.context:
        p["context"] = slot.context
    return p


def _build_batch_prompt(variable: str, batch_label: str, slots: List[Slot]) -> str:
    """Build the user prompt for one batch of slots."""
    bt_slots = [s for s in slots if s.kind == "bt"]
    name_slots = [s for s in slots if s.kind == "name"]

    scope = (
        "the variable itself (its business name, description, inquiry-path text)"
        if batch_label == "variable"
        else f"one setter subtree of the variable ({batch_label})"
    )

    lines: List[str] = [
        f"You are filling the EMPTY prose slots for a Setter-Analysis UI record of "
        f"the mainframe data field '{variable}'.",
        f"This batch covers {scope}.",
        "",
        "Each slot below gives:",
        "  • path   — the EXACT key you must return it under,",
        "  • is     — WHAT the field is (so you know what to write),",
        "  • kind   — 'bt' (needs a business 'b' and/or technical 't' side) or "
        "'name' (a short business name string),",
        "  • t_fact / raw_name — ground-truth context you must respect and never contradict,",
        "  • context — the nearest file / function / raw code / location / value.",
        "",
        "Return a JSON object with two maps:",
        "  • 'bt'    : { <path> : {\"b\": <business side>, \"t\": <technical side>} }  — "
        "for EVERY 'bt' slot. If a slot's 'needs' lists only [\"b\"], you may echo its "
        "t_fact as 't' (do NOT invent a new technical fact).",
        "  • 'names' : { <path> : <short Title-Case business name> }  — for EVERY 'name' slot.",
        "",
        "SLOTS:",
        json.dumps([_slot_payload(s) for s in slots], ensure_ascii=False, indent=2),
        "",
        f"Produce {len(bt_slots)} entries under 'bt' and {len(name_slots)} entries under "
        f"'names', keyed by the exact paths above.",
        "",
        "IMPORTANT: Keep each prose value to 1-2 SHORT sentences (max 40 words each). "
        "Do NOT write paragraphs or bullet lists. Be precise and concise.",
    ]
    return "\n".join(lines)


def _fill_batch_via_llm(
    struct: dict,
    variable: str,
    batch_label: str,
    slots: List[Slot],
    max_retries: int,
) -> List[Slot]:
    """Ask Gemini to fill one batch; write back empty sides. Return still-missing slots."""
    from process_analysis.backend.llm import call_llm_model, LLMJSONError

    if not slots:
        return []

    prompt = _build_batch_prompt(variable, batch_label, slots)
    try:
        resp = call_llm_model(
            prompt,
            _ProseFillResponse,
            system_prompt=_PROSE_SYSTEM_PROMPT,
            max_retries=max_retries,
        )
    except LLMJSONError as exc:
        logger.warning("prose batch %s/%s failed entirely: %s", variable, batch_label, exc)
        return list(slots)  # all still missing

    bt_map = resp.bt or {}
    name_map = resp.names or {}

    still_missing: List[Slot] = []
    for slot in slots:
        if slot.kind == "name":
            val = (name_map.get(slot.path) or "").strip()
            if val:
                _apply_name(struct, slot.path, val)
            else:
                still_missing.append(slot)
        else:  # bt
            fill = bt_map.get(slot.path)
            if fill is None:
                still_missing.append(slot)
                continue
            b = (fill.b or "").strip()
            t = (fill.t or "").strip()
            # A slot that needed a 'b' must have produced a non-blank 'b'.
            if not b:
                still_missing.append(slot)
                continue
            _apply_bt(struct, slot.path, b, t)
    return still_missing


# ===========================================================================
# Public entry point
# ===========================================================================

def _validate(struct: dict) -> dict:
    """Validate against the right top-level model; return the (unchanged) dict."""
    if struct.get("terminal") is True:
        models.TerminalInputTable.model_validate(struct)
    else:
        models.VariableTable.model_validate(struct)
    return struct


def fill_prose(
    struct: dict,
    *,
    variable: str,
    cache: Optional[ProseCache] = None,
    cross_var_cache: Optional[CrossVarCache] = None,
    no_llm: bool = False,
    shard: bool = True,
    max_retries: int = 3,
) -> dict:
    """Fill the empty prose slots of a structural (pre-fill) dict.

    Args:
        struct:   the structural dict (facts + empty placeholders). NOT mutated;
                  a deep copy is filled and returned.
        variable: the raw variable name (cache key + prompt context).
        cache:    optional ProseCache; on hit the LLM is skipped entirely.
        cross_var_cache: optional CrossVarCache; shared across parallel
                  fill_prose() calls so identical conditions across different
                  variables reuse the same LLM result.
        no_llm:   when True, fill deterministically (the --no-llm contract path).
                  The cache is bypassed (deterministic fills are not LLM output).
        shard:    when True (default), the LLM path batches one call per setter
                  subtree + one for the variable level. When False, all slots go
                  in a single call (smaller traces only — risks oversized prompts).
        max_retries: passed through to call_llm_model per batch.

    Returns:
        The FILLED dict, validated against VariableTable / TerminalInputTable.
    """
    import copy

    work = copy.deepcopy(struct)

    def _ret(payload: dict) -> dict:
        # member_of / counterpart are STRUCTURAL identity facts excluded from the
        # prose-cache key (cache.struct_hash), so a cache HIT returns a payload from
        # before they existed. Re-attach them from the current struct on EVERY return
        # path — present only when the struct actually carries them (UI shows them
        # only when present). The prose layer never owns these fields.
        for _k in ("member_of", "counterpart"):
            _v = struct.get(_k)
            if _v is not None:
                payload[_k] = _v
            else:
                payload.pop(_k, None)
        return payload

    # --- no-LLM contract path ------------------------------------------------
    if no_llm:
        slots = collect_slots(work)
        _no_llm_fill(work, slots)
        return _ret(_validate(work))

    # --- cache (keyed on the PRE-FILL struct) --------------------------------
    sh = ProseCache.struct_hash(struct) if cache is not None else None
    if cache is not None and sh is not None:
        hit = cache.get(variable, sh)
        if hit is not None:
            logger.info("prose cache HIT for %s (%s)", variable, sh[:12])
            return _ret(_validate(hit))

    # --- LLM fill ------------------------------------------------------------
    slots = collect_slots(work)
    if not slots:
        filled = _validate(work)
        if cache is not None and sh is not None:
            cache.put(variable, sh, filled)
        return _ret(filled)

    # --- DEDUP identical slots ----------------------------------------------
    # The clubbed setters all replay the same chain-prefix conditions (e.g. the
    # dw730000:57 readiness guard appears in every setter's path) and reuse the
    # same dep-var / file names. Explaining each unique fact ONCE and broadcasting
    # the result collapses ~1800 hero slots to a few hundred uniques — far fewer
    # Gemini calls, and identical conditions get identical wording. The key is the
    # field + ground-truth fact + full local context (which includes location /
    # raw text), so DISTINCT conditions never merge — only true duplicates do.
    def _dedup_key(s: Slot):
        if s.kind == "name":
            return ("name", (s.t_fact or "").strip().lower())
        return ("bt", s.field, (s.t_fact or "").strip(),
                json.dumps(s.context or {}, sort_keys=True, ensure_ascii=False))

    def _cross_var_key(s: Slot) -> tuple:
        """Dedup key that excludes 'variable' from context for cross-variable reuse."""
        if s.kind == "name":
            return ("name", (s.t_fact or "").strip().lower())
        ctx = s.context or {}
        ctx_sans_var = {k: v for k, v in ctx.items() if k != "variable"}
        return ("bt", s.field, (s.t_fact or "").strip(),
                json.dumps(ctx_sans_var, sort_keys=True, ensure_ascii=False))

    groups: Dict[Any, List[Slot]] = {}
    for s in slots:
        groups.setdefault(_dedup_key(s), []).append(s)
    reps = [members[0] for members in groups.values()]
    logger.info("prose dedup: %d slots -> %d unique for %s", len(slots), len(reps), variable)

    # --- CROSS-VARIABLE CACHE LOOKUP: skip LLM for slots already filled ----
    xv_hits = 0
    if cross_var_cache is not None:
        still_need_llm: List[Slot] = []
        for rep in reps:
            xk = _cross_var_key(rep)
            cached_val = cross_var_cache.get(xk)
            if cached_val is not None:
                if rep.kind == "name":
                    _apply_name(work, rep.path, cached_val)
                elif _is_bt(cached_val):
                    _apply_bt(work, rep.path, cached_val.get("b", ""), cached_val.get("t", ""))
                xv_hits += 1
            else:
                still_need_llm.append(rep)
        reps = still_need_llm
        if xv_hits:
            logger.info("cross-var cache: %d hits, %d still need LLM for %s",
                        xv_hits, len(reps), variable)

    # Batch the REPRESENTATIVES into bounded chunks (filled in parallel below).
    _CHUNK = 40  # larger batches → fewer LLM calls; safe with 65K output token limit
    if shard:
        batches: Dict[str, List[Slot]] = {
            f"chunk-{i // _CHUNK}": reps[i:i + _CHUNK]
            for i in range(0, len(reps), _CHUNK)
        }
    else:
        batches = {"all": reps}

    # Fill batches concurrently. Each batch writes a DISJOINT set of slot paths
    # (a different setter subtree / the variable level), so concurrent writes into
    # `work` touch different leaves. Real API concurrency is bounded by call_llm's
    # process-wide BoundedSemaphore (LLM_MAX_CONCURRENCY), so extra workers simply
    # block on it — this just stops the per-setter calls from running one-at-a-time.
    leftovers: List[Slot] = []
    if len(batches) <= 1:
        for batch_label, batch_slots in batches.items():
            leftovers += _fill_batch_via_llm(work, variable, batch_label, batch_slots, max_retries)
    else:
        from concurrent.futures import ThreadPoolExecutor
        try:
            from api.config import settings as _s
            _workers = max(2, int(getattr(_s, "LLM_MAX_CONCURRENCY", 6) or 6))
        except Exception:
            _workers = 6
        _workers = min(_workers, len(batches))
        with ThreadPoolExecutor(max_workers=_workers) as _ex:
            _futs = [
                _ex.submit(_fill_batch_via_llm, work, variable, bl, bs, max_retries)
                for bl, bs in batches.items()
            ]
            for _f in _futs:
                leftovers += _f.result()

    # One-shot top-up: retry any still-missing slots together (they may have been
    # dropped because the batch was large); then deterministically backfill the
    # rest so the result ALWAYS validates with no empty sides.
    if leftovers:
        logger.info("prose top-up: %d slot(s) still missing for %s", len(leftovers), variable)
        leftovers = _fill_batch_via_llm(work, variable, "top-up", leftovers, max_retries)
    if leftovers:
        logger.warning(
            "prose deterministic backfill: %d slot(s) unfilled by Gemini for %s",
            len(leftovers), variable,
        )
        _no_llm_fill(work, leftovers)

    # --- BROADCAST: copy each filled representative to its duplicate slots. ---
    for members in groups.values():
        if len(members) <= 1:
            continue
        rep = members[0]
        parent, key = _resolve_parent(work, rep.path)
        val = parent.get(key) if isinstance(parent, dict) else None
        for dup in members[1:]:
            if rep.kind == "name":
                if isinstance(val, str) and val:
                    _apply_name(work, dup.path, val)
            elif _is_bt(val):
                _apply_bt(work, dup.path, val.get("b", "") or "", val.get("t", "") or "")

    # --- POPULATE CROSS-VARIABLE CACHE with newly filled values. -----------
    if cross_var_cache is not None:
        _xv_stored = 0
        for members in groups.values():
            rep = members[0]
            xk = _cross_var_key(rep)
            if cross_var_cache.get(xk) is not None:
                continue  # already cached
            try:
                parent, key = _resolve_parent(work, rep.path)
                val = parent.get(key) if isinstance(parent, dict) else (
                    parent[key] if isinstance(key, int) else None
                )
            except (KeyError, IndexError, TypeError):
                continue
            if rep.kind == "name" and isinstance(val, str) and val:
                cross_var_cache.put(xk, val)
                _xv_stored += 1
            elif rep.kind == "bt" and _is_bt(val) and not models.is_empty_bt_side(val.get("b")):
                cross_var_cache.put(xk, dict(val))
                _xv_stored += 1
        if _xv_stored:
            logger.info("cross-var cache: stored %d new entries for %s (total %d)",
                        _xv_stored, variable, len(cross_var_cache))

    filled = _validate(work)
    if cache is not None and sh is not None:
        cache.put(variable, sh, filled)
    return _ret(filled)


# ===========================================================================
# Smoke test (NO real LLM)
# ===========================================================================

def _sample_struct() -> dict:
    """Hand-built pre-fill struct: 1 setter, 1 path, 2 files, 1 condition, 1 dep var."""
    return {
        "variable": "softCardValue",
        "business_name": "",
        "description": {"b": "", "t": ""},
        "inquiry_path": {
            "name": "Inquiry Path",
            "description": {"b": "", "t": ""},
            "long_description": {"b": "", "t": ""},
            "files": [
                {
                    "file": "aa71.asm",
                    "kind": "asm",
                    "business_name": "",
                    "conditions": [],
                    "call_site": {
                        "location": "aa71.asm:120",
                        "code": "BAS R7,DW73000",
                        "note": {"b": "", "t": ""},
                    },
                },
            ],
        },
        "setters": [
            {
                "id": "setter-0",
                "index": 0,
                "description": {"b": "", "t": ""},
                "assigned_value": {"b": "", "t": "SoftCardValueDetail::ExpressPayTransaction"},
                "location": "dw71.cpp:880",
                "paths": [
                    {
                        "id": "path-0",
                        "name": {"b": "", "t": ""},
                        "description": {"b": "", "t": ""},
                        "files": [
                            {
                                "file": "dw73.cpp",
                                "kind": "cpp",
                                "function": "routeRequest",
                                "business_name": "",
                                "conditions": [
                                    {
                                        "n": 1,
                                        "rule": {"b": "", "t": "(@CASVIS1 & X'01') == X'01'"},
                                        "location": "dw73.cpp:210",
                                        "source_code": "if ((CASVIS1 & 0x01) == 0x01) {",
                                        "dependent_variables": [
                                            {"name": "Visa Indicator (CASVIS1)", "id": "CASVIS1"}
                                        ],
                                        "description": {"b": "", "t": ""},
                                    }
                                ],
                                "call_site": {
                                    "location": "dw73.cpp:230",
                                    "code": "setSoftCardValue(detail);",
                                    "note": {"b": "", "t": ""},
                                },
                            },
                            {
                                "file": "dw71.cpp",
                                "kind": "cpp",
                                "function": "setSoftCardValue",
                                "business_name": "",
                                "sets": True,
                                "assigned_value": {
                                    "b": "",
                                    "t": "SoftCardValueDetail::ExpressPayTransaction",
                                },
                                "conditions": [],
                                "setter_source": {
                                    "location": "dw71.cpp:880",
                                    "code": "softCardValue = SoftCardValueDetail::ExpressPayTransaction;",
                                },
                            },
                        ],
                    }
                ],
                "dependent_variables": [
                    {
                        "variable": "CASVIS1",
                        "business_name": "",
                        "what_it_is": {"b": "", "t": ""},
                        "role": {"b": "", "t": ""},
                    }
                ],
            }
        ],
        "dependent_variables": [],
    }


def _smoke() -> None:
    struct = _sample_struct()
    slots = collect_slots(struct)

    by_kind: Dict[str, int] = {}
    by_field: Dict[str, int] = {}
    by_batch: Dict[str, int] = {}
    for s in slots:
        by_kind[s.kind] = by_kind.get(s.kind, 0) + 1
        by_field[s.field] = by_field.get(s.field, 0) + 1
        by_batch[s.batch] = by_batch.get(s.batch, 0) + 1

    print("=== collect_slots ===")
    print(f"total slots: {len(slots)}")
    print(f"by kind:  {by_kind}")
    print(f"by batch: {by_batch}")
    print("by field:")
    for f, n in sorted(by_field.items()):
        print(f"  {n:>2}  {f}")
    print("\npaths:")
    for s in slots:
        print(f"  [{s.kind:4}] {s.path}")

    # Expected slot accounting (hand-counted from _sample_struct):
    #   names: variable, inquiry aa71 file, path dw73 file, path dw71 file, dep var CASVIS1  = 5
    #   bt:    variable.description, inquiry.description, inquiry.long_description,
    #          inquiry aa71 call_site.note,
    #          setter.description, setter.assigned_value (.b only — .t is a fact),
    #          path.name, path.description,
    #          dw73 condition.rule (.b only), dw73 condition.description, dw73 call_site.note,
    #          dw71 assigned_value (.b only),
    #          dep var what_it_is, dep var role                                       = 14
    expected_names = 5
    expected_bt = 14
    assert by_kind.get("name", 0) == expected_names, (by_kind, "names")
    assert by_kind.get("bt", 0) == expected_bt, (by_kind, "bt")

    # A rule slot keeps its .t fact in the slot for the model to respect.
    rule_slot = next(s for s in slots if s.field == "condition rule")
    assert rule_slot.t_fact == "(@CASVIS1 & X'01') == X'01'", rule_slot.t_fact

    # --- no-LLM fill ---
    filled = fill_prose(struct, variable="softCardValue", no_llm=True)
    print("\n=== fill_prose(no_llm=True) ===")

    # Every placeholder must now be filled (no empty side, no empty business_name).
    remaining = collect_slots(filled)
    assert not remaining, f"still-empty slots after no_llm fill: {[s.path for s in remaining]}"

    # Ground-truth .t facts must be PRESERVED untouched.
    setter0 = filled["setters"][0]
    assert setter0["assigned_value"]["t"] == "SoftCardValueDetail::ExpressPayTransaction"
    cond0 = setter0["paths"][0]["files"][0]["conditions"][0]
    assert cond0["rule"]["t"] == "(@CASVIS1 & X'01') == X'01'"
    assert filled["setters"][0]["paths"][0]["files"][1]["assigned_value"]["t"] == (
        "SoftCardValueDetail::ExpressPayTransaction"
    )

    # business_name humanisation sanity.
    assert filled["business_name"] != ""
    assert filled["setters"][0]["dependent_variables"][0]["business_name"] != ""

    # Validates against the model (fill_prose already validated; re-assert here).
    models.VariableTable.model_validate(filled)

    print("all placeholders filled; .t facts preserved; VariableTable validates.")

    # --- terminal input variable shape ---
    term = {
        "variable": "CASVIS1",
        "business_name": "",
        "terminal": True,
        "description": {"b": "", "t": ""},
        "origin": {"b": "", "t": ""},
        "setters": [],
    }
    tslots = collect_slots(term)
    assert {s.field for s in tslots} == {
        "variable business_name",
        "variable description",
        "terminal input origin (where its value comes from)",
    }, {s.field for s in tslots}
    tfilled = fill_prose(term, variable="CASVIS1", no_llm=True)
    assert not collect_slots(tfilled)
    models.TerminalInputTable.model_validate(tfilled)
    print("terminal input: 3 slots, filled, TerminalInputTable validates.")

    print("\nSMOKE OK")


if __name__ == "__main__":
    _smoke()
