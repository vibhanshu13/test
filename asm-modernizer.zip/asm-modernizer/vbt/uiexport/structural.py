"""vbt.uiexport.structural — DETERMINISTIC (no-LLM) transform from a VBT trace
directory into the per-variable dicts the Zenflow Setter-Analysis "table" view
consumes.

This layer fills ONLY the facts that exist in the trace plus the `.t` sides that
are raw ground truth (the condition text and the assigned enum/literal). Every
other `{b,t}` side and every `business_name` is emitted as an EMPTY placeholder
(`{"b":"","t":""}` / `""`) for the later prose (Gemini) layer to fill. See the
FIELD-OWNERSHIP block at the top of `models.py` — this module honours it exactly.

The output of `build_variable_struct` validates against `models.VariableTable`
(when the variable has setters) or `models.TerminalInputTable` (a terminal input
with no setters). Validation runs before the dict is returned.

Nothing here ever calls an LLM and nothing here fabricates data: when the trace
is silent (e.g. a caller code block cannot be resolved for a hop), we fall back
to the raw `via` label rather than inventing source code.
"""
from __future__ import annotations

import json
import os
import re
import sys
from collections import Counter, OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from . import models

# --------------------------------------------------------------------------- #
# Empty-placeholder helpers (the prose layer fills these).
# --------------------------------------------------------------------------- #


def _empty_bt() -> Dict[str, str]:
    return {"b": "", "t": ""}


def _bt_t(t: str) -> Dict[str, str]:
    """A {b,t} pair whose technical side is a known fact and business side blank."""
    return {"b": "", "t": t or ""}


# --------------------------------------------------------------------------- #
# File-name normalisation.
# --------------------------------------------------------------------------- #


def file_stem(path: Optional[str]) -> str:
    """Reduce a trace `location.file` to a bare stem.

    "dw710000.cpp" -> "dw710000"; "aa71.asm" -> "aa71";
    "datasource/.../dw730000.cpp" -> "dw730000".
    """
    if not path:
        return ""
    base = os.path.basename(path)
    if "." in base:
        return base.rsplit(".", 1)[0]
    return base


def file_kind(path: Optional[str]) -> str:
    """Derive UI `kind` from the extension: ".asm" -> "asm", else "cpp"."""
    if path and path.endswith(".asm"):
        return "asm"
    return "cpp"


# --------------------------------------------------------------------------- #
# FunctionIndex — smallest enclosing code-block per (file-stem, line).
# --------------------------------------------------------------------------- #


class FunctionIndex:
    """Maps a (file_stem, line) to the smallest enclosing block's function/label.

    Built from codeBlocks.json keys of the form
    ``cpp:<stem>:<function>`` / ``asm:<stem>:<label>``.
    """

    def __init__(self, per_stem: Dict[str, List[Tuple[int, int, str]]]):
        # per_stem[stem] -> list of (start, end, function)
        self._per_stem = per_stem

    def lookup(self, file_stem: str, line: int) -> Optional[str]:
        cands = self._per_stem.get(file_stem)
        if not cands:
            return None
        best: Optional[Tuple[int, str]] = None
        for start, end, fn in cands:
            if start <= line <= end:
                span = end - start
                if best is None or span < best[0]:
                    best = (span, fn)
        return best[1] if best else None


def build_function_index(code_blocks: Dict[str, Any]) -> FunctionIndex:
    per_stem: Dict[str, List[Tuple[int, int, str]]] = {}
    for key, blk in code_blocks.items():
        # key = "<lang>:<stem-in-key>:<function>" but the authoritative stem is
        # taken from blk["file"] (handles datasource/ prefixed paths uniformly).
        parts = key.split(":", 2)
        if len(parts) != 3:
            continue
        fn = parts[2]
        stem = file_stem(blk.get("file")) or parts[1]
        try:
            start = int(blk["startLine"])
            end = int(blk["endLine"])
        except (KeyError, TypeError, ValueError):
            continue
        per_stem.setdefault(stem, []).append((start, end, fn))
    return FunctionIndex(per_stem)


# --------------------------------------------------------------------------- #
# Trace loader.
# --------------------------------------------------------------------------- #


class Trace:
    """Lazy holder for a VBT trace directory."""

    def __init__(self, trace_dir: Path, root: dict, code_blocks: dict,
                 depvar_index: Optional[Dict[str, dict]] = None,
                 depvar_groups: Optional[Dict[str, List[dict]]] = None):
        self._dir = Path(trace_dir)
        self.root = root
        self.code_blocks = code_blocks
        self._depvar_cache: Dict[str, Optional[dict]] = {}
        # When set (the in-memory / live path), dep vars are served from this
        # dict instead of dependentVariables/<name>.json files on disk.
        self._depvar_index = depvar_index
        # Additive: ALL trace entities that share one short tail name. The trace
        # distinguishes same-tail entities by their `qualified` path (e.g.
        # `allCidRecords.numberOfCidRecords` vs `allCidRecordWorkArea.numberOfCidRecords`
        # vs a plain local). `_depvar_index` keeps only the LAST such entity
        # (back-compat / single-entity callers); this preserves the full list so
        # the per-variable card can represent every entity's setters instead of
        # hiding the setter-having ones behind a terminal namesake. Keyed by the
        # SAME short name the UI clicks on; empty/None on the disk path (one file
        # per name → no in-memory collision to recover).
        self._depvar_groups = depvar_groups

    @property
    def root_variable(self) -> dict:
        return self.root.get("rootVariable", {})

    def _depvar_path(self, name: str) -> Path:
        return self._dir / "dependentVariables" / f"{name}.json"

    def has_depvar(self, name: str) -> bool:
        if self._depvar_index is not None:
            return name in self._depvar_index
        return self._depvar_path(name).is_file()

    def depvar(self, name: str) -> Optional[dict]:
        """Return the inner "dependentVariable" object for *name* (or None).
        In-memory index when present, else dependentVariables/<name>.json."""
        if self._depvar_index is not None:
            return self._depvar_index.get(name)
        if name in self._depvar_cache:
            return self._depvar_cache[name]
        path = self._depvar_path(name)
        if not path.is_file():
            self._depvar_cache[name] = None
            return None
        with path.open() as fh:
            doc = json.load(fh)
        inner = doc.get("dependentVariable") if isinstance(doc, dict) else None
        self._depvar_cache[name] = inner
        return inner

    def depvar_group(self, name: str) -> List[dict]:
        """All trace entities sharing the short tail *name* (in trace order).

        When the in-memory group index has more than one entity for *name*
        (same tail, distinct `qualified` paths), return them all so the card can
        surface every entity's setters. Otherwise (single entity, or the on-disk
        path with one file per name) fall back to the single `depvar(name)`."""
        if self._depvar_groups is not None:
            grp = self._depvar_groups.get(name)
            if grp:
                return grp
        one = self.depvar(name)
        return [one] if one is not None else []


def load_trace(trace_dir: Path) -> Trace:
    trace_dir = Path(trace_dir)
    with (trace_dir / "rootVariable.json").open() as fh:
        root = json.load(fh)
    with (trace_dir / "codeBlocks.json").open() as fh:
        code_blocks = json.load(fh)
    return Trace(trace_dir, root, code_blocks)


def load_trace_dict(trace_output: dict) -> Trace:
    """Build a Trace from the IN-MEMORY dict returned by
    ``vbt.engine.trace_root_variable`` (the same shape the on-disk split derives
    from), so the live API can feed engine output straight into
    ``build_variable_struct`` without writing files.

    trace_output = { "rootVariable": {name, setters[], aliases},
                     "dependentVariables": [ <inner dep-var obj>, ... ],
                     "codeBlocks": { blockId: {...} } }
    """
    root_var = trace_output.get("rootVariable", {}) or {}
    root = {"variable": root_var.get("name", ""), "rootVariable": root_var}
    code_blocks = trace_output.get("codeBlocks", {}) or {}
    # Index dep vars by name. Entries may be the inner object (has "name") or a
    # wrapped {"dependentVariable": {...}} — handle both.
    index: Dict[str, dict] = {}
    groups: Dict[str, List[dict]] = {}
    for d in trace_output.get("dependentVariables", []) or []:
        if not isinstance(d, dict):
            continue
        inner = d.get("dependentVariable") if "dependentVariable" in d else d
        name = (inner or {}).get("name")
        if name:
            # `index` keeps the last entity for the name (back-compat); `groups`
            # preserves EVERY same-tail entity (distinguished by `qualified`) so
            # the card can represent all of their setters, not just the survivor.
            index[name] = inner
            groups.setdefault(name, []).append(inner)
    return Trace(Path("."), root, code_blocks, depvar_index=index,
                 depvar_groups=groups)


# --------------------------------------------------------------------------- #
# via-edge parsing.
# --------------------------------------------------------------------------- #

# Recognised `via` shapes (the hop INTO the next file):
#   "aa71→dw730000"                                 (ASM stem -> stem)
#   "caller→callee@line"                            (function -> function)
#   "file.caller→file.callee@line"                  (qualified function hop)
_VIA_ARROW = "→"  # →


def _parse_via(via: Optional[str]) -> Optional[dict]:
    """Decompose a `via` label into its caller/callee parts.

    Returns {raw, callee_fn, callee_stem, callee_line} or None when there is no
    parseable callee. We never fabricate: callee_stem/line stay None when absent.
    """
    if not via:
        return None
    if _VIA_ARROW not in via:
        return {"raw": via, "callee_fn": None, "callee_stem": None, "callee_line": None}
    _, _, rhs = via.partition(_VIA_ARROW)
    rhs = rhs.strip()
    callee_line: Optional[int] = None
    m = re.search(r"@(\d+)\s*$", rhs)
    if m:
        callee_line = int(m.group(1))
        rhs = rhs[: m.start()].strip()
    callee_stem: Optional[str] = None
    callee_fn: Optional[str] = rhs or None
    if rhs and "." in rhs:
        # "file.function" qualified form.
        stem_part, _, fn_part = rhs.partition(".")
        callee_stem = stem_part or None
        callee_fn = fn_part or None
    return {
        "raw": via,
        "callee_fn": callee_fn,
        "callee_stem": callee_stem,
        "callee_line": callee_line,
    }


# --------------------------------------------------------------------------- #
# Condition construction.
# --------------------------------------------------------------------------- #


def _block_for(fnindex_key_stem: str, function: Optional[str], code_blocks: dict,
               stem: str) -> Optional[dict]:
    """Find the codeBlocks entry for (stem, function), if any."""
    if not function:
        return None
    # Keys are "<lang>:<stem-in-key>:<function>"; match on the bare stem from
    # blk["file"] AND the trailing function name.
    for key, blk in code_blocks.items():
        if file_stem(blk.get("file")) == stem and key.rsplit(":", 1)[-1] == function:
            return blk
    return None


def _slice_block_line(blk: Optional[dict], line: int) -> Optional[str]:
    """Best-effort: pull the source line `line` out of a code block's `code`."""
    if not blk:
        return None
    try:
        start = int(blk["startLine"])
        code = blk.get("code") or ""
    except (KeyError, TypeError, ValueError):
        return None
    lines = code.splitlines()
    offset = line - start
    if 0 <= offset < len(lines):
        return lines[offset]
    return None


def _slice_cpp_condition(blk: Optional[dict], start_line: int, max_lines: int = 8) -> Optional[str]:
    """Pull a FULL (possibly multi-line) C++ condition out of a code block.

    The engine reports a condition's location as a single startLine even when the
    `if (...)` spans several source lines, so a single-line slice truncates e.g.
    `if ((a==1) &&` and drops `(b==1))`. Read forward from start_line, tracking
    paren depth, until the parens opened on the first line balance — yielding the
    whole condition statement. Falls back to a single line if no '(' is seen."""
    if not blk:
        return None
    try:
        bstart = int(blk["startLine"])
        code = (blk.get("code") or "").splitlines()
    except (KeyError, TypeError, ValueError):
        return None
    out: List[str] = []
    depth = 0
    seen_open = False
    for i in range(max_lines):
        off = (start_line + i) - bstart
        if off < 0 or off >= len(code):
            break
        s = code[off]
        out.append(s)
        depth += s.count("(") - s.count(")")
        if "(" in s:
            seen_open = True
        if seen_open and depth <= 0:
            break
    if not out:
        return None
    return "\n".join(out).rstrip()


def _clean_asm_line(line: Optional[str]) -> Optional[str]:
    """Tidy a raw ASM source line for display: drop the trailing assembler
    change-ref tag (e.g. '   R097') and surrounding whitespace, keeping the
    instruction + its inline comment. No-op on C++ lines (no trailing R-tag)."""
    if not line:
        return None
    s = re.sub(r"\s+R\d{3}\s*$", "", line).strip()
    return s or None


def _condition_depvars(cond: dict, setter_depvars: List[dict]) -> List[dict]:
    """Build DepRef entries for a condition row.

    Primary source: the setter's `dependentVariables[]` whose foundAt line ==
    this condition's line (best-effort). Fallback: identifiers parsed out of the
    condition text, but ONLY when a matching dependentVariables entry exists for
    that name (so every emitted id keys a real generated file). `id` == raw name.
    """
    loc = cond.get("location") or {}
    cond_stem = file_stem(loc.get("file"))
    cond_line = loc.get("startLine")

    # Index the setter's dep vars by (stem, line) and by name.
    by_name = {dv.get("name"): dv for dv in setter_depvars if dv.get("name")}

    matched: "OrderedDict[str, dict]" = OrderedDict()
    for dv in setter_depvars:
        fa = dv.get("foundAt") or {}
        if (
            cond_line is not None
            and fa.get("startLine") == cond_line
            and file_stem(fa.get("file")) == cond_stem
        ):
            name = dv.get("name")
            if name and name not in matched:
                matched[name] = {"name": name, "id": name}

    if matched:
        return list(matched.values())

    # Fallback: identifiers in the condition text that ALSO appear as a dep var.
    text = cond.get("condition") or ""
    out: "OrderedDict[str, dict]" = OrderedDict()
    for ident in re.findall(r"[A-Za-z_][A-Za-z0-9_]*", text):
        if ident in by_name and ident not in out:
            out[ident] = {"name": ident, "id": ident}
    return list(out.values())


def _build_condition(cond: dict, n: int, setter_depvars: List[dict],
                     code_blocks: dict, fnindex: FunctionIndex) -> dict:
    """Map one raw trace condition into a leaf Condition dict (facts + rule.t)."""
    loc = cond.get("location") or {}
    stem = file_stem(loc.get("file"))
    line = loc.get("startLine")
    text = cond.get("condition") or ""

    # source_code, in priority order:
    #  1. ASM: the engine's verbatim compare (+ branch) instructions (asmTest /
    #     asmBranch) — REAL source, anchored at the compare line. (Engine §4.)
    #  2. C++: the real source line sliced from the enclosing code block.
    #  3. Fallback: the normalized condition text (last resort; never fabricated).
    function = None
    blk_id = cond.get("blockId")
    if blk_id:
        function = blk_id.rsplit(":", 1)[-1]
    if function is None and line is not None:
        function = fnindex.lookup(stem, line)
    src = None
    asm_test = cond.get("asmTest")
    asm_branch = cond.get("asmBranch")
    decision = cond.get("decisionLine")
    blk = _block_for(stem, function, code_blocks, stem) if line is not None else None
    if asm_test:
        # Prefer the REAL source lines from the (now-registered) ASM block: they
        # carry the comment that gives the guard its MEANING (e.g.
        # "IS CID INQUIRY ACTIVE?") — which the bare asmTest instruction lacks, and
        # which both the UI source box and the prose context need to be accurate.
        # Fall back to the engine's normalized instructions when no block line.
        cmp_src = _clean_asm_line(_slice_block_line(blk, line)) if line is not None else None
        br_src = _clean_asm_line(_slice_block_line(blk, decision)) if decision else None
        cmp_src = cmp_src or asm_test
        br_src = br_src or asm_branch
        src = cmp_src + (("\n" + br_src) if br_src else "")
    if not src and line is not None:
        # Full multi-line condition (not just the start line) for C++.
        src = _slice_cpp_condition(blk, line) or _slice_block_line(blk, line)
    if not src:
        src = text

    # ASM conditions now anchor startLine = compare, endLine/decisionLine = branch.
    decision = cond.get("decisionLine")
    if decision and line is not None and decision != line:
        location_str = f"{stem}:{line}–{decision}"  # compare–decision span
    else:
        location_str = f"{stem}:{line}" if line is not None else stem
    return {
        "n": n,
        "rule": _bt_t(text),
        "location": location_str,
        "dependent_variables": _condition_depvars(cond, setter_depvars),
        "source_code": src,
        "description": _empty_bt(),
    }


# --------------------------------------------------------------------------- #
# FileStep grouping — split a chain's ordered conditions into per-file runs.
# --------------------------------------------------------------------------- #


def _condition_function(cond: dict, fnindex: FunctionIndex) -> Optional[str]:
    """The enclosing function/label for a condition (for run-grouping)."""
    blk_id = cond.get("blockId")
    if blk_id:
        return blk_id.rsplit(":", 1)[-1]
    loc = cond.get("location") or {}
    line = loc.get("startLine")
    stem = file_stem(loc.get("file"))
    if line is not None:
        return fnindex.lookup(stem, line)
    return None


def _group_runs(conditions: List[dict], fnindex: FunctionIndex
                ) -> List[Tuple[str, Optional[str], List[dict]]]:
    """Split ordered conditions into consecutive (stem, function) runs.

    Returns a list of (stem, function, [conds]) preserving order. ASM conditions
    (no blockId, no fnindex hit) group by stem alone (function == None).
    """
    ordered = sorted(conditions, key=lambda c: c.get("order", 0))
    runs: List[Tuple[str, Optional[str], List[dict]]] = []
    for cond in ordered:
        loc = cond.get("location") or {}
        stem = file_stem(loc.get("file"))
        fn = _condition_function(cond, fnindex)
        if runs and runs[-1][0] == stem and runs[-1][1] == fn:
            runs[-1][2].append(cond)
        else:
            runs.append((stem, fn, [cond]))
    return runs


def _find_call_line(blk: Optional[dict], fn: Optional[str]) -> Optional[Tuple[int, str]]:
    """Find the line in *blk* that CALLS function *fn* (`fn(`), skipping comments.
    Returns (line_no, source) or None. Used when the `via` omits the call line."""
    if not blk or not fn:
        return None
    try:
        start = int(blk["startLine"])
        lines = (blk.get("code") or "").splitlines()
    except (KeyError, TypeError, ValueError):
        return None
    needle = fn + "("
    for i, raw in enumerate(lines):
        s = raw.strip()
        if not s or s.startswith("//") or s.startswith("*") or s.startswith("/*"):
            continue
        if needle in raw:
            return (start + i, s)
    return None


def _call_site_for_run(run_conds: List[dict], code_blocks: dict, fnindex: FunctionIndex,
                       caller_stem: str, caller_fn: Optional[str],
                       next_stem: Optional[str], next_fn: Optional[str]) -> dict:
    """Derive the REAL call statement leaving this file step — NOT a guard line.

    The trace's `via` on the run's last condition carries the call line
    (`caller→callee@LINE`); we slice the caller's block at that exact line. When
    the via omits the line (e.g. a stem-only C++ hop or an ASM ENTRC), we search
    the caller's code block for the call into the next function. We NEVER present a
    guard/switch/if line as the call; if no real call line resolves (e.g. ASM with
    no C++ block) we fall back to an honest hop label, never fabricated source.
    """
    via_raw = None
    for cond in reversed(run_conds):
        if cond.get("via"):
            via_raw = cond["via"]
            break
    parsed = _parse_via(via_raw)
    caller_blk = _block_for(caller_stem, caller_fn, code_blocks, caller_stem)

    call_line: Optional[int] = parsed.get("callee_line") if parsed else None
    code: Optional[str] = None
    if call_line is not None:
        code = _clean_asm_line(_slice_block_line(caller_blk, call_line))
    if not code and next_fn:
        found = _find_call_line(caller_blk, next_fn)
        if found:
            call_line, code = found
    if code:
        return {"location": f"{caller_stem}:{call_line}", "code": code, "note": _empty_bt()}

    # Honest fallback — no resolvable call statement (e.g. ASM ENTRC into C++).
    last_line = (run_conds[-1].get("location") or {}).get("startLine")
    loc = f"{caller_stem}:{last_line}" if last_line is not None else caller_stem
    tgt = next_fn or next_stem or (parsed.get("callee_fn") if parsed else "") or "next file"
    arrow = f"{caller_stem} → {(next_stem + '::') if next_stem else ''}{tgt}"
    return {"location": loc, "code": via_raw or arrow, "note": _empty_bt()}


def _span_clean(line: Optional[str]) -> str:
    """Tidy a raw source line for the span display: drop the trailing assembler
    change-ref tag (e.g. '   R097') but PRESERVE leading indentation (unlike
    _clean_asm_line, which strips it — indentation matters for reading context)."""
    if line is None:
        return ""
    return re.sub(r"\s+R\d{3}\s*$", "", line).rstrip()


def _loc_line(loc_str: Optional[str]) -> Optional[int]:
    """Parse the trailing line number out of a 'stem:LINE' location string."""
    if not loc_str:
        return None
    m = re.search(r":(\d+)\s*$", loc_str)
    return int(m.group(1)) if m else None


def _build_source_span(stem: str, function: Optional[str], run_conds: List[dict],
                       anchor_line: Optional[int], code_blocks: dict) -> Optional[dict]:
    """Build the source view for a file step: the FULL enclosing code block(s) — the
    block holding the first condition through the block holding the call/setter line,
    shown in their entirety so the surrounding code is visible (not just the trimmed
    condition→call window). Condition lines and the call/setter line are flagged for
    highlight; the rest are dim context. Lines are verbatim from the code blocks
    (NOT fabricated). Non-adjacent blocks are separated by a gap marker. Returns None
    when no block resolves."""
    hl: set = set()
    for c in run_conds:
        loc = c.get("location") or {}
        for v in (loc.get("startLine"), loc.get("endLine"), c.get("decisionLine")):
            if isinstance(v, int):
                hl.add(v)
    if isinstance(anchor_line, int):
        hl.add(anchor_line)
    if not hl:
        return None

    # Every block (in THIS file) that contains a highlighted line is shown in full —
    # so the initial block (first condition) and the final block (call/setter) are
    # both complete. Common case: conditions + call live in one block → that whole
    # block.
    blocks: List[Tuple[int, int, dict]] = []
    seen_ranges: set = set()
    for _k, b in code_blocks.items():
        if file_stem(b.get("file")) != stem:
            continue
        try:
            bs, be = int(b["startLine"]), int(b["endLine"])
        except (KeyError, TypeError, ValueError):
            continue
        if (bs, be) in seen_ranges:
            continue
        if any(bs <= n <= be for n in hl):
            blocks.append((bs, be, b))
            seen_ranges.add((bs, be))
    if not blocks:
        return None
    blocks.sort(key=lambda t: t[0])

    lines: List[dict] = []
    prev_end: Optional[int] = None
    for bs, be, b in blocks:
        if prev_end is not None and bs > prev_end + 1:
            lines.append({"n": None, "code": "", "hl": False, "gap": True})
        for n in range(bs, be + 1):
            raw = _slice_block_line(b, n)
            if raw is None:
                continue
            lines.append({"n": n, "code": _span_clean(raw), "hl": n in hl})
        prev_end = be
    if not lines:
        return None
    return {"file": stem, "start": blocks[0][0], "end": blocks[-1][1], "lines": lines}


def _build_path_from_chain(setter: dict, code_blocks: dict, fnindex: FunctionIndex,
                           path_id: str) -> dict:
    """Build one Path from a single clubbed-setter tuple's ordered conditions.

    The LAST file is the setter site (sets=True + assigned_value + setter_source);
    upstream files carry call_site.
    """
    conditions = setter.get("conditions") or []
    runs = _group_runs(conditions, fnindex)

    setter_loc = setter.get("location") or {}
    setter_stem = file_stem(setter_loc.get("file"))
    setter_line = setter_loc.get("startLine")
    setter_fn = (
        fnindex.lookup(setter_stem, setter_line) if setter_line is not None else None
    )
    setter_kind = file_kind(setter_loc.get("file"))

    setter_depvars = setter.get("dependentVariables") or []

    files: List[dict] = []
    # The setter site must be the LAST step. The runs end at the setter's file in
    # well-formed chains; we still guarantee a final setter step exists.
    last_run_is_setter = bool(runs) and runs[-1][0] == setter_stem

    n_counter = 0
    for i, (stem, fn, run_conds) in enumerate(runs):
        is_setter_step = (i == len(runs) - 1) and last_run_is_setter
        step_conds = []
        for cond in run_conds:
            n_counter += 1
            step_conds.append(
                _build_condition(cond, n_counter, setter_depvars, code_blocks, fnindex)
            )
        kind = file_kind(run_conds[0].get("location", {}).get("file"))
        step: dict = {
            "file": stem,
            "kind": kind,
            "function": fn,
            "business_name": "",
            "conditions": step_conds,
        }
        if is_setter_step:
            step["sets"] = True
            step["assigned_value"] = _bt_t(setter.get("value") or "")
            loc_str = (
                f"{setter_stem}.{'asm' if setter_kind == 'asm' else 'cpp'}:{setter_line}"
                if setter_line is not None
                else setter_stem
            )
            step["setter_source"] = {
                "location": loc_str,
                "code": setter.get("setterCodeChunk") or "",
            }
            span = _build_source_span(stem, fn, run_conds, setter_line, code_blocks)
            if span:
                step["source_span"] = span
        else:
            nxt = runs[i + 1] if i + 1 < len(runs) else (None, None, None)
            step["call_site"] = _call_site_for_run(
                run_conds, code_blocks, fnindex,
                caller_stem=stem, caller_fn=fn,
                next_stem=nxt[0], next_fn=nxt[1],
            )
            span = _build_source_span(
                stem, fn, run_conds,
                _loc_line(step["call_site"].get("location")), code_blocks,
            )
            if span:
                step["source_span"] = span
        files.append(step)

    if not last_run_is_setter:
        # No condition run terminated in the setter's own file (e.g. an
        # unconditional-at-setter tuple). Append an explicit setter step.
        loc_str = (
            f"{setter_stem}.{'asm' if setter_kind == 'asm' else 'cpp'}:{setter_line}"
            if setter_line is not None
            else setter_stem
        )
        files.append(
            {
                "file": setter_stem,
                "kind": setter_kind,
                "function": setter_fn,
                "business_name": "",
                "sets": True,
                "assigned_value": _bt_t(setter.get("value") or ""),
                "conditions": [],
                "setter_source": {
                    "location": loc_str,
                    "code": setter.get("setterCodeChunk") or "",
                },
            }
        )

    files = _expand_intermediate_hops(files, code_blocks, fnindex)

    return {
        "id": path_id,
        "name": _empty_bt(),
        "description": _empty_bt(),
        "files": files,
    }


def _parse_callee(code: Optional[str]) -> Optional[str]:
    """The function name a call statement invokes, e.g. 'processCidInquiry(plasticAuth,'
    → 'processCidInquiry'. None for non-calls (ASM ENTRC, etc.)."""
    if not code:
        return None
    m = re.search(r"([A-Za-z_]\w*)\s*\(", code)
    return m.group(1) if m else None


def _expand_intermediate_hops(files: List[dict], code_blocks: dict,
                              fnindex: FunctionIndex, max_depth: int = 4) -> List[dict]:
    """Insert collapsed same-file intermediate hops so every step's call_site is its
    REAL call. A reach step whose call_site invokes function C (≠ the next step's
    function T) means an intermediate function C was skipped: C is what actually calls
    T (or a deeper intermediate). Walk C→…→T (same file), inserting a step per hop with
    its true call line, so e.g. performPaInquiry [calls processCidInquiry@538] →
    processCidInquiry [calls selectCidDbRecord15@814] → selectCidDbRecord15."""
    out: List[dict] = []
    for i, step in enumerate(files):
        out.append(step)
        if step.get("sets") or i + 1 >= len(files):
            continue
        cs = step.get("call_site") or {}
        callee = _parse_callee(cs.get("code"))
        nxt = files[i + 1]
        target = nxt.get("function")
        stem = step.get("file")
        if not (callee and target) or callee == target or step.get("kind") == "asm":
            continue
        cur = callee
        guard = 0
        while cur and cur != target and guard < max_depth:
            guard += 1
            blk = _block_for(stem, cur, code_blocks, stem)
            if not blk:
                break
            found = _find_call_line(blk, target)
            if found:
                line, code = found
                interm = {
                    "file": stem,
                    "kind": step.get("kind"),
                    "function": cur,
                    "business_name": "",
                    "conditions": [],
                    "call_site": {
                        "location": f"{stem}:{line}",
                        "code": _clean_asm_line(code) or code,
                        "note": _empty_bt(),
                    },
                }
                span = _build_source_span(stem, cur, [], line, code_blocks)
                if span:
                    interm["source_span"] = span
                out.append(interm)
                break
            # cur does not call target directly (deeper nesting we can't resolve from
            # the available blocks) — leave the hop unexpanded rather than guess.
            break
    return out


# --------------------------------------------------------------------------- #
# Path de-dup + OR-fold.
# --------------------------------------------------------------------------- #


def _cond_signature(c: dict):
    """Identity of one condition row. Recurses into OR-groups so that two
    DIFFERENT `any` groups are distinguishable (and identical ones still dedup).
    Without this, every `any` row collapsed to the same empty rule-text, which
    made the fold treat distinct OR-groups as identical and silently lose
    alternatives."""
    if c.get("type") == "any":
        members = tuple(sorted((_cond_signature(a) for a in (c.get("any") or [])), key=repr))
        return ("any", members)
    return (c.get("rule") or {}).get("t", "")


def _file_signature(step: dict) -> Tuple:
    """Identity of a FileStep for de-dup: stem, function, ordered condition sigs."""
    cond_sigs = tuple(_cond_signature(c) for c in step.get("conditions", []))
    return (step.get("file"), step.get("function"), cond_sigs)


def _path_signature(path: dict) -> Tuple:
    return tuple(_file_signature(s) for s in path.get("files", []))


def _file_stems_signature(path: dict) -> Tuple:
    return tuple((s.get("file"), s.get("function")) for s in path.get("files", []))


def _leaf_from_step_conditions(step: dict) -> List[dict]:
    """Strip the `n` off a step's conditions to embed them inside an OR-group.

    Nested OR-groups are FLATTENED to their member leaves so that re-folding a
    path which already carries an `any` group accumulates ALL of its
    alternatives. Without flattening, an `any`-row read back as a single opaque
    leaf, so a switch with N>2 routes (e.g. the 5 transactionCode cases that
    reach dw710000's softCardValue setter) kept only the first pair folded and
    dropped the rest."""
    leaves = []
    for c in step.get("conditions", []):
        if c.get("type") == "any":
            for a in c.get("any", []) or []:
                leaves.append({k: v for k, v in a.items() if k != "n"})
        else:
            leaves.append({k: v for k, v in c.items() if k != "n"})
    return leaves


def _norm_cond_text(t: str) -> str:
    """Whitespace-insensitive normalization for comparing condition predicates."""
    return "".join((t or "").split())


def _is_negation(t1: str, t2: str) -> bool:
    """True when one predicate is the SYNTACTIC negation of the other, e.g.
    `X == Good` and `!(X == Good)`. Their disjunction P ∨ ¬P is a tautology, so
    it is not a real guard on the setter (both branches reach it)."""
    a, b = _norm_cond_text(t1), _norm_cond_text(t2)
    if not a or not b:
        return False
    return a == f"!({b})" or b == f"!({a})"


def _drop_negation_pairs(alts: List[dict]) -> List[dict]:
    """Remove provable tautology pairs (P and ¬P) from OR alternatives — a check
    that every merged route satisfies on all branches does not gate the setter.
    Genuine, non-exhaustive alternatives (e.g. code==A vs code==B) are kept; we
    only drop the *provable* P/¬P case, never guessing enum/switch exhaustiveness."""
    used = [False] * len(alts)
    out: List[dict] = []
    for x in range(len(alts)):
        if used[x]:
            continue
        tx = (alts[x].get("rule") or {}).get("t", "")
        for y in range(x + 1, len(alts)):
            if used[y]:
                continue
            ty = (alts[y].get("rule") or {}).get("t", "")
            if _is_negation(tx, ty):
                used[x] = used[y] = True
                break
        if not used[x]:
            out.append(alts[x])
    return out


def _or_fold_paths(paths: List[dict]) -> List[dict]:
    """Fold paths that differ ONLY at a single call-site hop into the same next
    file: merge the divergent step's conditions into a `type:"any"` OR-group.

    Conservative: only folds a pair when their file-stem sequences are identical
    and exactly ONE step differs (by condition text), and that step is a
    non-setter (call_site) step into the same next file.
    """
    if len(paths) <= 1:
        return paths

    folded = list(paths)
    changed = True
    while changed and len(folded) > 1:
        changed = False
        for i in range(len(folded)):
            for j in range(i + 1, len(folded)):
                a, b = folded[i], folded[j]
                fa, fb = a.get("files", []), b.get("files", [])
                if len(fa) != len(fb):
                    continue
                if _file_stems_signature(a) != _file_stems_signature(b):
                    continue
                diff_idx = [
                    k for k in range(len(fa))
                    if _file_signature(fa[k]) != _file_signature(fb[k])
                ]
                if len(diff_idx) != 1:
                    continue
                k = diff_idx[0]
                # Only fold a non-setter (upstream) step.
                if fa[k].get("sets") or fb[k].get("sets"):
                    continue
                merged_step = dict(fa[k])
                la = _leaf_from_step_conditions(fa[k])
                lb = _leaf_from_step_conditions(fb[k])

                def _lk(leaf):
                    return (leaf.get("location"), (leaf.get("rule") or {}).get("t"))

                shared_keys = {_lk(l) for l in la} & {_lk(l) for l in lb}

                # Conditions IDENTICAL in both routes are AND requirements (not OR).
                shared: List[dict] = []
                seen = set()
                for leaf in la:
                    key = _lk(leaf)
                    if key in shared_keys and key not in seen:
                        seen.add(key)
                        shared.append(leaf)

                # The genuine divergence = conditions present in only one route.
                alts: List[dict] = []
                seen = set()
                for leaf in la + lb:
                    key = _lk(leaf)
                    if key in shared_keys or key in seen:
                        continue
                    seen.add(key)
                    alts.append(leaf)

                # Drop provable tautologies (P ∨ ¬P): a check both branches pass is
                # not a guard for this setter — the routes collapse to one path.
                alts = _drop_negation_pairs(alts)

                # Stable, source-ordered alternatives (by location then predicate)
                # so the OR group renders deterministically across regenerations.
                def _alt_sort_key(leaf):
                    loc = str(leaf.get("location") or "")
                    m = re.search(r"(\d+)\s*$", loc)
                    return (loc[: m.start()] if m else loc,
                            int(m.group(1)) if m else 0,
                            (leaf.get("rule") or {}).get("t", ""))
                alts.sort(key=_alt_sort_key)

                merged_conditions: List[dict] = []
                n = 1
                for leaf in shared:
                    c = dict(leaf)
                    c["n"] = n
                    n += 1
                    merged_conditions.append(c)
                if len(alts) >= 2:
                    merged_conditions.append(
                        {"n": n, "type": "any", "note": _empty_bt(), "any": alts}
                    )
                elif len(alts) == 1:
                    c = dict(alts[0])
                    c["n"] = n
                    merged_conditions.append(c)
                # len(alts) == 0 → divergence was non-discriminating; emit no row.
                merged_step["conditions"] = merged_conditions
                new_files = list(fa)
                new_files[k] = merged_step
                merged_path = dict(a)
                merged_path["files"] = new_files
                folded = [
                    p for idx, p in enumerate(folded) if idx not in (i, j)
                ]
                folded.append(merged_path)
                changed = True
                break
            if changed:
                break
    return folded


def _dedup_paths(paths: List[dict]) -> List[dict]:
    seen = set()
    out = []
    for p in paths:
        sig = _path_signature(p)
        if sig in seen:
            continue
        seen.add(sig)
        out.append(p)
    return out


def _merge_setter_sites(paths: List[dict]) -> List[dict]:
    """Merge paths that are IDENTICAL up to the setter step (same upstream files +
    conditions, and the setter is the same file+function) into ONE path whose setter
    step holds multiple `sites`. Each site = one assignment of the SAME value at its
    own line, with its own guard-conjunction + source span. The value is set if ANY
    site's guards hold (OR across sites) — so two near-duplicate paths that differ
    only by which statement sets the value collapse into one path with an OR. Runs
    AFTER _or_fold_paths (which only folds upstream call-site hops, never the setter).
    """
    if len(paths) <= 1:
        return paths
    order: List[Tuple[str, object]] = []   # ("pass", path) | ("grp", key)
    groups: "OrderedDict[tuple, List[dict]]" = OrderedDict()
    for p in paths:
        files = p.get("files", [])
        last = files[-1] if files else None
        if not (last and last.get("sets")):
            order.append(("pass", p))
            continue
        up_sig = tuple(_file_signature(s) for s in files[:-1])
        key = ("grp", up_sig, last.get("file"), last.get("function"), last.get("kind"))
        if key not in groups:
            groups[key] = []
            order.append(("grp", key))
        groups[key].append(p)

    out: List[dict] = []
    for tag, val in order:
        if tag == "pass":
            out.append(val)
            continue
        grp = groups[val]
        if len(grp) == 1:
            out.append(grp[0])
            continue
        base = grp[0]
        shared = [dict(f) for f in base["files"][:-1]]
        sites: List[dict] = []
        for pp in grp:
            ls = pp["files"][-1]
            ss = ls.get("setter_source") or {}
            sites.append({
                "location": ss.get("location"),
                "code": ss.get("code", ""),
                "conditions": ls.get("conditions", []) or [],
                "source_span": ls.get("source_span"),
            })
        ls0 = base["files"][-1]
        # Populate setter_source from the first site so the UI can show
        # source code for the setter even on merged multi-site steps.
        ss0 = sites[0] if sites else {}
        merged_ss = (
            {"location": ss0.get("location") or "", "code": ss0.get("code") or ""}
            if ss0.get("location")
            else None
        )
        merged_setter = {
            "file": ls0.get("file"),
            "kind": ls0.get("kind"),
            "function": ls0.get("function"),
            "business_name": "",
            "sets": True,
            "assigned_value": ls0.get("assigned_value"),
            "conditions": [],          # per-site now (see sites[])
            "setter_source": merged_ss,
            "sites": sites,
        }
        mp = dict(base)
        mp["files"] = shared + [merged_setter]
        mp["name"] = _empty_bt()       # fresh prose name for the merged (multi-site) path
        mp["description"] = _empty_bt()
        out.append(mp)
    return out


def _cap_paths(paths: List[dict], max_paths: int, setter_id: str) -> List[dict]:
    if len(paths) <= max_paths:
        return paths
    # Keep the most-common file-stem signatures first.
    counts = Counter(_file_stems_signature(p) for p in paths)
    paths_sorted = sorted(
        paths, key=lambda p: -counts[_file_stems_signature(p)]
    )
    kept = paths_sorted[:max_paths]
    print(
        f"[uiexport.structural] setter {setter_id!r}: capped "
        f"{len(paths)} paths to {max_paths}",
        file=sys.stderr,
    )
    return kept


# --------------------------------------------------------------------------- #
# Clubbing.
# --------------------------------------------------------------------------- #


def _club_setters(setters: List[dict], fnindex: FunctionIndex
                  ) -> "OrderedDict[Tuple[str, Optional[str], str], List[dict]]":
    """Collapse setter tuples into logical setters keyed by
    (file_stem, function, value). Preserves first-seen order."""
    clubs: "OrderedDict[Tuple, List[dict]]" = OrderedDict()
    for s in setters:
        loc = s.get("location") or {}
        stem = file_stem(loc.get("file"))
        line = loc.get("startLine")
        fn = fnindex.lookup(stem, line) if line is not None else None
        key = (stem, fn, s.get("value"))
        clubs.setdefault(key, []).append(s)
    return clubs


def _build_setter_struct(key: Tuple[str, Optional[str], str], members: List[dict],
                         index: int, trace: Trace, fnindex: FunctionIndex,
                         max_paths: int) -> dict:
    """Build one Setter dict from a clubbed group (its chains become paths[])."""
    stem, fn, value = key
    code_blocks = trace.code_blocks

    raw_paths: List[dict] = []
    for m in members:
        raw_paths.append(
            _build_path_from_chain(m, code_blocks, fnindex, path_id="tmp")
        )

    paths = _dedup_paths(raw_paths)
    paths = _or_fold_paths(paths)
    paths = _dedup_paths(paths)
    paths = _merge_setter_sites(paths)
    setter_id = f"setter-{index}"
    paths = _cap_paths(paths, max_paths, setter_id)

    # Assign stable path ids (path-a, path-b, ...).
    for i, p in enumerate(paths):
        p["id"] = f"path-{chr(ord('a') + i)}" if i < 26 else f"path-{i + 1}"

    # Setter location string + dependent_variables union (raw names -> DepVar).
    rep = members[0]
    rep_loc = rep.get("location") or {}
    rep_line = rep_loc.get("startLine")
    rep_kind = file_kind(rep_loc.get("file"))
    ext = "asm" if rep_kind == "asm" else "cpp"
    # Header location lists EVERY distinct assignment site (a clubbed value may be
    # set at several lines in the function), not just the representative.
    site_lines = sorted({
        m.get("location", {}).get("startLine") for m in members
        if (m.get("location") or {}).get("startLine") is not None
    })
    if site_lines:
        location_str = f"{stem}.{ext}:" + ", :".join(str(l) for l in site_lines)
    else:
        location_str = stem

    dep_union = _dep_union_for_members(members)

    # Classify each dep var by HOW it's used in THIS setter:
    #   value_logic  — appears in a setter-SITE condition (the final condition table
    #                  that selects which value is assigned)
    #   reachability — appears only in UPSTREAM conditions (routes execution from the
    #                  root program to the setter site)
    def _dep_ids(conds):
        ids = set()
        for c in conds or []:
            for dv in c.get("dependent_variables", []) or []:
                ids.add(dv.get("id"))
            for leaf in c.get("any", []) or []:
                for dv in leaf.get("dependent_variables", []) or []:
                    ids.add(dv.get("id"))
        return ids
    value_logic_ids: set = set()
    for p in paths:
        for f in p.get("files", []) or []:
            conds = list(f.get("conditions", []) or [])
            for site in f.get("sites", []) or []:
                conds += site.get("conditions", []) or []
            if f.get("sets"):
                value_logic_ids |= _dep_ids(conds)
    for dv in dep_union:
        dv["dependency_type"] = "value_logic" if dv.get("variable") in value_logic_ids else "reachability"

    # Resolved literal (e.g. "'Z'") — the value the code actually stores, from the
    # const-resolver. Clubbing is keyed on `value`, so every member shares it; take
    # the representative's. Empty string when unresolved (asm consts / opaque exprs).
    resolved_value = str(rep.get("valueResolved") or "")

    return {
        "id": setter_id,
        "index": index,
        "description": _empty_bt(),
        "assigned_value": _bt_t(value or ""),
        "resolved_value": resolved_value,
        "location": location_str,
        "paths": paths,
        "dependent_variables": dep_union,
    }


def _dep_union_for_members(members: List[dict]) -> List[dict]:
    """Union the dependentVariables across a clubbed group into DepVar dicts.

    Only includes names that key a generated file are handled by the caller; here
    we simply preserve every distinct raw name (id == raw name) in first-seen
    order. business_name/what_it_is/role are empty placeholders for prose."""
    out: "OrderedDict[str, dict]" = OrderedDict()
    for m in members:
        for dv in m.get("dependentVariables") or []:
            name = dv.get("name")
            if name and name not in out:
                out[name] = {
                    "variable": name,
                    "business_name": "",
                    "what_it_is": _empty_bt(),
                    "role": _empty_bt(),
                }
    return list(out.values())


# --------------------------------------------------------------------------- #
# inquiry_path.
# --------------------------------------------------------------------------- #


def _longest_common_chain_prefix(setters: List[dict]) -> List[str]:
    """The longest common prefix of the clubbed setters' chains[] (stems).

    Chain hops may be function-qualified (``stem::fn``); normalize to file stems
    so the prefix (used downstream purely for per-file lookups + FileStep labels)
    stays stem-only and the common-prefix comparison is per file, not per function.
    """
    # GAP 8: a chain may now list the same file more than once (intra-file hops). The
    # common-prefix is a per-FILE notion, so collapse each chain to unique stems in order
    # before the positional comparison.
    chains = [list(dict.fromkeys(str(h).split("::", 1)[0] for h in (s.get("chain") or [])))
              for s in setters if s.get("chain")]
    if not chains:
        return []
    prefix: List[str] = []
    for stems in zip(*chains):
        first = stems[0]
        if all(x == first for x in stems):
            prefix.append(first)
        else:
            break
    return prefix


def _inquiry_path_files_from_prefix(prefix: List[str], setters: List[dict],
                                    fnindex: FunctionIndex) -> List[dict]:
    """Build inquiry-path FileSteps from the common chain prefix.

    Each hop carries the conditions whose location/via belong to that hop's file.
    We harvest conditions from a representative setter (the first with the
    longest chain) by file-stem run.
    """
    if not prefix:
        return []
    # Pick the representative setter with the most conditions covering the prefix.
    rep = max(
        setters,
        key=lambda s: len(s.get("conditions") or []),
        default=None,
    )
    if rep is None:
        return []
    runs = _group_runs(rep.get("conditions") or [], fnindex)
    runs_by_stem: Dict[str, List[Tuple[str, Optional[str], List[dict]]]] = {}
    for stem, fn, conds in runs:
        runs_by_stem.setdefault(stem, []).append((stem, fn, conds))

    setter_depvars = rep.get("dependentVariables") or []
    files: List[dict] = []
    n_counter = 0
    for stem in prefix:
        run_list = runs_by_stem.get(stem, [])
        # Merge all runs for this stem (a file may appear once in the prefix).
        conds = [c for (_, _, cs) in run_list for c in cs]
        fn = run_list[0][1] if run_list else None
        kind = "asm"
        step_conds = []
        if conds:
            kind = file_kind(conds[0].get("location", {}).get("file"))
            for cond in conds:
                n_counter += 1
                step_conds.append(
                    _build_condition(cond, n_counter, setter_depvars,
                                     rep.get("_code_blocks") or {}, fnindex)
                )
        files.append(
            {
                "file": stem,
                "kind": kind,
                "function": fn,
                "business_name": "",
                "description": _empty_bt(),
                "conditions": step_conds,
            }
        )
    return files


def _build_inquiry_path(setters: List[dict], trace: Trace,
                        fnindex: FunctionIndex) -> dict:
    prefix = _longest_common_chain_prefix(setters)
    # Stash code_blocks on the rep so _build_condition can slice source.
    for s in setters:
        s["_code_blocks"] = trace.code_blocks
    files = _inquiry_path_files_from_prefix(prefix, setters, fnindex)
    # Clean the stash.
    for s in setters:
        s.pop("_code_blocks", None)
    return {
        "name": "Inquiry Path",
        "description": _empty_bt(),
        "long_description": _empty_bt(),
        "files": files,
    }


def _build_inquiry_path_for_depvar(setters: List[dict], trace: Trace,
                                   fnindex: FunctionIndex) -> dict:
    """Synthesize a dep var's inquiry path from its setters' file-steps.

    Dep-var setters have no chain[]; each setter's path is a per-file run split.
    We take the longest-common file-stem prefix across the setters' built paths,
    or — when all setters are single-file — a single-file flow.
    """
    built_paths = []
    for s in setters:
        s2 = dict(s)
        built_paths.append(_build_path_from_chain(s2, trace.code_blocks, fnindex, "tmp"))
    if not built_paths:
        return {
            "name": "Inquiry Path",
            "description": _empty_bt(),
            "long_description": _empty_bt(),
            "files": [],
        }
    # Longest common (file, function) prefix across the setter paths.
    seqs = [[(f["file"], f.get("function")) for f in p["files"]] for p in built_paths]
    prefix_len = 0
    for tup in zip(*seqs):
        if all(x == tup[0] for x in tup):
            prefix_len += 1
        else:
            break
    if prefix_len == 0:
        # No shared prefix: present the first setter's flow as the canonical one.
        files = built_paths[0]["files"]
    else:
        files = built_paths[0]["files"][:prefix_len]
    # Inquiry-path file steps should not carry sets/assigned_value/setter_source
    # nor call_site — they are a plain flow with conditions only.
    clean_files = []
    for f in files:
        clean_files.append(
            {
                "file": f["file"],
                "kind": f["kind"],
                "function": f.get("function"),
                "business_name": "",
                "description": _empty_bt(),
                "conditions": f.get("conditions", []),
                **({"sets": True} if f.get("sets") else {}),
            }
        )
    return {
        "name": "Inquiry Path",
        "description": _empty_bt(),
        "long_description": _empty_bt(),
        "files": clean_files,
    }


# --------------------------------------------------------------------------- #
# Top-level variable struct builders.
# --------------------------------------------------------------------------- #


def _terminal_origin(entity: dict) -> Optional[dict]:
    """Extract a terminal entity's read-site provenance from its first dependency
    that carries a `foundAt` (e.g. dw780000.cpp:218 + the `int counterFor…` chunk).

    Terminal nodes have no setters, but the trace still records WHERE the value was
    read (the dependency's foundAt) and the verbatim source there (relevantCodeChunk).
    Returns a TerminalOrigin dict, or None when no foundAt is present (never fabricated)."""
    for dep in entity.get("dependencies") or []:
        fa = dep.get("foundAt") or {}
        f = fa.get("file")
        line = fa.get("startLine")
        if f and line is not None:
            return {
                "qualified": entity.get("qualified") or "",
                "location": f"{f}:{line}",
                "code": dep.get("relevantCodeChunk") or "",
            }
    return None


def _membership_fields(node: Optional[dict]) -> dict:
    """Extract a trace node's ``memberOf`` / ``counterpart`` as card fields, OMITTING
    null ones — so a card carries (and the UI shows) them ONLY when present.

    Returns ``{}``, ``{"member_of": …}``, ``{"counterpart": …}`` or both. Values pass
    through verbatim from the trace (memberOf = {language,kind,name}; counterpart =
    {name,language,memberOf}). Excluded from the prose-cache key (see cache.struct_hash)."""
    out: dict = {}
    if not node:
        return out
    mo = node.get("memberOf")
    cp = node.get("counterpart")
    if mo:
        out["member_of"] = mo
    if cp:
        out["counterpart"] = cp
    return out


def _build_terminal_input(name: str, terminal_origins: Optional[List[dict]] = None,
                          membership: Optional[dict] = None) -> dict:
    origins = [o for o in (terminal_origins or []) if o]
    out = {
        "variable": name,
        "business_name": "",
        "terminal": True,
        "description": _empty_bt(),
        # `origin` (the {b,t} prose pair) stays an EMPTY placeholder per the
        # FIELD-OWNERSHIP contract — the prose layer owns it. The structural read-site
        # provenance (location + verbatim code chunk) lives in `terminal_origins`,
        # a structural-owned facts field, so it is never lost yet does not pre-empt prose.
        "origin": _empty_bt(),
        "setters": [],
    }
    if origins:
        out["terminal_origins"] = origins
    out.update(membership or {})   # member_of / counterpart only when present
    return out


def _build_root_struct(name: str, trace: Trace, fnindex: FunctionIndex,
                       max_paths: int) -> dict:
    rv = trace.root_variable
    setters = rv.get("setters") or []

    clubs = _club_setters(setters, fnindex)
    setter_structs = []
    for i, (key, members) in enumerate(clubs.items(), start=1):
        setter_structs.append(
            _build_setter_struct(key, members, i, trace, fnindex, max_paths)
        )

    # Manual display pin: move a chosen setter to the front for specific variables
    # (an explicit curator choice, NOT a data-derived ordering). Match by the
    # setter's representative location prefix; then renumber index/id.
    pin = _PINNED_FIRST_SETTER.get(rv.get("name") or name)
    if pin:
        idx = next(
            (j for j, s in enumerate(setter_structs)
             if str(s.get("location", "")).startswith(pin)),
            None,
        )
        if idx not in (None, 0):
            setter_structs.insert(0, setter_structs.pop(idx))
        for j, s in enumerate(setter_structs, start=1):
            s["index"] = j
            s["id"] = f"setter-{j}"

    inquiry = _build_inquiry_path(setters, trace, fnindex)

    return {
        "variable": rv.get("name") or name,
        "business_name": "",
        "description": _empty_bt(),
        "inquiry_path": inquiry,
        "setters": setter_structs,
        "dependent_variables": [],
        **_membership_fields(rv),   # member_of / counterpart only when present
    }


def _build_depvar_struct(name: str, trace: Trace, fnindex: FunctionIndex,
                         max_paths: int) -> dict:
    # A short tail name may alias SEVERAL distinct trace entities (same `name`,
    # different `qualified` paths) — e.g. numberOfCidRecords resolves to
    #   • allCidRecordWorkArea.numberOfCidRecords  (terminal, 0 setters)
    #   • allCidRecords.numberOfCidRecords          (1 setter @ dw780000:220)
    #   • a plain local numberOfCidRecords          (2 setters @ dw780000:302 / dw712000:137)
    # The UI keys cards by the short name, so we build ONE card for the name that
    # represents EVERY entity's setters (each tagged with its `qualified` path) and
    # surfaces the terminal entity's read-site provenance — instead of letting the
    # last-indexed (terminal) namesake hide the setter-having ones.
    entities = trace.depvar_group(name)
    if not entities:
        # No trace entity for this dep var: terminal input placeholder.
        return _build_terminal_input(name)

    # Membership/counterpart for the card: first entity that has either (same-tail
    # entities usually share the logical variable's struct/twin; we take the first
    # populated one). Omitted entirely when no entity resolves any.
    membership: dict = {}
    for _e in entities:
        membership = _membership_fields(_e)
        if membership:
            break

    # Terminal-read provenance from any terminal (setter-less) entity in the group.
    terminal_origins: List[dict] = []
    for e in entities:
        if not (e.get("setters") or []):
            o = _terminal_origin(e)
            if o:
                terminal_origins.append(o)

    # Collect setters across ALL entities, tagging each with its owning entity's
    # qualified path so same-tail entities are not merged into one another. Then
    # CONTENT-DEDUP by (file,line,value): a bare entity (qualified "") and its
    # SELF-qualified twin (qualified == the variable name, e.g. allCidRecords +
    # "allCidRecords") are the SAME variable and carry identical sites — without
    # dedup they double the setter list. Genuinely-distinct entities keep their
    # sites (different file/line/value → no collision). A self-qualified path is
    # normalized to "" (it adds no struct disambiguation); a real struct-prefixed
    # qualified (contains ".") wins over a bare one on a collision.
    seen_sites: Dict[Tuple, int] = {}
    qualified_setters: List[Tuple[str, dict]] = []  # (qualified, raw setter)
    for e in entities:
        raw_q = e.get("qualified") or ""
        qualified = "" if raw_q == name else raw_q   # self-qualified == bare
        for s in e.get("setters") or []:
            loc = s.get("location") or {}
            key = (loc.get("file"), loc.get("startLine"), str(s.get("value")))
            if key in seen_sites:
                j = seen_sites[key]
                if "." in qualified and "." not in qualified_setters[j][0]:
                    qualified_setters[j] = (qualified, qualified_setters[j][1])
                continue
            seen_sites[key] = len(qualified_setters)
            qualified_setters.append((qualified, s))

    if not qualified_setters:
        # No entity in the group has setters → a pure terminal input. Carry the
        # read-site provenance recovered above.
        return _build_terminal_input(name, terminal_origins, membership)

    # Club setters PER (owning-qualified) entity so the setter-having entities stay
    # distinct (a setter on allCidRecords.numberOfCidRecords is NOT the same logical
    # setter as one on the plain local), then number them globally.
    setter_structs: List[dict] = []
    all_setters_for_inquiry: List[dict] = []
    idx = 0
    by_qualified: "OrderedDict[str, List[dict]]" = OrderedDict()
    for qualified, s in qualified_setters:
        by_qualified.setdefault(qualified, []).append(s)
    for qualified, ent_setters in by_qualified.items():
        all_setters_for_inquiry.extend(ent_setters)
        clubs = _club_setters(ent_setters, fnindex)
        for key, members in clubs.items():
            idx += 1
            st = _build_setter_struct(key, members, idx, trace, fnindex, max_paths)
            st["id"] = f"{name}-setter-{idx}"
            # Label the setter with its entity's qualified path so the UI can show
            # WHICH same-tail entity this setter mutates (empty when unambiguous).
            st["qualified"] = qualified
            setter_structs.append(st)

    inquiry = _build_inquiry_path_for_depvar(all_setters_for_inquiry, trace, fnindex)

    out = {
        "variable": name,
        "business_name": "",
        "description": _empty_bt(),
        "inquiry_path": inquiry,
        "setters": setter_structs,
        "dependent_variables": [],
    }
    if terminal_origins:
        out["terminal_origins"] = terminal_origins
    out.update(membership)   # member_of / counterpart only when present
    return out


# Manual, explicit per-variable setter ordering pins (curator choice, NOT a
# data-derived rule). Keyed by variable name → the location-prefix of the setter
# to surface FIRST. Easy to extend/remove.
_PINNED_FIRST_SETTER = {
    "softCardValue": "dw780000.cpp:368",
}


def build_variable_struct(name: str, *, is_root: bool, trace: Trace,
                          fnindex: FunctionIndex, max_paths: int = 6) -> dict:
    """Build the structural dict for one variable and validate it.

    Returns a plain dict that validates against models.VariableTable (has setters)
    or models.TerminalInputTable (terminal input, setters == []). Raises on
    validation mismatch.
    """
    if is_root:
        struct = _build_root_struct(name, trace, fnindex, max_paths)
    else:
        struct = _build_depvar_struct(name, trace, fnindex, max_paths)

    # Validate before returning.
    if struct.get("terminal") is True and not struct.get("setters"):
        models.TerminalInputTable.model_validate(struct)
    else:
        models.VariableTable.model_validate(struct)
    return struct


# --------------------------------------------------------------------------- #
# Clickable dep-var collection.
# --------------------------------------------------------------------------- #


def collect_clickable_depvars(root_struct: dict) -> List[str]:
    """Raw variable names referenced as clickable in the root struct.

    Gathers every condition-row dependent_variables[].id and every
    setter.dependent_variables[].variable, de-duplicated, preserving first-seen
    order."""
    seen: "OrderedDict[str, None]" = OrderedDict()

    def _walk_conditions(conds: List[dict]):
        for c in conds or []:
            for dv in c.get("dependent_variables", []) or []:
                vid = dv.get("id")
                if vid and vid not in seen:
                    seen[vid] = None
            # OR-group leaves.
            for leaf in c.get("any", []) or []:
                _walk_conditions([leaf])

    # Variable-level inquiry path.
    for fstep in (root_struct.get("inquiry_path") or {}).get("files", []):
        _walk_conditions(fstep.get("conditions", []))

    # Variable-level dependent_variables union.
    for dv in root_struct.get("dependent_variables", []) or []:
        v = dv.get("variable")
        if v and v not in seen:
            seen[v] = None

    for setter in root_struct.get("setters", []) or []:
        for dv in setter.get("dependent_variables", []) or []:
            v = dv.get("variable")
            if v and v not in seen:
                seen[v] = None
        for path in setter.get("paths", []) or []:
            for fstep in path.get("files", []) or []:
                _walk_conditions(fstep.get("conditions", []))
                # merged multi-site setter step: each site's own conditions
                for site in fstep.get("sites", []) or []:
                    _walk_conditions(site.get("conditions", []))

    return list(seen.keys())
