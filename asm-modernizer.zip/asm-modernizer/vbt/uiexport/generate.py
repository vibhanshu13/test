"""vbt.uiexport.generate — CLI orchestrator for the trace → UI-JSON pipeline.

Drives the four uiexport layers end-to-end:

    load_trace ──► build_function_index ──► build_variable_struct (structural)
               ──► fill_prose (prose / Gemini, or --no-llm deterministic backfill)
               ──► write_variable_json / write_manifest_js / write_manifest_json (emit)

Usage::

    python -m vbt.uiexport.generate [options]

    # fast contract / UI smoke (no Gemini), single variable:
    python -m vbt.uiexport.generate --no-llm --variables softCardValue \\
        --out-dir /tmp/uiexport_smoke

    # default variable set (root + clickable dep vars):
    python -m vbt.uiexport.generate --no-llm --out-dir /tmp/uiexport_smoke2

Determinism: every emitted file is sorted + indented; the only LLM temperature is
the prose-layer config's (0.01). Same trace + same flags ⇒ same bytes (no
Date.now / random anywhere in the emitted artefacts).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import List, Optional

from vbt.uiexport import models
from vbt.uiexport.cache import ProseCache
from vbt.uiexport.emit import (
    write_manifest_js,
    write_manifest_json,
    write_variable_json,
)
from vbt.uiexport.prose import fill_prose
from vbt.uiexport.structural import (
    build_function_index,
    build_variable_struct,
    collect_clickable_depvars,
    load_trace,
    load_trace_dict,
)

# The fixed entry chain every variable rides on (same as the live API task).
_FIXED_CHAIN = [
    ("aa71", "asm", None),
    ("dw730000", "cpp", "DW73"),
    ("dw710000", "cpp", "callPlasticAuthenticationComponentInterface"),
]

# asm-modernizer repo root = three parents up from this file
# (<root>/vbt/uiexport/generate.py).
_REPO_ROOT = Path(__file__).resolve().parents[2]

_DEFAULT_TRACE_DIR = _REPO_ROOT / "vbt" / "trace_softCardValue_d3"
_DEFAULT_OUT_DIR = Path(
    "/Users/prathamgupta/Documents/Zenflow_Frontend/src/api/mocks/generated"
)
_DEFAULT_CACHE_DIR = _REPO_ROOT / "vbt" / ".cache" / "uiexport_prose"


# --------------------------------------------------------------------------- #
# Helpers.
# --------------------------------------------------------------------------- #


def _log(msg: str) -> None:
    print(msg, file=sys.stderr)


def _dedup_preserve(seq: List[str]) -> List[str]:
    seen = set()
    out: List[str] = []
    for x in seq:
        if x and x not in seen:
            seen.add(x)
            out.append(x)
    return out


def _root_name(trace) -> str:
    """The root variable's raw name (should be ``softCardValue``)."""
    rv = trace.root.get("rootVariable") if isinstance(trace.root, dict) else None
    if isinstance(rv, dict) and rv.get("name"):
        return rv["name"]
    return trace.root.get("variable") if isinstance(trace.root, dict) else None


def _all_depvar_stems(trace_dir: Path) -> List[str]:
    """Every dependentVariables/*.json stem in the trace, sorted for determinism."""
    dep_dir = Path(trace_dir) / "dependentVariables"
    if not dep_dir.is_dir():
        return []
    return sorted(p.stem for p in dep_dir.glob("*.json"))


def _resolve_variable_list(
    args: argparse.Namespace,
    root: str,
    root_struct: dict,
    trace_dir: Path,
) -> List[str]:
    """Compute the ordered, deduped variable list (root first)."""
    if args.variables:
        names = [v.strip() for v in args.variables.split(",") if v.strip()]
    elif args.all_depvars:
        names = [root] + _all_depvar_stems(trace_dir)
    else:
        names = [root] + collect_clickable_depvars(root_struct)
    # Root must lead; dedup preserves order.
    return _dedup_preserve([root] + names)


def _validate_payload(payload: dict) -> None:
    """Validate against the right top-level model (mirrors prose._validate)."""
    if not payload.get("setters"):
        # No setters surfaced. A terminal-input payload is identified by
        # terminal=True; otherwise a setter-less VariableTable still validates.
        if payload.get("terminal") is True:
            models.TerminalInputTable.model_validate(payload)
            return
    models.VariableTable.model_validate(payload)


# --------------------------------------------------------------------------- #
# Core run.
# --------------------------------------------------------------------------- #


def reorder_dependent_variables(out_dir) -> int:
    """Order each variable's dependent_variables across the generated set:
      Rule 1 (supersedes): variables that themselves HAVE setter sites come first.
      Rule 2:              value_logic dep vars come before reachability ones.
    Stable within ties. `has_setters` is derived from each dep var's OWN generated
    file (a non-terminal table with setters) — so this cross-references the dir.
    Returns the number of files rewritten.
    """
    import glob
    out_dir = Path(out_dir)
    files = [f for f in glob.glob(str(out_dir / "*.json")) if os.path.basename(f) != "manifest.json"]
    has_setters: dict = {}
    docs: dict = {}
    for f in files:
        try:
            d = json.load(open(f))
        except Exception:
            continue
        docs[f] = d
        name = os.path.basename(f)[:-5]
        has_setters[name] = (d.get("terminal") is not True) and bool(d.get("setters"))

    def _key(dv):
        hs = has_setters.get(dv.get("variable"), False)
        vl = dv.get("dependency_type") == "value_logic"
        return (0 if hs else 1, 0 if vl else 1)

    def _sorted(lst):
        for dv in lst:
            dv["has_setters"] = has_setters.get(dv.get("variable"), False)
        return sorted(lst, key=_key)  # stable → preserves first-seen within ties

    n = 0
    for f, d in docs.items():
        touched = False
        if d.get("dependent_variables"):
            d["dependent_variables"] = _sorted(d["dependent_variables"])
            touched = True
        for s in d.get("setters", []) or []:
            if s.get("dependent_variables"):
                s["dependent_variables"] = _sorted(s["dependent_variables"])
                touched = True
        if touched:
            with open(f, "w") as fh:
                json.dump(d, fh, indent=2, ensure_ascii=False, sort_keys=False)
            n += 1
    return n


def run(args: argparse.Namespace) -> int:
    trace_dir = Path(args.trace_dir).resolve()
    out_dir = Path(args.out_dir)
    cache_dir = Path(args.cache_dir)

    # Engine scale caps (LIVE only) — distinct from the uiexport --max-paths (a UI
    # paths-per-setter cap). --unlimited lifts the ENGINE caps to the uncapped values
    # from vbt/UNLIMITED_TRACE_softCardValue.md so the full setter/route set is found.
    _cap_kwargs = {}
    if getattr(args, "unlimited", False):
        _cap_kwargs = {
            "max_paths": 512,          # engine: intra-file call paths per setter (default 64)
            "max_routes": 2000,        # cross-file routes tail→setter (default 200)
            "max_route_len": 32,       # route hop-length (default 16)
            "max_call_depth": 32,      # edges deep in intra-file path enum (default 16)
            "max_offchain_files": 1000,# off-chain files route-checked per dep var (default 100)
            "asm_max_levels": 32,      # N-level ASM backward-CFG (default 16)
        }
        _log(f"[uiexport.generate] UNLIMITED engine caps: {_cap_kwargs}")

    _log(f"[uiexport.generate] trace_dir={trace_dir}")
    _log(f"[uiexport.generate] out_dir={out_dir}")
    _log(
        f"[uiexport.generate] mode={'no-llm (deterministic)' if args.no_llm else 'llm (gemini)'}"
        f"  force={args.force}  max_paths={args.max_paths}"
    )

    # 1-3. Build a per-variable struct builder. Either read a pre-baked trace dir,
    #      or trace each variable LIVE from the kb (the SAME engine path the API
    #      uses, so mock JSON == API payload + picks up engine fixes like asmTest).
    if args.live and args.independent:
        # INDEPENDENT mode: trace EACH variable as its own root with
        # disable_dependents=True — exactly the live API's cold-start path. This
        # avoids the dep-var recursion entirely (so it is unaffected by in-progress
        # recurse.py work) and makes mock == API per variable. Traces are memoized
        # so the root is not re-traced when it appears in its own variable list.
        from vbt.engine import Hop, trace_root_variable

        bp = Path(args.blueprint_dir).resolve()
        asm = Path(args.asm_dir).resolve() if args.asm_dir else None
        graph = Path(args.graph_file).resolve()
        chain = [Hop(s, t, fn) for (s, t, fn) in _FIXED_CHAIN]
        root = (args.variables.split(",")[0].strip() if args.variables else "softCardValue")
        _log(
            f"[uiexport.generate] LIVE INDEPENDENT trace (disable_dependents=True), "
            f"root={root!r}  blueprint_dir={bp}  asm_dir={asm}"
        )
        _trace_cache: dict = {}

        def _trace_one(name: str):
            if name not in _trace_cache:
                _log(f"[uiexport.generate]   tracing {name!r} as its own root ...")
                out = trace_root_variable(
                    name, "cpp", chain,
                    blueprint_dir=bp, asm_dir=asm, graph_file=graph,
                    disable_dependents=True, progress=args.unlimited or None,
                    **_cap_kwargs,
                )
                t = load_trace_dict(out)
                _trace_cache[name] = (t, build_function_index(t.code_blocks))
            return _trace_cache[name]

        def make_struct(name: str, is_root: bool) -> dict:
            t, fnidx = _trace_one(name)
            return build_variable_struct(
                name, is_root=is_root, trace=t, fnindex=fnidx, max_paths=args.max_paths
            )
    elif args.live:
        from vbt.engine import Hop, trace_root_variable

        bp = Path(args.blueprint_dir).resolve()
        asm = Path(args.asm_dir).resolve() if args.asm_dir else None
        graph = Path(args.graph_file).resolve()
        chain = [Hop(s, t, fn) for (s, t, fn) in _FIXED_CHAIN]
        root = (args.variables.split(",")[0].strip() if args.variables else "softCardValue")
        _log(
            f"[uiexport.generate] LIVE depth-{args.dep_depth} trace of {root!r}  "
            f"blueprint_dir={bp}  asm_dir={asm}"
        )
        # ONE depth-N trace of the root (root setters + the dep-var tree), then
        # build root + each clickable dep var from it — same flow as the trace-dir
        # path, but sourced live (new engine → asmTest/asmBranch + compare anchoring).
        out = trace_root_variable(
            root, "cpp", chain,
            blueprint_dir=bp, asm_dir=asm, graph_file=graph,
            max_dep_var_depth=args.dep_depth, progress=args.unlimited or None,
            **_cap_kwargs,
        )
        trace = load_trace_dict(out)
        fnindex = build_function_index(trace.code_blocks)

        def make_struct(name: str, is_root: bool) -> dict:
            return build_variable_struct(
                name, is_root=is_root, trace=trace, fnindex=fnindex, max_paths=args.max_paths
            )
    else:
        trace = load_trace(trace_dir)
        fnindex = build_function_index(trace.code_blocks)
        root = _root_name(trace)
        if not root:
            _log("[uiexport.generate] FATAL: could not determine root variable name.")
            return 2

        def make_struct(name: str, is_root: bool) -> dict:
            return build_variable_struct(
                name, is_root=is_root, trace=trace, fnindex=fnindex, max_paths=args.max_paths
            )

    _log(f"[uiexport.generate] root variable = {root!r}")
    root_struct = make_struct(root, True)
    if args.variables:
        names = [v.strip() for v in args.variables.split(",") if v.strip()]
        variables = _dedup_preserve([root] + names)
    elif args.all_depvars and not args.live:
        variables = _dedup_preserve([root] + _all_depvar_stems(trace_dir))
    else:
        variables = _dedup_preserve([root] + collect_clickable_depvars(root_struct))
    _log(f"[uiexport.generate] {len(variables)} variable(s) to emit (root first).")

    # 4. Prose cache (bypass get on --force; we still pass it so puts happen).
    cache: Optional[ProseCache] = ProseCache(cache_dir)

    # 5. Per-variable: structural → prose → validate → write. One failure does
    #    not abort the batch, but the run exits non-zero if any failed.
    written: List[str] = []
    manifest_entries: List[dict] = []
    failures: List[str] = []
    mode = "no_llm" if args.no_llm else "llm"

    for i, name in enumerate(variables):
        prefix = f"[{i + 1}/{len(variables)}] {name}"
        try:
            is_root = name == root
            # Reuse the already-built root struct; build the rest fresh.
            struct = root_struct if is_root else make_struct(name, False)
            # Hash the PRE-FILL struct for the manifest + cache key.
            struct_hash = ProseCache.struct_hash(struct)

            payload = fill_prose(
                struct,
                variable=name,
                cache=(None if args.force else cache),
                no_llm=args.no_llm,
            )
            _validate_payload(payload)

            path = write_variable_json(out_dir, name, payload)
            written.append(name)
            manifest_entries.append(
                {
                    "variable": name,
                    "file": path.name,
                    "struct_hash": struct_hash,
                    "mode": mode,
                    "llm": not args.no_llm,
                }
            )
            kind = "terminal" if payload.get("terminal") is True else "table"
            n_setters = len(payload.get("setters") or [])
            _log(f"{prefix}: ok ({kind}, {n_setters} setter(s)) -> {path.name}")
        except Exception as exc:  # one bad variable must not sink the batch
            failures.append(name)
            _log(f"{prefix}: FAILED — {type(exc).__name__}: {exc}")

    # 6. Manifests (only over what was actually written).
    if written:
        js_path = write_manifest_js(out_dir, written)
        mj_path = write_manifest_json(out_dir, manifest_entries, trace_dir=str(trace_dir))
        _log(f"[uiexport.generate] wrote {js_path.name} ({len(written)} import(s))")
        _log(f"[uiexport.generate] wrote {mj_path.name}")
        # Reorder each variable's dependent_variables (cross-references the written
        # files): setter-having vars first (Rule 1, supersedes), then value_logic
        # first (Rule 2). Stable within ties.
        n_sorted = reorder_dependent_variables(out_dir)
        _log(f"[uiexport.generate] reordered dependent_variables in {n_sorted} file(s)")
    else:
        _log("[uiexport.generate] nothing written; skipping manifests.")

    # 7. Summary.
    _log("[uiexport.generate] --- summary ---")
    _log(f"[uiexport.generate] generated: {len(written)} / {len(variables)}")
    _log(f"[uiexport.generate] out_dir:   {out_dir}")
    if failures:
        _log(f"[uiexport.generate] FAILURES ({len(failures)}): {', '.join(failures)}")
        return 1
    return 0


# --------------------------------------------------------------------------- #
# CLI.
# --------------------------------------------------------------------------- #


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="python -m vbt.uiexport.generate",
        description=(
            "Generate per-variable Setter-Analysis table JSON fixtures from a VBT "
            "trace directory, plus the generatedSetterTables.js manifest the "
            "Zenflow mock adapter imports."
        ),
    )
    p.add_argument(
        "--trace-dir",
        type=Path,
        default=_DEFAULT_TRACE_DIR,
        help="VBT trace directory (default: vbt/trace_softCardValue_d3 under the repo root).",
    )
    p.add_argument(
        "--out-dir",
        type=Path,
        default=_DEFAULT_OUT_DIR,
        help="Output directory for the generated *.json + manifest files.",
    )
    # --- LIVE mode: trace each variable fresh from the kb (mock == API) --------
    _kb_out = _REPO_ROOT / "jobs" / "37203143-0fa3-46fe-820f-e3c7d1e18e24" / "output"
    p.add_argument(
        "--live",
        action="store_true",
        help="Trace each variable fresh from the kb (engine, disable_dependents) "
             "instead of reading --trace-dir. Mock data becomes identical to the "
             "live API and picks up engine fixes (e.g. asmTest/asmBranch).",
    )
    p.add_argument("--blueprint-dir", type=Path, default=_kb_out,
                   help="LIVE: kb blueprint dir (default: jobs/37203143…/output).")
    p.add_argument("--asm-dir", type=Path,
                   default=_REPO_ROOT / "datasource" / "asm_pipeline_user" / "asm_codebase_version_0",
                   help="LIVE: ASM/C++ source dir.")
    p.add_argument("--graph-file", type=Path, default=_kb_out / "file_call_graph.json",
                   help="LIVE: file_call_graph.json (default: <blueprint-dir>/file_call_graph.json).")
    p.add_argument("--dep-depth", type=int, default=3,
                   help="LIVE: dep-var recursion depth for the root trace (default: 3).")
    p.add_argument(
        "--unlimited",
        action="store_true",
        help="LIVE: lift the engine scale caps (max_paths/routes/route_len/call_depth/"
             "offchain_files/asm_levels) to the uncapped values from "
             "UNLIMITED_TRACE_softCardValue.md, so the full setter/route set is found.",
    )
    p.add_argument(
        "--independent",
        action="store_true",
        help="LIVE: trace EACH variable as its own root with disable_dependents=True "
             "(the API's cold-start path). Avoids dep-var recursion entirely and makes "
             "mock == API per variable. Use this when the dep-tree path is unavailable.",
    )
    p.add_argument(
        "--variables",
        type=str,
        default=None,
        help="Comma-separated variable list (default: root + clickable dep vars).",
    )
    p.add_argument(
        "--all-depvars",
        action="store_true",
        help="Expand to root + every dependentVariables/*.json stem in the trace.",
    )
    p.add_argument(
        "--no-llm",
        action="store_true",
        help="Structural + deterministic prose backfill only (no Gemini). Fast smoke.",
    )
    p.add_argument(
        "--force",
        action="store_true",
        help="Ignore the prose cache (always re-fill).",
    )
    p.add_argument(
        "--cache-dir",
        type=Path,
        default=_DEFAULT_CACHE_DIR,
        help="Prose cache directory (default: vbt/.cache/uiexport_prose under the repo root).",
    )
    p.add_argument(
        "--max-paths",
        type=int,
        default=6,
        help="Max paths kept per setter (default: 6).",
    )
    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = _build_parser().parse_args(argv)
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
