"""Build the SUMMARY view JSON for a VBT trace — SPEC: explain *how a variable
gets set and under what conditions* for a NON-technical product person.

Design contract (the product owner's words):
  • "Wear the hat of the product guy": the reader must see, clearly, IN WHAT
    CONDITION the variable is set TO WHAT VALUE.
  • NO intermediate variable names in the primary reading; REAL values everywhere
    (the enum a condition compares against, the outcome value) kept VERBATIM, and
    the root variable name kept VERBATIM.
  • Use the DEPENDENT-VARIABLE SETTER logic (the deep VBT recursion) to *ground*
    each condition: a condition like "the card was swiped" carries WHY/HOW it
    became true (the dep-var's own value logic), pushing the explanation down
    toward real inputs.

Output (one object):
  • root variable + what-it-is + DISTINCT values (count + list, verbatim);
  • one BOX per setter-site FILE, counted by distinct (file,line) sites (NOT by
    route multiplicity — the trace repeats each assignment once per route);
  • each box = a DECISION TREE rendered as nested when→then rules + stripped
    pseudo-code (no repeated prefixes, no noise lines);
  • EDGES carrying the cumulative cross-file conditions to REACH each box;
  • every condition: plain sentence + real value(s) + a `decided_by` grounding
    drawn from the referenced dep-var's setters.

This follows the decision-table / progressive-disclosure best practice for
explaining conditional logic to business users. Nothing is fabricated: unknown
predicates fall back to a literal cleanup; grounding is omitted when the dep-var
trace has nothing matching.

Usage:
    python -m vbt.uiexport.build_summary \
        --trace vbt/trace_softCardValue_d3/rootVariable.json \
        --out   vbt/uiexport/out/softCardValue.summary.json
"""
from __future__ import annotations

import argparse
import json
import re
from collections import Counter, OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from vbt.uiexport.summary_glossary import (
    GLOSSARY,
    humanize_condition,
    humanize_value,
    real_value_in,
    variable_codes_in,
    var_business_name,
    var_what_it_is,
    box_business_name,
    box_summary,
    value_family,
    condition_kind,
    glossary_terms,
)

# Grounding ("decided_by") is OFF: the dep-var recursion bottoms out in loop /
# buffer / memcmp internals that mean nothing to a product person. The dep-var
# knowledge is baked into the plain-language CONDITION translations instead.
EMIT_GROUNDING = False
MAX_GROUND_DEPTH = 2          # how deep dep-var grounding recurses (if enabled)
MAX_GROUND_CONDS = 4          # plain conditions shown per grounding


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip())


# --------------------------------------------------------------------------- #
# Trace loading
# --------------------------------------------------------------------------- #
def load_trace(path: Path) -> Dict[str, Any]:
    data = json.loads(path.read_text())
    return data.get("rootVariable", data)


def _loc_str(c: Dict[str, Any]) -> str:
    loc = c.get("location") or {}
    f = (loc.get("file") or "").rsplit("/", 1)[-1]
    ln = loc.get("startLine")
    return f"{f}:{ln}" if ln is not None else f


def _loc_file(c: Dict[str, Any]) -> str:
    return ((c.get("location") or {}).get("file") or "").rsplit("/", 1)[-1]


# --------------------------------------------------------------------------- #
# Dependent-variable index — the deep recursion. var name → its setters, so a
# condition referencing a dep-var can be grounded in HOW that dep-var is set.
# --------------------------------------------------------------------------- #
class DepVarIndex:
    def __init__(self, trace_path: Path):
        self.by_name: Dict[str, List[Dict[str, Any]]] = {}
        self.terminal: set = set()
        dvdir = trace_path.parent / "dependentVariables"
        if not dvdir.is_dir():
            return
        for f in dvdir.glob("*.json"):
            try:
                dv = json.loads(f.read_text()).get("dependentVariable", {})
            except Exception:
                continue
            name = dv.get("name")
            if not name:
                continue
            self.by_name[name] = dv.get("setters") or []
            if dv.get("terminal"):
                self.terminal.add(name)

    def ground(self, var_code: str, compared_value: str, depth: int) -> Optional[Dict[str, Any]]:
        """Why is `var_code` equal to `compared_value`? Return a compact plain
        explanation from that variable's own value-logic conditions."""
        if depth <= 0 or not var_code or not compared_value:
            return None
        setters = self.by_name.get(var_code)
        if not setters:
            return None
        member = compared_value.split("::")[-1].strip()
        matched = [s for s in setters
                   if member and member in (s.get("value") or "")]
        if not matched:
            return None
        # Use the value-logic (setter-local, via=None) conditions of the first
        # couple of matching sites — those are "why this value", not "how we got
        # to the file" (reachability).
        plains: List[Dict[str, Any]] = []
        seen = set()
        for s in matched:
            for c in (s.get("conditions") or []):
                if c.get("via"):
                    continue  # reachability, not value-logic
                raw = (c.get("condition") or "").strip()
                k = _norm(raw)
                if not raw or k in seen:
                    continue
                seen.add(k)
                sub_vars = variable_codes_in(raw)
                sub = None
                if depth - 1 > 0:
                    for sv in sub_vars:
                        rv = real_value_in(raw)
                        g = self.ground(sv, rv, depth - 1) if rv else None
                        if g:
                            sub = g
                            break
                plains.append({
                    "plain": humanize_condition(raw),
                    "value": real_value_in(raw),
                    "decided_by": sub,
                })
                if len(plains) >= MAX_GROUND_CONDS:
                    break
            if len(plains) >= MAX_GROUND_CONDS:
                break
        if not plains:
            return None
        return {
            "variable_business_name": var_business_name(var_code) or var_code,
            "value": compared_value,
            "value_business": humanize_value(compared_value),
            "when": plains,
            "sites": [_loc_str_setter(s) for s in matched[:3]],
        }


def _loc_str_setter(s: Dict[str, Any]) -> str:
    loc = s.get("location") or {}
    f = (loc.get("file") or "").rsplit("/", 1)[-1]
    return f"{f}:{loc.get('startLine')}"


def _mk_cond(c: Dict[str, Any], depidx: Optional[DepVarIndex]) -> Dict[str, Any]:
    raw = (c.get("condition") or "").strip()
    value = real_value_in(raw)
    decided = None
    if EMIT_GROUNDING and depidx is not None:
        for code in variable_codes_in(raw):
            g = depidx.ground(code, value, MAX_GROUND_DEPTH)
            if g:
                decided = g
                break
    return {
        "raw": raw,
        "plain": humanize_condition(raw),
        "value": value,
        "loc": _loc_str(c),
        "via": c.get("via") or None,
        "kind": condition_kind(raw),
        "decided_by": decided,
    }


# --------------------------------------------------------------------------- #
# Site grouping (distinct (file,line); keep richest representative)
# --------------------------------------------------------------------------- #
def group_sites(setters: List[Dict[str, Any]]):
    rep: "OrderedDict[Tuple[str,int], Dict[str,Any]]" = OrderedDict()
    counts: Counter = Counter()
    for s in setters:
        loc = s.get("location") or {}
        key = ((loc.get("file") or "").rsplit("/", 1)[-1], loc.get("startLine"))
        counts[key] += 1
        cur = rep.get(key)
        if cur is None or len(s.get("conditions") or []) > len(cur.get("conditions") or []):
            rep[key] = s
    return rep, counts


# --------------------------------------------------------------------------- #
# Decision tree — group per-site discriminators by common prefix so each
# condition is stated once (kills the repeated cumulative prefix).
# Node: {cond, value, value_business, site, children:[...]}.  A node with
# cond=None and a value is a terminal leaf at the current level.
# --------------------------------------------------------------------------- #
def _tree_insert(nodes: List[Dict], conds: List[Dict], leaf: Dict):
    if not conds:
        nodes.append({"cond": None, "value": leaf["value"],
                      "value_business": leaf["value_business"], "site": leaf["site"],
                      "children": []})
        return
    first, rest = conds[0], conds[1:]
    key = _norm(first["raw"])
    node = next((n for n in nodes if n["cond"] and _norm(n["cond"]["raw"]) == key), None)
    if node is None:
        node = {"cond": first, "value": None, "value_business": None,
                "site": None, "children": []}
        nodes.append(node)
    _tree_insert(node["children"], rest, leaf)


def _extract_gate(nodes: List[Dict]) -> Tuple[List[Dict], List[Dict]]:
    """Peel the leading single-condition chain into a shared 'gate' (conditions
    common to every rule), stopping once the tree actually branches."""
    gate = []
    while (len(nodes) == 1 and nodes[0]["cond"] is not None
           and nodes[0]["value"] is None and _has_branch(nodes[0]["children"])):
        gate.append(nodes[0]["cond"])
        nodes = nodes[0]["children"]
    return gate, nodes


def _has_branch(nodes: List[Dict]) -> bool:
    """True unless this level is a single terminal leaf (don't over-peel)."""
    return not (len(nodes) == 1 and nodes[0]["cond"] is None)


def render_pseudocode(var: str, gate: List[Dict], nodes: List[Dict]) -> str:
    lines: List[str] = []
    if gate:
        lines.append("# first, all of these must hold:")
        for c in gate:
            lines.append(f"require  {_pc_cond(c)}")
        lines.append("")
    lines += _render_nodes(var, nodes, 0)
    return "\n".join(lines)


def _pc_cond(c: Dict) -> str:
    v = f"   [{c['value']}]" if c.get("value") else ""
    return f"{c['plain']}{v}"


def _render_nodes(var: str, nodes: List[Dict], depth: int) -> List[str]:
    ind = "    " * depth
    out: List[str] = []
    branch_i = 0
    for n in nodes:
        if n["cond"] is None:  # terminal leaf
            kw = "else: " if branch_i > 0 else ""
            if kw:
                out.append(f"{ind}else:")
                out.append(f"{ind}    set {var} = {n['value_business']}   [{n['value']}]")
            else:
                out.append(f"{ind}set {var} = {n['value_business']}   [{n['value']}]")
        else:
            kw = "if" if branch_i == 0 else "elif"
            out.append(f"{ind}{kw} {_pc_cond(n['cond'])}:")
            child_lines = _render_nodes(var, n["children"], depth + 1)
            out += child_lines
            branch_i += 1
    return out


def _compute_reach(all_tuples: List[Dict[str, Any]], technical: "OrderedDict"):
    """Route-aware cross-file reach. There are usually MULTIPLE routes to a file;
    a condition required on one route is NOT required on all. So:
      • `always`  = intersection of the BUSINESS via-conditions across every route
                    (truly required to reach here, on any path) — a sound AND.
      • `varies`  = business via-conditions present on some routes but not all
                    (route-specific — only one route's set applies per transaction).
      • route_count = number of distinct business reach-condition SIGNATURES
                    (distinct condition-paths; counts within-file switch branches,
                    unlike a file-chain count).
    Plumbing via-conditions are stashed into `technical` (shared footnote)."""
    route_sets: List[set] = []
    ordered: "OrderedDict[str, Dict[str, Any]]" = OrderedDict()  # raw -> cond (first seen)
    for s in all_tuples:
        biz_keys = set()
        for c in (s.get("conditions") or []):
            if not c.get("via"):
                continue
            mc = _mk_cond(c, None)
            if mc["kind"] == "plumbing":
                k = _norm(mc["raw"])
                if k not in technical:
                    technical[k] = {"plain": mc["plain"], "value": mc["value"]}
                continue
            k = _norm(mc["raw"])
            biz_keys.add(k)
            ordered.setdefault(k, mc)
        route_sets.append(biz_keys)
    inter = set.intersection(*route_sets) if route_sets else set()

    # Dedup by PLAIN text (raws can differ only by operator spacing) and route any
    # condition we couldn't translate cleanly into the technical footnote.
    def collect(keys):
        out, seen = [], set()
        for k, c in ordered.items():
            if k not in keys or c["plain"] in seen:
                continue
            if not _is_clean_plain(c["plain"]):
                tk = _norm(c["raw"])
                technical.setdefault(tk, {"plain": c["plain"], "value": c["value"]})
                continue
            seen.add(c["plain"]); out.append(c)
        return out

    always = collect(inter)
    varies = collect(set(ordered) - inter)
    # route_count = number of DISTINCT business reach-condition signatures (the
    # genuinely-distinct condition-paths to here) — NOT distinct file chains,
    # which undercounts within-file switch branches (e.g. transaction types).
    route_count = len({frozenset(rs) for rs in route_sets}) or 1
    return always, varies, route_count


_TECH_MARKERS = ("equals", "::", "NOT (", "memcmp", " and (")


def _is_clean_plain(plain: str) -> bool:
    """A plain string is business-clean only if no raw/technical residue leaked
    through (un-translated enum ``::``, fallback ``equals``/``NOT (`` wording)."""
    return not any(m in plain for m in _TECH_MARKERS)


_NEG = re.compile(r"^!\((.*)\)$", re.S)


def _neg_inner(raw: str):
    m = _NEG.match(_norm(raw))
    return m.group(1).strip() if m else None


def _cond_lhs(raw: str):
    """The left-hand side (variable path) of an ==/!= comparison, or None."""
    inner = _neg_inner(raw) or raw
    parts = re.split(r"==|!=", inner, maxsplit=1)
    return _norm(parts[0]) if len(parts) > 1 else None


def _collapse_else_chains(nodes: List[Dict]) -> List[Dict]:
    """Flatten else-if CASCADES on the same variable. The trace renders
    ``if X==A / else if X==B / else if X==C`` as nested negations
    (``IF X==A`` / ``OR IF !(X==A): IF X==B`` / …) which read confusingly. When a
    negation node ``!(X==A)`` (a) has a positive sibling ``X==A`` and (b) its own
    children branch on the SAME variable X, it is a pure else-link: drop it and
    promote its children to siblings. Binary gates whose else leads to DIFFERENT
    logic (e.g. ``!(cidioReturnCode==NoCidRecord)`` → MatchCidInd checks) are kept."""
    for n in nodes:
        if n.get("children"):
            n["children"] = _collapse_else_chains(n["children"])
    changed = True
    while changed:
        changed = False
        positives = {_norm(c["cond"]["raw"]) for c in nodes
                     if c.get("cond") and _neg_inner(c["cond"]["raw"]) is None}
        out: List[Dict] = []
        for n in nodes:
            cond = n.get("cond")
            inner = _neg_inner(cond["raw"]) if cond else None
            if inner is not None and _norm(inner) in positives:
                neg_var = _cond_lhs(cond["raw"])
                kids = n.get("children") or []
                kid_vars = [_cond_lhs(k["cond"]["raw"]) for k in kids if k.get("cond")]
                if neg_var and kid_vars and all(kv == neg_var for kv in kid_vars):
                    out.extend(kids)
                    changed = True
                    continue
            out.append(n)
        nodes = out
    return nodes


def _flatten_outcomes(gate: List[Dict], nodes: List[Dict]) -> List[Dict[str, Any]]:
    """Walk the decision tree to each leaf, collecting the full IN-FILE condition
    path (gate + ancestor branch conditions) that sets the leaf's value. This is
    the VALUE-centric view: 'softCardValue = X when <these conditions>'."""
    out: List[Dict[str, Any]] = []

    def walk(ns: List[Dict], acc: List[Dict]):
        for n in ns:
            if n["cond"] is None:
                out.append({"value": n["value"], "value_business": n["value_business"],
                            "when": list(gate) + acc})
            else:
                walk(n["children"], acc + [n["cond"]])

    walk(nodes, [])
    return out


def build_box(file_stem: str, sites: List[Tuple[Tuple[str, int], Dict[str, Any]]],
              all_tuples: List[Dict[str, Any]], depidx: Optional[DepVarIndex]):
    file_name = sites[0][0][0]

    func = None
    for _, s in sites:
        for c in s.get("conditions") or []:
            m = re.search(r"cpp:[^:]+:([A-Za-z_]\w*)", c.get("blockId") or "")
            if m and _loc_file(c) == file_name:
                func = m.group(1)
                break
        if func:
            break

    # PLUMBING (pointer/null/work-area/file checks) — implementation detail, kept
    # out of the decision view but shown in a "technical checks" footnote so
    # nothing is silently dropped. Collected from both in-file and reach below.
    technical: "OrderedDict[str, Dict[str, Any]]" = OrderedDict()

    # In-file discriminators (route-INVARIANT local guards) → the decision tree.
    per_site = []
    for (f, ln), s in sites:
        infile = []
        for c in (s.get("conditions") or []):
            if c.get("via"):
                continue
            mc = _mk_cond(c, depidx)
            if mc["kind"] == "plumbing":
                k = _norm(mc["raw"])
                technical.setdefault(k, {"plain": mc["plain"], "value": mc["value"]})
                continue
            infile.append(mc)
        per_site.append({
            "site": f"{f}:{ln}", "line": ln, "value": s.get("value") or "",
            "value_business": humanize_value(s.get("value") or ""),
            "infile": infile,
        })

    tree: List[Dict] = []
    for ps in per_site:
        _tree_insert(tree, ps["infile"],
                     {"value": ps["value"], "value_business": ps["value_business"], "site": ps["site"]})
    gate, branches = _extract_gate(tree)
    branches = _collapse_else_chains(branches)     # flatten else-if cascades
    outcomes = _flatten_outcomes(gate, branches)   # per-VALUE condition path (V2)

    # Route-aware cross-file reach (intersection + route-specific).
    reach_always, reach_varies, route_count = _compute_reach(all_tuples, technical)

    values = list(OrderedDict((ps["value"], ps["value_business"]) for ps in per_site).items())

    return {
        "id": file_stem,
        "file": file_name,
        "function": func,
        "kind": "cpp" if file_name.endswith(".cpp") else "asm",
        "business_name": box_business_name(file_stem, func),
        "summary": box_summary(file_stem),
        "setter_count": len(per_site),
        "values": [{"value": v, "business": b} for v, b in values],
        "reach": reach_always,
        "reach_varies": reach_varies,
        "route_count": route_count,
        "outcomes": outcomes,
        "technical_checks": list(technical.values()),
        "logic": {
            "gate": gate,
            "tree": branches,
            "pseudocode": render_pseudocode("softCardValue", gate, branches),
        },
    }


# --------------------------------------------------------------------------- #
# Edges — each carries the target box's route-aware reach (always-required AND,
# plus route-specific "varies", plus how many routes reach it). NOT incremental:
# with multiple routes the always-set isn't monotonic along the chain, so each
# edge states the full, self-contained, sound reach for its target.
# --------------------------------------------------------------------------- #
def build_edges(boxes: List[Dict[str, Any]]):
    edges = []
    for i, box in enumerate(boxes):
        edges.append({
            "from": "entry" if i == 0 else boxes[i - 1]["id"],
            "to": box["id"],
            "conditions": box["reach"],            # always-required (every route)
            "varies": box.get("reach_varies", []),  # route-specific (only some apply)
            "route_count": box.get("route_count", 1),
        })
    return edges


# --------------------------------------------------------------------------- #
# Main assembly
# --------------------------------------------------------------------------- #
def build_summary(trace_path: Path) -> Dict[str, Any]:
    root = load_trace(trace_path)
    name = root.get("name") or "?"
    setters = root.get("setters") or []
    aliases = root.get("aliases") or []
    depidx = DepVarIndex(trace_path) if EMIT_GROUNDING else None

    qualified = ""
    for s in setters:
        m = re.search(rf"([A-Za-z_][\w.\->]*\.{re.escape(name)})\b", s.get("setterCodeChunk") or "")
        if m:
            qualified = m.group(1).replace("->", ".")
            break

    rep, _ = group_sites(setters)
    by_file: "OrderedDict[str, List]" = OrderedDict()
    for (f, ln), s in rep.items():
        by_file.setdefault(f, []).append(((f, ln), s))

    # ALL tuples per file (not deduped) — needed for route-aware reach.
    all_by_file: "OrderedDict[str, List]" = OrderedDict()
    for s in setters:
        f = (s.get("location") or {}).get("file")
        if f:
            all_by_file.setdefault(f, []).append(s)

    # Earliest position a file appears at across all chains → chain order.
    def chain_pos(f: str) -> int:
        stem = f.rsplit(".", 1)[0]
        best = 10 ** 6
        for s in all_by_file.get(f, []):
            for i, hop in enumerate(s.get("chain") or []):
                if hop == stem:
                    best = min(best, i)
        return best

    boxes = []
    for f, group in by_file.items():
        stem = f.rsplit(".", 1)[0]
        group = sorted(group, key=lambda kv: (kv[0][1] if isinstance(kv[0][1], int) else 0))
        boxes.append(build_box(stem, group, all_by_file.get(f, []), depidx))

    boxes.sort(key=lambda b: chain_pos(b["file"]))  # entry → … → setter order
    edges = build_edges(boxes)

    val_set: "OrderedDict[str, dict]" = OrderedDict()
    for box in boxes:
        for v in box["values"]:
            e = val_set.setdefault(v["value"], {"business": v["business"], "set_in": set()})
            e["set_in"].add(box["id"])
    distinct_values = [
        {"value": v, "business": e["business"], "set_in": sorted(e["set_in"]),
         "family": value_family(v)}
        for v, e in val_set.items()
    ]

    # VALUE-CENTRIC view (Summary V2): one entry per distinct value, listing the
    # WAY(S) it is set (each way = the in-file condition path) + which box/reach.
    values_detail: "OrderedDict[str, dict]" = OrderedDict()
    box_by_id = {b["id"]: b for b in boxes}
    for box in boxes:
        for oc in box["outcomes"]:
            d = values_detail.setdefault(oc["value"], {
                "value": oc["value"], "value_business": oc["value_business"],
                "family": value_family(oc["value"]), "ways": [],
            })
            d["ways"].append({
                "when": oc["when"],
                "box": box["id"], "box_name": box["business_name"],
                "reach": box["reach"], "reach_varies": box.get("reach_varies", []),
                "route_count": box.get("route_count", 1),
            })

    return {
        "variable": name,
        "qualified": qualified,
        "business_name": GLOSSARY.get("root", {}).get("business_name") or name,
        "what_it_is": GLOSSARY.get("root", {}).get("what_it_is") or "",
        "summary": GLOSSARY.get("root", {}).get("summary") or "",
        "aliases": [{"name": a.get("name"), "language": a.get("language")} for a in aliases],
        "distinct_values": {"count": len(distinct_values), "values": distinct_values},
        "values_detail": list(values_detail.values()),
        "glossary": glossary_terms(),
        "boxes": boxes,
        "edges": edges,
        "_provenance": {
            "trace": str(trace_path),
            "total_setter_tuples": len(setters),
            "note": "setter_count per box = distinct (file,line) sites, not route multiplicity",
        },
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trace", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()
    summary = build_summary(args.trace)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(summary, indent=2))
    nb = len(summary["boxes"])
    nv = summary["distinct_values"]["count"]
    print(f"wrote {args.out}: {nb} boxes, {nv} distinct values")


if __name__ == "__main__":
    main()
