"""VBT core data contracts + pluggable-module Protocols.

These are intentionally small and dependency-free so any module can be swapped
without touching the others (constraint #1: modular & pluggable). No kb_id.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Protocol, Sequence

Lang = str  # "asm" | "cpp"


# --------------------------------------------------------------------------- #
# Locations & code blocks
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Location:
    file: str
    start_line: int
    end_line: int


@dataclass
class CodeBlock:
    """An entry in the deduped top-level codeBlocks table.

    block = an ASM block (by id); a C++ function (by qualified name).
    Referenced from setters/conditions by ``block_id`` so code is stored once.
    """
    block_id: str
    file: str
    start_line: int
    end_line: int
    code: str


# --------------------------------------------------------------------------- #
# Cross-language identity
# --------------------------------------------------------------------------- #
@dataclass
class Alias:
    name: str
    language: Lang
    home_stem: Optional[str] = None
    certainty: str = "high"   # we only ever keep "high" (SPEC §7)
    via: Optional[str] = None  # which resolver produced it


@dataclass
class AliasSet:
    """All high-certainty names a logical variable has across languages."""
    canonical: str
    aliases: List[Alias] = field(default_factory=list)

    def names(self) -> List[str]:
        return [self.canonical] + [a.name for a in self.aliases]

    def for_language(self, lang: Lang) -> List[str]:
        return [a.name for a in self.aliases if a.language == lang]


# --------------------------------------------------------------------------- #
# Setters & conditions
# --------------------------------------------------------------------------- #
@dataclass
class SetterSite:
    """A raw site where a variable is written, found in one file."""
    variable: str
    file_stem: str
    language: Lang
    line: int
    instruction: str               # ASM opcode; "assign"/"define" for C++
    block_id: str                  # ASM block id; C++ enclosing function
    value: Optional[str] = None    # RHS / setter_expression
    setter_code_chunk: Optional[str] = None
    constant_source: bool = False
    prior_value_required: bool = False   # RMW (e.g. OI) → prior value is a dep var
    role: Optional[str] = None
    flipc_alias_of: Optional[str] = None
    hardware_source: Optional[str] = None
    function: Optional[str] = None       # C++ enclosing function (== block_id)
    is_declaration: bool = False
    # GAP 9 (not-set outcomes): a virtual setter representing a path on which the variable
    # is NOT written. ``is_not_set`` marks it (forwarded to the output as ``isNotSet``);
    # ``preset_conditions`` carries its intra-function guards verbatim (the negation of the
    # real setters' reaching conditions), so the engine uses them instead of recomputing via
    # ``collect_cpp_conditions`` at the (synthetic) line. None on every real, discovered setter.
    preset_conditions: Optional[List["Condition"]] = None
    is_not_set: bool = False


@dataclass
class Condition:
    """One guard that must hold to reach a site, polarity-resolved."""
    order: int
    condition: str                 # source/human predicate (polarity applied)
    block_id: str                  # ref into codeBlocks table
    location: Location
    polarity: Optional[bool] = None  # True = predicate holds, False = negated
    raw_test: Optional[str] = None   # ASM: "CLC WK_RRC,ZEROS"
    raw_branch: Optional[str] = None # ASM: "BNE DA7_0900"
    kind: Optional[str] = None       # cpp: if|switch|loop|ternary|early_exit


# --------------------------------------------------------------------------- #
# Pluggable module Protocols
# --------------------------------------------------------------------------- #
class NameResolver(Protocol):
    def resolve(self, variable: str, language: Lang) -> AliasSet: ...


class SetterFinder(Protocol):
    def find(self, alias_set: AliasSet, stem: str) -> List[SetterSite]: ...


class ConditionCollector(Protocol):
    def collect(self, site: SetterSite, *, before_line: Optional[int] = None) -> List[Condition]: ...
