"""Assemble the rootVariable / dependentVariable JSON (SPEC §8).

One entry per (setter, chain). Code lives once in the top-level ``codeBlocks`` table;
setters and conditions reference it by ``blockId``.
"""
from __future__ import annotations

from typing import Any, Dict, List

from vbt.output.codeblocks import CodeBlockStore

# The core fields every setter entry always carries. Anything ELSE the engine put
# on the entry is a SURFACED limitation/completeness flag (pathsCapped,
# reachableOnlyViaUnverified, unverifiedCallSites, and any future addition) and MUST
# be forwarded — rebuilding the entry field-by-field previously dropped pathsCapped /
# reachableOnlyViaUnverified, silently breaking the "truncation is always surfaced"
# promise. Forwarding non-core keys generically guarantees no flag is lost here again.
_CORE_FIELDS = frozenset({
    "value", "valueResolved", "setterCodeChunk", "location", "chain",
    "unconditionalAtSetter", "conditions", "dependentVariables",
})


def build_root_output(variable: str, setter_entries: List[Dict[str, Any]],
                      store: CodeBlockStore,
                      dependent_variables: List[Dict[str, Any]] | None = None) -> Dict[str, Any]:
    setters = []
    for i, e in enumerate(setter_entries, start=1):
        entry = {
            "setterId": i,
            "value": e.get("value"),
            "valueResolved": e.get("valueResolved"),
            "setterCodeChunk": e.get("setterCodeChunk"),
            "location": e.get("location"),
            "chain": e.get("chain"),
            "unconditionalAtSetter": e.get("unconditionalAtSetter"),
            "conditions": e.get("conditions", []),
            "dependentVariables": e.get("dependentVariables", []),
        }
        # Forward every surfaced flag the engine set (never silently drop one).
        for k, v in e.items():
            if k not in _CORE_FIELDS and k not in entry and v not in (None, False, [], {}):
                entry[k] = v
        setters.append(entry)
    return {
        "rootVariable": {"name": variable, "setters": setters},
        "dependentVariables": dependent_variables or [],
        "codeBlocks": store.as_dict(),
    }
