"""Assemble the rootVariable / dependentVariable JSON (SPEC §8).

One entry per (setter, chain). Code lives once in the top-level ``codeBlocks`` table;
setters and conditions reference it by ``blockId``.
"""
from __future__ import annotations

from typing import Any, Dict, List

from vbt.output.codeblocks import CodeBlockStore

# The core fields every setter entry always carries. Anything ELSE the engine put
# on the entry is a SURFACED limitation/completeness flag (pathsCapped,
# reachableOnlyViaUnverified, unverifiedCallSites, and any future addition) and MUST
# be forwarded — rebuilding the entry field-by-field previously dropped pathsCapped /
# reachableOnlyViaUnverified, silently breaking the "truncation is always surfaced"
# promise. Forwarding non-core keys generically guarantees no flag is lost here again.
# The convenience fields (setterId/file/line/function/blockId — GAP 6) are also core:
# they are derived deterministically from location/blockId by ``normalize_setter`` and
# must not be re-forwarded as if they were limitation flags.
_CORE_FIELDS = frozenset({
    "setterId", "value", "valueResolved", "setterCodeChunk", "location",
    "file", "line", "function", "blockId", "chain",
    "unconditionalAtSetter", "conditions", "dependentVariables",
})


def _function_from_block_id(block_id: Any) -> str | None:
    """C++ function name from a ``cpp:{stem}:{fn}`` blockId; ``None`` otherwise.

    Namespace-safe: ``split(":", 2)`` keeps qualified names like ``Ns::Class::fn``
    intact (``split(":")[2]`` would truncate at the first ``::``). ASM block ids
    (``asm:{stem}:{block}``) are labels/blocks, not functions, so they yield None."""
    if not isinstance(block_id, str):
        return None
    try:
        kind, _stem, rest = block_id.split(":", 2)
    except ValueError:
        return None
    return (rest or None) if kind == "cpp" else None


def normalize_setter(entry: Dict[str, Any], setter_id: int | None = None) -> Dict[str, Any]:
    """Return a fresh setter dict with the GAP-6 convenience fields populated.

    Serialization-only: ``file``/``line`` mirror ``location.file``/``location.startLine``
    and ``function`` is derived namespace-safely from a C++ ``blockId``. Never reads
    files, recomputes graphs, or overwrites a non-empty caller-supplied convenience
    field (``or`` / ``is not None`` preserve what the caller already set), so the helper
    is idempotent and safe to apply more than once on the same entry."""
    loc = entry.get("location") or {}
    out = dict(entry)
    if setter_id is not None:
        out["setterId"] = setter_id
    out.setdefault("blockId", None)
    out["file"] = out.get("file") or loc.get("file")
    out["line"] = out.get("line") if out.get("line") is not None else loc.get("startLine")
    out["function"] = out.get("function") or _function_from_block_id(out.get("blockId"))
    return out


def normalize_dependent_variable_entry(dv_entry: Dict[str, Any]) -> Dict[str, Any]:
    """Shallow-copy a ``{"dependentVariable": dv}`` object and normalize its setters.

    Shallow-copies ``dv`` (and rebuilds ``setters`` with fresh dicts) so the assembler
    never mutates caller-owned ``dep_objs``; every other dv key is preserved as-is."""
    dv = dict(dv_entry.get("dependentVariable") or {})
    dv["setters"] = [
        normalize_setter(s, i)
        for i, s in enumerate(dv.get("setters") or [], start=1)
    ]
    return {"dependentVariable": dv}


def build_root_output(variable: str, setter_entries: List[Dict[str, Any]],
                      store: CodeBlockStore,
                      dependent_variables: List[Dict[str, Any]] | None = None) -> Dict[str, Any]:
    setters = []
    for i, e in enumerate(setter_entries, start=1):
        entry = {
            "setterId": i,
            "value": e.get("value"),
            "valueResolved": e.get("valueResolved"),
            "setterCodeChunk": e.get("setterCodeChunk"),
            "location": e.get("location"),
            "blockId": e.get("blockId"),
            "chain": e.get("chain"),
            "unconditionalAtSetter": e.get("unconditionalAtSetter"),
            "conditions": e.get("conditions", []),
            "dependentVariables": e.get("dependentVariables", []),
        }
        # Forward every surfaced flag the engine set (never silently drop one).
        for k, v in e.items():
            if k not in _CORE_FIELDS and k not in entry and v not in (None, False, [], {}):
                entry[k] = v
        # GAP 6: derive file/line/function from location/blockId (fresh dict; the
        # original setter_entries are never mutated).
        setters.append(normalize_setter(entry, i))
    return {
        "rootVariable": {"name": variable, "setters": setters},
        # GAP 6: the inline dependent-variable setters carried by the root trace get the
        # same convenience fields. Shallow-copied so caller-owned dep_objs stay untouched.
        "dependentVariables": [
            normalize_dependent_variable_entry(d) for d in (dependent_variables or [])
        ],
        "codeBlocks": store.as_dict(),
    }
