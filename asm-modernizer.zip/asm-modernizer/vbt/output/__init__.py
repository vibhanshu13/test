"""Output assembly: deduped codeBlocks table + rootVariable/dependentVariable JSON."""
