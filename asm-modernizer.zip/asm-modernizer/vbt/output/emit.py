"""Optional output-emit layer for a VBT trace result (SPEC §8 dict).

This is a **post-processing / writer** layer on top of ``build_root_output``: it
NEVER touches the engine or the assembler. Everything here is opt-in — when no
emit options are supplied the caller keeps writing the one fat JSON exactly as
before.

Four orthogonal knobs (all default-off):

* **strip code** (``include_code=False``) — drop the source TEXT (``code`` in
  every ``codeBlocks`` entry, ``setterCodeChunk`` on root + dep-var setters,
  ``relevantCodeChunk`` on dependencies) while keeping every path+line
  REFERENCE. Consumers re-slice the code from ``<asm_dir>/<file>`` lines
  ``startLine..endLine`` (codeBlocks already carries file+lines).
* **split** (``out_dir=...``) — explode the one dict into named parts
  (rootVariable, one file per dependent variable, the shared codeBlocks, an
  index manifest). Reassembling the parts reproduces the original dict.
* **format** (``fmt="msgpack"``) — serialize as msgpack instead of JSON.
* **zip** (``zip_=True``) — pack the part(s) into a single DEFLATED archive.
"""
from __future__ import annotations

import copy
import io
import json
import re
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional

try:                                   # msgpack is an optional output format only
    import msgpack
except ImportError:                    # pragma: no cover - msgpack is in the venv
    msgpack = None


# --------------------------------------------------------------------------- #
# 1. strip_code                                                               #
# --------------------------------------------------------------------------- #
def strip_code(out: Dict[str, Any]) -> Dict[str, Any]:
    """Deep-copy ``out`` with all source TEXT removed but every path+line kept.

    Removed: ``code`` from each ``codeBlocks`` entry; ``setterCodeChunk`` from
    root setters AND dep-var setters; ``relevantCodeChunk`` from dependencies.
    Nothing else is changed (``file``/``startLine``/``endLine`` everywhere stay).
    """
    stripped = copy.deepcopy(out)

    for block in (stripped.get("codeBlocks") or {}).values():
        if isinstance(block, dict):
            block.pop("code", None)

    for setter in ((stripped.get("rootVariable") or {}).get("setters") or []):
        if isinstance(setter, dict):
            setter.pop("setterCodeChunk", None)

    for dv in (stripped.get("dependentVariables") or []):
        inner = dv.get("dependentVariable") if isinstance(dv, dict) else None
        if not isinstance(inner, dict):
            continue
        for dep in (inner.get("dependencies") or []):
            if isinstance(dep, dict):
                dep.pop("relevantCodeChunk", None)
        for setter in (inner.get("setters") or []):
            if isinstance(setter, dict):
                setter.pop("setterCodeChunk", None)

    return stripped


# --------------------------------------------------------------------------- #
# 2. split_output                                                             #
# --------------------------------------------------------------------------- #
_SANITIZE_RE = re.compile(r"[^A-Za-z0-9._-]+")


def _sanitize(name: str) -> str:
    """Filesystem-safe stem for a dependent-variable name (no extension)."""
    safe = _SANITIZE_RE.sub("_", str(name)).strip("._-")
    return safe or "unnamed"


def split_output(out: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """Split the one trace dict into named parts (relpath -> object).

    Parts (relpaths have NO extension; the writer adds ``.json``/``.msgpack``):

    * ``rootVariable``           -> ``{"variable", "rootVariable"}``
    * ``dependentVariables/<n>`` -> each ``out["dependentVariables"][i]`` verbatim
    * ``codeBlocks``             -> the shared ``out["codeBlocks"]`` (kept ONE
                                    shared part to preserve blockId dedup)
    * ``index``                  -> manifest (filled in by ``write_result`` with
                                    fmt/codeIncluded/asmDir/files)

    Reassembling the parts reproduces ``out`` exactly (see ``reassemble``).
    """
    root = out.get("rootVariable") or {}
    variable = root.get("name")
    dep_vars: List[Dict[str, Any]] = out.get("dependentVariables") or []
    code_blocks = out.get("codeBlocks") or {}

    parts: Dict[str, Dict[str, Any]] = {}
    files: List[str] = []

    parts["rootVariable"] = {"variable": variable, "rootVariable": root}
    files.append("rootVariable")

    used: Dict[str, int] = {}
    for dv in dep_vars:
        inner = dv.get("dependentVariable") if isinstance(dv, dict) else None
        name = inner.get("name") if isinstance(inner, dict) else None
        stem = _sanitize(name if name is not None else "unnamed")
        if stem in used:                       # collision -> append an index
            used[stem] += 1
            stem = f"{stem}_{used[stem]}"
        else:
            used[stem] = 0
        rel = f"dependentVariables/{stem}"
        parts[rel] = dv
        files.append(rel)

    parts["codeBlocks"] = code_blocks
    files.append("codeBlocks")

    parts["index"] = {
        "variable": variable,
        "counts": {
            "setters": len(root.get("setters") or []),
            "dependentVariables": len(dep_vars),
            "codeBlocks": len(code_blocks),
        },
        "files": list(files),
    }
    return parts


def reassemble(parts: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """Inverse of ``split_output`` — rebuild the original trace dict.

    Used by tests (and any consumer) to prove the split is lossless. Dependent
    variables are restored in the manifest's ``files`` order so the original
    list ordering is preserved.
    """
    index = parts.get("index") or {}
    # the manifest may carry extensions (after write_result finalizes it); strip
    # one trailing .json/.msgpack so it lines up with the in-memory part keys.
    def _key(rel: str) -> str:
        for ext in (".json", ".msgpack"):
            if rel.endswith(ext):
                return rel[: -len(ext)]
        return rel

    order = [_key(r) for r in index.get("files", [])] or sorted(parts)

    root_part = parts.get("rootVariable") or {}
    dep_vars: List[Dict[str, Any]] = []
    for rel in order:
        if rel.startswith("dependentVariables/") and rel in parts:
            dep_vars.append(parts[rel])

    return {
        "rootVariable": root_part.get("rootVariable", {}),
        "dependentVariables": dep_vars,
        "codeBlocks": parts.get("codeBlocks", {}),
    }


# --------------------------------------------------------------------------- #
# 3. serialize                                                                #
# --------------------------------------------------------------------------- #
def serialize(obj: Any, fmt: str = "json", *, json_indent: Optional[int] = 2) -> bytes:
    """Serialize ``obj`` to bytes as JSON (utf-8, indent=2) or msgpack."""
    if fmt == "json":
        if json_indent is None:
            return json.dumps(obj, separators=(",", ":")).encode("utf-8")
        return json.dumps(obj, indent=json_indent).encode("utf-8")
    if fmt == "msgpack":
        if msgpack is None:                    # pragma: no cover
            raise RuntimeError("msgpack is not installed")
        return msgpack.packb(obj, use_bin_type=True)
    raise ValueError(f"unknown format {fmt!r} (expected 'json' or 'msgpack')")


def _ext(fmt: str) -> str:
    return "json" if fmt == "json" else "msgpack"


# --------------------------------------------------------------------------- #
# 4. write_result                                                             #
# --------------------------------------------------------------------------- #
def write_result(
    out: Dict[str, Any],
    *,
    out_path: Optional[Path] = None,
    out_dir: Optional[Path] = None,
    fmt: str = "json",
    include_code: bool = True,
    zip_: bool = False,
    asm_dir: Optional[Any] = None,
    json_indent: Optional[int] = 2,
) -> str:
    """Emit a trace result; return a short human summary (paths + byte sizes).

    Modes (mutually exclusive on ``out_dir`` vs ``out_path``):

    * **SPLIT** (``out_dir`` given): split into parts; if ``zip_`` write one
      ``<out_dir>.zip`` (or ``out_dir`` itself if it already ends ``.zip``),
      else write ``out_dir/<relpath>.<ext>`` per part. ``asm_dir`` is recorded
      in ``index`` so consumers can resolve relative ``file`` paths.
    * **SINGLE** (``out_path`` given, or neither): serialize the whole dict; if
      ``zip_`` write a zip with one entry, else write the bytes (or to stdout
      when neither ``out_path`` nor ``out_dir`` is given).
    """
    if out_dir is not None and out_path is not None:
        raise ValueError("out_dir and out_path are mutually exclusive")
    if not include_code:
        out = strip_code(out)
    ext = _ext(fmt)

    # ---- SPLIT mode --------------------------------------------------------
    if out_dir is not None:
        parts = split_output(out)
        parts["index"]["format"] = fmt
        parts["index"]["codeIncluded"] = include_code
        if asm_dir is not None:
            parts["index"]["asmDir"] = str(asm_dir)
        # finalize manifest file list with extensions
        parts["index"]["files"] = [f"{rel}.{ext}" for rel in parts["index"]["files"]]

        out_dir = Path(out_dir)
        if zip_:
            zpath = out_dir if out_dir.suffix == ".zip" else out_dir.with_suffix(".zip")
            zpath.parent.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zf:
                for rel, obj in parts.items():
                    zf.writestr(f"{rel}.{ext}", serialize(obj, fmt, json_indent=json_indent))
            return f"wrote {zpath} ({zpath.stat().st_size} bytes, {len(parts)} entries, zip)"

        out_dir.mkdir(parents=True, exist_ok=True)
        total = 0
        for rel, obj in parts.items():
            fpath = out_dir / f"{rel}.{ext}"
            fpath.parent.mkdir(parents=True, exist_ok=True)
            data = serialize(obj, fmt, json_indent=json_indent)
            fpath.write_bytes(data)
            total += len(data)
        return (f"wrote {len(parts)} parts to {out_dir}/ "
                f"({total} bytes total, fmt={fmt}, code={'in' if include_code else 'out'})")

    # ---- SINGLE mode -------------------------------------------------------
    if out_path is not None:
        out_path = Path(out_path)
        if fmt == "json" and not zip_:
            out_path.parent.mkdir(parents=True, exist_ok=True)
            with out_path.open("w", encoding="utf-8") as fh:
                if json_indent is None:
                    json.dump(out, fh, separators=(",", ":"))
                else:
                    json.dump(out, fh, indent=json_indent)
            return f"wrote {out_path} ({out_path.stat().st_size} bytes, fmt=json)"
        data = serialize(out, fmt, json_indent=json_indent)
        if zip_:
            zpath = out_path if out_path.suffix == ".zip" else out_path.with_suffix(".zip")
            entry = (out_path.name if out_path.suffix != ".zip"
                     else f"{out_path.stem}.{ext}")
            zpath.parent.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zf:
                zf.writestr(entry, data)
            return f"wrote {zpath} ({zpath.stat().st_size} bytes, 1 entry, zip)"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(data)
        return f"wrote {out_path} ({len(data)} bytes, fmt={fmt})"

    # stdout (default) — JSON only is human-meaningful; msgpack goes as raw bytes
    data = serialize(out, fmt, json_indent=json_indent)
    if zip_:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(f"result.{ext}", data)
        import sys
        sys.stdout.buffer.write(buf.getvalue())
        return ""
    if fmt == "json":
        print(data.decode("utf-8"))
    else:
        import sys
        sys.stdout.buffer.write(data)
    return ""
