"""Deduped code-block store (SPEC §8).

A *block* is an ASM block (by id) or a C++ function (by name). Code is stored once
under a stable id; setters/conditions reference the id. Source is read lazily and
cached per file so JSON stays small even when many conditions share a function.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional


class CodeBlockStore:
    def __init__(self, asm_dir: Path, shared_src: Optional[Dict[str, List[str]]] = None,
                 job_id: Optional[str] = None):
        self.asm_dir = Path(asm_dir)
        self.blocks: Dict[str, Dict] = {}
        # Multi-chain sharing (vbt_multi_chain_trace_plan §2.A.2): the parsed source-line
        # cache may be SHARED across chains in one coordinator run so a file is read+split
        # once for the whole batch. ``self.blocks`` is NEVER shared (each chain gets a fresh
        # store) so per-chain ``codeBlocks`` stay isolated; only ``_src`` is the shared dict.
        # job_id=None / standalone path passes nothing → behaviour-identical (a fresh dict).
        self._src: Dict[str, List[str]] = shared_src if shared_src is not None else {}
        # GAP 7: when a job's precompute stored the comment-stripped C/C++ variant, prefer
        # it for output code-blocks (so the LLM never sees commented-out legacy code). The
        # manifest presence is checked once per store (tri-state cache below); job_id=None /
        # legacy jobs (no nc manifest) -> raw path -> behaviour identical to pre-GAP-7.
        self.job_id = job_id
        self._nc: Optional[bool] = None          # GAP 7: tri-state cache of "nc available?"

    def _nc_available(self) -> bool:
        # One presence check per store. Legacy jobs (no nc manifest) -> False -> ZERO
        # per-file srcnc lookups -> behaviour identical to pre-GAP-7.
        if self._nc is None:
            self._nc = False
            if self.job_id:
                try:
                    from vbt.precompute.db_artifacts import manifest_present
                    from vbt.precompute.source_nocomments_db import SOURCE_NC_MANIFEST
                    self._nc = manifest_present(self.job_id, SOURCE_NC_MANIFEST)
                except Exception:
                    self._nc = False
        return self._nc

    def _lines(self, filename: str) -> List[str]:
        if filename not in self._src:
            if len(self._src) >= 256:        # OOM guard: whole-file line lists; FIFO, re-read on miss
                self._src.pop(next(iter(self._src)))
            self._src[filename] = self._build_lines(filename)
        return self._src[filename]

    def _build_lines(self, filename: str) -> List[str]:
        import locale
        # GAP 7: prefer the precomputed comment-stripped variant for C/C++ output text.
        # DB read only (no file read). Decode matches the raw path so a fallback is identical.
        if (self.job_id and filename.endswith((".cpp", ".hpp")) and self._nc_available()):
            try:
                import gzip
                from vbt.precompute.db_artifacts import read_blob
                payload = read_blob(self.job_id, f"srcnc:{filename}")
                if payload is not None:
                    return gzip.decompress(payload).decode(
                        locale.getpreferredencoding(False), "replace").splitlines()
            except Exception:
                pass                              # fall through to raw

        # --- unchanged raw path (source_override -> disk) ---
        p = self.asm_dir / filename
        try:
            # T9: serve source from index.db when a source override is installed; decode
            # with the SAME default encoding read_text uses, so .splitlines() is identical.
            from backward_traversal.utils.blueprint_utils import source_override_bytes
            _ov = source_override_bytes(p)
            if _ov is not None:
                return _ov.decode(locale.getpreferredencoding(False), "replace").splitlines()
            return p.read_text(errors="replace").splitlines()
        except OSError:
            return []

    def _slice(self, filename: str, start: int, end: int) -> str:
        lines = self._lines(filename)
        if not lines or not start:
            return ""
        return "\n".join(lines[max(0, start - 1):max(start, end)])

    def chunk(self, filename: str, start: int, end: int) -> str:
        """A small INLINE source slice (not registered as a dedup block) — used for
        a dependency's ``relevantCodeChunk`` (the line[s] where the parent reads it)."""
        return self._slice(filename, start, end)

    def asm_block(self, stem: str, block_id: str, start: int, end: int) -> str:
        bid = f"asm:{stem}:{block_id}"
        if bid not in self.blocks:
            self.blocks[bid] = {
                "file": f"{stem}.asm", "startLine": start, "endLine": end,
                "code": self._slice(f"{stem}.asm", start, end),
            }
        return bid

    def cpp_function(self, stem: str, function: str, start: int, end: int,
                     ext: str = "cpp") -> str:
        bid = f"cpp:{stem}:{function}"
        if bid not in self.blocks:
            self.blocks[bid] = {
                "file": f"{stem}.{ext}", "startLine": start, "endLine": end,
                "code": self._slice(f"{stem}.{ext}", start, end),
            }
        return bid

    def as_dict(self) -> Dict[str, Dict]:
        return self.blocks
