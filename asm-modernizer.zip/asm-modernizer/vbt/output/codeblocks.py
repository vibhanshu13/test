"""Deduped code-block store (SPEC §8).

A *block* is an ASM block (by id) or a C++ function (by name). Code is stored once
under a stable id; setters/conditions reference the id. Source is read lazily and
cached per file so JSON stays small even when many conditions share a function.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional


class CodeBlockStore:
    def __init__(self, asm_dir: Path, shared_src: Optional[Dict[str, List[str]]] = None):
        self.asm_dir = Path(asm_dir)
        self.blocks: Dict[str, Dict] = {}
        # Multi-chain sharing (vbt_multi_chain_trace_plan §2.A.2): the parsed source-line
        # cache may be SHARED across chains in one coordinator run so a file is read+split
        # once for the whole batch. ``self.blocks`` is NEVER shared (each chain gets a fresh
        # store) so per-chain ``codeBlocks`` stay isolated; only ``_src`` is the shared dict.
        # job_id=None / standalone path passes nothing → behaviour-identical (a fresh dict).
        self._src: Dict[str, List[str]] = shared_src if shared_src is not None else {}

    def _lines(self, filename: str) -> List[str]:
        if filename not in self._src:
            if len(self._src) >= 256:        # OOM guard: whole-file line lists; FIFO, re-read on miss
                self._src.pop(next(iter(self._src)))
            p = self.asm_dir / filename
            try:
                # T9: serve source from index.db when a source override is installed; decode
                # with the SAME default encoding read_text uses, so .splitlines() is identical.
                from backward_traversal.utils.blueprint_utils import source_override_bytes
                _ov = source_override_bytes(p)
                if _ov is not None:
                    import locale
                    self._src[filename] = _ov.decode(
                        locale.getpreferredencoding(False), "replace").splitlines()
                else:
                    self._src[filename] = p.read_text(errors="replace").splitlines()
            except OSError:
                self._src[filename] = []
        return self._src[filename]

    def _slice(self, filename: str, start: int, end: int) -> str:
        lines = self._lines(filename)
        if not lines or not start:
            return ""
        return "\n".join(lines[max(0, start - 1):max(start, end)])

    def chunk(self, filename: str, start: int, end: int) -> str:
        """A small INLINE source slice (not registered as a dedup block) — used for
        a dependency's ``relevantCodeChunk`` (the line[s] where the parent reads it)."""
        return self._slice(filename, start, end)

    def asm_block(self, stem: str, block_id: str, start: int, end: int) -> str:
        bid = f"asm:{stem}:{block_id}"
        if bid not in self.blocks:
            self.blocks[bid] = {
                "file": f"{stem}.asm", "startLine": start, "endLine": end,
                "code": self._slice(f"{stem}.asm", start, end),
            }
        return bid

    def cpp_function(self, stem: str, function: str, start: int, end: int,
                     ext: str = "cpp") -> str:
        bid = f"cpp:{stem}:{function}"
        if bid not in self.blocks:
            self.blocks[bid] = {
                "file": f"{stem}.{ext}", "startLine": start, "endLine": end,
                "code": self._slice(f"{stem}.{ext}", start, end),
            }
        return bid

    def as_dict(self) -> Dict[str, Dict]:
        return self.blocks
