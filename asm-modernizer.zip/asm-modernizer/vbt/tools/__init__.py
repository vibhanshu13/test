"""VBT source-repair tools (operate on temp/asm extraction artifacts).

These tools are OPTIONAL, opt-in, and NON-DESTRUCTIVE by default: they propose
and *verify* source fixes for extraction defects that blind the analysis engine
(e.g. brace mis-nesting that truncates a Clang CFG). They never run as part of a
traversal; a human runs them deliberately, reviews the dry-run report, and only
then applies the verified subset with ``--apply``.
"""
