"""Verified source-repair for functions swallowed by a runaway block comment.

WHY
===
The extracted z/TPF C++ (``temp/asm``) sometimes drops the closing ``*/`` of a
``/**`` doc comment, so the comment RUNS ON until the NEXT ``*/`` and SWALLOWS the
function definition(s) in between — making them invisible to BOTH frontends:

  * tree-sitter (modifier index) → the function text lands inside a ``comment`` node,
    so ``files_defining_function`` is empty;
  * Clang LibTooling (cfg_extract) → no ``FunctionDecl`` (it needs a real definition).

Net effect: the function is invisible to every lineage that touches it, and the engine
reports it as ``externalCall``. ``vbt/precompute/source_lint.py`` already DIAGNOSES these
(report at ``process_analysis/swallowed_functions.json``) as ``SwallowedFn`` records — we
reuse its detector READ-ONLY and never re-implement the scan.

Canonical example — ``dw710000.cpp``: a ``/** … #editCidInquiryInputs`` opens at L732
with NO ``*/``; its prose ends ~L741, the ``editCidInquiryInputs`` signature begins at
L743, and the comment wrongly CLOSES at L782 — the ``*/`` that BELONGS to the NEXT doc
comment (``/** … #processCidInquiry`` at L771). So the whole ``editCidInquiryInputs``
body is one big comment.

WHAT
====
For each runaway comment this tool:

  1. PROPOSES a minimal insertion: a ``*/`` on its own line inserted IMMEDIATELY BEFORE
     the FIRST swallowed function's signature line (after the doc-comment prose, before
     the live code begins). This closes the runaway comment so the function(s) become
     live code; the ORIGINAL ``*/`` at ``comment_close_line`` is then expected to close
     the NEXT ``/**`` doc comment that sits between the function and that line. If ONE
     runaway comment swallowed SEVERAL functions, closing before the first makes them
     ALL live.
  2. VERIFIES the candidate by applying it to an in-memory / temp-copy of the file and
     re-checking ALL of:
       * tree-sitter: every swallowed function for that comment now parses as a real
         ``function_definition`` node (no longer inside a ``comment`` node) AND the
         file's total ``function_definition`` count increased by EXACTLY the number
         recovered;
       * block comments balanced: re-running ``source_lint.scan_source_for_swallowed``
         on the repaired text reports those functions as NO LONGER swallowed and
         introduces NO NEW swallowed functions;
       * tree-sitter introduces NO new ERROR/MISSING nodes vs the original;
       * Clang ``cfg_extract`` now emits a FunctionDecl/CFG for each recovered function.
         ``run_cfg_extract`` caches on (path, flags), so we verify against a written
         TEMP-COPY PATH to bust the cache.
  3. REPORTS, per runaway comment, REPAIRABLE (verified, with the exact insertion line)
     or NOT-REPAIRABLE (verification failed + why). DEFAULT is dry-run (print + optional
     JSON). ``--apply`` writes ONLY the verified repairs to the actual ``--asm-dir``.

Under-repairing is correct: a comment whose fix cannot be VERIFIED is left alone. Many
corpus cases are NOT this defect at all — they are functions deliberately commented OUT
by a ``/*Rxxx … } */`` block whose ``*/`` sits AFTER the function's own closing brace
(no intervening ``/**``). Inserting a ``*/`` before such a function leaves the original
``*/`` STRANDED (a stray ``*/`` token → a new tree-sitter ERROR + no Clang recovery), so
verification correctly REJECTS them. A wrong insertion that mis-closes a comment is never
acceptable.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from vbt.cpp_frontend.wrapper import run_cfg_extract
from vbt.precompute.source_lint import SwallowedFn, scan_source_for_swallowed
from vbt.setters.cpp_setters import _parser, _txt

_TS_PARSER = None


@dataclass
class CommentRepair:
    """Repair verdict for ONE runaway comment (which may swallow several functions)."""
    file: str
    comment_open_line: int          # 1-based line where the runaway `/**` opened
    comment_close_line: int         # 1-based line of the `*/` that wrongly closed it
    functions: List[str]            # swallowed function names (in source order)
    function_lines: List[int]       # their signature lines (in source order)
    insert_before_line: int         # where the `*/` is proposed (= first function line)
    repairable: bool
    cfg_recovered: List[str] = field(default_factory=list)   # fns Clang now emits a CFG for
    reason: str = ""                # why NOT repairable (when repairable is False)


# ---------------------------------------------------------------------------
# tree-sitter helpers (function-definition census + swallow check).
# ---------------------------------------------------------------------------
def _ts():
    global _TS_PARSER
    if _TS_PARSER is None:
        _TS_PARSER = _parser()
    return _TS_PARSER


def _fn_def_names(src: bytes) -> List[str]:
    """Every ``function_definition`` name (declarator-chain leaf) in ``src``.

    Counts EACH definition once (duplicates included) so the caller can assert the
    total ``function_definition`` count rose by exactly the number recovered."""
    tree = _ts().parse(src)
    out: List[str] = []
    stack = [tree.root_node]
    while stack:
        n = stack.pop()
        if n.type == "function_definition":
            d = n.child_by_field_name("declarator")
            nm = None
            while d is not None:
                if d.type in ("identifier", "field_identifier", "qualified_identifier",
                              "destructor_name", "operator_name"):
                    nm = _txt(d, src).split("::")[-1].lstrip("*&")
                    break
                d = d.child_by_field_name("declarator")
            out.append(nm or "")
        stack.extend(n.children)
    return out


def _fn_def_count(src: bytes) -> int:
    """Total number of ``function_definition`` nodes in ``src``."""
    tree = _ts().parse(src)
    cnt = 0
    stack = [tree.root_node]
    while stack:
        n = stack.pop()
        if n.type == "function_definition":
            cnt += 1
        stack.extend(n.children)
    return cnt


def _error_count(src: bytes) -> int:
    """Number of ERROR / MISSING nodes in the tree-sitter parse of ``src``."""
    tree = _ts().parse(src)
    cnt = 0
    stack = [tree.root_node]
    while stack:
        n = stack.pop()
        if n.type == "ERROR" or n.is_missing:
            cnt += 1
        stack.extend(n.children)
    return cnt


def _unmatched_comment_closers(text: str) -> int:
    """Count ``*/`` tokens in ``text`` that DO NOT close an open ``/*`` — i.e. stray
    comment closers — using a string/char-literal-aware scan.

    This is the decisive, parser-independent comment-balance check. The corpus has
    files that are ALREADY in a tree-sitter ERROR state, which can MASK a newly-
    stranded ``*/`` so the ERROR-node count doesn't rise (e.g. nm120100's
    ``accessHsmIVR``, a deliberately-commented-out ``/* … } */`` block: inserting a
    ``*/`` before the function leaves the original ``*/`` with no opener). Counting
    unmatched ``*/`` directly catches that, independent of any pre-existing parse
    errors. A correct repair (a genuine runaway ``/**`` whose original ``*/`` belongs
    to the NEXT doc comment) leaves this count UNCHANGED; an unsafe one increases it."""
    i = 0
    n = len(text)
    in_block = in_line = in_str = in_chr = False
    stray = 0
    while i < n:
        c = text[i]
        nxt = text[i + 1] if i + 1 < n else ""
        if in_line:
            if c == "\n":
                in_line = False
            i += 1
            continue
        if in_block:
            if c == "*" and nxt == "/":
                in_block = False
                i += 2
                continue
            i += 1
            continue
        if in_str:
            if c == "\\":
                i += 2
                continue
            if c == '"':
                in_str = False
            i += 1
            continue
        if in_chr:
            if c == "\\":
                i += 2
                continue
            if c == "'":
                in_chr = False
            i += 1
            continue
        # plain code context
        if c == "/" and nxt == "/":
            in_line = True
            i += 2
            continue
        if c == "/" and nxt == "*":
            in_block = True
            i += 2
            continue
        if c == "*" and nxt == "/":
            stray += 1            # a `*/` in code context — no `/*` to close
            i += 2
            continue
        if c == '"':
            in_str = True
            i += 1
            continue
        if c == "'":
            in_chr = True
            i += 1
            continue
        i += 1
    return stray


def _cfg_has_function(cpp_path: str, name: str) -> bool:
    """True iff Clang ``cfg_extract`` emits a FunctionDecl/CFG for ``name`` in
    ``cpp_path``. Runs on the GIVEN path so callers can bust the (path,flags) cache
    by using a freshly-written temp copy."""
    try:
        fns = run_cfg_extract(cpp_path)
    except Exception:
        return False
    for f in fns:
        nm = (f.get("function") or "").split("::")[-1]
        if nm == name:
            return True
    return False


# ---------------------------------------------------------------------------
# Edit application (insert a `*/` on its own line) + temp-copy harness.
# ---------------------------------------------------------------------------
def _apply_insert(text: str, before_line: int) -> str:
    """Insert a ``*/`` on its own line immediately BEFORE 1-based ``before_line``."""
    lines = text.split("\n")
    idx = max(0, min(before_line - 1, len(lines)))
    lines.insert(idx, "*/")
    return "\n".join(lines)


def _cfg_via_tempcopy(orig_path: str, edited_text: str, names: List[str]) -> List[str]:
    """Write ``edited_text`` to a uniquely-named temp copy NEXT TO the original (so its
    sibling-header ``-I <srcdir>`` resolution is identical) and ask Clang which of
    ``names`` now have a CFG — busting ``run_cfg_extract``'s (path, mtime) cache. The
    temp file is cleaned up regardless."""
    src_dir = os.path.dirname(os.path.abspath(orig_path))
    base = os.path.basename(orig_path)
    fd, tmp = tempfile.mkstemp(prefix=f".repair_comments_{base}.", suffix=".cpp",
                               dir=src_dir)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(edited_text)
        return [n for n in names if _cfg_has_function(tmp, n)]
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Verification (all four checks must pass).
# ---------------------------------------------------------------------------
def _verify(orig_text: str, edited_text: str, names: List[str], orig_path: str,
            orig_fn_count: int, orig_err: int, orig_stray: int,
            orig_swallowed: List[SwallowedFn], run_clang: bool = True
            ) -> Tuple[bool, List[str], str]:
    """Return ``(ok, cfg_recovered, reason)`` for an edited file text.

    All four conditions must hold for ``ok``:
      1. tree-sitter: every name in ``names`` now parses as a real
         ``function_definition`` (no longer inside a ``comment``), AND the total
         ``function_definition`` count rose by EXACTLY ``len(names)``.
      2. comments balanced: (a) the inserted ``*/`` strands NO new comment closer —
         i.e. the original ``*/`` at ``comment_close_line`` still has an opener (the
         NEXT doc comment), checked with a literal-aware stray-``*/`` count that does
         NOT depend on tree-sitter's pre-existing error state; AND (b)
         ``source_lint.scan_source_for_swallowed`` on the repaired text reports those
         functions NO LONGER swallowed and introduces NO NEW swallowed function.
      3. NO new tree-sitter ERROR/MISSING nodes vs the original count.
      4. Clang ``cfg_extract`` now emits a FunctionDecl/CFG for EVERY name (verified
         against a temp-copy PATH to bust the (path,flags) cache). Skippable for the
         self-contained tests via ``run_clang=False`` (Clang has nothing to resolve
         against in a synthetic snippet).
    """
    edited_bytes = edited_text.encode("utf-8")

    # 2a. comment balance — the decisive gate for the deliberately-commented-out case.
    # A genuine runaway /** has a NEXT /** between the function and comment_close_line,
    # so the original */ still has an opener and stray-count is unchanged. A commented-
    # OUT function (/*Rxxx … } */) has no such opener, so our */ STRANDS the original */
    # — caught here even when a pre-existing ERROR state masks it from the node census.
    new_stray = _unmatched_comment_closers(edited_text)
    if new_stray > orig_stray:
        return (False, [], f"insertion strands {new_stray - orig_stray} comment closer(s) "
                           f"('*/' with no opener) — the original '*/' belongs to the "
                           f"function's own commented-out block, not a NEXT doc comment; "
                           f"this is a deliberately-commented-out function, not a runaway "
                           f"doc comment")

    # 3. no new errors.
    new_err = _error_count(edited_bytes)
    if new_err > orig_err:
        return (False, [], f"introduced {new_err - orig_err} new tree-sitter "
                           f"ERROR/MISSING node(s) — likely a stray '*/' from a "
                           f"deliberately-commented-out function, not a runaway doc comment")

    # 1. every swallowed function is now a real function_definition, count rose by N.
    new_defs = _fn_def_names(edited_bytes)
    new_count = len(new_defs)
    missing = [n for n in names if n not in new_defs]
    if missing:
        return (False, [], f"tree-sitter did not recover function_definition(s): "
                           f"{', '.join(missing)}")
    if new_count != orig_fn_count + len(names):
        return (False, [], f"function_definition count changed by {new_count - orig_fn_count}, "
                           f"expected +{len(names)}")

    # 2. comment balance — re-run the detector on the repaired text via a temp copy.
    re_swallowed = _swallowed_in_text(edited_text, Path(orig_path).name)
    still = {f.function for f in re_swallowed} & set(names)
    if still:
        return (False, [], f"still reported swallowed after repair: {', '.join(sorted(still))}")
    orig_set = {(f.function, f.function_line) for f in orig_swallowed}
    new_extra = [f for f in re_swallowed if (f.function, f.function_line) not in orig_set]
    if new_extra:
        return (False, [], f"introduced new swallowed function(s): "
                           f"{', '.join(f.function for f in new_extra)}")

    # 4. Clang CFG for every recovered function.
    if not run_clang:
        return (True, [], "")
    cfg_recovered = _cfg_via_tempcopy(orig_path, edited_text, names)
    cfg_missing = [n for n in names if n not in cfg_recovered]
    if cfg_missing:
        return (False, cfg_recovered, f"Clang cfg_extract still emits no CFG for: "
                                      f"{', '.join(cfg_missing)}")
    return (True, cfg_recovered, "")


def _swallowed_in_text(text: str, fname: str) -> List[SwallowedFn]:
    """Run ``source_lint.scan_source_for_swallowed`` on arbitrary TEXT by writing it to
    a temp file (the detector takes a path). Read-only reuse of the detector."""
    fd, tmp = tempfile.mkstemp(prefix="repair_comments_lint_", suffix=".cpp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        found = scan_source_for_swallowed(tmp)
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    # rename the basename so it matches the real file (cosmetic; comparison is by fn).
    return [SwallowedFn(file=fname, function=f.function, function_line=f.function_line,
                        comment_open_line=f.comment_open_line,
                        comment_close_line=f.comment_close_line) for f in found]


# ---------------------------------------------------------------------------
# Per-comment repair.
# ---------------------------------------------------------------------------
def repair_comment(path: str, group: List[SwallowedFn], *, run_clang: bool = True
                   ) -> CommentRepair:
    """Propose + verify a ``*/`` insertion for ONE runaway comment (one
    ``comment_open_line``). ``group`` is its swallowed functions, source-ordered.
    Fault-isolated: a read/parse failure yields a NOT-REPAIRABLE verdict."""
    fname = Path(path).name
    group = sorted(group, key=lambda f: f.function_line)
    names = [f.function for f in group]
    flines = [f.function_line for f in group]
    first_line = flines[0]
    finding = CommentRepair(
        file=fname,
        comment_open_line=group[0].comment_open_line,
        comment_close_line=group[0].comment_close_line,
        functions=names, function_lines=flines,
        insert_before_line=first_line, repairable=False)
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        finding.reason = f"cannot read source: {e}"
        return finding
    src = text.encode("utf-8")
    orig_fn_count = _fn_def_count(src)
    orig_err = _error_count(src)
    orig_stray = _unmatched_comment_closers(text)
    orig_swallowed = scan_source_for_swallowed(path)

    edited = _apply_insert(text, first_line)
    ok, cfg_recovered, reason = _verify(
        text, edited, names, path, orig_fn_count, orig_err, orig_stray,
        orig_swallowed, run_clang=run_clang)
    if ok:
        finding.repairable = True
        finding.cfg_recovered = cfg_recovered
        finding.reason = ""
    else:
        finding.reason = reason
    return finding


# ---------------------------------------------------------------------------
# Driver: read the source-lint JSON (or scan), group, repair.
# ---------------------------------------------------------------------------
def _group_by_comment(findings: List[SwallowedFn]) -> Dict[Tuple[str, int], List[SwallowedFn]]:
    """Group swallowed functions by their runaway comment ``(file, comment_open_line)``
    so a single comment that swallowed several functions is repaired once."""
    groups: Dict[Tuple[str, int], List[SwallowedFn]] = {}
    for f in findings:
        groups.setdefault((f.file, f.comment_open_line), []).append(f)
    return groups


def load_targets(json_path: Path) -> List[SwallowedFn]:
    """Swallowed-function entries from a source-lint JSON report."""
    data = json.loads(Path(json_path).read_text())
    return [SwallowedFn(file=e["file"], function=e["function"],
                        function_line=int(e["function_line"]),
                        comment_open_line=int(e["comment_open_line"]),
                        comment_close_line=int(e["comment_close_line"]))
            for e in data.get("swallowedFunctions", [])]


def run(asm_dir: Path, findings: List[SwallowedFn]) -> List[CommentRepair]:
    """Propose + verify a repair for every runaway comment in ``findings``.
    Deterministic (sorted by file, then comment open line)."""
    out: List[CommentRepair] = []
    for (fname, open_line), group in _group_by_comment(findings).items():
        path = asm_dir / fname
        if not path.is_file():
            g0 = sorted(group, key=lambda f: f.function_line)
            out.append(CommentRepair(
                file=fname, comment_open_line=open_line,
                comment_close_line=g0[0].comment_close_line,
                functions=[f.function for f in g0],
                function_lines=[f.function_line for f in g0],
                insert_before_line=g0[0].function_line, repairable=False,
                reason="source file not present in --asm-dir"))
            continue
        out.append(repair_comment(str(path), group))
    out.sort(key=lambda r: (r.file, r.comment_open_line))
    return out


def apply_repairs(asm_dir: Path, findings: List[CommentRepair]) -> List[str]:
    """Write the VERIFIED repairs to the actual source files. Groups insertions per
    file so multiple verified comments in one file are applied together (bottom-up
    line order keeps line numbers valid). Returns the files written."""
    per_file: Dict[str, List[int]] = {}
    for f in findings:
        if f.repairable:
            per_file.setdefault(f.file, []).append(f.insert_before_line)
    written: List[str] = []
    for fname, lines in per_file.items():
        path = asm_dir / fname
        text = path.read_text(encoding="utf-8", errors="replace")
        for ln in sorted(lines, reverse=True):     # bottom-up keeps earlier lines stable
            text = _apply_insert(text, ln)
        path.write_text(text, encoding="utf-8")
        written.append(str(path))
    return written


# ---------------------------------------------------------------------------
# Reporting.
# ---------------------------------------------------------------------------
def format_report(findings: List[CommentRepair]) -> str:
    if not findings:
        return "repair-comments: no swallowed functions to repair."
    lines: List[str] = []
    for f in findings:
        fns = ", ".join(f.functions)
        if f.repairable:
            lines.append(
                f"REPAIRABLE: {f.file}: runaway comment at L{f.comment_open_line} "
                f"swallowed {fns}. Insert '*/' before L{f.insert_before_line}. "
                f"Verified: function_definition(s) recovered; comments rebalanced; "
                f"Clang CFG for {', '.join(f.cfg_recovered) or '(none)'}.")
        else:
            lines.append(
                f"NOT-REPAIRABLE: {f.file}: runaway comment at L{f.comment_open_line} "
                f"(swallows {fns}) — {f.reason}.")
    n_ok = sum(f.repairable for f in findings)
    n_fns = sum(len(f.functions) for f in findings)
    n_ok_fns = sum(len(f.functions) for f in findings if f.repairable)
    lines.append(f"  -> {n_ok}/{len(findings)} runaway comment(s) verified-repairable "
                 f"({n_ok_fns}/{n_fns} swallowed function(s) recovered); the rest left alone.")
    return "\n".join(lines)


def write_json(findings: List[CommentRepair], out_path: Path) -> None:
    payload = {
        "repairs": [asdict(f) for f in findings],
        "counts": {
            "comments": len(findings),
            "repairable": sum(f.repairable for f in findings),
            "not_repairable": sum(not f.repairable for f in findings),
            "functions": sum(len(f.functions) for f in findings),
            "functions_recovered": sum(len(f.functions) for f in findings if f.repairable),
        },
    }
    Path(out_path).write_text(json.dumps(payload, indent=2))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="python -m vbt.tools.repair_comments",
        description="Propose + VERIFY a minimal '*/' insertion that un-swallows "
                    "functions hidden by a runaway block comment. Default DRY-RUN; "
                    "--apply writes only the verified repairs.")
    ap.add_argument("--asm-dir", required=True, type=Path, help="dir of .cpp source files")
    ap.add_argument("--json", type=Path,
                    default=Path("process_analysis/swallowed_functions.json"),
                    help="source-lint JSON report listing the swallowed functions "
                         "(if absent, the directory is scanned with source_lint)")
    ap.add_argument("--out", type=Path, default=None,
                    help="also write the repair verdicts as JSON here")
    ap.add_argument("--apply", action="store_true",
                    help="WRITE the verified repairs to the source files (default: dry-run)")
    a = ap.parse_args(argv)
    if not a.asm_dir.is_dir():
        sys.exit(f"--asm-dir not found: {a.asm_dir}")

    if a.json and a.json.is_file():
        findings = load_targets(a.json)
    else:
        from vbt.precompute.source_lint import scan_dir
        findings = scan_dir(a.asm_dir)

    verdicts = run(a.asm_dir, findings)
    print(format_report(verdicts))
    if a.out:
        write_json(verdicts, a.out)
        print(f"\nwrote {a.out}", file=sys.stderr)
    if a.apply:
        written = apply_repairs(a.asm_dir, verdicts)
        if written:
            print("\nAPPLIED verified repairs to:", file=sys.stderr)
            for w in written:
                print(f"  {w}", file=sys.stderr)
        else:
            print("\n--apply: no verified repairs to write.", file=sys.stderr)
    else:
        print("\n(dry-run: no files modified; pass --apply to write verified repairs)",
              file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
