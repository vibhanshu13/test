"""Verified source brace-repair for CFG-truncated functions.

WHY
===
Clang's ``cfg_extract`` (``CFG::buildCFG``) truncates a function body at the first
construct it cannot model. In this migrated z/TPF corpus the dominant cause is a
SOURCE BRACE MIS-NESTING: a stray / misplaced ``}`` closes the function early, so
``cfg_extract`` emits no blocks past that point and every cfg-driven step
(conditions, value-pruning, route enumeration) goes blind. ``truncation_lint.py``
already DIAGNOSES these (report at ``process_analysis/truncated_functions.json``,
cause ``"brace-mismatch"`` vs ``"unresolved-type"``). The brace-mismatch cases are
*source* bugs we can actually fix; the unresolved-type cases need headers and are
out of scope.

Canonical example — ``dw710000.cpp::processACreditTransaction`` (body ``{`` at
L933, real end ``}`` at L1390, next function at ~L1405). A stray ``}`` at L1046
closes the ``expressPay`` gate early; brace depth returns to 0 at L1058, so the
function closes there and the gate-3 ``switch`` (L1062) + its case-calls fall to
file scope and are dropped. The file is one ``}`` too many overall, so REMOVING the
stray ``}`` at L1046 both balances the file and extends the function's true end to
L1390 (verified). Other corpus cases are "count-balanced but mis-nested": a stray
``}`` early plus a MISSING ``}`` near the true end — those need TWO edits (remove +
insert). The algorithm handles both, driven entirely by the detector's
``true_end_line`` and a comment/char/string-literal-aware brace-depth trace — never
by hardcoded line numbers.

WHAT
====
For each brace-mismatch function this tool:

  1. PROPOSES a minimal brace edit (remove a stray ``}`` and/or insert a ``}`` just
     before the next function) that makes brace depth, traced from the function's
     opening ``{``, stay >= 1 inside the body and reach 0 exactly at the true end.
  2. VERIFIES the candidate by applying it in-memory to a temp copy of the file and
     re-checking ALL of:
       * tree-sitter: the function_definition now spans to within a few lines of
         ``true_end_line`` (no longer the truncated end);
       * the file stays brace-count-balanced (literal/comment-aware ``{`` == ``}``);
       * tree-sitter introduces NO NEW ERROR/MISSING nodes vs the original count;
       * Clang ``cfg_extract`` now reaches within ~10% of ``true_end`` for that
         function (truncation gone). ``run_cfg_extract`` caches on (path, flags), so
         we verify against a written temp-copy PATH to bust the cache.
  3. REPORTS, per function, REPAIRABLE (verified, with the exact line edit) or
     NOT-REPAIRABLE (verification failed — stays on the tree-sitter condition
     fallback). DEFAULT is dry-run (print + optional JSON). ``--apply`` writes ONLY
     the verified repairs to the actual ``--asm-dir`` source files.

Under-repairing is correct: a function whose fix cannot be VERIFIED is left alone.
A wrong brace edit that corrupts analysis is never acceptable, so every applied
edit must pass all four checks.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from vbt.cpp_frontend.wrapper import run_cfg_extract
from vbt.reach.fn_attr import function_starts
from vbt.setters.cpp_setters import _parser, _txt

_TS_PARSER = None

# The detector's ``true_end_line`` is "next function start − 1", an UPPER bound: the
# real closing ``}`` sits at or (often) several lines before it, because inter-function
# doc comments / blank lines pad the gap (e.g. processACreditTransaction's real ``}`` is
# L1390 but the next function starts at ~L1405, so true_end is inflated by ~15). So we
# can't demand the repaired end equal true_end; instead we require it to (a) NOT overshoot
# past the next function (<= true_end + a tiny slack), and (b) RECOVER most of the lost
# span. "Most" = this fraction of the (truncated_end → true_end) gap.
_RECOVERY_FRAC = 0.80           # repaired tree-sitter end must recover >= 80% of lost span
_OVERSHOOT_SLACK = 3            # repaired end may sit at most this far past true_end
_CFG_TOL = 10                   # cfg max may fall this many lines short of last real stmt


@dataclass
class BraceEdit:
    """A single brace edit. ``op`` is ``"remove"`` or ``"insert"``.

    For ``remove``: the ``}`` on ``line`` (the ``col``-th column) is deleted.
    For ``insert``: a ``}`` is inserted on a new line just before ``line``.
    """
    op: str
    line: int
    col: int = 0


@dataclass
class RepairFinding:
    """Repair verdict for one truncated function."""
    file: str
    function: str
    function_line: int
    body_open_line: int
    truncated_end_line: int     # where brace depth hit 0 BEFORE repair (the bug)
    true_end_line: int          # detector's true end (next fn start − 1)
    repairable: bool
    edits: List[BraceEdit] = field(default_factory=list)
    repaired_end_line: int = 0  # tree-sitter span end AFTER the verified repair
    cfg_max_after: int = 0      # cfg max stmt line AFTER the verified repair
    reason: str = ""            # why NOT repairable (when repairable is False)


# ---------------------------------------------------------------------------
# Comment / char / string-literal-aware brace scanner.
#
# Essential here: the corpus has `'{'` / `'}'` CHAR LITERALS, `"..."` strings, and
# `//R0xx` revision-marker line comments and `/* ... */` block comments that contain
# braces. Counting raw `{`/`}` would mis-balance and mis-locate the stray.
# ---------------------------------------------------------------------------
@dataclass
class _Brace:
    line: int       # 1-based
    col: int        # 0-based column within the line
    char: str       # '{' or '}'
    offset: int     # byte/char offset into the text


def _scan_braces(text: str) -> List[_Brace]:
    """Every real (code-context) ``{`` / ``}`` in ``text``, skipping those inside
    line/block comments, string literals, and char literals."""
    out: List[_Brace] = []
    i = 0
    n = len(text)
    line = 1
    col = 0
    in_line = in_block = in_str = in_chr = False
    while i < n:
        c = text[i]
        nxt = text[i + 1] if i + 1 < n else ""
        if c == "\n":
            line += 1
            col = 0
            in_line = False
            i += 1
            continue
        if in_line:
            i += 1
            col += 1
            continue
        if in_block:
            if c == "*" and nxt == "/":
                in_block = False
                i += 2
                col += 2
                continue
            i += 1
            col += 1
            continue
        if in_str:
            if c == "\\":
                i += 2
                col += 2
                continue
            if c == '"':
                in_str = False
            i += 1
            col += 1
            continue
        if in_chr:
            if c == "\\":
                i += 2
                col += 2
                continue
            if c == "'":
                in_chr = False
            i += 1
            col += 1
            continue
        # plain code context
        if c == "/" and nxt == "/":
            in_line = True
            i += 2
            col += 2
            continue
        if c == "/" and nxt == "*":
            in_block = True
            i += 2
            col += 2
            continue
        if c == '"':
            in_str = True
            i += 1
            col += 1
            continue
        if c == "'":
            in_chr = True
            i += 1
            col += 1
            continue
        if c == "{" or c == "}":
            out.append(_Brace(line=line, col=col, char=c, offset=i))
        i += 1
        col += 1
    return out


def _balance(text: str) -> Tuple[int, int]:
    """``(open_count, close_count)`` of literal/comment-aware braces in ``text``."""
    braces = _scan_braces(text)
    return (sum(b.char == "{" for b in braces), sum(b.char == "}" for b in braces))


def _zero_crossing(braces: List[_Brace], open_idx: int) -> Optional[int]:
    """Trace brace depth from ``braces[open_idx]`` (an opening ``{``, depth→1) and
    return the LINE where depth first returns to 0, or None if it never does."""
    depth = 0
    for b in braces[open_idx:]:
        depth += 1 if b.char == "{" else -1
        if depth == 0:
            return b.line
    return None


def _line_indent(text: str, line: int) -> int:
    """Leading-space count of 1-based ``line`` (tabs counted as 1)."""
    lines = text.split("\n")
    if not (1 <= line <= len(lines)):
        return -1
    s = lines[line - 1]
    return len(s) - len(s.lstrip(" \t"))


def _pair_misalignment(text: str, braces: List[_Brace], open_idx: int,
                       skip_offset: Optional[int] = None) -> Tuple[int, int]:
    """Match the function's braces from ``open_idx`` to its close and count how many
    ``{``/``}`` PAIRS have mismatched indentation, optionally skipping the brace at
    ``skip_offset`` (a removal candidate). Returns ``(mismatches, pairs)``.

    WHY this disambiguates: brace-counting alone cannot tell WHICH ``}`` is the
    stray — in a run of sibling blocks, removing any one of several rebalances the
    file and gives the same span/cfg (e.g. dw710000 L947/L989/L1046 all "work"
    numerically). But only the SEMANTICALLY-correct removal leaves every remaining
    ``}`` indentation-aligned with its matching ``{`` (this corpus indents
    consistently per revision block). The correct stray is the removal that MINIMIZES
    pair indentation mismatch; verification then confirms it. A removal that mis-nests
    a different scope leaves more pairs misaligned."""
    bs = braces if skip_offset is None else [b for b in braces if b.offset != skip_offset]
    start = None
    target_line = braces[open_idx].line
    for k, b in enumerate(bs):
        if b.char == "{" and b.line == target_line:
            start = k
            break
    if start is None:
        return (1 << 30, 0)
    stack: List[_Brace] = []
    mism = pairs = depth = 0
    for b in bs[start:]:
        if b.char == "{":
            stack.append(b)
            depth += 1
        else:
            depth -= 1
            if stack:
                o = stack.pop()
                pairs += 1
                if _line_indent(text, o.line) != _line_indent(text, b.line):
                    mism += 1
            if depth == 0:
                break
    return (mism, pairs)


# ---------------------------------------------------------------------------
# tree-sitter helpers (function spans + error census).
# ---------------------------------------------------------------------------
def _ts() :
    global _TS_PARSER
    if _TS_PARSER is None:
        _TS_PARSER = _parser()
    return _TS_PARSER


def _fn_bodies(src: bytes) -> Dict[str, Tuple[int, int, int]]:
    """name → (def_end_line, body_open_line, body_open_col) for every
    function_definition with a ``compound_statement`` body. Last wins on dups."""
    tree = _ts().parse(src)
    out: Dict[str, Tuple[int, int, int]] = {}
    stack = [tree.root_node]
    while stack:
        n = stack.pop()
        if n.type == "function_definition":
            d = n.child_by_field_name("declarator")
            b = n.child_by_field_name("body")
            if d and b and b.type == "compound_statement":
                raw = _txt(d, src).split("(")[0].strip()
                parts = raw.split()
                if parts:
                    nm = parts[-1].split("::")[-1].lstrip("*&")
                    out[nm] = (n.end_point[0] + 1,
                               b.start_point[0] + 1, b.start_point[1])
        stack.extend(n.children)
    return out


def _ts_fn_end(src: bytes, name: str) -> int:
    """tree-sitter function_definition end line for ``name`` (0 if absent)."""
    return _fn_bodies(src).get(name, (0, 0, 0))[0]


def _error_count(src: bytes) -> int:
    """Number of ERROR / MISSING nodes in the tree-sitter parse of ``src``."""
    tree = _ts().parse(src)
    cnt = 0
    stack = [tree.root_node]
    while stack:
        n = stack.pop()
        if n.type == "ERROR" or n.is_missing:
            cnt += 1
        stack.extend(n.children)
    return cnt


# Statement node types that carry a real (cfg-modelable) line — the compound_statement
# WRAPPER is excluded so the trailing ``}`` line (often after a big comment block)
# doesn't masquerade as the "last code line".
_REAL_STMT = frozenset({
    "expression_statement", "declaration", "if_statement", "for_statement",
    "while_statement", "switch_statement", "return_statement", "do_statement",
    "labeled_statement", "break_statement", "continue_statement", "goto_statement",
})


def _last_real_stmt_line(src: bytes, name: str) -> int:
    """Start line of the LAST real (non-comment) statement inside ``name``'s body.

    This is the line a fully-recovered Clang CFG should reach. It is NOT the function
    closing-brace line: this corpus pads function ends with large trailing block
    comments (e.g. processACreditTransaction's body ends with a ~100-line ``/*R051
    ... */`` before the ``}`` at L1390, so the last real statement is L1285 and the
    CFG correctly stops there). Anchoring the cfg-recovery check on this avoids
    falsely rejecting a CORRECT brace repair just because trailing comments are not
    cfg statements. 0 if the function/body is not found."""
    bodies = _fn_bodies(src)
    if name not in bodies:
        return 0
    tree = _ts().parse(src)
    stack = [tree.root_node]
    target = None
    while stack:
        n = stack.pop()
        if n.type == "function_definition":
            d = n.child_by_field_name("declarator")
            if d:
                raw = _txt(d, src).split("(")[0].strip().split()
                if raw and raw[-1].split("::")[-1].lstrip("*&") == name:
                    target = n
        stack.extend(n.children)
    if target is None:
        return 0
    body = target.child_by_field_name("body")
    if body is None:
        return 0
    last = 0
    st = [body]
    while st:
        n = st.pop()
        if n.type in _REAL_STMT:
            last = max(last, n.start_point[0] + 1)
        st.extend(n.children)
    return last


def _cfg_max_line(cpp_path: str, name: str) -> int:
    """Max cfg stmt line for ``name`` in ``cpp_path`` (0 on miss). Runs cfg_extract
    on the GIVEN path so callers can bust the (path,flags) cache by using a temp
    copy with a distinct name/mtime."""
    try:
        fns = run_cfg_extract(cpp_path)
    except Exception:
        return 0
    best = 0
    for f in fns:
        nm = (f.get("function") or "").split("::")[-1]
        if nm != name:
            continue
        lines = [s.get("line") for b in f.get("cfg_blocks", []) for s in b.get("stmts", [])
                 if s.get("line")]
        if lines:
            best = max(best, max(lines))
    return best


# ---------------------------------------------------------------------------
# Locate the function body's opening brace.
# ---------------------------------------------------------------------------
def _locate_body_open(src: bytes, braces: List[_Brace], name: str,
                      function_line: int) -> Optional[int]:
    """Index into ``braces`` of the function body's opening ``{``.

    Prefer tree-sitter's ``compound_statement`` body start (exact, even when the
    body later truncates). Fall back to the first ``{`` at/after ``function_line``
    when tree-sitter cannot attach a clean body to ``name`` (badly tangled file)."""
    text = src.decode("utf-8", "replace")
    bodies = _fn_bodies(src)
    if name in bodies:
        _, bline, bcol = bodies[name]
        for k, b in enumerate(braces):
            if b.char == "{" and b.line == bline and b.col == bcol:
                return k
        # tree-sitter line known but col mismatch (tabs/encoding) — match by line.
        for k, b in enumerate(braces):
            if b.char == "{" and b.line == bline:
                return k
    # Fallback: first opening brace on or after the detector's function_line.
    for k, b in enumerate(braces):
        if b.char == "{" and b.line >= function_line:
            return k
    return None


# ---------------------------------------------------------------------------
# Edit application + candidate generation.
# ---------------------------------------------------------------------------
def _apply_edits(text: str, edits: List[BraceEdit]) -> str:
    """Apply brace edits to ``text`` and return the new text.

    ``remove`` deletes the ``}`` at (line, col). ``insert`` adds a ``}`` on its own
    line just before ``line``. Edits are applied bottom-up by line so earlier
    offsets stay valid."""
    lines = text.split("\n")
    # Apply removals and insertions in descending line order.
    ordered = sorted(edits, key=lambda e: (e.line, e.op == "insert"), reverse=True)
    for e in ordered:
        idx = e.line - 1
        if e.op == "remove":
            if 0 <= idx < len(lines):
                ln = lines[idx]
                # remove the brace at the recorded column if it is a '}', else the
                # first '}' on the line (column can drift after another same-line edit).
                if e.col < len(ln) and ln[e.col] == "}":
                    lines[idx] = ln[:e.col] + ln[e.col + 1:]
                else:
                    pos = ln.find("}")
                    if pos >= 0:
                        lines[idx] = ln[:pos] + ln[pos + 1:]
        elif e.op == "insert":
            ins = max(0, min(idx, len(lines)))
            lines.insert(ins, "}")
    return "\n".join(lines)


def _recovery_floor(truncated_end: int, true_end: int) -> int:
    """Minimum line a repaired close must reach to count as "recovered most of the
    lost span" — ``truncated_end + RECOVERY_FRAC * (true_end − truncated_end)``."""
    return truncated_end + int(_RECOVERY_FRAC * max(0, true_end - truncated_end))


def _in_recovery_window(zc: Optional[int], truncated_end: int, true_end: int) -> bool:
    """A close line ``zc`` is acceptable iff it recovered most of the lost span and
    did not overshoot past the next function. Tolerates the inter-function comment/
    blank gap that inflates ``true_end`` above the real closing-brace line."""
    if zc is None:
        return False
    return _recovery_floor(truncated_end, true_end) <= zc <= true_end + _OVERSHOOT_SLACK


def _candidate_edits(text: str, braces: List[_Brace], open_idx: int,
                     early_close_line: int, true_end_line: int
                     ) -> List[Tuple[List[BraceEdit], int]]:
    """Propose candidate edit-sets RANKED best-first, each paired with its
    indentation-mismatch score (lower = more structurally consistent).

    The function's brace depth (from ``braces[open_idx]``) prematurely hits 0 at
    ``early_close_line`` (the bug) instead of near ``true_end_line``.

      (a) SINGLE REMOVE — a stray ``}`` between the body open and the early close
          whose removal lands the new zero-crossing inside the RECOVERY WINDOW
          (recovered most of the lost span, no overshoot). Covers the "extra-brace"
          file (e.g. processACreditTransaction — removing the stray ``}`` at L1046
          closes the body at L1390, recovering the gate-3 switch). Brace-counting
          alone can't pick WHICH ``}`` (several rebalance identically), so we rank
          by ``_pair_misalignment`` and verify the lowest-mismatch one first.
      (b) REMOVE + INSERT — for a "count-balanced but mis-nested" file: removing a
          stray early ``}`` leaves the body still open at/after the true end, so we
          also insert a ``}`` just before the next function to close it there.

    ``true_end_line`` is the UPPER bound (real ``}`` may sit a few lines earlier due
    to trailing comments). The recovery-window prefilter is loose; the four-check
    verifier is the real gate. Ranked by (edit-count, mismatch, latest close first)."""
    ranked: List[Tuple[Tuple[int, int, int], List[BraceEdit], int]] = []
    seen = set()

    def add(edits: List[BraceEdit], mism: int, latest: int) -> None:
        key = tuple((e.op, e.line, e.col) for e in edits)
        if key in seen:
            return
        seen.add(key)
        ranked.append(((len(edits), mism, -latest), edits, mism))

    # Close braces strictly inside (open, early_close]; these are removal candidates.
    inner_closes = [b for b in braces[open_idx + 1:]
                    if b.char == "}" and b.line <= early_close_line]

    # (a) single remove landing inside the recovery window.
    for b in inner_closes:
        new_braces = [x for x in braces if x.offset != b.offset]
        # open_idx is stable: the removed brace is a close AFTER the body open.
        zc = _zero_crossing(new_braces, open_idx)
        if _in_recovery_window(zc, early_close_line, true_end_line):
            mism, _ = _pair_misalignment(text, braces, open_idx, skip_offset=b.offset)
            add([BraceEdit(op="remove", line=b.line, col=b.col)], mism, b.line)

    # (b) remove-stray + insert-at-true-end (count-balanced but mis-nested).
    for b in inner_closes:
        new_braces = [x for x in braces if x.offset != b.offset]
        zc = _zero_crossing(new_braces, open_idx)
        if zc is None or zc > true_end_line + _OVERSHOOT_SLACK:
            mism, _ = _pair_misalignment(text, braces, open_idx, skip_offset=b.offset)
            add([BraceEdit(op="remove", line=b.line, col=b.col),
                 BraceEdit(op="insert", line=true_end_line + 1)], mism, b.line)

    # (b') pure insert at true_end (function never closes — a plain MISSING ``}``).
    if _zero_crossing(braces, open_idx) is None:
        mism, _ = _pair_misalignment(text, braces, open_idx)
        add([BraceEdit(op="insert", line=true_end_line + 1)], mism, true_end_line)

    ranked.sort(key=lambda t: t[0])
    return [(edits, mism) for _, edits, mism in ranked]


# ---------------------------------------------------------------------------
# Verification.
# ---------------------------------------------------------------------------
def _verify(orig_text: str, edited_text: str, name: str, truncated_end: int,
            true_end_line: int, orig_err: int, orig_path: str
            ) -> Tuple[bool, int, int, str]:
    """Return ``(ok, ts_end, cfg_max, reason)`` for an edited file text.

    All four conditions must hold for ``ok``:
      1. tree-sitter: the function_definition for ``name`` now ends inside the
         RECOVERY WINDOW — it recovered >= ``_RECOVERY_FRAC`` of the lost
         (truncated_end → true_end) span and did NOT overshoot past the next
         function. (true_end is "next fn start − 1", inflated by the inter-function
         comment gap, so an exact match is neither expected nor required.)
      2. file stays brace-count-balanced (literal/comment-aware);
      3. NO new ERROR/MISSING nodes vs the original count;
      4. Clang cfg max for ``name`` now reaches the LAST REAL STATEMENT of the
         repaired body (within ``_CFG_TOL`` lines) — i.e. Clang no longer bails at
         the brace bug. Anchored on the last real statement (not true_end) so a big
         trailing comment block before the ``}`` doesn't falsely reject a correct
         repair. Verified against a TEMP COPY PATH to bust the (path,flags) cache.
    """
    edited_bytes = edited_text.encode("utf-8")

    # 2. balance
    o, c = _balance(edited_text)
    if o != c:
        return (False, 0, 0, f"file not brace-balanced after edit ({o} {{ vs {c} }})")

    # 1. tree-sitter span recovers the lost body without overshooting
    ts_end = _ts_fn_end(edited_bytes, name)
    if ts_end == 0:
        return (False, 0, 0, "tree-sitter lost the function_definition after edit")
    floor = _recovery_floor(truncated_end, true_end_line)
    if not _in_recovery_window(ts_end, truncated_end, true_end_line):
        return (False, ts_end, 0,
                f"tree-sitter end L{ts_end} outside recovery window "
                f"[L{floor}..L{true_end_line + _OVERSHOOT_SLACK}] "
                f"(was truncated at L{truncated_end}, true end L{true_end_line})")

    # 3. no new errors
    new_err = _error_count(edited_bytes)
    if new_err > orig_err:
        return (False, ts_end, 0,
                f"introduced {new_err - orig_err} new tree-sitter ERROR/MISSING node(s)")

    # 4. cfg recovery — verify against a TEMP COPY PATH to bust the (path,flags) cache.
    cfg_max = _cfg_via_tempcopy(orig_path, edited_text, name)
    last_stmt = _last_real_stmt_line(edited_bytes, name)
    # The cfg must reach the last real statement (the recovered constructs are now
    # modelled) and must have ADVANCED meaningfully past the old truncation.
    if last_stmt and cfg_max < last_stmt - _CFG_TOL:
        return (False, ts_end, cfg_max,
                f"Clang cfg max L{cfg_max} did not reach last real statement L{last_stmt} "
                f"(was L{truncated_end})")
    if cfg_max <= truncated_end:
        return (False, ts_end, cfg_max,
                f"Clang cfg max L{cfg_max} did not advance past the truncation L{truncated_end}")
    return (True, ts_end, cfg_max, "")


def _cfg_via_tempcopy(orig_path: str, edited_text: str, name: str) -> int:
    """Write ``edited_text`` to a uniquely-named temp copy NEXT TO the original (so
    its sibling-header ``-I <srcdir>`` resolution is identical) and run cfg_extract
    on that path — busting ``run_cfg_extract``'s (path, mtime) cache. Cleaned up."""
    src_dir = os.path.dirname(os.path.abspath(orig_path))
    base = os.path.basename(orig_path)
    fd, tmp = tempfile.mkstemp(prefix=f".repair_braces_{base}.", suffix=".cpp",
                               dir=src_dir)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(edited_text)
        return _cfg_max_line(tmp, name)
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Per-function repair.
# ---------------------------------------------------------------------------
def repair_function(path: str, function: str, function_line: int, cfg_max_line: int,
                    true_end_line: int) -> RepairFinding:
    """Propose + verify a brace repair for ONE truncated function. Fault-isolated."""
    fname = Path(path).name
    finding = RepairFinding(file=fname, function=function, function_line=function_line,
                            body_open_line=0, truncated_end_line=cfg_max_line,
                            true_end_line=true_end_line, repairable=False)
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        finding.reason = f"cannot read source: {e}"
        return finding
    src = text.encode("utf-8")
    braces = _scan_braces(text)
    open_idx = _locate_body_open(src, braces, function, function_line)
    if open_idx is None:
        finding.reason = "could not locate the function body opening brace"
        return finding
    finding.body_open_line = braces[open_idx].line
    early_close = _zero_crossing(braces, open_idx)
    if early_close is None:
        finding.reason = "function never closes (no matching brace) — not a clean truncation"
        return finding
    finding.truncated_end_line = early_close
    # If the body's brace depth already closes at/after the recovery floor, the
    # truncation is NOT a brace bug (it's e.g. an unresolved-type switch that
    # tree-sitter parses fine) — nothing to repair here.
    if early_close >= _recovery_floor(early_close, true_end_line) and \
            early_close >= true_end_line - _OVERSHOOT_SLACK:
        finding.reason = (f"brace depth already reaches the true end (L{early_close}); "
                          "not a brace truncation")
        return finding

    orig_err = _error_count(src)

    for edits, _mism in _candidate_edits(text, braces, open_idx, early_close, true_end_line):
        edited = _apply_edits(text, edits)
        ok, ts_end, cfg_max, reason = _verify(
            text, edited, function, early_close, true_end_line, orig_err, path)
        if ok:
            finding.repairable = True
            finding.edits = edits
            finding.repaired_end_line = ts_end
            finding.cfg_max_after = cfg_max
            finding.reason = ""
            return finding
        # remember the most informative failure reason (last candidate's)
        finding.reason = reason
    if not finding.reason:
        finding.reason = "no candidate edit passed verification"
    return finding


# ---------------------------------------------------------------------------
# Driver: read the truncation-lint JSON, repair the brace-mismatch entries.
# ---------------------------------------------------------------------------
def load_targets(json_path: Path) -> List[dict]:
    """Brace-mismatch entries from a truncation-lint JSON report."""
    data = json.loads(Path(json_path).read_text())
    return [t for t in data.get("truncatedFunctions", [])
            if t.get("cause") == "brace-mismatch"]


def run(asm_dir: Path, json_path: Path) -> List[RepairFinding]:
    """Propose + verify repairs for every brace-mismatch function in the report.
    Deterministic (sorted by file, then function line)."""
    targets = load_targets(json_path)
    out: List[RepairFinding] = []
    for t in targets:
        path = str(asm_dir / t["file"])
        if not Path(path).is_file():
            out.append(RepairFinding(
                file=t["file"], function=t["function"],
                function_line=t["function_line"], body_open_line=0,
                truncated_end_line=t.get("cfg_max_line", 0),
                true_end_line=t.get("true_end_line", 0), repairable=False,
                reason="source file not present in --asm-dir"))
            continue
        out.append(repair_function(
            path, t["function"], int(t["function_line"]),
            int(t.get("cfg_max_line", 0)), int(t.get("true_end_line", 0))))
    out.sort(key=lambda f: (f.file, f.function_line))
    return out


def apply_repairs(asm_dir: Path, findings: List[RepairFinding]) -> List[str]:
    """Write the VERIFIED repairs to the actual source files. Groups edits per file
    so multiple verified functions in one file are applied together (bottom-up line
    order keeps offsets valid). Returns the list of files written."""
    per_file: Dict[str, List[BraceEdit]] = {}
    for f in findings:
        if f.repairable and f.edits:
            per_file.setdefault(f.file, [])
            per_file[f.file].extend(f.edits)
    written: List[str] = []
    for fname, edits in per_file.items():
        path = asm_dir / fname
        text = path.read_text(encoding="utf-8", errors="replace")
        path.write_text(_apply_edits(text, edits), encoding="utf-8")
        written.append(str(path))
    return written


def _edit_str(e: BraceEdit) -> str:
    if e.op == "remove":
        return f"remove '}}' at L{e.line}"
    return f"insert '}}' before L{e.line}"


def format_report(findings: List[RepairFinding]) -> str:
    if not findings:
        return "repair-braces: no brace-mismatch functions to repair."
    lines: List[str] = []
    for f in findings:
        if f.repairable:
            edits = "; ".join(_edit_str(e) for e in f.edits)
            lines.append(
                f"REPAIRABLE: {f.file}: {f.function} (body {{ L{f.body_open_line}) — "
                f"was truncated at L{f.truncated_end_line}, true end ~L{f.true_end_line}. "
                f"Edit: {edits}. Verified: tree-sitter end L{f.repaired_end_line}, "
                f"cfg max L{f.cfg_max_after}.")
        else:
            lines.append(
                f"NOT-REPAIRABLE: {f.file}: {f.function} (L{f.function_line}) — "
                f"{f.reason}. Stays on the tree-sitter condition fallback.")
    n_ok = sum(f.repairable for f in findings)
    lines.append(f"  -> {n_ok}/{len(findings)} brace-mismatch function(s) "
                 f"verified-repairable; {len(findings) - n_ok} left on the fallback.")
    return "\n".join(lines)


def write_json(findings: List[RepairFinding], out_path: Path) -> None:
    payload = {
        "repairs": [
            {**{k: v for k, v in asdict(f).items() if k != "edits"},
             "edits": [asdict(e) for e in f.edits]}
            for f in findings
        ],
        "counts": {
            "functions": len(findings),
            "repairable": sum(f.repairable for f in findings),
            "not_repairable": sum(not f.repairable for f in findings),
        },
    }
    Path(out_path).write_text(json.dumps(payload, indent=2))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="python -m vbt.tools.repair_braces",
        description="Propose + VERIFY minimal brace edits that un-truncate "
                    "Clang-CFG-truncated functions (brace-mismatch cause). Default "
                    "DRY-RUN; --apply writes only the verified repairs.")
    ap.add_argument("--asm-dir", required=True, type=Path, help="dir of .cpp source files")
    ap.add_argument("--json", type=Path,
                    default=Path("process_analysis/truncated_functions.json"),
                    help="truncation-lint JSON report listing the truncated functions")
    ap.add_argument("--out", type=Path, default=None,
                    help="also write the repair verdicts as JSON here")
    ap.add_argument("--apply", action="store_true",
                    help="WRITE the verified repairs to the source files (default: dry-run)")
    a = ap.parse_args(argv)
    if not a.asm_dir.is_dir():
        sys.exit(f"--asm-dir not found: {a.asm_dir}")
    if not a.json.is_file():
        sys.exit(f"--json report not found: {a.json}")

    findings = run(a.asm_dir, a.json)
    print(format_report(findings))
    if a.out:
        write_json(findings, a.out)
        print(f"\nwrote {a.out}", file=sys.stderr)
    if a.apply:
        written = apply_repairs(a.asm_dir, findings)
        if written:
            print("\nAPPLIED verified repairs to:", file=sys.stderr)
            for w in written:
                print(f"  {w}", file=sys.stderr)
        else:
            print("\n--apply: no verified repairs to write.", file=sys.stderr)
    else:
        print("\n(dry-run: no files modified; pass --apply to write verified repairs)",
              file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
