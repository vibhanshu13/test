# VBT DB-Backed Precompute — Investigation Report & Plan

**Status:** ANALYSIS ONLY. No code changed. Implementation is staged one optimization at a
time (see the Development Tracker, §12), each gated on byte-identical regression proof.

**Goal.** Make VBT tracing much faster on very large codebases (~22K files) by moving
repeated file/JSON/blueprint reads and corpus-wide runtime computation into precomputed,
DB-backed (or disk-artifact) data — **with zero change to outputs, semantics, or behavior.**

**Hard constraint.** Performance/architecture only. Every step must prove the trace JSON is
byte-identical to baseline. No broad parser-pipeline changes; VBT-specific precompute gets
dedicated CLI commands.

---

## 0. Executive summary (the reframing)

The user's hypothesis — "we repeatedly read files/JSONs/blueprints/call-graphs during
tracing that could be precomputed once" — is **correct, but the dominant cost is bigger
than file I/O**. The deeper finding:

> **VBT builds whole *corpus-wide derived structures* from scratch on every trace (or every
> fresh worker process), even though those structures depend only on the call graph + cfg +
> source — never on the variable being traced.**

A "full-lineage run" at 22K scale = **one precompute + N independent traces** (one Celery
`run_vbt_trace`/`run_vbt_table` per variable; there is no single in-process orchestrator).
Each trace constructs a fresh `RouteEngine` (`vbt/engine.py:694`) and a fresh `CppFnGraph`
(`vbt/reach/cpp_routes.py:324`), and the `name_resolver`/`membership` resolvers have **no
disk persistence at all** — so the same corpus-wide work is repeated N times.

Three classes of work, and what to do with each:

| Class | Examples | Current persistence | Action |
|---|---|---|---|
| **A. Corpus-wide derived structures, recomputed per-trace / per-process** | RouteEngine reverse+forward file adjacency, `node_type`, `name_to_stems`; `CppFnGraph` fn-level adjacency + `fn→file` + per-file fn-start index; name/membership resolvers | per-trace (graph/CppFnGraph) or per-process **with no disk backing** (resolvers) | **PRECOMPUTE ONCE → DB, load at trace start.** *This is the win.* |
| **B. Already disk-persisted, manifest-hashed** | `modifier_index` (`$VBT_CACHE_DIR/index`), `const_resolver` (`$VBT_CACHE_DIR/const`), `file_call_graph.json`, cfg cache (`$VBT_CACHE_DIR/cfg`) | disk, cross-process | **KEEP.** DB-mirror only if cross-host sharing is later needed (low priority). cfg-warm is the single most important thing precompute already does — keep it on. |
| **C. Large nested per-stem blobs / content-addressed** | blueprint `blocks`/`flow`, C++ `variable_lineage`; raw cfg JSON | seekable `.bpidx` frames / SHA-256 file cache | **KEEP AS FILES.** Relationalizing buys nothing; the access pattern is "give me all of X for this one stem." |

**Provenance gate (correctness):**
- `file_call_graph.json` → index_db `call_graph_nodes/edges` is produced by the **SAME**
  `file_call_graph.CallGraphBuilder` that VBT invokes (`vbt/precompute/call_graph.py:38` vs
  `api/tasks/pipeline_task.py:717`). **VBT can safely read the call graph from DB.**
- `variable_modifier_index.json` → index_db `variable_modifiers` is a **DIFFERENT** producer
  (`build_modifier_index.py`: ASM `SETTER_INST`+aliases, C++ from **GVL edges**) than VBT's
  `vbt/precompute/modifier_index.py` (ASM `SETTER_INST`+MVC+register-indirect, C++ from
  **tree-sitter source**). **VBT must NOT read `variable_modifiers`** — it would change
  outputs. Any DB-backed VBT modifier index must persist *VBT's own* computation under new
  `vbt_*` tables.

VBT today has **zero** `api.index_db` imports. `vbt/reach/route.py:89` already calls
`_load_graph_payload(self.graph_file, None)` — the index.db fallback (`get_call_graph`)
exists but is never exercised because `job_id=None` is passed. The plumbing is there.

---

## 1. Tracing flow & execution model

Entry: `vbt.engine.trace_root_variable(variable, language, hops, blueprint_dir, asm_dir,
graph_file, …)` (`vbt/engine.py:663`). CLI: `python -m vbt.trace`. Production: Celery
`run_vbt_trace` (`api/tasks/vbt_trace_task.py:119`) and `run_vbt_table`
(`api/tasks/vbt_table_task.py:127`); precompute: `run_precompute`
(`api/tasks/vbt_precompute_task.py:167`).

Per trace, in order:
1. `ensure_call_graph(blueprint_dir, asm_dir, graph_file)` — rebuild `file_call_graph.json`
   if stale (mtime vs newest blueprint). `vbt/engine.py:692`.
2. `RouteEngine(blueprint_dir, graph_file, asm_dir, …)` — **fresh per trace**;
   loads the graph payload, builds reverse/forward adjacency, `name_to_stems`, lazily.
   `vbt/engine.py:694`.
3. `get_modifier_index` / `get_const_resolver` — disk-artifact-cached. `vbt/engine.py:706-707`.
4. Root setter search → per-setter route walks (`route.routes`) → per-route path enumeration
   (`CppFnGraph`) → per-edge/per-path guard collection → value-flow prune.
5. Dependent-variable recursion (`vbt/depvars/recurse.py`): per dep var, alias resolution,
   setter search, off-chain reachability (`route.reachable`), emit.
6. Membership resolution (`get_membership_resolver`) — lazy per-process, no disk artifact.
7. Output assembly (`CodeBlockStore` slices raw source).

**Identity:** KB id == job id == the `jobs/<id>/` directory name. `index.db` lives at
`jobs/<id>/index.db` (`api/index_db/engine.py:526`), keyed by `job_id`. A VBT precompute
already has `job_id` and resolves `blueprint_dir`/`asm_dir` (`vbt_precompute_task.py:200`).

---

## 2. (Req #1) Inventory of file / JSON / blueprint / graph / cfg reads during tracing

Frequency: **JOB** = once per `trace_root_variable`; **VAR** = per traced variable;
**SETTER** = per discovered setter; **ROUTE/PATH/EDGE** = per enumerated route/path/call-edge.
🔥 = innermost-loop hot site. (P)=per-process cache, (T)=per-trace cache, (D)=disk-persisted.

| # | Site (file:line) | What is read | Frequency | Existing cache |
|---|---|---|---|---|
| 1 | `engine.py:692` → `precompute/call_graph.py:25` | `file_call_graph.json` mtime; rebuild (re-glob + read all blueprints) if stale | JOB | mtime check (no cache) |
| 2 | `engine.py:706` → `modifier_index.py:512` | var/fn→stems index; cold build globs all `*.asm.json`/`*.mac.json` + tree-sitter all `*.cpp` | JOB (build) | `_CACHE` (P) + artifact (D) |
| 3 | `engine.py:707` → `const_resolver.py:390` | enum/EQU/DC resolver; cold build globs all cpp/hpp blueprints + all source | JOB (build) | `_CACHE` (P) + artifact (D) |
| 4 | `engine.py:704` / `recurse.py:841` → `name_resolver` | per cc/gen/mac triple: read all 3 + build byte-offset alias map | VAR (miss) | `_MAP_CACHE`/`_UNIT_CACHE` (P, **no disk**) |
| 5 | `engine.py:717` → `route.py:158-224` | `name_to_stems` (load **every** blueprint for `_entry_names`) + forward file adjacency | JOB | `_fwd_file_adj`/`_name_to_stems` (T) |
| 6 | `engine.py:739` → `cpp_setters.find_cpp_setters_in_file` | 🔥 raw `.cpp` `read_bytes()` + full tree-sitter parse | VAR × cpp stem | `_SETTER_CACHE` (P, max 8192) |
| 7 | `engine.py:742` → `asm_setters.find_asm_setters_in_file` | ASM blueprint `load_json` + `.asm` source lines + register-indirect pass | VAR × asm stem | bp LRU (P) + several (P) |
| 8 | `engine.py:119` `_cfg_for` → `wrapper.run_cfg_extract` | 🔥🔥 cfg JSON per cpp stem; **subprocess** on cold miss, else disk/memo | many (per setter/route/path/edge) | `cfg_cache`(T)→`_MEMO`(P)→disk(D) |
| 9 | `engine.py:779` `route.routes` → `find_routes`/`walk_callers` | 🔥 caller-forest walk; `load_json`s caller blueprints + C++ lineage | SETTER | `_reach_cache`/`_pfl_cache` (T) |
| 10 | `engine.py:797` → `cpp_routes.get_cpp_fn_graph` | fn-level graph build: `_cfg_for` + `cpp_call_edges` + `graph_edges` for every reachable stem | JOB (build) / SETTER (DFS) | `_cpp_fn_graph` (T) |
| 11 | `engine.py:296` `route.cpp_call_edges` | blueprint `call_graph.edges` + cfg re-attribution per cpp stem | per cpp stem | `_edge_cache`/`_cfg_cache` (T) |
| 12 | `engine.py:880,932` `_edge_guard`/`_cpp_fn_block` → `_cfg_for` + `collect_cpp_conditions` | 🔥 cfg + C++ guards per call edge; ts-fallback reads raw source on truncation | PATH × EDGE | cfg_cache (T) |
| 13 | `engine.py:626,644` value-flow prune | 🔥 raw `.cpp` + tree-sitter per route fn (switch-scrutinee); guards | ROUTE × fn | `_vf_setter_memo`/`_vf_cond_memo` (T) |
| 14 | `engine.py:823-831` ASM setter guards | `resolve_asm_blueprint`+`load_json` + `collect_asm_conditions` + `collect_constant_symbols` (`.asm` source) | ASM SETTER | bp LRU (P), `_get_file_cfg_maps` LRU (P) |
| 15 | `engine.py:1029` `get_membership_resolver().resolve` | first call builds header/DSECT indexes (glob all `cc*.hpp`/`*.hpp`/`*.mac`) | JOB (build) | `_CACHE` (P, **no disk**) |
| 16 | `engine.py:693` `CodeBlockStore` slices | raw `.cpp`/`.asm` `read_text().splitlines()` for output code | per source file | `_src` (T) |
| 17 | `recurse.py:883,891,899` dep-var setter search | 🔥 raw `.cpp`+tree-sitter, cfg, ASM blueprint per (dep × candidate file) | VAR × candidate stem | `_SETTER_CACHE`(P)/cfg_cache(T) |
| 18 | `recurse.py:925` `route.reachable` | 🔥 full route walk per (dep × off-chain file × hop), bounded `max_offchain_files=100` | VAR × off-chain file | `_reach_cache` (T) |
| 19 | `recurse.py:301-378` `_param_binding_setters` | 🔥 cfg of discovery + every candidate caller file + guards + reachability | VAR × caller file | cfg_cache (T) |
| 20 | `recurse.py:642` `find_cpp_writes_under_path` | 🔥 raw `.cpp`+tree-sitter full-file write scan for path-family descendants | VAR × scanned stem | `_FILE_WRITES_CACHE` (P) |

**Blueprint fields VBT reads at trace time** (everything else in the blueprint is ignored):
- `.cpp.json`: `call_graph.edges` (+`nodes`), `variable_lineage` (legacy C++ guard path only),
  `asm_entry_point_map` + `symbols.global_symbols` (entry-name expansion), `enum_values`
  (const-resolver build only).
- `.asm.json`/`.mac.json`: `blocks[*]` (+`flow`, `start_line`, `end_line`), `subroutines.flow`,
  `call_graph.edges`, `symbols` (constant filtering + entry names), `asm_entry_point_map`,
  `line_metadata.active_usings` + `meta.base_registers` + `dsect_layouts` (register-indirect).
- Large keys NEVER read at trace time: ASM `variable_lineage` (the multi-MB key),
  `line_metadata` (mostly), `macro_expansions`, `business_summary`, etc.

**Subprocess at trace time:** only `cfg_extract` (`wrapper.py:223`) on a cold cfg-cache miss
(+ one `xcrun` on macOS). Tree-sitter parsing is in-process. The intent is that cfg-warm
populates the cache during precompute so traces never shell out — but nothing enforces it.

---

## 3. (Req #2) Where runtime computation can be replaced by precomputation

Ranked by wall-clock impact at 22K scale (× N traces per job):

1. **cfg_extract subprocess per `.cpp`** (#8) — *already precomputed* (cfg-warm Step 5 → disk
   cache). The raw parse is covered; only **derived** structures over it are not (see #3, #4).
2. **RouteEngine corpus structures** (#5, #9) — reverse adjacency, `node_type`,
   `name_to_stems`, forward file adjacency. Pure functions of `file_call_graph.json`,
   **rebuilt every trace**. *Not precomputed.* Highest-value gap.
3. **name_resolver + membership resolver** (#4, #15) — pure functions of source, **rebuilt
   cold on every worker process, no disk artifact at all.** Clearest "add to precompute" win.
4. **CppFnGraph fn-level adjacency + `fn→file` map + per-file fn-start index** (#10) — the
   function-level call graph, **rebuilt every trace** from cfg + blueprint call graph.
   Directly answers the user's "function-file-call-graph" question (§9.5).
5. **Precise per-file setter sites + per-site enclosing-guard / "unconditional?" flag** (#6,
   #13, #17) — re-parsed across routes and traces. Subsumes the value-flow-prune re-parse.
6. **modifier_index / const_resolver** (#2, #3) — *already disk-precomputed.* Keep.

---

## 4. (Req #3) What should be precomputed

Computed once per job (deterministically, from data VBT already reads), then read at trace time:

| ID | Artifact | Derived from | Replaces (runtime) |
|---|---|---|---|
| **P1** | **File call graph** (nodes, edges, call_sites) | `file_call_graph.json` (SAME producer as index_db) | per-trace JSON load + payload parse (#5) |
| **P2** | **Reverse file adjacency** (`UPPER target/target_module → [(source_stem, instr)]`) + **node_type** map | P1 | `build_reverse_adjacency` per trace |
| **P3** | **Forward file adjacency** (file→file metadata superset for the scale prune) | P1 | `_build_forward_file_adj` per trace |
| **P4** | **`name_to_stems`** / entry-name index (`UPPER name → {owner_stem, type}`) | P1 nodes + per-blueprint `asm_entry_point_map`+`symbols` | `_entry_names` corpus sweep per trace |
| **P5** | **Function-level call graph** `(caller_stem, caller_fn) → [(callee_stem, callee_fn, line, cross)]` | blueprint `call_graph.edges` (re-attributed via cfg STARTs) + cfg + P1 ASM edges | `CppFnGraph._build` per trace (#10) |
| **P6** | **`fn → defining stem(s)`** map + per-file **`(start_line, fn)`** index + local-fn sets | cfg `function_starts` | `CppFnGraph._ensure_file` per trace |
| **P7** | **Name-alias map** (ASM↔C++ high-certainty aliases) | cc/gen/mac triples | `name_resolver` cold build per process (#4) |
| **P8** | **Membership map** (`name,lang → memberOf{struct/dsect}, counterpart`) | headers + DSECTs + P7 | `membership._build` per process (#15) |
| **P9** *(later)* | **Precise per-file setter sites** (var, stem, fn, line, value, `unconditional?`) | tree-sitter / ASM flow | `find_cpp/asm_setters_in_file` re-parse (#6, #13, #17) |

P5/P6 are the function-level call graph the user asked about (§9.5). P1–P4 are the call-graph
DB representation. P7/P8 close the no-persistence gap. P9 is the deepest/riskiest, deferred.

---

## 5. (Req #4) Where it should be stored in DB

**Policy.** New **VBT-namespaced tables** (`vbt_*` prefix) in the **existing** `index_db`
(`api/index_db/`), keyed on the same `job_id` used by `get_engine(job_id)` →
`jobs/<id>/index.db` (SQLite per-job) or shared Postgres (rows partitioned by `job_id`).
Do **not** reuse `variable_modifiers` (different provenance). Reuse `call_graph_nodes/edges`
for P1 only (same producer); everything else gets fresh `vbt_*` tables so VBT owns its
provenance and the parser pipeline is untouched.

**Storage directive (revised): DB everywhere, no files at trace time.** Per the scaling
requirement, *all* data the trace consumes moves into `index_db` — including the things a
pure architecture pass would have left on disk:
- cfg cache → DB blobs keyed `(job_id, stem)` (still produced once by cfg-warm; see T8 for the
  one honest trade-off: this is a storage-location move, not a CPU move, and it gives up
  cross-job content-addressed cfg sharing).
- ASM `blocks`/`flow`/`symbols`/`dsect_layouts` → DB (per-stem blob + small tables; see T7).
- raw `.cpp`/`.asm` source text → DB (`vbt_source`; see T9) so output slicing / constant
  scans / raw-line fetches read from DB.
- `modifier_index` / `const_resolver` → DB (T3/T4) even though they already have disk
  artifacts, so nothing is read from the filesystem during a trace.

The only filesystem reads that remain are at **precompute** time (one pass over blueprints +
source to populate the DB) — never during a trace.

Proposed schema (sketch — column lists firmed up per step):

```
-- P1: reuse existing call_graph_nodes / call_graph_edges (same producer)

-- P2/P3/P4 (graph-derived; tiny, ~O(files)):
vbt_fwd_file_adj(job_id, source_stem, target_stem)                 -- index (job_id, source_stem)
vbt_entry_name(job_id, upper_name, owner_stem, owner_type)         -- index (job_id, upper_name)
-- node_type + reverse adjacency are cheap to derive from P1 at load; store only if profiling shows need

-- P5/P6 (function-level call graph — the headline precompute):
vbt_fn_decl(job_id, stem, fn, start_line, is_local, is_external)   -- index (job_id, stem), (job_id, fn)
vbt_fn_call_edge(job_id, caller_stem, caller_fn, callee_stem, callee_fn, line, cross)
                                                                    -- index (job_id, caller_stem, caller_fn)

-- P7/P8 (source-derived resolvers):
vbt_name_alias(job_id, name, lang, alias, alias_lang, certainty)   -- index (job_id, name, lang)
vbt_membership(job_id, name, lang, member_of, member_kind, counterpart, counterpart_kind)

-- P9 (later): vbt_setter_site(job_id, var, stem, fn, line, set_value, unconditional)

-- bookkeeping: a manifest/version row so loaders can detect staleness exactly like the
-- disk artifacts do (per-file (path,size,mtime) hash + artifact version):
vbt_precompute_manifest(job_id, artifact, version, source_hash, built_at)
```

Every table carries `job_id` (matches the existing schema convention, `schema.py:5-6`).
Staleness is enforced by `vbt_precompute_manifest.source_hash` mirroring the existing
manifest-hash mechanism (`modifier_index.py:400-416`) — a loader compares the stored hash to
the live source set and falls back to runtime computation on mismatch (never serves stale).

---

## 6. (Req #5) How tracing should consume it from DB

**Principle: a single resolution helper per artifact, identical signature to today's builder,
with a 3-tier resolution order — and runtime computation always remains the source of truth
for correctness.**

For each artifact, introduce a thin accessor (e.g. `get_route_context(job_id, blueprint_dir,
graph_file)`) that:
1. **DB tier:** if `job_id` is set and `vbt_precompute_manifest` matches the live source hash,
   load the precomputed rows and build the in-memory structure the engine already expects
   (same object shape: e.g. populate `RouteEngine._reverse_adj`/`_node_type`/`_fwd_file_adj`,
   or return the `CppFnGraph.adjacency()` dict).
2. **Disk-artifact tier** (for P7/P8 if we choose disk over DB): manifest-hashed JSON under
   `$VBT_CACHE_DIR`, same pattern as `modifier_index`/`const_resolver`.
3. **Compute tier (fallback):** the exact current code path. **Behavior is unchanged when DB
   is absent or stale** — CLI runs with no `job_id` keep working identically.

Wiring points:
- Thread `job_id` from the Celery tasks into `trace_root_variable` (currently dropped:
  `route.py:89` passes `None`). When `job_id` is `None` (pure CLI), the compute tier runs —
  **no behavior change**.
- `RouteEngine.__init__` / `get_cpp_fn_graph` / `resolve_aliases` / `get_membership_resolver`
  gain an optional precomputed-context param; if provided, they populate their caches from it
  instead of building. This is the minimal-surface change: the *consumers* of these caches
  are untouched, so the trace logic downstream is bit-for-bit identical.

The contract that guarantees "no output change": **precompute emits exactly the structure the
runtime builder would have built**, verified by a shadow-equality test (§11). The trace then
walks the identical structure.

---

## 7. (Req #6) Parser dependencies that can be removed/minimized

- **No parser-pipeline changes.** VBT computes everything itself from blueprints/source it
  already reads, then persists. The parser's `pipeline_task.py` is untouched.
- **At trace time, after precompute lands:**
  - The corpus-wide blueprint sweep in `_entry_names`/`name_to_stems` (loads **every**
    blueprint, #5) → replaced by P4 lookups. Removes the biggest per-trace blueprint-LRU
    thrash source.
  - The per-trace `cpp_call_edges` + cfg re-attribution for every reachable file (#10/#11) →
    replaced by P5/P6.
  - `name_resolver`/`membership` cold rebuild (#4/#15) → replaced by P7/P8.
- **Still required at trace time** (cannot be removed without changing outputs): cfg cache
  reads (for guard/terminator detail inside functions), ASM `blocks`/`flow` reads for setter
  sites / conditions / register-indirect, raw source slicing for output. These stay as files.
- **Provenance constraint:** VBT may read `call_graph_nodes/edges` (P1, same producer) but
  must keep computing its own modifier index, const resolver, and setter sites (different
  producers / source-derived). This is the line that protects "no output change."

---

## 8. (Req #7) CLI commands for VBT-only precomputation

Extend, don't replace. Two surfaces, both VBT-only, neither touching the parser:

1. **`python -m vbt.precompute_all … [--job-id ID] [--db]`** — the existing CLI gains optional
   DB persistence. New steps after the current ones:
   - Step 7: build + persist P2–P4 (graph-derived) into `vbt_*` tables.
   - Step 8: build + persist P5/P6 (function-level call graph).
   - Step 9: build + persist P7/P8 (resolvers) — also gives them their first disk artifact.
   - Each writes a `vbt_precompute_manifest` row. With no `--db`/`--job-id`, behavior is
     unchanged (artifacts stay on disk only).
2. **`python -m vbt.precompute_db --job-id ID`** *(thin wrapper / or a subcommand)* — populate
   only the `vbt_*` DB tables for an already-precomputed project (re-runnable backfill,
   mirrors `scripts/backfill_index_db.py`). Useful to backfill existing jobs without redoing
   cfg-warm.
3. **Production:** `api/tasks/vbt_precompute_task.run_precompute` (already keyed on `job_id`,
   already resolves `blueprint_dir`/`asm_dir`) calls the same builders and writes the `vbt_*`
   tables as additional steps. This is where the 22K runs actually get their speedup.

---

## 9. The five "important examples" — direct answers

**9.1 `file_call_graph` — why/where/DB?**
Used for cross-file reachability: reverse adjacency (who-calls-X) for the route walk, forward
adjacency for the scale prune, `name_to_stems` for entry-name resolution, and ASM-source
cross edges for the fn-level graph. Read once per trace via `route.py:85-90`
(`_load_graph_payload`) and re-derived into adjacency structures **every trace**. It is small
(~5 MB at ~150 files; modest at 22K) and **already round-trips through index_db with the SAME
producer** (`get_call_graph`, used by the legacy chainless runner). **DB-representable: yes**
(reuse `call_graph_nodes/edges` for P1; add `vbt_fwd_file_adj`/`vbt_entry_name` for the
derived parts). The win is precomputing the *derived adjacency*, not the raw file.

**9.2 Blueprints — why/where/required-at-trace/DB?**
Blueprints are `zstd(msgpack)` with seekable per-key frames. VBT reads a small subset at
trace time (§2). **Required at trace time: yes**, for ASM `blocks`/`flow` (setter sites,
conditions, register-indirect) and C++ `call_graph.edges`. **DB representation:** the
*small/aggregate* parts (`enum_values`→const resolver, `asm_entry_point_map`+`symbols`→P4,
`call_graph.edges`→P5) should be precomputed into DB; the *large nested* parts
(`blocks`/`flow`, `variable_lineage`) should stay as seekable frames (one seek-load per stem).
Moving the whole blueprint into DB is not worth it.

**9.3 Parser JSONs read during tracing — list / DB-able / VBT-only?**
- `file_call_graph.json` — DB-able (P1–P4), VBT-only precompute.
- blueprints (`*.cpp.json`/`*.asm.json`/`*.mac.json`/`*.hpp.json`) — partial DB (aggregate
  keys → P4/P5/const); large keys stay files.
- cfg cache JSON (`$VBT_CACHE_DIR/cfg/*.json`) — keep as content-addressed files; **not** DB.
- modifier_index / const_resolver artifacts — already disk; keep (optional DB mirror later).
- GVL / universe / identity / hop JSONs — **VBT does not read these** (legacy engines do).

**9.4 Expensive computations — repeated across runs/files/functions?**
Yes: RouteEngine adjacency + `name_to_stems` (per trace), `CppFnGraph` (per trace),
name/membership resolvers (per process, no disk), and setter-site tree-sitter re-parses
(across routes/traces). All are functions of the call graph + cfg + source, **not** of the
traced variable → precompute once per job. Storage strategy in §5.

**9.5 Function-file call graph (nodes = C/C++ functions + ASM files) — useful?**
**Yes — and VBT already builds exactly this at trace time and throws it away.**
`vbt/reach/cpp_routes.py` (`CppFnGraph`, lines 87-307) builds a unified graph whose nodes are
`(stem, fn)` for C++ functions and `(asm_stem, asm_stem)` single-entry nodes for ASM modules,
with edges = calls (intra-file, cross-file C++, and C++→ASM), re-attributing `(global)`
callers via cfg function-START lines. It exists *because* the file-level graph under-counts
routes. It is rebuilt for **every trace** and never persisted. **Precomputing it once per job
(P5/P6) is the single highest-value structural precompute** and is precisely the user's
suggestion. Recommendation: build it. ASM stays file-level (a module is single-entry); C++ is
function-level.

---

## 10. (Req #8) Risk assessment

| Risk | Likelihood | Severity | Mitigation |
|---|---|---|---|
| Precomputed structure ≠ runtime-built structure → **output changes** | Med | **Critical** | Shadow-equality tests (§11): precompute output must `==` runtime build for the golden set, gated in CI. 3-tier fallback always allows compute tier. |
| Stale precompute served after source edit | Med | High | `vbt_precompute_manifest.source_hash` (same per-file (path,size,mtime) hash as existing artifacts); loader falls back to compute on mismatch, never serves stale. |
| Accidentally reading legacy `variable_modifiers` (different provenance) | Low | **Critical** | Hard rule: VBT never reads `variable_modifiers`. Only `call_graph_nodes/edges` (P1) reused. New `vbt_*` tables for everything else. Lint/test asserts no such import path. |
| SQLite-per-job write contention during parallel precompute | Low | Med | Precompute writes are single-task per job; batch inserts (existing `writers` pattern). WAL already on. |
| `job_id=None` (CLI) path regresses | Low | High | Compute tier is the unchanged code path; CLI tests run with no DB and assert byte-identical output. |
| DB absent / Postgres unreachable in headless runs | Low | Med | Graceful fallback to disk artifact then compute tier; DB read failures log + fall through (mirrors `readers._is_strict`). |
| `ensure_call_graph` staleness vs DB call graph diverge | Low | Med | P1 loader checks the same mtime/source-hash; on mismatch, rebuild + re-ingest before trace. |
| cfg-derived re-attribution (P5/P6) sensitive to cfg version/flags | Med | High | Manifest includes cfg binary mtime + parse flags (already in the cfg cache key); rebuild P5/P6 if cfg key set changes. |

---

## 11. (Req #9) Regression testing strategy — proving outputs identical

**The proof obligation is byte-identical trace JSON.** Three layers:

1. **Golden byte-identical baseline (the gate).** Before any change, capture
   `json.dumps(trace_root_variable(...), sort_keys=True, indent=2)` (canonicalized — robust to
   any residual set/dict-order drift while still catching real content changes) for a fixed
   variable set. **Confirmed runnable corpus (the pinned pairing):**
   - **blueprint-dir** = `jobs/1ffa983c-3282-42f2-9701-a4c3f21451b1/output/asm 5` (note the
     space; has the `.json` blueprints + `file_call_graph.json`);
   - **asm-dir (source)** = `datasource/asm7_admin/asm 7_version_0/asm 5` (the matching source
     — 109 cpp / 41 asm / 24 mac / 42 hpp; every cpp blueprint has a source, **zero gaps**).
   - This pairing runs the canonical `softCardValue` C++ trace clean (1316 setter-chain
     tuples, ~32s, 23 MB) — verified **byte-identical across cold→warm cfg cache** (SHA-256
     `c98d8823…`). The documented `jobs/baseline-temp-asm` fixture is absent and **not needed**
     — do NOT pair the 1ffa983c blueprints with `temp/asm` (4 missing cpp sources →
     `FileNotFoundError`).
   - Curated set: `softCardValue` root-only (`disable_dependents`) + `softCardValue` depth-1
     (default, exercises dep-var recursion) + `LG1OSI`@`da78` (asm) + a sample of modifier-index
     vars. Goldens stored locally (gitignored; ~23 MB each) with a committed SHA-256 manifest.
   After each step, re-run and assert **byte-identical** to the golden. Any diff → §11.2.

2. **Shadow-equality (proves precompute == runtime, not just final output).** A test/env mode
   that, when loading a precomputed artifact, *also* computes it the old way and asserts
   deep-equality of the structure (reverse adj, fn adjacency, alias map, …). This catches a
   precompute bug that happens not to affect the golden variables but would affect others.

3. **Round-trip unit tests per builder.** build → persist → load → `==` in-memory build, for
   each of P1–P8. Plus the existing `vbt/tests` suite (currently green) must stay green, and
   `api/tasks/test_vbt_*` tasks.

4. **Deterministic / canonical serialization (closes the silent-divergence hole).** Every
   precompute builder must emit a **canonically ordered** structure (sorted keys, sorted edge
   lists, stable dedup) so that "build it twice → identical bytes" and so set/dict iteration
   order can never make the DB copy differ from the runtime copy. A determinism test
   (build×2 → identical) runs per builder. This is the most common way a "behavior-preserving"
   refactor silently isn't.

5. **Broad-sample + production shadow (covers variables the golden set doesn't).** Golden only
   proves the variables we picked. Before flipping an artifact on in production, run
   shadow-equality over a **large sample** of variables (e.g. the full modifier-index key set,
   or all VbtTableCache'd variables for the job), not just the golden handful. Optionally run a
   **production shadow period** per artifact: compute *both* DB and runtime, **serve the
   runtime result**, log any mismatch — flip to trusting DB only after the mismatch rate is
   zero over real traffic.

**Reused-table freshness (T5 only).** The one table VBT *reads* that the parser also writes is
`call_graph_nodes/edges`. Before trusting it, the loader checks the same source-hash/mtime the
disk artifacts use; on any mismatch it rebuilds + re-ingests (VBT can repopulate it itself —
same producer) rather than serving a stale parser-written graph.

**Acceptance per step:** (golden byte-identical) ∧ (shadow-equality passes on golden **and**
the broad sample) ∧ (determinism test passes) ∧ (existing suite green) ∧ (negative path: DB
removed/empty → byte-identical via compute fallback) ∧ (measured wall-clock improvement on the
22K/real job). Only then move to the next step.

### 11.1 Zero-regression policy (the prime directive)

**Byte-identical output ranks above the speedup.** A step that is faster but changes any
output is **not shippable** until the diff is explained and explicitly classified by the user.
No diff ships silently — not even a "better" one.

**Test everywhere, not a sample.** The standard acceptance run is **corpus-wide parity**: for
the job under test, run *every* variable through both paths (DB and compute) and assert
byte-identical end-to-end output + structural shadow-equality. A representative sample is only
a fallback for interactive iteration, and if coverage is ever capped it must be **logged
explicitly** (consistent with the engine's existing "never truncate silently" rule) — a
skipped variable is reported, never quietly dropped.

### 11.2 Diff-triage protocol — what happens the instant any byte differs

Any diff (end-to-end or shadow-equality) **halts the step**. We then produce a **diff
dossier** and make a decision — we never edit the golden to make red turn green.

1. **Dossier (required for every diff):**
   - exact output location (JSON path / dep-var / setter id), old value → new value;
   - the precise code-level root cause (which builder, which line, which mechanism);
   - which class it falls in: **(a) ordering/serialization**, **(b) staleness / different
     input data**, **(c) scope (job-wide superset vs trace-scoped build)**, **(d)
     order-before-truncation (a cap kept a different subset)**, **(e) float/int/encoding
     round-trip**, or **(f) genuine semantic difference** (the old path had a latent bug, or
     was nondeterministic, and the new value is verifiably right against ground truth —
     source / the golden lineage docs).
2. **Classification:**
   - **REGRESSION** = the diff is caused by the mechanism (classes a–e) with no semantic
     justification, **or** the new value is wrong / less correct. → **Must fix. Do not
     proceed.** These are bugs in our precompute, not improvements. The fix is to make the
     precompute path reproduce the old computation exactly (canonical ordering, freshness
     check, preserve scope, preserve candidate order before caps).
   - **PROGRESSION** = class (f): the new output is provably *more* correct because the old
     path had a real defect, validated against ground truth — not just "looks plausible."
3. **Decision gate (yours, not mine):** even a confirmed **progression does NOT ship inside a
   perf step.** The perf work's contract is byte-identical. A progression is surfaced to you
   with its dossier; if you accept it, it lands as a **separate, explicitly-labelled
   behavioral change** with its own golden update — *after* the perf step has been made
   byte-identical (e.g. by reproducing the old behavior, merging perf, then applying the fix
   on top as its own commit). This keeps "did we change speed?" and "did we change behavior?"
   permanently separable in the history.
4. **Default when uncertain:** treat as **REGRESSION** and block. The burden of proof is on
   "progression"; ambiguity never ships.

**Net:** if every step is held to corpus-wide byte-identical parity, the only diffs that can
appear are pre-existing nondeterminism or latent bugs — and both are routed to you with an
exact explanation and a regression/progression verdict before anything changes.

---

## 12. The four guarantees these tasks must deliver

This tracker is designed so that, when complete, **every** one of the following holds. Each
task below is annotated with which guarantees it advances.

- **G1 — No heavy CPU at trace time.** All parsing (tree-sitter), the Clang `cfg_extract`
  subprocess, graph construction, adjacency building, alias/membership building, and
  const/modifier scanning happen **once, in precompute**. A trace becomes: indexed DB reads +
  in-memory walks over precomputed graphs + the variable-specific traversal logic. Trace cost
  then scales with the trace's own fan-out, **not** with corpus size and **not** with
  re-parsing.
- **G2 — No regressions.** Every task ships behind the 3-tier resolver (DB → disk → unchanged
  compute fallback) and is accepted only on **golden byte-identical** output + **shadow-
  equality** (precompute structure `==` runtime-built structure) + green suite.
- **G3 — Read from DB, not files.** After T5–T9 a trace opens **zero** files: no blueprints,
  no `file_call_graph.json`, no cfg JSON, no raw source. All of it is served from `index_db`.
- **G4 — No reliance on the parser pipeline.** Every artifact is computed by **VBT's own
  code** from blueprints/source during a dedicated VBT precompute (one read pass), then stored
  in DB. `pipeline_task.py` is never modified. The only table VBT *reads* that the parser also
  writes is `call_graph_nodes/edges` — and only because it is the **same producer**
  (`file_call_graph.CallGraphBuilder`); VBT can equally repopulate it itself.

### What remains irreducibly per-trace (honest boundary)

"Precompute everything possible" has a real boundary: the **backward-traversal decision
logic** is variable-specific and must run per trace — *which* setters are reachable from the
chain tail, the route DFS over the precomputed function graph, dependent-variable recursion,
and final output assembly. The point of the tracker is that after T0–T11 this logic runs as
**pure DB reads + in-memory graph walks with no parsing, no subprocess, and no file I/O** —
so it is cheap and bounded by the trace's own size, which is what makes 22K scale viable.

---

## 13. (Req #10) Development tracker — detailed, per task

Implement top-to-bottom. Per task: explain → add/update tests → run regression → prove
byte-identical → next. Status ∈ {TODO, IN-PROGRESS, BLOCKED, DONE}.

Phases: **0 Foundations → 1 Source-derived resolvers (low risk) → 2 Graph structures
(headline) → 3 Per-stem parser/source/cfg data (kills the last file reads) → 4 Production
wiring.**

### Phase 0 — Foundations

**T0 — Regression & performance harness.** *(advances G2)*
- *What it does:* Builds the proof + measurement scaffold before touching anything. (1) A
  golden-capture script that runs `trace_root_variable` for a frozen variable set
  (`softCardValue` + dep vars, `LG1OSI`, `aa71`, the R/D fixtures) on pinned jobs
  (`1ffa983c-…`, `baseline-temp-asm`) and stores `indent=2` JSON as golden files. (2) A
  shadow-equality helper: an env/pytest mode where loading any precomputed artifact *also*
  runs the old compute path and asserts the two structures are deep-equal. (3) Per-phase
  wall-clock + RSS timing to prove the speedup.
- *DB/precompute:* none (infra only).
- *Files:* `vbt/tests/golden/`, new `vbt/tests/test_golden_trace.py`, a harness script.
- *Risk:* Low. *Regression:* this task *is* the gate. *Status:* **DONE** — harness at
  `vbt/tests/parity/` (`cases.py` pinned corpus + curated cases, `capture_golden.py`,
  `check_parity.py` with §11.2 dossier, `shadow.py` scaffold) + `vbt/tests/test_parity_gate.py`
  (3 passed, 32.6s). Fast goldens captured (softCardValue_root: 1316 setters, sha `e29182ce…`;
  LG1OSI_asm: 1 setter/1 dep, sha `0d222518…`); determinism verified (LG1OSI run×2 identical;
  softCardValue cold→warm identical). depth-1 golden captured (1316 setters, 61 dep vars, sha
  `ce63e6f2…`, ~5min) and determinism CONFIRMED (re-run byte-identical). Goldens gitignored,
  manifest committed. Corpus pairing recorded in §11. Gate is trusted for light + heavy paths.

**T1 — VBT DB plumbing & 3-tier resolver foundation.** *(advances G2, G3, G4)*
- *What it does:* Lays the rails every later task rides. Threads `job_id` from the Celery
  tasks (`vbt_table_task`/`vbt_trace_task`) through `trace_root_variable` down to
  `RouteEngine` (today `route.py:89` passes `None`, so the DB path is never reached). Adds the
  `vbt_precompute_manifest` table + a manifest helper that mirrors the existing per-file
  `(path,size,mtime)` source hash. Establishes the generic resolver contract
  **`db_load → disk_artifact → compute`**, where `compute` is the unchanged current code and
  is always correct. Adds empty `vbt_*` schema + reader/writer stubs.
- *DB/precompute:* `vbt_precompute_manifest`; schema scaffolding.
- *Files:* `api/index_db/{schema,readers,writers}.py`, `vbt/engine.py`, `vbt/reach/route.py`,
  `api/tasks/vbt_table_task.py`, `api/tasks/vbt_trace_task.py`.
- *Risk:* Low (no artifact moved; `job_id=None` → compute tier → byte-identical).
  *Regression:* golden unchanged with DB empty; CLI path identical. *Status:* **DONE** —
  job_id plumbed engine (`engine.py` sig + `RouteEngine(...)` call) → `RouteEngine.job_id` →
  `_load_graph_payload(graph_file, self.job_id)` (route.py:89 no longer hardcodes `None`);
  both Celery tasks forward it via the sig-filter (`vbt_table_task` `wanted_kwargs["job_id"]`,
  `vbt_trace_task` `accepted["job_id"]`). Added `vbt_precompute_manifest` table (additive, no
  version bump) + `vbt/precompute/db_artifacts.py` (`source_manifest_hash`, 3-tier
  `resolve_artifact`, manifest read/write/`manifest_fresh`) + `vbt/tests/test_db_artifacts.py`
  (8 passed). **Parity: fast gate IDENTICAL with job_id=None AND byte-identical with job_id
  set to the real id**; suite collects 174, 136 passed / 34 skipped. NOTE: one PRE-EXISTING
  red — `test_uiexport_structural.py::test_expresspay_setter_has_lstknpoa_guard` (static
  fixture `vbt/trace_softCardValue_d3`; fails on pre-T1 code too, A/B-verified; unrelated to
  this work). depth-1 heavy-case parity CONFIRMED IDENTICAL (sha `ce63e6f2…`) — full curated
  set byte-identical.

### Phase 1 — Source-derived resolvers (lowest risk, proves the methodology)

**T2 — name_resolver + membership → DB (P7/P8).** *(G1, G2, G3)*
- *What it does:* These resolvers are pure functions of source and today are rebuilt **cold on
  every worker process with no persistence at all** (#4, #15) — the clearest gap. Precompute
  the ASM↔C++ alias map and the membership map (`name,lang → memberOf/counterpart`) once;
  store in `vbt_name_alias`/`vbt_membership`. At trace time `resolve_aliases` /
  `get_membership_resolver` populate their caches from DB instead of globbing + parsing every
  `cc/gen/mac` triple, header, and `.mac`.
- *Kills at trace time:* glob + parse of all triples/headers/`.mac` (CPU + file reads).
- *Files:* `vbt/resolve/name_resolver.py`, `vbt/resolve/membership.py`, `vbt/precompute_all.py`,
  new readers/writers.
- *Risk:* Low. *Regression:* round-trip + shadow-equality + golden. *Status:* **DONE** (pending
  heavy-case confirm) — implemented **without editing the resolver query logic**: persist the
  built intermediate state (per-unit alias maps; the 4 membership indexes) and pre-fill
  `_UNIT_CACHE`/`_MAP_CACHE` + reconstruct the `MembershipResolver` from DB at trace start, so
  `resolve()` runs byte-identically. New: `vbt_artifact_blob` table; `db_artifacts` gz-JSON +
  blob read/write; `vbt/precompute/resolvers_db.py` (build/serialize/load + `preload_resolvers`
  self-warming: load-if-fresh else build+persist); engine calls `preload_resolvers` only when
  `job_id` set. **Proof:** round-trip behavior tests (alias+membership `resolve()` identical
  after gz/JSON round-trip) + deterministic-bytes test (15 unit tests pass); full-trace parity
  **IDENTICAL** for (a) `job_id=None` compute path, (b) `job_id` set COLD build+write, (c)
  `job_id` set WARM in a fresh process (preload from DB). Suite: 143 passed / 34 skipped, no new
  failures (same 1 pre-existing `lstknpoa`). depth-1 heavy-case (job_id set) **IDENTICAL** —
  fully verified.

**T3 — const_resolver → DB.** *(G1, G3)*
- *What it does:* enum/EQU/DC constant→value resolver. Already disk-cached, but per the
  DB-everywhere directive mirror it to `vbt_enum_const`/`vbt_asm_const`; trace reads from DB.
- *Kills at trace time:* disk-artifact reload + (cold) full-corpus enum/EQU/DC scan.
- *Files:* `vbt/resolve/const_resolver.py`, `vbt/precompute_all.py`, readers/writers.
- *Risk:* Low. *Regression:* round-trip + shadow-equality + golden. *Status:* **DONE** (pending
  heavy confirm) — added const to `resolvers_db` (blob of `cpp_enum`+`asm_const`; loaded into
  `const_resolver._CACHE`, honored by `get_const_resolver`'s cache-first path); own source-hash
  via `const_resolver._source_files` + `_ARTIFACT_VERSION`. 16 unit tests pass (const round-trip
  + `bare_cpp_const_names` identical); parity IDENTICAL for job_id=None / cold / warm (const blob
  present). depth-1 (job_id) **IDENTICAL** — fully verified.

**T4 — modifier_index → DB (VBT's OWN; never the legacy `variable_modifiers`).** *(G1, G3, G4)*
- *What it does:* var/field/fn→stems + setter sites + functions. Already disk-cached; mirror
  **VBT's own computed index** to `vbt_modifier_files`/`vbt_modifier_sites`/
  `vbt_function_files`. **Hard provenance rule:** do NOT read the legacy `variable_modifiers`
  table — it is a different producer (C++ from GVL edges; no MVC/register-indirect) and would
  change outputs.
- *Kills at trace time:* disk-artifact reload + (cold) full-corpus tree-sitter/blueprint scan.
- *Files:* `vbt/precompute/modifier_index.py`, `vbt/precompute_all.py`, readers/writers.
- *Risk:* Low–Med (provenance discipline). *Regression:* round-trip + shadow-equality + golden.
  *Status:* **DONE** (pending heavy confirm) — added modifier_index to `resolvers_db` as a
  VBT-owned `modifier_index` blob (asm/cpp/functions stem-sets + asm_sites/cpp_sites
  `SetterSiteRef` tuples; sets→sorted lists, rebuilt via `SetterSiteRef(*row)`), loaded into
  `modifier_index._CACHE` (honored by `get_modifier_index`'s cache-first path). **Provenance:
  never reads the legacy `variable_modifiers` table.** 17 unit tests pass (round-trip preserves
  `files_for`/`sites_for`/`files_defining_function`); parity IDENTICAL for job_id=None / cold /
  warm (modifier_index blob present). depth-1 (job_id) **IDENTICAL** — fully verified.

### Phase 2 — Graph structures (the headline wins)

**T5 — Call-graph + derived adjacency (P1–P4) → DB.** *(G1, G2, G3)*
- *What it does:* Reuse the existing `call_graph_nodes/edges` (SAME producer → safe) for the
  raw graph. Precompute the structures `RouteEngine` rebuilds **every trace**: reverse file
  adjacency, `node_type`, `name_to_stems` (entry-name index), forward file adjacency. Store
  `name_to_stems → vbt_entry_name`, forward adj → `vbt_fwd_file_adj` (reverse adj/node_type
  are cheap to derive from P1 on load). At trace time `RouteEngine` populates
  `_reverse_adj`/`_node_type`/`_fwd_file_adj`/`_name_to_stems` from DB.
- *Kills at trace time:* loading **every** blueprint for `_entry_names` (the biggest
  blueprint-LRU thrash) + rebuilding adjacency on every trace.
- *Files:* `vbt/reach/route.py`, `vbt/engine.py`, `vbt/precompute_all.py`, index_db files.
- *Risk:* Med. *Regression:* round-trip + shadow-equality (adj/node_type/name_to_stems) +
  golden + CLI(no-DB). *Status:* **DONE** (pending heavy confirm) — `vbt/precompute/graph_db.py`
  persists `name_to_stems` (the per-blueprint `_entry_names` corpus sweep, the biggest route-layer
  blueprint thrash) as the `route_name_to_stems` blob; engine pre-fills `RouteEngine._name_to_stems`
  after construction (memoized field → sweep skipped), forward-reachable prune derives from it +
  the already-loaded payload. Content identity-preserving across round-trip. 3 unit tests pass
  (map round-trip + forward_reachable preserved + deterministic bytes); parity IDENTICAL for
  job_id=None / cold / warm (blob present). NOTE: only `name_to_stems` persisted (the expensive
  bit); reverse_adj/node_type/fwd_file_adj derive cheaply from the payload that loads anyway.
  depth-1 (job_id) **IDENTICAL** — fully verified.

**T6 — Function-level call graph (P5/P6) → DB. [THE headline — your function-file graph]** *(G1, G2, G3)*
- *What it does:* Precompute exactly what `CppFnGraph` builds per-trace and discards: the
  unified `(stem,fn) → [(callee_stem, callee_fn, line, cross)]` adjacency (nodes = C++
  functions + single-entry ASM modules), the `fn → defining-stem` map, and the per-file
  `(start_line, fn)` index + local-fn sets. Built from blueprint `call_graph.edges`
  re-attributed via cfg function-STARTs + the file-level ASM edges. Store in
  `vbt_fn_decl`/`vbt_fn_call_edge`. At trace time `get_cpp_fn_graph` loads the adjacency from
  DB and runs only the variable-specific DFS (tail→setter).
- *Kills at trace time:* per-trace cfg re-attribution + `cpp_call_edges` parse for **every**
  reachable file.
- *Files:* `vbt/reach/cpp_routes.py`, `vbt/reach/fn_attr.py`, `vbt/engine.py`,
  `vbt/precompute_all.py`, index_db files.
- *Risk:* High (route counts must match exactly). *Regression:* round-trip + shadow-equality
  (adjacency dict) + golden (exact route counts). *Status:* **DONE** (pending heavy confirm) —
  **SAFE REALIZATION:** rejected precomputing a full-corpus adjacency + DFS (would diverge from
  the per-trace *forward-reachable-scoped* `_fn_to_file` build → could change route counts).
  Instead precomputed the expensive per-stem INPUT — `RouteEngine.cpp_call_edges` (blueprint
  call-graph read + cfg-reattribution per cpp stem) — and pre-fill `route._edge_cache`
  (cache-first method → byte-identical edges). The `CppFnGraph` build stays per-trace + reachable-
  scoped (cheap dict ops). `graph_db.build_and_store_cpp_call_edges` (precompute-only, O(corpus))
  + `preload_cpp_call_edges` (LOAD-ONLY in the trace — no-op on cold DB so a cold first trace is
  NOT O(corpus); per-stem lazy build unchanged). cfg side of the build (`_ensure_file`
  starts/local) is handled by T8 (cfg→DB), not duplicated here. 4 graph_db unit tests pass;
  parity IDENTICAL for job_id=None / cold(no blob, no-op) / warm(109 cpp stems loaded). depth-1
  (warm) **IDENTICAL** — fully verified.

### Phase 3 — Per-stem parser / source / cfg data (eliminates the LAST file reads → G3)

**T7 — ASM per-stem structural data → DB.** *(G1, G3, G4)*
- *What it does:* The remaining blueprint reads at trace time are ASM `blocks`/`flow`/
  `symbols`/`dsect_layouts`/`line_metadata.active_usings`, used by the ASM setter-site scan,
  `collect_asm_conditions`, and register-indirect resolution. Precompute these per stem into
  DB (`blocks`/`flow` as a per-stem JSON blob keyed `(job_id, stem)`; `symbols`/`dsect` as
  small tables). At trace time those paths read from DB instead of `load_json(blueprint)`.
- *Kills at trace time:* `load_json` for every ASM stem touched. After T5+T6+T7, **a trace
  opens no `.json` blueprint at all.**
- *Files:* `vbt/engine.py`, `vbt/setters/asm_setters.py`, `vbt/conditions/asm_conditions.py`,
  `vbt/resolve/register_indirect.py`, `backward_traversal/utils/blueprint_utils.py` (read
  shim), index_db files.
- *Risk:* Med–High. *Regression:* round-trip + shadow-equality + golden (ASM
  setters/conditions byte-identical). *Status:* **DONE** (pending heavy confirm) — gated,
  decoupled override hook in shared `blueprint_utils.load_json` (`set/clear_blueprint_override`;
  `None` by default → zero legacy effect). `vbt/precompute/asm_db.py` stores each ASM/MAC
  blueprint dict per stem (`asm_bp:<stem>` blob; WHOLE dict, JSON-lossless — no key dropping) +
  an `asm_blueprints` freshness manifest; `install_asm_blueprint_override` serves THIS job's
  ASM blueprints from DB lazily (per stem, cached) — scale-correct (no upfront blob). Build is
  precompute-only; trace installs LOAD-ONLY (cold DB → not installed → disk, byte-identical).
  Engine CLEARS the override every trace (so job_id=None never inherits a prior job's). 2 unit
  tests pass (gz round-trip lossless + override serve/clear); parity IDENTICAL for job_id=None /
  cold(not installed) / warm(65 ASM blueprints from DB). depth-1 (warm) **IDENTICAL** — fully verified.

**T8 — cfg cache → DB blobs, content-hash keyed, batched writes.** *(G1 already met; G3)*
- *What it does:* The Clang `cfg_extract` subprocess is the dominant CPU cost and is **already
  moved to precompute** (cfg-warm). Per the DB-everywhere directive, move the cfg *result
  store* from `$VBT_CACHE_DIR/cfg/*.json` files into DB blobs. This is a **storage-location**
  move, not a CPU move — the CPU was already removed by cfg-warm — so its only job is to
  satisfy G3 ("no files at trace time").
- *Design (decided):*
  1. **Content-hash-keyed blobs, not `(job_id, stem)`-keyed.** Store cfg as
     `vbt_cfg_blob(content_hash PRIMARY KEY, cfg_json/cfg_msgpack)` plus a pointer table
     `vbt_cfg_ref(job_id, stem, content_hash)`. `content_hash` = the **same fingerprint the
     file cache already computes** (source path/size/mtime + binary mtime + parse flags,
     `wrapper.py` `_cache_key`). This preserves cross-job/content-addressed dedup *inside* the
     DB — identical source+binary+flags share one blob even across jobs (relevant on shared
     Postgres) — so the one theoretical downside of going DB-only disappears. `_cfg_for` reads
     via the `(job_id, stem) → content_hash → blob` lookup.
  2. **Batched writes for parallel cfg-warm.** cfg-warm stays parallel for the *compute* (one
     `cfg_extract` subprocess per worker), but SQLite is single-writer, so workers **return
     their cfg result to the parent**, which **batch-inserts** under one writer (the existing
     `index_db` `writers` streaming-batch pattern, WAL + `busy_timeout` already on). No
     per-worker DB writes → no write contention, no slowdown. `INSERT OR IGNORE` on
     `content_hash` makes re-warm idempotent and dedup-on-write.
- *Kills at trace time:* filesystem reads of cfg JSON (`_cfg_for` reads DB).
- *Files:* `vbt/cpp_frontend/wrapper.py`, `vbt/precompute/parallel.py` (return-to-parent),
  `vbt/engine.py`, `api/tasks/vbt_precompute_task.py`, `api/index_db/{schema,readers,writers}.py`.
- *Risk:* Med. *Regression:* round-trip (blob decodes byte-identically to the file cache) +
  golden (embedded cfg-derived output unchanged) + a cfg-warm write-contention/idempotency
  test. *Status:* **DONE** (pending heavy confirm) — content-hash-keyed `vbt_cfg_blob` table
  (self-validating, no manifest); decoupled GET/PUT hooks in `run_cfg_extract`
  (`set/clear_cfg_db_hooks`, both `None` by default → zero effect). `vbt/precompute/cfg_db.py`
  installs **self-warming** hooks: cold trace reads warm disk cfg + PUTs each touched key to DB
  (incremental, bounded by reached files — not O(corpus)); warm trace GETs from DB. Engine
  clears+installs every trace (job_id=None → not installed → disk path unchanged). 2 unit tests
  (gz round-trip lossless + hooks serve identical); parity IDENTICAL for job_id=None / cold
  (107 cfg blobs self-warmed) / warm fresh-process (served from DB). depth-1 **IDENTICAL** — fully verified.

**T9 — Raw source text → DB.** *(G1, G3)*
- *What it does:* Trace time still reads raw `.cpp`/`.asm` for output code-block slicing
  (`CodeBlockStore`), `collect_constant_symbols` (`.asm`), `fetch_raw_line`, and the ts-guard
  fallback. Store source text per `(job_id, stem)` in `vbt_source` at precompute;
  `CodeBlockStore`/`fetch_raw_line`/constant scan slice from DB.
- *Kills at trace time:* the **last** filesystem source reads. After T9, a trace touches zero
  files.
- *Files:* `vbt/output/codeblocks.py`, `backward_traversal/utils/blueprint_utils.py`
  (`fetch_raw_line`/`_read_lines_cached`), `vbt/conditions/ts_guards.py`, index_db files.
- *Risk:* Med. *Regression:* golden (embedded `code`/`setterCodeChunk` byte-identical).
  *Status:* **DONE** (pending heavy confirm) — `set/clear_source_override` + `source_override_bytes`
  (raw bytes; `None` → caller's own disk read runs unchanged) in `blueprint_utils`. 3 vbt-trace
  source consumers route through it: `CodeBlockStore._lines` (decode default-enc to match
  `read_text`), `ts_enclosing_guards` (raw bytes), `collect_constant_symbols` ASM scan (decode
  utf-8). `vbt/precompute/source_db.py` stores each source file's raw bytes per name
  (`src:<name>`, gzipped) + `source` manifest; `install_source_override` serves lazily per file.
  Build precompute-only; trace installs LOAD-ONLY; engine clears every trace. const_resolver
  source reads are build-time-only (covered by T3) so not touched. 3 unit tests (override
  serve/clear + **decode-equivalence** vs `read_text().splitlines()` + gz round-trip); parity
  IDENTICAL for job_id=None / cold(not installed) / warm(216 source files from DB). depth-1
  (warm) **IDENTICAL** — fully verified.

**T10 — Precise setter sites + per-site guards (P9) → DB.** *(G1, G2, G3)*
- *What it does:* The last heavy-CPU trace-time item: tree-sitter re-parsing for setter
  discovery (`find_cpp_setters_in_file`, `find_cpp_writes_under_path`) and the value-flow
  prune. Precompute per-file precise setter sites (`var, stem, fn, line, set_value,
  unconditional?, enclosing-guard`) into `vbt_setter_site`; the setter search + value-flow
  prune read from DB.
- *Kills at trace time:* trace-time tree-sitter parsing of source for setter discovery and
  value-flow pruning (#6, #13, #17).
- *Files:* `vbt/setters/*`, `vbt/engine.py` (value-flow prune), `vbt/depvars/recurse.py`,
  index_db files.
- *Risk:* **Highest** (touches setter semantics) — done last with the strongest
  shadow-equality. *Regression:* round-trip + shadow-equality + golden (setter sets +
  conditions byte-identical). *Status:* **DONE (scoped) — parse-precompute DEFERRED by the
  no-regression mandate.** Implemented the SAFE part: routed all 3 setter-module source reads
  (`find_cpp_setters_in_file`, `_file_writes`, `_file_returns` via `_src_bytes`) through the T9
  source override → setter scans read source from DB (G3 complete for setters), byte-identical.
  4 unit tests (incl. `find_cpp_setters_in_file` sites identical via override); parity IDENTICAL
  for job_id=None / warm. **DEFERRED:** precomputing the FILTERED setter sites to skip the
  tree-sitter parse. Reason: `find_cpp_setters_in_file` applies the `full_paths` filter
  *interleaved in the walk* AND `full_paths` affects an emitted field (`match_scope`), so a
  precomputed result is not a function of `(var,file)` and can't be reconstructed byte-identical
  without splitting the walk from the filter — a refactor the codebase itself avoids
  (`cpp_setters.py:525` "kept separate to avoid refactoring the load-bearing finder"). Shipping
  that risks the prime directive. The parse stays bounded per-process by `_SETTER_CACHE`; a
  shadow-validated refactor is the path to full T10 if explicitly approved. depth-1 (warm)
  **IDENTICAL** — the safe scope is fully verified.

### Phase 4 — Production wiring

**T11 — Dedicated VBT precompute CLI + production wiring.** *(G4)*
- *What it does:* Orchestrates all artifacts. New `python -m vbt.precompute_db --job-id ID`
  backfills every `vbt_*` table for an existing job (mirrors `scripts/backfill_index_db.py`),
  and `vbt.precompute_all` / `vbt_precompute_task` gain the new steps + manifest writes. No
  parser-pipeline changes — purely VBT precompute. This is where 22K runs get the speedup
  operationally.
- *DB/precompute:* orchestration + manifest staleness enforcement across all artifacts.
- *Files:* `vbt/precompute_all.py`, new `vbt/precompute_db.py`,
  `api/tasks/vbt_precompute_task.py`.
- *Risk:* Med. *Regression:* precompute idempotency + manifest-staleness fallback + golden
  after a clean backfill. *Status:* **DONE** — `vbt/precompute_db.py` = orchestrator
  `precompute_vbt_db(job_id, blueprint_dir, asm_dir, graph_file)` + CLI `python -m
  vbt.precompute_db`. Builds/persists EVERY vbt_* artifact (resolvers, route name_to_stems,
  cpp_call_edges, ASM blueprints, source, cfg) — activating T6/T7/T8/T9 (which are load-only in
  the trace). Wired into `vbt_precompute_task` as Step 5/5 (best-effort, non-fatal). **Capstone
  proof:** CLI populates all tables (cpp_call_edges=109, asm=65, src=216, cfg=109 [after fixing a
  cfg-ordering bug: `_MEMO` was pre-populated by the cpp_call_edges build before the cfg PUT hook
  → cleared `_MEMO` before the cfg loop]) in ~9s, then a **fresh-process** trace with all
  artifacts served from index.db is **byte-IDENTICAL** for both root and depth-1. No
  parser-pipeline change. Full suite 157 passed / 34 skipped (only the pre-existing `lstknpoa`
  red); committed parity gate 3 passed.

### Phase 5 — Trace-time O(1) hardening (the 22k scaling fix)

**T13 — Eliminate ALL per-trace O(files) work + the last file reads.** *(G1, G3)*
- *Why:* the freshness checks added in T2–T11 (`source_manifest_hash` over the whole file set)
  ran **per trace** in every `install_*`/`preload_*` — ~7× O(files) `stat` sweeps per trace
  (~150k stats/trace at 22k). Plus `ensure_call_graph` globbed all blueprint mtimes per trace,
  `file_call_graph.json` was read as a file, and the cross-file **route walk still loaded C++
  blueprints from disk** (T7 served ASM only) — ~24.7k corpus file ops per trace, measured.
- *What it does:*
  1. **`load_only` mode** (`db_artifacts.set_load_only`, set by the engine when `job_id` is
     present): loaders TRUST the DB — load each blob by **presence** (O(1) indexed read), **no
     source-file hashing, no build**. Freshness becomes the precompute's job (it overwrites
     blobs; cfg stays self-validating via its content-hash key). Precompute forces it OFF.
  2. **Blueprint override generalized to ALL types** (asm/mac/**cpp**/hpp), keyed by filename —
     so the route walk's C++ blueprint reads come from DB too (was ASM-only).
  3. **`file_call_graph` → DB blob**; `RouteEngine._ensure_graph` reads it from DB; the engine
     **skips `ensure_call_graph`'s blueprint-mtime glob** when the DB graph is present.
  4. **`_read_text_with_retry` routed through the source override** (covers the route walk's
     `fetch_raw_line`/`_read_lines_cached`/constant scans), replicating `read_text`'s
     universal-newline translation so it stays byte-identical.
- *Files:* `db_artifacts.py` (load_only + `manifest_present`), `resolvers_db.py`, `graph_db.py`
  (+ `file_call_graph` blob), `asm_db.py` (all blueprint types; string parent check — no
  per-load `resolve()` stat), `vbt/reach/route.py`, `vbt/engine.py`, `precompute_db.py`, shared
  `blueprint_utils.py` (`_read_text_with_retry`).
- *Risk:* Med. The trace no longer self-verifies freshness (trusts precompute) — output is
  identical for a fresh precompute (parity proves it); a stale DB just needs precompute re-run
  (operational contract; pipeline re-ingest hook covers it; cfg is self-validating).
- *Proof (measured, fully-DB warm trace):* corpus file ops **24,709 → 3** per trace (source
  reads 0; only 2 `.cpp.json` + 1 `.bpidx` residual; stats bounded at 214 — all O(reachable),
  none O(corpus)). **Parity IDENTICAL** (root + depth-1); `job_id=None` compute path unchanged;
  full suite 157 passed (same 1 pre-existing red). *Status:* **DONE**

---

## 14. Coverage check — does this precompute "everything possible"?

Mapping every trace-time file read / CPU burn from the §2 inventory to the task that removes it:

| Trace-time cost (from §2) | Type | Removed by |
|---|---|---|
| `cfg_extract` subprocess (#8) | CPU | cfg-warm (existing) + **T8** (store) |
| `name_to_stems`/`_entry_names` corpus blueprint sweep (#5) | file + CPU | **T5** |
| RouteEngine reverse/forward adjacency rebuild (#5, #9) | CPU | **T5** |
| `CppFnGraph` build + `cpp_call_edges` re-attribution (#10, #11) | CPU + file | **T6** |
| name_resolver / membership cold build (#4, #15) | CPU + file | **T2** |
| modifier_index / const_resolver (#2, #3) | file (+ cold CPU) | **T3, T4** |
| ASM `blocks`/`flow`/`symbols`/`dsect` `load_json` (#7, #14, #19) | file | **T7** |
| cfg JSON file reads (#8, #12) | file | **T8** |
| raw `.cpp`/`.asm` for output slicing / constants / raw lines (#16, #14) | file | **T9** |
| tree-sitter setter discovery + value-flow prune (#6, #13, #17, #20) | CPU + file | **T10** |
| route DFS / dep-var recursion / output assembly | CPU (irreducible) | — (becomes cheap graph-walk over precomputed data; see §13 boundary) |

**Conclusion:** T0–T11 move *every* parse, subprocess, glob, blueprint load, cfg read, and raw
source read out of the trace hot path and into a one-time, VBT-owned, DB-backed precompute.
What remains at trace time is the variable-specific traversal itself — reduced to indexed DB
reads and in-memory graph walks. That is the combination that lets tracing scale to 22K files:
**G1** (no heavy CPU), **G2** (byte-identical, proven per step), **G3** (DB-only reads),
**G4** (no parser-pipeline dependency).

---

## 15. Implementation & parallelization strategy

Task ordering is a **dependency chain**, and the zero-regression gate (§11) requires each step
proven byte-identical *before* the next so every diff is attributable to exactly one task.
Therefore:

- **Code edits: sequential by default.** Parallel only within the explicitly-disjoint waves
  below, and then only in isolated **git worktrees** so parallel agents never stomp the shared
  files (`index_db/{schema,readers,writers}.py`, `precompute_all.py`, `engine.py`,
  `route.py`). Parallel code edits are used only when a wave's tasks are large *and* disjoint;
  otherwise sequential wins because shared-file reconciliation eats the savings and muddies
  diff-attribution.
- **Testing / parity: always parallel.** The corpus-wide parity run (§11.1) is **sharded
  across many subagents** — each slice of the variable universe runs both paths and returns
  byte-diff dossiers. This is the primary, safe, high-leverage parallelism and is how we "test
  everywhere" within a wall-clock budget. (Precompute builders are already process-parallel via
  `parallel_map`, so they need no subagent fan-out.)

**Dependency waves (what may run in parallel):**

- **W0 — prerequisites (strict sequential):** T0 → capture baseline goldens on *current* code
  → T1. Nothing else starts until T1's `job_id` plumbing + 3-tier resolver contract exist.
- **W1 — resolver artifacts (parallelizable):** T2, T3, T4 are independent producers; build in
  parallel worktrees, each independently parity-verified, then merge one at a time with
  re-verification.
- **W2 — graph (sequential):** T5 → T6 (T6 consumes T5's graph + cfg).
- **W3 — per-stem data (parallelizable):** T7, T8, T9 hit disjoint subsystems (ASM blueprint
  reads / cfg wrapper / source slicing); parallel worktrees, independent parity.
- **W4 — finish (sequential):** T10 (highest risk, alone) → T11 (orchestration).

**Tracker discipline (always-on):** every task flips to **IN-PROGRESS** when started and
**DONE** only when its full §11 acceptance gate passes — recorded inline with the perf delta
and a one-line note. Any diff gets its dossier + regression/progression verdict logged in the
task row before the task can close. §13 is the single source of truth for status.

---

## 18. T16 — The `xcrun` subprocess storm (DONE; byte-identical; the biggest depth win)

Profiling the DEPTH path (depth-2, `--max-offchain-files 1000`, job_id/DB warm) — NOT depth-1 —
exposed a cost the depth-1 profiles never showed: of **294.6s total, >150s was subprocess
spawning** (`subprocess.run` cumtime **157s**, `fork_exec` 41.8s, `select.poll` 96s, **14,092
subprocess calls**). Root cause: `vbt/cpp_frontend/wrapper.py::_detect_sdk_isysroot()` spawns
`xcrun --show-sdk-path` to build `parse_flags`, and that runs at the TOP of EVERY
`run_cfg_extract` call — *before* the `_MEMO`/DB/disk cache lookup (the flags are part of the
cache key, D7). So even though every cfg result was already cached, each of the ~14k cfg requests
still spawned an `xcrun` subprocess just to re-learn the same invariant SDK path.

**Fix:** memoize `_detect_sdk_isysroot()` in a module-level cache (`_SDK_ISYSROOT_CACHE`) — `xcrun`
is spawned at most ONCE per process. **Byte-identical** (same SDK path → same parse_flags → same
cache key → same cfg; fast parity gate IDENTICAL). COW-safe for forked workers. This is a pure
latency kill and **dwarfs the parallelization wins** — it removes >50% of a deep trace's wall
time with a 1-line-effect change and zero output risk.

**MEASURED on the user's depth-3 command (max-dep-var-depth 3, max-routes 2000,
max-offchain-files 1000): 402s → 155s (2.6×), `cmp` IDENTICAL to baseline (both 33,500,416 B).**
The tell: **system time 162.6s → 5.25s** — that 162s WAS the fork/exec/poll of ~14k `xcrun`
spawns. Cumulative depth-3: >20min (orig) → 8.3min (T14+DB) → 6.7min (route-memo) → **2.6min
(this)** → ~0.2s on repeat (#1 cache). All byte-identical.

**Priority impact:** re-profile the depth path AFTER this fix before investing in the (complex,
higher-risk) trace-loop parallelization — the remaining depth cost is now ~140s of real compute
(tree-sitter parse 12s, `cpp_setters._iter` walk 9s, caller-walk 9s, `_asdict_inner` 4s, 1M
`posix.stat` from the family-scan `.exists()` 3.4s), a much smaller target than the 294s it was.

### T17 — Per-file (src+parse-tree) cache in cpp_setters (DONE; byte-identical)
The re-profile (depth-2, 294.6→158.7s) showed tree-sitter `parse` 14.4s (2,380 parses) +
`find_cpp_setters_in_file` 61s cumtime: distinct variables searching the same file each re-read +
re-parsed it, because the result cache is keyed by `(file, variable, full_paths)`. Added
`_src_and_tree(cpp_path)` (`vbt/setters/cpp_setters.py`) — one `(src_bytes, parse_tree)` per file,
shared across all variables AND all three parse sites (`find_cpp_setters_in_file`,
`find_cpp_writes_under_path`, `find_cpp_returns_in_function`). **Byte-identical** (same bytes ⇒
same tree; fast parity gate + suite 160 IDENTICAL). Bounded memory (≤1024 trees, wholesale-clear
on overflow — matches `_SETTER_CACHE`); NOT caching the full node list (that would blow memory at
22k scale). **MEASURED depth-3: 155s → 110s (cmp IDENTICAL)** — bigger than the 14s parse estimate
because the family-scan (`max-offchain-files 1000`) re-parsed up to 1000 files PER node.

**Cumulative depth-3: >20min → 8.3min → 6.7min → 2.6min (T16) → 1.83min (T17) → ~0.2s repeat.**
All byte-identical. NOT pursued (skipped, recorded): a memo inside the shared
`find_cpp_to_cpp_callers` (~60s cumtime) — it has ~10 consumers across the legacy engine that the
VBT parity gate does not exercise, so byte-identity can't be proven with the available gates; the
`_iter` node-list cache — memory-unsafe at 22k scale. The remaining lever is VBT-scoped
PARALLELIZATION (Task #1), which divides the per-node compute across cores (no memory blowup) and
is verifiable by the parity gate + `cmp`.

## 19. T18 — Cross-trace route precompute (#2-full, LAZY; DONE; byte-identical, shadow-gated)

`route.routes(parent, child, max_routes)` is deterministic in those args + the call graph, returns
**pure JSON** (empirically verified: `json.loads(json.dumps(r)) == r` for all 28 route results in a
root trace), and does NOT depend on the traced variable. The in-trace route memo (`af0c02a`,
`RouteEngine._routes_memo`) is the seam: `route.routes` serves it first. So #2-full =
**persist that memo to index.db and preload it on the next trace** — `route.routes` is unchanged,
so a preloaded result is byte-identical to a fresh compute.

- `vbt/precompute/route_cache_db.py`: ONE accumulating `route_cache` blob = `[[key_list, result]]`
  (the memo tuple key as a JSON list — `None` function + int `max_routes` survive the round-trip).
  `preload_route_cache` fills `_routes_memo` at trace start; `persist_route_cache` writes it back at
  trace end (current memo = prior + this trace's new routes). `PERSIST_CAP=200k` bounds the blob
  (best-effort cache ⇒ capping is correctness-neutral). Concurrent traces race last-wins (hit-rate
  only). `precompute_db` clears it on rebuild (a changed graph must never serve a stale route).
- Wired in `engine.py` (preload after the route/edge preloads; persist beside the §16 #1 store),
  both `job_id`-gated ⇒ the file/compute path (and the parity gate's `job_id=None` cases) are
  untouched.
- **Byte-identity proven:** shadow run — trace with `route_cache` COLD (computes+persists) vs WARM
  in a fresh process (preloads+reuses) → **A == B == golden**; full parity gate 3/3 IDENTICAL;
  suite 160; `test_route_cache_db.py` 3/3 (key-type round-trip + cold-blob no-op + no-job-id no-op).
- **Cross-trace reuse measured: root 6.23s → 3.91s (~37%); depth-3 93s → 62s (~33%)** on the warm
  path (a fresh process reused the prior trace's caller-walks via the DB; depth-3 COLD==WARM==
  BASELINE byte-identical). Helps the multi-variable / on-demand workflow — a new variable reuses
  every route to a function some earlier variable already reached.
- **NOT done (future, optional): EAGER warm.** `precompute_db` could pre-walk routes from each
  chain tail to all reachable functions so even the FIRST-ever trace on a cold job is instant — but
  it couples precompute to the chain(s) + the trace's `max_routes` values. The LAZY cache already
  captures the cross-trace benefit; EAGER only moves the first trace's walk cost to offline.

## 20. T19 — Per-file write-shaped node cache in cpp_setters (DONE; byte-identical; huge depth win)

After T17 (parse-tree cache), the next depth cost was the `_iter` tree-DFS inside
`find_cpp_setters_in_file` — it ran per `(variable, file)` (the result cache is keyed by
`(file, variable, full_paths)`), and at depth-3 the same files are searched for hundreds of
variables, so the full DFS (28M `list.extend`, ~30s of a depth-2 trace) was repeated. The set of
nodes the loop acts on is exactly 4 write shapes (`assignment_expression`, `init_declarator`,
`call_expression`, `update_expression`) and is **variable-independent**; every other node type was
a no-op in the loop. So `_setter_nodes(cpp_path, tree)` caches that DFS-ordered subset per file
(`_SETTER_NODES_CACHE`, cleared with the tree cache). **Byte-identical** (same nodes, same order;
fast gate + suite 163 + depth-3 `cmp` IDENTICAL).

**MEASURED cold depth-3: 110s → 46.6s** (the DFS now runs once per FILE, not per (variable,file)).
Committed (local). **Cumulative cold depth-3: >20min → 8.3 → 6.7 → 2.6 → 1.83min → 46.6s** — all
byte-identical. Target is <30s; the remaining cold cost is the caller-walk (~30s) — addressed by
#2-full route reuse (warm) and/or BFS parallelization.

**T19 + #2-full warm together MEASURED depth-3 = 17.0s (WARM==BASELINE IDENTICAL)** — i.e. any
trace after the route cache warms (incl. a new variable on the same chain) is **under 30s**, with
zero parallelization risk. Cold first-ever-per-rebuild stays 46.6s (one-time). To put the COLD
first trace under 30s too: either EAGER-warm the route cache at precompute (byte-identical) or BFS
parallelization (cold 46.6s ÷ cores → ~12-15s; risky).

## 16. Per-route entry building — the trace-LATENCY optimization (T14/T15)

The DB precompute (T0–T13) moved **input acquisition** off the trace hot path (file reads
24,709→3/trace). But for a heavy variable it left the **per-route entry building** CPU intact —
the actual backward traversal: per (setter, chain) tuple, enumerate routes + collect
per-edge/setter-local guard conditions. On `softCardValue` (1316 tuples, the corpus's heaviest
variable) that phase was **23.9s** of a 26.0s trace. cProfile (`tottime`) pinpointed it as
**redundant recomputation of deterministic guard data** across setters that share
routes/functions — NOT I/O.

### T14 — Memoize the deterministic guard recomputation (DONE; byte-identical)
| Hotspot | Was | Fix | After |
|---|---|---|---|
| `chainless_lineage_tree._conditions_at(stem,scope,line)` | 11.9s self, 14,996 calls, 170M `dict.get` | memoize result per `(scope,line)` on the cached pfl entry; return a fresh list | **0.36s** |
| `cpp_conditions._cfg_dominators(blocks)` | 3.5s, 8,947 calls | cache the dominator solve on the cfg fn dict (`_dom_cache`) | folded in |
| `cpp_conditions._fn_line_span(f)` | 2.4s (`_fn_line_span`+`upd`), 169k/9M calls | cache the span on the cfg fn dict (`_line_span_cache`) | folded in |

All three are **pure functions of fixed inputs** (lineage edges / cfg), cached → same outputs.
**Result: `softCardValue` root 26.0s → 9.7s (2.7×), per-route building 23.9s → 7.8s; parity gate
IDENTICAL** (memos change nothing). Files: `backward_traversal/runner/chainless_lineage_tree.py`,
`vbt/conditions/cpp_conditions.py`. *Status:* **DONE**

### T15 — What would make it (near-)instant. Ranked; precompute-first per the directive.
The remaining ~7.8s for the worst-case variable is genuine traversal (find_routes per setter +
DFS + dataclass serialization + the one-time DB-blob decompression ≈ 2s). To kill it:

1. **Result-level precompute (the real "instant", LOW risk). — DONE.** A finished trace for a
   given input set is deterministic, so we cache the whole `trace_root_variable` output keyed by
   a signature of ALL output-affecting inputs (variable, language, chain, dirs, every cap,
   hints). `vbt/precompute/trace_cache.py` + an early cache-check / pre-return store in
   `trace_root_variable` (job_id-gated). **Lazy self-warming:** the first trace of an input set
   computes+stores; any repeat is an O(1) DB blob read. `precompute_db` CLEARS the cache on
   rebuild (`clear_blobs_prefix("trace:")`) so a stale result is never served. **Proof:** run 1
   (miss) 9.95s → run 2 (fresh process, hit) **0.23s** (~43×), both byte-IDENTICAL to golden;
   `job_id=None` compute path unchanged; suite 160 passed. (A "warm the whole variable universe
   up front" batch can sit on top of this lazy cache for instant-on-first-request.)
2. **Route-and-guard reuse keyed by `(chain, setter-location)`.** A route `tail→setter` and its
   guards depend on the *setter's file/function + the chain*, NOT on the traced variable — so
   they're reusable across every setter (and every variable) landing in the same function.
   - **IN-TRACE memo — DONE (LOW risk, byte-identical).** `RouteEngine.routes` is now memoized by
     `(parent, child, max_routes)`. Profiling showed the cross-file caller-walk
     (`walk_callers`/`find_cpp_to_cpp_callers`, 14.8s cumulative) was *the* remaining per-setter
     cost; at depth-3 many setters share a target function, so this collapses the walk to once
     per `(tail, target)`. **softCardValue root 9.7s → 7.5s; depth-3 8.3min → 6.7min**, both
     byte-IDENTICAL (depth-3 `cmp`-equal to the baseline, 530 deps / 1507 tuples), fast gate
     IDENTICAL, suite 160 passed. (Also confirmed the blueprint-I/O hotspot `_load_frames_partial`
     6.3s only appears on the `job_id=None` path — `--job-id` serves blueprints from the DB.)
   - **CROSS-TRACE DB precompute — REMAINING (HIGH value, MED-HIGH risk).** Store the route+guard
     structure per `(chain, function)` in the DB so even a *first* trace of a never-seen variable
     is a lookup. Needs the reusable-vs-setter-specific separation + shadow-validated byte-identity
     before shipping. Deferred until explicitly approved.
3. **Parallelize the per-setter loop (MED).** Embarrassingly parallel (1316 independent setters);
   ~N-core speedup. Must re-sort by setterId after to stay byte-identical, and respect the
   RAM-aware worker plan.
4. **Opportunistic micro-memos (LOW, incremental):** cache `find_cpp_to_cpp_callers` /
   `find_asm_to_cpp_callers` per `(callee_stem, anchor)`; reuse decoded DB blobs across the trace
   (~2s of gz/JSON decode). Each shaves ~0.5–1s.

**Recommendation:** (1) is the highest-leverage, lowest-risk "instant" — warm the result cache in
precompute. (2) is the precompute that structurally kills first-trace latency but needs the
shadow-validated byte-identity pass. (3)+(4) are incremental. T14 (the 2.7× memo win) is in and
proven byte-identical.

## 17. Decided execution order (2026-06-18) — "do everything, no regressions"

User delegated the ordering. Doing all three, ordered by value-with-controlled-risk, each gated
byte-identical (parity harness + `cmp` vs baseline + full suite) at every step:

**A. Parallelize the trace loop (Task #1) — the headline 6.7min→~2min lever, the user's core pain.**
Key design findings (de-risk the original "MED" estimate above):
- **Block IDs are CONTENT-ADDRESSED**, not registration-order sequential: `CodeBlockStore` keys
  `cpp:{stem}:{function}` / `asm:{stem}:{block_id}` (vbt/output/codeblocks.py). So merging stores
  from parallel workers needs **NO remap** — same content → same id.
- BUT the output is `json.dumps(out, indent=2)` with **NO `sort_keys`** (vbt/trace.py:185), so the
  `codeBlocks` map preserves *insertion order*. ⇒ the merge must **replay block registration in the
  same deterministic order** the sequential trace would (setter order, then dep-var order),
  dedup-skipping repeats. Mechanical, not a remap.
- Two order-sensitive shared states to serialize in the merge: `seen_tuples` (first-tuple-wins
  dedup, engine.py:842) and the entries list (setterId = list position, assembler.py).
- **Worker model:** fork + COW (vbt/precompute/parallel.py `parallel_map` uses `fork`) → workers
  inherit the parent's warm route engine / cfg cache / loaded blueprints for free. HAZARD: open
  index.db SQLite handles across `fork` are unsafe — either pre-warm all needed source/blueprint/
  cfg into parent caches before fork, or give each worker its own engine. Resolve before shipping.
- **Two loops, very different difficulty:**
  - *Setter loop* (engine.py:849) — CLEAN: each setter independent; parallel-compute + ordered
    merge (block-replay + seen_tuples dedup + entries assembly). LOW-MED risk. **Stage 1a.**
  - *Dep-var BFS* (recurse.py `trace_dependents`) — HARD: a single worklist `q` drains while
    `results`/`memo`/`edge_seen`/`node_rescope`/`family_*` mutate; first-discoverer + edge order +
    rescope order are order-sensitive. Byte-identical parallelization = per-batch (drain current
    queue) parallel-compute of the EXPENSIVE per-node work (setter discovery + the
    `find_cpp_writes_under_path` family scan over ≤max_offchain_files) + **deterministic sequential
    merge** in the exact drain order. MED-HIGH risk. **Stage 1b** (where the depth-3 win lives —
    pending the profile confirming per-node compute, not orchestration, is the cost).
  - *Refactor-first discipline:* extract a pure `_compute_*` + a sequential `_merge_*`, run SERIAL,
    prove byte-identical (refactor changes nothing), THEN add the pool. Each sub-step parity-gated.

**B. Cross-trace route precompute (Task #2)** — sequenced after A (marginal value shrank after the
in-trace route-memo); shadow-gated.

**C. Speed up precompute_db's serial loops (Task #3)** — last, lowest risk (output untouched),
reuses A's process-pool helper; modest win (heavy Clang already parallel in cfg-warm).
