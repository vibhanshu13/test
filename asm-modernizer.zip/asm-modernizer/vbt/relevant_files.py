r"""Standalone relevant-files SCOPE enumerator (grep-based, blueprint-free).

==============================================================================
WHAT THIS IS
==============================================================================
Given ONE variable, this answers a single scoping question:

    "Which source files would a full backward-lineage trace of this variable —
     following its dependent variables, and THEIR dependent variables, to depth
     N (or forever) — ever need to read?"

It returns the UNION of every file where the variable, or any transitive
dependent variable, is *set*. It is meant for sizing/scoping a run (e.g. "copy
these 40 files", "this trace touches 12 files"), NOT for the precise lineage
itself — that is the job of the heavy engine (vbt/engine.py).

==============================================================================
WHY IT IS AN OVER-APPROXIMATION (and why that's the right choice here)
==============================================================================
The precise engine applies *reachability* — it keeps only setters actually
reachable on the execution path from a given chain. This tool deliberately does
NOT: it has no chain, no call graph, no CFG, no reachability filter. It treats
"variable X is written somewhere in file F" as "F is in scope". The result is a
strict SUPERSET of what any precise trace could touch — exactly what you want
for "give me ALL files that could possibly be relevant". Trading precision for
speed + zero setup is the entire point: it runs on a bare directory of source
files in seconds, with nothing but grep.

It is NOT part of any audit and does not touch the precise engine (vbt/engine.py,
vbt/depvars/recurse.py, vbt/conditions/*, vbt/reach/*). It only *imports* small,
pure, stateless helpers — the glossary opcode sets and the dep-var token filters
— so it stays consistent with how the real engine decides "is this a setter?"
and "is this token a real variable?".

==============================================================================
END-TO-END ALGORITHM
==============================================================================
A breadth-first search over VARIABLES (not files). Each queue item is
(variable_name, language, depth). The visited set is keyed on the CANONICAL
SHORT name (C++ tail component, or normalized ASM token) so the same logical
field reached by different qualified paths is one node — this is what makes it
cycle-safe and guarantees termination even with --unlimited.

For each dequeued variable we run `_scan_one_variable`, which does:

  STEP 1 — SETTER FILES.  Find every file where this variable is *written*:
    * C++ (`_is_cpp_setter_line` + `_cpp_setter_regex`): a write to the field by
      its TAIL name — plain `=` / compound `|= += &= ^= >>= ...` / declaration-
      with-init — optionally member-accessed via `.`/`->`, with an optional
      `[..]` subscript, and EXCLUDING comparisons (`==`, `!=`, `<=`, `>=`) via a
      `(?!=)` negative lookahead. Full-line comments / commented-out code are
      skipped.
    * ASM (`_is_asm_setter_line`): the line's opcode must be in the glossary
      `SETTER_INST`, and its DESTINATION operand — chosen by
      `DEST_ARG_INDEX_BY_INST` (e.g. ST→arg1, STM→arg2, MVC/OI→arg0) — must
      normalize to the variable. This mirrors the real engine's setter rule.

  STEP 2 — DEPENDENT VARIABLES.  For each setter site, read the setter line plus
    a small window of PRECEDING lines (`_CONTEXT_LINES`, the local guarding
    conditions), and extract the other variables it depends on:
    * C++ (`_cpp_dep_vars`): operand member-paths via the engine's
      `_cpp_operand_paths`, filtered by `_CPP_NOISE` (keywords, builtins,
      ALL-CAPS macros, scoped-enum constants, literals); self excluded.
    * ASM (`_asm_dep_vars`): the setter's SOURCE operands (all but the dest) plus
      every operand in the guard window, filtered by `is_dep_var_candidate`
      (drops registers, literals, immediates, constants); self excluded.

  STEP 3 — CROSS-LANGUAGE ALIASES.  A logical field has different names per
    language. `_resolve_cross_language` calls the high-certainty resolver
    (`vbt.resolve.name_resolver.resolve`) to get the variable's ASM↔C++
    counterpart(s), and STEP 1/2 are repeated for each alias in ITS language
    (e.g. C++ `softCardValue` also greps for ASM `LWRPOSFCRDV`). With no
    .mac/.hpp/cc<stem>.hpp triples in the dir the resolver returns nothing and
    this degrades to a no-op — the tool still works on a pure-C++ or pure-ASM dir.

Back in the BFS (`enumerate_relevant_files`):
  STEP 4 — RECURSE.  Each newly discovered dep var (by canonical key, if unseen)
    is enqueued at depth+1, UNLESS we're at the depth cap. --unlimited sets the
    cap to None and the BFS naturally terminates when no new variables appear
    (the visited set stops growing).
  STEP 5 — ACCUMULATE.  The union of all setter file NAMES across every variable
    and depth is the answer, alongside per-depth and per-variable breakdowns.

==============================================================================
GREP BACKEND NOTE (the one non-obvious implementation detail)
==============================================================================
ripgrep's default regex engine REJECTS lookahead. So the precise C++ setter test
(which needs `(?!=)` to exclude `==`) cannot be handed to rg/grep. Instead we
pass a broad LOOKAHEAD-FREE *candidate* pattern to rg/grep (`_cpp_grep_candidate`,
a superset that may include `==`), then re-test each hit precisely in Python with
`_cpp_setter_regex`. ASM uses a cheap "var token anywhere" candidate, then the
precise dest-operand test in `_is_asm_setter_line`. rg is preferred; plain
`grep -rnE` is the fallback (validated to give identical results).

==============================================================================
WORKED EXAMPLE (temp/asm)
==============================================================================
  python -m vbt.relevant_files softCardValue --dir temp/asm --unlimited
    depth 0: softCardValue is set in dw710000.cpp, dw780000.cpp; its ASM alias
             LWRPOSFCRDV pulls in nh76.asm. Its setter guards/operands yield
             dep vars (linkSourceArea, lstknpoa, expressPay, cidDbSelect, ...).
    depth 1..n: each dep var is scanned the same way, adding its setter files.
    => 29 files total (depth 0:3, 1:11, 2:26, unlimited:29). ~39s.
  Monotonic by construction: files(depth 0) ⊆ files(depth 1) ⊆ ... ⊆ unlimited.

==============================================================================
COMPLEXITY / PERFORMANCE
==============================================================================
Cost ≈ (number of distinct variables reached) × (one grep over the dir) +
file reads for the guard windows (cached per file in `line_cache`). Grep is
linear in corpus size; the variable count grows with depth and fans out fast,
so wall-clock is dominated by depth (depth 2 ≈ 4s, unlimited ≈ 40s on the 63-file
corpus). At 22k files each grep is larger but still a single pass; --unlimited on
a high-fan-out variable is the expensive case — bound it with --max-dep-var-depth.

==============================================================================
LIMITATIONS (honest)
==============================================================================
  * OVER-approximates by design: no reachability filter, so it includes files
    whose setter is never actually reached; self-OR / zero-test idioms
    (`OC X,X` — OC/NC are in SETTER_INST) count as possible writes; the guard
    window scans all preceding-line operands so a neighbouring macro operand can
    surface as a (harmless) dep var — it only adds a file if that token truly has
    a setter elsewhere.
  * UNDER-approximates in two cases: a setter HIDDEN inside a macro expansion
    (the destination is not a literal LHS in source) is invisible to grep; and
    cross-language coverage is limited to HIGH-CERTAINTY alias triples.
  * Tail-based matching means two distinct fields sharing a tail name collapse to
    one node (consistent with the engine's tail-based setter search).

==============================================================================
CLOSURE MODE (--closure / --with-deps) — SELF-CONTAINED PARSEABLE SUBSET
==============================================================================
The default output is the SETTER (lineage) file set — every file where the
variable or a transitive dep var is written. That set is enough to *scope* a
trace, but NOT enough to actually PARSE + TRACE it standalone: the C++ frontend
needs the headers those setters `#include`, the ASM parser needs the macros /
copybooks those setters `COPY`, and the cross-language name resolver needs the
``cc<stem>.hpp`` / ``<stem>.hpp`` / ``<stem>.mac`` resolver TRIPLE(s).

``--closure`` takes the setter set as a SEED and closes it (still grep/text only,
NO blueprints, NO cfg_extract) over three transitive dependency kinds:

  (A) C++ `#include` closure — every in-dir `.hpp`/`.h` reachable from any
      `.cpp`/`.hpp` in the set, via `_find_cpp_chain._included_paths`
      (in-dir only, cycle-safe, depth-bounded by `_INCLUDE_MAX_DEPTH`). This is
      what lets `cfg_extract` resolve member-writes / enums instead of hitting
      the headerless caveat.
  (B) ASM `COPY`/macro closure — every in-dir `.mac`/copybook reachable from any
      `.asm`/`.mac` in the set, by grepping `COPY <member>` and resolving
      `<member>` to an in-dir file (transitive, cycle-safe). This lets the ASM
      parser resolve DSECTs / macros.
  (C) Resolver TRIPLES — for the root variable AND every cross-language dep var
      reached during the BFS, the `cc<stem>.hpp` + `<stem>.hpp` + `<stem>.mac`
      for its high-certainty resolver `home_stem` (e.g. softCardValue ↔
      LWRPOSFCRDV → home stem `lwrpo` → cclwrpo.hpp / lwrpo.hpp / lwrpo.mac).
      These let the cross-language name resolver work IN the copied subset.
      Whatever triple file is present in-dir is added; the include/COPY closures
      then run over those triple files too (so a triple's own headers come in).

The closed list is sorted + deduped and reported with per-category counts
(setter-files / added headers / added macros / triple files). With ``--copy-to
DIR`` every file is copied (flat) into DIR, giving a ready-to-trace folder. The
result stays a strict over-approximation and is fully deterministic.

CLI:
    python -m vbt.relevant_files <VARIABLE> --dir <codebase_dir> \
        [--max-dep-var-depth N]   # default 3; 0 = root variable only
        [--unlimited]             # overrides depth; traverse until no new dep vars
        [--language asm|cpp]      # optional starting-language hint (else inferred)
        [--closure | --with-deps] # close the setter SEED over #include/COPY/triples
        [--chain "s1:asm,s2:cpp"] # backbone/prefix hops folded into the closure SEED
        [--reasons]               # per-FILE justification: which var(s) (+depth) are
                                  #   written there + the file's role (setter/chain/
                                  #   triple/+include/+COPY); also added to --json
        [--copy-to DIR]           # copy the (closed) file set into DIR, flat
        [--json out.json]         # optional machine-readable output

    # Get softCardValue's COMPLETE parseable subset on a 22k tree and copy it:
    python -m vbt.relevant_files softCardValue --dir /path/to/22k_src \
        --language cpp --unlimited --closure --copy-to /tmp/scv_subset

    # ...and ask WHY each file is in (per-file reasons + the chain backbone):
    python -m vbt.relevant_files softCardValue --dir /path/to/22k_src \
        --language cpp --unlimited --closure \
        --chain "aa71:asm,dw730000:cpp,dw710000:cpp" --reasons
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

# --- Pure helper reuse (no engine state, no blueprints) --------------------- #
from backward_traversal.glossary.instructions import (
    SETTER_INST,
    DEST_ARG_INDEX_BY_INST,
)
from backward_traversal.utils.token_utils import is_dep_var_candidate, normalize_token
from vbt.depvars.extract import _cpp_operand_paths, _CPP_NOISE
# Shared mem-write builtin set — single source of truth (vbt/setters/cpp_setters.py).
from vbt.setters.cpp_setters import MEM_WRITE_BUILTINS

# Pure, in-dir, cycle-safe, depth-bounded #include follower (reused for the C++
# header closure). _INCLUDE_MAX_DEPTH bounds both this and our COPY closure.
from vbt.resolve._find_cpp_chain import _included_paths, _INCLUDE_MAX_DEPTH

# Cross-language alias resolution is optional: degrade gracefully if it errors.
try:
    from vbt.resolve.name_resolver import resolve as _resolve_aliases  # type: ignore
except Exception:  # pragma: no cover - defensive import
    _resolve_aliases = None  # type: ignore


# --------------------------------------------------------------------------- #
# File-extension language classification
# --------------------------------------------------------------------------- #
_CPP_EXTS = (".cpp", ".cc", ".cxx", ".hpp", ".hh", ".hxx", ".h", ".c")
_ASM_EXTS = (".asm", ".mac", ".s", ".S")

# How many lines of preceding context to scan for guarding conditions / dep vars.
_CONTEXT_LINES = 6


def _lang_of_file(path: Path) -> Optional[str]:
    name = path.name.lower()
    for e in _CPP_EXTS:
        if name.endswith(e):
            return "cpp"
    for e in _ASM_EXTS:
        if name.endswith(e.lower()):
            return "asm"
    return None


# --------------------------------------------------------------------------- #
# Canonical short name
# --------------------------------------------------------------------------- #
def _short_name(name: str, language: str) -> str:
    """Canonical short/tail name used for the cycle-safe visited set."""
    if language == "cpp":
        tail = name.replace("->", ".").split(".")[-1].strip()
        return tail.split("[")[0].split("(")[0].strip()
    return normalize_token(name)


def _canon_key(short: str) -> str:
    return short.upper()


# --------------------------------------------------------------------------- #
# grep / ripgrep backend
# --------------------------------------------------------------------------- #
_HAS_RG = shutil.which("rg") is not None


@dataclass
class _Hit:
    path: Path
    line_no: int
    text: str


def _run_grep(pattern: str, src_dir: Path, exts: Tuple[str, ...]) -> List[_Hit]:
    """Run rg (preferred) or grep -rn for ``pattern`` over files of ``exts``.

    Returns raw hits; the caller applies the precise per-language setter test.
    """
    globs: List[str] = []
    for e in exts:
        globs.append(f"*{e}")

    hits: List[_Hit] = []
    if _HAS_RG:
        cmd = ["rg", "--no-heading", "--line-number", "--no-config",
               "-e", pattern]
        for g in globs:
            cmd += ["-g", g]
        cmd.append(str(src_dir))
    else:
        # grep can't OR file globs easily; --include repeated works on GNU/BSD grep.
        cmd = ["grep", "-rnE"]
        for g in globs:
            cmd += [f"--include={g}"]
        cmd += [pattern, str(src_dir)]

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    except Exception:
        return hits

    for raw in proc.stdout.splitlines():
        # format: <path>:<lineno>:<text>
        parts = raw.split(":", 2)
        if len(parts) < 3:
            continue
        fpath, lno, text = parts
        try:
            line_no = int(lno)
        except ValueError:
            continue
        hits.append(_Hit(path=Path(fpath), line_no=line_no, text=text))
    return hits


# --------------------------------------------------------------------------- #
# C++ setter detection (grep candidate + precise LHS test)
# --------------------------------------------------------------------------- #
# Compound + plain assignment, but NOT == / != / <= / >= ; declaration-with-init too.
# We match the field by its TAIL component, optionally member-accessed via . or ->.
_CPP_ASSIGN_OPS = r"(?:\|=|&=|\+=|-=|\^=|>>=|<<=|\*=|/=|%=|=)"

# Mem-write builtins (memcpy/memset/strcpy/sprintf/...) and member ++/-- ALSO
# write a field but are not =-shaped — mirror cpp_setters.py here so the lite grep
# scope tool finds fields written ONLY via these (e.g. serviceCode). Built from the
# SHARED MEM_WRITE_BUILTINS set so the three layers can never drift apart.
_MEM_WRITE_ALT = "|".join(sorted(re.escape(b) for b in MEM_WRITE_BUILTINS))


def _cpp_setter_regex(tail: str) -> re.Pattern:
    """Precise (Python-`re`) setter test — uses lookahead, NOT given to rg/grep.

    Three write shapes are accepted for the field ``tail`` (optionally member-
    accessed via ``.``/``->`` and subscripted):
      1. an assignment op (``=`` / ``|=`` / ... but NOT ``==``);
      2. a mem-write BUILTIN call whose FIRST argument is (an ``&``/cast of) the
         field — ``memcpy(dst.tail, ...)`` / ``memset(&dst.tail, ...)``;
      3. a pre/post increment-decrement — ``tail++`` / ``--p->tail``.
    """
    t = re.escape(tail)
    member = r"(?:(?:->|\.)\s*)?"          # optional member access
    field = rf"\b{t}\b(?:\s*\[[^\]]*\])?"  # tail + optional subscript
    # 1. assignment op (not ==)
    assign = rf"{member}{field}\s*{_CPP_ASSIGN_OPS}(?!=)"
    # 2. builtin( &?(cast)? <member-path ending in tail> , | )   (dest = first arg)
    #    The dest arg can be ``&``-prefixed and/or cast; a member-path may precede
    #    the tail. We accept the tail as the FIRST argument followed by ``,`` (multi-
    #    arg) or ``)`` (single-arg, rare). bcopy's dest is arg1 — also covered since
    #    we don't anchor to the first arg position, only require the builtin name.
    builtin = (
        rf"\b(?:{_MEM_WRITE_ALT})\s*\(\s*"   # builtin name + (
        r"[&(*\s]*"                          # optional &, cast/paren chars, *
        rf"(?:[A-Za-z_]\w*\s*(?:->|\.|\[[^\]]*\])\s*)*"  # leading member-path/subscripts
        rf"{field}\s*[,)]"                   # the field, then , or )
    )
    # 3. ++/-- on the field (pre or post)
    incdec = rf"(?:\+\+|--)\s*{member}{field}|{member}{field}\s*(?:\+\+|--)"
    pat = rf"(?:{assign})|(?:{builtin})|(?:{incdec})"
    return re.compile(pat)


def _cpp_grep_candidate(tail: str) -> str:
    """Broad, lookahead-FREE candidate pattern for rg/grep (Rust/ERE-safe).

    ripgrep's default engine rejects lookahead, so the precise test happens in
    Python afterwards. We just need a SUPERSET matcher: the tail token followed by
    an assignment op, a ``,``/``)`` (its builtin-call dest position), or ``++``/``--``
    (or those operators preceding it). The precise ``_cpp_setter_regex`` then re-tests.
    """
    t = re.escape(tail)
    return (
        r"(\+\+|--)?\s*\b" + t +
        r"\b\s*(\[[^]]*\]\s*)?(\|=|&=|\+=|-=|\^=|>>=|<<=|\*=|/=|%=|=|\+\+|--|,|\))"
    )


def _strip_cpp_comment(text: str) -> str:
    # drop // line comment (string literals already won't matter for LHS detection)
    idx = text.find("//")
    if idx != -1:
        text = text[:idx]
    return text


def _is_cpp_setter_line(text: str, regex: re.Pattern) -> bool:
    code = _strip_cpp_comment(text)
    # Skip obvious full-line comment / commented-out code.
    stripped = code.strip()
    if not stripped or stripped.startswith("*") or stripped.startswith("/*"):
        return False
    return regex.search(code) is not None


# --------------------------------------------------------------------------- #
# ASM setter detection (grep candidate + precise dest-operand test)
# --------------------------------------------------------------------------- #
def _asm_operands(text: str) -> Tuple[str, List[str]]:
    """Return (opcode, [operands]) from an ASM source line, comments stripped."""
    line = text.rstrip("\n")
    # An ASM comment line starts with '*' in column 1.
    if line[:1] == "*":
        return "", []
    # Strip a label in column 1 (token starting at col 0, no leading ws).
    # HLASM: LABEL  OPCODE  OPERANDS   comment
    # Tokenize on whitespace; if the first char is non-space there is a label.
    m = re.match(r"^(\S+)?\s+(\S+)\s+(\S+)", line)
    if not m:
        return "", []
    opcode = m.group(2).upper()
    operand_field = m.group(3)
    # Operands are comma-separated; everything after the first run of spaces is comment.
    operands = [o for o in operand_field.split(",") if o]
    return opcode, operands


def _is_asm_setter_line(text: str, var_upper: str) -> bool:
    opcode, operands = _asm_operands(text)
    if not opcode or opcode not in SETTER_INST:
        return False
    if not operands:
        return False
    dest_idx = DEST_ARG_INDEX_BY_INST.get(opcode, 0)
    if dest_idx >= len(operands):
        dest_idx = 0
    dest = operands[dest_idx]
    return normalize_token(dest) == var_upper


# --------------------------------------------------------------------------- #
# Dep-var extraction from a setter site (+ preceding guard window)
# --------------------------------------------------------------------------- #
def _read_file_lines(path: Path, cache: Dict[Path, List[str]]) -> List[str]:
    lines = cache.get(path)
    if lines is None:
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception:
            lines = []
        cache[path] = lines
    return lines


def _window_text(lines: List[str], line_no: int) -> Tuple[str, str]:
    """Return (setter_line_text, preceding_window_text) for a 1-based line number."""
    idx = line_no - 1
    if idx < 0 or idx >= len(lines):
        return "", ""
    setter_line = lines[idx]
    start = max(0, idx - _CONTEXT_LINES)
    window = "\n".join(lines[start:idx])
    return setter_line, window


def _cpp_dep_vars(setter_line: str, window: str, self_tail: str) -> Set[str]:
    deps: Set[str] = set()
    # RHS of the setter line: everything after the assignment op.
    code = _strip_cpp_comment(setter_line)
    # Use the whole setter line + the guard window as the operand pool.
    pool = code + "\n" + window
    for path in _cpp_operand_paths(pool):
        tail = path.replace("->", ".").split(".")[-1].strip()
        tail = tail.split("[")[0].split("(")[0].strip()
        if not tail or tail in _CPP_NOISE:
            continue
        if tail == self_tail:
            continue
        deps.add(tail)
    return deps


def _asm_dep_vars(setter_line: str, window: str, self_upper: str) -> Set[str]:
    deps: Set[str] = set()
    # Setter source operand(s): all operands except the destination.
    opcode, operands = _asm_operands(setter_line)
    src_operands: List[str] = []
    if opcode:
        dest_idx = DEST_ARG_INDEX_BY_INST.get(opcode, 0)
        for i, op in enumerate(operands):
            if i == dest_idx:
                continue
            src_operands.append(op)
    # Guard-window operands: tokens in preceding lines (compare operands etc.).
    for gline in window.splitlines():
        _, gops = _asm_operands(gline)
        src_operands.extend(gops)
    for op in src_operands:
        if not is_dep_var_candidate(op, skip_var=self_upper):
            continue
        tok = normalize_token(op)
        if tok and tok != self_upper:
            deps.add(tok)
    return deps


# --------------------------------------------------------------------------- #
# Per-variable setter scan (one logical variable, all its language aliases)
# --------------------------------------------------------------------------- #
@dataclass
class VarResult:
    name: str                     # canonical short name used as the key
    language: str                 # starting-language guess for this variable
    files: Set[str] = field(default_factory=set)        # file NAMES touched
    setter_count: int = 0
    dep_vars: Set[str] = field(default_factory=set)     # discovered (short names)
    aliases: List[Tuple[str, str]] = field(default_factory=list)  # (name, lang)
    home_stems: Set[str] = field(default_factory=set)   # resolver home stems (for triples)


def _resolve_cross_language(
    name: str, language: str, src_dir: Path
) -> Tuple[List[Tuple[str, str]], Set[str]]:
    """Return ([(alias_name, alias_language)], {home_stem}) high-certainty aliases.

    The ``home_stem`` set drives the resolver-TRIPLE closure: each stem yields
    ``cc<stem>.hpp`` / ``<stem>.hpp`` / ``<stem>.mac`` that the cross-language
    name resolver needs to operate inside the copied subset."""
    if _resolve_aliases is None:
        return [], set()
    try:
        aset = _resolve_aliases(name, language, src_dir)
    except Exception:
        return [], set()
    out: List[Tuple[str, str]] = []
    stems: Set[str] = set()
    for a in getattr(aset, "aliases", []) or []:
        out.append((a.name, a.language))
        stem = getattr(a, "home_stem", None)
        if stem:
            stems.add(stem)
    return out, stems


def _scan_one_variable(
    name: str,
    language: str,
    src_dir: Path,
    line_cache: Dict[Path, List[str]],
) -> VarResult:
    """Find every setter file for ``name`` (across its language aliases) + dep vars."""
    res = VarResult(name=_short_name(name, language), language=language)

    # Build the list of (search_name, search_language) probes: the variable itself in
    # its own language, plus high-certainty cross-language aliases.
    probes: List[Tuple[str, str]] = [(name, language)]
    aliases, home_stems = _resolve_cross_language(name, language, src_dir)
    res.home_stems |= home_stems
    for alias_name, alias_lang in aliases:
        probes.append((alias_name, alias_lang))
        res.aliases.append((alias_name, alias_lang))

    # Also probe the OPPOSITE language with the same short token, in case the
    # variable name itself appears verbatim in both languages (cheap, harmless).
    seen_probe: Set[Tuple[str, str]] = set()

    for probe_name, probe_lang in probes:
        key = (probe_name, probe_lang)
        if key in seen_probe:
            continue
        seen_probe.add(key)

        if probe_lang == "cpp":
            tail = _short_name(probe_name, "cpp")
            regex = _cpp_setter_regex(tail)
            hits = _run_grep(_cpp_grep_candidate(tail), src_dir, _CPP_EXTS)
            for hit in hits:
                if _lang_of_file(hit.path) != "cpp":
                    continue
                if not _is_cpp_setter_line(hit.text, regex):
                    continue
                res.files.add(hit.path.name)
                res.setter_count += 1
                lines = _read_file_lines(hit.path, line_cache)
                setter_line, window = _window_text(lines, hit.line_no)
                res.dep_vars |= _cpp_dep_vars(setter_line, window, tail)
        else:  # asm
            var_upper = _short_name(probe_name, "asm")
            # grep a cheap candidate pattern: the var token anywhere; precise test follows.
            pat = r"\b" + re.escape(var_upper) + r"\b"
            hits = _run_grep(pat, src_dir, _ASM_EXTS)
            for hit in hits:
                if _lang_of_file(hit.path) != "asm":
                    continue
                if not _is_asm_setter_line(hit.text, var_upper):
                    continue
                res.files.add(hit.path.name)
                res.setter_count += 1
                lines = _read_file_lines(hit.path, line_cache)
                setter_line, window = _window_text(lines, hit.line_no)
                res.dep_vars |= _asm_dep_vars(setter_line, window, var_upper)

    return res


# --------------------------------------------------------------------------- #
# BFS over variables
# --------------------------------------------------------------------------- #
@dataclass
class EnumResult:
    variable: str
    language: str
    src_dir: str
    max_depth: Optional[int]            # None == unlimited
    files: List[str]                    # sorted union of all touched file names
    files_by_depth: Dict[int, List[str]]
    vars_by_depth: Dict[int, List[str]]
    per_variable: Dict[str, Dict]       # short_name -> {depth,language,files,setters,aliases,dep_vars}
    elapsed_s: float
    home_stems: List[str] = field(default_factory=list)  # resolver home stems (for --closure triples)


def enumerate_relevant_files(
    variable: str,
    src_dir: Path,
    *,
    max_dep_var_depth: int = 3,
    unlimited: bool = False,
    language: Optional[str] = None,
) -> EnumResult:
    src_dir = Path(src_dir)
    t0 = time.time()
    line_cache: Dict[Path, List[str]] = {}

    # Guess the starting language if not given.
    if language not in ("asm", "cpp"):
        # camelCase / member-path / lowercase-with-cap => cpp; ALL-CAPS-ish => asm.
        if re.search(r"[a-z].*[A-Z]", variable) or "." in variable or "->" in variable:
            language = "cpp"
        elif variable.isupper() or "#" in variable or "$" in variable or "@" in variable:
            language = "asm"
        else:
            language = "cpp" if any(c.islower() for c in variable) else "asm"

    root_short = _short_name(variable, language)
    visited: Set[str] = {_canon_key(root_short)}
    # queue of (name, language, depth)
    q: deque = deque([(variable, language, 0)])

    all_files: Set[str] = set()
    files_by_depth: Dict[int, Set[str]] = defaultdict(set)
    vars_by_depth: Dict[int, Set[str]] = defaultdict(set)
    per_variable: Dict[str, Dict] = {}
    all_home_stems: Set[str] = set()

    depth_cap = None if unlimited else max_dep_var_depth

    while q:
        name, lang, depth = q.popleft()
        vr = _scan_one_variable(name, lang, src_dir, line_cache)

        short = vr.name
        vars_by_depth[depth].add(short)
        all_files |= vr.files
        files_by_depth[depth] |= vr.files
        all_home_stems |= vr.home_stems
        per_variable[short] = {
            "depth": depth,
            "language": lang,
            "files": sorted(vr.files),
            "setter_sites": vr.setter_count,
            "aliases": vr.aliases,
            "dep_vars": sorted(vr.dep_vars),
        }

        # Enqueue dep vars at depth+1 unless we are at the depth cap.
        if depth_cap is not None and depth >= depth_cap:
            continue
        for dep in sorted(vr.dep_vars):
            dep_key = _canon_key(dep)
            if dep_key in visited:
                continue
            visited.add(dep_key)
            # dep var inherits the language of the file/site it was found in (vr.language)
            q.append((dep, vr.language, depth + 1))

    elapsed = time.time() - t0
    return EnumResult(
        variable=variable,
        language=language,
        src_dir=str(src_dir),
        max_depth=depth_cap,
        files=sorted(all_files),
        files_by_depth={d: sorted(s) for d, s in sorted(files_by_depth.items())},
        vars_by_depth={d: sorted(s) for d, s in sorted(vars_by_depth.items())},
        per_variable=per_variable,
        elapsed_s=round(elapsed, 3),
        home_stems=sorted(all_home_stems),
    )


# --------------------------------------------------------------------------- #
# CLOSURE: close the setter SEED over #include / COPY / resolver-triple deps
# --------------------------------------------------------------------------- #
# Grep/text-only; NO blueprints, NO cfg_extract, NO engine import. Everything
# here resolves file *names* to in-dir paths and follows transitive, in-dir,
# cycle-safe dependency edges so the result is a self-contained parseable subset.

_HEADER_EXTS = (".hpp", ".hh", ".hxx", ".h")          # C++ headers (closure adds)
# ASM `COPY <member>` — label (col 1) optional, opcode COPY, then the member.
_COPY_RE = re.compile(r"^\s*\S*\s+COPY\s+([A-Za-z0-9$#@_]+)", re.IGNORECASE)


def _index_dir(src_dir: Path) -> Dict[str, Path]:
    """Map every in-dir file NAME (lowercased) -> its path. The corpus is flat;
    name->path lets us turn the BFS's file-name set back into readable paths and
    resolve `#include`/`COPY` targets to concrete in-dir files."""
    idx: Dict[str, Path] = {}
    try:
        for p in src_dir.iterdir():
            if p.is_file():
                idx.setdefault(p.name.lower(), p)
    except OSError:
        pass
    return idx


def _names_to_paths(names: Set[str], name_index: Dict[str, Path]) -> Set[Path]:
    out: Set[Path] = set()
    for n in names:
        p = name_index.get(n.lower())
        if p is not None:
            out.add(p)
    return out


def _cpp_include_closure(seed_paths: Set[Path], src_dir: Path) -> Set[Path]:
    """Transitive, in-dir, cycle-safe `#include` closure of the C++ files in the
    seed (reuses `_find_cpp_chain._included_paths`). Returns ONLY the NEWLY added
    in-dir header paths (the seed itself is excluded)."""
    base_dir = str(src_dir.resolve())
    seen: Set[str] = {str(p.resolve()) for p in seed_paths}
    added: Set[Path] = set()
    # BFS over every C++ source/header in the seed.
    queue: deque = deque(p for p in seed_paths if _lang_of_file(p) == "cpp")
    depth: Dict[str, int] = {str(p.resolve()): 0 for p in queue}
    while queue:
        cur = queue.popleft()
        cur_key = str(cur.resolve())
        if depth.get(cur_key, 0) >= _INCLUDE_MAX_DEPTH:
            continue
        try:
            text = cur.read_text(errors="replace")
        except OSError:
            continue
        for inc_abs in _included_paths(text, base_dir):
            inc = Path(inc_abs)
            key = str(inc.resolve())
            if key in seen:
                continue
            seen.add(key)
            depth[key] = depth.get(cur_key, 0) + 1
            # only headers are "added" deps; a .cpp it includes (rare) still gets
            # followed but is itself a setter-class file, not a header dep.
            if _lang_of_file(inc) == "cpp":
                if inc.name.lower().endswith(_HEADER_EXTS):
                    added.add(inc)
                queue.append(inc)
    return added


def _asm_copy_closure(seed_paths: Set[Path], name_index: Dict[str, Path],
                      src_dir: Path) -> Set[Path]:
    """Transitive, in-dir, cycle-safe `COPY <member>` closure of the ASM files in
    the seed. A `COPY MEMBER` resolves to an in-dir `member.mac`/`member.asm`
    (case-insensitive); anything not present in-dir is skipped (closure never
    escapes the source dir). Returns ONLY the newly added macro/copybook paths."""
    seen: Set[str] = {str(p.resolve()) for p in seed_paths}
    added: Set[Path] = set()
    queue: deque = deque(p for p in seed_paths if _lang_of_file(p) == "asm")
    depth: Dict[str, int] = {str(p.resolve()): 0 for p in queue}
    while queue:
        cur = queue.popleft()
        cur_key = str(cur.resolve())
        if depth.get(cur_key, 0) >= _INCLUDE_MAX_DEPTH:
            continue
        try:
            text = cur.read_text(errors="replace")
        except OSError:
            continue
        for raw in text.splitlines():
            m = _COPY_RE.match(raw)
            if not m:
                continue
            member = m.group(1).lower()
            # resolve <member> to an in-dir file: prefer .mac, then copybook/.asm.
            target = None
            for ext in (".mac", ".cpy", ".copy", ".asm"):
                cand = name_index.get(member + ext)
                if cand is not None:
                    target = cand
                    break
            if target is None:
                target = name_index.get(member)   # bare member file, if any
            if target is None:
                continue
            key = str(target.resolve())
            if key in seen:
                continue
            seen.add(key)
            depth[key] = depth.get(cur_key, 0) + 1
            added.add(target)
            queue.append(target)
    return added


def _resolver_triples(home_stems: List[str],
                      name_index: Dict[str, Path]) -> Set[Path]:
    """For each resolver ``home_stem`` add whichever of the triple files exist
    in-dir: ``cc<stem>.hpp`` (app header), ``<stem>.hpp`` (gen header),
    ``<stem>.mac`` (DSECT). These let the cross-language name resolver run inside
    the copied subset. Missing members are simply skipped."""
    out: Set[Path] = set()
    for stem in home_stems:
        for cand in (f"cc{stem}.hpp", f"{stem}.hpp", f"{stem}.mac"):
            p = name_index.get(cand.lower())
            if p is not None:
                out.add(p)
    return out


@dataclass
class ClosureResult:
    variable: str
    src_dir: str
    seed_files: List[str]               # the setter (lineage) files (BFS output)
    added_headers: List[str]            # C++ #include closure additions
    added_macros: List[str]             # ASM COPY/macro closure additions
    triple_files: List[str]             # resolver cc<stem>/stem.hpp/stem.mac files
    files: List[str]                    # the FULL closed set (sorted, deduped)
    home_stems: List[str]
    by_ext: Dict[str, int]              # extension -> count over the closed set
    enum: EnumResult                    # the underlying seed enumeration
    chain_files: List[str] = field(default_factory=list)  # --chain backbone files added to the seed


def compute_closure(enum: EnumResult, src_dir: Path,
                    chain: Optional[List[Tuple[str, str]]] = None) -> ClosureResult:
    """Close the setter SEED (``enum.files``) into a self-contained, parseable
    subset by adding (A) the C++ `#include` closure, (B) the ASM `COPY`/macro
    closure, and (C) the resolver TRIPLES for every home_stem the BFS surfaced.

    ``chain`` (the trace's BACKBONE — a list of ``(stem, language)`` hops, e.g.
    aa71/dw730000/dw710000) is folded into the SEED too: the prefix hop files often
    contain no setter of the variable but are required for the trace, and their
    own #include/COPY/triple deps must be closed. So the subset = setter-files
    (var + counterpart) + chain files + every transitive dep of all of them.

    Pure grep/text + in-dir transitive following; the include/COPY closures are
    re-run over the triple files so a triple's own in-dir headers/macros come in
    too. Deterministic: every collection is name-sorted."""
    src_dir = Path(src_dir)
    name_index = _index_dir(src_dir)

    seed_names: Set[str] = set(enum.files)
    # --chain: resolve each backbone hop stem to its in-dir source file and add it
    # to the seed (so the include/COPY/triple closure runs over it too).
    chain_names: Set[str] = set()
    for stem, lang in (chain or []):
        if lang == "cpp":
            exts = (".cpp", ".cc", ".cxx")
        elif lang == "asm":
            exts = (".asm", ".mac", ".s")
        else:                                   # language not given → try both
            exts = (".cpp", ".cc", ".cxx", ".asm", ".mac", ".s")
        for ext in exts:
            if (stem + ext).lower() in name_index:
                chain_names.add(stem + ext)
                break
    seed_names |= chain_names
    seed_paths = _names_to_paths(seed_names, name_index)

    # (C) resolver triples first, so their headers/macros also get closed below.
    triple_paths = _resolver_triples(enum.home_stems, name_index)

    # Base set for the include/COPY closures = seed + triple files.
    base_paths = set(seed_paths) | triple_paths

    # (A) C++ #include closure, (B) ASM COPY/macro closure — over seed + triples.
    header_paths = _cpp_include_closure(base_paths, src_dir)
    macro_paths = _asm_copy_closure(base_paths, name_index, src_dir)

    # Categorize. A triple file is reported under "triple"; headers/macros are
    # whatever the closures added beyond seed+triples (no double counting).
    triple_names = {p.name for p in triple_paths}
    header_names = {p.name for p in header_paths} - seed_names - triple_names
    macro_names = {p.name for p in macro_paths} - seed_names - triple_names

    full = seed_names | triple_names | header_names | macro_names

    by_ext: Dict[str, int] = defaultdict(int)
    for n in full:
        by_ext[Path(n).suffix.lower() or "(none)"] += 1

    return ClosureResult(
        variable=enum.variable,
        src_dir=str(src_dir),
        seed_files=sorted(seed_names - chain_names),   # pure setter-files (var + counterpart)
        added_headers=sorted(header_names),
        added_macros=sorted(macro_names),
        triple_files=sorted(triple_names),
        files=sorted(full),
        home_stems=list(enum.home_stems),
        by_ext={k: by_ext[k] for k in sorted(by_ext)},
        enum=enum,
        chain_files=sorted(chain_names),
    )


def copy_closure_files(closure: ClosureResult, src_dir: Path,
                       dest_dir: Path) -> Tuple[int, List[str]]:
    """Copy every file in the closed set into ``dest_dir`` (flat). Returns
    (copied_count, [missing_names]). Existing dest files are overwritten so a
    re-run is deterministic."""
    src_dir = Path(src_dir)
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    name_index = _index_dir(src_dir)
    copied = 0
    missing: List[str] = []
    for name in closure.files:
        srcp = name_index.get(name.lower())
        if srcp is None or not srcp.is_file():
            missing.append(name)
            continue
        shutil.copy2(srcp, dest_dir / srcp.name)
        copied += 1
    return copied, sorted(missing)


def _format_closure_report(c: ClosureResult) -> str:
    out: List[str] = []
    out.append("")
    out.append("=" * 72)
    out.append(f"CLOSURE (self-contained parseable subset) for: {c.variable}")
    out.append(f"  codebase dir : {c.src_dir}")
    if c.home_stems:
        out.append(f"  home stems   : {', '.join(c.home_stems)}")
    out.append("=" * 72)
    out.append(f"  seed setter-files : {len(c.seed_files)}")
    if c.chain_files:
        out.append(f"  + chain backbone  : {len(c.chain_files)}  ({', '.join(c.chain_files)})")
    out.append(f"  + #include headers: {len(c.added_headers)}"
               + (f"  ({', '.join(c.added_headers)})" if c.added_headers else ""))
    out.append(f"  + COPY macros     : {len(c.added_macros)}"
               + (f"  ({', '.join(c.added_macros)})" if c.added_macros else ""))
    out.append(f"  + resolver triples: {len(c.triple_files)}"
               + (f"  ({', '.join(c.triple_files)})" if c.triple_files else ""))
    out.append(f"  ---------------------------------------------------")
    out.append(f"  GRAND TOTAL files : {len(c.files)}")
    out.append(f"  by extension      : "
               + ", ".join(f"{ext} x{n}" for ext, n in c.by_ext.items()))
    out.append("")
    out.append("Closed file list:")
    for f in c.files:
        tag = ""
        if f in set(c.chain_files):
            tag = "  [chain]"
        elif f in set(c.triple_files):
            tag = "  [triple]"
        elif f in set(c.added_headers):
            tag = "  [+include]"
        elif f in set(c.added_macros):
            tag = "  [+COPY]"
        else:
            tag = "  [setter]"
        out.append(f"  - {f}{tag}")
    out.append("=" * 72)
    return "\n".join(out)


def _closure_to_json(c: ClosureResult) -> Dict:
    return {
        "variable": c.variable,
        "src_dir": c.src_dir,
        "home_stems": c.home_stems,
        "seed_files": c.seed_files,
        "added_headers": c.added_headers,
        "added_macros": c.added_macros,
        "triple_files": c.triple_files,
        "by_ext": c.by_ext,
        "total_files": len(c.files),
        "files": c.files,
    }


# --------------------------------------------------------------------------- #
# Per-file REASONS  (--reasons): why each file is in the set
# --------------------------------------------------------------------------- #
# Human-readable role text for closure-only files (no setter of any traced var).
_CLOSURE_ROLE = {
    "chain":    "chain backbone hop (carries the hop guard conditions of the trace)",
    "triple":   "cross-language resolver triple (cc<stem>.hpp/<stem>.hpp/<stem>.mac — counterpart resolution)",
    "+include": "#include closure (a kept .cpp/.hpp includes it — needed so C++ types resolve)",
    "+COPY":    "COPY/macro closure (a kept .asm/.mac COPYs it — needed so DSECTs/macros resolve)",
    "closure":  "parse/resolve dependency",
}
# Stable category ordering for the report (setter files first).
_CAT_RANK = {"setter": 0, "chain": 1, "triple": 2, "+include": 3, "+COPY": 4, "closure": 5}


def _build_reasons(r: EnumResult,
                   closure: Optional[ClosureResult] = None) -> Dict[str, Dict]:
    """Invert ``per_variable`` into a per-FILE justification map — the 'reason for
    inclusion' the lite (grep) path can emit without a full trace.

    For every file we record which traced variable(s) are *written* there (with
    the dep-var BFS depth + language that surfaced them), and — when a closure was
    computed — the structural category (setter / chain / triple / +include / +COPY)
    so closure-only files (headers, macros, backbone hops with no setter) still
    carry a concrete role.  Returns ``{file: {category, variables:[{name,depth,language}]}}``."""
    # file -> [(depth, name, language)] for every variable whose setters touch it
    setter_reasons: Dict[str, List[Tuple[int, str, str]]] = defaultdict(list)
    for name, info in r.per_variable.items():
        for f in info["files"]:
            setter_reasons[f].append((info["depth"], name, info["language"]))

    # Universe = the seed enumeration, or the full closed set when --closure.
    if closure is not None:
        universe: List[str] = list(closure.files)
        chain_s, triple_s = set(closure.chain_files), set(closure.triple_files)
        hdr_s, mac_s = set(closure.added_headers), set(closure.added_macros)

        def _cat(f: str) -> str:
            if f in chain_s:
                return "chain"
            if f in triple_s:
                return "triple"
            if f in hdr_s:
                return "+include"
            if f in mac_s:
                return "+COPY"
            return "setter"
    else:
        universe = list(r.files)

        def _cat(f: str) -> str:                       # no closure → setter vs (none)
            return "setter" if setter_reasons.get(f) else "closure"

    out: Dict[str, Dict] = {}
    for f in universe:
        vars_here = sorted(setter_reasons.get(f, []))   # by (depth, name, language)
        out[f] = {
            "category": _cat(f),
            "variables": [{"name": n, "depth": d, "language": l}
                          for d, n, l in vars_here],
        }
    return out


def _format_reasons(r: EnumResult,
                    closure: Optional[ClosureResult] = None) -> str:
    reasons = _build_reasons(r, closure)
    out: List[str] = []
    out.append("")
    out.append("=" * 72)
    out.append(f"PER-FILE REASONS for: {r.variable}")
    out.append("  (why each file is in the set: the variable(s) written there + its role)")
    out.append("=" * 72)

    def _key(item: Tuple[str, Dict]):
        f, info = item
        vs = info["variables"]
        min_d = vs[0]["depth"] if vs else 99
        return (0 if vs else 1, min_d, _CAT_RANK.get(info["category"], 9), f)

    for f, info in sorted(reasons.items(), key=_key):
        cat, vs = info["category"], info["variables"]
        out.append(f"  - {f}  [{cat}]")
        if vs:
            vtxt = "; ".join(f"{v['name']} (d{v['depth']},{v['language']})" for v in vs)
            out.append(f"        sets: {vtxt}")
        else:
            out.append(f"        role: {_CLOSURE_ROLE.get(cat, _CLOSURE_ROLE['closure'])}")
    out.append("=" * 72)
    return "\n".join(out)


# --------------------------------------------------------------------------- #
# Reporting
# --------------------------------------------------------------------------- #
def _format_report(r: EnumResult) -> str:
    out: List[str] = []
    depth_label = "unlimited" if r.max_depth is None else str(r.max_depth)
    out.append("=" * 72)
    out.append(f"RELEVANT FILES for variable: {r.variable}")
    out.append(f"  start language : {r.language}")
    out.append(f"  codebase dir   : {r.src_dir}")
    out.append(f"  dep-var depth  : {depth_label}")
    out.append(f"  elapsed        : {r.elapsed_s}s   (rg={'yes' if _HAS_RG else 'no (grep)'})")
    out.append("=" * 72)

    out.append("")
    out.append("Per-depth breakdown:")
    for depth in sorted(set(r.files_by_depth) | set(r.vars_by_depth)):
        dvars = r.vars_by_depth.get(depth, [])
        dfiles = r.files_by_depth.get(depth, [])
        out.append(f"  depth {depth}: {len(dvars)} var(s), {len(dfiles)} file(s)")
        out.append(f"    vars : {', '.join(dvars) if dvars else '(none)'}")
        out.append(f"    files: {', '.join(dfiles) if dfiles else '(none)'}")

    out.append("")
    out.append("Per-variable breakdown:")
    # Order variables by depth then name for stable reading.
    ordered = sorted(r.per_variable.items(), key=lambda kv: (kv[1]["depth"], kv[0]))
    for short, info in ordered:
        alias_str = ""
        if info["aliases"]:
            alias_str = "  aliases=" + ",".join(f"{n}({l})" for n, l in info["aliases"])
        out.append(
            f"  [d{info['depth']}] {short} ({info['language']}): "
            f"{info['setter_sites']} setter-site(s) in "
            f"{len(info['files'])} file(s){alias_str}"
        )
        if info["files"]:
            out.append(f"        files: {', '.join(info['files'])}")

    out.append("")
    out.append(f"TOTAL files touched: {len(r.files)}")
    for f in r.files:
        out.append(f"  - {f}")
    out.append("=" * 72)
    return "\n".join(out)


def _result_to_json(r: EnumResult) -> Dict:
    return {
        "variable": r.variable,
        "language": r.language,
        "src_dir": r.src_dir,
        "max_dep_var_depth": r.max_depth,  # None == unlimited
        "elapsed_s": r.elapsed_s,
        "total_files": len(r.files),
        "files": r.files,
        "files_by_depth": {str(k): v for k, v in r.files_by_depth.items()},
        "vars_by_depth": {str(k): v for k, v in r.vars_by_depth.items()},
        "per_variable": r.per_variable,
    }


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(
        prog="python -m vbt.relevant_files",
        description="Enumerate ALL files touched by a variable's full dependent-variable "
                    "lineage (grep-based scope over-approximation; no blueprints needed).",
    )
    ap.add_argument("variable", help="the starting variable (C++ field tail or ASM symbol)")
    ap.add_argument("--dir", required=True, help="codebase directory (source files only)")
    ap.add_argument("--max-dep-var-depth", type=int, default=3,
                    help="max dependent-variable BFS depth (default 3; 0 = root only)")
    ap.add_argument("--unlimited", action="store_true",
                    help="ignore --max-dep-var-depth; traverse until no new dep vars (cycle-safe)")
    ap.add_argument("--language", choices=("asm", "cpp"), default=None,
                    help="optional starting-language hint")
    ap.add_argument("--closure", "--with-deps", dest="closure", action="store_true",
                    help="close the setter SEED into a self-contained parseable subset: "
                         "add the C++ #include closure, the ASM COPY/macro closure, and "
                         "the resolver cc<stem>.hpp/<stem>.hpp/<stem>.mac triples")
    ap.add_argument("--copy-to", dest="copy_to", default=None,
                    help="copy the resulting file set (the CLOSED set when --closure) into "
                         "this directory, flat, ready to parse + trace")
    ap.add_argument("--chain", default=None,
                    help="comma-separated chain/backbone hops 'stem[:asm|cpp]' (the trace "
                         "prefix, e.g. 'aa71:asm,dw730000:cpp,dw710000:cpp'); with --closure "
                         "these files + their #include/COPY/triple deps are folded into the subset")
    ap.add_argument("--reasons", action="store_true",
                    help="print a PER-FILE justification (which variable/dep-var is written "
                         "there, at what BFS depth, + the file's role) — the 'reason for "
                         "inclusion' for each file; honours --closure for header/macro/triple roles")
    ap.add_argument("--json", default=None, help="optional path to write machine JSON output")
    args = ap.parse_args(argv)

    src_dir = Path(args.dir)
    if not src_dir.is_dir():
        print(f"error: --dir not a directory: {src_dir}", file=sys.stderr)
        return 2

    r = enumerate_relevant_files(
        args.variable,
        src_dir,
        max_dep_var_depth=args.max_dep_var_depth,
        unlimited=args.unlimited,
        language=args.language,
    )

    print(_format_report(r))

    chain: List[Tuple[str, str]] = []
    for hop in (args.chain or "").split(","):
        hop = hop.strip()
        if not hop:
            continue
        parts = hop.split(":")
        chain.append((parts[0].strip(), parts[1].strip() if len(parts) > 1 else ""))

    closure: Optional[ClosureResult] = None
    if args.closure:
        closure = compute_closure(r, src_dir, chain=chain)
        print(_format_closure_report(closure))

    if args.reasons:
        print(_format_reasons(r, closure))

    # --copy-to copies the CLOSED set when --closure, else the raw seed set.
    if args.copy_to:
        dest = Path(args.copy_to)
        if closure is not None:
            copied, missing = copy_closure_files(closure, src_dir, dest)
            total = len(closure.files)
        else:
            name_index = _index_dir(src_dir)
            dest.mkdir(parents=True, exist_ok=True)
            copied, missing = 0, []
            for name in r.files:
                srcp = name_index.get(name.lower())
                if srcp is None or not srcp.is_file():
                    missing.append(name)
                    continue
                shutil.copy2(srcp, dest / srcp.name)
                copied += 1
            total = len(r.files)
        print(f"\n[copied {copied}/{total} file(s) into {dest}]")
        if missing:
            print(f"[WARNING: {len(missing)} file(s) not found in --dir: "
                  f"{', '.join(missing)}]")

    if args.json:
        payload = _result_to_json(r)
        if closure is not None:
            payload["closure"] = _closure_to_json(closure)
        if args.reasons:
            payload["reasons"] = _build_reasons(r, closure)
        Path(args.json).write_text(json.dumps(payload, indent=2))
        print(f"\n[json written to {args.json}]")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
