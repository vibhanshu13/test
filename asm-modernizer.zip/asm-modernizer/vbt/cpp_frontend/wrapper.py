"""VBT C++ frontend — Python wrapper around the cfg_extract LibTooling binary.

Standalone: no kb_id, no project imports. Just runs the compiled tool as a
subprocess with best-effort parse flags and returns one dict per function.

Usage:
    from wrapper import run_cfg_extract
    funcs = run_cfg_extract("/path/to/file.cpp")
    funcs = run_cfg_extract("/path/to/file.cpp",
                            extra_args=["-I/path/to/headers"])

The binary emits JSONL (one JSON object per function definition in the main
file). See README.md for the schema.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
from typing import Any, Dict, List, Optional, Tuple

# Location of the compiled tool (sibling of this module).
_HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_BINARY = os.path.join(_HERE, "cfg_extract")

# ---------------------------------------------------------------------------
# Disk + in-process cache for cfg_extract results.
#
# LibTooling is the per-query hot path: the binary is re-invoked for every cpp
# file every traversal. At 22k files this dominates latency. We cache the
# parsed JSONL result keyed on a fingerprint of the source file AND the
# extractor binary, so a re-build of the tool or an edit to the source file
# transparently invalidates the entry.
#
# Cache dir is configurable via VBT_CACHE_DIR (default vbt/.cache/cfg). Each
# entry is a single .json file named after the SHA-256 fingerprint key; its
# payload is the list[dict] returned by run_cfg_extract.
#
# The in-process memo (_MEMO) short-circuits the disk round-trip when the same
# (cpp_path, key) is requested repeatedly within one process.
# ---------------------------------------------------------------------------

# vbt/.cache/cfg  — _HERE is vbt/cpp_frontend, so go up one level to vbt/.
_DEFAULT_CACHE_DIR = os.path.join(os.path.dirname(_HERE), ".cache", "cfg")

# fingerprint-key -> parsed result (list[dict]); populated on hit or miss.
_MEMO: Dict[str, List[Dict[str, Any]]] = {}

# VBT DB-backed cfg cache (DB_PRECOMPUTE_PLAN.md T8): optional, decoupled GET/PUT callbacks so
# a caller can serve/persist cfg_extract results from index.db keyed by the content-hash key.
# Both ``None`` by default → ZERO effect (disk cache path runs unchanged). GET(key)->list|None;
# PUT(key, funcs)->None. Decoupled via callbacks so this module imports neither vbt/ nor
# api.index_db. The key is content-addressed, so a served blob is never stale.
_CFG_DB_GET = None  # type: Optional[Any]
_CFG_DB_PUT = None  # type: Optional[Any]


def set_cfg_db_hooks(get_fn, put_fn) -> None:
    global _CFG_DB_GET, _CFG_DB_PUT
    _CFG_DB_GET, _CFG_DB_PUT = get_fn, put_fn


def clear_cfg_db_hooks() -> None:
    global _CFG_DB_GET, _CFG_DB_PUT
    _CFG_DB_GET = _CFG_DB_PUT = None


def _cache_dir() -> str:
    """Resolve the cfg cache directory (env-overridable). Created on demand."""
    base = os.environ.get("VBT_CACHE_DIR")
    if base:
        return os.path.join(base, "cfg")
    return _DEFAULT_CACHE_DIR


def _mtime_size(path: str) -> Tuple[float, int]:
    """(mtime, size) for `path`, or (0.0, -1) if it cannot be stat'd."""
    try:
        st = os.stat(path)
        return st.st_mtime, st.st_size
    except OSError:
        return 0.0, -1


def _cache_key(cpp_path: str, binary: str, extra_args: Optional[List[str]]) -> str:
    """SHA-256 over absolute source path + size + mtime + binary mtime (+ args).

    Includes extra_args so different include-dir invocations don't collide.
    """
    abs_cpp = os.path.abspath(cpp_path)
    cpp_mtime, cpp_size = _mtime_size(abs_cpp)
    bin_mtime, _ = _mtime_size(binary)
    parts = [
        abs_cpp,
        str(cpp_size),
        repr(cpp_mtime),
        repr(bin_mtime),
        "|".join(extra_args or []),
    ]
    return hashlib.sha256("\x00".join(parts).encode("utf-8")).hexdigest()


# extractor-binary content fingerprint, memoized on (path, mtime, size) so the binary is
# hashed at most once per process (re-hashed only if it actually changes on disk).
_BIN_FP_CACHE: Dict[Tuple[str, float, int], str] = {}


def _binary_fingerprint(binary: str) -> Optional[str]:
    abs_bin = os.path.abspath(binary)
    mtime, size = _mtime_size(abs_bin)
    if size < 0:
        return None
    k = (abs_bin, mtime, size)
    fp = _BIN_FP_CACHE.get(k)
    if fp is None:
        try:
            h = hashlib.sha256()
            with open(abs_bin, "rb") as fh:
                for chunk in iter(lambda: fh.read(1 << 20), b""):
                    h.update(chunk)
            fp = h.hexdigest()
        except OSError:
            return None
        _BIN_FP_CACHE.clear()          # at most one live binary — drop stale entries
        _BIN_FP_CACHE[k] = fp
    return fp


def _db_cfg_key(cpp_path: str, binary: str, parse_flags: Optional[List[str]]) -> Optional[str]:
    """CONTENT-addressed key for the DB (index.db) cfg tier — SHA-256 over the source file's
    basename + BYTES, the extractor binary's CONTENT fingerprint, and the parse flags with the
    machine-specific source-dir path normalized out.

    The mtime/abs-path ``_cache_key`` above is the right key for the per-machine memo/disk
    tiers (no content read), but it is WRONG for blobs that outlive the machine state: a
    redeploy (new binary mtime), a re-extracted corpus (new file mtimes) or a moved workspace
    (new abs paths) changes every mtime key at once — every stored cfg blob in the KB goes
    unreachable and the trace silently falls back to a live Clang subprocess per file (minutes
    to hours at 22k). This key depends only on WHAT is parsed and WITH WHAT, so a precomputed
    blob keeps serving across redeploys/re-ingests. Returns None when the source can't be read
    (the DB tier is then skipped)."""
    try:
        with open(cpp_path, "rb") as fh:
            src_hash = hashlib.sha256(fh.read()).hexdigest()
    except OSError:
        return None
    bin_fp = _binary_fingerprint(binary)
    if bin_fp is None:
        return None
    src_dir = os.path.dirname(os.path.abspath(cpp_path))
    norm_flags = ["<srcdir>" if a == src_dir else a for a in (parse_flags or [])]
    parts = [os.path.basename(cpp_path), src_hash, bin_fp, "|".join(norm_flags)]
    return "c:" + hashlib.sha256("\x00".join(parts).encode("utf-8")).hexdigest()


def _cache_path(key: str) -> str:
    return os.path.join(_cache_dir(), f"{key}.json")


def _cache_load(key: str) -> Optional[List[Dict[str, Any]]]:
    """Return the cached result for `key`, or None on miss / unreadable entry."""
    path = _cache_path(key)
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return None
    if isinstance(data, list):
        return data
    return None


def _cache_store(key: str, funcs: List[Dict[str, Any]]) -> None:
    """Atomically write `funcs` to the cache. Best-effort: never raises."""
    try:
        d = _cache_dir()
        os.makedirs(d, exist_ok=True)
        path = _cache_path(key)
        tmp = f"{path}.{os.getpid()}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(funcs, fh)
        os.replace(tmp, path)
    except OSError:
        pass

# Best-effort compiler flags after the `--` separator. These let most function
# bodies parse even when z/TPF headers are missing:
#   -ferror-limit=0  keep going past the missing-header fatal
#   -w               silence all warnings
#   -std=c++17       the codebase dialect ("C with classes")
#   -fsyntax-only    no codegen needed
DEFAULT_PARSE_FLAGS = ["-ferror-limit=0", "-w", "-std=c++17", "-fsyntax-only"]


# The macOS SDK path is invariant for the life of the process, so detect it AT MOST
# ONCE. Before this memo, ``_detect_sdk_isysroot`` ran on EVERY ``run_cfg_extract`` call
# (it builds parse_flags, which precede the cache-key lookup), spawning an ``xcrun``
# subprocess each time — ~14k needless spawns / >50% of a depth-2 trace's wall time, even
# though every cfg result was already memo/DB/disk-cached. Empty list = not yet detected;
# ``[value]`` = detected (value may be None = "no SDK"). Byte-identical: the cached path is
# the same xcrun output, so parse_flags + cache key + cfg result are unchanged. COW-safe:
# forked workers inherit the parent's already-populated cache.
_SDK_ISYSROOT_CACHE: List[Optional[str]] = []


def _detect_sdk_isysroot() -> Optional[str]:
    """On macOS, brew-LLVM/libc++ needs the SDK to find system headers
    (time_t, FP_* macros, <cstring>...). Return an -isysroot arg or None.
    Memoized per process — ``xcrun`` is spawned at most once."""
    if _SDK_ISYSROOT_CACHE:
        return _SDK_ISYSROOT_CACHE[0]
    result: Optional[str] = None
    xcrun = shutil.which("xcrun")
    if xcrun:
        try:
            out = subprocess.run(
                [xcrun, "--show-sdk-path"],
                capture_output=True, text=True, timeout=10,
            )
            sdk = out.stdout.strip()
            if sdk and os.path.isdir(sdk):
                result = sdk
        except Exception:
            pass
    _SDK_ISYSROOT_CACHE.append(result)
    return result


def run_cfg_extract(
    cpp_path: str,
    extra_args: Optional[List[str]] = None,
    binary: str = DEFAULT_BINARY,
    timeout: int = 120,
) -> List[Dict[str, Any]]:
    """Run cfg_extract on `cpp_path` and return a list of per-function dicts.

    Parameters
    ----------
    cpp_path : str
        Path to the C++ translation unit to analyze.
    extra_args : list[str], optional
        Extra compiler args appended after `--` (e.g. ``-I`` include dirs).
        These are added on top of DEFAULT_PARSE_FLAGS.
    binary : str
        Path to the compiled cfg_extract binary.
    timeout : int
        Subprocess timeout in seconds.

    Returns
    -------
    list[dict]
        One dict per function definition found in the main file. Empty if the
        translation unit produced no parseable function bodies.

    Notes
    -----
    A non-zero exit code is EXPECTED when headers are missing (Clang reports a
    fatal "file not found" but still recovers many bodies). We therefore parse
    stdout regardless of the return code and only raise if stdout is empty AND
    there was no JSON at all.
    """
    if not os.path.isfile(binary):
        raise FileNotFoundError(
            f"cfg_extract binary not found at {binary!r}. Run build.sh first."
        )
    if not os.path.isfile(cpp_path):
        raise FileNotFoundError(f"source file not found: {cpp_path!r}")

    # Resolve the FULL effective flag list (defaults + auto-detected SDK + caller
    # args) BEFORE the cache lookup so the cache key reflects every flag that
    # affects the parse (D7 — an SDK/Xcode change or a shared $VBT_CACHE_DIR must
    # not serve a parse produced under different effective flags).
    parse_flags = list(DEFAULT_PARSE_FLAGS)
    sdk = _detect_sdk_isysroot()
    if sdk:
        parse_flags += ["-isysroot", sdk]
    # The file's OWN directory is its natural include path: a z/TPF source does
    # ``#include <paapi.hpp>`` / ``#include <cclwrrr.hpp>`` for sibling headers, and
    # without ``-I <srcdir>`` Clang's angled-include search never finds them — so their
    # types don't resolve and CFG::buildCFG TRUNCATES the function body at the first
    # unresolved-type construct (e.g. a ``switch`` over an unresolved scrutinee), making
    # all later statements/calls/guards invisible (~7% of functions on a partial corpus).
    # Adding the source dir recovers every truncation whose headers are present-but-
    # unsearched. (Transitively-MISSING headers, e.g. casind.hpp absent from the extract,
    # still truncate — that's corpus completeness, resolved by the full 22k header set.)
    src_dir = os.path.dirname(os.path.abspath(cpp_path))
    parse_flags += ["-I", src_dir]
    if extra_args:
        parse_flags += list(extra_args)

    # --- cache lookup (in-process memo, then DB, then disk) -----------------
    # memo/disk use the cheap per-machine mtime key; the DB tier uses the CONTENT-addressed
    # key (_db_cfg_key) so KB blobs survive redeploys / re-ingests / workspace moves — see
    # the _db_cfg_key docstring for the failure mode the mtime key has there.
    key = _cache_key(cpp_path, binary, parse_flags)
    memo_hit = _MEMO.get(key)
    if memo_hit is not None:
        return memo_hit
    # T8: DB tier (before disk) when installed — serves cfg from index.db so a warm trace
    # touches no cfg file. Content-hash key ⇒ never stale. Best-effort.
    db_key: Optional[str] = None
    if _CFG_DB_GET is not None or _CFG_DB_PUT is not None:
        db_key = _db_cfg_key(cpp_path, binary, parse_flags)
    if _CFG_DB_GET is not None and db_key is not None:
        try:
            db_hit = _CFG_DB_GET(db_key)
        except Exception:
            db_hit = None
        if db_hit is not None:
            _MEMO[key] = db_hit
            return db_hit
    disk_hit = _cache_load(key)
    if disk_hit is not None:
        _MEMO[key] = disk_hit
        if _CFG_DB_PUT is not None and db_key is not None:
            try:                           # warm the DB from the disk cfg cache (incremental)
                _CFG_DB_PUT(db_key, disk_hit)
            except Exception:
                pass
        return disk_hit
    # ------------------------------------------------------------------------

    cmd = [binary, cpp_path, "--"] + parse_flags

    proc = subprocess.run(
        cmd, capture_output=True, text=True, timeout=timeout
    )

    funcs: List[Dict[str, Any]] = []
    for line in proc.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            funcs.append(json.loads(line))
        except json.JSONDecodeError:
            # Skip any stray non-JSON line; the tool emits strict JSONL but be
            # defensive.
            continue

    if not funcs and proc.returncode != 0 and not proc.stdout.strip():
        # Nothing parsed at all — surface the compiler error. Don't cache: this
        # is likely a transient/env failure, not a stable empty result.
        raise RuntimeError(
            f"cfg_extract produced no output for {cpp_path!r}.\n"
            f"exit={proc.returncode}\nstderr:\n{proc.stderr[:2000]}"
        )

    _cache_store(key, funcs)
    _MEMO[key] = funcs
    if _CFG_DB_PUT is not None and db_key is not None:
        try:
            _CFG_DB_PUT(db_key, funcs)
        except Exception:
            pass
    return funcs


def warm_cfg_cache(cpp_path: str) -> bool:
    """Pre-populate the disk cfg cache for one cpp file. Picklable, fault-isolated.

    Intended as the ``fn`` for a ``parallel_map`` cfg-warm step over all cpp
    sources: each worker invokes ``run_cfg_extract`` (which writes its own
    ``{key}.json`` atomically — race-safe across workers) and returns whether the
    warm succeeded. A failure on one file (missing binary, parse blow-up,
    timeout) is swallowed and returns ``False`` so it never aborts the batch.

    The per-file subprocess timeout honours ``VBT_FILE_TIMEOUT_SECONDS``
    (default 120).
    """
    try:
        timeout = int(os.environ.get("VBT_FILE_TIMEOUT_SECONDS", "") or 120)
    except (TypeError, ValueError):
        timeout = 120
    try:
        run_cfg_extract(cpp_path, timeout=timeout)
        return True
    except Exception:
        return False


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("usage: python wrapper.py <file.cpp> [extra -I args...]")
        raise SystemExit(2)
    extra = sys.argv[2:] or None
    result = run_cfg_extract(sys.argv[1], extra_args=extra)
    print(json.dumps(result, indent=2))
