# VBT C++ Frontend — `cfg_extract` (Clang LibTooling)

A small Clang LibTooling tool that, for **each function definition** in a C++
translation unit, builds a **real `clang::CFG`** (`CFG::buildCFG`) and emits a
faithful, structured JSON description: CFG blocks with labeled edges + per-block
terminator condition, fully-resolved member-path assignments, calls with
by-reference argument indices, by-reference/pointer parameters with a "written"
flag, and referenced enum constants with their integer values.

This is the C++ half of the VBT engine (SPEC §5). The tool emits **facts**; it
does **not** compute path-conditions — the Python reachability engine walks the
emitted CFG. But it does the work that requires the typed AST: member-path
resolution, enum-value resolution, and by-ref param-write detection.

No `kb_id`, no project imports, no DB.

---

## Build

Requires Homebrew LLVM 22 (`brew install llvm`) at `/opt/homebrew/opt/llvm`.

```bash
./build.sh          # produces ./cfg_extract
```

The build links against the single shared `libclang-cpp` + `libLLVM` dylibs
(`-lclang-cpp -lLLVM`) and bakes an rpath to the brew lib dir. On macOS it
passes `-isysroot $(xcrun --show-sdk-path)` so brew's libc++ headers can find
the system SDK headers (`time_t`, `FP_*`, `<cstring>`, …). Override the
toolchain with `LLVM_PREFIX`, `LLVM_CONFIG`, `CXX`, or `SDKROOT` env vars.

Working link command (recorded for reference):

```
clang++ -I/opt/homebrew/Cellar/llvm/22.1.7/include -std=c++17 -stdlib=libc++ \
  -D__STDC_CONSTANT_MACROS -D__STDC_FORMAT_MACROS -D__STDC_LIMIT_MACROS \
  -fno-exceptions -isysroot $(xcrun --show-sdk-path) -fno-rtti \
  cfg_extract.cpp -o cfg_extract \
  -L/opt/homebrew/Cellar/llvm/22.1.7/lib -Wl,-search_paths_first \
  -Wl,-rpath,/opt/homebrew/Cellar/llvm/22.1.7/lib -lclang-cpp -lLLVM
```

---

## Run

Direct (note the `--` separator before compiler flags):

```bash
./cfg_extract path/to/file.cpp -- -ferror-limit=0 -w -std=c++17 \
    -isysroot "$(xcrun --show-sdk-path)" [-I/path/to/headers ...]
```

Via the Python wrapper (adds best-effort flags + SDK isysroot automatically):

```python
from wrapper import run_cfg_extract
funcs = run_cfg_extract("path/to/file.cpp")                       # best effort
funcs = run_cfg_extract("path/to/file.cpp",
                        extra_args=["-I/path/to/headers"])        # with headers
```

**Missing headers are expected.** With no z/TPF headers, Clang reports a fatal
`'paapi.hpp' file not found` and exits non-zero — but it still recovers and
emits **most** function bodies. The wrapper parses stdout regardless of exit
code. See *Limitations* for what degrades without types.

### Caching + parallel pre-warm

`run_cfg_extract` is **disk-cached** per file content-hash (+ binary mtime + the full
resolved parse flags incl. the macOS SDK `-isysroot`) under `$VBT_CACHE_DIR/cfg`
(default `vbt/.cache/cfg`). VBT precompute **Step 5 (cfg-warm)** runs the tool in
**parallel** over every `*.cpp` source up front via `wrapper.warm_cfg_cache` +
`vbt/precompute/parallel.py` (RAM/CPU-aware `ProcessPoolExecutor`; each worker writes its
own `{key}.json` atomically, so the warm is race-safe). This front-loads the per-file
Clang cost so traces hit the cache instead of re-shelling out — the dominant 22k
cold-start win. Run it via `python -m vbt.precompute_all` (Step 5; `--no-cfg-warm` to
skip) or the `asm.vbt_precompute` Celery task. Per-file timeout: `VBT_FILE_TIMEOUT_SECONDS`
(default 120).

---

## Output format

**JSONL** — one JSON object per line, one object per function definition that
lives in the **main file** (header bodies that happened to parse are skipped).

```jsonc
{
  "file": "/abs/path/file.cpp",
  "function": "Namespace::qualifiedName",

  "cfg_blocks": [
    {
      "id": 17,                       // CFGBlock::getBlockID()
      "stmts": [
        { "line": 1002,
          "kind": "assignment|call|condition|return|break|continue|goto|other",
          "text": "whitespace-collapsed source text" }
      ],
      "terminator_kind": "if|switch|for|while|do|ternary|logical_and|logical_or|"
                         "binary|goto|indirect_goto|break|continue|return|none|other:<Class>",
      "terminator_cond_expr": "linkSourceArea->lstknpoa == 'Y'",  // "" if none
      "succs": [
        { "block_id": 16, "label": "true|false|case <v>|default|unconditional|other" }
      ],
      "preds": [ 19, 18 ]
    }
  ],

  "assignments": [
    { "line": 1002,
      "block_id": 17,
      "lhs_path": "plasticAuth.process.transactionInds.softCardValue",  // FULL resolved member path
      "rhs_expr": "SoftCardValueDetail::ExpressPayTransaction",
      "is_decl": false }                // true for `T x = init;`
  ],

  "calls": [
    { "line": 1011,
      "block_id": 15,
      "callee": "processExpressPayOnBlue",
      "args": ["plasticAuth", "lwrIso", "lwrCommon", ...],
      "by_ref_arg_indexes": [0,1,2,3,4] }   // param is ref/ptr OR arg is &expr
  ],

  "by_ref_params": [
    { "name": "plasticAuth", "type": "PlasticAuth &",
      "is_reference": true, "is_pointer": false,
      "written": true }                 // body assigns param / *param / param.field
  ],

  "params": [                           // FULL ordered formal list (incl. value params)
    { "name": "plasticAuth", "index": 0, "type": "PlasticAuth &",
      "is_reference": true, "is_pointer": false, "written": true },
    { "name": "countOfCidLrecs", "index": 2, "type": "int",
      "is_reference": false, "is_pointer": false, "written": false }
  ],                                    // dep engine maps a caller's args[index] → formal
                                        // to re-root a read-only param (IN-direction; SPEC §6b)

  "enums_used": [
    { "name": "SoftCardValueDetail::ExpressPayTransaction", "value": 7 }  // value null if unresolvable
  ]
}
```

### Edge label semantics

* **if / for / while / do / ternary / `&&` / `||`** — successor `[0]` is labeled
  `"true"` (condition taken), successor `[1]` is `"false"` (fallthrough). This
  matches Clang's CFG successor convention, so short-circuit `&&`/`||` chains and
  loop back-edges are fully recoverable.
* **switch** — each case successor is labeled `"case <case-value-text>"`;
  the default / implicit-exit edge is `"default"`. **Fallthrough** is modeled
  natively by the CFG (a case block's unconditional edge into the next case).
* **goto / break / continue / return** — single `"unconditional"` edge to the
  CFG target (the loop/switch exit, the goto label block, or the exit block).
* Everything else — `"unconditional"`.

A `block_id` of `-1` in a successor means a null CFG successor (an
unreachable/no-return/implicit-exit edge); `-1` for an assignment/call
`block_id` means the node wasn't found as a top-level CFG element (rare; only
under heavy error-recovery).

---

## How the typed-AST facts are computed

* **`lhs_path`** — resolved by walking the `MemberExpr`/`DeclRefExpr` chain
  (`buildMemberPath`). `a.b.c` and `p->b->c` both flatten to the dotted path
  `a.b.c`; `*param` resolves to `param`; `arr[i].f` drops the index. If the LHS
  isn't a pure lvalue path the raw source text is used instead.
* **`enums_used`** — every `DeclRefExpr` to an `EnumConstantDecl` is recorded
  once, with `getInitVal()` rendered as a base-10 integer (`value: null` if not
  constant-resolvable).
* **`by_ref_params` / `written`** — params are flagged from the signature
  (`isReferenceType()` / `isPointerType()`). `written` is set when an assignment
  in the body has a root decl (`rootDeclOf`) equal to the param — covering
  `param.field = …`, `param->field = …`, and `*param = …`.
* **`by_ref_arg_indexes`** — an arg index is included when the callee's
  parameter is a reference/pointer **or** the argument is an `&expr`
  (address-of).

---

## Limitations

1. **Member-write assignments need types.** When the defining struct headers are
   *absent*, Clang represents `plasticAuth.process...softCardValue = X` as a
   `RecoveryExpr` of error type, and the CFG **omits** it. Result without
   headers: the **CFG, terminator conditions, calls, and by-ref params still
   appear**, but member-path **assignments to unresolved-typed objects are
   dropped** and enum values may be unresolved. With the real headers present
   (the 22k-file codebase has them) every assignment, enum value, and
   `written` flag resolves correctly. Validated both ways — see below.
2. **`written` is a syntactic write flag**, not a may-write analysis. A callee
   mutating a by-ref arg is captured separately via `calls[].by_ref_arg_indexes`.
   NOTE: the engine's current function-output re-root keys off the callee's own
   `by_ref_params[*].written` and emits every written param (not yet scoped via
   `by_ref_arg_indexes` to the specific arg the caller consumes — a known
   over-capture, see Round-2 finding C4); `by_ref_arg_indexes` is emitted for that
   future scoping but not yet consumed by the engine.
3. **Main-file only.** Function bodies that parse from included headers are
   intentionally skipped (`SM.isInMainFile`).
4. **No templates / virtual / STL** are exercised (the corpus is "C with
   classes"); the tool compiles and parses them but they are untested here.
5. **`is_decl` initializers** record the declared variable name as `lhs_path`
   (no struct path, since a declaration introduces a fresh local).
6. **`-fno-exceptions`/`-fno-rtti`** are used to build the *tool*; they do not
   affect parsing of the analyzed translation units.

---

## Validation (run on `temp/asm/dw710000.cpp`)

Best-effort, no headers:
* 16 function bodies recovered despite the missing `paapi.hpp` fatal.
* `processACreditTransaction` CFG: 27 blocks; all three reference guards present
  as `terminator_cond_expr` with labeled true/false edges:
  `linkSourceArea != 0`, `linkSourceArea->lstknpoa == 'Y'`,
  `lwrCommon.process.various.expressPay == Cas::On`.

With minimal stub headers (proving the typed-AST path):
* Both `plasticAuth.process.transactionInds.softCardValue =
  SoftCardValueDetail::ExpressPayTransaction` assignments captured with the FULL
  `lhs_path` and correct `block_id`.
* `by_ref_params`: `plasticAuth` and `lwrCommon` both `written: true`.
* `enums_used`: 11 constants with resolved integer values (e.g. `Cas::On`=2).
* `switch`/`for`/`goto`/`break`/`continue` edge labels verified on a dedicated
  fixture (case values + `default` + fallthrough).
