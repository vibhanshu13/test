// cfg_extract.cpp — VBT C++ frontend (Clang LibTooling)
//
// For each function DEFINITION in a translation unit, build a real clang::CFG
// and emit ONE JSON object per function (JSONL: one object per line).
//
// See vbt/cpp_frontend/README.md for the JSON schema and limitations.
//
// Design notes:
//   * We use clang::CFG::buildCFG so true/false branches, switch cases +
//     fallthrough + default, loops, ternary, early return/break/continue/goto,
//     and &&/|| short-circuit are all modeled by Clang itself.
//   * Member paths (LHS of assignments) are resolved through the typed AST
//     (MemberExpr chains) into a fully-qualified dotted path like
//     "plasticAuth.process.transactionInds.softCardValue".
//   * by-ref/pointer params are detected from the function signature; "written"
//     is set when an assignment in the body targets the param, *param, or
//     param->field / param.field.
//   * enum constants referenced anywhere in the body are collected with their
//     integer value when resolvable.

#include "clang/AST/AST.h"
#include "clang/AST/ASTConsumer.h"
#include "clang/AST/RecursiveASTVisitor.h"
#include "clang/Analysis/CFG.h"
#include "clang/Basic/SourceManager.h"
#include "clang/Frontend/CompilerInstance.h"
#include "clang/Frontend/FrontendActions.h"
#include "clang/Lex/Lexer.h"
#include "clang/Tooling/CommonOptionsParser.h"
#include "clang/Tooling/Tooling.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/Support/raw_ostream.h"

#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace clang;

static llvm::cl::OptionCategory ToolCategory("cfg_extract options");

// ---------------------------------------------------------------------------
// JSON helpers (tiny, dependency-free)
// ---------------------------------------------------------------------------
static std::string jsonEscape(llvm::StringRef s) {
  std::string out;
  out.reserve(s.size() + 8);
  for (char c : s) {
    switch (c) {
    case '"': out += "\\\""; break;
    case '\\': out += "\\\\"; break;
    case '\n': out += "\\n"; break;
    case '\r': out += "\\r"; break;
    case '\t': out += "\\t"; break;
    default:
      if (static_cast<unsigned char>(c) < 0x20) {
        char buf[8];
        snprintf(buf, sizeof(buf), "\\u%04x", c);
        out += buf;
      } else {
        out += c;
      }
    }
  }
  return out;
}
static std::string jstr(llvm::StringRef s) {
  return "\"" + jsonEscape(s) + "\"";
}

// ---------------------------------------------------------------------------
// Source-text + line helpers
// ---------------------------------------------------------------------------
static std::string exprText(const Stmt *S, const SourceManager &SM,
                            const LangOptions &LO) {
  if (!S)
    return "";
  SourceRange R = S->getSourceRange();
  if (R.isInvalid())
    return "";
  CharSourceRange CSR = CharSourceRange::getTokenRange(R);
  llvm::StringRef raw = Lexer::getSourceText(CSR, SM, LO);
  // Strip C/C++ comments from the raw token text FIRST. Multi-line conditions in
  // this corpus carry trailing `//Rxxx` revision tags between tokens; if we left a
  // `//` comment in and then collapsed the newline below, everything after `//`
  // would be swallowed into the expression (or truncate it downstream). Comment
  // detection is string/char-literal aware so a `//` inside a literal is kept.
  std::string txt;
  txt.reserve(raw.size());
  char inStr = 0;  // 0 outside a literal; '"' or '\'' inside one
  for (size_t i = 0; i < raw.size(); ++i) {
    char c = raw[i];
    if (inStr) {
      txt += c;
      if (c == '\\' && i + 1 < raw.size()) { txt += raw[++i]; continue; }
      if (c == inStr) inStr = 0;
      continue;
    }
    if (c == '"' || c == '\'') { inStr = c; txt += c; continue; }
    if (c == '/' && i + 1 < raw.size() && raw[i + 1] == '/') {           // line comment
      while (i < raw.size() && raw[i] != '\n') ++i;
      if (i < raw.size()) txt += '\n';                                   // keep the line break
      continue;
    }
    if (c == '/' && i + 1 < raw.size() && raw[i + 1] == '*') {           // block comment
      i += 2;
      while (i + 1 < raw.size() && !(raw[i] == '*' && raw[i + 1] == '/')) ++i;
      ++i;                                                               // skip '*'; loop skips '/'
      txt += ' ';
      continue;
    }
    txt += c;
  }
  // Collapse internal whitespace/newlines so the JSON stays one-line friendly —
  // but LITERAL-AWARE (A4): bytes inside a "" / '' literal are copied verbatim so a
  // fixed-width blank field like memcmp(x,"  ",2) keeps its two spaces (collapsing
  // it to " " would change the compared value + length semantics downstream).
  std::string out;
  bool prevSpace = false;
  char inLit = 0;
  for (size_t i = 0; i < txt.size(); ++i) {
    char c = txt[i];
    if (inLit) {
      out += c;
      prevSpace = false;
      if (c == '\\' && i + 1 < txt.size()) { out += txt[++i]; continue; }
      if (c == inLit) inLit = 0;
      continue;
    }
    if (c == '"' || c == '\'') { inLit = c; out += c; prevSpace = false; continue; }
    if (c == '\n' || c == '\r' || c == '\t' || c == ' ') {
      if (!prevSpace) {
        out += ' ';
        prevSpace = true;
      }
    } else {
      out += c;
      prevSpace = false;
    }
  }
  // trim
  size_t b = out.find_first_not_of(' ');
  size_t e = out.find_last_not_of(' ');
  if (b == std::string::npos)
    return "";
  return out.substr(b, e - b + 1);
}

static unsigned lineOf(SourceLocation Loc, const SourceManager &SM) {
  if (Loc.isInvalid())
    return 0;
  // Use the spelling/expansion line in the main file.
  PresumedLoc PL = SM.getPresumedLoc(Loc);
  if (PL.isInvalid())
    return 0;
  return PL.getLine();
}

// ---------------------------------------------------------------------------
// Member-path resolution: walk a (possibly nested) MemberExpr/DeclRefExpr chain
// and produce a dotted path. Returns "" if the expression is not a pure
// lvalue member/var path (e.g. array index, deref of computed pointer).
// ---------------------------------------------------------------------------
static bool buildMemberPath(const Expr *E, std::string &out);

static bool buildMemberPath(const Expr *E, std::string &out) {
  if (!E)
    return false;
  E = E->IgnoreParenImpCasts();

  if (const auto *DRE = dyn_cast<DeclRefExpr>(E)) {
    out = DRE->getDecl()->getNameAsString();
    return true;
  }
  if (const auto *ME = dyn_cast<MemberExpr>(E)) {
    std::string base;
    if (!buildMemberPath(ME->getBase(), base))
      return false;
    std::string field = ME->getMemberDecl()->getNameAsString();
    if (base.empty())
      out = field;
    else
      out = base + "." + field; // ME->isArrow() handled the same dotted way
    return true;
  }
  if (const auto *UO = dyn_cast<UnaryOperator>(E)) {
    // *p  -> treat as the underlying path of p (so *param resolves to param)
    if (UO->getOpcode() == UO_Deref)
      return buildMemberPath(UO->getSubExpr(), out);
    return false;
  }
  if (const auto *ASE = dyn_cast<ArraySubscriptExpr>(E)) {
    // arr[i].field -> base path of arr (drop the index); good enough for our
    // field-path matching ("plasticAuth.process..." style).
    std::string base;
    if (!buildMemberPath(ASE->getBase(), base))
      return false;
    out = base;
    return true;
  }
  if (const auto *CE = dyn_cast<CastExpr>(E))
    return buildMemberPath(CE->getSubExpr(), out);
  return false;
}

// Root variable name of a member path (first segment), via the underlying decl.
static const ValueDecl *rootDeclOf(const Expr *E) {
  if (!E)
    return nullptr;
  E = E->IgnoreParenImpCasts();
  if (const auto *DRE = dyn_cast<DeclRefExpr>(E))
    return DRE->getDecl();
  if (const auto *ME = dyn_cast<MemberExpr>(E))
    return rootDeclOf(ME->getBase());
  if (const auto *UO = dyn_cast<UnaryOperator>(E))
    return rootDeclOf(UO->getSubExpr());
  if (const auto *ASE = dyn_cast<ArraySubscriptExpr>(E))
    return rootDeclOf(ASE->getBase());
  if (const auto *CE = dyn_cast<CastExpr>(E))
    return rootDeclOf(CE->getSubExpr());
  return nullptr;
}

// ---------------------------------------------------------------------------
// Per-function extractor
// ---------------------------------------------------------------------------
struct AssignmentRec {
  unsigned line;
  unsigned blockId;
  std::string lhsPath;
  std::string rhsExpr;
  bool isDecl;
};
struct CallRec {
  unsigned line;
  unsigned blockId;
  std::string callee;
  std::vector<std::string> args;
  std::vector<int> byRefArgIdx;
};
struct ParamRec {
  std::string name;
  std::string type;
  bool isReference;
  bool isPointer;
  bool written;
};
struct EnumRec {
  std::string name;       // qualified-ish: EnumName::Constant when available
  std::string value;      // integer value, or "" when not resolvable
};

// One control-flow guard REGION (an AST control-statement branch).
//   expr      : the full condition source text (e.g. "a > 0 || b > 0",
//               "sel == 1 || sel == 2")
//   polarity  : true  -> the predicate must HOLD to reach a stmt in the region
//               false -> the predicate must NOT hold (ELSE branch)
//               (true used for loops; default carries the kind only)
//   kind      : "if" | "switch" | "loop"
//   line      : source line of the controlling statement (the if/switch/loop)
//   startLine,
//   endLine   : source span of the GUARDED BRANCH BODY. Any setter line that
//               falls within [startLine, endLine] is enclosed by this guard —
//               which is how we attach guards to a member-write whose own
//               statement was dropped from the CFG (headerless ⑤-B1): the
//               enclosing if/switch body span is computed from the real AST,
//               independent of whether the write survived parsing.
struct GuardRec {
  std::string expr;
  bool polarity;     // true = assert cond; false = assert !cond
  bool hasPolarity;  // false for "default" case (no simple boolean polarity)
  std::string kind;  // "if" | "switch" | "loop"
  unsigned line;
  unsigned startLine;
  unsigned endLine;
};

class FunctionEmitter {
public:
  FunctionEmitter(ASTContext &Ctx, llvm::raw_ostream &OS)
      : Ctx(Ctx), SM(Ctx.getSourceManager()), LO(Ctx.getLangOpts()), OS(OS) {}

  void emit(const FunctionDecl *FD) {
    if (!FD->hasBody())
      return;
    Stmt *Body = FD->getBody();

    // Build the real CFG.
    CFG::BuildOptions BO;
    BO.AddInitializers = true;
    BO.AddImplicitDtors = false;
    BO.AddTemporaryDtors = false;
    std::unique_ptr<CFG> cfg =
        CFG::buildCFG(FD, Body, &Ctx, BO);
    if (!cfg)
      return;

    // Map each CFGBlock* to its id and, for every Stmt we care about, the
    // block it lives in.
    std::map<const CFGBlock *, unsigned> blockId;
    for (const CFGBlock *B : *cfg)
      blockId[B] = B->getBlockID();

    std::map<const Stmt *, unsigned> stmtBlock;
    for (const CFGBlock *B : *cfg) {
      for (const CFGElement &Elt : *B) {
        if (auto CS = Elt.getAs<CFGStmt>()) {
          const Stmt *S = CS->getStmt();
          stmtBlock[S] = B->getBlockID();
        }
      }
    }

    // Collect by-ref / pointer params.
    std::vector<ParamRec> params;
    std::map<const ValueDecl *, size_t> paramIndex; // decl -> params index
    for (unsigned i = 0; i < FD->getNumParams(); ++i) {
      const ParmVarDecl *P = FD->getParamDecl(i);
      QualType QT = P->getType();
      bool isRef = QT->isReferenceType();
      bool isPtr = QT->isPointerType();
      ParamRec pr;
      pr.name = P->getNameAsString();
      pr.type = QT.getAsString();
      pr.isReference = isRef;
      pr.isPointer = isPtr;
      pr.written = false;
      if (isRef || isPtr) {
        paramIndex[P] = params.size();
      }
      params.push_back(pr);
    }

    // Walk the body to collect assignments, calls, enums, and param writes.
    std::vector<AssignmentRec> assignments;
    std::vector<CallRec> calls;
    std::vector<EnumRec> enums;
    std::set<std::string> enumSeen;

    collectFromBody(Body, stmtBlock, paramIndex, params, assignments, calls,
                    enums, enumSeen);

    // Walk the AST top-down and emit one guard REGION per guarded branch
    // (if-then / if-else / loop body / switch case-group), each tagged with the
    // source-line span of its body. This is the AUTHORITATIVE guard source: it
    // is derived from the real AST control structure, so it survives the CFG
    // dropping a member-write whose type is unresolved (headerless), and it
    // carries FULL condition exprs (so `a||b`, `a&&b`, and switch fallthrough
    // OR-of-cases all come out whole). The Python side resolves a setter's
    // guard stack by line-containment over these regions.
    std::vector<GuardRec> guardRegions;
    collectGuards(Body, guardRegions);

    // ---- Emit JSON for this function ----
    std::string file = SM.getFilename(FD->getLocation()).str();
    std::string fname = FD->getQualifiedNameAsString();

    OS << "{";
    OS << jstr("file") << ":" << jstr(file) << ",";
    OS << jstr("function") << ":" << jstr(fname) << ",";

    // cfg_blocks
    OS << jstr("cfg_blocks") << ":[";
    bool firstBlock = true;
    for (const CFGBlock *B : *cfg) {
      if (!firstBlock)
        OS << ",";
      firstBlock = false;
      emitBlock(B, blockId, *cfg);
    }
    OS << "],";

    // assignments
    OS << jstr("assignments") << ":[";
    for (size_t i = 0; i < assignments.size(); ++i) {
      if (i)
        OS << ",";
      const auto &a = assignments[i];
      OS << "{" << jstr("line") << ":" << a.line << ","
         << jstr("block_id") << ":" << (int)a.blockId << ","
         << jstr("lhs_path") << ":" << jstr(a.lhsPath) << ","
         << jstr("rhs_expr") << ":" << jstr(a.rhsExpr) << ","
         << jstr("is_decl") << ":" << (a.isDecl ? "true" : "false") << "}";
    }
    OS << "],";

    // calls
    OS << jstr("calls") << ":[";
    for (size_t i = 0; i < calls.size(); ++i) {
      if (i)
        OS << ",";
      const auto &c = calls[i];
      OS << "{" << jstr("line") << ":" << c.line << ","
         << jstr("block_id") << ":" << (int)c.blockId << ","
         << jstr("callee") << ":" << jstr(c.callee) << ","
         << jstr("args") << ":[";
      for (size_t j = 0; j < c.args.size(); ++j) {
        if (j)
          OS << ",";
        OS << jstr(c.args[j]);
      }
      OS << "]," << jstr("by_ref_arg_indexes") << ":[";
      for (size_t j = 0; j < c.byRefArgIdx.size(); ++j) {
        if (j)
          OS << ",";
        OS << c.byRefArgIdx[j];
      }
      OS << "]}";
    }
    OS << "],";

    // by_ref_params
    OS << jstr("by_ref_params") << ":[";
    {
      bool first = true;
      for (const auto &p : params) {
        if (!(p.isReference || p.isPointer))
          continue;
        if (!first)
          OS << ",";
        first = false;
        OS << "{" << jstr("name") << ":" << jstr(p.name) << ","
           << jstr("type") << ":" << jstr(p.type) << ","
           << jstr("is_reference") << ":" << (p.isReference ? "true" : "false")
           << "," << jstr("is_pointer") << ":" << (p.isPointer ? "true" : "false")
           << "," << jstr("written") << ":" << (p.written ? "true" : "false")
           << "}";
      }
    }
    OS << "],";

    // params: the FULL ordered formal-parameter list (NOT just by-ref/pointer),
    // each with its positional ``index``. The dep-var engine maps a call site's
    // positional ``args[index]`` back to the formal name to re-root a read-only
    // parameter into the caller's actual argument (the IN-direction boundary
    // re-resolution: a formal param is bound, not set, so its value-defining
    // "setter" is the argument expression at each call site). ``written`` mirrors
    // by_ref_params (true only when an in-body assignment targets the param).
    OS << jstr("params") << ":[";
    for (size_t i = 0; i < params.size(); ++i) {
      if (i)
        OS << ",";
      const auto &p = params[i];
      OS << "{" << jstr("name") << ":" << jstr(p.name) << ","
         << jstr("index") << ":" << (int)i << ","
         << jstr("type") << ":" << jstr(p.type) << ","
         << jstr("is_reference") << ":" << (p.isReference ? "true" : "false")
         << "," << jstr("is_pointer") << ":" << (p.isPointer ? "true" : "false")
         << "," << jstr("written") << ":" << (p.written ? "true" : "false")
         << "}";
    }
    OS << "],";

    // enums_used
    OS << jstr("enums_used") << ":[";
    for (size_t i = 0; i < enums.size(); ++i) {
      if (i)
        OS << ",";
      OS << "{" << jstr("name") << ":" << jstr(enums[i].name) << ","
         << jstr("value") << ":";
      if (enums[i].value.empty())
        OS << "null";
      else
        OS << enums[i].value;
      OS << "}";
    }
    OS << "],";

    // guard_regions: a flat list of AST control-flow guards, each carrying the
    // source-line span of the branch body it governs. cpp_conditions resolves a
    // setter's enclosing guard stack by line-containment over these regions.
    OS << jstr("guard_regions") << ":[";
    for (size_t i = 0; i < guardRegions.size(); ++i) {
      if (i)
        OS << ",";
      const GuardRec &g = guardRegions[i];
      OS << "{" << jstr("expr") << ":" << jstr(g.expr) << ","
         << jstr("polarity") << ":";
      if (!g.hasPolarity)
        OS << "null";
      else
        OS << (g.polarity ? "true" : "false");
      OS << "," << jstr("kind") << ":" << jstr(g.kind) << ","
         << jstr("line") << ":" << g.line << ","
         << jstr("start_line") << ":" << g.startLine << ","
         << jstr("end_line") << ":" << g.endLine << "}";
    }
    OS << "]";

    OS << "}\n";
  }

private:
  ASTContext &Ctx;
  const SourceManager &SM;
  const LangOptions &LO;
  llvm::raw_ostream &OS;

  unsigned blockOf(const Stmt *S,
                   const std::map<const Stmt *, unsigned> &stmtBlock) {
    auto it = stmtBlock.find(S);
    if (it != stmtBlock.end())
      return it->second;
    return (unsigned)-1; // sentinel: emitted as -1
  }

  // ---- one CFG block ----
  void emitBlock(const CFGBlock *B, std::map<const CFGBlock *, unsigned> &id,
                 CFG &cfg) {
    OS << "{" << jstr("id") << ":" << B->getBlockID() << ",";

    // stmts
    OS << jstr("stmts") << ":[";
    bool firstStmt = true;
    for (const CFGElement &Elt : *B) {
      auto CS = Elt.getAs<CFGStmt>();
      if (!CS)
        continue;
      const Stmt *S = CS->getStmt();
      if (!firstStmt)
        OS << ",";
      firstStmt = false;
      unsigned line = lineOf(S->getBeginLoc(), SM);
      OS << "{" << jstr("line") << ":" << line << "," << jstr("kind") << ":"
         << jstr(stmtKind(S)) << "," << jstr("text") << ":"
         << jstr(exprText(S, SM, LO)) << "}";
    }
    OS << "],";

    // terminator
    const Stmt *Term = B->getTerminatorStmt();
    std::string termKind = Term ? terminatorKind(Term) : "none";
    OS << jstr("terminator_kind") << ":" << jstr(termKind) << ",";

    // terminator condition expression
    const Stmt *Cond = B->getTerminatorCondition(/*StripParens=*/true);
    std::string condText = Cond ? exprText(Cond, SM, LO) : "";
    OS << jstr("terminator_cond_expr") << ":" << jstr(condText) << ",";

    // succs with labels
    OS << jstr("succs") << ":[";
    {
      std::vector<std::string> labels = succLabels(B);
      bool first = true;
      unsigned idx = 0;
      for (CFGBlock::const_succ_iterator I = B->succ_begin();
           I != B->succ_end(); ++I, ++idx) {
        if (!first)
          OS << ",";
        first = false;
        std::string label = idx < labels.size() ? labels[idx] : "unconditional";
        if (*I) {
          OS << "{" << jstr("block_id") << ":" << (*I)->getBlockID() << ","
             << jstr("label") << ":" << jstr(label) << "}";
        } else {
          // Null successor (unreachable / no-return). Emit as block_id -1.
          OS << "{" << jstr("block_id") << ":" << -1 << "," << jstr("label")
             << ":" << jstr(label) << "}";
        }
      }
    }
    OS << "],";

    // preds
    OS << jstr("preds") << ":[";
    {
      bool first = true;
      for (CFGBlock::const_pred_iterator I = B->pred_begin();
           I != B->pred_end(); ++I) {
        if (!*I)
          continue;
        if (!first)
          OS << ",";
        first = false;
        OS << (*I)->getBlockID();
      }
    }
    OS << "]";

    OS << "}";
  }

  // ---- edge labels for the successors of a block ----
  // Order matches CFGBlock successor order.
  std::vector<std::string> succLabels(const CFGBlock *B) {
    std::vector<std::string> out;
    const Stmt *T = B->getTerminatorStmt();
    unsigned nsucc = std::distance(B->succ_begin(), B->succ_end());

    if (!T) {
      for (unsigned i = 0; i < nsucc; ++i)
        out.push_back("unconditional");
      return out;
    }

    // switch: Clang puts the implicit default last; case labels carried on each
    // successor block's CFGBlock::getLabel().
    if (isa<SwitchStmt>(T)) {
      for (CFGBlock::const_succ_iterator I = B->succ_begin();
           I != B->succ_end(); ++I) {
        // A null successor, or a successor whose entry label is not a CaseStmt,
        // is the default / implicit-exit edge of the switch.
        std::string lbl = "default";
        if (*I) {
          const Stmt *L = (*I)->getLabel();
          if (const auto *CaseS = dyn_cast_or_null<CaseStmt>(L)) {
            lbl = "case " + exprText(CaseS->getLHS(), SM, LO);
          } else if (isa_and_nonnull<DefaultStmt>(L)) {
            lbl = "default";
          } else {
            lbl = "default";
          }
        }
        out.push_back(lbl);
      }
      return out;
    }

    // if / for / while / do / conditional-operator / &&,|| :
    // Clang convention: succ[0] = TRUE/taken, succ[1] = FALSE/fallthrough.
    if (isa<IfStmt>(T) || isa<ForStmt>(T) || isa<WhileStmt>(T) ||
        isa<DoStmt>(T) || isa<ConditionalOperator>(T) ||
        isa<BinaryConditionalOperator>(T) || isa<BinaryOperator>(T) ||
        isa<AbstractConditionalOperator>(T)) {
      for (unsigned i = 0; i < nsucc; ++i) {
        if (i == 0)
          out.push_back("true");
        else if (i == 1)
          out.push_back("false");
        else
          out.push_back("other");
      }
      return out;
    }

    // goto / break / continue / return / others -> single unconditional edge.
    for (unsigned i = 0; i < nsucc; ++i)
      out.push_back("unconditional");
    return out;
  }

  std::string terminatorKind(const Stmt *T) {
    if (isa<IfStmt>(T)) return "if";
    if (isa<SwitchStmt>(T)) return "switch";
    if (isa<ForStmt>(T)) return "for";
    if (isa<WhileStmt>(T)) return "while";
    if (isa<DoStmt>(T)) return "do";
    if (isa<ConditionalOperator>(T) || isa<BinaryConditionalOperator>(T) ||
        isa<AbstractConditionalOperator>(T))
      return "ternary";
    if (const auto *BO = dyn_cast<BinaryOperator>(T)) {
      if (BO->getOpcode() == BO_LAnd) return "logical_and";
      if (BO->getOpcode() == BO_LOr) return "logical_or";
      return "binary";
    }
    if (isa<GotoStmt>(T)) return "goto";
    if (isa<IndirectGotoStmt>(T)) return "indirect_goto";
    if (isa<BreakStmt>(T)) return "break";
    if (isa<ContinueStmt>(T)) return "continue";
    if (isa<ReturnStmt>(T)) return "return";
    return std::string("other:") + T->getStmtClassName();
  }

  std::string stmtKind(const Stmt *S) {
    if (const auto *BO = dyn_cast<BinaryOperator>(S)) {
      if (BO->isAssignmentOp() || BO->isCompoundAssignmentOp())
        return "assignment";
      if (BO->getOpcode() == BO_LAnd || BO->getOpcode() == BO_LOr)
        return "condition";
    }
    if (isa<CallExpr>(S) || isa<CXXMemberCallExpr>(S) ||
        isa<CXXOperatorCallExpr>(S))
      return "call";
    if (isa<ReturnStmt>(S)) return "return";
    if (isa<BreakStmt>(S)) return "break";
    if (isa<ContinueStmt>(S)) return "continue";
    if (isa<GotoStmt>(S) || isa<IndirectGotoStmt>(S)) return "goto";
    if (isa<IfStmt>(S) || isa<SwitchStmt>(S) || isa<ForStmt>(S) ||
        isa<WhileStmt>(S) || isa<DoStmt>(S))
      return "condition";
    if (const auto *DS = dyn_cast<DeclStmt>(S)) {
      // a decl with an initializer counts as an assignment.
      for (const Decl *D : DS->decls())
        if (const auto *VD = dyn_cast<VarDecl>(D))
          if (VD->hasInit())
            return "assignment";
      return "other";
    }
    if (const auto *UO = dyn_cast<UnaryOperator>(S)) {
      if (UO->isIncrementDecrementOp())
        return "assignment";
    }
    return "other";
  }

  // ---- recursive body walk for assignments / calls / enums / param-writes ----
  void collectFromBody(const Stmt *S,
                       const std::map<const Stmt *, unsigned> &stmtBlock,
                       const std::map<const ValueDecl *, size_t> &paramIndex,
                       std::vector<ParamRec> &params,
                       std::vector<AssignmentRec> &assignments,
                       std::vector<CallRec> &calls,
                       std::vector<EnumRec> &enums,
                       std::set<std::string> &enumSeen) {
    if (!S)
      return;

    // enum constant references
    if (const auto *DRE = dyn_cast<DeclRefExpr>(S)) {
      if (const auto *ECD = dyn_cast<EnumConstantDecl>(DRE->getDecl())) {
        std::string qn = ECD->getQualifiedNameAsString();
        if (enumSeen.insert(qn).second) {
          EnumRec er;
          er.name = qn;
          llvm::APSInt v = ECD->getInitVal();
          llvm::SmallString<32> buf;
          v.toString(buf, 10);
          er.value = std::string(buf.c_str());
          enums.push_back(er);
        }
      }
    }

    // assignment: BinaryOperator '=' or compound, OR a VarDecl initializer.
    if (const auto *BO = dyn_cast<BinaryOperator>(S)) {
      if (BO->isAssignmentOp() || BO->isCompoundAssignmentOp()) {
        recordAssignment(BO, BO->getLHS(), BO->getRHS(), /*isDecl=*/false,
                         BO->getOperatorLoc(), stmtBlock, paramIndex, params,
                         assignments);
      }
    }
    if (const auto *DS = dyn_cast<DeclStmt>(S)) {
      for (const Decl *D : DS->decls()) {
        if (const auto *VD = dyn_cast<VarDecl>(D)) {
          if (VD->hasInit()) {
            AssignmentRec a;
            a.line = lineOf(VD->getLocation(), SM);
            a.blockId = blockOf(DS, stmtBlock);
            a.lhsPath = VD->getNameAsString();
            a.rhsExpr = exprText(VD->getInit(), SM, LO);
            a.isDecl = true;
            assignments.push_back(a);
          }
        }
      }
    }

    // unary inc/dec is a write to its operand
    if (const auto *UO = dyn_cast<UnaryOperator>(S)) {
      if (UO->isIncrementDecrementOp()) {
        recordAssignment(UO, UO->getSubExpr(), UO->getSubExpr(),
                         /*isDecl=*/false, UO->getOperatorLoc(), stmtBlock,
                         paramIndex, params, assignments);
      }
    }

    // call
    if (const auto *CE = dyn_cast<CallExpr>(S)) {
      recordCall(CE, stmtBlock, calls);
    }

    for (const Stmt *Child : S->children())
      collectFromBody(Child, stmtBlock, paramIndex, params, assignments, calls,
                      enums, enumSeen);
  }

  // ---- enclosing-guard collection (AST top-down, by GUARDED-REGION span) ----
  //
  // We descend the AST. For each control statement we emit ONE GuardRec per
  // guarded branch (if-then / if-else / loop-body / switch-case-group), each
  // tagged with the SOURCE-LINE SPAN of that branch's body. The Python side
  // then computes a setter's guard stack purely by line-containment: a guard
  // applies iff the setter line lies within its [startLine, endLine] region.
  //
  // Region-by-span (instead of attaching guards to surviving statement lines)
  // is what makes this robust to the headerless ⑤-B1 case: even when a
  // member-write statement is dropped from the CFG/AST (unresolved type), its
  // enclosing if/switch BODY SPAN is still computed from the real control
  // structure, so the setter line still falls inside the right regions.
  //
  // It is correct for the spec cases because the condition source text is taken
  // whole:
  //   * `||` / `&&`  — the IfStmt condition is the entire expression.
  //   * switch fallthrough — consecutive case labels feeding one body group are
  //     OR-ed into a single guard `expr == v1 || expr == v2`.
  //   * else branches — polarity flips to !cond.
  //   * loops — the loop condition is emitted (kind="loop").
  // Sibling branches that merely reconverge before a statement do NOT contain
  // the statement's line, so they are naturally excluded.

  std::string condTextOf(const Expr *E) {
    return exprText(E ? E->IgnoreParenImpCasts() : nullptr, SM, LO);
  }

  // The source-line span [begin, end] of a (branch-body) statement. For a
  // CompoundStmt this runs from `{` to `}`, so a dropped statement inside still
  // line-contains. We expand `begin` down to the controlling stmt's line when
  // the body begins on a later line, so a setter on the brace line is included.
  void spanOf(const Stmt *Body, unsigned ctrlLine, unsigned &begin,
              unsigned &end) {
    begin = Body ? lineOf(Body->getBeginLoc(), SM) : 0;
    end = Body ? lineOf(Body->getEndLoc(), SM) : 0;
    if (begin == 0 || begin > ctrlLine)
      begin = ctrlLine;          // include the `if (...)` / `case:` line itself
    if (end < begin)
      end = begin;
  }

  void addGuard(std::vector<GuardRec> &out, GuardRec g, const Stmt *body,
                unsigned ctrlLine) {
    spanOf(body, ctrlLine, g.startLine, g.endLine);
    out.push_back(g);
  }

  // Does this statement terminate a switch case group (so the next statement is
  // NOT a fallthrough continuation)? True for break/return/continue/goto, or a
  // block/case-sub whose final statement does.
  bool endsCaseGroup(const Stmt *S) {
    if (!S)
      return false;
    if (isa<BreakStmt>(S) || isa<ReturnStmt>(S) || isa<ContinueStmt>(S) ||
        isa<GotoStmt>(S) || isa<IndirectGotoStmt>(S))
      return true;
    if (const auto *CB = dyn_cast<CompoundStmt>(S))
      return !CB->body_empty() && endsCaseGroup(CB->body_back());
    if (const auto *SC = dyn_cast<SwitchCase>(S))
      return endsCaseGroup(SC->getSubStmt());
    return false;
  }

  // Does control-flow ALWAYS leave the enclosing block when this statement runs,
  // i.e. every path through `S` ends in return/break/continue/goto (so any code
  // textually AFTER `S` in the same block is NOT reached via `S`)? This is the
  // sound, AST-only basis for the early-exit fall-through guard below — it is a
  // pure structural property of the source, independent of the CFG (which the
  // headerless collapsed-switch corrupts).
  //   * jump statements terminate;
  //   * a compound block terminates iff its LAST statement does (descend);
  //   * an `if` terminates iff BOTH arms do — crucially, a then-only `if` with no
  //     else does NOT terminate (the false arm falls through), so we never emit a
  //     fall-through negation for `if(c){return;}` whose else would also reach.
  // Loops / switches are conservatively treated as non-terminating (a loop may run
  // zero times; a switch may fall out), so we never over-claim a guard.
  bool flowTerminates(const Stmt *S) {
    if (!S)
      return false;
    if (isa<ReturnStmt>(S) || isa<BreakStmt>(S) || isa<ContinueStmt>(S) ||
        isa<GotoStmt>(S) || isa<IndirectGotoStmt>(S))
      return true;
    if (const auto *CB = dyn_cast<CompoundStmt>(S))
      return !CB->body_empty() && flowTerminates(CB->body_back());
    if (const auto *If = dyn_cast<IfStmt>(S)) {
      const Stmt *Then = If->getThen();
      const Stmt *Else = If->getElse();
      // No else → the false arm falls through → the `if` does NOT terminate.
      if (!Else)
        return false;
      return flowTerminates(Then) && flowTerminates(Else);
    }
    return false;
  }

  // EARLY-EXIT FALL-THROUGH GUARD (AST, sound span). When a statement
  //   `if (c) { … return|break|continue|goto; }`   (then-arm always terminates)
  // with NO else (or whose else does NOT terminate — see note) sits directly
  // inside a CompoundStmt, every statement textually AFTER it in that SAME block
  // is reached ONLY when `c` was FALSE. We emit one guard_region for that
  // FALL-THROUGH region: expr=c, polarity=false (Python renders `!(c)`),
  // kind="early_exit", span = [line after the if's end .. the block's `}` line].
  // A setter lexically after the exiting `if` in the same block is then
  // line-contained and `_ast_guards` attaches `!(c)`.
  //
  // This is the one early-exit that AST nesting alone misses (the setter is NOT
  // inside the if's body), recovered here PURELY from source ranges + the
  // terminator check — so it is correct even when the CFG collapses (the
  // headerless collapsed-switch case: pre-switch returns are dropped from the
  // CFG path, but their fall-through span still line-contains the switch setters).
  //
  // NOTE on the else: if the then-arm terminates but an else exists and does NOT
  // itself terminate, the code after the `if` IS reachable via the else arm, so
  // it is NOT guarded by `!(c)` — we require the else to be absent or terminating.
  void emitFallThroughGuard(const IfStmt *If, unsigned blockEndLine,
                            std::vector<GuardRec> &out) {
    const Stmt *Then = If->getThen();
    if (!flowTerminates(Then))
      return;                       // then-arm doesn't always exit → no guard
    const Stmt *Else = If->getElse();
    if (Else && !flowTerminates(Else))
      return;                       // else reaches the fall-through → no guard
    std::string cond = condTextOf(If->getCond());
    if (cond.empty())
      return;
    unsigned ifEnd = lineOf(If->getEndLoc(), SM);
    unsigned ifLine = lineOf(If->getBeginLoc(), SM);
    if (ifEnd == 0)
      ifEnd = ifLine;
    unsigned start = ifEnd + 1;     // first line AFTER the if statement
    if (start <= ifLine)            // degenerate one-liner: start just past it
      start = ifLine + 1;
    if (blockEndLine < start)
      return;                       // nothing after the if in this block
    GuardRec g;
    g.expr = cond;
    g.kind = "early_exit";
    g.polarity = false;             // assert !(cond) on the fall-through
    g.hasPolarity = true;
    g.line = ifLine;
    g.startLine = start;
    g.endLine = blockEndLine;
    out.push_back(g);
  }

  // Build the OR-of-cases guard for the run of SwitchCase labels that all fall
  // into one body group (fallthrough). For a `default` in the run, polarity is
  // dropped (it carries the descriptive form only).
  GuardRec switchCaseGuard(const SwitchStmt *SW,
                           const std::vector<const SwitchCase *> &run) {
    GuardRec g;
    g.kind = "switch";
    g.polarity = true;
    g.hasPolarity = true;
    g.line = lineOf(SW->getBeginLoc(), SM);
    std::string scrut = condTextOf(SW->getCond());
    std::vector<std::string> terms;
    bool sawDefault = false;
    for (const SwitchCase *SC : run) {
      if (const auto *CS = dyn_cast<CaseStmt>(SC)) {
        std::string v = exprText(CS->getLHS(), SM, LO);
        terms.push_back(scrut + " == " + v);
      } else if (isa<DefaultStmt>(SC)) {
        sawDefault = true;
      }
    }
    if (sawDefault && terms.empty()) {
      g.expr = scrut + " (default case)";
      g.hasPolarity = false;
      return g;
    }
    std::string expr;
    for (size_t i = 0; i < terms.size(); ++i)
      expr += (i ? " || " : "") + terms[i];
    if (sawDefault)
      expr += " (or default)";
    g.expr = expr;
    return g;
  }

  // A1: recover switch-case guards LEXICALLY when Clang's error recovery for an
  // unresolved/dependent scrutinee type has discarded the CaseStmt AST nodes
  // (headerless parse). We scan the switch body source for top-level `case X:` /
  // `default:` labels and emit one `scrut == X` guard per label, spanning to the
  // next label. We ALSO emit a `collapsed_switch` marker over the body so the
  // Python early-exit pass skips branches inside it (the CFG collapsed in lockstep
  // and yields wrong-polarity negatives there). Only invoked when NO SwitchCase
  // child exists, so the normal resolved-switch path is never affected.
  void recoverCollapsedSwitch(const SwitchStmt *SW, const CompoundStmt *CB,
                              std::vector<GuardRec> &out) {
    unsigned bodyStart = lineOf(CB->getLBracLoc(), SM);
    unsigned bodyEnd = lineOf(CB->getRBracLoc(), SM);
    GuardRec marker;
    marker.kind = "collapsed_switch";
    marker.expr = "";
    marker.hasPolarity = false;
    marker.polarity = false;
    marker.line = lineOf(SW->getBeginLoc(), SM);
    marker.startLine = bodyStart;
    marker.endLine = bodyEnd < bodyStart ? bodyStart : bodyEnd;
    out.push_back(marker);

    std::string scrut = condTextOf(SW->getCond());
    if (scrut.empty())
      return;

    auto idc = [](char x) {
      return (x >= 'a' && x <= 'z') || (x >= 'A' && x <= 'Z') ||
             (x >= '0' && x <= '9') || x == '_';
    };
    llvm::StringRef src = Lexer::getSourceText(
        CharSourceRange::getTokenRange(CB->getSourceRange()), SM, LO);
    struct Lbl { unsigned line; std::string expr; bool isDefault; };
    std::vector<Lbl> labels;
    int depth = 0;
    char inLit = 0;
    unsigned line = bodyStart;
    size_t n = src.size();
    for (size_t i = 0; i < n; ++i) {
      char c = src[i];
      if (inLit) {
        if (c == '\n') line++;
        if (c == '\\' && i + 1 < n) { if (src[i + 1] == '\n') line++; ++i; }
        else if (c == inLit) inLit = 0;
        continue;
      }
      if (c == '\n') { line++; continue; }
      if (c == '"' || c == '\'') { inLit = c; continue; }
      if (c == '/' && i + 1 < n && src[i + 1] == '/') {
        while (i < n && src[i] != '\n') ++i;
        line++;
        continue;
      }
      if (c == '/' && i + 1 < n && src[i + 1] == '*') {
        i += 2;
        while (i + 1 < n && !(src[i] == '*' && src[i + 1] == '/')) {
          if (src[i] == '\n') line++;
          ++i;
        }
        ++i;
        continue;
      }
      if (c == '{' || c == '(' || c == '[') { depth++; continue; }
      if (c == '}' || c == ')' || c == ']') { depth--; continue; }
      if (depth != 1)
        continue;  // only top-level labels (inside the switch body braces)
      bool prevOk = (i == 0) || !idc(src[i - 1]);
      if (prevOk && i + 4 <= n && src.substr(i, 4) == "case" &&
          (i + 4 == n || !idc(src[i + 4]))) {
        unsigned lblLine = line;
        i += 4;
        std::string expr;
        int pd = 0;
        char lit2 = 0;
        while (i < n) {
          char d = src[i];
          if (d == '\n') line++;
          if (lit2) {
            expr += d;
            if (d == '\\' && i + 1 < n) { expr += src[++i]; }
            else if (d == lit2) lit2 = 0;
            ++i;
            continue;
          }
          if (d == '"' || d == '\'') { lit2 = d; expr += d; ++i; continue; }
          if (d == '(' || d == '[' || d == '{') { pd++; expr += d; ++i; continue; }
          if (d == ')' || d == ']' || d == '}') { pd--; expr += d; ++i; continue; }
          if (d == ':' && pd == 0) {
            if (i + 1 < n && src[i + 1] == ':') { expr += "::"; i += 2; continue; }
            break;  // label terminator (i at ':')
          }
          expr += d;
          ++i;
        }
        std::string e;
        bool ps = false;
        for (char x : expr) {
          if (x == '\n' || x == '\r' || x == '\t' || x == ' ') {
            if (!ps) { e += ' '; ps = true; }
          } else { e += x; ps = false; }
        }
        size_t a = e.find_first_not_of(' '), b = e.find_last_not_of(' ');
        e = (a == std::string::npos) ? "" : e.substr(a, b - a + 1);
        labels.push_back({lblLine, e, false});
      } else if (prevOk && i + 7 <= n && src.substr(i, 7) == "default" &&
                 (i + 7 == n || !idc(src[i + 7]))) {
        labels.push_back({line, "", true});
        i += 6;
      }
    }
    for (size_t k = 0; k < labels.size(); ++k) {
      unsigned spanEnd =
          (k + 1 < labels.size() && labels[k + 1].line > labels[k].line)
              ? labels[k + 1].line - 1
              : bodyEnd;
      GuardRec g;
      g.kind = "switch";
      g.line = labels[k].line;
      g.startLine = labels[k].line;
      g.endLine = spanEnd < labels[k].line ? labels[k].line : spanEnd;
      if (labels[k].isDefault) {
        g.expr = scrut + " (default case)";
        g.hasPolarity = false;
        g.polarity = false;
      } else {
        g.expr = scrut + " == " + labels[k].expr;
        g.hasPolarity = true;
        g.polarity = true;
      }
      out.push_back(g);
    }
  }

  void collectGuards(const Stmt *S, std::vector<GuardRec> &out) {
    if (!S)
      return;

    // CompoundStmt: before descending, emit an EARLY-EXIT fall-through guard for
    // each direct child that is an `if (c) { …return/break/continue/goto; }` whose
    // then-arm always terminates (and whose else, if any, also terminates). The
    // fall-through region is scoped to THIS block's closing-brace line, so only
    // statements lexically after the exiting `if` in the SAME block are guarded by
    // `!(c)` — the "directly inside a CompoundStmt" requirement is enforced by
    // iterating children here. We still recurse into every child as before, so a
    // terminating `if` nested in a deeper block emits its guard scoped to ITS block.
    if (const auto *CB = dyn_cast<CompoundStmt>(S)) {
      unsigned blockEnd = lineOf(CB->getRBracLoc(), SM);
      for (const Stmt *Child : CB->body()) {
        if (const auto *If = dyn_cast<IfStmt>(Child))
          emitFallThroughGuard(If, blockEnd, out);
        collectGuards(Child, out);
      }
      return;
    }

    if (const auto *If = dyn_cast<IfStmt>(S)) {
      GuardRec base;
      base.expr = condTextOf(If->getCond());
      base.kind = "if";
      base.hasPolarity = true;
      base.line = lineOf(If->getBeginLoc(), SM);
      if (const Stmt *Init = If->getInit())
        collectGuards(Init, out);
      if (const Stmt *Then = If->getThen()) {
        GuardRec g = base;
        g.polarity = true;
        addGuard(out, g, Then, base.line);
        collectGuards(Then, out);
      }
      if (const Stmt *Else = If->getElse()) {
        GuardRec g = base;
        g.polarity = false;
        // `else if` chains: the Else is itself an IfStmt; span it from the
        // controlling line so the chained condition's region is correct.
        unsigned eline = lineOf(Else->getBeginLoc(), SM);
        addGuard(out, g, Else, eline ? eline : base.line);
        collectGuards(Else, out);
      }
      return;
    }

    if (const auto *SW = dyn_cast<SwitchStmt>(S)) {
      if (const Stmt *Init = SW->getInit())
        collectGuards(Init, out);
      const Stmt *Body = SW->getBody();
      const auto *CB = dyn_cast_or_null<CompoundStmt>(Body);
      if (!CB) {
        if (Body)
          collectGuards(Body, out);
        return;
      }
      // A1: if Clang dropped the CaseStmt nodes (unresolved/dependent scrutinee),
      // recover case guards lexically + mark the collapsed region, then walk the
      // bare children for any nested control flow. NOTE: detect on CaseStmt
      // specifically — a collapsed switch often RETAINS the lone DefaultStmt (which
      // is also a SwitchCase), so checking isa<SwitchCase> would miss the collapse.
      bool hasCases = false;
      for (const Stmt *Child : CB->body())
        if (isa<CaseStmt>(Child)) { hasCases = true; break; }
      if (!hasCases) {
        recoverCollapsedSwitch(SW, CB, out);
        for (const Stmt *Child : CB->body())
          collectGuards(Child, out);
        return;
      }
      // Walk the switch body, accumulating the run of consecutive case labels
      // feeding the current body group. Each group emits one OR-of-cases guard
      // whose span covers the group's statements.
      std::vector<const SwitchCase *> run;
      for (const Stmt *Child : CB->body()) {
        if (const auto *SC = dyn_cast<SwitchCase>(Child)) {
          const SwitchCase *cur = SC;
          run.push_back(cur);
          while (const auto *inner =
                     dyn_cast_or_null<SwitchCase>(cur->getSubStmt())) {
            run.push_back(inner);
            cur = inner;
          }
          const Stmt *sub = cur->getSubStmt();
          GuardRec g = switchCaseGuard(SW, run);
          // Span the guard over the whole labeled run down through its body so
          // a dropped member-write inside still line-contains.
          unsigned cstart = lineOf(SC->getBeginLoc(), SM);
          addGuard(out, g, sub, cstart);
          collectGuards(sub, out);
          if (endsCaseGroup(sub))
            run.clear();
        } else {
          if (!run.empty()) {
            GuardRec g = switchCaseGuard(SW, run);
            unsigned cstart = lineOf(Child->getBeginLoc(), SM);
            addGuard(out, g, Child, cstart);
          }
          collectGuards(Child, out);
          if (endsCaseGroup(Child))
            run.clear();
        }
      }
      return;
    }

    // loops: For / While / Do / range-for — emit the loop condition guard over
    // the body span (kind="loop").
    auto emitLoop = [&](const Expr *Cond, const Stmt *Body, unsigned ctrlLine) {
      GuardRec g;
      g.expr = condTextOf(Cond);
      g.kind = "loop";
      g.polarity = true;
      g.hasPolarity = true;
      g.line = ctrlLine;
      if (!g.expr.empty())
        addGuard(out, g, Body, ctrlLine);
      if (Body)
        collectGuards(Body, out);
    };
    if (const auto *F = dyn_cast<ForStmt>(S)) {
      if (const Stmt *Init = F->getInit())
        collectGuards(Init, out);
      emitLoop(F->getCond(), F->getBody(), lineOf(F->getBeginLoc(), SM));
      return;
    }
    if (const auto *W = dyn_cast<WhileStmt>(S)) {
      emitLoop(W->getCond(), W->getBody(), lineOf(W->getBeginLoc(), SM));
      return;
    }
    if (const auto *D = dyn_cast<DoStmt>(S)) {
      emitLoop(D->getCond(), D->getBody(), lineOf(D->getBeginLoc(), SM));
      return;
    }
    if (const auto *FR = dyn_cast<CXXForRangeStmt>(S)) {
      GuardRec g;
      g.expr = exprText(FR->getRangeInit(), SM, LO);
      g.kind = "loop";
      g.polarity = true;
      g.hasPolarity = true;
      g.line = lineOf(FR->getBeginLoc(), SM);
      if (!g.expr.empty())
        addGuard(out, g, FR->getBody(), g.line);
      if (const Stmt *B = FR->getBody())
        collectGuards(B, out);
      return;
    }

    // Ordinary statement: descend into children (catches nested control flow).
    for (const Stmt *Child : S->children())
      collectGuards(Child, out);
  }

  void recordAssignment(const Stmt *Node, const Expr *LHS, const Expr *RHS,
                        bool isDecl, SourceLocation opLoc,
                        const std::map<const Stmt *, unsigned> &stmtBlock,
                        const std::map<const ValueDecl *, size_t> &paramIndex,
                        std::vector<ParamRec> &params,
                        std::vector<AssignmentRec> &assignments) {
    AssignmentRec a;
    a.line = lineOf(opLoc, SM);
    if (a.line == 0)
      a.line = lineOf(LHS->getBeginLoc(), SM);
    // The assignment expression node itself is the CFGStmt the CFG records;
    // fall back to LHS/RHS sub-exprs if it isn't a top-level element.
    a.blockId = blockOf(Node, stmtBlock);
    if (a.blockId == (unsigned)-1)
      a.blockId = blockOf(LHS, stmtBlock);
    if (a.blockId == (unsigned)-1)
      a.blockId = blockOf(RHS, stmtBlock);
    std::string path;
    if (buildMemberPath(LHS, path))
      a.lhsPath = path;
    else
      a.lhsPath = exprText(LHS, SM, LO);
    a.rhsExpr = exprText(RHS, SM, LO);
    a.isDecl = isDecl;
    assignments.push_back(a);

    // by-ref/pointer param write detection
    const ValueDecl *root = rootDeclOf(LHS);
    if (root) {
      auto it = paramIndex.find(root);
      if (it != paramIndex.end())
        params[it->second].written = true;
    }
  }

  void recordCall(const CallExpr *CE,
                  const std::map<const Stmt *, unsigned> &stmtBlock,
                  std::vector<CallRec> &calls) {
    CallRec c;
    c.line = lineOf(CE->getBeginLoc(), SM);
    c.blockId = blockOf(CE, stmtBlock);

    // callee name
    std::string callee;
    if (const FunctionDecl *FD = CE->getDirectCallee()) {
      callee = FD->getNameAsString();
    } else if (const Expr *Callee = CE->getCallee()) {
      callee = exprText(Callee, SM, LO);
    }
    c.callee = callee;

    const FunctionDecl *FD = CE->getDirectCallee();
    for (unsigned i = 0; i < CE->getNumArgs(); ++i) {
      const Expr *Arg = CE->getArg(i)->IgnoreParenImpCasts();
      c.args.push_back(exprText(Arg, SM, LO));

      bool byRef = false;
      // param is reference or pointer?
      if (FD && i < FD->getNumParams()) {
        QualType PT = FD->getParamDecl(i)->getType();
        if (PT->isReferenceType() || PT->isPointerType())
          byRef = true;
      }
      // arg is address-of?
      if (const auto *UO = dyn_cast<UnaryOperator>(Arg)) {
        if (UO->getOpcode() == UO_AddrOf)
          byRef = true;
      }
      if (byRef)
        c.byRefArgIdx.push_back((int)i);
    }
    calls.push_back(c);
  }
};

// ---------------------------------------------------------------------------
// AST consumer: visit every function DEFINITION in the main file.
// ---------------------------------------------------------------------------
class CFGVisitor : public RecursiveASTVisitor<CFGVisitor> {
public:
  CFGVisitor(ASTContext &Ctx, llvm::raw_ostream &OS)
      : Ctx(Ctx), SM(Ctx.getSourceManager()), Emit(Ctx, OS) {}

  bool VisitFunctionDecl(FunctionDecl *FD) {
    if (!FD->isThisDeclarationADefinition() || !FD->hasBody())
      return true;
    // Only functions whose body lives in the main file (skip system/header
    // bodies that happened to parse).
    SourceLocation Loc = FD->getLocation();
    if (Loc.isInvalid() || !SM.isInMainFile(Loc))
      return true;
    Emit.emit(FD);
    return true;
  }

private:
  ASTContext &Ctx;
  const SourceManager &SM;
  FunctionEmitter Emit;
};

class CFGConsumer : public ASTConsumer {
public:
  CFGConsumer(llvm::raw_ostream &OS) : OS(OS) {}
  void HandleTranslationUnit(ASTContext &Ctx) override {
    CFGVisitor V(Ctx, OS);
    V.TraverseDecl(Ctx.getTranslationUnitDecl());
  }

private:
  llvm::raw_ostream &OS;
};

class CFGAction : public ASTFrontendAction {
public:
  std::unique_ptr<ASTConsumer>
  CreateASTConsumer(CompilerInstance &CI, llvm::StringRef) override {
    return std::make_unique<CFGConsumer>(llvm::outs());
  }
};

int main(int argc, const char **argv) {
  auto ExpectedParser =
      tooling::CommonOptionsParser::create(argc, argv, ToolCategory);
  if (!ExpectedParser) {
    llvm::errs() << ExpectedParser.takeError();
    return 1;
  }
  tooling::CommonOptionsParser &OptionsParser = ExpectedParser.get();
  tooling::ClangTool Tool(OptionsParser.getCompilations(),
                          OptionsParser.getSourcePathList());
  return Tool.run(tooling::newFrontendActionFactory<CFGAction>().get());
}
