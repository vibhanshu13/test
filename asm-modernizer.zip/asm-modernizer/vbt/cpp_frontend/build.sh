#!/usr/bin/env bash
# Build cfg_extract against the Homebrew LLVM/Clang (LibTooling).
#
# Usage: ./build.sh
# Produces: ./cfg_extract
set -euo pipefail

LLVM_PREFIX="${LLVM_PREFIX:-/opt/homebrew/opt/llvm}"
LLVM_CONFIG="${LLVM_CONFIG:-$LLVM_PREFIX/bin/llvm-config}"
CXX="${CXX:-$LLVM_PREFIX/bin/clang++}"

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

CXXFLAGS="$("$LLVM_CONFIG" --cxxflags)"
LDFLAGS="$("$LLVM_CONFIG" --ldflags)"
LIBDIR="$("$LLVM_CONFIG" --libdir)"

# Homebrew's libc++ headers need the macOS SDK to resolve system headers
# (time_t, FP_* macros, etc). Point clang++ at it explicitly.
SDKROOT="${SDKROOT:-$(xcrun --show-sdk-path 2>/dev/null || true)}"
SDK_FLAGS=""
if [ -n "$SDKROOT" ]; then
    SDK_FLAGS="-isysroot $SDKROOT"
fi

# LibTooling + the clang AST/Analysis/CFG live in the single shared
# libclang-cpp dylib; libLLVM provides the support layer. This is the
# simplest, smallest link line on a brew LLVM install.
CLANG_LIBS="-lclang-cpp -lLLVM"

set -x
"$CXX" $CXXFLAGS \
    $SDK_FLAGS \
    -fno-rtti \
    "$HERE/cfg_extract.cpp" \
    -o "$HERE/cfg_extract" \
    $LDFLAGS \
    -L"$LIBDIR" \
    -Wl,-rpath,"$LIBDIR" \
    $CLANG_LIBS
set +x

echo "Built: $HERE/cfg_extract"
