# VBT Recursive Dependency Lineage (LCA-Feasibility)

Answer one question, fast and DB-only:

> **"Given a variable and an entry point, which setters can actually have produced the
> value observed there — under what conditions, and what do those setters themselves
> depend on, recursively?"**

Input: a variable (ASM or C++) + an entry endpoint (`stem` / `file_type` / `function`).
Output: a flat list of variables, each with its setters; every setter carries its
**entry**, its **LCA** against that entry, a **feasible / infeasible verdict with a
reason**, witness call paths, setter-local **conditions**, and the **dependent
variables** it reads. Dependent variables recurse with *their read site* as the new
entry.

Strictly `index.db`-only: no source reads, no blueprint JSON reads, no cfg subprocess —
ever (test-enforced). Typical depth-1 runtime is **under a second** on a warm worker.

| Artifact | Path |
|----------|------|
| Core module | `vbt/depvars/lca_lineage.py` (`run_lca_lineage`) |
| Celery task | `api/tasks/vbt_recursive_lineage_task.py` (`asm.vbt_recursive_dependency_lineage`) |
| Tests (core) | `vbt/tests/test_lca_lineage.py` |
| Tests (task) | `api/tasks/test_vbt_recursive_lineage_task.py` |
| CLI (dev) | `python -m vbt.depvars.lca_lineage --kb-id … --variable … --entry-stem … --asm-dir …` |
| Output | `jobs/<job_id>/output/recursive_dependency_lineage.json` |
| Predecessor (retired from the task) | `vbt/depvars/recursive_lineage.py` — trace_root_variable DAG projection + gap analysis |

---

## Modes

| `mode` (task option / `--mode`) | What it does | When to use |
|---|---|---|
| `"lca-feasibility"` (**default**) | Everything below: per-setter LCA + static-order feasibility gate; only feasible setters get conditions/dep vars/recursion. | "Which setters can actually affect the value at *this entry*?" |
| `"all-setters"` (opt-in) | **Skips feasibility entirely** — every discovered setter is emitted with `feasible: true, reason: "all-setters-mode"`, `lca: null`, no `lcaPath`; all of them get conditions + dep vars and recurse. No LCA/BFS/ordering work runs at all; the entry becomes metadata only (not validated against the graph). | "Show me *everything* that writes this variable (and its deps), regardless of the entry." |

Both modes share the same discovery, alias/counterpart resolution, conditions, dep-var
extraction, recursion, dedup, caps, caching, and logging. Cost intuition: `all-setters`
does **zero graph work** per setter (faster per setter, and immune to the graph-size
scaling of feasibility BFS), but it computes conditions/dep vars for **every** site and
recurses more variables — so on corpora where the gate prunes heavily, total wall-clock
can be similar or higher (e.g. softCardValue depth-1: 775/775 sites in 1.09s vs the
default's 357/775 in 0.74s). An invalid mode string raises `ValueError`.

---

## Why this design (history)

The first implementation wrapped `trace_root_variable`: per setter it **enumerated call
routes** entry→setter, which at 22k-file scale builds per-stem *caller forests* of
250k–440k nodes (minutes per stem), and its gap-analysis phase route-probed every
unreachable candidate — a depth-1 run took **2899s, of which ~47min was gap analysis
and 78s the trace**. The insight behind the redesign: reachability-by-route-enumeration
is the wrong primitive. What we actually need per setter is a *temporal feasibility
verdict* — "can this setter have fired by the time the entry is reached?" — and that is
answerable from the function graph alone with an LCA + static ordering, no route
enumeration at all. Same question, different algorithm: **2899s → 0.8s**.

---

## Core concepts

- **Function-graph node**: C++ → `(stem, function)`; ASM → `(stem, stem)` (a module is
  one node — reached at its entry). Prebuilt: `fn_graph_adj` artifact; edges carry the
  call-site line.
- **Entry**: where the question is asked. The root entry comes from the request; a dep
  var's entry is `(function, read-line)` — the exact site where a feasible setter read it.
- **Setter site**: one write instruction — from the precomputed `cpp_setter_map` /
  `asm_setters_full` blobs (never a live scan).
- **LCA**: the *nearest common ancestor* of (setter fn, entry fn) — the closest function
  from which the call graph reaches both. "Nearest" = minimal combined BFS hop distance,
  deterministic tie-break. **No common ancestor ⇒ the setter is infeasible** (nothing
  ever executes both).
- **Feasible**: from the LCA, the setter is reached **before** the entry in static
  program order — i.e. by the time execution arrives at the entry (or at the read line,
  for dep vars), the setter can already have fired.

---

## The full algorithm

### 0. Strict DB-only setup (once per request)

Clear all global hooks (no leaked state from other tasks), arm `load_only`, validate the
required artifact manifests (fn graph, reverse adjacency, the four resolver blobs,
fn_facts, both setter-map coverage artifacts) — any missing/stale one **hard-fails**
with "rerun precompute". Load resolvers from blobs, arm the DB-backed setter maps,
install the blueprint-blob override. The fn graph + derived reverse adjacency +
coverage maps come from a **cross-request corpus cache** keyed by manifest fingerprint
(`version`/`source_hash`/`built_at`), so a warm worker skips the load entirely and a
precompute rerun invalidates it automatically.

### 1. Variable queue (depth-first by default)

Seed: `(root variable, root entry, depth 0)`. Each popped item is deduped on the key
**(qualified-or-name, language, entry-node, entry-line)** — this key space is finite
(variables × read sites), each key processes at most once, and children carry `depth+1`,
so **dependency cycles terminate structurally** (A→B→A just re-enters at new read sites
until the key space or a cap is exhausted).

`traversal` picks the pop order:

- **`"dfs"` (default)** — LIFO: each `root → var1 → var2 → … → terminal` chain is
  completed before its siblings. Under a `max_dep_vars` budget on a huge corpus this is
  what you want: the budget buys **finished chains and terminal variables** instead of an
  unfinished depth-1 frontier. (Live, same budget of 60 vars on softCardValue: DFS
  reached depth 6 with 45 terminals vs BFS's depth 2 with 25.)
- **`"bfs"`** — FIFO level-order (the original behavior). Depth is monotone, so every
  variable is emitted at its shallowest depth.

With **no binding budget both traversals process the same variable set** with identical
per-variable setter verdicts (test-enforced); only visit order — and the `depth` a
duplicate is first met at — differs. One subtlety DFS handles explicitly: LIFO can meet a
key *deep first* (its children suppressed by the depth cap) and again *shallower* later;
the engine then **re-expands** just that key's children at the shallower depth (a ~free
memo replay — the variable's JSON entry is depth-independent and already emitted), so no
subtree BFS would have explored is ever lost.

### 2. Setter discovery (memoized per variable)

Resolve the variable's **alias set** — including cross-language counterparts (e.g.
`softCardValue (cpp)` ↔ `LWRPOSFCRDV (asm)`; the alias artifact keys C++ names by
their *qualified* path, which is why dep vars are searched by qualified path when they
carry one). For every `(name, language)` target, sweep the modifier index's stems and
load setter sites from the DB maps. C++ sites are attributed to a graph node via their
stored function, falling back to fn_facts nearest-preceding-start; unattributable sites
are excluded and counted. Coverage rule: a coverage hole **hard-fails for the root
variable** (incomplete precompute must be visible) but degrades to a warning + skipped
stem for dep vars (one odd extracted token must not kill the trace).

### 3. Feasibility per setter site

For each setter site vs the item's entry, in order:

| Case | Verdict | Rule |
|------|---------|------|
| same function, root entry (no line) | **feasible** `same-function-as-entry` | can't order without a line |
| same function, dep-var entry | line compare | `setter.line < read.line` ⇒ feasible (`same-function-line-order`), else infeasible |
| no common ancestor | **infeasible** `no-lca` | nothing executes both — the single biggest pruning class |
| setter fn is an ancestor of entry | feasible unless `setter.line >` the **latest** call site descending toward the entry (`setter-after-descent-to-entry`) | latest site = most permissive, mirrors `_prefix_guards`' descend bound |
| entry fn is an ancestor of setter | root entry ⇒ **feasible** `downstream-of-entry` (the entry's execution is what reaches it); dep-var entry ⇒ the **earliest** descent site must precede the read line | earliest site = most permissive |
| true sibling under an LCA | ordered DFS from the LCA: first-arrival index of setter-node vs entry-node, callees visited in call-site line order, descent pruned to nodes that can still reach either target | `setter-before-entry` / `entry-before-setter` |

Mechanics: ancestor sets come from reverse-BFS with distances + parent pointers
(memoized per node); the LCA is the common ancestor minimizing summed distance; every
setter with an LCA also emits `lcaPath` — **one shortest witness call path** per leg
(LCA→setter, LCA→entry), reconstructed free from the BFS parent pointers. A scale-gated
pre-filter (≥16 distinct setter fn-nodes) computes one forward closure of the entry's
ancestor cone and rejects the `no-lca` majority by O(1) membership — exact, since
*common-ancestor-exists ⟺ setter ∈ descendants(ancestors(entry))*.

### 4. Conditions + dependent variables (feasible setters only, memoized per site)

- **C++**: guards from `collect_cpp_conditions` over the cfg served from **cfg blobs**
  (key = path+size+mtime stats only; a blob miss ⇒ `conditionsAvailable: false` +
  warning, never a clang subprocess).
- **ASM**: guards from `collect_asm_conditions` over the **blueprint blob** (CFG walk
  with per-branch polarity; served via the DB blueprint override).
- **Dep vars**: `extract_dep_vars` over the setter's value expression + its guard
  expressions (pure parsing; blueprint symbol table filters constants). Function-output
  deps are flagged but not recursed. Infeasible setters get **no** conditions/dep vars —
  they can't have produced the observed value, so their inputs are irrelevant.

### 5. Recursion

Each dep var is queued with entry = *(the setter's fn-node, the read line)* and
`depth+1` (if under `max_dep_var_depth`). Re-queued duplicates (the same dep var seen
from another parent processing the same setter) dedup at pop — their key derives from
the setter's read site, not the parent's entry.

---

## Output shape (simplified)

```jsonc
{
  "variable": "L7DCME", "language": "asm",
  "entry": {"stem": "dw710000", "file_type": "cpp", "function": "callPlastic..."},
  "semantics": { "feasibility": "lca-first-arrival", "noLca": "infeasible",
                 "order": "static-call-site-line-order", "runtimeProof": false },
  "variables": [
    {
      "name": "L7DCME", "depth": 0, "entry": {...},
      "setterCount": 27, "feasibleSetterCount": 10, "infeasibleSetterCount": 17,
      "setters": [
        {
          "file": "hb66.asm", "line": 613, "instruction": "MVI", "value": "...",
          "entry": {...},
          "lca": {"file": "hb66.asm", "function": null},
          "feasible": true, "reason": "setter-on-path-to-entry",
          "lcaPath": { "toSetter": [ ...hops... ], "toEntry": [ ...hops... ] },
          "conditionsAvailable": true,
          "conditions": [ {"condition": "L7DCDIC != C'5'", "location": {...}} ],
          "depVars": [ {"name": "L7DCDIC", "language": "asm", "entry": {...read site}} ]
        }
      ]
    },
    { "name": "L7DCDIC", "depth": 1, "collectedFrom": {...}, "entry": {...}, "setters": [...] }
  ],
  "stats": { "variables": 28, "setters": 128, "feasibleSetters": 28, "elapsedSec": 0.45 },
  "truncated": false, "warnings": []
}
```

---

## Limits, caps, and what happens at each

| Knob | Default | On hit |
|------|---------|--------|
| `max_dep_var_depth` | 1 | children not queued (depth is rarely the binding limit — recursion exhausts naturally) |
| `max_dep_vars` | 500 | loop breaks; `truncated: true` + warning + `STOPPED…` log |
| `max_setters_per_var` | 250 | per-var setter **evaluation** capped + warning — with 0 feasible found so far the var is *not* marked terminal (unproven) |
| `max_feasible_setters` | `None` (all) | stop evaluating a var's setters once N **feasible** ones are found; infeasible ones scanned on the way are still emitted; `feasibleSettersCapped: true` on the var + one aggregate warning. `1` = **witness mode**: one feasible setter per var — minimal fanout, so the budget drills the deepest chains (but the lineage is a single witness thread, not exhaustive) |
| `max_order_nodes` | 20000 | ordering DFS truncated ⇒ verdict `order-unresolved` (conservatively infeasible), `truncated: true` |
| `traversal` | `"dfs"` | not a cap — see §1. `"bfs"` restores level-order |

"Unlimited depth" is safe: termination is guaranteed by the finite dedup-key space, not
by the depth cap. `max_dep_vars` is the real budget knob for output size.

**Terminal variables** — the leaves of the lineage (`root → var1 → … → terminal`): every
variable entry carries `terminal: true` iff it has **0 feasible setters and its setter
scan wasn't truncated** by `max_setters_per_var`; `stats.terminalVariables` counts them.
To maximize terminals per budget: DFS (default) + a high `max_dep_var_depth` (e.g. 50 —
the budget binds, not the depth). Caveat: `max_setters_per_var: 1` is the WRONG knob for
this — it caps setters *evaluated*, so the one evaluated setter may be infeasible and a
live variable would look terminal; use `max_feasible_setters: 1` instead.

## Performance model

Everything expensive is memoized at the right granularity: ancestor BFS per fn-node,
LCA per (setter-node, entry-node), ordering DFS per (LCA, setter, entry), conditions +
dep vars per **setter site** (entry-independent), setter discovery + aliases per
variable, cfg/blueprint blobs per stem, sorted adjacencies per node — plus the
cross-request corpus cache and the scale-gated no-LCA cone pre-filter. The end-of-run
`counters:` log line shows every hit/run rate, so a slow run on a new corpus is
diagnosable from the log alone.

Logging: the task defaults to `progress` on — `[vbt {ms}]` lines with per-phase setup
timings, per-variable summaries (setter counts, feasibility reasons, dep vars queued),
and a `TOTAL` + `counters` summary. `VBT_HANG_DEBUG=1` upgrades to a per-operation
DEBUG trace whose last line names the exact stuck call. Both are output-identical.

Recommended worker (the corpus cache is per-process):

```bash
celery -A api.tasks.celery_app worker -n lineage@%h -Q celery \
  --pool=prefork --concurrency=1 --max-tasks-per-child=100000
```

## Guarantees (test-enforced) and known approximations

**Guaranteed**: zero source/blueprint/cfg disk reads (disk fallbacks are patched to
*raise* in tests); deterministic output across runs and processes; cycle-safe
termination at any depth; feasibility pre-filter and all memos are output-identical
(forced on/off equivalence tests); `load_only` and all global hooks restored on exit.

**Approximations (by design — `semantics.runtimeProof` is always `false`)**:
- Ordering is **static** call-site/line order: a loop-carried setter written after the
  read line is conservatively infeasible for that read.
- `lcaPath` is one shortest witness per leg, not an enumeration of all routes.
- ASM ordering is module-granular (no CFG block-rank/dominance between ASM call sites yet).
- Register-indirect ASM setter sources (`0(R1)`) are not resolved to field names.
- No synthetic "[not set]" outcome entries (the full trace engine's GAP-9 feature).
