# Verification Prompt Phase 2 - Reachable Setters Validation And Report

> Paste everything below into Copilot / agent mode after Phase 1 has produced a suspect report.
> This phase validates suspects and writes the final audit report.

---

## Inputs

Use these inputs from Phase 1:

```text
phase1_report: <path or pasted report>
kb_id: <kb_id>
entry_stem: <stem>
entry_function: <function>
production_output_json: <path>
capraised_diff_json: <path>
asm_dir: <source dir>
blueprint_dir: jobs/<kb_id>/output
```

If any Phase 1 artifact is missing, reconstruct only the missing minimal artifact. Do not rerun the whole audit unless necessary.

Use `vbt/PROMPT_verify_reachable_setters.md` as the master audit spec for definitions and failure buckets.

Expected `capraised_diff_json` shape:

```text
inputs
caps
baseline
harness_prod_caps
raised_caps
diffs.new_vs_baseline
diffs.gone_vs_baseline
diffs.changed_counts_vs_baseline
diffs.new_vs_harness_prod_caps
diffs.gone_vs_harness_prod_caps
diffs.changed_counts_vs_harness_prod_caps
zero_reported_setters
```

---

## Role

You are a meticulous static-analysis auditor. Your job in this phase is to validate the Phase 1 suspects and produce the final correctness report.

A discrepancy is `confirmed` only when both are independently verified:

1. the source site really writes this variable's storage;
2. a concrete hop-by-hop valid path exists from `entry_stem::entry_function` to that setter.

If either check is incomplete, keep the site as `candidate`, `suspected`, or `rejected`; do not promote it to confirmed.

---

## Candidate Universe

Validate from the union:

```text
production output
cap-raised output / new_vs_baseline
grep/source-write oracle candidates for high-risk variables
zero-setter variables from Phase 1
top-N high-count variables from Phase 1
random sample of approximately 15 remaining variables, if time allows
```

Do not rely on the production task's candidate logic or reachability logic as ground truth.

---

## Validation Procedure

For each Phase 1 high-priority candidate:

1. **Source-write validation**
   - Open the source at the reported file and line.
   - Confirm the site writes this variable's storage, not a homonym tail.
   - For C++, inspect the LHS owner/member chain and declaration status.
   - For ASM, inspect the opcode, destination operand, DSECT/field mapping, and register-indirect resolution if relevant.
   - Reject comments, RHS-only reads, macro definitions without call-site proof, value-preserving/RMW-only writes when they do not count under the audit definition, and unrelated homonyms.

2. **Reachability validation**
   - Find one concrete path from `entry_stem::entry_function` to the setter site.
   - Prefer shortest metadata paths first, but validate each hop against source wherever possible.
   - Validate that the caller function actually contains the call line.
   - Validate that the callee resolves to the claimed destination file/function.
   - Do not accept file-level reachability as proof of function-level reachability.
   - Do not accept broad entry-name fan-out without source evidence.
   - For ASM, ensure the path originates from the intended entry/block, not another collapsed module entry.
   - Validation cap: try the shortest 25 metadata paths per destination or spend at most 10 minutes per destination, whichever comes first. If no path validates within that cap, label the candidate `candidate` or `unverified`, not confirmed.

3. **Attribution validation**
   - Confirm `function`, `block_id`, `line`, `file_stem`, and `code` fields match the real site.
   - If the site is legitimate but metadata points to the wrong function/block/line/code, classify as `MIS-ATTRIBUTED`.

---

## Soundness Sampling

Do not attempt exhaustive per-reported-setter soundness unless explicitly requested. Review:

```text
all gone_vs_baseline sites
all route/file-level-only suspects, if Phase 1 produced this bucket
all changed-count variables
all zero-setter variables with grep/source candidates
top-N variables by reported setter count
approximately 15 random remaining variables
```

For sampled variables that show no issue, use `no issue found in sampled checks`, not `OK`.

Use `OK` only for variables whose candidate universe and reported setters were fully reviewed.

---

## Grep / Source-Write Oracle Minimum

For high-risk variables and zero-setter variables, build a source-write candidate set before declaring no issue found. At minimum:

```text
C++ direct writes:
  <tail>\s*(=|\+=|-=|\*=|/=|\|=|&=|\^=|<<=|>>=|\+\+|--)
C++ destination APIs:
  memcpy, memmove, memset, strcpy, strncpy, bcopy, bzero, sprintf, snprintf
C++ macro call sites:
  macro invocations whose definitions write the field
ASM direct field writes:
  SETTER_INST opcodes with the field/DSECT label as destination operand
ASM indirect writes:
  register-indirect destinations with an independent backward register walk
```

Raw grep hits are not evidence. Discard comments, RHS-only reads, declarations that do not write storage under the audit definition, macro definitions without confirmed call sites, and unrelated homonym tails before adding a candidate to the oracle.

---

## Root-Cause Buckets

Use the bucket numbers and names from `vbt/PROMPT_verify_reachable_setters.md`.

Common MISSED buckets:

```text
2.1 depth/path caps
2.2 entry fan-out cap
2.3 dense-graph stale-stop
2.4 route cache / max_len mismatch
2.5 modifier-index miss
2.6 alias-resolution miss
2.7 forward_reachable_files pre-filter miss
2.8 setter-detection miss
2.9 incomplete DB precompute
```

Common EXTRA buckets:

```text
3.1 tail-only over-collection
3.2 declaration counted as setter
3.3 value-preserving/RMW ASM write
3.4 phantom reachability
3.5 mis-attribution
3.6 wrong alias bleed-through
3.7 ASM-entry reachability over-approximation
```

If a site does not fit, create a new bucket only after explaining why the existing buckets do not apply.

---

## Required Final Output

Produce a final report with:

1. **Per-variable table**

```text
variable | aliases_found | reported | oracle_reachable | MISSED | EXTRA | MIS-ATTRIBUTED | verdict
```

Allowed verdicts:

```text
OK
under-reports
over-reports
both
no issue found in sampled checks
not fully soundness-reviewed
blocked
```

2. **Discrepancy table**

```text
variable | site (file:line:fn) | classification | root-cause bucket | confidence | evidence
```

For evidence, cite the source line and show the validated path, or show the failing check.

For each confirmed or suspected discrepancy, include this evidence block:

```text
variable:
site:
source-write verdict:
source line:
validated path:
production result:
cap-raised result:
classification:
bucket:
confidence:
why not lower confidence:
```

If there is no validated path, write `validated path: none within cap` and do not mark the finding `confirmed`.

3. **Root-cause rollup**

Counts by bucket, split by `confirmed`, `candidate`, `suspected`, and `rejected`.

4. **Residual risk**

List anything not verified and why, including:

```text
source unavailable
path validation cap hit
only metadata-level reachability available
alias could not be independently derived
harness could not exercise fan-out cap because fn_graph_adj was precomputed
production output missing or not reproducible
```

Be skeptical and concrete. Prefer `needs evidence` over `looks fine`.
