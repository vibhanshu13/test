# Running VBT precompute from scratch on a new system

How to stand up the VBT trace engine on a fresh machine and precompute a codebase so traces are
fast (DB-backed). Two ways to run precompute: the **standalone CLI** (no services needed — easiest
for another machine) and the **Celery task** (production).

> **Is precompute a Celery task?** Yes — `asm.vbt_precompute` (`api/tasks/vbt_precompute_task.py`,
> `run_vbt_precompute`). It runs all steps in one job: call graph → modifier index → const resolver
> → parallel cfg-warm → **Step 5/5 the VBT DB artifacts (`vbt.precompute_db`)**. The CLI below runs
> the exact same building blocks without needing a broker/worker.

All commands run from the repo root using the repo venv (`env/bin/python3`).

---

## 1. One-time machine setup

```bash
git clone https://github.com/OpzenProduct/asm-modernizer.git
cd asm-modernizer
python3 -m venv env && source env/bin/activate
pip install -r requirements.txt          # + requirements-api.txt if you want the API/Celery path

# Build the C++ frontend (Clang LibTooling cfg_extract). Needs LLVM/Clang dev headers installed.
bash vbt/cpp_frontend/build.sh            # produces vbt/cpp_frontend/cfg_extract
env/bin/python3 -c "import vbt; print('vbt import OK')"
```

Notes:
- `cfg_extract` needs LLVM (`brew install llvm` on macOS; the distro's `llvm`/`clang` dev packages
  on Linux). `build.sh` prints the toolchain it found.
- The Celery path additionally needs **Redis** running (default broker `redis://localhost:6379`;
  override with `REDIS_URL` / `CELERY_BROKER_URL`). The CLI path needs none of this.

## 2. Get the inputs: blueprints + source

Precompute consumes a `--blueprint-dir` (`.cpp.json`/`.asm.json`/… per source file) and the matching
`--asm-dir` (the source). `index.db` does **not** need to pre-exist — `vbt.precompute_db` creates
`jobs/<id>/index.db` itself (idempotent `create_all`). Pick one:

**A. Copy an already-parsed job (simplest).** Copy the whole `jobs/<id>/` directory **and** its
source tree from the origin machine. That's all precompute needs. (`index.db` can be copied too, or
rebuilt by step 3.)

**B. Re-parse from source.** The parser (`main.py`) emits blueprints from source:
```bash
env/bin/python3 main.py <source files or dir> -o jobs/<id>/output
# e.g. a directory (auto-discovers COPY includes):
env/bin/python3 main.py path/to/src/ -o jobs/<id>/output
```
Then use `jobs/<id>/output` as `--blueprint-dir` and `path/to/src` as `--asm-dir`.

## 3. Run precompute

### CLI (self-contained — recommended for another machine)
```bash
# (a) file/disk artifacts: call graph + modifier index + const resolver + parallel cfg-warm
env/bin/python3 -m vbt.precompute_all \
    --blueprint-dir jobs/<id>/output \
    --asm-dir       /path/to/source

# (b) DB artifacts → jobs/<id>/index.db (resolvers, route name_to_stems, cpp_call_edges,
#     ASM blueprints, source text, cfg blobs) so a --job-id trace reads index.db, not files
env/bin/python3 -m vbt.precompute_db \
    --job-id <id> \
    --blueprint-dir jobs/<id>/output \
    --asm-dir       /path/to/source
```
Both are idempotent + near-instant when nothing changed. **Re-run `vbt.precompute_db` whenever the
blueprints/source change** — a `--job-id` trace trusts the DB for freshness (O(1) reads, no
per-trace file scans). It also clears the cross-trace caches (whole-trace results + route cache) on
rebuild, so a stale result is never served.

### Celery (production)
Start a worker, then enqueue the task:
```bash
# worker (needs Redis up)
celery -A api.tasks.celery_app worker -l info

# enqueue from a python shell / the API
from api.tasks.vbt_precompute_task import run_vbt_precompute
run_vbt_precompute.delay("<id>", {"blueprint_dir": "jobs/<id>/output", "asm_dir": "/path/to/source"})
```
`asm.vbt_precompute` runs steps 1–5 incl. the DB artifacts. The trace tasks (`asm.vbt_trace`,
`asm.vbt_table`) pass the `kb_id` as `job_id`, so API traces are DB-backed automatically.

## 3b. Speed knobs (optional, both byte-identical)

Two independent levers make a heavy trace fast. Both are off by default and change **timing only**,
never output (verified `cmp`-identical).

**Eager route warming (recommended — the cold-trace lever).** A deep trace is route-walk-bound; the
route cache makes a *warm* trace ~17s (vs ~44s cold) on the reference corpus. Add `--warm-*` to
`vbt.precompute_db` to run a seed trace at precompute, so the cache is filled **offline** and the
**first** trace a user runs is already warm. Pass the SAME hops/caps you will trace:
```bash
env/bin/python3 -m vbt.precompute_db --job-id <id> \
    --blueprint-dir jobs/<id>/output --asm-dir /path/to/source \
    --warm-variable softCardValue --warm-language cpp \
    --warm-hop aa71:asm --warm-hop dw730000:cpp:DW73 \
    --warm-hop dw710000:cpp:callPlasticAuthenticationComponentInterface \
    --warm-max-dep-var-depth 3 --warm-max-routes 2000 --warm-max-offchain-files 1000 \
    --warm-max-paths 512 --warm-max-route-len 32 --warm-max-call-depth 32 --warm-asm-max-levels 32
```
Effect (reference corpus, depth-3): that exact variable then traces in **~0.2s** (whole-trace cache)
and a **similar** variable on the same chain in **~17s** (it reuses the warmed routes) — both under
30s. (Equivalent without the flag: just run `vbt.trace --job-id <id> …` once after precompute; it
warms the same caches lazily.)

**BFS parallelism (opt-in via `VBT_DEPVAR_WORKERS`).** Set `VBT_DEPVAR_WORKERS=N` (default 1 =
serial) to compute the dependent-variable BFS across N worker processes. Byte-identical, but the
trace is IO-bound so it gives little/no wall-clock gain on few-core or IO-bound machines (measured
~no change on Apple Silicon). Prefer eager warming; reach for this only on many-core hardware.
```bash
VBT_DEPVAR_WORKERS=8 env/bin/python3 -m vbt.trace … --job-id <id> …
```

## 4. Trace
```bash
env/bin/python3 -m vbt.trace \
    --variable <name> --language cpp \
    --hop <stem>:asm --hop <stem>:cpp:<fn> ...   # tail (deepest) LAST
    --blueprint-dir jobs/<id>/output \
    --asm-dir       /path/to/source \
    --job-id <id> \                              # reads index.db; omit = file/compute path (same output)
    --out result.json
```

## 5. Verify it produces identical output (regression gate)
```bash
env/bin/python3 -m vbt.tests.parity.check_parity            # re-trace the curated set vs goldens
```

---

## Copy-paste smoke test (the pinned corpus shipped in this repo)
```bash
env/bin/python3 -m vbt.precompute_db \
  --job-id demo \
  --blueprint-dir "jobs/1ffa983c-3282-42f2-9701-a4c3f21451b1/output/asm 5" \
  --asm-dir       "datasource/asm7_admin/asm 7_version_0/asm 5"

env/bin/python3 -m vbt.trace \
  --variable softCardValue --language cpp \
  --hop aa71:asm --hop dw730000:cpp:DW73 \
  --hop dw710000:cpp:callPlasticAuthenticationComponentInterface \
  --blueprint-dir "jobs/1ffa983c-3282-42f2-9701-a4c3f21451b1/output/asm 5" \
  --asm-dir       "datasource/asm7_admin/asm 7_version_0/asm 5" \
  --job-id demo --out /tmp/softCardValue.json
```
> Note the **space** in those dir names, and pair these blueprints with this source dir.

## What lives where (so you know what to copy / what's rebuilt)
- `jobs/<id>/output/` — blueprints (`*.cpp.json`/`*.asm.json`) + `file_call_graph.json`. **Input.**
- `<source dir>` — the `.cpp`/`.asm` source. **Input.**
- `jobs/<id>/index.db` — SQLite holding the VBT artifacts + caches. **Built by `vbt.precompute_db`**
  (safe to delete + rebuild; the trace falls back to the file/compute path without it).
- VBT disk cache (cfg-warm results, modifier/const indexes) — under the VBT cache dir; rebuilt by
  `vbt.precompute_all`.

See `QUICKSTART.md` (short) and `RUNNING.md` (full operational guide) for more.
