"""Register-indirect ASM setter-source resolution (SPEC §6 / register-drop gap).

A setter whose SOURCE is register-indirect — ``MVC LWRLS4CSCRES,0(R1)`` (the data
lives at the address in R1) — currently stops a backward trace, because
``is_dep_var_candidate("0(R1)")`` correctly rejects a bare displacement form.  This
module resolves the register to the real named field it points at, so the trace can
continue.

It is a *self-contained port* of the sound CFG-aware backward register reaching-def
core (``backward_traversal.tracing.asm_backward_tracer._backtrack_register_dep_vars``)
with the survey's two defects FIXED:

  1. Every emitted candidate is routed through ``is_dep_var_candidate`` (the original
     LA handler called ``normalize_token`` directly and leaked 7 ``L'NAME``
     length-attribute noise tokens, e.g. ``L'LWRLSEMVRES``).
  2. Predecessor blocks are scanned with a per-block ``before_line`` bound (the
     original passed ``before_line=None`` to predecessors, allowing it to read
     instructions textually AFTER the call site inside an earlier block).

Resolution order (SPEC):
  1. NAMED-prefix form ``FIELD(Rn)`` → the field is the dep (is_dep_var_candidate
     already accepts it).
  2. USING context: the nearest ``active_usings`` line ≤ before_line; if ``Rn`` is a
     DSECT base there, ``disp`` resolves to the member at that offset (high
     confidence).
  3. CFG-aware reaching-def on ``Rn`` (the ported core).

SOUNDNESS — give up, don't guess: not found within bounds, or ``Rn`` is
caller-inherited (no in-file definition before ``before_line``) → emit an
``indirection`` envelope (``indirect_via=Rn``), never a fabricated field.  Multiple
reaching defs across paths → emit all (OR alternatives).  We NEVER emit
``disp(Rn)`` / ``L'NAME`` / register tokens / literals — everything is routed through
``is_dep_var_candidate``.
"""
from __future__ import annotations

import re
from collections import deque
from dataclasses import dataclass, field as dc_field
from pathlib import Path
from typing import Any, Deque, Dict, FrozenSet, List, Optional, Set, Tuple

# ---- read-only reuse from backward_traversal (never modified in place) ----
from backward_traversal.utils.token_utils import (
    is_dep_var_candidate,
    looks_like_register_token,
    normalize_token,
)
from backward_traversal.glossary.instructions import (
    REGISTER_LOAD_FROM_MEM,
    REGISTER_COPY_FROM_REG,
    REGISTER_LOAD_ADDRESS,         # {LA: 1, LAY: 1}
    ALLOC_RESULT_REG,
    DB_CONTEXT_REG,
    LEVEL_TO_CE1CR,
    SUBROUTINE_INST,
    CROSS_FILE_CALL_OPCODES,
    SETTER_INST,
    DEST_ARG_INDEX_BY_INST,
)
from api.utils.indirection import envelope_from_fields

# ---- VBT-local glossary (the missing opcodes; never edits backward_traversal) ----
from vbt.resolve.asm_indirect_glossary import (
    REGISTER_LOAD_ADDRESS_EXT,
    PC_RELATIVE_LOAD_ADDRESS,
    REGISTER_LOAD_FROM_MEM_EXT,
    REGISTER_MULTI_LOAD,
    IMMEDIATE_LOAD_INST,
    ADDRESS_ARITH_INPLACE,
)

# blueprint flow iterator (handles old list + columnar formats)
from blueprint_io import iter_flow

# CFG maps + raw-operand parser — same builders the conditions / modifier-index reuse.
from backward_traversal.tracing.asm_backward_tracer import _get_file_cfg_maps, _parse_raw_operands


# --------------------------------------------------------------------------- #
# Result type
# --------------------------------------------------------------------------- #
@dataclass
class ResolvedIndirect:
    """Outcome of resolving one register-indirect operand.

    ``named_deps`` — resolved named fields (OR alternatives when paths diverge).
    ``kind``       — how it resolved: ``named_prefix`` | ``using`` | ``reaching_def``
                     | ``implicit`` | ``constant`` | ``unresolved``.
    ``unresolved_envelope`` — set ONLY when we give up (caller-inherited / not found
                     within bounds): an ``indirection`` envelope (``indirect_via=Rn``).
    """
    named_deps: List[str] = dc_field(default_factory=list)
    kind: str = "unresolved"
    unresolved_envelope: Optional[Dict[str, Any]] = None
    base_register: Optional[str] = None


# --------------------------------------------------------------------------- #
# Operand parsing
# --------------------------------------------------------------------------- #
# disp(Rn) or disp(Rx,Rn) — pre-paren may be empty / a number / a named symbol.
_INDIRECT_RE = re.compile(r"^\s*([^(]*)\(\s*([^)]*?)\s*\)\s*$")


def is_register_indirect(operand: str) -> bool:
    """True for ``disp(Rn)`` / ``disp(Rx,Rn)`` forms that ``is_dep_var_candidate``
    rejects (i.e. the pre-paren is NOT a named symbol).  ``FIELD(Rn)`` is NOT here —
    that already resolves as the named field."""
    parsed = _parse_indirect(operand)
    if parsed is None:
        return False
    pre, _index, base = parsed
    if base is None:
        return False
    # A named pre-paren (FIELD(Rn)) is handled directly by is_dep_var_candidate.
    if _is_named_symbol(pre):
        return False
    return True


def _strip_operand_comment(operand: str) -> str:
    """Strip a trailing inline comment from a blueprint operand.

    Blueprint flow args carry comment contamination for some instructions (e.g.
    ``LA R1,L'NAME(R1) BUMP WITH PSC VALUE  R073``).  HLASM operands never contain a
    space, so the first whitespace marks the comment boundary — take the first
    whitespace-delimited token (same contract as ``_parse_raw_operands``)."""
    raw = str(operand or "").strip()
    return raw.split()[0] if raw else ""


def _parse_indirect(operand: str) -> Optional[Tuple[str, Optional[str], Optional[str]]]:
    """Parse ``disp(Rn)`` / ``disp(Rx,Rn)`` → (pre_paren, index_reg, base_reg).

    Returns ``None`` when the operand is not a parenthesised base form.  ``base_reg``
    is the LAST paren component (the base register in ``d(X,B)``), ``index_reg`` the
    first when two are present.  Either may be ``None`` if not a register.
    """
    raw = _strip_operand_comment(operand)
    m = _INDIRECT_RE.match(raw)
    if not m:
        return None
    pre = m.group(1).strip()
    inner = m.group(2).strip()
    if not inner:
        return (pre, None, None)
    parts = [p.strip() for p in inner.split(",") if p.strip()]
    if len(parts) == 1:
        base = parts[0].upper()
        return (pre, None, base if looks_like_register_token(base) else None)
    # d(X,B): index = parts[0], base = parts[-1]
    idx = parts[0].upper()
    base = parts[-1].upper()
    return (
        pre,
        idx if looks_like_register_token(idx) else None,
        base if looks_like_register_token(base) else None,
    )


def _is_named_symbol(tok: str) -> bool:
    t = (tok or "").strip()
    if not t:
        return False
    if t.isdigit():
        return False
    if looks_like_register_token(t.upper()):
        return False
    return bool(re.match(r"^[A-Za-z@$_#]", t))


# --------------------------------------------------------------------------- #
# USING resolution
# --------------------------------------------------------------------------- #
def _parse_disp(pre: str) -> Optional[int]:
    """Parse the displacement from the pre-paren text (``0`` / ``4`` / empty=0)."""
    p = (pre or "").strip()
    if p == "":
        return 0
    if p.isdigit():
        return int(p)
    # hex X'..' or other forms: not a plain displacement we can offset-resolve.
    m = re.match(r"^(\d+)$", p)
    return int(m.group(1)) if m else None


def _nearest_active_usings(bp_data: Dict[str, Any], before_line: int) -> Dict[str, str]:
    """Nearest ``line_metadata[L].active_usings`` for the greatest L ≤ before_line.

    ``active_usings`` is sparse (only lines where USING state changes), so bisect to
    the closest preceding line.  Returns ``{REG: DSECT}`` (regs upper-cased)."""
    lm = bp_data.get("line_metadata") or {}
    if not isinstance(lm, dict) or before_line <= 0:
        return {}
    best_line = -1
    best: Dict[str, str] = {}
    for k, v in lm.items():
        try:
            ln = int(k)
        except (TypeError, ValueError):
            continue
        if ln > before_line or ln <= best_line:
            continue
        au = v.get("active_usings") if isinstance(v, dict) else None
        if isinstance(au, dict) and au:
            best_line = ln
            best = {str(rk).upper(): str(rv) for rk, rv in au.items()}
    return best


def _member_at_offset(bp_data: Dict[str, Any], dsect: str, offset: int) -> Optional[str]:
    """The DSECT member whose layout entry covers ``offset`` (offset ≤ off <
    offset+length); exact-offset start wins."""
    layouts = bp_data.get("dsect_layouts") or {}
    members = layouts.get(dsect) if isinstance(layouts, dict) else None
    if not isinstance(members, dict):
        return None
    exact: Optional[str] = None
    covering: Optional[str] = None
    for name, meta in members.items():
        if not isinstance(meta, dict):
            continue
        off = int(meta.get("offset") or 0)
        length = int(meta.get("length") or 0)
        if off == offset:
            exact = str(name)
        if length > 0 and off <= offset < off + length:
            covering = covering or str(name)
    return exact or covering


def _resolve_via_using(
    bp_data: Dict[str, Any], base_reg: str, pre: str, before_line: int
) -> Optional[str]:
    """If ``base_reg`` is a DSECT base in the active USING at ≤ before_line, resolve
    ``disp`` to the member at that offset.  Returns a named field or None."""
    usings = _nearest_active_usings(bp_data, before_line)
    dsect = usings.get(base_reg.upper())
    if not dsect:
        # also honour static USING base registers from meta.base_registers
        for br in (bp_data.get("meta") or {}).get("base_registers", []) or []:
            if str(br.get("reg") or "").upper() == base_reg.upper():
                dsect = str(br.get("target") or "")
                break
    if not dsect:
        return None
    disp = _parse_disp(pre)
    if disp is None:
        return None
    member = _member_at_offset(bp_data, dsect, disp)
    if member and is_dep_var_candidate(member):
        return normalize_token(member)
    return None


# --------------------------------------------------------------------------- #
# CFG-aware reaching-def (ported core, defects fixed)
# --------------------------------------------------------------------------- #
def _emit(results: List[str], raw_candidate: str) -> bool:
    """Route a candidate through is_dep_var_candidate; emit the normalized token if
    it survives.  Returns True if a (non-noise) named token was emitted.

    THIS is defect-fix #1: the original LA handler bypassed is_dep_var_candidate and
    leaked ``L'NAME`` length-attribute tokens.  Here ``L'LWRLS4CSCRES`` /
    ``0(R1)`` / a register / a literal are all dropped at the source."""
    candidate = _strip_operand_comment(raw_candidate)
    if is_dep_var_candidate(candidate):
        tok = normalize_token(candidate)
        if tok and tok not in results:
            results.append(tok)
            return True
    return False


def _backtrack_register(
    reg_name: str,
    start_block: str,
    before_line: Optional[int],
    block_map: Dict[str, Dict[str, Any]],
    cfg_incoming: Dict[str, List[Tuple[str, str]]],
    *,
    max_reg_hops: int = 3,
    max_block_depth: int = 5,
    max_levels: int = 16,
    _seen_regs: Optional[FrozenSet[str]] = None,
    _resolved: Optional[Set[str]] = None,
) -> Tuple[List[str], bool]:
    """Backward CFG register reaching-def.

    Returns ``(named_deps, found_def)``.  ``found_def`` is False when no defining
    instruction for ``reg_name`` was found within the bounds (→ caller-inherited /
    give-up).  Bounded by ``max_reg_hops`` (register recursion), ``max_block_depth``
    (BFS levels), ``max_levels`` (hard cap), and visited-block + seen-register cycle
    guards (determinism + no runaway on the J-loop case).
    """
    if max_reg_hops <= 0:
        return [], False
    reg_upper = str(reg_name or "").strip().upper()
    if not looks_like_register_token(reg_upper):
        return [], False
    seen_regs: FrozenSet[str] = (_seen_regs or frozenset()) | {reg_upper}

    results: List[str] = []
    found_any_def = False
    # Each queue item carries its OWN before_line bound (defect-fix #2): the start
    # block uses the call-site bound; predecessor blocks scan their whole body
    # (None) because control reached the start block from their end.
    bfs_queue: Deque[Tuple[str, Optional[int]]] = deque([(start_block, before_line)])
    visited_blocks: Set[str] = set()
    depth = 0
    levels_used = 0
    while bfs_queue and depth <= max_block_depth and levels_used < max_levels:
        next_level: List[Tuple[str, Optional[int]]] = []
        while bfs_queue:
            levels_used += 1
            if levels_used >= max_levels:
                break
            cur_bid, scan_before = bfs_queue.popleft()
            if cur_bid in visited_blocks:
                continue
            visited_blocks.add(cur_bid)
            block = block_map.get(cur_bid)
            if not block:
                continue
            flow = [
                e for e in iter_flow(block)
                if int(e.get("line") or 0) > 0
                and (scan_before is None or int(e.get("line") or 0) < scan_before)
            ]
            flow_desc = sorted(flow, key=lambda e: int(e.get("line") or 0), reverse=True)
            block_defines = False
            for entry in flow_desc:
                inst = str(entry.get("inst") or "").upper()
                e_args = [str(a) for a in (entry.get("args") or [])]
                e_line = int(entry.get("line") or 0)
                if not e_args or normalize_token(e_args[0]).upper() != reg_upper:
                    # not a (potential) definition of reg_upper in args[0] position;
                    # but multi-load / alloc / db-context define implicitly — handle below.
                    if not _defines_implicitly(inst, reg_upper):
                        continue

                # ---- memory→register value load (reused + ext): named field source ----
                if inst in REGISTER_LOAD_FROM_MEM or inst in REGISTER_LOAD_FROM_MEM_EXT:
                    src_idx = REGISTER_LOAD_FROM_MEM.get(inst,
                              REGISTER_LOAD_FROM_MEM_EXT.get(inst, 1))
                    if src_idx < len(e_args):
                        if _emit(results, e_args[src_idx]):
                            found_any_def = True
                    block_defines = True
                    found_any_def = True
                    break

                # ---- register→register copy: recurse the source register ----
                if inst in REGISTER_COPY_FROM_REG:
                    src_idx = REGISTER_COPY_FROM_REG[inst]
                    if src_idx < len(e_args):
                        src_reg = normalize_token(e_args[src_idx]).upper()
                        if src_reg and src_reg not in seen_regs and looks_like_register_token(src_reg):
                            child, child_found = _backtrack_register(
                                src_reg, cur_bid, e_line, block_map, cfg_incoming,
                                max_reg_hops=max_reg_hops - 1, max_block_depth=max_block_depth,
                                max_levels=max_levels, _seen_regs=seen_regs, _resolved=_resolved,
                            )
                            for d in child:
                                if d not in results:
                                    results.append(d)
                            found_any_def = found_any_def or child_found
                    block_defines = True
                    found_any_def = True
                    break

                # ---- load-address LA/LAY/LAE: NAMED address; self-mod keeps scanning ----
                if inst in REGISTER_LOAD_ADDRESS or inst in REGISTER_LOAD_ADDRESS_EXT:
                    addr_idx = REGISTER_LOAD_ADDRESS.get(inst,
                               REGISTER_LOAD_ADDRESS_EXT.get(inst, 1))
                    raw_addr = e_args[addr_idx] if addr_idx < len(e_args) else ""
                    parsed = _parse_indirect(raw_addr)
                    is_self_mod = False
                    if parsed is not None:
                        _pre, _idx, _base = parsed
                        # LA Rx, d(Rx): self-modification (displacement only) — the real
                        # load of Rx is earlier. Keep scanning; do NOT emit d(Rx).
                        if (_base and _base == reg_upper) or (_idx and _idx == reg_upper):
                            is_self_mod = True
                        elif _base and _base not in seen_regs and looks_like_register_token(_base):
                            child, child_found = _backtrack_register(
                                _base, cur_bid, e_line, block_map, cfg_incoming,
                                max_reg_hops=max_reg_hops - 1, max_block_depth=max_block_depth,
                                max_levels=max_levels, _seen_regs=seen_regs, _resolved=_resolved,
                            )
                            for d in child:
                                if d not in results:
                                    results.append(d)
                            found_any_def = found_any_def or child_found
                    # Emit the named symbol (filtered): L'NAME(Rx) / d(Rx) / a register
                    # are all dropped by is_dep_var_candidate (defect-fix #1).
                    if _emit(results, raw_addr):
                        found_any_def = True
                    if not is_self_mod:
                        block_defines = True
                        found_any_def = True
                        break
                    # self-mod: fall through, keep scanning earlier entries.
                    continue

                # ---- PC-relative load-address / load (LARL / LRL): label IS the symbol ----
                if inst in PC_RELATIVE_LOAD_ADDRESS:
                    idx = PC_RELATIVE_LOAD_ADDRESS[inst]
                    if idx < len(e_args) and _emit(results, e_args[idx]):
                        found_any_def = True
                    block_defines = True
                    found_any_def = True
                    break

                # ---- load-multiple LM/LMG/LMY: save-area memory operand is the source ----
                if inst in REGISTER_MULTI_LOAD:
                    idx = REGISTER_MULTI_LOAD[inst]
                    if idx < len(e_args) and _emit(results, e_args[idx]):
                        found_any_def = True
                    block_defines = True
                    found_any_def = True
                    break

                # ---- immediate load: terminal constant, no data dependency ----
                if inst in IMMEDIATE_LOAD_INST:
                    block_defines = True
                    found_any_def = True
                    break

                # ---- alloc macro implicit producer (GETCC/…): emit CE1CRn field ----
                if inst in ALLOC_RESULT_REG and ALLOC_RESULT_REG[inst] == reg_upper:
                    if inst == "CALOC":
                        synthetic = f"alloc@heap:{e_line}" if e_line else "alloc@heap"
                        if synthetic not in results:
                            results.append(synthetic)
                    else:
                        alloc_args = [str(a).strip().upper() for a in e_args]
                        level_key: Optional[str] = alloc_args[0] if alloc_args else None
                        if level_key and not LEVEL_TO_CE1CR.get(level_key):
                            for a in alloc_args:
                                if a.startswith("LEVEL="):
                                    level_key = a[len("LEVEL="):]
                                    break
                        ce1cr = LEVEL_TO_CE1CR.get(level_key or "")
                        if ce1cr and ce1cr not in results:
                            results.append(ce1cr)
                    block_defines = True
                    found_any_def = True
                    break

                # ---- DB context implicit producer (DBOPN/…): synthetic terminal field ----
                if inst in DB_CONTEXT_REG and DB_CONTEXT_REG[inst] == reg_upper:
                    synthetic = f"DB_CONTEXT_{inst}"
                    if synthetic not in results:
                        results.append(synthetic)
                    block_defines = True
                    found_any_def = True
                    break

                # ---- in-place arithmetic on reg_upper: keep scanning (don't stop) ----
                if inst in ADDRESS_ARITH_INPLACE:
                    continue

                # ---- call-return re-root: a call whose return register is reg_upper ----
                # ENTRC/BAS etc. return into R15 (or R14/R0/R1 per linkage); when no
                # later store redefines reg_upper, the register's value is the call's
                # OUTPUT (return_register pattern). We can't name the field locally →
                # emit a synthetic re-root marker (sound, not a guess).
                if (inst in SUBROUTINE_INST or inst in CROSS_FILE_CALL_OPCODES) \
                        and reg_upper in {"R0", "R1", "R14", "R15"}:
                    synthetic = f"call_return@{reg_upper}:{e_line}" if e_line \
                        else f"call_return@{reg_upper}"
                    if synthetic not in results:
                        results.append(synthetic)
                    block_defines = True
                    found_any_def = True
                    break

            if not block_defines:
                for pred in cfg_incoming.get(cur_bid, []):
                    src_bid = pred[0] if isinstance(pred, (tuple, list)) else pred
                    edge_type = pred[1] if isinstance(pred, (tuple, list)) and len(pred) > 1 else "BRANCH"
                    if edge_type in {"BRANCH", "FALLTHROUGH"} and str(src_bid) not in visited_blocks:
                        # defect-fix #2: predecessor scans its WHOLE body (None) — control
                        # entered our block from the predecessor's end.
                        next_level.append((str(src_bid), None))
        bfs_queue = deque(next_level)
        depth += 1
    return results, found_any_def


def _defines_implicitly(inst: str, reg_upper: str) -> bool:
    """Whether ``inst`` defines ``reg_upper`` implicitly (alloc / db-context / call-
    return / load-multiple), independent of args[0]."""
    if inst in ALLOC_RESULT_REG and ALLOC_RESULT_REG[inst] == reg_upper:
        return True
    if inst in DB_CONTEXT_REG and DB_CONTEXT_REG[inst] == reg_upper:
        return True
    if (inst in SUBROUTINE_INST or inst in CROSS_FILE_CALL_OPCODES) \
            and reg_upper in {"R0", "R1", "R14", "R15"}:
        return True
    return False


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #
def resolve_register_indirect(
    operand: str,
    *,
    stem: str,
    block_id: str,
    before_line: int,
    bp_data: Dict[str, Any],
    bp_path: str,
    asm_dir: Any = None,
    route_engine_or_none: Any = None,
    max_block_depth: int = 5,
    max_reg_hops: int = 3,
    max_levels: int = 16,
) -> ResolvedIndirect:
    """Resolve a register-indirect setter source operand to named field(s).

    See the module docstring for the full algorithm + soundness contract.
    """
    parsed = _parse_indirect(operand)
    if parsed is None:
        return ResolvedIndirect(kind="unresolved")
    pre, _index, base = parsed

    # 1) NAMED-prefix form FIELD(Rn) → the field is the dep (already a candidate).
    if _is_named_symbol(pre) and is_dep_var_candidate(operand):
        return ResolvedIndirect(named_deps=[normalize_token(operand)], kind="named_prefix")

    if base is None:
        # no resolvable base register (e.g. "(R13)" with R13 a register but pre empty
        # and no index) — still try base, else give up with an envelope.
        return ResolvedIndirect(
            kind="unresolved",
            unresolved_envelope=envelope_from_fields(is_indirect=True, indirect_via=None),
        )

    # 2) USING-first: nearest active USING ≤ before_line; Rn a DSECT base → member.
    using_field = _resolve_via_using(bp_data, base, pre, before_line)
    if using_field:
        return ResolvedIndirect(named_deps=[using_field], kind="using", base_register=base)

    # 3) CFG-aware reaching-def on the base register.
    try:
        block_map, _cfg_out, cfg_incoming = _get_file_cfg_maps(bp_path)
    except Exception:
        block_map, cfg_incoming = (
            {str(b.get("id") or ""): b for b in (bp_data.get("blocks") or [])},
            {},
        )
    if block_id not in block_map:
        # fall back to building block_map directly if the cached id doesn't line up
        block_map = {str(b.get("id") or ""): b for b in (bp_data.get("blocks") or [])}

    named, found = _backtrack_register(
        base, block_id, before_line, block_map, cfg_incoming,
        max_reg_hops=max_reg_hops, max_block_depth=max_block_depth, max_levels=max_levels,
    )
    # split off the synthetic markers (alloc@ / DB_CONTEXT_ / call_return@) — they are
    # implicit terminal sources, kept as deps but they are not "named fields".
    real_named = [n for n in named if not _is_synthetic(n)]
    synthetic = [n for n in named if _is_synthetic(n)]

    if real_named or synthetic:
        kind = "reaching_def" if real_named else "implicit"
        return ResolvedIndirect(named_deps=real_named + synthetic, kind=kind, base_register=base)

    # A defining instruction WAS found but it carries no data dependency (immediate
    # load → constant address): terminal & sound. No dep, no give-up envelope.
    if found:
        return ResolvedIndirect(named_deps=[], kind="constant", base_register=base)

    # SOUNDNESS: nothing found within bounds, OR Rn caller-inherited (no def) →
    # give up with an indirection envelope; never guess a field.
    return ResolvedIndirect(
        kind="unresolved",
        base_register=base,
        unresolved_envelope=envelope_from_fields(is_indirect=True, indirect_via=base),
    )


def _is_synthetic(tok: str) -> bool:
    return tok.startswith("alloc@") or tok.startswith("DB_CONTEXT_") or tok.startswith("call_return@")


def resolve_indirect_dest_writes(
    bp_data: Dict[str, Any], bp_path: str, stem: str, *,
    asm_dir: Any = None, route_engine: Any = None,
) -> List[Tuple[str, int, str, str, Optional[str]]]:
    """Resolve every SETTER_INST whose DESTINATION operand is register-indirect.

    The MIRROR of the register-indirect SOURCE resolution above, applied at the setter-
    DISCOVERY layer.  A write like ``MVC 0(R1),SRC`` / ``ST R,d(Rn)`` / ``OI d(Rn),mask``
    stores into the field ``Rn`` points at, but the destination operand is a
    ``disp(Rn)`` form that does NOT name the field — so the reused name-matching setter
    finder is blind to it and the write is invisible to backward search.  Here we take
    each SETTER_INST's destination (by ``DEST_ARG_INDEX_BY_INST``), and when it is
    register-indirect resolve it through the SAME ``resolve_register_indirect`` (USING
    context → CFG reaching-def) to the named field(s) it writes.

    Returns ``(field, line, block_id, instruction, source_operand)`` rows — one per
    resolved field (OR alternatives kept).  SOUND: a dest that does not resolve to a
    named field yields NO row (give up, never guess); synthetic producers
    (``alloc@`` / ``DB_CONTEXT_`` / ``call_return@``) are not named fields and are skipped.
    Bounded + deterministic (each resolution is the bounded backward register walk)."""
    out: List[Tuple[str, int, str, str, Optional[str]]] = []
    _src: Dict[str, Optional[List[str]]] = {"lines": None}

    def _source_lines() -> List[str]:
        # lazily read once; the raw fallback is needed because some SETTER_INST (notably
        # MVC) leave the columnar ``flow["a"]`` EMPTY in this parser's blueprints, so the
        # register-indirect dest is only visible in the raw source line.
        if _src["lines"] is None:
            _src["lines"] = []
            if asm_dir:
                # ZERO-FS: serve from the index.db source override when installed (load-only), else
                # read the file. Same utf-8/replace decode + splitlines ⇒ byte-identical. (Was a
                # direct read_text — the one trace-path .asm read that bypassed the override.)
                from backward_traversal.utils.blueprint_utils import source_override_bytes
                _p = Path(asm_dir) / f"{stem}.asm"
                _ov = source_override_bytes(_p)
                if _ov is not None:
                    _src["lines"] = _ov.decode("utf-8", "replace").splitlines()
                else:
                    try:
                        _src["lines"] = _p.read_text(
                            encoding="utf-8", errors="replace").splitlines()
                    except OSError:
                        _src["lines"] = []
        return _src["lines"]

    for block in (bp_data.get("blocks") or []):
        bid = str(block.get("id") or "")
        for e in iter_flow(block):
            inst = str(e.get("inst") or "").upper()
            if inst not in SETTER_INST:
                continue
            ops = [str(a) for a in (e.get("args") or [])]
            di = DEST_ARG_INDEX_BY_INST.get(inst, 0)
            line = int(e.get("line") or 0)
            if di >= len(ops):
                # empty/insufficient columnar args (e.g. MVC) — recover the operands from
                # the raw source line with the proven paren-aware parser.
                lines = _source_lines()
                if not (0 < line <= len(lines)):
                    continue
                ops = _parse_raw_operands(lines[line - 1], inst) or []
                if di >= len(ops):
                    continue
            dest = ops[di]
            if not is_register_indirect(dest):
                continue
            try:
                res = resolve_register_indirect(
                    dest, stem=stem, block_id=bid, before_line=line,
                    bp_data=bp_data, bp_path=str(bp_path), asm_dir=asm_dir,
                    route_engine_or_none=route_engine)
            except Exception:
                continue
            # the SOURCE = the operand(s) other than the destination (what is written).
            src = ", ".join(o for j, o in enumerate(ops) if j != di).strip() or None
            for field in res.named_deps:
                if _is_synthetic(field):
                    continue
                f = normalize_token(field)
                if f:
                    out.append((f, line, bid, inst, src))
    return out


__all__ = (
    "ResolvedIndirect",
    "resolve_register_indirect",
    "resolve_indirect_dest_writes",
    "is_register_indirect",
)
