#!/usr/bin/env python3
"""find_cpp_chain.py  —  deterministic ASM<->C++ variable resolver that walks the
3-layer machine-generated-header chain:

    cc<a>.hpp (app struct, hand-written, semantic names)
        |  Link B : byte-offset layout alignment (C++<->C++, both pack(1))
        v
    <a>.hpp   (casuav gen struct, machine-generated, EXACT ASM names, fully sized)
        |  Link A : lowercase-identity (gen_name == asm_field.lower(), strip &A)
        v
    <a>.mac   (ASM DSECT)

Link A is essentially exact (the gen header literally re-emits each DSECT label,
lowercased, with the `&A` suffix stripped). Link B uses the gen layout as the
authoritative byte reference (the gen side is fully typed -> exact sizes), flattens
both C++ structs to primitive leaves with byte offsets, and maps each cc-hpp leaf to
the gen leaf(s) covering the same byte range. Because the gen side is exact, the
size of any cc-hpp external typedef / enum (Pa::Referral, HsmKey, ...) is INFERRED
from the gen field at that offset rather than guessed (no `::`=1, `long`=8 hacks).

Usage:
    python3 find_cpp_chain.py <NAME> <a>.mac
        [--gen <a>.hpp] [--cc cc<a>.hpp] [--struct <AppStructName>]

    NAME may be an ASM DSECT field (LWRPOSFCRDV) OR an app C++ member (softCardValue).

Examples:
    python3 find_cpp_chain.py LWRPOSFCRDV lwrpo.mac
    python3 find_cpp_chain.py softCardValue lwrpo.mac
    python3 find_cpp_chain.py LWRPA_HSMKEY lwrpo.mac
"""
import os
import re
import sys
import argparse

# ======================================================================
# Layer 3: ASM DSECT (.mac) parser  -- reused from find_cpp_for_asm.py
# ======================================================================
DEF = {"F": 4, "H": 2, "D": 8, "E": 4, "L": 16, "A": 4, "Y": 2,
       "S": 2, "V": 4, "B": 1, "C": 1, "X": 1, "P": 1}


def ds_size(op):
    m = re.match(r"^(\d*)([A-Z])(?:L(\d+))?", op.strip())
    if not m:
        return None
    dup = int(m.group(1)) if m.group(1) != "" else 1
    ln = int(m.group(3)) if m.group(3) else DEF.get(m.group(2), 1)
    return dup * ln, (dup == 0)          # (bytes, is_group_header)


def strip_suffix(name):
    return re.sub(r"&\w+$", "", name)    # LWRPOSFCRDV&A -> LWRPOSFCRDV


def parse_mac(path):
    """Ordered DSECT fields {name, off, size, op, region}. A 0XLn group header
    (dup==0) carries size 0 and bumps the region id (used only for context)."""
    fields, off, indsect, region = [], 0, False, 0
    for line in open(path, errors="replace"):
        raw = line.rstrip("\n")
        if raw.lstrip().startswith("*"):
            continue
        if re.match(r"^\S+\s+DSECT", raw):
            indsect = True
            continue
        if not indsect:
            continue
        if re.match(r"^\$|\s+CSECT", raw):
            break
        m = re.match(r"^([#A-Za-z][\w$#]*?)(?:&\w+)?\s+(DS|EQU)\s+(\S+)", raw)
        if not m:
            continue
        name, kind, op = strip_suffix(m.group(1)), m.group(2), m.group(3)
        if kind == "EQU":
            continue
        sz = ds_size(op)
        if not sz:
            continue
        size, grp = sz
        if not grp:
            fields.append({"name": name, "off": off, "size": size,
                           "op": op, "region": region})
            off += size
        else:
            region += 1
            fields.append({"name": name, "off": off, "size": 0, "op": op,
                           "group": True, "region": region})
    return fields


# ======================================================================
# Layer 2: machine-generated gen header (<a>.hpp, namespace casuav) parser
# ======================================================================
# Fully, exactly typed.  Type width comes from the name (be=bigendian, _z=plain):
#   beuint8_z/uint8_t          = 1     beuint16_z = 2
#   beuint32_z                 = 4     beuint64_z = 8
#   ebcdic_t<N> / num_ebcdic_t<N> = N  packed_t<N> / packed_t<N,S> = N
# union {...}  -> all members share offset, size = max(member sizes)
# struct{...}  -> sum; bitfields collapse to ceil(bits/8) of their integer base.
_GEN_PRIM = {
    "beuint8_z": 1, "beuint16_z": 2, "beuint32_z": 4, "beuint64_z": 8,
    "uint8_t": 1, "uint16_t": 2, "uint32_t": 4, "uint64_t": 8,
    "int8_t": 1, "int16_t": 2, "int32_t": 4, "int64_t": 8,
    "echar": 1, "char": 1,        # single EBCDIC / plain char
}


def gen_prim_size(t):
    """Exact byte size of a gen-hpp primitive type token, or None if unknown."""
    t = t.strip()
    if t in _GEN_PRIM:
        return _GEN_PRIM[t]
    # templated bigendian integer: be[u]intW_t<N>  ->  W/8 bytes, N elements.
    # (W = bit width in the name; <N> = array element count, e.g.
    #  beuint64_t<2> = 16B, beint32_t<6> = 24B.) NOTE: the <N>=count reading is
    #  inferred from the naming convention; no .mac was available to ground-truth
    #  lwrcw, so treat sizes of these specific fields as best-effort, not exact.
    m = re.match(r"be(?:u)?int(8|16|32|64)_t\s*<\s*(\d+)\s*>", t)
    if m:
        return (int(m.group(1)) // 8) * int(m.group(2))
    m = re.match(r"(?:num_)?ebcdic_t\s*<\s*(\d+)\s*>", t)
    if m:
        return int(m.group(1))
    m = re.match(r"packed_t\s*<\s*(\d+)\s*(?:,\s*\d+\s*)?>", t)
    if m:
        # packed decimal: <N> is the digit count, stored 2 digits/byte + sign
        # nibble  ->  ceil((N+1)/2) bytes  (matches ASM PLn byte count, verified
        # against lwrpo: packed_t<5>=PL3=3B, packed_t<7>=PL4=4B, packed_t<3>=PL2=2B)
        n = int(m.group(1))
        return (n + 1 + 1) // 2
    # plain C primitives, just in case a gen header mixes them in
    base = t.replace("unsigned", "").replace("signed", "").strip()
    if base.startswith("long"):
        return 8
    if base.startswith("short"):
        return 2
    if base.startswith("int"):
        return 4
    if base.startswith("char"):
        return 1
    return None


def _gen_tokenize(path):
    """Yield structural events from the gen hpp, ignoring # lines, namespace,
    and comments.  Events: ('open', kind, instname_or_None) on `{`, ('close',)
    on `}`, ('field', type, name, arr, bits) for a member declaration."""
    text = open(path, errors="replace").read()
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)   # block comments
    events = []
    pending_kind = None           # 'struct' / 'union' awaiting its '{'
    for raw in text.splitlines():
        line = raw.split("//")[0]
        if line.lstrip().startswith("#"):
            continue
        # strip a leading `namespace casuav` so its brace is treated as a plain
        # scope (we'll skip top-level scopes that hold no fields anyway)
        # detect struct/union keyword introducing the next brace
        km = re.search(r"\b(struct|union)\b", line)
        if km and "{" not in line[:km.start()]:
            pending_kind = km.group(1)
        i = 0
        while i < len(line):
            ch = line[i]
            if ch == "{":
                events.append(("open", pending_kind or "scope", None))
                pending_kind = None
                i += 1
                continue
            if ch == "}":
                # capture optional `instname;` after the brace
                rest = line[i + 1:]
                m = re.match(r"\s*([A-Za-z_]\w*)?\s*;", rest)
                inst = m.group(1) if m else None
                events.append(("close", inst))
                if m:
                    i += 1 + m.end()
                else:
                    i += 1
                continue
            i += 1
        # field declarations (must be a full statement on the line)
        code = line
        if "{" in code or "}" in code:
            continue
        bm = re.match(r"\s*([A-Za-z_][\w:]*)\s+\w+\s*:\s*(\d+)\s*;", code)
        if bm:
            events.append(("bits", bm.group(1), int(bm.group(2))))
            continue
        fm = re.match(
            r"\s*([A-Za-z_][\w:]*\s*(?:<\s*\d+\s*(?:,\s*\d+\s*)?>)?)"
            r"\s+([A-Za-z_]\w*)\s*(?:\[\s*(\d+)\s*\])?\s*;", code)
        if fm:
            arr = int(fm.group(3)) if fm.group(3) else 1
            events.append(("field", fm.group(1).strip(), fm.group(2), arr, 0))
    return events


def parse_gen(path):
    """Flatten the gen struct to ordered leaves with EXACT byte offsets.
    leaf: {name, type, off, size}.  union -> members overlay (same offset),
    union size = max member size.  Returns (struct_name, leaves)."""

    class Node:
        __slots__ = ("kind", "children", "bits_base", "bits")

        def __init__(self, kind):
            self.kind = kind          # 'struct' | 'union' | 'scope'
            self.children = []        # list of ('leaf', dict) | ('node', Node)
            self.bits = 0

    events = _gen_tokenize(path)
    root = Node("scope")
    stack = [root]
    struct_name = None
    # we also want the casuav struct's declared name; grab first `struct NAME {`
    name_text = open(path, errors="replace").read()
    nm = re.search(r"struct\s+([A-Za-z_]\w*)\s*\{", name_text)
    if nm:
        struct_name = nm.group(1)

    for ev in events:
        if ev[0] == "open":
            node = Node(ev[1])
            stack[-1].children.append(("node", node))
            stack.append(node)
        elif ev[0] == "close":
            if len(stack) > 1:
                stack.pop()
        elif ev[0] == "field":
            _, t, name, arr, _ = ev
            stack[-1].children.append(
                ("leaf", {"type": t, "name": name, "arr": arr}))
        elif ev[0] == "bits":
            stack[-1].bits += ev[2]

    def size_of(node):
        if node.kind == "union":
            best = 0
            for kind, c in node.children:
                if kind == "leaf":
                    s = (gen_prim_size(c["type"]) or 1) * c["arr"]
                else:
                    s = size_of(c)
                best = max(best, s)
            return best
        total = 0
        for kind, c in node.children:
            if kind == "leaf":
                total += (gen_prim_size(c["type"]) or 1) * c["arr"]
            else:
                total += size_of(c)
        if node.bits:
            total += (node.bits + 7) // 8
        return total

    leaves = []

    def emit(node, base):
        """Append primitive leaves; return bytes consumed from `base`."""
        if node.kind == "union":
            # every member starts at `base`; keep ONE flattened representative
            # (the largest member) so offsets downstream stay exact, but record
            # ALL leaf names at their overlaid offsets for name lookup.
            members = []
            for kind, c in node.children:
                members.append((kind, c))
            # emit the widest member's leaves for layout; for the others, emit
            # their leaves too (same base) so a name in any union arm resolves.
            sizes = []
            for kind, c in members:
                if kind == "leaf":
                    sizes.append((gen_prim_size(c["type"]) or 1) * c["arr"])
                else:
                    sizes.append(size_of(c))
            usize = max(sizes) if sizes else 0
            for kind, c in members:
                if kind == "leaf":
                    s = (gen_prim_size(c["type"]) or 1) * c["arr"]
                    leaves.append({"name": c["name"], "type": c["type"],
                                   "off": base, "size": s, "union": True})
                else:
                    emit(c, base)
            return usize
        cur = base
        for kind, c in node.children:
            if kind == "leaf":
                s = (gen_prim_size(c["type"]) or 1) * c["arr"]
                leaves.append({"name": c["name"], "type": c["type"],
                               "off": cur, "size": s})
                cur += s
            else:
                cur += emit(c, cur)
        if node.bits:
            nb = (node.bits + 7) // 8
            leaves.append({"name": "<bits>", "type": "bitfield",
                           "off": cur, "size": nb})
            cur += nb
        return cur - base

    # the real struct is the first 'struct' node under root (possibly nested in
    # the namespace scope). Find the deepest single struct that contains fields.
    def find_struct(node):
        for kind, c in node.children:
            if kind == "node" and c.kind == "struct":
                return c
        for kind, c in node.children:
            if kind == "node":
                r = find_struct(c)
                if r:
                    return r
        return None

    top = find_struct(root)
    if top is None:
        raise ValueError(f"no struct found in gen header {path}")
    emit(top, 0)
    leaves.sort(key=lambda x: (x["off"], 0 if x.get("union") else 1))
    return struct_name, leaves


# ======================================================================
# Layer 1: application cc header (cc<a>.hpp) parser
#   reused recursive flattener from find_cpp_for_asm.py, but external types
#   stay 'elastic' (unknown size) until inferred from the gen layout.
# ======================================================================
def cc_prim_size(t):
    t = t.replace("unsigned", "").replace("signed", "").strip()
    if t.startswith("long long"):
        return 8
    if t.startswith("long"):
        return 8
    if t.startswith("short"):
        return 2
    if t.startswith("int"):
        return 4
    if t.startswith("char"):
        return 1
    return None


# ----------------------------------------------------------------------
# I1: bounded, cycle-safe #include following (within the codebase dir only)
# ----------------------------------------------------------------------
# A cc/gen header references struct/typedef names that are defined in OTHER
# headers it #includes (cclwrpo.hpp -> pauth.hpp/cidret.hpp/paind.hpp;
# cclwrdx.hpp -> 10 headers). When such an included header is present in the
# SAME source directory, we follow it (transitively) and merge the struct
# definitions it declares into the parsing registry, so a cc field whose
# struct lives in an included header flattens into real primitive leaves
# instead of collapsing to a single 'elastic' (unknown-size) leaf.
#
# Bounds: we only follow includes whose basename resolves to a file in the
# SAME directory as the parsed header (never the system / out-of-tree paths),
# we track visited absolute paths so cycles terminate, and we cap the include
# depth so a pathological graph can't blow up.
_INCLUDE_RE = re.compile(r'^\s*#\s*include\s*[<"]([^>"]+)[">]')
_INCLUDE_MAX_DEPTH = 8


def _included_paths(text, base_dir):
    """Yield absolute paths of #included headers that exist in ``base_dir``.

    Only the include's basename is honoured (the corpus uses bare names like
    <pauth.hpp>); anything that does not resolve to a real file in base_dir is
    skipped, so include-following can never escape the codebase directory."""
    if base_dir is None:
        return
    for raw in text.splitlines():
        m = _INCLUDE_RE.match(raw)
        if not m:
            continue
        cand = os.path.join(base_dir, os.path.basename(m.group(1)))
        if os.path.isfile(cand):
            yield os.path.abspath(cand)


def _collect_included_structs(path, base_dir, _seen=None, _depth=0):
    """Transitively parse every in-dir #included header reachable from ``path``
    and return a merged {struct_name: struct_node} registry of their structs.

    Cycle-safe (visited set on absolute paths) and depth-bounded. The registry
    is keyed by struct name; first definition wins (the nearest include)."""
    if base_dir is None or _depth > _INCLUDE_MAX_DEPTH:
        return {}
    if _seen is None:
        _seen = set()
    try:
        text = open(path, errors="replace").read()
    except OSError:
        return {}
    merged = {}
    for inc in _included_paths(text, base_dir):
        if inc in _seen:
            continue
        _seen.add(inc)
        try:
            inc_lines = open(inc, errors="replace").read().splitlines()
        except OSError:
            continue
        # parse the included header's own structs (no extern merge — we recurse
        # explicitly below so the visited set is shared and cycles terminate)
        inc_reg, _ = _build_tree(inc_lines, extern_reg=None)
        for nm, node in inc_reg.items():
            merged.setdefault(nm, node)
        # follow the included header's OWN includes (transitive)
        for nm, node in _collect_included_structs(
                inc, base_dir, _seen, _depth + 1).items():
            merged.setdefault(nm, node)
    return merged


def _build_tree(lines, extern_reg=None):
    stack = [{"children": []}]
    pending = None
    for ln in lines:
        code = ln.split("//")[0]
        comment = ln[len(code):].lstrip("/ ").strip()
        code = re.sub(r"/\*.*?\*/", "", code)
        sm = re.search(r"\bstruct\s+([A-Za-z_]\w*)", code)
        if sm:
            pending = sm.group(1)
        _TYPE = (r"(?:unsigned\s+|signed\s+)?"
                 r"(?:long\s+long\s+int|long\s+long|long|short\s+int|short|int|char)"
                 r"|[A-Za-z_][\w:<>,]*")
        lm = re.match(rf"\s*({_TYPE})\s+([A-Za-z_]\w*)\s*(?:\[(\d+)\])?\s*;", code)
        if lm and "struct" not in code and not re.search(r":\s*\d+", code) \
           and lm.group(1) not in ("return", "else", "public", "private"):
            stack[-1]["children"].append(
                {"kind": "leaf", "type": lm.group(1).strip(),
                 "name": lm.group(2),
                 "arr": int(lm.group(3)) if lm.group(3) else 1,
                 "comment": comment})
        bm = re.match(r"\s*(?:unsigned\s+int|int)\s+\w+\s*:\s*(\d+)", code)
        if bm:
            stack[-1].setdefault("bits", 0)
            stack[-1]["bits"] += int(bm.group(1))
        i = 0
        while i < len(code):
            ch = code[i]
            if ch == "{":
                node = {"kind": "struct", "name": pending, "instname": None,
                        "arr": 1, "children": []}
                stack[-1]["children"].append(node)
                stack.append(node)
                pending = None
            elif ch == "}":
                # GUARDED POP (robustness): only close a scope we actually opened.
                # A line-oriented brace scan can underflow on preprocessor blocks
                # (`#if 0 … #endif`), `extern "C" { … }`, or braces pulled in via an
                # #include merge — a stray `}` then popped the root and the next `{`
                # hit `stack[-1]` on an empty stack → IndexError (crashed parse_cc on
                # cclwrcw/cclwrdx/cclwrwr/cccr21ae). Mirror parse_gen's guarded pop:
                # skip the stray brace and keep the partial-but-usable tree, so the
                # fields already collected stay resolvable instead of the whole
                # header failing.
                if len(stack) > 1:
                    node = stack.pop()
                    m2 = re.match(r"\s*([A-Za-z_]\w*)?\s*(?:\[(\d+)\])?\s*;", code[i + 1:])
                    if m2:
                        if m2.group(1):
                            node["instname"] = m2.group(1)
                            node["name"] = node["name"] or m2.group(1)
                        if m2.group(2):
                            node["arr"] = int(m2.group(2))
                        i += m2.end()
            i += 1
    reg = {}

    def walk(n):
        for c in n.get("children", []):
            if c.get("kind") == "struct":
                if c.get("name"):
                    reg.setdefault(c["name"], c)
                walk(c)
    walk(stack[0])
    # I1: types defined in #included headers (in-dir, transitive) become
    # resolvable. In-file definitions take precedence (setdefault below only
    # fills names this header did not define itself).
    if extern_reg:
        for nm, node in extern_reg.items():
            reg.setdefault(nm, node)
    return reg, stack[0]["children"]


def _flatten(node, reg, path=""):
    if node["kind"] == "struct":
        nm = node.get("instname") or ""
        p = (path + "/" + nm).strip("/") if nm else path
        sub = []
        for c in node["children"]:
            sub += _flatten(c, reg, p)
        if node.get("bits"):
            sub.append({"path": p, "name": "<bits>", "type": "bitfield",
                        "size": (node["bits"] + 7) // 8, "elastic": False})
        return sub * node.get("arr", 1)
    t = node["type"]
    k = node.get("arr", 1)
    nm = node["name"]
    cm = node.get("comment", "")

    def mk(e, elastic=False):
        leaf = {"path": path, "name": nm, "type": t, "size": e * k,
                "elastic": elastic, "comment": cm}
        if k > 1:
            leaf["elem"] = e
            leaf["count"] = k
        return [leaf]
    ps = cc_prim_size(t)
    if ps is not None:
        return mk(ps)
    if t in reg:                                    # inline in-file struct
        inl = []
        for c in reg[t]["children"]:
            inl += _flatten(c, reg, path)
        if reg[t].get("bits"):
            inl.append({"path": path, "name": "<bits>", "type": "bitfield",
                        "size": (reg[t]["bits"] + 7) // 8, "elastic": False,
                        "comment": cm})
        return inl * k
    # external typedef / enum (Pa::Referral, HsmKey, ...): size unknown -> elastic
    return mk(1, elastic=True)


def parse_cc(path, struct=None, follow_includes=True):
    """Return (struct_name, leaves[]) with provisional offsets (elastic=1).

    ``follow_includes`` (I1): when True, struct/type definitions in headers this
    cc header #includes (within the same directory, transitively) are merged into
    the parse registry so fields whose struct lives in an included header resolve
    to real leaves instead of one elastic leaf."""
    lines = open(path, errors="replace").read().splitlines()
    extern_reg = None
    if follow_includes:
        base_dir = os.path.dirname(os.path.abspath(path))
        extern_reg = _collect_included_structs(path, base_dir)
    reg, roots = _build_tree(lines, extern_reg=extern_reg)
    cand = {c.get("name"): c for c in roots
            if c.get("kind") == "struct" and c.get("name")}
    if not cand:
        raise ValueError(f"no named top-level struct found in {path}")
    if struct and struct in cand:
        top = cand[struct]
    else:
        top = max(cand.values(), key=lambda n: len(_flatten(n, reg)))
    leaves = _flatten(top, reg)
    off = 0
    for lf in leaves:
        lf["off"] = off
        off += lf["size"]
    return top.get("name"), leaves


# ======================================================================
# Link A:  gen leaf  <->  ASM field   (lowercase identity, EXACT)
# ======================================================================
def link_a(gen_leaves, asm_fields):
    """Map gen-leaf-name -> asm-field by `gen == asm.lower()`. Returns
    (gen_by_name, asm_by_lower, pairs) where pairs is gen_name -> asm field."""
    asm_by_lower = {}
    for f in asm_fields:
        asm_by_lower.setdefault(f["name"].lower(), f)
    pairs = {}
    for lf in gen_leaves:
        nm = lf["name"].lower()
        if nm in asm_by_lower:
            pairs[lf["name"]] = asm_by_lower[nm]
    return asm_by_lower, pairs


def link_a_coverage(gen_leaves, asm_fields):
    """% of DSECT (non-group) fields present as lowercased gen identifiers."""
    gen_names = {lf["name"].lower() for lf in gen_leaves}
    real = [f for f in asm_fields if not f.get("group")]
    hit = sum(1 for f in real if f["name"].lower() in gen_names)
    return hit, len(real)


# ======================================================================
# I2: comment-anchor map  (cc field  <->  ASM name carried in its // comment)
# ======================================================================
# The app header cc<name>.hpp carries each field's ASM source name DIRECTLY in
# a trailing comment, e.g.  `char redYellowGreen;  // LWRPORGY   //R028`  and,
# in some headers, lowercase:  `OnlineSourceInd onlineSrcInd;  // lg1osi`.
# These comments are GROUND TRUTH (hand-maintained alongside the DSECT). We mine
# them CASE-INSENSITIVELY (the original find_cpp_for_asm regex was uppercase-only,
# missing lowercase `// lg1osi` headers) and validate each candidate token
# against the real DSECT field names so revision tags (R028, R046, ...) and other
# prose tokens are rejected — only tokens that name an actual ASM field survive.
#
# Token shape: an identifier of length>=4 that may mix case and may contain the
# HLASM-legal punctuation @ # $ _ and digits. Validation against `asm_by_lower`
# (DSECT field names, lowercased) is what makes it precise without hardcoding.
_COMMENT_TOK_RE = re.compile(r"[A-Za-z][A-Za-z0-9_@#$]{3,}")


def build_comment_map(cc_leaves, asm_by_lower):
    """Bidirectional ASM-name <-> cc-field map mined from the cc fields' trailing
    comments, validated against real DSECT field names (``asm_by_lower``).

    Returns ``(by_asm_lower, by_cpp_lower)`` where::

        by_asm_lower[asm_name.lower()] = [cc_leaf_index, ...]
        by_cpp_lower[cc_tail.lower()]  = [asm_field_name, ...]

    A cc leaf is anchored to the FIRST comment token that names a real DSECT
    field. Case-insensitive throughout so both `// LWRPORGY` and `// lg1osi`
    resolve."""
    by_asm = {}
    by_cpp = {}
    for ci, lf in enumerate(cc_leaves):
        if lf.get("name") == "<bits>":
            continue
        comment = lf.get("comment", "")
        for tok in _COMMENT_TOK_RE.findall(comment):
            af = asm_by_lower.get(tok.lower())
            if af is None:
                continue
            asm_name = af["name"]
            by_asm.setdefault(asm_name.lower(), []).append(ci)
            by_cpp.setdefault(lf["name"].lower(), []).append(asm_name)
            break          # first real-field token wins for this leaf
    return by_asm, by_cpp


# ======================================================================
# Link B:  cc leaf  <->  gen leaf   (byte-offset overlay; gen is exact)
# ======================================================================
def infer_cc_sizes(cc_leaves, gen_leaves, asm_by_lower):
    """Set the byte size of each elastic cc leaf (external typedef / enum) then
    recompute cc offsets so the cc struct overlays the same bytes as the gen one.

    An external C++ type T (Pa::Referral, Pa::Bool, HsmKey, ...) has ONE fixed
    size everywhere, so we size it PER TYPE, not per occurrence. Ground truth comes
    from the cc field's own trailing `// LWRPONAME` comment: that ASM field's size
    (via Link A) is sizeof(T). We majority-vote over every anchored occurrence of
    T. Unanchored external types default to 1 byte (the overwhelmingly common case:
    they are single-byte status/indicator enums). This avoids the rolling-offset
    corruption of inferring each occurrence independently from whatever gen leaf
    happens to sit at a (still-shifting) offset.

    Returns the dict {type: inferred_size} actually used (for reporting)."""
    import collections
    votes = collections.defaultdict(collections.Counter)
    for lf in cc_leaves:
        if not lf.get("elastic"):
            continue
        # number of array elements is already folded into lf['size'] via _flatten;
        # but for sizing the TYPE we need the per-element size. _flatten stored the
        # element count in lf['count'] when >1; otherwise count == 1.
        cnt = lf.get("count", 1)
        for tok in re.findall(r"[A-Za-z][A-Za-z0-9_@#$]{3,}", lf.get("comment", "")):
            af = asm_by_lower.get(tok.lower())
            if af and cnt and af["size"] % cnt == 0:
                votes[lf["type"]][af["size"] // cnt] += 1
                break
    type_size = {}
    for t, ctr in votes.items():
        type_size[t] = ctr.most_common(1)[0][0]

    for lf in cc_leaves:
        if lf.get("elastic"):
            elem = type_size.get(lf["type"], 1)
            lf["size"] = elem * lf.get("count", 1)
    off = 0
    for lf in cc_leaves:
        lf["off"] = off
        off += lf["size"]
    return type_size


def anchor_true_offsets(cc_leaves, asm_by_lower):
    """Assign each cc leaf a `true_off` = its real ASM byte offset.

    The cc struct and gen struct describe the SAME bytes, but across ~46 hand
    revisions the cc side has merged indicator pairs into single enums, dropped /
    resized spares, etc., so a pure running offset DRIFTS. The cc fields carry
    trailing `// LWRPONAME` comments naming their exact ASM source — these are
    ground truth. We lock true_off at every anchored leaf (= that ASM field's
    offset via Link A) and interpolate the unanchored leaves between two anchors
    by their cc-local byte delta. This re-locks the register at each anchor, so a
    local divergence cannot propagate past the next anchor.

    Returns the count of anchored leaves (alignment locks)."""
    # 1) find anchors: cc leaf index -> exact ASM offset
    anchors = {}
    for ci, lf in enumerate(cc_leaves):
        for tok in re.findall(r"[A-Za-z][A-Za-z0-9_@#$]{3,}", lf.get("comment", "")):
            af = asm_by_lower.get(tok.lower())
            if af:
                anchors[ci] = af["off"]
                break
    # 2) interpolate true_off for every leaf from the nearest preceding anchor
    #    (cc-local delta carries through), falling back to raw cc offset if no
    #    anchor precedes it.
    for ci, lf in enumerate(cc_leaves):
        if ci in anchors:
            lf["true_off"] = anchors[ci]
            continue
        prev = max((k for k in anchors if k < ci), default=None)
        if prev is not None:
            lf["true_off"] = anchors[prev] + (lf["off"] - cc_leaves[prev]["off"])
        else:
            nxt = min((k for k in anchors if k > ci), default=None)
            if nxt is not None:
                lf["true_off"] = anchors[nxt] - (cc_leaves[nxt]["off"] - lf["off"])
            else:
                lf["true_off"] = lf["off"]
    return len(anchors)


def link_b(cc_leaves, gen_leaves):
    """cc_leaf_index -> list of gen leaves covering the same byte range, using the
    anchor-corrected `true_off` (falls back to raw `off` if anchoring wasn't run)."""
    pair = {}
    for ci, lf in enumerate(cc_leaves):
        base = lf.get("true_off", lf["off"])
        lo, hi = base, base + lf["size"]
        cover = [g for g in gen_leaves
                 if g["off"] < hi and g["off"] + g["size"] > lo]
        if cover:
            pair[ci] = cover
    return pair


def link_b_coverage(cc_leaves, pair):
    real = [i for i, lf in enumerate(cc_leaves) if lf["name"] != "<bits>"]
    hit = sum(1 for i in real if i in pair and pair[i])
    return hit, len(real)


# ======================================================================
# Reusable bulk resolver: build the FULL bidirectional alias map ONCE.
#   This factors the exact parse+Link-A+Link-B pipeline that `resolve()`
#   runs per-query into a single pass over the triple, so callers can do a
#   cheap dict lookup instead of re-parsing (or sub-processing) per variable.
#   The CLI `resolve()` below is left intact for backward compatibility.
# ======================================================================
def cc_path_str(struct, lf):
    """Dotted app path for a cc leaf, e.g. 'PlasticAuth.process....softCardValue'."""
    p = (lf["path"].replace("/", ".") + ".") if lf["path"] else ""
    return f"{struct}.{p}{lf['name']}"


def _asm_fields_from_gen(gen_leaves):
    """Derive ASM DSECT field identities from the gen header (the machine-EXPANDED
    DSECT). By construction the gen leaf name IS the ASM label, lowercased (Link A),
    so uppercasing it recovers the ASM field name, and the gen offset/size are exact.

    This is the CORE decoupling: the resolver no longer DEPENDS on parsing the
    fragile HLASM macro source for a field's identity. A macro-generated DSECT
    (lwrls/cr21ae/l7l7l/regna), whose .mac has no literal ``LABEL DSECT`` line so
    ``parse_mac`` yields nothing, is fully recovered here — its gen header already
    holds every field name + exact layout. ``from_gen`` marks the provenance.
    """
    out = []
    for g in gen_leaves:
        nm = g.get("name")
        if not nm or nm == "<bits>":
            continue
        out.append({"name": nm.upper(), "off": g["off"], "size": g["size"],
                    "op": g.get("type", ""), "from_gen": True})
    return out


def _merge_asm_fields(mac_fields, gen_fields):
    """Union of mac- and gen-derived ASM fields, keyed by name (lowercased).

    Real ``.mac`` fields WIN on conflict — they carry the authoritative ``DS`` op +
    offset. Gen-derived fields FILL every name the ``.mac`` parse did not yield. So:

      * working path (``.mac`` parses): unchanged for every shared field; gen only
        ADDS coverage in the gaps the macro parser missed — never rewrites an
        existing alias;
      * macro-DSECT path (``.mac`` empty): fully supplied by the gen header.

    Deterministic order (by offset then name) so emission is reproducible.
    """
    by = {}
    for f in gen_fields:
        by.setdefault(f["name"].lower(), f)
    for f in mac_fields:
        by[f["name"].lower()] = f          # .mac authoritative on conflict
    return sorted(by.values(), key=lambda f: (f.get("off", 0), f["name"]))


def build_alias_map(mac, gen_path, cc_path, struct=None):
    """Parse one (mac, gen-hpp, cc-hpp) triple ONCE and return the full
    bidirectional ASM<->C++ alias map for ALL fields.

    Returns a dict::

        {
          "by_asm": { ASM_NAME(upper): [ {cpp_path, cpp_tail, gen_name,
                                          asm_name, certainty, size, off}, ... ] },
          "by_cpp": { cpp_tail(lower): [ {asm_name, gen_name, cpp_path,
                                          certainty, size, off}, ... ] },
          "meta": { "mac", "gen", "cc", "asm_struct", "gen_struct", "cc_struct" },
        }

    Certainty is ``"high"`` ONLY when the chain is Link-A exact end-to-end
    (the gen field overlaying the byte range is itself a lowercase-identity of
    a real DSECT field). Anything weaker is ``"medium"``/``"low"`` and callers
    that want high-only (SPEC §7) can filter on ``certainty == "high"``.
    """
    asm_raw = parse_mac(mac)
    asm = [f for f in asm_raw if not f.get("group")]
    gen_struct, gen_leaves = parse_gen(gen_path)
    cc_struct, cc_leaves = parse_cc(cc_path, struct)

    # CORE FIX (gen-as-authoritative-ASM-source): the gen header IS the machine-
    # expanded DSECT, so its leaves are an exact, ALWAYS-available ASM identity
    # source. Union the .mac-derived fields with gen-derived ones BEFORE any link,
    # so a fragile / empty .mac parse (macro-generated DSECTs: lwrls, cr21ae, ...)
    # can no longer collapse cross-language resolution for the whole struct. .mac
    # fields win on conflict, so the working path is unchanged except for added
    # coverage; everything downstream (Link A, comment map, both emission loops)
    # now validates against the FULL field set instead of the .mac alone.
    mac_parsed = bool(asm)
    asm = _merge_asm_fields(asm, _asm_fields_from_gen(gen_leaves))

    # Link A: gen leaf <-> ASM field (lowercase identity, EXACT).
    asm_by_lower, a_pairs = link_a(gen_leaves, asm)
    # Link B: cc leaf <-> gen leaf (byte-offset overlay; gen is exact).
    infer_cc_sizes(cc_leaves, gen_leaves, asm_by_lower)
    anchor_true_offsets(cc_leaves, asm_by_lower)
    b_pair = link_b(cc_leaves, gen_leaves)

    # I2: ground-truth comment map (cc field <-> ASM name from trailing comment).
    cmt_by_asm, cmt_by_cpp = build_comment_map(cc_leaves, asm_by_lower)

    by_asm = {}
    by_cpp = {}

    def _emit(asm_name, lf, certainty, via):
        cpp_path = cc_path_str(cc_struct, lf)
        cpp_tail = lf["name"]
        by_asm.setdefault(asm_name.upper(), []).append({
            "cpp_path": cpp_path, "cpp_tail": cpp_tail,
            "gen_name": asm_name.lower(), "asm_name": asm_name,
            "certainty": certainty, "size": lf["size"],
            "off": lf.get("true_off", lf["off"]), "via": via,
        })
        by_cpp.setdefault(cpp_tail.lower(), []).append({
            "asm_name": asm_name, "gen_name": asm_name.lower(),
            "cpp_path": cpp_path, "certainty": certainty,
            "size": lf["size"], "off": lf.get("true_off", lf["off"]), "via": via,
        })

    # --- Direction ASM -> gen -> cc: for every DSECT field with an exact gen
    #     identity (Link A), gather the cc leaves overlaying that byte range. ---
    gen_to_cc = {}
    for ci, covers in b_pair.items():
        for g in covers:
            gen_to_cc.setdefault(g["name"], []).append(ci)

    for af in asm:
        gen_name = af["name"].lower()
        # the gen field must exist as a lowercase identity for a "high" link
        gen_leaf = next((g for g in gen_leaves
                         if g["name"].lower() == gen_name), None)
        if gen_leaf is None:
            continue
        for ci in gen_to_cc.get(gen_leaf["name"], []):
            lf = cc_leaves[ci]
            if lf["name"] == "<bits>":
                continue
            cpp_path = cc_path_str(cc_struct, lf)
            cpp_tail = lf["name"]
            # high-certainty when the cc leaf exactly overlays the same single
            # byte range as the (exact) gen field — same off, same size, 1:1.
            exact = (lf.get("true_off", lf["off"]) == gen_leaf["off"]
                     and lf["size"] == gen_leaf["size"])
            certainty = "high" if exact else "medium"
            # I2b CROSS-CHECK: if the cc field's own comment names this same ASM
            # field, the byte-offset path and the ground-truth comment agree —
            # the strongest possible signal. Promote a borderline overlay to high.
            comment_agrees = af["name"] in cmt_by_cpp.get(cpp_tail.lower(), [])
            if comment_agrees:
                certainty = "high"
            via = "offset+comment" if comment_agrees else "offset"
            by_asm.setdefault(af["name"].upper(), []).append({
                "cpp_path": cpp_path, "cpp_tail": cpp_tail,
                "gen_name": gen_leaf["name"], "asm_name": af["name"],
                "certainty": certainty, "size": lf["size"],
                "off": lf.get("true_off", lf["off"]), "via": via,
            })
            by_cpp.setdefault(cpp_tail.lower(), []).append({
                "asm_name": af["name"], "gen_name": gen_leaf["name"],
                "cpp_path": cpp_path, "certainty": certainty,
                "size": lf["size"], "off": lf.get("true_off", lf["off"]),
                "via": via,
            })

    # I2 COMMENT-ONLY anchors: a cc field whose comment names a real DSECT field
    # but which the byte-offset path did NOT already cover (the comment is
    # ground truth, so this is high-certainty even without an offset match).
    for asm_lower, cis in cmt_by_asm.items():
        af = asm_by_lower.get(asm_lower)
        if af is None:
            continue
        for ci in cis:
            lf = cc_leaves[ci]
            already = any(e["cpp_tail"].lower() == lf["name"].lower()
                          for e in by_asm.get(af["name"].upper(), []))
            if not already:
                _emit(af["name"], lf, "high", "comment")

    return {
        "by_asm": by_asm,
        "by_cpp": by_cpp,
        "meta": {
            "mac": str(mac), "gen": str(gen_path), "cc": str(cc_path),
            "gen_struct": gen_struct, "cc_struct": cc_struct,
        },
        # OBSERVABILITY: distinguish "no counterpart exists" from "could not parse".
        # An empty by_cpp with parse failures means the resolver gave up, NOT that
        # the field has no ASM twin — callers (name_resolver / engine) can surface
        # that instead of silently reporting a variable as terminal.
        "status": {
            "resolved": bool(by_cpp),
            "mac_parsed": mac_parsed,
            "gen_parsed": bool(gen_leaves),
            "cc_parsed": bool(cc_leaves),
            "n_cpp": len(by_cpp), "n_asm": len(by_asm),
        },
    }


def _comment_field_set_from_consensus(cc_leaves):
    """Last-resort ASM field set mined from the cc field COMMENTS alone.

    When there is NO parseable ``.mac`` (macro-generated DSECT) AND NO gen header
    (e.g. l7l7l: ``l7l7l.mac`` has no ``DSECT`` line and ``l7l7l.hpp`` does not
    exist), the cc field comments (``char authorizerTerminalId[5]; // L7LTID``) are
    the ONLY ground truth for the ASM names — but there is nothing to validate them
    against. We self-validate by CONSENSUS: accept a comment's first identifier token
    iff it shares the DOMINANT field-name prefix of this header's comments (the DSECT
    prefix, e.g. ``L7L``) and is not a pure revision tag (``R<digits>``). The prefix
    is derived from the data, so this rejects revision/author tags and prose while
    keeping real field names — no hardcoding. Returns ``{asm_lower: field-dict}``.
    """
    import collections
    toks = []
    for lf in cc_leaves:
        if lf.get("name") == "<bits>":
            continue
        m = _COMMENT_TOK_RE.search(lf.get("comment", ""))
        if m:
            toks.append(m.group(0))
    real = [t for t in toks if not re.match(r"^[Rr]\d+$", t)]
    if len(real) < 3:
        return {}
    pref_ctr = collections.Counter(t[:3].upper() for t in real).most_common(1)
    # require the prefix to dominate (>= 1/5 of comment tokens, min 3) so a
    # coincidental token cluster cannot masquerade as the field-name prefix.
    if not pref_ctr or pref_ctr[0][1] < max(3, len(real) // 5):
        return {}
    prefix = pref_ctr[0][0]
    fields = {}
    for t in real:
        if t[:3].upper() == prefix:
            fields.setdefault(t.lower(), {"name": t.upper(), "off": 0, "size": 0,
                                          "op": "", "from_comment": True})
    return fields


def build_alias_map_cc_only(mac, cc_path, struct=None):
    """I2(a) — GEN-ABSENT FALLBACK. Build the bidirectional ASM<->C++ alias map
    from ONLY the .mac DSECT and the cc<name>.hpp app header, using the
    ground-truth field-comment anchors (no gen <name>.hpp available).

    Same output shape as ``build_alias_map``. Every emitted alias is
    ``certainty == "high"``: each comes from a cc field whose trailing comment
    names a real DSECT field (validated against the .mac), which is exact by
    construction — the comment is the hand-maintained ASM source name.

    This closes audit ②-B3/⑥-E1: app headers like cclg1g1.hpp have NO machine-
    generated gen header, so the offset chain cannot run, yet their comments
    carry the ASM names directly (e.g. `OnlineSourceInd onlineSrcInd; // lg1osi`)."""
    asm_raw = parse_mac(mac)
    asm = [f for f in asm_raw if not f.get("group")]
    asm_by_lower = {}
    for f in asm:
        asm_by_lower.setdefault(f["name"].lower(), f)
    cc_struct, cc_leaves = parse_cc(cc_path, struct)

    # CORE FIX (comment-as-last-resort): gen-absent AND macro-DSECT (.mac yields
    # nothing) → there is no parsed field set to validate the comments against. The
    # comments are still ground truth, so self-validate them by prefix consensus.
    mac_parsed = bool(asm_by_lower)
    if not asm_by_lower:
        asm_by_lower = _comment_field_set_from_consensus(cc_leaves)

    cmt_by_asm, _ = build_comment_map(cc_leaves, asm_by_lower)

    by_asm = {}
    by_cpp = {}
    for asm_lower, cis in cmt_by_asm.items():
        af = asm_by_lower.get(asm_lower)
        if af is None:
            continue
        via = "comment" if mac_parsed else "comment-consensus"
        for ci in cis:
            lf = cc_leaves[ci]
            if lf.get("name") == "<bits>":
                continue
            cpp_path = cc_path_str(cc_struct, lf)
            cpp_tail = lf["name"]
            by_asm.setdefault(af["name"].upper(), []).append({
                "cpp_path": cpp_path, "cpp_tail": cpp_tail,
                "gen_name": af["name"].lower(), "asm_name": af["name"],
                "certainty": "high", "size": lf["size"],
                "off": lf["off"], "via": via,
            })
            by_cpp.setdefault(cpp_tail.lower(), []).append({
                "asm_name": af["name"], "gen_name": af["name"].lower(),
                "cpp_path": cpp_path, "certainty": "high",
                "size": lf["size"], "off": lf["off"], "via": via,
            })

    return {
        "by_asm": by_asm,
        "by_cpp": by_cpp,
        "meta": {
            "mac": str(mac), "gen": None, "cc": str(cc_path),
            "gen_struct": None, "cc_struct": cc_struct,
        },
        "status": {
            "resolved": bool(by_cpp),
            "mac_parsed": mac_parsed,
            "gen_parsed": False,
            "cc_parsed": bool(cc_leaves),
            "n_cpp": len(by_cpp), "n_asm": len(by_asm),
        },
    }


# ======================================================================
# Resolver / CLI
# ======================================================================
def cc_show(struct, lf):
    p = (lf["path"].replace("/", ".") + ".") if lf["path"] else ""
    off = lf.get("true_off", lf["off"])
    return f"{struct}.{p}{lf['name']} ({lf['type']}, {lf['size']}B @ off {off})"


def gen_show(struct, lf):
    return f"casuav::{struct}.{lf['name']} ({lf['type']}, {lf['size']}B @ off {lf['off']})"


def resolve(name, mac, gen_path, cc_path, struct=None, quiet=False):
    asm_raw = parse_mac(mac)
    asm = [f for f in asm_raw if not f.get("group")]
    gen_struct, gen_leaves = parse_gen(gen_path)
    cc_struct, cc_leaves = parse_cc(cc_path, struct)

    # Link A
    asm_by_lower, a_pairs = link_a(gen_leaves, asm)
    # Link B (infer elastic cc external-type sizes per-type via comment anchors,
    # then overlay against the exact gen byte layout)
    infer_cc_sizes(cc_leaves, gen_leaves, asm_by_lower)
    n_anchor = anchor_true_offsets(cc_leaves, asm_by_lower)
    b_pair = link_b(cc_leaves, gen_leaves)

    # reverse index: gen leaf name -> cc leaf indices covering it
    gen_to_cc = {}
    for ci, covers in b_pair.items():
        for g in covers:
            gen_to_cc.setdefault(g["name"], []).append(ci)

    if not quiet:
        print(f"ASM  : {mac}      (DSECT, {len(asm)} fields)")
        print(f"gen  : {gen_path}  (casuav::{gen_struct}, {len(gen_leaves)} leaves)")
        print(f"app  : {cc_path}   (struct {cc_struct}, {len(cc_leaves)} leaves)")
        ha, ta = link_a_coverage(gen_leaves, asm)
        hb, tb = link_b_coverage(cc_leaves, b_pair)
        print(f"LinkA: {ha}/{ta} DSECT fields named in gen ({100*ha/ta:.1f}%)")
        print(f"LinkB: {hb}/{tb} cc leaves mapped to gen by offset "
              f"({100*hb/tb:.1f}%, {n_anchor} comment anchors re-locking drift)\n")

    target = name.strip()
    tup = strip_suffix(target).upper()
    tlow = strip_suffix(target).lower()

    # ---- Direction 1: NAME is an ASM field (or a gen identity) ----
    asm_field = next((f for f in asm if f["name"].upper() == tup), None)
    gen_leaf = next((g for g in gen_leaves if g["name"].lower() == tlow), None)

    if asm_field is not None or (gen_leaf is not None and gen_leaf["name"].lower()
                                 in asm_by_lower):
        if gen_leaf is None:
            gen_leaf = next((g for g in gen_leaves
                             if g["name"].lower() == tup.lower()), None)
        af = asm_field or asm_by_lower.get(gen_leaf["name"].lower())
        print(f"== ASM field -> gen -> app  for '{target}' ==")
        print(f"  [ASM] {af['name']}  (op {af['op']}, off {af['off']}, "
              f"size {af['size']})")
        if gen_leaf is not None:
            print(f"  [gen] {gen_show(gen_struct, gen_leaf)}   "
                  f"<- Link A EXACT (lowercase identity)")
            ccs = gen_to_cc.get(gen_leaf["name"], [])
            if ccs:
                print("  [app] cc field(s) at this byte range  <- Link B (layout):")
                for ci in ccs:
                    note = "" if cc_leaves[ci]["size"] == gen_leaf["size"] \
                        else "  [size inferred / overlay]"
                    print("        " + cc_show(cc_struct, cc_leaves[ci]) + note)
            else:
                print("  [app] (no cc field overlays this byte range — "
                      "ASM-only / spare)")
        else:
            print("  [gen] (no gen identifier matches — DSECT-only field)")
        return

    # ---- Direction 2: NAME is an app cc member ----
    ci = next((k for k, lf in enumerate(cc_leaves)
               if lf["name"].lower() == tlow), None)
    if ci is not None:
        lf = cc_leaves[ci]
        print(f"== app -> gen -> ASM  for '{target}' ==")
        print(f"  [app] {cc_show(cc_struct, lf)}")
        covers = b_pair.get(ci, [])
        if not covers:
            print("  [gen] (no gen field overlays this byte range)")
            return
        print("  [gen] gen field(s) covering this byte range  "
              "<- Link B (layout):")
        for g in covers:
            print("        " + gen_show(gen_struct, g))
        print("  [ASM] DSECT field(s)  <- Link A EXACT (lowercase identity):")
        any_asm = False
        for g in covers:
            af = asm_by_lower.get(g["name"].lower())
            if af:
                any_asm = True
                print(f"        {af['name']}  (op {af['op']}, off {af['off']}, "
                      f"size {af['size']})")
        if not any_asm:
            print("        (covering gen fields have no DSECT counterpart)")
        return

    print(f"!! '{name}' is neither an ASM field in {mac}, a gen identifier in "
          f"{os.path.basename(gen_path)}, nor an app member of {cc_struct}.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("var")
    ap.add_argument("mac")
    ap.add_argument("--gen")
    ap.add_argument("--cc")
    ap.add_argument("--struct")
    a = ap.parse_args()
    mac = a.mac
    d = os.path.dirname(mac) or "."
    stem = re.sub(r"\.mac$", "", os.path.basename(mac))
    gen = a.gen or os.path.join(d, f"{stem}.hpp")
    cc = a.cc or os.path.join(d, f"cc{stem}.hpp")
    for p, label in ((gen, "gen header"), (cc, "cc header")):
        if not os.path.exists(p):
            sys.exit(f"{label} not found: {p} (pass --gen/--cc)")
    resolve(a.var, mac, gen, cc, a.struct)
