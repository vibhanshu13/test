"""Additional HLASM opcode tables for register reaching-definition (VBT-local).

The reaching-def core ported into :mod:`vbt.resolve.register_indirect` needs a few
opcodes that the read-only ``backward_traversal.glossary.instructions`` tables do not
cover.  Per SPEC constraint #3 we never edit the backward_traversal glossary in
place; the missing entries live here, in our own engine layer.

Categories:

* :data:`REGISTER_LOAD_ADDRESS_EXT` — additional load-address forms (LAE) beyond
  the reused ``REGISTER_LOAD_ADDRESS`` (LA/LAY).
* :data:`PC_RELATIVE_LOAD_ADDRESS` — LARL loads a *label address* PC-relative; the
  label IS the named symbol (terminal address producer, like LA).
* :data:`REGISTER_LOAD_FROM_MEM_EXT` — additional memory-to-register loads (the
  zero/sign-extending LLGF/LLGT/LLC/LLH and the PC-relative LRL) that the reused
  ``REGISTER_LOAD_FROM_MEM`` does not list.
* :data:`REGISTER_MULTI_LOAD` — LM/LMG/LMY restore a *range* of registers from a
  save area; the memory operand (the save area) is the source for any register in
  the range (sound over-approximation: the exact slot is the save area field).
* :data:`IMMEDIATE_LOAD_INST` — LGFI/LHI/LGHI/IILF/… load a compile-time constant
  into a register: terminal, no data dependency.
* :data:`ADDRESS_ARITH_INPLACE` — A/AH/S/… adjust a register's value in place; they
  do not establish where the register was first loaded, so the backward scan must
  continue (lifted verbatim from asm_backward_tracer.py:506).

Every table is keyed identically to the reused glossary (inst -> source operand
index, or a plain set) so the two can be consulted uniformly.
"""
from __future__ import annotations

from typing import Dict, FrozenSet

# Load-address (effective address into a register) — extends the reused
# REGISTER_LOAD_ADDRESS {LA, LAY}.  Maps inst -> address-operand index.
REGISTER_LOAD_ADDRESS_EXT: Dict[str, int] = {
    "LAE": 1,   # LAE Rd, addr  (Load Address Extended — RX, same operand layout as LA)
}

# PC-relative load-address: LARL Rd, label.  The label is the named symbol itself
# (no base register, no displacement). Terminal address producer.
PC_RELATIVE_LOAD_ADDRESS: Dict[str, int] = {
    "LARL": 1,
}

# Memory-to-register value loads NOT already in the reused REGISTER_LOAD_FROM_MEM.
# Maps inst -> source memory-operand index.  These load (and zero/sign-extend) the
# *value at* a named field, so that field is the data dependency.
REGISTER_LOAD_FROM_MEM_EXT: Dict[str, int] = {
    "LLGF": 1,   # Load Logical (32→64, zero-extend) from memory
    "LLGT": 1,   # Load Logical Thirty-One bits from memory
    "LLC":  1,   # Load Logical Character (8→32, zero-extend) from memory
    "LLH":  1,   # Load Logical Halfword (16→32, zero-extend) from memory
    "LLGC": 1,   # Load Logical Character (8→64)
    "LLGH": 1,   # Load Logical Halfword (16→64)
    "LRL":  1,   # Load (32-bit) PC-relative from storage — label is args[1]
}

# Load-multiple: LM/LMG/LMY Rlo, Rhi, mem.  Restores a register range from a save
# area; the memory operand (args[2]) is the source for any register in [Rlo, Rhi].
# Maps inst -> memory-operand index.
REGISTER_MULTI_LOAD: Dict[str, int] = {
    "LM":  2,
    "LMG": 2,
    "LMY": 2,
}

# Immediate loads: a compile-time constant into a register.  Terminal — no data dep.
IMMEDIATE_LOAD_INST: FrozenSet[str] = frozenset({
    "LHI", "LGHI",          # Load Halfword Immediate (16-bit signed) 32 / 64-bit
    "LGFI",                 # Load (64-bit) Fullword Immediate
    "IILF", "IIHF",         # Insert Immediate (low/high fullword)
    "IILL", "IILH", "IIHL", "IIHH",  # Insert Immediate (halfword positions)
    "LLILF", "LLIHF",       # Load Logical Immediate fullword (low/high)
    "LLILL", "LLILH", "LLIHL", "LLIHH",  # Load Logical Immediate halfword positions
})

# In-place address/value arithmetic: these modify a register but do NOT establish
# where it was originally loaded, so the backward scan must continue past them.
# Lifted from asm_backward_tracer.py:506 (the GAP-006 in-place-arith handling).
ADDRESS_ARITH_INPLACE: FrozenSet[str] = frozenset({
    "A", "AH", "AHI", "AGHI", "AGF", "AG", "AR", "AGR", "AL", "ALR", "ALGR",
    "S", "SH", "SR", "SGR", "SL", "SLR", "SLGR",
    "N", "NR", "NGR", "O", "OR", "OGR", "X", "XR", "XGR",
    "SLA", "SLL", "SRA", "SRL", "SLAG", "SLLG", "SRAG", "SRLG",
})

__all__ = (
    "REGISTER_LOAD_ADDRESS_EXT",
    "PC_RELATIVE_LOAD_ADDRESS",
    "REGISTER_LOAD_FROM_MEM_EXT",
    "REGISTER_MULTI_LOAD",
    "IMMEDIATE_LOAD_INST",
    "ADDRESS_ARITH_INPLACE",
)
