"""Cross-language name resolution + constant/enum resolution."""
