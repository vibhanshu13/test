"""High-certainty ASM↔C++ name resolution (SPEC §7) — parse-once, no subprocess.

Verdict: IMPROVE-THEN-USE `temp/asm/find_cpp_chain.py` — the deterministic 3-layer
resolver (ASM .mac → gen <stem>.hpp → app cc<stem>.hpp). Link A is EXACT (the gen
header re-emits each DSECT label lowercased), Link B is byte-offset overlay. We keep
ONLY high-certainty results (Link A exact end-to-end); anything weaker is dropped
(SPEC §7).

SCALABILITY (22k files): the old design spawned a `find_cpp_chain.py` SUBPROCESS once
per (triple × query) — O(queries × triples) process spawns, unusable at scale. We now
reuse that module's parser building-blocks (`parse_mac`/`parse_gen`/`parse_cc`,
`_flatten`, Link-A lowercase-identity + Link-B byte-offset alignment) via its factored
`build_alias_map(mac, gen, cc)` to build, ONCE per (mac, gen-hpp, cc-hpp) triple, a FULL
bidirectional alias map for ALL fields. That map is cached module-level keyed on the
triple paths, so `resolve()` is a pure in-process dict lookup. NO subprocess is ever
spawned. With a `home_hint` we scan only the triple whose stem == home_hint (falling
back to all triples).
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from vbt.interfaces import Alias, AliasSet

# Vendored deterministic 3-layer resolver (parse_mac/gen/cc + Link-A/B + the factored
# build_alias_map). Vendored into the package so vbt/ is self-contained & transferable
# (the original lives in temp/asm/find_cpp_chain.py, which is gitignored). It operates
# on whatever source dir is passed in — no hard-coded paths.
from vbt.resolve import _find_cpp_chain as _chain

# Module-level cache of built alias maps, keyed on the resolved unit paths.
# {(mac_abspath, gen_abspath_or_'', cc_abspath): alias_map_dict}
_MAP_CACHE: Dict[Tuple[str, str, str], dict] = {}
# Cache of (src_dir -> resolvable units) so directory discovery runs once.
_UNIT_CACHE: Dict[str, List["_Unit"]] = {}
# Cache of (mac path str -> lowercased DSECT names). _dsect_names is a pure function of
# file content; a file never changes mid-process, so this is a speed-only memo.
_DSECT_CACHE: Dict[str, List[str]] = {}


class _Unit(tuple):
    """A resolvable mapping unit: (mac, gen_or_None, cc, stem).

    ``gen`` is None for a cc-only unit (no machine-generated <stem>.hpp). ``stem``
    is the home stem used for home_hint matching and Alias.home_stem.
    ``_key`` is the resolved (mac, gen, cc) path triple used as the _MAP_CACHE key,
    computed once here so per-query lookups issue no Path.resolve() syscalls."""
    # NOTE: no __slots__. The previous `__slots__ = ()` blocks attribute assignment,
    # and `__slots__ = ("_key",)` is ILLEGAL on a tuple subclass (TypeError at import).
    # Omitting __slots__ gives the instance a __dict__ so `inst._key` is settable.

    def __new__(cls, mac: Path, gen: Optional[Path], cc: Path, stem: str):
        inst = super().__new__(cls, (mac, gen, cc, stem))
        gkey = str(gen.resolve()) if gen is not None else ""
        inst._key = (str(mac.resolve()), gkey, str(cc.resolve()))
        return inst

    mac = property(lambda s: s[0])
    gen = property(lambda s: s[1])
    cc = property(lambda s: s[2])
    stem = property(lambda s: s[3])


def _dsect_names(mac: Path) -> List[str]:
    """Lowercased DSECT names declared in ``mac`` (e.g. LG1G1&A DSECT -> 'lg1g1').
    Process-memoized by path (pure function of file content; read at most once/file)."""
    key = str(mac)
    cached = _DSECT_CACHE.get(key)
    if cached is not None:
        return cached
    try:
        text = _chain.read_source_text(mac)
    except OSError:
        _DSECT_CACHE[key] = []
        return []
    out = []
    for m in re.finditer(r"^([A-Za-z][\w$#@]*)(?:&\w+)?\s+DSECT", text, re.M):
        out.append(m.group(1).lower())
    _DSECT_CACHE[key] = out
    return out


def _mac_for_cc_stem(src_dir: Path, stem: str) -> Optional[Path]:
    """Find the .mac backing a cc<stem>.hpp. The DSECT MEMBER name (file) often
    differs from the RECORD name (cc stem) — e.g. cclg1g1.hpp (stem lg1g1) is
    backed by lg1lg1.mac whose DSECT is LG1G1. So: prefer a literal <stem>.mac,
    else the .mac whose declared DSECT name == stem (self-validating, no
    hardcoding)."""
    direct = src_dir / f"{stem}.mac"
    if direct.exists():
        return direct
    for mac in sorted(src_dir.glob("*.mac")):
        if stem in _dsect_names(mac):
            return mac
    return None


def _units(src_dir: Path) -> List[_Unit]:
    """All resolvable units in ``src_dir``: full triples (mac+gen+cc) AND cc-only
    pairs (mac+cc, no gen — the I2 gen-absent fallback). Discovery is cached."""
    key = str(src_dir.resolve())
    cached = _UNIT_CACHE.get(key)
    if cached is not None:
        return cached
    out: List[_Unit] = []
    for cc in sorted(src_dir.glob("cc*.hpp")):
        stem = cc.stem[2:]                       # ccda7gl -> da7gl
        if not stem:
            continue
        gen = src_dir / f"{stem}.hpp"
        mac = src_dir / f"{stem}.mac"
        if gen.exists() and mac.exists():
            out.append(_Unit(mac, gen, cc, stem))         # full triple
            continue
        # cc-only fallback: gen absent OR the stem-named mac is absent — locate
        # the backing .mac by DSECT name so the comment anchors can resolve.
        backing = mac if mac.exists() else _mac_for_cc_stem(src_dir, stem)
        if backing is not None:
            out.append(_Unit(backing, None, cc, stem))     # cc-only
    _UNIT_CACHE[key] = out
    return out


def _alias_map(unit: _Unit) -> Optional[dict]:
    """Build-and-cache (once) the bidirectional alias map for ``unit``.

    Full triple -> offset chain + comment cross-check; cc-only -> comment map."""
    cached = _MAP_CACHE.get(unit._key)
    if cached is not None:
        return cached
    mac, gen, cc, _stem = unit
    try:
        if gen is not None:
            amap = _chain.build_alias_map(str(mac), str(gen), str(cc))
        else:
            amap = _chain.build_alias_map_cc_only(str(mac), str(cc))
    except Exception:
        amap = None
    # Cache even None so we don't retry a broken unit on every query.
    _MAP_CACHE[unit._key] = amap
    return amap


def clear_cache() -> None:
    """Drop the cached alias maps + unit discovery + dsect-name memo (e.g. for tests)."""
    _MAP_CACHE.clear()
    _UNIT_CACHE.clear()
    _DSECT_CACHE.clear()


def resolve(variable: str, language: str, src_dir: Path,
            *, home_hint: Optional[str] = None) -> AliasSet:
    """Resolve high-certainty cross-language aliases for ``variable``.

    Returns an AliasSet (canonical + high-certainty cross-language aliases only).
    ``language`` is the variable's own language; for C++ pass the field tail or path.
    Drop-in for vbt/engine.py — signature unchanged. Pure dict lookup over the cached
    per-unit alias map(s); never spawns a subprocess. Units are full (mac+gen+cc)
    triples AND cc-only (mac+cc) gen-absent fallbacks (I2a).
    """
    src_dir = Path(src_dir)
    canonical = variable
    aliases: List[Alias] = []
    seen = set()

    units = _units(src_dir)
    if home_hint:
        scoped = [u for u in units if u.stem == home_hint]
        units = scoped or units      # fall back to all units if hint misses

    # C++ field paths resolve by their tail component in the headers.
    if language == "cpp":
        query = variable.split(".")[-1].split("->")[-1]
        lookup_key = query.lower()
    else:
        query = _chain.strip_suffix(variable).upper()
        lookup_key = query

    for unit in units:
        amap = _alias_map(unit)
        if not amap:
            continue

        if language == "cpp":
            entries = amap["by_cpp"].get(lookup_key, [])
            for e in entries:
                if e["certainty"] != "high":      # SPEC §7: high-certainty only
                    continue
                name, out_lang = e["asm_name"], "asm"
                key = (name, out_lang)
                if key in seen:
                    continue
                seen.add(key)
                aliases.append(Alias(name=name, language=out_lang,
                                     home_stem=unit.stem, certainty="high",
                                     via="find_cpp_chain"))
        else:
            entries = amap["by_asm"].get(lookup_key, [])
            for e in entries:
                if e["certainty"] != "high":      # SPEC §7: high-certainty only
                    continue
                # Emit the full app path so the cpp name is unambiguous; the tail
                # (e.g. softCardValue) is contained within it.
                name, out_lang = e["cpp_path"], "cpp"
                key = (name, out_lang)
                if key in seen:
                    continue
                seen.add(key)
                aliases.append(Alias(name=name, language=out_lang,
                                     home_stem=unit.stem, certainty="high",
                                     via="find_cpp_chain"))

    return AliasSet(canonical=canonical, aliases=aliases)
