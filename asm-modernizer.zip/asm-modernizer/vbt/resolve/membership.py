"""Variable membership + cross-language counterpart (SPEC §7 extension).

For ANY traced variable (root or dependent) we surface two facts:

  * ``memberOf``  — the data structure the variable belongs to: a C++ named
                    struct/record (the TOP-LEVEL struct in the cc/app header) or
                    an ASM DSECT/macro.  ``None`` for a bare local (no struct/DSECT).
  * ``counterpart`` — its high-certainty cross-language twin (ASM↔C++), if one
                    resolves, together with THAT twin's ``memberOf``.  ``None`` when
                    the variable has no cross-language identity (a C++-only field,
                    a local, a register).

Why the TOP-LEVEL struct is the right "struct it belongs to": the z/TPF corpus nests
fields in ANONYMOUS sub-structs (``struct { char softCardValue; } transactionInds;``),
so the only *named* owner is the record (``PlasticAuth``) — which is exactly the unit
the ASM↔C++ mapping is keyed on (a DSECT ↔ a cc record).

Sources, high-certainty only, first hit wins:
  1. ``name_resolver`` (cc↔gen↔mac byte-offset alignment, Link-A exact): gives the
     counterpart name + record stem + the cc top struct (``meta.cc_struct``) and, via
     the backing .mac, the DSECT name. Covers cross-language (DSECT-backed) fields.
  2. header field→top-struct index: for a C++ field with NO ASM twin, the top-level
     named struct in a cc/app header that (transitively) declares it. Ambiguity (a
     field name declared in several records) is resolved with the variable's qualified
     path; unresolved ambiguity is surfaced as ``candidates`` rather than a wrong guess.
  3. all-DSECT symbol index: the DSECT/macro a bare ASM symbol is defined in, even when
     the symbol has no cc counterpart.

Parse-once + process-cached (mirrors const_resolver / name_resolver)."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from vbt.resolve import name_resolver as _nr

_CACHE: Dict[Tuple[str, str], "MembershipResolver"] = {}


# --------------------------------------------------------------------------- #
# header parsing helpers (top-level named struct → its member field tails/paths)
# --------------------------------------------------------------------------- #
def _strip_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    return re.sub(r"//[^\n]*", "", text)


def _matching_brace(text: str, open_idx: int) -> int:
    depth = 0
    for j in range(open_idx, len(text)):
        c = text[j]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return j
    return len(text) - 1


_STRUCT_OPEN = re.compile(r"\b(struct|union)\b\s*([A-Za-z_]\w*)?\s*\{")
_FIELD = re.compile(r"([A-Za-z_]\w*)\s*(?:\[[^\]]*\])?\s*;")


class MembershipResolver:
    def __init__(self, blueprint_dir: Path, src_dir: Path) -> None:
        self.blueprint_dir = Path(blueprint_dir)
        self.src_dir = Path(src_dir)
        # cross-language (name_resolver) maps: key(lower/upper) -> record facts
        self._cpp: Dict[str, dict] = {}     # cpp tail.lower() -> {struct, record, asm, dsect}
        self._asm: Dict[str, dict] = {}     # ASM symbol upper -> {struct, record, cpp, dsect}
        # C++ field tail.lower() -> set(top struct names) declared anywhere in headers
        self._tail_structs: Dict[str, Set[str]] = {}
        # ASM symbol upper -> DSECT name (all DSECTs, incl. non-cc-paired)
        self._sym_dsect: Dict[str, str] = {}
        self._built = False

    # -- build -------------------------------------------------------------- #
    def _build(self) -> None:
        if self._built:
            return
        self._built = True
        units = _nr._units(self.src_dir)
        for u in units:
            m = _nr._alias_map(u)
            if not m:
                continue
            cc = (m.get("meta") or {}).get("cc_struct")
            ds = self._dsect_for_unit(u)
            for q, entries in m.get("by_cpp", {}).items():
                for e in entries:
                    if e.get("certainty") == "high":
                        self._cpp.setdefault(q, {"struct": cc, "record": u.stem,
                                                 "asm": e["asm_name"], "dsect": ds})
                        break
            for q, entries in m.get("by_asm", {}).items():
                for e in entries:
                    if e.get("certainty") == "high":
                        self._asm.setdefault(q.upper(), {"struct": cc, "record": u.stem,
                                                         "cpp": e["cpp_path"], "dsect": ds})
                        break
        self._build_header_index()
        self._build_dsect_index()

    @staticmethod
    def _dsect_for_unit(unit) -> Optional[str]:
        ds = _nr._dsect_names(unit.mac)
        return ds[0].upper() if ds else (unit.stem.upper() if unit.stem else None)

    def _build_header_index(self) -> None:
        """Map every field tail → the set of TOP-LEVEL named structs declaring it."""
        seen_files: Set[str] = set()
        for pat in ("cc*.hpp", "*.hpp"):
            for hp in sorted(self.src_dir.glob(pat)):
                rp = str(hp.resolve())
                if rp in seen_files:
                    continue
                seen_files.add(rp)
                try:
                    text = _strip_comments(_nr._chain.read_source_text(hp))
                except OSError:
                    continue
                for sm in re.finditer(r"\bstruct\s+([A-Za-z_]\w*)\s*\{", text):
                    top = sm.group(1)
                    op = text.index("{", sm.start())
                    self._collect_fields(text[op + 1:_matching_brace(text, op)], top)

    def _collect_fields(self, body: str, top: str) -> None:
        """Walk a struct body; assign every field (incl. those in nested anon structs)
        to ``top`` (the outermost named struct)."""
        i, n = 0, len(body)
        while i < n:
            sm = _STRUCT_OPEN.search(body, i)
            fm = _FIELD.search(body, i)
            if sm and (not fm or sm.start() < fm.start()):
                op = body.index("{", sm.start())
                close = _matching_brace(body, op)
                self._collect_fields(body[op + 1:close], top)        # recurse, same top
                semi = body.find(";", close)
                i = semi + 1 if semi >= 0 else close + 1
            elif fm:
                nm = fm.group(1)
                if nm not in ("struct", "union"):
                    self._tail_structs.setdefault(nm.lower(), set()).add(top)
                i = fm.end()
            else:
                break

    def _build_dsect_index(self) -> None:
        """ASM symbol → DSECT name across ALL .mac files (covers symbols with no cc twin).
        A field belongs to the most recent ``LABEL DSECT`` above it."""
        for mac in sorted(self.src_dir.glob("*.mac")):
            try:
                text = _nr._chain.read_source_text(mac)
            except OSError:
                continue
            cur: Optional[str] = None
            for line in text.splitlines():
                dm = re.match(r"^([A-Za-z@#$][\w@#$]*)(?:&\w+)?\s+DSECT", line)
                if dm:
                    cur = dm.group(1).upper()
                    continue
                if cur is None:
                    continue
                fm = re.match(r"^([A-Za-z@#$][\w@#$]*)(?:&\w+)?\s+(DS|DC|EQU)\b", line)
                if fm:
                    self._sym_dsect.setdefault(fm.group(1).upper(), cur)

    # -- query -------------------------------------------------------------- #
    @staticmethod
    def _tail(name: str) -> str:
        return name.split(".")[-1].split("->")[-1]

    def _disambiguate(self, candidates: Set[str], qualified: str) -> Tuple[Optional[str], List[str]]:
        """Pick the one declaring struct that matches the variable's qualified-path root
        (the access root names a local whose TYPE is the record, e.g. ``plasticAuth`` →
        ``PlasticAuth``, ``lwrCommon`` → ``LwrCommon``). Returns (chosen|None, candidates)."""
        cands = sorted(candidates)
        if len(cands) == 1:
            return cands[0], cands
        if qualified:
            root = re.split(r"\.|->", qualified)[0].strip()
            if root:
                rl = root.lower()
                # struct name == root (case-insensitive) or ends with it (Lwr<Root>)
                exact = [c for c in cands if c.lower() == rl or c.lower().endswith(rl)]
                if len(exact) == 1:
                    return exact[0], cands
        return None, cands       # genuinely ambiguous — surface candidates, don't guess

    def resolve(self, name: str, language: str, qualified: str = "") -> dict:
        """Return ``{"memberOf": {...}|None, "counterpart": {...}|None}`` for a variable."""
        self._build()
        tail = self._tail(name)
        if language == "cpp":
            key = tail.lower()
            hit = self._cpp.get(key)
            if hit:
                return {
                    "memberOf": {"language": "cpp", "kind": "struct", "name": hit["struct"]},
                    "counterpart": {"name": hit["asm"], "language": "asm",
                                    "memberOf": {"language": "asm", "kind": "mac",
                                                 "name": hit["dsect"]}},
                }
            structs = self._tail_structs.get(key)
            if structs:
                chosen, cands = self._disambiguate(structs, qualified)
                mo = {"language": "cpp", "kind": "struct", "name": chosen}
                if chosen is None:
                    mo["candidates"] = cands
                return {"memberOf": mo, "counterpart": None}
            return {"memberOf": None, "counterpart": None}      # bare local

        # ASM
        key = tail.upper()
        hit = self._asm.get(key)
        if hit:
            return {
                "memberOf": {"language": "asm", "kind": "mac", "name": hit["dsect"]},
                "counterpart": {"name": hit["cpp"], "language": "cpp",
                                "memberOf": {"language": "cpp", "kind": "struct",
                                             "name": hit["struct"]}},
            }
        dsect = self._sym_dsect.get(key)
        if dsect:
            return {"memberOf": {"language": "asm", "kind": "mac", "name": dsect},
                    "counterpart": None}
        return {"memberOf": None, "counterpart": None}


def get_membership_resolver(blueprint_dir: Path, src_dir: Path) -> MembershipResolver:
    key = (str(Path(blueprint_dir)), str(Path(src_dir)))
    cached = _CACHE.get(key)
    if cached is None:
        cached = MembershipResolver(blueprint_dir, src_dir)
        _CACHE[key] = cached
    return cached
