# Unlimited backward trace for `softCardValue` — runbook

Chain: **`aa71` → `dw730000` (DW73) → `dw710000` (callPlasticAuthenticationComponentInterface)**

> Hops are listed in chain order with the **tail (deepest) LAST**. The
> `callPlastic..` hop is the C++ function `callPlasticAuthenticationComponentInterface`
> in `dw710000.cpp`.

This is the operational sibling of [`RUNNING.md`](./RUNNING.md) — that doc is the
general guide; this one is the exact recipe for the `softCardValue` validation trace
at **uncapped (deep) traversal**.

---

## What "unlimited traversal" means

There is **no `--unlimited` flag**. The engine ships with scale-safety caps that
default *low* — most importantly `--max-dep-var-depth 1` (deep dependent-variable
recursion is opt-in at 22k scale). "Unlimited" = lift those caps so the full
dependent-variable tree expands (the way the validated `softCardValue` run produces
its full dep-var set instead of direct deps only).

If any cap is still hit, the affected setter is flagged `pathsCapped` and a dep var
`offchainSearchCapped` in the output — truncation is **never silent**, so you can see
whether to raise a limit further.

---

## New-laptop setup

Assumes the **codebase, call graph, and blueprints dir are already present**
(`jobs/baseline-temp-asm/output` + `temp/asm`). Three things are **per-machine** and
do NOT carry over with the data:

### 1. Python env (`env/` = Python 3.10)
```bash
cd /path/to/asm-modernizer
python3.10 -m venv env
env/bin/pip install -r requirements.txt      # tree-sitter, tree-sitter-cpp, etc.
```

### 2. LLVM + rebuild the C++ frontend binary
`vbt/cpp_frontend/cfg_extract` is a **native binary** linked against the local LLVM.
The committed binary will **not run** on a different machine — rebuild it:
```bash
brew install llvm                            # one-time per machine
bash vbt/cpp_frontend/build.sh               # produces vbt/cpp_frontend/cfg_extract (~30s)
```

### 3. VBT precompute (machine-local caches)
Even with the call graph + blueprints present, the **modifier/sites index, const
resolver, and cfg cache live under `vbt/.cache/`** and are machine-local. Build once:
```bash
env/bin/python3 -m vbt.precompute_all \
    --blueprint-dir jobs/baseline-temp-asm/output \
    --asm-dir       temp/asm
```
This regenerates `file_call_graph.json` if stale, builds the modifier/function index
(with concrete setter sites, MVC-complete), the enum/EQU-DC const resolver, and warms
the per-file `cfg_extract` cache in parallel. Re-runs are near-instant (disk-cached).

---

## Run the unlimited trace

```bash
env/bin/python3 -m vbt.trace \
    --variable softCardValue --language cpp \
    --hop aa71:asm \
    --hop dw730000:cpp:DW73 \
    --hop dw710000:cpp:callPlasticAuthenticationComponentInterface \
    --blueprint-dir jobs/baseline-temp-asm/output \
    --asm-dir       temp/asm \
    --max-dep-var-depth 6 \
    --max-paths        512 \
    --max-routes       2000 \
    --max-route-len    32 \
    --max-call-depth   32 \
    --max-offchain-files 1000 \
    --asm-max-levels   32 \
    --progress \
    --out vbt/_out_softCardValue.json
```

### What each lifted cap does (default in parentheses)

| Flag | Default | Effect when raised |
|---|---|---|
| `--max-dep-var-depth 6` | **1** | the real "unlimited" knob — recurse the dependent-variable tree deep, not direct-deps-only |
| `--max-paths 512` | 64 | distinct intra-file call paths enumerated per setter |
| `--max-routes 2000` | 200 | cross-file routes tail→setter (route_finder) |
| `--max-route-len 32` | 16 | cross-file route hop-length |
| `--max-call-depth 32` | 16 | edges deep when enumerating intra-file call paths |
| `--max-offchain-files 1000` | 100 | off-chain candidate files route-checked per dependent variable |
| `--asm-max-levels 32` | 16 | N-level ASM backward-CFG condition collection (matters for the `aa71` hop) |
| `--progress` | off | per-phase progress logs to STDERR (so a deep run doesn't "look hung") |

Two bounds stay source-only (edit source, not CLI): C++ early-exit local-walk
`max_blocks=6` (`vbt/conditions/cpp_conditions.py`) and resolver `#include`-follow
`_INCLUDE_MAX_DEPTH=8` (`vbt/resolve/_find_cpp_chain.py`).

---

## Python API equivalent

```python
from pathlib import Path
from vbt.engine import trace_root_variable, Hop

out = trace_root_variable(
    variable="softCardValue", language="cpp",
    chain_prefix=[
        Hop("aa71",     "asm", None),
        Hop("dw730000", "cpp", "DW73"),
        Hop("dw710000", "cpp", "callPlasticAuthenticationComponentInterface"),
    ],
    blueprint_dir=Path("jobs/baseline-temp-asm/output"),
    asm_dir=Path("temp/asm"),
    graph_file=Path("jobs/baseline-temp-asm/output/file_call_graph.json"),
    max_dep_var_depth=6,
    max_paths=512, max_routes=2000, max_route_len=32,
    max_call_depth=32, max_offchain_files=1000, asm_max_levels=32,
    progress=True,
)
```

---

## Sanity check on a fresh machine

The regression suite traces both validation vars (softCardValue C++ + LG1OSI ASM)
end-to-end against this same baseline:
```bash
env/bin/python3 -m pytest vbt/tests -q
```

### Caveat — headerless corpus
On this partial corpus the trace is **headerless**, so Clang drops some member-write
assignments and enum→int `valueResolved` values. Those resolve only when the full
22k-codebase headers are present — expected here, **not** a setup error.
