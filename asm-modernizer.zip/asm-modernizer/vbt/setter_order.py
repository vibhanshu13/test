"""DB-only Setter Ordering — ASM & C++ (flat ordered setter visits per LCA).

    variable → setter sites → function-graph LCA(s) → flat ordered setter VISITS per LCA

The public result is one flat ``setters`` array per LCA tree (NOT a nested tree). Each emitted
entry has an ``order`` index, use ``depth``, ``language``, ``file``, ``line``, and enough metadata
to explain the ordering quality.

STRICTLY ``index.db`` ONLY (mirrors ``vbt.lca_trace``): every read is an ``index.db`` artifact —
no source files, no blueprint JSON files, no live setter scans, no resolver rebuilds, no
``cfg_extract``, no disk fallbacks in the request path. The strict-DB-only setup + setter discovery
+ LCA computation is shared with ``vbt.lca_trace`` via ``_db_only_setter_lca_context``.

Ordering is STATIC CFG / source order, not observed runtime order — the DB has no branch-taken,
loop-count, data-dependent-dispatch, or transaction runtime evidence. The output never claims a
runtime order (no ``executionOrder`` / ``runtimeOrder`` fields); ASM setters carry a
``dominanceCertainty`` hint (``guaranteed`` | ``branch-alternative`` | ``unknown``) so callers do
not over-read ``blockRank``.
"""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple

from vbt.interfaces import SetterSite
from vbt.precompute import db_artifacts as DA
from vbt.lca_trace import (
    Node, DbArtifactMissing,
    _node_id, _bfs, _reverse_adjacency, _db_only_setter_lca_context, _LcaInputs,
)

logger = logging.getLogger("vbt.setter_order")

# Static order semantics (the SAME for every result; runtimeProof is always False).
_ORDER_SEMANTICS: Dict[str, Any] = {
    "kind": "static-cfg-source-order",
    "asm": "cfg-block-rank-with-dominance-hints",
    "cpp": "source-line-order",
    "runtimeProof": False,
}


# --------------------------------------------------------------------------- #
# ASM per-stem CFG / dominator reconstruction (PURE, in-memory — no disk)
# --------------------------------------------------------------------------- #
class _AsmCfg:
    """Per-stem ASM CFG view built from a blueprint BLOB (never a disk read):
    block ranks (reverse-postorder from virtual super-source), dominators (lifted pure
    fixed-point of asm_conditions.py:372-392), and per-block line ranges."""

    __slots__ = ("ok", "block_ranks", "dom", "line_ranges", "block_ids")

    def __init__(self, bp: Optional[Dict[str, Any]]):
        self.ok = False
        self.block_ranks: Dict[str, int] = {}
        self.dom: Dict[str, Set[str]] = {}
        self.line_ranges: Dict[str, Tuple[int, int]] = {}
        self.block_ids: List[str] = []
        if not bp:
            return
        blocks = bp.get("blocks") or []
        if not blocks:
            return
        from backward_traversal.tracing.asm_backward_tracer import _build_cfg_maps, _flow_line_bounds
        block_map: Dict[str, Dict[str, Any]] = {str(b.get("id", "")): b for b in blocks if b.get("id")}
        if not block_map:
            return
        cfg_out, cfg_in = _build_cfg_maps(block_map, bp)
        ids = set(block_map)
        self.block_ids = sorted(ids)

        # ---- block line ranges: start_line/end_line, else flow line bounds ----
        for bid, blk in block_map.items():
            lo = blk.get("start_line")
            hi = blk.get("end_line")
            if lo is None or hi is None:
                lr = _flow_line_bounds(blk)
                if lr:
                    lo = lr[0] if lo is None else lo
                    hi = lr[1] if hi is None else hi
            if lo is None and hi is None:
                continue
            lo = int(lo if lo is not None else hi)
            hi = int(hi if hi is not None else lo)
            self.line_ranges[bid] = (lo, hi)

        # ---- clean cfg maps to in-graph block ids only (drop $IS$ / out-of-graph) ----
        def _clean(d: Dict[str, List[Tuple[str, str]]]) -> Dict[str, List[str]]:
            out: Dict[str, List[str]] = {}
            for b in ids:
                lst: List[str] = []
                for x in (d.get(b) or []):
                    nid = str(x[0] if isinstance(x, (tuple, list)) else x)
                    if nid in ids and nid != "$IS$":
                        lst.append(nid)
                out[b] = lst
            return out

        c_out = _clean(cfg_out)
        c_in = _clean(cfg_in)

        # ---- dominators: lifted PURE fixed-point (asm_conditions.py:372-392) ----
        SS = "\x00super"
        sources = [b for b in ids if not c_in[b]]      # no in-edges ⇒ module entry
        preds = {b: set(c_in[b]) for b in ids}
        for s in sources:
            preds[s].add(SS)
        universe = set(ids) | {SS}
        dom: Dict[str, Set[str]] = {b: set(universe) for b in ids}
        dom[SS] = {SS}
        changed = True
        while changed:
            changed = False
            for b in ids:
                nd = set(universe)
                for p in preds[b]:
                    nd &= dom.get(p, {p})
                nd.add(b)
                if nd != dom[b]:
                    dom[b] = nd
                    changed = True
        self.dom = dom

        # ---- block rank: reverse-postorder from the virtual super-source, then tie-break by
        #      (start_line, id). DFS over c_out from each entry (sorted) gives a deterministic RPO. ----
        succ = c_out
        visited: Set[str] = set()
        postorder: List[str] = []

        def _dfs(start: str) -> None:
            stack: List[Tuple[str, int]] = [(start, 0)]
            while stack:
                node, idx = stack[-1]
                if idx == 0:
                    if node in visited:
                        stack.pop()
                        continue
                    visited.add(node)
                kids = succ.get(node) or []
                # advance to the next unvisited child
                while idx < len(kids) and kids[idx] in visited:
                    idx += 1
                if idx < len(kids):
                    stack[-1] = (node, idx + 1)
                    stack.append((kids[idx], 0))
                else:
                    postorder.append(node)
                    stack.pop()

        entry_order = sorted(sources, key=lambda b: (self.line_ranges.get(b, (1 << 30, 0))[0], b))
        for s in entry_order:
            if s not in visited:
                _dfs(s)
        # blocks unreachable from any entry (shouldn't happen for clean CFGs) — append deterministically.
        for b in self.block_ids:
            if b not in visited:
                postorder.append(b)
        rpo = list(reversed(postorder))
        # stable tie-break: primary = RPO position, but normalize so equal-RPO never happens
        # (RPO positions are unique). Keep RPO as the rank; line/id only matter when placing items.
        self.block_ranks = {bid: i for i, bid in enumerate(rpo)}
        self.ok = True

    def rank(self, block_id: Optional[str]) -> int:
        if block_id and block_id in self.block_ranks:
            return self.block_ranks[block_id]
        return 1 << 30                                  # unknown block → sorts last

    def block_for_line(self, line: int) -> Optional[str]:
        """The block whose line range contains ``line`` (smallest range wins on overlap)."""
        best: Optional[str] = None
        best_span = 1 << 62
        for bid, (lo, hi) in self.line_ranges.items():
            if lo <= line <= hi:
                span = hi - lo
                if span < best_span or (span == best_span and (best is None or bid < best)):
                    best = bid
                    best_span = span
        return best

    def dominates(self, a_block: Optional[str], b_block: Optional[str]) -> bool:
        """True iff ``a_block`` dominates ``b_block`` (every entry→b path goes through a)."""
        if not a_block or not b_block:
            return False
        return a_block in self.dom.get(b_block, set())


# --------------------------------------------------------------------------- #
# core
# --------------------------------------------------------------------------- #
def trace_variable_to_setter_order(
    precompute_job_id: str,
    variable: str,
    language: str,
    *,
    job_id: Optional[str] = None,
    domain: Optional[str] = None,
    candidate_stems: Optional[Sequence[str]] = None,
    home_hint: Optional[str] = None,
    allow_missing_forced_lca: bool = False,
    allow_unattributed_setters: bool = True,
    max_depth: int = 16,
    max_nodes: int = 4000,
    asm_cfg_order: bool = True,
    include_call_path: bool = False,
    blueprint_dir: Optional[str] = None,
    asm_dir: Optional[str] = None,
    graph_file: Optional[str] = None,
    debug: bool = False,
) -> Dict[str, Any]:
    """variable → LCA(s) → flat ordered setter VISITS per LCA, FULLY DB-only. See module docstring.

    Returns the ``setter_order.json`` payload (status / variable / language / orderSemantics /
    truncated / warnings / excludedSetterCount / trees[]). RAISES ``DbArtifactMissing`` (and its
    subclasses) on a missing/stale REQUIRED artifact, matching ``trace_variable_to_lca_chains`` —
    the task layer turns that into ``status:"failed"`` JSON. A missing per-stem ASM blueprint blob
    is NOT required: it degrades that one module to line order with a ``blueprint_missing`` warning
    (no disk read)."""
    t_start = time.perf_counter()

    with _db_only_setter_lca_context(
        precompute_job_id, variable, language,
        job_id=job_id, domain=domain, candidate_stems=candidate_stems, home_hint=home_hint,
        allow_missing_forced_lca=allow_missing_forced_lca,
        allow_unattributed_setters=allow_unattributed_setters,
        blueprint_dir=blueprint_dir, asm_dir=asm_dir, graph_file=graph_file,
    ) as inputs:
        builder = _OrderBuilder(
            precompute_job_id, inputs,
            max_depth=max_depth, max_nodes=max_nodes,
            asm_cfg_order=asm_cfg_order, include_call_path=include_call_path,
        )
        trees, truncated = builder.build()

    warnings = list(inputs.warnings)
    if not inputs.setter_nodes:
        warnings.append({"code": "no_setters"})

    out: Dict[str, Any] = {
        "status": "success",
        "variable": variable,
        "language": language,
        "orderSemantics": dict(_ORDER_SEMANTICS),
        "truncated": bool(truncated),
        "warnings": warnings,
        "excludedSetterCount": int(inputs.excluded),
        "trees": trees,
    }
    if debug:
        out["_debug"] = {
            "setterNodes": sorted(_node_id(n[0], n[1], inputs.node_types.get(n[0], "asm"))
                                  for n in inputs.setter_nodes),
            "lcas": [_node_id(n[0], n[1], inputs.node_types.get(n[0], "asm")) for n, _ in inputs.lca_list],
            "forcedLca": inputs.forced_lca,
            "dbOnly": True,
            "elapsedSec": round(time.perf_counter() - t_start, 3),
        }
    return out


# --------------------------------------------------------------------------- #
# ordered traversal builder
# --------------------------------------------------------------------------- #
class _OrderBuilder:
    def __init__(self, precompute_job_id: str, inputs: _LcaInputs, *,
                 max_depth: int, max_nodes: int, asm_cfg_order: bool, include_call_path: bool):
        self.job = precompute_job_id
        self.adj = inputs.adj
        self.node_types = inputs.node_types
        self.setter_sites_by_node = inputs.setter_sites_by_node
        self.lca_list = inputs.lca_list
        self.warnings = inputs.warnings
        self.max_depth = max_depth
        self.max_nodes = max_nodes
        self.asm_cfg_order = asm_cfg_order
        self.include_call_path = include_call_path
        self.rev = _reverse_adjacency(self.adj)
        self._asm_cfg_cache: Dict[str, _AsmCfg] = {}      # per-stem memo for ONE request
        self._warned_missing_bp: Set[str] = set()
        self._truncated = False

    # ---- per-request memoized ASM CFG (blob-only) ----
    def _asm_cfg(self, stem: str) -> _AsmCfg:
        cached = self._asm_cfg_cache.get(stem)
        if cached is not None:
            return cached
        bp = None
        if self.asm_cfg_order:
            payload = DA.read_blob(self.job, f"bp:{stem}.asm.json")
            bp = DA.loads_gz(payload) if payload is not None else None
            if bp is None and stem not in self._warned_missing_bp:
                self._warned_missing_bp.add(stem)
                self.warnings.append({"code": "blueprint_missing", "file": stem,
                                      "fallback": "line_order"})
        cfg = _AsmCfg(bp)
        self._asm_cfg_cache[stem] = cfg
        return cfg

    def _lang(self, stem: str) -> str:
        return self.node_types.get(stem, "asm")

    def build(self) -> Tuple[List[Dict[str, Any]], bool]:
        trees: List[Dict[str, Any]] = []
        for tree_index, (lca_node, covered) in enumerate(self.lca_list):
            tree = self._build_tree(tree_index, lca_node, covered)
            trees.append(tree)
        return trees, self._truncated

    # ---- one LCA tree ----
    def _build_tree(self, tree_index: int, lca_node: Node, covered: Sequence[Node]) -> Dict[str, Any]:
        # reachability prune: only follow edges into nodes that can reach a covered setter node.
        reachable: Set[Node] = set()
        for sn in covered:
            reachable |= _bfs(sn, self.rev)
        # the covered setter nodes themselves must be in-set (they are: _bfs includes start).

        setters: List[Dict[str, Any]] = []
        counter = {"order": 0, "nodes": 0}

        def emit(site_obj: Dict[str, Any]) -> None:
            site_obj["order"] = counter["order"]
            counter["order"] += 1
            setters.append(site_obj)

        self._dfs(lca_node, depth=0, visited=frozenset((lca_node,)),
                  reachable=reachable, emit=emit, counter=counter)

        lstem, lfn = lca_node
        lca_lang = self._lang(lstem)
        return {
            "treeIndex": tree_index,
            "lca": {
                "file": lstem,
                "function": (lfn if lca_lang == "cpp" else None),
                "language": lca_lang,
            },
            "setterCount": len(setters),
            "setters": setters,
        }

    # ---- forward DFS, per-path cycle guard, emits ordered visits ----
    def _dfs(self, node: Node, *, depth: int, visited: frozenset,
             reachable: Set[Node], emit, counter) -> None:
        if counter["nodes"] >= self.max_nodes:
            self._truncated = True
            return
        counter["nodes"] += 1

        stem, _fn = node
        lang = self._lang(stem)

        # build the ordered item list for THIS node: direct setters + outgoing call sites.
        direct = self.setter_sites_by_node.get(node, [])
        calls: List[Tuple[str, str, int, bool]] = []
        for (cs, cf, line, cross) in self.adj.get(node, set()):
            if (cs, cf) in reachable and (cs, cf) not in visited:
                calls.append((cs, cf, line, cross))

        if lang == "asm":
            items = self._order_items_asm(stem, direct, calls)
        else:
            items = self._order_items_cpp(stem, direct, calls)

        for kind, payload in items:
            if kind == "setter":
                site, meta = payload
                emit(self._setter_json(node, lang, site, depth, meta))
            else:  # call
                cs, cf, line, cross = payload
                child: Node = (cs, cf)
                if depth + 1 > self.max_depth:
                    self._truncated = True
                    continue
                self._dfs(child, depth=depth + 1, visited=visited | {child},
                          reachable=reachable, emit=emit, counter=counter)

    # ---- ASM node ordering (CFG block rank + dominance hints) ----
    def _order_items_asm(self, stem: str, direct: List[SetterSite],
                         calls: List[Tuple[str, str, int, bool]]):
        cfg = self._asm_cfg(stem)
        degraded = not cfg.ok                          # missing/malformed blob → line order

        def setter_block(s: SetterSite) -> Optional[str]:
            bid = getattr(s, "block_id", None) or None
            if not cfg.ok:
                return bid
            if bid and (bid in cfg.block_ranks or bid in cfg.line_ranges):
                return bid
            # no usable block_id → place by line range.
            return cfg.block_for_line(int(getattr(s, "line", 0) or 0))

        def call_block(line: int) -> Optional[str]:
            return cfg.block_for_line(line) if cfg.ok else None

        # one sortable record per item:
        #   (block_rank, line, kind_tiebreak, name, kind, payload, block_id)
        records: List[Tuple[int, int, int, str, str, Any, Optional[str]]] = []
        for s in direct:
            bid = setter_block(s)
            line = int(getattr(s, "line", 0) or 0)
            rank = cfg.rank(bid) if cfg.ok else line     # degraded → line order
            records.append((rank, line, 0, _setter_name(stem, s), "setter", s, bid))
        for (cs, cf, line, cross) in calls:
            cline = int(line or 0)
            bid = call_block(cline)
            rank = cfg.rank(bid) if cfg.ok else cline
            records.append((rank, cline, 1, _node_id(cs, cf, self._lang(cs)),
                            "call", (cs, cf, line, cross), bid))
        records.sort(key=lambda r: (r[0], r[1], r[2], r[3]))

        # dominance certainty per emitted ASM setter vs the OTHER item blocks in this group:
        #   guaranteed       — its block dominates every later peer item (or straight-line prefix);
        #   branch-alternative — it does NOT dominate at least one later peer;
        #   unknown          — CFG missing/degraded, no block_id, or block not in the rank map.
        item_blocks = [r[6] for r in records]
        out: List[Tuple[str, Any]] = []
        for idx, (rank, line, kt, name, kind, payload, bid) in enumerate(records):
            if kind != "setter":
                out.append(("call", payload))
                continue
            placed = bool(cfg.ok and bid and bid in cfg.block_ranks)
            if not placed:
                meta: Dict[str, Any] = {"blockId": bid, "blockRank": None,
                                        "dominanceCertainty": "unknown"}
            else:
                later = [b for j, b in enumerate(item_blocks) if j > idx and b and b != bid]
                cert = "guaranteed" if all(cfg.dominates(bid, lb) for lb in later) else "branch-alternative"
                meta = {"blockId": bid, "blockRank": cfg.rank(bid), "dominanceCertainty": cert}
            out.append(("setter", (payload, meta)))
        return out

    # ---- C++ node ordering (source / call-site line order) ----
    def _order_items_cpp(self, stem: str, direct: List[SetterSite],
                         calls: List[Tuple[str, str, int, bool]]):
        records: List[Tuple[int, int, str, str, Any]] = []
        for s in direct:
            line = int(getattr(s, "line", 0) or 0)
            records.append((line, 0, _setter_name(stem, s), "setter", s))
        for (cs, cf, line, cross) in calls:
            records.append((int(line or 0), 1, _node_id(cs, cf, self._lang(cs)), "call", (cs, cf, line, cross)))
        records.sort(key=lambda r: (r[0], r[1], r[2]))
        out: List[Tuple[str, Any]] = []
        for (line, kt, name, kind, payload) in records:
            if kind == "setter":
                out.append(("setter", (payload, None)))   # C++: no ASM dominance meta
            else:
                out.append(("call", payload))
        return out

    # ---- one setter JSON entry ----
    def _setter_json(self, node: Node, lang: str, site: SetterSite,
                     depth: int, meta: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        stem = node[0]
        line = int(getattr(site, "line", 0) or 0)
        instr = getattr(site, "instruction", None) or ""
        fn = getattr(site, "function", None)
        block_id = getattr(site, "block_id", None)
        if lang == "asm":
            site_id = f"{stem}:{line}:{block_id or ''}:{instr}"
            entry: Dict[str, Any] = {
                "depth": depth,
                "siteId": site_id,
                "file": stem,
                "function": None,
                "line": line,
                "language": "asm",
                "instruction": instr,
                "value": getattr(site, "value", None),
            }
            if meta is not None:
                entry["blockId"] = meta.get("blockId")
                entry["blockRank"] = meta.get("blockRank")
                entry["dominanceCertainty"] = meta.get("dominanceCertainty", "unknown")
            else:
                entry["blockId"] = block_id
                entry["blockRank"] = None
                entry["dominanceCertainty"] = "unknown"
        else:  # cpp
            fn_name = fn or node[1]
            site_id = f"{stem}:{line}:{fn_name}:{instr}"
            entry = {
                "depth": depth,
                "siteId": site_id,
                "file": stem,
                "function": fn_name,
                "line": line,
                "language": "cpp",
                "instruction": instr,
                "value": getattr(site, "value", None),
                "blockId": (getattr(site, "block_id", None) or f"{stem}::{fn_name}"),
            }
        return entry


def _setter_name(stem: str, s: SetterSite) -> str:
    """Deterministic tiebreak name for a setter site."""
    return f"{stem}:{int(getattr(s, 'line', 0) or 0)}:{getattr(s, 'instruction', '') or ''}"


# --------------------------------------------------------------------------- #
# CLI — dev-only --local in-process (mirrors vbt.lca_trace._cli --local)
# --------------------------------------------------------------------------- #
def _cli(argv=None) -> int:
    import argparse
    import json
    import sys

    ap = argparse.ArgumentParser(
        prog="vbt.setter_order",
        description="DB-only setter ordering (variable → LCA → flat ordered setter visits).")
    ap.add_argument("--kb-id", required=True, help="knowledge base / precompute job id")
    ap.add_argument("--variable", required=True)
    ap.add_argument("--language", default="asm", choices=["asm", "cpp"])
    ap.add_argument("--domain", default=None, help="e.g. plastic_authentication (forces LCA)")
    ap.add_argument("--allow-missing-forced-lca", action="store_true")
    ap.add_argument("--no-allow-unattributed-setters", dest="allow_unattributed_setters",
                    action="store_false",
                    help="hard-fail on an unattributable C++ setter (default: exclude+count)")
    ap.set_defaults(allow_unattributed_setters=True)
    ap.add_argument("--max-depth", type=int, default=16)
    ap.add_argument("--max-nodes", type=int, default=4000)
    ap.add_argument("--no-asm-cfg-order", dest="asm_cfg_order", action="store_false",
                    help="disable ASM CFG block ordering (use line order)")
    ap.set_defaults(asm_cfg_order=True)
    ap.add_argument("--include-call-path", action="store_true")
    ap.add_argument("--debug", action="store_true")
    ap.add_argument("--out", default=None, help="write the JSON here (default: stdout)")
    a = ap.parse_args(argv)

    # dev-only --local: run the core directly (no API/Celery), reading index.db.
    from api.config import settings
    from api.tasks._task_utils import find_blueprint_dir
    from api.storage.workspace import WorkspaceManager
    bp = find_blueprint_dir(settings.JOBS_BASE_DIR / a.kb_id / "output") or \
        (settings.JOBS_BASE_DIR / a.kb_id / "output")
    src = (WorkspaceManager(a.kb_id).get_pipeline_options() or {}).get("source_path") or ""
    result = trace_variable_to_setter_order(
        a.kb_id, a.variable, a.language, domain=a.domain,
        allow_missing_forced_lca=a.allow_missing_forced_lca,
        allow_unattributed_setters=a.allow_unattributed_setters,
        max_depth=a.max_depth, max_nodes=a.max_nodes,
        asm_cfg_order=a.asm_cfg_order, include_call_path=a.include_call_path,
        blueprint_dir=str(bp), asm_dir=str(src), debug=a.debug)
    payload = json.dumps(result, indent=2, default=str)
    if a.out:
        Path(a.out).write_text(payload)
        print(f"wrote {a.out} — {len(result.get('trees', []))} trees", file=sys.stderr)
    else:
        print(payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
