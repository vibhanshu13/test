"""VBT-local HLASM trigger-opcode extensions for condition collection.

The condition extractor (:mod:`vbt.conditions.asm_conditions`) recognizes a guard
by pairing a TRIGGER (a compare/test that sets the condition code) with a following
conditional branch, then :mod:`vbt.depvars.extract` harvests the trigger's storage
operand as a dependency.  The reused, read-only
``backward_traversal.glossary.instructions.TRIGGER_INST`` set omits several
CC-setting compares that occur in the z/TPF corpus — so their guards were SILENTLY
dropped (the pairing never formed → no Condition → the guarded field never became
a dependency).

Per SPEC constraint #4 (VBT reuses the shared glossary read-only, never mutates it
in place), the missing trigger opcodes live HERE, in the engine layer, and are
UNIONed with the imported ``TRIGGER_INST`` / ``MASK_TRIGGER_AT_ARG1`` by the
consumers.  This mirrors the existing VBT-local extension pattern in
:mod:`vbt.resolve.asm_indirect_glossary` (REGISTER_LOAD_FROM_MEM_EXT etc.).

Operand layout (IBM z/Architecture PoO SA22-7832):

* **TP** (TEST DECIMAL, RSL, opcode EBC0) — single storage operand at args[0];
  tests that the storage field holds valid packed-decimal data and sets the CC.
  The storage field is the dependency (args[0]).
* **CHHSI** (COMPARE HALFWORD IMMEDIATE, SIL, opcode E554) — args[0] is the 16-bit
  storage halfword (operand-1), args[1] is the 16-bit signed IMMEDIATE (operand-2).
* **CLHHSI** (COMPARE LOGICAL IMMEDIATE, SIL, opcode E555) — args[0] storage
  halfword (operand-1), args[1] 16-bit logical IMMEDIATE (operand-2).
* **CGFI** (COMPARE IMMEDIATE 64←32, RIL-a, opcode C2C) — args[0] is a register
  (operand-1, filtered by the register/token checks), args[1] the 32-bit signed
  IMMEDIATE.

For CHHSI/CLHHSI the second operand (args[1]) is ALWAYS a compile-time immediate,
so they are also marked mask/immediate-at-arg1 — exactly like CLI/TM in
``MASK_TRIGGER_AT_ARG1`` — so the immediate is not harvested as a spurious
dependency (a symbolic-EQU immediate would otherwise slip past the literal token
filters).  CGFI's args[1] is a plain numeric immediate already rejected by the
token filters, and its args[0] is a register, so it needs no arg1 suppression.
"""
from __future__ import annotations

from typing import FrozenSet

# CC-setting compares missing from the reused TRIGGER_INST.  Unioned with
# TRIGGER_INST so vbt.conditions.asm_conditions pairs them with a branch and emits
# the guard Condition (which vbt.depvars.extract then harvests for dependencies).
TRIGGER_INST_EXT: FrozenSet[str] = frozenset({
    "TP",       # TEST DECIMAL (RSL)          — storage operand args[0]
    "CHHSI",    # COMPARE HALFWORD IMMEDIATE  (SIL) — storage args[0], immediate args[1]
    "CLHHSI",   # COMPARE LOGICAL IMMEDIATE   (SIL) — storage args[0], immediate args[1]
    "CGFI",     # COMPARE IMMEDIATE 64<-32    (RIL) — register args[0], immediate args[1]
})

# Trigger opcodes whose args[1] is ALWAYS a constant immediate (operand-2 of the
# SIL-format compares).  Unioned with MASK_TRIGGER_AT_ARG1 so the dep-var extractor
# harvests only args[0] (the storage field) and never the immediate.
MASK_TRIGGER_AT_ARG1_EXT: FrozenSet[str] = frozenset({
    "CHHSI",
    "CLHHSI",
})

__all__ = (
    "TRIGGER_INST_EXT",
    "MASK_TRIGGER_AT_ARG1_EXT",
)
