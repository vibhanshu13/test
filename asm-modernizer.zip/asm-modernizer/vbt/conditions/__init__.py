"""Condition collectors: asm_conditions (improved CFG walk) + cpp_conditions (Clang CFG)."""
