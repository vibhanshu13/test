"""C++ intra-function condition collection (SPEC §5).

Given a setter line, compute the **necessary** guard conditions to reach that
line from the function entry. The guards come from two complementary sources:

  1. PRIMARY — the AST enclosing-guard regions emitted by ``cfg_extract``
     (``guard_regions``). Each region is one ``if`` / ``switch-case`` / loop
     branch tagged with the source-line span of its body and its full condition
     expression + polarity. A region guards the setter iff the setter line lies
     within its span. This is robust by construction:

       - ``||`` / ``&&`` come out whole (the full ``IfStmt`` condition), so the
         short-circuit CFG blocks that defeated the old dominator test are gone;
       - switch fallthrough is an OR-of-cases (``sel == 1 || sel == 2``);
       - ``else`` branches carry the negated polarity;
       - a member-write whose type is unresolved (headerless) is dropped from
         the CFG, but its enclosing if/switch BODY SPAN is still computed from
         the real AST, so line-containment still attaches the right guards
         (the ⑤-B1 fix);
       - a sibling branch that merely reconverges before the setter does NOT
         contain the setter line, so it is naturally excluded.

  2. EARLY-EXIT NEGATIVES — the one thing AST nesting cannot express. A guard
     ``if (c) { return | break | continue | goto … }`` that sits *before* the
     setter and whose taken edge bypasses the setter implies ``!(c)`` on every
     surviving path to the setter. We recover these from the CFG: a 2-way branch
     block, before the setter, one of whose edges cannot reach the setter while
     the other can, where the bypassing edge leads to an exit/jump.

``collect_cpp_conditions(cpp_path, setter_line, fn_name=None, *, functions=None)``
is preserved (the engine + dep-var recursion depend on it).
"""
from __future__ import annotations

import copy
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from vbt.interfaces import Condition, Location
from vbt.cpp_frontend.wrapper import run_cfg_extract


# --------------------------------------------------------------------------- #
# AST/CFG condition memoization (perf; byte-identical)
# --------------------------------------------------------------------------- #
# The same (file, setter_line, fn) is queried repeatedly across a route/precompute build
# (every edge of a caller stem re-collects guards at the SAME call-site lines), and the
# guard computation (AST region scan + CFG dominators + early-exit) is non-trivial. Memoize
# the result keyed by the file's (mtime, size) — a robust file-version proxy that is
# job/copy-safe: a re-ingested or copied file with a different mtime/size misses the stale
# cache (preventing cross-job poisoning in Celery). ``collect_cpp_conditions`` is a pure
# function of (file-content, setter_line, fn_name) — the optional ``functions`` arg is itself
# derived from the same file via ``run_cfg_extract`` — so memoizing on the file-version proxy
# is byte-identical. We return shallow copies so a caller that mutates a returned Condition
# never corrupts the cached list (no caller currently mutates, but this keeps it safe).
# Cache key: (resolved_path, mtime, size, setter_line, fn_name), or a load-only
# DB-trace key that skips filesystem stat/resolve because precompute owns
# source freshness for that process.
_CPP_COND_CACHE: Dict[Tuple[Any, ...], List[Condition]] = {}
_CPP_COND_CACHE_MAX = 100_000          # FIFO bound (recompute on miss is byte-identical)

# str(path) -> resolved str. Path.resolve() walks the filesystem (realpath + getcwd — ~7s of
# a 38s phase A when built per call) but depends only on the PATH, never the file's content,
# so caching it forever is safe. The (mtime, size) version proxy is deliberately NOT cached —
# it must be re-stat'ed per call so a re-ingested/changed file still misses the memo
# (cross-job poisoning guard).
_RESOLVED_PATH_CACHE: Dict[str, str] = {}
_RESOLVED_PATH_CACHE_MAX = 50_000


def _resolved_path(cpp_path: Path) -> str:
    raw = str(cpp_path)
    rp = _RESOLVED_PATH_CACHE.get(raw)
    if rp is None:
        rp = str(cpp_path.resolve())
        if len(_RESOLVED_PATH_CACHE) >= _RESOLVED_PATH_CACHE_MAX:
            _RESOLVED_PATH_CACHE.pop(next(iter(_RESOLVED_PATH_CACHE)))
        _RESOLVED_PATH_CACHE[raw] = rp
    return rp


def _cpp_cond_cache_put(key, value) -> None:
    """Insert into the memo with a FIFO size bound (mirrors the engine's other LRU/FIFO caches)."""
    if len(_CPP_COND_CACHE) >= _CPP_COND_CACHE_MAX:
        _CPP_COND_CACHE.pop(next(iter(_CPP_COND_CACHE)))
    _CPP_COND_CACHE[key] = value


def clear_cpp_conditions_cache() -> None:
    """Clear the AST/CFG condition memo. Call at the END of a trace / precompute run so the
    cache never outlives the source snapshot it was built against (the (mtime,size) key already
    guards against stale hits, but clearing bounds memory across long-lived processes)."""
    _CPP_COND_CACHE.clear()
    _RESOLVED_PATH_CACHE.clear()


# --------------------------------------------------------------------------- #
# Function selection
# --------------------------------------------------------------------------- #
def _fn_line_span(f: Dict) -> Tuple[Optional[int], Optional[int]]:
    """Overall source-line span of a function, from its CFG stmts AND guard
    regions (so it still contains a setter line whose own stmt was dropped).

    PERF: cached on the cfg fn dict — ``_select_function`` calls this for every function on
    every setter, so a heavy variable re-walks the same functions' stmts thousands of times.
    Pure function of the cfg ⇒ byte-identical."""
    cached = f.get("_line_span_cache")
    if cached is not None:
        return cached
    lo: Optional[int] = None
    hi: Optional[int] = None

    def upd(v):
        nonlocal lo, hi
        if not v:
            return
        lo = v if lo is None else min(lo, v)
        hi = v if hi is None else max(hi, v)

    for b in f.get("cfg_blocks", []):
        for s in b.get("stmts", []):
            upd(s.get("line"))
    for g in f.get("guard_regions", []):
        upd(g.get("start_line"))
        upd(g.get("end_line"))
        upd(g.get("line"))
    f["_line_span_cache"] = (lo, hi)
    return lo, hi


def _fn_name_matches(name: str, q: str) -> bool:
    """Exact or qualified-boundary function-name match (B4). A bare ``endswith``
    is unsound — ``myrxTail`` would match ``rxTail`` and pick the wrong function;
    require either an exact match or a ``::``-qualified suffix boundary."""
    return bool(name) and (name == q or name.endswith("::" + q))


def _select_function(functions: List[Dict], setter_line: int, fn_name: Optional[str]) -> Optional[Dict]:
    """Pick the function enclosing ``setter_line``, preferring an ``fn_name`` match."""
    containing: List[Dict] = []
    for f in functions:
        lo, hi = _fn_line_span(f)
        if lo is not None and hi is not None and lo <= setter_line <= hi:
            containing.append(f)
    if fn_name:
        for f in containing:
            if _fn_name_matches(f.get("function", ""), fn_name):
                return f
    if containing:
        # Tightest enclosing span wins when several overlap (nested lambdas etc.).
        containing.sort(key=lambda f: (lambda s: (s[1] or 0) - (s[0] or 0))(_fn_line_span(f)))
        return containing[0]
    if fn_name:
        for f in functions:
            if _fn_name_matches(f.get("function", ""), fn_name):
                return f
    return None


# --------------------------------------------------------------------------- #
# AST guard regions (PRIMARY)
# --------------------------------------------------------------------------- #
def _clean(expr: str) -> str:
    """Strip comments + collapse whitespace from a condition expression."""
    raw = expr or ""
    raw = re.sub(r"/\*.*?\*/", " ", raw, flags=re.S)
    raw = re.sub(r"//[^\n]*", " ", raw)
    out = " ".join(raw.split())
    # Defensive: strip a stray LEADING `case ` label prefix only (a collapsed-switch
    # fallback can leave one). Anchored at the start so `case` inside a string literal
    # mid-expression (e.g. `s == "in case of error"`) is never corrupted (A5).
    out = re.sub(r"^\s*case\s+", "", out)
    return out


def _render_guard(expr: str, polarity: Optional[bool], kind: str) -> Tuple[str, Optional[bool]]:
    """Apply polarity to a guard expression for human display.

    ``polarity is False`` negates the predicate (``!(expr)``); ``True`` (or a
    ``default``-case guard with ``polarity is None``) keeps it as written.
    """
    e = _clean(expr)
    if polarity is False:
        return f"!({e})", False
    return e, polarity


def _ast_guards(fn: Dict, setter_line: int, cpp_path: str) -> List[Condition]:
    """Guards whose AST branch-body span contains ``setter_line`` (outer→inner)."""
    regions = [
        g for g in fn.get("guard_regions", [])
        if g.get("start_line") and g.get("end_line")
        and g["start_line"] <= setter_line <= g["end_line"]
        and (g.get("expr") or "").strip()
    ]
    # Outer→inner: widest span first; tie-break by controlling line.
    regions.sort(key=lambda g: (g["start_line"] - g["end_line"], g.get("line") or 0))
    out: List[Condition] = []
    seen: Set[Tuple[str, Optional[bool]]] = set()
    for g in regions:
        text, polarity = _render_guard(g["expr"], g.get("polarity"), g.get("kind") or "if")
        key = (text, polarity)
        if key in seen:
            continue
        seen.add(key)
        cline = g.get("line") or g["start_line"]
        out.append(Condition(
            order=len(out) + 1,
            condition=text,
            block_id=f"{fn.get('function')}#guard",
            location=Location(file=cpp_path, start_line=cline, end_line=cline),
            polarity=polarity,
            kind=("loop" if g.get("kind") == "loop"
                  else "switch" if g.get("kind") == "switch"
                  else "early_exit" if g.get("kind") == "early_exit" else "if"),
        ))
    return out


# --------------------------------------------------------------------------- #
# CFG early-exit negatives (the one thing AST nesting can't express)
# --------------------------------------------------------------------------- #
def _block_lines(b: Dict) -> Tuple[Optional[int], Optional[int]]:
    ls = [s.get("line") for s in b.get("stmts", []) if s.get("line")]
    return (min(ls), max(ls)) if ls else (None, None)


def _map_line_to_block(blocks: Dict[int, Dict], setter_line: int) -> Optional[int]:
    """Block of the surviving statement at/after the setter line (else the
    nearest one below). The early-exit scan only needs an anchor block from
    which the setter is reachable; exact membership isn't required."""
    ge: List[Tuple[int, int]] = []
    le: List[Tuple[int, int]] = []
    for bid, b in blocks.items():
        for s in b.get("stmts", []):
            ln = s.get("line")
            if not ln:
                continue
            if ln >= setter_line:
                ge.append((ln, bid))
            if ln <= setter_line:
                le.append((ln, bid))
    if ge:
        ge.sort()
        return ge[0][1]
    if le:
        le.sort()
        return le[-1][1]
    return None


_FN_EXIT = {"return", "goto", "indirect_goto"}      # bypass the setter for good
_LOOP_EXIT = {"break", "continue"}                  # only bypass code WITHIN the loop
_LOOP_LATCH_KINDS = {"do", "while", "for"}          # CFG terminator kind of a loop latch/condition block


def _block_jump_kind(b: Dict) -> Optional[str]:
    """The unconditional control-transfer kind this block performs, if any:
    return / goto (function/forward exit) or break / continue (loop-scoped). We
    look at BOTH the terminator kind and the block's statements (a return/break
    often appears as a statement with the terminator left as ``none``)."""
    tk = b.get("terminator_kind")
    if tk in _FN_EXIT or tk in _LOOP_EXIT:
        return "goto" if tk == "indirect_goto" else tk
    for s in b.get("stmts", []):
        k = s.get("kind")
        if k in _FN_EXIT or k in _LOOP_EXIT:
            return k
    return None


def _edge_exit_kind(blocks: Dict[int, Dict], start: int, setter_block: int,
                    max_blocks: int = 6) -> Optional[str]:
    """If this edge heads (within a short unconditional chain) into a
    return/break/continue/goto WITHOUT first landing on the setter block, return
    that jump KIND; else None.

    Purposely *local*: follows only single forward edges so a loop back-edge can't
    make a continue/break look like it "re-reaches" the setter. Returning the kind
    (not just a bool) lets the caller apply loop-containment to break/continue,
    which — unlike return/goto — only bypass code *within* the loop (A2)."""
    cur = start
    seen: Set[int] = set()
    steps = 0
    while cur in blocks and cur not in seen and steps < max_blocks:
        if cur == setter_block:
            return None
        seen.add(cur)
        steps += 1
        b = blocks[cur]
        k = _block_jump_kind(b)
        if k:
            return k
        nxt = [s.get("block_id") for s in b.get("succs", [])
               if s.get("block_id") in blocks]
        if len(nxt) != 1:        # not a simple jump chain → not an early-exit arm
            return None
        cur = nxt[0]
    return None


def _cfg_dominators(blocks: Dict[int, Dict]) -> Optional[Dict[int, Set[int]]]:
    """Standard iterative dominators over the function CFG. Returns ``{block: set of
    blocks that dominate it}`` (a block always dominates itself), or None if the entry
    can't be determined.

    A branch block ``D`` dominates a setter block ``B`` iff ``D in dom[B]`` — i.e. EVERY
    path from the entry to ``B`` passes through ``D``. This is the sound, fragmentation-
    immune basis for the early-exit gate: an ``if(c){return/break/…}`` only contributes a
    necessary ``!(c)`` when its branch dominates the setter (a branch the setter can reach
    by BYPASSING it does not). Unlike AST-span containment, dominance is unaffected by
    cfg_extract splitting one switch-case body into several guard regions."""
    ids = set(blocks)
    if not ids:
        return None
    succ = {i: [s.get("block_id") for s in blocks[i].get("succs", [])
                if s.get("block_id") in blocks] for i in ids}
    incoming: Set[int] = set()
    for i in ids:
        incoming.update(succ[i])
    no_in = [i for i in ids if i not in incoming]
    # Unique source = entry; else Clang numbers the CFG Entry block highest.
    entry = no_in[0] if len(no_in) == 1 else max(ids)
    preds: Dict[int, List[int]] = {i: [] for i in ids}
    for i in ids:
        for j in succ[i]:
            preds[j].append(i)
    dom: Dict[int, Set[int]] = {i: set(ids) for i in ids}
    dom[entry] = {entry}
    changed = True
    while changed:
        changed = False
        for i in ids:
            if i == entry:
                continue
            ps = preds[i]
            new = set(ids)
            if ps:
                for p in ps:
                    new &= dom[p]
            else:
                new = set()          # unreachable from entry → dominated only by itself
            new.add(i)
            if new != dom[i]:
                dom[i] = new
                changed = True
    return dom


# --------------------------------------------------------------------------- #
# CFG loop-break negatives (GAP 2 — the search-loop match condition)
# --------------------------------------------------------------------------- #
# A search loop ``do { … if(match) break; … } while(more); if(!found) return;`` reaches the
# code after the loop ONLY when it exited via the ``break`` (matched) — the normal loop exit
# (``more`` false) is filtered out by the post-loop ``if(!found) return``. The condition(s)
# that gate the ``break`` are therefore necessary to reach any setter after the loop, but they
# are invisible to:
#   - AST nesting (the break's enclosing ``if`` does not contain the post-loop setter line);
#   - the dominance-based early-exit gate above (the break block does NOT dominate the setter —
#     the normal loop-exit path reaches it too, structurally).
# We recover them from the CFG by recognising the idiom: a post-loop 2-way guard ``D`` whose
# exit predicate is the negation of the loop latch's continue predicate (``!found`` ↔ ``more``),
# fed by the latch AND one-or-more ``break`` blocks. The guards dominating every break (inside
# the loop, with one arm to the break and the other back to the latch) are then necessary.
def _fully_wrapped(s: str) -> bool:
    """True iff a single outer ``( … )`` pair spans the whole string."""
    if not (s.startswith("(") and s.endswith(")")):
        return False
    depth = 0
    for i, ch in enumerate(s):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                return i == len(s) - 1
    return False


def _strip_outer_neg(expr: str) -> Tuple[str, bool]:
    """Strip matched outer ``!( … )`` layers → ``(core, negated)`` (collapses double-negation)."""
    e = (expr or "").strip()
    negated = False
    while e.startswith("!"):
        rest = e[1:].strip()
        if _fully_wrapped(rest):
            e = rest[1:-1].strip()
            negated = not negated
        else:
            break
    return e, negated


def _norm_neg(expr: str) -> Tuple[str, bool]:
    return _strip_outer_neg(_clean(expr))


def _reaches_without_passing_through(start: int, target: int, avoid: Set[int],
                                     blocks: Dict[int, Dict]) -> bool:
    """Reachability over forward edges that never enters ``avoid``. With the loop latch in
    ``avoid`` the search stays inside the loop body (visits very few blocks)."""
    if start == target:
        return True
    if start in avoid:
        return False
    seen: Set[int] = set()
    stack = [start]
    while stack:
        cur = stack.pop()
        if cur in seen or cur in avoid:
            continue
        seen.add(cur)
        if cur == target:
            return True
        b = blocks.get(cur)
        if not b:
            continue
        for s in b.get("succs", []):
            nxt = s.get("block_id")
            if nxt in blocks and nxt not in seen and nxt not in avoid:
                stack.append(nxt)
    return False


def _reaches(start: int, target: int, blocks: Dict[int, Dict]) -> bool:
    """Full structural reachability (cycles allowed)."""
    return _reaches_without_passing_through(start, target, set(), blocks)


def _extract_loop_breaks(blocks: Dict[int, Dict],
                         dom: Optional[Dict[int, Set[int]]]) -> List[Tuple[int, List[Tuple[str, bool, int]]]]:
    """Find search-loop patterns and the necessary break-guards. Returns
    ``[(D_block, [(text, polarity, line), …]), …]`` where ``D`` is the post-loop guard that
    must dominate a setter for its guards to apply. SETTER-INDEPENDENT: computed once per
    function and cached on the cfg fn dict (``_loop_break_cache``)."""
    if dom is None:
        return []
    # Fast path: no loop latch → nothing to do (the common case; one O(blocks) scan).
    if not any(b.get("terminator_kind") in _LOOP_LATCH_KINDS for b in blocks.values()):
        return []
    # Predecessor map (O(E)).
    preds: Dict[int, List[int]] = {bid: [] for bid in blocks}
    for bid, b in blocks.items():
        for s in b.get("succs", []):
            t = s.get("block_id")
            if t in preds:
                preds[t].append(bid)

    results: List[Tuple[int, List[Tuple[str, bool, int]]]] = []
    for D, db in blocks.items():
        if db.get("terminator_kind") != "if":
            continue
        arms = {s.get("label"): s.get("block_id") for s in db.get("succs", [])
                if s.get("block_id") in blocks}
        t_arm, f_arm = arms.get("true"), arms.get("false")
        if t_arm is None or f_arm is None:
            continue
        Dc = _clean(db.get("terminator_cond_expr") or "")
        if not Dc:
            continue
        # Classify D's predecessors: exactly one loop latch (whose loop-exit/false edge
        # targets D) + one-or-more breaks + nothing else (else the shape is not a clean
        # search loop → bail, sound under-collection).
        latches, breaks, other = [], [], []
        for p in preds[D]:
            pb = blocks[p]
            if pb.get("terminator_kind") in _LOOP_LATCH_KINDS:
                false_t = next((s.get("block_id") for s in pb.get("succs", [])
                                if s.get("label") == "false"), None)
                (latches if false_t == D else other).append(p)
            elif _block_jump_kind(pb) == "break":
                breaks.append(p)
            else:
                other.append(p)
        if len(latches) != 1 or len(breaks) < 1 or other:
            continue
        L = latches[0]
        Lc = _clean(blocks[L].get("terminator_cond_expr") or "")
        if not Lc:
            continue
        # Which arm of D exits the function (return/goto)? Exactly one must.
        t_k = _edge_exit_kind(blocks, t_arm, None)
        f_k = _edge_exit_kind(blocks, f_arm, None)
        t_exit = t_k in _FN_EXIT or t_k == "goto"
        f_exit = f_k in _FN_EXIT or f_k == "goto"
        if t_exit == f_exit:
            continue
        Dexit = Dc if t_exit else f"!({Dc})"
        # Polarity coupling (the soundness fingerprint): D's exit predicate must equal the
        # loop's normal-exit predicate ``!Lc`` (taking the latch's false edge forces D to exit).
        if _norm_neg(Dexit) != _norm_neg(f"!({Lc})"):
            continue
        # Intersection of the dominators of EVERY break predecessor: a guard necessary for the
        # break must dominate all of them (closes the multiple-break soundness hole).
        dom_inter: Optional[Set[int]] = None
        for p in breaks:
            dp = dom.get(p, set())
            dom_inter = set(dp) if dom_inter is None else (dom_inter & dp)
        if not dom_inter:
            continue
        avoid = {L}
        guards: List[Tuple[str, bool, int]] = []
        seen_txt: Set[str] = set()
        for C in dom_inter:
            cb = blocks[C]
            if cb.get("terminator_kind") != "if":     # whole-condition only; skips &&/|| fragments
                continue
            carms = {s.get("label"): s.get("block_id") for s in cb.get("succs", [])
                     if s.get("block_id") in blocks}
            ct, cf = carms.get("true"), carms.get("false")
            if ct is None or cf is None:
                continue
            Cc = _clean(cb.get("terminator_cond_expr") or "")
            if not Cc:
                continue
            # LOOP-INTERNAL DIVERGENCE: exactly one arm reaches the break set (avoiding the
            # latch) and the OTHER arm returns to the latch L (continues the loop). This keeps
            # the in-loop break guards and excludes BOTH reconverging guards (both arms reach
            # the break) AND pre-loop guards (whose non-break arm exits/diverges, never reaching
            # L). It is setter-independent, so the per-setter emit needs no reachability.
            t_brk = all(_reaches_without_passing_through(ct, p, avoid, blocks) for p in breaks)
            f_brk = all(_reaches_without_passing_through(cf, p, avoid, blocks) for p in breaks)
            t_any = any(_reaches_without_passing_through(ct, p, avoid, blocks) for p in breaks)
            f_any = any(_reaches_without_passing_through(cf, p, avoid, blocks) for p in breaks)
            if t_brk and not f_any and _reaches(cf, L, blocks):
                text, polarity = Cc, True
            elif f_brk and not t_any and _reaches(ct, L, blocks):
                text, polarity = f"!({Cc})", False
            else:
                continue
            if text in seen_txt:
                continue
            seen_txt.add(text)
            line = _block_lines(cb)[1] or _block_lines(cb)[0] or 0
            guards.append((text, polarity, line))
        if guards:
            results.append((D, guards))
    return results


def _early_exit_negatives(fn: Dict, setter_line: int, cpp_path: str,
                          start_order: int) -> List[Condition]:
    """Recover ``!(c)`` for any pre-setter ``if(c){ return|break|continue|goto }``
    whose taken arm exits/jumps past the setter (so reaching the setter on a
    surviving path implies the negation of that arm's condition).

    AST nesting can't express this (the setter is NOT inside the guard's body —
    the guard just skips over it), which is why it lives here. A plain
    reconverging sibling does NOT jump out, so it is correctly ignored."""
    blocks: Dict[int, Dict] = {b["id"]: b for b in fn.get("cfg_blocks", [])}
    if not blocks:
        return []
    B = _map_line_to_block(blocks, setter_line)
    if B is None:
        return []

    # A1: spans of collapsed switches (dependent scrutinee → Clang dropped the cases
    # → the CFG inside collapsed too). Early-exit negatives derived from branches
    # INSIDE such a region are unreliable (wrong polarity / spurious), so skip them;
    # the recovered case guards + AST guards still apply, and pre-switch early
    # returns (outside the region) are kept.
    collapsed_spans = [(g["start_line"], g["end_line"]) for g in fn.get("guard_regions", [])
                       if g.get("kind") == "collapsed_switch"
                       and g.get("start_line") and g.get("end_line")]

    def _in_collapsed(ln: int) -> bool:
        return any(lo <= ln <= hi for lo, hi in collapsed_spans)

    # If the setter itself sits inside a collapsed switch, that whole region's CFG
    # is unreliable (synthetic line-0 blocks, mis-wired edges). We then trust ONLY
    # early-exit branches strictly BEFORE the switch (genuine pre-switch returns);
    # everything at/after the switch start is discarded rather than emitted wrong.
    # If the setter sits inside a collapsed switch, the WHOLE function's CFG
    # reachability is corrupted (orphaned islands + mis-wired edges reaching into
    # the collapsed region), so NO early-exit inference is trustworthy here — even
    # branches physically before the switch are mis-analysed. Emit only the AST +
    # recovered case guards (sound: omit rather than fabricate). 22k (headers
    # present) never collapses, so this degradation is headerless-corpus only.
    if any(lo <= setter_line <= hi for lo, hi in collapsed_spans):
        return []

    # CFG dominators, computed once PER FUNCTION and cached on the cfg fn dict — the same
    # function is re-analysed for every setter inside it across the per-route build, so without
    # this the dominator solve reruns thousands of times. Pure function of the cfg ⇒ identical.
    if "_dom_cache" not in fn:
        fn["_dom_cache"] = _cfg_dominators(blocks)
    dom = fn["_dom_cache"]

    out: List[Condition] = []
    order = start_order
    seen: Set[str] = set()
    for D, b in blocks.items():
        if D == B:
            continue
        if b.get("terminator_kind") != "if":
            continue
        cond_expr = (b.get("terminator_cond_expr") or "").strip()
        succs = b.get("succs", [])
        if not cond_expr or len(succs) < 2:
            continue
        # The branch must sit at/before the setter line (a guard that runs
        # before the setter on the path).
        lo_b, hi = _block_lines(b)
        if hi is not None and hi > setter_line:
            continue
        # A1: collapsed-switch CFG is unreliable. If the SETTER is inside one, trust
        # only branches strictly before the switch; otherwise just skip any branch
        # that itself sits inside a collapsed region.
        bl = hi or lo_b or 0
        # A branch physically inside a collapsed switch has unreliable edges — skip
        # it (the setter here is OUTSIDE any collapsed region; the all-collapsed
        # case already returned []).
        if _in_collapsed(bl):
            continue
        # Classify each labeled arm: which exits/jumps (and HOW), which falls through.
        arms = {s.get("label"): s.get("block_id") for s in succs
                if s.get("block_id") in blocks}
        true_b = arms.get("true")
        false_b = arms.get("false")
        if true_b is None or false_b is None:
            continue
        true_kind = _edge_exit_kind(blocks, true_b, B)
        false_kind = _edge_exit_kind(blocks, false_b, B)
        true_exit = true_kind is not None
        false_exit = false_kind is not None
        # Exactly one arm is the early-exit; the surviving (other) arm's polarity
        # is what holds on every path that reaches the setter.
        if true_exit == false_exit:
            continue
        # SOUNDNESS — CFG DOMINANCE. Emit !(c) ONLY when this branch BLOCK dominates the
        # setter block (every path from entry to the setter passes through the branch).
        # A branch nested under a conditional the setter can BYPASS does not dominate it,
        # so its negation is NOT necessary — this suppresses the fabricated guard (#1).
        # Fragmentation-immune (unlike AST-span containment, which a switch-case body is
        # split into pieces), so a switch-case `break` guard is correctly KEPT (#2).
        # Uniform over return/goto/break/continue; subsumes the old loop containment.
        if dom is None or D not in dom.get(B, set()):
            continue
        if true_exit:
            # `if (c) <exit>;`  -> reaching setter means c was FALSE -> !(c)
            e = _clean(cond_expr)
            text, polarity = f"!({e})", False
        else:
            # `if (c) {…} else <exit>;` -> reaching setter means c was TRUE -> c
            text, polarity = _clean(cond_expr), True
        if text in seen:
            continue
        seen.add(text)
        order += 1
        cline = hi or _block_lines(b)[0] or 0
        out.append(Condition(
            order=order,
            condition=text,
            block_id=f"{fn.get('function')}#early_exit",
            location=Location(file=cpp_path, start_line=cline, end_line=cline),
            polarity=polarity,
            kind="early_exit",
        ))

    # LOOP-BREAK NEGATIVES (GAP 2): the search-loop match condition. The patterns are
    # setter-independent, so they are precomputed once per function and cached on the cfg fn
    # dict (mirrors _dom_cache). Per setter we only emit the guards of a pattern whose post-loop
    # guard D dominates the setter block B — O(loops), no reachability on this hot path.
    if "_loop_break_cache" not in fn:
        fn["_loop_break_cache"] = _extract_loop_breaks(blocks, dom)
    for D, guards in fn["_loop_break_cache"]:
        if dom is None or D not in dom.get(B, set()):
            continue
        for text, polarity, gline in guards:
            if text in seen:
                continue
            seen.add(text)
            order += 1
            out.append(Condition(
                order=order,
                condition=text,
                block_id=f"{fn.get('function')}#loop_break",
                location=Location(file=cpp_path, start_line=gline, end_line=gline),
                polarity=polarity,
                kind="loop_break",
            ))
    return out


# --------------------------------------------------------------------------- #
# Public API (preserved signature)
# --------------------------------------------------------------------------- #
def collect_cpp_conditions(
    cpp_path: str | Path,
    setter_line: int,
    fn_name: Optional[str] = None,
    *,
    functions: Optional[List[Dict]] = None,
) -> List[Condition]:
    cpp_path = Path(cpp_path)

    # Memo lookup — scoped by the file's (mtime, size) so a changed/re-ingested file misses.
    load_only_key = False
    if functions is not None:
        try:
            from vbt.precompute import db_artifacts as _DA
            load_only_key = _DA.is_load_only()
        except Exception:
            load_only_key = False
    if load_only_key:
        _ck = ("load_only", str(cpp_path), int(setter_line), fn_name)
    else:
        try:
            _st = cpp_path.stat()
            _mtime, _size = _st.st_mtime, _st.st_size
        except OSError:
            _mtime, _size = 0.0, 0
        _ck = (_resolved_path(cpp_path), _mtime, _size, int(setter_line), fn_name)
    _hit = _CPP_COND_CACHE.get(_ck)
    if _hit is not None:
        return [copy.copy(c) for c in _hit]

    if functions is None:
        try:
            functions = run_cfg_extract(str(cpp_path))
        except (FileNotFoundError, RuntimeError):
            _cpp_cond_cache_put(_ck, [])
            return []
    fn = _select_function(functions, setter_line, fn_name)
    if not fn:
        _cpp_cond_cache_put(_ck, [])
        return []

    path_str = str(cpp_path)
    # PRIMARY: AST enclosing-guard regions (outer→inner).
    out = _ast_guards(fn, setter_line, path_str)
    # ADDITIONAL: early-exit negatives from the CFG, deduped against the AST guards
    # (A3 — an if whose false arm flows into the function-epilogue return is both an
    # AST guard of the surviving arm AND looks like an early-exit; keep it once).
    ast_keys = {(c.condition, c.polarity) for c in out}
    for c in _early_exit_negatives(fn, setter_line, path_str, start_order=len(out)):
        if (c.condition, c.polarity) in ast_keys:
            continue
        ast_keys.add((c.condition, c.polarity))
        out.append(c)

    # FALLBACK (truncation only): if the line sits PAST the cfg's BLOCK coverage — the
    # last line Clang actually modeled control flow for — its CFG builder truncated the
    # body before it (a brace mis-nesting in the migrated source, or an unresolved-type
    # switch) and the AST guard_regions are incomplete there. Recover the enclosing
    # if/switch/case guards syntactically via tree-sitter — sound (real dominating guards;
    # may under-collect, never fabricate). Clang stays primary for every line it covers.
    # NB: gate on cfg_blocks max, NOT _fn_line_span's hi — a guard_region can extend PAST
    # the truncation (dw780100: blocks stop at 1335 but a region spans to 1382), which
    # would mask a site at 1343 that still needs the fallback for its inner guards.
    block_max = max([s.get("line") for b in fn.get("cfg_blocks", [])
                     for s in b.get("stmts", []) if s.get("line")] or [0])
    if block_max and setter_line > block_max:
        from vbt.conditions.ts_guards import ts_enclosing_guards
        for c in ts_enclosing_guards(path_str, setter_line, fn_name=fn.get("function"),
                                     start_order=len(out)):
            if (c.condition, c.polarity) in ast_keys:
                continue
            ast_keys.add((c.condition, c.polarity))
            out.append(c)

    # Re-number outer→inner: AST guards (already outer→inner) first, then the
    # early-exit negatives (which gate the straight-line prefix).
    for i, c in enumerate(out, start=1):
        c.order = i
    _cpp_cond_cache_put(_ck, out)
    return [copy.copy(c) for c in out]


# --------------------------------------------------------------------------- #
# GAP 9 — "not-set" outcomes (the logical complement of the setters' guards)
# --------------------------------------------------------------------------- #
# The trace engine models ``set(V) under guard G`` and nothing else. "V is NOT set" on a path
# is therefore the LOGICAL COMPLEMENT of the reaching conditions the engine already computes:
#
#     not_set(F)  ≡  ¬( ∨_{S∈setters(V,F)} guard(S) )
#                 =  ∧_S ( ∨_{literal L ∈ guard(S)} ¬L )           (De Morgan → CNF, linear size)
#
# Each conjunct ``∨_L ¬L`` is the negation of one setter's reaching guard, emitted as a single
# Condition; the engine AND-s a setter's condition list, so the CNF is represented natively.
# This is general for EVERY construct (if/switch/loop/goto/ternary) — there is no per-construct
# logic and no taint heuristic: an UNCONDITIONAL setter has ``guard(S)=∅`` ⇒ its conjunct is the
# empty disjunction (false) ⇒ ``not_set=false`` ⇒ no entry (V is always set); independent guards
# negate independently (so two reconverging conditional setters yield ``!c ∧ !d``). Soundness is
# inherited 1:1 from the engine's guard soundness (``guard(S)`` is necessary AND sufficient — the
# basis of the existing ``unconditionalAtSetter`` claim), so the complement is reliable exactly
# where the guards are. The two places guards are only NECESSARY — a collapsed switch and a
# truncation ts-fallback — are detected and the function is SUPPRESSED (never emit a possibly
# over-broad negation). Production corpora (headers present) never collapse/truncate ⇒ full
# coverage; the headerless dev corpus degrades soundly, logged by the caller via the status.


def _negate_literal(text: str) -> str:
    """Logical negation of one guard literal's DISPLAY text. ``!(X) ↔ X`` (parity flip via the
    shared ``_strip_outer_neg``), else wrap in ``!(...)``. Pure text transform — the engine and
    consumers treat condition strings opaquely."""
    core, negated = _norm_neg(text)
    return core if negated else f"!({core})"


# A single negated equality ``!(scrut == val)`` with NO boolean operator inside (so a
# fall-through OR-of-cases ``!(e==A || e==B)`` is left intact, not mis-split).
_NOTSET_EQ_RE = re.compile(r"^\s*(.+?)\s*==\s*(.+?)\s*$")


def _as_single_neg_eq(condition: str) -> Optional[Tuple[str, str]]:
    """If ``condition`` is exactly ``!(scrut == val)`` (single equality, no || / &&), return
    ``(scrut, val)``; else None."""
    core, negated = _strip_outer_neg(_clean(condition))
    if not negated or "||" in core or "&&" in core:
        return None
    m = _NOTSET_EQ_RE.match(core)
    if not m:
        return None
    return m.group(1).strip(), m.group(2).strip()


def _coalesce_not_set(conjuncts: List[Condition], cpp_path: str, fn_name: Optional[str],
                      anchor_line: int) -> List[Condition]:
    """COSMETIC, equivalence-preserving: merge single negated-equalities on the SAME scrutinee
    into one ``!(scrut == v1 || scrut == v2 || …)`` (so a switch reads as the example expects).
    Non-matching conjuncts (compound disjunctions, inequalities) pass through in first-seen
    order. Correctness never depends on this — the raw per-setter conjuncts are already a sound
    CNF; this only improves readability."""
    block_id = f"{fn_name or ''}#not_set"
    grouped: Dict[str, List[str]] = {}
    order: List[Tuple[str, Any]] = []          # ("eq", scrut) | ("other", Condition)
    for c in conjuncts:
        eq = _as_single_neg_eq(c.condition)
        if eq is not None:
            scrut, val = eq
            if scrut not in grouped:
                grouped[scrut] = []
                order.append(("eq", scrut))
            if val not in grouped[scrut]:
                grouped[scrut].append(val)
        else:
            order.append(("other", c))
    out: List[Condition] = []
    for kind, key in order:
        if kind == "other":
            out.append(key)
            continue
        vals = grouped[key]
        text = "!(" + " || ".join(f"{key} == {v}" for v in vals) + ")"
        out.append(Condition(order=0, condition=text, block_id=block_id,
                             location=Location(cpp_path, anchor_line, anchor_line),
                             polarity=None, kind="not_set"))
    return out


def _fn_guard_unreliable(fn: Dict, setter_line: int) -> bool:
    """The setter's reaching guard may be only NECESSARY (not sufficient) here, so negating it
    could over-claim not-set. True iff the setter sits inside a collapsed-switch span (CFG/guards
    corrupted) OR past the cfg's block coverage (tree-sitter truncation fallback, which may
    under-collect). Both are headerless-corpus only; production never triggers them."""
    for g in fn.get("guard_regions", []):
        if (g.get("kind") == "collapsed_switch" and g.get("start_line") and g.get("end_line")
                and g["start_line"] <= setter_line <= g["end_line"]):
            return True
    block_max = max([s.get("line") for b in fn.get("cfg_blocks", [])
                     for s in b.get("stmts", []) if s.get("line")] or [0])
    return bool(block_max) and setter_line > block_max


def _necessary_guards(g: List[Condition], fn: Dict, setter_line: int) -> List[Condition]:
    """Drop a loop-kind guard literal that is NOT actually necessary to reach the setter.

    ``collect_cpp_conditions`` attaches the loop condition to every body statement uniformly,
    but a POST-test loop (``do { … } while(c)``) runs its body unconditionally on the first
    iteration — so ``c`` is not a reaching guard there, and negating it would falsely claim a
    not-set path. We keep a loop literal only when its loop-TEST block DOMINATES the setter
    block (true for ``while``/``for``, false for ``do`` — whose test sits at the bottom and is
    bypassed by the entry→body edge). Non-loop literals are already dominance/span-sound inside
    ``collect_cpp_conditions``, so they pass through untouched. Default-KEEP on any ambiguity
    (missing CFG, unmatched expr) — that can only UNDER-claim not-set (sound), never over-claim."""
    blocks = {b["id"]: b for b in fn.get("cfg_blocks", [])}
    if not blocks or not any(c.kind == "loop" for c in g):
        return g
    B = _map_line_to_block(blocks, setter_line)
    if B is None:
        return g
    if "_dom_cache" not in fn:
        fn["_dom_cache"] = _cfg_dominators(blocks)
    dom = fn["_dom_cache"]
    if dom is None:
        return g
    loop_tests = [(bid, b) for bid, b in blocks.items()
                  if b.get("terminator_kind") in ("for", "while", "do")]
    out: List[Condition] = []
    for c in g:
        if c.kind != "loop":
            out.append(c)
            continue
        core = _norm_neg(c.condition)[0]
        matches = [bid for bid, b in loop_tests
                   if _norm_neg(b.get("terminator_cond_expr") or "")[0] == core]
        if matches and not any(bid in dom.get(B, set()) for bid in matches):
            continue                       # post-test loop guard → not necessary → drop
        out.append(c)
    return out


def compute_cpp_not_set_conditions(
    cpp_path: str | Path,
    fn_name: Optional[str],
    setter_lines: List[int],
    *,
    functions: List[Dict],
) -> Tuple[List[Condition], str]:
    """GAP 9: the not-set guard for variable ``V`` in C++ function ``fn_name`` = the negation of
    the reaching guards of ``V``'s real setters at ``setter_lines`` (all in ``fn_name``).

    Returns ``(conditions, status)``:
      * ``"ok"``           — ``conditions`` is the non-empty CNF; emit a not-set entry.
      * ``"unconditional"``— some setter runs on every path ⇒ V is always set ⇒ no not-set.
      * ``"incomplete"``   — a contributing setter's guards are unreliable (collapsed/truncated)
                             ⇒ suppress (sound: never emit a possibly over-broad negation).
      * ``"no_function"``  — no cfg function / no lines.

    Pure function of ``(functions, setter_lines)``; reuses ``collect_cpp_conditions`` (so with
    ``functions`` supplied there are ZERO new file reads — and the same ``(line, fn)`` are
    already warm from the real setters' own condition collection in the trace)."""
    cpp_path = Path(cpp_path)
    path_str = str(cpp_path)
    lines = sorted({int(l) for l in setter_lines if l})
    if not lines or not functions:
        return [], "no_function"

    fn = _select_function(functions, lines[0], fn_name)
    if fn is None:
        return [], "no_function"
    lo, _ = _fn_line_span(fn)
    anchor = lo or lines[0]

    conjuncts: List[Condition] = []
    for ln in lines:
        fln = _select_function(functions, ln, fn_name) or fn
        if _fn_guard_unreliable(fln, ln):
            return [], "incomplete"
        g = collect_cpp_conditions(cpp_path, ln, fn_name, functions=functions)
        g = _necessary_guards(g, fln, ln)
        if not g:
            # An unconditionally-reached setter ⇒ V is set on every path ⇒ ¬(…∨true…)=false.
            return [], "unconditional"
        _neg: List[str] = []                  # dedup identical negated literals within a guard
        for c in g:
            t = _negate_literal(c.condition)
            if t not in _neg:
                _neg.append(t)
        text = " || ".join(_neg)
        conjuncts.append(Condition(order=0, condition=text,
                                   block_id=f"{fn_name or fln.get('function') or ''}#not_set",
                                   location=Location(path_str, ln, ln),
                                   polarity=None, kind="not_set"))

    # Tautology / unreliable-guard guard: if two setters' collected guards are exact
    # single-literal negations (one reached under ``X``, another under ``¬X``), their union
    # ``X ∨ ¬X`` is a tautology ⇒ V is set on every path (or the guards were under-collected for
    # one of them — common on truncation-prone functions where an enclosing loop/if guard is
    # missing). In BOTH readings the not-set is empty or unreliable, so emit nothing (sound:
    # omit rather than fabricate a contradictory ``X ∧ ¬X`` condition set). Only single-literal
    # conjuncts can form such a pair; disjunctions are skipped.
    _pol_by_core: Dict[str, Set[bool]] = {}
    for c in conjuncts:
        if "||" in c.condition or "&&" in c.condition:
            continue
        _core, _neg = _norm_neg(c.condition)
        _pol_by_core.setdefault(_core, set()).add(_neg)
    if any(len(v) > 1 for v in _pol_by_core.values()):
        return [], "tautology"

    conjuncts = _coalesce_not_set(conjuncts, path_str, fn_name, anchor)
    # Drop exact-duplicate conjunct texts (e.g. two setters with the identical guard).
    seen: Set[str] = set()
    uniq: List[Condition] = []
    for c in conjuncts:
        if c.condition in seen:
            continue
        seen.add(c.condition)
        uniq.append(c)
    for i, c in enumerate(uniq, start=1):
        c.order = i
    return uniq, "ok"
