"""Tree-sitter enclosing-guard FALLBACK for CFG-truncated regions.

WHY
===
Clang's CFG builder truncates a function body at the first construct it cannot model.
In this corpus that is usually NOT a missing header — it is a brace mis-nesting in the
migrated source (a stray ``}`` closes the function early; e.g. ``dw710000.cpp``'s
``processACreditTransaction`` closes at L1058, hiding the gate-3 ``switch`` at L1062 and
its case-calls). A smaller share are genuine unresolved-type switches. Either way,
``cfg_extract`` emits no blocks/guard_regions past the truncation, so
``collect_cpp_conditions`` finds NO guards for a call/setter there — even though the
source plainly nests it under ``if`` / ``switch`` / ``case``.

WHAT
====
This module recovers those guards purely SYNTACTICALLY via tree-sitter (no types, never
truncates). It finds the deepest node at the target line and walks UP, collecting each
enclosing ``if`` (with else→negate polarity), ``switch``-``case`` (``scrutinee ==
caseValue``), and loop guard.

SOUNDNESS
=========
An enclosing ``if``/``case`` body in structured C++ (no ``goto`` into it) is DOMINATED by
that guard — so every guard returned genuinely holds on the path to the site. On a
malformed-brace function the up-walk may stop early (the function node ended prematurely),
so we may UNDER-collect — sound-but-incomplete. We never over-collect (which would be
fabrication). This honours the necessary-guards principle the engine is built on.

FALLBACK ONLY
=============
``collect_cpp_conditions`` invokes this ONLY when the target line is past the function's
cfg-covered span (truncation). Clang's CFG stays primary everywhere else — it alone gives
true dominance, resolved types, and enum values.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import List, Optional

from vbt.interfaces import Condition, Location
from vbt.setters.cpp_setters import _parser, _txt

# Per-process parser (tree-sitter Parser is not picklable; mirror the other workers).
_TS_PARSER = None


def _clean(expr: str) -> str:
    """Strip comments + collapse whitespace (local copy to avoid a cpp_conditions cycle)."""
    raw = re.sub(r"/\*.*?\*/", " ", expr or "", flags=re.S)
    raw = re.sub(r"//[^\n]*", " ", raw)
    return " ".join(raw.split())


def _strip_outer_parens(s: str) -> str:
    s = s.strip()
    while s.startswith("(") and s.endswith(")"):
        # only strip if the leading '(' matches the trailing ')'
        depth = 0
        for i, ch in enumerate(s):
            depth += (ch == "(") - (ch == ")")
            if depth == 0:
                break
        if i != len(s) - 1:
            break
        s = s[1:-1].strip()
    return s


def _deepest_node_at_line(root, line: int):
    """Smallest node that contains ``line``, preferring one that STARTS on ``line``
    (the statement/call itself rather than the whole block)."""
    best = None
    best_starts = None

    def span(n):
        return (n.end_point[0] - n.start_point[0], n.end_byte - n.start_byte)

    def visit(n):
        nonlocal best, best_starts
        s, e = n.start_point[0] + 1, n.end_point[0] + 1
        if not (s <= line <= e):
            return
        if s == line and n.type not in ("comment", "translation_unit"):
            if best_starts is None or span(n) < span(best_starts):
                best_starts = n
        if best is None or span(n) < span(best):
            best = n
        for c in n.children:
            visit(c)

    visit(root)
    return best_starts or best


def _enclosing_switch(case_node):
    cur = case_node.parent
    while cur is not None and cur.type != "switch_statement":
        cur = cur.parent
    return cur


def ts_enclosing_guards(
    cpp_path: str | Path,
    line: int,
    *,
    fn_name: Optional[str] = None,
    start_order: int = 0,
) -> List[Condition]:
    """Enclosing guards for ``line`` recovered from the tree-sitter syntax tree.

    Returns ``Condition`` objects outer→inner, numbered from ``start_order + 1``, in the
    same shape as ``cpp_conditions._ast_guards`` so the engine/UI treat them uniformly.
    """
    global _TS_PARSER
    try:
        # T9: serve raw source bytes from index.db when installed (byte offsets unchanged).
        from backward_traversal.utils.blueprint_utils import source_override_bytes
        _ov = source_override_bytes(cpp_path)
        src = _ov if _ov is not None else Path(cpp_path).read_bytes()
        if _TS_PARSER is None:
            _TS_PARSER = _parser()
        tree = _TS_PARSER.parse(src)
    except Exception:
        return []

    node = _deepest_node_at_line(tree.root_node, line)
    if node is None:
        return []

    def txt(n):
        return _txt(n, src)

    # Walk up, collecting guards inner→outer; reverse at the end for outer→inner.
    collected = []  # (condition_text, polarity, kind)
    seen_switch = set()
    fn_label = fn_name or "ts"
    cur = node
    while cur is not None:
        t = cur.type
        if t == "function_definition":
            d = cur.child_by_field_name("declarator")
            if d:
                fn_label = txt(d).split("(")[0].strip().split()[-1].split("::")[-1] or fn_label
            break  # reached the enclosing function — stop
        if t == "if_statement":
            cond = cur.child_by_field_name("condition")
            alt = cur.child_by_field_name("alternative")
            in_else = alt is not None and alt.start_byte <= node.start_byte < alt.end_byte
            expr = _strip_outer_parens(_clean(txt(cond))) if cond else ""
            if expr:
                if in_else:
                    collected.append((f"!({expr})", False, "if"))
                else:
                    collected.append((expr, True, "if"))
        elif t == "case_statement":
            sw = _enclosing_switch(cur)
            if sw is not None and id(sw) not in seen_switch:
                seen_switch.add(id(sw))
                scrut = sw.child_by_field_name("condition")
                scrut_txt = _strip_outer_parens(_clean(txt(scrut))) if scrut else ""
                val = cur.child_by_field_name("value")
                if scrut_txt and val is not None:                       # case X:
                    collected.append((f"{scrut_txt} == {_clean(txt(val))}", True, "switch"))
                elif scrut_txt:                                          # default:
                    collected.append((f"{scrut_txt} (default)", None, "switch"))
        elif t in ("for_statement", "while_statement", "do_statement"):
            cond = cur.child_by_field_name("condition")
            expr = _strip_outer_parens(_clean(txt(cond))) if cond else ""
            if expr:
                collected.append((expr, True, "loop"))
        cur = cur.parent

    collected.reverse()  # outer→inner
    out: List[Condition] = []
    seen = set()
    for expr, polarity, kind in collected:
        key = (expr, polarity)
        if key in seen:
            continue
        seen.add(key)
        out.append(Condition(
            order=start_order + len(out) + 1,
            condition=expr,
            block_id=f"{fn_label}#tsguard",
            location=Location(file=str(cpp_path), start_line=line, end_line=line),
            polarity=polarity,
            kind=kind,
        ))
    return out
