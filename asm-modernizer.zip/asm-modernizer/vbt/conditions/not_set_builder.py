"""GAP 9 — build virtual "[not set]" setters from a list of real setters.

Shared by the root engine (``trace_root_variable``) and the dependent-variable recursion
(``recurse._compute_node``) so both surface not-set outcomes identically. A not-set setter's
guard is the logical complement of the real setters' reaching conditions, computed per C++
function (``compute_cpp_not_set_conditions``) and per ASM module (``compute_asm_not_set_conditions``)
and attached as ``preset_conditions`` (the engine/recursion use it verbatim instead of recomputing
at the synthetic line). Trace-time only; never persisted to the precomputed setter map.
"""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from vbt.interfaces import SetterSite
from vbt.reach.fn_attr import line_to_function
from vbt.conditions.cpp_conditions import compute_cpp_not_set_conditions
from vbt.conditions.asm_conditions import compute_asm_not_set_conditions


def build_not_set_setters(
    real_setters: List[SetterSite],
    *,
    asm_dir: Path,
    get_cpp_fns: Callable[[str], List[Dict]],
    get_asm_bp: Optional[Callable[[str], Tuple[Optional[str], Optional[Dict]]]] = None,
    asm_max_levels: int = 16,
    log: Optional[Callable[..., None]] = None,
) -> List[SetterSite]:
    """Return virtual ``[not set]`` ``SetterSite``s for ``real_setters``.

    Groups C++ setters by ``(file_stem, cfg-function)`` and ASM setters by ``file_stem`` (module);
    emits at most one not-set setter per group when its complement is a non-empty, reliable guard.
    ``get_cpp_fns(stem) -> functions`` and ``get_asm_bp(stem) -> (bp_path, bp_data)`` abstract the
    caller's caches (``None`` ``get_asm_bp`` ⇒ skip ASM not-set)."""
    asm_dir = Path(asm_dir)

    def _log(msg, *a):
        if log:
            log(msg, *a)

    cpp_by_fn: Dict[Tuple[str, str], List[SetterSite]] = defaultdict(list)
    asm_by_stem: Dict[str, List[SetterSite]] = defaultdict(list)
    for s in real_setters:
        if getattr(s, "is_not_set", False):
            continue                       # never build a not-set from a not-set
        if s.language == "cpp":
            try:
                fns = get_cpp_fns(s.file_stem)
            except Exception:
                fns = []
            fn = line_to_function(fns, s.line) or s.function
            if fn:
                cpp_by_fn[(s.file_stem, fn)].append(s)
        elif s.language == "asm" and get_asm_bp is not None:
            asm_by_stem[s.file_stem].append(s)

    out: List[SetterSite] = []

    for (stem, fn), grp in cpp_by_fn.items():
        fns = get_cpp_fns(stem)
        conds, status = compute_cpp_not_set_conditions(
            asm_dir / f"{stem}.cpp", fn, [g.line for g in grp], functions=fns)
        if status == "ok" and conds:
            out.append(SetterSite(
                variable=grp[0].variable, file_stem=stem, language="cpp",
                line=min(g.line for g in grp), instruction="not_set",
                block_id=fn, function=fn, value="[not set]",
                setter_code_chunk=f"// {grp[0].variable} not set on this path",
                is_not_set=True, preset_conditions=conds))
        elif status in ("incomplete", "tautology"):
            _log("  not-set: suppressed %s::%s (%s)", stem, fn, status)

    for stem, grp in asm_by_stem.items():
        try:
            bp_path, bp = get_asm_bp(stem)
        except Exception:
            bp_path, bp = None, None
        if not bp:
            continue
        conds, status = compute_asm_not_set_conditions(
            bp, bp_path, f"{stem}.asm", grp, asm_max_levels=asm_max_levels)
        if status == "ok" and conds:
            anchor = min(grp, key=lambda s: s.line)
            out.append(SetterSite(
                variable=grp[0].variable, file_stem=stem, language="asm",
                line=anchor.line, instruction="not_set", block_id=anchor.block_id,
                value="[not set]",
                setter_code_chunk=f"// {grp[0].variable} not set on this path",
                is_not_set=True, preset_conditions=conds))
        elif status in ("incomplete", "tautology"):
            _log("  not-set: suppressed %s (asm %s)", stem, status)

    return out
