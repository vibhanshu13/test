"""Pure value-flow feasibility primitives for the LCA chain trace.

These are COPIED VERBATIM from git ``c17a8f4:vbt/chains/feasibility.py`` (the proven,
exhaustively unit-tested decision layer), with the FILE-READING extraction
(``chain_feasibility``) deliberately left out — at trace time the events are
reconstructed from the precomputed ``chain_facts`` artifact instead of from source
(see ``vbt.precompute.chain_facts_db.assemble_events_from_chain_facts``). Keeping the
decision pure + dependency-free lets BOTH the precompute parity test and the trace-time
prune import the IDENTICAL logic with no circular import (precompute ⇄ trace).

SOUNDNESS CONTRACT (unchanged from the reference): a chain is dropped ONLY when a
scrutinee is provably fixed to a constant incompatible with a guard required to descend.
Any uncertainty (unrecognized token, cross-kind comparison, conditional/non-constant
assignment) ⇒ ``unknown`` ⇒ KEEP. Extraction can only ever reduce pruning, never cause a
false drop.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, Optional, Sequence, Tuple


# --------------------------------------------------------------------------- #
# verdict + event model
# --------------------------------------------------------------------------- #
@dataclass
class FeasibilityVerdict:
    status: str                       # "feasible" | "infeasible" | "unknown"
    reason: str = ""
    conflict: Optional[Dict[str, Any]] = None   # {scrutinee, required, fixed_to, ...}

    @property
    def infeasible(self) -> bool:
        return self.status == "infeasible"

    @property
    def keep(self) -> bool:
        """Sound policy: keep unless PROVABLY infeasible."""
        return self.status != "infeasible"


@dataclass
class _Event:
    """One value-relevant event along the chain, in execution order (hop, line)."""
    hop: int                          # chain hop index (0 = root, increasing downstream)
    line: int                         # source line (within-hop ordering)
    kind: str                         # "assign" | "guard"
    scrutinee: str                    # normalized variable / masked-expr key
    const: Optional[str]              # constant value (assign RHS / guard comparand); None = unknown
    op: str = "eq"                    # guard operator: "eq" | "ne"
    conditional: bool = False         # assign only: True ⇒ value not guaranteed ⇒ clears the fact
    text: str = ""                    # raw, for the reason string


# --------------------------------------------------------------------------- #
# constant parsing / comparison (conservative: "provably different" or give up)
# --------------------------------------------------------------------------- #
_ENUM_RE = re.compile(r"^[A-Za-z_]\w*(?:::[A-Za-z_]\w*)+$")
_INT_RE = re.compile(r"^[+-]?\d+$")
_HEX_C_RE = re.compile(r"^[Xx]'([0-9A-Fa-f]+)'$")          # ASM X'40'
_CHARLIT_RE = re.compile(r"^'(?:\\.|[^'])*'$")            # 'Y'
_ASM_CHAR_RE = re.compile(r"^[Cc]'(.*)'$")                # ASM C'M'
_ZEROS_RE = re.compile(r"^(ZEROS?|X'0+'|0+)$", re.I)


def _enum_tail(name: str) -> str:
    return name.split("::")[-1].strip()


def _norm_const(c: Optional[str]) -> Optional[Tuple[str, Any]]:
    """Classify a constant token → (kind, value) for comparison, or None if not a
    recognizable constant. Kinds: 'enum'|'num'|'char'|'raw'."""
    if c is None:
        return None
    t = c.strip()
    if not t:
        return None
    if _ZEROS_RE.match(t):
        return ("num", 0)
    m = _HEX_C_RE.match(t)
    if m:
        return ("num", int(m.group(1), 16))
    if _INT_RE.match(t):
        return ("num", int(t))
    m = _ASM_CHAR_RE.match(t)
    if m:
        return ("char", m.group(1))
    if _CHARLIT_RE.match(t):
        return ("char", t.strip("'"))
    if _ENUM_RE.match(t):
        return ("enum", _enum_tail(t))
    return None


def _provably_different(a: Optional[str], b: Optional[str]) -> bool:
    """True ONLY when ``a`` and ``b`` are provably different constants. Any uncertainty
    (unrecognized token, cross-kind we can't reconcile) → False (do NOT prune)."""
    na, nb = _norm_const(a), _norm_const(b)
    if na is None or nb is None:
        return False
    ka, va = na
    kb, vb = nb
    if ka == kb:
        return va != vb
    # cross-kind: only compare when both reduce to a number (num/char-as--not-comparable).
    if {ka, kb} == {"num", "char"}:
        return False        # can't safely compare a number to a char literal
    return False            # different kinds, not safely comparable → conservative


def _is_constant(v: Optional[str]) -> bool:
    return _norm_const(v) is not None


# --------------------------------------------------------------------------- #
# guard parsing: a guard text → required equality/inequality on a CONSTANT
# --------------------------------------------------------------------------- #
_GUARD_RE = re.compile(r"^(.*?)(==|!=)(.*)$", re.S)


def _strip_outer_parens(s: str) -> str:
    t = s.strip()
    while len(t) >= 2 and t[0] == "(" and t[-1] == ")":
        # only strip if balanced
        depth = 0
        ok = True
        for i, ch in enumerate(t):
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0 and i != len(t) - 1:
                    ok = False
                    break
        if ok:
            t = t[1:-1].strip()
        else:
            break
    return t


def parse_required_guard(text: str) -> Optional[Tuple[str, str, str]]:
    """Parse a guard predicate into ``(scrutinee, const, op)`` where ``op`` ∈
    {"eq","ne"} and ``const`` is a recognized constant; else None. Handles a leading
    negation ``!(...)`` (flips the op) and the ASM bitmask form ``(F & M) == M``
    (scrutinee = the whole ``F & M`` key). Works for BOTH languages because it parses
    the engine's already-normalized predicate text."""
    t = (text or "").strip()
    if not t:
        return None
    neg = False
    # peel a leading not: !(...) or NOT (...)
    m = re.match(r"^!\s*\((.*)\)\s*$", t, re.S) or re.match(r"^NOT\s+\((.*)\)\s*$", t, re.S)
    if m:
        neg = True
        t = m.group(1).strip()
    # reject obvious compounds we can't reason about as a single equality
    if "&&" in t or "||" in t:
        return None
    m = _GUARD_RE.match(t)
    if not m:
        return None
    lhs, op_raw, rhs = m.group(1), m.group(2), m.group(3)
    scrut = _norm_scrutinee(_strip_outer_parens(lhs))
    rhs = _strip_outer_parens(rhs)
    if not _is_constant(rhs) or not scrut:
        return None                       # RHS not a constant → not a value guard
    if _is_constant(scrut):
        return None                       # both sides constant → not a variable guard
    op = op_raw
    if neg:
        op = "!=" if op == "==" else "=="
    return (scrut, rhs, "eq" if op == "==" else "ne")


def _norm_scrutinee(s: str) -> str:
    """Normalize a scrutinee key: collapse whitespace; keep member paths and the ASM
    masked-expr form intact so two references to the same thing compare equal."""
    return re.sub(r"\s+", "", s or "")


# --------------------------------------------------------------------------- #
# THE DECISION: a pure value-flow walk over ordered events (unit-tested)
# --------------------------------------------------------------------------- #
def decide_feasibility(events: Sequence[_Event]) -> FeasibilityVerdict:
    """Walk events in execution order, tracking the SET of constant values each
    scrutinee may still hold (``allowed``; absent ⇒ unconstrained). A scrutinee is
    pinned to ``{K}`` by an unconditional constant assignment; a *conditional* /
    non-constant assignment clears it (back to any).

    **Guards are grouped per hop, per scrutinee.** Multiple equality guards on the
    SAME scrutinee at the SAME hop are a DISJUNCTION — a ``switch`` / branch-table /
    dispatch where any case-value reaches the next file (a ``CLI`` / ``JE`` cascade) —
    NOT a conjunction. So a hop's required-equality guards mean ``scrut ∈ S``.

    **Conflict uses ``_provably_different``, NOT raw set-difference.** A chain is
    **provably infeasible** only when the current constraint and a required switch are
    PROVABLY DISJOINT — every value on one side is a provably-different constant from
    every value on the other. Two constants of DIFFERENT KINDS (an enum member vs the
    integer ``0``, say) are NOT provably different — we cannot know the enum's int value
    here — so that is kept (``feasible``). This avoids the cross-kind false positive
    (``returnCode == CreditApproved`` vs ``returnCode == 0``). Everything uncertain is
    kept; only provable same-kind contradictions are dropped."""
    if not events:
        return FeasibilityVerdict("feasible")
    allowed: Dict[str, set] = {}      # scrutinee -> {raw const strings}; ABSENT ⇒ any
    src_hop: Dict[str, int] = {}      # where a scrutinee's constraint last narrowed

    def _disp(vals: set) -> str:
        return "{" + ", ".join(sorted(vals)) + "}"

    for h in sorted({e.hop for e in events}):
        # 1) assignments first (in line order) — they pin or clear the value.
        for e in sorted((x for x in events if x.hop == h and x.kind == "assign"),
                        key=lambda x: x.line):
            if e.conditional or not _is_constant(e.const):
                allowed.pop(e.scrutinee, None)
                src_hop.pop(e.scrutinee, None)
            else:
                allowed[e.scrutinee] = {e.const}; src_hop[e.scrutinee] = e.hop
        # 2) guards, grouped per scrutinee (eq = disjunction set; ne = excluded set).
        eqg: Dict[str, set] = {}
        neg: Dict[str, set] = {}
        for e in (x for x in events if x.hop == h and x.kind == "guard"):
            if not _is_constant(e.const):
                continue
            (eqg if e.op == "eq" else neg).setdefault(e.scrutinee, set()).add(e.const)
        for scrut, S in eqg.items():
            prior = allowed.get(scrut)
            if prior is not None:
                if _sets_provably_disjoint(prior, S):
                    return FeasibilityVerdict(
                        "infeasible",
                        reason=(f"{scrut} is constrained to {_disp(prior)} "
                                f"(hop {src_hop.get(scrut, '?')}) but reaching the next file "
                                f"requires {scrut} in {_disp(S)} (hop {h}) — no overlap"),
                        conflict={"scrutinee": scrut, "allowed": sorted(prior),
                                  "required": sorted(S),
                                  "fixed_hop": src_hop.get(scrut), "required_hop": h})
                # keep the prior values still compatible with the switch; else take S.
                narrowed = {a for a in prior
                            if any(not _provably_different(a, b) for b in S)}
                allowed[scrut] = narrowed or set(S)
            else:
                allowed[scrut] = set(S)
            src_hop[scrut] = h
        for scrut, X in neg.items():
            prior = allowed.get(scrut)
            if prior is not None:
                # drop only values PROVABLY equal to a forbidden one (same normalized const).
                kept = {a for a in prior
                        if not any(_norm_const(a) == _norm_const(x) for x in X)}
                if not kept:
                    return FeasibilityVerdict(
                        "infeasible",
                        reason=(f"{scrut} is constrained to {_disp(prior)} but reaching the "
                                f"next file requires {scrut} != {_disp(X)} (hop {h})"),
                        conflict={"scrutinee": scrut, "forbidden": sorted(X),
                                  "required_hop": h})
                allowed[scrut] = kept
    return FeasibilityVerdict("feasible")


def _sets_provably_disjoint(a: set, b: set) -> bool:
    """True iff every value in ``a`` is a provably-different constant from every value
    in ``b`` (so no value can satisfy both). Cross-kind pairs (enum vs int) are NOT
    provably different → not disjoint → not pruned."""
    return all(_provably_different(x, y) for x in a for y in b)
