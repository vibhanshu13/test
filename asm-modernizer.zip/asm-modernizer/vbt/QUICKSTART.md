# VBT Quickstart

Trace **where and under what conditions a variable is set** in a mixed HLASM/C++ codebase.
Three steps: build the frontend once → precompute a job → trace. Full guide:
[`RUNNING.md`](./RUNNING.md). DB-precompute design: [`DB_PRECOMPUTE_PLAN.md`](./DB_PRECOMPUTE_PLAN.md).

All commands run from the repo root with the repo's venv (`env/bin/python3`).

---

## 0. One-time per machine — build the C++ frontend
```bash
bash vbt/cpp_frontend/build.sh          # compiles vbt/cpp_frontend/cfg_extract (needs LLVM)
```

## 1. Precompute a job (once per codebase; cached + idempotent)
You need a parsed codebase: a `--blueprint-dir` of `.asm.json`/`.cpp.json`/… and the matching
`--asm-dir` of source files.

```bash
# (a) file/disk artifacts: call graph + modifier index + const resolver + parallel cfg-warm
env/bin/python3 -m vbt.precompute_all \
    --blueprint-dir jobs/<id>/output \
    --asm-dir       /path/to/source

# (b) OPTIONAL but recommended at scale: move it all into jobs/<id>/index.db
env/bin/python3 -m vbt.precompute_db \
    --job-id <id> \
    --blueprint-dir jobs/<id>/output \
    --asm-dir       /path/to/source
```
Re-running either is near-instant when nothing changed. **Re-run `vbt.precompute_db` after the
blueprints/source change** — a `--job-id` trace trusts the DB (O(1) reads, no per-trace file
scans) and relies on precompute for freshness.

## 2. Trace a variable
```bash
env/bin/python3 -m vbt.trace \
    --variable softCardValue --language cpp \
    --hop aa71:asm \
    --hop dw730000:cpp:DW73 \
    --hop dw710000:cpp:callPlasticAuthenticationComponentInterface \
    --blueprint-dir jobs/<id>/output \
    --asm-dir       /path/to/source \
    --job-id <id> \                 # ← reads from index.db (omit = file/compute path; same output)
    --out result.json
```
- `--hop STEM:TYPE[:FN]` repeatable, **tail (deepest) LAST**. ASM = `stem:asm`, C++ = `stem:cpp:fn`.
- `--job-id` is optional: with it, the trace reads precomputed artifacts from `index.db`; without
  it, it reads from files/computes on the fly. **Output is byte-identical either way.**
- `--help` lists every flag (scope/scale knobs, emit formats).
- The `file` paths in the output mirror the `--asm-dir`/`--blueprint-dir` you pass: relative in →
  relative out, absolute in → absolute out (the trace doesn't rewrite them). Pass the same form
  consistently if you compare two runs byte-for-byte.

---

## Copy-paste example (the pinned test corpus in this repo)
```bash
env/bin/python3 -m vbt.precompute_db \
  --job-id demo \
  --blueprint-dir "jobs/1ffa983c-3282-42f2-9701-a4c3f21451b1/output/asm 5" \
  --asm-dir       "datasource/asm7_admin/asm 7_version_0/asm 5"

env/bin/python3 -m vbt.trace \
  --variable softCardValue --language cpp \
  --hop aa71:asm --hop dw730000:cpp:DW73 \
  --hop dw710000:cpp:callPlasticAuthenticationComponentInterface \
  --blueprint-dir "jobs/1ffa983c-3282-42f2-9701-a4c3f21451b1/output/asm 5" \
  --asm-dir       "datasource/asm7_admin/asm 7_version_0/asm 5" \
  --job-id demo --out /tmp/softCardValue.json
```
> Note the **space** in the dir names. Pair these blueprints with this source dir (NOT
> `temp/asm` — it's missing 4 C++ files and the trace will error).

## In production (API / Celery)
Nothing manual: the `asm.vbt_precompute` task runs both precompute steps, and the trace tasks
(`asm.vbt_trace`, `asm.vbt_table`) pass the `kb_id` as `job_id`, so API traces are DB-backed
automatically.

## Verify it still produces identical output (regression gate)
```bash
env/bin/python3 -m vbt.tests.parity.check_parity          # re-trace the curated set vs goldens
```
