"""Reachability / route enumeration (reuses route_finder; dep-var before_line bound added here)."""
