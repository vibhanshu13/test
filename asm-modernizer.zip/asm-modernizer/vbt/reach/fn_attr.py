"""Shared, header-independent line→function attribution.

WHY
===
A dependent-type ``switch`` makes the parser/Clang truncate the recovered function
body at the switch: calls past it are attributed to caller ``(global)`` and the
cfg statement span ends early (e.g. ``processACreditTransaction`` recovers as
934–1057 though its body runs to ~1406). The ONE reliable signal is each function's
START line — recovered even when the body truncates. So a line ``L`` belongs to the
function with the greatest START ≤ ``L`` (the nearest preceding definition); the
unreliable ``max(stmt)`` upper bound is never used.

This module centralizes that resolution so no consumer ever again trusts a
``(global)`` caller label or a truncated span (the route-undercount bug was one
instance of this; the same leak poisons dep-var reachability, prefix-guard site
selection, intra-file path enumeration, and setter/condition function attribution).
Read-only over cfg_extract output; kb_id-free.
"""
from __future__ import annotations

import bisect
from typing import Dict, Iterable, List, Optional, Tuple

# Caller labels that mean "no real enclosing function was recorded".
GLOBALISH = frozenset({"", "(global)", "global", "glob"})


def is_globalish(src) -> bool:
    return src is None or str(src).strip().lower() in GLOBALISH


def _fn_lines(f: Dict) -> List[int]:
    return [s.get("line") for b in f.get("cfg_blocks", []) for s in b.get("stmts", [])
            if s.get("line")]


# Memo for function_starts: it is a pure function of the cfg-fn list but was recomputed from scratch
# on EVERY line_to_function / function_span call (per setter, per edge — the per-route/dep hot path).
# Keyed by id() of the cfg list, with an identity re-check (hit[0] is cfg_fns) so a recycled id can
# never return a stale result; the held ref keeps the id stable while cached. Bounded (FIFO).
_STARTS_CACHE: Dict[int, Tuple[List[Dict], List[Tuple[int, str]]]] = {}
_STARTS_CACHE_MAX = 512


def function_starts(cfg_fns: List[Dict]) -> List[Tuple[int, str]]:
    """Sorted ``[(start_line, function_name)]`` from cfg_extract output (original
    case). Uses the MINIMUM statement line as the start proxy — recovered reliably
    even for a body that truncates at a collapsed switch. Memoized per cfg list."""
    _k = id(cfg_fns)
    _hit = _STARTS_CACHE.get(_k)
    if _hit is not None and _hit[0] is cfg_fns:    # identity re-check guards against id reuse
        return _hit[1]
    out: List[Tuple[int, str]] = []
    for f in cfg_fns:
        name = f.get("function") or ""
        lines = _fn_lines(f)
        if name and lines:
            out.append((min(lines), name))
    out.sort()
    if len(_STARTS_CACHE) >= _STARTS_CACHE_MAX:     # bounded; recompute on eviction (byte-identical)
        _STARTS_CACHE.pop(next(iter(_STARTS_CACHE)))
    _STARTS_CACHE[_k] = (cfg_fns, out)              # hold the ref so the id stays valid while cached
    return out


def line_to_function(cfg_fns: List[Dict], line: Optional[int]) -> Optional[str]:
    """Function whose START line is the greatest ≤ ``line`` (nearest preceding
    definition). Robust to truncated bodies: ignores the unreliable ``max(stmt)``
    upper bound. Returns None for a line before the first function (file scope)."""
    if line is None:
        return None
    starts = function_starts(cfg_fns)
    if not starts:
        return None
    idx = bisect.bisect_right([s for s, _ in starts], line) - 1
    return starts[idx][1] if idx >= 0 else None


def function_span(cfg_fns: List[Dict], fn_name: str) -> Tuple[int, int]:
    """``(lo, hi)`` for ``fn_name``, with ``hi`` bounded by the NEXT function's
    start − 1 (not ``max(stmt)``, which truncates at a collapsed switch). Matches
    by exact or ``::``-qualified-boundary name. ``(0, 0)`` if not found."""
    starts = function_starts(cfg_fns)
    for i, (lo, name) in enumerate(starts):
        if name == fn_name or name.endswith("::" + fn_name):
            hi = (starts[i + 1][0] - 1) if i + 1 < len(starts) else None
            if hi is None:
                # last function: fall back to its own max stmt line
                for f in cfg_fns:
                    if (f.get("function") or "") == name:
                        fl = _fn_lines(f)
                        hi = max(fl) if fl else lo
                        break
            return lo, hi if hi and hi >= lo else lo
    return 0, 0


def reattribute_edges(
    edges: Iterable[Dict], cfg_fns: List[Dict]
) -> List[Tuple[str, str, Optional[int]]]:
    """Map blueprint call_graph edges to ``(source, target, line)`` with every
    ``(global)``/empty ``source`` resolved to its enclosing function by nearest-
    preceding START. Targets and lines are passed through unchanged. This is the
    single point that de-poisons the parser's caller attribution for every consumer
    of the intra-file call graph."""
    starts = function_starts(cfg_fns)
    keys = [s for s, _ in starts]

    def at(line: Optional[int]) -> Optional[str]:
        if line is None or not starts:
            return None
        idx = bisect.bisect_right(keys, line) - 1
        return starts[idx][1] if idx >= 0 else None

    out: List[Tuple[str, str, Optional[int]]] = []
    for e in edges:
        s = e.get("source")
        t = e.get("target")
        ln = e.get("line")
        if is_globalish(s):
            s = at(ln) or s
        out.append((str(s) if s is not None else "", str(t) if t is not None else "", ln))
    return out
