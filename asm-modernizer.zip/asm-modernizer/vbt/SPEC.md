# VBT — Variable Backward Trace (Engine Spec)

> Source-of-truth for the new variable-backward-traversal engine. Captures every
> decision made during design. If code and this doc disagree, fix one of them.

## 0. Goal

Given a **variable** and a **chain prefix**, find **where and under what conditions
the variable gets set**, in a mixed HLASM/C++ z/TPF codebase — then do the same,
recursively, for every **dependent variable**. The output is consumed by an
explanation/UI layer; this engine produces structured, sound facts (no LLM here).

## 1. Hard constraints (non-negotiable)

1. **Modular & pluggable.** Every capability is a module behind a clean interface;
   any piece can be swapped without touching the others.
2. **No `kb_id` / `job_id`.** Nothing in this engine depends on a knowledge-base id,
   the Celery pipeline, Redis, or `index.db`.
3. **Reuse battle-ready code, but verify first.** For every capability we survey ALL
   existing implementations, judge soundness, and record a verdict:
   **USE-AS-IS / IMPROVE-THEN-USE / REBUILD** (see §9). Existing logic is reused
   **read-only** where provably correct; **we never modify it in place** — anything
   different/new goes in our own precompute/engine layer.
4. **Inputs = source files + our own lightweight precompute.** We may read existing
   parser "blueprint" artifacts read-only where they are provably correct (ASM
   blocks/CFG, file_call_graph, enum_values). The precompute must be light and scale
   in CPU/RAM at least as well as the project-creation pipeline.
5. **Full accuracy.** Especially for C++ control flow — see §5.

Validation corpus: `temp/asm/` (mixed ASM/C++). Reference variables:
- **ASM:** `LG1OSI` (set in `da78.asm:854` via `OI LG1OSI,LG#C400`).
- **C++:** `softCardValue` = `plasticAuth.process.transactionInds.softCardValue`
  (set in `dw710000.cpp:1002` and `:1033`).

## 2. Inputs

- `variable`: the root variable name (ASM or C++ form).
- `chain_prefix`: ordered entry hops, deepest = **tail**. A C++ hop is `file::function`
  (e.g. `dw730000::DW73`, `dw710000::callPlasticAuthenticationComponentInterface`);
  an ASM hop is a file (e.g. `aa71`). The tail may be ASM or C++.
- source dir (e.g. `temp/asm`), blueprint dir (read-only), `file_call_graph.json`.

## 3. Core flow (root variable)

For the root variable `V` and chain prefix ending at tail `T`:

1. **Find all setters of `V` codebase-wide.**
   - Candidate files from the modifier index (cheap, validated correct).
   - Per-file setter-site scan (§4). **Cross-language:** resolve `V`'s alias-set
     (§7) and search setters under **all high-certainty aliases** in every file.
2. **Filter by forward reachability from the tail `T`.** Keep a setter only if it is
   reachable by execution flow starting at `T` (function-level for C++ tail,
   file/subroutine-level for ASM tail). Drop the rest.
3. **Enumerate routes → `(setter, chain)` tuples.** For each surviving setter there
   may be multiple forward routes `T → … → setter`. Each route is its own tuple:
   `chain = chain_prefix + route_to_setter`. Multiple routes ⇒ multiple tuples.
   **Each `(setter, chain)` is processed independently.**
4. **Process each `(setter, chain)`:**
   - Capture the **set value** (RHS expression) + resolve enums/constants (§6).
   - Collect **intra-file conditions** to reach the setter (§4/§5).
   - Walk **upstream** along the chain: at each hop, collect the conditions in the
     caller required to reach the call site(s) into the next file. A caller→callee
     hop may have **multiple call sites** → collect all (OR).
   - Collect **dependent variables** (§6).

### Boolean structure of conditions
- One chain's guard = **AND** of (setter-local conditions) ∧ (hop-N call guard) ∧ …
  ∧ (entry call guard).
- Within one hop with *k* call sites = **OR** of the *k* call sites.
- Across multiple chains to the same setter = **OR** (modeled as separate output
  entries — see §8).

This is **chain-scoped interprocedural reaching-definitions** — a sound, bounded
def-use analysis.

## 4. Setter detection & ASM condition collection

### Setter detection
- **ASM** — `SETTER_INST` whose destination operand (via `DEST_ARG_INDEX_BY_INST`)
  equals the variable, refined by `classify_setter` (RMW prior-value e.g. `OI`,
  self-nop, zero-mask, EX/EXRL, implicit GETCC/DETAC/DBSPA writes, …).
  **Verdict: USE-AS-IS** (glossary + `_find_scoped_setter_sites` +
  `enumerate_setter_roots(job_id=None)`).
- **C++** — assignment statements whose LHS resolves to the field path. **REBUILT**
  on the C++ frontend (§5) — replaces the GVL.

### ASM intra-file condition collection
Backward CFG walk from the site to entry, collecting `TRIGGER_INST` (compare) +
`BRANCH_INST` pairs. Branch **polarity** = taken vs fallthrough decides whether the
condition is the predicate or its negation.
- Reuse `_build_cfg_maps`, `backward_reachable_blocks` **USE-AS-IS**.
- `_extract_block_conditions_before_line` **IMPROVE-THEN-USE**: (a) encode explicit
  polarity in each condition; (b) extend the predecessor scan from 1 level to
  **N-level** (multi-block routing chains) — a known soundness gap.

Worked truth (`LG1OSI`): setter `OI LG1OSI,LG#C400 @ da78:854` in block `DA780000`;
guard `WK_RRC == ZEROS` (three `CLC WK_RRC,ZEROS / BNE DA7_0900` pairs, fallthrough).

**Condition line anchoring + verbatim source.** An ASM `condition` string is the engine's
**normalized** predicate (`(L7DSTS & X'40') == X'40'`), not verbatim ASM. It is anchored at
the **compare/TEST instruction** line, never the branch or the call site: `location.startLine`
= the `TRIGGER` (e.g. `TM L7DSTS,X'40'` @2012), `location.endLine`/`decisionLine` = the
conditional `BRANCH` (e.g. `JNO` @2014). The verbatim instructions are surfaced as `asmTest`
/ `asmBranch` so a consumer can show real source + label the normalization honestly. This
holds for setter-local guards (`_pairs_to_conditions` captures the trigger line) AND
chain/hop guards (route_finder pins a hop guard at the branch/call line — `find_trigger_line`
re-points it at the compare from the blueprint, falling back to the branch line, never
fabricating). Previously a hop guard showed at the `ENTRC`/call line (e.g. aa71:2016).

**Descend call site present in the trace.** A chain hop's guard now also carries the
descend CALL site so the transfer instruction is in the data (it previously was not): the
ASM hop `via` gains `@<callLine>` (mirroring the C++ `caller→callee@line` form), and the
ASM block holding the guard + the descend call (e.g. block `AA710A5B`, which spans the
`TM…/JNO…` guards through `ENTRC DW73 @2016`) is registered in `codeBlocks` and set as the
guard's `blockId` (was null). A consumer resolves the `blockId` and slices the via's call
line to show the real `ENTRC DW73` — the same path it uses for a C++ call site.

## 5. C++ frontend (full accuracy) — **Clang LibTooling**

Decision: a small **Clang LibTooling** C++ tool, compiled once (`brew install llvm`),
emits **JSON per function**; Python consumes it. tree-sitter is kept only as a fast
pre-pass (function boundaries, enum tables, alias mapping) and a parse-failure fallback.

Why LibTooling and not libclang-python or tree-sitter: only LibTooling exposes a
**real CFG** (`clang::CFG::buildCFG`). The libclang **C API has no CFG**; tree-sitter
has no types/CFG. Full accuracy requires correct handling of: `if/else-if/else`,
`switch` (cases + **fallthrough** + default), loops, ternary, **early
`return`/`break`/`continue`/`goto`**, and `&&`/`||` **short-circuit** — all of which
the CFG models directly.

Per-function JSON contract (shape; finalize in code):
```
{ "file", "function",
  "cfg_blocks": [ { "id", "stmts":[...], "succs":[...], "preds":[...],
                    "terminator", "terminator_cond" } ],
  "assignments": [ { "line", "lhs_path", "rhs_expr", "is_decl" } ],
  "conditions":  [ { "line", "expr", "kind": "if|switch|loop|ternary", ... } ],
  "calls":       [ { "line", "callee", "args", "by_ref_arg_indexes":[...] } ],
  "by_ref_params": [ { "name", "type", "is_reference", "is_pointer", "written": bool } ],
  "enums_used":  [ ... ] }
```
Missing z/TPF headers: parse best-effort (`-ferror-limit=0 -w`); most bodies parse.

The `cfg_extract` invocation is **disk-cached** per file content-hash; precompute Step 5
(cfg-warm) runs it in **parallel** over every `*.cpp` up front (`vbt/precompute/parallel.py`
→ `vbt/cpp_frontend/wrapper.py:warm_cfg_cache`), so a trace hits the cache instead of
re-shelling out per file — the dominant 22k cold-start win (§12).

Worked truth (`softCardValue`): setter `@1002` guarded by
`linkSourceArea != 0 && linkSourceArea->lstknpoa == 'Y'`; setter `@1033` guarded by
`lwrCommon.process.various.expressPay == Cas::On`.

## 6. Set value, constants/enums, and dependent variables

### Set value + constant/enum resolution
Capture the RHS expression. **Resolve symbolic constants to their values** — C++
enum constants (e.g. `SoftCardValueDetail::ExpressPayTransaction`) via a cross-file
enum index (reuse blueprint `enum_values` where correct; in the full 22k-file codebase
the defining header is present), and ASM `EQU`/`DC` constants (e.g. `LG#C400`). This
applies to **both** the set value **and** the guard conditions (which compare against
enum constants like `Cas::On`, `'Y'`, `YankeeIndicator`).

### Dependent variables — three sources
1. **Setter operands (RHS).** Constants → resolved & terminal. ASM RMW (e.g. `OI`)
   adds the destination's **prior value** as a dep var.
2. **Condition variables** — every variable in the collected guards.
3. **Function-call outputs** — the function's output IS a dep var.
   - **C++:** output = **return value + every by-reference/pointer param it writes**
     (requires the LibTooling by-ref-write analysis).
   - **ASM:** an operand is a call output when its **reaching definition** is a call
     (no intervening local write) — e.g. `WK_RRC` after `ENTRC DB72` — OR it matches a
     glossary implicit-output (`DB_MANAGED_FIELD_WRITES`, `ALLOC_RESULT_REG`, return
     register `R15`). When the output is a register, **follow it one step** to its
     store into a named field (closes the register-drop gap).

### Cross-boundary identity re-resolution (the "terminal" trap) — **DONE** (§6b)
The dep-var trace is otherwise **name-keyed**: it searches for a setter by the dep's
own name/tail and declares the dep **terminal** when none is found in scope. But a
variable's identity is **not stable across scope boundaries** — the same logical value
can wear a different name in an adjacent scope. Before concluding "terminal" the engine
re-resolves identity at each boundary:

- **C++ function call — formal parameter ↔ caller's actual argument (the IN-direction;
  dual of §6.3's OUT-direction return/by-ref output).** A formal parameter is **bound,
  not set**: read-only inside its function, its value-defining "setter" is the
  **actual-argument expression at each call site**. The name search finds no in-scope
  write → wrongly terminal (e.g. `int countOfCidLrecs` read in `setSoftCardIndicatorValues`
  but bound from the caller's `numberOfCidRecords` at arg-index 2). `cfg_extract` now emits
  the full ordered `params` list (name + positional index) per function; the recursion
  maps a reachability-scoped call site's positional `args[index]` back to the formal,
  emits the actual as a binding "setter" guarded by the **call-site conditions in the
  caller**, and re-roots the actual's variables as children in the caller's scope
  (`vbt/depvars/recurse.py:_param_binding_setters`). **Soundness:** every kept call site
  is a verified binding (OR alternatives), nothing fabricated; bounded by the same
  forward-reachable / `max_offchain_files` prune. **Noise gate:** a binding is emitted
  ONLY when crossing the boundary reveals a name the codebase-wide TAIL-based search
  can't already see — i.e. a scalar value-parameter rename. A pointer/reference param
  passed through (`o`→`o`, or a member read `o->field`) has the same tail and is already
  covered globally, so no binding is emitted (no duplication). Validated: fixture D10.
  **Depth semantics:** a binding child is enqueued at the **SAME depth** when the actual
  is a single identifier (a *pure rename* — the same logical value under a different name,
  not a new derivation, so it must not consume the `max_dep_var_depth` budget — cycle-safe
  via the memo), and at **`depth+1`** when the actual is a *computed* expression
  (`a + b`, `getX()` — a genuine data dependency). So a rename chain resolves all the way
  to the variable that is actually SET regardless of how many call boundaries it crossed,
  while depth is reserved for real derivations. Validated: fixture D11 (pure rename free),
  D12 (computed-arg costs depth), and real-corpus `countOfCidLrecs`→`numberOfCidRecords`
  expanding to its real setter at the default depth 1.
- **Cross-language ASM↔C++** — same storage, different language name: the §7 alias-set
  is searched (root AND dep), but counterpart setters are kept ONLY when **call-graph
  reachable** like any other setter (current decision: dataflow follows the call graph).
- **ASM shared work-area / DSECT overlay** — a counterpart written in a module that is
  **not call-graph-reachable** (communication bypasses the call graph) is **NOT**
  surfaced. This is a *different mechanism* (storage overlay, not parameter binding) and
  is deliberately **out of scope for now** — VBT models dataflow along the call graph
  only. Tracked as "Issue B" ([[project_vbt_crosslang_resolution]]).

### Register-indirect setter source — **DONE** (§6a)
A setter whose SOURCE is register-indirect — `MVC LWRLS4CSCRES,0(R1)` — used to stop the
trace, because `is_dep_var_candidate("0(R1)")` correctly rejects a bare displacement.
`vbt/resolve/register_indirect.py` (+ `vbt/resolve/asm_indirect_glossary.py` for the
missing opcodes) now resolves `Rn` to the real named field, bounded + deterministic:
1. **Named-prefix** `FIELD(Rn)` → the field is the dep.
2. **USING context** — nearest `active_usings` line ≤ `before_line`; if `Rn` is a DSECT
   base there, the displacement resolves to the member at that offset (high confidence).
   Also honours static `meta.base_registers`.
3. **CFG-aware reaching-def** on `Rn` — a self-contained port of the sound
   `_backtrack_register_dep_vars` core with two survey defects fixed: every candidate is
   routed through `is_dep_var_candidate` (no `L'NAME` length-attribute leakage), and
   predecessor blocks scan with a per-block `before_line` bound (no reading past the call
   site). Handles mem-load / reg-copy / LA-family / PC-relative / load-multiple / immediate
   / alloc / DB-context / call-return producers; emits **OR** alternatives when paths diverge.

**Soundness — give up, don't guess:** not found within bounds, or `Rn` is caller-inherited
(no in-file def before `before_line`) → emit an **indirection envelope** (`indirect_via=Rn`),
never a fabricated field. Validated: `LWRLS4CSCRES`'s `0(R1)` → `LWRLSDF60SF1VER`.

### Worklist entry (per dep var)
`{ name (+alias-set), location:(file,line), depends_on:parent,
   relationship: setter_operand|condition|function_output,
   context:(setter,chain), depth }`
Paired with a **visited/memo** keyed on `(alias-set, site, chain-context)`.

### Processing a dep var — same engine, recursively
- Find its setters cross-language (same as §3.1).
- **Chain-scoped reaching-def reachability:** the dep var was read at `(file y, line x)`
  with the chain `a→b→…→y→…`. A dep-var setter is relevant iff it is forward-reachable
  inside some chain file `F` **before `F`'s descend call site** (the call to the next
  chain file); for the discovery file `y` the bound is **line x**. Setters after a
  file's descend point can't affect the read → dropped.
  - **Per-call-site bound:** when a hop has multiple call sites, each gives its own
    "before" bound → treated as separate paths.
  - Resulting chain = `prefix-up-to-F + forward path from F to the setter`. Multiple
    paths ⇒ separate `(setter, chain)` tuples.
- **Function-output dep vars re-root** into the callee (descend into the function),
  rather than the chain-prefix scan above.
- **All-reachable + annotate provable overwrites:** keep every reachable setter as an
  OR alternative (sound); additionally flag when one setter *provably* overwrites
  another on the same path (precision lever, not a drop).
- A setter not reachable for *this* chain is dropped here (may still matter for a
  different chain of the root — fine, each tuple is independent).
- Bounded by `max-dep-var-depth` (param; tune later).
- **Memoize / intern:** reuse already-traversed `(variable, setter, chain)` sub-walks;
  the result is a **content-addressed DAG** (chainless engine's proven pattern).

## 7. Cross-language name resolution (alias-set)

A logical variable is an **alias-set** across languages. We compute the alias-set
**once up front** (needed for cross-language setter search) and **re-resolve at each
language-boundary hop** for the local name.

- **High-certainty only.** Low-certainty mappings are **dropped**, not tagged.
- Resolver, layered (validated): `find_cpp_chain.py` (exact 3-layer; Link A =
  lowercase-identity, Link B = byte-offset overlay) → fallback `find_cpp_for_asm.py`
  (after fixing its uppercase-only anchor-regex bug) when no gen header exists →
  `field_asm_aliases` as a cheap pre-pass. **Verdict: IMPROVE-THEN-USE.**
  Validated: `softCardValue ↔ LWRPOSFCRDV` (exact); `LG1OSI ↔ CasGLRec.onlineSrcInd`.

## 8. Output

**One entry per `(setter, chain)`** (same code location may appear multiple times,
once per chain). Block/function code is **deduped** into a top-level `codeBlocks`
table keyed by a stable id (block = ASM block, function = C++ function); setters and
conditions carry a `blockId` + line range instead of inlining code.

Root variable:
```json
{ "rootVariable": { "name": "...",
    "setters": [ { "setterId", "value", "setterCodeChunk",
        "location": {"file","startLine","endLine"},
        "chain": ["a","b","c","...→setter"],
        "conditions": [ { "order", "condition", "blockId", "location" } ],
        "dependentVariables": [ { "name", "foundAt": {...} } ] } ] },
  "codeBlocks": { "<blockId>": { "file","startLine","endLine","code" } } }
```
Dependent variable: same shape under `dependentVariable`, plus a `dependencies` list
(`{variableName, foundAt, relevantCodeChunk|blockId}`).

## 9. Reuse map (verdicts — surveyed 2026-06-09)

| Capability | Verdict | Source |
|---|---|---|
| Reachability + routes + per-hop guards | IMPROVE-THEN-USE (add `before_line` bound) | `route_finder` + `chainless_reachability`/`caller_walker` + `cross_file_bridge_backward` |
| ASM setter detection | USE-AS-IS | glossary `SETTER_INST`/`classify_setter`, `_find_scoped_setter_sites`, `enumerate_setter_roots(job_id=None)` |
| ASM CFG build | USE-AS-IS | `_build_cfg_maps`, `backward_reachable_blocks` |
| ASM condition collection | IMPROVE-THEN-USE (polarity + N-level) | `_extract_block_conditions_before_line` |
| Cross-language name (high-certainty) | IMPROVE-THEN-USE (gen-absent fallback, regex fix) | `find_cpp_chain` → `find_cpp_for_asm` → `field_asm_aliases` |
| C++ setters/conditions/dataflow | REBUILD on LibTooling | replaces GVL + tree-sitter `_condition_stack` |
| Indirect calls | USE-AS-IS (read-only) | `api.utils.indirection` envelope + bridge inference |
| Register-indirect setter source | REBUILT (sound port, **DONE** §6a) | `vbt/resolve/register_indirect.py` (+ `asm_indirect_glossary.py`); ports `_backtrack_register_dep_vars` read-only with the 2 survey defects fixed |
| Precompute parallelism / RAM sizing | reuse pattern (read-only) | `api/config.py` worker/memory probes (§12) |
| Memoization / DAG | reuse pattern | chainless interned-node model |

## 10. Module layout (pluggable)

```
vbt/
├── SPEC.md                  ← this file
├── interfaces.py            ← dataclasses + Protocols for every module
├── precompute/              ← call_graph, modifier_index (sites + MVC), parallel (workers/RAM)
├── cpp_frontend/            ← LibTooling C++ tool + Python wrapper (+ warm_cfg_cache)
├── resolve/name_resolver.py ← high-certainty ASM↔C++ alias-set
├── resolve/const_resolver.py← enum / EQU / DC resolution (disk-backed + parallel)
├── resolve/register_indirect.py ← register-indirect setter-source resolution (§6a)
├── setters/                 ← asm_setters.py (reuse), cpp_setters.py (new)
├── reach/route.py           ← route_finder + before_line bound + forward_reachable_files
├── conditions/              ← asm_conditions.py (improved), cpp_conditions.py (from CFG)
├── depvars/                 ← dep-var sources + recursive engine + memo + cross-lang counterpart
├── engine.py                ← orchestrator (root var → tuples → recurse)
├── precompute_all.py        ← one-shot precompute CLI (Steps 0,2–5)
├── trace.py                 ← trace CLI (scope knobs, --progress, emit modes)
└── output/                  ← assembler.py (JSON + codeBlocks dedup), emit.py (split/strip/msgpack/zip)
```

## 11. Open params (decide later)
Route caps, overwrite-annotation depth. Cycle safety everywhere via visited-sets keyed on
`(file, function/block, call-site)`. **`max-dep-var-depth` is now decided: default `1`**
(deep dep-var recursion is opt-in at 22k scale — see §13).

## 12. Scale & performance (the 22k batch)

### 12.1 Chain-first reachability prune (the explosion fix — result-preserving)
Before opening **any** candidate file, the root setter search restricts the writer-file
set to those **forward-reachable from the chain tail**, using `file_call_graph` METADATA
only (no file opens): `RouteEngine.forward_reachable_files(tail)`. The reachable set is a
guaranteed **superset** of every file a verified `route(tail, setter)` could traverse, so a
setter that would survive can never be pruned; chain/tail files are always kept regardless.
At 22k a hot variable's `files_for` is huge — opening them all is the explosion this avoids.
The dep-var recursion applies the same prune (union of `forward_reachable_files` over all
chain hops) before opening off-chain candidate files. **Pure speedup, no result change.**

### 12.2 Parallel, RAM/CPU-aware precompute
`vbt/precompute/parallel.py` runs the modifier-index build, the const-resolver build, and
the new Step 5 cfg-warm on a `ProcessPoolExecutor`:
- `plan_workers()` decides worker count / batch size / per-proc memory cap from env
  overrides, falling back to a RAM- and CPU-aware auto plan that **reuses `api/config.py`**
  probes read-only (cgroup-aware); a CPU-only fallback keeps VBT standalone if that import
  fails.
- `parallel_map()` mirrors the proven `multi_file/orchestrator.py` pool setup (fork context,
  daemon-flag clearing for nested pools under a Celery prefork daemon, niced + SIGINT-ignoring
  workers, periodic worker recycling).

**Determinism contract:** results are keyed to their INPUT index (never as-completed order);
callers pass file PATHS and merge picklable partials in a fixed order, so every artifact is
**byte/content-identical regardless of worker count**. Env knobs: `VBT_WORKERS` (0=auto),
`VBT_BATCH_SIZE` (20), `VBT_MEM_BUDGET_FRACTION` (0.60), `VBT_FILE_TIMEOUT_SECONDS` (120).
Typical speedups vs serial: modifier ≈2.3×, const ≈2.6×, cfg-warm ≈4.5×.

### 12.3 Disk-backed, kb_id-free caches (no `index.db`)
- `file_call_graph.json` — in the job/output dir next to the blueprints.
- modifier index / const resolver / cfg cache — manifest-hashed artifacts under
  `$VBT_CACHE_DIR` (default `vbt/.cache/`), keyed on a per-file (path, size, mtime) +
  artifact-version fingerprint. The const resolver is now **disk-backed** (was
  in-process-only). The modifier index now stores concrete `sites_for(var)` and indexes
  `MVC` (and other empty-`flow["a"]`) ASM destinations via a raw-source fallback — **DONE**
  (previously MVC-set ASM vars were invisible to auto-discovery).

## 13. Scope / output knobs (engine + CLI)
`trace_root_variable` (and the matching `vbt.trace` flags) expose:
- `disable_dependents` (`--disable-dependents`) — root setters only; skip the dep-var tree.
- `candidate_functions` (`--candidate-functions`) — keep only setters whose function/block
  matches one of these names.
- `home_hint` (`--home-hint`) — scopes cross-language alias resolution.
- `progress` (`--progress`) — per-phase **STDERR** progress logs (the JSON on stdout is
  untouched). Fixes the "looks hung" UX on long traces.
- `max_dep_var_depth` (`--max-dep-var-depth`) — **default `1`** (deep recursion opt-in).
- existing: `candidate_stems`, `max_paths`, `max_call_depth`, `max_routes`, `max_route_len`,
  `max_offchain_files`, `asm_max_levels`.

**Cross-language dep vars:** like the root variable, each dependent variable's HIGH-certainty
ASM↔C++ aliases are resolved and its counterpart's setters searched too (a C++ field's ASM
counterpart, and vice-versa, writes the same logical variable).

### 13.1 Output emit modes (`vbt/output/emit.py` — all default-off)
A post-processing writer layer that never touches the engine. Default = one JSON dict to
stdout/`--out`, byte-identical to before. Opt-in: `--out-dir` (split into rootVariable +
per-dep-var + shared `codeBlocks` + index manifest; losslessly reassembles), `--no-code`
(drop source TEXT, keep every file+line ref), `--format msgpack`, `--zip`.

## 14. Celery surface
Two `kb_id`-free tasks run the heavy phases as managed background jobs inheriting the
`celery_app` worker resource limits (no new worker config):
- **`asm.vbt_precompute`** (`api/tasks/vbt_precompute_task.py`) — call graph → modifier index
  → const resolver → parallel cfg-warm. `cache_in_job_dir` (DEFAULT true) sets
  `VBT_CACHE_DIR = <blueprint_dir>/vbt_cache` for the run scope, so artifacts persist
  **per-project**, co-located, shareable across workers. `parallel_map` clears the daemon
  flag + forces the fork context so the nested pool runs under a Celery prefork daemon.
- **`asm.vbt_trace`** (`api/tasks/vbt_trace_task.py`) — precompute (cached) → trace → emit.
  `trace_options` are filtered through `inspect.signature` (forward-compat: unknown keys are
  dropped, never raised); `emit` maps 1:1 onto `write_result`.

## 15. Tests
`vbt/tests/`: `test_engine` (LG1OSI + softCardValue end-to-end + the R1–R6/D1–D9 reachability
fixture), `test_emit`, `test_precompute` (modifier index incl. MVC + const + sites),
`test_parallel` (env plan + deterministic map), `test_register_indirect` (resolution + sound
give-up); plus `api/tasks/test_vbt_{trace,precompute}_task`.
