# Audit Prompt — Find All Even-Odd Register-Pair Instruction Cases (10k+ ASM corpus)

> This is the only prompt file you need to paste. Before pasting it into Copilot
> (Copilot Chat / agent mode) **inside the client repo checkout**, fill the
> **INPUTS TO FILL** block. The prompt carries its own scanner script — the agent
> writes it to `scan_even_odd_pairs.py` at the repo root and runs it; nothing else
> to install.

---

## INPUTS TO FILL

```text
ASM_DIR=<root dir of the client .asm/.mac corpus, e.g. datasource/...>
COPY_PATHS=<space-separated extra dirs holding REGEQU / copybooks, or leave blank>
OUT_JSON=scan_pairs.json
PY=<repo venv python, e.g. env/bin/python3 — else python3>
```

Notes:
- `ASM_DIR` is scanned recursively for `*.asm` and `*.mac`.
- `COPY_PATHS` matters: if the client's `REGEQU` copybook (the file that does
  `RAC EQU 0 / RG1 EQU 1 / … / RDA EQU 8 / RDB EQU 9 / …`) is reachable, symbolic
  register names resolve to numbers and the scan reports them as `EQU_RESOLVED`
  instead of as unresolved. Point `COPY_PATHS` at wherever copybooks live.
- The scanner reuses the project's own parser (`file_reader.py`,
  `tokenizer.py`) and register resolver
  (`passes/variable_lineage_builder.py`), so its classification matches **what the
  analyzer actually sees**, not a re-implementation. Run it from the repo root so
  those imports resolve.

---

## ROLE

You are a static-analysis auditor. A recent fix
(`docs/2026-06-24-asm-register-shift-crash-fix.md`) repaired a crash where a z/TPF
**symbolic** register name in a **double-shift** (`SRDL RDA,32`) reached
`int(target[1:])` → `ValueError: invalid literal for int() with base 10: 'DA'` →
the **entire file was skipped**, losing all its lineage. The fix:

1. made the double-shift handler resolve the operand through the program's own
   `EQU`s first, and
2. added a small fallback table `_TPF_EVEN_ODD_PAIRS` (symbolic even → odd partner:
   `RAC→RG1, RGA→RGB, RGC→RGD, RGE→RGF, RDA→RDB, RDC→RDD, RDE→RDF`) for the
   copybook-less case.

That fix is **narrow**: it covers only the 4 double-shift opcodes
(`SLDA/SLDL/SRDA/SRDL`) and only 7 symbolic names. But a double-shift is just one
member of a **much larger family**: the z/Architecture Principles of Operation
(`docs/ibm/dz9zr006.pdf`) documents ~40 instructions that operate on an **even-odd
general-register pair** (multiply, divide, MVCL/CLCL, compare-and-swap-double,
crypto, etc.). The symbolic→numeric mapping itself is **not in any IBM doc** — it
lives in the client's `REGEQU` copybook.

**Your job:** find every site in the client corpus that uses an even-odd
register-pair instruction, and classify each into one of three problem classes:

- **(A) CRASH-class** — a double-shift whose first operand is a symbolic/unresolved
  register not covered by an `EQU` nor the table. Pre-fix this **crashed the whole
  file**; post-fix it is silently **skipped** (that one instruction's lineage is
  lost). Each is a symbolic name that should be **added to `_TPF_EVEN_ODD_PAIRS`**.
- **(B) TABLE-completion** — symbolic register names actually used as pair operands.
  These tell you, empirically, which pairs the table must contain (the docs can't).
- **(C) LINEAGE-GAP** — any even-odd-pair instruction where the analyzer tracks
  only the named even register and **never the odd partner `Rn+1`** (multiply/
  divide are tracked name-only; MVCL/CLCL/CDS/crypto/etc. are not modeled as pairs
  at all). Not a crash — silently incomplete lineage.

Do **not** modify production code. Produce a findings report; a clearly-labeled
"proposed changes" appendix is allowed but must not be applied.

---

## STEP 1 — Write the scanner to the repo root and run it

Create `scan_even_odd_pairs.py` at the repo root with exactly the contents in the
**SCANNER** block below, then run (from the repo root, using the INPUTS):

```bash
PYTHONPATH=. $PY scan_even_odd_pairs.py --asm-dir "$ASM_DIR" --out "$OUT_JSON" \
  ${COPY_PATHS:+--copy-paths $COPY_PATHS}
```

It prints a summary and writes `$OUT_JSON`. The JSON has these top-level keys:
`totals` (`by_class`, `by_opcode`, `by_handling`), `crash_or_gap_class`
(class **A** — `count`, `double_shift_crash_prefix`, `symbolic_name_inventory`,
`sites`), `symbolic_pair_usage` (class **B** — `name_counts`, `sites`),
`register_equates_found` (EQU labels resolving to 0–15 — the REGEQU map when
present), `stm_lm_evidence` (consecutive-store evidence for inferring pair order),
and `all_sites_sample`.

### Calibration baseline (sanity check before trusting a 10k run)

On the bundled 662-file reference corpus (`datasource/`) the scanner reports:
`files=662, parse errors=0, pair sites=861`; `by_class={NUMERIC_EVEN:834,
TABLE_FALLBACK:27}`; `by_handling={untracked:515, arith_namedonly:295,
shift_pairaware:51}`; **CRASH-class=0**; symbolic names used = `RGA, RDA, RGE, RGC`
(e.g. `DR RGA`, `MVCL RGE/RDA`). If your run on a comparable corpus shows wildly
different shape (e.g. thousands of parse errors, or every site `OTHER`), stop and
debug the setup before drawing conclusions.

---

## STEP 2 — Interpret the scan (the three classes)

1. **Class A — `crash_or_gap_class`.** Every `SYMBOLIC_UNCOVERED` site is a real
   "such case." For `is_double_shift: true` sites, this is the exact crash the fix
   addressed — list each with `file:line`, opcode, and the unresolved name. The
   `symbolic_name_inventory` is the de-duplicated set of names to add to the table.
   Cross-check each against `register_equates_found`: if the name *does* appear
   there, the copybook simply wasn't on `COPY_PATHS` (re-run with it); if it does
   **not**, the mapping is genuinely external and must be supplied by hand.

2. **Class B — `symbolic_pair_usage.name_counts`.** The complete inventory of
   symbolic register names used in *any* pair instruction. Compare against
   `code_table_TPF_EVEN_ODD_PAIRS`: names present = validated table entries; names
   absent = proposed additions (with provenance from STEP 3).

3. **Class C — `totals.by_handling`.** `arith_namedonly` = multiply/divide sites
   where the named even register is tracked but the odd partner `Rn+1` (which holds
   half the product / the quotient) is **not**. `untracked` = pair instructions the
   analyzer does not model as pairs at all (MVCL/CLCL/CDS/crypto/convert/translate/
   LPQ/STPQ). Roll these up `by_opcode` so the dominant gaps are visible.

---

## STEP 3 — Derive the symbolic→numeric mapping (docs can't; the corpus can)

For every symbolic name in class A/B, establish its number and even/odd partner
from corpus evidence, in this priority order:

1. **`register_equates_found`** — a direct `EQU` (e.g. `RDA EQU 8`) is authoritative.
   Re-run with `COPY_PATHS` pointing at the copybook dir to populate this.
2. **`stm_lm_evidence`** — a consecutive store like `STM RAC,RGF,SAVEREG` plus a
   matching `LM RG1,RGF,SAVEREG+4` proves ascending order and that `RG1 = RAC+1`
   (this is exactly how the fix doc fixed `RAC=R0…RGF=R7`). Use these to order names
   whose numbers you can't read directly.
3. **Source comments** at the use site (e.g. `SHIFT RDA TO RDB`) — state the pairing
   directly; cite the line.

A symbolic even register's partner is the **next** name in the ascending order you
established (even→odd). Record provenance per name; mark any you cannot ground as
`unverified` rather than guessing.

---

## STEP 4 — Confirm against the actual code, then spot-validate

- Open `passes/variable_lineage_builder.py` and confirm the handling labels: the
  double-shift branch (the `SHIFT_OPS` / `_TPF_EVEN_ODD_PAIRS` site) is the only
  pair-aware one; the arithmetic handler (`M/MR/D/DR…`, the `op_type` block) writes
  the **named** register only; the long/CDS/crypto opcodes have no pair handling.
  Correct any `handling` label in the report if the code differs from the table.
- Pick a sample to read against source + the POP: every distinct opcode in
  `by_opcode`, every class-A site, and ~10 class-C sites. For each, confirm from
  `dz9zr006.pdf` which operand is the pair and where the result lands (multiply:
  product across `R1,R1+1`; divide: remainder→`R1`, quotient→`R1+1`; MVCL/CLCL:
  `R1`=addr+`R1+1`=len for both operands). Flag any scanner mis-classification.
- **Caveat to apply:** the scanner counts each macro/COPY **expansion** as a site,
  so one source line can appear N times (e.g. `DR RGA` ×5 from a macro). When
  reporting "sites," distinguish source-distinct from expansion-counted.

---

## STEP 5 — Required output

1. **Totals table:** files scanned, parse errors, pair sites, `by_class`,
   `by_handling`, `by_opcode`.
2. **Class A (crash/skip) table:** `file:line | opcode | unresolved name | in REGEQU? | proposed pair`.
3. **Class B (table completion):** the symbolic-name inventory with, per name,
   `count | resolved number | partner | provenance (EQU / STM-LM / comment / unverified)`,
   and a concrete proposed `_TPF_EVEN_ODD_PAIRS` diff.
4. **Class C (lineage gaps):** per-opcode counts of `arith_namedonly` (odd-partner
   untracked) and `untracked` (whole pair unmodeled), with 1–2 example `file:line`
   each.
5. **Confidence note:** what is `confirmed` (read against source + POP) vs
   `candidate` (scanner-only). List anything you could not verify and why.

Be concrete: cite `file:line`, show the source line, and cite the POP page/section
for each instruction's pair semantics. Default to "needs evidence" over "looks fine."

---

## SCANNER — write this verbatim to `scan_even_odd_pairs.py` at the repo root

```python
#!/usr/bin/env python3
"""
scan_even_odd_pairs.py — Corpus scanner for z/Architecture even-odd
general-register-pair instructions. Reuses the project's own FileReader (COPY
expansion + continuation handling) and VariableLineageBuilder register resolver
so classification matches what the analyzer actually sees.

Run from the repo root:
    PYTHONPATH=. python3 scan_even_odd_pairs.py --asm-dir <dir> --out scan_pairs.json
"""
import argparse
import json
import os
import re
import sys
import traceback
from collections import Counter

from statement_id_generator import StatementIDGenerator
from file_reader import FileReader
from passes.variable_lineage_builder import VariableLineageBuilder
try:
    # Present once the double-shift crash fix is merged.
    from passes.variable_lineage_builder import _TPF_EVEN_ODD_PAIRS
except ImportError:
    # Older client checkout (pre-fix): use the same default so the scan still runs.
    _TPF_EVEN_ODD_PAIRS = {
        "RAC": "RG1", "RGA": "RGB", "RGC": "RGD", "RGE": "RGF", "RDA": "RDB",
        "RDC": "RDD", "RDE": "RDF",
    }

# --- The even-odd register-pair instruction set (from dz9zr006.pdf) -----------
# opcode -> (full_name, family, [operand indices that are even-odd pair R-fields],
#            handling)  where handling is the analyzer's CURRENT treatment:
#   "shift_pairaware" : double-shift handler, pair-aware (the fixed path)
#   "arith_namedonly" : arithmetic handler tracks the NAMED reg only (odd partner gap)
#   "untracked"       : not modeled as a pair at all (whole-pair gap)
DOUBLE_SHIFTS = {"SLDA", "SLDL", "SRDA", "SRDL"}
PAIR_INSTRS = {
    # Multiply: R1 is the pair (multiplicand in R1+1, 64-bit product across R1,R1+1)
    "M": ("MULTIPLY", "multiply", [0], "arith_namedonly"),
    "MR": ("MULTIPLY", "multiply", [0], "arith_namedonly"),
    "MFY": ("MULTIPLY", "multiply", [0], "untracked"),
    "MFYR": ("MULTIPLY", "multiply", [0], "untracked"),
    "ML": ("MULTIPLY LOGICAL", "multiply", [0], "untracked"),
    "MLR": ("MULTIPLY LOGICAL", "multiply", [0], "untracked"),
    "MLG": ("MULTIPLY LOGICAL", "multiply", [0], "untracked"),
    "MLGR": ("MULTIPLY LOGICAL", "multiply", [0], "untracked"),
    # Divide: R1 is the pair (dividend in pair; remainder->R1, quotient->R1+1)
    "D": ("DIVIDE", "divide", [0], "arith_namedonly"),
    "DR": ("DIVIDE", "divide", [0], "arith_namedonly"),
    "DL": ("DIVIDE LOGICAL", "divide", [0], "untracked"),
    "DLR": ("DIVIDE LOGICAL", "divide", [0], "untracked"),
    "DLG": ("DIVIDE LOGICAL", "divide", [0], "untracked"),
    "DLGR": ("DIVIDE LOGICAL", "divide", [0], "untracked"),
    "DSG": ("DIVIDE SINGLE", "divide", [0], "untracked"),
    "DSGR": ("DIVIDE SINGLE", "divide", [0], "untracked"),
    "DSGF": ("DIVIDE SINGLE", "divide", [0], "untracked"),
    "DSGFR": ("DIVIDE SINGLE", "divide", [0], "untracked"),
    # Shift double: R1 is the pair (the FIXED, pair-aware path)
    "SLDA": ("SHIFT LEFT DOUBLE", "shift_double", [0], "shift_pairaware"),
    "SLDL": ("SHIFT LEFT DOUBLE LOGICAL", "shift_double", [0], "shift_pairaware"),
    "SRDA": ("SHIFT RIGHT DOUBLE", "shift_double", [0], "shift_pairaware"),
    "SRDL": ("SHIFT RIGHT DOUBLE LOGICAL", "shift_double", [0], "shift_pairaware"),
    # Compare double and swap: R1 and R3
    "CDS": ("COMPARE DOUBLE AND SWAP", "cds", [0, 1], "untracked"),
    "CDSY": ("COMPARE DOUBLE AND SWAP", "cds", [0, 1], "untracked"),
    "CDSG": ("COMPARE DOUBLE AND SWAP", "cds", [0, 1], "untracked"),
    # Move/Compare logical long: R1 and (R2 or R3)
    "MVCL": ("MOVE LONG", "long", [0, 1], "untracked"),
    "MVCLE": ("MOVE LONG EXTENDED", "long", [0, 1], "untracked"),
    "MVCLU": ("MOVE LONG UNICODE", "long", [0, 1], "untracked"),
    "CLCL": ("COMPARE LOGICAL LONG", "long", [0, 1], "untracked"),
    "CLCLE": ("COMPARE LOGICAL LONG EXTENDED", "long", [0, 1], "untracked"),
    "CLCLU": ("COMPARE LOGICAL LONG UNICODE", "long", [0, 1], "untracked"),
    "CUSE": ("COMPARE UNTIL SUBSTRING EQUAL", "long", [0, 1], "untracked"),
    "CMPSC": ("COMPRESSION CALL", "crypto", [0, 1], "untracked"),
    # Load/Store pair (quadword): R1
    "LPQ": ("LOAD PAIR FROM QUADWORD", "pair_ls", [0], "untracked"),
    "STPQ": ("STORE PAIR TO QUADWORD", "pair_ls", [0], "untracked"),
    # Checksum / find
    "CKSM": ("CHECKSUM", "misc", [1], "untracked"),
    "FLOGR": ("FIND LEFTMOST ONE", "misc", [0], "untracked"),
    # Cryptographic: pair is R2
    "KM": ("CIPHER MESSAGE", "crypto", [1], "untracked"),
    "KMC": ("CIPHER MESSAGE WITH CHAINING", "crypto", [1], "untracked"),
    "KIMD": ("COMPUTE INTERMEDIATE MESSAGE DIGEST", "crypto", [1], "untracked"),
    "KLMD": ("COMPUTE LAST MESSAGE DIGEST", "crypto", [1], "untracked"),
    "KMAC": ("COMPUTE MESSAGE AUTHENTICATION CODE", "crypto", [1], "untracked"),
    # UTF/Unicode convert: R1 and R2
    "CU12": ("CONVERT UTF-8 TO UTF-16", "convert", [0, 1], "untracked"),
    "CU14": ("CONVERT UTF-8 TO UTF-32", "convert", [0, 1], "untracked"),
    "CU21": ("CONVERT UTF-16 TO UTF-8", "convert", [0, 1], "untracked"),
    "CU24": ("CONVERT UTF-16 TO UTF-32", "convert", [0, 1], "untracked"),
    "CU41": ("CONVERT UTF-32 TO UTF-8", "convert", [0, 1], "untracked"),
    "CU42": ("CONVERT UTF-32 TO UTF-16", "convert", [0, 1], "untracked"),
    "CUUTF": ("CONVERT UNICODE TO UTF-8", "convert", [0, 1], "untracked"),
    "CUTFU": ("CONVERT UTF-8 TO UNICODE", "convert", [0, 1], "untracked"),
    # Translate extended families: R1
    "TRE": ("TRANSLATE EXTENDED", "translate", [0], "untracked"),
    "TRTE": ("TRANSLATE AND TEST EXTENDED", "translate", [0], "untracked"),
    "TRTRE": ("TRANSLATE AND TEST REVERSE EXTENDED", "translate", [0], "untracked"),
    "TROO": ("TRANSLATE ONE TO ONE", "translate", [0], "untracked"),
    "TROT": ("TRANSLATE ONE TO TWO", "translate", [0], "untracked"),
    "TRTO": ("TRANSLATE TWO TO ONE", "translate", [0], "untracked"),
    "TRTT": ("TRANSLATE TWO TO TWO", "translate", [0], "untracked"),
    # Linkage-stack
    "ESTA": ("EXTRACT STACKED STATE", "stack", [0], "untracked"),
    "MSTA": ("MODIFY STACKED STATE", "stack", [0], "untracked"),
    # DFP <-> packed (extended / 128-bit only)
    "CXSTR": ("CONVERT FROM SIGNED PACKED", "dfp", [1], "untracked"),
    "CXUTR": ("CONVERT FROM UNSIGNED PACKED", "dfp", [1], "untracked"),
    "CSXTR": ("CONVERT TO SIGNED PACKED", "dfp", [0], "untracked"),
    "CUXTR": ("CONVERT TO UNSIGNED PACKED", "dfp", [0], "untracked"),
}

_REG_FIELD_RE = re.compile(r"^[A-Za-z@$#][A-Za-z0-9@$#_]*$")


def _build_equ_table(lines):
    """Reuse the analyzer's own first-pass EQU collection so resolution matches."""
    vlb = VariableLineageBuilder()
    for line in lines:
        if line.opcode and line.opcode.upper() == "EQU" and line.label:
            symbol = line.label.upper()
            if line.operands:
                resolved = vlb._resolve_equ_value(line.operands[0])
                if resolved is not None:
                    vlb.equ_symbols[symbol] = resolved
    return vlb


def _classify_operand(vlb, raw):
    """Classify a single pair R-field operand exactly as the analyzer would."""
    tok = (raw or "").strip().upper()
    # numeric register, e.g. "R8" — the shift handler's first branch
    if tok.startswith("R") and tok[1:].isdigit():
        n = int(tok[1:])
        return ("NUMERIC_EVEN" if n % 2 == 0 else "NUMERIC_ODD"), f"R{n}"
    # symbolic with a local EQU / REGEQU -> normalizes to Rn
    norm = vlb._normalize_register_operand(tok)
    if norm and norm.startswith("R") and norm[1:].isdigit():
        return "EQU_RESOLVED", f"{tok}->{norm}"
    # symbolic covered by the in-code fallback table
    if tok in _TPF_EVEN_ODD_PAIRS:
        return "TABLE_FALLBACK", tok
    # looks like a symbol (a register name) but nothing resolves it -> the bug class
    if _REG_FIELD_RE.match(tok) and not tok.isdigit():
        return "SYMBOLIC_UNCOVERED", tok
    return "OTHER", tok


def scan_file(path, search_paths):
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen, search_paths=search_paths)
    lines = list(reader.read_file(path))
    vlb = _build_equ_table(lines)

    sites = []
    equ_regs = {}
    stm_lm = []
    symbolic_names = Counter()

    for sym, val in vlb.equ_symbols.items():
        try:
            iv = int(str(val))
        except (TypeError, ValueError):
            continue
        if 0 <= iv <= 15:
            equ_regs[sym] = iv

    for line in lines:
        if not line.opcode:
            continue
        opcode = line.opcode.upper()
        ops = line.operands or []
        prov = getattr(line, "provenance", None)
        lineno = getattr(prov, "original_line", None)

        if opcode in ("STM", "STMG", "LM", "LMG") and len(ops) >= 2:
            stm_lm.append({"opcode": opcode, "r1": ops[0].upper(),
                           "r3": ops[1].upper(), "line": lineno})
            continue

        info = PAIR_INSTRS.get(opcode)
        if not info:
            continue
        # Every even-odd pair instruction takes >=2 operands (R1,source / R1,R3 /
        # R1,D2(...)). A 1-operand "D"/"M" line is a macro call or label use, NOT the
        # machine instruction — and the analyzer's own handlers gate on len(operands)>=2.
        if len(ops) < 2:
            continue
        full_name, family, pair_idx, handling = info
        for idx in pair_idx:
            if idx >= len(ops):
                continue
            klass, detail = _classify_operand(vlb, ops[idx])
            if klass == "SYMBOLIC_UNCOVERED":
                symbolic_names[detail] += 1
            sites.append({
                "file": os.path.basename(path),
                "line": lineno,
                "opcode": opcode,
                "name": full_name,
                "family": family,
                "handling": handling,
                "operand_index": idx,
                "operand": ops[idx],
                "class": klass,
                "detail": detail,
                "is_double_shift": opcode in DOUBLE_SHIFTS,
                "text": (line.label or "") + " " + opcode + " " + ",".join(ops),
            })
    return sites, equ_regs, stm_lm, symbolic_names


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--asm-dir", required=True)
    ap.add_argument("--out", default="scan_pairs.json")
    ap.add_argument("--copy-paths", nargs="*", default=None,
                    help="extra search paths for COPY/REGEQU resolution")
    ap.add_argument("--limit", type=int, default=0, help="cap files (0=all)")
    args = ap.parse_args()

    files = []
    for root, _dirs, names in os.walk(args.asm_dir):
        for n in names:
            if n.lower().endswith((".asm", ".mac")):
                files.append(os.path.join(root, n))
    files.sort()
    if args.limit:
        files = files[: args.limit]

    search_paths = [args.asm_dir] + (args.copy_paths or [])

    all_sites = []
    all_equ_regs = {}
    all_stm_lm = []
    sym_inv = Counter()
    errors = []
    for path in files:
        try:
            sites, equ_regs, stm_lm, sym = scan_file(path, search_paths)
            all_sites.extend(sites)
            for k, v in equ_regs.items():
                all_equ_regs.setdefault(k, Counter())[v] += 1
            all_stm_lm.extend([dict(s, file=os.path.basename(path)) for s in stm_lm])
            sym_inv.update(sym)
        except Exception as e:  # noqa: BLE001
            errors.append({"file": path, "error": f"{type(e).__name__}: {e}",
                           "trace": traceback.format_exc().splitlines()[-3:]})

    by_class = Counter(s["class"] for s in all_sites)
    by_opcode = Counter(s["opcode"] for s in all_sites)
    by_handling = Counter(s["handling"] for s in all_sites)
    crash_class = [s for s in all_sites if s["class"] == "SYMBOLIC_UNCOVERED"]
    crash_shift = [s for s in crash_class if s["is_double_shift"]]
    symbolic_sites = [s for s in all_sites
                      if s["class"] in ("TABLE_FALLBACK", "SYMBOLIC_UNCOVERED")]
    symbolic_usage = Counter((s["detail"] if s["class"] == "SYMBOLIC_UNCOVERED"
                              else s["operand"].strip().upper()) for s in symbolic_sites)
    equ_consensus = {sym: cnt.most_common(1)[0][0] for sym, cnt in all_equ_regs.items()}

    out = {
        "asm_dir": args.asm_dir,
        "files_scanned": len(files),
        "errors": errors,
        "totals": {
            "pair_instruction_sites": len(all_sites),
            "by_class": dict(by_class),
            "by_opcode": dict(by_opcode),
            "by_handling": dict(by_handling),
        },
        "crash_or_gap_class": {
            "count": len(crash_class),
            "double_shift_crash_prefix": len(crash_shift),
            "symbolic_name_inventory": dict(sym_inv.most_common()),
            "sites": crash_class[:500],
        },
        "symbolic_pair_usage": {
            "note": "symbolic register names actually used as pair operands "
                    "(TABLE_FALLBACK = already in _TPF_EVEN_ODD_PAIRS; "
                    "SYMBOLIC_UNCOVERED = NOT in table and no EQU -> must be added)",
            "name_counts": dict(symbolic_usage.most_common()),
            "sites": symbolic_sites[:500],
        },
        "register_equates_found": equ_consensus,
        "stm_lm_evidence": all_stm_lm[:500],
        "code_table_TPF_EVEN_ODD_PAIRS": dict(_TPF_EVEN_ODD_PAIRS),
        "all_sites_sample": all_sites[:200],
    }
    with open(args.out, "w") as f:
        json.dump(out, f, indent=2)

    print(f"files scanned        : {len(files)}")
    print(f"parse errors         : {len(errors)}")
    print(f"pair-instr sites     : {len(all_sites)}")
    print(f"by class             : {dict(by_class)}")
    print(f"by handling          : {dict(by_handling)}")
    print(f"by opcode            : {dict(by_opcode)}")
    print(f"CRASH/GAP class      : {len(crash_class)}  (double-shift pre-fix crashes: {len(crash_shift)})")
    print(f"symbolic inventory   : {dict(sym_inv.most_common(20))}")
    print(f"register EQUs found   : {len(equ_consensus)}")
    print(f"wrote {args.out}")


if __name__ == "__main__":
    sys.exit(main())
```

---

## Reference — the even-odd pair instruction families (from `dz9zr006.pdf`)

| Family | Mnemonics | Pair operand | Result location |
|---|---|---|---|
| Multiply | M, MR, MFY, ML, MLR, MLG, MLGR | R1 | 64-bit product across R1, R1+1 |
| Divide | D, DR, DL, DLR, DLG, DLGR, DSG, DSGR, DSGF, DSGFR | R1 | remainder→R1, quotient→R1+1 |
| Shift double *(fixed path)* | SLDA, SLDL, SRDA, SRDL | R1 | 64-bit value in R1, R1+1 |
| Compare-and-swap double | CDS, CDSY, CDSG | R1 **and** R3 | both pairs |
| Move/Compare long | MVCL, MVCLE, MVCLU, CLCL, CLCLE, CLCLU, CUSE | R1 + (R2 or R3) | addr in even, len in odd |
| Compression / crypto | CMPSC, KM, KMC, KIMD, KLMD, KMAC | R1+R2 or R2 | addr/len pair |
| UTF convert | CU12, CU14, CU21, CU24, CU41, CU42, CUUTF, CUTFU | R1 **and** R2 | addr/len pairs |
| Translate extended | TRE, TRTE, TRTRE, TROO, TROT, TRTO, TRTT | R1 | addr/len pair |
| Load/Store pair | LPQ, STPQ | R1 | 128-bit across R1, R1+1 |
| Misc / DFP / stack | CKSM, FLOGR, CXSTR, CXUTR, CSXTR, CUXTR, ESTA, MSTA | R1 or R2 | per POP |

The **8 architectural pairs** are structural: any even `Rn` pairs with `Rn+1` —
`R0/R1, R2/R3, R4/R5, R6/R7, R8/R9, R10/R11, R12/R13, R14/R15`. The symbolic→numeric
names (`RAC`, `RG1`, `RGA`, …) are **not** in any IBM doc; derive them from the
corpus per STEP 3.
