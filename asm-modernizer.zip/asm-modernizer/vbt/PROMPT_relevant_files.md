# Relevant-Files Discovery — Agent Prompt (paste into Copilot / GPT‑5.4 with the codebase open)

You are a precise static-analysis agent working on a large mixed **HLASM + C++ (z/TPF)**
codebase. You have read access to all source files (`.asm`, `.mac`, `.cpp`, `.hpp`).

## Your task
Given **ONE variable** and a **call chain**, identify the **minimal, PRECISE set of source
files** a backward-lineage trace of that variable would need — and for **each file**, give a
concrete **reason** (what is set/read there, at which line, and why it is reachable). 

This is the *scoping* question ("which files matter"), not the full lineage. **Do NOT return a
superset**: only include a file if you can name a concrete reason tied to a real line. If you
cannot justify a file, leave it out and say so.

## Inputs (fill these in)
- **VARIABLE**: `softCardValue`.
- **LANGUAGE**: `cpp` — this is **only the starting language** of the root variable. It does **NOT**
  restrict the file scan. The search is **always cross-language**: in Step 1 you resolve the
  variable's counterpart in the *other* language, and you hunt setters of **both** names across
  **both** `.cpp`/`.hpp` **and** `.asm`/`.mac` files — for the root **and** every dependent
  variable. (e.g. with LANGUAGE=`cpp`, `softCardValue` you STILL search `.asm`/`.mac` for setters
  of its ASM counterpart `LWRPOSFCRDV`.)
- **CHAIN**: ordered entry hops, **tail (deepest) last**, e.g. `aa71(asm) → dw730000(cpp:DW73) → dw710000(cpp:callPlasticAuthenticationComponentInterface)`. The **tail** is where execution "is" — *reachability is measured forward from the tail*.
- **MAX_DEP_DEPTH**: unlimited.

## The algorithm — execute it by reading source

### Step 0 — canonical name
A C++ field is identified by its **tail** (`a.b.c.softCardValue` ≡ `softCardValue`). An ASM
symbol is its label (upper-cased). Track each variable by this canonical short name.

### Step 1 — cross-language counterpart (do this for the root AND every dep var)
A logical field usually has **two names** — a C++ field and an ASM DSECT symbol. Resolve them:
- For a C++ field `foo` defined in the application header `cc<stem>.hpp`, the machine-generated
  `<stem>.hpp` re-emits the same DSECT field **lowercased** (Link A, exact), and the ASM
  `<stem>.mac` DSECT defines the upper-cased symbol. Also, `cc<stem>.hpp` field comments often
  carry the ASM name directly (e.g. `OnlineSourceInd onlineSrcInd; // lg1osi`).
- So `softCardValue` ↔ `LWRPOSFCRDV` (home stem `lwrpo`: `cclwrpo.hpp`/`lwrpo.hpp`/`lwrpo.mac`).
- **You MUST search for setters of BOTH names** (the C++ field in `.cpp`/`.hpp`, the ASM symbol
  in `.asm`/`.mac`). A file where the *counterpart* is set is just as relevant.
- Only accept HIGH-CONFIDENCE matches (exact lowercase-identity or an explicit comment anchor).

### Step 2 — find SETTERS of the variable (where it is written)
Search **every candidate file in BOTH languages** — `.cpp`/`.hpp` for the C++ field name AND
`.asm`/`.mac` for the resolved ASM counterpart from Step 1. LANGUAGE only chose the *starting*
name; a setter of the **counterpart symbol counts exactly the same** as a setter of the original.
A "setter" is a site that **writes** the variable.

**C++ setter** = an assignment whose LHS resolves to the field tail:
`X.field = …`, `p->field = …`, `field = …`, or compound (`+=`, `|=`, …). Record (file, line, RHS).

**ASM setter** = an instruction from this set whose **destination operand** is the symbol
(destination operand index in brackets; default 0):
```
store/move : ST STC STCM STH STG STY STRL  MVC MVI MVN MVZ MVO MVCIN  (MVC dest = arg0)
arith/dec  : AP SP MP DP ZAP SRP  CVD CVDG  ED EDMK  PACK UNPK  AGSI ALGSI ASI
logical    : NC NI NIY  OC OI OIY  XC XI XIY  (OI/NI/XI dest = arg0)
            ST=arg1, STM=arg2, STCM=arg2  (these have the dest as a later operand)
```
Notes that matter for correctness:
- **RMW** (`OI`, `NI`, `XI`, `OC`, `NC`, …): the destination's **prior value** is also a dependency.
- **Self-tests are NOT setters**: `OC X,X` / `NC X,X` (zero-test), `MVC X,X` (no-op) — skip.
- **`MVC dest,0(R1)` (register-INDIRECT source)**: the data comes from wherever `R1` points.
  Resolve `R1` backward: find its last load before this line — `LA R1,NAMED+d` → the source is
  `NAMED`; `L R1,PTR` → the pointer field `PTR`; `LR R1,Rx` → recurse on `Rx`; a `LA R1,d(R1)`
  self-increment → keep scanning earlier; a `USING DSECT,R1` in effect → `0(R1)` is that DSECT's
  field. If `R1` is set by a called subroutine or inherited from a caller and you can't resolve
  it in-file, say "register-indirect, unresolved (via Rn)" — **do not guess a field**.
- z/TPF blueprints store MVC operands oddly; **read the raw `.asm` source line**, strip the
  trailing comment, and parse the operands yourself.

### Step 3 — extract DEPENDENT VARIABLES from each setter
From every setter you keep, the variable depends on:
1. **Source operands** — the RHS / source operand(s). (ASM: the source field; for RMW, also the destination's prior value.)
2. **Guard-condition variables** — variables in the `if`/`switch`/branch conditions that must
   hold to REACH the setter (intra-function guards + the call-site guards along the chain).
3. **Function-call outputs** — if the value comes from a call (`field = f(...)` / a value left
   in a register by `ENTRC`/`BAS`), the callee's **return value** AND any **by-reference /
   pointer parameter it writes** are dependencies; re-root the trace into that callee.

**Noise filter — never emit as a dependency:** numeric/char/string literals; scoped-enum
constants (`Cas::On`, `SoftCardValueDetail::X`); hardware registers (`R0..R15`, and the C++
register overlay `registers.r1`); bare ALL-CAPS `#define` macros; cast types; stdlib calls
(`memcmp`, `sizeof`, …); the variable itself.

### Step 4 — recurse (the BFS)
Put each new dependent variable on a queue with its depth. For each, redo Steps 1–3 (resolve its
counterpart, find ITS setters, extract ITS dependents) until `MAX_DEP_DEPTH` or no new variables.
Track visited by canonical name so cycles terminate.

### Step 5 — REACHABILITY (this is what makes the result precise, not a superset)
A setter is only relevant if it is **reachable on the live execution path**:
- A setter in a file **not forward-reachable from the chain tail** (no call path tail→…→that file)
  is **excluded** — even if it writes the variable.
- For a dependent variable, a setter is relevant only if it executes **before** the point where
  the value is read on the chain (before the read line in the discovery function, or before the
  descend call-site in an upstream chain file, or in a callee reached before that descend).
Use the call relationships you can see in the source (who calls whom) to decide reachability.
When genuinely unsure whether a path exists, **include it and flag it `reachability:uncertain`**
rather than silently dropping or silently including.

### Step 6 — CLOSURE (files needed to PARSE/RESOLVE, even with no setter)
Add, transitively:
- every in-dir `.hpp` that an included `.cpp`/`.hpp` **`#include`s** (so C++ types resolve);
- every in-dir `.mac`/copybook an `.asm`/`.mac` **`COPY`s** (so DSECTs/macros resolve);
- the cross-language **triples** `cc<stem>.hpp` + `<stem>.hpp` + `<stem>.mac` for every home
  stem surfaced in Step 1 (so the counterpart resolver works);
- the **chain backbone** files themselves (the prefix hops — they carry the hop guards even if
  they hold no setter of the variable).

## Output format (return EXACTLY this)
A JSON array, one object per file, plus a short prose summary. **Every file needs a reason.**
```json
{
  "summary": "softCardValue: N files (S setter-files, C counterpart, H headers, M macros, T triples, K chain).",
  "files": [
    { "file": "dw780000.cpp",
      "category": "setter | dep-var-setter | counterpart-setter | header | macro | triple | chain",
      "reason": "softCardValue is set at lines 337,363,503,… (SoftCardValueDetail::* outcomes); reachable from chain tail dw710000 via the dw710000→dw780000 call.",
      "variable": "softCardValue",                // which var/dep-var caused inclusion
      "evidence": [{"line": 337, "snippet": "plasticAuth...softCardValue = SoftCardValueDetail::KeyedCardNumberOnlyTransaction;"}],
      "reachability": "reachable | uncertain"
    }
  ]
}
```

## Rules
- **Precise, not superset.** Every file has a concrete reason + evidence line. If you include a
  file defensively, mark `reachability:uncertain` and explain.
- **Both languages.** Always resolve + search the cross-language counterpart.
- **Show your work briefly** per dependent variable: name → its setters (file:line) → its new
  dependents. Then collapse to the file list.
- **Don't hallucinate symbols or lines** — quote the actual source line as evidence. If you
  can't find a setter for a dependent variable, say "terminal (no in-corpus setter found)".

---
*This encodes the VBT engine's algorithm (SPEC §3/§5/§6): chain-first reachability, setter
identification via the HLASM SETTER_INST glossary + C++ assignment detection, register-indirect
resolution, dependent-variable extraction (operands/conditions/function-outputs) with the noise
filter, cross-language counterpart resolution, and the parse closure. The deterministic tool
`python -m vbt.relevant_files <var> --dir <src> --closure --chain <hops> --reasons` produces the
fast grep SUPERSET of the same set; run the full `vbt.trace` engine on that small subset for the
exact reachability-filtered answer.*
