"""Tests for find_setter_conditions script functionality on both C++ and ASM variables.
"""
from __future__ import annotations

import pytest
from pathlib import Path
from vbt.tests.parity.cases import BLUEPRINT_DIR as BP, ASM_DIR as SRC, corpus_available

# Use the pre-existing precomputed job ID
JOB = "b58d8432-73e0-42d1-89a9-2ceebc47c6d2"

pytestmark = pytest.mark.skipif(not corpus_available(), reason="reference corpus unavailable")

def test_cpp_setter_conditions():
    """Verify condition extraction for a C++ variable (softCardValue)."""
    from find_setter_conditions import get_cpp_conditions_for_setter
    from vbt.precompute.source_db import install_source_override
    from backward_traversal.utils.blueprint_utils import clear_source_override
    
    try:
        install_source_override(JOB, SRC)
        cpp_file = SRC / "dw780000.cpp"
        
        # Test setter site in selectCidDbRecord15 around line 481
        conds = get_cpp_conditions_for_setter(cpp_file, 481)
        
        assert len(conds) >= 1
        # Innermost condition should be the check on cidioReturnCode around line 478
        assert any("cidioReturnCode" in c["text"] for c in conds)
    finally:
        clear_source_override()

def test_asm_setter_conditions():
    """Verify condition extraction for an ASM variable (LWRAW_LSTACTDT)."""
    from get_call_conditions import _asm_call_site_conditions
    from vbt.precompute.asm_db import install_asm_blueprint_override
    from backward_traversal.utils.blueprint_utils import load_json, resolve_asm_blueprint, clear_blueprint_override
    
    try:
        install_asm_blueprint_override(JOB, BP)
        bp_path = resolve_asm_blueprint("yb07", BP)
        assert bp_path is not None
        
        bp = load_json(bp_path)
        # Test setter site in yb07 @ line 328
        conds = _asm_call_site_conditions(bp, 328)
        
        assert len(conds) >= 1
        # Guard should be the check on LWRGB_YYCIDNUMD
        assert any("LWRGB_YYCIDNUMD" in c["condition"] for c in conds)
    finally:
        clear_blueprint_override()
