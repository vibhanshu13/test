"""Regression for the VBT-local trigger extension (TP/CHHSI/CLHHSI/CGFI).

These CC-setting compares occur in the z/TPF corpus but are absent from the reused
``backward_traversal.glossary.instructions.TRIGGER_INST``.  Without the VBT-local
union their guards were silently dropped (the TRIGGER+BRANCH pair never formed →
no Condition → the guarded storage field never became a dependency).

Pins:
  * the union sets are wired (the consumers see TP/CHHSI/CLHHSI/CGFI as triggers,
    and CHHSI/CLHHSI as mask/immediate-at-arg1);
  * the shared glossary is NOT mutated in place (SPEC #4 read-only reuse);
  * a TP guard and a CHHSI/CLHHSI guard are recognized and their storage operand
    (args[0]) is harvested, while the immediate operand (args[1]) is not.
"""
from __future__ import annotations

from backward_traversal.glossary import instructions as SHARED
from vbt.conditions import asm_conditions as AC
from vbt.depvars import extract as EX
from vbt.conditions.asm_condition_glossary import (
    TRIGGER_INST_EXT,
    MASK_TRIGGER_AT_ARG1_EXT,
)
from vbt.conditions.asm_conditions import collect_asm_conditions
from vbt.depvars.extract import extract_dep_vars
from vbt.interfaces import SetterSite

_NEW = {"TP", "CHHSI", "CLHHSI", "CGFI"}


def test_union_sets_contain_new_triggers():
    # The unioned sets the consumers actually use must include the new opcodes.
    assert _NEW <= AC.TRIGGER_INST
    assert {"CHHSI", "CLHHSI"} <= EX.MASK_TRIGGER_AT_ARG1
    # Ext sets are exactly the documented additions.
    assert set(TRIGGER_INST_EXT) == _NEW
    assert set(MASK_TRIGGER_AT_ARG1_EXT) == {"CHHSI", "CLHHSI"}


def test_shared_glossary_not_mutated():
    # SPEC #4: the reused glossary stays read-only — the new opcodes live ONLY in
    # the VBT-local extension, never injected into the shared multi-copy glossary.
    assert not (_NEW & set(SHARED.TRIGGER_INST))
    assert "CHHSI" not in SHARED.MASK_TRIGGER_AT_ARG1
    assert "CLHHSI" not in SHARED.MASK_TRIGGER_AT_ARG1


def _harvest(block, before_line):
    conds, _ = collect_asm_conditions({"blocks": [block]}, "x.asm", block["id"],
                                      before_line=before_line, file="x.asm")
    setter = SetterSite(variable="DESTFLD", file_stem="x", language="asm",
                        line=before_line, instruction="MVC", block_id=block["id"],
                        value="SRCFLD")
    deps = {d.name.upper() for d in extract_dep_vars(setter, conds)}
    return conds, deps


def test_tp_guard_field_now_harvested():
    block = {"id": "B", "flow": [
        {"line": 10, "inst": "TP", "args": ["LWRCW_NCHRATIO"]},
        {"line": 11, "inst": "BNZ", "args": ["AWAY"]},
        {"line": 20, "inst": "MVC", "args": ["DESTFLD", "SRCFLD"]},
    ]}
    conds, deps = _harvest(block, 20)
    assert any((c.raw_test or "").upper().startswith("TP ") for c in conds)
    assert "LWRCW_NCHRATIO" in deps


def test_chhsi_clhhsi_field_harvested_immediate_not():
    block = {"id": "B", "flow": [
        {"line": 10, "inst": "CHHSI", "args": ["FIELDXY", "5"]},
        {"line": 11, "inst": "BE", "args": ["AWAY1"]},
        {"line": 12, "inst": "CLHHSI", "args": ["L7BTC1", "C'TS'"]},
        {"line": 13, "inst": "BNE", "args": ["AWAY2"]},
        {"line": 20, "inst": "MVC", "args": ["DESTFLD", "SRCFLD"]},
    ]}
    conds, deps = _harvest(block, 20)
    # storage operands (args[0]) harvested
    assert "FIELDXY" in deps
    assert "L7BTC1" in deps
    # immediate operands (args[1]) NOT harvested
    assert "5" not in deps
    assert "TS" not in deps  # from C'TS' (literal already filtered; mask-at-arg1 reinforces)


def test_cgfi_register_immediate_not_harvested():
    block = {"id": "B", "flow": [
        {"line": 10, "inst": "CGFI", "args": ["R14", "10000"]},
        {"line": 11, "inst": "BH", "args": ["AWAY"]},
        {"line": 20, "inst": "MVC", "args": ["DESTFLD", "SRCFLD"]},
    ]}
    conds, deps = _harvest(block, 20)
    # CGFI is recognized as a trigger (the guard Condition is emitted)...
    assert any((c.raw_test or "").upper().startswith("CGFI ") for c in conds)
    # ...but its register operand and numeric immediate are not data dependencies.
    assert "R14" not in deps
    assert "10000" not in deps
