"""Module-local setter search for ASM scratch work fields (scratch_local_prefixes).

Generic work fields (WRK*-style scratch) are reused by EVERY module for unrelated
computations, so a corpus-wide setter search returns noise: a real lineage doc carried
2,149 setters for one WRKDBLW read, drawn from 98 modules that never feed the read
site (28MB for one node). With the knob, candidates for a matching dep are restricted
to the DISCOVERY file — the only module whose writes plausibly define the read.

The restriction is deliberately narrow: ASM only, name-prefix gated, default OFF in
the engine (the lineage task turns on ("WRK",)). ECB storage (EBW/EBX/CE1) is shared
across a transaction's programs and must NOT be listed.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[2]))

from vbt.depvars.extract import DepVarRef  # noqa: E402
from vbt.depvars.recurse import (  # noqa: E402
    _NodeCtx, _candidate_files_by_target, _is_scratch_local,
)


class _Idx:
    def files_for(self, name, language):
        return {"ni58", "nu59", "nj50", "nm71"}   # corpus-wide writers


def _ctx(prefixes=()):
    return _NodeCtx(
        blueprint_dir=Path("."), asm_dir=Path("."), chain_set={"cc80", "ch80"},
        upstream_bounds={}, route_engine=None, chain_hops=None, max_depth=2,
        const_resolver=None, max_offchain_files=100, asm_max_levels=16,
        max_descendants=50, midx=_Idx(), memb=None, reach_union=None,
        scratch_local_prefixes=tuple(p.upper() for p in prefixes),
    )


def _dep(name="WRKDBLW", language="asm", file="nm71.asm"):
    return DepVarRef(name=name, language=language, relationship="condition",
                     found_at={"file": file, "startLine": 442, "endLine": 442})


def test_scratch_dep_candidates_restricted_to_discovery_file():
    ctx = _ctx(("WRK",))
    dep = _dep()
    assert _is_scratch_local(dep, ctx)
    cbt = _candidate_files_by_target(dep, [], ctx)
    assert len(cbt) == 1
    _, _, _, cand = cbt[0]
    assert cand == ["nm71"]            # discovery module ONLY — not the 4 corpus writers


def test_without_knob_candidates_stay_corpus_wide():
    ctx = _ctx(())                      # engine default: off
    dep = _dep()
    assert not _is_scratch_local(dep, ctx)
    _, _, _, cand = _candidate_files_by_target(dep, [], ctx)[0]
    # chain files + all writer files + discovery file, as before
    assert set(cand) == {"cc80", "ch80", "ni58", "nu59", "nj50", "nm71"}


def test_gates_on_language_and_prefix():
    ctx = _ctx(("WRK",))
    # C++ variable with a WRK-looking name: NOT restricted (asm-only heuristic)
    assert not _is_scratch_local(_dep(language="cpp", file="nm71.cpp"), ctx)
    # non-matching ASM name: NOT restricted
    assert not _is_scratch_local(_dep(name="LWRCV_HDRDI"), ctx)
    # prefix match is case-insensitive on the name
    assert _is_scratch_local(_dep(name="wrkFld16"), ctx)


def test_aliases_of_scratch_dep_also_local():
    class _Alias:
        name = "WRKALIAS"
        language = "asm"
    ctx = _ctx(("WRK",))
    cbt = _candidate_files_by_target(_dep(), [_Alias()], ctx)
    assert [c for _, _, _, c in cbt] == [["nm71"], ["nm71"]]


class _Memb:
    """Membership stub: WRKYEAR/WRKDATE are DATWK DSECT fields; everything else bare."""
    _DATWK = {"WRKYEAR", "WRKDATE"}

    def resolve(self, name, language, qualified=""):
        if name.upper() in self._DATWK:
            return {"memberOf": {"language": "asm", "kind": "mac", "name": "DATWK"},
                    "counterpart": None}
        return {"memberOf": None, "counterpart": None}


def test_dsect_field_exempt_from_scratch_local():
    """A WRK*-prefixed name PROVEN to be a .mac DSECT field is a shared layout
    (e.g. WRKYEAR in the DATWK date work area: read in ua88, written in ae48) —
    it must take the normal corpus-wide search, not discovery-file-only."""
    ctx = _ctx(("WRK",))
    ctx.memb = _Memb()
    # DSECT field: exempt — candidates go corpus-wide again
    dep = _dep(name="WRKYEAR")
    assert not _is_scratch_local(dep, ctx)
    _, _, _, cand = _candidate_files_by_target(dep, [], ctx)[0]
    assert set(cand) == {"cc80", "ch80", "ni58", "nu59", "nj50", "nm71"}
    # module-private scratch (no DSECT membership): stays local — noise fix intact
    dep = _dep(name="WRKDBLW")
    assert _is_scratch_local(dep, ctx)
    _, _, _, cand = _candidate_files_by_target(dep, [], ctx)[0]
    assert cand == ["nm71"]


def test_no_membership_resolver_means_legacy_scratch_local():
    """memb=None ⇒ no proof possible ⇒ byte-identical legacy behavior."""
    ctx = _ctx(("WRK",))
    assert ctx.memb is None
    assert _is_scratch_local(_dep(name="WRKYEAR"), ctx)
