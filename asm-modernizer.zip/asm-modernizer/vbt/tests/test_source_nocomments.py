"""Unit battery for the GAP 7 comment stripper (vbt/precompute/source_nocomments_db.py).

Pure-function tests only (no job/corpus/DB) — the A/B and legacy-job identity tests live
elsewhere (handled by the precompute path). Every strip assertion checks the four invariants
the downstream line-offset slicers rely on (vbt/uiexport/structural.py):
  * same splitlines() count,
  * same per-line length,
  * every non-comment byte unchanged,
  * every changed byte is a blanking space (0x20).
"""
from vbt.precompute.source_nocomments_db import (
    strip_cpp_comments_bytes,
    _line_structure_preserved,
    _overlaps,
)
from vbt.setters.cpp_setters import _parser


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _strip(src: str) -> bytes:
    return strip_cpp_comments_bytes(src.encode("utf-8"), _parser())


def _strip_protected(src: str, protected) -> bytes:
    return strip_cpp_comments_bytes(src.encode("utf-8"), _parser(), protected)


def _assert_structure(raw: str, stripped_bytes: bytes) -> str:
    """Assert the four downstream invariants and return the decoded stripped text."""
    raw_b = raw.encode("utf-8")
    assert len(stripped_bytes) == len(raw_b), "byte length must not change"
    # same splitlines() count + same per-line length
    s = stripped_bytes.decode("utf-8", "replace")
    r_lines, s_lines = raw.splitlines(), s.splitlines()
    assert len(r_lines) == len(s_lines), (len(r_lines), len(s_lines))
    for rl, sl in zip(r_lines, s_lines):
        assert len(rl) == len(sl), (repr(rl), repr(sl))
    # every changed byte is a blanking space; every unchanged byte is identical
    for rb, sb in zip(raw_b, stripped_bytes):
        if rb != sb:
            assert sb == 0x20, f"changed byte must be space, got {sb!r} (was {rb!r})"
    # the strict gate must agree
    assert _line_structure_preserved(raw, s)
    return s


def _comment_blanked(raw: str, stripped: str, needle: str) -> bool:
    """True iff the comment substring `needle` (present verbatim in raw) is now spaces."""
    assert needle in raw
    idx = raw.index(needle)
    return stripped[idx:idx + len(needle)] == " " * len(needle)


# --------------------------------------------------------------------------- #
# string / char / raw-string literals containing comment markers — NOT stripped
# --------------------------------------------------------------------------- #
def test_string_with_comment_markers_preserved():
    src = 'const char* u = "http://x";\nconst char* n = "/* not a comment */";\n'
    out = _assert_structure(src, _strip(src))
    assert out == src, "no comment node here -> byte-identical"


def test_char_literal_slash_preserved():
    src = "char c = '/';\nint x = 1;\n"
    out = _assert_structure(src, _strip(src))
    assert out == src


def test_raw_string_with_line_comment_marker_preserved():
    src = 'auto s = R"(// not a comment)";\nint y = 2;\n'
    out = _assert_structure(src, _strip(src))
    assert out == src, "// inside a raw string is content, not a comment"


def test_digit_separator_not_a_comment():
    src = "long big = 1'000'000;\nint z = 3;\n"
    out = _assert_structure(src, _strip(src))
    assert out == src


# --------------------------------------------------------------------------- #
# genuine comments ARE blanked
# --------------------------------------------------------------------------- #
def test_line_comment_blanked():
    src = "int a = 1; // set a to one\nint b = 2;\n"
    out = _assert_structure(src, _strip(src))
    assert "int a = 1; " in out
    assert _comment_blanked(src, out, "// set a to one")
    assert "int b = 2;" in out


def test_trailing_comment_on_setter_line_blanked():
    # the active assignment survives; only the trailing // is blanked.
    src = "x = computeValue();   // R017 legacy note\n"
    out = _assert_structure(src, _strip(src))
    assert out.startswith("x = computeValue();")
    assert _comment_blanked(src, out, "// R017 legacy note")


def test_inline_block_comment_between_code_blanked():
    src = "int a = foo() /*c*/ + bar();\n"
    out = _assert_structure(src, _strip(src))
    assert _comment_blanked(src, out, "/*c*/")
    # code on both sides untouched
    assert out.startswith("int a = foo() ")
    assert out.rstrip().endswith("+ bar();")


def test_line_continued_line_comment_blanked():
    # a `\` at the EOL of a // comment continues the comment onto the next physical line.
    src = "int a = 1; // foo \\\nstill comment\nint b = 2;\n"
    out = _assert_structure(src, _strip(src))
    assert _comment_blanked(src, out, "// foo \\")
    assert _comment_blanked(src, out, "still comment")
    assert "int b = 2;" in out


def test_block_comment_with_embedded_newline_blanked():
    src = "int a = 1;\n/* line one\n   line two */\nint b = 2;\n"
    out = _assert_structure(src, _strip(src))
    # the newline inside the block comment is preserved (line count holds), text blanked.
    assert _comment_blanked(src, out, "/* line one")
    assert _comment_blanked(src, out, "   line two */")
    assert "int a = 1;" in out and "int b = 2;" in out


def test_formfeed_and_vtab_inside_block_comment_preserve_lines():
    # \f and \v are line boundaries for str.splitlines(); they MUST survive so the
    # stripped text keeps the same line structure as a banner-comment page break.
    src = "int a = 1;\n/* banner\fpage\vbreak end */\nint b = 2;\n"
    raw_b = src.encode("utf-8")
    stripped = _strip(src)
    assert len(stripped) == len(raw_b)
    # the splitlines() counts must match (the gate proves it)
    out = stripped.decode("utf-8", "replace")
    assert src.splitlines() == src.splitlines()  # sanity
    assert len(out.splitlines()) == len(src.splitlines())
    assert _line_structure_preserved(src, out)
    # the \f and \v bytes are preserved verbatim (not blanked to space)
    assert b"\x0c" in stripped and b"\x0b" in stripped


# --------------------------------------------------------------------------- #
# error-tolerance: a brace-mismatched function still tokenises comments
# --------------------------------------------------------------------------- #
def test_brace_mismatched_function_comments_still_blanked():
    # missing closing brace -> tree-sitter ERROR region, but comments inside still strip.
    src = (
        "void f() {\n"
        "   int a = 1;  // inner comment\n"
        "   /* block */\n"
        "   doThing();\n"          # NOTE: no closing brace for f()
        "int g() { return 0; }\n"
    )
    out = _assert_structure(src, _strip(src))
    assert _comment_blanked(src, out, "// inner comment")
    assert _comment_blanked(src, out, "/* block */")
    assert "int a = 1;" in out and "doThing();" in out


# --------------------------------------------------------------------------- #
# multi-byte UTF-8 in a comment -> each BYTE blanked (byte-length + line-break bytes
# preserved); the char-level verify gate then rejects it so the build degrades it to raw.
# --------------------------------------------------------------------------- #
def test_multibyte_comment_bytes_blanked():
    src = "int a = 1; // arrow → accent é\nint b = 2;\n"
    raw_b = src.encode("utf-8")
    stripped = _strip(src)
    # byte length preserved + same number of line-break-delimited segments (byte view).
    assert len(stripped) == len(raw_b)
    assert len(raw_b.splitlines()) == len(stripped.splitlines())
    # every comment byte is blanked to a space; the active code is byte-identical.
    cmt = "// arrow → accent é".encode("utf-8")
    idx = raw_b.index(cmt)
    assert stripped[idx:idx + len(cmt)] == b" " * len(cmt)
    assert stripped[:idx] == raw_b[:idx]                       # "int a = 1; " untouched
    assert b"int b = 2;" in stripped
    # the multi-byte comment changes the per-CHARACTER line length, so the strict gate
    # rejects this file -> build skips it -> trace falls back to raw (degrade-safe).
    assert not _line_structure_preserved(src, stripped.decode("utf-8", "replace"))


# --------------------------------------------------------------------------- #
# the §0 protected-region defect guard
# --------------------------------------------------------------------------- #
# A function swallowed in a runaway /* ... */ (mirrors source_lint's defect class), PLUS an
# ordinary comment elsewhere. With a `protected` range over the swallowed block, that block
# is left VERBATIM while the ordinary comment is still blanked.
_SWALLOWED = """\
int liveBefore = 1;
/* docA  runaway
static int swallowedFn(int x)
{
   return x + 1;
}
*/
int liveAfter = 2; // ordinary trailing comment
"""


def test_protected_region_left_verbatim_others_blanked():
    # the runaway comment spans lines 2..7 (1-based); protect that span.
    protected = [(2, 7)]
    stripped = _strip_protected(_SWALLOWED, protected)
    out = _assert_structure(_SWALLOWED, stripped)
    # the swallowed function text is preserved verbatim (NOT blanked)
    assert "static int swallowedFn(int x)" in out
    assert "return x + 1;" in out
    assert "/* docA  runaway" in out
    # the ordinary comment elsewhere is still blanked
    assert _comment_blanked(_SWALLOWED, out, "// ordinary trailing comment")
    # active code untouched
    assert "int liveBefore = 1;" in out and "int liveAfter = 2;" in out


def test_without_protection_the_runaway_comment_is_blanked():
    # same source, no protection -> the runaway comment (incl. the swallowed code) IS blanked.
    out = _assert_structure(_SWALLOWED, _strip(_SWALLOWED))
    assert _comment_blanked(_SWALLOWED, out, "static int swallowedFn(int x)")
    assert _comment_blanked(_SWALLOWED, out, "// ordinary trailing comment")
    assert "int liveBefore = 1;" in out and "int liveAfter = 2;" in out


def test_overlaps_helper():
    assert _overlaps(2, 7, [(2, 7)])
    assert _overlaps(5, 10, [(8, 12)])      # partial overlap
    assert _overlaps(1, 100, [(50, 50)])    # contains
    assert not _overlaps(2, 7, [(8, 12)])   # disjoint above
    assert not _overlaps(20, 30, [(8, 12)]) # disjoint below
    assert not _overlaps(2, 7, [])          # empty


# --------------------------------------------------------------------------- #
# the verify gate (_line_structure_preserved) catches drift -> build skips the file
# --------------------------------------------------------------------------- #
def test_verify_gate_rejects_line_count_change():
    raw = "line one\nline two\nline three\n"
    bad = "line one\nline three\n"            # a line dropped -> different count
    assert not _line_structure_preserved(raw, bad)


def test_verify_gate_rejects_length_change():
    raw = "abcdef\n"
    bad = "abc\n"                              # same line count, shorter line
    assert not _line_structure_preserved(raw, bad)


def test_verify_gate_rejects_non_space_substitution():
    raw = "int a = 1;\n"
    bad = "int X = 1;\n"                       # a non-space char replaced a real char
    assert not _line_structure_preserved(raw, bad)


def test_verify_gate_accepts_blanking():
    raw = "int a = 1; // note\n"
    good = "int a = 1; " + " " * len("// note") + "\n"   # comment -> spaces, same length
    assert _line_structure_preserved(raw, good)
