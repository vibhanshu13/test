"""T2: name-alias + membership DB artifacts — round-trip behavior preservation.

Proves the persisted/reloaded resolver state reproduces ``resolve()`` byte-for-byte against a
from-source build. Gated on the pinned corpus (skips cleanly when absent). The full-trace
byte-identical proof (with job_id set) lives in the parity gate.
"""
from __future__ import annotations

import pytest

from vbt.precompute import db_artifacts as DA
from vbt.precompute import resolvers_db as R
from vbt.resolve import membership as MB
from vbt.resolve import name_resolver as NR
from vbt.tests.parity import cases as P

pytestmark = pytest.mark.skipif(not P.corpus_available(),
                                reason="pinned corpus absent (see DB_PRECOMPUTE_PLAN.md §11)")


def _clear():
    NR.clear_cache()
    MB._CACHE.clear()


def _alias_tuples(aset):
    return aset.canonical, [(a.name, a.language, a.home_stem, a.certainty) for a in aset.aliases]


@pytest.mark.parametrize("var,lang", [("softCardValue", "cpp"), ("LG1OSI", "asm")])
def test_name_alias_artifact_roundtrip_preserves_resolve(var, lang):
    from vbt.resolve.name_resolver import resolve
    _clear()
    base = _alias_tuples(resolve(var, lang, P.ASM_DIR))           # from source

    _clear()
    art = R._build_name_alias_artifact(P.ASM_DIR)                 # build + serialize-safe
    art2 = DA.loads_gz(DA.dumps_gz(art))                          # full gz/JSON round-trip

    _clear()
    R._load_name_alias_artifact(P.ASM_DIR, art2)                 # reload into caches
    got = _alias_tuples(resolve(var, lang, P.ASM_DIR))           # resolve from DB-sourced state
    _clear()
    assert got == base


@pytest.mark.parametrize("var,lang", [("softCardValue", "cpp"), ("LG1OSI", "asm")])
def test_membership_artifact_roundtrip_preserves_resolve(var, lang):
    _clear()
    base = MB.get_membership_resolver(P.BLUEPRINT_DIR, P.ASM_DIR).resolve(var, lang)

    _clear()
    art = R._build_membership_artifact(P.BLUEPRINT_DIR, P.ASM_DIR)
    art2 = DA.loads_gz(DA.dumps_gz(art))

    _clear()
    R._load_membership_artifact(P.BLUEPRINT_DIR, P.ASM_DIR, art2)
    got = MB.get_membership_resolver(P.BLUEPRINT_DIR, P.ASM_DIR).resolve(var, lang)
    _clear()
    assert got == base


def test_name_alias_build_is_deterministic_bytes():
    """Same source -> identical serialized bytes (canonical-ordering guard, §11.4)."""
    _clear()
    a = DA.dumps_gz(R._build_name_alias_artifact(P.ASM_DIR))
    _clear()
    b = DA.dumps_gz(R._build_name_alias_artifact(P.ASM_DIR))
    _clear()
    assert a == b


def test_const_artifact_roundtrip_preserves_resolve():
    from vbt.resolve import const_resolver as CR
    CR._CACHE.clear()
    base = CR.get_const_resolver(P.BLUEPRINT_DIR, P.ASM_DIR)
    base_cpp, base_asm = dict(base.cpp_enum), dict(base.asm_const)

    CR._CACHE.clear()
    art2 = DA.loads_gz(DA.dumps_gz(R._build_const_artifact(P.BLUEPRINT_DIR, P.ASM_DIR)))

    CR._CACHE.clear()
    R._load_const_artifact(P.BLUEPRINT_DIR, P.ASM_DIR, art2)
    got = CR.get_const_resolver(P.BLUEPRINT_DIR, P.ASM_DIR)
    assert got.cpp_enum == base_cpp and got.asm_const == base_asm
    for k in list(base_cpp)[:25]:
        assert got.resolve(k, "cpp") == base.resolve(k, "cpp")
    assert got.bare_cpp_const_names() == base.bare_cpp_const_names()
    CR._CACHE.clear()


def test_modifier_index_artifact_roundtrip_preserves_lookups():
    from vbt.precompute import modifier_index as MI
    MI._CACHE.clear()
    base = MI.get_modifier_index(P.BLUEPRINT_DIR, P.ASM_DIR)
    base_cpp_files = base.files_for("softCardValue", "cpp")
    base_sites = [s.as_tuple() for s in base.sites_for("softCardValue", "cpp")]
    base_asm_keys, base_cpp_keys = sorted(base.asm), sorted(base.cpp)
    base_fn = base.files_defining_function("processACreditTransaction")

    MI._CACHE.clear()
    art2 = DA.loads_gz(DA.dumps_gz(R._build_modifier_artifact(P.BLUEPRINT_DIR, P.ASM_DIR)))

    MI._CACHE.clear()
    R._load_modifier_artifact(P.BLUEPRINT_DIR, P.ASM_DIR, art2)
    got = MI.get_modifier_index(P.BLUEPRINT_DIR, P.ASM_DIR)
    assert got.files_for("softCardValue", "cpp") == base_cpp_files
    assert [s.as_tuple() for s in got.sites_for("softCardValue", "cpp")] == base_sites
    assert sorted(got.asm) == base_asm_keys and sorted(got.cpp) == base_cpp_keys
    assert got.files_defining_function("processACreditTransaction") == base_fn
    MI._CACHE.clear()
