"""T5: route-graph (name_to_stems) DB artifact — round-trip behavior preservation.

Proves the persisted/reloaded name->stems map reproduces both the map content AND the
forward-reachable file set (the scale prune) exactly. The full-trace byte-identical proof
(with job_id set) lives in the parity gate.
"""
from __future__ import annotations

import pytest

from backward_traversal.route_finder import Endpoint

from vbt.precompute import db_artifacts as DA
from vbt.precompute import graph_db as G
from vbt.reach.route import RouteEngine
from vbt.tests.parity import cases as P

pytestmark = pytest.mark.skipif(not P.corpus_available(),
                                reason="pinned corpus absent (see DB_PRECOMPUTE_PLAN.md §11)")

# The canonical chain tail (cpp).
_TAIL = Endpoint("dw710000", "cpp", "callPlasticAuthenticationComponentInterface")


def _fresh_engine():
    return RouteEngine(P.BLUEPRINT_DIR, P.GRAPH_FILE, P.ASM_DIR)


def test_name_to_stems_roundtrip_content_identical():
    r = _fresh_engine()
    base = {k: set(v) for k, v in r.name_to_stems().items()}
    assert len(base) > 0
    loaded = {k: set(v) for k, v in
              DA.loads_gz(DA.dumps_gz({k: sorted(v) for k, v in base.items()})).items()}
    assert loaded == base


def test_preloaded_name_to_stems_preserves_forward_reachable():
    # Build the map from source on one engine; capture its forward-reachable file set.
    r1 = _fresh_engine()
    base_map = {k: set(v) for k, v in r1.name_to_stems().items()}
    base_reach = r1.forward_reachable_files(_TAIL)
    assert len(base_reach) > 0

    # A fresh engine PRELOADED with the round-tripped map (no blueprint sweep) must yield the
    # identical forward-reachable set.
    blob = DA.dumps_gz({k: sorted(v) for k, v in base_map.items()})
    r2 = _fresh_engine()
    r2._name_to_stems = {k: set(v) for k, v in DA.loads_gz(blob).items()}
    assert r2.forward_reachable_files(_TAIL) == base_reach


def test_name_to_stems_build_is_deterministic_bytes():
    a = DA.dumps_gz({k: sorted(v) for k, v in _fresh_engine().name_to_stems().items()})
    b = DA.dumps_gz({k: sorted(v) for k, v in _fresh_engine().name_to_stems().items()})
    assert a == b


def test_cpp_call_edges_roundtrip_identical():
    """Per-stem reattributed edges survive the gz/JSON round-trip unchanged, and a
    preloaded RouteEngine returns the identical edges (cache-first)."""
    r = _fresh_engine()
    nt = r.node_types()
    cpp_stems = sorted(s for s, t in nt.items() if t == "cpp")
    base = {stem: list(r.cpp_call_edges(stem)) for stem in cpp_stems}
    assert len(base) > 0

    data = DA.loads_gz(DA.dumps_gz({s: [list(e) for e in edges] for s, edges in base.items()}))
    loaded = {s: [tuple(e) for e in edges] for s, edges in data.items()}
    assert loaded == base

    # A fresh engine pre-filled with the loaded edges returns them verbatim (no recompute).
    r2 = _fresh_engine()
    for s, edges in loaded.items():
        r2._edge_cache[s] = edges
    for stem in cpp_stems:
        assert r2.cpp_call_edges(stem) == base[stem]
