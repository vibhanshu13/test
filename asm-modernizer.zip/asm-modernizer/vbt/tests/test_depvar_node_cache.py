"""Cross-chain dep-var node cache (DepNodeCache): validated memo soundness.

The lineage coordinator traces MANY chains of the SAME variable; the node cache lets
chains 2..N reuse chain 1's per-node computes — but ONLY when the per-node chain-scope
revalidation proves the output identical. The contract under test:

  1. Same scope, second run  → cache HITS and the output is byte-identical.
  2. Different scope that CHANGES a node's relevant setters → the probe REJECTS and the
     cached run equals a fresh (uncached) run for that scope — never the other chain's.
  3. Different scope that does NOT change any decision → cache HITS and the output is
     byte-identical to a fresh run for that scope.

Real tree-sitter setter extraction on disk fixtures; heavy non-parsing collaborators
(modifier index / alias resolver / cfg / block store) stubbed, as in the pathfamily tests.
"""
import json
from pathlib import Path

from vbt.depvars.extract import DepVarRef


def _setup(monkeypatch, tmp_path, files):
    import vbt.depvars.recurse as R

    for name, text in files.items():
        (tmp_path / name).write_text(text)
    stems = {Path(n).stem for n in files}

    class _Idx:
        def files_for(self, name, language): return set(stems)
        def files_defining_function(self, fn): return set()
        def sites_for(self, *a, **k): return []

    monkeypatch.setattr(R, "get_modifier_index", lambda *a, **k: _Idx())
    monkeypatch.setattr(R, "resolve_aliases",
                        lambda name, lang, asm_dir: type("A", (), {"aliases": []})())
    monkeypatch.setattr(R, "run_cfg_extract", lambda *a, **k: [])
    monkeypatch.setattr(R, "_cpp_fn_block", lambda *a, **k: None)
    monkeypatch.setattr(R, "_dep_chunk", lambda *a, **k: None)


def _trace(tmp_path, chain_files, node_cache=None, seed_file="d.cpp", seed_line=50):
    from vbt.depvars.recurse import trace_dependents
    dep = DepVarRef(name="v", language="cpp", relationship="condition",
                    found_at={"file": seed_file, "startLine": seed_line, "endLine": seed_line})
    out = trace_dependents([("root", dep)], chain_files,
                           blueprint_dir=tmp_path, asm_dir=tmp_path, store=None,
                           node_cache=node_cache)
    return json.dumps(out, sort_keys=True, default=str)


def test_same_scope_second_run_hits_and_is_identical(monkeypatch, tmp_path):
    from vbt.depvars.recurse import DepNodeCache
    _setup(monkeypatch, tmp_path,
           {"d.cpp": "void g(){ v = 1; w = v; }", "f.cpp": "void h(){ v = 2; }"})
    cache = DepNodeCache()
    first = _trace(tmp_path, ["d", "f"], node_cache=cache)
    assert len(cache.entries) > 0
    second = _trace(tmp_path, ["d", "f"], node_cache=cache)
    assert second == first
    assert cache.hits > 0
    # and identical to a run that never saw a cache at all
    assert first == _trace(tmp_path, ["d", "f"], node_cache=None)


def test_scope_change_that_alters_setters_is_rejected_not_reused(monkeypatch, tmp_path):
    from vbt.depvars.recurse import DepNodeCache
    # v is set in BOTH d.cpp (discovery) and f.cpp. Chain A includes f → f's setter is
    # relevant; chain B excludes f → it must NOT be (no route engine to rescue it).
    _setup(monkeypatch, tmp_path,
           {"d.cpp": "void g(){ v = 1; }", "f.cpp": "void h(){ v = 2; }"})
    fresh_a = _trace(tmp_path, ["d", "f"], node_cache=None)
    fresh_b = _trace(tmp_path, ["d"], node_cache=None)
    assert fresh_a != fresh_b   # the scope genuinely changes the output

    cache = DepNodeCache()
    assert _trace(tmp_path, ["d", "f"], node_cache=cache) == fresh_a   # warm on chain A
    cached_b = _trace(tmp_path, ["d"], node_cache=cache)               # replay on chain B
    assert cached_b == fresh_b        # per-chain-correct: B's scope, not A's
    assert cache.rejected > 0         # the node was revalidated and refused


def test_scope_change_with_same_decisions_hits(monkeypatch, tmp_path):
    from vbt.depvars.recurse import DepNodeCache
    # All setters live in the discovery file; f.cpp / g.cpp contain none. Swapping the
    # chain tail f→g changes the chain scope but not one chain-scoped decision, so the
    # nodes are served from the cache — and stay byte-identical to a fresh run.
    _setup(monkeypatch, tmp_path,
           {"d.cpp": "void g(){ v = 1; w = v; }",
            "f.cpp": "void f1(){ int unrelated = 0; }",
            "g.cpp": "void g1(){ int unrelated = 0; }"})
    fresh_b = _trace(tmp_path, ["d", "g"], node_cache=None)

    cache = DepNodeCache()
    _trace(tmp_path, ["d", "f"], node_cache=cache)     # warm on chain A
    hits_before = cache.hits
    cached_b = _trace(tmp_path, ["d", "g"], node_cache=cache)
    assert cached_b == fresh_b
    assert cache.hits > hits_before   # reused across a DIFFERENT chain


def test_knob_mismatch_bypasses_cache(monkeypatch, tmp_path):
    from vbt.depvars.recurse import DepNodeCache, trace_dependents
    _setup(monkeypatch, tmp_path, {"d.cpp": "void g(){ v = 1; }"})
    cache = DepNodeCache()

    def run(depth):
        dep = DepVarRef(name="v", language="cpp", relationship="condition",
                        found_at={"file": "d.cpp", "startLine": 50, "endLine": 50})
        return trace_dependents([("root", dep)], ["d"], blueprint_dir=tmp_path,
                                asm_dir=tmp_path, store=None, max_depth=depth,
                                node_cache=cache)

    run(2)
    stored = len(cache.entries)
    run(3)   # different knobs → accept() fails → bypass (no new entries, no hits)
    assert len(cache.entries) == stored
    assert cache.hits == 0


def test_scoped_local_nodes_cache_parity(monkeypatch, tmp_path):
    """Proven fn-local scoping (DepVarRef.local_scope) under the cross-chain cache:
    a scoped-local node cached on chain A revalidates on chain B and the cached run
    stays byte-identical to a fresh run — the scoping decisions live inside the
    probed helpers (_candidate_files_by_target / _gather_candidate_setters), so no
    new probe schema is needed."""
    import vbt.depvars.recurse as R
    from vbt.depvars.recurse import DepNodeCache, trace_dependents

    _setup(monkeypatch, tmp_path,
           {"d.cpp": "void fa() {\n    int v = 1;\n    v = 2;\n    o = v;\n}\n"
                     "void fb() {\n    int v = 5;\n    o2 = v;\n}\n",
            "f.cpp": "void h(){ v = 9; }"})
    cfg = [{"function": "fa", "cfg_blocks": [{"id": 0, "succs": [],
                                              "stmts": [{"line": ln} for ln in (2, 3, 4)]}]},
           {"function": "fb", "cfg_blocks": [{"id": 1, "succs": [],
                                              "stmts": [{"line": ln} for ln in (6, 7)]}]}]
    monkeypatch.setattr(R, "run_cfg_extract",
                        lambda path, *a, **k: cfg if Path(path).stem == "d" else [])

    def run(chain, cache):
        dep = DepVarRef(name="v", language="cpp", relationship="condition",
                        found_at={"file": "d.cpp", "startLine": 4, "endLine": 4})
        out = trace_dependents([("root", dep)], chain, blueprint_dir=tmp_path,
                               asm_dir=tmp_path, store=None, node_cache=cache)
        return json.dumps(out, sort_keys=True, default=str)

    fresh_a = run(["d", "f"], None)
    fresh_b = run(["d"], None)
    # the proof fired: the node is scoped to fa and f.cpp's foreign `v = 9` is excluded
    assert "localScope" in fresh_a and '"fa"' in fresh_a
    assert "v = 9" not in fresh_a

    cache = DepNodeCache()
    assert run(["d", "f"], cache) == fresh_a       # warm on chain A
    assert run(["d"], cache) == fresh_b            # replay on chain B: per-chain-correct
    assert run(["d", "f"], cache) == fresh_a       # back to A: still byte-identical
    assert cache.hits > 0


def test_foreign_local_excluded_nodes_cache_parity(monkeypatch, tmp_path):
    """v15 foreign-local exclusion under the cross-chain cache: the exclusion lives
    inside _gather_candidate_setters (probed via setters_sig), so a node whose
    candidates were pruned of foreign proven locals revalidates byte-identically
    across chains."""
    from vbt.depvars.recurse import DepNodeCache
    _setup(monkeypatch, tmp_path,
           {"d.cpp": "void g(){ v = 1; use(v); }",
            "f.cpp": "void h(){ int v = 5; v = 9; }"})   # h's v: PROVEN foreign local
    fresh_a = _trace(tmp_path, ["d", "f"], node_cache=None)
    fresh_b = _trace(tmp_path, ["d"], node_cache=None)
    # the exclusion fired: f.cpp's local writes never appear, either chain
    assert "v = 9" not in fresh_a and "v = 9" not in fresh_b

    cache = DepNodeCache()
    assert _trace(tmp_path, ["d", "f"], node_cache=cache) == fresh_a
    assert _trace(tmp_path, ["d"], node_cache=cache) == fresh_b
    assert _trace(tmp_path, ["d", "f"], node_cache=cache) == fresh_a
    assert cache.hits > 0
