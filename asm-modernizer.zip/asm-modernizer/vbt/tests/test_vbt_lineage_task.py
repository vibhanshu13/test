"""Unit tests for the /vbt/lineage coordinator's pure pieces (no DB, no engine):
the lineage-graph fold (`_build_lineage`), the terminal classifier
(`_classify_terminal`), and the missing-file attribution."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[2]))

from api.tasks.vbt_lineage_task import (  # noqa: E402
    _build_lineage, _classify_terminal, _resolve_missing_symbols,
    INPUT_MSG_PREFIXES, WORKING_STORAGE_PREFIXES,
)

_IO = {
    "db_read": {"aa71": ["FINWC"]},
    "user_input": {"lu82": ["AM0SG"]},
    "db_read_tokens": {"aa71": {"LWRLS", "LWRLS_FIELD", "FINWC"}},
}
_CONSTS = {"asm": {"MAXLEN"}, "cpp": {"kDefaultMode"}}
_MISSING = {"stems": {"xy99", "zz88"},
            "callees_of": {"dw710000": ["xy99"], "aa71": ["zz88"]}}


def _classify(node, missing_ctx=None):
    return _classify_terminal(node, io_stems=_IO, const_names=_CONSTS,
                              input_prefixes=INPUT_MSG_PREFIXES,
                              ws_prefixes=WORKING_STORAGE_PREFIXES,
                              missing_ctx=missing_ctx)


def test_classify_constant_and_external_and_working_storage():
    assert _classify({"name": "MAXLEN"})[0] == "constant"
    assert _classify({"name": "kDefaultMode"})[0] == "constant"
    assert _classify({"name": "x", "externalCall": True})[0] == "external"
    assert _classify({"name": "EBW040"})[0] == "working_storage"


def test_classify_user_input_by_prefix_and_membership():
    cls, ev, _ = _classify({"name": "MI0ACC"})
    assert cls == "user_input" and ev
    cls, _, _ = _classify({"name": "acctNbr", "memberOf": {"name": "AM0SG"}})
    assert cls == "user_input"


def test_classify_database_first_and_second_degree():
    # first degree: read in a stem that FINWCs
    node = {"name": "lwrlsField", "memberOf": {"name": "LWRLS"},
            "dependencies": [{"foundAt": {"file": "aa71.asm", "startLine": 10}}]}
    cls, ev, _ = _classify(node)
    assert cls == "database" and "FINWC" in ev[0]
    # second degree: read only on the C++ side, but its DSECT is addressed in a FINWC stem
    node = {"name": "lwrlsField", "memberOf": {"name": "LWRLS"},
            "dependencies": [{"foundAt": {"file": "dw710000.cpp", "startLine": 5}}]}
    cls, ev, _ = _classify(node)
    assert cls == "database" and "LWRLS" in ev[0]


def test_classify_record_field_without_io_evidence_and_unresolved():
    node = {"name": "someField", "memberOf": {"name": "ZZZZ"},
            "dependencies": [{"foundAt": {"file": "dw710000.cpp", "startLine": 5}}]}
    assert _classify(node)[0] == "record_field"
    assert _classify({"name": "mystery"})[0] == "unresolved"


def test_missing_candidates_attributed_from_reader_stems():
    # unresolved terminal read in dw710000 → dw710000 calls missing module xy99
    node = {"name": "mystery",
            "dependencies": [{"foundAt": {"file": "dw710000.cpp", "startLine": 7}}]}
    cls, ev, cands = _classify(node, missing_ctx=_MISSING)
    assert cls == "unresolved"
    assert cands == ["xy99"]
    assert any("xy99" in line for line in ev)
    # external terminal gets the same attribution
    node = {"name": "extOut", "externalCall": True,
            "dependencies": [{"foundAt": {"file": "aa71.asm", "startLine": 4}}]}
    cls, ev, cands = _classify(node, missing_ctx=_MISSING)
    assert cls == "external" and cands == ["zz88"]


def test_build_lineage_graph_fold():
    chain_out = {
        "rootVariable": {"name": "rootVar", "setters": [
            {"location": {"file": "a.cpp", "startLine": 3}, "value": "depA"}]},
        "dependentVariables": [
            {"dependentVariable": {
                "name": "depA", "terminal": False,
                "dependencies": [{"variableName": "rootVar",
                                  "foundAt": {"file": "a.cpp", "startLine": 3}}],
                "setters": [{"location": {"file": "b.cpp", "startLine": 9}, "value": "depB"}]}},
            {"dependentVariable": {
                "name": "depB", "terminal": True, "memberOf": {"name": "LWRLS"},
                "dependencies": [
                    {"variableName": "depA", "foundAt": {"file": "b.cpp", "startLine": 9}},
                    # duplicate edge must be deduped
                    {"variableName": "depA", "foundAt": {"file": "b.cpp", "startLine": 9}}],
                "setters": []}},
        ],
    }
    lin = _build_lineage(chain_out, "rootVar", io_stems=_IO, const_names=_CONSTS,
                         input_prefixes=INPUT_MSG_PREFIXES,
                         ws_prefixes=WORKING_STORAGE_PREFIXES)
    names = {n["name"]: n for n in lin["nodes"]}
    assert set(names) == {"rootVar", "depA", "depB"}
    assert names["rootVar"]["role"] == "root"
    assert not names["depA"]["terminal"] and names["depB"]["terminal"]
    assert lin["edges"] == [
        {"from": "rootVar", "to": "depA", "foundAt": {"file": "a.cpp", "line": 3}},
        {"from": "depA", "to": "depB", "foundAt": {"file": "b.cpp", "line": 9}},
    ]
    assert [t["name"] for t in lin["terminals"]] == ["depB"]
    # depB's DSECT (LWRLS) is addressed in the FINWC stem — second-degree database evidence
    assert lin["terminals"][0]["classification"] == "database"
    assert names["depB"]["classification"] == "database"


def test_resolve_missing_symbols_maps_linkage_aliases_to_modules():
    # ckxc is #pragma map'd to TE90 (missing) → becomes te90; unpackdata maps to an
    # IN-corpus module → dropped entirely; bs30 has no alias → unchanged.
    ctx = {"stems": {"ckxc", "unpackdata", "bs30"},
           "callees_of": {"rh73iw00": ["ckxc", "unpackdata"], "em71": ["bs30"]},
           "bp_stems": {"unpack", "em71", "rh73iw00"}}
    entry_map = {"ckxc": "te90", "unpackdata": "unpack"}
    called_as = _resolve_missing_symbols(ctx, entry_map)
    assert ctx["stems"] == {"te90", "bs30"}
    assert ctx["callees_of"] == {"rh73iw00": ["te90"], "em71": ["bs30"]}
    assert called_as == {"te90": ["ckxc"]}


def test_build_lineage_missing_candidates_on_unresolved_terminal():
    chain_out = {
        "rootVariable": {"name": "rootVar", "setters": []},
        "dependentVariables": [
            {"dependentVariable": {
                "name": "mystery", "terminal": True,
                "dependencies": [{"variableName": "rootVar",
                                  "foundAt": {"file": "dw710000.cpp", "startLine": 7}}],
                "setters": []}},
        ],
    }
    lin = _build_lineage(chain_out, "rootVar", io_stems=_IO, const_names=_CONSTS,
                         input_prefixes=INPUT_MSG_PREFIXES,
                         ws_prefixes=WORKING_STORAGE_PREFIXES, missing_ctx=_MISSING)
    (term,) = lin["terminals"]
    assert term["classification"] == "unresolved"
    assert term["missingCandidates"] == ["xy99"]
