"""Unit tests for the /vbt/lineage coordinator's pure pieces (no DB, no engine):
the lineage-graph fold (`_build_lineage`), the terminal classifier
(`_classify_terminal`), and the missing-file attribution."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[2]))

from api.tasks.vbt_lineage_task import (  # noqa: E402
    _build_lineage, _classify_terminal, _resolve_missing_symbols,
    INPUT_MSG_PREFIXES, WORKING_STORAGE_PREFIXES, SCRATCH_LOCAL_PREFIXES,
)

_IO = {
    "db_read": {"aa71": ["FINWC"]},
    "user_input": {"lu82": ["AM0SG"]},
    "db_read_tokens": {"aa71": {"LWRLS", "LWRLS_FIELD", "FINWC"}},
}
_CONSTS = {"asm": {"MAXLEN"}, "cpp": {"kDefaultMode"}}
_MISSING = {"stems": {"xy99", "zz88"},
            "callees_of": {"dw710000": ["xy99"], "aa71": ["zz88"]}}


def _classify(node, missing_ctx=None):
    return _classify_terminal(node, io_stems=_IO, const_names=_CONSTS,
                              input_prefixes=INPUT_MSG_PREFIXES,
                              ws_prefixes=WORKING_STORAGE_PREFIXES,
                              missing_ctx=missing_ctx)


def test_classify_constant_and_external_and_working_storage():
    assert _classify({"name": "MAXLEN"})[0] == "constant"
    assert _classify({"name": "kDefaultMode"})[0] == "constant"
    assert _classify({"name": "x", "externalCall": True})[0] == "external"
    assert _classify({"name": "EBW040"})[0] == "working_storage"


def test_classify_indirection_envelope_never_pattern_matches():
    """A register-indirect give-up envelope is named after the REGISTER — the
    pattern rules misfired on it (a real doc had R15 → user_input and RDA →
    constant, because register EQUs sit in the const table). It must short-circuit
    to unresolved_indirect before any pattern rule runs."""
    env = {"indirection": {"indirect_via": "R15"}}
    cls, ev, cands = _classify({"name": "R15", **env})
    assert cls == "unresolved_indirect" and "R15" in ev[0] and cands == []
    # even a name that would hit the const table / input prefixes short-circuits
    assert _classify({"name": "MAXLEN", **env})[0] == "unresolved_indirect"
    assert _classify({"name": "MI0ACC", **env})[0] == "unresolved_indirect"


def test_missing_candidates_filter_drops_keywords_libc_and_macro_operands():
    """Keywords, libc names, and DECB macro operand keywords can never be a missing
    corpus MODULE — they only bury the real candidates in the ranking."""
    mctx = {"stems": set(),
            "callees_of": {"dw710000": ["xy99", "isdigit", "atoi", "struct",
                                        "unsigned", "dft_fil", "dfcls", "tpf_regs"]}}
    node = {"name": "x", "externalCall": True,
            "dependencies": [{"foundAt": {"file": "dw710000.cpp"}}]}
    cls, _ev, cands = _classify(node, missing_ctx=mctx)
    assert cls == "external"
    assert cands == ["xy99"], cands


def test_working_storage_covers_ebnu_phase_family():
    # EB0U..EB9U is the numbered ECB "user area" family, same kind of shared
    # transaction storage as EBW/EBX/CE1 — a redYellowGreen lineage run showed these
    # NOT matching the (pre-fix) prefix list and getting chased as ordinary globals
    # across up to 86 files instead of being terminal-classified like their siblings.
    for name in ("EB0U004", "EB1U000", "EB5U000", "EB9U000"):
        assert _classify({"name": name})[0] == "working_storage", name


def test_scratch_local_prefixes_cover_generic_work_save_temp_families():
    # Discovered via a real redYellowGreen lineage doc: these generic scratch names
    # were reused across dozens of unrelated modules for unrelated computations
    # (DBLWORK alone produced 1,044 spurious cross-module edges in one run) — same
    # noise class as the original WRK*-style scratch fields, just not prefixed "WRK".
    generic_scratch = (
        "DBLWORK", "TDCWORK", "TODWORK", "SAVREG2", "SAVREG4", "TEMP1", "WORK1",
        "WORKUNPK", "BIGSAVE", "SAVERTN", "TIMEO", "DATEO", "STATO",
        # second audit sweep of the same doc: names that escaped the first list
        # (DBLWORD alone: 413 setters from 74 files)
        "DBLWORD", "WKAREA1", "WKAREA2", "WKAREA3", "SCRATCH", "HALFWORD", "FULLWORD",
    )
    for name in generic_scratch:
        assert name.upper().startswith(SCRATCH_LOCAL_PREFIXES), name
    # the original fix this generalizes must still match
    assert "WRKDBLW".startswith(SCRATCH_LOCAL_PREFIXES)


def test_classify_user_input_by_prefix_and_membership():
    cls, ev, _ = _classify({"name": "MI0ACC"})
    assert cls == "user_input" and ev
    cls, _, _ = _classify({"name": "acctNbr", "memberOf": {"name": "AM0SG"}})
    assert cls == "user_input"


def test_classify_database_first_and_second_degree():
    # first degree: read in a stem that FINWCs
    node = {"name": "lwrlsField", "memberOf": {"name": "LWRLS"},
            "dependencies": [{"foundAt": {"file": "aa71.asm", "startLine": 10}}]}
    cls, ev, _ = _classify(node)
    assert cls == "database" and "FINWC" in ev[0]
    # second degree: read only on the C++ side, but its DSECT is addressed in a FINWC stem
    node = {"name": "lwrlsField", "memberOf": {"name": "LWRLS"},
            "dependencies": [{"foundAt": {"file": "dw710000.cpp", "startLine": 5}}]}
    cls, ev, _ = _classify(node)
    assert cls == "database" and "LWRLS" in ev[0]


def test_classify_record_field_without_io_evidence_and_unresolved():
    node = {"name": "someField", "memberOf": {"name": "ZZZZ"},
            "dependencies": [{"foundAt": {"file": "dw710000.cpp", "startLine": 5}}]}
    assert _classify(node)[0] == "record_field"
    assert _classify({"name": "mystery"})[0] == "unresolved"


def test_missing_candidates_attributed_from_reader_stems():
    # unresolved terminal read in dw710000 → dw710000 calls missing module xy99
    node = {"name": "mystery",
            "dependencies": [{"foundAt": {"file": "dw710000.cpp", "startLine": 7}}]}
    cls, ev, cands = _classify(node, missing_ctx=_MISSING)
    assert cls == "unresolved"
    assert cands == ["xy99"]
    assert any("xy99" in line for line in ev)
    # external terminal gets the same attribution
    node = {"name": "extOut", "externalCall": True,
            "dependencies": [{"foundAt": {"file": "aa71.asm", "startLine": 4}}]}
    cls, ev, cands = _classify(node, missing_ctx=_MISSING)
    assert cls == "external" and cands == ["zz88"]


def test_build_lineage_graph_fold():
    chain_out = {
        "rootVariable": {"name": "rootVar", "setters": [
            {"location": {"file": "a.cpp", "startLine": 3}, "value": "depA"}]},
        "dependentVariables": [
            {"dependentVariable": {
                "name": "depA", "terminal": False,
                "dependencies": [{"variableName": "rootVar",
                                  "foundAt": {"file": "a.cpp", "startLine": 3}}],
                "setters": [{"location": {"file": "b.cpp", "startLine": 9}, "value": "depB"}]}},
            {"dependentVariable": {
                "name": "depB", "terminal": True, "memberOf": {"name": "LWRLS"},
                "dependencies": [
                    {"variableName": "depA", "foundAt": {"file": "b.cpp", "startLine": 9}},
                    # duplicate edge must be deduped
                    {"variableName": "depA", "foundAt": {"file": "b.cpp", "startLine": 9}}],
                "setters": []}},
        ],
    }
    lin = _build_lineage(chain_out, "rootVar", io_stems=_IO, const_names=_CONSTS,
                         input_prefixes=INPUT_MSG_PREFIXES,
                         ws_prefixes=WORKING_STORAGE_PREFIXES)
    names = {n["name"]: n for n in lin["nodes"]}
    assert set(names) == {"rootVar", "depA", "depB"}
    assert names["rootVar"]["role"] == "root"
    assert not names["depA"]["terminal"] and names["depB"]["terminal"]
    assert lin["edges"] == [
        {"from": "rootVar", "to": "depA", "foundAt": {"file": "a.cpp", "line": 3}},
        {"from": "depA", "to": "depB", "foundAt": {"file": "b.cpp", "line": 9}},
    ]
    assert [t["name"] for t in lin["terminals"]] == ["depB"]
    # depB's DSECT (LWRLS) is addressed in the FINWC stem — second-degree database evidence
    assert lin["terminals"][0]["classification"] == "database"
    assert names["depB"]["classification"] == "database"


def test_build_lineage_splits_scoped_locals_into_distinct_nodes():
    """Two proven fn-local deps sharing a bare name (recurse emits ``localScope`` and
    scoped owner labels) must fold into TWO nodes with distinct ids and correctly
    attributed edges — not one name-merged node with cross-wired edges."""
    chain_out = {
        "rootVariable": {"name": "rootVar", "setters": []},
        "dependentVariables": [
            {"dependentVariable": {
                "name": "i", "terminal": False,
                "localScope": {"file": "t", "function": "funcA"},
                "dependencies": [{"variableName": "rootVar",
                                  "foundAt": {"file": "t.cpp", "startLine": 6}}],
                "setters": [{"location": {"file": "t.cpp", "startLine": 4}, "value": "0"}]}},
            {"dependentVariable": {
                "name": "i", "terminal": False,
                "localScope": {"file": "t", "function": "funcB"},
                "dependencies": [{"variableName": "rootVar",
                                  "foundAt": {"file": "t.cpp", "startLine": 12}}],
                "setters": [{"location": {"file": "t.cpp", "startLine": 10}, "value": "5"}]}},
            # child discovered inside funcA's local — the engine's owner label is the
            # scoped id, so the edge lands on the RIGHT parent node.
            {"dependentVariable": {
                "name": "g", "terminal": True,
                "dependencies": [{"variableName": "i@t:funcA",
                                  "foundAt": {"file": "t.cpp", "startLine": 5}}],
                "setters": []}},
        ],
    }
    lin = _build_lineage(chain_out, "rootVar", io_stems=_IO, const_names=_CONSTS,
                         input_prefixes=INPUT_MSG_PREFIXES,
                         ws_prefixes=WORKING_STORAGE_PREFIXES)
    by_id = {n["id"]: n for n in lin["nodes"]}
    assert set(by_id) == {"rootVar", "i@t:funcA", "i@t:funcB", "g"}
    assert by_id["i@t:funcA"]["name"] == "i" and by_id["i@t:funcB"]["name"] == "i"
    assert by_id["i@t:funcA"]["localScope"] == {"file": "t", "function": "funcA"}
    # each scoped node keeps only ITS setters — no merge
    assert [s["line"] for s in by_id["i@t:funcA"]["setters"]] == [4]
    assert [s["line"] for s in by_id["i@t:funcB"]["setters"]] == [10]
    # edges reference ids; the child of funcA's local hangs off the scoped parent
    assert {"from": "i@t:funcA", "to": "g",
            "foundAt": {"file": "t.cpp", "line": 5}} in lin["edges"]
    assert all(e["to"] != "i" and e["from"] != "i" for e in lin["edges"])
    # unscoped nodes keep id == name (backward compatible)
    assert by_id["g"]["id"] == "g" == by_id["g"]["name"]


def test_build_lineage_disambiguates_multi_identity_names_and_resolves_ownerkey():
    """v15: one display name arriving under TWO engine identities (depKey) used to
    keep-first-merge — the second identity's setters silently vanished. Now each
    identity gets its own node (id derived from the depKey discriminator), edges
    resolve by ownerKey, and every node carries nameKey for cross-chain
    case-variant consolidation."""
    chain_out = {
        "rootVariable": {"name": "rootVar", "setters": []},
        "dependentVariables": [
            {"dependentVariable": {
                "name": "LL9RTN", "terminal": False,
                "depKey": "LL9RTN|@lang:asm",
                "dependencies": [{"variableName": "rootVar",
                                  "foundAt": {"file": "y.asm", "startLine": 5}}],
                "setters": [{"location": {"file": "y.asm", "startLine": 313}, "value": "X"}]}},
            {"dependentVariable": {
                "name": "LL9RTN", "terminal": False,
                "depKey": "LL9RTN|@lang:cpp",
                "dependencies": [{"variableName": "rootVar",
                                  "foundAt": {"file": "d.cpp", "startLine": 3}}],
                "setters": [{"location": {"file": "d.cpp", "startLine": 2}, "value": "1"}]}},
            # child of the CPP identity: ownerKey names the parent unambiguously even
            # though both parents share the display name LL9RTN.
            {"dependentVariable": {
                "name": "src", "terminal": True, "depKey": "SRC|@lang:cpp",
                "dependencies": [{"variableName": "LL9RTN",
                                  "ownerKey": "LL9RTN|@lang:cpp",
                                  "foundAt": {"file": "d.cpp", "startLine": 2}}],
                "setters": []}},
        ],
    }
    lin = _build_lineage(chain_out, "rootVar", io_stems=_IO, const_names=_CONSTS,
                         input_prefixes=INPUT_MSG_PREFIXES,
                         ws_prefixes=WORKING_STORAGE_PREFIXES)
    by_id = {n["id"]: n for n in lin["nodes"]}
    assert set(by_id) == {"rootVar", "LL9RTN@asm", "LL9RTN@cpp", "src"}
    # each identity keeps its OWN setters — the pre-fix keep-first collapse lost one
    assert [s["line"] for s in by_id["LL9RTN@asm"]["setters"]] == [313]
    assert [s["line"] for s in by_id["LL9RTN@cpp"]["setters"]] == [2]
    # the child's edge resolves via ownerKey to the RIGHT same-named parent
    assert {"from": "LL9RTN@cpp", "to": "src",
            "foundAt": {"file": "d.cpp", "line": 2}} in lin["edges"]
    assert all(e["from"] != "LL9RTN" for e in lin["edges"] if e["to"] == "src")
    # nameKey on every node (cross-chain case-variant consolidation hook)
    assert by_id["LL9RTN@asm"]["nameKey"] == "LL9RTN"
    assert by_id["src"]["nameKey"] == "SRC"
    assert by_id["rootVar"]["nameKey"] == "ROOTVAR"
    # single-identity names keep id == name
    assert by_id["src"]["id"] == "src" == by_id["src"]["name"]


def test_build_lineage_emit_polish_self_loops_values_notset():
    """v15 polish: self-loop edges are dropped; an empty-string ASM value renders
    null (extraction miss, not an assigned empty string); the engine's ``isNotSet``
    marker survives as ``notSet`` (reading only "notSet" silently dropped it);
    ``priorValue`` passes through."""
    chain_out = {
        "rootVariable": {"name": "rootVar", "setters": []},
        "dependentVariables": [
            {"dependentVariable": {
                "name": "age", "terminal": True, "depKey": "AGE|@lang:cpp",
                "dependencies": [
                    {"variableName": "age",      # self-loop read-site: no edge
                     "foundAt": {"file": "rg77aa00.cpp", "startLine": 0}},
                    {"variableName": "rootVar",
                     "foundAt": {"file": "rg77aa00.cpp", "startLine": 9}}],
                "setters": [
                    {"location": {"file": "bb35.asm", "startLine": 157}, "value": ""},
                    {"location": {"file": "sw61.asm", "startLine": 20}, "value": "X",
                     "isNotSet": True},
                    {"location": {"file": "yk09.asm", "startLine": 313},
                     "value": "LL9RTN", "priorValue": True}]}},
        ],
    }
    lin = _build_lineage(chain_out, "rootVar", io_stems=_IO, const_names=_CONSTS,
                         input_prefixes=INPUT_MSG_PREFIXES,
                         ws_prefixes=WORKING_STORAGE_PREFIXES)
    assert all(e["from"] != e["to"] for e in lin["edges"])
    assert {"from": "rootVar", "to": "age",
            "foundAt": {"file": "rg77aa00.cpp", "line": 9}} in lin["edges"]
    node = next(n for n in lin["nodes"] if n["name"] == "age")
    by_line = {s["line"]: s for s in node["setters"]}
    assert by_line[157]["value"] is None          # extraction miss → null, not ""
    assert by_line[20].get("notSet") is True      # isNotSet accepted
    assert by_line[313].get("priorValue") is True # RMW marker passes through


def test_resolve_missing_symbols_maps_linkage_aliases_to_modules():
    # ckxc is #pragma map'd to TE90 (missing) → becomes te90; unpackdata maps to an
    # IN-corpus module → dropped entirely; bs30 has no alias → unchanged.
    ctx = {"stems": {"ckxc", "unpackdata", "bs30"},
           "callees_of": {"rh73iw00": ["ckxc", "unpackdata"], "em71": ["bs30"]},
           "bp_stems": {"unpack", "em71", "rh73iw00"}}
    entry_map = {"ckxc": "te90", "unpackdata": "unpack"}
    called_as = _resolve_missing_symbols(ctx, entry_map)
    assert ctx["stems"] == {"te90", "bs30"}
    assert ctx["callees_of"] == {"rh73iw00": ["te90"], "em71": ["bs30"]}
    assert called_as == {"te90": ["ckxc"]}


def test_build_lineage_missing_candidates_on_unresolved_terminal():
    chain_out = {
        "rootVariable": {"name": "rootVar", "setters": []},
        "dependentVariables": [
            {"dependentVariable": {
                "name": "mystery", "terminal": True,
                "dependencies": [{"variableName": "rootVar",
                                  "foundAt": {"file": "dw710000.cpp", "startLine": 7}}],
                "setters": []}},
        ],
    }
    lin = _build_lineage(chain_out, "rootVar", io_stems=_IO, const_names=_CONSTS,
                         input_prefixes=INPUT_MSG_PREFIXES,
                         ws_prefixes=WORKING_STORAGE_PREFIXES, missing_ctx=_MISSING)
    (term,) = lin["terminals"]
    assert term["classification"] == "unresolved"
    assert term["missingCandidates"] == ["xy99"]


def test_setter_summary_carries_full_conditions():
    """The lineage output must carry the actual ordered guard objects on each setter
    (expression text + source location + ASM/constant metadata), not a bare count —
    consumers read the guards straight from the chain file, no second /vbt/trace call."""
    from api.tasks.vbt_lineage_task import _setter_summary

    setter = {
        "location": {"file": "b.cpp", "startLine": 9},
        "value": "depB",
        "valueResolved": "'7'",
        "conditions": [
            {"order": 1, "condition": "mode == kDefaultMode", "blockId": "cpp:b:fn",
             "location": {"file": "b.cpp", "startLine": 4, "endLine": 4},
             "resolvedConstants": {"kDefaultMode": "'7'"}},
            {"order": 2, "condition": "LWRLS_FIELD != 0", "blockId": "asm:aa71:12",
             "location": {"file": "aa71.asm", "startLine": 88, "endLine": 88},
             "asmTest": "CLI   LWRLS_FIELD,0", "asmBranch": "BNE", "decisionLine": 88},
        ],
    }
    out = _setter_summary(setter)
    conds = out["conditions"]
    assert isinstance(conds, list) and len(conds) == 2
    assert conds[0] == {"order": 1, "condition": "mode == kDefaultMode",
                        "file": "b.cpp", "line": 4,
                        "resolvedConstants": {"kDefaultMode": "'7'"}}
    # ASM metadata rides along; blockId is dropped (lineage strips codeBlocks)
    assert conds[1]["asmTest"] == "CLI   LWRLS_FIELD,0"
    assert conds[1]["asmBranch"] == "BNE"
    assert conds[1]["decisionLine"] == 88
    assert "blockId" not in conds[0] and "blockId" not in conds[1]
    # no conditions -> key absent entirely (unchanged)
    assert "conditions" not in _setter_summary(
        {"location": {"file": "b.cpp", "startLine": 9}, "value": "x"})


def test_build_lineage_root_setters_embedded_and_evidence_on_node_and_terminal():
    """The root node embeds its setter summaries (same content as the doc's top-level
    rootSetters); terminal evidence rides on BOTH the node and the terminals entry."""
    chain_out = {
        "rootVariable": {"name": "rootVar", "setters": [
            {"location": {"file": "a.cpp", "startLine": 3}, "value": "depA",
             "conditions": [{"order": 1, "condition": "g == 1",
                             "location": {"file": "a.cpp", "startLine": 1}}]}]},
        "dependentVariables": [
            {"dependentVariable": {
                "name": "depA", "terminal": True, "memberOf": {"name": "LWRLS"},
                "dependencies": [{"variableName": "rootVar",
                                  "foundAt": {"file": "aa71.asm", "startLine": 10}}],
                "setters": [{"location": {"file": "b.cpp", "startLine": 9}, "value": "x",
                             "conditions": [{"order": 1, "condition": "g == 1",
                                             "location": {"file": "a.cpp", "startLine": 1}}]}]}}],
    }
    lin = _build_lineage(chain_out, "rootVar", io_stems=_IO, const_names=_CONSTS,
                         input_prefixes=INPUT_MSG_PREFIXES,
                         ws_prefixes=WORKING_STORAGE_PREFIXES)
    names = {n["name"]: n for n in lin["nodes"]}
    root = names["rootVar"]
    assert len(root["setters"]) == 1
    assert root["setters"][0]["conditions"][0]["condition"] == "g == 1"
    dep = names["depA"]
    # guards are inline dicts on every setter, not indexes into a side table
    assert dep["setters"][0]["conditions"][0]["condition"] == "g == 1"
    (term,) = lin["terminals"]
    assert term["evidence"]
    assert dep["evidence"] == term["evidence"]
    assert dep["classification"] == term["classification"]
