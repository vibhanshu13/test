"""Regression suite for the VBT engine — codifies every validation done during the
build (LG1OSI + softCardValue end-to-end, name_resolver, modifier index, noise
filter, chain-scoped reachability, stress). Run from repo root:

    env/bin/python3 -m pytest vbt/tests/test_engine.py -q

Requires the baseline at jobs/baseline-temp-asm (built no-LLM via run_baseline_pipeline.py).
"""
from pathlib import Path

import pytest

BP = Path("jobs/baseline-temp-asm/output")
ASM = Path("temp/asm")
GF = BP / "file_call_graph.json"

pytestmark = pytest.mark.skipif(
    not BP.exists() or not GF.exists() or not ASM.exists(),
    reason="baseline jobs/baseline-temp-asm not built",
)

from vbt.engine import trace_root_variable, Hop          # noqa: E402
from vbt.resolve.name_resolver import resolve            # noqa: E402
from vbt.precompute.modifier_index import get_modifier_index  # noqa: E402
from vbt.depvars.recurse import _filter_chain_scoped     # noqa: E402
from vbt.depvars.extract import DepVarRef                # noqa: E402
from vbt.interfaces import SetterSite                    # noqa: E402

CPP_CHAIN = [Hop("aa71", "asm", None), Hop("dw730000", "cpp", "DW73"),
             Hop("dw710000", "cpp", "callPlasticAuthenticationComponentInterface")]


def _common():
    return dict(blueprint_dir=BP, asm_dir=ASM, graph_file=GF)


def test_lg1osi_root_setter_and_condition():
    o = trace_root_variable("LG1OSI", "asm", [Hop("da78", "asm", None)], **_common())
    # GAP 9: filter to REAL setters — LG1OSI is conditionally set, so an additive "[not set]"
    # outcome entry is now also emitted (covered in test_not_set.py); this test is about the write.
    setters = [s for s in o["rootVariable"]["setters"] if not s.get("isNotSet")]
    assert len(setters) == 1
    s = setters[0]
    assert s["location"]["startLine"] == 854 and s["value"] == "LG#C400"
    conds = [c["condition"].replace(" ", "") for c in s["conditions"]]
    assert "WK_RRC==ZEROS" in conds          # polarity-resolved fallthrough of BNE
    deps = {d["dependentVariable"]["name"]: d["dependentVariable"] for d in o["dependentVariables"]}
    assert "WK_RRC" in deps and deps["WK_RRC"]["terminal"] is True


def test_softcardvalue_setters_guards_alias():
    o = trace_root_variable("softCardValue", "cpp", CPP_CHAIN, **_common())
    setters = o["rootVariable"]["setters"]
    locs = {s["location"]["startLine"] for s in setters}
    # softCardValue is assigned at these lines of the current dw710000.cpp
    # (processACreditTransaction): the ExpressPay (1003) and lstknpoa (1034) writes.
    assert {1003, 1034} <= locs
    s1003 = next(s for s in setters if s["location"]["startLine"] == 1003)
    conds = [c["condition"] for c in s1003["conditions"]]
    assert "linkSourceArea != 0" in conds
    assert "linkSourceArea->lstknpoa == 'Y'" in conds
    assert not any("Yankee" in c for c in conds)               # reconverging sibling excluded
    assert any(a["name"] == "LWRPOSFCRDV" for a in o["rootVariable"]["aliases"])
    assert not any(s["location"]["file"].endswith(".asm") for s in setters)  # OC self-test rejected


def test_mixed_route_chain_qualifies_cpp_hops(): # TC-01
    """An ASM-tailed trace reaching C++ setters goes through the engine's mixed/ASM
    route branch. Its chain must qualify C++ hops (``stem::fn``) exactly like a
    pure-C++ route while keeping ASM hops bare — and must do so as a DISPLAY-ONLY
    change: stems, count, and conditions are governed by the file-stem identity."""
    from vbt.engine import _chain_stem

    def _ftype(stem):
        if (ASM / f"{stem}.cpp").exists():
            return "cpp"
        if (ASM / f"{stem}.asm").exists():
            return "asm"
        return None

    # tail = aa71 (ASM); softCardValue's setters live in C++ files (dw710000, ...),
    # so every root chain crosses C++ files reached via the mixed branch.
    o = trace_root_variable("softCardValue", "cpp", [Hop("aa71", "asm", None)],
                            disable_dependents=True, **_common())
    setters = o["rootVariable"]["setters"]
    assert setters
    saw_qualified_cpp = False
    for s in setters:
        chain = s["chain"]
        # every chain begins at the ASM tail, kept bare (single-entry module).
        assert chain[0] == "aa71"
        for hop in chain:
            stem = _chain_stem(hop)
            ft = _ftype(stem)
            if ft == "asm":
                assert "::" not in hop, f"ASM hop must stay bare: {hop!r}"
            elif ft == "cpp" and "::" in hop:
                saw_qualified_cpp = True
                # the function entered must be real (parseable stem::fn shape).
                assert hop.split("::", 1)[1]
        # GAP 8: a C++ file may now appear MORE THAN ONCE — one hop per distinct intra-file
        # function entered (stem::fnA -> stem::fnB). The invariants that still hold:
        #  * P2: no exact-duplicate label.
        assert len(chain) == len(set(chain)), f"duplicate label in chain: {chain!r}"
        #  * P1: any file that appears more than once is C++ and every occurrence is
        #    function-qualified (a bare stem and a qualified label for the same file never
        #    coexist — the bare placeholder is upgraded in place).
        stems = [_chain_stem(h) for h in chain]
        for stem in {st for st in stems if stems.count(st) > 1}:
            assert _ftype(stem) == "cpp", f"non-cpp file {stem!r} repeated in chain {chain!r}"
            assert all("::" in h for h in chain if _chain_stem(h) == stem), \
                f"repeated file {stem!r} has a bare hop: {chain!r}"
    # the whole point of TC-01: at least one C++ hop is now function-qualified.
    assert saw_qualified_cpp, "no C++ hop was function-qualified on any mixed route"

    # spot-check the canonical entries seen in the live trace.
    qualified = {h for s in setters for h in s["chain"] if "::" in h}
    assert "dw710000::callPlasticAuthenticationComponentInterface" in qualified
    assert "dw730000::DW73" in qualified


def test_softcardvalue_depvars_clean_and_recursive():
    # This test specifically exercises DEEP (level-2) dep-var recursion, so it pins
    # max_dep_var_depth=2 (the engine default is now 1 — deep recursion is opt-in).
    o = trace_root_variable("softCardValue", "cpp", CPP_CHAIN, max_dep_var_depth=2, **_common())
    dvs = [d["dependentVariable"] for d in o["dependentVariables"]]
    names = {dv["name"] for dv in dvs}
    # noise filter: no C++ keywords/builtins/cast-types/ALL-CAPS macros
    assert not any(n in {"sizeof", "char", "memcmp", "x02", "LinkSource"} for n in names)

    # z/TPF ASM guard fields (e.g. @CASVIS1, L7DSTS) legitimately surface as UPPERCASE
    # dep-vars via the ASM-condition dep-var harvest — only a C++-origin ALL-CAPS token
    # would be macro/builtin noise, so scope the uppercase check to non-ASM dep-vars.
    def _is_asm_field(dv):
        mo = dv.get("memberOf") or {}
        return mo.get("language") == "asm" or dv["name"].startswith("@")
    cpp_upper = [dv["name"] for dv in dvs if dv["name"].isupper() and not _is_asm_field(dv)]
    assert not cpp_upper, cpp_upper

    # recursion descended at least one level (linkSourceArea -> ptrLwrls)
    assert "linkSourceArea" in names and "ptrLwrls" in names


def test_name_resolver_bidirectional_high_certainty():
    a = resolve("softCardValue", "cpp", ASM)
    assert any(x.name == "LWRPOSFCRDV" and x.language == "asm" and x.certainty == "high"
               for x in a.aliases)
    b = resolve("LWRPOSFCRDV", "asm", ASM)
    assert any("softCardValue" in x.name and x.language == "cpp" for x in b.aliases)


def test_modifier_index():
    idx = get_modifier_index(BP, ASM)
    assert {"dw710000", "dw780000"} <= idx.files_for("softCardValue", "cpp")
    assert idx.files_for("LG1OSI", "asm") == {"da78"}


def test_chain_scoped_before_descend_bound():
    def mk(stem, line):
        return SetterSite(variable="X", file_stem=stem, language="cpp", line=line,
                          instruction="assign", block_id="fn")
    dep = DepVarRef(name="X", language="cpp", relationship="condition",
                    found_at={"file": "dw710000.cpp", "startLine": 990, "endLine": 990})
    rel = _filter_chain_scoped(
        [mk("dw730000", 50), mk("dw730000", 200), mk("dw710000", 988), mk("dw710000", 995)],
        dep, {"aa71", "dw730000", "dw710000"}, {"dw730000": 106})
    got = {(s.file_stem, s.line) for s in rel}
    assert ("dw730000", 50) in got and ("dw730000", 200) not in got     # before/after descend
    assert ("dw710000", 988) in got and ("dw710000", 995) not in got    # before/after read


@pytest.mark.parametrize("var", ["aevvCasValidResult", "cidDbSelect", "inputCid", "exitIndicator"])
def test_stress_cpp_no_crash(var):
    o = trace_root_variable(var, "cpp", CPP_CHAIN, **_common())
    assert "rootVariable" in o and "dependentVariables" in o


@pytest.mark.parametrize("var", ["EBW000", "WK_CNT", "L7DRET", "WK_BAS3"])
def test_stress_asm_no_crash(var):
    o = trace_root_variable(var, "asm", [Hop("da78", "asm", None)], **_common())
    assert "rootVariable" in o and "dependentVariables" in o


# --------------------------------------------------------------------------- #
# Synthetic reachability fixture — exercises the engine-core reachability/chain
# logic in isolation (controlled call graph): R1-R6 root cases (tail-local guard,
# C6 intra-file inter-function gates, two-path dedup, function-level reachability,
# cross-file hop guard, two-call-site OR) + D1-D9 dep cases (before/after read,
# before/after descend, call-order callee, function-output return + by-ref output,
# intra-file gate as a dep var). Independent of the two reference vars (anti-overfit).
# --------------------------------------------------------------------------- #
_CFG_BIN = Path("vbt/cpp_frontend/cfg_extract")


@pytest.mark.skipif(not _CFG_BIN.exists(), reason="clang cfg_extract binary not built")
def test_reachability_fixture_all_cases():
    import importlib.util
    vp = Path("vbt/tests/fixtures/reachability/validate.py")
    spec = importlib.util.spec_from_file_location("rxvalidate", vp)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    m.parse_fixture()
    m.reconstruct_metadata()
    o = m.run_engine()
    res = m.check_cases(o)
    failed = [c for c, ok, _exp, act in res if not ok]
    assert not failed, f"reachability cases failed: {failed}"


# --------------------------------------------------------------------------- #
# AST early-exit fall-through guard (C-2). A terminating `if (c) { return; }`
# directly inside a block negates `c` for every statement AFTER it in that block,
# recovered PURELY from AST source spans (sound even when the CFG collapses). A
# then-only `if (c) { y=1; }` with no terminator does NOT gate the code after it.
# --------------------------------------------------------------------------- #
@pytest.mark.skipif(not _CFG_BIN.exists(), reason="clang cfg_extract binary not built")
def test_ast_early_exit_fall_through_guard(tmp_path):
    from vbt.conditions.cpp_conditions import collect_cpp_conditions, _ast_guards
    from vbt.cpp_frontend.wrapper import run_cfg_extract

    def ast_early_exit_regions(fn):
        return [g for g in fn.get("guard_regions", []) if g.get("kind") == "early_exit"]

    # FIRES: `if (c) { return; } x = 1;` — reaching x=1 implies !(c). The AST
    # emits an early_exit guard_region negating c over the fall-through span.
    fires = tmp_path / "fires.cpp"
    fires.write_text(
        "int g;\n"               # 1
        "void f(int c) {\n"      # 2
        "    if (c == 0) {\n"    # 3
        "        return;\n"      # 4
        "    }\n"                # 5
        "    g = 1;\n"           # 6  <- setter, reached only when !(c == 0)
        "}\n"                    # 7
    )
    fn = run_cfg_extract(str(fires))[0]
    ee = ast_early_exit_regions(fn)
    assert len(ee) == 1 and ee[0]["expr"] == "c == 0" and ee[0]["polarity"] is False
    assert ee[0]["start_line"] <= 6 <= ee[0]["end_line"]   # span contains the setter
    # End-to-end through _ast_guards: the negated guard + early_exit kind attaches.
    ag = _ast_guards(fn, 6, str(fires))
    ag_texts = {(c.condition, c.polarity, c.kind) for c in ag}
    assert ("!(c == 0)", False, "early_exit") in ag_texts, ag_texts
    # And it survives the full public path.
    assert "!(c == 0)" in {c.condition for c in collect_cpp_conditions(str(fires), 6, "f")}

    # DOES NOT FIRE: `if (c) { y = 1; } x = 1;` — no terminator, so x=1 is reached
    # on BOTH arms; the AST must emit NO early_exit region (and no c-guard at all).
    nofire = tmp_path / "nofire.cpp"
    nofire.write_text(
        "int g, h;\n"            # 1
        "void f(int c) {\n"      # 2
        "    if (c == 0) {\n"    # 3
        "        h = 2;\n"       # 4  (no return — then-arm falls through)
        "    }\n"                # 5
        "    g = 1;\n"           # 6  <- setter, reached on BOTH arms
        "}\n"                    # 7
    )
    fn2 = run_cfg_extract(str(nofire))[0]
    assert ast_early_exit_regions(fn2) == [], "non-terminating if must NOT emit an early_exit region"
    # neither c==0 nor !(c==0) gates the fall-through via the AST path
    assert not {c.condition for c in _ast_guards(fn2, 6, str(nofire))} & {"c == 0", "!(c == 0)"}

    # DOES NOT FIRE when an else REACHES the fall-through: `if (c) { return; }
    # else { h = 2; } g = 1;` — g=1 is reachable via the (non-terminating) else,
    # so the AST early-exit must not claim !(c) over it.
    elsereach = tmp_path / "elsereach.cpp"
    elsereach.write_text(
        "int g, h;\n"            # 1
        "void f(int c) {\n"      # 2
        "    if (c == 0) {\n"    # 3
        "        return;\n"      # 4
        "    } else {\n"         # 5
        "        h = 2;\n"       # 6  (else does NOT terminate)
        "    }\n"                # 7
        "    g = 1;\n"           # 8  <- reached via the else arm too
        "}\n"                    # 9
    )
    fn3 = run_cfg_extract(str(elsereach))[0]
    assert ast_early_exit_regions(fn3) == [], "else that reaches the fall-through must NOT emit an early_exit region"


# --------------------------------------------------------------------------- #
# D-F5: dependent-variable recursion must key memo + results on
# (tail.upper(), qualified), NOT the bare tail — so two GENUINELY DIFFERENT
# same-tail fields (different qualified path) both survive with their own
# setters, while a TRUE duplicate (same tail AND qualified) reached via two
# parents still collapses to ONE entry. Driven directly against trace_dependents
# with the heavy file/clang/blueprint collaborators monkeypatched out, so it
# exercises only the dedup/keying logic (independent of the corpus/baseline).
# --------------------------------------------------------------------------- #
def _stub_trace_dependents(monkeypatch, *, setters_by_tail):
    """Patch recurse.py's collaborators so trace_dependents runs in-memory.

    ``setters_by_tail`` maps a C++ tail -> list of SetterSite returned by the
    setter search; conditions/child-dep extraction are emptied so the recursion
    surfaces exactly the seeded deps (depth 1) and their found setters."""
    import vbt.depvars.recurse as R

    class _Idx:
        def files_for(self, name, language):
            return {"f"}
        def files_defining_function(self, fn_name):
            return set()
        def sites_for(self, *a, **k):
            return []

    monkeypatch.setattr(R, "get_modifier_index", lambda *a, **k: _Idx())
    # setter search: return whatever the test registered for this C++ tail.
    # (**kw absorbs the real signature's full_paths=/harvest_tails= kwargs.)
    monkeypatch.setattr(R, "find_cpp_setters_in_file",
                        lambda tail, path, **kw: list(setters_by_tail.get(tail, [])))
    monkeypatch.setattr(R, "find_asm_setters_in_file", lambda *a, **k: [])
    # conditions + child harvest: none (we only test top-level dedup/keying)
    monkeypatch.setattr(R, "collect_cpp_conditions", lambda *a, **k: [])
    monkeypatch.setattr(R, "collect_asm_conditions", lambda *a, **k: ([], False))
    monkeypatch.setattr(R, "extract_dep_vars", lambda *a, **k: [])
    # no real alias resolution / cfg / blueprint / store I/O
    monkeypatch.setattr(R, "resolve_aliases",
                        lambda name, lang, asm_dir: type("A", (), {"aliases": []})())
    monkeypatch.setattr(R, "run_cfg_extract", lambda *a, **k: [])
    monkeypatch.setattr(R, "_cpp_fn_block", lambda *a, **k: None)
    monkeypatch.setattr(R, "_dep_chunk", lambda *a, **k: None)
    # the chain-scoped filter would otherwise need cfg/blueprint; the setter's
    # file is treated as a chain file (kept) by giving it a chain entry with no
    # bound, so _filter_chain_scoped keeps it via the `F in chain_files` arm.
    # The candidate-file search only opens stems whose `<stem>.cpp` exists on disk,
    # so the chain file must be present for find_cpp_setters_in_file to be called.


def test_depvar_distinct_qualified_both_survive(monkeypatch, tmp_path):
    from vbt.depvars.recurse import trace_dependents
    from vbt.depvars.extract import DepVarRef
    from vbt.interfaces import SetterSite

    # f.cpp is on the chain so its setters are kept unconditionally (no descend bound).
    s_alloc = SetterSite(variable="cidRecord", file_stem="f", language="cpp", line=10,
                         instruction="assign", block_id="g", value="0")
    s_temp = SetterSite(variable="cidRecord", file_stem="f", language="cpp", line=20,
                        instruction="assign", block_id="g", value="1")
    # both deps share the TAIL `cidRecord` but have DIFFERENT qualified paths →
    # genuinely different fields; under bare-tail keying the 2nd was dropped.
    # expand_family=False isolates the dedup/keying logic under test from the
    # path-family container expansion (covered by test_depvar_pathfamily.py), which
    # would otherwise also surface the `allCidRecords`/`tempCidRecord` containers.
    dep_a = DepVarRef(name="cidRecord", language="cpp", relationship="condition",
                      found_at={"file": "f.cpp", "startLine": 30, "endLine": 30},
                      qualified="allCidRecords.cidRecord", expand_family=False)
    dep_b = DepVarRef(name="cidRecord", language="cpp", relationship="condition",
                      found_at={"file": "f.cpp", "startLine": 31, "endLine": 31},
                      qualified="tempCidRecord.cidRecord", expand_family=False)
    (tmp_path / "f.cpp").write_text("// chain file f\n")
    _stub_trace_dependents(monkeypatch, setters_by_tail={"cidRecord": [s_alloc, s_temp]})

    out = trace_dependents(
        [("root", dep_a), ("root", dep_b)], ["f"],
        blueprint_dir=tmp_path, asm_dir=tmp_path, store=None)

    quals = sorted(d["dependentVariable"].get("qualified", "") for d in out)
    assert quals == ["allCidRecords.cidRecord", "tempCidRecord.cidRecord"], quals
    # BOTH entries carry their own setters (the 2nd is no longer skipped at the memo gate)
    for d in out:
        assert d["dependentVariable"]["name"] == "cidRecord"
        assert len(d["dependentVariable"]["setters"]) == 2


def test_depvar_true_duplicate_merges_to_one(monkeypatch, tmp_path):
    from vbt.depvars.recurse import trace_dependents
    from vbt.depvars.extract import DepVarRef
    from vbt.interfaces import SetterSite

    s = SetterSite(variable="cidRecord", file_stem="f", language="cpp", line=10,
                   instruction="assign", block_id="g", value="0")
    # SAME tail AND SAME qualified, reached via two different parents → ONE entry.
    # expand_family=False isolates dedup/keying from path-family container expansion.
    dep1 = DepVarRef(name="cidRecord", language="cpp", relationship="condition",
                     found_at={"file": "f.cpp", "startLine": 30, "endLine": 30},
                     qualified="allCidRecords.cidRecord", expand_family=False)
    dep2 = DepVarRef(name="cidRecord", language="cpp", relationship="condition",
                     found_at={"file": "f.cpp", "startLine": 40, "endLine": 40},
                     qualified="allCidRecords.cidRecord", expand_family=False)
    (tmp_path / "f.cpp").write_text("// chain file f\n")
    _stub_trace_dependents(monkeypatch, setters_by_tail={"cidRecord": [s]})

    out = trace_dependents(
        [("parentA", dep1), ("parentB", dep2)], ["f"],
        blueprint_dir=tmp_path, asm_dir=tmp_path, store=None)

    assert len(out) == 1, [d["dependentVariable"].get("qualified") for d in out]
    dv = out[0]["dependentVariable"]
    assert dv["name"] == "cidRecord" and dv.get("qualified") == "allCidRecords.cidRecord"
    # exactly one entry; no duplicate setter explosion
    assert len(dv["setters"]) == 1
    # ...but BOTH parents' read-sites are now captured as DAG in-edges (the node is
    # deduped, the dependency edges accumulate — not collapsed to the first discoverer).
    edges = {(e["variableName"], e["foundAt"]["startLine"]) for e in dv["dependencies"]}
    assert edges == {("parentA", 30), ("parentB", 40)}, dv["dependencies"]


# GAP 6: direct trace_dependents() output must carry the file/line/function
# convenience fields on every dep-var setter (consumers/tools call this without
# going through the assembler). Reuses the same monkeypatched in-memory harness;
# _cpp_fn_block is overridden to hand back a real C++ blockId so `function` derives.
def test_depvar_setters_carry_location_convenience_fields(monkeypatch, tmp_path):
    import vbt.depvars.recurse as R
    from vbt.depvars.recurse import trace_dependents
    from vbt.depvars.extract import DepVarRef
    from vbt.interfaces import SetterSite

    s = SetterSite(variable="cidRecord", file_stem="f", language="cpp", line=10,
                   instruction="assign", block_id="g", value="0")
    dep = DepVarRef(name="cidRecord", language="cpp", relationship="condition",
                    found_at={"file": "f.cpp", "startLine": 30, "endLine": 30},
                    qualified="allCidRecords.cidRecord", expand_family=False)
    (tmp_path / "f.cpp").write_text("// chain file f\n")
    _stub_trace_dependents(monkeypatch, setters_by_tail={"cidRecord": [s]})
    # override the stub's None block id with a real C++ block id so `function` derives
    monkeypatch.setattr(R, "_cpp_fn_block", lambda *a, **k: "cpp:f:setCidRecord")

    out = trace_dependents([("root", dep)], ["f"],
                           blueprint_dir=tmp_path, asm_dir=tmp_path, store=None)

    dv = out[0]["dependentVariable"]
    assert dv["terminal"] is False and dv["setters"], "expected a non-terminal dep-var"
    for st in dv["setters"]:
        # file/line mirror location; convenience keys always present
        assert st["file"] == st["location"]["file"]
        assert st["line"] == st["location"]["startLine"]
        assert "function" in st and "blockId" in st
        # this dep-var setter is C++ with a C++ blockId → function is derived (not null)
        if isinstance(st.get("blockId"), str) and st["blockId"].startswith("cpp:"):
            assert st["function"] == "setCidRecord"
