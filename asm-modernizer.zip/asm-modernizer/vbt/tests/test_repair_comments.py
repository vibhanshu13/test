"""Verified runaway-comment repair tool (vbt/tools/repair_comments.py).

Two layers:
  * SELF-CONTAINED (no corpus / no Clang): tiny synthetic .cpp files mirroring the real
    defect — a ``/**`` doc comment missing its ``*/`` that swallows a function (or
    several) before the NEXT ``/** … */``. We assert the tool proposes the ``*/``
    insertion, the repaired text makes the function a real ``function_definition``, the
    source-lint detector then reports it clean, and tree-sitter / comment-balance
    verification passes (Clang is skipped — a synthetic snippet has nothing to resolve).
    A NEGATIVE fixture (a deliberately-commented-out ``/* … } */`` function) must be
    REJECTED because inserting ``*/`` would strand the original ``*/``.
  * CORPUS-GUARDED (needs temp/asm + Clang cfg_extract): the canonical dw710000.cpp
    ``editCidInquiryInputs`` case must classify deterministically as repairable, and the
    deliberately-commented-out cases must be rejected.

Mirrors the skipif pattern in test_truncation_lint.py / test_repair_braces.py.
"""
from pathlib import Path

import pytest

from vbt.precompute.source_lint import scan_source_for_swallowed
from vbt.tools.repair_comments import (
    _apply_insert,
    _fn_def_count,
    _fn_def_names,
    _unmatched_comment_closers,
    apply_repairs,
    repair_comment,
    run,
)

ASM = Path("temp/asm")

# A /** doc comment missing its */ runs on until the NEXT doc comment's */, swallowing
# the function between them. Mirrors temp/asm/dw710000.cpp:732..782.
_SWALLOWED = """\
void liveBefore() { return; }

/** docA  #editCidInquiryInputs
 * @brief edits inputs and returns a verdict
 * @param plasticAuth structure
 * @return Pa::Bad or Pa::Good
 *

static Pa::ReturnCode editCidInquiryInputs(PlasticAuth& plasticAuth,
                                           const LwrIso& lwrIso,
                                           LwrCommon& lwrCommon)
{
   if (processEdit4dbcValue(lwrCommon, plasticAuth) == Pa::Bad)
   {
      return Pa::Bad;
   }
   return Pa::Good;
}

/** docB  #processCidInquiry
 * @brief next doc comment, whose own closer ends the runaway one above
 */
void processCidInquiry(PlasticAuth& plasticAuth) { return; }
"""

# Two real functions swallowed by ONE runaway comment; closing before the FIRST must
# make BOTH live. The NEXT doc comment's */ closes the runaway one.
_MULTI = """\
void liveBefore() { return; }

/** docA
 * @return int
 *

static int getNumberOfNoGoodItems(PrePaymentVariables& pre)
{
   return pre.count;
}

static int getHighestInternalRemit(PrePaymentVariables& pre)
{
   return pre.remit;
}

/** next
 */
void liveAfter() { return; }
"""

# NEGATIVE: a function deliberately COMMENTED OUT by a /*Rxxx … } */ block — the */ sits
# right after the function's own closing brace, with NO next /** between. Inserting a */
# before the function would STRAND the original */, so the tool must REJECT this.
# Mirrors temp/asm/bp300000.cpp:66..110 and nm120100.cpp accessHsmIVR.
_COMMENTED_OUT = """\
void liveBefore() { return; }

/*R015 obsolete — this whole function is deliberately commented out
static void getNumberOfNoGoodItems(PrePaymentVariables& pre)
{
   if (pre.count > 0)
   {
      pre.count++;
   }
   else if (pre.count < 0)
   {
      pre.count--;
   }
   else
   {
      pre.count = 0;
   }
   return;
} */

void liveAfter() { return; }
"""


def _write(tmp_path, name, text):
    p = tmp_path / name
    p.write_text(text)
    return str(p)


# --------------------------------------------------------------------------- #
# Self-contained: comment-balance scanner + proposal + verification.
# --------------------------------------------------------------------------- #
def test_unmatched_comment_closer_scanner():
    # balanced /* */ → no stray; a bare */ with no opener → one stray.
    assert _unmatched_comment_closers("/* a */ code") == 0
    assert _unmatched_comment_closers("code */ more") == 1
    # */ inside a string / line-comment / char literal is NOT a stray closer.
    assert _unmatched_comment_closers('const char* s = "a */ b";') == 0
    assert _unmatched_comment_closers("// trailing */ here") == 0
    assert _unmatched_comment_closers("char c = '*'; int x = 1;") == 0


def test_apply_insert_places_closer_before_line():
    src = "a\nb\nc\n"
    out = _apply_insert(src, 2)
    assert out.split("\n")[1] == "*/"            # `*/` now sits before old line 2
    assert out.split("\n")[2] == "b"


def test_runaway_comment_is_repairable_and_recovers_function(tmp_path):
    path = _write(tmp_path, "a.cpp", _SWALLOWED)
    # the function is swallowed before repair
    assert "editCidInquiryInputs" in {f.function for f in scan_source_for_swallowed(path)}
    group = scan_source_for_swallowed(path)
    f = repair_comment(path, group, run_clang=False)
    assert f.repairable, f.reason
    assert f.functions == ["editCidInquiryInputs"]
    # insertion lands on the swallowed function's signature line (general, not hardcoded)
    fl = next(s.function_line for s in group if s.function == "editCidInquiryInputs")
    assert f.insert_before_line == fl

    # apply the proposed insertion and confirm the recovery + clean source-lint.
    text = Path(path).read_text()
    repaired = _apply_insert(text, f.insert_before_line)
    assert "editCidInquiryInputs" in _fn_def_names(repaired.encode())
    assert _fn_def_count(repaired.encode()) == _fn_def_count(text.encode()) + 1
    repaired_path = _write(tmp_path, "a_fixed.cpp", repaired)
    assert scan_source_for_swallowed(repaired_path) == []       # detector now clean
    assert _unmatched_comment_closers(repaired) == 0            # no stranded */


def test_multiple_functions_in_one_comment_all_recovered(tmp_path):
    path = _write(tmp_path, "m.cpp", _MULTI)
    group = scan_source_for_swallowed(path)
    names = {s.function for s in group}
    assert {"getNumberOfNoGoodItems", "getHighestInternalRemit"} <= names
    f = repair_comment(path, group, run_clang=False)
    assert f.repairable, f.reason
    # closes before the FIRST swallowed function so ALL become live
    assert set(f.functions) == {"getNumberOfNoGoodItems", "getHighestInternalRemit"}
    first = min(s.function_line for s in group)
    assert f.insert_before_line == first

    repaired = _apply_insert(Path(path).read_text(), f.insert_before_line)
    defs = _fn_def_names(repaired.encode())
    assert {"getNumberOfNoGoodItems", "getHighestInternalRemit"} <= set(defs)
    assert scan_source_for_swallowed(_write(tmp_path, "m_fixed.cpp", repaired)) == []


def test_commented_out_function_is_rejected(tmp_path):
    # The detector DOES flag it (it looks like a swallowed fn), but the repair must be
    # rejected: inserting */ before the fn strands the original */ at `} */`.
    path = _write(tmp_path, "c.cpp", _COMMENTED_OUT)
    group = scan_source_for_swallowed(path)
    assert group, "fixture should be flagged by the detector"
    f = repair_comment(path, group, run_clang=False)
    assert not f.repairable
    assert "strand" in f.reason.lower()


def test_run_groups_by_comment_and_apply_writes_only_verified(tmp_path):
    _write(tmp_path, "a.cpp", _SWALLOWED)
    _write(tmp_path, "c.cpp", _COMMENTED_OUT)
    findings = scan_source_for_swallowed(str(tmp_path / "a.cpp")) + \
        scan_source_for_swallowed(str(tmp_path / "c.cpp"))
    # run() needs Clang for these (run_clang defaults True); skip if the binary is absent.
    from vbt.cpp_frontend.wrapper import DEFAULT_BINARY
    if not Path(DEFAULT_BINARY).is_file():
        pytest.skip("cfg_extract binary not built")
    verdicts = run(tmp_path, findings)
    by_file = {v.file: v for v in verdicts}
    assert by_file["a.cpp"].repairable, by_file["a.cpp"].reason
    assert not by_file["c.cpp"].repairable
    written = apply_repairs(tmp_path, verdicts)
    assert written == [str(tmp_path / "a.cpp")]                 # only the verified one
    # the commented-out file is byte-for-byte untouched
    assert Path(tmp_path / "c.cpp").read_text() == _COMMENTED_OUT
    # the repaired file now has the function live and no swallowed report
    assert scan_source_for_swallowed(str(tmp_path / "a.cpp")) == []


# --------------------------------------------------------------------------- #
# Corpus-guarded: the canonical dw710000 editCidInquiryInputs case.
# --------------------------------------------------------------------------- #
@pytest.mark.skipif(not (ASM / "dw710000.cpp").exists(),
                    reason="temp/asm sources not present")
def test_editCidInquiryInputs_repairable_deterministic():
    path = str(ASM / "dw710000.cpp")
    group = [f for f in scan_source_for_swallowed(path)
             if f.function == "editCidInquiryInputs"]
    if not group:
        pytest.skip("editCidInquiryInputs already comment-repaired in this corpus")
    f1 = repair_comment(path, group)
    f2 = repair_comment(path, group)
    # deterministic verdict + insertion line
    assert f1.repairable == f2.repairable
    assert f1.insert_before_line == f2.insert_before_line
    # THE known genuine runaway /** doc comment: closing it before the signature makes
    # editCidInquiryInputs a real function for both tree-sitter and Clang.
    assert f1.repairable, f1.reason
    assert f1.functions == ["editCidInquiryInputs"]
    # the */ is inserted just before the signature (general region, not a hardcoded line)
    sig = group[0].function_line
    assert f1.insert_before_line == sig
    assert "editCidInquiryInputs" in f1.cfg_recovered    # Clang now emits a CFG


@pytest.mark.skipif(not (ASM / "nm120100.cpp").exists(),
                    reason="temp/asm sources not present")
def test_commented_out_corpus_function_is_rejected():
    # accessHsmIVR / validateGns5csc in nm120100.cpp are deliberately-commented-out
    # /* … } */ blocks — must be REJECTED (inserting */ strands the original */).
    path = str(ASM / "nm120100.cpp")
    for name in ("validateGns5csc", "accessHsmIVR"):
        group = [f for f in scan_source_for_swallowed(path) if f.function == name]
        if not group:
            continue
        f = repair_comment(path, group)
        assert not f.repairable, f"{name} must not be repaired (would strand a '*/')"
        assert "strand" in f.reason.lower()


@pytest.mark.skipif(not (ASM / "dw710000.cpp").exists(),
                    reason="temp/asm sources not present")
def test_run_over_report_under_repairs_safely():
    report = Path("process_analysis/swallowed_functions.json")
    if not report.exists():
        pytest.skip("swallowed-functions report not present")
    from vbt.tools.repair_comments import load_targets
    findings = load_targets(report)
    verdicts = run(ASM, findings)
    assert verdicts
    for v in verdicts:
        if v.repairable:
            assert v.functions                      # a repairable verdict names its fns
            assert v.cfg_recovered                  # and Clang recovered them
        else:
            assert v.reason                          # NOT-REPAIRABLE must explain why
    # The canonical case is repairable — unless already repaired in this corpus (absent).
    eci = next((v for v in verdicts if "editCidInquiryInputs" in v.functions), None)
    if eci is not None:
        assert eci.repairable, eci.reason
    # under-repairing safely: at least one deliberately-commented-out case is rejected.
    assert any(not v.repairable for v in verdicts)
