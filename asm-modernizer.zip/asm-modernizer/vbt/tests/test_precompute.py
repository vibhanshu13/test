"""Precompute-layer regression suite (disk-backed const resolver + setter-site index).

Covers the two PRECOMPUTE scaling improvements:
  * const_resolver disk round-trip — build, reload from disk WITHOUT re-globbing,
    identical resolutions (incl. the must-not-change ``...::ExpressPayTransaction`` → None).
  * modifier_index setter SITES — ``sites_for`` round-trips through disk, ``files_for``
    is unchanged, sites are consistent with the precise setter finder, and the
    returned order is deterministic.

Run from repo root:
    env/bin/python3 -m pytest vbt/tests/test_precompute.py -q

Requires the baseline at jobs/baseline-temp-asm (built no-LLM via run_baseline_pipeline.py).
"""
from pathlib import Path

import pytest

BP = Path("jobs/baseline-temp-asm/output")
ASM = Path("temp/asm")

pytestmark = pytest.mark.skipif(
    not BP.exists() or not ASM.exists(),
    reason="baseline jobs/baseline-temp-asm not built",
)

import vbt.resolve.const_resolver as cr_mod              # noqa: E402
from vbt.resolve.const_resolver import get_const_resolver  # noqa: E402
import vbt.precompute.modifier_index as mi_mod           # noqa: E402
from vbt.precompute.modifier_index import (              # noqa: E402
    get_modifier_index, SetterSiteRef,
)
from vbt.setters.cpp_setters import find_cpp_setters_in_file  # noqa: E402
from vbt.setters.asm_setters import find_asm_setters_in_file  # noqa: E402


@pytest.fixture()
def isolated_cache(tmp_path, monkeypatch):
    """Point VBT_CACHE_DIR at a fresh temp dir and clear both in-process caches so
    every test exercises a genuine cold build → disk persist → cold reload cycle."""
    monkeypatch.setenv("VBT_CACHE_DIR", str(tmp_path))
    cr_mod._CACHE.clear()
    mi_mod._CACHE.clear()
    return tmp_path


# --------------------------------------------------------------------------- #
# TASK B — const resolver disk round-trip
# --------------------------------------------------------------------------- #
# (name, language, expected value).  ExpressPayTransaction resolves to 'Z' — its
# defining header (pauth.hpp: "ExpressPayTransaction = 'Z'") is in this corpus.
_CONST_SAMPLES = [
    ("LG#C400", "asm", "C'D'"),
    ("OnlineSourceInd::C400", "cpp", "'D'"),
    ("C400", "cpp", "'D'"),
    ("SoftCardValueDetail::ExpressPayTransaction", "cpp", "'Z'"),
]


def test_const_resolver_disk_roundtrip(isolated_cache, monkeypatch):
    # ---- cold build: persists to disk, exact baseline resolutions ----
    build_calls = {"n": 0}
    orig_build = cr_mod._build_resolver

    def spy_build(b, a):
        build_calls["n"] += 1
        return orig_build(b, a)

    monkeypatch.setattr(cr_mod, "_build_resolver", spy_build)

    cold = get_const_resolver(BP, ASM)
    assert build_calls["n"] == 1, "cold build should construct the resolver once"
    cold_vals = {(n, l): cold.resolve(n, l) for n, l, _ in _CONST_SAMPLES}
    for n, l, expected in _CONST_SAMPLES:
        assert cold.resolve(n, l) == expected, f"{n}/{l}"

    artifacts = list((isolated_cache / "const").glob("const-*.json"))
    assert len(artifacts) == 1, "cold build must persist exactly one artifact"

    # ---- second 'process': clear in-proc cache, prove NO re-glob / NO rebuild ----
    cr_mod._CACHE.clear()
    build_calls["n"] = 0
    glob_calls = {"n": 0}
    for fn in ("_cpp_pairs_from_blueprint", "_cpp_pairs_from_source",
               "_asm_pairs_from_source"):
        orig = getattr(cr_mod, fn)

        def make(o):
            def wrapped(*a, **k):
                glob_calls["n"] += 1
                return o(*a, **k)
            return wrapped
        monkeypatch.setattr(cr_mod, fn, make(orig))

    warm = get_const_resolver(BP, ASM)
    assert build_calls["n"] == 0, "warm load must NOT rebuild"
    assert glob_calls["n"] == 0, "warm load must NOT re-glob / re-parse sources"

    # identical resolutions after a disk reload
    for n, l, _ in _CONST_SAMPLES:
        assert warm.resolve(n, l) == cold_vals[(n, l)], f"{n}/{l} changed after reload"
    assert warm.cpp_enum == cold.cpp_enum
    assert warm.asm_const == cold.asm_const


def test_const_resolver_rebuilds_on_manifest_change(isolated_cache, monkeypatch):
    """A version bump (artifact-version embedded in the manifest hash) routes to a
    different artifact path → a fresh build, not a stale reload."""
    get_const_resolver(BP, ASM)               # seed v1 artifact
    cr_mod._CACHE.clear()

    monkeypatch.setattr(cr_mod, "_ARTIFACT_VERSION", cr_mod._ARTIFACT_VERSION + 1)
    rebuilt = {"n": 0}
    orig = cr_mod._build_resolver

    def spy(b, a):
        rebuilt["n"] += 1
        return orig(b, a)
    monkeypatch.setattr(cr_mod, "_build_resolver", spy)

    get_const_resolver(BP, ASM)
    assert rebuilt["n"] == 1, "a version/manifest change must force a rebuild"


# --------------------------------------------------------------------------- #
# TASK C — setter SITES index round-trip + files_for unchanged + consistency
# --------------------------------------------------------------------------- #
def test_modifier_index_files_for_unchanged(isolated_cache):
    idx = get_modifier_index(BP, ASM)
    # the exact assertions from test_engine.test_modifier_index must still hold
    assert {"dw710000", "dw780000"} <= idx.files_for("softCardValue", "cpp")
    assert idx.files_for("LG1OSI", "asm") == {"da78"}
    assert idx.files_for("LWRPOSFCRDV", "asm") == {"nh76"}


def test_sites_index_disk_roundtrip(isolated_cache, monkeypatch):
    # ---- cold build (one), persists v2 artifact with sites ----
    build_calls = {"n": 0}
    orig = mi_mod._build_index

    def spy(b, a, files):
        build_calls["n"] += 1
        return orig(b, a, files)
    monkeypatch.setattr(mi_mod, "_build_index", spy)

    cold = get_modifier_index(BP, ASM)
    assert build_calls["n"] == 1
    cold_cpp = cold.sites_for("softCardValue", "cpp")
    cold_asm = cold.sites_for("EBW000", "asm")
    assert cold_cpp and cold_asm
    # Reference the module's CURRENT class (robust if another test reloaded the
    # module and rebound SetterSiteRef to a fresh class object).
    assert all(isinstance(s, mi_mod.SetterSiteRef) for s in cold_cpp + cold_asm)

    artifacts = list((isolated_cache / "index").glob("modidx-*.json"))
    assert len(artifacts) == 1

    # ---- second 'process': reload from disk, no rebuild, identical sites ----
    mi_mod._CACHE.clear()
    build_calls["n"] = 0
    warm = get_modifier_index(BP, ASM)
    assert build_calls["n"] == 0, "warm load must NOT rebuild the index"

    assert warm.sites_for("softCardValue", "cpp") == cold_cpp
    assert warm.sites_for("EBW000", "asm") == cold_asm
    # files_for derivable from / consistent across the reload
    assert warm.files_for("softCardValue", "cpp") == cold.files_for("softCardValue", "cpp")


def test_sites_consistent_with_cpp_setter_finder(isolated_cache):
    """The coarse C++ sites' (file, line) must match what the precise
    find_cpp_setters_in_file reports for the same candidate files."""
    idx = get_modifier_index(BP, ASM)
    index_fl = {(s.file_stem, s.line) for s in idx.sites_for("softCardValue", "cpp")}
    precise_fl = set()
    for stem in idx.files_for("softCardValue", "cpp"):
        for s in find_cpp_setters_in_file("softCardValue", ASM / f"{stem}.cpp"):
            precise_fl.add((s.file_stem, s.line))
    assert index_fl == precise_fl, (index_fl ^ precise_fl)


def test_sites_consistent_with_asm_setter_finder(isolated_cache):
    """For an ASM var whose coarse sites survive precise verification, every
    precise (file, line) must be present in the coarse index sites (the index is
    a superset — the precise finder may reject some coarse sites)."""
    idx = get_modifier_index(BP, ASM)
    index_fl = {(s.file_stem, s.line) for s in idx.sites_for("EBW000", "asm")}
    precise_fl = set()
    for stem in idx.files_for("EBW000", "asm"):
        for s in find_asm_setters_in_file("EBW000", stem, BP, ASM):
            precise_fl.add((s.file_stem, s.line))
    assert precise_fl, "precise finder should locate at least one EBW000 site"
    assert precise_fl <= index_fl, (precise_fl - index_fl)


def test_sites_for_is_deterministic_and_sorted(isolated_cache):
    idx = get_modifier_index(BP, ASM)
    for name, lang in (("softCardValue", "cpp"), ("EBW000", "asm")):
        a = [s.as_tuple() for s in idx.sites_for(name, lang)]
        b = [s.as_tuple() for s in idx.sites_for(name, lang)]
        assert a == b                                  # stable across calls
        expected = sorted(a, key=lambda t: (t[0], t[2], t[3], t[1]))
        assert a == expected                           # sorted order
