"""Register-indirect ASM setter-source resolution — focused unit suite.

Exercises ``vbt.resolve.register_indirect`` on small synthetic blueprints (fast, no
parser run, anti-overfit to the real corpus).  Each blueprint is a minimal
``{blocks, line_metadata, dsect_layouts, meta}`` dict written to a temp ``*.asm.json``
so the real CFG builder (``_get_file_cfg_maps``) consumes it unchanged.

Cases:
  * LA-named            — ``LA R1,FIELDX`` then ``MVC dst,0(R1)`` → FIELDX
  * L-pointer           — ``L  R1,PTRFLD``  then ``MVC dst,0(R1)`` → PTRFLD
  * LR-copy             — ``LA R2,FIELDY`` / ``LR R1,R2`` → FIELDY (recurse Rm)
  * LA-self-mod-chain   — base load + ``LA R1,4(R1)`` self-mods → still the base,
                          and NO ``L'NAME`` / ``d(R1)`` noise leaks
  * USING-base→DSECT    — R8 USING a DSECT, ``MVC dst,8(R8)`` → member at offset 8
  * call-return         — ``ENTRC SOMECALL`` defines R15, ``MVC dst,0(R15)`` →
                          ``call_return@R15`` implicit re-root (sound)
  * give-up             — base register never defined in-file (caller-inherited) →
                          unresolved + indirection envelope (NO guessed field)
  * determinism+bounded — a ``J``-loop self-mod chain terminates and is stable

Run:  env/bin/python3 -m pytest vbt/tests/test_register_indirect.py -q
"""
from __future__ import annotations

import json
import os
import tempfile
from typing import Any, Dict, List, Optional

import pytest

from vbt.resolve.register_indirect import (
    resolve_register_indirect,
    is_register_indirect,
    ResolvedIndirect,
)


# --------------------------------------------------------------------------- #
# Synthetic blueprint helpers
# --------------------------------------------------------------------------- #
def _flow(line: int, inst: str, args: Optional[List[str]] = None,
          var: Optional[str] = None) -> Dict[str, Any]:
    return {"line": line, "inst": inst, "args": args, "var": var}


def _block(bid: str, flow: List[Dict[str, Any]],
           incoming: Optional[List[Dict[str, str]]] = None) -> Dict[str, Any]:
    lines = [f["line"] for f in flow if f["line"]]
    b: Dict[str, Any] = {
        "id": bid,
        "start_line": min(lines) if lines else 0,
        "end_line": max(lines) if lines else 0,
        "flow": flow,
    }
    if incoming:
        b["incoming_branches"] = incoming
    return b


def _write_bp(bp: Dict[str, Any]) -> str:
    fd, path = tempfile.mkstemp(suffix=".asm.json")
    os.write(fd, json.dumps(bp).encode())
    os.close(fd)
    return path


def _resolve(bp: Dict[str, Any], operand: str, block_id: str,
             before_line: int) -> ResolvedIndirect:
    path = _write_bp(bp)
    try:
        return resolve_register_indirect(
            operand, stem="syn", block_id=block_id, before_line=before_line,
            bp_data=bp, bp_path=path, asm_dir=None,
        )
    finally:
        os.unlink(path)


# --------------------------------------------------------------------------- #
# is_register_indirect gate
# --------------------------------------------------------------------------- #
def test_is_register_indirect_gate():
    assert is_register_indirect("0(R1)") is True
    assert is_register_indirect("4(R3)") is True
    assert is_register_indirect("0(R5,R1)") is True          # d(X,B)
    assert is_register_indirect("FIELD(R1)") is False        # named prefix → already a candidate
    assert is_register_indirect("LWRLS4CSCRES") is False     # plain field
    assert is_register_indirect("LG#C400") is False          # constant, no paren
    assert is_register_indirect("=C'00'") is False           # literal


# --------------------------------------------------------------------------- #
# LA-named: LA R1,FIELDX  /  MVC dst,0(R1)
# --------------------------------------------------------------------------- #
def test_la_named():
    bp = {"blocks": [
        _block("ENTRY", [_flow(10, "LA", ["R1", "FIELDX"]), _flow(12, "B", ["SET"])]),
        _block("SET", [_flow(20, "MVC", None, "DEST")],
               incoming=[{"source": "ENTRY", "type": "BRANCH"}]),
    ]}
    r = _resolve(bp, "0(R1)", "SET", 20)
    assert r.named_deps == ["FIELDX"]
    assert r.kind == "reaching_def"


# --------------------------------------------------------------------------- #
# L-pointer: L R1,PTRFLD  (pointer load)  /  MVC dst,0(R1)
# --------------------------------------------------------------------------- #
def test_l_pointer():
    bp = {"blocks": [
        _block("ENTRY", [_flow(10, "L", ["R1", "PTRFLD"]), _flow(12, "B", ["SET"])]),
        _block("SET", [_flow(20, "MVC", None, "DEST")],
               incoming=[{"source": "ENTRY", "type": "BRANCH"}]),
    ]}
    r = _resolve(bp, "0(R1)", "SET", 20)
    assert r.named_deps == ["PTRFLD"]


# --------------------------------------------------------------------------- #
# LR-copy: LA R2,FIELDY ; LR R1,R2  → recurse R2 → FIELDY
# --------------------------------------------------------------------------- #
def test_lr_copy_recurse():
    bp = {"blocks": [
        _block("ENTRY", [
            _flow(8, "LA", ["R2", "FIELDY"]),
            _flow(10, "LR", ["R1", "R2"]),
            _flow(12, "B", ["SET"]),
        ]),
        _block("SET", [_flow(20, "MVC", None, "DEST")],
               incoming=[{"source": "ENTRY", "type": "BRANCH"}]),
    ]}
    r = _resolve(bp, "0(R1)", "SET", 20)
    assert r.named_deps == ["FIELDY"]


# --------------------------------------------------------------------------- #
# LA-self-mod-chain: base load + LA R1,4(R1) self-mods + comment-contaminated
# L'NAME(R1) self-mod must NOT leak; result is the base field only.
# --------------------------------------------------------------------------- #
def test_la_self_mod_chain_no_noise():
    bp = {"blocks": [
        _block("ENTRY", [
            _flow(10, "LA", ["R1", "BASEFLD+2 POINT TO DATA  R001"]),  # comment contamination
            _flow(12, "B", ["LOOP"]),
        ]),
        _block("LOOP", [
            _flow(20, "LA", ["R1", "4(R1)"]),                          # self-mod bump
            _flow(22, "MVC", None, "DEST"),                            # the setter (uses 0(R1))
            _flow(24, "LA", ["R1", "L'DEST(R1) BUMP WITH VALUE  R002"]),  # self-mod after setter
        ], incoming=[{"source": "ENTRY", "type": "BRANCH"}]),
    ]}
    r = _resolve(bp, "0(R1)", "LOOP", 22)
    assert r.named_deps == ["BASEFLD"]                # comment + "+2" stripped, base resolved
    assert not any("'" in n for n in r.named_deps)    # no L'NAME length-attr noise
    assert not any(n.startswith("4(") or "(R1)" in n for n in r.named_deps)


# --------------------------------------------------------------------------- #
# USING-base → DSECT field: R8 USING MYDSECT, MVC dst,8(R8) → member at offset 8
# --------------------------------------------------------------------------- #
def test_using_base_dsect_member():
    bp = {
        "blocks": [
            _block("SET", [_flow(30, "MVC", None, "DEST")]),
        ],
        "line_metadata": {
            "25": {"active_usings": {"R8": "MYDSECT"}},
        },
        "dsect_layouts": {
            "MYDSECT": {
                "HDRFLD": {"offset": 0, "length": 8},
                "PAYFLD": {"offset": 8, "length": 4},
                "TRLFLD": {"offset": 12, "length": 4},
            }
        },
        "meta": {"base_registers": [{"reg": "R8", "target": "MYDSECT"}]},
    }
    r = _resolve(bp, "8(R8)", "SET", 30)
    assert r.named_deps == ["PAYFLD"]
    assert r.kind == "using"


def test_using_static_base_registers_fallback():
    # No active_usings line, but meta.base_registers declares R8→MYDSECT.
    bp = {
        "blocks": [_block("SET", [_flow(30, "MVC", None, "DEST")])],
        "dsect_layouts": {"MYDSECT": {"PAYFLD": {"offset": 0, "length": 4}}},
        "meta": {"base_registers": [{"reg": "R8", "target": "MYDSECT"}]},
    }
    r = _resolve(bp, "0(R8)", "SET", 30)
    assert r.named_deps == ["PAYFLD"] and r.kind == "using"


# --------------------------------------------------------------------------- #
# call-return: ENTRC defines R15 (return register), MVC dst,0(R15) → re-root marker
# --------------------------------------------------------------------------- #
def test_call_return_reroot():
    bp = {"blocks": [
        _block("ENTRY", [
            _flow(10, "ENTRC", ["SOMECALL"]),    # cross-file call; output in R15
            _flow(12, "B", ["SET"]),
        ]),
        _block("SET", [_flow(20, "MVC", None, "DEST")],
               incoming=[{"source": "ENTRY", "type": "BRANCH"}]),
    ]}
    r = _resolve(bp, "0(R15)", "SET", 20)
    assert r.kind == "implicit"
    assert any(n.startswith("call_return@R15") for n in r.named_deps)
    assert not any("'" in n for n in r.named_deps)


# --------------------------------------------------------------------------- #
# GIVE-UP: base register never defined in-file (caller-inherited) → envelope, no guess
# --------------------------------------------------------------------------- #
def test_give_up_caller_inherited_envelope():
    bp = {"blocks": [
        _block("SET", [_flow(20, "MVC", None, "DEST")]),   # R7 never loaded anywhere
    ]}
    r = _resolve(bp, "0(R7)", "SET", 20)
    assert r.named_deps == []                              # NO guessed field
    assert r.kind == "unresolved"
    assert r.unresolved_envelope is not None
    assert r.unresolved_envelope.get("indirect_via") == "R7"
    assert r.unresolved_envelope.get("is_indirect") is True


# --------------------------------------------------------------------------- #
# named prefix FIELD(Rn): the field is the dep directly
# --------------------------------------------------------------------------- #
def test_named_prefix_passthrough():
    bp = {"blocks": [_block("SET", [_flow(20, "MVC", None, "DEST")])]}
    r = _resolve(bp, "MYFIELD(R1)", "SET", 20)
    assert r.named_deps == ["MYFIELD"] and r.kind == "named_prefix"


# --------------------------------------------------------------------------- #
# Determinism + bounded: a J-loop self-mod chain must terminate and be stable.
# --------------------------------------------------------------------------- #
def test_loop_terminates_and_deterministic():
    bp = {"blocks": [
        _block("ENTRY", [
            _flow(10, "LA", ["R1", "LOOPBASE"]),
            _flow(12, "B", ["LOOP"]),
        ]),
        _block("LOOP", [
            _flow(20, "LA", ["R1", "4(R1)"]),     # self-mod bump
            _flow(22, "MVC", None, "DEST"),
            _flow(24, "J", ["LOOP"]),             # loops back to itself
        ], incoming=[
            {"source": "ENTRY", "type": "BRANCH"},
            {"source": "LOOP", "type": "BRANCH"},   # the J self-edge
        ]),
    ]}
    r1 = _resolve(bp, "0(R1)", "LOOP", 22)
    r2 = _resolve(bp, "0(R1)", "LOOP", 22)
    assert r1.named_deps == ["LOOPBASE"]
    assert r1.named_deps == r2.named_deps          # deterministic


# --------------------------------------------------------------------------- #
# Immediate load is terminal (constant) — no data dependency, no envelope.
# --------------------------------------------------------------------------- #
def test_immediate_load_terminal():
    bp = {"blocks": [
        _block("ENTRY", [
            _flow(10, "LGFI", ["R1", "X'1000'"]),   # constant address into R1
            _flow(12, "B", ["SET"]),
        ]),
        _block("SET", [_flow(20, "MVC", None, "DEST")],
               incoming=[{"source": "ENTRY", "type": "BRANCH"}]),
    ]}
    r = _resolve(bp, "0(R1)", "SET", 20)
    assert r.named_deps == []
    # terminal constant: a def WAS found, so we do NOT emit a give-up envelope.
    assert r.kind != "unresolved" or r.unresolved_envelope is None
