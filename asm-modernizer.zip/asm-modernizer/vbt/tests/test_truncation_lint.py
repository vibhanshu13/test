"""Truncation lint (vbt/precompute/truncation_lint.py).

Corpus-guarded: needs temp/asm to run Clang cfg_extract + tree-sitter. Verifies the
detector flags the known genuine truncation (processACreditTransaction, brace-mismatch),
classifies cause, and does NOT flag benign function-ends.
"""
from pathlib import Path

import pytest

from vbt.precompute.truncation_lint import detect_in_file, scan_dir

ASM = Path("temp/asm")

pytestmark = pytest.mark.skipif(not (ASM / "dw710000.cpp").exists(),
                                reason="temp/asm sources not present")


def test_flags_processACreditTransaction_as_brace_mismatch():
    found = detect_in_file(str(ASM / "dw710000.cpp"))
    by_name = {t.function: t for t in found}
    if "processACreditTransaction" not in by_name:
        pytest.skip("processACreditTransaction already brace-repaired in this corpus")
    t = by_name["processACreditTransaction"]
    assert t.cause == "brace-mismatch"
    assert t.cfg_max_line < t.true_end_line        # cfg stops well before the real end
    assert "switch_statement" in t.example_lost     # the gate-3 switch is what's lost
    assert t.lost_lines > 100


def test_benign_function_ends_not_flagged():
    # A function that simply ends (gap to next fn is comments/blanks) must NOT appear.
    found = {t.function for t in detect_in_file(str(ASM / "dw710000.cpp"))}
    # processCidInquiry is fully covered by the cfg — never a truncation.
    assert "processCidInquiry" not in found


def test_scan_dir_is_deterministic_and_classifies():
    out1 = scan_dir(ASM, parallel=False)
    out2 = scan_dir(ASM, parallel=False)
    assert [(t.file, t.function) for t in out1] == [(t.file, t.function) for t in out2]
    # every finding is one of the two causes, and reports a concrete lost construct
    assert all(t.cause in ("brace-mismatch", "unresolved-type") for t in out1)
    assert all("@" in t.example_lost for t in out1)
