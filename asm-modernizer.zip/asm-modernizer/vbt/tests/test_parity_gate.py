"""Pytest gate for the trace-parity harness (T0).

Skips cleanly when the pinned corpus or the captured goldens are absent, so it never breaks
CI on machines without the data. When both are present it asserts the FAST cases are
byte-identical to their goldens. The full curated set (incl. the slower depth-1 case) is run
via ``python -m vbt.tests.parity.check_parity`` at each step's acceptance gate, not here.

It also asserts determinism directly: a case run twice in-process is byte-identical.
"""
from __future__ import annotations

import pytest

from vbt.tests.parity import cases as P


pytestmark = pytest.mark.skipif(not P.corpus_available(),
                                reason="pinned parity corpus not present (see DB_PRECOMPUTE_PLAN.md §11)")


def _fast_cases():
    return [c for c in P.CASES if c.name in P.FAST_CASE_NAMES]


@pytest.mark.parametrize("case", _fast_cases(), ids=lambda c: c.name)
def test_fast_case_matches_golden(case):
    gp = P.golden_path(case.name)
    if not gp.is_file():
        pytest.skip(f"no golden captured for {case.name} "
                    f"(run: python -m vbt.tests.parity.capture_golden --fast)")
    canon, _raw, _secs = P.run_case(case)
    assert canon == gp.read_text(), (
        f"{case.name} diverged from golden — run "
        f"`python -m vbt.tests.parity.check_parity --only {case.name}` for the dossier"
    )


def test_lg1osi_is_deterministic():
    """Cheapest case run twice in-process must be byte-identical (determinism guard)."""
    case = next(c for c in P.CASES if c.name == "LG1OSI_asm")
    a, _, _ = P.run_case(case)
    b, _, _ = P.run_case(case)
    assert a == b, "LG1OSI trace is non-deterministic across in-process runs"
