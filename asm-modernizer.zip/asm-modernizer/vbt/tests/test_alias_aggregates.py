"""Aggregate <-> DSECT-group-label aliases from the STRUCTURAL mapping.

A C++ sub-struct (``}iso8583Field55;``) and an ASM explicit-length group header
(``LWRISB55 DS 0CL305``) are the same storage when their byte ranges coincide.
The alias must come from the offset+span mapping itself — NOT from the
aggregate's trailing ``//comment`` (which the cc parser drops on close-brace
lines and which may simply be absent).

Soundness (zero-false-negative contract): aliases only ADD setter searches;
a missing match falls back to today's behavior. The gates tested here keep a
fabricated bridge (which would wrongly MERGE identities) impossible:
  * both endpoints must agree (start offset AND byte length),
  * the aggregate must contain at least one comment-ANCHORED leaf,
  * spans are computed in .mac coordinate space (a stale gen revision's
    offsets must not drift them).
"""
from pathlib import Path

import pytest

from vbt.resolve import _find_cpp_chain as C
from vbt.resolve import name_resolver as NR

DS = Path(__file__).resolve().parents[2] / "datasource/alice/latest_sample_code_version_1/asm 6 1"


# --------------------------------------------------------------------------- #
# Synthetic unit: aggregate has NO comment — only the mapping can bridge it.
# --------------------------------------------------------------------------- #
MAC = """\
WRKAREA  DSECT
WRKHDR   DS   CL4
WRKGRP&A DS   0CL6
WRKF1&A  DS   CL2
WRKF2&A  DS   CL4
WRKTAIL  DS   CL3
"""

CC = """\
struct WorkArea {
    char header[4];        // WRKHDR
    struct {
        char f1[2];        // WRKF1
        char f2[4];        // WRKF2
    } grp;
    char tail[3];          // WRKTAIL
};
"""


def _write_unit(tmp_path, mac_text, cc_text):
    mac = tmp_path / "wrk.mac"
    cc = tmp_path / "ccwrk.hpp"
    mac.write_text(mac_text)
    cc.write_text(cc_text)
    return mac, cc


def test_aggregate_bridges_without_any_comment(tmp_path):
    """The aggregate's close-brace line carries no //comment at all; the
    offset+span identity alone produces the high-certainty alias."""
    mac, cc = _write_unit(tmp_path, MAC, CC)
    amap = C.build_alias_map_cc_only(str(mac), str(cc))
    ent = amap["by_cpp"].get("grp")
    assert ent and ent[0]["asm_name"] == "WRKGRP"
    assert ent[0]["certainty"] == "high" and ent[0]["via"] == "span"
    back = amap["by_asm"].get("WRKGRP")
    assert back and back[0]["cpp_path"] == "WorkArea.grp"
    # leaves unchanged
    assert amap["by_cpp"]["f1"][0]["asm_name"] == "WRKF1"


def test_span_mismatch_produces_no_alias(tmp_path):
    """Group declares 0CL8 but the cc aggregate covers 6 bytes — the two-point
    structural equality fails, so no alias is fabricated."""
    mac, cc = _write_unit(tmp_path, MAC.replace("0CL6", "0CL8"), CC)
    amap = C.build_alias_map_cc_only(str(mac), str(cc))
    assert "grp" not in amap["by_cpp"]
    assert "WRKGRP" not in amap["by_asm"]


def test_unanchored_aggregate_is_not_bridged(tmp_path):
    """No leaf comment anchors inside the aggregate -> its offsets are raw
    guesses -> the soundness gate refuses the bridge even if the raw numbers
    happen to line up."""
    cc_noanchors = CC.replace("// WRKF1", "").replace("// WRKF2", "")
    mac, cc = _write_unit(tmp_path, MAC, cc_noanchors)
    amap = C.build_alias_map_cc_only(str(mac), str(cc))
    assert "grp" not in amap["by_cpp"]
    # anchored siblings outside the aggregate still map normally
    assert amap["by_cpp"]["header"][0]["asm_name"] == "WRKHDR"


def test_parse_mac_captures_group_span():
    fields = {}
    mac = MAC
    import io as _io, tempfile, os
    with tempfile.NamedTemporaryFile("w", suffix=".mac", delete=False) as fh:
        fh.write(mac)
        p = fh.name
    try:
        parsed = C.parse_mac(p)
    finally:
        os.unlink(p)
    grp = next(f for f in parsed if f.get("group"))
    assert grp["name"] == "WRKGRP" and grp["span"] == 6 and grp["off"] == 4


# --------------------------------------------------------------------------- #
# Real corpus (lwris unit) — the shapes that motivated the change.
# --------------------------------------------------------------------------- #
needs_corpus = pytest.mark.skipif(not DS.exists(), reason="alice corpus not present")


@needs_corpus
def test_corpus_iso8583field55_bridges_to_lwrisb55():
    NR.clear_cache()
    r = NR.resolve("iso8583Field55", "cpp", DS)
    assert ("LWRISB55", "asm") in [(a.name, a.language) for a in r.aliases]
    back = NR.resolve("LWRISB55", "asm", DS)
    assert any(a.name.endswith("iso8583Field55") and a.language == "cpp"
               for a in back.aliases)


@needs_corpus
def test_corpus_nested_aggregates_bridge():
    NR.clear_cache()
    assert any(a.name == "LWRISB55EIAD"
               for a in NR.resolve("isExtendedIAD", "cpp", DS).aliases)
    assert any(a.name == "LWRISB55CVMI"
               for a in NR.resolve("isIADCVMInfo", "cpp", DS).aliases)


@needs_corpus
def test_corpus_leaf_aliases_unchanged():
    """The structural-aggregate pass must not disturb the leaf mapping."""
    NR.clear_cache()
    assert any(a.name == "LWRIS_7EIATA"
               for a in NR.resolve("iataNumber", "cpp", DS).aliases)
    assert any(a.name == "LWRISB55CVML"
               for a in NR.resolve("isIADCVMLen", "cpp", DS).aliases)
