"""FIFO cache eviction must be byte-identical (22k-OOM bounds).

The path-keyed, signature-validated memos in ``cpp_setters`` are FIFO-bounded so a 22k trace cannot
grow them without limit. Eviction is byte-identical *by construction* — every entry is a pure function
of (file, mtime/size), so a miss after eviction re-parses to the same value. But the local corpus never
reaches the production caps, so the normal suite (and parity) never exercises the eviction branch. This
test forces a tiny cap and asserts (a) the cache stays bounded and (b) re-computation after eviction is
byte-identical across repeated rounds — locking in the property the 22k bound relies on.
"""
from pathlib import Path

import pytest

import vbt.setters.cpp_setters as cs

_SRC = Path(__file__).resolve().parents[2] / "datasource/asm7_admin/asm 7_version_0/asm 5"


def _cpps(n=5):
    if not _SRC.is_dir():
        pytest.skip(f"corpus source dir absent: {_SRC}")
    files = sorted(_SRC.glob("*.cpp"))[:n]
    if len(files) < 3:
        pytest.skip("need >=3 cpp files to force eviction")
    return files


def _snap_writes(rows):
    from dataclasses import asdict
    return [(c, tuple(sorted(asdict(s).items())), getattr(s, "lhs_path", "")) for c, s in rows]


def _force_eviction_byte_identical(cache, cap_attr, fn, snap):
    """Baseline at default cap, then force cap=2 and assert bounded + byte-identical recompute x3."""
    files = _cpps()
    cache.clear()
    baseline = {p.name: snap(fn(p)) for p in files}
    cache.clear()
    old = getattr(cs, cap_attr)
    setattr(cs, cap_attr, 2)
    try:
        for _ in range(3):                       # repeated rounds → repeated evict+recompute
            for p in files:
                assert snap(fn(p)) == baseline[p.name], f"recompute differs for {p.name}"
                assert len(cache) <= 2, f"{cap_attr} cache exceeded cap: {len(cache)}"
    finally:
        setattr(cs, cap_attr, old)
        cache.clear()


def test_file_writes_cache_eviction_byte_identical():
    _force_eviction_byte_identical(
        cs._FILE_WRITES_CACHE, "_FILE_WRITES_CACHE_MAX", cs._file_writes, _snap_writes)


def test_file_returns_cache_eviction_byte_identical():
    _force_eviction_byte_identical(
        cs._FILE_RETURNS_CACHE, "_FILE_RETURNS_CACHE_MAX", cs._file_returns, lambda r: r)
