"""GAP 9 — "not-set" outcomes (``compute_cpp_not_set_conditions`` + engine wiring).

"V is not set" on a path is the LOGICAL COMPLEMENT of the reaching conditions the engine
already computes for V's setters:  ``not_set(F) = ¬(∨_S guard(S)) = ∧_S (∨_{L∈guard(S)} ¬L)``.
There is no per-construct logic and no taint heuristic — every shape (switch/if/loop/early
exit) falls out of the same negation. An UNCONDITIONAL setter ⇒ V always set ⇒ no not-set;
independent conditional setters negate independently (so two reconverging ones yield ``!c ∧ !d``).

Three layers:
  * PURE helpers (no compiler): negation parity, single-neg-eq detection, coalesce, and the
    dominance-based loop-necessity filter that distinguishes do-while (post-test) from while.
  * INTEGRATION through ``compute_cpp_not_set_conditions`` on compiled fixtures (one per shape).
  * WIRING: ``extract_dep_vars`` value-skip, the trace-cache signature, ``SetterSite`` fields.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from vbt.interfaces import Condition, Location, SetterSite
from vbt.conditions.cpp_conditions import (
    _negate_literal,
    _as_single_neg_eq,
    _coalesce_not_set,
    _necessary_guards,
    _cfg_dominators,
    compute_cpp_not_set_conditions,
    clear_cpp_conditions_cache,
)

_CFG_BIN = Path("vbt/cpp_frontend/cfg_extract")
_skip = pytest.mark.skipif(not _CFG_BIN.exists(), reason="clang cfg_extract binary not built")


# --------------------------------------------------------------------------- #
# Pure helpers — no compiler
# --------------------------------------------------------------------------- #
def test_negate_literal_parity():
    assert _negate_literal("e == A") == "!(e == A)"
    assert _negate_literal("!(rc != 0)") == "rc != 0"          # !(X) → X
    assert _negate_literal("e == A || e == B") == "!(e == A || e == B)"
    # double-negation collapses (via the shared _strip_outer_neg)
    assert _negate_literal("!(!(c))") == "!(c)"


def test_single_neg_eq_detection():
    assert _as_single_neg_eq("!(embossType == DbEmbossType::NewCard)") == (
        "embossType", "DbEmbossType::NewCard")
    assert _as_single_neg_eq("!(e == A || e == B)") is None      # disjunction → not single
    assert _as_single_neg_eq("!(e != A)") is None                # not an equality
    assert _as_single_neg_eq("e == A") is None                   # not negated


def _C(text):
    return Condition(order=0, condition=text, block_id="", location=Location("f.cpp", 1, 1),
                     polarity=None, kind="not_set")


def test_coalesce_same_scrutinee_merges():
    conj = [_C("!(e == A)"), _C("!(e == B)"), _C("!(e == C)")]
    out = _coalesce_not_set(conj, "f.cpp", "fn", 1)
    assert len(out) == 1
    assert out[0].condition == "!(e == A || e == B || e == C)"


def test_coalesce_leaves_mixed_alone():
    # one single-eq (mergeable) + one disjunction (left intact) + a different scrutinee
    conj = [_C("!(e == A)"), _C("!(e == B) || !(x)"), _C("!(g == 1)")]
    out = _coalesce_not_set(conj, "f.cpp", "fn", 1)
    texts = [c.condition for c in out]
    assert "!(e == A)" in texts                       # singleton scrut e (only one) stays !(e==A)
    assert "!(e == B) || !(x)" in texts               # compound disjunction untouched
    assert "!(g == 1)" in texts


# --- dominance-based loop necessity (do-while vs while), synthetic CFGs --------------------- #
def _b(bid, kind, succs, cond=None, lines=()):
    return {"id": bid, "terminator_kind": kind, "terminator_cond_expr": cond,
            "succs": [{"label": l, "block_id": t} for l, t in succs],
            "stmts": [{"line": ln} for ln in lines]}


def _loop_cond(kind):
    """kind='do' (post-test) vs 'while' (pre-test). Setter at line 4 inside the body block."""
    if kind == "do":
        # entry → body(4) → test(c) → (back to body | exit)
        return [
            _b(4, "none", [("unconditional", 1)], lines=[4]),       # entry == body (setter)
            _b(1, "do", [("true", 4), ("false", 0)], cond="c", lines=[5]),
            _b(0, "none", []),
        ]
    # while: entry/test(c) → (body(4) | exit); body → back to test
    return [
        _b(3, "while", [("true", 2), ("false", 0)], cond="c", lines=[2]),  # entry == test
        _b(2, "none", [("unconditional", 3)], lines=[4]),                   # body (setter)
        _b(0, "none", []),
    ]


def test_necessary_guards_drops_dowhile_loopcond():
    fn = {"cfg_blocks": _loop_cond("do")}
    g = [Condition(order=1, condition="c", block_id="", location=Location("f", 4, 4),
                   polarity=True, kind="loop")]
    # do-while body runs unconditionally → the loop cond is NOT necessary → dropped
    assert _necessary_guards(g, fn, 4) == []


def test_necessary_guards_keeps_while_loopcond():
    fn = {"cfg_blocks": _loop_cond("while")}
    g = [Condition(order=1, condition="c", block_id="", location=Location("f", 4, 4),
                   polarity=True, kind="loop")]
    # while test dominates the body → the loop cond IS necessary → kept
    kept = _necessary_guards(g, fn, 4)
    assert [c.condition for c in kept] == ["c"]


# --------------------------------------------------------------------------- #
# Integration — one compiled fixture, every shape is its own function
# --------------------------------------------------------------------------- #
_SRC = """\
namespace E { enum T { NewCard, Renewal, Emergency, Rep, Other }; }
struct S { int v; };

void named_switch(S& s, E::T e) {
    switch (e) {
        case E::NewCard:   s.v = 1; break;
        case E::Renewal:   s.v = 2; break;
        case E::Emergency: s.v = 3; break;
        case E::Rep:       s.v = 4; break;
        default: break;
    }
}

void missing_else(S& s, int c) {
    if (c)
        s.v = 1;
}

void missing_else_then_set(S& s, int c) {
    if (c)
        s.v = 1;
    s.v = 9;
}

void cond_in_case(S& s, int e, int x) {
    switch (e) {
        case 1:
            s.v = 1;
            break;
        case 2:
            if (x)
                s.v = 2;
            break;
        default: break;
    }
}

void fallthrough(S& s, int e) {
    switch (e) {
        case 1:
        case 2:
            s.v = 1;
            break;
        default: break;
    }
}

void early_return(S& s, int c) {
    if (c)
        return;
    s.v = 1;
}

void do_while(S& s, int c) {
    do {
        s.v = 1;
    } while (c);
}

void while_loop(S& s, int c) {
    while (c) {
        s.v = 1;
    }
}

void two_reconverging(S& s, int c, int d) {
    if (c)
        s.v = 1;
    if (d)
        s.v = 2;
}

void unconditional(S& s) {
    s.v = 7;
}

void nested(S& s, int a, int b) {
    if (a) {
        if (b)
            s.v = 1;
    }
}

void if_else_both_set(S& s, int c) {
    if (c)
        s.v = 1;
    else
        s.v = 2;
}
"""


def _lines_of(src: str, needle: str):
    return [i for i, ln in enumerate(src.splitlines(), start=1) if needle in ln]


@pytest.fixture(scope="module")
def fixture(tmp_path_factory):
    if not _CFG_BIN.exists():
        pytest.skip("clang cfg_extract binary not built")
    from vbt.cpp_frontend.wrapper import run_cfg_extract
    clear_cpp_conditions_cache()
    p = tmp_path_factory.mktemp("notset") / "shapes.cpp"
    p.write_text(_SRC)
    fns = run_cfg_extract(str(p))
    return p, fns


def _notset(fixture, fn_name, needle="s.v ="):
    p, fns = fixture
    # the real setter lines of V in fn_name: all `s.v =` lines within the function's span.
    from vbt.conditions.cpp_conditions import _select_function, _fn_line_span
    all_lines = _lines_of(_SRC, needle)
    f = next(f for f in fns if (f.get("function") or "").endswith(fn_name))
    lo, hi = _fn_line_span(f)
    lines = [ln for ln in all_lines if lo <= ln <= hi]
    return compute_cpp_not_set_conditions(str(p), fn_name, lines, functions=fns)


@_skip
def test_named_switch(fixture):
    conds, status = _notset(fixture, "named_switch")
    assert status == "ok"
    assert len(conds) == 1
    assert conds[0].condition == (
        "!(e == E::NewCard || e == E::Renewal || e == E::Emergency || e == E::Rep)")


@_skip
def test_missing_else(fixture):
    conds, status = _notset(fixture, "missing_else")
    assert status == "ok"
    assert [c.condition for c in conds] == ["!(c)"]


@_skip
def test_missing_else_then_set_is_unconditional(fixture):
    # the trailing unconditional s.v = 9 means V is ALWAYS set → no not-set outcome
    conds, status = _notset(fixture, "missing_else_then_set")
    assert status == "unconditional"
    assert conds == []


@_skip
def test_cond_in_case(fixture):
    conds, status = _notset(fixture, "cond_in_case")
    assert status == "ok"
    texts = [c.condition for c in conds]
    assert "!(e == 1)" in texts                  # case 1 sets unconditionally
    assert any("!(e == 2)" in t and "!(x)" in t for t in texts)   # case 2 sets only when x


@_skip
def test_fallthrough(fixture):
    conds, status = _notset(fixture, "fallthrough")
    assert status == "ok"
    # both fall-through labels reach the setter → both negated
    assert conds[0].condition == "!(e == 1 || e == 2)"


@_skip
def test_early_return(fixture):
    conds, status = _notset(fixture, "early_return")
    assert status == "ok"
    # not set exactly when we returned early: c
    assert [c.condition for c in conds] == ["c"]


@_skip
def test_do_while_no_not_set(fixture):
    # the body runs unconditionally (post-test loop) → V always set → NO not-set, NO false !(c)
    conds, status = _notset(fixture, "do_while")
    assert status == "unconditional"
    assert conds == []


@_skip
def test_while_loop_emits(fixture):
    conds, status = _notset(fixture, "while_loop")
    assert status == "ok"
    assert [c.condition for c in conds] == ["!(c)"]   # loop ran zero times


@_skip
def test_two_reconverging(fixture):
    # the case v3's CFG-departure approach lost: not set = !c && !d
    conds, status = _notset(fixture, "two_reconverging")
    assert status == "ok"
    assert sorted(c.condition for c in conds) == ["!(c)", "!(d)"]


@_skip
def test_unconditional_no_not_set(fixture):
    conds, status = _notset(fixture, "unconditional")
    assert status == "unconditional"
    assert conds == []


@_skip
def test_if_else_both_set_is_tautology(fixture):
    # both arms set V (guards c and !c) → union is a tautology → V always set → NO not-set.
    # This is the dw780100-class shape: two setters guarded by exact negations must NOT
    # produce a contradictory `c ∧ !c` entry.
    conds, status = _notset(fixture, "if_else_both_set")
    assert status == "tautology"
    assert conds == []


@_skip
def test_nested(fixture):
    conds, status = _notset(fixture, "nested")
    assert status == "ok"
    # not set = !(a && b) = !a || !b — surfaced as one conjunct (single setter, guard [a,b])
    assert len(conds) == 1
    assert conds[0].condition == "!(a) || !(b)"


# --------------------------------------------------------------------------- #
# Wiring — extract_dep_vars value-skip, SetterSite fields, cache signature
# --------------------------------------------------------------------------- #
def test_extract_dep_vars_skips_notset_value_keeps_condition_operands():
    from vbt.depvars.extract import extract_dep_vars
    s = SetterSite(variable="cardUseIndicator", file_stem="bp", language="cpp",
                   line=10, instruction="not_set", block_id="setUse", function="setUse",
                   value="[not set]", is_not_set=True)
    cond = Condition(order=1, condition="!(embossType == E::NewCard || embossType == E::Rep)",
                     block_id="", location=Location("bp.cpp", 10, 10), polarity=None, kind="not_set")
    refs = extract_dep_vars(s, [cond])
    names = {r.name for r in refs}
    assert "not" not in names and "set" not in names        # no junk from "[not set]"
    assert any("embossType" in n for n in names)            # the scrutinee IS harvested


def test_setter_site_defaults():
    s = SetterSite(variable="v", file_stem="bp", language="cpp", line=1,
                   instruction="assign", block_id="fn")
    assert s.preset_conditions is None and s.is_not_set is False


def test_setter_stats_excludes_not_set_and_tolerates():
    """Consumer tolerance (plan §9): setter_stats must not crash on a not-set entry and must
    exclude it from the real-setter counts (tracking the removal in meta, never silent)."""
    from api.tasks.setter_stats import compute_stats
    inp = {"variables": {"v": [
        {"file_stem": "a", "function": "f", "line": 1, "value": "X"},
        {"file_stem": "a", "function": "f", "line": 2, "value": "Y"},
        {"function": "f", "line": 3, "value": "[not set]", "isNotSet": True},
    ]}}
    st = compute_stats(inp)
    assert st["meta"].get("not_set_excluded") == {"v": 1}
    pv = st["per_variable"]["v"]
    assert pv["reachable_setters_count"] == 2 and pv["raw_setter_count"] == 2


# --------------------------------------------------------------------------- #
# Extensions — ASM not-set + shared builder (dep-var path)
# --------------------------------------------------------------------------- #
def test_negate_asm_literal_native_flip_and_fallback():
    from vbt.conditions.asm_conditions import _negate_asm_literal, _resolve_predicate
    orig = _resolve_predicate("TM @CASVIS1,X'01'", "JNO LBL", taken=True)   # (f & m) != m
    c = Condition(order=1, condition=orig, block_id="B", location=Location("aa71.asm", 10, 10),
                  polarity=True, raw_test="TM @CASVIS1,X'01'", raw_branch="JNO LBL", kind="asm_guard")
    assert _negate_asm_literal(c) != orig                       # native flip == ↔ !=
    assert "==" in _negate_asm_literal(c)
    c2 = Condition(order=1, condition="SOMECOND", block_id="B", location=Location("x", 1, 1),
                   polarity=None)                                # no raw_test → text-wrap fallback
    assert _negate_asm_literal(c2) == "!(SOMECOND)"


def _asm_setter(stem, block, line):
    return SetterSite(variable="v", file_stem=stem, language="asm", line=line,
                      instruction="ST", block_id=block)


def test_compute_asm_not_set_status_logic(monkeypatch):
    """The orchestration (negate→OR→dedup, unconditional/truncated/tautology gates) without a
    real blueprint: monkeypatch collect_asm_conditions to return canned guards per (block,line)."""
    import vbt.conditions.asm_conditions as A

    def g(test, branch, taken):
        p = A._resolve_predicate(test, branch, taken=taken)
        return Condition(order=1, condition=p, block_id="B", location=Location("m.asm", 1, 1),
                         polarity=taken, raw_test=test, raw_branch=branch, kind="asm_guard")

    table = {}   # (block, line) -> (conds, truncated)

    def fake_collect(bp, bpp, block_id, before_line, file, *, max_levels=16):
        return table.get((block_id, before_line), ([], False))
    monkeypatch.setattr(A, "collect_asm_conditions", fake_collect)

    # ok: one guarded setter → one negated conjunct
    table.clear(); table[("B1", 10)] = ([g("TM F,X'01'", "JO L", taken=True)], False)
    conds, st = A.compute_asm_not_set_conditions({}, "m.json", "m.asm", [_asm_setter("m", "B1", 10)])
    assert st == "ok" and len(conds) == 1 and "!=" in conds[0].condition

    # unconditional: a setter with no guards ⇒ V always set ⇒ no not-set
    table.clear(); table[("B1", 10)] = ([], False)
    assert A.compute_asm_not_set_conditions({}, "m.json", "m.asm", [_asm_setter("m", "B1", 10)])[1] == "unconditional"

    # truncated guard ⇒ suppressed
    table.clear(); table[("B1", 10)] = ([g("TM F,X'01'", "JO L", taken=True)], True)
    assert A.compute_asm_not_set_conditions({}, "m.json", "m.asm", [_asm_setter("m", "B1", 10)])[1] == "incomplete"

    # tautology: same compare reached under both polarities ⇒ suppressed
    table.clear()
    table[("B1", 10)] = ([g("TM F,X'01'", "JO L", taken=True)], False)
    table[("B2", 20)] = ([g("TM F,X'01'", "JO L", taken=False)], False)
    assert A.compute_asm_not_set_conditions(
        {}, "m.json", "m.asm", [_asm_setter("m", "B1", 10), _asm_setter("m", "B2", 20)])[1] == "tautology"


@_skip
def test_build_not_set_setters_cpp_grouping(fixture):
    """The shared builder (used by both root engine and dep-var recursion) groups cpp setters by
    (stem, fn) and yields one is_not_set SetterSite with preset_conditions."""
    from vbt.conditions.not_set_builder import build_not_set_setters
    p, fns = fixture
    stem = p.stem
    lines = _lines_of(_SRC, "s.v =")
    f = next(f for f in fns if (f.get("function") or "").endswith("named_switch"))
    from vbt.conditions.cpp_conditions import _fn_line_span
    lo, hi = _fn_line_span(f)
    sw_lines = [ln for ln in lines if lo <= ln <= hi]
    reals = [SetterSite(variable="cardUseIndicator", file_stem=stem, language="cpp",
                        line=ln, instruction="assign", block_id="named_switch", function="named_switch")
             for ln in sw_lines]
    virt = build_not_set_setters(reals, asm_dir=p.parent, get_cpp_fns=lambda st: fns)
    assert len(virt) == 1
    v = virt[0]
    assert v.is_not_set and v.value == "[not set]" and v.preset_conditions
    assert v.preset_conditions[0].condition.startswith("!(e == E::NewCard")


def test_trace_cache_signature_includes_emit_not_set():
    from vbt.precompute import trace_cache as TC
    kw = dict(candidate_stems=None, candidate_functions=None, home_hint=None,
              disable_dependents=False, max_dep_var_depth=1, max_paths=64, max_call_depth=16,
              max_routes=200, max_route_len=16, max_offchain_files=100, asm_max_levels=16)
    a = TC.signature("v", "cpp", [], Path("/bp"), Path("/asm"), Path("/g"), emit_not_set=True, **kw)
    b = TC.signature("v", "cpp", [], Path("/bp"), Path("/asm"), Path("/g"), emit_not_set=False, **kw)
    assert a != b                                            # the flag changes the cache key
