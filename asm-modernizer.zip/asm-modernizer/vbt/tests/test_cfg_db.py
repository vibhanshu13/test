"""T8: DB-backed cfg cache — lossless round-trip + the run_cfg_extract GET/PUT hooks.

The full-trace byte-identical proof (cold populates vbt_cfg_blob → warm serves from it) lives
in the parity gate.
"""
from __future__ import annotations

import pytest

from vbt.cpp_frontend import wrapper as W
from vbt.precompute import db_artifacts as DA
from vbt.tests.parity import cases as P

pytestmark = pytest.mark.skipif(not P.corpus_available(),
                                reason="pinned corpus absent (see DB_PRECOMPUTE_PLAN.md §11)")


def test_cfg_gz_roundtrip_lossless():
    base = W.run_cfg_extract(str(P.ASM_DIR / "dw710000.cpp"))
    assert len(base) > 0
    assert DA.loads_gz(DA.dumps_gz(base)) == base


def test_cfg_db_hooks_serve_identical():
    p = str(P.ASM_DIR / "dw730000.cpp")
    base = W.run_cfg_extract(p)
    store: dict = {}

    def put(k, f):
        store[k] = DA.dumps_gz(f)

    def get(k):
        b = store.get(k)
        return DA.loads_gz(b) if b is not None else None

    try:
        W._MEMO.clear()
        W.set_cfg_db_hooks(get, put)
        first = W.run_cfg_extract(p)        # disk/subprocess + PUT populates store
        assert first == base and len(store) >= 1
        W._MEMO.clear()
        second = W.run_cfg_extract(p)        # served (DB or disk) — identical either way
        assert second == base
    finally:
        W.clear_cfg_db_hooks()
        W._MEMO.clear()
