"""bridge_sites precompute: bridge-verified call-site map per callee.

The uncached caller-forest build ("find_routes: building caller forest ... (uncached, BFS)")
bridge-verifies every reverse-adjacency edge by loading the CALLER's blueprint from disk — at
22k scale a hub callee's cone is thousands of multi-MB json.loads per route query. The bridge
output is corpus-pure (independent of variable/chain/parent), so it is precomputed per KB and
served to the walkers through the ``_pfl_cache["_bridge_sites_loader"]`` hook.

Proof obligations here:
  * build → loader roundtrip through the DB blob preserves sites exactly (incl. EMPTY lists —
    a bridged-but-siteless pair must be a cache HIT that still yields the unverified node);
  * ``walk_callers_bfs`` with the loader produces the IDENTICAL CallerNode forest as the live
    bridge path, with ZERO live bridge calls;
  * a pair absent from the blob falls back to the live bridge (never a silent drop);
  * the loader serves only in load-only mode (build/verify traces keep scanning live).
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[2]))

import pytest
from sqlalchemy import create_engine

from api.index_db.schema import metadata
from vbt.precompute import db_artifacts as DA
from vbt.precompute import bridge_sites_db as BS
from backward_traversal.runner import chainless_caller_walker as CW


# --------------------------------------------------------------------------- #
# Synthetic corpus: top -> mid -> child, leaf -> child; leaf's bridge finds no
# sites (unverified-indirection case).
# --------------------------------------------------------------------------- #
REVERSE_ADJ = {
    "CHILD": [("mid", "ENTRC"), ("leaf", "ENTRC")],
    "MID": [("top", "ENTRC")],
}
NODE_TYPE = {"child": "asm", "mid": "asm", "leaf": "asm", "top": "asm"}


def _fake_sites(src: str, callee: str):
    if src == "leaf":
        return []                                # bridged, but no verifiable site
    return [{"routine": f"R_{src}", "line": 7, "instruction": "ENTRC",
             "call_type": None, "raw_line": f"{src} ENTRC {callee}"}]


class _CountingBridge:
    def __init__(self):
        self.calls = []

    def __call__(self, src, callee, blueprint_dir, asm_dir=None):
        self.calls.append((src, callee))
        return _fake_sites(src, callee)


class _FakeRoute:
    def __init__(self):
        self._reverse_adj = REVERSE_ADJ
        self._node_type = NODE_TYPE

    def _ensure_graph(self):
        pass


def _engine(tmp_path):
    eng = create_engine(f"sqlite:///{tmp_path / 'index.db'}")
    metadata.create_all(eng)
    return eng


@pytest.fixture()
def db(tmp_path, monkeypatch):
    eng = _engine(tmp_path)
    import api.index_db.engine as _E
    monkeypatch.setattr(_E, "get_engine", lambda job_id: eng, raising=False)
    return eng


def _node_key(n):
    return (n.stem, n.file_type, n.callee_stem, n.edge_kind, n.depth, n.cycle,
            n.call_sites, getattr(n.indirection, "unresolved", None) if n.indirection else None)


def _walk(bp_dir, pfl):
    return CW.walk_callers_bfs(
        "child", "asm", bp_dir, None, REVERSE_ADJ, NODE_TYPE,
        max_caller_depth=5, attach_conditions=False, _pfl_cache=pfl)


def test_build_loader_roundtrip_and_walk_parity(db, tmp_path, monkeypatch):
    bridge = _CountingBridge()
    monkeypatch.setattr(CW, "_bridge_for", lambda st, ct: bridge)

    n = BS.build_and_store_bridge_sites("j", tmp_path, tmp_path, _FakeRoute())
    assert n == 2                                # child + mid have callers; top/leaf don't
    built_pairs = set(bridge.calls)
    assert built_pairs == {("mid", "child"), ("leaf", "child"), ("top", "mid")}

    # Live walk (no loader) — the golden forest.
    live_bridge = _CountingBridge()
    monkeypatch.setattr(CW, "_bridge_for", lambda st, ct: live_bridge)
    golden = _walk(tmp_path, {})
    assert live_bridge.calls                     # live path really bridged
    # leaf's empty sites surfaced as an unresolved-indirection node, not dropped
    assert any(nd.stem == "leaf" and nd.indirection and nd.indirection.unresolved
               for nd in golden)

    # Preloaded walk: loader serves every pair; a live bridge call is a test failure.
    monkeypatch.setattr(DA, "is_load_only", lambda: True)

    def _boom(src, callee, blueprint_dir, asm_dir=None):
        raise AssertionError(f"live bridge called for ({src}, {callee}) despite preload")

    monkeypatch.setattr(CW, "_bridge_for", lambda st, ct: _boom)
    loader = BS.make_bridge_sites_loader("j")
    preloaded = _walk(tmp_path, {"_bridge_sites_loader": loader})

    assert [_node_key(nd) for nd in preloaded] == [_node_key(nd) for nd in golden]


def test_pair_missing_from_blob_falls_back_to_live_bridge(db, tmp_path, monkeypatch):
    # Blob for "child" covers only mid — leaf must be bridged live (correctness over speed).
    DA.write_blob("j", "bridge_sites:child",
                  DA.dumps_gz({"mid": _fake_sites("mid", "child")}))
    monkeypatch.setattr(DA, "is_load_only", lambda: True)
    live = _CountingBridge()
    monkeypatch.setattr(CW, "_bridge_for", lambda st, ct: live)
    loader = BS.make_bridge_sites_loader("j")
    nodes = _walk(tmp_path, {"_bridge_sites_loader": loader})
    assert ("mid", "child") not in live.calls    # served from the blob
    assert ("leaf", "child") in live.calls       # blob miss -> live
    assert {nd.stem for nd in nodes} >= {"mid", "leaf"}


def test_loader_inert_outside_load_only(db, monkeypatch):
    DA.write_blob("j", "bridge_sites:child", DA.dumps_gz({"mid": []}))
    monkeypatch.setattr(DA, "is_load_only", lambda: False)
    loader = BS.make_bridge_sites_loader("j")
    assert loader("child", "asm") is None        # build/verify mode: always live
    assert BS.make_bridge_sites_loader(None) is None


def test_loader_case_normalizes_callee_stem(db, monkeypatch):
    DA.write_blob("j", "bridge_sites:child", DA.dumps_gz({"mid": [{"line": 1}]}))
    monkeypatch.setattr(DA, "is_load_only", lambda: True)
    loader = BS.make_bridge_sites_loader("j")
    assert loader("CHILD", "asm") == {"mid": [{"line": 1}]}
