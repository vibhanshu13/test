"""GAP 5: empty synthetic path-family ANCESTOR hygiene at the root-trace boundary.

Pure unit tests for ``vbt.engine._filter_empty_path_family_ancestors`` — the
output-only cleanup that removes empty container-ancestor helper nodes from a root
trace's ``dependentVariables`` while keeping every node that carries real evidence
or a diagnostic flag. Baseline-INDEPENDENT (no corpus needed): drives the helper
directly with hand-built ``{"dependentVariable": {...}}`` fixtures. The compute-layer
contract (that ``trace_dependents`` still EMITS + links these ancestors) is covered
by test_depvar_pathfamily.py and is intentionally NOT touched here.

    env/bin/python3 -m pytest vbt/tests/test_pathfamily_filter.py -q
"""
from vbt.engine import _filter_empty_path_family_ancestors, _PATH_FAMILY_KEEP_FLAGS


def _node(name, qualified=None, *, origin=None, terminal=True, setters=None,
          path_parents=None, path_children=None, **flags):
    dv = {"name": name, "terminal": terminal, "setters": list(setters or [])}
    if qualified is not None:
        dv["qualified"] = qualified
    if origin is not None:
        dv["origin"] = origin
    if path_parents is not None:
        dv["pathParents"] = list(path_parents)
    if path_children is not None:
        dv["pathChildren"] = list(path_children)
    dv.update(flags)
    return {"dependentVariable": dv}


def _names(objs):
    return [o["dependentVariable"]["name"] for o in objs]


def _by_name(objs):
    return {o["dependentVariable"]["name"]: o["dependentVariable"] for o in objs}


def test_drops_only_empty_synthetic_ancestors_and_keeps_the_rest():
    """The canonical fixture from gap_5_analysis.md §7: a primary leaf, two empty
    ancestors (removed), a descendant (kept), a real aggregate ancestor (kept), and a
    primary terminal container with no origin (kept)."""
    dep_objs = [
        # primary leaf — terminal, no setters, but origin != ancestor → KEEP
        _node("month", "obj.rec.month", terminal=True, path_parents=["obj.rec"]),
        # empty helper ancestors — REMOVE both
        _node("rec", "obj.rec", origin="ancestor", terminal=True,
              path_parents=["obj"], path_children=["obj.rec.month"]),
        _node("obj", "obj", origin="ancestor", terminal=True,
              path_children=["obj.rec"]),
        # concrete sub-field write — descendant → KEEP
        _node("digit1", "obj.rec.month.digit1", origin="descendant", terminal=False,
              setters=[{"setterId": 1, "value": "1"}], path_parents=["obj.rec.month"]),
        # aggregate ancestor WITH a setter (memcpy) → KEEP
        _node("realParent", "obj.realParent", origin="ancestor", terminal=False,
              setters=[{"setterId": 1, "value": "src"}],
              path_children=["obj.realParent.field"]),
        # primary terminal container, no origin at all → KEEP
        _node("standaloneContainer", "lone.container", terminal=True),
    ]
    out = _filter_empty_path_family_ancestors(dep_objs)

    names = _names(out)
    # the two empty ancestors are gone...
    assert "rec" not in names and "obj" not in names
    # ...everything else survives, in the original relative order.
    assert names == ["month", "digit1", "realParent", "standaloneContainer"]

    nodes = _by_name(out)
    # link repair: the leaf's only parent (obj.rec) was removed → field dropped entirely.
    assert "pathParents" not in nodes["month"]
    # the surviving descendant's parent (obj.rec.month) was NOT removed → kept intact.
    assert nodes["digit1"]["pathParents"] == ["obj.rec.month"]
    # the aggregate ancestor's child link is untouched.
    assert nodes["realParent"]["pathChildren"] == ["obj.realParent.field"]


def test_partial_link_repair_keeps_surviving_targets():
    """A survivor whose link list references BOTH a removed and a kept path keeps only
    the kept one (the field is pruned, not dropped)."""
    dep_objs = [
        # leaf links to two parents: obj.rec (removed) and keptParent (kept, has setter)
        _node("month", "obj.rec.month", terminal=True,
              path_parents=["obj.rec", "obj.keptParent"]),
        _node("rec", "obj.rec", origin="ancestor", terminal=True,
              path_children=["obj.rec.month"], path_parents=["obj.keptParent"]),
        _node("keptParent", "obj.keptParent", origin="ancestor", terminal=False,
              setters=[{"setterId": 1, "value": "x"}],
              path_children=["obj.rec", "obj.rec.month"]),
    ]
    out = _filter_empty_path_family_ancestors(dep_objs)
    nodes = _by_name(out)
    assert "rec" not in nodes
    # leaf keeps only the surviving parent
    assert nodes["month"]["pathParents"] == ["obj.keptParent"]
    # the kept ancestor's child list drops the removed path, keeps the rest
    assert nodes["keptParent"]["pathChildren"] == ["obj.rec.month"]


def test_diagnostic_and_alias_ancestors_are_kept():
    """An empty ancestor that carries a cap/fallback/diagnostic flag (or aliases) must
    NOT be suppressed — the truncation/fallback has to stay visible."""
    base = dict(origin="ancestor", terminal=True, path_children=["a.b.c"])
    flagged = []
    # one ancestor per keep-flag, each referenced as a link
    for i, flag in enumerate(_PATH_FAMILY_KEEP_FLAGS):
        flagged.append(_node(f"anc{i}", f"a.flag{i}", **{**base, flag: True,
                                                          "path_children": [f"a.flag{i}.x"]}))
    # plus an alias-carrying ancestor
    alias_anc = _node("aliased", "a.aliased", **base)
    alias_anc["dependentVariable"]["aliases"] = [{"name": "OTHER", "language": "asm"}]
    # and a node that REFERENCES every flagged qual so they are all "linked"
    referencer = _node("ref", "a", origin="primary", terminal=False,
                       setters=[{"setterId": 1, "value": "0"}],
                       path_children=[f"a.flag{i}" for i in range(len(_PATH_FAMILY_KEEP_FLAGS))]
                                     + ["a.aliased"])
    dep_objs = flagged + [alias_anc, referencer]

    out = _filter_empty_path_family_ancestors(dep_objs)
    # nothing was dropped — every flagged/aliased ancestor survives.
    assert len(out) == len(dep_objs)
    assert _names(out) == _names(dep_objs)


def test_unlinked_ancestor_is_not_removed():
    """Safety gate: a node tagged origin=ancestor whose qualified is NOT referenced by
    any path-family link is left alone (only genuine helper nodes are removable)."""
    dep_objs = [
        _node("orphan", "x.y", origin="ancestor", terminal=True),   # not referenced anywhere
    ]
    out = _filter_empty_path_family_ancestors(dep_objs)
    assert out is dep_objs                       # nothing removable → original returned unchanged
    assert _names(out) == ["orphan"]


def test_noop_returns_original_object_when_nothing_removable():
    dep_objs = [
        _node("a", "x.a", terminal=True),                              # primary, no origin
        _node("b", "x.b", origin="descendant", terminal=False,
              setters=[{"setterId": 1, "value": "1"}]),                # descendant w/ setter
    ]
    out = _filter_empty_path_family_ancestors(dep_objs)
    assert out is dep_objs                       # identity: untouched fast path
    assert [] == [] and len(out) == 2


def test_empty_input_returns_input():
    assert _filter_empty_path_family_ancestors([]) == []


def test_chain_of_empty_ancestors_all_removed():
    """a.b.c (primary terminal leaf, kept) over a chain of empty ancestors a.b, a —
    both ancestors removed, leaf survives with its now-empty parent link dropped."""
    dep_objs = [
        _node("c", "a.b.c", terminal=True, path_parents=["a.b"]),
        _node("b", "a.b", origin="ancestor", terminal=True,
              path_parents=["a"], path_children=["a.b.c"]),
        _node("a", "a", origin="ancestor", terminal=True, path_children=["a.b"]),
    ]
    out = _filter_empty_path_family_ancestors(dep_objs)
    assert _names(out) == ["c"]
    assert "pathParents" not in out[0]["dependentVariable"]
