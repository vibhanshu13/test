"""Function-output dependent-variable terminal handling (noise reduction).

A function-output dep that yields no return/by-ref output is classified STRUCTURALLY
via the modifier index (no hardcoded name list):

  * defined NOWHERE in the corpus  -> ``externalCall`` (stdlib / z/TPF intrinsic /
    not ingested) -- e.g. atoi, tpf_STCK, ecbptr;
  * defined somewhere but no body recovered -> ``functionBodyUnresolved``.

Both are kept + terminal (surfaced, never silently dropped) and never recursed.
Baseline-independent (no jobs/baseline-temp-asm needed) via the monkeypatched
``trace_dependents`` collaborators.
"""
from vbt.depvars.extract import DepVarRef


def _run(monkeypatch, tmp_path, *, defining_files):
    """Run trace_dependents on one function-output dep, stubbing the modifier index
    so ``files_defining_function`` returns ``defining_files`` (drives the structural
    external-vs-unresolved decision). No file is created on disk, so
    ``_function_return_setters`` recovers no returns -> the terminal path is taken."""
    import vbt.depvars.recurse as R
    from vbt.depvars.recurse import trace_dependents

    class _Idx:
        def files_for(self, name, language): return set()
        def files_defining_function(self, fn): return set(defining_files)
        def sites_for(self, *a, **k): return []

    monkeypatch.setattr(R, "get_modifier_index", lambda *a, **k: _Idx())
    dep = DepVarRef(name="someFn", language="cpp", relationship="function_output",
                    is_function_output=True,
                    found_at={"file": "caller.cpp", "startLine": 10, "endLine": 10})
    out = trace_dependents([("root", dep)], ["caller"],
                           blueprint_dir=tmp_path, asm_dir=tmp_path, store=None)
    assert len(out) == 1
    return out[0]["dependentVariable"]


def test_no_corpus_definition_flagged_external(monkeypatch, tmp_path):
    # files_defining_function -> empty: defined nowhere -> external call.
    dv = _run(monkeypatch, tmp_path, defining_files=set())
    assert dv["is_function_output"] is True
    assert dv["terminal"] is True
    assert dv.get("externalCall") is True
    assert "functionBodyUnresolved" not in dv          # mutually exclusive
    assert dv["setters"] == []


def test_defined_but_body_unresolved_flagged_unresolved(monkeypatch, tmp_path):
    # files_defining_function -> a stem, but no .cpp on disk -> no returns recovered
    # -> defined-but-unresolvable (NOT external).
    dv = _run(monkeypatch, tmp_path, defining_files={"someotherfile"})
    assert dv["terminal"] is True
    assert dv.get("functionBodyUnresolved") is True
    assert "externalCall" not in dv                    # mutually exclusive
    assert dv["setters"] == []
