"""GAP 1 — unit tests for ``vbt.precompute.guard_decompose``.

The decomposer turns a compound C/C++ guard predicate into the SIMPLE value-guard facts the
feasibility decider can reason about, performing ONLY the two sound boolean rewrites:
top-level conjunction flattening and a homogeneous-equality disjunction on one scrutinee.
Anything else emits nothing. Constants here are chosen to match what ``parse_required_guard``
actually accepts (enum members need ``::``; ints/hex/char/ASM-char literals are constants;
a bare identifier is NOT).
"""
from __future__ import annotations

import pytest

from vbt.precompute.guard_decompose import (
    MAX_DECOMPOSED_GUARDS_PER_CONDITION,
    MAX_EXPR_CHARS_FOR_DECOMPOSITION,
    decompose_value_guards,
    decompose_value_guards_diag,
    _split_top_level,
)


def _triples(facts):
    """Project facts to a set of (scrutinee, const, op) for order-insensitive assertions."""
    return {(f["scrutinee"], f["const"], f["op"]) for f in facts}


# --------------------------------------------------------------------------- #
# 1–3: simple guards and a top-level conjunction
# --------------------------------------------------------------------------- #
def test_simple_eq():
    facts = decompose_value_guards("x == Foo::A")
    assert facts == [
        {"text": "x == Foo::A", "scrutinee": "x", "const": "Foo::A", "op": "eq"}
    ]


def test_simple_ne():
    facts = decompose_value_guards("x != Foo::A")
    assert facts == [
        {"text": "x != Foo::A", "scrutinee": "x", "const": "Foo::A", "op": "ne"}
    ]


def test_top_level_conjunction_two_facts():
    facts = decompose_value_guards("x == Foo::A && y == Bar::B")
    assert len(facts) == 2
    assert _triples(facts) == {("x", "Foo::A", "eq"), ("y", "Bar::B", "eq")}


# --------------------------------------------------------------------------- #
# 4: the CID gate — exactly 6 facts (1 ne on rc + 5 eq on tc)
# --------------------------------------------------------------------------- #
_RC = "lwrCommon.process.cid.cidioReturnCode"
_TC = "lwrCommon.process.links.transactionCode"
_CID_GATE = (
    "({rc} != CidioReturn::NoCidRecord)"
    " && (({tc} == CasTransactionCode::CreditRequest)"
    " || ({tc} == CasTransactionCode::WorkedFromReferralQue)"
    " || ({tc} == CasTransactionCode::ForceEntryToRefer)"
    " || ({tc} == CasTransactionCode::ForceEntryToAA)"
    " || ({tc} == CasTransactionCode::PostAuthorization))"
).format(rc=_RC, tc=_TC)


def test_cid_gate_exactly_six_facts():
    facts = decompose_value_guards(_CID_GATE)
    assert len(facts) == 6
    expected = {
        (_RC, "CidioReturn::NoCidRecord", "ne"),
        (_TC, "CasTransactionCode::CreditRequest", "eq"),
        (_TC, "CasTransactionCode::WorkedFromReferralQue", "eq"),
        (_TC, "CasTransactionCode::ForceEntryToRefer", "eq"),
        (_TC, "CasTransactionCode::ForceEntryToAA", "eq"),
        (_TC, "CasTransactionCode::PostAuthorization", "eq"),
    }
    assert _triples(facts) == expected
    # exactly one ne (on rc) and five eq (all on tc)
    assert sum(1 for f in facts if f["op"] == "ne") == 1
    assert sum(1 for f in facts if f["op"] == "eq") == 5
    assert all(f["scrutinee"] == _TC for f in facts if f["op"] == "eq")


# --------------------------------------------------------------------------- #
# 5: extra surrounding parentheses — identical output
# --------------------------------------------------------------------------- #
def test_cid_gate_extra_parens_identical():
    wrapped = "(" + _CID_GATE + ")"
    assert decompose_value_guards(wrapped) == decompose_value_guards(_CID_GATE)
    assert len(decompose_value_guards(wrapped)) == 6


# --------------------------------------------------------------------------- #
# 6–9: unsafe shapes → []
# --------------------------------------------------------------------------- #
def test_disjunction_different_scrutinees_unsafe():
    assert decompose_value_guards("x == Foo::A || y == Bar::B") == []


def test_disjunction_of_ne_unsafe():
    assert decompose_value_guards("x != Foo::A || x != Foo::B") == []


def test_disjunction_with_function_call_unsafe():
    assert decompose_value_guards("x == f() || x == Foo::B") == []


def test_conjunction_inside_disjunction_unsafe():
    # (a && b) || c — not a homogeneous eq disjunction; emit nothing.
    assert decompose_value_guards("(x == Foo::A && y == Bar::B) || x == Baz::C") == []


# --------------------------------------------------------------------------- #
# 10: over-cap → [] and capped flag
# --------------------------------------------------------------------------- #
def test_over_cap_emits_nothing_and_flags():
    expr = " || ".join(f"x == Foo::C{i}" for i in range(1, 6))  # 5 leaves
    assert decompose_value_guards(expr, max_parts=3) == []
    facts, capped = decompose_value_guards_diag(expr, max_parts=3)
    assert facts == []
    assert capped is True
    # under a sufficient cap the same expr decomposes fully.
    assert len(decompose_value_guards(expr, max_parts=5)) == 5


def test_over_long_text_capped():
    expr = "x" * (MAX_EXPR_CHARS_FOR_DECOMPOSITION + 1)
    facts, capped = decompose_value_guards_diag(expr)
    assert facts == []
    assert capped is True


# --------------------------------------------------------------------------- #
# 11: literal/quote safety — no split inside a quoted literal
# --------------------------------------------------------------------------- #
def test_quote_safety_no_split_inside_string_literal():
    # The KEY assertion: a literal containing "&&" must not be split.
    assert _split_top_level('x == "a&&b"', "&&") == ['x == "a&&b"']
    assert _split_top_level("flag == '|'", "|") == ["flag == '|'"]
    # parse_required_guard rejects a string-literal RHS as non-constant, so the fact
    # list may legitimately be empty — but it must NOT crash or spuriously split.
    assert decompose_value_guards('x == "a&&b"') == []


# --------------------------------------------------------------------------- #
# 12: _split_top_level direct behavior
# --------------------------------------------------------------------------- #
def test_split_single_amp_not_split():
    assert _split_top_level("a & b", "&&") == ["a & b"]


def test_split_top_level_and():
    assert _split_top_level("a && b", "&&") == ["a", "b"]


def test_split_inside_parens_not_split():
    assert _split_top_level("(a && b)", "&&") == ["(a && b)"]


def test_split_nested_disjunction_top_level():
    parts = _split_top_level("((tc==X)||(tc==Y))", "||")
    # outer parens are NOT stripped by _split_top_level, so the whole thing is depth>0 →
    # one fragment. After one strip of the outer parens it splits into two.
    assert parts == ["((tc==X)||(tc==Y))"]
    from vbt.lca_feasibility import _strip_outer_parens

    inner = _strip_outer_parens("((tc==X)||(tc==Y))")
    assert _split_top_level(inner, "||") == ["(tc==X)", "(tc==Y)"]


# --------------------------------------------------------------------------- #
# 13: ASM bitmask guard → one eq fact
# --------------------------------------------------------------------------- #
def test_asm_bitmask_guard():
    facts = decompose_value_guards("(@CASVIS1 & X'40') == X'40'")
    assert len(facts) == 1
    f = facts[0]
    assert f["op"] == "eq"
    assert f["scrutinee"] == "@CASVIS1&X'40'"
    assert f["const"] == "X'40'"


# --------------------------------------------------------------------------- #
# 14: empty / whitespace
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("text", ["", "   ", "\t\n"])
def test_empty_whitespace(text):
    assert decompose_value_guards(text) == []
    facts, capped = decompose_value_guards_diag(text)
    assert facts == []
    assert capped is False


# --------------------------------------------------------------------------- #
# contract: diag()[0] == plain
# --------------------------------------------------------------------------- #
def test_diag_matches_plain():
    for text in ["x == Foo::A", _CID_GATE, "x == Foo::A || y == Bar::B"]:
        assert decompose_value_guards(text) == decompose_value_guards_diag(text)[0]
