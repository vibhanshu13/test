from vbt.interfaces import SetterSite


def test_asm_direct_loader_returns_rows_and_missing_stems(monkeypatch):
    from vbt.precompute import db_artifacts as DA
    import vbt.precompute.depvar_direct_db as D

    for cache in (D._ASM_SETTER_LOADED, D._ASM_SETTER_GROUPED, D._ASM_SCANNED_STEMS):
        cache.clear()

    row = SetterSite(
        variable="FOO", file_stem="aa10", language="asm", line=12,
        instruction="MVC", block_id="AA10_001", value="BAR",
    )
    payload = DA.dumps_gz({"covered": ["aa10", "aa20"], "rows": [row.__dict__]})

    monkeypatch.setattr(D, "_artifact_ready", lambda job_id: True)
    monkeypatch.setattr(
        DA, "read_blob",
        lambda job_id, artifact: payload
        if artifact == D.ASM_SETTER_INDEX_PREFIX + "FOO" else None,
    )

    by_stem, missing = D.load_asm_setters_for_candidates(
        "job1", "foo", ["aa10", "aa20", "aa30"])

    assert missing == {"aa30"}
    assert [s.line for s in by_stem["aa10"]] == [12]
    assert by_stem["aa10"][0].variable == "foo"
    assert by_stem["aa20"] == []


def test_asm_direct_loader_uses_scanned_stems_for_negative_hits(monkeypatch):
    from vbt.precompute import db_artifacts as DA
    import vbt.precompute.depvar_direct_db as D

    for cache in (D._ASM_SETTER_LOADED, D._ASM_SETTER_GROUPED, D._ASM_SCANNED_STEMS):
        cache.clear()

    scanned = DA.dumps_gz(["aa10", "aa20"])

    monkeypatch.setattr(D, "_artifact_ready", lambda job_id: True)
    monkeypatch.setattr(D, "_artifact_version", lambda job_id: 2)
    monkeypatch.setattr(
        DA, "read_blob",
        lambda job_id, artifact: scanned
        if artifact == D.ASM_SCANNED_STEMS_BLOB else None,
    )

    by_stem, missing = D.load_asm_setters_for_candidates(
        "job1", "notPresent", ["aa10", "aa20", "aa30"])

    assert by_stem == {"aa10": [], "aa20": []}
    assert missing == {"aa30"}


def test_cpp_direct_keyset_skips_absent_tail_db_miss(monkeypatch):
    from vbt.precompute import db_artifacts as DA
    import vbt.precompute.depvar_direct_db as D

    for cache in (D._SETTER_LOADED, D._SETTER_GROUPED, D._KEYSETS):
        cache.clear()

    reads = []
    monkeypatch.setattr(D, "_artifact_ready", lambda job_id: True)
    monkeypatch.setattr(D, "_artifact_version", lambda job_id: D.DEPVAR_DIRECT_VERSION)
    monkeypatch.setattr(
        DA,
        "read_blob",
        lambda job_id, artifact: (
            reads.append(artifact) or DA.dumps_gz({
                "cpp_setters": ["presentTail"],
                "cpp_callsites": [],
                "asm_setters": [],
            })
            if artifact == D.DEPVAR_DIRECT_KEYS_BLOB else None
        ),
    )

    assert D.load_cpp_setters_for_candidates("job1", "missingTail", None, ["aa10"]) == []
    assert reads == [D.DEPVAR_DIRECT_KEYS_BLOB]


def test_cpp_callsite_keyset_skips_absent_tail_db_miss(monkeypatch):
    from vbt.precompute import db_artifacts as DA
    import vbt.precompute.depvar_direct_db as D

    for cache in (D._CALLSITE_LOADED, D._CALLSITE_GROUPED, D._KEYSETS):
        cache.clear()

    reads = []
    monkeypatch.setattr(D, "_artifact_ready", lambda job_id: True)
    monkeypatch.setattr(D, "_artifact_version", lambda job_id: D.DEPVAR_DIRECT_VERSION)
    monkeypatch.setattr(
        DA,
        "read_blob",
        lambda job_id, artifact: (
            reads.append(artifact) or DA.dumps_gz({
                "cpp_setters": [],
                "cpp_callsites": ["presentCall"],
                "asm_setters": [],
            })
            if artifact == D.DEPVAR_DIRECT_KEYS_BLOB else None
        ),
    )

    assert D.load_cpp_callsites_for_callee("job1", "missingCall", ["aa10"]) == []
    assert reads == [D.DEPVAR_DIRECT_KEYS_BLOB]
