"""Phase 2 byte-identity: the precomputed C++ setter map reproduces find_cpp_setters_in_file exactly.

For every (stem, tail) the modifier index covers, the precomputed lookup (`load_cpp_setters`) must
equal the live scan (`find_cpp_setters_in_file` with the lookup disabled) — including the dynamic
attrs (`match_scope`, `lhs_path`, `macro_setter_notes`) — for BOTH `full_paths=None` AND a qualified
`full_paths` (which exercises the filter + the `match_scope="qualified"` recomputation). The DB parity
gate separately proves it on the real trace's queried full_paths.
"""
from __future__ import annotations

from dataclasses import asdict

import pytest

from vbt.tests.parity.cases import BLUEPRINT_DIR as BP, ASM_DIR as SRC, corpus_available

JOB = "1ffa983c-3282-42f2-9701-a4c3f21451b1"
pytestmark = pytest.mark.skipif(not corpus_available(), reason="reference corpus unavailable")


def _key(s):
    return (tuple(sorted(asdict(s).items())), getattr(s, "match_scope", None),
            getattr(s, "lhs_path", None), getattr(s, "macro_setter_notes", None))


def _cmp(live, pre):
    return [_key(s) for s in (live or [])] == [_key(s) for s in (pre or [])]


def test_cpp_setter_map_matches_live_scan():
    from vbt.precompute.modifier_index import get_modifier_index
    from vbt.setters.cpp_setters import find_cpp_setters_in_file, set_cpp_setter_map_job, _SETTER_CACHE
    from vbt.precompute.cpp_setter_map_db import load_cpp_setters
    from vbt.precompute import db_artifacts as DA

    set_cpp_setter_map_job(None)       # force find_cpp_setters_in_file to SCAN (live)
    DA.set_load_only(False)
    _SETTER_CACHE.clear()

    midx = get_modifier_index(BP, SRC)
    pairs = [(stem, tail) for tail, files in midx.cpp.items() for stem in files]
    assert pairs, "modifier index produced no C++ (stem,tail) pairs — test would be vacuous"

    checked = mism = miss_nonempty = qualified_checked = 0
    for stem, tail in pairs:
        cpp = SRC / f"{stem}.cpp"
        # (a) permissive (full_paths=None)
        live = find_cpp_setters_in_file(tail, cpp, full_paths=None)
        pre = load_cpp_setters(JOB, stem, tail, None)
        if pre is None:
            if live:
                miss_nonempty += 1
            continue
        checked += 1
        if not _cmp(live, pre):
            mism += 1
            if mism <= 3:
                print(f"PERMISSIVE MISMATCH {stem}/{tail}")
        # (b) qualified full_paths — use a real qualified LHS path from the live sites (tail matches),
        #     exercising matched_explicit / the A3 gate / match_scope="qualified".
        for s in live:
            lp = getattr(s, "lhs_path", "")
            if lp and "." in lp or "->" in (lp or ""):
                fp = [lp]
                lq = find_cpp_setters_in_file(tail, cpp, full_paths=fp)
                pq = load_cpp_setters(JOB, stem, tail, fp)
                qualified_checked += 1
                if not _cmp(lq, pq):
                    mism += 1
                    if mism <= 6:
                        print(f"QUALIFIED MISMATCH {stem}/{tail} fp={fp}")
                break
    assert mism == 0, f"{mism} mismatches (checked {checked} permissive + {qualified_checked} qualified)"
    assert miss_nonempty == 0, f"{miss_nonempty} (stem,tail) had setters live but missed the precompute"
    assert checked > 0, "no (stem,tail) pair was covered by the precompute — coverage gap"
