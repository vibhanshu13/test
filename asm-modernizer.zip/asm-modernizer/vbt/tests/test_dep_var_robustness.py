"""Regression guards for two dep-var collection robustness fixes (audit follow-up).

1. Renamed-root suffix gate (`cpp_setters._chain_is_suffix_consistent`): a setter whose
   member suffix (field + owners) matches the dep's qualified path but whose OUTERMOST
   root differs — the z/TPF shared-work-area idiom where the same storage is reached via
   a differently-named local/by-ref per file (`commonWorkArea` vs `lwrCommon` vs `ccr`) —
   must be ACCEPTED (then the reachability filter decides). Unrelated structs, bare
   locals, and interior-owner mismatches must still be REJECTED (no noise).

2. Array-subscript shatter (`extract._cpp_operand_paths`): a subscripted member read
   `arr[i].field` must be captured as ONE path `arr.field` (not shattered into
   arr / i / field with the field link lost); the index `i` is kept as a separate
   operand (a real read).
"""
from vbt.setters.cpp_setters import _chain_is_suffix_consistent, _member_chain
from vbt.depvars.extract import _cpp_operand_paths


def _consistent(lhs, full):
    return _chain_is_suffix_consistent(_member_chain(lhs), _member_chain(full))


def test_suffix_gate_accepts_renamed_root_and_partial_view():
    full = "lwrCommon.process.various.expressPay"
    # renamed root (same storage, different local name) — the fix
    assert _consistent("commonWorkArea->process.various.expressPay", full)
    assert _consistent("ccr->process.various.expressPay", full)
    # partial view + exact still accepted (unchanged)
    assert _consistent("various.expressPay", full)
    assert _consistent(full, full)


def test_suffix_gate_still_rejects_unrelated_and_bare():
    full = "plasticAuth.process.transactionInds.softCardValue"
    assert not _consistent("other.softCardValue", full)        # unrelated struct
    assert not _consistent("softCardValue", full)              # same-named bare local
    # interior owner mismatch (different field of a different sub-struct)
    assert not _consistent("a.WRONGowner.expressPay", "lwrCommon.process.various.expressPay")
    # ambiguous 2-component renamed root — conservatively rejected (can't tell apart
    # from an unrelated struct's same-named field)
    assert not _consistent("x.expressPay", "lwrCommon.expressPay")


def test_subscript_member_read_recovered_as_one_path():
    for expr, member in [("allCidRecords[i].cidRecord", "allCidRecords.cidRecord"),
                         ("Iso8583[isoField].minLength", "Iso8583.minLength"),
                         ("o->arr[i]->field", "o->arr->field")]:
        paths = _cpp_operand_paths(expr)
        assert member in paths, f"{member!r} not recovered from {expr!r}: {paths}"
    # the index is kept as its own operand (a real read), not lost
    assert "i" in _cpp_operand_paths("allCidRecords[i].cidRecord")
    # a non-subscripted path is unchanged
    assert _cpp_operand_paths("cidRecord.value") == ["cidRecord.value"]
