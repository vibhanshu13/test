"""Regression guard for the ``collect_cpp_conditions`` AST/CFG memo (perf optimization).

The memo MUST be byte-identical to the un-memoized result and MUST NOT let a caller corrupt
a cached entry by mutating a returned ``Condition``. It is keyed by the file's (mtime, size),
so an edited file misses the stale cache. ``clear_cpp_conditions_cache`` empties it.
"""
from __future__ import annotations

import os
import time
from pathlib import Path

import pytest

_CFG_BIN = Path("vbt/cpp_frontend/cfg_extract")
_skip = pytest.mark.skipif(not _CFG_BIN.exists(), reason="clang cfg_extract binary not built")

_SRC = (
    "int g;\n"               # 1
    "void f(int c) {\n"      # 2
    "    if (c == 0) {\n"    # 3
    "        return;\n"      # 4
    "    }\n"                # 5
    "    g = 1;\n"           # 6  <- setter reached only when !(c == 0)
    "}\n"                    # 7
)


@_skip
def test_memo_hit_is_equal_but_independent(tmp_path):
    from vbt.conditions.cpp_conditions import collect_cpp_conditions, clear_cpp_conditions_cache, _CPP_COND_CACHE
    clear_cpp_conditions_cache()
    f = tmp_path / "fires.cpp"
    f.write_text(_SRC)

    first = collect_cpp_conditions(str(f), 6, "f")
    assert "!(c == 0)" in {c.condition for c in first}
    assert len(_CPP_COND_CACHE) >= 1                         # populated

    second = collect_cpp_conditions(str(f), 6, "f")
    # Same CONTENT ...
    assert [(c.condition, c.polarity, c.kind, c.order) for c in first] == \
           [(c.condition, c.polarity, c.kind, c.order) for c in second]
    # ... but INDEPENDENT objects (a cache hit returns copies, never the cached list).
    assert first is not second
    if first:
        assert all(a is not b for a, b in zip(first, second))


@_skip
def test_caller_mutation_does_not_corrupt_cache(tmp_path):
    from vbt.conditions.cpp_conditions import collect_cpp_conditions, clear_cpp_conditions_cache
    clear_cpp_conditions_cache()
    f = tmp_path / "fires.cpp"
    f.write_text(_SRC)

    first = collect_cpp_conditions(str(f), 6, "f")
    baseline = {c.condition for c in first}
    # Mutate the returned objects aggressively.
    for c in first:
        c.condition = "CORRUPTED"
        c.order = -999
    # A subsequent call must be unaffected by that mutation.
    again = collect_cpp_conditions(str(f), 6, "f")
    assert {c.condition for c in again} == baseline
    assert "CORRUPTED" not in {c.condition for c in again}


@_skip
def test_mtime_size_change_invalidates(tmp_path):
    from vbt.conditions.cpp_conditions import collect_cpp_conditions, clear_cpp_conditions_cache
    clear_cpp_conditions_cache()
    f = tmp_path / "fires.cpp"
    f.write_text(_SRC)
    first = {c.condition for c in collect_cpp_conditions(str(f), 6, "f")}
    assert "!(c == 0)" in first

    # Rewrite with a DIFFERENT guard at the same setter line; bump mtime so the key changes.
    f.write_text(
        "int g;\n"
        "void f(int c) {\n"
        "    if (c == 5) {\n"
        "        return;\n"
        "    }\n"
        "    g = 1;\n"
        "}\n"
    )
    os.utime(f, (time.time() + 5, time.time() + 5))
    second = {c.condition for c in collect_cpp_conditions(str(f), 6, "f")}
    assert "!(c == 5)" in second                              # picked up the new content
    assert "!(c == 0)" not in second                          # not the stale cached guard


@_skip
def test_clear_empties_cache(tmp_path):
    from vbt.conditions.cpp_conditions import (
        collect_cpp_conditions, clear_cpp_conditions_cache, _CPP_COND_CACHE)
    f = tmp_path / "fires.cpp"
    f.write_text(_SRC)
    collect_cpp_conditions(str(f), 6, "f")
    assert len(_CPP_COND_CACHE) >= 1
    clear_cpp_conditions_cache()
    assert len(_CPP_COND_CACHE) == 0
