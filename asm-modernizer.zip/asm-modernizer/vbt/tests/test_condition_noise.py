"""Regressions for two condition-metadata noise sources found in a real lineage doc
(542MB trxnResult.json):

1. resolvedConstants junk — the token scan fed LITERAL PIECES to the constant
   resolver: the HLASM literal/attribute prefix (``C'D'`` → token ``C``, ``X'78'`` →
   ``X``, ``L'FLD`` → ``L``), quoted contents (``'N'``, ``"CA"``), and registers.
   The corpus defines single-letter EQUs, so 503k of 1.2M emitted entries were junk
   like ``{"X": "23"}`` / ``{"N": "13"}`` / ``{"R1": "0x01"}``.

2. ICM memory-form predicate — ``ICM R15,15,WRKLWRCV`` + ``BZ`` rendered as
   ``R15 != 15``: the MASK (args[1]) was used as the comparand. ICM sets the CC from
   the inserted bytes, so the predicate is ``WRKLWRCV != 0``.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[2]))

from vbt.resolve.const_resolver import iter_resolvable_tokens  # noqa: E402
from vbt.conditions.asm_conditions import _resolve_predicate  # noqa: E402


# --------------------------------------------------------------------------- #
# 1. token filter
# --------------------------------------------------------------------------- #
def _toks(text):
    return list(iter_resolvable_tokens(text))


def test_hlasm_literal_prefix_and_content_skipped():
    assert _toks("LT2DTLTYP == C'D'") == ["LT2DTLTYP"]
    assert _toks("L7DTNC == X'78'") == ["L7DTNC"]
    assert _toks("=C'370261' == L7DCMN") == ["L7DCMN"]
    assert _toks("(L7ERET1 & X'08') != 0") == ["L7ERET1"]


def test_length_attribute_operand_skipped():
    # L'FIELD is FIELD's assembled LENGTH — resolving FIELD's value there is wrong.
    assert _toks("R2 == L'WRKFLD16") == []


def test_quoted_char_and_string_contents_skipped():
    assert _toks("testCard == 'N'") == ["testCard"]
    assert _toks('memcmp(fobApi->processRequested,"CA", sizeof(x))==0') == \
        ["memcmp", "fobApi", "processRequested", "sizeof", "x"]


def test_registers_skipped_but_real_symbols_kept():
    assert _toks("R15 < MAXCOUNT") == ["MAXCOUNT"]
    assert _toks("R14 < BLOCKSIZ") == ["BLOCKSIZ"]
    assert _toks("R0 == 0 && R15 != 0") == []
    # R16+ / RX are NOT registers — kept.
    assert _toks("R16 == RATE") == ["R16", "RATE"]


def test_qualified_cpp_enum_kept_whole():
    assert _toks("mode == POSTransactionResult::swipeTrxnHsmFailure") == \
        ["mode", "POSTransactionResult::swipeTrxnHsmFailure"]


def test_resolved_consts_uses_filter():
    from vbt.depvars.recurse import _resolved_consts

    class _CR:
        # a corpus-style table where single letters DO resolve (the junk source)
        table = {"C": "*", "X": "23", "N": "13", "D": "3", "MAXCOUNT": "H'200'"}

        def resolve(self, tok, lang):
            return self.table.get(tok)

    assert _resolved_consts("LT2DTLTYP == C'D'", _CR()) == {}
    assert _resolved_consts("testCard == 'N'", _CR()) == {}
    assert _resolved_consts("R15 < MAXCOUNT", _CR()) == {"MAXCOUNT": "H'200'"}


# --------------------------------------------------------------------------- #
# 2. ICM memory form
# --------------------------------------------------------------------------- #
def test_icm_memory_form_predicate_is_storage_vs_zero():
    # fallthrough past BZ = the loaded field is nonzero (was "R15 != 15")
    assert _resolve_predicate("ICM R15, 15, WRKLWRCV", "BZ NM710090",
                              taken=False) == "WRKLWRCV != 0"
    assert _resolve_predicate("ICM R1, 15, WRKLWRDN", "BZ NM710090",
                              taken=True) == "WRKLWRDN == 0"


def test_icm_self_form_still_register_vs_zero():
    assert _resolve_predicate("ICM R5, 15, R5", "BZ LBL", taken=False) == "R5 != 0"


def test_plain_compare_unchanged():
    assert _resolve_predicate("CH R15, MAXCOUNT", "BNL CC801140",
                              taken=False) == "R15 < MAXCOUNT"


# --------------------------------------------------------------------------- #
# 3. vacuous constant guards (v15) — while(1)/if(1)/if(true) constrain nothing
# --------------------------------------------------------------------------- #
def test_vacuous_true_guards_are_dropped_but_negations_kept(tmp_path):
    from vbt.conditions.cpp_conditions import collect_cpp_conditions
    p = tmp_path / "t.cpp"
    p.write_text(
        "void f() {\n"
        "    while (1) {\n"
        "        if (mode == 3) { x = 7; }\n"
        "    }\n"
        "}\n")
    fns = [{"function": "f",
            "guard_regions": [
                {"expr": "1", "kind": "loop", "polarity": True,
                 "line": 2, "start_line": 2, "end_line": 4},
                {"expr": "mode == 3", "kind": "if", "polarity": True,
                 "line": 3, "start_line": 3, "end_line": 3},
            ],
            "cfg_blocks": [{"id": 0, "succs": [],
                            "stmts": [{"line": ln} for ln in (2, 3)]}]}]
    conds = collect_cpp_conditions(p, 3, "f", functions=fns)
    texts = [c.condition for c in conds]
    assert "1" not in texts, texts                 # while(1): constrains nothing
    assert "mode == 3" in texts                    # the real guard survives
    # a NEGATED constant is a dead-path statement — informative, kept
    fns[0]["guard_regions"][0]["polarity"] = False
    from vbt.conditions.cpp_conditions import clear_cpp_conditions_cache
    clear_cpp_conditions_cache()
    conds = collect_cpp_conditions(p, 3, "f", functions=fns)
    assert "!(1)" in [c.condition for c in conds]


def test_xc_self_clear_resolves_to_zero():
    from vbt.output.assembler import xc_self_clear
    # XC FIELD,FIELD zeroes FIELD — the tautological value means "0"
    assert xc_self_clear("XC", "LL9RTN", "LL9RTN")
    assert xc_self_clear("XC", "LL9RTN(8)", "LL9RTN")      # lengthed self-form
    assert not xc_self_clear("XC", "OTHER", "LL9RTN")      # real two-operand XC
    assert not xc_self_clear("MVC", "LL9RTN", "LL9RTN")    # not XC (already skipped upstream)
    assert not xc_self_clear("XC", None, "LL9RTN")
