from pathlib import Path

from vbt.resolve import name_resolver as NR


class _Unit:
    def __init__(self, stem):
        self.stem = stem


def test_no_hint_resolve_uses_query_index_preserving_order(monkeypatch, tmp_path):
    NR.clear_cache()
    units = [_Unit("u1"), _Unit("u2")]
    maps = {
        "u1": {
            "by_cpp": {"field": [
                {"certainty": "high", "asm_name": "A1"},
                {"certainty": "low", "asm_name": "LOW"},
            ]},
            "by_asm": {"A1": [{"certainty": "high", "cpp_path": "rec.field"}]},
        },
        "u2": {
            "by_cpp": {"field": [
                {"certainty": "high", "asm_name": "A1"},
                {"certainty": "high", "asm_name": "A2"},
            ]},
            "by_asm": {},
        },
    }
    calls = {"units": 0}

    def fake_units(src):
        calls["units"] += 1
        return units

    monkeypatch.setattr(NR, "_units", fake_units)
    monkeypatch.setattr(NR, "_alias_map", lambda u: maps[u.stem])

    out1 = NR.resolve("record->field", "cpp", Path(tmp_path)).aliases
    out2 = NR.resolve("field", "cpp", Path(tmp_path)).aliases

    assert [(a.name, a.home_stem) for a in out1] == [("A1", "u1"), ("A2", "u2")]
    assert [(a.name, a.home_stem) for a in out2] == [("A1", "u1"), ("A2", "u2")]
    assert calls["units"] == 1

