from __future__ import annotations

from pathlib import Path


def test_cfg_for_soft_skips_extract_failure(monkeypatch, tmp_path: Path):
    from vbt import engine

    def boom(_path: str):
        raise RuntimeError(
            "cfg_extract produced no output\n"
            "stderr:\n"
            "bad.cpp:24:10: fatal error: 'tpf/tpfapi.h' file not found"
        )

    engine._CFG_SKIP_REASONS.pop("bad", None)
    monkeypatch.setattr(engine, "run_cfg_extract", boom)

    cache = {}
    assert engine._cfg_for("bad", cache, tmp_path) == []
    assert cache["bad"] == []
    assert engine._cfg_skip_reason("bad") == (
        "bad.cpp:24:10: fatal error: 'tpf/tpfapi.h' file not found"
    )

    engine._CFG_SKIP_REASONS.pop("bad", None)


def test_cpp_fn_graph_records_precomputed_cfg_skip(monkeypatch, tmp_path: Path):
    from vbt.precompute import fn_facts_db
    from vbt.reach.cpp_routes import CppFnGraph

    (tmp_path / "a.cpp").write_text("int a() { return 1; }\n", encoding="utf-8")

    monkeypatch.setattr(fn_facts_db, "get_fn_facts", lambda stem: ([], set()))
    monkeypatch.setattr(
        fn_facts_db,
        "get_fn_fact_skip_reason",
        lambda stem: "a.cpp:1:1: fatal error: missing.h file not found",
    )

    class Route:
        def cpp_call_edges(self, _stem):
            return []

        def graph_edges(self):
            return []

        def name_to_stems(self):
            return {}

    graph = CppFnGraph(Route(), {}, tmp_path, {"a"}, {"a": "cpp"})

    assert graph.adjacency() == {}
    assert graph.skipped_cfg_stems == {
        "a": "a.cpp:1:1: fatal error: missing.h file not found"
    }


def test_cpp_fn_graph_enumerate_paths_preserves_order_and_truncation():
    from vbt.reach.cpp_routes import CppFnGraph

    adj = {
        ("s", "S"): {("b", "B", 2, False), ("a", "A", 1, False)},
        ("a", "A"): {("t", "T", 3, False)},
        ("b", "B"): {("t", "T", 4, False)},
        ("t", "T"): set(),
    }
    graph = CppFnGraph.from_prebuilt(adj)

    paths, truncated = graph.enumerate_paths(("s", "S"), ("t", "T"), max_paths=64, max_depth=2)

    assert not truncated
    assert [
        [(edge["callee_stem"], edge["callee_fn"], edge["line"]) for edge in path]
        for path in paths
    ] == [
        [("a", "A", 1), ("t", "T", 3)],
        [("b", "B", 2), ("t", "T", 4)],
    ]
    assert graph.enumerate_paths(("s", "S"), ("t", "T"), max_paths=64, max_depth=2) == (
        paths, truncated
    )

    capped, capped_truncated = graph.enumerate_paths(
        ("s", "S"), ("t", "T"), max_paths=1, max_depth=2
    )
    assert len(capped) == 1
    assert capped_truncated
