"""Reference oracle for the chain_facts parity test — the LIVE, source-reading
``chain_feasibility`` copied VERBATIM from git ``c17a8f4:vbt/chains/feasibility.py``
(absent on the current tree), adapted only to (a) import the pure primitives from
``vbt.lca_feasibility`` and (b) RETURN ``(events, verdict)`` so the parity test can compare
the event list AND the verdict against ``chain_facts_db.assemble_events_from_chain_facts`` +
``decide_feasibility``.

This reads cfg/source/blueprints (it is the ground truth the DB-only path must equal); it is
TEST-ONLY and never imported by production code.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

from vbt.lca_feasibility import (
    _Event, decide_feasibility, parse_required_guard, _is_constant, FeasibilityVerdict)
from vbt.precompute.guard_decompose import decompose_value_guards   # GAP 1: same decomposition


def chain_feasibility_events(
    chain_files: Sequence[str],
    tail_function: Optional[str],
    route,
    blueprint_dir: Path,
    asm_dir: Path,
    *,
    cfg_cache: Optional[Dict[str, list]] = None,
) -> Tuple[List[_Event], FeasibilityVerdict]:
    """The c17a8f4 ``chain_feasibility`` extraction, returning ``(events, verdict)``."""
    from vbt.engine import _prefix_guards, Hop
    from vbt.output.codeblocks import CodeBlockStore
    from vbt.conditions.cpp_conditions import collect_cpp_conditions
    from vbt.conditions.asm_conditions import collect_asm_conditions
    from vbt.setters.cpp_setters import find_cpp_setters_in_file
    from vbt.setters.asm_setters import find_asm_setters_in_file
    from vbt.cpp_frontend.wrapper import run_cfg_extract
    from backward_traversal.utils.blueprint_utils import resolve_asm_blueprint, load_json

    blueprint_dir = Path(blueprint_dir)
    asm_dir = Path(asm_dir)
    files = list(chain_files)
    if len(files) < 2:
        return [], FeasibilityVerdict("feasible")
    cfg_cache = cfg_cache if cfg_cache is not None else {}
    nt = route.node_types()
    parsed_nodes = [(n.split("::", 1)[0], (n.split("::", 1)[1] if "::" in n else None))
                    for n in files]
    idx_of: Dict[str, int] = {}
    for i, (stem, _fn) in enumerate(parsed_nodes):
        idx_of.setdefault(stem, i)

    hops = []
    for i, (stem, fn) in enumerate(parsed_nodes):
        ftype = nt.get(stem, "asm")
        if ftype != "cpp":
            fn = None
        elif fn is None and i == len(parsed_nodes) - 1:
            fn = tail_function
        hops.append(Hop(stem, ftype, fn))
    store = CodeBlockStore(asm_dir)
    asm_bp_cache: Dict[str, Dict] = {}
    try:
        guard_conds, bounds = _prefix_guards(hops, route, cfg_cache, asm_dir, store,
                                             blueprint_dir, asm_bp_cache)
    except Exception:
        return [], FeasibilityVerdict("unknown", reason="guard collection failed")

    events: List[_Event] = []
    scrutinees: Dict[str, str] = {}
    seen_ev = set()
    for cond, via, _blk in guard_conds:
        from_stem = (via or "").split("→")[0].split("@")[0].strip()
        hop = idx_of.get(from_stem, 0)
        lang = "asm" if (cond.raw_test or str(cond.location.file).endswith(".asm")) else "cpp"
        line = int(cond.location.start_line or 0)
        # GAP 1: decompose safe compound guards into simple value-guards — the SAME
        # decomposition the precompute applies — so this source-reading oracle stays a
        # faithful reference for the DB-only ``value_guards`` replay (dedup mirrors the
        # per-edge dedup in chain_facts_db._process_stem_edges_worker).
        for f in decompose_value_guards(cond.condition or ""):
            scrut, const, op = f["scrutinee"], f["const"], f["op"]
            dk = (hop, line, scrut, const, op, f["text"])
            if dk in seen_ev:
                continue
            seen_ev.add(dk)
            scrutinees.setdefault(scrut, lang)
            events.append(_Event(hop=hop, line=line, kind="guard",
                                 scrutinee=scrut, const=const, op=op, text=f["text"]))
    if not events:
        return [], FeasibilityVerdict("unknown", reason="no constant value-guards on the chain")

    for scrut, lang in scrutinees.items():
        for stem in dict.fromkeys(s for s, _ in parsed_nodes):
            i = idx_of[stem]
            bound = bounds.get(stem)
            if lang == "cpp":
                cpp = asm_dir / f"{stem}.cpp"
                if not cpp.exists():
                    continue
                tail = scrut.split(".")[-1].split("->")[-1]
                fp = [scrut] if ("." in scrut or "->" in scrut) else None
                cfg = cfg_cache.get(stem)
                if cfg is None:
                    cfg = run_cfg_extract(str(cpp)); cfg_cache[stem] = cfg
                for s in find_cpp_setters_in_file(tail, cpp, full_paths=fp):
                    if s.is_declaration and not s.value:
                        continue
                    if bound is not None and s.line >= bound:
                        continue
                    val = (s.value or "").strip()
                    conditional = bool(collect_cpp_conditions(cpp, s.line, s.function, functions=cfg))
                    events.append(_Event(hop=i, line=int(s.line or 0), kind="assign",
                                         scrutinee=scrut,
                                         const=(val if _is_constant(val) else None),
                                         conditional=conditional, text=f"{scrut} = {val}"))
            else:
                try:
                    bp_path = str(resolve_asm_blueprint(stem, blueprint_dir))
                    bp = load_json(bp_path)
                except Exception:
                    continue
                for s in find_asm_setters_in_file(scrut, stem, blueprint_dir, asm_dir):
                    if bound is not None and s.line >= bound:
                        continue
                    val = (s.value or "").strip()
                    conds, _ = collect_asm_conditions(bp, bp_path, s.block_id, s.line, f"{stem}.asm")
                    events.append(_Event(hop=i, line=int(s.line or 0), kind="assign",
                                         scrutinee=scrut,
                                         const=(val if _is_constant(val) else None),
                                         conditional=bool(conds), text=f"{scrut} = {val}"))
    return events, decide_feasibility(events)


def _event_key(e: _Event):
    return (e.hop, e.line, e.kind, e.scrutinee, e.const, e.op, bool(e.conditional))


def event_multiset(events: Sequence[_Event]):
    from collections import Counter
    return Counter(_event_key(e) for e in events)
