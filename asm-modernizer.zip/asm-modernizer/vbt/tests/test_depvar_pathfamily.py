"""Path-family dependents: ancestors + descendants of a member-path dep var.

For a member-path dep `a.b.c`, VBT now emits, as SEPARATE linked nodes:
  * ANCESTORS  — the container prefixes `a.b`, `a` (string prefixes, no struct/types
    needed); a write to one (e.g. `memcpy(&a.b, src, n)`) sets `a.b.c` wholly.
  * DESCENDANTS — written sub-fields `a.b.c.*` (discovered from observed writes).
Derived nodes don't re-expand the family (no sibling blow-up); links are exposed as
`pathParents`/`pathChildren` (by qualified path) + `origin`.

Baseline-independent: real tree-sitter fixtures on disk; only the heavy non-parsing
collaborators (modifier index / alias resolver / cfg / store) are stubbed.
"""
from pathlib import Path

from vbt.depvars.extract import DepVarRef
from vbt.interfaces import SetterSite


def _run(monkeypatch, tmp_path, files, seed_qualified, seed_file, *,
         max_descendants=50, suppress_empty_path_family_ancestors=False):
    import vbt.depvars.recurse as R
    from vbt.depvars.recurse import trace_dependents

    for name, text in files.items():
        (tmp_path / name).write_text(text)
    stems = {Path(n).stem for n in files}

    class _Idx:
        def files_for(self, name, language): return set(stems)
        def files_defining_function(self, fn): return set()
        def sites_for(self, *a, **k): return []

    monkeypatch.setattr(R, "get_modifier_index", lambda *a, **k: _Idx())
    monkeypatch.setattr(R, "resolve_aliases",
                        lambda name, lang, asm_dir: type("A", (), {"aliases": []})())
    monkeypatch.setattr(R, "run_cfg_extract", lambda *a, **k: [])
    monkeypatch.setattr(R, "_cpp_fn_block", lambda *a, **k: None)
    monkeypatch.setattr(R, "_dep_chunk", lambda *a, **k: None)
    # find_cpp_setters_in_file + find_cpp_writes_under_path run REAL on the fixtures.

    dep = DepVarRef(name=seed_qualified.split(".")[-1], language="cpp",
                    relationship="condition", qualified=seed_qualified,
                    found_at={"file": seed_file, "startLine": 0, "endLine": 0})
    out = trace_dependents([("root", dep)], sorted(stems),
                           blueprint_dir=tmp_path, asm_dir=tmp_path, store=None,
                           max_descendants=max_descendants,
                           suppress_empty_path_family_ancestors=suppress_empty_path_family_ancestors)
    return {d["dependentVariable"].get("qualified", d["dependentVariable"]["name"]):
            d["dependentVariable"] for d in out}


def test_ancestors_emitted_and_chained(monkeypatch, tmp_path):
    nodes = _run(monkeypatch, tmp_path, {"f.cpp": "void g(){ obj.rec.month = 1; }"},
                 "obj.rec.month", "f.cpp")
    assert "obj.rec" in nodes and "obj" in nodes
    assert nodes["obj.rec.month"].get("pathParents") == ["obj.rec"]
    assert nodes["obj.rec"].get("origin") == "ancestor"
    assert nodes["obj.rec"].get("pathParents") == ["obj"]
    assert nodes["obj.rec"].get("pathChildren") == ["obj.rec.month"]
    assert nodes["obj"].get("pathChildren") == ["obj.rec"]


def test_ancestor_aggregate_write_is_a_setter(monkeypatch, tmp_path):
    # a whole-parent memcpy sets the nested field — found under the ANCESTOR node.
    nodes = _run(monkeypatch, tmp_path, {"f.cpp": "void g(){ memcpy(&obj.rec, src, 4); }"},
                 "obj.rec.month", "f.cpp")
    anc = nodes["obj.rec"]
    assert len(anc["setters"]) == 1, anc["setters"]
    assert anc["setters"][0]["value"] == "src"


def test_descendants_found_no_sibling_blowup(monkeypatch, tmp_path):
    nodes = _run(monkeypatch, tmp_path,
                 {"f.cpp": "void g(){ obj.rec.month.digit1 = 1; obj.rec.year = 2; }"},
                 "obj.rec.month", "f.cpp")
    # the sub-field write is a descendant of month...
    assert "obj.rec.month.digit1" in nodes
    assert nodes["obj.rec.month.digit1"].get("origin") == "descendant"
    assert nodes["obj.rec.month"].get("pathChildren") == ["obj.rec.month.digit1"]
    # ...but the SIBLING obj.rec.year is NOT pulled in (ancestors don't re-expand)
    assert "obj.rec.year" not in nodes


def test_descendant_cap_is_surfaced(monkeypatch, tmp_path):
    nodes = _run(monkeypatch, tmp_path,
                 {"f.cpp": "void g(){ obj.rec.a = 1; obj.rec.b = 2; obj.rec.c = 3; }"},
                 "obj.rec", "f.cpp", max_descendants=2)
    assert nodes["obj.rec"].get("descendantsCapped") is True
    assert len(nodes["obj.rec"].get("pathChildren", [])) <= 2


def test_root_trace_mode_suppresses_db_proven_empty_ancestors(monkeypatch, tmp_path):
    import vbt.depvars.recurse as R

    def _direct(job_id, variable, full_paths, candidate_stems):
        # Let the primary field use the real parser, but make the generated ancestors
        # DB-authoritative empty, as depvar_direct does on a large precomputed KB.
        if full_paths in (["obj.rec"], ["obj"]):
            return []
        return None

    monkeypatch.setattr(R, "load_cpp_setters_for_candidates", _direct)
    nodes = _run(monkeypatch, tmp_path, {"f.cpp": "void g(){ obj.rec.month = 1; }"},
                 "obj.rec.month", "f.cpp", suppress_empty_path_family_ancestors=True)

    assert "obj.rec.month" in nodes
    assert "obj.rec" not in nodes
    assert "obj" not in nodes
    assert "pathParents" not in nodes["obj.rec.month"]


def test_route_warmer_skips_db_proven_empty_ancestor(monkeypatch, tmp_path):
    import vbt.depvars.recurse as R

    class _Idx:
        def files_for(self, name, language): return {"f"}
        def files_defining_function(self, fn): return set()

    class _Route:
        def reachable(self, *args, **kwargs):
            raise AssertionError("suppressed ancestor should not route-check")

    monkeypatch.setattr(R, "resolve_aliases",
                        lambda name, lang, asm_dir: type("A", (), {"aliases": []})())
    monkeypatch.setattr(R, "load_cpp_setters_for_candidates",
                        lambda job_id, variable, full_paths, candidate_stems: [])
    monkeypatch.setattr(R, "_gather_candidate_setters",
                        lambda *args, **kwargs: (_ for _ in ()).throw(
                            AssertionError("suppressed ancestor should not gather setters")))

    ctx = R._NodeCtx(
        blueprint_dir=tmp_path, asm_dir=tmp_path, chain_set={"f"},
        upstream_bounds={}, route_engine=_Route(), chain_hops=[("f", "cpp", "g")],
        max_depth=2, const_resolver=None, max_offchain_files=100,
        asm_max_levels=16, max_descendants=50, midx=_Idx(),
        memb=type("M", (), {"resolve": lambda *args, **kwargs: {}})(),
        reach_union={"f"}, suppress_empty_path_family_ancestors=True,
    )
    dep = DepVarRef(name="rec", language="cpp", relationship="ancestor",
                    found_at={"file": "f.cpp", "startLine": 0, "endLine": 0},
                    qualified="obj.rec", origin="ancestor", expand_family=False)

    old_ctx = R._CTX
    try:
        R._set_ctx(ctx)
        R._warm_node_routes(("root", dep, 7))
    finally:
        R._CTX = old_ctx


def test_root_trace_mode_keeps_ancestor_with_aggregate_setter(monkeypatch, tmp_path):
    import vbt.depvars.recurse as R

    site = SetterSite(variable="rec", file_stem="f", language="cpp", line=1,
                      instruction="assign", block_id="", value="src")

    def _direct(job_id, variable, full_paths, candidate_stems):
        if full_paths == ["obj.rec"]:
            return [site]
        if full_paths == ["obj"]:
            return []
        return None

    monkeypatch.setattr(R, "load_cpp_setters_for_candidates", _direct)
    nodes = _run(monkeypatch, tmp_path, {"f.cpp": "void g(){ }"},
                 "obj.rec.month", "f.cpp", suppress_empty_path_family_ancestors=True)

    assert "obj.rec" in nodes
    assert len(nodes["obj.rec"]["setters"]) == 1
    assert nodes["obj.rec"]["setters"][0]["value"] == "src"
