"""Path-family dependents: ancestors + descendants of a member-path dep var.

For a member-path dep `a.b.c`, VBT now emits, as SEPARATE linked nodes:
  * ANCESTORS  — the container prefixes `a.b`, `a` (string prefixes, no struct/types
    needed); a write to one (e.g. `memcpy(&a.b, src, n)`) sets `a.b.c` wholly.
  * DESCENDANTS — written sub-fields `a.b.c.*` (discovered from observed writes).
Derived nodes don't re-expand the family (no sibling blow-up); links are exposed as
`pathParents`/`pathChildren` (by qualified path) + `origin`.

Baseline-independent: real tree-sitter fixtures on disk; only the heavy non-parsing
collaborators (modifier index / alias resolver / cfg / store) are stubbed.
"""
from pathlib import Path

from vbt.depvars.extract import DepVarRef


def _run(monkeypatch, tmp_path, files, seed_qualified, seed_file, *, max_descendants=50):
    import vbt.depvars.recurse as R
    from vbt.depvars.recurse import trace_dependents

    for name, text in files.items():
        (tmp_path / name).write_text(text)
    stems = {Path(n).stem for n in files}

    class _Idx:
        def files_for(self, name, language): return set(stems)
        def files_defining_function(self, fn): return set()
        def sites_for(self, *a, **k): return []

    monkeypatch.setattr(R, "get_modifier_index", lambda *a, **k: _Idx())
    monkeypatch.setattr(R, "resolve_aliases",
                        lambda name, lang, asm_dir: type("A", (), {"aliases": []})())
    monkeypatch.setattr(R, "run_cfg_extract", lambda *a, **k: [])
    monkeypatch.setattr(R, "_cpp_fn_block", lambda *a, **k: None)
    monkeypatch.setattr(R, "_dep_chunk", lambda *a, **k: None)
    # find_cpp_setters_in_file + find_cpp_writes_under_path run REAL on the fixtures.

    dep = DepVarRef(name=seed_qualified.split(".")[-1], language="cpp",
                    relationship="condition", qualified=seed_qualified,
                    found_at={"file": seed_file, "startLine": 0, "endLine": 0})
    out = trace_dependents([("root", dep)], sorted(stems),
                           blueprint_dir=tmp_path, asm_dir=tmp_path, store=None,
                           max_descendants=max_descendants)
    return {d["dependentVariable"].get("qualified", d["dependentVariable"]["name"]):
            d["dependentVariable"] for d in out}


def test_ancestors_emitted_and_chained(monkeypatch, tmp_path):
    nodes = _run(monkeypatch, tmp_path, {"f.cpp": "void g(){ obj.rec.month = 1; }"},
                 "obj.rec.month", "f.cpp")
    assert "obj.rec" in nodes and "obj" in nodes
    assert nodes["obj.rec.month"].get("pathParents") == ["obj.rec"]
    assert nodes["obj.rec"].get("origin") == "ancestor"
    assert nodes["obj.rec"].get("pathParents") == ["obj"]
    assert nodes["obj.rec"].get("pathChildren") == ["obj.rec.month"]
    assert nodes["obj"].get("pathChildren") == ["obj.rec"]


def test_ancestor_aggregate_write_is_a_setter(monkeypatch, tmp_path):
    # a whole-parent memcpy sets the nested field — found under the ANCESTOR node.
    nodes = _run(monkeypatch, tmp_path, {"f.cpp": "void g(){ memcpy(&obj.rec, src, 4); }"},
                 "obj.rec.month", "f.cpp")
    anc = nodes["obj.rec"]
    assert len(anc["setters"]) == 1, anc["setters"]
    assert anc["setters"][0]["value"] == "src"


def test_descendants_found_no_sibling_blowup(monkeypatch, tmp_path):
    nodes = _run(monkeypatch, tmp_path,
                 {"f.cpp": "void g(){ obj.rec.month.digit1 = 1; obj.rec.year = 2; }"},
                 "obj.rec.month", "f.cpp")
    # the sub-field write is a descendant of month...
    assert "obj.rec.month.digit1" in nodes
    assert nodes["obj.rec.month.digit1"].get("origin") == "descendant"
    assert nodes["obj.rec.month"].get("pathChildren") == ["obj.rec.month.digit1"]
    # ...but the SIBLING obj.rec.year is NOT pulled in (ancestors don't re-expand)
    assert "obj.rec.year" not in nodes


def test_descendant_cap_is_surfaced(monkeypatch, tmp_path):
    nodes = _run(monkeypatch, tmp_path,
                 {"f.cpp": "void g(){ obj.rec.a = 1; obj.rec.b = 2; obj.rec.c = 3; }"},
                 "obj.rec", "f.cpp", max_descendants=2)
    assert nodes["obj.rec"].get("descendantsCapped") is True
    assert len(nodes["obj.rec"].get("pathChildren", [])) <= 2
