"""Verified brace-repair tool (vbt/tools/repair_braces.py).

Two layers:
  * SELF-CONTAINED (no corpus / no Clang): a tiny synthetic .cpp with a deliberate
    stray-``}`` mis-nesting that truncates a function before a later ``switch``. We
    assert the tool locates the stray, proposes a minimal removal, and that the
    repaired text parses with the function spanning its full body — exercising the
    brace-depth + candidate + tree-sitter machinery deterministically.
  * CORPUS-GUARDED (needs temp/asm + Clang cfg_extract): the canonical
    processACreditTransaction case must classify deterministically and, when
    repairable, propose exactly the stray-``}`` removal that un-truncates it.

Mirrors the skipif pattern in test_truncation_lint.py.
"""
from pathlib import Path

import pytest

from vbt.tools.repair_braces import (
    BraceEdit,
    _apply_edits,
    _balance,
    _candidate_edits,
    _locate_body_open,
    _scan_braces,
    _ts_fn_end,
    _zero_crossing,
    repair_function,
    run,
)

ASM = Path("temp/asm")

# A stray `}` (L12) closes gate() early, hiding the later switch; the file carries
# one extra `}` so a single removal both rebalances and un-truncates the function.
_SYNTH = """\
int helper(int x) {
    return x + 1;
}

void gate(int mode, int code) {
    if (mode > 0) {
        helper(mode);
        if (code == 1) {
            helper(code);
        }
    }
    }
    helper(mode);
    switch (code) {
        case 2:
            helper(2);
            break;
        case 3:
            helper(3);
            break;
    }
    return;
}

void after() {
    helper(0);
}
"""


# --------------------------------------------------------------------------- #
# Self-contained (baseline-independent): brace mechanics + proposal.
# --------------------------------------------------------------------------- #
def test_scan_braces_is_literal_and_comment_aware():
    src = """\
void f() {
    char open = '{';      // a char-literal brace
    char close = '}';     // and its mate  }} in a comment
    const char* s = "a{b}c";
    /* a block } comment { */
    if (open) { open = 0; }
}
"""
    o, c = _balance(src)
    # Only the real code braces count: f() body + the if-block = 2 pairs.
    assert (o, c) == (2, 2)


def test_synthetic_stray_brace_is_located_and_proposed(tmp_path):
    src = _SYNTH
    braces = _scan_braces(src)
    open_idx = _locate_body_open(src.encode(), braces, "gate", 5)
    assert open_idx is not None
    # The body's brace depth prematurely returns to 0 at the stray `}` (L12),
    # truncating the function before the switch (which starts at L14).
    early_close = _zero_crossing(braces, open_idx)
    assert early_close == 12
    assert _ts_fn_end(src.encode(), "gate") == 12        # tree-sitter truncates too

    lines = src.split("\n")
    after_line = next(i + 1 for i, ln in enumerate(lines) if ln.startswith("void after"))
    true_end = after_line - 1
    cands = _candidate_edits(src, braces, open_idx, early_close, true_end)
    assert cands, "expected at least one candidate edit"
    edits, _mism = cands[0]
    # Minimal proposal: remove exactly the one stray `}` at L12.
    assert edits == [BraceEdit(op="remove", line=12, col=4)]


def test_synthetic_repair_balances_and_spans_full_body():
    src = _SYNTH
    braces = _scan_braces(src)
    open_idx = _locate_body_open(src.encode(), braces, "gate", 5)
    early_close = _zero_crossing(braces, open_idx)
    lines = src.split("\n")
    true_end = next(i + 1 for i, ln in enumerate(lines)
                    if ln.startswith("void after")) - 1

    edits, _ = _candidate_edits(src, braces, open_idx, early_close, true_end)[0]
    repaired = _apply_edits(src, edits)

    # File rebalances, and gate() now spans through its switch to its real `}`.
    assert _balance(repaired) == (6, 6)
    gate_end = _ts_fn_end(repaired.encode(), "gate")
    assert gate_end > early_close                 # no longer truncated
    # The `switch` line now sits INSIDE the recovered gate() span (it was lost before).
    rlines = repaired.split("\n")
    switch_line = next(i + 1 for i, ln in enumerate(rlines) if "switch" in ln)
    assert early_close < switch_line < gate_end
    # after() is untouched and still a separate function below gate().
    assert _ts_fn_end(repaired.encode(), "after") > gate_end


def test_apply_edits_remove_then_insert_orderings():
    # remove L12 + insert before L25 must apply without offset drift.
    src = _SYNTH
    edits = [BraceEdit(op="remove", line=12, col=4),
             BraceEdit(op="insert", line=25)]
    out = _apply_edits(src, edits)
    # one `}` removed and one `}` inserted → balance unchanged from original (6,7).
    assert _balance(out) == (6, 7)


# --------------------------------------------------------------------------- #
# Corpus-guarded: the canonical processACreditTransaction case.
# --------------------------------------------------------------------------- #
@pytest.mark.skipif(not (ASM / "dw710000.cpp").exists(),
                    reason="temp/asm sources not present")
def test_processACreditTransaction_repairable_deterministic():
    path = str(ASM / "dw710000.cpp")
    from vbt.precompute.truncation_lint import detect_in_file
    if not any(t.function == "processACreditTransaction" for t in detect_in_file(path)):
        pytest.skip("processACreditTransaction already brace-repaired in this corpus")
    # detector facts (from process_analysis/truncated_functions.json)
    f1 = repair_function(path, "processACreditTransaction", 934, 1057, 1406)
    f2 = repair_function(path, "processACreditTransaction", 934, 1057, 1406)
    # deterministic verdict + edit
    assert f1.repairable == f2.repairable
    assert [(e.op, e.line) for e in f1.edits] == [(e.op, e.line) for e in f2.edits]
    # This is THE known genuine brace bug: a single stray `}` near L1046 whose
    # removal extends the body to its real end (~L1390) and recovers the gate-3
    # switch for Clang. The algorithm must verify it as repairable.
    assert f1.repairable, f1.reason
    assert len(f1.edits) == 1
    e = f1.edits[0]
    assert e.op == "remove"
    assert 1044 <= e.line <= 1046          # the stray-`}` region (general, not hardcoded)
    assert f1.repaired_end_line > 1300     # body now spans far past the L1058 truncation
    assert f1.cfg_max_after > 1057         # Clang CFG advanced past the old truncation


@pytest.mark.skipif(not (ASM / "dw710000.cpp").exists(),
                    reason="temp/asm sources not present")
def test_run_over_report_is_safe_and_under_repairs(tmp_path):
    report = Path("process_analysis/truncated_functions.json")
    if not report.exists():
        pytest.skip("truncation report not present")
    findings = run(ASM, report)
    # Every brace-mismatch entry gets a verdict; under-repairing is acceptable, but
    # any REPAIRABLE verdict must carry a concrete, verified edit (never empty).
    assert findings
    for f in findings:
        if f.repairable:
            assert f.edits, f"{f.function} marked repairable with no edit"
            assert f.repaired_end_line > f.truncated_end_line
        else:
            assert f.reason                      # a NOT-REPAIRABLE must explain why
    # The canonical case must be among the repairable set — unless it's already been
    # repaired in this corpus (then it's absent from the report).
    pac = next((f for f in findings if f.function == "processACreditTransaction"), None)
    if pac is not None:
        assert pac.repairable, pac.reason
