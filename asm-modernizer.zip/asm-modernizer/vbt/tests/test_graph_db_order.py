"""B byte-identity: the precomputed graph blobs round-trip FAITHFULLY.

The crux of fix B is that `reverse_adj[key]` is a list of `(src, instr)` whose ORDER is load-bearing
downstream — `walk_callers` does `candidates.setdefault(src, instr)`, so the FIRST occurrence of a
src wins. If the gz/JSON round-trip reordered (or dropped tuple-ness) of those value lists, the
caller forest — and the whole trace — could change. These tests assert:

  1. the pure serialize→load round-trip reproduces `build_reverse_adjacency` element-for-element, in
     order, over the REAL corpus (no DB state needed);
  2. the actual `build_and_store_reverse_adj` / `load_reverse_adj` functions agree with a fresh build
     against the reference DB;
  3. `forward_file_adj` round-trips as identical SETS (order-independent by design).
"""
from __future__ import annotations

import pytest

from vbt.tests.parity.cases import BLUEPRINT_DIR, GRAPH_FILE, ASM_DIR, corpus_available
from vbt.precompute import db_artifacts as DA

JOB = "1ffa983c-3282-42f2-9701-a4c3f21451b1"

pytestmark = pytest.mark.skipif(not corpus_available(), reason="reference corpus unavailable")


def _fresh_reverse():
    from backward_traversal.runner.chainless_runner import _load_graph_payload
    from backward_traversal.runner.chainless_caller_walker import build_reverse_adjacency
    payload = _load_graph_payload(GRAPH_FILE, None)
    return build_reverse_adjacency(payload)


def test_reverse_adj_serialize_roundtrip_is_order_faithful():
    """The pure dumps_gz→loads_gz round-trip (the byte-identity crux) must reproduce every value
    list element-for-element AND in the SAME order as build_reverse_adjacency."""
    fresh_reverse, fresh_nt = _fresh_reverse()
    assert fresh_reverse, "corpus produced an empty reverse_adj — test would be vacuous"

    # serialize EXACTLY as build_and_store_reverse_adj does …
    data = {"reverse": {k: [list(p) for p in v] for k, v in fresh_reverse.items()},
            "node_type": fresh_nt}
    rt = DA.loads_gz(DA.dumps_gz(data))
    # … and rebuild EXACTLY as load_reverse_adj does.
    loaded_reverse = {k: [tuple(p) for p in v] for k, v in rt["reverse"].items()}
    loaded_nt = dict(rt["node_type"])

    assert loaded_nt == fresh_nt
    assert set(loaded_reverse) == set(fresh_reverse)
    # list == list compares length, element ORDER, and tuple contents — the load-bearing invariant.
    drift = [k for k in fresh_reverse if loaded_reverse[k] != fresh_reverse[k]]
    assert not drift, f"reverse_adj order/content drift in {len(drift)} keys, e.g. {drift[:5]}"
    # belt-and-suspenders: confirm tuple-ness + order on a non-trivial key (a multi-entry list)
    multi = next((k for k in fresh_reverse if len(fresh_reverse[k]) > 1), None)
    if multi is not None:
        assert loaded_reverse[multi] == fresh_reverse[multi]
        assert all(isinstance(p, tuple) and len(p) == 2 for p in loaded_reverse[multi])


def test_build_and_load_reverse_adj_matches_fresh_build():
    """The real build_and_store_reverse_adj → load_reverse_adj path equals a fresh in-memory build."""
    from vbt.precompute.graph_db import build_and_store_reverse_adj, load_reverse_adj
    fresh_reverse, fresh_nt = _fresh_reverse()
    build_and_store_reverse_adj(JOB, BLUEPRINT_DIR, GRAPH_FILE)
    loaded = load_reverse_adj(JOB)
    assert loaded is not None
    loaded_reverse, loaded_nt = loaded
    assert loaded_nt == fresh_nt
    assert set(loaded_reverse) == set(fresh_reverse)
    drift = [k for k in fresh_reverse if loaded_reverse[k] != fresh_reverse[k]]
    assert not drift, f"stored/loaded reverse_adj drift in {len(drift)} keys, e.g. {drift[:5]}"


def test_forward_file_adj_roundtrip_sets_identical():
    """forward_file_adj is set-valued; the round-trip must yield identical sets per source stem."""
    from vbt.reach.route import RouteEngine
    from vbt.precompute.graph_db import (
        preload_route_graph, build_and_store_forward_file_adj, load_forward_file_adj)
    DA.set_load_only(False)
    route = RouteEngine(BLUEPRINT_DIR, GRAPH_FILE, ASM_DIR, job_id=JOB)
    preload_route_graph(route, JOB, BLUEPRINT_DIR, GRAPH_FILE)
    fresh = route._build_forward_file_adj()
    build_and_store_forward_file_adj(JOB, route)
    loaded = load_forward_file_adj(JOB)
    assert loaded is not None
    assert set(loaded) == set(fresh)
    drift = [k for k in fresh if loaded[k] != fresh[k]]
    assert not drift, f"forward_file_adj set drift in {len(drift)} keys, e.g. {drift[:5]}"
