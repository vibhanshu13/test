"""Regression: register-indirect DESTINATION setter resolution (audit D3 fix).

A write whose destination is register-indirect — ``MVC 0(R1),SRC`` / ``ST R,d(Rn)`` /
``OI d(Rn),mask`` — stores into the field ``Rn`` points at, but the destination operand
is a ``disp(Rn)`` form that does NOT name the field, so the name-matching setter finder is
blind to it (and the modifier index used to record the spurious key ``0``). The fix
resolves the dest register to its named field (the mirror of the source-side resolver),
at BOTH the modifier-index (discovery → candidate file) and precise-finder (detection →
SetterSite) layers. Sound: gives up rather than guessing.

Needs a blueprint dir covering aa71 (+ the temp/asm sources). Skips otherwise.
"""
from pathlib import Path

import pytest

ASM = Path("temp/asm")


def _bp_dir():
    for out in sorted(Path("jobs").glob("*/output")):
        if (out / "aa71.asm.json").exists():
            return out
    return None


BP = _bp_dir()
pytestmark = pytest.mark.skipif(
    not (ASM.exists() and (ASM / "aa71.asm").exists() and BP is not None),
    reason="aa71 blueprint + temp/asm sources not present",
)


def test_core_resolves_register_indirect_dest_incl_mvc():
    """`resolve_indirect_dest_writes` finds register-indirect dests — including MVC, whose
    columnar args are empty (recovered from the raw source line) — and resolves them to a
    named field. Returns nothing for an unresolvable (caller-inherited) base (sound)."""
    from backward_traversal.utils.blueprint_utils import load_json
    from vbt.resolve.register_indirect import resolve_indirect_dest_writes
    bp = load_json(str(BP / "aa71.asm.json"))
    rows = resolve_indirect_dest_writes(bp, str(BP / "aa71.asm.json"), "aa71", asm_dir=ASM)
    assert rows, "expected at least one resolved register-indirect dest in aa71"
    # every row names a real field (no displacement/register/synthetic garbage)
    for field, line, bid, inst, src in rows:
        assert field and not field.startswith(("alloc@", "DB_CONTEXT_", "call_return@"))
        assert "(" not in field and field != "0"
    # at least one came from an MVC (empty columnar args → raw-source recovery)
    assert any(inst == "MVC" for *_, inst, _ in rows), \
        "MVC register-indirect dest (raw-recovered) not found"


def test_precise_finder_surfaces_indirect_dest_site():
    """find_asm_setters_in_file returns an ``indirect_dest`` SetterSite for the resolved
    field — a write the name-matching finder alone would miss."""
    from backward_traversal.utils.blueprint_utils import load_json
    from vbt.resolve.register_indirect import resolve_indirect_dest_writes
    from vbt.setters.asm_setters import find_asm_setters_in_file
    bp = load_json(str(BP / "aa71.asm.json"))
    rows = resolve_indirect_dest_writes(bp, str(BP / "aa71.asm.json"), "aa71", asm_dir=ASM)
    field = rows[0][0]
    sites = find_asm_setters_in_file(field, "aa71", BP, ASM)
    indirect = [s for s in sites if s.role == "indirect_dest"]
    assert indirect, f"no indirect_dest site surfaced for {field!r}"
    assert any(s.line == rows[0][1] for s in indirect)


def test_modifier_index_indexes_resolved_field_and_drops_zero_noise():
    """The modifier index makes the writer file a candidate for the resolved field, and no
    longer records the spurious ``0`` key the displacement form used to produce."""
    from vbt.precompute.modifier_index import get_modifier_index
    midx = get_modifier_index(BP, ASM)
    assert "0" not in midx.asm, 'the spurious "0" key must not be indexed'
    from backward_traversal.utils.blueprint_utils import load_json
    from vbt.resolve.register_indirect import resolve_indirect_dest_writes
    bp = load_json(str(BP / "aa71.asm.json"))
    rows = resolve_indirect_dest_writes(bp, str(BP / "aa71.asm.json"), "aa71", asm_dir=ASM)
    field = rows[0][0]
    assert "aa71" in midx.files_for(field, "asm"), \
        f"{field!r} writer file aa71 not indexed (would be pruned before detection)"
