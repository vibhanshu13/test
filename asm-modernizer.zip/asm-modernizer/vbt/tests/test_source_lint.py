"""Source lint: detect functions commented out by an unterminated /** doc comment.

Baseline-independent and fast — writes tiny .cpp fixtures to tmp_path and parses them
with tree-sitter directly. Models the real defect (dw710000.cpp:732 swallowing
editCidInquiryInputs): a /** whose */ is missing, so the next */ — belonging to the
NEXT doc comment — closes it, swallowing the function in between.
"""
from vbt.precompute.source_lint import (
    scan_source_for_swallowed, scan_dir, format_report,
)

# A /** doc comment missing its */ runs on until the NEXT doc comment's */, swallowing
# the function between them. Mirrors temp/asm/dw710000.cpp:732..782.
_SWALLOWED = """\
void liveBefore() { return; }

/** docA  #editCidInquiryInputs
 * @brief edits inputs and returns a verdict
 * @param plasticAuth structure
 * @param lwrIso structure
 * @return Pa::Bad or Pa::Good
 *

static Pa::ReturnCode editCidInquiryInputs(PlasticAuth& plasticAuth,
                                           const LwrIso& lwrIso,
                                           LwrCommon& lwrCommon)
{
   if (processEdit4dbcValue(lwrCommon, plasticAuth) == Pa::Bad)
   {
      return Pa::Bad;
   }
   return Pa::Good;
}

/** docB  #processCidInquiry
 * @brief next function, this comment's */ closes the runaway one above
 */
void processCidInquiry(PlasticAuth& plasticAuth) { return; }
"""

# Well-formed: closed doc comments + a legitimately //-commented-out example block.
# Must NOT be flagged.
_CLEAN = """\
/** docA
 * @brief a normal, properly closed doc comment that even mentions
 *        a return value Pa::Bad and names editCardNumber() in prose
 * @return Pa::Good
 */
static Pa::ReturnCode editCidInquiryInputs(PlasticAuth& p) { return Pa::Good; }

//Pa::ReturnCode editCardNumber(LwrIso& lwrIso)
//{
//   return Pa::Bad;
//}

void other() { return; }
"""

# Two real functions swallowed by one runaway comment.
_MULTI = """\
/** docA
 * @return int
 *

static int getNumberOfNoGoodItems(PrePaymentVariables& pre)
{
   return pre.count;
}

static int getHighestInternalRemit(PrePaymentVariables& pre)
{
   return pre.remit;
}

/** next
 */
void liveAfter() { return; }
"""


# A swallowed function whose long multi-line parameter list pushes the body `{` far
# below the signature line (mirrors nm120100.cpp accessHsmIVR: `{` ~12 lines down).
_LONG_SIG = """\
/*
ValidationResults* accessHsmIVR(L9x9x& l9x9x,
        const char* const fiveCsc,
        ValidationCodes::KeyIndicator keyIndicator,
        int match3csc,
        int matchi3csc,
        int unMatch3csc,
        int unMatchi3csc,
        char * i3Csc,
        char * i4Csc
)
{
   return valResults;
}

/** next
 */
void liveAfter() { return; }
"""


def _write(tmp_path, name, text):
    p = tmp_path / name
    p.write_text(text)
    return str(p)


def test_unterminated_comment_swallows_function(tmp_path):
    found = scan_source_for_swallowed(_write(tmp_path, "a.cpp", _SWALLOWED))
    names = {f.function for f in found}
    assert "editCidInquiryInputs" in names
    f = next(f for f in found if f.function == "editCidInquiryInputs")
    assert f.comment_open_line == 3                 # the runaway /** docA line
    assert f.function_line == 10                     # the `static Pa::ReturnCode ...` line
    # the live functions are NOT in the comment → not flagged
    assert "liveBefore" not in names and "processCidInquiry" not in names


def test_well_formed_source_no_false_positive(tmp_path):
    found = scan_source_for_swallowed(_write(tmp_path, "clean.cpp", _CLEAN))
    assert found == [], [f.function for f in found]   # closed comments + // examples ignored


def test_multiple_functions_in_one_runaway_comment(tmp_path):
    found = scan_source_for_swallowed(_write(tmp_path, "m.cpp", _MULTI))
    names = {f.function for f in found}
    assert {"getNumberOfNoGoodItems", "getHighestInternalRemit"} <= names
    assert "liveAfter" not in names


def test_long_multiline_signature_is_caught(tmp_path):
    # the body `{` sits ~11 lines below the signature line — must still be detected,
    # and the body `if`/`return` statements must NOT be reported as functions.
    found = scan_source_for_swallowed(_write(tmp_path, "h.cpp", _LONG_SIG))
    names = {f.function for f in found}
    assert names == {"accessHsmIVR"}, names


def test_scan_dir_aggregates_and_is_deterministic(tmp_path):
    _write(tmp_path, "a.cpp", _SWALLOWED)
    _write(tmp_path, "clean.cpp", _CLEAN)
    _write(tmp_path, "m.cpp", _MULTI)
    out1 = scan_dir(tmp_path, parallel=False)
    out2 = scan_dir(tmp_path, parallel=False)
    assert [(f.file, f.function) for f in out1] == [(f.file, f.function) for f in out2]
    files = {f.file for f in out1}
    assert files == {"a.cpp", "m.cpp"}               # clean.cpp contributes nothing
    assert "swallows" in format_report(out1)
