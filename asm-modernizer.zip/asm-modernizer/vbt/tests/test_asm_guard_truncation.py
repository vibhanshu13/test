"""Regression guard: when a NECESSARY cross-block ASM guard sits past the
``max_levels`` CFG-depth cap, ``collect_asm_conditions`` must (a) omit that guard
and (b) report ``truncated=True``, so the engine never reports the setter as
``unconditionalAtSetter`` (a false positive) on a depth-truncated trace.

Topology: a linear dominator chain  A -> B -> C -> D  with the setter in D and a
TM/JNO guard gating each hop. Backward depth from D is C=1, B=2, A=3. The
``_ASM_DOM_CACHE`` is seeded directly so the test owns the CFG without an on-disk
blueprint; the per-block flow (used by the gate + same-block steps) lives in bp_data.
"""
from vbt.conditions.asm_conditions import collect_asm_conditions, _ASM_DOM_CACHE


def _blk(bid, insts, args, lines):
    return {"id": bid, "flow": {"i": insts, "a": args, "l": lines}}


# Setter in D; each upstream block guards the single hop to its successor.
_BP_DATA = {"blocks": [
    _blk("A", ["TM", "JNO"], [["FLAGA", "X'01'"], ["B"]], [100, 101]),
    _blk("B", ["TM", "JNO"], [["FLAGB", "X'01'"], ["C"]], [200, 201]),
    _blk("C", ["TM", "JNO"], [["FLAGC", "X'01'"], ["D"]], [300, 301]),
    _blk("D", ["MVC"],       [["DEST", "SRC"]],          [400]),
]}
_PATH = "/__asm_guard_truncation_test__.asm.json"
_CFG_OUT = {"A": ["B"], "B": ["C"], "C": ["D"], "D": []}
_CFG_IN = {"A": [], "B": ["A"], "C": ["B"], "D": ["C"]}
_DOM = {"A": {"A"}, "B": {"A", "B"}, "C": {"A", "B", "C"}, "D": {"A", "B", "C", "D"}}


def _collect(max_levels):
    _ASM_DOM_CACHE[_PATH] = (_DOM, _CFG_OUT, _CFG_IN)
    try:
        return collect_asm_conditions(_BP_DATA, _PATH, "D", before_line=401,
                                      file="x.asm", max_levels=max_levels)
    finally:
        _ASM_DOM_CACHE.pop(_PATH, None)


def test_deep_guard_truncated_is_flagged_and_omitted():
    # max_levels=2 keeps C (depth 1) and B (depth 2) but drops A (depth 3).
    conds, truncated = _collect(max_levels=2)
    assert truncated is True, "dropping a dominator past the depth cap must set truncated"
    fields = " ".join(c.condition for c in conds)
    assert "FLAGC" in fields and "FLAGB" in fields, "in-cap guards must still be collected"
    assert "FLAGA" not in fields, "the over-deep dominator's guard must be omitted"


def test_within_cap_is_not_flagged_and_keeps_all_guards():
    # max_levels=10 reaches every dominator (deepest is A at depth 3).
    conds, truncated = _collect(max_levels=10)
    assert truncated is False, "no dominator dropped → no truncation"
    fields = " ".join(c.condition for c in conds)
    assert "FLAGA" in fields and "FLAGB" in fields and "FLAGC" in fields, \
        "every gating dominator guard must be collected when nothing is capped"
