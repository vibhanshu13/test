"""Issue 1: setter ``chain`` carries C++ function entries (``stem::fn``).

Unit coverage for the pure chain-label helpers in ``vbt.engine``:
  * ``_chain_label`` formats a C++ hop as ``stem::fn`` and ASM / function-less hops
    as a bare stem (never invents a label);
  * ``_chain_stem`` peels a label back to its file stem (idempotent on a bare stem);
  * ``_merge_chain`` is an order-preserving union deduped BY LABEL (GAP 8): a file may
    appear more than once, once per distinct intra-file function entered, while a bare
    stem and a qualified label for the same file still collapse to one node (P1) and a
    qualified label is never downgraded to a later bare stem (P5).
  * ``_chain_richness`` ranks chains (len, then qualified-hop count) so the prefer-richest
    dedup keeps the most informative chain among entries with the same file-path identity.

The end-to-end format (real trace) is exercised by the reachability fixture's R5.
"""
from __future__ import annotations

from pathlib import Path

from vbt.engine import _chain_label, _chain_stem, _chain_richness, _merge_chain


# --------------------------------------------------------------------------- #
# _chain_label
# --------------------------------------------------------------------------- #
def test_chain_label_cpp_with_fn():
    assert _chain_label("dw710000", "cpp", "fn") == "dw710000::fn"


def test_chain_label_asm_stays_stem():
    assert _chain_label("nb81", "asm", None) == "nb81"
    # an ASM hop with a (nominal) function is STILL a stem — modules are single-entry.
    assert _chain_label("nb81", "asm", "NB81") == "nb81"


def test_chain_label_cpp_without_fn_falls_back_to_stem():
    # guardrail: never invent a label when the function is unknown.
    assert _chain_label("dw710000", "cpp", None) == "dw710000"
    assert _chain_label("dw710000", "cpp", "") == "dw710000"


def test_chain_label_unknown_filetype_is_stem():
    assert _chain_label("foo") == "foo"
    assert _chain_label("foo", None, "bar") == "foo"


# --------------------------------------------------------------------------- #
# _chain_stem
# --------------------------------------------------------------------------- #
def test_chain_stem_strips_function():
    assert _chain_stem("dw710000::fn") == "dw710000"


def test_chain_stem_idempotent_on_bare_stem():
    assert _chain_stem("dw710000") == "dw710000"
    assert _chain_stem(_chain_stem("dw710000::fn")) == "dw710000"


def test_chain_stem_keeps_only_first_segment():
    # split on the FIRST "::" only — a C++ qualified name keeps the rest intact-free stem.
    assert _chain_stem("dw::a::b") == "dw"


# --------------------------------------------------------------------------- #
# _merge_chain
# --------------------------------------------------------------------------- #
def test_merge_chain_basic_order_preserving():
    prefix = [("dw710000", "dw710000::entry")]
    path = [("dw710000", "dw710000::internal"), ("dw780000", "dw780000::setterFn")]
    # GAP 8: distinct functions of the same file are KEPT (intra-file hops), so the
    # internal hop is no longer collapsed away.
    assert _merge_chain(prefix, path) == [
        "dw710000::entry", "dw710000::internal", "dw780000::setterFn"]


def test_merge_chain_keeps_distinct_functions_same_stem():
    # GAP 8 (was test_merge_chain_dedupes_by_stem_not_label): same stem, different
    # functions → TWO hops now, in order (the intra-file flow is surfaced).
    prefix = [("aa71", "aa71")]
    path = [("dw730000", "dw730000::DW73"), ("dw730000", "dw730000::other")]
    assert _merge_chain(prefix, path) == ["aa71", "dw730000::DW73", "dw730000::other"]


def test_merge_chain_upgrades_bare_stem_to_qualified_label():
    # an earlier bare-stem hop is upgraded when a later path edge qualifies the same file.
    prefix = [("dw710000", "dw710000")]            # prefix only had the stem
    path = [("dw710000", "dw710000::realFn")]      # later hop knows the function
    assert _merge_chain(prefix, path) == ["dw710000::realFn"]


def test_merge_chain_does_not_downgrade_qualified_label():
    # the inverse: a qualified label is NOT replaced by a later bare stem.
    prefix = [("dw710000", "dw710000::realFn")]
    path = [("dw710000", "dw710000")]
    assert _merge_chain(prefix, path) == ["dw710000::realFn"]


def test_merge_chain_asm_then_cpp_full_chain():
    # a realistic mixed chain: ASM prefix hop, then C++ hops into the setter file.
    prefix = [("aa71", "aa71"), ("dw730000", "dw730000::DW73")]
    path = [("dw730000", "dw730000::DW73"),
            ("dw710000", "dw710000::callPlasticAuthenticationComponentInterface")]
    assert _merge_chain(prefix, path) == [
        "aa71",
        "dw730000::DW73",
        "dw710000::callPlasticAuthenticationComponentInterface",
    ]


def test_merge_chain_empty():
    assert _merge_chain([], []) == []
    assert _merge_chain([("a", "a::x")], []) == ["a::x"]
    assert _merge_chain([], [("a", "a::x")]) == ["a::x"]


def test_merge_chain_bare_then_two_functions_same_stem():
    # E7: a bare entry placeholder is upgraded to the FIRST function, then the second
    # distinct function is appended (P1 upgrade + P3 keep-distinct).
    assert _merge_chain([("dw", "dw")], [("dw", "dw::a"), ("dw", "dw::b")]) == ["dw::a", "dw::b"]


def test_merge_chain_file_leaves_and_returns():
    # E8: a file can appear, another file intervenes, then the first file returns with a
    # different function — all three hops are kept in order.
    chain = _merge_chain([], [("dw", "dw::a"), ("x", "x::p"), ("dw", "dw::b")])
    assert chain == ["dw::a", "x::p", "dw::b"]


def test_merge_chain_qualified_then_bare_dropped_keeps_later_hops():
    # A bare hop arriving after the file is already qualified is dropped (P1), and a
    # later distinct function for the same file is still kept (P3).
    chain = _merge_chain([("dw", "dw::a")], [("dw", "dw"), ("dw", "dw::b")])
    assert chain == ["dw::a", "dw::b"]


def test_merge_chain_exact_duplicate_label_dropped():
    # P2: the exact same label never appears twice.
    chain = _merge_chain([("dw", "dw::a")], [("dw", "dw::a"), ("x", "x::p")])
    assert chain == ["dw::a", "x::p"]


# --------------------------------------------------------------------------- #
# _chain_richness
# --------------------------------------------------------------------------- #
def test_chain_richness_orders_by_len_then_qualified():
    # more hops wins.
    assert _chain_richness(["a", "b", "c"]) > _chain_richness(["a", "b"])
    # equal length → more function-qualified hops wins.
    assert _chain_richness(["a::f", "b::g"]) > _chain_richness(["a", "b"])
    assert _chain_richness(["a::f", "b"]) > _chain_richness(["a", "b"])


def test_chain_richness_tie_is_not_greater():
    # equal length AND equal qualification → tie (first-enumerated wins at the call site).
    assert not (_chain_richness(["a::f", "b::g"]) > _chain_richness(["x::p", "y::q"]))
    assert _chain_richness(["a::f", "b::g"]) == _chain_richness(["x::p", "y::q"])


# --------------------------------------------------------------------------- #
# _route_path_chain (TC-01): mixed ASM/C++ route chain builder
# --------------------------------------------------------------------------- #
from vbt.engine import _route_path_chain, Hop          # noqa: E402
from vbt.interfaces import SetterSite                  # noqa: E402


class _FakeRoute:
    """Minimal RouteEngine stand-in: the node-type accessors the helper reads, plus
    ``cpp_call_edges`` for the GAP-8 intra-file reconstruction.

    ``preloaded=False`` simulates a route-cache hit where ``_node_type`` is still
    None and the helper must fall back to ``node_types()``. ``call_edges`` maps a stem
    to its ``[(caller_fn, callee_fn, line), ...]`` intra-file call edges."""
    def __init__(self, node_types, preloaded=True, call_edges=None):
        self._types = dict(node_types)
        self._node_type = dict(node_types) if preloaded else None
        self._call_edges = dict(call_edges or {})

    def node_types(self):
        return dict(self._types)

    def cpp_call_edges(self, stem):
        return list(self._call_edges.get(stem, []))


def _setter(stem, language, function=None, line=10):
    return SetterSite(variable="v", file_stem=stem, language=language, line=line,
                      instruction="assign", block_id=function or "fn",
                      function=function)


# No .cpp files live here, so the GAP-8 intra-file reconstruction guard
# ``(asm_dir / f"{stem}.cpp").exists()`` is False → these tests exercise the pure
# file-level hop building (byte-identical to pre-GAP-8 _route_path_chain output).
_NO_ASM = Path("/nonexistent/asm/dir/for/route_path_chain/tests")


def _rpc(rt, *, tail, setter, route, cfg_cache=None, asm_dir=_NO_ASM, **kw):
    """Call _route_path_chain and return ONLY the hop list (the helper now also returns
    an intra-truncation flag). Supplies the GAP-8 cfg_cache/asm_dir kwargs."""
    hops, _trunc = _route_path_chain(
        rt, tail=tail, setter=setter, route=route,
        cfg_cache={} if cfg_cache is None else cfg_cache, asm_dir=asm_dir, **kw)
    return hops


def test_route_path_chain_mixed_asm_to_cpp():
    # The canonical TC-01 route: ASM tail (aa71) reaching a C++ setter (dw710000)
    # through a C++ hop (dw730000) and an ASM hop (nb81).
    rt = {
        "files": ["aa71", "dw730000", "nb81", "dw710000"],
        "hops": [
            {"from_file": "aa71", "to_file": "dw730000", "to_function": "DW73"},
            {"from_file": "dw730000", "to_file": "nb81", "from_function": "DW73"},
            {"from_file": "nb81", "to_file": "dw710000",
             "to_function": "callPlasticAuthenticationComponentInterface"},
        ],
    }
    route = _FakeRoute({"aa71": "asm", "dw730000": "cpp", "nb81": "asm", "dw710000": "cpp"})
    tail = Hop("aa71", "asm", None)
    s = _setter("dw710000", "cpp", "callPlasticAuthenticationComponentInterface")
    assert _rpc(rt, tail=tail, setter=s, route=route) == [
        ("aa71", "aa71"),
        ("dw730000", "dw730000::DW73"),
        ("nb81", "nb81"),
        ("dw710000", "dw710000::callPlasticAuthenticationComponentInterface"),
    ]


def test_route_path_chain_missing_to_function_falls_back_to_stem():
    # A C++ hop whose route edge carries no to_function stays a bare stem (no invention).
    rt = {
        "files": ["aa71", "dw730000"],
        "hops": [{"from_file": "aa71", "to_file": "dw730000"}],   # no to_function
    }
    route = _FakeRoute({"aa71": "asm", "dw730000": "cpp"})
    out = _rpc(rt, tail=Hop("aa71", "asm", None),
                            setter=_setter("dw730000", "cpp", None), route=route)
    assert out == [("aa71", "aa71"), ("dw730000", "dw730000")]


def test_route_path_chain_non_cpp_node_type_is_never_formatted():
    # Even with a function present, an ASM-typed hop is never ``stem::fn``.
    rt = {
        "files": ["aa71", "nb81"],
        "hops": [{"from_file": "aa71", "to_file": "nb81", "to_function": "NB81X"}],
    }
    route = _FakeRoute({"aa71": "asm", "nb81": "asm"})
    out = _rpc(rt, tail=Hop("aa71", "asm", None),
                            setter=_setter("nb81", "asm", None), route=route)
    assert out == [("aa71", "aa71"), ("nb81", "nb81")]


def test_route_path_chain_infers_cpp_from_to_function_when_type_absent():
    # site_target_fn() returns a function only for C++ targets, so a non-empty
    # to_function with no recorded node type can be safely typed C++.
    rt = {
        "files": ["aa71", "dw730000"],
        "hops": [{"from_file": "aa71", "to_file": "dw730000", "to_function": "DW73"}],
    }
    route = _FakeRoute({})        # node type map has no entry for dw730000
    out = _rpc(rt, tail=Hop("aa71", "asm", None),
                            setter=_setter("dw730000", "cpp", "DW73"), route=route)
    assert out == [("aa71", "aa71"), ("dw730000", "dw730000::DW73")]


def test_route_path_chain_setter_function_fallback():
    # The setter file uses the engine's authoritative setter.function when the hop
    # edge did not name one.
    rt = {
        "files": ["aa71", "dw710000"],
        "hops": [{"from_file": "aa71", "to_file": "dw710000"}],   # no to_function
    }
    route = _FakeRoute({"aa71": "asm", "dw710000": "cpp"})
    out = _rpc(rt, tail=Hop("aa71", "asm", None),
                            setter=_setter("dw710000", "cpp", "callPlasticAuthenticationComponentInterface"),
                            route=route)
    assert out == [("aa71", "aa71"),
                   ("dw710000", "dw710000::callPlasticAuthenticationComponentInterface")]


def test_route_path_chain_falls_back_to_node_types_method():
    # A preloaded route-cache hit returns before _ensure_graph() ran (_node_type
    # still None); the helper must fall back to node_types().
    rt = {
        "files": ["aa71", "dw730000"],
        "hops": [{"from_file": "aa71", "to_file": "dw730000", "to_function": "DW73"}],
    }
    route = _FakeRoute({"aa71": "asm", "dw730000": "cpp"}, preloaded=False)
    assert route._node_type is None
    out = _rpc(rt, tail=Hop("aa71", "asm", None),
                            setter=_setter("dw730000", "cpp", "DW73"), route=route)
    assert out == [("aa71", "aa71"), ("dw730000", "dw730000::DW73")]


def test_route_path_chain_pure_asm_route_is_unchanged():
    # Pure-ASM route: every hop stays a bare stem (byte-identical to the old
    # ``[(f, f) for f in rt_files]`` — guards LG1OSI-style traces against drift).
    rt = {
        "files": ["da78", "ag41", "lg10"],
        "hops": [
            {"from_file": "da78", "to_file": "ag41", "to_function": ""},
            {"from_file": "ag41", "to_file": "lg10", "to_function": ""},
        ],
    }
    route = _FakeRoute({"da78": "asm", "ag41": "asm", "lg10": "asm"})
    out = _rpc(rt, tail=Hop("da78", "asm", None),
                            setter=_setter("lg10", "asm", None), route=route)
    assert out == [("da78", "da78"), ("ag41", "ag41"), ("lg10", "lg10")]


def test_route_path_chain_then_merge_dedupes_by_stem():
    # End-to-end with _merge_chain: the chain dedupes BY STEM, so adding C++ function
    # labels never changes the file-count (entry-count invariant of TC-01).
    rt = {
        "files": ["aa71", "dw730000", "dw710000"],
        "hops": [
            {"from_file": "aa71", "to_file": "dw730000", "to_function": "DW73"},
            {"from_file": "dw730000", "to_file": "dw710000",
             "to_function": "callPlasticAuthenticationComponentInterface"},
        ],
    }
    route = _FakeRoute({"aa71": "asm", "dw730000": "cpp", "dw710000": "cpp"})
    path = _rpc(rt, tail=Hop("aa71", "asm", None),
                             setter=_setter("dw710000", "cpp",
                                            "callPlasticAuthenticationComponentInterface"),
                             route=route)
    # the prefix already carries the qualified tail (aa71) — merge keeps one entry per stem.
    prefix = [("aa71", "aa71")]
    merged = _merge_chain(prefix, path)
    assert merged == ["aa71", "dw730000::DW73",
                      "dw710000::callPlasticAuthenticationComponentInterface"]
    assert [_chain_stem(c) for c in merged] == ["aa71", "dw730000", "dw710000"]


# --------------------------------------------------------------------------- #
# _route_path_chain GAP 8: intra-file C++ hops on mixed / ASM-tail routes (§7.1)
# --------------------------------------------------------------------------- #
def test_route_path_chain_intra_file_setter_segment_surfaces_hops(tmp_path):
    # ASM tail (aa71) → C++ setter file (dw710000). The setter sits in fn C, the file is
    # ENTERED at fn A; the verified intra path A→B→C is now inlined as stem::fn hops.
    (tmp_path / "dw710000.cpp").write_text("")
    rt = {
        "files": ["aa71", "dw710000"],
        "hops": [{"from_file": "aa71", "to_file": "dw710000", "to_function": "A"}],
    }
    route = _FakeRoute({"aa71": "asm", "dw710000": "cpp"},
                       call_edges={"dw710000": [("A", "B", 10), ("B", "C", 20)]})
    out = _rpc(rt, tail=Hop("aa71", "asm", None),
              setter=_setter("dw710000", "cpp", "C"), route=route,
              cfg_cache={"dw710000": [{"function": "A"}, {"function": "B"}, {"function": "C"}]},
              asm_dir=tmp_path)
    assert out == [("aa71", "aa71"),
                   ("dw710000", "dw710000::A"),
                   ("dw710000", "dw710000::B"),
                   ("dw710000", "dw710000::C")]
    # the merged chain keeps all the intra-file functions, file sequence unchanged.
    merged = _merge_chain([], out)
    assert merged == ["aa71", "dw710000::A", "dw710000::B", "dw710000::C"]
    assert [_chain_stem(c) for c in merged] == ["aa71", "dw710000", "dw710000", "dw710000"]


def test_route_path_chain_intra_file_intermediate_segment(tmp_path):
    # Mixed route asm → cpp(entry→mid→exit) → cpp(setter): the intermediate C++ file's
    # entry→exit path is inlined; the ASM file stays a bare stem; the setter file (entry
    # == setter fn) adds no intra hop.
    (tmp_path / "dw710000.cpp").write_text("")
    (tmp_path / "dw780000.cpp").write_text("")
    rt = {
        "files": ["aa71", "dw710000", "dw780000"],
        "hops": [
            {"from_file": "aa71", "to_file": "dw710000", "to_function": "entry"},
            {"from_file": "dw710000", "to_file": "dw780000",
             "from_function": "exit", "to_function": "setFn"},
        ],
    }
    route = _FakeRoute({"aa71": "asm", "dw710000": "cpp", "dw780000": "cpp"},
                       call_edges={"dw710000": [("entry", "mid", 1), ("mid", "exit", 2)]})
    out = _rpc(rt, tail=Hop("aa71", "asm", None),
              setter=_setter("dw780000", "cpp", "setFn"), route=route,
              cfg_cache={"dw710000": [{"function": "entry"}, {"function": "mid"},
                                      {"function": "exit"}],
                         "dw780000": [{"function": "setFn"}]},
              asm_dir=tmp_path)
    assert out == [("aa71", "aa71"),
                   ("dw710000", "dw710000::entry"),
                   ("dw710000", "dw710000::mid"),
                   ("dw710000", "dw710000::exit"),
                   ("dw780000", "dw780000::setFn")]


def test_route_path_chain_no_intra_edges_is_unchanged(tmp_path):
    # A C++ segment with no verified intra-file call path adds NO hops (byte-identical to
    # pre-GAP-8): only the entered function shows.
    (tmp_path / "dw710000.cpp").write_text("")
    rt = {
        "files": ["aa71", "dw710000"],
        "hops": [{"from_file": "aa71", "to_file": "dw710000", "to_function": "A"}],
    }
    route = _FakeRoute({"aa71": "asm", "dw710000": "cpp"}, call_edges={})   # no edges
    out = _rpc(rt, tail=Hop("aa71", "asm", None),
              setter=_setter("dw710000", "cpp", "C"), route=route,
              cfg_cache={"dw710000": [{"function": "A"}, {"function": "C"}]},
              asm_dir=tmp_path)
    assert out == [("aa71", "aa71"), ("dw710000", "dw710000::A")]


def test_route_path_chain_intra_truncation_flag(tmp_path):
    # The intra-file truncation flag is surfaced so pathsCapped stays honest on mixed routes.
    (tmp_path / "dw710000.cpp").write_text("")
    rt = {
        "files": ["aa71", "dw710000"],
        "hops": [{"from_file": "aa71", "to_file": "dw710000", "to_function": "A"}],
    }
    # two distinct A→C paths; max_paths=1 forces truncation.
    route = _FakeRoute({"aa71": "asm", "dw710000": "cpp"},
                       call_edges={"dw710000": [("A", "m1", 1), ("A", "m2", 2),
                                                ("m1", "C", 3), ("m2", "C", 4)]})
    hops, trunc = _route_path_chain(
        rt, tail=Hop("aa71", "asm", None), setter=_setter("dw710000", "cpp", "C"),
        route=route,
        cfg_cache={"dw710000": [{"function": "A"}, {"function": "m1"},
                                {"function": "m2"}, {"function": "C"}]},
        asm_dir=tmp_path, max_paths=1)
    assert trunc is True
    assert hops[0] == ("aa71", "aa71")               # ASM tail stays bare
    assert ("dw710000", "dw710000::A") in hops       # the entered function is present


def test_route_path_chain_asm_segment_stays_bare(tmp_path):
    # An ASM file on the route never gets intra-file hops (no ASM call graph yet) even if
    # call_edges were (erroneously) supplied — the cpp-only guard protects it.
    rt = {
        "files": ["aa71", "nb81"],
        "hops": [{"from_file": "aa71", "to_file": "nb81", "to_function": ""}],
    }
    route = _FakeRoute({"aa71": "asm", "nb81": "asm"},
                       call_edges={"nb81": [("X", "Y", 1)]})
    out = _rpc(rt, tail=Hop("aa71", "asm", None),
              setter=_setter("nb81", "asm", None), route=route, asm_dir=tmp_path)
    assert out == [("aa71", "aa71"), ("nb81", "nb81")]
