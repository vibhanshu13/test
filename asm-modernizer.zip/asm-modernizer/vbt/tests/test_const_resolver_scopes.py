"""Regression: the const resolver's source-enum parser must qualify enumerators by the
ENCLOSING struct/class, not only the inner enum name.

The z/TPF corpus uses the `struct X { enum Type { ... } }` namespace idiom (e.g.
`SoftCardValueDetail`), and the code spells the constants `X::Const` — because an
*unscoped* enum's members leak into the enclosing struct's scope. A parser that scoped
only by the inner enum (`Type::Const`) forced resolution through the lossy bare-tail
fallback (collision-prone at scale). The brace-aware scanner must emit the exact
`X::Const` key. No type names are hard-coded — this is generic structural parsing.
"""
import textwrap

from vbt.resolve.const_resolver import _cpp_pairs_from_source, ConstResolver


def _resolver(tmp_path, src):
    (tmp_path / "t.hpp").write_text(textwrap.dedent(src))
    cr = ConstResolver()
    for k, v in _cpp_pairs_from_source(str(tmp_path / "t.hpp")):
        cr.cpp_enum.setdefault(k, v)
    return cr


def test_struct_wrapped_enum_scoped_by_struct(tmp_path):
    cr = _resolver(tmp_path, """
        struct Sc {
            enum Type {
                Zero = 0,
                One,          // auto -> 1
                Two  = 5,
                Three,        // auto -> 6
                Ch   = 'Z'    // char literal kept verbatim
            };
        };
    """)
    # the EXACT key the code uses (struct-scoped) resolves on its own key:
    assert cr.resolve("Sc::Zero", "cpp") == "0"
    assert cr.resolve("Sc::One", "cpp") == "1"      # implicit auto-increment
    assert cr.resolve("Sc::Two", "cpp") == "5"
    assert cr.resolve("Sc::Three", "cpp") == "6"    # auto-increment after explicit 5
    assert cr.resolve("Sc::Ch", "cpp") == "'Z'"     # char literal verbatim
    # the inner-enum and bare spellings still resolve too
    assert cr.resolve("Type::Zero", "cpp") == "0"
    assert cr.resolve("Zero", "cpp") == "0"


def test_top_level_enum_class_still_works(tmp_path):
    cr = _resolver(tmp_path, """
        enum class Cas : int { On = 1, Off };
    """)
    assert cr.resolve("Cas::On", "cpp") == "1"
    assert cr.resolve("Cas::Off", "cpp") == "2"


def test_nested_namespace_struct_enum(tmp_path):
    cr = _resolver(tmp_path, """
        namespace pa {
            struct Ind { enum Type { A = 0x10, B = 0x20 }; };
        }
    """)
    # enclosing chain is qualified; the struct-scoped spelling the code uses resolves
    assert cr.resolve("pa::Ind::A", "cpp") == "0x10"
    assert cr.resolve("Ind::B", "cpp") == "0x20"
    assert cr.resolve("B", "cpp") == "0x20"
