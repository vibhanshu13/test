"""GAP 2 — C++ search-loop match condition recovery (``_extract_loop_breaks``).

A search loop ``do { … if(match) break; … } while(more); if(!found) return;`` reaches code
after the loop ONLY when it broke (matched); the normal loop exit is filtered out by the
post-loop ``if(!found) return``. The guards that gate the ``break`` are therefore necessary
for any setter after the loop, but are invisible to AST nesting and to the dominance-based
early-exit gate. ``_extract_loop_breaks`` recovers them.

Two layers of tests:
  * SYNTHETIC CFG dicts driving ``_extract_loop_breaks`` directly — no compiler needed, and
    they pin the soundness gates (polarity coupling, multiple breaks, unclean shape).
  * INTEGRATION through ``collect_cpp_conditions`` on a compiled search-loop fixture — guarded
    by the presence of the ``cfg_extract`` binary.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from vbt.conditions.cpp_conditions import (
    _cfg_dominators,
    _extract_loop_breaks,
    collect_cpp_conditions,
    clear_cpp_conditions_cache,
)

_CFG_BIN = Path("vbt/cpp_frontend/cfg_extract")
_skip = pytest.mark.skipif(not _CFG_BIN.exists(), reason="clang cfg_extract binary not built")


# --------------------------------------------------------------------------- #
# Synthetic CFG helpers
# --------------------------------------------------------------------------- #
def _b(bid, kind, succs, cond=None, lines=(), stmt_kinds=()):
    """Build one CFG block dict. ``succs`` = [(label, block_id), …]."""
    stmts = [{"line": ln} for ln in lines] + [{"kind": k} for k in stmt_kinds]
    return {
        "id": bid,
        "terminator_kind": kind,
        "terminator_cond_expr": cond,
        "succs": [{"label": lbl, "block_id": t} for lbl, t in succs],
        "stmts": stmts,
    }


def _run(block_list):
    blocks = {b["id"]: b for b in block_list}
    dom = _cfg_dominators(blocks)
    return _extract_loop_breaks(blocks, dom)


def _guard_pairs(patterns):
    """Flatten patterns → {(text, polarity)} across all D blocks."""
    return {(t, p) for _D, gs in patterns for (t, p, _ln) in gs}


# A faithful search loop: a pre-break guard `rc == 0` whose FALSE arm skips to the latch
# (so it does NOT dominate the latch), nested `match` break, do-while latch `more`, and the
# post-loop guard `!(more)` returning. Mirrors dw780100::updateCidTransactionIndicators.
def _search_loop_blocks(d_cond="!(more)", extra_pred=False):
    blocks = [
        _b(100, "none", [("unconditional", 26)]),                       # entry
        _b(26, "if", [("true", 24), ("false", 22)], cond="rc == 0", lines=[8]),
        _b(24, "if", [("true", 23), ("false", 22)], cond="match", lines=[10]),
        _b(23, "break", [("unconditional", 20)]),                       # the break
        _b(22, "none", [("unconditional", 21)], lines=[12]),            # i++
        _b(21, "do", [("true", 26), ("false", 20)], cond="more", lines=[13]),  # latch
        _b(20, "if", [("true", 19), ("false", 18)], cond=d_cond, lines=[15]),  # post-loop guard D
        _b(19, "none", [("unconditional", 0)], stmt_kinds=["return"]),  # return
        _b(18, "none", [("unconditional", 0)], lines=[50]),             # setter (after loop)
        _b(0, "none", []),                                             # exit
    ]
    if extra_pred:
        # A third predecessor of D that is neither the latch nor a break → unclean shape.
        blocks.append(_b(70, "none", [("unconditional", 20)], lines=[14]))
        blocks.insert(0, _b(101, "none", [("unconditional", 70)]))  # keep 70 reachable
        # rewire entry 100 to also be reachable; give 101 no preds so it is the entry
        blocks[1]["succs"] = [{"label": "unconditional", "block_id": 26}]
    return blocks


# --------------------------------------------------------------------------- #
# Synthetic unit tests (no compiler)
# --------------------------------------------------------------------------- #
def test_search_loop_emits_break_guards():
    """The match guard AND the pre-break `rc == 0` guard are recovered, both positive."""
    pats = _run(_search_loop_blocks())
    assert len(pats) == 1
    D, _ = pats[0]
    assert D == 20                       # the post-loop guard dominates the setter
    pairs = _guard_pairs(pats)
    assert ("match", True) in pairs
    assert ("rc == 0", True) in pairs


def test_polarity_coupling_required():
    """If the post-loop guard tests a DIFFERENT predicate than the loop latch, the idiom
    does not hold and NOTHING is emitted (the soundness fingerprint)."""
    pats = _run(_search_loop_blocks(d_cond="!(somethingElse)"))
    assert pats == []


def test_unclean_shape_bails():
    """A predecessor of D that is neither the latch nor a break → bail (under-collect)."""
    pats = _run(_search_loop_blocks(extra_pred=True))
    assert pats == []


def test_reconverging_guard_excluded():
    """A guard whose BOTH arms reach the break (reconverges before the break, like the
    `resultIndicator` check in dw780100) is NOT necessary and must be excluded."""
    # 28 is a reconverging guard: both arms flow into 26 (which gates the break).
    blocks = _search_loop_blocks()
    # insert 28 between entry/back-edge and 26
    for blk in blocks:
        if blk["id"] == 100:
            blk["succs"] = [{"label": "unconditional", "block_id": 28}]
        if blk["id"] == 21:                       # latch back-edge now targets 28
            blk["succs"] = [{"label": "true", "block_id": 28}, {"label": "false", "block_id": 20}]
    blocks.append(_b(28, "if", [("true", 27), ("false", 26)], cond="recon", lines=[6]))
    blocks.append(_b(27, "none", [("unconditional", 26)], lines=[7]))
    pats = _run(blocks)
    pairs = _guard_pairs(pats)
    assert ("match", True) in pairs           # real break guard still recovered
    assert ("rc == 0", True) in pairs
    assert not any(t == "recon" for (t, _p) in pairs)   # reconverging guard excluded


def test_multiple_breaks_only_common_guard():
    """With two breaks, a guard dominating only ONE break is NOT necessary; only a guard
    dominating EVERY break is emitted."""
    blocks = [
        _b(100, "none", [("unconditional", 49)]),
        _b(49, "none", [("unconditional", 40)]),
        _b(40, "if", [("true", 41), ("false", 47)], cond="common", lines=[5]),
        _b(41, "if", [("true", 43), ("false", 42)], cond="cond1", lines=[6]),
        _b(42, "if", [("true", 44), ("false", 47)], cond="cond2", lines=[7]),
        _b(43, "break", [("unconditional", 20)]),
        _b(44, "break", [("unconditional", 20)]),
        _b(47, "none", [("unconditional", 21)], lines=[9]),
        _b(21, "do", [("true", 49), ("false", 20)], cond="more", lines=[10]),
        _b(20, "if", [("true", 19), ("false", 18)], cond="!(more)", lines=[12]),
        _b(19, "none", [("unconditional", 0)], stmt_kinds=["return"]),
        _b(18, "none", [("unconditional", 0)], lines=[50]),
        _b(0, "none", []),
    ]
    pairs = _guard_pairs(_run(blocks))
    assert ("common", True) in pairs                 # dominates both breaks
    assert not any(t in ("cond1", "cond2") for (t, _p) in pairs)


def test_no_loop_fastpath():
    """A loopless function returns no patterns (and hits the fast path)."""
    blocks = [
        _b(100, "none", [("unconditional", 1)]),
        _b(1, "if", [("true", 2), ("false", 3)], cond="c", lines=[2]),
        _b(2, "none", [("unconditional", 3)], lines=[3]),
        _b(3, "none", [], lines=[4]),
    ]
    assert _run(blocks) == []


# --------------------------------------------------------------------------- #
# Integration through collect_cpp_conditions (needs the compiled binary)
# --------------------------------------------------------------------------- #
_SEARCH_LOOP_SRC = (
    "int classify(int n, int rc0, int probe, int key, int* out) {\n"  # 1
    "    int rc = 0;\n"                                                # 2
    "    int found = 0;\n"                                             # 3  pre-loop setter
    "    int i = 0;\n"                                                 # 4
    "    do {\n"                                                       # 5
    "        rc = rc0;\n"                                              # 6
    "        if (rc == 0) {\n"                                         # 7
    "            if (probe == key) {\n"                                # 8
    "                found = 1;\n"                                     # 9
    "                break;\n"                                         # 10
    "            }\n"                                                  # 11
    "        }\n"                                                      # 12
    "        i = i + 1;\n"                                             # 13
    "    } while (i < n);\n"                                           # 14
    "    if (!(i < n)) {\n"                                            # 15
    "        return -1;\n"                                             # 16
    "    }\n"                                                          # 17
    "    found = 2;\n"                                                 # 18  post-loop setter
    "    if (n > 100) {\n"                                             # 19
    "        found = found + 1;\n"                                     # 20
    "    }\n"                                                          # 21
    "    *out = found;\n"                                              # 22
    "    return found;\n"                                              # 23
    "}\n"                                                              # 24
)


@_skip
def test_integration_post_loop_setter_gets_match(tmp_path):
    clear_cpp_conditions_cache()
    f = tmp_path / "searchloop.cpp"
    f.write_text(_SEARCH_LOOP_SRC)
    conds = collect_cpp_conditions(str(f), 18, "classify")
    lb = {(c.condition, c.polarity) for c in conds if c.kind == "loop_break"}
    assert ("probe == key", True) in lb
    assert ("rc == 0", True) in lb


@_skip
def test_integration_pre_loop_setter_unaffected(tmp_path):
    """A setter BEFORE the loop is not dominated by the post-loop guard → no loop_break."""
    clear_cpp_conditions_cache()
    f = tmp_path / "searchloop.cpp"
    f.write_text(_SEARCH_LOOP_SRC)
    conds = collect_cpp_conditions(str(f), 3, "classify")
    assert not any(c.kind == "loop_break" for c in conds)
