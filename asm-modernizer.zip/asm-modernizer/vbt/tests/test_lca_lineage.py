"""Focused tests for vbt/depvars/lca_lineage.py (LCA-feasibility dependency lineage).

Two layers:
  1. PURE unit tests of the LCA + feasibility logic over a synthetic function graph
     (no DB, no corpus).
  2. DB-gated end-to-end runs on the local baseline corpus (skipped when absent),
     including a ZERO-FILE-READ guard: cfg extraction and blueprint/source disk opens
     are patched to raise, so any disk fallback fails the test loudly.

Run:  env/bin/python3 -m pytest vbt/tests/test_lca_lineage.py -v
"""
from __future__ import annotations

from pathlib import Path

import pytest

from vbt.depvars.lca_lineage import _Ctx, _feasibility, _find_lca, run_lca_lineage

PROJECT_ROOT = Path(__file__).resolve().parents[2]
KB = "baseline-temp-asm"
BP_DIR = PROJECT_ROOT / "jobs" / KB / "output"
ASM_DIR = PROJECT_ROOT / "temp" / "asm"
_HAVE_DB = (PROJECT_ROOT / "jobs" / KB / "index.db").is_file() and ASM_DIR.is_dir()
_db = pytest.mark.skipif(not _HAVE_DB, reason="baseline-temp-asm fixture not present")

ENTRY = {"stem": "dw710000", "file_type": "cpp",
         "function": "callPlasticAuthenticationComponentInterface"}


# --------------------------------------------------------------------------- #
# synthetic-graph unit tests
# --------------------------------------------------------------------------- #
def _mk_ctx(adj, node_types=None):
    """Minimal ctx over a synthetic adjacency {node: {(stem, fn, line, cross), ...}}."""
    types = node_types or {}
    for (s, _f) in adj:
        types.setdefault(s, "cpp")
    for outs in adj.values():
        for (cs, _cf, _l, _c) in outs:
            types.setdefault(cs, "cpp")
    graph_nodes = set(adj)
    for outs in adj.values():
        for (cs, cf, _l, _c) in outs:
            graph_nodes.add((cs, cf))
    return _Ctx("test-job", Path("."), Path("."), adj, types, graph_nodes,
                {}, {}, midx=None, warnings=[], max_order_nodes=1000)


# Graph:  root::main -L10-> a::setter_fn ; root::main -L20-> b::entry_fn
#         b::entry_fn -L5-> c::deep ;  island::x isolated
ADJ = {
    ("root", "main"): {("a", "setter_fn", 10, False), ("b", "entry_fn", 20, False)},
    ("b", "entry_fn"): {("c", "deep", 5, False)},
    ("island", "x"): set(),
}


def test_sibling_setter_before_entry_is_feasible():
    ctx = _mk_ctx(ADJ)
    lca, feasible, reason = _feasibility(ctx, ("a", "setter_fn"), 99, ("b", "entry_fn"), None)
    assert lca == ("root", "main")
    assert feasible and reason == "setter-before-entry"


def test_sibling_entry_before_setter_is_infeasible():
    # swap call-site lines: entry branch first
    adj = {("root", "main"): {("a", "setter_fn", 30, False), ("b", "entry_fn", 20, False)},
           ("b", "entry_fn"): set()}
    ctx = _mk_ctx(adj)
    lca, feasible, reason = _feasibility(ctx, ("a", "setter_fn"), 99, ("b", "entry_fn"), None)
    assert lca == ("root", "main")
    assert not feasible and reason == "entry-before-setter"


def test_no_common_ancestor_is_infeasible():
    ctx = _mk_ctx(ADJ)
    lca, feasible, reason = _feasibility(ctx, ("island", "x"), 1, ("b", "entry_fn"), None)
    assert lca is None
    assert not feasible and reason == "no-lca"


def test_downstream_of_root_entry_is_feasible():
    # setter deep under the entry, root entry (no line) => feasible
    ctx = _mk_ctx(ADJ)
    lca, feasible, reason = _feasibility(ctx, ("c", "deep"), 42, ("b", "entry_fn"), None)
    assert lca == ("b", "entry_fn")
    assert feasible and reason == "downstream-of-entry"


def test_downstream_call_vs_read_line():
    # dep-var entry with read line: descent at line 5 must precede the read
    ctx = _mk_ctx(ADJ)
    _, ok_after, r_after = _feasibility(ctx, ("c", "deep"), 42, ("b", "entry_fn"), 3)
    assert not ok_after and r_after == "downstream-call-after-read"
    ctx2 = _mk_ctx(ADJ)
    _, ok_before, r_before = _feasibility(ctx2, ("c", "deep"), 42, ("b", "entry_fn"), 9)
    assert ok_before and r_before == "downstream-call-before-read"


def test_setter_on_path_to_entry_line_bound():
    # setter's fn is an ancestor of the entry; feasible only if the setter line does
    # not provably come after the LATEST descent toward the entry (site line 20).
    ctx = _mk_ctx(ADJ)
    _, ok, r = _feasibility(ctx, ("root", "main"), 15, ("b", "entry_fn"), None)
    assert ok and r == "setter-on-path-to-entry"
    ctx2 = _mk_ctx(ADJ)
    _, ok2, r2 = _feasibility(ctx2, ("root", "main"), 25, ("b", "entry_fn"), None)
    assert not ok2 and r2 == "setter-after-descent-to-entry"


def test_same_function_line_order():
    ctx = _mk_ctx(ADJ)
    node = ("b", "entry_fn")
    assert _feasibility(ctx, node, 5, node, None)[1:] == (True, "same-function-as-entry")
    assert _feasibility(ctx, node, 5, node, 9)[1:] == (True, "same-function-line-order")
    assert _feasibility(ctx, node, 9, node, 5)[1:] == (False, "same-function-after-entry-line")


def test_lca_path_reconstruction():
    # root::main -> a::setter_fn ; root::main -> b::entry_fn -> c::deep
    ctx = _mk_ctx(ADJ)
    lca = _find_lca(ctx, ("a", "setter_fn"), ("c", "deep"))
    assert lca == ("root", "main")
    assert ctx.path_from(lca, ("a", "setter_fn")) == [("root", "main"), ("a", "setter_fn")]
    assert ctx.path_from(lca, ("c", "deep")) == [("root", "main"), ("b", "entry_fn"), ("c", "deep")]
    # degenerate leg: LCA == target => single-hop path
    assert ctx.path_from(("b", "entry_fn"), ("b", "entry_fn")) == [("b", "entry_fn")]


def test_cycle_safe_lca():
    # a <-> b cycle above the entry; must terminate and find a join
    adj = {
        ("a", "f"): {("b", "g", 1, False)},
        ("b", "g"): {("a", "f", 1, False), ("s", "set", 2, False), ("e", "ent", 3, False)},
    }
    ctx = _mk_ctx(adj)
    lca = _find_lca(ctx, ("s", "set"), ("e", "ent"))
    assert lca == ("b", "g")
    _, feasible, reason = _feasibility(ctx, ("s", "set"), 1, ("e", "ent"), None)
    assert feasible and reason == "setter-before-entry"


# --------------------------------------------------------------------------- #
# DB-gated end-to-end (zero file reads enforced)
# --------------------------------------------------------------------------- #
def _forbid_disk(monkeypatch):
    """Any cfg subprocess or blueprint/source disk open during the trace fails the test."""
    import vbt.cpp_frontend.wrapper as W
    import backward_traversal.utils.blueprint_utils as BU

    def _boom(*a, **k):
        raise AssertionError("disk/subprocess fallback fired during a DB-only lineage trace")

    import vbt.resolve._find_cpp_chain as FCC
    monkeypatch.setattr(W, "run_cfg_extract", _boom)          # cfg must come from blobs
    monkeypatch.setattr(BU, "_load_json_cached", _boom)       # blueprints must come from the override
    monkeypatch.setattr(FCC, "read_source_text", _boom)       # no source text at all


@_db
def test_e2e_cpp_root_feasible_with_conditions(monkeypatch):
    _forbid_disk(monkeypatch)
    out = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY,
                          blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR),
                          max_dep_var_depth=1)
    assert out["status"] == "success"
    root = out["variables"][0]
    assert root["name"] == "softCardValue" and root["depth"] == 0
    assert root["feasibleSetterCount"] > 0
    for s in root["setters"]:
        assert "feasible" in s and "reason" in s and "entry" in s and "lca" in s
        if s["reason"] == "no-lca":
            assert s["lca"] is None and not s["feasible"] and "lcaPath" not in s
        else:
            # every setter WITH an LCA carries witness paths anchored at that LCA and
            # ending at the setter / the entry.
            p = s["lcaPath"]
            assert p["toSetter"][0] == s["lca"] and p["toEntry"][0] == s["lca"]
            assert p["toSetter"][-1]["file"] == s["file"]
            assert p["toEntry"][-1]["file"] == s["entry"]["file"]
        if s["feasible"]:
            assert "conditions" in s and "depVars" in s
    # depth-1 recursion happened and dep vars carry their read-site entry
    deps = [v for v in out["variables"] if v["depth"] == 1]
    assert deps, "expected depth-1 dependent variables"
    assert all(v.get("collectedFrom") for v in deps)
    assert out["stats"]["variables"] == len(out["variables"])


@_db
def test_e2e_asm_root_conditions_from_blob(monkeypatch):
    _forbid_disk(monkeypatch)
    out = run_lca_lineage(KB, "L7DCME", "asm", ENTRY,
                          blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR),
                          max_dep_var_depth=1)
    assert out["status"] == "success"
    root = out["variables"][0]
    assert root["feasibleSetterCount"] > 0
    feas = [s for s in root["setters"] if s["feasible"]]
    # blueprint-blob conditions actually surface on ASM setters
    assert any(s.get("conditionsAvailable") and s.get("conditions") for s in feas)
    assert any(s.get("depVars") for s in feas)


@_db
def test_e2e_deterministic(monkeypatch):
    _forbid_disk(monkeypatch)
    kwargs = dict(blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR), max_dep_var_depth=1)
    o1 = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, **kwargs)
    o2 = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, **kwargs)
    o1["stats"].pop("elapsedSec"), o2["stats"].pop("elapsedSec")
    assert o1 == o2


@_db
def test_e2e_bad_entry_fails_actionably():
    with pytest.raises(ValueError):
        run_lca_lineage(KB, "softCardValue", "cpp",
                        {"stem": "nosuchstem", "file_type": "cpp", "function": "nope"},
                        blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR))


@_db
def test_e2e_progress_logging_emits_and_is_output_identical(monkeypatch):
    """progress=True must emit the [vbt] INFO lines (per-var + TOTAL + counters) without
    changing the payload. The 'vbt' root doesn't propagate, so capture via a direct handler."""
    import logging

    _forbid_disk(monkeypatch)
    kwargs = dict(blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR), max_dep_var_depth=1)
    quiet = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, **kwargs)

    vbt_log = logging.getLogger("vbt")
    records: list = []

    class _Capture(logging.Handler):
        def emit(self, record):
            records.append(record.getMessage())

    h = _Capture()
    vbt_log.addHandler(h)
    prev_level = vbt_log.level
    try:
        loud = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, progress=True, **kwargs)
    finally:
        vbt_log.removeHandler(h)
        vbt_log.setLevel(prev_level)

    assert any(m.startswith("var #1 ") for m in records)
    assert any(m.startswith("TOTAL lca_lineage") for m in records)
    assert any(m.startswith("counters:") for m in records)
    quiet["stats"].pop("elapsedSec"), loud["stats"].pop("elapsedSec")
    assert quiet == loud


@_db
def test_e2e_deep_depth_terminates(monkeypatch):
    """Cycle safety at large depth: the (var, lang, entry-node, entry-line) key space is
    finite and each key processes once, so depth 12 must terminate and cost ~the same as
    the depth where recursion naturally exhausts — never hang or blow up."""
    _forbid_disk(monkeypatch)
    kwargs = dict(blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR))
    d1 = run_lca_lineage(KB, "L7DCME", "asm", ENTRY, max_dep_var_depth=1, **kwargs)
    d12 = run_lca_lineage(KB, "L7DCME", "asm", ENTRY, max_dep_var_depth=12, **kwargs)
    assert d12["status"] == "success"
    assert d12["stats"]["variables"] >= d1["stats"]["variables"]
    assert d12["stats"]["elapsedSec"] < 60


@_db
def test_e2e_corpus_cache_hit(monkeypatch):
    """The second request on the same kb must reuse the cached fn-graph bundle (and still
    produce an identical payload — covered by the determinism test)."""
    import vbt.depvars.lca_lineage as LL

    _forbid_disk(monkeypatch)
    kwargs = dict(blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR), max_dep_var_depth=0)
    run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, **kwargs)
    assert KB in LL._CORPUS_CACHE
    fp_before = LL._CORPUS_CACHE[KB][0]
    run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, **kwargs)
    assert LL._CORPUS_CACHE[KB][0] == fp_before   # same fingerprint => bundle reused


@_db
def test_e2e_cone_prefilter_output_identical(monkeypatch):
    """The no-lca cone pre-filter is an exact rejection (s ∉ descendants(anc(e)) ⟺ no
    common ancestor): forcing it ALWAYS-ON vs ALWAYS-OFF must be payload-identical."""
    import vbt.depvars.lca_lineage as LL

    _forbid_disk(monkeypatch)
    kwargs = dict(blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR), max_dep_var_depth=1)
    monkeypatch.setattr(LL, "_CONE_PREFILTER_MIN_NODES", 10**9)   # never engage
    off = run_lca_lineage(KB, "L7DCME", "asm", ENTRY, **kwargs)
    monkeypatch.setattr(LL, "_CONE_PREFILTER_MIN_NODES", 0)       # always engage
    on = run_lca_lineage(KB, "L7DCME", "asm", ENTRY, **kwargs)
    off["stats"].pop("elapsedSec"), on["stats"].pop("elapsedSec")
    assert off == on


# --------------------------------------------------------------------------- #
# all-setters mode (feasibility skipped entirely)
# --------------------------------------------------------------------------- #
def test_invalid_mode_raises_value_error():
    with pytest.raises(ValueError):
        run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, mode="nope")


@_db
def test_e2e_all_setters_mode(monkeypatch):
    """all-setters mode: every discovered setter is feasible with no LCA work at all —
    lca is None, no lcaPath, reason='all-setters-mode' — and conditions + dep-var
    recursion still happen (zero-file-read guard stays active)."""
    _forbid_disk(monkeypatch)
    out = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY,
                          blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR),
                          max_dep_var_depth=1, mode="all-setters")
    assert out["status"] == "success"
    assert out["semantics"]["mode"] == "all-setters"
    assert out["semantics"]["feasibility"] == "skipped-all-feasible"
    assert out["stats"]["feasibleSetters"] == out["stats"]["setters"] > 0
    assert out["stats"]["infeasibleSetters"] == 0
    for v in out["variables"]:
        assert v["feasibleSetterCount"] == v["setterCount"]
        assert v["infeasibleSetterCount"] == 0
        for s in v["setters"]:
            assert s["feasible"] is True
            assert s["reason"] == "all-setters-mode"
            assert s["lca"] is None
            assert "lcaPath" not in s
            assert "conditions" in s and "depVars" in s
    deps = [v for v in out["variables"] if v["depth"] == 1]
    assert deps, "expected depth-1 dependent variables"


@_db
def test_e2e_all_setters_superset_of_default(monkeypatch):
    """Same variable: all-setters mode keeps every discovered setter, so its root
    setterCount is >= the default mode's (which only differs by feasibility verdicts,
    not discovery — counts are equal unless the setter cap truncates differently)."""
    _forbid_disk(monkeypatch)
    kwargs = dict(blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR), max_dep_var_depth=0)
    default = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, **kwargs)
    allmode = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY,
                              mode="all-setters", **kwargs)
    assert allmode["variables"][0]["setterCount"] >= default["variables"][0]["setterCount"]
    assert (allmode["variables"][0]["feasibleSetterCount"]
            >= default["variables"][0]["feasibleSetterCount"])


@_db
def test_e2e_load_only_state_restored():
    from vbt.precompute import db_artifacts as DA
    prev = DA.is_load_only()
    run_lca_lineage(KB, "softCardValue", "cpp", ENTRY,
                    blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR), max_dep_var_depth=0)
    assert DA.is_load_only() == prev


# --------------------------------------------------------------------------- #
# traversal (DFS default / BFS option) + max_feasible_setters + terminal flag
# --------------------------------------------------------------------------- #
def test_invalid_traversal_raises_value_error():
    with pytest.raises(ValueError):
        run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, traversal="sideways")
    with pytest.raises(ValueError):
        run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, max_feasible_setters=0)


def _vkeys(out):
    """The dedup identity of each emitted variable (depth/collectedFrom are traversal-
    dependent; the identity + setter content are not)."""
    return {(v.get("qualified") or v["name"], v["language"],
             v["entry"]["file"], v["entry"].get("function"), v["entry"].get("line"))
            for v in out["variables"]}


@_db
def test_e2e_dfs_bfs_same_variable_set(monkeypatch):
    """With no binding max_dep_vars budget, DFS and BFS must process the SAME variable
    set with identical per-variable setter verdicts — only visit order (and hence the
    depth a duplicate is first met at) may differ. This is also the regression test for
    DFS depth-cap re-expansion: losing a shallower re-encounter's subtree would shrink
    the DFS set below BFS's."""
    _forbid_disk(monkeypatch)
    kwargs = dict(blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR), max_dep_var_depth=2)
    dfs = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, traversal="dfs", **kwargs)
    bfs = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, traversal="bfs", **kwargs)
    assert not dfs["truncated"] and not bfs["truncated"]
    assert _vkeys(dfs) == _vkeys(bfs)
    assert dfs["stats"]["setters"] == bfs["stats"]["setters"]
    assert dfs["stats"]["feasibleSetters"] == bfs["stats"]["feasibleSetters"]
    assert dfs["stats"]["terminalVariables"] == bfs["stats"]["terminalVariables"]
    # per-variable setter content is traversal-independent
    def _by_key(out):
        return {(v.get("qualified") or v["name"], v["entry"]["file"],
                 v["entry"].get("function"), v["entry"].get("line")):
                (v["setterCount"], v["feasibleSetterCount"], v["terminal"])
                for v in out["variables"]}
    assert _by_key(dfs) == _by_key(bfs)


@_db
def test_e2e_dfs_drills_deeper_under_budget(monkeypatch):
    """The point of DFS: under a tight max_dep_vars budget, BFS spends it on the depth-1
    frontier while DFS completes chains — reaching strictly deeper variables."""
    _forbid_disk(monkeypatch)
    kwargs = dict(blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR),
                  max_dep_var_depth=3, max_dep_vars=12)
    dfs = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, traversal="dfs", **kwargs)
    bfs = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, traversal="bfs", **kwargs)
    max_dfs = max(v["depth"] for v in dfs["variables"])
    max_bfs = max(v["depth"] for v in bfs["variables"])
    assert max_dfs > max_bfs, (max_dfs, max_bfs)
    assert dfs["limits"]["traversal"] == "dfs" and bfs["limits"]["traversal"] == "bfs"


@_db
def test_e2e_max_feasible_setters_witness(monkeypatch):
    """max_feasible_setters=1 is a FEASIBLE-setter cap: evaluation continues past
    infeasible setters until a feasible one is found, so a live variable can never
    become a false terminal (unlike max_setters_per_var=1, which caps evaluation)."""
    _forbid_disk(monkeypatch)
    kwargs = dict(blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR), max_dep_var_depth=1)
    full = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, **kwargs)
    one = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY,
                          max_feasible_setters=1, **kwargs)
    assert one["limits"]["max_feasible_setters"] == 1
    root_full, root_one = full["variables"][0], one["variables"][0]
    assert root_full["feasibleSetterCount"] > 1        # cap actually bites on the root
    assert root_one["feasibleSetterCount"] == 1
    assert root_one["feasibleSettersCapped"] is True
    assert root_one["terminal"] is False               # NOT a false terminal
    for v in one["variables"]:
        assert v["feasibleSetterCount"] <= 1
        if v.get("feasibleSettersCapped"):
            assert v["feasibleSetterCount"] == 1
    assert any(w["code"] == "max_feasible_setters" and w["variablesCapped"] > 0
               for w in one["warnings"])


@_db
def test_e2e_all_setters_mode_composes_with_dfs(monkeypatch):
    """mode and traversal are orthogonal: all-setters + DFS drills chains under a budget
    just like the default mode, with every setter feasible and no LCA work."""
    _forbid_disk(monkeypatch)
    kwargs = dict(blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR),
                  max_dep_var_depth=3, max_dep_vars=12, mode="all-setters")
    dfs = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, traversal="dfs", **kwargs)
    bfs = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY, traversal="bfs", **kwargs)
    assert dfs["semantics"]["mode"] == "all-setters" and dfs["limits"]["traversal"] == "dfs"
    assert all(s["feasible"] and s["lca"] is None
               for v in dfs["variables"] for s in v["setters"])
    assert (max(v["depth"] for v in dfs["variables"])
            > max(v["depth"] for v in bfs["variables"]))


@_db
def test_e2e_terminal_flag_consistency(monkeypatch):
    """terminal <=> 0 feasible setters (and the scan wasn't cut by max_setters_per_var);
    stats.terminalVariables counts exactly the flagged entries."""
    _forbid_disk(monkeypatch)
    out = run_lca_lineage(KB, "softCardValue", "cpp", ENTRY,
                          blueprint_dir=str(BP_DIR), asm_dir=str(ASM_DIR),
                          max_dep_var_depth=1)
    assert out["stats"]["terminalVariables"] == sum(v["terminal"] for v in out["variables"])
    for v in out["variables"]:
        if v["terminal"]:
            assert v["feasibleSetterCount"] == 0
        elif v["feasibleSetterCount"] == 0:
            # non-terminal despite 0 feasible => the setter scan was truncated
            assert any(w["code"] == "max_setters_per_var" and w["variable"] == v["name"]
                       for w in out["warnings"])
