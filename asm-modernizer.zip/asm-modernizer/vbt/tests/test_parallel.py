"""Tests for the VBT precompute parallelism layer (vbt/precompute/parallel.py)
and the parallel==serial identity of the modifier index / const resolver.

Run from repo root:
    env/bin/python3 -m pytest vbt/tests/test_parallel.py -q
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest

from vbt.precompute.parallel import ParallelPlan, parallel_map, plan_workers

BP = Path("jobs/baseline-temp-asm/output")
ASM = Path("temp/asm")
_HAVE_BASELINE = BP.exists() and ASM.exists()


# --------------------------------------------------------------------------- #
# plan_workers
# --------------------------------------------------------------------------- #
def test_plan_workers_defaults_sane(monkeypatch):
    for k in ("VBT_WORKERS", "VBT_BATCH_SIZE", "VBT_MEM_BUDGET_FRACTION",
              "VBT_FILE_TIMEOUT_SECONDS"):
        monkeypatch.delenv(k, raising=False)
    p = plan_workers()
    assert isinstance(p, ParallelPlan)
    assert p.worker_count >= 1
    assert p.batch_size == 20                      # default
    assert p.per_proc_mem_cap_mb >= 256


def test_plan_workers_env_overrides(monkeypatch):
    monkeypatch.setenv("VBT_WORKERS", "4")
    monkeypatch.setenv("VBT_BATCH_SIZE", "7")
    p = plan_workers()
    assert p.worker_count == 4                      # explicit override honoured
    assert p.batch_size == 7
    assert p.per_proc_mem_cap_mb >= 256


def test_plan_workers_garbage_env_falls_back(monkeypatch):
    monkeypatch.setenv("VBT_WORKERS", "not-a-number")
    monkeypatch.setenv("VBT_BATCH_SIZE", "")
    monkeypatch.setenv("VBT_MEM_BUDGET_FRACTION", "9.9")  # out of (0,1] → default
    p = plan_workers()
    assert p.worker_count >= 1                       # auto path, no crash
    assert p.batch_size == 20


# --------------------------------------------------------------------------- #
# parallel_map
# --------------------------------------------------------------------------- #
def _square(x):
    return x * x


def test_parallel_map_sequential_fallback_single_worker():
    plan = ParallelPlan(worker_count=1, batch_size=20, per_proc_mem_cap_mb=512)
    out = parallel_map(_square, [1, 2, 3, 4, 5], plan=plan)
    assert out == [1, 4, 9, 16, 25]


def test_parallel_map_single_item_fallback():
    plan = ParallelPlan(worker_count=8, batch_size=20, per_proc_mem_cap_mb=512)
    assert parallel_map(_square, [9], plan=plan) == [81]


def test_parallel_map_empty():
    plan = ParallelPlan(worker_count=8, batch_size=20, per_proc_mem_cap_mb=512)
    assert parallel_map(_square, [], plan=plan) == []


def test_parallel_map_input_ordered():
    """Results must come back in INPUT order regardless of completion order."""
    plan = ParallelPlan(worker_count=4, batch_size=20, per_proc_mem_cap_mb=512)
    items = list(range(20))
    out = parallel_map(_square, items, plan=plan)
    assert out == [x * x for x in items]            # strictly input-ordered


def test_parallel_map_matches_sequential():
    items = list(range(13))
    seq = parallel_map(
        _square, items,
        plan=ParallelPlan(worker_count=1, batch_size=20, per_proc_mem_cap_mb=512),
    )
    par = parallel_map(
        _square, items,
        plan=ParallelPlan(worker_count=4, batch_size=20, per_proc_mem_cap_mb=512),
    )
    assert seq == par == [x * x for x in items]


# --------------------------------------------------------------------------- #
# parallel == serial identity for the real precompute artifacts
# --------------------------------------------------------------------------- #
def _build_index(workers: int):
    """Force a from-scratch index build under a private cache dir + worker count."""
    os.environ["VBT_CACHE_DIR"] = tempfile.mkdtemp(prefix=f"vbttest_idx_w{workers}_")
    os.environ["VBT_WORKERS"] = str(workers)
    import vbt.precompute.modifier_index as M
    # Force a from-scratch build (fresh cache dir + cleared in-proc memo). Do NOT
    # importlib.reload(M): a reload rebinds the module-level SetterSiteRef class, and
    # other test files that imported it by name then fail isinstance against the new
    # class object. plan_workers reads VBT_WORKERS at call time, so no reload needed.
    M._CACHE.clear()
    return M.get_modifier_index(BP, ASM)


def _full_index(idx):
    return (
        {k: sorted(v) for k, v in idx.asm.items()},
        {k: sorted(v) for k, v in idx.cpp.items()},
        {k: sorted(v) for k, v in idx.functions.items()},
        {k: sorted(s.as_tuple() for s in v) for k, v in idx.asm_sites.items()},
        {k: sorted(s.as_tuple() for s in v) for k, v in idx.cpp_sites.items()},
    )


@pytest.mark.skipif(not _HAVE_BASELINE, reason="baseline jobs/baseline-temp-asm not built")
def test_modifier_index_parallel_equals_serial():
    serial = _build_index(1)
    parallel = _build_index(4)
    try:
        # Spot-check the reference variables.
        assert sorted(serial.files_for("LG1OSI", "asm")) == \
               sorted(parallel.files_for("LG1OSI", "asm"))
        assert [s.as_tuple() for s in serial.sites_for("LG1OSI", "asm")] == \
               [s.as_tuple() for s in parallel.sites_for("LG1OSI", "asm")]
        assert sorted(serial.files_for("softCardValue", "cpp")) == \
               sorted(parallel.files_for("softCardValue", "cpp"))
        # Full structural identity.
        assert _full_index(serial) == _full_index(parallel)
    finally:
        os.environ.pop("VBT_WORKERS", None)
        os.environ.pop("VBT_CACHE_DIR", None)


def _build_const(workers: int):
    os.environ["VBT_CACHE_DIR"] = tempfile.mkdtemp(prefix=f"vbttest_const_w{workers}_")
    os.environ["VBT_WORKERS"] = str(workers)
    import vbt.resolve.const_resolver as C
    C._CACHE.clear()          # from-scratch build; no reload (see _build_index note)
    return C.get_const_resolver(BP, ASM)


@pytest.mark.skipif(not _HAVE_BASELINE, reason="baseline jobs/baseline-temp-asm not built")
def test_const_resolver_parallel_equals_serial():
    serial = _build_const(1)
    parallel = _build_const(4)
    try:
        assert serial.cpp_enum == parallel.cpp_enum
        assert serial.asm_const == parallel.asm_const
        # The canonical ASM constant must resolve identically (SPEC §6 worked truth).
        assert serial.resolve("LG#C400", "asm") == "C'D'"
        assert parallel.resolve("LG#C400", "asm") == "C'D'"
    finally:
        os.environ.pop("VBT_WORKERS", None)
        os.environ.pop("VBT_CACHE_DIR", None)
