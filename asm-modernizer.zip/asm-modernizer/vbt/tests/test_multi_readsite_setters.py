"""Regression: a dependent variable read at MULTIPLE sites must get the UNION of the
setters live for ANY read-site — not just the first-discovered read-site's before-line
scope.

The dep-var DAG dedups a variable onto one node keyed on (tail, qualified); the node's
setters are discovery-scoped (a same-file setter AFTER the read line is dropped — D2).
Because the node is SHARED across read-sites, the first discoverer's scope must not be
the only one applied: a later read in the same file (or a read elsewhere) can make a
setter live that the first read dropped. The fix re-scopes the shared node on each new
read-site and unions in the newly-live setters (recurse.py:_rescope_node).

Scenario — one file, one function:
    line 3:  if (o->v == 1) ...   // READ v
    line 4:  o->v = o->w;         // SET v (after read@3, before read@5)
    line 5:  if (o->v == 2) ...   // READ v
Seeding read@3 FIRST builds the node scoped to line 3 (setter@4 dropped). Read@5 then
re-scopes and unions the now-live setter@4 in. We also assert the D2 precision still
holds: with ONLY read@3, setter@4 is correctly dropped (the fix is a union, not a
disable). Needs the cfg_extract binary (skipped otherwise).
"""
import textwrap
from pathlib import Path

import pytest

_BIN = Path(__file__).resolve().parents[1] / "cpp_frontend" / "cfg_extract"
pytestmark = pytest.mark.skipif(not _BIN.exists(), reason="cfg_extract binary not built")

_SRC = """\
struct RxObj { int v; int w; };
void f(RxObj* o) {
    if (o->v == 1) { o->w = 9; }
    o->v = o->w;
    if (o->v == 2) { o->w = 8; }
}
"""


def _dep(line):
    from vbt.depvars.extract import DepVarRef
    return DepVarRef(name="v", language="cpp", relationship="condition",
                     found_at={"file": "tv.cpp", "startLine": line, "endLine": line},
                     qualified="o->v")


def _v_setter_lines(tmp_path, read_lines):
    from vbt.depvars.recurse import trace_dependents
    from vbt.output.codeblocks import CodeBlockStore
    (tmp_path / "tv.cpp").write_text(textwrap.dedent(_SRC))
    out = trace_dependents(
        [("root", _dep(ln)) for ln in read_lines], chain_files=["tv"],
        blueprint_dir=tmp_path, asm_dir=tmp_path, store=CodeBlockStore(tmp_path),
        chain_hops=None, route_engine=None, max_depth=1)
    node = next((d["dependentVariable"] for d in out
                 if d["dependentVariable"]["name"] == "v"), None)
    return {s["location"]["startLine"] for s in (node["setters"] if node else [])}


def test_later_readsite_unions_in_setter(tmp_path):
    # read@3 processed FIRST (setter@4 is after it → dropped for that scope); read@5
    # re-scopes the shared node and unions setter@4 in (live for the read@5).
    assert 4 in _v_setter_lines(tmp_path, [3, 5])


def test_sole_early_read_still_drops_later_setter(tmp_path):
    # D2 precision preserved: with ONLY read@3, setter@4 is genuinely after the (only)
    # read and must stay dropped — the fix is a UNION across read-sites, not a disable.
    assert 4 not in _v_setter_lines(tmp_path, [3])
