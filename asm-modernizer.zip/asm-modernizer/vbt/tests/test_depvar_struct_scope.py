"""Dep-var setter search is scoped to the dependency's STRUCT path.

A tail-only search attributes a DIFFERENT struct's same-tail field
(``l9x9x.expirationDate`` mis-counted as a setter of ``lwrIso.expirationDate``). The
recursion now passes ``full_paths=[dep.qualified]`` into ``find_cpp_setters_in_file``,
whose suffix-consistency gate keeps the dep's struct path (+ partial views) and drops
divergent-prefix structs. A bare-tail dep (``qualified == ""``) stays unscoped.

Baseline-independent.
"""
from vbt.depvars.extract import DepVarRef


# Two structs, same field tail. Tree-sitter is syntactic, so the unresolved types
# (LwrIso / L9x9x) don't matter — the assignment LHS member-chains are what's matched.
_TWO_STRUCT = """\
void f(LwrIso& lwrIso, L9x9x& l9x9x) {
    lwrIso.expirationDate = 1;
    l9x9x.expirationDate = 2;
}
"""


def test_find_cpp_setters_scoped_by_full_path(tmp_path):
    """The gate the wiring relies on: full_paths scopes to the named struct."""
    from vbt.setters.cpp_setters import find_cpp_setters_in_file
    f = tmp_path / "t.cpp"
    f.write_text(_TWO_STRUCT)
    scoped = find_cpp_setters_in_file("expirationDate", str(f),
                                      full_paths=["lwrIso.expirationDate"])
    unscoped = find_cpp_setters_in_file("expirationDate", str(f))
    assert {s.line for s in scoped} == {2}, [(s.line, s.value) for s in scoped]  # only lwrIso
    assert {s.line for s in unscoped} == {2, 3}                                  # tail-only = both


def _spy_run(monkeypatch, tmp_path, dep):
    """Run trace_dependents with collaborators stubbed and a spy on the cpp setter
    search; return the list of ``full_paths`` it was invoked with."""
    import vbt.depvars.recurse as R
    from vbt.depvars.recurse import trace_dependents

    calls = []

    def spy(tail, p, *, full_paths=None):
        calls.append(full_paths)
        return []

    class _Idx:
        def files_for(self, name, language): return {"f"}
        def files_defining_function(self, fn): return set()
        def sites_for(self, *a, **k): return []

    monkeypatch.setattr(R, "get_modifier_index", lambda *a, **k: _Idx())
    monkeypatch.setattr(R, "find_cpp_setters_in_file", spy)
    monkeypatch.setattr(R, "find_asm_setters_in_file", lambda *a, **k: [])
    monkeypatch.setattr(R, "collect_cpp_conditions", lambda *a, **k: [])
    monkeypatch.setattr(R, "extract_dep_vars", lambda *a, **k: [])
    monkeypatch.setattr(R, "resolve_aliases",
                        lambda name, lang, asm_dir: type("A", (), {"aliases": []})())
    monkeypatch.setattr(R, "run_cfg_extract", lambda *a, **k: [])
    monkeypatch.setattr(R, "_cpp_fn_block", lambda *a, **k: None)
    monkeypatch.setattr(R, "_dep_chunk", lambda *a, **k: None)
    (tmp_path / "f.cpp").write_text("// chain file f\n")
    trace_dependents([("root", dep)], ["f"], blueprint_dir=tmp_path, asm_dir=tmp_path, store=None)
    return calls


def test_recursion_passes_qualified_as_scope(monkeypatch, tmp_path):
    # expand_family=False isolates the PRIMARY dep's scoped search (path-family
    # ancestors would otherwise add their own scoped calls — covered separately in
    # test_depvar_pathfamily).
    dep = DepVarRef(name="expirationDate", language="cpp", relationship="condition",
                    found_at={"file": "f.cpp", "startLine": 10, "endLine": 10},
                    qualified="lwrIso.expirationDate", expand_family=False)
    calls = _spy_run(monkeypatch, tmp_path, dep)
    assert calls and all(fp == ["lwrIso.expirationDate"] for fp in calls), calls


def test_bare_tail_dep_is_unscoped(monkeypatch, tmp_path):
    # no struct prefix known at the read site → cannot scope → tail-only (full_paths=None)
    dep = DepVarRef(name="someLocal", language="cpp", relationship="condition",
                    found_at={"file": "f.cpp", "startLine": 10, "endLine": 10},
                    qualified="")
    calls = _spy_run(monkeypatch, tmp_path, dep)
    assert calls and all(fp is None for fp in calls), calls
