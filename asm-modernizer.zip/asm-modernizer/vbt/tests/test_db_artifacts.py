"""Unit tests for the DB-backed precompute foundation (T1).

No engine behavior is exercised here — only the plumbing contract: the source fingerprint,
the 3-tier resolver, and the manifest round-trip against a throwaway SQLite engine.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from vbt.precompute import db_artifacts as DA


# --------------------------------------------------------------------------- #
# source_manifest_hash
# --------------------------------------------------------------------------- #
def test_source_hash_is_order_independent_and_deterministic(tmp_path: Path):
    a = tmp_path / "a.cpp"; a.write_text("aaa")
    b = tmp_path / "b.cpp"; b.write_text("bbbb")
    h1 = DA.source_manifest_hash([a, b])
    h2 = DA.source_manifest_hash([b, a])          # order should not matter (sorted)
    assert h1 == h2
    assert h1 == DA.source_manifest_hash([a, b])  # deterministic across calls


def test_source_hash_changes_on_size_version_and_salt(tmp_path: Path):
    a = tmp_path / "a.cpp"; a.write_text("aaa")
    base = DA.source_manifest_hash([a])
    a.write_text("aaa-bigger-now")                # size change
    assert DA.source_manifest_hash([a]) != base
    assert DA.source_manifest_hash([a], version=2) != DA.source_manifest_hash([a], version=1)
    assert DA.source_manifest_hash([a], extra="x") != DA.source_manifest_hash([a], extra="y")


def test_source_hash_missing_file_then_appearing(tmp_path: Path):
    missing = tmp_path / "ghost.cpp"
    h_absent = DA.source_manifest_hash([missing])
    missing.write_text("now here")
    assert DA.source_manifest_hash([missing]) != h_absent


# --------------------------------------------------------------------------- #
# resolve_artifact (DB -> disk -> compute)
# --------------------------------------------------------------------------- #
def test_resolve_prefers_db_then_disk_then_compute():
    assert DA.resolve_artifact(db_load=lambda: "db", compute=lambda: "c") == "db"
    assert DA.resolve_artifact(db_load=lambda: None, compute=lambda: "c") == "c"
    assert DA.resolve_artifact(db_load=lambda: None, disk_load=lambda: "disk",
                               compute=lambda: "c") == "disk"


def test_resolve_swallows_loader_errors_and_falls_through():
    def boom():
        raise RuntimeError("db down")
    assert DA.resolve_artifact(db_load=boom, compute=lambda: "c") == "c"
    assert DA.resolve_artifact(db_load=lambda: None, disk_load=boom,
                               compute=lambda: "c") == "c"


def test_resolve_does_not_call_compute_when_db_hits():
    called = []
    out = DA.resolve_artifact(db_load=lambda: "db",
                              compute=lambda: called.append(1) or "c")
    assert out == "db" and called == []


# --------------------------------------------------------------------------- #
# manifest round-trip (explicit throwaway engine — no global settings)
# --------------------------------------------------------------------------- #
@pytest.fixture()
def engine(tmp_path: Path):
    from sqlalchemy import create_engine
    from api.index_db.schema import metadata
    eng = create_engine(f"sqlite:///{tmp_path / 'index.db'}")
    metadata.create_all(eng)
    return eng


def test_manifest_write_read_roundtrip_and_upsert(engine):
    assert DA.read_manifest_with_engine(engine, "job1", "name_alias") is None

    DA.write_manifest_with_engine(engine, "job1", "name_alias", 1, "hashA")
    row = DA.read_manifest_with_engine(engine, "job1", "name_alias")
    assert row == {"version": 1, "source_hash": "hashA", "built_at": ""}

    # upsert overwrites the same (job, artifact) — exactly one row
    DA.write_manifest_with_engine(engine, "job1", "name_alias", 2, "hashB", "2026-06-18T00:00:00")
    row = DA.read_manifest_with_engine(engine, "job1", "name_alias")
    assert row["version"] == 2 and row["source_hash"] == "hashB"

    # other (job, artifact) pairs are independent
    assert DA.read_manifest_with_engine(engine, "job1", "fn_call_graph") is None
    assert DA.read_manifest_with_engine(engine, "job2", "name_alias") is None


def test_read_write_manifest_noop_without_job_id():
    assert DA.read_manifest(None, "name_alias") is None
    assert DA.write_manifest(None, "name_alias", 1, "h") is False


def test_blob_roundtrip_and_upsert(engine):
    assert DA.read_blob_with_engine(engine, "job1", "name_alias") is None
    payload = DA.dumps_gz({"units": [1, 2, 3], "nested": {"k": ["a", "b"]}})
    DA.write_blob_with_engine(engine, "job1", "name_alias", payload)
    got = DA.read_blob_with_engine(engine, "job1", "name_alias")
    assert got == payload
    assert DA.loads_gz(got) == {"units": [1, 2, 3], "nested": {"k": ["a", "b"]}}
    # upsert overwrites
    payload2 = DA.dumps_gz({"v": 2})
    DA.write_blob_with_engine(engine, "job1", "name_alias", payload2)
    assert DA.loads_gz(DA.read_blob_with_engine(engine, "job1", "name_alias")) == {"v": 2}


def test_dumps_gz_is_deterministic():
    obj = {"b": [3, 2, 1], "a": {"x": 1}}
    assert DA.dumps_gz(obj) == DA.dumps_gz(obj)   # mtime=0 -> stable bytes
