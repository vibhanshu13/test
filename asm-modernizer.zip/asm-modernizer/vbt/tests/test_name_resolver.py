"""Cross-language name-resolution regression suite (SPEC §7).

Locks in the CORE resolver fix: cross-language counterpart resolution must NOT
depend on a parseable HLASM ``.mac``. The resolver derives ASM field identities
from, in priority order, the ``.mac`` DSECT → the gen header ``<name>.hpp`` (the
machine-EXPANDED DSECT) → the cc header field COMMENTS — so a macro-generated
DSECT (no literal ``LABEL DSECT`` line) no longer silently zeros resolution for
every field of that struct.

Reproduces the tester's two cases that came back ``terminal`` with no aliases:
  * ``linkSourceArea->ls4cscres`` ↔ ``LWRLS4CSCRES``   (lwrls: macro DSECT + gen)
  * ``linkSourceArea->lstknpoa``  ↔ ``LWRLSTKNPOA``    (lwrls)
plus the gen-absent macro-DSECT tier (l7l7l, comment-consensus) and guards the
working path (lwrpo: ``softCardValue`` ↔ ``LWRPOSFCRDV``) against regression.

Only needs the source triples under ``temp/asm`` (no built baseline / blueprints).

    env/bin/python3 -m pytest vbt/tests/test_name_resolver.py -q
"""
from pathlib import Path

import pytest

ASM = Path("temp/asm")

pytestmark = pytest.mark.skipif(
    not ASM.exists(), reason="temp/asm source corpus not present",
)

from vbt.resolve import name_resolver as NR          # noqa: E402
from vbt.resolve import _find_cpp_chain as ch         # noqa: E402


@pytest.fixture(autouse=True)
def _clear():
    """Each test resolves against a freshly-built alias map (no cross-test cache)."""
    NR.clear_cache()
    yield
    NR.clear_cache()


def _asm_aliases(var, lang="cpp"):
    return {a.name for a in NR.resolve(var, lang, ASM).aliases if a.certainty == "high"}


# --------------------------------------------------------------------------- #
# The reported failures — macro-DSECT struct recovered via the gen header.
# --------------------------------------------------------------------------- #
@pytest.mark.skipif(not (ASM / "lwrls.hpp").exists(), reason="lwrls gen header absent")
def test_macro_dsect_fields_resolve_via_gen():
    # lwrls.mac is a macro-generated DSECT (no literal `LABEL DSECT` line), so
    # parse_mac yields nothing; resolution must fall through to the gen header.
    assert "LWRLS4CSCRES" in _asm_aliases("ls4cscres")
    assert "LWRLSTKNPOA" in _asm_aliases("lstknpoa")


@pytest.mark.skipif(not (ASM / "lwrls.hpp").exists(), reason="lwrls gen header absent")
def test_macro_dsect_status_marks_gen_sourced():
    amap = ch.build_alias_map(
        str(ASM / "lwrls.mac"), str(ASM / "lwrls.hpp"), str(ASM / "cclwrls.hpp"))
    st = amap["status"]
    assert st["resolved"] is True            # recovered ...
    assert st["mac_parsed"] is False         # ... despite the .mac yielding nothing
    assert st["gen_parsed"] is True
    assert st["n_cpp"] > 100                 # whole struct resolved, not a stray field


@pytest.mark.skipif(not (ASM / "lwrls.hpp").exists(), reason="lwrls gen header absent")
def test_reverse_direction_asm_to_cpp():
    # ASM → C++ must also resolve (the engine searches counterpart setters both ways).
    aliases = {a.name for a in NR.resolve("LWRLS4CSCRES", "asm", ASM).aliases
               if a.certainty == "high"}
    assert any("ls4cscres" in a.lower() for a in aliases), aliases


# --------------------------------------------------------------------------- #
# Gen-absent macro DSECT — comment-consensus last-resort tier (l7l7l).
# --------------------------------------------------------------------------- #
@pytest.mark.skipif(
    (ASM / "l7l7l.hpp").exists() or not (ASM / "ccl7l7l.hpp").exists(),
    reason="l7l7l comment-consensus case not present (gen header exists or cc absent)",
)
def test_comment_consensus_when_no_mac_and_no_gen():
    # No parseable .mac AND no gen header → the cc field comments are the only
    # ground truth, self-validated by prefix consensus.
    assert "L7LTID" in _asm_aliases("authorizerTerminalId")


# --------------------------------------------------------------------------- #
# Regression: the working .mac-parsed path must be unchanged.
# --------------------------------------------------------------------------- #
@pytest.mark.skipif(not (ASM / "lwrpo.mac").exists(), reason="lwrpo triple absent")
def test_working_path_unregressed():
    assert "LWRPOSFCRDV" in _asm_aliases("softCardValue")
    # ASM → C++ for the same logical field still resolves to the app member path.
    rev = {a.name for a in NR.resolve("LWRPOSFCRDV", "asm", ASM).aliases
           if a.certainty == "high"}
    assert any("softcardvalue" in a.lower() for a in rev), rev


# --------------------------------------------------------------------------- #
# Robustness: headers that crashed parse_cc must now parse cleanly.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("cc", ["cccr21ae.hpp", "cclwrcw.hpp", "cclwrdx.hpp", "cclwrwr.hpp"])
def test_parse_cc_no_longer_crashes(cc):
    p = ASM / cc
    if not p.exists():
        pytest.skip(f"{cc} not present")
    struct, leaves = ch.parse_cc(str(p), None)   # must not raise IndexError
    assert struct and len(leaves) > 0
