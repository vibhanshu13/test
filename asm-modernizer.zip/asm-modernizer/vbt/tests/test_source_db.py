"""T9: DB-backed source text — override mechanism + decode-equivalence + gz round-trip.

The full-trace byte-identical proof (build → install → warm trace serves source from DB) lives
in the parity gate.
"""
from __future__ import annotations

import gzip
import locale
from pathlib import Path

import pytest

from backward_traversal.utils import blueprint_utils as BU

from vbt.tests.parity import cases as P

pytestmark = pytest.mark.skipif(not P.corpus_available(),
                                reason="pinned corpus absent (see DB_PRECOMPUTE_PLAN.md §11)")


def test_source_override_serves_then_clears():
    p = P.ASM_DIR / "dw710000.cpp"
    base = p.read_bytes()
    name = p.name

    def ov(path_str):
        return base if Path(path_str).name == name else None

    try:
        BU.set_source_override(ov)
        assert BU.source_override_bytes(p) == base
    finally:
        BU.clear_source_override()
    assert BU.source_override_bytes(p) is None      # cleared → fall back to disk


def test_decode_equivalence_matches_read_text_splitlines():
    """The DB path (bytes.decode(default-enc).splitlines()) must equal read_text(errors=
    'replace').splitlines() — the assumption CodeBlockScope._lines relies on."""
    for fn in ("dw710000.cpp", "aa71.asm"):
        p = P.ASM_DIR / fn
        via_bytes = p.read_bytes().decode(locale.getpreferredencoding(False), "replace").splitlines()
        via_text = p.read_text(errors="replace").splitlines()
        assert via_bytes == via_text, f"decode mismatch for {fn}"


def test_gz_bytes_roundtrip_lossless():
    b = (P.ASM_DIR / "aa71.asm").read_bytes()
    assert gzip.decompress(gzip.compress(b, mtime=0)) == b


def test_find_cpp_setters_identical_via_source_override():
    """T10: the setter finder reads source via the override → identical sites vs disk."""
    from vbt.setters.cpp_setters import find_cpp_setters_in_file, _SETTER_CACHE
    p = P.ASM_DIR / "dw710000.cpp"

    def _fields(sites):
        return [(s.variable, s.file_stem, s.line, s.instruction, s.value,
                 s.is_declaration, getattr(s, "lhs_path", None)) for s in sites]

    _SETTER_CACHE.clear()
    base = _fields(find_cpp_setters_in_file("softCardValue", str(p)))

    raw = p.read_bytes()
    _SETTER_CACHE.clear()
    BU.set_source_override(lambda ps: raw if Path(ps).name == "dw710000.cpp" else None)
    try:
        got = _fields(find_cpp_setters_in_file("softCardValue", str(p)))
    finally:
        BU.clear_source_override()
        _SETTER_CACHE.clear()
    assert got == base
