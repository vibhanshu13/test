"""Tests for the DB-only LCA chain trace (vbt/lca_trace.py).

Two tiers:
  * pure-logic (no DB): the copied feasibility decision + the LCA/chains/subset-prune algorithms +
    the chains-only hop shape — fast, always run.
  * DB-backed (auto-discovered chain_facts job; skip if none): softCardValue LCA/chains, plastic-auth
    forced LCA, hard-fail on missing/stale artifact, prune keeps-reachable, and the HARDENED
    no-fallback proof (every source/disk reader monkeypatched to RAISE ⇒ identical result, prune
    included — the real proof of strict DB-only).
"""
from __future__ import annotations

import pytest

from vbt.lca_feasibility import _Event, decide_feasibility, parse_required_guard
from vbt.lca_trace import (
    lca_roots, chains_to_lca, _subset_prune, _to_hops, _line_to_fn,
    trace_variable_to_lca_chains, DbArtifactMissing, ForcedLcaAbsent, DOMAIN_FORCED_LCA)
from vbt.tests._lca_corpus import find_chain_facts_job


# =========================================================================== #
# pure-logic: feasibility decision (copied verbatim from c17a8f4 — sanity it's wired)
# =========================================================================== #
def _g(hop, scrut, const, op="eq"):
    return _Event(hop=hop, line=1, kind="guard", scrutinee=scrut, const=const, op=op)


def _a(hop, scrut, const, conditional=False, line=1):
    return _Event(hop=hop, line=line, kind="assign", scrutinee=scrut, const=const,
                  conditional=conditional)


def test_decide_feasibility_provable_conflict_drops():
    # pin x=5 (hop0, unconditional) then a switch requiring x==9 (hop1) → provably infeasible.
    v = decide_feasibility([_a(0, "x", "5"), _g(1, "x", "9")])
    assert v.status == "infeasible"


def test_decide_feasibility_same_value_feasible():
    v = decide_feasibility([_a(0, "x", "5"), _g(1, "x", "5")])
    assert v.status == "feasible"


def test_decide_feasibility_conditional_assign_clears_pin():
    # a CONDITIONAL assignment clears the pin → no provable conflict → keep.
    v = decide_feasibility([_a(0, "x", "5"), _a(0, "x", "5", conditional=True), _g(1, "x", "9")])
    assert v.status != "infeasible"


def test_decide_feasibility_cross_kind_not_provably_different():
    # enum vs int are NOT provably different (can't know the enum's int value) → keep.
    v = decide_feasibility([_a(0, "rc", "CreditApproved"), _g(1, "rc", "0")])
    assert v.status == "feasible"


def test_decide_feasibility_switch_disjunction():
    # multiple eq guards on the same scrutinee at the same hop are a DISJUNCTION (x in {1,2}).
    assert decide_feasibility([_a(0, "x", "3"), _g(1, "x", "1"), _g(1, "x", "2")]).status == "infeasible"
    assert decide_feasibility([_a(0, "x", "2"), _g(1, "x", "1"), _g(1, "x", "2")]).status == "feasible"


def test_parse_required_guard():
    assert parse_required_guard("x == 5") == ("x", "5", "eq")
    assert parse_required_guard("x != 5") == ("x", "5", "ne")
    assert parse_required_guard("!(x == 5)") == ("x", "5", "ne")          # negation flips op
    assert parse_required_guard("a && b") is None                         # compound rejected
    assert parse_required_guard("x == y") is None                         # RHS not a constant


# =========================================================================== #
# pure-logic: LCA + chains + subset prune over synthetic graphs
# =========================================================================== #
def _adj(edges):
    """edges: list of (caller_stem, caller_fn, callee_stem, callee_fn) → CppFnGraph-shaped adj."""
    out = {}
    for cs, cf, ds, df in edges:
        out.setdefault((cs, cf), set()).add((ds, df, 0, False))
        out.setdefault((ds, df), out.get((ds, df), set()))
    return out


def test_lca_roots_consolidates_under_common_ancestor():
    # root R calls A and B; setters at A and B → LCA = R (the common ancestor).
    nt = {"r": "cpp", "a": "cpp", "b": "cpp"}
    adj = _adj([("r", "R", "a", "A"), ("r", "R", "b", "B")])
    roots = lca_roots([("a", "A"), ("b", "B")], adj, nt)
    assert len(roots) == 1
    assert roots[0][0] == ("r", "R")


def test_lca_roots_chain_picks_deepest():
    # R → M → S ; setters at M and S → deepest common = M (M reaches S).
    nt = {"r": "cpp", "m": "cpp", "s": "cpp"}
    adj = _adj([("r", "R", "m", "M"), ("m", "M", "s", "S")])
    roots = lca_roots([("m", "M"), ("s", "S")], adj, nt)
    assert len(roots) == 1
    assert roots[0][0] == ("m", "M")


def test_lca_roots_multiple_when_no_common_ancestor():
    nt = {"a": "cpp", "b": "cpp"}
    adj = _adj([("a", "A", "a", "X"), ("b", "B", "b", "Y")])
    roots = lca_roots([("a", "X"), ("b", "Y")], adj, nt)
    assert len(roots) == 2


def test_chains_to_lca_and_truncation():
    nt = {"r": "cpp", "m": "cpp", "s": "cpp"}
    adj = _adj([("r", "R", "m", "M"), ("m", "M", "s", "S")])
    chains, trunc = chains_to_lca(("s", "S"), adj, nt)
    assert chains == [["r::R", "m::M", "s::S"]]
    assert trunc is False
    capped, trunc2 = chains_to_lca(("s", "S"), adj, nt, max_chains=0)
    assert trunc2 is True   # cap hit


def test_subset_prune_by_node_set_not_subsequence():
    # [a,b,c] strictly contains the node-set of [b,c] → drop [b,c]; keep the maximal one.
    kept, dropped = _subset_prune([["a", "b", "c"], ["b", "c"]])
    assert kept == [["a", "b", "c"]]
    assert dropped == 1
    # different node-sets → both kept.
    kept2, _ = _subset_prune([["a", "b"], ["a", "c"]])
    assert len(kept2) == 2


def test_to_hops_shape():
    nt = {"aa71": "asm", "dw710000": "cpp"}
    hops = _to_hops(["aa71", "dw710000::processACreditTransaction"], nt)
    assert hops[0] == {"file": "aa71"}                                    # asm: file only
    assert hops[1] == {"file": "dw710000", "function": "processACreditTransaction"}  # cpp: +function


def test_line_to_fn_nearest_preceding_start():
    starts = [(10, "f"), (20, "g"), (30, "h")]
    assert _line_to_fn(starts, 25) == "g"
    assert _line_to_fn(starts, 5) is None


# =========================================================================== #
# DB-backed: auto-discovered chain_facts job (skip if none)
# =========================================================================== #
_JOB = find_chain_facts_job()
_db = pytest.mark.skipif(_JOB is None, reason="no chain_facts-ready job in jobs/ (run precompute_db "
                                              "+ chain_facts_db)")


@_db
def test_softcardvalue_lca_and_chains():
    job, bp, src = _JOB
    out = trace_variable_to_lca_chains(job, "softCardValue", "cpp",
                                       blueprint_dir=str(bp), asm_dir=str(src), debug=True)
    assert out["_debug"]["lcas"] == ["dw710000::processACreditTransaction"]
    assert out["chains"], "expected non-empty chains"
    # chains-only hop shape: cpp hops carry function, asm hops do not.
    for ch in out["chains"]:
        for hop in ch:
            assert "file" in hop
            if "function" in hop:
                assert hop["function"]                     # cpp function non-empty
    # the canonical plastic-auth chain is present and ends at the LCA. Matched with
    # "in" (not startswith): the aa71 -> dw730000 hop is corpus-invariant, but newer
    # corpus versions add deeper roots (yd61 -> xa84 -> aa71 -> ...) ahead of it.
    flat = [" -> ".join(h["file"] + ("::" + h.get("function", "") if "function" in h else "")
                        for h in ch) for ch in out["chains"]]
    assert any("aa71 -> dw730000" in c and c.endswith("dw710000::processACreditTransaction")
               for c in flat)


@_db
def test_plastic_auth_forces_lca_and_skips_computation():
    job, bp, src = _JOB
    out = trace_variable_to_lca_chains(job, "softCardValue", "cpp", blueprint_dir=str(bp),
                                       asm_dir=str(src), domain="plastic_authentication", debug=True)
    assert out["_debug"]["lcas"] == ["dw710000::callPlasticAuthenticationComponentInterface"]
    for ch in out["chains"]:
        assert ch[-1] == {"file": "dw710000", "function": "callPlasticAuthenticationComponentInterface"}


@_db
def test_forced_lca_absent_hardfails_then_warns(monkeypatch):
    job, bp, src = _JOB
    monkeypatch.setitem(DOMAIN_FORCED_LCA, "__absent__", ("nosuchstem", "cpp", "nosuchfn"))
    with pytest.raises(ForcedLcaAbsent):
        trace_variable_to_lca_chains(job, "softCardValue", "cpp", blueprint_dir=str(bp),
                                     asm_dir=str(src), domain="__absent__")
    out = trace_variable_to_lca_chains(job, "softCardValue", "cpp", blueprint_dir=str(bp),
                                       asm_dir=str(src), domain="__absent__",
                                       allow_missing_forced_lca=True)
    assert out["chains"] == []
    assert any(w["code"] == "forced_lca_absent" for w in out["warnings"])


@_db
def test_missing_artifact_hardfails():
    _job, bp, src = _JOB
    with pytest.raises(DbArtifactMissing):
        trace_variable_to_lca_chains("no-such-job-id", "softCardValue", "cpp",
                                     blueprint_dir=str(bp), asm_dir=str(src))


@_db
def test_stale_version_hardfails(monkeypatch):
    job, bp, src = _JOB
    import vbt.lca_trace as L
    real = L.DA.read_manifest

    def fake(jid, art):
        row = real(jid, art)
        if art == "fn_graph_adj" and row is not None:
            row = dict(row); row["version"] = 999          # simulate a stale artifact
        return row
    monkeypatch.setattr(L.DA, "read_manifest", fake)
    with pytest.raises(DbArtifactMissing):
        trace_variable_to_lca_chains(job, "softCardValue", "cpp",
                                     blueprint_dir=str(bp), asm_dir=str(src))


@_db
def test_prune_keeps_reachable_subset():
    job, bp, src = _JOB
    nf = trace_variable_to_lca_chains(job, "softCardValue", "cpp", blueprint_dir=str(bp), asm_dir=str(src))
    pr = trace_variable_to_lca_chains(job, "softCardValue", "cpp", blueprint_dir=str(bp), asm_dir=str(src),
                                      prune=True)
    # prune can only DROP (provably-dead) chains, never add — kept ⊆ unpruned.
    nf_set = {tuple((h["file"], h.get("function")) for h in ch) for ch in nf["chains"]}
    pr_set = {tuple((h["file"], h.get("function")) for h in ch) for ch in pr["chains"]}
    assert pr_set <= nf_set


@_db
def test_prune_requires_chain_facts(monkeypatch):
    job, bp, src = _JOB
    import vbt.lca_trace as L
    real = L.DA.read_manifest
    monkeypatch.setattr(L.DA, "read_manifest",
                        lambda jid, art: (None if art == "chain_facts" else real(jid, art)))
    with pytest.raises(DbArtifactMissing):
        trace_variable_to_lca_chains(job, "softCardValue", "cpp", blueprint_dir=str(bp),
                                     asm_dir=str(src), prune=True)


@_db
def test_hardened_no_source_fallback(monkeypatch):
    """THE proof of strict DB-only: with a fully-populated DB, monkeypatch every source/disk reader
    to RAISE — the trace (prune=True included) must return the IDENTICAL result and NO patched reader
    may fire. A monkeypatch-raise is strictly stronger than a moved source dir."""
    job, bp, src = _JOB
    baseline = trace_variable_to_lca_chains(job, "softCardValue", "cpp", blueprint_dir=str(bp),
                                            asm_dir=str(src), prune=True)
    fired = []

    def tripwire(name):
        def _boom(*a, **k):
            fired.append(name)
            raise AssertionError(f"strict DB-only violated: {name} read source/disk")
        return _boom

    # Tripwire the source/disk LEAVES (cfg subprocess, blueprint JSON, live setter scans) + the
    # resolver source-build ORCHESTRATOR (lca_trace must use strict_load_resolvers, never this).
    # NOT name_resolver._units — that is the CACHE-AWARE accessor resolve() always calls; it returns
    # from the strict-loaded cache without reading source. The resolver no-source-read is proven
    # additionally by test_nonexistent_source_dir_identical_result (data comes from the job blob).
    import vbt.cpp_frontend.wrapper as _w
    import backward_traversal.utils.blueprint_utils as _bu
    import vbt.setters.cpp_setters as _cs
    import vbt.setters.asm_setters as _as
    import vbt.precompute.resolvers_db as _rd
    monkeypatch.setattr(_w, "run_cfg_extract", tripwire("run_cfg_extract"))
    monkeypatch.setattr(_bu, "load_json", tripwire("load_json"))
    monkeypatch.setattr(_cs, "find_cpp_setters_in_file", tripwire("find_cpp_setters_in_file"))
    monkeypatch.setattr(_as, "find_asm_setters_in_file", tripwire("find_asm_setters_in_file"))
    monkeypatch.setattr(_rd, "preload_resolvers", tripwire("preload_resolvers"))

    out = trace_variable_to_lca_chains(job, "softCardValue", "cpp", blueprint_dir=str(bp),
                                       asm_dir=str(src), prune=True)
    assert not fired, f"source/disk readers fired: {fired}"
    assert out == baseline


@_db
def test_nonexistent_source_dir_identical_result():
    """Weaker cross-check: point the source dir at a nonexistent path ⇒ identical result (DB-only)."""
    job, bp, _src = _JOB
    baseline = trace_variable_to_lca_chains(job, "softCardValue", "cpp", blueprint_dir=str(bp),
                                            asm_dir=str(_src), prune=True)
    out = trace_variable_to_lca_chains(job, "softCardValue", "cpp", blueprint_dir="/no/such/bp",
                                       asm_dir="/no/such/src", prune=True)
    assert out == baseline
