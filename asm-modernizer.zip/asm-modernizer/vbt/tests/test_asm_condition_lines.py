"""Regression guard: an ASM guard condition must be anchored at the COMPARE/TEST
instruction (where the tested field + comparand live), not at the conditional-branch
or the call/decision line, and must surface the verbatim source instructions.

Real-corpus symptom (aa71): the L7DSTS guard `(L7DSTS & X'40') == X'40'` was reported
at aa71:2016 (the ENTRC DW73 call) — but `TM L7DSTS,X'40'` is at 2012 and the `JNO` at
2014. The fix anchors location.startLine at the compare (2012), keeps the branch line as
location.endLine / decisionLine, and emits asmTest/asmBranch (verbatim) since `condition`
is the engine's normalized predicate.
"""
from vbt.conditions.asm_conditions import collect_asm_conditions, find_trigger_line
from vbt.engine import _asm_block_at


def _block(insts, args, lines):
    return {"blocks": [{"id": "B1", "flow": {"i": insts, "a": args, "l": lines}}]}


def test_find_trigger_line_resolves_compare_not_branch():
    bp = _block(["TM", "JNO"], [["L7DSTS", "X'40'"], ["AA71_AN70"]], [2012, 2014])
    # the compare is at 2012; route_finder would have reported the branch (2014)
    assert find_trigger_line(bp, "TM L7DSTS, X'40'", 2014) == 2012
    # nearest-preceding when the same compare repeats
    bp2 = _block(["TM", "JNO", "TM", "JNO"],
                 [["L7DSTS", "X'40'"], ["A"], ["L7DSTS", "X'40'"], ["B"]],
                 [2012, 2014, 3000, 3002])
    assert find_trigger_line(bp2, "TM L7DSTS, X'40'", 2014) == 2012   # not 3000
    # not found → None (caller falls back to the branch line, never fabricates)
    assert find_trigger_line(bp, "CLC FOO, BAR", 2014) is None


def test_setter_local_condition_anchored_at_compare():
    # TM @2012 / JNO @2014 / ENTRC @2016 — the guard to reach the call.
    bp = _block(["TM", "JNO", "ENTRC"],
                [["L7DSTS", "X'40'"], ["AA71_AN70"], ["DW73"]],
                [2012, 2014, 2016])
    conds, _ = collect_asm_conditions(bp, "/nonexistent.asm.json", "B1",
                                      before_line=2017, file="aa71.asm")
    assert conds, "expected the TM/JNO guard"
    c = conds[0]
    assert c.location.start_line == 2012, "condition not anchored at the compare line"
    assert c.location.end_line == 2014, "branch (decision) line not kept as end_line"
    # verbatim source instructions are preserved on the Condition
    assert c.raw_test == "TM L7DSTS, X'40'"
    assert c.raw_branch == "JNO AA71_AN70"
    # the normalized predicate is still produced (not verbatim — that's `condition`)
    assert "L7DSTS" in c.condition and "&" in c.condition


def test_asm_block_at_picks_smallest_containing_block():
    # The block registered for a hop (so the descend ENTRC source lands in the trace)
    # must be the real basic block, never the file-wide container.
    bp = {"blocks": [
        {"id": "AA71BASED", "start_line": 1, "end_line": 3000},     # container
        {"id": "AA710A5B", "start_line": 2002, "end_line": 2021},   # real block (TM..ENTRC)
    ]}
    assert _asm_block_at(bp, 2016) == ("AA710A5B", 2002, 2021)   # both cover 2016 → smallest
    assert _asm_block_at(bp, 100) == ("AA71BASED", 1, 3000)      # only the container covers it
    assert _asm_block_at(bp, 5000) is None                       # no block covers it
