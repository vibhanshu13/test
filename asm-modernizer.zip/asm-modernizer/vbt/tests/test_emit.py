"""Tests for the optional output-emit layer (vbt/output/emit.py).

These run on a small HAND-BUILT sample dict (no real trace needed) so the suite
is fast. They cover: strip_code (text gone, refs kept), split round-trip,
msgpack round-trip, default-identity (the emit layer's JSON == the legacy
``json.dumps(out, indent=2)``), zip contents, and the writer's split/single
file modes.

    env/bin/python3 -m pytest vbt/tests/test_emit.py -q
"""
import json
import zipfile
from pathlib import Path

import msgpack
import pytest

from vbt.output.emit import (
    reassemble,
    serialize,
    split_output,
    strip_code,
    write_result,
)


def _sample():
    """A small but structurally complete SPEC §8 trace dict."""
    return {
        "rootVariable": {
            "name": "softCardValue",
            "aliases": [{"name": "LWRPOSFCRDV", "language": "asm", "certainty": "high"}],
            "setters": [
                {
                    "setterId": 1,
                    "value": "ExpressPay",
                    "valueResolved": None,
                    "setterCodeChunk": "softCardValue = ExpressPay;",
                    "location": {"file": "dw710000.cpp", "startLine": 1002, "endLine": 1002},
                    "chain": ["aa71", "dw730000", "dw710000"],
                    "unconditionalAtSetter": False,
                    "conditions": [
                        {"order": 1, "condition": "linkSourceArea != 0",
                         "location": {"file": "dw710000.cpp", "startLine": 990, "endLine": 990}},
                    ],
                    "dependentVariables": [
                        {"name": "lstknpoa", "qualified": "linkSourceArea->lstknpoa",
                         "foundAt": {"file": "dw710000.cpp", "startLine": 991, "endLine": 991}},
                    ],
                },
            ],
        },
        "dependentVariables": [
            {"dependentVariable": {
                "name": "lstknpoa",
                "qualified": "linkSourceArea->lstknpoa",
                "dependencies": [
                    {"variableName": "softCardValue",
                     "foundAt": {"file": "dw710000.cpp", "startLine": 991, "endLine": 991},
                     "relevantCodeChunk": "if (linkSourceArea->lstknpoa == 'Y')"},
                ],
                "setters": [
                    {"setterId": 1, "value": "'Y'", "valueResolved": None,
                     "setterCodeChunk": "lstknpoa = 'Y';", "blockId": "cpp:dw710000:DW71",
                     "location": {"file": "dw710000.cpp", "startLine": 500, "endLine": 500},
                     "conditions": []},
                ],
                "terminal": False, "is_function_output": False}},
            {"dependentVariable": {
                "name": "ptrLwrls",
                "qualified": "ptrLwrls",
                "dependencies": [],
                "setters": [],
                "terminal": True, "is_function_output": False}},
        ],
        "codeBlocks": {
            "cpp:dw710000:DW71": {"file": "dw710000.cpp", "startLine": 480, "endLine": 520,
                                  "code": "void DW71() { ... }"},
            "asm:da78:B1": {"file": "da78.asm", "startLine": 850, "endLine": 860,
                            "code": "         LA  R1,LG1OSI"},
        },
    }


# --------------------------------------------------------------------------- #
def test_strip_code_removes_text_keeps_refs():
    out = _sample()
    stripped = strip_code(out)

    # original is untouched (deep copy)
    assert "code" in out["codeBlocks"]["cpp:dw710000:DW71"]

    # all source TEXT gone
    for blk in stripped["codeBlocks"].values():
        assert "code" not in blk
        # but the ref is intact
        assert {"file", "startLine", "endLine"} <= set(blk)
    for s in stripped["rootVariable"]["setters"]:
        assert "setterCodeChunk" not in s
        assert s["location"]["startLine"] == 1002
    for dv in stripped["dependentVariables"]:
        inner = dv["dependentVariable"]
        for dep in inner["dependencies"]:
            assert "relevantCodeChunk" not in dep
            assert dep["foundAt"]["startLine"] == 991
        for s in inner["setters"]:
            assert "setterCodeChunk" not in s
            assert s["location"]["startLine"] == 500

    # no `code`/`setterCodeChunk`/`relevantCodeChunk` key anywhere
    blob = json.dumps(stripped)
    assert "setterCodeChunk" not in blob
    assert "relevantCodeChunk" not in blob
    assert '"code"' not in blob

    # measurable size reduction
    assert len(json.dumps(stripped)) < len(json.dumps(out))


def test_split_round_trip():
    out = _sample()
    parts = split_output(out)

    assert "rootVariable" in parts
    assert "codeBlocks" in parts
    assert "index" in parts
    dep_parts = [k for k in parts if k.startswith("dependentVariables/")]
    assert len(dep_parts) == 2

    # shared codeBlocks kept as ONE part (dedup preserved)
    assert parts["codeBlocks"] == out["codeBlocks"]

    assert reassemble(parts) == out


def test_split_name_collision_gets_index():
    out = _sample()
    # force a name collision after sanitization
    out["dependentVariables"][1]["dependentVariable"]["name"] = "lstknpoa"
    parts = split_output(out)
    dep_parts = sorted(k for k in parts if k.startswith("dependentVariables/"))
    assert dep_parts == ["dependentVariables/lstknpoa", "dependentVariables/lstknpoa_1"]
    assert reassemble(parts) == out


def test_msgpack_round_trip():
    out = _sample()
    packed = serialize(out, "msgpack")
    assert isinstance(packed, bytes)
    assert msgpack.unpackb(packed, raw=False) == out


def test_json_serialize_is_indent2():
    out = _sample()
    assert serialize(out, "json") == json.dumps(out, indent=2).encode("utf-8")


def test_json_serialize_compact_mode():
    out = _sample()
    assert serialize(out, "json", json_indent=None) == json.dumps(
        out, separators=(",", ":")).encode("utf-8")


def test_default_identity_stdout(capsys):
    """write_result with NO emit options == legacy json.dumps(out, indent=2)."""
    out = _sample()
    write_result(out)  # defaults: out_path/out_dir=None, fmt=json, code=True, zip=False
    captured = capsys.readouterr().out
    assert captured == json.dumps(out, indent=2) + "\n"


def test_default_identity_out_file(tmp_path):
    out = _sample()
    f = tmp_path / "result.json"
    write_result(out, out_path=f)
    assert f.read_bytes() == json.dumps(out, indent=2).encode("utf-8")


def test_compact_json_out_file(tmp_path):
    out = _sample()
    f = tmp_path / "result.json"
    write_result(out, out_path=f, json_indent=None)
    assert f.read_bytes() == json.dumps(out, separators=(",", ":")).encode("utf-8")


def test_write_split_dir(tmp_path):
    out = _sample()
    d = tmp_path / "trace"
    write_result(out, out_dir=d, asm_dir="temp/asm")

    index = json.loads((d / "index.json").read_text())
    assert index["format"] == "json"
    assert index["codeIncluded"] is True
    assert index["asmDir"] == "temp/asm"
    assert index["counts"] == {"setters": 1, "dependentVariables": 2, "codeBlocks": 2}
    assert "rootVariable.json" in index["files"]
    assert "codeBlocks.json" in index["files"]

    # every listed file exists on disk and reassembles to the original
    parts = {}
    for rel in index["files"]:
        obj = json.loads((d / rel).read_text())
        parts[rel[: -len(".json")]] = obj
    parts["index"] = index
    assert reassemble(parts) == out


def test_write_split_no_code(tmp_path):
    out = _sample()
    d = tmp_path / "trace"
    write_result(out, out_dir=d, include_code=False)
    index = json.loads((d / "index.json").read_text())
    assert index["codeIncluded"] is False
    cb = json.loads((d / "codeBlocks.json").read_text())
    for blk in cb.values():
        assert "code" not in blk and "startLine" in blk


def test_write_split_zip(tmp_path):
    out = _sample()
    d = tmp_path / "trace"
    write_result(out, out_dir=d, zip_=True)
    z = tmp_path / "trace.zip"
    assert z.exists()
    with zipfile.ZipFile(z) as zf:
        names = set(zf.namelist())
        assert zipfile.is_zipfile(z)
        assert "rootVariable.json" in names
        assert "codeBlocks.json" in names
        assert "index.json" in names
        assert any(n.startswith("dependentVariables/") for n in names)
        # reassemble from the zip
        parts = {}
        index = json.loads(zf.read("index.json"))
        for rel in index["files"]:
            parts[rel[: -len(".json")]] = json.loads(zf.read(rel))
        parts["index"] = index
    assert reassemble(parts) == out


def test_write_single_zip(tmp_path):
    out = _sample()
    f = tmp_path / "result.json"
    write_result(out, out_path=f, zip_=True)
    z = tmp_path / "result.zip"
    assert z.exists()
    with zipfile.ZipFile(z) as zf:
        assert zf.namelist() == ["result.json"]
        assert json.loads(zf.read("result.json")) == out


def test_write_split_msgpack(tmp_path):
    out = _sample()
    d = tmp_path / "trace"
    write_result(out, out_dir=d, fmt="msgpack")
    index = msgpack.unpackb((d / "index.msgpack").read_bytes(), raw=False)
    assert index["format"] == "msgpack"
    parts = {}
    for rel in index["files"]:
        parts[rel[: -len(".msgpack")]] = msgpack.unpackb((d / rel).read_bytes(), raw=False)
    parts["index"] = index
    assert reassemble(parts) == out
