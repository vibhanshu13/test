"""§16 #1: whole-trace result cache — signature determinism/sensitivity + prefix clear.

The end-to-end byte-identical + instant-hit proof lives in the parity check (run twice with a
job_id). Here we test the pure signature logic and the prefix-delete mechanism.
"""
from __future__ import annotations

from vbt.engine import Hop
from vbt.precompute import db_artifacts as DA
from vbt.precompute.trace_cache import signature, store

_CHAIN = [Hop("aa71", "asm", None), Hop("dw730000", "cpp", "DW73")]
_BASE = dict(candidate_stems=None, candidate_functions=None, home_hint=None,
             disable_dependents=True, max_dep_var_depth=1, max_paths=64, max_call_depth=16,
             max_routes=200, max_route_len=16, max_offchain_files=100, asm_max_levels=16)


def _sig(**over):
    kw = dict(_BASE)
    kw.update(over)
    return signature("softCardValue", "cpp", _CHAIN, "/bp", "/src", "/g", **kw)


def test_signature_is_deterministic():
    assert _sig() == _sig()


def test_signature_is_sensitive_to_every_output_affecting_input():
    base = _sig()
    assert _sig(max_dep_var_depth=3) != base          # a cap change
    assert _sig(max_offchain_files=1000) != base       # another cap
    assert _sig(disable_dependents=False) != base      # dependents toggle
    assert signature("other", "cpp", _CHAIN, "/bp", "/src", "/g", **_BASE) != base   # variable
    assert signature("softCardValue", "cpp", _CHAIN, "/bp2", "/src", "/g", **_BASE) != base  # path


def test_clear_blobs_prefix_only_removes_matching(tmp_path):
    from sqlalchemy import create_engine, delete, select
    from api.index_db.schema import metadata, vbt_artifact_blob as t
    eng = create_engine(f"sqlite:///{tmp_path / 'i.db'}")
    metadata.create_all(eng)
    DA.write_blob_with_engine(eng, "j", "trace:aaa", DA.dumps_gz({"x": 1}))
    DA.write_blob_with_engine(eng, "j", "trace:bbb", DA.dumps_gz({"x": 2}))
    DA.write_blob_with_engine(eng, "j", "name_alias", DA.dumps_gz({"keep": 1}))
    # mirror clear_blobs_prefix's delete (it uses get_engine internally)
    with eng.begin() as c:
        c.execute(delete(t).where((t.c.job_id == "j") & (t.c.artifact.like("trace:%"))))
    with eng.connect() as c:
        left = c.execute(select(t.c.artifact).where(t.c.job_id == "j")).scalars().all()
    assert left == ["name_alias"]   # trace:* gone, other artifacts untouched


def test_store_skips_large_depvar_outputs_by_default(monkeypatch):
    writes = []
    monkeypatch.setattr(DA, "write_blob", lambda *args, **kwargs: writes.append(args) or True)
    out = {"dependentVariables": [{"dependentVariable": {"name": str(i)}} for i in range(10001)]}

    store("j", "sig", out)

    assert writes == []


def test_store_threshold_can_be_disabled(monkeypatch):
    writes = []
    monkeypatch.setenv("VBT_TRACE_CACHE_MAX_DEP_VARS", "0")
    monkeypatch.setattr(DA, "write_blob", lambda *args, **kwargs: writes.append(args) or True)
    out = {"dependentVariables": [{"dependentVariable": {"name": "x"}} for _ in range(10001)]}

    store("j", "sig", out)

    assert len(writes) == 1
