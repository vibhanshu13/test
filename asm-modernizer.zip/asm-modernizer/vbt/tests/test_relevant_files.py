"""Tests for the grep-based relevant-files enumerator + CLOSURE mode.

Run from repo root:

    env/bin/python3 -m pytest vbt/tests/test_relevant_files.py -q

The closure tests use a small SYNTHETIC source dir (no blueprints, no baseline,
no LLM) so they are fast and hermetic: a C++ setter file that ``#include``\\s an
in-dir header (and one out-of-dir header that must be IGNORED), and an ASM file
that ``COPY``\\s an in-dir macro (and one out-of-dir member that must be IGNORED).
This exercises every closure category — #include closure, COPY/macro closure,
and (separately) the resolver-triple discovery — and the determinism + default-
behavior guarantees, without depending on the heavy engine.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from vbt.relevant_files import (
    enumerate_relevant_files,
    compute_closure,
    copy_closure_files,
    _cpp_include_closure,
    _asm_copy_closure,
    _resolver_triples,
    _index_dir,
    _names_to_paths,
)


# --------------------------------------------------------------------------- #
# Synthetic source dir
# --------------------------------------------------------------------------- #
@pytest.fixture()
def src(tmp_path: Path) -> Path:
    """A tiny mixed C++/ASM source dir with in-dir + out-of-dir dependencies."""
    d = tmp_path / "src"
    d.mkdir()

    # C++ setter file that includes an in-dir header AND an out-of-dir one.
    (d / "writer.cpp").write_text(
        '#include <inhdr.hpp>\n'        # in-dir -> must be added
        '#include <system_only.hpp>\n'  # NOT in-dir -> must be ignored
        'void f() {\n'
        '    myField = 1;\n'            # a setter for myField
        '    other = myField;\n'
        '}\n'
    )
    # in-dir header that transitively includes another in-dir header (chain).
    (d / "inhdr.hpp").write_text('#include <inhdr2.hpp>\nstruct A { int x; };\n')
    (d / "inhdr2.hpp").write_text('struct B { int y; };\n')

    # ASM setter file that COPYs an in-dir macro AND an out-of-dir member.
    (d / "prog.asm").write_text(
        "PROG     CSECT\n"
        "         COPY  INMAC\n"        # in-dir -> must be added
        "         COPY  EXTONLY\n"      # NOT in-dir -> must be ignored
        "         ST    R1,MYSYM\n"     # a setter for MYSYM
    )
    # in-dir macro that COPYs another in-dir macro (transitive).
    (d / "inmac.mac").write_text("         COPY  INMAC2\n         DS  F\n")
    (d / "inmac2.mac").write_text("         DS  F\n")
    return d


# --------------------------------------------------------------------------- #
# Closure building blocks (pure, hermetic)
# --------------------------------------------------------------------------- #
def test_cpp_include_closure_in_dir_transitive_and_bounded(src: Path):
    idx = _index_dir(src)
    seed = _names_to_paths({"writer.cpp"}, idx)
    added = {p.name for p in _cpp_include_closure(seed, src)}
    # transitive in-dir headers added; out-of-dir <system_only.hpp> ignored.
    assert added == {"inhdr.hpp", "inhdr2.hpp"}
    assert "system_only.hpp" not in added


def test_asm_copy_closure_in_dir_transitive(src: Path):
    idx = _index_dir(src)
    seed = _names_to_paths({"prog.asm"}, idx)
    added = {p.name for p in _asm_copy_closure(seed, idx, src)}
    # transitive in-dir macros added; out-of-dir EXTONLY ignored.
    assert added == {"inmac.mac", "inmac2.mac"}


def test_resolver_triples_only_existing(src: Path):
    # synthetic dir has no cc*/gen/mac triple; a made-up stem yields nothing.
    idx = _index_dir(src)
    assert _resolver_triples(["nope"], idx) == set()


# --------------------------------------------------------------------------- #
# End-to-end compute_closure on the synthetic dir
# --------------------------------------------------------------------------- #
def test_compute_closure_categorizes_and_dedupes(src: Path):
    enum = enumerate_relevant_files("myField", src, unlimited=True, language="cpp")
    c = compute_closure(enum, src)
    # writer.cpp is the C++ setter seed.
    assert "writer.cpp" in c.seed_files
    # its in-dir #include chain is added as headers.
    assert set(c.added_headers) == {"inhdr.hpp", "inhdr2.hpp"}
    # closed set is the sorted union with no duplicates.
    assert c.files == sorted(set(c.files))
    assert set(c.files) >= {"writer.cpp", "inhdr.hpp", "inhdr2.hpp"}
    # by_ext counts cover the whole closed set.
    assert sum(c.by_ext.values()) == len(c.files)


def test_closure_is_deterministic(src: Path):
    enum1 = enumerate_relevant_files("myField", src, unlimited=True, language="cpp")
    enum2 = enumerate_relevant_files("myField", src, unlimited=True, language="cpp")
    c1 = compute_closure(enum1, src)
    c2 = compute_closure(enum2, src)
    assert c1.files == c2.files


def test_copy_closure_copies_every_file(src: Path, tmp_path: Path):
    enum = enumerate_relevant_files("myField", src, unlimited=True, language="cpp")
    c = compute_closure(enum, src)
    dest = tmp_path / "subset"
    copied, missing = copy_closure_files(c, src, dest)
    assert missing == []
    assert copied == len(c.files)
    for name in c.files:
        assert (dest / name).is_file()


# --------------------------------------------------------------------------- #
# Default (non-closure) behavior must be unchanged
# --------------------------------------------------------------------------- #
def test_default_enumeration_unchanged(src: Path):
    enum = enumerate_relevant_files("myField", src, unlimited=True, language="cpp")
    # default seed enumeration finds the C++ setter file and NOT headers/macros.
    assert "writer.cpp" in enum.files
    assert "inhdr.hpp" not in enum.files
    assert "inmac.mac" not in enum.files
