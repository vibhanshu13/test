"""§16 #2-full: cross-trace route-cache persist/preload round-trip.

The end-to-end byte-identical proof is the shadow run (cold vs warm trace → identical output) +
the parity gate. Here we test the pure persist→preload mechanics: the memo tuple key (which has a
``None`` function component and an int ``max_routes``) and the result dict must survive the
JSON-blob round-trip exactly, and the cap must bound the persisted set.
"""
from __future__ import annotations

from sqlalchemy import create_engine
from api.index_db.schema import metadata
from vbt.precompute import db_artifacts as DA
from vbt.precompute import route_cache_db as RC


class _FakeRoute:
    def __init__(self, memo):
        self._routes_memo = memo


def _engine(tmp_path):
    eng = create_engine(f"sqlite:///{tmp_path / 'index.db'}")
    metadata.create_all(eng)
    return eng


def test_persist_preload_roundtrip_preserves_key_types(tmp_path, monkeypatch):
    eng = _engine(tmp_path)
    monkeypatch.setattr(DA, "get_engine", lambda job_id: eng, raising=False)
    # also patch the engine used inside read/write_blob (they call api.index_db.get_engine)
    import api.index_db.engine as _E
    monkeypatch.setattr(_E, "get_engine", lambda job_id: eng, raising=False)

    # keys mirror RouteEngine: (p_stem, p_type, p_fn_or_None, c_stem, c_type, c_fn, max_routes:int)
    memo = {
        ("aa71", "asm", None, "dw73", "cpp", "DW73", 200): {"reachable": True, "routes": [{"hops": [], "files": ["aa71"]}]},
        ("dw73", "cpp", "DW73", "dw71", "cpp", "f", 1): {"reachable": False, "routes": []},
    }
    assert RC.persist_route_cache(_FakeRoute(memo), "j") is True

    fresh = {}
    n = RC.preload_route_cache(_FakeRoute(fresh), "j")
    assert n == 2
    # tuple keys reconstructed exactly — None and the int max_routes preserved (not "None"/"200")
    assert set(fresh.keys()) == set(memo.keys())
    assert fresh[("aa71", "asm", None, "dw73", "cpp", "DW73", 200)] == memo[("aa71", "asm", None, "dw73", "cpp", "DW73", 200)]


def test_preload_missing_blob_is_noop(tmp_path, monkeypatch):
    eng = _engine(tmp_path)
    import api.index_db.engine as _E
    monkeypatch.setattr(_E, "get_engine", lambda job_id: eng, raising=False)
    fresh = {}
    assert RC.preload_route_cache(_FakeRoute(fresh), "j") == 0   # cold DB → no-op
    assert fresh == {}


def test_no_job_id_is_noop():
    assert RC.preload_route_cache(_FakeRoute({}), None) == 0
    assert RC.persist_route_cache(_FakeRoute({"k": 1}), None) is False


class _FakeRoute2:
    def __init__(self, memo, rmemo):
        self._routes_memo = memo
        self._reachable_memo = rmemo


def test_reachable_memo_roundtrip_and_v1_compat(tmp_path, monkeypatch):
    """v2: the reachable memo (the dep-var BFS's dominant route cost — off-chain setter and
    param-binding checks all go through route.reachable) must persist + preload alongside the
    routes memo; a v1 legacy blob (bare list) must still load as routes-only."""
    eng = _engine(tmp_path)
    import api.index_db.engine as _E
    monkeypatch.setattr(_E, "get_engine", lambda job_id: eng, raising=False)

    memo = {("aa71", "asm", None, "dw73", "cpp", "DW73", 200): {"reachable": True, "routes": []}}
    # reachable key mirrors RouteEngine.reachable: (...endpoints..., max_len:int) -> bool
    rmemo = {("aa71", "asm", None, "dw73", "cpp", "DW73", 16): True,
             ("dw73", "cpp", "f", "aa71", "asm", None, 16): False}
    assert RC.persist_route_cache(_FakeRoute2(memo, rmemo), "j2") is True

    m2, r2 = {}, {}
    n = RC.preload_route_cache(_FakeRoute2(m2, r2), "j2")
    assert n == 3
    assert set(m2.keys()) == set(memo.keys())
    assert r2 == rmemo                                  # bools + tuple keys exact

    # a route object WITHOUT a _reachable_memo (legacy caller) must not break preload
    m3 = {}
    assert RC.preload_route_cache(_FakeRoute(m3), "j2") == 1
    assert set(m3.keys()) == set(memo.keys())

    # v1 legacy blob (bare [[key, result], ...] list) still loads
    legacy = [[list(k), v] for k, v in memo.items()]
    DA.write_blob("j1", RC.ARTIFACT, DA.dumps_gz(legacy))
    m4, r4 = {}, {}
    assert RC.preload_route_cache(_FakeRoute2(m4, r4), "j1") == 1
    assert set(m4.keys()) == set(memo.keys()) and r4 == {}


def test_reachable_only_memo_persists(tmp_path, monkeypatch):
    """A trace whose route walks were ALL reachable() checks (empty routes memo) must still
    persist — this was the exact gap that left KBs with no route_cache blob at all."""
    eng = _engine(tmp_path)
    import api.index_db.engine as _E
    monkeypatch.setattr(_E, "get_engine", lambda job_id: eng, raising=False)
    rmemo = {("aa71", "asm", None, "dw73", "cpp", "DW73", 16): True}
    assert RC.persist_route_cache(_FakeRoute2({}, rmemo), "j3") is True
    m, r = {}, {}
    assert RC.preload_route_cache(_FakeRoute2(m, r), "j3") == 1
    assert r == rmemo and m == {}
