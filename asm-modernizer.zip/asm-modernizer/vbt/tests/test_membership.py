"""Per-variable membership + cross-language counterpart (vbt/resolve/membership.py).

Every traced variable gets two facts: the struct (C++) / DSECT-macro (ASM) it belongs
to, and its high-certainty cross-language twin (+ that twin's struct/mac), when one
resolves. Validates against the temp/asm source (same cc/gen/mac triples as the corpus):

  * softCardValue (cpp)  -> struct PlasticAuth ; counterpart LWRPOSFCRDV (asm, mac LWRPO)
  * L7DSTS (asm)         -> mac L7D7D ; counterpart accountStatus (cpp, struct BasicCreditInputSegment)
  * a C++-only field is disambiguated to ONE struct via its qualified path
  * a bare local has neither struct nor counterpart (both None)

Skips when the temp/asm source (cc*.hpp + *.mac) is absent.
"""
from pathlib import Path

import pytest

SRC = Path("temp/asm")
BP = Path("temp/asm")   # blueprint_dir is only used as a cache key here; source drives it

pytestmark = pytest.mark.skipif(
    not (SRC.exists() and list(SRC.glob("cc*.hpp")) and list(SRC.glob("*.mac"))),
    reason="temp/asm cc*.hpp + *.mac source not present",
)


@pytest.fixture(scope="module")
def resolver():
    from vbt.resolve.membership import get_membership_resolver
    return get_membership_resolver(BP, SRC)


def test_cpp_field_resolves_struct_and_asm_counterpart(resolver):
    r = resolver.resolve("softCardValue", "cpp", "plasticAuth.process.transactionInds.softCardValue")
    assert r["memberOf"] == {"language": "cpp", "kind": "struct", "name": "PlasticAuth"}
    cp = r["counterpart"]
    assert cp and cp["name"] == "LWRPOSFCRDV" and cp["language"] == "asm"
    assert cp["memberOf"] == {"language": "asm", "kind": "mac", "name": "LWRPO"}


def test_asm_symbol_resolves_mac_and_cpp_counterpart(resolver):
    r = resolver.resolve("L7DSTS", "asm")
    assert r["memberOf"] == {"language": "asm", "kind": "mac", "name": "L7D7D"}
    cp = r["counterpart"]
    assert cp and cp["language"] == "cpp" and cp["name"].endswith("accountStatus")
    assert cp["memberOf"]["kind"] == "struct" and cp["memberOf"]["name"] == "BasicCreditInputSegment"


def test_counterpart_is_symmetric(resolver):
    fwd = resolver.resolve("L7DSTS", "asm")["counterpart"]["name"].split(".")[-1]
    back = resolver.resolve(fwd, "cpp")["counterpart"]
    assert back and back["name"] == "L7DSTS"


def test_cpp_only_field_disambiguated_by_qualified_path(resolver):
    # plasticAuthOnlyArea is declared in several records; the qualified-path root picks one.
    r = resolver.resolve("plasticAuthOnlyArea", "cpp", "addresses->plasticAuthOnlyArea")
    mo = r["memberOf"]
    assert mo and mo["kind"] == "struct" and mo["name"] == "LwrAddresses"
    assert r["counterpart"] is None        # C++-only field has no ASM twin


def test_bare_local_has_no_struct_or_counterpart(resolver):
    r = resolver.resolve("task", "cpp")
    assert r["memberOf"] is None and r["counterpart"] is None


def test_ambiguous_surfaces_candidates_not_a_guess(resolver):
    # with no qualified path to disambiguate, an ambiguous tail lists candidates rather
    # than guessing a single (possibly wrong) struct.
    r = resolver.resolve("plasticAuthOnlyArea", "cpp")
    mo = r["memberOf"]
    assert mo is not None
    if mo["name"] is None:
        assert len(mo.get("candidates", [])) > 1
