"""Tree-sitter enclosing-guard fallback (vbt/conditions/ts_guards.py).

Two layers:
  * baseline-independent unit tests of the up-walk (switch/case, if/else polarity, loops)
    on tiny .cpp fixtures written to tmp_path — fast, deterministic, no corpus needed;
  * a corpus-guarded integration test proving collect_cpp_conditions now recovers the
    gate-3 conditions for processACreditTransaction's truncated call sites (dw710000.cpp).
"""
from pathlib import Path

import pytest

from vbt.conditions.ts_guards import ts_enclosing_guards

ASM = Path("temp/asm")


def _line_of(text: str, needle: str) -> int:
    for i, ln in enumerate(text.splitlines(), 1):
        if needle in ln:
            return i
    raise AssertionError(f"{needle!r} not found")


def _write(tmp_path, text):
    p = tmp_path / "x.cpp"
    p.write_text(text)
    return str(p), text


def test_switch_case_and_if_guards(tmp_path):
    src = """\
void route();
void f(int sel, int flag) {
    switch (sel) {
    case 3:
        if (flag == 1) {
            route();   // TARGET
        }
        break;
    default:
        break;
    }
}
"""
    path, text = _write(tmp_path, src)
    gs = ts_enclosing_guards(path, _line_of(text, "TARGET"))
    conds = [(c.condition, c.kind, c.polarity) for c in gs]
    # outer→inner: switch-case first, then the if
    assert conds == [("sel == 3", "switch", True), ("flag == 1", "if", True)], conds
    assert [c.order for c in gs] == [1, 2]


def test_else_branch_is_negated(tmp_path):
    src = """\
void a(); void b();
void g(int flag) {
    if (flag == 0) {
        a();
    } else {
        b();   // TARGET
    }
}
"""
    path, text = _write(tmp_path, src)
    gs = ts_enclosing_guards(path, _line_of(text, "TARGET"))
    assert [(c.condition, c.polarity) for c in gs] == [("!(flag == 0)", False)], \
        [(c.condition, c.polarity) for c in gs]


def test_default_case_has_no_equality_guard(tmp_path):
    src = """\
void route();
void h(int sel) {
    switch (sel) {
    case 1: break;
    default:
        route();   // TARGET
    }
}
"""
    path, text = _write(tmp_path, src)
    gs = ts_enclosing_guards(path, _line_of(text, "TARGET"))
    assert len(gs) == 1 and "default" in gs[0].condition and gs[0].polarity is None, \
        [(c.condition, c.polarity) for c in gs]


def test_no_guards_when_unconditional(tmp_path):
    src = """\
void route();
void k() {
    route();   // TARGET
}
"""
    path, text = _write(tmp_path, src)
    assert ts_enclosing_guards(path, _line_of(text, "TARGET")) == []


@pytest.mark.skipif(not (ASM / "dw710000.cpp").exists(),
                    reason="temp/asm/dw710000.cpp not present")
def test_collect_conditions_recovers_gate3_via_fallback():
    # L1093 (processMagSwipeWith4dbc call) is PAST the cfg truncation (1057): the gate-3
    # switch+if guards must be recovered by the tree-sitter fallback.
    from vbt.conditions.cpp_conditions import collect_cpp_conditions
    conds = collect_cpp_conditions(str(ASM / "dw710000.cpp"), 1093, "processACreditTransaction")
    texts = [c.condition for c in conds]
    assert any("securityCode.length == SecurityCodeLength::StripeSecurityCode" in t
               for t in texts), texts
    assert any("doSwipeWith4DBC == Cas::Yes" in t for t in texts), texts


@pytest.mark.skipif(not (ASM / "dw710000.cpp").exists(),
                    reason="temp/asm/dw710000.cpp not present")
def test_fallback_does_not_fire_before_truncation():
    # L1002 (a setter BEFORE the truncation) must come from the Clang CFG only — the
    # fallback adds nothing, and the gate-1 guards are intact.
    from vbt.conditions.cpp_conditions import collect_cpp_conditions
    conds = collect_cpp_conditions(str(ASM / "dw710000.cpp"), 1002, "processACreditTransaction")
    texts = [c.condition for c in conds]
    assert any("linkSourceArea" in t for t in texts), texts
    # no tree-sitter-origin block_id on a non-truncated line
    assert all(not (c.block_id or "").endswith("#tsguard") for c in conds)
