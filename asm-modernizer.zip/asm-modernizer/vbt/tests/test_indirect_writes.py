"""GAP 6 — C++→ASM TPF_regs register-bridge data-source setters (docs/2026-06-28-gap6-…-FIX-PLAN.md §8).

Covers: the bounded escape/bridge attribution (§8.1-8.4), comment-blindness (§8.3b), the bare-aggregate
descendant gate / P0 (§8.5), the DB round-trip (§8.6), the no-file-read load contract (§8.7), flag-OFF
additivity (§8.8), and CFG reuse (§8.9). P2 (ASM descent, §8.10) is a separate phase — not asserted here.
"""
from __future__ import annotations

from pathlib import Path

import pytest

BP = Path("jobs/baseline-temp-asm/output")
ASM = Path("temp/asm")
GF = BP / "file_call_graph.json"

pytestmark = pytest.mark.skipif(
    not BP.exists() or not GF.exists() or not (ASM / "dw780000.cpp").exists(),
    reason="baseline corpus (jobs/baseline-temp-asm + temp/asm) not built",
)

from vbt.cpp_frontend.wrapper import run_cfg_extract
from vbt.precompute.cpp_indirect_writes_db import (
    compute_bridge_writers, _aggregate_bindings, _ss_to_row, _row_to_ss,
    _addr_of_base, _arg_base, _is_zero_fill,
)
from vbt.precompute import db_artifacts as DA


# --------------------------------------------------------------------------- #
# fixtures / helpers
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="module")
def bindings():
    return _aggregate_bindings(BP)


def _writers(cpp_stem, bindings, defined=None):
    p = ASM / f"{cpp_stem}.cpp"
    return compute_bridge_writers(
        p, bindings=bindings["bindings"],
        defined_fns=set(defined if defined is not None else bindings["defined_fns"]),
        get_cfg=lambda: run_cfg_extract(str(p)))


def _vpay(site):
    return [(c.polarity, c.condition) for c in (site.preset_conditions or [])
            if "VPAY" in (c.condition or "")]


# --------------------------------------------------------------------------- #
# §8.1 — bridge setters at the guarded calls only
# --------------------------------------------------------------------------- #
def test_bridge_setters_at_call_lines_only(bindings):
    res = _writers("dw780000", bindings)
    assert set(res) == {"allCidRecordWorkArea"}, "only the prepared CID work-area buffer qualifies"
    lines = sorted(s.line for s in res["allCidRecordWorkArea"])
    assert lines == [207, 215], "exactly the two guarded ASM-bridge calls (not getTmsTableEntry@200)"
    for s in res["allCidRecordWorkArea"]:
        assert s.function == "getAllCidRecords"
        assert s.variable == "allCidRecordWorkArea"
        assert s.file_stem == "dw780000" and s.language == "cpp"
        assert s.bridge and s.bridge["reg"] == "R1"   # carried via the TPF_regs.r1 register field


# --------------------------------------------------------------------------- #
# §8.2 — VPAY guard at the right polarity
# --------------------------------------------------------------------------- #
def test_vpay_guard_polarity(bindings):
    res = _writers("dw780000", bindings)
    by_line = {s.line: s for s in res["allCidRecordWorkArea"]}
    g207 = _vpay(by_line[207])
    g215 = _vpay(by_line[215])
    assert g207 and g207[0][0] is True, "retrieveCrcnCidData runs when VPAY matches (polarity True)"
    assert g215 and g215[0][0] is False, "callAccountManager runs in the else (negated VPAY)"
    assert 'memcmp(&tmsTablePtr->productType,"VPAY",4)' in g207[0][1]


# --------------------------------------------------------------------------- #
# §8.3 — binding resolution (corpus-global)
# --------------------------------------------------------------------------- #
def test_binding_resolution(bindings):
    res = _writers("dw780000", bindings)
    by_line = {s.line: s for s in res["allCidRecordWorkArea"]}
    assert by_line[215].value == "«SL70»"
    assert by_line[215].instruction == "asm_bridge"
    assert by_line[215].bridge["asm_module"] == "SL70"      # #pragma map(callAccountManager,"SL70")
    # retrieveCrcnCidData has no binding in this corpus → external leaf keeping the callee identifier
    assert by_line[207].value == "«retrieveCrcnCidData»"
    assert by_line[207].instruction == "external_source"
    assert by_line[207].bridge["asm_module"] is None


def test_binding_corpus_global_and_defined_fns(bindings):
    # The callAccountManager→SL70 binding lives in a header (pipeline.hpp), not dw780000's blueprint.
    assert bindings["bindings"].get("callAccountManager") == "SL70"
    df = set(bindings["defined_fns"])
    assert "getAllCidRecords" in df                          # has a C++ body
    assert "retrieveCrcnCidData" not in df and "callAccountManager" not in df  # ASM/external entries


# --------------------------------------------------------------------------- #
# §8.3b — comment-blindness (no fact from a comment / commented-out directive)
# --------------------------------------------------------------------------- #
def test_binding_is_comment_blind(bindings):
    # pipeline.hpp has `//R044 #pragma map(callSeMerchInterface,"EA90")` (commented) directly above the
    # active `#pragma map(callSeMerchInterface,"SE90")` — the binding must be the ACTIVE one.
    assert bindings["bindings"].get("callSeMerchInterface") == "SE90"


def test_compute_is_comment_blind(tmp_path, bindings):
    # An idiom whose bridge call is COMMENTED OUT yields no setter; the active one does.
    src = (
        "struct TPF_regs { long r1; };\n"
        "struct Buf { char x[8]; };\n"
        "extern int activeBridge(TPF_regs*);\n"
        "extern int deadBridge(TPF_regs*);\n"
        "void f() {\n"
        "    Buf buf;\n"
        "    memset(&buf, 0, sizeof(buf));\n"
        "    TPF_regs regs;\n"
        "    regs.r1 = (long)&buf;\n"
        "    // deadBridge(&regs);\n"
        "    activeBridge(&regs);\n"
        "}\n"
    )
    p = tmp_path / "cb.cpp"
    p.write_text(src)
    res = compute_bridge_writers(p, bindings={"activeBridge": "AB99", "deadBridge": "XX99"},
                                 defined_fns=set(), get_cfg=lambda: run_cfg_extract(str(p)))
    callees = {s.bridge["callee"] for sites in res.values() for s in sites}
    assert "activeBridge" in callees
    assert "deadBridge" not in callees, "a commented-out call must never produce a bridge setter"


# --------------------------------------------------------------------------- #
# §8.4 — gates: defined callee / real direct setter / scalar / builtins → no bridge
# --------------------------------------------------------------------------- #
def test_gate_in_corpus_defined_callee_no_bridge(bindings):
    # If both callees were (wrongly) considered C++-defined, no bridge is emitted (normal-call gate).
    res = _writers("dw780000", bindings,
                   defined=set(bindings["defined_fns"]) | {"retrieveCrcnCidData", "callAccountManager"})
    assert res == {}


def test_gate_builtins_never_bridge(bindings):
    # memset/memcpy/memcmp pass &buffer but are libc byte ops, never an ASM data source.
    res = _writers("dw780000", bindings)
    callees = {s.bridge["callee"] for sites in res.values() for s in sites}
    assert callees == {"retrieveCrcnCidData", "callAccountManager"}
    assert not (callees & {"memset", "memcpy", "memcmp"})


def test_gate_scalar_and_real_setter_no_bridge(tmp_path, bindings):
    src = (
        "struct TPF_regs { long r1; };\n"
        "struct Buf { char x[8]; };\n"
        "extern int br(TPF_regs*);\n"
        "void f() {\n"
        "    int scalar = 5;\n"            # scalar, real setter → never a buffer
        "    Buf buf;\n"
        "    buf.x[0] = 'A';\n"            # real direct write → NOT escape-only
        "    TPF_regs regs;\n"
        "    regs.r1 = (long)&buf;\n"
        "    br(&regs);\n"
        "    (void)scalar;\n"
        "}\n"
    )
    p = tmp_path / "g.cpp"
    p.write_text(src)
    res = compute_bridge_writers(p, bindings={"br": "BR99"}, defined_fns=set(),
                                 get_cfg=lambda: run_cfg_extract(str(p)))
    assert res == {}, "a buffer with a real direct field write is not escape-only → no bridge"


# --------------------------------------------------------------------------- #
# §8.5 — P0 bare-name aggregate descendant gate
# --------------------------------------------------------------------------- #
def test_p0_bare_aggregate_init_only_and_descendants():
    from vbt.depvars.recurse import _setters_init_only
    from vbt.setters.cpp_setters import find_cpp_setters_in_file, find_cpp_writes_under_path
    p = ASM / "dw780000.cpp"
    # allCidRecords has no whole-object setter (only field writers) → init-only aggregate.
    assert _setters_init_only(find_cpp_setters_in_file("allCidRecords", p)) is True
    # its descendants (the field writers) are discoverable by the path-family scan.
    descs = {getattr(s, "lhs_path", "") for s in find_cpp_writes_under_path(["allCidRecords"], p)}
    assert any("numberOfCidRecords" in d for d in descs)
    assert any("cidItem" in d for d in descs)
    # the buffer it feeds is itself init-only (memset-zero only).
    assert _setters_init_only(find_cpp_setters_in_file("allCidRecordWorkArea", p)) is True


def test_p0_scalar_with_real_setter_not_init_only():
    from vbt.depvars.recurse import _setters_init_only
    from vbt.setters.cpp_setters import find_cpp_setters_in_file
    # returnValue = retrieveCrcnCidData(...) is a real direct assignment → not init-only.
    s = find_cpp_setters_in_file("returnValue", ASM / "dw780000.cpp")
    assert s and _setters_init_only(s) is False


# --------------------------------------------------------------------------- #
# §8.6 — DB round-trip (SetterSite + nested preset_conditions + bridge)
# --------------------------------------------------------------------------- #
def test_db_roundtrip_byte_equal(bindings):
    res = _writers("dw780000", bindings)
    blob = {B: [_ss_to_row(s) for s in sites] for B, sites in res.items()}
    rt = DA.loads_gz(DA.dumps_gz(blob))
    back = {B: [_row_to_ss(d) for d in rows] for B, rows in rt.items()}
    orig = res["allCidRecordWorkArea"]
    rb = back["allCidRecordWorkArea"]
    assert len(orig) == len(rb)
    for o, b in zip(orig, rb):
        assert (o.variable, o.file_stem, o.line, o.value, o.instruction, o.function) == \
               (b.variable, b.file_stem, b.line, b.value, b.instruction, b.function)
        assert o.bridge == b.bridge
        assert [(c.condition, c.polarity, c.location.file, c.location.start_line) for c in o.preset_conditions] == \
               [(c.condition, c.polarity, c.location.file, c.location.start_line) for c in b.preset_conditions]


# --------------------------------------------------------------------------- #
# §8.7 — no source file reads on the load path (DB-served, fail-closed)
# --------------------------------------------------------------------------- #
def test_load_bridge_writers_no_file_reads(tmp_path, monkeypatch, bindings):
    from api.config import settings
    from vbt.precompute.cpp_indirect_writes_db import (
        build_and_store_cpp_indirect_writes, load_bridge_writers, set_cpp_indirect_writes_job,
        clear_caches,
    )
    job = "test-indirect-writes-noread"
    monkeypatch.setattr(settings, "JOBS_BASE_DIR", str(tmp_path))

    # build (reads files — allowed in precompute); the per-stem blob lands in the temp job DB.
    n = build_and_store_cpp_indirect_writes(job, BP, ASM)
    assert n >= 1

    clear_caches()
    set_cpp_indirect_writes_job(job)
    DA.set_load_only(True)

    # tripwire: any SOURCE/blueprint content read is a failure; stat/exists stay allowed.
    src_exts = (".cpp", ".hpp", ".asm", ".mac", ".h", ".cc", ".cxx")
    real_rt, real_rb = Path.read_text, Path.read_bytes

    def _guard_rt(self, *a, **k):
        assert self.suffix.lower() not in src_exts, f"trace read source file {self}"
        return real_rt(self, *a, **k)

    def _guard_rb(self, *a, **k):
        assert self.suffix.lower() not in src_exts, f"trace read source bytes {self}"
        return real_rb(self, *a, **k)

    def _no_clang(*a, **k):
        raise AssertionError("run_cfg_extract (live) must not run in a load-only trace")

    try:
        monkeypatch.setattr(Path, "read_text", _guard_rt)
        monkeypatch.setattr(Path, "read_bytes", _guard_rb)
        monkeypatch.setattr("vbt.precompute.cpp_indirect_writes_db.run_cfg_extract", _no_clang, raising=False)
        sites = load_bridge_writers(job, "dw780000", "allCidRecordWorkArea", asm_dir=ASM, blueprint_dir=BP)
        assert {s.value for s in sites} == {"«SL70»", "«retrieveCrcnCidData»"}
        assert all(s.preset_conditions for s in sites)        # guards came from the DB blob, not a re-parse
        # negative: a stem with no blob fails closed → [] and still no source read.
        assert load_bridge_writers(job, "nonexistent_stem_xyz", "x", asm_dir=ASM, blueprint_dir=BP) == []
    finally:
        DA.set_load_only(False)
        set_cpp_indirect_writes_job(None)
        clear_caches()


# --------------------------------------------------------------------------- #
# §8.8 — flag OFF: no bridge artifacts surface (strictly additive when ON)
# --------------------------------------------------------------------------- #
def _bridge_markers(out):
    n = 0
    for s in (out.get("rootVariable", {}).get("setters") or []):
        if s.get("dataSource") or "«" in str(s.get("value", "")):
            n += 1
    return n


def test_flag_off_no_bridge_then_on_adds():
    from vbt.engine import trace_root_variable, Hop
    chain = [Hop("dw780000", "cpp", "getAllCidRecords")]
    common = dict(blueprint_dir=BP, asm_dir=ASM, graph_file=GF, bypass_trace_cache=True)
    off = trace_root_variable("allCidRecordWorkArea", "cpp", chain, emit_indirect_writes=False, **common)
    on = trace_root_variable("allCidRecordWorkArea", "cpp", chain, emit_indirect_writes=True, **common)
    assert _bridge_markers(off) == 0, "flag OFF must surface no bridge setters"
    on_setters = on.get("rootVariable", {}).get("setters") or []
    ds = [s for s in on_setters if s.get("dataSource")]
    assert {s["value"] for s in ds} == {"«SL70»", "«retrieveCrcnCidData»"}
    # additive: every OFF setter (by location/value) is still present when ON.
    off_keys = {(s["location"]["startLine"], s["value"]) for s in (off["rootVariable"]["setters"] or [])}
    on_keys = {(s["location"]["startLine"], s["value"]) for s in on_setters}
    assert off_keys <= on_keys


def test_dep_path_bridge_surfaces_on_ancestor():
    # End-to-end DEP path: counterForNumberOfCidRecord reads allCidRecordWorkArea.numberOfCidRecords;
    # P0 ancestor expansion creates the `allCidRecordWorkArea` buffer node, and the P1 merge attaches
    # its cross-language data source (the reported gap, reproduced through recurse not just root).
    from vbt.engine import trace_root_variable, Hop
    o = trace_root_variable("counterForNumberOfCidRecord", "cpp",
                            [Hop("dw780000", "cpp", "getAllCidRecords")],
                            blueprint_dir=BP, asm_dir=ASM, graph_file=GF,
                            max_dep_var_depth=2, emit_indirect_writes=True, bypass_trace_cache=True)
    buf = None
    for e in o.get("dependentVariables", []):
        dv = e.get("dependentVariable", e)
        if dv.get("name") == "allCidRecordWorkArea":
            buf = dv
            break
    assert buf is not None, "P0 must surface the allCidRecordWorkArea buffer node"
    ds = {s["dataSource"]["asm_module"] or s["dataSource"]["callee"]
          for s in (buf.get("setters") or []) if s.get("dataSource")}
    assert ds == {"SL70", "retrieveCrcnCidData"}, "buffer node carries its cross-language data source"


# --------------------------------------------------------------------------- #
# §8.9 — CFG reuse: guard collection does not run a second (live) cfg_extract
# --------------------------------------------------------------------------- #
def test_cfg_reused_no_second_extract(monkeypatch, bindings):
    # Warm the in-process cfg memo for dw780000, then forbid the live clang subprocess.
    run_cfg_extract(str(ASM / "dw780000.cpp"))
    monkeypatch.setattr("vbt.cpp_frontend.wrapper.subprocess.run",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("live cfg_extract ran")))
    res = _writers("dw780000", bindings)        # guard collection must reuse the warm cfg
    assert res["allCidRecordWorkArea"], "bridge writers + guards built from the reused CFG"
    assert _vpay({s.line: s for s in res["allCidRecordWorkArea"]}[207])


# --------------------------------------------------------------------------- #
# small-unit coverage of the parsing primitives
# --------------------------------------------------------------------------- #
def test_addr_and_arg_base_helpers():
    assert _addr_of_base("(long)&workArea") == "workArea"
    assert _addr_of_base("&allCidRecordWorkArea.workArea[0]") == "allCidRecordWorkArea"
    assert _addr_of_base("getTmsTableEntry(x)") is None
    assert _arg_base("&regs") == "regs"
    assert _arg_base("(TPF_regs*)&r") == "r"
    assert _is_zero_fill("0") and _is_zero_fill("0x00") and not _is_zero_fill("0X5c")
