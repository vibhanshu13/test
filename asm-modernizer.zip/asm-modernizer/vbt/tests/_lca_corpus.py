"""Locate a precomputed job that has the LCA-trace chains-precompute artifacts.

Portable across machines: scans ``jobs/*/index.db`` for one whose manifest has BOTH
``chain_facts`` and ``asm_setters_full_coverage`` (i.e. ``python -m vbt.precompute.chain_facts_db``
has been run on it), and derives its (blueprint_dir, asm_dir) the same way the task does. Returns
``None`` when no such job exists, so the DB-backed tests skip instead of failing.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Tuple

REPO = Path(__file__).resolve().parents[2]


def find_chain_facts_job() -> Optional[Tuple[str, Path, Path]]:
    """(job_id, blueprint_dir, asm_dir) for a chain_facts-ready job, or None."""
    jobs_dir = REPO / "jobs"
    if not jobs_dir.is_dir():
        return None
    from vbt.precompute import db_artifacts as DA
    prev = DA.is_load_only()
    try:
        DA.set_load_only(True)
        from vbt.precompute.chain_facts_db import CHAIN_FACTS_VERSION, COVERAGE_VERSION

        def _ver(job_id: str, artifact: str) -> int:
            row = DA.read_manifest(job_id, artifact)
            return int(row.get("version", -1)) if row else -1

        for db in sorted(jobs_dir.glob("*/index.db")):
            job = db.parent.name
            try:
                # CURRENT-version artifacts only: a KB built by older extraction code
                # is not chain_facts-ready for the code under test — the parity /
                # completeness tests would report that staleness as an engine bug.
                # Prod self-heals through _ensure_chain_facts_artifacts (the same
                # version check triggers an on-demand rebuild); here we skip.
                if not (_ver(job, "chain_facts") == CHAIN_FACTS_VERSION
                        and _ver(job, "asm_setters_full_coverage") == COVERAGE_VERSION
                        and _ver(job, "cpp_setter_map_coverage") == COVERAGE_VERSION):
                    continue
            except Exception:
                continue
            bp, src = _derive_dirs(job)
            if bp is not None and src is not None and bp.is_dir() and src.is_dir():
                return job, bp, src
    finally:
        DA.set_load_only(prev)
    return None


def _source_root(sp: Path) -> Path:
    """The dir that actually holds the ``.cpp``/``.asm`` sources: ``sp`` itself, else the
    subdir (e.g. an ``asm 5`` folder) that does. The pipeline's ``source_path`` can point one
    level above the real sources, exactly as blueprints nest under ``output/`` — so mirror the
    blueprint-dir descent here. Returns ``sp`` unchanged when it already holds sources (or none
    is found), so non-nested corpora are unaffected."""
    def _has_src(d: Path) -> bool:
        return next(d.glob("*.cpp"), None) is not None or next(d.glob("*.asm"), None) is not None
    if not sp.is_dir() or _has_src(sp):
        return sp
    subs = [d for d in sorted(sp.iterdir()) if d.is_dir() and _has_src(d)]
    return subs[0] if subs else sp


def _derive_dirs(job: str):
    try:
        from api.config import settings
        from api.tasks._task_utils import find_blueprint_dir
        from api.storage.workspace import WorkspaceManager
        out = settings.JOBS_BASE_DIR / job / "output"
        bp = find_blueprint_dir(out) or out
        sp = (WorkspaceManager(job).get_pipeline_options() or {}).get("source_path")
        return Path(bp), (_source_root(Path(sp)) if sp else None)
    except Exception:
        return None, None
