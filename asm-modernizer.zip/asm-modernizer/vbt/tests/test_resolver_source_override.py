"""Fix 2 (2026-06-24 plan): resolver content reads route through the source override.

These lock in the two guarantees the parity gate CANNOT (it runs with job_id=None, so no
override is installed and only the disk-fallback path is exercised):

  1. ``read_source_text`` is byte-identical to ``open(path, errors='replace').read()`` on BOTH
     the disk-fallback path and the override-hit path, including newline edge cases
     (\\r\\n, lone \\r, no trailing newline).
  2. With a source override installed (the warm-trace scenario), the resolver layer
     (_find_cpp_chain / name_resolver / membership) performs ZERO disk ``open()`` of any
     .hpp/.mac file — the bytes come from the override. This is the direct proof Fix 2
     eliminates the [DISK_READ] storm even on a cold resolver build.

  3. The resolver OUTPUT is identical whether the bytes come from disk or the override.

Also exercises Fix 1a: ``_dsect_names`` reads each .mac at most once (process memo).

    env/bin/python -m pytest vbt/tests/test_resolver_source_override.py -q
"""
from __future__ import annotations

import builtins
import os
from pathlib import Path

import pytest

ASM = Path("temp/asm")

pytestmark = pytest.mark.skipif(not ASM.exists(), reason="temp/asm source corpus not present")

from vbt.resolve import _find_cpp_chain as ch          # noqa: E402
from vbt.resolve import name_resolver as NR            # noqa: E402
from vbt.resolve import membership as MB               # noqa: E402
from backward_traversal.utils import blueprint_utils as BU   # noqa: E402


@pytest.fixture(autouse=True)
def _clean():
    BU.clear_source_override()
    NR.clear_cache()
    MB._CACHE.clear()
    yield
    BU.clear_source_override()
    NR.clear_cache()
    MB._CACHE.clear()


def _disk_read(p) -> str:
    with open(p, errors="replace") as fh:
        return fh.read()


def _install_override_for(byte_map: dict):
    """Install an override serving raw bytes keyed by basename (mirrors source_db)."""
    def _ov(path_str: str):
        return byte_map.get(os.path.basename(path_str))
    BU.set_source_override(_ov)


# --------------------------------------------------------------------------- #
# 1. read_source_text byte-identity — disk fallback (no override)
# --------------------------------------------------------------------------- #
def test_read_source_text_disk_matches_open():
    files = sorted(ASM.glob("*.mac")) + sorted(ASM.glob("*.hpp"))
    assert files, "expected .mac/.hpp under temp/asm"
    for p in files:
        assert ch.read_source_text(str(p)) == _disk_read(p), p


# --------------------------------------------------------------------------- #
# 2. read_source_text byte-identity — override hit equals disk, incl. newlines
# --------------------------------------------------------------------------- #
def test_read_source_text_override_matches_disk_real_files():
    files = sorted(ASM.glob("*.mac")) + sorted(ASM.glob("*.hpp"))
    byte_map = {p.name: p.read_bytes() for p in files}
    _install_override_for(byte_map)
    for p in files:
        # The override serves the bytes; result must equal the universal-newline disk read.
        assert ch.read_source_text(str(p)) == _disk_read(p), p


@pytest.mark.parametrize("raw,expected", [
    (b"a\r\nb\r\nc",      "a\nb\nc"),        # CRLF -> LF
    (b"a\rb\rc",          "a\nb\nc"),        # lone CR -> LF
    (b"a\nb\nc",          "a\nb\nc"),        # already LF
    (b"a\nb\n",           "a\nb\n"),         # trailing newline preserved
    (b"no_trailing_nl",   "no_trailing_nl"), # no trailing newline preserved
    (b"mix\r\nlone\rlf\nend", "mix\nlone\nlf\nend"),
])
def test_read_source_text_newline_translation(tmp_path, raw, expected):
    # Write raw bytes to disk; both the disk-fallback and override paths must reproduce the
    # universal-newline-translated text (matching open(errors='replace').read()).
    f = tmp_path / "x.mac"
    f.write_bytes(raw)
    # disk fallback
    assert ch.read_source_text(str(f)) == expected
    assert ch.read_source_text(str(f)) == _disk_read(f)
    # override hit (bytes from "db")
    _install_override_for({"x.mac": raw})
    assert ch.read_source_text(str(f)) == expected


# --------------------------------------------------------------------------- #
# 3. resolver OUTPUT identical: disk vs override
# --------------------------------------------------------------------------- #
@pytest.mark.skipif(not (ASM / "lwrpo.mac").exists(), reason="lwrpo triple absent")
def test_build_alias_map_identical_disk_vs_override():
    import json
    mac, gen, cc = str(ASM / "lwrpo.mac"), str(ASM / "lwrpo.hpp"), str(ASM / "cclwrpo.hpp")
    disk = ch.build_alias_map(mac, gen, cc)

    files = sorted(ASM.glob("*.mac")) + sorted(ASM.glob("*.hpp"))
    _install_override_for({p.name: p.read_bytes() for p in files})
    via_ov = ch.build_alias_map(mac, gen, cc)
    assert json.dumps(disk, sort_keys=True) == json.dumps(via_ov, sort_keys=True)


@pytest.mark.skipif(not (ASM / "lwrpo.mac").exists(), reason="lwrpo triple absent")
def test_resolve_identical_disk_vs_override():
    NR.clear_cache()
    disk = {(a.name, a.language, a.home_stem, a.certainty)
            for a in NR.resolve("softCardValue", "cpp", ASM).aliases}
    NR.clear_cache()
    files = sorted(ASM.glob("*.mac")) + sorted(ASM.glob("*.hpp"))
    _install_override_for({p.name: p.read_bytes() for p in files})
    ov = {(a.name, a.language, a.home_stem, a.certainty)
          for a in NR.resolve("softCardValue", "cpp", ASM).aliases}
    assert disk == ov and disk, disk


# --------------------------------------------------------------------------- #
# 4. THE SYMPTOM: zero .hpp/.mac disk open() when the override is installed
# --------------------------------------------------------------------------- #
class _OpenCounter:
    """Mirror the commit-74f7771 interceptor: count content opens of .hpp/.mac."""
    def __init__(self):
        self.real = builtins.open
        self.hits = []

    def __enter__(self):
        def _patched(file, *a, **kw):
            try:
                s = os.fspath(file)
                if isinstance(s, str) and (s.endswith(".hpp") or s.endswith(".mac")):
                    # 'r'/'rb' (default) = a content read — what the interceptor logs
                    mode = (a[0] if a else kw.get("mode", "r"))
                    if "w" not in mode and "a" not in mode and "x" not in mode:
                        self.hits.append(s)
            except Exception:
                pass
            return self.real(file, *a, **kw)
        builtins.open = _patched
        return self

    def __exit__(self, *exc):
        builtins.open = self.real


@pytest.mark.skipif(not (ASM / "lwrpo.mac").exists(), reason="lwrpo triple absent")
def test_no_hpp_mac_disk_open_when_override_installed():
    files = sorted(ASM.glob("*.mac")) + sorted(ASM.glob("*.hpp"))
    byte_map = {p.name: p.read_bytes() for p in files}

    # Baseline: WITHOUT override, a cold build DOES open .hpp/.mac (the storm).
    NR.clear_cache(); MB._CACHE.clear()
    with _OpenCounter() as c_off:
        ch.build_alias_map(str(ASM / "lwrpo.mac"), str(ASM / "lwrpo.hpp"),
                           str(ASM / "cclwrpo.hpp"))
    assert c_off.hits, "expected disk .hpp/.mac opens with NO override (sanity)"

    # With the override installed: ZERO disk .hpp/.mac opens — bytes come from the override.
    NR.clear_cache(); MB._CACHE.clear()
    _install_override_for(byte_map)
    with _OpenCounter() as c_on:
        ch.build_alias_map(str(ASM / "lwrpo.mac"), str(ASM / "lwrpo.hpp"),
                           str(ASM / "cclwrpo.hpp"))
    assert c_on.hits == [], f"override installed but still opened: {c_on.hits}"


def test_full_resolver_layer_no_disk_open_with_override():
    """name_resolver._units + resolve + membership build: zero .hpp/.mac disk opens
    once the override is installed (the warm-trace guarantee)."""
    files = sorted(ASM.glob("*.mac")) + sorted(ASM.glob("*.hpp"))
    _install_override_for({p.name: p.read_bytes() for p in files})
    NR.clear_cache(); MB._CACHE.clear()
    with _OpenCounter() as c:
        # exercise discovery (_mac_for_cc_stem -> _dsect_names), alias maps, and membership
        NR.resolve("softCardValue", "cpp", ASM)
        for u in NR._units(ASM):
            NR._alias_map(u)
        MB.MembershipResolver(ASM, ASM)._build()
    assert c.hits == [], f"resolver layer opened .hpp/.mac on disk despite override: {c.hits[:10]}"


# --------------------------------------------------------------------------- #
# 5. Fix 1a: _dsect_names reads each .mac at most once (process memo)
# --------------------------------------------------------------------------- #
@pytest.mark.skipif(not list(ASM.glob("*.mac")), reason="no .mac files")
def test_dsect_names_memoized():
    NR.clear_cache()
    mac = sorted(ASM.glob("*.mac"))[0]
    with _OpenCounter() as c:
        first = NR._dsect_names(mac)
        opens_after_first = len(c.hits)
        second = NR._dsect_names(mac)
        opens_after_second = len(c.hits)
    assert first == second
    assert opens_after_second == opens_after_first, "second _dsect_names should not re-read"
