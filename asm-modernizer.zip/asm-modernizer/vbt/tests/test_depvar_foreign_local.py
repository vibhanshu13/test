"""v15: foreign proven-local setter exclusion + language-scoped bare identity.

Two mechanisms under test, both bound by the zero-false-negative doctrine (only a
POSITIVE proof may drop a setter site; identity changes may only SPLIT, never drop):

  * Cut A — a bare-LHS C++ write at a line where a non-reference function-scope
    declaration of the name is in scope provably writes THAT function's automatic,
    never the dep's variable (recurse._gather_candidate_setters via
    cpp_setters.find_cpp_local_decls / proves_local). The adversarial-validation
    counterexamples (CE-1 closed shadow block, CE-2 trailing file-scope decl,
    CE-3 reference alias, reference parameters) must all be KEPT.

  * Cut C — an UNBRIDGED bare name is language-scoped in ``_dep_key``
    (``@lang:<lang>``): the old language-blind merge routed the second language's
    discovery through the rescope path, whose setter search never ran — a silent
    false negative this split recovers.

Real tree-sitter on disk fixtures; CFG maps synthetic (node-cache test convention).
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[2]))

from vbt.setters.cpp_setters import find_cpp_local_decls, proves_local  # noqa: E402
from vbt.depvars.extract import DepVarRef  # noqa: E402
from vbt.depvars.recurse import (  # noqa: E402
    _NodeCtx, _candidate_files_by_target, _dep_key, _gather_candidate_setters,
)


# One "member-ish" name written three ways across two files:
#   f1.cpp: a foreign function's PROVEN local (decl + assign)      → excluded
#   f1.cpp: a member-chained write obj.returnCode                  → kept
#   f2.cpp: CE shapes — every one must be KEPT
_F1 = """void other() {
    int returnCode = 0;
    returnCode = 5;
}

void writer(Obj& obj) {
    obj.returnCode = 9;
}
"""

_F2 = """int returnCode;

void ce1() {
    if (c) { int returnCode = k(); }
    returnCode = 11;
}

void ce3(Obj& obj) {
    int& rc = obj.returnCode;
    returnCode = 22;
}
"""


def _cfg(*fns):
    return [{"function": name,
             "cfg_blocks": [{"id": i, "stmts": [{"line": ln} for ln in lines],
                             "succs": []}]}
            for i, (name, lines) in enumerate(fns)]


class _Idx:
    def files_for(self, name, language):
        return {"f1", "f2"}


def _ctx(tmp_path, cfg_by_stem):
    ctx = _NodeCtx(
        blueprint_dir=tmp_path, asm_dir=tmp_path, chain_set={"f1", "f2"},
        upstream_bounds={}, route_engine=None, chain_hops=None, max_depth=2,
        const_resolver=None, max_offchain_files=100, asm_max_levels=16,
        max_descendants=50, midx=_Idx(), memb=None, reach_union=None,
    )
    ctx.cfg_cache.update(cfg_by_stem)
    return ctx


def _write(tmp_path):
    (tmp_path / "f1.cpp").write_text(_F1)
    (tmp_path / "f2.cpp").write_text(_F2)


_CFGS = {"f1": _cfg(("other", [2, 3]), ("writer", [7])),
         "f2": _cfg(("ce1", [4, 5]), ("ce3", [9, 10]))}


def _dep(**kw):
    d = dict(name="returnCode", language="cpp", relationship="condition",
             found_at={"file": "reader.cpp", "startLine": 10, "endLine": 10})
    d.update(kw)
    return DepVarRef(**d)


def _lines(tmp_path, dep):
    ctx = _ctx(tmp_path, _CFGS)
    cbt = _candidate_files_by_target(dep, [], ctx)
    return sorted((s.file_stem, s.line)
                  for s in _gather_candidate_setters(dep, ctx, cbt))


# --------------------------------------------------------------------------- #
# Cut A — exclusion fires ONLY on the proven foreign local
# --------------------------------------------------------------------------- #
def test_foreign_proven_local_writes_are_excluded_everything_else_kept(tmp_path):
    _write(tmp_path)
    got = _lines(tmp_path, _dep())
    # f1: other()'s decl@2 + assign@3 are PROVEN locals → dropped; member write @7 kept.
    # f2: the uninit file-scope decl@1 is not a setter site (no initializer) so it is
    #     not in the candidate list to begin with;
    #     ce1's write@5 kept (CE-1: the shadow block at line 4 CLOSED before it);
    #     ce3's write@10 kept (CE-3: `rc` is a reference decl — and it's a different
    #     name anyway; the bare returnCode there has NO in-scope non-ref decl).
    assert got == [("f1", 7), ("f2", 5), ("f2", 10)], got


def test_uninitialized_declaration_is_a_proof_for_both_gates(tmp_path):
    (tmp_path / "f3.cpp").write_text(
        "void u() {\n    bool returnCode;\n    returnCode = f();\n}\n")
    # site-side (Cut A): the bare write @3 is proven local by the UNINIT decl @2
    recs = find_cpp_local_decls("returnCode", tmp_path / "f3.cpp")
    assert proves_local(recs, 3)
    assert not proves_local(recs, 1)          # before the declaration line
    # read-side (v13 gate upgrade): a read at line 3 gets scoped
    import vbt.depvars.recurse as R
    ctx = _ctx(tmp_path, {"f3": _cfg(("u", [2, 3]))})
    dep = _dep(found_at={"file": "f3.cpp", "startLine": 3, "endLine": 3})
    assert R._cpp_local_scope(dep, ctx) == "u"


def test_reference_parameter_writes_are_kept(tmp_path):
    # `void g(int& returnCode)` writes the CALLER's variable — parameters are never
    # a proof, so the bare write inside g survives for a foreign dep.
    (tmp_path / "f4.cpp").write_text(
        "void g(int& returnCode) {\n    returnCode = 7;\n}\n")
    assert find_cpp_local_decls("returnCode", tmp_path / "f4.cpp") == []
    ctx = _ctx(tmp_path, {"f4": _cfg(("g", [2]))})
    ctx.chain_set = {"f4"}
    dep = _dep()
    setters = _gather_candidate_setters(dep, ctx, [("returnCode", "cpp", None, ["f4"])])
    assert [(s.file_stem, s.line) for s in setters] == [("f4", 2)]


def test_own_scope_sites_survive_via_span_carveout_without_cfg(tmp_path):
    # The dep IS a local whose read gate could not run (no CFG): the span carve-out
    # keeps its own scope's sites — a missing CFG can never orphan the dep.
    (tmp_path / "f5.cpp").write_text(
        "void mine() {\n    int v = 1;\n    v = 2;\n    use(v);\n}\n"
        "void theirs() {\n    int v = 8;\n}\n")
    ctx = _ctx(tmp_path, {})            # NO cfg anywhere
    ctx.chain_set = {"f5"}
    dep = DepVarRef(name="v", language="cpp", relationship="condition",
                    found_at={"file": "f5.cpp", "startLine": 4, "endLine": 4})
    setters = _gather_candidate_setters(dep, ctx, [("v", "cpp", None, ["f5"])])
    assert sorted(s.line for s in setters) == [2, 3], \
        "own-scope sites dropped / foreign kept"   # theirs()'s decl@7 excluded


# --------------------------------------------------------------------------- #
# Cut C — language-scoped identity for unbridged bare names
# --------------------------------------------------------------------------- #
def _seed(name, language, file, line=6, **kw):
    return DepVarRef(name=name, language=language, relationship="condition",
                     found_at={"file": file, "startLine": line, "endLine": line}, **kw)


def test_dep_key_language_scopes_unbridged_and_merges_bridged():
    cpp = _seed("LL9RTN", "cpp", "a.cpp")
    asm = _seed("LL9RTN", "asm", "b.asm")
    assert _dep_key(cpp) == ("LL9RTN", "@lang:cpp")
    assert _dep_key(asm) == ("LL9RTN", "@lang:asm")
    assert _dep_key(cpp) != _dep_key(asm)
    cpp.bridged = asm.bridged = True
    assert _dep_key(cpp) == _dep_key(asm) == ("LL9RTN", "")


def _trace_two_langs(monkeypatch, tmp_path, *, bridged):
    """One cpp + one asm seed of the same bare name; count nodes and whether the
    SECOND language's setters were actually searched (the pre-fix bug: they were
    not — the merged node only re-filtered the first node's candidates)."""
    import vbt.depvars.recurse as R
    from vbt.depvars.recurse import trace_dependents

    (tmp_path / "d.cpp").write_text("void g() {\n    LL9RTN = 1;\n    use(LL9RTN);\n}\n")

    class _TIdx:
        def files_for(self, name, language):
            return {"d"} if language == "cpp" else set()
        def files_defining_function(self, fn): return set()
        def sites_for(self, *a, **k): return []

    class _Alias:
        def __init__(self, aliases): self.aliases = aliases

    aliases = ([type("A", (), {"name": "LL9RTN", "language": "cpp",
                               "certainty": "high", "via": "test"})()]
               if bridged else [])
    monkeypatch.setattr(R, "get_modifier_index", lambda *a, **k: _TIdx())
    monkeypatch.setattr(R, "resolve_aliases", lambda n, l, d: _Alias(list(aliases)))
    monkeypatch.setattr(R, "run_cfg_extract", lambda *a, **k: [])
    monkeypatch.setattr(R, "find_asm_setters_in_file", lambda *a, **k: [])
    monkeypatch.setattr(R, "_cpp_fn_block", lambda *a, **k: None)
    monkeypatch.setattr(R, "_dep_chunk", lambda *a, **k: None)

    seeds = [("root", _seed("LL9RTN", "asm", "y.asm", 5)),        # asm discovered FIRST
             ("root", _seed("LL9RTN", "cpp", "d.cpp", 3))]
    out = trace_dependents(seeds, ["d"], blueprint_dir=tmp_path, asm_dir=tmp_path,
                           store=None)
    return [e["dependentVariable"] for e in out
            if e["dependentVariable"]["name"] == "LL9RTN"]


def test_unbridged_same_name_splits_and_recovers_second_languages_setters(
        monkeypatch, tmp_path):
    dvs = _trace_two_langs(monkeypatch, tmp_path, bridged=False)
    assert len(dvs) == 2, "unbridged asm+cpp same-name deps must NOT merge"
    by_key = {dv["depKey"]: dv for dv in dvs}
    assert set(by_key) == {"LL9RTN|@lang:asm", "LL9RTN|@lang:cpp"}
    # THE RECOVERED FALSE NEGATIVE: the cpp node ran its own setter search — the
    # cpp write d.cpp:2 is present (pre-fix, the asm-first merge left it unsearched).
    cpp_lines = {s["location"]["startLine"] for s in by_key["LL9RTN|@lang:cpp"]["setters"]
                 if not s.get("notSet")}
    assert 2 in cpp_lines, f"second language's setter search did not run: {cpp_lines}"


def test_bridged_same_name_keeps_single_merged_node(monkeypatch, tmp_path):
    dvs = _trace_two_langs(monkeypatch, tmp_path, bridged=True)
    assert len(dvs) == 1, "a bridged pair must keep merging into ONE node"
    assert dvs[0]["depKey"] == "LL9RTN"
