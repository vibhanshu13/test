"""GAP 1: precomputed ``value_guards`` replay + feasibility behavior (corpus-free).

These tests exercise the trace-time decision path with SYNTHETIC ``chain_facts`` dicts
(no job/index.db/corpus), proving:
  * a chain_facts v4 blob carrying decomposed ``value_guards`` for the CID gate makes the
    contradictory transactionCode chains PROVABLY infeasible (the GAP-1 bug), while an
    allowed transaction code stays feasible;
  * the trace replay reads ``value_guards`` DIRECTLY — it never reparses guard text
    (monkeypatch ``parse_required_guard`` to raise and replay still works);
  * a legacy (pre-v4) blob with no ``value_guards`` still works via the text-parse fallback;
  * the underlying ``decide_feasibility`` verdicts for the §2 behavior matrix.
"""
from __future__ import annotations

import pytest

from vbt.lca_feasibility import _Event, decide_feasibility
from vbt.precompute.chain_facts_db import (
    _edge_key, assemble_events_from_chain_facts, chain_facts_verdict,
)

# normalized scrutinees (whitespace already collapsed, as the decomposer emits)
TC = "lwrCommon.process.links.transactionCode"
RC = "lwrCommon.process.cid.cidioReturnCode"
CID_ALLOWED = [
    "CasTransactionCode::CreditRequest",
    "CasTransactionCode::WorkedFromReferralQue",
    "CasTransactionCode::ForceEntryToRefer",
    "CasTransactionCode::ForceEntryToAA",
    "CasTransactionCode::PostAuthorization",
]

# chain: callPlastic switch (hop 0) -> selectCidDbRecord15 -> updateCidTransactionIndicators
N0 = "dw710000::callPlasticAuthenticationComponentInterface"
N1 = "dw780000::selectCidDbRecord15"
N2 = "dw780100::updateCidTransactionIndicators"
CHAIN = [N0, N1, N2]
EDGE0 = _edge_key("dw710000", "callPlasticAuthenticationComponentInterface",
                  "dw780000", "selectCidDbRecord15")
EDGE1 = _edge_key("dw780000", "selectCidDbRecord15",
                  "dw780100", "updateCidTransactionIndicators")


def _vg(scrut, const, op):
    return {"scrutinee": scrut, "const": const, "op": op, "line": 702, "lang": "cpp",
            "source_text": f"{scrut} {'==' if op == 'eq' else '!='} {const}"}


def _facts_v4(switch_const):
    """A v4 chain_facts dict: hop-0 switch pins transactionCode == switch_const; the CID gate
    on the hop-1 edge requires transactionCode in the allowed set (+ cidioReturnCode != NoCid)."""
    cid_value_guards = [_vg(RC, "CidioReturn::NoCidRecord", "ne")] + \
                       [_vg(TC, c, "eq") for c in CID_ALLOWED]
    return {
        "edges": {
            EDGE0: {"guards": [{"text": f"{TC} == {switch_const}", "line": 100, "lang": "cpp"}],
                    "value_guards": [_vg(TC, switch_const, "eq")],
                    "descend_line": 110},
            EDGE1: {"guards": [{"text": "(CID gate compound)", "line": 702, "lang": "cpp"}],
                    "value_guards": cid_value_guards,
                    "descend_line": 709},
        },
        "scrutinees": {TC: "cpp", RC: "cpp"},
        "nodes": {},
    }


# --------------------------------------------------------------------------- #
# end-to-end: assemble value_guards -> decide_feasibility (the GAP-1 bug)
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("case", ["CasTransactionCode::Reversal",
                                  "CasTransactionCode::AddNegative",
                                  "CasTransactionCode::AuthorizerStatusCode"])
def test_contradictory_transaction_codes_are_infeasible(case):
    facts = _facts_v4(case)
    v = chain_facts_verdict(CHAIN, facts)
    assert v.status == "infeasible", v.reason
    assert v.conflict and v.conflict["scrutinee"] == TC


def test_allowed_transaction_code_stays_feasible():
    facts = _facts_v4("CasTransactionCode::CreditRequest")
    v = chain_facts_verdict(CHAIN, facts)
    assert v.status == "feasible", v.reason


def test_assemble_emits_one_event_per_value_guard():
    facts = _facts_v4("CasTransactionCode::Reversal")
    events, status = assemble_events_from_chain_facts(CHAIN, facts)
    assert status == "ok"
    # hop 0: the switch eq; hop 1: 1 ne + 5 eq = 6
    hop0 = [e for e in events if e.hop == 0 and e.kind == "guard"]
    hop1 = [e for e in events if e.hop == 1 and e.kind == "guard"]
    assert len(hop0) == 1 and hop0[0].scrutinee == TC and hop0[0].op == "eq"
    assert len(hop1) == 6
    assert sum(1 for e in hop1 if e.op == "ne") == 1
    assert sum(1 for e in hop1 if e.op == "eq" and e.scrutinee == TC) == 5


# --------------------------------------------------------------------------- #
# DB-only / no-reparse: replay must NOT call parse_required_guard for v4 blobs
# --------------------------------------------------------------------------- #
def test_replay_does_not_reparse_guard_text(monkeypatch):
    def _boom(*a, **k):
        raise AssertionError("parse_required_guard must NOT be called when value_guards exist")
    monkeypatch.setattr("vbt.precompute.chain_facts_db.parse_required_guard", _boom)
    facts = _facts_v4("CasTransactionCode::Reversal")
    v = chain_facts_verdict(CHAIN, facts)          # would raise if replay reparsed text
    assert v.status == "infeasible"


# --------------------------------------------------------------------------- #
# legacy (pre-v4) fallback: no value_guards key -> parse the stored guard text
# --------------------------------------------------------------------------- #
def test_legacy_blob_without_value_guards_uses_text_parse():
    # No "value_guards" key on either edge -> assemble must parse guards[].text. The two
    # SIMPLE same-scrutinee guards conflict, so the legacy path still prunes them.
    facts = {
        "edges": {
            EDGE0: {"guards": [{"text": f"{TC} == CasTransactionCode::Reversal",
                                "line": 100, "lang": "cpp"}], "descend_line": 110},
            EDGE1: {"guards": [{"text": f"{TC} == CasTransactionCode::CreditRequest",
                                "line": 702, "lang": "cpp"}], "descend_line": 709},
        },
        "scrutinees": {TC: "cpp"},
        "nodes": {},
    }
    events, status = assemble_events_from_chain_facts(CHAIN, facts)
    assert status == "ok" and events
    assert decide_feasibility(events).status == "infeasible"


# --------------------------------------------------------------------------- #
# §2 feasibility behavior matrix (pure decide_feasibility)
# --------------------------------------------------------------------------- #
def _g(hop, scrut, const, op="eq"):
    return _Event(hop=hop, line=1, kind="guard", scrutinee=scrut, const=const, op=op)


def test_decide_reversal_vs_cid_infeasible():
    events = [_g(0, TC, "CasTransactionCode::Reversal")] + [_g(1, TC, c) for c in CID_ALLOWED]
    assert decide_feasibility(events).status == "infeasible"


def test_decide_creditrequest_vs_cid_feasible():
    events = [_g(0, TC, "CasTransactionCode::CreditRequest")] + [_g(1, TC, c) for c in CID_ALLOWED]
    assert decide_feasibility(events).status == "feasible"


def test_decide_unknown_prior_plus_cid_feasible():
    # no prior constraint on TC -> the CID gate just narrows it -> feasible
    events = [_g(1, TC, c) for c in CID_ALLOWED]
    assert decide_feasibility(events).status == "feasible"


def test_decide_cidio_eq_then_ne_infeasible():
    events = [_g(0, RC, "CidioReturn::NoCidRecord", "eq"),
              _g(1, RC, "CidioReturn::NoCidRecord", "ne")]
    assert decide_feasibility(events).status == "infeasible"


def test_decide_cross_kind_constants_conservative():
    # enum prior vs integer required: NOT provably different (we can't know the enum's int) -> keep
    events = [_g(0, RC, "CidioReturn::CreditApproved"), _g(1, RC, "0")]
    assert decide_feasibility(events).status == "feasible"
