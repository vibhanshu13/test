"""Function-output return recovery (lexical) + identity + before-or-equal setter scope.

- `_lexical_returns` recovers `return <expr>;` over a function's TRUE span even when the
  cfg_extract CFG truncates the body (the Pa::ReturnCode-classifier class came back with
  0 returns → wrongly terminal). Comment lines are skipped.
- function-output identity is keyed on the DEFINING file, so same-named functions in
  different files don't merge; `definedIn` is exposed.
- `_filter_chain_scoped` keeps a discovery-file setter at the SAME line as the read
  (set-and-use) after the `<` → `<=` change.
"""
import os
import pytest

from pathlib import Path

from vbt.depvars.extract import DepVarRef
from vbt.depvars.recurse import _dep_key, _filter_chain_scoped
from vbt.cpp_frontend.wrapper import DEFAULT_BINARY

_HAVE_CLANG = os.path.isfile(DEFAULT_BINARY)


# --------------------------------------------------------------------------- #
# identity + scope — no Clang needed
# --------------------------------------------------------------------------- #
def test_funcoutput_identity_keyed_on_def_file():
    mk = lambda dfile: DepVarRef(name="editSecurityCode", language="cpp",
                                 relationship="function_output", is_function_output=True,
                                 found_at={}, def_file=dfile)
    assert _dep_key(mk("dw710700")) != _dep_key(mk("other"))   # distinct defs → distinct nodes
    assert _dep_key(mk("dw710700")) == _dep_key(mk("dw710700"))  # same def → merge
    # a member-path dep is unaffected (qualified keying, never @fn:)
    m = DepVarRef(name="month", language="cpp", relationship="condition",
                  found_at={}, qualified="lwrIso.expirationDate.month")
    assert _dep_key(m) == ("MONTH", "lwrIso.expirationDate.month")


def test_filter_chain_scoped_keeps_same_line_set_and_use():
    # setter at the SAME line as the read (e.g. `if ((x = f()) == Bad)`) — kept after `<=`.
    s = type("S", (), {"file_stem": "f", "language": "cpp", "line": 40,
                       "function": "g", "block_id": "g"})()
    dep = DepVarRef(name="x", language="cpp", relationship="condition",
                    found_at={"file": "f.cpp", "startLine": 40, "endLine": 40})
    kept = _filter_chain_scoped([s], dep, {"f"}, {})   # cfg_cache=None → textual <= branch
    assert s in kept


# --------------------------------------------------------------------------- #
# return recovery — tree-sitter (no Clang, no regex): robust to inline / comments
# --------------------------------------------------------------------------- #
_FIXTURE = """\
int classify(int flag)
{
    if (flag) return A;              // INLINE return — a line-regex would miss this
    // return SKIPPED_LINE_COMMENT;
    /* return SKIPPED_BLOCK; */
    if (flag)
    {
        return B;                    // standalone return
    }
    return C;
}

int helper(int y)
{
    return D;                        // belongs to helper, NOT classify
}
"""


def test_returns_recovered_robustly(tmp_path):
    # tree-sitter (no cfg_extract binary needed): finds inline + standalone returns,
    # attributes them to the right enclosing function, and never reads a comment as a return.
    from vbt.setters.cpp_setters import find_cpp_returns_in_function
    f = tmp_path / "c.cpp"
    f.write_text(_FIXTURE)
    exprs = {e for (_l, e) in find_cpp_returns_in_function(f, "classify")}
    assert exprs == {"A", "B", "C"}, exprs       # inline A + standalone B,C; comments ignored; D excluded
    assert {e for (_l, e) in find_cpp_returns_in_function(f, "helper")} == {"D"}


@pytest.mark.skipif(not _HAVE_CLANG or not Path("temp/asm/dw710700.cpp").exists(),
                    reason="real corpus / cfg_extract not available")
def test_editsecuritycode_now_productive():
    # the Pa::Good/Pa::Bad classifier whose CFG truncates: lexical recovery makes it
    # productive (was 0 returns → terminal).
    from vbt.precompute.modifier_index import get_modifier_index
    from vbt.depvars.recurse import _function_return_setters
    bp = Path("jobs/37203143-0fa3-46fe-820f-e3c7d1e18e24/output")
    if not bp.exists():
        pytest.skip("baseline blueprints not present")
    midx = get_modifier_index(bp, Path("temp/asm"))
    sj, _child, _byref = _function_return_setters(
        "editSecurityCode", midx, Path("temp/asm"), {}, call_site_stem="dw710500")
    vals = {s["value"] for s in sj}
    assert "Pa::Bad" in vals and "Pa::Good" in vals
    assert len(sj) >= 2
