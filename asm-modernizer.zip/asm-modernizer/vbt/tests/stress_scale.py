#!/usr/bin/env python3
"""Synthetic-scale stress harness for VBT route walks (reproduce the 22k / 10k+-ASM client).

The reference corpus has ~3k call-graph nodes; the client has ~22k files / 10k+ ASM. This scales
the REAL file_call_graph by replicating its ASM subgraph K times (renamed stems, same edge shape,
plus cross-links so the search space is genuinely larger) while keeping the real nodes + the real
softCardValue chain (aa71→dw730000→dw710000) intact. Then it times the exact prefix-guard call
``route.routes(aa71:asm, dw730000:cpp, max_routes=1)`` at each scale.

If route.routes time grows ~linearly with K, the ASM route walk is O(graph-size) — i.e. the
forward-reachable prune is NOT bounding it (the client bottleneck). If flat, the prune works and the
slowness is elsewhere.

    env/bin/python3 -m vbt.tests.stress_scale --scales 1 2 4 8
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

REF_BP = Path("jobs/1ffa983c-3282-42f2-9701-a4c3f21451b1/output/asm 5")
REF_SRC = Path("datasource/asm7_admin/asm 7_version_0/asm 5")
REF_GRAPH = REF_BP / "file_call_graph.json"


def inject_blob(base: dict, n: int, fanout: int = 6) -> dict:
    """Inject ``n`` synthetic ASM nodes into the CALLER FOREST of dw730000 — i.e. fake callers
    (``SYNi → dw730000``) plus a dense caller-of-caller web (``SYNi → SYNj``). ``walk_callers``
    searches BACKWARD from the child (dw730000), so an unbounded/unpruned walk will explore all
    ``n`` fake callers even though NONE of them are reachable from the real parent (aa71) and so
    none can be on a real aa71→dw730000 route. If ``route.routes(aa71, dw730000)`` time grows with
    ``n`` → ``walk_callers`` is unbounded and not pruned by the parent's forward cone (the
    bottleneck). The real answer is unchanged (the route is still the real aa71→dw730000 path)."""
    nodes = list(base.get("nodes", []))
    edges = list(base.get("edges", []))
    syn = [f"SYN{i:06d}" for i in range(n)]
    for s in syn:
        nodes.append({"id": s, "type": "asm", "file": f"{s}.asm"})
    for i, s in enumerate(syn):
        # every synthetic node calls dw730000 (a fake direct caller)…
        edges.append({"source": s, "target": "dw730000", "is_internal": False,
                      "instructions": ["ENTRC"], "call_sites": []})
        # …and calls `fanout` other synthetic nodes (so each is also a caller-of-callers → the
        # backward forest from dw730000 is deep + wide, n nodes total).
        for j in range(1, fanout + 1):
            edges.append({"source": s, "target": syn[(i + j) % n], "is_internal": False,
                          "instructions": ["ENTRC"], "call_sites": []})
    out = dict(base)
    out["nodes"] = nodes
    out["edges"] = edges
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="vbt.tests.stress_scale", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--inject", type=int, nargs="+", default=[0, 2000, 5000, 10000],
                    help="counts of synthetic dw730000-caller nodes to inject (the 10k-ASM stressor)")
    ap.add_argument("--max-routes", type=int, default=1)
    a = ap.parse_args(argv)

    from vbt.reach.route import RouteEngine, Endpoint
    base = json.loads(REF_GRAPH.read_text())
    print(f"base graph: {len(base['nodes'])} nodes, {len(base['edges'])} edges")
    print(f"{'inject':>7} {'nodes':>9} {'edges':>9} {'route.routes(aa71→dw730000) s':>32} {'reachable':>10}")
    for n in a.inject:
        g = inject_blob(base, n)
        gpath = Path(f"/tmp/vbt_stress_graph_n{n}.json")
        gpath.write_text(json.dumps(g))
        route = RouteEngine(REF_BP, gpath, REF_SRC)   # job_id=None → reads our scaled file
        t = time.monotonic()
        r = route.routes(Endpoint("aa71", "asm", None),
                         Endpoint("dw730000", "cpp", "DW73"), max_routes=a.max_routes)
        dt = time.monotonic() - t
        print(f"{n:>7} {len(g['nodes']):>9} {len(g['edges']):>9} {dt:>32.3f} {str(r.get('reachable')):>10}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
