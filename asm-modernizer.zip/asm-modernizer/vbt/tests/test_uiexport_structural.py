"""Tests for vbt.uiexport.structural — the deterministic (no-LLM) VBT->UI
structural transform. Runs against the real trace_softCardValue_d3 fixture.

Run from the asm-modernizer root:
    python -m pytest vbt/tests/test_uiexport_structural.py -q
"""
from __future__ import annotations

from pathlib import Path

import pytest

from vbt.uiexport import models
from vbt.uiexport import structural as S

REPO_ROOT = Path(__file__).resolve().parents[2]
TRACE_DIR = REPO_ROOT / "vbt" / "trace_softCardValue_d3"


@pytest.fixture(scope="module")
def trace():
    return S.load_trace(TRACE_DIR)


@pytest.fixture(scope="module")
def fnindex(trace):
    return S.build_function_index(trace.code_blocks)


# --------------------------------------------------------------------------- #
# FunctionIndex / normalisation primitives.
# --------------------------------------------------------------------------- #


def test_file_stem_and_kind():
    assert S.file_stem("dw710000.cpp") == "dw710000"
    assert S.file_stem("aa71.asm") == "aa71"
    assert S.file_stem(
        "datasource/asm_pipeline_user/asm_codebase_version_0/dw730000.cpp"
    ) == "dw730000"
    assert S.file_kind("aa71.asm") == "asm"
    assert S.file_kind("dw710000.cpp") == "cpp"
    assert S.file_kind(
        "datasource/asm_pipeline_user/asm_codebase_version_0/dw730000.cpp"
    ) == "cpp"


def test_function_index_lookup(fnindex):
    # processACreditTransaction spans 934-1057 in dw710000.
    assert fnindex.lookup("dw710000", 1002) == "processACreditTransaction"
    # selectCidDbRecord15 spans 261-812 in dw780000.
    assert fnindex.lookup("dw780000", 400) == "selectCidDbRecord15"
    # Smallest-enclosing: line 4572 is inside the nested override-check block.
    assert (
        fnindex.lookup("dw780000", 4572)
        == "perform4cscMatchInstantAccountOverrideCheck"
    )
    # ASM lines have no code blocks → None (expected; ASM steps keyed by file).
    assert fnindex.lookup("aa71", 2016) is None


# --------------------------------------------------------------------------- #
# Clubbing: 26 logical setters, 0 fnindex misses on root setters.
# --------------------------------------------------------------------------- #


def test_club_yields_26_setters_zero_misses(trace, fnindex):
    setters = trace.root_variable["setters"]
    assert len(setters) == 1009  # sanity: the raw tuple count

    misses = 0
    for s in setters:
        loc = s["location"]
        stem = S.file_stem(loc["file"])
        fn = fnindex.lookup(stem, loc["startLine"])
        if fn is None:
            misses += 1
    assert misses == 0, "every root setter site must resolve to a function/label"

    clubs = S._club_setters(setters, fnindex)
    assert len(clubs) == 26, f"expected 26 clubbed setters, got {len(clubs)}"

    # The clubbing partitions across exactly these functions (genuine trace data:
    # 1 @ dw710000::processACreditTransaction, the rest in dw780000 split between
    # selectCidDbRecord15 and the nested perform4cscMatchInstantAccountOverrideCheck).
    fns = {(stem, fn) for (stem, fn, _value) in clubs.keys()}
    assert ("dw710000", "processACreditTransaction") in fns
    assert ("dw780000", "selectCidDbRecord15") in fns


# --------------------------------------------------------------------------- #
# Root variable struct.
# --------------------------------------------------------------------------- #


@pytest.fixture(scope="module")
def root_struct(trace, fnindex):
    return S.build_variable_struct(
        "softCardValue", is_root=True, trace=trace, fnindex=fnindex
    )


def test_root_struct_validates(root_struct):
    # Validates against VariableTable (raises inside build_variable_struct
    # already, but assert explicitly here too).
    models.VariableTable.model_validate(root_struct)
    assert root_struct["variable"] == "softCardValue"
    assert root_struct["business_name"] == ""  # placeholder for prose
    assert len(root_struct["setters"]) == 26


def test_root_inquiry_path_stems(root_struct):
    stems = [f["file"] for f in root_struct["inquiry_path"]["files"]]
    assert stems == ["aa71", "dw730000", "dw710000"], stems
    # Placeholders left for prose.
    assert root_struct["inquiry_path"]["description"] == {"b": "", "t": ""}
    assert root_struct["inquiry_path"]["long_description"] == {"b": "", "t": ""}


def test_expresspay_setter_has_lstknpoa_guard(root_struct):
    # The dw710000 setter assigns SoftCardValueDetail::ExpressPayTransaction; it
    # must carry the lstknpoa branch guard (the :992 / :1005 wallet-token gates).
    targets = [
        s for s in root_struct["setters"]
        if s["assigned_value"]["t"] == "SoftCardValueDetail::ExpressPayTransaction"
    ]
    assert targets, "ExpressPayTransaction setter must exist"
    setter = targets[0]
    assert setter["assigned_value"]["b"] == ""  # business side blank (prose fills)

    # Gather every condition rule.t across the setter's paths. The lstknpoa guard is a
    # setter-SITE gate (it selects which value the assignment stores), so after
    # _merge_setter_sites it lives in fstep["sites"][].conditions — gather BOTH the
    # file-step reachability conditions and the setter-site conditions.
    def _collect(conds, out):
        for cond in conds or []:
            if cond.get("rule"):
                out.append(cond["rule"]["t"])
            for leaf in cond.get("any", []) or []:
                if leaf.get("rule"):
                    out.append(leaf["rule"]["t"])

    rule_texts = []
    for path in setter["paths"]:
        for fstep in path["files"]:
            _collect(fstep.get("conditions"), rule_texts)
            for site in fstep.get("sites", []) or []:
                _collect(site.get("conditions"), rule_texts)
    assert any("lstknpoa" in t for t in rule_texts), (
        "ExpressPayTransaction setter must include the lstknpoa guard; "
        f"got rule texts: {rule_texts}"
    )

    # The setter site is the last file step, sets=True, points at dw710000.
    last_setter_steps = [
        fstep
        for path in setter["paths"]
        for fstep in path["files"]
        if fstep.get("sets")
    ]
    assert last_setter_steps
    for fstep in last_setter_steps:
        assert fstep["file"] == "dw710000"
        assert fstep["function"] == "processACreditTransaction"
        assert fstep["assigned_value"]["t"] == "SoftCardValueDetail::ExpressPayTransaction"
        assert "softCardValue" in fstep["setter_source"]["code"]


def test_setter_paths_capped(root_struct):
    for setter in root_struct["setters"]:
        assert len(setter["paths"]) <= 6, (
            f"setter {setter['id']} exceeded max_paths"
        )


# --------------------------------------------------------------------------- #
# Clickable dep vars.
# --------------------------------------------------------------------------- #


def test_collect_clickable_depvars(root_struct, trace):
    clickable = S.collect_clickable_depvars(root_struct)
    assert clickable, "root must surface clickable dependent variables"
    # ids must be raw names (no business labels) and preserve order/dedup.
    assert len(clickable) == len(set(clickable))

    # At least some clickable ids must key a real dependentVariables/<name>.json.
    have_file = [n for n in clickable if trace.has_depvar(n)]
    assert have_file, "no clickable dep var keys a generated file"

    # Spot-check known-referenced names that have files.
    for nm in ("lstknpoa", "transactionCode"):
        assert nm in clickable, f"{nm} should be clickable"
        assert trace.has_depvar(nm)


# --------------------------------------------------------------------------- #
# Dep-var structs: at least one terminal input + at least one with setters.
# --------------------------------------------------------------------------- #


def test_terminal_depvar_builds(trace, fnindex):
    # lstknpoa is terminal (no setters) → TerminalInputTable.
    struct = S.build_variable_struct(
        "lstknpoa", is_root=False, trace=trace, fnindex=fnindex
    )
    models.TerminalInputTable.model_validate(struct)
    assert struct["terminal"] is True
    assert struct["setters"] == []
    assert struct["variable"] == "lstknpoa"
    assert struct["business_name"] == ""  # prose fills
    assert struct["origin"] == {"b": "", "t": ""}


def test_setter_depvar_builds(trace, fnindex):
    # exitIndicator has 5 setters → VariableTable.
    struct = S.build_variable_struct(
        "exitIndicator", is_root=False, trace=trace, fnindex=fnindex
    )
    models.VariableTable.model_validate(struct)
    assert struct["variable"] == "exitIndicator"
    assert len(struct["setters"]) >= 1
    # Dep-var setter ids are namespaced and assigned_value.t carries the raw enum.
    for s in struct["setters"]:
        assert s["id"].startswith("exitIndicator-setter-")
        assert s["assigned_value"]["t"]  # raw value present
        assert s["assigned_value"]["b"] == ""
    # inquiry_path present (synthesized from the setters' file flow).
    assert "inquiry_path" in struct
    assert struct["inquiry_path"]["name"] == "Inquiry Path"


def test_unknown_depvar_is_terminal_placeholder(trace, fnindex):
    struct = S.build_variable_struct(
        "definitely_not_a_real_variable_xyz", is_root=False, trace=trace,
        fnindex=fnindex,
    )
    models.TerminalInputTable.model_validate(struct)
    assert struct["setters"] == []
    assert struct["terminal"] is True


# --------------------------------------------------------------------------- #
# _longest_common_chain_prefix — file-level prefix, dup-stem safe (GAP 8).
# --------------------------------------------------------------------------- #


def test_longest_common_chain_prefix_simple_shared_prefix():
    # Two setters sharing the leading file, diverging at the second.
    setters = [
        {"chain": ["dw710000::a", "dw780000::set"]},
        {"chain": ["dw710000::x", "dw730000::other"]},
    ]
    assert S._longest_common_chain_prefix(setters) == ["dw710000"]


def test_longest_common_chain_prefix_duplicated_stem_intra_file_hops():
    # GAP 8: setter A's chain lists dw710000 twice (intra-file hops). The
    # file-level common prefix must match what the de-duplicated chains give:
    # the shared file backbone is dw710000, diverging at the second file.
    # Without the dict.fromkeys de-dup, A's positional pos-1 (dw710000) would
    # mis-align against B's pos-1 (dw730000) and garble the prefix.
    with_dups = [
        {"chain": ["dw710000::a", "dw710000::b", "dw780000::set"]},
        {"chain": ["dw710000::x", "dw730000::other"]},
    ]
    deduped = [
        {"chain": ["dw710000::a", "dw780000::set"]},
        {"chain": ["dw710000::x", "dw730000::other"]},
    ]
    prefix = S._longest_common_chain_prefix(with_dups)
    assert prefix == ["dw710000"]
    assert prefix == S._longest_common_chain_prefix(deduped)


def test_longest_common_chain_prefix_full_shared_file_path_with_dups():
    # Both setters share the same two-file backbone; intra-file hops on one of
    # them must not shorten or garble the file-level prefix.
    setters = [
        {"chain": ["dw710000::a", "dw710000::b", "dw780000::set"]},
        {"chain": ["dw710000::x", "dw780000::y", "dw780000::z"]},
    ]
    assert S._longest_common_chain_prefix(setters) == ["dw710000", "dw780000"]
