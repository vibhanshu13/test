"""Tests for the DB-only setter-ORDER trace (vbt/setter_order.py, Wave 1) + its task/route wiring.

Tiers (mirrors test_lca_trace.py):
  * pure-logic (synthetic _LcaInputs, NO DB): interleave, depth, monotonic order, reachability
    prune, cycle termination, repeated-visit siteId, max_depth/max_nodes truncation, determinism.
    These ALWAYS run.
  * ASM CFG (hand-built blueprint dicts via _AsmCfg, NO files): block-rank/line emission,
    guaranteed vs branch-alternative dominance, multi-entry super-source, missing block_id
    line-range/line-order fallback, malformed/missing blob → line order + blueprint_missing warning.
    These ALWAYS run (DA.read_blob is monkeypatched to feed the in-memory blob — never a disk read).
  * DB-backed (auto-discovered chain_facts job; skip if none): ASM/C++/mixed variables, no-setters,
    unattributable-setter exclusion, missing fn_graph_adj hard-fail.
  * strict DB-only tripwire (copy/extend test_hardened_no_source_fallback).
  * task/route (Wave 2 — guarded so a missing symbol SKIPS, not errors-at-collection).

No source files, no blueprint JSON files: the ASM-CFG tier feeds blueprint dicts directly through a
monkeypatched DA.read_blob/DA.loads_gz, exactly the seam the request path uses.
"""
from __future__ import annotations

import random

import pytest

from vbt.interfaces import SetterSite
from vbt.lca_trace import _LcaInputs, DbArtifactMissing
from vbt.setter_order import _AsmCfg, _OrderBuilder, trace_variable_to_setter_order
from vbt.tests._lca_corpus import find_chain_facts_job


# =========================================================================== #
# helpers — synthetic _LcaInputs (the same shape _db_only_setter_lca_context yields)
# =========================================================================== #
def _cpp_site(stem, fn, line, value=None, instr="assign"):
    return SetterSite(variable="v", file_stem=stem, language="cpp", line=line,
                      instruction=instr, block_id=f"{stem}::{fn}", value=value, function=fn)


def _asm_site(stem, line, block_id, value=None, instr="OI"):
    return SetterSite(variable="v", file_stem=stem, language="asm", line=line,
                      instruction=instr, block_id=block_id, value=value)


def _adj(edges):
    """edges: list of (caller_stem, caller_fn, callee_stem, callee_fn, line).

    Returns the fn_graph_adj shape: caller_node -> {(callee_stem, callee_fn, line, cross)}.
    Every callee node is also seeded as a key so it is a real graph node.
    """
    out = {}
    for cs, cf, ds, df, line in edges:
        out.setdefault((cs, cf), set()).add((ds, df, line, False))
        out.setdefault((ds, df), out.get((ds, df), set()))
    return out


def _inputs(adj, node_types, setter_sites_by_node, lca_list, *, warnings=None, excluded=0):
    graph_nodes = set(adj.keys())
    for outs in adj.values():
        for (cs, cf, _l, _c) in outs:
            graph_nodes.add((cs, cf))
    return _LcaInputs(
        adj=adj,
        node_types=node_types,
        graph_nodes=graph_nodes,
        setter_nodes=set(setter_sites_by_node.keys()),
        setter_sites_by_node=setter_sites_by_node,
        lca_list=lca_list,
        warnings=list(warnings or []),
        excluded=excluded,
        setter_diag=[],
        forced_lca=False,
    )


def _build(inputs, *, max_depth=16, max_nodes=4000, asm_cfg_order=True):
    b = _OrderBuilder("job", inputs, max_depth=max_depth, max_nodes=max_nodes,
                      asm_cfg_order=asm_cfg_order, include_call_path=False)
    return b.build()


@pytest.fixture
def asm_blob(monkeypatch):
    """Install an in-memory blueprint blob so _AsmCfg/_OrderBuilder read it via DA.read_blob —
    NEVER from disk. Returns a setter that maps {stem: blueprint_dict}."""
    import vbt.setter_order as SO
    store = {}

    def fake_read_blob(job, key):
        # key shape: "bp:{stem}.asm.json"
        if key.startswith("bp:") and key.endswith(".asm.json"):
            stem = key[len("bp:"):-len(".asm.json")]
            return store.get(stem)            # the dict itself; loads_gz returns it unchanged
        return None

    monkeypatch.setattr(SO.DA, "read_blob", fake_read_blob)
    monkeypatch.setattr(SO.DA, "loads_gz", lambda payload: payload)
    return store


# --------------------------------------------------------------------------- #
# blueprint dict builders (in-memory only — fed through the monkeypatched read_blob seam)
# --------------------------------------------------------------------------- #
def _block(bid, lo, hi, flow, incoming=None):
    blk = {"id": bid, "start_line": lo, "end_line": hi, "flow": flow}
    if incoming:
        blk["incoming_branches"] = incoming
    return blk


def _straight_line_bp():
    """B1 -> B2 -> B3 (pure fallthrough by line ordering)."""
    return {"blocks": [
        _block("B1", 10, 12, [{"line": 10, "inst": "LA", "args": ["R1", "X"]},
                              {"line": 12, "inst": "OI", "args": ["F", "1"]}]),
        _block("B2", 20, 22, [{"line": 20, "inst": "MVC", "args": ["A", "B"]},
                              {"line": 22, "inst": "STH", "args": ["R2", "Y"]}]),
        _block("B3", 30, 32, [{"line": 30, "inst": "L", "args": ["R3", "Z"]},
                              {"line": 32, "inst": "BR", "args": ["R14"]}]),
    ]}


def _diamond_bp():
    """If/else diamond: B1 -> {B2 fallthrough, B3 branch} -> B4. B1 dominates everything; B2/B3
    dominate neither each other nor B4."""
    return {"blocks": [
        _block("B1", 10, 12, [{"line": 10, "inst": "CLC", "args": ["A", "B"]},
                              {"line": 12, "inst": "BNE", "args": ["B3"]}]),
        _block("B2", 20, 22, [{"line": 20, "inst": "OI", "args": ["F", "1"]},
                              {"line": 22, "inst": "B", "args": ["B4"]}],
               incoming=[{"source": "B1", "type": "FALLTHROUGH"}]),
        _block("B3", 30, 31, [{"line": 30, "inst": "OI", "args": ["G", "2"]}],
               incoming=[{"source": "B1", "type": "BRANCH"}]),
        _block("B4", 40, 42, [{"line": 40, "inst": "STH", "args": ["R2", "Y"]},
                              {"line": 42, "inst": "BR", "args": ["R14"]}],
               incoming=[{"source": "B2", "type": "BRANCH"},
                         {"source": "B3", "type": "FALLTHROUGH"}]),
    ]}


# =========================================================================== #
# PURE-LOGIC (synthetic _LcaInputs, NO DB) — always run
# =========================================================================== #
def test_cpp_direct_and_child_calls_interleave_by_line():
    # R::main: direct setter at line 50; child calls A (line 20), B (line 80).
    # B can't reach a covered setter → pruned. A's setter must come BEFORE R's (call line 20 < 50).
    adj = _adj([("r", "main", "a", "A", 20), ("r", "main", "b", "B", 80)])
    nt = {"r": "cpp", "a": "cpp", "b": "cpp"}
    sites = {("r", "main"): [_cpp_site("r", "main", 50, "r1")],
             ("a", "A"): [_cpp_site("a", "A", 5, "a1")]}
    lca = [(("r", "main"), [("r", "main"), ("a", "A")])]
    trees, trunc = _build(_inputs(adj, nt, sites, lca))
    setters = trees[0]["setters"]
    files = [s["file"] for s in setters]
    assert files == ["a", "r"], "child-call setter (line 20) interleaves before direct setter (50)"
    assert "b" not in files, "B is unreachable to a covered setter → pruned"
    assert trunc is False
    # C++ setters omit ASM-only dominance fields.
    for s in setters:
        assert "blockRank" not in s and "dominanceCertainty" not in s
        assert s["function"]                       # C++ carries the enclosing function


def test_depth_correct_for_direct_and_nested():
    # R -> M -> S ; setters at R (depth0), M (depth1), S (depth2).
    adj = _adj([("r", "R", "m", "M", 10), ("m", "M", "s", "S", 10)])
    nt = {"r": "cpp", "m": "cpp", "s": "cpp"}
    sites = {("r", "R"): [_cpp_site("r", "R", 5)],
             ("m", "M"): [_cpp_site("m", "M", 5)],
             ("s", "S"): [_cpp_site("s", "S", 5)]}
    lca = [(("r", "R"), [("r", "R"), ("m", "M"), ("s", "S")])]
    trees, _ = _build(_inputs(adj, nt, sites, lca))
    by_file = {s["file"]: s["depth"] for s in trees[0]["setters"]}
    assert by_file == {"r": 0, "m": 1, "s": 2}


def test_order_monotonic_0_to_N():
    adj = _adj([("r", "R", "m", "M", 10), ("m", "M", "s", "S", 10)])
    nt = {"r": "cpp", "m": "cpp", "s": "cpp"}
    sites = {("r", "R"): [_cpp_site("r", "R", 5)],
             ("m", "M"): [_cpp_site("m", "M", 5)],
             ("s", "S"): [_cpp_site("s", "S", 5)]}
    lca = [(("r", "R"), [("r", "R"), ("m", "M"), ("s", "S")])]
    trees, _ = _build(_inputs(adj, nt, sites, lca))
    orders = [s["order"] for s in trees[0]["setters"]]
    assert orders == list(range(len(orders)))
    assert trees[0]["setterCount"] == len(orders)


def test_reachability_prune_drops_dead_child_calls():
    # R calls A (has setter) and D (and its whole subtree D->E) with NO setter anywhere.
    adj = _adj([("r", "R", "a", "A", 10), ("r", "R", "d", "D", 20), ("d", "D", "e", "E", 5)])
    nt = {"r": "cpp", "a": "cpp", "d": "cpp", "e": "cpp"}
    sites = {("a", "A"): [_cpp_site("a", "A", 5)]}     # only A is a setter node
    lca = [(("r", "R"), [("a", "A")])]
    trees, _ = _build(_inputs(adj, nt, sites, lca))
    files = {s["file"] for s in trees[0]["setters"]}
    assert files == {"a"}, "the dead D/E subtree must be pruned (cannot reach a covered setter)"


def test_recursive_back_edge_terminates():
    # A -> B -> A cycle; setters at A and B. The per-path visited guard must stop re-emit.
    adj = _adj([("a", "A", "b", "B", 10), ("b", "B", "a", "A", 10)])
    nt = {"a": "cpp", "b": "cpp"}
    sites = {("a", "A"): [_cpp_site("a", "A", 5)],
             ("b", "B"): [_cpp_site("b", "B", 5)]}
    lca = [(("a", "A"), [("a", "A"), ("b", "B")])]
    trees, _ = _build(_inputs(adj, nt, sites, lca))   # must not hang / recurse forever
    files = [s["file"] for s in trees[0]["setters"]]
    # A entered once (LCA), B once via A; the back-edge B->A is blocked by the per-path visited set.
    assert files.count("a") == 1 and files.count("b") == 1


def test_repeated_physical_setter_two_call_sites_same_siteId():
    # R calls A at line 10 and again (different fn wrapper) routes back to the SAME node A's setter.
    # Build R -> {M1, M2}, both M1 and M2 -> A. A's single physical setter is visited twice.
    adj = _adj([("r", "R", "m1", "M1", 10), ("r", "R", "m2", "M2", 20),
                ("m1", "M1", "a", "A", 5), ("m2", "M2", "a", "A", 5)])
    nt = {"r": "cpp", "m1": "cpp", "m2": "cpp", "a": "cpp"}
    sites = {("a", "A"): [_cpp_site("a", "A", 7, "x")]}
    lca = [(("r", "R"), [("a", "A")])]
    trees, _ = _build(_inputs(adj, nt, sites, lca))
    a_visits = [s for s in trees[0]["setters"] if s["file"] == "a"]
    assert len(a_visits) == 2, "same physical site reached via M1 and M2 → two ordered visits"
    assert a_visits[0]["siteId"] == a_visits[1]["siteId"], "identical stable siteId on both visits"
    # but distinct order indices (flat list of visits).
    assert a_visits[0]["order"] != a_visits[1]["order"]


def test_max_depth_sets_truncated():
    # deep chain R->M->S->T; cap depth at 1 so the deeper nodes are cut → truncated:true.
    adj = _adj([("r", "R", "m", "M", 10), ("m", "M", "s", "S", 10), ("s", "S", "t", "T", 10)])
    nt = {"r": "cpp", "m": "cpp", "s": "cpp", "t": "cpp"}
    sites = {("t", "T"): [_cpp_site("t", "T", 5)]}
    lca = [(("r", "R"), [("t", "T")])]
    trees, trunc = _build(_inputs(adj, nt, sites, lca), max_depth=1)
    assert trunc is True


def test_max_nodes_sets_truncated():
    # wide fan-out so the node budget trips before the (single, deep) setter is emitted.
    edges = [("r", "R", f"c{i}", f"C{i}", i) for i in range(50)]
    edges += [(f"c{i}", f"C{i}", "s", "S", 1) for i in range(50)]
    adj = _adj(edges)
    nt = {"r": "cpp", "s": "cpp"}
    for i in range(50):
        nt[f"c{i}"] = "cpp"
    sites = {("s", "S"): [_cpp_site("s", "S", 5)]}
    lca = [(("r", "R"), [("s", "S")])]
    trees, trunc = _build(_inputs(adj, nt, sites, lca), max_nodes=3)
    assert trunc is True


def test_deterministic_across_shuffled_input():
    edges = [("r", "main", "a", "A", 20), ("r", "main", "b", "B", 30),
             ("a", "A", "c", "C", 5), ("b", "B", "c", "C", 5)]
    nt = {"r": "cpp", "a": "cpp", "b": "cpp", "c": "cpp"}
    base_sites = {("r", "main"): [_cpp_site("r", "main", 50), _cpp_site("r", "main", 10)],
                  ("a", "A"): [_cpp_site("a", "A", 5)],
                  ("c", "C"): [_cpp_site("c", "C", 9)]}
    lca = [(("r", "main"), [("r", "main"), ("a", "A"), ("c", "C")])]

    def run_with_shuffle(seed):
        rng = random.Random(seed)
        # shuffle the adjacency-edge sets and the per-node setter lists; rebuild adj as shuffled sets.
        shuffled_edges = list(edges)
        rng.shuffle(shuffled_edges)
        adj = _adj(shuffled_edges)
        sites = {}
        for node, lst in base_sites.items():
            cp = list(lst)
            rng.shuffle(cp)
            sites[node] = cp
        trees, _ = _build(_inputs(adj, nt, sites, lca))
        return [(s["siteId"], s["order"], s["depth"]) for s in trees[0]["setters"]]

    baseline = run_with_shuffle(0)
    for seed in range(1, 6):
        assert run_with_shuffle(seed) == baseline, "ordering must be stable across shuffled input"


# =========================================================================== #
# ASM CFG (hand-built blueprint dicts via _AsmCfg / _OrderBuilder, NO files)
# =========================================================================== #
def test_asm_cfg_pure_view_straight_line():
    cfg = _AsmCfg(_straight_line_bp())
    assert cfg.ok
    assert cfg.block_ranks == {"B1": 0, "B2": 1, "B3": 2}
    assert cfg.dominates("B1", "B3") and cfg.dominates("B1", "B2")
    assert not cfg.dominates("B2", "B1")
    assert cfg.block_for_line(21) == "B2"


def test_asm_straight_line_emitted_by_rank_and_line(asm_blob):
    asm_blob["aa71"] = _straight_line_bp()
    sites = {("aa71", "aa71"): [_asm_site("aa71", 22, "B2", "y"),    # rank 1
                                _asm_site("aa71", 12, "B1", "x")]}   # rank 0 — must come first
    lca = [(("aa71", "aa71"), [("aa71", "aa71")])]
    inp = _inputs({("aa71", "aa71"): set()}, {"aa71": "asm"}, sites, lca)
    trees, _ = _build(inp)
    out = trees[0]["setters"]
    assert [s["blockId"] for s in out] == ["B1", "B2"], "emitted by ascending block rank"
    assert [s["blockRank"] for s in out] == [0, 1]
    assert [s["order"] for s in out] == [0, 1]


def test_asm_dominating_prefix_is_guaranteed(asm_blob):
    asm_blob["aa71"] = _straight_line_bp()
    # two setters: B1 (dominating prefix, emitted first) + B3 (later peer).
    sites = {("aa71", "aa71"): [_asm_site("aa71", 12, "B1", "x"),
                                _asm_site("aa71", 30, "B3", "z", instr="STH")]}
    lca = [(("aa71", "aa71"), [("aa71", "aa71")])]
    trees, _ = _build(_inputs({("aa71", "aa71"): set()}, {"aa71": "asm"}, sites, lca))
    out = trees[0]["setters"]
    assert out[0]["blockId"] == "B1"
    assert out[0]["dominanceCertainty"] == "guaranteed", "B1 dominates the later B3 peer"


def test_asm_branch_alternative_setter(asm_blob):
    asm_blob["aa71"] = _diamond_bp()
    # B2 (branch arm, rank lower than B4) is emitted BEFORE the B4 merge-block peer it does NOT
    # dominate → branch-alternative. B4 (last, no later peer) → guaranteed.
    sites = {("aa71", "aa71"): [_asm_site("aa71", 20, "B2", "1"),
                                _asm_site("aa71", 40, "B4", "2", instr="STH")]}
    lca = [(("aa71", "aa71"), [("aa71", "aa71")])]
    trees, _ = _build(_inputs({("aa71", "aa71"): set()}, {"aa71": "asm"}, sites, lca))
    out = {s["blockId"]: s["dominanceCertainty"] for s in trees[0]["setters"]}
    assert out["B2"] == "branch-alternative"
    assert out["B4"] == "guaranteed"


def test_asm_multi_entry_super_source(asm_blob):
    # Two disjoint entry blocks E1 and E2 (each no in-edge). The virtual super-source makes both
    # roots; the CFG view must build ranks for both and place each setter.
    bp = {"blocks": [
        _block("E1", 10, 11, [{"line": 10, "inst": "OI", "args": ["F", "1"]}]),
        _block("E2", 50, 51, [{"line": 50, "inst": "OI", "args": ["G", "2"]}]),
    ]}
    asm_blob["aa71"] = bp
    cfg = _AsmCfg(bp)
    assert cfg.ok
    assert set(cfg.block_ranks) == {"E1", "E2"}     # both reachable from the super-source
    sites = {("aa71", "aa71"): [_asm_site("aa71", 50, "E2"), _asm_site("aa71", 10, "E1")]}
    lca = [(("aa71", "aa71"), [("aa71", "aa71")])]
    trees, _ = _build(_inputs({("aa71", "aa71"): set()}, {"aa71": "asm"}, sites, lca))
    assert {s["blockId"] for s in trees[0]["setters"]} == {"E1", "E2"}


def test_asm_missing_block_id_falls_back_to_line_range(asm_blob):
    asm_blob["aa71"] = _straight_line_bp()
    # setter with NO block_id but a line inside B2's range → placed in B2 by line range.
    s = _asm_site("aa71", 21, "")          # line 21 ∈ B2 (20..22), empty block_id
    sites = {("aa71", "aa71"): [s]}
    lca = [(("aa71", "aa71"), [("aa71", "aa71")])]
    trees, _ = _build(_inputs({("aa71", "aa71"): set()}, {"aa71": "asm"}, sites, lca))
    out = trees[0]["setters"][0]
    assert out["blockId"] == "B2", "placed into the containing block by line range"
    assert out["dominanceCertainty"] == "guaranteed"  # B2 is the only / last item


def test_asm_unplaceable_block_id_is_unknown(asm_blob):
    asm_blob["aa71"] = _straight_line_bp()
    # line 999 maps to NO block range and block_id 'NOPE' is not in the rank map → unknown.
    s = _asm_site("aa71", 999, "NOPE")
    sites = {("aa71", "aa71"): [s]}
    lca = [(("aa71", "aa71"), [("aa71", "aa71")])]
    trees, _ = _build(_inputs({("aa71", "aa71"): set()}, {"aa71": "asm"}, sites, lca))
    out = trees[0]["setters"][0]
    assert out["dominanceCertainty"] == "unknown"
    assert out["blockRank"] is None


def test_asm_missing_blob_degrades_to_line_order_with_warning(asm_blob):
    # no entry for 'aa71' in asm_blob → DA.read_blob returns None → blueprint_missing warning,
    # setters fall back to line order. No source read (read_blob is the only seam, returns None).
    warnings = []
    sites = {("aa71", "aa71"): [_asm_site("aa71", 30, "Bz"), _asm_site("aa71", 10, "Ba")]}
    lca = [(("aa71", "aa71"), [("aa71", "aa71")])]
    inp = _inputs({("aa71", "aa71"): set()}, {"aa71": "asm"}, sites, lca, warnings=warnings)
    trees, _ = _build(inp)
    out = trees[0]["setters"]
    assert [s["line"] for s in out] == [10, 30], "fallback = ascending line order"
    assert all(s["dominanceCertainty"] == "unknown" for s in out)
    assert any(w.get("code") == "blueprint_missing" and w.get("file") == "aa71"
               for w in inp.warnings)


def test_asm_malformed_blob_degrades_to_line_order(asm_blob):
    asm_blob["aa71"] = {"blocks": []}      # malformed: empty blocks → cfg.ok False
    sites = {("aa71", "aa71"): [_asm_site("aa71", 30, "Bz"), _asm_site("aa71", 10, "Ba")]}
    lca = [(("aa71", "aa71"), [("aa71", "aa71")])]
    trees, _ = _build(_inputs({("aa71", "aa71"): set()}, {"aa71": "asm"}, sites, lca))
    out = trees[0]["setters"]
    assert [s["line"] for s in out] == [10, 30]
    assert all(s["dominanceCertainty"] == "unknown" for s in out)


def test_no_executionorder_runtimeorder_fields(asm_blob):
    # Honesty boundary: the emitted setter dicts never use runtime-implying field names.
    asm_blob["aa71"] = _straight_line_bp()
    sites = {("aa71", "aa71"): [_asm_site("aa71", 12, "B1")]}
    lca = [(("aa71", "aa71"), [("aa71", "aa71")])]
    trees, _ = _build(_inputs({("aa71", "aa71"): set()}, {"aa71": "asm"}, sites, lca))
    blob = repr(trees)
    assert "executionOrder" not in blob and "runtimeOrder" not in blob


# =========================================================================== #
# DB-backed (auto-discovered chain_facts job; skip if none)
# =========================================================================== #
_JOB = find_chain_facts_job()
_db = pytest.mark.skipif(_JOB is None, reason="no chain_facts-ready job in jobs/ (run precompute_db "
                                              "+ chain_facts_db)")


@_db
def test_db_cpp_variable_setters_shape():
    job, bp, src = _JOB
    out = trace_variable_to_setter_order(job, "softCardValue", "cpp",
                                         blueprint_dir=str(bp), asm_dir=str(src), debug=True)
    assert out["status"] == "success"
    assert out["orderSemantics"]["runtimeProof"] is False
    assert out["trees"], "softCardValue should yield at least one LCA tree"
    saw_cpp = False
    for tree in out["trees"]:
        last_order = -1
        for s in tree["setters"]:
            assert s["file"] and isinstance(s["line"], int)        # file+line on every setter
            assert s["order"] == last_order + 1                    # monotonic 0..N within tree
            last_order = s["order"]
            if s["language"] == "cpp":
                saw_cpp = True
                assert s["function"], "C++ setter carries the enclosing function"
                assert "blockRank" not in s and "dominanceCertainty" not in s
    assert saw_cpp, "softCardValue is C++-rooted; expected C++ setters"


@_db
def test_db_asm_variable_metadata():
    # softCardValue's trace reaches ASM setters (aa71 etc.) — assert ASM entries carry CFG metadata
    # where a blueprint blob exists. (Discovered via the C++ root that fans into ASM.)
    job, bp, src = _JOB
    out = trace_variable_to_setter_order(job, "softCardValue", "cpp",
                                         blueprint_dir=str(bp), asm_dir=str(src))
    asm_setters = [s for tree in out["trees"] for s in tree["setters"] if s["language"] == "asm"]
    if not asm_setters:
        pytest.skip("this KB's softCardValue trace surfaced no ASM setters")
    for s in asm_setters:
        assert s["function"] is None                       # ASM setters have no C++ function
        assert "blockRank" in s and "dominanceCertainty" in s
        assert s["dominanceCertainty"] in ("guaranteed", "branch-alternative", "unknown")


@_db
def test_db_mixed_trace_has_both_languages():
    job, bp, src = _JOB
    out = trace_variable_to_setter_order(job, "softCardValue", "cpp",
                                         blueprint_dir=str(bp), asm_dir=str(src))
    langs = {s["language"] for tree in out["trees"] for s in tree["setters"]}
    if langs != {"asm", "cpp"}:
        pytest.xfail(f"this KB's softCardValue surfaced only {sorted(langs)} setters "
                     f"(mixed-language demonstration needs both)")
    assert langs == {"asm", "cpp"}


@_db
def test_db_no_setters_variable_success_empty():
    job, bp, src = _JOB
    out = trace_variable_to_setter_order(job, "__no_such_variable_zzz__", "cpp",
                                         blueprint_dir=str(bp), asm_dir=str(src))
    assert out["status"] == "success"
    assert out["trees"] == []
    assert any(w.get("code") == "no_setters" for w in out["warnings"])


@_db
def test_db_unattributable_cpp_setter_excluded_not_raised(monkeypatch):
    # Force _attribute_cpp to return None for every C++ setter → with the setter-order default
    # (allow_unattributed_setters=True) those are excluded + counted, never raised.
    job, bp, src = _JOB
    import vbt.lca_trace as L
    monkeypatch.setattr(L, "_attribute_cpp", lambda stem, site, graph_nodes: None)
    out = trace_variable_to_setter_order(job, "softCardValue", "cpp",
                                         blueprint_dir=str(bp), asm_dir=str(src))
    assert out["status"] == "success"
    assert out["excludedSetterCount"] >= 1
    assert any(w.get("code") == "unattributed_setter" for w in out["warnings"])


@_db
def test_db_missing_fn_graph_adj_hardfails():
    _job, bp, src = _JOB
    with pytest.raises(DbArtifactMissing):
        trace_variable_to_setter_order("no-such-job-id", "softCardValue", "cpp",
                                       blueprint_dir=str(bp), asm_dir=str(src))


@_db
def test_db_stale_fn_graph_adj_hardfails(monkeypatch):
    job, bp, src = _JOB
    import vbt.lca_trace as L
    real = L.DA.read_manifest

    def fake(jid, art):
        row = real(jid, art)
        if art == "fn_graph_adj" and row is not None:
            row = dict(row); row["version"] = 999
        return row
    monkeypatch.setattr(L.DA, "read_manifest", fake)
    with pytest.raises(DbArtifactMissing):
        trace_variable_to_setter_order(job, "softCardValue", "cpp",
                                       blueprint_dir=str(bp), asm_dir=str(src))


# =========================================================================== #
# STRICT DB-ONLY tripwire (copy/extend test_hardened_no_source_fallback)
# =========================================================================== #
@_db
def test_hardened_no_source_fallback(monkeypatch):
    """THE proof of strict DB-only for setter-order: with a fully-populated DB, monkeypatch every
    source/disk reader to RAISE — the trace must return the IDENTICAL result, NO patched reader may
    fire, and (when ASM setters exist) the ASM CFG must arrive via DA.read_blob('bp:...asm.json')."""
    job, bp, src = _JOB
    baseline = trace_variable_to_setter_order(job, "softCardValue", "cpp",
                                              blueprint_dir=str(bp), asm_dir=str(src))
    fired = []

    def tripwire(name):
        def _boom(*a, **k):
            fired.append(name)
            raise AssertionError(f"strict DB-only violated: {name} read source/disk")
        return _boom

    import vbt.cpp_frontend.wrapper as _w
    import backward_traversal.utils.blueprint_utils as _bu
    import vbt.setters.cpp_setters as _cs
    import vbt.setters.asm_setters as _as
    import vbt.precompute.resolvers_db as _rd
    monkeypatch.setattr(_w, "run_cfg_extract", tripwire("run_cfg_extract"))
    monkeypatch.setattr(_bu, "load_json", tripwire("load_json"))
    monkeypatch.setattr(_cs, "find_cpp_setters_in_file", tripwire("find_cpp_setters_in_file"))
    monkeypatch.setattr(_as, "find_asm_setters_in_file", tripwire("find_asm_setters_in_file"))
    monkeypatch.setattr(_rd, "preload_resolvers", tripwire("preload_resolvers"))

    # spy on DA.read_blob to PROVE the ASM CFG arrives through the blob seam (bp:...asm.json).
    import vbt.setter_order as SO
    real_read_blob = SO.DA.read_blob
    blob_keys = []

    def spy_read_blob(job_id, key):
        blob_keys.append(key)
        return real_read_blob(job_id, key)
    monkeypatch.setattr(SO.DA, "read_blob", spy_read_blob)

    out = trace_variable_to_setter_order(job, "softCardValue", "cpp",
                                         blueprint_dir=str(bp), asm_dir=str(src))
    assert not fired, f"source/disk readers fired: {fired}"
    assert out == baseline
    asm_setters = [s for tree in out["trees"] for s in tree["setters"] if s["language"] == "asm"]
    if asm_setters:
        assert any(k.startswith("bp:") and k.endswith(".asm.json") for k in blob_keys), \
            "ASM CFG must arrive via DA.read_blob('bp:{stem}.asm.json')"


# =========================================================================== #
# TASK / ROUTE (Wave 2 — guard so a missing symbol SKIPS, not errors-at-collection)
# =========================================================================== #
try:
    from api.tasks.vbt_lca_trace_task import run_setter_order, run_vbt_setter_order
    _HAVE_TASK = True
except Exception:
    run_setter_order = run_vbt_setter_order = None  # type: ignore
    _HAVE_TASK = False

_task = pytest.mark.skipif(not _HAVE_TASK,
                           reason="Wave 2 task symbols (run_setter_order / run_vbt_setter_order) "
                                  "not present yet")


@_db
@_task
def test_run_setter_order_writes_json(tmp_path, monkeypatch):
    job, bp, src = _JOB
    import api.tasks.vbt_lca_trace_task as T
    # write the output under a temp dir (no real ws) and point artifact resolution at the KB dirs.
    monkeypatch.setattr(T.settings, "JOBS_BASE_DIR", tmp_path)
    out_job = "soj-write-test"
    options = {
        "kb_id": job, "variable": "softCardValue", "language": "cpp",
        "blueprint_dir": str(bp), "asm_dir": str(src),
    }
    res = run_setter_order(out_job, options, ws=None)
    assert res["status"] == "success"
    out_file = tmp_path / out_job / "output" / "setter_order.json"
    assert out_file.is_file()
    import json
    payload = json.loads(out_file.read_text())
    assert payload["status"] == "success"
    assert "trees" in payload


@_task
def test_bogus_job_id_returns_failed_json(tmp_path, monkeypatch):
    import api.tasks.vbt_lca_trace_task as T
    monkeypatch.setattr(T.settings, "JOBS_BASE_DIR", tmp_path)
    options = {"kb_id": "no-such-kb-zzz", "variable": "softCardValue", "language": "cpp",
               "blueprint_dir": str(tmp_path / "nope"), "asm_dir": str(tmp_path / "nope")}
    res = run_vbt_setter_order.run("soj-bogus", options)
    assert res["status"] == "failed"
    assert "error" in res
    # best-effort failure JSON is written when the output dir can be created.
    out_file = tmp_path / "soj-bogus" / "output" / "setter_order.json"
    if out_file.is_file():
        import json
        assert json.loads(out_file.read_text())["status"] == "failed"


@_task
def test_soft_timeout_returns_failed_json(tmp_path, monkeypatch):
    from celery.exceptions import SoftTimeLimitExceeded
    import api.tasks.vbt_lca_trace_task as T
    monkeypatch.setattr(T.settings, "JOBS_BASE_DIR", tmp_path)
    # make the worker body raise a soft-timeout; the wrapper must convert it to status:failed JSON.
    monkeypatch.setattr(T, "run_setter_order",
                        lambda *a, **k: (_ for _ in ()).throw(SoftTimeLimitExceeded()))
    res = run_vbt_setter_order.run("soj-timeout",
                                   {"variable": "x", "language": "cpp"})
    assert res["status"] == "failed"
    assert "trees" in res and res["trees"] == []


def test_route_dispatches_with_kb_preserved(monkeypatch, tmp_path):
    """POST /v1/jobs/vbt/setter-order registered → dispatches asm.vbt_setter_order with kb_id
    preserved as the artifact source and a FRESH output job id."""
    try:
        from fastapi.testclient import TestClient
        from api.app import app
        from api.db import get_db
        from api.dependencies import get_current_user
        import api.routes.vbt as R
        import api.tasks.vbt_lca_trace_task as T
    except Exception as exc:                                   # Wave 2 / app not importable
        pytest.skip(f"route deps unavailable: {exc}")

    # capture the apply_async dispatch instead of hitting a broker.
    captured = {}

    class _FakeTask:
        id = "fake-task-id"

    def fake_apply_async(args=None, **kwargs):
        captured["args"] = args
        return _FakeTask()

    monkeypatch.setattr(T.run_vbt_setter_order, "apply_async", fake_apply_async)
    monkeypatch.setattr(T.settings, "JOBS_BASE_DIR", tmp_path)
    # keep the route's KB-dir resolution hermetic.
    monkeypatch.setattr(R.settings, "JOBS_BASE_DIR", tmp_path)

    # fake KB row + auth + DB so the route reaches dispatch.
    class _FakeKB:
        id = "kb-123"
        source_path = None

    class _FakeQuery:
        def filter(self, *a, **k):
            return self

        def first(self):
            return _FakeKB()

    class _FakeDB:
        def query(self, *a, **k):
            return _FakeQuery()

    class _FakeUser:
        username = "tester"

    app.dependency_overrides[get_db] = lambda: _FakeDB()
    app.dependency_overrides[get_current_user] = lambda: _FakeUser()
    try:
        client = TestClient(app)
        resp = client.post("/v1/jobs/vbt/setter-order",
                            json={"kb_id": "kb-123", "variable": "softCardValue",
                                  "language": "cpp"})
        assert resp.status_code == 202, resp.text
        body = resp.json()
        assert body["operation"] == "vbt_setter_order"
        # dispatched with a FRESH output job id (≠ kb_id) and kb_id preserved in options.
        out_job, options = captured["args"]
        assert out_job != "kb-123"
        assert options["kb_id"] == "kb-123"
        assert options["variable"] == "softCardValue"
        assert options["language"] == "cpp"
    finally:
        app.dependency_overrides.clear()
