"""Declaration-anchored scoping of bare C++ function-locals (DepVarRef.local_scope).

A real lineage doc merged every bare local sharing a name into ONE node keyed by name
alone: `i` carried setters from 68 files and 348 outgoing edges into unrelated targets;
`tempPtr` 225, `j` 197. Two automatic locals that merely share a name are different
variables — but only provably so when the read's own function DECLARES the name at/before
the read line (C++ scoping then guarantees no outside write spelled with that name can
target it). The gate (`recurse._cpp_local_scope`) fires only on that positive proof:

  * proof found  → identity keys on (name, @local:file:function); the setter search is
    restricted to the discovery file + same function (only provably-irrelevant setters
    are removed — never a false negative);
  * no proof     → "" and behavior is byte-identical to the unscoped engine (globals,
    unqualified member reads, parameters, `int i;` without initializer, parse/CFG gaps).

Real tree-sitter setter extraction on disk fixtures; the CFG function map is synthetic
(same convention as the node-cache tests).
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[2]))

from vbt.depvars.extract import DepVarRef  # noqa: E402
from vbt.depvars.recurse import (  # noqa: E402
    _NodeCtx, _candidate_files_by_target, _cpp_local_scope, _dep_key,
    _gather_candidate_setters,
)

# Fixture: two functions in ONE file, each declaring its own local `i`; `g` is file-scope.
_SRC = """int g = 0;

void funcA() {
    int i = 0;
    i = g + 1;
    out = i;
}

void funcB() {
    int i = 5;
    i = 7;
    res = i;
}
"""

# read-before-declaration: the read at line 2 refers to the OUTER name, not the local.
_SRC_LATE_DECL = """void funcC() {
    use = i;
    int i = 5;
}
"""


def _cfg(*fns):
    """Synthetic cfg_extract output: [(name, [stmt lines])] → the fn_attr shape.
    Blocks carry an ``id`` so the condition collector's CFG walk accepts them."""
    return [{"function": name,
             "cfg_blocks": [{"id": i, "stmts": [{"line": ln} for ln in lines],
                             "succs": []}]}
            for i, (name, lines) in enumerate(fns)]


_CFG_T = _cfg(("funcA", [4, 5, 6]), ("funcB", [10, 11, 12]))
_CFG_T2 = _cfg(("funcC", [2, 3]))


class _Idx:
    def files_for(self, name, language):
        return {"t", "other1", "other2"}


def _ctx(tmp_path, cfg_by_stem):
    ctx = _NodeCtx(
        blueprint_dir=tmp_path, asm_dir=tmp_path, chain_set={"t"},
        upstream_bounds={}, route_engine=None, chain_hops=None, max_depth=2,
        const_resolver=None, max_offchain_files=100, asm_max_levels=16,
        max_descendants=50, midx=_Idx(), memb=None, reach_union=None,
    )
    ctx.cfg_cache.update(cfg_by_stem)   # pre-seeded → the real extractor is never run
    return ctx


def _write_fixture(tmp_path):
    (tmp_path / "t.cpp").write_text(_SRC)
    (tmp_path / "t2.cpp").write_text(_SRC_LATE_DECL)


def _dep(name="i", file="t.cpp", line=6, **kw):
    return DepVarRef(name=name, language="cpp", relationship="condition",
                     found_at={"file": file, "startLine": line, "endLine": line}, **kw)


# --------------------------------------------------------------------------- #
# the proof gate
# --------------------------------------------------------------------------- #
def test_declared_local_gets_its_functions_scope(tmp_path):
    _write_fixture(tmp_path)
    ctx = _ctx(tmp_path, {"t": _CFG_T, "t2": _CFG_T2})
    assert _cpp_local_scope(_dep(line=6), ctx) == "funcA"
    assert _cpp_local_scope(_dep(line=12), ctx) == "funcB"


def test_no_proof_cases_stay_unscoped(tmp_path):
    _write_fixture(tmp_path)
    ctx = _ctx(tmp_path, {"t": _CFG_T, "t2": _CFG_T2})
    # file-scope variable: its declaration maps to no function → not a local proof
    assert _cpp_local_scope(_dep(name="g", line=5), ctx) == ""
    # read BEFORE the declaration line: refers to the outer name → no proof
    assert _cpp_local_scope(_dep(file="t2.cpp", line=2), ctx) == ""
    # non-cpp / qualified / function-output deps never fire the gate
    asm = DepVarRef(name="I", language="asm", relationship="condition",
                    found_at={"file": "t.asm", "startLine": 6, "endLine": 6})
    assert _cpp_local_scope(asm, ctx) == ""
    assert _cpp_local_scope(_dep(line=6, qualified="a.b.i"), ctx) == ""
    assert _cpp_local_scope(_dep(line=6, is_function_output=True), ctx) == ""
    # missing CFG (no function map) → never guess
    assert _cpp_local_scope(_dep(line=6), _ctx(tmp_path, {"t": []})) == ""
    # missing file on disk → never guess
    assert _cpp_local_scope(_dep(file="gone.cpp", line=6), ctx) == ""


# --------------------------------------------------------------------------- #
# identity
# --------------------------------------------------------------------------- #
def test_dep_key_splits_scoped_locals_and_language_scopes_unbridged():
    a = _dep(line=6, local_scope="funcA")
    b = _dep(line=12, local_scope="funcB")
    assert _dep_key(a) == ("I", "@local:t:funcA")
    assert _dep_key(b) == ("I", "@local:t:funcB")
    assert _dep_key(a) != _dep_key(b)
    # v15: an UNBRIDGED bare name is language-scoped — a same-named dep in the
    # other language is a different variable (the old language-blind merge left
    # the second language's setter search silently unrun).
    assert _dep_key(_dep(line=6)) == ("I", "@lang:cpp")
    asm = DepVarRef(name="I", language="asm", relationship="condition",
                    found_at={"file": "t.asm", "startLine": 6, "endLine": 6})
    assert _dep_key(asm) == ("I", "@lang:asm")
    assert _dep_key(_dep(line=6)) != _dep_key(asm)
    # a BRIDGED pair (high-certainty cross-language alias) keeps the merged key
    assert _dep_key(_dep(line=6, bridged=True)) == ("I", "")
    asm.bridged = True
    assert _dep_key(asm) == ("I", "")
    # struct-member and function-output identity are untouched
    q = _dep(line=6, qualified="a.b.i", local_scope="")
    assert _dep_key(q) == ("I", "a.b.i")


# --------------------------------------------------------------------------- #
# setter search restriction
# --------------------------------------------------------------------------- #
def test_scoped_candidates_restricted_to_discovery_file(tmp_path):
    _write_fixture(tmp_path)
    ctx = _ctx(tmp_path, {"t": _CFG_T})
    cbt = _candidate_files_by_target(_dep(line=6, local_scope="funcA"), [], ctx)
    assert [c for _, _, _, c in cbt] == [["t"]]   # never the corpus writers
    # no proof → unchanged corpus-wide candidates (chain + writers + discovery)
    _, _, _, cand = _candidate_files_by_target(_dep(line=6), [], ctx)[0]
    assert set(cand) == {"t", "other1", "other2"}


def test_scoped_setter_search_keeps_only_same_function_sites(tmp_path):
    _write_fixture(tmp_path)
    ctx = _ctx(tmp_path, {"t": _CFG_T})
    dep = _dep(line=6, local_scope="funcA")
    setters = _gather_candidate_setters(dep, ctx, _candidate_files_by_target(dep, [], ctx))
    lines = sorted(s.line for s in setters)
    assert lines == [4, 5], f"expected funcA's decl+assign only, got lines {lines}"
    assert all(s.function == "funcA" for s in setters)
    # the declaration proof guarantees the filter can never come back empty
    assert any(s.is_declaration for s in setters)
    # funcB's same-named local resolves to ITS OWN sites
    dep_b = _dep(line=12, local_scope="funcB")
    lines_b = sorted(s.line for s in
                     _gather_candidate_setters(dep_b, ctx, _candidate_files_by_target(dep_b, [], ctx)))
    assert lines_b == [10, 11]


def test_unscoped_dep_keeps_own_scope_drops_foreign_locals(tmp_path):
    # v15 (Cut A): even for an UNSCOPED dep, a foreign function's PROVEN local
    # writes are excluded (funcA's `i` can never be what funcB's read sees), while
    # the read's own scope's sites survive via the span carve-out.
    _write_fixture(tmp_path)
    ctx = _ctx(tmp_path, {"t": _CFG_T})
    dep = _dep(line=12)                            # read inside funcB, no local_scope
    setters = _gather_candidate_setters(dep, ctx, _candidate_files_by_target(dep, [], ctx))
    assert sorted(s.line for s in setters) == [10, 11]


def test_unproven_global_keeps_all_non_local_sites(tmp_path):
    # The explicit no-regression case for Cut A: a dep with NO proving declaration
    # anywhere (file-scope `g`) keeps every candidate site that is not itself a
    # proven foreign local — nothing unproven is ever dropped.
    (tmp_path / "t3.cpp").write_text(
        "int g = 0;\n"                             # file-scope decl: never proves
        "void fa() {\n    g = 1;\n}\n"             # bare write to the GLOBAL: kept
        "void fb() {\n    g = 2;\n}\n"             # bare write to the GLOBAL: kept
    )
    ctx = _NodeCtx(
        blueprint_dir=tmp_path, asm_dir=tmp_path, chain_set={"t3"},
        upstream_bounds={}, route_engine=None, chain_hops=None, max_depth=2,
        const_resolver=None, max_offchain_files=100, asm_max_levels=16,
        max_descendants=50, midx=_Idx(), memb=None, reach_union=None,
    )
    ctx.cfg_cache.update({"t3": _cfg(("fa", [3]), ("fb", [6]))})
    dep = _dep(name="g", file="t3.cpp", line=6)
    cbt = [("g", "cpp", None, ["t3"])]
    setters = _gather_candidate_setters(dep, ctx, cbt)
    # line 1 is the global's own file-scope initializer — a genuine setter, kept
    assert sorted(s.line for s in setters) == [1, 3, 6]


# --------------------------------------------------------------------------- #
# end-to-end: two same-named locals → two nodes, each with its own setters
# --------------------------------------------------------------------------- #
def _setup_trace(monkeypatch, tmp_path):
    import vbt.depvars.recurse as R
    _write_fixture(tmp_path)

    class _TIdx:
        def files_for(self, name, language): return {"t"}
        def files_defining_function(self, fn): return set()
        def sites_for(self, *a, **k): return []

    monkeypatch.setattr(R, "get_modifier_index", lambda *a, **k: _TIdx())
    monkeypatch.setattr(R, "resolve_aliases",
                        lambda name, lang, asm_dir: type("A", (), {"aliases": []})())
    monkeypatch.setattr(R, "run_cfg_extract",
                        lambda path, *a, **k: _CFG_T if Path(path).stem == "t" else [])
    monkeypatch.setattr(R, "_cpp_fn_block", lambda *a, **k: None)
    monkeypatch.setattr(R, "_dep_chunk", lambda *a, **k: None)


def test_trace_dependents_splits_same_named_locals(monkeypatch, tmp_path):
    from vbt.depvars.recurse import trace_dependents
    _setup_trace(monkeypatch, tmp_path)
    seeds = [("root", _dep(line=6)), ("root", _dep(line=12))]
    out = trace_dependents(seeds, ["t"], blueprint_dir=tmp_path, asm_dir=tmp_path, store=None)
    i_nodes = [e["dependentVariable"] for e in out if e["dependentVariable"]["name"] == "i"]
    assert len(i_nodes) == 2, "same-named locals in different functions must NOT merge"
    by_fn = {n["localScope"]["function"]: n for n in i_nodes}
    assert set(by_fn) == {"funcA", "funcB"}
    for fn, want in (("funcA", {4, 5}), ("funcB", {10, 11})):
        got = {s["location"]["startLine"] for s in by_fn[fn]["setters"] if not s.get("notSet")}
        assert got == want, f"{fn} node carries foreign setters: {got}"
        assert by_fn[fn]["localScope"] == {"file": "t", "function": fn}


def test_trace_without_cfg_merges_but_span_carveout_still_protects(monkeypatch, tmp_path):
    """No CFG → the read gate can't fire → one merged (unscoped) node. But the v15
    span carve-out is CFG-FREE: the read's own scope's sites survive while the
    other function's proven locals are still (soundly) excluded — the dep's own
    setters are never orphaned by a missing CFG."""
    import vbt.depvars.recurse as R
    from vbt.depvars.recurse import trace_dependents
    _setup_trace(monkeypatch, tmp_path)
    monkeypatch.setattr(R, "run_cfg_extract", lambda *a, **k: [])   # kill the CFG source
    seeds = [("root", _dep(line=6)), ("root", _dep(line=12))]
    out = trace_dependents(seeds, ["t"], blueprint_dir=tmp_path, asm_dir=tmp_path, store=None)
    i_nodes = [e["dependentVariable"] for e in out if e["dependentVariable"]["name"] == "i"]
    assert len(i_nodes) == 1
    assert "localScope" not in i_nodes[0]
    lines = {s["location"]["startLine"] for s in i_nodes[0]["setters"] if not s.get("notSet")}
    assert lines == {4, 5}, f"first read's own-scope sites must survive without CFG: {lines}"
