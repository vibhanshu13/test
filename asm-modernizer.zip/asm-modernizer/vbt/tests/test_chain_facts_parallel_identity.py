"""Byte-identity guard for the PARALLEL chain_facts build (vbt/precompute/chain_facts_db.py).

The parallel phase-A/phase-B fan-out MUST produce a gz blob identical to the serial (1-worker)
build, regardless of worker count or completion order — the determinism contract. We build the
same job serially and with 2 workers and assert the gzipped ``chain_facts`` blob is identical.

Auto-discovers a chain_facts-ready job; skips when none (or no usable source dir) is present.
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from vbt.tests._lca_corpus import find_chain_facts_job

_JOB = find_chain_facts_job()
_db = pytest.mark.skipif(_JOB is None, reason="no chain_facts-ready job in jobs/")


def _resolve_src_with_source(src: Path) -> Path:
    """The discovered asm_dir, or its single child dir that actually holds the source files
    (some jobs store source one level down, e.g. ``.../asm 7_version_0/asm 5``)."""
    if list(src.glob("*.cpp")) or list(src.glob("*.asm")):
        return src
    try:
        cands = [d for d in src.iterdir()
                 if d.is_dir() and (list(d.glob("*.cpp")) or list(d.glob("*.asm")))]
    except OSError:
        cands = []
    return cands[0] if len(cands) == 1 else src


def _build_blob(job, bp, src, workers: int) -> bytes:
    from vbt.precompute import db_artifacts as DA
    from vbt.precompute.chain_facts_db import CHAIN_FACTS_ARTIFACT, build_and_store_chain_facts
    prev = os.environ.get("VBT_WORKERS")
    os.environ["VBT_WORKERS"] = str(workers)
    try:
        build_and_store_chain_facts(job, bp, src, progress=False, edge_timeout=4.0)
        blob = DA.read_blob(job, CHAIN_FACTS_ARTIFACT)
    finally:
        if prev is None:
            os.environ.pop("VBT_WORKERS", None)
        else:
            os.environ["VBT_WORKERS"] = prev
    assert blob is not None
    return blob


@_db
def test_parallel_build_byte_identical_to_serial():
    job, bp, src = _JOB
    src = _resolve_src_with_source(src)
    if not (list(src.glob("*.cpp")) or list(src.glob("*.asm"))):
        pytest.skip("no source files reachable for this job")

    import gzip
    serial = _build_blob(job, bp, src, workers=1)
    parallel = _build_blob(job, bp, src, workers=2)

    # Compare decompressed JSON (the order-sensitive content contract); gz bytes are deterministic
    # too (mtime=0) but JSON comparison gives a clearer diff on failure.
    assert gzip.decompress(serial) == gzip.decompress(parallel), \
        "parallel chain_facts build is NOT byte-identical to serial"
