"""Precompute tests for the chains-precompute step (vbt/precompute/chain_facts_db.py).

  * chain_facts PARITY (#14): ``assemble_events_from_chain_facts`` + ``decide_feasibility`` ==
    the LIVE ``chain_feasibility`` (event-list + verdict) for the softCardValue chains — the proof
    that the DB-only prune equals the source-reading prune BY CONSTRUCTION.
  * asm_setters_full COMPLETENESS (#15): every setter the LIVE finder returns for a queryable
    (stem, var) appears in the DB artifact (so "var absent from an OK stem ⇒ no setter" is sound),
    plus the per-stem universe closure (every modifier-index var is queryable).
  * coverage STATUS correctness: an ``ok`` stem has a blob; ``empty``/``failed`` are split.

Auto-discovered chain_facts job; skip if none.
"""
from __future__ import annotations

import pytest

from vbt.tests._lca_corpus import find_chain_facts_job

_JOB = find_chain_facts_job()
_db = pytest.mark.skipif(_JOB is None, reason="no chain_facts-ready job in jobs/")


@_db
def test_chain_facts_parity_with_live_chain_feasibility():
    job, bp, src = _JOB
    from vbt.lca_trace import trace_variable_to_lca_chains
    from vbt.precompute import db_artifacts as DA
    from vbt.precompute.chain_facts_db import (
        set_chain_facts_job, get_chain_facts, assemble_events_from_chain_facts, chain_facts_verdict)
    from vbt.tests._chain_feasibility_oracle import chain_feasibility_events, event_multiset

    # discover the real chains (DB-only).
    pr = trace_variable_to_lca_chains(job, "softCardValue", "cpp", blueprint_dir=str(bp),
                                      asm_dir=str(src), prune=True, debug=True)
    raw = pr["_debug"]["rawChains"]
    assert raw, "no chains to check parity on"

    # DB-only verdicts/events.
    DA.set_load_only(True); set_chain_facts_job(job)
    facts = get_chain_facts()
    assert facts is not None
    db = [(chain_facts_verdict(ch, facts).status, assemble_events_from_chain_facts(ch, facts)[0])
          for ch in raw]

    # live oracle (reads source) — disarm DB-only setter routing first.
    DA.set_load_only(False)
    from vbt.setters.asm_setters import set_asm_setter_map_job
    from vbt.setters.cpp_setters import set_cpp_setter_map_job, set_cpp_file_writes_job
    from vbt.precompute.fn_facts_db import set_fn_facts_job
    for f in (set_asm_setter_map_job, set_cpp_setter_map_job, set_cpp_file_writes_job, set_fn_facts_job):
        f(None)
    from vbt.reach.route import RouteEngine
    from vbt.precompute.call_graph import ensure_call_graph
    gf = bp / "file_call_graph.json"
    ensure_call_graph(bp, src, out_path=gf)
    route = RouteEngine(bp, gf, src)

    cfg_cache = {}
    verdict_mismatch = []
    event_mismatch = 0
    for i, ch in enumerate(raw):
        oev, overd = chain_feasibility_events(ch, None, route, bp, src, cfg_cache=cfg_cache)
        db_status, db_ev = db[i]
        if db_status != overd.status:
            verdict_mismatch.append((i, db_status, overd.status))
        if event_multiset(db_ev) != event_multiset(oev):
            event_mismatch += 1
    assert not verdict_mismatch, f"verdict parity failed: {verdict_mismatch}"
    # event-list parity holds with complete (reverse-index) coverage; a couple may differ only by a
    # timed-out ASM edge (sound — same verdict). Require the vast majority to match exactly.
    assert event_mismatch <= 1, f"too many event-list mismatches: {event_mismatch}/{len(raw)}"


@_db
def test_asm_setters_full_completeness_and_closure():
    """Every queryable (stem, var) the LIVE finder produces a setter for is reproduced by the DB
    artifact (#15), and every modifier-index var for a stem is queryable (universe closure)."""
    job, bp, src = _JOB
    from dataclasses import asdict
    from vbt.precompute import db_artifacts as DA
    from vbt.precompute.modifier_index import get_modifier_index
    from vbt.precompute.chain_facts_db import (
        set_asm_setters_full_job, get_asm_setters_full, load_coverage,
        ASM_SETTERS_FULL_COVERAGE_ARTIFACT, OK, EMPTY)
    from vbt.setters.asm_setters import find_asm_setters_in_file, set_asm_setter_map_job

    midx = get_modifier_index(bp, src)
    stem_vars = {}
    for var, files in midx.asm.items():
        for stem in files:
            stem_vars.setdefault(stem, set()).add(var)
    if not stem_vars:
        pytest.skip("no ASM modifier vars in this corpus")

    coverage = load_coverage(job, ASM_SETTERS_FULL_COVERAGE_ARTIFACT) or {}

    # live finder: disable the precomputed maps so it SCANS.
    DA.set_load_only(False); set_asm_setter_map_job(None)
    live = {}
    for stem, vars_ in sorted(stem_vars.items()):
        for var in sorted(vars_):
            sites = find_asm_setters_in_file(var, stem, bp, src)
            if sites:
                live[(stem, var)] = [tuple(sorted(asdict(s).items())) for s in sites]

    # DB-only: every live (stem,var) setter set must be reproduced; the covered stem must be OK.
    DA.set_load_only(True); set_asm_setters_full_job(job)
    missing = []
    for (stem, var), live_key in live.items():
        assert coverage.get(stem) in (OK, EMPTY), f"{stem} coverage={coverage.get(stem)} (expected ok)"
        db_sites = get_asm_setters_full(stem, var) or []
        db_key = [tuple(sorted(asdict(s).items())) for s in db_sites]
        if db_key != live_key:
            missing.append((stem, var, len(live_key), len(db_key)))
    assert not missing, f"asm_setters_full missing/mismatched setters (UNSOUND): {missing[:8]}"


@_db
def test_coverage_status_ok_stems_have_blobs():
    job, _bp, _src = _JOB
    from vbt.precompute import db_artifacts as DA
    from vbt.precompute.chain_facts_db import (
        load_coverage, ASM_SETTERS_FULL_COVERAGE_ARTIFACT, CPP_SETTER_MAP_COVERAGE_ARTIFACT,
        ASM_SETTERS_FULL_ARTIFACT, OK, EMPTY, FAILED)
    from vbt.precompute.cpp_setter_map_db import CPP_SETTER_MAP_ARTIFACT

    DA.set_load_only(True)
    asm_cov = load_coverage(job, ASM_SETTERS_FULL_COVERAGE_ARTIFACT) or {}
    cpp_cov = load_coverage(job, CPP_SETTER_MAP_COVERAGE_ARTIFACT) or {}
    assert asm_cov and cpp_cov, "coverage artifacts must be populated"
    assert set(asm_cov.values()) <= {OK, EMPTY, FAILED}
    assert set(cpp_cov.values()) <= {OK, EMPTY, FAILED}
    # an OK asm stem must have a setter blob; an OK cpp stem must have its cpp_setter_map blob.
    for stem, st in asm_cov.items():
        if st == OK:
            assert DA.read_blob(job, f"{ASM_SETTERS_FULL_ARTIFACT}:{stem}") is not None
    for stem, st in cpp_cov.items():
        if st == OK:
            assert DA.read_blob(job, f"{CPP_SETTER_MAP_ARTIFACT}:{stem}") is not None
