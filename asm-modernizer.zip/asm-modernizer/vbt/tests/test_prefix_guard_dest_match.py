"""Issue 2 — C++ prefix hops must not lose conditions on FILE-ONLY destination hops.

The bug lived in ``_prefix_guards`` (vbt/engine.py): its destination predicate
``(not e_h.function) or _fn_name_matches(t, e_h.function)`` matched EVERY call edge in
the caller file whenever the destination chain hop carried no function (the common
LCA-discovered file-only hop). So an unrelated *unconditional* utility call (``glob``,
``ecbptr``, ``callCoreCarver``) was admitted as a candidate ``c_h→e_h`` descend site;
the B6 "any unconditional site ⇒ unconditional transition" rule then fired on that
unrelated call and DROPPED the real prefix guards (e.g. the ``dw730000→dw710000``
carverActive / plasticAuthOnlyArea / lstknpoa gates).

The fix routes every candidate descend site through ``_cpp_call_targets_hop``, which
only accepts a call that actually ENTERS the destination hop (its own C++ functions, or
— for ASM destinations — an entry name it exports). Missing destination CFG / names
degrade to "no precise site" (False), never to "every call matches".

These tests use a fake RouteEngine + stubbed condition collector, so they need no
corpus and run anywhere:

    env/bin/python3 -m pytest vbt/tests/test_prefix_guard_dest_match.py -q
"""
from pathlib import Path

from vbt.engine import Hop, _cpp_call_targets_hop, _prefix_guards, _mk_cond


class _FakeRoute:
    """Minimal RouteEngine stand-in exposing only the two methods the prefix-guard
    C++ path and ``_cpp_call_targets_hop`` touch."""

    def __init__(self, edges=None, name_to_stems_map=None):
        self._edges = list(edges or [])
        self._n2s = dict(name_to_stems_map or {})

    def cpp_call_edges(self, stem):           # (caller_fn, callee_fn, line)
        return list(self._edges)

    def name_to_stems(self):                  # UPPER entry name -> {owning stems}
        return dict(self._n2s)


# --------------------------------------------------------------------------- #
# Helper-level: _cpp_call_targets_hop
# --------------------------------------------------------------------------- #
def test_helper_explicit_function_unchanged():
    route = _FakeRoute()
    e_h = Hop("dest", "cpp", "realEntry")
    # rule 1 — explicit function keeps exact + qualified-boundary matching, nothing else.
    assert _cpp_call_targets_hop(route, {}, Path("."), "realEntry", e_h)
    assert _cpp_call_targets_hop(route, {}, Path("."), "Ns::realEntry", e_h)
    assert not _cpp_call_targets_hop(route, {}, Path("."), "glob", e_h)


def test_helper_cpp_file_only_matches_only_dest_functions():
    route = _FakeRoute()
    # destination CFG pre-seeded (no disk read) exposes DestNs::realEntry
    cfg_cache = {"dest": [{"function": "DestNs::realEntry"}]}
    e_h = Hop("dest", "cpp", None)
    assert _cpp_call_targets_hop(route, cfg_cache, Path("."), "DestNs::realEntry", e_h)
    # the Issue-2 regression: unrelated utility calls are NOT descend sites
    assert not _cpp_call_targets_hop(route, cfg_cache, Path("."), "glob", e_h)
    assert not _cpp_call_targets_hop(route, cfg_cache, Path("."), "ecbptr", e_h)
    assert not _cpp_call_targets_hop(route, cfg_cache, Path("."), "callCoreCarver", e_h)


def test_helper_cpp_inverse_qualification_matches():
    # call target is the BARE name, dest CFG function is QUALIFIED → must still match
    route = _FakeRoute()
    cfg_cache = {"dest": [{"function": "DestNs::realEntry"}]}
    e_h = Hop("dest", "cpp", None)
    assert _cpp_call_targets_hop(route, cfg_cache, Path("."), "realEntry", e_h)


def test_helper_cpp_missing_cfg_degrades_to_false():
    # no destination CFG functions known → False (NOT "everything matches")
    route = _FakeRoute()
    e_h = Hop("dest", "cpp", None)
    assert not _cpp_call_targets_hop(route, {"dest": []}, Path("."), "anything", e_h)


def test_helper_asm_file_only_ownership():
    route = _FakeRoute(name_to_stems_map={"NB81": {"nextasm"}})
    assert _cpp_call_targets_hop(route, {}, Path("."), "NB81", Hop("nextasm", "asm", None))
    # owned by a DIFFERENT stem ⇒ must not match this ASM destination (under-match guard)
    assert not _cpp_call_targets_hop(route, {}, Path("."), "NB81", Hop("otherasm", "asm", None))


def test_helper_asm_direct_stem_fallback():
    route = _FakeRoute(name_to_stems_map={})   # name_to_stems empty
    e_h = Hop("nextasm", "asm", None)
    assert _cpp_call_targets_hop(route, {}, Path("."), "nextasm", e_h)   # direct stem name
    assert _cpp_call_targets_hop(route, {}, Path("."), "NEXTASM", e_h)   # case-insensitive
    assert not _cpp_call_targets_hop(route, {}, Path("."), "somethingelse", e_h)


def test_helper_empty_target_is_false():
    assert not _cpp_call_targets_hop(_FakeRoute(), {}, Path("."), "", Hop("dest", "cpp", None))


# --------------------------------------------------------------------------- #
# End-to-end through _prefix_guards (the behaviour the helper protects).
# Each of these FAILS under the old broad predicate and PASSES with the fix.
# --------------------------------------------------------------------------- #
def _patch_collectors(monkeypatch, conds_by_line):
    """Stub the engine's C++ condition collector + code-block registrar so
    _prefix_guards runs with no disk/clang/codeBlocks I/O."""
    import vbt.engine as E

    def fake_collect(cpp_path, ln, fn, functions=None):
        return list(conds_by_line.get(ln, []))

    monkeypatch.setattr(E, "collect_cpp_conditions", fake_collect)
    monkeypatch.setattr(E, "_cpp_fn_block", lambda *a, **k: None)


def test_prefix_guards_drops_unrelated_unconditional_call(monkeypatch):
    """Crux of Issue 2: caller has an unrelated UNCONDITIONAL ``glob`` at line 10 and the
    real descend ``DestNs::realEntry`` at line 20 carrying a guard. The destination hop has
    NO function. Only line 20 must be considered and its guard emitted."""
    route = _FakeRoute(edges=[("Entry", "glob", 10),
                              ("Entry", "DestNs::realEntry", 20)])
    cfg_cache = {"caller": [{"function": "Entry"}],
                 "dest": [{"function": "DestNs::realEntry"}]}
    guard = _mk_cond("walletToken->lstknpoa == 'Y'", "caller.cpp", 20)
    _patch_collectors(monkeypatch, {20: [guard]})   # line 10 (glob) unconditional

    prefix = [Hop("caller", "cpp", "Entry"), Hop("dest", "cpp", None)]
    out, bounds = _prefix_guards(prefix, route, cfg_cache, Path("."), None, Path("."), {})

    texts = [c.condition for c, _via, _blk in out]
    assert texts == ["walletToken->lstknpoa == 'Y'"], texts
    assert bounds.get("caller") == 20            # descend bound = the real site, not glob@10


def test_prefix_guards_two_real_descend_sites_preserve_or(monkeypatch):
    """B6 preserved after narrowing: two LEGITIMATE descend sites (both enter dest) with
    different guards → OR of per-site guards. The unrelated ``glob`` is still excluded, so
    the transition is not falsely unconditional."""
    route = _FakeRoute(edges=[("Entry", "DestNs::realEntry", 20),
                              ("Entry", "DestNs::altEntry", 40),
                              ("Entry", "glob", 10)])
    cfg_cache = {"caller": [{"function": "Entry"}],
                 "dest": [{"function": "DestNs::realEntry"},
                          {"function": "DestNs::altEntry"}]}
    g20 = _mk_cond("a == 1", "caller.cpp", 20)
    g40 = _mk_cond("b == 2", "caller.cpp", 40)
    _patch_collectors(monkeypatch, {20: [g20], 40: [g40]})

    prefix = [Hop("caller", "cpp", "Entry"), Hop("dest", "cpp", None)]
    out, bounds = _prefix_guards(prefix, route, cfg_cache, Path("."), None, Path("."), {})

    texts = [c.condition for c, _via, _blk in out]
    assert texts == ["a == 1 || b == 2"], texts
    assert bounds.get("caller") == 40            # latest legitimate descend site (permissive)


def test_prefix_guards_explicit_function_path_unaffected(monkeypatch):
    """Acceptance #2: explicit-function destination hops behave exactly as before — only
    the call matching ``e_h.function`` is a descend site, its guard is emitted."""
    route = _FakeRoute(edges=[("Entry", "glob", 10),
                              ("Entry", "DestNs::realEntry", 20)])
    cfg_cache = {"caller": [{"function": "Entry"}]}   # dest CFG not even needed (explicit fn)
    guard = _mk_cond("a == 1", "caller.cpp", 20)
    _patch_collectors(monkeypatch, {20: [guard]})

    prefix = [Hop("caller", "cpp", "Entry"), Hop("dest", "cpp", "realEntry")]
    out, bounds = _prefix_guards(prefix, route, cfg_cache, Path("."), None, Path("."), {})

    texts = [c.condition for c, _via, _blk in out]
    assert texts == ["a == 1"], texts
    assert bounds.get("caller") == 20
