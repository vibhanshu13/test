"""Parity + correctness tests for the multi-chain coordinator (vbt_multi_chain_trace_plan).

Two tiers (mirror test_lca_trace.py):
  * pure-logic (no DB): hop translation, the codeBlocks consolidation invariant, the budget cap.
  * DB-backed (auto-discovered chain_facts job; skip if none): the THREE-LEGGED parity harness of §4
      1. Traversal parity  — baseline (no sharing) vs optimized (shared caches), BOTH cache-OFF,
         route-cache cleared so each leg computes routes FRESH → must be canonically identical.
      2. Cache parity      — cache-ON run twice (optimized populates the whole-trace cache, a later
         standalone run HITS it) → identical structures.
      3. Production regression — the coordinator's consolidated per-chain element (codeBlocks stripped
         to root) vs today's standalone trace_root_variable, after extracting {rootVariable,
         dependentVariables} → identical.

The DB-backed legs run on a small chain count (CAP) so the suite stays fast; the full-corpus run is
exercised by the live validation script.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import pytest

from vbt.tests._lca_corpus import find_chain_facts_job


# =========================================================================== #
# canonical comparison
# =========================================================================== #
def canon(obj: Any) -> str:
    """Canonical JSON string: recursive key-sort, stable, so two dicts that differ only in key
    ORDER compare equal (the plan's 'canonical JSON object comparison')."""
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, default=str)


# =========================================================================== #
# pure-logic: hop translation (file_type inferred by KEY PRESENCE, not truthiness)
# =========================================================================== #
def test_chain_to_hops_infers_cpp_by_key_presence():
    from vbt.engine import Hop
    from api.tasks.vbt_lca_trace_task import _chain_to_hops

    chain = [
        {"file": "aa71"},                              # ASM: no "function" key
        {"file": "dw710000", "function": "DW73"},      # C++: key present, value set
        {"file": "dw710600", "function": None},        # C++: key present, value None
    ]
    hops = _chain_to_hops(chain, Hop)
    assert [(h.stem, h.file_type, h.function) for h in hops] == [
        ("aa71", "asm", None),
        ("dw710000", "cpp", "DW73"),
        ("dw710600", "cpp", None),
    ]


def test_chain_to_hops_tail_last():
    """The discovered chain is root→LCA; the LCA (tail used by trace_root_variable) stays LAST."""
    from vbt.engine import Hop
    from api.tasks.vbt_lca_trace_task import _chain_to_hops

    hops = _chain_to_hops([{"file": "lu82"}, {"file": "da76"}, {"file": "da78"}], Hop)
    assert hops[-1].stem == "da78"


# =========================================================================== #
# pure-logic: codeBlocks consolidation invariant (the coordinator's merge/strip)
# =========================================================================== #
def _consolidate(traces: List[Dict[str, Any]]):
    """Reference implementation of the coordinator's consolidation: strip each trace's local
    codeBlocks, merge into a root dict deduped by blockId, return (elements, root_blocks)."""
    root: Dict[str, Any] = {}
    elements: List[Dict[str, Any]] = []
    for i, out in enumerate(traces):
        out = dict(out)
        local = out.pop("codeBlocks", None) or {}
        for bid, blk in local.items():
            root.setdefault(bid, blk)
        el = {"chain_index": i, "files": ["x"]}
        el.update(out)
        elements.append(el)
    return elements, root


def test_consolidation_strips_local_and_dedups_root():
    traces = [
        {"rootVariable": {"name": "v"}, "codeBlocks": {"b1": {"code": "A"}, "b2": {"code": "B"}}},
        {"rootVariable": {"name": "v"}, "codeBlocks": {"b2": {"code": "B"}, "b3": {"code": "C"}}},
    ]
    elements, root = _consolidate(traces)
    assert all("codeBlocks" not in e for e in elements)          # stripped from every element
    assert set(root) == {"b1", "b2", "b3"}                       # merged + deduped
    assert root["b2"]["code"] == "B"                             # first-wins, structural IDs unique


# =========================================================================== #
# DB-backed parity harness
# =========================================================================== #
CAP = 5                          # chains traced per leg (keep the suite fast; live script does all)
VARS = [("LG1OSI", "asm"), ("softCardValue", "cpp")]


def _setup():
    job = find_chain_facts_job()
    if job is None:
        pytest.skip("no chain_facts-ready job under jobs/*/index.db")
    kb, bp, src = job
    gf = bp / "file_call_graph.json"
    return kb, bp, src, gf


def _discover(kb, bp, src, gf, variable, language) -> List[List[Dict[str, Any]]]:
    from vbt.lca_trace import trace_variable_to_lca_chains
    r = trace_variable_to_lca_chains(kb, variable, language,
                                     blueprint_dir=str(bp), asm_dir=str(src), graph_file=str(gf))
    return list(r.get("chains", []) or [])


def _clear_route_cache(kb: str) -> None:
    from vbt.precompute import db_artifacts as DA
    from vbt.precompute.route_cache_db import ARTIFACT
    try:
        DA.clear_blobs_prefix(kb, ARTIFACT)
    except Exception:
        pass


def _baseline_traces(kb, bp, src, gf, variable, language, chains, *, bypass: bool):
    """Leg 'no sharing': each chain gets its OWN RouteEngine + DB preloads (the standalone path)."""
    from vbt.engine import Hop, trace_root_variable
    from api.tasks.vbt_lca_trace_task import _chain_to_hops
    outs = []
    for chain in chains:
        hops = _chain_to_hops(chain, Hop)
        outs.append(trace_root_variable(
            variable, language, hops,
            blueprint_dir=bp, asm_dir=src, graph_file=gf, job_id=kb,
            bypass_trace_cache=bypass))
    return outs


def _optimized_traces(kb, bp, src, gf, variable, language, chains, *, bypass: bool,
                      preload_routes: bool):
    """Leg 'shared caches': one hoisted RouteEngine + caches threaded across the chain loop."""
    from vbt.engine import Hop, trace_root_variable
    from api.tasks.vbt_lca_trace_task import _chain_to_hops
    from vbt.reach.route import RouteEngine
    from vbt.precompute.graph_db import preload_route_graph, preload_cpp_call_edges
    from vbt.precompute.route_cache_db import preload_route_cache, persist_route_cache
    from vbt.precompute.resolvers_db import preload_resolvers

    route = RouteEngine(bp, gf, src, max_routes=200, max_len=16, job_id=kb)
    preload_route_graph(route, kb, bp, gf)
    preload_cpp_call_edges(route, kb, bp, src)
    if preload_routes:
        preload_route_cache(route, kb)
    preload_resolvers(kb, bp, src)
    shared_src: Dict[str, Any] = {}
    cfg_cache: Dict[str, Any] = {}
    asm_bp_cache: Dict[str, Any] = {}
    outs = []
    for chain in chains:
        hops = _chain_to_hops(chain, Hop)
        outs.append(trace_root_variable(
            variable, language, hops,
            blueprint_dir=bp, asm_dir=src, graph_file=gf, job_id=kb,
            _shared_route=route, _shared_src=shared_src,
            _shared_cfg_cache=cfg_cache, _shared_asm_bp_cache=asm_bp_cache,
            bypass_trace_cache=bypass))
    if not bypass:
        persist_route_cache(route, kb)
    return outs


@pytest.mark.parametrize("variable,language", VARS)
def test_leg1_traversal_parity_cache_off(variable, language):
    """§4.1 — baseline vs optimized, BOTH cache-off, routes computed fresh → identical."""
    kb, bp, src, gf = _setup()
    chains = _discover(kb, bp, src, gf, variable, language)[:CAP]
    if not chains:
        pytest.skip(f"no chains discovered for {variable}/{language}")
    _clear_route_cache(kb)
    base = _baseline_traces(kb, bp, src, gf, variable, language, chains, bypass=True)
    _clear_route_cache(kb)
    opt = _optimized_traces(kb, bp, src, gf, variable, language, chains,
                            bypass=True, preload_routes=False)   # fresh DFS in BOTH legs
    assert len(base) == len(opt) == len(chains)
    for i, (b, o) in enumerate(zip(base, opt)):
        assert canon(b) == canon(o), f"chain {i} differs between baseline and optimized (cache-off)"


@pytest.mark.parametrize("variable,language", VARS)
def test_leg2_cache_parity_cache_on(variable, language):
    """§4.2 — cache-ON: optimized populates the whole-trace cache, a later standalone HITS it →
    identical structures (and identical to the cache-off result)."""
    kb, bp, src, gf = _setup()
    chains = _discover(kb, bp, src, gf, variable, language)[:CAP]
    if not chains:
        pytest.skip(f"no chains discovered for {variable}/{language}")
    # optimized cache-ON (stores results), then baseline cache-ON (must hit + match).
    opt_on = _optimized_traces(kb, bp, src, gf, variable, language, chains,
                               bypass=False, preload_routes=True)
    base_on = _baseline_traces(kb, bp, src, gf, variable, language, chains, bypass=False)
    for i, (o, b) in enumerate(zip(opt_on, base_on)):
        assert canon(o) == canon(b), f"chain {i} cache-on optimized vs baseline differ"
    # and the cached result equals a fresh (cache-off) compute.
    _clear_route_cache(kb)
    fresh = _optimized_traces(kb, bp, src, gf, variable, language, chains,
                              bypass=True, preload_routes=False)
    for i, (o, f) in enumerate(zip(opt_on, fresh)):
        assert canon(o) == canon(f), f"chain {i} cached vs fresh differ"


@pytest.mark.parametrize("variable,language", VARS)
def test_leg4_dep_node_cache_parity(variable, language):
    """Cross-chain dep-var node cache (DepNodeCache): a chain loop sharing ONE node cache
    must produce canonically identical per-chain outputs to the standalone no-cache path —
    the per-node chain-scope revalidation, not blind reuse, is what makes chains 2..N cheap.
    Both legs run bypass_trace_cache=True so the whole-trace cache can't mask a difference."""
    from vbt.depvars.recurse import DepNodeCache
    from vbt.engine import Hop, trace_root_variable
    from api.tasks.vbt_lca_trace_task import _chain_to_hops

    kb, bp, src, gf = _setup()
    chains = _discover(kb, bp, src, gf, variable, language)[:CAP]
    if not chains:
        pytest.skip(f"no chains discovered for {variable}/{language}")
    _clear_route_cache(kb)
    base = _baseline_traces(kb, bp, src, gf, variable, language, chains, bypass=True)
    _clear_route_cache(kb)
    node_cache = DepNodeCache()
    cached = []
    for chain in chains:
        hops = _chain_to_hops(chain, Hop)
        cached.append(trace_root_variable(
            variable, language, hops,
            blueprint_dir=bp, asm_dir=src, graph_file=gf, job_id=kb,
            _shared_dep_node_cache=node_cache, bypass_trace_cache=True))
    for i, (b, c) in enumerate(zip(base, cached)):
        assert canon(b) == canon(c), \
            f"chain {i} differs with the shared dep node cache ({node_cache.stats()})"
    if len(chains) > 1 and node_cache.entries:
        assert node_cache.hits + node_cache.rejected > 0, \
            f"cache never consulted across chains ({node_cache.stats()})"


@pytest.mark.parametrize("variable,language", VARS)
def test_leg3_production_regression(variable, language):
    """§4.3 — the coordinator's consolidated per-chain element vs today's standalone production trace,
    normalized to {rootVariable, dependentVariables} (strip codeBlocks + wrapper keys)."""
    from api.tasks.vbt_lca_trace_task import run_all_chains_trace

    kb, bp, src, gf = _setup()
    all_chains = _discover(kb, bp, src, gf, variable, language)
    chains = all_chains[:CAP]
    if not chains:
        pytest.skip(f"no chains discovered for {variable}/{language}")

    # standalone production: per-chain trace_root_variable WITH caching (today's behaviour).
    standalone = _baseline_traces(kb, bp, src, gf, variable, language, chains, bypass=False)

    # coordinator: run with the cap so it traces exactly these chains, read the consolidated payload.
    opts = {
        "kb_id": kb, "variable": variable, "language": language,
        "blueprint_dir": str(bp), "asm_dir": str(src),
        "trace_options": {"max_chains_to_trace": CAP},
    }
    job_out = f"test-allchains-regress-{language}"
    res = run_all_chains_trace(job_out, opts, ws=None)
    payload = json.loads((Path("jobs") / job_out / "output" / "vbt_all_chains_trace.json").read_text())

    assert res["traced_chains_count"] == len(chains)
    assert payload["lca_chains_discovered"] == len(all_chains)
    assert len(payload["chains"]) == len(chains)
    # codeBlocks consolidated to root; never left on a chain element.
    assert isinstance(payload["codeBlocks"], dict) and payload["codeBlocks"]
    assert all("codeBlocks" not in c for c in payload["chains"])

    def _inner(d: Dict[str, Any]) -> Dict[str, Any]:
        return {"rootVariable": d.get("rootVariable"),
                "dependentVariables": d.get("dependentVariables")}

    for i, (coord_el, std) in enumerate(zip(payload["chains"], standalone)):
        assert canon(_inner(coord_el)) == canon(_inner(std)), \
            f"chain {i}: coordinator element vs standalone production trace differ"

    # every blockId referenced by the chains must exist in the consolidated root codeBlocks
    # (the consolidation didn't drop a block a condition/setter points at).
    referenced = set()
    for std in standalone:
        referenced.update((std.get("codeBlocks") or {}).keys())
    missing = referenced - set(payload["codeBlocks"].keys())
    assert not missing, f"{len(missing)} referenced blockIds missing from root codeBlocks: {sorted(missing)[:5]}"


@pytest.mark.parametrize("variable,language", VARS)
def test_split_chains_mode(variable, language):
    """split_chains=True writes one fully self-contained JSON per chain (each with its OWN
    codeBlocks) + index.json. Per-chain analysis must equal the consolidated mode's, and the UNION
    of every per-chain codeBlocks must equal the consolidated root codeBlocks (nothing lost)."""
    from api.tasks.vbt_lca_trace_task import run_all_chains_trace

    kb, bp, src, gf = _setup()
    chains = _discover(kb, bp, src, gf, variable, language)
    if not chains:
        pytest.skip(f"no chains discovered for {variable}/{language}")
    cap = min(CAP, len(chains))
    opts = {"kb_id": kb, "variable": variable, "language": language,
            "blueprint_dir": str(bp), "asm_dir": str(src),
            "trace_options": {"max_chains_to_trace": cap}}

    # consolidated reference
    cons_job = f"test-split-cons-{language}"
    run_all_chains_trace(cons_job, opts, ws=None)
    cons = json.loads((Path("jobs") / cons_job / "output" / "vbt_all_chains_trace.json").read_text())

    # split mode
    split_job = f"test-split-{language}"
    res = run_all_chains_trace(split_job, {**opts, "split_chains": True}, ws=None)
    sd = Path("jobs") / split_job / "output" / "vbt_all_chains_trace"
    idx = json.loads((sd / "index.json").read_text())

    assert res["split"] is True
    assert res.get("output_dir", "").endswith("vbt_all_chains_trace")
    assert idx["split"] is True
    assert idx["traced_chains_count"] == cap
    files = sorted(sd.glob("chain_*.json"))
    assert len(files) == cap == len(idx["chains"])

    union_blocks: Dict[str, Any] = {}
    for f in files:
        d = json.loads(f.read_text())
        ci = d["chain_index"]
        # self-contained shape
        assert {"variable", "language", "chain_index", "files", "rootVariable",
                "dependentVariables", "codeBlocks"} <= set(d)
        assert isinstance(d["codeBlocks"], dict)
        # per-chain analysis identical to consolidated element
        cc = cons["chains"][ci]
        assert canon(d["rootVariable"]) == canon(cc["rootVariable"])
        assert canon(d["dependentVariables"]) == canon(cc["dependentVariables"])
        for bid, blk in d["codeBlocks"].items():
            union_blocks.setdefault(bid, blk)

    # nothing lost vs consolidation: union of per-chain blocks == consolidated root codeBlocks.
    assert canon(union_blocks) == canon(cons["codeBlocks"]), \
        "union of split per-chain codeBlocks != consolidated root codeBlocks"
