"""The DB cfg tier must be CONTENT-addressed: a redeploy (new extractor-binary mtime), a
re-extracted corpus (new source mtimes) or a moved workspace (new absolute paths) must NOT
orphan the KB's cfg blobs — the mtime-keyed disk cache may miss, but the DB tier keeps
serving and the trace never falls back to a live Clang subprocess per file."""
from __future__ import annotations

import os
import shutil

from vbt.cpp_frontend import wrapper as W


def _keys(tmp_path, body: bytes):
    src = tmp_path / "ab12.cpp"
    src.write_bytes(body)
    return src


def test_db_key_stable_across_mtime_and_path(tmp_path):
    """Same bytes + same extractor content ⇒ same DB key, regardless of mtime or directory."""
    binary = tmp_path / "cfg_extract"
    binary.write_bytes(b"#!/bin/sh\nexit 0\n")

    a_dir = tmp_path / "a"; a_dir.mkdir()
    b_dir = tmp_path / "b"; b_dir.mkdir()
    a = a_dir / "ab12.cpp"; a.write_bytes(b"int f(){return 1;}\n")
    b = b_dir / "ab12.cpp"; b.write_bytes(b"int f(){return 1;}\n")
    os.utime(a, (1_000_000_000, 1_000_000_000))
    os.utime(b, (2_000_000_000, 2_000_000_000))          # different mtime AND directory

    flags_a = ["-w", "-I", str(a_dir)]
    flags_b = ["-w", "-I", str(b_dir)]                    # per-file srcdir include differs too
    k_a = W._db_cfg_key(str(a), str(binary), flags_a)
    k_b = W._db_cfg_key(str(b), str(binary), flags_b)
    assert k_a is not None and k_a == k_b

    # binary mtime alone (a redeploy of the SAME binary) must not change the key…
    os.utime(binary, (2_000_000_000, 2_000_000_000))
    W._BIN_FP_CACHE.clear()
    assert W._db_cfg_key(str(a), str(binary), flags_a) == k_a

    # …but different CONTENT (source or extractor) must.
    a.write_bytes(b"int f(){return 2;}\n")
    assert W._db_cfg_key(str(a), str(binary), flags_a) != k_a
    a.write_bytes(b"int f(){return 1;}\n")
    binary.write_bytes(b"#!/bin/sh\nexit 1\n")
    W._BIN_FP_CACHE.clear()
    assert W._db_cfg_key(str(a), str(binary), flags_a) != k_a


def test_db_tier_serves_after_mtime_drift(tmp_path, monkeypatch):
    """End-to-end through run_cfg_extract: PUT once, then bump every mtime (redeploy simulation),
    clear memo + disk cache — the DB GET must serve; the subprocess must NOT run."""
    real_bin = W.DEFAULT_BINARY
    if not os.path.isfile(real_bin):
        import pytest
        pytest.skip("cfg_extract binary not built")

    src = tmp_path / "ab12.cpp"
    src.write_bytes(b"int f() { return 1; }\n")
    monkeypatch.setenv("VBT_CACHE_DIR", str(tmp_path / "cache"))

    store: dict = {}
    W._MEMO.clear()
    W.set_cfg_db_hooks(store.get, store.__setitem__)
    try:
        first = W.run_cfg_extract(str(src))
        assert store, "PUT did not populate the DB store"
        assert all(k.startswith("c:") for k in store), "DB tier must use the content key"

        # redeploy simulation: new source mtime, wiped memo + disk cache
        os.utime(src, (2_000_000_000, 2_000_000_000))
        W._MEMO.clear()
        shutil.rmtree(tmp_path / "cache", ignore_errors=True)

        def _boom(*a, **kw):
            raise AssertionError("live Clang subprocess ran — DB tier missed")
        monkeypatch.setattr(W.subprocess, "run", _boom)
        second = W.run_cfg_extract(str(src))
        assert second == first
    finally:
        W.clear_cfg_db_hooks()
        W._MEMO.clear()
