"""T7: ASM-blueprint DB override — lossless round-trip + the load_json override hook.

The full-trace byte-identical proof (build → install → warm trace) lives in the parity gate.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from backward_traversal.utils import blueprint_utils as BU

from vbt.precompute import db_artifacts as DA
from vbt.tests.parity import cases as P

pytestmark = pytest.mark.skipif(not P.corpus_available(),
                                reason="pinned corpus absent (see DB_PRECOMPUTE_PLAN.md §11)")


def test_asm_blueprint_gz_roundtrip_lossless():
    p = BU.resolve_asm_blueprint("aa71", P.BLUEPRINT_DIR)
    base = BU.load_json(str(p))
    assert len(base) > 0
    assert DA.loads_gz(DA.dumps_gz(base)) == base


def test_override_serves_then_clears():
    p = BU.resolve_asm_blueprint("aa71", P.BLUEPRINT_DIR)
    base = BU.load_json(str(p))
    served = DA.loads_gz(DA.dumps_gz(base))
    name = Path(str(p)).name

    def ov(path_str):
        return served if Path(path_str).name == name else None

    try:
        BU.set_blueprint_override(ov)
        assert BU.load_json(str(p)) == base                     # served dict == disk dict
        # a path the override declines (returns None) falls through to disk:
        cpp = BU.resolve_cpp_blueprint("dw710000", P.BLUEPRINT_DIR)
        assert BU.load_json(str(cpp)) is not None
    finally:
        BU.clear_blueprint_override()
    assert BU.load_json(str(p)) == base                         # disk again after clear
