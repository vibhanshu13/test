"""Tests for the GAP-6 setter convenience-field normalizer (vbt/output/assembler.py).

These run on small HAND-BUILT dicts (no real trace / corpus needed) so the suite is
fast. They cover: namespace-safe C++ function parsing, ``normalize_setter`` field
derivation + idempotency + non-mutation, and ``build_root_output`` populating
``file``/``line``/``function``/``blockId`` on BOTH root setters and the inline
dependent-variable setters while forwarding surfaced limitation flags.

    env/bin/python3 -m pytest vbt/tests/test_output_assembler.py -q
"""
import copy
from pathlib import Path

from vbt.output.assembler import (
    _function_from_block_id,
    build_root_output,
    normalize_dependent_variable_entry,
    normalize_setter,
)
from vbt.output.codeblocks import CodeBlockStore


# --------------------------------------------------------------------------- #
# _function_from_block_id — namespace safety + non-C++ → None
def test_function_from_block_id_namespace_safe():
    # plain C++ fn
    assert _function_from_block_id("cpp:dw710000:processACreditTransaction") == \
        "processACreditTransaction"
    # qualified C++ name keeps every `::` segment (split(":")[2] would truncate)
    assert _function_from_block_id("cpp:dw710000:Ns::Class::fn") == "Ns::Class::fn"
    # ASM block ids are labels/blocks, not functions
    assert _function_from_block_id("asm:da78:B1") is None
    # garbage / non-string / empty-fn → None
    assert _function_from_block_id(None) is None
    assert _function_from_block_id(123) is None
    assert _function_from_block_id("nocolons") is None
    assert _function_from_block_id("cpp:stem:") is None


# --------------------------------------------------------------------------- #
# normalize_setter — field derivation, idempotency, no input mutation
def test_normalize_setter_cpp_fields():
    e = {"location": {"file": "dw710000.cpp", "startLine": 1002, "endLine": 1002},
         "blockId": "cpp:dw710000:Ns::Class::fn", "pathsCapped": True}
    n = normalize_setter(e, 1)
    assert n["setterId"] == 1
    assert n["file"] == "dw710000.cpp"
    assert n["line"] == 1002
    assert n["function"] == "Ns::Class::fn"
    assert n["blockId"] == "cpp:dw710000:Ns::Class::fn"
    assert n["pathsCapped"] is True             # surfaced flag preserved
    assert e.get("file") is None                # original NOT mutated


def test_normalize_setter_asm_function_is_none():
    n = normalize_setter(
        {"location": {"file": "da78.asm", "startLine": 50, "endLine": 50},
         "blockId": "asm:da78:B1"}, 1)
    assert n["file"] == "da78.asm"
    assert n["line"] == 50
    assert n["function"] is None


def test_normalize_setter_no_location_is_none():
    n = normalize_setter({"blockId": "cpp:s:fn"}, 1)
    assert n["file"] is None and n["line"] is None
    assert n["function"] == "fn"


def test_normalize_setter_missing_blockid_defaults_none():
    n = normalize_setter({"location": {"file": "f.cpp", "startLine": 3, "endLine": 3}}, 1)
    assert n["blockId"] is None and n["function"] is None
    assert n["file"] == "f.cpp" and n["line"] == 3


def test_normalize_setter_idempotent_and_preserves_caller_fields():
    e = {"location": {"file": "f.cpp", "startLine": 9, "endLine": 9},
         "blockId": "cpp:f:realFn",
         # caller already set explicit (different) convenience fields → preserved
         "file": "override.cpp", "line": 0, "function": "callerFn"}
    n1 = normalize_setter(e, 2)
    n2 = normalize_setter(n1, 2)
    assert n1 == n2                              # idempotent
    assert n1["file"] == "override.cpp"          # `or` keeps non-empty caller value
    assert n1["line"] == 0                        # `is not None` keeps a 0 line
    assert n1["function"] == "callerFn"           # caller value not overwritten


# --------------------------------------------------------------------------- #
# normalize_dependent_variable_entry — shallow copy, no caller mutation
def test_normalize_dependent_variable_entry_no_mutation():
    dep = {"dependentVariable": {
        "name": "foo", "origin": "ancestor", "terminal": False,
        "setters": [
            {"value": "1", "location": {"file": "da78.asm", "startLine": 7, "endLine": 7},
             "blockId": "asm:da78:B1"},
            {"value": "2", "location": {"file": "dw71.cpp", "startLine": 9, "endLine": 9},
             "blockId": "cpp:dw71:helper"},
        ]}}
    src = copy.deepcopy(dep)
    out = normalize_dependent_variable_entry(dep)
    dv = out["dependentVariable"]
    assert dv["origin"] == "ancestor" and dv["terminal"] is False   # other keys kept
    assert dv["setters"][0]["file"] == "da78.asm" and dv["setters"][0]["function"] is None
    assert dv["setters"][1]["file"] == "dw71.cpp" and dv["setters"][1]["function"] == "helper"
    assert [s["setterId"] for s in dv["setters"]] == [1, 2]
    assert dep == src, "caller-owned dependentVariable was mutated"


# --------------------------------------------------------------------------- #
# build_root_output — end to end (root + inline dep setters + flag forwarding)
def _root_entry():
    return {
        "value": "ExpressPay", "valueResolved": None,
        "setterCodeChunk": "softCardValue = ExpressPay;",
        "location": {"file": "dw710000.cpp", "startLine": 1002, "endLine": 1002},
        "blockId": "cpp:dw710000:Ns::Class::processACreditTransaction",
        "chain": ["aa71", "dw710000"], "unconditionalAtSetter": False,
        "conditions": [], "dependentVariables": [],
        "pathsCapped": True,                       # a surfaced limitation flag
    }


def _dep_obj():
    return {"dependentVariable": {
        "name": "lstknpoa", "qualified": "linkSourceArea->lstknpoa",
        "origin": "ancestor", "terminal": False, "is_function_output": False,
        "setters": [
            {"value": "'Y'", "location": {"file": "dw710000.cpp", "startLine": 500, "endLine": 500},
             "blockId": "cpp:dw710000:DW71", "conditions": []},
            {"value": "X'01'", "location": {"file": "da78.asm", "startLine": 860, "endLine": 860},
             "blockId": "asm:da78:B1", "conditions": []},
        ]}}


def test_build_root_output_root_setter_fields():
    store = CodeBlockStore(Path("/tmp"))
    entries = [_root_entry()]
    src = copy.deepcopy(entries)
    out = build_root_output("softCardValue", entries, store, dependent_variables=[])

    rs = out["rootVariable"]["setters"][0]
    assert rs["setterId"] == 1
    assert rs["file"] == "dw710000.cpp"
    assert rs["line"] == 1002
    assert rs["function"] == "Ns::Class::processACreditTransaction"
    assert rs["blockId"] == "cpp:dw710000:Ns::Class::processACreditTransaction"
    assert rs["pathsCapped"] is True              # surfaced flag still forwarded
    assert entries == src, "build_root_output mutated input setter_entries"


def test_build_root_output_inline_dependent_setters():
    store = CodeBlockStore(Path("/tmp"))
    deps = [_dep_obj()]
    src = copy.deepcopy(deps)
    out = build_root_output("softCardValue", [_root_entry()], store, dependent_variables=deps)

    dvs = out["dependentVariables"][0]["dependentVariable"]["setters"]
    # C++ dep setter → file/line/function from blockId
    assert dvs[0]["file"] == "dw710000.cpp" and dvs[0]["line"] == 500
    assert dvs[0]["function"] == "DW71"
    # ASM dep setter → file/line but NO function
    assert dvs[1]["file"] == "da78.asm" and dvs[1]["line"] == 860
    assert dvs[1]["function"] is None
    # surviving dv keys + ordering preserved
    assert out["dependentVariables"][0]["dependentVariable"]["origin"] == "ancestor"
    assert deps == src, "build_root_output mutated caller-owned dep_objs"
