"""Phase 1 byte-identity: the precomputed ASM setter map reproduces find_asm_setters_in_file exactly.

For every (stem, variable) the modifier index covers, the precomputed lookup (`load_asm_setters`)
must equal the live scan (`find_asm_setters_in_file` with the lookup disabled), field-for-field. This
proves the serialize→load round-trip (asdict→blob→SetterSite, with the `variable` field re-stamped to
the queried form) is faithful — the crux of moving the setter scan to precompute. The DB parity gate
separately proves it on the REAL trace's queried variables.
"""
from __future__ import annotations

from dataclasses import asdict

import pytest

from vbt.tests.parity.cases import BLUEPRINT_DIR as BP, ASM_DIR as SRC, corpus_available

JOB = "1ffa983c-3282-42f2-9701-a4c3f21451b1"

pytestmark = pytest.mark.skipif(not corpus_available(), reason="reference corpus unavailable")


def test_asm_setter_map_matches_live_scan():
    from vbt.precompute.modifier_index import get_modifier_index
    from vbt.setters.asm_setters import (
        find_asm_setters_in_file, set_asm_setter_map_job, _SETTER_CACHE)
    from vbt.precompute.setter_map_db import load_asm_setters
    from vbt.precompute import db_artifacts as DA

    set_asm_setter_map_job(None)       # force find_asm_setters_in_file to SCAN (live)
    DA.set_load_only(False)
    _SETTER_CACHE.clear()

    midx = get_modifier_index(BP, SRC)
    pairs = [(stem, var) for var, files in midx.asm.items() for stem in files]
    assert pairs, "modifier index produced no ASM (stem,var) pairs — test would be vacuous"

    checked = mism = miss_nonempty = 0
    for stem, var in pairs:
        live = find_asm_setters_in_file(var, stem, BP, SRC)
        pre = load_asm_setters(JOB, stem, var)
        if pre is None:                # precompute miss — only a bug if the live scan found setters
            if live:
                miss_nonempty += 1
            continue
        checked += 1
        if [asdict(s) for s in live] != [asdict(s) for s in pre]:
            mism += 1
            if mism <= 3:
                print(f"MISMATCH {stem}/{var}: live={[asdict(s) for s in live][:1]} "
                      f"pre={[asdict(s) for s in pre][:1]}")
    assert mism == 0, f"{mism}/{checked} precomputed setter lists differ from the live scan"
    assert miss_nonempty == 0, f"{miss_nonempty} (stem,var) had setters live but missed the precompute"
    assert checked > 0, "no (stem,var) pair was actually covered by the precompute — coverage gap"
