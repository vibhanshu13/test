"""Regression: a BARE enum constant must not leak in as a dependent variable.

A guard like ``task != DacAutoRes`` (where ``DacAutoRes = 0x64`` is an enum constant)
or a ``case DacAutoRes:`` reconstruction compares a real variable (``task``) against a
CONSTANT (``DacAutoRes``). The constant is not a traceable lineage variable. The
``EnumType::Const`` spelling is already dropped by the ``::`` rule and ``#define``-style
ALL-CAPS by the all-caps rule; this closes the remaining gap — a *bare* TitleCase or
camelCase enumerator — by consulting the const-resolver's authoritative enum-constant
table. Only names PROVEN to be enum constants are dropped, and only in their bare form
(a ``x.DacAutoRes`` member read keeps its path), so no real variable is lost.
"""
from vbt.depvars.extract import _cpp_operand_paths


def test_bare_enum_constant_dropped_titlecase():
    # `task` is the variable, `DacAutoRes` the constant it is compared against.
    assert _cpp_operand_paths("task != DacAutoRes", {"DacAutoRes"}) == ["task"]


def test_bare_enum_constant_dropped_camelcase():
    # the corpus also has camelCase enum constants (e.g. chipCard) — case can't be the
    # discriminator; membership in the authoritative table is.
    assert _cpp_operand_paths("entryType == chipCard", {"chipCard"}) == ["entryType"]


def test_member_path_with_const_tail_is_kept():
    # a field whose tail happens to share a constant's name is a real read, NOT the
    # constant — only the BARE form is dropped.
    assert _cpp_operand_paths("x.DacAutoRes", {"DacAutoRes"}) == ["x.DacAutoRes"]


def test_no_const_names_is_a_noop():
    # backward compatibility: with no table supplied, behavior is unchanged.
    assert _cpp_operand_paths("task != DacAutoRes") == ["task", "DacAutoRes"]


def test_real_variables_never_dropped():
    got = _cpp_operand_paths("(lwrCommon != 0) && (task != DacAutoRes)", {"DacAutoRes"})
    assert "lwrCommon" in got and "task" in got and "DacAutoRes" not in got
