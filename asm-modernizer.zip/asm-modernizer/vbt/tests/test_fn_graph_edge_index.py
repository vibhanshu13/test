from pathlib import Path

from vbt.precompute import db_artifacts as DA
from vbt.precompute import graph_db as G
from vbt.reach.cpp_routes import CppFnGraph
from vbt.reach.route import RouteEngine


def _clear_edge_caches():
    G._FN_EDGE_INDEX_PRESENT.clear()
    G._FN_EDGE_STEM_CACHE.clear()


def test_fn_graph_slice_loads_max_depth_frontier_for_truncation(monkeypatch):
    _clear_edge_caches()
    rows = {
        G.FN_GRAPH_EDGE_PREFIX + "a": {"fa": [["b", "fb", 1, True]]},
        G.FN_GRAPH_EDGE_PREFIX + "b": {"fb": [["c", "fc", 2, True]]},
        G.FN_GRAPH_EDGE_PREFIX + "c": {"fc": [["d", "fd", 3, True]]},
    }

    monkeypatch.setattr(
        DA,
        "read_manifest",
        lambda job_id, artifact: (
            {"version": G.FN_GRAPH_EDGE_INDEX_VERSION}
            if artifact == G.FN_GRAPH_EDGE_INDEX_ARTIFACT else None
        ),
    )
    monkeypatch.setattr(
        DA,
        "read_blob",
        lambda job_id, artifact: (
            DA.dumps_gz(rows[artifact]) if artifact in rows else None
        ),
    )

    adj = G.load_fn_graph_adj_slice("j", ("a", "fa"), max_depth=2)
    assert adj[("c", "fc")] == {("d", "fd", 3, True)}

    graph = CppFnGraph.from_prebuilt(adj)
    paths, truncated = graph.enumerate_paths(
        ("a", "fa"), ("d", "fd"), max_paths=64, max_depth=2)
    assert paths == []
    assert truncated is True


def test_fn_graph_slice_absent_index_returns_none(monkeypatch):
    _clear_edge_caches()
    monkeypatch.setattr(DA, "read_manifest", lambda job_id, artifact: None)

    assert G.load_fn_graph_adj_slice("j", ("a", "fa"), max_depth=2) is None


def test_route_engine_full_fn_graph_loader_ignores_cached_slice(tmp_path, monkeypatch):
    full = {("root", "f"): {("target", "g", 10, True)}}
    sliced = {("root", "f"): {("near", "h", 1, True)}}
    route = RouteEngine(Path(tmp_path), Path(tmp_path) / "file_call_graph.json",
                        Path(tmp_path), job_id="j")
    route._cpp_fn_graph = CppFnGraph.from_prebuilt(sliced)
    route._cpp_fn_graph_slice_depth = 2

    monkeypatch.setattr(G, "load_fn_graph_adj", lambda job_id: full)

    assert route._load_fn_graph_adj() == full

