"""Regression guard: source-comment text must never leak into the dependent-variable
set, and the fix must never drop a real operand (SPEC §6 dep-var harvesting).

Root cause (both langs): dep-var harvesting tokenized operand/value strings that still
contained comment text, then trusted a name-shape filter to remove the garbage — but a
name-shape filter cannot tell a real identifier from an English word. The fix strips
the comment at the operand boundary BEFORE harvesting:

  * ASM: cut each columnar operand at the first UNQUOTED blank (the HLASM operand-field
    boundary) — see vbt/conditions/asm_conditions.py:_operand_head.
  * C++: strip // and /* */ before extracting operand paths — see
    vbt/depvars/extract.py:_cpp_operand_paths.

These are unit-level (no corpus / no blueprint files needed).
"""
from vbt.conditions.asm_conditions import _operand_head, collect_asm_conditions
from vbt.depvars.extract import _cpp_operand_paths, extract_dep_vars
from vbt.interfaces import SetterSite


# --------------------------------------------------------------------------- #
# ASM operand boundary
# --------------------------------------------------------------------------- #
def test_operand_head_strips_inline_comment_keeps_real_operand():
    # comment glued onto the operand (the real-corpus shapes)
    assert _operand_head("EBWKIDX+4 BASE THE ADDRESSES AREA") == "EBWKIDX+4"
    assert _operand_head("LWRISOA+4 ADDRESS 'IS' AREA") == "LWRISOA+4"
    assert _operand_head("PAMSG1 '    PRE-AUTH MESSAGE ?        R188") == "PAMSG1"
    assert _operand_head("CE2TIME(R14) THIS ECB START TIME?") == "CE2TIME(R14)"
    # quoted literals with an embedded blank survive intact (quote-aware boundary)
    assert _operand_head("C'A B'") == "C'A B'"
    assert _operand_head("B'1111'") == "B'1111'"
    assert _operand_head("=C'DUMP' ERROR FROM UA81") == "=C'DUMP'"
    # clean operands are unchanged
    assert _operand_head("LWRIS_MSG_TYP") == "LWRIS_MSG_TYP"
    assert _operand_head("0(R1)") == "0(R1)"


def test_asm_condition_harvest_drops_comment_words_keeps_field():
    # One block: a CLC compare whose 2nd columnar operand carries the inline comment,
    # paired with a branch. Fake bp_path → cfg_incoming build excepts → same-block only.
    bp = {"blocks": [{"id": "B1", "flow": {
        "i": ["CLC", "JE"],
        "a": [["LWRIS_MSG_TYP", "PAMSG1 '    PRE-AUTH MESSAGE ?        R188"],
              ["AA710A5M"]],
        "l": [100, 101],
    }}]}
    conds, _ = collect_asm_conditions(bp, "/nonexistent.asm.json", "B1",
                                      before_line=105, file="t.asm")
    assert conds, "expected the CLC/JE guard to be collected"
    blob = " ".join(f"{c.raw_test} {c.raw_branch}" for c in conds)
    # comment words must NOT appear in the reconstructed raw_test/raw_branch
    for word in ("MESSAGE", "PRE", "AUTH", "R188"):
        assert word not in blob, f"comment word {word!r} leaked into {blob!r}"

    setter = SetterSite(variable="LWRPOSFCRDV", file_stem="t", language="asm",
                        line=105, instruction="OI", block_id="B1", value="")
    names = {d.name.upper() for d in extract_dep_vars(setter, conds)}
    assert "LWRIS_MSG_TYP" in names, "the real compared field was dropped"
    assert not ({"MESSAGE", "THE", "BASE", "AREA", "ADDRESS", "AUTH", "WE"} & names), \
        f"comment words leaked as dep vars: {names}"
    # the BRANCH target label (raw_branch operand) is a code location, not a data
    # variable, and must never be harvested as a dependent variable.
    assert "AA710A5M" not in names, f"branch target label leaked as a dep var: {names}"


def test_branch_target_label_not_harvested():
    """A conditional branch's operand is its TARGET LABEL — never a dependency."""
    from vbt.interfaces import Condition, Location
    cond = Condition(order=1, condition="WK_RRC == ZEROS", block_id="B1",
                     location=Location("t.asm", 10, 10),
                     raw_test="CLC WK_RRC, ZEROS", raw_branch="BNE DA7_0900")
    setter = SetterSite(variable="LG1OSI", file_stem="t", language="asm",
                        line=12, instruction="OI", block_id="B1", value="")
    names = {d.name.upper() for d in extract_dep_vars(setter, [cond])}
    assert "WK_RRC" in names, "the real compared field (raw_test) was dropped"
    assert "DA7_0900" not in names, f"branch label DA7_0900 leaked: {names}"


# --------------------------------------------------------------------------- #
# C++ comment stripping
# --------------------------------------------------------------------------- #
def test_cpp_operand_paths_strips_comments_keeps_code():
    # an aggregate-initializer value with //* N: <comment> rows (the Iso8583 shape)
    val = ('{ {0, 0, 0, 0, 0 ,""}, //* 0: Nothing in Field 0\n'
           '  {0, 6, 6, 0, 0 ,""}, //* 3: Processing Code\n'
           '  realStruct.realField }  /* Date / Time Transmission */')
    paths = _cpp_operand_paths(val)
    tails = {p.split(".")[-1].split("->")[-1] for p in paths}
    # the real member-path in code survives (returned whole; canonical tail = realField)
    assert "realStruct.realField" in paths
    assert "realField" in tails
    # comment words are gone
    assert not ({"Nothing", "Code", "Processing", "Date", "Time", "Transmission",
                 "Field"} & tails), f"comment words leaked: {tails}"


def test_cpp_comment_strip_only_removes_never_adds():
    # stripping comments is monotone: the post-strip operand set is a SUBSET of pre.
    samples = [
        "a->b == Cas::On  // expressPay set here",
        "linkSourceArea->lstknpoa /* token */ == 'Y'",
        "x = y + z;  //* comment Words Here",
    ]
    for s in samples:
        without_comment_marks = s.replace("//", "  ").replace("/*", "  ").replace("*/", "  ")
        full = set(_cpp_operand_paths(s))
        # the real operands (no comment text) must all still be harvested
        code_only = set(_cpp_operand_paths(s.split("//")[0].split("/*")[0]))
        assert code_only.issubset(full | code_only)  # sanity
        # nothing the stripped version yields is absent from a comment-free parse
        assert set(_cpp_operand_paths(s)).issuperset(
            set(_cpp_operand_paths(s.split("//")[0].split("/*")[0])) - {""})
