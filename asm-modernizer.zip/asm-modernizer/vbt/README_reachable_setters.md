# VBT Reachable Setters

Find every setter of one or more variables that is **forward-reachable** from a
given entry point (`stem` + `function`), using only the precomputed `index.db` —
**zero live file reads**.

| Artifact | Path |
|----------|------|
| Celery task | `api/tasks/vbt_reachable_setters_task.py` (`asm.vbt_reachable_setters`) |
| Standalone CLI | `find_reachable_setters.py` (repo root) |
| Tests | `api/tasks/test_vbt_reachable_setters_task.py` |
| Registration | `api/tasks/celery_app.py` (`include` list) |

---

## What it does & why

A variable can be *set* in many places across the corpus, but from a specific
entry point most of those setter sites are **unreachable** (the call graph never
flows into them). This feature answers:

> Starting at `stem::function`, which setters of variable *V* can actually be
> reached?

It is the lightweight, read-only counterpart to a full VBT trace: instead of
building lineage it just enumerates candidate setters and confirms each one is
reachable from the entry point. Because it runs entirely against the
precomputed `index.db` (in `load_only` mode), it does **no disk/source reads and
never live-compiles** — a single softCardValue query returns in ~0.6 s after a
~0.2 s DB warm-up.

---

## How it works

1. **Detect entry file type** — query `vbt_artifact_blob` for `bp:{stem}.%`;
   `.cpp/.hpp` ⇒ `cpp`, `.asm/.mac` ⇒ `asm` (defaults to `cpp`). The C++ entry
   uses `function`; an ASM entry ignores it.
2. **Load precomputed context** (`set_load_only(True)`): resolvers, route graph,
   C++ call edges, route cache, ASM/C++ setter maps, C++ file-writes, fn-facts.
   All are keyed off the precompute job's `index.db`.
3. **Compute the reachable file set** once: `route.forward_reachable_files(tail_ep)`.
4. **Per variable:**
   - Resolve cross-language aliases (`resolve_aliases`) → search targets
     `[(variable, cpp)] + aliases`.
   - For each target, take the modifier-index files that set it, intersect with
     the reachable file set, and collect candidate setters
     (`find_cpp_setters_in_file` / `find_asm_setters_in_file`).
   - **Confirm reachability** of each candidate: it is kept if
     `enumerate_cpp_paths(... max_paths=64, max_depth=16)` finds a path, **or**
     `route.routes(tail_ep, child)` reports `reachable`.
5. Emit the surviving setters per variable.

---

## Prerequisites

A completed VBT precompute for the target KB, i.e. these must exist:

- `jobs/<kb_id>/index.db` — the precomputed artifact store
- a blueprint dir (e.g. `jobs/<kb_id>/output/asm 5`) containing
  `file_call_graph.json`
- the original source dir (e.g. `datasource/asm7_admin/asm 7_version_0/asm 5`)

> ⚠️ Copy-fragility: the C++ cfg cache is keyed by path+size+mtime, so copying a
> datasource into a new folder invalidates cfg keys. Keep paths stable, or this
> degrades (in `load_only` it simply misses rather than live-compiling).

---

## Celery task — `asm.vbt_reachable_setters`

```python
from api.tasks.vbt_reachable_setters_task import run_vbt_reachable_setters

result = run_vbt_reachable_setters.delay(job_id, {
    "variables": ["softCardValue", "OnlineSourceInd"],
    "stem": "dw710000",
    "function": "callPlasticAuthenticationComponentInterface",
    "precompute_job_id": "b58d8432-73e0-42d1-89a9-2ceebc47c6d2",
})
```

### Options

| Key | Required | Default | Meaning |
|-----|----------|---------|---------|
| `variables` | **yes** | — | List of variable names to query |
| `stem` | no | `dw710000` | Entry file stem |
| `function` | no | `callPlasticAuthenticationComponentInterface` | Entry C++ function (block_id for ASM; ignored for ASM entries) |
| `kb_id` / `precompute_job_id` | no | `job_id` | Job whose `index.db` holds the precompute |
| `blueprint_dir` | no | `jobs/<job_id>/output` (auto-descended) | Blueprint dir; `file_call_graph.json` lives here |
| `asm_dir` | no | job's pipeline `source_path` | Original source dir |
| `graph_file` | no | `<blueprint_dir>/file_call_graph.json` | Call-graph file override |

`asm_dir` is required *effectively*: if not passed and not derivable from the
job's pipeline options (`source_path`), the task raises `ValueError`.

### Output

```jsonc
{
  "job_id":  "<job_id>",
  "kb_id":   "<precompute_job_id>",
  "status":  "success",            // or "failed" (with "error")
  "elapsed": 0.83,                 // seconds
  "variables": {
    "softCardValue": [
      {
        "file_stem": "dw780000",
        "language":  "cpp",
        "line":      342,
        "function":  "selectCidDbRecord15",   // block_id for ASM setters
        "code":      "plasticAuth.process.transactionInds.softCardValue"
      }
      // ...
    ],
    "OnlineSourceInd": []          // reachable from this entry: none
  }
}
```

The task is resilient: a `SoftTimeLimitExceeded` or any exception is caught,
logged, and returned as `{"status": "failed", "error": ...}` while marking the
workspace status `failed`. Logs go to the job log (`redirect_output_to_log` +
`job_log_handler`).

---

## CLI — `find_reachable_setters.py`

A standalone prototype with the same logic (paths hardcoded to the
`b58d8432…` fixture; edit the script for other jobs).

```bash
# multiple args or comma-separated
env/bin/python3 find_reachable_setters.py softCardValue OnlineSourceInd
env/bin/python3 find_reachable_setters.py "softCardValue,OnlineSourceInd"

# override entry point / job
env/bin/python3 find_reachable_setters.py \
  --job-id b58d8432-73e0-42d1-89a9-2ceebc47c6d2 \
  --stem dw710000 \
  --function callPlasticAuthenticationComponentInterface \
  softCardValue
```

| Flag | Default |
|------|---------|
| `--job-id` | `b58d8432-73e0-42d1-89a9-2ceebc47c6d2` |
| `--stem` | `dw710000` |
| `--function` | `callPlasticAuthenticationComponentInterface` |
| `variables` (positional) | prompted interactively if omitted |

### Example output

```
=== Variable: 'softCardValue' (took 596.73 ms) ===
Aliases searched: ['softCardValue', 'LWRPOSFCRDV']
  1. dw710000.cpp @ line 1003 inside processACreditTransaction: plasticAuth.process.transactionInds.softCardValue
  ...
  27. dw780000.cpp @ line 4577 inside perform4cscMatchInstantAccountOverrideCheck: plasticAuth.process.transactionInds.softCardValue

=== Variable: 'OnlineSourceInd' (took 0.90 ms) ===
Aliases searched: ['OnlineSourceInd']
  No reachable setters found.
```

---

## Testing

```bash
env/bin/python3 -m pytest api/tasks/test_vbt_reachable_setters_task.py -v
```

- `test_task_is_registered` — `asm.vbt_reachable_setters` is on the shared
  `celery_app` (no fixture needed).
- `test_eager_run_reachable_setters` — eager run on `softCardValue` /
  `OnlineSourceInd`; asserts `success`, that softCardValue has ≥1 reachable
  setter rooted in `dw710000`/`dw780000` (27 in the fixture), and that
  OnlineSourceInd has none. **Skipped** automatically if the
  `b58d8432…` DB / blueprint / source fixture is absent.

---

## Notes & caveats

- **No HTTP endpoint yet** — invoke via the Celery task or the CLI. (Other VBT
  features such as all-chains-trace expose a route; this one does not.)
- **`name_alias` load-only fallback** — if the precomputed `name_alias` resolver
  artifact fails validation, the resolver logs a warning and falls back to a
  full-corpus alias build. Results are unaffected (the alias still resolves,
  e.g. `softCardValue → LWRPOSFCRDV`); only that one resolver isn't served from
  the DB.
- **Reachability is forward** — candidate setters are pruned to
  `forward_reachable_files(entry)` before the per-setter path check, so a setter
  in an unreachable file is never considered.
