"""Setter detection modules (ASM reused read-only; C++ rebuilt on the frontend)."""
