"""C++ setter detection — tree-sitter (syntactic, header-independent).

SPEC §4/§5: assignment LHS member-paths are syntactic, so tree-sitter resolves them
correctly even when struct headers are missing (Clang drops member-writes to
unresolved types). We use tree-sitter to find WHERE a field is written + its RHS;
the Clang CFG (cpp_conditions) supplies reachability conditions; enum-int/by-ref
enrichment comes from Clang when headers are present.

Matches a target field by its trailing component (e.g. variable ``softCardValue``
matches ``plasticAuth.process.transactionInds.softCardValue``) and/or a full path.

Match disambiguation (A3)
-------------------------
Tail-only matching ("any LHS whose last component is ``field``") over-collects: it
attributes an UNRELATED struct's same-named field (``other.softCardValue``), a
pointer-chain into a different object, and even a same-named local variable to the
target.  When the caller supplies ``full_paths`` (the qualified member path(s) of the
target), we additionally require the matched LHS member-chain to be *consistent* with
one of them — i.e. one chain is a trailing-suffix of the other (handles partial views
like ``b.softCardValue`` vs ``a.b.softCardValue`` and ``->``/``.`` mixing).  Sites that
are not consistent are dropped, so an unrelated struct's field is no longer attributed.

Every returned ``SetterSite`` also carries a (dynamic) ``match_scope`` attribute so a
consumer can disambiguate without re-parsing:
    * ``"member"`` — LHS is a member-access chain (``a.b.field`` / ``p->field``).
    * ``"local"``  — LHS is a bare local/global declaration or assignment (``field``).
    * ``"qualified"`` — LHS matched an explicit entry in ``full_paths``.
The existing ``is_declaration`` flag still separates a declaration from an assignment.

A2 — MACRO blind spot (NOT fully solved by design)
---------------------------------------------------
Tree-sitter is a *syntactic* parser with no preprocessor: writes hidden inside a
function-like macro (e.g. ``SET_SOFTCARD(plasticAuth, val);`` expanding to an
assignment) are INVISIBLE here — the macro call is just a ``call_expression`` and the
assignment only exists post-expansion.  Fully resolving this needs a preprocessor
(Clang), which is out of scope for the header-independent path.  As a cheap
best-effort *note* we scan ``#define``s for object-like/function-like macros whose
replacement text textually assigns the target field, and attach them as a
``macro_setter_notes`` attribute on every returned site (advisory only — never a
SetterSite, since we cannot know the call sites or conditions syntactically).
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tree_sitter_cpp
from tree_sitter import Language, Parser

from vbt.interfaces import SetterSite

_CPP_LANG = Language(tree_sitter_cpp.language())

# Declarator wrappers that sit between an init_declarator/declarator field and the
# actual name being declared.  For ``int* x``, ``int& x``, ``int** x``, ``int x[4]``,
# ``int (*x)`` tree-sitter nests pointer/reference/array/parenthesized declarators
# around the inner ``identifier``; their .text is e.g. ``"* x"`` which never tail-
# matches ``x``.  We must descend through them to the leaf name (A1).
_DECLARATOR_WRAPPERS = (
    "init_declarator",
    "pointer_declarator",
    "reference_declarator",
    "parenthesized_declarator",
    "array_declarator",
)

# Node types that ARE the declared/assigned name (or a member-access leaf).
_NAME_NODES = (
    "identifier",
    "field_identifier",
    "qualified_identifier",
    "type_identifier",
)

# --------------------------------------------------------------------------- #
# Mem-write builtins (SHARED — single source of truth, reused by the coarse
# modifier_index scan and the lite relevant_files grep, see those modules).
#
# These are ``call_expression``s, NOT ``assignment_expression``s, so the
# ``=``-shaped setter discovery never recorded the DESTINATION (arg0) they write.
# Every builtin here writes through its FIRST argument (arg0 is the dest buffer).
# ``memcmp`` is a READ (compare) — deliberately NOT in this set.
#
# Map: builtin name -> 0-based index of the SOURCE operand that supplies the
# written value (the dep var(s) of the write).  ``None`` means "every argument
# after the destination is a source" (the printf-family format + varargs).
#   memcpy(dst, SRC, n) / memmove(dst, SRC, n) / strcpy(dst, SRC) /
#   strncpy(dst, SRC, n) / bcopy(SRC, dst, n)*  → source is the copied buffer
#   memset(dst, FILL, n) / bzero(dst, n)        → source is the fill/len operand
#   sprintf(dst, FMT, ...) / snprintf(dst, n, FMT, ...) → source = all the rest
# *bcopy's signature is bcopy(src, dest, n) — dest is arg1, not arg0 — handled
#  via _MEM_WRITE_DEST_INDEX below; its source is then arg0.
# --------------------------------------------------------------------------- #
MEM_WRITE_BUILTINS = frozenset({
    "memcpy", "memmove", "memset", "strcpy", "strncpy",
    "bcopy", "bzero", "sprintf", "snprintf",
})

# Which arg index holds the DESTINATION (written) buffer. Default 0; bcopy is the
# odd one out — bcopy(src, dest, n).
_MEM_WRITE_DEST_INDEX = {"bcopy": 1}

# Which arg index holds the SOURCE value (the dep var of the write). ``None`` ==
# "all args after the destination" (printf-family varargs). Defaults to 1.
_MEM_WRITE_SRC_INDEX = {
    "memcpy": 1, "memmove": 1, "strcpy": 1, "strncpy": 1, "memset": 1,
    "bzero": 1, "bcopy": 0,            # bcopy(SRC, dest, n)
    "sprintf": None, "snprintf": None,  # all args after dest are sources
}

# Wrapper expressions that sit between an argument node and the underlying
# lvalue member-path: a leading ``&`` (pointer_expression), a C-style/C++ cast,
# and parentheses.  We descend through them to the dest lvalue (A1-style).
_DEST_UNWRAP_TYPES = (
    "pointer_expression",      # &dest.field
    "cast_expression",         # (char*)dest.field
    "parenthesized_expression",  # (dest.field)
)


def _parser() -> Parser:
    try:
        return Parser(_CPP_LANG)
    except TypeError:  # older/newer binding shape
        p = Parser()
        p.language = _CPP_LANG
        return p


def _txt(node, src: bytes) -> str:
    return src[node.start_byte:node.end_byte].decode("utf-8", "replace")


def _last_component(path: str) -> str:
    tok = path.replace("->", ".").replace("::", ".")
    return tok.split(".")[-1].strip().split("[")[0].strip()


def _member_chain(path: str) -> List[str]:
    """Normalize a (possibly mixed ``.``/``->``) member path to its component chain.

    ``"a->b.softCardValue[2]"`` -> ``["a", "b", "softCardValue"]``.  ``::`` is treated
    as a namespace/scope separator and folded into the chain too (enum/static paths).
    Array subscripts and surrounding whitespace are stripped per component.
    """
    tok = path.replace("->", ".").replace("::", ".")
    out: List[str] = []
    for part in tok.split("."):
        c = part.strip().split("[")[0].strip()
        if c:
            out.append(c)
    return out


def _unwrap_declarator(node):
    """Descend a declarator through pointer/reference/array/parenthesized/init
    wrappers to the inner name node (A1).

    Returns the innermost name-bearing node (``identifier`` / ``field_identifier`` /
    ``qualified_identifier``), or ``None`` if no such leaf exists (e.g. a
    ``function_declarator`` — not a variable, must not be treated as a setter).

    We prefer the ``declarator`` field when present (the canonical "what is being
    declared" edge) and otherwise pick the single name-bearing child, so we never
    cross into a ``parameter_list`` or default-value expression.
    """
    cur = node
    seen = 0
    while cur is not None and seen < 64:   # depth guard against pathological nesting
        seen += 1
        if cur.type in _NAME_NODES:
            return cur
        # A function_declarator is NOT a variable being defined; refuse it so e.g.
        # ``int* foo(int x) { ... }`` is never reported as a write to ``foo``.
        if cur.type == "function_declarator":
            return None
        nxt = cur.child_by_field_name("declarator")
        if nxt is None:
            # No declarator field (e.g. a bare pointer_declarator in some grammar
            # shapes): fall back to the first name-bearing / wrapper child.
            nxt = None
            for ch in cur.children:
                if ch.type in _NAME_NODES or ch.type in _DECLARATOR_WRAPPERS:
                    nxt = ch
                    break
            if nxt is None:
                return None
        cur = nxt
    return None


def _unwrap_dest_lvalue(node):
    """Descend a mem-write DESTINATION argument to its underlying lvalue node.

    A builtin's dest arg may be wrapped in a leading ``&`` (``pointer_expression``),
    a cast (``cast_expression``), or parentheses (``parenthesized_expression``) —
    e.g. ``memcpy(&plasticAuth.process.various.trxnType, ...)`` or
    ``memcpy((char*)dest.field, ...)``.  We strip those wrappers to reach the
    ``field_expression`` / ``subscript_expression`` / ``identifier`` that actually
    names the written object, so its member-path TAIL can be matched like a normal
    assignment LHS.  Returns the unwrapped node (never ``None``: an unwrappable
    arg just returns the original, whose text simply won't tail-match a field).
    """
    cur = node
    seen = 0
    while cur is not None and seen < 32:   # depth guard
        seen += 1
        if cur.type == "pointer_expression":
            # &expr → the `argument` field is the pointed-at lvalue.
            nxt = cur.child_by_field_name("argument")
        elif cur.type == "cast_expression":
            # (T)expr → the `value` field is the cast operand.
            nxt = cur.child_by_field_name("value")
        elif cur.type == "parenthesized_expression":
            # (expr) → the single named child.
            nxt = next((c for c in cur.children if c.is_named), None)
        else:
            return cur
        if nxt is None:
            return cur
        cur = nxt
    return cur


def _enclosing_function(node, src: bytes) -> Optional[str]:
    cur = node.parent
    while cur is not None:
        if cur.type == "function_definition":
            # The function NAME is the declarator-chain leaf, NOT a parameter.
            # Walk down the `declarator` field (function_declarator → … → name),
            # skipping pointer/reference wrappers, never entering parameter_list.
            n = cur.child_by_field_name("declarator")
            while n is not None:
                if n.type in ("identifier", "field_identifier", "qualified_identifier",
                              "destructor_name", "operator_name"):
                    return _txt(n, src)
                n = n.child_by_field_name("declarator")
            return None
        cur = cur.parent
    return None


def _iter(node):
    stack = [node]
    while stack:
        n = stack.pop()
        yield n
        stack.extend(reversed(n.children))


def _chain_is_suffix_consistent(lhs_chain: List[str], full_chain: List[str]) -> bool:
    """True iff the two member-chains denote the same field of the same object.

    Both already end in the same target component (callers only invoke this for
    candidates that tail-match).  We align from the *right* and take the longest common
    suffix ``c`` (the field + as many of its owners as agree).  We require the overlap to
    include at least the field's immediate owner (``c >= 2`` for a real member-chain;
    ``>= 1`` for a bare target) — so a same-named bare local (``field`` vs ``a.b.field``)
    or an unrelated struct (``other.field`` vs ``a.b.field`` — owner differs ⇒ ``c == 1``)
    is rejected.  Given a sufficient overlap, we accept in two cases:

      (a) **Partial view** — one chain is a full suffix of the other (``b.field`` ⊑
          ``a.b.field``): ``c == len`` of the shorter.
      (b) **Renamed root** — the chains agree on the whole owner→field suffix and differ
          ONLY at the outermost ROOT identifier (each side has exactly one unmatched
          leading component).  This is the z/TPF shared-work-area idiom: the SAME storage
          is reached through a differently-named local/by-ref in each file
          (``commonWorkArea->process.various.expressPay`` ≡
          ``lwrCommon.process.various.expressPay``).  An INTERIOR owner mismatch leaves
          >1 unmatched on a side ⇒ a genuinely different struct ⇒ rejected.

    Soundness: this only *admits* a candidate for the precise reachability filter to then
    keep-or-drop; it never asserts a write is on-path.  It strictly widens (a) with (b),
    recovering same-storage writes the old root-anchored compare dropped, while keeping
    the unrelated-struct / bare-local rejections intact.
    """
    c = 0
    for a, b in zip(reversed(lhs_chain), reversed(full_chain)):
        if a == b:
            c += 1
        else:
            break
    if c == 0:
        return False
    required = 2 if len(full_chain) > 1 else 1
    if c < required:                      # must share at least the field + its owner
        return False
    if c == len(lhs_chain) or c == len(full_chain):
        return True                       # (a) partial view (one is a suffix of the other)
    return (len(lhs_chain) - c == 1) and (len(full_chain) - c == 1)   # (b) renamed root only


def _matches_full_paths(lhs_chain: List[str], full_chains: List[List[str]]) -> bool:
    """Consistency gate for A3 when the caller knows the target's qualified path(s)."""
    return any(_chain_is_suffix_consistent(lhs_chain, fc) for fc in full_chains)


# Best-effort detector for A2: an object-/function-like ``#define`` whose replacement
# text assigns the target field.  Purely textual (no expansion), advisory only.
def _macro_setter_notes(src: bytes, variable: str) -> List[str]:
    notes: List[str] = []
    if not variable:
        return notes
    # `=` not `==`/`<=`/... followed (after optional members) by the target field on
    # the LHS.  We look for `<field> =` or `.<field> =` / `->%field =` inside a #define
    # replacement list.  Cheap, line-oriented; multi-line macros (trailing backslash)
    # are joined first.
    text = src.decode("utf-8", "replace")
    text = re.sub(r"\\\n", " ", text)            # splice line-continued #defines
    field = re.escape(variable)
    assign = re.compile(
        r"(?:(?:->|\.)\s*)?\b" + field + r"\b\s*(?:\[[^\]]*\])?\s*=(?!=)"
    )
    define = re.compile(r"^\s*#\s*define\s+(\w+)(\([^)]*\))?\s+(.*)$")
    for line in text.splitlines():
        m = define.match(line)
        if not m:
            continue
        repl = m.group(3)
        if assign.search(repl):
            notes.append(m.group(1))
    return notes


# Memo for find_cpp_setters_in_file. The function is PURE in (file content, variable,
# full_paths) but re-reads + re-parses the whole .cpp with tree-sitter on every call.
# It is hammered by the per-route value-flow prune (engine.py) and the dep-var setter
# search (recurse.py) — the SAME (variable, file) recurs across many routes/deps — so an
# uncached parse turned a depth-2 trace into a multi-minute hot loop. Keyed on the file's
# (size, mtime) so an edited file rebuilds; bounded with a coarse clear to cap memory.
_SETTER_CACHE: Dict[tuple, List["SetterSite"]] = {}
_SETTER_CACHE_MAX = 8192

# Phase 2: the job whose precomputed per-file C++ setter map should be consulted (a LOOKUP +
# full_paths filter instead of a tree-sitter parse + node walk). Armed by the engine at trace start
# for a load-only trace; None ⇒ always scan. The lookup is also gated on is_load_only() so the
# precompute build itself (load-only OFF) still parses + scans to produce the map.
_CPP_SETTER_MAP_JOB: Optional[str] = None


def set_cpp_setter_map_job(job_id: Optional[str]) -> None:
    """Engine hook: route find_cpp_setters_in_file through the precomputed setter map for this job."""
    global _CPP_SETTER_MAP_JOB
    _CPP_SETTER_MAP_JOB = job_id


_CPP_FILE_WRITES_JOB: Optional[str] = None


def set_cpp_file_writes_job(job_id: Optional[str]) -> None:
    """Engine hook: serve _file_writes from the precomputed cpp_file_writes map for this job."""
    global _CPP_FILE_WRITES_JOB
    _CPP_FILE_WRITES_JOB = job_id


def _setter_cache_key(cpp_path: Path, variable: str, full_paths) -> Optional[tuple]:
    try:
        st = cpp_path.stat()
    except OSError:
        return None
    return (str(cpp_path), st.st_size, st.st_mtime_ns, variable,
            tuple(sorted(full_paths or ())))


def _src_bytes(cpp_path: Path) -> bytes:
    """Raw source bytes for a C++ file: from the T9 source override (index.db) when installed,
    else the file. Identical bytes either way → tree-sitter parse is byte-identical."""
    from backward_traversal.utils.blueprint_utils import source_override_bytes
    ov = source_override_bytes(cpp_path)
    return ov if ov is not None else cpp_path.read_bytes()


# Per-file (src bytes + parse tree) cache. The raw read + tree-sitter parse are INVARIANT in
# the variable being searched, but find_cpp_setters_in_file keys its result cache by
# (file, variable, full_paths) — so distinct variables searching the same file each re-read
# + re-parse it (~2,380 parses / ~14s of a depth-2 trace). Sharing the parse across all
# variables AND all three parse sites is byte-identical (same bytes ⇒ same tree). Keyed by
# path: a source file is immutable within a process (precompute owns freshness).
_SRC_TREE_CACHE: Dict[str, tuple] = {}
_SRC_TREE_CACHE_MAX = 1024


def _src_and_tree(cpp_path: Path) -> tuple:
    """``(src_bytes, parse_tree)`` for a C++ file, parsed at most once per process.
    Propagates OSError from the read (callers that tolerate a missing file wrap this)."""
    k = str(cpp_path)
    hit = _SRC_TREE_CACHE.get(k)
    if hit is not None:
        return hit
    src = _src_bytes(cpp_path)
    tree = _parser().parse(src)
    if len(_SRC_TREE_CACHE) >= _SRC_TREE_CACHE_MAX:
        # FIFO-evict the oldest entry (was a wholesale .clear() — a re-parse CLIFF above the cap on
        # a >1024-cpp 22k trace). Evict the same key from the node cache to keep them consistent.
        _ek = next(iter(_SRC_TREE_CACHE))
        _SRC_TREE_CACHE.pop(_ek, None)
        _SETTER_NODES_CACHE.pop(_ek, None)
    _SRC_TREE_CACHE[k] = (src, tree)
    return src, tree


# DFS-ordered subset of nodes find_cpp_setters_in_file acts on (the 4 write shapes). This subset is
# variable-INDEPENDENT, but the result cache is keyed by (file, variable, full_paths) — so distinct
# variables searching the same file each re-walked the WHOLE tree (the _iter DFS was ~30s of a
# depth-2 trace, 28M list.extend calls). Cache the subset per file: byte-identical (same nodes, same
# DFS order; every other node type was a no-op in the loop). Cleared with _SRC_TREE_CACHE.
_SETTER_NODE_TYPES = frozenset({
    "assignment_expression", "init_declarator", "call_expression", "update_expression"})
_SETTER_NODES_CACHE: Dict[str, list] = {}


def _setter_nodes(cpp_path: Path, tree) -> list:
    """The interesting (write-shaped) nodes of a file's tree, in DFS order, parsed/walked once."""
    k = str(cpp_path)
    hit = _SETTER_NODES_CACHE.get(k)
    if hit is not None:
        return hit
    nodes = [n for n in _iter(tree.root_node) if n.type in _SETTER_NODE_TYPES]
    if len(_SETTER_NODES_CACHE) >= _SRC_TREE_CACHE_MAX:
        _SETTER_NODES_CACHE.pop(next(iter(_SETTER_NODES_CACHE)), None)   # FIFO, not a clear-cliff
    _SETTER_NODES_CACHE[k] = nodes
    return nodes


def find_cpp_setters_in_file(
    variable: str,
    cpp_path: str | Path,
    *,
    full_paths: Optional[List[str]] = None,
    harvest_tails: Optional[set] = None,
) -> List[SetterSite]:
    """Find every C++ write to ``variable`` (by trailing field name) in one file.

    When ``full_paths`` is given (qualified member path(s) of the target), only sites
    whose LHS member-chain is consistent with one of them are returned, so an unrelated
    struct's same-tail field is no longer mis-attributed (A3).  Without ``full_paths``
    we keep permissive tail-matching but tag each site's ``match_scope`` so the consumer
    can still disambiguate ``member`` writes from same-named ``local`` declarations.
    """
    cpp_path = Path(cpp_path)
    _ck = _setter_cache_key(cpp_path, variable, full_paths)
    if _ck is not None and _ck in _SETTER_CACHE:
        return _SETTER_CACHE[_ck]
    stem = cpp_path.name
    for suf in (".cpp", ".hpp", ".cc", ".cxx", ".c", ".h"):
        if stem.lower().endswith(suf):
            stem = stem[: -len(suf)]
            break
    # Phase 2: in a load-only trace, return the PRECOMPUTED setter sites (a lookup + full_paths
    # filter, not the tree-sitter parse + node walk below). Disabled during the precompute build
    # (is_load_only() False). A miss (no blob / tail not precomputed / unusual full_paths) → live scan.
    if _CPP_SETTER_MAP_JOB is not None:
        try:
            from vbt.precompute import db_artifacts as _DA
            if _DA.is_load_only():
                from vbt.precompute.cpp_setter_map_db import load_cpp_setters
                _pre = load_cpp_setters(_CPP_SETTER_MAP_JOB, stem, variable, full_paths)
                if _pre is not None:
                    if _ck is not None:
                        if len(_SETTER_CACHE) >= _SETTER_CACHE_MAX:
                            _SETTER_CACHE.clear()
                        _SETTER_CACHE[_ck] = _pre
                    return _pre
        except Exception:
            pass
    src, tree = _src_and_tree(cpp_path)

    full_set = set(full_paths or [])
    full_chains = [_member_chain(p) for p in full_set]
    macro_notes = _macro_setter_notes(src, variable)   # A2 advisory (best-effort)
    out: List[SetterSite] = []

    for node in _setter_nodes(cpp_path, tree):
        lhs_node = rhs_node = None
        op = "="
        is_decl = False
        # Overrides for the non-assignment write shapes (builtin call / ++/--).
        # When ``instruction`` is set we skip the assignment-style chunk/value
        # synthesis and use these instead.
        instruction: Optional[str] = None
        value_override: Optional[str] = None
        chunk_override: Optional[str] = None
        prior_value = False

        if node.type == "assignment_expression":
            lhs_node = node.child_by_field_name("left")
            rhs_node = node.child_by_field_name("right")
            on = node.child_by_field_name("operator")
            op = _txt(on, src) if on else "="
        elif node.type == "init_declarator":
            # A1: the `declarator` field may be a pointer/reference/array/parenthesized
            # wrapper (``"* fieldPtr"``), so resolve to the inner name node before
            # tail-matching instead of using the raw wrapper text.
            lhs_node = _unwrap_declarator(node.child_by_field_name("declarator"))
            rhs_node = node.child_by_field_name("value")
            is_decl = True
        elif node.type == "call_expression":
            # ROOT-CAUSE fix: mem-write builtins (memcpy/memset/strcpy/sprintf/...)
            # write through arg0 (or arg1 for bcopy) but are call_expressions, so
            # the =-shaped discovery never recorded their destination field.
            callee = node.child_by_field_name("function")
            if callee is None or callee.type != "identifier":
                continue
            name = _txt(callee, src)
            if name not in MEM_WRITE_BUILTINS:
                continue
            arglist = node.child_by_field_name("arguments")
            if arglist is None:
                continue
            args = [c for c in arglist.children if c.is_named]
            dest_i = _MEM_WRITE_DEST_INDEX.get(name, 0)
            if dest_i >= len(args):
                continue
            lhs_node = _unwrap_dest_lvalue(args[dest_i])
            # Source operand(s): a single src arg, or (printf-family) everything
            # after the destination.
            src_i = _MEM_WRITE_SRC_INDEX.get(name, 1)
            if src_i is None:
                srcs = [_txt(a, src).strip() for j, a in enumerate(args) if j != dest_i]
                value_override = ", ".join(s for s in srcs if s) or None
            elif src_i < len(args):
                value_override = _txt(args[src_i], src).strip() or None
            instruction = f"builtin({name})"
            chunk_override = _txt(node, src).strip()
        elif node.type == "update_expression":
            # ROOT-CAUSE fix: ``p->f++`` / ``--p->f`` is a read-modify-write of a
            # member-path — a real write the =-shaped discovery also missed.
            operand = node.child_by_field_name("argument")
            if operand is None:
                continue
            lhs_node = _unwrap_dest_lvalue(operand)
            on = node.child_by_field_name("operator")
            op = _txt(on, src) if on else "++"
            # RMW: the prior value is itself a dependency of the new value.
            value_override = _txt(operand, src).strip() or None
            prior_value = True
            instruction = f"update({op})"
            chunk_override = _txt(node, src).strip()

        if lhs_node is None:
            continue

        # Raw LHS path: for assignments this is the member-access expression text
        # (``a.b.field``); for declarations it is the bare resolved name (``fieldPtr``);
        # for builtins/updates it is the unwrapped dest lvalue (``a.b.field``).
        lhs_path = _txt(lhs_node, src).strip()
        lhs_chain = _member_chain(lhs_path)
        tail = lhs_chain[-1] if lhs_chain else ""

        # Phase 2 precompute hook: collect EVERY setter tail this file produces (before the per-var
        # filter), so the precompute universe is driven by THIS engine's detection — not the narrower
        # modifier index. Additive; default None ⇒ no behavior change for the trace.
        if harvest_tails is not None and tail:
            harvest_tails.add(tail)

        # Tail (or explicit full-path) match gate.
        matched_explicit = lhs_path in full_set
        if tail != variable and not matched_explicit:
            continue

        # A3 consistency gate: when we know the qualified path(s), require the LHS
        # chain to be suffix-consistent with one of them.  An explicit full-path text
        # match always qualifies.  Skip the gate entirely when no full_paths are known
        # (preserve the historical permissive behavior, but tag scope so the consumer
        # can still disambiguate).
        if full_chains and not matched_explicit and not _matches_full_paths(lhs_chain, full_chains):
            continue

        if matched_explicit:
            match_scope = "qualified"
        elif len(lhs_chain) > 1:
            match_scope = "member"
        else:
            match_scope = "local"

        line = lhs_node.start_point[0] + 1
        fn = _enclosing_function(node, src)
        if instruction is not None:
            # builtin call / update_expression
            value = value_override
            chunk = chunk_override or lhs_path
            instr_text = instruction
        else:
            # assignment / declaration (unchanged)
            value = _txt(rhs_node, src).strip() if rhs_node is not None else None
            chunk = f"{lhs_path} {op} {value}" if value is not None else lhs_path
            instr_text = "define" if is_decl else f"assign({op})"
        site = SetterSite(
            variable=variable,
            file_stem=stem,
            language="cpp",
            line=line,
            instruction=instr_text,
            block_id=fn or "",
            function=fn,
            value=value,
            setter_code_chunk=chunk,
            constant_source=bool(value and "::" in value and not value.endswith(")")),
            prior_value_required=prior_value,
            is_declaration=is_decl,
        )
        # Dynamic (non-dataclass-field) disambiguation hints — additive, so no
        # interfaces.py change and no impact on existing consumers.
        site.match_scope = match_scope          # "qualified" | "member" | "local"
        site.lhs_path = lhs_path                 # full LHS text (already in chunk too)
        site.macro_setter_notes = macro_notes    # A2 advisory (may be empty)
        out.append(site)
    if _ck is not None:
        if len(_SETTER_CACHE) >= _SETTER_CACHE_MAX:
            _SETTER_CACHE.clear()
        _SETTER_CACHE[_ck] = out
    return out


# Cache of EVERY write in a file, as ``(lhs_chain, SetterSite)`` pairs, walked once
# (keyed on path + mtime + size). The per-file tree walk is the expensive part; the
# path-family descendant scan filters this cheaply per dependency, so re-scanning the
# same reachable files across many deps costs one walk per file, not one per (dep,file).
_FILE_WRITES_CACHE: Dict[str, "Tuple[Tuple[float, int], List[Tuple[List[str], SetterSite]]]"] = {}
_FILE_WRITES_CACHE_MAX = 4096   # 22k-OOM bound; FIFO-evict (sig-validated re-parse on miss ⇒ byte-identical)


def _file_writes(cpp_path: Path) -> List["Tuple[List[str], SetterSite]"]:
    """Every C++ write in ``cpp_path`` as ``(lhs_member_chain, SetterSite)`` (cached).

    Mirrors ``find_cpp_setters_in_file``'s write-shape detection (assignment / init /
    mem-write builtin / ``++``/``--``) but is variable-agnostic — it returns ALL writes,
    so callers filter by tail OR by path-prefix. Kept separate to avoid refactoring the
    load-bearing finder; the SetterSite carries ``variable`` = the write's own tail."""
    key = str(cpp_path)
    try:
        st = os.stat(key)
        sig = (st.st_mtime, st.st_size)
    except OSError:
        sig = (0.0, -1)
    cached = _FILE_WRITES_CACHE.get(key)
    if cached is not None and cached[0] == sig:
        return cached[1]

    stem = cpp_path.name
    for suf in (".cpp", ".hpp", ".cc", ".cxx", ".c", ".h"):
        if stem.lower().endswith(suf):
            stem = stem[: -len(suf)]
            break
    # Load-only: serve the PRECOMPUTED writes (a lookup, not the tree-sitter parse + node walk below).
    # Byte-identical (the stored list is exactly this function's output, in source order). A miss (no
    # blob / not load-only / build mode) falls through to the live parse. Cached in _FILE_WRITES_CACHE
    # under the same sig so the in-process cache + the prefix index behave identically to a live parse.
    if _CPP_FILE_WRITES_JOB is not None:
        try:
            from vbt.precompute import db_artifacts as _DA
            if _DA.is_load_only():
                from vbt.precompute.cpp_file_writes_db import load_cpp_file_writes
                _pre = load_cpp_file_writes(_CPP_FILE_WRITES_JOB, stem)
                if _pre is not None:
                    if len(_FILE_WRITES_CACHE) >= _FILE_WRITES_CACHE_MAX:
                        _FILE_WRITES_CACHE.pop(next(iter(_FILE_WRITES_CACHE)), None)
                    _FILE_WRITES_CACHE[key] = (sig, _pre)
                    return _pre
        except Exception:
            pass
    src, tree = _src_and_tree(cpp_path)
    out: List[Tuple[List[str], SetterSite]] = []

    for node in _iter(tree.root_node):
        lhs_node = rhs_node = None
        op = "="
        is_decl = False
        instruction: Optional[str] = None
        value_override: Optional[str] = None
        chunk_override: Optional[str] = None
        prior_value = False

        if node.type == "assignment_expression":
            lhs_node = node.child_by_field_name("left")
            rhs_node = node.child_by_field_name("right")
            on = node.child_by_field_name("operator")
            op = _txt(on, src) if on else "="
        elif node.type == "init_declarator":
            lhs_node = _unwrap_declarator(node.child_by_field_name("declarator"))
            rhs_node = node.child_by_field_name("value")
            is_decl = True
        elif node.type == "call_expression":
            callee = node.child_by_field_name("function")
            if callee is None or callee.type != "identifier":
                continue
            name = _txt(callee, src)
            if name not in MEM_WRITE_BUILTINS:
                continue
            arglist = node.child_by_field_name("arguments")
            if arglist is None:
                continue
            args = [c for c in arglist.children if c.is_named]
            dest_i = _MEM_WRITE_DEST_INDEX.get(name, 0)
            if dest_i >= len(args):
                continue
            lhs_node = _unwrap_dest_lvalue(args[dest_i])
            src_i = _MEM_WRITE_SRC_INDEX.get(name, 1)
            if src_i is None:
                srcs = [_txt(a, src).strip() for j, a in enumerate(args) if j != dest_i]
                value_override = ", ".join(s for s in srcs if s) or None
            elif src_i < len(args):
                value_override = _txt(args[src_i], src).strip() or None
            instruction = f"builtin({name})"
            chunk_override = _txt(node, src).strip()
        elif node.type == "update_expression":
            operand = node.child_by_field_name("argument")
            if operand is None:
                continue
            lhs_node = _unwrap_dest_lvalue(operand)
            on = node.child_by_field_name("operator")
            op = _txt(on, src) if on else "++"
            value_override = _txt(operand, src).strip() or None
            prior_value = True
            instruction = f"update({op})"
            chunk_override = _txt(node, src).strip()

        if lhs_node is None:
            continue
        lhs_path = _txt(lhs_node, src).strip()
        lhs_chain = _member_chain(lhs_path)
        if not lhs_chain:
            continue
        tail = lhs_chain[-1]
        line = lhs_node.start_point[0] + 1
        fn = _enclosing_function(node, src)
        if instruction is not None:
            value = value_override
            chunk = chunk_override or lhs_path
            instr_text = instruction
        else:
            value = _txt(rhs_node, src).strip() if rhs_node is not None else None
            chunk = f"{lhs_path} {op} {value}" if value is not None else lhs_path
            instr_text = "define" if is_decl else f"assign({op})"
        site = SetterSite(
            variable=tail, file_stem=stem, language="cpp", line=line,
            instruction=instr_text, block_id=fn or "", function=fn, value=value,
            setter_code_chunk=chunk,
            constant_source=bool(value and "::" in value and not value.endswith(")")),
            prior_value_required=prior_value, is_declaration=is_decl,
        )
        site.lhs_path = lhs_path
        out.append((lhs_chain, site))

    if len(_FILE_WRITES_CACHE) >= _FILE_WRITES_CACHE_MAX:
        _FILE_WRITES_CACHE.pop(next(iter(_FILE_WRITES_CACHE)), None)
    _FILE_WRITES_CACHE[key] = (sig, out)
    return out


# Per-file index of writes keyed by EVERY proper prefix of their LHS chain, so a path-family search
# (find_cpp_writes_under_path) is an O(matches) dict lookup instead of an O(all-writes) scan per call —
# a deep trace does 40k+ DISTINCT such searches. Byte-identical: a chain of length L is indexed under
# chain[:1..L-1] (exactly the old `len(chain) > n and chain[:n] == prefix` condition), and each prefix's
# list is appended in _file_writes ORDER, so the lookup yields the same sites in the same order the old
# linear filter did. Cached by path + (mtime, size); evicted entries rebuild cheaply from cached writes.
_WRITES_PREFIX_INDEX_CACHE: Dict[str, "Tuple[Tuple[float, int], Dict[tuple, List[Tuple[List[str], SetterSite]]]]"] = {}
_WRITES_PREFIX_INDEX_CACHE_MAX = 4096


def _writes_prefix_index(cpp_path: Path) -> "Dict[tuple, List[Tuple[List[str], SetterSite]]]":
    key = str(cpp_path)
    try:
        st = os.stat(key)
        sig = (st.st_mtime, st.st_size)
    except OSError:
        sig = (0.0, -1)
    cached = _WRITES_PREFIX_INDEX_CACHE.get(key)
    if cached is not None and cached[0] == sig:
        return cached[1]
    idx: Dict[tuple, List[Tuple[List[str], SetterSite]]] = {}
    for chain, site in _file_writes(cpp_path):          # _file_writes order ⇒ per-prefix order preserved
        for k in range(1, len(chain)):                  # proper prefixes only (descendants have len > k)
            idx.setdefault(tuple(chain[:k]), []).append((chain, site))
    if len(_WRITES_PREFIX_INDEX_CACHE) >= _WRITES_PREFIX_INDEX_CACHE_MAX:
        _WRITES_PREFIX_INDEX_CACHE.pop(next(iter(_WRITES_PREFIX_INDEX_CACHE)))
    _WRITES_PREFIX_INDEX_CACHE[key] = (sig, idx)
    return idx


_FILE_RETURNS_CACHE: Dict[str, "Tuple[Tuple[float, int], List[Tuple[str, int, str]]]"] = {}
_FILE_RETURNS_CACHE_MAX = 4096   # 22k-OOM bound; FIFO-evict (sig-validated re-parse on miss ⇒ byte-identical)


def _file_returns(cpp_path: Path) -> List["Tuple[str, int, str]"]:
    """Every `return` statement as ``(enclosing_function, line, return_expr_text)`` via
    **tree-sitter** (cached by path+mtime). A real parser — so it is robust where a regex
    or the truncating CFG are not: inline ``if (c) return x;``, multi-line returns, and
    returns past a collapsed switch are all found, and comments are never mis-read as
    returns (comment nodes simply aren't ``return_statement`` nodes)."""
    key = str(cpp_path)
    try:
        st = os.stat(key)
        sig = (st.st_mtime, st.st_size)
    except OSError:
        sig = (0.0, -1)
    cached = _FILE_RETURNS_CACHE.get(key)
    if cached is not None and cached[0] == sig:
        return cached[1]
    try:
        src, tree = _src_and_tree(cpp_path)
    except OSError:
        src = b""
        tree = _parser().parse(src)
    out: List[Tuple[str, int, str]] = []
    for node in _iter(tree.root_node):
        if node.type != "return_statement":
            continue
        expr_node = next((ch for ch in node.children if ch.is_named), None)
        expr = _txt(expr_node, src).strip() if expr_node is not None else ""
        fn = _enclosing_function(node, src) or ""
        out.append((fn, node.start_point[0] + 1, expr))
    if len(_FILE_RETURNS_CACHE) >= _FILE_RETURNS_CACHE_MAX:
        _FILE_RETURNS_CACHE.pop(next(iter(_FILE_RETURNS_CACHE)), None)
    _FILE_RETURNS_CACHE[key] = (sig, out)
    return out


def find_cpp_returns_in_function(cpp_path: str | Path, fn_name: str) -> List[Tuple[int, str]]:
    """``[(line, return_expr)]`` for every return in function ``fn_name`` (matched by
    exact or ``::``-qualified-boundary tail). Void ``return;`` yields ``""`` (caller
    skips). Tree-sitter based — robust, no regex, no CFG/span dependency."""
    tail = fn_name.split("::")[-1]
    return [(ln, expr) for (fn, ln, expr) in _file_returns(Path(cpp_path))
            if fn == fn_name or fn.split("::")[-1] == tail]


def find_cpp_writes_under_path(prefix_chain: List[str], cpp_path: str | Path) -> List[SetterSite]:
    """C++ writes whose LHS member-chain STRICTLY EXTENDS ``prefix_chain`` — the
    DESCENDANTS (sub-field writes) of a member-path dependency (path-family search).

    e.g. ``prefix_chain=['lwrIso','expirationDate','month']`` matches a write
    ``lwrIso.expirationDate.month.digit1 = …`` (chain extends the prefix) but NOT the
    field itself nor a sibling (``…expirationDate.year``). Cheap filter over the cached
    per-file write list; ``variable`` = the write's own tail, ``match_scope="descendant"``."""
    if not prefix_chain:
        return []
    matches = _writes_prefix_index(Path(cpp_path)).get(tuple(prefix_chain))
    if not matches:
        return []
    out: List[SetterSite] = []
    for _chain, site in matches:                  # already in _file_writes order ⇒ byte-identical
        site.match_scope = "descendant"
        out.append(site)
    return out
