"""Source lint: detect functions lexically commented out by an unterminated `/**`.

WHY
===
The extracted z/TPF source (``temp/asm``) occasionally drops the closing ``*/`` of a
doc comment, so the comment runs on until the NEXT ``*/`` and swallows the function
definition that followed it. Example — ``dw710000.cpp:732`` opens
``/** … #editCidInquiryInputs`` with no close; the next ``*/`` is at L782, so the whole
``editCidInquiryInputs`` body (its ``return Pa::Bad`` / ``return Pa::Good``) is one big
comment. Both VBT frontends then correctly see no function:

  * tree-sitter (modifier index) → a ``comment`` node, so ``files_defining_function`` is empty;
  * Clang LibTooling (cfg_extract) → no ``FunctionDecl`` (needs a real definition + body).

Net effect: the function is invisible to every lineage that touches it, and the engine
reports it as ``externalCall``. This is a DATA-QUALITY defect in the extraction, not a VBT
bug — so we **diagnose only** (report it for the extraction pipeline to fix) and never edit
source here. A corpus scan of ``temp/asm`` finds ~27 such functions across 8 files.

WHAT
====
A read-only, kb_id-free tree-sitter pass: any block (``/* … */``) ``comment`` node that
spans a real function DEFINITION (a non-prose signature line + a ``{`` body + a ``return``)
is flagged, one entry per swallowed function. Decoupled from the cached modifier index (a
separate parse) so the index artifact is untouched; parallel + deterministic at scale.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List

from vbt.setters.cpp_setters import _parser, _txt, _iter

# A non-prose, non-line-comment line that declares a function: optional storage
# specifiers, a (possibly qualified/templated) return type (group 1), then NAME( (group 2).
# Real swallowed code matches; doc-comment prose (`* @return …`) and `//`-commented
# examples are excluded by the prefix guard in _scan_text, and CONTROL-FLOW statements
# (`else if(...)`, `if DF_OK(...)`, `while(...)`) are excluded by _STMT_KEYWORDS below —
# without that, a swallowed function's body `if`s match as bogus "functions".
_SIG = re.compile(
    r"^\s*(?:static\s+|inline\s+|virtual\s+|extern\s+|const\s+)*"
    r"([A-Za-z_][\w:]*)(?:\s*<[^>]*>)?[\s*&]+([A-Za-z_]\w*)\s*\("
)
_LONE_BRACE = re.compile(r"^\s*\{")

# Statement / control-flow keywords that must NEVER appear as a return type OR a
# function name — their presence means the line is a statement, not a definition.
# (Type keywords like int/char/void are NOT here: they are legitimate return types.)
_STMT_KEYWORDS = frozenset({
    "if", "else", "for", "while", "do", "switch", "case", "default", "return",
    "break", "continue", "goto", "try", "catch", "throw", "sizeof", "new",
    "delete", "using", "namespace", "template", "typedef",
})

# A block comment shorter than this can't plausibly hide a function definition; cheap
# pre-filter. The structural checks below (signature + brace + return) are authoritative.
_MIN_COMMENT_LINES = 10
# How far below a signature line the opening `{` may sit. A long multi-line parameter
# list pushes the body brace down (e.g. accessHsmIVR's 11-param signature → `{` 12 lines
# later), so this must be generous; the keyword + signature-shape guards keep precision.
_BRACE_LOOKAHEAD = 20

_WORKER_PARSER = None   # per-process tree-sitter Parser (not picklable → lazy)


@dataclass
class SwallowedFn:
    """One function lexically commented out by an unterminated block comment."""
    file: str                 # bare basename, e.g. "dw710000.cpp"
    function: str             # the swallowed function's name
    function_line: int        # 1-based line of its signature
    comment_open_line: int    # 1-based line where the runaway `/*` opened
    comment_close_line: int   # 1-based line of the `*/` that finally closed it


def _scan_text(text: str, open_line: int, close_line: int, fname: str) -> List[SwallowedFn]:
    """Find function definitions swallowed inside one block-comment's text.

    ``text`` is the comment node's source (starts with ``/*``); ``open_line`` is its
    first line. A line is a swallowed definition iff it (a) is NOT doc-comment prose
    (doesn't start with ``*``) and NOT a ``//`` example, (b) matches ``_SIG``, and
    (c) is followed within a few lines by a lone ``{`` — i.e. a body, not a prototype.
    Requires a ``return`` somewhere in the comment to avoid flagging declaration-only
    blocks. One entry per matched function (a runaway comment may hide several)."""
    lines = text.split("\n")
    has_return = any("return" in ln for ln in lines)
    if not has_return:
        return []
    out: List[SwallowedFn] = []
    for i, ln in enumerate(lines):
        stripped = ln.lstrip()
        if stripped.startswith("*") or stripped.startswith("//") or stripped.startswith("/*"):
            continue                                  # doc-comment prose / example / the opener
        m = _SIG.match(ln)
        if not m:
            continue
        rettype, name = m.group(1), m.group(2)
        if rettype in _STMT_KEYWORDS or name in _STMT_KEYWORDS:
            continue                                  # a control-flow statement, not a definition
        if not any(_LONE_BRACE.match(lines[j])
                   for j in range(i + 1, min(i + 1 + _BRACE_LOOKAHEAD, len(lines)))):
            continue                                  # no body brace → a prototype/mention, skip
        out.append(SwallowedFn(file=fname, function=name, function_line=open_line + i,
                               comment_open_line=open_line, comment_close_line=close_line))
    return out


def scan_source_for_swallowed(path: str) -> List[SwallowedFn]:
    """Scan ONE C++ source file for functions swallowed by an unterminated block comment.

    Picklable worker (lazy per-process parser, mirroring modifier_index). Fault-isolated:
    a read/parse failure on one file returns ``[]`` rather than aborting a batch."""
    global _WORKER_PARSER
    try:
        src = Path(path).read_bytes()
        if _WORKER_PARSER is None:
            _WORKER_PARSER = _parser()
        tree = _WORKER_PARSER.parse(src)
    except Exception:
        return []
    fname = Path(path).name
    out: List[SwallowedFn] = []
    for node in _iter(tree.root_node):
        if node.type != "comment":
            continue
        open_line = node.start_point[0] + 1
        close_line = node.end_point[0] + 1
        if close_line - open_line < _MIN_COMMENT_LINES:
            continue
        text = _txt(node, src)
        if not text.startswith("/*"):                 # block comments only (multi-line)
            continue
        out += _scan_text(text, open_line, close_line, fname)
    return out


def scan_dir(asm_dir, *, parallel: bool = True) -> List[SwallowedFn]:
    """Scan every ``*.cpp`` in ``asm_dir``. Deterministic (sorted input + stable order)."""
    paths = [str(p) for p in sorted(Path(asm_dir).glob("*.cpp"))]
    results: List[List[SwallowedFn]] = []
    if parallel and len(paths) > 1:
        try:
            from vbt.precompute.parallel import parallel_map
            results = parallel_map(scan_source_for_swallowed, paths)
        except Exception:
            results = []
    if not results:
        results = [scan_source_for_swallowed(p) for p in paths]
    flat = [f for sub in (results or []) if sub for f in sub]
    flat.sort(key=lambda f: (f.file, f.function_line, f.function))
    return flat


def format_report(findings: List[SwallowedFn]) -> str:
    """Human WARN report. Empty findings → a clean one-liner."""
    if not findings:
        return "source lint: no functions swallowed by unterminated block comments."
    lines = [
        f"WARN: {f.file}: unterminated block comment at L{f.comment_open_line} "
        f"swallows {f.function} (L{f.function_line})"
        for f in findings
    ]
    n_files = len({f.file for f in findings})
    lines.append(f"  -> {len(findings)} function(s) across {n_files} file(s) "
                 f"commented out by unterminated block comments (fix at the source extraction).")
    return "\n".join(lines)


def write_json(findings: List[SwallowedFn], out_path) -> None:
    """Machine-readable report for the extraction-pipeline owner."""
    payload = {
        "swallowedFunctions": [asdict(f) for f in findings],
        "counts": {"functions": len(findings),
                   "files": len({f.file for f in findings})},
    }
    Path(out_path).write_text(json.dumps(payload, indent=2))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="python -m vbt.precompute.source_lint",
        description="Report C++ functions lexically commented out by an unterminated /** "
                    "block comment (an extraction defect; report-only, never edits source).")
    ap.add_argument("--asm-dir", required=True, type=Path, help="dir of .cpp source files")
    ap.add_argument("--json", type=Path, default=None, help="also write a JSON report here")
    ap.add_argument("--no-parallel", action="store_true", help="scan serially")
    a = ap.parse_args(argv)
    if not a.asm_dir.is_dir():
        sys.exit(f"--asm-dir not found: {a.asm_dir}")
    findings = scan_dir(a.asm_dir, parallel=not a.no_parallel)
    print(format_report(findings))
    if a.json:
        write_json(findings, a.json)
        print(f"\nwrote {a.json}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
