"""Truncation lint: detect functions whose Clang CFG stops before the function ends.

WHY
===
``cfg_extract`` (Clang ``CFG::buildCFG``) sometimes emits blocks only up to some line well
short of a function's real end, so every cfg-based step (conditions, value-pruning) goes
blind past that point. Two distinct causes, which need DIFFERENT remedies:

  * **brace-mismatch** — a stray/misplaced ``}`` in the migrated source closes the function
    early. tree-sitter (no types) ALSO stops at the same line. Example: ``dw710000.cpp``'s
    ``processACreditTransaction`` — a stray ``}`` near L1046 closes it at L1058, hiding the
    gate-3 ``switch`` (L1062) + its case-calls. Remedy: fix the source brace (then Clang
    recovers natively); until then the tree-sitter guard fallback covers conditions.
  * **unresolved-type** — the source is well-formed but a ``switch`` scrutinee's type is
    unresolved (missing header), so Clang can't model the switch and truncates there.
    tree-sitter parses the full body. Remedy: bring the header, or rely on the fallback.

This pass DIAGNOSES ONLY (never edits source). It reports, per truncated function: how
many lines are lost, an example lost construct, and the cause classification — so the
extraction pipeline can fix braces / supply headers, and so the engine knows which
functions lean on the tree-sitter condition fallback.

A function whose cfg ends early but has only comments/blank lines after it is BENIGN (it
just ends) and is NOT reported.
"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from vbt.cpp_frontend.wrapper import run_cfg_extract
from vbt.reach.fn_attr import function_starts
from vbt.setters.cpp_setters import _parser, _txt

_TS_PARSER = None
_MIN_BODY = 30          # ignore tiny functions (nothing meaningful to lose)
_MIN_LOST = 25          # cfg must stop at least this many lines before the true end
_TYPE_MARGIN = 20       # tree-sitter end this far past cfg-max ⇒ tree-sitter recovered it
_CLOSE_MARGIN = 15      # cfg-max within this of the tree-sitter function end ⇒ fully covered


@dataclass
class TruncatedFn:
    file: str
    function: str
    function_line: int      # 1-based start of the function
    cfg_max_line: int       # last line Clang's CFG covered
    true_end_line: int      # where the function really ends (next function start − 1)
    lost_lines: int         # true_end − cfg_max
    cause: str              # "brace-mismatch" | "unresolved-type"
    example_lost: str       # e.g. "switch_statement@1062"


def _ts_spans(src: bytes) -> Dict[str, Tuple[int, int]]:
    """name → (start_line, end_line) for every function_definition (last wins on dups)."""
    global _TS_PARSER
    if _TS_PARSER is None:
        _TS_PARSER = _parser()
    tree = _TS_PARSER.parse(src)
    out: Dict[str, Tuple[int, int]] = {}
    stack = [tree.root_node]
    while stack:
        n = stack.pop()
        if n.type == "function_definition":
            d = n.child_by_field_name("declarator")
            if d:
                nm = _txt(d, src).split("(")[0].strip().split()[-1].split("::")[-1]
                out[nm] = (n.start_point[0] + 1, n.end_point[0] + 1)
        stack.extend(n.children)
    return out


def _preproc_ranges(src: bytes) -> List[Tuple[int, int]]:
    """1-based inclusive line ranges inside ``#if/#ifdef/#ifndef … #endif`` blocks.

    Code Clang omits because a preprocessor condition was false (e.g. ``#if debug``) is
    NOT a truncation — Clang correctly drops disabled code, while tree-sitter (no
    preprocessing) still sees it. Excluding these ranges removes that false-positive
    class (confirmed on av200100.cpp PerformEmailMatching: the 'lost' call sits inside
    ``#if debug``)."""
    ranges: List[Tuple[int, int]] = []
    stack: List[int] = []
    for i, raw in enumerate(src.decode("utf-8", "replace").splitlines(), 1):
        s = raw.lstrip()
        if s.startswith("#"):
            d = s[1:].lstrip()
            if d.startswith(("if", "ifdef", "ifndef")):
                stack.append(i)
            elif d.startswith("endif") and stack:
                ranges.append((stack.pop(), i))
    return ranges


def _in_ranges(line: int, ranges: List[Tuple[int, int]]) -> bool:
    return any(lo <= line <= hi for lo, hi in ranges)


def _error_lines(src: bytes) -> List[int]:
    """Start lines of tree-sitter ERROR / MISSING nodes — a brace mis-nesting or other
    malformation leaves one here. Used to tell a genuine brace-truncation (the body
    really extends past the early parse end, with an error in the gap) apart from an
    inflated-``true_end`` false-positive (the function closes cleanly; the apparent gap
    is just the next, separately-undetected function)."""
    global _TS_PARSER
    if _TS_PARSER is None:
        _TS_PARSER = _parser()
    tree = _TS_PARSER.parse(src)
    out: List[int] = []
    stack = [tree.root_node]
    while stack:
        n = stack.pop()
        if n.type == "ERROR" or n.is_missing:
            out.append(n.start_point[0] + 1)
        stack.extend(n.children)
    return out


def _lost_construct(src: bytes, lo: int, hi: int,
                    disabled: Optional[List[Tuple[int, int]]] = None) -> Optional[str]:
    """First real control/call construct whose line is in (lo, hi] AND not inside a
    preprocessor-disabled region — proves LIVE code is lost. Returns ``"<type>@<line>"``
    or None (gap is only comments/blanks/conditionally-compiled code ⇒ benign)."""
    global _TS_PARSER
    if _TS_PARSER is None:
        _TS_PARSER = _parser()
    disabled = disabled if disabled is not None else _preproc_ranges(src)
    tree = _TS_PARSER.parse(src)
    best: Optional[Tuple[int, str]] = None
    stack = [tree.root_node]
    while stack:
        n = stack.pop()
        ln = n.start_point[0] + 1
        if (n.type in ("switch_statement", "call_expression", "if_statement",
                       "for_statement", "while_statement")
                and lo < ln <= hi and not _in_ranges(ln, disabled)):
            if best is None or ln < best[0]:
                best = (ln, n.type)
        stack.extend(n.children)
    return f"{best[1]}@{best[0]}" if best else None


def detect_in_file(path: str) -> List[TruncatedFn]:
    """Truncated functions in ONE .cpp. Fault-isolated: errors → []."""
    try:
        fns = run_cfg_extract(path)
        starts = sorted(function_starts(fns))
        if not starts:
            return []
        src = Path(path).read_bytes()
        n_lines = len(src.splitlines())
        ts = _ts_spans(src)
        disabled = _preproc_ranges(src)
        err_lines = _error_lines(src)
    except Exception:
        return []
    fname = Path(path).name
    # cfg max stmt line per function (original-case basename key)
    cfg_max: Dict[str, int] = {}
    for f in fns:
        nm = (f.get("function") or "").split("::")[-1]
        m = max([s.get("line") for b in f.get("cfg_blocks", []) for s in b.get("stmts", [])
                 if s.get("line")] or [0])
        cfg_max[nm] = max(cfg_max.get(nm, 0), m)
    bounds = [(starts[i][1].split("::")[-1], starts[i][0],
               (starts[i + 1][0] - 1 if i + 1 < len(starts) else n_lines))
              for i in range(len(starts))]
    out: List[TruncatedFn] = []
    for name, start, end in bounds:
        cm = cfg_max.get(name, 0)
        if not cm or (end - start) <= _MIN_BODY or (end - cm) <= _MIN_LOST:
            continue
        lost = _lost_construct(src, cm, end, disabled)
        if not lost:
            continue                # benign: comments/blanks or #if-disabled code only
        ts_end = ts.get(name, (0, 0))[1]
        # Drop inflated-true_end false-positives: the function closes cleanly at ts_end,
        # the cfg already reached it, AND there is no malformation in the apparent gap
        # (no ERROR past ts_end). Genuine brace-truncations keep ts_end early BUT carry an
        # ERROR in (ts_end, end] (the body truly extends further); genuine type-truncations
        # have cfg << ts_end. Either of those is retained.
        if (ts_end and cm >= ts_end - _CLOSE_MARGIN
                and not any(ts_end < e <= end for e in err_lines)):
            continue
        cause = "unresolved-type" if ts_end and ts_end > cm + _TYPE_MARGIN else "brace-mismatch"
        out.append(TruncatedFn(file=fname, function=name, function_line=start,
                               cfg_max_line=cm, true_end_line=end, lost_lines=end - cm,
                               cause=cause, example_lost=lost))
    return out


def scan_dir(asm_dir, *, parallel: bool = True) -> List[TruncatedFn]:
    paths = [str(p) for p in sorted(Path(asm_dir).glob("*.cpp"))]
    results: List[List[TruncatedFn]] = []
    if parallel and len(paths) > 1:
        try:
            from vbt.precompute.parallel import parallel_map
            results = parallel_map(detect_in_file, paths)
        except Exception:
            results = []
    if not results:
        results = [detect_in_file(p) for p in paths]
    flat = [t for sub in (results or []) if sub for t in sub]
    flat.sort(key=lambda t: (-t.lost_lines, t.file, t.function_line))
    return flat


def format_report(findings: List[TruncatedFn]) -> str:
    if not findings:
        return "truncation lint: no functions with CFG truncation losing code."
    lines = []
    for t in findings:
        lines.append(f"WARN: {t.file}: {t.function} (L{t.function_line}) — CFG stops at "
                     f"L{t.cfg_max_line}, body ends ~L{t.true_end_line} "
                     f"({t.lost_lines} lines lost, {t.cause}; e.g. {t.example_lost})")
    n_brace = sum(t.cause == "brace-mismatch" for t in findings)
    n_type = sum(t.cause == "unresolved-type" for t in findings)
    n_files = len({t.file for t in findings})
    lines.append(f"  -> {len(findings)} truncated function(s) across {n_files} file(s): "
                 f"{n_brace} brace-mismatch (fix source), {n_type} unresolved-type "
                 f"(bring header). Conditions in these regions use the tree-sitter fallback.")
    return "\n".join(lines)


def write_json(findings: List[TruncatedFn], out_path) -> None:
    payload = {
        "truncatedFunctions": [asdict(t) for t in findings],
        "counts": {
            "functions": len(findings),
            "files": len({t.file for t in findings}),
            "brace_mismatch": sum(t.cause == "brace-mismatch" for t in findings),
            "unresolved_type": sum(t.cause == "unresolved-type" for t in findings),
        },
    }
    Path(out_path).write_text(json.dumps(payload, indent=2))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="python -m vbt.precompute.truncation_lint",
        description="Report C++ functions whose Clang CFG truncates before the function "
                    "ends and loses real code (report-only; never edits source).")
    ap.add_argument("--asm-dir", required=True, type=Path, help="dir of .cpp source files")
    ap.add_argument("--json", type=Path, default=None, help="also write a JSON report here")
    ap.add_argument("--no-parallel", action="store_true", help="scan serially")
    a = ap.parse_args(argv)
    if not a.asm_dir.is_dir():
        sys.exit(f"--asm-dir not found: {a.asm_dir}")
    findings = scan_dir(a.asm_dir, parallel=not a.no_parallel)
    print(format_report(findings))
    if a.json:
        write_json(findings, a.json)
        print(f"\nwrote {a.json}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
