"""Phase 2 — per-file C++ setter map (precompute the tree-sitter parse + setter scan).

Mirror of the ASM setter-map (setter_map_db.py): per cpp stem, store the PERMISSIVE
(full_paths=None) output of the robust find_cpp_setters_in_file for every tail-field the modifier
index records, keyed by tail field name. A trace LOOKS IT UP and applies the full_paths filter at
trace time (the only full_paths-dependent part of the scan).

Byte-identical: stored sites are find_cpp_setters_in_file's verbatim output. At trace we replay the
EXACT filter (cpp_setters.py lines 514/523/526-531) reusing the real `_member_chain` /
`_matches_full_paths`, and recompute `match_scope` from the queried full_paths — `match_scope` is the
ONE emitted field that depends on full_paths, so it is NEVER stored (would be wrong for a qualified
query). `variable` is re-stamped to the queried tail (as ASM does). The dynamic attrs `lhs_path` /
`macro_setter_notes` are full_paths-independent and stored verbatim. A miss — or a full_paths entry
whose tail != the queried variable (the permissive bucket can't have served it) — returns None ⇒ the
caller falls back to the live scan (byte-identical). Per-stem blobs ⇒ lazy load. Lookups are gated on
load-only so the precompute build itself still parses + scans.
"""
from __future__ import annotations

import logging
from dataclasses import asdict, fields as _dc_fields
from pathlib import Path
from typing import Dict, List, Optional

from vbt.precompute import db_artifacts as DA
from vbt.interfaces import SetterSite

logger = logging.getLogger(__name__)

CPP_SETTER_MAP_ARTIFACT = "cpp_setter_map"        # per-stem blob: f"{ARTIFACT}:{stem}"

_LOADED: Dict[tuple, object] = {}                 # (job,stem) -> dict | None | sentinel 0
_LOADED_MAX = 4096
_SS_FIELDS = [f.name for f in _dc_fields(SetterSite)]


def _build_one_cpp_setter_map(args):
    """ProcessPool worker for cpp_setter_map: given (cpp_path_str, src_dir_str), parse the file,
    build the {tail: [SetterSite-dict]} map, and gzip-compress it. Returns (stem, payload_or_None).

    Each worker is independent: parses the cpp via tree-sitter, harvests _file_writes, runs
    _macro_setter_notes once per tail. The parent writes the blob (sqlite single-writer)."""
    import os
    cpp_path_str, _src_dir_str = args
    try:
        from pathlib import Path as _Path
        from dataclasses import asdict as _asdict
        from vbt.setters.cpp_setters import _file_writes, _macro_setter_notes, _src_and_tree
        from vbt.precompute import db_artifacts as _DA
        cpp_path = _Path(cpp_path_str)
        name = cpp_path.name
        stem = name
        for suf in (".cpp", ".hpp", ".cc", ".cxx", ".c", ".h"):
            if stem.lower().endswith(suf):
                stem = stem[: -len(suf)]
                break
        try:
            writes = _file_writes(cpp_path)
        except Exception:
            return (stem, None)
        m: Dict[str, list] = {}
        src_bytes = None
        macro_cache: Dict[str, list] = {}
        for lhs_chain, site in writes:
            tail = lhs_chain[-1] if lhs_chain else ""
            if not tail:
                continue
            d = _asdict(site)
            lp = getattr(site, "lhs_path", "")
            d["lhs_path"] = lp
            d["lhs_chain"] = lhs_chain
            if tail not in macro_cache:
                try:
                    if src_bytes is None:
                        src_bytes, _ = _src_and_tree(cpp_path)
                    macro_cache[tail] = _macro_setter_notes(src_bytes, tail)
                except Exception:
                    macro_cache[tail] = None
            d["macro_setter_notes"] = macro_cache[tail]
            m.setdefault(tail, []).append(d)
        if not m:
            return (stem, None)
        return (stem, _DA.dumps_gz(m))
    except Exception:
        return (os.path.basename(cpp_path_str), None)


def build_and_store_cpp_setter_map(job_id, blueprint_dir, asm_dir) -> int:
    """Build + store the per-stem C++ setter map. Returns the number of stems stored.

    Parallelized: each ProcessPool worker parses one .cpp via tree-sitter, harvests setter sites,
    and returns the gzip-compressed blob; the parent writes blobs serially (sqlite single-writer).
    Byte-identical to the serial path because each worker performs the same deterministic compute
    and the parent writes in INPUT-ORDERED sequence."""
    bp, src = Path(blueprint_dir), Path(asm_dir)
    DA.clear_blobs_prefix(job_id, CPP_SETTER_MAP_ARTIFACT + ":")
    paths = [(str(p), str(src)) for p in sorted(src.glob("*.cpp"))]
    try:
        from vbt.precompute.parallel import parallel_map
        results = parallel_map(_build_one_cpp_setter_map, paths)
    except Exception as exc:
        logger.debug("parallel cpp_setter_map fallback: %s", exc)
        results = [_build_one_cpp_setter_map(p) for p in paths]
    n = 0
    for stem, payload in results:
        if payload is None:
            continue
        try:
            if DA.write_blob(job_id, f"{CPP_SETTER_MAP_ARTIFACT}:{stem}", payload):
                n += 1
        except Exception as exc:
            logger.debug("store cpp_setter_map:%s failed: %s", stem, exc)
    return n


def load_cpp_setters(job_id, stem: str, variable: str,
                     full_paths: Optional[List[str]]) -> Optional[List[SetterSite]]:
    """Precomputed C++ setter sites for (stem, variable) under `full_paths`, or None ⇒ live scan.

    Replays find_cpp_setters_in_file's exact full_paths filter + match_scope, reusing the real
    `_member_chain`/`_matches_full_paths`. Byte-identical to the live scan for the production call
    pattern (variable == the tail of every full_paths entry)."""
    from vbt.setters.cpp_setters import _member_chain, _matches_full_paths
    fp = list(full_paths or [])
    # The permissive bucket only holds tail==variable sites; a full_paths entry whose tail differs
    # could need a site we didn't store (matched_explicit on a tail!=variable LHS) → fall back.
    for p in fp:
        ch = _member_chain(p)
        if ch and ch[-1] != variable:
            return None
    key = (job_id, stem)
    m = _LOADED.get(key, 0)
    if m == 0:
        payload = DA.read_blob(job_id, f"{CPP_SETTER_MAP_ARTIFACT}:{stem}")
        m = DA.loads_gz(payload) if payload is not None else None
        if len(_LOADED) >= _LOADED_MAX:
            _LOADED.pop(next(iter(_LOADED)))
        _LOADED[key] = m
    if not m:
        return None                               # no blob ⇒ stem not precomputed ⇒ live scan
    rows = m.get(variable)
    if rows is None:
        # The per-stem map is COMPLETE — the builder harvests EVERY setter tail the file produces — so
        # a tail absent from a PRESENT (non-empty) blob provably has NO setter here: the live scan would
        # return []. Return [] (not None) to SKIP that wasted tree-sitter scan. Byte-identical (verified:
        # every absent-tail miss in a depth-3/9 softCardValue trace returns live-empty, 0 violations).
        # This was the #1 cold-trace cost — ~72% of trace-time find_cpp_setters_in_file calls were such
        # empty scans (9.8s of a 16.4s cold trace funnelled through them).
        return []
    full_set = set(fp)
    full_chains = [_member_chain(p) for p in full_set]
    out: List[SetterSite] = []
    for d in rows:
        lhs_path = d.get("lhs_path", "")
        lhs_chain = d.get("lhs_chain") or _member_chain(lhs_path)
        matched_explicit = lhs_path in full_set                       # cpp_setters.py:514
        if full_chains and not matched_explicit and not _matches_full_paths(lhs_chain, full_chains):
            continue                                                  # cpp_setters.py:523
        if matched_explicit:                                          # cpp_setters.py:526-531
            match_scope = "qualified"
        elif len(lhs_chain) > 1:
            match_scope = "member"
        else:
            match_scope = "local"
        s = SetterSite(**{k: d[k] for k in _SS_FIELDS})
        s.variable = variable                                         # byte-identity (queried tail)
        s.match_scope = match_scope                                   # recomputed, never stored
        s.lhs_path = lhs_path
        s.macro_setter_notes = d.get("macro_setter_notes")
        out.append(s)
    return out
