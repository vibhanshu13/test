"""Our own lightweight, kb_id-free modifier index (var → files that write it).

A coarse candidate-file filter so the engine is self-contained (no ``candidate_stems``
input, no GVL). Setter detection is re-verified precisely later by the setter_finder;
this only narrows which files to look at.

  ASM: scan blueprint columnar flow for SETTER_INST destinations (glossary).
  C++: tree-sitter scan assignments/inits → LHS member-path tail (header-independent).

Cached per (blueprint_dir, asm_dir). Memory-light: only name→{stems}.

Setter SITES (not just files)
-----------------------------
The scan already visits every concrete setter site while accumulating
``files_for``, so we ALSO capture the site itself: ``var -> [(file_stem,
function_or_block, line, instruction)]``. A later trace can therefore start from
``sites_for(var)`` instead of reopening every candidate file with the precise
``find_{asm,cpp}_setters_in_file``. The sites are a *coarse* superset (the same
scan that powers ``files_for``); the precise setter finder still re-verifies and
may reject some (e.g. an ASM ``OC`` self-test). ``files_for`` is derived from the
sites so existing callers are unaffected.

Scaling (22k files)
-------------------
The naive build scans *every* ``*.asm.json``/``*.mac.json`` blueprint and *every*
``*.cpp`` on the first call — minutes of work, repeated for every fresh process.
Two mitigations live here:

* **Disk persistence.** The built index (``asm`` / ``cpp`` / ``functions`` dicts
  + the per-name site lists) is serialized to a compact JSON artifact under the
  VBT cache dir. The artifact is keyed on a *manifest hash* of the source set
  (every contributing file's name + size + mtime) and an artifact-version tag.
  On a hit we reload the artifact instead of rescanning; any add/remove/edit of a
  source file — or an artifact-version bump — changes the key and rebuilds.
* **Memory bound.** The build processes one blueprint / one cpp file at a time
  and releases its parsed form immediately. Only the ``name -> {stems}`` dicts
  and the (small per-name) site lists are retained, so peak RAM scales with the
  number of distinct written names, independent of total file count.
"""
from __future__ import annotations

import hashlib
import json
import os
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from backward_traversal.glossary.instructions import SETTER_INST, DEST_ARG_INDEX_BY_INST
from backward_traversal.utils.blueprint_utils import load_json
from backward_traversal.utils.token_utils import normalize_token

from vbt.setters.cpp_setters import (
    _parser, _txt, _iter, _last_component, _enclosing_function,
    _unwrap_dest_lvalue, MEM_WRITE_BUILTINS, _MEM_WRITE_DEST_INDEX,
)

_CACHE: Dict[Tuple[str, str], "ModifierIndex"] = {}

# Disk artifact location. Mirrors wrapper.py: VBT_CACHE_DIR overrides the base,
# default is vbt/.cache/index . modifier_index.py lives in vbt/precompute/, so
# vbt/ is two levels up.
_VBT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_DEFAULT_CACHE_DIR = os.path.join(_VBT_DIR, ".cache", "index")

# Bump if the artifact layout or scan semantics change (forces a rebuild).
# v2: artifact now carries per-name SETTER SITES (file, block, line, instruction)
#     in addition to the var -> {stems} dicts. Old v1 caches no longer match and
#     are rebuilt cleanly (the key embeds the version).
# v3: ASM scan gained a raw-SOURCE fallback for SETTER_INST sites whose columnar
#     flow["a"] operands are missing (e.g. MVC — empty in this parser's
#     blueprints). The index CONTENT changes (MVC-set vars now indexed), so the
#     version bump invalidates stale v2 caches and forces a rebuild.
# v4: C++ scan now recognizes mem-write BUILTIN calls (memcpy/memset/strcpy/
#     sprintf/... — dest is arg0/arg1) and member ++/-- (update_expression) as
#     setter sites — fields written ONLY via these were never indexed before
#     (e.g. serviceCode). The index CONTENT changes, so the bump invalidates v3.
# v5: ASM scan now resolves register-indirect DESTINATIONS (MVC 0(R1),SRC / ST R,d(Rn)
#     / OI d(Rn),mask ...) to the named field they write (the mirror of the source-side
#     register-indirect resolution), so a file writing a field ONLY through a register
#     pointer is indexed under that field — and the spurious "0" key the displacement
#     form used to produce is no longer indexed. Index CONTENT changes → invalidates v4.
_ARTIFACT_VERSION = 5


def _cache_dir() -> str:
    base = os.environ.get("VBT_CACHE_DIR")
    if base:
        return os.path.join(base, "index")
    return _DEFAULT_CACHE_DIR


@dataclass(frozen=True)
class SetterSiteRef:
    """A concrete setter site captured by the coarse index scan.

    Coarse (the same scan that powers ``files_for``): the precise setter finder
    re-verifies and may reject some of these. ``block`` is the ASM block id /
    C++ enclosing function (may be empty when unknown).
    """
    file_stem: str
    block: str
    line: int
    instruction: str

    def as_tuple(self) -> Tuple[str, str, int, str]:
        return (self.file_stem, self.block, self.line, self.instruction)


class ModifierIndex:
    def __init__(self) -> None:
        self.asm: Dict[str, Set[str]] = defaultdict(set)    # VAR_UPPER -> {stems}
        self.cpp: Dict[str, Set[str]] = defaultdict(set)    # field_tail -> {stems}
        self.functions: Dict[str, Set[str]] = defaultdict(set)  # fn_name -> {stems that DEFINE it}
        # Concrete setter sites, captured during the same scan as files_for.
        self.asm_sites: Dict[str, Set[SetterSiteRef]] = defaultdict(set)
        self.cpp_sites: Dict[str, Set[SetterSiteRef]] = defaultdict(set)

    def files_for(self, name: str, language: str) -> Set[str]:
        if language == "cpp":
            tail = name.split(".")[-1].split("->")[-1]
            return set(self.cpp.get(tail, set()))
        return set(self.asm.get(normalize_token(name), set()))

    def sites_for(self, name: str, language: str) -> List[SetterSiteRef]:
        """Concrete coarse setter sites for ``name``, in a stable (sorted) order.

        Lets a trace start from these sites instead of reopening every candidate
        file. The order is deterministic (sorted by file/line/instruction/block)
        so callers see a stable result across processes.
        """
        if language == "cpp":
            tail = name.split(".")[-1].split("->")[-1]
            sites = self.cpp_sites.get(tail, set())
        else:
            sites = self.asm_sites.get(normalize_token(name), set())
        return sorted(sites, key=lambda s: (s.file_stem, s.line, s.instruction, s.block))

    def files_defining_function(self, fn_name: str) -> Set[str]:
        return set(self.functions.get(fn_name.split("::")[-1], set()))


# --------------------------------------------------------------------------- #
# Per-file scan workers.
#
# Each worker scans ONE file and returns its small, picklable PARTIAL
# contribution (name -> stem, plus 4-tuple sites). The parent merges these by
# set-union, so the result is identical regardless of worker count or order.
# Workers parse one file and return only the tiny contribution — no parsed
# blueprint / parse tree ever crosses the IPC boundary (memory-bounded).
#
# Partial shape (all picklable):
#   { "asm":       { VAR_UPPER: stem },                 # one stem per file
#     "cpp":       { field_tail: stem },
#     "functions": { fn_name: stem },
#     "asm_sites": { VAR_UPPER: [ (stem, block, line, instr), ... ] },
#     "cpp_sites": { field_tail: [ (stem, fn, line, instr), ... ] } }
# A single file only ever contributes its own stem, so the name->stem maps hold
# at most one stem; the site lists may hold several rows for the same name.
# --------------------------------------------------------------------------- #
_EMPTY_PARTIAL: Dict[str, Dict] = {"asm": {}, "cpp": {}, "functions": {},
                                   "asm_sites": {}, "cpp_sites": {}}

# Per-worker tree-sitter parser (NOT picklable → instantiate lazily per process).
_WORKER_PARSER = None


def _scan_one_asm_partial(bp_path: Path, asm_dir: Optional[str] = None) -> Dict[str, Dict]:
    """Return the partial index contribution of a single ASM/MAC blueprint.

    Setter destinations normally come from the columnar ``flow["a"]`` operand
    args. Some SETTER_INST (notably ``MVC``) leave ``flow["a"]`` EMPTY in this
    parser's blueprints, so the destination would never be indexed. When the
    columnar args are missing/insufficient we FALL BACK to parsing the
    destination from the raw ``.asm`` SOURCE line (``flow["l"][k]``) with the
    proven paren-aware operand parser — the same one the precise setter finder
    uses — and filter it through ``is_dep_var_candidate`` so only a real named
    label (not a register / displacement form like ``0(R1)``) is indexed. The
    source file is read at most once per blueprint, and only when a fallback is
    actually needed.
    """
    from vbt.resolve.register_indirect import is_register_indirect
    from backward_traversal.utils.token_utils import is_dep_var_candidate
    asm: Dict[str, str] = {}
    asm_sites: Dict[str, list] = defaultdict(list)
    stem = bp_path.name.split(".")[0]
    try:
        bp = load_json(str(bp_path))
    except Exception:
        return {"asm": {}, "cpp": {}, "functions": {},
                "asm_sites": {}, "cpp_sites": {}}

    # Lazily-read, once-per-file source lines for the raw fallback (only loaded
    # when a SETTER_INST site has no usable columnar args). ``None`` until read,
    # an empty list if unreadable (so we don't retry).
    _src_lines: Optional[List[str]] = None

    def _source_lines() -> List[str]:
        nonlocal _src_lines
        if _src_lines is None:
            _src_lines = []
            if asm_dir:
                try:
                    _src_lines = (Path(asm_dir) / f"{stem}.asm").read_text(
                        encoding="utf-8", errors="replace"
                    ).splitlines()
                except OSError:
                    _src_lines = []
        return _src_lines

    for block in (bp.get("blocks") or []):
        bid = str(block.get("id") or "")
        f = block.get("flow") or {}
        insts, argcol = f.get("i") or [], f.get("a") or []
        lines = f.get("l") or []   # per-instruction source line (parallel to i/a)
        for k, inst in enumerate(insts):
            mn = str(inst or "").upper()
            if mn not in SETTER_INST:
                continue
            args = argcol[k] if k < len(argcol) and isinstance(argcol[k], list) else []
            di = DEST_ARG_INDEX_BY_INST.get(mn, 0)
            ln = lines[k] if k < len(lines) else 0
            try:
                ln = int(ln)
            except (TypeError, ValueError):
                ln = 0
            if di < len(args):
                # Columnar path (OI/ST/etc.). A register-indirect destination
                # (``0(R1)`` etc.) does NOT name the field — skip it here (it used to be
                # indexed as the spurious key ``0``); it is resolved to its real field by
                # the once-per-file register-indirect-dest pass below.
                if is_register_indirect(str(args[di])):
                    continue
                dest = normalize_token(str(args[di]))
                # Gate on is_dep_var_candidate (as the raw-source branch already does), so
                # a comment-mangled columnar arg that normalizes to garbage (e.g. ``0``)
                # is not indexed as a spurious "variable".
                if dest and is_dep_var_candidate(dest):
                    asm[dest] = stem
                    asm_sites[dest].append((stem, bid, ln, mn))
                continue
            # Fallback: columnar args missing/insufficient (e.g. MVC). Recover
            # the destination from the raw source line with the proven parser.
            if ln <= 0:
                continue
            src = _source_lines()
            if not (0 < ln <= len(src)):
                continue
            from backward_traversal.tracing.asm_backward_tracer import _parse_raw_operands
            operands = _parse_raw_operands(src[ln - 1], mn)
            if di >= len(operands):
                continue
            # Reduce the raw destination to its base label first (normalize_token
            # strips length/base qualifiers: EBW000(L'AJ84EBWS) -> EBW000,
            # 0(R1) -> 0), then vet THAT with is_dep_var_candidate. Vetting the
            # raw operand would wrongly reject a legitimate length-qualified label
            # like EBW000(L'AJ84EBWS) on the embedded L'-apostrophe, while still
            # rejecting register / displacement forms (0(R1), (R13)) — exactly the
            # garbage we must keep out.
            dest = normalize_token(str(operands[di]))
            if dest and is_dep_var_candidate(dest) and not is_register_indirect(str(operands[di])):
                asm[dest] = stem
                asm_sites[dest].append((stem, bid, ln, mn))

    # Register-indirect DESTINATIONS (MVC 0(R1),SRC / ST R,d(Rn) / OI d(Rn),mask ...):
    # resolve the dest register to the named field it writes, so a file writing a field
    # ONLY through a register pointer becomes a candidate for that field. Mirror of the
    # source-side register-indirect resolution; bounded + sound (gives up, never guesses).
    # Defensive: a resolution failure must never break the whole index build.
    try:
        from vbt.resolve.register_indirect import resolve_indirect_dest_writes
        _adir = Path(asm_dir) if asm_dir else None
        for field, ln2, bid2, inst2, _src in resolve_indirect_dest_writes(
                bp, str(bp_path), stem, asm_dir=_adir):
            asm[field] = stem
            asm_sites[field].append((stem, bid2, ln2, inst2))
    except Exception:
        pass

    return {"asm": asm, "cpp": {}, "functions": {},
            "asm_sites": dict(asm_sites), "cpp_sites": {}}


def _scan_one_cpp_partial(cpp: Path) -> Dict[str, Dict]:
    """Return the partial index contribution of a single cpp source file.

    Instantiates the (non-picklable) tree-sitter parser lazily, once per worker
    process, and reuses it for every file that worker handles.
    """
    global _WORKER_PARSER
    cpp_map: Dict[str, str] = {}
    functions: Dict[str, str] = {}
    cpp_sites: Dict[str, list] = defaultdict(list)
    try:
        src = cpp.read_bytes()
        if _WORKER_PARSER is None:
            _WORKER_PARSER = _parser()
        tree = _WORKER_PARSER.parse(src)
    except Exception:
        return {"asm": {}, "cpp": {}, "functions": {},
                "asm_sites": {}, "cpp_sites": {}}
    stem = cpp.stem
    for node in _iter(tree.root_node):
        if node.type == "function_definition":
            n = node.child_by_field_name("declarator")
            while n is not None:
                if n.type in ("identifier", "field_identifier", "qualified_identifier",
                              "destructor_name", "operator_name"):
                    functions[_txt(n, src).split("::")[-1]] = stem
                    break
                n = n.child_by_field_name("declarator")
            continue
        lhs = None
        is_decl = False
        instr = "assign"
        if node.type == "assignment_expression":
            lhs = node.child_by_field_name("left")
        elif node.type == "init_declarator":
            lhs = node.child_by_field_name("declarator")
            is_decl = True
            instr = "define"
        elif node.type == "call_expression":
            # Same mem-write builtin recognition as find_cpp_setters_in_file:
            # the dest field (arg0, or arg1 for bcopy) is the written variable.
            callee = node.child_by_field_name("function")
            if callee is None or callee.type != "identifier":
                continue
            name = _txt(callee, src)
            if name not in MEM_WRITE_BUILTINS:
                continue
            arglist = node.child_by_field_name("arguments")
            if arglist is None:
                continue
            args = [c for c in arglist.children if c.is_named]
            dest_i = _MEM_WRITE_DEST_INDEX.get(name, 0)
            if dest_i >= len(args):
                continue
            lhs = _unwrap_dest_lvalue(args[dest_i])
            instr = f"builtin({name})"
        elif node.type == "update_expression":
            # ``p->f++`` / ``--p->f`` — a RMW write of a member-path field.
            operand = node.child_by_field_name("argument")
            if operand is None:
                continue
            lhs = _unwrap_dest_lvalue(operand)
            on = node.child_by_field_name("operator")
            instr = f"update({_txt(on, src) if on else '++'})"
        if lhs is None:
            continue
        tail = _last_component(_txt(lhs, src))
        if tail and tail.isidentifier():
            cpp_map[tail] = stem
            line = lhs.start_point[0] + 1
            fn = _enclosing_function(node, src) or ""
            cpp_sites[tail].append((stem, fn, line, instr))
    return {"asm": {}, "cpp": cpp_map, "functions": functions,
            "asm_sites": {}, "cpp_sites": dict(cpp_sites)}


def _scan_one_partial(path_str: str, asm_dir: Optional[str] = None) -> Dict[str, Dict]:
    """Top-level dispatcher (picklable): scan one file by PATH string.

    Routed by extension so the worker only needs string arguments. ``asm_dir``
    (a string for picklability) lets the ASM scan fall back to the raw source
    for SETTER_INST sites whose columnar ``flow["a"]`` is empty (e.g. MVC).
    """
    p = Path(path_str)
    name = p.name
    if name.endswith(".asm.json") or name.endswith(".mac.json"):
        return _scan_one_asm_partial(p, asm_dir)
    if name.endswith(".cpp"):
        return _scan_one_cpp_partial(p)
    return {"asm": {}, "cpp": {}, "functions": {}, "asm_sites": {}, "cpp_sites": {}}


def _merge_partial(idx: ModifierIndex, partial: Dict[str, Dict]) -> None:
    """Merge one worker partial into ``idx`` by set-union (order-independent)."""
    for name, stem in (partial.get("asm") or {}).items():
        idx.asm[name].add(stem)
    for name, stem in (partial.get("cpp") or {}).items():
        idx.cpp[name].add(stem)
    for name, stem in (partial.get("functions") or {}).items():
        idx.functions[name].add(stem)
    for name, rows in (partial.get("asm_sites") or {}).items():
        idx.asm_sites[name].update(SetterSiteRef(*r) for r in rows)
    for name, rows in (partial.get("cpp_sites") or {}).items():
        idx.cpp_sites[name].update(SetterSiteRef(*r) for r in rows)


def _source_files(blueprint_dir: Path, asm_dir: Path) -> List[Path]:
    """Every file that contributes to the index, in a stable order."""
    files: List[Path] = []
    for pat in ("*.asm.json", "*.mac.json"):
        files.extend(blueprint_dir.glob(pat))
    files.extend(asm_dir.glob("*.cpp"))
    return sorted(files, key=lambda p: str(p))


def _manifest_hash(files: List[Path]) -> str:
    """Fingerprint the source set: per-file (path, size, mtime).

    Add/remove/edit any contributing file → hash changes → rebuild. Cheap:
    one ``stat`` per file, no content read.
    """
    h = hashlib.sha256()
    h.update(f"v{_ARTIFACT_VERSION}\n".encode("utf-8"))
    for p in files:
        try:
            st = p.stat()
            meta = f"{p}\x00{st.st_size}\x00{st.st_mtime_ns}"
        except OSError:
            meta = f"{p}\x00?\x00?"
        h.update(meta.encode("utf-8"))
        h.update(b"\n")
    return h.hexdigest()


def _artifact_path(blueprint_dir: Path, asm_dir: Path, manifest: str) -> str:
    # Disambiguate dirs (so two corpora never collide) without embedding the
    # full path in the filename: short hash of the dir pair + the manifest.
    dir_key = hashlib.sha256(
        f"{blueprint_dir}\x00{asm_dir}".encode("utf-8")
    ).hexdigest()[:16]
    return os.path.join(_cache_dir(), f"modidx-{dir_key}-{manifest[:32]}.json")


def _artifact_load(path: str) -> Optional[ModifierIndex]:
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    if data.get("version") != _ARTIFACT_VERSION:
        return None     # stale layout — force a rebuild
    idx = ModifierIndex()
    for attr in ("asm", "cpp", "functions"):
        section = data.get(attr) or {}
        if not isinstance(section, dict):
            return None
        target = getattr(idx, attr)
        for name, stems in section.items():
            target[name] = set(stems)
    for attr, section_key in (("asm_sites", "asm_sites"), ("cpp_sites", "cpp_sites")):
        section = data.get(section_key) or {}
        if not isinstance(section, dict):
            return None
        target = getattr(idx, attr)
        for name, rows in section.items():
            target[name] = {
                SetterSiteRef(str(r[0]), str(r[1]), int(r[2]), str(r[3]))
                for r in rows if isinstance(r, (list, tuple)) and len(r) == 4
            }
    return idx


def _artifact_store(path: str, idx: ModifierIndex) -> None:
    """Atomically persist the index (files + sites) as sorted, stable rows. Best-effort."""
    def _sorted_sites(d: Dict[str, Set[SetterSiteRef]]):
        return {
            k: sorted((s.as_tuple() for s in v),
                      key=lambda t: (t[0], t[2], t[3], t[1]))
            for k, v in d.items()
        }
    payload = {
        "version": _ARTIFACT_VERSION,
        "asm": {k: sorted(v) for k, v in idx.asm.items()},
        "cpp": {k: sorted(v) for k, v in idx.cpp.items()},
        "functions": {k: sorted(v) for k, v in idx.functions.items()},
        "asm_sites": _sorted_sites(idx.asm_sites),
        "cpp_sites": _sorted_sites(idx.cpp_sites),
    }
    try:
        os.makedirs(_cache_dir(), exist_ok=True)
        tmp = f"{path}.{os.getpid()}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh)
        os.replace(tmp, path)
    except OSError:
        pass


def _build_index(blueprint_dir: Path, asm_dir: Path, files: List[Path]) -> ModifierIndex:
    """Memory-bounded build: scan each file (in parallel when planned), then MERGE.

    Each worker scans ONE file and returns a tiny picklable PARTIAL (no parsed
    blueprint / parse tree crosses IPC). The parent merges by set-union — so the
    result is byte/content-IDENTICAL to a serial build regardless of worker
    count or completion order. The disk artifact is still written ONCE by the
    parent (see ``get_modifier_index``).
    """
    import functools

    from vbt.precompute.parallel import parallel_map

    idx = ModifierIndex()
    # Pass PATH STRINGS (picklable) in stable order; results are input-ordered.
    # ``asm_dir`` is bound via functools.partial (picklable under fork + spawn,
    # since both the worker fn and the partial's arg are module-level/strings) so
    # the ASM scan can fall back to the raw source for MVC-style setters.
    worker = functools.partial(_scan_one_partial, asm_dir=str(asm_dir))
    partials = parallel_map(worker, [str(f) for f in files])
    for partial in partials:
        _merge_partial(idx, partial)
    return idx


def get_modifier_index(blueprint_dir: Path, asm_dir: Path) -> ModifierIndex:
    blueprint_dir, asm_dir = Path(blueprint_dir), Path(asm_dir)
    key = (str(blueprint_dir), str(asm_dir))
    cached = _CACHE.get(key)
    if cached is not None:
        return cached

    files = _source_files(blueprint_dir, asm_dir)
    manifest = _manifest_hash(files)
    artifact = _artifact_path(blueprint_dir, asm_dir, manifest)

    idx = _artifact_load(artifact)
    if idx is None:
        idx = _build_index(blueprint_dir, asm_dir, files)
        _artifact_store(artifact, idx)

    _CACHE[key] = idx
    return idx
