"""Direct dep-var relations for load-only traces.

This module intentionally precomputes only *direct* facts:

* C++ field tail -> direct setter sites.
* C++ callee tail -> direct call sites with argument expressions.
* ASM normalized variable -> direct setter sites plus stem coverage.

It does not precompute transitive reachability or recursive dependent-variable
trees. Trace-time code still applies the existing chain-scope, route-reachability,
condition, and depth filters, so the JSON output remains controlled by the same
logic as the live path. Missing artifacts return ``None`` and callers fall back
to the old live scans.
"""
from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import asdict, fields as _dc_fields
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

from vbt.interfaces import SetterSite
from vbt.precompute import db_artifacts as DA
from backward_traversal.utils.token_utils import normalize_token

logger = logging.getLogger(__name__)

DEPVAR_DIRECT_ARTIFACT = "depvar_direct"
CPP_SETTER_INDEX_PREFIX = "depvar_cpp_setters:"
CPP_CALLSITE_INDEX_PREFIX = "depvar_cpp_callsites:"
ASM_SETTER_INDEX_PREFIX = "depvar_asm_setters:"
ASM_SCANNED_STEMS_BLOB = "depvar_asm_scanned_stems"
DEPVAR_DIRECT_VERSION = 2

_SS_FIELDS = [f.name for f in _dc_fields(SetterSite)]
_SETTER_LOADED: Dict[tuple, object] = {}
_CALLSITE_LOADED: Dict[tuple, object] = {}
_SETTER_GROUPED: Dict[tuple, object] = {}
_CALLSITE_GROUPED: Dict[tuple, object] = {}
_ASM_SETTER_LOADED: Dict[tuple, object] = {}
_ASM_SETTER_GROUPED: Dict[tuple, object] = {}
_ASM_SCANNED_STEMS: Dict[str, object] = {}
_READY: Dict[str, bool] = {}
_VERSION: Dict[str, int] = {}
_LOADED_MAX = 4096


def _artifact_ready(job_id: Optional[str]) -> bool:
    if not job_id or not DA.is_load_only():
        return False
    key = str(job_id)
    if key not in _READY:
        man = DA.read_manifest(job_id, DEPVAR_DIRECT_ARTIFACT)
        _VERSION[key] = int((man or {}).get("version") or 0)
        _READY[key] = bool(man and _VERSION[key] >= 1)
    return _READY[key]


def _artifact_version(job_id: Optional[str]) -> int:
    if not _artifact_ready(job_id):
        return 0
    return int(_VERSION.get(str(job_id), 0))


def _tail(name: str) -> str:
    return str(name or "").split("::")[-1].split(".")[-1].split("->")[-1]


def _asm_key(name: str) -> str:
    return normalize_token(str(name or "")).upper()


def _load_tail_blob(cache: Dict[tuple, object], job_id: str, prefix: str, tail: str):
    key = (job_id, prefix, tail)
    val = cache.get(key, 0)
    if val == 0:
        payload = DA.read_blob(job_id, prefix + tail)
        val = DA.loads_gz(payload) if payload is not None else []
        if len(cache) >= _LOADED_MAX:
            cache.pop(next(iter(cache)))
        cache[key] = val
    return val


def _load_grouped_tail_blob(
    rows_cache: Dict[tuple, object],
    grouped_cache: Dict[tuple, object],
    job_id: str,
    prefix: str,
    tail: str,
    stem_field: str,
) -> Dict[str, list]:
    key = (job_id, prefix, tail)
    grouped = grouped_cache.get(key, 0)
    if grouped != 0:
        return grouped
    rows = _load_tail_blob(rows_cache, job_id, prefix, tail)
    out: Dict[str, list] = defaultdict(list)
    for row in rows or []:
        stem = str(row.get(stem_field) or "")
        if stem:
            out[stem].append(row)
    if len(grouped_cache) >= _LOADED_MAX:
        grouped_cache.pop(next(iter(grouped_cache)))
    grouped_cache[key] = out
    return out


def _cpp_source_files(asm_dir: Path) -> List[Path]:
    return sorted(Path(asm_dir).glob("*.cpp"))


def _asm_blueprint_files(blueprint_dir: Path) -> List[Path]:
    bp = Path(blueprint_dir)
    return sorted(list(bp.glob("*.asm.json")) + list(bp.glob("*.mac.json")))


def _asm_source_files(asm_dir: Path) -> List[Path]:
    src = Path(asm_dir)
    return sorted(list(src.glob("*.asm")) + list(src.glob("*.mac")))


def _row_to_setter(row: dict, variable: str, full_paths: Optional[Sequence[str]]) -> Optional[SetterSite]:
    """Reconstruct one row and replay the exact full-path filter from
    ``cpp_setter_map_db.load_cpp_setters``."""
    from vbt.setters.cpp_setters import _member_chain, _matches_full_paths

    fp = list(full_paths or [])
    full_set = set(fp)
    full_chains = [_member_chain(p) for p in full_set]
    lhs_path = row.get("lhs_path", "")
    lhs_chain = row.get("lhs_chain") or _member_chain(lhs_path)
    matched_explicit = lhs_path in full_set
    if full_chains and not matched_explicit and not _matches_full_paths(lhs_chain, full_chains):
        return None
    if matched_explicit:
        match_scope = "qualified"
    elif len(lhs_chain) > 1:
        match_scope = "member"
    else:
        match_scope = "local"
    s = SetterSite(**{k: row.get(k) for k in _SS_FIELDS})
    s.variable = variable
    s.match_scope = match_scope
    s.lhs_path = lhs_path
    s.macro_setter_notes = row.get("macro_setter_notes")
    return s


def _row_to_asm_setter(row: dict, variable: str) -> SetterSite:
    s = SetterSite(**{k: row.get(k) for k in _SS_FIELDS})
    s.variable = variable
    return s


def load_cpp_setters_for_candidates(
    job_id: Optional[str],
    variable: str,
    full_paths: Optional[Sequence[str]],
    candidate_stems: Iterable[str],
) -> Optional[List[SetterSite]]:
    """Direct C++ setter sites for ``variable`` in ``candidate_stems``.

    ``None`` means the direct artifact is absent/not armed and the caller must
    run the old per-file scan. ``[]`` is an authoritative no-setters result when
    the artifact is present.
    """
    if not _artifact_ready(job_id):
        return None
    tail = _tail(variable)
    # Match cpp_setter_map_db's fallback condition: an explicit full path whose
    # tail differs from the queried variable may need a bucket we did not store.
    for p in full_paths or ():
        if _tail(p) != tail:
            return None
    grouped = _load_grouped_tail_blob(
        _SETTER_LOADED, _SETTER_GROUPED, str(job_id), CPP_SETTER_INDEX_PREFIX, tail, "file_stem")
    if not grouped:
        return []
    cand = {str(s) for s in candidate_stems}
    out: List[SetterSite] = []
    for stem in sorted(cand):
        for row in grouped.get(stem, ()):
            site = _row_to_setter(row, tail, full_paths)
            if site is not None:
                out.append(site)
    return out


def _load_asm_var_blob(job_id: str, key_name: str) -> Optional[dict]:
    key = (job_id, ASM_SETTER_INDEX_PREFIX, key_name)
    val = _ASM_SETTER_LOADED.get(key, 0)
    if val == 0:
        payload = DA.read_blob(job_id, ASM_SETTER_INDEX_PREFIX + key_name)
        val = DA.loads_gz(payload) if payload is not None else None
        if len(_ASM_SETTER_LOADED) >= _LOADED_MAX:
            _ASM_SETTER_LOADED.pop(next(iter(_ASM_SETTER_LOADED)))
        _ASM_SETTER_LOADED[key] = val
    return val


def _load_asm_grouped_rows(job_id: str, key_name: str) -> Dict[str, list]:
    key = (job_id, ASM_SETTER_INDEX_PREFIX, key_name)
    grouped = _ASM_SETTER_GROUPED.get(key, 0)
    if grouped != 0:
        return grouped
    data = _load_asm_var_blob(job_id, key_name) or {}
    out: Dict[str, list] = defaultdict(list)
    for row in data.get("rows") or []:
        stem = str(row.get("file_stem") or "")
        if stem:
            out[stem].append(row)
    if len(_ASM_SETTER_GROUPED) >= _LOADED_MAX:
        _ASM_SETTER_GROUPED.pop(next(iter(_ASM_SETTER_GROUPED)))
    _ASM_SETTER_GROUPED[key] = out
    return out


def _load_asm_scanned_stems(job_id: str) -> Optional[Set[str]]:
    if _artifact_version(job_id) < 2:
        return None
    val = _ASM_SCANNED_STEMS.get(job_id, 0)
    if val == 0:
        payload = DA.read_blob(job_id, ASM_SCANNED_STEMS_BLOB)
        val = set(DA.loads_gz(payload) or []) if payload is not None else None
        _ASM_SCANNED_STEMS[job_id] = val
    return val


def load_asm_setters_for_candidates(
    job_id: Optional[str],
    variable: str,
    candidate_stems: Iterable[str],
) -> Optional[Tuple[Dict[str, List[SetterSite]], Set[str]]]:
    """Direct ASM setter sites for ``variable`` grouped by candidate stem.

    Returns ``None`` when the artifact cannot answer anything and the caller must
    run the old full scan. Otherwise returns ``(by_stem, missing_stems)``.
    ``missing_stems`` are candidate stems not covered by this direct build; callers
    must live-scan only those stems to preserve output for incomplete coverage.
    """
    if not _artifact_ready(job_id):
        return None
    key_name = _asm_key(variable)
    if not key_name:
        return None
    cand = {str(s) for s in candidate_stems}
    scanned = _load_asm_scanned_stems(str(job_id))
    data = _load_asm_var_blob(str(job_id), key_name)
    if data is None:
        if scanned is None:
            return None
        covered_empty = cand & scanned
        return {stem: [] for stem in sorted(covered_empty)}, cand - scanned
    covered = {str(s) for s in (data.get("covered") or [])}
    if scanned is not None:
        covered |= (cand & scanned)
    missing = cand - covered
    grouped = _load_asm_grouped_rows(str(job_id), key_name)
    by_stem: Dict[str, List[SetterSite]] = {}
    for stem in sorted(cand & covered):
        rows = grouped.get(stem, ())
        by_stem[stem] = [_row_to_asm_setter(row, variable) for row in rows]
    return by_stem, missing


def load_cpp_callsites_for_callee(
    job_id: Optional[str],
    callee_tail: str,
    candidate_stems: Iterable[str],
) -> Optional[List[dict]]:
    """Direct C++ call sites for a callee tail, filtered to candidate stems.

    Rows are returned in the same order as the old scan: sorted source stem, then
    CFG function/call order within that stem.
    """
    if not _artifact_ready(job_id):
        return None
    grouped = _load_grouped_tail_blob(
        _CALLSITE_LOADED, _CALLSITE_GROUPED, str(job_id), CPP_CALLSITE_INDEX_PREFIX,
        _tail(callee_tail), "stem"
    )
    if not grouped:
        return []
    cand = {str(s) for s in candidate_stems}
    out: List[dict] = []
    for stem in sorted(cand):
        out.extend(dict(r) for r in grouped.get(stem, ()))
    return out


def _load_precomputed_cpp_setter_rows(job_id: Optional[str], stem: str) -> Optional[Dict[str, list]]:
    if not job_id:
        return None
    try:
        from vbt.precompute.cpp_setter_map_db import CPP_SETTER_MAP_ARTIFACT
        payload = DA.read_blob(job_id, f"{CPP_SETTER_MAP_ARTIFACT}:{stem}")
        if payload is None:
            return None
        data = DA.loads_gz(payload)
        return {str(tail): [dict(r) for r in rows] for tail, rows in (data or {}).items()}
    except Exception:
        return None


def _load_precomputed_asm_setter_rows(job_id: Optional[str], stem: str) -> Optional[Dict[str, list]]:
    if not job_id:
        return None
    try:
        from vbt.precompute.setter_map_db import ASM_SETTER_MAP_ARTIFACT
        payload = DA.read_blob(job_id, f"{ASM_SETTER_MAP_ARTIFACT}:{stem}")
        if payload is None:
            return None
        data = DA.loads_gz(payload)
        return {_asm_key(var): [dict(r) for r in rows] for var, rows in (data or {}).items()}
    except Exception:
        return None


def _build_one_cpp_direct(args):
    """Build direct rows for one C++ file. Pickle-safe."""
    from vbt.cpp_frontend.wrapper import run_cfg_extract
    from vbt.setters.cpp_setters import (
        _file_writes,
        _macro_setter_notes,
        _src_and_tree,
    )

    job_id, cpp_path_str = args
    cpp_path = Path(cpp_path_str)
    stem = cpp_path.stem
    setters: Dict[str, list] = defaultdict(list)
    callsites: Dict[str, list] = defaultdict(list)

    pre_rows = _load_precomputed_cpp_setter_rows(job_id, stem)
    if pre_rows is not None:
        setters.update(pre_rows)
    else:
        writes = _file_writes(cpp_path)
        src_bytes = None
        macro_cache: Dict[str, list] = {}
        for lhs_chain, site in writes:
            tail = lhs_chain[-1] if lhs_chain else ""
            if not tail:
                continue
            row = asdict(site)
            row["lhs_path"] = getattr(site, "lhs_path", "")
            row["lhs_chain"] = lhs_chain
            if tail not in macro_cache:
                try:
                    if src_bytes is None:
                        src_bytes, _ = _src_and_tree(cpp_path)
                    macro_cache[tail] = _macro_setter_notes(src_bytes, tail)
                except Exception:
                    macro_cache[tail] = None
            row["macro_setter_notes"] = macro_cache[tail]
            setters[tail].append(row)

    try:
        fns = run_cfg_extract(str(cpp_path))
    except Exception:
        fns = []
    for fn in fns or []:
        caller_fn = fn.get("function") or ""
        for call in fn.get("calls") or []:
            callee = str(call.get("callee") or "")
            tail = _tail(callee)
            if not tail:
                continue
            try:
                line = int(call.get("line") or 0)
            except (TypeError, ValueError):
                line = 0
            args = [str(a) for a in (call.get("args") or [])]
            callsites[tail].append({
                "stem": stem,
                "caller_fn": caller_fn,
                "line": line,
                "args": args,
            })

    return stem, dict(setters), dict(callsites)


def _build_one_asm_direct(args):
    """Build direct ASM setter rows and coverage for one ASM/MAC stem."""
    from dataclasses import asdict as _asdict
    from pathlib import Path as _Path
    from vbt.precompute.setter_map_db import _augment_universe
    from vbt.setters.asm_setters import find_asm_setters_in_file

    job_id, stem, vars_list, bp_str, src_str = args
    bp = _Path(bp_str)
    src = _Path(src_str)
    try:
        vars_ = _augment_universe(stem, set(vars_list), bp, src)
    except Exception:
        vars_ = set(vars_list)
    rows_by_var: Dict[str, list] = _load_precomputed_asm_setter_rows(job_id, stem) or {}
    covered: Set[str] = {k for k in rows_by_var if k}
    for var in sorted(vars_):
        key = _asm_key(var)
        if not key or key in covered:
            continue
        try:
            sites = find_asm_setters_in_file(var, stem, bp, src)
        except Exception:
            continue
        covered.add(key)
        if sites:
            rows_by_var[key] = [_asdict(s) for s in sites]
    return stem, covered, rows_by_var


def build_and_store_depvar_direct(job_id, blueprint_dir, asm_dir) -> Dict[str, int]:
    """Build and store direct dep-var relation blobs for one job.

    Returns row/tail counts. The build is corpus-wide but direct only; recursive
    reachability and dep-var expansion stay at trace time.
    """
    bp = Path(blueprint_dir)
    src = Path(asm_dir)
    setter_by_tail: Dict[str, list] = defaultdict(list)
    callsite_by_tail: Dict[str, list] = defaultdict(list)
    asm_rows_by_var: Dict[str, list] = defaultdict(list)
    asm_covered_by_var: Dict[str, Set[str]] = defaultdict(set)

    _READY.pop(str(job_id), None)
    _VERSION.pop(str(job_id), None)
    _ASM_SCANNED_STEMS.pop(str(job_id), None)
    for cache in (_SETTER_LOADED, _CALLSITE_LOADED, _SETTER_GROUPED, _CALLSITE_GROUPED,
                  _ASM_SETTER_LOADED, _ASM_SETTER_GROUPED):
        for key in [k for k in cache if k and k[0] == str(job_id)]:
            cache.pop(key, None)
    DA.clear_blobs_prefix(job_id, CPP_SETTER_INDEX_PREFIX)
    DA.clear_blobs_prefix(job_id, CPP_CALLSITE_INDEX_PREFIX)
    DA.clear_blobs_prefix(job_id, ASM_SETTER_INDEX_PREFIX)
    DA.clear_blobs_prefix(job_id, ASM_SCANNED_STEMS_BLOB)

    cpp_paths = [(str(job_id), str(p)) for p in _cpp_source_files(src)]
    from vbt.precompute.modifier_index import get_modifier_index
    midx = get_modifier_index(bp, src)
    stem_vars: Dict[str, set] = {}
    for var, files in midx.asm.items():
        for stem in files:
            stem_vars.setdefault(stem, set()).add(var)
    asm_stems = {p.stem for p in _asm_blueprint_files(bp)}
    cpp_stems = {p.stem for p in _cpp_source_files(src)}
    asm_items = [
        (str(job_id), stem, sorted(stem_vars.get(stem, set())), str(bp), str(src))
        for stem in sorted(asm_stems | set(stem_vars))
    ]
    previous_load_only = DA.is_load_only()
    from vbt.precompute.cfg_db import install_cfg_db, clear_cfg_db
    install_cfg_db(job_id)
    DA.set_load_only(True)
    try:
        from vbt.precompute.parallel import parallel_map
        def _pmap(fn, items):
            if not items:
                return []
            return parallel_map(fn, items)
        try:
            cpp_results = _pmap(_build_one_cpp_direct, cpp_paths)
            asm_results = _pmap(_build_one_asm_direct, asm_items)
        except Exception as exc:
            logger.debug("parallel depvar_direct fallback: %s", exc)
            cpp_results = [_build_one_cpp_direct(p) for p in cpp_paths]
            asm_results = [_build_one_asm_direct(p) for p in asm_items]
    finally:
        clear_cfg_db()
        DA.set_load_only(previous_load_only)

    for _stem, setters, callsites in cpp_results:
        for tail, rows in setters.items():
            setter_by_tail[tail].extend(rows)
        for tail, rows in callsites.items():
            callsite_by_tail[tail].extend(rows)
    # C++-only stems are authoritative empty for ASM setters. Candidate sets are
    # file-stem based and often include C++ chain hops; without recording these
    # as scanned-empty, the runtime conservatively calls the live ASM finder for
    # impossible C++ stems on every dep var.
    asm_scanned_stems: Set[str] = set(cpp_stems)
    for stem, covered, rows_by_var in asm_results:
        if stem:
            asm_scanned_stems.add(stem)
        for var in covered:
            asm_covered_by_var[var].add(stem)
        for var, rows in rows_by_var.items():
            asm_rows_by_var[var].extend(rows)

    setter_rows = 0
    for tail, rows in sorted(setter_by_tail.items()):
        setter_rows += len(rows)
        DA.write_blob(job_id, CPP_SETTER_INDEX_PREFIX + tail, DA.dumps_gz(rows))

    callsite_rows = 0
    for tail, rows in sorted(callsite_by_tail.items()):
        callsite_rows += len(rows)
        DA.write_blob(job_id, CPP_CALLSITE_INDEX_PREFIX + tail, DA.dumps_gz(rows))

    asm_setter_rows = 0
    for var in sorted(set(asm_covered_by_var) | set(asm_rows_by_var)):
        rows = asm_rows_by_var.get(var, [])
        asm_setter_rows += len(rows)
        DA.write_blob(job_id, ASM_SETTER_INDEX_PREFIX + var, DA.dumps_gz({
            "covered": sorted(asm_covered_by_var.get(var, set())),
            "rows": rows,
        }))
    DA.write_blob(job_id, ASM_SCANNED_STEMS_BLOB, DA.dumps_gz(sorted(asm_scanned_stems)))

    summary = {
        "cpp_setter_tails": len(setter_by_tail),
        "cpp_setter_rows": setter_rows,
        "cpp_callsite_tails": len(callsite_by_tail),
        "cpp_callsite_rows": callsite_rows,
        "asm_setter_vars": len(set(asm_covered_by_var) | set(asm_rows_by_var)),
        "asm_setter_rows": asm_setter_rows,
        "asm_covered_pairs": sum(len(v) for v in asm_covered_by_var.values()),
        "asm_scanned_stems": len(asm_scanned_stems),
    }
    DA.write_blob(job_id, DEPVAR_DIRECT_ARTIFACT, DA.dumps_gz(summary))
    source_files = (
        _cpp_source_files(src) + _asm_blueprint_files(bp) + _asm_source_files(src)
    )
    source_hash = DA.source_manifest_hash(
        source_files, version=DEPVAR_DIRECT_VERSION)
    DA.write_manifest(job_id, DEPVAR_DIRECT_ARTIFACT, DEPVAR_DIRECT_VERSION, source_hash)
    _READY[str(job_id)] = True
    _VERSION[str(job_id)] = DEPVAR_DIRECT_VERSION
    _ASM_SCANNED_STEMS[str(job_id)] = asm_scanned_stems
    return summary
