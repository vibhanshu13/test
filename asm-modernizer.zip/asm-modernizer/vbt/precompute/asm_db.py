"""DB-backed blueprints (DB_PRECOMPUTE_PLAN.md T7 + T12).

At trace time blueprints are loaded through ``blueprint_utils.load_json`` (a bounded LRU that
thrashes at 22k scale) by: the ASM setter scan / conditions / register-indirect (`.asm`/`.mac`)
AND the cross-file route walk (`find_routes`/`_load_bp`/`_load_pfl`/`reaches_function_set`,
which read `.cpp` blueprints' `call_graph`/`variable_lineage`/`nodes`). This module persists
EVERY blueprint dict (asm/mac/cpp/hpp) in index.db and installs a decoupled override on
``load_json`` so all those reads come from DB instead of disk (+ their `.bpidx` sidecars).

Behavior preservation: the WHOLE blueprint dict is stored (no key dropping), JSON round-trips
losslessly, and ``load_json`` returns the served dict verbatim before its LRU/disk path — so
every consumer sees the identical structure. Storage is PER FILE and the override loads lazily
on first touch (scale-correct; a trace only pays for the blueprints it reads). The build is
precompute-only; the trace only LOADS, so a cold DB falls through to disk (byte-identical).
``job_id`` None → not installed.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import List, Optional

from vbt.precompute import db_artifacts as DA

logger = logging.getLogger(__name__)

# Manifest row governing freshness of the whole blueprint set; each blueprint dict lives under
# the artifact key "bp:<filename>" (full name, so cpp/asm stems never collide) in vbt_artifact_blob.
ASM_BP_MANIFEST = "blueprints"
ASM_BP_VERSION = 2   # bumped: now covers cpp/hpp too, keyed by filename (was asm-only by stem)
_SUFFIXES = (".asm.json", ".mac.json", ".cpp.json", ".hpp.json")


def _bp_files(blueprint_dir: Path) -> List[Path]:
    bp = Path(blueprint_dir)
    out: List[Path] = []
    for suf in _SUFFIXES:
        out.extend(sorted(bp.glob("*" + suf)))
    return out


def _is_blueprint(name: str) -> bool:
    return name.endswith(_SUFFIXES)


def _load_compress_one_bp(file_path_str: str):
    """ProcessPool worker: load one blueprint and gzip-compress its JSON dict.

    Returns (filename, payload_or_None). Pickle-safe (str input, bytes/None output).
    Errors are swallowed and surface as None so the parent can skip them quietly,
    matching the original per-file try/except behaviour."""
    import os
    name = os.path.basename(file_path_str)
    try:
        from backward_traversal.utils.blueprint_utils import load_json as _lj
        from vbt.precompute import db_artifacts as _DA
        return (name, _DA.dumps_gz(_lj(file_path_str)))
    except Exception:
        return (name, None)


def build_and_store_asm_blueprints(job_id, blueprint_dir) -> int:
    """Precompute (one-shot, O(corpus)): store every blueprint dict (asm/mac/cpp/hpp) + a
    freshness manifest. Belongs to the precompute step, NOT the trace path. Returns the count.

    Parallelized via vbt.precompute.parallel.parallel_map: each worker loads + gzip-compresses
    one blueprint; the parent then writes blobs sequentially (sqlite single-writer). Byte-identical
    to the serial path because the compression is deterministic and the write order is preserved
    (parallel_map returns INPUT-ORDERED results)."""
    bp = Path(blueprint_dir)
    files = _bp_files(bp)
    shash = DA.source_manifest_hash(files, version=ASM_BP_VERSION)
    paths = [str(f) for f in files]
    try:
        from vbt.precompute.parallel import parallel_map
        results = parallel_map(_load_compress_one_bp, paths)
    except Exception as exc:
        logger.debug("parallel asm_blueprints fallback: %s", exc)
        results = [_load_compress_one_bp(p) for p in paths]
    n = 0
    for name, payload in results:
        if payload is None:
            continue
        try:
            if DA.write_blob(job_id, f"bp:{name}", payload):
                n += 1
        except Exception as exc:
            logger.debug("store bp:%s failed: %s", name, exc)
    DA.write_manifest(job_id, ASM_BP_MANIFEST, ASM_BP_VERSION, shash)
    return n


def install_asm_blueprint_override(job_id: Optional[str], blueprint_dir) -> bool:
    """If a fresh blueprint artifact exists, install a ``load_json`` override serving this job's
    blueprints from DB (lazy, per file, cached). Returns True iff installed. Cold/stale DB →
    not installed → load_json reads disk (byte-identical)."""
    if not job_id:
        return False
    bp_dir = Path(blueprint_dir)
    bp_str = str(bp_dir)
    # T12: trace-time = O(1) presence check (no O(files) source hash). Per-file GET misses fall
    # back to disk, so a stale/partial set is still correct, just not accelerated.
    if DA.is_load_only():
        if not DA.manifest_present(job_id, ASM_BP_MANIFEST):
            return False
    else:
        try:
            shash = DA.source_manifest_hash(_bp_files(bp_dir), version=ASM_BP_VERSION)
        except Exception:
            return False
        if not DA.manifest_fresh(job_id, ASM_BP_MANIFEST, version=ASM_BP_VERSION, source_hash=shash):
            return False

    cache: dict = {}   # filename -> dict | None (None = not in DB → fall through to disk)

    def _override(path_str: str):
        name = os.path.basename(path_str)
        if not _is_blueprint(name):                 # not a blueprint (e.g. file_call_graph.json)
            return None
        # Only intercept THIS job's blueprint dir. String compare (NO resolve() — that would
        # stat on every one of the thousands of blueprint loads during a route walk).
        if os.path.dirname(path_str) != bp_str:
            return None
        if name in cache:
            return cache[name]
        payload = DA.read_blob(job_id, f"bp:{name}")
        d = DA.loads_gz(payload) if payload is not None else None
        cache[name] = d
        return d

    from backward_traversal.utils.blueprint_utils import set_blueprint_override
    set_blueprint_override(_override)
    return True
