"""DB-backed cfg cache (DB_PRECOMPUTE_PLAN.md T8).

Installs self-warming GET/PUT hooks on ``cpp_frontend.wrapper.run_cfg_extract`` so cfg_extract
results are served from / persisted to index.db (keyed by the content-hash cfg key).  The CPU
(the Clang subprocess) was already eliminated by precompute cfg-warm; this only moves the
*storage* so a warm trace reads cfg from DB rather than files (G3).  Self-warming: on a cold DB
the trace reads the warm disk cfg cache and PUTs each touched key incrementally (bounded by the
files the trace reaches — NOT O(corpus)); subsequent traces GET from DB.  The content-hash key
is self-validating (a changed source/binary/flag ⇒ different key), so a stale blob is never
served and no manifest is needed.  ``job_id`` None → hooks not installed (disk path unchanged).
"""
from __future__ import annotations

import logging
from typing import Optional

from vbt.precompute import db_artifacts as DA

logger = logging.getLogger(__name__)


def install_cfg_db(job_id: Optional[str]) -> bool:
    """Install the GET/PUT cfg hooks bound to ``job_id``. Returns True iff installed."""
    if not job_id:
        return False

    def _get(key):
        payload = DA.read_cfg_blob(job_id, key)
        return DA.loads_gz(payload) if payload is not None else None

    def _put(key, funcs):
        DA.write_cfg_blob(job_id, key, DA.dumps_gz(funcs))

    from vbt.cpp_frontend.wrapper import set_cfg_db_hooks
    set_cfg_db_hooks(_get, _put)
    return True


def clear_cfg_db() -> None:
    from vbt.cpp_frontend.wrapper import clear_cfg_db_hooks
    clear_cfg_db_hooks()
