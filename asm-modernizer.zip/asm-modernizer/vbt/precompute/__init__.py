"""Lightweight, kb_id-free precompute (call graph regen, indexes) for the engine."""
