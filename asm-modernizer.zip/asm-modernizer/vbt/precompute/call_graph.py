"""Regenerate ``file_call_graph.json`` from blueprints (READ-ONLY reuse).

The project pipeline ingests the call graph into ``index.db`` and deletes the JSON.
Our engine is kb_id-free, so we rebuild the JSON ourselves via the existing,
validated ``CallGraphBuilder`` (USE-AS-IS) and cache it next to the blueprints —
exactly where ``route_finder`` expects ``graph_file``.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional


def ensure_call_graph(
    blueprint_dir: Path,
    asm_dir: Optional[Path] = None,
    *,
    out_path: Optional[Path] = None,
    rebuild: bool = False,
) -> Path:
    """Ensure ``file_call_graph.json`` exists; build it if missing/stale. Returns the path."""
    blueprint_dir = Path(blueprint_dir)
    out_path = Path(out_path) if out_path else (blueprint_dir / "file_call_graph.json")

    if out_path.exists() and not rebuild:
        # cheap freshness check: newer than the newest blueprint
        try:
            newest_bp = max(
                (p.stat().st_mtime for p in blueprint_dir.glob("*.json")
                 if p.name != out_path.name),
                default=0.0,
            )
            if out_path.stat().st_mtime >= newest_bp:
                return out_path
        except OSError:
            return out_path

    from file_call_graph import CallGraphBuilder, format_json

    builder = CallGraphBuilder(
        asm_dir=Path(asm_dir) if asm_dir else None,
        blueprint_dir=blueprint_dir,
        recursive=False,
    )
    graph = builder.build()
    out_path.write_text(format_json(graph, include_external=True), encoding="utf-8")
    return out_path
