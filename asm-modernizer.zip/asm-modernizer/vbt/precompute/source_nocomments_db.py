"""DB-backed COMMENT-STRIPPED C/C++ source (GAP 7).

Precompute-only: tree-sitter parses each .cpp/.hpp and blanks every comment node to
spaces, preserving EVERY line-break byte so the stripped text has the identical line
structure as the raw file. CodeBlockStore reads THIS variant at trace time, so codeBlocks
`code`/chunks carry no commented-out legacy code for the LLM to mistake as active logic.
Raw source (source_db `src:`) is UNTOUCHED and still serves all parsers. job_id=None /
cold DB / verify-failed file -> CodeBlockStore falls back to raw -> byte-identical to
pre-GAP-7. A per-file self-verification gate turns ANY stripper surprise into a safe
no-strip for that file, never a misaligned slice.
"""
from __future__ import annotations

import gzip
import locale
import logging
from pathlib import Path
from typing import List

from vbt.precompute import db_artifacts as DA

logger = logging.getLogger(__name__)

SOURCE_NC_MANIFEST = "source_nocomments"
SOURCE_NC_VERSION = 1                # bump to force a re-strip when the stripper changes
_PATTERNS = ("*.cpp", "*.hpp")       # C/C++ only; .asm/.mac use ASM comment syntax (out of scope)

# Bytes that str.splitlines() treats as line boundaries (ASCII subset: \n \v \f \r FS GS RS).
# Preserve them verbatim so the stripped text keeps the SAME line structure as the raw text.
# Mainframe-origin C source often has form-feed (0x0C) page breaks inside comment banners;
# preserving only 0x0A would drop those line breaks and misalign every slice below them.
# (Unicode separators U+0085/U+2028/U+2029 are multi-byte; the verify gate catches any
# residual drift and degrades that file to raw.)
_LINE_BREAK_BYTES = frozenset({0x0A, 0x0B, 0x0C, 0x0D, 0x1C, 0x1D, 0x1E})


def _nc_files(asm_dir: Path) -> List[Path]:
    src = Path(asm_dir)
    files: List[Path] = []
    for pat in _PATTERNS:
        files.extend(sorted(src.glob(pat)))
    return files


def _overlaps(lo: int, hi: int, ranges) -> bool:
    """True if 1-based line span [lo,hi] intersects any protected (a,b) range."""
    return any(not (hi < a or lo > b) for (a, b) in ranges)


def strip_cpp_comments_bytes(raw: bytes, parser, protected=()) -> bytes:
    """Blank every C/C++ comment in `raw` to spaces, keeping all line-break bytes.

    Parser-accurate (tree-sitter): string/char/raw-string literals, line-continued `//`,
    and digit separators are handled correctly. Tree-sitter is error-tolerant, so the
    corpus's brace-mismatched files (see vbt/conditions/ts_guards.py) still tokenise
    comments. Iterative DFS (no recursion-depth limit). `parser` is reused across files.

    `protected` is a list of 1-based (open_line, close_line) ranges that `source_lint`
    flagged as a function definition lexically inside a comment (§0). Comment nodes that
    overlap a protected range are LEFT VERBATIM — that text is ambiguous between
    deliberately-dead code and a dropped-*/ extraction defect, so we never destroy it; the
    diagnostic/repair pipeline owns it. Empty for the vast majority of files.
    """
    tree = parser.parse(raw)
    buf = bytearray(raw)
    stack = [tree.root_node]
    while stack:
        node = stack.pop()
        if node.type == "comment":          # tree-sitter-cpp uses one `comment` type for // and /* */
            lo = node.start_point[0] + 1    # 1-based first line of the comment node
            hi = node.end_point[0] + 1      # 1-based last line
            if protected and _overlaps(lo, hi, protected):
                continue                    # swallowed-function region -> preserve verbatim
            for i in range(node.start_byte, node.end_byte):
                if buf[i] not in _LINE_BREAK_BYTES:
                    buf[i] = 0x20           # space; never overwrites a line break
            continue                        # comments don't nest -> don't descend
        stack.extend(node.children)
    return bytes(buf)


def _line_structure_preserved(raw_text: str, stripped_text: str) -> bool:
    """The exact invariant downstream relies on: same number of lines, each the same
    length, and each stripped char is either the original char or a blanking space."""
    r = raw_text.splitlines()
    s = stripped_text.splitlines()
    if len(r) != len(s):
        return False
    for ri, si in zip(r, s):
        if len(ri) != len(si):
            return False
        for c, o in zip(si, ri):
            if c != o and c != " ":
                return False
    return True


def build_and_store_source_nocomments(job_id, asm_dir) -> int:
    """Precompute (one-shot): store the verified comment-stripped variant of every C/C++
    source file (gzipped) + a manifest. NOT the trace path. A per-file parse error OR a
    line-structure drift SKIPS that file (the trace then falls back to raw source for it).
    Returns the count stored.

    INVARIANT: `srcnc:NAME` exists  <=>  it is a verified, line-structure-preserving,
    comment-stripped variant of NAME. So a trace can trust any blob it finds and safely
    fall back when one is absent."""
    if not job_id:
        return 0
    from vbt.setters.cpp_setters import _parser    # the ONE shared C++ grammar/parser
    from vbt.precompute.source_lint import scan_source_for_swallowed  # §0 defect guard
    parser = _parser()
    enc = locale.getpreferredencoding(False)         # match CodeBlockStore's decode
    src = Path(asm_dir)
    files = _nc_files(src)
    shash = DA.source_manifest_hash(files, version=SOURCE_NC_VERSION)
    n = 0
    for f in files:
        try:
            raw = f.read_bytes()
            # §0: comment regions source_lint flags as a function definition are AMBIGUOUS
            # (deliberate dead-code vs. dropped-*/ extraction defect). Never destroy them;
            # leave them verbatim for the diagnostic/repair pipeline. (Extra per-file parse;
            # precompute-only, heavy-by-design. Empty for almost every file.)
            protected = [(s.comment_open_line, s.comment_close_line)
                         for s in scan_source_for_swallowed(str(f))]
            stripped = strip_cpp_comments_bytes(raw, parser, protected)
            if not _line_structure_preserved(raw.decode(enc, "replace"),
                                              stripped.decode(enc, "replace")):
                logger.warning("srcnc:%s line-structure drift; skipping (trace uses raw)", f.name)
                continue
            if DA.write_blob(job_id, f"srcnc:{f.name}", gzip.compress(stripped, mtime=0)):
                n += 1
        except Exception as exc:
            logger.debug("strip srcnc:%s failed (trace uses raw): %s", f.name, exc)
    DA.write_manifest(job_id, SOURCE_NC_MANIFEST, SOURCE_NC_VERSION, shash)
    return n
