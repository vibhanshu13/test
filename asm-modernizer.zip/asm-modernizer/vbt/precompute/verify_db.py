#!/usr/bin/env python3
"""Post-precompute health check: does ``jobs/<id>/index.db`` have everything a VBT trace needs?

Run this RIGHT AFTER ``vbt.precompute_db`` / the ``asm.vbt_precompute`` Celery task to confirm the
artifacts are present, complete, AND non-degenerate — instead of finding out later that a trace
returns "no setters" or rebuilds from 22k files at startup.

30 GB-SAFE BY DESIGN
====================
The index.db can be tens of GB (the ``gvl_edges`` table alone is ~18 GB). This script NEVER loads
the DB into memory and NEVER materializes blob payloads in bulk:

  * Sizes/counts use SQL aggregates ``COUNT(*)`` / ``SUM(length(payload))`` / ``MAX(length(payload))``.
    In SQLite ``length(payload)`` is read from the record header (the serial-type code encodes the
    byte length) — it does NOT read the blob's content or its overflow pages. So summing the size
    of millions of GB of blobs is a header scan, not a data load.
  * It only ever touches the ``vbt_*`` tables (``vbt_artifact_blob`` / ``vbt_cfg_blob`` /
    ``vbt_precompute_manifest``). It deliberately NEVER queries ``gvl_edges`` or any other large
    non-VBT table — a ``COUNT(*)`` there is the 232 s full-scan that stalls cold startup.
  * Integrity decoding is SAMPLED: it loads at most ``--sample`` blobs PER artifact type (default 3)
    to confirm they gunzip/JSON-decode, never the whole set.

    env/bin/python3 -m vbt.precompute.verify_db --job-id <id> \
        [--blueprint-dir jobs/<id>/output] [--asm-dir /path/to/source] [--sample 3] \
        [--test-variable softCardValue --test-language cpp \
         --test-hop aa71:asm --test-hop dw730000:cpp:DW73 --test-hop dw710000:cpp:fn]

Exit code 0 = no FAIL, 1 = at least one FAIL.  WARN (e.g. a speedup artifact not built yet) does
NOT fail — a missing setter map only means the trace falls back to live detection (byte-identical,
just slower), so it is a heads-up, not a broken precompute.
"""
from __future__ import annotations

import argparse
from pathlib import Path
from typing import List, Optional, Tuple

from sqlalchemy import text

OK, WARN, FAIL = "OK  ", "WARN", "FAIL"
_results: List[Tuple[str, str, str]] = []


def _chk(status: str, name: str, detail: str) -> None:
    _results.append((status, name, detail))
    print(f"  [{status}] {name:30} {detail}")


def _fmt(nbytes: int) -> str:
    f = float(nbytes)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if f < 1024 or unit == "TB":
            return f"{f:.1f} {unit}"
        f /= 1024
    return f"{f:.1f} TB"


# ---- size-safe SQL helpers (header-only; never read blob payloads) ----------------------------- #
def _agg_like(c, job_id: str, like: str) -> Tuple[int, int]:
    """``(count, total_bytes)`` for artifacts whose key matches ``LIKE``. Uses SUM(length(payload)) so
    the blob CONTENT is never read — only the per-row length from the record header."""
    row = c.execute(text(
        "SELECT COUNT(*), COALESCE(SUM(length(payload)), 0) "
        "FROM vbt_artifact_blob WHERE job_id = :j AND artifact LIKE :l"),
        {"j": job_id, "l": like}).one()
    return int(row[0]), int(row[1])


def _singleton(c, job_id: str, artifact: str) -> Optional[int]:
    """Byte length of one named artifact blob, or ``None`` if absent. length() = header read."""
    row = c.execute(text(
        "SELECT length(payload) FROM vbt_artifact_blob WHERE job_id = :j AND artifact = :a"),
        {"j": job_id, "a": artifact}).first()
    return int(row[0]) if row is not None else None


def _sample_decode(c, job_id: str, like: str, k: int, raw: bool = False) -> Tuple[int, int, str]:
    """Load at most ``k`` blobs matching ``LIKE`` and decode them. Returns ``(n_ok, n_tried,
    first_error)``. This is the ONLY path that reads blob payloads, and it is hard-capped at ``k``
    rows (LIMIT), so it is bounded regardless of DB size. ``raw=True`` for SOURCE blobs (stored as
    ``gzip.compress(bytes)``, NOT ``dumps_gz(json)``) — they gunzip to text, not a JSON object."""
    import gzip
    from vbt.precompute import db_artifacts as DA
    rows = c.execute(text(
        "SELECT payload FROM vbt_artifact_blob WHERE job_id = :j AND artifact LIKE :l LIMIT :k"),
        {"j": job_id, "l": like, "k": k}).fetchall()
    n_ok, err = 0, ""
    for (blob,) in rows:
        try:
            if raw:
                gzip.decompress(bytes(blob))   # success (even if empty file) = valid; raises iff corrupt
            elif DA.loads_gz(bytes(blob)) is None:
                raise ValueError("decoded to None")
            n_ok += 1
        except Exception as exc:  # corrupt/partial blob — the thing this check exists to catch
            if not err:
                err = str(exc)
    return n_ok, len(rows), err


def verify(job_id: str, blueprint_dir=None, asm_dir=None, sample: int = 3,
           test_variable=None, test_language="cpp", test_hops=None) -> int:
    from api.index_db.engine import get_engine
    from vbt.precompute import db_artifacts as DA
    from vbt.precompute.graph_db import (FILE_CALL_GRAPH_ARTIFACT, ROUTE_NAME_TO_STEMS_ARTIFACT,
                                         CPP_CALL_EDGES_ARTIFACT, REVERSE_ADJ_ARTIFACT,
                                         FORWARD_FILE_ADJ_ARTIFACT, FN_GRAPH_ADJ_ARTIFACT)
    from vbt.precompute.resolvers_db import (NAME_ALIAS_ARTIFACT, MEMBERSHIP_ARTIFACT,
                                             CONST_ARTIFACT, MODIFIER_ARTIFACT)
    from vbt.precompute.setter_map_db import ASM_SETTER_MAP_ARTIFACT
    from vbt.precompute.cpp_setter_map_db import CPP_SETTER_MAP_ARTIFACT
    from vbt.precompute.cpp_file_writes_db import CPP_FILE_WRITES_ARTIFACT
    from vbt.precompute.fn_facts_db import FN_FACTS_ARTIFACT

    eng = get_engine(job_id)
    with eng.connect() as c:
        # ---- footprint: aggregates only (header reads). Never SELECT blob in bulk. ----
        n_blobs, total_bytes, max_bytes = c.execute(text(
            "SELECT COUNT(*), COALESCE(SUM(length(payload)),0), COALESCE(MAX(length(payload)),0) "
            "FROM vbt_artifact_blob WHERE job_id = :j"), {"j": job_id}).one()
        n_cfg, cfg_bytes = c.execute(text(
            "SELECT COUNT(*), COALESCE(SUM(length(payload)),0) FROM vbt_cfg_blob WHERE job_id = :j"),
            {"j": job_id}).one()
        n_manifest = c.execute(text(
            "SELECT COUNT(*) FROM vbt_precompute_manifest WHERE job_id = :j"),
            {"j": job_id}).scalar() or 0

        print(f"\n=== index.db VBT footprint for job {job_id} ===")
        print(f"  (size-safe: COUNT/SUM(length) header scans only — blobs never loaded; "
              f"gvl_edges & non-VBT tables never queried)")
        print(f"  artifact blobs : {n_blobs:>7}  ({_fmt(total_bytes)} total, largest {_fmt(max_bytes)})")
        print(f"  cfg blobs      : {n_cfg:>7}  ({_fmt(cfg_bytes)})")
        print(f"  manifest rows  : {n_manifest:>7}")
        print(f"  VBT total      : {_fmt(total_bytes + cfg_bytes)} "
              f"(the rest of the DB is gvl_edges etc. — NOT read by a trace)\n")

        # ---- 1. REQUIRED artifacts (missing ⇒ precompute didn't finish / wrong dir) ---------- #
        print("--- required artifacts (missing ⇒ degenerate traces) ---")
        for art, label in [(FILE_CALL_GRAPH_ARTIFACT, "file_call_graph"),
                           (ROUTE_NAME_TO_STEMS_ARTIFACT, "route_name_to_stems"),
                           (CPP_CALL_EDGES_ARTIFACT, "cpp_call_edges"),
                           (NAME_ALIAS_ARTIFACT, "name_alias"), (MEMBERSHIP_ARTIFACT, "membership"),
                           (CONST_ARTIFACT, "const"), (MODIFIER_ARTIFACT, "modifier_index")]:
            sz = _singleton(c, job_id, art)
            _chk(OK if sz is not None else FAIL, label,
                 f"present ({_fmt(sz)})" if sz is not None else
                 "MISSING — precompute did not finish (or wrong --job-id)")

        # ---- 2. FALLBACK artifacts (missing ⇒ correct but slower; trace rebuilds/scans live) -- #
        print("\n--- speedup artifacts (missing ⇒ byte-identical fallback, just slower) ---")
        for art, label, build, note in [
            (REVERSE_ADJ_ARTIFACT, "reverse_adj", "reverse_adj", "cold start rebuilds from 80MB payload"),
            (FORWARD_FILE_ADJ_ARTIFACT, "forward_file_adj", "forward_file_adj", "metadata prune rebuilds from payload")]:
            sz = _singleton(c, job_id, art)
            _chk(OK if sz is not None else WARN, label,
                 f"present ({_fmt(sz)})" if sz is not None else
                 f"not built — {note}; build: --only {build}")

        n_asm_sm, b_asm_sm = _agg_like(c, job_id, ASM_SETTER_MAP_ARTIFACT + ":%")
        n_cpp_sm, b_cpp_sm = _agg_like(c, job_id, CPP_SETTER_MAP_ARTIFACT + ":%")
        _chk(OK if n_asm_sm else WARN, "asm_setter_map",
             f"{n_asm_sm} stems ({_fmt(b_asm_sm)})" if n_asm_sm else
             "not built — trace falls back to LIVE ASM setter scan (correct, slower); build: --only asm_setter_map")
        _chk(OK if n_cpp_sm else WARN, "cpp_setter_map",
             f"{n_cpp_sm} stems ({_fmt(b_cpp_sm)})" if n_cpp_sm else
             "not built — trace falls back to LIVE C++ setter scan (correct, slower); build: --only cpp_setter_map")
        n_cfw, b_cfw = _agg_like(c, job_id, CPP_FILE_WRITES_ARTIFACT + ":%")
        _chk(OK if n_cfw else WARN, "cpp_file_writes",
             f"{n_cfw} stems ({_fmt(b_cfw)})" if n_cfw else
             "not built — trace tree-sitter-parses each cpp live for the path-family search (correct, slower); build: --only cpp_file_writes")
        for art, label, note in [
            (FN_GRAPH_ADJ_ARTIFACT, "fn_graph_adj",
             "cold trace REBUILDS the whole fn-graph every run (the dominant 22k one-time cost); build: --only fn_graph_adj"),
            (FN_FACTS_ARTIFACT, "fn_facts",
             "fn-graph build inputs (per-stem starts/local) rebuilt from cfg each cold trace; build: --only fn_facts")]:
            sz = _singleton(c, job_id, art)
            _chk(OK if sz is not None else WARN, label,
                 f"present ({_fmt(sz)})" if sz is not None else f"not built — {note}")

        # ---- 3. per-stem groups: counts + sizes (header aggregates) -------------------------- #
        print("\n--- per-stem coverage (counts + sizes via header aggregates) ---")
        n_bp_cpp, b_bp_cpp = _agg_like(c, job_id, "bp:%.cpp.json")
        n_bp_asm_a, b_bp_asm_a = _agg_like(c, job_id, "bp:%.asm.json")
        n_bp_asm_m, b_bp_asm_m = _agg_like(c, job_id, "bp:%.mac.json")
        n_src_cpp, b_src_cpp = _agg_like(c, job_id, "src:%.cpp")
        n_src_asm, b_src_asm = _agg_like(c, job_id, "src:%.asm")
        n_src_mac, b_src_mac = _agg_like(c, job_id, "src:%.mac")
        _chk(OK if n_bp_cpp else FAIL, "cpp blueprints",
             f"{n_bp_cpp} ({_fmt(b_bp_cpp)})" if n_bp_cpp else
             "0 — parser ran on the wrong dir (no cpp setters will resolve)")
        _chk(OK if (n_bp_asm_a + n_bp_asm_m) else WARN, "asm/mac blueprints",
             f"asm={n_bp_asm_a} mac={n_bp_asm_m} ({_fmt(b_bp_asm_a + b_bp_asm_m)})")
        _chk(OK if n_src_cpp else FAIL, "cpp source",
             f"{n_src_cpp} ({_fmt(b_src_cpp)})" if n_src_cpp else "0 — wrong --asm-dir")
        _chk(OK if (n_src_asm + n_src_mac) else WARN, "asm/mac source",
             f"asm={n_src_asm} mac={n_src_mac} ({_fmt(b_src_asm + b_src_mac)})")
        _chk(OK if n_cfg else FAIL, "cpp cfg blobs",
             f"{n_cfg} ({_fmt(cfg_bytes)})" if n_cfg else
             "0 — no cpp cfg → every cpp setter unreachable; rebuild with correct --asm-dir")

        # ---- 4. file_call_graph non-degenerate (size-guarded decode of the ONE big blob) ----- #
        print("\n--- graph non-degenerate (single bounded decode) ---")
        fcg_sz = _singleton(c, job_id, FILE_CALL_GRAPH_ARTIFACT)
        if fcg_sz is None:
            _chk(FAIL, "call-graph populated", "file_call_graph blob MISSING")
        elif fcg_sz > 1_000_000_000:  # >1GB: don't materialize — report + warn rather than risk memory
            _chk(WARN, "call-graph populated", f"blob is {_fmt(fcg_sz)} — skipped full decode (size guard)")
        else:
            try:
                payload = DA.loads_gz(DA.read_blob(job_id, FILE_CALL_GRAPH_ARTIFACT))
                nodes, edges = payload.get("nodes", []), payload.get("edges", [])
                _chk(OK if (nodes and edges) else FAIL, "call-graph populated",
                     f"nodes={len(nodes)} edges={len(edges)}"
                     + ("" if (nodes and edges) else "  — EMPTY/stale; re-run rebuild=True"))
            except Exception as exc:
                _chk(FAIL, "call-graph populated", f"decode failed: {exc}")

        # fn_graph_adj + fn_facts: decode the singleton blob, confirm it is populated (not an empty map).
        for art, label, unit in [(FN_GRAPH_ADJ_ARTIFACT, "fn_graph_adj populated", "nodes"),
                                 (FN_FACTS_ARTIFACT, "fn_facts populated", "stems")]:
            asz = _singleton(c, job_id, art)
            if asz is None:
                continue  # absence already WARNed in section 2 (speedup fallback)
            if asz > 1_000_000_000:   # >1GB: don't materialize — report + warn rather than risk memory
                _chk(WARN, label, f"blob is {_fmt(asz)} — skipped full decode (size guard)")
                continue
            try:
                obj = DA.loads_gz(DA.read_blob(job_id, art))
                _chk(OK if obj else WARN, label,
                     f"{len(obj)} {unit}" + ("" if obj else "  — EMPTY; rebuild this artifact"))
            except Exception as exc:
                _chk(FAIL, label, f"decode failed: {exc}")

        # ---- 5. SAMPLED integrity: decode a few blobs per type (bounded by --sample) --------- #
        print(f"\n--- sampled integrity (decode ≤{sample} blobs/type; bounded, never bulk) ---")
        for like, label, raw in [("bp:%.cpp.json", "blueprint(cpp)", False),
                                 ("bp:%.asm.json", "blueprint(asm)", False),
                                 ("src:%.cpp", "source(cpp)", True), ("src:%.asm", "source(asm)", True),
                                 (ASM_SETTER_MAP_ARTIFACT + ":%", "asm_setter_map", False),
                                 (CPP_SETTER_MAP_ARTIFACT + ":%", "cpp_setter_map", False),
                                 (CPP_FILE_WRITES_ARTIFACT + ":%", "cpp_file_writes", False)]:
            n_ok, n_try, err = _sample_decode(c, job_id, like, sample, raw=raw)
            if n_try == 0:
                continue  # nothing of this type — already reported above
            _chk(OK if n_ok == n_try else FAIL, f"decode {label}",
                 f"{n_ok}/{n_try} ok" + ("" if n_ok == n_try else f"  — CORRUPT: {err}"))
        # cfg lives in its own table — sample it directly (still bounded by LIMIT)
        try:
            cfg_rows = c.execute(text(
                "SELECT payload FROM vbt_cfg_blob WHERE job_id = :j LIMIT :k"),
                {"j": job_id, "k": sample}).fetchall()
            ok = sum(1 for (b,) in cfg_rows if DA.loads_gz(bytes(b)) is not None)
            if cfg_rows:
                _chk(OK if ok == len(cfg_rows) else FAIL, "decode cfg", f"{ok}/{len(cfg_rows)} ok")
        except Exception as exc:
            _chk(FAIL, "decode cfg", f"sample failed: {exc}")

    # ---- 6. disk cross-check: do DB counts match the actual dirs? ---------------------------- #
    if blueprint_dir or asm_dir:
        print("\n--- disk cross-check ---")
    if blueprint_dir:
        disk_cpp_bp = len(list(Path(blueprint_dir).glob("*.cpp.json")))
        st = OK if disk_cpp_bp == n_bp_cpp else WARN
        _chk(st, "blueprint-dir vs DB (cpp)", f"disk .cpp.json={disk_cpp_bp} db={n_bp_cpp}"
             + ("" if st == OK else "  — mismatch ⇒ stale/incomplete; re-run rebuild=True"))
    if asm_dir:
        disk_cpp_src = len(list(Path(asm_dir).glob("*.cpp")))
        st = OK if disk_cpp_src == n_src_cpp else WARN
        _chk(st, "asm-dir vs DB (cpp source)", f"disk .cpp={disk_cpp_src} db={n_src_cpp}"
             + ("" if st == OK else "  — mismatch ⇒ wrong/stale --asm-dir; re-run rebuild=True"))

    # ---- 7. STRONG end-to-end: does the test variable actually resolve setters? ------------- #
    if test_variable and test_hops and blueprint_dir and asm_dir:
        print("\n--- live end-to-end ---")
        try:
            from vbt.engine import trace_root_variable, Hop
            hops = [Hop(*h) for h in test_hops]
            gf = Path(blueprint_dir) / "file_call_graph.json"
            out = trace_root_variable(test_variable, test_language, hops,
                                      blueprint_dir=Path(blueprint_dir), asm_dir=Path(asm_dir),
                                      graph_file=gf, job_id=job_id, disable_dependents=True)
            n_set = len(out["rootVariable"]["setters"])
            _chk(OK if n_set > 0 else FAIL, f"live root-setters({test_variable})",
                 f"{n_set} setters" + ("" if n_set else "  — 0 setters: artifacts above are wrong/stale"))
        except Exception as exc:
            _chk(FAIL, f"live root-setters({test_variable})", f"trace errored: {exc}")

    n_fail = sum(1 for s, _, _ in _results if s == FAIL)
    n_warn = sum(1 for s, _, _ in _results if s == WARN)
    print(f"\n=== VERDICT: {'PASS ✅' if not n_fail else 'FAIL ❌'}  "
          f"({n_fail} fail, {n_warn} warn, {len(_results) - n_fail - n_warn} ok) ===")
    if n_fail:
        print("  FAIL ⇒ re-run precompute with rebuild=True and the CORRECT --blueprint-dir/--asm-dir.")
    if n_warn:
        print("  WARN ⇒ trace still correct (byte-identical fallback); listed artifacts are speed-only.\n"
              "         Build just those incrementally: vbt.precompute_db --only <name>,<name> --job-id ...")
    return 1 if n_fail else 0


def health_summary(job_id: str, blueprint_dir=None, asm_dir=None,
                   require_speedup_artifacts: bool = True) -> dict:
    """Programmatic health check (no stdout, no decode pass) — for the pipeline
    task to use as a hard gate.

    Returns ``{"status": "PASS"|"FAIL", "missing": [<name>...], "warnings": [...],
    "counts": {"artifact_blobs":N, "cpp_blueprints":N, "asm_blueprints":N, ...}}``.

    ``require_speedup_artifacts=True`` (the default the < 1-min target needs)
    promotes the speedup artifacts (asm_setter_map / cpp_setter_map /
    cpp_file_writes / fn_facts / fn_graph_adj / reverse_adj / forward_file_adj)
    to FAIL — without them a 24k trace silently rebuilds from the 80 MB payload
    (multi-minute cold path). Set to False to match the historic CLI semantics.

    Backend-aware: when VBT_DB_BACKEND=lmdb the counts come from the LMDB env
    (a fast cursor walk); otherwise from sqlite header aggregates.
    """
    # W12: when LMDB is active, use LMDB-aware helpers; sqlite-aware otherwise.
    try:
        from vbt.precompute import db_artifacts as _DA
        _backend_lmdb = _DA._lmdb_active()
    except Exception:
        _backend_lmdb = False
    if _backend_lmdb:
        return _health_summary_lmdb(job_id, blueprint_dir, asm_dir,
                                    require_speedup_artifacts)
    from sqlalchemy import text as _sqltext
    from api.index_db.engine import get_engine
    from vbt.precompute.graph_db import (FILE_CALL_GRAPH_ARTIFACT, ROUTE_NAME_TO_STEMS_ARTIFACT,
                                         CPP_CALL_EDGES_ARTIFACT, REVERSE_ADJ_ARTIFACT,
                                         FORWARD_FILE_ADJ_ARTIFACT, FN_GRAPH_ADJ_ARTIFACT)
    from vbt.precompute.resolvers_db import (NAME_ALIAS_ARTIFACT, MEMBERSHIP_ARTIFACT,
                                             CONST_ARTIFACT, MODIFIER_ARTIFACT)
    from vbt.precompute.setter_map_db import ASM_SETTER_MAP_ARTIFACT
    from vbt.precompute.cpp_setter_map_db import CPP_SETTER_MAP_ARTIFACT
    from vbt.precompute.cpp_file_writes_db import CPP_FILE_WRITES_ARTIFACT
    from vbt.precompute.fn_facts_db import FN_FACTS_ARTIFACT

    missing: list = []
    warnings: list = []
    counts: dict = {}

    eng = get_engine(job_id)
    with eng.connect() as c:
        def _one(art):
            return c.execute(_sqltext(
                "SELECT length(payload) FROM vbt_artifact_blob "
                "WHERE job_id = :j AND artifact = :a"),
                {"j": job_id, "a": art}).first()

        def _grp(like):
            return int(c.execute(_sqltext(
                "SELECT COUNT(*) FROM vbt_artifact_blob "
                "WHERE job_id = :j AND artifact LIKE :l"),
                {"j": job_id, "l": like}).scalar() or 0)

        # Singleton required: trace fails or runs cold without these.
        hard_required = (
            (FILE_CALL_GRAPH_ARTIFACT, "file_call_graph"),
            (ROUTE_NAME_TO_STEMS_ARTIFACT, "route_name_to_stems"),
            (CPP_CALL_EDGES_ARTIFACT, "cpp_call_edges"),
            (NAME_ALIAS_ARTIFACT, "name_alias"),
            (MEMBERSHIP_ARTIFACT, "membership"),
            (CONST_ARTIFACT, "const"),
            (MODIFIER_ARTIFACT, "modifier_index"),
        )
        for art, label in hard_required:
            if _one(art) is None:
                missing.append(label)

        # Speedup-or-cliff: at 24k a missing one of these means multi-minute fallback.
        speedup = (
            (REVERSE_ADJ_ARTIFACT, "reverse_adj"),
            (FORWARD_FILE_ADJ_ARTIFACT, "forward_file_adj"),
            (FN_GRAPH_ADJ_ARTIFACT, "fn_graph_adj"),
            (FN_FACTS_ARTIFACT, "fn_facts"),
        )
        for art, label in speedup:
            if _one(art) is None:
                (missing if require_speedup_artifacts else warnings).append(label)

        # Per-stem coverage — the parts the pre-existing _has_db_trace_artifacts
        # did NOT check. A pipeline that died midway through these still leaves
        # the singletons looking complete — that is the silent cliff.
        per_stem = (
            (ASM_SETTER_MAP_ARTIFACT + ":%", "asm_setter_map"),
            (CPP_SETTER_MAP_ARTIFACT + ":%", "cpp_setter_map"),
            (CPP_FILE_WRITES_ARTIFACT + ":%", "cpp_file_writes"),
        )
        for like, label in per_stem:
            n = _grp(like)
            counts[label] = n
            if n == 0:
                (missing if require_speedup_artifacts else warnings).append(label)

        counts["cpp_blueprints"] = _grp("bp:%.cpp.json")
        counts["asm_blueprints"] = _grp("bp:%.asm.json") + _grp("bp:%.mac.json")
        counts["cpp_source"] = _grp("src:%.cpp")
        counts["asm_source"] = _grp("src:%.asm") + _grp("src:%.mac")
        counts["cfg_blobs"] = int(c.execute(_sqltext(
            "SELECT COUNT(*) FROM vbt_cfg_blob WHERE job_id = :j"),
            {"j": job_id}).scalar() or 0)

        if counts["cpp_blueprints"] == 0:
            missing.append("cpp_blueprints (bp:*.cpp.json)")
        if counts["cpp_source"] == 0:
            missing.append("cpp_source (src:*.cpp)")
        if counts["cfg_blobs"] == 0:
            (missing if require_speedup_artifacts else warnings).append("cfg_blobs")

    # Disk cross-check: do counts match the source dir?
    if blueprint_dir is not None:
        bp = Path(blueprint_dir)
        if bp.is_dir():
            disk_cpp = len(list(bp.glob("*.cpp.json")))
            if disk_cpp != counts.get("cpp_blueprints", 0):
                warnings.append(
                    f"blueprint count mismatch — disk={disk_cpp} db={counts['cpp_blueprints']}"
                )
    if asm_dir is not None:
        ad = Path(asm_dir)
        if ad.is_dir():
            disk_cpp_src = len(list(ad.glob("*.cpp")))
            if disk_cpp_src != counts.get("cpp_source", 0):
                warnings.append(
                    f"cpp source count mismatch — disk={disk_cpp_src} db={counts['cpp_source']}"
                )

    return {
        "status": "FAIL" if missing else "PASS",
        "missing": missing,
        "warnings": warnings,
        "counts": counts,
    }


def _health_summary_lmdb(job_id: str, blueprint_dir, asm_dir,
                         require_speedup_artifacts: bool) -> dict:
    """LMDB variant of ``health_summary`` (W12).

    Walks the LMDB env's ``blobs`` and ``cfg`` sub-DBs with a cursor for counts
    (fast — keys are short, sub-µs each), and probes manifest presence by
    direct ``get``. No payload decode; size estimates skipped (LMDB stores
    payload + key in one record, ``stat()`` totals are env-wide).
    """
    from vbt.precompute import lmdb_store as _ls
    from vbt.precompute.graph_db import (FILE_CALL_GRAPH_ARTIFACT, ROUTE_NAME_TO_STEMS_ARTIFACT,
                                         CPP_CALL_EDGES_ARTIFACT, REVERSE_ADJ_ARTIFACT,
                                         FORWARD_FILE_ADJ_ARTIFACT, FN_GRAPH_ADJ_ARTIFACT)
    from vbt.precompute.resolvers_db import (NAME_ALIAS_ARTIFACT, MEMBERSHIP_ARTIFACT,
                                             CONST_ARTIFACT, MODIFIER_ARTIFACT)
    from vbt.precompute.setter_map_db import ASM_SETTER_MAP_ARTIFACT
    from vbt.precompute.cpp_setter_map_db import CPP_SETTER_MAP_ARTIFACT
    from vbt.precompute.cpp_file_writes_db import CPP_FILE_WRITES_ARTIFACT
    from vbt.precompute.fn_facts_db import FN_FACTS_ARTIFACT

    missing: list = []
    warnings: list = []
    counts: dict = {}

    env, subs = _ls._env(job_id)
    if env is None:
        return {"status": "FAIL", "missing": ["lmdb env (none)"],
                "warnings": [], "counts": {}}

    def _one(art):
        with env.begin(db=subs["blobs"], buffers=True) as txn:
            return txn.get(art.encode("utf-8")) is not None

    def _grp(prefix: str) -> int:
        pb = prefix.encode("utf-8")
        n = 0
        with env.begin(db=subs["blobs"], buffers=True) as txn:
            cur = txn.cursor()
            if cur.set_range(pb):
                for k, _v in cur:
                    if not bytes(k).startswith(pb):
                        break
                    n += 1
        return n

    hard_required = (
        (FILE_CALL_GRAPH_ARTIFACT, "file_call_graph"),
        (ROUTE_NAME_TO_STEMS_ARTIFACT, "route_name_to_stems"),
        (CPP_CALL_EDGES_ARTIFACT, "cpp_call_edges"),
        (NAME_ALIAS_ARTIFACT, "name_alias"),
        (MEMBERSHIP_ARTIFACT, "membership"),
        (CONST_ARTIFACT, "const"),
        (MODIFIER_ARTIFACT, "modifier_index"),
    )
    for art, label in hard_required:
        if not _one(art):
            missing.append(label)

    speedup = (
        (REVERSE_ADJ_ARTIFACT, "reverse_adj"),
        (FORWARD_FILE_ADJ_ARTIFACT, "forward_file_adj"),
        (FN_GRAPH_ADJ_ARTIFACT, "fn_graph_adj"),
        (FN_FACTS_ARTIFACT, "fn_facts"),
    )
    for art, label in speedup:
        if not _one(art):
            (missing if require_speedup_artifacts else warnings).append(label)

    per_stem = (
        (ASM_SETTER_MAP_ARTIFACT + ":", "asm_setter_map"),
        (CPP_SETTER_MAP_ARTIFACT + ":", "cpp_setter_map"),
        (CPP_FILE_WRITES_ARTIFACT + ":", "cpp_file_writes"),
    )
    for prefix, label in per_stem:
        n = _grp(prefix)
        counts[label] = n
        if n == 0:
            (missing if require_speedup_artifacts else warnings).append(label)

    counts["cpp_blueprints"] = _grp("bp:") and sum(
        1 for _ in _iter_keys_with_filter(env, subs["blobs"], b"bp:", b".cpp.json")
    )
    counts["asm_blueprints"] = sum(
        1 for _ in _iter_keys_with_filter(env, subs["blobs"], b"bp:", b".asm.json")
    ) + sum(
        1 for _ in _iter_keys_with_filter(env, subs["blobs"], b"bp:", b".mac.json")
    )
    counts["cpp_source"] = sum(
        1 for _ in _iter_keys_with_filter(env, subs["blobs"], b"src:", b".cpp")
    )
    counts["asm_source"] = sum(
        1 for _ in _iter_keys_with_filter(env, subs["blobs"], b"src:", b".asm")
    ) + sum(
        1 for _ in _iter_keys_with_filter(env, subs["blobs"], b"src:", b".mac")
    )
    # cfg blobs live in their own sub-db, not the blob namespace.
    with env.begin(db=subs["cfg"]) as txn:
        counts["cfg_blobs"] = txn.stat().get("entries", 0)

    if counts["cpp_blueprints"] == 0:
        missing.append("cpp_blueprints (bp:*.cpp.json)")
    if counts["cpp_source"] == 0:
        missing.append("cpp_source (src:*.cpp)")
    if counts["cfg_blobs"] == 0:
        (missing if require_speedup_artifacts else warnings).append("cfg_blobs")

    if blueprint_dir is not None:
        bp = Path(blueprint_dir)
        if bp.is_dir():
            disk_cpp = len(list(bp.glob("*.cpp.json")))
            if disk_cpp != counts.get("cpp_blueprints", 0):
                warnings.append(
                    f"blueprint count mismatch — disk={disk_cpp} db={counts['cpp_blueprints']}"
                )
    if asm_dir is not None:
        ad = Path(asm_dir)
        if ad.is_dir():
            disk_cpp_src = len(list(ad.glob("*.cpp")))
            if disk_cpp_src != counts.get("cpp_source", 0):
                warnings.append(
                    f"cpp source count mismatch — disk={disk_cpp_src} db={counts['cpp_source']}"
                )

    return {
        "status": "FAIL" if missing else "PASS",
        "missing": missing,
        "warnings": warnings,
        "counts": counts,
        "backend": "lmdb",
    }


def _iter_keys_with_filter(env, db, prefix: bytes, suffix: bytes):
    """Yield LMDB keys under ``prefix`` whose decoded form also ends with ``suffix``."""
    with env.begin(db=db, buffers=True) as txn:
        cur = txn.cursor()
        if not cur.set_range(prefix):
            return
        for k, _v in cur:
            kb = bytes(k)
            if not kb.startswith(prefix):
                return
            if kb.endswith(suffix):
                yield kb


def _hop(spec: str):
    parts = spec.split(":")
    if len(parts) < 2:
        raise argparse.ArgumentTypeError(f"--test-hop must be stem:type[:function], got {spec!r}")
    return (parts[0], parts[1], parts[2] if len(parts) > 2 else None)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="vbt.precompute.verify_db", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--job-id", required=True)
    ap.add_argument("--blueprint-dir", type=Path, default=None)
    ap.add_argument("--asm-dir", type=Path, default=None)
    ap.add_argument("--sample", type=int, default=3,
                    help="blobs to decode PER artifact type for the integrity check (bounded; default 3)")
    ap.add_argument("--test-variable", default=None)
    ap.add_argument("--test-language", default="cpp")
    ap.add_argument("--test-hop", action="append", dest="test_hops", type=_hop, default=None)
    a = ap.parse_args(argv)
    return verify(a.job_id, a.blueprint_dir, a.asm_dir, a.sample,
                  a.test_variable, a.test_language, a.test_hops)


if __name__ == "__main__":
    raise SystemExit(main())
