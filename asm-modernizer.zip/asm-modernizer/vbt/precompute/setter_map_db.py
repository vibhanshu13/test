"""Phase 1 — per-file ASM setter map (precompute the setter SCAN, not just the bytes).

`find_asm_setters_in_file(var, stem)` does ~6 full-file block passes to detect a variable's setter
sites (value, guard-source, role, …). At 10k-ASM, re-running that per (var, stem) — for the root
search AND for every dep var — is the dominant trace-time compute. This precomputes it: for each ASM
stem, store `{normalized_var: [SetterSite-as-dict]}` = the VERBATIM output of `find_asm_setters_in_file`
for every variable the modifier index says the stem modifies. A trace then LOOKS IT UP.

Byte-identical by construction: the stored sites ARE `find_asm_setters_in_file`'s output; at trace we
return them with the `variable` field set to the queried form (the only per-call-varying field). A
variable absent from a loaded stem's map → return None → caller falls back to the live scan (so an
incomplete precompute can never change output, only forgo the speedup). Per-stem blobs ⇒ a trace
loads only its candidate files (memory-safe at 22k). Lookups are disabled unless load-only is armed,
so the precompute build itself still SCANS (it must, to produce the map).
"""
from __future__ import annotations

import logging
from dataclasses import asdict
from pathlib import Path
from typing import Dict, List, Optional

from vbt.precompute import db_artifacts as DA
from vbt.interfaces import SetterSite
from backward_traversal.utils.token_utils import normalize_token

logger = logging.getLogger(__name__)

ASM_SETTER_MAP_ARTIFACT = "asm_setter_map"        # per-stem blob: f"{ARTIFACT}:{stem}"

# Bounded per-process cache of loaded per-stem maps. Value: dict (loaded) | None (no blob for the
# stem) | sentinel 0 (not yet looked up). Reload on eviction → byte-identical.
_LOADED: Dict[tuple, object] = {}
_LOADED_MAX = 4096


def _build_one_asm_setter_map(args):
    """ProcessPool worker: build the {var: [SetterSite-dict]} map for a single ASM stem.

    Input tuple: (stem, sorted_vars_list, blueprint_dir_str, asm_dir_str).
    Each worker does its own _augment_universe + find_asm_setters_in_file calls. Pickle-safe.
    Returns (stem, payload_or_None) where payload is the gzip-compressed blob."""
    try:
        from dataclasses import asdict as _asdict
        from pathlib import Path as _Path
        from vbt.setters.asm_setters import find_asm_setters_in_file
        from vbt.precompute import db_artifacts as _DA
        from backward_traversal.utils.token_utils import normalize_token as _nt
        stem, vars_list, bp_str, src_str = args
        bp = _Path(bp_str)
        src = _Path(src_str)
        vars_ = _augment_universe(stem, set(vars_list), bp, src)
        m: Dict[str, list] = {}
        for var in vars_:
            try:
                sites = find_asm_setters_in_file(var, stem, bp, src)
            except Exception:
                sites = []
            if sites:
                m[_nt(var).upper()] = [_asdict(s) for s in sites]
        if not m:
            return (stem, None)
        return (stem, _DA.dumps_gz(m))
    except Exception:
        try:
            return (args[0], None)
        except Exception:
            return ("", None)


def build_and_store_asm_setter_map(job_id, blueprint_dir, asm_dir) -> int:
    """Build + store the per-stem ASM setter map. Returns the number of stems stored.

    Parallelized: each ProcessPool worker handles one stem (augment_universe + the inner
    find_asm_setters_in_file loop), returns the gzip-compressed blob. Parent writes blobs
    serially (sqlite single-writer). Byte-identical to the serial path: every worker performs
    the same deterministic compute and the parent writes in INPUT-ORDERED sequence."""
    from vbt.precompute.modifier_index import get_modifier_index
    bp, src = Path(blueprint_dir), Path(asm_dir)
    midx = get_modifier_index(bp, src)
    stem_vars: Dict[str, set] = {}
    for var, files in midx.asm.items():
        for stem in files:
            stem_vars.setdefault(stem, set()).add(var)
    DA.clear_blobs_prefix(job_id, ASM_SETTER_MAP_ARTIFACT + ":")
    # Sort vars per stem for determinism; sort stems for determinism.
    items = [
        (stem, sorted(vars_), str(bp), str(src))
        for stem, vars_ in sorted(stem_vars.items())
    ]
    try:
        from vbt.precompute.parallel import parallel_map
        results = parallel_map(_build_one_asm_setter_map, items)
    except Exception as exc:
        logger.debug("parallel asm_setter_map fallback: %s", exc)
        results = [_build_one_asm_setter_map(it) for it in items]
    n = 0
    for stem, payload in results:
        if payload is None:
            continue
        try:
            if DA.write_blob(job_id, f"{ASM_SETTER_MAP_ARTIFACT}:{stem}", payload):
                n += 1
        except Exception as exc:
            logger.debug("store asm_setter_map:%s failed: %s", stem, exc)
    return n


def _augment_universe(stem: str, vars_: set, blueprint_dir: Path, asm_dir: Path) -> set:
    """Expand the candidate var set to the ROBUST engine's OWN detection sources, not just the
    narrower modifier-index dest-scan: FLIPC level-aliases (CE1CRn↔CE1CRm) + the four implicit-write
    collectors (level-alloc / DETAC-ATTAC flags / DB-managed fields / macro-fixed results), which
    each return a complete ``{var -> sites}`` map. Reuses those engine functions verbatim, so the
    universe matches what find_asm_setters can detect. find_asm_setters returns [] for a non-setter
    candidate ⇒ over-including is harmless. Best-effort; the byte-identical fallback (live scan)
    still covers any harder-aliasing var (range-write / EX) we don't pre-store."""
    try:
        from backward_traversal.utils.blueprint_utils import resolve_asm_blueprint, load_json
        from backward_traversal.runner.backward_only_runner import (
            _collect_flipc_level_aliases, _collect_level_alloc_setter_sites,
            _collect_detac_attac_flag_writes, _collect_db_managed_field_writes,
            _collect_macro_fixed_result_writes)
        bpp = resolve_asm_blueprint(stem, blueprint_dir)
        if not bpp:
            return vars_
        bp = load_json(bpp)
        blocks = {str(b.get("id") or "") for b in (bp.get("blocks") or []) if b.get("id")}
        adir = Path(asm_dir) if asm_dir else None
        asm_file = (adir / f"{stem}.asm") if adir else Path(f"{stem}.asm")
        fa = _collect_flipc_level_aliases(bp, blocks)
        vars_ = vars_ | set(fa.keys()) | {a for v in fa.values() for a in v}
        for coll in (_collect_level_alloc_setter_sites, _collect_detac_attac_flag_writes,
                     _collect_db_managed_field_writes, _collect_macro_fixed_result_writes):
            try:
                vars_ |= set(coll(bp, blocks, asm_file, adir).keys())
            except Exception:
                pass
        return vars_
    except Exception:
        return vars_


def load_asm_setters(job_id, stem: str, variable: str) -> Optional[List[SetterSite]]:
    """Precomputed setter sites for (stem, variable), or None to signal 'fall back to the live scan'.

    None when the stem has no blob OR the variable isn't in the stem's map (so an incomplete
    precompute degrades to the live scan, never to a wrong empty result). A hit returns reconstructed
    SetterSites with `variable` set to the queried form — byte-identical to the live scan."""
    key = (job_id, stem)
    m = _LOADED.get(key, 0)
    if m == 0:
        payload = DA.read_blob(job_id, f"{ASM_SETTER_MAP_ARTIFACT}:{stem}")
        m = DA.loads_gz(payload) if payload is not None else None
        if len(_LOADED) >= _LOADED_MAX:
            _LOADED.pop(next(iter(_LOADED)))
        _LOADED[key] = m
    if not m:
        return None                                   # no blob for this stem → live scan
    rows = m.get(normalize_token(variable).upper())
    if rows is None:
        return None                                   # var not precomputed here → live scan (safe)
    out: List[SetterSite] = []
    for d in rows:
        s = SetterSite(**d)
        s.variable = variable                         # byte-identity: the queried form is returned
        out.append(s)
    return out
