"""GAP 1 — decompose safe compound C/C++ guard predicates into simple value-guard facts.

The feasibility pruner (``vbt.lca_feasibility``) reasons over SIMPLE value guards:
``scrutinee <op> constant`` with ``op`` ∈ {"eq","ne"}. A real guard, however, is often a
COMPOUND boolean expression — the CID gate

    (rc != NoCidRecord)
      && ((tc == CreditRequest) || (tc == WorkedFromReferralQue) || ... )

is one guard text but encodes one ``ne`` fact on ``rc`` and a same-scrutinee equality
DISJUNCTION on ``tc``. ``parse_required_guard`` deliberately rejects anything with a
top-level ``&&``/``||``, so without this module those gates are opaque and never prune.

This module performs ONLY the two boolean rewrites that are SOUND for the feasibility
decider, which treats multiple equality guards on the SAME scrutinee at the SAME hop as a
disjunction (``scrut ∈ S``):

  1. TOP-LEVEL CONJUNCTION (``a && b && …``) — every conjunct is a NECESSARY condition, so
     each that parses to a simple value guard is emitted independently.
  2. HOMOGENEOUS EQUALITY DISJUNCTION on ONE scrutinee (``x==C1 || x==C2 || …``) — emitted as
     one ``eq`` fact per leaf; the decider already unions same-scrutinee/same-hop equalities.

Everything else (mixed scrutinees, any ``ne`` inside a disjunction, nested conjunctions, an
``(a&&b)||c`` shape, function calls, non-constant operands, anything over a cap) emits
NOTHING for that fragment. We do NOT distribute, build CNF/DNF, or recurse into nested
parens. SOUNDNESS IS PARAMOUNT: when in doubt, emit nothing. A missing fact only ever
reduces pruning (keep-unknown) — it can never cause a false drop.
"""
from __future__ import annotations

from typing import List, Tuple

from vbt.lca_feasibility import parse_required_guard, _strip_outer_parens

# How many simple guard facts a single compound condition may yield. An over-cap compound is
# treated conservatively: emit NOTHING (keep-unknown) rather than a partial set.
MAX_DECOMPOSED_GUARDS_PER_CONDITION = 16
# Refuse to even tokenize an expression longer than this (DoS / pathological-input guard).
MAX_EXPR_CHARS_FOR_DECOMPOSITION = 4096


def _split_top_level(expr: str, op: str) -> List[str]:
    """Split ``expr`` on the 2-char boolean operator ``op`` ("&&" or "||") ONLY at
    paren-depth 0 and NOT inside single/double-quoted literals.

    Returns the list of fragments, each stripped. A single ``&`` or ``|`` is NEVER a split
    point — only the exact 2-char operator matches. If there is no top-level split point the
    result is a length-1 list ``[expr.strip()]``.
    """
    s = expr
    n = len(s)
    frags: List[str] = []
    buf: List[str] = []
    depth = 0
    quote = ""        # "" = not in a literal; otherwise the opening quote char
    i = 0
    while i < n:
        ch = s[i]
        if quote:
            buf.append(ch)
            if ch == "\\" and i + 1 < n:
                # escaped char inside the literal — consume the next char verbatim.
                buf.append(s[i + 1])
                i += 2
                continue
            if ch == quote:
                quote = ""
            i += 1
            continue
        if ch == "'" or ch == '"':
            quote = ch
            buf.append(ch)
            i += 1
            continue
        if ch == "(":
            depth += 1
            buf.append(ch)
            i += 1
            continue
        if ch == ")":
            depth -= 1
            buf.append(ch)
            i += 1
            continue
        if depth == 0 and s[i:i + 2] == op:
            frags.append("".join(buf).strip())
            buf = []
            i += 2
            continue
        buf.append(ch)
        i += 1
    frags.append("".join(buf).strip())
    return frags


def _decompose(text: str, max_parts: int) -> Tuple[List[dict], bool]:
    """Core worker. Returns ``(facts, capped)``.

    ``capped`` is True when a length or part-count cap was hit; in that case ``facts`` is
    ALWAYS ``[]`` (conservative: an over-cap compound contributes nothing).
    """
    if text is None:
        return [], False
    raw = text.strip()
    if not raw:
        return [], False
    if len(text) > MAX_EXPR_CHARS_FOR_DECOMPOSITION:
        return [], True

    t = _strip_outer_parens(raw)
    facts: List[dict] = []
    seen = set()  # (scrutinee, const, op, text) for first-occurrence dedup

    def _emit(scrut: str, const: str, op: str, frag: str) -> bool:
        """Append a fact (deduped). Return False iff the part-count cap was exceeded."""
        key = (scrut, const, op, frag)
        if key in seen:
            return True
        if len(facts) + 1 > max_parts:
            return False
        seen.add(key)
        facts.append({"text": frag, "scrutinee": scrut, "const": const, "op": op})
        return True

    for conj in _split_top_level(t, "&&"):
        c = _strip_outer_parens(conj.strip())
        if not c:
            continue

        # (b) simple value guard: x==A / x!=A / !(...) / bitmask (F & M) == M
        parsed = parse_required_guard(c)
        if parsed is not None:
            scrut, const, op = parsed
            if not _emit(scrut, const, op, c):
                return [], True
            continue

        # (c) homogeneous equality disjunction on ONE scrutinee: x==C1 || x==C2 || …
        disj = _split_top_level(c, "||")
        if len(disj) < 2:
            continue  # not a disjunction → unsupported conjunct → emit nothing for it

        leaves: List[Tuple[str, str, str, str]] = []
        safe = True
        for leaf in disj:
            lf = _strip_outer_parens(leaf.strip())
            p = parse_required_guard(lf)
            if p is None or p[2] != "eq":
                safe = False
                break
            leaves.append((p[0], p[1], p[2], lf))
        if not safe:
            continue
        # require a single shared scrutinee across all leaves.
        if len({lv[0] for lv in leaves}) != 1:
            continue
        for scrut, const, op, lf in leaves:
            if not _emit(scrut, const, op, lf):
                return [], True

    return facts, False


def decompose_value_guards(
    text: str, *, max_parts: int = MAX_DECOMPOSED_GUARDS_PER_CONDITION
) -> List[dict]:
    """Return parsed simple value guards extracted from a (possibly compound) condition.

    Each dict has EXACTLY these keys:
    ``{"text": <fragment str>, "scrutinee": <str>, "const": <str>, "op": "eq"|"ne"}``.

    Returns ``[]`` for unsupported shapes, empty input, or when a cap is exceeded
    (conservative keep-unknown). See module docstring for the exact sound rewrites.
    """
    return _decompose(text, max_parts)[0]


def decompose_value_guards_diag(
    text: str, *, max_parts: int = MAX_DECOMPOSED_GUARDS_PER_CONDITION
) -> Tuple[List[dict], bool]:
    """Same as :func:`decompose_value_guards`, but also reports whether a cap was hit.

    Returns ``(facts, capped)`` where ``capped`` is True iff the part-count or char-length
    cap was exceeded. ``decompose_value_guards(...) == decompose_value_guards_diag(...)[0]``.
    """
    return _decompose(text, max_parts)
