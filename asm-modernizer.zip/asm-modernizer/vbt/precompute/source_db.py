"""DB-backed raw source text (DB_PRECOMPUTE_PLAN.md T9).

At trace time the output code-block slicer (`CodeBlockStore`), the tree-sitter guard fallback
(`ts_enclosing_guards`), and the ASM constant-symbol scan (`collect_constant_symbols`) read raw
`.cpp`/`.asm`/`.mac`/`.hpp` SOURCE files.  This module stores each source file's RAW BYTES in
index.db and installs a `source_override` so those reads come from DB.

Behavior preservation: RAW BYTES are stored, and each consumer applies ITS existing decode
(text slicers) or uses the bytes directly (tree-sitter), so output is byte-identical.  Storage
is PER FILE and loaded lazily on first touch (scale-correct).  Build is precompute-only; the
trace installs LOAD-ONLY and the consumers fall back to their own disk read when the override
returns None (so a cold DB / job_id=None path is unchanged).
"""
from __future__ import annotations

import gzip
import logging
from pathlib import Path
from typing import List, Optional

from vbt.precompute import db_artifacts as DA

logger = logging.getLogger(__name__)

SOURCE_MANIFEST = "source"
SOURCE_VERSION = 1
_PATTERNS = ("*.cpp", "*.asm", "*.mac", "*.hpp")


def _src_files(asm_dir: Path) -> List[Path]:
    src = Path(asm_dir)
    files: List[Path] = []
    for pat in _PATTERNS:
        files.extend(sorted(src.glob(pat)))
    return files


def build_and_store_source(job_id, asm_dir) -> int:
    """Precompute (one-shot): store every source file's raw bytes (gzipped) + a manifest.
    Precompute-only — NOT the trace path. Returns the count stored."""
    src = Path(asm_dir)
    files = _src_files(src)
    shash = DA.source_manifest_hash(files, version=SOURCE_VERSION)
    n = 0
    for f in files:
        try:
            if DA.write_blob(job_id, f"src:{f.name}", gzip.compress(f.read_bytes(), mtime=0)):
                n += 1
        except Exception as exc:
            logger.debug("store src:%s failed: %s", f.name, exc)
    DA.write_manifest(job_id, SOURCE_MANIFEST, SOURCE_VERSION, shash)
    return n


def install_source_override(job_id: Optional[str], asm_dir) -> bool:
    """Install a source override serving THIS job's source bytes from DB (lazy, per file,
    cached) when a fresh artifact exists. Returns True iff installed."""
    if not job_id:
        return False
    src_dir = Path(asm_dir)
    try:
        src_resolved = src_dir.resolve()
    except Exception:
        return False
    # T12: trace-time = O(1) presence check (no O(files) source hash). Per-file GET misses fall
    # back to disk, so correctness holds even on a stale/partial set.
    if DA.is_load_only():
        if not DA.manifest_present(job_id, SOURCE_MANIFEST):
            return False
    else:
        try:
            shash = DA.source_manifest_hash(_src_files(src_dir), version=SOURCE_VERSION)
        except Exception:
            return False
        if not DA.manifest_fresh(job_id, SOURCE_MANIFEST, version=SOURCE_VERSION, source_hash=shash):
            return False

    cache: dict = {}

    def _override(path_str: str):
        p = Path(path_str)
        name = p.name
        try:                                      # only serve THIS job's source dir
            if p.resolve().parent != src_resolved:
                return None
        except Exception:
            return None
        if name in cache:
            return cache[name]
        payload = DA.read_blob(job_id, f"src:{name}")
        out = gzip.decompress(payload) if payload is not None else None
        cache[name] = out
        return out

    from backward_traversal.utils.blueprint_utils import set_source_override
    set_source_override(_override)
    return True
