"""Precompute the C++→ASM **TPF_regs register-bridge** writers (GAP 6 data-source branch).

The reported gap: a backward trace of ``cardUseIndicator`` / ``softCardValue`` / ``allCidRecords``
dead-ends at ``allCidRecordWorkArea`` — a stack buffer that is *declared + zeroed* in C++ and then
populated by an ASM module reached through the z/TPF register convention
(``regs.r1 = (long)&workArea; callAccountManager(&regs);`` with ``#pragma map(callAccountManager,"SL70")``).
The C++ value-flow stops at the buffer because the populator has no C++ body.

This module recovers, **once per file in precompute**, the *data-source* of such a buffer: a synthetic
``SetterSite`` anchored at the guarded call line, resolved to its ASM module via the corpus-global
``#pragma map`` / ``asm()`` binding (``callAccountManager → SL70``) or — when unbound — the callee
identifier itself (``retrieveCrcnCidData``). The C++ guard at the call (``memcmp(productType,"VPAY",4)==0``)
is collected and baked into ``preset_conditions`` so the trace surfaces the branch without re-reading
source. A trace loads these per-stem and merges them into the setter list for an init-only buffer.

NOT GENERIC (see docs/2026-06-28-gap6-datasource-branch-FIX-PLAN.md §6): a setter is emitted only for the
precise conjunction — an **escape-only, explicitly zeroed** stack buffer whose address provably reaches a
call argument through the register/struct chain, where the **callee has no C++ body in-corpus** (an
ASM/external entry). Every fact comes from code: the parsed AST, the actual ``&``-assignments, the
``#pragma map``/``asm()`` directives (already comment-stripped by ``_extract_symbol_aliases``), and the
collected guards. No fact is inferred from a comment, and a commented-out ``//#pragma`` never binds.

Storage/round-trip mirrors ``cpp_file_writes_db``: per-stem gz blob ``cpp_indirect_writes:{stem}`` =
``{buffer_root: [SetterSite-row...]}`` plus an explicit (de)serializer for the nested
``preset_conditions`` (Condition→Location) and the dynamic ``bridge`` attribute. A corpus-global
``cpp_asm_bindings`` blob holds ``{callee→asm_module}`` + the set of C++-defined function names so a call
site can resolve a binding declared in a header it #includes (the call site's own blueprint has none).

A stem absent from the DB → ``None`` → indirect feature off for that stem (no live parse in a load-only
trace; the merge is simply skipped + a warning). In FILE mode (no job/load-only), the writers are
computed live — exactly as ``_file_writes`` parses live off a job — so the feature works in both modes.
The whole feature is gated by the trace ``emit_indirect_writes`` flag (default off ⇒ byte-identical).
"""
from __future__ import annotations

import logging
import re
from collections import defaultdict
from dataclasses import asdict as _asdict, fields as _dc_fields
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from vbt.precompute import db_artifacts as DA
from vbt.interfaces import SetterSite, Condition, Location

logger = logging.getLogger(__name__)

CPP_INDIRECT_WRITES_ARTIFACT = "cpp_indirect_writes"   # per-stem blob: f"{ARTIFACT}:{stem}"
CPP_ASM_BINDINGS_ARTIFACT = "cpp_asm_bindings"         # single corpus-global blob

_SS_FIELDS = [f.name for f in _dc_fields(SetterSite)]
_COND_FIELDS = [f.name for f in _dc_fields(Condition) if f.name != "location"]

_LOADED: Dict[tuple, object] = {}                  # (job, stem) -> {base:[row]} | None | sentinel 0
_LOADED_MAX = 4096
_BINDINGS_LOADED: Dict[Any, object] = {}           # job_id -> {bindings, defined_fns} | None | 0
_LIVE_BINDINGS: Dict[str, dict] = {}               # str(blueprint_dir) -> aggregated (FILE mode)
_LIVE_WRITERS: Dict[tuple, dict] = {}              # (asm_dir, blueprint_dir, stem) -> {base:[SetterSite]}

_INDIRECT_WRITES_JOB: Optional[str] = None


def set_cpp_indirect_writes_job(job_id: Optional[str]) -> None:
    """Engine hook: arm the precomputed indirect-writes lookup for ``job_id`` (None ⇒ off)."""
    global _INDIRECT_WRITES_JOB
    _INDIRECT_WRITES_JOB = job_id


def get_cpp_indirect_writes_job() -> Optional[str]:
    return _INDIRECT_WRITES_JOB


# --------------------------------------------------------------------------- #
# (de)serialization — SetterSite + nested preset_conditions + dynamic bridge
# --------------------------------------------------------------------------- #
def _cond_to_dict(c: Condition) -> dict:
    return _asdict(c)                                   # recurses Location → dict


def _cond_from_dict(d: dict) -> Condition:
    d = dict(d)
    loc = d.pop("location", None) or {}
    return Condition(location=Location(**loc), **{k: d.get(k) for k in _COND_FIELDS})


def _ss_to_row(site: SetterSite) -> dict:
    d = _asdict(site)
    d.pop("preset_conditions", None)                    # rebuilt explicitly below
    d["preset_conditions"] = [_cond_to_dict(c) for c in (site.preset_conditions or [])]
    d["lhs_path"] = getattr(site, "lhs_path", "")
    d["bridge"] = getattr(site, "bridge", None)
    return d


def _row_to_ss(d: dict) -> SetterSite:
    s = SetterSite(**{k: d.get(k) for k in _SS_FIELDS if k != "preset_conditions"})
    s.preset_conditions = [_cond_from_dict(c) for c in (d.get("preset_conditions") or [])]
    s.lhs_path = d.get("lhs_path", "")
    s.bridge = d.get("bridge")
    return s


# --------------------------------------------------------------------------- #
# Escape closure + bridge attribution (the core, bounded intraprocedural pass)
# --------------------------------------------------------------------------- #
_ZERO_FILL = re.compile(r"0[xX]?0*\Z")
_REG_FIELD = re.compile(r"r(\d|1[0-5])\Z")             # r0 .. r15 (TPF_regs carriers)
_CAST = re.compile(r"^\s*\((?:[^()]*)\)\s*")           # one leading C-style cast

# C/C++ library calls that move/compare bytes through a buffer pointer but are NOT ASM-module
# entry points — they must never be mistaken for a cross-language data source.
_BUILTIN_CALLEES = frozenset({
    "memcmp", "memcpy", "memset", "memmove", "bcopy", "bcmp", "bzero",
    "strcmp", "strncmp", "strcpy", "strncpy", "strcat", "strncat", "strlen",
    "sprintf", "snprintf", "sscanf", "printf", "fprintf", "sizeof",
})


def _stem_of(p: Path) -> str:
    stem = p.name
    for suf in (".cpp", ".hpp", ".cc", ".cxx", ".c", ".h"):
        if stem.lower().endswith(suf):
            return stem[: -len(suf)]
    return stem


def _is_zero_fill(val: str) -> bool:
    """True for a memset fill byte that zeroes (``0`` / ``0x0`` / ``0X00`` …)."""
    return bool(val) and bool(_ZERO_FILL.fullmatch(val.strip()))


def _addr_of_base(val: Optional[str]) -> Optional[str]:
    """If ``val`` is ``(cast)?&EXPR`` return the base identifier of EXPR, else None.

    ``(long)&workArea`` → ``workArea``; ``&allCidRecordWorkArea.workArea[0]`` → ``allCidRecordWorkArea``;
    a non-address RHS (a call, a literal) → None. Operates on the parsed RHS text (no comments)."""
    if not val:
        return None
    v = _CAST.sub("", val.strip()).strip()
    if not v.startswith("&"):
        return None
    m = re.match(r"[A-Za-z_]\w*", v[1:].strip())
    return m.group(0) if m else None


def _arg_base(val: Optional[str]) -> Optional[str]:
    """Base identifier of a call argument: strips a cast and leading ``& *`` (``&regs`` → ``regs``)."""
    if not val:
        return None
    v = _CAST.sub("", val.strip()).lstrip("&* \t")
    m = re.match(r"[A-Za-z_]\w*", v)
    return m.group(0) if m else None


def _is_zero_memset(s: SetterSite) -> bool:
    return (s.instruction or "").startswith("builtin(memset)") and _is_zero_fill(s.value or "")


def compute_bridge_writers(
    cpp_path,
    *,
    bindings: Dict[str, str],
    defined_fns: Set[str],
    get_cfg,
) -> Dict[str, List[SetterSite]]:
    """Return ``{buffer_root: [SetterSite]}`` for the TPF_regs ASM-bridge idiom in ``cpp_path``.

    ``bindings``     corpus-global ``{callee → asm_module}`` (from ``#pragma map`` / ``asm()``).
    ``defined_fns``  C++ function names defined in-corpus (a callee here is a normal call, NOT a bridge).
    ``get_cfg``      ``() -> cfg functions`` for ``cpp_path`` (DB-served in precompute / live in file mode);
                     called at most once, and only when a bridge candidate exists.

    Reuses ``_file_writes`` (battle-tested, DB-servable) for the address edges + escape-only test, and a
    single tree-sitter walk for the calls + their argument objects + TPF_regs locals. Comment-blind by
    construction (assignments/calls/declarations are AST code nodes; comments are separate nodes)."""
    from vbt.setters.cpp_setters import (
        _file_writes, _src_and_tree, _iter, _txt, _enclosing_function,
    )
    from vbt.conditions.cpp_conditions import collect_cpp_conditions

    cpp_path = Path(cpp_path)
    stem = _stem_of(cpp_path)
    try:
        writes = _file_writes(cpp_path)
    except Exception:
        return {}

    # ---- bucket writes by enclosing function (the escape closure is INTRAPROCEDURAL: locals
    #      like `regs` / `workArea` / `allCidRecordWorkArea` are reused across functions, so a
    #      file-wide graph would conflate them) ----
    writes_by_fn: Dict[str, List[Tuple[List[str], SetterSite]]] = defaultdict(list)
    for chain, s in writes:
        if chain:
            writes_by_fn[s.function or ""].append((chain, s))

    # ---- single tree walk: calls (+ arg objects + enclosing fn) and TPF_regs locals (per fn) ----
    src, tree = _src_and_tree(cpp_path)
    reg_structs_by_fn: Dict[str, Set[str]] = defaultdict(set)
    calls_by_fn: Dict[str, List[Tuple[str, List[str], int]]] = defaultdict(list)
    for node in _iter(tree.root_node):
        if node.type == "declaration":
            txt = _txt(node, src)
            if txt.lstrip().startswith("TPF_regs"):
                fn = _enclosing_function(node, src) or ""
                for nm in re.findall(r"\bTPF_regs\s+([A-Za-z_]\w*)", txt):
                    reg_structs_by_fn[fn].add(nm)
        elif node.type == "call_expression":
            callee_node = node.child_by_field_name("function")
            if callee_node is None or callee_node.type != "identifier":
                continue
            callee = _txt(callee_node, src)
            arglist = node.child_by_field_name("arguments")
            if arglist is None:
                continue
            argbases = [b for a in arglist.children if a.is_named
                        for b in (_arg_base(_txt(a, src)),) if b]
            calls_by_fn[_enclosing_function(node, src) or ""].append(
                (callee, argbases, callee_node.start_point[0] + 1))

    out: Dict[str, List[SetterSite]] = {}
    cfg_funcs: Any = None
    for fn, fn_writes in writes_by_fn.items():
        fn_calls = calls_by_fn.get(fn)
        if not fn_calls:
            continue
        reg_structs = reg_structs_by_fn.get(fn, set())

        # escape graph from address assignments (assign(=) / define only; never builtins)
        alias: Dict[str, str] = {}                    # P -> base it aliases  (bare LHS:  P = &Z…)
        contain: Dict[str, Set[str]] = defaultdict(set)   # base -> address-target bases  (X.f = &Y)
        reg_field: Dict[Tuple[str, str], str] = {}    # (base, target) -> "R1"  (register-field carrier)
        writes_by_base: Dict[str, List[SetterSite]] = defaultdict(list)
        for chain, s in fn_writes:
            base = chain[0]
            writes_by_base[base].append(s)
            if (s.instruction or "") not in ("assign(=)", "define"):
                continue                              # builtins are byte copies, not pointer stores
            tgt = _addr_of_base(s.value)
            if not tgt:
                continue
            if len(chain) == 1:
                alias[base] = tgt                     # bare LHS: P aliases Z (its pointee lives in Z)
            else:
                contain[base].add(tgt)                # field store: base contains a pointer to tgt
                if base in reg_structs and _REG_FIELD.fullmatch(chain[1] or ""):
                    reg_field[(base, tgt)] = "R" + chain[1][1:]

        def storage_root(n: str, _alias=alias) -> str:
            seen: Set[str] = set()
            while n in _alias and n not in seen:
                seen.add(n)
                n = _alias[n]
            return n

        # re-key containment by storage_root so a store through an alias lands in the underlying object
        reach: Dict[str, Set[str]] = defaultdict(set)
        rfield: Dict[Tuple[str, str], str] = {}
        for base, tgts in contain.items():
            root = storage_root(base)
            for t in tgts:
                reach[root].add(t)
                if (base, t) in reg_field:
                    rfield[(root, t)] = reg_field[(base, t)]

        def reaches_from(start: str, _reach=reach) -> Set[str]:
            seen: Set[str] = set()
            stack = [start]
            while stack:
                n = stack.pop()
                for t in _reach.get(n, ()):
                    if t not in seen:
                        seen.add(t)
                        stack.append(t)
            return seen

        def carrier_to(root: str, b: str, _reach=reach, _rfield=rfield) -> Optional[str]:
            for t in _reach.get(root, ()):
                if (root, t) in _rfield and (t == b or b in reaches_from(t)):
                    return _rfield[(root, t)]
            return None

        # "prepared buffer" signal: escape-only AND explicitly zero-filled (memset(&B,0,…))
        buffer_ok: Dict[str, bool] = {}
        for base, ws in writes_by_base.items():
            escape_only = all(s.is_declaration or _is_zero_memset(s) for s in ws)
            has_zero = any(_is_zero_memset(s) for s in ws)
            buffer_ok[base] = bool(escape_only and has_zero)
        if not any(buffer_ok.values()):
            continue

        # attribute each call → bridge SetterSite(s) for the buffer it reaches via a TPF_regs.rN carrier
        for callee, argbases, line in fn_calls:
            if callee in defined_fns or callee in _BUILTIN_CALLEES:
                continue                              # C++ body in-corpus / libc builtin → never a bridge
            hit: Dict[str, str] = {}                  # buffer -> register carrier (required)
            for ab in argbases:
                root = storage_root(ab)
                for b in ({ab} | reaches_from(root)):
                    if not buffer_ok.get(b):
                        continue
                    carrier = carrier_to(root, b)
                    if carrier:                       # idiom requires the TPF_regs register pass
                        hit.setdefault(b, carrier)
            if not hit:
                continue
            asm_module = bindings.get(callee)
            if cfg_funcs is None:
                cfg_funcs = get_cfg()
            try:
                conds = collect_cpp_conditions(cpp_path, line, fn, functions=cfg_funcs)
            except Exception:
                conds = []
            for B, carrier in sorted(hit.items()):
                site = SetterSite(
                    variable=B, file_stem=stem, language="cpp", line=line,
                    instruction="asm_bridge" if asm_module else "external_source",
                    block_id=fn or "", function=fn or None,
                    value="«%s»" % (asm_module or callee),
                    setter_code_chunk="%s(…)  →  %s" % (callee, asm_module or callee),
                )
                site.preset_conditions = list(conds)
                site.bridge = {"callee": callee, "asm_module": asm_module, "reg": carrier}
                site.lhs_path = B
                out.setdefault(B, []).append(site)
    return out


# --------------------------------------------------------------------------- #
# Corpus-global C++→ASM bindings ( {callee → asm_module} + defined-function set )
# --------------------------------------------------------------------------- #
def _aggregate_bindings(blueprint_dir) -> dict:
    """Union ``symbol_aliases`` and the set of C++-defined functions across all C++/header blueprints.

    The callee's ``#pragma map`` binding lives in a header (``pipeline.hpp``) compiled into *other*
    files' blueprints, so the call site's own blueprint has none — hence the corpus-global union.
    ``symbol_aliases`` already keeps declaration-only ``#pragma map`` entries (the RC-A fix), and is
    comment-blind (``_extract_symbol_aliases`` strips ``/* */`` and ``//`` before matching)."""
    from backward_traversal.utils.blueprint_utils import load_json
    bp = Path(blueprint_dir)
    bindings: Dict[str, str] = {}
    defined: Set[str] = set()
    paths = sorted(bp.glob("*.cpp.json")) + sorted(bp.glob("*.hpp.json"))
    for p in paths:
        try:
            d = load_json(p)
        except Exception:
            continue
        for k, v in (d.get("symbol_aliases") or {}).items():
            if k and v:
                bindings.setdefault(str(k), str(v))
        nodes = (d.get("call_graph") or {}).get("nodes") or {}
        if isinstance(nodes, dict):
            for name, node in nodes.items():
                if (isinstance(node, dict) and not node.get("is_external")
                        and str(node.get("kind") or "") == "function"):
                    defined.add(str(name))
    return {"bindings": bindings, "defined_fns": sorted(defined)}


def build_and_store_cpp_asm_bindings(job_id, blueprint_dir, asm_dir) -> int:
    """Build + store the corpus-global ``cpp_asm_bindings`` blob. Returns the binding count."""
    agg = _aggregate_bindings(blueprint_dir)
    try:
        DA.write_blob(job_id, CPP_ASM_BINDINGS_ARTIFACT, DA.dumps_gz(agg))
    except Exception as exc:
        logger.debug("store cpp_asm_bindings failed: %s", exc)
    return len(agg.get("bindings") or {})


def load_cpp_asm_bindings(job_id) -> Optional[dict]:
    if not job_id:
        return None
    m = _BINDINGS_LOADED.get(job_id, 0)
    if m == 0:
        payload = DA.read_blob(job_id, CPP_ASM_BINDINGS_ARTIFACT)
        m = DA.loads_gz(payload) if payload is not None else None
        _BINDINGS_LOADED[job_id] = m
    return m or None


def _live_bindings(blueprint_dir) -> dict:
    key = str(blueprint_dir)
    agg = _LIVE_BINDINGS.get(key)
    if agg is None:
        agg = _aggregate_bindings(blueprint_dir)
        _LIVE_BINDINGS[key] = agg
    return agg


# --------------------------------------------------------------------------- #
# Per-stem build + load
# --------------------------------------------------------------------------- #
def build_and_store_cpp_indirect_writes(job_id, blueprint_dir, asm_dir) -> int:
    """Build + store per-stem bridge writers for every C++ source stem. Returns the stored-stem count.

    Built SERIALLY in the parent: the per-file escape walk is cheap (a bounded tree walk), candidates
    are rare, and guard collection reuses the **already-built** ``cfg_blobs`` via ``install_cfg_db`` —
    so ``run_cfg_extract`` is a DB hit, never a second Clang run. Must run AFTER ``cfg_blobs`` in the
    orchestrator. ``_file_writes`` parses live here (no job armed during the build), byte-identically."""
    n_bind = build_and_store_cpp_asm_bindings(job_id, blueprint_dir, asm_dir)
    agg = _aggregate_bindings(blueprint_dir)
    bindings = agg["bindings"]
    defined = set(agg["defined_fns"])
    DA.clear_blobs_prefix(job_id, CPP_INDIRECT_WRITES_ARTIFACT + ":")

    from vbt.precompute.cfg_db import install_cfg_db, clear_cfg_db
    from vbt.cpp_frontend.wrapper import run_cfg_extract
    src = Path(asm_dir)
    n = 0
    install_cfg_db(job_id)                            # serve cfg from cfg_blobs (no 2nd cfg_extract)
    try:
        for p in sorted(src.glob("*.cpp")):
            stem = _stem_of(p)
            try:
                res = compute_bridge_writers(
                    p, bindings=bindings, defined_fns=defined,
                    get_cfg=lambda _p=p: run_cfg_extract(str(_p)))
            except Exception as exc:
                logger.debug("compute_bridge_writers %s: %s", stem, exc)
                continue
            if not res:
                continue
            blob = {B: [_ss_to_row(s) for s in sites] for B, sites in res.items()}
            try:
                if DA.write_blob(job_id, f"{CPP_INDIRECT_WRITES_ARTIFACT}:{stem}", DA.dumps_gz(blob)):
                    n += 1
            except Exception as exc:
                logger.debug("store cpp_indirect_writes:%s failed: %s", stem, exc)
    finally:
        clear_cfg_db()
    logger.debug("cpp_indirect_writes: %d bindings, %d stems with bridge writers", n_bind, n)
    return n


def load_cpp_indirect_writes(job_id, stem: str) -> Optional[Dict[str, List[SetterSite]]]:
    """Precomputed ``{buffer_root: [SetterSite]}`` for ``stem`` (preset_conditions + bridge rebuilt), or None."""
    if not job_id:
        return None
    key = (job_id, stem)
    m = _LOADED.get(key, 0)
    if m == 0:
        payload = DA.read_blob(job_id, f"{CPP_INDIRECT_WRITES_ARTIFACT}:{stem}")
        m = DA.loads_gz(payload) if payload is not None else None
        if len(_LOADED) >= _LOADED_MAX:
            _LOADED.pop(next(iter(_LOADED)))
        _LOADED[key] = m
    if not m:
        return None
    return {B: [_row_to_ss(d) for d in rows] for B, rows in m.items()}


# --------------------------------------------------------------------------- #
# Trace-time entry: DB-served in load-only, computed live in file mode
# --------------------------------------------------------------------------- #
def load_bridge_writers(job_id, stem: str, base: str, *, asm_dir, blueprint_dir) -> List[SetterSite]:
    """Bridge setters of buffer ``base`` declared in ``stem`` (a local cannot escape its TU ⇒ scoped).

    Load-only (job set): a DB lookup; a MISS is fail-closed (skip + warn, never a live parse). File mode
    (no job / not load-only): compute live + cache (the engine already reads source freely in file mode)."""
    from vbt.precompute import db_artifacts as _DA
    if job_id and _DA.is_load_only():
        m = load_cpp_indirect_writes(job_id, stem)
        if m is None:
            return []                                 # no blob for this stem ⇒ feature off here (no live read)
        return list(m.get(base, []))
    # FILE mode — compute live (cached per (asm_dir, blueprint_dir, stem)).
    key = (str(asm_dir), str(blueprint_dir), stem)
    res = _LIVE_WRITERS.get(key)
    if res is None:
        p = Path(asm_dir) / f"{stem}.cpp"
        if not p.exists():
            _LIVE_WRITERS[key] = {}
            return []
        from vbt.cpp_frontend.wrapper import run_cfg_extract
        agg = _live_bindings(blueprint_dir)
        try:
            res = compute_bridge_writers(
                p, bindings=agg["bindings"], defined_fns=set(agg["defined_fns"]),
                get_cfg=lambda: run_cfg_extract(str(p)))
        except Exception:
            res = {}
        if len(_LIVE_WRITERS) >= _LOADED_MAX:
            _LIVE_WRITERS.pop(next(iter(_LIVE_WRITERS)))
        _LIVE_WRITERS[key] = res
    return list(res.get(base, []))


def clear_caches() -> None:
    """Drop in-process caches (per-trace hygiene; mirrors the other *_db modules)."""
    _LOADED.clear()
    _BINDINGS_LOADED.clear()
    _LIVE_BINDINGS.clear()
    _LIVE_WRITERS.clear()
