"""Precompute the per-file C++ writes (`cpp_setters._file_writes` output) so a load-only trace LOADS
them instead of re-running the tree-sitter parse + node walk per file.

`_file_writes` is the variable-agnostic "all writes in this file" scan that drives the path-family search
(`find_cpp_writes_under_path` → `_writes_prefix_index`, used by dep-var descendant search + param-binding).
In a cold trace it tree-sitter-parses each touched .cpp once (~2s locally; scales with the corpus — a 22k
killer). The output is a pure function of the file, so it is precomputed once and the trace loads it.

Byte-identical by construction: the stored `[(lhs_chain, SetterSite)]` is exactly what `_file_writes`
produces, in the SAME source order (so `_writes_prefix_index`'s per-prefix lists — and thus
`find_cpp_writes_under_path`'s output — are identical). A stem absent from the DB → live parse fallback
(so an incomplete precompute can only forgo the speedup, never change output). Lookups are armed only when
a job id is set; the precompute build itself parses live (`is_load_only()` is False during the build).
Mirrors `cpp_setter_map_db` (same SetterSite round-trip via `_SS_FIELDS` + the dynamic `lhs_path`).
"""
from __future__ import annotations

import logging
from dataclasses import asdict as _asdict, fields as _dc_fields
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from vbt.precompute import db_artifacts as DA
from vbt.setters.cpp_setters import SetterSite

logger = logging.getLogger(__name__)

CPP_FILE_WRITES_ARTIFACT = "cpp_file_writes"        # per-stem blob: f"{ARTIFACT}:{stem}"
_SS_FIELDS = [f.name for f in _dc_fields(SetterSite)]

_LOADED: Dict[tuple, object] = {}                   # (job, stem) -> rows | None | sentinel 0
_LOADED_MAX = 4096


def _build_one_cpp_file_writes(cpp_path_str: str):
    """ProcessPool worker: build the per-stem `_file_writes` output blob.

    Returns (stem, payload_or_None). Pickle-safe."""
    try:
        from pathlib import Path as _Path
        from dataclasses import asdict as _asdict
        from vbt.setters.cpp_setters import _file_writes
        from vbt.precompute import db_artifacts as _DA
        p = _Path(cpp_path_str)
        stem = p.name
        for suf in (".cpp", ".hpp", ".cc", ".cxx", ".c", ".h"):
            if stem.lower().endswith(suf):
                stem = stem[: -len(suf)]
                break
        try:
            writes = _file_writes(p)
        except Exception:
            return (stem, None)
        rows: List[list] = []
        for lhs_chain, site in writes:
            d = _asdict(site)
            d["lhs_path"] = getattr(site, "lhs_path", "")
            rows.append([lhs_chain, d])
        if not rows:
            return (stem, None)
        return (stem, _DA.dumps_gz(rows))
    except Exception:
        try:
            import os
            return (os.path.basename(cpp_path_str), None)
        except Exception:
            return ("", None)


def build_and_store_cpp_file_writes(job_id, blueprint_dir, asm_dir) -> int:
    """Build + store the per-stem `_file_writes` output for every C++ source stem. Returns the count.

    Parallelized via ProcessPool: each worker parses one .cpp via tree-sitter; the parent writes
    blobs serially (sqlite single-writer). Byte-identical because writes preserve source order
    and parallel_map returns INPUT-ORDERED results."""
    src = Path(asm_dir)
    DA.clear_blobs_prefix(job_id, CPP_FILE_WRITES_ARTIFACT + ":")
    paths = [str(p) for p in sorted(src.glob("*.cpp"))]
    try:
        from vbt.precompute.parallel import parallel_map
        results = parallel_map(_build_one_cpp_file_writes, paths)
    except Exception as exc:
        logger.debug("parallel cpp_file_writes fallback: %s", exc)
        results = [_build_one_cpp_file_writes(p) for p in paths]
    n = 0
    for stem, payload in results:
        if payload is None:
            continue
        try:
            if DA.write_blob(job_id, f"{CPP_FILE_WRITES_ARTIFACT}:{stem}", payload):
                n += 1
        except Exception as exc:
            logger.debug("store cpp_file_writes:%s failed: %s", stem, exc)
    return n


def load_cpp_file_writes(job_id, stem: str) -> "Optional[List[Tuple[List[str], SetterSite]]]":
    """Precomputed `_file_writes` output for ``stem`` (byte-identical to a live parse), or None.

    Reconstructs ``[(lhs_chain, SetterSite)]`` in the stored (source) order; `SetterSite.lhs_path` is
    re-attached exactly as `_file_writes` set it. Same round-trip as `cpp_setter_map_db.load_cpp_setters`."""
    if not job_id:
        return None
    key = (job_id, stem)
    m = _LOADED.get(key, 0)
    if m == 0:
        payload = DA.read_blob(job_id, f"{CPP_FILE_WRITES_ARTIFACT}:{stem}")
        m = DA.loads_gz(payload) if payload is not None else None
        if len(_LOADED) >= _LOADED_MAX:
            _LOADED.pop(next(iter(_LOADED)))
        _LOADED[key] = m
    if not m:
        return None
    out: List[Tuple[List[str], SetterSite]] = []
    for lhs_chain, d in m:
        s = SetterSite(**{k: d[k] for k in _SS_FIELDS})
        s.lhs_path = d.get("lhs_path", "")
        out.append((lhs_chain, s))
    return out
