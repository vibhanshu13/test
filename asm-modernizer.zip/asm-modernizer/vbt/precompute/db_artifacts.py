"""DB-backed precompute artifact plumbing — the foundation every later step rides
(DB_PRECOMPUTE_PLAN.md T1).

Provides three things and nothing else (no artifact is moved in T1):

  * ``source_manifest_hash`` — a deterministic fingerprint of a source set, mirroring the
    per-file ``(path, size, mtime)`` hash that ``modifier_index``/``const_resolver`` already
    use, so a loader can detect staleness exactly and never serve a stale precompute.

  * ``read_manifest`` / ``write_manifest`` — best-effort persistence of a
    ``(job_id, artifact) -> {version, source_hash, built_at}`` row in
    ``vbt_precompute_manifest``.  Best-effort: any DB failure logs at debug and returns
    ``None``/``False`` (the caller then recomputes — the DB is never load-bearing for
    correctness).

  * ``resolve_artifact(db_load, disk_load, compute)`` — the 3-tier resolution contract
    (DB → disk → compute).  ``compute`` is the unchanged runtime path and is always correct,
    so behavior is preserved whenever the DB/disk tiers are absent, stale, or error.

T2+ supply the per-artifact ``db_load``/``disk_load``/``compute`` closures; T1 only
establishes the contract and the manifest table.
"""
from __future__ import annotations

import hashlib
import logging
import os
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Optional, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")

# T12 — trace-time scaling. When ON, the loaders TRUST the DB (load a blob/manifest by presence,
# O(1)) and do NOT re-hash the source set (which is O(files) — a 22k bottleneck). Freshness is
# then the precompute's responsibility (it overwrites blobs when sources change; cfg stays
# self-validating via its content-hash key). The engine turns this ON for a trace (job_id set)
# and OFF otherwise; precompute forces it OFF so it always verifies + (re)builds.
_LOAD_ONLY = False


def set_load_only(value: bool) -> None:
    global _LOAD_ONLY
    _LOAD_ONLY = bool(value)
    # A load-only trace trusts the precomputed DB and never reads the parser's gvl_edges columns,
    # so tell the engine to skip those O(DB-size) backfill COUNT scans on open (the 18GB cold-start
    # killer). Best-effort; the engine flag defaults OFF so non-VBT consumers are unaffected.
    try:
        from api.index_db.engine import set_skip_gvl_backfill
        set_skip_gvl_backfill(bool(value))
    except Exception:
        pass


def is_load_only() -> bool:
    return _LOAD_ONLY


def manifest_present(job_id: Optional[str], artifact: str) -> bool:
    """O(1): does a manifest row exist for (job_id, artifact)? — the trace-time freshness check
    (trust precompute), with NO source-file scan."""
    return read_manifest(job_id, artifact) is not None


# --------------------------------------------------------------------------- #
# Source fingerprint
# --------------------------------------------------------------------------- #
def source_manifest_hash(files: Iterable[os.PathLike | str], *, version: int = 1,
                         extra: str = "") -> str:
    """SHA-256 over (artifact version, optional extra salt, then each file's
    ``path\\0size\\0int(mtime)``) with files visited in sorted path order — so the hash is
    stable across runs and changes iff a tracked file is added/removed/edited.  A missing
    file hashes as ``MISSING`` (so its later appearance also flips the hash)."""
    h = hashlib.sha256()
    h.update(f"v{version}\x00{extra}\x00".encode("utf-8"))
    for p in sorted(str(f) for f in files):
        try:
            st = os.stat(p)
            h.update(f"{p}\x00{st.st_size}\x00{int(st.st_mtime)}\x00".encode("utf-8"))
        except OSError:
            h.update(f"{p}\x00MISSING\x00".encode("utf-8"))
    return h.hexdigest()


# --------------------------------------------------------------------------- #
# 3-tier resolution contract
# --------------------------------------------------------------------------- #
def resolve_artifact(
    *,
    db_load: Callable[[], Optional[T]],
    compute: Callable[[], T],
    disk_load: Optional[Callable[[], Optional[T]]] = None,
) -> T:
    """Return the first non-``None`` of DB → disk → compute.

    ``db_load`` and ``disk_load`` return the value or ``None`` (a miss OR a stale entry they
    declined to serve).  Any exception in a loader is swallowed (logged at debug) and treated
    as a miss.  ``compute`` is the authoritative fallback (the unchanged runtime path) and is
    only called when both upper tiers miss — guaranteeing behavior preservation.
    """
    try:
        v = db_load()
        if v is not None:
            return v
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("db_load miss (falling through): %s", exc)

    if disk_load is not None:
        try:
            v = disk_load()
            if v is not None:
                return v
        except Exception as exc:  # pragma: no cover - defensive
            logger.debug("disk_load miss (falling through): %s", exc)

    return compute()


# --------------------------------------------------------------------------- #
# Manifest persistence (engine-level helpers + job-level wrappers)
# --------------------------------------------------------------------------- #
def _manifest_table():
    from api.index_db.schema import vbt_precompute_manifest
    return vbt_precompute_manifest


def read_manifest_with_engine(engine, job_id: str, artifact: str) -> Optional[Dict[str, Any]]:
    """Low-level read against an explicit engine (used by tests and the wrappers)."""
    from sqlalchemy import select
    t = _manifest_table()
    with engine.connect() as conn:
        row = conn.execute(
            select(t.c.version, t.c.source_hash, t.c.built_at).where(
                (t.c.job_id == job_id) & (t.c.artifact == artifact)
            )
        ).first()
    if row is None:
        return None
    return {"version": int(row[0]), "source_hash": row[1], "built_at": row[2]}


def write_manifest_with_engine(engine, job_id: str, artifact: str, version: int,
                               source_hash: str, built_at: str = "") -> None:
    """Low-level upsert against an explicit engine (delete-then-insert; one row per pair)."""
    from sqlalchemy import delete, insert
    t = _manifest_table()
    with engine.begin() as conn:
        conn.execute(delete(t).where((t.c.job_id == job_id) & (t.c.artifact == artifact)))
        conn.execute(insert(t).values(
            job_id=job_id, artifact=artifact, version=int(version),
            source_hash=source_hash, built_at=built_at,
        ))


def read_manifest(job_id: Optional[str], artifact: str) -> Optional[Dict[str, Any]]:
    """Manifest row for (job_id, artifact), or ``None`` if absent / job_id unset / DB error."""
    if not job_id:
        return None
    try:
        from api.index_db.engine import get_engine
        return read_manifest_with_engine(get_engine(job_id), job_id, artifact)
    except Exception as exc:
        logger.debug("read_manifest(%s, %s) failed: %s", job_id, artifact, exc)
        return None


def write_manifest(job_id: Optional[str], artifact: str, version: int, source_hash: str,
                   *, built_at: str = "") -> bool:
    """Persist the manifest row; returns ``True`` on success, ``False`` (best-effort) otherwise."""
    if not job_id:
        return False
    try:
        from api.index_db.engine import get_engine
        write_manifest_with_engine(get_engine(job_id), job_id, artifact, version,
                                   source_hash, built_at)
        return True
    except Exception as exc:
        logger.debug("write_manifest(%s, %s) failed: %s", job_id, artifact, exc)
        return False


def manifest_fresh(job_id: Optional[str], artifact: str, *, version: int,
                   source_hash: str) -> bool:
    """True iff a stored manifest matches the given version AND source hash — the staleness
    gate a ``db_load`` calls before trusting precomputed rows."""
    row = read_manifest(job_id, artifact)
    return bool(row and row["version"] == version and row["source_hash"] == source_hash)


# --------------------------------------------------------------------------- #
# Artifact blobs (gzipped JSON) — for "load the whole thing once" structures
# --------------------------------------------------------------------------- #
def dumps_gz(obj: Any) -> bytes:
    """Serialize ``obj`` to gzipped UTF-8 JSON.  ``sort_keys=False`` so caller-controlled
    insertion order (which can be load-bearing, e.g. alias-map entry lists) is preserved
    exactly across the round-trip."""
    import gzip
    import json
    raw = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return gzip.compress(raw, compresslevel=6, mtime=0)   # mtime=0 -> deterministic bytes


def loads_gz(payload: bytes) -> Any:
    import gzip
    import json
    return json.loads(gzip.decompress(payload).decode("utf-8"))


def _blob_table():
    from api.index_db.schema import vbt_artifact_blob
    return vbt_artifact_blob


def read_blob_with_engine(engine, job_id: str, artifact: str) -> Optional[bytes]:
    from sqlalchemy import select
    t = _blob_table()
    with engine.connect() as conn:
        row = conn.execute(
            select(t.c.payload).where((t.c.job_id == job_id) & (t.c.artifact == artifact))
        ).first()
    return bytes(row[0]) if row is not None and row[0] is not None else None


def write_blob_with_engine(engine, job_id: str, artifact: str, payload: bytes) -> None:
    from sqlalchemy import delete, insert
    t = _blob_table()
    with engine.begin() as conn:
        conn.execute(delete(t).where((t.c.job_id == job_id) & (t.c.artifact == artifact)))
        conn.execute(insert(t).values(job_id=job_id, artifact=artifact, payload=payload))


def read_blob(job_id: Optional[str], artifact: str) -> Optional[bytes]:
    if not job_id:
        return None
    try:
        from api.index_db.engine import get_engine
        return read_blob_with_engine(get_engine(job_id), job_id, artifact)
    except Exception as exc:
        logger.debug("read_blob(%s, %s) failed: %s", job_id, artifact, exc)
        return None


def write_blob(job_id: Optional[str], artifact: str, payload: bytes) -> bool:
    if not job_id:
        return False
    try:
        from api.index_db.engine import get_engine
        write_blob_with_engine(get_engine(job_id), job_id, artifact, payload)
        return True
    except Exception as exc:
        logger.debug("write_blob(%s, %s) failed: %s", job_id, artifact, exc)
        return False


def clear_blobs_prefix(job_id: Optional[str], prefix: str) -> int:
    """Delete all blobs whose artifact name starts with ``prefix`` for ``job_id``.
    Returns the row count deleted (best-effort; 0 on failure / no job_id)."""
    if not job_id:
        return 0
    try:
        from sqlalchemy import delete
        from api.index_db.engine import get_engine
        t = _blob_table()
        with get_engine(job_id).begin() as conn:
            res = conn.execute(delete(t).where(
                (t.c.job_id == job_id) & (t.c.artifact.like(prefix + "%"))))
        return int(res.rowcount or 0)
    except Exception as exc:
        logger.debug("clear_blobs_prefix(%s, %s) failed: %s", job_id, prefix, exc)
        return 0


# --------------------------------------------------------------------------- #
# cfg blobs (content-hash keyed; self-validating — no manifest) — T8
# --------------------------------------------------------------------------- #
def _cfg_table():
    from api.index_db.schema import vbt_cfg_blob
    return vbt_cfg_blob


def read_cfg_blob(job_id: Optional[str], cfg_key: str) -> Optional[bytes]:
    if not job_id:
        return None
    try:
        from sqlalchemy import select
        from api.index_db.engine import get_engine
        t = _cfg_table()
        with get_engine(job_id).connect() as conn:
            row = conn.execute(
                select(t.c.payload).where((t.c.job_id == job_id) & (t.c.cfg_key == cfg_key))
            ).first()
        return bytes(row[0]) if row is not None and row[0] is not None else None
    except Exception as exc:
        logger.debug("read_cfg_blob(%s, %s) failed: %s", job_id, cfg_key, exc)
        return None


def write_cfg_blob(job_id: Optional[str], cfg_key: str, payload: bytes) -> bool:
    if not job_id:
        return False
    try:
        from sqlalchemy import insert
        from api.index_db.engine import get_engine
        t = _cfg_table()
        with get_engine(job_id).begin() as conn:
            conn.execute(insert(t).values(job_id=job_id, cfg_key=cfg_key, payload=payload))
        return True
    except Exception as exc:
        # Likely a unique-constraint race (another worker stored it) — benign.
        logger.debug("write_cfg_blob(%s, %s) failed: %s", job_id, cfg_key, exc)
        return False
