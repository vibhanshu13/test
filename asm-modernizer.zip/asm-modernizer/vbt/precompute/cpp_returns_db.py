"""Precompute the per-file C++ `return` statements (`cpp_setters._file_returns` output) so a
load-only trace LOADS them instead of re-running the tree-sitter parse + node walk per file.

`_file_returns` is the variable-agnostic "every return in this file" scan that drives
function-output resolution (`find_cpp_returns_in_function`, used when a dep var is a function's
return value). In a cold/DB trace it tree-sitter-parses each touched .cpp live — the LAST C++
operation in the trace hot path that was NOT served from the DB (setters, writes, source, and
cfg already are). The output is a pure function of the file, so it is precomputed once and the
trace loads it.

Byte-identical by construction: the stored `[fn, line, expr]` rows are exactly what `_file_returns`
produces, in the SAME source order, re-hydrated to `(fn, line, expr)` tuples on load. A stem absent
from the DB → live parse fallback (so an incomplete precompute can only forgo the speedup, never
change output). Lookups are armed only when a job id is set; the precompute build itself parses live
(`is_load_only()` is False during the build). Mirrors `cpp_file_writes_db`.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from vbt.precompute import db_artifacts as DA

logger = logging.getLogger(__name__)

CPP_RETURNS_ARTIFACT = "cpp_returns"                # per-stem blob: f"{ARTIFACT}:{stem}"

_LOADED: Dict[tuple, object] = {}                   # (job, stem) -> rows | None | sentinel 0
_LOADED_MAX = 4096


def _build_one_cpp_returns(cpp_path_str: str):
    """ProcessPool worker: build the per-stem `_file_returns` output blob.

    Returns (stem, payload_or_None). Pickle-safe."""
    try:
        from pathlib import Path as _Path
        from vbt.setters.cpp_setters import _file_returns
        from vbt.precompute import db_artifacts as _DA
        p = _Path(cpp_path_str)
        stem = p.name
        for suf in (".cpp", ".hpp", ".cc", ".cxx", ".c", ".h"):
            if stem.lower().endswith(suf):
                stem = stem[: -len(suf)]
                break
        try:
            returns = _file_returns(p)
        except Exception:
            return (stem, None)
        # Store JSON-friendly [fn, line, expr] rows in source order.
        rows: List[list] = [[fn, ln, expr] for (fn, ln, expr) in returns]
        if not rows:
            return (stem, None)
        return (stem, _DA.dumps_gz(rows))
    except Exception:
        try:
            import os
            return (os.path.basename(cpp_path_str), None)
        except Exception:
            return ("", None)


def build_and_store_cpp_returns(job_id, blueprint_dir, asm_dir) -> int:
    """Build + store the per-stem `_file_returns` output for every C++ source stem. Returns the count.

    Parallelized via ProcessPool: each worker parses one .cpp via tree-sitter; the parent writes
    blobs serially (sqlite single-writer). Byte-identical because returns preserve source order
    and parallel_map returns INPUT-ORDERED results."""
    src = Path(asm_dir)
    DA.clear_blobs_prefix(job_id, CPP_RETURNS_ARTIFACT + ":")
    paths = [str(p) for p in sorted(src.glob("*.cpp"))]
    try:
        from vbt.precompute.parallel import parallel_map
        results = parallel_map(_build_one_cpp_returns, paths)
    except Exception as exc:
        logger.debug("parallel cpp_returns fallback: %s", exc)
        results = [_build_one_cpp_returns(p) for p in paths]
    n = 0
    for stem, payload in results:
        if payload is None:
            continue
        try:
            if DA.write_blob(job_id, f"{CPP_RETURNS_ARTIFACT}:{stem}", payload):
                n += 1
        except Exception as exc:
            logger.debug("store cpp_returns:%s failed: %s", stem, exc)
    return n


def load_cpp_returns(job_id, stem: str) -> "Optional[List[Tuple[str, int, str]]]":
    """Precomputed `_file_returns` output for ``stem`` (byte-identical to a live parse), or None.

    Re-hydrates the stored `[fn, line, expr]` rows to `(fn, line, expr)` tuples in source order —
    exactly what `_file_returns` returns. A stem with no blob → None → caller parses live."""
    if not job_id:
        return None
    key = (job_id, stem)
    m = _LOADED.get(key, 0)
    if m == 0:
        payload = DA.read_blob(job_id, f"{CPP_RETURNS_ARTIFACT}:{stem}")
        m = DA.loads_gz(payload) if payload is not None else None
        if len(_LOADED) >= _LOADED_MAX:
            _LOADED.pop(next(iter(_LOADED)))
        _LOADED[key] = m
    if m is None:
        return None
    return [(fn, ln, expr) for (fn, ln, expr) in m]
