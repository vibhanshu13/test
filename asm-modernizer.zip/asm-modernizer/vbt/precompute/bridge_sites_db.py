"""Bridge-verified call-site map per callee (the uncached caller-forest fix).

``find_routes``' caller-forest build (``walk_callers_bfs``) and the dep-var
``is_reachable_bounded`` walk both verify every reverse-adjacency edge with a
cross-file bridge (``find_asm_callers`` & co).  Each bridge call loads the CALLER's
full blueprint JSON from disk and scans it — and a hub callee's transitive cone at
22k scale holds thousands of callers, far beyond the blueprint LRU, so an uncached
forest build is minutes of repeated multi-MB ``json.loads``.  That was the
"find_routes: building caller forest for <stem> (uncached, BFS)" stall.

The bridge output is a pure function of the corpus — ``(source_stem, callee_stem,
types, blueprints, sources)`` — independent of the traced variable, the chain, and
the route parent.  So we precompute it ONCE per KB: for every candidate edge the
walkers could ever verify (the same ``{stem} ∪ entry_names`` key expansion over the
same ``reverse_adj``), run the same bridge, and store the sites per CALLEE as one
``bridge_sites:<callee_stem>`` gzip blob = ``{source_stem: [site, ...]}``.

At trace time the walkers consult a loader hook (``_pfl_cache["_bridge_sites_loader"]``,
installed by ``RouteEngine`` in load-only mode): one small blob read per expanded
callee replaces N caller-blueprint loads.  Byte-identical by construction — the
stored VALUE is the live bridge's output (deterministic, JSON-pure: routine/line/
instruction/call_type/raw_line/indirection), and any miss (blob absent, source not
in the map, load-only off) falls back to the live bridge unchanged.

Freshness: rebuilt by ``vbt.precompute_db`` (which clears the prefix first), same
lifecycle as ``reverse_adj``/``forward_file_adj``.  Sites are stored WITHOUT
condition attachment (``attach_conditions=False`` — the only mode the VBT walkers
use; guard reconstruction stays deferred to emitted hops).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

from vbt.precompute import db_artifacts as DA

logger = logging.getLogger(__name__)

ARTIFACT_PREFIX = "bridge_sites:"
MANIFEST_KEY = "bridge_sites"
BRIDGE_SITES_VERSION = 1


def _blob_key(callee_stem: str) -> str:
    # Case-normalized: walk callee stems come from Endpoint.norm() (case-preserving)
    # while build stems come from graph node ids — lower() makes them collide.
    return ARTIFACT_PREFIX + str(callee_stem).strip().lower()


def build_and_store_bridge_sites(job_id: str, blueprint_dir, asm_dir, route) -> int:
    """Bridge-verify every candidate caller edge and persist per-callee site maps.

    ``route`` is a build-mode RouteEngine (load_only OFF); its graph gives the SAME
    ``reverse_adj``/``node_type`` the walkers reach over.  Candidate enumeration
    replicates the walkers exactly: callee keys = ``{stem.upper()} ∪ _entry_names``,
    sources = the union of ``reverse_adj`` hits; per pair the bridge for
    ``(source_type, callee_type)`` runs verbatim.  Pairs are computed grouped by
    SOURCE stem so each caller blueprint is parsed once (LRU-local), not once per
    callee.  Returns the number of callee blobs written.
    """
    from backward_traversal.runner.chainless_caller_walker import (
        _bridge_for, _entry_names, _guess_type,
    )

    blueprint_dir = Path(blueprint_dir)
    asm_dir = Path(asm_dir) if asm_dir else None
    route._ensure_graph()
    reverse_adj: Dict[str, List] = route._reverse_adj or {}
    node_type: Dict[str, str] = route._node_type or {}

    # Callee universe: every graph node PLUS every reverse-adjacency source (the walk
    # enqueues sources as next callees, typed via node_type-or-guess, same as here).
    callees: Dict[str, str] = {}
    for stem, ftype in node_type.items():
        callees[stem] = ftype
    for pairs in reverse_adj.values():
        for src, _instr in pairs:
            if src not in callees:
                callees[src] = node_type.get(src) or _guess_type(src, blueprint_dir)

    # Candidate sources per callee via the walkers' exact key expansion.
    sources_by_callee: Dict[str, Set[str]] = {}
    for cs, ct in callees.items():
        keys = {cs.upper()} | _entry_names(cs, ct, blueprint_dir)
        srcs: Set[str] = set()
        for k in keys:
            for src, _instr in reverse_adj.get(k, []):
                srcs.add(src)
        if srcs:
            sources_by_callee[cs] = srcs

    # Verify grouped by source stem — each caller blueprint hot in the LRU while all
    # of its outgoing pairs are bridged.
    all_pairs = sorted((src, cs) for cs, srcs in sources_by_callee.items() for src in srcs)
    sites_by_callee: Dict[str, Dict[str, List[Dict[str, Any]]]] = {
        cs: {} for cs in sources_by_callee
    }
    for src, cs in all_pairs:
        ct = callees[cs]
        st = node_type.get(src) or _guess_type(src, blueprint_dir)
        bridge = _bridge_for(st, ct)
        if bridge is None:
            continue  # walker skips this pair too — no entry needed
        try:
            sites = bridge(src, cs, blueprint_dir, asm_dir) or []
        except Exception as exc:
            logger.debug("bridge %s->%s failed for %s: %s", st, ct, src, exc)
            sites = []
        # Empty lists ARE stored: the walker emits an unverified-indirection node for
        # a bridged-but-siteless pair, so "verified empty" must be a cache HIT.
        sites_by_callee[cs][src] = sites

    DA.clear_blobs_prefix(job_id, ARTIFACT_PREFIX)
    n = 0
    for cs, m in sites_by_callee.items():
        if DA.write_blob(job_id, _blob_key(cs), DA.dumps_gz(m)):
            n += 1
    try:
        shash = DA.source_manifest_hash(sorted(blueprint_dir.glob("*.json")),
                                        version=BRIDGE_SITES_VERSION)
        DA.write_manifest(job_id, MANIFEST_KEY, BRIDGE_SITES_VERSION, shash)
    except Exception as exc:
        logger.debug("bridge_sites manifest write failed (non-fatal): %s", exc)
    return n


def make_bridge_sites_loader(job_id: Optional[str]) -> Optional[Callable]:
    """Loader hook for ``_pfl_cache["_bridge_sites_loader"]``.

    ``loader(callee_stem, callee_type) -> {source_stem: sites} | None`` — one blob
    read per callee, memoized (FIFO-bounded; an evicted callee is just re-read).
    Serves only in load-only mode so build/verify traces keep scanning live.
    """
    if not job_id:
        return None
    _MISS = object()
    memo: Dict[str, Any] = {}

    def load(callee_stem: str, callee_type: str):
        if not DA.is_load_only():
            return None
        key = str(callee_stem).strip().lower()
        hit = memo.get(key, _MISS)
        if hit is not _MISS:
            return hit
        data = None
        try:
            payload = DA.read_blob(job_id, ARTIFACT_PREFIX + key)
            if payload is not None:
                data = DA.loads_gz(payload)
        except Exception as exc:
            logger.debug("bridge_sites load failed for %s (live fallback): %s",
                         callee_stem, exc)
            data = None
        if len(memo) >= 4096:
            memo.pop(next(iter(memo)))
        memo[key] = data
        return data

    return load
