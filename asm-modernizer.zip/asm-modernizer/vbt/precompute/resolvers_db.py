"""DB-backed name-alias + membership resolvers (DB_PRECOMPUTE_PLAN.md T2).

These two resolvers are pure functions of the SOURCE set and today are rebuilt cold on every
worker process (no persistence at all).  This module persists their BUILT state to ``index.db``
once and pre-fills the in-process caches at trace start, so ``resolve_aliases`` /
``get_membership_resolver`` become pure cache hits — no globbing/parsing of cc/gen/mac/headers
during a trace.

Behavior preservation (the load-bearing point): we persist the *intermediate built state*
(the per-unit alias maps; the membership indexes), NOT per-query answers.  The query logic
(``name_resolver.resolve``, ``MembershipResolver.resolve``) is left completely untouched and
runs over the identical structures, so output is byte-identical.  When ``job_id`` is ``None``
(CLI / parity harness) this module is a no-op and the resolvers build from source exactly as
before.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from vbt.precompute import db_artifacts as DA
from vbt.precompute import modifier_index as _mi
from vbt.resolve import const_resolver as _cr
from vbt.resolve import membership as _mb
from vbt.resolve import name_resolver as _nr

logger = logging.getLogger(__name__)

NAME_ALIAS_ARTIFACT = "name_alias"
MEMBERSHIP_ARTIFACT = "membership"
CONST_ARTIFACT = "const"
# VBT's OWN modifier index — stored as a vbt_* blob, NEVER the legacy `variable_modifiers`
# table (a DIFFERENT producer: C++ from GVL edges, no MVC/register-indirect). Reusing that
# table would change outputs; this artifact persists exactly what vbt/precompute computes.
MODIFIER_ARTIFACT = "modifier_index"
# Bump when the serialized SHAPE or the builders' SEMANTICS change (forces a rebuild).
RESOLVERS_VERSION = 1


def _resolver_source_files(src_dir: Path) -> List[Path]:
    """Source files both resolvers derive from: app/gen headers, plain headers (include
    targets), and macros.  Superset of what ``name_resolver``/``membership`` read."""
    files: List[Path] = []
    for pat in ("*.hpp", "*.h", "*.mac"):
        files.extend(src_dir.glob(pat))
    return files


def _source_hash(src_dir: Path) -> str:
    return DA.source_manifest_hash(_resolver_source_files(src_dir), version=RESOLVERS_VERSION)


# --------------------------------------------------------------------------- #
# name-alias artifact (the per-unit alias maps + their ordered unit list)
# --------------------------------------------------------------------------- #
def _build_name_alias_artifact(src_dir: Path) -> Dict[str, Any]:
    """Build (filling the name_resolver caches) and return the serializable artifact.
    Units are kept in ``_units`` order; each map is the exact ``build_alias_map`` dict so
    ``resolve``'s ordered iteration + dedup reproduce identically."""
    _nr.clear_cache()
    units = _nr._units(src_dir)
    if not units and any(src_dir.glob("cc*.hpp")):
        # Stale-cache guard: a populated name_resolver cache can yield 0 units even though cc*.hpp
        # units exist, producing an EMPTY name-alias artifact that silently reverts every cold trace
        # to a full-corpus glob+parse (minutes at 22k — the #1 cold-run cliff). Clear + rebuild so the
        # artifact is non-empty. Byte-identical: a correct build already discovers the same units.
        logger.warning("_build_name_alias_artifact: 0 units despite cc*.hpp files in %s "
                       "— retrying after cache clear", src_dir)
        _nr.clear_cache()
        units = _nr._units(src_dir)
    maps = [_nr._alias_map(u) for u in units]
    return {
        "units": [
            {"mac": u.mac.name,
             "gen": (u.gen.name if u.gen is not None else None),
             "cc": u.cc.name,
             "stem": u.stem}
            for u in units
        ],
        "maps": maps,                       # parallel to units; entries may be null
    }


def _load_name_alias_artifact(src_dir: Path, artifact: Dict[str, Any]) -> None:
    """Reconstruct the EXACT name_resolver cache state (``_UNIT_CACHE`` + ``_MAP_CACHE``)
    from the artifact so ``resolve`` runs without touching source."""
    units = []
    for u in artifact["units"]:
        mac = src_dir / u["mac"]
        gen = (src_dir / u["gen"]) if u["gen"] else None
        cc = src_dir / u["cc"]
        units.append(_nr._Unit(mac, gen, cc, u["stem"]))
    _nr._UNIT_CACHE[str(src_dir.resolve())] = units
    for unit, amap in zip(units, artifact["maps"]):
        _nr._MAP_CACHE[unit._key] = amap


# --------------------------------------------------------------------------- #
# membership artifact (the four built indexes)
# --------------------------------------------------------------------------- #
def _build_membership_artifact(blueprint_dir: Path, src_dir: Path) -> Dict[str, Any]:
    r = _mb.get_membership_resolver(blueprint_dir, src_dir)
    r._build()
    return {
        "cpp": r._cpp,
        "asm": r._asm,
        "tail_structs": {k: sorted(v) for k, v in r._tail_structs.items()},   # sets -> lists
        "sym_dsect": r._sym_dsect,
    }


def _load_membership_artifact(blueprint_dir: Path, src_dir: Path, artifact: Dict[str, Any]) -> None:
    r = _mb.MembershipResolver(blueprint_dir, src_dir)
    r._cpp = dict(artifact["cpp"])
    r._asm = dict(artifact["asm"])
    r._tail_structs = {k: set(v) for k, v in artifact["tail_structs"].items()}
    r._sym_dsect = dict(artifact["sym_dsect"])
    r._built = True
    _mb._CACHE[(str(Path(blueprint_dir)), str(Path(src_dir)))] = r


# --------------------------------------------------------------------------- #
# const artifact (enum / EQU-DC value resolver — already disk-cached; this adds the DB tier)
# --------------------------------------------------------------------------- #
def _build_const_artifact(blueprint_dir: Path, src_dir: Path) -> Dict[str, Any]:
    cr = _cr.get_const_resolver(blueprint_dir, src_dir)     # existing disk/build fast path
    return {"cpp_enum": cr.cpp_enum, "asm_const": cr.asm_const}


def _load_const_artifact(blueprint_dir: Path, src_dir: Path, artifact: Dict[str, Any]) -> None:
    cr = _cr.ConstResolver()
    cr.cpp_enum = dict(artifact["cpp_enum"])
    cr.asm_const = dict(artifact["asm_const"])
    # _bare_cpp stays lazy (derived from cpp_enum on first use) — same as a fresh build.
    _cr._CACHE[(str(Path(blueprint_dir)), str(Path(src_dir)))] = cr


# --------------------------------------------------------------------------- #
# modifier-index artifact (var/fn -> stems + concrete setter sites) — VBT's OWN index
# --------------------------------------------------------------------------- #
def _build_modifier_artifact(blueprint_dir: Path, src_dir: Path) -> Dict[str, Any]:
    idx = _mi.get_modifier_index(blueprint_dir, src_dir)        # existing disk/build fast path
    return {
        "asm": {k: sorted(v) for k, v in idx.asm.items()},
        "cpp": {k: sorted(v) for k, v in idx.cpp.items()},
        "functions": {k: sorted(v) for k, v in idx.functions.items()},
        "asm_sites": {k: sorted(s.as_tuple() for s in v) for k, v in idx.asm_sites.items()},
        "cpp_sites": {k: sorted(s.as_tuple() for s in v) for k, v in idx.cpp_sites.items()},
    }


def _load_modifier_artifact(blueprint_dir: Path, src_dir: Path, artifact: Dict[str, Any]) -> None:
    idx = _mi.ModifierIndex()
    for k, v in artifact["asm"].items():
        idx.asm[k] = set(v)
    for k, v in artifact["cpp"].items():
        idx.cpp[k] = set(v)
    for k, v in artifact["functions"].items():
        idx.functions[k] = set(v)
    for k, rows in artifact["asm_sites"].items():
        idx.asm_sites[k] = {_mi.SetterSiteRef(*r) for r in rows}
    for k, rows in artifact["cpp_sites"].items():
        idx.cpp_sites[k] = {_mi.SetterSiteRef(*r) for r in rows}
    _mi._CACHE[(str(Path(blueprint_dir)), str(Path(src_dir)))] = idx


# --------------------------------------------------------------------------- #
# orchestration
# --------------------------------------------------------------------------- #
def _load_only(job_id: str, artifact: str, load: Callable[[Dict[str, Any]], None],
               *, validate: Optional[Callable[[Dict[str, Any]], bool]] = None) -> None:
    """O(1): load the blob if present; no hashing, no build. Caller falls back to compute on miss.

    ``validate`` (optional): reject a present-but-malformed blob (e.g. an empty name-alias artifact
    from a stale-cache build) so it falls back to the full-corpus build instead of silently loading a
    wrong/empty resolver. The #1 cold-run cliff: a MISSING (or here, INVALID) load-only blob reverts
    this resolver to a full-corpus source glob+parse (minutes at 22k — the "fresh full modifier-index
    scan" symptom), so we warn to make an incomplete precompute diagnosable rather than a silent hang
    (output unchanged — the caller computes the same result, just slowly)."""
    payload = DA.read_blob(job_id, artifact)
    if payload is None:
        logger.warning("load-only: resolver artifact %r ABSENT for job %s — falling back to a "
                       "full-corpus build (run `python -m vbt.precompute_db` to avoid the cold scan)",
                       artifact, job_id)
        return
    try:
        data = DA.loads_gz(payload)
        if validate is not None and not validate(data):
            logger.warning("load-only: resolver artifact %r for job %s failed validation — "
                           "falling back to full-corpus build", artifact, job_id)
            return
        load(data)
    except Exception as exc:
        logger.warning("load-only: resolver artifact %r failed to load (%s) — full-corpus build "
                       "fallback", artifact, exc)


def _ensure_artifact(job_id: str, artifact: str, source_hash: str, *,
                     load: Callable[[Dict[str, Any]], None],
                     build: Callable[[], Dict[str, Any]]) -> None:
    """Fresh-in-DB → load into caches; else build from source (fills caches) + persist."""
    if DA.manifest_fresh(job_id, artifact, version=RESOLVERS_VERSION, source_hash=source_hash):
        payload = DA.read_blob(job_id, artifact)
        if payload is not None:
            try:
                load(DA.loads_gz(payload))
                return
            except Exception as exc:
                logger.debug("load %s from DB failed, rebuilding: %s", artifact, exc)
    art = build()                              # fills the in-process caches either way
    try:
        if DA.write_blob(job_id, artifact, DA.dumps_gz(art)):
            DA.write_manifest(job_id, artifact, RESOLVERS_VERSION, source_hash)
    except Exception as exc:
        logger.debug("persist %s failed (non-fatal): %s", artifact, exc)


def preload_resolvers(job_id: Optional[str], blueprint_dir, asm_dir) -> bool:
    """Ensure the name-alias + membership resolvers are ready for this trace.

    * ``job_id`` None  → no-op (resolvers build lazily from source — unchanged behavior).
    * ``job_id`` set   → pre-fill the caches from a fresh DB artifact, else build from source
      (filling the caches) and persist for next time.

    Best-effort: any failure falls back to the normal lazy build.  Returns True iff it touched
    the caches.  name-alias is ensured before membership (membership's build reuses it)."""
    if not job_id:
        return False
    bp = Path(blueprint_dir)
    src = Path(asm_dir)

    # T12 trace-time fast path: load each blob by presence (O(1) DB reads), no source-file
    # hashing, no build. Freshness is the precompute's job.
    if DA.is_load_only():
        has_cc = any(src.glob("cc*.hpp"))
        _load_only(job_id, NAME_ALIAS_ARTIFACT, lambda a: _load_name_alias_artifact(src, a),
                   validate=lambda a: bool(a.get("units")) or not has_cc)
        _load_only(job_id, MEMBERSHIP_ARTIFACT, lambda a: _load_membership_artifact(bp, src, a))
        _load_only(job_id, CONST_ARTIFACT, lambda a: _load_const_artifact(bp, src, a))
        _load_only(job_id, MODIFIER_ARTIFACT, lambda a: _load_modifier_artifact(bp, src, a))
        return True

    try:
        shash = _source_hash(src)
    except Exception as exc:
        logger.debug("resolver source hash failed (lazy build will run): %s", exc)
        return False

    _ensure_artifact(job_id, NAME_ALIAS_ARTIFACT, shash,
                     load=lambda art: _load_name_alias_artifact(src, art),
                     build=lambda: _build_name_alias_artifact(src))
    _ensure_artifact(job_id, MEMBERSHIP_ARTIFACT, shash,
                     load=lambda art: _load_membership_artifact(bp, src, art),
                     build=lambda: _build_membership_artifact(bp, src))

    # const resolver: its own source set (blueprints' enum_values + source enums/EQU-DC),
    # so hash it with const_resolver's own file list + artifact version.
    try:
        const_hash = DA.source_manifest_hash(_cr._source_files(bp, src),
                                             version=_cr._ARTIFACT_VERSION)
        _ensure_artifact(job_id, CONST_ARTIFACT, const_hash,
                         load=lambda art: _load_const_artifact(bp, src, art),
                         build=lambda: _build_const_artifact(bp, src))
    except Exception as exc:
        logger.debug("const preload skipped (lazy build will run): %s", exc)

    # modifier index: its own source set + artifact version.
    try:
        mi_hash = DA.source_manifest_hash(_mi._source_files(bp, src),
                                          version=_mi._ARTIFACT_VERSION)
        _ensure_artifact(job_id, MODIFIER_ARTIFACT, mi_hash,
                         load=lambda art: _load_modifier_artifact(bp, src, art),
                         build=lambda: _build_modifier_artifact(bp, src))
    except Exception as exc:
        logger.debug("modifier_index preload skipped (lazy build will run): %s", exc)
    return True
