"""§16 #2-full (cross-trace route precompute): persist ``RouteEngine._routes_memo`` to index.db.

``route.routes(parent, child, max_routes)`` is a deterministic function of those args + the call
graph, and its result is pure JSON (round-trip-verified: ``json.loads(json.dumps(r)) == r`` for
every route result in a trace).  It does NOT depend on the traced variable — so the cross-file
caller-walk that dominates a *first* trace can be reused by every later trace (a new variable, the
same chain).

The route memo (RouteEngine._routes_memo, keyed by the parent/child Endpoint fields + max_routes)
is already the in-process seam: ``route.routes`` serves it first.  This module just **preloads**
that memo from a DB blob at trace start and **persists** it at trace end.  ``route.routes`` itself
is unchanged, so a preloaded result is byte-identical to a fresh compute — proven by the parity
gate + a shadow run (preload ON vs OFF → identical output).

Storage: ONE accumulating ``route_cache`` blob = a list of ``[key_list, result]`` pairs (the memo
tuple key as a JSON list — ``None`` survives as ``null``; ``max_routes`` int survives).  Concurrent
traces race to write it last-wins, which only affects hit-rate, never correctness.
``precompute_db`` clears it on rebuild so a stale route (a changed graph) is never served.
"""
from __future__ import annotations

from typing import Optional

from vbt.precompute import db_artifacts as DA

ARTIFACT = "route_cache"

# Bound the persisted cache so it can't grow without limit across many traces (the preload loads
# the whole blob into memory). It's a best-effort optimization, so capping never affects
# correctness — only hit-rate. Generous for the on-demand multi-variable workflow.
PERSIST_CAP = 200_000


def preload_route_cache(route, job_id: Optional[str]) -> int:
    """Pre-fill ``route._routes_memo`` AND ``route._reachable_memo`` from the DB blob.
    Returns #entries loaded (0 on miss/fail). Best-effort: any failure leaves the memos
    empty (routes/reachability compute live, byte-identical).

    Blob formats: v1 (legacy) — a bare list of ``[key_list, routes_result]`` pairs (routes
    memo only); v2 — ``{"routes": [...], "reachable": [[key_list, bool], ...]}``. The
    reachable memo matters MORE than the routes memo for the dep-var BFS: its off-chain
    setter checks and param-binding scoping are `route.reachable()` calls (the dominant
    per-node cost), and before v2 that memo was purely in-process — every fresh worker
    re-walked all reachability even on a fully warm KB."""
    if not job_id:
        return 0
    try:
        payload = DA.read_blob(job_id, ARTIFACT)
        if payload is None:
            return 0
        entries = DA.loads_gz(payload)
        n = 0
        if isinstance(entries, dict):                # v2
            memo = route._routes_memo
            for kl, res in entries.get("routes") or []:
                memo[tuple(kl)] = res                # list -> tuple key; None/int preserved
                n += 1
            rmemo = getattr(route, "_reachable_memo", None)
            if rmemo is not None:
                for kl, ok in entries.get("reachable") or []:
                    rmemo[tuple(kl)] = bool(ok)
                    n += 1
        else:                                        # v1 legacy list — routes memo only
            memo = route._routes_memo
            for kl, res in entries:
                memo[tuple(kl)] = res
                n += 1
        return n
    except Exception:
        return 0


def persist_route_cache(route, job_id: Optional[str]) -> bool:
    """Write both route memos back to the DB blob (current memos = prior + this trace's new
    entries, since preload filled them). Best-effort; never raises into the trace."""
    if not job_id:
        return False
    try:
        memo = getattr(route, "_routes_memo", None) or {}
        rmemo = getattr(route, "_reachable_memo", None) or {}
        if not memo and not rmemo:
            return False
        r_items = list(memo.items())[:PERSIST_CAP]   # bound the blob (best-effort cache;
        k_items = list(rmemo.items())[:PERSIST_CAP]  # correctness-neutral)
        entries = {"routes": [[list(k), v] for k, v in r_items],
                   "reachable": [[list(k), bool(v)] for k, v in k_items]}
        return DA.write_blob(job_id, ARTIFACT, DA.dumps_gz(entries))
    except Exception:
        return False
