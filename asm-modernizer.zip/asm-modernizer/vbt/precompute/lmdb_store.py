"""LMDB backend for VBT precompute artifacts (W12 / T2).

A drop-in alternative to the sqlite tables (``vbt_artifact_blob`` /
``vbt_cfg_blob`` / ``vbt_precompute_manifest``) backing
``vbt.precompute.db_artifacts``. Mirrors that module's public API surface
(read/write/clear blob, read/write/manifest_present manifest, cfg read/write).

Why
====
SQLite blob reads pay a per-row deserialize + connection acquire cost
(~500 µs per ``read_blob`` for a 5 KB blob). At 24 k scale a heavy trace may
do thousands of these per query, accumulating multiple seconds of pure
storage overhead. LMDB returns the stored bytes as a memoryview into an mmap'd
file — the read becomes a hash + bounds check (~10 µs), no copy until the
caller reads the bytes.

When this backend is selected
==============================
Reads & writes go through this module when ``VBT_DB_BACKEND=lmdb``. Default
backend remains sqlite — existing precomputed corpora keep working with no
config change.

Storage layout
==============
One LMDB environment per ``job_id`` at::

    <JOBS_BASE_DIR>/<job_id>/vbt_lmdb/

Three named sub-databases inside that env:

* ``blobs``    — key = artifact name (bytes), value = payload bytes (the same
                 gzipped JSON the sqlite backend stores; callers expect to call
                 ``loads_gz`` themselves).
* ``cfg``      — key = cfg_key (bytes), value = payload bytes.
* ``manifest`` — key = artifact name, value = ``json.dumps({version,
                 source_hash, built_at})``.

Read path is mmap-only (no copy until ``bytes(buf)``); write path runs one
short ``env.begin(write=True)`` per call. The env's ``map_size`` is set
generously (default 100 GB) — LMDB allocates sparsely on Linux so this costs
no disk until data is written.
"""
from __future__ import annotations

import json
import logging
import os
import time
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---- per-process env cache --------------------------------------------------- #
_ENV_LOCK = threading.Lock()
_ENVS: Dict[str, Any] = {}            # job_id -> lmdb.Environment
_SUBDBS: Dict[str, Dict[str, Any]] = {}   # job_id -> {name -> lmdb db handle}


def _default_map_size() -> int:
    raw = os.environ.get("VBT_LMDB_MAP_SIZE_BYTES")
    if raw and raw.strip().isdigit():
        return max(64 << 20, int(raw))      # >= 64 MB floor
    return 100 * (1 << 30)                  # 100 GB default, sparse


def _lmdb_root(job_id: str) -> Path:
    """Resolve the LMDB dir for a job. Honors JOBS_BASE_DIR / api.config.settings."""
    base = os.environ.get("JOBS_BASE_DIR")
    if not base:
        try:
            from api.config import settings
            base = str(settings.JOBS_BASE_DIR)
        except Exception:
            base = "/var/asm-jobs"
    return Path(base) / job_id / "vbt_lmdb"


def _env(job_id: str):
    """Open + cache the LMDB env for a job_id. Thread-safe."""
    if not job_id:
        return None, None
    with _ENV_LOCK:
        env = _ENVS.get(job_id)
        if env is not None:
            return env, _SUBDBS[job_id]
        import lmdb
        root = _lmdb_root(job_id)
        root.mkdir(parents=True, exist_ok=True)
        env = lmdb.open(
            str(root),
            map_size=_default_map_size(),
            max_dbs=8,
            subdir=True,
            sync=False,         # writes flushed lazily; precompute restart re-runs anyway
            metasync=False,
            readahead=True,     # OK for our scan patterns
            lock=True,
        )
        subs = {
            "blobs": env.open_db(b"blobs"),
            "cfg": env.open_db(b"cfg"),
            "manifest": env.open_db(b"manifest"),
        }
        _ENVS[job_id] = env
        _SUBDBS[job_id] = subs
        return env, subs


def is_active() -> bool:
    """``True`` when the LMDB backend should be used.

    Activated by ``VBT_DB_BACKEND=lmdb``. Any other value (or absence) falls
    back to the sqlite path in db_artifacts. Module import is checked here
    rather than at db_artifacts import-time so callers can flip the env in
    tests / runtime without a re-import.
    """
    val = (os.environ.get("VBT_DB_BACKEND") or "").strip().lower()
    return val in ("lmdb", "vbt_lmdb")


# ---- blob ops ---------------------------------------------------------------- #
def read_blob(job_id: Optional[str], artifact: str) -> Optional[bytes]:
    if not job_id:
        return None
    try:
        env, subs = _env(job_id)
        if env is None:
            return None
        with env.begin(db=subs["blobs"], buffers=True) as txn:
            buf = txn.get(artifact.encode("utf-8"))
            return bytes(buf) if buf is not None else None
    except Exception as exc:
        logger.debug("[lmdb] read_blob(%s, %s) failed: %s", job_id, artifact, exc)
        return None


def write_blob(job_id: Optional[str], artifact: str, payload: bytes) -> bool:
    if not job_id:
        return False
    try:
        env, subs = _env(job_id)
        if env is None:
            return False
        with env.begin(db=subs["blobs"], write=True) as txn:
            txn.put(artifact.encode("utf-8"), payload, overwrite=True)
        return True
    except Exception as exc:
        logger.debug("[lmdb] write_blob(%s, %s) failed: %s", job_id, artifact, exc)
        return False


def clear_blobs_prefix(job_id: Optional[str], prefix: str) -> int:
    if not job_id:
        return 0
    try:
        env, subs = _env(job_id)
        if env is None:
            return 0
        pb = prefix.encode("utf-8")
        n = 0
        with env.begin(db=subs["blobs"], write=True) as txn:
            cur = txn.cursor()
            if cur.set_range(pb):
                while True:
                    k = bytes(cur.key())
                    if not k.startswith(pb):
                        break
                    cur.delete()
                    n += 1
                    # cursor advances to next via delete() in MDB; if not, set_range again
                    if not cur.set_range(pb):
                        break
        return n
    except Exception as exc:
        logger.debug("[lmdb] clear_blobs_prefix(%s, %s) failed: %s", job_id, prefix, exc)
        return 0


def list_blob_keys_prefix(job_id: Optional[str], prefix: str) -> List[str]:
    """Return every blob artifact key starting with ``prefix`` for ``job_id``."""
    if not job_id:
        return []
    try:
        env, subs = _env(job_id)
        if env is None:
            return []
        pb = prefix.encode("utf-8")
        out: List[str] = []
        with env.begin(db=subs["blobs"]) as txn:
            cur = txn.cursor()
            if cur.set_range(pb):
                for k, _v in cur:
                    kb = bytes(k)
                    if not kb.startswith(pb):
                        break
                    out.append(kb.decode("utf-8"))
        return out
    except Exception as exc:
        logger.debug("[lmdb] list_blob_keys_prefix(%s, %s) failed: %s", job_id, prefix, exc)
        return []


# ---- cfg ops ----------------------------------------------------------------- #
def read_cfg_blob(job_id: Optional[str], cfg_key: str) -> Optional[bytes]:
    if not job_id:
        return None
    try:
        env, subs = _env(job_id)
        if env is None:
            return None
        with env.begin(db=subs["cfg"], buffers=True) as txn:
            buf = txn.get(cfg_key.encode("utf-8"))
            return bytes(buf) if buf is not None else None
    except Exception as exc:
        logger.debug("[lmdb] read_cfg_blob(%s, %s) failed: %s", job_id, cfg_key, exc)
        return None


def write_cfg_blob(job_id: Optional[str], cfg_key: str, payload: bytes) -> bool:
    if not job_id:
        return False
    try:
        env, subs = _env(job_id)
        if env is None:
            return False
        with env.begin(db=subs["cfg"], write=True) as txn:
            # Cfg keys are content-hashes — store first-wins to match the sqlite
            # path's "unique constraint, ignore duplicate" behavior.
            txn.put(cfg_key.encode("utf-8"), payload, overwrite=False)
        return True
    except Exception as exc:
        logger.debug("[lmdb] write_cfg_blob(%s, %s) failed: %s", job_id, cfg_key, exc)
        return False


# ---- manifest ops ------------------------------------------------------------ #
def read_manifest(job_id: Optional[str], artifact: str) -> Optional[Dict[str, Any]]:
    if not job_id:
        return None
    try:
        env, subs = _env(job_id)
        if env is None:
            return None
        with env.begin(db=subs["manifest"], buffers=True) as txn:
            buf = txn.get(artifact.encode("utf-8"))
            if buf is None:
                return None
            return json.loads(bytes(buf).decode("utf-8"))
    except Exception as exc:
        logger.debug("[lmdb] read_manifest(%s, %s) failed: %s", job_id, artifact, exc)
        return None


def write_manifest(job_id: Optional[str], artifact: str, version: int,
                   source_hash: str, built_at: Optional[str] = None) -> bool:
    if not job_id:
        return False
    if built_at is None:
        built_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    try:
        env, subs = _env(job_id)
        if env is None:
            return False
        payload = json.dumps({"version": version, "source_hash": source_hash,
                              "built_at": built_at}, separators=(",", ":")).encode("utf-8")
        with env.begin(db=subs["manifest"], write=True) as txn:
            txn.put(artifact.encode("utf-8"), payload, overwrite=True)
        return True
    except Exception as exc:
        logger.debug("[lmdb] write_manifest(%s, %s) failed: %s", job_id, artifact, exc)
        return False


def manifest_present(job_id: Optional[str], artifact: str) -> bool:
    return read_manifest(job_id, artifact) is not None
