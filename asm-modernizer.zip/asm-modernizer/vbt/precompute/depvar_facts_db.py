"""Reverse setter facts for dep-var traversal.

The existing setter-map artifacts are stored per source file:

    stem -> {variable_tail: [SetterSite, ...]}

That shape is good for one file scan, but dep-var recursion asks the opposite
question thousands of times at d3 scale:

    variable_tail -> setters in the current chain/reach frontier

This module builds that reverse index as local facts. It is deliberately not a
transitive closure and does not precompute a trace result; it only stores local
producer facts so the runtime can do a Souffle-style semi-naive frontier walk
using indexed lookups.
"""
from __future__ import annotations

import logging
from dataclasses import fields as _dc_fields
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence
from urllib.parse import quote

from backward_traversal.utils.token_utils import normalize_token

from vbt.interfaces import SetterSite
from vbt.precompute import db_artifacts as DA

logger = logging.getLogger(__name__)

DEPVAR_SETTER_FACTS_ARTIFACT = "depvar_setter_facts"
DEPVAR_SETTER_FACTS_VERSION = 1
_SS_FIELDS = [f.name for f in _dc_fields(SetterSite)]
_LOADED: Dict[tuple, object] = {}
_LOADED_MAX = 2048


def _norm_key(variable: str, language: str) -> str:
    if language == "cpp":
        return (variable or "").split(".")[-1].split("->")[-1]
    return normalize_token(variable or "").upper()


def _artifact(language: str, key: str) -> str:
    return f"{DEPVAR_SETTER_FACTS_ARTIFACT}:{language}:{quote(key, safe='')}"


def _cpp_source_exists(asm_dir: Optional[Path], stem: str) -> bool:
    return bool(asm_dir and (asm_dir / f"{stem}.cpp").exists())


def _asm_source_exists(asm_dir: Optional[Path], stem: str) -> bool:
    if not asm_dir:
        return False
    return (asm_dir / f"{stem}.asm").exists() or (asm_dir / f"{stem}.mac").exists()


def _stem_covered(
    coverage: Optional[Dict[str, str]],
    stem: str,
    *,
    language: str,
    asm_dir: Optional[Path],
) -> bool:
    """True when a missing row for (stem,var) is a sound negative answer."""
    from vbt.precompute.chain_facts_db import EMPTY, OK

    if language == "cpp" and not _cpp_source_exists(asm_dir, stem):
        return True
    if language == "asm" and not _asm_source_exists(asm_dir, stem):
        return True
    return bool(coverage and coverage.get(stem) in (OK, EMPTY))


def _row_to_setter(row: dict, variable: str, language: str,
                   full_paths: Optional[Sequence[str]]) -> Optional[SetterSite]:
    if language == "cpp":
        from vbt.setters.cpp_setters import _matches_full_paths, _member_chain

        fp = list(full_paths or [])
        full_set = set(fp)
        full_chains = [_member_chain(p) for p in full_set]
        lhs_path = row.get("lhs_path", "")
        lhs_chain = row.get("lhs_chain") or _member_chain(lhs_path)
        matched_explicit = lhs_path in full_set
        if full_chains and not matched_explicit and not _matches_full_paths(lhs_chain, full_chains):
            return None
        if matched_explicit:
            match_scope = "qualified"
        elif len(lhs_chain) > 1:
            match_scope = "member"
        else:
            match_scope = "local"
        s = SetterSite(**{k: row.get(k) for k in _SS_FIELDS})
        s.variable = variable
        s.match_scope = match_scope
        s.lhs_path = lhs_path
        s.macro_setter_notes = row.get("macro_setter_notes")
        return s

    s = SetterSite(**{k: row.get(k) for k in _SS_FIELDS})
    s.variable = variable
    return s


def _load_rows(job_id: str, language: str, key: str) -> Optional[List[dict]]:
    ck = (job_id, language, key)
    rows = _LOADED.get(ck, 0)
    if rows == 0:
        payload = DA.read_blob(job_id, _artifact(language, key))
        rows = DA.loads_gz(payload) if payload is not None else []
        if len(_LOADED) >= _LOADED_MAX:
            _LOADED.pop(next(iter(_LOADED)))
        _LOADED[ck] = rows
    return list(rows or [])


def load_setters_for_target(
    job_id: Optional[str],
    variable: str,
    language: str,
    candidate_stems: Iterable[str],
    *,
    asm_dir: Optional[Path] = None,
    full_paths: Optional[Sequence[str]] = None,
) -> Optional[List[SetterSite]]:
    """Return reverse-indexed setters, [] for covered negatives, or None to fallback.

    ``None`` is used whenever the DB cannot prove coverage for all candidate stems;
    the caller then runs the old live/per-stem path, preserving output.
    """
    if not job_id or not DA.is_load_only():
        return None
    manifest = DA.read_manifest(job_id, DEPVAR_SETTER_FACTS_ARTIFACT)
    if not manifest or int(manifest.get("version", 0) or 0) != DEPVAR_SETTER_FACTS_VERSION:
        return None
    key = _norm_key(variable, language)
    cand = sorted({str(s) for s in candidate_stems})
    try:
        from vbt.precompute.chain_facts_db import (
            ASM_SETTERS_FULL_COVERAGE_ARTIFACT,
            CPP_SETTER_MAP_COVERAGE_ARTIFACT,
            load_coverage,
        )
        cov_art = CPP_SETTER_MAP_COVERAGE_ARTIFACT if language == "cpp" else ASM_SETTERS_FULL_COVERAGE_ARTIFACT
        cov = load_coverage(job_id, cov_art)
        if not all(_stem_covered(cov, stem, language=language, asm_dir=asm_dir) for stem in cand):
            return None
        rows = _load_rows(job_id, language, key)
    except Exception as exc:
        logger.debug("depvar setter facts load fallback: %s", exc)
        return None

    cand_set = set(cand)
    out: List[SetterSite] = []
    for row in rows:
        stem = str(row.get("file_stem") or "")
        if stem not in cand_set:
            continue
        s = _row_to_setter(row, variable, language, full_paths)
        if s is not None:
            out.append(s)
    return out


def build_and_store_depvar_setter_facts(job_id, blueprint_dir, asm_dir) -> Dict[str, int]:
    """Build reverse local setter facts from the already-built per-stem maps."""
    from vbt.precompute.chain_facts_db import ASM_SETTERS_FULL_ARTIFACT
    from vbt.precompute.cpp_setter_map_db import CPP_SETTER_MAP_ARTIFACT

    src = Path(asm_dir)
    DA.clear_blobs_prefix(job_id, DEPVAR_SETTER_FACTS_ARTIFACT + ":")

    facts: Dict[tuple, List[dict]] = {}
    cpp_stems = 0
    asm_stems = 0

    for cpp in sorted(src.glob("*.cpp")):
        payload = DA.read_blob(job_id, f"{CPP_SETTER_MAP_ARTIFACT}:{cpp.stem}")
        if payload is None:
            continue
        cpp_stems += 1
        m = DA.loads_gz(payload) or {}
        for tail, rows in m.items():
            facts.setdefault(("cpp", str(tail)), []).extend(rows or [])

    for asm in sorted(src.glob("*.asm")):
        payload = DA.read_blob(job_id, f"{ASM_SETTERS_FULL_ARTIFACT}:{asm.stem}")
        if payload is None:
            continue
        asm_stems += 1
        m = DA.loads_gz(payload) or {}
        for var, rows in m.items():
            facts.setdefault(("asm", str(var)), []).extend(rows or [])

    written = 0
    for (language, key), rows in sorted(facts.items()):
        rows = sorted(rows, key=lambda r: (
            str(r.get("file_stem") or ""),
            int(r.get("line") or 0),
            str(r.get("instruction") or ""),
            str(r.get("block_id") or ""),
            str(r.get("value") or ""),
        ))
        if DA.write_blob(job_id, _artifact(language, key), DA.dumps_gz(rows)):
            written += 1

    src_files = sorted(src.glob("*.cpp")) + sorted(src.glob("*.asm")) + sorted(src.glob("*.mac"))
    DA.write_manifest(
        job_id,
        DEPVAR_SETTER_FACTS_ARTIFACT,
        DEPVAR_SETTER_FACTS_VERSION,
        DA.source_manifest_hash(src_files, version=DEPVAR_SETTER_FACTS_VERSION),
    )
    _LOADED.clear()
    return {
        "keys": len(facts),
        "blobs": written,
        "cpp_stems": cpp_stems,
        "asm_stems": asm_stems,
    }
