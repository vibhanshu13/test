# VBT Setter Ordering

Given a variable (**ASM or C++**), return JSON that lists **where** it is set and in
**what static order** the setters run — using only the precomputed `index.db`, with
**zero live file reads**.

```
variable → setter sites → function-graph LCA(s) → flat ordered setter visits per LCA
```

| Artifact | Path |
|----------|------|
| Core module | `vbt/setter_order.py` (`trace_variable_to_setter_order`, `--local` CLI) |
| Celery task | `api/tasks/vbt_lca_trace_task.py` (`asm.vbt_setter_order`, body `run_setter_order`) |
| HTTP route | `api/routes/vbt.py` (`POST /vbt/setter-order`, `VbtSetterOrderRequest`) |
| Shared DB-only context | `vbt/lca_trace.py` (`_db_only_setter_lca_context`, `_LcaInputs`) |
| Tests | `vbt/tests/test_setter_order.py` |
| Registration | `api/tasks/celery_app.py` (`include` list — same module as `asm.vbt_lca_trace`) |

---

## What it does & why

A variable is set in many places across the corpus. This feature answers, for one
variable:

> Where are its setters, and in what order do they run relative to each other?

It reuses the strict DB-only discovery + LCA machinery (`vbt/lca_trace.py`): it finds
the variable's setter sites, computes the function-graph **lowest common ancestor(s)**
of those setters (multiple LCAs ⇒ multiple independent trees), then walks each tree
**downward** and emits the setters it visits as a single **flat ordered list**. The
nested traversal is internal only — the public result per LCA is one flat `setters`
array, each entry carrying an `order` index, a use `depth`, language, file, and line.

It runs entirely against the precomputed `index.db` in `load_only` mode: **no source,
blueprint-file, live setter scan, resolver rebuild, or `cfg_extract`** — any missing
required artifact hard-fails rather than reading disk.

---

## Ordering semantics (the honesty boundary)

Ordering is **static source/CFG order, not observed runtime order**. The DB has no
branch-taken, loop-count, or data-dependent dispatch evidence, so this never claims a
proven execution order. Per language, both fully DB-only:

- **ASM nodes** → **CFG dominance order** reconstructed from the ASM blueprint blob
  (`bp:{stem}.asm.json`) already in `index.db`. Setters carry `blockId`, `blockRank`,
  and `dominanceCertainty`:
  - `guaranteed` — the setter's block dominates the later-emitted blocks on that path
    (it always runs before them).
  - `branch-alternative` — the block does not dominate a peer item (it is on a
    mutually-exclusive branch).
  - `unknown` — CFG data was missing/malformed/capped or fell back to line order.
- **C++ nodes** → **source / call-site line order**. A reliable C++ CFG/dominator is
  *not* DB-only (it is trace-time `cfg_extract`; `vbt_cfg_blob` is an opportunistic,
  incomplete cache), so C++ stays line-ordered by design. C++ setters carry `function`
  and omit `blockRank`/`dominanceCertainty`.
- **Mixed traces** — each node orders its own setters and child calls by its own
  language rule; a child call's position comes from the parent's per-language rank.

`blockRank` is an ordering heuristic; **dominance is the guarantee signal** — do not read
`blockRank(A) < blockRank(B)` as "A always runs before B". Output never uses the field
names `executionOrder`/`runtimeOrder`.

---

## How it works

1. **`_db_only_setter_lca_context`** (in `vbt/lca_trace.py`): `set_load_only(True)`,
   clears all overrides, validates required manifests with `_require(...)`, loads
   resolvers via `strict_load_resolvers` (never `preload_resolvers`), arms only the
   DB-backed setter/fn-facts jobs, loads `fn_graph_adj` + `reverse_adj`, discovers
   setters (ASM `asm_setters_full`, C++ `cpp_setter_map` + `_attribute_cpp`, plus
   cross-language aliases) — **retaining the `SetterSite` objects per node** — and
   computes the LCA(s) via `lca_roots`.
2. **Reachability prune:** for each LCA, `reachable = ⋃ _bfs(setter_node, reverse_adj)`
   over the covered setters; the forward walk only follows edges into nodes that can
   reach a setter.
3. **Ordered traversal:** forward DFS from the LCA with a per-path cycle guard. At each
   node, direct setters and outgoing call sites are interleaved into one ordered item
   list (by the node's language rule), walked in order — direct setters are emitted,
   call items are recursed into before the next item. `order` is assigned 0..N as
   setters are emitted; `depth` is the hop distance from the LCA.
4. **ASM CFG ranker:** the blueprint blob is read via `DA.read_blob(...)`,
   `_build_cfg_maps` (in-memory, pure) builds the block CFG, and the dominator
   fixed-point is computed in-memory (the pure loop lifted from
   `asm_conditions.py`; the disk-reading `_cfg_dom_reach` is **not** used). The per-stem
   CFG/dominator build is **memoized for the request** so re-entered modules are O(1).
5. **Emit** one flat `setters` array per tree.

Bounded by `max_depth=16` and `max_nodes=4000`; hitting either sets top-level
`truncated: true` and the list is a deterministic prefix.

---

## API

### Celery task — `asm.vbt_setter_order`

`POST /vbt/setter-order` (202 + `JobResponse`) dispatches the task. Request body
(`VbtSetterOrderRequest`):

| Field | Default | Notes |
|-------|---------|-------|
| `kb_id` | — | precompute job whose `index.db` is read |
| `variable` | — | the variable to order |
| `language` | `"asm"` | `"asm"` or `"cpp"` |
| `domain` | `null` | optional forced-LCA domain |
| `allow_missing_forced_lca` | `false` | |
| `allow_unattributed_setters` | `true` | exclude + warn instead of hard-fail |
| `trace_options` | `null` | see below |
| `debug` | `false` | also writes `setter_order.debug.json` |

`trace_options`: `candidate_stems`, `home_hint`, `max_depth` (16), `max_nodes` (4000),
`asm_cfg_order` (true), `include_call_path` (false, diagnostic),
`include_cpp_condition_hints` (false, accepted but inert).

Output is written to `jobs/<output_job_id>/output/setter_order.json`. The task **always
returns JSON**: on `SoftTimeLimitExceeded` / `DbArtifactMissing` / any error it returns
`{"status":"failed", ...}` and best-effort writes that failure payload.

### Core function (DB-only, in-process)

```python
from vbt.setter_order import trace_variable_to_setter_order
payload = trace_variable_to_setter_order(precompute_job_id, variable, language,
                                         max_depth=16, max_nodes=4000, asm_cfg_order=True)
```

It **raises** `DbArtifactMissing` on a missing/stale required artifact (the task layer
turns that into failure JSON). CLI: `python -m vbt.setter_order --local <kb> <variable> <lang>`.

---

## Output schema

```jsonc
{
  "status": "success",
  "variable": "softCardValue",
  "language": "asm",
  "orderSemantics": {
    "kind": "static-cfg-source-order",
    "asm": "cfg-block-rank-with-dominance-hints",
    "cpp": "source-line-order",
    "runtimeProof": false
  },
  "truncated": false,
  "warnings": [],
  "excludedSetterCount": 0,
  "trees": [
    {
      "treeIndex": 0,
      "lca": { "file": "dw710000", "function": "processACreditTransaction", "language": "cpp" },
      "setterCount": 2,
      "setters": [
        { "order": 0, "depth": 0, "siteId": "aa71:412:AA710A58:OI",
          "file": "aa71", "function": null, "line": 412, "language": "asm",
          "instruction": "OI", "value": "...",
          "blockId": "AA710A58", "blockRank": 0, "dominanceCertainty": "guaranteed" },
        { "order": 1, "depth": 1, "siteId": "dw730000:910:applyCredit:assign",
          "file": "dw730000", "function": "applyCredit", "line": 910, "language": "cpp",
          "instruction": "assign", "value": "0", "blockId": "dw730000::applyCredit" }
      ]
    }
  ]
}
```

- `order` is a within-tree index, **not** a runtime guarantee. `depth` is call-hop
  distance from the LCA. `siteId` is stable/deterministic but not unique across KB
  versions — the same physical site reached via two call sites appears as two visits
  with the same `siteId`.
- No setters ⇒ `status:"success"`, `trees:[]`, `warnings:[{"code":"no_setters"}]`.
- Warning codes: `no_setters`, `blueprint_missing` (`{file, fallback:"line_order"}`),
  `unattributed_setter` (`{file, line}`), `forced_lca_absent` (`{node}`).

---

## Operational guarantees

- **No file reads** — request path reads only `index.db` blobs; enforced by `load_only`
  + a strict-DB-only tripwire test (monkeypatches `run_cfg_extract`/`load_json`/
  `find_*_setters`/`preload_resolvers` to raise and asserts none fire).
- **No VBT precompute re-run** — consumes only artifacts the standard `vbt.precompute_db`
  already emits (`fn_graph_adj`, `reverse_adj`, resolvers, `fn_facts`, setter coverage
  maps + blobs, ASM `bp:*` blueprints). No new artifact, no schema change. A missing
  per-stem blueprint degrades that one module to line order with a warning; only a
  missing/stale *required* artifact hard-fails.
- **No chain precompute re-run** — `chain_facts` is not used (only the optional,
  default-off C++ `conditional` hint would touch it).

---

## Prerequisites

A completed VBT precompute for the target KB: `jobs/<kb_id>/index.db` with the standard
artifacts present and fresh. ASM CFG ordering additionally uses the per-stem
`bp:{stem}.asm.json` blobs (degrades to line order if a stem's blueprint is absent).

---

## Testing

`pytest vbt/tests/test_setter_order.py` — pure-logic ordering/depth/prune/recursion/
truncation/determinism, ASM-CFG dominance over hand-built blueprints, DB-backed
end-to-end (skipped if no ready KB), the strict-DB-only tripwire, and task/route tests.
The refactor is guarded by `pytest vbt/tests/test_lca_trace.py vbt/tests/test_all_chains_trace.py`
(behavior-preserving — byte-identical LCA/chains output).
