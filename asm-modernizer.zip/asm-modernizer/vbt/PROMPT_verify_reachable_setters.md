# Verification Prompt — VBT "Reachable Setters" Correctness Audit

> This is the only prompt file you need to paste. Before pasting it into Copilot /
> agent mode, update the **INPUTS TO FILL** block below. The repo includes the
> audit harness referenced by this prompt at repo root:
> `verify_reachable_setters_capraised.py`.

---

## INPUTS TO FILL

Replace the placeholder values in this block before running the audit. Keep the
field names unchanged so the agent can refer back to them.

```text
KB_ID=<kb_id>
ENTRY_STEM=<stem>
ENTRY_FUNCTION=<function>
PRODUCTION_OUTPUT_JSON=<path-to-saved-221-variable-reachable-setters-output.json>
ASM_DIR=<source-dir>
BLUEPRINT_DIR=jobs/<kb_id>/output
CAPRAISED_OUT=capraised_diff.json
```

Notes:

- `PRODUCTION_OUTPUT_JSON` is required. It should be the saved output from the
  original `asm.vbt_reachable_setters` run over the 221 variables.
- Prefer deriving the 221-variable set from `PRODUCTION_OUTPUT_JSON`; do not infer
  it from broad source greps.
- If any input cannot be resolved from local context, stop after DB readiness and
  report the missing input as a blocker.
- If `BLUEPRINT_DIR=jobs/<kb_id>/output` is not the actual blueprint directory,
  replace it with the concrete blueprint directory discovered for the job.

---

> Paste everything below into Copilot (Copilot Chat / agent mode) **inside the
> client repo checkout** that contains `vbt/`, the task code, and the precomputed
> `jobs/<kb_id>/index.db`. It tells Copilot to (1) learn `vbt/` end‑to‑end, then
> (2) independently verify the 221‑variable reachable‑setters output for **missed**
> setters, **extra** setters, and **mis‑attributed** setters — with a root cause for
> every discrepancy and an executable methodology, not hand‑waving.

---

## ROLE

You are a meticulous static‑analysis auditor. I ran the Celery task
`asm.vbt_reachable_setters` (code: `api/tasks/vbt_reachable_setters_task.py`,
prototype CLI: `find_reachable_setters.py`) over **221 variables** for a client KB
of **~22,000 files**, from a single entry point `stem::function`. For each variable
it emitted a list of setter sites it claims are **forward‑reachable from that entry
point**, using only the precomputed `jobs/<kb_id>/index.db` (zero live file reads).

Your job is to **verify correctness of that output**, per variable, answering three
questions precisely:

- **MISSED (false negative):** a setter site that *genuinely* sets the variable AND is
  *genuinely* reachable from `stem::function`, but is **absent** from the task output.
- **EXTRA (false positive):** a reported setter that is **not actually a setter of the
  variable**, OR is **not genuinely reachable** from `stem::function`.
- **MIS‑ATTRIBUTED:** a reported setter whose `function`/`block_id`, `line`, `file_stem`,
  or `code` field is wrong even if the site itself is legitimate.

Do **not** trust the task's own reachability/candidate logic as ground truth — the whole
point is to build an **independent** oracle and diff against it. Do not modify production
code or fix any defects you find; temporary audit-only harnesses/scripts are allowed if
they are clearly labeled, kept out of production paths, and included only as evidence for
the report.

Critical audit standard: distinguish **candidate evidence** from **confirmed evidence**.
A cap-raised rerun, a wider fan-out, or an unbounded metadata walk can reveal suspicious
sites, but a discrepancy is not confirmed until you independently verify both facts:
(1) the source site really writes this variable's storage, and (2) a concrete, hop-by-hop
valid path exists from the entry point to that setter.

---

## STEP 1 — Learn the pipeline (read these, in order)

Read each file and confirm you understand its contract before auditing. The pipeline
has five stages; a defect in any stage changes the answer.

| File / symbol | Role in the pipeline |
|---|---|
| `vbt/README_reachable_setters.md` | The feature's own spec — read first. |
| `api/tasks/vbt_reachable_setters_task.py` → `run_reachable_setters()` | The orchestrator. This is the algorithm of record. |
| `find_reachable_setters.py` | Standalone twin of the task (same logic, hardcoded fixture paths). Easiest to run & instrument. |
| `vbt/engine.py` → `resolve_aliases()` | Stage 1: cross‑language alias expansion (C++ name ↔ ASM DSECT field). |
| `vbt/resolve/name_resolver.py`, `vbt/resolve/_find_cpp_chain.py` | How aliases are actually derived (gen `.hpp` ↔ `.mac` ↔ `cc*.hpp`, byte‑offset overlay, comment consensus). |
| `vbt/precompute/modifier_index.py` → `get_modifier_index()`, `.files_for(name, lang)` | Stage 2: the candidate **file** set that supposedly contains every write of a name. |
| `vbt/reach/route.py` → `RouteEngine.forward_reachable_files()`, `RouteEngine.routes()`, `forward_file_distances()` | Stage 3 pre‑filter + fallback reachability check. Note default `max_len` (file‑hop cap). |
| `vbt/reach/cpp_routes.py` → `enumerate_cpp_paths()`, `CppFnGraph`, `_ENTRY_FANOUT_CAP`, dense‑graph phases | Stage 4 primary reachability confirmation. Note the `max_paths` / `max_depth` caps. |
| `vbt/setters/cpp_setters.py` → `find_cpp_setters_in_file()` | Stage 4 candidate detection (C++). Tree‑sitter; tail‑match + `full_paths` suffix gate. |
| `vbt/setters/asm_setters.py` → `find_asm_setters_in_file()`, `find_asm_indirect_dest_sites()`; reused glossary `SETTER_INST`/`classify_setter()` | Stage 4 candidate detection (ASM). |
| `check_db_readiness.py` | Verifies the `index.db` actually contains the artifacts all of the above depend on. |

### The algorithm of record (state it back in your own words after reading)

For entry `tail_ep = Endpoint(stem, file_type, function)` (file_type from `index.db`
blueprint key `bp:{stem}.%`; `function` is ignored for ASM entries):

1. Load precompute in **load‑only** mode: resolvers, route graph, C++ call edges, route
   cache, ASM+C++ setter maps, C++ file‑writes, fn‑facts.
2. `reachable_files = route.forward_reachable_files(tail_ep)` — a file‑stem set.
3. For each variable `V`:
   a. `targets = [(V,"cpp")] + resolve_aliases(V,"cpp",asm_dir).aliases` (cross‑language).
   b. For each `(name, lang)`: `stems = midx.files_for(name, lang)`, then
      `pruned = stems ∩ reachable_files`. For each pruned stem, collect candidate setters
      via `find_cpp_setters_in_file` (with `full_paths=[name]` when `name` contains `.`/`->`)
      or `find_asm_setters_in_file`.
   c. **Confirm reachability of each candidate** `s`:
      `cpp_paths, truncated = enumerate_cpp_paths(route,{},asm_dir,tail_ep,s,max_paths=64,max_depth=16)`;
      `reachable = bool(cpp_paths)` or
      `route.routes(tail_ep, Endpoint(s.file_stem,s.language,s.function)).get("reachable")`.
      The task ignores `truncated` when deciding whether to escalate.
   d. Keep `s` iff `reachable`.

**The single most important structural observation:** the reachability decision in (c) is
the **OR of two *bounded* checks**. `enumerate_cpp_paths` is bounded by `max_depth=16`
(function‑hops) and `max_paths=64`; `route.routes` is bounded by `max_len` (file‑hops,
default ~16) and `max_routes`. There is **no unbounded fallback**. So a setter that is
genuinely reachable but only via a chain deeper than these caps will be **silently
dropped as a false negative**. Treat this as your top hypothesis for MISSED setters.

---

## STEP 2 — Completeness failure modes (these cause **MISSED** setters)

Audit each. For every one, decide whether it could have fired in this run, and if so, find
the concrete instances.

1. **Depth/path caps in the reachability confirm (Stage 4c).**
   `max_depth=16`, `max_paths=64` in `enumerate_cpp_paths`; `max_len`/`max_routes` in
   `route.routes`. A prior audit (`docs/2026-06-23-traversal-reaudit.md`, finding NEW‑05)
   notes the corpus max function‑depth is *16 exactly* → **zero headroom**: a setter at
   depth 17 is dropped. **Decisive test:** re‑run with the caps raised (see Step 6, Test C).

2. **`_ENTRY_FANOUT_CAP = 64` in `vbt/reach/cpp_routes.py`.** When an entry/global symbol
   on the path is owned by >64 files, the unified fn‑graph **omits those edges**, which can
   make a genuinely reachable setter appear unreachable (NEW‑07). Find any path that must
   cross a >64‑owner symbol.

3. **Dense‑graph DFS stale‑stop.** `enumerate_cpp_paths` falls back to best‑first search
   past `_DFS_LEX_BUDGET` (≈300k visits) and **gives up after `_DFS_STALE_AFTER` (≈500k)
   visits with no new path** — returning *0 paths with `truncated=True`* for a reachable
   setter whose completing paths are few and lexically late (this is the documented "22k"
   bug). Note: the task **ignores the `truncated` flag** and never escalates — so a
   truncated‑to‑zero result silently falls through to the (also bounded) `route.routes`.

4. **`route.routes` cache / bound mismatch.** The in-process and persisted route memo key
   includes `max_routes`, but not `max_len`. If a cached `(parent,child,max_routes)` result
   was computed with a shorter file-hop bound, a later cap-raised audit run can accidentally
   reuse the old bounded result. For Test C, either disable/prevent route-cache preload,
   clear `route._routes_memo`, or make the cache key include the raised `max_len` before
   treating the diff as evidence.

5. **Modifier‑index misses (Stage 2) — the candidate file is never even considered.**
   `midx.files_for` returns nothing for a file that really writes `V` when:
   - a **register‑indirect ASM write** (`MVC 0(R1),…`, `ST R,0(Rn)`) failed to resolve to the
     named field (resolution is best‑effort with a silent `except: pass`);
   - the **`.asm` source was unreadable/moved** (copy‑fragility) so the MVC fallback bailed;
   - a **symbol‑name normalization** variant (`$WK_CMO` vs `WK_CMO`, underscores) produced a
     different key;
   - a C++ field only ever written through a **macro** (`SET_X(...)`) — tree‑sitter can't see
     post‑expansion assignments (only advisory `macro_setter_notes`).
   **Test:** grep the corpus for possible writes to `V`/aliases, discard comments/RHS reads/homonym
   tails after source-write validation, then diff the validated write files against
   `midx.files_for`.

6. **Alias‑resolution misses (Stage 1) — the entire ASM (or C++) setter space is unsearched.**
   `resolve_aliases` returns no counterpart when: the cc `.hpp` field has **no trailing
   comment** (cc‑only fallback), **gen `.hpp` AND `.mac` are both unparseable**, **comment
   consensus** prefix detection fails, or **gen↔ASM normalization** differs (underscore).
   Only `certainty=="high"` aliases are returned. If `softCardValue`'s ASM twin (e.g.
   `LWRPOSFCRDV`) is missing from `targets`, *no ASM setters are searched at all*.
   **Test:** independently re‑derive the alias for each `V` (Step 6, Test B).

7. **`forward_reachable_files` pre‑filter dropping a reachable file (Stage 3).** This set is
   designed to be a **superset** (sound over‑approximation) of truly reachable files, so it
   *should not* drop reachable files — verify that claim on the discrepancies: for any MISSED
   setter, confirm its file IS in `reachable_files`; if not, that's a reachability‑graph bug.

8. **Setter‑detection misses inside a file (Stage 4 detection).**
   - C++: pointer‑chain writes (`p=get(); p->f=…`), macro‑hidden writes, writes via
     out‑params/`memcpy` whose dest member isn't the searched tail.
   - ASM: `MVCL/MVCP/MVCS` are deliberately **not** in `SETTER_INST`; `CVB` excluded
     (writes a register); register‑indirect dest only caught by `find_asm_indirect_dest_sites`.

9. **DB not fully precomputed (Stage 0).** If `index.db` is missing a *REQUIRED* artifact
   (`modifier_index`, `name_alias`, `membership`, `file_call_graph`, `cpp_call_edges`,
   `const`), candidate generation is silently degenerate. Run `check_db_readiness.py` first.

---

## STEP 3 — Soundness failure modes (these cause **EXTRA** setters)

1. **Tail‑only over‑collection (C++).** `find_cpp_setters_in_file` matches the **last**
   member‑chain component. Searching `softCardValue` also matches `unrelatedStruct.softCardValue`.
   The `full_paths` suffix‑consistency gate (A3) suppresses this **only when the caller passes a
   qualified `name`** (contains `.`/`->`). For a **bare** variable name, no gate fires — verify
   each reported C++ setter's LHS owner chain actually corresponds to `V` (check `match_scope`:
   `qualified`/`member`/`local`).

2. **Declarations counted as setters.** `int field = x;` is flagged `is_declaration=True` but
   still emitted. Decide per your definition whether a declaration‑initializer counts as a
   "setter"; flag any reported site that is purely a declaration.

3. **Value‑preserving / RMW ASM writes.** `classify_setter()` flags `skip_setter_site` for
   self‑clearing/masked/zero‑mask/nonzero‑displacement writes, and `prior_value_required` for
   RMW (`ED`, `SRP`, `TR`, `MP`, `DP`, self `XC/NC/OC`). Confirm none of these slipped through as
   a "definitive set."

4. **Phantom reachability (Stage 4c soundness).**
   - **File‑level over‑approximation:** when the fn‑graph is unavailable, `route.routes` can fall
     back to *file* reachability — the file is reachable but the specific setter **function** may
     not be. Confirm a real **function‑level** path exists.
   - **Entry‑name fan‑out over‑connection:** edges synthesized to all owners of a global name can
     create a path that doesn't exist in the real call graph.
   - **ASM single‑entry collapse:** an ASM module is modeled as one node `(stem,stem)`; a path
     "through" it may use the wrong internal entry.

5. **Mis‑attribution.** C++ caller attribution can resolve to `(global)` when a function body is
   truncated at an unresolved‑type `switch`; the code re‑attributes via nearest‑preceding‑start,
   but verify the reported `function`/`line` actually contains the write.

6. **Wrong alias bleed‑through.** A medium/low‑certainty or namespace‑colliding alias could pull
   in setters of a *different* variable that happens to share a tail/field name. Confirm every
   reported setter writes **this** variable's storage, not a homonym.

7. **ASM-entry reachability over-approximation.** For an ASM entry the task **drops** the `function`
   argument (`func_arg = function if file_type=="cpp" else None`) — reachability is computed from the
   *whole module*, not the specific block. If the real entry is one block inside a multi-entry ASM
   module, paths reachable only from *other* entry points of that module are wrongly counted → EXTRA.
   Confirm the validated path actually originates at the intended block.

---

## STEP 4 — Build the independent oracle (do not reuse the task's logic)

For each variable `V` (and its independently‑derived aliases), build a ground‑truth setter set
by a path that does **not** share the task's candidate or reachability decisions:

- **Independent candidate set:** `grep`/ripgrep the full corpus for writes to `V` and aliases —
  C++ (`<tail>\s*(=|\+=|-=|\*=|/=|\|=|&=|\^=|<<=|>>=|\+\+|--)`, destination writes through
  `memcpy/memmove/memset/strcpy/strncpy/bcopy/bzero/sprintf/snprintf`, and macro call sites
  whose definitions write the field); ASM (operands referencing the field/DSECT label under
  `SETTER_INST` opcodes, plus register‑indirect destinations resolved by an independent
  backward register walk). Record file, line, enclosing function/block.
- **Independent reachability candidate search:** from `stem::function`, walk the raw graph inputs
  (`file_call_graph.json` / DB equivalent plus C++ intra-file call edges) **without** the
  production `max_depth`/`max_paths`/`fanout` caps. This unbounded walk produces **candidate
  paths only**; because the metadata file graph is an over-approximation, it cannot by itself
  prove reachability.
- **Hop-by-hop path validation (find one, do NOT enumerate all):** you only need to prove the
  *existence* of a single valid path, not all of them — and an all-paths walk over 221 vars ×
  candidates × 22k files will never finish. For each candidate destination take the **shortest**
  path first (BFS over the metadata graph), validate it hop-by-hop, and only try the next-shortest
  if it fails. Put a finite cap on validation attempts per destination (for example, the shortest
  25 metadata paths or 10 minutes of wall time); if no path validates within that cap, label the
  candidate `candidate`/`unverified`, not confirmed. **Memoize reachability per destination node**
  so variables don't re-walk the graph.
  Validate each hop **against source wherever possible** — the actual call-site text and the actual
  enclosing-function boundaries are the only truly independent check; fall back to a resolver/metadata
  artifact only when source can't settle it, and flag that dependency (the resolver is partly what's
  under test). Each hop must satisfy: the C++ caller function actually contains the call line; the
  callee resolves to the claimed destination function/file; ASM `target_module`/entry ownership
  matches; no hop relies solely on broad entry-name fan-out without source evidence; and same-file
  C++ reachability is **function**-accurate, not just file-accurate. A path that is only file-level
  reachable is **not** proof.
- The oracle's reachable‑setter set for `V` = candidates that are real writes (Step 3 rules) AND
  have at least one validated path.

Then **diff** oracle vs task output:
`MISSED = oracle − task`, `EXTRA = task − oracle`, `MIS‑ATTRIBUTED = matched site, differing fields`.

**Mind the oracle's own blind spot.** `MISSED = oracle − task` only catches misses the *oracle
itself* found; a setter missed by **both** the grep-oracle and the task is invisible to this diff.
So treat the **candidate universe = grep-oracle ∪ production-output ∪ cap-raised-rerun (Test C)**
and run confirmation over that whole union. Test C matters precisely because it reuses the task's
*richer* detectors (register-indirect resolution, implicit-write macros like
`GETCC`/`DETAC`/`DBSPA`/`TMSMA`, member-chain matching) that a naive grep will not replicate — so
it surfaces real-write candidates the grep oracle would never generate. The three sources are
complementary, not redundant; the more of the union you confirm, the smaller the residual unknown.

---

## STEP 5 — Scale strategy for 221 variables

Hand‑reading every site is infeasible; combine cheap full‑coverage checks with deep dives on suspects:

- **All 221 (cheap, structural):** run Test A (grep vs `midx`) and Test B (alias re‑derivation) —
  these flag candidate/alias *misses* across the whole set fast.
- **All 221 (decisive, executable):** run Test C (cap‑raised differential re‑run) and diff — any
  setter that appears only with raised caps is a high‑priority candidate, then confirm it with
  Test D path validation and Test E source-write validation.
- **Deep manual dives:** every variable with **0 reported setters** (prime suspect for alias/index
  miss), every variable whose reported count changed under Test C, the **top‑N by reported count**
  (prime suspect for over‑collection/soundness), plus a random sample of ~15 of the rest. If a
  variable is not fully soundness-reviewed, do not mark it `OK`; use `no issue found in sampled
  checks` or `not fully soundness-reviewed`.

---

## STEP 6 — Executable tests to run

**Test 0 — DB readiness and DB-only parity.** Use the repo virtualenv unless you have already
confirmed another interpreter has the VBT dependencies installed. Use the `KB_ID` from the
input block:
`env/bin/python3 check_db_readiness.py --job-id "$KB_ID"` and, if available,
`env/bin/python3 -m vbt.precompute.verify_db --job-id "$KB_ID"`. For reproducing the original
DB-only task output, require the required artifacts **and** the speedup/stem artifacts used by
the task (`asm_setter_map:%`, `cpp_setter_map:%`, `cpp_file_writes:%`, `fn_graph_adj`,
`fn_facts`, `reverse_adj`, `forward_file_adj`, CFG blobs). `READY‑WITH‑WARNINGS` is acceptable
only for a separate audit mode that intentionally permits live-source fallback; label that mode
clearly and record every fallback, because source drift can change the result.

**Test A — modifier‑index completeness.** For each `V`+aliases, compare source-validated
write-site files from corpus‑wide grep against `midx.files_for(name, lang)`. Do not report raw
grep hits as Stage‑2 misses until you have discarded comments, RHS-only reads, declarations that
do not write storage under the audit definition, unrelated homonym tails, and macro definitions
without a confirmed call site. Report every validated write file that `midx` omits (→ Stage‑2
miss, bucket §2.5).

**Test B — alias re‑derivation.** Independently determine each `V`'s cross‑language counterpart
from source-grounded evidence first: gen `.hpp`/`.mac`, `cc*.hpp` comments, byte offsets, and
comment consensus. Then compare that source-derived alias set against both the `index.db`
`name_alias` artifact and `resolve_aliases(V).aliases`. Do not use `name_alias` as the oracle for
this test, because the artifact is part of what you are auditing. Report any source-derived
counterpart the task failed to produce (→ §2.6). Also confirm the load‑only `name_alias` artifact
validated (else it fell back to full‑corpus build — results should be identical, but note it).

**Test C — cap‑raised differential re‑run (the decisive suspect generator).** Re‑run the exact
task logic with the caps lifted and bounded checks made much wider:
`enumerate_cpp_paths(..., max_paths=512, max_depth=64)`, raise `route` `max_len`/`max_routes`,
raise `_ENTRY_FANOUT_CAP` (note: only takes effect if you **rebuild** the fn-graph live — in
load-only mode the precomputed `fn_graph_adj` blob already baked in cap=64), optionally raise the
dense-graph budgets (`_DFS_STALE_AFTER`/`_DFS_HARD_CAP`), and **prevent stale `route_cache` reuse**
(don't preload it; clear `route._routes_memo` whenever `max_len` changes — the memo key omits
`max_len`). **Pin the run** so the diff isolates caps from drift: use the **same `index.db`**
(record its hash/path), the **same entry point**, and the **saved production 221-variable output**,
and change *only* the caps. This repo includes **`verify_reachable_setters_capraised.py`** at the
repo root; use it as the ready-to-run harness for a drift-free "vs harness-prod-cap" diff:

```bash
# Use the values from INPUTS TO FILL.
env/bin/python3 verify_reachable_setters_capraised.py \
  --job-id "$KB_ID" --stem "$ENTRY_STEM" --function "$ENTRY_FUNCTION" \
  --baseline "$PRODUCTION_OUTPUT_JSON" \
  --blueprint-dir "$BLUEPRINT_DIR" --asm-dir "$ASM_DIR" \
  --out "$CAPRAISED_OUT"
```

The script writes JSON with these top-level keys: `inputs`, `caps`, `baseline`,
`harness_prod_caps`, `raised_caps`, `diffs`, `zero_reported_setters`, and
`elapsed_seconds`. Use `diffs.new_vs_baseline`, `diffs.gone_vs_baseline`, and
`diffs.changed_counts_vs_baseline` as the suspect list for validation.
Setter identity is normalized as `file_stem | language | line | function | code`.

If that harness is unexpectedly absent, do **not** stop or guess, and do **not** patch production code. Create a
temporary audit-only copy of `find_reachable_setters.py` (or monkeypatch it in a scratch script) that
changes only the caps above, constructs `RouteEngine(..., max_routes=<raised>, max_len=<raised>)`,
skips `preload_route_cache`, clears `route._routes_memo` before raised-route checks, and writes
normalized JSON comparable to the saved production output. State clearly in the report that Test C
used a temporary harness, include the exact command and diff script, and mark any harness-only
diagnostic buckets as `unavailable` unless you implemented them explicitly.

Every new setter is a **candidate false negative**. It becomes a **confirmed** false negative only
after Test D validates a real path and Test E validates a real write of this variable's storage. If
using the provided cap-raised harness, use its per-candidate cap/fan-out/budget buckets, validate
`routes_only_filelevel_SUSPECT` candidates first (found only via file/route-level reachability, never
via a function-level path), and inspect `gone_vs_baseline` for possible production false positives
caused by stale bounded cache. If using a temporary fallback harness, the minimum required output is
`new_vs_baseline` and `gone_vs_baseline`; bucket root causes manually during Test D/E validation.

**Test D — unbounded reachability for each MISSED candidate.** For each candidate the production
run dropped, confirm with an unbounded graph walk **plus hop-by-hop validation** whether a real
path from `stem::function` exists. If yes and the source write is real → confirmed MISS
(caps/fanout/cache/pre-filter/etc.). If no → correctly excluded or only metadata-reachable. If the
path search hits the finite validation cap from Step 4, keep the finding as `candidate`, not
confirmed.

**Test E — per‑reported‑setter soundness.** For each setter the task reported, open the source at
`file_stem:line` and confirm (a) it is a real write of **this** variable's storage (apply Step 3
rules: not a homonym tail, not a bare declaration, not a value‑preserving/RMW op), and (b) a
concrete function‑level path exists from the entry. Anything failing either → EXTRA.

**Test F — full‑trace oracle cross‑check (sample).** The reachable‑setters task is the lightweight
counterpart to the full VBT lineage trace. For ~5 variables (include `softCardValue` if present),
run the full trace (or use existing local trace artifacts such as `vbt/_out_softCardValue*.json` or
`vbt/UNLIMITED_TRACE_softCardValue.md`, if present) and confirm the reachable‑setters output is a
subset of / consistent with the full trace's setter set.

---

## STEP 7 — Required output

Produce a report with:

1. **Per‑variable table:** `variable | aliases_found | reported | oracle_reachable | MISSED | EXTRA | MIS‑ATTRIBUTED | verdict (OK / under‑reports / over‑reports / both / no issue found in sampled checks / not fully soundness-reviewed)`.
2. **For every discrepancy**, a row: `variable | site (file:line:fn) | classification | root‑cause bucket (one of §2.x / §3.x above) | evidence (the source line + the path or the failing check)`.
3. **Root‑cause rollup:** counts of discrepancies per bucket, so I know whether the dominant
   problem is depth caps, fan‑out, alias misses, modifier‑index misses, or over‑collection.
4. **Confidence note** per finding: `confirmed` only when both source-write validation and
   hop-by-hop path validation succeeded; `candidate` when surfaced by Test C or grep but not
   independently validated; `suspected` when evidence is partial. Include an explicit list of
   anything you could not verify and why.

For each confirmed or suspected discrepancy, include this evidence block:

```text
variable:
site:
source-write verdict:
source line:
validated path:
production result:
cap-raised result:
classification:
bucket:
confidence:
why not lower confidence:
```

If there is no validated path, write `validated path: none within cap` and do not mark the
finding `confirmed`.

Be skeptical and concrete: cite `file:line`, show the source line, and show the path (or the
absence of one). Default to "needs evidence" over "looks fine."

---

## Reference — caps, knobs, and required artifacts

| Knob / artifact | Where | Default | Why it matters |
|---|---|---|---|
| `max_depth` (fn‑hops) | task call to `enumerate_cpp_paths` | **16** | corpus max depth ≈16 → false negatives at the edge |
| `max_paths` | same | **64** | truncates path enumeration |
| `_ENTRY_FANOUT_CAP` | `vbt/reach/cpp_routes.py` | **64** | drops edges through >64‑owner global symbols |
| `_DFS_LEX_BUDGET` / `_DFS_HARD_CAP` / `_DFS_STALE_AFTER` | `vbt/reach/cpp_routes.py` | 300k / 5M / 500k | dense‑graph stale‑stop → 0 paths for reachable setters |
| `max_len` (file‑hops) / `max_routes` | `RouteEngine` (`vbt/reach/route.py`) | ~16 / 200 | the fallback check is also bounded |
| `VBT_BFS_FOREST` | env | on for job_id traces | DFS caller forest can drop shallow edges |
| `VBT_PATHS_CACHE_MAX`, `VBT_ROUTES_MEMO_MAX` | env | 16384 / 32768 | cache sizes; route memo key includes `max_routes` but not `max_len` |
| REQUIRED artifacts | `index.db` | — | `file_call_graph`, `route_name_to_stems`, `cpp_call_edges`, `name_alias`, `membership`, `const`, `modifier_index` |
| Speedup/stem artifacts | `index.db` | — | `reverse_adj`, `forward_file_adj`, `fn_graph_adj`, `fn_facts`, `asm_setter_map`, `cpp_setter_map`, `cpp_file_writes`, `vbt_cfg_blob` |
