"""DB-only LCA-feasibility dependency lineage (vbt/depvars/lca_lineage.py).

The originally-intended recursive lineage semantics:

  1. Input: a variable + an ENTRY endpoint (stem / file_type / function).
  2. Per setter site: the LCA of (setter function, entry function) over the function
     graph. NO common ancestor => the setter is INFEASIBLE. With an LCA, the setter is
     feasible only if it is reached BEFORE the entry from that LCA (static call-site
     order) — i.e. by the time execution reaches the entry, the setter has already fired.
  3. Feasible setters get SETTER-LOCAL conditions + dependent variables (no cross-file
     route guards — no route enumeration, no caller forests).
  4. Each dependent variable recurses with entry = the (function, read line) it was
     collected from. Recursion order is DFS by default — each root→…→terminal chain is
     completed before its siblings, so a ``max_dep_vars`` budget on a huge corpus yields
     finished chains (more TERMINAL variables) instead of an unfinished breadth frontier;
     ``traversal="bfs"`` restores level-order.

STRICTLY ``index.db`` ONLY (mirrors ``vbt.lca_trace`` / ``vbt.setter_order``): setter maps,
fn-graph, resolvers, modifier index, ASM blueprint BLOBS and C++ cfg BLOBS all come from DB
artifacts. A cfg/blueprint blob miss degrades that setter to ``conditionsAvailable: false``
plus a warning — NEVER a live cfg_extract subprocess, source read, or blueprint JSON read.

Ordering is STATIC call-site line order from the LCA, not observed runtime order (same
disclaimer as ``vbt.setter_order``): ``semantics.runtimeProof`` is always False.
"""
from __future__ import annotations

import logging
import os
import sys
import time
from collections import Counter, deque
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple

from vbt.interfaces import Condition, SetterSite
from vbt.precompute import db_artifacts as DA
from vbt.lca_trace import (
    Node, DbArtifactMissing,
    _node_id, _reverse_adjacency, _require, _attribute_cpp, strict_load_resolvers,
)
from vbt.precompute.chain_facts_db import (
    ASM_SETTERS_FULL_COVERAGE_ARTIFACT, CPP_SETTER_MAP_COVERAGE_ARTIFACT,
    COVERAGE_VERSION, EMPTY, FAILED,
    set_asm_setters_full_job, get_asm_setters_full, load_coverage,
)
from vbt.precompute.graph_db import FN_GRAPH_ADJ_ARTIFACT, REVERSE_ADJ_ARTIFACT

# --------------------------------------------------------------------------- #
# progress logging (mirrors vbt/engine.py): the shared "vbt" root gets ONE stderr
# handler with the [vbt {ms}] prefix (idempotent — engine may have attached it
# already); ``progress=True`` raises the level to INFO (VBT_HANG_DEBUG=1 → DEBUG,
# the before-each-op trace that names the exact stuck call). Default WARNING ⇒
# every _log/_dbg below is a no-op and the trace pays nothing.
# --------------------------------------------------------------------------- #
_VBT_LOG = logging.getLogger("vbt")
if not _VBT_LOG.handlers:
    _h = logging.StreamHandler(sys.stderr)
    _h.setFormatter(logging.Formatter("[vbt %(relativeCreated)8.0fms] %(message)s"))
    _VBT_LOG.addHandler(_h)
    _VBT_LOG.propagate = False
logger = logging.getLogger("vbt.lca_lineage")


def _log(msg: str, *args) -> None:
    if logger.isEnabledFor(logging.INFO):
        logger.info(msg, *args)


def _dbg(msg: str, *args) -> None:
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug(msg, *args)


class _Phase:
    """START/DONE + elapsed for one setup phase (no-op below INFO)."""

    def __init__(self, name: str):
        self.name = name
        self.t0 = 0.0

    def __enter__(self):
        if logger.isEnabledFor(logging.INFO):
            self.t0 = time.perf_counter()
            logger.info("START %s", self.name)
        return self

    def __exit__(self, *exc):
        if logger.isEnabledFor(logging.INFO):
            logger.info("DONE  %s (%.3fs)", self.name, time.perf_counter() - self.t0)
        return False


SCHEMA_VERSION = 1

# Scale gate for the common-ancestor PRE-FILTER (exact, output-identical): when a variable
# has at least this many distinct setter fn-nodes, compute ONE forward closure of the
# entry's ancestor cone — "s shares an ancestor with e" ⟺ "s ∈ descendants(ancestors(e))"
# — and reject no-lca setters by O(1) membership instead of a per-setter ancestor BFS.
# Below the gate the per-setter BFS cones are cheaper than the one big closure.
_CONE_PREFILTER_MIN_NODES = 16

# --------------------------------------------------------------------------- #
# cross-request corpus cache: the fn-graph blob + its derived structures are the
# dominant per-request setup cost and are immutable between precompute runs. Keyed
# by the manifest rows (version, source_hash, built_at) of every artifact the
# bundle is derived from, so a precompute rerun invalidates it. Everything cached
# is READ-ONLY in this module. FIFO-bounded (a worker typically serves 1-2 kbs).
# --------------------------------------------------------------------------- #
_CORPUS_CACHE: Dict[str, Tuple[Tuple, Dict[str, Any]]] = {}
_CORPUS_CACHE_MAX = 2
_CORPUS_FP_ARTIFACTS = (FN_GRAPH_ADJ_ARTIFACT, REVERSE_ADJ_ARTIFACT,
                        CPP_SETTER_MAP_COVERAGE_ARTIFACT, ASM_SETTERS_FULL_COVERAGE_ARTIFACT)


def _corpus_fingerprint(job_id: str) -> Tuple:
    rows = []
    for art in _CORPUS_FP_ARTIFACTS:
        row = DA.read_manifest(job_id, art) or {}
        rows.append((art, row.get("version"), row.get("source_hash"), row.get("built_at")))
    return tuple(rows)

_SEMANTICS: Dict[str, Any] = {
    "feasibility": "lca-first-arrival",     # setter must arrive before entry from the LCA
    "lca": "nearest-common-ancestor-by-bfs-distance",
    "order": "static-call-site-line-order",
    "noLca": "infeasible",                  # no common ancestor => setter dropped as infeasible
    "lcaPath": "shortest-witness-by-hops",  # ONE shortest call path per leg, not all paths
    "runtimeProof": False,
}


# --------------------------------------------------------------------------- #
# per-request corpus context: armed DB-only lookups + memos
# --------------------------------------------------------------------------- #
class _Ctx:
    def __init__(self, job: str, bp: Path, src: Path,
                 adj: Dict[Node, Set[Tuple[str, str, int, bool]]],
                 node_types: Dict[str, str], graph_nodes: Set[Node],
                 cpp_cov: Dict[str, str], asm_cov: Dict[str, str], midx,
                 warnings: List[Dict[str, Any]], max_order_nodes: int,
                 bp_override_ok: bool = False,
                 rev: Optional[Dict[Node, Set[Node]]] = None):
        self.job = job
        self.bp = bp
        self.src = src
        # True iff the DB blueprint override is serving load_json — required for ASM
        # conditions (collect_asm_conditions loads CFG maps via load_json(bp_path));
        # without it that call would fall through to a DISK read, which is forbidden here.
        self.bp_override_ok = bp_override_ok
        self.adj = adj
        self.rev = rev if rev is not None else _reverse_adjacency(adj)
        self.node_types = node_types
        self.graph_nodes = graph_nodes
        self.cpp_cov = cpp_cov
        self.asm_cov = asm_cov
        self.midx = midx
        self.warnings = warnings
        self.max_order_nodes = max_order_nodes
        self.truncated = False
        # ---- memos (per request) ----
        self._anc: Dict[Node, Dict[Node, int]] = {}          # node -> {ancestor: bfs distance}
        self._anc_next: Dict[Node, Dict[Node, Node]] = {}    # node -> {ancestor: next hop TOWARD node}
        self._lca: Dict[Tuple[Node, Node], Optional[Node]] = {}
        self._order: Dict[Tuple[Node, Node, Node], Tuple[Optional[int], Optional[int]]] = {}
        self._cfg_fns: Dict[str, Optional[List[Dict]]] = {}  # cpp stem -> cfg fns | None (blob miss)
        self._asm_bp: Dict[str, Optional[Dict]] = {}         # asm stem -> blueprint dict | None
        self._asm_consts: Dict[str, Set[str]] = {}
        self._alias: Dict[Tuple[str, str], List[Tuple[str, str]]] = {}
        self._setters: Dict[Tuple[str, str], Tuple[Dict[Node, List[SetterSite]], int]] = {}
        self._warned: Set[Tuple[str, str]] = set()
        # sorted adjacency memos: BFS/DFS re-visit the same nodes across many
        # setter/entry pairs — sort each node's caller/callee list ONCE, not per run.
        self._rev_sorted: Dict[Node, List[Node]] = {}
        self._fwd_sorted: Dict[Node, List[Tuple[int, str, Node]]] = {}
        # per (frm, target) call-site lines toward target (the ancestor-path bounds)
        self._sites_toward: Dict[Tuple[Node, Node], List[int]] = {}
        # per SETTER SITE (conditions, available, dep vars): entry-INDEPENDENT, so a
        # variable recurring at N read-site entries computes each site's facts once.
        self._site_facts: Dict[Tuple, Tuple[List[Condition], bool, list]] = {}
        # entry node -> descendants(ancestors(entry)) — the no-lca pre-filter cone
        self._entry_cone: Dict[Node, Set[Node]] = {}
        # observability counters (logged in the end-of-run summary; never in the payload)
        self.counters: Counter = Counter()

    def rev_sorted(self, node: Node) -> List[Node]:
        hit = self._rev_sorted.get(node)
        if hit is None:
            hit = self._rev_sorted[node] = sorted(self.rev.get(node, ()))
        return hit

    def fwd_sorted(self, node: Node) -> List[Tuple[int, str, Node]]:
        """Outgoing calls of ``node`` as (line, callee-id, callee) sorted in call-site
        line order — the DFS visit order, computed once per node."""
        hit = self._fwd_sorted.get(node)
        if hit is None:
            hit = self._fwd_sorted[node] = sorted(
                (int(line or 0), _node_id(cs, cf, self.lang(cs)), (cs, cf))
                for (cs, cf, line, _cross) in self.adj.get(node, ()))
        return hit

    def _warn_once(self, code: str, file: str) -> None:
        if (code, file) in self._warned:
            return
        self._warned.add((code, file))
        self.warnings.append({"code": code, "file": file})

    def lang(self, stem: str) -> str:
        return self.node_types.get(stem, "asm")

    # ---- ancestors with BFS distance (nodes that can REACH ``node``, incl. itself) ----
    def ancestors(self, node: Node) -> Dict[Node, int]:
        hit = self._anc.get(node)
        if hit is not None:
            self.counters["anc_bfs_hits"] += 1
            return hit
        self.counters["anc_bfs_runs"] += 1
        _dbg("    ancestors: BFS from %s...", _node_id(node[0], node[1], self.lang(node[0])))
        dist: Dict[Node, int] = {node: 0}
        # next[a] = the node a was discovered THROUGH = a's next hop toward ``node`` on a
        # shortest (by hops) call path — makes LCA→target witness paths O(hops) to rebuild.
        # Callers iterated SORTED so the chosen parent is stable across processes (set
        # iteration order varies under hash randomization; distances don't care, paths do).
        nxt: Dict[Node, Node] = {}
        dq: deque = deque([node])
        while dq:
            cur = dq.popleft()
            d = dist[cur] + 1
            for caller in self.rev_sorted(cur):
                if caller not in dist:
                    dist[caller] = d
                    nxt[caller] = cur
                    dq.append(caller)
        self._anc[node] = dist
        self._anc_next[node] = nxt
        _dbg("    ancestors: cone of %s = %d nodes",
             _node_id(node[0], node[1], self.lang(node[0])), len(dist))
        return dist

    def entry_cone(self, e: Node) -> Set[Node]:
        """descendants(ancestors(e)) — EXACTLY the nodes that share ≥1 common ancestor
        with ``e`` (w→s and w→e ⟺ s is a forward-descendant of some member of anc(e);
        anc(e) includes e itself, so the cone also contains e's own descendants). One
        multi-source forward BFS per entry, memoized; used as the scale-gated no-lca
        pre-filter."""
        hit = self._entry_cone.get(e)
        if hit is not None:
            return hit
        self.counters["entry_cone_runs"] += 1
        _dbg("    entry_cone: forward closure from anc(%s)...",
             _node_id(e[0], e[1], self.lang(e[0])))
        cone: Set[Node] = set(self.ancestors(e))
        dq: deque = deque(cone)
        while dq:
            cur = dq.popleft()
            for (cs, cf, _l, _c) in self.adj.get(cur, ()):
                child = (cs, cf)
                if child not in cone:
                    cone.add(child)
                    dq.append(child)
        self._entry_cone[e] = cone
        _dbg("    entry_cone: %d nodes", len(cone))
        return cone

    def path_from(self, start: Node, target: Node) -> List[Node]:
        """Shortest-witness call path ``start → … → target`` (inclusive), following the
        parent pointers recorded by ``ancestors(target)``. ``start`` must be an ancestor
        of ``target`` (callers assert this by construction: start is their LCA)."""
        self.ancestors(target)                      # ensure the parent map exists
        nxt = self._anc_next[target]
        hops = [start]
        cur = start
        while cur != target:
            cur = nxt[cur]
            hops.append(cur)
        return hops

    # ---- C++ cfg fns from the cfg BLOB tier only (stat-only key; NEVER a subprocess) ----
    def cfg_fns(self, stem: str) -> Optional[List[Dict]]:
        if stem in self._cfg_fns:
            return self._cfg_fns[stem]
        _dbg("    cfg_fns: cfg blob read for %s...", stem)
        fns: Optional[List[Dict]] = None
        try:
            from vbt.cpp_frontend import wrapper as W
            cpp_path = str(self.src / f"{stem}.cpp")
            parse_flags = list(W.DEFAULT_PARSE_FLAGS)
            sdk = W._detect_sdk_isysroot()
            if sdk:
                parse_flags += ["-isysroot", sdk]
            parse_flags += ["-I", os.path.dirname(os.path.abspath(cpp_path))]
            key = W._cache_key(cpp_path, W.DEFAULT_BINARY, parse_flags)
            payload = DA.read_cfg_blob(self.job, key)
            fns = DA.loads_gz(payload) if payload is not None else None
        except Exception:
            fns = None
        self.counters["cfg_blob_miss" if fns is None else "cfg_blob_hit"] += 1
        if fns is None:
            self._warn_once("cfg_blob_miss", stem)
        self._cfg_fns[stem] = fns
        return fns

    # ---- ASM blueprint from its DB blob only ----
    def asm_bp(self, stem: str) -> Optional[Dict]:
        if stem in self._asm_bp:
            return self._asm_bp[stem]
        _dbg("    asm_bp: blueprint blob read for %s...", stem)
        payload = DA.read_blob(self.job, f"bp:{stem}.asm.json")
        bp = DA.loads_gz(payload) if payload is not None else None
        self.counters["bp_blob_miss" if bp is None else "bp_blob_hit"] += 1
        if bp is None:
            self._warn_once("blueprint_blob_miss", stem)
        self._asm_bp[stem] = bp
        return bp

    def asm_consts(self, stem: str) -> Set[str]:
        hit = self._asm_consts.get(stem)
        if hit is not None:
            return hit
        from backward_traversal.utils.blueprint_utils import collect_constant_symbols
        bp = self.asm_bp(stem)
        # asm_file=None: symbols come from the blueprint dict only — the source-scan
        # fallback would be a disk read, which this module forbids.
        consts = collect_constant_symbols(bp, None, bp_path=Path(f"db:{stem}.asm.json")) if bp else set()
        self._asm_consts[stem] = consts
        return consts


# --------------------------------------------------------------------------- #
# LCA + first-arrival order (pure graph functions on the ctx memos)
# --------------------------------------------------------------------------- #
def _find_lca(ctx: _Ctx, setter_node: Node, entry_node: Node,
              *, use_cone: bool = False) -> Optional[Node]:
    """Nearest common ancestor of the two nodes by combined BFS distance (deterministic
    tie-break by node id). For a tree this IS the LCA; for a DAG it is the closest join.
    Returns None when the nodes share NO common ancestor (=> infeasible).

    ``use_cone`` (scale gate): reject the no-lca case by O(1) membership in the entry's
    precomputed cone BEFORE paying the setter's ancestor BFS — exact, verdict-identical
    (s ∉ descendants(anc(e)) ⟺ anc(s) ∩ anc(e) = ∅)."""
    key = (setter_node, entry_node)
    if key in ctx._lca:
        return ctx._lca[key]
    if use_cone and setter_node not in ctx.entry_cone(entry_node):
        ctx.counters["cone_prefilter_rejects"] += 1
        ctx._lca[key] = None
        return None
    anc_s = ctx.ancestors(setter_node)
    anc_e = ctx.ancestors(entry_node)
    # iterate the smaller set for the intersection
    small, big = (anc_s, anc_e) if len(anc_s) <= len(anc_e) else (anc_e, anc_s)
    best: Optional[Tuple[int, str, Node]] = None
    for n, d_small in small.items():
        d_big = big.get(n)
        if d_big is None:
            continue
        cand = (d_small + d_big, _node_id(n[0], n[1], ctx.lang(n[0])), n)
        if best is None or cand < best:
            best = cand
    lca = best[2] if best is not None else None
    ctx._lca[key] = lca
    return lca


def _first_arrival(ctx: _Ctx, lca: Node, setter_node: Node, entry_node: Node
                   ) -> Tuple[Optional[int], Optional[int]]:
    """First-arrival preorder index of ``setter_node`` and ``entry_node`` in an ordered
    DFS from ``lca`` (call sites in line order; descent pruned to nodes that can still
    reach either target). ``None`` = not reached before the node cap."""
    key = (lca, setter_node, entry_node)
    hit = ctx._order.get(key)
    if hit is not None:
        return hit
    ctx.counters["order_dfs_runs"] += 1
    _dbg("    order: DFS from LCA %s (setter %s vs entry %s)...",
         _node_id(lca[0], lca[1], ctx.lang(lca[0])),
         _node_id(setter_node[0], setter_node[1], ctx.lang(setter_node[0])),
         _node_id(entry_node[0], entry_node[1], ctx.lang(entry_node[0])))
    anc_s = ctx.ancestors(setter_node)
    anc_e = ctx.ancestors(entry_node)
    targets = {setter_node, entry_node}
    found: Dict[Node, int] = {}
    visited: Set[Node] = set()
    counter = 0
    stack: List[Node] = [lca]
    while stack and len(found) < len(targets):
        if counter >= ctx.max_order_nodes:
            ctx.truncated = True
            break
        node = stack.pop()
        if node in visited:
            continue
        visited.add(node)
        if node in targets:
            found[node] = counter
        counter += 1
        # children in call-site line order (pre-sorted once per node); pruned to nodes
        # that can reach a target. Pushed reversed so the stack pops in line order.
        kids = [child for (_line, _nid, child) in ctx.fwd_sorted(node)
                if (child in anc_s or child in anc_e) and child not in visited]
        stack.extend(reversed(kids))
    res = (found.get(setter_node), found.get(entry_node))
    ctx._order[key] = res
    return res


def _call_sites_toward(ctx: _Ctx, frm: Node, target: Node) -> List[int]:
    """Call-site lines in ``frm`` whose callee can still reach ``target`` (callee is one of
    the target's ancestors, or the target itself — target ∈ its own ancestor set).
    Memoized per (frm, target): the same bound is asked for every setter SITE in a fn."""
    key = (frm, target)
    hit = ctx._sites_toward.get(key)
    if hit is None:
        target_anc = ctx.ancestors(target)
        hit = ctx._sites_toward[key] = [
            int(line or 0) for (cs, cf, line, _cross) in ctx.adj.get(frm, ())
            if (cs, cf) in target_anc]
    return hit


def _feasibility(ctx: _Ctx, setter_node: Node, setter_line: int,
                 entry_node: Node, entry_line: Optional[int],
                 *, use_cone: bool = False
                 ) -> Tuple[Optional[Node], bool, str]:
    """(lca, feasible, reason) for one setter site against one entry.

    Feasible = the setter can have fired by the time the entry is reached (root entry:
    by/while the entry executes). INFEASIBLE: no common ancestor at all (no-lca), an
    entry-first sibling branch under the LCA, or a line-provable too-late site."""
    if setter_node == entry_node:
        if entry_line is None:
            return setter_node, True, "same-function-as-entry"
        if setter_line < entry_line:
            return setter_node, True, "same-function-line-order"
        return setter_node, False, "same-function-after-entry-line"
    lca = _find_lca(ctx, setter_node, entry_node, use_cone=use_cone)
    if lca is None:
        return None, False, "no-lca"
    if lca == setter_node:
        # setter's fn is an ANCESTOR of the entry: it fires on the way in, feasible unless
        # the setter line provably comes AFTER the LATEST descent toward the entry (latest
        # site = most permissive, mirroring _prefix_guards' descend-bound convention).
        sites = _call_sites_toward(ctx, setter_node, entry_node)
        if not sites or setter_line <= max(sites):
            return lca, True, "setter-on-path-to-entry"
        return lca, False, "setter-after-descent-to-entry"
    if lca == entry_node:
        # entry's fn is an ANCESTOR of the setter: the setter runs via calls the entry
        # makes. Root entry (no line) => feasible — the entry's execution is exactly what
        # reaches it. Dep-var entry (read line known) => the descent must START before the
        # read (earliest site = most permissive).
        if entry_line is None:
            return lca, True, "downstream-of-entry"
        sites = _call_sites_toward(ctx, entry_node, setter_node)
        if sites and min(sites) < entry_line:
            return lca, True, "downstream-call-before-read"
        return lca, False, "downstream-call-after-read"
    o_s, o_e = _first_arrival(ctx, lca, setter_node, entry_node)
    if o_s is None or o_e is None:
        return lca, False, "order-unresolved"
    if o_s < o_e:
        return lca, True, "setter-before-entry"
    return lca, False, "entry-before-setter"


# --------------------------------------------------------------------------- #
# DB-only setter discovery (mirrors lca_trace._db_only_setter_lca_context's
# discovery loop, allow_unattributed_setters=True semantics: exclude + count)
# --------------------------------------------------------------------------- #
def _discover_setters(ctx: _Ctx, name: str, lang: str, *, strict: bool = True,
                      home_hint: Optional[str] = None
                      ) -> Tuple[Dict[Node, List[SetterSite]], int]:
    """``strict=True`` (the ROOT variable): a coverage hole HARD-FAILS with
    ``DbArtifactMissing`` (same contract as vbt.lca_trace — incomplete precompute must be
    visible, not silent). ``strict=False`` (dep vars): a hole degrades to a warning + skip
    of that stem, so one odd extracted token can't kill the whole trace.

    ``name`` may be a QUALIFIED C++ path (``a.b->field``): the sweep then searches by its
    tail with the full-path filter engaged (``root_fp``), and cross-language aliases are
    resolved from the full path — same fidelity as the root search. ``home_hint`` scopes
    alias resolution (root variable only, mirroring the lca_trace context)."""
    key = (name.upper(), lang)
    hit = ctx._setters.get(key)
    if hit is not None:
        return hit
    from vbt.precompute.cpp_setter_map_db import load_cpp_setters
    from vbt.resolve.name_resolver import resolve as resolve_aliases

    akey = (name.upper(), lang)
    targets = ctx._alias.get(akey)
    if targets is None:
        alias_set = resolve_aliases(name, lang, ctx.src, home_hint=home_hint)
        targets = [(name, lang)] + [(a.name, a.language) for a in alias_set.aliases]
        ctx._alias[akey] = targets
        _log("  aliases of %s (%s): %s", name, lang,
             [t for t in targets[1:]] if len(targets) > 1 else "none")

    by_node: Dict[Node, List[SetterSite]] = {}
    excluded = 0
    stems_swept = 0
    for tname, tlang in targets:
        for stem in sorted(ctx.midx.files_for(tname, tlang)):
            stems_swept += 1
            _dbg("    discover: %s (%s) in stem %s...", tname, tlang, stem)
            if tlang == "cpp":
                status = ctx.cpp_cov.get(stem)
                if status is None or status == FAILED:
                    if strict:
                        raise DbArtifactMissing(
                            f"cpp_setter_map coverage for stem {stem!r} is {status or 'ABSENT'} "
                            f"(kb {ctx.job}) — rerun `python -m vbt.precompute.chain_facts_db {ctx.job}`")
                    ctx._warn_once("setter_coverage_missing", stem)
                    continue
                if status == EMPTY:
                    continue
                tail = tname.split(".")[-1].split("->")[-1]
                root_fp = [tname] if ("." in tname or "->" in tname) else None
                sites = load_cpp_setters(ctx.job, stem, tail, root_fp)
                if sites is None:
                    if strict:
                        raise DbArtifactMissing(
                            f"cpp_setter_map coverage OK for stem {stem!r} but blob missing "
                            f"(kb {ctx.job}) — drift; rerun precompute")
                    ctx._warn_once("setter_blob_missing", stem)
                    continue
                for s in sites:
                    node = _attribute_cpp(stem, s, ctx.graph_nodes)
                    if node is None:
                        excluded += 1
                        ctx._warn_once("unattributed_setter", stem)
                        continue
                    by_node.setdefault(node, []).append(s)
            else:
                status = ctx.asm_cov.get(stem)
                if status is None or status == FAILED:
                    if strict:
                        raise DbArtifactMissing(
                            f"asm_setters_full coverage for stem {stem!r} is {status or 'ABSENT'} "
                            f"(kb {ctx.job}) — rerun `python -m vbt.precompute.chain_facts_db {ctx.job}`")
                    ctx._warn_once("setter_coverage_missing", stem)
                    continue
                if status == EMPTY:
                    continue
                sites = get_asm_setters_full(stem, tname)
                if sites:
                    by_node.setdefault((stem, stem), []).extend(sites)
    _log("  setter discovery %s (%s): %d sites in %d fn-nodes (%d stems swept, %d unattributed excluded)",
         name, lang, sum(len(v) for v in by_node.values()), len(by_node), stems_swept, excluded)
    ctx._setters[key] = (by_node, excluded)
    return by_node, excluded


# --------------------------------------------------------------------------- #
# setter-local conditions + dep vars (blob-only)
# --------------------------------------------------------------------------- #
def _setter_conditions(ctx: _Ctx, node: Node, site: SetterSite
                       ) -> Tuple[List[Condition], bool]:
    """(conditions, available). ``available`` False = the cfg/blueprint blob was absent,
    so guards are UNKNOWN (not proven unconditional)."""
    stem = node[0]
    if site.language == "cpp":
        from vbt.conditions.cpp_conditions import collect_cpp_conditions
        fns = ctx.cfg_fns(stem)
        if fns is None:
            return [], False
        conds = collect_cpp_conditions(ctx.src / f"{stem}.cpp", site.line,
                                       site.function or node[1], functions=fns)
        return conds, True
    from vbt.conditions.asm_conditions import collect_asm_conditions
    bp = ctx.asm_bp(stem)
    if bp is None or not ctx.bp_override_ok:
        return [], False
    # bp_path is the CANONICAL blueprint path: collect_asm_conditions loads its CFG maps
    # via load_json(bp_path), which the installed DB override serves (blob presence was
    # just verified by ctx.asm_bp, so the disk fallback can't fire).
    conds, _trunc = collect_asm_conditions(bp, str(ctx.bp / f"{stem}.asm.json"),
                                           site.block_id, site.line, f"{stem}.asm")
    return conds, True


def _setter_dep_vars(ctx: _Ctx, node: Node, site: SetterSite,
                     conditions: List[Condition], cpp_const_names: Set[str]):
    from vbt.depvars.extract import extract_dep_vars
    consts = ctx.asm_consts(node[0]) if site.language == "asm" else None
    return extract_dep_vars(site, conditions, constant_symbols=consts,
                            cpp_const_names=cpp_const_names, asm_indirect_ctx=None)


def _site_facts(ctx: _Ctx, node: Node, site: SetterSite, cpp_const_names: Set[str]
                ) -> Tuple[List[Condition], bool, list]:
    """(conditions, conditionsAvailable, dep vars) for ONE setter site — entry-independent,
    so it's memoized per site: a variable recurring at N read-site entries (and the same
    site reached via aliases) pays the guard walk + dep-var extraction exactly once."""
    key = (node, site.language, int(site.line or 0), site.block_id, site.instruction)
    hit = ctx._site_facts.get(key)
    if hit is not None:
        ctx.counters["site_facts_hits"] += 1
        return hit
    ctx.counters["site_facts_runs"] += 1
    conds, avail = _setter_conditions(ctx, node, site)
    deps = _setter_dep_vars(ctx, node, site, conds, cpp_const_names)
    hit = ctx._site_facts[key] = (conds, avail, deps)
    return hit


# --------------------------------------------------------------------------- #
# top-level orchestrator
# --------------------------------------------------------------------------- #
def run_lca_lineage(
    precompute_job_id: str,
    variable: str,
    language: str,
    entry: Dict[str, Any],
    *,
    job_id: Optional[str] = None,
    blueprint_dir: Optional[str] = None,
    asm_dir: Optional[str] = None,
    home_hint: Optional[str] = None,
    max_dep_var_depth: int = 1,
    max_dep_vars: int = 500,
    max_setters_per_var: int = 250,
    max_feasible_setters: Optional[int] = None,
    max_order_nodes: int = 20000,
    mode: str = "lca-feasibility",
    traversal: str = "dfs",
    progress: bool = False,
    debug: bool = False,
) -> Dict[str, Any]:
    """variable + entry → LCA-feasible setters → setter-local conditions + dep vars →
    recurse each dep var with entry = its read site. See module docstring. STRICTLY DB-only;
    raises ``DbArtifactMissing`` on a missing required artifact.

    ``mode="lca-feasibility"`` (default) is the behavior above. ``mode="all-setters"``
    SKIPS feasibility entirely: every discovered setter is treated as feasible (gets
    conditions + dep vars + recursion) with no LCA/ancestor-BFS/ordering work at all;
    the entry becomes metadata only (any entry accepted — no graph-membership check).
    Everything else (discovery, site facts, dep-var recursion, dedup, caps) is shared.

    ``traversal="dfs"`` (default) drills each dependency chain to its terminal variables
    before visiting siblings — under a ``max_dep_vars`` budget on a huge corpus this
    maximizes COMPLETED root→…→terminal chains instead of an unfinished breadth frontier.
    ``traversal="bfs"`` processes depth levels in order (the pre-2026-07 behavior; under
    no binding budget both traversals process the same variable set — see the dedup notes
    in the loop). ``max_feasible_setters=N`` stops evaluating a variable's setters once N
    FEASIBLE ones are found (infeasible ones scanned along the way are still emitted);
    unlike ``max_setters_per_var`` — which caps setters EVALUATED and so can cut off
    before any feasible one is seen — this never turns a live variable into a false
    terminal. ``N=1`` = witness mode: one feasible setter per variable, minimum fanout,
    deepest chains per budget.

    ``progress=True`` raises the shared "vbt" logger to INFO (stderr, ``[vbt {ms}]``
    prefix): per-phase setup timings, per-variable setter/feasibility summaries, and an
    end-of-run counter summary. ``VBT_HANG_DEBUG=1`` raises it to DEBUG instead — a
    before-each-operation trace (per-stem discovery, per-BFS/DFS, per-blob read) whose
    LAST line names the exact stuck call if a run ever looks hung. Output-identical
    either way."""
    if mode not in ("lca-feasibility", "all-setters"):
        raise ValueError(
            f"mode must be 'lca-feasibility' or 'all-setters', got {mode!r}")
    if traversal not in ("dfs", "bfs"):
        raise ValueError(f"traversal must be 'dfs' or 'bfs', got {traversal!r}")
    if max_feasible_setters is not None and max_feasible_setters < 1:
        raise ValueError(f"max_feasible_setters must be >= 1, got {max_feasible_setters}")
    all_setters = mode == "all-setters"
    dfs = traversal == "dfs"
    t0 = time.perf_counter()
    if progress:
        _VBT_LOG.setLevel(logging.DEBUG if os.environ.get("VBT_HANG_DEBUG") else logging.INFO)
    bp = Path(blueprint_dir) if blueprint_dir else Path(".")
    src = Path(asm_dir) if asm_dir else Path(".")
    _log("=== lca_lineage: variable=%r language=%s entry=%s kb=%s (%s, depth<=%d, vars<=%d, "
         "setters/var<=%d, feasible/var<=%s) ===", variable, language, entry,
         precompute_job_id, traversal, max_dep_var_depth, max_dep_vars,
         max_setters_per_var, max_feasible_setters if max_feasible_setters else "inf")

    from vbt.setters.cpp_setters import set_cpp_setter_map_job, set_cpp_file_writes_job
    from vbt.setters.asm_setters import set_asm_setter_map_job
    from vbt.precompute.fn_facts_db import set_fn_facts_job

    prev_load_only = DA.is_load_only()
    # clear every global hook at entry (mirrors _db_only_setter_lca_context) so a prior
    # task can't leak overrides in, and this one can't leak DB-only state out.
    try:
        from backward_traversal.utils.blueprint_utils import clear_blueprint_override, clear_source_override
        from vbt.precompute.cfg_db import clear_cfg_db
        from vbt.conditions.cpp_conditions import clear_cpp_conditions_cache
        clear_blueprint_override(); clear_source_override(); clear_cfg_db()
        clear_cpp_conditions_cache()
    except Exception:
        pass
    set_asm_setter_map_job(None); set_cpp_setter_map_job(None)
    set_cpp_file_writes_job(None); set_fn_facts_job(None)
    set_asm_setters_full_job(None)

    warnings: List[Dict[str, Any]] = []
    try:
        DA.set_load_only(True)
        try:
            from api.index_db.engine import get_engine
            get_engine(precompute_job_id)
        except DbArtifactMissing:
            raise
        except Exception as exc:
            raise DbArtifactMissing(f"index.db unavailable for kb {precompute_job_id}: {exc}")

        from vbt.precompute.graph_db import (
            FN_GRAPH_ADJ_ARTIFACT, FN_GRAPH_ADJ_VERSION,
            REVERSE_ADJ_ARTIFACT, ROUTE_GRAPH_VERSION,
            load_fn_graph_adj, load_reverse_adj)
        from vbt.precompute.resolvers_db import (
            NAME_ALIAS_ARTIFACT, MEMBERSHIP_ARTIFACT, CONST_ARTIFACT,
            MODIFIER_ARTIFACT, RESOLVERS_VERSION)
        from vbt.precompute.fn_facts_db import FN_FACTS_ARTIFACT
        with _Phase("artifact validation"):
            _require(precompute_job_id, FN_GRAPH_ADJ_ARTIFACT, FN_GRAPH_ADJ_VERSION)
            _require(precompute_job_id, REVERSE_ADJ_ARTIFACT, ROUTE_GRAPH_VERSION)
            _require(precompute_job_id, MODIFIER_ARTIFACT, RESOLVERS_VERSION)
            _require(precompute_job_id, NAME_ALIAS_ARTIFACT, RESOLVERS_VERSION)
            _require(precompute_job_id, MEMBERSHIP_ARTIFACT, RESOLVERS_VERSION)
            _require(precompute_job_id, CONST_ARTIFACT, RESOLVERS_VERSION)
            _require(precompute_job_id, FN_FACTS_ARTIFACT, 1)
            _require(precompute_job_id, CPP_SETTER_MAP_COVERAGE_ARTIFACT, COVERAGE_VERSION)
            _require(precompute_job_id, ASM_SETTERS_FULL_COVERAGE_ARTIFACT, COVERAGE_VERSION)

        with _Phase("resolver load (DB blobs)"):
            strict_load_resolvers(precompute_job_id, bp, src)
        set_cpp_setter_map_job(precompute_job_id)
        set_asm_setters_full_job(precompute_job_id)
        set_fn_facts_job(precompute_job_id)

        # ---- corpus bundle: fn graph + derived reverse adjacency + coverage. Served from
        # the cross-request cache when the manifest fingerprint matches (a precompute
        # rerun changes built_at/source_hash => miss => reload). Read-only downstream.
        fp = _corpus_fingerprint(precompute_job_id)
        cached = _CORPUS_CACHE.get(precompute_job_id)
        if cached is not None and cached[0] == fp:
            bundle = cached[1]
            _log("corpus cache HIT (fn graph + coverage reused from a prior request)")
        else:
            with _Phase("fn graph load"):
                adj_l = load_fn_graph_adj(precompute_job_id)
                if adj_l is None:
                    raise DbArtifactMissing(f"fn_graph_adj blob absent for kb {precompute_job_id}")
                rev_res = load_reverse_adj(precompute_job_id)
                if rev_res is None:
                    raise DbArtifactMissing(f"reverse_adj blob absent for kb {precompute_job_id}")
                gnodes: Set[Node] = set(adj_l.keys())
                for outs in adj_l.values():
                    for (cs, cf, _l, _c) in outs:
                        gnodes.add((cs, cf))
                bundle = {
                    "adj": adj_l, "rev": _reverse_adjacency(adj_l),
                    "node_types": rev_res[1], "graph_nodes": gnodes,
                    "cpp_cov": load_coverage(precompute_job_id, CPP_SETTER_MAP_COVERAGE_ARTIFACT) or {},
                    "asm_cov": load_coverage(precompute_job_id, ASM_SETTERS_FULL_COVERAGE_ARTIFACT) or {},
                }
            if len(_CORPUS_CACHE) >= _CORPUS_CACHE_MAX:   # FIFO bound
                _CORPUS_CACHE.pop(next(iter(_CORPUS_CACHE)))
            _CORPUS_CACHE[precompute_job_id] = (fp, bundle)
        adj = bundle["adj"]
        node_types = bundle["node_types"]
        graph_nodes = bundle["graph_nodes"]
        cpp_cov = bundle["cpp_cov"]
        asm_cov = bundle["asm_cov"]
        _log("fn graph: %d nodes, %d caller-nodes, %d edges (%d stems typed); coverage: "
             "cpp %d / asm %d stems", len(graph_nodes), len(adj),
             sum(len(v) for v in adj.values()), len(node_types), len(cpp_cov), len(asm_cov))

        with _Phase("modifier index"):
            from vbt.precompute.modifier_index import get_modifier_index
            midx = get_modifier_index(bp, src)

        # DB blueprint override: serves load_json(bp_path) from blobs — needed by ASM
        # conditions. Not installed (manifest absent) => ASM conditions degrade to
        # unavailable rather than disk-reading.
        from vbt.precompute.asm_db import install_asm_blueprint_override
        bp_override_ok = bool(install_asm_blueprint_override(precompute_job_id, bp))
        _log("blueprint override: %s", "installed (DB blobs)" if bp_override_ok
             else "NOT installed — asm conditions unavailable")
        if not bp_override_ok:
            warnings.append({"code": "blueprint_manifest_absent",
                             "effect": "asm conditions unavailable"})

        ctx = _Ctx(precompute_job_id, bp, src, adj, node_types, graph_nodes,
                   cpp_cov, asm_cov, midx, warnings, max_order_nodes,
                   bp_override_ok=bp_override_ok, rev=bundle["rev"])

        # ---- entry node ----
        e_stem = str(entry.get("stem") or "").strip()
        e_type = (entry.get("file_type") or language or "cpp").lower()
        e_fn = entry.get("function")
        entry_node: Node = (e_stem, e_fn) if (e_type == "cpp" and e_fn) else (e_stem, e_stem)
        # all-setters mode: the entry is metadata only (feasibility is skipped), so any
        # entry is accepted — the graph-membership validation applies to the default mode.
        if not all_setters and entry_node not in graph_nodes:
            raise ValueError(
                f"entry node {_node_id(entry_node[0], entry_node[1], e_type)!r} is not in the "
                f"function graph of kb {precompute_job_id}")

        try:
            from vbt.resolve.const_resolver import get_const_resolver
            cpp_const_names = set(get_const_resolver(bp, src).bare_cpp_const_names())
        except Exception:
            cpp_const_names = set()

        # ---- traversal over variables: root first, then dep vars at their read-site
        # entries. DFS (LIFO, default) completes each root→…→terminal chain before its
        # siblings; BFS (FIFO) sweeps depth levels in order.
        variables: List[Dict[str, Any]] = []
        queue: deque = deque()
        queue.append({"name": variable, "language": language, "qualified": "",
                      "entry_node": entry_node, "entry_line": None, "depth": 0,
                      "collected_from": None})
        # vkey -> depth at which the key was processed (see the re-expansion note below).
        seen_vars: Dict[Tuple[str, str, Node, Optional[int]], int] = {}
        n_setters = n_feasible = n_terminal = n_feas_capped_vars = 0
        dep_capped = False

        def _reexpand_children(item: Dict[str, Any]) -> List[Dict[str, Any]]:
            """Dep-var queue items from ``item``'s feasible setters — the recursion-only
            replay used when a depth-capped key re-appears SHALLOWER under DFS. The
            variable's JSON entry (setters, conditions, dep-var lists) is depth-
            independent and was already emitted at the deeper visit; only the child
            enqueueing was suppressed by the depth cap. Mirrors the main loop's
            enumeration order and caps; feasibility legs and site facts are memo hits,
            so the replay is ~free."""
            by_node, _ = _discover_setters(ctx, item["qualified"] or item["name"],
                                           item["language"], strict=False, home_hint=None)
            en_, e_line_ = item["entry_node"], item["entry_line"]
            use_cone_ = (not all_setters) and len(by_node) >= _CONE_PREFILTER_MIN_NODES
            children_: List[Dict[str, Any]] = []
            n_eval = n_feas = 0
            for node in sorted(by_node.keys(), key=lambda n: _node_id(n[0], n[1], ctx.lang(n[0]))):
                for s in sorted(by_node[node], key=lambda x: int(getattr(x, "line", 0) or 0)):
                    if n_eval >= max_setters_per_var:
                        return children_
                    n_eval += 1
                    if all_setters:
                        feasible_ = True
                    else:
                        _, feasible_, _ = _feasibility(ctx, node, int(s.line or 0),
                                                       en_, e_line_, use_cone=use_cone_)
                    if not feasible_:
                        continue
                    _, _, deps_ = _site_facts(ctx, node, s, cpp_const_names)
                    for d in deps_:
                        if d.is_function_output:
                            continue
                        children_.append({
                            "name": d.name, "language": d.language,
                            "qualified": d.qualified or "",
                            "entry_node": node,
                            "entry_line": (d.found_at or {}).get("startLine"),
                            "depth": item["depth"] + 1,
                            "collected_from": {
                                "variable": item["name"],
                                "file": (f"{node[0]}.{s.language}" if s.language == "asm"
                                         else f"{node[0]}.cpp"),
                                "function": (node[1] if ctx.lang(node[0]) == "cpp" else None),
                                "line": int(s.line or 0)},
                        })
                    n_feas += 1
                    if max_feasible_setters is not None and n_feas >= max_feasible_setters:
                        return children_
            return children_

        while queue:
            item = queue.pop() if dfs else queue.popleft()
            # Termination (cycle safety): this dedup key space — (var, lang, entry node,
            # entry line) — is FINITE (vars × read sites), each key is processed at most
            # once (plus depth-decreasing re-expansions, see below), and every queued
            # child carries depth+1 under max_dep_var_depth, so A→B→A dependency cycles
            # cannot loop; they just re-enter at a new read site until the key space or a
            # cap is exhausted. entry_line is IN the key because same-function feasibility
            # is read-line-sensitive (two reads of one var at different lines legitimately
            # keep different setters).
            vkey = ((item["qualified"] or item["name"]).upper(), item["language"],
                    item["entry_node"], item["entry_line"])
            prev_depth = seen_vars.get(vkey)
            if prev_depth is not None:
                # A dep var re-queued by ANOTHER (var, entry) processing the same setter:
                # its key (var, setter-node, read-line) is entry-independent, so it dedups
                # here. BFS/FIFO ⇒ depth is monotone ⇒ the processed instance was the
                # shallowest ⇒ skipping never loses a subtree. DFS/LIFO can process a key
                # DEEP first (children suppressed by the depth cap) and meet it again
                # SHALLOWER — then replay its child enqueueing at the shallower depth so
                # no subtree BFS would have expanded is lost. Transitively complete (the
                # re-enqueued children handle their own shallower re-encounters) and
                # terminating (a key re-expands only on a strictly smaller depth, ≥ 0).
                if item["depth"] < prev_depth and prev_depth >= max_dep_var_depth:
                    seen_vars[vkey] = item["depth"]
                    ctx.counters["depth_reexpansions"] += 1
                    _re_children = _reexpand_children(item)
                    queue.extend(reversed(_re_children) if dfs else _re_children)
                else:
                    ctx.counters["dup_var_skips"] += 1
                continue
            seen_vars[vkey] = item["depth"]
            if len(variables) >= max_dep_vars:
                dep_capped = True
                break
            _t_var = time.perf_counter()
            _n_queued_before = len(queue)
            _log("var #%d [d%d] %s (%s) entry=%s%s  (%d queued)...",
                 len(variables) + 1, item["depth"], item["name"], item["language"],
                 _node_id(item["entry_node"][0], item["entry_node"][1],
                          ctx.lang(item["entry_node"][0])),
                 f":{item['entry_line']}" if item["entry_line"] is not None else "",
                 len(queue))

            # search by the QUALIFIED path when the dep var carries one (engages the
            # full-path setter filter — a bare tail would match same-named fields of
            # unrelated structs); the root's home_hint scopes only the root's aliases.
            search_name = item["qualified"] or item["name"]
            by_node, excluded = _discover_setters(
                ctx, search_name, item["language"], strict=(item["depth"] == 0),
                home_hint=(home_hint if item["depth"] == 0 else None))
            en: Node = item["entry_node"]
            e_line: Optional[int] = item["entry_line"]

            setters_json: List[Dict[str, Any]] = []
            children: List[Dict[str, Any]] = []
            infeasible = 0
            setter_capped = feas_capped = False
            n_var_feasible = 0
            # scale gate: with many distinct setter fn-nodes, one entry-cone closure beats
            # a per-node ancestor BFS for the (typically majority) no-lca rejections.
            # (default-mode-only concern — all-setters mode never touches the cone.)
            use_cone = (not all_setters) and len(by_node) >= _CONE_PREFILTER_MIN_NODES
            for node in sorted(by_node.keys(), key=lambda n: _node_id(n[0], n[1], ctx.lang(n[0]))):
                for s in sorted(by_node[node], key=lambda x: int(getattr(x, "line", 0) or 0)):
                    if len(setters_json) >= max_setters_per_var:
                        setter_capped = True
                        break
                    _dbg("  setter %s:%s (%s) feasibility vs %s...",
                         _node_id(node[0], node[1], ctx.lang(node[0])), s.line, s.instruction,
                         _node_id(en[0], en[1], ctx.lang(en[0])))
                    if all_setters:
                        lca, feasible, reason = None, True, "all-setters-mode"
                    else:
                        lca, feasible, reason = _feasibility(
                            ctx, node, int(s.line or 0), en, e_line, use_cone=use_cone)
                    n_setters += 1
                    sj: Dict[str, Any] = {
                        "file": f"{node[0]}.{s.language}" if s.language == "asm" else f"{node[0]}.cpp",
                        "function": (node[1] if ctx.lang(node[0]) == "cpp" else None),
                        "line": int(s.line or 0),
                        "language": s.language,
                        "instruction": s.instruction,
                        "value": s.value,
                        "entry": _ep_json(ctx, en, e_line),
                        "lca": (_ep_json(ctx, lca, None) if lca is not None else None),
                        "feasible": bool(feasible),
                        "reason": reason,
                    }
                    if lca is not None:
                        # one shortest witness path per leg (free: parent pointers were
                        # recorded by the feasibility BFS; reconstruction is O(hops)).
                        sj["lcaPath"] = {
                            "toSetter": [_ep_json(ctx, h, None) for h in ctx.path_from(lca, node)],
                            "toEntry": [_ep_json(ctx, h, None) for h in ctx.path_from(lca, en)],
                        }
                    if feasible:
                        n_feasible += 1
                        n_var_feasible += 1
                        conds, cond_avail, deps = _site_facts(ctx, node, s, cpp_const_names)
                        sj["conditionsAvailable"] = cond_avail
                        sj["conditions"] = [
                            {"condition": c.condition, "location": _loc_json(c.location)}
                            for c in conds]
                        dv_json: List[Dict[str, Any]] = []
                        for d in deps:
                            found = d.found_at or {}
                            read_line = found.get("startLine")
                            dv_json.append({
                                "name": d.name,
                                "language": d.language,
                                **({"qualified": d.qualified} if d.qualified else {}),
                                **({"isFunctionOutput": True} if d.is_function_output else {}),
                                "entry": _ep_json(ctx, node, read_line),
                            })
                            if (not d.is_function_output
                                    and item["depth"] < max_dep_var_depth):
                                children.append({
                                    "name": d.name, "language": d.language,
                                    "qualified": d.qualified or "",
                                    "entry_node": node, "entry_line": read_line,
                                    "depth": item["depth"] + 1,
                                    "collected_from": {
                                        "variable": item["name"],
                                        "file": sj["file"], "function": sj["function"],
                                        "line": sj["line"]},
                                })
                        sj["depVars"] = dv_json
                    else:
                        infeasible += 1
                    setters_json.append(sj)
                    if (max_feasible_setters is not None
                            and n_var_feasible >= max_feasible_setters):
                        feas_capped = True
                        break
                if setter_capped or feas_capped:
                    break
            if setter_capped:
                warnings.append({"code": "max_setters_per_var", "variable": item["name"],
                                 "value": max_setters_per_var})
            if feas_capped:
                n_feas_capped_vars += 1
            # DFS: reversed so the FIRST-discovered dep var pops first (natural chain
            # order). BFS: same order as the historical inline appends.
            queue.extend(reversed(children) if dfs else children)

            feasible_count = sum(1 for s_ in setters_json if s_["feasible"])
            # terminal = a true lineage leaf: nothing feasibly sets it. Guarded against
            # evaluation truncation — a var whose setter scan was cut by
            # max_setters_per_var before any feasible one appeared is NOT proven terminal.
            terminal = feasible_count == 0 and not setter_capped
            if terminal:
                n_terminal += 1
            variables.append({
                "name": item["name"],
                "language": item["language"],
                **({"qualified": item["qualified"]} if item["qualified"] else {}),
                "depth": item["depth"],
                "entry": _ep_json(ctx, en, e_line),
                **({"collectedFrom": item["collected_from"]} if item["collected_from"] else {}),
                "setterCount": len(setters_json),
                "feasibleSetterCount": feasible_count,
                "infeasibleSetterCount": infeasible,
                "terminal": terminal,
                **({"feasibleSettersCapped": True} if feas_capped else {}),
                **({"excludedUnattributedSetters": excluded} if excluded else {}),
                "setters": setters_json,
            })
            if logger.isEnabledFor(logging.INFO):
                _reasons = Counter(s_["reason"] for s_ in setters_json)
                _log("var #%d done [d%d] %s: %d setters, %d feasible %s, +%d dep vars queued "
                     "(%.3fs)", len(variables), item["depth"], item["name"],
                     len(setters_json), len(setters_json) - infeasible,
                     dict(_reasons) if _reasons else "{}",
                     len(queue) - _n_queued_before, time.perf_counter() - _t_var)
        if dep_capped:
            warnings.append({"code": "max_dep_vars", "value": max_dep_vars})
            _log("STOPPED at max_dep_vars=%d (%d still queued)", max_dep_vars, len(queue))
        if n_feas_capped_vars:
            # one aggregate entry — with max_feasible_setters=1 this fires on nearly
            # every live variable, so per-var warnings would bloat the payload.
            warnings.append({"code": "max_feasible_setters", "value": max_feasible_setters,
                             "variablesCapped": n_feas_capped_vars})

        out: Dict[str, Any] = {
            "status": "success",
            "schema_version": SCHEMA_VERSION,
            "job_id": job_id or precompute_job_id,
            "kb_id": precompute_job_id,
            "variable": variable,
            "language": language,
            "entry": dict(entry),
            "semantics": ({"mode": "all-setters", "feasibility": "skipped-all-feasible",
                           "runtimeProof": False} if all_setters
                          else {"mode": "lca-feasibility", **_SEMANTICS}),
            "limits": {"max_dep_var_depth": max_dep_var_depth, "max_dep_vars": max_dep_vars,
                       "max_setters_per_var": max_setters_per_var,
                       "max_feasible_setters": max_feasible_setters,
                       "traversal": traversal},
            "stats": {
                "variables": len(variables),
                "setters": n_setters,
                "feasibleSetters": n_feasible,
                "infeasibleSetters": n_setters - n_feasible,
                "terminalVariables": n_terminal,
                "elapsedSec": round(time.perf_counter() - t0, 3),
            },
            "truncated": bool(ctx.truncated or dep_capped),
            "variables": variables,
            "warnings": warnings,
        }
        if logger.isEnabledFor(logging.INFO):
            _log("TOTAL lca_lineage (%.3fs, %s): %d variables (%d terminal), %d setters "
                 "(%d feasible / %d infeasible), %d warnings", time.perf_counter() - t0,
                 traversal, len(variables), n_terminal, n_setters, n_feasible,
                 n_setters - n_feasible, len(warnings))
            _log("counters: %s | memos: anc=%d lca-pairs=%d order=%d cfg-stems=%d bp-stems=%d "
                 "vars-discovered=%d", dict(ctx.counters), len(ctx._anc), len(ctx._lca),
                 len(ctx._order), len(ctx._cfg_fns), len(ctx._asm_bp), len(ctx._setters))
            if warnings:
                _log("warning codes: %s", dict(Counter(w.get("code") for w in warnings)))
        if debug:
            out["_debug"] = {"dbOnly": True, "entryNode": list(entry_node),
                             "counters": dict(ctx.counters)}
        return out
    finally:
        DA.set_load_only(prev_load_only)
        set_cpp_setter_map_job(None)
        set_asm_setters_full_job(None)
        set_fn_facts_job(None)
        try:
            from backward_traversal.utils.blueprint_utils import clear_blueprint_override
            clear_blueprint_override()
        except Exception:
            pass


def _loc_json(loc: Any) -> Optional[Dict[str, Any]]:
    """Normalize a Condition.location (``Location`` dataclass OR already-a-dict) to a plain
    JSON-safe dict — the two condition collectors emit different shapes."""
    if loc is None or isinstance(loc, dict):
        return loc
    return {"file": getattr(loc, "file", None),
            "startLine": getattr(loc, "start_line", None),
            "endLine": getattr(loc, "end_line", None)}


def _ep_json(ctx: _Ctx, node: Node, line: Optional[int]) -> Dict[str, Any]:
    lang = ctx.lang(node[0])
    return {"file": f"{node[0]}.{'cpp' if lang == 'cpp' else 'asm'}",
            "function": (node[1] if lang == "cpp" else None),
            **({"line": line} if line is not None else {})}


# --------------------------------------------------------------------------- #
# CLI — dev-only in-process run (mirrors vbt.setter_order._cli)
# --------------------------------------------------------------------------- #
def _cli(argv=None) -> int:
    import argparse
    import json
    import sys

    ap = argparse.ArgumentParser(
        prog="vbt.depvars.lca_lineage",
        description="DB-only LCA-feasibility dependency lineage (var + entry → feasible "
                    "setters → conditions + dep vars, recursed).")
    ap.add_argument("--kb-id", required=True)
    ap.add_argument("--variable", required=True)
    ap.add_argument("--language", default="cpp", choices=["cpp", "asm"])
    ap.add_argument("--entry-stem", required=True)
    ap.add_argument("--entry-type", default="cpp", choices=["cpp", "asm"])
    ap.add_argument("--entry-function", default=None)
    ap.add_argument("--max-dep-var-depth", type=int, default=1)
    ap.add_argument("--max-dep-vars", type=int, default=500)
    ap.add_argument("--max-setters-per-var", type=int, default=250)
    ap.add_argument("--max-feasible-setters", type=int, default=None,
                    help="stop evaluating a variable's setters once N FEASIBLE ones are "
                         "found (1 = witness mode: minimal fanout, deepest chains)")
    ap.add_argument("--traversal", default="dfs", choices=["dfs", "bfs"],
                    help="dfs (default) completes each root→…→terminal chain before "
                         "siblings; bfs sweeps depth levels in order")
    ap.add_argument("--mode", default="lca-feasibility",
                    choices=["lca-feasibility", "all-setters"],
                    help="'all-setters' skips feasibility: every discovered setter is "
                         "treated as feasible (no LCA/ordering work; entry is metadata only)")
    ap.add_argument("--blueprint-dir", default=None)
    ap.add_argument("--asm-dir", default=None, help="source dir (needed for the cfg-blob key)")
    ap.add_argument("--progress", action="store_true",
                    help="INFO progress logs on stderr (VBT_HANG_DEBUG=1 for the per-op trace)")
    ap.add_argument("--debug", action="store_true")
    ap.add_argument("--out", default=None)
    a = ap.parse_args(argv)

    from api.config import settings
    from api.tasks._task_utils import find_blueprint_dir
    from api.storage.workspace import WorkspaceManager
    bp = a.blueprint_dir or find_blueprint_dir(settings.JOBS_BASE_DIR / a.kb_id / "output") or \
        (settings.JOBS_BASE_DIR / a.kb_id / "output")
    src = a.asm_dir or (WorkspaceManager(a.kb_id).get_pipeline_options() or {}).get("source_path") or ""
    result = run_lca_lineage(
        a.kb_id, a.variable, a.language,
        {"stem": a.entry_stem, "file_type": a.entry_type, "function": a.entry_function},
        blueprint_dir=str(bp), asm_dir=str(src),
        max_dep_var_depth=a.max_dep_var_depth, max_dep_vars=a.max_dep_vars,
        max_setters_per_var=a.max_setters_per_var,
        max_feasible_setters=a.max_feasible_setters,
        mode=a.mode, traversal=a.traversal,
        progress=a.progress, debug=a.debug)
    payload = json.dumps(result, indent=2, default=str)
    if a.out:
        Path(a.out).write_text(payload)
        print(f"wrote {a.out} — {result['stats']}", file=sys.stderr)
    else:
        print(payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
