"""Extract dependent variables from a (setter, conditions) — SPEC §6.

Three sources: (1) setter source operands [ASM RMW prior-value handled; constants
skipped], (2) variables in the collected guard conditions, (3) function-call outputs
[flagged here; re-rooted by the recursion]. ASM uses the proven token filters; C++
extracts comparison member-paths and drops literals/enum constants.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Set

from vbt.interfaces import Condition, SetterSite
from backward_traversal.utils.token_utils import is_dep_var_candidate, normalize_token
from backward_traversal.glossary.instructions import MASK_TRIGGER_AT_ARG1 as _MASK_TRIGGER_AT_ARG1_SHARED
from vbt.conditions.asm_condition_glossary import MASK_TRIGGER_AT_ARG1_EXT
from vbt.resolve.register_indirect import is_register_indirect, resolve_register_indirect

# VBT-local mask/immediate-at-arg1 extension (SPEC #4: shared glossary reused
# read-only).  CHHSI/CLHHSI's operand-2 is always a 16-bit immediate (like
# CLI/TM's), so only operand-1 (args[0], the storage field) is a real dependency.
MASK_TRIGGER_AT_ARG1 = set(_MASK_TRIGGER_AT_ARG1_SHARED) | set(MASK_TRIGGER_AT_ARG1_EXT)


@dataclass
class DepVarRef:
    name: str                  # CANONICAL short/tail name (e.g. "softCardValue")
    language: str
    relationship: str          # condition | setter_operand | function_output | indirect_source
    found_at: Dict             # {file,startLine,endLine}
    is_function_output: bool = False
    qualified: str = ""        # full path as seen, e.g. "plasticAuth.process.transactionInds.softCardValue"
    indirection: Optional[Dict] = None  # register-indirect give-up envelope (indirect_via=Rn) — never a guess
    # Path-family provenance (member-path ancestors/descendants). A "primary" dep is
    # discovered from a read/condition/operand; it emits its container ANCESTORS (path
    # prefixes) and written sub-field DESCENDANTS as separate linked nodes. Those derived
    # nodes carry origin != "primary" and expand_family=False, so they recurse their own
    # SETTER-based deps but never re-expand the path family (no sibling blow-up / runaway).
    origin: str = "primary"            # "primary" | "ancestor" | "descendant"
    expand_family: bool = True         # False on derived (ancestor/descendant) nodes
    path_parent: str = ""              # qualified path of the immediate path-family parent (link)
    def_file: str = ""                 # function-output dep: the resolved DEFINING file stem
                                       # (disambiguates same-named functions across files)


@dataclass
class AsmIndirectContext:
    """Context needed to resolve a register-INDIRECT ASM setter source operand
    (``MVC dest,0(R1)``) to the named field it points at.  Optional — when omitted,
    register-indirect sources are dropped exactly as before (behavior preserved)."""
    bp_data: Dict[str, Any]
    bp_path: str
    asm_dir: Any = None
    route_engine: Any = None


# --------------------------------------------------------------------------- #
# C++ operand extraction
# --------------------------------------------------------------------------- #
_PATH = re.compile(r"[A-Za-z_]\w*(?:\s*(?:->|\.)\s*[A-Za-z_]\w*)*")

# C++ keywords/types and common stdlib builtins that are NOT traceable variables.
_CPP_NOISE = frozenset({
    # keywords / types
    "char", "int", "short", "long", "unsigned", "signed", "void", "bool", "float",
    "double", "const", "volatile", "static", "struct", "class", "enum", "union",
    "sizeof", "return", "if", "else", "switch", "case", "default", "for", "while",
    "do", "break", "continue", "goto", "true", "false", "nullptr", "NULL", "this",
    "new", "delete", "typedef", "auto", "register", "extern", "inline", "operator",
    "NOT", "and", "or", "not",
    # common stdlib / builtins (results aren't traceable lineage variables)
    "memcmp", "memcpy", "memset", "strcmp", "strncmp", "strlen", "strcpy",
    "strncpy", "strcat", "sprintf", "snprintf", "abs", "labs", "min", "max",
})


# z/TPF hardware-register overlay: `registers.r1`, `registers->r15`, etc. These
# are CPU registers (the C++ analogue of the ASM R0-R15 the ASM path already
# filters via looks_like_register_token), not traceable data/business variables —
# tracing a register's "setters" yields every transient load corpus-wide (the
# 217-dep explosion, audit C3). Drop any path rooted at the register overlay.
_REG_OVERLAY_HEAD = re.compile(r"^(?:registers|regs|cpuRegs|registerSaveArea)$")
_REG_TAIL = re.compile(r"^[a-z]?r(?:[0-9]|1[0-5])$")  # r0-r15 / gr0-15 style


def _is_register_path(path: str) -> bool:
    head = path.split(".")[0].split("->")[0]
    if _REG_OVERLAY_HEAD.match(head):
        return True
    # a bare/overlay register tail (registers.r1, x.r15) is a hardware register
    tail = path.split(".")[-1].split("->")[-1]
    return bool(("." in path or "->" in path) and _REG_TAIL.match(tail)
                and _REG_OVERLAY_HEAD.match(head))


def _cpp_operand_paths(text: str, const_names: Optional[Set[str]] = None) -> List[str]:
    # Strip C++ comments FIRST. A setter VALUE (especially a multi-line aggregate
    # initializer like ``Iso8583rules x[] = { {..}, //* 3: Processing Code ... }``) or a
    # condition can carry // and /* */ text whose Title-case words would otherwise leak
    # as dependent variables (``Code``/``Nothing``/``Amt``/…). Comments are not code, so
    # this only ever removes comment tokens, never a real operand.
    # LINE comments are stripped BEFORE block comments on purpose: a ``//* N: ...`` row
    # comment contains the substring ``/*``, so a block-comment pass run first would
    # match from inside the ``//*`` all the way to the next ``*/`` and devour the real
    # code in between. Killing the ``//`` line comment first removes that false ``/*``.
    t = re.sub(r"//[^\n]*", " ", text or "")
    t = re.sub(r"/\*.*?\*/", " ", t, flags=re.S)
    # drop char/string literals so 'Y' / "00" never leak
    t = re.sub(r"'(?:\\.|[^'])*'", " ", t)
    t = re.sub(r'"(?:\\.|[^"])*"', " ", t)
    # strip C-style pointer casts so the cast TYPE isn't read as a variable: (LinkSource *)
    t = re.sub(r"\(\s*[A-Za-z_][\w:]*\s*\*+\s*\)", " ", t)
    # strip hex / numeric literals (0x02 → x02 false-positive)
    t = re.sub(r"\b0[xX][0-9a-fA-F]+\b", " ", t)
    # Collapse array subscripts so a subscripted member read is captured as ONE path
    # (``allCidRecords[i].cidRecord`` → ``allCidRecords.cidRecord``) instead of shattering
    # into ``allCidRecords`` / ``i`` / ``cidRecord`` with the field link lost. The index
    # expression(s) are pulled out and re-appended as separate operands — an array index
    # IS a real read (it selects the element), captured exactly like any other variable in
    # an expression (consistent with how ``if (i < n)`` already yields ``i``). Single
    # bracket level (nested subscripts are rare); innermost is recovered either way.
    _idx = " ".join(re.findall(r"\[([^\[\]]*)\]", t))
    t = re.sub(r"\[[^\[\]]*\]", "", t)
    if _idx.strip():
        t = t + " " + _idx
    compact = t.replace(" ", "")
    out: List[str] = []
    seen: Set[str] = set()
    for m in _PATH.finditer(t):
        raw = m.group(0)
        pn = re.sub(r"\s+", "", raw)
        head = pn.split(".")[0].split("->")[0]
        if not pn or pn in seen:
            continue
        # scoped enum constant (Cas::On, SoftCardValueDetail::X) → not a variable
        if "::" in pn or (pn + "::") in compact or ("::" + pn) in compact:
            continue
        if pn.isdigit() or pn in ("0", "1"):
            continue
        # language keyword / builtin / cast-type / stdlib fn → not a lineage variable
        if head in _CPP_NOISE or pn in _CPP_NOISE:
            continue
        # hardware-register overlay (registers.r1, …) → not a data/business variable
        if _is_register_path(pn):
            continue
        # bare ALL-CAPS identifier in this camelCase codebase = #define macro / constant
        if "." not in pn and "->" not in pn and re.match(r"^[A-Z][A-Z0-9_]*$", pn):
            continue
        # bare identifier that is a KNOWN enum constant (per the const-resolver table) =
        # a comparand/case-label, not a variable (e.g. ``task != DacAutoRes`` → DacAutoRes
        # = 0x64). This catches the bare TitleCase / camelCase enumerators the ALL-CAPS and
        # ``::`` rules above miss. Authoritative: only names PROVEN to be enum constants are
        # dropped, and only in their bare form (a ``x.DacAutoRes`` field read keeps its path).
        if const_names and "." not in pn and "->" not in pn and pn in const_names:
            continue
        seen.add(pn)
        out.append(pn)
    return out


def _is_cpp_call(text: str, name: str) -> bool:
    return re.search(re.escape(name) + r"\s*\(", text) is not None


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #
def extract_dep_vars(
    setter: SetterSite,
    conditions: List[Condition],
    *,
    constant_symbols: Optional[Set[str]] = None,
    cpp_const_names: Optional[Set[str]] = None,
    skip_vars: Iterable[str] = (),
    asm_indirect_ctx: Optional[AsmIndirectContext] = None,
) -> List[DepVarRef]:
    lang = setter.language

    def _short(n: str, src_lang: str = lang) -> str:
        # Canonical short name, keyed on the NAME's OWN language — not necessarily the
        # setter's. In a mixed cross-language chain a C++ setter can carry ASM-origin
        # condition deps, which must be normalized as ASM names (and vice-versa).
        # C++ setter search is tail-based, so a field and its full path
        # (a.b.c.field vs field) are the SAME variable → canonical = tail.
        if src_lang == "cpp":
            return n.split(".")[-1].split("->")[-1]
        return normalize_token(n)

    skip_idents = {_short(setter.variable).upper()} | {_short(s).upper() for s in skip_vars}
    deps: List[DepVarRef] = []
    seen: Set[str] = set()

    def _add(full: str, rel: str, loc: Dict, is_fn: bool = False, src_lang: str = lang):
        short = _short(full, src_lang)
        ident = short.upper()
        if not short or ident in seen or ident in skip_idents:   # never emit self/root
            return
        seen.add(ident)
        deps.append(DepVarRef(name=short, language=src_lang, relationship=rel, found_at=loc,
                              is_function_output=is_fn,
                              qualified=(full if full != short else "")))

    # ---- (1) setter source operand(s) ----
    if lang == "asm":
        # Use the parsed source operand (setter_expression), NOT the raw line —
        # the raw line carries an inline comment that must never leak as operands.
        # NOTE: split on comma/whitespace would shatter a register-indirect form
        # ``0(R1)`` into "0(R1)" still (no top-level comma inside), but a comment-
        # contaminated value could; the value field is already comment-stripped by
        # the setter detector for the source operand.
        for tok in re.split(r"[,\s]+", setter.value or ""):
            if not tok:
                continue
            if is_dep_var_candidate(tok, skip_var=setter.variable, constant_symbols=constant_symbols):
                _add(normalize_token(tok), "setter_operand", setter_loc(setter))
            elif asm_indirect_ctx is not None and is_register_indirect(tok):
                # Register-INDIRECT source (``0(R1)``) — previously DROPPED.  Resolve
                # the register to the named field it points at (SPEC §6, register-drop
                # gap).  Sound: gives up with an envelope rather than guessing.
                res = resolve_register_indirect(
                    tok,
                    stem=setter.file_stem,
                    block_id=setter.block_id,
                    before_line=setter.line,
                    bp_data=asm_indirect_ctx.bp_data,
                    bp_path=asm_indirect_ctx.bp_path,
                    asm_dir=asm_indirect_ctx.asm_dir,
                    route_engine_or_none=asm_indirect_ctx.route_engine,
                )
                for nm in res.named_deps:
                    # F2: the resolver already vetted named_deps (via _emit →
                    # is_dep_var_candidate). Re-filtering here was redundant AND
                    # destructive — it dropped the SYNTHETIC terminal-producer markers
                    # (call_return@Rn / alloc@heap / DB_CONTEXT_*) that contain '@'/':'.
                    # Emit those verbatim; normalize only real named fields.
                    if "@" in nm or nm.startswith("DB_CONTEXT_"):
                        ident = nm.upper()
                        if ident not in seen:
                            seen.add(ident)
                            deps.append(DepVarRef(name=nm, language=lang,
                                                  relationship="indirect_source",
                                                  found_at=setter_loc(setter)))
                    elif is_dep_var_candidate(nm, skip_var=setter.variable,
                                              constant_symbols=constant_symbols):
                        _add(normalize_token(nm), "setter_operand", setter_loc(setter))
                # F1: register-indirect resolution gave up (caller-inherited register /
                # not found within bounds) — emit the give-up ENVELOPE as a dep so the
                # lineage shows "value arrives via Rn, unresolved" instead of vanishing
                # silently (SPEC §6a: give up, don't guess, but NEVER silent).
                if res.unresolved_envelope:
                    env = res.unresolved_envelope
                    via = str(env.get("indirect_via") or "?")
                    ident = f"INDIRECT@{via}".upper()
                    if ident not in seen:
                        seen.add(ident)
                        deps.append(DepVarRef(name=via, language=lang,
                                              relationship="indirect_source",
                                              found_at=setter_loc(setter),
                                              indirection=env))
    else:
        # ⑤-M6: do NOT gate on `constant_source`. A RHS like `a::b + localVar` is not a
        # pure constant — gating dropped its real operand `localVar`. `_cpp_operand_paths`
        # already filters scoped-enum constants (`::`), literals and keywords, so a
        # genuinely-constant RHS yields no operands while a mixed expression still
        # surfaces its variable operands.
        val = setter.value or ""
        if val:
            for p in _cpp_operand_paths(val, cpp_const_names):
                _add(p, "setter_operand", setter_loc(setter), is_fn=_is_cpp_call(val, p.split(".")[0].split("->")[0]))

    # ---- (2) condition variables ----
    for c in conditions:
        # Normalize the condition's file to a bare basename. A C++ condition's
        # location carries the ABSOLUTE cpp_path (collect_cpp_conditions), whereas a
        # setter operand's found_at is the bare ``{stem}.{ext}`` (setter_loc). Leaving
        # them inconsistent makes a downstream ``found_at["file"]`` → stem extraction
        # yield two spellings of the same file (absolute vs bare) — which both leak
        # into the dep-var candidate set (duplicate setters) and break the discovery-
        # file chain-scoping rule (the absolute disc_file never equals a bare stem).
        cfile = (c.location.file or "").rsplit("/", 1)[-1]
        loc = {"file": cfile, "startLine": c.location.start_line, "endLine": c.location.end_line}
        # ROOT-CAUSE FIX: dispatch the condition-operand extractor on the CONDITION's
        # OWN origin language, never on `setter.language`. A C++ setter's guard chain
        # can cross an ASM file in a mixed cross-language trace (e.g. softCardValue's
        # `aa71 → dw730000` hop, whose guards are ASM `TM @CASVIS1,X'01'` /
        # `TM L7DSTS,X'40'`). Those ASM conditions carry raw_test (the ASM compare, set
        # by engine._mk_cond). Keying on setter.language (== "cpp" here) routed them to
        # the C++ extractor, which then discarded the ASM operands (`@CASVIS1`/`L7DSTS`
        # → all-caps macro-drop; `X'..'` masks → literal-strip) → ZERO dep vars from the
        # ASM guards. An ASM condition is identified by a populated raw_test (ASM-only)
        # or a `.asm` source file; its deps are emitted with language="asm" (src_lang)
        # so the downstream recursion resolves/searches the ASM setter space —
        # resolve_aliases keys on dep.language (recurse.py), and a "cpp" tag would hunt
        # for a C++ setter of an ASM symbol and find nothing.
        cond_is_asm = bool(c.raw_test) or cfile.endswith(".asm")
        if cond_is_asm:
            # Harvest operands from the TRIGGER (raw_test, the compare) ONLY. raw_branch
            # is the conditional BRANCH, whose operand is the TARGET LABEL (``JZ
            # AA710A5Q``) — a code location, never a data variable; harvesting it turned
            # every branch target into a spurious dependent variable (AA710A5Q / FIRECHK /
            # CONTINUE / SKIP_89CNT / …). Indexed-branch register operands are already
            # rejected by is_dep_var_candidate, so raw_test alone loses no real dependency
            # (the compare carries all the compared fields).
            for src in (c.raw_test,):
                if not src:
                    continue
                # raw_test like "CLC WK_RRC, ZEROS" → operands after the mnemonic
                parts = re.split(r"\s+", src.strip(), maxsplit=1)
                mnem = parts[0].upper() if parts else ""
                ops = parts[1] if len(parts) > 1 else ""
                op_toks = re.split(r"[,\s]+", ops)
                # F9: MASK_TRIGGER_AT_ARG1 (TM/TMY/CLI/CLIY/TRT) — operand[1] is ALWAYS
                # a constant mask/comparand, never a data variable (e.g. the bit-EQU in
                # `TM L7DSAF,L7DSBIT`). Harvest only operand[0], mirroring the precise
                # engine's _collect_dep_vars; else the mask leaks in as a dep var.
                if mnem in MASK_TRIGGER_AT_ARG1:
                    op_toks = op_toks[:1]
                for tok in op_toks:
                    if is_dep_var_candidate(tok, skip_var=setter.variable, constant_symbols=constant_symbols):
                        _add(normalize_token(tok), "condition", loc, src_lang="asm")
        else:
            for p in _cpp_operand_paths(c.condition, cpp_const_names):
                _add(p, "condition", loc, is_fn=_is_cpp_call(c.condition, p.split(".")[0].split("->")[0]),
                     src_lang="cpp")

    return deps


def setter_loc(setter: SetterSite) -> Dict:
    ext = "cpp" if setter.language == "cpp" else "asm"
    return {"file": f"{setter.file_stem}.{ext}", "startLine": setter.line, "endLine": setter.line}
