"""Dependent-variable extraction + recursive tracing (SPEC §6)."""
