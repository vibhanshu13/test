LG1OSI is directly and centrally tied to C400 processing. Here's the evidence:
                                                                                                                                  
  ---
  What LG1OSI is:                                                                                                                                       
                                                                                                                                                        
  It's an "Online Source Indicator" byte. Its possible values are defined in lg1lg1.mac:                                                                
                                                                                                                                                        
  LG#C112  EQU  C'A'    X'C1' - REQUEST FROM C112
  LG#G116  EQU  C'B'    X'C2' - G116 BATCH UPDATE                                                                                                       
  LG#C400  EQU  C'D'    X'C4' - REQUEST FROM C400
  LG#PSGL  EQU  C'P'    X'D7' - REQUEST FROM PRESENTATION SERVICES                                                                                      
                  
  It's a routing flag — set once to record where the current transaction came from, then checked downstream to drive conditional logic.                 
                  
  ---                                                                                                                                                   
  How C400 sets it — da78.asm line 854:
                                                                                                                                                        
  OI    LG1OSI,LG#C400    UPDATE IS COMING FROM C400  R024
                                                                                                                                                        
  And da78's own header comments confirm it explicitly:                                                                                                 
  * REASON:  SET ONLINE SOURCE INDICATOR TO C400 IN LG1G1 TO LET FM
  *          KNOW WE'RE COMING FROM C400 PROCESSING.                                                                                                    
  * TEMPORARY SECONDARY PRODUCT CODE VIA THE CAS C400 REST API.                                                                                         
                                                                                                                                                        
  da78 is the C400 program.                                                                                                                             
                                                                                                                                                        
  ---             
  How downstream files consume it:                                                                                                                      
                                  
  ┌──────────┬────────────┬────────────────────┬────────────────────────────────────────────┐
  │   File   │    Line    │    Instruction     │                  Comment                   │                                                           
  ├──────────┼────────────┼────────────────────┼────────────────────────────────────────────┤
  │ xh80.asm │ 996, 1411  │ CLI LG1OSI,LG#C400 │ FROM C400?                                 │                                                           
  ├──────────┼────────────┼────────────────────┼────────────────────────────────────────────┤
  │ xh85.asm │ 187        │ CLI LG1OSI,LG#C400 │ FROM C400 PROCESSING?                      │                                                           
  ├──────────┼────────────┼────────────────────┼────────────────────────────────────────────┤                                                           
  │ xh88.asm │ 1022, 1251 │ CLI LG1OSI,LG#C400 │ FROM C400 PATH? / IS SOURCE C400 REALTIME? │                                                           
  └──────────┴────────────┴────────────────────┴────────────────────────────────────────────┘                                                           
                  
  All of these check LG1OSI specifically to gate C400-specific logic.                                                                                   
                  
  ---                                                                                                                                                   
  Conclusion: LG1OSI is the central C400 source indicator. da78 sets it to mark a transaction as coming from C400, and at least 3 downstream programs
  (xh80, xh85, xh88) branch on it to execute C400-specific processing paths. Tracing LG1OSI IS tracing C400 processing flow.  