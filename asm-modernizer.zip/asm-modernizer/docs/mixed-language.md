# Mixed-Language Analysis

This project supports analyzing assembly, macros, copybooks, and C/C++ sources together.

## Capabilities
- Cross-language call graph linking between ASM and C/C++ symbols
- Macro expansion and conditional assembly for ASM
- Variable lineage tracking for ASM registers/memory and C/C++ variables

## Tree-sitter
C/C++ parsing uses tree-sitter when available. If tree-sitter is not installed, C/C++ files will be accepted but parsed with `c_family_parse_errors` metadata.

## Output
The JSON output includes a `variable_lineage` graph describing how values are defined, assigned, and used across the codebase.

You can also export lineage directly with `--lineage-export` to a file or directory.
DOT export is available via `--lineage-dot`.
