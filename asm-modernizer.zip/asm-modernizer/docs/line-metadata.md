# Line Metadata System

## Overview

The line metadata system provides O(1) lookup of rich context for every line:
- **Codeblock context**: Which function/section/routine contains this line
- **Conditional context**: Active conditionals, nesting depth, condition types
- **Call summary**: Pre-computed lists of functions/routines/macros called

## Usage

### Accessing Line Metadata

```python
# From AnalysisContext
metadata = context.get_line_metadata(42)

if metadata:
    # Check if line is in conditional
    if metadata.conditional.is_conditional:
        print(f"Depth: {metadata.conditional.depth}")
        print(f"Conditions: {metadata.conditional.active_conditions}")

    # Get enclosing function/section
    function = metadata.codeblock.enclosing_function
    section = metadata.codeblock.enclosing_section

    # Get calls from this codeblock
    calls = (metadata.calls.calls_functions +
             metadata.calls.calls_routines +
             metadata.calls.invokes_macros)
```

### Query API

```python
index = context.line_metadata_index

# Get all lines in a function
lines = index.get_lines_in_function("main")

# Get all conditional lines
conditional_lines = index.get_conditional_lines()

# Get all lines in a section
section_lines = index.get_lines_in_section("MAINSECT")
```

## JSON Output

Line metadata is included in JSON output under `line_metadata`:

```json
{
  "line_metadata": {
    "42": {
      "codeblock": {
        "enclosing_function": "main",
        "in_executable_block": true
      },
      "conditional": {
        "is_conditional": true,
        "depth": 1,
        "active_conditions": ["x > 0"],
        "condition_types": ["if"]
      },
      "calls": {
        "calls_functions": ["helper"],
        "calls_routines": [],
        "invokes_macros": []
      }
    }
  }
}
```

## Architecture

### Collection (Phase 1)

During parsing, collectors track ephemeral state:
- **ASMLineMetadataCollector**: Tracks sections, routines, conditionals (BC, AIF)
- **CLineMetadataCollector**: Tracks functions, conditionals (if/while/for/switch)

Both maintain stacks for nested conditionals and record metadata per line.

### Enrichment (Phase 2)

After parsing, **LineMetadataEnricher** populates call information:
- Extracts calls from CallGraph
- Classifies into functions/routines/macros
- Updates all lines within each codeblock

### Storage

**LineMetadataIndex** provides O(1) lookups and query methods.
Stored in `AnalysisContext.line_metadata_index`.

## Examples

### Variable Tracking

```python
# Check if variable defined in conditional
var_line = 42
metadata = context.get_line_metadata(var_line)

if metadata.conditional.is_conditional:
    print("Variable may not be initialized on all paths")
    print(f"Conditions: {metadata.conditional.active_conditions}")
```

### Call Analysis

```python
# Find all functions that call a specific routine
target = "HELPER"

for metadata in context.line_metadata_index.get_all():
    if target in metadata.calls.calls_routines:
        function = (metadata.codeblock.enclosing_function or
                   metadata.codeblock.enclosing_routine)
        print(f"{function} calls {target}")
```

### Complexity Analysis

```python
# Find deeply nested conditionals (potential code smell)
complex_lines = [
    m for m in context.line_metadata_index.get_all()
    if m.conditional.depth >= 3
]

for metadata in complex_lines:
    print(f"Line {metadata.line_number}: {metadata.conditional.depth} levels deep")
```
