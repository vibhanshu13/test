# Variable Explanation Feature

## Overview

The explanation feature translates a variable's backward-lineage chain into a rich technical narrative, one file at a time. It is designed for **ASM/mainframe engineers** who need to understand, navigate, and modify the codebase — answers cite specific instruction mnemonics (OI, MVC, CLC, TM, BAS, ENTRC, etc.), operands, line numbers, routine names, and branch conditions throughout.

The key design principle is **incremental context accumulation**: rather than feeding the entire lineage to the LLM in one large prompt, each LLM call covers exactly one `(file_stem, variable_in_file, phase)` tuple. A growing "story so far" — compact one-liner facts *plus* full prior LLM explanations — is appended to each subsequent call. After all tuples are explained a **final synthesis pass** produces one unified end-to-end narrative. Production uses Gemini 2.5 Pro (~1 M token context window), so no truncation is applied.

---

## Prerequisites

The explanation feature sits on top of two existing systems:

1. **Blueprint pipeline** — parses every ASM / C++ source file into a structured JSON blueprint and builds a `file_call_graph.json`.
2. **Chunked backward-lineage session** — traces a variable backward through the call graph, assembling one tuple per `(file, phase)` step. Created by `POST /{kb_id}/backward-lineage/chunks` or the `chunk_cli.py` dev tool.

A `ChunkedBackwardSession` must exist and have at least one processed tuple before the explanation endpoints can be called.

---

## Components

| File | Role |
|------|------|
| `llm/variable_explainer.py` | Core explainer: prompt construction, session persistence, synthesis, LLM orchestration |
| `llm/caller.py` | Thin Gemini API wrapper used by the explainer |
| `api/schemas/variable_explain.py` | Pydantic request/response models for the two HTTP endpoints |
| `api/routes/knowledge_base.py` (lines 1769–2042) | Route handlers, backward-session loader, response builder |
| `explain_cli.py` | Dev CLI: run the explainer on `chunk_cli.py` output without starting the API server |
| `backward_traversal/chunk_cli.py` | Dev CLI: generate backward-lineage chunk files locally |

---

## Data Flow

```
chunk_cli.py / POST /backward-lineage/chunks
        │
        ▼
ChunkedBackwardSession  (persisted as msgpack chunks on disk)
        │
        │  tuple 0 (setter file)
        ▼
POST /{kb_id}/explain-variable
        │
        ├─ _backward_session_meta()      load root_variable, selected_chain, total_tuples
        ├─ create_explain_session()      create explain session on disk (if new)
        ├─ _load_backward_tuple(idx=0)   assemble tuple dict from chunk files
        ├─ build_tuple_prompt()          construct LLM prompt with story + file context
        ├─ call_llm()                    Gemini API call → explanation text
        ├─ _extract_tuple_fact()         derive one-line fact from metadata (no LLM)
        └─ _save_session()               persist explanation + fact to explain session
        │
        │  response → { explanation, next_tuple_index, is_complete, … }
        │
        │  (client clicks "Explain More")
        ▼
POST /{kb_id}/explain-variable/next  { backward_session_id, current_tuple_index: 0 }
        │
        ├─ next_idx = current_tuple_index + 1
        ├─ load_explain_session()        load accumulated story (facts + full prior explanations)
        ├─ _load_backward_tuple(next_idx)
        ├─ _load_business_summary()      load FILE CONTEXT from blueprint (no extra LLM call)
        ├─ build_tuple_prompt()          now includes story, file context, prior explanations
        ├─ call_llm()
        ├─ _extract_tuple_fact()
        └─ _save_session()
        │
        └─ repeat until is_complete = true
        │
        │  (all tuples explained)
        ▼
generate_synthesis()    one final LLM call — unified end-to-end narrative saved to explain session
```

---

## Phase System

Each tuple has a `phase` that describes its role in the lineage. The prompt task and the "story so far" fact both vary by phase.

| Phase key | Human label | What it represents |
|-----------|-------------|-------------------|
| `modifier` | Setter File | The file that directly writes the variable. This is tuple 0. |
| `upstream` | Upstream Caller | A file in the call chain that eventually triggers the setter. |
| `root_var_downstream` | Downstream Consumer | A file that reads the variable after it has been set and acts on it. |
| `dep_var_chain` | Dependent Variable | A prerequisite variable that must be correctly established before the root variable can be written. |
| `dep_var_downstream` | Dependent Variable (Downstream) | A file that consumes a dependent variable downstream. |
| `cpp_dep_var_extended` | Extended C++ Dependency | A C++ dependency variable traced through the extended lineage pass. |

The traversal order is: `modifier` → `upstream` callers (deepest first) → `root_var_downstream` consumers → `dep_var_chain` prerequisites.

**dep_var gate-linking requirement**: every `dep_var_chain` explanation must explicitly reference the specific `CLC`/`CLI`/`TM`/`CP` compare and the conditional branch (`BNE`/`BE`/`BZ`/`BNZ`) at the *setter* that consumes the dep_var. The phase-specific task instruction (see `_phase_task()`) enforces this with a direct prompt directive. If the link is not visible in the metadata the LLM is instructed to say so rather than fabricate one.

---

## `llm/variable_explainer.py` — Core Module

### Session model

An **explain session** is a msgpack file stored at:

```
{JOBS_BASE_DIR}/{kb_id}/output/explain_sessions/{backward_session_id}.msgpack
```

Schema:

```python
{
    "version": 1,
    "backward_session_id": str,
    "root_variable": str,          # always uppercased (e.g. "LG1OSI")
    "current_tuple_index": int,    # last explained index
    "explanations": {              # str(idx) → LLM output text
        "0": "...",
        "1": "...",
    },
    "tuple_facts": {               # str(idx) → one-line structured fact
        "0": "da78: LG1OSI set via MVI at line 1234, conditions checked: WK_RRC, WK_ID",
        "1": "dx750000: upstream caller → calls da78",
    },
    "synthesis": str,              # NEW: unified end-to-end narrative (added after all tuples explained)
    "created_at": ISO-8601 string,
}
```

The session is created on the first call to `/explain-variable` or `/explain-variable/next` for a given `backward_session_id`. Both endpoints are idempotent: if an explanation for a given `tuple_index` is already in `session["explanations"]`, the cached value is returned and no LLM call is made.

### `_extract_tuple_fact()` — no-LLM context extraction

Rather than calling the LLM to summarise prior steps, `_extract_tuple_fact()` constructs a deterministic one-line fact from the tuple's metadata fields. This is cheap (no API call) and precise. The format varies by phase:

- **modifier**: `"{stem}: {root_var} set via {instruction} at line {n}, conditions checked: {vars}"`
- **upstream**: `"{stem}: upstream caller (as {var}) → calls {target_files}"`
- **root_var_downstream**: `"{stem}: receives {root_var} after it is set (downstream consumer)"`
- **dep_var_chain / dep_var_downstream / cpp_dep_var_extended**: `"{stem}: dep_var {var} set at line {n} (dependency from {origin}), must be correct for {root_var}"`

These facts accumulate in `tuple_facts` and are fed as a bullet list ("STORY SO FAR") to every subsequent LLM call.

**cond_vars parsing fix**: The `modifier` fact includes the condition variables checked before the setter fires, extracted from `COMPARE` type `relevant_code_lines`. Operands in those instructions are stored in raw assembly notation (e.g. `0(2,WK_RRC)`, `6(1,WK_ID)`), which previously caused offset fragments like `0(2,` and `6(1,` to be captured as variable names. Fixed by validating each extracted operand against a strict identifier pattern before including it:

```python
_IDENT_RE = re.compile(r"^[A-Z_][A-Z0-9_#@.]*$")
# Only keep operands that look like valid assembly identifiers
if first_op and _IDENT_RE.match(first_op) and first_op not in cond_vars:
    cond_vars.append(first_op)
```

Before fix: `conditions checked: WK_RRC, 0(2, 6(1`  
After fix: `conditions checked: WK_RRC, WK_ID`

### `build_tuple_prompt()` — prompt construction

Each prompt has five clearly labelled sections separated by `---`:

```
ANALYSIS GOAL
  Variable, full chain (entry point → setter), "step N of M"

STORY SO FAR
  Quick reference (one-liner per prior step):
    • Step 0: da78: LG1OSI set via MVI at line 1234, conditions checked: WK_RRC, WK_ID
    • Step 1: dx750000: upstream caller → calls da78
    …

  Detailed prior explanations:

  [Step 0]
  In routine DA7_8000, LG1OSI is set via …

  [Step 1]
  The lu82 routing block identifies …

FILE CONTEXT — what '{stem}' does in the system
  {blueprint.business_summary}   ← pulled from the pre-built blueprint file

CURRENT STEP: {stem} | variable: {var} | role: {phase_label}
  Pre-analysis summary: {tuple.summary}
  Write/setter sites: …
  Relevant source instructions: …
  Cross-file calls from this block: …
  Source code excerpt: …

YOUR TASK
  Phase-specific instruction (what to explain and in what order)
```

**Prompt parameter**: `build_tuple_prompt()` accepts an optional `prior_explanations: Dict[str, str]` parameter. When provided, all prior LLM explanations are included verbatim in the STORY SO FAR section after the quick-reference facts. This gives the LLM full narrative context for dep_var gate-linking.

**FILE CONTEXT injection**: `_load_business_summary(bp_path)` reads the `business_summary` field from the blueprint msgpack file referenced by `tuple_data["bp_path"]`. This is a pre-built LLM-generated description of the entire source file's business purpose. It is injected as a dedicated "FILE CONTEXT" section between STORY SO FAR and CURRENT STEP. No extra LLM call is required — the summary was already generated during the blueprint pipeline.

**Phase-specific task instructions** (`_phase_task()`):
- **modifier** — asks for the full precondition chain: every subroutine call (`BAS`/`ENTRC`/`ENTDC`), every compare (`CLC`/`CLI`/`TM`/`CP`), and every conditional branch (`BNE`/`BE`/`BZ`/`BNZ`) that must evaluate correctly for the setter to fire. Line numbers required for each.
- **upstream** — asks for every guard condition at the call site that must pass for the downstream segment to be reached.
- **dep_var_chain** — explicitly requires linking back to `root_variable`: "reference the specific gate site at the setter (the CLC/CLI/TM line and the conditional branch) where '{variable}' is consumed to decide whether '{root_variable}' is set."

No hard token limits are applied — Gemini 2.5 Pro in production has ~1 M token context. The original 800-char / 15-line caps documented previously have been removed from the prompt building logic.

### System prompt

The LLM is positioned as a technical explainer for **ASM/mainframe engineers**. Key constraints baked into the system prompt:
- Match the technical depth of the question
- When answering about implementation: cite specific instruction mnemonics (`OI`, `MVC`, `CLC`, `TM`, `BAS`, `ENTRC`, `ENTDC`, etc.), operands, line numbers, routine names, and branch conditions
- Build on prior context, do not repeat it verbatim
- 4–6 sentences per response; expand for multi-part questions
- If the answer is not in the provided context, say so explicitly rather than fabricating instructions

### `_load_business_summary(bp_path)` — blueprint context loader

```python
def _load_business_summary(bp_path: str) -> str:
    """Load the business_summary field from a blueprint msgpack file."""
    path = Path(bp_path)
    if not path.exists():
        return ""
    with open(path, "rb") as f:
        bp = msgpack.unpackb(f.read(), raw=False)
    return (bp.get("business_summary") or "").strip()
```

Blueprints are msgpack-encoded (not JSON). Returns empty string on any error — blueprint context is supplementary, not required.

### `build_synthesis_prompt()` and `generate_synthesis()` — final synthesis pass

After all tuples are explained, one additional LLM call produces a unified end-to-end narrative. This is the highest-quality artifact — it synthesises all per-step explanations into a coherent story with full cross-step context.

**`build_synthesis_prompt()`** assembles:
1. Header: variable name, chain, total tuples
2. Phase index: for each tuple → `Step N: {file_stem} ({phase_label})`
3. Quick-reference facts (the tuple_facts bullet list)
4. All per-step explanations in full
5. Task: "Synthesise into ONE coherent narrative (10–15 sentences). Open with the variable's role; close with the business state it records when set successfully."

**`_SYNTHESIS_SYSTEM_PROMPT`** positions the LLM to produce a flowing story (not a step-by-step enumeration) that covers:
- (a) what the variable represents
- (b) how it is set — exact instruction, line, and routine
- (c) the full precondition chain (every compare and branch)
- (d) which dep_vars matter and which gate each one feeds
- (e) how upstream callers reach the setter and what business decision they make

**`generate_synthesis()`** is one LLM call. It is called by `explain_cli.py` after the main loop and the result is saved to `explain_session["synthesis"]`.

---

## `llm/caller.py` — Gemini API Wrapper

`call_llm(prompt, system_prompt)` calls the Gemini model configured in `settings.LLM_MODEL_NAME` (default: `gemini-3-flash-preview`).

**Non-text part handling**: Thinking models (e.g. `gemini-2.5-flash`) return `thought_signature` parts alongside the text. The wrapper iterates `response.candidates[].content.parts[]` and concatenates only parts that have a `.text` attribute, suppressing the SDK warning:

```python
text = "".join(
    part.text
    for candidate in (response.candidates or [])
    for part in (candidate.content.parts or [])
    if hasattr(part, "text") and part.text
)
```

Config pulled from `api.config.settings`: `GEMINI_API_KEY`, `LLM_MAX_TOKENS`, `LLM_TEMPERATURE`, `LLM_MODEL_NAME`.

---

## API Endpoints

Both endpoints require a valid KB (status `"success"`) and an authenticated user.

### `POST /{kb_id}/explain-variable`

**Purpose**: Start a new explanation walk at a given tuple index (default 0, the setter file).

**Request body** (`ExplainVariableRequest`):

```json
{
  "backward_session_id": "abc-123",
  "start_tuple_index": 0
}
```

**Guards**:
- KB must exist and be in `"success"` state
- `backward_session_id` must map to an existing `ChunkedBackwardSession`
- Session must have at least one tuple (`total_tuples > 0`)
- `start_tuple_index` must be within range

**Response** (`ExplainLayerResponse`):

```json
{
  "backward_session_id": "abc-123",
  "root_variable": "LG1OSI",
  "tuple_index": 0,
  "next_tuple_index": 1,
  "total_tuples_known": 16,
  "is_session_complete": false,
  "file_stem": "da78",
  "file_type": "asm",
  "variable_in_file": "LG1OSI",
  "phase": "modifier",
  "phase_label": "Setter File",
  "tuple_summary": "da78 sets LG1OSI via MVI …",
  "explanation": "In the initial step …",
  "is_complete": false
}
```

`is_complete` is `true` when `tuple_index >= total_tuples_known - 1`. `is_session_complete` reflects whether the backward traversal itself has finished processing all phases.

### `POST /{kb_id}/explain-variable/next`

**Purpose**: Advance explanation by one tuple. This is the "Explain More" button on the client.

**Request body** (`ExplainNextRequest`):

```json
{
  "backward_session_id": "abc-123",
  "current_tuple_index": 0
}
```

The endpoint computes `next_idx = current_tuple_index + 1`. If `next_idx >= total_tuples`, it returns the last cached explanation with `is_complete: true` rather than erroring.

Both endpoints are safe to call multiple times for the same index — the explain session cache prevents duplicate LLM calls.

---

## Helper Functions in Routes

### `_load_backward_tuple(kb_id, backward_session_id, tuple_index)`

Loads a `ChunkedBackwardSession` from disk and calls `session.assemble_tuple(tuple_index, session_dir)`, which reconstructs a complete tuple dict from the raw chunk files. Returns `None` if the session is missing or the tuple hasn't been processed yet.

### `_backward_session_meta(kb_id, backward_session_id)`

Returns lightweight metadata without assembling any tuple data:

```python
{
    "is_complete": bool,
    "total_tuples": int,
    "selected_chain": list[str],
    "root_variable": str,
}
```

### `_build_explain_response(...)`

Assembles an `ExplainLayerResponse` from a tuple dict + explanation text. Calls `phase_label()` from `variable_explainer` for the human-readable phase name.

---

## Schemas (`api/schemas/variable_explain.py`)

### `ExplainVariableRequest`
| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `backward_session_id` | str (min 1) | required | Session ID from a prior `/backward-lineage/chunks` call |
| `start_tuple_index` | int (≥ 0) | 0 | Tuple index to begin from |

### `ExplainNextRequest`
| Field | Type | Description |
|-------|------|-------------|
| `backward_session_id` | str (min 1) | Same session |
| `current_tuple_index` | int (≥ 0) | The tuple just explained; next = this + 1 |

### `ExplainLayerResponse`
All fields documented in the schema file. Key fields for client logic:

- `next_tuple_index` — pass this as `current_tuple_index` to the next `/next` call
- `is_complete` — `true` when no more tuples remain; stop calling `/next`
- `is_session_complete` — `true` when the backward traversal has finished all phases (may be `false` while tuples are still being processed in a long-running session)
- `variable_in_file` — may differ from `root_variable` when a C++ field alias is used (e.g. root `LG1OSI`, alias `CasGLRec.onlineSrcInd`)

---

## Dev CLI Tools

### Step 1 — Generate backward chunks (`backward_traversal/chunk_cli.py`)

Runs the full `ChunkedBackwardSession` locally, bypassing the API/Redis/Celery stack. Writes one `{VAR}_tuple_{N}.json` per tuple plus a `tuple_index_map.json` registry.

```bash
python backward_traversal/chunk_cli.py LG1OSI \
    --chain-files lu82,dx750000,dx710000,dx730000,dx740200,da78 \
    --blueprint-dir output/asm \
    --asm-dir temp/asm \
    --graph output/file_call_graph.json \
    --output-dir /tmp/lg1osi_chunks
```

The last entry in `--chain-files` must be the modifier file (the one that sets the variable). The chain for `LG1OSI` is `lu82 → dx750000 → dx710000 → dx730000 → dx740200 → da78` (taken from `LG1OSI_cross_lineage.json`).

Output structure:

```
/tmp/lg1osi_chunks/
  LG1OSI_tuple_0.json      ← page envelope: session_id, root_variable, chain, tuple {}
  LG1OSI_tuple_1.json
  …
  tuple_index_map.json     ← [{tuple_index, file, file_stem, file_type, variable, phase, node_count}, …]
  session/
    chunk_0.json           ← raw intermediate chunk (same format as API session dir)
    …
```

### Step 2 — Run the explainer (`explain_cli.py`)

Reads the chunk output and calls the LLM for each tuple, printing explanations with accumulated story context. After all tuples are done, it makes one final synthesis LLM call and saves the result to `explain_session.json`.

```bash
# Dry-run: print prompts only, no LLM call
python explain_cli.py /tmp/lg1osi_chunks --dry-run

# Explain first 3 tuples (requires GEMINI_API_KEY)
GEMINI_API_KEY=your_key python explain_cli.py /tmp/lg1osi_chunks --max-tuples 3

# Explain all tuples (includes synthesis pass at end)
GEMINI_API_KEY=your_key python explain_cli.py /tmp/lg1osi_chunks
```

`--dry-run` prints the full prompt for each tuple including the "STORY SO FAR" section and FILE CONTEXT block, which is useful for inspecting prompt quality without spending API credits.

`--max-tuples N` explains tuples 0 through N-1 in order, with context accumulating between them — equivalent to clicking "Explain More" N times in the UI. The synthesis pass runs only when `--max-tuples` is not set (i.e. all tuples are explained).

---

## Caching Behaviour

Explanations are cached at two levels:

1. **In-memory**: not cached between requests (the session dict is loaded from disk on each request).
2. **On-disk**: `session["explanations"][str(idx)]` is checked before calling the LLM. If present, the cached text is returned immediately. This means re-calling `/explain-variable` with `start_tuple_index=0` a second time returns the cached explanation without any LLM call.

The explain session file is separate from the backward-lineage session. Deleting the explain session file resets all cached explanations for that backward session, forcing fresh LLM calls on the next request.

---

## Validation Results

The following variables were used to validate the Tier 1 and Tier 2 prompt improvements. All tests ran against the real codebase using `explain_cli.py` with Gemini 2.5 Flash.

| Variable | Chain | Tuples | Key findings |
|----------|-------|--------|-------------|
| `LG1OSI` | lu82 → dx750000 → dx710000 → dx730000 → dx740200 → da78 | 16 | Regression baseline; dep_var gate links (LBWTN, LBSTA, CE1FM5) now cited correctly at setter line |
| `WK_RRC` | lu82 → da76 | 5 | Short chain; cond_vars fix confirmed (no offset fragments in facts) |
| `WK_TIME` | lu82 → da76 | 9 | da76 dep_var chain: EBW000, L3TFCH, LYGCNT, WK_RRC, CE1FM5, L7AACT, WK_PACK8 all linked back to setter gate at line 627–654 |
| `WB1RCNBR` | lu82 → de82 | 4 | Business summary injection confirmed from de82 blueprint |

**Quality checks verified per variable:**
- Tuple 0 (modifier): setter instruction + line number + precondition chain cited
- Tuple 1+ (upstream): dispatch table / FUNCTION macro entry cited for lu82 routing
- dep_var tuples: gate-linking to root_variable setter line explicit in each explanation
- cond_vars in `tuple_facts`: no offset fragments (`0(2,`, `6(1,`) — only valid identifiers
- FILE CONTEXT block: blueprint `business_summary` visible in `--dry-run` prompt output
- Synthesis: 10–15 sentence unified narrative covering setter, preconditions, dep_var gates, and upstream routing

---

## Error Cases

| Condition | HTTP status | Detail |
|-----------|-------------|--------|
| KB not found or wrong owner | 404 | — |
| KB not in `"success"` state | 409 | `KB '{kb_id}' is not ready (status: …)` |
| `backward_session_id` not found | 404 | `Backward-lineage session '…' not found` |
| Session has zero tuples | 409 | `…has no tuples yet. Call backward-lineage/chunks at least once first.` |
| `start_tuple_index` out of range | 422 | `start_tuple_index={n} is out of range` |
| Tuple not yet assembled (race) | 409 | `Tuple {n} is not yet available in session '…'` |
| LLM content safety block | 500 | `LLM returned an empty response` |
