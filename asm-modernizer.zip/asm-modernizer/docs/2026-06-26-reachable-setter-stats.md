# Reachable-Setter Statistics — Pure JSON Post-Processor

**Date:** 2026-06-26  ·  **Branch:** dev_pratham_v4

## Goal

Add statistics to the `asm.vbt_reachable_setters` task output. The requirement: stats
must be a **pure post-processor** — "plug in the result JSON and get stats back" — not
logic welded into the task. And the stats must be the *best* reliable ones, which forced
two scope decisions (below).

## Scope decisions

Every reachable site is a **setter**. There is no declaration-vs-assignment split.

Stats rest **only on structural / graph facts**, never on the setter's source text. The
`code` / `value` (RHS expression) text is not reliably fetched, so anything derived from
it is excluded:

| Computed (trusted) | Excluded (unreliable) |
| :--- | :--- |
| `file_stem`, `function`, `language`, `line` | `code` / `value` source text |
| reachability `depth`, `paths`, `paths_truncated` | distinct-value counts, constant ratio, RMW ratio |
| | **conditional / guarded split** — conditions are absent from the setter record, and the layer that reconstructs them has documented guard-truncation issues |

Depth/paths are kept because they are the **exact output of the reachability check the
task already runs** (we merely stop discarding it), not a heuristic reconstruction.

## Design

```
asm.vbt_reachable_setters  ──enriched JSON──►  setter_stats.compute_stats
 (engine + DB; emits setters)  (+depth/paths/   PURE: json in → stats out
  + retains path metadata)       entry)         + CLI + graceful coverage
```

Two pieces: a **pure module** that computes stats from the JSON alone, and a **small task
enrichment** so that JSON carries the reachability facts the rich stats need.

### `api/tasks/setter_stats.py` (new)

Pure — no imports from `vbt.*` / DB / engine, so it is unit-testable without the
`index.db` fixture and runs on any saved output.

- `compute_stats(result)` — accepts the full result dict **or** a bare `variables`
  mapping; returns the `stats` block. Mutates nothing.
- Local **mirrors** of `_level_by_count` (low ≤2 / medium 3-6 / high >6) and
  `_languages_value` from `api/routes/setter_analysis.py`, plus `_depth_level`
  (low ≤4 / medium 5-9 / high >9, mirrors process complexity `max_call_depth`),
  `_max_level`, `_dim` (emits the `ComplexityDimension` `{key,label,value,level,detail}`
  shape). Kept local so the module stays standalone.
- `_dedup` by `(file_stem, function, line)`; `_field_coverage` probe drives graceful
  degradation — depth/paths stats are computed only when those fields are present, and
  coverage is reported under `stats["meta"]["field_coverage"]`.
- CLI: `python -m api.tasks.setter_stats result.json [-o out.json]`.

**Stats produced** — Tier 1 needs only the original record fields; Tier 2 needs the
enrichment:

- **Per-variable** — setter count (deduped + raw), unique files, unique functions,
  language mix + per-language counts, hotspot (the single `(file,function)` doing the
  most writes), entry-local count, complexity band (dimensions: setter_sites / files /
  languages / [depth], `overall_band` = max level), and reachability (min/max/avg depth,
  total paths, `any_truncated`).
- **Global** — active vs dead variables (counts + lists), total reachable setters,
  file/function footprint (union), shared-files & shared-functions coupling maps
  (`file → [vars]`, only entries touched by >1 variable), language distribution +
  percentages, complexity distribution, and worst-case `max_path_depth` (with its setter
  location).

### `api/tasks/vbt_reachable_setters_task.py` (modified)

- Hoisted a shared `cfg_cache = {}` across the variable loop (was a fresh `{}` per
  `enumerate_cpp_paths` call → no reuse). cfg is keyed by file, so reuse is safe and
  avoids re-parsing per setter.
- Stopped discarding the truncation flag: `cpp_paths, _` → `cpp_paths, cpp_trunc`.
- Per reachable setter, captured reachability metadata:
  - via `enumerate_cpp_paths`: `depth = min over paths of cross-file-edge count`
    (normalized to **file hops**), `paths = len(cpp_paths)`, `paths_truncated = cpp_trunc`.
  - via the `route.routes()` fallback: `depth = min(route["length"])`,
    `paths = route_count`, `paths_truncated = routes_capped`.
- Added `depth`, `paths`, `paths_truncated` to each emitted setter record (additive — the
  pre-existing `file_stem`/`language`/`line`/`function`/`code` keys are unchanged).
- Added top-level `"entry": {stem, function, file_type}` so stats can compute
  entry-local counts.
- Builds `result`, then `result["stats"] = compute_stats(result)` before returning.
- Fixed a latent bug: `code = getattr(s,"lhs_path", getattr(s,"instruction","")) or
  s.lhs_chain` → `getattr(s,"lhs_path",None) or getattr(s,"instruction","") or ""`.
  `SetterSite` has no `lhs_chain`, so the old tail could raise `AttributeError`.

## Validation

- **Unit (fixture-free):** `api/tasks/test_setter_stats.py` — 15 tests feeding hand-built
  JSON to `compute_stats`: band thresholds, dedup, files/functions/languages/hotspot,
  band precedence (high beats low/medium), language-crossing forces high, entry-local
  (present/absent), Tier-2 depth/paths, truncation propagation, graceful degradation
  (old minimal JSON → Tier-1 only), global active/dead + coupling, bare-mapping input.
- **Task test:** `api/tasks/test_vbt_reachable_setters_task.py` strengthened — asserts
  each record carries `depth`/`paths`/`paths_truncated`, the `stats` block is present,
  global counts/lists, `softCardValue` count + `overall_band == "high"`, and full field
  coverage.
- **Suite:** `api/tasks/` — 27 passed.
- **Live on `jobs/b58d8432…`** (`softCardValue` + `OnlineSourceInd`,
  entry `dw710000::callPlasticAuthenticationComponentInterface`):
  - `softCardValue` → 27 reachable setters, 2 files, 3 functions, all C++,
    hotspot `dw780000::selectCidDbRecord15` (24), entry-local 2, depth min 0 / max 1 /
    avg 0.93, `total_paths` 1610 with `any_truncated: true`, `overall_band: high`.
  - `OnlineSourceInd` → dead (0 setters), all-empty form.
  - Reachable setter counts unchanged vs before the change (no regression).
- **Purity proven:** ran the standalone CLI over the saved result JSON; its stats are
  byte-identical to the stats produced inline by the task.

## Notes

- Path/depth counts are capped (`max_paths=64`, `max_depth=16` for `enumerate_cpp_paths`).
  When the cap is hit, `any_truncated` is `true` and `total_paths` / `max_depth` are
  floors, not exact — the flag makes that explicit instead of silently under-counting.
