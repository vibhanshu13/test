# KB Variable APIs README

This document explains how to use the two knowledge-base APIs for:

1. Variable modifiers discovery
2. Backward-only variable lineage tracing

Both APIs are asynchronous and run through Celery.


## Endpoints Covered

- `POST /v1/knowledge-bases/{kb_id}/modifiers`
- `POST /v1/knowledge-bases/{kb_id}/backward-lineage`


## Authentication

These KB endpoints require JWT bearer auth.

Example login:

```bash
curl -sS -X POST "http://localhost:8000/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"username":"testadmin","password":"<password>"}'
```

Use the returned token:

```bash
export TOKEN="<access_token>"
export KB_ID="<your_kb_id>"
```


## Shared Async Flow

Each POST returns:

- `job_id`
- `celery_task_id`
- `operation`

Poll task state:

```bash
curl -sS "http://localhost:8000/v1/tasks/<celery_task_id>" \
  -H "Authorization: Bearer $TOKEN"
```

When complete, download output from `GET /v1/jobs/{job_id}/files/{path}`.


## API 1: Find Variable Modifiers

### Request

`POST /v1/knowledge-bases/{kb_id}/modifiers`

Body:

```json
{
  "variable_name": "LG1OSI",
  "max_depth": 10,
  "no_chains": false,
  "filter_subsets": true
}
```

### Parameters

- `variable_name`: required, non-empty string, max 128 chars
- `max_depth`: optional, integer `1..100`
- `no_chains`: optional, default `false`
- `filter_subsets`: optional, default `true`

### Validation/Preflight

- KB must exist and have `status=success`
- KB output directory must exist
- Blueprint files must exist (`*.asm.json`, optionally `*.mac.json`)
- If `no_chains=false`, `file_call_graph.json` must exist and be valid

### Output File

Written to:

- `jobs/{job_id}/output/variable_modifiers/{variable_name}_modifiers.json`

Download with:

```bash
curl -sS "http://localhost:8000/v1/jobs/${KB_ID}/files/variable_modifiers/LG1OSI_modifiers.json"
```


## API 2: Run Backward-Only Lineage

### Request

`POST /v1/knowledge-bases/{kb_id}/backward-lineage`

Body:

```json
{
  "variable_name": "LG1OSI",
  "chain_files": ["da76", "da78"],
  "max_depth": 8,
  "max_subroutine_depth": 2,
  "max_subroutine_nodes": 400,
  "max_trace_nodes": 5000,
  "max_dep_vars": 20,
  "max_dep_var_depth": 2,
  "max_downstream_depth": 2,
  "max_downstream_files": 30
}
```

### Parameters

- `variable_name`: required, non-empty string, max 128 chars
- `chain_files`: required list, at least 2 items, ordered `upstream...modifier`
- `max_depth`: `1..100`
- `max_subroutine_depth`: `0..20`
- `max_subroutine_nodes`: `50..5000`
- `max_trace_nodes`: `200..50000`
- `max_dep_vars`: `1..500`
- `max_dep_var_depth`: `0..10`
- `max_downstream_depth`: `0..10`
- `max_downstream_files`: `1..1000`
- `output_name`: optional filename only (no directories, no absolute path)
- `asm_dir`: optional absolute path to asm source dir (must exist if provided)

Rule:

- `max_subroutine_nodes <= max_trace_nodes`

### Validation/Preflight

- KB must exist and have `status=success`
- KB output and `file_call_graph.json` must exist
- `chain_files` entries must exist in call graph node IDs
- Last entry in `chain_files` must be a real modifier for `variable_name`:
  - corresponding `{stem}.asm.json` or `{stem}.mac.json` exists
  - contains at least one SETTER hit for the variable

### Output File

Written to:

- `jobs/{job_id}/output/backward_lineage/{variable_name}_backward_lineage.json`

Download with:

```bash
curl -sS "http://localhost:8000/v1/jobs/${KB_ID}/files/backward_lineage/LG1OSI_backward_lineage.json"
```


## Suggested End-to-End Usage

1. Run modifiers API for target variable.
2. Open `variable_modifiers/{variable}_modifiers.json`.
3. Select a valid chain from `results.<modifier>.call_chains[*].files` where last file is modifier.
4. Call backward-lineage API with that `chain_files`.
5. Poll task status.
6. Download backward lineage output JSON.


## Notes

- Current behavior reuses KB workspace (`job_id == kb_id`) for these KB APIs.
- Files are namespaced in subfolders:
  - `output/variable_modifiers/`
  - `output/backward_lineage/`


## Using Existing GET APIs to Read Results

There is no dedicated `GET /v1/knowledge-bases/{kb_id}/modifiers` or
`GET /v1/knowledge-bases/{kb_id}/backward-lineage` endpoint today.

Use the existing generic output APIs:

1. List files for a KB:

```bash
curl -sS "http://localhost:8000/v1/knowledge-bases/${KB_ID}/files" \
  -H "Authorization: Bearer $TOKEN"
```

2. Download from KB files endpoint:

```bash
# Modifiers output
curl -sS "http://localhost:8000/v1/knowledge-bases/${KB_ID}/files/variable_modifiers/LG1OSI_modifiers.json" \
  -H "Authorization: Bearer $TOKEN"

# Backward lineage output
curl -sS "http://localhost:8000/v1/knowledge-bases/${KB_ID}/files/backward_lineage/LG1OSI_backward_lineage.json" \
  -H "Authorization: Bearer $TOKEN"
```

3. Download from jobs endpoint (same workspace in current design):

```bash
# job_id == kb_id in current KB API flow
curl -sS "http://localhost:8000/v1/jobs/${KB_ID}/files/variable_modifiers/LG1OSI_modifiers.json"
curl -sS "http://localhost:8000/v1/jobs/${KB_ID}/files/backward_lineage/LG1OSI_backward_lineage.json"
```

4. List all job result files:

```bash
curl -sS "http://localhost:8000/v1/jobs/${KB_ID}/results"
```


## Testing Summary (What Was Validated)

The APIs in this document were tested end-to-end with in-process API calls and
task execution:

- `POST /v1/knowledge-bases/{kb_id}/modifiers`:
  - accepted valid payloads (`202`)
  - wrote output to `output/variable_modifiers/{variable}_modifiers.json`
  - output downloadable through `GET /v1/jobs/{job_id}/files/...` (`200`)
  - invalid payloads rejected with `422` (empty variable, invalid max_depth, etc.)

- `POST /v1/knowledge-bases/{kb_id}/backward-lineage`:
  - accepted valid payloads (`202`)
  - wrote output to `output/backward_lineage/{variable}_backward_lineage.json`
  - output downloadable through `GET /v1/jobs/{job_id}/files/...` (`200`)
  - invalid payloads rejected with `422` (short chain, invalid chain node,
    invalid `asm_dir`, wrong modifier, inconsistent limits)

- Multi-KB behavior:
  - both APIs were executed on more than one KB/job ID
  - verified no hardcoded job ID pathing in runtime behavior
  - outputs were created under each target KB’s own `jobs/{kb_id}/output/...` tree
