# Variable Universe - Quick Start Guide

## What is the Variable Universe?

A two-pass system that:
1. **Pass 1:** Discovers all variables in your codebase
2. **Pass 2:** Enriches lineage tracking with operation types and conditional context

## Quick Start (3 Steps)

### 1. Build the Universe

```bash
python universe_builder.py <your_source_directory> --output output/
```

**Example:**
```bash
python universe_builder.py test_data/ --output output/
```

**Output:**
```
output/
├── asm_variable_universe.json      # Full ASM metadata
├── asm_variable_names.json         # ASM variable list
├── cpp_variable_universe.json      # Full C++ metadata
└── cpp_variable_names.json         # C++ variable list
```

### 2. Run Parser with Universe

```bash
python main.py <your_files> --load-universe
```

**Example:**
```bash
python main.py test_data/*.asm --load-universe --output-dir output/
```

### 3. Check Enriched Output

```bash
# View enriched lineage edges
cat output/yourfile.asm.json | jq '.variable_lineage.edges[] | select(.operation_type)'
```

**Expected enriched fields:**
- `operation_type`: move, compare, load, store, arithmetic, etc.
- `conditional_context`: List of conditions affecting the variable
- `transformation`: Human-readable description
- `initialization_method`: How variable was initialized

## What Gets Tracked?

### ASM Variables
✅ Memory locations (DS, DC)
✅ Constants (EQU)
✅ External symbols (EXTRN, WXTRN)
❌ Registers (still in lineage, just not in universe)
❌ Section names (CSECT, DSECT, RSECT)

### C/C++ Variables
✅ Local variables
✅ Function parameters
✅ Global variables
✅ Class/struct members
✅ Static variables

## Example Output

**Without Universe:**
```json
{
  "source": "memory:BUFFER",
  "target": "register:R1",
  "relation": "assign",
  "file": "app.asm",
  "line": 100
}
```

**With Universe:**
```json
{
  "source": "memory:BUFFER",
  "target": "register:R1",
  "relation": "assign",
  "file": "app.asm",
  "line": 100,
  "operation_type": "load",
  "conditional_context": ["CLC BUFFER,=C'READY' -> BNE"],
  "transformation": "Load BUFFER into R1"
}
```

## Command Reference

### Universe Builder

```bash
# Basic usage
python universe_builder.py <directories> --output <output_dir>

# Multiple directories
python universe_builder.py src/ lib/ include/ --output output/

# ASM only
python universe_builder.py src/ --asm-only --output output/

# C++ only
python universe_builder.py src/ --cpp-only --output output/
```

### Main Parser

```bash
# With universe
python main.py <files> --load-universe

# Specify universe directory
python main.py <files> --load-universe --universe-dir my_universe/

# Without universe (standard mode)
python main.py <files>
```

## Troubleshooting

**Problem:** `Warning: ASM universe file not found`
**Solution:** Run `universe_builder.py` first

**Problem:** No enriched metadata in output
**Solution:** Add `--load-universe` flag to `main.py`

**Problem:** Variable not tracked
**Solution:** Check if it's in universe (might be register, macro param, or section name)

## What's Next?

See full documentation:
- `docs/variable-universe.md` - Complete user guide
- `docs/implementation-summary.md` - Technical details

## Backward Compatibility

✅ Old workflow still works (don't use `--load-universe`)
✅ Existing JSON outputs remain valid
✅ No breaking changes

The universe system is **opt-in** and **fully backward compatible**.
