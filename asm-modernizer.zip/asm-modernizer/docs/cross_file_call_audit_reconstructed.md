# Blueprint Audit Report: Cross-File Call Detection in TPF ASM/C++ Codebase

---

## Preliminary: data quality note on C++ line numbers

Every edge in a `.cpp.json` file records the **function definition start line** as `"line"`, not the individual call-site line. Every edge belonging to `processAccountMaintenance` has `"line": 280`; every edge in `globalLimitsUpdate` has `"line": 281`; etc. This is a known limitation of the C++ parser (function-level granularity only). It does **not** break correctness of the bridge, but `raw_line` will always point at the function header, not the actual call.

---

## Q1 — ASM → ASM calls

### What was found

Three families of call instructions appear as cross-file edges:

**a) `ENTRC` — primary cross-file subroutine call (108 edges)**

```json
{"source":"DA760000","target":"DA78","call_type":"subroutine_call",
 "instruction":"ENTRC","is_indirect":false,"line":334}

{"source":"XH881370","target":"XH93","call_type":"subroutine_call",
 "instruction":"ENTRC","is_indirect":false,"line":608}
```

`edge.target` is always the callee file stem in ALL-CAPS (e.g., `"DA78"`, `"XH93"`, `"DB73"`, `"DX76"`).

**b) `ENTNC` — no-return cross-file call (10 edges)**

```json
{"source":"DA7_0100","target":"DA78","call_type":"no_return_call",
 "instruction":"ENTNC","is_indirect":false,"line":383}

{"source":"XH820900","target":"XH88","call_type":"no_return_call",
 "instruction":"ENTNC","is_indirect":false,"line":321}
```

Same structure as `ENTRC`. `edge.target` is the callee file stem.

**c) `FUNCTION` — TPF dispatch-table macro (192 edges in `lu82` alone) — undocumented**

```json
{"source":"LU8X100","target":"DA76","call_type":"no_return_call",
 "instruction":"FUNCTION","is_indirect":false,"line":654}

{"source":"LU8X100","target":"DX75","call_type":"no_return_call",
 "instruction":"FUNCTION","is_indirect":false,"line":624}
```

`FUNCTION` is a locally-defined macro in `lu82.asm` that compiles a routing table — `FUNCTION C126,DX75` means "when function code `C126` arrives, enter segment `DX75`". The parser captures the second argument (`&SEG`) as `edge.target` and the instruction as `"FUNCTION"`. `edge.target` is the callee file stem or callee entry-point name. `call_type` is `no_return_call`.

**d) `CREEC`, `CREMC`, `SWISC` — rare no-return calls (1–2 edges each)**

```json
{"source":"DA7_4000","target":"GA71","call_type":"no_return_call","instruction":"CREEC"}
{"source":"ZERO_MCC_EXPI","target":"VW77","call_type":"no_return_call","instruction":"CREMC"}
{"source":"CM_80_010","target":"GA71","call_type":"no_return_call","instruction":"SWISC"}
```

`edge.target` is the callee file stem. All handled by name-match.

**e) `BAS` (606 edges) — ALWAYS intra-file**

All 606 `BAS` edges target **local labels** with the file's own prefix (e.g., `XH881000`, `DA7_8100`, `XH883000`). None cross file boundaries. The name-matching logic will never match a file stem against these.

**f) System macros (`LEVTA`, `ISCFA`, `ATTAC`, `DETAC`, `DBRED`, `DBOPN`, etc.)**

All are `call_type=macro_invocation` and `target=<macro_name>` (e.g., `target="ATTAC"`, `target="DBRED"`). These are system call macros, not inter-module calls. They will never match a callee file stem.

### Does the current code handle it?

**Yes, completely** — `find_asm_callers()` uses:

```python
if (edge.get("target") or "").upper() != callee_upper:
    continue
```

This matches `ENTRC`, `ENTNC`, `FUNCTION`, `CREEC`, `CREMC`, and `SWISC` edges, since all of them store the callee file stem in `edge.target`. No instruction filter is applied, so new instruction types work automatically.

### What needs to change

Nothing breaks. One documentation gap: **`FUNCTION` (with `call_type=no_return_call`) accounts for 192+ cross-file edges in `lu82`** and is not listed anywhere in the code comments or specification. Add a comment in `find_asm_callers()` noting that `FUNCTION`, `ENTRC`, `ENTNC`, `CREEC`, `CREMC`, and `SWISC` are all covered by the single target-name comparison.

One minor parser artifact: line 368 of `lu82.asm` is the `FUNCTION` macro definition itself — the parser incorrectly emits an edge `{"target": "&SEG"}` for it. This won't match any real callee stem (the literal string `&SEG` won't equal `xh80` etc.), so it causes no false positives. But it should be filtered in the parser.

---

## Q2 — C++ → ASM calls

### What was found

Two instruction types appear for C++→ASM edges, both correctly using the ASM stem as target:

**a) `CALL_ALIAS` + `call_type=subroutine_call` — `#pragma map`-aliased calls (primary mechanism)**

```json
{"source":"globalLimitsUpdate","target":"DA78","call_type":"subroutine_call",
 "instruction":"CALL_ALIAS","file":"dx740200.cpp","line":281}

{"source":"cardCasAccountMaintenance","target":"XH80","call_type":"subroutine_call",
 "instruction":"CALL_ALIAS","file":"dx740100.cpp","line":452}

{"source":"callMessageMonitor","target":"DE70","call_type":"subroutine_call",
 "instruction":"CALL_ALIAS","file":"dx730000.cpp","line":314}
```

`edge.target` is the callee ASM file stem exactly (4–6 ALL-CAPS chars).

**b) `CALL` + `call_type=call` — direct `extern "C"` calls**

```json
{"source":"processAccountMaintenance","target":"NB81","call_type":"call",
 "instruction":"CALL","file":"dx710000.cpp","line":280}

{"source":"maintainPreAuthParm","target":"NB81","call_type":"call",
 "instruction":"CALL","file":"dx740500.cpp","line":141}

{"source":"enrollmentDateMaintenance","target":"AN71","call_type":"call",
 "instruction":"CALL","file":"dx740300.cpp","line":102}
```

`edge.target` is again the uppercase ASM symbol/stem.

### Does the current code handle it?

**Yes.** `find_cpp_callers()` simply does:

```python
if edge.get("target", "").upper() == callee_upper:
```

This matches both `CALL` and `CALL_ALIAS` edges without needing to inspect `instruction`.

### What needs to change

Nothing in the matching logic. However, note the **line-number quality issue**: all edges in `processAccountMaintenance` report `"line": 280` (the function header). Consumers of `raw_line` should be warned this is the function definition line, not the individual call-site line.

---

## Q3 — ASM → C++ calls

### What was found

**`asm_entry_point_map` is present in every `.cpp.json`** (16/16 files). It uses identity mappings throughout this codebase — every entry maps a camelCase name to itself:

```json
dx740200.cpp.json: {"globalLimitsUpdate":"globalLimitsUpdate","getDateAndTime":"getDateAndTime",...}
dx750000.cpp.json: {"DX75":"DX75"}
xh890000.cpp.json: {"XH89":"XH89","deleteGlAccount":"deleteGlAccount","deleteAllGLoSLrec":"deleteAllGLoSLrec"}
```

The key insight: when the C++ function name is also the ASM-callable name (no `asm("...")` alias or `#pragma map` renaming), the identity mapping `name ↔ name` is what `asm_entry_point_map` contains. The code uses the **keys** as ASM names to match against `edge.target` — fully correct.

**Matching an ASM `FUNCTION` dispatch to a C++ module works** because:
- `lu82` has `FUNCTION &NAME,DX75` edges with `target="DX75"`
- `dx750000.cpp.json`'s `asm_entry_point_map` has key `"DX75"`
- `find_asm_to_cpp_callers("lu82","dx750000",...)` will find those `FUNCTION` edges

### Does the current code handle it?

**Yes, for all blueprints in this corpus.** No "old blueprints without `asm_entry_point_map`" exist here — all 16 have it. The fallback to `entry`-type global symbols is not exercised.

### What needs to change

Nothing functionally. One precaution: if a future C++ file uses `asm("ALIAS")` to give the function a **different** ASM-callable name from the C++ name, the `asm_entry_point_map` would have a non-identity pair (e.g., `"ALIAS": "cppFunctionName"`). That is exactly what the map is designed for — the code will handle it correctly.

---

## Q4 — `find_variable_modifiers.py` C++ gap

### What was found

**All `.cpp.json` blueprints have `"blocks": []` (an empty array).**

```
dx740200.cpp.json: total blocks: 0
dx710000.cpp.json: (same)
...all 16 cpp.json files: blocks = []
```

There is **no `blocks[].flow[]` data** in C++ blueprints. The C++ parser does not emit block-level flow information.

### Does the current code handle it?

The code on line 457 of `find_variable_modifiers.py` only globs `*.asm.json`:

```python
blueprint_files = sorted(blueprint_dir.glob("*.asm.json"))
```

This is **correct given the data format**. Even if you changed the glob to include `*.cpp.json`, `scan_blueprint_for_setters()` would iterate `blueprint.get("blocks", [])` → empty list → 0 hits for every C++ file.

### What needs to change

This is a **parser gap, not a code bug**. The C++ blueprint format doesn't record variable-level flow. To detect C++ modifications of variables you would need either:

1. The C++ parser to be extended to emit a `blocks[].flow[]` structure analogous to ASM blueprints (field writes, struct assignments, `memcpy`/`memset` targets), OR
2. A separate C++ source scanner that reads the `.cpp` files directly.

No change to `find_variable_modifiers.py` is needed or useful until the parser is enhanced. Add a comment to the `blueprint_files` line noting this limitation explicitly.

---

## Q5 — Patterns that might be incomplete

### Dynamic dispatch / indirect calls

`is_indirect=true` edges: **NONE FOUND** (0 across all ~2500 edges in all files).

`is_indirect` is `false` for every single edge. The parser does not capture register-indirect branches (`BR R14`, `BCR 15,R15`) or C++ function pointers as call edges.

**If any cross-file call in this codebase uses a computed address, it will be completely absent from `call_graph.edges`.**

This is unlikely to affect the currently-known call chains (all known cross-file calls use explicit symbol names), but it is an architectural blind spot.

### Macro-expanded cross-file calls

**`FUNCTION` (`lu82` dispatch table):** The macro `FUNCTION &NAME,&SEG` expands to a table entry + `ENTDC &SEG`. The parser records one `call_graph.edges` entry per `FUNCTION` invocation with `instruction="FUNCTION"` and `target=&SEG`. The actual `ENTDC` inside the macro also appears as a separate edge with `target="ENTDC"` (the macro name, not a file stem). Only the `FUNCTION` edge contains the callee module — that is the one the bridge uses.

### `ATTAC` / `DETAC` (TPF storage level operations)

```json
{"source":"DA7_1900","target":"ATTAC","call_type":"macro_invocation","instruction":"ATTAC","level_number":2}
{"source":"DA780000","target":"DETAC","call_type":"macro_invocation","instruction":"DETAC","level_number":4}
```

`ATTAC` and `DETAC` are TPF macros for **attaching/detaching program-controlled storage pools** — they are NOT inter-module program calls. Target is the literal macro name `"ATTAC"` / `"DETAC"`. They will never match a callee file stem. Not a gap.

### External loads (`LOAD`, `XCTL`, `LINK`, `LINKX`, `ATTACH`, `SVC`)

**None of these appear in any blueprint edge.** Either this codebase does not use them for cross-module calls, or the parser does not capture them. Not actionable with current data.

### `#pragma map` / `asm("...")` alias discrepancy

Not found as a problem. All `CALL_ALIAS` edges in C++ blueprints correctly name the target ASM file stem (e.g., `"XH80"`, `"DA78"`, `"DE70"`). The `asm_entry_point_map` in the callee C++ blueprints contains those exact names as keys. The mapping is consistent end-to-end.

---

## Summary table

| Question | Gap level | Root cause | Fix needed |
|---|---|---|---|
| Q1 ASM→ASM `ENTRC` / `ENTNC` | ✅ Works | Target-name match | None |
| Q1 ASM→ASM `FUNCTION` (192 edges in `lu82`) | ⚠️ Works, undocumented | Same target-name match | Add comment only |
| Q1 ASM→ASM `BAS` (all local) | ✅ Works | Local labels ≠ file stems | None |
| Q1 `CREEC` / `CREMC` / `SWISC` | ✅ Works | Target-name match | None |
| Q2 C++→ASM `CALL_ALIAS` | ✅ Works | Target-name match | None |
| Q2 C++→ASM `CALL` (extern C) | ✅ Works | Target-name match | None |
| Q2 C++ line granularity | ⚠️ Cosmetic | Parser limitation | Document in output |
| Q3 ASM→C++ via `asm_entry_point_map` | ✅ Works | Identity map, correct keys | None |
| Q3 Missing `asm_entry_point_map` | N/A | All 16 `cpp.json` files have it | None (watch for new files) |
| Q4 C++ variable modifiers invisible | 🔴 Data gap | `cpp.json` `blocks[]` always empty | Parser must be extended |
| Q5 Indirect/register calls | 🔴 Blind spot | `is_indirect` never set; parser limitation | Document as known limitation |
| Q5 `FUNCTION` macro-expanded dispatch | ✅ Works (see Q1) | Same target-name match | None |
| Q5 `ATTAC`/`DETAC`/`SVC`/`LOAD`/`XCTL` | ✅ Not inter-module or not present | — | None |

### The two hard gaps requiring action

1. **`find_variable_modifiers.py` cannot see C++ variable writes** — `cpp.json` has no `blocks[].flow[]` data. Fix requires extending the C++ parser to emit flow-level setter information, not a change to `find_variable_modifiers.py` itself.

2. **Indirect/register calls are invisible** — `is_indirect` is never `true` in any blueprint. Any cross-file call made via a computed address (function pointer, branch through register) won't appear in `call_graph.edges` at all. This is a parser gap, not a `cross_file_bridge.py` gap. Document it as a known limitation.
