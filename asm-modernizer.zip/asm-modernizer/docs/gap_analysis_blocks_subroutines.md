# Gap Analysis: Current Parser Output → Expected `input_structure.txt` Format

## Overview

This document analyzes whether the current parser output (e.g., `ACCTUPDT.asm.json`) can be mapped
via a transformer to produce the structure defined in `input_structure.txt`.

---

## Expected Structure (3 top-level keys)

```json
{
  "file": "da76.asm",
  "blocks": [...],
  "subroutines": [...]
}
```

---

## Blocks Structure

Each block represents a label-delimited section of code with control flow:

```json
{
  "id": "DA760000",
  "flow": [
    {
      "line": 327,
      "inst": "FETCHC",
      "args": ["D7", "L2   1K FOR WK_BLK"]
    },
    {
      "line": 349,
      "inst": "MVC",
      "var": "WK_RCE",
      "val": "ZEROS  INITIALIZE RESPONSE CODE"
    }
  ],
  "incoming_branches": ["SLOTLENG"]
}
```

**Notes on `flow` elements:**
- Branch/call instructions use `args` array
- Memory move instructions (MVC, MOVEX, etc.) use `var` (destination) and `val` (source)
- `args` and `var`/`val` are mutually exclusive per instruction

---

## Subroutines Structure

```json
{
  "id": "DA7_8000",
  "start_line": 957,
  "end_line": 982,
  "called_by": ["DA7_0050", "DA7_0500"]
}
```

---

## Current Parser Output Structure

Top-level keys emitted today:

```
metadata, symbol_aliases, symbols, call_graph, db_operations,
file_dependencies, macro_expansions, macro_errors,
variable_lineage, global_variable_lineage, build_metadata, line_metadata
```

---

## Field-by-Field Mapping Analysis

### `blocks[*]` Fields

| Field | Status | Detail |
|-------|--------|--------|
| `id` (label name) | ✅ Available | Directly in `call_graph.nodes` keys |
| `flow[*].line` | ✅ Available | In `call_graph.edges[].line` |
| `flow[*].inst` | ✅ Available | In `call_graph.edges[].instruction` |
| `flow[*].args` | ❌ Gap | `ParsedLine.operands[]` is parsed internally but never emitted to JSON |
| `flow[*].var` / `flow[*].val` | ❌ Gap | Structured operand split (dest/source) is not emitted |
| `incoming_branches` | ⚠️ Derivable | Filter `call_graph.edges` where `target == block_id` |
| Block boundary grouping | ❌ Gap | Parser tracks branch edges but NOT sequential instructions within a block |

### `subroutines[*]` Fields

| Field | Status | Detail |
|-------|--------|--------|
| `id` | ✅ Available | In `call_graph.nodes` |
| `start_line` | ⚠️ Derivable (heuristic) | Approximate from first edge referencing this label; no explicit tracking |
| `end_line` | ❌ Gap | No "end of subroutine" marker in output; requires next-label heuristic |
| `called_by` | ⚠️ Derivable | Filter `call_graph.edges` where `call_type == "subroutine_call"` and `target == id` |

---

## What CAN Be Built from Current Output (~40%)

- Block IDs and subroutine IDs
- `incoming_branches` — reverse-index `call_graph.edges` by target
- `called_by` — filter edges by `call_type == "subroutine_call"` and target
- Line numbers for instructions that are branch/call points

---

## What CANNOT Be Built — True Parser Gaps (~60%)

### 1. Block Flow Sequences
The parser tracks control-flow *edges* (branches between labels) but does **not** group sequential
instructions into their enclosing labeled block. There is no data structure saying "lines 318–325
belong to block `DA760000`." To build `flow[]`, you need label boundaries + all lines between them
with their structured operands.

### 2. Structured Operands (`args` / `var` / `val`)
`ParsedLine.operands[]` is parsed internally but never emitted to JSON. The
`call_graph.edges[].instruction` field only stores the raw opcode string — not a structured operand
list. Reconstructing `args` vs `var`/`val` requires either re-parsing the original ASM or exposing
`ParsedLine.operands` in the output.

### 3. Subroutine End Lines
Nothing in the current output marks where a subroutine ends. Building `end_line` would require a
heuristic (e.g., "the line before the next label definition or next CSECT") applied against the
original line sequence — data that is not preserved in the JSON.

---

## Bottom Line

A mapper alone **cannot produce the full expected structure**. The parser needs to emit two new
things natively:

1. **Block/instruction sequences** — for each labeled block, the ordered list of all instructions
   with structured operands (`args` or `var`/`val`)
2. **Subroutine line ranges** — explicit `start_line` and `end_line` per subroutine

The existing `call_graph` and `line_metadata` already cover call/branch relationships, so
`incoming_branches` and `called_by` can be derived without parser changes.

---

## Recommended Path Forward

| Option | Effort | Result |
|--------|--------|--------|
| **A — Minimal mapper only** | Low | Produces block IDs + incoming_branches + subroutine IDs + called_by. No `flow[]`, no line ranges. |
| **B — Mapper + operand re-parsing** | Medium | Adds `flow[]` by re-parsing original ASM text; heuristic subroutine boundaries. Fragile. |
| **C — Parser enhancement (recommended)** | High | Extend `JSONEmitter` to natively emit `blocks` and `subroutines`. Expose `ParsedLine.operands`. Add label-boundary tracking. Clean, accurate, no inference. |
