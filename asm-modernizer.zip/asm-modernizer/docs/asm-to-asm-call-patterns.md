# ASM-to-ASM Call Chain Traversal Patterns

This document describes all the different ASM to ASM function calling
patterns handled by the `/cpp-call-chain` API endpoint, covering both
**forward** (callees) and **backward** (callers) BFS traversal directions.

Reference implementation: `cpp_call_chain/traversal.py`

---

## Table of Contents

1. [Forward Traversal Patterns](#1-forward-traversal-patterns)
2. [Backward Traversal Patterns](#2-backward-traversal-patterns)
3. [Intra-File Calling Instructions](#3-intra-file-calling-instructions)
4. [Inter-File Calling Instructions](#4-inter-file-calling-instructions)
5. [Return Instructions](#5-return-instructions)
6. [Concrete Calling Patterns in the Codebase](#6-concrete-calling-patterns-in-the-codebase)
7. [IBM / z/TPF Conventions](#7-ibm--ztpf-conventions)
8. [Coverage Gap: Inter-File ASM to ASM Forward](#8-coverage-gap-inter-file-asm-to-asm-forward)
9. [Summary Table](#9-summary-table)
10. [Configuration Parameters](#10-configuration-parameters)

---

## 1. Forward Traversal Patterns

Forward traversal answers: **"What does this ASM routine call?"**

### 1.1 Intra-File Blueprint Edge Traversal

When an ASM routine is being traversed, its blueprint (`*.asm.json`) is
loaded and all intra-file edges are followed. This covers BAS, BALR, JAS
and other branch-and-save instructions within the same ASM file.

- **Source:** ASM blueprint `call_graph.edges` where `edge.source == method`
- **Code:** `traversal.py:549-613` (same language-agnostic loop as CPP)
- **How it works:** `_load_cg(fstem, blueprint_dir)` tries `{fstem}.cpp.json`,
  `{fstem}.asm.json`, then `{fstem}.mac.json`. Iterates edges where
  `source == method` and enqueues each intra-file target.
- **Edge properties preserved:** `call_type` (e.g. `"subroutine_call"`),
  `instruction` (e.g. `"BAS"`, `"BALR"`), `line`, `is_indirect`

```
Example intra-file edge in ASM blueprint:
  {source: "DA760000", target: "DA7_8000", call_type: "subroutine_call",
   instruction: "BAS", line: 104}
```

### 1.2 Inter-File Blueprint Edge Traversal

ASM routines calling routines in OTHER ASM files (e.g., `ENTRC XH85`
from `xh80.asm`) are also captured as edges in the source file's blueprint.

- **Source:** Same blueprint `call_graph.edges` where `edge.source == method`
- **Code:** `traversal.py:549-613`
- **How it works:** The inter-file target appears as a node in the source
  blueprint's `nodes` dict with its `file` path set to the target file.
  `_file_stem(t_fp)` extracts the target's file stem, and the next BFS
  iteration loads the target file's blueprint.
- **Limitation:** Depends on the blueprint generator populating the target
  node's `file` field correctly. If the file path is empty, the traversal
  cannot load the target's blueprint for further expansion.
- **Edge properties:** `call_type="subroutine_call"`, `instruction="ENTRC"`
  (or `"ENTNC"`, `"ENTDC"`)

```
Example inter-file edge in xh80.asm.json:
  {source: "XH80_MAIN", target: "XH85", call_type: "subroutine_call",
   instruction: "ENTRC", line: 401, is_external: true}
```

### 1.3 Cross-Language Index (NOT Used for ASM→ASM)

The cross-language index (`cross_lang.forward`) is built from
`file_call_graph.json` but **intentionally excludes same-language edges**.

- **Code:** `index_builder.py:632` — `if src_type == tgt_type: continue`
- **Impact:** ASM→ASM inter-file edges are NOT in the cross-language
  index. Forward traversal relies solely on blueprint edges (pattern 1.2)
  for inter-file ASM→ASM calls.

### 1.4 Indirect Call from ASM (Resolved Target)

Register-indirect calls where static analysis resolves the target to
another ASM routine.

- **Source:** ASM blueprint edge with `is_indirect=true` and a known `target`
- **Code:** `traversal.py:555-560` (flag extraction and opt-out filter),
  `traversal.py:598-613` (enqueue with indirection envelope)
- **How it works:** Edge has `is_indirect=true` and a `register` field
  (e.g. `"R15"`). If `include_indirect_calls` is false, the edge is
  skipped at line 560. Otherwise the resolved target is enqueued at
  lines 598-613 with an indirection envelope attached at lines 606-610:
  `{is_indirect: true, indirect_via: "R15"}`
- **Controlled by:** `include_indirect_calls` parameter
- **Common ASM pattern:** `BALR R14,R15` where R15 was loaded with a
  known address.

### 1.5 Indirect Call from ASM (Unresolved Target)

When an ASM indirect call cannot be resolved to a concrete target.

- **Source:** ASM blueprint edge with `is_indirect=true` and **no target**
- **Code:** `traversal.py:563-587`
- **How it works:** Creates a synthetic leaf node named `(indirect via R15)`
  or similar. BFS does not continue through it.

```asm
; Example — unresolved indirect in ASM
         L     R15,FUNC_TABLE(R4)   ; Load from jump table
         BALR  R14,R15              ; Branch and link (unresolved target)
```

### 1.6 ASM Metadata Resolution Fallback

When an ASM routine is not in the definitions index, metadata is extracted
directly from the blueprint.

- **Source:** ASM blueprint `call_graph.nodes[method]`
- **Code:** `traversal.py:165-189` (`_resolve_node_from_blueprint`)
- **When used:** For any node where `language != "cpp"` and the definitions
  index has no entry (lines 434-435).

### 1.7 No Source Fallback for ASM

Unlike CPP nodes, ASM nodes have no source fallback. When an ASM
blueprint is missing, a warning is emitted but no source scanning occurs.

- **Code:** `traversal.py:540-544`
- **Warning:** `"ASM blueprint not found for '{fstem}'; callees of '{method}' may be incomplete."`

---

## 2. Backward Traversal Patterns

Backward traversal answers: **"Who calls this ASM routine?"**

### 2.1 Pre-Built Callers Index Lookup

The primary backward mechanism. The callers index is built from ALL
blueprints (CPP, ASM, MAC) and contains ASM→ASM caller entries.

- **Source:** `index.callers[method_name]` — built at index time from all
  `*.asm.json`, `*.cpp.json`, and `*.mac.json` blueprints
- **Code:** `traversal.py:757`
- **How it works:** For any method, looks up all callers in the pre-built
  index. ASM→ASM inter-file callers ARE present because the index builder
  processes all blueprint types without language filtering.
- **Code (index builder):** `index_builder.py:183-206` — caller entries
  extracted from every edge in every blueprint.

```python
# The callers index contains entries from ALL languages:
callers_idx["XH85"] = [
    # ASM→ASM inter-file caller
    {"caller_func": "XH80_MAIN", "file_stem": "xh80",
     "call_type": "subroutine_call", "instruction": "ENTRC", ...},
    # ASM→ASM intra-file caller (also in index)
    {"caller_func": "CM_UPDATES", "file_stem": "xh80",
     "call_type": "subroutine_call", "instruction": "BAS", ...},
]
```

### 2.2 ASM Blueprint Edge Inversion (Intra-File)

In addition to the callers index, backward traversal loads the ASM
blueprint and inverts edges to find intra-file callers.

- **Source:** ASM blueprint edges where `edge.target == method`
- **Code:** `traversal.py:759-780`
- **How it works:** Only runs when `language in ("asm", "mac")`. Loads the
  blueprint, iterates all edges, finds those where `target == method`.
  The `source` of each matching edge is treated as a caller.
- **Why both index AND inversion?** The callers index may not capture all
  intra-file edges (depending on blueprint processing), so edge inversion
  serves as a safety net. Duplicate callers are filtered by the visited set.

### 2.3 Cross-Language Index (NOT Used for ASM→ASM)

Same as forward — the cross-language backward index excludes same-language
edges.

- **Code:** `index_builder.py:632` — same-language edges skipped
- **Impact:** Backward ASM→ASM discovery relies on the callers index
  (pattern 2.1) and blueprint edge inversion (pattern 2.2), not the
  cross-language backward map.

### 2.4 No Source Fallback for ASM Backward

Source fallback scanning only applies to CPP nodes at depth 0.

- **Code:** `traversal.py:782-809` (guarded by `language == "cpp"`)

### 2.5 Backward CHA Expansion

When backward-traversing from a derived-class method (e.g.,
`Derived::foo`), callers of the base-class method (`Base::foo`) may
dispatch to `Derived::foo` at runtime via virtual dispatch. Backward CHA
expansion ensures those callers are also discovered.

- **Code:** `traversal.py:318-370` (`_apply_cha_expansion_backward`)
- **Traversal call site:** `traversal.py:840-853`
- **Controlled by:** `expand_virtual_dispatch` parameter
- **Only triggers when:** method name contains `::`

---

## 3. Intra-File Calling Instructions

These are z/Architecture instructions used for subroutine calls within
the same ASM file. They appear as blueprint edges with both `source` and
`target` in the same file.

### 3.1 BAS — Branch and Save

The primary intra-file call mechanism. Saves the return address in a
register and branches to a label.

- **Syntax:** `BAS Rx,<label>`
- **Typical registers:** R14 (standard linkage) or R10 (alternate)
- **Return:** YES — caller uses `BR Rx` to return
- **Call graph edge:** `call_type="subroutine_call"`, `instruction="BAS"`
- **Prevalence:** Most common intra-file call. Hundreds of instances across
  the codebase.

```asm
; Source: da76.asm:104
         BAS   R14,DA7_8000           GET DATE/TIME STAMP
; ...
DA7_8000 EQU   *                      ; Subroutine entry point
         ; ... body ...
         BR    R14                    ; Return to caller
```

### 3.2 BALR — Branch and Link Register

Register-indirect variant. Both target and return address use registers.

- **Syntax:** `BALR Rx,Ry`
- **Behaviour:** Saves return address in Rx, branches to address in Ry
- **Return:** YES — via `BR Rx`
- **Call graph edge:** May be marked as indirect if target register value
  is computed at runtime
- **Use case:** Computed dispatch, jump tables, or when the target address
  is loaded from memory.

```asm
; Example — computed indirect call
         L     R15,FUNC_TABLE(R4)     ; Load target address from table
         BALR  R14,R15                ; Branch and link (indirect)
```

### 3.3 JAS — Jump and Save

Modern z/Architecture instruction, functionally similar to BAS.

- **Syntax:** `JAS Rx,<label>`
- **Typical registers:** R14, R1, R6
- **Return:** YES — via `BR Rx`
- **Call graph edge:** `call_type="subroutine_call"`, `instruction="JAS"`
- **Use case:** Common in date/time conversion routines (ae48.asm).

```asm
; Source: ae48.asm:603
         JAS   R14,UA80PAR1        CONVERT TO DAYS SINCE 01/01/00
```

### 3.4 BRAS / BRASL — Branch Relative and Save (Long)

PC-relative branch instructions used for intra-file calls.

- **Syntax:** `BRAS Rx,<label>` or `BRASL Rx,<label>`
- **BRASL:** 64-bit long form for targets beyond 16-bit offset
- **Return:** YES — via `BR Rx`
- **Call graph edge:** `call_type="subroutine_call"`
- **Code recognition:** `passes/call_graph_builder.py` recognizes these
  as call instructions.

### 3.5 BAL — Branch and Link

Historical predecessor to BAS. Functionally identical — saves the return
address and branches to a label.

- **Syntax:** `BAL Rx,<label>`
- **Return:** YES — via `BR Rx`
- **Call graph edge:** `call_type="subroutine_call"`, `instruction="BAL"`
- **Code recognition:** `instruction_classifier.py:29` — classified as
  `SUBROUTINE_CALL`
- **Note:** Rarely seen in new code; BAS is preferred. Recognized by the
  builder for legacy compatibility.

### 3.6 BASR — Branch and Save Register

Register-indirect form of BAL, analogous to BALR.

- **Syntax:** `BASR Rx,Ry`
- **Behaviour:** Saves return address in Rx, branches to address in Ry
- **Return:** YES — via `BR Rx`
- **Call graph edge:** May be `subroutine_call` or marked indirect
- **Code recognition:** `instruction_classifier.py:29` — classified as
  `SUBROUTINE_CALL`

### 3.7 JASL — Jump and Save Long

Long-displacement variant of JAS, for targets beyond 16-bit PC-relative
offset.

- **Syntax:** `JASL Rx,<label>`
- **Return:** YES — via `BR Rx`
- **Call graph edge:** `call_type="subroutine_call"`
- **Code recognition:** `instruction_classifier.py:31` — classified as
  `SUBROUTINE_CALL`

### 3.8 B — Unconditional Branch (GOTO)

Unconditional branch to a label. No return expected — this is a GOTO.

- **Syntax:** `B <label>`
- **Return:** NO — no return address saved
- **Call graph edge:** May be classified as a control-flow edge, not a
  call edge. Blueprint generators typically capture these as edges only
  when they cross block boundaries.
- **Use case:** Jumping to error handling, loop bodies, or alternate code
  paths within the same file.

```asm
; Source: da76.asm:82
         B     DA760000              ; Jump to main processing
```

### 3.9 Conditional Branches (BZ, BNZ, BE, BNE, BH, BNH, etc.)

Conditional branches based on condition codes. GOTO-style, no return.

- **Syntax:** `BZ <label>`, `BNE <label>`, etc.
- **Return:** NO — control-flow edges, not calls
- **Call graph relevance:** Not typically represented as call edges. They
  affect intra-function control flow only.

### 3.10 BCT / BCTR — Branch on Count

Loop construct — decrements a register and branches if non-zero.

- **Syntax:** `BCT Rx,<label>` or `BCTR Rx,Ry`
- **Return:** NO — loop construct
- **Call graph relevance:** Internal to a routine's control flow; not a
  call edge.

```asm
; Source: da76.asm:262
         BCT   R0,DA7_1200           ; CHECK NEXT ACCT NBR (loop back)
```

### 3.11 BASSM / BASM / BSM — Mode Transition Instructions

These instructions switch the addressing mode (AMODE 24/31/64) as part
of a branch. They generate `CallType.MODE_TRANSITION` edges.

- **BASSM Rx,Ry:** Branch And Save and Set Mode — saves return address +
  current mode in Rx, branches to address in Ry with mode from Ry bit 0.
- **BASM Rx,Ry:** Branch And Set Mode — similar to BASSM.
- **BSM Rx,Ry:** Branch and Set Mode (return variant) — restores mode from
  Ry and branches.
- **Call graph edge:** `call_type="mode_transition"`
- **Code recognition:** `instruction_classifier.py:34-35`, handled by
  `_handle_mode_transition()` at `call_graph_builder.py:674`
- **Use case:** Cross-AMODE calls when a 31-bit routine calls a 64-bit
  routine or vice versa.

### 3.12 EX — Execute Instruction

The EX instruction dynamically modifies and executes a target instruction
in-place.

- **Syntax:** `EX Rx,<target_instruction>`
- **Behaviour:** ORs the low byte of Rx into the target instruction's
  second byte, then executes the modified instruction.
- **Call graph edge:** `call_type="execute"` (`CallType.EXECUTE`)
- **Code recognition:** `instruction_classifier.py:40`, handled by
  `_handle_execute()` at `call_graph_builder.py:721`
- **Use case:** Dynamic MVC length, conditional execution patterns.
  Typically intra-routine; generates an edge to the target instruction
  label.

---

## 4. Inter-File Calling Instructions

These are z/TPF macros used for calling routines in OTHER ASM files
(or C/CPP modules). They appear as blueprint edges where the target is
in a different file.

### 4.1 ENTRC — Enter with Return Expected

The standard inter-file call macro. Transfers control to another ASM
module and expects return.

- **Syntax:** `ENTRC <target_module>`
- **Return:** YES — returns to caller (counterpart: BACKC)
- **Call graph edge:** `call_type="subroutine_call"`, `instruction="ENTRC"`
- **Codebase instances:** 88 across 15 ASM files

```asm
; Source: da76.asm:91
         ENTRC DE70                     MESSAGE MONITOR CHECK
; Source: xh80.asm:449
         ENTRC XH81               PROCESS CARD ATTRIBUTES/LIMITS
```

### 4.2 ENTNC — Enter with No Return Expected

Tail-call / handoff to another ASM module. No return expected.

- **Syntax:** `ENTNC <target_module>`
- **Return:** NO — terminal/handoff edge
- **Call graph edge:** `call_type="no_return_call"`, `instruction="ENTNC"`
- **Codebase instances:** 8

```asm
; Source: xh82.asm:139
         ENTNC XH88                CONTINUE WITH MORE UPDATES
; Source: xh80.asm:3332
         ENTNC XW79                    POST ECB & EXIT PROCESSING
```

### 4.3 ENTDC — Enter with Drop

Transfers control and drops the calling program. No return.

- **Syntax:** `ENTDC <target_module>`
- **Return:** NO — terminal edge, drops caller from stack
- **Call graph edge:** `call_type="no_return_call"`, `instruction="ENTDC"`
- **Codebase instances:** 1 direct + 191 via FUNCTION macro

```asm
; Source: lu82.asm:125 (inside FUNCTION macro)
         ENTDC &SEG              ENTER EXPANSION FOR HANDLING SEGMENT
```

### 4.4 FUNCTION Macro — TPF Request Routing

Maps a 4-character request name to a target module. Expands to ENTDC.

- **Syntax:** `FUNCTION <request_name>,<target_module>`
- **Return:** NO — dispatches via ENTDC
- **Call graph edge:** `call_type="no_return_call"`, `instruction="FUNCTION"`
- **Codebase instances:** 191 (all in lu82.asm)
- **Note:** The `effective_inst` is ENTDC for `call_type` determination,
  but the edge's `instruction` field stores the original macro name
  "FUNCTION".

```asm
; Source: lu82.asm:225-1022 (selection)
         FUNCTION CIPS,LU84          CAS INTRANET PRESENTATION SVCS
         FUNCTION GB72,GB72          REQUEST PROCESSOR
```

### 4.5 Create-Family Macros — Async Entry Creation

The z/TPF create-family macros spawn new ECBs (Entry Control Blocks).
They are NOT subroutine calls — the spawned entry runs independently.

| Macro | Purpose | Semantics |
|-------|---------|-----------|
| CREEC | Create Entry with ECB | Async — spawns independent ECB |
| CREMC | Create Entry (Memory) | Async — spawns independent ECB |
| CREDC | Create Deferred Entry | Async — deferred execution |
| CRETC | Create Time-Initiated Entry | Async — timer-based spawn (in builder, `async_spawn`) |
| CREXC | Create Lower-Priority Deferred Entry | Async — low-priority deferred (in builder, `async_spawn`) |
| CRESC | Create Synchronous Entry | Synchronous — suspends current entry, waits for new entry to complete (in builder, `sync_spawn`) |

- **Call graph edge:** `CallType.ASYNC_SPAWN` (CREEC, CREMC, CREDC,
  CRETC, CREXC); `CallType.SYNC_SPAWN` (CRESC)
- **Code recognition:** CREEC, CREMC, CREDC, CRETC, CREXC, and CRESC
  recognized by `passes/call_graph_builder.py`. CRESC gets
  `CallType.SYNC_SPAWN` (new).
- **Codebase instances:** 1 (CREEC in da78.asm:1255)
- **Note:** CRESC is distinct — it has synchronous wait/return semantics
  that behave more like a subroutine call with suspension, unlike the
  other async create macros.

### 4.6 ATTAC / ATTC — Attach (Dual Meaning)

In the call graph builder, ATTAC/ATTC with an operand is recognized as
an async child ECB spawn (`CallType.ASYNC_SPAWN`).

- **Syntax:** `ATTAC <target>` or `ATTC <target>` (when spawning a child ECB)
- **Code recognition:** `passes/call_graph_builder.py:799`
- **Codebase note:** The 31 ATTAC instances in this codebase are
  **data-level attach** operations (`ATTAC D0`, `ATTAC D6`, etc.) that
  attach a core block to an ECB data level. These are NOT async spawns
  and are NOT captured as call graph edges. Zero child-ECB-spawn ATTAC
  instances exist in the current codebase.

### 4.7 CALLCPP / CALLC — ASM-to-C/C++ Bridge Macros

Bridge macros for calling C or C++ functions from ASM. While these cross
the language boundary (ASM→CPP), they are recognized by the ASM call
graph builder and produce edges.

- **CALLCPP:** Calls a C++ function from ASM
- **CALLC:** Calls a C function from ASM (via CPROC)
- **Call graph edge:** `CallType.CALL`
- **Code recognition:** `call_graph_builder.py:816-829` (CALLCPP);
  CALLC recognized in `variable_lineage_builder.py:59`
- **Note:** These produce cross-language edges (ASM→CPP), so they appear
  in the cross-language index rather than ASM→ASM traversal. Documented
  here for completeness as they are recognized by the ASM builder.
- **Call type split:** The blueprint (`call_graph_builder.py`) stores
  `CallType.CALL` (value `"call"`) for CALLCPP/CALLC edges. However,
  `INSTRUCTION_CALL_TYPE` in `file_call_graph.py` maps both to
  `"subroutine_call"`. Blueprint edges carry `call_type="call"`, while
  `file_call_graph.json` edges carry `call_type="subroutine_call"`.

### 4.8 CLINKC / RLINKC / SLINKC — Program Linkage Macros

IBM-documented inter-module linkage macros for ASM/C interoperability.

- **CLINKC:** Call linkage to a C-callable BAL function
- **RLINKC:** Return linkage from a C-callable BAL function
- **SLINKC:** Save linkage for a C-callable BAL function
- **Status:** Listed in IBM docs (`temp/ibm/patterns/asm-c-interoperability.md`)
  alongside ENTRC/ENTDC/ENTNC as signals to look for.
- **Code recognition:**
  - CLINKC: Recognized by `passes/call_graph_builder.py:766` with `CallType.SUBROUTINE_CALL`
  - RLINKC: Recognized by `passes/call_graph_builder.py:835` as a return boundary (`CallType.RETURN`)
  - SLINKC: Falls through to generic macro handler (`CallType.MACRO_INVOCATION`) — prologue macro, no control transfer
- **Codebase instances:** 0 in current codebase (all three).

### 4.9 EXSR — Execute Subroutine

A z/TPF cross-file call opcode for executing a named subroutine in
another module. Widely used in legacy mainframe code.

- **Syntax:** `EXSR <target_subroutine>`
- **Call graph edge:** `call_type="subroutine_call"`, `instruction="EXSR"`
- **Cross-file inclusion:** In `CROSS_FILE_CALL_OPCODES`
  (`backward_traversal/glossary/instructions.py:84-85`):
  `{"ENTRC", "ENTNC", "ENTDC", "CREEC", "CREMC", "CREDC", "CRETC", "CREXC", "CRESC", "CLINKC", "SWISC", "EXSR", "FUNCTION", "CALLC", "CALLCPP"}` (15 elements)
- **Note:** GAP-037 documents that EXSR was added to the cross-file
  opcodes because without it, all EXSR calls were silently skipped.
- **Codebase instances:** 0 in current temp/asm (recognized by builder)

### 4.10 SWISC — Switch Index Service Call

Switch-based routing to an external module.

- **Syntax:** `SWISC <target_module>`
- **Codebase instances:** 1 (xh80.asm:1219)

### 4.11 Generic Macro Invocation (CallType.MACRO_INVOCATION)

When a macro is not one of the specifically-handled macros (ENTRC,
ENTNC, ATTAC, CALLCPP, EXITC, etc.), the call graph builder falls
through to a generic `MACRO_INVOCATION` handler.

- **Trigger:** Known macros via `macro_classifier.is_macro()` or
  unknown opcodes matching the custom macro heuristic
  (`_is_custom_macro_opcode`: 1-8 character uppercase alphanumeric)
- **Call graph edge:** `CallType.MACRO_INVOCATION`, `instruction=<macro_name>`
- **Code:** `call_graph_builder.py:846-855`
- **How it works:** Adds a node for the macro name itself (kind="macro")
  and an edge from the current source to the macro name. Then extracts
  branch targets from keyword parameters (see 4.12).

### 4.12 Macro Branch Keyword Parameters (CallType.BRANCH)

When a macro invocation contains keyword parameters with names
`NOTUSED`, `BAD`, or `ERROR`, their values are extracted as branch
targets with `CallType.BRANCH`.

- **Code:** `call_graph_builder.py:857-867`, `_extract_macro_branch_targets`
  (`call_graph_builder.py:869-880`)
- **Keyword params:** `{"NOTUSED", "BAD", "ERROR"}`
  (`call_graph_builder.py:148`)
- **How it works:** For each operand with `KEY=VALUE` format, if KEY is
  one of the branch keyword params, VALUE is treated as a branch target
  label. Produces edge: `CallType.BRANCH`, `instruction=<macro_name>`.
- **Example:** `SERRC R,E029AC,ERROR=ERR_HANDLER` would produce a
  BRANCH edge from the current source to `ERR_HANDLER`.

### 4.13 Codebase Macros (System/Utility)

The following z/TPF system macros appear in the codebase and are
recognized by the macro classifier. They produce `MACRO_INVOCATION`
edges via the generic handler (4.11).

| Macro | Purpose | Instances | Files |
|-------|---------|-----------|-------|
| SERRC | System error recording with optional return | 37 | 11 |
| DATEA | Date/time conversion macro | 24 | 9 |
| GETCC | Allocate working storage (core block) | 24 | 11 |
| DETAC | Detach storage block from ECB data level | 36 | 11 |
| DBRED | z/TPFDF database read LREC | 33 | 9 |
| DBCLS | z/TPFDF database close | 15 | 5 |
| SNAPC | Snapshot/diagnostic dump | 12 | 4 |
| DBOPN | z/TPFDF database open | 10 | 5 |
| DBMOD | z/TPFDF database mark modified | 9 | 4 |
| DBIFB | z/TPFDF database info block query | 9 | 4 |
| DBADD | z/TPFDF database add LREC | 6 | 3 |
| RELCC | Release working storage (core block) | 6 | 5 |
| CASIO | CAS I/O operation | 2 | 1 |
| DBDEL | z/TPFDF database delete LREC | 2 | 2 |
| DBCKP | z/TPFDF database checkpoint | 1 | 1 |

**Note:** All macros above are **data/utility operations** — they do
NOT transfer control to another named routine. However, they produce
`CallType.MACRO_INVOCATION` edges in the call graph blueprint via the
generic macro handler (4.11), with `target=<macro_name>`.

```asm
; Source: xh83.asm:512
         DATEA F1=CONVERT,        FUNCTION REQUESTED                   +

; Source: xh83.asm:1463
         SERRC  R,E029A1           TYP-GENDB UPDT PROB- LM1M1 RCD

; Source: xh82.asm:2275
         SNAPC R,E029AC,LIST=SNAPLIST,MSG=SMSG

; Source: xh80.asm — z/TPFDF database sequence
         DBOPN                     OPEN DATABASE CONTEXT
         DBRED                     READ LREC
         DBMOD                     MARK MODIFIED
         DBCLS                     CLOSE DATABASE CONTEXT
```

---

## 5. Return Instructions

These complement the calling instructions and mark where control returns.

### 5.1 BR Rx — Branch Register (Intra-File Return)

Returns from an intra-file subroutine call made with BAS/JAS.

- **Syntax:** `BR R14` or `BR R10`
- **Convention:** The register must match the one used in the corresponding
  BAS/JAS call. R14 is standard linkage; R10 is used in xh80.asm, xh82.asm.

```asm
; Source: da76.asm:518
         BR    R14                    ; Return from subroutine DA7_1950
; Source: xh80.asm:343
         BR    R10                    ; Return to mainline from CM_DATES
```

### 5.2 BACKC — Return from Inter-File Program Call

Returns to the caller after an ENTRC-style inter-file call.

- **Syntax:** `BACKC`
- **Counterpart:** ENTRC
- **Codebase instances:** 19 across 14 ASM files
- **Code recognition:** Recognized in `passes/call_graph_builder.py` and
  `passes/variable_lineage_builder.py` as a return instruction.

```asm
; Source: xh81.asm:1868
         BACKC
; Source: xh83.asm:223
         BACKC
```

### 5.3 EXITC — Exit from Current Entry Point

Exits the current program entry point.

- **Syntax:** `EXITC`
- **Call graph:** Treated as `CallType.RETURN` by the blueprint generator.
- **Codebase instances:** 4 (3 in da76.asm, 1 in lu82.asm via DONTCARE macro)
- **Code recognition:** `passes/call_graph_builder.py:832` — this handler
  also recognizes EXIT, RETURN, RETRN, and BACKC (see 5.4).

### 5.4 EXIT / RETURN / RETRN — Additional Return Macros

The call graph builder recognizes additional return-boundary macros
at the same handler as EXITC (`call_graph_builder.py:832`):

| Macro | Purpose |
|-------|---------|
| EXIT | General exit macro (non-z/TPF form) |
| RETURN | Return macro |
| RETRN | Alternate return macro |
| BACKC | Return from ENTRC inter-file call |
| RLINKC | Return linkage from C-callable BAL function |

- **Call graph edge:** `CallType.RETURN`
- **Code recognition:** `call_graph_builder.py:835` —
  `if macro_name in ("EXIT", "EXITC", "RETURN", "RETRN", "BACKC", "RLINKC")`
- **Note:** EXIT, RETURN, and RETRN are recognized by the builder but may
  not appear in the current codebase. BACKC has 19 instances across 14
  files (see §5.2).

---

## 6. Concrete Calling Patterns in the Codebase

### 6.1 BAS Subroutine Pattern (Most Common Intra-File)

The dominant intra-file pattern. A main routine calls helper subroutines
defined as `EQU *` labels in the same file. Hundreds of instances.

```asm
; Source: da76.asm — Main routine calls helpers
DA760000 EQU   *                      ; Main entry point
         BAS   R14,DA7_8000           ; Call: GET DATE/TIME STAMP
         BAS   R14,DA7_8100           ; Call: COUNT IT
         BAS   R14,DA7_1000           ; Call: VERIFY ACCOUNT NUMBER
         BAS   R14,DA7_2000           ; Call: GET CORE BLOCKS
         ; ...

DA7_8000 EQU   *                      ; Subroutine: GET DATE/TIME STAMP
         ; ... body ...
         BR    R14                    ; Return

DA7_8100 EQU   *                      ; Subroutine: COUNT IT
         ; ... body ...
         BR    R14                    ; Return
```

**Files with extensive BAS usage:**
- `da76.asm` — 15+ BAS calls, 9 subroutine entry points
- `xh80.asm` — 30+ BAS calls using R10, 20+ subroutine entry points
- `xh82.asm` — 35+ BAS calls, extensive limit-processing subroutines
- `xh81.asm`, `xh83.asm`, `xh85.asm`, `xh87.asm`, `xh88.asm`

### 6.2 R10 vs R14 Link Register Convention

Two link register conventions coexist in the codebase:

**R14 convention** (standard z/Architecture linkage):
```asm
; Source: da76.asm
         BAS   R14,DA7_8000           ; Save return in R14
         ; ...
DA7_8000 EQU   *
         BR    R14                    ; Return via R14
```

**R10 convention** (used in xh80, xh82, and related modules):
```asm
; Source: xh80.asm
         BAS   R10,CM_DATES           ; Save return in R10
         ; ...
CM_DATES EQU   *
         BR    R10                    ; Return via R10
```

### 6.3 JAS Pattern (Date/Time Routines)

Used primarily in ae48.asm for date conversion. Multiple link registers.

```asm
; Source: ae48.asm:603-613
         JAS   R14,UA80PAR1        CONVERT TO DAYS SINCE 01/01/00
         JAS   R1,UA80DAT1         Convert date
         L     R4,JULSAVE          RESTORE JULIAN VALUE
         ENTRC UA88                ; Then call external module

; Source: ae48.asm:1003-1011
         JAS   R6,LEAPYEAR        SEE IF MULTIPLE OF 4
         JAS   R6,LEAPYEAR        NOW TRY 100
         JAS   R6,LEAPYEAR        FINALLY, 400
```

### 6.4 ENTRC Chain Between Sibling ASM Modules

ASM modules in the same functional area call each other via ENTRC.
These form call chains: XH80 → XH81 → XH84 → XH87, etc.

```asm
; Source: xh80.asm — calls multiple sibling modules
         ENTRC XH85               DELETE GL INFO FROM CR21AE
         ENTRC XH81               PROCESS CARD ATTRIBUTES/LIMITS
         ENTRC XH90               CREATE A7 LREC WORKAREA
         ENTRC XH71               (to sibling module)

; Source: xh83.asm — calls siblings
         ENTRC XH84               UPDATE EXPO BASED ON CARD & DAY
         ENTRC XH92               PROCESS RELATNSHIP FINANCE INFO
         ENTRC XH87               ZERO GLOS EXPOSURES

; Source: xh85.asm — calls siblings
         ENTRC XH93               PROCESS RELATIONSHIP
         ENTRC XH89               DELETE A7 LREC + ADDT'L CLEANUP
         ENTRC XH94               UPDATE CM PROFILE DATABASE
```

### 6.5 ENTRC to Shared Utility Modules

Common utility modules called from many ASM files:

```asm
; NB81 — Counter module (called from da76, xh81, xh88, xh93)
         ENTRC NB81                GO COUNT

; XI71 — Error logging (called from xh80, xh81, xh83, xh85, xh88, xh93)
         ENTRC XI71                SEND STAT FILE ERROR LOG RCD

; TB44 — Currency conversion (called from xh71, xh81, xh83, xh93)
         ENTRC TB44               CONVERT AMT BASED ON NEW CODE

; SX01 — Logging (called from da76, xh93, xh96)
         ENTRC SX01                LOG LI1I1
```

### 6.6 ENTNC Tail-Call Handoff

Used when an ASM module finishes its work and hands off to the next
module permanently.

```asm
; Source: da76.asm:130
         ENTNC DA78                GO BUILD LG1G1 (no return to DA76)

; Source: xh80.asm:3332
FINALIZE EQU   *
         ENTNC XW79                    POST ECB & EXIT PROCESSING

; Source: xh82.asm:139
         ENTNC XH88                CONTINUE WITH MORE UPDATES
```

### 6.7 FUNCTION Macro Dispatch Table

lu82.asm contains a large routing table mapping request names to ASM
modules. 191 entries.

```asm
; Source: lu82.asm:225-1022 (selection)
         FUNCTION CIPS,LU84          CAS INTRANET PRESENTATION SVCS
         FUNCTION ISC1,DB84          SELF TEST - REQUEST
         FUNCTION GB72,GB72          REQUEST PROCESSOR
         FUNCTION GNA1,DA76          GNA1_ADD_ACCOUNT (routes to DA76)
         FUNCTION C400,DX75          GLOBAL LIMIT UPDATE
         ; ... 186 more entries ...
```

### 6.8 Nested Intra-File Calls

Subroutines within the same file call other subroutines, creating
multi-level call depth.

```asm
; Source: da76.asm — nested calls
DA7_8100 EQU   *                      ; Counting subroutine
         BAS   R14,DA7_NB81           ; Calls helper subroutine
         BR    R14                    ; Return

DA7_NB81 EQU   *                      ; Helper: ENTRC NB81 wrapper
         ENTRC NB81                   ; Calls external NB81 module
         BR    R14                    ; Return
```

---

## 7. IBM / z/TPF Conventions

### 7.1 Register Conventions for ASM→ASM Calls

| Register | Role | Convention | Source |
|----------|------|------------|--------|
| R1 | Parameter pointer | ENTRC-style parameter passing | IBM docs |
| R3 | z/TPFDF slot address | SW00SR slot address for database context passing | IBM docs |
| R9 | ECB base | Must be preserved across all calls; many z/TPF macros require R9 → ECB | IBM docs |
| R10 | Alternate link register | Used in xh80/xh82 family for BAS/BR | Codebase convention |
| R14 | Standard link register | Used in da76, ae48 family for BAS/BR; also receives GETCC results | z/Architecture + IBM docs |
| R15 | Return value / target | Return value from called program/macro | IBM docs |

### 7.2 Entry Points and Labels

ASM subroutines are defined using `EQU *` to create named labels:

```asm
ROUTINE_NAME EQU   *          ; Defines entry point at current address
```

Entry points follow naming conventions:
- `XX_NNNN` — file prefix + numeric (e.g., `DA7_8000`, `XH820000`)
- `CM_<action>` — functional name (e.g., `CM_DATES`, `CM_OPEN_CR21`)
- `LABEL` — descriptive name (e.g., `FINALIZE`, `DELETECD`)

### 7.3 Program Packaging

From IBM documentation (`temp/ibm/migration-notes.md`):

- **BEGIN macro:** Defines program entry and transfer vectors (TV)
- **Transfer Vectors:** Required for programs callable by other programs
  via ENTRC/ENTDC
- **AMODE:** Addressing mode (31-bit or 64-bit) must be declared

### 7.4 Prolog / Epilog Macros

| Macro | Purpose | Status |
|-------|---------|--------|
| PRLGC | Modern prolog for C-callable BAL function | Preferred |
| EPLGC | Modern epilog for C-callable BAL function | Preferred |
| TMSPC | Legacy prolog (TPF 4.1) | Migration compatibility |
| TMSEC | Legacy epilog (TPF 4.1) | Migration compatibility |

### 7.5 z/TPFDF Database Macros (IBM-Documented)

IBM-documented z/TPFDF macros for database operations. These are NOT
inter-module calls; they operate on the database context managed by the
TPFDF subsystem. They produce `MACRO_INVOCATION` edges.

| Macro | Purpose | Codebase Instances | IBM Reference |
|-------|---------|-------------------|---------------|
| DBOPN | Open subfile for access | 10 | `ztpfdf-db-macros.md` |
| DBCLS | Close subfile | 15 | `ztpfdf-db-macros.md` |
| DBRED | Read next LREC | 33 | `ztpfdf-db-macros.md` |
| DBMOD | Mark LREC as modified | 9 | `ztpfdf-db-macros.md` |
| DBIFB | Query database info block | 9 | `ztpfdf-db-macros.md` |
| DBADD | Add LREC to subfile | 6 | `ztpfdf-db-macros.md` |
| DBDEL | Delete LREC from subfile | 2 | `ztpfdf-db-macros.md` |
| DBCKP | Checkpoint database | 1 | `ztpfdf-db-macros.md` |
| DBKEY | Activate search key | 0 | `ztpfdf-db-macros.md` |
| DBRET | Retain subfile position | 0 | `ztpfdf-db-macros.md` |
| DBSPA | Allocate subfile space | 0 | `ztpfdf-db-macros.md` |
| DBCLR | Clear database context | 0 | `ztpfdf-db-macros.md` |

### 7.6 Storage / Memory Management Macros (IBM-Documented)

IBM-documented macros for ECB storage and core block management. These
are data operations, not inter-module calls. They produce
`MACRO_INVOCATION` edges.

| Macro | Purpose | Codebase Instances | IBM Reference |
|-------|---------|-------------------|---------------|
| GETCC | Allocate working storage (core block) | 24 | `storage-and-ecb-lifecycle.md` |
| DETAC | Detach storage block from data level | 36 | `storage-and-ecb-lifecycle.md` |
| RELCC | Release working storage | 6 | `storage-and-ecb-lifecycle.md` |
| ATTAC | Attach storage block to data level | 31 (data ops) | `storage-and-ecb-lifecycle.md` |
| FINWC | Find/read record with core | 1 | `storage-and-ecb-lifecycle.md` |
| FIWHC | Find/read with hold and core | 1 | `storage-and-ecb-lifecycle.md` |
| GETFC | Allocate from file pool | 0 | `storage-and-ecb-lifecycle.md` |
| RELFC | Release file pool block | 0 | `storage-and-ecb-lifecycle.md` |
| RCRFC | Combined release core/file | 0 | `storage-and-ecb-lifecycle.md` |
| FILEC | File a record | 0 | `storage-and-ecb-lifecycle.md` |

### 7.7 Transaction / Commit Scope Macros (IBM-Documented)

IBM-documented macros for transaction boundaries. Not present in the
current codebase but documented for completeness. These are boundary
markers, not inter-module calls.

| Macro | C Equivalent | Purpose | IBM Reference |
|-------|-------------|---------|---------------|
| TXBGC | `tx_begin` | Begin transaction scope | `transactions-and-commit-scopes.md` |
| TXCMC | `tx_commit` | Commit transaction | `transactions-and-commit-scopes.md` |
| TXRBC | `tx_rollback` | Rollback transaction | `transactions-and-commit-scopes.md` |
| TXSPC | `tx_suspend_tpf` | Suspend TPF transaction | `transactions-and-commit-scopes.md` |
| TXRSC | `tx_resume_tpf` | Resume TPF transaction | `transactions-and-commit-scopes.md` |

---

## 8. Coverage Gap: Inter-File ASM to ASM Forward

### The Gap

The cross-language index (`cross_lang.forward`) intentionally excludes
same-language edges:

```python
# index_builder.py:632
if src_type == tgt_type:
    continue  # Skip ASM→ASM, CPP→CPP
```

This means inter-file ASM→ASM edges are NOT in the cross-language forward
index. Forward traversal relies on blueprint edge metadata to resolve the
target file.

### How It Works (When It Works)

For an inter-file call like `ENTRC XH85` from `xh80.asm`:

1. The blueprint `xh80.asm.json` has an edge:
   `{source: "XH80_MAIN", target: "XH85", is_external: true}`
2. The target node metadata includes a `file` field with the target path
3. `_file_stem(t_fp)` derives the target's file stem (`"xh85"`)
4. On the next BFS iteration, `_load_cg("xh85", blueprint_dir)` loads
   `xh85.asm.json`
5. Traversal continues through xh85's edges

### When It Fails

If the blueprint's target node has an empty or incorrect `file` field,
`t_fstem` will be `None` or wrong, and the traversal cannot load the
target's blueprint. The target becomes a leaf node.

### MAC Blueprint Loading

The blueprint loader (`_load_cg` at `traversal.py:101-142`) tries three
file extensions: `{fstem}.cpp.json`, `{fstem}.asm.json`, and
`{fstem}.mac.json`. MAC files can now be loaded for forward traversal
and blueprint edge inversion. MAC files primarily contain DSECT
definitions and macro definitions rather than executable calling
instructions, so the practical impact on call chain traversal is limited.

### Backward Direction (No Gap)

Backward traversal does NOT have this gap because:
- The callers index (`index.callers`) contains ALL edges from ALL blueprints
  (CPP, ASM, MAC), with no language filtering
- ASM→ASM inter-file callers are present in the index
- Blueprint edge inversion provides additional intra-file coverage

---

## 9. Summary Table

### 9.1 Forward Traversal (ASM→ASM)

| # | Pattern | Data Source | Key Feature |
|---|---------|-------------|-------------|
| 1 | Intra-file blueprint edges | `*.asm.json` call_graph edges | BAS/JAS/BALR calls within same file |
| 2 | Inter-file blueprint edges | `*.asm.json` edges + target node file path | ENTRC/ENTNC/ENTDC to other ASM files |
| 3 | Cross-language index | NOT USED | Same-language edges excluded |
| 4 | Indirect call (resolved) | ASM blueprint edge + `is_indirect` | Register-indirect with known target |
| 5 | Indirect call (unresolved) | ASM blueprint edge + `is_indirect`, no target | Synthetic leaf, BFS stops |
| 6 | Metadata fallback | ASM blueprint `call_graph.nodes` | When definitions index has no ASM entry |
| 7 | No source fallback | — | Warning only; no ASM source scanning |

### 9.2 Backward Traversal (ASM→ASM)

| # | Pattern | Data Source | Key Feature |
|---|---------|-------------|-------------|
| 8 | Callers index lookup | `index.callers` (all languages) | Contains ASM→ASM inter-file callers |
| 9 | Blueprint edge inversion | ASM blueprint edges (inverted) | Intra-file ASM callers |
| 10 | Cross-language index | NOT USED | Same-language edges excluded |
| 11 | No source fallback | — | Source scanning is CPP-only |

### 9.3 Intra-File Instructions

| # | Instruction | Type | Returns? | Call Graph Edge | Codebase Prevalence |
|---|-------------|------|----------|-----------------|---------------------|
| 1 | BAS | Subroutine call | YES (via BR Rx) | `subroutine_call` | Dominant — hundreds |
| 2 | JAS | Subroutine call | YES (via BR Rx) | `subroutine_call` | Common in ae48.asm |
| 3 | BALR | Register-indirect call | YES (via BR Rx) | May be `indirect` | Less common |
| 4 | BRAS/BRASL | Relative branch-save | YES (via BR Rx) | `subroutine_call` | Recognized by builder |
| 5 | BAL | Subroutine call (legacy) | YES (via BR Rx) | `subroutine_call` | Legacy; recognized by builder |
| 6 | BASR | Register-indirect (legacy) | YES (via BR Rx) | `subroutine_call` | Legacy; recognized by builder |
| 7 | JASL | Jump-and-save long | YES (via BR Rx) | `subroutine_call` | Recognized by builder |
| 8 | BASSM/BASM/BSM | Mode transition | YES | `mode_transition` | AMODE switching |
| 9 | EX | Execute instruction | N/A | `execute` | Dynamic instruction modification |
| 10 | B | Unconditional branch | NO | Control-flow edge | Very common |
| 11 | BZ/BNZ/BE/BNE/... | Conditional branch | NO | Control-flow edge | Very common |
| 12 | BCT/BCTR | Loop (decrement) | NO | Loop edge | Moderate |
| 13 | BR Rx | Return from call | — | Return edge | Paired with BAS/JAS |

### 9.4 Inter-File Instructions

| # | Instruction | Returns? | Call Graph Edge | Codebase Count |
|---|-------------|----------|-----------------|----------------|
| 1 | ENTRC | YES | `subroutine_call` | 88 |
| 2 | ENTNC | NO | `no_return_call` | 8 |
| 3 | ENTDC | NO | `no_return_call` | 1 (+ 191 FUNCTION) |
| 4 | FUNCTION | NO (→ ENTDC) | `no_return_call` | 191 |
| 5 | CREEC/CREMC | N/A | `async_spawn` | 1 |
| 6 | CREDC | N/A | `async_spawn` | 0 (in builder) |
| 6a | CRETC/CREXC | N/A | `async_spawn` | 0 (in builder, `async_spawn`) |
| 7 | CRESC | synchronous wait | `sync_spawn` | 0 (in builder, `sync_spawn`) |
| 8 | ATTAC/ATTC | N/A | `async_spawn` | 0 spawn (31 data-level ops) |
| 9 | CALLCPP/CALLC | YES | `call` (cross-language) | 0 ASM→ASM (bridge to CPP) |
| 10 | CLINKC/RLINKC/SLINKC | varies | CLINKC: `subroutine_call`, RLINKC: `return`, SLINKC: `macro_invocation` | 0 (in builder) |
| 11 | EXSR | YES | `subroutine_call` | 0 (in CROSS_FILE_CALL_OPCODES) |
| 12 | SWISC | varies | `isc_route` | 1 |
| 13 | BACKC | return | `return` | 19 |
| 14 | EXITC | return | `return` | 4 |
| 15 | EXIT/RETURN/RETRN | return | `return` | 0 (recognized by builder) |
| 16 | Generic macros | varies | `macro_invocation` | SERRC(37), DATEA(24), SNAPC(12), CASIO(2) |
| 17 | Macro branch targets | N/A | `branch` | Via NOTUSED/BAD/ERROR keyword params |

---

## 10. Configuration Parameters

These request-level parameters affect ASM→ASM traversal:

| Parameter | Default | Effect on ASM→ASM |
|-----------|---------|-------------------|
| `direction` | `"forward"` | Forward: traces ASM callees. Backward: finds ASM callers. |
| `max_depth` | `5` | Maximum BFS hops; controls depth of intra-file + inter-file chains |
| `include_external` | `false` | Include stdlib/external functions (rarely relevant for pure ASM) |
| `include_indirect_calls` | `true` | Include BALR-based indirect calls |
| `expand_virtual_dispatch` | `true` | No effect on ASM (CHA only applies to `::` methods) |
| `max_nodes` | `1,000,000` | Maximum nodes before truncation |
| `source_path` | `null` | No effect on ASM nodes (source fallback is CPP-only) |
| `include_params` | `true` | No effect on ASM nodes (signature enrichment is CPP-only) |
| `force_rebuild_index` | `false` | Forces re-parse of blueprints and file_call_graph.json |

---

## CallType Enum Reference

All 11 values defined in `models/call_graph.py:8-19`:

| CallType | Value | ASM Instruction(s) | Documented In |
|----------|-------|---------------------|---------------|
| SUBROUTINE_CALL | `subroutine_call` | BAS, BALR, JAS, BRAS, BRASL, BAL, BASR, JASL, ENTRC, EXSR, CLINKC | §3, §4.1, §4.8, §4.9 |
| NO_RETURN_CALL | `no_return_call` | ENTNC, ENTDC | §4.2, §4.3 |
| ASYNC_SPAWN | `async_spawn` | CREEC, CREMC, CREDC, CRETC, CREXC, ATTAC/ATTC | §4.5, §4.6 |
| SYNC_SPAWN | `sync_spawn` | CRESC | §4.5 |
| CALL | `call` | CALLCPP, CALLC | §4.7 |
| MODE_TRANSITION | `mode_transition` | BASSM, BASM, BSM | §3.11 |
| BRANCH | `branch` | B*, BC, BCR; macro keyword branch targets | §3.8-3.10, §4.12 |
| RETURN | `return` | BR R14, BACKC, EXITC, EXIT, RETURN, RETRN, RLINKC | §5 |
| EXECUTE | `execute` | EX | §3.12 |
| MACRO_INVOCATION | `macro_invocation` | Generic macros (SERRC, DATEA, GETCC, DBOPN, etc.) | §4.11, §4.13 |
| ISC_ROUTE | `isc_route` | SWISC | §4.10 |

---

## File References

| Component | Path |
|-----------|------|
| Forward traversal | `cpp_call_chain/traversal.py:377-639` |
| Backward traversal | `cpp_call_chain/traversal.py:646-883` |
| ASM metadata fallback | `cpp_call_chain/traversal.py:165-189` |
| Blueprint loader | `cpp_call_chain/traversal.py:101-142` |
| Index builder (all blueprints) | `cpp_call_chain/index_builder.py:220-332` |
| Cross-language index (skips same-lang) | `cpp_call_chain/index_builder.py:526-778` |
| ASM call graph builder | `passes/call_graph_builder.py` |
| Instruction classifier | `instruction_classifier.py` |
| Macro classifier | `macro_classifier.py` |
| CallType enum | `models/call_graph.py:8-19` |
| Variable lineage builder | `passes/variable_lineage_builder.py` |
| Indirection utils | `api/utils/indirection.py` |
| Endpoint handler | `api/routes/knowledge_base.py:2504-2832` |
| IBM ASM-C interop docs | `temp/ibm/patterns/asm-c-interoperability.md` |
| IBM system macros docs | `temp/ibm/macros/ztpf-system-macros.md` |
| IBM migration notes | `temp/ibm/migration-notes.md` |
