# ECB Field Matching Strategy for get_equivalent_variable.py

**Date:** 2026-04-24
**Goal:** Reduce false negatives in cross-file variable resolution by leveraging `ecb_field` metadata.

## Problem

The equivalent variable resolver (`get_equivalent_variable.py`) has an **87.3% fallback rate** (117/134 attempts returned NOT_FOUND in the LG1OSI audit). Root cause: the resolver's 5 strategies rely on `dsect`, `byte_offset`, and `access_identity` metadata — but these fields are **almost entirely absent** from the blueprints. Meanwhile, the dominant metadata `ecb_field` (present on 179/225 memory nodes in da78, 246/310 in xh80) is completely ignored.

## Evidence

| File | Memory nodes | Nodes with `access_identity` | Nodes with `dsect` | Nodes with `ecb_field` |
|------|-------------|------------------------------|---------------------|------------------------|
| da78 | ~225 | 0 | 0 | 179 |
| xh80 | ~310 | 0 | 8 | 246 |
| xh81 | ~246 | 0 | 0 | 246 |

Variables like `LG1ACT`, `WB1ACT`, `LG1UPT` have matching `ecb_field` values across files but the resolver can't see them.

## Design

### New Strategy: ECB Field Match (inserted between Strategy 2 and Strategy 3)

**Rationale:** `ecb_field` is derived from the shared macro definitions (lg1lg1.mac, wb1wb.mac, etc.) and identifies the ECB memory field a node maps to. Two nodes in different files with the same `ecb_field` value reference the same physical ECB memory. This is a reliable identity signal — in xh80 alone, all 246 ecb_field values are unique (no duplicates).

**How it works:**

1. New helper `_get_ecb_field(bp, node_id)` — extracts `ecb_field` from a node's metadata.
2. New helper `_collect_ecb_field_map(bp)` — builds `{ecb_field: set(node_ids)}` for all memory nodes.
3. New strategy slot between S2 (Access Identity) and S3 (Direct Name Match):
   - Get the `ecb_field` of the current tracked variable from the previous blueprint.
   - Look up that `ecb_field` in the target blueprint's ecb_field map.
   - If found, return the matching node ID.
   - Prefer a node with the same name if multiple candidates exist.

**Identity propagation:** Also carry `ecb_field` forward alongside `dsect`/`offset`/`access_identity` so that even when physical identity fields are absent, the variable can still be matched at subsequent hops.

### Strategy numbering after change

1. Parameter Bridge
2. Access Identity Match (CE-slot:offset)
3. **ECB Field Match (NEW)**
4. Direct Name Match
5. DSECT + Offset
6. Global Alias / Bridge

### Variables this fixes (from the audit)

| Variable | Hops fixed | ecb_field |
|----------|-----------|-----------|
| LG1ACT | xh80->xh81, xh80->xh85 | `lg1act` |
| WB1ACT | xh80->xh81 | `wb1act` |
| LG1UPT | xh80->xh71 | `lg1upt` |
| LG1OSI | da78->xh80, xh80->xh71, xh80->xh85 | `lg1osi` |

### What this does NOT fix

- **WK_* variables** — These are program-local workspace (DA7GL DSECT) that genuinely don't exist in xh80. True negatives.
- **WB1RTC, L7DNCC beyond xh80** — These nodes only exist in xh80's variable_lineage. True negatives (not referenced downstream).
- **EBW002** — Not referenced in xh80 at all. True negative.

## Implementation

1. Add `_get_ecb_field()` and `_collect_ecb_field_map()` helpers.
2. Add `target_ecb_field` to the identity state carried through the chain (alongside `target_dsect`, `target_offset`, `target_access_id`).
3. Insert the new strategy block in `find_match_in_file()`.
4. Update `main()` and `resolve_equivalent_variable()` to initialize and propagate `target_ecb_field`.
5. Include `ecb_field` in the "has_identity" check so the chain doesn't die prematurely when ecb_field is the only available identity.

## Files changed

- `get_equivalent_variable.py` — all changes are in this single file.