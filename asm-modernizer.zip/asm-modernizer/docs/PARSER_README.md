# Parser README

This repository contains a z/TPF ASM parser that analyzes assembly files and
emits structured JSON artifacts: symbols, call graph, control-flow blocks,
subroutines, variable lineage, DB operations, and more. The entry point is
`main.py`.

---

## Prerequisites

- Python 3.x available as `python3`
- Install dependencies if needed:

```bash
python3 -m pip install -r requirements.txt
```

---

## Basic Usage

```bash
python3 main.py <asm-file>
```

Example (with macro search path):

```bash
python3 main.py temp/final_test_data/asm/ENTRYDRV.asm \
  -s temp/final_test_data/macros
```

---

## Common CLI Options

| Flag | Default | Description |
|------|---------|-------------|
| `-s <dir>` | auto-detected | Additional search path for COPY includes (repeatable) |
| `-m <file>` | — | Macro library file, takes precedence over auto-discovered macros (repeatable) |
| `-o <dir>` | `output/` | Directory for JSON output files |
| `-c <dir>` | `.cache` | Directory for parser cache |
| `--no-json` | off | Skip writing JSON output files |

### Analyze a directory (auto-discovers all `.asm` files and COPY paths)

```bash
python3 main.py temp/final_test_data/asm/
```

### Analyze multiple files

```bash
python3 main.py file1.asm file2.asm file3.asm
```

### Wildcard input

```bash
python3 main.py temp/final_test_data/asm/*.asm
```

### Custom output directory

```bash
python3 main.py -o output/my_run temp/final_test_data/asm/ENTRYDRV.asm \
  -s temp/final_test_data/macros
```

---

## Output Format

Each input file produces one JSON file:

```
output/<input-filename>.json
```

Example: `ENTRYDRV.asm` → `output/ENTRYDRV.asm.json`

### Top-level keys

| Key | Description |
|-----|-------------|
| `metadata` | Parser version and generator info |
| `symbol_aliases` | C/C++ ↔ ASM symbol alias mappings |
| `symbols` | Full symbol table (ENTRY, EXTRN, CSECT, DSECT, EQU, labels) |
| `call_graph` | Control-flow graph: nodes (routines) and edges (branches/calls/returns) |
| `blocks` | **Control-flow blocks** — each labeled section with its instruction flow |
| `subroutines` | **Subroutine definitions** — routines called via BAS/BAL, with line ranges |
| `db_operations` | z/TPFDF database operation catalog (DBRED, DBWRT, etc.) |
| `file_dependencies` | COPY/include dependency graph |
| `macro_expansions` | Successful macro expansion records |
| `macro_errors` | Macro expansion errors |
| `variable_lineage` | Per-file variable data-flow graph |
| `global_variable_lineage` | Merged cross-file variable lineage |
| `build_metadata` | Metadata derived from Makefiles |
| `line_metadata` | Per-line context index (section, routine, conditional depth, calls) |

---

## blocks

Each entry in `blocks` represents a labeled section of executable code
(a CSECT label or internal branch target).

```json
{
  "id": "ERRSTATS",
  "flow": [
    { "line": 130, "inst": "STM",  "args": ["R14", "R12", "12(R13)"] },
    { "line": 131, "inst": "LR",   "args": ["R12", "R15"] },
    { "line": 149, "inst": "BAS",  "args": ["R10", "DO_VALIDATE"] },
    { "line": 162, "inst": "MVC",  "var": "SCRATCH(2)", "val": "ERRORLOG" }
  ],
  "incoming_branches": [{ "source": "ENTRYDRV" }]
}
```

### `flow` item fields

| Field | When present | Description |
|-------|-------------|-------------|
| `line` | always | Source line number in the original `.asm` file |
| `inst` | always | Instruction opcode (e.g. `STM`, `BAS`, `MVC`) |
| `args` | non-move instructions | Operands as a list of strings |
| `var` | move instructions only | Destination operand (e.g. MVC, MOVEX, MVI) |
| `val` | move instructions only | Source operand |

`args` and `var`/`val` are mutually exclusive on a single item.

### What is excluded from `flow`

Assembler directives are not executable instructions and are excluded:
`CSECT`, `DSECT`, `RSECT`, `EQU`, `DC`, `DS`, `USING`, `DROP`, `LTORG`,
`END`, `MACRO`, `MEND`, `COPY`, `ENTRY`, `EXTRN`, `WXTRN`.

Comment-only lines and blank lines are also excluded.

### `incoming_branches`

List of objects describing branch sources targeting this block.
Each object currently has shape `{ "source": "<block_id>" }`.
Empty list means the block is only reached by fall-through or is an entry point.

---

## subroutines

Each entry in `subroutines` represents a routine that is called via a
`BAS`/`BAL`/`BASR`/`BALR` instruction (a subroutine call, not a plain branch).

```json
{
  "id": "DO_VALIDATE",
  "start_line": 194,
  "end_line":   202,
  "called_by":  ["ERRSTATS"]
}
```

| Field | Description |
|-------|-------------|
| `id` | Label name of the subroutine |
| `start_line` | First source line in the subroutine's body |
| `end_line` | Last source line in the subroutine's body |
| `called_by` | List of block/subroutine IDs that call this routine via BAS/BAL |

---

## meta

Additional blueprint metadata used by traversal and alias-aware analysis:

```json
{
  "aliases": { "WK_RRC": "EBW002" },
  "base_registers": { "R12": "EQUTEST" }
}
```

---

## Variable Lineage Options

Request a lineage trace at parse time:

```bash
python3 main.py temp/final_test_data/asm/ENTRYDRV.asm \
  -s temp/final_test_data/macros \
  --lineage-name STATUS \
  --lineage-kind memory \
  --lineage-direction forward \
  --lineage-depth 5
```

Restrict to a specific scope:

```bash
python3 main.py temp/final_test_data/asm/ENTRYDRV.asm \
  -s temp/final_test_data/macros \
  --lineage-name STATUS \
  --lineage-kind memory \
  --lineage-scope ERRSTATS
```

Export lineage graph to JSON and DOT format:

```bash
python3 main.py temp/final_test_data/asm/ENTRYDRV.asm \
  -s temp/final_test_data/macros \
  --lineage-name STATUS \
  --lineage-kind memory \
  --lineage-export output/lineage_STATUS.json \
  --lineage-dot   output/lineage_STATUS.dot
```

---

## Validating blocks / subroutines Output

A dedicated validator cross-checks the `blocks` and `subroutines` sections
against the raw ASM source. It runs three tiers of checks:

1. **Schema** — required keys present, correct types, `args` XOR `var`/`val`
2. **Consistency** — no duplicate IDs, `incoming_branches`/`called_by`
   reference real labels, no line-number overlap between blocks
3. **Source** — every flow item's line number and opcode verified against
   the actual `.asm` file

```bash
python3 tools/validate_blocks.py output/<run>/asm/  temp/final_test_data/asm/
```

Example output:

```
[PASS] ENTRYDRV.asm.json
  All checks passed.

[PASS] ERRSTATS.asm.json
  All checks passed.

SUMMARY: 10 file(s) | 10/10 passed | 0 error(s) | 0 warning(s)
```

---

## Reviewing Parser Completeness (Per File)

Use the completeness reviewer to verify whether core sections capture expected
information for a given source file:

- top-level JSON sections present
- deterministic `line_metadata` coverage audit
- `call_graph` coverage on expected call lines
- `variable_lineage` overlap/coverage checks
- ASM-only extras: `blocks.flow` and `db_operations` coverage

```bash
python3 tools/review_parser_output.py output/<run>/ENTRYDRV.asm.json temp/final_test_data/asm/ENTRYDRV.asm
```

For C/C++:

```bash
python3 tools/review_parser_output.py output/<run>/cpp/cross_lang_callers.cpp.json temp/final_test_data/cpp/cross_lang_callers.cpp
```

Directory mode (auto-maps `<name>.json` -> `<source_dir>/<name>`):

```bash
python3 tools/review_parser_output.py output/<run>/asm/ temp/final_test_data/asm/
```

The report prints per-file metrics and a weighted completeness score.
It also includes deterministic `LINE_AUDIT` accounting:

- every source line must be either covered by expected JSON sections, or
- explicitly explained as an exclusion (`blank_line`, `comment_line`,
  `directive_or_declaration`, etc.)

Any line that is neither covered nor explained is reported as a hard error.

---

## Automatic Coverage Review in `main.py`

When JSON output is enabled (default), `main.py` now automatically runs the
deterministic coverage review for ASM/C/C++ inputs and appends a
`coverage_review` section to each generated source JSON file.

Disable this behavior with:

```bash
python3 main.py <input> --no-coverage-review
```

The appended `coverage_review` includes:
- pass/fail (`ok`) and weighted score
- detailed errors and warnings
- deterministic `line_audit` summary
- per-metric coverage counts

To backfill already generated JSON files with `coverage_review`:

```bash
python3 tools/review_parser_output.py --append output/<run>/asm/ temp/final_test_data/asm/
```

---

## Help

```bash
python3 main.py --help
```
