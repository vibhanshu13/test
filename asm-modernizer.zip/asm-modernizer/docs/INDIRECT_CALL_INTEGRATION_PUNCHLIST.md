# Indirect Call Integration — Tracking Document

**Status:** Audit complete. Implementation pending.
**Companion doc:** [`INDIRECT_CALL_COVERAGE.md`](../INDIRECT_CALL_COVERAGE.md) — full capability reference.
**Commit that started this:** `005361f` ("cpp/asm indirect call resolution") — landed the producer side; this doc tracks consumer-side propagation.

---

## 1. Why this exists

For the AMEX CAS POC, the call graph must honestly represent **indirect calls** — call sites where the target is determined at runtime rather than by a literal symbol. Four patterns matter:

| Pattern | Example | Static resolution |
|---|---|---|
| **C++ function pointers** | `fp = target; fp(wa);` | Resolved via `fp_sources` for single-identifier assignments; unresolved cases surfaced as leaf nodes |
| **C++ virtual dispatch (vtable)** | `BaseT* p; p->vfunc();` | Same-file CHA at pipeline time; cross-TU CHA at query time |
| **ASM jump tables** | `EX R2,TABLE_BC` + BC table | Resolved when table is statically readable (e.g. MQ C400 patterns); dynamic indexes cannot be resolved |
| **ASM register-based calls** | `BALR R14,R15`, `BR R15` | Surfaced as leaf node annotated with `register="R15"` — call site visible, target unknown |

Each resolved or surfaced indirect call carries four annotations on its edge / response node:

- `is_indirect: bool`
- `indirect_via: string` (FP variable name or register)
- `is_virtual_dispatch: bool`
- `cha_base_class: string`

The producer pipeline already emits these (commit `005361f`). The goal of this punch-list is to make sure **every downstream consumer** honors them — APIs, schemas, traversal engines, persistence, explainability.

---

## 2. Annotation field reference

| Field | Where it's set | When |
|---|---|---|
| `is_indirect` | `passes/call_graph_builder.py:542-580`, `passes/c_family_parser.py:2453`, `multi_file/c_family_analyzer.py:1000,1014` | Edge emit time |
| `register` / `indirect_via` | Same as above | ASM register-indirect or unresolved FP variable |
| `is_virtual_dispatch` | `cpp_call_chain/traversal.py` (`_apply_cha_expansion`) | Query time, when expanding base→derived |
| `cha_base_class` | Same — set to the base class whose virtual call triggered expansion | Query time |

Serialization is handled by `models/call_graph.py:36-51` (`CallEdge.to_dict`) and `json_emitter.py:213` — verified honoring.

---

## 2a. Architectural pattern: indirection envelope (forward-compatible)

**Problem:** if we cherry-pick the 4 fields at every one of the 27 sites, Phase 2 gap closures (callback IPA, return-target tracking, jump-table over-approximation, etc.) will require re-walking every site to add each new field.

**Solution:** treat indirect-call metadata as a single opaque envelope that every consumer preserves but does not inspect.

### Shared helper

```python
# api/utils/indirection.py
INDIRECTION_FIELDS = (
    "is_indirect", "indirect_via",
    "is_virtual_dispatch", "cha_base_class",
    # Phase 2: "over_approximation", "binding_site", "confidence",
    #         "resolution_chain", ...
)

def extract_indirection(edge: Dict) -> Optional[Dict]:
    """Return the indirection blob if any indirection signal is present, else None."""
    blob = {k: edge[k] for k in INDIRECTION_FIELDS if k in edge}
    if not blob or not any(blob.get(k) for k in ("is_indirect", "is_virtual_dispatch")):
        return None
    return blob

def merge_indirection(into: Dict, src: Dict) -> None:
    """Carry the envelope from one edge dict to another, in place."""
    blob = extract_indirection(src)
    if blob is not None:
        into["indirection"] = blob
```

### Shared schema

```python
# api/schemas/_indirection.py
class IndirectionEnvelope(BaseModel):
    model_config = ConfigDict(extra="allow")  # forward-compatible
    is_indirect: bool = False
    indirect_via: Optional[str] = None
    is_virtual_dispatch: bool = False
    cha_base_class: Optional[str] = None
```

`extra="allow"` means future fields appear in API responses **without schema migration**.

### Per-site pattern (replaces the 27 walks)

```python
# Old: every site cherry-picks 4 fields manually
# New: every site is one line
new_edge = {"source": e["source"], "target": e["target"], "label": label}
merge_indirection(into=new_edge, src=e)
edges.append(new_edge)
```

### Future-proofing guarantee

When Phase 2 closes a gap and adds (say) `over_approximation: bool` on edges:

1. Producer emits the new key on blueprint edges (one file change).
2. Add `"over_approximation"` to `INDIRECTION_FIELDS` (one-line change).
3. Optionally add to `IndirectionEnvelope` for type hints (one-line change).
4. **All 27 sites pick it up automatically — no re-walk.**

The only place that has to change is the **rendering layer** (UI / Pi / explainability) — and only for fields it wants to surface to users. That's by design: the plumbing is opaque; the renderer is selective.

### Updated schema fixes (SC1–SC4)

Each schema gets **one** `indirection` field, not four:

```python
class EdgeInfo(BaseModel):                    # SC1
    # ... existing fields ...
    indirection: Optional[IndirectionEnvelope] = None

class ChainHop(BaseModel):                    # SC2
    # ... existing fields ...
    indirection: Optional[IndirectionEnvelope] = None

class VariableLineageEdge(BaseModel):         # SC3
    source: str
    target: str
    label: str
    indirection: Optional[IndirectionEnvelope] = None

# SC4: replace Dict[str, Any] with typed model embedding IndirectionEnvelope
```

---

## 3. Coverage tally

| Bucket | Count |
|---|---|
| Producers (already honoring) | 5 files |
| Consumers (already honoring) | 5 files |
| **GAPS — integration sites** | **27 distinct sites across 19 files** |
| Verified N/A (no action) | ~25 modules |

---

## 4. ✅ Already honoring — but still need envelope-pattern refactor

These places honor the 4 fields today, but they hard-code them individually. To keep the system future-proof against Phase 2 gap closures (so we don't have to re-walk these too), they should be refactored to use the indirection envelope pattern from §2a.

### Producers — keep individual fields on the dataclass (source of truth)
- `passes/call_graph_builder.py:542-580` — ASM register-indirect, emits `is_indirect`, `register`
- `passes/c_family_parser.py:2453` — C++ FP dereferences
- `multi_file/c_family_analyzer.py:1000,1014` — passes `is_indirect=is_indirect` to `add_edge()`
- `models/call_graph.py:36-51, 187-195` — `CallEdge.to_dict()` serializes
- `json_emitter.py:213` — blueprint write

> **No action:** producers stay as individual fields. The envelope wraps consumer/transit only.

### Consumers — refactor to envelope (internal, no API impact)
| ID | Status | File:Line | Refactor |
|---|---|---|---|
| H1 | ☐ | `cpp_call_chain/index_builder.py:193,203,286-295` | Replace 4-field reads with `extract_indirection()`; store as `indirection` blob in index entries |
| H2 | ☐ | `cpp_call_chain/traversal.py:503-536,688-691,727-729,784` | Replace queue-tuple cherry-picking with `merge_indirection()`; pass envelope into `_make_node()` |
| H3 | ☐ | `cpp_call_chain/traversal.py:_make_node()` | Accept `indirection` arg instead of 4 separate args |

### Consumers — public API surface, needs backward-compat decision
| ID | Status | File:Line | Refactor |
|---|---|---|---|
| H4 | ☐ | `api/schemas/processes.py:184-203` (`ProcessCppCallChainNode`) | Add `indirection: Optional[IndirectionEnvelope] = None` alongside existing 4 fields (Option A: backward-compat) **OR** replace 4 fields with envelope only (Option B: hard cutover). **See §4a for decision.** |
| H5 | ☐ | `api/routes/processes.py:666-894` | Falls out of H4 |
| H6 | ☐ | `api/routes/knowledge_base.py:2621-2832` | Falls out of traversal change (H2) since it returns raw dict |

---

## 4a. Backward-compatibility decision for `ProcessCppCallChainNode`

**Decision: Option B (hard cutover). Verified no consumers exist.**

### Verification

Exhaustive search of the repo for direct readers of the 4 fields:

| Surface | Result |
|---|---|
| Frontend (`mini_project/ui/src/**`) | 0 references to any of the 4 fields |
| Frontend (`api/static/**`) | 0 references |
| Other `.ts/.tsx/.js/.jsx/.vue/.html` files | 0 references |
| Python tests | 0 assertions (only a comment in `tests/cpp_connections/tx_a_entry.cpp:25`) |
| Python consumers of `ProcessCppCallChainNode` outside `api/schemas/processes.py` and `api/routes/processes.py` | 0 references |
| All Python `.is_indirect` / `["is_indirect"]` / `get("is_indirect")` hits | All internal — `passes/*`, `models/call_graph.py`, `cpp_call_chain/*`, `file_call_graph.py:423` (already flagged) |

No external consumer reads `node.is_indirect` or its siblings. The schema is internal-only despite being a "public" API surface — the only thing on the wire is JSON that nothing currently parses for these fields.

### Resulting schema

```python
class ProcessCppCallChainNode(BaseModel):
    # ... existing fields (method_name, file_name, line_number, ...) ...
    indirection: Optional[IndirectionEnvelope] = None  # ← single canonical field
```

The 4 individual fields are **removed**. JSON output changes from:

```json
{"is_indirect": true, "indirect_via": "R15", "is_virtual_dispatch": false, "cha_base_class": ""}
```

to:

```json
{"indirection": {"is_indirect": true, "indirect_via": "R15"}}
```

(`is_virtual_dispatch` and `cha_base_class` omitted when default — the envelope only carries fields with non-default values, keeping payloads lean.)

### Cleanup task

`INDIRECT_CALL_COVERAGE.md` documents the 4 fields explicitly at:
- Lines 15-23 (overview table)
- Lines 110-121 (FP response shape example)
- Lines 162-173 (CHA response shape example)
- Lines 244-256 (register-indirect example)
- Lines 320-343 (cross-language hop example)

Update each to show the envelope shape. Doc-only edit, no regression risk.

---

## 5. ⚠️ Master gap list (27 sites, 19 files)

Each row is a tracked ticket. Mark as `done` when integrated.

### A. Schemas — need new fields

| ID | Status | File:Line | Symbol | Fix |
|---|---|---|---|---|
| SC1 | ☐ | `api/schemas/processes.py:53-60` | `EdgeInfo` | Add `is_indirect: bool = False`, `indirect_via: Optional[str] = None` |
| SC2 | ☐ | `api/schemas/processes.py:127-135` | `ChainHop` | Add all 4 fields |
| SC3 | ☐ | `api/schemas/conversations.py:192-195` | `VariableLineageEdge` | Add `is_indirect`, `indirect_via` |
| SC4 | ☐ | `api/schemas/conversations.py:157-161` | `FileFlowGraphResponse` | Replace `Dict[str, Any]` with typed model carrying fields |

### B. File-level call graph — root cause for many downstream gaps

| ID | Status | File:Line | Issue |
|---|---|---|---|
| F1 | ☐ | `file_call_graph.py:423` | **Explicit `continue`** drops every C++ `is_indirect=true` edge. Comment says "can't be resolved without runtime dataflow." Decision needed: surface as annotated edge (matches `/cpp-call-chain`) or keep dropping (then update docs). |
| F2 | ☐ | `file_call_graph.py:407-450` (`scan_blueprint_cpp`) | `EdgeDetail` doesn't preserve `is_indirect`, `register` even for ASM edges that have them |
| F3 | ☐ | `file_call_graph.py:850-873` (`format_json`) | Output JSON edge schema has no indirect fields → starves every downstream reader of `file_call_graph.json` |

> **Cascade unlocked by F1–F3:** C1, C2, C3, S1, R5, T1, partial T2

### C. Process-scoped APIs

| ID | Status | Endpoint | File:Line | Issue |
|---|---|---|---|---|
| P1 | ☐ | `GET /v1/jobs/{job_id}/processes/{name}/edges` | `api/routes/processes.py:215-241` | Converts to `EdgeInfo` at line 240 — drops fields. Fix paired with SC1 |
| P2 | ☐ | `POST /v1/jobs/{job_id}/processes/{name}/file-chains` | `api/routes/processes.py:599-657` | Builds `ChainHop` at 635-642 — drops fields. Fix paired with SC2 |
| P3 | ☐ | `GET /v1/jobs/{job_id}/processes/{name}/lineage/sessions/{sid}/file-graph` | `api/routes/processes.py:541-597` | `full_file_flow` returned as opaque `Dict[str, Any]` (schemas/processes.py:111-121); fields silently absent |
| P4 | ☐ | `POST /v1/jobs/{job_id}/processes/{name}/variable-graph` | `api/routes/variable_graph.py:140,251` | Variable domain — optional, only if UI wants per-hop indirect markers |

### D. Conversation / Chat / Lineage APIs

| ID | Status | Endpoint | File:Line | Issue |
|---|---|---|---|---|
| C1 | ☐ | `POST /v1/knowledge-bases/{kb}/conversations/{cid}/keyword-file-flow` | `api/routes/conversations.py:826-1041` | Edges at 998-1001 have only `source/target/label`. Fix paired with F1–F3 |
| C2 | ☐ | `GET /v1/knowledge-bases/{kb}/conversations/{cid}/messages/{mid}/file-flow-graph` | `api/routes/conversations.py:1086-1249` | Edges at 1224-1238 strip all metadata |
| C3 | ☐ | `GET /v1/knowledge-bases/{kb}/conversations/{cid}/messages/{mid}/variable-lineage` | `api/routes/conversations.py:1256-1370` | `VariableLineageEdge` at 1351-1365 only `source/target/label`. Fix paired with SC3 |
| C4 | ☐ | `POST /sessions/{sid}/ask` (SSE) | `api/routes/chat.py:477` | Evidence chunks streamed without indirect-call markers — verify chunk schema |

### E. Backward traversal engine

| ID | Status | File:Line | Issue |
|---|---|---|---|
| B1 | ☐ | `backward_traversal/bridge/cross_file_bridge_backward.py:55,140,236,355` | All 4 caller-finder funcs ignore `is_indirect`/`register` |
| B2 | ☐ | `backward_traversal/runner/backward_only_runner.py:310-333,1784-1790,1917` | `_scan_asm_entries`, `_collect_upstream_asm`, `_collect_downstream_cpp` |
| B3 | ☐ | `backward_traversal/tracing/asm_backward_tracer.py:392-400` | Only extracts return edges — should annotate tuples when call IS indirect |
| B4 ⭐ | ☐ | `backward_traversal/runner/chunked_session.py:118-142` (`_ff_to_serial`) | **CRITICAL** — msgpack serialization drops fields. Without this, backward lineage persists without fields even after upstream fixes |

### F. Async tasks (Celery)

| ID | Status | File:Line | Issue |
|---|---|---|---|
| T1 | ☐ | `api/tasks/kb_chain_summaries_task.py:101-174` (line 134) | `_build_root_chains()` reads only `source/target/instructions` — drops |
| T2 | ☐ | `api/tasks/process_seeds.py:104-108` | Patches edges then writes back — silent pass-through; depends on what's in seeds |

### G. Scope filtering & stitching

| ID | Status | File:Line | Issue |
|---|---|---|---|
| S1 | ☐ | `api/processes/scope.py:103-104,129` | Pass-through copy; safe only if seeds (file_call_graph.json) have fields → blocked on F3 |
| L1 | ☐ | `passes/global_lineage_stitcher.py:337,357,360` | Local→global merge; verify `is_indirect`/`register` survive merge |

### H. Root-level analyzers

| ID | Status | File:Line | Issue |
|---|---|---|---|
| R1 | ☐ | `cross_file_bridge.py:166,248,289,384` | 4 caller-finder funcs drop |
| R2 | ☐ | `trace_cpp_function_lineage.py:203,328,340,343` | Drops |
| R3 | ☐ | `trace_cpp_lineage.py:567,781-782` | Drops |
| R4 | ☐ | `get_call_conditions.py:462,1130,1368` | Drops |
| R5 | ☐ | `find_variable_modifiers.py:227-229` | Inherits F3 |

### I. Explainability / Pi

| ID | Status | File:Line | Issue |
|---|---|---|---|
| E1 | ☐ | `explainability/evidence_collector.py:103-136` (`_normalise_callgraph`) | Extracts only `source/target` — Pi answers never mention indirection |

---

## 6. ➖ Verified Not Applicable

These were audited and confirmed to need no change:

| File / Group | Reason |
|---|---|
| `backward_traversal/graph_extraction/variable_graph_builder.py` | Pure variable dataflow — different domain |
| `backward_traversal/tracing/cpp_backward_tracer.py` | Reads global variable lineage, not call edges |
| `backward_traversal/utils/*` (9 files) | Utility layer; no edge consumption |
| `backward_traversal/cli.py` | Delegates to flagged runner |
| `backward_traversal/tests/` | No edge-field assertions |
| `passes/block_extractor.py:60-62,124-133` | Only needs `call_type`/`target` for block classification |
| `passes/variable_lineage_builder.py` | Variable lineage domain |
| `api/utils/variable_search.py` | Variable search, no edge walk |
| `api/routes/{auth,jobs,upload,analysis,modifiers,universe,pipeline,callgraph,lineage,tasks}.py` | Job dispatchers / metadata only |
| `api/schemas/{auth,upload,common,lineage,knowledge_base}.py` | Auth/request/metadata models |
| `api/tasks/{analysis,callgraph,cleanup,pipeline,universe,lineage,modifiers,variable_usage*,file_summary_fallback,kb_modifiers,kb_file_summaries,kb_backward_lineage*,process_lineage_chunked,variable_graph}_task.py` | Orchestration / dispatch — no call-edge handling beyond what their underlying modules already do |
| `block_flow.py`, `filter_block_lineage.py` | Block-level, not call-level |
| No `frontend/`, `ui/`, `web/`, `mcp_servers/`, root-level `prompts/`, `templates/` exist | N/A |

---

## 7. Cascade-aware fix order

1. **F1–F3** (`file_call_graph.py`) — unlocks C1, C2, C3, S1, R5, T1, partial T2
2. **SC1–SC4** schemas — required before any route can surface fields
3. **B4** ⭐ (`chunked_session.py` msgpack) — persistence layer; without this, backward lineage persists without fields even when upstream is fixed
4. **B1–B3** backward traversal walkers
5. **P1, P2** process-scoped APIs (highest user visibility)
6. **C1–C4** conversation APIs
7. **T1, T2** async tasks
8. **L1, R1–R5** stitcher + root analyzers
9. **E1** evidence collector (last — Pi can then say "this hop is indirect via R15")

---

## 8. Verification criteria (per ticket)

For each fix, the closing check should be:

1. **Unit / regression test** that constructs an edge or response with `is_indirect=True`, `indirect_via="R15"` (or `"fp_callback"`), and asserts those fields survive the touched layer.
2. **End-to-end live test** (per CLAUDE memory `feedback_live_tests`) — real HTTP call against the modified endpoint with a known indirect-call source file, confirm response payload carries the fields.
3. **Round-trip check** for persistence layers (B4, T1, T2): write → read → fields preserved.

---

## 9. Out of scope (intentional limits of static analysis)

The fix surfaces every call site, but some patterns **cannot be resolved** statically — these correctly remain leaf nodes annotated with the indirection mechanism:

| Pattern | Why unresolvable |
|---|---|
| Callback passed as parameter (`void cb(FnPtr fn) { fn(); }`) | Requires interprocedural analysis |
| Template-dependent calls (`template<F> void exec(F fn) { fn(); }`) | Template substitution at compile time |
| Return-value chain (`getBetaFactory()(w)`) | RHS is a call expression |
| Dynamic jump table (`EX R2,table` with runtime-computed index) | Target unknown without execution |
| Computed goto / dynamic base register | Same fundamental limit |
| `auto`-typed / factory-returned object method | Type inference limit |

These are documented in [`INDIRECT_CALL_COVERAGE.md`](../INDIRECT_CALL_COVERAGE.md) under "Known Gaps & Limitations" and are **not** integration gaps in this punch-list.
