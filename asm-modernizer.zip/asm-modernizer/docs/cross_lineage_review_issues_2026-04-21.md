# Cross-File Lineage Review Issues (2026-04-21)

## Fixed (Critical)

1. Lossy `discovered_from` provenance
- Issue: only first queue parent was preserved; additional discoverers were dropped.
- Fix: preserve all discovery parents whenever a file is discovered, even if already queued/visited.
- Code: `trace_cross_file_lineage.py` (`_run_unified_modifier_downstream_traversal`, `_record_discovery`).

2. C++ downstream target type fallback could be wrong
- Issue: downstream C++ target typing defaulted to `asm` when target was absent from `file_type_map`.
- Fix: downstream target typing now uses `_resolve_file_type(...)` with blueprint-based fallback.
- Code: `trace_cross_file_lineage.py` (`_trace_cpp_downstream_calls`, `_resolve_file_type`).

## Open (Non-Critical)

1. Performance overhead in unified traversal
- Observation: per-variable tracing in ASM currently re-runs expensive scans and graph builds; runtime can be high on broad traversals.
- Impact: slower runs, large stderr logs.
- Proposed follow-up: pass pre-scanned setter/usage hits into tracer paths and cache per-file artifacts.

2. Legacy helper code still present
- Observation: old dep-var lineage helper functions remain in file, but new main flow no longer calls them.
- Impact: maintainability/readability only.
- Proposed follow-up: remove deprecated helper blocks in a cleanup PR.

3. Data completeness depends on blueprint availability
- Observation: discovered files without matching blueprint are marked `blueprint_not_found` and cannot be expanded.
- Impact: partial downstream graph in those branches.
- Proposed follow-up: ensure blueprint export coverage or document expected exclusions.
