# ASM-to-CPP Call Chain Traversal Patterns

This document describes all the different ASM to C/C++ function calling
patterns handled by the `/cpp-call-chain` API endpoint, covering both
**forward** (callees) and **backward** (callers) BFS traversal directions.

Reference implementation: `cpp_call_chain/traversal.py`

---

## Table of Contents

1. [Forward Traversal Patterns (ASM calling CPP)](#1-forward-traversal-patterns-asm-calling-cpp)
2. [Backward Traversal Patterns (finding ASM callers of CPP)](#2-backward-traversal-patterns-finding-asm-callers-of-cpp)
3. [ASM Calling Instructions](#3-asm-calling-instructions)
4. [Concrete Calling Patterns in the Codebase](#4-concrete-calling-patterns-in-the-codebase)
5. [IBM / z/TPF Calling Conventions](#5-ibm--ztpf-calling-conventions)
6. [Summary Table](#6-summary-table)
7. [Configuration Parameters](#7-configuration-parameters)

---

## 1. Forward Traversal Patterns (ASM calling CPP)

Forward traversal answers: **"What does this ASM routine call?"**

When the BFS reaches an ASM node, the traversal loads the ASM blueprint
and follows edges into CPP territory.

### 1.1 Intra-File ASM Edge Traversal (Blueprint)

When an ASM routine is being traversed, its blueprint (`*.asm.json`) is
loaded and edges are followed just like CPP blueprints.

- **Source:** ASM blueprint `call_graph.edges` where `edge.source == method`
- **Code:** `traversal.py:549-613` (same loop as CPP, language-agnostic)
- **How it works:** Loads the ASM blueprint via `_load_cg(fstem, blueprint_dir)`,
  which tries `{fstem}.cpp.json`, `{fstem}.asm.json`, then `{fstem}.mac.json`.
  Iterates edges where `source == method` and enqueues each target.
- **Edge properties preserved:** `call_type` (e.g. `"subroutine_call"`),
  `instruction` (e.g. `"ENTRC"`, `"CALLC"`, `"ENTNC"`), `line`, `is_indirect`
- **Language detection:** Target language determined from `file_types` index;
  if target is a CPP file, the node gets `language="cpp"` and signature
  enrichment is applied.

```
Example edge in ASM blueprint:
  {source: "DA760000", target: "DE70", call_type: "subroutine_call",
   instruction: "ENTRC", line: 91}
```

### 1.2 Cross-Language Forward (ASM to CPP)

After processing intra-file blueprint edges, the traversal checks the
cross-language index for ASM→CPP boundary edges.

- **Source:** `cross_lang.forward` index built from `file_call_graph.json`
- **Code:** `traversal.py:615-637`
- **How it works:** Looks up `(asm_stem, asm_method)` in `_cl_forward`.
  Any targets with `file_type == "cpp"` are enqueued. BFS continues into
  CPP territory with full CPP-mode processing (signature enrichment,
  CHA expansion, etc.).
- **Edge metadata preserved:** `call_type`, `instruction`, `line` from
  the `file_call_graph.json` call site.

```python
# Cross-language index entry example:
_cl_forward[("da76", "DA760000")] = [
    {"stem": "de70_module", "method": "DE70", "call_type": "subroutine_call",
     "instruction": "ENTRC", "line": 91, "file_type": "cpp"},
]
```

### 1.3 ASM Metadata Resolution Fallback

When an ASM routine is not found in the CPP-centric definitions index,
the traversal falls back to extracting metadata directly from the ASM
blueprint.

- **Source:** ASM blueprint `call_graph.nodes[method]`
- **Code:** `traversal.py:165-189` (`_resolve_node_from_blueprint`)
- **How it works:** Loads the ASM blueprint's call graph nodes section and
  extracts `file_path`, `is_external`, and `kind` (typically `"routine"`).
- **When used:** For any node where `language != "cpp"` and the definitions
  index has no entry (lines 434-435).

### 1.4 Indirect Call from ASM (Resolved Target)

ASM routines can make indirect calls (e.g., `BALR R14,R15`) where static
analysis resolves the target.

- **Source:** ASM blueprint edge with `is_indirect=true` and a known `target`
- **Code:** `traversal.py:555-560` (flag extraction and opt-out filter),
  `traversal.py:598-613` (enqueue with indirection envelope)
- **How it works:** Edge has `is_indirect=true` and a `register` field
  (e.g. `"R15"`). If `include_indirect_calls` is false, the edge is
  skipped at line 560. Otherwise the resolved CPP target is enqueued at
  lines 598-613 with an indirection envelope attached at lines 606-610:
  `{is_indirect: true, indirect_via: "R15"}`
- **Controlled by:** `include_indirect_calls` parameter

### 1.5 Indirect Call from ASM (Unresolved Target)

When an ASM indirect call (e.g., branch-via-register) cannot be resolved
to a concrete target.

- **Source:** ASM blueprint edge with `is_indirect=true` and **no target**
- **Code:** `traversal.py:563-587`
- **How it works:** Creates a synthetic leaf node named `(indirect via R15)`
  or similar. BFS does not continue through it.
- **Common ASM pattern:** `BALR R14,R15` where R15 holds a function pointer
  loaded at runtime.

```asm
; Example — unresolved indirect call in ASM
         L     R15,FUNC_ADDR       ; Load function pointer
         BALR  R14,R15             ; Branch and link (indirect)
```

### 1.6 No Source Fallback for ASM

Unlike CPP nodes, ASM nodes have **no source fallback**. When an ASM
blueprint is missing, a warning is emitted but no source scanning is
attempted.

- **Code:** `traversal.py:540-544`
- **Warning:** `"ASM blueprint not found for '{fstem}'; callees of '{method}' may be incomplete."`

---

## 2. Backward Traversal Patterns (finding ASM callers of CPP)

Backward traversal answers: **"Who calls this function?"**
For ASM→CPP, this means finding ASM routines that call a given CPP function.

### 2.1 Cross-Language Backward (ASM callers of CPP)

The primary mechanism for finding ASM callers of a CPP function. Uses the
pre-built cross-language backward index.

- **Source:** `cross_lang.backward` index built from `file_call_graph.json`
- **Code:** `traversal.py:855-881`
- **How it works:** Looks up `(cpp_stem, cpp_method)` in `_cl_backward`.
  Any entries with `file_type == "asm"` or `"mac"` are enqueued as callers.
  BFS continues into ASM territory.
- **Edge metadata:** `call_type`, `instruction` (ENTRC, CALLC, etc.),
  `call_line`

```python
# Cross-language backward index entry example:
_cl_backward[("cf500000", "CF55")] = [
    {"stem": "xh80", "method": "XH80_MAIN", "call_type": "subroutine_call",
     "instruction": "ENTRC", "line": 97, "file_type": "asm"},
]
```

### 2.2 ASM Blueprint Edge Inversion (Intra-File)

When backward-traversing through an ASM node, the blueprint edges are
inverted to find intra-file callers within the same ASM module.

- **Source:** ASM blueprint edges where `edge.target == method`
- **Code:** `traversal.py:759-780`
- **How it works:** Loads the ASM blueprint, iterates all edges, finds those
  where `target == method`. The `source` of each matching edge is treated
  as a caller. Indirection metadata is merged via `merge_indirection()`.
- **Why needed:** The callers index (pattern 2.3) is built from ALL
  blueprints (CPP, ASM, MAC) and does contain intra-file ASM caller
  entries. Blueprint edge inversion serves as a safety net ensuring all
  intra-file edges are discovered, including any that may not have been
  captured during index building. Duplicate callers are filtered by the
  visited set.

```python
# Example: In xh80.asm.json, edge {source: "XH80_MAIN", target: "CM_GET_LREC_WKA"}
# → backward from CM_GET_LREC_WKA finds XH80_MAIN as a caller
```

### 2.3 Callers Index for CPP Nodes Called by ASM

When backward-traversing a CPP function, the pre-built callers index
provides O(1) lookup. The callers index is built from ALL blueprints
(CPP, ASM, MAC) without language filtering, so it may contain ASM→CPP
caller entries if the ASM blueprint captured the edge. Cross-language
backward (pattern 2.1) provides additional coverage.

- **Source:** `index.callers[method]` — built from all blueprints
  (`index_builder.py:183-206`)
- **Code:** `traversal.py:757`
- **Note:** While the callers index processes all blueprint types, the
  cross-language backward map (pattern 2.1) remains the primary
  mechanism for discovering ASM callers of CPP functions, because it
  is specifically built from `file_call_graph.json` cross-language edges.

### 2.4 No Source Fallback for ASM Backward

Source fallback scanning (`scan_callers_in_source`) only applies to CPP
nodes at depth 0. ASM backward traversal has no source fallback.

- **Code:** `traversal.py:782-809` (CPP-only branch)

### 2.5 Backward CHA Expansion

When backward-traversing a derived-class method, backward CHA expansion
enqueues the corresponding base-class methods so that callers dispatching
via virtual pointers are also discovered.

- **Code:** `traversal.py:318-370` (`_apply_cha_expansion_backward`)
- **Traversal call site:** `traversal.py:840-853`
- **Controlled by:** `expand_virtual_dispatch` parameter

---

## 3. ASM Calling Instructions

These are the z/TPF ASM instructions that create call edges to C/C++
functions, as seen in the `temp/asm` codebase and documented in IBM
references.

### 3.1 ENTRC — Enter with Return Expected

The most common ASM→external call instruction in the codebase (88 instances).

- **Syntax:** `ENTRC <target_module>`
- **Behaviour:** Transfers control to target program, expects return
- **Return:** YES — returns to caller
- **Call graph edge:** `call_type="subroutine_call"`, `instruction="ENTRC"`
- **Parameter passing:** Via `R1` (parameter list pointer) or CPROC convention

```asm
; Source: da76.asm:91
DA760000 EQU   *
         ENTRC DE70                     MESSAGE MONITOR CHECK
```

### 3.2 CALLC — Direct ASM-to-C Function Call

The modern, type-safe ASM-to-C calling mechanism. Requires a matching
`CPROC` prototype declaration.

- **Syntax:** `CALLC function_name(R2,R3,...)`
- **Behaviour:** Calls a C function with typed parameters
- **Return:** YES — return value in `R15` (integer/pointer) or `F0` (float)
- **Call graph edge:** `call_type="call"`, `instruction="CALLC"`
- **Parameter passing:** Registers R2-R7 (up to 12 parameters); R15 cannot
  be used as input
- **Prerequisite:** `CPROC` declaration must precede the call

```asm
; Example from IBM docs
         CPROC RETURN=i,validate_customer,(p,i)
         LA    R2,CUSTREC              ; param 1: pointer
         LHI   R3,80                   ; param 2: int
         CALLC validate_customer(R2,R3)
         LTR   R15,R15                 ; check return
         BNZ   BAD_CUSTOMER
```

### 3.3 ENTNC — Enter with No Return Expected

Transfer control without expecting a return. Used for tail-call / handoff
patterns.

- **Syntax:** `ENTNC <target_module>`
- **Behaviour:** Transfers control, no normal return expected
- **Return:** NO — terminal/handoff edge
- **Call graph edge:** `call_type="no_return_call"`, `instruction="ENTNC"`
- **Codebase instances:** 8

```asm
; Source: xh82.asm:139
         ENTNC XH88                CONTINUE WITH MORE UPDATES
```

### 3.4 ENTDC — Enter with Drop (Program Termination)

Transfers control and drops the calling program from the stack. No return.

- **Syntax:** `ENTDC <target_module>`
- **Behaviour:** Transfers control, drops prior programs
- **Return:** NO — terminal edge
- **Call graph edge:** `call_type="no_return_call"`, `instruction="ENTDC"`
- **Codebase instances:** 1 (used inside FUNCTION macro expansion)

```asm
; Source: lu82.asm:125 (inside FUNCTION macro)
         ENTDC &SEG              ENTER EXPANSION FOR HANDLING SEGMENT
```

### 3.5 CREEC — Create Entry with Continuation

Creates an asynchronous entry (independent ECB) targeting another module.
**Not a normal function call** — state does not flow like a subroutine.

- **Syntax:** `CREEC <target>,<parm>,<reg>`
- **Behaviour:** Creates independent ECB processing entry
- **Return:** N/A — async boundary, current program continues
- **Call graph edge:** Should be treated as async boundary, not call edge
- **Codebase instances:** 1

```asm
; Source: da78.asm:1255
         SR    R14,R14                 ZERO PARAMETER
         CREEC GA71,D0,R               HIGH PRIORITY
```

### 3.6 FUNCTION Macro — TPF Request Routing

A TPF-specific macro that maps a 4-character request name to a target
module entry point. Used for message-based dispatch.

- **Syntax:** `FUNCTION <request_name>,<target_module>`
- **Behaviour:** Registers a routing entry; expands to `ENTDC` internally
- **Return:** NO — dispatches via ENTDC
- **Call graph edge:** `call_type="no_return_call"`, `instruction="FUNCTION"`
- **Codebase instances:** 191 (all in lu82.asm)

```asm
; Source: lu82.asm:225-1022 (selection)
         FUNCTION CIPS,LU84          CAS INTRANET PRESENTATION SVCS
         FUNCTION ISC1,DB84          SELF TEST - REQUEST
         FUNCTION GB72,GB72          REQUEST PROCESSOR
         FUNCTION FASI,BB35          ER,INQ (UNIQUE FOR INTRANET)
```

### 3.7 SWISC — Switch Index Service Call

Switch-based routing to an external module.

- **Syntax:** `SWISC <target_module>`
- **Codebase instances:** 1

```asm
; Source: xh80.asm:1219
CM_80_010  SWISC GA71
```

### 3.8 CPROC — C Function Prototype Declaration

Metadata-only declaration that defines a C function's signature for
subsequent `CALLC` or `ENTxC` calls. No runtime effect.

- **Syntax:** `CPROC RETURN=<type>,<function_name>,(<param_types>)`
- **Return types:** `i` (int), `p` (pointer), `f` (float), `v` (void)
- **Parameter types:** `i` (int), `p` (pointer), `f` (float)
- **Call graph significance:** Metadata node, not an edge. Used to type
  cross-language call edges.

### 3.9 BACKC — Return from Called Program

Return instruction that transfers control back to the caller after an
ENTRC-style call. This is the counterpart to ENTRC.

- **Syntax:** `BACKC`
- **Behaviour:** Returns to the calling program
- **Return:** N/A — this IS the return
- **Call graph edge:** Not a call edge; marks the end of a subroutine
- **Codebase instances:** 19 (across 14 ASM files)
- **Code recognition:** Recognized in `passes/call_graph_builder.py` and
  `passes/variable_lineage_builder.py` as a return instruction

```asm
; Source: xh81.asm:1868
         BACKC
; Source: xh83.asm:223
         BACKC
```

### 3.10 EXITC — Exit from Current Entry Point

Exits the current program entry point. Similar to BACKC but may have
different stack-unwinding semantics.

- **Syntax:** `EXITC`
- **Behaviour:** Exits current entry point
- **Return:** N/A — terminates current execution
- **Call graph edge:** Not a call edge; treated as `CallType.RETURN` by
  the blueprint generator
- **Codebase instances:** 4 (3 in da76.asm, 1 in lu82.asm via DONTCARE macro)
- **Code recognition:** Handled explicitly in `passes/call_graph_builder.py:832`
  with `CallType.RETURN`

```asm
; Source: da76.asm
         EXITC
```

### 3.11 CALLCPP — ASM to C++ Bridge

A modern macro for calling C++ functions directly from ASM. Recognized by
the call graph builder as a standard call edge.

- **Syntax:** `CALLCPP <target>`
- **Behaviour:** Calls a C++ function
- **Return:** YES
- **Call graph edge:** `CallType.CALL`
- **Codebase instances:** 0 in temp/asm (recognized by call graph builder)
- **Code recognition:** Handled in `passes/call_graph_builder.py:816`

> **Note:** The blueprint (`call_graph_builder.py`) stores `CallType.CALL`
> (value `"call"`) for CALLCPP/CALLC edges. However, `INSTRUCTION_CALL_TYPE`
> in `file_call_graph.py` maps both to `"subroutine_call"`. Blueprint edges
> carry `call_type="call"`, while `file_call_graph.json` edges carry
> `call_type="subroutine_call"`.

### 3.12 ATTAC / ATTC — Attach Child ECB/Task

Creates and attaches a child ECB or task. Similar to CREEC but with
attach semantics.

- **Syntax:** `ATTAC <target>` or `ATTC <target>`
- **Behaviour:** Spawns a child task/ECB (when operand is a program name)
- **Return:** N/A — async spawn
- **Call graph edge:** `CallType.ASYNC_SPAWN`
- **Codebase instances:** 31 ATTAC in temp/asm, but all are **data-level
  attach** operations (e.g., `ATTAC D0`, `ATTAC D7`) that attach a core
  block to an ECB data level. Zero spawn-form ATTAC with a program name
  target exists in the current codebase.
- **Code recognition:** Handled in `passes/call_graph_builder.py:799`

### 3.13 CREMC — Create Immediate Ready-List Entry

Creates an immediate ready-list entry (async boundary). Recognized by the
call graph builder alongside CREEC.

- **Syntax:** `CREMC <target>,<parm>,<reg>`
- **Behaviour:** Creates an immediate async entry
- **Return:** N/A — async boundary
- **Call graph edge:** Async boundary (same as CREEC)
- **Codebase instances:** 0 in temp/asm (recognized by call graph builder)
- **Code recognition:** Handled in `passes/call_graph_builder.py:765`
  alongside CREEC

### 3.14 EXSR -- Execute Subroutine

A z/TPF cross-file call opcode for executing a named subroutine in
another module.

- **Syntax:** `EXSR <target_subroutine>`
- **Return:** YES
- **Call graph edge:** `call_type="subroutine_call"`, `instruction="EXSR"`
- **Cross-file inclusion:** In `CROSS_FILE_CALL_OPCODES` (`instructions.py:84-85`)
- **Code recognition:** Handled in `passes/call_graph_builder.py:765`
  alongside ENTRC
- **Codebase instances:** 0 in current temp/asm

### 3.15 IBM-Documented Patterns (Not in Codebase)

The following instructions are documented in the IBM z/TPF references
but are not present in the `temp/asm` source files. They may appear in
other z/TPF codebases.

| Instruction | Purpose | IBM Reference | Status |
|-------------|---------|---------------|--------|
| CRETC | Time-initiated entry | `ztpf-system-macros.md` | Now in builder (`async_spawn`) |
| CREXC | Low-priority deferred entry | `ztpf-system-macros.md` | Now in builder (`async_spawn`) |
| CRESC | Synchronous entry (suspends current) | `ztpf-system-macros.md` | Now in builder (`sync_spawn`) |
| CLINKC | C-linkage call to BAL function | `asm-c-interoperability.md` | Now in builder (`subroutine_call`) |
| RLINKC | Return from C-linkage function | `asm-c-interoperability.md` | Now in builder (`return`) |
| SLINKC | Link macro for C interop | `asm-c-interoperability.md` | Falls through to generic macro handler |
| UPROC | Include directive for CPROC bundles | `asm-c-interoperability.md` | Not in builder |
| PRLGC | Prolog for C-callable BAL library function | `asm-c-interoperability.md` | Not in builder |
| EPLGC | Epilog for C-callable BAL library function | `asm-c-interoperability.md` | Not in builder |
| TMSPC | Old prolog (TPF 4.1 compatibility) | `asm-c-interoperability.md` | Not in builder |
| TMSEC | Old epilog (TPF 4.1 compatibility) | `asm-c-interoperability.md` | Not in builder |

> **Note:** CREDC was previously listed here but has been in the builder
> since before this update (`CallType.ASYNC_SPAWN`). It is documented in
> §3.5 alongside CREEC/CREMC.

---

## 4. Concrete Calling Patterns in the Codebase

These are the actual ASM→CPP calling patterns found in the `temp/asm`
source files with file locations and line numbers.

### 4.1 ENTRC to External Module (Most Common)

88 instances across 15 ASM files. The dominant cross-module call pattern.

```asm
; Source: da76.asm:91
DA760000 EQU   *
         ENTRC DE70                     MESSAGE MONITOR CHECK

; Source: da76.asm:98
         ENTRC DB73                     CONVERT FORMAT

; Source: xh80.asm:97
         ENTRC XI73               PRE-EDIT FOR G1 INPUT RCD

; Source: xh80.asm:449
         ENTRC XH81               PROCESS CARD ATTRIBUTES/LIMITS

; Source: xh81.asm:231
         ENTRC HD78     GET PRODUCT CODES AND DESCRIPTIONS

; Source: xh88.asm:1074
         ENTRC BR11                UPDATE/CREATE/DELETE..
```

- **Traversal:** Blueprint edge with `call_type="subroutine_call"`,
  `instruction="ENTRC"`. If target module has a CPP blueprint, it crosses
  the language boundary via `cross_lang.forward`.

### 4.2 ENTRC with Register Parameter Setup

Parameters are loaded into registers before the ENTRC call.

```asm
; Source: ae48.asm:603-613
         JAS   R14,UA80PAR1        CONVERT TO DAYS SINCE 01/01/00
         JAS   R1,UA80DAT1
         L     R4,JULSAVE          RESTORE JULIAN VALUE
         ENTRC UA88

; Source: xh80.asm:389
         BAS   R10,CM_GET_LREC_WKA  CALL XH90 TO CREATE A7 LREC WKA
```

- **Traversal:** Same as 4.1. Register setup instructions are not tracked
  as separate edges; the ENTRC is the call edge.

### 4.3 ENTNC for Tail-Call / Handoff

Used when the current routine is done and transfers control permanently.

```asm
; Source: xh82.asm:139
         ENTNC XH88                CONTINUE WITH MORE UPDATES

; Source: da78.asm:1002
DA7_0930 EQU   *
         ENTNC DA7G                    LOG AND SEND RESPONSE

; Source: lu82.asm:209
LU8X100  EQU   *
         ENTNC LU83                CONTINUE IN LU83 IF NOT FOUND

; Source: xh80.asm:3332
FINALIZE EQU   *
         ENTNC XW79                    POST ECB & EXIT PROCESSING
```

- **Traversal:** Blueprint edge with `call_type="no_return_call"`,
  `instruction="ENTNC"`. Terminal edge — BFS continues at the target
  but the source is not expected to resume.

### 4.4 CREEC for Async Entry Creation

Creates an independent processing entry. Not a normal subroutine call.

```asm
; Source: da78.asm:1245-1255
         L     R15,CE1CR0              L7D7D BASE
         MVC   L7DTHH,EBW000           SAVE HOURS
         MVC   L7DTMM,EBW003           SAVE MINUTES
         MVC   L7DTSS,EBW006           SAVE SECONDS
         SR    R14,R14                 ZERO PARAMETER
         CREEC GA71,D0,R               HIGH PRIORITY
```

- **Traversal:** Should be treated as an async boundary. The target `GA71`
  runs in an independent ECB — register and local state do not carry over.

### 4.5 FUNCTION Macro Dispatch Table (lu82.asm)

191 entries mapping 4-character request names to target modules. This is
TPF's message routing mechanism.

```asm
; Source: lu82.asm:225-1022 (selection)
         FUNCTION CIPS,LU84          CAS INTRANET PRESENTATION SVCS
         FUNCTION ISC1,DB84          SELF TEST - REQUEST
         FUNCTION ISC2,DB84            "   "   - REPLY
         FUNCTION ISC3,DB83          OPERATOR-TO-OPERATOR (MSG)
         FUNCTION GB72,GB72          REQUEST PROCESSOR
         FUNCTION GB73,GB73          REPLY PROCESSOR
         FUNCTION CO72,CO72          OPTIMA ACCUM DELETE REQUESTS
         FUNCTION XQ76,XQ76          OPTIMA LOC MAINTENANCE REQUESTS
         FUNCTION SEDB,SB88
         FUNCTION DE84,DE84          REQUEST PROCESSOR
         FUNCTION HB5C,HB5C          REQUEST PROCESSOR
         FUNCTION FASI,BB35          ER,INQ (UNIQUE FOR INTRANET)
         FUNCTION FASJ,BB36          ER,ADD (ONE STEP FOR INTRANET)
         FUNCTION EXC0,VA60          EXC0_EC_ADD
```

- **Traversal:** Each FUNCTION macro expands internally to `ENTDC`, creating
  a non-returning dispatch edge. Blueprint captures these as edges with
  `instruction="FUNCTION"`.

### 4.6 SWISC Service Call

```asm
; Source: xh80.asm:1219
CM_80_010  SWISC GA71
```

- **Traversal:** Captured as a blueprint edge to the target module.

### 4.7 Intra-File BAS/JAS Subroutine Calls

Internal subroutine calls within the same ASM module using branch-and-save.

```asm
; Source: xh80.asm:389
         BAS   R10,CM_GET_LREC_WKA  CALL XH90 TO CREATE A7 LREC WKA

; Source: ae48.asm:603
         JAS   R14,UA80PAR1        CONVERT TO DAYS SINCE 01/01/00
```

- **Traversal:** These are intra-file calls within the ASM module. They
  appear as blueprint edges with `source` and `target` in the same file.
  Backward traversal finds them via blueprint edge inversion (pattern 2.2).

---

## 5. IBM / z/TPF Calling Conventions

From the IBM z/TPF documentation (`temp/ibm/`).

### 5.1 CALLC Calling Convention

The modern, type-safe mechanism for ASM calling C/C++.

| Aspect | Detail |
|--------|--------|
| **Prototype** | `CPROC RETURN=<type>,<name>,(<param_types>)` |
| **Call** | `CALLC <name>(R2,R3,...)` |
| **Input registers** | R2-R7 for up to 6 parameters; up to 12 total |
| **Return register** | R15 (int/pointer) or F0 (floating-point) |
| **R15 restriction** | Cannot be used as input parameter |
| **Structure passing** | By pointer only; never in registers |
| **Structure return** | Not supported; use pointer return |

### 5.2 Entry Transfer Classification

| Instruction | Returns? | Edge Type | Description |
|-------------|----------|-----------|-------------|
| CALLC | YES | `call` | Type-safe C function call via CPROC |
| ENTRC | YES | `subroutine_call` | Program call with return expected |
| ENTDC | NO | `no_return_call` | Program call, drops caller from stack |
| ENTNC | NO | `no_return_call` | Program call, no return expected |
| CREDC | N/A | `async_spawn` | Deferred entry creation (independent ECB) |
| CREEC | N/A | `async_spawn` | Entry with storage attachment |
| CREMC | N/A | `async_spawn` | Immediate ready-list entry |
| CRETC | N/A | `async_spawn` | Time-initiated entry |
| CREXC | N/A | `async_spawn` | Low-priority deferred entry |
| CRESC | N/A | `sync_spawn` | Synchronous entry, caller suspends |
| CLINKC | YES | `subroutine_call` | C-linkage call to BAL function |

### 5.3 Register Conventions

| Register | Role | Constraints |
|----------|------|-------------|
| R1 | Parameter pointer (ENTRC style) | Address of parameter block |
| R2-R7 | CALLC input parameters | Positional; count must match CPROC |
| R9 | ECB base register | Must point to ECB; clobbering invalidates macro calls |
| R14 | GETCC output / link register | Receives allocated storage address |
| R15 | Return value register | Cannot be CALLC input; set by CALLC/ENTRC returns |
| F0 | Floating-point return | Used when CPROC declares `RETURN=f` |

### 5.4 Parameter Passing Patterns

**Register-Based (CALLC style — preferred):**
```asm
CPROC RETURN=i,validate_customer,(p,i)
LA    R2,CUSTREC              ; param 1: pointer
LHI   R3,80                   ; param 2: int
CALLC validate_customer(R2,R3)
LTR   R15,R15                 ; check return
```

**Storage-Based (ENTRC / TPF 4.1 style — legacy):**
```asm
LA    R1,PARM_BLOCK           ; param pointer in R1
ENTRC TARGET_MODULE            ; old-style parameter passing
```

### 5.5 Return Value Handling

```asm
; Integer/pointer return (R15)
CALLC myfunc(R2,R3)
LTR   R15,R15              ; test return value
BZ    SUCCESS               ; branch on zero
ST    R15,RCODE             ; store return code

; Floating-point return (F0)
CALLC get_balance()
STD   F0,BALANCE_AREA       ; store float result

; Void return
CALLC side_effect_func(R2)
; no return value to check
```

### 5.6 Hidden State Across ASM→CPP Boundaries

State that flows implicitly across ASM→CPP call boundaries:

| State | Register/Location | Impact |
|-------|-------------------|--------|
| ECB context | R9 | Must be preserved; many z/TPF macros depend on it |
| Database context | R3 (SW00SR slot) | Mutable hidden state for open subfile operations |
| Storage ownership | CBRW | Core block reference words tied to ECB data levels |
| Transaction scope | TXBGC/TXCMC | DB file opens must close in same scope |
| Active keys | Internal | Persist across calls |

### 5.7 Async vs. Synchronous Boundaries

**Async boundaries (CREDC/CREEC/CREMC/CRETC):**
- Create independent ECB processing
- Register/local state does NOT carry over
- Should NOT be modelled as subroutine call edges
- The created entry runs independently

**Synchronous boundary (CRESC/tpf_cresc):**
- Creates entry and suspends current ECB
- Current program waits until created entry completes
- Semantically a blocking call, but state isolation applies

---

## 6. Summary Table

### 6.1 Forward Traversal (ASM→CPP)

| # | Pattern | Data Source | Key Feature |
|---|---------|-------------|-------------|
| 1 | Intra-file ASM edge (blueprint) | `*.asm.json` call_graph edges | Same traversal loop as CPP; preserves ASM instruction type |
| 2 | Cross-language forward | `cross_lang.forward[(asm_stem, method)]` | Crosses into CPP territory; enables CPP-mode processing |
| 3 | ASM metadata fallback | ASM blueprint `call_graph.nodes` | When definitions index has no entry for ASM routine |
| 4 | Indirect call (resolved) | ASM blueprint edge + `is_indirect` | Register-based function pointer with known target |
| 5 | Indirect call (unresolved) | ASM blueprint edge + `is_indirect`, no target | Synthetic leaf `(indirect via R15)`, BFS stops |
| 6 | No source fallback | — | Warning emitted; no ASM source scanning |

### 6.2 Backward Traversal (finding ASM callers of CPP)

| # | Pattern | Data Source | Key Feature |
|---|---------|-------------|-------------|
| 7 | Cross-language backward | `cross_lang.backward[(cpp_stem, method)]` | Finds ASM routines that call a CPP function |
| 8 | ASM blueprint edge inversion | ASM blueprint edges (inverted) | Intra-file ASM callers; O(edges) per hop |
| 9 | CPP callers index | `index.callers` (all blueprints) | May contain ASM→CPP entries; cross-lang backward is primary for ASM callers |
| 10 | No source fallback for ASM | — | Source scanning is CPP-only |

### 6.3 ASM Calling Instructions

| # | Instruction | Returns? | Call Graph Edge | Codebase Count |
|---|-------------|----------|-----------------|----------------|
| 1 | ENTRC | YES | `subroutine_call` | 88 |
| 2 | CALLC | YES | `call` (typed via CPROC) | 0 in temp/asm (documented in IBM) |
| 3 | ENTNC | NO | `no_return_call` | 8 |
| 4 | ENTDC | NO | `no_return_call` | 1 (+ 191 via FUNCTION macro) |
| 5 | FUNCTION | NO | `no_return_call` (expands to ENTDC) | 191 |
| 6 | CREEC | N/A | `async_spawn` | 1 |
| 7 | SWISC | varies | `isc_route` | 1 |
| 8 | CPROC | — | metadata only | 0 in temp/asm (documented in IBM) |
| 9 | BACKC | N/A (return) | return (not a call edge) | 19 |
| 10 | EXITC | N/A (return) | return (not a call edge) | 4 |
| 11 | CALLCPP | YES | `call` | 0 in temp/asm (recognized by builder) |
| 12 | ATTAC/ATTC | N/A | `async_spawn` | 31 data-level attach, 0 spawn-form |
| 13 | CREMC | N/A | `async_spawn` | 0 in temp/asm (recognized by builder) |
| 14 | EXSR | YES | `subroutine_call` | 0 in temp/asm (in builder) |
| 15 | CRETC | N/A | `async_spawn` | 0 (in builder) |
| 16 | CREXC | N/A | `async_spawn` | 0 (in builder) |
| 17 | CRESC | N/A | `sync_spawn` | 0 (in builder) |
| 18 | CLINKC | YES | `subroutine_call` | 0 (in builder) |
| 19 | RLINKC | N/A (return) | `return` | 0 (in builder) |

---

## 7. Configuration Parameters

These request-level parameters affect ASM→CPP traversal:

| Parameter | Default | Effect on ASM→CPP |
|-----------|---------|-------------------|
| `direction` | `"forward"` | Forward: traces ASM callees into CPP. Backward: finds ASM callers of CPP. |
| `max_depth` | `5` | Maximum BFS hops across language boundaries |
| `include_external` | `false` | Include stdlib/external functions encountered after crossing into CPP |
| `include_indirect_calls` | `true` | Include register-based indirect calls from ASM (e.g., `BALR R14,R15`) |
| `expand_virtual_dispatch` | `true` | Apply CHA to all nodes; only CPP methods with `::` in their name benefit from expansion |
| `max_nodes` | `1,000,000` | Maximum nodes to collect before truncation |
| `source_path` | `null` | Only used for CPP source fallback; no effect on ASM nodes |
| `include_params` | `true` | Signature enrichment applied only to CPP nodes in the chain |
| `force_rebuild_index` | `false` | Forces re-parse of blueprints and file_call_graph.json |

---

## CPP Entry Points Called from ASM in this Codebase

These are CPP modules (with `extern "C"` entry points) that are called
from ASM code via ENTRC or FUNCTION macros.

| CPP Module | Source File | Called From (ASM) | Call Mechanism |
|------------|-------------|-------------------|----------------|
| DX75 | dx750000.cpp | lu82.asm (FUNCTION C126, C127, C128, C130, C410, C411, +16 more) | FUNCTION→ENTDC dispatch |
| XH89 | xh890000.cpp | xh85.asm:338, xh88.asm:1787 (ENTRC XH89) | `extern "C" GlDb::Rc XH89(int, ...)` |

**Traversal:** These CPP entry points appear as ASM→CPP boundary
crossings. Forward traversal from ASM finds them via cross-language
index forward (pattern 1.2). Backward traversal from CPP finds the ASM
callers via cross-language index backward (pattern 2.1).

---

## File References

| Component | Path |
|-----------|------|
| Forward traversal | `cpp_call_chain/traversal.py:377-639` |
| Backward traversal | `cpp_call_chain/traversal.py:646-883` |
| ASM metadata fallback | `cpp_call_chain/traversal.py:165-189` |
| Cross-language index builder | `cpp_call_chain/index_builder.py:526-778` |
| Index builder (ASM blueprint processing) | `cpp_call_chain/index_builder.py:220-332` |
| Indirection utils | `api/utils/indirection.py` |
| Endpoint handler | `api/routes/knowledge_base.py:2504-2832` |
| ASM call graph builder | `passes/call_graph_builder.py` |
| Variable lineage builder | `passes/variable_lineage_builder.py` |
| IBM ASM-C interop docs | `temp/ibm/patterns/asm-c-interoperability.md` |
| IBM system macros docs | `temp/ibm/macros/ztpf-system-macros.md` |
| IBM OS C functions docs | `temp/ibm/functions/ztpf-os-c-functions.md` |
| IBM migration notes | `temp/ibm/migration-notes.md` |
