# Finding the Important Variables of a Process

How the hier walk identifies a process's important variables and classifies them
as **Input / Output / Key‑business**.

---

## The idea in one line

Ride on the hier walk (which already clubs a process's functions together), pull
the important variables **out of the real source on demand**, then make **one
whole‑process pass** to label them.

---

## Why two passes

A single activity can't tell you if a value is an input or an output — a number
*read* in one step may be the *result* the whole process emits. Direction is a
**whole‑process** property. So:

| Pass | Scope | Question | Output |
|------|-------|----------|--------|
| **Pass 1 — Extract** | per file (its clubbed routines) | *Which variables matter here, and what happens to them?* | per‑file observations |
| **Pass 2 — Classify** | whole process | *Across everything, is each one input / output / key‑business?* | labels + role |

---

## Pass 1 — Extract (per file, on demand)

For each **kept** file (off‑process plumbing is already pruned by the relevance
gate), club its reached, non‑utility routines and hand the **actual source** to
the LLM. It returns, per important variable:

- **business name** (e.g. "Card Security Code")
- **raw identifier** — exactly as written in the code
- **io_direction** — `read` / `written` / `computed` / `read_write` *in this file*
- **what happens** — one line
- **importance** — high / medium / low
- **components** — if the variable PACKS several sub-values (a record/area/struct),
  the business names of the parts it carries (empty for a plain scalar/flag)
- **decisions_driven** — how many decisions/branches in this code hinge on it

Source‑only. We do **not** read the blueprint's stored variable lineage (empty
for this corpus) or any precomputed variable DB — everything is generated fresh
from code.

### Anti‑hallucination anchor
Every returned variable must have its raw identifier **actually appear in the
source we showed the model**. Anything that doesn't is dropped. So every variable
is traceable to real code.

---

## Aggregate (deterministic, no LLM)

Merge the per‑file observations into one global variable, keyed by a canonical
slug of the business name. For each variable we now know, across the whole
process:

- every raw identifier it goes by
- which files **read** it vs **write/compute** it
- **fan‑in** — how many files touch it
- combined io‑direction and highest importance
- **components** (union of sub-values it carries) and **decision_count**
  (total decisions it gates across the process)
- evidence (file + routines + direction)

These global properties are exactly what makes the next pass accurate.

---

## Score — how much it PACKS, and how much it MATTERS (deterministic)

Two reproducible 0–100 scores derived from the aggregated evidence, normalised
relative to the richest/most-important variable in this process:

- **packing_score** — *how much the variable carries & drives*: the sub-components
  it bundles + the decisions it gates + the alias forms it goes by + its reach.
  Labelled `rich` / `moderate` / `atomic`. (An ISO-8583 message area that carries
  account number, expiry and track data is `rich`; a single edit-log flag is `atomic`.)
- **process_importance** — *how important to the END-TO-END process*: reach across
  files + decisions gated + being a central (key_business) value or the produced
  decision/return code. Every variable also gets an **importance_rank** (1 = most
  important to the whole process).

Numbers are deterministic so they are stable and explainable; the LLM only adds a
one-line **why_important** for the top-ranked variables.

---

## Pass 2 — Classify (whole process)

Give the LLM the **process profile** + the aggregated variables with their io
evidence, and assign each a **multi‑label** classification (a variable can carry
more than one label, or none):

- **input** — comes from outside and is consumed (read, not produced here).
- **output** — a result the process produces/writes (decisions, counters,
  response fields, persisted records).
- **key_business** — a central business value the process reasons about,
  regardless of direction (account number, security code, fraud/auth decision).

The evidence drives it: *read‑only and early* → input; *written / returned* →
output; *high fan‑in + business‑named* → key_business. Pass 2 also writes a
one‑line **role across the whole process** and a final importance.

---

## Output

- Persisted in `hier_variable` (cache).
- Written to **`data/processes/<process>/variables.json`**:

```jsonc
{
  "process": "...",
  "process_summary": "...",
  // process-level view: the variables that matter most, ranked
  "top_variables": [
    {
      "rank": 1,
      "business_name": "ISO 8583 Message Area",
      "process_importance": 100,        // 0-100, relative to the most important
      "packing": "rich",                // rich | moderate | atomic
      "packing_score": 100,             // 0-100, how much it carries & drives
      "classification": ["input"],
      "components": ["Account Number", "Expiration Date", "Track Data", "..."],
      "decision_count": 7,
      "fan_in": 6,
      "why_important": "Carries the whole incoming transaction the entire process reasons over."
    }
  ],
  "by_class":   { "input": [...], "output": [...], "key_business": [...] },
  "by_packing": { "rich": [...], "moderate": [...], "atomic": [...] },
  "variables": [
    {
      "var_id": "card_security_code",
      "business_name": "Card Security Code",
      "raw_identifiers": ["cscVal", "PA_CSC"],
      "classification": ["input", "key_business"],
      "io_direction": "read",
      "what_happens": "Validated against the HSM value to drive the auth decision.",
      "importance": "high",
      "read_files": ["..."], "write_files": [],
      "fan_in": 4,
      // how much it packs + how much it matters to the whole process
      "components": [], "component_count": 0,
      "decision_count": 3,
      "packing": "moderate", "packing_score": 41,
      "process_importance": 78, "importance_rank": 6,
      "why_important": "The security code the whole authentication decision hinges on.",
      "evidence": [{ "file": "...", "functions": ["..."], "io": "read" }]
    }
  ]
}
```

`variables` is ordered by `importance_rank`. `top_variables` (top 25) is the
quick answer to *"what are the variables of this process and which matter most."*

---

## How to run it

```
# 1. Build the hier walk substrate (relevance gate trims off-process files)
POST /demo/v1/projects/default/processes/<p>/hierwalk/build

# 2a. Build the variable map directly …
POST /demo/v1/projects/default/processes/<p>/hierwalk/variables/build
GET  /demo/v1/projects/default/processes/<p>/hierwalk/variables?class=output

# 2b. … or as part of the batch run (one shot):
POST /demo/v1/projects/default/processes/<p>/hierwalk/batch?variables=true
```

Batch flags: `relevance=llm|deterministic|off` (or `full=true`) toggles the
util‑stop; `variables=true` also produces the variable map + `variables.json`.

---

## Design choices (and why)

- **On‑demand from source, not a precomputed DB** — the source is the ground
  truth and the only signal the thin blueprints carry; keeps the map fresh.
- **Two passes** — input vs output is undecidable from one clubbed activity;
  it needs the cross‑file picture.
- **Deterministic anchor + LLM judgement** — the LLM supplies meaning and
  salience; the source‑substring anchor guarantees no invented variables.
- **Rides the relevance gate** — only in‑process files are scanned, so the map
  stays focused and the cost stays bounded.
