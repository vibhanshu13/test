# Variable Chat Feature

## Overview

The chat feature lets a user ask free-form follow-up questions about a variable's lineage after (or during) the explain-variable walk. Each answer is grounded in the context already assembled by the explanation layer — the unified synthesis, tuple facts, and LLM-generated explanations — so the LLM never needs to re-interpret raw source code from scratch.

The key design principle is **grounded, stateful Q&A**: every reply draws from the accumulated explanation context for the variable (not raw ASM/C++ files), and the full conversation history is included in every prompt so the LLM can handle multi-turn follow-ups naturally.

The chatbot is designed for **ASM/mainframe engineers**: answers cite instruction mnemonics, operands, line numbers, routine names, and branch conditions when the question calls for it, and switch to business-level language when asked a high-level question.

---

## Prerequisites

The chat feature builds on the explain-variable feature:

1. **Blueprint pipeline** — parses every ASM / C++ source file into a structured JSON blueprint and builds a `file_call_graph.json`.
2. **Chunked backward-lineage session** — traces a variable backward, assembling one tuple per `(file, phase)` step.
3. **Explain session** (optional but strongly recommended) — at least one tuple explanation must be generated via `POST /{kb_id}/explain-variable` or `explain_cli.py`. Without it, the chatbot can still answer but context is limited to compact one-line facts.

A `ChunkedBackwardSession` must exist before a chat session can be created. An explain session is loaded automatically if one exists for the same `backward_session_id`.

---

## Components

| File | Role |
|------|------|
| `llm/variable_chat.py` | Core: session persistence, context assembly, prompt building, LLM call |
| `llm/caller.py` | Thin Gemini API wrapper (shared with the explainer) |
| `api/schemas/variable_chat.py` | Pydantic request/response models for the two HTTP endpoints |
| `api/routes/knowledge_base.py` (lines 2044–2153) | Route handlers (`chat_start`, `chat_message`) |
| `chat_cli.py` | Dev CLI: interactive REPL or one-shot Q&A without starting the API server |
| `explain_cli.py` | Also saves `explain_session.json` to the output dir after each tuple, which `chat_cli.py` auto-detects |

---

## Data Flow

```
POST /{kb_id}/chat   { backward_session_id }
        │
        ├─ _backward_session_meta()     load root_variable, selected_chain
        ├─ create_chat_session()        create chat session on disk
        └─ response → { chat_session_id, root_variable }

        │
        │  (user types a question)
        ▼

POST /{kb_id}/chat/{chat_session_id}/message   { message }
        │
        ├─ load_chat_session()          load messages history
        ├─ _backward_session_meta()     load selected_chain
        ├─ load_explain_session()       load tuple_facts + explanations
        ├─ _assemble_context()          build grounding context block
        ├─ _build_chat_prompt()         context + history + question
        ├─ call_llm()                   Gemini API call → reply text
        ├─ append turn to session       persist user + assistant messages
        └─ response → { reply, turn_index, … }

        │
        └─ repeat for each follow-up question
```

---

## Context Strategy

Each LLM call receives four blocks in the grounding context, followed by conversation history and the current question:

```
VARIABLE: LG1OSI
LINEAGE CHAIN (entry point → setter): lu82 → dx750000 → … → da78

UNIFIED SYNTHESIS (top-level end-to-end explanation):
LG1OSI is a 1-byte online source indicator that records whether the C400 transaction
arrived via an online or batch path. It is set by a single MVI instruction at line …

STEP-BY-STEP FACTS (one line per file in the lineage):
  • Step 0: da78: LG1OSI set via MVI at line 1234, conditions checked: WK_RRC, WK_ID
  • Step 1: dx750000: upstream caller → calls da78
  …

EXPLANATIONS GENERATED SO FAR:
[Step 0]
In routine DA7_8000, LG1OSI is set via MVI …

[Step 1]
The lu82 routing block …

---

CONVERSATION HISTORY:
User: What triggers LG1OSI to be set?
Assistant: LG1OSI is set in da78 when …

---

CURRENT QUESTION:
Why does the upstream caller matter here?
```

**Context ordering rationale:**
1. **Synthesis first** — highest-signal block; the LLM sees the full end-to-end narrative before any detail
2. **Step-by-step facts** — structural skeleton; always included even for tuples not yet explained (negligible tokens)
3. **Per-step explanations** — full narrative detail; included verbatim, no truncation (Gemini 2.5 Pro ~1 M token context)
4. **Conversation history** — all prior turns, no window; enables natural multi-turn follow-up

If no explain session exists, the synthesis and explanations blocks are omitted and only the variable header and chain are shown with a note.

---

## Future: Vector DB Upgrade

The current context assembly (`_assemble_context()` in `llm/variable_chat.py`) is **in-memory and non-selective** — it always includes all tuple facts and all explanations. This works well for typical sessions (10–20 tuples, ~3 000 tokens of context) but will not scale to large sessions or cross-variable search.

The `_assemble_context()` function has a `# TODO(vector-db)` comment with the full upgrade spec:

**What to store per tuple (as separate vectors):**

| Artifact | `artifact_type` value | Notes |
|----------|----------------------|-------|
| LLM explanation | `"explanation"` | Plain English, best semantic signal |
| `tuple.summary` | `"summary"` | Pre-analysis one-liner from traversal engine |
| `tuple_facts` one-liner | `"fact"` | Compact structured fact |
| `relevant_code_lines` | `"code_lines"` | Code-level detail |
| Setter sites | `"setter_sites"` | Modifier tuples only |
| `cross_file_calls_out` | `"cross_file_calls"` | Call-graph edges |

**Metadata attached to every vector:**
```python
{
    "kb_id":               str,
    "backward_session_id": str,
    "root_variable":       str,   # always uppercase
    "file_stem":           str,
    "phase":               str,   # modifier / upstream / …
    "tuple_index":         int,
    "artifact_type":       str,
}
```

**Retrieval pattern:** query with the user's message as the search vector, filter by `{kb_id, backward_session_id}`, retrieve top-K chunks. `_assemble_context()` becomes a thin wrapper around the retrieval client — no other code changes needed.

---

## `llm/variable_chat.py` — Core Module

### Chat session model

A **chat session** is a msgpack file stored at:

```
{JOBS_BASE_DIR}/{kb_id}/output/chat_sessions/{chat_session_id}.msgpack
```

Schema:

```python
{
    "version": 1,
    "chat_session_id": str,          # UUID v4
    "backward_session_id": str,      # link to the backward-lineage session
    "root_variable": str,            # always uppercased (e.g. "LG1OSI")
    "messages": [
        {
            "role":      "user" | "assistant",
            "content":   str,
            "timestamp": ISO-8601 string,
        },
        …
    ],
    "created_at": ISO-8601 string,
}
```

The session is created by `POST /{kb_id}/chat`. Each call to `/message` appends exactly two entries to `messages` (user turn then assistant turn) and re-saves the session. There is no size cap on `messages` — the full history is always retained.

### `_assemble_context(root_variable, selected_chain, explain_session)` — context builder

Reads the explain session dict (already loaded from disk by the route handler) and formats up to four sections in priority order:

1. **UNIFIED SYNTHESIS** — the top-level end-to-end narrative from `explain_session["synthesis"]`. Included first as the highest-signal block. Only rendered if the synthesis field is present (i.e. all tuples have been explained).
2. **STEP-BY-STEP FACTS** — iterates `explain_session["tuple_facts"]` in index order. Always included even if no explanations exist yet.
3. **EXPLANATIONS GENERATED SO FAR** — iterates `explain_session["explanations"]` in index order. Only rendered if at least one explanation exists.

If `explain_session` is `None` (no explain session on disk), only the variable header and chain are included, with a note that no explanations are available.

### `_build_chat_prompt(question, messages, context)` — prompt builder

Joins three sections with `---` separators:
1. Context block (from `_assemble_context`)
2. Conversation history (all prior turns from `messages`, formatted as `User: …` / `Assistant: …`)
3. Current question

### System prompt

The LLM is positioned as a grounded Q&A assistant for **ASM/mainframe engineers**. Key behaviours:
- **Adaptive technical depth**: when asked about implementation, cite specific instruction mnemonics (`OI`, `MVC`, `CLC`, `TM`, etc.), operands, constants, line numbers, routine names, and branch conditions; when asked about business purpose or high-level flow, stay at that level
- Prefer 3–6 sentences; expand for multi-part questions or when a structured list is clearly better
- Ground every answer in the provided context; say explicitly if the answer isn't there rather than guessing or fabricating instructions

**Prior system prompt (removed)**: The original system prompt positioned the LLM for "business analysts" and explicitly forbade mnemonics. This was the opposite of what ASM engineers need — it was causing watered-down answers even when rich technical context was available. The rewrite was validated against four variables with both implementation-level and business-level questions.

### `answer_question(kb_id, session, question, explain_session, selected_chain)` — main entry point

1. Reads `session["messages"]` for conversation history
2. Calls `_assemble_context()` then `_build_chat_prompt()`
3. Calls `call_llm(prompt, system_prompt=_SYSTEM_PROMPT)`
4. Appends `{role: "user", …}` and `{role: "assistant", …}` to `session["messages"]`
5. Saves the updated session to disk
6. Returns the reply text

---

## API Endpoints

Both endpoints require a valid KB (status `"success"`) and an authenticated user.

### `POST /{kb_id}/chat`

**Purpose**: Create a new chat session linked to an existing backward-lineage session.

**Request body** (`ChatStartRequest`):

```json
{
  "backward_session_id": "abc-123"
}
```

**Guards**:
- KB must exist and be in `"success"` state
- `backward_session_id` must map to an existing `ChunkedBackwardSession`

**Response** (`ChatStartResponse`):

```json
{
  "chat_session_id": "f3a8b2c1-…",
  "backward_session_id": "abc-123",
  "root_variable": "LG1OSI"
}
```

Pass `chat_session_id` to every subsequent `/message` call. The explain session does not need to exist at this point — it is loaded on each message call.

### `POST /{kb_id}/chat/{chat_session_id}/message`

**Purpose**: Send a question and receive a grounded reply.

**Request body** (`ChatMessageRequest`):

```json
{
  "message": "Why does the upstream caller matter for LG1OSI?"
}
```

**What happens internally**:
1. Loads the chat session from disk
2. Loads backward session metadata (chain, root variable)
3. Loads the explain session if it exists (no error if it doesn't)
4. Assembles context and prompt
5. Calls the LLM
6. Persists the new turn
7. Returns the reply

**Response** (`ChatReplyResponse`):

```json
{
  "chat_session_id": "f3a8b2c1-…",
  "root_variable": "LG1OSI",
  "reply": "The upstream caller dx750000 acts as the transaction routing hub …",
  "turn_index": 1
}
```

`turn_index` is 0-based and reflects the number of user messages sent so far (including this one). Safe to call multiple times — each call appends to history and the LLM sees all prior turns.

---

## Schemas (`api/schemas/variable_chat.py`)

### `ChatStartRequest`
| Field | Type | Description |
|-------|------|-------------|
| `backward_session_id` | str (min 1) | Session ID from a prior `/backward-lineage/chunks` call |

### `ChatStartResponse`
| Field | Type | Description |
|-------|------|-------------|
| `chat_session_id` | str | Pass to every `/message` call |
| `backward_session_id` | str | Echoed back for reference |
| `root_variable` | str | Root variable (e.g. `"LG1OSI"`) |

### `ChatMessageRequest`
| Field | Type | Description |
|-------|------|-------------|
| `message` | str (min 1) | User's question or follow-up |

### `ChatReplyResponse`
| Field | Type | Description |
|-------|------|-------------|
| `chat_session_id` | str | Same session ID |
| `root_variable` | str | Root variable |
| `reply` | str | LLM-generated answer |
| `turn_index` | int | 0-based count of user messages sent so far |

---

## Dev CLI Tools

### Full two-step local test

```bash
# Step 1 — generate backward chunks
python backward_traversal/chunk_cli.py LG1OSI \
    --chain-files lu82,dx750000,dx710000,dx730000,dx740200,da78 \
    --blueprint-dir output/asm \
    --asm-dir temp/asm \
    --graph output/file_call_graph.json \
    --output-dir /tmp/lg1osi_chunks

# Step 2 — explain N tuples (saves explain_session.json to /tmp/lg1osi_chunks)
GEMINI_API_KEY=your_key python explain_cli.py /tmp/lg1osi_chunks --max-tuples 2

# Step 3 — interactive chat grounded in those 2 explanations
GEMINI_API_KEY=your_key python chat_cli.py /tmp/lg1osi_chunks

# Step 3 (alternative) — one-shot question
GEMINI_API_KEY=your_key python chat_cli.py /tmp/lg1osi_chunks \
    --question "What business event triggers LG1OSI to be set?"

# Step 3 (dry-run) — inspect assembled context without calling LLM
python chat_cli.py /tmp/lg1osi_chunks \
    --question "What business event triggers LG1OSI?" --dry-run
```

### `explain_session.json` handoff

`explain_cli.py` writes `explain_session.json` to the output directory **after every tuple** (not just at the end). This means:
- After `--max-tuples 2`: the file exists with 2 explanations and 2 tuple facts
- If `explain_cli.py` is interrupted mid-run: all tuples completed so far are available to `chat_cli.py`
- Re-running `explain_cli.py` with a higher `--max-tuples` overwrites the file with the richer session

File format (plain JSON for easy inspection):

```json
{
  "root_variable": "LG1OSI",
  "selected_chain": ["lu82", "dx750000", "dx710000", "dx730000", "dx740200", "da78"],
  "tuple_facts": {
    "0": "da78: LG1OSI set via MVI at line 1234, conditions checked: WK_RRC, WK_ID",
    "1": "dx750000: upstream caller → calls da78"
  },
  "explanations": {
    "0": "In routine DA7_8000, da78 sets the online source indicator …",
    "1": "The dx750000 module acts as the transaction routing hub …"
  },
  "synthesis": "LG1OSI is a 1-byte online source indicator … (10–15 sentences, written after all tuples explained)"
}
```

The `synthesis` field is present only when `explain_cli.py` (or the API) has completed all tuples and run the synthesis pass. The chatbot automatically uses it as the top context block when available — the richer the explain session, the better the chat answers.

### `chat_cli.py` context detection

On startup, `chat_cli.py` looks for `explain_session.json` in the output directory:

- **Found** → loads tuple_facts + explanations from the file; prints `Context: explain_session.json (N explanation(s) loaded)`
- **Not found** → derives tuple_facts in-memory from raw chunk metadata using `_extract_tuple_fact()` (no LLM calls); prints `Context: tuple-facts only (run explain_cli.py for richer context)`

In both cases the chatbot is fully functional. The difference is richness: with a saved explain session the LLM has full narrative context; with tuple-facts only it has compact one-liners.

The CLI does **not** persist the conversation history to disk — each `chat_cli.py` invocation starts fresh. To persist history, use the API endpoints.

---

## Chatbot Validation

Validated against four variables (`LG1OSI`, `WK_RRC`, `WK_TIME`, `WB1RCNBR`) using `chat_cli.py` after full explain sessions. Four question types were tested per variable:

| Question type | Example | Expected behaviour | Result |
|--------------|---------|-------------------|--------|
| Implementation detail | "What instruction sets WK_TIME?" | Cites `MVC WK_TIME+0(2),EBW000` at line 686, routine `DA7_8000` | ✓ Technical answer with mnemonics and line numbers |
| Precondition chain | "What gates must pass before WK_TIME is set?" | Lists `TM LBWTN,X'01'`, `LTR R0,R0`, `CLC WK_RRC,ZEROS`, `OC L3TFCH,L3TFCH` with branch names | ✓ All gates enumerated with line numbers |
| Business-level | "What business event does WK_TIME record?" | Explains timestamp at point of account synchronisation | ✓ No spurious mnemonics; business language |
| Cross-step | "How does lu82's routing decision affect WK_TIME?" | Links `ENTDC DE82` → da76 path → setter | ✓ Synthesis used as anchor; multi-step reasoning |

**Key fix confirmed**: answers now include mnemonics and line numbers for implementation questions (previously suppressed by the "business analyst" system prompt).

---

## Caching Behaviour

- **Chat session turns** are persisted to disk after every message. If the server restarts between turns, the history is fully recovered on the next `/message` call.
- **Explain session context** is loaded fresh on every `/message` call. If more tuples are explained between two chat messages, the next message automatically uses the richer context — no session refresh needed.
- There is no per-reply cache. The same question asked twice will produce two LLM calls (and potentially two different but semantically similar answers). This is intentional — the conversation history differs between the two calls.

---

## Error Cases

| Condition | HTTP status | Detail |
|-----------|-------------|--------|
| KB not found or wrong owner | 404 | — |
| KB not in `"success"` state | 409 | `KB '{kb_id}' is not ready (status: …)` |
| `backward_session_id` not found (on POST /chat) | 404 | `Backward-lineage session '…' not found` |
| `chat_session_id` not found (on /message) | 404 | `Chat session '…' not found` |
| `backward_session_id` missing from chat session's linked backward session | 404 | `Backward-lineage session '…' not found` |
| LLM content safety block | 500 | `LLM returned an empty response` |
