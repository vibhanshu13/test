# CPP-to-ASM Call Chain Traversal Patterns

This document describes all the different CPP to ASM function calling
patterns handled by the `/cpp-call-chain` API endpoint, covering both
**forward** (callees) and **backward** (callers) BFS traversal directions.

Reference implementation: `cpp_call_chain/traversal.py`

---

## Table of Contents

1. [Forward Traversal Patterns](#1-forward-traversal-patterns)
2. [Backward Traversal Patterns](#2-backward-traversal-patterns)
3. [Concrete Calling Patterns in the Codebase](#3-concrete-calling-patterns-in-the-codebase)
4. [IBM / z/TPF Conventions](#4-ibm--ztpf-conventions)
5. [Cross-Language Index Internals](#5-cross-language-index-internals)
6. [Summary Table](#6-summary-table)
7. [Configuration Parameters](#7-configuration-parameters)

---

## 1. Forward Traversal Patterns

Forward traversal answers: **"What ASM routines does this CPP function call?"**

### 1.1 Cross-Language Index Forward Lookup (Primary Mechanism)

The cross-language index is the primary way CPP→ASM boundary crossings
are discovered. It is built from `file_call_graph.json` and captures
edges where `src_type != tgt_type`.

- **Source:** `cross_lang.forward[(fstem, method)]` — keyed by the CPP
  function's file stem and method name
- **Code:** `traversal.py:615-637`
- **How it works:**
  1. After processing the CPP node's own blueprint edges, the traversal
     checks `_cl_forward.get((fstem, method), [])`.
  2. Each entry contains the ASM target's `stem`, `method`, `file_type`,
     `call_type`, `instruction`, and `line`.
  3. The ASM target is enqueued with its file stem so the next BFS
     iteration loads the ASM blueprint.
- **Data built by:** `index_builder.py:526-778` (`build_cross_lang_index`)
- **Filter:** Only cross-language edges pass — `index_builder.py:632`:
  `if src_type == tgt_type: continue`

```python
# traversal.py:615-637 — Cross-language callees
if fstem:
    for cl in _cl_forward.get((fstem, method), []):
        if cl.get("file_type") not in ("asm", "mac", "cpp"):
            continue
        vk = (cl["method"], cl["stem"] or "")
        if vk not in visited:
            queue.append((
                cl["method"], cl["stem"], depth + 1,
                method, fstem,
                {"call_type": cl["call_type"],
                 "instruction": cl["instruction"],
                 "line": cl["line"], "file_path": ""},
            ))
```

### 1.2 CPP Blueprint Edge to External ASM Target

A CPP blueprint (`*.cpp.json`) may contain call_graph edges where the
target node has `is_external: true` and its `file` field points to an
ASM module. These edges are generated when the CPP call graph builder
detects a call to an extern function with an ASM-style name.

- **Source:** CPP blueprint `call_graph.edges` where `edge.source == method`
  and the target node has `is_external: true`
- **Code:** `traversal.py:549-613` (language-agnostic edge loop)
- **How it works:** The target node's `file` path is extracted; if it
  resolves to an ASM file, language detection on the next BFS iteration
  classifies it as ASM and loads the ASM blueprint.
- **Edge properties:** `call_type="subroutine_call"`,
  `instruction="CALL_ALIAS"` for resolved `asm()` / `#pragma map` calls;
  `call_type="call"`, `instruction="CALL"` for unresolved generic calls;
  `instruction="CALLCPP"` for CALLCPP macro bridges.
- **CALL_ALIAS detail:** When the C family analyzer detects an `asm()`
  specifier or `#pragma map` directive, it records a `symbol_aliases`
  mapping (e.g., `{"initCCR": "AI71"}`) in the CPP blueprint. Calls
  through these aliases emit `CALL_ALIAS` edges instead of plain `CALL`
  edges. In `file_call_graph.py`, `CALL_ALIAS` is in the
  `CPP_ALWAYS_CROSS` set, meaning these edges are unconditionally
  included in the file-level call graph regardless of module-boundary
  heuristics. This is the mechanism by which patterns 3.1 and 3.2
  become traversable cross-language edges.

### 1.3 CALLCPP / CALLC Bridge Macro Edges

When an ASM file uses the `CALLCPP` macro to call a CPP function, the
call graph builder generates an edge with `CallType.CALL` and
`instruction="CALLCPP"`. This is the ASM→CPP direction, but it creates
nodes visible during CPP→ASM backward traversal.

- **Code (edge creation):** `call_graph_builder.py:816-829`
- **Target extraction:** `call_graph_builder.py:388-404`
  (`_extract_callcpp_target`) — parses operands for `ENTRY=`, `TARGET=`,
  `FUNC=`, `FUNCTION=`, `NAME=`, `SEG=`, `SEGMENT=` keywords
- **Edge:** `CallType.CALL`, `instruction="CALLCPP"`, target marked
  `is_external=true`
- **CALLC:** Recognized in `variable_lineage_builder.py:59` as a known
  opcode for lineage tracking. CPROC-based parameter typing is an
  IBM-documented pattern but is not yet implemented in the builder

### 1.4 CPP Source Fallback Scanning

When no CPP blueprint exists for a file, the source scanner provides a
regex-based fallback to discover callees.

- **Source:** `source_scanner.py:366-427` (`scan_callees_in_function`)
- **Code:** `traversal.py:517-544`
- **How it works:** Uses brace-counting to isolate the function body,
  then applies regex `\b([A-Za-z_][A-Za-z0-9_:~]*)\s*\(` to find call
  tokens.
- **Limitation:** Cannot distinguish CPP→ASM calls from CPP→CPP calls
  by source alone. The cross-language index (pattern 1.1) is needed to
  identify which callees are ASM routines.
- **When used:** Only when blueprint loading fails for the CPP file
  (`traversal.py:517-544`).

### 1.5 ASM Node Metadata Resolution (Post-Crossing)

Once an ASM target is enqueued from a CPP caller, the traversal must
resolve the ASM node's metadata. Since ASM routines are not in the
CPP-only definitions index, a fallback loads metadata directly from the
ASM blueprint.

- **Source:** ASM blueprint `call_graph.nodes[method]`
- **Code:** `traversal.py:165-189` (`_resolve_node_from_blueprint`)
- **When used:** `traversal.py:434-435` — for any node where
  `language != "cpp"` and the definitions index has no entry.
- **Returns:** `{file_path, definition_line, is_external, kind}`

### 1.6 Language Detection at Boundary

When a node is dequeued during BFS, the traversal determines its language
using a priority cascade:

- **Code:** `traversal.py:427-429`
- **Priority:**
  1. Cross-lang boundary map (`_cl_file_types`) — most specific
  2. Full index file_types (`_idx_file_types`) — from all blueprints
  3. Default to `"cpp"` — if neither source has the file_stem
- **Impact:** This determines whether blueprint loading tries `.cpp.json`
  or `.asm.json`, and whether ASM-specific fallbacks apply.

```python
language: str = (
    _cl_file_types.get(fstem) or _idx_file_types.get(fstem) or "cpp"
) if fstem else "cpp"
```

### 1.7 No CHA Expansion for ASM Targets

Virtual dispatch expansion (`expand_virtual_dispatch`) only applies to
methods with `::` in the name. ASM routines use flat 4-6 character names
and are never subject to Class Hierarchy Analysis.

- **Code:** `traversal.py:265-316` (`_apply_cha_expansion`)
- **Guard:** Only runs when method name contains `"::"` — ASM names
  like `DA78`, `NB81` never match.

---

## 2. Backward Traversal Patterns

Backward traversal answers: **"Which CPP functions call this ASM routine?"**

### 2.1 Cross-Language Index Backward Lookup (Primary)

The backward map of the cross-language index provides direct O(1) lookup
of CPP callers for any ASM routine.

- **Source:** `cross_lang.backward[(fstem, method)]` — keyed by the ASM
  routine's file stem and name
- **Code:** `traversal.py:855-881`
- **How it works:** Each entry in the backward map contains a CPP caller
  with `file_type: "cpp"`, its stem, method name, and call metadata.
- **When used:** After same-language callers are collected (patterns
  2.2 and 2.3), cross-language callers are added from this map.

```python
# traversal.py:855-881 — Cross-language callers
if fstem:
    for cl in _cl_backward.get((fstem, method), []):
        if cl.get("file_type") not in ("asm", "mac", "cpp"):
            continue
        caller_func = cl["method"]
        caller_fstem = cl["stem"]
        if not include_external and _is_stdlib(caller_func):
            continue
        vk = (caller_func, caller_fstem or "")
        if vk not in visited:
            queue.append((
                caller_func, caller_fstem, depth + 1,
                method, fstem,
                {"call_type": cl["call_type"],
                 "instruction": cl["instruction"],
                 "call_line": cl["line"], "file_path": ""},
            ))
```

### 2.2 Pre-Built Callers Index Lookup

The callers index is built from ALL blueprints (CPP, ASM, MAC) and may
contain CPP→ASM caller entries if the CPP blueprint captured the edge.

- **Source:** `index.callers[method_name]`
- **Code:** `traversal.py:757`
- **Code (index builder):** `index_builder.py:183-206` — caller entries
  extracted from every edge in every blueprint
- **How it works:** If a CPP blueprint contains an edge to an ASM target
  (e.g., via extern call), that caller entry appears in the callers
  index. The backward traversal finds it at O(1).

### 2.3 ASM Blueprint Edge Inversion (Intra-ASM Only)

For ASM nodes, backward traversal loads the ASM blueprint and inverts
edges to find callers where `edge.target == method`.

- **Code:** `traversal.py:759-780`
- **Guard:** Only runs when `language in ("asm", "mac")`
- **Scope:** This finds intra-file ASM callers, NOT CPP callers. CPP
  callers come from patterns 2.1 and 2.2.

### 2.4 CPP Source Fallback (Backward, Depth-0 Only)

When a CPP function has no callers in the index, the source scanner
greps all source files under `source_path` for calls to the function.

- **Code:** `traversal.py:782-809`
- **Guard:** `language == "cpp"` — only applies to CPP starting nodes
- **Scanner:** `source_scanner.py:434-509` (`scan_callers_in_source`)
- **Limitation:** Not applicable when starting from an ASM node; the
  ASM→CPP direction relies on the cross-language backward index.

### 2.5 No Source Fallback for ASM Backward

ASM nodes have no source fallback for backward traversal. The CPP source
fallback (`traversal.py:782-809`) only applies when `language == "cpp"`.
When backward-traversing an ASM node, only the callers index (pattern 2.2)
and blueprint edge inversion (pattern 2.3) are used. If the ASM blueprint
is also missing, a warning is emitted during forward traversal
(`traversal.py:540-544`) but no equivalent exists for backward.

### 2.6 Backward CHA Expansion

When backward-traversing a derived-class method, backward CHA expansion enqueues the corresponding base-class methods so callers dispatching via virtual pointer are also discovered.

- **Code:** `traversal.py:318-370` (`_apply_cha_expansion_backward`)
- **Traversal call site:** `traversal.py:840-853`
- **Controlled by:** `expand_virtual_dispatch` parameter

---

## 3. Concrete Calling Patterns in the Codebase

### 3.1 `extern "C"` with `asm()` Specifier (Most Common)

The dominant CPP→ASM calling pattern. Functions are declared with
explicit ASM routine names using the `asm()` specifier, then called
using the C++ wrapper name.

```cpp
// Source: dx740200.cpp:29-48
extern "C" void initCCR(TPF_regs*) asm ("AI71");
extern "C" void initializeBcis(TPF_regs*) asm ("AC71");
extern "C" void setAuthRelayBcis(TPF_regs*) asm ("AC76");
extern "C" void convertMessageFormat(TPF_regs* regs) asm ("DB73");
extern "C" void buildLg1g1(TPF_regs* regs) asm ("DA78");
extern "C" void incrementCounters(TPF_regs* regs) asm ("NB81");
extern "C" void getLg1g1Type16(TPF_regs* regs) asm ("AU70");
extern "C" void getLg1g1Type26(TPF_regs* regs) asm ("DA77");
extern "C" void logLi1i1(TPF_regs* regs) asm ("SX01");
extern "C" void getTdr(TPF_regs* regs) asm ("PB3A");
extern "C" void editHubglHeaderInfo(TPF_regs* regs) asm ("DB71");
extern "C" void checkMessageMonitor(TPF_regs*) asm ("DE70");
extern "C" void processNegative(TPF_regs*) asm ("GA71");
extern "C" void callCoreCarver(TPF_regs* registers) asm ("SR70");
extern "C" void callAccountManager(TPF_regs* registers) asm ("SL70");
```

**Calling convention:**
```cpp
// Source: dx740200.cpp:145
buildLg1g1(&regs);  // Compiler resolves to ASM symbol DA78
```

**Files using this pattern:**
- `dx740200.cpp` — 15+ declarations (AI71, AC71, AC76, DB73, DA78, NB81, etc.)
- `dx730000.cpp` — 4 declarations (DC78, DE70, AL22, DC10)
- `rh73Iw00.cpp` — 3 declarations (PB31, TE90, AV01)

### 3.2 `#pragma map()` Directive (Platform-Specific)

Used for z/TPF (`__370__`) builds. Maps a C++ function name to an ASM
routine name at compile time.

```cpp
// Source: rh73Iw00.cpp:42-62
#ifdef __370__
#pragma map(unpackData,"UNPACK")
#pragma map(buildIsoAreaFields,"RH73")
#pragma map(getTms, "PB31")
#pragma map(ckXc, "TE90")
#pragma map(callAV01, "AV01")
#endif
```

```cpp
// Source: dx710000.cpp:25-26
#pragma map(callLogCasARecord,"FA71")
#pragma map(initCCR, "AI71")
```

```cpp
// Source: dw710500.cpp:468
#pragma map(callAccountManager,"SL70")
```

```cpp
// Source: dp710100.cpp:47
#pragma map(unpackData,"UNPACK")
```

**Files using this pattern:**
- `rh73Iw00.cpp`, `dx710000.cpp`, `dw710500.cpp`, `dp710100.cpp`

### 3.3 Direct `extern "C"` with ASM-Style Names

Functions declared directly using the ASM routine's 4-character name,
without `asm()` specifier or pragma. Linkage relies on the name itself.

```cpp
// Source: cf500000.cpp:18-20
extern "C" void CF55(TPF_regs* regs);
extern "C" void NB81(TPF_regs* regs);
extern "C" void TE89(TPF_regs* regs);
```

```cpp
// Source: av200100.cpp:25-27
extern "C" void NB81(TPF_regs*);
extern "C" void callAavManager(TPF_regs* registers);
extern "C" void ZCM1(TPF_regs*);
```

```cpp
// Source: dw712100.cpp:20-22
extern "C" void AO71(TPF_regs* regs);
extern "C" void AH71(TPF_regs* regs);
extern "C" void CF55(TPF_regs* regs);
```

```cpp
// Source: cf580100.cpp:4-5
extern "C" void AO71(TPF_regs* regs);     //Scramble utility
extern "C" void CF55(TPF_regs* regs);     //KEYLT & CSCPI processes
```

**Calling convention:**
```cpp
// Source: cf500000.cpp:81
TE89(&regs);
// Source: cf500000.cpp:329
CF55(&regs);
// Source: av200100.cpp:291
ZCM1(0);
// Source: dw712100.cpp:1429
AO71(&registers);
```

**Files using this pattern:**
- `cf500000.cpp`, `av200100.cpp`, `dw712100.cpp`, `cf580100.cpp`

### 3.4 Register Setup + ASM Call (TPF_regs Convention)

All CPP→ASM calls pass a `TPF_regs*` pointer. The calling code
explicitly sets up register fields (r0-r9) before calling the ASM
routine, and reads return values from register fields after the call.

```cpp
// Source: dx740200.cpp:99-100 — Single register setup
TPF_regs regs;
regs.r7 = (int)ecbptr()->ce1cr7;
convertMessageFormat(&regs);  // → DB73
```

```cpp
// Source: dx740200.cpp:140-145 — Multi-register setup
regs.r3 = (int) ecbptr()->ce1cr4;
regs.r4 = (int) ecbptr()->ce1cr6;
regs.r7 = (int) ecbptr()->ce1cr7;
regs.r6 = (int) ecbptr()->ce1cr8;
regs.r5 = (int) ecbptr()->ce1cr9;
buildLg1g1(&regs);  // → DA78
```

```cpp
// Source: cf500000.cpp:78-82 — Register setup with return value check
TPF_regs regs;
regs.r0 = (long) (retrieveAevvInputInfo->cardNbr);
regs.r1 = (long) &lvyvy;
TE89(&regs);
if (regs.r0 != 0)  // Check return value in R0
```

```cpp
// Source: cf580100.cpp:103-105 — Pointer in R1
TPF_regs regs;
regs.r1 = (long) &l9x9x;
CF55(&regs);
```

```cpp
// Source: rh73Iw00.cpp:769-770
regs.r1 = (long) &l8u8u;
getTms(&regs);  // → PB31
```

```cpp
// Source: av200100.cpp:276-278 — Register + ECB field setup
registers.r1 = (long) "RF";
ecbptr()->ebxsw1 = GET_SPEC_ADDR;
callCoreCarver(&registers);  // → SR70
```

### 3.5 `#pragma export` (Making CPP Callable from ASM)

The reverse direction — CPP functions exported for ASM consumption.
These appear in the same files and create the ASM→CPP backward edges
visible during CPP→ASM backward traversal.

```cpp
// Source: cf580100.cpp:9-12
#ifdef __370__
#pragma export (scrambleHsm5csc)
#pragma export (callHsm)
#endif
```

```cpp
// Source: dp710100.cpp:24-36
#ifdef __370__
#pragma export(authAChargePipeline(LwrPipeTask task))
#pragma export(processInitialEntry(const CasVision1&,const CasVision3&))
#pragma export(processAccountManager(const CasVision1& casVision1))
#pragma export(processProductManager(const CasVision1& casVision1))
#pragma export(processInitialPayachVariables(const CasVision4& casVision4))
#pragma export(populateIsoAreaFields(const CasVision3& casVision3))
#pragma export(getLwrwrAddresses())
#pragma export(processCustomerManager(const CasVision4& casVision4))
#pragma export(processCorpManager())
#pragma export(processVariableDecommission())
#pragma export(processCardMemberVarManager())
#endif
```

### 3.6 Null-Pointer TPF_regs Convention

Some ASM calls pass `0` (null) instead of a `TPF_regs*`, when the ASM
routine reads its parameters from ECB fields rather than registers.

```cpp
// Source: dx740200.cpp:369
incrementCounters(0);  // → NB81, reads from ECB directly

// Source: av200100.cpp:291
ZCM1(0);

// Source: av200100.cpp:546
NB81(0);
```

---

## 4. IBM / z/TPF Conventions

### 4.1 CALLC Macro — Primary C→ASM Bridge

The IBM-documented mechanism for calling a C function from BAL
(assembler). On the CPP→ASM side, the C function prototype is defined
with CPROC, and BAL code calls it with CALLC.

- **Syntax:** `CALLC function_name(R2,R3,...)`
- **Requires:** Matching `CPROC` definition for parameter types
- **Return value:** R15 (non-floating) or F0 (floating-point)
- **Max parameters:** 12 per IBM documentation
- **Gotchas:**
  - R15 cannot be used as a CALLC input parameter register
  - Floating-point parameters must be binary floating-point
  - Structures cannot be return values (use pointers)
  - Parameter count must match CPROC definition

```asm
; IBM pattern: ASM calling C via CALLC
CPROC RETURN=i,validate_customer,(p,i)
LA    R2,CUSTREC
LHI   R3,80
CALLC validate_customer(R2,R3)
LTR   R15,R15          ; Check return value
BNZ   BAD_CUSTOMER
```

- **Source:** `temp/ibm/patterns/asm-c-interoperability.md`,
  `temp/ibm/macros/ztpf-system-macros.md`

### 4.2 CPROC — C Function Prototype Declaration

Declares a C function prototype for use with CALLC and ENTxC macros.
No runtime effect — metadata only.

- **Syntax:** `CPROC RETURN=type,function_name,(param_types...)`
- **Type indicators:** `i` (int), `p` (pointer), `f` (float),
  `d` (double), `v` (void)
- **Usage:** Must precede any CALLC invocation of the function
- **Modernization:** Use as symbol/type metadata for building typed
  cross-language call graph

- **Source:** `temp/ibm/macros/ztpf-system-macros.md`

### 4.3 UPROC — Prototype Bundle

Groups multiple CPROC statements. Search macro/library source for CPROC
bundle when UPROC is encountered.

- **Source:** `temp/ibm/patterns/asm-c-interoperability.md`

### 4.4 Register Conventions for CPP↔ASM Calls

| Register | Role | Convention | Source |
|----------|------|------------|--------|
| R1 | Parameter pointer | ENTRC-style parameter list | IBM docs |
| R2-R6 | CALLC input parameters | General-purpose parameter registers | IBM docs |
| R3 | z/TPFDF slot address | SW00SR for database context passing | IBM docs |
| R9 | ECB base | Must be preserved; many z/TPF macros require R9 → ECB | IBM docs |
| R14 | GETCC result / link | Receives assigned storage; also link register for BAS/BR | IBM docs |
| R15 | Return value | Non-floating return from CALLC and program calls; cannot be CALLC input | IBM docs |
| F0-F3 | Float parameters | Floating-point parameter registers for CALLC | IBM docs |
| F0 | Float return | Floating-point return value from CALLC | IBM docs |

### 4.5 PRLGC / EPLGC — C-Callable BAL Library Wrappers

Modern prolog/epilog macros for BAL (assembler) functions that are
callable from C/C++. These define the ASM-side entry/exit conventions
for CPP→ASM calls.

| Macro | Purpose | Status |
|-------|---------|--------|
| PRLGC | Modern prolog for C-callable BAL function | Preferred |
| EPLGC | Modern epilog for C-callable BAL function | Preferred |
| TMSPC | Legacy prolog (TPF 4.1) | Migration compatibility |
| TMSEC | Legacy epilog (TPF 4.1) | Migration compatibility |

- **Source:** `temp/ibm/migration-notes.md`,
  `temp/ibm/patterns/asm-c-interoperability.md`

### 4.6 ENTxC Macros from CPP Perspective

When C++ code calls an ASM routine, the ASM side receives control via
ENTxC macros. From the CPP caller's perspective:

| Macro | Behavior | CPP Caller Sees |
|-------|----------|-----------------|
| ENTRC | Enter with return expected | Function call returns normally |
| ENTNC | Enter with no return | Control does not return to CPP |
| ENTDC | Enter with drop | CPP program level dropped |

- **Modernization note:** When target is C/C++, check CPROC and
  pointer-width caveats; R1/CPROC parameter passing needs extraction.

### 4.7 z/TPF OS C Functions (C API Equivalents)

z/TPF provides C-callable wrappers for common ASM macros:

| C Function | ASM Equivalent | Purpose | Boundary | Builder Edge |
|-----------|----------------|---------|----------|-------------|
| `getcc` | GETCC | Allocate working storage | — | — |
| `relcc` | RELCC | Release working storage | — | — |
| `detac` | DETAC | Detach storage block | — | — |
| `attac` | ATTAC | Reattach storage block | — | — |
| `credc` | CREDC | Create deferred ECB entry | Independent ECB | async_spawn edge |
| `creec` | CREEC | Create ECB entry | Independent ECB | async_spawn edge |
| `cremc` | CREMC | Create memory ECB entry | Independent ECB | async_spawn edge |
| `cretc` | CRETC | Timer-initiated entry | Independent ECB | async_spawn edge (in builder at call_graph_builder.py:766) |
| `crexc` | CREXC | Low-priority deferred entry | Independent ECB | async_spawn edge (in builder at call_graph_builder.py:766) |
| `tpf_cresc` | CRESC | Synchronous entry (suspends caller) | Blocking boundary | sync_spawn edge (in builder at call_graph_builder.py:766) |
| `tpf_rcrfc` | RCRFC | Release core block and file address | — | — |
| — | CLINKC | C-linkage call to BAL function | Returns to caller | subroutine_call edge (in builder at call_graph_builder.py:766) |
| — | RLINKC | Return from C-callable BAL | Return boundary | return edge (in builder at call_graph_builder.py:835) |

- **Source:** `temp/ibm/functions/ztpf-os-c-functions.md`

### 4.8 TPF 4.1 Legacy Parameter Passing

Legacy parameter passing via CPROC is still supported for migration
compatibility.

- **Mechanism:** Parameters passed via traditional TPF 4.1 conventions
  using CPROC declaration
- **Risk:** Pointer values exceeding 31 bits in 64-bit mode
- **Modernization:** Prefer CALLC for modern z/TPF code when pointers
  exceed 31 bits
- **Source:** `temp/ibm/migration-notes.md`

### 4.9 Linkage Macros

IBM-documented program linkage macros for ASM/C interoperability:

| Macro | Purpose | Status |
|-------|---------|--------|
| CLINKC | Call linkage to C-callable BAL function | In builder (`subroutine_call`) |
| RLINKC | Return linkage from C-callable BAL function | In builder (`return`) |
| SLINKC | Save linkage for C-callable BAL function | Generic macro handler (`macro_invocation`) |

- **Source:** `temp/ibm/patterns/asm-c-interoperability.md`,
  `temp/ibm/todo.md`
- **Note:** Listed alongside ENTRC/ENTDC/ENTNC as signals to look for.

---

## 5. Cross-Language Index Internals

### 5.1 Data Source: file_call_graph.json

The cross-language index is built from `file_call_graph.json`, which
is generated during knowledge base construction. It contains file-level
nodes (with type: "cpp", "asm", "mac") and edges with call_site details.

### 5.2 Two-Pass Streaming Parse

**Pass 1: Node Type Collection** (`index_builder.py:606-613`)
```python
for node in ijson.items(fh, "nodes.item"):
    if isinstance(node, dict) and node.get("id"):
        file_types[node["id"]] = node.get("type", "unknown")
```
Builds map: `file_stem → "cpp" | "asm" | "mac" | "unknown"`

**Pass 2: Edge Filtering** (`index_builder.py:616-658`)
- Streams edges from `file_call_graph.json`
- Filters: `src_type != tgt_type` (cross-language only)
- For each `call_site` in the edge, builds both forward and backward
  index entries

### 5.3 Index Structure

```python
{
    "forward": {
        (src_stem, src_method): [
            {"stem": tgt_stem, "method": tgt_method,
             "call_type": "...", "instruction": "...",
             "line": N, "file_type": "asm"},
            ...
        ],
    },
    "backward": {
        (tgt_stem, tgt_method): [
            {"stem": src_stem, "method": src_method,
             "call_type": "...", "instruction": "...",
             "line": N, "file_type": "cpp"},
            ...
        ],
    },
    "file_types": {stem: "cpp" | "asm" | "mac"},
}
```

### 5.4 Disk Cache

- **Filename:** `cpp_cross_lang_index.msgpack.zst`
- **Key encoding:** Tuple keys serialized as `"stem\x00method"` strings
  for msgpack compatibility
- **Staleness:** Mtime-based detection (`index_builder.py:556-579`)

### 5.5 ASM Module Name Pattern

The file-level call graph identifies ASM modules using:
```python
# file_call_graph.py:93
ASM_MODULE_RE = re.compile(r"^[A-Z][A-Z0-9]{3,5}$")
```
Matches: DA78, XH72, NB81, DE70, AC71 (4-6 character uppercase codes)

### 5.6 Cross-File Call Opcodes

The file-level call graph includes ASM cross-file edges for the
following set of opcodes:

```python
# backward_traversal/glossary/instructions.py:84-85
CROSS_FILE_CALL_OPCODES = {"ENTRC", "ENTNC", "ENTDC", "CREEC", "CREMC", "CREDC", "CRETC", "CREXC", "CRESC",
                           "SWISC", "EXSR", "FUNCTION", "CALLC", "CALLCPP", "CLINKC"}
```

All cross-file call opcodes — including non-returning (ENTNC, ENTDC),
async (CREEC, CREMC, CREDC, CRETC, CREXC), synchronous spawn (CRESC),
typed C calls (CALLC), and C-linkage subroutine calls (CLINKC) — are
included in `file_call_graph.json` and consequently appear in the
cross-language index. Their semantic differences are captured by
`CallType` in `call_graph_builder.py` and by the separate
`NON_RETURNING_CALL_OPCODES` / `ASYNC_CALL_OPCODES` sets in
`instructions.py`. CRETC and CREXC are async spawns like CREEC/CREMC/CREDC.
CRESC is a synchronous spawn (`CallType.SYNC_SPAWN`). CLINKC is a
C-linkage subroutine call.

**EXSR** (Execute Subroutine) is a z/TPF cross-file subroutine call opcode. While it is primarily an ASM-to-ASM pattern, it may appear in call chains that started from CPP and crossed into ASM territory. Handled in `call_graph_builder.py:765` with `CallType.SUBROUTINE_CALL`.

### 5.7 MAC Blueprint Loading Limitation

The blueprint loader (`_load_cg` at `traversal.py:101-142`) tries three file extensions: `{fstem}.cpp.json`, `{fstem}.asm.json`, and `{fstem}.mac.json`. MAC files can now be loaded for forward traversal and blueprint edge inversion.

### 5.8 "Unknown" Language Default

When a file stem is not found in either `_cl_file_types` or
`_idx_file_types`, the language detection defaults to `"cpp"`:

```python
# traversal.py:427-429
language = _cl_file_types.get(fstem) or _idx_file_types.get(fstem) or "cpp"
```

This means if an ASM module is not present in any index, it will be
treated as CPP by default. In practice, all ASM modules in the codebase
are indexed, so this fallback rarely triggers.

### 5.9 CPP Stdlib Noise Filter

The file-level call graph generator silently drops calls to a curated
set of C stdlib and z/TPF platform API functions. These calls DO appear
in blueprint edges but are NOT included in `file_call_graph.json` and
therefore NOT in the cross-language index.

```python
# file_call_graph.py:69-89
_CPP_STDLIB_NOISE = frozenset({
    # C stdlib: memcpy, strlen, malloc, free, printf, ...
    # z/TPF APIs: crusa, getcc, relcc, ecbptr, glob, attac, ...
    # z/TPFDF APIs: dfred, dfmod, df_setkey, ...
    # TPF heap: tpf_eheap_alloc, tpf_eheap_free, ...
})
```

**Impact:** Calls to `crusa()`, `glob()`, `getcc()`, `df_setkey()` etc.
from CPP source files are filtered out of the file-level call graph.
They still appear as blueprint edges and in the callers index, but not
in the cross-language index.

### 5.10 CALL_ALIAS in File-Level Call Graph

CPP→ASM edges from `asm()` / `#pragma map` aliases are represented as
`CALL_ALIAS` instruction type in `file_call_graph.json`:

```python
# file_call_graph.py — CPP_ALWAYS_CROSS set
CPP_ALWAYS_CROSS = {"CALL_ALIAS"}
```

`CALL_ALIAS` edges bypass the normal module-boundary heuristics and are
unconditionally included in the file-level call graph. This ensures that
all resolved CPP→ASM alias calls appear in the cross-language index.

---

## 6. Summary Table

### 6.1 Forward Traversal (CPP→ASM)

| # | Pattern | Data Source | Key Feature |
|---|---------|-------------|-------------|
| 1 | Cross-language index forward | `cross_lang.forward` from file_call_graph.json | Primary CPP→ASM boundary crossing |
| 2 | CPP blueprint edge to external | `*.cpp.json` call_graph edges | External ASM target in CPP blueprint |
| 3 | CALLCPP/CALLC bridge | ASM blueprint edge with `instruction="CALLCPP"` | ASM-to-CPP macro bridge (reverse visible) |
| 4 | CPP source fallback | `source_scanner.scan_callees_in_function` | Regex-based when blueprint absent |
| 5 | ASM metadata resolution | `_resolve_node_from_blueprint` | ASM node details from ASM blueprint |
| 6 | Language detection | `_cl_file_types` → `_idx_file_types` → `"cpp"` | Priority cascade for node language |
| 7 | No CHA for ASM | — | Virtual dispatch only for `::` methods |

### 6.2 Backward Traversal (CPP→ASM)

| # | Pattern | Data Source | Key Feature |
|---|---------|-------------|-------------|
| 8 | Cross-language index backward | `cross_lang.backward` from file_call_graph.json | Primary CPP callers of ASM routines |
| 9 | Callers index | `index.callers` (all blueprints) | CPP→ASM entries if blueprint captured edge |
| 10 | ASM blueprint edge inversion | ASM blueprint edges (inverted) | Intra-file ASM callers only |
| 11 | CPP source fallback | `source_scanner.scan_callers_in_source` | Depth-0 CPP nodes only |
| 12 | No ASM source fallback | — | Warning only; no ASM source scanning |

### 6.3 Concrete Codebase Patterns

| # | Pattern | Declaration | Linkage Mechanism | Example File |
|---|---------|-------------|-------------------|--------------|
| A | `extern "C"` + `asm()` | `extern "C" void f(TPF_regs*) asm("XX99")` | Compiler resolves to ASM symbol | dx740200.cpp |
| B | `#pragma map()` | `#pragma map(f,"XX99")` | Compile-time name mapping | rh73Iw00.cpp |
| C | Direct ASM name | `extern "C" void XX99(TPF_regs*)` | Name-based linkage | cf500000.cpp |
| D | Register setup | `regs.rN = ...; f(&regs);` | TPF_regs convention | dx740200.cpp |
| E | `#pragma export` | `#pragma export(f)` | CPP callable from ASM | dp710100.cpp |
| F | Null-pointer call | `f(0)` | ECB-based parameter passing | av200100.cpp |

### 6.4 IBM-Documented Patterns

| # | Pattern | Macro/Mechanism | Direction |
|---|---------|-----------------|-----------|
| 1 | CALLC | `CALLC func(R2,R3)` | ASM → C (with CPROC) |
| 2 | CPROC | `CPROC RETURN=type,name,(types)` | Prototype declaration |
| 3 | UPROC | Prototype bundle | Groups CPROCs |
| 4 | ENTRC/ENTNC/ENTDC | Program entry macros | Inter-module transfer |
| 5 | PRLGC/EPLGC | C-callable BAL prolog/epilog | ASM library wrappers |
| 6 | CLINKC/RLINKC/SLINKC | Program linkage macros | Needs extraction |
| 7 | z/TPF C functions | getcc, relcc, creec, etc. | C wrappers for ASM macros |
| 8 | TPF 4.1 parameter passing | Via CPROC (legacy) | Migration compatibility |

---

## 7. Configuration Parameters

These request-level parameters affect CPP→ASM traversal:

| Parameter | Default | Effect on CPP→ASM |
|-----------|---------|-------------------|
| `direction` | `"forward"` | Forward: traces CPP's ASM callees. Backward: finds CPP callers of ASM. |
| `max_depth` | `5` | Maximum BFS hops; controls depth across CPP→ASM boundary and into ASM call graph |
| `include_external` | `false` | Include stdlib/external functions; ASM targets marked `is_external` may be filtered |
| `include_indirect_calls` | `true` | Include register-indirect calls (BALR-based in ASM portion of graph) |
| `expand_virtual_dispatch` | `true` | No effect on ASM targets (CHA only applies to `::` methods) |
| `max_nodes` | `1,000,000` | Maximum nodes before truncation |
| `source_path` | `null` | CPP source fallback path; no effect on ASM nodes |
| `include_params` | `true` | Signature enrichment for CPP nodes only; no effect on ASM nodes |
| `force_rebuild_index` | `false` | Forces re-parse of blueprints and file_call_graph.json |

---

## ASM Routines Called from CPP in this Codebase

| ASM Module | C++ Wrapper Name | Called From |
|------------|-----------------|-------------|
| AI71 | initCCR | dx740200.cpp, dx710000.cpp |
| AC71 | initializeBcis | dx740200.cpp |
| AC76 | setAuthRelayBcis | dx740200.cpp |
| AH71 | AH71 | dw712100.cpp |
| AL22 | callAlertMaintenence | dx730000.cpp |
| AO71 | AO71 | dw712100.cpp, cf580100.cpp |
| AU70 | getLg1g1Type16 | dx740200.cpp |
| AV01 | callAV01 | rh73Iw00.cpp |
| CF55 | CF55 | cf500000.cpp, dw712100.cpp, cf580100.cpp |
| DA77 | getLg1g1Type26 | dx740200.cpp |
| DA78 | buildLg1g1 | dx740200.cpp |
| DB71 | editHubglHeaderInfo | dx740200.cpp |
| DB73 | convertMessageFormat | dx740200.cpp |
| DC10 | cmseUpdate | dx730000.cpp |
| DC78 | negativeUpdate | dx730000.cpp |
| DE70 | checkMessageMonitor | dx740200.cpp, dx730000.cpp |
| EM71 | EM71 | dw710300.cpp |
| FA71 | callLogCasARecord | dx710000.cpp |
| GA71 | processNegative | dx740200.cpp |
| NB81 | incrementCounters / NB81 | dx740200.cpp, cf500000.cpp, av200100.cpp, dx710000.cpp, dw710700.cpp, dw780000.cpp |
| PB31 | getTms | rh73Iw00.cpp |
| PB3A | getTdr | dx740200.cpp |
| SL70 | callAccountManager | dx740200.cpp, dp710100.cpp, dw780000.cpp |
| SR70 | callCoreCarver | av200100.cpp, rh73Iw00.cpp, dp710100.cpp, dw730000.cpp, dw780000.cpp |
| SX01 | logLi1i1 | dx740200.cpp |
| TE89 | TE89 | cf500000.cpp |
| TE90 | ckXc | rh73Iw00.cpp |
| UNPACK | unpackData | rh73Iw00.cpp, dp710100.cpp, dw710100.cpp, dw710200.cpp, dw710700.cpp, dw712100.cpp, dw780000.cpp |
| VP18 | VP18 | dx710000.cpp |
| YK11 | YK11 | dx710000.cpp |
| ZCM1 | ZCM1 | av200100.cpp |

---

## File References

| Component | Path |
|-----------|------|
| Forward traversal | `cpp_call_chain/traversal.py:377-639` |
| Backward traversal | `cpp_call_chain/traversal.py:646-883` |
| Cross-lang forward boundary | `cpp_call_chain/traversal.py:615-637` |
| Cross-lang backward boundary | `cpp_call_chain/traversal.py:855-881` |
| Language detection | `cpp_call_chain/traversal.py:427-429` |
| ASM metadata fallback | `cpp_call_chain/traversal.py:165-189` |
| Blueprint loader | `cpp_call_chain/traversal.py:101-142` |
| Source scanner (forward) | `cpp_call_chain/source_scanner.py:366-427` |
| Source scanner (backward) | `cpp_call_chain/source_scanner.py:434-509` |
| Index builder (all blueprints) | `cpp_call_chain/index_builder.py:220-332` |
| Cross-language index | `cpp_call_chain/index_builder.py:526-778` |
| Same-language filter | `cpp_call_chain/index_builder.py:632` |
| File-level call graph | `file_call_graph.py` |
| ASM module name regex | `file_call_graph.py:93` |
| Cross-file call opcodes | `backward_traversal/glossary/instructions.py:84-85` |
| C family analyzer (alias extraction) | `multi_file/c_family_analyzer.py` |
| CALLCPP target extraction | `passes/call_graph_builder.py:388-404` |
| CALLCPP edge creation | `passes/call_graph_builder.py:816-829` |
| CallType enum | `models/call_graph.py:8-19` |
| Indirection utils | `api/utils/indirection.py` |
| Endpoint handler | `api/routes/knowledge_base.py:2504-2832` |
| Cross-lang index loading | `api/routes/knowledge_base.py:2711-2722` |
| IBM ASM-C interop docs | `temp/ibm/patterns/asm-c-interoperability.md` |
| IBM system macros docs | `temp/ibm/macros/ztpf-system-macros.md` |
| IBM migration notes | `temp/ibm/migration-notes.md` |
| IBM OS C functions | `temp/ibm/functions/ztpf-os-c-functions.md` |
