# Explainability Module — Design Document

**Date:** 2026-05-18
**Status:** Proposed
**Scope:** Knowledge-base-level codebase intelligence agent that answers natural language questions about any entity in a CPP/ASM codebase using pipeline-generated outputs, actual source code, and PI-Coding-Agent.

---

## 1. Problem Statement

After the pipeline runs against a codebase and produces its outputs (blueprints, variable universes, hop index, call graph, modifier index), a user needs to ask questions like:

- *"What is CE1CR0 and where does it get modified?"*
- *"How do CE1CR0 and CE1CR1 interact within FINSUPP, and what triggers their modification?"*
- *"Trace the complete data flow from ae48.asm through xh80.asm for the CASDB block."*
- *"Which subroutines call FINSUPP and what variables do they pass to it?"*
- *"Explain the backward lineage of all variables in the CE1CRA DSECT section."*
- *"Give me full traceability of CE1CR0 — every chain it appears in, every file that reads or writes it, all backward lineage, all forward impact, all aliases."*
- *"Show me the complete end-to-end traceability report for the FINSUPP function."*

These questions have five properties that rule out a simple lookup approach:

1. **Multiple entities** — a single question can reference several variables, functions, files, and blocks simultaneously.
2. **Unbounded depth** — questions can ask to "trace all the way", "complete picture", requiring recursive traversal of the call graph and backward lineage.
3. **Mixed entity types** — questions span variables, subroutines, DSECT blocks, files, registers, macros, and business-level operations.
4. **Index gaps and staleness** — parsed indices do not capture everything. Comments, conditional assembly, macro-generated symbols, and parser edge cases leave gaps. The actual source files are the ground truth and must be consulted to fill those gaps and to verify index results before presenting them as fact.
5. **Full traceability** — some questions do not ask for an explanation at all; they ask for a complete enumeration of every chain an entity participates in. This is a fundamentally different output shape: a structured report organized by chain type (modification chains, read chains, backward lineage tree, forward impact tree, alias map), with coverage metrics and per-chain verification. Prose synthesis is not the goal — completeness and structure are.

---

## 2. Available Data Sources (per job output)

The agent works from two tiers of data. Both are always available.

### Tier 1 — Pipeline-Generated Indices (fast, structured, pre-computed)

Present in `/var/asm-jobs/{kb_id}/output/`.

| File | Contents | Size (1400-file job) |
|---|---|---|
| `asm_variable_universe.json` | Declaration, scope, data type, all locations for every ASM variable | 108 MB |
| `cpp_variable_universe.json` | Same for C/C++ variables | ~183 KB |
| `variable_identity_index.json` | Maps variable names to canonical identities; lists which files contain each identity | ~380 KB |
| `variable_hop_index.json` | Every file:line where each variable appears, with operation type and relation | ~1.5 MB |
| `variable_modifier_index.json` | Which files write/set each variable | ~16 KB |
| `file_call_graph.json` | File-level call graph: nodes (file stems), edges (call sites, call types) | ~660 KB |
| `{stem}.asm.json` / `{stem}.cpp.json` | Per-file blueprints: symbols, lineage edges, DSECT blocks, macro expansions, call graph | 100 KB–15 MB each |

**Limitations of indices:** Indices reflect what the parser successfully extracted. They miss: inline comments with business logic, symbols introduced by conditional assembly not taken during the parse run, macro-generated labels that were not fully expanded, and any parser edge cases silently skipped. They are also fixed at pipeline run time and do not reflect edits made to source files afterward.

### Tier 2 — Actual Source Files (ground truth, raw, requires search/read)

Present in `/var/asm-jobs/{kb_id}/input/` (uploaded codebase).

| What the source provides | That indices do not |
|---|---|
| Inline comments explaining business intent | Not captured in any index |
| Full instruction sequence within a subroutine | Blueprints record edges, not ordered instruction flow |
| Conditional assembly branches not taken | Parser resolves one path; other branches absent from indices |
| Macro-generated code at expansion site | Index records the macro name, not expanded instructions |
| Symbols only referenced but never defined in parsed files | Identity index records only symbols with a definition |
| Cross-verification: does the index claim match the actual line? | Indices can be stale or contain parser approximations |

**Source is the authoritative fallback.** Whenever an index result is uncertain, incomplete, or contradicts another index result, the agent reads the actual source to resolve the conflict or fill the gap.

### Entity types available across these sources

| Entity Type | Primary Source | Examples |
|---|---|---|
| Variable (memory) | `asm_variable_universe`, hop index | `CE1CR0`, `LG1SRC`, `CASDB` |
| DSECT field | Blueprint `meta.dsect_fields` | `CE1CRA:5`, `LG1G1:CASDB` |
| Register | Universe + hop index (`node_id` prefix `register:`) | `R5`, `R14` |
| Function / Subroutine | Blueprint `symbols` (kind: `routine`/`function`) | `FINSUPP`, `DA7_MAIN` |
| File / Module | `file_call_graph.json` nodes | `xh71`, `ae48`, `dx710000` |
| DSECT Block / Section | Blueprint sections | `CE1CRA`, `LG1G1` |
| Macro | Blueprint `meta.macros` | `SWISC`, `ENTRC`, `CREEC` |
| Operation | Hop index `operation_type` field | `move`, `compare`, `load`, `store` |

### Operation types tracked in hop index

`move`, `compare`, `load`, `store`, `arithmetic`, `logical`, `initialize`, `call_arg`

### Call types tracked in call graph

`subroutine_call`, `no_return_call`, `async_spawn`, `call`, `mode_transition`, `branch`, `return`, `execute`, `macro_invocation`, `isc_route`

---

## 3. Architecture Overview

The module operates in two distinct **modes** selected in Phase 1. Both modes share Phases 1 and 2 but diverge in what they gather and how they produce output.

```
┌─────────────────────────────────────────────────────────────┐
│  PHASE 1: INTELLIGENCE EXTRACTION                            │
│                                                              │
│  NL Question                                                 │
│       ↓                                                      │
│  Entity Extractor  → [CE1CR0, CE1CR1, FINSUPP, xh80]        │
│  Intent Classifier → trace_multi_entity | full_traceability  │
│  Mode Selector     → EXPLAIN mode  or  TRACE mode           │
└───────────────┬──────────────────────────┬──────────────────┘
                │                          │
                ▼  EXPLAIN mode            ▼  TRACE mode
┌───────────────────────────┐  ┌───────────────────────────────┐
│  PHASE 2: AGENTIC         │  │  PHASE 2: EXHAUSTIVE CHAIN    │
│  GATHERING                │  │  ENUMERATION                  │
│                           │  │                               │
│  2a. INDEX PASS           │  │  2a. Enumerate ALL chain      │
│      Targeted index tools │  │      types for every entity   │
│      Parallel execution   │  │      (modification, read,     │
│      → Knowledge          │  │      backward, forward,       │
│        Accumulator        │  │      alias, call tree)        │
│                           │  │                               │
│  2b. SOURCE VERIFICATION  │  │  2b. SOURCE VERIFICATION      │
│      Verify key claims    │  │      Verify every chain hop   │
│      Source overrides     │  │      against actual source    │
│      index on conflict    │  │                               │
│                           │  │  2c. GAP FILLING              │
│  2c. GAP FILLING          │  │      Fill missing chain nodes │
│      Raw source search    │  │      from raw source search   │
│      for missing entities │  │                               │
│                           │  │  2d. CROSS-CHAIN ANALYSIS     │
│  Loop until answered      │  │      Find shared nodes across │
│  or budget exhausted      │  │      chains; coverage metrics │
└───────────┬───────────────┘  └─────────────┬─────────────────┘
            │                                │
            ▼                                ▼
┌───────────────────────────┐  ┌───────────────────────────────┐
│  PHASE 3: PROSE SYNTHESIS │  │  PHASE 3: REPORT ASSEMBLY     │
│                           │  │                               │
│  LLM synthesizes          │  │  Deterministic assembly of    │
│  accumulator → narrative  │  │  TraceabilityReport struct    │
│  with file:line citations │  │  No LLM prose — structured    │
│  Flags gaps, open threads │  │  chain records + coverage     │
│                           │  │  LLM adds 1-sentence summary  │
│                           │  │  per chain (optional)         │
└───────────────────────────┘  └───────────────────────────────┘
```

**Key distinction:** In TRACE mode, Phase 3 is mostly deterministic — the report is assembled from chain records gathered in Phase 2, not synthesized from an LLM narrative. The LLM is only optionally used to generate a one-sentence human summary for each individual chain.

---

## 4. Phase 1 — Intelligence Extraction

A lightweight single LLM call before any tool use. It produces a structured plan that drives Phase 2.

### 4.1 Entity Extraction

Extracts all entity references from the question, regardless of type:

```json
{
  "entities": [
    { "name": "CE1CR0",  "likely_type": "register" },
    { "name": "CE1CR1",  "likely_type": "register" },
    { "name": "FINSUPP", "likely_type": "subroutine" },
    { "name": "xh80",    "likely_type": "file" }
  ]
}
```

### 4.2 Intent Classification and Mode Selection

Intents are classified into two groups. The group determines which execution mode is used.

#### EXPLAIN mode intents (prose narrative output)

| Intent | Description | Example trigger phrases |
|---|---|---|
| `explain_entity` | Describe what an entity is and does | "what is", "what does X do", "define" |
| `trace_flow` | Follow data/control flow across files | "trace", "flow", "from X to Y" |
| `find_callers` | Find what calls a function | "who calls", "what triggers" |
| `find_effects` | Find what a variable/function affects downstream | "what does X affect", "what changes when" |
| `explain_block` | Describe a DSECT block or section | "explain the block", "what fields are in" |
| `trace_multi_entity` | Find how multiple entities interact | multiple entities + relationship words |
| `describe_process` | Business-level process explanation | "what business process", "what does this implement" |
| `backward_lineage` | Where does a value come from | "where does X get its value", "what feeds into" |

#### TRACE mode intents (structured traceability report output)

| Intent | Chain types collected | Example trigger phrases |
|---|---|---|
| `full_traceability` | All: modification + read + backward lineage + forward impact + aliases + call tree | "full traceability", "complete traceability", "trace everything", "all chains" |
| `modification_trace` | Modification chains only | "every place X is set", "all write chains", "all modification paths" |
| `read_trace` | Read chains only | "every place X is read", "all read chains", "all compare paths" |
| `call_tree_trace` | Full caller tree + callee tree | "full call tree", "all callers recursively", "complete call hierarchy" |
| `lineage_trace` | Backward lineage tree + forward impact tree | "full lineage", "end-to-end data flow", "complete upstream and downstream" |
| `block_traceability` | All fields in a DSECT block, each field's chains | "trace the entire CE1CRA block", "full DSECT traceability" |

**Mode selection rule:** If any TRACE-mode intent is detected, the entire request runs in TRACE mode regardless of other intents in the same question. A question like *"What is CE1CR0 and give me full traceability"* runs in TRACE mode and includes a prose entity description as a field within the traceability report.

### 4.3 Depth Detection (EXPLAIN mode only)

Depth is auto-detected from question signals. It controls how many agent rounds are allowed.

| Signal | Depth | Max rounds |
|---|---|---|
| "what is", "define", "where declared" | `surface` | 2 |
| "how does", "explain", "what does it do" | `medium` | 5 |
| "trace", "flow", "from X to Y", "through" | `deep` | 10 |
| "complete", "all the way", "full picture" | `exhaustive` | 15 |
| Multiple entities mentioned | +1 level | +3 rounds |
| "briefly", "quick", "just tell me" | −1 level | −2 rounds |

---

## 5. Phase 2 — Agentic Gathering (PI-Coding-Agent)

### 5.1 Tool Set (32 tools across 7 domains)

#### A. Entity Resolution (4 tools)

**`resolve_entities(names: list[str])`**
Batch lookup of any entity names. Returns canonical ID, entity type, declaration location, and file count for each. Queries `identity_index` + `variable_universe` + `call_graph` nodes simultaneously. This is always the first tool called.

**`get_entity_type(name: str)`**
Determines whether a name is a variable, subroutine, file, DSECT block, or macro. Needed when the intent extraction is uncertain (e.g., `FINSUPP` could be a variable or a subroutine label).

**`search_entities(pattern: str, kind: str = None)`**
Fuzzy/partial name search across all universes. Handles partial names, alternate spellings, and questions that don't use the exact symbol name.

**`get_aliases(entity: str)`**
Returns all known aliases for an entity: global alias, DSECT:offset alias, `ce_slot` alias, `access_identity` alias. Critical for variables that have multiple names across files.

---

#### B. Variable Intelligence (5 tools)

**`get_variable_profile(canonical_key: str)`**
Full variable profile from `variable_universe` + `identity_index`: scope, data type, all locations, operation summary (count of load/store/compare operations per file).

**`get_variable_hops(canonical_key: str, filter_ops: list[str] = None)`**
All entries from `variable_hop_index` for this variable, optionally filtered by operation type. Groups results by file for readability. Shows every file:line:instruction that touches the variable.

**`get_variable_modifiers(name: str)`**
Files and lines that write/set this variable. Sources: `variable_modifier_index` + hop index filtered to `define`, `assign`, `move` (setter instructions: MVC, ST, MVI, LA, etc.).

**`get_variable_readers(name: str)`**
Files and lines that read or compare this variable. Hop index filtered to `compare`, `load`, `use` relations (trigger instructions: CLC, CLI, C, CR, TM, etc.).

**`get_backward_lineage(variable: str, from_file: str, depth: int = 3)`**
What feeds into this variable's value. Calls `backward_only_runner` directly (not via HTTP). Returns a condensed graph (nodes + edges), not the full JSON output. `depth` maps to `max_depth` in the backward lineage runner.

---

#### C. Function/Subroutine Intelligence (4 tools)

**`get_function_definition(name: str, file: str = None)`**
Entry point location, instruction count, registers used, calls made. Source: blueprint `symbols` filtered to `kind: routine/function`. If `file` is omitted, searches all blueprints.

**`get_callers_of_function(name: str, file: str)`**
Which files and subroutines call this function, via what call type (BAL, ENTRC, CREEC, etc.). Source: `file_call_graph` edges reversed + `call_sites` metadata.

**`get_callees_of_function(name: str, file: str)`**
What this function calls: direct calls, macro invocations, cross-file calls. Source: blueprint `call_graph` for the file + `file_call_graph` outgoing edges from the file.

**`get_variables_in_function(name: str, file: str)`**
All variables defined or used within a function's scope. Source: blueprint symbols filtered by `scope_chain` containing the function name.

---

#### D. File/Block Intelligence (3 tools)

**`get_file_overview(file_stem: str)`**
Entry points, exported symbols, imported macros, call count, DSECT sections defined, total variable count. Source: blueprint top-level metadata + symbol counts. Returns a compact summary, not the full blueprint.

**`get_block_contents(file_stem: str, block_name: str)`**
All fields in a DSECT block: field names, byte offsets, data types. Source: blueprint `meta.dsect_fields` filtered to the named block.

**`find_shared_files(entities: list[str])`**
Files that contain ALL of the specified entities simultaneously. Source: intersection of `identity_index.by_identity[*].files` across all listed entities. This is the critical first tool for multi-entity questions — it finds the common ground before deeper analysis.

---

#### E. Flow & Graph Intelligence (2 tools)

**`get_call_paths(source_file: str, target_file: str, variable: str = None)`**
All call-graph paths between two files. Reuses the existing `_find_paths` + 7-strategy identity resolver from `knowledge_base.py`. Optional `variable` parameter filters to paths where the variable is tracked.

**`trace_cross_entity_flow(entity_a: str, entity_b: str)`**
Finds the connection between two entities of potentially different types (variable↔function, variable↔variable, function↔file). Combines `find_shared_files` + `get_call_paths` + hop index intersection to build a relationship narrative.

---

#### F. Traceability Chain Enumeration (3 tools — TRACE mode only)

These tools are only called in TRACE mode. They operate exhaustively, not selectively — they return all chains of a given type, not just the most relevant ones.

**`enumerate_modification_chains(entity: str, max_depth: int = 10)`**
Returns every complete path from any entry point in the call graph to every site where the entity is written or set. Each chain record includes: chain ID, entry point (file + label), every hop (file + line + instruction + call type), terminal modification site (file + line + instruction + operation type), trigger condition (the branch instruction that guards this modification path if any), and a `verified` flag. Sources: `variable_hop_index` for terminal sites + `file_call_graph` for path enumeration + `variable_modifier_index` for setter confirmation.

**`enumerate_read_chains(entity: str, max_depth: int = 10)`**
Same structure as modification chains but for every site where the entity is loaded, compared, or tested. Returns chains grouped by operation type (compare, load, call_arg). Includes the instruction that uses the entity and the condition register context if available from the blueprint.

**`get_full_call_tree(entity: str, file_stem: str, direction: str, max_depth: int = 8)`**
Returns the complete recursive call tree for a subroutine or file. `direction` is `"callers"` (who calls this, recursively) or `"callees"` (what this calls, recursively). Each node in the tree includes: file, label, call type, line, and whether it is an external dependency or a known internal module. Sources: `file_call_graph` edges + blueprint `call_graph` per file for intra-file resolution. Used for `call_tree_trace` intent and as a sub-step in `full_traceability`.

**`enumerate_forward_impact(entity: str, max_depth: int = 6)`**
Traces what the entity feeds into downstream: which other variables receive its value (directly or via register carry-over), which branch conditions it triggers, which files those branches affect. Returns a tree structure, not a flat list. Sources: `variable_hop_index` (reads of the entity that appear as sources for other operations) + blueprint lineage edges in the forward direction.

**`get_block_traceability(file_stem: str, block_name: str)`**
For every field in a DSECT block, returns that field's full profile: declaration, all modification chains, all read chains, backward lineage summary. Combines `enumerate_modification_chains` + `enumerate_read_chains` + `get_variable_profile` for each field in `get_block_contents` output. This is the bulk tool for `block_traceability` intent.

---

#### G. Source Code — Index-Backed Reads (3 tools)

These tools are driven by known line numbers from the indices (Tier 1 data points to Tier 2 content).

**`read_source_context(file_stem: str, line: int, window: int = 10)`**
Reads `window` lines before and after a target line from the job input directory. Used after an index lookup returns a specific file:line — the agent reads the actual source to see the full instruction in context, including any inline comments.

**`read_source_segment(file_stem: str, from_line: int, to_line: int)`**
Reads an arbitrary contiguous range of lines. Used when the agent needs to read an entire subroutine body or DSECT block after the blueprint identifies its start and end line numbers.

**`read_function_source(file_stem: str, function_name: str)`**
Extracts the complete source of a subroutine or function. Locates the entry label from the blueprint, then reads from that label to the next `BR R14`/`RETURN`/`EXITC` or next section label. Returns the full instruction sequence — ordered, annotated with line numbers, and including any comments within the body.

---

#### G. Source Code — Direct Source Search (4 tools)

These tools operate on raw source when index data is absent, incomplete, or needs verification. They treat the source codebase as a searchable corpus.

**`search_in_file(file_stem: str, pattern: str)`**
Searches for a symbol, instruction mnemonic, or text pattern within a single source file. Returns all matching line numbers with the surrounding line. For targeted lookup within a file when the index didn't record it.

**`search_across_codebase(pattern: str, file_extension: str = None)`**
Searches the pattern across ALL source files in the job input directory. `file_extension` narrows to `.asm`, `.cpp`, `.hpp`, etc. Returns a list of `(file, line, matching_line_text)` tuples. Used for gap-filling when an entity is not in any index — the agent finds it directly in source.

**`extract_comments_near(file_stem: str, line: int, window: int = 20)`**
Extracts only comment lines (`;`-prefixed in ASM, `//` or `/* */` in CPP) near a given line. Comments are not captured in any index but often contain the business intent explanation that makes a variable's purpose clear. This tool is called specifically to gather that context.

**`verify_claim(file_stem: str, line: int, expected_pattern: str)`**
Checks whether the actual source at `file:line` matches what an index claims is there. Returns `verified: true/false`, the actual source line text, and a diff if there is a mismatch. Called during the Source Verification Pass for every key claim before it is included in the final explanation.

---

### 5.2 Source Verification and Gap-Filling Strategy

#### Verification Pass (Phase 2b)

After the Index Pass (2a) populates the accumulator with claims from the indices, the agent runs a targeted verification pass before synthesis. The goal is to not present an index result as fact if the source contradicts it.

**What gets verified:**
- Every `modifier_files` entry: read the actual line where the index says a variable is set — confirm the instruction is a setter (ST, MVC, MVI, etc.) and the symbol name matches
- Every function definition location: confirm the label exists at the claimed line in source
- Every DSECT field offset: confirm the EQU value at the blueprint-reported line matches the claimed offset

**What happens on a mismatch:**
- The source text overrides the index claim in the accumulator
- The discrepancy is recorded in `accumulator.source_discrepancies`
- Included in the response `gaps` field: *"Index claimed CE1CR0 set at xh80.asm:245 but source at that line shows CLC (compare), not ST — index may be stale"*

**Selective verification:** The agent verifies claims that are directly cited in the answer (not all index data). Depth `surface` verifies 0–2 claims. `medium` verifies up to 5. `deep`/`exhaustive` verifies all cited claims.

#### Gap-Filling Pass (Phase 2c)

Triggered when any of the following occurs:
- `resolve_entities` returns no match for an entity name
- `get_variable_profile` returns empty locations
- `get_function_definition` finds no blueprint entry for a symbol
- The agent determines that a key aspect of the question is unanswered by indices alone (e.g., "what does the comment above this block say?")

**Gap-filling workflow:**
1. Agent calls `search_across_codebase(entity_name)` to find raw occurrences
2. If found: `read_source_context` at the found lines to understand usage
3. If entity looks like a subroutine label: `read_function_source` to extract its body
4. If the gap is about intent/purpose: `extract_comments_near` the relevant lines
5. Findings are added to accumulator with source `"tier2_only"` flag (index never captured this)
6. `tier2_only` entries are marked in the response to signal the user that this was inferred from raw source, not parsed indices

---

### 5.3 Knowledge Accumulator

Raw tool outputs are MB-scale. Appending them directly to the conversation history overflows the context window within 3–4 rounds. The **Knowledge Accumulator** solves this by distilling each tool result into a compact structured graph.

The LLM sees a summary of the accumulator each round. The raw outputs are held in Python memory only.

**Accumulator structure:**
```json
{
  "entities_known": {
    "CE1CR0": {
      "type": "register",
      "canonical": "CE1CRA:5",
      "declared_in": "xh71.asm:45",
      "appears_in_n_files": 8,
      "modifier_files": ["xh80.asm", "xh90.asm"],
      "op_breakdown": { "load": 12, "compare": 5, "store": 3 },
      "source_tier": "tier1"
    },
    "FINSUPP": {
      "type": "subroutine",
      "defined_in": "ae48.asm:1200",
      "called_by": ["xh71.asm", "xh80.asm"],
      "modifies_variables": ["CE1CR0", "CE1CR1", "LG1SRC"],
      "source_tier": "tier1"
    },
    "DA7_CLEANUP": {
      "type": "subroutine",
      "defined_in": "da76.asm:850",
      "source_tier": "tier2_only",
      "note": "Not in identity index — found via search_across_codebase"
    }
  },
  "relationships_found": [
    "CE1CR0 modified_inside FINSUPP at ae48.asm:1245 (ST instruction)",
    "xh71 → calls → FINSUPP → reads_then_sets → CE1CR0"
  ],
  "verified_claims": [
    "ae48.asm:1245 — confirmed ST R3,CE1CR0 in source",
    "xh71.asm:88  — confirmed BAL R14,FINSUPP in source"
  ],
  "source_discrepancies": [
    "Index: CE1CR0 set at xh80.asm:245 (ST). Source: line 245 is CLC — compare, not setter. May be stale index."
  ],
  "source_snippets_available": [
    "xh80.asm:120-135",
    "ae48.asm:1240-1255"
  ],
  "comments_extracted": [
    "ae48.asm:1238 — comment: '* Set control flag for financial suppression'"
  ],
  "gaps": [
    "CE1CR1 backward lineage not yet traced"
  ],
  "rounds_used": 3,
  "tool_calls_made": [
    "resolve_entities",
    "get_variable_profile",
    "get_callers_of_function",
    "verify_claim",
    "extract_comments_near"
  ]
}
```

Key fields added for source integration:
- `source_tier` on each entity: `"tier1"` (from index), `"tier2_only"` (found in raw source only)
- `verified_claims`: index claims confirmed against actual source
- `source_discrepancies`: mismatches where source contradicts index
- `comments_extracted`: business-intent comments pulled from source

**Additional fields in TRACE mode** — the accumulator grows a `chains` section alongside `entities_known`:

```json
{
  "mode": "trace",
  "entities_known": { "...": "same as EXPLAIN mode" },
  "chains": {
    "modification": [
      {
        "chain_id": "MC-001",
        "entry_point": { "file": "xh71", "label": "MAIN", "line": 10 },
        "hops": [
          { "file": "xh71", "line": 88,   "instruction": "BAL R14,FINSUPP", "call_type": "subroutine_call" },
          { "file": "ae48", "line": 1245, "instruction": "ST R3,CE1CR0",    "call_type": null }
        ],
        "terminal": { "file": "ae48", "line": 1245, "instruction": "ST R3,CE1CR0", "operation": "store" },
        "trigger_condition": "BNZ at xh71:92",
        "verified": true,
        "business_summary": null
      }
    ],
    "read": [ "..." ],
    "backward_lineage": {
      "root": "CE1CR0",
      "tree": { "...": "recursive node structure" },
      "depth_reached": 4
    },
    "forward_impact": {
      "root": "CE1CR0",
      "impacted_entities": [
        { "entity": "CE1CR1", "file": "xh80", "line": 302, "via": "CLI CE1CR0,X'01'", "impact_type": "branch_condition" }
      ]
    },
    "aliases": [
      { "alias": "CE1CRA:5", "type": "access_identity", "used_in_files": ["ae48", "xh90"] }
    ],
    "call_tree": {
      "callers": { "...": "recursive call tree inward" },
      "callees": { "...": "recursive call tree outward" }
    }
  },
  "cross_chain_nodes": [
    { "entity": "R3",      "shared_by_chains": ["MC-001", "MC-002", "RC-003"] },
    { "entity": "FINSUPP", "shared_by_chains": ["MC-001", "RC-005"] }
  ],
  "coverage": {
    "files_covered": 8,
    "files_total": 15,
    "coverage_pct": 53,
    "modification_chains_found": 3,
    "read_chains_found": 7,
    "chains_verified": 10,
    "chains_unverified": 0,
    "gaps": [
      { "chain_type": "modification", "file": "xh90", "reason": "max_depth exceeded", "depth_at_stop": 3 }
    ]
  },
  "verified_claims": ["..."],
  "source_discrepancies": ["..."],
  "tier2_only_findings": ["..."]
}
```

### 5.4 Parallel Tool Execution

When the agent identifies multiple independent tool calls in a single round (e.g., resolve three variables simultaneously, or verify three claims in parallel), they execute concurrently using `ThreadPoolExecutor`. This reduces round latency when the agent needs broad initial coverage of multiple entities.

Source search tools (`search_across_codebase`, `search_in_file`) are I/O-bound and benefit especially from parallel execution when the agent needs to search multiple files or symbols at once.

---

## 6. Phase 3 — Output Generation

Phase 3 diverges completely based on mode.

### 6.1 EXPLAIN mode — Prose Synthesis

The synthesis prompt uses the full accumulator — including verified claims, source discrepancies, extracted comments, and any `tier2_only` entities found via raw source search. The LLM is instructed to:

1. Answer the original question directly
2. Cite every claim with `file:line` and note whether it is index-backed (`tier1`) or source-only (`tier2_only`)
3. Where a verified source snippet is available, quote or paraphrase it
4. Where a comment was extracted, use its text to explain business intent in plain language
5. Explicitly call out discrepancies: *"The index reports CE1CR0 is set at xh80.asm:245 but source inspection shows a compare instruction there — cited only from source below"*
6. Flag gaps with reason: budget, max depth, or entity not found in either tier
7. List open threads that could be explored with follow-up questions

### 6.2 TRACE mode — Report Assembly

Report assembly is **deterministic**, not LLM-driven. The `TraceabilityReport` is built directly from the accumulator's `chains`, `cross_chain_nodes`, and `coverage` fields without an LLM synthesis call. This ensures the report is complete, consistent, and reproducible.

**Assembly steps:**
1. Sort modification chains by entry point file, then by hop count (shortest first)
2. Sort read chains by operation type, then by file
3. Build backward lineage tree from the accumulator's recursive node structure
4. Build forward impact list sorted by hop distance from root
5. Deduplicate aliases and sort by alias type
6. Compute cross-chain shared nodes: any entity appearing in more than one chain ID
7. Finalize coverage metrics
8. *(Optional)* For each chain where `business_summary` is null, make a batch LLM call to generate a one-sentence business summary per chain. Controlled by `include_chain_summaries` request flag. Reuses `llm/chain_explainer.py` caching pattern.

The report is written to disk at:
`/var/asm-jobs/{kb_id}/output/traceability/{entity}_{timestamp}.json`

and returned inline in the API response (or as a download URL for large reports — see Section 8).

---

## 7. Multi-Turn Session Support

Complex questions naturally generate follow-ups. Sessions allow the agent to resume without re-fetching what it already knows.

**First turn:** `session_id: null` → creates a new session, returns `session_id`
**Follow-up turn:** `session_id: "abc123"` → loads previous accumulator, continues from it

The agent skips `resolve_entities` for entities already in the accumulator. It picks up open threads flagged in the previous response.

Sessions are stored at:
`/var/asm-jobs/{kb_id}/explain_sessions/{session_id}.msgpack`

Sessions expire after 24 hours (configurable).

---

## 8. API Contract

### Endpoints

```
POST /v1/knowledge-bases/{kb_id}/explain
```
EXPLAIN mode (default) and TRACE mode for smaller reports. Synchronous. Returns the response directly. 120-second timeout for exhaustive depth.

```
POST /v1/knowledge-bases/{kb_id}/explain/async
```
Async variant for TRACE mode on large codebases where full chain enumeration may take more than 120 seconds. Returns a `job_id` immediately; result polled via `GET /v1/jobs/{job_id}`. Report written to `{kb_id}/output/traceability/`.

```
GET /v1/knowledge-bases/{kb_id}/explain/sessions/{session_id}
```
Returns the current accumulator state for a session (for debugging or continuing in a new client).

---

### Request Schema (shared by both endpoints)

```json
{
  "question": "Give me full traceability of CE1CR0",
  "session_id": null,
  "mode": null,
  "depth_override": null,
  "max_rounds": null,
  "include_source_snippets": true,
  "include_chain_summaries": true,
  "chain_types": null,
  "max_chain_depth": null
}
```

| Field | Type | Default | Description |
|---|---|---|---|
| `question` | `string` | required | Natural language question. Any entity type, any complexity. |
| `session_id` | `string \| null` | `null` | `null` starts a new session. Existing ID continues. |
| `mode` | `"explain" \| "trace" \| null` | `null` | `null` = auto-detect from question. Explicit override if needed. |
| `depth_override` | `"surface" \| "medium" \| "deep" \| "exhaustive" \| null` | `null` | EXPLAIN mode only. Overrides auto-detected depth. |
| `max_rounds` | `int \| null` | `null` | EXPLAIN mode only. Overrides auto-detected max rounds. |
| `include_source_snippets` | `bool` | `true` | Whether to fetch actual source lines during verification. |
| `include_chain_summaries` | `bool` | `true` | TRACE mode only. Whether to generate one-sentence LLM summaries per chain. |
| `chain_types` | `list[string] \| null` | `null` | TRACE mode only. `null` = all types. Or any subset: `["modification","read","backward_lineage","forward_impact","aliases","call_tree"]`. |
| `max_chain_depth` | `int \| null` | `null` | TRACE mode only. Overrides default per-chain max depth. |

---

### EXPLAIN mode Response Schema

```json
{
  "mode": "explain",
  "session_id": "abc123",
  "question": "How do CE1CR0 and CE1CR1 interact within FINSUPP?",
  "explanation": "CE1CR0 and CE1CR1 are control registers stored in the CE1CRA DSECT block...",
  "entities": {
    "CE1CR0": {
      "canonical": "CE1CRA:5",
      "type": "register",
      "declaration": { "file": "xh71.asm", "line": 45 },
      "modifier_files": ["xh80.asm", "xh90.asm"],
      "source_tier": "tier1"
    },
    "CE1CR1": { "...": "..." },
    "FINSUPP": {
      "type": "subroutine",
      "defined_in": "ae48.asm:1200",
      "called_by": ["xh71.asm", "xh80.asm"],
      "source_tier": "tier1"
    }
  },
  "relationships": [
    "FINSUPP modifies CE1CR0 at ae48.asm:1245 (ST instruction)",
    "CE1CR0 triggers branch at xh80.asm:302 (CLI comparison)"
  ],
  "source_snippets": [
    { "file": "ae48.asm", "lines": [1240, 1255], "code": "..." }
  ],
  "depth_used": "deep",
  "rounds_used": 7,
  "verified_claims": ["ae48.asm:1245 — ST R3,CE1CR0 confirmed"],
  "source_discrepancies": ["Index: CE1CR0 set at xh80.asm:245. Source shows CLC — stale index."],
  "tier2_only_findings": [],
  "gaps": ["CE1CR1 lineage in xh90 not fully traced"],
  "open_threads": ["Trace CE1CR1 backward from xh90", "Run full traceability of CE1CR0 for all chains"]
}
```

---

### TRACE mode Response Schema — TraceabilityReport

```json
{
  "mode": "trace",
  "report_id": "trc-20260518-ce1cr0-abc123",
  "subject": "CE1CR0",
  "subject_type": "register",
  "canonical": "CE1CRA:5",
  "question": "Give me full traceability of CE1CR0",
  "generated_at": "2026-05-18T15:47:00Z",
  "download_url": "/v1/knowledge-bases/{kb_id}/files/traceability/trc-20260518-ce1cr0-abc123.json",

  "summary": {
    "total_chains": 12,
    "modification_chains": 3,
    "read_chains":          7,
    "alias_count":          3,
    "backward_lineage_depth_reached": 4,
    "forward_impact_entity_count":    6,
    "call_tree_caller_depth":         3,
    "call_tree_callee_depth":         2,
    "files_covered":   8,
    "files_total":    15,
    "coverage_pct":   53,
    "chains_verified":   10,
    "chains_unverified":  2
  },

  "chains": {

    "modification": [
      {
        "chain_id": "MC-001",
        "description": "xh71.MAIN → FINSUPP → CE1CR0 store",
        "entry_point":  { "file": "xh71", "label": "MAIN",    "line": 10   },
        "terminal":     { "file": "ae48", "line": 1245, "instruction": "ST R3,CE1CR0", "operation": "store" },
        "hops": [
          { "seq": 1, "file": "xh71", "line": 88,   "instruction": "BAL R14,FINSUPP", "call_type": "subroutine_call" },
          { "seq": 2, "file": "ae48", "line": 1245, "instruction": "ST R3,CE1CR0",    "call_type": null }
        ],
        "trigger_condition": "BNZ at xh71:92 (CE1CR0 non-zero on entry)",
        "verified": true,
        "source_snippet": "1243  *  Set financial suppression flag\n1244   LA  R3,1\n1245   ST  R3,CE1CR0",
        "business_summary": "CE1CR0 is set to 1 when the entry condition indicates financial suppression is required."
      },
      { "chain_id": "MC-002", "...": "..." },
      { "chain_id": "MC-003", "...": "..." }
    ],

    "read": [
      {
        "chain_id": "RC-001",
        "entry_point": { "file": "xh80", "label": "XH80_MAIN", "line": 5 },
        "read_site":   { "file": "xh80", "line": 302, "instruction": "CLI CE1CR0,X'01'", "operation": "compare" },
        "hops": [ { "seq": 1, "file": "xh80", "line": 302, "instruction": "CLI CE1CR0,X'01'", "call_type": null } ],
        "subsequent_branch": { "instruction": "BNZ", "line": 304, "target_label": "XH80_SKIP" },
        "verified": true,
        "source_snippet": "302   CLI CE1CR0,X'01'\n303   BNZ XH80_SKIP",
        "business_summary": "CE1CR0 is tested here to determine whether to skip the suppression block."
      }
    ],

    "backward_lineage": {
      "root": "CE1CR0",
      "depth_reached": 4,
      "tree": {
        "node": "CE1CR0",
        "set_by": [
          {
            "site": "ae48.asm:1245",
            "instruction": "ST R3,CE1CR0",
            "value_source": {
              "node": "R3",
              "set_by": [
                {
                  "site": "ae48.asm:1240",
                  "instruction": "LA R3,1",
                  "value_source": { "node": "literal:1", "set_by": [] }
                }
              ]
            }
          }
        ]
      }
    },

    "forward_impact": {
      "root": "CE1CR0",
      "depth_reached": 3,
      "impacted": [
        { "entity": "branch:XH80_SKIP", "file": "xh80", "line": 304, "via": "CLI+BNZ", "impact_type": "branch_condition", "hop_distance": 1 },
        { "entity": "CE1CR1",           "file": "xh90", "line": 88,  "via": "MVC CE1CR1,CE1CR0", "impact_type": "data_copy", "hop_distance": 2 }
      ]
    },

    "aliases": [
      { "alias": "CE1CRA:5",  "type": "access_identity", "used_in_files": ["ae48", "xh90"] },
      { "alias": "LG1CR0",    "type": "global_alias",    "used_in_files": ["da76"] },
      { "alias": "5(,R9)",    "type": "base_offset",     "used_in_files": ["ae48"],
        "note": "R9 carries CE1CRA base in ae48 context" }
    ],

    "call_tree": {
      "callers": {
        "root": "FINSUPP in ae48",
        "children": [
          { "file": "xh71", "label": "MAIN",    "line": 88,  "call_type": "subroutine_call", "children": [] },
          { "file": "xh80", "label": "XH80_CHK","line": 200, "call_type": "subroutine_call", "children": [
              { "file": "da76", "label": "DA76_ENTRY", "line": 44, "call_type": "subroutine_call", "children": [] }
          ]}
        ]
      },
      "callees": {
        "root": "FINSUPP in ae48",
        "children": [
          { "file": "ae48", "label": "AE48_SUB1", "line": 1300, "call_type": "subroutine_call", "children": [] }
        ]
      }
    }
  },

  "cross_chain_nodes": [
    { "entity": "R3",      "type": "register",   "shared_by_chains": ["MC-001", "MC-002", "RC-003"] },
    { "entity": "FINSUPP", "type": "subroutine", "shared_by_chains": ["MC-001", "MC-002", "RC-005"] }
  ],

  "verified_claims": [
    "ae48.asm:1245 — ST R3,CE1CR0 confirmed in source",
    "xh71.asm:88   — BAL R14,FINSUPP confirmed in source"
  ],
  "source_discrepancies": [
    "Index: CE1CR0 set at xh80.asm:245. Source line 245 is CLC — possible stale index entry."
  ],
  "tier2_only_findings": [
    "LG1CR0 alias used in da76.asm — found via source search, not in identity index"
  ],
  "gaps": [
    { "chain_type": "modification", "file": "xh90", "reason": "max_depth exceeded", "depth_at_stop": 3 },
    { "chain_type": "forward_impact", "entity": "CE1CR1 downstream", "reason": "not in identity index in xh90", "depth_at_stop": 2 }
  ]
}
```

---

## 9. Module File Structure

```
explainability/
├── __init__.py
├── agent.py               # EXPLAIN mode: agentic loop
│                          # 2a index → 2b verify → 2c fill → prose synthesis
├── tracer.py              # TRACE mode: exhaustive chain enumeration
│                          # 2a enumerate → 2b verify per hop → 2c fill gaps
│                          # → 2d cross-chain analysis → deterministic report assembly
├── accumulator.py         # KnowledgeAccumulator: shared by both modes
│                          # EXPLAIN fields: entities, relationships, snippets
│                          # TRACE fields: chains{modification,read,backward,forward,
│                          #   aliases,call_tree}, cross_chain_nodes, coverage
├── intent.py              # Phase 1: entity extraction + intent + mode selection
│                          # Detects TRACE vs EXPLAIN; identifies chain_types for TRACE
├── report.py              # TraceabilityReport builder (TRACE mode)
│                          # Deterministic assembly from accumulator.chains
│                          # Optional LLM batch call for per-chain business_summary
├── session.py             # Multi-turn: persist/load accumulator via msgpack
│                          # 24-hour TTL; shared across EXPLAIN and TRACE sessions
├── prompts.py             # System prompts: EXPLAIN variants (7) + TRACE chain summary (1)
├── executor.py            # Parallel tool runner: ThreadPoolExecutor wrapper
├── response.py            # Pydantic schemas: ExplainRequest, ExplainResponse,
│                          # TraceabilityReport, ChainRecord, HopRecord, CoverageMetrics
└── tools/
    ├── __init__.py
    ├── entity_tools.py    # resolve_entities, get_entity_type, search_entities, get_aliases
    ├── variable_tools.py  # get_variable_profile, get_variable_hops,
    │                      # get_variable_modifiers, get_variable_readers,
    │                      # get_backward_lineage
    ├── function_tools.py  # get_function_definition, get_callers_of_function,
    │                      # get_callees_of_function, get_variables_in_function
    ├── file_tools.py      # get_file_overview, get_block_contents, find_shared_files
    ├── graph_tools.py     # get_call_paths, trace_cross_entity_flow
    ├── trace_tools.py     # TRACE mode only:
    │                      # enumerate_modification_chains, enumerate_read_chains,
    │                      # get_full_call_tree, enumerate_forward_impact,
    │                      # get_block_traceability
    └── source_tools.py    # INDEX-BACKED:  read_source_context, read_source_segment,
                           #               read_function_source
                           # DIRECT SEARCH: search_in_file, search_across_codebase,
                           #               extract_comments_near, verify_claim

api/routes/
└── explainability.py      # POST /explain          → agent.py or tracer.py
                           # POST /explain/async    → Celery task for large TRACE jobs
                           # GET  /explain/sessions/{id}
                           # Registered in api/app.py under /v1/knowledge-bases
```

---

## 10. Integration with Existing Components

No existing code is duplicated. The new module is wired into the existing stack.

| Existing Component | How the Explainability Module Uses It |
|---|---|
| `llm/caller.py` `_get_client()` | Agent loop reuses the same Gemini singleton; adds `tools=` parameter for function calling |
| `knowledge_base.py` `_blueprint_cache` | Imported directly by `file_tools.py` and `variable_tools.py` for blueprint access |
| `knowledge_base.py` `_load_identity_index()` | Imported into `variable_tools.py` |
| `knowledge_base.py` `_load_hop_index()` | Imported into `variable_tools.py` |
| `knowledge_base.py` `_find_paths()` | Imported into `graph_tools.py` `get_call_paths` |
| `find_variable_modifiers._build_adjacency()` | Used in `graph_tools.py` for call graph traversal |
| `backward_traversal/runner/backward_only_runner.py` | Called directly (not via HTTP) in `get_backward_lineage` |
| `llm/chain_explainer.py` `get_cached_chain_summary()` | Called in `get_call_paths` when chain summaries are already precomputed |
| `api/config.settings.JOBS_BASE_DIR` | Used to locate source files (`{JOBS_BASE_DIR}/{kb_id}/input/`) and session storage |

**Source file path resolution** (`source_tools.py`): The input directory is `settings.JOBS_BASE_DIR / kb_id / "input"`. File stems map to source files by scanning the input tree for `{stem}.asm`, `{stem}.cpp`, `{stem}.hpp`, etc. A stem→path map is built once per session and cached in the accumulator to avoid repeated directory scans.

---

## 11. Caching Strategy

Follows the same pattern as `chain_summaries.msgpack` in `llm/chain_explainer.py`.

| Cache | Location | Key | Invalidation |
|---|---|---|---|
| Explain response cache | `{kb_id}/output/explain_cache.msgpack` | `sha256(question + kb_id)[:16]` | Cleared when pipeline reruns |
| Session accumulator | `{kb_id}/explain_sessions/{session_id}.msgpack` | Session ID | 24-hour TTL |
| Stem→path map | In-memory per session | `kb_id` | Rebuilt if session restarts |

**Cache invalidation on source change:** If a source file's mtime is newer than the explain cache entry, the cached response is considered stale and the agent re-runs. This handles the case where source files have been edited since the last pipeline run — the agent always reads fresh source even if indices are stale.

---

## 12. Suggested Implementation Order

| Step | Component | Reason |
|---|---|---|
| 1 | `tools/entity_tools.py`, `variable_tools.py`, `function_tools.py`, `file_tools.py`, `graph_tools.py` | Pure index access, no LLM; fully unit-testable against existing output files |
| 2 | `tools/source_tools.py` — index-backed reads (`read_source_context`, `read_source_segment`, `read_function_source`) | Test against a known file:line from existing output |
| 3 | `tools/source_tools.py` — direct search (`search_in_file`, `search_across_codebase`, `extract_comments_near`, `verify_claim`) | Test gap-filling and verification against known discrepancies |
| 4 | `intent.py` | Single LLM call; validates entity extraction and EXPLAIN/TRACE mode selection |
| 5 | `accumulator.py` | Core data structure; test by replaying real tool outputs; include both EXPLAIN and TRACE field shapes |
| 6 | `agent.py` — Phase 2a (index pass) only | Get the EXPLAIN index-only path working end-to-end first |
| 7 | `agent.py` — Phase 2b + 2c (verification + gap-filling) | Add source passes once index pass is stable |
| 8 | `tools/trace_tools.py` | Build TRACE-mode enumeration tools; test each independently against the hop index and call graph |
| 9 | `tracer.py` — chain enumeration only (no verification) | Run all chain types against the 1400-file job output; validate chain counts and structure |
| 10 | `tracer.py` — Phase 2b + 2c (per-hop verification + gap-filling) | Add source verification per chain hop |
| 11 | `report.py` | Deterministic report assembly; test with accumulated chain data |
| 12 | `session.py` | Add after both modes work end-to-end |
| 13 | `api/routes/explainability.py` — sync endpoint | Expose POST /explain |
| 14 | `api/routes/explainability.py` — async endpoint | Add POST /explain/async as a Celery task for large TRACE jobs |

---

## 13. Example Walkthroughs

### Simple single-variable question

> *"What is CE1CR0?"*

- **Phase 1:** Entity = `CE1CR0`, Intent = `explain_entity`, Depth = `surface`, Max rounds = 2
- **2a Index Round 1:** `resolve_entities(["CE1CR0"])` + `get_variable_profile("CE1CRA:5")` — parallel
- **2b Verify:** `verify_claim("xh71", 45, "CE1CR0")` — confirm declaration line in source
- **2c Gap-fill:** Not triggered (index returned a full profile)
- **Phase 3:** Synthesizes declaration, type, scope, where it appears; quotes source line 45 directly

---

### Multi-entity interaction question

> *"How do CE1CR0 and CE1CR1 interact within FINSUPP, and what triggers their modification?"*

- **Phase 1:** Entities = `[CE1CR0, CE1CR1, FINSUPP]`, Intent = `trace_multi_entity`, Depth = `deep`, Max rounds = 10
- **2a Round 1:** `resolve_entities(["CE1CR0","CE1CR1","FINSUPP"])` + `find_shared_files(["CE1CR0","CE1CR1","FINSUPP"])` — parallel
- **2a Round 2:** `get_variables_in_function("FINSUPP","ae48")` + `get_variable_modifiers("CE1CR0")` + `get_variable_modifiers("CE1CR1")` — parallel
- **2a Round 3:** `get_callers_of_function("FINSUPP","ae48")` — what triggers the call
- **2b Verify:** `verify_claim("ae48",1245,"ST")` + `verify_claim("xh71",88,"BAL")` — parallel; both confirmed
- **2b Source read:** `read_function_source("ae48","FINSUPP")` — full ordered instruction sequence; reveals the exact sequence in which CE1CR0 and CE1CR1 are set relative to each other
- **2b Comments:** `extract_comments_near("ae48",1238,5)` — retrieves `"* Set control flag for financial suppression"` which the index never captured
- **2c Gap-fill:** Not triggered (all entities resolved from index)
- **Phase 3:** Full explanation including the sequential modification order (not just individual hop entries), the business intent from the comment, and verified file:line citations

---

### Deep backward lineage question

> *"Trace the complete data flow into CASDB from all upstream sources."*

- **Phase 1:** Entity = `CASDB`, Intent = `backward_lineage`, Depth = `exhaustive`, Max rounds = 15
- **2a Round 1:** `resolve_entities(["CASDB"])` + `get_variable_profile`
- **2a Round 2:** `get_backward_lineage("CASDB","xh80",depth=5)`
- **2a Round 3:** For each upstream variable found in lineage: `get_variable_hops` — identifies the chain of writes
- **2b Verify:** `verify_claim` on the top 3 most upstream setter locations — one returns mismatch (stale index), logged as discrepancy
- **2b Source read:** `read_source_context` at each verified setter location to see surrounding instructions
- **2c Gap-fill:** One upstream variable (`INQCMN`) not found in identity index → `search_across_codebase("INQCMN")` finds it in `da76.asm:412` → `read_source_context("da76",412,15)` reads its initialization — added to accumulator as `tier2_only`
- **Phase 3:** Synthesizes the complete upstream dependency tree, flags the one discrepancy, flags the `tier2_only` upstream variable found only in source

---

### Full traceability — single entity

> *"Give me full traceability of CE1CR0."*

- **Phase 1:** Entity = `CE1CR0`, Intent = `full_traceability`, Mode = **TRACE**, Chain types = all
- **2a Round 1:** `resolve_entities(["CE1CR0"])` — establishes canonical `CE1CRA:5`
- **2a Round 2 (parallel):**
  - `enumerate_modification_chains("CE1CRA:5")` → 3 chains discovered
  - `enumerate_read_chains("CE1CRA:5")` → 7 chains discovered
  - `get_backward_lineage("CE1CRA:5","ae48",depth=5)` → 4-level tree built
  - `enumerate_forward_impact("CE1CRA:5")` → 6 impacted entities
  - `get_aliases("CE1CR0")` → 3 aliases: `CE1CRA:5`, `LG1CR0`, `5(,R9)`
  - `get_full_call_tree("FINSUPP","ae48","callers",depth=4)` + `get_full_call_tree("FINSUPP","ae48","callees",depth=3)` → full call tree
- **2b Verify (parallel):** `verify_claim` for the terminal site of each of the 10 chains — 10/10 confirmed
- **2b Source:** `read_source_context` at each of the 3 modification terminals to capture surrounding instructions + comments; `extract_comments_near` at each terminal
- **2c Gap-fill:** `LG1CR0` alias not in identity index → `search_across_codebase("LG1CR0")` → found in `da76.asm` → added as `tier2_only` alias
- **2d Cross-chain:** `R3` and `FINSUPP` found in multiple chains → recorded in `cross_chain_nodes`
- **2d Coverage:** 8 of 15 files covered; 2 gaps logged (xh90 depth exceeded)
- **Phase 3:** Deterministic `TraceabilityReport` assembled; batch LLM call generates one-sentence `business_summary` per chain (10 calls, cached); report written to disk and returned

---

### Full traceability — DSECT block

> *"Give me full traceability of the entire CE1CRA block."*

- **Phase 1:** Entity = `CE1CRA`, Intent = `block_traceability`, Mode = **TRACE**, Chain types = all
- **2a Round 1:** `get_block_contents("xh71","CE1CRA")` → 12 fields: CE1CR0 through CE1CRB
- **2a Round 2 (parallel for all 12 fields):** `enumerate_modification_chains` + `enumerate_read_chains` + `get_variable_profile` for each field — 12 parallel batches
- **2b Verify:** Sample verification across the 12 fields (up to 5 checks per field)
- **2c Gap-fill:** Any field not in identity index → `search_across_codebase` for that field name
- **2d Cross-chain:** Fields that appear together in the same modification chain noted (e.g., CE1CR0 and CE1CR1 both set in MC-001)
- **Phase 3:** Report assembled with one top-level section per field; each field has its own `modification`, `read`, `aliases` sub-sections; block-level `cross_chain_nodes` shows which fields co-appear in chains

---

### Full traceability — function

> *"Show me the complete end-to-end traceability report for FINSUPP."*

- **Phase 1:** Entity = `FINSUPP`, Intent = `call_tree_trace` + `full_traceability`, Mode = **TRACE**
- **2a Round 1:** `get_function_definition("FINSUPP","ae48")` + `resolve_entities(["FINSUPP"])`
- **2a Round 2 (parallel):**
  - `get_full_call_tree("FINSUPP","ae48","callers",depth=6)` → complete upstream caller tree
  - `get_full_call_tree("FINSUPP","ae48","callees",depth=4)` → complete downstream callee tree
  - `get_variables_in_function("FINSUPP","ae48")` → all variables in scope
- **2a Round 3:** For each variable inside FINSUPP: `enumerate_modification_chains` and `enumerate_read_chains` — gives per-variable chain report *scoped to FINSUPP's context*
- **2b Verify:** `read_function_source("ae48","FINSUPP")` — full ordered body for verification; `verify_claim` on each identified modification site
- **2c Gap-fill:** Any variable in function body not in identity index → `search_in_file("ae48", var_name)` for exact lines
- **2d Cross-chain + Coverage:** Variables that appear in multiple chains within FINSUPP noted; coverage of FINSUPP's variable set tracked
- **Phase 3:** Report structured as: call tree (in/out) → per-variable traceability within the function → cross-variable relationships within the function body

---

### Gap-filling scenario

> *"What does the DA7_CLEANUP routine do?"*

- **Phase 1:** Entity = `DA7_CLEANUP`, Intent = `explain_entity`, Depth = `medium`, Max rounds = 5
- **2a Round 1:** `resolve_entities(["DA7_CLEANUP"])` — returns empty (not in identity index)
- **2c Gap-fill Round 1:** `search_across_codebase("DA7_CLEANUP")` — finds `da76.asm:850`
- **2c Gap-fill Round 2:** `read_function_source("da76","DA7_CLEANUP")` — extracts full subroutine body (lines 850–920)
- **2c Gap-fill Round 3:** `extract_comments_near("da76",850,30)` — retrieves block-header comment describing the routine's purpose
- **Phase 3:** Full explanation of what the routine does, sourced entirely from raw source + comments since the parser never captured it; response clearly marked `tier2_only`

---

## 14. Scalability Analysis — 10M Lines / 50K Files

### 14.1 Baseline Measurements (1,400-file job)

All numbers measured from the running Docker job `13d3366f-5e92-4f13-9e4f-53b6a47bfbd3`.

| Artifact | Measured size | Key metric |
|---|---|---|
| `asm_variable_universe.json` | **108 MB** | 2,933 unique names, 139,910 entries |
| `variable_hop_index.json` | ~76 MB (est.) | 1,452 identities, **439,737 total hops** across 753 blueprints |
| `variable_identity_index.json` | 380 KB | 1,748 identities |
| `file_call_graph.json` | 660 KB | **1,438 nodes, 21,598 edges, 36,177 call sites** |
| `variable_modifier_index.json` | 16 KB | — |
| Blueprint files | **64.5 MB total**, 1,403 files | **46 KB average per blueprint** |

### 14.2 Projections at 50K Files (35.7× scaling factor)

| Artifact | 1,400 files | 50K files | Verdict |
|---|---|---|---|
| `asm_variable_universe.json` | 108 MB | **3.86 GB** | **BROKEN** — memory |
| `variable_hop_index.json` | ~76 MB | **~2.7 GB** | **BROKEN** — memory |
| `file_call_graph.json` | 660 KB | **23.6 MB + 771K edges** | **BROKEN** — DFS |
| Blueprint corpus | 64.5 MB | **2.3 GB, 50K files** | **BROKEN** — cache useless |
| `variable_identity_index.json` | 380 KB | **13.6 MB** | OK |
| `variable_modifier_index.json` | 16 KB | **571 KB** | OK |
| Per-blueprint file size | 46 KB avg | **46 KB avg** (unchanged) | OK |
| Hop entries total | 439,737 | **15.7 million** | **BROKEN** — LLM context |
| Call sites total | 36,177 | **1.29 million** | DFS concern |
| Variable entries in universe | 139,910 | **4.99 million** | **BROKEN** — memory |
| Source lines | ~100K est. | **10 million** | **BROKEN** — search |

### 14.3 The 7 Hard Breakpoints

#### Breakpoint 1 — Variable Universe (3.86 GB JSON, can't fit in memory)

`knowledge_base.py` loads the universe JSON into Python process memory at query time. The 108 MB version at 1,400 files already takes ~2 seconds to parse. At 3.86 GB this exhausts a typical worker's memory allocation before answering a single query. Even if memory were unlimited, JSON parse time for 4.99 million entries is ~40 seconds.

#### Breakpoint 2 — Hop Index (2.7 GB JSON, 15.7 million entries)

`_hop_index_cache` in `knowledge_base.py` is a module-level dict holding the entire hop index in process memory. At 2.7 GB that means one KB's hop index consumes the full worker. Beyond the memory problem: a variable appearing in 5,000 files has ~300,000 hop entries. The LLM context window holds roughly 50,000 tokens. The agent accumulator cannot distill 300,000 raw hop entries without a bounded sampling strategy.

#### Breakpoint 3 — Call Graph DFS on 771K edges

`_find_paths` builds an adjacency dict from the full call graph JSON on every request (no caching today). At 50K files: building the dict from a 23 MB JSON takes ~1 second per request. The DFS itself explores dead-end paths before finding valid ones. With branching factor ~15 (21,598 edges / 1,438 nodes) and a 51K-node graph, worst-case exploration before reaching `max_paths=100` can visit millions of intermediate states even with a path-length cap.

#### Breakpoint 4 — Blueprint LRU Cache Becomes Useless in TRACE Mode

The 256-entry LRU covers `256 / 50,000 = 0.5%` of blueprints. In EXPLAIN mode with targeted access to 5–20 files, the cache still works. In TRACE mode (`enumerate_modification_chains` visiting every modifier file for a popular variable), nearly every blueprint access is a cold miss. Loading 50K × 46 KB = 2.3 GB from disk sequentially for a single traceability request is not viable.

#### Breakpoint 5 — `search_across_codebase` on 10M Lines

A sequential file scan of 50K files is a linear pass over 10M lines of I/O. Even with `ThreadPoolExecutor` at 32 workers, wall time is 5–30 seconds depending on disk latency. This tool is the gap-filling fallback — it fires precisely when the system is already under stress (index miss). It is the worst possible moment for a slow operation.

#### Breakpoint 6 — Traceability Chain Explosion

A global control register present in 3,000 files, with 5 modification chains per file, yields 15,000 modification chains. Assembling the `TraceabilityReport` in memory — sorting, deduplicating, building the cross-chain node map — requires holding all 15,000 chain objects simultaneously. At ~500 bytes per chain record, that is 7.5 MB of chain objects alone. More critically, the LLM batch call for `business_summary` at 15,000 chains × 1 LLM call each is completely infeasible.

#### Breakpoint 7 — Backward Lineage `max_trace_nodes=5000` Floor

The backward lineage runner's default `max_trace_nodes=5000` was sized for small codebases. At 50K files, a non-trivial variable's backward graph can contain tens of thousands of nodes in the first two hops. The runner hits its limit immediately, returns a severely truncated result, and provides no signal about how much of the actual lineage tree was missed.

---

### 14.4 What Is Already Fine (no changes needed)

| Component | Why it scales |
|---|---|
| Identity index (13.6 MB at scale) | Fits in memory; O(1) hash lookup |
| Modifier index (571 KB at scale) | Trivially small |
| Per-blueprint size (46 KB avg) | Small; fast individual loads |
| Parallel tool execution (`ThreadPoolExecutor`) | Scales horizontally with worker count |
| Async endpoint (already designed) | Correct architecture for this scale |
| Accumulator compact design | Already bounded — never holds raw data |
| `msgpack` session persistence | Binary format, not JSON; scales fine |
| Blueprint file I/O per file | 46 KB is fast to load individually |

---

### 14.5 Required Changes — 7 Targeted Fixes

Each fix is scoped to the `explainability/` module or a new pipeline post-step. None require changes to the existing pipeline passes, analysis logic, or `knowledge_base.py` routes.

---

#### Fix 1 — Replace 3 Large JSON Indices with SQLite (pipeline post-step)

Add a new final step to the pipeline that converts the 3 large JSON outputs into indexed SQLite databases. All agent tools query SQLite instead of loading JSON. Runs once per pipeline execution.

```
variable_universe.db
  Table: variables
    (name TEXT, canonical_key TEXT, file TEXT, kind TEXT,
     scope TEXT, line INTEGER, data_type TEXT, metadata TEXT)
  Index on: (name), (canonical_key), (canonical_key, file)
  Query: SELECT * FROM variables WHERE name = ?   → microseconds at 5M rows

hop_index.db
  Table: hops
    (canonical_key TEXT, file TEXT, line INTEGER, expression TEXT,
     operation_type TEXT, relation TEXT, node_id TEXT, variable_name TEXT)
  Index on: (canonical_key), (canonical_key, operation_type), (canonical_key, file)
  Query: SELECT * FROM hops WHERE canonical_key = ? LIMIT 1000  → ms at 15M rows

call_graph.db
  Table: nodes  (id TEXT, type TEXT, file TEXT)
  Table: edges  (source TEXT, target TEXT, call_type TEXT, line INTEGER, file TEXT)
  Index on: edges(source), edges(target)
  Query: SELECT target FROM edges WHERE source = ?  → O(1) indexed scan
```

SQLite databases occupy 20–30% of equivalent JSON size on disk. At 50K files: `variable_universe.db` ≈ 800 MB, `hop_index.db` ≈ 600 MB, `call_graph.db` ≈ 5 MB. No file is loaded entirely into memory — SQLite pages only the accessed rows.

**Addresses:** Breakpoints 1, 2, 3 (call graph adjacency build).

---

#### Fix 2 — Blueprint Metadata Index (SQLite, pipeline post-step)

Add a `blueprint_meta.db` built by scanning all blueprint files during the post-step:

```
blueprint_meta.db
  Table: symbols
    (stem TEXT, symbol_name TEXT, kind TEXT,
     line_start INTEGER, line_end INTEGER, scope TEXT)
  Index on: (symbol_name), (stem, symbol_name), (stem, kind)
```

Agent tools (`get_function_definition`, `get_variables_in_function`, `get_block_contents`) query this index for symbol lookup without loading any blueprint file. The full blueprint is only read when the agent explicitly needs source content — approximately 10–20% of tool calls. The existing LRU cache is retained but repurposed: it holds blueprints fetched during the current request, not pre-warmed entries.

**Addresses:** Breakpoint 4.

---

#### Fix 3 — BFS Path-Finding with Cached Adjacency Dict

Two changes to the call path tool:

1. **BFS replaces DFS** in `get_call_paths`. BFS with a `max_depth` limit explores level by level and prunes entire subtrees immediately when depth is exceeded. It returns the `max_paths` shortest paths — which is exactly what the agent wants (most direct chains). DFS finds deep paths first (often irrelevant long chains) and can explore exponential dead-end branches.

2. **Module-level adjacency dict cache** in `graph_tools.py`, built once from `call_graph.db` and reused across requests. At 50K files the adjacency dict is approximately `771K entries × 100 bytes ≈ 77 MB` — acceptable as a process-level singleton. Invalidated when the KB output directory mtime changes.

**Addresses:** Breakpoint 3.

---

#### Fix 4 — Source Full-Text Search Index (SQLite FTS5, pipeline ingest step)

Add `source_fts.db` built during pipeline ingest — when source files are first scanned, before analysis runs:

```
source_fts.db
  Virtual Table: source_lines (FTS5)
    stem TEXT, line_number INTEGER, content TEXT
  Query: SELECT stem, line_number, content
         FROM source_lines
         WHERE source_lines MATCH 'CE1CR0'
         LIMIT 200
  Execution: <50ms for 10M lines (SQLite FTS5 uses inverted index)
```

`search_across_codebase` and `search_in_file` route to this index instead of scanning files. SQLite FTS5 index for 10M lines occupies approximately 200–400 MB on disk. `extract_comments_near` still reads raw source (targeted, few lines) — no change needed there.

**Addresses:** Breakpoint 5.

---

#### Fix 5 — Hard Pagination on All List-Returning Tools + LLM Sampling Cap

Every tool that returns a list of results gets two new parameters: `limit` (default 50, max 500) and `cursor` (opaque keyset string for continuation). The tool always returns `total_count` alongside the page.

The accumulator enforces an additional cap independent of tool pagination: it never stores more than 100 entries per field in the compact summary shown to the LLM. If `total_count > 100`, it samples by file diversity — one representative entry per file — and appends:

```
"showing 100 of 30,247 hops across 5,000 files — use cursor to page"
```

This cap is enforced at the accumulator layer. The full data is always queryable through paginated tool calls; the LLM sees only a bounded view.

**Addresses:** Breakpoint 2 (LLM context), Breakpoint 6 (chain count).

---

#### Fix 6 — TRACE Mode: Streaming Report Assembly + Always Async

Two changes to `tracer.py` and `report.py`:

1. **Streaming assembly**: The report file is opened at the start of Phase 2 and chain records are written incrementally as each `enumerate_*` call completes. The total in-process state is bounded to one page of chain records at a time. For the LLM batch `business_summary` call: batched at 50 chains per LLM call, not one call per chain.

2. **Always async**: All TRACE requests are routed through `POST /explain/async` regardless of depth. The synchronous `POST /explain` endpoint rejects TRACE-mode intents with `HTTP 303` redirecting to the async endpoint. The async response is:
```json
{ "job_id": "...", "poll_url": "...", "report_url": "..." }
```
The report is written to `{kb_id}/output/traceability/{report_id}.json` and served via the existing `GET /v1/knowledge-bases/{kb_id}/files/` endpoint.

**Addresses:** Breakpoint 6.

---

#### Fix 7 — Dynamic Lineage Budget Based on Codebase Size

Replace the fixed `max_trace_nodes=5000` with a dynamic limit derived from the KB's file count, stored in the KB metadata at pipeline completion:

```python
def _lineage_budget(total_files: int) -> int:
    if total_files <  5_000: return 5_000
    if total_files < 20_000: return 2_000
    if total_files < 50_000: return 1_000
    return 500
```

The backward lineage response gains two new fields: `budget_consumed_pct` (0–100) and `budget_exhausted` (bool). When `budget_exhausted` is true, the response includes `depth_at_cutoff` and an `open_thread` suggesting a narrower re-query (single source file, lower `max_dep_vars`).

**Addresses:** Breakpoint 7.

---

### 14.6 Optional: Chain Pre-Materialization (pipeline post-step)

For the top 20% of variables by hop frequency (those appearing in the most files), pre-compute and persist their full chain sets as part of the pipeline post-step:

```
{kb_id}/output/materialized_chains/{canonical_key}.msgpack
```

Each file contains pre-built modification chains, read chains, and alias map for that identity. `tracer.py` checks for a materialized file before computing chains. For hot variables this reduces TRACE mode response time from minutes to seconds.

This is optional at the 1,400-file scale but becomes necessary at 50K files for any variable present in more than ~500 files.

---

### 14.7 Post-Step Architecture

The existing pipeline ends at Step 6. A new **Step 7: Index Build** runs once after all analysis is complete and produces the queryable index layer.

```
Pipeline Steps (updated):
  Step 1  — Universe building
  Step 2  — Orchestrated analysis (phases 1–5)
  Step 2.5 — Business summaries (optional)
  Step 3  — Backward lineage
  Step 4  — Chain summaries
  Step 5  — Modifier tracking
  Step 6  — Final aggregation / export
  Step 7  — Index build (NEW)
              source_fts.db       ← from job input files
              variable_universe.db ← from asm/cpp_variable_universe.json
              hop_index.db        ← from variable_hop_index.json
              call_graph.db       ← from file_call_graph.json
              blueprint_meta.db   ← from all *.asm.json / *.cpp.json blueprints
              materialized_chains/ ← top-20% variables by hop frequency (optional)
```

Step 7 is resumable (each sub-task checks if its output file already exists before rebuilding) and incremental (if a pipeline re-run only updates some blueprints, only those blueprints are re-ingested into `blueprint_meta.db`).

The explainability module detects whether Step 7 has been run by checking for `variable_universe.db`. If the SQLite files are absent (older KB, or Step 7 was skipped), it falls back to the current JSON loading approach with a warning in the response: `"Large-codebase indices not built — queries may be slow. Re-run pipeline with index_build=true to enable scalable mode."`

---

### 14.8 Summary: Scale Tiers

| Codebase size | What works as-is | What requires Fix |
|---|---|---|
| < 5K files | Everything | Nothing |
| 5K–20K files | EXPLAIN mode fully | Fix 7 (lineage budget); Fix 1 optional |
| 20K–50K files | EXPLAIN surface/medium | All 7 fixes required |
| 50K+ files | Nothing without changes | All 7 fixes + pre-materialization |
