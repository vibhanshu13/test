# Dependent Variable Filtering Rules

Rules applied in `_is_dep_var_candidate()` (`trace_cross_file_lineage.py`) to decide whether a raw instruction operand token qualifies as a `dependent_variable` in graph nodes.

Applied at all five dep_var extraction sites:
- `_build_backward_call_graph` — primary lineage_graph path
- `_build_backward_call_graph` — fallback guard_conditions path
- `_build_modifier_graph` — `add_dep_vars` inner helper
- `_build_forward_usage_graph` — `_dep_vars_from_args` inner helper (downstream usage-only files)
- `_build_dep_var_trace_graph` — dep-var-of-dep-var tracing

---

## Active Filters

### 1. Standard registers (R0–R15)
**What it catches:** `R0`, `R1`, ..., `R15`  
**Rule:** token is in `REGISTERS = {f"R{i}" for i in range(16)}`  
**HLASM basis:** z/Architecture general-purpose registers. These are the first operand of instructions like `C R5,FIELD` and must never be treated as storage variables.

---

### 2. Register alias patterns
**What it catches:** `RGA`, `RGB`, `RGC`, `RGD`, `RA`, `RB`, `R28`, `R32`, `R46`, etc.  
**Rule (letter-suffix):** `^R[A-Z][A-Z0-9]{0,1}$` — e.g., RGA, RGB, RGC, RA, RB  
**Rule (high-number):** `^R\d+$` where the number > 15 — e.g., R28, R32, R46  
**HLASM basis:** Programs commonly define register equates (`RGB EQU 2`). These follow the naming convention of `R` + 1–2 letter characters, or numeric aliases beyond the 16-register range. Confirmed in `lu82.asm` (`C RGB,LU82(RGA)`) and blueprint data_flow (`"id": "register:RGB"`).

---

### 3. Indexed address bases
**What it catches:** The base symbol in `SYMBOL(Rx)` or `SYMBOL(Rx,Ry)` addressing  
**Rule:** Check the raw operand **before** `normalize_token` strips `(...)`. If the content inside `()` matches a register (Rules 1 or 2), skip the whole arg.  
**HLASM basis:** `C RGB,LU82(RGA)` — `LU82` is a table base address used with index register `RGA`. After normalization, `LU82(RGA)` → `LU82`, which would otherwise pass all other filters. `LU82` here is a structural label (defined as `DS 0F`), not a data variable.  
**Safe case (not filtered):** `MVC WK_FIELD(5),SOURCE` — `(5)` is a length specifier, not a register. `5` fails the register test → `WK_FIELD` is correctly kept.

---

### 4. Self-defining term fragments
**What it catches:** `C'A`, `X'FF`, `P'-2`, `H'1`, `C'99`, `X'00`, etc.  
**Rule:** `"'" in tok` — after normalization, if the token still contains a single quote  
**HLASM basis:** `normalize_token` strips the trailing `'` from literals like `C'A'` → `C'A` (the `'A'` interior remains). HLASM symbol names **cannot legally contain `'`** — so any post-normalization token with `'` is always a literal fragment, never a valid variable name.  
**Examples from codebase:** `CLI HUBTXN,C'A'`, `CLI WK_TMPLIM,C'Y'`, `CLC EBW000(2),=C'99'`, `CLI 0(R14),C'A'` across da78, xh71, xh72, xh80, xh87, xh88.

---

### 5. Displacement-only tokens (pure digits)
**What it catches:** `0`, `1`, `6`, `7`, `8`  
**Rule:** `tok.isdigit()`  
**HLASM basis:** `CLI 0(R14),C'A'` — `0(R14)` is a base-register address (displacement=0, base=R14). `normalize_token` splits on `(` → `0`. HLASM symbol names **cannot start with a digit** — pure numeric tokens are always displacements or self-defining terms, never storage variable names.  
**Examples from codebase:** da78.asm `CLI 0(R14),...` sequences (lines 1813–1841).

---

### 6. EQU constants with `#`
**What it catches:** `WB#OTB`, `WB#M1NFND`, `LG#C400`, `#RTNGOOD`, etc.  
**Rule:** `"#" in tok`  
**HLASM basis:** Assembler EQU constants for bit masks and byte offsets use `#` as a naming convention in this codebase (e.g., `TM WB1SW1,WB#OTB`). These are fixed constants, not storage variables. HLASM allows `#` in symbol names but it's reserved here for EQU constants.

---

### 7. The traced variable itself
**What it catches:** The variable currently being traced (e.g., `LG1OSI` when tracing LG1OSI lineage)  
**Rule:** `tok == skip_var.upper()`  
**Rationale:** Prevents circular self-reference in dep_var lists.

---

### 8. Invalid HLASM symbol pattern
**What it catches:** `BAD=DA7_TRT9`, `AREA=WB1DBWD1`, `REGR=R1`, residual `(` after normalization  
**Rule:** after normalization, `not re.match(r'^[A-Z@$_][A-Z0-9@$_]*$', tok)`  
**HLASM basis:** Legal HLASM symbol names start with `A-Z`, `@`, `$`, or `_` and contain only alphanumerics plus `@`, `$`, `_`. Macro keyword arguments (`KEY=VALUE`) and displacement expressions (`BASE+OFFSET`) are not symbol names.  
**Examples:** `BAD=DA7_TRT9` (TRTSA macro keyword arg in da76.asm), `AREA=WB1DBWD1` (TIMEC macro in xh85.asm), `REGR=R1` (GLOBZ macro in xh96.asm).

---

### 9. Literal address constants
**What it catches:** `=Y(LM1OAMC_F)`, `=Y(LM1OASE_F)`, `=X'000C'`, `=A(...)`  
**Rule:** `raw.startswith('=')`  
**HLASM basis:** Operands beginning with `=` are literal address constants assembled inline by the assembler. They are never storage variable names.  
**Examples from codebase:** `=Y(LM1TSPC_F)` (da78.asm line 1634), `=Y(#CR21LA7-L'CR21GLDTBLK)` (xh90.asm).

---

### 10. DC-defined constants (blueprint-driven)
**What it catches:** `ZEROS`, `BLANKS`, `PKDZERO`, `HEXFF`, `CHARF`, `WCT`, `CZEROS`, `SPACES`  
**Rule:** symbol's `type == "dc"` in the file's `.asm.json` blueprint symbol table  
**HLASM basis:** Symbols defined with `DC` (Define Constant) provide fixed fill values. In `CLC WK_RRC,ZEROS`, `ZEROS` is a padding constant (`DC 15C'0'`), not a data variable. Filtering these removes noise from the dep_var list while keeping the comparison partner (`WK_RRC`) visible.  
**Note:** `DS`-defined symbols are NOT filtered — `DS` defines working storage fields which are genuine variables.  
**Activation:** Requires blueprint regeneration after `symbol_parser.py` changes to emit `type: "dc"` entries.

---

## Known Intentional Inclusions

- **`WCT`** — previously listed here; now filtered via Rule 10 (DC-defined constant in xh80.asm).
