# README: ASM Guard Truncation & False Unconditional Setters

This document details the issue and fix introduced in commit `ed9e8a08b5628c8d4283d9e9e98181c5b76763bc` to prevent false unconditional setter classifications caused by CFG depth-capping.

## One-Line Issue Summary
CFG depth-capping silently dropped deep dominator guards for assembly setters, leading the tracing engine to incorrectly report them as unconditionally executed (false unconditional).

---

## Symptoms & Impact
During backward lineage tracing, the engine analyzes control flow paths. If an assembly setter is conditional but its gating condition resides in an upstream dominator block whose distance from the setter is greater than the depth cap (`max_levels`), the guard is not collected. 

Without this fix:
- The engine received an empty or partial list of conditions for the path.
- The engine concluded that the setter was unconditionally executed (`unconditionalAtSetter`), resulting in false positives.

---

## Solution & Implementation Details
To prevent these false positives, the tracing flow was modified to track and surface when a path's dominators are truncated by the depth limit:

1. **Detection of Truncation in [asm_conditions.py](file:///Users/prathamgupta/Documents/asm-modernizer/vbt/conditions/asm_conditions.py)**
   - The [collect_asm_conditions](file:///Users/prathamgupta/Documents/asm-modernizer/vbt/conditions/asm_conditions.py#L467) function now returns a tuple `(conditions, truncated)`.
   - `truncated` is set to `True` if any dominator block was omitted solely because its BFS depth exceeded `max_levels`.

2. **Flagging Dependent Variables in [recurse.py](file:///Users/prathamgupta/Documents/asm-modernizer/vbt/depvars/recurse.py)**
   - The [_emit_setter_run](file:///Users/prathamgupta/Documents/asm-modernizer/vbt/depvars/recurse.py#L699) function checks the truncation flag. If truncated, the entry is annotated with `"pathsCapped": True` to signal that its condition list is incomplete.

3. **Propagating in Engine Traces in [engine.py](file:///Users/prathamgupta/Documents/asm-modernizer/vbt/engine.py)**
   - The [trace_root_variable](file:///Users/prathamgupta/Documents/asm-modernizer/vbt/engine.py#L1059) function aggregates the local truncation status `local_trunc` as part of the `incomplete` flag. This ensures the tracing engine recognizes that path conditions were capped, avoiding the false "unconditional" verdict.

---

## Verification
A dedicated test suite [test_asm_guard_truncation.py](file:///Users/prathamgupta/Documents/asm-modernizer/vbt/tests/test_asm_guard_truncation.py) was added to verify:
- Deep dominator guards past the cap are correctly dropped.
- The `truncated` status is correctly reported as `True` when drop occurs, and `False` otherwise.
