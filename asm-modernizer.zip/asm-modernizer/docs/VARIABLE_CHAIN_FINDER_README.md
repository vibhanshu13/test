# Variable Chain Finder — Implementation Guide

Traces all paths a variable takes from a **source file** to a **target file** across
a multi-file HLASM/C++ codebase, with per-hop details: file name, line number,
instruction expression, operation type, and any variable renaming at each hop.

---

## Table of Contents

1. [Overview](#1-overview)
2. [Full System Architecture](#2-full-system-architecture)
3. [Pipeline Steps — Status Summary](#3-pipeline-steps--status-summary)
4. [Steps 1–5: Already Implemented](#4-steps-15-already-implemented)
5. [Step 6: Variable Hop Index (NOT YET IMPLEMENTED)](#5-step-6-variable-hop-index-not-yet-implemented)
6. [Query Algorithm — Implementation Status](#6-query-algorithm--implementation-status)
7. [Output Structure](#7-output-structure)
8. [Scalability Design (10K files / 10M LOC)](#8-scalability-design-10k-files--10m-loc)
9. [Implementation Steps — What Needs to Be Built](#9-implementation-steps--what-needs-to-be-built)
10. [API Endpoint](#10-api-endpoint)
11. [Data Flow Diagram](#11-data-flow-diagram)

---

## 1. Overview

**Input:**
```json
{
  "variable":    "WB1ACCTC",
  "source_file": "xh80",
  "target_file": "xh87"
}
```

**Output:** All chains (paths through the call graph) through which the variable
flows from `source_file` to `target_file`, with full per-hop detail:

```json
{
  "canonical_key": "CE1CRA:35",
  "canonical_identity": {
    "access_identity":  "CE1CRA:35",
    "symbolic_identity":"WB1WB:WB1ACCTC",
    "dsect":            "WB1WB",
    "field_offset":      35
  },
  "chains": [
    {
      "path": ["xh80", "xh71", "xh87"],
      "resolved": true,
      "hops": [
        {
          "file": "xh80",
          "variable_name": "WB1ACCTC",
          "resolution_strategy": "origin",
          "occurrences": [
            { "line": 245, "expression": "L R5,WB1ACCTC(,R8)", "operation_type": "load"    },
            { "line": 312, "expression": "CLC WB1ACCTC,=C'AMEX'", "operation_type": "compare" }
          ]
        },
        {
          "file": "xh71",
          "variable_name": null,
          "resolution_strategy": "bridge_file",
          "occurrences": []
        },
        {
          "file": "xh87",
          "variable_name": "WB1ACCTC",
          "resolution_strategy": "Access Identity Match",
          "occurrences": [
            { "line": 178, "expression": "MVC WB1ACCTC,WORKACCT", "operation_type": "move",
              "transformation": "WORKACCT → WB1ACCTC" }
          ]
        }
      ]
    }
  ]
}
```

---

## 2. Full System Architecture

```
═══════════════════════════════════════════════════════════════════════════
  OFFLINE  (pipeline — runs once when a Knowledge Base is created)
═══════════════════════════════════════════════════════════════════════════

  Step 1   Universe build          →  asm_variable_universe.json      ✅ DONE
  Step 2   Full analysis           →  <file>.asm.json  blueprints     ✅ DONE
  Step 2.5 Enrich access_identity  →  blueprints updated in-place     ✅ DONE (fixed)
  Step 3   Call graph              →  file_call_graph.json            ✅ DONE
  Step 4   Modifier index          →  variable_modifier_index.json    ✅ DONE
  Step 5   Identity index          →  variable_identity_index.json    ✅ DONE (fixed)
  Step 6   Hop index               →  variable_hop_index.json         🔲 TODO (new)

═══════════════════════════════════════════════════════════════════════════
  ONLINE   (query — runs on each API request)
═══════════════════════════════════════════════════════════════════════════

  Input: variable + source_file + target_file
        │
        ▼
  Step A  Identity lookup         O(1)   in identity_index["by_name"]    ✅ DONE
        │  → canonical_key, var_files
        ▼
  Step B  Filtered subgraph       O(|var_files|²)                         🔲 TODO
        │  → sub-graph of only the files that contain this variable
        ▼
  Step C  DFS on subgraph         fast   (5–50 nodes instead of 10K)     ✅ DONE (basic)
        │  → list of paths [ [f1,f2,f3], [f1,f4,f3], … ]
        ▼
  Step D  Hop detail assembly     O(1) per hop from hop_index            🔲 TODO
        │  → attach occurrences (line, expression, operation_type, …)
        ▼
  Step E  Return JSON chains                                              🔲 TODO (enriched format)
```

---

## 3. Pipeline Steps — Status Summary

| Step | Script | Output file | Purpose | Status |
|------|--------|-------------|---------|--------|
| 1 | `universe_builder.py` | `asm_variable_universe.json` | Discover all variables across the codebase | ✅ DONE |
| 2 | `main.py` | `<stem>.asm.json` blueprints | Per-file lineage graph (nodes + edges with line numbers, expressions, operation_type) | ✅ DONE |
| 2.5 | `passes/cross_file_access_identity.py` | blueprints updated | Enrich edges with L1 `access_identity`, L2 `symbolic_identity`, L4 `file_label` | ✅ DONE (bugs fixed) |
| 3 | `file_call_graph.py` | `file_call_graph.json` | Directed call graph: fileA → fileB means A transfers control to B | ✅ DONE |
| 4 | `build_modifier_index.py` | `variable_modifier_index.json` | Inverted index: variable → files that set it | ✅ DONE |
| 5 | `build_variable_identity_index.py` | `variable_identity_index.json` | Canonical key per variable, cross-file file list | ✅ DONE (bugs fixed) |
| 6 | `build_variable_hop_index.py` | `variable_hop_index.json` | Per-key line-level occurrence list for O(1) hop detail lookup | 🔲 TODO |

**Additional components:**

| Component | Status |
|-----------|--------|
| 7-strategy cross-file variable resolver (`get_equivalent_variable.py`) | ✅ DONE |
| Basic `POST /{kb_id}/variable-flow` endpoint (path finding, simple hops, no line details) | ✅ DONE |
| `_build_filtered_subgraph()` in `knowledge_base.py` | 🔲 TODO |
| Enriched hops with `occurrences` (line, expression, operation_type) | 🔲 TODO |
| New `POST /{kb_id}/variable-chains` endpoint (full detail output) | 🔲 TODO |

---

## 4. Steps 1–5: Already Implemented

All pipeline steps 1–5 are complete and integrated into `pipeline_task.py`.

### Identity Index Structure (Step 5 output — already built)

```json
{
  "_meta": { "unique_identities": 1748, "unique_names": 1674 },

  "by_name": {
    "WB1ACCTC": "CE1CRA:35",
    "WB1SUPP":  "CE1CRA:65",
    "LG1OSI":   "CE1CR0:28"
  },

  "by_identity": {
    "CE1CRA:35": {
      "names":              ["WB1ACCTC"],
      "access_identity":    "CE1CRA:35",
      "symbolic_identity":  "WB1WB:WB1ACCTC",
      "dsect":              "WB1WB",
      "field_offset":        35,
      "file_label":         null,
      "files": {
        "xh80": "memory:WB1ACCTC",
        "xh87": "memory:WB1ACCTC"
      }
    }
  }
}
```

**Identity tiers (strongest → weakest):**

| Tier | Field | Example | Meaning |
|------|-------|---------|---------|
| L1 | `access_identity` | `CE1CRA:35` | ECB-resident field — architecture-constant, survives register renaming |
| L2 | `symbolic_identity` | `WB1WB:WB1ACCTC` | DSECT:FIELD name — cross-file stable |
| L4 | `file_label` | `da76:STATCODE` | File-scoped local variable — cannot cross files by identity alone |

### Bugs fixed in this session

**`passes/cross_file_access_identity.py`**
- Pass 1: Added plain-label fallback — when a node is `memory:TOT_LEN` (not `memory:RESPONSE:TOT_LEN`) but the edge carries `dsect=RESPONSE`, now correctly derives `symbolic_identity=RESPONSE:TOT_LEN` by checking the DSECT field table.
- Pass 2: Fixed the skip guard — DSECT edges that had no `symbolic_identity` after Pass 1 now correctly fall through to get L4 `file_label` assignment instead of being silently skipped.

**`build_variable_identity_index.py`**
- Added `_is_noise_node()` to filter numeric literals (`memory:0`, `memory:-1`), register names (`memory:R0`…`memory:R15`), literal pool refs (`memory:=F'0'`), and synthetic `@` nodes.
- Added `_symbolic_field_matches_node()` to detect wrong-DSECT-context assignments — avoids `WB1ACCTC` getting canonical key `CE1CRA:5` (from `LG1G1:LG1ACT`) instead of the correct `CE1CRA:35`.

**Result:** 0% name-only fallback (was 5%), 0 noise entries (was 236), all variables correctly identified.

---

## 5. Step 6: Variable Hop Index (NOT YET IMPLEMENTED)

### Purpose

Pre-compute, for every canonical key and every file that contains it, **all
the line-level occurrences** (line number, ASM instruction, operation type,
transformation, relation type). This removes the need to scan blueprints at
query time.

### Output file: `variable_hop_index.json`

```json
{
  "_meta": {
    "built_at":     "2026-05-08T08:00:00Z",
    "blueprints_scanned": 15,
    "unique_keys":  198,
    "total_hops":   8423
  },

  "CE1CRA:35": {
    "xh80": [
      {
        "line":           245,
        "expression":     "L R5,WB1ACCTC(,R8)",
        "operation_type": "load",
        "transformation": "WB1ACCTC loaded into R5",
        "relation":       "assign",
        "node_id":        "memory:WB1ACCTC",
        "variable_name":  "WB1ACCTC"
      },
      {
        "line":           312,
        "expression":     "CLC WB1ACCTC,=C'AMEX'",
        "operation_type": "compare",
        "relation":       "use",
        "node_id":        "memory:WB1ACCTC",
        "variable_name":  "WB1ACCTC"
      }
    ],
    "xh87": [
      {
        "line":           178,
        "expression":     "MVC WB1ACCTC,WORKACCT",
        "operation_type": "move",
        "transformation": "WORKACCT → WB1ACCTC",
        "relation":       "assign",
        "node_id":        "memory:WB1ACCTC",
        "variable_name":  "WB1ACCTC"
      }
    ]
  },

  "CE1CRA:65": {
    "xh80": [ ... ],
    "xh71": [ ... ],
    "xh72": [ ... ]
  }
}
```

### Build algorithm (`build_variable_hop_index.py`)

```
for each blueprint  <stem>.asm.json  in blueprint_dir:

    load blueprint
    load variable_lineage.edges

    for each edge in edges:
        node_id = edge.source  (or target for "use" edges)
        if node_id.kind not in MEMORY_KINDS:  skip

        # Look up canonical key from identity index
        leaf_name  = extract_leaf_name(node_id)          # "WB1ACCTC"
        canon_key  = identity_index["by_name"].get(leaf_name.upper())
        if canon_key is None:  skip  (not a tracked variable)

        hop = {
            "line":           edge.line,
            "expression":     edge.expression,
            "operation_type": edge.operation_type,
            "transformation": edge.transformation,
            "relation":       edge.relation,
            "node_id":        node_id,
            "variable_name":  leaf_name
        }

        hop_index[canon_key][file_stem].append(hop)

deduplicate hops by (line, relation) within each file
write  variable_hop_index.json
```

**Complexity:** O(total_edges) — single pass over all blueprints. For 10K files
with ~2,500 edges each → ~25M edge operations, completes in minutes.

### Integration into pipeline (`pipeline_task.py`)

```python
# Step 6 — build variable hop index for detailed chain queries
print("=== Step 6/6: Building variable hop index ===")
_build_variable_hop_index(ws)
```

---

## 6. Query Algorithm — Implementation Status

### Step A — Identity lookup  ✅ DONE

```python
canonical_key  = identity_index["by_name"][variable.upper()]
# e.g. "CE1CRA:35"

identity_entry = identity_index["by_identity"][canonical_key]
var_files      = set(identity_entry["files"].keys())
# e.g. {"xh80", "xh87"}

canonical_identity = {
    "access_identity":   identity_entry["access_identity"],
    "symbolic_identity": identity_entry["symbolic_identity"],
    "dsect":             identity_entry["dsect"],
    "field_offset":      identity_entry["field_offset"],
}
```

### Step B — Build variable-filtered subgraph  🔲 TODO

The call graph has 10K nodes at scale. Most variables exist in 5–50 files.
DFS on the full graph explores irrelevant paths. Pruning to relevant files
reduces DFS space by 100–1000×.

```python
relevant_files = var_files | {source_file, target_file}

# Keep only call-graph edges where BOTH endpoints are in relevant_files
subgraph = {
    node: [
        (neighbor, inst)
        for (neighbor, inst) in full_forward_adj[node]
        if neighbor in relevant_files
    ]
    for node in relevant_files
    if node in full_forward_adj
}
```

> **Note:** A file NOT in `var_files` but on the call-graph path between
> source and target is a **bridge file** — the variable passes through the
> call boundary but is not referenced inside it. The subgraph filter
> naturally handles this: if the DFS reaches a file where the variable is
> absent, that hop is marked `"resolution_strategy": "bridge_file"` in the
> output.

### Step C — DFS all simple paths on subgraph  ✅ DONE (basic, unfiltered)

Currently implemented in `knowledge_base.py` but runs on the full call graph.
Needs to be switched to the filtered subgraph from Step B.

```python
def find_paths(source, target, subgraph, max_path_length=15, max_paths=100):
    """DFS with visited-set pruning. O(paths) on the small subgraph."""
    collected = []

    def dfs(node, path, visited):
        if len(collected) >= max_paths:  return
        if node == target:
            collected.append(list(path));  return
        if len(path) >= max_path_length:  return
        for neighbor, _ in subgraph.get(node, []):
            if neighbor not in visited:
                visited.add(neighbor)
                path.append(neighbor)
                dfs(neighbor, path, visited)
                path.pop()
                visited.remove(neighbor)

    dfs(source, [source], {source})
    return collected
```

### Step D — Hop detail assembly  🔲 TODO

Currently hops are returned without line-level `occurrences`. After building
the hop index (Step 6), each hop can be enriched in O(1):

```python
for path in paths:
    hops = []

    for i, file_stem in enumerate(path):
        if file_stem in var_files:
            # Variable is present in this file — fetch detail from hop index
            occurrences = hop_index.get(canonical_key, {}).get(file_stem, [])

            # Determine resolution strategy using 7-strategy resolver
            if i == 0:
                strategy = "origin"
            else:
                strategy = resolve_strategy(prev_node, file_stem, identity_entry)

            hops.append({
                "file":                file_stem,
                "variable_name":       occurrences[0]["variable_name"] if occurrences else None,
                "node_id":             identity_entry["files"][file_stem],
                "resolution_strategy": strategy,
                "occurrences":         occurrences,
            })
        else:
            # Bridge file — variable passes through call boundary, not referenced here
            hops.append({
                "file":                file_stem,
                "variable_name":       None,
                "node_id":             None,
                "resolution_strategy": "bridge_file",
                "bridge_type":         "call_boundary",
                "occurrences":         [],
            })
```

### 7-Strategy resolver  ✅ DONE (in `get_equivalent_variable.py`)

Used in Step D to assign `resolution_strategy` per hop:

| Priority | Strategy | Trigger |
|----------|----------|---------|
| 1 | Parameter Bridge | `caller_param` relation from previous file |
| 2 | Access Identity Match | `access_identity` matches (e.g. `CE1CRA:35`) |
| 3 | Symbolic Identity Match | `symbolic_identity` matches (e.g. `WB1WB:WB1ACCTC`) |
| 4 | ECB Field Match | `ecb_field` name matches |
| 5 | Direct Name Match | Same variable name + physical identity confirmed |
| 6 | DSECT + Offset | Same DSECT + byte offset |
| 7 | Global Alias / Bridge | `alias`, `assign`, `bridge` relation in global lineage |

---

## 7. Output Structure

Full JSON response schema:

```json
{
  "variable":    "WB1ACCTC",
  "source_file": "xh80",
  "target_file": "xh87",

  "canonical_key": "CE1CRA:35",
  "canonical_identity": {
    "access_identity":   "CE1CRA:35",
    "symbolic_identity": "WB1WB:WB1ACCTC",
    "dsect":             "WB1WB",
    "field_offset":       35
  },

  "total_paths_found": 2,
  "resolved_count":    1,

  "chains": [
    {
      "chain_id": 1,
      "path":     ["xh80", "xh87"],
      "resolved": true,
      "hops": [
        {
          "file":                "xh80",
          "variable_name":       "WB1ACCTC",
          "node_id":             "memory:WB1ACCTC",
          "resolution_strategy": "origin",
          "occurrences": [
            {
              "line":           245,
              "expression":     "L R5,WB1ACCTC(,R8)",
              "operation_type": "load",
              "transformation": "WB1ACCTC loaded into R5",
              "relation":       "assign"
            },
            {
              "line":           312,
              "expression":     "CLC WB1ACCTC,=C'AMEX'",
              "operation_type": "compare",
              "relation":       "use"
            }
          ]
        },
        {
          "file":                "xh87",
          "variable_name":       "WB1ACCTC",
          "node_id":             "memory:WB1ACCTC",
          "resolution_strategy": "Access Identity Match",
          "occurrences": [
            {
              "line":           178,
              "expression":     "MVC WB1ACCTC,WORKACCT",
              "operation_type": "move",
              "transformation": "WORKACCT → WB1ACCTC",
              "relation":       "assign"
            }
          ]
        }
      ]
    }
  ],

  "unresolved_chains": [
    {
      "chain_id": 2,
      "path":     ["xh80", "xh71", "xh83", "xh87"],
      "resolved": false,
      "failure_at": "xh71",
      "hops": [...]
    }
  ],

  "warnings": []
}
```

### Hop fields reference

| Field | Type | Description |
|-------|------|-------------|
| `file` | string | File stem (e.g. `"xh80"`) |
| `variable_name` | string\|null | Name of the variable in this file (may differ from input due to renaming) |
| `node_id` | string\|null | Full node identifier (e.g. `"memory:WB1ACCTC"`) |
| `resolution_strategy` | string | How the variable was matched at this hop |
| `bridge_type` | string\|null | `"call_boundary"` if file is a bridge (variable absent here) |
| `occurrences[].line` | int | Source line number |
| `occurrences[].expression` | string | ASM instruction (e.g. `"L R5,WB1ACCTC(,R8)"`) |
| `occurrences[].operation_type` | string | `load`, `store`, `move`, `compare`, `arithmetic`, `logical`, `initialize`, `call_arg` |
| `occurrences[].transformation` | string\|null | Human-readable description of what happens to the variable |
| `occurrences[].relation` | string | `define`, `assign`, `use`, `alias`, `arg_bind` |

---

## 8. Scalability Design (10K files / 10M LOC)

### Memory budget

| Component | Size (10K files) | Load strategy |
|-----------|-----------------|---------------|
| Identity index (`variable_identity_index.json`) | ~250 MB | Loaded at worker startup, stays in memory |
| Call graph (`file_call_graph.json`) | ~100 MB | Loaded at worker startup, stays in memory |
| Hop index (`variable_hop_index.json`) | ~200 MB | Loaded at worker startup, OR streamed per key |
| Blueprint LRU cache | 256 × 2 MB = 512 MB cap | Lazy load, evict LRU |
| **Total at startup** | **~1.1 GB** | Within 16 GB machine budget |

### Why the filtered subgraph is the key scaling win

```
Full call graph DFS:
  10,000 nodes × avg 5 out-edges = 50,000 edges
  Worst-case paths between two files: exponential
  DFS with max_path_length=15 and max_paths=100: may visit thousands of nodes

Variable-filtered subgraph DFS:
  Typical variable: 5–50 files out of 10K
  Subgraph: 5–50 nodes × avg 3 relevant edges = 15–150 edges
  DFS on 50-node graph: completes in microseconds
  Speedup: 100–1000×
```

### Hop index at scale

For very large codebases (>10K files, index >1 GB), split into per-key files:

```
variable_hop_index/
  CE1CRA_35.json        (WB1ACCTC occurrences)
  CE1CRA_65.json        (WB1SUPP occurrences)
  CE1CR0_28.json        (LG1OSI occurrences)
  ...
```

Key-to-filename mapping stored in a small manifest:
```json
{ "CE1CRA:35": "CE1CRA_35.json", "CE1CRA:65": "CE1CRA_65.json" }
```

This gives O(1) disk access per query — only the relevant key's file is loaded.

### Async threshold

For queries where the variable spans many files or paths:

```python
SYNC_THRESHOLD_FILES = 200   # var_files count
SYNC_THRESHOLD_PATHS = 500   # DFS paths found

if len(var_files) > SYNC_THRESHOLD_FILES or len(paths) > SYNC_THRESHOLD_PATHS:
    # Submit as Celery background job, return job_id
    task = run_variable_chains_async.delay(kb_id, variable, source_file, target_file)
    return {"job_id": task.id, "status": "queued"}
else:
    # Return result synchronously
    return build_chains_response(...)
```

---

## 9. Implementation Steps — What Needs to Be Built

The following four items remain to be implemented. Everything else listed in
Section 3 is already working.

---

### Step 6a — `build_variable_hop_index.py`  🔲 TODO (new file)

```
File: build_variable_hop_index.py

class HopIndexBuilder:
    def __init__(self, blueprint_dir, identity_index):
        ...

    def build(self, output_path):
        for bp_path in blueprint_dir.glob("*.asm.json"):
            bp = load_blueprint(bp_path)
            self._process_blueprint(bp, file_stem)
        self._write(output_path)

    def _process_blueprint(self, bp, stem):
        edges = bp["variable_lineage"]["edges"]
        for edge in edges:
            node_id = self._pick_memory_node(edge)
            if not node_id:  continue
            leaf = _name_upper(node_id)
            canon_key = self.identity_index["by_name"].get(leaf)
            if not canon_key:  continue
            hop = self._edge_to_hop(edge, node_id, leaf)
            self.index[canon_key][stem].append(hop)

    def _edge_to_hop(self, edge, node_id, variable_name):
        return {
            "line":           edge.get("line"),
            "expression":     edge.get("expression"),
            "operation_type": edge.get("operation_type"),
            "transformation": edge.get("transformation"),
            "relation":       edge.get("relation"),
            "node_id":        node_id,
            "variable_name":  variable_name,
        }
```

---

### Step 6b — `_build_variable_hop_index()` in `pipeline_task.py`  🔲 TODO

Add after the existing Step 5 call:

```python
def _build_variable_hop_index(ws: WorkspaceManager) -> None:
    from build_variable_hop_index import build_index
    identity_index_path = ws.output_dir / "variable_identity_index.json"
    output_path         = ws.output_dir / "variable_hop_index.json"
    build_index(blueprint_dir, identity_index_path, output_path)
```

Also update the step counter calls:

```python
print("=== Step 6/6: Building variable hop index ===")
_build_variable_hop_index(ws)
```

---

### Step 6c — `_build_filtered_subgraph()` in `knowledge_base.py`  🔲 TODO

Replace the current full-graph DFS in the variable-flow handler with a
variable-scoped subgraph:

```python
def _build_filtered_subgraph(full_forward, var_files, source, target):
    relevant = var_files | {source, target}
    return {
        node: [(nb, inst) for nb, inst in full_forward.get(node, []) if nb in relevant]
        for node in relevant
    }
```

Pass this subgraph into the existing `_find_paths()` / DFS logic instead of
the full call graph.

---

### Step 6d — Enrich hops with line-level occurrences  🔲 TODO

In `_trace_variable_along_path()` (or the equivalent hop-assembly loop in
`knowledge_base.py`), after resolving each hop, load occurrences from the hop
index and attach them:

```python
hop_index = _load_hop_index(ws.output_dir / "variable_hop_index.json")
...
hop_details = hop_index.get(canonical_key, {}).get(file_stem, [])
hop["occurrences"] = hop_details
```

---

### Step 6e — New `POST /{kb_id}/variable-chains` endpoint  🔲 TODO

Either upgrade the existing `POST /{kb_id}/variable-flow` to return the
enriched format, or add a new sibling endpoint:

```
POST /v1/knowledge-bases/{kb_id}/variable-chains
Body: { "variable": "WB1ACCTC", "source_file": "xh80", "target_file": "xh87",
        "max_path_length": 15, "max_paths": 100 }
Response: Full chains JSON as described in Section 7
```

---

## 10. API Endpoint

### Request

```
POST /v1/knowledge-bases/{kb_id}/variable-chains
Content-Type: application/json

{
  "variable":        "WB1ACCTC",
  "source_file":     "xh80",
  "target_file":     "xh87",
  "max_path_length": 15,
  "max_paths":       100
}
```

### Response (synchronous for small queries)

```
HTTP 200 OK
Content-Type: application/json

{ ... full chains JSON as in Section 7 ... }
```

### Response (async for large queries)

```
HTTP 202 Accepted
Content-Type: application/json

{
  "job_id":  "celery-task-uuid",
  "status":  "queued",
  "poll_url": "/v1/jobs/{job_id}/status"
}
```

### Error responses

| Code | Condition |
|------|-----------|
| 404 | KB not found |
| 409 | KB pipeline not yet complete |
| 422 | `source_file` or `target_file` not in call graph |
| 422 | `variable` not found in identity index |
| 422 | No call-graph path from source to target |

---

## 11. Data Flow Diagram

```
 SOURCE CODEBASE (.asm / .mac / .cpp)
        │
        ▼ Steps 1–2  ✅ DONE
 BLUEPRINTS   (<stem>.asm.json)
   • variable_lineage.nodes  — node_id, kind, metadata
   • variable_lineage.edges  — line, expression, operation_type,
                                transformation, relation,
                                dsect, field_offset,
                                access_identity, symbolic_identity,
                                file_label
        │
        ├─── Step 2.5  ✅ DONE ──────────────────────────────┐
        │    cross_file_access_identity.py                    │
        │    Enriches edges with L1/L2/L4 identity fields     │
        │    (modifies blueprints in-place)                   │
        │                                                     │
        ├─── Step 3    ✅ DONE ──►  file_call_graph.json      │
        │                           Directed: A → B           │
        │                                                     │
        ├─── Step 4    ✅ DONE ──►  variable_modifier_index   │
        │                           variable → [files]        │
        │                                                     │
        ├─── Step 5    ✅ DONE ──►  variable_identity_index   │
        │                           name   → canonical_key    │
        │                           key    → {ai,si,files}    │
        │                                                     │
        └─── Step 6    🔲 TODO ──►  variable_hop_index        │
             (reads Step 5)         key → file → [line,expr]  │
                                                              │
 ──────────────── QUERY TIME ──────────────────────────────── ┘

  Input: variable + source_file + target_file
        │
        ▼ Step A  ✅ DONE  (O(1))
  canonical_key  +  var_files  ◄── identity_index["by_name"]
        │
        ▼ Step B  🔲 TODO  (O(|var_files|²))
  filtered_subgraph  ◄── call_graph  ∩  var_files
        │
        ▼ Step C  ✅ DONE (basic, unfiltered graph)  →  🔲 TODO (switch to subgraph)
  paths  =  DFS(filtered_subgraph, source → target)
        │
        ▼ Step D  🔲 TODO  (O(1) per hop)
  hops with occurrences  ◄── hop_index[key][file]
        │
        ▼ Step E  🔲 TODO
  JSON response with all chains, per-hop line details,
  variable renaming, and resolution strategies
```

---

## Files Reference

| File | Status | Description |
|------|--------|-------------|
| `universe_builder.py` | ✅ DONE | Step 1 — variable universe builder |
| `main.py` | ✅ DONE | Step 2 — per-file blueprint generator |
| `passes/cross_file_access_identity.py` | ✅ DONE (fixed) | Step 2.5 — L1/L2/L4 edge enrichment |
| `file_call_graph.py` | ✅ DONE | Step 3 — file call graph builder |
| `build_modifier_index.py` | ✅ DONE | Step 4 — variable modifier index |
| `build_variable_identity_index.py` | ✅ DONE (fixed) | Step 5 — canonical identity index |
| `get_equivalent_variable.py` | ✅ DONE | 7-strategy cross-file variable resolver |
| `api/routes/knowledge_base.py` | ✅ DONE (basic) | `/variable-flow` endpoint — path finding, simple hops (no line details yet) |
| `api/tasks/pipeline_task.py` | ✅ DONE (partial) | Pipeline orchestration — Steps 1–5 wired in; Step 6 call missing |
| `build_variable_hop_index.py` | 🔲 TODO | Step 6 — new file, hop detail pre-computation |
| `api/tasks/pipeline_task.py` | 🔲 TODO | Add `_build_variable_hop_index()` call for Step 6 |
| `api/routes/knowledge_base.py` | 🔲 TODO | `_build_filtered_subgraph()`, enrich hops with `occurrences`, add `/variable-chains` endpoint |

---

*Generated: 2026-05-08*
