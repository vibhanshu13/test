# CPP-to-CPP Call Chain Traversal Patterns

This document describes all the different C++ to C++ function calling patterns
handled by the `/cpp-call-chain` API endpoint, covering both **forward**
(callees) and **backward** (callers) BFS traversal directions.

Reference implementation: `cpp_call_chain/traversal.py`

---

## Table of Contents

1. [Forward Traversal Patterns](#1-forward-traversal-patterns)
2. [Backward Traversal Patterns](#2-backward-traversal-patterns)
3. [Concrete Calling Styles in the Codebase](#3-concrete-calling-styles-in-the-codebase)
4. [IBM / z/TPF Calling Conventions](#4-ibm--ztpf-calling-conventions)
5. [Summary Table](#5-summary-table)
6. [Configuration Parameters](#6-configuration-parameters)

---

## 1. Forward Traversal Patterns

Forward traversal answers: **"What does this function call?"**

Implementation: `traverse_forward()` in `cpp_call_chain/traversal.py:377-639`

### 1.1 Direct Function Call (Blueprint Edge)

The most common pattern. A C++ function directly invokes another C++ function.

- **Source:** Blueprint `call_graph.edges` where `edge.source == method`
- **Code:** `traversal.py:549-613`
- **How it works:** Loads the blueprint for the caller's file, iterates edges
  where `source == method`, enqueues each `target`.
- **Edge properties:** `call_type="call"`, `instruction="CALL"`, `is_indirect=false`

```cpp
// Example
void funcA() {
    funcB();           // direct call
    funcC(arg1, arg2); // direct call with arguments
}
```

### 1.2 Indirect Call via Function Pointer (Resolved Target)

A function is called through a function pointer, but the blueprint analysis
was able to resolve the actual target.

- **Source:** Blueprint edge with `is_indirect=true` and a known `target`
- **Code:** `traversal.py:555-560` (filter/detection), `traversal.py:606-610` (envelope construction)
- **How it works:** Edge has `is_indirect=true` and a `register` field (e.g.
  `"funcPtr"`). The target is known, so it is enqueued with an indirection
  envelope: `{is_indirect: true, indirect_via: "funcPtr"}`
- **Controlled by:** `include_indirect_calls` request parameter

```cpp
// Example
void (*fp)(int) = &funcB;
fp(42);  // indirect call — target resolved to funcB
```

### 1.3 Indirect Call via Function Pointer (Unresolved Target)

A function pointer call where static analysis could not determine the target.

- **Source:** Blueprint edge with `is_indirect=true` and **no target**
- **Code:** `traversal.py:563-587`
- **How it works:** Creates a synthetic leaf node named `(indirect via R15)` or
  similar. This is a **terminal node** — BFS does not continue through it.
- **Output node example:** `method_name="(indirect via R15)"`,
  `indirection={is_indirect: true, indirect_via: "R15"}`

```cpp
// Example — target unknown at analysis time
typedef void (*Callback)(int);
Callback cb = getCallback();  // runtime-determined
cb(42);                        // unresolved indirect call
```

### 1.4 Virtual Method Dispatch via CHA (Class Hierarchy Analysis)

When a virtual method on a base class is encountered, CHA expands the
traversal to include all known derived-class overrides.

- **Source:** Index `class_hierarchy.base_to_derived` map
- **Code:** `traversal.py:265-316` (`_apply_cha_expansion`)
- **How it works:** When traversing `BaseClass::foo()`, looks up all derived
  classes in the hierarchy. If `DerivedClass::foo()` has a definition in the
  index, it is enqueued with `call_type="virtual_dispatch_cha"` and
  `indirection={is_virtual_dispatch: true, cha_base_class: "BaseClass"}`
- **Controlled by:** `expand_virtual_dispatch` request parameter
- **Constraint:** Only triggers when method name contains `::`

```cpp
// Example
struct Base {
    virtual void process(Data* d) = 0;
};
struct DerivedA : Base {
    void process(Data* d) override;  // enqueued via CHA
};
struct DerivedB : Base {
    void process(Data* d) override;  // enqueued via CHA
};

Base* b = factory();
b->process(data);  // CHA expands to DerivedA::process + DerivedB::process
```

### 1.5 Multiple Inheritance CHA

A specialisation of pattern 1.4 where a class derives from multiple bases,
each with virtual methods.

- **Source:** Same CHA mechanism, applied per base class
- **How it works:** Each base class is checked independently in
  `base_to_derived`. A class like `MultiDerived : BaseAlpha, BaseBeta` will
  appear as a derived class under both `BaseAlpha` and `BaseBeta`.

```cpp
// Example
struct BaseAlpha { virtual void alphaMethod() = 0; };
struct BaseBeta  { virtual void betaMethod()  = 0; };
struct MultiDerived : BaseAlpha, BaseBeta {
    void alphaMethod() override;  // CHA from BaseAlpha
    void betaMethod()  override;  // CHA from BaseBeta
};
```

### 1.6 Source Fallback (No Blueprint Available)

When no blueprint exists for a file, the traversal falls back to scanning
the actual C++ source file for call sites.

- **Source:** Live source file scanning via `source_scanner.scan_callees_in_function()`
- **Code:** `traversal.py:517-544`
- **How it works:** Scans the function body in the `.cpp` source for call
  expressions. Enqueues discovered callees with `call_type="call"`,
  `instruction="CALL"`.
- **Limitation:** Only for CPP files; only when `resolved_fp` is available and
  the function is not external.

### 1.7 Cross-Language Boundary (CPP to ASM/MAC)

After processing same-language edges, the traversal checks for cross-language
calls where a CPP function invokes an ASM or MAC routine.

- **Source:** `cross_lang.forward` index built from `file_call_graph.json`
- **Code:** `traversal.py:615-637`
- **How it works:** Looks up `(file_stem, method)` in the cross-language forward
  map. Any ASM/MAC targets are enqueued and BFS continues into ASM/MAC territory.

```cpp
// Example — CPP calling ASM entry point
extern "C" void EM71(TPF_regs* regs);  // ASM entry
void cppFunction(TPF_regs* regs) {
    EM71(regs);  // cross-language call
}
```

---

## 2. Backward Traversal Patterns

Backward traversal answers: **"Who calls this function?"**

Implementation: `traverse_backward()` in `cpp_call_chain/traversal.py:646-883`

### 2.1 Pre-Built Callers Index Lookup

The primary backward mechanism for CPP-to-CPP. Uses a pre-built reverse
index for O(1) lookup per function.

- **Source:** `index.callers[method_name]` — built at index time by
  `index_builder.py`
- **Code:** `traversal.py:757`
- **How it works:** Each entry in the callers index contains
  `{caller_func, file_stem, file_path, call_line, call_type, instruction}`.
  All matching callers are enqueued for further traversal.

```
Index entry example:
  callers["funcB"] = [
      {caller_func: "funcA", file_stem: "main", call_line: 42, call_type: "call", ...},
      {caller_func: "funcC", file_stem: "utils", call_line: 87, call_type: "call", ...},
  ]
```

### 2.2 Indirect Caller (via Callers Index)

Same as pattern 2.1, but the caller entry carries an indirection envelope
indicating the call was made through a function pointer.

- **Source:** Callers index entries with `indirection` field
- **Code:** `traversal.py:811-838`
- **How it works:** The callers index entry has
  `indirection={is_indirect: true, indirect_via: "..."}`. These callers are
  skipped when `include_indirect_calls=false`.

```cpp
// Example — funcA calls funcB via a function pointer
void funcA() {
    void (*fp)() = &funcB;
    fp();  // backward traversal from funcB finds funcA as indirect caller
}
```

### 2.3 ASM/MAC Blueprint Edge Inversion

For ASM/MAC nodes (not CPP), the traversal loads the blueprint and inverts
edges to find intra-file callers.

- **Source:** Blueprint edges where `edge.target == method`
- **Code:** `traversal.py:759-780`
- **How it works:** Loads the blueprint for the ASM/MAC file, iterates all edges,
  and finds those where `target == method`. The `source` of each matching edge
  is treated as a caller.
- **Note:** This handles ASM-to-ASM and ASM-to-CPP backward relationships.

### 2.4 Source Fallback (Root Only)

When the callers index has no entry for a CPP function, the traversal falls
back to scanning source files — but only at depth 0.

- **Source:** `source_scanner.scan_callers_in_source()`
- **Code:** `traversal.py:782-809`
- **How it works:** Scans all `.cpp` files in `source_path` for occurrences of
  the function name. Limited to codebases with fewer than 500 `.cpp` files.
- **Limitation:** Only at depth 0, only when `source_path` is provided.
  Deeper nodes that are missing from the index produce a warning instead.

### 2.5 Cross-Language Boundary (ASM/MAC to CPP)

After same-language callers, checks the cross-language index for reverse
edges — ASM/MAC routines that call the target CPP function.

- **Source:** `cross_lang.backward` index
- **Code:** `traversal.py:855-881`
- **How it works:** Looks up `(file_stem, method)` in the cross-language backward
  map. Any ASM/MAC callers are enqueued and BFS continues into ASM/MAC.

```
Example: ASM routine "PB31" calls CPP function "processRecord"
  → backward traversal from processRecord discovers PB31 as a caller
```

### 2.6 Backward CHA Expansion

When backward-traversing from a derived-class method (e.g., `Derived::foo`),
callers of the base-class method (`Base::foo`) may dispatch to `Derived::foo`
at runtime through virtual dispatch. Backward CHA expansion enqueues the
base-class method so those callers are also discovered.

- **Source:** `class_hierarchy.base_to_derived` map (inverted lookup)
- **Code:** `traversal.py:318-370` (`_apply_cha_expansion_backward`)
- **How it works:** For each base class whose derived list includes the current
  class, enqueues `Base::foo` with `call_type="virtual_dispatch_cha"` and
  `indirection={is_virtual_dispatch: true, cha_base_class: "Base"}`
- **Controlled by:** `expand_virtual_dispatch` parameter
- **Constraint:** Only triggers when method name contains `::`
- **Traversal call site:** `traversal.py:840-853`

---

## 3. Concrete Calling Styles in the Codebase

These are the actual C++ calling styles found in the `temp/asm` source files
and how the traversal engine handles each one.

### 3.1 Direct Function Call

```cpp
// Source: dw730000.cpp
callCoreCarver(&registers);
callPlasticAuthenticationComponentInterface(addresses->plasticAuthOnlyArea->data, ...);
```

- **Traversal:** Blueprint edge with `call_type="call"`

### 3.2 `extern "C"` Function Call

```cpp
// Source: cf500000.cpp, dw710300.cpp
extern "C" void EM71(TPF_regs* regs);
extern "C" void YL73(TPF_regs* regs);
extern "C" void CF55(TPF_regs* regs);
```

- **Traversal:** Treated as direct call at same-language level; may also appear
  in cross-language boundary index if the target is an ASM routine.

### 3.3 `asm()` Symbol Alias

```cpp
// Source: rh73Iw00.cpp
extern "C" void getTms(TPF_regs *)asm("PB31");
extern "C" void ckXc  (TPF_regs *)asm("TE90");
extern "C" void callAV01(TPF_regs *)asm("AV01");
```

- **Traversal:** Mapped through `asm_entry_point_map` in the blueprint. The
  C++ name is used in the call graph edge, but the ASM entry point name is
  the target in the cross-language index.

### 3.4 Function Pointer

```cpp
// Source: tests/cpp_regression/tx_caller.cpp
RegFnPtr g_globalFp = fpTarget;   // global FP initialisation
RegFnPtr fp = fpTarget;           // local FP initialisation
fp(wa);                           // FP invocation
```

- **Traversal:** Indirect call — resolved target enqueued with indirection
  envelope; unresolved targets become synthetic leaf nodes.

### 3.5 Virtual Method Call

```cpp
// Source: tests/cpp_regression/tx_caller.cpp
struct BaseT {
    virtual void vfunc(RWA* wa) = 0;
};
struct DerivedT : BaseT {
    void vfunc(RWA* wa) override;
};
BaseT& ref = derived;
ref.vfunc(wa);  // virtual call via reference
```

- **Traversal:** CHA expansion enqueues `DerivedT::vfunc` alongside
  `BaseT::vfunc`.

### 3.6 `std::function` Wrapper

```cpp
// Source: tests/cpp_regression/tx_caller.cpp
RegFnPtr fn = stdFnTarget;  // RegFnPtr is a typedef; target is std::function-compatible
fn(wa);
```

- **Traversal:** Indirect call (type-erased). Target may or may not be resolved
  depending on blueprint analysis depth.

### 3.7 Functor (`operator()`)

```cpp
// Source: tests/cpp_regression/tx_target.cpp
struct TargetFunctor {
    void operator()(RWA* wa);
};
TargetFunctor f;
f(wa);
```

- **Traversal:** Direct call to `TargetFunctor::operator()` in the blueprint.

### 3.8 Namespace-Qualified Call

```cpp
// Source: tests/cpp_regression/tx_caller.cpp
TxNS::nsTarget(wa);                  // simple namespace
TxOuter::Inner::innerTarget(wa);     // nested namespace
```

- **Traversal:** Direct call with fully-qualified name in blueprint edge.

### 3.9 Static Method Call

```cpp
// Source: tests/cpp_regression/tx_caller.cpp
TargetHelpers::staticHelper(wa);
```

- **Traversal:** Direct call with `ClassName::method` in the blueprint.

### 3.10 Multiple Inheritance Virtual Dispatch

```cpp
// Source: tests/cpp_regression/tx_caller.cpp
struct BaseAlpha { virtual void alphaMethod(RWA* wa) = 0; };
struct BaseBeta  { virtual void betaMethod(RWA* wa)  = 0; };
struct MultiDerived : public BaseAlpha, public BaseBeta {
    void alphaMethod(RWA* wa) override;
    void betaMethod(RWA* wa)  override;
};
BaseAlpha* a = &multi;
a->alphaMethod(wa);  // CHA expands to MultiDerived::alphaMethod
```

- **Traversal:** CHA expansion applied per base class independently.

### 3.11 Macro-Wrapped Call

```cpp
// Source: dh720200.cpp
#define recordId ecbptr()->ebcidc
crusa(1, LJ1_level);
finwc(LJ1_level);
```

- **Traversal:** Macros are expanded at blueprint generation time. The
  underlying function call appears as a direct edge in the call graph.

### 3.12 `#pragma export` Directive

```cpp
// Source: cf580100.cpp
#pragma export (scrambleHsm5csc)
#pragma export (callHsm)
```

- **Traversal:** Affects symbol visibility and linkage, not the call graph
  itself. Exported functions are reachable from other translation units.

### 3.13 Pointer Dereference Member Access

```cpp
// Source: dh720200.cpp
LJ1J1 *indexRecord = (LJ1J1 *) ecbptr()->ce1crc;
indexRecord->indexSlots[slot].corporateIdentifier;
```

- **Traversal:** Member access via `->` is data access, not a function call.
  Only relevant if it results in a virtual method invocation.

### 3.14 Constructor / Destructor (Implicit)

```cpp
// Source: cf500000.cpp
L9x9x l9x9x;  // constructor called implicitly
```

- **Traversal:** Constructor calls may appear as edges in the blueprint if the
  blueprint generator tracks them. Otherwise they are not in the call graph.

### 3.15 z/TPF C API Functions (crusa, finwc, glob)

z/TPF provides C-callable API functions that appear as direct calls in
CPP source. These are system-level functions, not user-defined.

```cpp
// Source: dh720200.cpp:181-185
crusa(1, LJ1_level);          // Create/allocate storage area
if ( finwc(LJ1_level) == 0 )  // Find with core block

// Source: dx740200.cpp:125
if(*((char*) glob(_ccibind)) & 0x10)  // Global ECB field access

// Source: dx730000.cpp:69
crusa(1,D0);                   // Create at data level D0
```

- **Traversal:** Direct call edges in the blueprint. `crusa`, `finwc`,
  `glob` are z/TPF OS C functions wrapping ASM macros (GETCC, FINWC,
  GLOB respectively).
- **Files:** `dx740200.cpp` (6), `dx730000.cpp` (4), `dh720200.cpp` (2),
  `rh73Iw00.cpp` (2), `dp710100.cpp` (1), `dx710000.cpp` (1)

### 3.16 z/TPFDF Database API Functions

z/TPFDF database operations use C API functions that appear as direct
calls in CPP source.

```cpp
// Source: dw710500.cpp, dw712100.cpp, dw780000.cpp
df_setkey(...)         // Set key for database access
df_setkey_bool(...)    // Set boolean key
dfopn_acc(...)         // Open and access database
```

- **Traversal:** Direct call edges. These are z/TPFDF C API functions.
- **Files:** `dw710500.cpp`, `xh890000.cpp`, `dw712100.cpp`,
  `dw780000.cpp`, `dw710000.cpp` (27 active instances)
- **Note:** Many z/TPF C API functions (`crusa`, `getcc`, `relcc`,
  `glob`, `df_setkey`, etc.) are in the `_CPP_STDLIB_NOISE` filter
  (`file_call_graph.py:69-89`). Calls to these functions are dropped
  from `file_call_graph.json` but still appear as blueprint edges.

---

## 4. IBM / z/TPF Calling Conventions

The IBM z/TPF documentation (`temp/ibm/`) describes additional calling
patterns relevant to cross-language boundaries:

| Instruction | Type | Return Behaviour | Traversal Edge |
|-------------|------|-------------------|----------------|
| **CALLC** | Direct ASM-to-C call | Returns to caller | Call edge |
| **ENTRC** | Program call with return | Returns to caller | Call edge |
| **ENTDC** | Program call, drop caller | No return | Terminal edge |
| **ENTNC** | Program call, no return expected | No return | Terminal/handoff edge |
| **CREDC** | Deferred async entry creation | Independent ECB | `async_spawn` edge (in builder at `call_graph_builder.py:765`) |
| **CREEC/CREMC** | Async entry creation | Independent ECB | `async_spawn` edge (in `CROSS_FILE_CALL_OPCODES`) |
| **CRESC / tpf_cresc** | Synchronous entry | Blocking boundary | `sync_spawn` edge (in builder) |
| **ATTAC/ATTC** | Attach child ECB/task | Independent ECB | `async_spawn` edge (in builder at `call_graph_builder.py:799`) |
| **EXSR** | Execute subroutine | Returns to caller | `subroutine_call` edge (in builder at `call_graph_builder.py:765`) |
| **CRETC** | Timer-initiated entry | Independent ECB | `async_spawn` edge (in builder at `call_graph_builder.py:766`) |
| **CREXC** | Low-priority deferred entry | Independent ECB | `async_spawn` edge (in builder at `call_graph_builder.py:766`) |
| **CLINKC** | C-linkage call to BAL function | Returns to caller | `subroutine_call` edge (in builder at `call_graph_builder.py:766`) |
| **RLINKC** | Return from C-callable BAL | Return boundary | `return` edge (in builder at `call_graph_builder.py:835`) |

### Key z/TPF Considerations

- **CPROC:** Metadata-only macro declaring a C function prototype for
  cross-language calls. No runtime effect but essential for accurate call
  graph building.
- **Register conventions:** R9 = ECB base, R15 = return value, R14 = link/return register (also receives GETCC allocation results). These affect indirect call resolution.
- **Hidden state:** ECB lifecycle, SW00SR (database context), CBRW (storage
  ownership) all flow implicitly across calls and must be tracked for
  accurate modernisation.

---

## 5. Summary Table

| # | Pattern | Direction | Data Source | Key Feature |
|---|---------|-----------|-------------|-------------|
| 1 | Direct call | Forward | Blueprint edges | Standard function invocation |
| 2 | Indirect call (resolved) | Forward | Blueprint edges + `is_indirect` | Function pointer with known target |
| 3 | Indirect call (unresolved) | Forward | Blueprint edges + `is_indirect`, no target | Synthetic leaf node, BFS stops |
| 4 | Virtual dispatch (CHA) | Forward | `class_hierarchy.base_to_derived` | Enqueues all subclass overrides |
| 5 | Multiple inheritance CHA | Forward | `class_hierarchy.base_to_derived` | Per-base-class expansion |
| 6 | Source fallback (callees) | Forward | Live source scan | When no blueprint exists |
| 7 | Cross-language (CPP to ASM) | Forward | `cross_lang.forward` | CPP-to-ASM/MAC boundary |
| 8 | Callers index lookup | Backward | `index.callers` | O(1) pre-built reverse map |
| 9 | Indirect caller | Backward | `index.callers` + indirection env | Caller used function pointer |
| 10 | ASM edge inversion | Backward | Blueprint edges (inverted) | Intra-file ASM callers |
| 11 | Source fallback (callers) | Backward | Live source scan | Root-only, < 500 files |
| 12 | Cross-language (ASM to CPP) | Backward | `cross_lang.backward` | ASM/MAC-to-CPP boundary |
| 13 | z/TPF C API calls | Forward | Blueprint edges | crusa, finwc, glob — system functions |
| 14 | z/TPFDF database API | Forward | Blueprint edges | df_setkey, df_setkey_bool, dfopn_acc |

---

## 6. Configuration Parameters

These request-level parameters control which patterns are activated:

| Parameter | Default | Effect |
|-----------|---------|--------|
| `direction` | `"forward"` | Selects forward (callees) or backward (callers) traversal |
| `max_depth` | `5` | Maximum BFS hops from root (1-50) |
| `include_external` | `false` | Include stdlib/external functions (memcpy, std::, etc.) |
| `include_indirect_calls` | `true` | Include function-pointer call sites |
| `expand_virtual_dispatch` | `true` | Apply cross-TU Class Hierarchy Analysis |
| `max_nodes` | `1,000,000` | Maximum nodes to collect before truncation |
| `source_path` | `null` | Absolute path to C++ sources for fallback scanning |
| `include_params` | `true` | Enrich nodes with function signatures |
| `force_rebuild_index` | `false` | Force rebuild of the function index |

---

## File References

| Component | Path |
|-----------|------|
| Endpoint handler | `api/routes/knowledge_base.py:2504-2832` |
| Forward traversal | `cpp_call_chain/traversal.py:377-639` |
| Backward traversal | `cpp_call_chain/traversal.py:646-883` |
| CHA expansion | `cpp_call_chain/traversal.py:265-316` |
| Index builder | `cpp_call_chain/index_builder.py` |
| Source scanner | `cpp_call_chain/source_scanner.py` |
| Indirection utils | `api/utils/indirection.py` |
| Cross-language index | `cpp_call_chain/index_builder.py:526-778` |
