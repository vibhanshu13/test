# Variable Universe System

## Overview

The Variable Universe system is a two-pass approach for comprehensive variable lineage tracking across ASM and C/C++ codebases.

**Key Features:**
- **Pass 1 (Universe Builder):** Discovers all permanent variables across the codebase
- **Pass 2 (Enhanced Parser):** Enriches lineage tracking with operation classification and conditional context
- **Strict Lookup:** Only tracks variables that exist in the universe
- **Rich Metadata:** Captures operation types, initialization methods, and conditional dependencies

## Architecture

### Pass 1: Universe Builder

Pre-scans all source files to build a catalog of permanent variables.

**ASM Variables Include:**
- Memory locations (DS, DC directives)
- Named constants (EQU)
- External symbols (EXTRN, WXTRN)

**ASM Variables Exclude:**
- Registers (R0-R15)
- Section names (CSECT, DSECT, RSECT)
- Macro parameters

**C/C++ Variables Include:**
- Local variables
- Function parameters
- Global variables
- Class/struct members
- Static variables
- Extern declarations

**Outputs:**
- `asm_variable_universe.json` - Full metadata for ASM variables
- `asm_variable_names.json` - Simple list of ASM variable names
- `cpp_variable_universe.json` - Full metadata for C++ variables
- `cpp_variable_names.json` - Simple list of C++ variable names

### Pass 2: Enhanced Parser

The existing parser with universe-aware lineage tracking.

**Enriched Edge Metadata:**
- `operation_type`: move, compare, load, store, arithmetic, logical, initialize, call_arg, etc.
- `initialization_method`: macro, direct, parameter, computed, default
- `conditional_context`: List of active conditional expressions affecting the variable
- `transformation`: Human-readable description of the operation

**How It Works:**
1. Load variable names at startup
2. During parsing, check each operand against universe
3. If variable found, classify operation and track context
4. Create enriched lineage edges with operation metadata

## Usage

### Step 1: Build Variable Universe

```bash
python universe_builder.py <source_directories> --output output/
```

**Examples:**

```bash
# Build universe from a directory
python universe_builder.py src/ --output output/

# Build from multiple directories
python universe_builder.py src/ lib/ include/ --output output/

# Build ASM universe only
python universe_builder.py src/ --asm-only --output output/

# Build C++ universe only
python universe_builder.py src/ --cpp-only --output output/
```

**Output Structure:**
```
output/
├── asm_variable_universe.json      # Full ASM variable metadata
├── asm_variable_names.json         # Simple ASM variable list
├── cpp_variable_universe.json      # Full C++ variable metadata
└── cpp_variable_names.json         # Simple C++ variable list
```

### Step 2: Run Parser with Universe

```bash
python main.py <source_files> --load-universe --universe-dir output/
```

**Examples:**

```bash
# Analyze with universe awareness
python main.py src/app.asm --load-universe

# Specify custom universe directory
python main.py src/ --load-universe --universe-dir my_universe/

# Standard analysis (without universe)
python main.py src/app.asm
```

**Effect:**
- Variables are validated against universe during parsing
- Lineage edges include operation_type, conditional_context, etc.
- Output JSON contains enriched variable_lineage data

### Step 3: Traversal (Future Enhancement)

Future traversal algorithms will leverage the enriched metadata for smarter lineage analysis.

```bash
# Example (not yet implemented)
python traversal/trace_variable_v2.py \
  --var BUFFER \
  --use-universe \
  --cpp-json output/app.cpp.json \
  --asm-dir output/
```

## Variable Universe JSON Format

### Simple Names File

```json
{
  "variables": [
    "BUFFER",
    "counter",
    "app_context",
    "MAXLEN"
  ]
}
```

### Full Universe File

```json
{
  "variables": {
    "BUFFER": [
      {
        "name": "BUFFER",
        "kind": "memory",
        "scope": "MAIN",
        "file": "app.asm",
        "line": 42,
        "declaration_type": "DS",
        "data_type": "CL100",
        "storage_class": "local",
        "initial_value": null,
        "all_locations": [
          {"file": "app.asm", "line": 42, "context": "definition"}
        ],
        "scope_chain": ["MAIN"],
        "aliased_as": [],
        "related_symbols": [],
        "metadata": {
          "length": 100,
          "introduced_via": "direct_declaration"
        }
      }
    ]
  },
  "extern_symbols": {
    "EDACCT": {
      "name": "EDACCT",
      "kind": "external",
      "scope": "global",
      "file": "app.asm",
      "line": 10,
      "declaration_type": "EXTRN",
      "storage_class": "extern",
      "metadata": {
        "symbol_type": "unknown"
      }
    }
  }
}
```

## Enriched Lineage Edge Format

```json
{
  "source": "memory:BUFFER",
  "target": "register:R1",
  "relation": "assign",
  "file": "app.asm",
  "line": 100,
  "expression": "LA R1,BUFFER",
  "scope": "MAIN",
  "statement_id": "stmt_100",
  "operation_type": "load",
  "initialization_method": null,
  "conditional_context": [
    "CLC BUFFER,=C'READY' -> BNE"
  ],
  "transformation": "Load BUFFER into R1"
}
```

## Operation Classification

### ASM Operations

| Operation Type | Instructions |
|---------------|-------------|
| `move` | MVC, MVCL, MVCIN, MVI, MVZ, MVN |
| `compare` | CLC, CLI, C, CR, CH, CL, CLR |
| `load` | L, LR, LA, LH, LM, LTR, LCR, LNR, LPR |
| `store` | ST, STH, STM, STC |
| `arithmetic` | A, AR, AH, S, SR, SH, M, MR, D, DR |
| `logical` | N, NR, O, OR, X, XR, NC, OC, XC |
| `shift` | SLA, SRA, SLL, SRL, SLDA, SRDA |
| `initialize` | DS, DC, EQU |
| `call` | BAL, BALR, BAS, BASR, BASSM |
| `branch` | BC, BCR, BE, BNE, BH, BL, etc. |

### C/C++ Operations

| Operation Type | AST Nodes |
|---------------|-----------|
| `initialize` | declaration |
| `assign` | assignment_expression |
| `modify` | update_expression, compound_assignment_operator |
| `call_arg` | call_expression |
| `arithmetic` | binary_expression (operators: +, -, *, /) |

## Conditional Context Tracking

The system tracks which conditional expressions affect each variable operation.

**ASM Example:**
```asm
CLC    BUFFER,=C'READY'    ; Compare BUFFER with 'READY'
BNE    SKIP                ; Branch if not equal
MVC    OUTPUT,BUFFER       ; This MVC has conditional_context
SKIP   DS     0H
```

The `MVC OUTPUT,BUFFER` edge will have:
```json
"conditional_context": [
  "CLC BUFFER,=C'READY' -> BNE"
]
```

**C++ Example:**
```cpp
if (counter > 0) {
    result = counter * 2;  // This assignment has conditional context
}
```

The assignment edge will capture the `if (counter > 0)` condition.

## Implementation Details

### Data Structures

**VariableEntry** (`models/variable_universe.py`):
- Full metadata for a single variable
- Includes scope, type, storage class, all locations
- Extensible metadata dictionary

**VariableEdge** (`models/variable_lineage.py`):
- Extended with new optional fields
- Backward compatible (defaults to None)
- Serializes to JSON with enriched metadata

**AnalysisContext** (`models/analysis_context.py`):
- Stores variable name sets for quick lookup
- `is_variable(name, language)` method for validation
- Injected by orchestrators after universe loading

### Key Files

- `universe_builder.py` - Pass 1 implementation
- `operation_classifier.py` - Operation classification and conditional tracking
- `models/variable_universe.py` - Data structures for universe
- `models/variable_lineage.py` - Extended edge model
- `models/analysis_context.py` - Universe storage in context
- `passes/data_flow_tracker.py` - Universe-aware tracking integration

## Cross-File Variable Identity

**Current Status:** Deferred for later design.

**Challenge:** Same variable name can appear in multiple files:
- Same variable (shared across files)
- Different variables (coincidental naming)

**Future Strategy Options:**
1. Symbol resolution via EXTRN/ENTRY linkage
2. Heuristic matching (scope + file patterns)
3. User-provided mapping configuration
4. UUID-based identity (considered but deferred)

## Limitations and Future Work

1. **Cross-file identity:** Not yet implemented
2. **Macro parameter tracking:** Macro parameters excluded from universe
3. **C++ traversal:** Future work to leverage tree-sitter AST for conditional tracking
4. **Register tracking:** Registers not in universe but still tracked in lineage
5. **Dynamic values:** Computed/runtime values not tracked in universe

## Testing

To test the variable universe system:

```bash
# 1. Build universe
python universe_builder.py test_data/ --output output/

# 2. Run parser with universe
python main.py test_data/*.asm --load-universe --output-dir output/

# 3. Check output JSON files for enriched edges
cat output/test.asm.json | jq '.variable_lineage.edges[] | select(.operation_type)'
```

Expected: Edges should have `operation_type`, `conditional_context`, and `transformation` fields where applicable.

## Integration with Existing Workflows

The variable universe system is **fully backward compatible**:

- Without `--load-universe`: Parser behaves as before
- With `--load-universe`: Parser uses strict lookup and adds enrichment
- Old JSON outputs still valid (new fields are optional)
- Existing traversal scripts work unchanged

## Performance Considerations

**Pass 1 (Universe Builder):**
- Lightweight: Only extracts declarations, no full parsing
- Fast: Processes 1000+ files in seconds
- Output: Small JSON files (KB to low MB range)

**Pass 2 (Parser):**
- Minimal overhead: Set membership checks (O(1) average)
- No significant performance impact
- Memory: Variable name sets cached in RAM

## Troubleshooting

**Q: Universe files not found**
```
Warning: ASM universe file not found: output/asm_variable_names.json
```
**A:** Run `universe_builder.py` first to generate universe files.

**Q: No enriched metadata in output**
```
Lineage edges missing operation_type
```
**A:** Ensure you're running with `--load-universe` flag.

**Q: Variable not being tracked**
```
Variable FOO appears in code but not in lineage
```
**A:** Check if FOO is in the universe. If not, it might be:
- A register (excluded from ASM universe)
- A macro parameter (excluded)
- A typo or expression (not a variable name)

## Contact and Support

For issues, questions, or contributions related to the variable universe system, please refer to the main project README.
