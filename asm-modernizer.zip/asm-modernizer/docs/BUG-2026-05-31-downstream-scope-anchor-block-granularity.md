# BUG: Downstream scope leaks post-setter cross-file calls (anchor-block granularity)

- **Date filed:** 2026-05-31
- **Status:** OPEN (confirmed, not yet fixed — left as-is pending decision)
- **Severity:** Medium — produces irrelevant branches in a variable's lineage; not a crash or data-corruption.
- **Component:** `backward_traversal` engine (shared by every lineage API).
- **Found via:** `LG1OSI` on chain `lu82 → dx750000 → dx710000 → dx730000 → dx740200 → da78`.

## Summary

When the backward-lineage engine runs its **downstream passes** (`root_var_downstream`,
`dep_var_downstream`), it collects cross-file calls to follow forward using a scope built from
`backward_reachable_blocks(setter_block)`. The scope direction is correct (backward-reachable
from the setter), **but it is block-granular, not line-granular**. The setter's own basic block
is included *whole*, so any cross-file call sequenced **after** the setter instruction — but in
the same basic block — is collected and followed downstream. Those calls run *after* the variable
is already set and therefore have nothing to do with how the variable got its value.

## Concrete reproduction (LG1OSI)

`temp/asm/da78.asm`, block `DA780000`:

```
854:  OI    LG1OSI,LG#C400          UPDATE IS COMING FROM C400   ← the setter
856:  ENTRC XH80                    UPDATE GL-CR21AE A7 LREC      ← AFTER the setter, same block
```

Resulting (wrong) lineage tail, observed in session `3dc224c2bb44aeac`
(KB `6f0e29ff-aa67-4d45-aaad-46d1a1fd0690`):

```
6: xh71 [dep_var_downstream] var=CE1CR6     (path_to_source: ['da78','xh80'])
7: xh81 [dep_var_downstream] var=CE1CR6
8: xh90 [dep_var_downstream] var=CE1CR7
```

`da78 → XH80` (line 856) is followed because `XH80` sits in the setter's block; from `XH80` the
engine then chases the dependent value `CE1CR6` (the z/TPF ECB level-6 core-block pointer) forward
into `xh71`, `xh81`, `xh90`. None of this contributes to *how* `LG1OSI` is set — it is the program
continuing on *after* the write.

## Root cause (exact code path)

`backward_traversal/runner/chunked_session.py`, PASS1B transition (~lines 453–463):

```python
anchor_blocks = set(meta.get("anchor_blocks"))            # the setter block(s), e.g. DA780000
if anchor_blocks:
    rv_scope = set()
    for b in anchor_blocks:
        rv_scope.update(backward_reachable_blocks(bp_data, b))   # includes the anchor block itself
else:
    rv_scope = {all blocks in file}
rv_cross = _collect_scoped_cross_file_calls(bp_data, rv_scope, asm_file, asm_dir)
```

Two facts combine:

1. `backward_reachable_blocks(setter_block)` **includes the setter's own block** (it is the BFS
   start node) — `backward_traversal/tracing/asm_backward_tracer.py:584`.
2. `_collect_scoped_cross_file_calls` (`backward_only_runner.py:264`) scans **every flow entry in
   every in-scope block**. Its dedup key is `(source_block, line, target)` — there is **no filter
   for "only instructions at or before the setter line"** within the anchor block.

So the anchor block is scanned in full, and a cross-file call physically after the setter line
(but in the same basic block, with no intervening branch) is collected and enqueued as a
downstream target.

The same logic gates the dependent-variable downstream pass (`dep_var_downstream`), so the leak
propagates: once `XH80` is in scope, `CE1CR6` collected there is chased further downstream.

## Scope of impact

- **All lineage APIs are affected**, because the downstream passes live in the shared engine
  (`ChunkedBackwardSession`, PASS1B/PASS2B) and in the non-chunked `run_backward_only`. Affected
  endpoints: `POST /backward-lineage/chunks`, `POST /backward-lineage/co-track`,
  `POST /explain-lineage/run` (+ `/step`), and the CLI.
- Triggers **only when the setter and a later cross-file call share a basic block** (no branch
  between them). Predecessor blocks are genuinely all-upstream (they end in the branch into the
  setter block), so including them whole is correct.
- On by default: `DEFAULT_MAX_DOWNSTREAM_DEPTH = 2`; request schema default `max_downstream_depth = 2`.

## Workaround (today)

Pass `max_downstream_depth = 0` (and `max_downstream_files = 0`) on the request. This disables the
downstream passes entirely — `_process_root_var_downstream` returns before emitting any tuple
(`chunked_session.py:896`) — leaving only the genuine backward setting logic (setter file, upstream
chain, backward dependent-variable traces). Note this removes *all* downstream/consumer context,
not just the post-setter leak.

## Proposed fix (precise, minimal)

Trim **only the anchor block(s)** to flow entries with `line <= setter_line` when building the
downstream scope's cross-file-call set. Predecessor blocks remain whole (they are entirely
upstream). Concretely: when collecting cross-file calls for the `root_var`/`dep_var` downstream
scope, pass the setter line for each anchor block and have `_collect_scoped_cross_file_calls` skip
entries in the anchor block whose `line` exceeds the setter line. This drops `ENTRC XH80`
(856 > 854) and, with it, the `xh80 → xh71 → CE1CR6` branch — without disabling legitimate
downstream-of-consumer context elsewhere.

Open design question to decide first: should a variable's lineage include downstream **consumer**
context at all (a separate "where the value flows after it is set" view), or should the lineage be
strictly "how it is set"? The fix above keeps consumers but removes the post-setter same-block
leak; a stricter product choice is `max_downstream_depth = 0`.
