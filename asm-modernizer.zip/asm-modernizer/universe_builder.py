#!/usr/bin/env python3
"""Variable Universe Builder - Pass 1

Discovers all permanent variables across ASM and C/C++ files.
Outputs universe JSON files for use in Pass 2.
"""

import argparse
import hashlib
import logging
import os
import pickle
import re
import signal
import sys
import tempfile
import time
import traceback
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

# Per-file timeout (seconds).  Configurable via FILE_TIMEOUT_SECONDS env var.
_FILE_TIMEOUT_SECONDS: int = int(os.environ.get("FILE_TIMEOUT_SECONDS", "300"))
_HAS_SIGALRM: bool = hasattr(signal, "SIGALRM")

# Number of C++ files to process in parallel.  Each file runs in its own
# child process (killed with SIGKILL on timeout) so tree-sitter's C runtime
# cannot block the build.  Set to 1 to disable parallelism.
_UNIVERSE_BUILD_WORKERS: int = int(
    os.environ.get("UNIVERSE_BUILD_WORKERS", str(min(os.cpu_count() or 4, 8)))
)

logger = logging.getLogger(__name__)

from models.variable_universe import VariableUniverse, VariableEntry, VariableLocation
from models.provenance import StatementProvenance
from tokenizer import ParsedLine, Tokenizer
from file_reader import FileReader
from macro_definition_parser import MacroDefinitionParser
from statement_id_generator import StatementIDGenerator
from multi_file.c_family_analyzer import CFamilyAnalyzer
from source_discovery import filter_discovered_paths, merge_discovery_exclude_patterns


# File extension mappings
ASM_EXTENSIONS = {".asm", ".mac", ".s", ".cpy", ".copy"}
CPP_EXTENSIONS = {".cpp", ".cc", ".cxx", ".c", ".h", ".hpp"}
SECTION_OPCODES = {"CSECT", "DSECT", "RSECT"}
# Opcodes that keep a parameter-established DSECT region open (storage layout and
# listing directives).  Any other opcode is treated as executable and closes the
# region — see _update_scope_context / BEGIN ...,DSECT= handling.
_DSECT_LAYOUT_OPCODES = {
    "DS", "DC", "EQU", "ORG", "DXD", "CNOP", "LTORG", "SPACE", "EJECT", "PRINT", "TITLE",
}
# A real instruction/macro mnemonic: letters then alphanumerics.  Continued macro
# operand fragments (e.g. "BASELESS=YES") and keyword args contain "=" and never
# match, so they don't prematurely close a parameter-established DSECT region.
_INSTRUCTION_OPCODE_RE = re.compile(r"^[A-Z][A-Z0-9]*$")

# A well-formed HLASM ordinary symbol: uppercase letters, digits, and $ # @ _ ,
# starting with a non-digit.  Clean .asm sources contain zero lowercase labels,
# so anything else (mixed case, leading punctuation) is parser/source corruption.
_ASM_SYMBOL_RE = re.compile(r"^[A-Z@#$_][A-Z0-9@#$_]*$")
# Macro-parameter token, e.g. &A or &SUFFIX, used to suffix control-block fields
# inside mapping macros (LM1BID&A).  Stripped to recover the runtime field name.
_MACRO_PARAM_TOKEN_RE = re.compile(r"&[A-Za-z][A-Za-z0-9_]*")


@dataclass
class AsmScopeContext:
    """Tracks active ASM section/macro scopes while scanning lines."""

    module_scope: str
    section_stack: List[str] = field(default_factory=list)
    macro_stack: List[str] = field(default_factory=list)
    awaiting_macro_prototype: bool = False
    in_dsect: bool = False  # True while the active section is a DSECT (control block)
    dsect_via_param: bool = False  # in_dsect was opened by a DSECT= macro parameter

    def current_scope(self) -> str:
        if self.macro_stack:
            return self.macro_stack[-1]
        if self.section_stack:
            return self.section_stack[-1]
        return "global"

    def scope_chain(self) -> List[str]:
        chain = [f"module:{self.module_scope}"]
        chain.extend(f"section:{section}" for section in self.section_stack)
        chain.extend(f"macro:{macro}" for macro in self.macro_stack)
        return chain


def is_asm_file(filepath: Path) -> bool:
    """Check if file is an ASM file."""
    return filepath.suffix.lower() in ASM_EXTENSIONS


def is_cpp_file(filepath: Path) -> bool:
    """Check if file is a C/C++ file."""
    return filepath.suffix.lower() in CPP_EXTENSIONS


def _cpp_file_subprocess_worker(file_path_str: str, result_file_str: str) -> None:
    """Run in a subprocess to process one C++ file.

    SIGALRM cannot interrupt tree-sitter's C runtime, so the caller spawns this
    function in a child process and kills it with SIGKILL if it exceeds the per-file
    budget.  Results are written as JSON to *result_file_str* so the parent can
    reconstruct the VariableUniverse entries without any IPC pipe-buffer limits.

    Must be defined at module level so it is picklable for both 'fork' and
    'spawn' multiprocessing start methods.
    """
    _t0 = time.monotonic()
    _pid = os.getpid()
    _name = Path(file_path_str).name
    print(f"[C++ worker pid={_pid}] START: {_name}", flush=True)
    try:
        sub_builder = UniverseBuilder()
        sub_builder.process_cpp_file(Path(file_path_str))
        data = sub_builder.cpp_universe.to_dict()
        Path(result_file_str).write_text(
            __import__("json").dumps(data, separators=(",", ":")),
            encoding="utf-8",
        )
        print(
            f"[C++ worker pid={_pid}] DONE: elapsed={time.monotonic() - _t0:.2f}s {_name}",
            flush=True,
        )
    except Exception as exc:
        print(
            f"[C++ worker pid={_pid}] ERROR: {type(exc).__name__}: {exc} file={_name}",
            flush=True,
        )
        Path(result_file_str).write_text(
            __import__("json").dumps({"__error__": f"{type(exc).__name__}: {exc}"}),
            encoding="utf-8",
        )


class UniverseBuilder:
    """Builds variable universes for ASM and C/C++ files."""

    def __init__(self):
        self.asm_universe = VariableUniverse()
        self.cpp_universe = VariableUniverse()
        self.current_scope = None
        self._macro_parser = MacroDefinitionParser()
        # Maps file_key → pickle cache path (str) instead of holding all
        # line_contexts in RAM.  Each file's data is serialised to a temp dir
        # immediately after parsing so only one file's lines live in memory
        # at a time.  _populate_asm_usage_locations loads them back one-by-one.
        self._asm_lines_by_file: Dict[str, str] = {}
        self._asm_lines_cache_dir: Optional[Path] = Path(tempfile.mkdtemp(prefix="ub_lines_"))
        self._asm_processing_issues: Dict[str, List[str]] = defaultdict(list)

    def build(self, source_files: List[Path]) -> None:
        """Build universes from source files.

        ASM files are processed sequentially (SIGALRM-based per-file timeout —
        pure Python so the signal fires reliably).

        C++ files are processed in a parallel process pool: up to
        UNIVERSE_BUILD_WORKERS child processes run concurrently.  Each child
        is killed with SIGKILL if it exceeds FILE_TIMEOUT_SECONDS so that
        tree-sitter's C runtime cannot block the build indefinitely.

        Post-processing (_populate_asm_usage_locations) is guarded by a
        second SIGALRM timeout and a SIG_DFL restore so Celery's own
        soft-time-limit alarm is not cancelled.
        """
        total = len(source_files)
        logger.info(
            "[UB] Build start — total_files=%d workers=%d file_timeout=%ds",
            total, _UNIVERSE_BUILD_WORKERS, _FILE_TIMEOUT_SECONDS,
        )
        print(f"Building variable universes from {total} files...")

        asm_files = [f for f in source_files if is_asm_file(f)]
        cpp_files = [f for f in source_files if is_cpp_file(f)]
        other_files = [
            f for f in source_files if not is_asm_file(f) and not is_cpp_file(f)
        ]
        logger.info(
            "[UB] File breakdown — asm=%d cpp=%d other=%d",
            len(asm_files), len(cpp_files), len(other_files),
        )
        for f in other_files:
            logger.warning("[UB] Skipping unknown file type: %s", f)
            print(f"Skipping unknown file type: {f}")

        # -------------------------------------------------------------------
        # Per-file exception types and signal handlers
        # -------------------------------------------------------------------
        class _FileTimeout(Exception):
            pass

        class _PostProcessTimeout(Exception):
            pass

        def _asm_alarm_handler(signum, frame):
            raise _FileTimeout()

        def _post_alarm_handler(signum, frame):
            raise _PostProcessTimeout()

        skipped: List[str] = []
        _build_start = time.monotonic()

        # -------------------------------------------------------------------
        # Phase 1/3 — ASM files (sequential, SIGALRM works for pure Python)
        # -------------------------------------------------------------------
        logger.info("[UB ASM] Phase 1/3 start — files=%d", len(asm_files))
        for idx, file_path in enumerate(asm_files, 1):
            try:
                size_kb = file_path.stat().st_size // 1024
            except OSError:
                size_kb = 0
            logger.info(
                "[UB ASM] [%d/%d] START — %s (%d KB)",
                idx, len(asm_files), file_path.name, size_kb,
            )
            _t = time.monotonic()
            if _HAS_SIGALRM:
                signal.signal(signal.SIGALRM, _asm_alarm_handler)
                signal.alarm(_FILE_TIMEOUT_SECONDS)
            try:
                self.process_asm_file(file_path)
                elapsed = time.monotonic() - _t
                logger.info(
                    "[UB ASM] [%d/%d] DONE — elapsed=%.2fs %s",
                    idx, len(asm_files), elapsed, file_path.name,
                )
            except _FileTimeout:
                elapsed = time.monotonic() - _t
                logger.warning(
                    "[UB ASM] [%d/%d] TIMEOUT — after=%.1fs %s",
                    idx, len(asm_files), elapsed, file_path,
                )
                print(f"WARNING: TIMEOUT after {_FILE_TIMEOUT_SECONDS}s: {file_path}", flush=True)
                skipped.append(str(file_path))
            except Exception as e:
                elapsed = time.monotonic() - _t
                logger.warning(
                    "[UB ASM] [%d/%d] ERROR — elapsed=%.2fs %s: %s",
                    idx, len(asm_files), elapsed, file_path, e,
                )
                print(f"Error processing {file_path}: {e}", flush=True)
                skipped.append(str(file_path))
            finally:
                if _HAS_SIGALRM:
                    signal.alarm(0)

            if idx % 25 == 0 or idx == len(asm_files):
                logger.info(
                    "[UB ASM] Progress: %d/%d (%.0f%%) — total_elapsed=%.1fs",
                    idx, len(asm_files), idx * 100 / len(asm_files),
                    time.monotonic() - _build_start,
                )

        asm_skipped = len(skipped)
        logger.info(
            "[UB ASM] Phase 1/3 complete — processed=%d skipped=%d elapsed=%.1fs",
            len(asm_files) - asm_skipped, asm_skipped,
            time.monotonic() - _build_start,
        )

        # -------------------------------------------------------------------
        # Phase 2/3 — C++ files (parallel process pool, SIGKILL on timeout)
        #
        # Processes are managed directly in the main thread (no ThreadPool)
        # so fork() is never called from a non-main thread, avoiding any
        # lock-inheritance hazards.
        # -------------------------------------------------------------------
        if cpp_files:
            _cpp_start = time.monotonic()
            cpp_done = 0
            cpp_skipped_count = 0
            logger.info(
                "[UB C++] Phase 2/3 start — files=%d workers=%d timeout=%ds",
                len(cpp_files), _UNIVERSE_BUILD_WORKERS, _FILE_TIMEOUT_SECONDS,
            )

            # active: result_path -> (pid, file_path, start_time)
            active: Dict[str, Any] = {}
            pending = list(reversed(cpp_files))  # .pop() yields the first item

            while pending or active:
                # Fill available worker slots
                while len(active) < _UNIVERSE_BUILD_WORKERS and pending:
                    fp = pending.pop()
                    try:
                        size_kb = fp.stat().st_size // 1024
                    except OSError:
                        size_kb = 0
                    fd, rp = tempfile.mkstemp(suffix=".json", prefix="ub_cpp_")
                    os.close(fd)

                    # Use os.fork() directly.  multiprocessing.Process.start()
                    # raises AssertionError when the calling process is a daemon
                    # (Celery ForkPoolWorker).  os.fork() is a raw POSIX syscall
                    # with no such restriction.
                    pid = os.fork()
                    if pid == 0:
                        # ---- child process ----
                        # os._exit bypasses atexit handlers and avoids double-
                        # flushing shared file descriptors in the parent.
                        try:
                            _cpp_file_subprocess_worker(str(fp), rp)
                            os._exit(0)
                        except BaseException:
                            os._exit(1)
                    # ---- parent process ----
                    active[rp] = (pid, fp, time.monotonic())
                    logger.info(
                        "[UB C++] STARTED — pid=%d active=%d pending=%d file=%s (%d KB)",
                        pid, len(active), len(pending), fp.name, size_kb,
                    )

                # Brief sleep so we're not burning CPU on the poll loop
                if active:
                    time.sleep(0.1)

                now = time.monotonic()
                completed_keys: List[str] = []
                for rp, (pid, fp, t0) in list(active.items()):
                    elapsed = now - t0

                    # Non-blocking check: has this child exited?
                    try:
                        wpid, wstatus = os.waitpid(pid, os.WNOHANG)
                    except ChildProcessError:
                        wpid, wstatus = pid, 0  # already reaped elsewhere

                    if wpid != 0:
                        # Child exited — decode exit code
                        if os.WIFEXITED(wstatus):
                            exitcode = os.WEXITSTATUS(wstatus)
                        elif os.WIFSIGNALED(wstatus):
                            exitcode = -os.WTERMSIG(wstatus)
                        else:
                            exitcode = -1

                        completed_keys.append(rp)
                        cpp_done += 1
                        if exitcode == 0:
                            logger.info(
                                "[UB C++] [%d/%d] DONE — elapsed=%.2fs pid=%d %s",
                                cpp_done, len(cpp_files), elapsed, pid, fp.name,
                            )
                            self._merge_cpp_result_file(rp, fp)
                        else:
                            logger.warning(
                                "[UB C++] [%d/%d] CRASHED — exitcode=%d elapsed=%.2fs %s",
                                cpp_done, len(cpp_files), exitcode, elapsed, fp,
                            )
                            print(
                                f"WARNING: C++ worker crashed (exitcode={exitcode}): {fp}",
                                flush=True,
                            )
                            skipped.append(str(fp))
                            cpp_skipped_count += 1

                    elif elapsed > _FILE_TIMEOUT_SECONDS:
                        completed_keys.append(rp)
                        cpp_done += 1
                        try:
                            os.kill(pid, signal.SIGKILL)
                            os.waitpid(pid, 0)  # reap the zombie
                        except OSError:
                            pass
                        logger.warning(
                            "[UB C++] [%d/%d] TIMEOUT — after=%.1fs pid=%d %s",
                            cpp_done, len(cpp_files), elapsed, pid, fp,
                        )
                        print(
                            f"WARNING: TIMEOUT after {_FILE_TIMEOUT_SECONDS}s: {fp}",
                            flush=True,
                        )
                        skipped.append(str(fp))
                        cpp_skipped_count += 1

                for rp in completed_keys:
                    del active[rp]
                    try:
                        os.unlink(rp)
                    except OSError:
                        pass

                if completed_keys and (cpp_done % 25 == 0 or cpp_done == len(cpp_files)):
                    logger.info(
                        "[UB C++] Progress: %d/%d (%.0f%%) — active=%d pending=%d "
                        "skipped=%d elapsed=%.1fs",
                        cpp_done, len(cpp_files), cpp_done * 100 / len(cpp_files),
                        len(active), len(pending), cpp_skipped_count,
                        time.monotonic() - _cpp_start,
                    )

            logger.info(
                "[UB C++] Phase 2/3 complete — processed=%d skipped=%d elapsed=%.1fs",
                len(cpp_files) - cpp_skipped_count, cpp_skipped_count,
                time.monotonic() - _cpp_start,
            )

        if skipped:
            logger.warning(
                "[UB] %d file(s) skipped (timeout or error): %s%s",
                len(skipped),
                [Path(s).name for s in skipped[:5]],
                " ..." if len(skipped) > 5 else "",
            )
            print(f"WARNING: {len(skipped)} file(s) were skipped (timeout or error).")

        # -------------------------------------------------------------------
        # Phase 3/3 — Post-processing
        # _populate_asm_usage_locations() is O(files × lines × tokens × vars)
        # and has no internal timeout — guard it here.
        # SIG_DFL restore avoids cancelling Celery's own soft-time-limit alarm.
        # -------------------------------------------------------------------
        _post_timeout = max(_FILE_TIMEOUT_SECONDS * 2, 120)
        asm_var_count_pre = len(self.asm_universe.variables)
        asm_lines_count = len(self._asm_lines_by_file)
        logger.info(
            "[UB POST] Phase 3/3 start — asm_vars=%d asm_files_cached=%d timeout=%ds",
            asm_var_count_pre, asm_lines_count, _post_timeout,
        )
        _post_phase_start = time.monotonic()

        if _HAS_SIGALRM:
            signal.signal(signal.SIGALRM, _post_alarm_handler)
            signal.alarm(_post_timeout)
        try:
            _t = time.monotonic()
            logger.info("[UB POST] Running _populate_equ_alias_groups...")
            self._populate_equ_alias_groups()
            logger.info(
                "[UB POST] _populate_equ_alias_groups done — elapsed=%.2fs",
                time.monotonic() - _t,
            )

            _t = time.monotonic()
            logger.info(
                "[UB POST] Running _populate_asm_usage_locations "
                "(asm_files=%d known_vars=%d)...",
                asm_lines_count, asm_var_count_pre,
            )
            self._populate_asm_usage_locations()
            logger.info(
                "[UB POST] _populate_asm_usage_locations done — elapsed=%.2fs",
                time.monotonic() - _t,
            )

            _t = time.monotonic()
            logger.info("[UB POST] Running _report_asm_processing_issues...")
            self._report_asm_processing_issues()
            logger.info(
                "[UB POST] _report_asm_processing_issues done — elapsed=%.2fs",
                time.monotonic() - _t,
            )
        except _PostProcessTimeout:
            logger.warning(
                "[UB POST] TIMEOUT after %ds — cross-reference data may be incomplete",
                _post_timeout,
            )
            print(
                f"WARNING: Post-processing timed out after {_post_timeout}s — "
                "cross-reference location data may be incomplete.",
                flush=True,
            )
        finally:
            if _HAS_SIGALRM:
                signal.alarm(0)
                signal.signal(signal.SIGALRM, signal.SIG_DFL)
            # Clean up the line-context pickle cache now that post-processing
            # is complete — no longer needed and can be several GB on large runs.
            try:
                import shutil
                if self._asm_lines_cache_dir and self._asm_lines_cache_dir.exists():
                    shutil.rmtree(self._asm_lines_cache_dir, ignore_errors=True)
                    self._asm_lines_by_file.clear()
                    logger.info("[UB POST] Line-context cache cleaned up.")
            except Exception:
                pass

        logger.info(
            "[UB POST] Phase 3/3 complete — elapsed=%.1fs",
            time.monotonic() - _post_phase_start,
        )

        total_elapsed = time.monotonic() - _build_start
        asm_var_count = len(self.asm_universe.get_variable_names())
        cpp_var_count = len(self.cpp_universe.get_variable_names())
        logger.info(
            "[UB] Build complete — asm_vars=%d cpp_vars=%d skipped=%d total_elapsed=%.1fs",
            asm_var_count, cpp_var_count, len(skipped), total_elapsed,
        )
        print(f"ASM universe: {asm_var_count} unique variables")
        print(f"C++ universe: {cpp_var_count} unique variables")

    def _is_placeholder_scope_label(self, label: Optional[str]) -> bool:
        """Heuristic for synthetic/internal section labels that should not become scope."""
        if not label:
            return True
        text = label.strip()
        if not text:
            return True
        if text.startswith("&"):
            return True
        if text.startswith("$") and text.endswith("$") and len(text) > 2:
            return True
        return False

    def _extract_section_name(self, line: ParsedLine) -> Optional[str]:
        """Extract section name from section directive line."""
        if line.label and not self._is_placeholder_scope_label(line.label):
            return line.label.strip()
        if line.operands:
            candidate = line.operands[0].strip()
            if candidate and "=" not in candidate and not self._is_placeholder_scope_label(candidate):
                return candidate
        return None

    def _dsect_param_name(self, line: ParsedLine) -> Optional[str]:
        """Return the DSECT name from a ``DSECT=<name>`` macro keyword parameter.

        The TPF segment prologue (``BEGIN ...,DSECT=WKSAV,...``) establishes a
        work-area DSECT via a macro parameter rather than a DSECT opcode.  The
        lookbehind rejects a macro-parameter default (``&DSECT=...``) and the
        value guard rejects the common ``DSECT=NO``/``DSECT=YES`` toggles.
        """
        opcode = (line.opcode or "").upper()
        if not opcode or opcode in SECTION_OPCODES:
            return None
        operand_text = ",".join(line.operands or []).upper()
        m = re.search(r"(?<![&\w@#$])DSECT=([A-Z@#$][A-Z0-9@#$_]*)", operand_text)
        if not m:
            return None
        name = m.group(1)
        if name in ("NO", "YES"):
            return None
        return name

    def _update_scope_context(self, line: ParsedLine, scope_context: AsmScopeContext) -> None:
        """Advance section/macro scope state using current line."""
        opcode = (line.opcode or "").upper()

        if opcode == "MACRO":
            scope_context.awaiting_macro_prototype = True
            return

        if scope_context.awaiting_macro_prototype:
            if line.opcode:
                macro_name = line.opcode.strip()
                if macro_name and macro_name.upper() not in {"MACRO", "MEND"}:
                    scope_context.macro_stack.append(macro_name)
                    scope_context.awaiting_macro_prototype = False

        if opcode == "MEND":
            if scope_context.macro_stack:
                scope_context.macro_stack.pop()
            scope_context.awaiting_macro_prototype = False
            return

        if opcode in SECTION_OPCODES:
            section_name = self._extract_section_name(line)
            if section_name:
                scope_context.section_stack = [section_name]
            # DSECT fields are control-block (block-ref) variables; CSECT/RSECT
            # switch back to ordinary code/data storage.
            scope_context.in_dsect = (opcode == "DSECT")
            scope_context.dsect_via_param = False
            return

        # TPF segment prologue: ``BEGIN ...,DSECT=NAME`` opens a work-area DSECT
        # via a macro parameter.  Open it here; it closes at the first executable
        # instruction (handled below) so later working storage stays `memory`.
        dsect_param = self._dsect_param_name(line)
        if dsect_param:
            scope_context.section_stack = [dsect_param]
            scope_context.in_dsect = True
            scope_context.dsect_via_param = True
            return

        if (
            scope_context.dsect_via_param
            and opcode not in _DSECT_LAYOUT_OPCODES
            and _INSTRUCTION_OPCODE_RE.match(opcode)
        ):
            # First real executable instruction ends the parameter DSECT region;
            # continuation fragments / keyword args (contain "=") are ignored.
            scope_context.in_dsect = False
            scope_context.dsect_via_param = False
            scope_context.section_stack = []

        if opcode == "END":
            scope_context.section_stack.clear()
            scope_context.macro_stack.clear()
            scope_context.awaiting_macro_prototype = False
            scope_context.in_dsect = False
            scope_context.dsect_via_param = False

    def _derive_asm_storage_class(self, scope_chain: List[str], declaration_type: str) -> str:
        """Return storage class for ASM declarations without conflating section-local and global."""
        if declaration_type in {"EXTRN", "WXTRN", "XTRN"}:
            return "extern"
        has_section_scope = any(scope.startswith("section:") for scope in scope_chain)
        if not has_section_scope:
            return "module"
        return "section_local"

    def process_asm_file(self, file_path: Path):
        """Process an ASM file and extract variables.

        Args:
            file_path: Path to ASM file
        """
        file_path = file_path.resolve()
        file_key = str(file_path)
        print(f"Processing ASM file: {file_key}")

        try:
            id_gen = StatementIDGenerator()
            search_paths = [str(file_path.parent)]
            candidate_macro_dirs = [
                file_path.parent.parent / "macros",
                file_path.parent.parent.parent / "macros" if len(file_path.parents) >= 3 else None,
            ]
            for macros_dir in candidate_macro_dirs:
                if macros_dir and macros_dir.exists():
                    search_paths.append(str(macros_dir))

            reader = FileReader(id_gen, search_paths=search_paths)
            parsed_lines = self._read_asm_lines_with_fallback(file_path, reader, id_gen)
            self._collect_macro_definitions(file_path)

            scope_context = AsmScopeContext(module_scope=file_path.stem)
            line_contexts: List[Tuple[ParsedLine, str, List[str]]] = []
            declarations_found = 0

            for line in parsed_lines:
                self._update_scope_context(line, scope_context)
                effective_scope = scope_context.current_scope()
                effective_chain = scope_context.scope_chain()
                line_contexts.append((line, effective_scope, effective_chain))
                if self._extract_asm_variables(
                    line, file_path, effective_scope, effective_chain, scope_context.in_dsect
                ):
                    declarations_found += 1

            # Serialize line_contexts to disk and record the path — avoids
            # holding all 11K+ files' parsed lines in memory simultaneously.
            _cache_key = hashlib.md5(file_key.encode()).hexdigest() + ".pkl"
            _cache_path = self._asm_lines_cache_dir / _cache_key
            try:
                with open(_cache_path, "wb") as _fh:
                    pickle.dump(line_contexts, _fh, protocol=pickle.HIGHEST_PROTOCOL)
                self._asm_lines_by_file[file_key] = str(_cache_path)
            except Exception as _exc:
                logger.warning("UB: could not cache lines for %s: %s", file_key, _exc)
                # Fall back: keep in memory for this file so post-processing still works.
                self._asm_lines_by_file[file_key] = line_contexts  # type: ignore[assignment]
            if declarations_found == 0:
                self._record_asm_issue(file_path, "No DS/DC/EQU/EXTRN/WXTRN declarations found.")

        except Exception as e:
            self._record_asm_issue(file_path, f"Failed to process file: {e}")
            traceback.print_exc()

    def _read_asm_lines_with_fallback(
        self,
        file_path: Path,
        reader: FileReader,
        id_gen: StatementIDGenerator,
    ) -> List[ParsedLine]:
        """Read ASM lines with COPY expansion, falling back to direct read when needed."""
        try:
            return list(reader.read_file(str(file_path)))
        except FileNotFoundError as e:
            self._record_asm_issue(
                file_path,
                f"{e} - continuing without COPY expansion.",
            )
            return self._read_main_asm_file(file_path, id_gen)
        except Exception as e:
            self._record_asm_issue(
                file_path,
                f"Reader failed ({e}); continuing without COPY expansion.",
            )
            return self._read_main_asm_file(file_path, id_gen)

    def _read_main_asm_file(self, file_path: Path, id_gen: StatementIDGenerator) -> List[ParsedLine]:
        """Read only the requested ASM file without COPY expansion."""
        tokenizer = Tokenizer()
        parsed_lines: List[ParsedLine] = []
        with open(file_path, "r", errors="replace") as f:
            for line_num, line_text in enumerate(f, 1):
                provenance = StatementProvenance(
                    statement_id=id_gen.next_id(),
                    original_file=str(file_path),
                    original_line=line_num,
                )
                parsed = tokenizer.tokenize_line(line_text.rstrip("\n"), provenance)
                parsed_lines.append(parsed)
        return parsed_lines

    def _collect_macro_definitions(self, file_path: Path) -> None:
        """Collect MACRO/MEND definitions from an ASM source file."""
        try:
            content = file_path.read_text(errors="replace")
            macros = self._macro_parser.parse_macro_definitions(content, file_path)
        except Exception as e:
            self._record_asm_issue(file_path, f"Failed to parse macro definitions: {e}")
            return

        for macro in macros:
            params = [param.name for param in macro.parameters]
            introduced = self._extract_macro_variables(macro.body, file_path, macro.start_line)
            self.asm_universe.add_macro_definition(
                name=macro.name,
                params=params,
                defined_in=str(file_path),
                variables_introduced=introduced,
            )

    def _extract_macro_variables(
        self,
        macro_body: List[str],
        file_path: Path,
        macro_start_line: int,
    ) -> List[str]:
        """Extract variables introduced within macro bodies (DS/DC/EQU labels)."""
        tokenizer = Tokenizer()
        introduced: Set[str] = set()
        for offset, body_line in enumerate(macro_body, start=1):
            provenance = StatementProvenance(
                statement_id=f"macro_{macro_start_line}_{offset}",
                original_file=str(file_path),
                original_line=macro_start_line + offset,
            )
            parsed = tokenizer.tokenize_line(body_line, provenance)
            opcode = (parsed.opcode or "").upper()
            if opcode not in ("DS", "DC", "EQU"):
                continue
            if not parsed.label or parsed.label.startswith("&"):
                continue
            introduced.add(parsed.label)
        return sorted(introduced)

    def _record_asm_issue(self, file_path: Path, message: str) -> None:
        file_key = str(file_path.resolve())
        self._asm_processing_issues[file_key].append(message)
        print(f"ASM issue [{file_key}]: {message}")

    def _report_asm_processing_issues(self) -> None:
        if not self._asm_processing_issues:
            return
        total = sum(len(messages) for messages in self._asm_processing_issues.values())
        print(f"ASM processing issues: {total}")
        for file_name, messages in sorted(self._asm_processing_issues.items()):
            for message in messages:
                print(f"  - {file_name}: {message}")

    def _infer_equ_data_type(self, value: Optional[str]) -> Optional[str]:
        """Infer EQU data type from equated expression."""
        if not value:
            return None

        token = value.strip()
        upper = token.upper()

        if re.fullmatch(r"[+-]?\d+", token):
            return "integer"
        if re.fullmatch(r"R(?:1[0-5]|[0-9])", upper):
            return "register"
        if re.fullmatch(r"[0-9]|1[0-5]", token):
            return "integer"
        if re.fullmatch(r"=?X'[^']*'", upper):
            return "hex"
        if re.fullmatch(r"=?C'[^']*'", upper):
            return "string"
        if re.fullmatch(r"=?[FAHVDP]'[^']*'", upper):
            return "literal"
        if re.fullmatch(r"[#.&@$A-Z_][A-Z0-9_.$@#&]*", upper):
            return "symbol"
        return "expression"

    def _strip_quoted_literals(self, text: str) -> str:
        """Remove quoted literals so symbolic token extraction does not over-capture."""
        text = re.sub(r"[A-Za-z]?\'(?:[^\']|\'\')*\'", " ", text)
        text = re.sub(r"\"(?:[^\"]|\"\")*\"", " ", text)
        return text

    def _extract_symbol_tokens(self, text: str) -> Set[str]:
        """Extract potential symbol tokens from an ASM expression."""
        if not text:
            return set()

        cleaned = self._strip_quoted_literals(text)
        candidates = re.findall(r"[#.&@$A-Za-z_][A-Za-z0-9_.$@#&]*", cleaned)
        ignore = {"EQ", "NE", "LT", "LE", "GT", "GE", "AND", "OR", "NOT"}

        symbols = set()
        for candidate in candidates:
            upper = candidate.upper()
            if upper in ignore:
                continue
            if re.fullmatch(r"R(?:1[0-5]|[0-9])", upper):
                continue
            symbols.add(candidate)
        return symbols

    def _extract_extern_symbol_name(self, operand: str) -> Optional[str]:
        """Extract clean external symbol name from EXTRN/WXTRN operand."""
        cleaned = operand.strip().rstrip(",")
        if not cleaned:
            return None

        if "=" in cleaned and not cleaned.startswith("="):
            cleaned = cleaned.split("=", 1)[0].strip()

        match = re.match(r"[#.&@$A-Za-z_][A-Za-z0-9_.$@#&]*", cleaned)
        if not match:
            return None
        return match.group(0)

    def _extract_equ_related_symbols(self, label: str, value: Optional[str]) -> List[str]:
        """Extract symbols referenced by an EQU expression."""
        if not value:
            return []
        related = set()
        for token in self._extract_symbol_tokens(value):
            if token.upper() == label.upper():
                continue
            related.add(token)
        return sorted(related)

    def _extract_equ_aliases(self, value: Optional[str]) -> List[str]:
        """Extract direct alias targets for an EQU value."""
        if not value:
            return []

        token = value.strip().upper()
        if re.fullmatch(r"R(?:1[0-5]|[0-9])", token):
            return [token]
        if re.fullmatch(r"[0-9]|1[0-5]", token):
            return [f"R{int(token)}"]
        return []

    def _normalize_asm_label(self, label: Optional[str]) -> Optional[str]:
        """Return the runtime base symbol for *label*, stripping macro params.

        Control-block mapping macros define fields like ``LM1BID&A`` where ``&A``
        is a macro parameter; the runtime field is ``LM1BID``.  Pure macro
        artifacts such as ``&A`` or ``&LABEL`` normalize to nothing and are
        rejected by the caller.
        """
        if not label:
            return None
        name = label.strip()
        if "&" in name:
            # Keep only the text preceding the first macro-parameter token.
            name = _MACRO_PARAM_TOKEN_RE.split(name, 1)[0].replace("&", "")
        return name.strip() or None

    def _is_valid_asm_symbol(self, name: Optional[str]) -> bool:
        """True when *name* is a well-formed HLASM ordinary symbol.

        Rejects parser/source-corruption artifacts (mixed case, leading
        punctuation, bare digits) that otherwise pollute the inventory.
        """
        return bool(name) and bool(_ASM_SYMBOL_RE.match(name))

    def _asm_kind(
        self,
        declaration_type: str,
        *,
        from_macro_template: bool,
        in_dsect: bool,
    ) -> str:
        """Resolve a coherent, mutually-exclusive kind for an ASM symbol.

        - external      : EXTRN / WXTRN / XTRN
        - constant      : EQU equates (values, masks, offsets, register aliases)
        - block_ref     : DS / DC field of a control block (DSECT or mapping macro)
        - memory        : DS / DC ordinary storage
        """
        if declaration_type in ("EXTRN", "WXTRN", "XTRN"):
            return "external"
        if declaration_type == "EQU":
            return "constant"
        if in_dsect or from_macro_template:
            return "block_ref"
        return "memory"

    def _metadata_for_asm_symbol(
        self,
        original_label: str,
        *,
        from_macro_template: bool,
        in_dsect: bool,
        **extra: object,
    ) -> Dict[str, object]:
        """Build standardized metadata for ASM symbols."""
        metadata: Dict[str, object] = dict(extra)
        metadata["from_macro_template"] = from_macro_template
        metadata["in_control_block"] = in_dsect
        # All retained ASM symbols are real runtime symbols now that macro
        # artifacts and malformed labels are rejected at extraction.  Kept for
        # downstream consumers that filter on this flag (e.g. the demo variable
        # inventory pipeline).
        metadata["is_runtime_symbol"] = True
        return metadata

    def _is_runtime_asm_symbol_entry(self, entry: VariableEntry) -> bool:
        """Predicate for symbols that should appear in flat runtime names lists.

        Macro artifacts and malformed labels are now rejected at extraction, so
        every retained ``self.variables`` entry is a real runtime symbol.
        """
        return entry.kind != "external"

    def _add_location_if_missing(self, entry: VariableEntry, location: VariableLocation) -> None:
        for existing in entry.all_locations:
            if (
                existing.file == location.file
                and existing.line == location.line
                and existing.context == location.context
            ):
                return
        entry.all_locations.append(location)

    def _select_reference_targets(
        self,
        name: str,
        file_name: str,
        scope: str,
    ) -> List[VariableEntry]:
        entries = self.asm_universe.get_variable_entries(name)
        if not entries:
            return []

        same_file = [entry for entry in entries if entry.file == file_name]
        if not same_file:
            same_file = entries

        same_scope = [entry for entry in same_file if entry.scope == scope]
        if same_scope:
            return same_scope

        global_scope = [entry for entry in same_file if entry.scope == "global"]
        if global_scope:
            return global_scope

        return same_file

    def _extract_reference_tokens(self, line: ParsedLine) -> Set[str]:
        tokens: Set[str] = set()
        for operand in line.operands:
            cleaned = operand.strip().rstrip(",")
            if cleaned:
                tokens.add(cleaned)
            tokens.update(self._extract_symbol_tokens(operand))
        return tokens

    def _populate_asm_usage_locations(self) -> None:
        """Populate `all_locations` with reference sites across all ASM files.

        Hot-loop fix (prod-scale O(N^2) -> O(N)): the original implementation called
        `_add_location_if_missing`, which scans `entry.all_locations` linearly per add. For
        symbols referenced thousands of times the per-entry list scan dominates. We instead
        memo a per-entry set of `(file, line, context)` triples seeded from the entry's
        current locations, so the membership check is O(1) per add. Same append order,
        same final state -> byte-identical universe."""
        if not self._asm_lines_by_file:
            return

        known_names = set(self.asm_universe.variables.keys()) | set(self.asm_universe.extern_symbols.keys())
        if not known_names:
            return

        names_by_upper: Dict[str, List[str]] = defaultdict(list)
        for name in known_names:
            names_by_upper[name.upper()].append(name)

        # Per-entry seen-set memo: id(entry) -> set of (file, line, context) tuples.
        # Seeded lazily from entry.all_locations on first touch.
        seen_locations: Dict[int, Set[Tuple[str, int, str]]] = {}

        def _add_seen(entry: "VariableEntry", file: str, line: int, ctx: str) -> None:
            key = id(entry)
            s = seen_locations.get(key)
            if s is None:
                s = {(loc.file, loc.line, loc.context) for loc in entry.all_locations}
                seen_locations[key] = s
            tup = (file, line, ctx)
            if tup in s:
                return
            s.add(tup)
            entry.all_locations.append(VariableLocation(file, line, ctx))

        for _, _lc_ref in self._asm_lines_by_file.items():
            # _lc_ref is either a cache path (str) or the raw list (fallback).
            if isinstance(_lc_ref, str):
                try:
                    with open(_lc_ref, "rb") as _fh:
                        line_contexts = pickle.load(_fh)
                except Exception as _exc:
                    logger.warning("UB: could not load cached lines from %s: %s", _lc_ref, _exc)
                    continue
            else:
                line_contexts = _lc_ref
            for line, scope, _ in line_contexts:
                line_num = line.provenance.original_line if hasattr(line, "provenance") else 0
                line_file = line.provenance.original_file if hasattr(line, "provenance") else ""
                opcode = (line.opcode or "").upper()

                definition_name = None
                if opcode in ("DS", "DC", "EQU") and line.label:
                    definition_name = line.label

                for token in self._extract_reference_tokens(line):
                    canonical_names = names_by_upper.get(token.upper(), [])
                    if not canonical_names:
                        continue

                    for canonical_name in canonical_names:
                        if definition_name and canonical_name.upper() == definition_name.upper():
                            continue

                        for entry in self._select_reference_targets(canonical_name, line_file, scope):
                            _add_seen(entry, line_file, line_num, "reference")

                        extern_entry = self.asm_universe.extern_symbols.get(canonical_name)
                        if extern_entry:
                            _add_seen(extern_entry, line_file, line_num, "reference")

    def _canonical_equ_alias_target(self, value: Optional[str]) -> Optional[str]:
        if not value:
            return None
        token = value.strip().upper()
        if re.fullmatch(r"R(?:1[0-5]|[0-9])", token):
            return f"register:{token}"
        if re.fullmatch(r"[0-9]|1[0-5]", token):
            return f"register:R{int(token)}"
        if re.fullmatch(r"[#.&@$A-Z_][A-Z0-9_.$@#&]*", token):
            return f"symbol:{token}"
        return None

    def _populate_equ_alias_groups(self) -> None:
        """Populate aliased_as for EQU definitions that share same alias target."""
        groups: Dict[str, List[VariableEntry]] = defaultdict(list)
        for entries in self.asm_universe.variables.values():
            for entry in entries:
                if entry.declaration_type != "EQU":
                    continue
                target = self._canonical_equ_alias_target(entry.initial_value)
                if target:
                    groups[target].append(entry)

        for alias_entries in groups.values():
            if len(alias_entries) <= 1:
                continue
            names = [entry.name for entry in alias_entries]
            for entry in alias_entries:
                for alias_name in names:
                    if alias_name == entry.name:
                        continue
                    if alias_name not in entry.aliased_as:
                        entry.aliased_as.append(alias_name)
                entry.aliased_as.sort()

    def _extract_asm_variables(
        self,
        line: ParsedLine,
        file_path: Path,
        scope: str,
        scope_chain: List[str],
        in_dsect: bool = False,
    ) -> bool:
        """Extract variables from a single ASM line.

        Labels are normalized (macro-parameter tokens stripped) and validated as
        well-formed HLASM symbols before entering the universe, so macro template
        fragments (``LM1BID&A`` → ``LM1BID``) and parser/source-corruption
        artifacts (``(HIAS&A``, ``26h``) never reach the inventory.

        Args:
            line: Parsed line
            file_path: Source file path
            scope: Current scope
            scope_chain: Active module/section/macro scope chain
            in_dsect: True when the active section is a DSECT control block
        """
        if not line.opcode:
            return False

        opcode_upper = line.opcode.upper()
        file_str = (
            line.provenance.original_file
            if hasattr(line, "provenance") and line.provenance
            else str(file_path)
        )
        line_num = line.provenance.original_line if hasattr(line, 'provenance') else 0

        if opcode_upper in ("DS", "DC", "EQU") and line.label:
            from_macro_template = "&" in line.label
            name = self._normalize_asm_label(line.label)
            if not self._is_valid_asm_symbol(name):
                return False

            kind = self._asm_kind(
                opcode_upper,
                from_macro_template=from_macro_template,
                in_dsect=in_dsect,
            )
            metadata = self._metadata_for_asm_symbol(
                line.label,
                from_macro_template=from_macro_template,
                in_dsect=in_dsect,
                introduced_via="direct_declaration",
            )

            data_type = line.operands[0] if line.operands else None
            initial_value = None
            aliased_as: List[str] = []
            related_symbols: List[str] = []

            if opcode_upper == "DC":
                metadata["is_constant"] = True
                if data_type and "'" in data_type:
                    # Format like F'0' or CL100'HELLO'
                    parts = data_type.split("'")
                    if len(parts) >= 2:
                        initial_value = parts[1]
            elif opcode_upper == "EQU":
                value = line.operands[0] if line.operands else None
                data_type = self._infer_equ_data_type(value)
                initial_value = value
                aliased_as = self._extract_equ_aliases(value)
                related_symbols = self._extract_equ_related_symbols(name, value)

            entry = VariableEntry(
                name=name,
                kind=kind,
                scope=scope,
                file=file_str,
                line=line_num,
                declaration_type=opcode_upper,
                data_type=data_type,
                storage_class=self._derive_asm_storage_class(scope_chain, opcode_upper),
                initial_value=initial_value,
                aliased_as=aliased_as,
                related_symbols=related_symbols,
                metadata=metadata,
            )
            self._add_location_if_missing(entry, VariableLocation(file_str, line_num, "definition"))
            entry.scope_chain = list(scope_chain)
            self.asm_universe.add_variable(entry)
            return True

        # EXTRN (External Reference) - External variable
        elif opcode_upper in ("EXTRN", "WXTRN", "XTRN"):
            if line.operands:
                added = False
                for operand in line.operands:
                    name = self._normalize_asm_label(self._extract_extern_symbol_name(operand))
                    if not self._is_valid_asm_symbol(name):
                        continue
                    entry = VariableEntry(
                        name=name,
                        kind="external",
                        scope="global",
                        file=file_str,
                        line=line_num,
                        declaration_type=opcode_upper,
                        storage_class=self._derive_asm_storage_class([], opcode_upper),
                        metadata={
                            "introduced_via": "external_declaration",
                            "symbol_type": "unknown"  # Could be data or function
                        }
                    )
                    self._add_location_if_missing(entry, VariableLocation(file_str, line_num, "declaration"))
                    self.asm_universe.add_extern_symbol(name, entry)
                    added = True
                return added

        return False

    def _is_cpp_variable_kind(self, kind: str) -> bool:
        return kind in {"variable", "parameter", "member", "global"}

    def _unique_sorted(self, values: List[str]) -> List[str]:
        seen: Set[str] = set()
        result: List[str] = []
        for value in values:
            token = (value or "").strip()
            if not token or token in seen:
                continue
            seen.add(token)
            result.append(token)
        return sorted(result)

    def _parse_cpp_scope_and_name(
        self,
        qualified_name: str,
        metadata: Dict[str, Any],
    ) -> Tuple[str, str, List[str]]:
        name_text = (qualified_name or "").strip()
        if not name_text:
            return "global", "", []

        if "::" not in name_text:
            inferred_scope = metadata.get("enclosing_function") or metadata.get("scope") or "global"
            return str(inferred_scope), name_text, []

        parts = [part for part in name_text.split("::") if part]
        if not parts:
            return "global", name_text, []

        base_name = parts[-1]
        scope_parts = parts[:-1]
        scope = "::".join(scope_parts) if scope_parts else "global"
        return scope, base_name, scope_parts

    def _is_cpp_symbol_name(self, name: str) -> bool:
        token = (name or "").strip()
        if not token:
            return False
        if not re.fullmatch(r"[A-Za-z_]\w*", token):
            return False
        reserved = {
            "if", "for", "while", "switch", "return", "sizeof", "alignof",
            "static_cast", "reinterpret_cast", "const_cast", "dynamic_cast",
            "nullptr", "true", "false",
        }
        return token not in reserved

    def _sanitize_cpp_scope(
        self,
        raw_scope: Optional[str],
        file_str: str,
        *,
        function_name: Optional[str] = None,
        enclosing_type: Optional[str] = None,
        kind: Optional[str] = None,
    ) -> str:
        if function_name:
            return function_name
        if kind == "member" and enclosing_type:
            return enclosing_type

        scope = (raw_scope or "").strip()
        if not scope:
            return "file"
        if scope in {"global", "static", "extern"}:
            return "file"
        if scope in {"local", "local_static"}:
            return function_name or "file"
        if scope == "member":
            return enclosing_type or "member"
        if scope == file_str:
            return "file"
        if "/" in scope or "\\" in scope:
            # Avoid path-like fallback scopes leaking into universe output.
            if scope.endswith((".c", ".cc", ".cpp", ".cxx", ".h", ".hpp")):
                return "file"
        if scope.startswith("//"):
            return "file"
        return scope

    def _cpp_entry_key(self, entry: VariableEntry) -> Tuple[str, str, int, str, str]:
        return (entry.name, entry.file, entry.line, entry.scope, entry.kind)

    def _is_cpp_symbol_declaration_entry(self, entry: VariableEntry) -> bool:
        return (
            entry.scope in {"file", "global", "static", "extern"}
            or entry.storage_class in {"file", "global", "static", "extern"}
            or (entry.declaration_type or "").lower() in {
                "const",
                "extern",
                "static",
                "global",
                "extern_linkage",
                "thread_local",
            }
        )

    def _upsert_cpp_entry(self, entry: VariableEntry) -> None:
        existing_entries = self.cpp_universe.get_variable_entries(entry.name)
        for existing in existing_entries:
            if self._cpp_entry_key(existing) != self._cpp_entry_key(entry):
                continue
            for location in entry.all_locations:
                self._add_location_if_missing(existing, location)
            existing.aliased_as = self._unique_sorted(existing.aliased_as + entry.aliased_as)
            existing.related_symbols = self._unique_sorted(existing.related_symbols + entry.related_symbols)
            merged_metadata = dict(existing.metadata or {})
            merged_metadata.update(entry.metadata or {})
            existing.metadata = merged_metadata
            if not existing.declaration_type and entry.declaration_type:
                existing.declaration_type = entry.declaration_type
            if not existing.data_type and entry.data_type:
                existing.data_type = entry.data_type
            if not existing.storage_class and entry.storage_class:
                existing.storage_class = entry.storage_class
            if not existing.initial_value and entry.initial_value:
                existing.initial_value = entry.initial_value
            if not existing.scope_chain and entry.scope_chain:
                existing.scope_chain = list(entry.scope_chain)
            return

        self.cpp_universe.add_variable(entry)

    def _merge_cpp_result_file(self, result_path: str, file_path: Path) -> None:
        """Read the JSON written by _cpp_file_subprocess_worker and merge into cpp_universe.

        If the subprocess reported an error the result file will contain
        ``{"__error__": "..."}`` — log a warning and skip rather than crashing
        the whole build.
        """
        import json as _json

        try:
            raw = Path(result_path).read_text(encoding="utf-8")
        except OSError as exc:
            print(f"WARNING: Could not read C++ result file for {file_path}: {exc}", flush=True)
            return

        try:
            data = _json.loads(raw)
        except _json.JSONDecodeError as exc:
            print(f"WARNING: C++ result JSON corrupt for {file_path}: {exc}", flush=True)
            return

        if "__error__" in data:
            print(
                f"WARNING: C++ worker reported error for {file_path}: {data['__error__']}",
                flush=True,
            )
            return

        for _name, entries in data.get("variables", {}).items():
            for entry_dict in entries:
                entry = VariableEntry(
                    name=entry_dict["name"],
                    kind=entry_dict["kind"],
                    scope=entry_dict["scope"],
                    file=entry_dict["file"],
                    line=entry_dict["line"],
                    declaration_type=entry_dict.get("declaration_type"),
                    data_type=entry_dict.get("data_type"),
                    storage_class=entry_dict.get("storage_class"),
                    initial_value=entry_dict.get("initial_value"),
                    all_locations=[
                        VariableLocation(loc["file"], loc["line"], loc["context"])
                        for loc in entry_dict.get("all_locations", [])
                    ],
                    scope_chain=entry_dict.get("scope_chain", []),
                    aliased_as=entry_dict.get("aliased_as", []),
                    related_symbols=entry_dict.get("related_symbols", []),
                    metadata=entry_dict.get("metadata", {}),
                )
                self._upsert_cpp_entry(entry)

        for ext_name, entry_dict in data.get("extern_symbols", {}).items():
            entry = VariableEntry(
                name=entry_dict["name"],
                kind=entry_dict["kind"],
                scope=entry_dict["scope"],
                file=entry_dict["file"],
                line=entry_dict["line"],
                declaration_type=entry_dict.get("declaration_type"),
                data_type=entry_dict.get("data_type"),
                storage_class=entry_dict.get("storage_class"),
                initial_value=entry_dict.get("initial_value"),
                all_locations=[
                    VariableLocation(loc["file"], loc["line"], loc["context"])
                    for loc in entry_dict.get("all_locations", [])
                ],
                scope_chain=entry_dict.get("scope_chain", []),
                aliased_as=entry_dict.get("aliased_as", []),
                related_symbols=entry_dict.get("related_symbols", []),
                metadata=entry_dict.get("metadata", {}),
            )
            self.cpp_universe.add_extern_symbol(ext_name, entry)

    def _best_cpp_line_for_node(self, node_id: str, edges: List[dict]) -> int:
        define_lines = [
            int(edge.get("line", 0) or 0)
            for edge in edges
            if edge.get("relation") == "define"
            and (edge.get("target") == node_id or edge.get("source") == node_id)
            and int(edge.get("line", 0) or 0) > 0
        ]
        if define_lines:
            return min(define_lines)

        edge_lines = [
            int(edge.get("line", 0) or 0)
            for edge in edges
            if (edge.get("target") == node_id or edge.get("source") == node_id)
            and int(edge.get("line", 0) or 0) > 0
        ]
        if edge_lines:
            return min(edge_lines)

        return 0

    def _cpp_storage_class_for_entry(self, kind: str, scope: str, metadata: Dict[str, Any]) -> str:
        storage = (metadata.get("storage_class") or "").strip()
        if storage:
            return storage
        decl_type = str(metadata.get("declaration_type") or "").strip().lower()
        if decl_type == "extern":
            return "extern"
        if kind == "parameter":
            return "parameter"
        if kind == "member":
            return "member"
        if scope.endswith("::static") or decl_type == "static":
            return "static"
        if scope in ("global", "extern", "static"):
            return scope
        return "local"

    def _best_cpp_line_for_name(self, name: str, edges: List[dict], nodes: List[dict]) -> int:
        node_ids = {
            node.get("id", "")
            for node in nodes
            if name in self._candidate_names_from_lineage_label(node.get("name", ""))
        }
        lines: List[int] = []
        for edge in edges:
            line_num = int(edge.get("line", 0) or 0)
            if line_num <= 0:
                continue
            source = edge.get("source", "")
            target = edge.get("target", "")
            if source in node_ids or target in node_ids:
                lines.append(line_num)
        if lines:
            return min(lines)
        return 0

    def _candidate_names_from_lineage_label(self, label: str) -> List[str]:
        raw = (label or "").strip()
        if not raw:
            return []
        if raw.startswith("use@") or raw.startswith("return@") or raw.startswith("arg@"):
            return []
        if "#" in raw:
            return []

        work = raw.lstrip("*&").strip()
        variants = {work}
        if "::" in work:
            variants.add(work.split("::")[-1])
        if "->" in work:
            variants.add(work.rsplit("->", 1)[-1])
            variants.add(work.split("->", 1)[0].split("::")[-1])
        if "." in work:
            variants.add(work.rsplit(".", 1)[-1])
            variants.add(work.split(".", 1)[0].split("::")[-1])
        if "[" in work:
            variants.add(work.split("[", 1)[0].split("::")[-1])

        tokens: List[str] = []
        for variant in variants:
            for token in re.findall(r"[A-Za-z_]\w*", variant):
                if self._is_cpp_symbol_name(token):
                    tokens.append(token)
        return self._unique_sorted(tokens)

    def _extract_cpp_from_declarations(
        self,
        translation_unit: Any,
        file_path: Path,
        edges: List[dict],
        nodes: List[dict],
    ) -> Dict[str, List[VariableEntry]]:
        file_str = str(file_path)
        entries_by_name: Dict[str, List[VariableEntry]] = defaultdict(list)

        for decl in getattr(translation_unit, "declarations", []) or []:
            if getattr(decl, "kind", None) not in {"variable", "parameter", "member", "global"}:
                continue

            name = (getattr(decl, "name", "") or "").strip()
            if not self._is_cpp_symbol_name(name):
                continue

            decl_metadata = dict(getattr(decl, "metadata", {}) or {})
            function_name = getattr(decl, "function", None)
            enclosing_type = decl_metadata.get("enclosing_type")
            raw_scope = getattr(decl, "scope", None)
            scope = self._sanitize_cpp_scope(
                raw_scope,
                file_str,
                function_name=function_name,
                enclosing_type=enclosing_type,
                kind=getattr(decl, "kind", None),
            )

            line_num = int(getattr(decl, "line", 0) or 0)
            if line_num <= 0:
                line_num = self._best_cpp_line_for_name(name, edges, nodes)

            storage_class = (getattr(decl, "storage_class", None) or "").strip()
            if not storage_class:
                if getattr(decl, "kind", None) == "parameter":
                    storage_class = "parameter"
                elif getattr(decl, "kind", None) == "member":
                    storage_class = "member"
                elif scope == "file":
                    decl_type = (getattr(decl, "declaration_type", None) or "").lower()
                    if decl_type in {"static", "extern", "thread_local"}:
                        storage_class = decl_type
                    else:
                        storage_class = "file"
                else:
                    storage_class = "local"

            decl_type = getattr(decl, "declaration_type", None)
            data_type = getattr(decl, "data_type", None)
            initial_value = getattr(decl, "initial_value", None)
            related_symbols = list(getattr(decl, "related_symbols", []) or [])
            aliased_as = list(getattr(decl, "aliased_as", []) or [])

            entry_metadata = {"introduced_via": "declaration"}
            entry_metadata.update(decl_metadata)
            if line_num <= 0:
                entry_metadata["line_unknown"] = True

            entry = VariableEntry(
                name=name,
                kind=getattr(decl, "kind", "variable"),
                scope=scope,
                file=file_str,
                line=line_num,
                declaration_type=decl_type,
                data_type=data_type,
                storage_class=storage_class,
                initial_value=initial_value,
                aliased_as=self._unique_sorted(aliased_as),
                related_symbols=self._unique_sorted(related_symbols),
                metadata=entry_metadata,
            )
            if line_num > 0:
                self._add_location_if_missing(entry, VariableLocation(file_str, line_num, "definition"))

            if scope == "file":
                entry.scope_chain = [f"file:{Path(file_str).name}"]
            elif scope:
                entry.scope_chain = [scope]

            self._upsert_cpp_entry(entry)
            entries_by_name[name].append(entry)

        # Refresh references to actual stored entries after upsert merges.
        refreshed: Dict[str, List[VariableEntry]] = defaultdict(list)
        for name in entries_by_name:
            refreshed[name].extend(
                entry
                for entry in self.cpp_universe.get_variable_entries(name)
                if entry.file == file_str
            )
        return refreshed

    def _extract_cpp_auxiliary_metadata(self, unit: Any, file_path: Path) -> None:
        if unit is None:
            return

        file_str = str(file_path)

        # Capture extern declarations for cross-language linkage.
        for decl in getattr(unit, "declarations", []):
            metadata = getattr(decl, "metadata", {}) or {}
            decl_type = (getattr(decl, "declaration_type", None) or "").lower()
            is_extern = (
                getattr(decl, "scope", None) == "extern"
                or getattr(decl, "storage_class", None) == "extern"
                or decl_type in {"extern", "extern_linkage"}
                or bool(metadata.get("linkage"))
            )
            if not is_extern:
                continue

            decl_name = getattr(decl, "name", "") or ""
            if not decl_name:
                continue

            line_num = int(getattr(decl, "line", 0) or 0)
            if line_num <= 0:
                continue
            entry = VariableEntry(
                name=decl_name,
                kind="external",
                scope="global",
                file=file_str,
                line=line_num,
                declaration_type=getattr(decl, "declaration_type", None) or "extern",
                data_type=getattr(decl, "data_type", None),
                storage_class="extern",
                metadata={
                    "introduced_via": "external_declaration",
                    "decl_kind": getattr(decl, "kind", "unknown"),
                    "linkage": metadata.get("linkage"),
                },
            )
            self._add_location_if_missing(entry, VariableLocation(file_str, line_num, "declaration"))
            self.cpp_universe.add_extern_symbol(entry.name, entry)

        # Capture preprocessor macro definitions from C/C++ translation units.
        macro_definitions = getattr(unit, "macro_definitions", []) or []
        for macro in macro_definitions:
            macro_name = getattr(macro, "name", "") or ""
            if not macro_name:
                continue
            macro_file = getattr(macro, "file", None) or file_str
            params = list(getattr(macro, "parameters", []) or [])
            self.cpp_universe.add_macro_definition(
                name=macro_name,
                params=params,
                defined_in=macro_file,
                variables_introduced=[],
            )

        # Attach alias and relationship hints from typedef/using aliases and macro aliases.
        type_aliases = dict(getattr(unit, "type_aliases", {}) or {})
        macro_aliases: Dict[str, str] = {}
        for macro in macro_definitions:
            body = (getattr(macro, "body", None) or "").strip()
            macro_name = getattr(macro, "name", "") or ""
            if macro_name and re.fullmatch(r"[A-Za-z_]\w*", body):
                macro_aliases[macro_name] = body

        if not type_aliases and not macro_aliases:
            return

        for entries in self.cpp_universe.variables.values():
            for entry in entries:
                if entry.file != file_str:
                    continue
                data_type = entry.data_type or ""
                for alias, target in type_aliases.items():
                    if re.search(rf"\b{re.escape(alias)}\b", data_type):
                        entry.related_symbols.append(target)

                for macro_name, target in macro_aliases.items():
                    if entry.name == target:
                        entry.related_symbols.append(macro_name)
                    if entry.name == macro_name:
                        entry.aliased_as.append(target)
                        entry.related_symbols.append(target)

                entry.related_symbols = self._unique_sorted(entry.related_symbols)
                entry.aliased_as = self._unique_sorted(entry.aliased_as)

    def process_cpp_file(self, file_path: Path):
        """Process a C/C++ file and extract variables."""
        print(f"Processing C++ file: {file_path}")

        try:
            language = "c" if file_path.suffix.lower() == ".c" else "cpp"
            search_paths = [file_path.parent]
            if len(file_path.parents) >= 2:
                search_paths.append(file_path.parent.parent)

            analyzer = CFamilyAnalyzer(language, search_paths=search_paths)
            source_text = file_path.read_text(errors="replace")
            analysis_result = analyzer.analyze(file_path, source_text)

            graph = analysis_result.analysis_context.get_metadata("variable_lineage")
            translation_unit = analysis_result.analysis_context.get_metadata("c_family_unit")

            if graph:
                self._extract_cpp_from_lineage(graph.to_dict(), file_path, translation_unit=translation_unit)
            else:
                # Still capture extern/macro/type metadata even when lineage graph is missing.
                self._extract_cpp_from_lineage({}, file_path, translation_unit=translation_unit)
                print(f"Warning: No C++ variable lineage produced for {file_path}")

        except Exception as e:
            print(f"Error processing C++ file {file_path}: {e}")
            raise

    def _extract_cpp_from_lineage(
        self,
        parse_result: dict,
        file_path: Path,
        translation_unit: Any = None,
    ) -> None:
        """Extract variables, relationships, and locations from C/C++ analysis artifacts."""
        if "variable_lineage" in parse_result:
            lineage = parse_result.get("variable_lineage", {})
        elif "nodes" in parse_result and "edges" in parse_result:
            lineage = parse_result
        else:
            lineage = {}

        nodes = lineage.get("nodes", []) or []
        edges = lineage.get("edges", []) or []
        file_str = str(file_path)

        # Prefer declaration-driven extraction to avoid synthetic lineage nodes.
        entries_by_name: Dict[str, List[VariableEntry]] = defaultdict(list)
        if translation_unit is not None:
            entries_by_name = self._extract_cpp_from_declarations(translation_unit, file_path, edges, nodes)

        # Fallback to lineage nodes only when declaration metadata is unavailable.
        if not entries_by_name:
            fallback_names: Set[str] = set()
            for node in nodes:
                node_id = node.get("id", "")
                kind = node.get("kind", "")
                if not node_id or not self._is_cpp_variable_kind(kind):
                    continue
                node_metadata = dict(node.get("metadata", {}) or {})
                parsed_scope, name, _ = self._parse_cpp_scope_and_name(node.get("name", ""), node_metadata)
                if not self._is_cpp_symbol_name(name):
                    continue
                scope = self._sanitize_cpp_scope(
                    parsed_scope,
                    file_str,
                    function_name=node_metadata.get("enclosing_function"),
                    enclosing_type=node_metadata.get("enclosing_type"),
                    kind=kind,
                )
                line_num = self._best_cpp_line_for_node(node_id, edges)
                storage_class = self._cpp_storage_class_for_entry(kind, scope, node_metadata)
                entry = VariableEntry(
                    name=name,
                    kind=kind,
                    scope=scope,
                    file=file_str,
                    line=line_num,
                    declaration_type=node_metadata.get("declaration_type"),
                    data_type=node_metadata.get("data_type"),
                    storage_class=storage_class,
                    initial_value=node_metadata.get("initial_value"),
                    related_symbols=self._unique_sorted(list(node_metadata.get("related_symbols", []) or [])),
                    aliased_as=self._unique_sorted(list(node_metadata.get("aliased_as", []) or [])),
                    metadata={
                        "introduced_via": "lineage_fallback",
                        "node_id": node_id,
                    },
                )
                if line_num > 0:
                    self._add_location_if_missing(entry, VariableLocation(file_str, line_num, "definition"))
                if scope == "file":
                    entry.scope_chain = [f"file:{Path(file_str).name}"]
                elif scope:
                    entry.scope_chain = [scope]
                self._upsert_cpp_entry(entry)
                fallback_names.add(name)

            for name in fallback_names:
                entries_by_name[name] = [
                    entry for entry in self.cpp_universe.get_variable_entries(name)
                    if entry.file == file_str
                ]

        nodes_by_id = {node.get("id", ""): node for node in nodes if node.get("id")}
        node_names: Dict[str, List[str]] = {}
        for node_id, node in nodes_by_id.items():
            candidates = self._candidate_names_from_lineage_label(node.get("name", ""))
            node_names[node_id] = candidates

        touched_entries: Set[int] = set()
        for edge in edges:
            source_id = edge.get("source", "")
            target_id = edge.get("target", "")
            relation = edge.get("relation", "")
            line_num = int(edge.get("line", 0) or 0)
            edge_file = edge.get("file") or file_str

            source_names = node_names.get(source_id, [])
            target_names = node_names.get(target_id, [])

            source_entries = [entry for name in source_names for entry in entries_by_name.get(name, [])]
            target_entries = [entry for name in target_names for entry in entries_by_name.get(name, [])]

            if not source_entries:
                for name in source_names:
                    source_entries.extend(
                        entry
                        for entry in self.cpp_universe.get_variable_entries(name)
                        if self._is_cpp_symbol_declaration_entry(entry)
                    )
            if not target_entries:
                for name in target_names:
                    target_entries.extend(
                        entry
                        for entry in self.cpp_universe.get_variable_entries(name)
                        if self._is_cpp_symbol_declaration_entry(entry)
                    )

            if line_num > 0:
                for entry in source_entries:
                    context = "definition" if relation == "define" and source_id == target_id else "reference"
                    self._add_location_if_missing(entry, VariableLocation(edge_file, line_num, context))
                    touched_entries.add(id(entry))
                for entry in target_entries:
                    context = "definition" if relation == "define" else "reference"
                    self._add_location_if_missing(entry, VariableLocation(edge_file, line_num, context))
                    touched_entries.add(id(entry))

            for source_entry in source_entries:
                for target_entry in target_entries:
                    if source_entry.name == target_entry.name:
                        continue
                    source_entry.related_symbols.append(target_entry.name)
                    target_entry.related_symbols.append(source_entry.name)
                    touched_entries.add(id(source_entry))
                    touched_entries.add(id(target_entry))
                    if relation == "alias":
                        source_entry.aliased_as.append(target_entry.name)
                        target_entry.aliased_as.append(source_entry.name)

        for entries in entries_by_name.values():
            for entry in entries:
                if id(entry) not in touched_entries:
                    continue
                entry.related_symbols = self._unique_sorted(entry.related_symbols)
                entry.aliased_as = self._unique_sorted(entry.aliased_as)

        self._extract_cpp_auxiliary_metadata(translation_unit, file_path)

    def write_output(self, output_dir: Path):
        """Write universe files to output directory.

        Args:
            output_dir: Output directory path
        """
        output_dir.mkdir(parents=True, exist_ok=True)

        # Write ASM universe
        asm_universe_path = output_dir / "asm_variable_universe.json"
        asm_names_path = output_dir / "asm_variable_names.json"

        self.asm_universe.to_json(asm_universe_path)
        self.asm_universe.to_sqlite(asm_universe_path.with_suffix(".db"))
        self.asm_universe.write_variable_names(
            asm_names_path,
            include_predicate=self._is_runtime_asm_symbol_entry,
        )

        print(f"Written ASM universe to {asm_universe_path}")
        print(f"Written ASM universe DB to {asm_universe_path.with_suffix('.db')}")
        print(f"Written ASM variable names to {asm_names_path}")

        # Write C++ universe
        cpp_universe_path = output_dir / "cpp_variable_universe.json"
        cpp_names_path = output_dir / "cpp_variable_names.json"

        self.cpp_universe.to_json(cpp_universe_path)
        self.cpp_universe.to_sqlite(cpp_universe_path.with_suffix(".db"))
        self.cpp_universe.write_variable_names(cpp_names_path)

        print(f"Written C++ universe to {cpp_universe_path}")
        print(f"Written C++ universe DB to {cpp_universe_path.with_suffix('.db')}")
        print(f"Written C++ variable names to {cpp_names_path}")


def find_source_files(
    directories: List[str],
    patterns: List[str] = None,
    exclude_patterns: Optional[List[str]] = None,
    respect_gitignore: bool = True,
    include_test_sources: bool = False,
) -> List[Path]:
    """Find source files in directories.

    Args:
        directories: List of directory paths
        patterns: Optional list of glob patterns

    Returns:
        List of file paths
    """
    files = []
    recursive_candidates = []

    for directory in directories:
        dir_path = Path(directory)

        if dir_path.is_file():
            files.append(dir_path.resolve())
            continue

        if not dir_path.is_dir():
            print(f"Warning: {directory} is not a valid directory")
            continue

        root_dir = dir_path.resolve()

        # Find all ASM and C++ files
        for ext in ASM_EXTENSIONS | CPP_EXTENSIONS:
            for source_file in dir_path.rglob(f"*{ext}"):
                if source_file.is_file():
                    recursive_candidates.append((source_file.resolve(), root_dir))

    effective_exclude_patterns = merge_discovery_exclude_patterns(
        exclude_patterns,
        include_test_sources=include_test_sources,
    )

    filtered_recursive_files = []
    excluded_count = 0
    if recursive_candidates:
        filtered_recursive_files, excluded_count = filter_discovered_paths(
            recursive_candidates,
            exclude_patterns=effective_exclude_patterns,
            respect_gitignore=respect_gitignore,
        )

    ordered_files = []
    seen_paths = set()
    for source_file in files + filtered_recursive_files:
        if source_file in seen_paths:
            continue
        seen_paths.add(source_file)
        ordered_files.append(source_file)

    if excluded_count:
        print(f"Discovery filters excluded {excluded_count} file(s).")

    return ordered_files


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Build variable universes from ASM and C/C++ source files"
    )
    parser.add_argument(
        "source_dirs",
        nargs="+",
        help="Source directories or files to process"
    )
    parser.add_argument(
        "--output",
        "-o",
        default="output",
        help="Output directory (default: output/)"
    )
    parser.add_argument(
        "--asm-only",
        action="store_true",
        help="Process only ASM files"
    )
    parser.add_argument(
        "--cpp-only",
        action="store_true",
        help="Process only C/C++ files"
    )
    parser.add_argument(
        "--exclude",
        action="append",
        default=[],
        metavar="GLOB",
        help="Exclude recursively discovered files/directories matching glob patterns "
             "(can be specified multiple times)"
    )
    parser.add_argument(
        "--no-gitignore",
        action="store_true",
        help="Do not use git ignore rules when recursively discovering files in directories"
    )
    parser.add_argument(
        "--include-test-sources",
        action="store_true",
        help="Include recursively discovered files under common test/temp/fixture paths"
    )

    args = parser.parse_args()

    # Find source files
    source_files = find_source_files(
        args.source_dirs,
        exclude_patterns=args.exclude,
        respect_gitignore=not args.no_gitignore,
        include_test_sources=args.include_test_sources,
    )

    if not source_files:
        print("No source files found!")
        return 1

    # Filter by file type if requested
    if args.asm_only:
        source_files = [f for f in source_files if is_asm_file(f)]
    elif args.cpp_only:
        source_files = [f for f in source_files if is_cpp_file(f)]

    print(f"Found {len(source_files)} source files")

    # Build universes
    builder = UniverseBuilder()
    builder.build(source_files)

    # Write output
    output_dir = Path(args.output)
    builder.write_output(output_dir)

    print("\nUniverse building complete!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
