#!/usr/bin/env python3
"""Script to verify if the SQLite index database has all the precomputed VBT artifacts.

Usage:
  python3 check_db_readiness.py --job-id <job_id>
  python3 check_db_readiness.py --db-path jobs/<job_id>/index.db
"""

import argparse
import os
import sqlite3
from pathlib import Path

# Artifact keys to look for in vbt_artifact_blob
REQUIRED_SINGLETONS = {
    "file_call_graph": "File Call Graph JSON representation",
    "route_name_to_stems": "Route Name to Stems mapping (forward reachability)",
    "cpp_call_edges": "C++ Function Call Edges index",
    "name_alias": "Name Alias Resolver Data (C++ / ASM aliases)",
    "membership": "Membership Resolver Index (class/struct/namespace definitions)",
    "const": "Const/Enum/EQU resolver data",
    "modifier_index": "VBT Modifier/Variable modifier index"
}

SPEEDUP_SINGLETONS = {
    "reverse_adj": "Reverse Adjacency List (speeds up RouteEngine cold starts)",
    "forward_file_adj": "Forward File Adjacency List (speeds up file reachability)",
    "fn_graph_adj": "Unified Function Graph Adjacency index",
    "fn_facts": "Function Facts metadata"
}

STEM_MAPPED_ARTIFACTS = {
    "asm_setter_map": "ASM Setter Maps (prevents scanning files live)",
    "cpp_setter_map": "C++ Setter Maps (prevents parsing files live)",
    "cpp_file_writes": "C++ File Writes Index (speeds up C++ side effects calculation)"
}

def format_size(size_in_bytes):
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_in_bytes < 1024.0:
            return f"{size_in_bytes:.2f} {unit}"
        size_in_bytes /= 1024.0
    return f"{size_in_bytes:.2f} TB"

def check_db_readiness(db_path: Path, job_id: str):
    print("=" * 80)
    print(f"Checking VBT Database Readiness for Job: {job_id}")
    print(f"Database Path: {db_path.resolve()}")
    print("=" * 80)

    if not db_path.is_file():
        print(f"\033[91mFAIL: Database file does not exist at {db_path}\033[0m")
        print("\nTo fix this:")
        print("  1. Run the universe and analysis tasks for this job/KB.")
        print("  2. Run the VBT precomputation task.")
        return False

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
    except Exception as e:
        print(f"\033[91mFAIL: Could not open SQLite database: {e}\033[0m")
        return False

    # Check for tables
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [row[0] for row in cursor.fetchall()]
    
    required_tables = ["vbt_artifact_blob", "vbt_precompute_manifest"]
    missing_tables = [t for t in required_tables if t not in tables]
    
    if missing_tables:
        print(f"\033[91mFAIL: Database is missing VBT tables: {', '.join(missing_tables)}\033[0m")
        print("\nThis means VBT precompute has not been run on this database.")
        print("Please run `vbt_precompute_task` first.")
        conn.close()
        return False

    print("\033[92mPASS: Found VBT database tables.\033[0m\n")

    has_failures = False
    has_warnings = False

    # 1. Check Required Singletons
    print("--- 1. REQUIRED VBT ARTIFACTS (crucial for correctness & trace execution) ---")
    for key, desc in REQUIRED_SINGLETONS.items():
        cursor.execute(
            "SELECT length(payload) FROM vbt_artifact_blob WHERE job_id = ? AND artifact = ?",
            (job_id, key)
        )
        row = cursor.fetchone()
        if row:
            size_str = format_size(row[0])
            print(f"  [\033[92mOK\033[0m]  {key:25} Size: {size_str:>10}  | {desc}")
        else:
            print(f"  [\033[91mFAIL\033[0m] {key:25} MISSING             | {desc}")
            has_failures = True
    print()

    # 2. Check Speedup Singletons
    print("--- 2. SPEEDUP SINGLETON ARTIFACTS (missing = trace correct but slower) ---")
    for key, desc in SPEEDUP_SINGLETONS.items():
        cursor.execute(
            "SELECT length(payload) FROM vbt_artifact_blob WHERE job_id = ? AND artifact = ?",
            (job_id, key)
        )
        row = cursor.fetchone()
        if row:
            size_str = format_size(row[0])
            print(f"  [\033[92mOK\033[0m]  {key:25} Size: {size_str:>10}  | {desc}")
        else:
            print(f"  [\033[93mWARN\033[0m] {key:25} MISSING             | {desc}")
            has_warnings = True
    print()

    # 3. Check Stem-Mapped Prefix Artifacts
    print("--- 3. STEM-MAPPED ARTIFACTS (missing = falls back to slow runtime scanning) ---")
    for prefix, desc in STEM_MAPPED_ARTIFACTS.items():
        cursor.execute(
            "SELECT COUNT(*), COALESCE(SUM(length(payload)), 0) "
            "FROM vbt_artifact_blob WHERE job_id = ? AND artifact LIKE ?",
            (job_id, f"{prefix}:%")
        )
        count, total_bytes = cursor.fetchone()
        if count > 0:
            size_str = format_size(total_bytes)
            print(f"  [\033[92mOK\033[0m]  {prefix:25} {count:>5} blobs ({size_str:>8}) | {desc}")
        else:
            print(f"  [\033[93mWARN\033[0m] {prefix:25} 0 blobs             | {desc}")
            has_warnings = True
    print()

    # 4. Check C++ CFG Cache Blobs
    print("--- 4. C++ CONTROL FLOW GRAPH (CFG) BLOBS ---")
    if "vbt_cfg_blob" in tables:
        cursor.execute(
            "SELECT COUNT(*), COALESCE(SUM(length(payload)), 0) "
            "FROM vbt_cfg_blob WHERE job_id = ?",
            (job_id,)
        )
        count, total_bytes = cursor.fetchone()
        if count > 0:
            size_str = format_size(total_bytes)
            print(f"  [\033[92mOK\033[0m]  {'vbt_cfg_blob':25} {count:>5} blobs ({size_str:>8}) | Stores pre-warmed C++ Control Flow Graphs")
        else:
            print(f"  [\033[91mFAIL\033[0m] {'vbt_cfg_blob':25} 0 blobs             | Missing pre-warmed CFG cache (C++ tracing will fail/be slow)")
            has_failures = True
    else:
        print(f"  [\033[91mFAIL\033[0m] {'vbt_cfg_blob':25} Table missing       | Missing pre-warmed CFG cache (C++ tracing will fail/be slow)")
        has_failures = True
    print()

    conn.close()

    print("=" * 80)
    if has_failures:
        print("\033[91mVERDICT: INCOMPLETE / DEGENERATE VBT DATABASE ❌\033[0m")
        print("Some required VBT artifacts are missing. Tracing will fail or be highly inefficient.")
        print("\nTo rebuild the precomputation artifacts, run:")
        print(f"  env/bin/python3 -m vbt.precompute_db --job-id {job_id} --blueprint-dir jobs/{job_id}/output --asm-dir <path_to_source_code> --rebuild")
    elif has_warnings:
        print("\033[93mVERDICT: READY WITH WARNINGS ⚠️ (SLOWER PATH FALLBACKS)\033[0m")
        print("Required artifacts are present, but some speedup helper artifacts are missing.")
        print("Traces will yield correct outputs but will have fallback runtime penalty.")
        print("\nTo generate the missing speedup artifacts incrementally, run:")
        print(f"  env/bin/python3 -m vbt.precompute_db --job-id {job_id} --blueprint-dir jobs/{job_id}/output --asm-dir <path_to_source_code> --only reverse_adj,forward_file_adj,asm_setter_map,cpp_setter_map,cpp_file_writes,fn_graph_adj,fn_facts")
    else:
        print("\033[92mVERDICT: READY & OPTIMIZED FOR FAST VBT TRACING! ✅\033[0m")
    print("=" * 80)

def main():
    parser = argparse.ArgumentParser(description="Verify VBT DB precomputation artifacts status.")
    parser.add_argument("--job-id", default="b58d8432-73e0-42d1-89a9-2ceebc47c6d2", help="Knowledge base / Job ID")
    parser.add_argument("--db-path", type=str, default=None, help="Direct path to index.db (defaults to jobs/<job-id>/index.db)")
    
    args = parser.parse_args()

    project_root = Path(__file__).resolve().parent
    
    if args.db_path:
        db_path = Path(args.db_path)
    else:
        db_path = project_root / "jobs" / args.job_id / "index.db"

    check_db_readiness(db_path, args.job_id)

if __name__ == "__main__":
    main()
