# build.ps1 — one-shot build of the Uniformance Excel Refresher installer.
# Run on Windows from inside the honeywell_excel_refresher folder:
#     powershell -ExecutionPolicy Bypass -File .\build.ps1
#
# Requires:
#   * Rust toolchain        (https://rustup.rs)  -> cargo, rustc
#   * Inno Setup 6          (https://jrsoftware.org/isdl.php) -> iscc.exe on PATH
#   * Python 3 + Pillow     (only if you change logo.png and want to regen assets)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host "==> (optional) regenerating image assets from logo.png" -ForegroundColor Cyan
if (Get-Command python -ErrorAction SilentlyContinue) {
    try { python assets\make_assets.py } catch { Write-Warning "asset regen skipped: $_" }
} else {
    Write-Host "    python not found — using existing assets/*.ico and installer/*.bmp"
}

Write-Host "==> building release binary" -ForegroundColor Cyan
cargo build --release
if ($LASTEXITCODE -ne 0) { throw "cargo build failed" }

$exe = "target\release\UniformanceRefresher.exe"
if (-not (Test-Path $exe)) { throw "expected binary not found at $exe" }
Write-Host "    built $exe" -ForegroundColor Green

Write-Host "==> compiling installer with Inno Setup" -ForegroundColor Cyan
$iscc = Get-Command iscc -ErrorAction SilentlyContinue
if (-not $iscc) {
    $guess = "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe"
    if (Test-Path $guess) { $iscc = $guess } else {
        throw "iscc.exe (Inno Setup) not found on PATH. Install Inno Setup 6."
    }
}
& $iscc installer\setup.iss
if ($LASTEXITCODE -ne 0) { throw "Inno Setup build failed" }

Write-Host ""
Write-Host "DONE. Installer is at: installer\Output\UniformanceRefresher-Setup.exe" -ForegroundColor Green
