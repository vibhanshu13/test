// build.rs — embeds the application icon and version info into the Windows .exe.
// On non-Windows hosts (e.g. building/checking on macOS) this is a no-op so the
// crate still type-checks; the real icon is only embedded for the Windows target.

fn main() {
    #[cfg(windows)]
    {
        let mut res = winres::WindowsResource::new();
        res.set_icon("assets/logo.ico");
        res.set("ProductName", "Uniformance Excel Refresher");
        res.set("FileDescription", "Refreshes a Honeywell Uniformance-linked Excel workbook");
        res.set("CompanyName", "opzen.ai");
        res.set("LegalCopyright", "opzen.ai");
        if let Err(e) = res.compile() {
            // Don't hard-fail the build if the resource compiler is unavailable;
            // the program still works, just without the embedded icon.
            eprintln!("warning: could not embed icon resource: {e}");
        }
    }
}
