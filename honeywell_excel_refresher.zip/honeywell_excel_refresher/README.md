# Uniformance Excel Refresher

A small Windows tool (written in Rust) that keeps a Honeywell **Uniformance
(PHD)**-linked Excel workbook up to date. It opens the workbook, makes the
Uniformance Excel add-in re-query the historian, fully recalculates, saves, and
closes — **every 10 minutes** (configurable).

It ships as a single branded `.exe` installer that uses `logo.png` for its icon
and welcome screen.

---

## What it does, exactly

The workbook is "already integrated" with Uniformance — i.e. it contains the
add-in formulas / data connections that pull tag values from PHD when Excel
recalculates. This tool automates that recalculation on a schedule.

Each cycle (default every 10 min):

1. Launches Excel **hidden** (no window, no pop-up dialogs).
2. Opens the configured workbook.
3. `Workbook.RefreshAll` → refreshes all data connections / queries.
4. `Application.CalculateUntilAsyncQueriesDone` → waits for the add-in's
   asynchronous PHD queries to finish.
5. `Application.CalculateFull` → recomputes every formula.
6. `Workbook.Save` → writes the fresh values back in place.
7. Closes the workbook and quits Excel.

COM is initialized and torn down **per cycle**, so a hung Excel never poisons
later cycles.

---

## Requirements (on the operator's PC)

- Windows 10/11
- Microsoft Excel (desktop) installed
- The **Honeywell Uniformance / PHD Excel add-in** installed and configured
  (the same add-in that already populates the workbook by hand)
- Network access to the PHD server

> This is **Windows-only by design** — Uniformance and the Excel add-in are
> Windows COM components. It cannot fetch data on macOS/Linux.

---

## Using the installer (operator)

1. Run `UniformanceRefresher-Setup.exe`.
2. Click through; on the **"Workbook to keep refreshed"** page enter:
   - the full path to the `.xlsm`/`.xlsx` workbook, and
   - the refresh interval in minutes (default `10`).
3. Finish. Optionally tick *"Start refreshing now"* / *"Start automatically when
   I log in"*.

A console window opens showing each refresh cycle. Leave it open; close it (or
Ctrl+C) to stop. Settings live in `config.ini` next to the exe — edit and
restart to change them.

---

## Building the installer (developer, on Windows)

You need:

| Tool | Where |
|------|-------|
| Rust toolchain | <https://rustup.rs> |
| Inno Setup 6 (`iscc.exe`) | <https://jrsoftware.org/isdl.php> |
| Python 3 + Pillow | only to regenerate assets from `logo.png` |

Then, from this folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

This builds the release binary and compiles the installer to:

```
installer\Output\UniformanceRefresher-Setup.exe
```

### Manual steps (if you prefer)

```powershell
cargo build --release                 # -> target\release\UniformanceRefresher.exe
iscc installer\setup.iss              # -> installer\Output\UniformanceRefresher-Setup.exe
```

### Regenerating logo assets

If you replace `../logo.png`, regenerate the icon and wizard bitmaps:

```bash
python3 assets/make_assets.py
```

This produces `assets/logo.ico` (embedded as the exe icon) and the
`installer/wizard_*.bmp` images (Inno Setup welcome/banner art, incl. HiDPI).

---

## Running without the installer (for testing)

```powershell
copy config.ini.example config.ini    # then edit excel_path
cargo run --release                    # loop every interval_minutes
cargo run --release -- --once          # single refresh then exit
cargo run --release -- "C:\Data\Frac prototype.xlsm"   # path overrides config
```

---

## Project layout

```
honeywell_excel_refresher/
├── Cargo.toml              crate + windows-rs / winres deps
├── build.rs                embeds assets/logo.ico into the exe
├── build.ps1               one-shot Windows build (cargo + iscc)
├── config.ini.example      sample config
├── src/
│   ├── main.rs             config load + 10-min loop + console output
│   └── excel.rs            COM/IDispatch automation of Excel
├── assets/
│   ├── logo.ico            multi-size app icon (from logo.png)
│   └── make_assets.py      regenerates icon + installer bitmaps
└── installer/
    ├── setup.iss           Inno Setup script (branded .exe installer)
    └── wizard_*.bmp        welcome/banner images (from logo.png)
```

---

## Notes / gotchas

- **Build host must be Windows.** The COM code only compiles/links and runs on
  the `*-pc-windows-msvc` target. (`build.rs` is a no-op off-Windows so the
  crate still type-checks on macOS/Linux, but it won't link there.)
- The `windows` crate is pinned to `0.58`. If your local crates.io resolves a
  newer major version, a couple of COM call signatures in `src/excel.rs`
  (`Invoke` / `GetIDsOfNames` argument wrapping) may need a minor tweak —
  keep the pin to avoid that.
- The tool saves **in place** in the original format (e.g. `.xlsm` stays
  macro-enabled). Make sure the account running it has write access and that
  the file isn't open elsewhere with an exclusive lock.
- If Excel shows a credential / "enable content" prompt the first time, open
  the workbook once manually, authenticate to PHD, and enable macros/content
  so future automated opens are silent.
```
