//! UniformanceRefresher — keeps a Honeywell Uniformance-linked Excel workbook
//! up to date by re-querying PHD and recalculating on a fixed interval.
//!
//! Run modes:
//!   UniformanceRefresher.exe                 -> reads config.ini next to the exe
//!   UniformanceRefresher.exe "C:\path.xlsm"  -> overrides the workbook path
//!   UniformanceRefresher.exe --once          -> single refresh then exit
//!
//! The installer writes config.ini (the workbook path + interval) at install
//! time, so the operator normally just double-clicks the exe.

mod excel;

use std::env;
use std::path::{Path, PathBuf};
use std::process::ExitCode;
use std::thread::sleep;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use windows::Win32::System::Com::{
    CoInitializeEx, CoUninitialize, COINIT_APARTMENTTHREADED,
};

struct Config {
    excel_path: PathBuf,
    interval: Duration,
}

fn main() -> ExitCode {
    let args: Vec<String> = env::args().collect();
    let run_once = args.iter().any(|a| a == "--once");
    let cli_path = args
        .iter()
        .skip(1)
        .find(|a| !a.starts_with("--"))
        .map(PathBuf::from);

    let cfg = match load_config(cli_path) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("[FATAL] {e}");
            eprintln!();
            eprintln!("Expected a config.ini next to this program, e.g.:");
            eprintln!("    excel_path = C:\\Data\\Frac prototype.xlsm");
            eprintln!("    interval_minutes = 10");
            eprintln!();
            eprintln!("Or pass the workbook path directly:");
            eprintln!("    UniformanceRefresher.exe \"C:\\Data\\Frac prototype.xlsm\"");
            pause_on_exit();
            return ExitCode::FAILURE;
        }
    };

    banner(&cfg, run_once);

    if !cfg.excel_path.exists() {
        eprintln!("[WARN] Workbook not found right now: {}", cfg.excel_path.display());
        eprintln!("       Will keep trying — make sure the path in config.ini is correct.");
    }

    let mut cycle: u64 = 0;
    loop {
        cycle += 1;
        println!("\n{}", "-".repeat(64));
        println!("[{}] Cycle #{cycle} starting", now_string());

        match run_cycle(&cfg.excel_path) {
            Ok(()) => println!("[{}] OK  — workbook refreshed & saved.", now_string()),
            Err(e) => eprintln!("[{}] ERROR — {e}", now_string()),
        }

        if run_once {
            break;
        }

        let mins = cfg.interval.as_secs() / 60;
        println!("[{}] Sleeping {mins} min until next refresh…", now_string());
        sleep(cfg.interval);
    }

    ExitCode::SUCCESS
}

/// One full refresh cycle: open → refresh → save → close. COM is initialized
/// and torn down per cycle so a hung Excel never poisons later cycles.
fn run_cycle(path: &Path) -> Result<(), String> {
    if !path.exists() {
        return Err(format!("workbook not found: {}", path.display()));
    }

    unsafe {
        // STA — Excel automation must run single-threaded-apartment.
        // S_FALSE (already initialized on this thread) counts as success.
        CoInitializeEx(None, COINIT_APARTMENTTHREADED)
            .ok()
            .map_err(|e| format!("CoInitializeEx failed: {e}"))?;

        let result = (|| -> windows::core::Result<()> {
            let app = excel::new_excel()?;
            println!("    Excel launched (hidden).");

            let wb = excel::open_workbook(&app, path)?;
            println!("    Workbook opened: {}", path.display());

            println!("    Re-querying Uniformance / recalculating…");
            excel::refresh(&app, &wb)?;

            excel::save(&wb)?;
            println!("    Saved.");

            excel::close_and_quit(&app, &wb);
            Ok(())
        })();

        CoUninitialize();
        result.map_err(|e| format!("Excel automation failed: {e}"))
    }
}

// --------------------------------------------------------------------------
// Config
// --------------------------------------------------------------------------

fn load_config(cli_path: Option<PathBuf>) -> Result<Config, String> {
    // Defaults.
    let mut excel_path: Option<PathBuf> = cli_path;
    let mut interval_minutes: u64 = 10;

    // config.ini sits next to the executable.
    let ini = exe_dir().join("config.ini");
    if ini.exists() {
        let text = std::fs::read_to_string(&ini)
            .map_err(|e| format!("could not read {}: {e}", ini.display()))?;
        for line in text.lines() {
            let line = line.trim();
            if line.is_empty() || line.starts_with('#') || line.starts_with(';') {
                continue;
            }
            if let Some((key, val)) = line.split_once('=') {
                let key = key.trim().to_ascii_lowercase();
                let val = val.trim();
                match key.as_str() {
                    "excel_path" | "workbook" | "path" => {
                        if excel_path.is_none() && !val.is_empty() {
                            excel_path = Some(PathBuf::from(strip_quotes(val)));
                        }
                    }
                    "interval_minutes" | "interval" => {
                        if let Ok(m) = val.parse::<u64>() {
                            if m >= 1 {
                                interval_minutes = m;
                            }
                        }
                    }
                    _ => {}
                }
            }
        }
    }

    let excel_path = excel_path.ok_or_else(|| {
        "no workbook path configured (set excel_path in config.ini or pass it as an argument)"
            .to_string()
    })?;

    Ok(Config {
        excel_path,
        interval: Duration::from_secs(interval_minutes * 60),
    })
}

fn strip_quotes(s: &str) -> &str {
    s.trim_matches(|c| c == '"' || c == '\'')
}

fn exe_dir() -> PathBuf {
    env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(|p| p.to_path_buf()))
        .unwrap_or_else(|| PathBuf::from("."))
}

// --------------------------------------------------------------------------
// Console niceties
// --------------------------------------------------------------------------

fn banner(cfg: &Config, run_once: bool) {
    println!("======================================================================");
    println!("  UNIFORMANCE EXCEL REFRESHER");
    println!("  Workbook : {}", cfg.excel_path.display());
    if run_once {
        println!("  Mode     : single run (--once)");
    } else {
        println!("  Interval : every {} minutes", cfg.interval.as_secs() / 60);
        println!("  Stop     : close this window or press Ctrl+C");
    }
    println!("======================================================================");
}

/// Seconds-since-epoch rendered as a simple HH:MM:SS-ish stamp without pulling
/// in a date crate. Good enough for console logging.
fn now_string() -> String {
    let secs = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    let s = secs % 60;
    let m = (secs / 60) % 60;
    let h = (secs / 3600) % 24;
    format!("{h:02}:{m:02}:{s:02} UTC")
}

fn pause_on_exit() {
    use std::io::Read;
    println!("\nPress Enter to close…");
    let _ = std::io::stdin().read(&mut [0u8]);
}
