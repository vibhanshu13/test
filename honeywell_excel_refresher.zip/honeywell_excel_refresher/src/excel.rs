//! excel.rs — late-bound COM automation of Microsoft Excel.
//!
//! Honeywell Uniformance (PHD) ships an Excel add-in. A workbook that is
//! "integrated" with Uniformance contains add-in formulas / data connections
//! that pull live tag values from the PHD server whenever the workbook is
//! recalculated. This module opens such a workbook, forces the add-in to
//! re-query the historian, saves the refreshed values, and closes cleanly.
//!
//! Everything here uses IDispatch late binding (the same mechanism VBA uses),
//! so we do not need a type library for Excel at build time.

use std::mem::ManuallyDrop;
use std::path::Path;
use std::ptr;

use windows::core::{BSTR, GUID, HSTRING, PCWSTR};
use windows::Win32::Foundation::{E_NOINTERFACE, E_POINTER, VARIANT_BOOL};
use windows::Win32::System::Com::{
    CoCreateInstance, CLSCTX_LOCAL_SERVER, DISPATCH_METHOD, DISPATCH_PROPERTYGET,
    DISPATCH_PROPERTYPUT, DISPPARAMS, IDispatch,
};
use windows::Win32::System::Ole::{CLSIDFromProgID, DISPID_PROPERTYPUT};
use windows::Win32::System::Variant::{
    VARIANT, VT_BOOL, VT_BSTR, VT_DISPATCH, VT_I4,
};

const LOCALE_USER_DEFAULT: u32 = 0x0400;

/// Excel `XlCalculation` / state and a couple of enum constants we need.
mod xl {
    /// Workbooks.Open(UpdateLinks:=0) — never prompt to update external links.
    pub const UPDATE_LINKS_NEVER: i32 = 0;
}

/// A thin wrapper over an Excel automation object (`IDispatch`).
#[derive(Clone)]
pub struct Dispatch(pub IDispatch);

impl Dispatch {
    /// Resolve a member name to its DISPID.
    unsafe fn dispid(&self, name: &str) -> windows::core::Result<i32> {
        let wide = HSTRING::from(name);
        let name_ptr = PCWSTR(wide.as_ptr());
        let mut dispid = 0i32;
        self.0.GetIDsOfNames(
            &GUID::zeroed(),
            &name_ptr,
            1,
            LOCALE_USER_DEFAULT,
            &mut dispid,
        )?;
        Ok(dispid)
    }

    /// Low-level invoke. `args` are in natural (left-to-right) order; COM wants
    /// them reversed, which we handle here. Returns the result VARIANT.
    unsafe fn invoke(
        &self,
        name: &str,
        flags: windows::Win32::System::Com::DISPATCH_FLAGS,
        mut args: Vec<VARIANT>,
    ) -> windows::core::Result<VARIANT> {
        let dispid = self.dispid(name)?;
        args.reverse();

        // PROPERTYPUT needs the named-argument DISPID_PROPERTYPUT.
        let mut named = DISPID_PROPERTYPUT;
        let is_put = flags.0 & DISPATCH_PROPERTYPUT.0 != 0;

        let mut dp = DISPPARAMS {
            rgvarg: if args.is_empty() { ptr::null_mut() } else { args.as_mut_ptr() },
            rgdispidNamedArgs: if is_put { &mut named } else { ptr::null_mut() },
            cArgs: args.len() as u32,
            cNamedArgs: if is_put { 1 } else { 0 },
        };

        let mut result = VARIANT::default();
        // IDispatch::Invoke: pVarResult / pExcepInfo / puArgErr are plain [out]
        // pointers in the IDL, so windows-rs generates raw `*mut` (not Option).
        self.0.Invoke(
            dispid,
            &GUID::zeroed(),
            LOCALE_USER_DEFAULT,
            flags,
            &mut dp,
            &mut result,
            ptr::null_mut(),
            ptr::null_mut(),
        )?;
        Ok(result)
    }

    /// Call a method (no return value needed).
    pub unsafe fn call(&self, name: &str, args: Vec<VARIANT>) -> windows::core::Result<VARIANT> {
        self.invoke(name, DISPATCH_METHOD, args)
    }

    /// Read a property, returning the raw VARIANT.
    pub unsafe fn get(&self, name: &str, args: Vec<VARIANT>) -> windows::core::Result<VARIANT> {
        self.invoke(name, DISPATCH_PROPERTYGET, args)
    }

    /// Set a property.
    pub unsafe fn put(&self, name: &str, value: VARIANT) -> windows::core::Result<()> {
        self.invoke(name, DISPATCH_PROPERTYPUT, vec![value])?;
        Ok(())
    }

    /// Read a property that returns another COM object and wrap it.
    pub unsafe fn get_object(&self, name: &str, args: Vec<VARIANT>) -> windows::core::Result<Dispatch> {
        let v = self.get(name, args)?;
        variant_to_dispatch(&v)
    }

    /// Call a method that returns a COM object and wrap it.
    pub unsafe fn call_object(&self, name: &str, args: Vec<VARIANT>) -> windows::core::Result<Dispatch> {
        let v = self.call(name, args)?;
        variant_to_dispatch(&v)
    }

    /// Read an i32-valued property.
    pub unsafe fn get_i32(&self, name: &str) -> windows::core::Result<i32> {
        let v = self.get(name, vec![])?;
        Ok(variant_to_i32(&v))
    }
}

// --------------------------------------------------------------------------
// VARIANT construction / extraction helpers
// --------------------------------------------------------------------------

/// Build a `VT_BSTR` VARIANT from a Rust string.
pub fn v_str(s: &str) -> VARIANT {
    unsafe {
        let mut v = VARIANT::default();
        // BSTR::from allocates via SysAllocString internally; VARIANT's Drop
        // (VariantClear) frees it, so there is no leak and no double-free.
        let bstr = BSTR::from(s);
        let inner = &mut *v.Anonymous.Anonymous;
        inner.vt = VT_BSTR;
        inner.Anonymous.bstrVal = ManuallyDrop::new(bstr);
        v
    }
}

/// Build a `VT_I4` VARIANT.
pub fn v_i32(n: i32) -> VARIANT {
    unsafe {
        let mut v = VARIANT::default();
        let inner = &mut *v.Anonymous.Anonymous;
        inner.vt = VT_I4;
        inner.Anonymous.lVal = n;
        v
    }
}

/// Build a `VT_BOOL` VARIANT (COM TRUE == -1).
pub fn v_bool(b: bool) -> VARIANT {
    unsafe {
        let mut v = VARIANT::default();
        let inner = &mut *v.Anonymous.Anonymous;
        inner.vt = VT_BOOL;
        inner.Anonymous.boolVal = VARIANT_BOOL(if b { -1 } else { 0 });
        v
    }
}

/// Extract an `IDispatch` from a VARIANT returned by Excel.
unsafe fn variant_to_dispatch(v: &VARIANT) -> windows::core::Result<Dispatch> {
    let inner = &*v.Anonymous.Anonymous;
    if inner.vt != VT_DISPATCH {
        // Expected an object (VT_DISPATCH) but Excel returned another type.
        return Err(windows::core::Error::from_hresult(E_NOINTERFACE));
    }
    let disp = (*inner.Anonymous.pdispVal).clone();
    match disp {
        Some(d) => Ok(Dispatch(d)),
        // Null object reference from Excel.
        None => Err(windows::core::Error::from_hresult(E_POINTER)),
    }
}

/// Extract an i32 from a VARIANT (handles VT_I4 / VT_I2 / VT_BOOL).
unsafe fn variant_to_i32(v: &VARIANT) -> i32 {
    let inner = &*v.Anonymous.Anonymous;
    match inner.vt {
        t if t == VT_I4 => inner.Anonymous.lVal,
        t if t == VT_BOOL => inner.Anonymous.boolVal.0 as i32,
        _ => 0,
    }
}

// --------------------------------------------------------------------------
// High-level Excel operations
// --------------------------------------------------------------------------

/// Create a hidden Excel.Application instance.
pub unsafe fn new_excel() -> windows::core::Result<Dispatch> {
    let progid = HSTRING::from("Excel.Application");
    let clsid = CLSIDFromProgID(&progid)?;
    let app: IDispatch = CoCreateInstance(&clsid, None, CLSCTX_LOCAL_SERVER)?;
    let app = Dispatch(app);

    // Run silently: invisible window, no modal dialogs, no link prompts.
    app.put("Visible", v_bool(false))?;
    app.put("DisplayAlerts", v_bool(false))?;
    app.put("ScreenUpdating", v_bool(false))?;
    // AskToUpdateLinks=false so opening never blocks on a dialog.
    let _ = app.put("AskToUpdateLinks", v_bool(false));
    Ok(app)
}

/// Open a workbook read/write and return the Workbook object.
pub unsafe fn open_workbook(app: &Dispatch, path: &Path) -> windows::core::Result<Dispatch> {
    let workbooks = app.get_object("Workbooks", vec![])?;
    let path_str = path.to_string_lossy().to_string();
    // Workbooks.Open(Filename, UpdateLinks:=0) — positional args.
    workbooks.call_object("Open", vec![v_str(&path_str), v_i32(xl::UPDATE_LINKS_NEVER)])
}

/// Force the Uniformance add-in / RTD / data connections to re-pull from PHD,
/// then fully recalculate so all dependent cells update.
pub unsafe fn refresh(app: &Dispatch, workbook: &Dispatch) -> windows::core::Result<()> {
    // 1. Refresh all data connections / queries (RefreshAll on the workbook).
    let _ = workbook.call("RefreshAll", vec![]);

    // 2. Let any asynchronous add-in/RTD queries settle. This method blocks
    //    until Excel's async query queue is empty — exactly what add-ins use.
    let _ = app.call("CalculateUntilAsyncQueriesDone", vec![]);

    // 3. Full rebuild so every formula (including add-in functions) recomputes.
    let _ = app.call("CalculateFull", vec![]);

    // 4. Settle once more in case the recalc kicked off new async queries.
    let _ = app.call("CalculateUntilAsyncQueriesDone", vec![]);
    Ok(())
}

/// Save the workbook in place (keeps the existing format, e.g. .xlsm).
pub unsafe fn save(workbook: &Dispatch) -> windows::core::Result<()> {
    workbook.call("Save", vec![])?;
    Ok(())
}

/// Close the workbook (without re-saving — we already saved) and quit Excel.
pub unsafe fn close_and_quit(app: &Dispatch, workbook: &Dispatch) {
    let _ = workbook.call("Close", vec![v_bool(false)]); // SaveChanges = false
    let _ = app.call("Quit", vec![]);
}
