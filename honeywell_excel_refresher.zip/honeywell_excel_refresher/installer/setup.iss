; ============================================================================
; setup.iss — Inno Setup script for the Uniformance Excel Refresher.
;
; Produces a single branded .exe installer that:
;   * shows the logo on the welcome/finish pages and as the setup icon
;   * asks the operator for the Excel workbook path and refresh interval
;   * installs UniformanceRefresher.exe and writes config.ini next to it
;   * creates Start-Menu and (optional) Desktop shortcuts that use the logo
;
; Build:  iscc installer\setup.iss        (run from the project root on Windows,
;                                           AFTER `cargo build --release`)
; Output: installer\Output\UniformanceRefresher-Setup.exe
; ============================================================================

#define AppName        "Uniformance Excel Refresher"
#define AppVersion      "1.0.0"
#define AppPublisher    "opzen.ai"
#define ExeName         "UniformanceRefresher.exe"
; Path to the compiled binary, relative to this .iss file.
#define BuiltExe        "..\target\release\UniformanceRefresher.exe"

[Setup]
AppId={{C7E2F1A4-9B3D-4E55-8A21-7F3C0A91D2E6}}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\UniformanceRefresher
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputDir=Output
OutputBaseFilename=UniformanceRefresher-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin

; ---- Branding (logo.png -> these files via assets\make_assets.py) ----------
SetupIconFile=..\assets\logo.ico
WizardImageFile=wizard_large.bmp
WizardSmallImageFile=wizard_small.bmp
UninstallDisplayIcon={app}\{#ExeName}

[Files]
Source: "{#BuiltExe}"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\README.md";  DestDir: "{app}"; Flags: ignoreversion isreadme skipifsourcedoesntexist

[Icons]
Name: "{group}\{#AppName}";            Filename: "{app}\{#ExeName}"; IconFilename: "{app}\{#ExeName}"
Name: "{group}\Uninstall {#AppName}";  Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}";      Filename: "{app}\{#ExeName}"; IconFilename: "{app}\{#ExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"
Name: "startuprun";  Description: "Start the refresher automatically when I log in"; GroupDescription: "Startup:"; Flags: unchecked

[Run]
; Offer to launch right after install finishes.
Filename: "{app}\{#ExeName}"; Description: "Start refreshing now"; Flags: nowait postinstall skipifsilent

; ============================================================================
; Custom wizard page: ask for the workbook path + refresh interval, then write
; config.ini after files are copied.
; ============================================================================
[Code]
var
  CfgPage: TInputQueryWizardPage;

procedure InitializeWizard();
begin
  CfgPage := CreateInputQueryPage(wpSelectDir,
    'Workbook to keep refreshed',
    'Which Excel file is linked to Honeywell Uniformance?',
    'Enter the full path to the .xlsm/.xlsx workbook that contains the ' +
    'Uniformance add-in formulas, and how often it should be refreshed.');

  CfgPage.Add('Excel workbook path (e.g. C:\Data\Frac prototype.xlsm):', False);
  CfgPage.Add('Refresh interval in minutes:', False);

  // Sensible defaults.
  CfgPage.Values[0] := '';
  CfgPage.Values[1] := '10';
end;

function NextButtonClick(CurPageID: Integer): Boolean;
var
  Mins: Integer;
begin
  Result := True;
  if CurPageID = CfgPage.ID then
  begin
    if Trim(CfgPage.Values[0]) = '' then
    begin
      MsgBox('Please enter the path to the Excel workbook.', mbError, MB_OK);
      Result := False;
      Exit;
    end;
    Mins := StrToIntDef(Trim(CfgPage.Values[1]), 0);
    if Mins < 1 then
    begin
      MsgBox('Refresh interval must be a whole number of minutes (1 or more).',
        mbError, MB_OK);
      Result := False;
      Exit;
    end;
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  CfgFile: String;
  Lines: TArrayOfString;
begin
  if CurStep = ssPostInstall then
  begin
    CfgFile := ExpandConstant('{app}\config.ini');
    SetArrayLength(Lines, 5);
    Lines[0] := '; Uniformance Excel Refresher configuration';
    Lines[1] := '; Edit this file to change the workbook or interval, then restart the app.';
    Lines[2] := '';
    Lines[3] := 'excel_path = ' + Trim(CfgPage.Values[0]);
    Lines[4] := 'interval_minutes = ' + Trim(CfgPage.Values[1]);
    SaveStringsToFile(CfgFile, Lines, False);

    // Optional: register a logon autostart entry if the user ticked the task.
    if WizardIsTaskSelected('startuprun') then
      RegWriteStringValue(HKEY_CURRENT_USER,
        'Software\Microsoft\Windows\CurrentVersion\Run',
        'UniformanceRefresher',
        '"' + ExpandConstant('{app}\{#ExeName}') + '"');
  end;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usUninstall then
  begin
    // Clean up the autostart entry and config on uninstall.
    RegDeleteValue(HKEY_CURRENT_USER,
      'Software\Microsoft\Windows\CurrentVersion\Run', 'UniformanceRefresher');
    DeleteFile(ExpandConstant('{app}\config.ini'));
  end;
end;
