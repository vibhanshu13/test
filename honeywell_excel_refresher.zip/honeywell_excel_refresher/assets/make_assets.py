"""
make_assets.py
==============
Generates all installer/app image assets from ../../logo.png:

  assets/logo.ico              -> embedded as the .exe icon (winres) + installer icon
  installer/wizard_large.bmp   -> Inno Setup welcome/finish page image (164x314)
  installer/wizard_large@2x.bmp-> HiDPI variant (328x628)
  installer/wizard_small.bmp   -> Inno Setup top-banner image (55x58)
  installer/wizard_small@2x.bmp-> HiDPI variant (110x116)

Run:  python3 assets/make_assets.py    (from the project root)
"""
import os
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                 # honeywell_excel_refresher/
SRC_LOGO = os.path.join(os.path.dirname(ROOT), "logo.png")  # project logo.png
ICO_PATH = os.path.join(HERE, "logo.ico")
INST = os.path.join(ROOT, "installer")

BG = (255, 255, 255, 255)   # clean white canvas behind the (square) logo

def load_logo():
    img = Image.open(SRC_LOGO).convert("RGBA")
    return img

def make_ico(logo):
    # Multi-resolution Windows icon. Pillow writes a proper .ico with all sizes.
    sizes = [16, 24, 32, 48, 64, 128, 256]
    logo.save(ICO_PATH, format="ICO",
              sizes=[(s, s) for s in sizes])
    print("wrote", ICO_PATH)

def fit_centered(logo, canvas_w, canvas_h, margin_frac=0.12):
    """Return an RGB BMP-ready canvas with the logo centered and padded."""
    canvas = Image.new("RGBA", (canvas_w, canvas_h), BG)
    max_w = int(canvas_w * (1 - 2 * margin_frac))
    max_h = int(canvas_h * (1 - 2 * margin_frac))
    lw, lh = logo.size
    scale = min(max_w / lw, max_h / lh)
    new = logo.resize((max(1, int(lw * scale)), max(1, int(lh * scale))),
                      Image.LANCZOS)
    x = (canvas_w - new.width) // 2
    y = (canvas_h - new.height) // 2
    canvas.alpha_composite(new, (x, y))
    return canvas.convert("RGB")   # 24-bit BMP, what Inno expects

def make_bmp(logo, name, w, h):
    out = os.path.join(INST, name)
    fit_centered(logo, w, h).save(out, format="BMP")
    print("wrote", out)

def main():
    if not os.path.exists(SRC_LOGO):
        raise SystemExit(f"logo.png not found at {SRC_LOGO}")
    os.makedirs(INST, exist_ok=True)
    logo = load_logo()
    make_ico(logo)
    # Inno Setup standard sizes (and HiDPI 2x variants it auto-selects)
    make_bmp(logo, "wizard_large.bmp",    164, 314)
    make_bmp(logo, "wizard_large@2x.bmp", 328, 628)
    make_bmp(logo, "wizard_small.bmp",     55,  58)
    make_bmp(logo, "wizard_small@2x.bmp", 110, 116)
    print("done.")

if __name__ == "__main__":
    main()
