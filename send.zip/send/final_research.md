# Variable Flow Pattern Research Skill
# IBM HLASM / z/TPF / C++ Mixed-Codebase — Amex Transaction Management System
#
# HOW TO USE THIS SKILL:
#   Prompt: "Use skill final_research.md to create the prompts"
#
# What Claude does when this skill runs:
#   1. Reads the IBM KB under ibm/ (macros, patterns, migration-notes)
#   2. Reads the backward_traversal glossary (instructions.py)
#   3. Reads sample source files (.asm, .mac, .cpp, .hpp) for ground-truth patterns
#   4. Produces a COMPLETE, NUMBERED set of copy-paste-ready prompts for GPT mini
#      — covering every variable flow pattern category derived from the IBM docs
#   5. Saves all prompts to temp/var-flow-patterns/prompts.md
#
# OUTPUT CONTRACT (what the skill MUST produce):
#   - A numbered list of prompts, grouped by PATTERN CATEGORY
#   - Each prompt is ready to paste directly into GitHub Copilot (GPT mini)
#   - Each prompt has: a one-line label, the exact text to paste, and
#     "What to copy back:" instructions
#   - No placeholders. No "fill in X". Every field is concrete.
#
# ─────────────────────────────────────────────────────────────────────────────

You are a research orchestrator for an IBM HLASM / z/TPF code modernization project
at American Express.

The codebase is written in IBM High Level Assembler (HLASM) running on z/TPF OS — NOT
z/OS or MVS. It uses TPF-specific macros: ENTRC, BACKC, GETCC, CRUSA, DATEA,
DBRED/DBMOD/DBADD, CALLC, CPROC. The codebase also contains C++ files that interoperate
with ASM via CALLC/CPROC bridges and extern "C" entry points.

Your job: generate a COMPLETE, CATEGORIZED set of prompts for a remote GitHub Copilot
instance running GPT mini (a WEAK model). These prompts will be pasted one-by-one into
Copilot at the Amex server, which has the FULL codebase (millions of LOC across thousands
of .asm, .mac, .cpp, .hpp files).

---

## STEP 0 — WORKSPACE SETUP (do this first)

1. Create folder: `mkdir -p temp/var-flow-patterns/`
2. Announce the workspace path at the top of your response.
3. At the end of your response, write all prompts verbatim to
   `temp/var-flow-patterns/prompts.md`.

---

## STEP 1 — LOCAL RESEARCH (run before writing prompts)

Read the following local sources in this order. Use `grep` and file reads to extract
specific facts. Show key findings inline (don't just say "I read it").

### 1A — IBM KB: Instruction Sets
Read `backward_traversal/glossary/instructions.py`.
Extract and show:
- The complete SETTER_INST set (instructions that write to a variable)
- The complete TRIGGER_INST set (comparison/test instructions that gate branches)
- CROSS_FILE_INST (inter-program calls)
- SUBROUTINE_INST (intra-file call instructions)
Show these as comma-separated lists so you can reference them in prompts.

### 1B — IBM KB: System Macros
Read `ibm/macros/ztpf-system-macros.md`.
Extract and show:
- Which macros produce a variable-defining side effect (e.g., GETCC → R14)
- Which macros are terminal (no return): ENTNC, ENTDC, CREEC, CREMC
- Which macros are non-terminal (return): ENTRC, CALLC, CRESC

### 1C — IBM KB: DB Macros
Read `ibm/macros/ztpfdf-db-macros.md`.
Extract and show:
- The full list of DB read macros (DBRED, DBADD, DBDEL, DBREP, DBMOD, DBOPN, DBCLS, DBKEY)
- The C equivalents (dfred, dfadd, etc.) for the .cpp scan prompts
- The SW00SR / SW00REC / SW00RTN hidden-state fields to look for

### 1D — IBM KB: Patterns
Read all files under `ibm/patterns/`. Extract and show one concrete signal per pattern:
- `asm-c-interoperability.md`: the CALLC/CPROC/R15 bridge signal
- `storage-and-ecb-lifecycle.md`: the GETCC→R14 alias chain signal
- `db-open-read-update-close.md`: the DBRED→MVC→DBMOD mutation signal
- `transactions-and-commit-scopes.md`: the TXBGC/TXCMC/TXRBC scope signal
- `keyed-lrec-access.md`: the DBKEY→DBRED selection signal

### 1E — Sample Source Files
Run these grep commands on local sample files and show output:

```bash
# Setter patterns in ASM
grep -n "^\s*\(MVC\|MVI\|ST\|STM\|LA\|LR\|ZAP\|PACK\|OI\|NI\|XC\)" xh96.asm | head -20

# DB patterns in ASM
grep -n "^\s*\(DBRED\|DBMOD\|DBADD\|DBOPN\|DBCLS\|DBDEL\)" xh96.asm | head -20

# Cross-file calls
grep -n "^\s*ENTRC" xh96.asm | head -10

# C++ DB calls
grep -n "dfred\|dfmod\|dfadd\|dfopn\|dfcls" xh890000.cpp | head -20

# C++ variable assignments
grep -n "=\s" xh890000.cpp | head -20
```

Show the raw output from each grep.

---

## STEP 2 — PATTERN TAXONOMY

Based on your Step 1 findings, define the following 10 pattern categories. For each
category, show: (a) the IBM KB basis, (b) the concrete opcode/macro signals, (c) the
typical 2–4 line sequence in ASM or C++.

You MUST cover all 10 categories. If local samples don't show a category, note it and
still write the prompt for the full codebase.

### CATEGORY 1 — Direct Memory Assignment (ASM)
Signals: MVC, MVI, ST, STH, STC, STM, STCM, ZAP, PACK, UNPK, XC, NC, OC, TR
Pattern: one instruction writes a named storage field as its destination operand.
Example: `MVC LG1OSI,WKRRC` — LG1OSI is the destination, WKRRC is the source.

### CATEGORY 2 — Register-Load-then-Store Chain (ASM)
Signals: L/LH/LR/LA loads a register, then ST/STH/STC stores it to named storage.
Pattern: variable is never written directly — it flows through a register hop.
Example: `L R5,SOURCE` → ... → `ST R5,DEST` — DEST gets its value from SOURCE via R5.
IBM basis: backward_traversal glossary notes registers are filtered from dep_vars; these
chains are a known limitation — the prompts must surface them for manual review.

### CATEGORY 3 — Conditional-Guarded Assignment (ASM)
Signals: CLI/CLC/TM/LTR/CR + branch (BE/BNE/BZ/BNZ/BO/BNO) + MVC/MVI/ST
Pattern: a comparison result gates whether the assignment executes.
Example: `TM FLAG,X'80'` → `BO SKIP` → `MVC DEST,SRC` — DEST is only set when bit is off.
IBM basis: TRIGGER_INST in instructions.py.

### CATEGORY 4 — DB-Read-to-Variable Flow (ASM)
Signals: DBOPN → DBRED (sets current LREC pointer) → MVC from LREC field to workfield
Pattern: variable gets its value from a DB record field after a successful DBRED.
Example: `DBRED REF=CR21AE,...` → `CLI SW00RTN,X'00'` → `MVC DEST,CR21FIELD`
IBM basis: ztpfdf-db-macros.md (DBRED sets SW00REC/current LREC).
Note: SW00RTN must be X'00' (success) before the MVC.

### CATEGORY 5 — GETCC Storage Allocation → Variable Initialization (ASM)
Signals: GETCC Dn,Lx → LR Rx,R14 → XC/MVI/MVC to initialize fields in that block
Pattern: a new working storage block is allocated; its fields are first set via zeroing
(XC) or byte fill (MVI) immediately after allocation.
IBM basis: storage-and-ecb-lifecycle.md (GETCC returns block address in R14).
Example: `GETCC D6,L4` → `LR R1,R14` → `XC 0(L'BLOCK,R1),0(R1)`

### CATEGORY 6 — Cross-File Variable Pass via ENTRC (ASM)
Signals: ENTRC <target-program> with prior MVC/ST/LA into a parameter area
Pattern: a variable is loaded into a shared data area (often named WKxxx or EBW000)
immediately before ENTRC; the called program reads that area.
IBM basis: asm-c-interoperability.md (R1 and parameter conventions for ENTRC).
Example: `MVC EBW000(4),LGOSI` → `ENTRC XH89` — XH89 reads EBW000.

### CATEGORY 7 — ASM-to-C Bridge via CALLC / CPROC (ASM + C++)
Signals (ASM side): CPROC defines prototype → LA/LR loads args → CALLC invokes → ST R15,RCODE
Signals (C++ side): extern "C" function definition receiving those args
Pattern: variable defined in ASM is passed as a parameter to a C++ function; C++ may
write the return value back into an ASM storage field via R15.
IBM basis: ztpf-system-macros.md (CALLC), asm-c-interoperability.md.
Example: `CPROC RETURN=i,XH89,(p,i)` → `LA R2,GLREC` → `CALLC XH89(R2,R3)` → `ST R15,RC`

### CATEGORY 8 — Arithmetic / Logical Accumulation (ASM)
Signals: AH, AR, SH, SR, AP, SP, MP, DP, ZAP followed by AH/AP, SLL, SRL, OR, NI, OI, XI
Pattern: a variable's value is built up by repeated arithmetic/logical operations;
not a single copy but a cumulative computation.
Example: `ZAP TOTAL,=PL1'0'` → (loop) `AP TOTAL,AMOUNT` — TOTAL accumulates.

### CATEGORY 9 — Macro-Defined DSECT Field (MAC / ASM)
Signals: DS/DC directives inside a DSECT in a .mac file → that field name used in MVC/CLI/TM
Pattern: the variable's definition is in a copybook/macro (.mac file) DSECT, not in the
.asm file itself. The variable name (e.g., LG1OSI) is "inherited" by including that macro.
IBM basis: .mac files use DSECT + DS/DC to declare field layouts; programs include them
with a macro invocation (e.g., `LG1G1 REG=R5`).
Example in lg1lg1.mac: `LG1OSI&A DS CL1` defines the field LG1OSI.

### CATEGORY 10 — C++ Internal Variable Flow (CPP / HPP)
Signals: variable assignments in .cpp files using =, +=, -=, struct member access (->), 
function return values stored, conditional assignments (ternary, if/else branches).
Pattern: C++ variables that feed into extern "C" functions (bridging back to ASM) or
receive values from DB C API calls (dfred, dfopn, dfmod, etc.).
Example: `GlDb::Rc rc = deleteGlAccount(ptr, cardNum);` — rc gets its value from a
function whose internal logic uses dfmod/dfred.

---

## STEP 3 — GENERATE PROMPTS FOR GPT MINI (MANDATORY)

You MUST produce prompts for ALL 10 categories. Each category gets 3 prompts:
  - Prompt A: SCAN — find every instance
  - Prompt B: SCRIPT — ask GPT mini to write + execute a Python script to count/extract
  - Prompt C: CROSS-CHECK — verify from a different angle (different keyword, absence, etc.)

Total: 30 prompts. Number them 1A, 1B, 1C, 2A, 2B, 2C, ... 10A, 10B, 10C.

### WEAK-MODEL ARMOR (apply to EVERY prompt):
1. ONE atomic task per prompt. One verb, one target, one criterion.
2. Output MUST be pipe-separated (`|`). Never markdown tables. Never CSV.
3. ALWAYS end with: `No commentary. No grouping. No summary. No "I found N matches".`
4. ALWAYS include: `If no matches found, output exactly: NO_MATCHES`
5. Specify file extension explicitly (.asm, .mac, .cpp, .hpp).
6. Define every column requested.
7. For SCRIPT prompts: embed the full Python script as a code block; ask GPT mini to
   run it and paste the output. The script must not use any non-stdlib imports.

### PROMPT SKELETON — SCAN:
```
Search every [.asm/.mac/.cpp/.hpp] file in this repository.
[ONE SENTENCE: find/list every line where [EXACT CONDITION].]

[Column definitions if non-obvious.]

Output exactly this format, one row per match, no header:
filename|line_number|[col3]|[col4]

Sort by filename then line_number.

If no matches found, output exactly: NO_MATCHES
No commentary. No grouping. No summary. No "I found N matches".
```

### PROMPT SKELETON — SCRIPT:
```
Write and execute a Python script that does the following:
[ONE SENTENCE describing what to count/extract/report.]

Requirements:
- Use only Python standard library (os, re, glob, collections).
- Search recursively from the current directory.
- [Specific file extensions to search.]
- [Specific pattern to match.]
- Output format: [exact pipe-separated format]

Paste the complete script first, then paste its output verbatim.

If no matches found, output exactly: NO_MATCHES
No commentary. No grouping. No summary.
```

### PROMPT SKELETON — CROSS-CHECK:
```
[Run independently.]
Search every [extension] file in this repository.
[ONE SENTENCE: different angle — verify presence/absence of related signal.]

Output exactly this format, one row per match, no header:
filename|line_number|raw_line

Sort by filename then line_number.

If no matches found, output exactly: NO_MATCHES
No commentary. No grouping. No summary. No "I found N matches".
```

---

Now produce all 30 prompts below. For each prompt: write the label, then the exact
paste-ready text in a fenced code block, then "What to copy back:".

Do NOT use placeholders. Every pattern, opcode, and field name must be the real value
derived from Step 1.

After all 30 prompts, tell the user:

> All 30 prompts are saved to `temp/var-flow-patterns/prompts.md`.
>
> **How to run:**
> - Prompts ending in A (SCAN) and C (CROSS-CHECK) are independent — run in any order.
> - Prompts ending in B (SCRIPT) are also independent — run after A to compare counts.
> - Prompts within the same category (e.g., 4A, 4B, 4C) cover the same pattern from
>   three angles. Paste results back here after all three for synthesis.
>
> **Paste results back using this template:**
> ```
> CATEGORY [N] — [name]
> --- [N]A SCAN ---
> [paste raw output]
> --- [N]B SCRIPT ---
> [paste script then output]
> --- [N]C CROSS-CHECK ---
> [paste raw output]
> ```

---

## STEP 4 — SYNTHESIS (when user pastes results back)

When the user pastes results for any category, do the following in order:

1. **Save raw results** to `temp/var-flow-patterns/results-cat[N].md` verbatim.

2. **Classify each finding** into:
   | Label | Meaning |
   |---|---|
   | CONFIRMED | Pattern found exactly as expected from IBM KB |
   | VARIANT | Pattern found but with unexpected operand shape or context |
   | NOVEL | Pattern not in the 10-category taxonomy — needs new category |
   | FALSE_POS | Hit matched the grep but is NOT a variable flow pattern |

3. **Gap assessment**: State in one paragraph exactly what the backward_traversal
   Python code currently handles vs. what it misses, based on the real pattern counts.
   Reference specific files: `backward_traversal/glossary/instructions.py`,
   `backward_traversal/tracing/asm_backward_tracer.py`,
   `backward_traversal/bridge/cross_file_bridge_backward.py`.

4. **Recommendation**: For each VARIANT or NOVEL finding, state whether:
   - It should be added to SETTER_INST / TRIGGER_INST in `instructions.py`
   - It requires a new detection pass in `asm_backward_tracer.py`
   - It is outside scope (too rare or too ambiguous to automate)

5. **Write `temp/var-flow-patterns/synthesis-cat[N].md`** with:
   - Category name and number
   - Pattern count (confirmed/variant/novel/false_pos)
   - Gap paragraph
   - Recommendation(s)
   - List of exact lines from client output that are NOVEL (verbatim)

---

## CONTEXT ALWAYS TRUE FOR THIS PROJECT

### The full codebase shape (at Amex server):
- Thousands of `.asm` files — HLASM source, z/TPF entry programs
- Hundreds of `.mac` files — DSECT copybooks, macro definitions
- Hundreds of `.cpp` / `.hpp` files — C++ modules callable via CALLC/CPROC
- All interlinked via ENTRC (ASM→ASM), CALLC (ASM→C++), extern "C" (C++→ASM)
- The backward_traversal engine processes blueprint `.asm.json` files; the raw source
  (.asm, .mac, .cpp) is what GPT mini searches.

### Instruction classification (from `backward_traversal/glossary/instructions.py`):
- **SETTER_INST** (instructions that write a variable):
  MVC, MVI, XC, ZAP, ST, STM, STCM, STCK, STH, STC, PACK, CVB, CVD, LA, NI, OI, XI,
  API, SPI, AH, SH, TR, TRT, L, LH, IC, LR, ICM, NC, OC, UNPK, MVN, MVZ, MVO,
  MVCL, MVCP, MVCS, MP, DP, AHI, AR, AG, SLL, SRL, SLR, SRA
- **TRIGGER_INST** (comparison/test instructions): CLC, CLI, TM, CP, LTR, C, CR, CH, CL, CLR
- **BRANCH_INST**: B, BE, BNE, BZ, BNZ, BH, BNH, BM, BNM, BO, BNO, BP, BNP, BCT,
  J, JE, JNE, JZ, JNZ, JH, JNH, JL, JNL, JM, JNM, JO, JNO, JP, JNP, JXHG, JXLE, BC, BCTR
- **SUBROUTINE_INST**: BAS, BAL, BASR
- **CROSS_FILE_INST**: ENTRC, ENTNC, ENTDC, CREEC, CREMC, SWISC, FUNCTION, ENTRY
- **RETURN_OPCODES**: BR, BCR, PR, BSM, BASR, BACKC, EXITC, RETURN

### Dep-var filtering rules (tokens that are NOT variable names):
- R0–R15 (standard registers)
- R[A-Z][A-Z0-9]{0,1} pattern (register aliases like RGA, RGB)
- Tokens containing `'` (self-defining literals: C'Y', X'FF')
- Pure digit tokens (displacement values like 0, 1, 6)
- Tokens containing `#` (EQU constants like WB#OTB, LG#C400)
- Tokens starting with `=` (literal address constants like =C'00', =F'4402')
- Tokens not matching `^[A-Z@$_][A-Z0-9@$_]*$`

### GPT mini constraints (NEVER violate):
- Model is WEAK — one atomic task per prompt, no chained reasoning
- Output format: pipe-separated (`|`) ONLY — no markdown tables, no CSV
- Always include anti-hallucination anchor: `If no matches found, output exactly: NO_MATCHES`
- Closing line on every prompt: `No commentary. No grouping. No summary. No "I found N matches".`
- Label prompts that depend on prior output: `Run after Prompt [N][X].`
- Specify file extension every time — never just "all files"
- For SCRIPT prompts: only Python stdlib — no pip installs

### Current backward_traversal known limitations (do NOT re-research these):
- Register-chained values: if DEST ← R5 ← SOURCE, the R5 hop is NOT followed
- C++ dep_var filtering: dep_vars in C++ upstream nodes are not collected
- Non-returning cross-file calls (ENTNC/ENTDC/CREEC/CREMC/SWISC) not followed downstream
- DSECT base register context: displacement addressing (0(R5)) not resolved to field name

---

## ITERATION PROTOCOL

After all categories are researched and synthesized:
- If synthesis reveals a NOVEL category, run `/research <new pattern name>` in a new
  workspace `temp/var-flow-patterns-ext/` rather than expanding the current workspace.
- Each workspace covers one focused research question and produces one synthesis file.
- The final deliverable is a combined `temp/var-flow-patterns/FINAL-TAXONOMY.md` that
  merges all category synthesis files into a single canonical list of patterns, with:
  - Pattern name
  - Frequency (count from full codebase)
  - Current tool coverage (YES/PARTIAL/NO)
  - Recommended action for the backward_traversal engine
