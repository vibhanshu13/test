"""Parse symbol-defining directives from assembly code."""

from typing import List, Optional
from models.symbol import Symbol, SymbolType
from tokenizer import ParsedLine


class SymbolParser:
    """Parses symbol definitions from assembly directives.

    Handles: ENTRY, EXTRN, WXTRN, CSECT, DSECT, RSECT, EQU, DC
    """

    def parse_line(
        self,
        parsed_line: ParsedLine,
        current_section: Optional[str] = None
    ) -> List[Symbol]:
        """Parse a line and extract any symbol definitions.

        Args:
            parsed_line: Tokenized assembly line
            current_section: Current section context (for label resolution)

        Returns:
            List of symbols defined on this line (may be empty)
        """
        symbols = []
        opcode = parsed_line.opcode

        if not opcode:
            return symbols

        opcode_upper = opcode.upper()

        if opcode_upper == "ENTRY":
            symbols.extend(self._parse_entry(parsed_line))
        elif opcode_upper == "EXTRN":
            symbols.extend(self._parse_extrn(parsed_line))
        elif opcode_upper == "WXTRN":
            symbols.extend(self._parse_wxtrn(parsed_line))
        elif opcode_upper in ("CSECT", "DSECT", "RSECT"):
            symbol = self._parse_section(parsed_line, opcode_upper)
            if symbol:
                symbols.append(symbol)
        elif opcode_upper == "EQU":
            symbol = self._parse_equ(parsed_line, current_section)
            if symbol:
                symbols.append(symbol)
        elif opcode_upper == "DC":
            symbol = self._parse_dc(parsed_line, current_section)
            if symbol:
                symbols.append(symbol)

        return symbols

    def _parse_entry(self, parsed_line: ParsedLine) -> List[Symbol]:
        """Parse ENTRY directive.

        ENTRY can define multiple symbols: ENTRY MAIN,HELPER,UTILS

        Args:
            parsed_line: Tokenized line

        Returns:
            List of ENTRY symbols
        """
        if not parsed_line.operands:
            return []

        symbols = []

        for name in parsed_line.operands:
            name = name.strip()
            if name:
                symbol = Symbol(
                    name=name,
                    symbol_type=SymbolType.ENTRY,
                    file=parsed_line.provenance.original_file,
                    provenance=parsed_line.provenance
                )
                symbols.append(symbol)

        return symbols

    def _parse_extrn(self, parsed_line: ParsedLine) -> List[Symbol]:
        """Parse EXTRN directive.

        Args:
            parsed_line: Tokenized line

        Returns:
            List of EXTRN symbols
        """
        if not parsed_line.operands:
            return []

        symbols = []

        for name in parsed_line.operands:
            name = name.strip()
            if name:
                symbol = Symbol(
                    name=name,
                    symbol_type=SymbolType.EXTRN,
                    file=parsed_line.provenance.original_file,
                    provenance=parsed_line.provenance
                )
                symbols.append(symbol)

        return symbols

    def _parse_wxtrn(self, parsed_line: ParsedLine) -> List[Symbol]:
        """Parse WXTRN directive.

        Args:
            parsed_line: Tokenized line

        Returns:
            List of WXTRN symbols
        """
        if not parsed_line.operands:
            return []

        symbols = []

        for name in parsed_line.operands:
            name = name.strip()
            if name:
                symbol = Symbol(
                    name=name,
                    symbol_type=SymbolType.WXTRN,
                    file=parsed_line.provenance.original_file,
                    provenance=parsed_line.provenance
                )
                symbols.append(symbol)

        return symbols

    def _parse_section(self, parsed_line: ParsedLine, section_type: str) -> Optional[Symbol]:
        """Parse section directive (CSECT, DSECT, RSECT).

        Section directives use the label as the section name.
        Example: MAIN CSECT

        Args:
            parsed_line: Tokenized line
            section_type: "CSECT", "DSECT", or "RSECT"

        Returns:
            Symbol if label present, None otherwise
        """
        if not parsed_line.label:
            return None

        symbol_type = SymbolType[section_type]

        return Symbol(
            name=parsed_line.label,
            symbol_type=symbol_type,
            file=parsed_line.provenance.original_file,
            provenance=parsed_line.provenance,
            section=parsed_line.label  # Section name is the label itself
        )

    def _parse_equ(self, parsed_line: ParsedLine, current_section: Optional[str]) -> Optional[Symbol]:
        """Parse EQU directive.

        EQU defines constants. Example: MAXLEN EQU 256
        Value may be numeric or symbolic (we try to parse as int).

        Args:
            parsed_line: Tokenized line
            current_section: Current section for scoping

        Returns:
            Symbol if label present, None otherwise
        """
        if not parsed_line.label:
            return None

        value = None
        expression = None
        if parsed_line.operands and len(parsed_line.operands) > 0:
            expression = parsed_line.operands[0].strip()
            # Try to parse first operand as integer
            try:
                value = int(expression)
            except ValueError:
                # Symbolic value - store as None for now
                # (would need expression evaluator for full support)
                value = None

        return Symbol(
            name=parsed_line.label,
            symbol_type=SymbolType.EQU,
            file=parsed_line.provenance.original_file,
            provenance=parsed_line.provenance,
            value=value,
            expression=expression,
            section=current_section
        )

    def _parse_dc(self, parsed_line: ParsedLine, current_section: Optional[str]) -> Optional[Symbol]:
        """Parse DC directive — records the label as a DC-defined constant.

        DC defines storage with an initial value (ZEROS DC 15C'0').
        Only lines with a label are recorded; anonymous DC blocks are skipped.

        Args:
            parsed_line: Tokenized line
            current_section: Current section for scoping

        Returns:
            Symbol if label present, None otherwise
        """
        if not parsed_line.label:
            return None
        expression = parsed_line.operands[0].strip() if parsed_line.operands else None
        return Symbol(
            name=parsed_line.label,
            symbol_type=SymbolType.DC,
            file=parsed_line.provenance.original_file,
            provenance=parsed_line.provenance,
            value=None,
            expression=expression,
            section=current_section,
        )
