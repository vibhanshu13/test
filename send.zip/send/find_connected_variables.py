#!/usr/bin/env python3
"""find_connected_variables.py

Given two HLASM ASM file stems, find all connected variables between them.

Four connection types are detected:
  1. call_boundary_registers  — registers the caller loads before ENTRC/ENTNC
                                 that the callee reads before writing
  2. return_registers         — registers the callee sets before BR/BACKC
                                 that the caller reads after ENTRC returns
                                 (ENTRC only; ENTNC never returns)
  3. shared_dsects            — same MACRO_NAME REG=Rx declaration in both files
  4. shared_memory_fields     — same field name in both files' global_variable_lineage

Usage:
  python find_connected_variables.py <stem_a> <stem_b> [options]

Options:
  --asm-dir DIR         Directory containing .asm source files
  --blueprint-dir DIR   Directory containing .asm.json blueprint files
  --output FILE         Output JSON path (default: {a}_{b}_connections.json)
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from blueprint_io import iter_flow, load_blueprint
from cross_file_bridge import (
    _discover_asm_dir,
    _discover_blueprint_dir,
    find_asm_callers,
)
from trace_lineage import (
    CROSS_FILE_INST,
    REGISTERS,
    SETTER_INST,
    parse_instruction_line,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Instructions that write to their first (destination) register argument.
# LM is handled separately (range write). STM reads registers, writes memory.
WRITE_DEST_INSTS: Set[str] = {
    "L", "LR", "LA", "LH", "LTR", "LCR", "LNR", "LPR", "IC", "ICM",
    "A", "AR", "AH", "AL", "ALR", "S", "SR", "SH", "SL", "SLR",
    "N", "NR", "O", "OR", "X", "XR",
    "SLA", "SRA", "SLL", "SRL", "SLDA", "SRDA",
    "BAL", "BAS", "BALR", "BASR", "CVB", "CVBG",
    "LM",   # included here for convenience; expanded separately in callers
}

RETURN_INST: Set[str] = {"BR", "BACKC"}

CALLER_WINDOW = 30   # lines to scan before ENTRC when no blueprint block boundary
CALLEE_ENTRY_WINDOW = 60   # lines to scan at callee entry when no blueprint
RETURN_WINDOW = 20   # lines to scan before BR/BACKC for callee return values
POST_CALL_WINDOW = 15   # lines to scan after ENTRC for caller post-call reads

_DSECT_REG_RE = re.compile(r"\bREG=(R?\d+)\b", re.IGNORECASE)
_DSECT_SUFFIX_RE = re.compile(r"\bSUFFIX=([A-Z0-9]+)\b", re.IGNORECASE)
_PAREN_RE = re.compile(r"\(([^)]+)\)")


# ---------------------------------------------------------------------------
# Register utilities
# ---------------------------------------------------------------------------

def _reg_num(token: str) -> Optional[int]:
    """Return the integer register number for a token like R5, R14, or 5."""
    m = re.match(r"^R?(\d{1,2})$", token.strip(), re.IGNORECASE)
    if m:
        n = int(m.group(1))
        if 0 <= n <= 15:
            return n
    return None


def _lm_range(r_start: str, r_end: str) -> List[str]:
    """Return list of register names for LM/STM Rstart,Rend range.

    Handles wrap-around: LM R14,R12 → R14,R15,R0,R1,...,R12.
    """
    s = _reg_num(r_start)
    e = _reg_num(r_end)
    if s is None or e is None:
        return []
    if s <= e:
        return [f"R{i}" for i in range(s, e + 1)]
    # wrap-around
    return [f"R{i}" for i in range(s, 16)] + [f"R{i}" for i in range(0, e + 1)]


def _extract_addr_registers(operand: str) -> List[str]:
    """Return register names found inside parentheses in an addressing operand.

    Examples: '0(R7,R2)' → ['R7','R2'],  'FIELD(R3)' → ['R3']
    """
    m = _PAREN_RE.search(operand)
    if not m:
        return []
    regs = []
    for part in m.group(1).split(","):
        n = _reg_num(part.strip())
        if n is not None:
            regs.append(f"R{n}")
    return regs


# ---------------------------------------------------------------------------
# Blueprint helpers
# ---------------------------------------------------------------------------

def _load_blueprint(bp_path: Path) -> Optional[Dict[str, Any]]:
    if not bp_path.exists():
        return None
    try:
        return load_blueprint(bp_path)
    except Exception:
        return None


def _get_block_start_line(call_line: int, blueprint: Dict) -> Optional[int]:
    """Find the first line of the block that contains call_line."""
    for block in blueprint.get("blocks", []):
        lines = [e["line"] for e in iter_flow(block) if "line" in e]
        if lines and min(lines) <= call_line <= max(lines):
            return min(lines)
    return None


def _get_entry_block_bounds(blueprint: Dict) -> Tuple[int, int]:
    """Return (start_line, end_line) of the earliest block in the blueprint."""
    best_start = None
    best_end = None
    for block in blueprint.get("blocks", []):
        lines = [e["line"] for e in iter_flow(block) if "line" in e]
        if not lines:
            continue
        s, e = min(lines), max(lines)
        if best_start is None or s < best_start:
            best_start = s
            best_end = e
    return (best_start or 1, best_end or CALLEE_ENTRY_WINDOW)


def _get_field_accesses(blueprint: Dict, asm_path: Path) -> Dict[str, List[Dict]]:
    """Return {field_name: [{relation, line, expression, scope}]} for own file only."""
    own = str(asm_path)
    result: Dict[str, List[Dict]] = {}
    for edge in blueprint.get("global_variable_lineage", {}).get("edges", []):
        edge_file = edge.get("file", "")
        if not (edge_file == own or Path(edge_file).name == asm_path.name):
            continue
        for node_id in (edge.get("source", ""), edge.get("target", "")):
            if node_id.startswith("memory:"):
                name = node_id[7:]
                result.setdefault(name, []).append({
                    "relation": edge.get("relation"),
                    "line": edge.get("line"),
                    "expression": edge.get("expression"),
                    "scope": edge.get("scope"),
                })
    return result


# ---------------------------------------------------------------------------
# DSECT detection
# ---------------------------------------------------------------------------

def _get_dsect_macros(asm_lines: List[str]) -> List[Tuple[str, str, str, int]]:
    """Return (macro_name, suffix, register, lineno) for every MACRO REG=Rx line."""
    results = []
    for lineno, line in enumerate(asm_lines, 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("*"):
            continue

        reg_m = _DSECT_REG_RE.search(line)
        if not reg_m:
            continue

        # Find the macro name: first token if line starts with space,
        # second token if first column is non-space (label present).
        tokens = stripped.split()
        if not tokens:
            continue
        macro = tokens[1].upper() if (line[0] != " " and len(tokens) >= 2) else tokens[0].upper()

        # Skip obvious non-macro tokens (opcodes, directives)
        if macro in ("DS", "DC", "EQU", "CSECT", "DSECT", "USING", "DROP"):
            continue

        reg_raw = reg_m.group(1).upper()
        reg = reg_raw if reg_raw.startswith("R") else f"R{reg_raw}"
        suf_m = _DSECT_SUFFIX_RE.search(line)
        suffix = suf_m.group(1).upper() if suf_m else ""

        results.append((macro, suffix, reg, lineno))
    return results


def find_shared_dsects(
    stem_a: str,
    stem_b: str,
    asm_path_a: Path,
    asm_path_b: Path,
) -> List[Dict[str, Any]]:
    lines_a = asm_path_a.read_text(encoding="utf-8", errors="replace").splitlines()
    lines_b = asm_path_b.read_text(encoding="utf-8", errors="replace").splitlines()

    macros_a = _get_dsect_macros(lines_a)
    macros_b = _get_dsect_macros(lines_b)

    idx_a: Dict[Tuple[str, str], Tuple[str, int]] = {
        (m, s): (r, l) for m, s, r, l in macros_a
    }
    idx_b: Dict[Tuple[str, str], Tuple[str, int]] = {
        (m, s): (r, l) for m, s, r, l in macros_b
    }

    shared = []
    for key in sorted(set(idx_a.keys()) & set(idx_b.keys())):
        macro, suffix = key
        reg_a, line_a = idx_a[key]
        reg_b, line_b = idx_b[key]
        display = macro + (f",SUFFIX={suffix}" if suffix else "")
        shared.append({
            "macro": macro,
            "suffix": suffix,
            "display_name": display,
            "in_file_a": {"stem": stem_a, "register": reg_a, "line": line_a},
            "in_file_b": {"stem": stem_b, "register": reg_b, "line": line_b},
            "same_register": reg_a == reg_b,
            "note": "same_reg" if reg_a == reg_b else "different_reg_aliases",
        })
    return shared


# ---------------------------------------------------------------------------
# Register scanning — caller side (what's set before the call)
# ---------------------------------------------------------------------------

def scan_caller_registers_set(
    call_site: Dict[str, Any],
    asm_lines: List[str],
    blueprint: Optional[Dict],
) -> Dict[str, Any]:
    """Forward-scan from block start to call_line; record last write per register."""
    call_line: int = call_site["line"]

    scan_start = None
    if blueprint is not None:
        scan_start = _get_block_start_line(call_line, blueprint)
    if scan_start is None:
        scan_start = max(1, call_line - CALLER_WINDOW)

    written: Dict[str, Dict] = {}

    for lineno in range(scan_start, call_line):
        if lineno > len(asm_lines):
            break
        raw = asm_lines[lineno - 1]
        _, inst, args = parse_instruction_line(raw)
        if inst is None:
            continue
        inst_up = inst.upper()

        if inst_up == "LM":
            if len(args) >= 2:
                for reg in _lm_range(args[0], args[1]):
                    written[reg] = {
                        "register": reg,
                        "set_at_line": lineno,
                        "instruction": "LM",
                        "raw_line": raw.rstrip(),
                    }
        elif inst_up in WRITE_DEST_INSTS:
            if args:
                n = _reg_num(args[0])
                if n is not None:
                    reg = f"R{n}"
                    written[reg] = {
                        "register": reg,
                        "set_at_line": lineno,
                        "instruction": inst_up,
                        "raw_line": raw.rstrip(),
                    }

    return {
        "scan_start_line": scan_start,
        "call_line": call_line,
        "registers_set": list(written.values()),
    }


# ---------------------------------------------------------------------------
# Register scanning — callee side (what's consumed at entry)
# ---------------------------------------------------------------------------

def scan_callee_registers_consumed(
    asm_lines: List[str],
    blueprint: Optional[Dict],
) -> Dict[str, Any]:
    """Forward-scan from entry; find registers read before being written."""
    if blueprint is not None:
        entry_start, entry_end = _get_entry_block_bounds(blueprint)
    else:
        entry_start = 1
        entry_end = min(len(asm_lines), CALLEE_ENTRY_WINDOW)

    written: Set[str] = set()
    consumed: Dict[str, Dict] = {}
    stop_reason = "end_of_entry_block"

    for lineno in range(entry_start, entry_end + 1):
        if lineno > len(asm_lines):
            break
        raw = asm_lines[lineno - 1]
        _, inst, args = parse_instruction_line(raw)
        if inst is None:
            continue
        inst_up = inst.upper()

        if inst_up in CROSS_FILE_INST:
            stop_reason = "first_cross_file_call"
            break

        def _maybe_consume(reg: str) -> None:
            if reg not in written and reg not in consumed:
                consumed[reg] = {
                    "register": reg,
                    "first_read_at_line": lineno,
                    "instruction": inst_up,
                    "raw_line": raw.rstrip(),
                }

        if inst_up == "LM":
            # LM Rstart,Rend,ADDR: reads base reg in ADDR, writes Rstart..Rend
            if len(args) >= 3:
                for reg in _extract_addr_registers(args[2]):
                    _maybe_consume(reg)
            if len(args) >= 2:
                for reg in _lm_range(args[0], args[1]):
                    written.add(reg)

        elif inst_up == "STM":
            # STM Rstart,Rend,ADDR: reads Rstart..Rend + base reg in ADDR
            if len(args) >= 2:
                for reg in _lm_range(args[0], args[1]):
                    _maybe_consume(reg)
            if len(args) >= 3:
                for reg in _extract_addr_registers(args[2]):
                    _maybe_consume(reg)

        elif inst_up == "LR" and len(args) >= 2:
            # LR Rdest,Rsrc: reads Rsrc, writes Rdest
            src_n = _reg_num(args[1])
            if src_n is not None:
                _maybe_consume(f"R{src_n}")
            dest_n = _reg_num(args[0])
            if dest_n is not None:
                written.add(f"R{dest_n}")

        elif inst_up in WRITE_DEST_INSTS:
            # Writes arg[0]; reads everything else + addr modes
            dest_n = _reg_num(args[0]) if args else None
            if dest_n is not None:
                written.add(f"R{dest_n}")
            for arg in (args[1:] if args else []):
                src_n = _reg_num(arg)
                if src_n is not None:
                    _maybe_consume(f"R{src_n}")
                for reg in _extract_addr_registers(arg):
                    _maybe_consume(reg)
            # Also check addr modes in arg[0] (base reg for load with displacement)
            if args:
                for reg in _extract_addr_registers(args[0]):
                    _maybe_consume(reg)

        else:
            # All register references are reads (branches, CLC, MVC, etc.)
            for arg in (args or []):
                src_n = _reg_num(arg)
                if src_n is not None:
                    _maybe_consume(f"R{src_n}")
                for reg in _extract_addr_registers(arg):
                    _maybe_consume(reg)

    return {
        "entry_start_line": entry_start,
        "entry_end_line": entry_end,
        "scan_stop_reason": stop_reason,
        "registers_consumed": list(consumed.values()),
    }


# ---------------------------------------------------------------------------
# Register scanning — callee side (what's set before return)
# ---------------------------------------------------------------------------

def scan_callee_return_registers(
    asm_lines: List[str],
) -> Dict[str, Any]:
    """Find registers set just before BR/BACKC return instructions."""
    return_lines: List[int] = []
    link_reg: Optional[str] = None

    for lineno, raw in enumerate(asm_lines, 1):
        _, inst, args = parse_instruction_line(raw)
        if inst is None:
            continue
        inst_up = inst.upper()
        if inst_up == "BR" and args:
            n = _reg_num(args[0])
            if n is not None:
                return_lines.append(lineno)
                if link_reg is None:
                    link_reg = f"R{n}"
        elif inst_up == "BACKC":
            return_lines.append(lineno)

    if not return_lines:
        return {"return_registers": [], "return_instruction": None, "link_register": None}

    # BACKC routines don't return values via the normal register convention —
    # link_reg is None means no BR was found, so the dest != link_reg guard
    # would be dest != None which is always True, producing false positives.
    if link_reg is None:
        return {"return_registers": [], "return_instruction": "BACKC", "link_register": None}

    set_before_return: Dict[str, Dict] = {}

    for ret_line in return_lines:
        window_start = max(1, ret_line - RETURN_WINDOW)
        for lineno in range(window_start, ret_line):
            if lineno > len(asm_lines):
                break
            raw = asm_lines[lineno - 1]
            _, inst, args = parse_instruction_line(raw)
            if inst is None:
                continue
            inst_up = inst.upper()

            # Skip LM (register restore patterns — restoring caller's regs, not return values)
            if inst_up == "LM":
                continue

            if inst_up in WRITE_DEST_INSTS and args:
                dest_n = _reg_num(args[0])
                if dest_n is not None:
                    dest = f"R{dest_n}"
                    if dest != link_reg and dest not in set_before_return:
                        set_before_return[dest] = {
                            "register": dest,
                            "set_at_line": lineno,
                            "instruction": inst_up,
                            "raw_line": raw.rstrip(),
                        }

    return {
        "return_registers": list(set_before_return.values()),
        "return_instruction": f"BR {link_reg}" if link_reg else "BACKC",
        "link_register": link_reg,
    }


# ---------------------------------------------------------------------------
# Register scanning — caller side (what's read after ENTRC returns)
# ---------------------------------------------------------------------------

def scan_caller_post_call_reads(
    call_site: Dict[str, Any],
    asm_lines: List[str],
) -> Set[str]:
    """Scan POST_CALL_WINDOW lines after the call for registers read before written."""
    call_line: int = call_site["line"]
    post_start = call_line + 1
    post_end = min(len(asm_lines), post_start + POST_CALL_WINDOW)

    written: Set[str] = set()
    reads: Set[str] = set()

    for lineno in range(post_start, post_end + 1):
        if lineno > len(asm_lines):
            break
        raw = asm_lines[lineno - 1]
        _, inst, args = parse_instruction_line(raw)
        if inst is None:
            continue
        inst_up = inst.upper()

        if inst_up in CROSS_FILE_INST:
            break

        if inst_up == "LM":
            if len(args) >= 2:
                for reg in _lm_range(args[0], args[1]):
                    written.add(reg)
        elif inst_up in WRITE_DEST_INSTS and args:
            # Sources (args[1..]) are reads
            for arg in args[1:]:
                src_n = _reg_num(arg)
                if src_n is not None and f"R{src_n}" not in written:
                    reads.add(f"R{src_n}")
                for reg in _extract_addr_registers(arg):
                    if reg not in written:
                        reads.add(reg)
            # Destination is written
            dest_n = _reg_num(args[0])
            if dest_n is not None:
                written.add(f"R{dest_n}")
        else:
            for arg in (args or []):
                src_n = _reg_num(arg)
                if src_n is not None and f"R{src_n}" not in written:
                    reads.add(f"R{src_n}")
                for reg in _extract_addr_registers(arg):
                    if reg not in written:
                        reads.add(reg)

    return reads


# ---------------------------------------------------------------------------
# Register connection analysis — per direction
# ---------------------------------------------------------------------------

def find_register_connections(
    direction: str,
    caller_stem: str,
    callee_stem: str,
    call_sites: List[Dict[str, Any]],
    asm_dir: Path,
    blueprint_dir: Path,
) -> List[Dict[str, Any]]:
    caller_asm = asm_dir / f"{caller_stem}.asm"
    callee_asm = asm_dir / f"{callee_stem}.asm"

    if not caller_asm.exists() or not callee_asm.exists():
        return []

    caller_lines = caller_asm.read_text(encoding="utf-8", errors="replace").splitlines()
    callee_lines = callee_asm.read_text(encoding="utf-8", errors="replace").splitlines()

    caller_bp = _load_blueprint(blueprint_dir / f"{caller_stem}.asm.json")
    callee_bp = _load_blueprint(blueprint_dir / f"{callee_stem}.asm.json")

    # Compute callee's consumed registers once (same entry for all call sites)
    callee_consumed_info = scan_callee_registers_consumed(callee_lines, callee_bp)
    callee_consumed_regs = {e["register"] for e in callee_consumed_info["registers_consumed"]}

    # Compute callee's return registers once
    callee_return_info = scan_callee_return_registers(callee_lines)
    callee_return_regs = {e["register"] for e in callee_return_info["return_registers"]}

    results = []
    for site in call_sites:
        is_entrc = (site.get("instruction") or "").upper() == "ENTRC"

        caller_set_info = scan_caller_registers_set(site, caller_lines, caller_bp)
        caller_set_regs = {e["register"] for e in caller_set_info["registers_set"]}

        # Passed registers = set by caller AND consumed by callee
        passed_regs = caller_set_regs & callee_consumed_regs
        passed = []
        for e in caller_set_info["registers_set"]:
            if e["register"] not in passed_regs:
                continue
            callee_rec = next(
                (c for c in callee_consumed_info["registers_consumed"]
                 if c["register"] == e["register"]),
                None,
            )
            passed.append({
                "register": e["register"],
                "set_by_caller": {
                    "line": e["set_at_line"],
                    "instruction": e["instruction"],
                    "raw_line": e["raw_line"],
                },
                "consumed_by_callee": {
                    "line": callee_rec["first_read_at_line"] if callee_rec else None,
                    "instruction": callee_rec["instruction"] if callee_rec else None,
                },
            })

        # Return registers (only relevant for ENTRC)
        return_connections = []
        if is_entrc and callee_return_regs:
            post_reads = scan_caller_post_call_reads(site, caller_lines)
            for e in callee_return_info["return_registers"]:
                if e["register"] in post_reads:
                    return_connections.append({
                        "register": e["register"],
                        "set_by_callee": {
                            "line": e["set_at_line"],
                            "instruction": e["instruction"],
                            "raw_line": e["raw_line"],
                        },
                        "read_by_caller_after_return": True,
                    })

        results.append({
            "direction": direction,
            "caller": caller_stem,
            "callee": callee_stem,
            "call_site": {
                "routine": site.get("routine"),
                "line": site.get("line"),
                "instruction": site.get("instruction"),
                "call_type": site.get("call_type"),
                "raw_line": site.get("raw_line"),
            },
            "passed_registers": passed,
            "return_registers": return_connections,
            "callee_entry_scan": callee_consumed_info,
            "caller_block_scan": caller_set_info,
        })

    return results


# ---------------------------------------------------------------------------
# Shared memory fields
# ---------------------------------------------------------------------------

def find_shared_memory_fields(
    stem_a: str,
    stem_b: str,
    bp_path_a: Path,
    bp_path_b: Path,
    asm_path_a: Path,
    asm_path_b: Path,
) -> List[Dict[str, Any]]:
    bp_a = _load_blueprint(bp_path_a)
    bp_b = _load_blueprint(bp_path_b)
    if bp_a is None or bp_b is None:
        return []

    fields_a = _get_field_accesses(bp_a, asm_path_a)
    fields_b = _get_field_accesses(bp_b, asm_path_b)

    shared_names = set(fields_a.keys()) & set(fields_b.keys())

    # Filter trivial names
    meaningful = [
        f for f in shared_names
        if len(f) >= 3
        and not f.startswith("=")
        and not f.isdigit()
        and f.upper() not in REGISTERS
        and not re.match(r"^[A-Z]$", f, re.IGNORECASE)
    ]

    result = []
    for name in sorted(meaningful):
        result.append({
            "field": name,
            "in_file_a": fields_a[name],
            "in_file_b": fields_b[name],
        })
    return result


# ---------------------------------------------------------------------------
# Safe wrapper for find_asm_callers (handles missing blueprints gracefully)
# ---------------------------------------------------------------------------

def _safe_find_asm_callers(
    caller_stem: str,
    callee_stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path],
) -> List[Dict[str, Any]]:
    """Return call sites or [] if caller blueprint is missing."""
    bp_path = blueprint_dir / f"{caller_stem}.asm.json"
    if not bp_path.exists():
        return []
    return find_asm_callers(caller_stem, callee_stem, blueprint_dir, asm_dir)


# ---------------------------------------------------------------------------
# Top-level orchestration
# ---------------------------------------------------------------------------

def find_all_connections(
    stem_a: str,
    stem_b: str,
    blueprint_dir: Path,
    asm_dir: Path,
) -> Dict[str, Any]:
    warnings: List[str] = []

    result: Dict[str, Any] = {
        "file_a": stem_a,
        "file_b": stem_b,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "call_summary": {"a_calls_b": [], "b_calls_a": []},
        "connections": {
            "call_boundary_registers": [],
            "return_registers": [],
            "shared_dsects": [],
            "shared_memory_fields": [],
        },
        "warnings": warnings,
    }

    asm_a = asm_dir / f"{stem_a}.asm"
    asm_b = asm_dir / f"{stem_b}.asm"
    bp_a = blueprint_dir / f"{stem_a}.asm.json"
    bp_b = blueprint_dir / f"{stem_b}.asm.json"

    # 1. Find call sites in both directions
    a_calls_b = _safe_find_asm_callers(stem_a, stem_b, blueprint_dir, asm_dir)
    b_calls_a = _safe_find_asm_callers(stem_b, stem_a, blueprint_dir, asm_dir)
    result["call_summary"]["a_calls_b"] = a_calls_b
    result["call_summary"]["b_calls_a"] = b_calls_a

    # 2. Register connections at call boundaries
    if not asm_a.exists():
        warnings.append(f"ASM file not found for '{stem_a}' — register analysis skipped")
    if not asm_b.exists():
        warnings.append(f"ASM file not found for '{stem_b}' — register analysis skipped")

    if asm_a.exists() and asm_b.exists():
        if a_calls_b:
            conns = find_register_connections(
                "A_calls_B", stem_a, stem_b, a_calls_b, asm_dir, blueprint_dir
            )
            result["connections"]["call_boundary_registers"].extend(conns)
        if b_calls_a:
            conns = find_register_connections(
                "B_calls_A", stem_b, stem_a, b_calls_a, asm_dir, blueprint_dir
            )
            result["connections"]["call_boundary_registers"].extend(conns)

    # 3. Shared DSECTs (works from raw ASM, no blueprint needed)
    if asm_a.exists() and asm_b.exists():
        result["connections"]["shared_dsects"] = find_shared_dsects(
            stem_a, stem_b, asm_a, asm_b
        )

    # 4. Shared memory fields (requires both blueprints)
    if bp_a.exists() and bp_b.exists():
        result["connections"]["shared_memory_fields"] = find_shared_memory_fields(
            stem_a, stem_b, bp_a, bp_b, asm_a, asm_b
        )
    else:
        if not bp_a.exists():
            warnings.append(
                f"Blueprint missing for '{stem_a}' — shared field analysis skipped"
            )
        if not bp_b.exists():
            warnings.append(
                f"Blueprint missing for '{stem_b}' — shared field analysis skipped"
            )

    # 5. Extract return connections into their own top-level list for convenience
    for conn in result["connections"]["call_boundary_registers"]:
        if conn.get("return_registers"):
            result["connections"]["return_registers"].append({
                "direction": conn["direction"],
                "caller": conn["caller"],
                "callee": conn["callee"],
                "call_site": conn["call_site"],
                "return_registers": conn["return_registers"],
            })

    return result


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Find all connected variables between two HLASM ASM files."
    )
    parser.add_argument("stem_a", help="First ASM file stem (e.g. da78)")
    parser.add_argument("stem_b", help="Second ASM file stem (e.g. xh80)")
    parser.add_argument("--asm-dir", type=Path, help="Directory containing .asm source files")
    parser.add_argument(
        "--blueprint-dir", type=Path, help="Directory containing .asm.json blueprint files"
    )
    parser.add_argument("--output", type=Path, help="Output JSON path")
    args = parser.parse_args()

    # Resolve directories
    blueprint_dir: Optional[Path] = args.blueprint_dir or _discover_blueprint_dir()
    if blueprint_dir is None:
        print("ERROR: Could not find blueprint directory. Use --blueprint-dir.", file=sys.stderr)
        sys.exit(1)

    asm_dir: Optional[Path] = args.asm_dir or _discover_asm_dir(blueprint_dir)
    if asm_dir is None:
        print("ERROR: Could not find ASM source directory. Use --asm-dir.", file=sys.stderr)
        sys.exit(1)

    output_path: Path = args.output or Path(f"{args.stem_a}_{args.stem_b}_connections.json")

    result = find_all_connections(args.stem_a, args.stem_b, blueprint_dir, asm_dir)

    output_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"Written: {output_path}")

    # Summary to stdout
    cs = result["call_summary"]
    cx = result["connections"]
    print(f"  calls {args.stem_a}→{args.stem_b}: {len(cs['a_calls_b'])}")
    print(f"  calls {args.stem_b}→{args.stem_a}: {len(cs['b_calls_a'])}")
    print(f"  call_boundary_registers: {len(cx['call_boundary_registers'])} call sites")
    print(f"  return_registers:        {len(cx['return_registers'])} call sites with returns")
    print(f"  shared_dsects:           {len(cx['shared_dsects'])}")
    print(f"  shared_memory_fields:    {len(cx['shared_memory_fields'])}")
    if result["warnings"]:
        for w in result["warnings"]:
            print(f"  WARNING: {w}")


if __name__ == "__main__":
    main()
