# Plan: Forward Lineage Tracing for HLASM Variables (Full Stages)

## Context

`trace_lineage.py` currently implements strong **backward** lineage.  
This plan adds **forward** lineage in a **new file** (`forward_trace_lineage.py`) with staged rollout, including cross-file continuation.

Forward lineage answers:
- after variable `X` is set, where is that value used?
- where is it tested in conditions?
- where does that value die (overwrite)?
- if control jumps to another file (`ENTRC`/`ENTNC`), how does trace continue there?

Requested public API:
`LineageTracer.trace_forward(target_variable, source_asm_file, blueprint_file) -> TraceResults`

---

## Key Design Decisions

| Decision | Choice | Reason |
|---|---|---|
| Overwrite behavior | Stop path + record `OVERWRITE` | Original value is dead after overwrite. |
| Overwrite payload | Record overwrite destination and `new_value_expr` | We should know what value replaced the traced one. |
| Usage scope | Reads in `TRIGGER_INST`, load/copy families, MVC `val`, operand reads | Covers practical patterns in `da76.asm` / `da78.asm`. |
| Traversal | Block graph traversal; setter block scans after setter line; successor blocks scan fully | Keeps logic simple and semantically correct. |
| Subroutines | Scan inside `BAS`/`BAL` ranges | Mirrors backward behavior and catches hidden usages. |
| Cross-file (outbound) | Stage 2: recurse into called files (parity with backward) | Needed for full lineage chains across modules. |
| Cross-file (inbound) | Stage 3: discover external callers into entry blocks and recurse | Matches backward “entry caller” coverage. |
| Output model | Reuse `TraceResults` with new forward roles and metadata | Avoids structural churn. |

---

## Forward Roles

| Role | Meaning |
|---|---|
| `SETTER` | Existing role: write to target variable. |
| `READER` | Target appears as source/read operand. |
| `CONDITION_TEST` | Target used in conditional test instruction. |
| `BRANCH_ON_CONDITION` | Immediate branch using a relevant condition test. |
| `OVERWRITE` | Target re-set; forward path terminates here. |
| `SUBROUTINE_USAGE` | Read/test/overwrite found inside scanned subroutine range. |
| `CROSS_FILE_CALL` | Existing role reused for `ENTRC`/`ENTNC`. |

`OVERWRITE` row should include:
- `detail`: human summary
- `overwrite_to`: normalized destination symbol
- `new_value_expr`: best-effort source expression (register/literal/symbol/operand text)

---

## File Strategy

Primary implementation file:
`/Users/prathamgupta/Desktop/asm-modernizer/forward_trace_lineage.py`

Reference file (read-only baseline logic to mirror):
`/Users/prathamgupta/Desktop/asm-modernizer/trace_lineage.py`

Compatibility approach:
- Keep backward tracer unchanged in `trace_lineage.py`.
- Build forward tracer classes/helpers in `forward_trace_lineage.py`.
- Optional later: add a thin CLI route in `trace_lineage.py` that dispatches to the new forward module.
- If we want strict isolation now, run forward tracing directly via `python forward_trace_lineage.py ...`.

Reuse existing utilities:
- instruction sets: `SETTER_INST`, `TRIGGER_INST`, `BRANCH_INST`, `SUBROUTINE_INST`, `CROSS_FILE_INST`
- helpers: `normalize_token()`, `extract_symbol_from_operand()`
- block helpers: `_block_start_line()`, `_block_end_line()`, `_line_in_block()`, `_next_sequential_block()`
- alias resolver: `_resolve_aliases()`
- output model: `TraceResults`
- post-process: `_post_process()`

---

## Implementation Stages

## Stage 1: Intra-file Forward Trace

### Step 1 — `_build_outgoing_map(blocks)`
Invert `incoming_branches` into successor adjacency:
`{source_block: [{"target": ..., "type": ...}, ...]}`.

### Step 2 — `_var_is_read_by(entry, match_names)`
Return true when target (or alias) is read as source:
- `entry["val"]` matches alias (MVC-like entries)
- args contain alias in read position
- include `TRIGGER_INST` reads

### Step 3 — `_var_is_overwritten_by(entry, match_names)` + `_extract_overwrite_value(entry)`
Detect writes to target:
- `entry["var"]` matches alias
- or destination operand index for arg-only instructions

Also extract replacement expression:
- `new_value_expr` from `val`, or source arg, or raw args join if ambiguous

### Step 4 — `_forward_trace(...)`
Parameters parallel `_backward_trace`, but with `start_line` and `outgoing_map`.

Flow:
1. cycle guard (`visited_blocks`)
2. scan block flow by line:
   - ignore lines `<= start_line`
   - `OVERWRITE` => record + return (kill this path)
   - read/test => record `READER` or `CONDITION_TEST`
   - immediate branch after relevant test => `BRANCH_ON_CONDITION`
   - subroutine call => invoke `_scan_subroutine_forward(...)`
   - cross-file call => record `CROSS_FILE_CALL` + append `dependent_files`
3. recurse successors from `outgoing_map[block_id]` with `start_line=0`

### Step 5 — `_scan_subroutine_forward(...)`
Mirror `_scan_subroutine()` scanning between `start_line` / `end_line`.
- record read/test as `SUBROUTINE_USAGE`
- record overwrite inside subroutine with `SUBROUTINE_USAGE` + overwrite note
- do not terminate main-block traversal because subroutine body is a nested scan

### Step 6 — `_trace_file_forward(...)` (intra-file shell)
Match `_trace_file()` orchestration style:
1. load blueprint + expanded asm lines + label map
2. resolve aliases
3. block maps + outgoing map
4. discover all setters in file
5. call `_forward_trace()` per setter

---

## Stage 2: Outbound Cross-file Forward Recursion

Goal: when forward traversal hits `ENTRC/ENTNC`, continue tracing in target file.

### Step 7 — Cross-file capture during forward traversal
On `inst in CROSS_FILE_INST`:
- append `results.dependent_files` row:
  - `file`, `called_from_block`, `line`, `type`, `calling_file`
- append `lineage_chain` row with role `CROSS_FILE_CALL`
- continue current block scan unless overwritten; do not hard-stop solely on call

### Step 8 — Recursive resolution in `_trace_file_forward(...)`
After intra-file tracing:
- iterate `results.dependent_files`
- resolve `<dep>.asm` and `<dep>.asm.json` in configured dirs
- recurse into `_trace_file_forward(...)` for existing pairs
- add unresolved entries otherwise
- use `self.visited_files` guard to avoid loops

Graph wiring parity with backward:
- pass `caller_chunk_id` into recursive calls
- stamp newly added nodes with `_cross_file_parent` so graph builder can connect subgraph roots to `CROSS_FILE_CALL`

---

## Cross-file Target Resolution Strategy (New)

Problem:
- `ENTRC/ENTNC` argument is not always a file stem.
- Example: `ENTNC DA7G` may target an entry label in another file, not `da7g.asm`.

Resolution order (deterministic):

1. **Direct file-stem match (fast path)**
   - Try `<target>.asm` + `<target>.asm.json` in configured dirs.
   - If present, use it.

2. **Entry-dispatch index match**
   - Build once per run:
     - iterate all blueprints in `blueprint_dir`
     - collect `_find_entry_dispatch_blocks(blueprint)` per file
     - create map `ENTRY_LABEL -> [candidate_files]`
   - If `target` matches an entry label, resolve to that file (or files).

3. **Subroutine-id index fallback**
   - Build `SUBROUTINE_ID -> [candidate_files]` from `blueprint["subroutines"]`.
   - Useful when call target is a routine label rather than file stem.

4. **Call-graph hint fallback (optional)**
   - Use `blueprint["call_graph"]` node/edge names as hints for probable target files.
   - Apply only when 1–3 fail or produce ambiguity.

5. **Unresolved with reason**
   - If no confident mapping, push to `unresolved_files` with explicit status:
     - `Target label not mapped to any file`
     - `Ambiguous target label across files`

Tie-break rules:
- If exactly one candidate file has both ASM and blueprint, choose it.
- If multiple valid candidates remain, prefer:
  1) file containing entry-dispatch match
  2) file containing subroutine-id match
  3) lexical file-stem proximity as last resort
- Still record ambiguity warning in `data_quality_warnings`.

Implementation notes:
- Add helper methods in `forward_trace_lineage.py`:
  - `_build_cross_file_indices()`
  - `_resolve_cross_file_target(target_label) -> ResolutionResult`
- Cache indices on tracer instance to avoid rescanning directories per call.
- Keep existing `visited_files` guard; resolution strategy only chooses target file(s).

Verification additions:
- Add a test where call target is an entry label (e.g., `DA7G`) and ensure it resolves to owning file (e.g., `da76.asm`) rather than unresolved.
- Add ambiguity test (same label in multiple files) to confirm deterministic handling + warning.

---

## Stage 3: Inbound Entry Cross-file Stage

Goal: also capture files that call **into** the current file’s entry-dispatch blocks.

### Step 9 — Inbound caller discovery
For primary forward trace file:
- compute entry-dispatch blocks (`_find_entry_dispatch_blocks(...)`, same helper as backward)
- intersect with blocks touched in this forward trace window
- scan asm files for `ENTRC/ENTNC <entry_block>`
- queue as `dependent_files` with `type: INBOUND_ENTRY`

### Step 10 — Inbound recursion mode
During dependent resolution:
- if `type == INBOUND_ENTRY`, recurse with `inbound_target=<entry_block>`
- create `CROSS_FILE_CALL` node in inbound caller file for that target
- keep `caller_chunk_id=None` for inbound mode (same rationale as backward wiring)

This stage gives backward/forward symmetry for external entry callers.

---

## Stage 4: API + CLI + Output Integration

### Step 11 — Public API
Add:
```python
def trace_forward(self, target_variable, source_asm_file, blueprint_file) -> TraceResults:
    results = TraceResults()
    self._trace_file_forward(target_variable, Path(source_asm_file), Path(blueprint_file), results)
    self._post_process(results)
    return results
```

### Step 12 — CLI switch
Add:
`--direction {backward,forward}` (default `backward`) in one of two ways:

- preferred now: define this in `forward_trace_lineage.py` CLI and run forward traces there
- optional compatibility mode: add a thin dispatcher in `trace_lineage.py` that imports and calls forward module

Dispatch model (when shared CLI is used):
- backward -> existing `trace_lineage.py` flow
- forward -> `forward_trace_lineage.py` flow

### Step 13 — Post-process priorities
Update `_post_process()` role priority to include forward roles so dedupe keeps semantically strongest row at same `(file,line,block)`.

Suggested priority order:
`SETTER` > `OVERWRITE` > `CONDITION_TEST` > `BRANCH_ON_CONDITION` > `READER` > `SUBROUTINE_USAGE` > `CROSS_FILE_CALL`

---

## Still Out of Scope

- Register dataflow propagation across register moves (`L R5,VAR` then later use `R5`)
- Full expression evaluation for computed addresses (best-effort string capture only)
- Forward-specific dependent-variable formatter UI polish

---

## Verification Plan

1. **Basic intra-file (`da76`)**
   - `python forward_trace_lineage.py --variable WK_RRC --asm temp/asm/da76.asm --blueprint temp/parser_run/da76.asm.json`
   - Expect `SETTER`, downstream `READER`/`CONDITION_TEST`, and `OVERWRITE` rows.

2. **Overwrite payload check**
   - On each `OVERWRITE`, confirm `new_value_expr` is populated (or explicit fallback string when ambiguous).

3. **Cross-file outbound recursion**
   - Run variable(s) in `da76` that encounter `ENTRC`/`ENTNC` call sites.
   - Expect `CROSS_FILE_CALL` in `da76` and lineage continuation from traced dependent files when blueprint+asm exist.

4. **Inbound entry recursion**
   - For entry-dispatch blocks in lineage, verify external files calling those entries are discovered and traced.

5. **Cycle safety**
   - Loops in block graph and file graph must terminate via visited guards.

6. **Backward/forward complement check**
   - Same variable run in both directions should provide complementary views:
     backward => “why set”; forward => “where used / where value dies”.

7. **Module separation check**
   - Forward runs should succeed with only `forward_trace_lineage.py` entrypoint.
   - Backward behavior in `trace_lineage.py` should remain unchanged.
