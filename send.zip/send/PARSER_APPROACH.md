# ASM-Modernizer Parser Approach

## Overview

ASM-Modernizer is a multi-language static analysis tool designed to parse and analyze z/TPF (Transaction Processing Facility) assembly code along with C/C++ sources. It extracts comprehensive metadata about code structure, data flow, call graphs, database operations, and variable lineage to support legacy system modernization efforts.

**Primary Goal:** Analyze legacy z/TPF mainframe assembly code to understand its architecture, dependencies, and data flows for migration to modern platforms.

---

## What We're Doing

The parser performs **multi-pass static analysis** on assembly and C/C++ files to extract:

1. **Symbol Tables** - All symbols (ENTRY, EXTRN, CSECT, DSECT, etc.) with cross-file resolution
2. **Call Graphs** - Control flow between routines and files, including indirect calls
3. **Variable Lineage** - How data flows through the code (definitions → assignments → uses)
4. **Database Operations** - z/TPFDF macro invocations for database access
5. **Macro Expansions** - Full macro expansion with parameter substitution
6. **File Dependencies** - COPY directives and external dependencies
7. **Mixed Language Analysis** - ASM ↔ C/C++ cross-linking
8. **Line Metadata** - Per-line scope, conditional context, and call information

---

## Parsing Approach

### Strategy: Hybrid Multi-Pass Static Analysis

1. **Token-Based Parsing for Assembly**
   - Custom tokenizer for fixed-form assembly layout
   - Pattern-based recognition (no formal grammar)
   - Handles assembly's flexible syntax

2. **Tree-Sitter for C/C++**
   - Proper AST parsing using tree-sitter library
   - Graceful degradation if unavailable

3. **Multi-Pass Architecture**
   - Each pass enriches the shared analysis context
   - Passes can feed back (e.g., data flow refines call graph)
   - Best-effort analysis with flagged uncertainties

4. **Provenance Tracking**
   - Every statement tagged with origin (file, line, expansion source)
   - Full traceability through COPY and macro expansions

---

## Processing Pipeline

```
┌─────────────────────────────────────────────────────────┐
│ PHASE 0: Variable Universe Building (Optional)         │
│   - First pass: discover all permanent variables       │
│   - Output: asm_variable_names.json, cpp_variable_*.json
└─────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────┐
│ PHASE 1: File Discovery & Preprocessing                │
│   1. File discovery (glob patterns)                    │
│   2. Tokenization (assembly lines → structured tokens) │
│   3. COPY directive expansion (recursive includes)     │
│   4. Conditional assembly preprocessing (AIF/AGO/SETA) │
└─────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────┐
│ PHASE 2: Per-File Analysis (6 passes)                  │
│   Pass 1: Symbol Resolution                            │
│   Pass 2: Call Graph Building                          │
│   Pass 3: Data Flow Tracking                           │
│   Pass 4: DB Operation Extraction                      │
│   Pass 5: Variable Lineage Building                    │
│   Pass 6: Line Metadata Collection                     │
└─────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────┐
│ PHASE 3: Cross-File Resolution                         │
│   - Global symbol registry                             │
│   - EXTRN → ENTRY linkages                            │
│   - Cross-file call graph linking                      │
└─────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────┐
│ PHASE 4: Macro Processing                              │
│   - Macro definition collection                        │
│   - Macro expansion with parameter substitution        │
│   - Rebuild call graphs for expanded code              │
└─────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────┐
│ PHASE 5: C/C++ Analysis (Mixed Mode)                   │
│   - Parse C/C++ via tree-sitter                        │
│   - Build C++ call graph and lineage                   │
│   - Link ASM ↔ C++ via extern "C"                     │
└─────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────┐
│ PHASE 6: Universe-Aware Enrichment (Optional)          │
│   - Validate variables against universe                │
│   - Classify operations (move, load, store, etc.)     │
│   - Track conditional contexts                         │
└─────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────┐
│ PHASE 7: JSON Output Generation                        │
│   - Serialize all analysis results                     │
│   - Per-file JSON outputs                              │
│   - Optional lineage exports (JSON/DOT)                │
└─────────────────────────────────────────────────────────┘
```

---

## Where Things Are Located

### Project Structure

```
asm-modernizer/
├── main.py                         # CLI entry point & orchestration
├── universe_builder.py             # Variable universe builder (Pass 1)
│
├── Core Parsing Layer
│   ├── tokenizer.py                # Assembly lexer (lines → tokens)
│   ├── file_reader.py              # COPY expansion & conditional assembly
│   ├── line_continuation.py        # Multi-line statement handling
│   ├── conditional_parser.py       # Conditional directive parsing
│   ├── conditional_evaluator.py    # Conditional expression evaluation
│   ├── symbol_parser.py            # Symbol identification
│   ├── literal_resolver.py         # Literal value resolution
│   └── statement_id_generator.py   # Unique statement IDs
│
├── Macro System
│   ├── macro_classifier.py         # Macro type classification
│   ├── macro_definition_parser.py  # MACRO...MEND parsing
│   ├── macro_library.py            # Macro definition storage
│   └── macro_expander.py           # Macro invocation expansion
│
├── models/                         # Data structures (18 files)
│   ├── analysis_context.py         # Central analysis context
│   ├── symbol.py                   # Symbol & SymbolTable
│   ├── call_graph.py               # Call graph (nodes + edges)
│   ├── variable_lineage.py         # Variable lineage graph
│   ├── variable_universe.py        # Variable universe model
│   ├── db_operation.py             # Database operation catalog
│   ├── file_dependency.py          # File dependency graph
│   ├── macro_definition.py         # Macro definitions
│   ├── macro_expansion.py          # Macro expansion metadata
│   ├── conditional_assembly.py     # Conditional assembly state
│   ├── provenance.py               # Statement provenance
│   ├── c_family.py                 # C/C++ models
│   └── line_metadata.py            # Per-line metadata
│
├── passes/                         # Analysis passes (13 files)
│   ├── symbol_resolver.py          # Pass 1: Symbol table building
│   ├── call_graph_builder.py       # Pass 2: Call graph construction
│   ├── data_flow_tracker.py        # Pass 3: Data flow analysis
│   ├── db_operation_extractor.py   # Pass 4: DB operation extraction
│   ├── variable_lineage_builder.py # Pass 5: Variable lineage
│   ├── file_dependency_builder.py  # File dependency analysis
│   ├── macro_collector.py          # Macro collection
│   ├── macro_expansion_pass.py     # Macro expansion orchestration
│   ├── c_family_parser.py          # C/C++ tree-sitter parsing
│   ├── makefile_parser.py          # Makefile parsing
│   ├── global_lineage_stitcher.py  # Cross-file lineage merging
│   ├── asm_line_metadata_collector.py  # Line metadata collection
│   └── line_metadata_enricher.py   # Line metadata enrichment
│
├── multi_file/                     # Multi-file orchestration
│   ├── orchestrator.py             # ASM-only multi-file analysis
│   ├── mixed_orchestrator.py       # Mixed ASM + C/C++ analysis
│   ├── single_file_analyzer.py     # Single file analysis
│   ├── c_family_analyzer.py        # C/C++ file analysis
│   ├── makefile_analyzer.py        # Makefile analysis
│   └── symbol_registry.py          # Global symbol registry
│
├── Utilities
│   ├── operation_classifier.py     # ASM/C++ operation classification
│   ├── instruction_classifier.py   # Instruction type classification
│   ├── external_call_identifier.py # External call identification
│   ├── json_emitter.py             # JSON output generation
│   ├── lineage_levels.py           # Lineage utilities
│   ├── section_tracker.py          # CSECT/DSECT tracking
│   └── cache/file_cache.py         # File-level caching
│
├── tests/                          # Test suite
│   ├── unit/                       # Unit tests (40+ files)
│   └── integration/                # Integration tests (12+ files)
│
├── test_data/                      # Test fixtures
│   ├── asm/                        # Assembly test files
│   ├── cpp/                        # C++ test files
│   └── macros/                     # Macro test files
│
├── docs/                           # Documentation
│   ├── implementation-summary.md   # Variable universe implementation
│   ├── variable-universe.md        # Variable universe guide
│   ├── mixed-language.md           # Mixed language support
│   ├── line-metadata.md            # Line metadata tracking
│   └── plans/                      # Design documents (20+ files)
│
└── output/                         # JSON output directory
```

---

## Key Components Explained

### Entry Point: `main.py`

**Responsibilities:**
- Parse command-line arguments
- Discover files via glob patterns
- Load variable universes (optional)
- Dispatch to appropriate orchestrator (ASM-only or mixed)
- Generate JSON output files

**Key Functions:**
- `main()` - CLI entry point
- `discover_files()` - File discovery
- `load_universes()` - Load variable universe files

---

### Tokenizer: `tokenizer.py`

**What it does:**
- Breaks assembly lines into structured tokens
- Parses fixed-form layout: `label | opcode | operands | comment`
- Handles parenthesized addressing modes
- Splits operands on top-level commas only

**Input:** Raw assembly line
```assembly
LOOP     LA    R1,BUFFER(R2)    Load buffer address
```

**Output:** ParsedLine object
```python
ParsedLine(
    label="LOOP",
    opcode="LA",
    operands=["R1", "BUFFER(R2)"],
    comment="Load buffer address"
)
```

---

### File Reader: `file_reader.py`

**What it does:**
- Reads assembly files with COPY directive expansion
- Recursively expands includes (like C's #include)
- Processes conditional assembly (AIF, AGO, ANOP, SETA/SETB/SETC)
- Detects circular includes
- Maintains provenance through all expansions

**Example:**
```assembly
         COPY  MACROS          ← Expands recursively
```

---

### Analysis Context: `models/analysis_context.py`

**What it is:**
- Central hub for all analysis results
- Shared across all passes
- Stores: symbol table, metadata, statements, variable universe

**Key Fields:**
- `symbol_table` - SymbolTable instance
- `metadata` - Extensible metadata dictionary
- `statements` - List of parsed statements
- `variable_universe_names` - Set of known variable names

---

### Analysis Passes: `passes/`

Each pass enriches the analysis context:

1. **symbol_resolver.py** - Build symbol tables (ENTRY, EXTRN, CSECT, etc.)
2. **call_graph_builder.py** - Extract subroutine calls (BAL, BALR, BAS, etc.)
3. **data_flow_tracker.py** - Track register/memory data movement
4. **db_operation_extractor.py** - Extract z/TPFDF database macros
5. **variable_lineage_builder.py** - Track variable definitions → uses
6. **file_dependency_builder.py** - Build file dependency graph
7. **macro_collector.py** - Collect macro definitions
8. **macro_expansion_pass.py** - Expand macro invocations
9. **c_family_parser.py** - Parse C/C++ via tree-sitter

---

### Orchestrators: `multi_file/`

**orchestrator.py** - ASM-only analysis
- Analyzes multiple assembly files
- Resolves cross-file symbols (EXTRN → ENTRY)
- Builds global call graph

**mixed_orchestrator.py** - Mixed language analysis
- Analyzes ASM + C/C++ together
- Links ASM and C++ symbols (extern "C" ↔ EXTRN)
- Builds unified call graph

---

### Variable Universe System

**Two-Pass System:**

**Pass 1: Universe Building** (`universe_builder.py`)
- Scans all source files
- Extracts variable declarations (DS, DC, EQU, EXTRN for ASM)
- Extracts C/C++ variables via tree-sitter
- Outputs: `asm_variable_names.json`, `cpp_variable_names.json`

**Pass 2: Analysis with Universe** (`main.py --load-universe`)
- Validates variables against universe
- Classifies operations (move, load, store, arithmetic, etc.)
- Tracks conditional contexts
- Enriches lineage edges with metadata

---

## Data Structures

### Core Models

**Symbol & SymbolTable** (`models/symbol.py`)
- Multi-level scoping (global + section-scoped)
- Types: ENTRY, EXTRN, WXTRN, CSECT, DSECT, RSECT, EQU, LABEL

**CallGraph** (`models/call_graph.py`)
- Nodes: routine name, section, file, is_external, kind
- Edges: source, target, call_type, instruction, line, is_indirect

**VariableLineageGraph** (`models/variable_lineage.py`)
- Nodes: variable/register/memory/literal
- Edges: define/assign/use relationships
- Enriched: operation_type, conditional_context, transformation

---

## Output Format

### Per-File JSON Structure

```json
{
  "metadata": { ... },
  "symbols": {
    "global_symbols": { ... },
    "sections": { ... }
  },
  "call_graph": {
    "nodes": { ... },
    "edges": [ ... ]
  },
  "db_operations": { ... },
  "file_dependencies": { ... },
  "macro_expansions": [ ... ],
  "variable_lineage": {
    "nodes": [ ... ],
    "edges": [ ... ]
  },
  "line_metadata": { ... }
}
```

### Output Files

- **Per-file JSON:** `output/path/to/file.asm.json`
- **Universe files:**
  - `asm_variable_universe.json`
  - `asm_variable_names.json`
  - `cpp_variable_universe.json`
  - `cpp_variable_names.json`
- **Lineage exports:**
  - `.lineage.json`
  - `.lineage.dot` (GraphViz format)

---

## Key Features

1. **Variable Universe System**
   - Two-pass analysis for strict validation
   - Operation classification
   - Conditional context tracking

2. **Mixed Language Support**
   - Seamless ASM + C/C++ analysis
   - Cross-language call graph linking
   - Symbol aliasing (extern "C" ↔ EXTRN)

3. **Macro Expansion**
   - Full MACRO...MEND parsing
   - Parameter substitution
   - Conditional macro expansion

4. **Provenance Tracking**
   - Every statement tagged with origin
   - Full COPY and macro expansion traceability

5. **Caching**
   - File-level caching by content hash
   - Speeds up re-analysis

---

## Usage Examples

### Basic Analysis
```bash
# Single file
python main.py program.asm

# Directory (auto-discovers dependencies)
python main.py src/

# With COPY search paths
python main.py -s ./copybooks -s ./macros program.asm
```

### With Variable Universe
```bash
# Step 1: Build universe
python universe_builder.py src/ --output output/

# Step 2: Analyze with universe
python main.py src/*.asm --load-universe --output-dir output/
```

### Variable Lineage Tracing
```bash
python main.py program.asm \
  --lineage-name BUFFER \
  --lineage-kind memory \
  --lineage-direction forward \
  --lineage-depth 5 \
  --lineage-export output/lineage.json
```

### Mixed Language
```bash
python main.py src/*.asm src/*.cpp --output-dir output/
```

---

## Technical Highlights

### Design Patterns
- **Multi-Pass Pipeline:** Separation of concerns
- **Provenance Pattern:** Full traceability
- **Registry Pattern:** Global symbol registry
- **Metadata Pattern:** Extensible metadata dictionary
- **Builder Pattern:** Graph builders

### Key Algorithms
- **Symbol Resolution:** Multi-level scoping
- **Call Graph Construction:** Pattern matching on call instructions
- **Data Flow Propagation:** Register state tracking
- **Macro Expansion:** Parameter binding + text substitution

---

## Summary

ASM-Modernizer is a **production-grade static analysis framework** for z/TPF assembly code modernization. It combines traditional compiler techniques (multi-pass analysis, symbol resolution, data flow) with modern tools (tree-sitter, JSON output) to provide comprehensive understanding of legacy codebases.

**Key Strengths:**
- Comprehensive multi-language analysis (ASM + C/C++)
- Extensible pass-based architecture
- Rich metadata extraction
- Production-ready with extensive testing
- Handles real-world complexity (macros, conditionals, indirect calls)
