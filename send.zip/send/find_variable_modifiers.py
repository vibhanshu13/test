#!/usr/bin/env python3
"""
find_variable_modifiers.py

Scans all blueprint (.asm.json and .mac.json) files to find every file where a given
variable is modified by a SETTER instruction. For each modifying file,
retrieves all call chains that include that file at any position in the
file-level call graph.

Output is always written as a JSON file.

Usage:
  python find_variable_modifiers.py <variable_name> [options]

Options:
  --blueprint-dir DIR   Directory containing .asm.json files
                        (auto-detected from graph metadata if omitted)
  --graph FILE          Path to file_call_graph.json
                        (auto-discovered near blueprint-dir if omitted)
  --output FILE         Output JSON path (default: <variable>_modifiers.json)
  --max-depth N         Maximum chain length in hops (default: unlimited)
  --no-chains           Skip call chain lookup; write setter locations only
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import deque
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from blueprint_io import iter_flow, load_blueprint
from trace_lineage import (
    BRANCH_INST, SETTER_INST, TRIGGER_INST,
    DEST_ARG_INDEX_BY_INST, normalize_token, is_real_setter_site,
)


# ---------------------------------------------------------------------------
# Variable matching  (mirrors LineageTracer private methods exactly)
# ---------------------------------------------------------------------------

def _resolve_aliases(target_variable: str, aliases: List[Dict[str, Any]]) -> Set[str]:
    target = target_variable.upper()
    out: Set[str] = set()
    for alias in aliases:
        name = str(alias.get("name", "")).upper()
        mapped = str(alias.get("target", "")).upper()
        if not name and not mapped:
            continue
        if name == target:
            out.add(mapped)
        if mapped == target:
            out.add(name)
    return {v for v in out if v}


def _operand_matches(operand: str, match_names: Set[str]) -> bool:
    up = str(operand).strip().upper()
    if not up:
        return False
    if normalize_token(up) in match_names:
        return True
    for m in match_names:
        if up == m or up.startswith(m + "+") or up.startswith(m + "("):
            return True
    return False


def _entry_touches_match(entry: Dict[str, Any], match_names: Set[str]) -> bool:
    """Return True if this flow entry writes to a variable in match_names."""
    if "var" in entry:
        return _operand_matches(str(entry.get("var", "")), match_names)
    inst = str(entry.get("inst", "")).upper()
    args = entry.get("args", []) or []
    if isinstance(args, str):
        args = [args]
    if not args:
        return False
    dest_idx = DEST_ARG_INDEX_BY_INST.get(inst, 0)
    if dest_idx >= len(args):
        return False
    return _operand_matches(str(args[dest_idx]), match_names)


def _entry_reads_match(entry: Dict[str, Any], match_names: Set[str]) -> bool:
    """Return True if this flow entry reads from a variable in match_names (source operand)."""
    inst = str(entry.get("inst", "")).upper()
    args = entry.get("args", []) or []
    if isinstance(args, str):
        args = [args]

    # val field = source of an MVC/structured entry (dest is in "var")
    if "val" in entry:
        return _operand_matches(str(entry.get("val", "")), match_names)

    if not args:
        return False

    if inst in SETTER_INST:
        # For setter instructions check non-destination (source) operands only
        dest_idx = DEST_ARG_INDEX_BY_INST.get(inst, 0)
        source_args = [a for i, a in enumerate(args) if i != dest_idx]
        return any(_operand_matches(str(a), match_names) for a in source_args)

    # All other instructions (comparisons, branches, triggers, etc.): check every operand
    return any(_operand_matches(str(a), match_names) for a in args)


def _entry_detail(entry: Dict[str, Any]) -> str:
    if "var" in entry and "val" in entry:
        return f"{entry['var']} = {entry['val']}"
    args = entry.get("args", [])
    return ", ".join(args) if isinstance(args, list) else str(args)


# ---------------------------------------------------------------------------
# Blueprint scanning
# ---------------------------------------------------------------------------

def _stem_from_path(path: Path) -> str:
    name = path.name
    for suffix in (".asm.json", ".mac.json", ".cpp.json", ".json"):
        if name.endswith(suffix):
            name = name[: -len(suffix)]
            break
    return name.lower()


def _extract_gvl_terminal_name(text: str) -> str:
    """Extract the terminal field name from a GVL node ID or name path.

    Handles the actual separators seen in production blueprints:
        "struct_field:fn::}path.to.softCardValue"          -> "softCardValue"
        "processACreditTransaction::}path.to.softCardValue"-> "softCardValue"
        "struct_field:fn::ptr->transactionInds->fieldName" -> "fieldName"
        "literal:SoftCardValueDetail::ExpressPayTransaction"-> "ExpressPayTransaction"

    Priority: "." first (most common dotted path), then "->", then "::".
    Falls back to the last colon-delimited segment for bare kind:name IDs.
    """
    for sep in (".", "->", "::"):
        if sep in text:
            return text.rsplit(sep, 1)[-1].strip()
    return text.split(":")[-1].strip()


def scan_cpp_blueprint_for_setters(
    path: Path,
    variable: str,
) -> Tuple[List[Dict[str, Any]], Optional[str]]:
    """Scan one .cpp.json blueprint for GVL assign/define edges targeting *variable*.

    C++ assignments are not emitted as block-level flow instructions — they live in
    global_variable_lineage.edges as edges with relation="assign" or "define" where
    the *target* node is the variable being written.

    The GVL embedded in a blueprint may cover all C++ files (universe blueprints) or
    be null (per-file blueprints sharing an external GVL).  In both cases edges are
    filtered by the source ``file`` field so only setter sites that belong to *this*
    file are returned.

    Returns (hits, error_message) in the same shape as scan_blueprint_for_setters.
    """
    import os as _os

    try:
        blueprint = load_blueprint(path, keys={"global_variable_lineage", "variable_lineage"})
    except Exception as exc:
        return [], f"Could not read {path.name}: {exc}"

    # Per-file blueprints store local edges under "variable_lineage"; universe blueprints
    # embed the full shared graph under "global_variable_lineage".  Try both.
    gvl = blueprint.get("global_variable_lineage") or {}
    if not gvl:
        gvl = blueprint.get("variable_lineage") or {}
    if not gvl:
        return [], None

    var_upper = variable.upper()
    stem = _stem_from_path(path)

    node_lookup: Dict[str, Dict[str, Any]] = {
        str(n.get("id") or ""): n
        for n in (gvl.get("nodes") or [])
        if n.get("id")
    }

    hits: List[Dict[str, Any]] = []
    for edge in (gvl.get("edges") or []):
        if edge.get("relation") not in ("assign", "define"):
            continue

        # Filter to edges that originate from this file only.
        # Each edge carries a "file" field with the absolute source path.
        # Without this check, universe blueprints (which embed the full shared GVL
        # for all C++ files) would report setter sites from every file in the
        # codebase as belonging to this single blueprint.
        edge_file = str(edge.get("file") or "")
        if edge_file:
            edge_stem = _os.path.splitext(_os.path.basename(edge_file))[0].lower()
            if edge_stem != stem:
                continue

        target_id = str(edge.get("target") or "")
        if not target_id:
            continue

        target_node = node_lookup.get(target_id)
        if target_node:
            target_name = _extract_gvl_terminal_name(str(target_node.get("name") or target_id)).upper()
        else:
            target_name = _extract_gvl_terminal_name(target_id).upper()

        if target_name != var_upper:
            continue

        source_id = str(edge.get("source") or "")
        source_node = node_lookup.get(source_id)
        source_name = _extract_gvl_terminal_name(
            str(source_node.get("name") or source_id) if source_node else source_id
        )

        meta = edge.get("metadata") or {}
        enclosing_fn = str(
            meta.get("enclosing_function") or edge.get("enclosing_function")
            or edge.get("scope") or ""
        )

        hits.append({
            "file_stem": stem,
            "block": enclosing_fn or "unknown",
            "line": edge.get("line"),
            "inst": "=",
            "detail": f"{variable} = {source_name}",
        })

    return hits, None


def _build_block_parent_map(
    blocks: List[Dict[str, Any]],
) -> Dict[str, Tuple[str, Optional[int]]]:
    """Return {child_block_upper → (parent_block_id, call_line)} for BAS and FALLTHROUGH.

    Two relationships are captured:

    * **BAS**: a block containing ``BAS Rn,LABEL`` is the parent of LABEL;
      ``call_line`` is the BAS instruction's line number.
    * **FALLTHROUGH**: when block B immediately follows block A in source order
      and A does not end with an unconditional transfer (B, BR, BCR, ENTNC …),
      B is a FALLTHROUGH child of A; ``call_line`` is ``None``.

    TMSMA return blocks (e.g. ``FIN_03_TMSEND``) fall into the FALLTHROUGH
    category because TMSMA args in the blueprint omit the return label.
    """
    # Sort blocks by first flow-entry line to establish source order.
    block_order: List[Tuple[int, str]] = []
    for block in blocks:
        blk_id = str(block.get("id") or "")
        first_line = 0
        for fl in iter_flow(block):
            ln = int(fl.get("line") or 0)
            if ln > 0:
                first_line = ln
                break
        if blk_id:
            block_order.append((first_line, blk_id))
    block_order.sort()

    parent_map: Dict[str, Tuple[str, Optional[int]]] = {}

    # 1. Explicit BAS calls.
    for block in blocks:
        blk_id = str(block.get("id") or "")
        for fl in iter_flow(block):
            if str(fl.get("inst") or "").upper() == "BAS":
                args = [str(a) for a in (fl.get("args") or [])]
                if len(args) >= 2:
                    target_upper = args[1].strip().upper()
                    call_ln: Optional[int] = int(fl.get("line") or 0) or None
                    if target_upper not in parent_map:
                        parent_map[target_upper] = (blk_id, call_ln)

    # 2. FALLTHROUGH: preceding block ends without an unconditional transfer.
    _UNCONDITIONAL: Set[str] = {"B", "BR", "BCR", "BC", "ENTNC", "RETURN", "BALR"}
    block_last_inst: Dict[str, str] = {}
    for block in blocks:
        blk_id = str(block.get("id") or "")
        last_inst = ""
        for fl in iter_flow(block):
            inst = str(fl.get("inst") or "").upper()
            if inst:
                last_inst = inst
        if blk_id:
            block_last_inst[blk_id] = last_inst

    for i in range(1, len(block_order)):
        _, curr_id = block_order[i]
        _, prev_id = block_order[i - 1]
        curr_upper = curr_id.upper()
        if curr_upper in parent_map:
            continue  # already has an explicit BAS parent
        if block_last_inst.get(prev_id, "").upper() not in _UNCONDITIONAL:
            parent_map[curr_upper] = (prev_id, None)

    return parent_map


def _collect_site_guards(
    blocks: List[Dict[str, Any]],
    block_id: str,
    setter_line: int,
) -> List[str]:
    """Return TRIGGER+BRANCH guard strings in block_id before setter_line.

    Also inherits guards from the immediate parent block (via BAS or FALLTHROUGH)
    so conditions established before entering the sub-block are included.
    Example: the basic-card check in FIN_03GLOS is inherited by the TMSMA
    return block FIN_03_TMSEND that falls through from it.

    Returns plain ``"TRIGGER / BRANCH"`` strings in execution order (parent
    guards first, then local guards).
    """
    def _scan(target_id: str, limit: int) -> List[str]:
        result: List[str] = []
        pending: Optional[str] = None
        for block in blocks:
            if str(block.get("id") or "") != target_id:
                continue
            for flow in iter_flow(block):
                ln = int(flow.get("line") or 0)
                if limit and ln and ln >= limit:
                    break
                inst = str(flow.get("inst") or "").upper()
                fa = [str(a) for a in (flow.get("args") or [])]
                if inst in TRIGGER_INST:
                    pending = (f"{inst} {', '.join(fa)}" if fa else inst).strip()
                elif inst in BRANCH_INST and pending:
                    branch_str = (f"{inst} {', '.join(fa)}" if fa else inst).strip()
                    result.append(f"{pending} / {branch_str}")
                    pending = None
            break
        return result

    guards = _scan(block_id, setter_line)

    # One level of parent inheritance (BAS caller or FALLTHROUGH predecessor).
    parent_map = _build_block_parent_map(blocks)
    parent_entry = parent_map.get(block_id.upper())
    if parent_entry:
        parent_id, call_line = parent_entry
        # call_line = BAS line → collect parent guards before that line.
        # call_line = None (FALLTHROUGH) → collect all parent guards (limit=0).
        inherited = _scan(parent_id, call_line or 0)
        guards = inherited + guards

    return guards


def _find_bas_target_blocks(blocks: List[Dict[str, Any]]) -> Set[str]:
    """Return the set of block IDs (uppercased) that are BAS call targets.

    Scans all blocks for ``BAS Rn,<LABEL>`` instructions and collects the
    target label (args[1]).  These blocks represent internal subroutines entered
    via branch-and-save rather than as standalone routines.
    """
    targets: Set[str] = set()
    for block in blocks:
        for flow in iter_flow(block):
            if str(flow.get("inst") or "").upper() == "BAS":
                args = [str(a) for a in (flow.get("args") or [])]
                if len(args) >= 2:
                    targets.add(args[1].strip().upper())
    return targets


def _setter_action_and_bit(
    inst: str, args: List[str]
) -> Tuple[str, Optional[str]]:
    """Classify a setter instruction as set/clear/move/write and extract the named bitmask.

    Returns ``(action, bit)`` where:
    - ``action``:  ``"set"`` (OI/OIY), ``"clear"`` (NI/NIY), ``"move"`` (MVI/MVC family),
                   or ``"write"`` for all other SETTER_INST.
    - ``bit``:     for OI/OIY: ``args[1]`` directly (e.g. ``"WB#03GLOS"``).
                   for NI/NIY: the **named bit** extracted from the complement mask
                   ``X'FF'-BIT_SYMBOL`` → ``BIT_SYMBOL``; falls back to full mask
                   if no symbol is found.  ``None`` for all other setters.
    """
    if inst in {"OI", "OIY"}:
        return "set", (args[1].strip() if len(args) > 1 else None)
    if inst in {"NI", "NIY"}:
        raw = args[1].strip() if len(args) > 1 else None
        if raw:
            # Unwrap complement mask: X'FF'-WB#03GLOS → WB#03GLOS
            import re as _re
            m = _re.search(r"-\s*([A-Za-z#$@_][A-Za-z0-9#$@_]*)\s*$", raw)
            bit: Optional[str] = m.group(1) if m else raw
        else:
            bit = None
        return "clear", bit
    if inst in {"MVI", "MVIY", "MVC", "MVCIN", "MVHI", "MVHHI", "MVGHI"}:
        return "move", None
    return "write", None


def scan_blueprint_for_setters(
    path: Path,
    variable: str,
) -> Tuple[List[Dict[str, Any]], Optional[str]]:
    """Scan one .asm.json blueprint for SETTER instructions targeting *variable*.

    Returns (hits, error_message). hits is an empty list (not None) on parse failure.
    """
    try:
        # skip_global_lineage=True: this function only reads meta+blocks; loading
        # global_variable_lineage.json (up to 8 GB on large codebases) is wasteful.
        blueprint = load_blueprint(path, skip_global_lineage=True, keys={"meta", "blocks"})
    except Exception as exc:
        return [], f"Could not read {path.name}: {exc}"

    aliases = _resolve_aliases(variable, blueprint.get("meta", {}).get("aliases", []))
    match_names = {variable.upper()} | aliases

    stem = _stem_from_path(path)
    blocks: List[Dict[str, Any]] = blueprint.get("blocks", [])

    # Pre-build BAS target set so each setter site can be tagged entered_via_bas.
    bas_targets = _find_bas_target_blocks(blocks)

    hits: List[Dict[str, Any]] = []
    for block in blocks:
        block_id = block.get("id", "UNKNOWN")
        for entry in iter_flow(block):
            inst = str(entry.get("inst", "")).upper()
            if inst not in SETTER_INST:
                continue
            if not _entry_touches_match(entry, match_names):
                continue
            # Audit §3a/§3b/§3c/§3d: skip value-preserving / spec-exception /
            # zero-mask / nonzero-displacement writes that are not real modifiers.
            _args = entry.get("args", []) or []
            if isinstance(_args, str):
                _args = [_args]
            if _args and not is_real_setter_site(inst, _args):
                continue
            setter_line = entry.get("line")
            action, bit = _setter_action_and_bit(inst, _args)
            guards = _collect_site_guards(blocks, block_id, int(setter_line or 0))
            hits.append({
                "file_stem": stem,
                "block": block_id,
                "line": setter_line,
                "inst": inst,
                "detail": _entry_detail(entry),
                "action": action,
                "bit": bit,
                "guards": guards,
                "entered_via_bas": block_id.upper() in bas_targets,
            })

    return hits, None


def scan_blueprint_for_usages(
    path: Path,
    variable: str,
) -> Tuple[List[Dict[str, Any]], Optional[str]]:
    """Scan one blueprint for entries where *variable* is READ (source operand).

    Returns (hits, error_message). hits is an empty list on parse failure.
    Unlike scan_blueprint_for_setters, this finds any instruction that *reads*
    the variable rather than writing to it.
    """
    try:
        # skip_global_lineage=True: this function only reads meta+blocks; loading
        # global_variable_lineage.json (up to 8 GB on large codebases) is wasteful.
        blueprint = load_blueprint(path, skip_global_lineage=True, keys={"meta", "blocks"})
    except Exception as exc:
        return [], f"Could not read {path.name}: {exc}"

    aliases = _resolve_aliases(variable, blueprint.get("meta", {}).get("aliases", []))
    match_names = {variable.upper()} | aliases

    stem = _stem_from_path(path)

    hits: List[Dict[str, Any]] = []
    for block in blueprint.get("blocks", []):
        block_id = block.get("id", "UNKNOWN")
        for entry in iter_flow(block):
            if not _entry_reads_match(entry, match_names):
                continue
            args = entry.get("args", []) or []
            if isinstance(args, str):
                args = [args]
            hits.append({
                "file_stem": stem,
                "block": block_id,
                "line": entry.get("line"),
                "inst": str(entry.get("inst", "")).upper(),
                "detail": _entry_detail(entry),
                "args": list(args),
            })

    return hits, None


# ---------------------------------------------------------------------------
# Call-graph traversal
# ---------------------------------------------------------------------------

def _build_adjacency(
    graph_payload: Dict[str, Any],
) -> Tuple[Dict[str, List[Tuple[str, str]]], Dict[str, List[str]]]:
    """Build forward and reverse adjacency maps from file_call_graph.json.

    Returns:
        forward: {source: [(target, instruction)]}
        reverse: {target: [source, ...]}
    """
    forward: Dict[str, List[Tuple[str, str]]] = {}
    reverse: Dict[str, List[str]] = {}

    for edge in graph_payload.get("edges", []):
        src = edge["source"]
        tgt = edge["target"]
        inst = (edge.get("instructions") or ["?"])[0]

        forward.setdefault(src, []).append((tgt, inst))
        if src not in reverse.setdefault(tgt, []):
            reverse[tgt].append(src)

    return forward, reverse


# Maximum number of paths collected per direction before the cross-product.
# Prevents combinatorial explosion on high-fan-in/fan-out nodes in large graphs.
_PATH_CAP = 500


def _all_paths_from(
    start: str,
    forward: Dict[str, List[Tuple[str, str]]],
    max_depth: Optional[int] = None,
    max_paths: int = _PATH_CAP,
) -> List[List[str]]:
    """Return up to *max_paths* simple paths starting at *start* (forward edges).

    Depth is pruned eagerly when *max_depth* is set, and collection stops as
    soon as *max_paths* paths have been gathered to avoid combinatorial blow-up.
    """
    collected: List[List[str]] = []

    def dfs(node: str, path: List[str], visited: Set[str]) -> None:
        if len(collected) >= max_paths:
            return
        collected.append(list(path))
        if max_depth is not None and len(path) - 1 >= max_depth:
            return
        for neighbor, _inst in forward.get(node, []):
            if len(collected) >= max_paths:
                return
            if neighbor not in visited:
                visited.add(neighbor)
                path.append(neighbor)
                dfs(neighbor, path, visited)
                path.pop()
                visited.remove(neighbor)

    dfs(start, [start], {start})
    return collected


def _all_paths_to(
    end: str,
    reverse: Dict[str, List[str]],
    max_depth: Optional[int] = None,
    max_paths: int = _PATH_CAP,
) -> List[List[str]]:
    """Return up to *max_paths* simple paths ending at *end* (in forward order).

    Longer ancestor chains are emitted first (post-order DFS), so the cap
    preferentially keeps the deepest context.  Depth is pruned eagerly when
    *max_depth* is set.
    """
    collected: List[List[str]] = []

    def dfs(node: str, path_rev: List[str], visited: Set[str]) -> None:
        if len(collected) >= max_paths:
            return
        depth = len(path_rev) - 1
        if max_depth is None or depth < max_depth:
            for parent in reverse.get(node, []):
                if len(collected) >= max_paths:
                    return
                if parent not in visited:
                    visited.add(parent)
                    path_rev.append(parent)
                    dfs(parent, path_rev, visited)
                    path_rev.pop()
                    visited.remove(parent)
        if len(collected) < max_paths:
            collected.append(list(reversed(path_rev)))

    dfs(end, [end], {end})
    return collected


def _shortest_paths_to(
    end: str,
    reverse: Dict[str, List[str]],
    max_results: int,
    max_depth: Optional[int] = None,
) -> List[List[str]]:
    """Return up to *max_results* simple upstream paths ending at *end*, SHORTEST FIRST.

    A breadth-first expansion over reverse edges emits paths in nondecreasing
    length and stops as soon as *max_results* are collected. Unlike the
    longest-first DFS in ``_all_paths_to`` (which can hit its cap on deep chains
    and *miss* the short ones), this guarantees the genuinely shortest chains —
    exactly what the file-flow UI keeps after its ``[:N]`` slice — and bounds
    peak memory to the BFS frontier (≤ max_results × max_branching) instead of
    materialising up to _PATH_CAP paths.

    Each emitted path is in forward order ``[root, ..., end]``.
    """
    if max_results <= 0:
        return []
    results: List[List[str]] = []
    # Each queue item: (node, path_rev=[end, ..., node], visited set on that path).
    queue: deque = deque()
    queue.append((end, [end], frozenset((end,))))
    while queue and len(results) < max_results:
        node, path_rev, visited = queue.popleft()
        results.append(list(reversed(path_rev)))  # valid chain: every prefix ends at `end`
        if max_depth is not None and len(path_rev) - 1 >= max_depth:
            continue
        for parent in reverse.get(node, []):
            if parent not in visited:
                queue.append((parent, path_rev + [parent], visited | {parent}))
    return results


def find_chains_through(
    graph_payload: Dict[str, Any],
    target_stem: str,
    max_depth: Optional[int] = None,
    max_paths: int = _PATH_CAP,
    upstream_only: bool = False,
    max_results: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """Find call chains in the graph that include *target_stem* at any position.

    A chain is a simple path (no repeated nodes) in the directed call graph.
    Returns chains sorted by length (hops) then lexicographic order.

    Each chain dict has:
      length  — number of hops
      files   — ordered list of file stems
      hops    — list of {from, to, inst}

    Args:
        max_depth:     Maximum chain length in hops (applied eagerly inside DFS).
        max_paths:     Cap on paths collected per traversal direction before the
                       cross-product; prevents combinatorial explosion on
                       high-fan-in/fan-out nodes.  Default: _PATH_CAP (500).
        upstream_only: When True, skip the forward (downstream) traversal and
                       return only ancestor chains ending at *target_stem*.
                       Use this when callers only need the upstream context,
                       as it avoids the full to_paths × from_paths cross-product.
        max_results:   Only honoured together with *upstream_only*. When set, the
                       upstream paths are collected SHORTEST-FIRST via BFS and
                       capped at this many, bounding CPU+memory regardless of
                       graph density (replaces the longest-first DFS + _PATH_CAP).
    """
    forward, reverse = _build_adjacency(graph_payload)

    # Build edge instruction lookup for hop annotation
    edge_inst: Dict[Tuple[str, str], str] = {}
    for edge in graph_payload.get("edges", []):
        key = (edge["source"], edge["target"])
        if key not in edge_inst:
            edge_inst[key] = (edge.get("instructions") or ["?"])[0]

    if upstream_only and max_results is not None:
        # Bounded shortest-first upstream collection (preferred fast path).
        to_paths = _shortest_paths_to(
            target_stem, reverse, max_results=max_results, max_depth=max_depth
        )
    else:
        to_paths = _all_paths_to(
            target_stem, reverse, max_depth=max_depth, max_paths=max_paths
        )

    if upstream_only:
        # Callers only need [root → ... → target_stem]; skip forward expansion
        # entirely to avoid the O(to_paths × from_paths) cross-product.
        seen: Set[Tuple[str, ...]] = set()
        chains: List[Dict[str, Any]] = []
        for path in to_paths:
            key = tuple(path)
            if key in seen:
                continue
            seen.add(key)
            n_hops = len(path) - 1
            hops = [
                {"from": path[i], "to": path[i + 1], "inst": edge_inst.get((path[i], path[i + 1]), "?")}
                for i in range(n_hops)
            ]
            chains.append({"length": n_hops, "files": path, "hops": hops})
        chains.sort(key=lambda c: (c["length"], c["files"]))
        return chains

    from_paths = _all_paths_from(
        target_stem, forward, max_depth=max_depth, max_paths=max_paths
    )

    seen = set()
    chains = []

    for to_path in to_paths:
        for from_path in from_paths:
            # to_path ends at target; from_path starts at target.
            # Combine by dropping the duplicate target at from_path[0].
            # Reject if any node before target appears after target (cycle).
            before = set(to_path[:-1])
            after = set(from_path[1:])
            if not before.isdisjoint(after):
                continue

            chain = to_path + from_path[1:]
            key = tuple(chain)
            if key in seen:
                continue
            seen.add(key)

            n_hops = len(chain) - 1
            if max_depth is not None and n_hops > max_depth:
                continue

            hops = [
                {"from": chain[i], "to": chain[i + 1], "inst": edge_inst.get((chain[i], chain[i + 1]), "?")}
                for i in range(n_hops)
            ]
            chains.append({"length": n_hops, "files": chain, "hops": hops})

    chains.sort(key=lambda c: (c["length"], c["files"]))
    return chains


# ---------------------------------------------------------------------------
# Auto-discovery helpers
# ---------------------------------------------------------------------------

def _discover_graph_file(blueprint_dir: Optional[Path]) -> Optional[Path]:
    candidates: List[Path] = []
    if blueprint_dir:
        candidates += [
            blueprint_dir / "file_call_graph.json",
            blueprint_dir.parent / "file_call_graph.json",
        ]
    cwd = Path.cwd()
    candidates += [
        cwd / "temp" / "output_latest" / "file_call_graph.json",
        cwd / "output" / "file_call_graph.json",
        cwd / "file_call_graph.json",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def _discover_blueprint_dir(graph_payload: Optional[Dict[str, Any]]) -> Optional[Path]:
    if graph_payload:
        bp = graph_payload.get("metadata", {}).get("blueprint_dir", "")
        if bp:
            p = Path(bp)
            if p.exists() and list(p.glob("*.asm.json")):
                return p

    cwd = Path.cwd()
    for candidate in [
        cwd / "temp" / "output_latest" / "asm",
        cwd / "output" / "asm",
        cwd / "temp" / "parser_run",
    ]:
        if candidate.exists() and list(candidate.glob("*.asm.json")):
            return candidate
    return None


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Find every .asm.json blueprint that modifies a variable via a SETTER "
            "instruction, then show the call chains that pass through each such file."
        )
    )
    parser.add_argument("variable", help="Variable name to search for (case-insensitive)")
    parser.add_argument("--blueprint-dir", metavar="DIR",
                        help="Directory containing .asm.json files")
    parser.add_argument("--graph", metavar="FILE",
                        help="Path to file_call_graph.json")
    parser.add_argument("--output", metavar="FILE",
                        help="Output JSON path (default: <variable>_modifiers.json)")
    parser.add_argument("--max-depth", metavar="N", type=int,
                        help="Maximum chain length in hops")
    parser.add_argument("--no-chains", action="store_true",
                        help="Skip call chain lookup; write setter locations only")
    args = parser.parse_args()

    variable: str = args.variable
    output_path = Path(args.output) if args.output else Path(f"{variable}_modifiers.json")
    warnings: List[str] = []

    # ── Load call graph ──────────────────────────────────────────────────────
    graph_payload: Optional[Dict[str, Any]] = None

    if not args.no_chains:
        graph_file: Optional[Path] = Path(args.graph) if args.graph else None

        if graph_file and not graph_file.exists():
            print(f"ERROR: Graph file not found: {graph_file}", file=sys.stderr)
            return 1

        if graph_file is None:
            graph_file = _discover_graph_file(
                Path(args.blueprint_dir) if args.blueprint_dir else None
            )

        if graph_file:
            try:
                graph_payload = json.loads(graph_file.read_text(encoding="utf-8"))
                print(f"[graph]      {graph_file}", file=sys.stderr)
            except Exception as exc:
                msg = f"Could not load call graph: {exc}"
                print(f"WARNING: {msg}", file=sys.stderr)
                warnings.append(msg)
        else:
            msg = (
                "No file_call_graph.json found. "
                "Pass --graph to specify one, or --no-chains to skip chain lookup."
            )
            print(f"WARNING: {msg}", file=sys.stderr)
            warnings.append(msg)

    # ── Resolve blueprint directory ──────────────────────────────────────────
    if args.blueprint_dir:
        blueprint_dir = Path(args.blueprint_dir)
        if not blueprint_dir.exists():
            print(f"ERROR: Blueprint dir not found: {blueprint_dir}", file=sys.stderr)
            return 1
    else:
        blueprint_dir = _discover_blueprint_dir(graph_payload)
        if blueprint_dir is None:
            print(
                "ERROR: Could not discover blueprint directory. "
                "Pass --blueprint-dir explicitly.",
                file=sys.stderr,
            )
            return 1

    print(f"[blueprints] {blueprint_dir}", file=sys.stderr)

    # ── Scan blueprints ──────────────────────────────────────────────────────
    # .asm.json and .mac.json: scanned for SETTER_INST instructions in blocks[].flow.
    # .cpp.json: scanned for assign/define edges in global_variable_lineage — C++ does
    # not emit block-level flow instructions; assignments live in the GVL graph.
    # .hpp.json: excluded — headers contain only declarations, no executable setters.
    blueprint_files = sorted(
        list(blueprint_dir.glob("*.asm.json")) +
        list(blueprint_dir.glob("*.mac.json")) +
        list(blueprint_dir.glob("*.cpp.json"))
    )
    if not blueprint_files:
        print(f"ERROR: No blueprint files found in {blueprint_dir}", file=sys.stderr)
        return 1

    n_asm = sum(1 for f in blueprint_files if f.name.endswith(".asm.json"))
    n_mac = sum(1 for f in blueprint_files if f.name.endswith(".mac.json"))
    n_cpp = sum(1 for f in blueprint_files if f.name.endswith(".cpp.json"))
    print(
        f"Scanning {len(blueprint_files)} blueprints ({n_asm} asm, {n_mac} mac, {n_cpp} cpp) for '{variable}'...",
        file=sys.stderr,
    )

    setter_hits: Dict[str, List[Dict[str, Any]]] = {}

    for bp_path in blueprint_files:
        if bp_path.name.endswith(".cpp.json"):
            hits, err = scan_cpp_blueprint_for_setters(bp_path, variable)
        else:
            hits, err = scan_blueprint_for_setters(bp_path, variable)
        if err:
            warnings.append(err)
            print(f"  WARNING: {err}", file=sys.stderr)
            continue
        if hits:
            stem = hits[0]["file_stem"]
            setter_hits[stem] = hits

    if not setter_hits:
        print(
            f"Variable '{variable}' not found as a SETTER target in any blueprint.",
            file=sys.stderr,
        )
        result: Dict[str, Any] = {
            "variable": variable,
            "scanned_files": len(blueprint_files),
            "modifying_files": [],
            "results": {},
            "warnings": warnings,
        }
        output_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(f"Wrote results to: {output_path}", file=sys.stderr)
        return 0

    modifying_files = sorted(setter_hits.keys())
    print(
        f"Found {len(modifying_files)} file(s) that modify '{variable}': "
        + ", ".join(modifying_files),
        file=sys.stderr,
    )

    # ── Find call chains ─────────────────────────────────────────────────────
    graph_node_ids: Set[str] = (
        {n["id"] for n in graph_payload.get("nodes", [])}
        if graph_payload
        else set()
    )

    results: Dict[str, Any] = {}

    for stem in modifying_files:
        entry: Dict[str, Any] = {"setter_locations": setter_hits[stem]}

        if args.no_chains:
            entry["call_chains"] = None
        elif graph_payload is None:
            entry["call_chains"] = []
        elif stem not in graph_node_ids:
            msg = f"File '{stem}' not found in call graph; chain data unavailable."
            warnings.append(msg)
            entry["call_chains"] = []
            entry["call_chains_warning"] = msg
        else:
            entry["call_chains"] = find_chains_through(
                graph_payload, stem, args.max_depth
            )

        results[stem] = entry

    # ── Write output ─────────────────────────────────────────────────────────
    output: Dict[str, Any] = {
        "variable": variable,
        "scanned_files": len(blueprint_files),
        "modifying_files": modifying_files,
        "results": results,
        "warnings": warnings,
    }
    output_path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(f"Wrote results to: {output_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
