"""Parser for z/TPF assembly macro definitions (MACRO/MEND blocks)."""

import re
from pathlib import Path
from typing import List, Optional
from models.macro_definition import MacroDefinition, MacroParameter


class MacroDefinitionParser:
    """Parses MACRO/MEND blocks from assembly source files.

    Extracts macro name, parameters (with defaults), and body instructions.
    """

    def __init__(self):
        """Initialize the macro definition parser."""
        # Pattern to match MACRO directive
        self.macro_pattern = re.compile(r'^\s*MACRO\s*$', re.IGNORECASE)

        # Pattern to match MEND directive
        self.mend_pattern = re.compile(r'^\s*MEND\s*$', re.IGNORECASE)

        # Pattern to match macro prototype line (e.g., "&LABEL   CHKRC &RC=0,&ERROR=ERROR")
        self.prototype_pattern = re.compile(
            r'^(&\w+)?\s*(\w+)\s*(.*?)$'
        )

        # Pattern to extract parameters with defaults
        self.param_pattern = re.compile(r'(&\w+)(?:=([^,]+))?')

    def parse_file(self, file_path: Path) -> List[MacroDefinition]:
        """Parse macro definitions from a file.

        Args:
            file_path: Path to assembly file containing macros

        Returns:
            List of MacroDefinition objects found in file
        """
        content = file_path.read_text(encoding="latin-1")
        return self.parse_macro_definitions(content, file_path)

    def parse_macro_definitions(
        self,
        content: str,
        source_file: Path
    ) -> List[MacroDefinition]:
        """Parse all macro definitions from assembly content.

        Args:
            content: Assembly source code text
            source_file: Path to source file (for provenance)

        Returns:
            List of MacroDefinition objects
        """
        lines = content.split('\n')
        macros = []

        i = 0
        while i < len(lines):
            line = lines[i]

            # Check if this is a MACRO directive
            if self.macro_pattern.match(line):
                macro = self._parse_single_macro(lines, i, source_file)
                if macro:
                    macros.append(macro)
                    i = macro.end_line  # Skip to end of this macro
                else:
                    i += 1
            else:
                i += 1

        return macros

    def _parse_single_macro(
        self,
        lines: List[str],
        start_index: int,
        source_file: Path
    ) -> Optional[MacroDefinition]:
        """Parse a single macro definition starting at given line.

        Args:
            lines: All lines from the file
            start_index: Index of MACRO directive line
            source_file: Source file path

        Returns:
            MacroDefinition if valid macro found, None otherwise
        """
        macro_start = start_index

        # Next line should be prototype
        if start_index + 1 >= len(lines):
            return None

        prototype_line = lines[start_index + 1]

        # Parse prototype to get name and parameters
        name, parameters = self._parse_prototype(prototype_line)
        if not name:
            return None

        # Parse body until MEND
        body = []
        current_line = start_index + 2

        while current_line < len(lines):
            line = lines[current_line]

            if self.mend_pattern.match(line):
                # Found end of macro
                return MacroDefinition(
                    name=name,
                    parameters=parameters,
                    body=body,
                    source_file=source_file,
                    start_line=macro_start + 1,  # 1-indexed
                    end_line=current_line + 1,  # 1-indexed
                    scope="global"  # Default to global, can be changed later
                )
            else:
                # Add to body (excluding the prototype line)
                body.append(line)

            current_line += 1

        # No MEND found - invalid macro
        return None

    def _parse_prototype(self, line: str) -> tuple[Optional[str], List[MacroParameter]]:
        """Parse macro prototype line to extract name and parameters.

        Args:
            line: Prototype line (e.g., "&LABEL   CHKRC &RC=0,&ERROR=ERROR")

        Returns:
            Tuple of (macro_name, list of MacroParameter objects)
        """
        match = self.prototype_pattern.match(line)
        if not match:
            return None, []

        label = match.group(1)  # Optional &LABEL
        name = match.group(2)  # Macro name
        params_str = match.group(3)  # Parameter string

        parameters = []

        # If there's a label parameter, add it first
        if label:
            parameters.append(MacroParameter(
                name=label,
                default_value=None,
                is_label=True
            ))

        # Parse positional and keyword parameters
        if params_str:
            for param_match in self.param_pattern.finditer(params_str):
                param_name = param_match.group(1)
                default_value = param_match.group(2)

                parameters.append(MacroParameter(
                    name=param_name,
                    default_value=default_value,
                    is_label=False
                ))

        return name, parameters
