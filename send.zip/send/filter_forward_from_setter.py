#!/usr/bin/env python3
"""
filter_forward_from_setter.py

Trace forward from a specific write instruction until the next write of the
same variable on each execution path.

  - Starts at a known setter: (block, line) in a single .asm file
  - Follows control flow forward, collecting USES and SIDE-EFFECTS
  - Stops each path at the first OVERWRITE (next write to the same variable)
  - Cross-file calls are noted but NOT followed (intentionally intra-file)

Usage:
  python filter_forward_from_setter.py WK_RRC \\
      --file da78 --block DA7_1800 --line 1164

  python filter_forward_from_setter.py WK_RRC \\
      --file da78 --block DA7_0800 --line 939 \\
      --blueprint-dir /path/to/blueprints \\
      --asm-dir /path/to/asm \\
      --output result.json

  # Trace every setter found in a cross-lineage JSON
  python filter_forward_from_setter.py WK_RRC \\
      --from-lineage WK_RRC_cross_lineage.json
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from cross_file_bridge import _discover_blueprint_dir, _discover_asm_dir
from forward_trace_lineage import ForwardLineageTracer


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

FORWARD_USE_ROLES = {"READER", "CONDITION_TEST", "BRANCH_ON_CONDITION"}
SIDE_EFFECT_ROLES = {"SIDE_EFFECT_SETTER", "SUBROUTINE_USAGE"}


def _resolve_asm_file(
    stem: str,
    asm_dir: Optional[Path],
    blueprint_dir: Optional[Path],
) -> Optional[Path]:
    """Return the .asm Path for *stem*, searching known locations."""
    candidates: List[Path] = []
    if asm_dir:
        candidates.append(asm_dir / f"{stem}.asm")
    if blueprint_dir:
        candidates += [
            blueprint_dir.parent.parent / "asm" / f"{stem}.asm",
            blueprint_dir.parent / "asm" / f"{stem}.asm",
            blueprint_dir / f"{stem}.asm",
        ]
    candidates.append(Path.cwd() / f"{stem}.asm")
    for c in candidates:
        if c.exists():
            return c
    return None


def trace_one(
    variable: str,
    stem: str,
    block_id: str,
    line: int,
    blueprint_dir: Path,
    asm_dir: Optional[Path],
) -> Dict[str, Any]:
    """Run trace_forward_from_setter for one (stem, block, line) and return
    a structured result dict."""

    bp = blueprint_dir / f"{stem}.asm.json"
    asm_file = _resolve_asm_file(stem, asm_dir, blueprint_dir)

    if asm_file is None:
        return {
            "setter": {"file": f"{stem}.asm", "block": block_id, "line": line},
            "error": f"Could not find {stem}.asm source file.",
        }
    if not bp.exists():
        return {
            "setter": {"file": asm_file.name, "block": block_id, "line": line},
            "error": f"Blueprint not found: {bp}",
        }

    tracer = ForwardLineageTracer(
        asm_dir=asm_dir or blueprint_dir,
        blueprint_dir=blueprint_dir,
    )

    results = tracer.trace_forward_from_setter(
        target_variable=variable,
        source_asm_file=asm_file,
        blueprint_file=bp,
        start_block_id=block_id,
        start_line=line,
    )

    chain = results.lineage_chain

    uses         = [e for e in chain if e.get("role") in FORWARD_USE_ROLES]
    overwrites   = [e for e in chain if e.get("role") == "OVERWRITE"]
    side_effects = [e for e in chain if e.get("role") in SIDE_EFFECT_ROLES]
    cross_file   = [e for e in chain if e.get("role") == "CROSS_FILE_CALL"]
    branches     = [e for e in chain if e.get("role") in {
                        "BRANCH_ENTRY", "FALLTHROUGH_ENTRY", "MACRO_BRANCH"}]

    return {
        "setter": {
            "file":    asm_file.name,
            "block":   block_id,
            "line":    line,
        },
        "uses": uses,
        "terminal_overwrites": overwrites,
        "side_effects": side_effects,
        "cross_file_calls": cross_file,
        "branch_edges": branches,
        "warnings": [str(w) for w in results.data_quality_warnings],
        "full_chain": chain,
    }


# ---------------------------------------------------------------------------
# --from-lineage: batch-trace every setter in a cross-lineage JSON
# ---------------------------------------------------------------------------

def from_lineage(
    lineage_path: Path,
    variable: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path],
) -> List[Dict[str, Any]]:
    """Read setter_paths from a cross-lineage JSON and trace each setter forward."""
    data = json.loads(lineage_path.read_text(encoding="utf-8"))

    var = variable or str(data.get("variable", ""))
    modifier = str(data.get("modifier_file", ""))
    sections = data.get("sections", {})
    modifier_section = sections.get(modifier, {})
    setter_paths = modifier_section.get("setter_paths", [])

    if not setter_paths:
        print(f"WARNING: No setter_paths found in section '{modifier}'.", file=sys.stderr)
        return []

    out: List[Dict[str, Any]] = []
    for sp in setter_paths:
        block = str(sp.get("setter_block", ""))
        line  = int(sp.get("setter_line",  0))
        if not block or not line:
            continue
        print(
            f"  Tracing forward from {modifier}:{block}:{line}  "
            f"({sp.get('setter_detail', '')})",
            file=sys.stderr,
        )
        result = trace_one(var, modifier, block, line, blueprint_dir, asm_dir)
        result["setter"]["detail"] = sp.get("setter_detail", "")
        result["setter"]["chunk_id"] = sp.get("setter_chunk_id", "")
        out.append(result)

    return out


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Trace forward from a specific setter instruction, stopping at the "
            "next write to the same variable on each execution path."
        )
    )
    parser.add_argument("variable", help="Variable name (e.g. WK_RRC)")
    parser.add_argument(
        "--file", metavar="STEM",
        help="ASM file stem (e.g. da78).  Required unless --from-lineage is used.",
    )
    parser.add_argument(
        "--block", metavar="BLOCK_ID",
        help="Block containing the setter (e.g. DA7_1800).",
    )
    parser.add_argument(
        "--line", metavar="N", type=int,
        help="Line number of the setter instruction.",
    )
    parser.add_argument(
        "--from-lineage", metavar="FILE",
        help=(
            "Read setter locations from a cross-lineage JSON (output of "
            "trace_cross_file_lineage.py) and trace each setter forward."
        ),
    )
    parser.add_argument("--blueprint-dir", metavar="DIR")
    parser.add_argument("--asm-dir",       metavar="DIR")
    parser.add_argument(
        "--output", metavar="FILE",
        help="Output JSON path (default: <variable>_forward_from_setter.json)",
    )
    args = parser.parse_args()

    variable   = args.variable
    output_path = Path(args.output) if args.output else Path(f"{variable}_forward_from_setter.json")

    # ── Resolve directories ──────────────────────────────────────────────────
    if args.blueprint_dir:
        blueprint_dir = Path(args.blueprint_dir)
    else:
        blueprint_dir = _discover_blueprint_dir()
        if blueprint_dir is None:
            print("ERROR: Could not discover blueprint directory. Pass --blueprint-dir.",
                  file=sys.stderr)
            return 1
    print(f"[blueprints]  {blueprint_dir}", file=sys.stderr)

    asm_dir: Optional[Path] = Path(args.asm_dir) if args.asm_dir else _discover_asm_dir(blueprint_dir)
    if asm_dir:
        print(f"[asm-source]  {asm_dir}", file=sys.stderr)

    # ── Mode: batch from cross-lineage JSON ──────────────────────────────────
    if args.from_lineage:
        lineage_path = Path(args.from_lineage)
        if not lineage_path.exists():
            print(f"ERROR: Lineage file not found: {lineage_path}", file=sys.stderr)
            return 1
        print(f"\nBatch mode: reading setters from {lineage_path}", file=sys.stderr)
        traces = from_lineage(lineage_path, variable, blueprint_dir, asm_dir)
        output: Dict[str, Any] = {
            "variable": variable,
            "source_lineage": str(lineage_path),
            "traces": traces,
        }

    # ── Mode: single (file, block, line) ─────────────────────────────────────
    else:
        if not args.file:
            print("ERROR: --file is required when not using --from-lineage.", file=sys.stderr)
            return 1
        if not args.block:
            print("ERROR: --block is required.", file=sys.stderr)
            return 1
        if args.line is None:
            print("ERROR: --line is required.", file=sys.stderr)
            return 1

        stem    = args.file.lower().removesuffix(".asm")
        block   = args.block.upper()
        line    = args.line

        print(f"\nTracing forward: {variable} from {stem}:{block}:{line}", file=sys.stderr)
        result = trace_one(variable, stem, block, line, blueprint_dir, asm_dir)

        output = {
            "variable":    variable,
            "traces":      [result],
        }

    # ── Write output ─────────────────────────────────────────────────────────
    output_path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(f"\nWrote results to: {output_path}", file=sys.stderr)

    # ── Print summary to stdout ───────────────────────────────────────────────
    for trace in output.get("traces", []):
        setter = trace.get("setter", {})
        print(
            f"\n=== {setter.get('file')}  block={setter.get('block')}  "
            f"line={setter.get('line')}  {setter.get('detail', '')} ===",
        )
        if "error" in trace:
            print(f"  ERROR: {trace['error']}")
            continue
        uses = trace.get("uses", [])
        overwrites = trace.get("terminal_overwrites", [])
        cross = trace.get("cross_file_calls", [])
        print(f"  Uses (reads/conditions):   {len(uses)}")
        for u in uses:
            print(f"    [{u.get('role'):20s}] line {u.get('line'):>5}  {u.get('block'):20s}  {u.get('detail','')}")
        print(f"  Terminal overwrites:        {len(overwrites)}")
        for ow in overwrites:
            print(f"    [OVERWRITE           ] line {ow.get('line'):>5}  {ow.get('block'):20s}  {ow.get('detail','')}")
        if cross:
            print(f"  Cross-file calls (noted):  {len(cross)}")
            for cf in cross:
                print(f"    [CROSS_FILE_CALL     ] line {cf.get('line'):>5}  {cf.get('block'):20s}  {cf.get('detail','')}")
        warns = trace.get("warnings", [])
        if warns:
            print(f"  Warnings: {len(warns)}")
            for w in warns:
                print(f"    {w}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
