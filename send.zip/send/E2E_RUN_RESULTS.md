# E2E Run Results — asm_1400 (1400 files)

**Date:** 2026-05-12
**Branch:** dev_tabish
**Commit:** 076eaed
**Source dataset:** `/var/asm-source/asm_1400`
**KB ID:** `1231b1e8-9e57-45c3-8ed8-4aac80c95132`

---

## Input

| File type | Count |
|-----------|-------|
| .asm      | 750   |
| .mac      | 300   |
| .cpp      | 250   |
| .hpp      | 100   |
| **Total** | **1400** |

---

## Pipeline

| Metric | Value |
|--------|-------|
| Status | **SUCCESS** |
| Task elapsed | 367.2s |
| Total wall-clock | 395.1s |
| Output files generated | 1409 |
| Call graph nodes | 1158 |
| Call graph edges | 11,146 |

---

## Index Build (post-pipeline)

| Index | Scope | Entries |
|-------|-------|---------|
| Modifier index | 1,050 blueprints (ASM + MAC) | 653 unique variables |
| Identity index | 750 ASM blueprints | 77,698 identities, 1,674 names |
| Hop index | 750 ASM blueprints | 1,333 identities, 438,450 hop records |
| Global Variable Lineage | All 1,400 files | 229,577 nodes, 1,686,467 edges |

---

## API Tests

| # | Endpoint | Variable / Chain | Result | Elapsed | Peak RAM (worker) | CPU (worker) |
|---|----------|-----------------|--------|---------|-------------------|--------------|
| 0 | POST /jobs/pipeline | — | **PASS** — HTTP 202, task state=SUCCESS, 1409 output files | 367.2s | 5,920 MB VmRSS | 96.19% |
| 1 | POST /modifiers | WK_CNT | **PASS** — 100 setter files, 50 chains | 10.1s | — | — |
| 2 | POST /backward-lineage | WK_CNT, chain `lu82→da76` | **PASS** — 20 flow nodes, 20 dep vars | 5.0s | — | — |
| 3 | POST /variable-flow (ASM→ASM) | WK_CNT, `lu82→da76` | **PASS** — 1 resolved chain, DSECT+Offset, line 128 OC | 3.1s | — | — |
| 4 | POST /variable-flow (ASM→CPP) | TPFCV83, `da78→xh80` | PASS — path found, unresolved at C++ boundary (expected) | 0.9s | — | — |
| 5 | POST /variable-usage | WK_CNT | **PASS** — found=True, 100 files, 100 locations | ~4s | — | — |
| 6 | POST /variable-usage (cache) | WK_CNT (2nd call) | **PASS** — cached=True, 1.0s vs ~4s cold | 1.0s | — | — |
| 7 | POST /variable-usage | TPFCV83 (C++ global) | found=False — not in ASM setter index (expected) | ~4s | — | — |

**Overall result: ALL TESTS PASSED**

### POST /jobs/pipeline — Detailed Resource Timeline

| Stage | Wall time | VmRSS (worker) | Worker CPU |
|-------|-----------|----------------|------------|
| Analysis (all 1400 files) | 0s – ~290s | grows to 4,243 MB | 96.19% |
| GVL write (229K nodes, 1.7M edges) | ~290s – ~292s | 4,272 MB → 4,272 MB (zero spike) | high |
| GVL graph freed + heap trim | ~292s – ~303s | 4,272 MB → 4,243 MB | low |
| Blueprint emission (1 thread, 1400 files) | ~303s – ~363s | 4,243 MB → **5,920 MB** peak → 5,508 MB | moderate |
| Post-emission heap trim | ~363s – ~364s | 5,508 MB → 3,871 MB | low |
| Index builds (modifier, identity, hop) | ~364s – ~428s | ~3,871 MB | moderate |
| **Total task elapsed** | **367.2s** | | |
| **Total wall-clock** | **395.1s** | | |

---

## C++ Variable Analysis

| Metric | Value |
|--------|-------|
| C++ blueprints produced | 250 .cpp.json + 100 .hpp.json |
| Variable lineage per file (dx710000.cpp) | 393 nodes, 1,067 edges |
| Node kinds | function, variable, literal, struct_field, call_arg, register, use, global, memory |
| C++ nodes in global GVL | 6,850 |
| C++ globals tracked (dx710000.cpp) | TPFCV83 |
| Dependent variables in backward lineage | 20 (e.g. @CCIBIND, @TPFCV82, CE1DT2, CE1FM5, EB0U001 …) |

---

## Memory Profile (Worker, VmRSS — live current RSS via /proc/self/status)

| Stage | VmRSS |
|-------|-------|
| Before GVL write | 4,272 MB |
| After GVL streamed (229K nodes, 1.7M edges, 470 MB file) | 4,272 MB — **zero spike** |
| After GVL graph freed (pre-emission) | 4,243 MB |
| Available RAM → emission workers | 2,411 MB → **1 thread** |
| Peak during emission (after first 50 files) | 5,920 MB |
| After 1400/1400 files emitted | 5,508 MB |
| After full malloc_trim | 3,871 MB |
| Worker container at rest | 385 MiB |

---

## Disk Usage

| Volume | Size |
|--------|------|
| jobs (after pipeline) | 2.1 GB |
| jobs (final) | 2.1 GB |
| datasource | 4.0 KB |
| db | 40 KB |

---

## Container Stats

| Container | CPU (during pipeline) | MEM (during pipeline) | MEM (final idle) |
|-----------|----------------------|----------------------|-----------------|
| worker | 96.19% | 509 MiB (early snapshot) | 385 MiB |
| api | 0.51% | 174 MiB | 3.95 GiB |
| nginx | 0.00% | 12 MiB | 1.7 MiB |
| beat | 0.00% | 46 MiB | 13 MiB |
| redis | 0.24% | 13 MiB | 13 MiB |

---

## Fixes Applied in This Run

### 1. Blueprint corruption — `passes/cross_file_access_identity.py`

`_enrich_blueprint` was calling `load_blueprint` with
`keys={"variable_lineage", "line_metadata"}`, then writing back via
`pack_blueprint`. This destroyed all other blueprint content (blocks,
meta, call_graph, subroutines, dsect_layouts, etc.) on every file in
the KB. Removed the `keys=` parameter; now loads the full blueprint.

**Symptom:** modifier index showed 0 unique variables; backward-lineage
returned HTTP 422 (setter not found).

### 2. OOM SIGKILL during pipeline — `api/tasks/analysis_task.py`

Three-layer fix:

- **Streaming GVL write** (`_stream_write_gvl`): serialises the
  229K-node graph to msgpack node-by-node instead of calling
  `graph.to_dict()`, eliminating the ~743 MB intermediate dict spike.

- **VmRSS measurement**: replaced `resource.getrusage().ru_maxrss`
  (Linux high-watermark, never decreases) with `/proc/self/status`
  VmRSS (live current RSS) so trim decisions are based on actual memory.

- **Memory-aware emission workers**: reads `MemAvailable` from
  `/proc/meminfo` and caps workers to `available_MB // 2000` (min 1).
  On a 7.6 GiB host with ~2.4 GB free → 1 thread, peak 5.9 GB VmRSS,
  well within host limits. Previously 4 concurrent threads spiked the
  container to 7.2 GiB (94% of Docker VM) and triggered OOM SIGKILL.
