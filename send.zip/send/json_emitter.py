"""JSON emitter for analysis results."""
import json
from typing import Dict, Any
from models.analysis_context import AnalysisContext
from models.symbol import SymbolType


class JSONEmitter:
    """Emits analysis results as JSON."""

    def emit(self, context: AnalysisContext) -> Dict[str, Any]:
        """
        Emit analysis results as dictionary.

        Args:
            context: Analysis context with all results

        Returns:
            Dictionary representation of analysis results
        """
        result = {
            "metadata": self._emit_metadata(context),
            "meta": self._emit_meta(context),
            "symbol_aliases": self._emit_symbol_aliases(context),
            "field_asm_aliases": self._emit_field_asm_aliases(context),
            "field_asm_alias_sources": self._emit_field_asm_alias_sources(context),
            "enum_values": self._emit_enum_values(context),
            "globals_used": self._emit_globals_used(context),
            "asm_entry_point_map": self._emit_asm_entry_point_map(context),
            "symbols": self._emit_symbols(context),
            "call_graph": self._emit_call_graph(context),
            "blocks": self._emit_blocks(context),
            "subroutines": self._emit_subroutines(context),
            "db_operations": self._emit_db_operations(context),
            "file_dependencies": self._emit_file_dependencies(context),
            "class_bases": self._emit_class_bases(context),
            "union_members": self._emit_union_members(context),
            "macro_expansions": self._emit_macro_expansions(context),
            "macro_errors": self._emit_macro_errors(context),
            "variable_lineage": self._emit_variable_lineage(context),
            "dsect_layouts": self._emit_dsect_layouts(context),
            "build_metadata": self._emit_build_metadata(context),
            "line_metadata": self._emit_line_metadata(context),
            "register_entry_state": self._emit_register_entry_state(context),
        }

        return result

    def emit_json(self, context: AnalysisContext) -> str:
        """Emit analysis results as compact JSON string (no whitespace — T1)."""
        data = self.emit(context)
        return json.dumps(data, separators=(',', ':'))

    def emit_msgpack(self, context: AnalysisContext) -> bytes:
        """Emit analysis results as msgpack bytes (T2+T3 compact binary format)."""
        from blueprint_io import pack_blueprint
        return pack_blueprint(self.emit(context))

    def _emit_metadata(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit metadata section."""
        metadata = {
            "version": "1.0",
            "generator": "z/TPF Assembly Parser"
        }
        c_errors = context.get_metadata("c_family_parse_errors")
        if c_errors is not None:
            metadata["c_family_parse_errors"] = c_errors
        lineage_trace = context.get_metadata("lineage_trace")
        if lineage_trace is not None:
            metadata["lineage_trace"] = lineage_trace
        return metadata

    def _emit_meta(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit ASM blueprint meta section."""
        meta = context.get_metadata("asm_meta") or {}
        aliases = meta.get("aliases", {})
        base_registers = meta.get("base_registers", {})
        return {
            "aliases": [
                {"name": name, "target": target}
                for name, target in sorted(aliases.items())
            ],
            "base_registers": [
                {"reg": reg, "target": target}
                for reg, target in sorted(base_registers.items())
            ],
        }

    def _emit_symbol_aliases(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit C/C++ symbol aliases extracted from pragma map / asm labels."""
        unit = context.get_metadata("c_family_unit")
        aliases: Dict[str, Any] = {}
        if unit is not None:
            unit_aliases = getattr(unit, "symbol_aliases", None)
            if unit_aliases:
                aliases.update(dict(unit_aliases))

        # Fallback: derive aliases from symbol table asm_name when parser metadata
        # is unavailable (e.g., cached/legacy contexts).
        for symbol in getattr(context.symbol_table, "all_symbols", []):
            name = getattr(symbol, "name", None)
            asm_name = getattr(symbol, "asm_name", None)
            if not name or not asm_name:
                continue
            aliases.setdefault(name, asm_name)

        return aliases

    def _emit_field_asm_aliases(self, context: AnalysisContext) -> Dict[str, str]:
        """Emit C++ struct-field → ASM variable aliases from cc*.hpp trailing comments.

        Populated by `_extract_field_asm_aliases()` in the parser and augmented
        by `_collect_include_field_asm_aliases()` in the multi-file analyzer.
        Keys are `StructName.fieldName`; values are the uppercased ASM symbol.
        """
        unit = context.get_metadata("c_family_unit")
        aliases: Dict[str, str] = {}
        if unit is not None:
            unit_aliases = getattr(unit, "field_asm_aliases", None)
            if unit_aliases:
                aliases.update(dict(unit_aliases))
        return aliases

    def _emit_field_asm_alias_sources(self, context: AnalysisContext) -> Dict[str, str]:
        """Emit the cc*.hpp basename each field alias came from.

        Parallel to `field_asm_aliases`: same keys, values are header filenames
        (e.g. "cclg1g1.hpp", "ccda7gl.hpp"). Lets downstream consumers report
        which header established a mapping when the trace references it.
        """
        unit = context.get_metadata("c_family_unit")
        sources: Dict[str, str] = {}
        if unit is not None:
            unit_sources = getattr(unit, "field_asm_alias_sources", None)
            if unit_sources:
                sources.update(dict(unit_sources))
        return sources

    def _emit_enum_values(self, context: AnalysisContext) -> Dict[str, Dict[str, str]]:
        """Emit enum identifier → {enum_type, value} mappings (Phase 5).

        Populated by `_extract_enum_values()` in the parser and augmented by
        `_collect_include_enum_values()` in the multi-file analyzer. Lets
        downstream consumers resolve `task = AddLimit` to its literal value
        `'A'` when matching against ASM conditions like `CLI LG1TYP,C'A'`.
        """
        unit = context.get_metadata("c_family_unit")
        values: Dict[str, Dict[str, str]] = {}
        if unit is not None:
            unit_values = getattr(unit, "enum_values", None)
            if unit_values:
                values.update({k: dict(v) for k, v in unit_values.items()})
        return values

    def _emit_globals_used(self, context: AnalysisContext) -> list:
        """Phase 7 — emit the list of uppercased ASM global names referenced
        via ``glob(_name)`` calls anywhere in the translation unit.

        Parallel to `field_asm_aliases`: consumers can join the list with
        ASM-side memory symbols to spot which globals cross the boundary."""
        unit = context.get_metadata("c_family_unit")
        values = getattr(unit, "globals_used", None) if unit else None
        return list(values) if values else []

    def _emit_asm_entry_point_map(self, context: AnalysisContext) -> Dict[str, str]:
        """Emit {asm_name -> cpp_function_name} for all ASM-callable entry points.

        Covers two patterns:
          1. asm("NAME") / #pragma map  — reverse of symbol_aliases
          2. Direct extern "C" with no alias — identity mapping for "entry" type
             symbols whose C++ name IS the assembly-callable name (e.g. XH89)

        Used by cross_file_bridge to resolve ENTRC targets without source parsing.
        """
        result: Dict[str, str] = {}

        # Collect names of functions DEFINED in this file (entry type).
        # External declarations (extrn) represent outbound calls — this file
        # calls them, but they are defined and owned by other modules.
        entry_names: set = {
            str(getattr(s, "name", ""))
            for s in getattr(context.symbol_table, "all_symbols", [])
            if getattr(s, "symbol_type", None) == SymbolType.ENTRY
            and getattr(s, "name", None)
        }

        # Pattern 1: asm("NAME") and #pragma map — only for DEFINED functions.
        # symbol_aliases also captures extern declarations with asm() used for
        # outbound calls; those must be excluded or the map becomes incorrect.
        for cpp_name, asm_name in self._emit_symbol_aliases(context).items():
            if asm_name and str(cpp_name) in entry_names:
                result[str(asm_name)] = str(cpp_name)

        # Pattern 2: direct extern "C" entry points (no asm alias) — identity.
        for symbol in getattr(context.symbol_table, "all_symbols", []):
            sym_type = getattr(symbol, "symbol_type", None)
            name = getattr(symbol, "name", None)
            asm_name = getattr(symbol, "asm_name", None)
            if sym_type == SymbolType.ENTRY and name and not asm_name:
                result.setdefault(str(name), str(name))

        return result

    def _emit_symbols(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit symbols section."""
        if context.symbol_table is None:
            return {}
        return context.symbol_table.to_dict()

    def _emit_call_graph(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit call graph section."""
        call_graph = context.get_metadata("call_graph")
        if call_graph:
            return call_graph.to_dict()
        return {"nodes": {}, "edges": []}

    def _emit_blocks(self, context: AnalysisContext) -> list:
        """Emit blocks section."""
        result = context.get_metadata("block_analysis")
        if result:
            return [b.to_dict() for b in result.blocks]
        return []

    def _emit_subroutines(self, context: AnalysisContext) -> list:
        """Emit subroutines section."""
        result = context.get_metadata("block_analysis")
        if result:
            return [s.to_dict() for s in result.subroutines]
        return []

    def _emit_db_operations(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit DB operations section."""
        catalog = context.get_metadata("db_operation_catalog")
        if catalog:
            return catalog.to_dict()
        return {"operations": []}

    def _emit_file_dependencies(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit file dependencies section."""
        graph = context.get_metadata("file_dependency_graph")
        if graph:
            return graph.to_dict()
        return {"nodes": [], "edges": [], "circular_dependencies": []}

    def _emit_class_bases(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit class inheritance map {DerivedClass: [BaseClass, ...]} for cross-TU CHA."""
        unit = context.get_metadata("c_family_unit")
        if unit is None:
            return {}
        return dict(getattr(unit, "class_bases", None) or {})

    def _emit_union_members(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit union layout {UnionName: [member, ...]} for may_alias analysis."""
        unit = context.get_metadata("c_family_unit")
        if unit is None:
            return {}
        return dict(getattr(unit, "union_members", None) or {})

    def _emit_macro_expansions(self, context: AnalysisContext) -> list:
        """Emit macro expansion section."""
        if not hasattr(context, 'macro_expansions'):
            return []

        result = []
        for expansion in context.macro_expansions:
            if getattr(expansion, 'expansion_status', None) == "success":
                to_dict = getattr(expansion, 'to_dict', None)
                result.append(to_dict() if to_dict else vars(expansion))
        return result

    def _emit_macro_errors(self, context: AnalysisContext) -> list:
        """Emit macro errors section."""
        if not hasattr(context, 'macro_expansions'):
            return []

        errors = []
        for expansion in context.macro_expansions:
            err = getattr(expansion, 'error', None)
            if err:
                to_dict = getattr(err, 'to_dict', None)
                errors.append(to_dict() if to_dict else vars(err) if hasattr(err, '__dict__') else str(err))

        return errors

    def _emit_variable_lineage(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit variable lineage section."""
        graph = context.get_metadata("variable_lineage")
        if graph:
            return graph.to_dict()
        return {"nodes": [], "edges": []}

    def emit_global_lineage(self, context: AnalysisContext) -> Dict[str, Any]:
        """Return the merged global variable lineage graph as a dict.

        This is intentionally NOT included in the per-file blueprint emitted by
        emit() — the global graph is O(N) to O(N²) in the number of files and
        must be written once as a shared ``global_variable_lineage.json`` file
        rather than replicated into every individual blueprint.
        """
        graph = context.get_metadata("global_variable_lineage")
        if graph:
            return graph.to_dict()
        return {"nodes": [], "edges": []}

    def _emit_dsect_layouts(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit DSECT field offset layouts for cross-file variable identity matching."""
        dsect_field_offsets = context.get_metadata("dsect_field_offsets")
        if not dsect_field_offsets:
            return {}
        result = {}
        for dsect_name, fields in dsect_field_offsets.items():
            result[dsect_name] = {
                field_name: {"offset": offset, "length": length}
                for field_name, (offset, length) in sorted(fields.items(), key=lambda x: x[1][0])
            }
        return result

    def _emit_build_metadata(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit build metadata section from Makefiles."""
        build_metadata = context.get_metadata("build_metadata")
        if build_metadata:
            return build_metadata
        return {}

    def _emit_line_metadata(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit line metadata section."""
        line_metadata_dict = {}
        # Add line metadata if available
        if hasattr(context, 'line_metadata_index') and context.line_metadata_index:
            for metadata in context.line_metadata_index.get_all():
                line_metadata_dict[str(metadata.line_number)] = metadata.to_dict()

        # Merge per-line USING + register CE-slot snapshots
        using_snapshots = context.get_metadata("line_using_snapshots")
        if using_snapshots:
            for line_str, snap in using_snapshots.items():
                if line_str in line_metadata_dict:
                    line_metadata_dict[line_str]["active_usings"] = snap.get("active_usings", {})
                    line_metadata_dict[line_str]["register_ce_slots"] = snap.get("register_ce_slots", {})
                else:
                    line_metadata_dict[line_str] = snap

        return line_metadata_dict

    def _emit_register_entry_state(self, context: AnalysisContext) -> Dict[str, Any]:
        """Emit register entry state for cross-file register liveness checks.

        ``inherited_regs``  — USING base registers NOT written before USING
                              (the caller loaded them; safe to carry identity).
        ``self_loaded_regs`` — USING base registers written by this file before USING
                              (the callee loaded its own value; identity is overwritten).
        """
        state = context.get_metadata("register_entry_state")
        if state:
            return state
        return {"inherited_regs": [], "self_loaded_regs": []}
