#!/usr/bin/env python3
"""Variable lineage tracer for assembler + blueprint JSON.

Implements the algorithm documented in `variable_lineage_algorithm.md`:
- per-setter backward tracing
- trigger/branch relevance (BRANCH_TO_SETTER vs GUARD_BRANCH)
- subroutine range scans
- cross-file dependency discovery + recursive blueprint tracing
"""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from blueprint_io import iter_flow, load_blueprint


# --------------------------------------------------------------------------
# Macro-branch expansion table.
# Each entry: (MACRO_NAME, KEYWORD_PARAM, synthetic branch mnemonic)
# When a source line matches   <MACRO>  ...PARAM=<label>...," the expander
# injects a synthetic "*$MACRO  <mnemonic>  <label>  <comment>" line
# immediately after it in the in-memory working copy.  The original file
# is NEVER written.
# --------------------------------------------------------------------------

MACRO_BRANCH_PARAMS: List[Tuple[str, str, str]] = [
    ("ACCTA", "ERRTN", "BNZ"),     # ACCTA: jumps to label on validation error
    ("CASIO", "FACEERR", "BNZ"),   # CASIO: jumps to label on face error
    ("CASIO", "IOERR", "BNZ"),     # CASIO: jumps to label on I/O error
    ("LEVTA", "NOTUSED", "BZ"),    # LEVTA: jumps to label when level not in use
    ("ISCFA", "ERROR", "BNZ"),     # ISCFA: jumps to label on ISCFA error
    ("EVNWC", "ERROR", "BNZ"),     # EVNWC: jumps to label on event error
    ("EVNWC", "NFOUND", "BZ"),     # EVNWC: jumps to label when event not found
    ("DBADD", "ERROR", "BNZ"),     # DBADD: jumps to label when add fails (ztpfdf-db-macros)
    ("DBDEL", "ERROR", "BNZ"),     # DBDEL: jumps to label when delete fails (ztpfdf-db-macros)
]

# Regex to extract KEYWORD=LABEL from a macro parameter list.
# Matches KEYWORD=LABEL where LABEL is a valid assembler symbol.
_MACRO_PARAM_RE = re.compile(
    r'\b(?P<key>[A-Z0-9_]+)=(?P<label>[A-Z@#$][A-Z0-9@#$_]*)',
    re.IGNORECASE,
)


def expand_macro_branches(raw_lines: List[str]) -> List[str]:
    """Return an in-memory copy of *raw_lines* with synthetic *$MACRO branch
    lines injected after any macro invocation that encodes a conditional
    branch via a keyword parameter (ERRTN=, NOTUSED=, FACEERR=, etc.).

    The original source file is never touched.  Injected lines look like::

        *$MACRO  BNZ   DA7_1810            ACCTA ERRTN= (macro branch)

    The leading "*$MACRO" tag makes them visible to the tracer while
    remaining clearly distinct from real source lines in any human review.
    The "*$" prefix is stripped by `parse_instruction_line` only for
    these tagged lines, so the branch mnemonic is parsed normally.
    """
    out: List[str] = []
    for line in raw_lines:
        out.append(line)
        stripped = line.lstrip()
        if not stripped or stripped.startswith("*"):
            continue

        # Identify the macro name: first token if it starts in column > 1,
        # or second token if there is a label in column 1.
        tokens = line.split()
        if not tokens:
            continue

        # Heuristic: if col 0 is non-space -> first token is label, second is macro.
        if line[0] != " " and len(tokens) >= 2:
            macro_name = tokens[1].upper()
        else:
            macro_name = tokens[0].upper()

        for (table_macro, table_param, synth_branch) in MACRO_BRANCH_PARAMS:
            if macro_name != table_macro.upper():
                continue
            # Scan all KEYWORD=LABEL matches in the line.
            for m in _MACRO_PARAM_RE.finditer(line):
                if m.group("key").upper() != table_param.upper():
                    continue
                label = m.group("label")
                synthetic = (
                    f"*$MACRO  {synth_branch:<5} {label:<20}"
                    f"  * {table_macro} {table_param}= (macro-generated branch)"
                )
                out.append(synthetic)
    return out


# SETTER_INST — authoritative 65-member set per SETTER_INST_COMPLETE.md audit
# (IBM z/Architecture PoO SA22-7832-12).  THIS SET MUST STAY BYTE-FOR-BYTE
# IDENTICAL to the copies in backward_traversal/glossary/instructions.py and
# process/instructions.py.  Register-destination loads (L/LR/LG/IC/ICM/LA…),
# CVB (data-flow inverted), TRT (operand unchanged), API/SPI (phantom mnemonics),
# and MVCL/MVCP/MVCS (register-indirect dest) are intentionally excluded.
SETTER_INST = {
    "AGSI", "ALGSI", "ALSI", "AP", "ASI",
    "CVD", "CVDG", "CVDY",
    "DP", "ED", "EDMK",
    "MP", "MVC", "MVCIN", "MVGHI", "MVHHI", "MVHI", "MVI", "MVIY", "MVN", "MVO", "MVZ",
    "NC", "NI", "NIY",
    "OC", "OI", "OIY",
    "PACK", "PKA", "PKU",
    "SP", "SRP", "ST", "STC", "STCK", "STCKF", "STCM", "STCMH", "STCMY",
    "STCY", "STEY", "STFLE", "STG", "STGRL", "STH", "STHRL", "STHY",
    "STM", "STMG", "STMH", "STMY", "STRL", "STRV", "STRVG", "STRVH", "STY",
    "TR", "UNPK", "UNPKA", "UNPKU",
    "XC", "XI", "XIY",
    "ZAP",
}

TRIGGER_INST = {
    "CLC", "CLI", "TM", "CP", "LTR", "C", "CR", "CH", "CL", "CLR",
    # Y-displacement forms — same condition-code semantics, 20-bit offset (z/Architecture PoP SA22-7832)
    "TMY", "CLIY", "CLM", "CLMY",
    # 64-bit comparison mnemonics (z/Architecture PoP)
    "LTGR", "CGR", "CG", "CGF",        # compare register / memory (sign-extend 32→64 for CGF)
    "CGHI", "CHI", "CFI",              # compare halfword/fullword immediate
    # Compare Logical 64-bit / immediate variants
    "CLGR", "CLG", "CLFI", "CLGFI",
    # Zero-test self-ops: OC/NC field,field sets CC=0 when all bytes are zero —
    # used as "if field == zeros" guards before cross-file calls (IBM PoO §7-226).
    # These are also in SETTER_INST; they legitimately appear in both because
    # the operation both modifies the field and sets the condition code.
    "OC", "NC",
    # GAP-CC-LOAD: Load-and-Test from memory (PoO §7-152/153).
    "LT", "LTG",
    # GAP-CC-ICM: Insert Characters under Mask (PoO §7-144) sets CC.
    "ICM",
    # GAP-CC-TRT: Translate and Test (PoO §7-228).
    "TRT",
    # GAP-CC-CLCL: Compare Logical Characters Long / Extended (PoO §7-69/70).
    "CLCL", "CLCLE",
}
BRANCH_INST = {
    # Standard HLASM conditional/unconditional branches
    "B", "BE", "BNE", "BZ", "BNZ", "BH", "BNH", "BM", "BNM", "BO", "BNO", "BP", "BNP", "BCT",
    # Raw hardware opcodes underlying the extended mnemonics above
    "BC",                             # Branch on Condition (RX X'47') — assembles all BE/BZ/etc.
    "BCTR",                           # Branch on Count to Register (RR X'06') — tight-loop decrement
    # 64-bit and index-loop branch forms (z/Architecture PoP SA22-7832)
    "BCTG",                           # Branch on Count (64-bit register)
    "BXH", "BXLE", "BXHG", "BXLEG",  # Branch on Index High/Low (32- and 64-bit)
    "BRCT", "BRCTG",                  # Branch Relative on Count (32- and 64-bit)
    "BRXH", "BRXLE",                  # Branch Relative on Index High/Low
    # Relative-branch forms — PC-relative encoding, commonly emitted by modern HLASM assemblers
    "BRC", "BRCL",                    # Branch Relative on Condition (RI / RIL forms of BC)
    # TPF/z-Architecture J-type extended branch mnemonics
    "J", "JE", "JNE", "JZ", "JNZ", "JH", "JNH", "JL", "JNL", "JM", "JNM", "JO", "JNO", "JP", "JNP",
    "JXHG", "JXLE", "JXLEG",          # JXLEG: 64-bit counterpart to JXHG
}
SUBROUTINE_INST = {"BAS", "BAL"}
CROSS_FILE_INST = {
    "ENTRC", "ENTNC", "ENTDC",          # Enter (returning, drop-prior, drop-all)
    "CREEC", "CREMC",                   # Create entry / message-controlled
    "CREDC", "CRETC", "CREXC", "CRESC", # Create deferred / time-initiated / lower-priority / synchronous
    "SWISC",                            # Switch segment
    "EXSR",                             # Execute Subroutine (legacy cross-file linkage)
    "FUNCTION",                         # Blueprint function call
    "CALLC", "CALLCPP", "CLINKC",       # C / C++ / C-link cross-language bridges
}

REGISTERS = {f"R{i}" for i in range(16)}

# For entries represented as raw arg lists (no `var` key), identify which
# operand is the write destination for setter classification.
# MUST stay byte-for-byte identical to backward_traversal/glossary/instructions.py
# and process/instructions.py (audit §2).
DEST_ARG_INDEX_BY_INST = {
    "ST": 1, "STH": 1, "STC": 1, "CVD": 1, "CVDG": 1, "CVDY": 1,
    "STM": 2, "STMG": 2, "STMH": 2, "STMY": 2,
    "STCM": 2, "STCMH": 2, "STCMY": 2,
    "STG": 1, "STY": 1, "STHY": 1, "STCY": 1, "STGRL": 1,
    "STRL": 1, "STHRL": 1, "STRV": 1, "STRVG": 1, "STRVH": 1, "STEY": 1,
}


def normalize_token(token: str) -> str:
    token = token.strip().split()[0].upper() if token.strip() else ""
    if re.match(r"^[A-Z0-9#$@_]", token):
        token = re.split(r"[+(]", token, maxsplit=1)[0]
    # GAP-024 / audit §7: include $ in the allowed boundary characters so HLASM
    # variable names that begin or end with $ (e.g. $WK_CMO, WK_CMO$) are not
    # silently truncated.  Must match backward_traversal/utils/token_utils.py.
    token = re.sub(r"^[^A-Z0-9_@$#]+|[^A-Z0-9_@$#]+$", "", token)
    return token


def looks_like_register_token(tok: str) -> bool:
    """Return True for register names (R0-R15) and out-of-range Rnn forms.

    GAP-023 / audit parity: the legacy R[A-Z] pattern was removed — names like RB,
    RC, RA, RACK, RATE are valid HLASM variable names, not registers.  Only Rnn
    (numeric suffix) forms with n > 15 are register-like out-of-range values.
    """
    u = tok.upper()
    if u in REGISTERS:
        return True
    m = re.match(r"^R(\d+)$", u)
    return bool(m) and int(m.group(1)) > 15


def is_dep_var_candidate(
    raw_arg: str,
    skip_var: str = "",
    allow_register_dependencies: bool = False,
    constant_symbols: Optional[Set[str]] = None,
) -> bool:
    """Canonical filter for dependent-variable extraction.

    Mirrors the project rules used by cross-file lineage:
    - reject literal address constants (=Y(...), =A(...), =X'...')
    - reject indexed-address bases when (...) holds a register token
    - reject register aliases unless register deps are explicitly enabled
    - reject self-defining literals/fragments (contains ')
    - reject displacement-only numeric tokens
    - reject EQU-style # constants
    - reject tokens that are not valid HLASM symbol names
    - reject the variable currently being traced (skip_var)
    - reject DC-defined constants when constant_symbols is provided
    """
    raw = str(raw_arg or "")
    if raw.startswith("="):
        return False

    paren = re.search(r"\(([^,)]+)", raw.upper())
    if paren and looks_like_register_token(paren.group(1).strip()):
        # Fix #2 (audit §5/§3e): reject only when the pre-paren portion is NOT a
        # valid HLASM symbol.  USING-based forms SYMBOL(Rn) / SYMBOL+d(Rn) carry a
        # real storage label before the base register (normalize_token strips the
        # paren suffix correctly).  Pure displacement forms 4(R3), 0(R13), (R13),
        # R13(R13) have no label and must still be rejected.
        _before = re.split(r"[+\(]", raw.upper(), maxsplit=1)[0]
        _is_symbol = (
            bool(_before)
            and not _before.isdigit()
            and not looks_like_register_token(_before)
            and bool(re.match(r"^[A-Z@$_#]", _before))
        )
        if not _is_symbol:
            return False
        # _is_symbol True: fall through to the normalize_token path below.

    tok = normalize_token(raw)
    if not tok:
        return False
    if not allow_register_dependencies and looks_like_register_token(tok):
        return False
    if "'" in tok:
        return False
    if tok.isdigit():
        return False
    if "#" in tok:
        return False
    if not re.match(r"^[A-Z@$_][A-Z0-9@$_]*$", tok):
        return False
    if skip_var and tok == skip_var.upper():
        return False
    if constant_symbols and tok in constant_symbols:
        return False
    return True


def _is_zero_literal_operand(arg: str) -> bool:
    """True for literals that resolve to zero: =P'0', =F'0', =H'0', =XL4'00…', 0."""
    a = str(arg).strip().upper().replace(" ", "")
    if a == "0":
        return True
    if re.fullmatch(r"=[PFH]'[+-]?0+'", a):
        return True
    if re.fullmatch(r"=X[L]?\d*'0+'", a):
        return True
    return False


def is_real_setter_site(inst: str, args: Iterable[str]) -> bool:
    """Return False for SETTER_INST occurrences that do NOT modify the normalized
    destination symbol (audit §3a/§3b/§3c/§3d): value-preserving self-ops, identity
    immediates, zero-literal add/subtract, zero-mask stores, and nonzero-displacement
    (SYMBOL+N) writes.  Mirrors backward_traversal special_cases.classify_setter skip
    outcomes so the /modifiers chain-finding pipeline agrees with backward lineage.
    XC FIELD,FIELD is intentionally KEPT — it zeroes the field (a real modification).
    """
    inst = (inst or "").upper()
    a = [str(x) for x in (args or [])]

    def _norm_eq(x: str, y: str) -> bool:
        nx, ny = normalize_token(x), normalize_token(y)
        return bool(nx) and nx == ny

    if len(a) >= 2:
        # self-operand no-ops / specification exceptions / unpredictable overlaps
        if inst in ("OC", "NC", "ZAP", "MP", "DP", "MVCIN") and _norm_eq(a[0], a[1]):
            return False
        # MVC FIELD,FIELD (exact raw identity) — no-op copy
        if inst == "MVC" and a[0] == a[1]:
            return False
        imm = a[1].strip().upper().replace(" ", "")
        # identity immediates: NI X'FF' (AND all-ones), OI/XI X'00' (OR/XOR zero)
        if inst == "NI" and re.fullmatch(r"X'F+'", imm):
            return False
        if inst in ("OI", "XI") and re.fullmatch(r"X'0+'", imm):
            return False
        # add/subtract zero, all-zero XC literal
        if inst in ("AP", "SP") and _is_zero_literal_operand(a[1]):
            return False
        if inst == "XC" and re.fullmatch(r"=X[L]?\d*'0+'", imm):
            return False
        # store-under-mask with a zero mask writes nothing
        if inst in ("STCM", "STCMH", "STCMY"):
            mask = a[1].strip().upper().replace(" ", "")
            if mask in ("0", "0000") or re.fullmatch(r"[BX]'0+'", mask):
                return False

    # nonzero displacement on the destination: write targets SYMBOL+N, not SYMBOL
    didx = DEST_ARG_INDEX_BY_INST.get(inst, 0)
    if didx < len(a):
        mm = re.match(r"^([A-Z@$_][A-Z0-9@$_]*)\+(\d+)", str(a[didx]).strip().upper())
        if mm and int(mm.group(2)) != 0:
            return False
    return True


def extract_symbol_from_operand(operand: str, allow_registers: bool = False) -> Optional[str]:
    raw = operand.strip()
    if not raw or is_literal(raw):
        return None

    # Capture a leading symbol (e.g., HUBACM in HUBACM+12(2)).
    match = re.match(r"^([A-Z@#$_][A-Z0-9@#$_]*)", raw, flags=re.IGNORECASE)
    if match:
        symbol = normalize_token(match.group(1))
        if symbol in REGISTERS and not allow_registers:
            return None
        return symbol or None

    # Optional: allow register dependencies (R0-R15).
    token = normalize_token(raw)
    if allow_registers and token in REGISTERS:
        return token

    return None


def is_literal(token: str) -> bool:
    t = token.strip()
    return (
        t.startswith("=")
        or t.startswith("C'")
        or t.startswith("X'")
        or t.startswith("P'")
        or t.startswith("B'")
        or t.isdigit()
    )


def parse_operands(arg_text: str) -> List[str]:
    parts = [p.strip() for p in arg_text.split(",")]
    return [p for p in parts if p]


def parse_instruction_line(line: str) -> Tuple[Optional[str], Optional[str], List[str]]:
    """Parse a raw assembler line into (label, inst, args).

    This parser is intentionally permissive to handle classic fixed-format sources.
    """
    raw = line.rstrip("\n")
    if not raw.strip():
        return None, None, []

    # *$MACRO lines are synthetic macro-branch annotations injected by
    # expand_macro_branches().  Strip the "*$MACRO " prefix so the remainder
    # ("BNZ  DA7_1820  ...") parses as a normal branch instruction.
    is_macro_branch = raw.lstrip().startswith("*$MACRO")
    if is_macro_branch:
        raw = re.sub(r"^\s*\*\$MACRO\s+", "", raw)
    elif raw.lstrip().startswith("*"):
        return None, None, []

    # Strip inline comments that start with * after at least one whitespace.
    candidate = re.split(r"\s\*", raw, maxsplit=1)[0].rstrip()
    if not candidate:
        return None, None, []

    tokens = candidate.split()
    if not tokens:
        return None, None, []

    label: Optional[str] = None
    inst: Optional[str] = None
    args: List[str] = []

    def looks_like_inst(tok: str) -> bool:
        up = tok.upper()
        return up in (
            SETTER_INST
            | TRIGGER_INST
            | BRANCH_INST
            | SUBROUTINE_INST
            | CROSS_FILE_INST
            | {
                "EQU",
                "BR",
                "GETCC",
                "LEVTA",
                "ISCFA",
                "FLIPC",
                "STM",
                "LM",
                "OC",
                "CLI",
                "CLC",
                "MVC",
                "TM",
                "CP",
                "LTR",
                "MVI",
                "PACK",
                "DATEA",
                "TIMEC",
                "ENTRC",
                "ENTNC",
                "ENTDC",
                "BAS",
                "B",
                "BE",
                "BNE",
                "BZ",
                "BH",
                "BNH",
                "BCT",
                "BM",
                "BO",
                "BNP",
            }
        )

    if len(tokens) >= 2 and not looks_like_inst(tokens[0]) and looks_like_inst(tokens[1]):
        label = normalize_token(tokens[0])
        inst = tokens[1].upper()
        tail = candidate.split(tokens[1], 1)[1].strip()
        args = parse_operands(tail) if tail else []
        return label, inst, args

    if looks_like_inst(tokens[0]):
        inst = tokens[0].upper()
        tail = candidate.split(tokens[0], 1)[1].strip()
        args = parse_operands(tail) if tail else []
        return label, inst, args

    return None, None, []


def load_asm_lines(path: Path) -> List[str]:
    return path.read_text(encoding="utf-8", errors="ignore").splitlines()


def build_label_map(asm_lines: List[str]) -> Dict[str, int]:
    label_map: Dict[str, int] = {}
    for i, line in enumerate(asm_lines, start=1):
        label, inst, _ = parse_instruction_line(line)
        if not label:
            continue
        # Common label-def forms include EQU * and instruction labels.
        if inst is not None:
            label_map[label] = i
    return label_map


@dataclass
class TraceResults:
    lineage_chain: List[Dict[str, Any]] = field(default_factory=list)
    dependent_vars: List[Dict[str, Any]] = field(default_factory=list)
    dependent_files: List[Dict[str, Any]] = field(default_factory=list)
    unresolved_files: List[Dict[str, Any]] = field(default_factory=list)
    data_quality_warnings: List[Dict[str, Any]] = field(default_factory=list)


class LineageTracer:
    def __init__(self, asm_dir: Path, blueprint_dir: Path, include_register_dependencies: bool = False):
        self.asm_dir = asm_dir
        self.blueprint_dir = blueprint_dir
        self.include_register_dependencies = include_register_dependencies
        self.visited_files: Set[str] = set()

    def trace(self, target_variable: str, source_asm_file: Path, blueprint_file: Path) -> TraceResults:
        # Top-level trace calls must be independent. Keep visited-file state scoped
        # to this invocation so multiple variables can be traced in sequence.
        self.visited_files = set()
        results = TraceResults()
        self._trace_file(
            target_variable=target_variable,
            source_asm_file=source_asm_file,
            blueprint_file=blueprint_file,
            results=results,
        )
        self._post_process(results)
        return results

    def trace_dependent_variable(
        self,
        dep_variable: str,
        usage_file: Path,
        usage_block: str,
        usage_line: int,
        blueprint_file: Path,
        primary_variable: str,
        reason: str,
        allowed_files: Optional[Set[str]] = None,
    ) -> TraceResults:
        """Trace lineage for a dependent variable starting from its usage point.

        This runs the same backward tracing algorithm as the primary variable,
        but treats the dependent variable's usage location as the 'setter' starting point.
        """
        results = TraceResults()

        if not blueprint_file.exists():
            results.unresolved_files.append(
                {
                    "file": usage_file.stem.upper(),
                    "status": "Blueprint missing - manual review required",
                }
            )
            return results

        blueprint = load_blueprint(blueprint_file)
        asm_lines = load_asm_lines(usage_file)
        asm_lines = expand_macro_branches(asm_lines)
        label_map = build_label_map(asm_lines)

        aliases = self._resolve_aliases(dep_variable, blueprint.get("meta", {}).get("aliases", []))
        match_names = {dep_variable.upper()} | aliases

        blocks = blueprint.get("blocks", [])
        block_map = {b.get("id", ""): b for b in blocks}
        blocks_in_order = sorted(blocks, key=self._block_start_line)
        root_block_id = str(blocks_in_order[0].get("id", "")) if blocks_in_order else ""

        # Find the block where the dependent variable is used
        usage_block_obj = block_map.get(usage_block)
        if not usage_block_obj:
            results.data_quality_warnings.append(
                {
                    "file": usage_file.name,
                    "block": usage_block,
                    "line": usage_line,
                    "message": f"Usage block {usage_block} not found in blueprint",
                }
            )
            return results

        # Add a synthetic "usage" entry as the starting point
        results.lineage_chain.append(
            {
                "file": usage_file.name,
                "line": usage_line,
                "block": usage_block,
                "inst": "USAGE",
                "role": "DEPENDENT_VAR_USAGE",
                "detail": f"Used as dependency of {primary_variable}: {reason}",
                "depth": 0,
            }
        )

        # Backward trace from the usage point
        visited_blocks: Set[str] = set()
        visited_block_calls: Set[str] = set()
        self._backward_trace(
            block=usage_block_obj,
            pivot_line=usage_line,
            focus_block_id=usage_block,
            focus_line=usage_line,
            depth=0,
            block_map=block_map,
            blocks_in_order=blocks_in_order,
            root_block_id=root_block_id,
            label_map=label_map,
            match_names=match_names,
            subroutines=blueprint.get("subroutines", []),
            source_asm_file=usage_file,
            asm_lines=asm_lines,
            visited_blocks=visited_blocks,
            visited_block_calls=visited_block_calls,
            results=results,
        )

        # Phase 4: Cross-file resolution for the dependent variable.
        # Uses a fresh visited_files context so this dep var's cross-file trace is
        # independent of the primary variable's trace (e.g. DA78 may have already
        # been visited for WK_RRC, but EBE01's lineage in DA78 is separate).
        saved_visited = self.visited_files
        self.visited_files = set()
        try:
            for dep in list(results.dependent_files):
                dep_name = str(dep.get("file", "")).strip().lower()
                if not dep_name:
                    continue
                if allowed_files and dep_name not in allowed_files:
                    continue
                dep_asm = self.asm_dir / f"{dep_name}.asm"
                dep_blueprint = self.blueprint_dir / f"{dep_name}.asm.json"
                asm_exists = dep_asm.exists()
                bp_exists = dep_blueprint.exists()
                calling_file = dep.get("calling_file", "")
                caller_cid = (
                    f"{calling_file}:{dep.get('called_from_block', '')}:{dep.get('line', 0)}"
                    if calling_file else None
                )
                if asm_exists and bp_exists:
                    inbound = dep.get("target") if dep.get("type") == "INBOUND_ENTRY" else None
                    effective_cid = None if inbound else caller_cid
                    self._trace_file(
                        dep_variable, dep_asm, dep_blueprint, results,
                        caller_chunk_id=effective_cid,
                        inbound_target=inbound,
                    )
                elif asm_exists and not bp_exists:
                    results.unresolved_files.append({"file": dep_name.upper(), "status": "Blueprint missing - manual review required"})
                elif bp_exists and not asm_exists:
                    results.unresolved_files.append({"file": dep_name.upper(), "status": "ASM file missing - manual review required"})
                else:
                    results.unresolved_files.append({"file": dep_name.upper(), "status": "ASM + Blueprint missing - manual review required"})
        finally:
            self.visited_files = saved_visited

        # Post-process and return (but do NOT trace dependencies of dependencies)
        self._post_process(results)
        return results

    def trace_from_call_site(
        self,
        source_asm_file: Path,
        blueprint_file: Path,
        call_block_id: str,
        call_line: int,
        call_instruction: str,
        call_detail: str,
    ) -> TraceResults:
        """Backward-trace from a cross-file call site to find its guard conditions.

        Instead of starting from a variable setter, starts from a known call
        instruction (ENTRC/ENTNC/FUNCTION/ENTDC) at *call_line* in *call_block_id*
        and walks backward to find what trigger+branch conditions route execution
        to that call.

        Returns a TraceResults whose lineage_chain starts with the CALL_SITE anchor
        followed by all triggers, branches, and cross-file calls that precede it.
        dependent_vars contains all variables found in those trigger comparisons.
        """
        results = TraceResults()

        if not blueprint_file.exists():
            results.unresolved_files.append({
                "file": source_asm_file.stem.upper(),
                "status": "Blueprint missing - manual review required",
            })
            return results

        blueprint = load_blueprint(blueprint_file)
        asm_lines = load_asm_lines(source_asm_file)
        asm_lines = expand_macro_branches(asm_lines)
        label_map = build_label_map(asm_lines)

        blocks = blueprint.get("blocks", [])
        block_map = {b.get("id", ""): b for b in blocks}
        blocks_in_order = sorted(blocks, key=self._block_start_line)

        # Sentinel match_names: won't match any real variable, so _backward_trace
        # emits no SETTER entries — but all TRIGGER, BRANCH, CROSS_FILE_CALL and
        # SUBROUTINE_CALL entries are captured normally.  The sentinel also ensures
        # next(iter(match_names)) never raises StopIteration.
        sentinel_names: Set[str] = {"__CALL_SITE__"}

        # Anchor: the call site itself is the starting point of the lineage chain.
        results.lineage_chain.append({
            "file": source_asm_file.name,
            "line": call_line,
            "block": call_block_id,
            "inst": call_instruction,
            "role": "CALL_SITE",
            "detail": call_detail,
            "depth": 0,
        })

        # Locate the block (case-insensitive fallback).
        block = block_map.get(call_block_id)
        if block is None:
            for bid, b in block_map.items():
                if bid.upper() == call_block_id.upper():
                    block = b
                    call_block_id = bid
                    break

        if block is None:
            results.data_quality_warnings.append({
                "file": source_asm_file.name,
                "block": call_block_id,
                "line": call_line,
                "message": f"Block '{call_block_id}' not found in blueprint",
            })
            return results

        visited_blocks: Set[str] = set()
        visited_block_calls: Set[str] = set()

        self._backward_trace(
            block=block,
            pivot_line=call_line,
            focus_block_id=call_block_id,
            focus_line=call_line,
            depth=0,
            block_map=block_map,
            blocks_in_order=blocks_in_order,
            root_block_id=str(blocks_in_order[0].get("id", "")) if blocks_in_order else "",
            label_map=label_map,
            match_names=sentinel_names,
            subroutines=blueprint.get("subroutines", []),
            source_asm_file=source_asm_file,
            asm_lines=asm_lines,
            visited_blocks=visited_blocks,
            visited_block_calls=visited_block_calls,
            results=results,
        )

        self._post_process(results)
        return results

    def _trace_file(
        self,
        target_variable: str,
        source_asm_file: Path,
        blueprint_file: Path,
        results: TraceResults,
        caller_chunk_id: Optional[str] = None,
        inbound_target: Optional[str] = None,
    ) -> None:
        file_key = str(source_asm_file.resolve())
        if file_key in self.visited_files:
            return
        self.visited_files.add(file_key)
        chain_len_before = len(results.lineage_chain)

        if not blueprint_file.exists():
            results.unresolved_files.append(
                {
                    "file": source_asm_file.stem.upper(),
                    "status": "Blueprint missing - manual review required",
                }
            )
            return

        blueprint = load_blueprint(blueprint_file)
        asm_lines = load_asm_lines(source_asm_file)
        # Expand macro-encoded conditional branches into synthetic *$MACRO lines
        # in memory only - the original file is never written.
        asm_lines = expand_macro_branches(asm_lines)
        label_map = build_label_map(asm_lines)

        aliases = self._resolve_aliases(target_variable, blueprint.get("meta", {}).get("aliases", []))
        match_names = {target_variable.upper()} | aliases

        blocks = blueprint.get("blocks", [])
        block_map = {b.get("id", ""): b for b in blocks}
        blocks_in_order = sorted(blocks, key=self._block_start_line)
        root_block_id = str(blocks_in_order[0].get("id", "")) if blocks_in_order else ""

        work_queue: List[Dict[str, Any]] = []

        # Phase 1: Find setters.
        for block in blocks:
            block_id = block.get("id", "UNKNOWN")
            for entry in iter_flow(block):
                inst = str(entry.get("inst", "")).upper()
                if inst not in SETTER_INST:
                    continue
                if not self._entry_touches_match(entry, match_names):
                    continue
                results.lineage_chain.append(
                    {
                        "file": source_asm_file.name,
                        "line": entry.get("line"),
                        "block": block_id,
                        "inst": inst,
                        "role": "SETTER",
                        "detail": self._entry_detail(entry),
                        "depth": 0,
                    }
                )
                work_queue.append({"block": block, "setter_line": int(entry.get("line", 0))})

        # Phase 1.5 (inbound callers only): record the ENTNC/ENTRC call site that
        # jumps INTO the target file's entry point.  This becomes a CROSS_FILE_CALL
        # node in this (inbound caller) file, and build_lineage_graph Step 4.6 will
        # wire the target file's entry-point root to it.
        if inbound_target:
            inbound_target_up = inbound_target.upper()
            for block in blocks:
                block_id = block.get("id", "UNKNOWN")
                for entry in iter_flow(block):
                    inst = str(entry.get("inst", "")).upper()
                    if inst not in CROSS_FILE_INST:
                        continue
                    args = entry.get("args") or []
                    if not args:
                        continue
                    if str(args[0]).strip().upper() != inbound_target_up:
                        continue
                    results.lineage_chain.append(
                        {
                            "file": source_asm_file.name,
                            "line": entry.get("line"),
                            "block": block_id,
                            "inst": inst,
                            "role": "CROSS_FILE_CALL",
                            "args": [inbound_target],
                            "detail": f"{inst} {inbound_target} (inbound entry caller)",
                            "depth": 0,
                            # Step 4.6 uses this to wire the entry-point root in the
                            # target file as a child of this node.
                            "_inbound_entry_call": {
                                "caller_file": source_asm_file.stem,
                                "entry": inbound_target,
                            },
                        }
                    )

        # Phase 2: backward trace per setter instance.
        visited_block_calls: Set[str] = set()
        for work in work_queue:
            block = work["block"]
            setter_line = work["setter_line"]
            visited_blocks: Set[str] = set()
            self._backward_trace(
                block=block,
                pivot_line=setter_line,
                focus_block_id=block.get("id", ""),
                focus_line=setter_line,
                depth=0,
                block_map=block_map,
                blocks_in_order=blocks_in_order,
                root_block_id=root_block_id,
                label_map=label_map,
                match_names=match_names,
                subroutines=blueprint.get("subroutines", []),
                source_asm_file=source_asm_file,
                asm_lines=asm_lines,
                visited_blocks=visited_blocks,
                visited_block_calls=visited_block_calls,
                results=results,
            )

        # Phase 2.5: Inbound entry-point caller discovery.
        # For the PRIMARY file only (caller_chunk_id is None, inbound_target is None):
        # find entry-dispatch blocks
        # that appear in this file's lineage and have no internal incoming edges — meaning
        # they can only be reached from outside (a different segment calling ENTNC/ENTRC
        # to this block name).  Scan asm_dir for any file containing such a call and add
        # it as an INBOUND_ENTRY dependent so Phase 4 traces it.
        if caller_chunk_id is None and inbound_target is None and self.asm_dir and self.blueprint_dir:
            entry_dispatch = _find_entry_dispatch_blocks(blueprint)
            lineage_blocks = {
                entry.get("block", "")
                for entry in results.lineage_chain[chain_len_before:]
                if entry.get("file") == source_asm_file.name
            }
            already_queued = {
                str(d.get("file", "")).strip().lower()
                for d in results.dependent_files
            }
            for entry_name in entry_dispatch & lineage_blocks:
                entry_up = entry_name.upper()
                pattern = re.compile(
                    rf'\b(?:ENTNC|ENTRC|ENTDC)\s+{re.escape(entry_up)}\b',
                    re.IGNORECASE,
                )
                for asm_path in self.asm_dir.glob("*.asm"):
                    stem = asm_path.stem.lower()
                    if stem == source_asm_file.stem.lower():
                        continue
                    if str(asm_path.resolve()) in self.visited_files:
                        continue
                    if stem in already_queued:
                        continue
                    try:
                        content = asm_path.read_text(encoding="utf-8", errors="ignore")
                    except Exception:
                        continue
                    if pattern.search(content):
                        results.dependent_files.append(
                            {
                                "file": stem,
                                "calling_file": source_asm_file.stem,
                                "target": entry_name,
                                "type": "INBOUND_ENTRY",
                            }
                        )
                        already_queued.add(stem)

        # Mark ALL nodes added by this file's trace with their cross-file call parent.
        # build_lineage_graph Step 4.5 uses this to wire root nodes (parent_chunk_id=None)
        # of the cross-file sub-graph as children of the CROSS_FILE_CALL anchor in the
        # calling file. Non-root nodes already get parents from within the sub-graph and
        # the field is discarded.
        if caller_chunk_id:
            for entry in results.lineage_chain[chain_len_before:]:
                entry["_cross_file_parent"] = caller_chunk_id

        # Phase 4: Cross-file resolution.
        for dep in list(results.dependent_files):
            dep_name = str(dep.get("file", "")).strip().lower()
            if not dep_name:
                continue
            dep_asm = self.asm_dir / f"{dep_name}.asm"
            dep_blueprint = self.blueprint_dir / f"{dep_name}.asm.json"
            asm_exists = dep_asm.exists()
            bp_exists = dep_blueprint.exists()
            calling_file = dep.get("calling_file", "")
            caller_cid = (
                f"{calling_file}:{dep.get('called_from_block', '')}:{dep.get('line', 0)}"
                if calling_file else None
            )
            if asm_exists and bp_exists:
                inbound = dep.get("target") if dep.get("type") == "INBOUND_ENTRY" else None
                # For INBOUND_ENTRY: caller_chunk_id must be None — wiring is handled
                # by build_lineage_graph Step 4.6, not by the _cross_file_parent mechanism.
                effective_cid = None if inbound else caller_cid
                self._trace_file(
                    target_variable, dep_asm, dep_blueprint, results,
                    caller_chunk_id=effective_cid,
                    inbound_target=inbound,
                )
            elif asm_exists and not bp_exists:
                results.unresolved_files.append(
                    {
                        "file": dep_name.upper(),
                        "status": "Blueprint missing - manual review required",
                    }
                )
            elif bp_exists and not asm_exists:
                results.unresolved_files.append(
                    {
                        "file": dep_name.upper(),
                        "status": "ASM file missing - manual review required",
                    }
                )
            else:
                # CPP pass-through: dep_name has no .asm/.asm.json but may be a
                # CPP intermediary with a .cpp.json blueprint whose call_graph
                # edges point to downstream ASM callees we should still trace.
                cpp_bp_path = self.blueprint_dir / f"{dep_name}.cpp.json"
                if cpp_bp_path.exists():
                    try:
                        cpp_bp = load_blueprint(cpp_bp_path)
                        # Build dedup set from current dependent_files — already_queued
                        # may be uninitialized when Phase 2.5 was skipped.
                        _cpp_queued = {
                            str(d.get("file", "")).strip().lower()
                            for d in results.dependent_files
                        }
                        for cg_edge in (cpp_bp.get("call_graph") or {}).get("edges", []):
                            callee = str(cg_edge.get("target", "")).strip().lower()
                            if not callee or callee in _cpp_queued:
                                continue
                            callee_asm = self.asm_dir / f"{callee}.asm"
                            callee_bp = self.blueprint_dir / f"{callee}.asm.json"
                            if callee_asm.exists() and callee_bp.exists():
                                _cpp_queued.add(callee)
                                results.dependent_files.append(
                                    {
                                        "file": callee,
                                        "calling_file": dep_name,
                                        "called_from_block": dep.get("called_from_block", ""),
                                        "line": dep.get("line", 0),
                                        "type": "CPP_PASSTHROUGH",
                                    }
                                )
                                # Direct trace: Phase 4 snapshot was taken before this
                                # append, so CPP_PASSTHROUGH entries are never iterated
                                # by Phase 4's loop — call _trace_file immediately here.
                                #
                                # Resolve the variable through the CPP function's own
                                # lineage before entering the downstream ASM trace.
                                # Example: CE1CR0 → regs.r2 → arg@AI71:R2 → "R2".
                                # Falls back to target_variable when no mapping found.
                                _cpp_resolved = self._resolve_cpp_passthrough_variable(
                                    target_variable, cpp_bp, callee
                                )
                                self._trace_file(
                                    _cpp_resolved, callee_asm, callee_bp, results,
                                    caller_chunk_id=None,
                                    inbound_target=None,
                                )
                        results.unresolved_files.append(
                            {
                                "file": dep_name.upper(),
                                "status": "CPP pass-through - downstream ASM callees enqueued",
                            }
                        )
                    except Exception:
                        results.unresolved_files.append(
                            {
                                "file": dep_name.upper(),
                                "status": "ASM + Blueprint missing - manual review required",
                            }
                        )
                else:
                    results.unresolved_files.append(
                        {
                            "file": dep_name.upper(),
                            "status": "ASM + Blueprint missing - manual review required",
                        }
                    )

        # Phase 4c: ECB-slot co-owner discovery.
        # Scans all .asm.json blueprints for files that share a CE1CR slot with the
        # current file. Files with no direct call edge between them can still share
        # state via ECB slots — this phase discovers them and traces them directly.
        # Only run at top-level (not in recursive calls) to avoid corpus-wide scans
        # on every recursive _trace_file invocation.
        if caller_chunk_id is None and inbound_target is None:
            import re as _re
            _ecb_slots: set = set()
            for _node in (blueprint.get("variable_lineage") or {}).get("nodes", []):
                _nm = str(_node.get("name", ""))
                if _re.match(r"^CE1CR[0-9A-F]$", _nm, _re.IGNORECASE):
                    _ecb_slots.add(_nm.upper())
            if _ecb_slots:
                _ecb_traced = {
                    str(d.get("file", "")).strip().lower()
                    for d in results.dependent_files
                }
                _ecb_traced.add(source_asm_file.stem.lower())
                for _co_bp_path in self.blueprint_dir.glob("*.asm.json"):
                    _co_base = _co_bp_path.name[: -len(".asm.json")]
                    if _co_base in _ecb_traced:
                        continue
                    try:
                        _raw = _co_bp_path.read_text(errors="ignore")
                    except OSError:
                        continue
                    if not any(_slot in _raw for _slot in _ecb_slots):
                        continue
                    try:
                        _co_bp = load_blueprint(_co_bp_path)
                    except Exception:
                        continue
                    _co_node_names = {
                        str(_n.get("name", ""))
                        for _n in (_co_bp.get("variable_lineage") or {}).get("nodes", [])
                    }
                    if not (_ecb_slots & _co_node_names):
                        continue
                    _co_asm = self.asm_dir / f"{_co_base}.asm"
                    if not _co_asm.exists():
                        continue
                    _ecb_traced.add(_co_base)
                    results.dependent_files.append(
                        {
                            "file": _co_base,
                            "calling_file": source_asm_file.stem,
                            "called_from_block": "",
                            "line": 0,
                            "type": "ECB_SLOT_COOP",
                        }
                    )
                    self._trace_file(
                        target_variable, _co_asm, _co_bp_path, results,
                        caller_chunk_id=None,
                        inbound_target=None,
                    )

    def _resolve_cpp_passthrough_variable(
        self,
        target_variable: str,
        cpp_bp: Dict[str, Any],
        callee: str,
    ) -> str:
        """Resolve target_variable through a CPP blueprint to find the register
        that is passed to `callee`.

        Walks the CPP blueprint's variable_lineage forward from any node whose
        name ends with ``::target_variable`` (or equals it), following assign /
        use / alias edges, until it reaches a ``register:arg@CALLEE:RN`` node.
        Returns the register name (e.g. ``"R2"``) so the downstream ASM trace
        starts from the correct variable.

        Falls back to the original ``target_variable`` when no mapping is found,
        preserving the existing (unchanged) behaviour.
        """
        vl = cpp_bp.get("variable_lineage") or {}
        edges = vl.get("edges", [])
        nodes = vl.get("nodes", [])

        tv_upper = target_variable.upper()
        callee_upper = callee.upper()

        # Build forward adjacency: source_id → [target_id]
        forward: Dict[str, list] = {}
        for edge in edges:
            if edge.get("relation") in ("assign", "use", "alias"):
                src = str(edge.get("source", ""))
                tgt = str(edge.get("target", ""))
                if src and tgt and src != tgt:
                    forward.setdefault(src, []).append(tgt)

        # Find start nodes whose name matches target_variable:
        #   - exact match: "CE1CR0"
        #   - scoped match: "callLogging::ce1cr0" (ends with "::CE1CR0")
        #   - field match:  "regs.ce1cr0"         (ends with ".CE1CR0")
        start_ids: set = set()
        for n in nodes:
            name_upper = str(n.get("name", "")).upper()
            if (
                name_upper == tv_upper
                or name_upper.endswith("::" + tv_upper)
                or name_upper.endswith("." + tv_upper)
            ):
                start_ids.add(str(n.get("id", "")))

        if not start_ids:
            return target_variable

        # BFS forward; stop on the first arg@CALLEE:RN node found.
        visited: set = set(start_ids)
        queue: list = list(start_ids)
        while queue:
            curr = queue.pop(0)
            for nxt in forward.get(curr, []):
                nxt_upper = nxt.upper()
                # Matches "register:arg@CALLEE:RN" (kind may also be "parameter")
                if f"ARG@{callee_upper}:R" in nxt_upper:
                    reg = nxt.split(":")[-1]  # last segment, e.g. "R2"
                    if reg.upper().startswith("R") and reg[1:].isdigit():
                        return reg
                if nxt not in visited:
                    visited.add(nxt)
                    queue.append(nxt)

        return target_variable  # fallback: trace downstream ASM with unchanged name

    def _resolve_aliases(self, target_variable: str, aliases: Iterable[Dict[str, Any]]) -> Set[str]:
        target = target_variable.upper()
        out: Set[str] = set()
        for alias in aliases:
            name = str(alias.get("name", "")).upper()
            mapped = str(alias.get("target", "")).upper()
            if not name and not mapped:
                continue
            if name == target:
                out.add(mapped)
            if mapped == target:
                out.add(name)
        return {v for v in out if v}

    def _entry_touches_match(self, entry: Dict[str, Any], match_names: Set[str]) -> bool:
        def operand_matches_target(operand: str) -> bool:
            up = str(operand).strip().upper()
            if not up:
                return False
            if normalize_token(up) in match_names:
                return True
            for m in match_names:
                if up == m or up.startswith(m + "+") or up.startswith(m + "("):
                    return True
            return False

        # Blueprint flow entries with `var` / `val` structure represent writes to
        # operand-1 (`var`) and reads from operand-2 (`val`). For setter
        # classification, only destination (`var`) is valid.
        if "var" in entry:
            return operand_matches_target(str(entry.get("var", "")))

        # Fallback for entries that only expose raw argument lists.
        inst = str(entry.get("inst", "")).upper()
        args = entry.get("args", []) or []
        if isinstance(args, str):
            args = [args]
        if not args:
            return False
        dest_idx = DEST_ARG_INDEX_BY_INST.get(inst, 0)
        if dest_idx >= len(args):
            return False
        return operand_matches_target(str(args[dest_idx]))

    def _entry_detail(self, entry: Dict[str, Any]) -> str:
        if "var" in entry and "val" in entry:
            return f"{entry['var']} = {entry['val']}"
        args = entry.get("args", [])
        return ", ".join(args) if isinstance(args, list) else str(args)

    def _classify_branch(
        self,
        branch_entry: Dict[str, Any],
        focus_block_id: str,
        focus_line: int,
        label_map: Dict[str, int],
        block_map: Optional[Dict[str, Dict[str, Any]]] = None,
    ) -> str:
        branch_line = int(branch_entry.get("line", 0))
        args = branch_entry.get("args", []) or []
        # Branch target is always the last operand (handles single-arg branches like
        # J/B/JE/BE as well as multi-operand forms like BCT R1,Lbl and JXHG R1,R3,Lbl).
        target = normalize_token(str(args[-1])) if args else ""
        target_line = label_map.get(target)

        if branch_line > focus_line:
            return "IRRELEVANT"

        if target == focus_block_id:
            return "BRANCH_TO_SETTER"

        if target_line is not None:
            if block_map and focus_block_id in block_map and self._line_in_block(target_line, block_map[focus_block_id]):
                return "BRANCH_TO_SETTER"
            if target_line == focus_line:
                return "BRANCH_TO_SETTER"

        if branch_line < focus_line:
            return "GUARD_BRANCH"

        return "IRRELEVANT"

    def _record_trigger_dependencies(
        self,
        trigger_entry: Dict[str, Any],
        block_id: str,
        target_variable: str,
        reason: str,
        results: TraceResults,
    ) -> None:
        args = trigger_entry.get("args", []) or []
        for operand in args:
            if not is_dep_var_candidate(
                str(operand),
                skip_var=target_variable,
                allow_register_dependencies=self.include_register_dependencies,
            ):
                continue
            token = extract_symbol_from_operand(
                str(operand),
                allow_registers=self.include_register_dependencies,
            )
            if not token or token == target_variable.upper():
                continue
            results.dependent_vars.append(
                {
                    "variable": token,
                    "block": block_id,
                    "line": trigger_entry.get("line"),
                    "reason": reason,
                }
            )

    def _scan_subroutine(
        self,
        sub_id: str,
        start_line: int,
        end_line: int,
        match_names: Set[str],
        source_asm_file: Path,
        asm_lines: List[str],
        results: TraceResults,
        label_map: Optional[Dict[str, int]] = None,
    ) -> None:
        if start_line <= 0 or end_line <= 0 or end_line < start_line:
            return

        # Walk the expanded asm lines, tracking real source line numbers.
        # Synthetic *$MACRO lines inherit the real line number of their parent.
        sub_entries: List[Dict[str, Any]] = []
        current_real = 0
        for raw_line in asm_lines:
            is_synthetic = raw_line.lstrip().startswith("*$MACRO")
            if not is_synthetic:
                current_real += 1
            if current_real < start_line:
                continue
            if current_real > end_line:
                break
            _, inst, args = parse_instruction_line(raw_line)
            if not inst:
                continue
            entry: Dict[str, Any] = {"line": current_real, "inst": inst, "args": args}
            if is_synthetic:
                entry["is_macro_branch"] = True
            sub_entries.append(entry)

        setter_lines = [
            e["line"]
            for e in sub_entries
            if e["inst"] in SETTER_INST and self._entry_touches_match(e, match_names)
        ]

        for idx, entry in enumerate(sub_entries):
            inst = entry["inst"]
            args = entry.get("args", [])

            touches_target = self._entry_touches_match(entry, match_names)

            # Record synthetic macro-branch entries found within subroutine scope.
            if entry.get("is_macro_branch") and inst in BRANCH_INST:
                results.lineage_chain.append(
                    {
                        "file": source_asm_file.name,
                        "line": entry["line"],
                        "block": sub_id,
                        "inst": inst,
                        "args": args,
                        "role": "MACRO_BRANCH",
                        "detail": ", ".join(args),
                        "note": "macro-generated conditional branch",
                        "depth": 0,
                    }
                )
                continue

            if inst in SETTER_INST and touches_target:
                results.lineage_chain.append(
                    {
                        "file": source_asm_file.name,
                        "line": entry["line"],
                        "block": sub_id,
                        "inst": inst,
                        "role": "SETTER_IN_SUB",
                        "detail": ", ".join(args),
                        "depth": 0,
                    }
                )

            if inst in TRIGGER_INST:
                condition_type = "DIRECT"
                if idx + 1 < len(sub_entries) and sub_entries[idx + 1]["inst"] in BRANCH_INST:
                    branch_role = self._classify_branch(
                        sub_entries[idx + 1],
                        focus_block_id=sub_id,
                        focus_line=entry["line"],
                        label_map=label_map or {},
                        block_map=None,
                    )
                    if branch_role == "GUARD_BRANCH":
                        condition_type = "INVERSE"

                for setter_line in setter_lines:
                    if setter_line <= entry["line"]:
                        continue
                    reason = (
                        f"Subroutine condition at line {entry['line']} may control setter at line {setter_line} "
                        f"via {'GUARD_BRANCH (inverse)' if condition_type == 'INVERSE' else 'BRANCH_TO_SETTER'}"
                    )
                    self._record_trigger_dependencies(
                        trigger_entry=entry,
                        block_id=sub_id,
                        target_variable=next(iter(match_names)),
                        reason=reason,
                        results=results,
                    )

                results.lineage_chain.append(
                    {
                        "file": source_asm_file.name,
                        "line": entry["line"],
                        "block": sub_id,
                        "inst": inst,
                        "role": "TRIGGER",
                        "condition_type": condition_type,
                        "detail": ", ".join(args),
                        "depth": 0,
                    }
                )

            if inst in CROSS_FILE_INST and args:
                dep_file = normalize_token(str(args[0]))
                results.dependent_files.append(
                    {
                        "file": dep_file,
                        "called_from_block": sub_id,
                        "line": entry["line"],
                        "type": "NO_RETURN" if inst in ("ENTNC", "ENTDC") else "RETURN",
                        "calling_file": source_asm_file.stem,
                    }
                )
                # Also record the CROSS_FILE_CALL node so caller_cid is valid in Step 4.5
                results.lineage_chain.append(
                    {
                        "file": source_asm_file.name,
                        "line": entry["line"],
                        "block": sub_id,
                        "inst": inst,
                        "args": args,
                        "role": "CROSS_FILE_CALL",
                        "detail": dep_file,
                        "depth": 0,
                    }
                )

    def _block_start_line(self, block: Dict[str, Any]) -> int:
        flow = list(iter_flow(block))
        lines = [int(e.get("line", 0)) for e in flow if int(e.get("line", 0)) > 0]
        return min(lines) if lines else 10**9

    def _block_end_line(self, block: Dict[str, Any]) -> int:
        flow = list(iter_flow(block))
        lines = [int(e.get("line", 0)) for e in flow if int(e.get("line", 0)) > 0]
        return max(lines) if lines else 0

    def _line_in_block(self, line_no: int, block: Dict[str, Any]) -> bool:
        if line_no <= 0:
            return False
        start = self._block_start_line(block)
        end = self._block_end_line(block)
        return start <= line_no <= end

    def _is_unconditional_terminal(self, block: Dict[str, Any]) -> bool:
        flow = list(iter_flow(block))
        if not flow:
            return False
        last = max(flow, key=lambda e: int(e.get("line", 0)))
        inst = str(last.get("inst", "")).upper()
        if inst in {"B", "ENTNC", "ENTDC", "EXITC"}:
            return True
        if inst == "BR":
            args = last.get("args", []) or []
            if args and normalize_token(str(args[0])) == "R14":
                return True
            return True
        return False

    def _next_sequential_block(
        self,
        block_id: str,
        blocks_in_order: List[Dict[str, Any]],
        block_map: Dict[str, Dict[str, Any]],
    ) -> Optional[Dict[str, Any]]:
        cur = block_map.get(block_id)
        if not cur or self._is_unconditional_terminal(cur):
            return None
        for idx, b in enumerate(blocks_in_order):
            if str(b.get("id", "")) != block_id:
                continue
            if idx + 1 < len(blocks_in_order):
                return blocks_in_order[idx + 1]
            return None
        return None

    def _collect_cross_file_calls(
        self,
        block: Dict[str, Any],
        source_asm_file: Path,
        results: TraceResults,
        visited_block_calls: Set[str],
        depth: int,
        subroutines: Optional[List[Dict[str, Any]]] = None,
        match_names: Optional[Set[str]] = None,
        asm_lines: Optional[List[str]] = None,
        label_map: Optional[Dict[str, int]] = None,
    ) -> None:
        block_id = str(block.get("id", "UNKNOWN"))
        if block_id in visited_block_calls:
            return
        visited_block_calls.add(block_id)

        for entry in iter_flow(block):
            inst = str(entry.get("inst", "")).upper()
            args = entry.get("args", []) or []

            if inst in CROSS_FILE_INST and args:
                dep_file = normalize_token(str(args[0]))
                results.dependent_files.append(
                    {
                        "file": dep_file,
                        "called_from_block": block_id,
                        "line": int(entry.get("line", 0)),
                        "type": "NO_RETURN" if inst in ("ENTNC", "ENTDC") else "RETURN",
                        "calling_file": source_asm_file.stem,
                    }
                )
                results.lineage_chain.append(
                    {
                        "file": source_asm_file.name,
                        "line": int(entry.get("line", 0)),
                        "block": block_id,
                        "inst": inst,
                        "args": args,
                        "role": "CROSS_FILE_CALL",
                        "detail": ", ".join(args),
                        "depth": depth,
                    }
                )

            # Sweep BAS subroutine calls so macro-branch entries inside
            # subroutines are surfaced even when the backward scan pivot
            # prevents the BAS handler from firing (e.g. sequential fall-through).
            if inst in SUBROUTINE_INST and len(args) >= 2 and subroutines and match_names and asm_lines is not None:
                callee = normalize_token(str(args[1]))
                for sub in subroutines:
                    if str(sub.get("id", "")).upper() == callee:
                        self._scan_subroutine(
                            sub_id=callee,
                            start_line=int(sub.get("start_line", 0)),
                            end_line=int(sub.get("end_line", 0)),
                            match_names=match_names,
                            source_asm_file=source_asm_file,
                            asm_lines=asm_lines,
                            results=results,
                            label_map=label_map,
                        )
                        break

    def _record_data_quality_warning(
        self,
        block_id: str,
        line: int,
        message: str,
        source_asm_file: Path,
        results: TraceResults,
    ) -> None:
        results.data_quality_warnings.append(
            {
                "file": source_asm_file.name,
                "block": block_id,
                "line": line,
                "message": message,
            }
        )

    def _backward_trace(
        self,
        block: Dict[str, Any],
        pivot_line: int,
        focus_block_id: str,
        focus_line: int,
        depth: int,
        block_map: Dict[str, Dict[str, Any]],
        blocks_in_order: List[Dict[str, Any]],
        root_block_id: str,
        label_map: Dict[str, int],
        match_names: Set[str],
        subroutines: List[Dict[str, Any]],
        source_asm_file: Path,
        asm_lines: List[str],
        visited_blocks: Set[str],
        visited_block_calls: Set[str],
        results: TraceResults,
        skip_cross_file_discovery: bool = False,
    ) -> None:
        block_id = block.get("id", "UNKNOWN")
        if block_id in visited_blocks:
            return
        visited_blocks.add(block_id)

        # [UPD-DA78-1] Block-level cross-file call sweep (once per visited block).
        # Skipped when tracing backward through subroutine-caller context so that
        # cross-file calls in the caller (e.g. ENTNC in DA7_0100) don't interfere
        # with the primary file's cross-file discovery and visited_files state.
        if not skip_cross_file_discovery:
            self._collect_cross_file_calls(
                block=block,
                source_asm_file=source_asm_file,
                results=results,
                visited_block_calls=visited_block_calls,
                depth=depth,
                subroutines=subroutines,
                match_names=match_names,
                asm_lines=asm_lines,
                label_map=label_map,
            )

        flow = list(iter_flow(block))
        block_start = self._block_start_line(block)
        block_end = self._block_end_line(block)

        # Collect any *$MACRO synthetic branch entries within this block's line
        # range from the expanded asm_lines list.  These are not in the blueprint
        # flow, so we inject them here as synthetic flow entries.
        # Strategy: walk the expanded list, track the "current real source line"
        # by counting non-synthetic lines, and emit a macro_entry whenever a
        # *$MACRO line is found whose parent real line falls inside this block.
        macro_entries: List[Dict[str, Any]] = []
        if block_start > 0 and block_end > 0:
            current_real_lineno = 0
            for raw_line in asm_lines:
                if raw_line.lstrip().startswith("*$MACRO"):
                    # Synthetic line - attribute it to the preceding real line.
                    if block_start <= current_real_lineno <= block_end:
                        _, m_inst, m_args = parse_instruction_line(raw_line)
                        if m_inst and m_inst.upper() in BRANCH_INST:
                            macro_entries.append(
                                {
                                    "line": current_real_lineno,
                                    "inst": m_inst.upper(),
                                    "args": m_args,
                                    "is_macro_branch": True,
                                }
                            )
                else:
                    current_real_lineno += 1

        # Merge macro entries into the flow scan list, sorted by line.
        combined_flow = sorted(
            list(flow) + macro_entries,
            key=lambda e: int(e.get("line", 0)),
        )

        # Full-block macro sweep: record any macro branch that targets a known
        # setter block, regardless of pivot. These are independent paths to a
        # setter that may sit at any line position in the block.
        setter_block_ids = {
            r.get("block")
            for r in results.lineage_chain
            if r.get("role") == "SETTER"
        }
        for me in macro_entries:
            m_args = me.get("args", []) or []
            m_target = normalize_token(str(m_args[0])) if m_args else ""
            m_target_line = label_map.get(m_target)
            is_to_setter_block = (
                m_target in setter_block_ids
                or (
                    m_target_line is not None
                    and any(
                        self._line_in_block(m_target_line, block_map[bid])
                        for bid in setter_block_ids
                        if bid in block_map
                    )
                )
            )
            if is_to_setter_block:
                results.lineage_chain.append(
                    {
                        "file": source_asm_file.name,
                        "line": me["line"],
                        "block": block_id,
                        "inst": me["inst"],
                        "args": m_args,
                        "role": "MACRO_BRANCH",
                        "detail": ", ".join(m_args),
                        "note": "macro-generated conditional branch",
                        "depth": depth,
                    }
                )

        # Scan backward above pivot line
        for idx in range(len(combined_flow) - 1, -1, -1):
            entry = combined_flow[idx]
            line = int(entry.get("line", 0))
            if line >= pivot_line:
                continue

            inst = str(entry.get("inst", "")).upper()
            args = entry.get("args", []) or []

            if inst in BRANCH_INST:
                role = self._classify_branch(entry, focus_block_id, focus_line, label_map, block_map)
                if role == "IRRELEVANT":
                    continue

                # Synthetic macro-branch entries get a distinct role label.
                if entry.get("is_macro_branch"):
                    role = "MACRO_BRANCH"
                detail = ", ".join(args)
                note = "Setter runs when this branch does NOT fire" if role == "GUARD_BRANCH" else ""
                if entry.get("is_macro_branch"):
                    note = "macro-generated conditional branch"
                rec = {
                    "file": source_asm_file.name,
                    "line": line,
                    "block": block_id,
                    "inst": inst,
                    "args": args,
                    "role": role,
                    "detail": detail,
                    "depth": depth,
                }
                if note:
                    rec["note"] = note
                results.lineage_chain.append(rec)
                continue

            if inst in TRIGGER_INST:
                next_entry = combined_flow[idx + 1] if (idx + 1) < len(combined_flow) else None
                condition_type = "DIRECT"
                trigger_note = ""
                if next_entry and str(next_entry.get("inst", "")).upper() in BRANCH_INST:
                    branch_role = self._classify_branch(next_entry, focus_block_id, focus_line, label_map, block_map)
                    if branch_role == "GUARD_BRANCH":
                        condition_type = "INVERSE"
                else:
                    trigger_note = "No immediate branch; condition codes may be consumed later."

                reason = (
                    f"Condition at line {line} controls path to line {focus_line} "
                    f"via {'GUARD_BRANCH (inverse)' if condition_type == 'INVERSE' else 'BRANCH_TO_SETTER'}"
                )
                self._record_trigger_dependencies(
                    trigger_entry=entry,
                    block_id=block_id,
                    target_variable=next(iter(match_names)),
                    reason=reason,
                    results=results,
                )

                trig_rec = {
                    "file": source_asm_file.name,
                    "line": line,
                    "block": block_id,
                    "inst": inst,
                    "args": args,
                    "role": "TRIGGER",
                    "condition_type": condition_type,
                    "detail": ", ".join(args),
                    "depth": depth,
                }
                if trigger_note:
                    trig_rec["note"] = trigger_note
                results.lineage_chain.append(trig_rec)
                continue

            if inst in SUBROUTINE_INST and len(args) >= 2:
                callee = normalize_token(str(args[1]))
                # Subroutine callees are code labels, not data variables — do NOT add
                # to dependent_vars.  The call is already captured as a SUBROUTINE_CALL
                # node in the lineage chain below.

                results.lineage_chain.append(
                    {
                        "file": source_asm_file.name,
                        "line": line,
                        "block": block_id,
                        "inst": inst,
                        "args": args,
                        "role": "SUBROUTINE_CALL",
                        "detail": ", ".join(args),
                        "depth": depth,
                    }
                )

                for sub in subroutines:
                    if str(sub.get("id", "")).upper() == callee:
                        self._scan_subroutine(
                            sub_id=callee,
                            start_line=int(sub.get("start_line", 0)),
                            end_line=int(sub.get("end_line", 0)),
                            match_names=match_names,
                            source_asm_file=source_asm_file,
                            asm_lines=asm_lines,
                            results=results,
                            label_map=label_map,
                        )
                        break
                continue

            if inst in CROSS_FILE_INST and args:
                dep_file = normalize_token(str(args[0]))
                results.dependent_files.append(
                    {
                        "file": dep_file,
                        "called_from_block": block_id,
                        "line": line,
                        "type": "NO_RETURN" if inst in ("ENTNC", "ENTDC") else "RETURN",
                        "calling_file": source_asm_file.stem,
                    }
                )
                results.lineage_chain.append(
                    {
                        "file": source_asm_file.name,
                        "line": line,
                        "block": block_id,
                        "inst": inst,
                        "args": args,
                        "role": "CROSS_FILE_CALL",
                        "detail": ", ".join(args),
                        "depth": depth,
                    }
                )
                # Rule 6: stop at no-return instructions (ENTNC, ENTDC, EXITC).
                # ENTRC/CALLC return to the next line — earlier guards still apply.
                if inst in ("ENTNC", "ENTDC", "EXITC"):
                    break

        # Move to parent blocks (incoming branches)
        incoming = block.get("incoming_branches", []) or []

        # Fallback: if the blueprint has no incoming_branches for this block (e.g.
        # because the blueprint was generated before J/JXHG were recognised as
        # branch instructions), scan all other blocks' flow for any BRANCH_INST that
        # targets this block.  This keeps the tracer correct against stale blueprints.
        if not incoming and block_id != root_block_id:
            block_start = self._block_start_line(block)
            block_end   = self._block_end_line(block)
            seen_sources: Set[str] = set()
            for src_id, src_block in block_map.items():
                if src_id == block_id or src_id in seen_sources:
                    continue
                for cand in iter_flow(src_block):
                    cinst = str(cand.get("inst", "")).upper()
                    if cinst not in BRANCH_INST:
                        continue
                    cargs = cand.get("args", []) or []
                    ctgt = normalize_token(str(cargs[-1])) if cargs else ""
                    ctgt_line = label_map.get(ctgt)
                    if ctgt == block_id or (
                        ctgt_line is not None
                        and block_start > 0
                        and block_start <= ctgt_line <= block_end
                    ):
                        incoming.append({"source": src_id, "type": "BRANCH"})
                        seen_sources.add(src_id)
                        break

        for parent_ref in incoming:
            parent_id = parent_ref.get("source")
            branch_type = parent_ref.get("type", "BRANCH")  # default to BRANCH if not specified

            if not parent_id:
                continue
            parent_block = block_map.get(parent_id)
            if not parent_block:
                if parent_id not in visited_blocks:
                    self._record_data_quality_warning(
                        block_id=block_id,
                        line=int(pivot_line),
                        message=f"incoming_branches references missing parent block: {parent_id}",
                        source_asm_file=source_asm_file,
                        results=results,
                    )
                continue

            # Handle FALLTHROUGH edges (implicit control flow)
            # Always record the bridge node so build_lineage_graph can wire the
            # connection — even if the parent block was already visited (e.g. it
            # contains its own setter for the same variable).  Only skip the
            # recursive descent when already visited, to prevent cycles.
            if branch_type == "FALLTHROUGH":
                # For fall-through, use the last line of the parent block as the pivot
                parent_flow = list(iter_flow(parent_block))
                last_line = max((int(e.get("line", 0)) for e in parent_flow), default=pivot_line)

                # Record the fall-through bridge node unconditionally
                results.lineage_chain.append(
                    {
                        "file": source_asm_file.name,
                        "line": last_line,
                        "block": parent_id,
                        "inst": "(fall-through)",
                        "args": [block_id],
                        "role": "FALLTHROUGH_ENTRY",
                        "detail": f"Sequential fall-through to {block_id}",
                        "depth": depth + 1,
                    }
                )

                if parent_id not in visited_blocks:
                    self._backward_trace(
                        block=parent_block,
                        pivot_line=last_line,
                        focus_block_id=block_id,
                        focus_line=last_line,
                        depth=depth + 1,
                        block_map=block_map,
                        blocks_in_order=blocks_in_order,
                        root_block_id=root_block_id,
                        label_map=label_map,
                        match_names=match_names,
                        subroutines=subroutines,
                        source_asm_file=source_asm_file,
                        asm_lines=asm_lines,
                        visited_blocks=visited_blocks,
                        visited_block_calls=visited_block_calls,
                        results=results,
                    )
                continue  # Skip to next incoming branch

            if parent_id in visited_blocks:
                continue

            # Handle SUBROUTINE_CALL edges (BAS/BAL callers)
            if branch_type == "SUBROUTINE_CALL":
                # Find the BAS/BAL instruction in the parent block that calls block_id
                parent_flow = list(iter_flow(parent_block))
                call_entry: Optional[Dict[str, Any]] = None
                for candidate in parent_flow:
                    inst = str(candidate.get("inst", "")).upper()
                    if inst not in SUBROUTINE_INST:
                        continue
                    args = candidate.get("args", []) or []
                    target = normalize_token(str(args[1])) if len(args) >= 2 else ""
                    if target == block_id:
                        call_entry = candidate
                        break

                next_pivot = int(call_entry.get("line", 0)) if call_entry else max(1, int(pivot_line))
                if call_entry:
                    results.lineage_chain.append(
                        {
                            "file": source_asm_file.name,
                            "line": call_entry.get("line"),
                            "block": parent_id,
                            "inst": call_entry.get("inst"),
                            "args": call_entry.get("args", []),
                            "role": "SUBROUTINE_CALL",
                            "detail": f"Subroutine call to {block_id}",
                            "depth": depth + 1,
                        }
                    )

                self._backward_trace(
                    block=parent_block,
                    pivot_line=next_pivot,
                    focus_block_id=block_id,
                    focus_line=next_pivot,
                    depth=depth + 1,
                    block_map=block_map,
                    blocks_in_order=blocks_in_order,
                    root_block_id=root_block_id,
                    label_map=label_map,
                    match_names=match_names,
                    subroutines=subroutines,
                    source_asm_file=source_asm_file,
                    asm_lines=asm_lines,
                    visited_blocks=visited_blocks,
                    visited_block_calls=visited_block_calls,
                    results=results,
                    skip_cross_file_discovery=True,
                )
                continue  # Skip to next incoming branch

            # Handle explicit BRANCH edges
            parent_flow = list(iter_flow(parent_block))
            branch_entry: Optional[Dict[str, Any]] = None
            for candidate in parent_flow:
                inst = str(candidate.get("inst", "")).upper()
                if inst not in BRANCH_INST:
                    continue
                args = candidate.get("args", []) or []
                # Branch target is the last operand (covers J/B single-arg and
                # multi-operand forms like BCT R1,Lbl or JXHG R1,R3,Lbl).
                target = normalize_token(str(args[-1])) if args else ""
                target_line = label_map.get(target)
                if target == block_id or (target_line is not None and self._line_in_block(target_line, block)):
                    branch_entry = candidate
                    break

            next_pivot = int(branch_entry.get("line", 0)) if branch_entry else max(1, int(pivot_line))
            if branch_entry:
                results.lineage_chain.append(
                    {
                        "file": source_asm_file.name,
                        "line": branch_entry.get("line"),
                        "block": parent_id,
                        "inst": branch_entry.get("inst"),
                        "args": branch_entry.get("args", []),
                        "role": "BRANCH_ENTRY",
                        "detail": self._entry_detail(branch_entry),
                        "depth": depth + 1,
                    }
                )

            self._backward_trace(
                block=parent_block,
                pivot_line=next_pivot,
                focus_block_id=block_id,
                focus_line=next_pivot,
                depth=depth + 1,
                block_map=block_map,
                blocks_in_order=blocks_in_order,
                root_block_id=root_block_id,
                label_map=label_map,
                match_names=match_names,
                subroutines=subroutines,
                source_asm_file=source_asm_file,
                asm_lines=asm_lines,
                visited_blocks=visited_blocks,
                visited_block_calls=visited_block_calls,
                results=results,
            )

        # [UPD-DA76-BP-1] Blueprint is authoritative; warn when no parent links exist.
        if not incoming and block_id != root_block_id:
            self._record_data_quality_warning(
                block_id=block_id,
                line=int(pivot_line),
                message="No incoming_branches found for non-root reachable block (blueprint completeness issue)",
                source_asm_file=source_asm_file,
                results=results,
            )

    def _post_process(self, results: TraceResults) -> None:
        def dedupe(items: List[Dict[str, Any]], key_fn):
            seen = set()
            out = []
            for item in items:
                k = key_fn(item)
                if k in seen:
                    continue
                seen.add(k)
                out.append(item)
            return out

        role_priority = {
            "DEPENDENT_VAR_USAGE": 110,  # synthetic entry must survive dedup at the usage line
            "SETTER": 100,
            "SETTER_IN_SUB": 95,
            "TRIGGER": 90,
            "GUARD_BRANCH": 85,
            "BRANCH_TO_SETTER": 80,
            "BRANCH_ENTRY": 75,
            "FALLTHROUGH_ENTRY": 73,
            "MACRO_BRANCH": 70,
            "SUBROUTINE_CALL": 60,
            "CROSS_FILE_CALL": 76,  # beats FALLTHROUGH_ENTRY: actual instruction > synthetic edge marker
        }

        best_by_key: Dict[Tuple, Dict[str, Any]] = {}
        for row in results.lineage_chain:
            # FALLTHROUGH_ENTRY nodes are synthetic edges to a specific target block.
            # Include the target in their dedup key so they don't collide with
            # BRANCH_ENTRY / GUARD_BRANCH nodes at the same line that branch to a
            # different target (e.g. BZ DA7_9100 at line 121 vs fall-through to DA7_0100).
            _role = str(row.get("role", ""))
            _args = row.get("args", []) or []
            if _role == "FALLTHROUGH_ENTRY" and _args:
                key = (row.get("file"), row.get("line"), row.get("block"), _args[0])
            else:
                key = (row.get("file"), row.get("line"), row.get("block"), "")
            existing = best_by_key.get(key)
            if existing is None:
                best_by_key[key] = row
                continue

            existing_score = (
                role_priority.get(str(existing.get("role", "")), 0),
                -int(existing.get("depth", 0) or 0),
            )
            candidate_score = (
                role_priority.get(str(row.get("role", "")), 0),
                -int(row.get("depth", 0) or 0),
            )
            if candidate_score > existing_score:
                best_by_key[key] = row

        results.lineage_chain = sorted(
            best_by_key.values(),
            key=lambda x: (int(x.get("line", 0)), str(x.get("file", ""))),
        )

        filtered_dep_vars = []
        for row in results.dependent_vars:
            var = str(row.get("variable", "")).strip()
            if not is_dep_var_candidate(
                var,
                allow_register_dependencies=self.include_register_dependencies,
            ):
                continue
            if normalize_token(var) != var:
                row = {**row, "variable": normalize_token(var)}
            filtered_dep_vars.append(row)

        results.dependent_vars = sorted(
            dedupe(
                filtered_dep_vars,
                lambda x: (x.get("variable"), x.get("block"), x.get("line"), x.get("reason")),
            ),
            key=lambda x: (x.get("variable", ""), int(x.get("line", 0))),
        )

        results.dependent_files = sorted(
            dedupe(
                results.dependent_files,
                lambda x: (x.get("file"), x.get("called_from_block"), x.get("line"), x.get("type")),
            ),
            key=lambda x: (x.get("file", ""), int(x.get("line", 0))),
        )

        results.unresolved_files = dedupe(
            results.unresolved_files,
            lambda x: (x.get("file"), x.get("status")),
        )

        results.data_quality_warnings = dedupe(
            results.data_quality_warnings,
            lambda x: (x.get("file"), x.get("block"), x.get("line"), x.get("message")),
        )


def format_results(target_variable: str, source_asm_file: Path, results: TraceResults) -> str:
    file_line_cache: Dict[str, List[str]] = {}

    def get_source_line(file_name: str, line_no: int) -> str:
        if line_no <= 0:
            return ""
        try:
            if file_name not in file_line_cache:
                resolved = (source_asm_file.parent / file_name).resolve()
                if resolved.exists():
                    file_line_cache[file_name] = resolved.read_text(encoding="utf-8", errors="ignore").splitlines()
                else:
                    file_line_cache[file_name] = []
            lines = file_line_cache[file_name]
            if 1 <= line_no <= len(lines):
                return lines[line_no - 1].rstrip()
        except (OSError, UnicodeDecodeError, IndexError, ValueError):
            return ""
        return ""

    def _source_inst_matches(raw_line: str, expected_inst: str) -> bool:
        """Return True when the instruction parsed from *raw_line* matches
        *expected_inst*.

        This guard prevents the detail column from showing the wrong source
        text when the blueprint's stored line number for an entry is offset
        from the real instruction (e.g. ENTRC/BAS/TM at consecutive lines
        sharing the same blueprint line number after deduplication).
        """
        if not raw_line or not expected_inst:
            return False
        # Strip the leading label (if any) before comparing.
        stripped = raw_line.lstrip()
        # Comment lines can never match an instruction.
        if stripped.startswith("*"):
            return False
        tokens = raw_line.split()
        if not tokens:
            return False
        # Determine the instruction token: if col-0 is non-space the first
        # token is a label and the second (if present) is the instruction.
        if raw_line[0] != " " and len(tokens) >= 2:
            candidate = tokens[1].upper()
        else:
            candidate = tokens[0].upper()
        return candidate == expected_inst.strip().upper()

    lines: List[str] = []

    lines.append(f"LINEAGE CHAIN for {target_variable.upper()} in {source_asm_file.name}")
    lines.append("=" * 86)
    block_col_width = 20
    lines.append("Depth  File      Line  Block                Inst    Role                 Detail")
    lines.append("-----  --------- ----- -------------------- ------- -------------------- ------------------------------")

    for row in results.lineage_chain:
        depth = str(row.get("depth", 0)).rjust(2)
        file_ = str(row.get("file", ""))[:9].ljust(9)
        line = str(row.get("line", "")).rjust(5)
        row_file = str(row.get("file", ""))
        file_stem = Path(row_file).stem if row_file else ""
        block_label = f"{file_stem}:{row.get('block', '')}" if file_stem else str(row.get("block", ""))
        block = block_label[:block_col_width].ljust(block_col_width)
        row_inst = str(row.get("inst", ""))
        inst = row_inst[:7].ljust(7)
        role = str(row.get("role", ""))[:20].ljust(20)
        row_line = int(row.get("line", 0) or 0)
        raw_src = get_source_line(row_file, row_line)
        # Only use the raw source text when its leading instruction token
        # actually matches the row's instruction.  If the blueprint line
        # number is slightly off (e.g. consecutive ENTRC/TM/BAS lines that
        # share a line number after post-process deduplication), fall back to
        # the detail string that was captured at emit time so the Inst and
        # Detail columns stay consistent with each other.
        if raw_src and _source_inst_matches(raw_src, row_inst):
            detail = raw_src
        else:
            detail = str(row.get("detail", "")) or raw_src
        if row.get("condition_type"):
            detail = f"[{row['condition_type']}] {detail}".strip()
        if row.get("note"):
            detail = f"{detail} ({row['note']})".strip()
        lines.append(f"{depth}   {file_} {line}  {block} {inst} {role} {detail}")

    lines.append("")
    lines.append(f"DEPENDENT VARIABLES for {target_variable.upper()} in {source_asm_file.name}")
    lines.append("=" * 86)
    lines.append("Variable         Block           Line  Reason")
    lines.append("---------------  --------------  ----- -----------------------------------------------")
    for row in results.dependent_vars:
        lines.append(
            f"{str(row.get('variable', ''))[:16].ljust(16)}  "
            f"{str(row.get('block', ''))[:15].ljust(15)}  "
            f"{str(row.get('line', '')).rjust(5)}  "
            f"{row.get('reason', '')}"
        )

    lines.append("")
    lines.append(f"DEPENDENT FILES for {target_variable.upper()} in {source_asm_file.name}")
    lines.append("=" * 86)
    lines.append("File   Called From Block  Line  Type      Status")
    lines.append("------ ----------------- ----- --------- ----------------------------------------------")
    unresolved_lookup = {x.get("file"): x.get("status") for x in results.unresolved_files}
    for row in results.dependent_files:
        dep_file = str(row.get("file", ""))
        status = unresolved_lookup.get(dep_file.upper(), "")
        lines.append(
            f"{dep_file[:6].ljust(6)}  "
            f"{str(row.get('called_from_block', ''))[:17].ljust(17)}  "
            f"{str(row.get('line', '')).rjust(5)}  "
            f"{str(row.get('type', ''))[:9].ljust(9)}  "
            f"{status}"
        )

    if results.unresolved_files:
        lines.append("")
        lines.append("UNRESOLVED FILES")
        lines.append("=" * 86)
        for row in results.unresolved_files:
            lines.append(f"- {row.get('file')}: {row.get('status')}")

    if results.data_quality_warnings:
        lines.append("")
        lines.append("DATA QUALITY WARNINGS")
        lines.append("=" * 86)
        for row in results.data_quality_warnings:
            lines.append(
                f"- {row.get('file')}:{row.get('line')} [{row.get('block')}] {row.get('message')}"
            )

    return "\n".join(lines)


def format_dependent_variable_lineage(
    dep_variable: str,
    primary_variable: str,
    usage_file: Path,
    usage_block: str,
    usage_line: int,
    reason: str,
    results: TraceResults,
) -> str:
    """Format the lineage report for a single dependent variable."""
    file_line_cache: Dict[str, List[str]] = {}

    def get_detail(row: Dict[str, Any]) -> str:
        detail = str(row.get("detail", ""))
        if detail:
            return detail
        # Fallback: read source line if available
        file_name = str(row.get("file", ""))
        line = int(row.get("line", 0))
        inst = str(row.get("inst", ""))
        if not file_name or not line or not inst:
            return ""
        try:
            if file_name not in file_line_cache:
                file_path = usage_file.parent / file_name
                if file_path.exists():
                    file_line_cache[file_name] = file_path.read_text(encoding="utf-8").splitlines()
                else:
                    return ""
            lines_array = file_line_cache[file_name]
            if 0 < line <= len(lines_array):
                source_line = lines_array[line - 1]
                source_inst = source_line.split()[0] if source_line.split() else ""
                if normalize_token(source_inst) == normalize_token(inst):
                    return source_line.strip()
        except (OSError, UnicodeDecodeError, IndexError, ValueError):
            pass
        return ""

    lines = []
    lines.append("")
    lines.append(f"DEPENDENT VARIABLE LINEAGE for {dep_variable.upper()}")
    lines.append("=" * 86)
    lines.append(f"Primary Variable: {primary_variable.upper()}")
    lines.append(f"Used At: {usage_file.name}:{usage_line} ({usage_block})")
    lines.append(f"Reason: {reason}")
    lines.append("")
    lines.append("Depth  File      Line  Block                Inst    Role                 Detail")
    lines.append("-----  --------- ----- -------------------- ------- -------------------- ------------------------------")

    for row in results.lineage_chain:
        depth = int(row.get("depth", 0))
        file = str(row.get("file", ""))
        line = str(row.get("line", ""))
        block_raw = str(row.get("block", ""))
        inst = str(row.get("inst", ""))
        role = str(row.get("role", ""))
        detail = get_detail(row)
        note = row.get("note", "")
        if note:
            detail = f"{detail} ({note})"

        lines.append(
            f"{str(depth).rjust(5)}  "
            f"{file[:9].ljust(9)}  "
            f"{line.rjust(5)}  "
            f"{block_raw[:20].ljust(20)}  "
            f"{inst[:7].ljust(7)}  "
            f"{role[:20].ljust(20)}  "
            f"{detail}"
        )

    if results.dependent_vars:
        lines.append("")
        lines.append(f"DEPENDENT VARIABLES for {dep_variable.upper()} in {usage_file.name}")
        lines.append("=" * 86)
        lines.append("Variable         Block           Line  Reason")
        lines.append("---------------  --------------  ----- -----------------------------------------------")
        for row in results.dependent_vars:
            lines.append(
                f"{str(row.get('variable', ''))[:16].ljust(16)}  "
                f"{str(row.get('block', ''))[:15].ljust(15)}  "
                f"{str(row.get('line', '')).rjust(5)}  "
                f"{row.get('reason', '')}"
            )

    if results.dependent_files:
        lines.append("")
        lines.append(f"DEPENDENT FILES for {dep_variable.upper()} in {usage_file.name}")
        lines.append("=" * 86)
        lines.append("File   Called From Block  Line  Type      Status")
        lines.append("------ ----------------- ----- --------- ----------------------------------------------")
        unresolved_lookup = {x.get("file"): x.get("status") for x in results.unresolved_files}
        for row in results.dependent_files:
            dep_file = str(row.get("file", ""))
            status = unresolved_lookup.get(dep_file.upper(), "")
            lines.append(
                f"{dep_file[:6].ljust(6)}  "
                f"{str(row.get('called_from_block', ''))[:17].ljust(17)}  "
                f"{str(row.get('line', '')).rjust(5)}  "
                f"{str(row.get('type', ''))[:9].ljust(9)}  "
                f"{status}"
            )

    if results.data_quality_warnings:
        lines.append("")
        lines.append(f"DATA QUALITY WARNINGS for {dep_variable.upper()}")
        lines.append("=" * 86)
        for row in results.data_quality_warnings:
            lines.append(
                f"- {row.get('file')}:{row.get('line')} [{row.get('block')}] {row.get('message')}"
            )

    return "\n".join(lines)


def _find_entry_dispatch_blocks(blueprint: Dict[str, Any]) -> Set[str]:
    """Return block IDs that are externally-callable entry-dispatch blocks.

    An entry dispatch block has:
    - No internal incoming_branches (i.e., no edge from within the same file leads to it)
    - Exactly one meaningful flow item: an unconditional B to a processing block
      (e.g.,  DA76  B  DA760000   or   DA7G  B  DA7G0000)

    These blocks can only be reached from OUTSIDE the segment (via ENTRC/ENTNC from
    another file), so if one appears in the backward trace it means an external caller
    fed execution into this segment at that entry point.
    """
    entry_dispatch: Set[str] = set()
    for block in blueprint.get("blocks", []):
        # No internal incoming edges means externally entered only
        if block.get("incoming_branches"):
            continue
        flow = [
            f for f in iter_flow(block)
            if str(f.get("inst", "")).upper() not in {
                "EQU", "DC", "DS", "USING", "DROP", "LTORG", "EJECT", "SPACE",
            }
        ]
        if len(flow) == 1 and str(flow[0].get("inst", "")).upper() == "B":
            entry_dispatch.add(str(block.get("id", "")))
    return entry_dispatch


def _enrich_scope(
    node: Dict[str, Any],
    line_meta: Dict[str, Any],
    subroutine_ids: Set[str],
) -> None:
    """Attach a scope object to node in-place.

    scope fields:
      csect      — Control Section (CSECT directive name, e.g. "$IS$")
      routine    — enclosing labeled section when it is NOT a BAS-called subroutine
      subroutine — enclosing labeled section when it IS a BAS-called subroutine
      block      — basic block id (mirrors node.block)
    """
    meta = line_meta.get(str(node.get("line", "")), {})
    codeblock = meta.get("codeblock", {})
    csect = codeblock.get("enclosing_section") or None
    enclosing = codeblock.get("enclosing_routine") or str(node.get("block", ""))
    is_sub = enclosing in subroutine_ids
    node["scope"] = {
        "csect": csect,
        "routine": None if is_sub else enclosing,
        "subroutine": enclosing if is_sub else None,
        "block": str(node.get("block", "")),
    }


def build_lineage_graph(
    target_variable: str,
    source_asm_file: Path,
    results: TraceResults,
    dep_var_traces: Optional[List[Tuple[str, str, int, str, "TraceResults", int, str]]] = None,
    blueprint_file: Optional[Path] = None,
    blueprint_dir: Optional[Path] = None,
    asm_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """Build a DAG-ready JSON structure from a flat TraceResults lineage_chain.

    Each entry in results.lineage_chain becomes a graph node with:
      - chunk_id          unique node identifier "{file_stem}:{block}:{line}"
      - parent_chunk_id   chunk_id of the predecessor node (None for roots)
      - edge_to_parent    description of the edge type (SEQUENTIAL / BRANCH / FALLTHROUGH)

    When dep_var_traces is provided (list of
      (var_name, usage_block, usage_line, reason, TraceResults, trace_id, parent_anchor_id)),
    each dep var's lineage is merged in as a child subtree of parent_anchor_id.
    Dep var chunk_ids use ":DEP:{VAR}#{trace_id}" suffix — trace_id is a monotonic
    integer assigned per trace invocation, guaranteeing uniqueness even when the same
    variable is traced from multiple usage points or at multiple nesting levels.

    The algorithm:
      1. Assign chunk_id to every primary entry.
      2. Group entries by block and sort by line within each block.
      3. Scan for bridge entries to build cross-block bridge map.
      4. Wire parent_chunk_id for primary nodes.
      5. Inject dep var nodes (if provided), wiring DEPENDENT_VAR_USAGE → primary anchor.
      6. DFS from all roots for readable execution-flow ordering.
    """
    from collections import defaultdict

    chain: List[Dict[str, Any]] = results.lineage_chain

    # Pre-load source files so each node can carry the raw ASM line.
    # Searches source_asm_file.parent first, then asm_dir (for cross-file nodes).
    _src_cache: Dict[str, List[str]] = {}
    _search_dirs = [source_asm_file.parent]
    if asm_dir and asm_dir != source_asm_file.parent:
        _search_dirs.append(asm_dir)

    def _get_source_line(file_name: str, line_no: int) -> str:
        if line_no <= 0:
            return ""
        if file_name not in _src_cache:
            _src_cache[file_name] = []
            for search_dir in _search_dirs:
                candidate = search_dir / file_name
                if candidate.exists():
                    try:
                        _src_cache[file_name] = candidate.read_text(encoding="utf-8", errors="ignore").splitlines()
                    except OSError:
                        pass
                    break
        lines = _src_cache[file_name]
        return lines[line_no - 1].rstrip() if 1 <= line_no <= len(lines) else ""

    # Per-file scope metadata cache: file_name → (line_meta, subroutine_ids).
    # Loaded lazily so cross-file nodes get the right blueprint's data.
    _scope_cache: Dict[str, Tuple[Dict[str, Any], Set[str]]] = {}

    def _get_scope_meta(file_name: str) -> Tuple[Dict[str, Any], Set[str]]:
        if file_name in _scope_cache:
            return _scope_cache[file_name]
        stem = Path(file_name).stem
        bp_path: Optional[Path] = None
        if blueprint_file and stem.lower() == source_asm_file.stem.lower():
            bp_path = blueprint_file
        elif blueprint_dir:
            candidate = blueprint_dir / f"{stem}.asm.json"
            if candidate.exists():
                bp_path = candidate
        if bp_path and bp_path.exists():
            try:
                bp = load_blueprint(bp_path)
                lm: Dict[str, Any] = bp.get("line_metadata", {})
                si: Set[str] = {str(s.get("id", "")) for s in bp.get("subroutines", [])}
            except Exception:
                lm, si = {}, set()
        else:
            lm, si = {}, set()
        _scope_cache[file_name] = (lm, si)
        return lm, si

    # Step 1 – assign chunk_id, source_line, and scope on a shallow copy so we don't mutate TraceResults.
    nodes: List[Dict[str, Any]] = []
    for entry in chain:
        node = dict(entry)
        file_stem = Path(str(node.get("file", ""))).stem
        block = str(node.get("block", ""))
        line = node.get("line", 0)
        node["chunk_id"] = f"{file_stem}:{block}:{line}"
        node["source_line"] = _get_source_line(str(node.get("file", "")), int(line))
        _lm, _si = _get_scope_meta(str(node.get("file", "")))
        _enrich_scope(node, _lm, _si)
        nodes.append(node)

    # Step 2 – group by (file_stem, block), sort by line.
    # Keyed by (file_stem, block) — NOT bare block — to prevent collisions when
    # two different files share a block label (e.g. both have "$IS$" or "DA7_1000").
    blocks_entries: Dict[tuple, List[Dict[str, Any]]] = defaultdict(list)
    for node in nodes:
        file_stem = Path(str(node.get("file", ""))).stem
        blocks_entries[(file_stem, str(node.get("block", "")))].append(node)
    for key in blocks_entries:
        blocks_entries[key].sort(key=lambda n: int(n.get("line", 0)))

    # Step 3 – build bridge map: (file_stem, child_block_id) → (bridge_chunk_id, role, inst, args, parent_block)
    # All roles that define a cross-block edge via args[0] as the target block:
    #   BRANCH_ENTRY, FALLTHROUGH_ENTRY — normal forward branches / fall-throughs
    #   GUARD_BRANCH, MACRO_BRANCH     — conditional branches to error/alternate paths
    #   BRANCH_TO_SETTER               — branch that directly targets a setter block
    # Walk nodes in line order so the first (earliest) bridge wins when multiple
    # parent blocks branch to the same child.
    # Keyed by (file_stem, target_block) so bridges from da76 never wire da78 blocks.
    _BRIDGE_ROLES = {
        "BRANCH_ENTRY",
        "FALLTHROUGH_ENTRY",
        "GUARD_BRANCH",
        "MACRO_BRANCH",
        "BRANCH_TO_SETTER",
        "SUBROUTINE_CALL",
    }
    _BRIDGE_ROLE_PRIORITY = {
        "GUARD_BRANCH": 85,
        "BRANCH_TO_SETTER": 80,
        "BRANCH_ENTRY": 75,
        "FALLTHROUGH_ENTRY": 73,
        "MACRO_BRANCH": 70,
        "SUBROUTINE_CALL": 65,  # lower than branches — secondary inbound path
    }
    child_to_bridge: Dict[tuple, tuple] = {}
    # secondary_bridges: SUBROUTINE_CALL nodes whose target already has a primary bridge.
    # These get wired as children of their target block's first node (SHARED_INBOUND_CALL).
    secondary_bridges: List[tuple] = []  # (node_chunk_id, target, file_stem)

    for node in sorted(nodes, key=lambda n: int(n.get("line", 0))):
        role = str(node.get("role", ""))
        if role not in _BRIDGE_ROLES:
            continue
        args = node.get("args", []) or []
        if not args:
            continue
        # BAS/BAL: target is args[1] (args[0] is the return-address register).
        # BRANCH_ENTRY/GUARD_BRANCH: target is the last operand — handles both
        # single-arg branches (J/B → args[0]) and multi-arg forms (BCT R1,Lbl → args[-1],
        # JXHG R1,R3,Lbl → args[-1]).
        if role == "SUBROUTINE_CALL":
            target = normalize_token(str(args[1])) if len(args) >= 2 else ""
        else:
            target = normalize_token(str(args[-1]))
        node_file_stem = Path(str(node.get("file", ""))).stem
        key = (node_file_stem, target)
        if not target:
            continue
        candidate = (
            node["chunk_id"],
            role,
            str(node.get("inst", "")),
            args,
            str(node.get("block", "")),
        )
        if key not in child_to_bridge:
            child_to_bridge[key] = candidate
        else:
            existing_role = child_to_bridge[key][1]
            if _BRIDGE_ROLE_PRIORITY.get(role, 0) > _BRIDGE_ROLE_PRIORITY.get(existing_role, 0):
                # Current candidate beats the existing bridge — demote existing to secondary
                secondary_bridges.append((child_to_bridge[key][0], target, node_file_stem))
                child_to_bridge[key] = candidate
            else:
                # This candidate loses — queue as secondary inbound (all roles, not just SUBROUTINE_CALL)
                secondary_bridges.append((node["chunk_id"], target, node_file_stem))

    # Step 3.5 – deduplicate blocks_entries by chunk_id within each block.
    # When two nodes share the same (file, block, line) — e.g. a BRANCH_ENTRY and a
    # synthetic FALLTHROUGH_ENTRY both land on the block's last line — they get the
    # same chunk_id.  Keeping both causes the second node in the sorted list to receive
    # `parent_chunk_id = its_own_chunk_id` (a self-loop) in Step 4.
    # The bridge map was already built above from all nodes, so FALLTHROUGH bridges are
    # preserved.  Here we keep only the highest-priority role per chunk_id.
    for key in blocks_entries:
        entries = blocks_entries[key]
        best: Dict[str, Dict[str, Any]] = {}
        for n in entries:
            cid = n["chunk_id"]
            if cid not in best:
                best[cid] = n
            else:
                existing_priority = _BRIDGE_ROLE_PRIORITY.get(str(best[cid].get("role", "")), 50)
                candidate_priority = _BRIDGE_ROLE_PRIORITY.get(str(n.get("role", "")), 50)
                if candidate_priority > existing_priority:
                    best[cid] = n
        blocks_entries[key] = sorted(best.values(), key=lambda n: int(n.get("line", 0)))

    # Step 4 – assign parent_chunk_id and edge_to_parent.
    for (key_file, blk), entries in blocks_entries.items():
        for i, node in enumerate(entries):
            if i > 0:
                node["parent_chunk_id"] = entries[i - 1]["chunk_id"]
                node["edge_to_parent"] = {
                    "type": "SEQUENTIAL",
                    "description": "Sequential execution",
                }
            else:
                bridge = child_to_bridge.get((key_file, blk))
                if bridge:
                    bridge_cid, bridge_role, bridge_inst, _, parent_blk = bridge
                    node["parent_chunk_id"] = bridge_cid
                    if bridge_role == "FALLTHROUGH_ENTRY":
                        node["edge_to_parent"] = {
                            "type": "FALLTHROUGH",
                            "description": f"Fall-through from {parent_blk} to {blk}",
                        }
                    elif bridge_role == "GUARD_BRANCH":
                        node["edge_to_parent"] = {
                            "type": "GUARD_BRANCH",
                            "inst": bridge_inst,
                            "target_block": blk,
                            "description": f"Guard branch {bridge_inst} taken to {blk}",
                        }
                    elif bridge_role == "MACRO_BRANCH":
                        node["edge_to_parent"] = {
                            "type": "MACRO_BRANCH",
                            "inst": bridge_inst,
                            "target_block": blk,
                            "description": f"Macro-generated branch {bridge_inst} to {blk}",
                        }
                    elif bridge_role == "BRANCH_TO_SETTER":
                        node["edge_to_parent"] = {
                            "type": "BRANCH_TO_SETTER",
                            "inst": bridge_inst,
                            "target_block": blk,
                            "description": f"Branch {bridge_inst} directly to setter block {blk}",
                        }
                    else:
                        node["edge_to_parent"] = {
                            "type": "BRANCH",
                            "inst": bridge_inst,
                            "target_block": blk,
                            "description": f"Branch via {bridge_inst} to {blk}",
                        }
                else:
                    node["parent_chunk_id"] = None
                    node["edge_to_parent"] = None

    # Step 4.4 – wire secondary SUBROUTINE_CALL bridges.
    # When multiple callers reach the same block (e.g. BAS from DA7_0100 and
    # FALLTHROUGH from DA7_0640 both lead to DA7_1000), the primary bridge already
    # parented DA7_1000's first node.  Wire each secondary BAS caller node as a
    # child of its target block's first node so it appears in the graph.
    node_by_id_tmp = {n["chunk_id"]: n for n in nodes}
    for (caller_cid, target_blk, target_file_stem) in secondary_bridges:
        caller_node = node_by_id_tmp.get(caller_cid)
        if caller_node is None or caller_node.get("parent_chunk_id") is not None:
            continue
        # Find first node of the target block in the same file
        target_first = next(
            (n for n in nodes
             if str(n.get("block", "")) == target_blk
             and Path(str(n.get("file", ""))).stem == target_file_stem
             and n.get("role") != "SUBROUTINE_CALL"),
            None,
        )
        if target_first:
            caller_node["parent_chunk_id"] = target_first["chunk_id"]
            caller_node["edge_to_parent"] = {
                "type": "SHARED_INBOUND_CALL",
                "description": (
                    f"Additional caller: {caller_node.get('inst','')} to {target_blk} "
                    f"from {caller_node.get('block','?')}"
                ),
            }

    # Step 4.5 – wire cross-file SETTER roots to their CROSS_FILE_CALL anchor.
    # When _trace_file traces a dependent file, it marks SETTER nodes with
    # _cross_file_parent = chunk_id of the ENTRC/ENTNC node in the calling file.
    # After Step 4, those SETTER nodes still have parent_chunk_id = None because
    # no bridge in child_to_bridge points to their block from the primary file.
    for node in nodes:
        xfp = node.pop("_cross_file_parent", None)
        if xfp and node.get("parent_chunk_id") is None:
            node["parent_chunk_id"] = xfp
            node["edge_to_parent"] = {
                "type": "CROSS_FILE_ENTRY",
                "description": f"Entry from cross-file call into {node.get('file', '?')}",
            }

    # Step 4.6 – wire inbound entry-point roots to their inbound CROSS_FILE_CALL node.
    # When file B has ENTNC DA7G (jumping INTO file A's DA7G entry), file B's
    # ENTNC DA7G node carries _inbound_entry_call = {"caller_file": "da78", "entry": "DA7G"}.
    # File A's DA7G block is a root node (parent_chunk_id=None).  We wire it as a child of
    # file B's ENTNC node so the graph reads: ...da78 setters → ENTNC DA7G → DA7G → DA7G0000.
    inbound_callers: List[Dict[str, Any]] = []
    for node in nodes:
        iec = node.pop("_inbound_entry_call", None)
        if iec:
            node["_iec_meta"] = iec  # temporarily re-attach so we can read it below
            inbound_callers.append(node)
    for caller_node in inbound_callers:
        iec = caller_node.pop("_iec_meta", {})
        caller_file = iec.get("caller_file", "").lower()
        entry_name  = iec.get("entry", "")
        if not entry_name:
            continue
        # Find the primary target entry block (first match in a different file)
        target_node = None
        for n in nodes:
            if n is caller_node:
                continue
            if str(n.get("block", "")) != entry_name:
                continue
            t_file = Path(str(n.get("file", ""))).stem.lower()
            if t_file == caller_file:
                continue
            target_node = n
            break  # first match is the entry-dispatch root

        if target_node is None:
            continue

        if target_node.get("parent_chunk_id") is None:
            # Primary inbound caller: entry block becomes child of this ENTNC node
            target_node["parent_chunk_id"] = caller_node["chunk_id"]
            target_node["edge_to_parent"] = {
                "type": "INBOUND_ENTRY",
                "description": (
                    f"Entry via {caller_node.get('inst','ENTNC')} {entry_name} "
                    f"from {caller_node.get('file','?')}"
                ),
            }
        else:
            # Secondary inbound caller: wire ENTNC node under the entry block
            if caller_node.get("parent_chunk_id") is None:
                caller_node["parent_chunk_id"] = target_node["chunk_id"]
                caller_node["edge_to_parent"] = {
                    "type": "SHARED_INBOUND_ENTRY",
                    "description": (
                        f"Additional inbound caller: {caller_node.get('inst','ENTNC')} {entry_name} "
                        f"from {caller_node.get('file','?')}"
                    ),
                }

    # Step 5 – inject dependent variable nodes into the primary graph.
    # Each dep var's lineage sub-graph is connected as a child of the primary
    # TRIGGER/SUBROUTINE_CALL node that references it, using ":DEP:{VAR}" chunk_ids.
    if dep_var_traces:
        # Build a set of all primary node chunk_ids for anchor validation in Step 5b.
        primary_chunk_ids = {n["chunk_id"] for n in nodes}

        for (var_name, usage_block, usage_line, reason, dep_results, trace_id, parent_anchor_id) in dep_var_traces:
            dep_chain = dep_results.lineage_chain
            if not dep_chain:
                continue

            # a) Assign chunk_ids with :DEP:{VAR}#{trace_id} suffix.
            # trace_id is a unique integer per trace invocation — prevents collisions when
            # the same variable is traced from multiple usage points or at nested levels.
            # Deduplicate within this trace: if the synthetic USAGE entry and the backward
            # trace produce the same (block, line), keep DEPENDENT_VAR_USAGE role.
            dep_by_id: Dict[str, Dict[str, Any]] = {}
            for entry in dep_chain:
                dep_node = dict(entry)
                fs = Path(str(dep_node.get("file", ""))).stem
                blk = str(dep_node.get("block", ""))
                ln = dep_node.get("line", 0)
                dep_node["chunk_id"] = f"{fs}:{blk}:{ln}:DEP:{var_name}#{trace_id}"
                dep_node["source_line"] = _get_source_line(str(dep_node.get("file", "")), int(ln))
                _dep_lm, _dep_si = _get_scope_meta(str(dep_node.get("file", "")))
                _enrich_scope(dep_node, _dep_lm, _dep_si)
                dep_node["dep_variable"] = var_name
                dep_node["dep_trace_id"] = trace_id
                cid = dep_node["chunk_id"]
                if cid in dep_by_id and dep_by_id[cid].get("role") == "DEPENDENT_VAR_USAGE":
                    continue  # USAGE entry takes precedence over backward-trace duplicate
                dep_by_id[cid] = dep_node
            dep_nodes: List[Dict[str, Any]] = list(dep_by_id.values())

            # b) Wire DEPENDENT_VAR_USAGE node → parent anchor.
            # parent_anchor_id is the primary TRIGGER node (level-1) or a TRIGGER node
            # inside a parent dep var's subtree (level-2+).
            # Validate the anchor exists; if not, fall back to the nearest primary node
            # in the same block (by line proximity), or the first node in the block.
            for dep_node in dep_nodes:
                if dep_node.get("role") == "DEPENDENT_VAR_USAGE":
                    anchor = parent_anchor_id
                    if anchor not in primary_chunk_ids:
                        candidates = [
                            n for n in nodes
                            if str(n.get("block", "")) == usage_block
                        ]
                        if candidates:
                            anchor = min(
                                candidates,
                                key=lambda n: abs(int(n.get("line", 0)) - int(usage_line)),
                            )["chunk_id"]
                        else:
                            anchor = None
                    dep_node["parent_chunk_id"] = anchor
                    dep_node["edge_to_parent"] = {
                        "type": "DEP_VAR_USAGE",
                        "variable": var_name,
                        "description": f"{var_name} traced as dependency",
                    }
                    break

            # c) Wire remaining dep var nodes to each other using the same
            #    bridge-building algorithm as the primary graph.
            dep_blocks: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
            for dep_node in dep_nodes:
                dep_blocks[str(dep_node.get("block", ""))].append(dep_node)
            for blk in dep_blocks:
                dep_blocks[blk].sort(key=lambda n: int(n.get("line", 0)))

            dep_bridge: Dict[str, tuple] = {}
            for dep_node in sorted(dep_nodes, key=lambda n: int(n.get("line", 0))):
                role = str(dep_node.get("role", ""))
                if role not in _BRIDGE_ROLES:
                    continue
                args = dep_node.get("args", []) or []
                if not args:
                    continue
                target_lbl = normalize_token(str(args[0]))
                if not target_lbl:
                    continue
                candidate_bridge = (
                    dep_node["chunk_id"],
                    role,
                    str(dep_node.get("inst", "")),
                    str(dep_node.get("block", "")),
                )
                if target_lbl not in dep_bridge:
                    dep_bridge[target_lbl] = candidate_bridge
                else:
                    existing_role = dep_bridge[target_lbl][1]
                    if _BRIDGE_ROLE_PRIORITY.get(role, 0) > _BRIDGE_ROLE_PRIORITY.get(existing_role, 0):
                        dep_bridge[target_lbl] = candidate_bridge

            for blk, entries in dep_blocks.items():
                for i, dep_node in enumerate(entries):
                    if dep_node.get("role") == "DEPENDENT_VAR_USAGE":
                        continue  # already wired in step b
                    if i > 0:
                        dep_node["parent_chunk_id"] = entries[i - 1]["chunk_id"]
                        dep_node["edge_to_parent"] = {"type": "SEQUENTIAL", "description": "Sequential execution"}
                    else:
                        bridge = dep_bridge.get(blk)
                        if bridge:
                            b_cid, b_role, b_inst, b_parent_blk = bridge
                            dep_node["parent_chunk_id"] = b_cid
                            if b_role == "FALLTHROUGH_ENTRY":
                                dep_node["edge_to_parent"] = {"type": "FALLTHROUGH", "description": f"Fall-through from {b_parent_blk} to {blk}"}
                            elif b_role == "GUARD_BRANCH":
                                dep_node["edge_to_parent"] = {"type": "GUARD_BRANCH", "inst": b_inst, "target_block": blk, "description": f"Guard branch {b_inst} taken to {blk}"}
                            elif b_role == "MACRO_BRANCH":
                                dep_node["edge_to_parent"] = {"type": "MACRO_BRANCH", "inst": b_inst, "target_block": blk, "description": f"Macro-generated branch {b_inst} to {blk}"}
                            else:
                                dep_node["edge_to_parent"] = {"type": "BRANCH", "inst": b_inst, "target_block": blk, "description": f"Branch via {b_inst} to {blk}"}
                        else:
                            # Dep var root with no bridge — leave parent as already set (USAGE node)
                            # or mark as dep-var root if not already wired.
                            if "parent_chunk_id" not in dep_node:
                                dep_node["parent_chunk_id"] = None
                                dep_node["edge_to_parent"] = None

            # c2) Wire dep var orphan roots → USAGE node so the sub-graph is connected.
            usage_chunk_id = next(
                (n["chunk_id"] for n in dep_nodes if n.get("role") == "DEPENDENT_VAR_USAGE"), None
            )
            if usage_chunk_id:
                for dep_node in dep_nodes:
                    if dep_node.get("role") == "DEPENDENT_VAR_USAGE":
                        continue
                    if dep_node.get("parent_chunk_id") is None:
                        dep_node["parent_chunk_id"] = usage_chunk_id
                        dep_node["edge_to_parent"] = {
                            "type": "DEP_VAR_ANCESTOR",
                            "description": f"Ancestor in {var_name} dep var lineage",
                        }

            # d) Merge into primary node list.
            nodes.extend(dep_nodes)

    # Step 6 – DFS topological sort so nodes appear in execution-flow order:
    # primary entry points first, setters last; dep var subtrees nested under
    # the TRIGGER that references them.
    node_by_id: Dict[str, Dict[str, Any]] = {n["chunk_id"]: n for n in nodes}

    # Build parent → children adjacency list.
    children_of: Dict[str, List[str]] = {cid: [] for cid in node_by_id}
    for n in nodes:
        pid = n.get("parent_chunk_id")
        if pid and pid in children_of:
            children_of[pid].append(n["chunk_id"])
    # Sort children by line number so sibling order is stable.
    for pid in children_of:
        children_of[pid].sort(key=lambda cid: int(node_by_id[cid].get("line", 0)))

    # DFS preorder from all roots (no parent), ordered by line number.
    roots = sorted(
        [n["chunk_id"] for n in nodes if n.get("parent_chunk_id") is None],
        key=lambda cid: int(node_by_id[cid].get("line", 0)),
    )
    visited: Set[str] = set()
    ordered: List[Dict[str, Any]] = []
    # Iterative DFS: push children in reverse line order so the
    # lowest-line child is processed first.
    stack: List[str] = list(reversed(roots))
    while stack:
        cid = stack.pop()
        if cid in visited:
            continue
        visited.add(cid)
        ordered.append(node_by_id[cid])
        for child_cid in reversed(children_of.get(cid, [])):
            if child_cid not in visited:
                stack.append(child_cid)

    # Append any nodes not reachable from roots (cycle guard / orphans).
    for n in sorted(nodes, key=lambda n: int(n.get("line", 0))):
        if n["chunk_id"] not in visited:
            ordered.append(n)

    nodes = ordered

    # Build block_predecessors: maps a block's first-node chunk_id → all secondary predecessor chunk_ids.
    # These are blocks that can also reach the target block but were not chosen as the primary bridge.
    # Used by callers (e.g. trace_cross_file_lineage) to enumerate all paths to each setter.
    block_predecessors: Dict[str, List[str]] = defaultdict(list)
    node_by_id_for_pred = {n["chunk_id"]: n for n in nodes}
    for (caller_cid, target_blk, target_file_stem) in secondary_bridges:
        target_key = (target_file_stem, target_blk)
        target_entries = blocks_entries.get(target_key, [])
        if not target_entries:
            continue
        target_first_cid = target_entries[0]["chunk_id"]
        if caller_cid in node_by_id_for_pred:  # only include nodes that made it into the graph
            block_predecessors[target_first_cid].append(caller_cid)

    return {
        "variable": target_variable.upper(),
        "file": source_asm_file.name,
        "nodes": nodes,
        "dependent_vars": results.dependent_vars,
        "dependent_files": results.dependent_files,
        "unresolved_files": results.unresolved_files,
        "data_quality_warnings": results.data_quality_warnings,
        "block_predecessors": dict(block_predecessors),
    }


def infer_blueprint_path(source_asm_file: Path) -> Path:
    return source_asm_file.with_name(f"{source_asm_file.stem.lower()}_blueprint.json")


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Trace lineage for an assembler variable using blueprint JSON.")
    p.add_argument("target_variable", help="Variable to trace (e.g., WK_RRC)")
    p.add_argument("source_asm_file", help="Path to source asm file (e.g., da76.asm)")
    p.add_argument("blueprint_file", nargs="?", help="Optional path to blueprint JSON")
    p.add_argument("--output-file", dest="output_file", help="Optional report output file path")
    p.add_argument(
        "--trace-dependencies",
        action="store_true",
        help="Trace lineage for each dependent variable found in the primary variable's analysis",
    )
    p.add_argument(
        "--dependency-filter",
        help="Comma-separated list of dependent variable names to trace (if empty, traces all)",
    )
    p.add_argument(
        "--include-register-dependencies",
        action="store_true",
        help="Include register operands (e.g., R2) as dependent variables",
    )
    p.add_argument(
        "--output-format",
        choices=["text", "json"],
        default="text",
        dest="output_format",
        help="Output format: text (default) or json graph with parent_chunk_id",
    )
    p.add_argument(
        "--dependency-depth",
        type=int,
        default=None,
        dest="dependency_depth",
        help="Maximum depth for recursive dependent variable tracing (default: unlimited). "
             "depth=1 traces only direct deps of the primary variable; depth=2 also traces "
             "deps-of-deps, etc.",
    )
    p.add_argument(
        "--asm-dir",
        dest="asm_dir",
        default=None,
        metavar="DIR",
        help="Directory containing cross-file ASM sources (default: directory of source_asm_file)",
    )
    p.add_argument(
        "--blueprint-dir",
        dest="blueprint_dir",
        default=None,
        metavar="DIR",
        help="Directory containing cross-file blueprint JSON files named <stem>.asm.json "
             "(default: directory of primary blueprint file)",
    )
    return p


def main() -> int:
    args = build_arg_parser().parse_args()
    source_asm_file = Path(args.source_asm_file).resolve()
    if source_asm_file.suffix.lower() == ".json":
        raise SystemExit(
            f"ERROR: '{source_asm_file.name}' looks like a JSON blueprint, not an ASM file.\n"
            "Usage: trace_lineage.py <variable> <source.asm> [blueprint.json]"
        )

    if not source_asm_file.exists():
        raise SystemExit(f"Source ASM file not found: {source_asm_file}")

    blueprint_file = Path(args.blueprint_file).resolve() if args.blueprint_file else infer_blueprint_path(source_asm_file)
    asm_dir = Path(args.asm_dir).resolve() if args.asm_dir else source_asm_file.parent
    blueprint_dir = Path(args.blueprint_dir).resolve() if args.blueprint_dir else blueprint_file.parent
    tracer = LineageTracer(
        asm_dir=asm_dir,
        blueprint_dir=blueprint_dir,
        include_register_dependencies=args.include_register_dependencies,
    )

    # Trace the primary variable
    results = tracer.trace(args.target_variable, source_asm_file, blueprint_file)

    # JSON graph output — collect dep var traces if requested, then build graph.
    if args.output_format == "json":
        dep_var_traces: List[Tuple[str, str, int, str, TraceResults, int, str]] = []
        if args.trace_dependencies:
            filter_vars = {v.strip().upper() for v in args.dependency_filter.split(",")} if args.dependency_filter else set()
            # Global seen set — (var_name, block, line) — prevents re-tracing the same
            # usage point regardless of which parent chain led to it (cycle guard).
            seen_deps: Set[Tuple[str, str, int]] = set()
            file_stem = source_asm_file.stem
            trace_counter = 0
            max_depth: Optional[int] = args.dependency_depth

            # BFS queue entries: (var_name, block, line, reason, parent_anchor_id, depth)
            # parent_anchor_id is the chunk_id of the node this dep var hangs off.
            bfs_queue: List[Tuple[str, str, int, str, str, int]] = []

            # Seed: level-1 deps from the primary trace.
            for dep in results.dependent_vars:
                var_name = str(dep.get("variable", "")).upper()
                block = str(dep.get("block", ""))
                line = int(dep.get("line", 0))
                reason = str(dep.get("reason", ""))
                if filter_vars and var_name not in filter_vars:
                    continue
                key = (var_name, block, line)
                if key in seen_deps:
                    continue
                seen_deps.add(key)
                # Parent anchor = primary node at the usage block+line.
                parent_anchor = f"{file_stem}:{block}:{line}"
                bfs_queue.append((var_name, block, line, reason, parent_anchor, 1))

            while bfs_queue:
                var_name, block, line, reason, parent_anchor_id, depth = bfs_queue.pop(0)
                trace_counter += 1
                current_trace_id = trace_counter

                dep_results = tracer.trace_dependent_variable(
                    dep_variable=var_name,
                    usage_file=source_asm_file,
                    usage_block=block,
                    usage_line=line,
                    blueprint_file=blueprint_file,
                    primary_variable=args.target_variable,
                    reason=reason,
                )
                dep_var_traces.append((var_name, block, line, reason, dep_results, current_trace_id, parent_anchor_id))

                # Expand nested deps unless we've hit the depth limit.
                if max_depth is None or depth < max_depth:
                    for nested_dep in dep_results.dependent_vars:
                        nested_var = str(nested_dep.get("variable", "")).upper()
                        nested_block = str(nested_dep.get("block", ""))
                        nested_line = int(nested_dep.get("line", 0))
                        nested_reason = str(nested_dep.get("reason", ""))
                        if filter_vars and nested_var not in filter_vars:
                            continue
                        nested_key = (nested_var, nested_block, nested_line)
                        if nested_key in seen_deps:
                            continue
                        seen_deps.add(nested_key)
                        # Parent anchor for nested dep = TRIGGER node inside the current
                        # dep var's subtree at the nested usage block+line.
                        nested_anchor = f"{file_stem}:{nested_block}:{nested_line}:DEP:{var_name}#{current_trace_id}"
                        bfs_queue.append((nested_var, nested_block, nested_line, nested_reason, nested_anchor, depth + 1))

        graph = build_lineage_graph(
            args.target_variable, source_asm_file, results,
            dep_var_traces or None,
            blueprint_file=blueprint_file,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
        )
        report = json.dumps(graph, indent=2)
        if args.output_file:
            out_file = Path(args.output_file).expanduser().resolve()
        else:
            output_dir = source_asm_file.parent / "output"
            file_name = f"{source_asm_file.stem.lower()}_{args.target_variable.upper()}_lineage.json"
            out_file = (output_dir / file_name).resolve()
        out_file.parent.mkdir(parents=True, exist_ok=True)
        out_file.write_text(report + "\n", encoding="utf-8")
        print(f"Wrote lineage graph to: {out_file}")
        return 0

    report = format_results(args.target_variable, source_asm_file, results)

    # Optionally trace dependent variables
    if args.trace_dependencies:
        # Parse the filter if provided
        filter_vars = set()
        if args.dependency_filter:
            filter_vars = {v.strip().upper() for v in args.dependency_filter.split(",")}

        # Group dependent variables by (variable, file, block, line) to avoid duplicates
        dep_var_set = set()
        for dep in results.dependent_vars:
            var_name = str(dep.get("variable", "")).upper()
            block = str(dep.get("block", ""))
            line = int(dep.get("line", 0))
            reason = str(dep.get("reason", ""))

            # Apply filter if specified
            if filter_vars and var_name not in filter_vars:
                continue

            # Deduplicate by (variable, block, line)
            key = (var_name, block, line)
            if key in dep_var_set:
                continue
            dep_var_set.add(key)

            # Trace this dependent variable
            dep_results = tracer.trace_dependent_variable(
                dep_variable=var_name,
                usage_file=source_asm_file,
                usage_block=block,
                usage_line=line,
                blueprint_file=blueprint_file,
                primary_variable=args.target_variable,
                reason=reason,
            )

            # Append the formatted dependent variable lineage to the report
            dep_report = format_dependent_variable_lineage(
                dep_variable=var_name,
                primary_variable=args.target_variable,
                usage_file=source_asm_file,
                usage_block=block,
                usage_line=line,
                reason=reason,
                results=dep_results,
            )
            report += "\n" + dep_report

    if args.output_file:
        out_file = Path(args.output_file).expanduser().resolve()
    else:
        output_dir = source_asm_file.parent / "output"
        file_name = f"{source_asm_file.stem.lower()}_{args.target_variable.upper()}_lineage.txt"
        out_file = (output_dir / file_name).resolve()

    out_file.parent.mkdir(parents=True, exist_ok=True)
    out_file.write_text(report + "\n", encoding="utf-8")
    print(f"Wrote lineage report to: {out_file}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
