# Verification: Shared Variable Patterns vs. `/backward-lineage` Algorithm

Cross-referencing the 44 shared variable patterns in `shared_variable_patterns.md`
against the actual implementation of the `/backward-lineage` API.

**Last updated:** After Round 4+ fixes: P43 (FIWHC/FINHC LEVEL= keyword arg — `_collect_level_alloc_setter_sites` and `_backtrack_register_dep_vars` now handle FILE_FIND_INST via `_extract_level_from_args`). Round 4: P9, P16, P17/P18, P26, P29. Round 3: P8/P30, P19, P20, P28, P42. Round 2: P14, P15, P17-P18 (R3 chain), CALLC role. Round 1: P33, P37, P41.

**Files examined:**
- `api/routes/knowledge_base.py` — API endpoint
- `api/tasks/kb_backward_lineage_task.py` — Celery task
- `backward_traversal/runner/backward_only_runner.py` — Core traversal engine
- `backward_traversal/bridge/cross_file_bridge_backward.py` — Cross-language call bridge
- `backward_traversal/utils/cpp_lineage_utils.py` — C++ GVL seed finding
- `backward_traversal/glossary/instructions.py` — Instruction classification sets
- `find_variable_modifiers.py` — Blueprint setter scanning

---

## Category A — Symbol / Name Binding (P1–P6)

| Pattern | Status | Notes |
|---|---|---|
| **P1** `extern "C"` implicit binding | **Covered** | `find_asm_to_cpp_callers` / `find_cpp_to_asm_callers` use `asm_entry_point_map` and `global_symbols`. |
| **P2** `extern "C"` + `asm("SYMBOL")` | **Covered** | Blueprint generator populates `asm_entry_point_map`; algorithm is agnostic. |
| **P3** `#pragma map` | **Covered** | Same as P2. |
| **P4** `#pragma export` | **Covered** | Blueprint emits symbol into `global_symbols` or `asm_entry_point_map`. |
| **P5** visibility hidden | **Covered** | Negative constraint — hidden symbols absent from call graph. |
| **P6** `BEGIN NAME=...,TV=(...)` | **Covered** | Transfer vector entries found via `global_symbols` types `entry`/`csect`/`public` (`cross_file_bridge_backward.py:342-357`). |

---

## Category B — Register-Based Parameter Passing (P7–P9, P33–P34)

| Pattern | Status | Notes |
|---|---|---|
| **P7** `TPF_regs*` struct | **Covered** | `extract_tpf_regs_slots()` (`cpp_lineage_utils.py:75-131`) scans GVL for `struct_field::regs.rN→register:arg` edges. Strategy 4 in `find_cpp_seed_nodes()`. |
| **P8** `ENTRC`/`ENTNC` register pre-load | **Covered** ✅ **FIXED** | `_collect_pre_call_dep_vars()` added to `backward_only_runner.py`. Scans up to 15 instructions before each `ENTRC`/`ENTNC`/`CALLC`/`CREEC`/`EXSR`/`FUNCTION` for `LA Rn,FIELD` / `L Rn,FIELD` patterns; feeds discovered FIELD names into the dep_var BFS. `PRE_CALL_OPCODES` set and `REGISTER_LOAD_FROM_MEM` imported from `instructions.py`. |
| **P9** `CREEC`/`creec()` R14/R15 params | **Covered** ✅ **FIXED** | `_collect_pre_call_dep_vars()` extended with CREEC-family handling. When call_inst is CREEC/CREMC/CREDC, extracts R14=VALUE and R15=VALUE keyword args (via `_extract_keyword_arg` and `CREEC_PARAM_KEYWORDS` frozenset) and feeds them into the dep_var BFS as parameter area names. Preceding LA/L pre-loads also captured via existing window scan. |
| **P33** `CALLC`/`CPROC`/`UPROC` | **Covered** ✅ **FIXED** | `CALLC` added to `CROSS_FILE_CALL_OPCODES` (`instructions.py:61`). `_collect_scoped_cross_file_calls` Source 1 (call_graph.edges, line 318) and Source 2 (blocks[].flow, line 350) now accept CALLC. `_is_followable_cross_file_call()` returns True. Dep_var BFS (line 2316–2319) and root_var downstream (line 1933–1934) now both follow CALLC-connected files. |
| **P34** `ENTDC` — non-returning entry | **Covered** | In `CROSS_FILE_CALL_OPCODES`; `_is_followable_cross_file_call()` returns True. |

---

## Category C — ECB Memory Map Sharing (P10–P13, P41)

| Pattern | Status | Notes |
|---|---|---|
| **P10** `CE1CRx` pointer slots | **Covered** | `SETTER_INST` (`ST`, `L`, `MVC`) matches named CE1CRx fields. |
| **P11** `EBW000` ECB scratch | **Covered** | `_range_write_covers_target()` handles multi-byte range writes. |
| **P12** `EB0Uxxx` Region Zero | **Covered** | Named DSECT offsets tracked as variables. |
| **P13** `CE1DTn` detach state | **Covered** | `CLI` in `TRIGGER_INST`; backward tracer follows data flow. DETAC/ATTAC implicit CE1DTn writes now detected — see P15-P16. |
| **P41** `CE1USA` + `REGNA` regions | **Covered** ✅ **IMPROVED** | `CE1USA` tracked by name. Strategy 6 added to `find_cpp_seed_nodes()` (`cpp_lineage_utils.py:267-278`): when variable is `EB0USER`–`EB7USER` and Strategies 1–5 find no seeds, falls back to searching for `ce1usa` GVL nodes. `_REGNA_REGION_NAMES` frozenset and `_REGNA_CE1USA_ALIAS` constant added. |

---

## Category D — Working Storage and Data Level Sharing (P14–P16, P37–P40)

| Pattern | Status | Notes |
|---|---|---|
| **P14** `GETCC`/`getcc()` | **Covered** ✅ **FIXED** | `_collect_level_alloc_setter_sites()` added to `backward_only_runner.py`. Scans scope blocks for `GETCC Dn`/`GETFC Dn`/`MALOC Dn`, maps level designator via `_LEVEL_TO_CE1CR`, emits `implicit_setter` site for CE1CRn. Called from both `_find_scoped_setter_sites()` and `_extract_modifier_setter_sites()`. `ALLOC_RESULT_REG` dict added to `instructions.py`; `_backtrack_register_dep_vars` now returns CE1CRn as dep_var when R14 is traced back to GETCC. |
| **P15** `DETAC`/`ATTAC` | **Covered** ✅ **FIXED** | `_collect_detac_attac_flag_writes()` added to `backward_only_runner.py`. Scans scope blocks for `DETAC Dn`/`ATTAC Dn`, maps level designator via `LEVEL_TO_CE1DT` (new in `instructions.py`), emits `implicit_setter` site for CE1DTn. Called from both setter-scanning functions. |
| **P16** `RELCC`/`DETAC` lifetime | **Covered** ✅ **FIXED** | Flag bytes (CE1DTn) detected via DETAC/ATTAC (P15 fix). `CRUSA` (multi-level release shorthand, `CRUSA S0=6` ≡ sequential RELCCs) added to `LEVEL_RELEASE_INST`. RELCC/CRUSA are resource-release operations — they do not write named variables; the lifecycle link is established via the DETAC/ATTAC CE1DTn setter (P15). |
| **P37** `FLIPC`/`flipc()` level swap | **Covered** ✅ **FIXED** | `_collect_flipc_level_aliases()` added (`backward_only_runner.py:663-698`). Scans scope blocks for `FLIPC Dn,Dm`, maps level designators to CE1CRx via `_LEVEL_TO_CE1CR` table (D0→CE1CR0 … DF→CE1CRF), returns bidirectional alias dict. `_find_scoped_setter_sites()` (line 763) and `_extract_modifier_setter_sites()` (line 934) both use `match_names = {target} ∪ flipc_aliases.get(target)`. Sites found via alias carry `"flipc_alias_of"` annotation. `FLIPC` classified in new `LEVEL_SWAP_INST` set. |
| **P38** `LEVTA`/`levtest()` | **Not Covered** *(by design)* | Control-flow conditional; not a variable data dependency. `LEVTA`/`LEVTB` classified in new `LEVEL_TEST_INST` set for documentation. |
| **P39** `GETFC`/`RELFC` | **Not Covered** *(by design)* | File-pool resource management; not variable data flow. Classified in `LEVEL_ALLOC_INST` / `LEVEL_RELEASE_INST`. |
| **P40** `RCRFC`/`tpf_rcrfc()` | **Not Covered** *(by design)* | Combined release; not variable data flow. Classified in `LEVEL_RELEASE_INST`. |

---

## Category E — Database Context Sharing (P17–P20, P35–P36, P43–P44)

| Pattern | Status | Notes |
|---|---|---|
| **P17** `DBOPN`/`dfopn()` file handle | **Covered** ✅ **FIXED** | `DB_MANAGED_FIELD_WRITES` extended with DBOPN/DBRED/DBCLS/DBMOD/DBWRT/DBDLT → `SW00RTN`. `_collect_db_managed_field_writes()` now emits implicit setter sites for SW00RTN whenever these DB I/O macros appear in scope blocks. `DB_CONTEXT_DBOPN` synthetic dep_var informational annotation retained for R3 chain tracing. |
| **P18** `DBIFB` context retrieval | **Covered** ✅ **FIXED** | DBIFB/DBIFD added to `DB_MANAGED_FIELD_WRITES` → `SW00RTN`. Named workblock fields (e.g. `WB1XH89SW`) already caught by SETTER_INST (`ST R3,WB1XH89SW`). Pre-call `LA R1,WB1XH89RN` → ENTRC pattern covered by `_collect_pre_call_dep_vars` (P8/P30 fix). `DB_CONTEXT_DBIFB` informational annotation retained. |
| **P19** `DBSPA`/`dfspa()` + `SW00WKA` | **Covered** ✅ **FIXED** | `_collect_db_managed_field_writes()` added to `backward_only_runner.py`. Scans scope blocks for `DBSPA` (via `DB_MANAGED_FIELD_WRITES` dict in `instructions.py`) and emits an `implicit_setter` site targeting `SW00WKA`. Called from both `_find_scoped_setter_sites()` and `_extract_modifier_setter_sites()`. |
| **P20** `dft_kyl` key list | **Covered** ✅ **FIXED** | `_extract_keyword_arg()` helper added; `_find_scoped_setter_sites()` and `_extract_modifier_setter_sites()` now detect `DBKEY KEYLIST=VAR` instructions (via `DB_KEYLIST_INST` set in `instructions.py`) and emit setter sites for the named key-list work area. |
| **P35** `DBMOD`/`dfmod()` LREC mutation | **Covered** | `NI` in `SETTER_INST`; field writes like `NI CR21ACST1,X'FF'-X'80'` found as setter sites. |
| **P36** Transaction scope | **Not Covered** *(by design)* | Commit-scope visibility, not data flow. Classified in new `TRANSACTION_INST` set (`TXBGC`, `TXCMC`, `TXRBC`, `TXSPC`, `TXRSC`). |
| **P43** `FIWHC`/`fiwhc()` | **Covered** ✅ **FIXED** | `_collect_level_alloc_setter_sites` extended to scan `FILE_FIND_INST` (FIWHC/FINHC/FINDC/FINWC) alongside `LEVEL_ALLOC_INST`. New `_extract_level_from_args()` helper handles both the positional `D2` form (GETCC) and the keyword `LEVEL=DE` form (FINHC); maps level designator via `_LEVEL_TO_CE1CR` to emit CE1CRn implicit setter site. Same keyword-arg fallback added to `_backtrack_register_dep_vars` in `asm_backward_tracer.py`. |
| **P44** `DBWAIT`/`dfwait()` | **Not Covered** *(by design)* | I/O synchronization primitive, not data flow. Classified in new `DB_SYNC_INST` set. |

---

## Category F — Structural Layout Identity (P21–P27)

| Pattern | Status | Notes |
|---|---|---|
| **P21** DSECT ↔ `#pragma pack(1)` struct | **Covered** | Foundation of cross-language tracking via `field_asm_aliases` in CPP blueprint. |
| **P22** `DS PLn` ↔ `decimal<N,0>` | **Covered** | Tracked by name; type encoding irrelevant. |
| **P23** `DS XL4` ↔ `__ptr32_t` | **Covered** | Same as P22. |
| **P24** `EQU` bitmask ↔ bitfield | **Covered** | `NI`, `OI`, `XI` in `SETTER_INST`; `TM` in `TRIGGER_INST`. |
| **P25** `ORG *-n` ↔ `union` | **Covered** | Overlapping names tracked independently. |
| **P26** Repeating group ↔ array | **Covered** ✅ **FIXED** | ASM base name already tracked by `normalize_token` (strips `+offset(length)`). `find_cpp_seed_nodes` Strategies 2 and 5 extended to strip trailing digit-only components from GVL node ID/name before suffix comparison, so array-element nodes like `cyclicallimitsbyse[3]` match the alias `cyclicalLimitsBySe`. |
| **P27** DSECT `SUFFIX=` ↔ two-pointer pair | **Covered** | Both names tracked if in aliases. |

---

## Category G — Global and System-Wide Storage (P28–P30, P42)

| Pattern | Status | Notes |
|---|---|---|
| **P28** `GLOBZ` `@MMU...` ↔ `tpfglbl.h` | **Covered** ✅ **FIXED** | Strategy 7 added to `find_cpp_seed_nodes()` (`cpp_lineage_utils.py:280-296`). When Strategies 1–6 find no seeds and the variable name starts with `@`, strips the leading `@` and searches GVL nodes for a matching `name`/`id` (minimum 4 chars after strip). Maps `@MMUFOO` → C++ GVL node `tpfglbl::mmufoo`. |
| **P29** `ALASW` application work area | **Covered** ✅ **FIXED** | Individual ALASW fields (e.g. `ALAFLAG1`) already matched by Strategy 5 via `->alaflag1` / `::alaflag1` suffixes in C++ GVL node IDs. Strategy 8 added: when `variable == "ALASW"` or `"CE1ALASW"` (the DSECT name itself), searches for `ce1alasw` GVL nodes so the backward trace starts at the ECB pointer field from which all ALASW accesses originate. |
| **P30** `CINFC` system state | **Covered** ✅ **FIXED** | Fixed via P8 pre-call dep_var collection. `_collect_pre_call_dep_vars()` detects `LA R1,PARM_AREA` / `L R1,PARM_AREA` before `ENTRC CINFC` and feeds `PARM_AREA` into the dep_var BFS, making the parameter area a traceable seed. `ENTRC CINFC` call edge already tracked as a cross-file call since Round 1. |
| **P42** `TMSMA` table lookup | **Covered** ✅ **FIXED** | `_collect_macro_fixed_result_writes()` added to `backward_only_runner.py`. Scans scope blocks for `TMSMA` (via `MACRO_FIXED_RESULT_FIELD` dict in `instructions.py`) and emits an `implicit_setter` site targeting `EBL8URTN`. Called from both setter-scanning functions. |

---

## Category H — Stack Frame and Entry Linkage (P31–P32)

| Pattern | Status | Notes |
|---|---|---|
| **P31** `APSTKC`/`STMG`/`LMG` | **Not Covered** *(by design)* | Calling convention; not a variable data dependency. |
| **P32** `TMSPC`/`PRLGC`/`EPLGC` | **Not Covered** *(by design)* | BAL subroutine linkage convention. |

---

## Summary (final)

| Category | Total | Covered | Partially Covered | Not Covered (by design) |
|---|---|---|---|---|
| A — Name Binding | 6 | 6 | 0 | 0 |
| B — Register Passing | 5 | **5** | 0 | 0 |
| C — ECB Map | 5 | **5** | 0 | 0 |
| D — Working Storage | 7 | **4** | 0 | 3 |
| E — Database Context | 8 | **6** | 0 | 2 |
| F — Struct Layout | 7 | **7** | 0 | 0 |
| G — Global Storage | 4 | **4** | 0 | 0 |
| H — Stack/Linkage | 2 | 0 | 0 | 2 |
| **Total** | **44** | **37** | **0** | **7** |

Round 1: P33, P37, P41. Round 2: P14, P15, P17-P18 (R3 chain), CALLC role.
Round 3: P8/P30, P19, P20, P28, P42. Round 4: P9, P16, P17/P18 (SW00RTN), P26, P29.
Round 4+: P43 (FIWHC/FINHC LEVEL= keyword arg).
**0 patterns remain Partially Covered. 7 "Not Covered by Design" are genuine exclusions** (calling conventions, transaction scope, branch predicates, resource lifecycle, I/O sync).

---

## Remaining Open Gaps

**No "Partially Covered" patterns remain.** All 44 patterns are either Covered (36) or
Not Covered by Design (8). The 8 by-design exclusions are calling convention infrastructure
and sync primitives that carry no variable data-flow semantics.

### Residual Informational Limitations (not gaps)

These do not affect correctness of variable tracking but are noted for completeness:

- **R3 → SW00SR field chain (P17/P18):** `DBOPN`/`DBIFB` set SW00RTN (now covered as
  implicit setter). The register R3 is set to the SW00SR context address; tracing
  R3→ST R3,FIELD→named_field without a `USING`-aware schema model is impractical.
  The `DB_CONTEXT_*` synthetic dep_var informational annotation remains.
- **CREEC async inter-procedural binding (P9 residual):** R14=/R15= parameter area
  names now surfaced as dep_vars. Deep cross-entry callback binding (the new entry
  sees those values as initial register state) is not modeled — this is an
  intra-entry concern handled at runtime, not statically traceable.

---

## What Was Fixed

### Fix 1 — P33: `CALLC` added to `CROSS_FILE_CALL_OPCODES`

**File:** `backward_traversal/glossary/instructions.py:61`

`CALLC` is IBM's preferred typed cross-language call from BAL. It now appears in
`CROSS_FILE_CALL_OPCODES` (and therefore `CROSS_FILE_INST`), fixing three phases:

| Phase | Location | Previously | After fix |
|---|---|---|---|
| Dep_var BFS, Source 1 | `backward_only_runner.py:318` | CALLC edges dropped | CALLC edges accepted |
| Dep_var BFS, Source 2 | `backward_only_runner.py:350` | CALLC flow entries dropped | CALLC flow entries accepted |
| Root_var downstream | `backward_only_runner.py:1934` | `_is_followable_cross_file_call` returned False | Returns True |
| Pass 1 upstream bridge | `cross_file_bridge_backward.py` | Target-match only (already worked) | Unchanged |

---

### Fix 2 — P37: FLIPC CE1CRx alias expansion

**Files:** `backward_traversal/runner/backward_only_runner.py:650-698, 760-804, 930-976`

New `_LEVEL_TO_CE1CR` table maps all 16 level designators (D0–DF) to canonical
CE1CRx field names. New `_collect_flipc_level_aliases(bp_data, scope_blocks)`
function scans scope blocks for `FLIPC Dn,Dm` instructions and returns a
bidirectional alias dict `{CE1CRx: {CE1CRy}}`.

Both setter-scanning functions now use `match_names = {target} | flipc_aliases.get(target)`:

- `_find_scoped_setter_sites()` — scoped (upstream call-site scope)
- `_extract_modifier_setter_sites()` — full-file scope for the modifier file

Setter sites discovered via a FLIPC alias carry `"flipc_alias_of": target` so
consumers can distinguish direct writes from level-swap-mediated writes.

**Concrete scenario now handled:**
```
ASM:  ST  R7,CE1CR0(,R9)   ;; write pointer to D0's block via CE1CR0
      FLIPC D0,D4           ;; swap levels
C++:  ptr = ecbptr()->ce1cr4 ;; reads old D0 block — now at D4
```
Previously: CE1CR0 write and CE1CR4 read were disconnected.
After fix: `_collect_flipc_level_aliases` detects `FLIPC D0,D4`, adds
`CE1CR0↔CE1CR4` bidirectional alias. Searching for `CE1CR4` now also finds
the `ST R7,CE1CR0` setter. `"flipc_alias_of": "CE1CR4"` is annotated on the result.

---

### Fix 3 — P41: REGNA → CE1USA Strategy 6

**File:** `backward_traversal/utils/cpp_lineage_utils.py:134-143, 267-278`

New constants `_REGNA_REGION_NAMES = frozenset({"EB0USER"…"EB7USER"})` and
`_REGNA_CE1USA_ALIAS = "ce1usa"` added before `find_cpp_seed_nodes()`.

Strategy 6 activates only when:
1. Strategies 1–5 produced no seeds, AND
2. The variable name is one of the eight REGNA region names

It then scans GVL nodes for any node with name or id matching `ce1usa`
(including `::ce1usa`, `:ce1usa`, `->ce1usa` forms) and adds it as a seed,
so the C++ backward trace starts at `ecbptr()->ce1usa` rather than returning empty.

---

## Patterns Not Covered by Design

These 7 patterns represent control-flow mechanisms, calling conventions, or
synchronization primitives — not variable data dependencies. They carry no
setter or data-flow semantics that the algorithm can usefully model.

| Pattern | Why it cannot be modelled as a variable setter |
|---|---|
| P31 — APSTKC/STMG/LMG | `STMG` writes GPR contents (calling convention metadata) to a local save area, not application-level shared data. APSTKC/USRSTK allocate/free the frame; neither sets a named ECB field. |
| P32 — TMSPC/PRLGC/EPLGC | BAL subroutine prologue/epilogue macros. Same reasoning as P31 — pure register-save infrastructure. |
| P36 — TXBGC/TXCMC/TXRBC | `TXBGC` opens a commit scope; `TXCMC`/`TXRBC` commit/rollback it. These control *when* DB changes are visible to other ECBs, not *what* is written to a named variable. No ECB field is set. |
| P38 — LEVTA/levtest() | `LEVTA LEVEL=n,NOTUSED=label` tests whether data level n is occupied and branches. It reads ECB state and sets the condition code — it writes nothing to a named field. It is a branch predicate, not a setter. |
| P39 — GETFC/RELFC | `GETFC` obtains a file-pool address (FARW) into R14 — a transient memory-management token, not a named CE1CRx ECB field. The caller stores R14 into their own local field (caught by SETTER_INST). `RELFC` releases the FARW. Neither writes a shared named variable. |
| P40 — RCRFC/tpf_rcrfc() | Atomically releases both the CBRW (core block) and FARW (file-pool address) for a level. A combined release — nothing is set. |
| P44 — DBWAIT/dfwait() | Blocks until a background prefetch I/O (initiated by `DBOPN PREFETCH=PRIME`) completes. Waits on a pending-I/O flag in SW00SR; does not produce a named variable as output. |

All 7 have been classified into instruction category sets in `instructions.py`
(`LEVEL_ALLOC_INST`, `LEVEL_RELEASE_INST`, `LEVEL_TEST_INST`, `FILE_FIND_INST`,
`DB_SYNC_INST`, `TRANSACTION_INST`) for documentation and future tooling use.

**Note — P43 was incorrectly in this list.** FIWHC/FINHC/FINDC/FINWC DO allocate a
core data level block (same as GETCC) and write CE1CRn. They were not working because
their level designator uses `LEVEL=DE` keyword syntax rather than the positional `D2`
form assumed by the original code. Fixed in Round 4+: `_extract_level_from_args()`
handles both forms; `_collect_level_alloc_setter_sites` now covers `FILE_FIND_INST`
alongside `LEVEL_ALLOC_INST`.

---

## Round 2 Fixes

### Fix 4 — P14: GETCC/GETFC implicit CE1CRn setter sites

**Files:** `backward_traversal/glossary/instructions.py`, `backward_traversal/runner/backward_only_runner.py`, `backward_traversal/tracing/asm_backward_tracer.py`

**`instructions.py` additions:**
- `ALLOC_RESULT_REG`: maps GETCC/GETFC/MALOC/FIWHC/FINHC/FINDC/FINWC → "R14"
- `LEVEL_TO_CE1CR`: level designator (D0–DF) → CE1CRx canonical name (shared constant, avoids circular import)

**`backward_only_runner.py` additions:**
- `_collect_level_alloc_setter_sites(bp_data, scope_blocks, asm_file, asm_dir)` — scans blocks for GETCC Dn/GETFC Dn/MALOC Dn, maps via `_LEVEL_TO_CE1CR`, emits `{"call_type": "implicit_setter", "implicit_target": ce1cr}` site dicts
- Called from `_find_scoped_setter_sites()` and `_extract_modifier_setter_sites()` after the SETTER_INST loop

**`asm_backward_tracer.py` addition:**
- In `_backtrack_register_dep_vars()`: when tracing Rn backward hits `GETCC Dn` with `ALLOC_RESULT_REG[inst] == reg_upper`, emits `CE1CRn` (from `LEVEL_TO_CE1CR`) as the dep_var source, making the allocation chain visible in trace output.

---

### Fix 5 — P15-P16: DETAC/ATTAC implicit CE1DTn setter sites

**Files:** `backward_traversal/glossary/instructions.py`, `backward_traversal/runner/backward_only_runner.py`

**`instructions.py` addition:**
- `LEVEL_TO_CE1DT`: level designator (D0–DF) → CE1DTx canonical name (D0→CE1DT0 … DF→CE1DTF)

**`backward_only_runner.py` additions:**
- `_collect_detac_attac_flag_writes(bp_data, scope_blocks, asm_file, asm_dir)` — scans blocks for `DETAC Dn` / `ATTAC Dn` instructions (via `LEVEL_TRANSFER_INST`), maps level designator via `LEVEL_TO_CE1DT`, emits `{"call_type": "implicit_setter", "implicit_target": ce1dt}` site dicts
- Called from both setter-scanning functions after the SETTER_INST loop

**Concrete scenario now handled:**
```
ASM:  DETAC D2        ;; implicitly writes CE1DT2 = detached
C++:  if (ecbptr()->ce1dt2 == DETACHED) { ... }
```
Previously: `DETAC D2` was not recognised as a write to CE1DT2; tracing CE1DT2
found no setter site in the file that executed DETAC.
After fix: `_collect_detac_attac_flag_writes` detects `DETAC D2`, maps to CE1DT2,
and emits an `implicit_setter` site so the link is visible in the output.

---

### Fix 6 — P17-P18: DB context register chain visibility

**Files:** `backward_traversal/glossary/instructions.py`, `backward_traversal/runner/backward_only_runner.py`, `backward_traversal/tracing/asm_backward_tracer.py`

**`instructions.py` addition:**
- `DB_CONTEXT_REG`: maps DBOPN/DBIFB/DBRED/DBIFD/DBSPA/DBCLS → "R3"

**`asm_backward_tracer.py` addition:**
- In `_backtrack_register_dep_vars()`: when tracing R3 backward hits a DB context instruction (`DB_CONTEXT_REG[inst] == reg_upper`), emits `DB_CONTEXT_{inst}` as a synthetic dep_var (e.g. `DB_CONTEXT_DBOPN`). This is filtered from recursive BFS by `_is_noise_dep_var` (won't waste budget on it) but appears in `dependent_variables` output as an informational annotation.

**`backward_only_runner.py` addition:**
- `_is_noise_dep_var()` extended with `or n.startswith("DB_CONTEXT_")` so synthetic labels don't enter the dep_var BFS as traceable variables.

---

### Fix 7 — CALLC in `_inst_to_role`

**File:** `backward_traversal/tracing/asm_backward_tracer.py:93`

Added `"CALLC": "CROSS_FILE_CALL"` to the `_inst_to_role` mapping table.  Previously
`CALLC` was in `CROSS_FILE_CALL_OPCODES` (Round 1 fix) but not in the role table used
by `trace_asm_call_site_backward` to annotate relevant code lines.  Now CALLC call sites
emit `role="CROSS_FILE_CALL"` in the call graph output, consistent with ENTRC/ENTNC.

---

## Round 3 Fixes

### Fix 8 — P8/P30: Pre-call register pre-load dep_var collection

**Files:** `backward_traversal/glossary/instructions.py`, `backward_traversal/runner/backward_only_runner.py`

**`instructions.py` additions:**
- `PRE_CALL_OPCODES`: set of all cross-file call instructions whose preceding register
  loads should be captured as dep_vars — `ENTRC`, `ENTNC`, `ENTDC`, `CALLC`, `CREEC`,
  `CREMC`, `CREDC`, `EXSR`, `FUNCTION`
- `REGISTER_LOAD_FROM_MEM` imported by `backward_only_runner.py` (was already in
  `instructions.py` but not imported by the runner)

**`backward_only_runner.py` additions:**
- `_PRE_CALL_LOAD_WINDOW = 15` — scan window (instructions before each call opcode)
- `_collect_pre_call_dep_vars(bp_data, scope_blocks) → List[str]` — iterates all blocks,
  finds `PRE_CALL_OPCODES` instructions, then walks backward up to 15 instructions
  looking for `LA Rn,FIELD` / `L Rn,FIELD` (using `REGISTER_LOAD_FROM_MEM` for the
  load forms, and special-casing `LA` for address loads). Returns all discovered FIELD
  names as dep_vars.
- Integrated into the BFS chain-file loop (after `chain_file_results[stem]` is assigned):
  each ASM file's pre-call dep_vars are fed into `dv_queue` after noise filtering via
  `_is_noise_dep_var`.

**Concrete scenario now handled:**
```
ASM:  LA   R1,PARM_AREA      ;; pre-load parameter area address into R1
      ENTRC CINFC             ;; cross-file call (P30 CINFC pattern)

;; or:
      L    R2,WB1XH89RN      ;; pre-load named field into R2
      ENTRC SOMEFN            ;; cross-file call (P8 generic pattern)
```
Previously: PARM_AREA and WB1XH89RN were invisible to the dep_var BFS — only the
call edge itself was tracked.
After fix: `_collect_pre_call_dep_vars` discovers PARM_AREA and WB1XH89RN; they are
enqueued as dep_vars and traced in subsequent BFS iterations.

---

### Fix 9 — P19: DBSPA implicit SW00WKA setter

**Files:** `backward_traversal/glossary/instructions.py`, `backward_traversal/runner/backward_only_runner.py`

**`instructions.py` addition:**
- `DB_MANAGED_FIELD_WRITES = {"DBSPA": "SW00WKA"}` — maps macro names to the named
  ECB field they implicitly write.

**`backward_only_runner.py` additions:**
- `_collect_db_managed_field_writes(bp_data, scope_blocks, asm_file, asm_dir) → Dict[str, List]`
  — scans scope blocks for any instruction in `DB_MANAGED_FIELD_WRITES`. For each match,
  emits an `{"call_type": "implicit_setter", "implicit_target": field_name, ...}` site
  dict keyed by the target field name.
- Called from `_find_scoped_setter_sites()` (scoped scan) and
  `_extract_modifier_setter_sites()` (full-file scan) after the SETTER_INST loop.
  Result filtered by whether the current `target` matches any implicitly-written field.

**Concrete scenario now handled:**
```
ASM:  DBSPA REF=SW00FILE      ;; implicitly initialises SW00WKA in the open DB context
C++:  wkptr = sw00srptr->sw00wka;  ;; reads the work area pointer
```
Previously: `DBSPA` was not recognised as a write to SW00WKA; searching for SW00WKA
found no setter site.
After fix: `_collect_db_managed_field_writes` detects `DBSPA` and emits an
`implicit_setter` site for SW00WKA so the link is visible in the output.

---

### Fix 10 — P20: DBKEY KEYLIST= key-list work area

**Files:** `backward_traversal/glossary/instructions.py`, `backward_traversal/runner/backward_only_runner.py`

**`instructions.py` addition:**
- `DB_KEYLIST_INST = {"DBKEY"}` — instruction set for key-list filling macros.

**`backward_only_runner.py` additions:**
- `_extract_keyword_arg(args, keyword) → Optional[str]` — scans an instruction's
  argument list for a `KEYWORD=VALUE` positional argument, normalises and returns VALUE.
  Skips register-like tokens (e.g. `KEYLIST=R1`).
- In `_find_scoped_setter_sites()` and `_extract_modifier_setter_sites()`: before the
  SETTER_INST loop, checks if `inst in DB_KEYLIST_INST`. If so, calls
  `_extract_keyword_arg(args, "KEYLIST")`; if the returned variable name is in
  `match_names`, emits a setter site.

**Concrete scenario now handled:**
```
ASM:  DBKEY KEYLIST=WK_KEYLIST,DBFN=SW00FILE   ;; fills WK_KEYLIST with DB key data
C++:  memcpy(&wkb->wk_keylist, ...)            ;; C++ reads the filled key list
```
Previously: `DBKEY` was not in `SETTER_INST`, so `WK_KEYLIST` had no setter site.
After fix: `_extract_keyword_arg(args, "KEYLIST")` extracts `WK_KEYLIST` from the
`KEYLIST=WK_KEYLIST` operand and emits a setter site when the target matches.

---

### Fix 11 — P28: @MMU global storage → Strategy 7 in `find_cpp_seed_nodes`

**File:** `backward_traversal/utils/cpp_lineage_utils.py:280-296`

New Strategy 7 added to `find_cpp_seed_nodes()`:

```python
# Strategy 7 (P28): @MMU-prefixed global storage variables (GLOBZ / TPFGLB).
if not seeds and var_upper.startswith("@"):
    stripped_lower = var_lower.lstrip("@")
    if len(stripped_lower) >= 4:
        for n in (gvl.get("nodes") or []):
            nid = _safe_str(n.get("id")).lower()
            nname = _safe_str(n.get("name")).lower()
            if (nname == stripped_lower
                    or nid == stripped_lower
                    or nid.endswith(f"::{stripped_lower}")
                    or nid.endswith(f":{stripped_lower}")
                    or nid.endswith(f"->{stripped_lower}")):
                sid = _safe_str(n.get("id") or n.get("name") or "").strip()
                if sid:
                    _add(sid)
```

Strategy 7 activates only when Strategies 1–6 have produced no seeds and the ASM
variable name starts with `@`. It strips the leading `@` and searches GVL nodes for
a name/id match (requiring ≥ 4 chars after stripping to avoid false positives).

**Concrete scenario now handled:**
```
ASM:  ST   R5,@MMUFOO(,R9)   ;; writes to GLOBZ-declared global @MMUFOO
C++:  val = tpfglbl.mmufoo;  ;; C++ accesses the same field as mmufoo
```
Previously: `@MMUFOO` is not a standard DSECT field — `find_cpp_seed_nodes` with
Strategies 1–6 found no GVL node. The C++ side was never reached.
After fix: Strategy 7 strips `@` → `mmufoo`, finds the `tpfglbl::mmufoo` GVL node,
and feeds it as a seed for the C++ backward trace.

Warning message updated to say "after all 7 strategies".

---

### Fix 12 — P42: TMSMA implicit EBL8URTN setter

**Files:** `backward_traversal/glossary/instructions.py`, `backward_traversal/runner/backward_only_runner.py`

**`instructions.py` addition:**
- `MACRO_FIXED_RESULT_FIELD = {"TMSMA": "EBL8URTN"}` — maps macro names to the fixed
  ECB result field they always write.

**`backward_only_runner.py` additions:**
- `_collect_macro_fixed_result_writes(bp_data, scope_blocks, asm_file, asm_dir) → Dict[str, List]`
  — mirrors `_collect_db_managed_field_writes` but uses `MACRO_FIXED_RESULT_FIELD`.
  Scans blocks for `TMSMA`; emits `{"call_type": "implicit_setter", "implicit_target": "EBL8URTN", ...}`.
- Called from `_find_scoped_setter_sites()` and `_extract_modifier_setter_sites()` after
  the `_collect_db_managed_field_writes` call.

**Concrete scenario now handled:**
```
ASM:  TMSMA KEY=WK_TMS,DBFN=SW00FILE   ;; table lookup — always writes EBL8URTN
      CLI   EBL8URTN,X'00'             ;; check return code
C++:  if (ecbptr()->ebl8urtn == 0) { ... }
```
Previously: `TMSMA` was not recognised as a write to `EBL8URTN`; searching for
`EBL8URTN` as the target variable found no setter site in files that used TMSMA.
After fix: `_collect_macro_fixed_result_writes` detects `TMSMA` and emits an
`implicit_setter` site for `EBL8URTN`.

---

## Round 4 Fixes

### Fix 13 — P9: CREEC R14=/R15= parameter keyword args

**Files:** `backward_traversal/glossary/instructions.py`, `backward_traversal/runner/backward_only_runner.py`

**`instructions.py` addition:**
- `CREEC_PARAM_KEYWORDS = frozenset({"R14", "R15"})` — the keyword argument names that
  carry parameter block addresses on CREEC/CREMC/CREDC call instructions.

**`backward_only_runner.py` additions:**
- `_CREEC_FAMILY = frozenset({"CREEC", "CREMC", "CREDC"})` — CREEC-family call instructions.
- In `_collect_pre_call_dep_vars()`: when the detected cross-file call instruction is in
  `_CREEC_FAMILY`, iterates `CREEC_PARAM_KEYWORDS` and calls `_extract_keyword_arg(args, kw)`
  for each. Any non-register, non-noise VALUE from `R14=VALUE` / `R15=VALUE` is added
  to `pre_call_vars` and enqueued in the dep_var BFS.

**Concrete scenario now handled:**
```
ASM:  CREEC PROGNM=CINFC,R14=PARM_AREA_A,R15=PARM_AREA_B
```
Previously: only the CINFC call edge was tracked; PARM_AREA_A and PARM_AREA_B were
invisible to the dep_var BFS.
After fix: `_collect_pre_call_dep_vars` extracts `PARM_AREA_A` and `PARM_AREA_B` from
R14= and R15= keyword args; both are enqueued as dep_vars.

---

### Fix 14 — P16: CRUSA multi-level release classification

**File:** `backward_traversal/glossary/instructions.py`

Added `"CRUSA"` to `LEVEL_RELEASE_INST`. `CRUSA Sn=level` is IBM's shorthand macro for
releasing multiple ECB data levels in one call (equivalent to sequential `RELCC` calls):
`CRUSA S0=6` releases level 6; `CRUSA S0=2,S1=7` releases levels 2 and 7.

CRUSA does not write a named variable (it releases resources), so no setter detection is
added. The lifecycle link is already established via DETAC/ATTAC → CE1DTn (P15 fix). This
fix ensures CRUSA is properly classified in `LEVEL_RELEASE_INST` for documentation and
future static analysis tooling.

---

### Fix 15 — P17/P18: DB I/O operations implicit SW00RTN setter

**Files:** `backward_traversal/glossary/instructions.py`, `backward_traversal/runner/backward_only_runner.py`

**`instructions.py` change:**
- `DB_MANAGED_FIELD_WRITES` extended with 8 DB operation → SW00RTN mappings:
  ```python
  "DBOPN": "SW00RTN",  "DBRED": "SW00RTN",  "DBCLS": "SW00RTN",
  "DBMOD": "SW00RTN",  "DBWRT": "SW00RTN",  "DBDLT": "SW00RTN",
  "DBIFB": "SW00RTN",  "DBIFD": "SW00RTN",
  ```
  Every DB I/O macro writes its return code to `SW00RTN` unconditionally.

**`backward_only_runner.py`:** No additional changes — `_collect_db_managed_field_writes()`
already iterates `DB_MANAGED_FIELD_WRITES` and emits implicit setter sites for any matching
instruction found in scope blocks.

**Concrete scenario now handled:**
```
ASM:  DBOPN REF=CR21AEFM,REG=R7,HOLD
      DBRED REF=CR21AEFM
      CLI   SW00RTN,#ACPDBOK      ;; check DBRED return code
C++:  dft_fil* f = dfopn(...);
      rec = dfred(f, ...);
      if (rec != nullptr) { ... } ;; dfred return value ≡ SW00RTN check
```
Previously: `SW00RTN` had no setter site in a file that used `DBOPN`/`DBRED`; searching
backward found no instruction that explicitly wrote SW00RTN.
After fix: `_collect_db_managed_field_writes` detects DBOPN and DBRED and emits
`implicit_setter` sites for SW00RTN so the CLI check is correctly linked to the DB
operation that produced the return code.

---

### Fix 16 — P26: Array-indexed GVL node IDs in Strategies 2 and 5

**File:** `backward_traversal/utils/cpp_lineage_utils.py:213-257`

**Strategy 2 change:** Before the suffix comparison loop, strips trailing digit-only
components from `id_parts` and `name_parts`. When a GVL node ID is `cyclicallimitsbyse[3]`,
`_field_components` returns `["cyclicallimitsbyse", "3"]`. The digit-stripped form
`["cyclicallimitsbyse"]` now successfully suffix-matches the alias path `["cyclicallimitsbyse"]`
derived from `asm_field_aliases["LG1CYCL"] = ["cyclicalLimitsBySe"]`.

**Strategy 5 change:** For both `nid_lower` and `nname`, computes the base form
`nid_base = nid_lower.split("[")[0]` before the equality/endswith checks. This allows
`lg1cycl[5]` (with array index) to match the ASM variable `LG1CYCL` via direct name
comparison.

**Concrete scenario now handled:**
```
ASM:  MVC LG1CYCL+n(LG1CYCLEN),SOURCE   ;; writes n-th element of repeating group
C++:  cyclicalLimitsBySe[n].field = ...  ;; GVL node: "cyclicallimitsbyse[n]"
```
Previously: GVL nodes like `cyclicallimitsbyse[3]` didn't match alias `cyclicalLimitsBySe`
because the numeric suffix `3` appeared as an extra component in the suffix comparison.
After fix: digit-stripped form `["cyclicallimitsbyse"]` matches alias `["cyclicallimitsbyse"]`.

---

### Fix 17 — P29: ALASW DSECT name → ce1alasw ECB pointer (Strategy 8)

**Files:** `backward_traversal/utils/cpp_lineage_utils.py`

**Constants added:**
- `_ALASW_ECB_POINTER = "ce1alasw"` — the ECB pointer field name in C++.
- `_ALASW_DSECT_NAMES = frozenset({"ALASW", "CE1ALASW"})` — DSECT names that are aliases
  for the ALASW application-level work area.

**Strategy 8 added:** When all Strategies 1–7 find no seeds and `var_upper` is in
`_ALASW_DSECT_NAMES`, scans GVL nodes for any node with name or id matching `ce1alasw`
(including `::ce1alasw`, `:ce1alasw`, `->ce1alasw` forms). This handles the case where
the variable is the DSECT name itself (e.g. the caller stores a pointer to the whole
ALASW struct) rather than an individual field within it.

Individual ALASW field accesses (e.g. `ALAFLAG1`) are already handled by Strategy 5:
the GVL node `ce1alasw->alaflag1` matches via `nid.endswith("->alaflag1")`.

Warning message updated to say "after all 8 strategies".

**Concrete scenario now handled:**
```
ASM:  USING ALASW,Rx           ;; establish ALASW addressability
      OI    ALAFLAG1,AL#DONE   ;; set field (Strategy 5 catches ALAFLAG1)
C++:  Alasw* pAla = (Alasw*)ecbptr()->ce1alasw;  ;; GVL: ce1alasw node
      pAla->alaflag1 |= AL_DONE;
```
Previously: when searching for `ALASW` or `CE1ALASW` as the target (not a field within it),
`find_cpp_seed_nodes` with Strategies 1–7 found no seed.
After fix: Strategy 8 matches the `ce1alasw` ECB pointer node so the C++ backward trace
starts at the correct struct pointer field.
