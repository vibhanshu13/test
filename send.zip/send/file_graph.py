#!/usr/bin/env python3
"""Build a file-level graph for a codebase (item #1 of the multi-level graph builder).

Nodes are source files (C++ or ASM). Each node carries:
  * ``makefiles``        — the makefile(s) that build this file (may be empty),
  * ``business_name``    — a short LLM label (via llm.business_name, cached), and
  * ``business_summary`` — the per-file blueprint summary.

LLM modes:
  * default               — read ``business_summary`` from the blueprint, derive
                            ``business_name`` from it (cached at
                            ``<output-dir>/business_names.json``; 1 call/file cold,
                            0 on re-run). A file with no blueprint summary gets
                            ``business_summary=null`` / ``business_name=null`` at no cost.
  * ``--generate-summaries`` — additionally, when a blueprint has no summary,
                            generate one from the raw source via
                            ``llm.summarizer`` (persisted to
                            ``<output-dir>/generated_summaries.json``), then name it.
  * ``--no-llm``          — purely structural graph: both ``business_summary`` and
                            ``business_name`` are ``null`` (0 LLM calls).

Edges are relationships between files:
  * ``call``    — file-to-file calls, from a fresh file_call_graph.CallGraphBuilder run, and
  * ``include`` — C/C++ ``#include`` dependencies, from each blueprint's file_dependencies,
                  kept when the included header is itself a file in the codebase.

Inputs:
  --codebase-dir   directory of raw source files (e.g. temp/asm)
  --output-dir     parser-output root containing the per-file blueprints (e.g. temp/output_latest)

Example:
    python file_graph.py --codebase-dir temp/asm --output-dir temp/output_latest
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from cluster_graph import (
    _ASM_EXTS,
    _CPP_EXTS,
    _C_EXTS,
    _enumerate_source_files,
    _find_blueprint_dir,
    _load_business_summary,
    _load_makefile_clusters,
    _stem,
    build_file_call_graph,
    include_file_edges,
)


def _file_type(name: str) -> str:
    ext = os.path.splitext(name)[1]
    if ext in {".hpp", ".h"}:
        return "header"
    if ext in _CPP_EXTS:
        return "cpp"
    if ext in _C_EXTS:
        return "c"
    if ext in _ASM_EXTS:
        return "asm"
    return "other"


def _file_to_makefiles(makefile_clusters: Dict[str, dict], source_files: List[str]) -> Dict[str, List[str]]:
    """Map each present filename to the makefile name(s) that build it."""
    present_stems = {_stem(f): f for f in source_files}
    out: Dict[str, List[str]] = defaultdict(list)
    for meta in makefile_clusters.values():
        mkname = meta["makefile"]
        for src in meta["source_files"]:
            fname = present_stems.get(_stem(src))
            if fname:
                out[fname].append(mkname)
    return out


def _call_edges(file_graph: dict, stem_to_file: Dict[str, str]) -> List[dict]:
    """Internal file-to-file call edges from the fresh call graph."""
    edges: List[dict] = []
    for e in file_graph.get("edges", []):
        if not e.get("is_internal"):
            continue
        src = stem_to_file.get(e["source"])
        tgt = stem_to_file.get(e["target"])
        if not src or not tgt or src == tgt:
            continue
        edges.append(
            {
                "source": src,
                "target": tgt,
                "type": "call",
                "instructions": e.get("instructions", []),
            }
        )
    return edges


_GENERATED_SUMMARY_CACHE = "generated_summaries.json"


def _load_json(path: Path) -> Dict[str, str]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8")) or {}
    except (json.JSONDecodeError, OSError):
        return {}


def _resolve_summaries(
    codebase_dir: Path,
    blueprint_dir: Path,
    output_dir: Path,
    source_files: List[str],
    generate_summaries: bool,
) -> Tuple[Dict[str, Optional[str]], int]:
    """Return ``{file: summary or None}`` and the count generated this run.

    Summaries are read from the blueprint first. With ``generate_summaries`` a
    file whose blueprint has none is summarised from its raw source via
    ``llm.summarizer.generate_business_summary`` and persisted to a sidecar
    cache so re-runs don't pay for it again.
    """
    summaries: Dict[str, Optional[str]] = {}
    gen_cache_path = output_dir / _GENERATED_SUMMARY_CACHE
    gen_cache = _load_json(gen_cache_path) if generate_summaries else {}
    generated = 0
    for fname in source_files:
        summary = _load_business_summary(blueprint_dir, fname)
        if not summary and generate_summaries:
            summary = gen_cache.get(fname)
            if not summary:
                try:
                    from llm.summarizer import generate_business_summary

                    summary = (generate_business_summary(codebase_dir / fname) or "").strip()
                except Exception as exc:  # noqa: BLE001
                    print(f"warning: summary generation failed for {fname}: {exc}", file=sys.stderr)
                    summary = None
                if summary:
                    gen_cache[fname] = summary
                    generated += 1
        summaries[fname] = summary or None
    if generated:
        gen_cache_path.write_text(json.dumps(gen_cache, indent=2, sort_keys=True), encoding="utf-8")
    return summaries, generated


def _resolve_names(
    output_dir: Path,
    source_files: List[str],
    summaries: Dict[str, Optional[str]],
) -> Dict[str, Optional[str]]:
    """Derive a short business name from each (resolved) summary, cached.

    Reuses the ``llm.business_name`` cache (positive hits only) so names —
    including those for on-the-fly generated summaries — are computed once.
    """
    from llm.business_name import generate_business_name, load_cache, save_cache

    cache = load_cache(output_dir)
    names: Dict[str, Optional[str]] = {}
    dirty = False
    for fname in source_files:
        if cache.get(fname):  # positive cache hit
            names[fname] = cache[fname]
            continue
        summary = summaries.get(fname)
        if not summary:
            names[fname] = None
            continue
        label = generate_business_name(summary)
        names[fname] = label or None
        if label:
            cache[fname] = label
            dirty = True
    if dirty:
        save_cache(output_dir, cache)
    return names


def build_graph(
    codebase_dir: Path,
    output_dir: Path,
    use_llm: bool = True,
    generate_summaries: bool = False,
) -> dict:
    blueprint_dir = _find_blueprint_dir(output_dir)
    source_files = _enumerate_source_files(codebase_dir)
    if not source_files:
        raise SystemExit(f"error: no recognised source files found in {codebase_dir}")

    makefile_clusters = _load_makefile_clusters(blueprint_dir)
    file_to_makefiles = _file_to_makefiles(makefile_clusters, source_files)

    # --no-llm produces a purely structural graph: no summaries, no names.
    summaries: Dict[str, Optional[str]] = {f: None for f in source_files}
    business_names: Dict[str, Optional[str]] = {}
    generated = 0
    if use_llm:
        try:
            summaries, generated = _resolve_summaries(
                codebase_dir, blueprint_dir, output_dir, source_files, generate_summaries
            )
            business_names = _resolve_names(output_dir, source_files, summaries)
        except Exception as exc:  # noqa: BLE001
            print(f"warning: LLM summary/name resolution failed ({exc}); omitted", file=sys.stderr)

    nodes: List[dict] = []
    for fname in source_files:
        nodes.append(
            {
                "id": _stem(fname),
                "file": fname,
                "type": _file_type(fname),
                "makefiles": sorted(set(file_to_makefiles.get(fname, []))),
                "business_name": business_names.get(fname),
                "business_summary": summaries.get(fname),
            }
        )

    file_call_graph = build_file_call_graph(codebase_dir, blueprint_dir)
    stem_to_file = {_stem(f): f for f in source_files}
    # Resolve call-graph real-file nodes that exist as blueprints but were not
    # enumerated in the codebase dir, so no internal edge is silently dropped.
    for node in file_call_graph.get("nodes", []):
        if node.get("type") in {"asm", "cpp", "header"} and node["id"] not in stem_to_file:
            stem_to_file[node["id"]] = node.get("file") or node["id"]
    call_edges = _call_edges(file_call_graph, stem_to_file)
    raw_includes, external_includes = include_file_edges(blueprint_dir, source_files)
    include_edges = [
        {"source": e["source_file"], "target": e["target_file"], "type": "include"}
        for e in raw_includes
    ]
    edges = call_edges + include_edges

    return {
        "metadata": {
            "generator": "file_graph.py",
            "codebase_dir": str(codebase_dir),
            "blueprint_dir": str(blueprint_dir),
            "llm_enabled": use_llm,
            "generate_summaries": generate_summaries,
        },
        "nodes": nodes,
        "edges": edges,
        "summary": {
            "file_count": len(nodes),
            "call_edge_count": len(call_edges),
            "include_edge_count": len(include_edges),
            "external_include_count": external_includes,
            "summarised_files": sum(1 for n in nodes if n["business_summary"]),
            "generated_summaries": generated,
            "named_files": sum(1 for n in nodes if n["business_name"]),
        },
    }


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="file_graph.py",
        description="Build a file-level graph (nodes=files with makefiles + business name/summary).",
    )
    p.add_argument("--codebase-dir", required=True, metavar="DIR", help="Directory of raw source files")
    p.add_argument("--output-dir", required=True, metavar="DIR", help="Parser-output root with per-file blueprints")
    p.add_argument("--output", metavar="FILE", help="Write JSON to FILE (default: <output-dir>/file_graph.json)")
    p.add_argument(
        "--no-llm",
        action="store_true",
        help="Structural graph only: no business_summary, no business_name (0 LLM calls)",
    )
    p.add_argument(
        "--generate-summaries",
        action="store_true",
        help="When a blueprint has no business_summary, generate one from the raw source "
        "(extra LLM calls, cached in <output-dir>/generated_summaries.json). Ignored with --no-llm.",
    )
    return p


def main() -> int:
    args = build_arg_parser().parse_args()
    codebase_dir = Path(args.codebase_dir).resolve()
    output_dir = Path(args.output_dir).resolve()
    for d in (codebase_dir, output_dir):
        if not d.exists():
            print(f"error: directory not found: {d}", file=sys.stderr)
            return 1
    if args.generate_summaries and args.no_llm:
        print("warning: --generate-summaries ignored because --no-llm was given", file=sys.stderr)

    graph = build_graph(
        codebase_dir,
        output_dir,
        use_llm=not args.no_llm,
        generate_summaries=args.generate_summaries,
    )
    out_path = Path(args.output) if args.output else output_dir / "file_graph.json"
    out_path.write_text(json.dumps(graph, indent=2), encoding="utf-8")
    s = graph["summary"]
    print(
        f"Wrote file graph to: {out_path}\n"
        f"  files={s['file_count']} call_edges={s['call_edge_count']} "
        f"include_edges={s['include_edge_count']} "
        f"summarised={s['summarised_files']} (generated={s['generated_summaries']}) "
        f"named={s['named_files']}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
