import asyncio
import os
import sys
import argparse
from explainability.pi_rpc import PiRpcProcess

class ExplainabilityModule:
    """
    Explainability module for the ASM-to-C++ modernization project.
    Uses Pi coding agent to answer questions about the codebase and generated analysis outputs.
    """
    def __init__(self, codebase_root, output_dir, model="google/gemini-2.5-flash"):
        self.codebase_root = codebase_root
        self.output_dir = output_dir
        self.model = model
        self.pi = None

    async def start(self):
        """Starts the Pi RPC process."""
        self.pi = PiRpcProcess(
            cwd=self.codebase_root,
            extra_args=["--no-context-files", "--model", self.model, "--skill", ".pi/skills/asm-modernizer-explainability"]
        )
        await self.pi.start()

    async def ask(
        self,
        question: str,
        timeout: float | None = None,
        auto_collect: bool = True,
    ) -> "tuple[str, dict | None]":
        """Ask a question using the asm-modernizer-explainability skill.

        Returns:
            (answer_str, auto_clarify_dict_or_None)

            ``auto_clarify_dict_or_None`` is a pre-built clarify payload
            dict when the evidence contained 3+ downstream callees — the
            caller should emit this as a ``clarify`` SSE event without
            waiting for Pi to generate it.
        """
        if not self.pi:
            await self.start()

        evidence = ""
        auto_clarify = None
        if auto_collect:
            from explainability.evidence_collector import collect_evidence
            # Run the synchronous I/O-bound search in a thread so the
            # event loop is not blocked while the sidecar index is built.
            evidence, auto_clarify = await asyncio.to_thread(
                collect_evidence, question, self.output_dir,
                codebase_root=self.codebase_root,
            )

        # When evidence was pre-collected, Pi only needs to synthesise —
        # no tool calls required, so a shorter timeout is sufficient.
        effective_timeout = timeout
        if evidence and timeout is None:
            effective_timeout = 300.0  # synthesis-only: 5 min is generous

        augmented_question = (evidence + "\n\n" + question) if evidence else question

        contextualized_query = (
            f"\nCurrent Job Context:\n"
            f"- Source Code Root: {self.codebase_root}\n"
            f"- Modernization Output: {self.output_dir}\n\n"
            f"{augmented_question}\n"
        )
        skill_invocation = f"/skill:asm-modernizer-explainability {contextualized_query}"
        answer = await self.pi.prompt(skill_invocation, timeout=effective_timeout)
        return answer, auto_clarify

    async def stop(self):
        """Stops the Pi RPC process."""
        if self.pi:
            await self.pi.stop()
            self.pi = None

class ExplainabilitySession:
    """Persistent Pi session for chatbot-style multi-turn queries.

    Unlike using ``ExplainabilityModule`` directly with separate
    ``start()``/``stop()`` calls per question, ``ExplainabilitySession``
    keeps the Pi process alive so that each follow-up question can
    reference the accumulated conversation context — exactly like a
    chatbot session.

    Use ``new_topic()`` to restart Pi and clear all prior context when
    switching to an unrelated question.

    Usage (async context manager)::

        async with ExplainabilitySession(codebase, output_dir) as session:
            a1, _ = await session.ask("What does INPDAT1 do?")
            a2, _ = await session.ask("Which of those flags are set in ae48?")
            await session.new_topic()          # clear context
            a3, _ = await session.ask("Explain JULSAVE")

    Usage (explicit start/stop)::

        session = ExplainabilitySession(codebase, output_dir)
        await session.start()
        a1, _ = await session.ask("What does EB0U000 mean?")
        a2, _ = await session.ask("Which modules read vs write it?")
        await session.stop()
    """

    def __init__(
        self,
        codebase_root: str,
        output_dir: str,
        model: str = "google/gemini-2.5-flash",
    ) -> None:
        self._module = ExplainabilityModule(codebase_root, output_dir, model)
        self._started = False

    # ── lifecycle ──────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Start the Pi process (called automatically on first ask if omitted)."""
        if not self._started:
            await self._module.start()
            self._started = True

    async def stop(self) -> None:
        """Terminate the Pi process and release resources."""
        await self._module.stop()
        self._started = False

    # ── async context manager ──────────────────────────────────────────────

    async def __aenter__(self) -> "ExplainabilitySession":
        await self.start()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.stop()

    # ── query interface ────────────────────────────────────────────────────

    async def ask(
        self,
        question: str,
        timeout: float | None = None,
        auto_collect: bool = True,
    ) -> "tuple[str, dict | None]":
        """Ask a question; Pi retains full context from all previous turns.

        Returns (answer_str, auto_clarify_dict_or_None).
        """
        if not self._started:
            await self.start()
        return await self._module.ask(question, timeout=timeout, auto_collect=auto_collect)

    async def new_topic(self) -> None:
        """Clear all conversation context and start a fresh Pi session."""
        await self._module.stop()
        await self._module.start()
        self._started = True


async def interactive_shell(module):
    """Interactive chatbot shell backed by a persistent Pi session."""
    session = ExplainabilitySession(
        module.codebase_root,
        module.output_dir,
        module.model,
    )
    await session.start()

    print("ASM Modernizer Explainability Shell  (chatbot mode)")
    print("Pi context is preserved between questions.")
    print("Commands: '!new' to start a new topic | 'exit'/'quit' to stop")

    try:
        while True:
            try:
                question = input("\nQuestion: ").strip()
            except EOFError:
                break

            if not question:
                continue
            if question.lower() in ("exit", "quit"):
                break
            if question.lower() == "!new":
                print("Starting new topic — clearing Pi context...")
                await session.new_topic()
                print("Context cleared. Ask your next question.")
                continue

            print("Analyzing...")
            try:
                answer, _ = await session.ask(question)
                print(f"\nAnswer:\n{answer}")
            except Exception as e:
                print(f"Error: {e}")
    finally:
        await session.stop()

async def main():
    parser = argparse.ArgumentParser(description="ASM Modernizer Explainability Module")
    parser.add_argument("question", nargs="?", help="The question to ask. If omitted, starts an interactive chatbot shell.")
    parser.add_argument("--codebase", default=".", help="Root directory of the project.")
    parser.add_argument("--output", default="output", help="Directory containing analysis outputs.")
    parser.add_argument("--model", default="google/gemini-3-flash-preview", help="Model to use.")

    args = parser.parse_args()
    codebase = os.path.abspath(args.codebase)
    output   = os.path.abspath(args.output)

    if args.question:
        module = ExplainabilityModule(codebase, output, model=args.model)
        try:
            answer, _ = await module.ask(args.question)
            print(answer)
        finally:
            await module.stop()
    else:
        await interactive_shell(
            ExplainabilityModule(codebase, output, model=args.model)
        )

if __name__ == "__main__":
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    asyncio.run(main())
