"""Pi coding-agent RPC client.

Manages a ``pi --mode rpc`` subprocess and exposes a fully-async Python
API that mirrors the JSONL-over-stdin/stdout protocol of the Pi coding
agent.

Protocol — confirmed behaviour
-------------------------------
All messages are newline-delimited JSON (one object per ``\\n``).

Client → Pi (commands)::

    {"type": "<command>", ...fields}

For generative commands (``prompt``, ``follow_up``, ``steer``) Pi sends
back **two** things:

1. An immediate **ACK** response::

       {"type": "response", "command": "prompt", "success": true, "id": "..."}

   The ``data`` field is absent — the ACK only confirms the command was
   accepted.

2. A stream of **events** emitted as generation proceeds::

       {"type": "agent_start"}
       {"type": "turn_start"}
       {"type": "message_start", ...}
       {"type": "message_update", ...}   # repeated — carries text deltas
       {"type": "message_end", ...}
       {"type": "turn_end", ...}
       {"type": "agent_end", "messages": [...]}   # ← final answer here

   The complete answer is in ``agent_end.messages[-1].content[0].text``.

For state-query commands (``get_state``, ``get_messages``, ``bash``, etc.)
the response carries the actual data::

    {"type": "response", "command": "get_state", "success": true,
     "data": { ... }}

Event callbacks are fired for every non-response line regardless of
which command triggered the generation.

Typical usage
-------------
::

    async with PiRpcProcess(cwd="/path/to/source") as pi:
        pi.add_event_listener(lambda e: print(e["type"]))
        answer = await pi.prompt("Explain variable RCNTRL")
        print(answer)

    # Follow-up in the same session:
    async with PiRpcProcess() as pi:
        await pi.prompt("What files modify RCNTRL?")
        answer = await pi.follow_up("Which one is called first?")

    # One-shot helper (handles lifecycle for you):
    answer = await ask_pi("Explain RCNTRL", cwd="/path/to/source")
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from typing import Any, AsyncIterator, Callable

logger = logging.getLogger(__name__)

# ── Timeouts ────────────────────────────────────────────────────────────────
DEFAULT_RESPONSE_TIMEOUT: float = 600.0
_SHUTDOWN_GRACE: float = 5.0
_ACK_TIMEOUT: float = 10.0   # max seconds to receive the initial ACK for prompt

# ── Event name constants ─────────────────────────────────────────────────────
EVT_AGENT_START = "agent_start"
EVT_AGENT_END = "agent_end"
EVT_TURN_START = "turn_start"
EVT_TURN_END = "turn_end"
EVT_MESSAGE_START = "message_start"
EVT_MESSAGE_UPDATE = "message_update"
EVT_MESSAGE_END = "message_end"
EVT_COMPACTION_END = "compaction_end"

# All events that signal a generation is in progress
STREAMING_EVENTS: frozenset[str] = frozenset({
    EVT_AGENT_START, EVT_TURN_START, EVT_MESSAGE_START,
    EVT_MESSAGE_UPDATE, EVT_TURN_END, EVT_MESSAGE_END,
})


# ── Exceptions ────────────────────────────────────────────────────────────────

class PiRpcError(RuntimeError):
    """Raised when Pi returns ``success: false`` or the subprocess fails."""


class PiRpcTimeout(TimeoutError):
    """Raised when Pi does not respond within the configured timeout."""


class PiRpcNotRunning(PiRpcError):
    """Raised when a command is issued before ``start()`` or after ``stop()``."""


# ── Helpers ───────────────────────────────────────────────────────────────────

def _extract_text(agent_end_event: dict) -> str:
    """Pull the final assistant reply text out of an ``agent_end`` event.

    Pi puts the full conversation in ``agent_end.messages``.  We walk
    backwards to find the last assistant message and return its first
    text-type content block.

    Returns an empty string if no assistant text can be found (shouldn't
    happen in normal usage).
    """
    messages: list = agent_end_event.get("messages") or []
    if not messages:
        logger.debug("No messages in agent_end event: %s", agent_end_event)
    for msg in reversed(messages):
        if msg.get("role") != "assistant":
            continue
        for block in (msg.get("content") or []):
            if block.get("type") == "text":
                return block.get("text") or ""
    return ""


# ── Core process wrapper ──────────────────────────────────────────────────────

class PiRpcProcess:
    """Async wrapper around a ``pi --mode rpc`` subprocess.

    **Lifecycle** — start/stop via context manager or explicit calls::

        async with PiRpcProcess(cwd="/src") as pi:
            answer = await pi.prompt("...")

    **Concurrency** — safe for concurrent ``prompt`` calls because each
    call gets a unique UUID correlation id.  Only one generation can run
    at a time (Pi is sequential), so concurrent prompts will queue.

    Args:
        pi_executable: Path or name of the ``pi`` binary.
        cwd: Subprocess working directory — point at the source-code root
            so Pi can read/navigate files.
        env: Environment overrides for the subprocess; ``None`` inherits
            the current process environment.
        response_timeout: Seconds to wait for the ``agent_end`` event
            before raising ``PiRpcTimeout``.
    """

    def __init__(
        self,
        pi_executable: str = "pi",
        cwd: str | None = None,
        env: dict[str, str] | None = None,
        response_timeout: float = DEFAULT_RESPONSE_TIMEOUT,
        no_session: bool = False,
        extra_args: list[str] | None = None,
    ) -> None:
        self._pi_executable = pi_executable
        self._cwd = cwd
        self._env = env
        self._response_timeout = response_timeout
        self._no_session = no_session
        self._extra_args = extra_args or []

        self._proc: asyncio.subprocess.Process | None = None
        self._reader_task: asyncio.Task | None = None

        # Pending futures keyed by correlation id (or command type for
        # id-less state-query commands).  See _call() and _dispatch().
        self._pending: dict[str, asyncio.Future] = {}

        # Pending generation futures — awaited by prompt()/follow_up().
        # Keyed by the correlation id of the triggering command.
        # Resolved with the full ``agent_end`` event dict.
        self._generation_futures: dict[str, asyncio.Future] = {}
        # When only one generation can run at a time, this tracks the
        # current active id so incoming agent_end can be routed correctly.
        self._active_generation_id: str | None = None

        # Global event callbacks — fired for every non-response line.
        self._event_listeners: list[Callable[[dict], None]] = []

        # Serialise concurrent generative commands so we don't send two
        # prompts at the same time (Pi queues them anyway, but this gives
        # us clean future management).
        self._generation_lock = asyncio.Lock()

    # ── Context manager ───────────────────────────────────────────────────────

    async def __aenter__(self) -> "PiRpcProcess":
        await self.start()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.stop()

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Spawn the Pi subprocess and start the background stdout reader.

        Idempotent — subsequent calls while the process is already running
        are no-ops.

        Raises:
            FileNotFoundError: When the ``pi`` binary cannot be found.
            PiRpcError: On subprocess launch failure.
        """
        if self._proc is not None and self._proc.returncode is None:
            return

        cmd = [self._pi_executable, "--mode", "rpc"]
        if self._no_session:
            cmd.append("--no-session")
        cmd.extend(self._extra_args)
        try:
            self._proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self._cwd,
                env=self._env,
            )
        except FileNotFoundError:
            raise FileNotFoundError(
                f"Pi executable '{self._pi_executable}' not found. "
                "Install with: pip install pi-mono-coding"
            )
        except Exception as exc:
            raise PiRpcError(f"Failed to start Pi subprocess: {exc}") from exc

        self._reader_task = asyncio.create_task(
            self._stdout_reader(), name="pi-rpc-stdout-reader"
        )
        logger.info(
            "Pi RPC process started (pid=%d, cwd=%s)",
            self._proc.pid,
            self._cwd or os.getcwd(),
        )

    async def stop(self) -> None:
        """Gracefully terminate the Pi subprocess.

        Sends SIGTERM, waits ``_SHUTDOWN_GRACE`` seconds, then SIGKILLs.
        All waiting futures are cancelled.
        """
        if self._proc is None:
            return

        for fut in list(self._pending.values()) + list(self._generation_futures.values()):
            if not fut.done():
                fut.cancel()
        self._pending.clear()
        self._generation_futures.clear()
        self._active_generation_id = None

        try:
            if self._proc.returncode is None:
                self._proc.terminate()
                try:
                    await asyncio.wait_for(self._proc.wait(), timeout=_SHUTDOWN_GRACE)
                except asyncio.TimeoutError:
                    logger.warning("Pi did not exit in %.0fs — force-killing", _SHUTDOWN_GRACE)
                    self._proc.kill()
        except Exception as exc:
            logger.debug("Error stopping Pi: %s", exc)

        if self._reader_task and not self._reader_task.done():
            self._reader_task.cancel()
            try:
                await self._reader_task
            except (asyncio.CancelledError, Exception):
                pass

        pid = self._proc.pid
        self._proc = None
        self._reader_task = None
        # Yield the event loop so any in-flight I/O callbacks complete before
        # the caller starts a new subprocess.
        await asyncio.sleep(0)
        logger.info("Pi RPC process stopped (pid=%d)", pid)

    @property
    def is_running(self) -> bool:
        """``True`` when the subprocess is alive."""
        return self._proc is not None and self._proc.returncode is None

    # ── Internal I/O ──────────────────────────────────────────────────────────

    async def _send(self, msg: dict[str, Any]) -> None:
        """Serialise *msg* as compact JSONL and write to Pi stdin."""
        if not self.is_running or self._proc is None or self._proc.stdin is None:
            raise PiRpcNotRunning("Pi RPC process is not running. Call start() first.")
        line = json.dumps(msg, separators=(",", ":")) + "\n"
        self._proc.stdin.write(line.encode())
        await self._proc.stdin.drain()

    async def _stdout_reader(self) -> None:
        """Background task: read Pi stdout line-by-line and dispatch."""
        assert self._proc and self._proc.stdout
        reader = self._proc.stdout
        while True:
            try:
                raw = await reader.readline()
            except Exception as exc:
                logger.debug("Pi stdout read error: %s", exc)
                break
            if not raw:
                break  # EOF — process exited
            line = raw.decode(errors="replace").strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                logger.debug("Pi non-JSON: %s", line[:200])
                continue
            self._dispatch(msg)

        # Process gone — fail everything still pending
        returncode = self._proc.returncode if self._proc else "unknown"
        stderr_data = ""
        if self._proc and self._proc.stderr:
            try:
                # Try to read some stderr if available
                stderr_raw = await self._proc.stderr.read()
                stderr_data = stderr_raw.decode(errors="replace")
            except:
                pass
        
        err = PiRpcError(f"Pi process exited unexpectedly with code {returncode}. Stderr: {stderr_data}")
        for fut in list(self._pending.values()) + list(self._generation_futures.values()):
            if not fut.done():
                fut.set_exception(err)
        self._pending.clear()
        self._generation_futures.clear()

    def _dispatch(self, msg: dict[str, Any]) -> None:
        """Route one decoded JSON message to the appropriate future or listeners.

        Routing rules:

        * ``type == "response"`` with ``id`` → match ``_pending[id]``
        * ``type == "response"`` without ``id`` → match ``_pending[command]``
        * ``type == "agent_end"`` → resolve the active generation future
        * everything else → call all event listeners
        """
        msg_type: str = msg.get("type", "")
        logger.debug("Pi ← %s", msg_type)

        if msg_type == "response":
            req_id: str | None = msg.get("id")
            fut = self._pending.pop(req_id, None) if req_id else None
            if fut is None:
                command: str = msg.get("command", "")
                fut = self._pending.pop(command, None)
            if fut is not None and not fut.done():
                if msg.get("success"):
                    # ACKs for generative commands have no data — set None.
                    fut.set_result(msg.get("data"))
                else:
                    fut.set_exception(
                        PiRpcError(msg.get("error") or "Pi returned success=false")
                    )
            return

        if msg_type == EVT_AGENT_END:
            # Resolve the active generation future with the full event dict
            gen_id = self._active_generation_id
            gen_fut = self._generation_futures.pop(gen_id, None) if gen_id else None
            self._active_generation_id = None
            if gen_fut is not None and not gen_fut.done():
                gen_fut.set_result(msg)

        # Fire all registered event listeners for every non-response message
        for listener in self._event_listeners:
            try:
                listener(msg)
            except Exception as exc:
                logger.debug("Event listener raised: %s", exc)

    # ── Internal call helpers ─────────────────────────────────────────────────

    async def _call(self, msg: dict[str, Any], *, timeout: float | None = None) -> Any:
        """Send a **state-query** command and return its ``data``.

        Suitable for: ``get_state``, ``get_messages``, ``bash``,
        ``set_model``, ``compact``, ``get_session_stats``, ``abort``.

        NOT suitable for ``prompt`` / ``follow_up`` — those use
        ``_call_generative()`` because their result arrives via events.
        """
        key: str = msg.get("id") or msg.get("type", str(uuid.uuid4()))
        loop = asyncio.get_event_loop()
        fut: asyncio.Future = loop.create_future()
        self._pending[key] = fut
        try:
            await self._send(msg)
        except Exception:
            self._pending.pop(key, None)
            raise
        _timeout = timeout if timeout is not None else self._response_timeout
        try:
            return await asyncio.wait_for(asyncio.shield(fut), timeout=_timeout)
        except asyncio.TimeoutError:
            self._pending.pop(key, None)
            raise PiRpcTimeout(f"Pi command '{key}' timed out after {_timeout:.0f}s")

    async def _call_generative(
        self,
        msg: dict[str, Any],
        *,
        timeout: float | None = None,
    ) -> str:
        """Send a **generative** command (``prompt`` or ``follow_up``).

        Protocol:
          1. Send command → receive immediate ACK response
          2. Wait for ``agent_end`` event → extract final assistant text

        Returns the assistant reply as a plain string.
        """
        cid: str = msg.get("id") or str(uuid.uuid4())
        msg["id"] = cid

        loop = asyncio.get_event_loop()
        # Register ACK future (keyed by id)
        ack_fut: asyncio.Future = loop.create_future()
        self._pending[cid] = ack_fut
        # Register generation future (keyed by same id)
        gen_fut: asyncio.Future = loop.create_future()
        self._generation_futures[cid] = gen_fut

        self._active_generation_id = cid

        try:
            await self._send(msg)
        except Exception:
            self._pending.pop(cid, None)
            self._generation_futures.pop(cid, None)
            self._active_generation_id = None
            raise

        _timeout = timeout if timeout is not None else self._response_timeout

        # Step 1: Await ACK (quick — should arrive in <1s)
        try:
            await asyncio.wait_for(asyncio.shield(ack_fut), timeout=_ACK_TIMEOUT)
        except asyncio.TimeoutError:
            self._pending.pop(cid, None)
            self._generation_futures.pop(cid, None)
            self._active_generation_id = None
            raise PiRpcTimeout(
                f"Pi did not acknowledge command '{msg.get('type')}' within {_ACK_TIMEOUT:.0f}s"
            )

        # Step 2: Await agent_end event (may take seconds for long generations)
        try:
            agent_end_event = await asyncio.wait_for(
                asyncio.shield(gen_fut), timeout=_timeout
            )
        except asyncio.TimeoutError:
            self._generation_futures.pop(cid, None)
            raise PiRpcTimeout(
                f"Pi generation timed out after {_timeout:.0f}s"
            )

        return _extract_text(agent_end_event)

    # ── Event subscriptions ───────────────────────────────────────────────────

    def add_event_listener(self, callback: Callable[[dict], None]) -> None:
        """Register *callback* — called for every Pi event (not responses).

        The callback receives the raw decoded dict and must not block.
        Exceptions from callbacks are silently swallowed.
        """
        if callback not in self._event_listeners:
            self._event_listeners.append(callback)

    def remove_event_listener(self, callback: Callable[[dict], None]) -> None:
        """Deregister a previously added event listener."""
        try:
            self._event_listeners.remove(callback)
        except ValueError:
            pass

    # ── Public RPC commands ───────────────────────────────────────────────────

    async def prompt(
        self,
        message: str,
        *,
        req_id: str | None = None,
        timeout: float | None = None,
    ) -> str:
        """Send a new top-level prompt and return the agent reply text.

        This acquires ``_generation_lock`` so concurrent callers queue up
        rather than racing.

        Args:
            message: Natural-language prompt text.
            req_id: Optional correlation ID (auto-generated when omitted).
            timeout: Per-call timeout override in seconds.

        Returns:
            The final assistant reply as a plain string.

        Raises:
            PiRpcError: When Pi rejects the command.
            PiRpcTimeout: When the generation takes too long.
        """
        async with self._generation_lock:
            return await self._call_generative(
                {"type": "prompt", "message": message, "id": req_id or str(uuid.uuid4())},
                timeout=timeout,
            )

    async def follow_up(
        self,
        message: str,
        *,
        timeout: float | None = None,
    ) -> str:
        """Send a follow-up message in the current session.

        In Pi's RPC protocol ``follow_up`` only queues a message without
        triggering a new generation turn.  This wrapper therefore sends a
        standard ``prompt`` command so the conversation continues naturally
        while preserving the full session history.

        Args:
            message: Follow-up prompt text.
            timeout: Per-call timeout override.

        Returns:
            The agent reply as a plain string.
        """
        return await self.prompt(message, timeout=timeout)

    async def steer(
        self,
        message: str,
        *,
        timeout: float | None = None,
    ) -> Any:
        """Steer an active generation with additional mid-stream guidance.

        Must be called while a ``prompt`` is actively generating.
        """
        return await self._call({"type": "steer", "message": message}, timeout=timeout)

    async def abort(self) -> Any:
        """Abort the currently running generation."""
        return await self._call({"type": "abort"})

    async def get_state(self) -> dict:
        """Return the current Pi agent session state."""
        result = await self._call({"type": "get_state"})
        return result if isinstance(result, dict) else {}

    async def get_messages(self) -> list:
        """Return the full conversation message history.

        Pi returns ``{"messages": [...]}`` — this helper unpacks that dict
        and returns only the list.
        """
        result = await self._call({"type": "get_messages"})
        if isinstance(result, list):
            return result
        if isinstance(result, dict):
            msgs = result.get("messages")
            if isinstance(msgs, list):
                return msgs
        return []

    async def set_model(self, provider: str, model_id: str) -> Any:
        """Switch the model used by the Pi agent.

        Args:
            provider: e.g. ``"google"``, ``"openai"``, ``"anthropic"``.
            model_id: e.g. ``"gemini-2.5-flash"``, ``"claude-3-5-haiku"``.
        """
        return await self._call(
            {"type": "set_model", "provider": provider, "modelId": model_id}
        )

    async def bash(self, command: str, *, timeout: float | None = None) -> Any:
        """Run a shell command inside Pi's working directory.

        Useful for pre-loading context: e.g. ``pi.bash("cat RCNTRL.asm")``
        before asking a question about it.
        """
        return await self._call({"type": "bash", "command": command}, timeout=timeout)

    async def compact(self) -> Any:
        """Compact the session conversation to reduce context window size."""
        return await self._call({"type": "compact"})

    async def get_session_stats(self) -> dict:
        """Return token / cost statistics for the current session."""
        result = await self._call({"type": "get_session_stats"})
        return result if isinstance(result, dict) else {}

    # ── Streaming helper ──────────────────────────────────────────────────────

    async def prompt_stream(
        self,
        message: str,
        *,
        req_id: str | None = None,
        timeout: float | None = None,
    ) -> AsyncIterator[dict]:
        """Send a prompt and yield Pi events in real time.

        Yields every event dict as it arrives, then the final
        ``{"type": "agent_end", ...}`` as the last item.

        Useful for forwarding real-time progress over WebSockets / SSE.

        Args:
            message: Prompt text.
            req_id: Optional correlation ID.
            timeout: Max seconds to wait for completion.

        Yields:
            Raw Pi event dicts.

        Raises:
            PiRpcError: On agent failure.
            PiRpcTimeout: When the generation times out.
        """
        cid = req_id or str(uuid.uuid4())
        queue: asyncio.Queue[dict] = asyncio.Queue()
        _timeout = timeout if timeout is not None else self._response_timeout

        def _listener(ev: dict) -> None:
            queue.put_nowait(ev)

        self.add_event_listener(_listener)
        try:
            async with self._generation_lock:
                # Register generation future before sending so we don't miss agent_end
                loop = asyncio.get_event_loop()
                gen_fut: asyncio.Future = loop.create_future()
                ack_fut: asyncio.Future = loop.create_future()
                self._pending[cid] = ack_fut
                self._generation_futures[cid] = gen_fut
                self._active_generation_id = cid

                await self._send({"type": "prompt", "message": message, "id": cid})

                # Wait for ACK
                try:
                    await asyncio.wait_for(asyncio.shield(ack_fut), timeout=_ACK_TIMEOUT)
                except asyncio.TimeoutError:
                    raise PiRpcTimeout("Pi did not acknowledge prompt in time")

                # Yield events until agent_end resolves gen_fut
                deadline = loop.time() + _timeout
                while not gen_fut.done():
                    remaining = deadline - loop.time()
                    if remaining <= 0:
                        raise PiRpcTimeout(f"prompt_stream timed out after {_timeout:.0f}s")
                    try:
                        ev = await asyncio.wait_for(queue.get(), timeout=min(remaining, 1.0))
                        yield ev
                    except asyncio.TimeoutError:
                        continue

                # Drain remaining queued events
                while not queue.empty():
                    yield queue.get_nowait()
        finally:
            self.remove_event_listener(_listener)


# ── One-shot convenience function ─────────────────────────────────────────────

async def ask_pi(
    message: str,
    *,
    cwd: str | None = None,
    pi_executable: str = "pi",
    response_timeout: float = DEFAULT_RESPONSE_TIMEOUT,
    on_event: Callable[[dict], None] | None = None,
    no_session: bool = True,
) -> str:
    """One-shot helper — start Pi, ask one question, stop Pi, return the answer.

    Handles the full subprocess lifecycle.  Use ``PiRpcProcess`` directly
    for multi-turn sessions or streaming.

    Args:
        message: The question or prompt.
        cwd: Working directory for Pi (source-code root).
        pi_executable: Path or name of the ``pi`` binary.
        response_timeout: Seconds to wait for the reply.
        on_event: Optional event callback for observing generation progress.
        no_session: When ``True`` (default) Pi is started with ``--no-session``
            so one-shot queries do not pollute the persistent session history.

    Returns:
        The agent reply as a plain string.

    Raises:
        PiRpcError, PiRpcTimeout, FileNotFoundError
    """
    async with PiRpcProcess(
        pi_executable=pi_executable,
        cwd=cwd,
        response_timeout=response_timeout,
        no_session=no_session,
    ) as pi:
        if on_event is not None:
            pi.add_event_listener(on_event)
        return await pi.prompt(message)


# ── Discovery utilities ────────────────────────────────────────────────────────

def find_pi_executable() -> str | None:
    """Return the absolute path to the ``pi`` binary, or ``None`` if not found."""
    import shutil
    return shutil.which("pi")


def assert_pi_installed() -> str:
    """Return the ``pi`` path or raise ``RuntimeError`` with install instructions."""
    path = find_pi_executable()
    if path is None:
        raise RuntimeError(
            "The 'pi' CLI is not installed or not on PATH. "
            "Install with: pip install pi-mono-coding"
        )
    return path
