"""Explainability module for the ASM Modernizer.

Provides natural-language question answering over CPP/ASM pipeline outputs
using the Pi coding agent (via RPC) backed by the analysis indices.
"""
