# Explainability Module

This module provides a way to ask natural language questions about the ASM-to-C++ modernization project codebase and its analysis outputs.

## Components

- `pi_rpc.py`: A Python RPC client for interacting with the Pi coding agent.
- `explain.py`: A command-line tool and Python module that uses `pi_rpc.py` to answer questions with project context.

## Usage

### Command Line

You can ask questions directly from the terminal:

```bash
PYTHONPATH=. python3 explainability/explain.py "What is the purpose of WB1SUPP in xh71.asm?"
```

For an interactive shell:

```bash
PYTHONPATH=. python3 explainability/explain.py
```

### Python API

```python
import asyncio
from explainability.explain import ExplainabilityModule

async def main():
    module = ExplainabilityModule(codebase_root=".", output_dir="output")
    answer = await module.ask("Trace the flow of variable RCNTRL")
    print(answer)
    await module.stop()

if __name__ == "__main__":
    asyncio.run(main())
```

## Features

- **Context Awareness**: Automatically informs the AI about the location of source code and analysis outputs.
- **Hybrid Analysis**: The AI uses both the raw source code and pre-computed analysis JSONs (blueprints, variable universe) to answer questions.
- **Support for Complex Queries**: Can handle questions about variable flow, traceability, dependencies, and program logic.
