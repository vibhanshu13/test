"""Pre-fetch hop index evidence before sending questions to Pi.

Why this exists
---------------
Pi's default behaviour is to run tool calls (search_large_json.py,
read_blueprint.py, bash) to find evidence before answering.  Each tool
call takes 5–30 s; a typical complex query triggers 8–15 calls, easily
exceeding the 600 s timeout.

This module eliminates those tool calls by fetching the same data
programmatically (in Python, in the caller's process) and injecting it
directly into the prompt.  Pi then only needs to synthesise an answer —
pure LLM reasoning — which typically completes in 20–60 s.

For TEST operations (TM, CLI, CLC, CLM) the collector also reads the
source file to include the following branch instruction (JZ, JO, BC,
etc.) as context.  Without the branch target, Pi cannot build decision
trees and resorts to tool calls to find it.

Flow
----
    ask(question)
      ↓
    collect_evidence(question, output_dir)   ← this module
      • extract candidate variable names from question text
      • for each candidate: O(1) sidecar-indexed hop index lookup
      • for TEST operations: read 2 source lines to capture branch target
      • format as a compact evidence block
      ↓
    Pi receives: [evidence block] + [question]
      → synthesises answer without any tool calls
      → returns in 20–60 s instead of 300–900 s
"""
from __future__ import annotations

import json
import re
import sqlite3
import sys
import threading
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Token extraction
# ---------------------------------------------------------------------------

# Minimum / maximum character length for a candidate variable name.
# IBM HLASM labels start with a letter and may contain letters, digits,
# @, #, $, _  (standard HLASM symbol rules).
_VAR_MIN_LEN = 4
_VAR_MAX_LEN = 32

# Tokens to exclude — common English words and HLASM instruction mnemonics
# that appear uppercase in questions but are not variable names.
_SKIP_TOKENS: frozenset[str] = frozenset({
    # English words
    "WITH", "FROM", "THAT", "THIS", "WHAT", "WHICH", "WHEN", "WHERE",
    "HAVE", "BEEN", "WILL", "DOES", "USED", "USES", "CALL", "CALLED",
    "EACH", "BOTH", "ONLY", "ALSO", "AFTER", "BEFORE", "EVERY", "SOME",
    "LINE", "FILE", "TYPE", "NAME", "DATA", "CODE", "BYTE", "WORD",
    "DATE", "TIME", "YEAR", "MONTH", "FLAG", "MODE", "LIST", "STEP",
    "NEXT", "PASS", "SAVE", "LOAD", "READ", "WRITE", "THEN", "ELSE",
    "INPUT", "OUTPUT", "RESULT", "STATUS", "RECORD", "VALUE", "FIELD",
    "FIRST", "SECOND", "THIRD", "LAST", "PHASE", "BLOCK", "TABLE",
    "TRACE", "TRACK", "CROSS", "FLOW", "CHAIN", "GRAPH", "INDEX",
    "SHOW", "GIVE", "MAKE", "TAKE", "FIND", "LOOK", "EXPLAIN",
    "SECTION", "DETAIL", "SUMMARY", "ANALYSIS", "COMPLETE",
    # HLASM instruction mnemonics
    "ENTRC", "ENTNC", "ENTDC", "CREEC", "CREMC", "BALR", "SWISC",
    "MVC", "MVCL", "MVI", "MVHHI",
    "OI", "NI", "XI", "TM", "CLI", "CLC", "CLM",
    "ST", "STH", "STM", "STMH", "STCM",
    "LH", "LR", "LA", "LM", "LHI", "LGHI",
    "AR", "SR", "MR", "DR", "AH", "SH", "MHI",
    "PACK", "UNPK", "CVB", "CVD", "MVN", "MVZ",
    "BC", "BCR", "BZ", "BNZ", "BE", "BNE", "BP", "BNP",
    "JZ", "JNZ", "JO", "JNO", "JM", "JNM", "JAS",
    "DS", "DC", "EQU", "CSECT", "DSECT", "USING", "COPY",
    # Common register names (single letter + digits handled separately)
    "R10", "R11", "R12", "R13", "R14", "R15",
})

# Regex to detect numbered copy suffixes like _01, _02 … _49 or _COPY
_COPY_SUFFIX_RE = re.compile(r'(_\d+|_COPY\w*)$', re.IGNORECASE)


def _canonical_node(name: str) -> str:
    """Strip numbered/copy suffixes from a call-graph node ID.

    Converts 'da76_01' → 'da76', 'da76_COPY1' → 'da76', 'da76' → 'da76'.
    Used to collapse blueprint chunk nodes into their canonical module name.
    """
    return _COPY_SUFFIX_RE.sub('', str(name))


def _is_copy_node(name: str) -> bool:
    """Return True if *name* is a numbered or _COPY variant (not the canonical node)."""
    return bool(_COPY_SUFFIX_RE.search(str(name)))


def _normalise_callgraph(callgraph: dict) -> tuple[set[str], dict[str, int], dict[str, int], dict[str, list[str]]]:
    """Return (canonical_nodes, out_cnt, in_cnt, out_tgts) with numbered copies merged.

    Edges from 'da76_01 → X' are merged into 'da76 → X'.
    Duplicate canonical edges (same src→tgt from multiple copies) are counted once.

    Side effect: when ``callgraph`` is a mutable dict, sets
    ``callgraph['_indirect_pairs']`` to a set of ``(src, tgt)`` pairs that were
    reached via an indirect call (function pointer, virtual dispatch, ASM
    register-indirect, etc.).  Downstream prompt-construction code can use this
    to flag hops to the LLM as "indirect via X".  Backward-compatible — older
    callers ignore the extra key.
    """
    nodes = callgraph.get("nodes", [])
    edges = callgraph.get("edges", [])

    canonical_nodes: set[str] = set()
    for n in nodes:
        cname = _canonical_node(str(n.get("id", ""))).upper()
        if cname:
            canonical_nodes.add(cname)

    out_cnt:  dict[str, int] = {}
    in_cnt:   dict[str, int] = {}
    out_tgts: dict[str, list[str]] = {}
    seen_edges: set[tuple[str, str]] = set()
    indirect_pairs: set[tuple[str, str]] = set()

    try:
        from api.utils.indirection import extract_indirection
    except Exception:
        extract_indirection = None  # type: ignore[assignment]

    for edge in edges:
        src = _canonical_node(str(edge.get("source", ""))).upper()
        tgt = _canonical_node(str(edge.get("target", ""))).upper()
        if not src or not tgt:
            continue
        pair = (src, tgt)
        if pair in seen_edges:
            continue
        seen_edges.add(pair)
        out_cnt[src] = out_cnt.get(src, 0) + 1
        in_cnt[tgt]  = in_cnt.get(tgt, 0) + 1
        out_tgts.setdefault(src, []).append(tgt)
        if extract_indirection is not None:
            env = extract_indirection(edge)
            if env is None:
                for cs in (edge.get("call_sites") or []):
                    if isinstance(cs, dict):
                        env = extract_indirection(cs)
                        if env is not None:
                            break
            if env is not None:
                indirect_pairs.add(pair)

    if isinstance(callgraph, dict):
        callgraph["_indirect_pairs"] = indirect_pairs

    return canonical_nodes, out_cnt, in_cnt, out_tgts


def _extract_candidate_vars(text: str) -> list[str]:
    """Return deduplicated uppercase tokens that look like HLASM variable names.

    Matches tokens that:
      - start with an uppercase letter
      - are _VAR_MIN_LEN to _VAR_MAX_LEN characters long
      - contain only letters, digits, @, #, $, _
      - are not in the skip-list
      - are not single-letter + single-digit register names (R0–R9)
    """
    pattern = (
        r"\b([A-Z][A-Z0-9@#$_]"
        r"{" + str(_VAR_MIN_LEN - 1) + r","
        + str(_VAR_MAX_LEN - 1) + r"})\b"
    )
    found = re.findall(pattern, text.upper())
    seen: dict[str, None] = {}
    result = []
    for t in found:
        if t in _SKIP_TOKENS:
            continue
        # Skip short register aliases R0–R9 (single-letter prefix + one digit)
        if re.match(r'^R[0-9]$', t):
            continue
        if t not in seen:
            seen[t] = None
            result.append(t)
    return result


# ---------------------------------------------------------------------------
# Hop index lookup
# ---------------------------------------------------------------------------

def _hop_index_search(
    hop_index_path: Path,
    var_name: str,
) -> Optional[dict[str, list]]:
    """Fetch all hop entries for *var_name* from the hop index.

    Handles two on-disk formats:

    **Production format** (``build_variable_hop_index.py``, Step 6):
    A flat JSON object whose top-level keys are canonical variable names::

        {
          "_meta": {...},
          "INPDAT1": {"ae48": [{line, expression, operation_type, ...}]},
          "WB1WB:WB1ACCTC": {"da76": [...]}
        }

    Files > 10 MB are extracted via the sidecar-indexed
    ``surgical_json_extract`` (O(1) after first call).

    **Explainability format** (``tools/build_hop_index.py``):
    A JSON array of flat hop records::

        [{"variable": "INPDAT1", "file": "...", "line": 599, ...}, ...]

    Loaded directly (files are typically small).

    Returns ``{file_stem: [hop_dict, ...]}`` or ``None`` if not found.
    """
    if not hop_index_path.exists():
        return None

    try:
        size = hop_index_path.stat().st_size

        if size > 10 * 1024 * 1024:
            # Large file — use the sidecar-indexed O(1) extractor.
            # The sidecar is built on first call and reused thereafter.
            tools_dir = str(Path(__file__).parent.parent / "tools")
            if tools_dir not in sys.path:
                sys.path.insert(0, tools_dir)
            from search_large_json import surgical_json_extract  # type: ignore
            raw = surgical_json_extract(str(hop_index_path), var_name)
            if not raw or raw.startswith(("Key '", "Error")):
                return None
            result = json.loads(raw)
            # Production format: value is {file_stem: [hops]}
            if isinstance(result, dict):
                return result

        else:
            # Small file — load in full and handle array or dict format.
            data = json.loads(hop_index_path.read_text(encoding="utf-8"))

            if isinstance(data, dict):
                # Nested dict format (small version of production format)
                if var_name in data:
                    return data[var_name]
                return None

            if isinstance(data, list):
                # Array format from tools/build_hop_index.py.
                # Preserve file path alongside stem so source context can
                # be read for TEST operations.
                matching = [
                    r for r in data
                    if r.get("variable", "").upper() == var_name.upper()
                ]
                if not matching:
                    return None
                by_file: dict[str, list] = {}
                for r in matching:
                    file_path = r.get("file", "")
                    stem = Path(file_path).stem if file_path else "unknown"
                    by_file.setdefault(stem, []).append({
                        "line":           r.get("line"),
                        # expression: full instruction (e.g. "TM INPDAT1,X'02'")
                        # Falls back to details (comment) if expression absent
                        # (records generated before the expression field was added).
                        "expression":     r.get("expression") or r.get("details", ""),
                        "operation_type": r.get("operation", "other"),
                        # Keep file path so callers can read source context.
                        "_file_path":     file_path,
                    })
                return by_file or None

    except Exception:
        return None

    return None


# ---------------------------------------------------------------------------
# Source context reader
# ---------------------------------------------------------------------------

# Mnemonics that test a condition and are immediately followed by a branch.
# For these we read the next 2 source lines so Pi sees the branch target.
_TEST_MNEMONICS: frozenset[str] = frozenset({
    "TM", "CLI", "CLC", "CLM", "CL", "C", "CH", "CP",
    "CLCL", "CLCLE", "ICM",
})


def _source_snippet(
    file_path: str,
    line_no: int,
    extra_lines: int = 2,
    before_lines: int = 0,
) -> list[str]:
    """Return source lines around line_no.

    Covers the range [line_no - before_lines, line_no + extra_lines] inclusive,
    formatted as ``"  N: <source>"``.

    - ``extra_lines`` lines after line_no (default 2) — used to capture the
      branch instruction (JZ/JO/BC/…) that follows a TEST operation.
    - ``before_lines`` lines before line_no (default 0) — used to reveal the
      containing section label (EQU *) and nearby JAS/ENTRC calls.

    Returns an empty list if the file cannot be read or the line is out of range.
    """
    if not file_path:
        return []
    try:
        path = Path(file_path)
        if not path.exists():
            return []
        src = path.read_text(encoding="utf-8", errors="replace").splitlines()
        idx = line_no - 1          # convert 1-based to 0-based
        if idx < 0 or idx >= len(src):
            return []
        start = max(0, idx - before_lines)
        end   = min(len(src), idx + 1 + extra_lines)
        result = []
        for i in range(start, end):
            result.append(f"  {i + 1:>6}: {src[i].rstrip()}")
        return result
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Data-flow helpers (source operand extraction, DB-module detection)
# ---------------------------------------------------------------------------

# Regex to extract the SOURCE operand from two-operand ASM instructions.
# e.g. "MVC INPDAT1,INCOMP1"  → group(1)="INPDAT1", group(2)="INCOMP1"
#      "L   R4,JULSAVE"       → group(1)="R4",       group(2)="JULSAVE"
#      "ST  R4,JULSAVE"       → group(1)="R4",       group(2)="JULSAVE"
_TWO_OPERAND_RE = re.compile(
    r"^[A-Z]+\s+"          # mnemonic + whitespace
    r"([A-Z0-9@#$_()+,']+)"  # first operand (destination or register)
    r"\s*,\s*"             # comma separator
    r"([A-Z0-9@#$_()+,'=]+)"  # second operand (source)
    , re.IGNORECASE
)

# Operations where the SECOND operand is the data source for the first
_SOURCE_OPS = frozenset({"MVC", "MVI", "L", "LH", "LR", "LA"})
# Operations where the FIRST operand is stored FROM a register
_STORE_OPS  = frozenset({"ST", "STH", "STM"})


def _extract_source_operand(mnemonic: str, expression: str) -> Optional[str]:
    """Return the source variable/value for a data-transfer instruction.

    For MVC/L/LH: source is the second operand.
    For ST/STH:   source is the first operand (the register being stored).
    Returns None if not a recognised data-transfer or no match.
    """
    op = mnemonic.strip().upper()
    m = _TWO_OPERAND_RE.match(expression.strip())
    if not m:
        return None
    dest, src = m.group(1), m.group(2)
    if op in _SOURCE_OPS:
        # Skip immediate hex constants and pure register references
        if src.startswith(("X'", "C'", "=")) or re.match(r'^R\d+$', src, re.I):
            return None
        return src
    if op in _STORE_OPS:
        # For ST, the source is the register (first operand); destination is the address
        return dest if re.match(r'^R\d+$', dest, re.I) else None
    return None


def _build_db_modules(callgraph: dict) -> dict[str, list[str]]:
    """Return a mapping {module_id: [db_targets]} for modules that make
    CREEC (event-chain / database) calls.

    In TPF, CREEC (Create Entry Chain) is the primary mechanism for
    asynchronous database record access.  Any module that issues a CREEC
    call should be flagged as a potential database accessor.
    """
    result: dict[str, list[str]] = {}
    for edge in callgraph.get("edges", []):
        if "_copy" in edge.get("source", "").lower():
            continue
        for site in edge.get("call_sites", []):
            if site.get("instruction", "").upper() == "CREEC":
                src = edge.get("source", "")
                tgt = edge.get("target", "")
                result.setdefault(src, []).append(tgt)
    return result


# ---------------------------------------------------------------------------
# Evidence formatter
# ---------------------------------------------------------------------------

def _format_evidence_block(
    var_name: str,
    by_file: dict[str, list],
    max_files: int = 20,
    max_hops_per_file: int = 25,
    db_modules: Optional[set] = None,
) -> str:
    """Format hop entries as compact, line-oriented evidence text.

    Enhancements over the basic formatter:
    • Inline assembler comments are shown on the instruction line.
    • Surrounding source context (5 before, 2 after) exposes phase labels.
    • Data-flow annotations: for MVC/L/ST hops the SOURCE variable is
      shown as "← from: SRC" so Pi can trace where values originate.
    • DB annotation: if the containing file is a known CREEC/DB-accessing
      module, a warning is emitted so Pi can note potential DB lineage.
    """
    total_files = len(by_file)
    total_hops  = sum(len(v) for v in by_file.values())
    db_mods     = db_modules or set()

    lines: list[str] = [
        f"Variable '{var_name}'  ({total_hops} hops across {total_files} files):"
    ]

    for i, (file_stem, hops) in enumerate(sorted(by_file.items())):
        if i >= max_files:
            lines.append(
                f"  ... {total_files - max_files} more files "
                f"(total {total_hops} hops across {total_files} files)"
            )
            break
        db_flag = "  ⚠ DB/event-chain module (CREEC caller)" if file_stem in db_mods else ""
        lines.append(f"  [{file_stem}]{db_flag}")
        for hop in hops[:max_hops_per_file]:
            ln        = hop.get("line") or "?"
            mnemonic  = (hop.get("operation_type") or "?")[:9]
            expr      = hop.get("expression") or hop.get("variable_name") or ""
            # Data-flow annotation: show contributing source variable
            src_var   = _extract_source_operand(mnemonic, expr)
            src_note  = f"  ← from: {src_var}" if src_var else ""
            lines.append(f"    L{str(ln):>6}  [{mnemonic:<9}]  {expr}{src_note}")
            instr_idx = len(lines) - 1   # remember position BEFORE context lines

            # Include surrounding source context for ALL operation types:
            #   • 5 lines before: exposes the containing section label (EQU *),
            #     preceding JAS/ENTRC calls, and overall code structure so Pi
            #     can determine which phase each ST/L belongs to.
            #   • 2 lines after:  for TEST ops reveals the branch target
            #     (JZ/JO/BC…); for WRITE/LOAD ops reveals the next section
            #     boundary — both are needed for complete decision trees.
            if isinstance(ln, int):
                file_path = hop.get("_file_path", "")
                snippet   = _source_snippet(
                    file_path, ln, before_lines=5, extra_lines=2
                )
                for src_line in snippet:
                    try:
                        n = int(src_line.strip().split(':')[0])
                    except (ValueError, IndexError):
                        continue
                    # Skip blank source lines (line content after ': ' is empty).
                    content = src_line.split(':', 1)[1] if ':' in src_line else ""
                    if not content.strip():
                        continue
                    if n == ln:
                        # Update the instruction line in-place with its full source
                        # so inline assembler comments (e.g. "INDICATE PARS DATE
                        # FORMAT") are visible to Pi — no tool calls needed.
                        lines[instr_idx] = (
                            f"    L{str(ln):>6}  [{mnemonic:<9}]  {content.strip()}"
                        )
                    else:
                        lines.append(f"    {src_line}")

        if len(hops) > max_hops_per_file:
            lines.append(
                f"    ... ({len(hops) - max_hops_per_file} more hops in {file_stem})"
            )

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Cross-file evidence: modifier index, variable universe, C++ universe,
# call graph, and variable identity / renaming
# ---------------------------------------------------------------------------

# Module-level cache for medium-sized JSON files (modifier, cpp universe,
# call graph).  Populated on first access; subsequent calls are O(1).
_JSON_CACHE: dict[str, Any] = {}


def _load_json_cached(path: Path) -> Any:
    """Load and cache a JSON file.  Returns {} on error."""
    key = str(path)
    if key not in _JSON_CACHE:
        try:
            _JSON_CACHE[key] = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            _JSON_CACHE[key] = {}
    return _JSON_CACHE[key]


# ---------------------------------------------------------------------------
# SQLite universe helpers (O(1) per-variable lookups — avoids loading 1–2 GB)
# ---------------------------------------------------------------------------

_EC_CONN_CACHE_MAX = 4
_ec_conn_cache: OrderedDict = OrderedDict()
_ec_conn_lock = threading.Lock()


def _ec_get_conn(db_path: Path) -> Optional[sqlite3.Connection]:
    """Return a cached SQLite connection for *db_path*; None if DB absent."""
    key = str(db_path)
    with _ec_conn_lock:
        if key in _ec_conn_cache:
            _ec_conn_cache.move_to_end(key)
            return _ec_conn_cache[key]
        if not db_path.exists():
            return None
        conn = sqlite3.connect(str(db_path), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        _ec_conn_cache[key] = conn
        _ec_conn_cache.move_to_end(key)
        while len(_ec_conn_cache) > _EC_CONN_CACHE_MAX:
            _, old = _ec_conn_cache.popitem(last=False)
            try:
                old.close()
            except Exception:
                pass
        return conn


def _ec_row_to_entry(row: sqlite3.Row) -> Dict:
    """Decode a SQLite row back into the dict shape used by formatters."""
    entry = dict(row)
    for col in ("scope_chain", "aliased_as", "related_symbols", "metadata", "all_locations"):
        raw = entry.get(col)
        if raw:
            try:
                entry[col] = json.loads(raw)
            except Exception:
                entry[col] = [] if col != "metadata" else {}
        else:
            entry[col] = [] if col != "metadata" else {}
    return entry


def _ec_lookup_variable(db_path: Path, name: str) -> List[Dict]:
    """Fetch all entries for *name* from a universe SQLite DB."""
    conn = _ec_get_conn(db_path)
    if conn is None:
        return []
    try:
        rows = conn.execute(
            "SELECT * FROM variables WHERE name = ?", (name,)
        ).fetchall()
        return [_ec_row_to_entry(r) for r in rows]
    except Exception:
        return []


def _ec_lookup_cpp_aliases(db_path: Path, alias_upper: str) -> List[Dict]:
    """Return C++ variable entries whose aliased_as list contains *alias_upper*."""
    conn = _ec_get_conn(db_path)
    if conn is None:
        return []
    try:
        rows = conn.execute(
            """SELECT v.* FROM variables v
               JOIN aliases a ON a.var_id = v.id
               WHERE a.alias_upper = ?""",
            (alias_upper,),
        ).fetchall()
        return [_ec_row_to_entry(r) for r in rows]
    except Exception:
        return []


def _format_modifier_block(var_name: str, modifier_index: dict) -> str:
    """Cross-file presence from variable_modifier_index.json.

    Returns a one-line summary or '' if the variable is absent.
    """
    idx = modifier_index.get("index", modifier_index)
    files = idx.get(var_name)
    if not files:
        return ""
    unique = sorted(set(files))
    return (
        f"Cross-file presence: '{var_name}' referenced/modified in "
        f"{len(unique)} file(s): {', '.join(unique)}"
    )


def _format_asm_universe_block(var_name: str, asm_universe_path: Path) -> str:
    """ASM variable definition + all-location list from asm_variable_universe.

    Uses the SQLite DB when present (O(1) lookup); falls back to JSON otherwise.
    Returns a compact multi-line block, or '' if not found.
    """
    db_path = asm_universe_path.with_suffix(".db")
    try:
        if db_path.exists():
            entries = _ec_lookup_variable(db_path, var_name)
        elif asm_universe_path.exists():
            data = _load_json_cached(asm_universe_path)
            entries = data.get("variables", {}).get(var_name, [])
        else:
            return ""
        if not entries:
            return ""
        if not isinstance(entries, list):
            entries = [entries]

        lines: list[str] = [f"ASM Definition — '{var_name}':"]
        for entry in entries[:3]:          # ≤3 definitions (usually 1)
            kind  = entry.get("kind", "?")
            scope = entry.get("scope", "?")
            dtype = entry.get("data_type", "?")
            fpath = entry.get("file", "")
            fstem = Path(fpath).stem if fpath else "?"
            ln    = entry.get("line", "?")
            decl  = entry.get("declaration_type", "?")
            init  = entry.get("initial_value") or ""
            lines.append(
                f"  [{fstem} L{ln}]  kind={kind}  scope={scope}  "
                f"type={dtype}  decl={decl}"
                + (f"  value={init!r}" if init and init not in ("*", "0") else "")
            )
            locs = entry.get("all_locations", [])
            if locs:
                lines.append(f"  All locations ({len(locs)}):")
                for loc in locs[:8]:
                    ls = Path(loc.get("file", "")).stem or "?"
                    lines.append(
                        f"    {ls} L{loc.get('line','?')}"
                        f"  [{loc.get('context','?')}]"
                    )
                if len(locs) > 8:
                    lines.append(f"    ... and {len(locs) - 8} more")
            asm_aliases = [str(a) for a in (entry.get("aliased_as") or []) if a]
            if asm_aliases:
                lines.append(f"  ASM aliases: {', '.join(asm_aliases[:6])}")
        return "\n".join(lines)
    except Exception:
        return ""


def _format_cpp_mapping_block(var_name: str, cpp_universe_or_path) -> str:
    """C++ variables that list the ASM variable in their aliased_as field.

    Accepts either a ``Path`` (to cpp_variable_universe.json / .db) or the
    already-loaded dict for backward compatibility.
    Uses the SQLite DB when the .db file is present; falls back to JSON scan.
    Returns a compact block, or '' if no C++ equivalent found.
    """
    alias_upper = var_name.upper()
    matches: list[dict] = []

    if isinstance(cpp_universe_or_path, Path):
        cpp_univ_path: Path = cpp_universe_or_path
        db_path = cpp_univ_path.with_suffix(".db")
        if db_path.exists():
            # Fast path: indexed alias lookup
            for e in _ec_lookup_cpp_aliases(db_path, alias_upper):
                fpath = e.get("file", "")
                matches.append({
                    "cpp_name":    e.get("name", "?"),
                    "file":        Path(fpath).stem if fpath else "?",
                    "line":        e.get("line", "?"),
                    "dtype":       e.get("data_type", "?"),
                    "scope":       e.get("scope", "?"),
                    "all_aliases": e.get("aliased_as", []),
                })
        elif cpp_univ_path.exists():
            cpp_universe = _load_json_cached(cpp_univ_path)
            vars_dict = cpp_universe.get("variables", {})
            for cpp_name, entries in vars_dict.items():
                if not isinstance(entries, list):
                    entries = [entries]
                for e in entries:
                    if alias_upper in [str(a).upper() for a in (e.get("aliased_as") or [])]:
                        fpath = e.get("file", "")
                        matches.append({
                            "cpp_name":    cpp_name,
                            "file":        Path(fpath).stem if fpath else "?",
                            "line":        e.get("line", "?"),
                            "dtype":       e.get("data_type", "?"),
                            "scope":       e.get("scope", "?"),
                            "all_aliases": e.get("aliased_as", []),
                        })
    else:
        # Legacy: caller passed the loaded dict directly
        cpp_universe: dict = cpp_universe_or_path
        vars_dict = cpp_universe.get("variables", {})
        for cpp_name, entries in vars_dict.items():
            if not isinstance(entries, list):
                entries = [entries]
            for e in entries:
                if alias_upper in [str(a).upper() for a in (e.get("aliased_as") or [])]:
                    fpath = e.get("file", "")
                    matches.append({
                        "cpp_name":    cpp_name,
                        "file":        Path(fpath).stem if fpath else "?",
                        "line":        e.get("line", "?"),
                        "dtype":       e.get("data_type", "?"),
                        "scope":       e.get("scope", "?"),
                        "all_aliases": e.get("aliased_as", []),
                    })
    if not matches:
        return ""
    lines: list[str] = [f"C++ Equivalent — '{var_name}':"]
    for m in matches[:4]:
        lines.append(
            f"  C++ name  : {m['cpp_name']}"
            f"  ({m['file']} L{m['line']})"
        )
        lines.append(f"  data type : {m['dtype']}  scope: {m['scope']}")
        if m["all_aliases"]:
            lines.append(
                f"  ASM aliases in C++: "
                + ", ".join(str(a) for a in m["all_aliases"][:6])
            )
    return "\n".join(lines)


def _format_callgraph_block(candidates: list[str], callgraph: dict) -> str:
    """Inter-file call relationships for any candidate that is a known module.

    Returns a compact call-graph excerpt, or '' if none of the candidates
    appear as nodes in the call graph.
    """
    if not callgraph:
        return ""

    canonical_nodes, out_cnt_cg, in_cnt_cg, out_tgts_cg = _normalise_callgraph(callgraph)

    # Which candidates are actually known canonical modules?
    module_cands = [c for c in candidates if c.upper() in canonical_nodes]
    if not module_cands:
        return ""

    cand_set = {c.upper() for c in module_cands}

    # Build per-module structures using normalised edges
    edges = callgraph.get("edges", [])
    calls_from: dict[str, list] = {}
    calls_to:   dict[str, list] = {}
    seen: set[tuple[str, str]] = set()
    for edge in edges:
        src = _canonical_node(str(edge.get("source", ""))).upper()
        tgt = _canonical_node(str(edge.get("target", ""))).upper()
        if not src or not tgt or (src, tgt) in seen:
            continue
        seen.add((src, tgt))
        sites = edge.get("call_sites", [])
        n_sites = len(sites)
        site_details = [
            f"L{s.get('line','?')} {s.get('instruction','?')}"
            for s in sites[:3]
        ]
        if src in cand_set:
            calls_from.setdefault(src, []).append((tgt, n_sites, site_details))
        if tgt in cand_set:
            calls_to.setdefault(tgt, []).append((src, n_sites, site_details))

    lines: list[str] = ["Call Graph:"]
    # Track total distinct outgoing callees across all candidate modules
    total_out_callees: set[str] = set()
    for mod in module_cands:
        mu = mod.upper()
        out = calls_from.get(mu, [])
        inc = calls_to.get(mu, [])
        if not out and not inc:
            continue
        lines.append(f"  [{mod}]")
        if out:
            top = sorted(out, key=lambda x: -x[1])[:8]
            for tgt, n, details in top:
                detail_str = (
                    " [" + ", ".join(details) + "]" if details else ""
                )
                lines.append(f"    → calls {tgt}  ({n} site(s)){detail_str}")
                total_out_callees.add(tgt.upper())
        if inc:
            top = sorted(inc, key=lambda x: -x[1])[:8]
            for src, n, details in top:
                detail_str = (
                    " [" + ", ".join(details) + "]" if details else ""
                )
                lines.append(f"    ← called by {src}  ({n} site(s)){detail_str}")

    return "\n".join(lines) if len(lines) > 1 else ""


def _detect_auto_clarify(
    candidates: list[str],
    callgraph: dict,
    chosen_options: "list[str] | None" = None,
) -> "dict | None":
    """Return a pre-built clarify dict when the callgraph shows 3+ outgoing callees.

    This drives the interactive clarification card entirely from Python so the
    LLM does not need to produce the <clarify> block itself.

    ``chosen_options`` is a list of option strings already chosen by the user
    in this session — matching callees are excluded so the same suggestion is
    never repeated.

    Returns None when no clarification is needed.
    """
    if not callgraph:
        return None

    canonical_nodes, _, _, _ = _normalise_callgraph(callgraph)
    module_cands = [c for c in candidates if c.upper() in canonical_nodes]
    if not module_cands:
        return None

    cand_set = {c.upper() for c in module_cands}
    # Tally unique outgoing callees per candidate (deduplicated across numbered copies)
    callee_sites: dict[str, int] = {}
    seen_pairs: set[tuple[str, str]] = set()
    for edge in callgraph.get("edges", []):
        src = _canonical_node(str(edge.get("source", ""))).upper()
        tgt = _canonical_node(str(edge.get("target", ""))).upper()
        if not src or not tgt or (src, tgt) in seen_pairs:
            continue
        seen_pairs.add((src, tgt))
        if src in cand_set:
            n = len(edge.get("call_sites", []))
            callee_sites[tgt] = callee_sites.get(tgt, 0) + n

    # Filter out callees already chosen by the user in this session
    if chosen_options:
        chosen_upper = {o.split(" —")[0].strip().upper() for o in chosen_options}
        callee_sites = {k: v for k, v in callee_sites.items() if k not in chosen_upper}

    if len(callee_sites) < 3:
        return None

    mod_name = module_cands[0].upper()
    # Top 3 callees by call-site count
    top = [c for c, _ in sorted(callee_sites.items(), key=lambda x: -x[1])[:3]]
    options = [f"{c} — explain what {c} does and why {mod_name} calls it" for c in top]
    options.append("Give me a high-level overview of all the paths")

    return {
        "question": (
            f"{mod_name} hands work off to {len(callee_sites)} different downstream programs — "
            "which one would you like me to explain in detail?"
        ),
        "type": "choice",
        "options": options,
    }


def _format_multihop_chain(
    var_name: str,
    asm_files_or_modifier_idx,
    cpp_universe_or_path,
    hop_index_path: Optional[Path],
    *,
    kb_id: Optional[str] = None,
) -> str:
    """Build a multi-hop cross-linkage chain for *var_name*.

    Shows the full journey:
      ASM file(s) [instruction-level operations]
        → cross-file ASM presence (modifier index)
          → C++ equivalent (aliased_as)

    *asm_files_or_modifier_idx* may be a list of file stems (new callers that
    already resolved the modifier lookup) or the full modifier index dict
    (legacy callers passing the whole dict).

    *cpp_universe_or_path* may be a ``Path`` (to cpp_variable_universe.json/.db)
    or the already-loaded dict (legacy callers).

    *kb_id* is used for DB-first hop lookups when provided.
    """
    if isinstance(asm_files_or_modifier_idx, list):
        asm_files = asm_files_or_modifier_idx
    else:
        mod_idx_inner = asm_files_or_modifier_idx.get("index", asm_files_or_modifier_idx)
        asm_files = sorted(set(mod_idx_inner.get(var_name, [])))
    if not asm_files:
        return ""

    # Hop-level summary per file — DB-first, JSON fallback.
    by_file: dict = {}
    if kb_id:
        try:
            from api.index_db.readers import get_hops_for_variable as _ghv
            by_file = _ghv(
                kb_id, var_name,
                fallback_path=hop_index_path if hop_index_path and hop_index_path.exists() else None,
            ) or {}
        except Exception:
            if hop_index_path and hop_index_path.exists():
                by_file = _hop_index_search(hop_index_path, var_name) or {}
    elif hop_index_path and hop_index_path.exists():
        by_file = _hop_index_search(hop_index_path, var_name) or {}

    file_summaries: list[str] = []
    for f in asm_files[:6]:
        hops = by_file.get(f, [])
        if hops:
            ops = ", ".join(
                f"L{h['line']} {h.get('operation_type','?')}"
                for h in hops[:4]
            )
            file_summaries.append(f"    {f}.asm  [{ops}]")
        else:
            file_summaries.append(f"    {f}.asm")
    if len(asm_files) > 6:
        file_summaries.append(f"    ... and {len(asm_files)-6} more ASM files")

    steps: list[str] = ["ASM hops:\n" + "\n".join(file_summaries)]

    # C++ equivalent — use DB when available to avoid full JSON load
    alias_upper = var_name.upper()
    cpp_entries: List[Dict] = []
    if isinstance(cpp_universe_or_path, Path):
        db_path = cpp_universe_or_path.with_suffix(".db")
        if db_path.exists():
            cpp_entries = _ec_lookup_cpp_aliases(db_path, alias_upper)
        elif cpp_universe_or_path.exists():
            cpp_universe = _load_json_cached(cpp_universe_or_path)
            for cpp_name, entries in cpp_universe.get("variables", {}).items():
                if not isinstance(entries, list):
                    entries = [entries]
                for e in entries:
                    if alias_upper in [str(a).upper() for a in (e.get("aliased_as") or [])]:
                        entry_copy = dict(e)
                        entry_copy.setdefault("name", cpp_name)
                        cpp_entries.append(entry_copy)
    else:
        # Legacy dict path
        for cpp_name, entries in cpp_universe_or_path.get("variables", {}).items():
            if not isinstance(entries, list):
                entries = [entries]
            for e in entries:
                if alias_upper in [str(a).upper() for a in (e.get("aliased_as") or [])]:
                    entry_copy = dict(e)
                    entry_copy.setdefault("name", cpp_name)
                    cpp_entries.append(entry_copy)

    cpp_matches: list[str] = []
    for e in cpp_entries:
        cpp_name = e.get("name", "?")
        fpath    = e.get("file", "")
        fstem    = Path(fpath).stem if fpath else "?"
        cpp_matches.append(
            f"    {cpp_name}  ({fstem} L{e.get('line','?')})"
            f"  type: {e.get('data_type','?')}"
            f"  scope: {e.get('scope','?')}"
        )
    if cpp_matches:
        steps.append("  ↓ C++ equivalent:\n" + "\n".join(cpp_matches[:4]))

    if len(steps) < 2:
        return ""

    return f"Multi-hop chain for '{var_name}':\n" + "\n".join(steps)


def _collect_cross_file_evidence(
    candidates: list[str],
    output_path: Path,
    max_vars: int = 8,
) -> str:
    """Collect cross-file evidence for *candidates* from the broader indices.

    Combines six evidence sources:
      1. modifier_index      — which files modify the variable
      2. asm_universe        — ASM declaration + all-location list
      3. cpp_universe        — C++ equivalents via aliased_as (variable renaming)
      4. multi-hop chain     — full ASM file(s) → C++ journey in one view
      5. blueprint accesses  — per-file read/write breakdown via blueprint
                               variable_lineage edges (distinguishes readers
                               from writers when modifier index doesn't)
      6. call_graph          — inter-module calls; CREEC edges flagged as DB access

    DB lineage: when a variable is modified by a module that makes CREEC
    (TPF event-chain / database) calls, a ⚠ DB lineage note is emitted
    so Pi can flag potential database contributions to that variable's value.

    Returns a formatted evidence section, or '' if nothing is found.
    """
    modifier_p    = output_path / "variable_modifier_index.json"
    asm_univ_p    = output_path / "asm_variable_universe.json"
    cpp_univ_p    = output_path / "cpp_variable_universe.json"
    callgraph_p   = output_path / "file_call_graph.json"
    hop_index_p   = output_path / "variable_hop_index.json"
    _bp = output_path / "asm" / "asm"
    if not _bp.is_dir():
        _bp = output_path / "asm"
    if not _bp.is_dir():
        _bp = output_path
    blueprint_dir = _bp

    # kb_id for DB-first index readers (path: {JOBS_BASE_DIR}/{kb_id}/output)
    kb_id = output_path.parent.name

    # Load call graph from DB (fallback to JSON for old KBs).
    try:
        from api.index_db.readers import (
            get_call_graph as _get_cg,
            get_modifier_files as _get_mod_files,
            get_hops_for_variable as _get_hops,
        )
        callgraph = _get_cg(kb_id, fallback_path=callgraph_p)
        _use_db_readers = True
    except Exception:
        callgraph = _load_json_cached(callgraph_p) if callgraph_p.exists() else {}
        _use_db_readers = False

    # cpp_universe is NOT pre-loaded here — _format_cpp_mapping_block and
    # _format_multihop_chain use per-variable SQLite queries (or lazy JSON
    # load) to avoid pulling a 2 GB file into RAM.

    # Build DB-module lookup from CREEC edges
    db_module_map = _build_db_modules(callgraph)   # {module: [db_targets]}

    var_blocks: list[str] = []
    found = 0

    for var in candidates:
        parts: list[str] = []

        # 1. Cross-file modifier presence + DB lineage annotation
        if _use_db_readers:
            files = sorted(set(_get_mod_files(kb_id, var, fallback_path=modifier_p)))
        else:
            modifier_idx = _load_json_cached(modifier_p) if modifier_p.exists() else {}
            mod_idx_inner = modifier_idx.get("index", modifier_idx)
            files = sorted(set(mod_idx_inner.get(var, [])))
        if files:
            db_files = [f for f in files if f in db_module_map]
            line = (
                f"Cross-file presence: '{var}' referenced/modified in "
                f"{len(files)} file(s): {', '.join(files)}"
            )
            for df in db_files:
                targets = db_module_map[df]
                line += (
                    f"\n  ⚠ DB lineage: '{var}' is modified by {df}, which issues "
                    f"CREEC (database event-chain) call(s) to: {', '.join(targets)}. "
                    f"The value of '{var}' in {df} may originate from or contribute "
                    f"to a database record read/write."
                )
            parts.append(line)

        # 2. ASM variable definition + locations
        asm_block = _format_asm_universe_block(var, asm_univ_p)
        if asm_block:
            parts.append(asm_block)

        # 3. C++ mapping (variable renaming) — uses DB or lazy JSON, no full load
        cpp_block = _format_cpp_mapping_block(var, cpp_univ_p)
        if cpp_block:
            parts.append(cpp_block)

        # 4. Multi-hop chain (ASM → cross-file → C++) — passes pre-computed
        # files list and kb_id for DB-first hop lookups.
        chain = _format_multihop_chain(
            var, files, cpp_univ_p,
            hop_index_p if hop_index_p.exists() else None,
            kb_id=kb_id,
        )
        if chain:
            parts.append(chain)

        # 5. Blueprint read/write access map (distinguishes readers from writers)
        if files and blueprint_dir.is_dir():
            bp_access = _collect_blueprint_accesses(var, files, blueprint_dir)
            if bp_access:
                parts.append(bp_access)

        if parts:
            var_blocks.append(f"[Cross-file: {var}]\n" + "\n".join(parts))
            found += 1
            if found >= max_vars:
                break

    # Call graph (with CREEC DB annotation) for module-shaped candidates
    cg_block = _format_callgraph_block(candidates, callgraph)
    if cg_block:
        var_blocks.append(cg_block)

    if not var_blocks:
        return ""

    divider = "╌" * 66
    body = ("\n" + divider + "\n").join(var_blocks)
    return (
        "┌── CROSS-FILE / C++ EVIDENCE ────────────────────────────────────\n"
        + body
        + "\n└─────────────────────────────────────────────────────────────────"
    )


# ---------------------------------------------------------------------------
# Algorithm-based evidence (file-level traversals)
# ---------------------------------------------------------------------------

# Cache of known blueprint stems per blueprint_dir path.
_BLUEPRINT_STEMS_CACHE: Dict[str, frozenset] = {}


def _get_known_stems(blueprint_dir: Path) -> frozenset:
    """Return file stems for which blueprint JSON files exist (cached)."""
    key = str(blueprint_dir)
    if key not in _BLUEPRINT_STEMS_CACHE:
        try:
            stems: set[str] = set()
            for p in blueprint_dir.glob("*.asm.json"):
                stem = p.name[: p.name.index(".asm.json")]
                stems.add(stem.lower())
            _BLUEPRINT_STEMS_CACHE[key] = frozenset(stems)
        except Exception:
            _BLUEPRINT_STEMS_CACHE[key] = frozenset()
    return _BLUEPRINT_STEMS_CACHE[key]


def _extract_file_stems(text: str, blueprint_dir: Path) -> List[str]:
    """Return known file stems (e.g. 'da76', 'ae48') mentioned in *text*.

    Matching is word-boundary-aware and case-insensitive.  Only stems for
    which a blueprint file actually exists are returned.
    """
    known = _get_known_stems(blueprint_dir)
    if not known:
        return []
    text_lower = text.lower()
    found: List[str] = []
    seen: set[str] = set()
    for stem in sorted(known):
        # Require word-boundary on each side to avoid false positives inside
        # longer tokens (e.g. "da76" must not match inside "da760000").
        if re.search(r'\b' + re.escape(stem) + r'\b', text_lower) and stem not in seen:
            seen.add(stem)
            found.append(stem)
    return found


# Keywords that suggest the question is asking about connections / handoffs
# between two modules.
_CONNECTION_KEYWORDS: frozenset[str] = frozenset({
    "connect", "handoff", "hand off", "hand-off", "pass", "pipeline",
    "between", "share", "shared", "common", "communicate", "interface",
    "transfer", "flow", "across", "from", "to",
})


def _is_connection_question(question: str) -> bool:
    """Return True if the question is asking about inter-module data exchange."""
    q = question.lower()
    return any(kw in q for kw in _CONNECTION_KEYWORDS)


def _format_connection_block(conn: Dict[str, Any]) -> str:
    """Format ``find_all_connections`` output as compact evidence text."""
    if not conn:
        return ""

    fa = conn.get("file_a", "?")
    fb = conn.get("file_b", "?")
    connections = conn.get("connections", {})
    call_summary = conn.get("call_summary", {})
    warnings = conn.get("warnings", [])

    lines: List[str] = [f"Module connections [{fa}] ↔ [{fb}]:"]

    # ── call sites ──────────────────────────────────────────────────────
    for direction, key in (
        (f"  {fa} → {fb}", "a_calls_b"),
        (f"  {fb} → {fa}", "b_calls_a"),
    ):
        sites = call_summary.get(key, [])
        if sites:
            lines.append(f"{direction}  ({len(sites)} call site(s)):")
            for s in sites[:5]:
                raw = s.get("raw_line", "").strip()[:80]
                lines.append(
                    f"    L{s.get('line','?')} [{s.get('instruction','?')}]  {raw}"
                )

    # ── shared DSECTs / work blocks ─────────────────────────────────────
    shared_dsects: List[Dict] = connections.get("shared_dsects", [])
    if shared_dsects:
        lines.append(f"  Shared DSECTs / work blocks ({len(shared_dsects)}):")
        for d in shared_dsects[:10]:
            macro = d.get("display_name") or d.get("macro", "?")
            reg_a = d.get("in_file_a", {}).get("register", "?")
            reg_b = d.get("in_file_b", {}).get("register", "?")
            note  = d.get("note", "")
            lines.append(f"    {macro}  ({fa}: {reg_a} | {fb}: {reg_b})  {note}")
        if len(shared_dsects) > 10:
            lines.append(f"    ... and {len(shared_dsects) - 10} more")

    # ── shared memory fields ─────────────────────────────────────────────
    shared_mem: List[Dict] = connections.get("shared_memory_fields", [])
    if shared_mem:
        names = [f.get("field", "?") for f in shared_mem[:20]]
        lines.append(
            f"  Shared memory fields ({len(shared_mem)}): "
            + ", ".join(names)
            + (f" ... +{len(shared_mem) - 20} more" if len(shared_mem) > 20 else "")
        )
        # Expand details for the first 5 fields
        for field_info in shared_mem[:5]:
            field = field_info.get("field", "?")
            in_a  = field_info.get("in_file_a", [])
            in_b  = field_info.get("in_file_b", [])
            for side_label, side_entries in ((fa, in_a), (fb, in_b)):
                for entry in side_entries[:2]:
                    rel  = entry.get("relation", "?")
                    ln   = entry.get("line", "?")
                    expr = entry.get("expression", "")[:50]
                    scope = entry.get("scope", "")
                    lines.append(
                        f"    [{side_label}] {field}  L{ln} {rel}  {expr}  ({scope})"
                    )

    # ── register handoffs ────────────────────────────────────────────────
    reg_conns: List[Dict] = connections.get("call_boundary_registers", [])
    for rc in reg_conns[:2]:
        passed = rc.get("passed_registers", [])
        if passed:
            lines.append(
                f"  Registers passed at call boundary ({fa}→{fb}):"
            )
            for reg in passed[:6]:
                lines.append(
                    f"    {reg.get('register','?')}: {reg.get('detail','')}"
                )

    if warnings:
        for w in warnings[:3]:
            lines.append(f"  ⚠ {w}")

    return "\n".join(lines) if len(lines) > 1 else ""


def _collect_blueprint_accesses(
    var_name: str,
    modifier_stems: List[str],
    blueprint_dir: Path,
) -> str:
    """Scan blueprint variable_lineage edges to distinguish reads from writes.

    For each file stem in *modifier_stems* that has a blueprint, loads only
    the ``variable_lineage`` section and collects every edge whose source or
    target node ID contains *var_name*.  Groups results by relation type
    (assign/use/define) so Pi can answer "which modules read vs write X".

    Returns a compact formatted block, or ``""`` if no blueprint data found.
    """
    if not blueprint_dir.is_dir() or not modifier_stems:
        return ""

    try:
        sys.path.insert(0, str(blueprint_dir.parent.parent.parent))
        from find_connected_variables import load_blueprint  # type: ignore
    except Exception:
        return ""

    var_upper = var_name.upper()
    # relation → list of (stem, line, expression, scope)
    accesses: Dict[str, List[str]] = {}
    files_with_data: int = 0

    for stem in modifier_stems[:15]:          # cap at 15 files
        bp_path = blueprint_dir / f"{stem}.asm.json"
        if not bp_path.exists():
            continue
        try:
            bp = load_blueprint(bp_path, keys={"variable_lineage"})
            edges = bp.get("variable_lineage", {}).get("edges", [])
            for edge in edges:
                # Match if var_name appears in source or target node id
                src = str(edge.get("source", "")).upper()
                tgt = str(edge.get("target", "")).upper()
                if var_upper not in src and var_upper not in tgt:
                    continue
                rel   = edge.get("relation", "unknown")
                ln    = edge.get("line", "?")
                expr  = str(edge.get("expression", ""))[:50]
                scope = str(edge.get("scope", ""))
                entry = f"    [{stem} L{ln}] {rel}  {expr}  ({scope})"
                accesses.setdefault(rel, []).append(entry)
            if any(var_upper in str(e.get("source","")).upper()
                   or var_upper in str(e.get("target","")).upper()
                   for e in edges):
                files_with_data += 1
        except Exception:
            continue

    if not accesses:
        return ""

    lines: List[str] = [f"Blueprint access map for '{var_name}' ({files_with_data} file(s)):"]
    for rel in ("assign", "use", "define", "unknown"):
        entries = accesses.get(rel, [])
        if not entries:
            continue
        label = {"assign": "WRITE", "use": "READ", "define": "DECLARATION"}.get(rel, rel.upper())
        lines.append(f"  {label} ({len(entries)} occurrence(s)):")
        for e in entries[:10]:
            lines.append(e)
        if len(entries) > 10:
            lines.append(f"    ... and {len(entries) - 10} more")
    return "\n".join(lines)


_GRAPH_KEYWORDS: frozenset[str] = frozenset({
    "graph", "diagram", "draw", "chart", "map",
    "visualize", "visualise", "show flow", "show path",
    "show connections", "flow chart", "flowchart",
})


def _is_graph_question(question: str) -> bool:
    """Return True when the question explicitly asks for a diagram or graph."""
    q = question.lower()
    return any(kw in q for kw in _GRAPH_KEYWORDS)


def _build_expanded_callgraph(candidates: list[str], callgraph: dict, hops: int = 2) -> str:
    """BFS-expand the callgraph ``hops`` levels from each candidate module.

    Used for graph/diagram questions so Pi has enough edges to draw a
    meaningful Mermaid diagram, not just immediate callers/callees.
    """
    if not callgraph or not candidates:
        return ""

    canonical_nodes, _, _, _ = _normalise_callgraph(callgraph)
    module_cands = [c.upper() for c in candidates if c.upper() in canonical_nodes]
    if not module_cands:
        return ""

    # Build adjacency from normalised (deduplicated) edges
    adj: dict[str, list] = {}
    seen_adj: set[tuple[str, str]] = set()
    for edge in callgraph.get("edges", []):
        src = _canonical_node(str(edge.get("source", ""))).upper()
        tgt = _canonical_node(str(edge.get("target", ""))).upper()
        if not src or not tgt or (src, tgt) in seen_adj:
            continue
        seen_adj.add((src, tgt))
        instr = (edge.get("instructions") or ["?"])[0]
        n = len(edge.get("call_sites", []))
        adj.setdefault(src, []).append((tgt, n, instr))

    # BFS forward from each candidate
    visited: set[str] = set()
    frontier: set[str] = set(module_cands)
    all_edges: list[tuple] = []

    for _ in range(hops):
        next_frontier: set[str] = set()
        for src in frontier:
            if src in visited:
                continue
            for tgt, n, instr in adj.get(src, []):
                all_edges.append((src, tgt, n, instr))
                next_frontier.add(tgt)
        visited |= frontier
        frontier = next_frontier - visited

    if not all_edges:
        return ""

    _MAX_GRAPH_EDGES = 15
    lines = ["Program Flow Graph:"]
    for src, tgt, n, instr in all_edges[:_MAX_GRAPH_EDGES]:
        lines.append(f"  {src} →[{instr}]→ {tgt}  ({n} call site(s))")
    if len(all_edges) > _MAX_GRAPH_EDGES:
        lines.append(f"  ... and {len(all_edges) - _MAX_GRAPH_EDGES} more edges")

    return "\n".join(lines)


def _build_system_overview(callgraph: dict) -> str:
    """Return a structured system overview for broad questions with no specific candidates.

    Provides structural analysis (entry programs, orchestrators, shared utilities,
    module families) so Pi can describe the system's architecture and purpose even
    when no variable or module name was identified in the question.
    """
    if not callgraph:
        return ""

    canonical_nodes, out_cnt, in_cnt, out_tgts = _normalise_callgraph(callgraph)
    main_nodes = sorted(canonical_nodes)
    if not main_nodes:
        return ""

    total_edges = sum(out_cnt.values())

    # Entry programs: no callers and at least one outgoing call (true roots)
    entry_programs = sorted(
        [m for m in main_nodes if in_cnt.get(m, 0) == 0 and out_cnt.get(m, 0) > 0],
        key=lambda m: -out_cnt.get(m, 0),
    )

    # Top orchestrators: highest outgoing call counts (>= 5)
    top_orchestrators = sorted(
        [(m, out_cnt.get(m, 0)) for m in main_nodes if out_cnt.get(m, 0) >= 5],
        key=lambda x: -x[1],
    )[:10]

    # Shared utilities: called by the most distinct programs (>= 3)
    top_utilities = sorted(
        [(m, in_cnt.get(m, 0)) for m in main_nodes if in_cnt.get(m, 0) >= 3],
        key=lambda x: -x[1],
    )[:10]

    # Module families by 2-letter alphabetic prefix
    families: dict[str, list[str]] = {}
    for m in main_nodes:
        prefix = "".join(c for c in m[:2] if c.isalpha())
        if prefix:
            families.setdefault(prefix, []).append(m)
    large_families = {k: v for k, v in families.items() if len(v) >= 3}

    lines: list[str] = [
        f"System Overview — {len(main_nodes)} modules, {total_edges} call edges",
        "",
    ]

    if entry_programs:
        lines.append("Entry programs (no callers — top-level program or standalone entry point):")
        for m in entry_programs[:8]:
            callees = ", ".join(sorted(out_tgts.get(m, []))[:5])
            lines.append(f"  {m:20s}  calls {out_cnt.get(m, 0):3d} programs  → {callees}")
        lines.append("")

    if top_orchestrators:
        lines.append("Key orchestrators (most downstream programs called):")
        for m, n in top_orchestrators:
            callees = ", ".join(sorted(out_tgts.get(m, []))[:5])
            lines.append(f"  {m:20s}  calls {n:3d} programs  → {callees}")
        lines.append("")

    if top_utilities:
        lines.append("Shared utilities (called by most programs):")
        for m, n in top_utilities:
            lines.append(f"  {m:20s}  called by {n:3d} programs")
        lines.append("")

    if large_families:
        lines.append("Module families (related program groups by naming convention):")
        for prefix in sorted(large_families.keys()):
            mods = sorted(large_families[prefix])
            suffix = " ..." if len(mods) > 8 else ""
            lines.append(f"  {prefix}* ({len(mods)} programs): {', '.join(mods[:8])}{suffix}")
        lines.append("")

    lines.append("Full module list:")
    for mod in main_nodes:
        out = out_cnt.get(mod, 0)
        inc = in_cnt.get(mod, 0)
        callees = ", ".join(sorted(out_tgts.get(mod, []))[:4])
        suffix = f"  → {callees}" if callees else ""
        lines.append(f"  {mod:20s}  calls={out:3d}  called_by={inc:3d}{suffix}")

    return "\n".join(lines)


def _collect_algorithm_evidence(
    question: str,
    file_stems: List[str],
    blueprint_dir: Path,
    asm_dir: Optional[Path],
) -> str:
    """Run implemented analysis algorithms and return formatted evidence.

    Algorithms dispatched based on question content:

    * **find_all_connections** — when two known file stems appear together in
      a question that asks about connections, handoffs, or shared state between
      modules.  Returns shared DSECTs, shared memory fields, and register
      handoffs at the call boundary.  Typical latency: < 1 s.

    * Additional algorithms (LineageTracer, CallChainTraversal, etc.) are
      available in the codebase and can be added here for specific intents.
    """
    if not file_stems:
        return ""

    blocks: List[str] = []

    # ── find_all_connections: two-file questions ─────────────────────────
    # Skip for diagram questions — the graph section already provides the
    # structural view, and find_all_connections can take 20-30s on large
    # codebases due to blueprint scanning.
    if (
        len(file_stems) >= 2
        and _is_connection_question(question)
        and not _is_graph_question(question)
        and asm_dir is not None
        and blueprint_dir.is_dir()
    ):
        stem_a, stem_b = file_stems[0], file_stems[1]
        bp_a = blueprint_dir / f"{stem_a}.asm.json"
        bp_b = blueprint_dir / f"{stem_b}.asm.json"
        if bp_a.exists() and bp_b.exists():
            try:
                sys.path.insert(0, str(blueprint_dir.parent.parent.parent))
                from find_connected_variables import find_all_connections  # type: ignore
                conn = find_all_connections(
                    stem_a, stem_b,
                    blueprint_dir=blueprint_dir,
                    asm_dir=asm_dir,
                )
                block = _format_connection_block(conn)
                if block:
                    blocks.append(block)
            except Exception:
                pass

    if not blocks:
        return ""

    divider = "╌" * 66
    body = ("\n" + divider + "\n").join(blocks)
    return (
        "┌── ALGORITHM RESULTS (find_all_connections) ───────────────────────\n"
        + body
        + "\n└─────────────────────────────────────────────────────────────────"
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_EVIDENCE_HEADER = """\
╔══════════════════════════════════════════════════════════════════╗
║  PRE-COLLECTED EVIDENCE — MANDATORY PROTOCOL C                  ║
║  • Do NOT call any tools (search, read, bash, find, etc.)       ║
║  • Write a COMPLETE answer using ALL sections of the evidence.  ║
║  • NEVER respond with only a <clarify> block — always answer.   ║
║  • For graph/diagram questions: draw the Mermaid diagram first. ║
║  • A <clarify> block is OPTIONAL and goes AFTER a full answer.  ║
╚══════════════════════════════════════════════════════════════════╝"""

_EVIDENCE_FOOTER = """\
╔══════════════════════════════════════════════════════════════════╗
║  END OF PRE-COLLECTED EVIDENCE                                  ║
║  REQUIRED: Write a complete business-friendly answer above.     ║
║  OPTIONAL: Add a <clarify> block after your answer to offer     ║
║  one focused follow-up path. Never replace the answer with it.  ║
╚══════════════════════════════════════════════════════════════════╝"""


def collect_evidence(
    question: str,
    output_dir: str | Path,
    *,
    max_vars: int = 8,
    codebase_root: str | Path | None = None,
    chosen_options: "list[str] | None" = None,
) -> "tuple[str, dict | None]":
    """Pre-collect evidence for variables/modules mentioned in *question*.

    Queries three evidence layers and combines them:

    1. **Hop index** (``variable_hop_index.json``) — instruction-level
       usage trace for variables in the primary ASM file, with inline
       assembler comments and surrounding source context.

    2. **Cross-file indices** — four broader indices that cover the
       full project:
       * ``variable_modifier_index.json``  — which files touch a variable
       * ``asm_variable_universe.json``    — declaration type, scope, all
         file/line locations
       * ``cpp_variable_universe.json``    — C++ name + ``aliased_as`` list
         that maps ASM → C++ variable renaming
       * ``file_call_graph.json``          — inter-module call relationships
         (also activated for any file stems mentioned in the question, e.g.
         "da76", "ae48")

    3. **Algorithm results** — implemented traversal algorithms called
       directly when the question pattern matches:
       * ``find_all_connections`` — shared DSECTs, memory fields, and
         register handoffs between two named modules.

    All results are injected directly into the prompt so Pi can synthesise
    an answer without any tool calls (Protocol C).

    Args:
        question:       The natural-language question text.
        output_dir:     Path to the pipeline output directory.
        max_vars:       Max distinct variables to look up per layer.
        codebase_root:  Root directory of the ASM source files.  Required for
                        algorithm-based evidence (find_all_connections).
                        When ``None`` the algorithm layer is skipped.

    Returns:
        Tuple of (evidence_block_str, auto_clarify_dict_or_None).
        ``evidence_block_str`` is ``""`` when nothing is found.
        ``auto_clarify_dict_or_None`` is a pre-built clarify payload dict
        when the evidence contains 3+ downstream callees (drives the
        interactive clarification card without relying on Pi to generate it).
    """
    output_path   = Path(output_dir)
    # kb_id is the job/KB identifier — the directory structure is
    # {JOBS_BASE_DIR}/{kb_id}/output, so output_path.parent.name gives kb_id.
    kb_id         = output_path.parent.name
    hop_index     = output_path / "variable_hop_index.json"
    # Blueprint dir: try output/asm/asm → output/asm → output root (flat layout)
    blueprint_dir = output_path / "asm" / "asm"
    if not blueprint_dir.is_dir():
        blueprint_dir = output_path / "asm"
    if not blueprint_dir.is_dir():
        blueprint_dir = output_path
    asm_dir       = Path(codebase_root) if codebase_root else None

    candidates = _extract_candidate_vars(question)

    # Extract known file stems mentioned in the question (e.g. "da76", "ae48").
    # These are added (uppercased) to the candidate list so the call-graph block
    # activates even when no variable names are found in the question.
    file_stems = (
        _extract_file_stems(question, blueprint_dir)
        if blueprint_dir.is_dir()
        else []
    )
    stem_candidates = [s.upper() for s in file_stems]
    all_candidates  = candidates + [
        s for s in stem_candidates if s not in candidates
    ]

    # ── Load call graph once; build DB-module set for hop-level annotation ─
    callgraph_p = output_path / "file_call_graph.json"
    try:
        from api.index_db.readers import get_call_graph as _get_call_graph
        callgraph = _get_call_graph(kb_id, fallback_path=callgraph_p)
    except Exception:
        callgraph = _load_json_cached(callgraph_p) if callgraph_p.exists() else {}
    db_mods     = set(_build_db_modules(callgraph).keys())

    # ── Load identity index for canonical key resolution ──────────────────
    # Hop index keys are canonical identity keys (e.g. "ae48:INPDAT1"),
    # not plain variable names ("INPDAT1").  We resolve only the candidate
    # names we actually need using per-name DB lookups (one query per var)
    # instead of loading the entire by_name table into RAM.
    identity_p = output_path / "variable_identity_index.json"
    identity_by_name: dict[str, str] = {}
    if candidates:
        try:
            from api.index_db.readers import get_canonical_key as _get_ck
            for _var in candidates:
                for _name in (_var, _var.upper()):
                    _ck = _get_ck(kb_id, _name, fallback_path=identity_p)
                    if _ck:
                        identity_by_name[_name] = _ck
                        identity_by_name[_name.upper()] = _ck
        except Exception:
            # Fallback: JSON file (old KBs without DB-backed identity index)
            if identity_p.exists():
                try:
                    id_index = _load_json_cached(identity_p)
                    identity_by_name = id_index.get("by_name", {}) if isinstance(id_index, dict) else {}
                except Exception:
                    pass

    # ── Layer 1: hop index — instruction-level variable trace ──────────────
    hop_blocks: list[str] = []
    if candidates:
        try:
            from api.index_db.readers import get_hops_for_variable as _get_hops
            _hop_fallback = hop_index if hop_index.exists() else None
            for var in candidates:
                # Resolve plain name → canonical key (e.g. INPDAT1 → ae48:INPDAT1)
                canonical_key = identity_by_name.get(var, identity_by_name.get(var.upper(), var))
                by_file = _get_hops(kb_id, canonical_key, fallback_path=_hop_fallback)
                # Fallback to plain name in case old-format index uses plain keys
                if not by_file and canonical_key != var:
                    by_file = _get_hops(kb_id, var, fallback_path=_hop_fallback)
                if by_file:
                    hop_blocks.append(
                        _format_evidence_block(var, by_file, db_modules=db_mods)
                    )
                    if len(hop_blocks) >= max_vars:
                        break
        except Exception:
            # Legacy fallback: use _hop_index_search if DB readers unavailable
            if hop_index.exists():
                for var in candidates:
                    canonical_key = identity_by_name.get(var, identity_by_name.get(var.upper(), var))
                    by_file = _hop_index_search(hop_index, canonical_key)
                    if not by_file and canonical_key != var:
                        by_file = _hop_index_search(hop_index, var)
                    if by_file:
                        hop_blocks.append(
                            _format_evidence_block(var, by_file, db_modules=db_mods)
                        )
                        if len(hop_blocks) >= max_vars:
                            break

    # ── Layer 2: cross-file / C++ evidence ────────────────────────────────
    # Use all_candidates so callgraph block activates for named file stems
    # even when no variable-name candidates are found.
    cross_section = _collect_cross_file_evidence(
        all_candidates, output_path, max_vars=max_vars
    )

    # ── Layer 3: algorithm-based evidence ─────────────────────────────────
    algo_section = _collect_algorithm_evidence(
        question, file_stems, blueprint_dir, asm_dir
    )

    # ── Auto-clarify detection (Python-driven, does not depend on Pi) ─────
    auto_clarify = _detect_auto_clarify(all_candidates, callgraph, chosen_options)

    # ── Layer 4: expanded callgraph for graph/diagram questions ───────────
    graph_section = ""
    if _is_graph_question(question) and all_candidates:
        graph_section = _build_expanded_callgraph(all_candidates, callgraph, hops=1)

    # ── Fallback: system overview when no specific evidence was found ──────
    overview_section = ""
    if not hop_blocks and not cross_section and not algo_section and not graph_section:
        overview_section = _build_system_overview(callgraph)
        if not overview_section:
            return "", auto_clarify

    # ── Assemble final evidence block ─────────────────────────────────────
    sections: list[str] = []
    if hop_blocks:
        divider = "─" * 66
        sections.append(("\n" + divider + "\n").join(hop_blocks))
    if cross_section:
        sections.append(cross_section)
    if algo_section:
        sections.append(algo_section)
    if graph_section:
        sections.append(graph_section)
    if overview_section:
        sections.append(overview_section)

    body = "\n\n".join(sections)
    return _EVIDENCE_HEADER + "\n\n" + body + "\n\n" + _EVIDENCE_FOOTER, auto_clarify
