#!/usr/bin/env python3
"""
cluster_analyzer.py — 4-Pillar cluster-aware utility detection.

Improves on utility_detector.py + utility_llm_classifier.py by adding:

  Pillar 1 — Structural signals        (5-factor weighted score per file)
  Pillar 2 — Graph topology            (connected-component cluster structure)
  Pillar 3 — LLM semantic / cluster    (whole-cluster analysis, not per-file)
  Pillar 4 — Mutual validation         (inter-pillar agreement → confidence)

Key new concepts:
  Cluster   = A set of files connected by call/include edges (weakly connected
              component). The cluster is the unit of classification, not the
              individual file.
  Cluster Role = CRITICAL_CLUSTER  — implements unique business logic
                 UTILITY_CLUSTER   — shared infrastructure / data layouts
                 MIXED_CLUSTER     — contains both (needs LLM to separate)

Usage:
  # Step 1 — build deterministic index (same as utility_detector.py build)
  python3 utility_detector.py build --src temp/asm --db analysis.db

  # Step 2 — form clusters + compute all 4 pillars
  python3 cluster_analyzer.py build --db analysis.db --src temp/asm

  # Step 3 — list clusters with roles and confidence
  python3 cluster_analyzer.py clusters --db analysis.db

  # Step 4 — find files+clusters for a given functionality
  python3 cluster_analyzer.py find --functionality "global limits" --db analysis.db
  python3 cluster_analyzer.py find --functionality "account maintenance" --db analysis.db

  # Step 5 — LLM names + describes each cluster (optional, requires ANTHROPIC_API_KEY)
  python3 cluster_analyzer.py llm-name --db analysis.db --src temp/asm

  # Inspect a specific cluster
  python3 cluster_analyzer.py info --cluster 1 --db analysis.db

  # Show confidence breakdown for all files
  python3 cluster_analyzer.py confidence --db analysis.db
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import sqlite3
import sys
import textwrap
import time
from collections import defaultdict, deque
from pathlib import Path
from typing import Dict, Iterator, List, Optional, Set, Tuple

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

ANTHROPIC_DEFAULT_MODEL = "claude-sonnet-4-5"
GEMINI_DEFAULT_MODEL    = "gemini-2.5-flash"   # Gemini Flash 3 (stable)

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

_CLUSTER_DDL = """
-- Connected-component clusters
CREATE TABLE IF NOT EXISTS clusters (
    id            INTEGER PRIMARY KEY,
    name          TEXT    DEFAULT 'Unnamed',
    purpose       TEXT    DEFAULT '',
    det_role      TEXT    DEFAULT 'UNKNOWN',   -- from deterministic score
    llm_role      TEXT,                         -- from LLM cluster analysis
    final_role    TEXT    DEFAULT 'UNKNOWN',   -- resolved role
    det_score     REAL    DEFAULT 0.5,          -- avg member utility_score
    graph_score   REAL    DEFAULT 0.5,          -- graph topology utility score
    llm_score     REAL,
    final_score   REAL    DEFAULT 0.5,
    confidence    REAL    DEFAULT 0.0,          -- inter-pillar agreement
    member_count  INTEGER DEFAULT 0,
    entry_stems   TEXT    DEFAULT '[]',         -- JSON: entry-point file stems
    llm_named     INTEGER DEFAULT 0
);

-- File ↔ cluster membership
CREATE TABLE IF NOT EXISTS file_clusters (
    file_id    INTEGER NOT NULL REFERENCES files(id),
    cluster_id INTEGER NOT NULL REFERENCES clusters(id),
    is_entry   INTEGER DEFAULT 0,
    is_leaf    INTEGER DEFAULT 0,
    role       TEXT    DEFAULT 'MEMBER',
    PRIMARY KEY (file_id)
);

-- Cross-cluster call edges
CREATE TABLE IF NOT EXISTS cluster_edges (
    src_cluster_id INTEGER NOT NULL,
    dst_cluster_id INTEGER NOT NULL,
    call_count     INTEGER DEFAULT 1,
    PRIMARY KEY (src_cluster_id, dst_cluster_id)
);

-- Per-file pillar scores (for confidence model)
CREATE TABLE IF NOT EXISTS file_pillars (
    file_id       INTEGER PRIMARY KEY REFERENCES files(id),
    p1_structural REAL DEFAULT -1.0,
    p2_graph      REAL DEFAULT -1.0,
    p3_llm        REAL DEFAULT -1.0,
    agreement     REAL DEFAULT -1.0,   -- 1 - std(available pillars)
    final_score   REAL DEFAULT -1.0,
    confidence    REAL DEFAULT -1.0
);

-- FTS5 full-text index on cluster names / purposes for functionality search
CREATE VIRTUAL TABLE IF NOT EXISTS cluster_fts USING fts5(
    cluster_id UNINDEXED,
    name,
    purpose,
    stems_text,
    tokenize = 'ascii'
);
"""

# Idempotently add new columns (ALTER TABLE is not in _CLUSTER_DDL because
# SQLite does not support ALTER TABLE IF NOT EXISTS)
_MIGRATE_FILES_COLS = [
    ("ALTER TABLE files ADD COLUMN graph_score REAL DEFAULT -1.0",),
    ("ALTER TABLE files ADD COLUMN final_score REAL DEFAULT -1.0",),
    ("ALTER TABLE files ADD COLUMN confidence  REAL DEFAULT -1.0",),
]


def setup_cluster_schema(db_path: str) -> None:
    con = sqlite3.connect(db_path)
    for stmt in _CLUSTER_DDL.strip().split(";"):
        s = stmt.strip()
        if s:
            try:
                con.execute(s)
            except sqlite3.OperationalError as e:
                if "already exists" not in str(e).lower():
                    raise
    for (stmt,) in _MIGRATE_FILES_COLS:
        try:
            con.execute(stmt)
        except sqlite3.OperationalError:
            pass  # column already exists
    con.commit()
    con.close()


# ---------------------------------------------------------------------------
# Role thresholds (re-used from utility_detector.py)
# ---------------------------------------------------------------------------

ROLE_THRESHOLDS = [
    (0.80, "PURE_UTILITY"),
    (0.60, "SHARED_INFRA"),
    (0.40, "BRIDGE"),
    (0.20, "FUNCTIONAL"),
    (0.00, "CRITICAL"),
]
CLUSTER_ROLE_THRESHOLDS = [
    (0.70, "UTILITY_CLUSTER"),
    (0.35, "MIXED_CLUSTER"),
    (0.00, "CRITICAL_CLUSTER"),
]


def _role(score: float) -> str:
    for thr, label in ROLE_THRESHOLDS:
        if score >= thr:
            return label
    return "CRITICAL"


def _cluster_role(score: float) -> str:
    for thr, label in CLUSTER_ROLE_THRESHOLDS:
        if score >= thr:
            return label
    return "CRITICAL_CLUSTER"


# ---------------------------------------------------------------------------
# Pillar 2 — Graph topology via streaming Union-Find (weakly connected comps)
# ---------------------------------------------------------------------------

class UnionFind:
    """Path-compressed union-find. O(E·α(V)) total, O(V) memory."""

    def __init__(self):
        self._parent: Dict[int, int] = {}
        self._rank:   Dict[int, int] = {}

    def find(self, x: int) -> int:
        if x not in self._parent:
            self._parent[x] = x
            self._rank[x] = 0
        root = x
        while self._parent[root] != root:
            root = self._parent[root]
        # path compression
        while self._parent[x] != root:
            self._parent[x], x = root, self._parent[x]
        return root

    def union(self, x: int, y: int) -> None:
        rx, ry = self.find(x), self.find(y)
        if rx == ry:
            return
        if self._rank[rx] < self._rank[ry]:
            rx, ry = ry, rx
        self._parent[ry] = rx
        if self._rank[rx] == self._rank[ry]:
            self._rank[rx] += 1

    def components(self) -> Dict[int, List[int]]:
        """Return {root_id: [member_ids]}."""
        result: Dict[int, List[int]] = defaultdict(list)
        for node in list(self._parent.keys()):
            result[self.find(node)].append(node)
        return dict(result)


# ---------------------------------------------------------------------------
# Cluster formation
# ---------------------------------------------------------------------------

class ClusterFormer:
    """Forms clusters from call graph + scores them.  All operations on SQLite."""

    def __init__(self, db_path: str):
        self.con = sqlite3.connect(db_path)
        self.con.row_factory = sqlite3.Row

    def close(self):
        self.con.close()

    # ------------------------------------------------------------------
    # Step 1 — connected components via union-find
    # ------------------------------------------------------------------

    def form_connected_components(self, verbose: bool = True) -> int:
        """Build weakly-connected-component clusters from call graph."""
        if verbose:
            print("  forming clusters via union-find …", flush=True)

        uf = UnionFind()
        # Ensure all file IDs are in the union-find (even isolated files)
        for (fid,) in self.con.execute("SELECT id FROM files"):
            uf.find(fid)

        # Stream all edges — no full graph load needed
        batch_size = 10_000
        offset = 0
        while True:
            rows = self.con.execute(
                "SELECT src_id, dst_id FROM edges LIMIT ? OFFSET ?",
                (batch_size, offset),
            ).fetchall()
            if not rows:
                break
            for (src, dst) in rows:
                uf.union(src, dst)
            offset += len(rows)

        # Clear old clusters
        self.con.execute("DELETE FROM file_clusters")
        self.con.execute("DELETE FROM clusters")
        self.con.execute("DELETE FROM cluster_edges")
        try:
            self.con.execute("DELETE FROM cluster_fts")
        except Exception:
            pass
        self.con.commit()

        # Write cluster rows + file_clusters mapping
        components = uf.components()
        cluster_map: Dict[int, int] = {}  # root_id → cluster_id
        file_to_cluster: Dict[int, int] = {}  # file_id → cluster_id

        cluster_rows = []
        file_cluster_rows = []

        for root, members in components.items():
            self.con.execute(
                "INSERT INTO clusters (member_count) VALUES (?)", (len(members),)
            )
            cid = self.con.execute("SELECT last_insert_rowid()").fetchone()[0]
            cluster_map[root] = cid
            for fid in members:
                file_to_cluster[fid] = cid
                file_cluster_rows.append((fid, cid))

        self.con.executemany(
            "INSERT OR IGNORE INTO file_clusters (file_id, cluster_id) VALUES (?,?)",
            file_cluster_rows,
        )
        self.con.commit()

        if verbose:
            print(f"  formed {len(components)} clusters (components)")
        return len(components)

    # ------------------------------------------------------------------
    # Step 2 — identify entry/leaf files within each cluster
    # ------------------------------------------------------------------

    def tag_entry_exit(self, verbose: bool = True) -> None:
        """Mark cluster entry (no in-cluster callers) and leaf (no in-cluster callees)."""
        if verbose:
            print("  tagging cluster entry/leaf files …", flush=True)

        # For each file, check if any caller/callee is in the SAME cluster
        rows = self.con.execute("""
            SELECT fc.file_id, fc.cluster_id FROM file_clusters fc
        """).fetchall()

        for (fid, cid) in rows:
            # Count in-cluster callers
            n_callers = self.con.execute("""
                SELECT COUNT(*) FROM edges e
                JOIN file_clusters fc2 ON fc2.file_id = e.src_id
                WHERE e.dst_id = ? AND fc2.cluster_id = ?
            """, (fid, cid)).fetchone()[0]

            # Count in-cluster callees
            n_callees = self.con.execute("""
                SELECT COUNT(*) FROM edges e
                JOIN file_clusters fc2 ON fc2.file_id = e.dst_id
                WHERE e.src_id = ? AND fc2.cluster_id = ?
            """, (fid, cid)).fetchone()[0]

            is_entry = 1 if n_callers == 0 else 0
            is_leaf = 1 if n_callees == 0 else 0
            role = (
                "ENTRY" if is_entry and not is_leaf else
                "LEAF"  if is_leaf and not is_entry else
                "ENTRY_LEAF" if is_entry and is_leaf else
                "MEMBER"
            )
            self.con.execute(
                "UPDATE file_clusters SET is_entry=?, is_leaf=?, role=? WHERE file_id=?",
                (is_entry, is_leaf, role, fid),
            )

        self.con.commit()

    # ------------------------------------------------------------------
    # Step 3 — score clusters (Pillar 1 + Pillar 2 combined)
    # ------------------------------------------------------------------

    def score_clusters(self, verbose: bool = True) -> None:
        """Compute det_score, graph_score, entry_stems for each cluster."""
        if verbose:
            print("  scoring clusters …", flush=True)

        cluster_ids = [r[0] for r in self.con.execute("SELECT id FROM clusters")]
        total_files = self.con.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        max_size = self.con.execute("SELECT MAX(member_count) FROM clusters").fetchone()[0] or 1

        for cid in cluster_ids:
            members = self.con.execute("""
                SELECT f.id, f.stem, f.ext, f.utility_score, f.loc,
                       fc.is_entry, fc.role,
                       m.in_degree, m.out_degree
                FROM file_clusters fc
                JOIN files f ON f.id = fc.file_id
                JOIN metrics m ON m.file_id = f.id
                WHERE fc.cluster_id = ?
            """, (cid,)).fetchall()

            if not members:
                continue

            # Pillar 1: weighted average utility score (weight by LOC)
            total_loc = sum(r["loc"] or 1 for r in members)
            det_score = sum(
                (r["utility_score"] or 0.5) * (r["loc"] or 1)
                for r in members
            ) / max(total_loc, 1)

            # Pillar 2: graph topology utility score
            size = len(members)
            all_ext_utility = all(r["ext"] in (".mac", ".hpp", ".h") for r in members)
            has_entry_program = any(
                r["is_entry"] and r["ext"] in (".asm", ".cpp") for r in members
            )
            max_in = max((r["in_degree"] or 0) for r in members)
            # Large clusters with ASM entry points → critical
            # All .mac/.hpp → utility
            # High cross-system in-degree → shared infra
            if all_ext_utility:
                graph_score = 0.88
            elif has_entry_program and size > 3:
                size_factor = math.log(size + 1) / math.log(max(max_size, 2) + 1)
                graph_score = max(0.0, 0.25 - size_factor * 0.15)
            elif max_in > 5:
                graph_score = 0.72   # heavily shared
            elif size == 1 and members[0]["ext"] == ".cpp":
                graph_score = 0.05
            else:
                graph_score = det_score  # fallback to structural

            # Combined score for cluster (before LLM)
            combined = det_score * 0.55 + graph_score * 0.45
            det_role = _cluster_role(combined)

            # Entry stems: files with no in-cluster callers
            entry_stems = [r["stem"] for r in members if r["is_entry"]]
            if not entry_stems:
                entry_stems = [r["stem"] for r in members][:3]

            # Per-file graph_score (store in files table + file_pillars)
            for r in members:
                fid = r["id"]
                f_struct = r["utility_score"] or 0.5
                f_graph = graph_score  # cluster-level; refined below
                # Refine per-file: entry files in critical clusters → more critical
                if r["is_entry"] and det_role == "CRITICAL_CLUSTER":
                    f_graph = max(0.0, f_graph - 0.10)
                elif r["role"] == "LEAF" and all_ext_utility:
                    f_graph = min(1.0, f_graph + 0.05)

                # Provisional final score (no LLM yet)
                final = f_struct * 0.55 + f_graph * 0.45

                # Agreement between pillar 1 and 2
                diff = abs(f_struct - f_graph)
                agreement = max(0.0, 1.0 - diff * 2.0)

                self.con.execute("""
                    INSERT OR REPLACE INTO file_pillars
                    (file_id, p1_structural, p2_graph, agreement, final_score, confidence)
                    VALUES (?,?,?,?,?,?)
                """, (fid, round(f_struct, 4), round(f_graph, 4),
                      round(agreement, 4), round(final, 4), round(agreement, 4)))

                self.con.execute(
                    "UPDATE files SET graph_score=?, final_score=?, confidence=? WHERE id=?",
                    (round(f_graph, 4), round(final, 4), round(agreement, 4), fid),
                )

            self.con.execute("""
                UPDATE clusters SET
                    det_score=?, graph_score=?, final_score=?,
                    det_role=?, final_role=?,
                    entry_stems=?
                WHERE id=?
            """, (round(det_score, 4), round(graph_score, 4), round(combined, 4),
                  det_role, det_role,
                  json.dumps(entry_stems[:5]), cid))

        self.con.commit()

    # ------------------------------------------------------------------
    # Step 4 — build cross-cluster edges
    # ------------------------------------------------------------------

    def build_cluster_edges(self, verbose: bool = True) -> None:
        """For each call edge between different clusters, record a cluster edge."""
        if verbose:
            print("  building cross-cluster edges …", flush=True)

        self.con.execute("DELETE FROM cluster_edges")
        self.con.execute("""
            INSERT OR IGNORE INTO cluster_edges (src_cluster_id, dst_cluster_id, call_count)
            SELECT fc1.cluster_id, fc2.cluster_id, COUNT(*)
            FROM edges e
            JOIN file_clusters fc1 ON fc1.file_id = e.src_id
            JOIN file_clusters fc2 ON fc2.file_id = e.dst_id
            WHERE fc1.cluster_id != fc2.cluster_id
            GROUP BY fc1.cluster_id, fc2.cluster_id
        """)
        self.con.commit()

    # ------------------------------------------------------------------
    # Step 5 — build FTS5 index for functionality search
    # ------------------------------------------------------------------

    def build_fts_index(self, verbose: bool = True) -> None:
        """Populate cluster_fts for full-text search."""
        if verbose:
            print("  building FTS index …", flush=True)
        try:
            self.con.execute("DELETE FROM cluster_fts")
        except Exception:
            pass

        clusters = self.con.execute(
            "SELECT id, name, purpose, entry_stems FROM clusters"
        ).fetchall()

        for (cid, name, purpose, entry_stems_json) in clusters:
            # Build searchable text from member stems
            member_stems = self.con.execute(
                "SELECT f.stem FROM file_clusters fc JOIN files f ON f.id=fc.file_id "
                "WHERE fc.cluster_id=?", (cid,)
            ).fetchall()
            stems_text = " ".join(r[0] for r in member_stems)
            entry_list = json.loads(entry_stems_json or "[]")
            self.con.execute("""
                INSERT INTO cluster_fts (cluster_id, name, purpose, stems_text)
                VALUES (?,?,?,?)
            """, (cid, name or "", purpose or "", stems_text))

        self.con.commit()

    # ------------------------------------------------------------------
    # Full build pipeline
    # ------------------------------------------------------------------

    def build(self, verbose: bool = True) -> None:
        self.form_connected_components(verbose=verbose)
        self.tag_entry_exit(verbose=verbose)
        self.score_clusters(verbose=verbose)
        self.build_cluster_edges(verbose=verbose)
        self.build_fts_index(verbose=verbose)


# ---------------------------------------------------------------------------
# Pillar 3 — LLM cluster analysis
# ---------------------------------------------------------------------------

_CLUSTER_NAME_PROMPT = """\
You are an expert in IBM HLASM / TPF mainframe codebases for financial \
transaction processing.

Below is a CLUSTER of source files that are connected by call/include \
relationships. Analyse the cluster as a whole unit and return:

  1. A SHORT NAME for the cluster (3-8 words, business-oriented, e.g.
     "Global Credit Limit Processor", "Account Maintenance Workarea")

  2. A PURPOSE sentence (one sentence, ≤ 20 words)

  3. A ROLE: "CRITICAL_CLUSTER" (unique business logic that would need to be
     changed if business rules change), "UTILITY_CLUSTER" (shared data \
structures / helpers / templates used by many features), or "MIXED_CLUSTER"

  4. A CONFIDENCE 0.0–1.0 in your role decision

Cluster info (member count: {MEMBER_COUNT}, entry points: {ENTRIES}):
{EVIDENCE}

Respond with ONLY valid JSON (no prose, no markdown):
{{
  "name": "...",
  "purpose": "...",
  "role": "CRITICAL_CLUSTER" | "UTILITY_CLUSTER" | "MIXED_CLUSTER",
  "confidence": 0.0-1.0
}}"""


class LLMClusterAnalyzer:
    """Names and classifies whole clusters using LLM."""

    def __init__(self, db_path: str, src_dir: Path, model: Optional[str] = None,
                 backend: str = "anthropic", api_key: str = ""):
        self.db_path = db_path
        self.src_dir = src_dir.resolve()
        self.backend = backend
        self.api_key = api_key
        if model is None:
            self.model = GEMINI_DEFAULT_MODEL if backend == "gemini" else ANTHROPIC_DEFAULT_MODEL
        else:
            self.model = model
        self.con = sqlite3.connect(db_path)
        self.con.row_factory = sqlite3.Row
        self._client = None

    def close(self):
        self.con.close()

    def _get_client(self):
        """Initialise and return the backend-specific LLM client."""
        if self._client is None:
            if self.backend == "gemini":
                try:
                    from google import genai as _genai
                    key = self.api_key or os.environ.get("GEMINI_API_KEY", "")
                    if not key:
                        print("ERROR: No Gemini API key. "
                              "Set GEMINI_API_KEY env var or pass --api-key.", file=sys.stderr)
                        sys.exit(1)
                    self._client = _genai.Client(api_key=key)
                except ImportError:
                    print("ERROR: google-genai not installed. "
                          "Run: pip install google-genai", file=sys.stderr)
                    sys.exit(1)
            else:
                try:
                    import anthropic
                    self._client = anthropic.Anthropic()
                except ImportError:
                    print("ERROR: pip install anthropic", file=sys.stderr)
                    sys.exit(1)
        return self._client

    def _call_llm(self, prompt: str, max_tokens: int = 256) -> str:
        """Call the configured LLM and return the raw text response."""
        client = self._get_client()
        if self.backend == "gemini":
            response = client.models.generate_content(
                model=self.model, contents=prompt
            )
            return response.text.strip()
        else:
            resp = client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                messages=[{"role": "user", "content": prompt}],
            )
            return resp.content[0].text.strip()

    def _build_cluster_evidence(self, cluster_id: int) -> str:
        """Compact evidence for a whole cluster (≤ 800 tokens)."""
        members = self.con.execute("""
            SELECT f.stem, f.ext, f.loc, f.utility_score, f.graph_score,
                   f.dsect_ratio, f.instruction_ratio,
                   fc.is_entry, fc.role,
                   m.in_degree
            FROM file_clusters fc
            JOIN files f ON f.id = fc.file_id
            JOIN metrics m ON m.file_id = f.id
            WHERE fc.cluster_id = ?
            ORDER BY fc.is_entry DESC, f.loc DESC
        """, (cluster_id,)).fetchall()

        lines = []
        for r in members:
            hint = ""
            path = self.src_dir / self.con.execute(
                "SELECT path FROM files WHERE stem=?", (r["stem"],)
            ).fetchone()["path"]
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
                for line in text.splitlines()[:60]:
                    s = line.strip()
                    if s and not s.startswith("*") and not s.startswith("//"):
                        # First TITLE or program description
                        m = re.search(
                            r"(?:TITLE|BEGIN NAME\s*=\s*|DESCRIPTION)\s*['\"]?([A-Z][A-Z /\-']{6,60})",
                            s, re.IGNORECASE
                        )
                        if m:
                            hint = m.group(1).strip()[:60]
                            break
            except Exception:
                pass

            role_tag = f"[{r['role']}]" if r["is_entry"] else ""
            lines.append(
                f"  {role_tag}{r['stem']}{r['ext']}  "
                f"det={r['utility_score']:.2f}  graph={r['graph_score'] or 0:.2f}  "
                f"in_deg={r['in_degree']}  "
                f"dsect={r['dsect_ratio']:.2f}  instr={r['instruction_ratio']:.2f}"
                + (f"  hint: {hint}" if hint else "")
            )
        return "\n".join(lines)

    def analyse_cluster(self, cluster_id: int) -> Optional[dict]:
        row = self.con.execute(
            "SELECT id, member_count, entry_stems FROM clusters WHERE id=?",
            (cluster_id,)
        ).fetchone()
        if not row:
            return None

        evidence = self._build_cluster_evidence(cluster_id)
        entries = json.loads(row["entry_stems"] or "[]")

        prompt = _CLUSTER_NAME_PROMPT.format(
            MEMBER_COUNT=row["member_count"],
            ENTRIES=", ".join(entries[:5]) or "none identified",
            EVIDENCE=evidence,
        )

        for attempt in range(3):
            try:
                raw = self._call_llm(prompt, max_tokens=256)
                # Strip markdown fences if present
                raw = re.sub(r"^```(?:json)?\s*", "", raw)
                raw = re.sub(r"\s*```$", "", raw)
                data = json.loads(raw)
                return {
                    "name":       str(data.get("name", "Unnamed"))[:80],
                    "purpose":    str(data.get("purpose", ""))[:200],
                    "role":       str(data.get("role", "MIXED_CLUSTER")),
                    "confidence": float(data.get("confidence", 0.5)),
                }
            except json.JSONDecodeError:
                # Try to extract fields with regex
                name_m = re.search(r'"name"\s*:\s*"([^"]+)"', raw)
                role_m = re.search(r'"role"\s*:\s*"(CRITICAL_CLUSTER|UTILITY_CLUSTER|MIXED_CLUSTER)"', raw)
                if name_m and role_m:
                    return {
                        "name": name_m.group(1)[:80],
                        "purpose": "",
                        "role": role_m.group(1),
                        "confidence": 0.5,
                    }
            except Exception as e:
                if attempt < 2:
                    time.sleep(2 ** attempt)
        return None

    def name_all_clusters(self, min_size: int = 2, verbose: bool = True) -> None:
        """Run LLM analysis on clusters with ≥ min_size members."""
        clusters = self.con.execute(
            "SELECT id, member_count FROM clusters WHERE llm_named=0 AND member_count >= ?",
            (min_size,)
        ).fetchall()

        if verbose:
            print(f"  LLM-naming {len(clusters)} clusters …", flush=True)

        named = 0
        for i, (cid, mcount) in enumerate(clusters, 1):
            if verbose and i % 10 == 0:
                print(f"    {i}/{len(clusters)} …", flush=True)

            result = self.analyse_cluster(cid)
            if result:
                llm_score = {"UTILITY_CLUSTER": 1.0, "MIXED_CLUSTER": 0.5, "CRITICAL_CLUSTER": 0.0}.get(
                    result["role"], 0.5
                )
                # Compute confidence: agreement between det_score and llm_score
                det = self.con.execute(
                    "SELECT final_score FROM clusters WHERE id=?", (cid,)
                ).fetchone()["final_score"]
                agreement = max(0.0, 1.0 - abs(det - llm_score) * 2)
                confidence = (agreement + result["confidence"]) / 2

                self.con.execute("""
                    UPDATE clusters SET
                        name=?, purpose=?, llm_role=?, llm_score=?,
                        final_role=?, final_score=?, confidence=?, llm_named=1
                    WHERE id=?
                """, (result["name"], result["purpose"], result["role"],
                      llm_score, result["role"], round((det + llm_score) / 2, 4),
                      round(confidence, 4), cid))

                # Update per-file confidence with LLM pillar
                self.con.execute("""
                    UPDATE file_pillars SET p3_llm=?,
                        agreement = CASE
                            WHEN p2_graph >= 0 THEN
                                1.0 - (ABS(p1_structural - p2_graph) +
                                       ABS(p2_graph - ?) +
                                       ABS(p1_structural - ?)) / 3.0
                            ELSE
                                1.0 - ABS(p1_structural - ?)
                        END,
                        confidence = MIN(1.0, MAX(0.0,
                            CASE
                                WHEN p2_graph >= 0 THEN
                                    1.0 - (ABS(p1_structural - p2_graph) +
                                           ABS(p2_graph - ?) +
                                           ABS(p1_structural - ?)) / 3.0
                                ELSE
                                    1.0 - ABS(p1_structural - ?)
                            END
                        ))
                    WHERE file_id IN (
                        SELECT file_id FROM file_clusters WHERE cluster_id=?
                    )
                """, (llm_score, llm_score, llm_score, llm_score,
                      llm_score, llm_score, llm_score, cid))

                named += 1
            else:
                # Mark as attempted even if failed
                self.con.execute(
                    "UPDATE clusters SET llm_named=1 WHERE id=?", (cid,)
                )

        self.con.commit()
        # Rebuild FTS after naming — use same connection to avoid lock contention
        try:
            self.con.execute("DELETE FROM cluster_fts")
            clusters = self.con.execute(
                "SELECT id, name, purpose, entry_stems FROM clusters"
            ).fetchall()
            for (cid, name, purpose, entry_stems_json) in clusters:
                member_stems = self.con.execute(
                    "SELECT f.stem FROM file_clusters fc JOIN files f ON f.id=fc.file_id "
                    "WHERE fc.cluster_id=?", (cid,)
                ).fetchall()
                stems_text = " ".join(r[0] for r in member_stems)
                self.con.execute(
                    "INSERT INTO cluster_fts (cluster_id, name, purpose, stems_text) VALUES (?,?,?,?)",
                    (cid, name or "", purpose or "", stems_text),
                )
            self.con.commit()
        except Exception as e:
            pass  # FTS rebuild failure is non-fatal
        if verbose:
            print(f"  named {named} clusters")


# ---------------------------------------------------------------------------
# Functionality mapper — finds clusters + files for a given functionality
# ---------------------------------------------------------------------------

class FunctionalityMapper:
    """Maps a plain-text functionality description to clusters + files."""

    def __init__(self, db_path: str):
        self.con = sqlite3.connect(db_path)
        self.con.row_factory = sqlite3.Row

    def close(self):
        self.con.close()

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def _fts_search(self, query: str) -> List[int]:
        """Full-text search on cluster names/purposes/stems. Returns cluster IDs."""
        # Build FTS5 query: each word as a separate token
        tokens = [t for t in re.split(r"\s+", query.strip()) if len(t) >= 2]
        if not tokens:
            return []

        # Try progressive relaxation: all tokens → any two → any one
        for min_matches in range(len(tokens), 0, -1):
            if min_matches == len(tokens):
                fts_query = " ".join(tokens)
            else:
                # FTS5 OR semantics
                fts_query = " OR ".join(tokens)

            try:
                rows = self.con.execute(
                    "SELECT cluster_id FROM cluster_fts WHERE cluster_fts MATCH ?",
                    (fts_query,)
                ).fetchall()
                if rows:
                    return [r["cluster_id"] for r in rows]
            except sqlite3.OperationalError:
                # FTS syntax error — fall back to LIKE search
                break

        # Fallback: substring search on cluster name + stems
        like_clauses = " AND ".join("(name LIKE ? OR purpose LIKE ? OR stems_text LIKE ?)"
                                    for _ in tokens)
        params = [p for t in tokens for p in (f"%{t}%", f"%{t}%", f"%{t}%")]
        try:
            rows = self.con.execute(
                f"SELECT cluster_id FROM cluster_fts WHERE {like_clauses}", params
            ).fetchall()
            return [r["cluster_id"] for r in rows]
        except Exception:
            return []

    def _stem_search(self, query: str) -> List[int]:
        """Direct stem match for the query."""
        tokens = [t.lower() for t in query.split() if len(t) >= 2]
        result: List[int] = []
        for token in tokens:
            rows = self.con.execute("""
                SELECT DISTINCT fc.cluster_id FROM files f
                JOIN file_clusters fc ON fc.file_id = f.id
                WHERE f.stem LIKE ? OR f.stem LIKE ?
            """, (token, token + "%")).fetchall()
            result.extend(r["cluster_id"] for r in rows)
        return list(set(result))

    def _bfs_cluster_deps(self, seed_cluster_ids: List[int], max_depth: int = 4) -> Dict[int, int]:
        """BFS over cluster_edges from seed clusters. Returns {cluster_id: depth}."""
        visited: Dict[int, int] = {cid: 0 for cid in seed_cluster_ids}
        frontier = list(seed_cluster_ids)
        depth = 0
        while frontier and depth < max_depth:
            next_frontier = []
            ph = ",".join("?" * len(frontier))
            rows = self.con.execute(
                f"SELECT DISTINCT dst_cluster_id FROM cluster_edges WHERE src_cluster_id IN ({ph})",
                frontier,
            ).fetchall()
            for (dst,) in rows:
                if dst not in visited:
                    visited[dst] = depth + 1
                    next_frontier.append(dst)
            frontier = next_frontier
            depth += 1
        return visited

    def _get_cluster_files(self, cluster_id: int) -> List[dict]:
        """Return all files in a cluster with their scores."""
        return [dict(r) for r in self.con.execute("""
            SELECT f.stem, f.path, f.ext, f.loc,
                   f.utility_score, f.final_score, f.confidence, f.graph_score,
                   fc.is_entry, fc.role as file_role,
                   m.in_degree, m.out_degree
            FROM file_clusters fc
            JOIN files f ON f.id = fc.file_id
            JOIN metrics m ON m.file_id = f.id
            WHERE fc.cluster_id = ?
            ORDER BY fc.is_entry DESC, f.utility_score ASC
        """, (cluster_id,)).fetchall()]

    # ------------------------------------------------------------------
    # Main find
    # ------------------------------------------------------------------

    def find(self, functionality: str, include_deps: bool = True) -> dict:
        """Return clusters + files matching a functionality description."""
        # 1. Find primary clusters via FTS
        primary_ids = self._fts_search(functionality)
        if not primary_ids:
            primary_ids = self._stem_search(functionality)

        if not primary_ids:
            return {
                "functionality": functionality,
                "found": False,
                "message": f"No clusters found matching '{functionality}'. "
                           "Try running 'llm-name' to give clusters meaningful names, "
                           "or use a stem keyword (e.g. the module name).",
                "clusters": [],
            }

        # 2. BFS over cluster graph to find dependency clusters
        dep_depths: Dict[int, int] = {}
        if include_deps:
            dep_depths = self._bfs_cluster_deps(primary_ids, max_depth=4)

        all_cluster_ids = set(primary_ids) | set(dep_depths.keys())

        # 3. Fetch cluster metadata
        result_clusters = []
        for cid in all_cluster_ids:
            cdata = self.con.execute(
                "SELECT * FROM clusters WHERE id=?", (cid,)
            ).fetchone()
            if not cdata:
                continue

            is_primary = cid in primary_ids
            depth = 0 if is_primary else dep_depths.get(cid, -1)
            files = self._get_cluster_files(cid)

            # Classify this cluster's ROLE in the context of this functionality
            final_score = cdata["final_score"] or cdata["det_score"] or 0.5
            role_in_query = (
                "PRIMARY"    if is_primary else
                "DEPENDENCY" if depth <= 2 else
                "TRANSITIVE"
            )

            result_clusters.append({
                "cluster_id":   cid,
                "name":         cdata["name"] or f"Cluster-{cid}",
                "purpose":      cdata["purpose"] or "",
                "final_role":   cdata["final_role"] or cdata["det_role"] or "UNKNOWN",
                "utility_score": round(final_score, 4),
                "confidence":   round(cdata["confidence"] or 0.0, 4),
                "member_count": cdata["member_count"],
                "is_primary":   is_primary,
                "depth":        depth,
                "role_in_query": role_in_query,
                "files": files,
            })

        # Sort: primary first, then by depth, then by utility_score ascending (most critical first)
        result_clusters.sort(key=lambda c: (
            0 if c["is_primary"] else 1,
            c["depth"],
            c["utility_score"],
        ))

        # Flat file list for convenience
        all_files = []
        for c in result_clusters:
            for f in c["files"]:
                f_copy = dict(f)
                f_copy["cluster_name"] = c["name"]
                f_copy["cluster_id"]   = c["cluster_id"]
                f_copy["cluster_role"] = c["final_role"]
                f_copy["role_in_query"] = c["role_in_query"]
                all_files.append(f_copy)

        # Deduplicate (a file can only be in one cluster, but keep order)
        seen_stems: Set[str] = set()
        deduped = []
        for f in all_files:
            if f["stem"] not in seen_stems:
                seen_stems.add(f["stem"])
                deduped.append(f)

        return {
            "functionality":   functionality,
            "found":           True,
            "total_clusters":  len(result_clusters),
            "total_files":     len(deduped),
            "clusters":        result_clusters,
            "files":           deduped,
        }


# ---------------------------------------------------------------------------
# Confidence model summary
# ---------------------------------------------------------------------------

def compute_confidence_summary(db_path: str) -> dict:
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row

    # Pillar coverage
    p1 = con.execute("SELECT COUNT(*) FROM file_pillars WHERE p1_structural >= 0").fetchone()[0]
    p2 = con.execute("SELECT COUNT(*) FROM file_pillars WHERE p2_graph >= 0").fetchone()[0]
    p3 = con.execute("SELECT COUNT(*) FROM file_pillars WHERE p3_llm >= 0").fetchone()[0]
    total = con.execute("SELECT COUNT(*) FROM files").fetchone()[0]

    # Confidence distribution
    bands = con.execute("""
        SELECT
            SUM(CASE WHEN confidence >= 0.80 THEN 1 ELSE 0 END) AS high,
            SUM(CASE WHEN confidence >= 0.50 AND confidence < 0.80 THEN 1 ELSE 0 END) AS medium,
            SUM(CASE WHEN confidence < 0.50 AND confidence >= 0 THEN 1 ELSE 0 END) AS low,
            SUM(CASE WHEN confidence < 0 THEN 1 ELSE 0 END) AS unscored
        FROM file_pillars
    """).fetchone()

    # Files needing review
    review = con.execute("""
        SELECT f.stem, f.ext, fp.p1_structural, fp.p2_graph, fp.p3_llm, fp.confidence
        FROM file_pillars fp JOIN files f ON f.id = fp.file_id
        WHERE fp.confidence >= 0 AND fp.confidence < 0.50
        ORDER BY fp.confidence ASC LIMIT 20
    """).fetchall()

    con.close()
    return {
        "total_files": total,
        "pillar_coverage": {"p1_structural": p1, "p2_graph": p2, "p3_llm": p3},
        "confidence_bands": {
            "HIGH (>=0.80)":   bands[0] or 0,
            "MEDIUM (0.50-0.80)": bands[1] or 0,
            "LOW (<0.50)":     bands[2] or 0,
            "UNSCORED":        bands[3] or 0,
        },
        "review_needed": [dict(r) for r in review],
    }


# ---------------------------------------------------------------------------
# Console printers
# ---------------------------------------------------------------------------

def _bar(score: float, w: int = 10) -> str:
    f = round(min(1.0, max(0.0, score)) * w)
    return "█" * f + "░" * (w - f)


def _conf_star(conf: float) -> str:
    if conf >= 0.85: return "★★★"
    if conf >= 0.65: return "★★ "
    if conf >= 0.40: return "★  "
    return "?  "


def print_clusters(db_path: str, show_files: bool = False, role_filter: Optional[str] = None,
                   max_rows: int = 60) -> None:
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row

    where = ""
    params: list = []
    if role_filter:
        where = "WHERE final_role LIKE ?"
        params = [f"%{role_filter.upper()}%"]

    rows = con.execute(
        f"SELECT * FROM clusters {where} ORDER BY final_score ASC, member_count DESC LIMIT {max_rows}",
        params,
    ).fetchall()

    total = con.execute("SELECT COUNT(*) FROM clusters").fetchone()[0]
    print(f"\nTotal clusters: {total}")
    print(f"\n{'ID':>4}  {'NAME':<30} {'ROLE':<20} {'SCORE':>6}  {'CONF':>4}  {'N':>4}  ENTRIES")
    print("─" * 90)
    for r in rows:
        entries = json.loads(r["entry_stems"] or "[]")
        entry_str = ", ".join(entries[:3]) + ("…" if len(entries) > 3 else "")
        name = (r["name"] or f"Cluster-{r['id']}")[:29]
        role = (r["final_role"] or "UNKNOWN")[:19]
        score = r["final_score"] or r["det_score"] or 0.5
        conf = r["confidence"] or 0.0
        print(
            f"  {r['id']:>4}  {name:<30} {role:<20} {score:>6.3f}  "
            f"{_conf_star(conf)}  {r['member_count']:>4}  {entry_str}"
        )
        if show_files:
            files = con.execute("""
                SELECT f.stem, f.ext, f.utility_score, f.final_score, fc.role
                FROM file_clusters fc JOIN files f ON f.id=fc.file_id
                WHERE fc.cluster_id=? ORDER BY fc.is_entry DESC
            """, (r["id"],)).fetchall()
            for f in files:
                score_col = f["final_score"] if (f["final_score"] or -1) >= 0 else f["utility_score"]
                print(f"           {'→' if f['role']=='ENTRY' else ' '} "
                      f"{f['stem']:<22}{f['ext']:<6}  {_bar(1 - (score_col or 0.5))} "
                      f"crit={1-(score_col or 0.5):.3f}  [{f['role']}]")
    con.close()


def print_cluster_info(db_path: str, cluster_id: int) -> None:
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row

    c = con.execute("SELECT * FROM clusters WHERE id=?", (cluster_id,)).fetchone()
    if not c:
        print(f"Cluster {cluster_id} not found.")
        return

    print(f"\n{'='*65}")
    print(f"  Cluster {c['id']}: {c['name'] or 'Unnamed'}")
    print(f"{'='*65}")
    print(f"  Purpose      : {c['purpose'] or '(not yet named)'}")
    print(f"  Final Role   : {c['final_role'] or c['det_role']}")
    print(f"  Det score    : {c['det_score']:.4f}")
    print(f"  Graph score  : {c['graph_score']:.4f}")
    if c["llm_score"] is not None:
        print(f"  LLM score    : {c['llm_score']:.4f}")
    print(f"  Final score  : {(c['final_score'] or c['det_score']):.4f}")
    print(f"  Confidence   : {(c['confidence'] or 0):.4f}  {_conf_star(c['confidence'] or 0)}")
    print(f"  Members      : {c['member_count']}")

    # Cluster dependency graph
    deps = con.execute("""
        SELECT c2.id, c2.name, c2.final_role, ce.call_count
        FROM cluster_edges ce JOIN clusters c2 ON c2.id=ce.dst_cluster_id
        WHERE ce.src_cluster_id=? ORDER BY ce.call_count DESC
    """, (cluster_id,)).fetchall()
    if deps:
        print(f"\n  Depends on ({len(deps)} cluster(s)):")
        for d in deps:
            print(f"    → Cluster {d['id']:3}: {(d['name'] or 'Unnamed'):<30} "
                  f"[{d['final_role'] or '?'}]  ({d['call_count']} calls)")

    called_by = con.execute("""
        SELECT c2.id, c2.name, c2.final_role, ce.call_count
        FROM cluster_edges ce JOIN clusters c2 ON c2.id=ce.src_cluster_id
        WHERE ce.dst_cluster_id=? ORDER BY ce.call_count DESC
    """, (cluster_id,)).fetchall()
    if called_by:
        print(f"\n  Called by ({len(called_by)} cluster(s)):")
        for d in called_by:
            print(f"    ← Cluster {d['id']:3}: {(d['name'] or 'Unnamed'):<30} "
                  f"[{d['final_role'] or '?'}]")

    print(f"\n  Files:")
    print(f"  {'STEM':<22} {'EXT':<6} {'FILE_ROLE':<12}  {'CRIT':>6} {'CONF':>4}  P1/P2/P3")
    print("  " + "─" * 72)
    files = con.execute("""
        SELECT f.stem, f.ext, fc.role, fc.is_entry,
               f.utility_score, f.final_score, f.confidence,
               fp.p1_structural, fp.p2_graph, fp.p3_llm
        FROM file_clusters fc
        JOIN files f ON f.id = fc.file_id
        LEFT JOIN file_pillars fp ON fp.file_id = f.id
        WHERE fc.cluster_id=?
        ORDER BY fc.is_entry DESC, f.utility_score ASC
    """, (cluster_id,)).fetchall()
    for f in files:
        eff = f["final_score"] if (f["final_score"] or -1) >= 0 else f["utility_score"] or 0.5
        crit = 1.0 - eff
        p1 = f"{f['p1_structural']:.2f}" if f["p1_structural"] is not None and f["p1_structural"] >= 0 else " —  "
        p2 = f"{f['p2_graph']:.2f}" if f["p2_graph"] is not None and f["p2_graph"] >= 0 else " —  "
        p3 = f"{f['p3_llm']:.2f}" if f["p3_llm"] is not None and f["p3_llm"] >= 0 else " —  "
        marker = "★ " if f["is_entry"] else "  "
        print(f"  {marker}{f['stem']:<20} {f['ext']:<6} {f['role']:<12}  "
              f"{crit:>6.3f} {_conf_star(f['confidence'] or 0)}  {p1}/{p2}/{p3}")
    con.close()


def print_find_result(result: dict, max_files_per_cluster: int = 10) -> None:
    if not result["found"]:
        print(f"\nNo results for: {result['functionality']}")
        print(f"  {result.get('message', '')}")
        return

    print(f"\nFunctionality : \"{result['functionality']}\"")
    print(f"Matched       : {result['total_clusters']} cluster(s), {result['total_files']} files total")

    for c in result["clusters"]:
        tag = "► PRIMARY" if c["is_primary"] else f"  dep[{c['depth']}]"
        score = c["utility_score"]
        print(f"\n  {tag}  Cluster {c['cluster_id']}: {c['name']}")
        print(f"          Role: {c['final_role']}  |  score={score:.3f}  "
              f"conf={c['confidence']:.3f}  members={c['member_count']}")
        if c["purpose"]:
            print(f"          Purpose: {c['purpose']}")

        files = c["files"][:max_files_per_cluster]
        print(f"\n          {'STEM':<22} {'EXT':<6} {'CLUSTER_ROLE':<15}  {'CRIT':>6}  {'FILE_ROLE':<10}")
        print("          " + "─" * 65)
        for f in files:
            eff = f.get("final_score") or f.get("utility_score") or 0.5
            if eff < 0:
                eff = 0.5
            crit = 1.0 - eff
            marker = "★ " if f.get("is_entry") else "  "
            print(f"          {marker}{f['stem']:<20} {f['ext']:<6} {c['final_role']:<15}  "
                  f"{crit:>6.3f}  {f.get('file_role', ''):<10}")
        if len(c["files"]) > max_files_per_cluster:
            print(f"          … {len(c['files']) - max_files_per_cluster} more files")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="cluster_analyzer.py",
        description=textwrap.dedent(__doc__).split("Usage:")[0].strip(),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = p.add_subparsers(dest="command", required=True)

    # build
    pb = sub.add_parser("build", help="Form clusters + compute all pillars")
    pb.add_argument("--db",    required=True)
    pb.add_argument("--src",   required=True)
    pb.add_argument("--quiet", action="store_true")

    # clusters
    pc = sub.add_parser("clusters", help="List all clusters")
    pc.add_argument("--db",       required=True)
    pc.add_argument("--files",    action="store_true", help="Show member files")
    pc.add_argument("--role",     help="Filter by role keyword")
    pc.add_argument("--output",   help="Write JSON to file")

    # info
    pi = sub.add_parser("info", help="Show full info for one cluster")
    pi.add_argument("--db",      required=True)
    pi.add_argument("--cluster", type=int, required=True)

    # find
    pf = sub.add_parser("find", help="Find clusters+files for a functionality")
    pf.add_argument("--db",           required=True)
    pf.add_argument("--functionality", required=True)
    pf.add_argument("--no-deps",      action="store_true", help="Skip dependency clusters")
    pf.add_argument("--output",       help="Write JSON to file")

    # llm-name
    pl = sub.add_parser("llm-name", help="Use LLM to name and classify each cluster")
    pl.add_argument("--db",          required=True)
    pl.add_argument("--src",         required=True)
    pl.add_argument("--model",       default=None,
                    help="Model name (default: claude-sonnet-4-5 for Anthropic, "
                         "gemini-2.0-flash for Gemini)")
    pl.add_argument("--llm-backend", default="anthropic", choices=["anthropic", "gemini"],
                    help="LLM backend to use (default: anthropic)")
    pl.add_argument("--api-key",     default="",
                    help="API key for the backend. For Gemini: overrides GEMINI_API_KEY env var.")
    pl.add_argument("--min-size",    type=int, default=2,
                    help="Only name clusters with ≥ N members (default: 2)")

    # confidence
    pconf = sub.add_parser("confidence", help="Show confidence model summary")
    pconf.add_argument("--db", required=True)

    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "build":
        if not Path(args.db).exists():
            print(f"ERROR: DB not found: {args.db}. Run 'utility_detector.py build' first.")
            sys.exit(1)
        setup_cluster_schema(args.db)
        v = not args.quiet
        print(f"Building cluster index for {args.db} …")
        former = ClusterFormer(args.db)
        try:
            former.build(verbose=v)
        finally:
            former.close()
        print("Done.")

    elif args.command == "clusters":
        if not Path(args.db).exists():
            print(f"ERROR: DB not found: {args.db}")
            sys.exit(1)
        if args.output:
            con = sqlite3.connect(args.db)
            con.row_factory = sqlite3.Row
            rows = con.execute("SELECT * FROM clusters ORDER BY final_score ASC").fetchall()
            data = []
            for r in rows:
                c = dict(r)
                c["files"] = [dict(f) for f in con.execute("""
                    SELECT f.stem, f.ext, f.utility_score, f.final_score,
                           fc.role, fc.is_entry
                    FROM file_clusters fc JOIN files f ON f.id=fc.file_id
                    WHERE fc.cluster_id=?
                """, (r["id"],)).fetchall()]
                data.append(c)
            con.close()
            Path(args.output).write_text(json.dumps(data, indent=2))
            print(f"Wrote {len(data)} clusters to {args.output}")
        else:
            print_clusters(args.db, show_files=args.files, role_filter=args.role)

    elif args.command == "info":
        if not Path(args.db).exists():
            print(f"ERROR: DB not found: {args.db}")
            sys.exit(1)
        print_cluster_info(args.db, args.cluster)

    elif args.command == "find":
        if not Path(args.db).exists():
            print(f"ERROR: DB not found: {args.db}")
            sys.exit(1)
        mapper = FunctionalityMapper(args.db)
        try:
            result = mapper.find(args.functionality, include_deps=not args.no_deps)
        finally:
            mapper.close()

        if args.output:
            Path(args.output).write_text(json.dumps(result, indent=2))
            print(f"Wrote results to {args.output}")
        else:
            print_find_result(result)

    elif args.command == "llm-name":
        if not Path(args.db).exists():
            print(f"ERROR: DB not found: {args.db}")
            sys.exit(1)
        if not Path(args.src).exists():
            print(f"ERROR: Source directory not found: {args.src}")
            sys.exit(1)
        analyzer = LLMClusterAnalyzer(
            args.db, Path(args.src),
            model=args.model,
            backend=args.llm_backend,
            api_key=args.api_key,
        )
        try:
            analyzer.name_all_clusters(min_size=args.min_size)
        finally:
            analyzer.close()
        print("Done.")

    elif args.command == "confidence":
        if not Path(args.db).exists():
            print(f"ERROR: DB not found: {args.db}")
            sys.exit(1)
        s = compute_confidence_summary(args.db)
        print(f"\nTotal files: {s['total_files']}")
        print("\nPillar coverage:")
        for k, v in s["pillar_coverage"].items():
            print(f"  {k:<20} {v:>6} files  ({v/max(s['total_files'],1)*100:5.1f}%)")
        print("\nConfidence bands:")
        for k, v in s["confidence_bands"].items():
            print(f"  {k:<25} {v:>6} files")
        if s["review_needed"]:
            print(f"\nFiles needing review (low confidence):")
            print(f"  {'STEM':<22} {'P1':>5} {'P2':>5} {'P3':>5}  CONF")
            print("  " + "─" * 50)
            for r in s["review_needed"]:
                p1 = f"{r['p1_structural']:.3f}" if r["p1_structural"] and r["p1_structural"] >= 0 else "  —  "
                p2 = f"{r['p2_graph']:.3f}" if r["p2_graph"] and r["p2_graph"] >= 0 else "  —  "
                p3 = f"{r['p3_llm']:.3f}" if r["p3_llm"] and r["p3_llm"] >= 0 else "  —  "
                print(f"  {r['stem']:<22} {p1} {p2} {p3}  {r['confidence']:.3f}")


if __name__ == "__main__":
    main()
