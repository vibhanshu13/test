#!/usr/bin/env python3
"""Extract FUNCTION macro process mappings from an ASM file.

Usage:
  python process/extract_function_processes.py temp/asm/lu82.asm
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Dict, List

FUNCTION_LINE_RE = re.compile(
    r"^\s*(?:[A-Za-z0-9@$#._]+\s+)?FUNCTION\s+([^,\s]+)\s*,\s*([A-Za-z0-9@$#._]+)\b",
    re.IGNORECASE,
)


def parse_function_entries(asm_path: Path) -> List[Dict[str, object]]:
    entries: List[Dict[str, object]] = []

    with asm_path.open("r", encoding="utf-8", errors="ignore") as handle:
        for line_number, raw_line in enumerate(handle, start=1):
            line = raw_line.rstrip("\n")
            stripped = line.lstrip()

            if not stripped or stripped.startswith("*"):
                continue

            match = FUNCTION_LINE_RE.search(line)
            if not match:
                continue

            process = match.group(1).strip()
            target_segment = match.group(2).strip()

            # Skip macro definition lines such as: &LABEL FUNCTION &NAME,&SEG
            if "&" in process or "&" in target_segment:
                continue

            description = line[match.end() :].strip()

            entries.append(
                {
                    "line": line_number,
                    "process": process,
                    "target_segment": target_segment,
                    "description": description,
                }
            )

    return entries


def build_output_payload(asm_path: Path, entries: List[Dict[str, object]]) -> Dict[str, object]:
    unique_processes = []
    seen = set()

    for entry in entries:
        process = str(entry["process"])
        if process in seen:
            continue
        seen.add(process)
        unique_processes.append(process)

    return {
        "source_file": str(asm_path),
        "total_function_entries": len(entries),
        "unique_process_count": len(unique_processes),
        "unique_processes": unique_processes,
        "entries": entries,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Extract FUNCTION macro process mappings from an ASM file."
    )
    parser.add_argument("asm_file", help="Path to input ASM file (for example temp/asm/lu82.asm)")
    parser.add_argument(
        "-o",
        "--output",
        help="Output JSON file path. Default: process/<asm_stem>_function_processes.json",
    )

    args = parser.parse_args()

    asm_path = Path(args.asm_file).expanduser().resolve()
    if not asm_path.exists():
        raise FileNotFoundError(f"Input ASM file not found: {asm_path}")

    default_output = Path(__file__).resolve().parent / f"{asm_path.stem.lower()}_function_processes.json"
    output_path = Path(args.output).expanduser().resolve() if args.output else default_output
    output_path.parent.mkdir(parents=True, exist_ok=True)

    entries = parse_function_entries(asm_path)
    payload = build_output_payload(asm_path, entries)

    with output_path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")

    txt_output_path = output_path.with_name(f"{output_path.stem}_list.txt")
    with txt_output_path.open("w", encoding="utf-8") as handle:
        for process in payload["unique_processes"]:
            handle.write(f"{process}\n")

    print(f"Input file: {asm_path}")
    print(f"Output file: {output_path}")
    print(f"Process list: {txt_output_path}")
    print(f"FUNCTION entries: {payload['total_function_entries']}")
    print(f"Unique processes: {payload['unique_process_count']}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
