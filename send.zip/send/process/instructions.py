"""Backward-only instruction glossary (isolated from legacy/simple pipelines)."""

# SETTER_INST — authoritative 65-member set per SETTER_INST_COMPLETE.md audit.
# MUST stay byte-for-byte identical to trace_lineage.py and
# backward_traversal/glossary/instructions.py (audit §1c).
SETTER_INST = {
    "AGSI", "ALGSI", "ALSI", "AP", "ASI",
    "CVD", "CVDG", "CVDY",
    "DP", "ED", "EDMK",
    "MP", "MVC", "MVCIN", "MVGHI", "MVHHI", "MVHI", "MVI", "MVIY", "MVN", "MVO", "MVZ",
    "NC", "NI", "NIY",
    "OC", "OI", "OIY",
    "PACK", "PKA", "PKU",
    "SP", "SRP", "ST", "STC", "STCK", "STCKF", "STCM", "STCMH", "STCMY",
    "STCY", "STEY", "STFLE", "STG", "STGRL", "STH", "STHRL", "STHY",
    "STM", "STMG", "STMH", "STMY", "STRL", "STRV", "STRVG", "STRVH", "STY",
    "TR", "UNPK", "UNPKA", "UNPKU",
    "XC", "XI", "XIY",
    "ZAP",
}

# DEST_ARG_INDEX_BY_INST — must stay byte-for-byte identical to the other two
# copies (audit §2).  Maps instruction → args[] index of the storage destination.
DEST_ARG_INDEX_BY_INST = {
    "ST": 1, "STH": 1, "STC": 1, "CVD": 1, "CVDG": 1, "CVDY": 1,
    "STM": 2, "STMG": 2, "STMH": 2, "STMY": 2,
    "STCM": 2, "STCMH": 2, "STCMY": 2,
    "STG": 1, "STY": 1, "STHY": 1, "STCY": 1, "STGRL": 1,
    "STRL": 1, "STHRL": 1, "STRV": 1, "STRVG": 1, "STRVH": 1, "STEY": 1,
}

TRIGGER_INST = {
    "CLC", "CLI", "CLIY", "TM", "TMY", "CP", "LTR", "C", "CR", "CH", "CL", "CLR",
    # Y-displacement forms
    "CLM", "CLMY",
    # 64-bit comparison variants (z/Architecture PoP)
    "LTGR", "CGR", "CG", "CGF",        # compare register / memory (sign-extend 32→64 for CGF)
    "CGHI", "CHI", "CFI",              # compare halfword/fullword immediate
    # Compare Logical 64-bit / immediate variants
    "CLGR", "CLG", "CLFI", "CLGFI",
    # Zero-test self-ops: OC/NC field,field sets CC=0 when all bytes are zero (IBM PoO §7-226)
    "OC", "NC",
    # GAP-CC-LOAD: Load-and-Test from memory (PoO §7-152/153).
    "LT", "LTG",
    # GAP-CC-ICM: Insert Characters under Mask (PoO §7-144) sets CC.
    "ICM",
    # GAP-CC-TRT: Translate and Test (PoO §7-228).
    "TRT",
    # GAP-CC-CLCL: Compare Logical Characters Long / Extended (PoO §7-69/70).
    "CLCL", "CLCLE",
}

BRANCH_INST = {
    "B", "BE", "BNE", "BZ", "BNZ", "BH", "BNH", "BM", "BNM", "BO", "BNO", "BP", "BNP", "BCT",
    # Raw hardware opcodes underlying extended mnemonics
    "BC", "BCTR",
    # 64-bit count and index-loop branches (z/Architecture PoP)
    "BCTG",
    "BXH", "BXLE", "BXHG", "BXLEG",
    # Relative branch forms
    "BRCT", "BRCTG", "BRXH", "BRXLE",
    # Relative-branch forms — PC-relative encoding
    "BRC", "BRCL",
    "J", "JE", "JNE", "JZ", "JNZ", "JH", "JNH", "JL", "JNL", "JM", "JNM", "JO", "JNO", "JP", "JNP",
    "JXHG", "JXLE", "JXLEG",
}

SUBROUTINE_CALL_OPCODES = {"BAS", "BAL"}
SUBROUTINE_INST = set(SUBROUTINE_CALL_OPCODES)

# Return-like operations used only for backward-only subroutine anchor heuristics.
# These are intentionally broad because different asm sources use different return idioms.
RETURN_OPCODES = {
    "BR", "BCR", "PR", "BSM", "BASR", "BACKC", "EXITC", "RETURN",
}

CROSS_FILE_INST = {
    "ENTRC", "ENTNC", "ENTDC",          # Enter (returning, drop-prior, drop-all)
    "CREEC", "CREMC",                   # Create entry / message-controlled
    "CREDC", "CRETC", "CREXC", "CRESC", # Create deferred / time-initiated / lower-priority / synchronous
    "SWISC",                            # Switch segment
    "EXSR",                             # Execute Subroutine (legacy cross-file linkage)
    "FUNCTION",                         # Blueprint function call
    "CALLC", "CALLCPP", "CLINKC",       # C / C++ / C-link cross-language bridges
}

REGISTERS = {f"R{i}" for i in range(16)}
