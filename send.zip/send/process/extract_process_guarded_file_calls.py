#!/usr/bin/env python3
"""Extract process-gated cross-file ASM calls from ASM blueprints.

Scans all ``*.asm.json`` files in a blueprint directory, finds trigger
comparisons where the RHS contains a known process token, then returns
cross-file calls reachable from the trigger's TRUE path only
(TRUE-path minus FALSE-path).
"""

from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

try:
    from process.instructions import BRANCH_INST, CROSS_FILE_INST, TRIGGER_INST
except ModuleNotFoundError:
    from instructions import BRANCH_INST, CROSS_FILE_INST, TRIGGER_INST

from blueprint_io import iter_flow, load_blueprint


# Branch behavior relative to a "comparison true" condition interpreted as
# compare-equal (CC=0). If branch takes on equal, true path is branch target.
# Otherwise true path is fallthrough.
_BRANCH_TAKES_ON_EQUAL: Dict[str, bool] = {
    # unconditional
    "B": True,
    "J": True,
    # equal
    "BE": True,
    "BZ": True,
    "JE": True,
    "JZ": True,
    # not equal
    "BNE": False,
    "BNZ": False,
    "JNE": False,
    "JNZ": False,
    # high / not high
    "BH": False,
    "JH": False,
    "BNH": True,
    "JNH": True,
    # low(minus) / not low(not minus)
    "BL": False,
    "JL": False,
    "BM": False,
    "JM": False,
    "BNL": True,
    "JNL": True,
    "BNM": True,
    "JNM": True,
    # plus / not plus
    "BP": False,
    "JP": False,
    "BNP": True,
    "JNP": True,
    # overflow / no-overflow
    "BO": False,
    "JO": False,
    "BNO": True,
    "JNO": True,
}

# Counter/index branches are not condition-code branches from compare.
_NON_CC_BRANCH = {"BCT", "JXHG", "JXLE"}

PROCESS_LITERAL_RE = re.compile(r"(?:=)?C'([A-Z0-9]+)'", re.IGNORECASE)
PROCESS_LG_ALIAS_RE = re.compile(r"\bLG#([A-Z0-9]+)\b", re.IGNORECASE)


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _normalize_module_token(value: str) -> str:
    text = (value or "").strip()
    if not text:
        return ""
    return text.split()[0].split(",")[0].upper()


def _load_processes(process_json: Path) -> Set[str]:
    payload = json.loads(process_json.read_text(encoding="utf-8"))
    items = payload.get("unique_processes") or []
    out = set()
    for item in items:
        if item is None:
            continue
        txt = str(item).strip().upper()
        if txt:
            out.add(txt)
    return out


def _match_processes_from_rhs(rhs: str, process_set: Set[str]) -> List[str]:
    rhs_upper = (rhs or "").upper()
    found: Set[str] = set()

    for m in PROCESS_LITERAL_RE.finditer(rhs_upper):
        token = m.group(1).strip().upper()
        if token in process_set:
            found.add(token)

    for m in PROCESS_LG_ALIAS_RE.finditer(rhs_upper):
        token = m.group(1).strip().upper()
        if token in process_set:
            found.add(token)

    return sorted(found)


def _rhs_mentions_process(rhs: str, process: str) -> bool:
    probe = (process or "").strip().upper()
    if not probe:
        return False
    return probe in _match_processes_from_rhs(rhs, {probe})


def _norm_operand(operand: str) -> str:
    return (operand or "").strip().upper()


def _first_arg(item: Dict[str, Any]) -> str:
    args = item.get("args") or []
    if not args:
        return ""
    return str(args[0])


def _second_arg(item: Dict[str, Any]) -> str:
    args = item.get("args") or []
    if len(args) < 2:
        return ""
    return str(args[1])


def _find_nearest_semantic_branch(flow: Sequence[Dict[str, Any]], start_idx: int) -> Optional[Tuple[int, Dict[str, Any]]]:
    for idx in range(start_idx, len(flow)):
        item = flow[idx]
        inst = str(item.get("inst") or "").upper()
        if inst in BRANCH_INST:
            if inst in _BRANCH_TAKES_ON_EQUAL:
                return idx, item
            if inst in _NON_CC_BRANCH:
                continue
            return None
    return None


def _reachable(seed: Optional[str], outgoing: Dict[str, Set[str]]) -> Set[str]:
    if not seed:
        return set()
    if seed not in outgoing:
        return {seed}

    seen: Set[str] = set()
    q: deque[str] = deque([seed])
    while q:
        cur = q.popleft()
        if cur in seen:
            continue
        seen.add(cur)
        for nxt in outgoing.get(cur, set()):
            if nxt not in seen:
                q.append(nxt)
    return seen


def _build_cfg(blocks: Sequence[Dict[str, Any]], call_graph_edges: Sequence[Dict[str, Any]]) -> Tuple[Dict[str, Set[str]], Dict[str, Optional[str]], List[str], Set[str]]:
    block_order: List[str] = []
    block_set: Set[str] = set()
    for block in blocks:
        bid = str(block.get("id") or "")
        if bid and bid not in block_set:
            block_order.append(bid)
            block_set.add(bid)

    outgoing: Dict[str, Set[str]] = defaultdict(set)
    fallthrough: Dict[str, Optional[str]] = {bid: None for bid in block_order}

    # Reverse incoming branches to outgoing edges.
    for block in blocks:
        target = str(block.get("id") or "")
        if not target:
            continue
        for inc in block.get("incoming_branches") or []:
            src = str(inc.get("source") or "")
            etype = str(inc.get("type") or "").upper()
            if not src or src not in block_set:
                continue
            if etype not in {"BRANCH", "FALLTHROUGH"}:
                continue
            outgoing[src].add(target)
            if etype == "FALLTHROUGH" and src in fallthrough and fallthrough[src] is None:
                fallthrough[src] = target

    # Branch edges from call graph as a fallback reinforcement.
    for edge in call_graph_edges:
        if str(edge.get("call_type") or "").lower() != "branch":
            continue
        src = str(edge.get("source") or "")
        tgt = str(edge.get("target") or "")
        if src in block_set and tgt in block_set:
            outgoing[src].add(tgt)

    # Final fallthrough fallback: next block in declared order.
    for idx, bid in enumerate(block_order[:-1]):
        if fallthrough.get(bid) is None:
            fallthrough[bid] = block_order[idx + 1]
        if fallthrough.get(bid):
            outgoing[bid].add(fallthrough[bid])

    for bid in block_order:
        outgoing.setdefault(bid, set())

    return outgoing, fallthrough, block_order, block_set


def _collect_cross_file_calls_by_block(
    call_graph_edges: Sequence[Dict[str, Any]],
    blocks: Sequence[Dict[str, Any]] = (),
    block_set: Optional[Set[str]] = None,
) -> Dict[str, List[Dict[str, Any]]]:
    by_block: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    seen: Set[Tuple[str, int, str]] = set()  # (source_block, line, target_stem)

    # Source 1: call_graph.edges (primary)
    for edge in call_graph_edges:
        inst = str(edge.get("instruction") or "").upper()
        if inst not in CROSS_FILE_INST:
            continue

        source_block = str(edge.get("source") or "")
        target_module = _normalize_module_token(str(edge.get("target") or ""))
        if not source_block or not target_module:
            continue
        # Skip entries with source not in known blocks (e.g. "(unknown)")
        if block_set is not None and source_block not in block_set:
            continue

        target_stem = target_module.lower()
        call_line = int(edge.get("line") or 0)
        dedup_key = (source_block, call_line, target_stem)
        if dedup_key in seen:
            continue
        seen.add(dedup_key)

        by_block[source_block].append(
            {
                "call_line": call_line,
                "call_inst": inst,
                "target_module": target_module,
                "target_stem": target_stem,
                "source_block": source_block,
            }
        )

    # Source 2: blocks[].flow (catches cross-file calls missing from call_graph)
    for block in blocks:
        block_id = str(block.get("id") or "")
        if not block_id:
            continue
        for item in iter_flow(block):
            inst = str(item.get("inst") or "").upper()
            if inst not in CROSS_FILE_INST:
                continue
            args = item.get("args") or []
            if inst == "FUNCTION":
                operand_raw = str(args[1]) if len(args) > 1 else ""
            else:
                operand_raw = str(args[0]) if args else ""
            target_module = _normalize_module_token(operand_raw)
            if not target_module:
                continue
            target_stem = target_module.lower()
            call_line = int(item.get("line") or 0)
            dedup_key = (block_id, call_line, target_stem)
            if dedup_key in seen:
                continue
            seen.add(dedup_key)

            by_block[block_id].append(
                {
                    "call_line": call_line,
                    "call_inst": inst,
                    "target_module": target_module,
                    "target_stem": target_stem,
                    "source_block": block_id,
                }
            )

    for block, items in by_block.items():
        items.sort(key=lambda x: (x["call_line"], x["call_inst"], x["target_stem"]))

    return by_block


def _collect_calls_for_blocks(
    block_ids: Iterable[str],
    calls_by_block: Dict[str, List[Dict[str, Any]]],
) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for bid in sorted(set(block_ids)):
        out.extend(calls_by_block.get(bid, []))
    return out


def _resolve_true_false_seeds(
    branch_inst: str,
    branch_target: str,
    fallback_target: Optional[str],
) -> Tuple[Optional[str], Optional[str], str]:
    takes_on_equal = _BRANCH_TAKES_ON_EQUAL.get(branch_inst)
    if takes_on_equal is None:
        return None, None, ""
    if takes_on_equal:
        return branch_target or None, fallback_target, "branch_target"
    return fallback_target, branch_target or None, "fallthrough"


def _analyze_with_blueprint(
    blueprint_file: Path,
    process_set: Set[str],
    asm_stems: Set[str],
) -> Dict[str, List[Dict[str, Any]]]:
    payload = load_blueprint(blueprint_file)
    blocks = payload.get("blocks") or []
    call_edges = (payload.get("call_graph") or {}).get("edges") or []
    block_index: Dict[str, Dict[str, Any]] = {
        str(b.get("id") or ""): b for b in blocks if str(b.get("id") or "")
    }

    outgoing, fallthrough, block_order, block_set = _build_cfg(blocks, call_edges)
    del block_order
    del asm_stems  # target filtering is intentionally not restricted to local files
    calls_by_block = _collect_cross_file_calls_by_block(call_edges, blocks, block_set)

    process_edges: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    for block in blocks:
        block_id = str(block.get("id") or "")
        if not block_id:
            continue
        flow = list(iter_flow(block))

        for idx, item in enumerate(flow):
            inst = str(item.get("inst") or "").upper()
            if inst not in TRIGGER_INST:
                continue

            rhs = _second_arg(item)
            matched_processes = _match_processes_from_rhs(rhs, process_set)
            if not matched_processes:
                continue
            selector_var = _norm_operand(_first_arg(item))
            if not selector_var:
                continue

            near = _find_nearest_semantic_branch(flow, idx + 1)
            if near is None:
                continue

            _, branch_item = near
            branch_inst = str(branch_item.get("inst") or "").upper()
            branch_target = _normalize_module_token(_first_arg(branch_item))
            if branch_target and branch_target not in block_set:
                branch_target = ""

            fallback_target = fallthrough.get(block_id)
            if fallback_target and fallback_target not in block_set:
                fallback_target = None

            true_seed, false_seed, true_mode = _resolve_true_false_seeds(
                branch_inst=branch_inst,
                branch_target=branch_target,
                fallback_target=fallback_target,
            )
            if true_seed is None and false_seed is None:
                continue
            if not true_seed and not false_seed:
                continue

            true_reach = _reachable(true_seed, outgoing)
            false_reach = _reachable(false_seed, outgoing)
            false_only_blocks = false_reach - true_reach

            compare_line = int(item.get("line") or 0)
            branch_line = int(branch_item.get("line") or 0)
            for proc in matched_processes:
                candidate_rows: List[Dict[str, Any]] = []

                # Case 1: negative-side only calls (false path minus true path).
                for call in _collect_calls_for_blocks(false_only_blocks, calls_by_block):
                    target_stem = str(call.get("target_stem") or "")
                    call_block = str(call.get("source_block") or "")
                    if not target_stem:
                        continue
                    candidate_rows.append(
                        {
                            "basis": "negative_case_only",
                            "selector_var": selector_var,
                            "compare_line": compare_line,
                            "compare_inst": inst,
                            "compare_rhs": str(rhs),
                            "branch_line": branch_line,
                            "branch_inst": branch_inst,
                            "branch_target": branch_target,
                            "true_mode": true_mode,
                            "call_line": int(call.get("call_line") or 0),
                            "call_inst": str(call.get("call_inst") or ""),
                            "target_module": str(call.get("target_module") or ""),
                            "target_stem": target_stem,
                            "trigger_block": block_id,
                            "call_block": call_block,
                        }
                    )

                # Case 2 (relaxed): same-variable comparisons with RHS != current process;
                # follow their positive case and collect calls from other_true directly
                # (no other_true/other_false subtraction).
                for scoped_block_id in sorted(block_index.keys()):
                    scoped_block = block_index.get(scoped_block_id)
                    if not scoped_block:
                        continue
                    scoped_flow = list(iter_flow(scoped_block))
                    for scoped_idx, scoped_item in enumerate(scoped_flow):
                        scoped_inst = str(scoped_item.get("inst") or "").upper()
                        if scoped_inst not in TRIGGER_INST:
                            continue
                        scoped_lhs = _norm_operand(_first_arg(scoped_item))
                        if scoped_lhs != selector_var:
                            continue
                        scoped_rhs = _second_arg(scoped_item)
                        if _rhs_mentions_process(scoped_rhs, proc):
                            continue
                        scoped_near = _find_nearest_semantic_branch(scoped_flow, scoped_idx + 1)
                        if scoped_near is None:
                            continue
                        _, scoped_branch = scoped_near
                        scoped_branch_inst = str(scoped_branch.get("inst") or "").upper()
                        scoped_branch_target = _normalize_module_token(_first_arg(scoped_branch))
                        if scoped_branch_target and scoped_branch_target not in block_set:
                            scoped_branch_target = ""

                        scoped_fallback = fallthrough.get(scoped_block_id)
                        if scoped_fallback and scoped_fallback not in block_set:
                            scoped_fallback = None

                        scoped_true_seed, scoped_false_seed, scoped_true_mode = _resolve_true_false_seeds(
                            branch_inst=scoped_branch_inst,
                            branch_target=scoped_branch_target,
                            fallback_target=scoped_fallback,
                        )
                        if not scoped_true_seed:
                            continue

                        scoped_true_reach = _reachable(scoped_true_seed, outgoing)
                        _ = scoped_false_seed  # relaxed mode: intentionally not subtracted

                        for call in _collect_calls_for_blocks(scoped_true_reach, calls_by_block):
                            target_stem = str(call.get("target_stem") or "")
                            call_block = str(call.get("source_block") or "")
                            if not target_stem:
                                continue
                            # Keep this path-sensitive case even if block-level global reachability
                            # over-approximates the process path; selector-var branch semantics here
                            # imply a non-current-process positive case.
                            candidate_rows.append(
                                {
                                    "basis": "other_compare_positive_case",
                                    "selector_var": selector_var,
                                    "compare_line": compare_line,
                                    "compare_inst": inst,
                                    "compare_rhs": str(rhs),
                                    "branch_line": branch_line,
                                    "branch_inst": branch_inst,
                                    "branch_target": branch_target,
                                    "true_mode": true_mode,
                                    "other_compare_line": int(scoped_item.get("line") or 0),
                                    "other_compare_inst": scoped_inst,
                                    "other_compare_rhs": str(scoped_rhs),
                                    "other_branch_line": int(scoped_branch.get("line") or 0),
                                    "other_branch_inst": scoped_branch_inst,
                                    "other_branch_target": scoped_branch_target,
                                    "other_true_mode": scoped_true_mode,
                                    "other_true_only": False,
                                    "call_line": int(call.get("call_line") or 0),
                                    "call_inst": str(call.get("call_inst") or ""),
                                    "target_module": str(call.get("target_module") or ""),
                                    "target_stem": target_stem,
                                    "trigger_block": block_id,
                                    "other_compare_block": scoped_block_id,
                                    "call_block": call_block,
                                }
                            )

                for row in candidate_rows:
                    process_edges[proc].append(
                        row
                    )

    # Deduplicate process edges
    deduped: Dict[str, List[Dict[str, Any]]] = {}
    for proc, rows in process_edges.items():
        seen: Set[Tuple[Any, ...]] = set()
        keep: List[Dict[str, Any]] = []
        for row in sorted(
            rows,
            key=lambda r: (
                str(r.get("basis") or ""),
                int(r["compare_line"]),
                int(r["branch_line"]),
                int(r.get("other_compare_line") or 0),
                int(r["call_line"]),
                str(r["target_stem"]),
                str(r["call_inst"]),
            ),
        ):
            key = (
                str(row.get("basis") or ""),
                row["compare_line"],
                row["branch_line"],
                int(row.get("other_compare_line") or 0),
                row["call_line"],
                row["target_stem"],
                row["call_inst"],
                row["trigger_block"],
                row["call_block"],
            )
            if key in seen:
                continue
            seen.add(key)
            keep.append(row)
        if keep:
            deduped[proc] = keep

    return deduped


def _parse_raw_asm_lines(asm_path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    text = asm_path.read_text(encoding="utf-8", errors="replace")

    for line_no, raw in enumerate(text.splitlines(), start=1):
        stripped = raw.lstrip()
        if not stripped or stripped.startswith("*"):
            continue

        tokens = raw.split()
        if not tokens:
            continue

        if raw[0] == " ":
            label = ""
            inst = tokens[0].upper()
            args_raw = " ".join(tokens[1:]) if len(tokens) > 1 else ""
        else:
            label = tokens[0].upper()
            inst = tokens[1].upper() if len(tokens) > 1 else ""
            args_raw = " ".join(tokens[2:]) if len(tokens) > 2 else ""

        args = [a.strip() for a in args_raw.split(",")] if args_raw else []

        rows.append(
            {
                "line": line_no,
                "label": label,
                "inst": inst,
                "args": args,
                "raw": raw,
            }
        )

    return rows


def _collect_segment_calls(rows: Sequence[Dict[str, Any]], start_idx: int, asm_stems: Set[str]) -> List[Dict[str, Any]]:
    del asm_stems  # kept for fallback signature consistency
    calls: List[Dict[str, Any]] = []
    for i in range(start_idx, len(rows)):
        row = rows[i]
        if i > start_idx and row.get("label"):
            break

        inst = str(row.get("inst") or "").upper()
        if inst in BRANCH_INST:
            if i > start_idx:
                break
            continue

        if inst not in CROSS_FILE_INST:
            continue

        args = row.get("args") or []
        if inst == "FUNCTION":
            target_raw = args[1] if len(args) > 1 else ""
        else:
            target_raw = args[0] if args else ""

        target_module = _normalize_module_token(str(target_raw))
        if not target_module:
            continue

        target_stem = target_module.lower()

        calls.append(
            {
                "call_line": int(row.get("line") or 0),
                "call_inst": inst,
                "target_module": target_module,
                "target_stem": target_stem,
            }
        )

    return calls


def _analyze_with_raw_fallback(asm_file: Path, process_set: Set[str], asm_stems: Set[str]) -> Dict[str, List[Dict[str, Any]]]:
    rows = _parse_raw_asm_lines(asm_file)
    label_to_index = {str(r.get("label") or ""): idx for idx, r in enumerate(rows) if r.get("label")}

    process_edges: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    for idx, row in enumerate(rows):
        inst = str(row.get("inst") or "").upper()
        if inst not in TRIGGER_INST:
            continue

        args = row.get("args") or []
        if len(args) < 2:
            continue

        rhs = str(args[1])
        matched_processes = _match_processes_from_rhs(rhs, process_set)
        if not matched_processes:
            continue

        branch_idx = None
        branch_row = None
        for j in range(idx + 1, len(rows)):
            maybe = rows[j]
            maybe_inst = str(maybe.get("inst") or "").upper()
            if maybe_inst in BRANCH_INST:
                if maybe_inst in _BRANCH_TAKES_ON_EQUAL:
                    branch_idx = j
                    branch_row = maybe
                elif maybe_inst in _NON_CC_BRANCH:
                    continue
                break
            if maybe.get("label") and j > idx + 1:
                break

        if branch_idx is None or branch_row is None:
            continue

        branch_inst = str(branch_row.get("inst") or "").upper()
        bargs = branch_row.get("args") or []
        branch_target = _normalize_module_token(str(bargs[0])) if bargs else ""

        takes_on_equal = _BRANCH_TAKES_ON_EQUAL.get(branch_inst)
        if takes_on_equal is None:
            continue

        true_calls: List[Dict[str, Any]] = []
        false_calls: List[Dict[str, Any]] = []
        if takes_on_equal:
            true_mode = "branch_target"
            false_mode = "fallthrough"
            if branch_target and branch_target in label_to_index:
                true_calls = _collect_segment_calls(rows, label_to_index[branch_target], asm_stems)
            false_calls = _collect_segment_calls(rows, branch_idx + 1, asm_stems)
        else:
            true_mode = "fallthrough"
            false_mode = "branch_target"
            true_calls = _collect_segment_calls(rows, branch_idx + 1, asm_stems)
            if branch_target and branch_target in label_to_index:
                false_calls = _collect_segment_calls(rows, label_to_index[branch_target], asm_stems)

        false_keys = {(c["call_line"], c["target_stem"], c["call_inst"]) for c in false_calls}
        true_only_calls = [
            c
            for c in true_calls
            if (c["call_line"], c["target_stem"], c["call_inst"]) not in false_keys
        ]

        if not true_only_calls:
            continue

        compare_line = int(row.get("line") or 0)
        branch_line = int(branch_row.get("line") or 0)

        for proc in matched_processes:
            for call in true_only_calls:
                process_edges[proc].append(
                    {
                        "compare_line": compare_line,
                        "compare_inst": inst,
                        "compare_rhs": rhs,
                        "branch_line": branch_line,
                        "branch_inst": branch_inst,
                        "branch_target": branch_target,
                        "true_mode": true_mode,
                        "fallback_mode": "raw_conservative",
                        "call_line": int(call.get("call_line") or 0),
                        "call_inst": str(call.get("call_inst") or ""),
                        "target_module": str(call.get("target_module") or ""),
                        "target_stem": str(call.get("target_stem") or ""),
                        "false_mode": false_mode,
                    }
                )

    deduped: Dict[str, List[Dict[str, Any]]] = {}
    for proc, rows_out in process_edges.items():
        seen: Set[Tuple[Any, ...]] = set()
        keep: List[Dict[str, Any]] = []
        for row in sorted(
            rows_out,
            key=lambda r: (
                int(r["compare_line"]),
                int(r["branch_line"]),
                int(r["call_line"]),
                str(r["target_stem"]),
            ),
        ):
            key = (row["compare_line"], row["branch_line"], row["call_line"], row["target_stem"], row["call_inst"])
            if key in seen:
                continue
            seen.add(key)
            keep.append(row)
        if keep:
            deduped[proc] = keep

    return deduped


def _default_output_path(script_path: Path) -> Path:
    return script_path.resolve().parent / "process_guarded_file_calls.json"


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract process-gated cross-file ASM calls.")
    parser.add_argument("--process-json", required=True, help="JSON with unique_processes (example: process/lu82_function_processes.json)")
    parser.add_argument("--blueprint-dir", default="temp/output_latest/asm", help="Directory containing *.asm.json blueprints")
    parser.add_argument("--output", help="Output JSON path (default: process/process_guarded_file_calls.json)")
    args = parser.parse_args()

    process_json = Path(args.process_json).expanduser().resolve()
    blueprint_dir = Path(args.blueprint_dir).expanduser().resolve()
    output_path = Path(args.output).expanduser().resolve() if args.output else _default_output_path(Path(__file__))

    if not blueprint_dir.exists():
        raise FileNotFoundError(f"Blueprint directory not found: {blueprint_dir}")
    if not process_json.exists():
        raise FileNotFoundError(f"Process JSON not found: {process_json}")

    asm_blueprints = sorted(blueprint_dir.glob("*.asm.json"))
    asm_stems = {p.name[: -len(".asm.json")].lower() for p in asm_blueprints}
    process_set = _load_processes(process_json)

    files_out: Dict[str, Any] = {}
    files_scanned = 0
    files_with_results = 0
    total_edges = 0
    total_process_entries = 0

    for bp in asm_blueprints:
        files_scanned += 1
        stem = bp.name[: -len(".asm.json")].lower()
        proc_edges = _analyze_with_blueprint(bp, process_set, asm_stems)
        analysis_mode = "blueprint"

        if not proc_edges:
            continue

        proc_payload: Dict[str, Any] = {}
        for proc in sorted(proc_edges.keys()):
            edges = proc_edges[proc]
            if not edges:
                continue
            file_calls = sorted({str(e.get("target_stem") or "") for e in edges if str(e.get("target_stem") or "")})
            if not file_calls:
                continue
            proc_payload[proc] = {
                "file_calls": file_calls,
                "edges": edges,
            }
            total_edges += len(edges)
            total_process_entries += 1

        if not proc_payload:
            continue

        files_with_results += 1
        files_out[stem] = {
            "analysis_mode": analysis_mode,
            "processes": proc_payload,
        }

    output = {
        "metadata": {
            "generator": "extract_process_guarded_file_calls.py",
            "generated_at_utc": _now_utc_iso(),
            "blueprint_dir": str(blueprint_dir),
            "process_json": str(process_json),
            "files_scanned": files_scanned,
            "files_with_results": files_with_results,
            "process_count": len(process_set),
            "process_entries": total_process_entries,
            "edge_count": total_edges,
        },
        "files": dict(sorted(files_out.items(), key=lambda kv: kv[0])),
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")

    print(f"Process JSON: {process_json}")
    print(f"Blueprint dir: {blueprint_dir}")
    print(f"Output: {output_path}")
    print(f"Files scanned: {files_scanned}")
    print(f"Files with results: {files_with_results}")
    print(f"Process entries: {total_process_entries}")
    print(f"Edges: {total_edges}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
