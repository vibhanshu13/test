#!/usr/bin/env python3
"""Build per-process truncated file-call graphs starting from LU82 FUNCTION seeds.

For each LU82 process (from extract_function_processes output), this script:
1. Resolves the LU82 FUNCTION call site to an internal file edge.
2. Traverses file_call_graph forward from that seed target.
3. Applies process-specific target-level blocking rules from
   process_guarded_file_calls.json, i.e. skip only blocked source->target edges
   while allowing other outgoing edges from the same source.
4. Emits process-wise nodes/edges and reverse file->process mapping.
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _normalize_process_name(value: Any) -> str:
    return str(value or "").strip().upper()


def _normalize_file_id(value: Any) -> str:
    return str(value or "").strip().lower()


def _default_output_path(script_path: Path) -> Path:
    return script_path.resolve().parent / "process_truncated_file_graph.json"


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _load_lu82_entries(process_json_path: Path, root_file: str) -> Tuple[List[Dict[str, Any]], List[str]]:
    payload = _load_json(process_json_path)
    entries = payload.get("entries") or []
    unique_processes = [
        _normalize_process_name(p)
        for p in (payload.get("unique_processes") or [])
        if _normalize_process_name(p)
    ]

    out: List[Dict[str, Any]] = []
    for row in entries:
        proc = _normalize_process_name(row.get("process"))
        seg = str(row.get("target_segment") or "").strip().upper()
        if not proc or not seg:
            continue
        out.append(
            {
                "process": proc,
                "target_segment": seg,
                "line": int(row.get("line") or 0),
                "source": root_file,
            }
        )

    # deterministic
    out.sort(key=lambda r: (r["process"], r["line"], r["target_segment"]))
    unique_processes = sorted({p for p in unique_processes if p})
    if not unique_processes:
        unique_processes = sorted({row["process"] for row in out})

    return out, unique_processes


def _load_target_block_rules(guarded_json_path: Path) -> Dict[str, Dict[str, Set[str]]]:
    payload = _load_json(guarded_json_path)
    files = payload.get("files") or {}
    out: Dict[str, Dict[str, Set[str]]] = defaultdict(lambda: defaultdict(set))

    for file_stem, fobj in files.items():
        source_file_id = _normalize_file_id(file_stem)
        processes = (fobj or {}).get("processes") or {}
        for proc, pobj in processes.items():
            proc_name = _normalize_process_name(proc)
            if not proc_name:
                continue
            file_calls = (pobj or {}).get("file_calls") or []
            for target in file_calls:
                target_id = _normalize_file_id(target)
                if not target_id:
                    continue
                out[proc_name][source_file_id].add(target_id)

    return out


def _index_graph_nodes(graph_payload: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for node in graph_payload.get("nodes") or []:
        node_id = _normalize_file_id(node.get("id"))
        if node_id:
            out[node_id] = node
    return out


def _load_or_build_file_graph(file_call_graph_path: Path) -> Dict[str, Any]:
    payload = _load_json(file_call_graph_path)
    if not isinstance(payload, dict):
        raise ValueError("Invalid file call graph payload.")
    if "edges" not in payload:
        raise ValueError("File call graph JSON must contain 'edges'.")
    return payload


def _build_edge_indices(
    graph_payload: Dict[str, Any],
) -> Tuple[Dict[str, List[Dict[str, Any]]], Dict[Tuple[str, str], Dict[str, Any]], List[Dict[str, Any]]]:
    """Return (adjacency_internal, edge_by_pair, lu82_outgoing_edges)."""
    adjacency_internal: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    edge_by_pair: Dict[Tuple[str, str], Dict[str, Any]] = {}
    lu82_outgoing: List[Dict[str, Any]] = []

    for edge in graph_payload.get("edges") or []:
        src = _normalize_file_id(edge.get("source"))
        tgt_raw = edge.get("target")
        tgt = _normalize_file_id(tgt_raw)
        if not src or not tgt:
            continue

        is_internal = bool(edge.get("is_internal"))

        normalized_edge = {
            "source": src,
            "target": tgt,
            "is_internal": is_internal,
            "instructions": sorted({str(i).upper() for i in (edge.get("instructions") or []) if str(i).strip()}),
            "call_sites": sorted(
                [
                    {
                        "source_block": str(cs.get("source_block") or ""),
                        "target_module": str(cs.get("target_module") or "").upper(),
                        "instruction": str(cs.get("instruction") or "").upper(),
                        "call_type": str(cs.get("call_type") or ""),
                        "line": int(cs.get("line") or 0),
                        "source_file": str(cs.get("source_file") or ""),
                    }
                    for cs in (edge.get("call_sites") or [])
                ],
                key=lambda x: (x["line"], x["instruction"], x["target_module"]),
            ),
        }

        edge_by_pair[(src, tgt)] = normalized_edge
        if src == "lu82":
            lu82_outgoing.append(normalized_edge)

        if is_internal:
            adjacency_internal[src].append(normalized_edge)

    for src in adjacency_internal:
        adjacency_internal[src].sort(key=lambda e: (e["target"], tuple(e["instructions"])))

    lu82_outgoing.sort(key=lambda e: (e["target"], tuple(e["instructions"])))
    return adjacency_internal, edge_by_pair, lu82_outgoing


def _match_seed_edges_for_entry(
    entry: Dict[str, Any],
    lu82_outgoing_edges: Sequence[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    target_segment = str(entry.get("target_segment") or "").upper()
    target_segment_lower = target_segment.lower()
    entry_line = int(entry.get("line") or 0)

    # First: exact line match from call sites.
    line_matches: List[Dict[str, Any]] = []
    for edge in lu82_outgoing_edges:
        for site in edge.get("call_sites") or []:
            if int(site.get("line") or 0) == entry_line and str(site.get("instruction") or "").upper() == "FUNCTION":
                line_matches.append(edge)
                break

    if line_matches:
        # keep edges whose call-site target_module matches LU82 target segment when possible
        exact_mod = []
        for edge in line_matches:
            mods = {str(cs.get("target_module") or "").upper() for cs in (edge.get("call_sites") or [])}
            if target_segment in mods:
                exact_mod.append(edge)
        if exact_mod:
            return exact_mod
        return line_matches

    # Fallback: resolve by target file id or call-site target_module.
    fallback: List[Dict[str, Any]] = []
    for edge in lu82_outgoing_edges:
        if edge.get("target") == target_segment_lower:
            fallback.append(edge)
            continue
        mods = {str(cs.get("target_module") or "").upper() for cs in (edge.get("call_sites") or [])}
        if target_segment in mods:
            fallback.append(edge)

    return fallback


def _traverse_with_target_blocks(
    seeds: Iterable[str],
    adjacency_internal: Dict[str, List[Dict[str, Any]]],
    blocked_targets_by_source: Dict[str, Set[str]],
) -> Tuple[Set[str], Set[Tuple[str, str]], Set[Tuple[str, str]]]:
    """Traverse internal graph and skip blocked source->target edges.

    Returns: (nodes, kept_edges, blocked_edges)
    """
    seen_nodes: Set[str] = set()
    seen_edges: Set[Tuple[str, str]] = set()
    blocked_edges: Set[Tuple[str, str]] = set()

    q: deque[str] = deque()
    for seed in seeds:
        s = _normalize_file_id(seed)
        if s:
            q.append(s)

    while q:
        cur = q.popleft()
        if cur in seen_nodes:
            continue
        seen_nodes.add(cur)

        blocked_targets = blocked_targets_by_source.get(cur, set())
        for edge in adjacency_internal.get(cur, []):
            src = _normalize_file_id(edge.get("source"))
            tgt = _normalize_file_id(edge.get("target"))
            if not src or not tgt:
                continue
            if tgt in blocked_targets:
                blocked_edges.add((src, tgt))
                continue
            seen_edges.add((src, tgt))
            if tgt not in seen_nodes:
                q.append(tgt)

    return seen_nodes, seen_edges, blocked_edges


def _edge_payload(edge: Dict[str, Any], blocked_by_rule: bool) -> Dict[str, Any]:
    return {
        "source": str(edge.get("source") or ""),
        "target": str(edge.get("target") or ""),
        "is_internal": bool(edge.get("is_internal")),
        "instructions": list(edge.get("instructions") or []),
        "blocked_by_rule": blocked_by_rule,
        "call_sites": list(edge.get("call_sites") or []),
    }


def _build_file_reverse_index(process_payload: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    per_file_processes: Dict[str, Set[str]] = defaultdict(set)
    per_file_edge_count: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))

    for proc, pobj in process_payload.items():
        for node in pobj.get("nodes") or []:
            per_file_processes[node].add(proc)
        for edge in pobj.get("edges") or []:
            src = _normalize_file_id(edge.get("source"))
            if src:
                per_file_processes[src].add(proc)
                per_file_edge_count[src][proc] += 1
            tgt = _normalize_file_id(edge.get("target"))
            if tgt:
                per_file_processes[tgt].add(proc)

    out: Dict[str, Dict[str, Any]] = {}
    for file_id in sorted(per_file_processes.keys()):
        proc_list = sorted(per_file_processes[file_id])
        edge_counts = {p: per_file_edge_count[file_id][p] for p in sorted(per_file_edge_count[file_id].keys())}
        out[file_id] = {
            "processes": proc_list,
            "process_count": len(proc_list),
            "edge_count_by_process_from_file": edge_counts,
        }

    return out


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Build per-process truncated file-call graphs using LU82 FUNCTION seeds."
    )
    parser.add_argument(
        "--process-json",
        default="process/lu82_function_processes.json",
        help="Path to LU82 FUNCTION process JSON (from extract_function_processes.py)",
    )
    parser.add_argument(
        "--guarded-json",
        default="process/process_guarded_file_calls.json",
        help="Path to process-guarded file mapping JSON",
    )
    parser.add_argument(
        "--file-call-graph",
        default="process/file_call_graph.json",
        help="Path to file_call_graph JSON",
    )
    parser.add_argument(
        "--root-file",
        default="lu82",
        help="Root dispatcher file stem (default: lu82)",
    )
    parser.add_argument(
        "--output",
        help="Output JSON path (default: process/process_truncated_file_graph.json)",
    )

    args = parser.parse_args()

    process_json_path = Path(args.process_json).expanduser().resolve()
    guarded_json_path = Path(args.guarded_json).expanduser().resolve()
    file_call_graph_path = Path(args.file_call_graph).expanduser().resolve()
    root_file = _normalize_file_id(args.root_file)
    output_path = Path(args.output).expanduser().resolve() if args.output else _default_output_path(Path(__file__))

    if not process_json_path.exists():
        raise FileNotFoundError(f"Process JSON not found: {process_json_path}")
    if not guarded_json_path.exists():
        raise FileNotFoundError(f"Guarded JSON not found: {guarded_json_path}")
    if not file_call_graph_path.exists():
        raise FileNotFoundError(f"File call graph JSON not found: {file_call_graph_path}")

    lu82_entries, unique_processes = _load_lu82_entries(process_json_path, root_file)
    target_block_rules = _load_target_block_rules(guarded_json_path)
    graph_payload = _load_or_build_file_graph(file_call_graph_path)
    _ = _index_graph_nodes(graph_payload)
    adjacency_internal, edge_by_pair, lu82_outgoing = _build_edge_indices(graph_payload)

    entries_by_process: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for entry in lu82_entries:
        entries_by_process[entry["process"]].append(entry)

    process_out: Dict[str, Any] = {}

    for proc in unique_processes:
        entries = entries_by_process.get(proc, [])
        blocked_targets_by_source = {
            src: set(tgts)
            for src, tgts in (target_block_rules.get(proc) or {}).items()
        }

        seed_edges: List[Dict[str, Any]] = []
        seed_targets_internal: Set[str] = set()
        unresolved_seed_targets: Set[str] = set()

        for entry in entries:
            matched_edges = _match_seed_edges_for_entry(entry, lu82_outgoing)

            if not matched_edges:
                unresolved_seed_targets.add(str(entry.get("target_segment") or "").upper())
                seed_edges.append(
                    {
                        "process": proc,
                        "lu82_line": int(entry.get("line") or 0),
                        "target_segment": str(entry.get("target_segment") or "").upper(),
                        "matched": False,
                        "resolved_target": None,
                    }
                )
                continue

            for edge in matched_edges:
                resolved_target = _normalize_file_id(edge.get("target"))
                is_internal = bool(edge.get("is_internal"))
                entry_line = int(entry.get("line") or 0)
                # Filter call_sites to only the one matching this process entry's line
                filtered_edge = dict(edge)
                filtered_call_sites = [
                    cs for cs in (edge.get("call_sites") or [])
                    if int(cs.get("line") or 0) == entry_line
                ]
                filtered_edge["call_sites"] = filtered_call_sites if filtered_call_sites else list(edge.get("call_sites") or [])
                seed_edges.append(
                    {
                        "process": proc,
                        "lu82_line": entry_line,
                        "target_segment": str(entry.get("target_segment") or "").upper(),
                        "matched": True,
                        "resolved_target": resolved_target if is_internal else None,
                        "is_internal": is_internal,
                        "edge": _edge_payload(
                            filtered_edge,
                            blocked_by_rule=(
                                _normalize_file_id(edge.get("target"))
                                in blocked_targets_by_source.get(_normalize_file_id(edge.get("source")), set())
                            ),
                        ),
                    }
                )
                if is_internal and resolved_target:
                    seed_targets_internal.add(resolved_target)

        # Traverse from internal seed targets and block configured source->target edges.
        reached_nodes, reached_edges_pairs, blocked_edges_pairs = _traverse_with_target_blocks(
            seeds=sorted(seed_targets_internal),
            adjacency_internal=adjacency_internal,
            blocked_targets_by_source=blocked_targets_by_source,
        )

        # Include root node + root->seed edges that matched and are internal.
        if seed_targets_internal:
            reached_nodes.add(root_file)

        process_edges: List[Dict[str, Any]] = []
        seen_pair: Set[Tuple[str, str]] = set()

        # add seed edges from root
        for seed in seed_edges:
            if not seed.get("matched"):
                continue
            edge = seed.get("edge") or {}
            src = _normalize_file_id(edge.get("source"))
            tgt = _normalize_file_id(edge.get("target"))
            if not src or not tgt:
                continue
            if not bool(edge.get("is_internal")):
                continue
            pair = (src, tgt)
            if tgt in blocked_targets_by_source.get(src, set()):
                continue
            if pair in seen_pair:
                continue
            seen_pair.add(pair)
            process_edges.append(edge)

        # add traversed internal edges
        for src, tgt in sorted(reached_edges_pairs):
            edge = edge_by_pair.get((src, tgt))
            if not edge:
                continue
            pair = (src, tgt)
            if pair in seen_pair:
                continue
            seen_pair.add(pair)
            process_edges.append(
                _edge_payload(
                    edge,
                    blocked_by_rule=(tgt in blocked_targets_by_source.get(src, set())),
                )
            )

        nodes_sorted = sorted(reached_nodes)
        if root_file not in nodes_sorted and seed_targets_internal:
            nodes_sorted = [root_file] + nodes_sorted

        process_out[proc] = {
            "truncation_mode": "target_level",
            "seed_count": len(entries),
            "seed_edges": sorted(
                seed_edges,
                key=lambda x: (
                    int(x.get("lu82_line") or 0),
                    str(x.get("target_segment") or ""),
                    str(x.get("resolved_target") or ""),
                ),
            ),
            "blocked_source_files": sorted(blocked_targets_by_source.keys()),
            "blocked_targets_by_source": {
                src: sorted(tgts) for src, tgts in sorted(blocked_targets_by_source.items(), key=lambda kv: kv[0])
            },
            "blocked_edges_filtered": [
                {"source": src, "target": tgt}
                for src, tgt in sorted(blocked_edges_pairs)
            ],
            "unresolved_seed_targets": sorted(unresolved_seed_targets),
            "nodes": nodes_sorted,
            "edges": sorted(
                process_edges,
                key=lambda e: (
                    str(e.get("source") or ""),
                    str(e.get("target") or ""),
                ),
            ),
            "node_count": len(nodes_sorted),
            "edge_count": len(process_edges),
        }

    reverse_files = _build_file_reverse_index(process_out)

    files_with_any_process = len(reverse_files)
    processes_with_edges = sum(1 for p in process_out.values() if int(p.get("edge_count") or 0) > 0)

    output_payload = {
        "metadata": {
            "generator": "build_process_truncated_file_graph.py",
            "generated_at_utc": _now_utc_iso(),
            "truncation_mode": "target_level",
            "root_file": root_file,
            "process_json": str(process_json_path),
            "guarded_json": str(guarded_json_path),
            "file_call_graph": str(file_call_graph_path),
            "process_count": len(unique_processes),
            "processes_with_edges": processes_with_edges,
            "files_with_any_process": files_with_any_process,
        },
        "processes": {k: process_out[k] for k in sorted(process_out.keys())},
        "files": reverse_files,
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(output_payload, indent=2) + "\n", encoding="utf-8")

    print(f"Process JSON: {process_json_path}")
    print(f"Guarded JSON: {guarded_json_path}")
    print(f"File call graph: {file_call_graph_path}")
    print(f"Root file: {root_file}")
    print(f"Output: {output_path}")
    print(f"Processes: {len(unique_processes)}")
    print(f"Processes with edges: {processes_with_edges}")
    print(f"Files with any process: {files_with_any_process}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
