# Process Algorithm

This document captures the complete algorithm used in `process/`.

## Goal

Given LU82 process dispatch definitions, compute process-wise file-call graphs where process-specific blocked targets are filtered at edge level.

---

## End-to-End Pipeline

1. Extract LU82 process seeds
- Script: `process/extract_function_processes.py`
- Input: `temp/asm/lu82.asm`
- Output:
  - `process/lu82_function_processes.json`
  - `process/lu82_function_processes_list.txt`

2. Build process-guarded target rules
- Script: `process/extract_process_guarded_file_calls.py`
- Inputs:
  - `process/lu82_function_processes.json`
  - ASM blueprints (`temp/output_latest/asm/*.asm.json`)
- Output:
  - `process/process_guarded_file_calls.json`

3. Build file-level call graph
- Script: root `file_call_graph.py`
- Inputs:
  - `temp/asm`
  - `temp/output_latest/asm`
- Output:
  - `process/file_call_graph.json`

4. Build process traversal graph with target-level blocking
- Script: `process/build_process_truncated_file_graph.py`
- Inputs:
  - `process/lu82_function_processes.json`
  - `process/process_guarded_file_calls.json`
  - `process/file_call_graph.json`
- Output:
  - `process/process_truncated_file_graph.json`

---

## Algorithm 1: Extract LU82 Process Seeds

Source: `extract_function_processes.py`

1. Read ASM file line by line.
2. Match lines of form:
- `FUNCTION <process>,<segment>`
3. Ignore comments/blank lines and macro-formal definitions (`&NAME`, `&SEG`, etc.).
4. Record for each match:
- `line`
- `process`
- `target_segment`
- trailing `description`
5. Build:
- `entries[]`
- unique ordered `unique_processes[]`

Output contract:
- `unique_processes` is canonical process set for downstream scripts.
- `entries` retains line-level evidence used for deterministic seed matching.

---

## Algorithm 2: Build Process-Guarded File Calls

Source: `extract_process_guarded_file_calls.py`

### 2.1 Inputs and instruction sets

- Process set from `unique_processes`
- Instruction sets from `process/instructions.py`:
  - `TRIGGER_INST`
  - `BRANCH_INST`
  - `CROSS_FILE_INST`

### 2.2 Process token matching

Only right-side compare operand is checked.
Recognized forms:
- `C'XXXX'`
- `=C'XXXX'`
- `LG#XXXX`

### 2.3 Per-file analysis over blueprint CFG

For each `*.asm.json` file:
1. Build CFG from `blocks` + `incoming_branches` + `call_graph` branch edges.
2. Build fallthrough map.
3. Index cross-file calls by source block where `instruction in CROSS_FILE_INST`.

### 2.4 Find trigger comparisons

For each flow item where `inst in TRIGGER_INST`:
1. Extract selector variable (LHS) and RHS.
2. Match RHS against process set.
3. Find nearest semantic conditional branch in same flow.
4. Resolve comparison true/false successors using branch semantics.
5. Compute block reachability sets.

### 2.5 Collection logic (relaxed)

For each matched process `P`:

Case A:
- Collect calls from `false_reach - true_reach`

Case B:
- Find other comparisons on same selector variable where RHS is not `P`
- Follow other comparison positive reach (`other_true`)
- Collect calls directly from `other_true` (no subtraction)

### 2.6 Output shaping

For each source file and process:
- `file_calls`: unique target stems
- `edges`: line-level evidence fields (`compare_line`, `branch_line`, `call_line`, etc.)

Only non-empty process entries are emitted.

---

## Algorithm 3: Build Process Graph with Target-Level Blocking

Source: `build_process_truncated_file_graph.py`

### 3.1 Build per-process block rules

From `process_guarded_file_calls.json`:
- For each source file `S`
- For each process `P`
- Read `file_calls[]`
- Build rules: `blocked_targets_by_source[P][S] = {targets...}`

This is edge-level blocking, not node-level blocking.

### 3.2 Build traversal graph indices

From `file_call_graph.json`:
- Keep internal edges (`is_internal = true`) in adjacency map.
- Keep LU82 outgoing edges for seed resolution.
- Keep edge-by-pair lookup for output reconstruction.

### 3.3 Resolve LU82 seeds per process

For each process entry from LU82:
1. Try line-accurate match on LU82 call sites (`entries[].line`).
2. If not matched, fallback by target segment/module token.
3. Keep only internal resolved targets as traversal seeds.
4. Preserve seed evidence in `seed_edges`.

### 3.4 BFS traversal with edge filtering

For each process `P`:
1. Initialize queue with internal seed targets.
2. Pop node `S`.
3. For each outgoing internal edge `S -> T`:
- If `T in blocked_targets_by_source[P][S]`:
  - do not traverse this edge
  - record in `blocked_edges_filtered`
- Else:
  - keep edge
  - enqueue `T` if unseen

Important behavior:
- Blocking one edge does not ban `T` globally.
- `T` can still appear if reachable through another allowed path.

### 3.5 Emit process outputs

Per process:
- `truncation_mode: "target_level"`
- `seed_edges`
- `blocked_source_files`
- `blocked_targets_by_source`
- `blocked_edges_filtered`
- `nodes`
- `edges`
- counts

Also emit reverse index:
- `files.<file>.processes`
- `files.<file>.edge_count_by_process_from_file`

---

## Correctness Notes

1. If `xh80 -> xh71` is blocked for C400, traversal does not enter `xh71` via that edge.
2. Descendants of `xh71` are absent unless another allowed path reaches them.
3. If `xh88 -> xh93` is blocked but `xh85 -> xh93` is allowed and reachable, `xh93` remains in graph.

This is expected under target-level semantics.

---

## Primary Commands

```bash
python3 process/extract_function_processes.py temp/asm/lu82.asm

python3 process/extract_process_guarded_file_calls.py \
  --process-json process/lu82_function_processes.json \
  --blueprint-dir temp/output_latest/asm \
  --output process/process_guarded_file_calls.json

python3 file_call_graph.py \
  --asm-dir temp/asm \
  --blueprint-dir temp/output_latest/asm \
  --output process/file_call_graph.json

python3 process/build_process_truncated_file_graph.py \
  --process-json process/lu82_function_processes.json \
  --guarded-json process/process_guarded_file_calls.json \
  --file-call-graph process/file_call_graph.json \
  --output process/process_truncated_file_graph.json
```
