"""Handle assembly line continuations."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class ContinuationResult:
    """Result of processing a line for continuations."""
    is_complete: bool
    text: Optional[str]
    continuation_count: int


class LineContinuationHandler:
    """Handles line continuations in assembly source.

    Assembly lines can be continued using a continuation character
    (typically 'X') in column 72, with continuation on the next line
    starting around column 16.
    """

    def __init__(self):
        self.accumulated_parts = []
        self.continuation_count = 0

    def process_line(self, line: str) -> ContinuationResult:
        """Process a line, handling continuations.

        Args:
            line: Assembly source line

        Returns:
            ContinuationResult indicating if line is complete
        """
        # Check if this line is a continuation (starts with spaces, follows a continuation)
        if self.accumulated_parts:
            # This is a continuation line
            continuation_text = line.strip()

            # Increment continuation count
            self.continuation_count += 1

            # Check if it ends with continuation character
            if continuation_text.endswith('X'):
                # More continuations to come
                self.accumulated_parts.append(continuation_text[:-1].strip())
                return ContinuationResult(
                    is_complete=False,
                    text=None,
                    continuation_count=self.continuation_count
                )
            else:
                # Final continuation
                self.accumulated_parts.append(continuation_text)
                # Join directly without extra spaces
                complete_text = ''.join(self.accumulated_parts)
                count = self.continuation_count

                # Reset for next line
                self.accumulated_parts = []
                self.continuation_count = 0

                return ContinuationResult(
                    is_complete=True,
                    text=complete_text,
                    continuation_count=count
                )

        # Check if this line has continuation
        if line.rstrip().endswith('X'):
            # Start accumulating
            self.accumulated_parts.append(line.rstrip()[:-1].rstrip())
            self.continuation_count = 0
            return ContinuationResult(
                is_complete=False,
                text=None,
                continuation_count=0
            )

        # Regular line, no continuation
        return ContinuationResult(
            is_complete=True,
            text=line,
            continuation_count=0
        )
