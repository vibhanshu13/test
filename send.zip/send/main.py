#!/usr/bin/env python3
"""Assembly Analyzer - Main entry point for analyzing z/TPF assembly files."""

import argparse
import json
import sys
from pathlib import Path
from multi_file.orchestrator import MultiFileOrchestrator
from multi_file.mixed_orchestrator import MixedLanguageOrchestrator
from json_emitter import JSONEmitter
from source_discovery import filter_discovered_paths, merge_discovery_exclude_patterns
from blueprint_io import write_blueprint


def main():
    """Analyze assembly files and output results."""
    parser = argparse.ArgumentParser(
        description="Analyze z/TPF assembly files and generate analysis reports",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Analyze a single file
  python3 main.py tests/fixtures/simple.asm

  # Analyze a directory (auto-discovers subdirectories for COPY includes)
  python3 main.py tests/fixtures/authorization/

  # Analyze multiple files
  python3 main.py file1.asm file2.asm file3.asm

  # Specify additional search paths for COPY includes (optional)
  python3 main.py -s ./extra-copybooks program.asm

  # Specify custom cache and output directories
  python3 main.py -c .cache -o output/ program.asm

  # Analyze with wildcard pattern
  python3 main.py tests/fixtures/*.asm
        """
    )

    parser.add_argument(
        'files',
        nargs='+',
        help='Assembly file(s) to analyze (supports wildcards)'
    )

    parser.add_argument(
        '-s', '--search-path',
        action='append',
        dest='search_paths',
        help='Directory to search for COPY includes (can be specified multiple times)'
    )

    parser.add_argument(
        '-m', '--macro-lib',
        action='append',
        dest='macro_libs',
        help='Macro library file to load (can be specified multiple times). '
             'These take precedence over auto-discovered macros.'
    )

    parser.add_argument(
        '-c', '--cache-dir',
        default='.cache',
        help='Directory for caching analysis results (default: .cache)'
    )

    parser.add_argument(
        '-o', '--output-dir',
        default='output',
        help='Directory for JSON output files (default: output/)'
    )

    parser.add_argument(
        '--no-json',
        action='store_true',
        help='Skip JSON file generation'
    )

    parser.add_argument(
        '--no-coverage-review',
        action='store_true',
        help='Skip deterministic coverage review for generated ASM/C/C++ JSON outputs'
    )

    parser.add_argument(
        '--exclude',
        action='append',
        default=[],
        metavar='GLOB',
        help='Exclude recursively discovered files/directories matching glob patterns '
             '(can be specified multiple times)'
    )

    parser.add_argument(
        '--no-gitignore',
        action='store_true',
        help='Do not use git ignore rules when recursively discovering files in directories'
    )

    parser.add_argument(
        '--include-test-sources',
        action='store_true',
        help='Include recursively discovered files under common test/temp/fixture paths'
    )

    parser.add_argument(
        '--lineage-name',
        help='Variable/register/memory name to trace in variable lineage output'
    )

    parser.add_argument(
        '--lineage-kind',
        default='variable',
        help='Kind for lineage trace (variable, register, memory, literal, use)'
    )

    parser.add_argument(
        '--lineage-direction',
        default='forward',
        help='Direction for lineage trace (forward or backward)'
    )

    parser.add_argument(
        '--lineage-depth',
        type=int,
        default=5,
        help='Max depth for lineage trace (default: 5)'
    )

    parser.add_argument(
        '--lineage-scope',
        help='Limit lineage trace to a specific scope (e.g., function name)'
    )

    parser.add_argument(
        '--lineage-export',
        help='Export variable lineage graph to a JSON file or directory'
    )

    parser.add_argument(
        '--lineage-dot',
        help='Export variable lineage graph to DOT file or directory'
    )

    parser.add_argument(
        '--load-universe',
        action='store_true',
        help='Load variable universe files for universe-aware lineage tracking'
    )

    parser.add_argument(
        '--universe-dir',
        default='output',
        help='Directory containing universe files (default: output/)'
    )

    args = parser.parse_args()

    # Collect all source files
    explicit_files = []
    wildcard_files = []
    recursive_file_candidates = []
    recursive_dir_candidates = []
    root_directories = set()
    # Track the base directory for preserving structure in output
    base_input_dir = None

    asm_exts = {".asm", ".mac", ".s", ".cpy", ".copy"}
    c_exts = {".c"}
    cpp_exts = {".cc", ".cpp", ".cxx", ".hpp", ".h"}
    make_exts = {".mak"}
    make_names = {"Makefile", "makefile", "GNUmakefile"}
    all_exts = asm_exts | c_exts | cpp_exts | make_exts

    for arg in args.files:
        path = Path(arg)

        # Handle glob patterns
        if '*' in arg:
            base_dir = Path(arg.split('*')[0]) if arg.split('*')[0] else Path('.')
            pattern = arg[len(str(base_dir)):].lstrip('/')
            matched = list(base_dir.glob(pattern))
            if not matched:
                print(f"Warning: No files matched pattern: {arg}")
            for file_path in matched:
                if file_path.is_file():
                    wildcard_files.append(file_path.resolve())
        elif path.is_file():
            explicit_files.append(path.resolve())
        elif path.is_dir():
            # Track the root directory for recursive search path discovery
            root_dir = path.resolve()
            root_directories.add(root_dir)

            # Set base directory for preserving structure
            if base_input_dir is None:
                base_input_dir = root_dir.parent

            # Analyze all .asm files in directory
            matched = []
            for ext in all_exts:
                matched.extend(list(path.rglob(f"*{ext}")))
            for name in make_names:
                matched.extend(list(path.rglob(name)))
            if not matched:
                print(f"Warning: No source files found in directory: {arg}")
            for source_file in matched:
                if source_file.is_file() and not source_file.name.startswith("."):
                    recursive_file_candidates.append((source_file.resolve(), root_dir))

            for subdir in root_dir.rglob("*"):
                if subdir.is_dir():
                    recursive_dir_candidates.append((subdir.resolve(), root_dir))
        else:
            print(f"Error: File not found: {arg}")
            sys.exit(1)

    recursive_files = []
    included_recursive_dirs = []
    excluded_recursive_files = 0
    excluded_recursive_dirs = 0
    effective_exclude_patterns = merge_discovery_exclude_patterns(
        args.exclude,
        include_test_sources=args.include_test_sources,
    )

    if recursive_file_candidates:
        recursive_files, excluded_recursive_files = filter_discovered_paths(
            recursive_file_candidates,
            exclude_patterns=effective_exclude_patterns,
            respect_gitignore=not args.no_gitignore,
        )

    if recursive_dir_candidates:
        included_recursive_dirs, excluded_recursive_dirs = filter_discovered_paths(
            recursive_dir_candidates,
            exclude_patterns=effective_exclude_patterns,
            respect_gitignore=not args.no_gitignore,
        )

    file_paths = []
    seen_files = set()
    for source_file in explicit_files + wildcard_files + recursive_files:
        if source_file in seen_files:
            continue
        seen_files.add(source_file)
        file_paths.append(source_file)

    auto_search_paths = {file_path.parent.resolve() for file_path in file_paths}
    for subdir in included_recursive_dirs:
        auto_search_paths.add(subdir.resolve())

    if excluded_recursive_files or excluded_recursive_dirs:
        print(
            f"Discovery filters excluded {excluded_recursive_files} file(s) and "
            f"{excluded_recursive_dirs} directory path(s)."
        )

    if not file_paths:
        print("Error: No source files found after applying discovery filters")
        sys.exit(1)

    # Combine user-specified search paths with auto-detected ones
    if args.search_paths:
        final_search_paths = [Path(p).resolve() for p in args.search_paths]
        # Add auto-detected paths if not already specified
        for auto_path in auto_search_paths:
            if auto_path not in final_search_paths:
                final_search_paths.append(auto_path)
    else:
        final_search_paths = list(auto_search_paths)

    print(f"\n{'='*60}")
    print(f"Assembly Analyzer - Processing {len(file_paths)} file(s)")
    print(f"{'='*60}\n")

    print(f"Search paths for COPY includes:")
    for search_path in final_search_paths:
        print(f"  - {search_path}")
    print()

    # Load variable universe if requested
    universe_asm_names = set()
    universe_cpp_names = set()

    if args.load_universe:
        from models.variable_universe import load_variable_names

        universe_dir = Path(args.universe_dir)
        asm_names_path = universe_dir / "asm_variable_names.json"
        cpp_names_path = universe_dir / "cpp_variable_names.json"

        if asm_names_path.exists():
            universe_asm_names = load_variable_names(asm_names_path)
            print(f"Loaded ASM universe: {len(universe_asm_names)} variables")
        else:
            print(f"Warning: ASM universe file not found: {asm_names_path}")

        if cpp_names_path.exists():
            universe_cpp_names = load_variable_names(cpp_names_path)
            print(f"Loaded C++ universe: {len(universe_cpp_names)} variables")
        else:
            print(f"Warning: C++ universe file not found: {cpp_names_path}")

        print()

    # Setup orchestrator
    cache_dir = Path(args.cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)

    macro_libs = [Path(p).resolve() for p in args.macro_libs] if args.macro_libs else None

    has_c_family = any(p.suffix.lower() in (c_exts | cpp_exts) for p in file_paths)
    has_make = any(p.suffix.lower() in make_exts or p.name in make_names for p in file_paths)

    if has_c_family or has_make:
        orchestrator = MixedLanguageOrchestrator(
            cache_dir=cache_dir,
            search_paths=final_search_paths,
            macro_libs=macro_libs,
            universe_asm_names=universe_asm_names if args.load_universe else None,
            universe_cpp_names=universe_cpp_names if args.load_universe else None
        )
    else:
        orchestrator = MultiFileOrchestrator(
            cache_dir=cache_dir,
            search_paths=final_search_paths,
            macro_libs=macro_libs,
            universe_asm_names=universe_asm_names if args.load_universe else None,
            universe_cpp_names=universe_cpp_names if args.load_universe else None
        )

    # Analyze files
    print("Analyzing files...")
    result = orchestrator.analyze_files(file_paths)

    # Print summary
    print(f"\n{'='*60}")
    print("Analysis Results Summary")
    print(f"{'='*60}\n")

    print(f"Files Analyzed: {len(result.file_results)}")

    # Pre-existing: orchestrator skips the EXTRN/ENTRY registry for
    # C++-only input sets, leaving result.global_registry == None.
    if result.global_registry is None:
        print("\n(No ENTRY/EXTRN registry — C/C++-only analysis.)")
    else:
        # Show ENTRY symbols (exports)
        print(f"\nENTRY Symbols ({len(result.global_registry.entries)}):")
        for name, symbols in result.global_registry.entries.items():
            for symbol in symbols:
                file_name = Path(symbol.file).name if symbol.file else "unknown"
                print(f"  - {name:20s} (in {file_name})")

    # Show EXTRN symbols (imports) — guarded for C/C++-only runs.
    if result.global_registry is not None:
        print(f"\nEXTRN Symbols ({len(result.global_registry.extrns)}):")
        for name, symbols in result.global_registry.extrns.items():
            referenced_by = [Path(s.file).name for s in symbols if s.file]
            refs = ", ".join(set(referenced_by[:3]))
            if len(referenced_by) > 3:
                refs += f" +{len(referenced_by)-3} more"
            print(f"  - {name:20s} (referenced by: {refs})")

    # Show unresolved externals
    if result.unresolved_externals:
        print(f"\nUnresolved Externals ({len(result.unresolved_externals)}):")
        for name in result.unresolved_externals:
            print(f"  - {name}")

    # Show per-file details
    print(f"\n{'='*60}")
    print("Per-File Details")
    print(f"{'='*60}\n")

    for file_result in result.file_results:
        file_name = file_result.file_path.name
        print(f"\n{file_name}:")
        print(f"  Exports: {len(file_result.exports)} ({', '.join(file_result.exports[:5])})")
        print(f"  Imports: {len(file_result.imports)} ({', '.join(file_result.imports[:5])})")
        print(f"  Sections: {len(file_result.sections)} ({', '.join(file_result.sections[:5])})")

        if file_result.call_graph:
            print(f"  Call Graph Nodes: {len(file_result.call_graph.nodes)}")
            print(f"  Call Graph Edges: {len(file_result.call_graph.edges)}")

        if args.lineage_name:
            lineage_graph = file_result.analysis_context.get_metadata("variable_lineage")
            if lineage_graph:
                trace_edges = lineage_graph.trace(
                    args.lineage_name,
                    args.lineage_kind,
                    args.lineage_direction,
                    args.lineage_depth,
                    args.lineage_scope
                )
                file_result.analysis_context.add_metadata(
                    "lineage_trace",
                    [edge.to_dict() for edge in trace_edges]
                )
                print(f"  Lineage Trace Edges: {len(trace_edges)}")

    # Export variable lineage if requested
    if args.lineage_export:
        export_path = Path(args.lineage_export)
        export_dir = export_path

        if len(result.file_results) > 1 or export_path.suffix == "" or export_path.is_dir():
            export_dir.mkdir(parents=True, exist_ok=True)
            for file_result in result.file_results:
                graph = file_result.analysis_context.get_metadata("variable_lineage")
                if not graph:
                    continue
                output_file = export_dir / f"{file_result.file_path.stem}.lineage.json"
                output_file.write_text(json.dumps(graph.to_dict(), indent=2))
                print(f"  Wrote lineage: {output_file}")
        else:
            graph = result.file_results[0].analysis_context.get_metadata("variable_lineage")
            if graph:
                export_path.parent.mkdir(parents=True, exist_ok=True)
                export_path.write_text(json.dumps(graph.to_dict(), indent=2))
                print(f"  Wrote lineage: {export_path}")

    if args.lineage_dot:
        export_path = Path(args.lineage_dot)
        export_dir = export_path

        if len(result.file_results) > 1 or export_path.suffix == "" or export_path.is_dir():
            export_dir.mkdir(parents=True, exist_ok=True)
            for file_result in result.file_results:
                graph = file_result.analysis_context.get_metadata("variable_lineage")
                if not graph:
                    continue
                output_file = export_dir / f"{file_result.file_path.stem}.lineage.dot"
                output_file.write_text(graph.to_dot())
                print(f"  Wrote lineage DOT: {output_file}")
        else:
            graph = result.file_results[0].analysis_context.get_metadata("variable_lineage")
            if graph:
                export_path.parent.mkdir(parents=True, exist_ok=True)
                export_path.write_text(graph.to_dot())
                print(f"  Wrote lineage DOT: {export_path}")

    # Offer JSON output
    if not args.no_json:
        print(f"\n{'='*60}")
        print("JSON Output")
        print(f"{'='*60}\n")

        emitter = JSONEmitter()
        reviewer = None
        if not args.no_coverage_review:
            try:
                from tools.review_parser_output import review as reviewer
            except Exception as exc:
                print(f"Warning: Could not load coverage reviewer ({exc}); continuing without coverage review.")
                reviewer = None
        output_base_dir = Path(args.output_dir)
        output_base_dir.mkdir(parents=True, exist_ok=True)
        coverage_review_exts = asm_exts | c_exts | cpp_exts

        try:
            from llm.summarizer import generate_business_summary
            _summarizer = generate_business_summary
        except Exception as _exc:
            print(f"Warning: Could not load LLM summarizer ({_exc}); business_summary will be null.")
            _summarizer = None

        for file_result in result.file_results:
            json_dict = emitter.emit(file_result.analysis_context)

            # Preserve directory structure relative to base input directory
            input_file = file_result.file_path

            if base_input_dir and base_input_dir in input_file.parents:
                # Preserve the relative path structure and keep original extension
                relative_path = input_file.relative_to(base_input_dir)
                output_file = output_base_dir / (str(relative_path) + ".json")
            else:
                # If no base directory, include full filename with extension
                output_file = output_base_dir / f"{input_file.name}.json"

            # Create parent directories if needed
            output_file.parent.mkdir(parents=True, exist_ok=True)

            if _summarizer:
                try:
                    json_dict["business_summary"] = _summarizer(input_file)
                    print(f"    Summary generated for {input_file.name}")
                except Exception as exc:
                    print(f"    Warning: Could not generate business summary for {input_file.name}: {exc}")
                    json_dict["business_summary"] = None
            else:
                json_dict["business_summary"] = None

            write_blueprint(output_file, json_dict)
            print(f"  Wrote: {output_file}")

            # Auto-run deterministic coverage review for source files with line-aware analyzers.
            if reviewer and input_file.suffix.lower() in coverage_review_exts:
                review_result = reviewer(output_file, input_file)
                json_dict["coverage_review"] = {
                    "ok": review_result.ok,
                    "score": round(review_result.score, 2),
                    "errors": review_result.errors,
                    "warnings": review_result.warnings,
                    "line_audit": review_result.line_audit_summary,
                    "metrics": [
                        {
                            "name": metric.name,
                            "covered": metric.covered,
                            "expected": metric.expected,
                            "ratio": round(metric.ratio, 6),
                            "weight": metric.weight,
                            "points": round(metric.points, 6),
                        }
                        for metric in review_result.metrics
                    ],
                }
                write_blueprint(output_file, json_dict)
                status = "PASS" if review_result.ok else "FAIL"
                print(f"    Coverage Review: {status} ({review_result.score:.1f}%)")

    # Release analysis contexts — allows the GC to reclaim ~10 MB per file
    # immediately after all output files have been written.
    for file_result in result.file_results:
        file_result.analysis_context = None

    print(f"\n{'='*60}")
    print("Analysis Complete!")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
