"""Classify assembly instructions for control flow analysis."""

from enum import Enum
from typing import Optional, List


class ControlFlowType(Enum):
    """Types of control flow instructions."""
    SUBROUTINE_CALL = "subroutine_call"
    MODE_TRANSITION = "mode_transition"
    BRANCH = "branch"
    EXECUTE = "execute"
    RETURN = "return"


class InstructionClassifier:
    """Classify assembly instructions by control flow type.

    Recognizes:
    - Subroutine calls: BAL, BALR, BAS, BASR, BRAS, BRASL
    - Mode transitions: BASSM, BASM, BSM
    - Branches: B*, BC, BCR, etc.
    - Returns: BR R14
    - Execute: EX
    """

    def __init__(self):
        self.subroutine_calls = {
            "BAL", "BALR", "BAS", "BASR", "BRAS", "BRASL",
            # J-type subroutine equivalents
            "JAS", "JASL",
        }

        self.mode_transitions = {
            "BASSM", "BASM", "BSM"
        }

        self.branch_prefixes = ["B"]  # B, BC, BCR, BZ, BNZ, etc.

        self.execute = {"EX"}

    def classify(self, instruction: str) -> Optional[ControlFlowType]:
        """Classify an instruction by control flow type.

        Args:
            instruction: Instruction mnemonic (e.g., "BAL", "BR")

        Returns:
            ControlFlowType if control flow instruction, None otherwise
        """
        if not instruction:
            return None

        instr_upper = instruction.upper()

        if instr_upper in self.subroutine_calls:
            return ControlFlowType.SUBROUTINE_CALL

        if instr_upper in self.mode_transitions:
            return ControlFlowType.MODE_TRANSITION

        if instr_upper in self.execute:
            return ControlFlowType.EXECUTE

        # Check branch instructions (B, BC, BCR, BZ, BNZ, etc.)
        if instr_upper.startswith("B"):
            # Exclude the call instructions we already handled
            if instr_upper not in self.subroutine_calls and \
               instr_upper not in self.mode_transitions:
                return ControlFlowType.BRANCH

        # J-type extended branch mnemonics (TPF/z-Architecture):
        # J, JE, JH, JL, JM, JO, JP, JZ, JNE, JNH, JNL, JNM, JNO, JNP, JNZ, JXHG, JXLE
        if instr_upper.startswith("J"):
            if instr_upper not in self.subroutine_calls:
                return ControlFlowType.BRANCH

        return None

    def is_return(self, instruction: str, operands: List[str]) -> bool:
        """Check if instruction is a return (BR R14, BCR 15,R14, BACKC).

        Args:
            instruction: Instruction mnemonic
            operands: Instruction operands

        Returns:
            True if this is a return instruction
        """
        if not instruction:
            return False

        instr_upper = instruction.upper()

        # z/TPF return macro form
        if instr_upper == "BACKC":
            return True

        # BR R14 — branch to link register (standard return)
        # BR R10 — return from BAS/JAS subroutine (R10 is the conventional
        #           BAS link register in z/TPF HLASM code)
        if instr_upper == "BR":
            if not operands:
                return False
            return operands[0].upper() in ("R14", "14", "R10", "10")

        # BCR 15,R14 — unconditional register-indirect return
        if instr_upper == "BCR" and len(operands) >= 2:
            mask = operands[0].strip().upper()
            reg  = operands[1].strip().upper()
            return mask == "15" and reg in ("R14", "14")

        return False

    def is_indirect(self, instruction: str, operands: List[str]) -> bool:
        """Check if this is an indirect call (target in register).

        Args:
            instruction: Instruction mnemonic
            operands: Instruction operands

        Returns:
            True if this is an indirect call
        """
        if not instruction or not operands:
            return False

        instr_upper = instruction.upper()

        # BALR and BASR with two register operands are indirect
        if instr_upper in ("BALR", "BASR"):
            if len(operands) >= 2:
                # Check if second operand is a register (not a label)
                second_op = operands[1].upper()
                # If it starts with R or is a digit, it's a register
                if second_op.startswith("R") or second_op.isdigit():
                    return True

        return False

    def is_register_indirect_branch(self, instruction: str, operands: List[str]) -> bool:
        """True for register-indirect branches that are not returns and not NOPs.

        Covers:
          BR Rx      — where Rx is not R14/R10 (not a return register)
          BCR mask,Rx — where mask != 0 (not a NOP) and Rx is not R14/R10

        These instructions branch to a function address loaded into a register
        at runtime, making them indirect calls from a call-graph perspective.

        Args:
            instruction: Instruction mnemonic
            operands: Instruction operands

        Returns:
            True when the instruction is a register-indirect branch-to-call
        """
        if not instruction or not operands:
            return False

        instr_upper = instruction.upper()

        if instr_upper == "BR":
            reg = operands[0].strip().upper()
            # R14 and R10 are return registers — handled by is_return()
            if reg in ("R14", "14", "R10", "10"):
                return False
            # Must be a general-purpose register (R0–R15 or 0–15)
            return reg.startswith("R") or (reg.isdigit() and 0 <= int(reg) <= 15)

        if instr_upper == "BCR" and len(operands) >= 2:
            mask = operands[0].strip().upper()
            reg  = operands[1].strip().upper()
            # mask=0 → branch-never (NOP form: BCR 0,0)
            if mask == "0":
                return False
            # R14 and R10 are return registers
            if reg in ("R14", "14", "R10", "10"):
                return False
            return reg.startswith("R") or (reg.isdigit() and 0 <= int(reg) <= 15)

        return False
