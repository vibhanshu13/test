import msgpack
import sys

def search_variable(file_path, var_name):
    with open(file_path, 'rb') as f:
        data = msgpack.unpack(f)
    
    print(f"Searching for {var_name} in {file_path}")
    
    if 'symbols' in data:
        if var_name in data['symbols']:
            print(f"Found in symbols: {data['symbols'][var_name]}")
    
    if 'variable_lineage' in data:
        if var_name in data['variable_lineage']:
            print(f"Found in variable_lineage: {data['variable_lineage'][var_name]}")

    if 'dsect_layouts' in data:
        for dsect, layout in data['dsect_layouts'].items():
            if var_name in layout.get('fields', {}):
                print(f"Found in dsect_layout {dsect}: {layout['fields'][var_name]}")

if __name__ == "__main__":
    search_variable(sys.argv[1], sys.argv[2])
