"""process_analysis backend package.

All LLM access in this package MUST go through ``process_analysis.backend.llm``
(which wraps ``llm.caller.call_llm``). Importing ``google.genai``, ``openai``,
or any other LLM SDK directly is a design violation.
"""
