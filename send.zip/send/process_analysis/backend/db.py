"""SQLite helpers for process_analysis.

The schema lives in ``schema.sql`` (siblings of this file). We do **not**
duplicate the DDL in Python — read the SQL, execute it, done.

Connection model: one connection per request/task, opened with
``check_same_thread=False`` so FastAPI's threadpool can share it safely under
read-mostly workloads. Writes are serialized via SQLite's own file-level
locking; for the demo's volume this is more than enough.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from process_analysis.backend.config import settings

_SCHEMA_PATH = Path(__file__).parent / "schema.sql"


def register_vector(conn: sqlite3.Connection) -> None:
    """Load sqlite-vec extension for ANN cosine distance queries.

    Gracefully no-ops if sqlite-vec is not installed — BM25 fallback remains.
    Must be called before any vec_* function is used in a query.
    """
    try:
        import sqlite_vec
        sqlite_vec.load(conn)
    except Exception:
        pass  # BM25-only mode; ANN search unavailable


def _connect(path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(
        str(path),
        check_same_thread=False,
        isolation_level=None,           # autocommit; explicit transactions when needed
    )
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA busy_timeout = 10000")  # wait on lock (parallel writers) instead of erroring
    register_vector(conn)
    return conn


def _cols(conn: sqlite3.Connection, table: str) -> set:
    return {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}


def init_schema() -> None:
    """Create all tables/indices/virtual tables. Idempotent."""
    settings.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    sql = _SCHEMA_PATH.read_text(encoding="utf-8")
    with _connect(settings.DB_PATH) as conn:
        conn.executescript(sql)
        # ------------------------------------------------------------------ #
        # Idempotent column migrations (ALTER TABLE only when column absent). #
        # ------------------------------------------------------------------ #

        # Legacy: content_hash on process (added before project scoping)
        if "content_hash" not in _cols(conn, "process"):
            conn.execute("ALTER TABLE process ADD COLUMN content_hash TEXT")

        # Phase 2 enrichment columns on block and file (added to DDL after initial deploy).
        _block_enrichment = [
            ("touches_persistence",       "INTEGER DEFAULT 0"),
            ("touches_storage_lifecycle", "INTEGER DEFAULT 0"),
            ("inside_commit_scope",       "INTEGER"),
            ("incoming_guards_json",      "TEXT"),
            ("outgoing_guards_json",      "TEXT"),
            ("is_callc_bridge",           "INTEGER DEFAULT 0"),
        ]
        for col_name, col_def in _block_enrichment:
            try:
                if col_name not in _cols(conn, "block"):
                    conn.execute(f"ALTER TABLE block ADD COLUMN {col_name} {col_def}")
            except Exception:
                pass

        _file_enrichment = [
            ("touches_persistence",       "INTEGER DEFAULT 0"),
            ("touches_storage_lifecycle", "INTEGER DEFAULT 0"),
            ("is_callc_bridge",           "INTEGER DEFAULT 0"),
        ]
        for col_name, col_def in _file_enrichment:
            try:
                if col_name not in _cols(conn, "file"):
                    conn.execute(f"ALTER TABLE file ADD COLUMN {col_name} {col_def}")
            except Exception:
                pass

        # Hierarchical Walkthrough — key_variables added after initial deploy.
        try:
            if "key_variables_json" not in _cols(conn, "hier_subprocess"):
                conn.execute("ALTER TABLE hier_subprocess ADD COLUMN key_variables_json TEXT")
        except Exception:
            pass

        # Hierarchical Walkthrough is PROJECT-FREE: the hierarchy is keyed only
        # by (process, node_id) — a process name always maps to the same code,
        # so the cache is global. Drop any legacy hier_* table that still
        # carries a project_id column and let schema.sql re-create it with the
        # corrected, project-free key (these rows are regenerable cache).
        _hier_dropped = False
        for _t in ("hier_subprocess", "hier_walk_node", "hier_walk_meta"):
            try:
                if _cols(conn, _t) and "project_id" in _cols(conn, _t):
                    conn.execute(f"DROP TABLE {_t}")
                    _hier_dropped = True
            except Exception:
                pass
        if _hier_dropped:
            conn.executescript(sql)  # re-create dropped hier_* (project-free)

        # §4.5.3 hard constraint #3 — self-contained walkthrough cards.
        _walkthrough_card_enrichment = [
            ("previous_card_title",   "TEXT"),
            ("next_card_title",       "TEXT"),
            ("next_segment_hint",     "TEXT"),
            ("guards_summary_json",   "TEXT"),
            ("role_summary",          "TEXT"),
        ]
        for col_name, col_def in _walkthrough_card_enrichment:
            try:
                if col_name not in _cols(conn, "process_narrative_card"):
                    conn.execute(
                        f"ALTER TABLE process_narrative_card ADD COLUMN {col_name} {col_def}"
                    )
            except Exception:
                pass

        # Project scoping: add project_id to every table that lacked it.
        _needs_project_id = [
            # original tables
            "process", "file", "block", "variable",
            "investigation_message", "conversation_message",
            # Phase 1 tables
            "call_edge", "io_site", "io_site_variable",
            "subfile_session", "storage_lifecycle", "commit_scope",
            "variable_alias", "ecb_alias",
            "block_utility_classification",
            # Phase 3 tables
            "walk_node", "walk_truncation",
            # Phase 4 tables
            "variable_context", "variable_classification", "variable_meaning",
            # Phase 5 tables
            "process_flow", "commit_scope_narrative", "process_artifact",
            "payload_lineage", "process_narrative_card",
            # Shared tables
            "entity_business_name", "process_meta",
            "chunk_embedding", "variable_context_embedding", "block_embedding",
            "chat_session",
        ]
        for table in _needs_project_id:
            try:
                existing = _cols(conn, table)
            except Exception:
                continue
            if "project_id" not in existing:
                conn.execute(
                    f"ALTER TABLE {table} ADD COLUMN "
                    f"project_id TEXT NOT NULL DEFAULT 'default'"
                )

        # Create project-scoped indices AFTER project_id columns are guaranteed to exist.
        _project_id_indices = [
            "CREATE INDEX IF NOT EXISTS ix_process_project  ON process(project_id)",
            "CREATE INDEX IF NOT EXISTS ix_file_process     ON file(project_id, process)",
            "CREATE INDEX IF NOT EXISTS ix_block_file       ON block(project_id, process, file_path)",
            "CREATE INDEX IF NOT EXISTS ix_variable_process ON variable(project_id, process)",
            "CREATE INDEX IF NOT EXISTS ix_inv_msg_project  ON investigation_message(project_id, process, variable)",
            "CREATE INDEX IF NOT EXISTS ix_conversation     ON conversation_message(project_id, conversation_id, idx)",
        ]
        for idx_sql in _project_id_indices:
            try:
                conn.execute(idx_sql)
            except Exception:
                pass


@contextmanager
def get_conn() -> Iterator[sqlite3.Connection]:
    """Short-lived connection context for one request/task."""
    conn = _connect(settings.DB_PATH)
    try:
        yield conn
    finally:
        conn.close()


def fts5_available() -> bool:
    """Return True if this SQLite build supports FTS5 (required by chunk_fts)."""
    try:
        with _connect(":memory:") as conn:
            conn.execute("CREATE VIRTUAL TABLE _probe USING fts5(x)")
        return True
    except sqlite3.OperationalError:
        return False
