"""Celery application — 3-queue topology per §19.5.1.

Three queues:
  q_emit  concurrency=2   CPU-heavy, multi-hour orchestration
  q_io    concurrency=4   I/O-bound disk / DB work
  q_llm   concurrency=2   LLM API calls, rate-limited

Start workers:
    celery -A process_analysis.backend.celery_app worker \
        -Q q_emit -c 2 --loglevel=info &
    celery -A process_analysis.backend.celery_app worker \
        -Q q_io -c 4 --loglevel=info &
    celery -A process_analysis.backend.celery_app worker \
        -Q q_llm -c 2 --loglevel=info &
"""

from __future__ import annotations

import json
import logging

from celery import Celery
from celery.signals import task_failure, task_revoked

from process_analysis.backend.config import settings

logger = logging.getLogger("process_analysis.celery")

app = Celery(
    "process_analysis",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
)

app.conf.update(
    # §19.5.1 global settings — do not override without reason
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=50,
    task_soft_time_limit=71 * 3600,
    task_time_limit=72 * 3600,
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="UTC",
    enable_utc=True,
    # Route every task — never rely on default queue (§19.5.1 rule 1)
    task_routes={
        "process_analysis.backend.tasks.build_task.run_full_pipeline": {"queue": "q_emit"},
        "process_analysis.backend.tasks.build_task.run_variable_pipeline": {"queue": "q_emit"},
        "process_analysis.backend.tasks.build_task.run_phase1_static": {"queue": "q_io"},
        "process_analysis.backend.tasks.build_task.run_schema_migrate": {"queue": "q_io"},
        "process_analysis.backend.tasks.build_task.run_index_rebuild": {"queue": "q_io"},
        "process_analysis.backend.tasks.build_task.run_phase2_summaries": {"queue": "q_llm"},
        "process_analysis.backend.tasks.build_task.run_phase3_walk": {"queue": "q_llm"},
        "process_analysis.backend.tasks.build_task.run_phase4_variable_context": {"queue": "q_llm"},
        "process_analysis.backend.tasks.build_task.run_phase5_synthesis": {"queue": "q_llm"},
        "process_analysis.backend.tasks.hierwalk_task.run_hierwalk_batch": {"queue": "q_llm"},
    },
)


# ---------------------------------------------------------------------------
# §19.5.8 Signal handlers — mark jobs failed on worker death
# ---------------------------------------------------------------------------

def _mark_failed(task_id: str, error: str) -> None:
    try:
        from process_analysis.backend.redis_client import get_redis
        r = get_redis()
        # Find any build key matching this task_id (pattern scan, small fan-out)
        for key in r.scan_iter(f"build:*:{task_id}"):
            r.setex(key, 86400, json.dumps({"status": "failed", "error": error}))
    except Exception:
        logger.exception("Failed to mark task %s as failed in Redis", task_id)


@task_failure.connect
def on_task_failure(task_id: str, exception: Exception, **kwargs) -> None:
    _mark_failed(task_id, str(exception))


@task_revoked.connect
def on_task_revoked(request, **kwargs) -> None:
    _mark_failed(request.id, "task revoked")


# Register tasks with the worker. Without this import the worker's strategy
# table is empty and incoming tasks fail with KeyError on dispatch.
from process_analysis.backend.tasks import build_task  # noqa: E402, F401
from process_analysis.backend.tasks import hierwalk_task  # noqa: E402, F401
