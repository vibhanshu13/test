"""The single LLM entry point for the process_analysis subsystem.

DESIGN RULE (DESIGN.md §8.5): every LLM interaction in
``process_analysis/`` goes through ``call_llm_json`` (or its raw companion
``call_llm_text``). Both delegate to the central
``llm.caller.call_llm(prompt, system_prompt=None) -> str``, which always uses
Gemini 2.5 Pro (per ``settings.LLM_MODEL_NAME``).

Why this wrapper at all (vs. importing ``call_llm`` directly):
  * Forces structured JSON output via a uniform parse-or-retry loop.
  * Sanitizes common Gemini quirks (markdown code fences around JSON, BOM,
    leading/trailing prose).
  * Centralizes the "schema hint" instruction so we can swap prompt templates
    later in one place.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, Optional, Sequence, Type, TypeVar

from pydantic import BaseModel, ValidationError

from llm.caller import call_llm as _call_llm   # the ONLY allowed Gemini call


_TModel = TypeVar("_TModel", bound=BaseModel)

logger = logging.getLogger(__name__)

_FENCE_RE = re.compile(r"^\s*```(?:json|JSON)?\s*\n?(.*?)\n?\s*```\s*$", re.DOTALL)


# ---------------------------------------------------------------------------
# Raw text passthrough
# ---------------------------------------------------------------------------

def call_llm_text(prompt: str, *, system_prompt: Optional[str] = None) -> str:
    """Plain-text Gemini call. Use ``call_llm_json`` for structured output."""
    return _call_llm(prompt, system_prompt=system_prompt)


# ---------------------------------------------------------------------------
# JSON with retry
# ---------------------------------------------------------------------------

class LLMJSONError(RuntimeError):
    """Raised when ``call_llm_json`` exhausts retries without valid JSON."""


def _strip_fences(text: str) -> str:
    """Remove ```json fences``` Gemini sometimes adds despite instructions."""
    text = text.strip().lstrip("﻿")  # strip BOM if any
    m = _FENCE_RE.match(text)
    if m:
        return m.group(1).strip()
    return text


def _find_balanced_json(text: str) -> Optional[str]:
    """Best-effort: find the first balanced {...} or [...] block in ``text``.

    Useful when Gemini prepends explanatory prose despite "JSON only" instructions.
    """
    text = text.strip()
    for opener, closer in (("{", "}"), ("[", "]")):
        start = text.find(opener)
        if start == -1:
            continue
        depth = 0
        in_str = False
        esc = False
        for i in range(start, len(text)):
            c = text[i]
            if esc:
                esc = False
                continue
            if c == "\\":
                esc = True
                continue
            if c == '"':
                in_str = not in_str
                continue
            if in_str:
                continue
            if c == opener:
                depth += 1
            elif c == closer:
                depth -= 1
                if depth == 0:
                    return text[start : i + 1]
    return None


def call_llm_json(
    prompt: str,
    *,
    schema_hint: str,
    required_keys: Optional[Sequence[str]] = None,
    system_prompt: Optional[str] = None,
    max_retries: int = 3,
) -> Any:
    """Call the LLM, expect JSON, parse-or-retry — and optionally validate shape.

    Args:
        prompt: The user prompt body (without schema instructions — those are
                appended automatically).
        schema_hint: A textual description of the expected JSON shape. Will be
                appended to ``prompt`` inside a strict "return ONLY JSON"
                envelope.
        required_keys: If provided, the parsed result MUST be a dict containing
                all of these top-level keys. If a key is missing the call is
                retried with an explanation appended to the prompt. This is the
                cheapest correctness gate against partial-object outputs
                (observed empirically with Gemini on long C++ source).
        system_prompt: Optional system instruction (passed through to
                ``llm.caller.call_llm``).
        max_retries: Total attempts including the first. Must be >= 1.

    Returns:
        The parsed JSON object (dict or list).

    Raises:
        LLMJSONError: If parsing/shape-validation fails after ``max_retries`` attempts.
    """
    if max_retries < 1:
        raise ValueError("max_retries must be >= 1")

    envelope = (
        f"{prompt}\n\n"
        f"---\n"
        f"Return ONLY a JSON value matching this schema, with no prose, no "
        f"markdown fences, no commentary, no explanation. JSON only.\n\n"
        f"SCHEMA:\n{schema_hint}\n"
    )

    last_error: str = ""
    last_raw: str = ""

    for attempt in range(1, max_retries + 1):
        if attempt == 1:
            full_prompt = envelope
        else:
            # Re-prompt with the parse error so the model self-corrects.
            full_prompt = (
                f"{envelope}\n\n"
                f"PREVIOUS ATTEMPT FAILED to parse. Error:\n  {last_error}\n"
                f"Previous output (first 400 chars):\n  {last_raw[:400]}\n\n"
                f"Return ONLY a valid JSON value. JSON only."
            )

        try:
            raw = _call_llm(full_prompt, system_prompt=system_prompt)
        except Exception as exc:  # noqa: BLE001  — surface LLM transport failures verbatim
            last_error = f"LLM call raised: {exc!r}"
            last_raw = ""
            logger.warning("call_llm_json attempt %d/%d: %s", attempt, max_retries, last_error)
            continue

        last_raw = raw
        candidate = _strip_fences(raw)
        parsed: Any
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError as exc:
            balanced = _find_balanced_json(candidate)
            if balanced:
                try:
                    parsed = json.loads(balanced)
                except json.JSONDecodeError as exc2:
                    last_error = f"JSONDecodeError on balanced extraction: {exc2.msg} at pos {exc2.pos}"
                    logger.warning("call_llm_json attempt %d/%d: %s", attempt, max_retries, last_error)
                    continue
            else:
                last_error = f"JSONDecodeError: {exc.msg} at pos {exc.pos}; no balanced block found"
                logger.warning("call_llm_json attempt %d/%d: %s", attempt, max_retries, last_error)
                continue

        # Shape validation
        if required_keys is not None:
            if not isinstance(parsed, dict):
                last_error = (
                    f"Top-level JSON is {type(parsed).__name__}, expected an object "
                    f"with keys {list(required_keys)}"
                )
                logger.warning("call_llm_json attempt %d/%d: %s", attempt, max_retries, last_error)
                continue
            missing = [k for k in required_keys if k not in parsed]
            if missing:
                last_error = (
                    f"Top-level JSON object is missing required keys: {missing}. "
                    f"Present keys: {sorted(parsed.keys())}"
                )
                logger.warning("call_llm_json attempt %d/%d: %s", attempt, max_retries, last_error)
                continue

        return parsed

    raise LLMJSONError(
        f"Failed to obtain valid JSON after {max_retries} attempts. "
        f"Last error: {last_error}. Last raw (truncated): {last_raw[:300]!r}"
    )


# ---------------------------------------------------------------------------
# Pydantic-typed convenience (Q-P4a, approved 2026-05-27)
# ---------------------------------------------------------------------------

def call_llm_model(
    prompt: str,
    model: Type[_TModel],
    *,
    schema_hint: Optional[str] = None,
    system_prompt: Optional[str] = None,
    max_retries: int = 3,
) -> _TModel:
    """Like ``call_llm_json`` but returns a validated Pydantic model instance.

    Treats ``pydantic.ValidationError`` as a soft error: the next attempt is
    re-prompted with the field-level error messages so the model can
    self-correct. ``LLMJSONError`` after exhausted retries.

    ``schema_hint`` is optional — when omitted, we derive it from the
    Pydantic model's ``model_json_schema()`` so the LLM sees the same
    structural contract Pydantic will enforce.
    """
    if max_retries < 1:
        raise ValueError("max_retries must be >= 1")

    if schema_hint is None:
        schema_hint = (
            "A JSON OBJECT matching this Pydantic JSON Schema:\n"
            + json.dumps(model.model_json_schema(), indent=2)
        )

    envelope = (
        f"{prompt}\n\n"
        f"---\n"
        f"Return ONLY a JSON value matching this schema, with no prose, no "
        f"markdown fences, no commentary, no explanation. JSON only.\n\n"
        f"SCHEMA:\n{schema_hint}\n"
    )

    last_error: str = ""
    last_raw: str = ""

    for attempt in range(1, max_retries + 1):
        if attempt == 1:
            full_prompt = envelope
        else:
            full_prompt = (
                f"{envelope}\n\n"
                f"PREVIOUS ATTEMPT FAILED. Validation error:\n  {last_error}\n"
                f"Previous output (first 400 chars):\n  {last_raw[:400]}\n\n"
                f"Return ONLY a valid JSON object that matches the schema. JSON only."
            )

        try:
            raw = _call_llm(full_prompt, system_prompt=system_prompt)
        except Exception as exc:  # noqa: BLE001
            last_error = f"LLM transport: {exc!r}"
            last_raw = ""
            logger.warning("call_llm_model attempt %d/%d: %s", attempt, max_retries, last_error)
            continue

        last_raw = raw
        candidate = _strip_fences(raw)
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError as exc:
            balanced = _find_balanced_json(candidate)
            if balanced:
                try:
                    parsed = json.loads(balanced)
                except json.JSONDecodeError as exc2:
                    last_error = f"JSONDecodeError on balanced extraction: {exc2.msg} at pos {exc2.pos}"
                    logger.warning("call_llm_model attempt %d/%d: %s", attempt, max_retries, last_error)
                    continue
            else:
                last_error = f"JSONDecodeError: {exc.msg} at pos {exc.pos}; no balanced block found"
                logger.warning("call_llm_model attempt %d/%d: %s", attempt, max_retries, last_error)
                continue

        # Unwrap common LLM quirks before Pydantic validation:
        # • double-encoded JSON: model returned a JSON string instead of an object
        # • single-element list wrapping: model wrapped the object in an array
        # • flat list of strings: model returned only the summary bullets as a JSON array
        if isinstance(parsed, str):
            try:
                parsed = json.loads(parsed)
            except json.JSONDecodeError:
                pass
        if isinstance(parsed, list):
            if len(parsed) == 1 and isinstance(parsed[0], dict):
                parsed = parsed[0]
            elif all(isinstance(x, str) for x in parsed):
                parsed = {"summary": parsed}

        try:
            return model.model_validate(parsed)
        except ValidationError as vexc:
            # Compact, model-friendly error message.
            last_error = "Pydantic validation error: " + "; ".join(
                f"{'.'.join(str(p) for p in e['loc'])}: {e['msg']}" for e in vexc.errors()
            )
            logger.warning("call_llm_model attempt %d/%d: %s [type=%s repr=%s]",
                           attempt, max_retries, last_error, type(parsed).__name__, repr(parsed)[:200])
            continue

    raise LLMJSONError(
        f"Failed to obtain a {model.__name__} after {max_retries} attempts. "
        f"Last error: {last_error}. Last raw (truncated): {last_raw[:300]!r}"
    )
