"""Redis connection pool — single entry point for all Redis access.

§19.5.6: Never create a bare Redis() instance in route or task code.
Import get_redis() from this module only.
"""

from __future__ import annotations

from redis import ConnectionPool, Redis

from process_analysis.backend.config import settings

_pool: ConnectionPool | None = None


def _get_pool() -> ConnectionPool:
    global _pool
    if _pool is None:
        _pool = ConnectionPool.from_url(
            settings.REDIS_URL,
            max_connections=settings.REDIS_MAX_CONNECTIONS,
            decode_responses=True,
        )
    return _pool


def get_redis() -> Redis:
    """Return a Redis client backed by the shared connection pool."""
    return Redis(connection_pool=_get_pool())
