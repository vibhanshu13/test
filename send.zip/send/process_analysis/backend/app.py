"""FastAPI application for process_analysis.

Run locally:

    cd /Users/prathamgupta/Documents/asm-modernizer
    env/bin/uvicorn process_analysis.backend.app:app --reload --port 8010

The ``--reload`` flag is fine for dev. CORS is open to localhost:5173 + 3000
for the Vite frontend.
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from process_analysis.backend.config import settings
from process_analysis.backend.db import fts5_available, init_schema
from process_analysis.backend.routes import build as build_routes
from process_analysis.backend.routes import chat as chat_routes
from process_analysis.backend.routes import files as files_routes
from process_analysis.backend.routes import flows as flows_routes
from process_analysis.backend.routes import forward as forward_routes
from process_analysis.backend.routes import hierwalk as hierwalk_routes
from process_analysis.backend.routes import investigation as investigation_routes
from process_analysis.backend.routes import io_sites as io_sites_routes
from process_analysis.backend.routes import processes as processes_routes
from process_analysis.backend.routes import projects as projects_routes
from process_analysis.backend.routes import variable_context as variable_context_routes
from process_analysis.backend.routes import variables as variables_routes
from process_analysis.backend.routes import walk as walk_routes
from process_analysis.backend.routes import walkthrough as walkthrough_routes

logger = logging.getLogger("process_analysis")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")


@asynccontextmanager
async def lifespan(_: FastAPI):
    if not fts5_available():
        logger.warning(
            "SQLite was built without FTS5; chunk_fts will fail. "
            "Retrieval (Phase 8) requires FTS5 — re-install Python with system "
            "SQLite that has FTS5, or rebuild sqlite3."
        )
    init_schema()
    logger.info("DB ready at %s", settings.DB_PATH)
    logger.info("Data processes dir: %s", settings.DATA_PROCESSES_DIR)
    yield


app = FastAPI(
    title="process_analysis",
    version="0.2.0",
    description="Business-user explanation surface over the ASM/C++ codebase. Phase 2 skeleton.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


@app.get("/demo/v1/health")
def health() -> dict:
    """Lightweight liveness probe — no DB / no LLM."""
    return {"status": "ok", "version": app.version, "fts5": fts5_available()}


app.include_router(projects_routes.router, prefix="/demo/v1/projects")
app.include_router(processes_routes.router, prefix="/demo/v1/projects")
app.include_router(build_routes.router, prefix="/demo/v1/projects")
app.include_router(variables_routes.router, prefix="/demo/v1/projects")
app.include_router(forward_routes.router, prefix="/demo/v1/projects")
app.include_router(chat_routes.router, prefix="/demo/v1/projects")
app.include_router(files_routes.router, prefix="/demo/v1/projects")
app.include_router(investigation_routes.router, prefix="/demo/v1/projects")
# §12 new endpoints (Stage A stubs — real data flows in as pipeline phases complete)
app.include_router(walk_routes.router, prefix="/demo/v1/projects")
app.include_router(io_sites_routes.router, prefix="/demo/v1/projects")
app.include_router(flows_routes.router, prefix="/demo/v1/projects")
app.include_router(walkthrough_routes.router, prefix="/demo/v1/projects")
app.include_router(variable_context_routes.router, prefix="/demo/v1/projects")
# Hierarchical Walkthrough (self-contained; no dependency on Phase 1–5)
app.include_router(hierwalk_routes.router, prefix="/demo/v1/projects")
