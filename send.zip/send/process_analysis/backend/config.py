"""Backend settings for process_analysis.

Settings are loaded from the repo-root ``.env`` (same file the existing API
uses). Only fields specific to the demo are declared here — Gemini settings
(``GEMINI_API_KEY``, ``LLM_MODEL_NAME``, ...) live in ``api.config.settings``
and are read by ``llm/caller.py`` directly, NOT duplicated here.
"""

from __future__ import annotations

from pathlib import Path
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict

REPO_ROOT = Path(__file__).resolve().parents[2]


class DemoSettings(BaseSettings):
    """All demo-specific config. Add new fields here, never inline-default in code."""

    model_config = SettingsConfigDict(
        env_file=str(REPO_ROOT / ".env"),
        env_prefix="DEMO_",          # all settings overridable via DEMO_<NAME>=...
        extra="ignore",
        case_sensitive=False,
    )

    # Data sources (read-only)
    REPO_ROOT: Path = REPO_ROOT
    DATA_PROCESSES_DIR: Path = REPO_ROOT / "data" / "processes"
    TEMP_ASM_DIR: Path = REPO_ROOT / "temp" / "asm"
    TEMP_OUTPUT_DIR: Path = REPO_ROOT / "temp" / "output_latest"
    PROCESS_TRUNCATED_GRAPH: Path = REPO_ROOT / "process" / "process_truncated_file_graph.json"

    # Demo state (read-write)
    DB_PATH: Path = REPO_ROOT / "process_analysis" / "backend" / "knowledge.db"

    # HTTP
    PORT: int = 8010
    HOST: str = "127.0.0.1"
    CORS_ORIGINS: List[str] = [
        "http://localhost:5173",      # Vite dev server
        "http://127.0.0.1:5173",
        "http://localhost:3000",      # CRA dev (Zenflow_Frontend) default
        "http://127.0.0.1:3000",
        "http://localhost:3001",      # CRA fallback ports
        "http://127.0.0.1:3001",
        "http://localhost:3002",
        "http://127.0.0.1:3002",
    ]

    # Build pipeline (Q-S1 approved 2026-05-27)
    # Within a topo level, this many block/file summaries run in parallel.
    # Tune down if Gemini RPM limits are hit; up if quota allows.
    MAX_CONCURRENT_LLM_CALLS: int = 16

    # Redis (§19.5.6) — connection pool used by all route and task code
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_MAX_CONNECTIONS: int = 20

    # Celery (§19.5.1) — broker + result backend
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"


settings = DemoSettings()
