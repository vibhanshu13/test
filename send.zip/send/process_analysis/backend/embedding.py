"""Single embedding entry point — Rule 1-E (§11.5).

Every embedding call in process_analysis goes through call_embedding().
No direct genai.embed_content calls outside this module.

Model: gemini-embedding-001 (Google), truncated to 768 dimensions (Matryoshka
``output_dimensionality``) and L2-normalised so cosine similarity matches the
unit-vector behaviour of the retired text-embedding-004 model.
Uses the new ``google.genai`` Client (same SDK + GEMINI_API_KEY credential as
generation in llm/caller.py).
Batching: up to 100 texts per API call (gemini-embedding-001 request limit).
"""

from __future__ import annotations

import logging
import math
import threading
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from typing import List

logger = logging.getLogger("process_analysis.embedding")

_EMBEDDING_MODEL = "gemini-embedding-001"
_EMBEDDING_DIMS = 768      # Matryoshka truncation — keeps the stored vector width
_BATCH_SIZE = 100          # gemini-embedding-001 per-request limit
_MAX_WORKERS = 4           # concurrent batch calls (§11.5)
_EMBED_CACHE_MAX = 100     # §19.5.5 — never grow unbounded

# A single shared genai.Client is reused across batches (mirrors llm/caller.py):
# the client owns an httpx connection pool + TLS context and is thread-safe.
_client_instance = None
_client_lock = threading.Lock()


def _get_client():
    global _client_instance
    if _client_instance is None:
        with _client_lock:
            if _client_instance is None:
                from google import genai
                from api.config import settings as _s
                _client_instance = genai.Client(api_key=_s.GEMINI_API_KEY)
    return _client_instance


def _l2_normalize(vec: List[float]) -> List[float]:
    """Unit-normalise a vector. gemini-embedding-001 only returns normalised
    output at its native 3072 dims; truncated dims must be normalised by us."""
    norm = math.sqrt(sum(x * x for x in vec))
    if norm == 0.0:
        return vec
    return [x / norm for x in vec]


@lru_cache(maxsize=_EMBED_CACHE_MAX)
def _cached_embed_single(text: str) -> tuple:
    """LRU-cached embedding for a single text. Returns a tuple (hashable)."""
    return _embed_batch_raw([text])[0]


def _embed_batch_raw(texts: List[str]) -> List[List[float]]:
    """Embed one batch (≤ _BATCH_SIZE texts). Returns a list of 768-dim vectors."""
    try:
        from google.genai import types
        client = _get_client()
        result = client.models.embed_content(
            model=_EMBEDDING_MODEL,
            contents=texts,
            config=types.EmbedContentConfig(
                output_dimensionality=_EMBEDDING_DIMS,
                task_type="RETRIEVAL_DOCUMENT",
            ),
        )
        return [_l2_normalize(list(e.values)) for e in result.embeddings]
    except ImportError:
        logger.warning("google-genai not installed; returning zero embeddings")
        return [[0.0] * _EMBEDDING_DIMS for _ in texts]
    except Exception as exc:
        logger.error("Embedding API error: %s", exc)
        return [[0.0] * _EMBEDDING_DIMS for _ in texts]


def call_embedding(texts: List[str]) -> List[List[float]]:
    """Embed a list of texts (any length). Batched internally at BATCH_SIZE.

    Rule 1-E: this is the ONLY embedding entry point in process_analysis.
    Every other module must import and call this function.

    Returns a list of 768-dimensional float vectors, one per input text.
    """
    if not texts:
        return []

    # Split into batches
    batches = [texts[i : i + _BATCH_SIZE] for i in range(0, len(texts), _BATCH_SIZE)]

    if len(batches) == 1:
        return _embed_batch_raw(batches[0])

    # Parallel batch calls capped at _MAX_WORKERS
    results: List[List[float]] = []
    with ThreadPoolExecutor(max_workers=_MAX_WORKERS, thread_name_prefix="emb") as pool:
        futures = [pool.submit(_embed_batch_raw, batch) for batch in batches]
        for fut in futures:
            results.extend(fut.result())
    return results
