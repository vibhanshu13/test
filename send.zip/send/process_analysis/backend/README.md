# explanability_demo/backend

Phase 2 skeleton: FastAPI app + SQLite + single `call_llm` wrapper, plus the
first read-only endpoints serving `data/processes/<P>/` JSON.

## Run

```bash
cd /Users/prathamgupta/Documents/asm-modernizer
env/bin/uvicorn explanability_demo.backend.app:app --reload --port 8010
```

Then:

```bash
curl -s http://127.0.0.1:8010/demo/v1/health | jq
curl -s http://127.0.0.1:8010/demo/v1/processes | jq
curl -s http://127.0.0.1:8010/demo/v1/processes/C400 | jq
curl -s http://127.0.0.1:8010/demo/v1/processes/C400/file-graph | jq '.edges | length'
```

## Test

```bash
env/bin/python -m pytest explanability_demo/backend/tests -v
```

## Layout

```
backend/
├── __init__.py
├── README.md           ← this file
├── app.py              ← FastAPI app, lifespan, CORS, route mount at /demo/v1
├── config.py           ← DemoSettings (pydantic), reads .env via DEMO_<NAME>
├── db.py               ← SQLite connect / init_schema / fts5_available
├── llm.py              ← call_llm_text + call_llm_json (THE ONLY LLM ENTRY)
├── schema.sql          ← DESIGN.md §11 schema (idempotent)
├── routes/
│   ├── __init__.py
│   └── processes.py    ← GET /processes, /{P}, /{P}/file-graph, /{P}/headers, /{P}/macros
├── schemas/
│   ├── __init__.py
│   └── processes.py    ← Pydantic response models
└── tests/
    ├── __init__.py
    ├── test_smoke.py       ← endpoint live tests (V2.1, V2.4, V2.5, V2.6, V2.7)
    └── test_llm_wrapper.py ← call_llm_json unit tests (V2.2, V2.3)
```

## Design rules baked in here

1. **No LLM call outside `backend/llm.py`.** That file is the only one
   allowed to `from llm.caller import call_llm`. Anything else in the demo
   imports `call_llm_text` / `call_llm_json` from this module. Enforced by
   `tests/test_smoke.py::test_no_direct_llm_sdk_imports_in_explanability_demo`.
2. **No embeddings.** No `chunk_embedding` table; no embedding API calls.
   Retrieval (Phase 8) is BM25 over FTS5 + `call_llm`-based rerank.
3. **Idempotent schema.** `init_schema()` runs on every startup.
4. **Data files are read-only inputs.** This service consumes
   `data/processes/<P>/*.json`; it never writes them. The generator that
   produces them is `explanability_demo/scripts/build_process_data.py`.

## Phase 2 endpoints

| Method | Path | Purpose | Validates |
|---|---|---|---|
| GET | `/demo/v1/health` | Liveness probe (no DB / no LLM) | V2.1 |
| GET | `/demo/v1/processes` | List all processes with summary counts | V2.5 |
| GET | `/demo/v1/processes/{P}` | Full per-process detail (file_graph + headers + macros summary + build status) | V2.6 |
| GET | `/demo/v1/processes/{P}/file-graph` | Full `file_graph.json` for graph rendering | V5.4 (later) |
| GET | `/demo/v1/processes/{P}/headers` | Full `headers.json` | V5.4 (later) |
| GET | `/demo/v1/processes/{P}/macros` | Full `macros.json` | V5.4 (later) |

## Stub-detection guard

`GET /processes/{P}` returns **409 Conflict** with a helpful message when the
`file_graph.json` looks like the pre-Phase-0 random stub (detected by the
absence of the `process` field, which only the new generator writes). The
error tells the caller exactly which script to run.
