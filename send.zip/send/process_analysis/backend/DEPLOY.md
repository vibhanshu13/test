# explanability_demo/backend — Deployment Notes

Cross-reference: [README.md](README.md) for layout, design rules, and endpoint list.

---

## Prerequisites

| Requirement | Detail |
|---|---|
| Python | 3.10+ |
| SQLite | Built with FTS5 (standard on macOS/Ubuntu 22+; verify with `python -c "import sqlite3; print(sqlite3.sqlite_version)"`) |
| Gemini API key | Set as `GEMINI_API_KEY` in the repo-root `.env` |
| z/TPF source tree | Must exist at `<repo-root>/temp/asm/` before running a build |
| Repo cloned | Full repo — the backend reads `data/processes/<P>/*.json` and `temp/asm/` |

---

## Quick Start (local)

Run all commands from the **repo root** (`/path/to/asm-modernizer`).

```bash
# 1. Create and activate a virtual environment
python3 -m venv env
source env/bin/activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Copy the env template and fill in your Gemini key
cp .env.example .env          # or edit .env directly if it already exists
#   Set: GEMINI_API_KEY=<your-key>

# 4. Start the backend
env/bin/uvicorn explanability_demo.backend.app:app --reload --port 8010

# 5. Verify it's up
curl -s http://127.0.0.1:8010/demo/v1/health | python3 -m json.tool
```

Expected health response:
```json
{"status": "ok", "version": "0.2.0", "fts5": true}
```

If `fts5` is `false`, retrieval (Phase 8) will not work — rebuild Python against a system SQLite with FTS5.

---

## Environment Variables

All demo-specific variables use the `DEMO_` prefix and are read from the repo-root `.env`. The main API's Gemini settings (`GEMINI_API_KEY`, `LLM_MODEL_NAME`, etc.) are read directly by `llm/caller.py` — do **not** duplicate them under `DEMO_`.

| Variable | Default | Description |
|---|---|---|
| `DEMO_DB_PATH` | `explanability_demo/backend/knowledge.db` | SQLite database path (absolute or relative to repo root) |
| `DEMO_PORT` | `8010` | Port uvicorn binds to |
| `DEMO_HOST` | `127.0.0.1` | Interface uvicorn binds to |
| `DEMO_CORS_ORIGINS` | `["http://localhost:5173","http://127.0.0.1:5173","http://localhost:3000","http://127.0.0.1:3000"]` | Allowed CORS origins (JSON list) |
| `DEMO_MAX_CONCURRENT_LLM_CALLS` | `16` | Max parallel Gemini calls during a build |
| `DEMO_DATA_PROCESSES_DIR` | `data/processes` | Root dir for per-process JSON files (read-only) |
| `DEMO_TEMP_ASM_DIR` | `temp/asm` | z/TPF source tree root (read-only) |
| `DEMO_TEMP_OUTPUT_DIR` | `temp/output_latest` | Pipeline output directory (read-only) |
| `GEMINI_API_KEY` | *(required, no default)* | Gemini API key — no `DEMO_` prefix |
| `LLM_MODEL_NAME` | `gemini-3-flash-preview` | Gemini model name |
| `LLM_MAX_TOKENS` | `8192` | Max tokens per LLM call |
| `LLM_TEMPERATURE` | `0.2` | LLM temperature |

---

## First-Time Data Build

After the server is running and `temp/asm/` is populated, trigger knowledge extraction for a process `P` (e.g. `C400`):

```bash
# Start the build (async — returns immediately)
curl -s -X POST http://127.0.0.1:8010/demo/v1/processes/C400/build | python3 -m json.tool

# Poll until status is "completed" or "failed"
watch -n 5 'curl -s http://127.0.0.1:8010/demo/v1/processes/C400/build/status | python3 -m json.tool'
```

The build walks the file graph, summarises blocks and files via Gemini, and stores results in SQLite. At ~3 000 source files expect roughly 800 LLM calls. Content-hash caching means subsequent reruns for unchanged files are near-zero cost.

---

## Database

- **Location**: `DEMO_DB_PATH` (default: `explanability_demo/backend/knowledge.db`).
- **Engine**: SQLite in WAL mode — concurrent reads do not block writes.
- **Schema**: Applied idempotently on every startup via `init_schema()` — safe to restart without manual migration steps.
- **Backup**: WAL mode makes a simple file copy safe while the server is idle. For a live copy, use:

  ```bash
  sqlite3 explanability_demo/backend/knowledge.db ".backup backup.db"
  ```

- **Reset**: Delete `knowledge.db`; it will be recreated empty on next startup.

---

## Scaling Notes

- `DEMO_MAX_CONCURRENT_LLM_CALLS` (default `16`) controls the in-process asyncio semaphore for parallel Gemini calls. Reduce if you hit Gemini RPM quota errors; increase if your quota allows.
- The demo is designed for a **single-user, single-process** model. There is no task queue — builds run in-process as a background asyncio task.
- At 3 000 source files, a cold build takes ~800 LLM calls. Warm reruns (content-hash hit) consume no LLM quota.
- The backend is stateless except for `knowledge.db`. Scale out (multiple instances) is not supported with SQLite; see Production Considerations below.

---

## Production Considerations

| Topic | Default behaviour | What to change for prod |
|---|---|---|
| CORS | Locked to localhost origins | Set `DEMO_CORS_ORIGINS` to your actual frontend origin(s) |
| Auth | No auth layer | Add an API-key or OAuth middleware in `app.py` before go-live |
| SQLite concurrency | Single-writer (fine for demo single-user) | Swap `db.py` for a PostgreSQL backend if multiple simultaneous builds are needed |
| TLS | Plain HTTP | Terminate TLS at a reverse proxy (nginx/caddy) in front of uvicorn |
| Process manager | `--reload` dev flag | Remove `--reload`; use `gunicorn -k uvicorn.workers.UvicornWorker` or a systemd unit |
| Gemini API key | In `.env` on disk | Move to a secret manager (AWS Secrets Manager, GCP Secret Manager, etc.) |
