"""Phase 7 SSE helper utilities.

Pure string formatters — no DB, no LLM, no side-effects.
Import and use in any route that needs Server-Sent Events framing.

Usage::

    from process_analysis.backend.sse import sse_event, sse_keepalive

    yield sse_event({"variable": "WB1SW6", "direction": "backward"}, event="start")
    yield sse_keepalive()
"""

from __future__ import annotations

import json
from typing import Any, Dict


def sse_event(data: Dict[str, Any], event: str = "message") -> str:
    """Format a single SSE event string.

    Produces the wire format::

        event: <event>
        data: <json>

    (double newline at end to flush the event to the client)

    Args:
        data: Payload to JSON-encode.
        event: SSE event type label (default ``"message"``).

    Returns:
        A string ready to ``yield`` from a ``StreamingResponse`` generator.
    """
    return f"event: {event}\ndata: {json.dumps(data, default=str)}\n\n"


def sse_keepalive() -> str:
    """Return an SSE keepalive comment line.

    SSE comment lines (lines starting with ``:``) are ignored by the client
    but keep the HTTP connection alive through proxies and load balancers.

    Returns:
        ``": keepalive\\n\\n"``
    """
    return ": keepalive\n\n"
