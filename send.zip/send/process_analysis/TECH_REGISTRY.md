# Tech & Tools Registry — explanability_demo

Single source of truth for **every** technology, library, model, framework,
algorithm, or external service used inside `explanability_demo/`. Updated
the moment something is adopted; nothing ships without an entry here.

Per PROJECT_RULES Rule 2, every entry must be either:
- a Python stdlib component, OR
- something already in the repo's `venv`, OR
- a user-approved addition (with the decision id and date).

Last updated: 2026-05-28

---

## Approval index

| Decision id | Date | Topic | Outcome |
|---|---|---|---|
| Rule 1 | 2026-05-27 | Single LLM entry | Only `llm/caller.py::call_llm` via `backend/llm.py` wrappers |
| Q1 | 2026-05-27 | Frontend stack | React + Vite + Tailwind + shadcn/ui |
| Q2 | 2026-05-27 | Build coverage | On-demand per process |
| Q3 (Rule 1) | 2026-05-27 | LLM access | Gemini 2.5 Pro only via `call_llm` |
| Q4 | 2026-05-27 | Chat memory | Session-local (no auth) |
| Q5 | 2026-05-27 | Files view layout | 50/50 graph + list, cross-highlight |
| Q6 | 2026-05-27 | Forward output | Partitioned (one file per dep_var) |
| Token budget | 2026-05-27 | LLM_MAX_TOKENS | 2048 → 8192 in `.env` |
| Q-P4a | 2026-05-27 | Structured output | `call_llm_json` + Pydantic models (no new dep) |
| Q-P4b | 2026-05-27 | Variable purpose extraction | Single-shot per variable + ThreadPoolExecutor(8) |
| Q-P4d | 2026-05-27 | V4 live validation | Lint + LLM-as-judge on 50-sample |
| Q-S1 | 2026-05-27 | Build parallelism | Levelized DAG parallelism, ThreadPoolExecutor cap 16 |
| Q-S2 | 2026-05-27 | QA capability | Adaptive RAG with agentic ReAct fallback |
| Q-S2-impl | 2026-05-27 | Phase 8.0 adaptive-RAG agent | 6-tool ReAct loop via call_llm_model + SSE endpoint. No new external deps. |
| Q-S3 | 2026-05-27 | Retrieval index | sqlite-fts5 BM25 with p95<500ms gate |
| Q-S4 | 2026-05-27 | Graph scale | React Flow virtualization + ELK Worker + cluster-by-file |
| Q-P5a1 | 2026-05-27 | Routing | TanStack Router |
| Q-P5a2 | 2026-05-27 | API client | @hey-api/openapi-ts (codegen) + @hey-api/client-fetch |
| Q-P5a3 | 2026-05-27 | Test stack | Vitest now, Playwright in 5b |
| Q-P6a | 2026-05-27 | forward_traversal strategy | Wrap existing forward_trace_lineage.py |
| Q-P6b | 2026-05-27 | forward_traversal output shape | Partitioned (one file per dep_var trace) |
| Q-P6c | 2026-05-27 | V_FWD live validation gate | Rule-6 line refs + parser-vs-forward setter symmetry |
| Q-P6d | 2026-05-27 | Backward→forward gap closure order | Track A → B → C sequentially |
| Q-P6e | 2026-05-27 | Baseline before gap closures | Yes — discharge V_FWD before any new code |
| **Q-E1** | **2026-05-28** | **Embedding + semantic retrieval** | **SQLite + pgvector Python adapter (SQLite mode); `text-embedding-004` (768-dim) via `google.genai`; single `call_embedding` entry point (Rule 1-E); BLOB embedding columns + `cosine_distance` function; RRF(k=60) hybrid fusion (FTS5 BM25 + pgvector cosine) — see §11.5 of PROCESS_ANALYSIS_DESIGN.md** |
| **Q-C1** | **2026-05-28** | **Chat session memory** | **`chat_session` SQLite table + `backend/chat/session.py`; UUID session_id (client-generated, no auth); last-10-turns window loaded per request; no new external dep** |
| **Q-C2** | **2026-05-28** | **Chat agent architecture upgrade** | **Tier 1: native Gemini function calling (`tools=` param) + 16-tool catalogue + reiteration + critic. Tier 2: query router (direct/search/agent) + session memory (Q-C1) + Gemini context caching. Tier 3: IRCoT + dynamic alpha. No new external deps for Tier 1/2. New modules: `backend/chat/router.py`, `backend/chat/session.py`, `backend/chat/cache.py`, `backend/chat/agent.py` (updated).** |
| **Q-C3** | **PENDING** | **Cross-encoder reranking** | **Replace LLM rerank step with `BAAI/bge-reranker-v2-m3` via `sentence-transformers`. More accurate, burns zero LLM tokens. Trade-off: ~500 MB model, `sentence-transformers` dep. LLM rerank stays as fallback until approved.** |

When a future decision lands, ADD its row above AND any tech rows below.

---

## Backend — Python

### Runtime / language

| Item | Version | Source | Why | Approval | Used in |
|---|---|---|---|---|---|
| Python | 3.10.18 | `env/bin/python` | Pre-existing repo venv | Pre-approved (existing) | All backend code |

### Core stdlib (no approval needed — Rule 2)

| Module | Used for | Used in |
|---|---|---|
| `json` | JSON parse / dump | every backend file that handles SQLite JSON fields or LLM I/O |
| `sqlite3` | SQLite client | `backend/db.py` |
| `hashlib` | Content-hash (SHA-256, truncated 32 chars) for resumable builds | `backend/pipeline/runner.py::_content_hash` |
| `pathlib.Path` | File path manipulation | every script & module |
| `collections.defaultdict`, `deque` | Kahn's topo sort + levels | `backend/pipeline/topo.py` |
| `concurrent.futures.ThreadPoolExecutor`, `as_completed` | Levelized DAG parallelism (Q-S1) + variable inventory parallelism (Q-P4b) | `backend/pipeline/runner.py`, `backend/pipeline/variables.py` |
| `threading.Thread`, `threading.Lock`, `threading.Event` | Background build threads, in-memory active-build registry | `backend/routes/build.py`, `backend/routes/variables.py` |
| `dataclasses` | DTOs for enumeration + manifests | `backend/pipeline/{enumerate,variables}.py` |
| `re` | Regexes for source scanning (HLASM macros, `#include`, opcode lint) | `scripts/build_process_data.py`, `scripts/validate_parser_output.py`, `backend/pipeline/variables.py`, `scripts/validate_variable_purposes.py` |
| `contextlib.contextmanager` | Connection context manager | `backend/db.py` |
| `argparse` | CLI flags for scripts | every script in `scripts/` |
| `random` | Seeded sampling for validation | `scripts/validate_parser_output.py`, `scripts/validate_variable_purposes.py` |
| `time`, `datetime` | Timing, ISO timestamps | runner, routes |
| `logging` | Diagnostic logs | every module |

### Third-party libraries (pre-existing in venv — Rule 2 satisfied at adoption of base repo)

| Library | Version (approx) | Used for | Used in | Notes |
|---|---|---|---|---|
| **FastAPI** | latest in venv | HTTP server, route declaration, dependency injection | `backend/app.py`, `backend/routes/*` | Approved as part of P2 / Q1 frontend-backend split |
| **uvicorn** | latest in venv | ASGI server | `backend/README.md` instructions | |
| **Pydantic** (v2) | latest in venv | Request/response models AND LLM structured-output validation (Q-P4a) | `backend/schemas/*`, `backend/llm.py::call_llm_model` | Already a FastAPI transitive dep — no new external dep |
| **pydantic-settings** | latest in venv | `DemoSettings` reading `.env` | `backend/config.py` | Same |
| **starlette.testclient** + **pytest** | latest in venv | Test fixtures | `backend/tests/*` | |
| **google.genai** (via `llm/caller.py`) | latest in venv | Gemini API client | **NOT imported directly inside `explanability_demo/`** — wrapped by `llm/caller.py`. Enforced by `test_no_direct_llm_sdk_imports_in_explanability_demo`. | Rule 1 |

### Project-internal Python (imported, not modified)

| Import | Why | Used in |
|---|---|---|
| `llm.caller.call_llm` | The ONE LLM entry point (Rule 1) | `backend/llm.py` only |
| `google.genai.embed_content` (via `text-embedding-004`) | The ONE embedding entry point (Rule 1-E) — wrapped by `backend/embedding.py`; no other file calls `embed_content` directly | `backend/embedding.py` only |
| `llm.business_name.generate_business_name` | File business name generation — takes `business_summary`, returns 2–5 word plain-English name; has own `business_names.json` cache; called in Phase 2 per file | `backend/naming.py` only |
| `backend/naming.py::generate_block_business_name` | **New module (explanability_demo).** Block business name generation — takes block summary, calls `call_llm_model` (Rule 1), returns 2–5 word name; cached via `entity_business_name.content_hash` | `backend/pipeline/runner.py` Phase 2 pass |
| `backward_traversal.runner.backward_only_runner` | Backward lineage tool | Planned for P6/P7 (will be called from agentic-RAG tool catalog) |
| (planned) `forward_traversal.*` | New package, Phase 6 | TBD |

---

## Database & retrieval

### SQLite (existing demo — kept as-is)

| Item | Version | Source | Why | Approval | Used in |
|---|---|---|---|---|---|
| SQLite (stdlib + system) | 3.x with FTS5 | Python's `sqlite3` module + system SQLite | Current live demo knowledge store. FTS5 for BM25 retrieval. | Q-S3 | `backend/db.py`, `backend/schema.sql` |
| `chunk_fts` (FTS5 virtual table) | tokenize=`porter unicode61` | DDL in `schema.sql` | Lexical retrieval for adaptive-RAG simple path + agent tool `search_chunks` | Q-S3 | Current demo (live) |
| WAL journal mode + `synchronous=NORMAL` | — | PRAGMA in `db.py::_connect` | Better concurrent-read performance during builds | (configuration default) | All SQLite connections |

### pgvector Python adapter — SQLite mode (Q-E1)

| Item | Version | Source | Why | Approval | Used in |
|---|---|---|---|---|---|
| **pgvector** (Python, SQLite mode) | latest | `pip install pgvector` | Registers `cosine_distance(v1, v2)` / `l2_distance` as custom SQLite functions + BLOB float32 adapters; no external server; called via `pgvector.sqlite.register_vector(conn)` | Q-E1 | `backend/db.py` (adapter registration), `backend/schema.sql` (BLOB columns) |
| `chunk_embedding` table | — | DDL in PROCESS_ANALYSIS_DESIGN.md §11.5 | One row per chunk; `embedding BLOB` column for ANN; BM25 still via existing `chunk_fts` FTS5 | Q-E1 | Phase 2 build + `search_chunks` tool |
| `variable_context_embedding` table | — | §11.5 | `embedding BLOB`; few-shot retrieval for Phase 4 variable classification | Q-E1 | Phase 4 |
| `block_embedding` table | — | §11.5 | `embedding BLOB`; few-shot retrieval for utility detection L3.5 | Q-E1 | §4.1.2 L3.5 |
| **Hybrid search pipeline** | — | §11.5 | FTS5 BM25 MATCH + pgvector `cosine_distance(embedding, ?)` ORDER BY ASC → RRF(k=60) → LLM rerank; BM25-only fallback when `embedding IS NULL` | Q-E1 | `backend/retrieval/search.py` (updated) |

---

## Project-internal imports (Phase 6)

| Import | From | Used in | Approval |
|---|---|---|---|
| `forward_trace_lineage.ForwardLineageTracer` | repo root | `forward_traversal/runner.py` | Q-P6a (wrap strategy) |
| `backward_traversal.utils.subroutine_resolution.{extract_subroutine_target, resolve_subroutine_target}` | backward_traversal | `forward_traversal/expand.py` | Q-P6d Track A — G8 read-only import; 4-level fallback (exact subroutine → normalized → exact block → normalized block) |
| `backward_traversal.glossary.instructions.{SETTER_INST, TRIGGER_INST, BRANCH_INST, SUBROUTINE_CALL_OPCODES, RETURN_OPCODES, CROSS_FILE_INST, REGISTER_INDIRECT_MOVE_INST}` | backward_traversal | `forward_traversal/expand.py::classify_instructions` | Q-P6d Track A — G13 read-only import; ~140 instruction tokens incl. 64-bit z/Architecture variants |
| `backward_traversal.utils.cpp_lineage_utils.{find_cpp_seed_nodes, extract_asm_field_aliases, extract_tpf_regs_slots}` | backward_traversal | `forward_traversal/cpp_forward_tracer.py` | Q-P6d Track B — G1 seed discovery + G5 ASM-field aliases. Audit confirmed all three are direction-agnostic. |
| `temp/output_latest/asm_variable_universe.json` (read-only; entry count is dataset-specific, e.g. 2,794 at C400 scale, incl. EQU labels) | parser output | `forward_traversal/runner.py::_parser_universe_index()` | EF-1 fallback for G10 BFS — Phase-4 inventory is too narrow (kind=='memory' only) for dep_var declaration lookup |

## Algorithms (mechanism choices that need a record)

| Algorithm | Use case | Why this | Approval | Used in |
|---|---|---|---|---|
| **Kahn's topological sort** (sinks-first) | Order block / file summarization callees-before-callers | Stdlib-implementable, deterministic cycle handling | (default) | `backend/pipeline/topo.py::topo_sort` |
| **Kahn's with level grouping** (levelized DAG) | Parallel batches for block summarization | Standard pattern for compound LLM workflows; cited in arxiv 2504.03444 (LLMSched) | Q-S1 | `backend/pipeline/topo.py::topo_levels` |
| **Content-hash resumability** (SHA-256 over source + prompt + template_version) | Skip cached blocks/files on re-run | Simple, deterministic, no external state | (default) | `backend/pipeline/runner.py::_content_hash` |
| **Parse-or-retry + Pydantic validation** | Structured LLM output enforcement | No new external dep; same retry-on-shape-error UX as Instructor | Q-P4a | `backend/llm.py::{call_llm_json, call_llm_model}` |
| **Source-scan over parser blueprint** | `headers.json`, `macros.json`, all variable validations | Parser fields `macro_expansions`, `file_dependencies` are empty in this corpus — distrusted per Rule 6 | (default) | `scripts/build_process_data.py`, `scripts/validate_parser_output.py` |
| **Single-shot per-variable prompt** | Variable purpose extraction | Validated 47/50 (94%) judge-pass at C400 scale; arxiv 2411.14971 supports line-wise prompting for legacy ASM | Q-P4b | `backend/pipeline/variables.py` |
| **Adaptive RAG: classifier → simple / single-tool / agentic ReAct** | "Answer anything" QA capability | Adopted 2026 SOTA; routes by complexity; agent tools are deterministic graph + lineage queries | Q-S2 | Phase 8 (planned) |
| **Query routing (direct / search / agent)** | Classify incoming chat question before any tool call; cheap queries bypass agent loop | Eliminates 2–5 agent turns for direct lookup questions; p50 latency ×3 improvement on simple queries | Q-C2 | `backend/chat/router.py` |
| **Native Gemini function calling** | Replace hand-rolled JSON dispatch in agent loop with `response.function_calls` from `google.genai` SDK | More robust than string-matching; SDK handles malformed JSON; enables parallel tool calls in one generation | Q-C2 | `backend/chat/agent.py` |
| **Reiteration + critic pass** | Guard rails for long ReAct chains: re-state original question each Thought; validate final answer vs. retrieved facts | Prevents mid-chain drift (reiteration) and hallucinated answers (critic); zero new deps | Q-C2 | `backend/chat/agent.py` |
| **IRCoT (interleaved retrieval)** | search_chunks called between Thought steps, not only at start | Enables multi-hop traces (e.g., variable → call path → persistence site) in a single agent turn | Q-C2 | `backend/chat/agent.py` |
| **Dynamic retrieval alpha** | BM25 / ANN weight adjusted per query type (0.7/0.3 for exact-identifier, 0.3/0.7 for semantic, 0.5/0.5 mixed) | Exact ASM variable/macro names benefit from BM25 precision; semantic questions benefit from dense | Q-C2 | `backend/retrieval/search.py` (alpha param) |
| **Gemini context caching** | Process KB (block summaries + variable context) uploaded once per process/day as Gemini cached content; subsequent turns reference cache_id | ~4× cheaper cached-token cost vs. full prompt; enables 500k-token KB without per-turn cost | Q-C2 | `backend/chat/cache.py` |
| **Levelized parallelism with per-level dict snapshot** | Avoid in-level races on `block_purpose_by_path` during parallel block summarization | Discovered empirically when cycle-remainder blocks co-resided in the synthetic final level and produced non-deterministic content_hashes | Q-S1 implementation detail | `backend/pipeline/runner.py::build_process` |
| **Reciprocal Rank Fusion (RRF, k=60)** | Hybrid retrieval — fuse BM25 rank and ANN rank without score normalisation: `score = 1/(60+rank_bm25) + 1/(60+rank_ann)` | Stateless, no hyperparameter tuning required; standard fusion baseline; previously dropped when embeddings were unavailable — **reinstated Q-E1** | Q-E1 | `backend/retrieval/search.py` |
| **Flat ANN (pgvector / SQLite)** | `cosine_distance(embedding, query_vec)` registered by `pgvector.sqlite`; `ORDER BY cosine_distance ASC LIMIT 50` with `WHERE process = ?` pre-filter | Brute-force scan over process-local rows; no periodic rebuild needed; <2k rows per process → < 20 ms in-process | Q-E1 | `backend/retrieval/search.py` + BLOB columns in §11.5 |

---

## Frontend — Phase 5a installed

| Item | Version | Why | Approval | Used in |
|---|---|---|---|---|
| React + react-dom | 19.2.x | Q1 chosen stack (Vite default upgraded 18 → 19) | Q1 | `frontend/src/**` |
| Vite | 8.x | Q1 chosen build tool | Q1 | `frontend/vite.config.ts` |
| TypeScript | 6.0.x | Type-safety | Q1 | All `frontend/src/**.{ts,tsx}` |
| Tailwind CSS + @tailwindcss/vite | 4.x | Styling + OKLCH tokens via v4 `@theme inline` | Q1 | `frontend/src/index.css`, vite plugin |
| shadcn/ui — **hand-written** | n/a | Per shadcn ownership model: source lives in our repo. Phase 5a hand-rolls Button/Card/Badge/Skeleton/Input. `npx shadcn@latest init` for the rest in 5b. | Q1 | `frontend/src/components/ui/*` |
| @tanstack/react-router + router-plugin + router-devtools | 1.170 / 1.168 / 1.167 | Routing — first-class type-safety for SPA params/search | Q-P5a1 | `frontend/src/routes/*`, `vite.config.ts` |
| @tanstack/react-query + react-query-devtools | 5.100 | Server-state cache | Q1 | `frontend/src/main.tsx`, all route components |
| @hey-api/client-fetch | 0.13 | Reserved for 5b codegen (not yet wired) | Q-P5a2 | (deferred) |
| @hey-api/openapi-ts | 0.97 (dev) | OpenAPI → TypeScript codegen in 5b | Q-P5a2 | (deferred) |
| class-variance-authority + clsx + tailwind-merge | latest | shadcn variant patterns + `cn()` | Q1 | `frontend/src/components/**`, `frontend/src/lib/utils.ts` |
| lucide-react | 1.16 | Icons | Q1 | `frontend/src/routes/index.tsx` |
| @fontsource-variable/inter + @fontsource-variable/jetbrains-mono | 5.2.x | Variable-weight Inter & JetBrains Mono for body + mono text | Q1 | `frontend/src/main.tsx` (or index.css import) |
| @fontsource/inter + @fontsource/jetbrains-mono | 5.2.x | Static-weight fallback variants | Q1 | `frontend/src/main.tsx` |
| sonner | 2.0.x | Toast notifications | Q1 | `frontend/src/**` |
| Vitest + @testing-library/react + jsdom + jest-dom | 4 + 16 + 29 | Unit tests (Q-P5a3) | Q-P5a3 | `frontend/src/test/*`, `vite.config.ts::test` |

## Frontend — Phase 5b (partial install)

| Item | Version | Why | Approval | Status |
|---|---|---|---|---|
| **@xyflow/react** | 12.x | File graph (V3); block graph (V4 — 5b finish) | Q1 + Q-S4 | ✅ Installed, used in `frontend/src/components/blocks/Graph.tsx` |
| **elkjs** | latest | Async layered layout via `elk.bundled.js`; runs on main thread for ≤100 nodes (Web Worker variant wired for larger graphs in 5b/V4) | Q-S4 | ✅ Installed, used in `frontend/src/components/blocks/Graph.tsx` |

## Frontend — Phase 5c

| Item | Version | Why | Approval | Status |
|---|---|---|---|---|
| Native `fetch` + `ReadableStream` + `TextDecoder` SSE parser | n/a (browser API) | POST-with-SSE for the chat endpoint (browser EventSource is GET-only). ~40 LOC in `ChatStream.tsx`. No new dep. | Q1 (stack approved) | ✅ Live (see V8.0e in VALIDATION_TRACKER) |
| **motion** (`motion/react`) | 12.x | `AnimatePresence` + `motion.div` for enter/exit transitions on the investigation streaming page | Q1 | ✅ Installed, used in `frontend/src/routes/p.$P.v.$V.investigation.$direction.tsx` |

## Frontend — Phase 5b/5c planned

| Item | Why | Approval | Status |
|---|---|---|---|
| react-markdown + remark-gfm | Chat / explanation rendering (5c) | Q1 | Not yet installed |
| ~~EventSource (browser native)~~ | ~~SSE for streamed explanations (5c)~~ | Q1 | **Not adopted** — EventSource is GET-only; superseded by native `fetch` + `ReadableStream` SSE parser in Phase 5c |
| Playwright (`@playwright/test`) | 1.60.x (devDep) | E2E for graph interaction + SSE streams | Q-P5a3 | ✅ Installed — tests not yet written |
| **NO** other graph libs, **NO** state-management libraries beyond TanStack Query | — | Q1 / Q-S4 | — |

---

## External services / models

| Item | Version | Why | Approval | Used in |
|---|---|---|---|---|
| **Gemini 2.5 Pro** (via `settings.LLM_MODEL_NAME`) | API version of 2026-05 | Single approved LLM for text generation | Rule 1 | `llm/caller.py` (and only there) |
| **Google `text-embedding-004`** (via `google.genai`) | stable, 768-dim | Single approved embedding model (Rule 1-E); same SDK already in venv; 768-dim matches pgvector BLOB (768 × 4 bytes per vector) | Q-E1 | `backend/embedding.py` (new, single entry point — Rule 1-E) |
| `.env::LLM_MAX_TOKENS` | 8192 | Long-block summaries don't truncate | "Token budget" approval | `.env` (shared) |
| `.env::EMBEDDING_BATCH_SIZE` | 250 | Max texts per `text-embedding-004` API call | Q-E1 | `backend/embedding.py` |
| **NO** Cohere/Voyage/OpenAI/Anthropic | — | Rule 1 | — | — |
| **NO** external vector DBs (Qdrant, LanceDB, Pinecone, …) | — | pgvector Python adapter in SQLite is in-process — no external server needed | Q-E1 | — |

---

## How to update this registry

1. **About to adopt something new?** → Run the Rule 2 research round.
   Present 2-4 alternatives via `AskUserQuestion`. Wait for explicit
   approval.
2. **Approved?** → Add a row to the **Approval index** (top of this file)
   AND a row to the relevant section below.
3. **About to use a stdlib module not already listed?** → Just add a row to
   "Core stdlib" — no approval needed.
4. **Removed something?** → Don't delete its row; mark it removed with a
   date and reason. The history matters.
