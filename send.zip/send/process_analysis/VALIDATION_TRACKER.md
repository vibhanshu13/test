# Validation Tracker — explanability_demo

Every checkpoint where we verify reality matches the design. Build trust by checking, not by asserting.
Status legend: ✅ Passed · ⚠️ Partial · ❌ Failed · ⏳ Pending · ♻️ Re-run needed

Updated: 2026-05-27

---

## Dashboard

| Layer | Total | ✅ | ⚠️ | ❌ | ⏳ |
|---|---|---|---|---|---|
| P0 data | 4 | 4 | 0 | 0 | 0 |
| P1 design assumptions | 6 | 6 | 0 | 0 | 0 |
| P2 backend skeleton | 7 | 7 | 0 | 0 | 0 |
| P3 knowledge extraction | 8 | 7 | 1 | 0 | 0 |
| P3-b scale retrofit (Q-S1) | 3 | 3 | 0 | 0 | 0 |
| P4 variable inventory | 5 | 5 | 0 | 0 | 0 |
| P5 frontend | 6 | 4 | 0 | 0 | 2 |
| P6 forward_traversal | 11 | 11 | 0 | 0 | 0 |
| P7 chunked SSE | 4 | 3 | 0 | 0 | 1 |
| P8 retrieval/QA | 8 | 7 | 0 | 0 | 1 |
| P9 polish | 4 | 3 | 0 | 0 | 1 |
| P9 end-to-end | 3 | 0 | 0 | 0 | 3 |
| P10 Celery/Redis infra | 5 | 4 | 0 | 0 | 1 |
| P11 Phase 1 static | 12 | 0 | 0 | 0 | 12 |
| P12 Phase 3 walk | 8 | 0 | 0 | 0 | 8 |
| P13 Phase 4 variable context | 7 | 0 | 0 | 0 | 7 |
| P14 Phase 5 synthesis | 8 | 0 | 0 | 0 | 8 |
| P14.5 Phase 2 updates | 4 | 0 | 0 | 0 | 4 |
| P15 §12 API stubs | 4 | 1 | 0 | 0 | 3 |
| P16 chat upgrade | 6 | 0 | 0 | 0 | 6 |
| P17 hybrid search | 4 | 0 | 0 | 0 | 4 |
| P18 schema tables | 5 | 0 | 0 | 0 | 5 |
| P19 frontend Stage B | 7 | 0 | 0 | 0 | 7 |
| P20 ASM resolver | 4 | 0 | 0 | 0 | 4 |

---

## P0 — Data fix validations ✅

| V0.1 | DFS from `lu82.asm` reproduces `lu82 → dx750000 → dx710000 → dx730000 → dx740200 → ...` chain | manual + scripted DFS | ✅ Passed | 2026-05-27 | Output matches user-specified chain exactly |
|---|---|---|---|---|---|
| V0.2 | `file_graph.json` shape: 16 files, 20 edges, edge_types breakdown is `cpp_to_cpp:6, cpp_to_asm:1, asm_to_asm:9, asm_to_cpp:4` | `scripts/build_process_data.py --dry-run` | ✅ Passed | 2026-05-27 | |
| V0.3 | `lu82.asm` confirmed to use 0 of 9 known `.mac` names | `grep -ciE …` independently | ✅ Passed | 2026-05-27 | Confirms macro scanner correctness |
| V0.4 | Parser fields `macro_expansions` + `file_dependencies` confirmed empty/null in blueprints — distrusted | manual JSON inspection of 2 blueprints | ✅ Passed | 2026-05-27 | Drives the "source-scan only" choice |

---

## P1 — Design assumption validations ✅

| V1.1 | `llm/caller.py::call_llm(prompt, system_prompt=None) -> str` exists and uses Gemini 2.5 Pro via `settings.LLM_MODEL_NAME` | `Read` of `llm/caller.py` | ✅ Passed | 2026-05-27 | Source of truth for the single-LLM rule |
|---|---|---|---|---|---|
| V1.2 | `process/process_truncated_file_graph.json` regenerates successfully and contains C400 | pipeline run | ✅ Passed | 2026-05-27 | 190 processes total, 24 with edges, C400 = 16 nodes / 17 edges |
| V1.3 | `backward_traversal.runner.backward_only_runner.run_backward_only(...)` is importable from Python (not CLI-only) | source inspection | ✅ Passed | 2026-05-27 | Signature verified |
| V1.4 | Backward output JSON schema (`files`, `dep_var_traces`, `full_file_flow`) — line-anchored evidence present | sample output structure | ✅ Passed | 2026-05-27 | Drives the SSE iteration design |
| V1.5 | Existing `api/routes/processes.py` already serves `GET /v1/jobs/{job_id}/processes` — we won't collide on `/demo/v1/...` | Explore agent audit | ✅ Passed | 2026-05-27 | Demo backend uses a different prefix |
| V1.6 | ASM variable universe: 2,726 entries, 57% macro-noise; C++ universe: 346 entries clean | universe JSON count | ✅ Passed | 2026-05-27 | T1 filter strategy justified |

---

## P2 — Backend skeleton validations ✅

| V2.1 | Backend imports succeed from a clean venv | `pytest` import path | ✅ Passed | 2026-05-27 | 11/11 tests collected |
|---|---|---|---|---|---|
| V2.2 | `call_llm_json` parses valid JSON output, strips fences, recovers balanced blocks | `test_llm_wrapper.py` (3 tests) | ✅ Passed | 2026-05-27 | |
| V2.3 | `call_llm_json` retries on parse failure and raises `LLMJSONError` after exhaustion | `test_llm_wrapper.py` (2 tests) | ✅ Passed | 2026-05-27 | |
| V2.4 | SQLite schema initializes; FTS5 available; tables queryable | live `/health` returns `fts5: true`; routes query `process` table | ✅ Passed | 2026-05-27 | |
| V2.5 | `GET /demo/v1/processes` lists C400 with file_count=16, edge_count=20, has_real_graph=true | live `curl` | ✅ Passed | 2026-05-27 | total=1 (only C400 dir exists with real data) |
| V2.6 | `GET /demo/v1/processes/C400` returns full detail (seed_file=`temp/asm/lu82.asm`, seed_segment=DX75, all 16 files) | live `curl` | ✅ Passed | 2026-05-27 | |
| V2.7 | No direct LLM SDK imports inside `explanability_demo/` | `test_no_direct_llm_sdk_imports_in_explanability_demo` | ✅ Passed | 2026-05-27 | Re-run on every phase per rule |

---

## V_PARSER_* — Parser-blueprint vs source validation (Rule 6) ✅

Required by [PROJECT_RULES.md Rule 6](./PROJECT_RULES.md). Re-run via
`env/bin/python explanability_demo/scripts/validate_parser_output.py --process <P>`
whenever the parser corpus is regenerated, a new field is consumed, or
process scope expands. Output: `explanability_demo/docs/parser_validation_<P>.json`.

| Id | What it validates | Method | Status | Date | Notes |
|---|---|---|---|---|---|
| V_PARSER.C400.PA1 | ASM: every REAL (non-synthetic) `block.id` appears in source at/near `block.start_line` | script `validate_parser_output.py` over 16 files, 10 samples each | ✅ Passed | 2026-05-27 | 0/10 mismatches across non-synthetic blocks |
| V_PARSER.C400.PA1b | ASM: synthetic file-entry blocks (`id == file_stem.upper()`) start on a non-blank, non-comment line | same | ✅ Passed | 2026-05-27 | Documented parser convention — synthetic ids for the first executable section (e.g. `LU82` block at lu82.asm:122). Source slice remains valid for LLM consumption. |
| V_PARSER.C400.PA2 | ASM: `start_line <= end_line` and within source bounds for every block | same | ✅ Passed | 2026-05-27 | |
| V_PARSER.C400.PA3 | ASM: every `subroutines[].id` exists in `blocks[]` | same | ✅ Passed | 2026-05-27 | |
| V_PARSER.C400.PA4 | ASM: random `call_graph.edges` — source at `edge.line` contains instruction AND target id | same, 10 samples per file | ✅ Passed | 2026-05-27 | |
| V_PARSER.C400.PC1 | C++: `symbols.global_symbols[type=entry]` function name appears at `provenance.original_line` | same | ✅ Passed | 2026-05-27 | |
| V_PARSER.C400.PC2 | C++: derived `end_line = next_start − 1` doesn't overlap into next function | same | ✅ Passed | 2026-05-27 | |
| V_PARSER.C400.PC3 | C++: random `call_graph.edges` — source at `edge.line` mentions target | same, 10 samples per file | ✅ Passed | 2026-05-27 | |

Parser fields that are **untrusted and bypassed entirely** (Rule 6 fallback
mechanism = source-scan or skip):

| Field | Status | Replacement |
|---|---|---|
| `macro_expansions` | ❌ Empty/null in this corpus | Source-scan opcodes vs `.mac` basenames (`scripts/build_process_data.py`) |
| `file_dependencies` | ❌ Empty | Source-scan `#include` directives (same script) |
| `variable_identity_index::symbolic_identity` / `access_identity` | ❌ Empty | Phase 4 will not rely on cross-language mapping; filter ASM universe + use C++ as-is |

---

## P3 — Knowledge extraction validations ✅⚠️

| V3.1 | Topo-sort on intra-file CFG for `xh88.asm` and `dx740200.cpp` produces valid linear order | `test_enumerate_*`, `test_topo_sort_sinks_first` | ✅ Passed | 2026-05-27 | xh88 → 120 blocks, sub-IDs cross-checked; intra-file callees attached |
|---|---|---|---|---|---|
| V3.2 | Per-block prompt + `call_llm_json` returns parseable JSON matching schema on real Gemini run | `scripts/sanity_check_llm.py` on 1 ASM + 1 C++ block | ✅ Passed | 2026-05-27 | Validates ASM (DA78) and C++ (processAccountMaintenance, 275-line function). Both return complete, business-language-only structured JSON. |
| V3.3 | C400 full live build completes within budget | manifest after a real run | ✅ Passed | 2026-05-27 | First live build finished at 03:53:28Z (phase=done, 788/788 blocks, 16/16 files, process summary persisted). Re-run captured in `docs/v33_v3b3_validation.json` via `scripts/snapshot_v33.py`. |
| V3.4 | Pipeline is **resumable**: re-run is a no-op when nothing changed | `test_build_is_resumable_via_content_hash` | ✅ Passed | 2026-05-27 | Second run does 0 block + 0 file LLM calls; only process-level re-runs (no content_hash on process row) |
| V3.5 | `TEMPLATE_VERSION` bump invalidates every row | `test_build_invalidates_on_template_version_bump` | ✅ Passed | 2026-05-27 | |
| V3.6 | All C400 files have non-empty `purpose` + `narrative` after build | `test_build_c400_with_mocked_llm` | ✅ Passed | 2026-05-27 | With **mocked** LLM. Real-LLM re-check belongs with V3.3 full build. |
| V3.7 | Spot-check business-language only (no `BAS`, `BAL`, `MVC`, `LR`, `->`, `::`, `void*`, `0x`) in purpose/behavior | `test_stub_purposes_contain_no_asm_or_cpp_syntax` (lint) + manual review of sanity-check output | ✅ Passed | 2026-05-27 | Lint runs on every build; manual: ASM DA78 + C++ processAccountMaintenance outputs have zero forbidden tokens |
| V3.8 | `required_keys` shape validation reprompts on partial-object responses | observed in `scripts/sanity_check_llm.py` on first C++ run | ⚠️ Partial | 2026-05-27 | Validation logic works (Gemini returned only `calls` array, validator rejected). However ROOT CAUSE was `LLM_MAX_TOKENS=2048` truncation — bumped to 8192. Reprompt-on-shape-mismatch logic is sound. |

---

## P3-b — Scale retrofit validations (Q-S1) ✅

| V3b.1 | `topo_levels` groups independent nodes correctly + appends cycle remainder | unit tests | ✅ Passed | 2026-05-27 | 2 tests in test_pipeline.py |
|---|---|---|---|---|---|
| V3b.2 | Levelized parallel block pass produces identical results to sequential | full 31-test suite includes test_build_c400_with_mocked_llm, _resumable_via_content_hash, _invalidates_on_template_version_bump — all still pass with concurrency=16 | ✅ Passed | 2026-05-27 | Per-level dict snapshot was required to fix a race in the cycle-remainder level |
| V3b.3 | Live build for V3.3 will use the retrofitted runner | `scripts/snapshot_v33.py` no-op rerun | ✅ Passed | 2026-05-27 | Levelized block pass cached 787/788 (99.87%) — no race, no data loss. Manifest in `docs/v33_v3b3_validation.json`. File-pass + process-pass cache gap recorded as `FU-CACHE-FILE` / `FU-CACHE-PROCESS` follow-ups (perf, not correctness). |

## P4 — Variable inventory validations ✅

| V4.1 | ASM universe filter `is_runtime_symbol=True AND kind=="memory"` for C400 yields true DATA variables (no EQU code labels) | scripted count + live run | ✅ Passed | 2026-05-27 | 66 ASM occurrences (down from 831 with looser filter — see EF-1 in PROJECT_RULES) |
|---|---|---|---|---|---|
| V4.2 | C++ inventory matches parser count for C400 | scripted count | ✅ Passed | 2026-05-27 | 160 occurrences. Combined with ASM: 226 unique entries after dedupe by (name, file, line). |
| V4.3 | Each variable has a non-empty 1-sentence `purpose` after live build | SQL count + null check | ✅ Passed | 2026-05-27 | 226 rows, 0 with empty purpose, manifest `failures=0`. |
| V4.4 | Lint: zero forbidden-token hits (opcodes, registers, hex, ->, ::, void*) in `purpose` field on 50-row sample | `scripts/validate_variable_purposes.py` (live) | ✅ Passed | 2026-05-27 | 50/50 clean. Report: `docs/v4_validation_C400.json` |
| V4.5 | LLM-as-judge: each sampled purpose reads as a clear business-language sentence | live `call_llm_model(VariablePurposeJudgement)` on 50-sample | ✅ Passed | 2026-05-27 | 47/50 (94%) passed. 3 nuanced failures (undefined acronyms / implementation detail framing) recorded in report; not systemic. |

---

## P5 — Frontend validations (5a: V5.1, V5.2, V5.5; 5b: V5.3, V5.4; 5c: V5.6 E2E full sweep)

| V5.1 | Vite dev server starts on :5173 (IPv6 ::1) and `npm run build` succeeds (350 KB / 109 KB gz) | live | ✅ Passed | 2026-05-27 | `vite build` succeeds; `vitest run` 2/2 pass |
|---|---|---|---|---|---|
| V5.2 | Vite proxy forwards `/demo/v1/*` to backend; `/processes` returns C400 row with file_count=16, edge_count=20 via proxy | live curl through `http://localhost:5173/demo/v1/...` | ✅ Passed | 2026-05-27 | end-to-end with both processes alive |
| V5.3 | Process detail Overview shows seed file/segment, edge breakdown, headers + macros counts, files list | manual visual test (requires browser) | ⏳ | — | Route + components ship in 5a; visual smoke deferred to user-driven |
| V5.4 | Files view 50/50 split with cross-highlight (V3) | live curl + route HTML serve | ⚠️ Partial | 2026-05-27 | Backend `/file-graph` returns 16 files / 20 edges (17 unique pairs); `/p/C400/files` route serves. **Visual interaction (click-to-highlight)** needs browser smoke or Playwright (5b.7). |
| V5.5 | Variables list renders 226 rows paginated; search narrows; origin filter works; LLM-generated purposes visible | live + spot-check via proxy + route component | ✅ Passed | 2026-05-27 | `/variables?page=1&page_size=3` returns A7AFTERGLHIST etc. with real purposes |
| V5.6 | No console errors on any view (Playwright sweep) | DevTools / Playwright | ⏳ | — | Phase 5b/5c when Playwright is added |
| V5.7 (new) | Unit tests pass under Vitest | `vitest run` | ✅ Passed | 2026-05-27 | 2/2 (Button rendering + variant class) |

---

## P6 — forward_traversal validations

| V6.1 (V_FWD baseline) | 3 representative variables (WB1SW6, WB1SW1, A7AFTERGLHIST): parser setters 100% covered by forward; Rule-6 source gate passes; 0 out-of-scope leakage | `scripts/validate_forward_baseline.py` + live tracer | ✅ Passed | 2026-05-27 | Report: `docs/v_fwd_baseline.json`. WB1SW6: 2/2 setters covered, 137 blank-line warnings (CFG navigation anchored to whitespace). WB1SW1: 1/1 covered. A7AFTERGLHIST: 0/0 (constant). |
|---|---|---|---|---|---|
| V6.2 | Partitioned output: one file per dep_var | filesystem listing during smoke run | ✅ Passed | 2026-05-27 | `dep_vars/<NAME>.json` per name; `dep_var_traces/<NAME>.json` for G10 BFS expansions. |
| V6.3 | G10 dep-var BFS respects caps (max_dep_var_depth, max_dep_vars) | live trace with max_dep_var_depth=2, max_dep_vars=10 | ✅ Passed | 2026-05-27 | Capped at 10; out-of-scope dep_vars marked `skipped_no_declaration_in_scope`. |
| V6.4 | `/usage-flows` endpoint serves manifest + dep_var summaries | `scripts/validate_v6_v7.py` (live) | ✅ Passed | 2026-05-27 | ASM (WB1SW6, xh80.asm): 2499 nodes / 961 setters / 439 dep_vars in scope. C++ (bcis, dx740200.cpp): 300 GVL nodes / 33 cross-file calls. Manifest field-shape checked; report at `docs/v6_v7_validation.json`. |
| V6.5 | Track-A gaps closed without breaking V_FWD baseline | re-run validate_forward_baseline.py after each gap | ✅ Passed | 2026-05-27 | Re-baselined after G6/G8/G13 — still 100% parser-setter coverage, 0 out-of-scope across all 3 variables; `docs/v_fwd_baseline.json` unchanged. |
| V6.6 | G6 expansion correctness on real subroutine call (xh81 BAS R10, XH811A00) | unit test + live run | ✅ Passed | 2026-05-27 | `test_forward_expand.py`; resolver returns `exact_subroutine` confidence; body inserted with `expansion_depth=1` + `expansion_parent_block`. |
| V6.7 | G13 instruction classification coverage on real C400 trace | live trace | ✅ Passed | 2026-05-27 | 1925/2099 (92%) of WB1SW6 in-scope nodes classified. Untagged 8% are synthetic CFG markers without `inst` (FALLTHROUGH_ENTRY / BRANCH_ENTRY). |
| V6.8 (Track B) | G1 C++ forward GVL tracer cost-model audit | unit test against backward DEPTH_WEIGHTS spec | ✅ Passed | 2026-05-27 | `test_forward_cpp.py::test_depth_weights_match_backward_spec` |
| V6.9 (Track B) | G1 forward BFS stops at terminal kinds (literal/memory/clobbered) | unit test | ✅ Passed | 2026-05-27 | |
| V6.10 (Track B) | G1 live trace on 3 C400 C++ variables (`bcis`, `LwrPtr`, `casGlosInputMessage`) — seeds + nodes + bridge registers | live tracer | ✅ Passed | 2026-05-27 | bcis: 2 seeds, 50 nodes, 12 bridge_to_asm registers. LwrPtr: 1 seed, 50 nodes, 4 bridges. casGlosInputMessage: 2 seeds, 50 nodes, 0 bridges. |
| V6.11 (Track B) | Runner dispatches `.cpp` declaration to C++ tracer; manifest serializes correctly | unit test | ✅ Passed | 2026-05-27 | `test_runner_dispatches_cpp_for_cpp_declaration` |

---

## P7 — Chunked SSE investigation validations ✅ (backend) / ⏳ (V7.4 UI)

| V7.1 | SSE stream emits exactly N events (one per iteration) and a final `done` event | `scripts/validate_v6_v7.py` (live) | ✅ Passed | 2026-05-27 | A7AFTERGLHIST setter: plan=1 / messages=1 / done=1. WB1SW6 usage: plan=2 / messages=2 / done=1. Report `docs/v6_v7_validation.json`. |
|---|---|---|---|---|---|
| V7.2 | Each message references at least one source with `(file, line_range OR block_id)` | scripted check (same script) | ✅ Passed | 2026-05-27 | Every emitted `message` event in both runs cited ≥1 source with the (file, anchor) pair. The IterationMessage prompt explicitly admits either `line_range` or `block_id` as the anchor. |
| V7.3 | Messages are **connected**: each Mk references prior Mi by paraphrase / explicit anchor | scripted heuristic + manual spot check | ✅ Passed | 2026-05-27 | Heuristic admits 3 anchors: source-file overlap with priors, explicit variable-name mention, or paraphrase markers (Building on / Continuing / etc.). WB1SW6 iter#2 opened "Building on the initial setup…" → paraphrase anchor caught. |
| V7.4 | "Explain more" button only fires the next iteration (not re-streams) | UI test (Playwright) | ⏳ | — | Pure UI-side check; deferred with V5.6 / V9.1 to the Playwright round. Found + fixed adjacent backend bug: `InvestigationRequest` now accepts `declaration_file` so multi-declaration vars (e.g. WB1SW6) trace correctly. |

---

## P8 — Retrieval / QA validations

| V8.0 (NEW) | Agent ReAct loop: AgentStep validator enforces exactly-one-action; unknown tool → error observation; max_iterations cap fires | unit tests in `test_agent.py` | ✅ Passed | 2026-05-27 | 11/11 |
|---|---|---|---|---|---|
| V8.0b (NEW) | SSE endpoint streams `thought / tool_call / tool_result / answer / done` events in order | unit test with monkey-patched run_agent | ✅ Passed | 2026-05-27 | |
| V8.0c (NEW) | Live Gemini end-to-end: agent answers `"What does the variable bcis represent…"` correctly with 2 cited sources | live run captured in `backend/agent/README.md` | ✅ Passed | 2026-05-27 | Real C400 data via `get_variable_purpose`; clean business-language answer; no opcodes/syntax in body |
| V8.0d (NEW) | Forbidden-token lint on the agent's final_answer text | manual review of live run | ✅ Passed | 2026-05-27 | "BAS", "MVC", "->", "void*", hex, registers — all absent |
| V8.0e (NEW) | End-to-end live chain: frontend → Vite proxy → backend SSE → Gemini → back through proxy | live `curl -X POST http://localhost:5173/demo/v1/processes/C400/chat` | ✅ Passed | 2026-05-27 | 5 SSE frames returned (thought / tool_call / tool_result / answer / done). Answer for casGlosOutputMessage cites dx730000.cpp::maintenancePipeline:46 and dx740200.cpp::globalLimitsUpdate:83. |
| V8.1 | BM25 index has one row per (block + variable) with non-empty purpose | live count after rebuild_chunk_index_for_process | ✅ Passed | 2026-05-27 | C400: 935 chunks (709 blocks + 226 variables); file/process chunks pending V3.3 finish |
| V8.2 | Top-K retrieval for "credit limit maintenance message" surfaces relevant variable chunks | live curl + `search_chunks_bm25` | ✅ Passed | 2026-05-27 | Top-5 hits include `msgLength1`, `casGlosOutputMessage`, `casGlosInputMessage`, `registers` — all on-topic |
| V8.3 | Phase 8.1 `search_chunks` tool registered in agent catalog | inspection of `tools.CATALOG` | ✅ Passed | 2026-05-27 | |
| V8.4 | End-to-end backend smoke: every public endpoint passes | `scripts/e2e_smoke.sh` | ✅ Passed | 2026-05-27 | 12/12 — Phase 2/4/5b.5/6/8 surfaces |
| V8.5 | Process-level chat keeps citations valid across 5 turns | live manual | ⏳ | — | Requires user driving the chat in browser; defer to user smoke during app run |

---

## P9 — End-to-end validations ⏳

| V9.1 | Full happy path: open process → see summary → drill to file → drill to variable → run setter investigation → ask 3 follow-ups | scripted Playwright run | ⏳ | — | |
|---|---|---|---|---|---|
| V9.2 | Re-run build for C400 with no template change: 0 LLM calls (full cache hit) | log inspection | ⏳ | — | |
| V9.3 | Build for `plastic_authentication` completes without code change (portability) | live run | ⏳ | — | |

---

---

## P10 — Celery / Redis infrastructure validations

| Id | What it validates | Method | Status | Date | Notes |
|---|---|---|---|---|---|
| V10.1 | `celery_app.py` task_routes covers every task name; 3 queues declared | static import + inspect task_routes dict | ✅ Passed | 2026-05-28 | All 8 tasks routed; q_emit/q_io/q_llm confirmed |
| V10.2 | `get_redis()` returns a connected client; pool cap respected | unit test with mock pool | ✅ Passed | 2026-05-28 | Connection pool capped at REDIS_MAX_CONNECTIONS |
| V10.3 | `call_embedding([…])` returns list of 768-dim vectors; Rule 1-E enforced (no other embedding calls) | unit test (mocked google.generativeai); grep for embed_content outside embedding.py | ✅ Passed | 2026-05-28 | text-embedding-004 |
| V10.4 | `translate_macro("DBWRT")` returns "writes a record to"; safe filler returned for unknown token (never raw code) | unit test | ✅ Passed | 2026-05-28 | |
| V10.5 | Live: `POST /build` returns 202 with `task_id` field; threading fallback fires when Celery unavailable; `GET /build/status/{task_id}` returns `{status:"not_found"}` when Redis down | live curl against running backend | ⏳ | — | Requires running backend |

---

## P11 — Phase 1 static analysis validations ⏳

| Id | What it validates | Method | Status | Date | Notes |
|---|---|---|---|---|---|
| V11.1 | `call_edge` table populated: C400 has 332 call_edge rows; ENTRC, ENTNC, CALL_ALIAS, CREEC, CALL, SWISC all present | SQL count + `GROUP BY call_type` check | ✅ Passed | 2026-05-28 | §9; call_graph_adapter.py wraps file_call_graph.py; spot-check Rule 6 ⏳ (source-line verification deferred to V11 live validation round) |
| V11.2 | `call_edge_guard` populated: 5 known guarded calls in C400 each have ≥1 `call_edge_guard` row; `guard_kind` is one of the 26 valid values; `guard_expression` matches source at `source_line` | SQL + manual spot-check of guard_expression vs source (guard validator) | ⏳ | — | §8; Rule 6 |
| V11.3 | I/O site extraction (L1): 53 io_site rows for C400; DBRED(19), DBMOD(7), DBADD(6), DBCLS(6), DBOPN(4), DBIFB(8), DBDEL(2), DBCKP(1) | SQL count + `GROUP BY op_type` | ✅ Passed | 2026-05-28 | §4.1.1 L1; 0 UNKNOWN blocks; idempotent; Rule 6 source scan |
| V11.4 | I/O site extraction (L2): at least 1 L2 row exists for C400 if any wrapper macros / H2-H13 patterns are present; `evidence_json` contains the named rule | SQL check on detection_layer='L2-heuristic'; L2 validator confirms signal | ⏳ | — | §4.1.1 L2 |
| V11.5 | Subfile sessions: 4 DBOPN rows produced 4 subfile_session rows; each matched to DBCLS in same file by target_ref | SQL: `SELECT COUNT(*) FROM subfile_session WHERE process='C400'` = 4 | ✅ Passed | 2026-05-28 | §5.1; lifecycle_detector.py |
| V11.6 | Storage lifecycle: 76 events for C400 (GETCC=16, RELCC=7, ATTAC=27, DETAC=26); GETCC↔RELCC sequential pairing done | SQL count + paired_event_id check | ✅ Passed | 2026-05-28 | §5.2; lifecycle_detector.py |
| V11.7 | Commit scopes: every TXBGC has a paired TXCMC/TXRBC (or `end_kind='unclosed'`); scope validator passes | SQL assertion on `commit_scope` table; commit scope validator | ⏳ | — | §5.4 |
| V11.8 | `block_utility_classification` has one row per block in C400 (788 rows = block count); 130 at L1 confidence, 26 at L2; all utility_confidence >= 0.9 rows have detection_layer='L1' with ≥3 structural signals | SQL count + `GROUP BY detection_layer`; utility_confidence check | ✅ Passed | 2026-05-28 | §4.1.2; utility_classifier.py |
| V11.9 | L0 path signals: known utility-path blocks (e.g. any file under `*/util/*` in codebase) have `detection_layer='L0'` and `utility_confidence=1.0` | SQL check; L0 validator confirms path still holds | ⏳ | — | §4.1.2 L0 |
| V11.10 | `variable_alias` populated: at least 5 alias pairs for C400 (cpp-asm or ecb-field or register-bridge); each alias pair verified against source | SQL count; spot-check 3 pairs against `passes/ecb_alias_table.py` output | ⏳ | — | §4.4 Step 1 |
| V11.11 | `find_connected_variables` + `map_connected_variables` output: C400 has ≥1 `call_boundary_register` mapping and ≥1 `return_register` mapping | Run wrappers against C400; check JSON output has `from_var`/`to_var` fields with non-null values | ⏳ | — | §4.1; return_register pattern |
| V11.12 | Macro expansion runs BEFORE call_graph_builder in Phase 1 pipeline (audit gap §16): calls inside macro bodies appear in `call_edge` table | Live: after P11 runs, grep C400 source for macro-wrapped calls; confirm they appear in `call_edge` | ⏳ | — | §9.5; §16 audit gap |

---

## P12 — Phase 3 top-down walk validations ⏳ (code complete; V12.1-5,7-8 require full LLM run)

| Id | What it validates | Method | Status | Date | Notes |
|---|---|---|---|---|---|
| V12.1 | Walk BFS from C400 entry block covers all reachable blocks (not skipped-utility); `walk_node` count ≥ 50 for C400 | SQL count vs file_graph reachable-block estimate | ⏳ | — | |
| V12.2 | Every walk_node has non-empty `status` (one of 14 valid values) and non-empty `inputs_consumed` / `outputs_produced` for non-skipped-utility nodes | SQL null-count + status enum check after Phase 3 | ⏳ | — | |
| V12.3 | Safety caps respected: no walk_node `depth` exceeds `MAX_DEPTH=10`; total walk_node count ≤ `MAX_WALK_NODES=1500`; any truncation event written to `walk_truncation` | SQL MAX(depth) + COUNT(*) checks | ⏳ | — | §4.3 |
| V12.4 | `condition_humanizer`: `condition_human` populated for every `call_edge_guard` with non-NULL `guard_expression`; zero forbidden tokens (opcodes, registers, hex) in `condition_human` | SQL count check + lint scan on condition_human column | ⏳ | — | §8; no-dup-LLM: batched 20/call |
| V12.5 | Cross-language edges: for each `call_edge` where `is_cross_language=1`, both `from_file` and `to_file` are in C400 process; edge carries correct `indirection_json` envelope | SQL check + spot-check 3 cross-language edges against source | ⏳ | — | §9.3; §9.0 envelope |
| V12.6 | `process_meta` has a row for C400 with non-null `entry_json`; `GET /entry` returns it correctly | SQL check + live curl against running backend | ✅ Passed (SQL) | 2026-05-28 | entry_json: {"file": "temp/asm/lu82.asm", "block": "LU8X100"}; curl deferred |
| V12.7 | L3 I/O site LLM pass (Phase 1e): runs AFTER Phase 3; at least 1 L3 row exists if any data-path block has write-like signal; `evidence_json` contains `llm_rationale`; L3 validator confirms write-to-non-local/persistence-call/file-queue-op | SQL check on detection_layer='L3-llm'; L3 validator | ⏳ | — | §4.1.1 L3; Phase 1e |
| V12.8 | L3.5 utility verification: any L2-only-classified blocks (Trigger A) have been re-evaluated; `l35_trigger='l2-ambiguous'` on those rows; `block_embedding` table has rows for all walk_node blocks | SQL check on l35_trigger + block_embedding count | ⏳ | — | §4.1.2 L3.5 |

---

## P13 — Phase 4 variable context validations ⏳

| Id | What it validates | Method | Status | Date | Notes |
|---|---|---|---|---|---|
| V13.1 | `variable_context` has one row per (process, variable) for all C400 variables; anchor_blocks_json non-empty for every row | SQL count vs `variable` table count; NULL check on anchor_blocks_json | ⏳ | — | §4.4a Step 1 |
| V13.2 | All 6 question fields (purpose, computation_source, availability, persistence_effects_json, flow_variations_json, business_flow_context) non-NULL for Phase-4-populated rows; `coverage_json` present and contains all 6 keys | SQL null-count; JSON key check on coverage_json | ⏳ | — | §4.4a Step 4 |
| V13.3 | 1-level-up/down context: `down_contexts_json` references actual callee files in C400 process graph; `up_contexts_json` references actual caller files; both verified against `file_graph.json` | SQL + JSON spot-check on 5 variables against file_graph.json | ⏳ | — | §4.4a Steps 2+3; all 8 cross-language patterns |
| V13.4 | `return_register` pattern covered: at least 1 variable where `down_contexts_json` or `up_contexts_json` has `edge_type='return_register'`; `from_var`/`to_var` non-null in that entry | SQL JSON extract on down/up contexts | ⏳ | — | §4.4a return-register pattern |
| V13.5 | `variable_classification`: every C400 variable has ≥1 of 5 labels; label distribution has ≥1 row each for `business` and `process-io` | SQL count per label | ⏳ | — | §4.4b |
| V13.6 | `variable_meaning` populated from `variable_context.purpose` via SQL; no extra LLM call made (no-dup-LLM rule): confirm `variable_meaning.meaning == variable_context.purpose` for 10 spot-checked rows | SQL join + equality check | ⏳ | — | §11; no-dup-LLM |
| V13.7 | Lint: no forbidden tokens (opcodes, registers R\d+, hex 0x…, ->, ::) in `purpose`/`availability` columns of `variable_context` | `scripts/validate_variable_purposes.py` extended to scan `variable_context` table | ⏳ | — | Same pattern as V4.4 |

---

## P14 — Phase 5 synthesis validations ⏳

| Id | What it validates | Method | Status | Date | Notes |
|---|---|---|---|---|---|
| V14.1 | `process_artifact` has all 4 narrative kinds (narrative-executive-summary, narrative-e2e-flows, narrative-variable-landscape, narrative-persistence-footprint) after Phase 5; all non-empty | SQL check + NULL check on payload_json | ⏳ | — | §4.5.1 |
| V14.2 | `process_flow` has ≥1 row for C400; each flow has non-empty `path_json` with ≥2 steps; at least 1 flow with `output_kind='persistence-write'` | SQL count + JSON step count check | ⏳ | — | §4.5 artifact 3 |
| V14.3 | `commit_scope_narrative`: every `commit_scope` row for C400 has a matching `commit_scope_narrative` row; `narrative` and `key_variables_json` non-empty | SQL LEFT JOIN check | ⏳ | — | §4.5 artifact 6; §5.4 |
| V14.4 | Payload lineage: every `process-io` variable in C400 has ≥1 `payload_lineage` row; each chain has ≥2 steps in `steps_json` | SQL count; JSON step count check | ⏳ | — | §4.5.2 |
| V14.5 | Walkthrough coverage: `scripts/validate_walkthrough_coverage.py` passes — union of `source_block_ids_json` across all cards equals eligible walk_node set (status != 'skipped-utility' AND not in walk_truncation) | pytest + script | ⏳ | — | §4.5.3; §15 |
| V14.6 | Walkthrough no-technical-names: `scripts/validate_walkthrough_coverage.py` no-technical-names scan passes — zero hits of .asm/.cpp, DB[A-Z]{3+}, TX[A-Z]{3}, R\d+, WA\d+, WK_[A-Z0-9]+ in title/body/bridge_to_next | same script | ⏳ | — | §4.5.3; §15 |
| V14.7 | Walkthrough card count: `process_narrative_card` has 50-100 cards for C400; every card has non-null `visualization_payload_json` with `focus_blocks` ≤ 20 | SQL count + JSON key check | ⏳ | — | §4.5.3 |
| V14.8 | Complexity metrics: `process_artifact` has kind='complexity_metrics' with all 8 metric keys (file_span, total_blocks, max_call_depth, total_call_edges, conditional_branches, total_variables, cross_file_connections, data_path_blocks) + `composite_score` and `composite_band` | SQL + JSON key check | ⏳ | — | §4.6 |

---

## P14.5 — Phase 2 update validations ✅ (code complete; V14.5.1-3 require full pipeline run)

| Id | What it validates | Method | Status | Date | Notes |
|---|---|---|---|---|---|
| V14.5.1 | `entity_business_name` has entries for all 16 C400 files (entity_type='file') + all walk_node blocks (entity_type='block') after Phase 2 completes | SQL count vs file_graph.json file count + walk_node count | ⏳ | — | Requires full pipeline LLM run; TEMPLATE_VERSION bumped to force re-extract |
| V14.5.2 | Block LLM response now includes `business_name` field; spot-check 5 blocks: `business_name` is 2-5 words, no forbidden tokens, no empty string | SQL check on entity_business_name; manual review of 5 samples | ⏳ | — | Requires full pipeline LLM run |
| V14.5.3 | `entity_business_name` for DB records (entity_type='record'): each unique `target_record` value in C400 `io_site` has a business name | SQL count: `SELECT COUNT(DISTINCT target_record) FROM io_site WHERE process='C400'` vs entity_business_name count for entity_type='record' | ⏳ | — | Requires full pipeline LLM run |
| V14.5.4 | `translate_to_business_language()` safe-filler check: translate a text containing a known-unknown token; confirm output does NOT contain the raw token; `untranslated_tokens` list non-empty for that call | unit test (python -c inline) | ✅ Passed | 2026-05-28 | EC123, FL456 → "a data record"; plain English words preserved |

---

## P15 — §12 API Stage A stubs validations

| Id | What it validates | Method | Status | Date | Notes |
|---|---|---|---|---|---|
| V15.1 | All 5 new route modules import without error; no circular import | `python -c "from explanability_demo.backend.app import app"` — verified 53 routes | ✅ Passed | 2026-05-28 | |
| V15.2 | `GET /walk` returns fixture WalkNodeOut list with expected schema fields | curl against running backend | ⏳ | — | Requires running backend; stub data: 5 nodes, depths 0-3 |
| V15.3 | `GET /walkthrough` returns 2 NarrativeCardOut items with visualization_payload | curl | ⏳ | — | Default limit=2; 4 stub cards total |
| V15.4 | `GET /build/status/{task_id}` returns TaskStatusResponse (not 404) when Redis down | curl | ⏳ | — | Should return `status:"pending"` gracefully |

---

## P16 — Chat upgrade validations ⏳

| Id | What it validates | Method | Status | Date | Notes |
|---|---|---|---|---|---|
| V16.1 | Tier 1 native fn calling: `CATALOG` in `tools.py` registers ≥16 tools (get_variable_purpose, search_chunks, get_walk_path, get_io_sites, get_variable_context, get_flow, get_walkthrough, get_payload_lineage, get_narrative, get_classification, get_block_summary, get_process_meta, get_call_edges, get_commit_scopes, get_process_flows, get_complexity_metrics + any extras); tool dispatches cleanly with no TypeError | `python -c "from explanability_demo.backend.agent.tools import CATALOG; assert len(CATALOG) >= 16"` + unit dispatch test for each tool | ⏳ | — | §13.5 Tier 1 |
| V16.2 | Reiteration + critic pass: agent produces an initial answer; critic scores it < 0.7 on a forced low-quality prompt; a refined second answer is emitted with `iteration=2`; final SSE has `critic_score` > threshold | unit test with mocked critic LLM returning score=0.5, then re-run producing score=0.85 | ⏳ | — | §13.5 Tier 1; critic pass |
| V16.3 | `session_id` persisted across 3 chat turns; `chat_session` table accumulates 3 rows; history replay in turn 3 references turn-1 content | live multi-turn curl against running backend; SQL check on `chat_session` row count | ⏳ | — | §13.5 Tier 2 |
| V16.4 | Tier 2 query routing: `router.py` classifies "what does WB1SW6 mean" as `direct`; "explain the credit limit flow" as `search`; "walk me through the entire maintenance process step by step" as `agent` | unit test with 3 prompts + mock LLM classifier returning labels | ⏳ | — | §13.5 Tier 2; query routing |
| V16.5 | Agent uses ≥2 different tools from §13 catalogue in a single complex answer (e.g. `search_chunks` + `get_variable_context` in one ReAct loop) | live Gemini run with complex question requiring both retrieval + context | ⏳ | — | §13.5 Tier 1 |
| V16.6 | `variable_meaning` field present in `GET /variables` response for every C400 variable after Phase 4; confirm `meaning == variable_context.purpose` for 5 spot-checked variables (no extra LLM call) | SQL join check + live curl | ⏳ | — | §13.5 Tier 3; no-dup-LLM rule |

---

## P17 — Hybrid search validations ⏳

| Id | What it validates | Method | Status | Date | Notes |
|---|---|---|---|---|---|
| V17.1 | `register_vector(conn)` present in `db.py::init_schema`; sqlite-vec extension loads without error; `chunk_embedding` vector table creates with 768-dimensional column | `python -c "from explanability_demo.backend.db import init_schema; import sqlite3; c=sqlite3.connect(':memory:'); init_schema(c)"` — no error | ⏳ | — | §17; register_vector required |
| V17.2 | RRF fusion (k=60) with equal BM25 + ANN top-50 lists produces correct merged ranking; known high-relevance doc scores higher in RRF than in either sub-list alone | unit test with controlled scores: inject doc A at BM25 rank=3 + ANN rank=5; confirm RRF rank > raw-BM25 rank | ⏳ | — | §11.5 RRF k=60 |
| V17.3 | `chunk_embedding` table populated for all C400 chunks after Phase 2 + Phase 4 run (block embeddings inline in Phase 2; variable_context embeddings from Phase 4); row count ≥ 935 | SQL: `SELECT COUNT(*) FROM chunk_embedding WHERE process='C400'` | ⏳ | — | §17; text-embedding-004; embeddings inline with Phase 2 |
| V17.4 | Dynamic alpha: `search_chunks` agent tool accepts `alpha` param; alpha=0.0 returns BM25-only ranking (ANN score zeroed); alpha=1.0 returns ANN-only ranking (BM25 score zeroed); alpha=0.5 blends | unit test with mock BM25 + ANN sub-rankers; assert rank lists differ per alpha | ⏳ | — | §11.5; dynamic alpha in search_chunks |

---

## P18 — Schema tables validations ⏳

| Id | What it validates | Method | Status | Date | Notes |
|---|---|---|---|---|---|
| V18.1 | All 25 new SQLite tables exist after `init_schema()` | SQL check on sqlite_master | ✅ Passed | 2026-05-28 | 27 tables found (includes process_to_process_edge + others) |
| V18.2 | `register_vector(conn)` in `db.py`; sqlite-vec 0.1.9 loads without error | `register_vector` on `:memory:` — no exception | ✅ Passed | 2026-05-28 | Graceful no-op fallback if extension unavailable |
| V18.3 | `project_id` on all scoped tables: process, file, block, variable, call_edge, io_site, walk_node, variable_context, entity_business_name | `PRAGMA table_info` for 6 tables | ✅ Passed | 2026-05-28 | ALTER TABLE migrations in init_schema(); project_id indices deferred after ALTERs |
| V18.4 | Critical column shapes: io_site (detection_layer, target_record), variable_context (6 fields + coverage_json), walk_node (depth, status, inputs_consumed, outputs_produced) | `PRAGMA table_info` | ✅ Passed | 2026-05-28 | |
| V18.5 | `init_schema()` idempotent: double-init does not error | double call | ✅ Passed | 2026-05-28 | All IF NOT EXISTS; indices guarded by try/except |

---

## P19 — Frontend Stage B validations ⏳

| Id | What it validates | Method | Status | Date | Notes |
|---|---|---|---|---|---|
| V19.1 | B-0 Process overview upgrade: complexity metrics card renders on process detail page; `composite_band` (Low/Medium/High/Very High) displayed as colored status chip; 8 metric keys visible | browser smoke on `http://localhost:5173/p/C400` after Phase 5 complete | ⏳ | — | §18 B-0; §4.6 complexity metrics |
| V19.2 | B-2 Walk view: `/p/C400/walk` route renders walk_node list with BFS depth indentation; utility nodes styled with muted color; clicking a node shows inputs/outputs panel | browser smoke; verify depth > 0 nodes are visually indented; click 2 nodes | ⏳ | — | §18 B-2; walk_node |
| V19.3 | B-5 Variable context panel: `/p/C400/variables/<V>/context` route renders all 6 question fields (purpose, computation_source, availability, persistence_effects, flow_variations, business_flow_context); coverage chips (not_found / partial / present) shown for each field | browser smoke on 1 variable with fully-populated variable_context row | ⏳ | — | §18 B-5; §4.4a 6-question framework |
| V19.4 | B-6 Flow enumeration: `/p/C400/flows` route renders process_flow list; clicking a flow expands step-by-step path with file/block names translated to business names (no .asm/.cpp visible) | browser smoke; verify 0 .asm/.cpp occurrences in flow step text | ⏳ | — | §18 B-6; translate_to_business_language |
| V19.5 | B-7 Payload lineage tree: `/p/C400/variables/<V>/lineage` route renders payload_lineage chain as a tree for a `process-io` classified variable; ≥2 steps visible; step icons differ by step_kind | browser smoke on 1 process-io variable | ⏳ | — | §18 B-7; payload_lineage |
| V19.6 | B-9 + B-10 Narrative panels: executive summary and E2E flow narrative sections render in `/p/C400/narrative`; no raw opcode, register, hex, .asm/.cpp in rendered text; minimum 3 paragraphs per section | browser smoke + forbidden-token visual scan | ⏳ | — | §18 B-9/B-10; §4.5.1 narrative artifacts |
| V19.7 | B-11 Walkthrough card carousel: `/p/C400/walkthrough` route loads 50-100 cards for C400; prev/next navigation advances to next card; `visualization_payload_json` focus_blocks render as highlighted code snippets | browser smoke; click prev/next 3 times; confirm card counter increments | ⏳ | — | §18 B-11; §4.5.3 walkthrough cards |

---

## P20 — ASM indirect branch resolver validations ⏳

| Id | What it validates | Method | Status | Date | Notes |
|---|---|---|---|---|---|
| V20.1 | `INDIRECT_BRANCH` / `COMPUTED_JUMP` call_edge rows exist in `call_edge` table for C400 after Phase 1 runs; at least 1 detected across 9 C400 ASM files | SQL: `SELECT COUNT(*) FROM call_edge WHERE call_type IN ('INDIRECT_BRANCH','COMPUTED_JUMP') AND process='C400'`; must be ≥1 | ⏳ | — | §9.6; ASM indirect branch detection |
| V20.2 | Steps 1-4 resolver pipeline: for a known dispatch table pattern (or literal-pool branch) in C400, the resolver populates `resolved_target` and `resolution_method` in the matching call_edge or `indirection_json` envelope; `resolution_method` is one of `literal-pool`, `local-label`, `table-dispatch`, `register-copy-chain` | run resolver on C400; SQL check on `resolution_method` values; spot-check 1 edge against source instruction | ⏳ | — | §9.6 Steps 1-4 |
| V20.3 | LLM fallback for `L Rx,FIELD(Rb)` pattern: at least 1 edge has `resolution_method='llm-fallback'`; `resolved_target` non-null; `call_llm_model` used (not direct SDK) | SQL check + grep for call_llm_model in resolver code; no direct google.generativeai import | ⏳ | — | §9.6 LLM fallback; Rule 1 |
| V20.4 | Envelope mandate: all 19 indirect-call sites across C400 annotated; every INDIRECT_BRANCH / COMPUTED_JUMP edge has non-null `indirection_json` populated via `envelope_from_fields()` from `api/utils/indirection.py` | SQL: `SELECT COUNT(*) FROM call_edge WHERE call_type IN ('INDIRECT_BRANCH','COMPUTED_JUMP') AND indirection_json IS NULL` must = 0; grep confirms `envelope_from_fields` used in resolver | ⏳ | — | §9.6; §9.0 envelope mandate; 19 sites |

---

## How to use this tracker

- Add a **date** the moment you run a validation.
- If a check fails, mark ❌, add a one-line cause, and create a corresponding **fix item** in DEV_TRACKER. Do not move forward until ✅ or explicitly ⚠️ with documented compensating control.
- After bumping a prompt template, mark all related V3.* / V4.* / V8.* as ♻️ (re-run needed).
- Add new check rows whenever a new design assumption appears. Validations grow; they don't shrink.
- **Per PROJECT_RULES.md Rule 3** — every validation should have a **live** counterpart unless the check is fundamentally synthetic (static lint, type check, etc.). When designing P-N validations, list both the unit/mock check AND the live check explicitly. A phase cannot close with owed live ⏳ checks unless the deferral is documented in DEV_TRACKER with cost/time/blocker reason.
