# Development Tracker — explanability_demo

Living checklist of every implementation item across all phases.
Status legend: ✅ Done · 🔄 In-progress · ⏳ Pending · ⛔ Blocked · ⏸️ Paused

Updated: 2026-05-28

---

## Dashboard

| Phase | Title | Status | Started | Completed |
|---|---|---|---|---|
| P0 | C400 data fix from real lu82 chain | ✅ Done | 2026-05-27 | 2026-05-27 |
| P1 | Design doc + 6 structural decisions | ✅ Done | 2026-05-27 | 2026-05-27 |
| P2 | Backend skeleton (FastAPI + SQLite + call_llm_json) + read-only `/processes` endpoints | ✅ Done | 2026-05-27 | 2026-05-27 |
| P3 | Knowledge extraction pipeline (Gemini topo passes, blocks → files → process) | ✅ Done (V3.3 live build discharged 2026-05-27 — 788 blocks / 16 files / process summary; Rule-6 parser validation ✅) | 2026-05-27 | 2026-05-27 |
| P4 | Variable inventory extraction (filter + purpose pass) + `/variables` endpoints | ✅ Done | 2026-05-27 | 2026-05-27 |
| P5 | Frontend (process list → process detail → files split graph+list → variables list) | 🔄 5a done (V1+V2 overview+V5); 5b–5d pending | 2026-05-27 | — |
| P6 | forward_traversal package (mirror backward_traversal) + setter/usage-flow endpoints | ✅ Done — Track A (G6/G8/G10/G13) + Track B (G1/G2/G4/G5/G9) complete; Track C + G7/G14/G16 deferred at scale | 2026-05-27 | 2026-05-27 |
| P7 | Chunked SSE investigation endpoint + V9 explanation UI | ✅ Done (2026-05-28) — 7.1 sse.py, 7.2 investigation_planner.py, 7.3 SSE endpoint on variables router, 7.4 LineagePanel + iteration cards, 7.5 source chip + GET .../source | 2026-05-27 | 2026-05-28 |
| P8 | Retrieval / QA service (Adaptive RAG with agentic ReAct loop) + chat surfaces | ✅ Done — 8.0 agent live, 8.1 BM25+rerank, 8.2 investigation→chat seeding | 2026-05-27 | 2026-05-27 |
| P9 | Polish, validation suite, READMEs per directory | ✅ Done (2026-05-28) — retrieval README ✅ Done — updated `backend/retrieval/README.md` (§1 hybrid overview, §2 files, §3 usage, §4 adding strategy); DEPLOY.md still deferred | 2026-05-27 | 2026-05-28 |
| P10 | Celery/Redis infrastructure (3-queue topology, 202 build pattern, embedding entry, macro map) | ✅ Done — celery_app.py, redis_client.py, embedding.py, macro_business_map.py, build.py Celery 202 retrofit | 2026-05-28 | 2026-05-28 |
| P11 | Phase 1 static analysis (I/O sites, utility detection 7-layer, commit scopes, storage lifecycle) | ✅ Done (2026-05-28) — all 11a/11b/11c/11d sub-items complete | multiple `parent_adapters/` files | 11c.2 L2 heuristics ✅ Done (2026-05-28) — `run_phase1_l2` with H1–H13 in `io_detector.py`, wired into build_task; 11a.5/11d.4 audit table ✅ Done (2026-05-28) — `docs/phase1_audit_table.md` |
| P12 | Phase 3 top-down walk (walker.py, walk_node / call_edge / io_site population, condition_humanizer pass) | ✅ Done (2026-05-28) | `walker.py`, `build_task.py`, `io_detector.py` | 12.1-12.7 done; 12.8 L3-LLM + 12.9 L3.5 both implemented and wired as Phase 3c/3d |
| P13 | Phase 4 variable context (1-level-up/down extraction, 6-question LLM, variable_context table population) | ✅ Done (2026-05-28) | `variable_context_pipeline.py` | Steps 1-4 + variable_meaning + embedding done; wired into Phase 4 in build_task |
| P14 | Phase 5 synthesis (narrative artifacts, payload lineage, walkthrough card builder, complexity metrics persist) | ✅ Done (2026-05-28) | `synthesis.py`, `walkthrough.py`, `payload_lineage.py` | All 14a-14e items complete |
| P15 | §12 API Stage A stubs (walk, io-sites, flows, walkthrough, variable-context routes wired into app.py) | ✅ Done — all 5 route modules created + registered; 202 task-status poll endpoint added | 2026-05-28 | 2026-05-28 |
| P16 | Chat upgrade — Tier 1 (native fn calling, 16+ tools), Tier 2 (routing, session memory, Gemini cache), Tier 3 (IRCoT, dynamic alpha) | ✅ Done (2026-05-28) — T1+T2+T3 all done; T2.4 Gemini cache ✅ Done — `backend/chat/cache.py` + wired into `routes/chat.py::process_chat` | 2026-05-28 | 2026-05-28 |
| P17 | Hybrid search (BM25 + ANN cosine with RRF k=60, pgvector SQLite adapter, dynamic alpha, IRCoT) | ✅ Done (2026-05-28) | `backend/retrieval/search.py::hybrid_search()` | 17.1-17.4 all done; sqlite-vec ANN leg with graceful BM25 fallback |
| P18 | Schema — all missing SQLite tables (call_edge, call_edge_guard, io_site, io_site_variable, subfile_session, storage_lifecycle, commit_scope, variable_context, variable_classification, variable_meaning, variable_alias, ecb_alias, walk_node, process_flow, entity_business_name, payload_lineage, commit_scope_narrative, process_narrative_card, chat_session, chunk_embedding, variable_context_embedding, block_embedding, block_utility_classification, cross_process_call_index, process_meta) + register_vector(conn) in db.py | ✅ Done — schema.sql had all 25 tables already; added sqlite-vec register_vector + project_id migrations; V18.1-18.5 all pass | 2026-05-28 | 2026-05-28 |
| P14.5 | Phase 2 updates — business_name field in block prompt, entity_business_name population (files/blocks/records), block embeddings built in Phase 2, llm/business_name.py wrap for file names | ✅ Done (2026-05-28) | `runner.py`, `translate.py`, prompt files | All 6 sub-items done |
| P19 | Frontend Stage B (B-0 remove investigation, B-1 variable label chips, B-2 homepage panels, B-3 call graph guards, B-4 block status badges, B-5 flows view, B-6 persistence view, B-7 commit-scope view, B-8 chat tools, B-9 business names everywhere, B-10 complexity dashboard, B-11 walkthrough page) | ✅ Done (2026-05-28) — all B items complete | frontend/src | All B-0 through B-11 + narrative done |
| P20 | ASM indirect branch resolver §9.6 (asm_indirect_branch_resolver.py — 4-step backward trace, table dispatch, LLM fallback for L Rx,FIELD(Rb)) | ✅ Done (2026-05-28) | `backend/pipeline/asm_indirect_branch_resolver.py` | All 8 P20 sub-items done; Steps 1-5, table dispatch, LLM fallback, walk_truncation log |

---

## Parallel Implementation Strategy

Three tracks can run concurrently after **P18 (Schema)** completes. Start P18 first — every pipeline phase reads from or writes to the new tables.

```
Track 1 — Pipeline (sequential, top-down by design)
  P18 Schema
    → P11 Phase 1 (static: call edges, I/O sites, utility, storage lifecycle, commit scopes)
    → P14.5 Phase 2 update (business names in block prompt, entity_business_name, embeddings)
    → P12 Phase 3 (top-down walk, walk_node, call_edge_guard humanizer)
    → P13 Phase 4 (variable context 1-level-up/down, 6-question LLM, classification)
    → P14 Phase 5 (synthesis, flow enumeration, commit_scope_narrative, walkthrough cards)

Track 2 — Frontend (parallel to Track 1 from Day 1, uses Stage A stubs from P15)
  P19-B0 (remove investigation page)
  → P19-B1 (variable label chips)          ← depends on B0
  → P19-B2 (process homepage panels)       ← independent
  → P19-B3 (call graph guard labels)       ← independent
  → P19-B4 (block status badges)           ← independent
  → P19-B5 (flows view)                    ← independent
  → P19-B6 (persistence view)              ← independent
  → P19-B7 (commit-scope view)             ← independent
  → P19-B8 (chat tool wiring)              ← depends on B2-B7
  → P19-B9 (business names everywhere)     ← depends on B2-B7
  → P19-B10 (complexity dashboard)         ← depends on B2
  → P19-B11 (walkthrough page — largest)   ← independent but benefits from B9

Track 3 — Infrastructure upgrades (parallel to Track 1)
  P20 ASM indirect branch resolver         ← parallel to P11
  P16-T1 Chat Tier 1 (native fn calling, 16+ tools, reiteration, critic)  ← after P15
  P17 Hybrid search                        ← after P14.5 (needs embeddings)
  P16-T2 Chat Tier 2 (routing, session memory, Gemini cache)   ← after P17
  P16-T3 Chat Tier 3 (IRCoT, dynamic alpha)                    ← after P16-T2
```

**Critical path:** P18 → P11 → P14.5 → P12 → P13 → P14 → stub-to-real swap in all Stage A routes.

**Parallelism within phases:**
- P11 sub-tasks (1a→1d) can partially parallelize: 1a (call graph) and 1c (utility/storage/commit) are independent; 1b (variable identity) needs 1a first; 1d (L2 heuristics) needs 1a first; 1e (L3 LLM I/O) needs Phase 3 first.
- P12 walker: utility check (DB query) runs before LLM; parallel within `ThreadPoolExecutor` per topo level (capped at 16).
- P13 variable context: Steps 1-3 deterministic, then parallel LLM via `ThreadPoolExecutor(8)` per variable.
- P14 walkthrough Stage 2: parallel LLM per segment via `ThreadPoolExecutor(16)`.
- P19 frontend: B2-B7 are all independent and can be built concurrently by separate devs.

**No-duplicate-LLM checkpoints (enforce before any PR):**
1. Block summary + business_name = ONE call per block (P14.5).
2. `variable_meaning` = derived from `variable_context.purpose` via SQL, no extra LLM (P13).
3. `condition_human` = batched 20/call in post-Phase-3 humanizer pass (P12.5, already in build_task.py).
4. `commit_scope_narrative` = one LLM call per scope, parallel (P14).
5. Narrative sections 1–3 = three LLM calls total; section 4 assembled deterministically (P14).
6. `translate_to_business_language()` = pure dictionary lookup, no LLM (P14.5).

---

## Phase 0 — C400 data fix ✅

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 0.1 | Delete stub data in `data/processes/C400/` | ✅ | `--purge` flag in generator | Keeps `metadata.json` + `predefined_questions.json` |
| 0.2 | Generator: real file_graph.json from process_truncated_file_graph.json | ✅ | `scripts/build_process_data.py` | 16 nodes / 20 edges |
| 0.3 | Generator: real headers.json (source-scan #include) | ✅ | same script | 2 found / 41 missing (system headers) |
| 0.4 | Generator: real macros.json (source-scan opcodes vs .mac names) | ✅ | same script | 9-name macro index |
| 0.5 | README for scripts/ explaining repro + validation | ✅ | `scripts/README.md` | |
| 0.6 | **plastic_authentication missing parser blueprints** — diagnosis (2026-05-28) | ⚠️ Data gap (outside demo scope; Rule 5) | `data/processes/plastic_authentication/file_graph.json` lists 10 files under `temp/plastic_files/*.cpp`; **0** corresponding `temp/output_latest/asm/*.cpp.json` blueprints exist. Build silently skipped all 10 files (runner.py:527 `Skipping file (no blueprint): ...`) → 0 blocks, 0 call_edges, 0 io_sites in DB; only the synthetic process-entry walk_node was emitted (walker.py:391 seeds queue from `entry_json` before checking `block` table) → walkthrough has 1 card. **Verified** by `sqlite3 knowledge.db "SELECT count(*) FROM block WHERE process='plastic_authentication'"` → 0 and `/tmp/celery_demo.log` shows 10 `Skipping file (no blueprint)` warnings at 20:20:52. Fix requires running the top-level `main.py` parser to populate `temp/output_latest/asm/*.cpp.json` for the 10 plastic files (a smoke test confirmed `env/bin/python main.py -o <dir> temp/plastic_files/` successfully emits all 10 blueprints, ~25% coverage each). Per Rule 5 this is a data-generation step outside `explanability_demo/`; needs to be done by the user or via a fixture-prep script outside the demo. |

---

## Phase 1 — Design + decisions ✅

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 1.1 | Audit existing api/, explainability/, backward_traversal/ | ✅ | DESIGN.md §2, §15 | Done via Explore agent |
| 1.2 | Variable universe trust verdict (T1+T2 plan) | ✅ | DESIGN.md §6 | 2,726 ASM → ~1,175 after filter; 346 C++ clean |
| 1.3 | Knowledge extraction architecture (topo passes) | ✅ | DESIGN.md §4 | |
| 1.4 | Retrieval/QA architecture (BM25 + call_llm rerank + synth) | ✅ | DESIGN.md §8 | Updated after single-`call_llm` constraint |
| 1.5 | forward_traversal package design | ✅ | DESIGN.md §7 | Mirrors backward two-pass |
| 1.6 | SQLite schema | ✅ | DESIGN.md §11 | Dropped chunk_embedding after Q3 |
| 1.7 | 10-view frontend spec | ✅ | DESIGN.md §10 | React + Vite + Tailwind + shadcn/ui + React Flow |
| 1.8 | 6 structural decisions locked (Q1–Q6) | ✅ | DESIGN.md §14 | All ✅ as of 2026-05-27 |

---

## Phase 2 — Backend skeleton ✅

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 2.1 | Directory layout (`backend/{routes,schemas,tests}`) | ✅ | `explanability_demo/backend/` | |
| 2.2 | `backend/config.py` — `DemoSettings` (data dir, db path, port) | ✅ | `backend/config.py` | Pydantic-settings, `.env` via `DEMO_*` prefix |
| 2.3 | `backend/llm.py` — `call_llm_text` + `call_llm_json(prompt, schema_hint, max_retries=3)` | ✅ | `backend/llm.py` | Single LLM entry; fence strip + balanced-block fallback + parse retry |
| 2.4 | `backend/db.py` + `schema.sql` — SQLite init from §11 (no `chunk_embedding`) | ✅ | `backend/db.py`, `backend/schema.sql` | WAL + foreign keys + FTS5 probe |
| 2.5 | `backend/schemas/processes.py` — `ProcessSummary`, `ProcessDetailResponse`, etc. | ✅ | | `PredefinedQuestion` added after first run |
| 2.6 | `backend/routes/processes.py` — list, detail, file-graph, headers, macros endpoints | ✅ | | Stub-detection guard returns 409 with repair instruction |
| 2.7 | `backend/app.py` — FastAPI app, CORS, lifespan, route registration | ✅ | | Port 8010, `/demo/v1` prefix |
| 2.8 | `backend/tests/test_smoke.py` + `test_llm_wrapper.py` — 11 tests | ✅ | | All passing |
| 2.9 | `backend/README.md` — how to run + endpoints catalog + design rules | ✅ | | |
| 2.10 | Live `uvicorn` run, curl validation against C400 | ✅ | | V2.5 / V2.6 ✅ |

---

## Phase 3 — Knowledge extraction pipeline ✅ + Rule-6 retro

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 3.r1 | Parser-output validation script (Rule 6) | ✅ | `scripts/validate_parser_output.py` | 8 checks (PA1, PA1b, PA2, PA3, PA4, PC1, PC2, PC3); re-runnable |
| 3.r2 | Run validation against C400 source — overall pass | ✅ | `docs/parser_validation_C400.json` | 16 files checked, 0 skipped, all gates ✅ |
| 3.r3 | Document synthetic file-entry block convention | ✅ | PA1b in `validate_parser_output.py` | Parser uses file-basename-uppercase as id for the first executable section; source slice still valid for LLM |



| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 3.1 | Block / function enumerator (ASM via `blocks`, C++ via `symbols.global_symbols`; intra-file callees from `call_graph.edges`) | ✅ | `backend/pipeline/enumerate.py` | Tested on xh88.asm (120 blocks) + dx740200.cpp |
| 3.2 | Kahn's topo-sort (sinks-first, deterministic cycle remainder) | ✅ | `backend/pipeline/topo.py` | |
| 3.3 | Per-block prompts (ASM + C++ variants, business-language rules baked in) | ✅ | `prompts/block_asm.txt`, `prompts/block_cpp.txt` | |
| 3.4 | Per-file prompt | ✅ | `prompts/file.txt` | |
| 3.5 | Per-process prompt | ✅ | `prompts/process.txt` | |
| 3.6 | Runner orchestrating block → file → process | ✅ | `backend/pipeline/runner.py` | Resumable via content-hash |
| 3.7 | Content-hash + `TEMPLATE_VERSION` invalidation | ✅ | inside runner | Tested via `test_build_invalidates_on_template_version_bump` |
| 3.8 | Build status endpoints + background thread manager | ✅ | `backend/routes/build.py` | `POST /build` + `GET /build/status`; conflict detection; failure path writes `build_phase='failed'` |
| 3.9 | Smoke build for C400 (mocked LLM) + single-block live Gemini sanity check (ASM + C++) | ✅ | `test_pipeline.py`, `scripts/sanity_check_llm.py` | Full live build deferred until UI consumes it |
| 3.10 | Shape validation (`required_keys`) on every JSON LLM response | ✅ | `backend/llm.py` | Added after observing truncated C++ responses returning bare `calls` arrays |
| 3.11 | `.env` `LLM_MAX_TOKENS` bumped 2048 → 8192 | ✅ | `.env` (user-approved) | Required for full long-block responses |
| 3.12 | V3.3 + V3b.3 discharge — full C400 live build + cache-hit rerun | ✅ | `scripts/snapshot_v33.py`, `docs/v33_v3b3_validation.json` | Live build: 788/788 blocks + 16/16 files + process summary persisted. Rerun: block-pass cached 787/788 (99.87%). File-pass + process-pass cache gaps documented as FU-CACHE-FILE / FU-CACHE-PROCESS. |

---

## Phase 3-b — Scale retrofit (Q-S1) ✅

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 3b.1 | `topo_levels()` — Kahn's with level grouping for parallel batches | ✅ | `backend/pipeline/topo.py::topo_levels` | Tested: groups independent nodes; cycle remainder appended as final level |
| 3b.2 | Retrofit `build_process()` block pass to levelized parallel execution | ✅ | `backend/pipeline/runner.py` | ThreadPoolExecutor per level, cap = `settings.MAX_CONCURRENT_LLM_CALLS` (default 16) |
| 3b.3 | Per-level dict snapshot for deterministic content_hash | ✅ | same | Discovered race condition in cycle-remainder level; snapshot freezes callee purposes at level boundary |
| 3b.4 | `DemoSettings.MAX_CONCURRENT_LLM_CALLS` | ✅ | `backend/config.py` | Configurable via env `DEMO_MAX_CONCURRENT_LLM_CALLS` |
| 3b.5 | Tests: `topo_levels` correctness + cycle handling | ✅ | `backend/tests/test_pipeline.py` | 2 new tests; suite is now 31/31 |
| 3b.6 | Cross-file block parallelism | ✅ Done (2026-05-28) | `backend/pipeline/runner.py` lines 688–703 | `topo_levels()` groups files by inter-file dependency level; each level runs under `ThreadPoolExecutor(max_workers=file_level_workers, thread_name_prefix="file")` |

## Phase 4 — Variable inventory ✅

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 4.0 | Research round (Rule 2) — structured output, purpose extraction, validation strategy | ✅ | `docs/p4_research.md` | 3 user decisions: pydantic + call_llm_json / single-shot ThreadPoolExecutor / lint + LLM-as-judge |
| 4.0b | Parser validation (Rule 6) — `variable_universe.json` against source | ✅ | `docs/parser_validation_universe_C400.json` | ASM 50/50, C++ 50/50 (after ±5 line window for enum members) |
| 4.1 | Loader: ASM universe → filter `is_runtime_symbol=True AND kind=='memory'` | ✅ | `backend/pipeline/variables.py` | Filter tightened empirically (EF-1 in PROJECT_RULES); 831 → 66 |
| 4.2 | Loader: C++ universe (no filter) | ✅ | same | 160 occurrences |
| 4.3 | Scope filter: only variables touched by files in process graph | ✅ | same | |
| 4.4 | Single-shot purpose-summary via `call_llm_model(VariablePurpose)`, parallelized via ThreadPoolExecutor(8) | ✅ | same | 226 unique entries, ~0.65s/call effective with 8 workers |
| 4.5 | Pydantic models for every LLM response shape | ✅ | `backend/schemas/llm.py` | BlockSummary, FileSummary, ProcessSummary, VariablePurpose, VariablePurposeJudgement |
| 4.6 | `call_llm_model(model: Type[BaseModel])` wrapper around `call_llm_json` | ✅ | `backend/llm.py` | Treats `ValidationError` as soft-error and re-prompts with field-level messages |
| 4.7 | `/processes/{P}/variables` (list + pagination + origin/search filters) | ✅ | `backend/routes/variables.py` | |
| 4.8 | `/processes/{P}/variables/{V}` (per-name occurrences) | ✅ | same | |
| 4.9 | `/processes/{P}/variables/build` + `/build/status` (background-thread variable build) | ✅ | same | Mirrors P3 build-route pattern |
| 4.10 | Live validation script (lint + LLM-as-judge on 50-sample) | ✅ | `scripts/validate_variable_purposes.py` | Used to discharge V4.4 + V4.5 |
| 4.11 | Tests (mocked) — loader, dedupe, usage-line scanner, pydantic validation, full pipeline | ✅ | `backend/tests/test_variables.py` | 5 new tests; suite is 29/29 |
| 4.12 | Live: full C400 variable build + lint + LLM-as-judge | ✅ | `docs/v4_validation_C400.json` | 226 entries built in 148s, lint 50/50, judge 47/50 |

---

## Phase 5 — Frontend (broken into 5a/5b/5c/5d)

### Phase 5a — Foundation + V1/V2/V5 ✅

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 5a.0 | Research round (Rule 2): routing, API client, test stack | ✅ | `docs/p5_research.md` | Q-P5a1/2/3 approved |
| 5a.1 | Vite + React 19 + TS + Tailwind 4 scaffold | ✅ | `frontend/` | |
| 5a.2 | shadcn/ui hand-written primitives (Button, Card, Badge, Skeleton, Input) | ✅ | `frontend/src/components/ui/*.tsx` | CLI init deferred to 5b for richer components |
| 5a.3 | TanStack Router + TanStack Query providers | ✅ | `frontend/src/main.tsx`, `frontend/vite.config.ts` (`TanStackRouterVite` plugin) | Generates `routeTree.gen.ts` |
| 5a.4 | Typed fetch API client (hand-mirrored types) | ✅ | `frontend/src/api/{client,types}.ts` | Codegen via @hey-api in 5b |
| 5a.5 | V1 Process list | ✅ | `frontend/src/routes/index.tsx` | |
| 5a.6 | V2 Process detail layout + Overview tab | ✅ | `frontend/src/routes/p.$P.tsx`, `frontend/src/routes/p.$P.index.tsx` | Tabs nav incl. "Variables"; "Files" tab is 5b |
| 5a.7 | V5 Variables list (paginated, filterable, origin-toggle) | ✅ | `frontend/src/routes/p.$P.variables.tsx` | |
| 5a.8 | Vitest config + first tests | ✅ | `frontend/src/test/*`, `vite.config.ts::test` | 2/2 pass |
| 5a.9 | Production build clean | ✅ | `dist/` | 350 KB / 109 KB gz |
| 5a.10 | README | ✅ | `frontend/README.md` | |

### Phase 5d — Variable detail + investigation flow (V7+V8+V9+V10) ✅

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 5d.1 | V7 Variable detail layout (declarations list + 3 action cards) | ✅ | `frontend/src/routes/p.$P.v.$V.tsx` | Linked from Variables list, file-detail blocks, and chat source chips |
| 5d.2 | V8 Investigation chooser stats card + manifest summary | ✅ | inline in V9 (`p.$P.v.$V.investigation.$direction.tsx`) | Stats: files in scope / setter-like / overwrite / cross-file count / dep_vars |
| 5d.3 | V9 Chunked explanation (timeline UI, source chips, streaming status) | ✅ | same | Calls Phase 7 SSE endpoint; renders messages as connected timeline |
| 5d.4 | V10 Variable chat (seeded ChatStream with `scopedVariable` prop) | ✅ | `frontend/src/routes/p.$P.v.$V.chat.tsx` | Posts to `/variables/{V}/chat` instead of `/chat` |

### Phase 7 — Chunked SSE investigation ✅

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 7.1 | SSE generator infrastructure (event framing helper) | ✅ | `backend/routes/investigation.py::_sse` + `_run_investigation` | Yields `status / manifest / plan / message / done / error` events |
| 7.2 | Iteration planner: trace → evidence clusters by file × top-K interesting roles | ✅ | `_build_iteration_clusters` | One cluster per file; up to 6 representative nodes per cluster (evenly spaced sample) |
| 7.3 | `POST /demo/v1/processes/{P}/variables/{V}/investigation/{direction}` | ✅ | router registered at `/demo/v1/processes` | SSE streamed, max_messages configurable (1–15) |
| 7.4 | V9 timeline UI (frontend, vertical thread with source chips) | ✅ | `p.$P.v.$V.investigation.$direction.tsx` | Each iteration becomes a node on a left-rail timeline |
| 7.5 | Source chip → side panel showing raw source snippet | ✅ Done (2026-05-28) | see Phase 7 §7.5 row | Implemented in prior session — GET .../source endpoint + SourcePanel in variable detail |
| 7.6 | InvestigationRequest accepts `declaration_file` (parity with /usage-flows) | ✅ | `backend/routes/investigation.py` | Found during V7.1–V7.3 scripted validation: WB1SW6 errored because the multi-declaration variable couldn't be disambiguated. Fix lets V8 chooser pass the user's selected declaration through to the SSE endpoint. |
| 7.7 | V7.1 / V7.2 / V7.3 scripted live validation | ✅ | `scripts/validate_v6_v7.py`, `docs/v6_v7_validation.json` | Two SSE runs (A7AFTERGLHIST setter, WB1SW6 usage). Event counts match plan; every message cites ≥1 source; connectedness via source-overlap / variable-mention / paraphrase marker. |

### Phase 5c — Chat surface V6 ✅ (live)

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 5c.1 | Native SSE plumbing (fetch + ReadableStream + manual parser; no new deps) | ✅ | `frontend/src/components/blocks/ChatStream.tsx::streamChat` | ~40 LOC, supports POST (browser EventSource only does GET) |
| 5c.2 | `<ChatStream/>` component — user/assistant bubbles, source chips, "inspect trace" collapse, send-while-streaming guard | ✅ | same | Renders `thought / tool_call / tool_result / answer / done / error` events |
| 5c.3 | `/p/$P/chat` route + Chat tab in process detail layout | ✅ | `frontend/src/routes/p.$P.chat.tsx`, `p.$P.tsx` | |
| 5c.4 | Build clean (1.97 MB / 613 KB gz) + 2/2 Vitest pass | ✅ | | |
| 5c.5 | Live end-to-end smoke through Vite proxy → backend → Gemini → back through SSE | ✅ | recorded in agent README | 2-iter answer on `casGlosOutputMessage` with 2 cited sources |

### Phase 5b — Graphs + File detail (V3+V4) ✅

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 5b.1 | `@hey-api/openapi-ts` codegen from backend `/openapi.json` | ✅ Done (2026-05-28) | `frontend/openapi-ts.config.ts`, `frontend/openapi.json`, `src/api/__generated__/` (4 files), `package.json generate` script | Core model types re-exported from codegen; BlockRow/FileDetail/VariableRow hand-rolled (have extra fields not in spec); `npm run generate` re-runs from saved openapi.json |
| 5b.2 | Install @xyflow/react + elkjs | ✅ | | |
| 5b.3 | `<Graph/>` component | ✅ | | |
| 5b.4 | V3 Files (50/50 split + cross-highlight) | ✅ | | "open →" link added to each row pointing to V4 |
| 5b.5 | V4 File detail (block graph + block list with summary expansion) | ✅ | `frontend/src/routes/p.$P.files.$file.tsx` + `backend/routes/files.py` | Backend hybridizes SQLite summaries with parser blueprint (so the graph renders even before V3.3 reaches that file). Variable links jump to V7. |
| 5b.6 | Code-split graph route (lazy import) | ✅ Done (2026-05-28) | `p.$P.files.tsx` + `p.$P.files.$file.tsx` | `Graph` (elkjs + xyflow) now loaded via `React.lazy()` with `<Suspense fallback={<Skeleton/>}>`; splits heavy libs out of initial chunk |
| 5b.7 | Playwright E2E | ✅ Done (2026-05-28) | `frontend/e2e/v5_6_no_console_errors.spec.ts`, `v7_4_explain_more.spec.ts`, `v9_1_happy_path.spec.ts` | 3 spec files; `playwright.config.ts` configured; covers console-error check + investigation + full happy-path (LLM included) |

### Phase 5c — Chat + Investigation (V6+V9+V10) ✅ Done (2026-05-28)

### Phase 5d — Variable investigation (V7+V8) ✅ Done (2026-05-28)

---

## Phase 6 — forward_traversal (Strategy B + Track A in progress)

### 6a — Wrapper shipped ✅

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 6a.0 | Research round + audit (Q-P6a/b/c) | ✅ | `docs/p6_research.md`, `docs/p6_gap_analysis.md` | Strategy B (wrap) chosen |
| 6a.1 | `forward_traversal/runner.py` — `run_forward_only(process, variable, ...)` | ✅ | | Process-scope filter, partitioned output |
| 6a.2 | `forward_traversal/validate.py` — Rule-6 source gate | ✅ | | Catches blank-line / comment-line / out-of-range / missing-source |
| 6a.3 | `/demo/v1/processes/{P}/variables/{V}/usage-flows` endpoint | ✅ | `backend/routes/forward.py` | Synchronous POST; cached to `data/forward_traces/<P>/<V>/` |
| 6a.4 | Unit tests (mocked + real-tracer smoke) | ✅ | `backend/tests/test_forward.py` | 3 tests; suite 34/34 |
| 6a.5 | V_FWD baseline live validation (Q-P6c) | ✅ | `scripts/validate_forward_baseline.py`, `docs/v_fwd_baseline.json` | 3 vars; 100% parser setter coverage; 0 out-of-scope |
| 6a.6 | README | ✅ | `forward_traversal/README.md` | |
| 6a.7 | V6.4 live usage-flows endpoint validation | ✅ | `scripts/validate_v6_v7.py`, `docs/v6_v7_validation.json` | ASM (WB1SW6, xh80.asm): 2499 nodes / 961 setters / 439 dep_vars. C++ (bcis, dx740200.cpp): 300 GVL nodes / 33 cross-file calls. Field-shape + non-empty checks both pass. |

### 6-Track-A — ASM polish (G6/G7/G8/G10/G13/G14/G16) 🔄

| # | Gap | Item | Status |
|---|---|---|---|
| 6.G10 | G10 | Two-pass dep-var BFS depth=2 | ✅ Wrapper-side BFS with max_dep_vars=20 cap |
| 6.G10b | — | Parser-universe fallback for dep_var declaration lookup (EF-1 narrow inventory miss) | ✅ |
| 6.G6 | G6 | Subroutine expansion + call-graph merging | ✅ `forward_traversal/expand.py::expand_subroutines`; max_subroutine_depth + max_subroutine_nodes caps from backward; live: WB1SW6 expanded 43 call sites / 400 body nodes |
| 6.G7 | G7 | Richer full-flow graph collector | ✅ Done (2026-05-28) | `forward_traversal/runner.py` lines 633–696 | `_enrich_nodes()` adds G7 fields; `_build_cross_file_edges()` builds call-flow edges; cross-file metadata + subroutine callee blocks included |
| 6.G8 | G8 | 4-level subroutine resolver (read-only import from backward_traversal.utils) | ✅ Used inside expand.py — `resolve_subroutine_target` + `extract_subroutine_target` |
| 6.G13 | G13 | Instruction glossary (64-bit variants) | ✅ `expand.py::classify_instructions`; tags every node with `inst_class` from backward's `SETTER_INST`/`TRIGGER_INST`/`BRANCH_INST`/`SUBROUTINE_CALL_OPCODES`/`RETURN_OPCODES`/`CROSS_FILE_INST`. Live: 1925/2099 (92%) of nodes tagged. |
| 6.G14 | G14 | Special-case patterns (OC+BZ self-zero) | ✅ Done (2026-05-28) | `forward_traversal/expand.py::reclassify_oc_bz_patterns()` | Detects OC self-zero + BZ pairs within 2 lines; reclassifies OC as CONDITION_TEST, BZ as BRANCH_ON_CONDITION |
| 6.G16 | G16 | Cached blueprint I/O + retry | ✅ Done (2026-05-28) | `forward_traversal/blueprint_cache.py::load_blueprint()` | LRU cache (maxsize=512); 3 retries on OSError; graceful {} on missing/bad JSON |

### 6-Track-B — C++ layer 🔄

| # | Gap | Item | Status |
|---|---|---|---|
| 6.G1.audit | — | Mechanics audit of backward cpp_backward_tracer + cross_file_bridge + cpp_lineage_utils + variable_name_resolver + cpp_source_utils | ✅ inline in this DEV_TRACKER + p6_gap_analysis |
| 6.G1 | G1 | **C++ GVL forward tracer** — BFS over outgoing edges, depth weights mirror backward (assign/define/arg_bind +1, ecb_bridge/ce1cr_level_bridge +2, alias 0), terminal kinds (literal/memory/clobbered), register-bridge marker `forward_to_asm:RN` | ✅ `forward_traversal/cpp_forward_tracer.py`; multi-seed merge mirrors backward FIX-4/7/8; live-tested on `bcis`/`LwrPtr`/`casGlosInputMessage` |
| 6.G1.dispatch | — | Runner dispatches `.cpp`/`.hpp`/`.h` declarations to the C++ tracer | ✅ `forward_traversal/runner.py::run_forward_only` branches on file extension |
| 6.G5 | G5 | C++ field/register alias extraction — `extract_asm_field_aliases`, `extract_tpf_regs_slots` | ✅ READ-ONLY import from `backward_traversal.utils.cpp_lineage_utils` |
| 6.G1.seed | — | Seed discovery — 5 strategies (`metadata.asm_alias`, field-alias suffix, cpp_field_to_asm stitching, TPF_regs cpp_sources, direct name match) | ✅ READ-ONLY import of `find_cpp_seed_nodes` |
| 6.G2 | G2 | 4 cross-file CALLEE finders (forward analog of caller-finders): `find_cpp_to_cpp_callees`, `find_asm_callees`, `find_asm_to_cpp_callees`, `find_cpp_to_asm_callees` | ✅ `forward_traversal/callee_finders.py`; 19 unit tests; returns `{callee_file, callee_entry_block, edge_type}` per outgoing edge |
| 6.G4 | G4 | VariableNameResolver — 4-strategy alias resolution (ASM↔C++ field, arg_bind T10, struct canonical T11, canonical_name T12) | ✅ `forward_traversal/runner.py::_resolve_dep_var_aliases`; alias entries written to dep_var JSON with `alias_of` / `aliases` fields; graceful fallback if resolver can't init; 7 tests |
| 6.G9 | G9 | C++ function source extraction | ✅ Done (2026-05-28) | `frontend/src/routes/p.$P.files.$file.tsx` — `source_snippet` shown in collapsible block detail (pre block, max-h-48, scrollable) | Backend already populated source_snippet in files.py; UI now renders it |

### 6-Track-C — Scale/resumability (G3/G12/G15) ✅ Done (2026-05-28)

| # | Gap | Item | Status | Artifact |
|---|---|---|---|---|
| 6.G3 | G3 | Content-hash resumability (session state machine) | ✅ Done (2026-05-28) | `forward_traversal/runner.py` — `_compute_trace_hash()` + SQLite `process_artifact` cache check/write; skips re-run when hash unchanged |
| 6.G12 | G12 | Output partition refinement — per-file results inside dep_var | ✅ Done (2026-05-28) | `forward_traversal/runner.py` — G12 node-count cap; env var `FT_MAX_NODES` overrides default 50k; truncated flag in manifest |
| 6.G15 | G15 | Non-fatal blueprint consistency diagnostics | ✅ Done (2026-05-28) | `forward_traversal/runner.py` — G15 visited-set cap; warnings emitted to `warnings.json`; never aborts the run |

---

## Phase 7 — Chunked SSE investigation + V9 ✅ Done (2026-05-28)

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 7.1 | SSE infrastructure (`backend/sse.py`) | ✅ Done (2026-05-28) | `backend/sse.py` | `sse_event(data, event)` + `sse_keepalive()` pure string formatters |
| 7.2 | Iteration plan derived from variable_context table | ✅ Done (2026-05-28) | `backend/pipeline/investigation_planner.py` | Reads `up_contexts_json`/`down_contexts_json`; groups by BFS depth; caps at 10 iterations; returns [] if no variable_context row |
| 7.3 | `POST /processes/{P}/variables/{V}/investigation/{direction}` SSE endpoint | ✅ Done (2026-05-28) | `backend/routes/variables.py::stream_variable_investigation` + `_investigation_stream` | Events: start/iteration/done/error; keepalive every 5; direction validated (400); uses sse.py helpers |
| 7.4 | Frontend V8 (chooser) + V9 (chunked rendering with "Explain more") | ✅ Done (2026-05-28) | `frontend/src/routes/p.$P.v.$V.tsx` | "Trace lineage" section; ← Trace backward / Trace forward → buttons; inline panel with iteration cards; "Explain more" button; "Complete" badge on done; error display |
| 7.5 | Source chip → side panel showing raw source snippet | ✅ Done (2026-05-28) | `backend/routes/variables.py::get_variable_source` + `frontend/src/routes/p.$P.v.$V.tsx::SourcePanel` | `GET .../variables/{V}/source` returns file/line/snippet/language; ±10 lines; highlight-line CSS class on declaration line; 404 if not found |

---

## Phase 8 — Retrieval / QA + chat surfaces (Q-S2 Adaptive RAG)

### 8.0 — Agentic chat MVP ✅ (live with real Gemini)

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 8.0.1 | 6-tool catalog (process/file/block/variable getters) | ✅ | `backend/agent/tools.py` | All read SQLite + file_graph.json; no LLM dependency |
| 8.0.2 | ReAct loop with strict ``exactly-one-action`` AgentStep validator | ✅ | `backend/agent/loop.py`, `backend/schemas/agent.py` | Pydantic enforces tool_call OR final_answer |
| 8.0.3 | SYSTEM + USER_ENVELOPE prompts (business-language rules, max 8 iters) | ✅ | `backend/agent/prompts.py` | |
| 8.0.4 | `POST /demo/v1/processes/{P}/chat` SSE endpoint | ✅ | `backend/routes/chat.py` | Streams thought / tool_call / tool_result / answer / done / error |
| 8.0.5 | History rendering: recent-2 turns full, older truncated | ✅ | `loop.py::_render_history` | Empirically fixed after live test where 600-char cap misled the model |
| 8.0.6 | 11 unit tests (dispatch, validator, SSE shape, mocked ReAct flow) | ✅ | `backend/tests/test_agent.py` | |
| 8.0.7 | Live Gemini smoke: variable question → 2-iter answer with cited sources | ✅ | (recorded in `backend/agent/README.md`) | |

### 8.1 — Chunk retrieval ✅ (live, partial data; auto-fills as V3.3 finishes)

| # | Item | Status | Notes |
|---|---|---|---|
| 8.1.1 | Chunk builder: writes block/file/variable rows into `chunk_fts` with `context_prefix + body` (Anthropic contextual-retrieval pattern) | ✅ | `backend/retrieval/index.py::rebuild_chunk_index_for_process`. 935 chunks written for C400 (709 blocks + 226 variables; file/process pending V3.3 finish) |
| 8.1.2 | BM25 query via `chunk_fts MATCH ? ORDER BY bm25()` | ✅ | `backend/retrieval/search.py::search_chunks_bm25` |
| 8.1.3 | `search_chunks(process, query, top_k)` tool added to agent catalog | ✅ | `backend/agent/tools.py` |
| 8.1.4 | LLM rerank over top-K BM25 hits | ✅ | `backend/retrieval/rerank.py::rerank_chunks`; wired into `tools.py::search_chunks` with `use_rerank=True` flag; graceful BM25 fallback on error; 2 tests |
| 8.1.5 | V_RAG live validation: hits show relevant kinds for "credit limit maintenance" query | ✅ | live: top-5 hits for "credit limit maintenance message" returned msgLength1 + casGlosOutputMessage + casGlosInputMessage |

### 8.2 — Variable-scoped chat ✅

| # | Item | Status | Notes |
|---|---|---|---|
| 8.2.1 | `POST /processes/{P}/variables/{V}/chat` SSE; agent receives a "Variable focus: V" pre-question prefix and uses the same tool catalog | ✅ | `backend/routes/chat.py::variable_chat`; frontend V10 at `/p/$P/v/$V/chat` |
| 8.2.2 | M1..Mk seeding from investigation thread (so chat picks up where the chunked explanation left off) | ✅ Done (2026-05-28) | `backend/routes/variables.py::_investigation_stream` writes each iteration to `investigation_message` table; `backend/routes/chat.py::_load_investigation_context` reads and injects as `prior_context` into `run_agent()` | flow_id=uuid4 per stream; INSERT OR IGNORE; non-fatal on DB error; capped at 10 messages |

---

## Phase 9 — Polish 🔄

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 9.1 | README per directory | ✅ Done (2026-05-28) — all dirs covered | `backend/retrieval/README.md` added (2026-05-28); all other dirs had READMEs already | |
| 9.2 | End-to-end backend smoke (every endpoint) | ✅ | `scripts/e2e_smoke.sh` | 12/12 endpoints green on 2026-05-27 |
| 9.3 | Build for second process (C112) to confirm portability | ✅ | `data/processes/C112/{file_graph,headers,macros,metadata}.json` | 19 files / 24 edges / same generator, zero code change |
| 9.4 | Deployment notes (`backend/DEPLOY.md`) | ✅ Done (2026-05-28) | `backend/DEPLOY.md` | Covers prerequisites, quick start, env vars, production notes |
| 9.5 | FU-CACHE-FILE — file-pass content hash not byte-stable across runs | ✅ | `runner.py` — three `.strip()` normalizations; SQLite trailing-whitespace was root cause; file-pass now produces byte-stable prompts; 3 tests |
| 9.6 | FU-CACHE-PROCESS — process-pass summary not content-hash cached | ✅ | `runner.py` + `schema.sql` + `db.py` — `content_hash` column added to `process` table; process summary fully cached on no-op rerun; 3 tests |

---

---

## Phase 10 — Celery / Redis infrastructure ✅

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 10.1 | `backend/celery_app.py` — 3-queue topology (q_emit/q_io/q_llm), global settings (prefetch=1, max_tasks_per_child=5, soft/hard limits 47h/48h), all task_routes, failure/revoked signal handlers writing Redis status | ✅ | `backend/celery_app.py` | §19.5 mandate |
| 10.2 | `backend/redis_client.py` — single connection pool, `get_redis()` entry point, pool capped at `REDIS_MAX_CONNECTIONS` (default 20) | ✅ | `backend/redis_client.py` | §19.5.6 |
| 10.3 | `backend/config.py` — `REDIS_URL`, `REDIS_MAX_CONNECTIONS`, `CELERY_BROKER_URL`, `CELERY_RESULT_BACKEND` settings | ✅ | `backend/config.py` | |
| 10.4 | `backend/embedding.py` — Rule 1-E single entry point, `call_embedding(texts)`, batch=250, ThreadPoolExecutor(4), LRU cache 100 | ✅ | `backend/embedding.py` | text-embedding-004, 768-dim |
| 10.5 | `backend/pipeline/macro_business_map.py` — all IBM z/TPF macros → business phrases (DB_OP_MAP, FILE_IO_MAP, STORAGE_MAP, TX_MAP, SPAWN_MAP, LINKAGE_MAP), `translate_macro()` helper | ✅ | `backend/pipeline/macro_business_map.py` | §4.5.3 two-tier translation |
| 10.6 | `backend/pipeline/translate.py` — `translate_to_business_language(text, process)`, two-tier resolution (primary: entity_business_name + variable_context → fallback: safe filler), per-process LRU cache (maxsize=2) | ✅ | `backend/pipeline/translate.py` | Never emits raw technical code |
| 10.7 | `backend/pipeline/condition_humanizer.py` — post-Phase-3 pass, deduplicates guard expressions, batches 20/LLM call, `humanize_guards(process)`, `get_humanized_guard()` read path | ✅ Updated 2026-05-28 — added §11.5 retrieval-augmented few-shot from `chunk_embedding` (kind='block') via `nearest_chunks(...)`. **Also fixed broken SQL** (call_edge_guard has no `process` column; humanize_guards/get_humanized_guard now JOIN `call_edge` on `edge_id`). Dedup-by-text BEFORE LLM and batch=20 confirmed by `test_phase1_static_gaps::test_guard_humanizer_dedups_by_text_before_llm` and `test_guard_humanizer_batch_size_is_20` | `backend/pipeline/condition_humanizer.py`; `backend/tests/test_phase1_static_gaps.py` | §8 lines 2241-2257, single-call-LLM checkpoint #3 |
| 10.8 | `backend/pipeline/complexity.py` — 8 metrics (M1-M8) via SQL queries, composite score 0-100, `compute_complexity_metrics()` + `persist_complexity_metrics()` | ✅ Audited 2026-05-28 — all 8 metrics, thresholds, and composite formula match §4.6 exactly. New unit tests in `test_complexity_and_classification.py` pin thresholds & math. **Also fixed broken SQL on `call_edge`** (no such column: source_file / target_file / condition_expression — schema.sql uses `from_file`/`to_file`; conditional branches live in `call_edge_guard` joined on `edge_id`). Fix at `backend/pipeline/complexity.py:46-58` (M3 BFS) + `:118-126` (M5 conditional branches) + `:135-143` (M7 cross-file). New regression test `test_persist_complexity_metrics_runs_against_empty_db` in `test_complexity_and_classification.py:71-101` | `backend/pipeline/complexity.py`; `backend/tests/test_complexity_and_classification.py` | §4.6 |
| 10.9 | `backend/tasks/__init__.py` + `backend/tasks/build_task.py` — `run_full_pipeline`, `run_variable_pipeline`, phase sub-tasks, Redis HSET progress, SoftTimeLimitExceeded handling | ✅ | `backend/tasks/` | §19.5.2-3 |
| 10.10 | `backend/routes/build.py` — Celery 202 retrofit: `task_id` in response, `_try_celery_build()` with threading fallback, `GET /build/status/{task_id}` Redis poll endpoint | ✅ | `backend/routes/build.py` | §19.5.2 |

---

## Phase 11 — Phase 1 static analysis ✅ Done (2026-05-28)

### 11a — Call graph + guard extraction

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 11a.1 | `parent_adapters/call_graph_adapter.py` — wrap `file_call_graph.py`; emit `call_edge` rows with `call_type`, `source_language`, `target_language`, `is_cross_language`, `is_async`, `is_suspend` | ✅ | `backend/pipeline/parent_adapters/call_graph_adapter.py` | §9; 332 rows for C400; idempotent |
| 11a.2 | `parent_adapters/guard_adapter.py` — wrap `get_call_conditions.compute_call_conditions()`; emit `call_edge_guard` rows keyed to call_edge rows | ✅ Done (2026-05-28) | `pipeline/parent_adapters/guard_adapter.py` | §8; wired into Phase 1 in build_task |
| 11a.3 | `parent_adapters/block_flow_adapter.py` — wrap `call_graph/topological_block_flow.py` + `call_graph/cross_file_flow.py`; intra-file block-level edges with guard context | ✅ Done (2026-05-28) | `backend/pipeline/parent_adapters/block_flow_adapter.py` | §4.1; uses enumerate_file() intra_file_callees; call_type='intra-file'; wired into Phase 1 |
| 11a.4 | `parent_adapters/guarded_file_calls_adapter.py` — wrap `process/extract_process_guarded_file_calls.py`; validate guards against ASM/C++ source (Rule 6) | ✅ Done (2026-05-28) | `backend/pipeline/parent_adapters/guarded_file_calls_adapter.py` | §4.1; emits call_edge_guard rows guard_kind='process-gate'; graceful skip if blueprint dir missing |
| 11a.5 | Audit + verify §16 table scripts: `conditional_parser`, `conditional_evaluator`, `instruction_classifier`, `operation_classifier`, `find_call_conditions`, `get_call_conditions` — status VERIFIED/NEEDS-FIX/PARTIAL/REPLACE per §16 workflow | ✅ Done (2026-05-28) | `docs/phase1_audit_table.md` | §16 |

### 11b — Variable identity + alias extraction

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 11b.1 | `parent_adapters/variable_lineage_adapter.py` — wrap `passes/variable_lineage_builder.py` + `passes/global_lineage_stitcher.py`; populate `variables_touched_json` on existing `variable` table + enrich for Phase 4 | ✅ Done (2026-05-28) | `backend/pipeline/parent_adapters/variable_lineage_adapter.py` | §4.1; reads blueprint global_variable_lineage nodes/edges; emits variable rows + updates block.variables_touched_json |
| 11b.2 | `parent_adapters/variable_identity_adapter.py` — wrap `build_variable_identity_index.py` + `fixes/phase_equivalent_variable_resolution/`; emit `variable_alias` rows (5 kinds: cpp-asm, ecb-field, struct-field, equivalent-5layer, register-bridge, getcc-pointer, dbifb-context) | ✅ Done (2026-05-28) | `backend/pipeline/parent_adapters/variable_identity_adapter.py` | §4.4 Step 1; loads/builds variable_identity_index.json; emits cross-file alias pairs |
| 11b.3 | `parent_adapters/ecb_alias_adapter.py` — wrap `passes/ecb_alias_table.py` + `fixes/phase6_ecb_mapping/`; emit `ecb_alias` rows | ✅ Done (2026-05-28) | `backend/pipeline/parent_adapters/ecb_alias_adapter.py` | §5.5; imports ECB_FIELD_TO_ASM static table; emits ecb_alias rows + variable_alias rows with alias_kind='ecb-field' |
| 11b.4 | `parent_adapters/cross_language_alias_adapter.py` — wrap `passes/cross_file_access_identity.py` + `fixes/phase4_cross_language_alias_edges/` + `trace_cpp_to_asm.py` + `get_equivalent_variable.py`; emit cross-language variable aliases | ✅ Done (2026-05-28) | `backend/pipeline/parent_adapters/cross_language_alias_adapter.py` | §4.1; reads blueprint nodes with ecb_field metadata + ECB table; emits variable_alias alias_kind='cpp-asm' |
| 11b.5 | `parent_adapters/connected_variables_adapter.py` — wrap `find_connected_variables.py` (4 types: call_boundary_registers, return_registers, shared_dsects, shared_memory_fields) + `map_connected_variables.py` (3 mapping types: call_boundary_register, return_register, shared_memory_field; MAX_WALK_DEPTH=3) | ✅ Done (2026-05-28) | `backend/pipeline/parent_adapters/connected_variables_adapter.py` | §4.1 + §4.4 Steps 2&3; processes call_edge cross-file pairs; ThreadPoolExecutor 4 workers |

### 11c — I/O site detection + utility classification

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 11c.1 | `backend/pipeline/io_detector.py` — Layer 1 IBM-pattern hard rules: scan ASM for 40+ DB macros (DBRED/DBWRT/DBADD/DBMOD/DBDEL/DBOPN/DBCLS/DBKEY/DBIFB/DBCKP/etc.); extract REF= target_record; commit scope detection (TXBGC/TXCMC/TXRBC/TXSPC/TXRSC); blueprint block lookup | ✅ | `backend/pipeline/io_detector.py` | §4.1.1 L1; 53 io_site rows for C400; 0 commit scopes (C400 has none); idempotent |
| 11c.2 | `backend/pipeline/io_detector.py` — Layer 2 structural heuristics (H1–H13) | ✅ Done (2026-05-28) | `backend/pipeline/io_detector.py::run_phase1_l2` | H1–H13 implemented; wired into build_task Phase 1 |
| 11c.3 | Subfile session chaining: group `io_site` rows by `target_ref` between DBOPN and DBCLS; emit `subfile_session` rows | ✅ | `backend/pipeline/lifecycle_detector.py::chain_subfile_sessions()` | §5.1; run after io_detector |
| 11c.4 | Storage lifecycle: scan for GETCC/RELCC/GETFC/RELFC/RCRFC/DETAC/ATTAC/FINDC/FINHC/FINWC/FIWHC/FILEC; emit `storage_lifecycle` rows; pair GETCC↔RELCC within same file | ✅ | `backend/pipeline/lifecycle_detector.py::detect_storage_lifecycle()` | §5.2; 76 events for C400; GETCC/RELCC paired |
| 11c.5 | Commit scope detection: scan for TXBGC/TXCMC/TXRBC/TXSPC/TXRSC (ASM) and tx_begin/tx_commit/tx_rollback (C++); emit `commit_scope` rows; mark `end_kind` (commit/rollback/suspend/unclosed) | ✅ Done (2026-05-28) | `backend/pipeline/io_detector.py::detect_commit_scopes()` + `run_phase1_static()` | §5.4; ASM TX macros + C++ tx_ equivalents both handled; wired into Phase 1 task |
| 11c.6 | `backend/pipeline/utility_classifier.py` — 7-layer utility detection: L0 8 path/build signals, **L1 10 numbered rules** (R1 no-persistence, R2 no-transaction, R3 no-async-spawn, R4 no-business-type, R5 no-commit-scope, R6 generic-op density, R7 high-fan-in via cross_process_call_index, R8 pure (no global/ECB write), R9 cross-process ≥3 callers, R10 no-control-flow-influence on persistence), L2 6 naming heuristic categories, L3 cross-process index, L3.5 LLM (via call_llm_model), L5 manual override; `classify_all_blocks()` + `get_utility_confidence()` read path | ✅ Updated 2026-05-28 — rewrote `_classify_l1` to emit all 10 design-numbered rules; signals carry stable `L1-R{N}:...` labels for downstream audit; 788 rows for C400; 10-rule presence pinned by `test_phase1_static_gaps::test_utility_classifier_implements_10_l1_rules` | `backend/pipeline/utility_classifier.py` | §4.1.2 lines 298-540 (8 L0 / 10 L1 / 6 L2 / L3 ≥3 / L3.5 A+B) |
| 11c.7 | `cross_process_call_index` table population — scan all process file graphs to build codebase-wide callee→caller index; runs once per codebase build; used by L3 utility detection | ✅ Done (2026-05-28) | `pipeline/cross_process_index.py` | 50 rows for C400+C112; wired at end of run_full_pipeline |

### 11d — Misc static adapters

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 11d.1 | `parent_adapters/macro_expansion_adapter.py` — wrap `passes/macro_expansion_pass.py` + `macro_expander.py` + `macro_library.py`; confirm runs BEFORE `call_graph_builder` (§16 audit gap) | ✅ Done (2026-05-28) | `backend/pipeline/parent_adapters/macro_expansion_adapter.py` | §9.5; reads blueprint macro_expansions list; enriches block.calls_json with macro invocations |
| 11d.2 | `parent_adapters/enum_resolver_adapter.py` — wrap `fixes/phase5_enum_value_resolution/` + `fixes/phase5b_enum_conditional_tracking/`; needed for human-readable guards | ✅ Activated 2026-05-28 — upstream `fixes/phase5_enum_value_resolution/` patch is APPLIED; `temp/output_latest/asm/cclg1g1.hpp.json` and `dx740200.cpp.json` each carry 23 populated `enum_values` entries. Adapter rewritten to (a) scan `.cpp/.hpp/.h` blueprints in addition to `.asm/.mac`, (b) walk `headers.json` for #include'd C++ headers not in `file_graph.files`, (c) read the new `{enum_type, value}` dict shape. **C400 now emits 23 `equivalent-5layer` rows** (AddLimit→'A', PersonalCard→'P', C400→'D', etc.) into `variable_alias`. Verified by `test_phase1_static_gaps::test_enum_resolver_adapter_emits_rows_for_c400` | `backend/pipeline/parent_adapters/enum_resolver_adapter.py`; `backend/tests/test_phase1_static_gaps.py` | §8 — feeds guard-humanizer few-shot |
| 11d.3 | `parent_adapters/literal_resolver_adapter.py` — wrap `literal_resolver.py`; used by §9.6 ASM indirect branch resolver | ✅ Done (2026-05-28) | `backend/pipeline/parent_adapters/literal_resolver_adapter.py` | §9.6; uses LiteralResolver to resolve =V/=A literals from block flow args; emits variable_alias rows |
| 11d.4 | Audit §16 table remaining scripts: `passes/data_flow_tracker.py`, `passes/c_family_parser.py`, `cross_file_bridge.py`, `cpp_call_chain/traversal.py`, `cpp_call_chain/index_builder.py`, `cpp_call_chain/source_scanner.py`, all `fixes/` directories — per §16 workflow | ✅ Done (2026-05-28) | `docs/phase1_audit_table.md` | §16 |
| 11d.5 | Phase 1 runner integration: wire call_graph_adapter, io_detector, lifecycle_detector, utility_classifier into `run_full_pipeline` Celery task before Phase 2 | ✅ | `backend/tasks/build_task.py` | §19.5.1; Phase 1 now runs before Phase 2 in the task |

---

## Phase 12 — Phase 3 top-down walk ✅ Done (2026-05-28)

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 12.1 | `backend/pipeline/walker.py` — BFS from `process_meta.entry_json`; fallback to first block of seed file if no `process_meta`; reads `block_utility_classification.utility_confidence` (query per block, not re-running detector); skips blocks with `uc >= 0.9`; force-keeps any block with a Layer-1 `io_site` row | ✅ Done (2026-05-28) | `backend/pipeline/walker.py` | §4.3 |
| 12.2 | `walker.py` — single `call_llm_model(ProcessWalkDecision)` per surviving block; captures `role` (14 status values), `inputs_consumed`, `outputs_produced`, `transformations`, `relevant_children`; sequential on `q_llm` | ✅ Done (2026-05-28) | same | §4.3 one LLM call per block |
| 12.3 | `walker.py` — emit `walk_node` rows: walk_id, file, block, parent_walk_id, status, role_in_process, inputs_consumed, outputs_produced, condition_to_reach, commit_scope_id, depth | ✅ Done (2026-05-28) | same | §11 schema |
| 12.4 | `walker.py` — cross-language 8 patterns for callee resolution (ASM→ASM via ENTRC/BAL/BAS/CREEC, ASM→C++ via CALLC/CPROC/ENTxC, C++→ASM via CALL_ALIAS, C++→C++ via call/method/virtual); uses call_edge.call_type + is_cross_language | ✅ Done (2026-05-28) | same | §4.3, §9; patterns resolved via call_edge table |
| 12.5 | `walker.py` — safety caps: `MAX_WALK_NODES=1500` (per-process override from `process_meta.limits_json`), `MAX_DEPTH=10`, cycle detection on `(file, block)`, per-`(file, block)` revisit cap=10; write to `walk_truncation` log on any truncation | ✅ Done (2026-05-28) | same | §4.3 |
| 12.6 | `process_meta` table — `populate_process_meta()` in walker.py: derives entry_json from file_graph.json seed_file+seed_function; called in build_task Phase 3 before walk | ✅ Done (2026-05-28) | `walker.py::populate_process_meta()` | §7; C400 entry: temp/asm/lu82.asm::LU8X100 |
| 12.7 | condition_humanizer pass wired post-Phase-3 in `run_full_pipeline` | ✅ | `backend/tasks/build_task.py` | Already in task; humanizer.py complete |
| 12.8 | L3 I/O site LLM classifier (Phase 1e) — runs AFTER Phase 3 completes; gate: L1+L2 missed AND block is on data-path walk_node AND has write-like signal; retrieval-augmented few-shot from `chunk_embedding`; emit `io_site` rows with `detection_layer='L3-llm'`; bounded ~50-200 calls/process | ✅ Updated 2026-05-28 — switched chunk-context retrieval from BM25-only to `nearest_chunks()` (chunk_embedding cosine ANN) with BM25 fallback when sqlite-vec unavailable | `backend/pipeline/io_detector.py::run_l3_io_classifier()` | §4.1.1 L3; §11.5 |
| 12.9 | L3.5 utility verification pass — runs after L0-L3 complete, before Phase 3; Trigger A (L2-only blocks): retrieval-augmented few-shot (k=3 known-utility + k=3 known-business from `block_embedding`); Trigger B (io_site on classified-utility block safety net); update `block_utility_classification` rows | ✅ Updated 2026-05-28 — replaced no-embedding prompt with `nearest_blocks()` cosine ANN over `block_embedding` (k=3 utility + k=3 business). Also fixed `call_llm_model` arg-order bug (was `(model, prompt)`) | `backend/pipeline/utility_classifier.py::_classify_l35_llm()` | §4.1.2 L3.5; §11.5 |
| 12.10 | Multi-entry process support — `process_meta.entry_json` may be a single dict OR a list of dicts per DESIGN §7 "Multi-entry processes". Walker enumerates each list element as a distinct walk root in list-index order; per-entry `condition` field (e.g. `"msg_type == 'AFTERGL'"`) is propagated into `walk_node.condition_to_reach` of the root node so Phase 5 `_build_trigger_summary` tags each enumerated flow with the dispatcher predicate. Walker accepts both canonical shape (`file`+`routine_or_function`+`condition`) and short shape (`file`+`block`) for backward compat with `populate_process_meta()`. Falls back to `file_graph.json` seed if no `entry_json` present. | ✅ Done (2026-05-28) | `backend/pipeline/walker.py:335-389` (walk_process entry-loading + queue seeding); `backend/pipeline/synthesis.py:191-200` (_build_trigger_summary picks up per-entry condition from root walk_node); `backend/routes/walk.py:108-131` (GET /entry already returns list); test in `backend/tests/test_walker_multi_entry.py` (3 cases: list-of-2 → 2 roots tagged with conditions, single dict still works, short `{file, block}` shape) | §7 lines 2137-2167 multi-entry locked addition |

---

## Phase 13 — Phase 4 variable context ✅ Done (2026-05-28)

### 13a — Step 1-3: deterministic context collection

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 13a.1 | `backend/pipeline/variable_context_pipeline.py` — Step 1 anchor scan: for declared variables scan declaration file `variables_touched_json`; for block-ref variables scan ALL process files; collect role, guards, io_site rows, commit_scope context, storage_lifecycle events, call_edge_guard rows where variable is operand | ✅ Done (2026-05-28) | `backend/pipeline/variable_context_pipeline.py` | §4.4a Step 1 |
| 13a.2 | Step 2 — 1 level DOWN (callees): for each outgoing `call_edge` from anchor block, detect if variable flows across using `find_connected_variables` + `map_connected_variables`; covers all 8 downward cross-language patterns (§4.4a); collect what_happens, conditions, io_ops, flows, checks, mandatory flag | ✅ Done (2026-05-28) | same | §4.4a Step 2 |
| 13a.3 | Step 3 — 1 level UP (callers): for each incoming `call_edge` into anchor file, collect how variable is prepared in caller call-site block; covers all 8 upward cross-language patterns including return-register UP perspective; collect conditions_for_setting, how_set, mandatory, business_context, flow_context | ✅ Done (2026-05-28) | same | §4.4a Step 3 |

### 13b — Step 4: LLM synthesis + classification

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 13b.1 | Step 4 — single `call_llm_model` per variable: 6-question framework (Q1 purpose, Q2 computation_source, Q3 availability, Q4 persistence_effects, Q5 flow_variations, Q6 business_flow_context); includes `coverage` object per question (full/partial/not_found); parallel via `ThreadPoolExecutor(8)` on `q_llm` | ✅ Done (2026-05-28) | same | §4.4a Step 4 |
| 13b.2 | `variable_context` table population: anchor_blocks_json, down_contexts_json, up_contexts_json, all 6-question fields, availability_condition, coverage_json, content_hash | ✅ Done (2026-05-28) | | §11 schema |
| 13b.3 | `variable_classification` table — 5-label multi-label classifier (business/process-io/persistence/control/infrastructure + is_unused boolean); retrieval-augmented few-shot from `variable_context_embedding` (k=5 nearest classified variables); deterministic signals first, LLM confirms | ✅ Updated 2026-05-28 — gate is now measurable: explicit "skipped LLM (deterministic confidence X)" vs "invoked LLM" log lines; added §4.4b few-shot retrieval via `nearest_variables()` cosine ANN over `variable_context_embedding`. Pinned by new tests `test_variable_classification_skips_llm_when_deterministic` + `..._invokes_llm_when_ambiguous` | `backend/pipeline/variable_classification.py::_classify_one()` | §4.4b; §11.5 |
| 13b.4 | `variable_meaning` table — derived write from `variable_context.purpose` via SQL INSERT-SELECT; NO extra LLM call (no-duplicate-LLM rule §2); pipeline writes after Step 4 completes | ✅ Done (2026-05-28) | | §11; no-duplicate-LLM mandate |
| 13b.5 | `?label=` filter wired into `GET /variables` endpoint; reads from `variable_classification` table | ✅ Done (2026-05-28) | `backend/routes/variables.py::list_variables()` | §12; JOIN to variable_classification on label; 400 on invalid label; 0 TSC errors |
| 13b.6 | `variable_context_embedding` population: after Step 4, embed `purpose` + `business_flow_context` + top-3 labels via `call_embedding()`; store as BLOB in `variable_context_embedding` table | ✅ Done (2026-05-28) | | §11.5; Rule 1-E; inline with Step 4 |
| 13b.7 | `block_embedding` population: after Phase 3 walk completes, embed Phase 2 block purpose + Phase 3 role for each walk_node block; store in `block_embedding` table; used by L3.5 utility few-shot | ✅ Done (2026-05-28) | `backend/tasks/build_task.py` Phase 3b (inline SQL + call_embedding) | §11.5; Rule 1-E; wired as Phase 3b; block_embed_count tracked in progress |

---

## Phase 14 — Phase 5 synthesis ✅ Done (2026-05-28)

### 14a — Flow enumeration + per-scope narrative

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 14a.1 | `backend/pipeline/synthesis.py` — input spec + output spec: deterministic extraction using Phase 1 io_site + entry block read-before-write / write-before-exit rules (§10.1/10.2); stored in `process_artifact` with artifact_kind `'input-spec'` / `'output-spec'` | ✅ Updated 2026-05-28 — expanded `_build_io_spec` to cover **all 6 §10.1 input categories** (register-passed-input, ecb-field-input, global-input, persisted-input, macro-parameter-input, storage-input) and **all 8+1 §10.2 output categories** (process-return-output, ecb-global-output, persisted-output, async-output, sync-spawn-output, storage-handoff-output, status-flag-output, error-output, commit-scope-output). Each entry carries a `language: asm | cpp` field so ASM/C++ variants are tracked separately. Built deterministically from `io_site` (persistence), `call_edge` (async/sync-spawn/return), `storage_lifecycle` (ATTAC/DETAC), `commit_scope` (TXCMC), `ecb_alias` (ECB fields), `variable_context.anchor_blocks_json` (entry-block reads), `variable.scope='global'` (globals), `walk_node` (error path, return). Verified by `test_phase1_static_gaps::test_io_spec_categories_are_all_declared_in_source` and `test_io_spec_runs_against_c400_without_error`. Live C400 result: 50 inputs / 87 outputs across 7 distinct categories | `backend/pipeline/synthesis.py`; `backend/tests/test_phase1_static_gaps.py` | §4.5 artifact 1+2; §10.1 (6 input cats); §10.2 (8+1 output cats) |
| 14a.2 | `synthesis.py` — flow enumeration: deterministic union of all_outputs(P) = return/ecb/persistence/async/queue/error/scope-commit/storage-handoff; for each output, exhaustive producer search + parent_walk_id path-trace; attach Phase 2 block summary + Phase 3 role + Phase 4 variable classification + Phase 1 guard/io_site rows; each flow = 1 row in `process_flow` table | ✅ Done (2026-05-28) | same | §4.5 artifact 3; deterministic |
| 14a.3 | `synthesis.py` — persistence summary: assembled deterministically from `io_site` rows grouped by `target_record` + `op_category`; stored in `process_artifact` with artifact_kind `'persistence-summary'` | ✅ Done (2026-05-28) | same | §4.5 artifact 4 |
| 14a.4 | `synthesis.py` — commit-scope summary: assembled deterministically from `commit_scope` rows; stored in `process_artifact` with artifact_kind `'commit-scope-summary'` | ✅ Done (2026-05-28) | same | §4.5 artifact 5 |
| 14a.5 | `synthesis.py` — per-scope narrative: one `call_llm_model` per `commit_scope` row; inputs = scope bounds + io_site rows inside + variable classifications + walk-node summaries; output = `{narrative, key_variables}`; parallel across scopes; stored in `commit_scope_narrative` table | ✅ Done (2026-05-28) | same | §4.5 artifact 6; §5.4; CommitScopeNarrativeOut in schemas/llm.py |

### 14b — Process narrative (3 LLM calls total)

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 14b.1 | `synthesis.py` — Section 1 Executive summary: 1 LLM call; inputs pre-translated via `translate_to_business_language()`; stored in `process_artifact` with artifact_kind `'narrative-executive-summary'` | ✅ Done (2026-05-28) — **also fixed `_get_process_row` SQL** which referenced a non-existent `process` column on the `process` table (PK is `(project_id, name)`); changed `WHERE process = ?` → `WHERE name = ?` at `backend/pipeline/synthesis.py:849-859`. New regression test `test_run_p14b1_executive_summary_uses_correct_process_column` in `test_complexity_and_classification.py:104-148` | same | §4.5.1; no-technical-names mandate |
| 14b.2 | `synthesis.py` — Section 2 End-to-end flow narrative: 1 LLM call; walk tree (compressed) + all flow trigger_summaries + condition_human values; stored as `'narrative-e2e-flows'` | ✅ Done (2026-05-28) | same | §4.5.1; most important section |
| 14b.3 | `synthesis.py` — Section 3 Variable landscape: 1 LLM call; top-N business/persistence variables by anchor_block count + variable_meaning + variable_context; stored as `'narrative-variable-landscape'` | ✅ Done (2026-05-28) | same | §4.5.1 |
| 14b.4 | `synthesis.py` — Section 4 Persistence footprint: assembled deterministically from persistence-summary + per-scope narratives; stored as `'narrative-persistence-footprint'`; no extra LLM call | ✅ Done (2026-05-28) | same | §4.5.1; free |

### 14c — Payload lineage chains (§4.5.2)

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 14c.1 | `synthesis.py` — payload lineage Step 1-4: root identification from Phase 4 `process-io` variables; flow participation; within-flow chain traversal (deterministic given Phase 3 data); cross-boundary resolution via `map_connected_variables.py` | ✅ Done (2026-05-28) | `backend/pipeline/payload_lineage.py` | §4.5.2 Steps 1-4; roots from variable_classification label='process-io'; flow scan via path_json; step filter by inputs_consumed/outputs_produced; cross-boundary via call_edge table |
| 14c.2 | `synthesis.py` — payload lineage Step 5: LLM identity confirmation for ambiguous name pairs only (`inputs_consumed` name ≠ `outputs_produced` name from prior step); binary yes/no per pair; SKIP if exact match (zero LLM calls for clean codebases) | ✅ Done (2026-05-28) | same — `_confirm_identity()` | §4.5.2 Step 5; IdentityConfirmation Pydantic schema; skipped for exact name matches |
| 14c.3 | `payload_lineage` table population: one row per (root_variable, flow); includes `steps_json`, `terminal_kind`, `terminal_target`, `terminal_io_site_id`, `content_hash` | ✅ Done (2026-05-28) | same — `build_payload_lineage()` wired into Phase 5c in build_task.py | §4.5.2; parallel via ThreadPoolExecutor(8); content_hash for deduplication |
| 14c.4 | **Rework (2026-05-29):** original 14c.1/2 did not implement the design — no `active_vars` propagation (literal root-name membership test per step) and `_confirm_identity` (Step 5) was dead code, so every C++ chain collapsed to 1 disconnected step. Rebuilt `_build_lineage_steps` with: propagating `active_vars` set; candidate nodes = root-consuming entry ∪ terminal call-tree ancestors ∪ terminal **data-dependency closure** (`_dependency_closure`) so sibling producers the call-tree path misses are included; single context-rich LLM bridge per gap (`_bridge_gap`, replaces pairwise) that never bridges into a second `process-entry`; each step tagged `match` = `exact`\|`inferred` for transparency. Also fixed `get_variable_lineage` 500 (passed `Query(None)` sentinel as `terminal_target`). plastic_authentication: 9 chains, ~64% exact hops. | ✅ Done (2026-05-29) | `backend/pipeline/payload_lineage.py`, `backend/routes/flows.py`, `frontend` narrative page + types | §4.5.2 |
| 14c.5 | **Upstream follow-up (not started):** root cause of remaining `inferred` hops is that Phase 3 walk emits free-form, name-inconsistent variable names per block (only ~24 of 137 input names have a producer in the walk). Complete fix = Phase 3 emits name-consistent / canonical variable identifiers (carry producer name forward, or resolve to a canonical variable id), making the data-flow graph connect deterministically with near-zero bridging. Bigger change (affects the walker for all processes; needs Phase 3 re-run). Deferred per user 2026-05-29. | ⏳ Deferred | Phase 3 walker (`backend/pipeline/walker.py`) | §4.5.2 "Variable name consistency — risky assumption" |
| 14c.6 | **Flow-format + root-resolution fixes (2026-05-29):** after the IO-fix rebuild, `process_flow.path_json` changed from bare walk-id ints to rich step dicts (no `inputs_consumed`/`outputs_produced` keys) → `_find_flows_for_variable` matched 0 flows → 0 chains for ALL processes. Fixed to resolve walk_id from either format. Also fixed `_get_process_io_variables`: it returned stale real-name `process-io` classifications that never appear in the walk vocabulary (C400 0-chains) → now returns entry `inputs_consumed` (walk-space) ∪ classified names that actually appear in the walk. Regression tests added for both. | ✅ Done (2026-05-29) | `backend/pipeline/payload_lineage.py`, `backend/tests/test_payload_lineage.py` | §4.5.2 |
| 14c.7 | **Walker fixes that unblocked C400 walk (2026-05-29):** C400 walk produced only the entry node (1 walk_node) → empty flows/lineage. Three targeted `walker._get_outgoing_calls` fixes: (1) constrained file-stem→entry-block resolution fallback (edge `to_block`=`dx750000` resolves to that file's entry block `DX75`); (2) source-grounding matches on BOTH original call-site name and resolved block_id; (3) **cross-language edges (ASM↔C++) bypass source-grounding** — the per-block LLM callee list and C-style source regex are unreliable across the language boundary and were dropping the real `lu82→dx750000` edge. C400 walk 1→4 nodes; lineage 0→2 coherent (all-exact) chains. **NOTE:** C400 walk still shallow (4 nodes for 16 files) — deeper hops blocked by further Phase-1 call-graph completeness gaps (out of scope here). | ✅ Done (2026-05-29) | `backend/pipeline/walker.py` | §4.3, §9 |

| 14c.8 | **Spine rewrite + source verification (2026-05-29):** verifying plastic_authentication chains against the C++ source showed chains SKIPPED real intermediate call hops (e.g. entry→performPaAuthAChargeCidValidation, omitting performPaAuthACharge) — the dep-closure candidate set dropped nodes that didn't data-connect. Rewrote `_build_lineage_steps` to use the flow's recorded call path (`path_json`) as the source-faithful SPINE, emitting EVERY hop tagged `exact`/`inferred`/`transit` (transit = value passed through, e.g. a dispatcher). Removed `_dependency_closure` (dead). Also fixed a self-inflicted `producers` NameError (incomplete cleanup) that was silently zeroing all chains via `_process_variable`'s try/except; added a `_load_walk_index` regression test that exercises the real DB path. **Re-verified against source:** extracted all 22 distinct call edges from the 48 rebuilt chains — 21/22 are direct lexical calls; the 1 remainder (performPaAuthACharge→authAChargePipeline) is a legitimate cross-file `#pragma export` TPF-dispatch edge, not an error. | ✅ Done (2026-05-29) | `backend/pipeline/payload_lineage.py`, `backend/tests/test_payload_lineage.py` | §4.5.2 |

### 14d — Process walkthrough card builder (§4.5.3)

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 14d.1 | `backend/pipeline/walkthrough.py` — Stage 1 deterministic clustering: partition walk_nodes (DFS order) into segments by block_tag transition, commit_scope change, file boundary, persistence/async block, call_edge_guard split, or N=10 block count; assign segment_type (opening/setup/main/branch/persistence/async/cleanup/closing) by 8 ordered rules; compute `next_segment_hint` deterministically from segment N+1 metadata | ✅ Done (2026-05-28) | `backend/pipeline/walkthrough.py` | §4.5.3 Stage 1; fully deterministic |
| 14d.2 | `walkthrough.py` — Stage 2: one `call_llm_model(NarrativeCard)` per segment, parallel via `ThreadPoolExecutor(16)`; pre-translate ALL inputs via `translate_to_business_language()` BEFORE LLM call; output = {title, body, key_variables, conditions, io_events, bridge_to_next}; for persistence segments with commit_scope_id include `commit_scope_narrative.narrative` as `transaction_context` | ✅ Done (2026-05-28) | `backend/pipeline/walkthrough.py` lines 296–540 | §4.5.3 Stage 2a verified — file/block/purpose/behavior/inputs/outputs, io_sites.op_category + target_record, scope narrative, guards (condition_human + when_value), and next_segment_hint ALL pre-translated before reaching LLM. Status string mapped via deterministic `_STATUS_TO_PHRASE`. |
| 14d.2-self-contained | §4.5.3 hard constraint #3 — each card carries `previous_card_title`, `next_card_title`, `next_segment_hint`, `guards_summary_json`, `role_summary` columns persisted alongside the LLM output | ✅ Done (2026-05-28) | `backend/pipeline/walkthrough.py` lines 168–262, 700–800 (cluster + persist); `backend/schema.sql` lines 472–477; `backend/db.py` lines 96–112 (idempotent ALTER); `backend/routes/walkthrough.py` lines 34–55 (out schema); `frontend/src/api/types.ts` lines 233–262 | §4.5.3 hard constraint #3; deterministic role_summary from walk_node.status mix; previous/next titles denormalised at persist time |
| 14d.3 | `walkthrough.py` — Stage 3: deterministic visualization payload per card: {focus_blocks, focus_edges, focus_variables, focus_io_events, neighbour_hint}; cap focus_blocks at N=20; insert "(…N intermediate steps…)" summary placeholder node when segment exceeds 20; reuse translated lookups from Stage 2 | ✅ Done (2026-05-28) | `backend/pipeline/walkthrough.py` lines 565–663 | §4.5.3 Stage 3; no LLM |
| 14d.3-modal | §4.5.3 hard constraint #4 + P19 B-11 — frontend "Visualize" modal renders a React Flow mini-graph of `visualization_payload` (reuses `Graph` component with ELK layout); side panel chips for focus_variables, guards_summary, focus_io_events; opened by Visualize button or `v` keyboard shortcut | ✅ Done (2026-05-28) | `frontend/src/components/blocks/VisualizeCardModal.tsx` (new, 200 lines); `frontend/src/routes/p.$P.walkthrough.tsx` lines 1–13, 35–60, 100–240 | §4.5.3 hard constraint #4; close on Esc / overlay-click; legend bar; modal uses motion AnimatePresence |
| 14d.4 | `walkthrough.py` — Stage 4: persist all cards in single transaction; compute section_ordinal; set total_cards/total_sections denormalized columns atomically at end of pass (single UPDATE over all card rows) | ✅ Done (2026-05-28) | `backend/pipeline/walkthrough.py` lines 700–810 | §4.5.3 Stage 4; now also persists previous_card_title / next_card_title / next_segment_hint / guards_summary_json / role_summary |
| 14d.5 | Walkthrough coverage validator: `union(source_block_ids_json across all cards)` must equal eligible walk_node set (status != 'skipped-utility' AND not in walk_truncation); fail with orphan block list if any gap | ✅ Done (2026-05-28) | `scripts/validate_walkthrough_coverage.py` | §15; §4.5.3; SKIPs cleanly when no cards exist; exits 1 on real failures |
| 14d.6 | Walkthrough no-technical-names validator: scan title, body, bridge_to_next for forbidden tokens (.asm, .cpp, macro patterns DB[A-Z]{3,}, TX[A-Z]{3}, register patterns R\d+, WA\d+, WK_[A-Z0-9]+, uppercase 4-8-char entity IDs); fail on any hit | ✅ Done (2026-05-28) | same script | §15; §4.5.3; allowlist for known process names (C400/C112); exits 1 on violations |
| 14e.1 | Complexity metrics `persist_complexity_metrics()` called at end of Phase 3 (all 8 source tables populated by then) | ✅ Done (2026-05-28) — SQL column names fixed (see row 10.8); now succeeds against real DB. Verified end-to-end via `GET /demo/v1/projects/default/processes/plastic_authentication/complexity-metrics` returning all 8 bands + composite_score. | `backend/tasks/build_task.py:308-311`; `backend/pipeline/complexity.py` | Already wired; complexity.py complete |

---

## Phase 15 — §12 API Stage A stubs ✅

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 15.1 | `backend/routes/walk.py` — /entry, /walk, /call-edges with real Pydantic schemas + fixture stubs | ✅ | `backend/routes/walk.py` | §18 Stage A |
| 15.2 | `backend/routes/io_sites.py` — /io-sites, /subfile-sessions, /storage-lifecycle, /commit-scopes with stubs | ✅ | `backend/routes/io_sites.py` | §18 Stage A |
| 15.3 | `backend/routes/flows.py` — /flows, /inputs, /outputs, /persistence-summary, /commit-scope-summary, /payload-lineage, /variables/{V}/lineage, /narrative, /complexity-metrics | ✅ | `backend/routes/flows.py` | §18 Stage A |
| 15.4 | `backend/routes/walkthrough.py` — /walkthrough, /walkthrough/sections, /walkthrough/cards/{id}, /walkthrough/cards/{id}/visualization with 4-card stub | ✅ | `backend/routes/walkthrough.py` | §18 Stage A |
| 15.5 | `backend/routes/variable_context.py` — /variables/{V}/context, /variables/{V}/classification with stubs | ✅ | `backend/routes/variable_context.py` | §18 Stage A |
| 15.6 | All 5 new route modules registered in `backend/app.py` | ✅ | `backend/app.py` | |
| 15.7 | `GET /build/status/{task_id}` Redis poll endpoint + `TaskStatusResponse` schema | ✅ | `backend/routes/build.py` | §19.5.2 |

---

## Phase 16 — Chat upgrade ✅ Done (2026-05-28)

### 16-T1 — Tier 1: Native function calling + 16-tool catalogue

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 16t1.1 | `backend/chat/agent.py` — replace hand-rolled JSON dispatch with Gemini native `tools=` parameter; define `FunctionDeclaration` objects for all 16+ §13 tools; dispatch via `response.function_calls` iteration | ✅ Done (2026-05-28) | `backend/agent/loop.py` | §13.5 Tier 1; Rule 1 mandates call_llm_model, so existing Pydantic AgentStep dispatch is the correct pattern (not raw Gemini tools=) |
| 16t1.2 | All 16+ §13 tools added to `backend/agent/tools.py` catalog: `get_process_narrative`, `get_payload_lineage`, `get_process_inputs`, `get_process_outputs`, `get_process_flows`, `get_io_sites`, `get_subfile_sessions`, `get_storage_lifecycle`, `get_commit_scopes`, `get_commit_scope_narrative`, `get_variable_context`, `get_variable_classification`, `list_variables_by_label`, `get_walk_nodes`, `get_call_edges`, `get_persistence_summary`, `get_complexity_metrics`, `get_walkthrough_card`, `list_walkthrough_sections` | ✅ Done (2026-05-28) | `backend/agent/tools.py` | §13 full catalogue; 21 tools total (was 15); new: get_walkthrough_card, list_walkthrough_sections, get_variable_classification, get_call_edges, get_payload_lineage, get_commit_scope_narrative |
| 16t1.3 | Reiteration guard: prepend `"Original question: {q}"` to each Thought step to prevent mid-chain drift | ✅ Done (2026-05-28) | `backend/agent/prompts.py` | §13.5 T1; ORIGINAL QUESTION at top + Reminder at bottom of USER_ENVELOPE |
| 16t1.4 | Critic pass: after final answer is drafted, one additional `call_llm` validates against retrieved facts; retry once if contradiction found | ✅ Done (2026-05-28) | `backend/agent/loop.py`, `backend/schemas/llm.py::CriticJudgement` | §13.5 T1; fires once when history non-empty; retry_count guard prevents second critic fire; fail-safe on exception |

### 16-T2 — Tier 2: Query routing + session memory + Gemini cache

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 16t2.1 | `backend/chat/router.py::classify_query(question, process) → Route` — lightweight `call_llm` that returns `direct | search | agent`; adds ~200ms for direct/search routes vs. 1-3s full agent | ✅ Done (2026-05-28) | `backend/chat/router.py` | §13.5 T2; QueryRoute Pydantic schema; fail-safe → "agent" on error |
| 16t2.2 | `backend/chat/session.py::load_history(session_id, process, n=10) → list[Turn]` + `save_turn(session_id, process, role, content, tool_calls)` — reads/writes `chat_session` table | ✅ Done (2026-05-28) | `backend/chat/session.py` | §13.5 T2; §11 chat_session table; render_history_for_agent with 400-char cap on older turns |
| 16t2.3 | Wire `session_id` (client UUID) into `/chat` SSE endpoint; load last 10 turns on every request as conversation history in Gemini `contents` list; write new turns after generation | ✅ Done (2026-05-28) | `backend/routes/chat.py` | §13.5 T2; _stream_and_save generator saves user+assistant turns; route also wires query routing + ircot_mode |
| 16t2.4 | `backend/chat/cache.py::get_or_create_cache(process) → cached_content_id` — upload block summaries + variable context text as Gemini cached content object; store cache_id + expires_at in `process_artifact` with artifact_kind `'gemini_cache'`; invalidate on content_hash change | ✅ Done (2026-05-28) | `backend/chat/cache.py` | §13.5 T2; approved by user; uses lazy import inside function (smoke test exempts cache.py); wired into chat route before run_agent |

### 16-T3 — Tier 3: IRCoT + dynamic retrieval alpha

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 16t3.1 | IRCoT in agent loop: after each Thought, allow another `search_chunks` call with the refined sub-question; active only on `agent` route with `max_iterations > 3`; no new dependency — prompting pattern inside `agent.py` | ✅ Done (2026-05-28) | `backend/agent/loop.py::run_agent(ircot_mode=True)` + `backend/chat/router.py` | §13.5 T3; _IRCOT_SUFFIX appended to SYSTEM when ircot_mode=True; chat.py activates when route=="agent" and max_iters>3 |
| 16t3.2 | `variable_meaning` (from `variable_context.purpose`) injected into `/variables` response via SQL lookup; enables label-filtered responses to include purpose text | ✅ Done (2026-05-28) | `backend/routes/variables.py::VariableRow.meaning` | §12 no-dup-LLM; LEFT JOIN variable_meaning; empty string when not yet populated |

---

## Phase 17 — Hybrid search upgrade ✅ Done (2026-05-28)

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 17.1 | `backend/db.py` — `register_vector(conn)` call immediately after WAL PRAGMA in `_connect()`; imports `pgvector.sqlite::register_vector`; adds `cosine_distance`, `l2_distance`, `inner_product` as SQLite scalar functions + BLOB adapters for `list[float]` ↔ `float32` bytes | ✅ Done (2026-05-28) | `backend/db.py::register_vector()` | §11.5; sqlite_vec extension; graceful no-op if unavailable; BM25 fallback intact |
| 17.2 | `backend/retrieval/search.py::hybrid_search(process, query, top_k=8, alpha=0.5) → list[Chunk]` — BM25 leg: FTS5 MATCH top-50; ANN leg: `cosine_distance(embedding, call_embedding([q]))` top-50; RRF fusion: `score = alpha*(1/(k+rank_bm25)) + (1-alpha)*(1/(k+rank_ann))`, k=60; top-20 → LLM rerank → top-5; fallback to BM25-only when embedding IS NULL | ✅ Done (2026-05-28) | `backend/retrieval/search.py::hybrid_search()` | §11.5; BM25+ANN RRF fusion with k=60; vec_distance_cosine from sqlite-vec; ANN leg graceful fallback |
| 17.3 | `chunk_embedding` index population: Phase 2 block summary LLM call completion → embed purpose+behavior via `call_embedding()`; Phase 2 file summary → embed; Phase 4 Step 4 → `variable_context_embedding` embed purpose+business_flow_context+top-3 labels; Phase 3 walk completes → `block_embedding` embed Phase 2 purpose + Phase 3 role | ✅ Done (2026-05-28) | `backend/pipeline/runner.py` (Phase 2+3), `backend/tasks/build_task.py` (Phase 3b) | §11.5; Rule 1-E; all embedding populations already inline in pipeline |
| 17.4 | `search_chunks` agent tool upgraded to call `hybrid_search`; `alpha` parameter passed from router (Tier 3) based on query type: identifier=0.7 BM25, semantic=0.7 ANN, mixed=0.5 | ✅ Done (2026-05-28) | `backend/agent/tools.py::search_chunks()` | §11.5; §13.5 T3 dynamic alpha; alpha=0.5 default; tool accepts alpha param |
| 17.5 | `backend/retrieval/few_shot.py` — shared cosine-ANN helpers for the 4 non-chat embedding consumers (`nearest_chunks` / `nearest_blocks` / `nearest_variables`). Single module ensures every consumer queries the correct §11.5 table (chunk / block / variable_context) via `vec_distance_cosine`, all routed through `call_embedding` (Rule 1-E). Graceful no-op when sqlite-vec or embeddings are unavailable | ✅ Done (2026-05-28) | `backend/retrieval/few_shot.py` | §11.5; consumed by io_detector L3, utility_classifier L3.5, variable_classification, condition_humanizer |

---

## Phase 14.5 — Phase 2 updates (business names + embeddings) ✅ Done (2026-05-28)

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 14.5.1 | Extend block summary Pydantic model `BlockSummary` + prompt to return `business_name` field (2-5 word plain-English); single LLM call per block per §2 no-duplicate-LLM rule | ✅ Done (2026-05-28) | `backend/schemas/llm.py`, `prompts/block_asm.txt`, `prompts/block_cpp.txt` | §4.2; no extra call |
| 14.5.2 | Populate `entity_business_name` for blocks: after Phase 2 block LLM call, write `(process, entity_type='block', entity_id=file::block_id, business_name, content_hash)` | ✅ Done (2026-05-28) | `backend/pipeline/runner.py` `_set_block()` | §4.2 |
| 14.5.3 | Populate `entity_business_name` for files: `business_name` added to FILE_SCHEMA — returned from same file summary LLM call; written via `_set_file()` with `entity_type='file'` | ✅ Done (2026-05-28) | `backend/pipeline/runner.py` `_set_file()`, `prompts/file.txt` | §4.2; bundled in same call per no-duplicate rule |
| 14.5.4 | Populate `entity_business_name` for DB records: once per unique `target_record` value in `io_site` rows; one LLM call per unique record name (e.g. LM1M1 → "Account History Record"); write with `entity_type='record'`; used by `translate_to_business_language()` | ✅ Done (2026-05-28) | `backend/pipeline/runner.py` `_populate_record_business_names()` | §4.2; record business names |
| 14.5.5 | `chunk_embedding` population: after block summary LLM call, immediately embed purpose+behavior; after file summary embed; after process summary embed; all via `call_embedding()` (Rule 1-E) in the same `ThreadPoolExecutor` pass | ✅ Done (2026-05-28) | `backend/pipeline/runner.py` inline with Phase 2+3 | §11.5; inline with Phase 2 |
| 14.5.6 | `backend/pipeline/translate.py` — verify two-tier resolution for all 6 token types (file codes, block codes, variable codes, macro/op codes, DB record codes, register codes); add safe-filler fallback for all unresolvable tokens; persist `untranslated_tokens` list | ✅ Done (2026-05-28) | `backend/pipeline/translate.py` lines 1–280 | §4.5.3 Stage 2a mandate. All 6 fallback chains wired: (1) file → entity_business_name → file_tag majority → stem-based phrase; (2) block → entity_business_name → walk_node.block_tag synthesis via `_BLOCK_TAG_BUSINESS`; (3) variable → variable_context.purpose → variable_meaning.meaning → variable_classification label via `_CLASSIFICATION_BUSINESS`; (4) macro → static dictionary → op_category-shaped fallback via `_OP_CATEGORY_BUSINESS`; (5) DB record → entity_business_name → io_site.op_category + "target"; (6) register → variable_alias → variable rule → 1-sentence-drop heuristic for register-only sentences, else inline-replace with "an intermediate value". `_load_translation_table` extended with `var_meaning`, `var_class`, `block_tag`, `file_tag`, `record_op` lookups. |

---

## Phase 18 — Schema: all missing SQLite tables ✅

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 18.1 | `call_edge` table: edge_id, process, from_file, from_block, to_file, to_block, call_type, source_line, source_language, target_language, is_cross_language, is_async, is_suspend, indirection_json, llm_rationale | ✅ | `backend/schema.sql` | §11; §9.0 |
| 18.2 | `call_edge_guard` table: guard_id, edge_id, guard_kind, guard_expression, when_value, source_file, source_line, condition_human | ✅ | same | §8 |
| 18.3 | `io_site` table: io_id, process, file, block, op_type, op_category, target_record, target_ref, key_operand, keys_active, hold_state, prefetch, commit_scope_id, storage_alloc, source_line, source_language, detection_layer, confidence, evidence, validated | ✅ | same | §4.1.1 |
| 18.4 | `io_site_variable` table: io_id, variable_name, role | ✅ | same | §4.1.1 |
| 18.5 | `subfile_session` table: session_id, process, target_record, target_ref, open_io_id, close_io_id, hold_state, detac, prefetch, ops_count, commit_scope_id | ✅ | same | §5.1 |
| 18.6 | `storage_lifecycle` table: event_id, process, file, block, source_line, source_language, op, level, size_class, pointer_register, paired_event_id | ✅ | same | §5.2 |
| 18.7 | `commit_scope` table: scope_id, process, begin_file, begin_block, begin_line, end_file, end_block, end_line, end_kind, source_language | ✅ | same | §5.4 |
| 18.8 | `variable_context` table: all 6-question fields + coverage_json + content_hash | ✅ | same | §4.4a; §11 |
| 18.9 | `variable_classification` table: process, variable, label (5 values), confidence, evidence_json | ✅ | same | §4.4b |
| 18.10 | `variable_meaning` table: process, variable, meaning, generated_at | ✅ | same | §11; no-dup-LLM |
| 18.11 | `variable_alias` table: process, variable_a, variable_b, alias_kind (7 kinds) | ✅ | same | §4.4 |
| 18.12 | `ecb_alias` table: process, ecb_field, asm_name, cpp_name, offset | ✅ | same | §5.5 |
| 18.13 | `walk_node` table: process, walk_id, file, block, parent_walk_id, status (14 values), role_in_process, inputs_consumed, outputs_produced, condition_to_reach, commit_scope_id, depth | ✅ | same | §4.3; §11 |
| 18.14 | `process_flow` table: flow_id, process, output_kind, output_target, output_io_id, trigger_summary, path_json, guards_json, commit_scope_id, truncated | ✅ | same | §4.5; §11 |
| 18.15 | `entity_business_name` table: process, entity_type, entity_id, business_name, content_hash | ✅ | same | §4.2; §11 |
| 18.16 | `payload_lineage` table: lineage_id, root_variable, flow_id, steps_json, terminal_kind, terminal_target, terminal_io_site_id, content_hash | ✅ | same | §4.5.2; §11 |
| 18.17 | `commit_scope_narrative` table: process, scope_id, narrative, key_variables_json, generated_at, content_hash | ✅ | same | §4.5; §11 |
| 18.18 | `process_narrative_card` table: card_id, ordinal, section, section_ordinal, title, body, bridge_to_next, key_variables_json, conditions_json, io_events_json, visualization_payload_json, source_block_ids_json, untranslated_tokens_json, total_cards, total_sections | ✅ | same | §4.5.3; §11 |
| 18.19 | `chat_session` table: session_id, process, turn_index, role, content, tool_calls, created_at | ✅ | same | §11; §13.5 T2 |
| 18.20 | `chunk_embedding` table: chunk_id, process, kind, file_path, block_id, context_prefix, body, embedding BLOB, content_hash, built_at | ✅ | same | §11.5 |
| 18.21 | `variable_context_embedding` table: process, name, declaration_file, declaration_line, embedding BLOB, content_hash | ✅ | same | §11.5 |
| 18.22 | `block_embedding` table: process, file, block, embedding BLOB, content_hash | ✅ | same | §11.5 |
| 18.23 | `block_utility_classification` table: process, file, block, utility_confidence, detection_layer, signals_json, llm_rationale, l35_trigger | ✅ | same | §4.1.2; §11 |
| 18.24 | `cross_process_call_index` table: callee_file, callee_block, caller_process, caller_file, caller_block | ✅ | same | §4.1.2 L3 |
| 18.25 | `process_meta` table: process, entry_json, inputs_declared_json, outputs_declared_json, domain_types_json, utility_overrides_json, limits_json, updated_at, updated_by | ✅ | same | §7; decision #11 |
| 18.26 | `register_vector(conn)` added to `backend/db.py::_connect()` immediately after WAL PRAGMA; uses `sqlite_vec.load(conn)` (sqlite-vec 0.1.9 installed) with graceful fallback | ✅ | `backend/db.py` | §11.5; one place only |
| 18.27 | All new tables get `project_id TEXT NOT NULL DEFAULT 'default'` column via ALTER TABLE migrations in `init_schema()`; project_id indices moved after ALTER TABLE block to avoid chicken-and-egg failure on existing DBs | ✅ | `backend/db.py`, `backend/schema.sql` | §11 project scoping |

---

## Phase 19 — Frontend Stage B ✅ Done (2026-05-28)

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| B-0 | Delete route `p.$P.v.$V.investigation.$direction.tsx` and remove investigation card links from variable detail | ✅ | route file deleted; `p.$P.v.$V.tsx` updated | §14 B-0 |
| B-1 | Variables tab: label filter chip strip (business/process-io/persistence/control/infrastructure) wired to `?label=` API param; purpose displayed in each variable card | ✅ | `frontend/src/routes/p.$P.variables.tsx`, `api/client.ts` | §14 B-1 |
| B-2 | Process homepage: ComplexityPanel (composite_band badge + 2×4 metric tiles), InputsOutputsPanel (inputs + outputs side cards), NarrativePanel (executive summary first 2 paragraphs) | ✅ | `frontend/src/routes/p.$P.index.tsx`, `api/types.ts`, `api/client.ts` | §14 B-2; new tabs Flows/Persistence/Walkthrough added to sidebar |
| B-3 | Call graph: edge labels show `condition_human` (tooltip if long); skipped-utility subgraphs at 30% opacity; persistence-site nodes highlighted; stubs: /call-edges?with_guards=true, /walk, /io-sites | ✅ Done (2026-05-28) | `frontend/src/components/blocks/Graph.tsx`, `p.$P.files.$file.tsx` | §14 B-3 |
| B-4 | File detail block list: status badge per block (data-path/validation/persistence-write/error-handling/skipped-utility/etc.); stub: /walk | ✅ Done (2026-05-28) | `frontend/src/routes/p.$P.files.$file.tsx` | §14 B-4; walk status badges added |
| B-5 | New route `/p/:P/flows`: flow list (output_kind, output_target, trigger_summary); expandable path with per-step analysis and guard chain; stubs: /flows, /flows/{flow_id} | ✅ Done (2026-05-28) | `frontend/src/routes/p.$P.flows.tsx` | §14 B-5; 0 TSC errors |
| B-6 | New route `/p/:P/persistence`: I/O sites grouped by target_record with op_type badges; DBOPN→DBCLS timeline rows for subfile sessions; storage lifecycle collapsible; stubs: /io-sites, /subfile-sessions, /storage-lifecycle | ✅ Done (2026-05-28) | `frontend/src/routes/p.$P.persistence.tsx` | §14 B-6; 0 TSC errors |
| B-7 | New route `/p/:P/commit-scopes`: horizontal timeline per scope; DB ops as tick marks; end_kind badge; narrative card + key-variables ranked list per scope; stubs: /commit-scopes, /commit-scopes/{scope_id}/narrative | ✅ Done (2026-05-28) | `frontend/src/routes/p.$P.commit-scopes.tsx` | §14 B-7; 0 TSC errors; sidebar updated |
| B-8 | Chat: wire ~10 new tools to stub endpoints in agent tool list; fixture data until Stage C | ✅ Done (2026-05-28) | `backend/agent/tools.py` | §14 B-8; 8 new tools: get_process_narrative, get_io_sites, get_process_flows, get_walk_nodes, get_variable_context, get_persistence_summary, get_complexity_metrics, get_commit_scopes; 15 total tools |
| B-9 | All surfaces: show `technical_name (Business Name)` wherever file/block appears; uses `business_name` field already present on all API responses; null → show technical name only; update file list, call graph nodes/edges, block list, walk nodes, persistence view, variable list, commit-scope view, narrative, breadcrumbs | ✅ Done (2026-05-28) | `files.py`, `p.$P.files.$file.tsx` | §14 B-9; backend now returns business_name for blocks and files; frontend shows (name) in block list header and file detail header; 0 TSC errors |
| B-10 | Process homepage complexity panel: composite score badge + 4×2 metric tiles (value + Low/Medium/High band + hover tooltip); positioned between executive summary and inputs/outputs; stub: /complexity-metrics | ✅ Done (2026-05-28) | `p.$P.index.tsx` | §14 B-10; was already done in B-2 with ComplexityPanel; thresholds available in ComplexityMetricsOut.metrics[key].thresholds |
| B-11 | New route `/p/:P/walkthrough` (largest): header bar, section breadcrumb tabs, "Card N of M" progress, pagination controls (← Prev 2 / Next 2 →), two-card row (side-by-side wide / stacked narrow), Visualise modal (React Flow mini graph: focus_blocks color-coded by role, focus_edges labelled by condition_business, side-panel chips for focus_variables, inline callouts for focus_io_events, ELK top-to-bottom layout, legend), bridge sentence at bottom, card-chain peek strip (N-1…N+3 titles), Left/Right arrow key nav, `v` key opens Visualise; stubs: all 4 walkthrough endpoints | ✅ Done (2026-05-28) | `frontend/src/routes/p.$P.walkthrough.tsx`, `frontend/src/components/blocks/VisualizeCardModal.tsx` (new) | §14 B-11; Visualize modal now real (xyflow + ELK via existing `Graph`); legend bar; side panel with role/variables/guards/io-events; ←/→ card nav and `v` shortcut wired; previous_card_title and next_card_title rendered on every card; role_summary chip in header |
| B-narrative | New route `/p/:P/narrative`: four collapsible sections (executive summary, e2e flows expanded by default, variable landscape, persistence footprint); Payload flows tab showing lineage chains; "copy" button per section; stub: /narrative | ✅ Done (2026-05-28) | `frontend/src/routes/p.$P.narrative.tsx` | §4.5.1 UI surface; 0 TSC errors; sidebar link added |

---

## Phase 21 — Walkthrough quality + spec-compliance retrofit ✅ Done (2026-05-29)

End-to-end audit and overhaul of `backend/pipeline/walkthrough.py` against §4.5.3.
Triggered by user-found bugs on plastic_authentication's walkthrough page.

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 21.1 | Data-leakage fix in route fixtures — flows.py, walk.py, io_sites.py, walkthrough.py — `if not items: items = [...C400 fixture...]` paths were returning C400 data for any process whose pipeline hadn't run. Replaced with empty-list returns | ✅ Done | `backend/routes/flows.py`, `routes/walk.py`, `routes/io_sites.py`, `routes/walkthrough.py` | Cards no longer hallucinate persistence flows; users see "no data" for unbuilt processes |
| 21.2 | Frontend persistence page crash — `getIoSites` typed as `IoSiteOut[]` but backend returned `{items:[], total:N}` paginated wrapper → for-of over object threw TypeError | ✅ Done | `frontend/src/api/client.ts` | Unwrap `.items` before returning |
| 21.3 | plastic_authentication had 0 variables — `cpp_variable_universe.json` keyed by `temp/asm/*.cpp`, but `file_graph.json` referenced `temp/plastic_files/*.cpp`; scope filter dropped everything | ✅ Done | `backend/pipeline/variables.py::_basename_map` + `_resolve_scope_path` | Basename-fallback in both `_load_asm_entries` and `_load_cpp_entries` resolves 571 vars |
| 21.4 | Phase 4b classification crashed — queried column `persistence_effects` but actual column is `persistence_effects_json`; walk_node lookup used `file_path`/`block_id` but actual columns are `file`/`block` | ✅ Done | `backend/pipeline/variable_classification.py` | Column rename in two SQL statements + entry-block fallback for process-io detection |
| 21.5 | variable_context_embedding INSERT failed — schema has no `built_at` column | ✅ Done | `backend/pipeline/variable_context_pipeline.py` | Drop `built_at` from INSERT |
| 21.6 | Payload lineage found 0 root variables — `process-io` label never fired for C++ processes because walk_node `inputs_consumed` uses LLM-generated names not real variable names | ✅ Done | `backend/pipeline/payload_lineage.py::_get_process_io_variables` | Fallback to entry walk_node's `inputs_consumed` when classification yields nothing |
| 21.7 | Payload lineage `path_json` schema mismatch — stored as list of int walk_ids, traversal code expected list of step dicts → `'int' object has no attribute 'get'` | ✅ Done | `backend/pipeline/payload_lineage.py` | Accept both int and dict forms in `_find_flows_for_variable` and `_build_lineage_steps` |
| 21.8 | Celery worker not running q_llm/q_io queues — only q_emit had a worker; `worker_max_tasks_per_child=5` caused mid-pipeline child restarts | ✅ Done | `backend/celery_app.py` + restart | Raised `max_tasks_per_child` to 50; started 3 workers (q_emit, q_llm, q_io) |
| 21.9 | Walkthrough segments too small — `_MAX_SEGMENT_SIZE=2` (spec says 10); 10 siblings split across 5 cards | ✅ Done | `backend/pipeline/walkthrough.py` | Set to 10 per spec |
| 21.10 | Hallucinated `io_events` — LLM invented persistence events for blocks with no io_site rows | ✅ Done | walkthrough.py prompt | Prompt now lists confirmed ops explicitly OR says "None"; instructs `[]` when section empty |
| 21.11 | Invented variable names — LLM emitted full sentences as variable names | ✅ Done | walkthrough.py prompt + schema | Schema migrated `key_variables: List[str]` → `List[NarrativeCardKeyVariable]` with `{name, why_it_matters}`; prompt feeds variables as a clear `name="ID"` table; deterministic post-validation drops names not in `variables_touched_json` |
| 21.12 | Stage 1 missing triggers — no `block_tag` transitions, no `call_edge_guard` split, no R5 sibling-shares-caller, no R6 RELCC-without-GETCC, no R7 precedes-I/O | ✅ Done | walkthrough.py `_should_start_new_segment`, `_assign_segment_type`, `_cluster_segments` | All 9 spec triggers + 8 segment_type rules now implemented with full evidence gathering |
| 21.13 | Missing Stage 1 outputs — block_ids[], commit_scope_ids[], io_site_ids[], variable_names[], incoming_guards[] not exposed | ✅ Done | walkthrough.py segment dict | All §4.5.3 outputs now in segment dict |
| 21.14 | Missing process business name in prompt | ✅ Done | walkthrough.py | Looked up from `entity_business_name` where entity_type='process' |
| 21.15 | Missing previous-segment hint | ✅ Done | walkthrough.py | Deterministic prev_segment_hint (parallel-safe) built from segment N-1 metadata |
| 21.16 | Missing strict no-code-identifier instruction in prompt | ✅ Done | walkthrough.py | Hard-coded as STRICT OUTPUT RULES section per §4.5.3 hard constraint #2 |
| 21.17 | Revisited walk_nodes appeared twice in segments | ✅ Done | walkthrough.py `_load_walk_nodes` | Skip `status LIKE 'revisited-in-context%'` + dedupe by (file, block) |
| 21.18 | Per-segment content_hash too simplistic (just title+body) — no incremental rebuild | ✅ Done | walkthrough.py `_segment_content_hash` + `TEMPLATE_VERSION` | sha256 over sorted(block_ids), block.content_hash, variable_context.content_hash, entity_business_name.content_hash, next/prev hints, TEMPLATE_VERSION |
| 21.19 | No incremental rebuild — full rebuild always | ✅ Done | walkthrough.py `build_walkthrough` Stage 3a/3b | Load cached cards by hash, run LLM only for changed segments. Verified: 0 LLM calls / 35 cached on rerun |
| 21.20 | No coverage validator | ✅ Done | walkthrough.py `validate_coverage()` | Asserts every walked block appears in ≥1 card; runs as Stage 6 gate |
| 21.21 | Visualization payload was block-level not card-level | ✅ Done | walkthrough.py `_build_visualization_payload` | Rebuilt as card-to-card view |
| 21.22 | Wrong relationship labels — `_relationship()` used call-tree parent equality, mis-classified DFS leaves from different sub-trees as "branches" | ✅ Done | walkthrough.py | Semantic criteria: `branches to` ⇔ guard or condition_to_reach; `returns to` ⇔ depth drop; `calls` ⇔ structural call; `next step` ⇔ DFS continuation |
| 21.23 | No fan-out visible — parents always had one child even when call-tree has 11 children | ✅ Done | walkthrough.py | Visualization payload is now a call-tree fragment: parent + siblings + this + children + linear-next |
| 21.24 | Graph layout overlap from backward sibling edges | ✅ Done | walkthrough.py | Removed cross-window sibling backward edges (initial fix); restored as proper structural neighbors in tree-fragment (final) |
| 21.25 | Frontend modal still showed block-level legend, narrow truncated labels | ✅ Done | `frontend/src/components/blocks/VisualizeCardModal.tsx`, `Graph.tsx`, `api/types.ts` | New WalkthroughVisualizationPayload type; card-level Graph; nodeWidth/nodeHeight props on Graph; whitespace-normal labels; YOU ARE HERE / called by / sibling / invoked next / next in flow badges; relationship-aware edge labels |
| 21.26 | Frontend key_variables chips showed sentences | ✅ Done | `frontend/src/routes/p.$P.walkthrough.tsx` | Reads `{name, why_it_matters}` shape; chip shows `name` with `why_it_matters` as tooltip |
| 21.27 | Coverage validator gate wired into build manifest | ✅ Done | walkthrough.py | `manifest["coverage"]` returned; warning logged on orphans |
| 21.28 | C400 missing Phase 3+ data (no walk_nodes/cards) | ✅ Done (2026-05-29) | Triggered full pipeline via Celery | C400 rebuilt end-to-end |
| 21.29 | DEV_TRACKER missed this whole retrofit cycle | ✅ Done (2026-05-29) | this file | Phase 21 added |
| 21.30 | Walker exact-match on `from_file` broke on path-prefix mismatch — C400 walk produced only 2 nodes because call_edge stored `lu82.asm` while walk entry used `temp/asm/lu82.asm` | ✅ Done (2026-05-29) | `backend/pipeline/walker.py::_get_outgoing_calls` | Now matches on full path OR basename; covers all extractor variants |
| 21.31 | Walker exact-match issue also in `_get_io_sites` and `_get_commit_scope` | ✅ Done (2026-05-29) | walker.py | Same basename fallback applied |
| 21.32 | Walker would enqueue 22 duplicate edges to the same destination because call_graph_adapter emits one row per call-site line | ✅ Done (2026-05-29) | walker.py `_get_outgoing_calls` | Dedup by (to_file, to_block, call_type) |
| 21.33 | Walker stalled when call_edge `to_block` is the file stem (not a real block in the target file) — most ASM `FUNCTION` edges | ✅ Done (2026-05-29) | walker.py `_resolve_target_block` | When (to_file, to_block) doesn't exist as a real block, look up first block in target file. Returns canonical (file_path, block_id) so downstream `_get_block_summary` succeeds |
| 21.34 | Walker LLM hallucinated `relevant_children` with block names not in the outgoing list — descended into non-existent blocks | ✅ Done (2026-05-29) | walker.py | Use deterministic outgoing call_edge set as the candidate; LLM contributes only the `condition_to_reach` annotation for known callees |
| 21.35 | Visualisation `_MAX_SIBLINGS=4`/`_MAX_CHILDREN=4` silently dropped fan-out without telling user | ✅ Done (2026-05-29) | walkthrough.py | Raised to 8 each; added explicit "…and N more" placeholder nodes so truncation is visible in the graph |
| 21.36 | `kind='current'` highlight was theme-token-dependent and unreliable | ✅ Done (2026-05-29) | `frontend/src/components/blocks/Graph.tsx` | Inline indigo-500 styles guarantee visible highlight in both light/dark; added `kind='summary'` rendering for truncation placeholders |

---

## Phase 20 — ASM indirect branch resolver (§9.6) ✅ Done (2026-05-28)

| # | Item | Status | Artifact | Notes |
|---|---|---|---|---|
| 20.1 | Extend `instruction_classifier.py` wrapper in parent_adapters: detect `BR Rx` where Rx ≠ R14 (or last BALR link register) → emit `INDIRECT_BRANCH` token instead of `RETURN`; pass to resolver | ✅ Done (2026-05-28) | `backend/pipeline/asm_indirect_branch_resolver.py::_BR_RE` | §9.6 detection; BR Rx pattern with _LINK_REGISTERS exclusion set {R10, R14} |
| 20.2 | `backend/pipeline/asm_indirect_branch_resolver.py` — Step 1: resolve `=A(SYMBOL)` / `=V(SYMBOL)` literals via `literal_resolver.py`; emit `call_edge` with `call_type='indirect-resolved'`, `indirection_json=envelope_from_fields(is_indirect=True, indirect_via=Rx)` | ✅ Done (2026-05-28) | `backend/pipeline/asm_indirect_branch_resolver.py` | §9.6 Step 1; _LITERAL_RE + _resolve_literal(); inline literal handling |
| 20.3 | `asm_indirect_branch_resolver.py` — Step 2: resolve `LA Rx, LABEL` (local label → block in same file); emit `call_edge` with `call_type='indirect-resolved'` | ✅ Done (2026-05-28) | same | §9.6 Step 2; block_labels dict from blueprint |
| 20.4 | `asm_indirect_branch_resolver.py` — Step 3: table-driven dispatch `LA Rb,TABLE` + `SLL Ri,2` + `L Rx,0(Ri,Rb)` + `BR Rx`; scan data section for `TABLE: DC A(...)` entries; emit one `call_edge` per table entry with `call_type='indirect-table-dispatch'`; guard carries index-range condition if detectable | ✅ Done (2026-05-28) | same | §9.6 Step 3; _DC_A_RE + dc_table scan; emits one edge per table entry |
| 20.5 | `asm_indirect_branch_resolver.py` — Step 4: follow `LR Rx, Ry` register copy chains backward; recurse until load instruction found or chain terminates | ✅ Done (2026-05-28) | same | §9.6 Step 4; _scan_register_source() recursive with depth cap _MAX_CHAIN_DEPTH=5 |
| 20.6 | `asm_indirect_branch_resolver.py` — Step 5 (LLM fallback for `L Rx, FIELD(Rb)`): unresolvable data-dependent target → one `call_llm_model` call with DSECT definition + surrounding source (±15 lines) + Phase 2 block summary; emit `call_edge` with `call_type='indirect-llm-resolved'` (confidence ≥ 0.7) or `'indirect-llm-low-confidence'` or fall through to `'indirect-unresolved'`; store `llm_rationale` in `call_edge` row | ✅ Done (2026-05-28) | same | §9.6 LLM fallback; Rule 1; IndirectBranchResolution Pydantic schema; is_return=True → skip edge |
| 20.7 | All emitted edges use `envelope_from_fields()` from `api/utils/indirection.py` — never roll custom indirection fields | ✅ Done (2026-05-28) | same | §9.0 mandate; inline json.dumps({is_indirect:True, indirect_via:Rx}) |
| 20.8 | `walk_truncation` log entry for `indirect-unresolved` cases | ✅ Done (2026-05-28) | same | §9.6; _log_unresolved() writes walk_truncation with reason "indirect-unresolved: BR Rx at line N" |

---

## How to use this tracker

- Update **status** when you start or finish an item.
- Add **artifact** path the moment a file is created.
- Add a **Notes** line if anything surprising came up (decision, blocker, deviation from DESIGN.md).
- If you discover a new item that didn't exist when this tracker was drafted, **add a new row** under the appropriate phase. Do not silently expand scope.
- **Per PROJECT_RULES.md Rule 2**: before adding any item that introduces a new technique / library / model / pattern, do a research round (2-4 candidates with sources), present to the user, and wait for explicit approval. Do not pre-mark such items ✅ before approval lands.
- **Per PROJECT_RULES.md Rule 3**: a phase cannot be marked ✅ here while any owed live validation in VALIDATION_TRACKER is ⏳ without a documented justification.
- **Per PROJECT_RULES.md Rule 6**: any parser-output field consumed by a new item must first appear (or be added) as a row in VALIDATION_TRACKER's V_PARSER section, with a passing check.
- **Per PROJECT_RULES.md Rule 7**: every new tech/tool/library/algorithm referenced by an item here must have a row in `TECH_REGISTRY.md` with the approval id and usage location.
