# Explanability Demo — Design Document

> **Updates after v1**:
> - 2026-05-27 — Scale & QA architecture revised after user clarified production
>   data will have **3k+ files / dense call graph** and chat must "answer
>   anything". Decisions Q-S1/2/3/4 locked. See
>   [`docs/scale_and_qa_proposal.md`](./docs/scale_and_qa_proposal.md).
>   §4 (build pipeline) now uses **levelized DAG parallelism**.
>   §8 (retrieval / QA) now uses **Adaptive RAG with agentic ReAct fallback**.
> - Every tech / tool / algorithm in use is registered in
>   [`TECH_REGISTRY.md`](./TECH_REGISTRY.md) per PROJECT_RULES Rule 7.

**Status:** v1 draft for review. Once approved, becomes the build contract.
**Scope:** A standalone subsystem under `explanability_demo/` that surfaces process-level / variable-level explanations to **non-technical business users** for the ASM/C++ codebase.

> All code changes for this initiative live under `explanability_demo/`. Existing packages (`backward_traversal`, `process`, `file_call_graph.py`, parser blueprints) are **imported / consumed read-only**. Existing `api/` is **reference only** — we do not extend it.

---

## 0. What was done already

Phase 0 ✅ — `data/processes/C400/{file_graph.json, headers.json, macros.json}` regenerated from the **real** lu82 → dx750000 → dx710000 → dx730000 → dx740200 → ... chain. 16 nodes, 20 edges, deterministic. Generator: `explanability_demo/scripts/build_process_data.py`.

Validation results live in the script output and the JSON. The earlier stub files (from `data/processes/_generate_seeds.py`) were random and have been replaced.

---

## 1. Goals & Non-goals

### Goals
1. Business users select a **process** → see a comprehensive, plain-English summary of what that process does end-to-end.
2. View a **variable inventory** for that process, with one-sentence purposes per variable.
3. View a **file inventory** for that process — purpose per file, block/function flow, callee detail.
4. For any variable, run **setter-logic investigation** (backward) **or** **usage-point investigation** (forward), get an iterative chunked explanation with cited sources.
5. Free-form chat at process level **and** variable level (variable chat is seeded with the explanation thread).

### Non-goals (this phase)
- Editing / round-tripping ASM into modern code.
- Cross-language equivalence beyond what the existing `variable_identity_index` gives.
- Replacing the existing `api/` chat UI (`api/static/index.html`). The demo is a parallel surface, not a migration.

---

## 2. What already exists vs what we build

### Existing (consume, do not modify)
| Concern | Module | Reuse as |
|---|---|---|
| Per-process file graph (deterministic) | `process/build_process_truncated_file_graph.py` | Authority for `process → files/edges` |
| Process catalog | LU82 FUNCTION extractor (`process/extract_function_processes.py`) | Source for the process list |
| Macros + headers per file | New `build_process_data.py` (this PR) | Process-data JSON files |
| Backward variable lineage | `backward_traversal.runner.backward_only_runner.run_backward_only` | Python import for setter-logic investigation |
| File-call graph (full) | `file_call_graph.py` | When we need the un-truncated graph |
| Parser blueprints | `temp/output_latest/asm/*.json` and `temp/output_latest/asm_variable_universe.json` | Block / function / variable extraction (with filter — see §6) |
| Gemini wrapper | `llm/caller.py` | Single LLM client (or our own minimal wrapper if `llm/caller.py` requires job context) |

### Existing-but-untrusted (validate then maybe reuse)
- `temp/output_latest/asm/*.json::macro_expansions` — populated with `None`s; **untrusted**. We source-scan `#include` and macro opcodes directly (§5).
- `temp/output_latest/asm/*.json::file_dependencies` — empty arrays; **untrusted**.
- `variable_identity_index.json` cross-language mapping — `symbolic_identity`/`access_identity` are empty; **untrusted**. We only use the ASM-side DSECT alignment data.

### To build (in `explanability_demo/`)
1. **Knowledge extraction pipeline** — Gemini topo passes over each process → file → block, persisting summaries + variable purposes into SQLite (§4).
2. **Forward_traversal package** — proper cross-file forward variable tracing, mirroring `backward_traversal`'s two-pass architecture (§7).
3. **Retrieval / QA service** — hybrid BM25 + dense + LLM-rerank over the process-scoped knowledge, with **contextual retrieval** prepending (§8).
4. **FastAPI backend** — narrowly-scoped endpoints for the new UI (§9).
5. **Frontend** — React + Vite + Tailwind, with React Flow for graphs and a chat surface that streams chunked explanations with citations (§10).

---

## 3. Architecture overview

```
┌───────────────────────────────────────────────────────────────────────────┐
│                      Frontend (React + Vite + Tailwind)                   │
│  Process list → Process detail (summary | files | variables | chat)       │
│    File detail (block/function graph + summaries)                         │
│    Variable detail → Setter / Usage investigation → Variable chat         │
└───────────────────────────────────────────────────────────────────────────┘
                                    │  (HTTP/JSON + SSE for streamed chunks)
                                    ▼
┌───────────────────────────────────────────────────────────────────────────┐
│      Backend (FastAPI, async)   —   explanability_demo/backend            │
│  ┌───────────────┐  ┌───────────────┐  ┌────────────────────────────┐     │
│  │ Process API   │  │ Knowledge API │  │ Investigation API           │     │
│  │ (catalog,     │  │ (summaries,   │  │ - backward (setter logic)   │     │
│  │  graphs,      │  │  inventories) │  │ - forward (usage points)    │     │
│  │  files)       │  │               │  │ - chunked explanation SSE   │     │
│  └───────┬───────┘  └───────┬───────┘  └──────────────┬─────────────┘     │
│          │                  │                         │                   │
│          └──────────────────┴────────────┬────────────┘                   │
│                                          ▼                                │
│                         ┌──────────────────────────────┐                  │
│                         │   Retrieval / QA service     │                  │
│                         │   (BM25 + Gemini embed +     │                  │
│                         │    Gemini-flash rerank)      │                  │
│                         └──────────────┬───────────────┘                  │
│                                        │                                  │
│        ┌───────────────────────────────┼─────────────────────────────┐    │
│        ▼                               ▼                             ▼    │
│  ┌───────────────┐         ┌───────────────────────┐      ┌──────────────┐│
│  │ SQLite +      │         │ backward_traversal /  │      │ Gemini 2.5   ││
│  │ sqlite-vec    │         │ forward_traversal /   │      │ Pro + 2.5    ││
│  │ (knowledge,   │         │ process truncation    │      │ Flash + emb. ││
│  │ embeddings)   │         │  (deterministic)      │      │ 004          ││
│  └───────────────┘         └───────────────────────┘      └──────────────┘│
└───────────────────────────────────────────────────────────────────────────┘
```

### Build vs runtime path
- **Build-time** (one-shot per process, idempotent, resumable): topo-sort files → for each file, topo-sort blocks → call Gemini → write `summary`, `purpose`, `dep_calls`, variable-purpose rows into SQLite. Embed everything. Hours-long but cached.
- **Runtime** (UI-driven, < 2s typical): pure SQLite reads for inventories and summaries. Retrieval only kicks in for chat / "explain more" / open-ended QA.

---

## 4. Knowledge extraction pipeline

### 4.1 Topological order
- **Outer pass**: topo-sort the process file graph (`data/processes/<P>/file_graph.json`). Sinks first, sources last — so when we summarize `lu82` we already have summaries for everything it calls.
- **Inner pass**: per file, topo-sort blocks (ASM) / functions (C++) within the file using the parser blueprint's intra-file edges. Sinks first.

### 4.2 What we extract per block/function (Gemini 2.5 Pro via `call_llm`)

> **LLM constraint (decided):** every LLM call in this subsystem goes through
> the existing `llm/caller.py::call_llm(prompt, system_prompt=None) -> str`.
> Gemini 2.5 Pro only. No embedding API, no separate Flash, no other vendors,
> no `responseSchema`. JSON shape is enforced by **prompt instruction + parse
> + retry**.

Single prompt per block. The prompt ends with a strict "Return ONLY a JSON
object matching this schema, no prose, no markdown fences" instruction.
Parsing is wrapped in `_parse_or_retry(raw, schema, attempts=3)` which
re-prompts with the parse error on failure.

```json
{
  "purpose": "1–2 sentence business-language description",
  "behavior": "3–6 sentences: inputs, decisions, side effects, outputs",
  "calls": [
    {"target": "<file>::<block-or-fn>", "reason_business_language": "..."}
  ],
  "variables_touched": [
    {"name":"...", "role":"read|write|both", "purpose":"1 sentence"}
  ]
}
```

Inputs provided to the prompt:
- The block's raw source lines (from `temp/asm/`).
- For each callee in this block: the callee's already-cached `purpose` (because of topo order).
- Process context (`process metadata.title + description`).
- For variables referenced: declaration line, type, scope (from the parser blueprint).

### 4.3 What we extract per file (Gemini 2.5 Pro)

After all blocks/functions of the file are summarized:

```json
{
  "file_purpose": "Why this file exists in process <P>",
  "narrative": "5–10 sentences explaining how the file's blocks interact",
  "key_variables": ["..."],
  "key_callees": ["..."]
}
```

### 4.4 What we extract per process (Gemini 2.5 Pro)

After all files done — one final pass:

```json
{
  "summary_short": "≤ 80 words",
  "summary_long": "600–1200 words, business-language end-to-end walkthrough",
  "key_steps": [{"step":"...", "files":["..."]}],
  "key_variables_top10": ["..."]
}
```

### 4.5 Failure handling
- Each block call is wrapped with bounded retry (3) + structured-output validation.
- Build is **resumable**: the runner reads "what's already in SQLite for this process at content-hash X" and skips.
- A block's content_hash = sha256(source + prompt template version). Bump template → re-extract that block only.

### 4.6 Why topo-sort, not flat batch?
- Each block's prompt is **cheaper** (smaller context) because callee purposes are pre-computed strings.
- Determinism: same inputs → same outputs (modulo LLM nondeterminism, dampened by `temperature=0.1`).
- Easy to "explain more": just re-render the cached chain.

---

## 5. Data sources & validation gates

| Source | Trust | Use |
|---|---|---|
| `data/processes/<P>/file_graph.json` | High (deterministic, just regenerated) | Authority for files + cross-file edges |
| `temp/output_latest/asm/<f>.json::blocks`, `subroutines` | High (tree-sitter / HLASM parser; well-formed) | Block/function discovery + line ranges |
| `temp/output_latest/asm/<f>.json::call_graph` | High | Intra-file edges for topo-sort |
| `temp/output_latest/asm_variable_universe.json` | Mixed — see §6 | Variable inventory after filtering |
| `temp/output_latest/cpp_variable_universe.json` | High | C++ variable inventory as-is |
| Parser `file_dependencies` / `macro_expansions` | **Empty / null — distrust** | Skip; source-scan instead |
| Parser `variable_identity_index::symbolic_identity` | **Empty — distrust** | Skip cross-language mapping for now |

Every consumer in `explanability_demo/` runs through a tiny **validation gate** (`explanability_demo/backend/validation.py`) that asserts non-empty + shape-correct before treating the field as trusted. If a gate fails for a process, the affected feature is degraded gracefully (UI shows "data unavailable for this slice") instead of silently rendering garbage.

---

## 6. Variable inventory strategy

**Audit verdict** (full evidence: `explanability_demo/docs/variable_universe_audit.md` — to be written from the audit run already done):

- ASM universe: 2,726 entries, 57% are macro-scoped noise (`&`/`#` in name). Only `metadata.is_runtime_symbol=True` is trustworthy → drops to ~1,175.
- C++ universe: 346 entries, all clean (tree-sitter AST extraction).
- For C400 (16-file scope): **~993 raw → ~518 after filter**.

**Decision (T1 + T2 from audit):**

1. **Filter** ASM universe to `metadata.is_runtime_symbol=True`. Keep all C++ variables.
2. **Augment** each variable with a 1-sentence `purpose` generated by Gemini (from §4.2's `variables_touched.purpose` plus a final dedup/refine pass per variable).
3. Store in SQLite (`variables` table). UI reads directly.

Reasoning: the cheapest way to give business users **useful** variable inventory without committing to full cross-language equivalence (T4 — multi-week work).

UI will label the variable origin (ASM-runtime / C++-source) so users know what they're looking at.

---

## 7. forward_traversal package

### 7.1 Why mirror `backward_traversal`
Same call-graph data, same dep_var concept, same evidence shape → reuse the explanation rendering layer downstream. Output JSON shape ≡ `backward_only`'s shape but with semantics inverted ("where is this variable used after it's set?").

### 7.2 Architecture (mirror)
```
forward_traversal/
├── cli.py
├── runner/forward_only_runner.py     ← run_forward_only(...)
├── tracing/
│   ├── asm_forward_tracer.py          ← BFS forward over intra-file ASM CFG
│   └── cpp_forward_tracer.py          ← BFS forward over C++ GVL graph
├── bridge/cross_file_bridge_forward.py
├── utils/                              ← Reuse from backward_traversal where possible
│   └── (subroutine_resolution.py, token_utils.py imported from backward)
└── glossary/
    └── instructions.py                 ← READER_INST (CLC, CLI, L, ...), USER_INST, SETTER_INST (terminal)
```

### 7.3 Existing partial work to harvest
From the audit:
- `forward_trace_lineage.py` (root) — has `ForwardLineageTracer` with intra-file forward DFS. Lift the BFS body.
- `filter_forward_strict.py` / `filter_forward_overwrite.py` — post-processors; can become final filters.
- `filter_forward_from_setter.py` — single-file forward stops on overwrite; useful for the **terminal** definition of "usage path".

### 7.4 Two-pass mirror (vs backward's two-pass)

**Pass 1 — primary trace (forward)**
- **Setter** (first in chain — equivalent to backward's "modifier" role): find all setter sites for the root variable.
- From each setter site, **forward-reachable** CFG blocks within the file; collect READ instructions (`CLC`, `CLI`, `L`, `LH`, `LR` source operand, parameter binds, etc.).
- Cross-file: ENTRC/CREEC/SWISC outbound → next file's entry block; continue forward there.
- C++: GVL graph in forward direction (`assign → use`, `arg_bind → ...`).

**Pass 1b — terminator detection**
- Forward path stops at: variable overwrite (next SETTER on same var), end of file with no outbound flow, or hitting `max_depth`.

**Pass 2 — dependent variable BFS (forward)**
- Variables **derived from** the root (`ST root → dep`, `MVC dep, root`) are forward-traced at `depth+1`. Caps mirror backward's.

### 7.5 Output JSON shape
Same top-level keys as backward (`files`, `dep_var_traces`, `full_file_flow`), with:
- `setter_sites_root` (entrypoints) instead of `modifier`.
- `usage_sites` per file: list of READER lines and the dep_vars they produce.
- `full_file_flow.edges[].discovered_from = "forward_chain"` etc.

### 7.6 Caps (same defaults as backward)
`max_depth=8, max_subroutine_depth=2, max_subroutine_nodes=400, max_trace_nodes=5000, max_dep_vars=20, max_dep_var_depth=2, max_downstream_depth=2`.

---

## 8. Retrieval / QA strategy

### 8.1 Why not pure-LLM with full process dump?
Process slices can be 5k–50k LOC across files. A 50k-LOC dump fits in Gemini 2.5 Pro's 1M-token window technically, but: (a) every question would pay the full-context price, (b) you'd lose attribution — the model would synthesize without citations, (c) latency is unacceptable for a chat UI.

### 8.2 Why not GraphRAG?
GraphRAG (Microsoft, 2024) reconstructs a knowledge graph **from unstructured text**. We already have an **authoritative** call graph. Building a noisier semantic one on top would be redundant. Better to **anchor retrieval in the existing deterministic graph**.

### 8.3 Chosen approach — "deterministic skeleton + BM25-with-contextual-prefix + LLM rerank + LLM synthesis"

This is the user's "deterministic + probabilistic perfect mix" under the
single-`call_llm` constraint. No embedding API is available, so we cannot do
dense retrieval — BM25 carries the semantic load, and we compensate by
adding **contextual prefixes** to every chunk (Anthropic, Sep 2024). Gemini
2.5 Pro is reused for reranking and synthesis.

**Stage A — Deterministic prefilter (free)**
For any query in a process P:
- Restrict candidate scope to files in P's `file_graph.json`.
- If the query references a specific variable / file / block, prune harder.

**Stage B — BM25 retrieval over the SQLite knowledge base**
Each "chunk" is one of:
- Block/function summary (~150 words) prepended with a `context_prefix` ("In
  process C400, file dx740200.cpp, function globalLimitsUpdate, called from
  dx730000:maintenancePipeline, this block ..."). The prefix is **stored
  inside the FTS5 row** so a single BM25 score covers both query→chunk and
  query→context matches.
- File summary chunks.
- Variable purpose rows.

Scored via `sqlite-fts5` (`MATCH`/`bm25()`). Top 30 candidates.

**Stage C — LLM rerank (via `call_llm`)**
Single prompt structure:
```
Question: <q>
Candidates (id followed by chunk text):
  [1] ...
  [2] ...
  ...
Return ONLY a JSON array of the top-8 candidate ids in descending order of
relevance, e.g. [5, 12, 1, 7, 3, 22, 9, 18].
```
Parsed with the same `_parse_or_retry` helper. Cost: one `call_llm` per
query. Latency budget: ~3-6s; acceptable for chat. We pipeline this with the
SSE message stream so the UI shows "thinking..." then the first words.

**Stage D — Synthesis via `call_llm` (Gemini 2.5 Pro)**
Single prompt with question + the 8 reranked chunks (each tagged with its
`chunk_id`, `file`, `line_range`). Output instruction:
```
Return ONLY a JSON object:
{
  "message": "business-language answer, 80-300 words, plain English",
  "sources": [{"chunk_id":..., "file":..., "line_range":[..,..], "what_it_supports":"..."}],
  "suggested_next": ["...", "..."]
}
```
Strict rule in the prompt: **never quote ASM mnemonics or C++ syntax in
`message`**; raw text only travels in `sources[].snippet_internal` (rendered
behind a "view raw source" affordance). Parsed with `_parse_or_retry`.

### 8.3b — Why this works without dense retrieval

- Anthropic's measured improvement from adding contextual prefixes to BM25
  alone is ~+35% recall over plain BM25, and ~5-10pp behind dense+BM25
  hybrid. We accept the gap.
- Process slices are small (16-50 files). The vocabulary overlap between
  business-phrased questions and contextual-prefixed chunks is high enough
  that BM25's top-30 reliably contains the right answer for the LLM
  reranker to surface.
- The reranker is Gemini 2.5 Pro itself, which on small candidate pools
  outperforms specialized learned rerankers on most public benchmarks
  (NQ, BEIR, MS MARCO trec-dl).

### 8.4 "Explain more" / iterative chained explanation
For the variable investigation flow (setter-logic / usage-points):

1. First API call: run backward (or forward) traversal → get the trace JSON with line-anchored evidence chunks per dep_var.
2. **First message**: synthesize one business-language message covering the **top-level setter site** (or first usage point) — call it message M1. Each evidence node becomes an addressable `source`.
3. UI shows "Explain more" button.
4. Each click → next iteration of the API: pull the next dep_var / next file in the trace → synthesize message M2 that **references** M1 ("Earlier we saw that `LG1OSI` was set in `da78`; here's what determined that...") via in-context anchors.
5. Iteration order mirrors `backward_traversal`'s **Pass-2 BFS order** — so each message is a logical step deeper, matching what `backward_traversal` already conceptually computes. The user sees the same algorithm narrated.
6. After the chain ends, **variable chat** opens. The chat's knowledge = M1..Mk + all `sources` collected so far + process-scoped retrieval. User asks a follow-up → Stage A/B/C/D pipeline runs but the prefilter favors chunks already cited by the M-chain.

### 8.5 Single-`call_llm` rule
**Confirmed**: every LLM interaction in `explanability_demo/` flows through
`llm/caller.py::call_llm(prompt, system_prompt=None) -> str`. No embedding
API, no separate Flash model, no `responseSchema`, no other vendors. JSON
output is prompt-engineered and validated by a single parse-or-retry helper
defined once at `explanability_demo/backend/llm.py::call_llm_json`.

### 8.6 No vector store needed
Because we don't compute embeddings, the SQLite schema in §11 drops the
`chunk_embedding` table. BM25 over `chunk_fts` is the only retrieval index.

---

## 9. Backend API surface

All under `/demo/v1/...` to avoid colliding with the existing `/v1/...`.

| Method | Path | Returns |
|---|---|---|
| GET | `/processes` | `[{name, title, description, icon, file_count, edge_count}]` |
| GET | `/processes/{P}` | full `metadata.json` + counts + KB build status |
| GET | `/processes/{P}/summary` | `{summary_short, summary_long, key_steps, key_variables_top10}` |
| GET | `/processes/{P}/files` | `[{path, kind, purpose, narrative}]` (file inventory) |
| GET | `/processes/{P}/files/{rel}` | `{purpose, narrative, blocks:[{id, purpose, behavior, calls, variables_touched}], block_graph:{nodes,edges}}` |
| GET | `/processes/{P}/variables` | `[{name, kind, origin, purpose}]` paginated, filterable |
| GET | `/processes/{P}/variables/{V}` | declaration metadata + per-file occurrence stats |
| POST | `/processes/{P}/variables/{V}/setter-flows` | Stats: file-flows in which V is set; for each: `{chain, modifier_file, evidence_summary}` |
| POST | `/processes/{P}/variables/{V}/usage-flows` | Same shape, but forward |
| POST | `/processes/{P}/variables/{V}/investigation/{direction}` (SSE) | Streams messages M1, M2, ... + cited sources, one event per iteration |
| POST | `/processes/{P}/chat` (SSE) | Process-level chat |
| POST | `/processes/{P}/variables/{V}/chat` (SSE) | Variable-level chat (seeded with last investigation thread) |
| POST | `/processes/{P}/build` | Kicks off the knowledge-extraction pipeline (idempotent, resumable) |
| GET | `/processes/{P}/build/status` | Phase, files done / total, blocks done / total, ETA |

SSE event shape:
```json
{"event":"message","data":{"i":1,"text":"...","sources":[{"id":"chunk:xxx","file":"...","line_range":[854,871],"label":"Set in DA780000"}]}}
{"event":"done","data":{"total":7}}
```

---

## 10. Frontend architecture

### 10.1 Stack
- **React 18 + Vite + TypeScript** — fastest setup, no SSR needed.
- **Tailwind CSS** + **shadcn/ui** (Radix primitives) — consistent design language without designing every component.
- **TanStack Query** — server-state cache & refetch (huge for "summary fetched once, reused everywhere").
- **React Flow (xyflow)** — interactive graphs (file graph, block graph). Dagre / ELK layout.
- **react-markdown** + **remark-gfm** + **mermaid-react** — render chat / explanation content.
- **EventSource** (native) — SSE for chunked explanation streams.

### 10.2 Views

**(V1) Process list** — `/`
- Grid of process cards (icon, name, description, "Build status: ready/building/pending"). Click → V2.

**(V2) Process detail** — `/p/:P`
- Top: short summary chip + "Read full summary" expand → long markdown.
- Tabs: **Overview** (long summary + "Ask anything" chat button) | **Files** | **Variables** | **Chat**.
- "Ask anything" surfaces process-level chat (V6).

**(V3) Files view** — `/p/:P/files`
- **Split layout**: left = React Flow file graph (zoom / pan / click to filter); right = list of files (sortable by purpose). Clicking a node in the graph highlights it in the list and vice versa. Both selections deep-link to V4. *(Answer to your "list vs graph?" — show **both** in one screen, linked. Users self-select preferred mode.)*

**(V4) File detail** — `/p/:P/files/:rel`
- Header: file path, purpose, "Open raw source" (read-only).
- **Block / function graph** (React Flow) on top — for ASM files this is the intra-file CFG; for C++ this is the function-call graph.
- **Block list** below — table with columns: id, 1-line purpose, callees, variables touched. Row expansion shows the full behavior summary.
- Click a node in graph → scrolls to its row in list (and vice versa).

**(V5) Variables view** — `/p/:P/variables`
- Searchable list. Each row: `name`, `kind`, `origin`, `purpose`. Click → V7.

**(V6) Chat (process)** — `/p/:P/chat`
- Standard chat surface (reuses the visual language of `api/static/index.html`). Streams from `POST /processes/{P}/chat`. Citations appear inline as `[1]` and as a Sources panel.

**(V7) Variable detail** — `/p/:P/v/:V`
- Header: variable name, declaration site, type, scope, purpose.
- Two big buttons: **"Setter logic"** and **"Usage points"**.
- Clicking a button → V8.

**(V8) Investigation chooser** — `/p/:P/v/:V/:direction`
- Step 1: stats card — "Set in N file-flows" (or "Used across M file-flows"). For each flow, a card showing the chain summary (`lu82 → ... → da78`), modifier file purpose, and "how many evidence chunks". *Designed so the user can preview before committing to an explanation pass.*
- Step 2: user picks a flow → V9.

**(V9) Chunked explanation** — `/p/:P/v/:V/:direction/:flow_id`
- Streams M1 from SSE, renders as markdown + citation chips.
- "Explain more" button → triggers next SSE iteration; appends M2 below M1 (visually connected: a vertical line linking them).
- When iterations end: a divider, then variable chat field appears.

**(V10) Variable chat** — under V9
- Same chat UI; pre-loaded with M1..Mk + sources. Queries route through the variable-scoped retrieval.

### 10.3 Component reuse
- All chat surfaces share a single `<ChatStream/>` component.
- All graphs share `<Graph/>` (wraps React Flow with our node renderer).
- All citation chips → `<SourceChip/>` → click opens a side panel with line-anchored source snippet.

---

## 11. SQLite schema (`explanability_demo/backend/knowledge.db`)

```sql
CREATE TABLE process (
  name TEXT PRIMARY KEY,
  title TEXT, description TEXT, icon TEXT,
  file_count INTEGER, edge_count INTEGER,
  summary_short TEXT, summary_long TEXT,
  key_steps_json TEXT, key_variables_top10_json TEXT,
  build_phase TEXT, build_blocks_done INTEGER, build_blocks_total INTEGER,
  template_version TEXT, updated_at TEXT
);

CREATE TABLE file (
  process TEXT, path TEXT, kind TEXT,     -- 'asm' | 'cpp' | 'mac' | 'hpp'
  purpose TEXT, narrative TEXT,
  key_variables_json TEXT, key_callees_json TEXT,
  content_hash TEXT, template_version TEXT,
  PRIMARY KEY (process, path)
);

CREATE TABLE block (
  process TEXT, file_path TEXT, block_id TEXT,
  kind TEXT,                              -- 'asm_block' | 'cpp_function'
  line_start INTEGER, line_end INTEGER,
  purpose TEXT, behavior TEXT,
  calls_json TEXT,                        -- [{target, reason_business_language}]
  variables_touched_json TEXT,            -- [{name, role, purpose}]
  content_hash TEXT, template_version TEXT,
  PRIMARY KEY (process, file_path, block_id)
);

CREATE TABLE variable (
  process TEXT, name TEXT,
  origin TEXT,                            -- 'asm-runtime' | 'cpp'
  kind TEXT, declaration_file TEXT, declaration_line INTEGER,
  data_type TEXT, scope TEXT,
  purpose TEXT,
  PRIMARY KEY (process, name, declaration_file, declaration_line)
);

CREATE VIRTUAL TABLE chunk_fts USING fts5(
  chunk_id, process, kind, file_path, block_id, context_prefix, body,
  tokenize='porter unicode61'
);
-- (No chunk_embedding table: single-call_llm rule precludes embeddings; see §8.5)

CREATE TABLE investigation_message (
  flow_id TEXT, iteration INTEGER,
  direction TEXT,                         -- 'setter' | 'usage'
  variable TEXT, process TEXT,
  text TEXT, sources_json TEXT,
  created_at TEXT,
  PRIMARY KEY (flow_id, iteration)
);

CREATE TABLE conversation_message (     -- for chat surfaces
  conversation_id TEXT, idx INTEGER,
  role TEXT, text TEXT, sources_json TEXT,
  created_at TEXT,
  PRIMARY KEY (conversation_id, idx)
);
```

---

## 12. Quality / validation gates

- Every LLM call goes through `explanability_demo/backend/llm.py::call_llm_json(prompt, schema_hint, max_retries=3)`, a thin wrapper around `llm.caller.call_llm` that enforces JSON parsing + schema-hint validation. No code in `explanability_demo/` may import `google.genai`, `openai`, embedding APIs, or any reranker SDK — only `from llm.caller import call_llm`. A pre-commit hook can enforce this.
- Every "evidence" used in a UI message **must** carry `(file_path, line_start, line_end)`. The UI refuses to render a message whose `sources` list is empty.
- Build pipeline writes a **manifest** per process: `{template_version, block_counts, file_counts, gemini_calls, est_cost_usd, started_at, finished_at}`. Surfaced in `/processes/{P}/build/status`.
- Smoke test (`explanability_demo/tests/test_c400_smoke.py`): end-to-end build for C400 → assert all 16 files have file rows, all blocks have purpose, all variables have purpose, randomly sampled 5 evidence chunks have real source lines.

---

## 13. Phased delivery plan

| Phase | Deliverable | Approx |
|---|---|---|
| **P0 ✅** | C400 data fix (done in this session) | 0 |
| **P1** (this doc) | DESIGN.md approved | 0 |
| **P2** | `explanability_demo/backend` skeleton (FastAPI + SQLite + Gemini wrapper) + `/processes` and `/processes/{P}` endpoints (read from existing JSON) | 1 day |
| **P3** | Knowledge extraction pipeline (block + file + process passes) for C400. Resumable, with manifest. | 2–3 days |
| **P4** | Variable inventory extraction (filter + purpose pass). `/variables` endpoints. | 1 day |
| **P5** | Frontend P5a–P5d (List → Detail → Files (split graph+list) → Variables list) — read-only over P3/P4 data | 3 days |
| **P6** | `forward_traversal` package + `/setter-flows` + `/usage-flows` endpoints | 3–5 days |
| **P7** | Chunked SSE investigation endpoint + V9 explanation UI | 2 days |
| **P8** | Retrieval / QA service (hybrid + rerank + synthesis) + chat surfaces (V6 + V10) | 3–4 days |
| **P9** | Polishing, validation, README per directory | 1 day |

Total: **≈ 16–20 working days** (≈ 3–4 weeks calendar).

---

## 14. Open questions for the user

Numbered so you can answer just `Q1: ...`, `Q2: ...`:

- **Q1.** ✅ **Resolved** — React + Vite + Tailwind + shadcn/ui.
- **Q2.** ✅ **Resolved** — On-demand per process (build kicks off when first opened).
- **Q3.** ✅ **Resolved** — Single `call_llm` rule (Gemini 2.5 Pro, prompt-engineered JSON, used for both rerank and synthesis). No separate reranker. §8.3 / §8.5 updated.
- **Q4.** ✅ **Resolved** — Session-local chat memory (no auth needed). Investigation messages persisted in SQLite per `flow_id`.
- **Q5.** ✅ **Resolved** — Files view: 50/50 split (graph left, list right), with cross-highlight selection.
- **Q6.** ✅ **Resolved** — Forward_traversal writes **partitioned** output (one file per dep_var), matching `backward_traversal`. Enables the SSE "Explain more" endpoint to stream one dep_var file per iteration without loading everything in memory.

> **All six structural decisions are now locked. Phase 2 begins on next session.**

---

## 15. References (validated during audit)

- `backward_traversal` architecture: matches the memory entry but verified against `runner/backward_only_runner.py`, `tracing/asm_backward_tracer.py`, output schema in `runner/output_writer.py` (single + partitioned modes).
- Variable universe trustworthiness: numbers in §6 are from a fresh count over `temp/output_latest/asm_variable_universe.json` and `cpp_variable_universe.json` filtered to the 16-file C400 scope.
- Existing `api/` surface: enumerated in `explanability_demo/docs/backend_audit.md` (to be written from the audit run done in this session).
- Process truncation pipeline: §1 of `process/Algorithm.md`.
- Contextual Retrieval (Anthropic, 2024): `https://www.anthropic.com/news/contextual-retrieval` — referenced in §8.3.
- Reciprocal Rank Fusion: Cormack et al., 2009 — used for BM25/dense fusion.
