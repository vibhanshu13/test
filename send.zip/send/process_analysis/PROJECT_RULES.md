# Project Rules — explanability_demo

Non-negotiable rules that override any default behavior in DESIGN.md, the
trackers, or task descriptions. If any future change conflicts with a rule
here, the rule wins.

Last updated: 2026-05-27

---

## Rule 1 — Single LLM entry point

Every LLM interaction in `explanability_demo/` goes through
`llm/caller.py::call_llm(prompt, system_prompt=None) -> str`, wrapped by
`backend/llm.py::{call_llm_text, call_llm_json}`. Only Gemini 2.5 Pro. No
embedding APIs, no separate Flash model, no other vendors.

Enforced by: `backend/tests/test_smoke.py::test_no_direct_llm_sdk_imports_in_explanability_demo`.

## Rule 2 — Research latest tech before introducing it; get explicit approval

**Before** adopting any technique, library, framework, model, or pattern for
a use case, do two things in order:

1. **Research the current (2025-2026) state of the art** for that use case
   — what are the leading approaches today, what are their tradeoffs, what
   has been deprecated or surpassed since training cutoff. Use WebSearch /
   WebFetch / context7 / first-party docs.

2. **Present 2–4 candidates with tradeoffs and a recommendation, then wait
   for explicit user approval.** Do not implement before approval.

This applies to:
- Libraries / dependencies (graph viz, vector store, retrieval, validators…)
- Algorithms / patterns (topo-sort variant, dedup strategy, parsing
  approach, structured-output enforcement…)
- Models / providers (which Gemini variant, embedding model, reranker…)
- Architectural choices (background workers, queue systems, caches…)

What DOES NOT need pre-approval:
- Python stdlib usage.
- Files / patterns already approved in DESIGN.md or PROJECT_RULES.md.
- Bug fixes, refactors that don't change tech.
- Documentation, tests, READMEs.

How to present a research outcome to the user:

```
TECH DECISION needed for <use case>:

Researched 2025-2026 options:
  A. <option> — <when good, when bad>
  B. <option> — ...
  C. <option> — ...

Recommendation: <option> because <one-line reason>.

Sources: <links you actually fetched>
```

Then ask via AskUserQuestion.

## Rule 3 — Validations must include live runs whenever possible

Every validation entry in `VALIDATION_TRACKER.md` should have a **live**
counterpart unless the check is fundamentally synthetic (e.g., a static
lint over Python source).

For LLM-driven work:
- Mocked unit tests prove that the *plumbing* works.
- A live Gemini call against a real chunk of code proves the *prompt and
  output shape* hold up in reality.

When a phase finishes, every ⏳-deferred live validation must be either:
- discharged (run, recorded), OR
- explicitly listed in the phase's "Open items" with a date/owner.

Phase cannot be marked ✅ in `DEV_TRACKER.md` while live validations remain
⏳ without a documented reason (cost, time, blocked-on-X).

## Rule 7 — Track every tech / tool / library / algorithm in `TECH_REGISTRY.md`

The moment something is **adopted** (a new library, a new model, a new
algorithm choice, a new framework, a new external service), add a row to
[`TECH_REGISTRY.md`](./TECH_REGISTRY.md):
- **What** it is and version.
- **Why** it was chosen (link to the AskUserQuestion approval id).
- **Where** it's used (modules / phases).

When something is **removed**, don't delete its row — mark it removed with a
date and one-line reason. The history matters for future audits.

For Rule 2 to be useful, this registry has to be honest. "Adoption" includes:
- pip installing a new package
- adding a `import` to a file in `explanability_demo/` of a non-stdlib name
- choosing an algorithm beyond a one-line stdlib pattern
- pointing at a new external service

Stdlib usage doesn't need approval, but the broader stdlib modules used
should still be listed in `TECH_REGISTRY.md` so the surface is visible.

## Rule 4 — Single source of truth: DEV_TRACKER + VALIDATION_TRACKER

Every implementation item belongs in `DEV_TRACKER.md` under its phase.
Every validation belongs in `VALIDATION_TRACKER.md`. No "side tracking" in
chat history or commit messages. If something isn't in the trackers, it
doesn't exist.

## Rule 6 — Validate parser output against source before consuming

Any field read from `temp/output_latest/` (ASM blueprints, C++ blueprints,
variable_universe, identity_index, etc.) must be **independently verified
against the actual source files** before any code in `explanability_demo/`
treats it as trusted input.

The validation must check, at minimum:
  - Line ranges match the source (the `start_line` actually has the expected
    label/signature; `end_line` doesn't cross into the next block/function).
  - IDs match real labels / function names that exist in the source.
  - Cross-references (call_graph edges, variable references) actually appear
    on the cited source lines.

If validation fails, choose one of these (Rule 5 forbids modifying the
parser script, since it lives outside `explanability_demo/`):
  1. **Use a different mechanism** — write our own deterministic extractor
     in `explanability_demo/backend/parser_validation/` (regex / tree-sitter
     via `py-tree-sitter`, after Rule 2 research+approval if it's a new
     library).
  2. **Restrict scope** — consume only the parser fields that *do* pass
     validation; fall back to source-scan for the rest.
  3. **Flag and skip** — for fields that are partially broken and not
     critical (e.g. `key_callees` enrichment), mark the related feature as
     degraded in the UI and continue.

Every consumer of a parser field carries a one-line comment pointing at the
specific validation it relied on (the VALIDATION_TRACKER row id).

Enforced by: `explanability_demo/scripts/validate_parser_output.py` (added
P3-retro; see V_PARSER_* rows in VALIDATION_TRACKER). This script must be
re-run whenever the parser corpus is regenerated, whenever a new field is
consumed, and whenever a process scope expands.

## Rule 5 — Code changes only inside `explanability_demo/`

The exception is the regenerated process-data files under
`data/processes/<P>/` (these are data, not code), and config-only changes
to the shared `.env` (with explicit user approval, per Rule 2 — already
granted once for `LLM_MAX_TOKENS=8192`).

Enforced by: convention. Every PR review should confirm the diff doesn't
touch `api/`, `backward_traversal/`, `process/`, `llm/`, etc.

---

## Empirical findings (build these into future decisions)

### EF-1 — ASM variable filter must use `kind == "memory"`, not just `is_runtime_symbol`

DESIGN.md §6 originally proposed filtering ASM variables by
`metadata.is_runtime_symbol == True`. The first P4 live validation run
(50-sample, 2026-05-27) showed 72% pass rate with judge feedback that 14/14
failures were code labels described as "procedures" rather than data.

Profiling the in-scope C400 ASM entries after the `is_runtime_symbol`
filter: 765 of 831 (92%) were `EQU` declarations — code labels, not data.

**Decision (empirical, not user-redirected):** add a second filter,
`kind == "memory"`, which keeps only `DS`/`DC` storage definitions. This
reduces in-scope ASM variables from 831 → 66 (true data items).

This is NOT a tech change requiring Rule 2 approval — it's a tightening of
an already-approved filter discovered through live validation per Rule 3.
Same general technique, narrower predicate.

If a future use case wants the EQU code labels too (e.g., "show me all
named code points in this process"), they should be exposed as a SEPARATE
inventory type, not mixed into "variables".

## Retro-application notes (Phase 3)

These items existed before Rule 2/3 were written; flagging for follow-up:

- **Phase 3 mechanism choices were not pre-researched against alternatives.**
  Specifically:
  - `_parse_or_retry` for structured-output enforcement — alternatives that
    should have been weighed: `pydantic-ai`, `instructor`, `outlines`,
    `mirascope`, raw `responseSchema` (blocked by Rule 1).
  - `threading.Thread` for background builds — alternatives: FastAPI
    `BackgroundTasks`, `arq`, `dramatiq`, `huey`, Celery (already in repo
    for the existing api/).
  - `sqlite-fts5` for retrieval index (planned in DESIGN §8.3) — needs
    re-research before Phase 8: `tantivy-py`, `meilisearch` embeddable,
    Postgres `pgroach`, etc.

  These are flagged for review at the start of Phase 8 and any time before
  introducing new code into the same area. The current implementations are
  acceptable demo-level choices; alternatives will be re-evaluated when
  scaling beyond a single process.

- **Phase 3 has one ⏳ live validation deferred** (V3.3: full live C400
  build, ~800 LLM calls, ~$5-10 cost). Per Rule 3, this needs to be either
  discharged before Phase 4 finishes, or explicitly justified for later
  deferral.
