# ASM Modernizer — Explainability Demo: Technical Overview

**Audience:** Tech manager reviewing the system end-to-end.
**Date:** 2026-05-27

---

## What This System Does

Takes a z/TPF mainframe process (a cluster of ASM + C++ source files) and:

1. **Builds a structured knowledge base** — summarises every block, file, and the whole process in plain business English using an LLM.
2. **Provides variable-level lineage tracing** — shows forward dataflow (where a variable is set, where it flows downstream) across files and language boundaries (ASM ↔ C++).
3. **Exposes an adaptive-RAG chat agent** — answers free-form questions about the process by combining BM25 retrieval, LLM reranking, and a ReAct tool-call loop, citing every claim with exact file + block references.
4. **Serves a web UI** — React 19 frontend with process/file/variable browsing, investigation timelines, and chat interfaces.

The system is built for **demo / explainability**, not production deployment, but every mechanism is production-grade internally.

---

## High-Level Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│  Source data (read-only, on disk)                                │
│  file_graph.json  |  blueprints/*.json  |  variable_universe.json│
└────────────────────────────┬─────────────────────────────────────┘
                             │
                    ┌────────▼─────────┐
                    │  Knowledge build  │  (one-time offline pass)
                    │  3-pass pipeline  │
                    └────────┬─────────┘
                             │ upserts
                    ┌────────▼─────────┐
                    │   SQLite DB      │  knowledge.db (WAL mode)
                    │ + FTS5 index     │
                    └────────┬─────────┘
                             │
              ┌──────────────┼───────────────┐
              │              │               │
     ┌────────▼───┐  ┌───────▼──────┐  ┌────▼────────────┐
     │  REST API  │  │ Variable     │  │ Chat agent      │
     │ (FastAPI)  │  │ investigation│  │ (ReAct + SSE)   │
     └────────┬───┘  │ (SSE)        │  └────┬────────────┘
              │      └──────────────┘        │
              └──────────────┬───────────────┘
                             │
                    ┌────────▼─────────┐
                    │  React frontend  │
                    │  (Vite + TanStack│
                    │   Router/Query)  │
                    └──────────────────┘
```

---

## Source Data (Input)

The system reads from pre-generated static files on disk. **Nothing in this demo touches raw ASM source directly** — all parsing was already done upstream.

| File | Content | Used by |
|---|---|---|
| `file_graph.json` | Directed call graph: nodes = files, edges = call relationships, seed file/function | Pipeline, API |
| `blueprints/<file>.json` | Block-level parse of each source file: blocks with line ranges, intra-file call graph, instruction list | Pipeline, forward traversal |
| `variable_universe.json` | Full variable inventory: name, origin (asm-runtime / cpp), declaration file + line, data type, scope | Variable API |
| `headers.json` | Include-file scan results (C++ / ASM includes) | API |
| `macros.json` | ASM macro index | API |

---

## 1. Knowledge Build Pipeline

**Entry point:** `POST /demo/v1/processes/{P}/build`
**Implementation:** `backend/pipeline/runner.py`

### Three-Pass Architecture

```
Blueprints on disk
     │
     ▼ enumerate_file()
 Block objects (id, kind, line range, intra-file callees)
     │
     ▼ Pass 1 — Block summaries
 Each block → LLM → {purpose, behavior, calls[], variables_touched[]}
 Stored in: block table
     │
     ▼ Pass 2 — File summaries
 All block summaries in a file → LLM → {file_purpose, narrative, key_variables[], key_callees[]}
 Stored in: file table
     │
     ▼ Pass 3 — Process summary
 All file summaries → LLM → {summary_short, summary_long, key_steps[], key_variables_top10[]}
 Stored in: process table
```

### Parallelism Strategy

Two levels of parallelism run together:

- **Intra-file (within one file):** Blocks at the same topological depth (callees-first ordering) have no dependencies on each other and run in parallel via `ThreadPoolExecutor`. A callee's summary is always available before its caller is processed.
- **Inter-file (across files):** Files at the same depth in the process call graph run in parallel. A callee file's summary is always available when the calling file is processed.

This gives near-optimal throughput while preserving correctness guarantees.

### Resumability / Caching

Every block, file, and process row stores a `content_hash` = SHA256 of `(source_text + prompt_template_version)`.

- On re-run: rows whose hash matches the stored hash are **skipped** (zero LLM calls).
- To force a full rebuild: bump `TEMPLATE_VERSION` constant.
- **Measured cache rate on no-op rerun:** 804/804 (100%) hits for block + file passes. Process-level summary makes 1 LLM call (known followup).

### LLM Interface Rule

**One function, one model, everywhere in the codebase:**

```python
call_llm_model(prompt, ResponseSchema, system_prompt=..., max_retries=2)
call_llm_json(prompt, schema_description, ...)
```

Both ultimately call **Gemini 2.5 Pro** via the Google GenAI SDK. No other LLM call exists anywhere in the demo codebase (enforced as a hard rule).

JSON schema compliance is enforced by structured output (Pydantic model) + retry logic. Retry on parse failure, never on network failure.

### What Gets Stored Per Block

```json
{
  "purpose": "1-2 sentence business-language summary",
  "behavior": "3-6 sentence technical description",
  "calls": [
    { "target": "subroutine_name", "reason_business_language": "why it calls this" }
  ],
  "variables_touched": [
    { "name": "VAR", "role": "read|write|both", "purpose": "what this variable means here" }
  ]
}
```

---

## 2. SQLite Knowledge Database

**File:** `knowledge.db` (WAL mode, autocommit connections)
**Schema:** `backend/schema.sql`

| Table | Key columns | Purpose |
|---|---|---|
| `process` | name, title, description, summary_short, summary_long, build_phase, build_blocks_done, build_blocks_total, content_hash | Top-level process metadata + build state |
| `file` | process, path, kind, purpose, narrative, key_variables_json, key_callees_json, content_hash | File-level LLM summaries |
| `block` | process, file_path, block_id, kind, line_start, line_end, purpose, behavior, calls_json, variables_touched_json, content_hash | Block/function-level LLM summaries |
| `variable` | process, name, origin, kind, declaration_file, declaration_line, data_type, scope, purpose | Variable inventory with LLM-generated purpose |
| `chunk_fts` | FTS5 virtual table | Full-text search index over all summaries |
| `investigation_message` | flow_id, iteration, direction, variable, process, text, sources_json | Persisted variable investigation steps (for chat seeding) |
| `conversation_message` | conversation_id, idx, role, content | General chat history |

### FTS5 / BM25 Search Index

Every entity (process summary, file summary, block summary, variable purpose) is indexed as a "chunk" in the FTS5 virtual table. This enables BM25-scored full-text search across the entire knowledge base in a single SQL query. The query sanitisation layer tokenises the input, ORs the tokens, and filters single-character noise.

---

## 3. Variable Investigation (Forward Traversal)

**Entry point:** `POST /demo/v1/processes/{P}/variables/{V}/investigation/{direction}`
**Implementation:** `forward_traversal/runner.py`, `forward_traversal/expand.py`

### What It Does

Traces **where a variable comes from (setter)** and **where it flows (usage)** across the full process file graph, crossing ASM ↔ C++ language boundaries.

### Language-Specific Tracers

| File kind | Tracer used |
|---|---|
| `.asm` | `ForwardLineageTracer` — upstream pure-ASM tracer operating on blueprint blocks |
| `.cpp` / `.hpp` | `cpp_forward_tracer` — custom BFS over global variable location (GVL) entries in the blueprint |

The runner detects file kind from the declaration file extension and dispatches accordingly.

### Output Shape (written to a temp directory)

```
<temp_dir>/
  manifest.json          — node/role counts, caps hit, timing
  root_var.json          — all trace nodes + edges for the primary variable
  dep_vars/<NAME>.json   — one file per variable that the primary variable depends on
  dep_files/cross_calls.json — cross-file call records
  warnings.json          — validation and tracer warnings
```

Each node carries: `file`, `line`, `block`, `role`, `inst`, `detail`, `depth`, `inst_class`, `to_file`, `callee_block`.

### Node Roles

| Role | Meaning |
|---|---|
| `SETTER` | Direct assignment to the variable |
| `SIDE_EFFECT_SETTER` | Indirect assignment (pointer, register chain) |
| `OVERWRITE` | Value overwritten |
| `USAGE_SEED` | First usage point |
| `CONDITION_TEST` | Variable tested in a branch condition |
| `BRANCH_ON_CONDITION` | Branch instruction triggered by the variable |
| `CROSS_FILE_CALL` | Call that carries the variable to another file |
| `SUBROUTINE_CALL` | Call to a subroutine within the same file |
| `SUBROUTINE_BODY` | Synthetic node from expanded subroutine body |

### Enrichment Steps Applied to Every Trace

1. **G6 — Subroutine expansion:** For every `SUBROUTINE_CALL` node, fetches the callee body from blueprint and inserts synthetic `SUBROUTINE_BODY` nodes.
2. **G13 — Instruction classification:** Classifies every instruction into one or more categories: setter, trigger, branch, subroutine, return, cross_file, register_move.
3. **G14 — OC/BZ reclassification:** Detects the z/TPF pattern of `OC reg,reg` (self-zero) followed by `BZ` within 2 lines and reclassifies both to `CONDITION_TEST` / `BRANCH_ON_CONDITION`.
4. **G7 — Rich graph enrichment:** Adds cross-file edge metadata (`to_file`, `callee_block`) and builds the `edges` list in `root_var.json`.
5. **G4 — Alias resolution:** Best-effort mapping of ASM ↔ C++ variable names via `VariableNameResolver`. Never raises; fails silently.

### Safety Caps

| Cap | Default | Config |
|---|---|---|
| Max trace nodes | 50,000 | `FORWARD_MAX_NODES` env var |
| Max visited set | 200,000 unique (file, line) pairs | Hardcoded |
| Subroutine expansion depth | 1 | `max_subroutine_depth` arg |
| Subroutine body nodes | 400 | `max_subroutine_nodes` arg |

All caps are recorded in `manifest.json` and surfaced to the frontend.

### Resumability

Same content-hash pattern as the pipeline: `SHA256(variable + declaration_file + TRACER_VERSION)`. On re-request with identical inputs, serves cached trace output from disk.

### Investigation → SSE Stream

After tracing, the investigation endpoint:
1. Partitions trace nodes into clusters (by file, up to `max_messages` clusters).
2. For each cluster, calls Gemini to synthesise one business-language paragraph citing the evidence.
3. Streams each paragraph as an SSE `message` event.
4. **Persists each message to SQLite** (`investigation_message` table) so the chat agent can be seeded with prior investigation context.

---

## 4. Chat Agent (Adaptive RAG + ReAct)

**Entry points:**
- `POST /demo/v1/processes/{P}/chat` — process-scoped
- `POST /demo/v1/processes/{P}/variables/{V}/chat` — variable-scoped (seeded with investigation history)

**Implementation:** `backend/agent/loop.py`, `backend/agent/tools.py`

### ReAct Loop

```
User message
     │
     ▼
System prompt + tool catalog + conversation history + (optional) prior investigation context
     │
     ▼ LLM (Gemini 2.5 Pro) → AgentStep JSON
     │
     ├─ tool_call → dispatch → tool result → append to history → loop
     │
     └─ final_answer → stream answer + sources → done
```

**Max iterations:** 8 (hard cap).
**History management:** Most recent 2 tool observations included in full; older ones truncated to 800 chars each; total history capped at 16,000 chars.

### Tool Catalog (6 deterministic tools)

| Tool | What it returns |
|---|---|
| `get_process_summary(process)` | LLM-generated title, short + long summary, build status |
| `list_files_in_process(process)` | File list with per-file purpose |
| `get_file_summary(process, file_path)` | File purpose, narrative, key variables and callees |
| `list_blocks_in_file(process, file_path)` | Block list with purposes |
| `get_block_summary(process, file_path, block_id)` | Full block: purpose, behavior, calls, variables touched |
| `get_variable_purpose(process, variable)` | Variable purpose + all declaration sites |
| `search_chunks(process, query, top_k, use_rerank)` | BM25 + optional LLM rerank; returns top matching chunks with citations |

All tools are **deterministic** — they read from the SQLite DB or static JSON files, never call the LLM.

### BM25 Retrieval

SQLite FTS5's native BM25 scoring over the full text of all blocks, files, variables, and process summaries. Query sanitisation tokenises input, filters noise, and constructs an OR query so partial matches are returned. Results carry `file`, `block_id`, and `line_range` for citations.

### LLM Reranking (8.1.4)

After BM25, the top 16 hits are sent to Gemini with a reranking prompt. Gemini returns a `RerankedIndices` JSON (just the ordered indices). On any parse error, falls back to original BM25 order — never breaks the agent loop.

### Chat Seeding from Investigation

When using the variable-scoped chat endpoint, the agent's history block is prepended with up to 10 prior investigation messages from the `investigation_message` table. This means the LLM already knows what the investigation found and the conversation starts from a richer context.

### SSE Event Types

| Event | Payload |
|---|---|
| `thought` | Agent's private reasoning note for that iteration |
| `tool_call` | Which tool was called and with what arguments |
| `tool_result` | JSON observation returned by the tool |
| `answer` | Final business-language text + `sources[]` |
| `done` | Iteration count |
| `error` | Transport or agent failure message |

The frontend renders all of these, with the tool trace collapsible under each answer.

---

## 5. API Layer

**Framework:** FastAPI + uvicorn
**Base path:** `/demo/v1/`

### Endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Liveness check |
| GET | `/processes` | List all processes with build status |
| GET | `/processes/{P}` | Process detail (file graph, headers, macros, build progress) |
| GET | `/processes/{P}/file-graph` | Full file graph with edges |
| GET | `/processes/{P}/headers` | Include-file scan summary |
| GET | `/processes/{P}/macros` | ASM macro index |
| POST | `/processes/{P}/build` | Start knowledge build (async, 202) |
| GET | `/processes/{P}/build/status` | Build progress |
| GET | `/processes/{P}/variables` | Paginated + searchable variable list |
| GET | `/processes/{P}/variables/{V}` | Variable occurrences (all declaration sites) |
| POST | `/processes/{P}/variables/build` | Build variable summaries (async) |
| GET | `/processes/{P}/files/{path}` | File detail: block list + block graph + source snippets |
| POST | `/processes/{P}/variables/{V}/usage-flows` | Full forward trace manifest + dep_vars (JSON) |
| POST | `/processes/{P}/variables/{V}/investigation/{direction}` | Chunked LLM investigation SSE stream |
| POST | `/processes/{P}/chat` | Process-scoped agent chat SSE |
| POST | `/processes/{P}/variables/{V}/chat` | Variable-scoped agent chat SSE |

---

## 6. Frontend

**Stack:** React 19 + Vite 8 + TypeScript
**Routing:** TanStack Router (file-based, typed)
**Data fetching:** TanStack Query (30s stale time, no refetch on focus)
**Graph rendering:** React Flow v12 + elkjs (layered DAG layout)
**Animations:** Motion (framer-motion v11+)
**Toasts:** Sonner
**Theme:** OKLCH color palette, dark-default with light toggle, aurora backdrop

### Pages / Routes

| Route | What it shows |
|---|---|
| `/` | Process list with stat cards |
| `/p/:P` | Process layout with left sidebar nav (Overview / Files / Variables / Chat) |
| `/p/:P/` | Overview: stat summary, call graph edge breakdown, file list, includes/macros |
| `/p/:P/files` | File call graph (React Flow) + sortable file list |
| `/p/:P/files/:file` | File detail: block graph + block list with animated expand/collapse |
| `/p/:P/variables` | Variable list with search + origin filter + pagination |
| `/p/:P/v/:V` | Variable detail: declarations, setter/usage/chat action cards |
| `/p/:P/v/:V/investigation/:dir` | SSE investigation timeline with source chip expand-to-snippet |
| `/p/:P/v/:V/chat` | Variable-scoped chat (seeded from investigation history) |
| `/p/:P/chat` | Process-scoped chat |

### Key Frontend Mechanisms

- **SSE streaming:** Native `fetch` + `ReadableStream` SSE parser (no `EventSource` — needed POST). Shared pattern in `ChatStream` and investigation route.
- **Source chip → code viewer:** Clicking a source citation lazily fetches the file via TanStack Query and renders the raw source snippet inline with animated expand/collapse.
- **Cross-highlight:** In file detail and file graph views, selecting a node in the graph highlights the corresponding row in the block list and vice versa.
- **Blueprint LRU cache:** `blueprint_cache.py` caches loaded blueprint JSONs in an LRU cache (512 entries) with 3 retries on `OSError`, shared by all forward-traversal callers.

---

## 7. Key Engineering Decisions

| Decision | Rationale |
|---|---|
| Single LLM function (`call_llm_model`) | Prevents accidental model drift; one place to swap models or add tracing |
| SQLite + FTS5 (no vector DB) | No infra dependency; BM25 + LLM rerank achieves quality close to dense retrieval for structured code summaries |
| Content-hash resumability everywhere | Prevents re-billing on identical inputs; safe to run pipeline repeatedly without cost explosion |
| Topological parallelism (intra + inter file) | Maximises concurrency while guaranteeing callee-before-caller ordering for accurate summaries |
| ReAct with deterministic tools | LLM reasons; tools retrieve — no hallucinated file paths or block IDs |
| SSE for all LLM responses | First token appears immediately; user sees agent working live |
| Investigation → chat seeding | Carries the variable lineage narrative into the chat without the user needing to repeat context |
| Node/visited caps on forward traversal | Prevents runaway traces on deeply connected variables; always terminates |

---

## 8. Data Volume (Process C400)

| Metric | Value |
|---|---|
| Files in process | 16 (mix of ASM + C++) |
| Call edges | 88 |
| Blocks summarised | 788 |
| Variables indexed | 226 |
| Build time (cold, parallel) | ~8 min |
| Build time (warm, all cached) | ~17 sec |
| BM25 index size | FTS5 over all chunk bodies |

---

## 9. Testing

- **Unit tests:** 140 tests covering pipeline caching, forward traversal (callee finders, G4 aliases, G7 graph, G14 OC/BZ reclassification, G16 blueprint cache), investigation/chat seeding, reranking, file cache stability, cross-file parallelism.
- **Validation scripts:**
  - `scripts/snapshot_v33.py` — confirms 0 unexpected LLM calls on no-op pipeline rerun
  - `scripts/validate_v6_v7.py` — live HTTP assertions on usage-flow manifest shape + investigation SSE contract (V6.4 / V7.1–V7.3)
  - `scripts/e2e_smoke.sh` — 13-endpoint smoke test bringing backend up from scratch
- **Playwright E2E (14 tests):**
  - V5.6: No console errors on 5 key views
  - V7.4: Investigation single-shot mode confirmed (no re-fire risk)
  - V9.1: Full 8-step happy path (process → file → variable → investigation → chat)

---

## 10. What Is NOT In Scope (Known Followups)

| Item | Status |
|---|---|
| Backward traversal integration (setter direction uses forward's side-effect nodes as proxy) | Deferred |
| Process-level summary content-hash caching | 1 LLM call per rerun; followup item |
| Playwright automation for V7.4 "Explain more" and V9.1 full sweep | Implemented and passing |
| Variable build (purpose generation) being async | In place; polling endpoint available |
| Multi-process support | Architecture ready; only C400 loaded in demo data |
