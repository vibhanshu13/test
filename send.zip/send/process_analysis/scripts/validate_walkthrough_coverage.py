#!/usr/bin/env python3
"""Walkthrough coverage and no-technical-names validator (P14d.5 + P14d.6).

Two checks run in sequence:
  1. Coverage: union of source_block_ids_json across all cards must equal the
     eligible walk_node set (status != 'skipped-utility' AND NOT in walk_truncation).
  2. No-technical-names: scan title, body, bridge_to_next of every card for
     forbidden tokens (file extensions, macro patterns, register patterns, etc.).

Usage:
    python validate_walkthrough_coverage.py [--process C400] [--project-id default]
    python validate_walkthrough_coverage.py --check coverage
    python validate_walkthrough_coverage.py --check names

Exit code 0 = all selected checks pass, 1 = any failure.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import List, Set

# Make the project importable
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from process_analysis.backend.db import get_conn


# ---------------------------------------------------------------------------
# Forbidden-token patterns for check 2 (no-technical-names)
# ---------------------------------------------------------------------------
_FORBIDDEN_PATTERNS = [
    (re.compile(r"\.\b(asm|mac|cpp|hpp|h|c)\b", re.IGNORECASE), "file extension"),
    (re.compile(r"\bDB[A-Z]{3,}\b"), "DB macro opcode (e.g. DBRED, DBWRT)"),
    (re.compile(r"\bTX[A-Z]{3}\b"), "TX macro opcode (e.g. TXBGC, TXCMC)"),
    (re.compile(r"\b(?:R|WA|WK_)[0-9A-Z]{1,5}\b"), "register or work-area name"),
    (re.compile(r"\b[A-Z0-9]{4,8}\b(?!\s*:)"), "uppercase 4-8 char entity ID (possible raw code)"),
]
# Allowlist — entity IDs that are known business names and should not be flagged
_ALLOWLIST = re.compile(r"\b(C400|C112)\b")


def _check_coverage(process: str, project_id: str) -> bool:
    """Check 1: all eligible walk_node blocks appear in at least one card."""
    with get_conn() as conn:
        # Eligible walk_nodes: status != 'skipped-utility'
        eligible_rows = conn.execute(
            "SELECT DISTINCT file || '::' || block as id FROM walk_node "
            "WHERE process=? AND status != 'skipped-utility'",
            (process,),
        ).fetchall()
        eligible: Set[str] = {r["id"] for r in eligible_rows}

        # Truncated blocks (excluded from coverage requirement)
        # walk_truncation.skipped_block_ids is a JSON list of block IDs
        truncated: Set[str] = set()
        if _table_exists(conn, "walk_truncation"):
            trunc_rows = conn.execute(
                "SELECT skipped_block_ids FROM walk_truncation WHERE process=?",
                (process,),
            ).fetchall()
            for r in trunc_rows:
                try:
                    ids = json.loads(r["skipped_block_ids"] or "[]")
                    truncated.update(ids)
                except Exception:
                    pass

        # All cards and their source_block_ids_json
        card_rows = conn.execute(
            "SELECT card_id, source_block_ids_json FROM process_narrative_card WHERE process=?",
            (process,),
        ).fetchall()

    if not card_rows:
        print(f"[SKIP] No walkthrough cards found for {process} — pipeline may not have run.")
        return True

    covered: Set[str] = set()
    for r in card_rows:
        try:
            ids = json.loads(r["source_block_ids_json"] or "[]")
            covered.update(ids)
        except Exception:
            pass

    eligible_minus_truncated = eligible - truncated
    orphans = eligible_minus_truncated - covered

    if orphans:
        print(f"[FAIL] Coverage: {len(orphans)} eligible walk_node blocks not covered by any card:")
        for o in sorted(orphans)[:20]:
            print(f"  {o}")
        if len(orphans) > 20:
            print(f"  ... and {len(orphans) - 20} more")
        return False

    print(f"[PASS] Coverage: {len(covered)} blocks covered across {len(card_rows)} cards "
          f"({len(eligible_minus_truncated)} eligible, {len(truncated)} truncated)")
    return True


def _table_exists(conn, name: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)
    ).fetchone()
    return bool(row)


def _check_no_technical_names(process: str) -> bool:
    """Check 2: no forbidden tokens in card title/body/bridge_to_next."""
    with get_conn() as conn:
        cards = conn.execute(
            "SELECT card_id, title, body, bridge_to_next FROM process_narrative_card WHERE process=?",
            (process,),
        ).fetchall()

    if not cards:
        print(f"[SKIP] No walkthrough cards found for {process}.")
        return True

    violations: List[str] = []
    for r in cards:
        fields = {
            "title": r["title"] or "",
            "body": r["body"] or "",
            "bridge_to_next": r["bridge_to_next"] or "",
        }
        for field_name, text in fields.items():
            for pattern, label in _FORBIDDEN_PATTERNS:
                hits = pattern.findall(text)
                # Remove allowlisted hits
                hits = [h for h in hits if not _ALLOWLIST.fullmatch(h)]
                if hits:
                    violations.append(
                        f"  card {r['card_id']} [{field_name}] — {label}: {hits[:3]}"
                    )

    if violations:
        print(f"[FAIL] No-technical-names: {len(violations)} violations found:")
        for v in violations[:30]:
            print(v)
        if len(violations) > 30:
            print(f"  ... and {len(violations) - 30} more")
        return False

    print(f"[PASS] No-technical-names: {len(cards)} cards checked, 0 violations")
    return True


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(description="Walkthrough coverage + no-technical-names validator")
    parser.add_argument("--process", default="C400", help="Process name (default: C400)")
    parser.add_argument("--project-id", default="default", help="Project ID (default: default)")
    parser.add_argument(
        "--check",
        choices=["coverage", "names", "all"],
        default="all",
        help="Which check to run (default: all)",
    )
    args = parser.parse_args()

    results = []
    if args.check in ("coverage", "all"):
        print(f"\n=== Check 1: Walkthrough coverage [{args.process}] ===")
        results.append(_check_coverage(args.process, args.project_id))

    if args.check in ("names", "all"):
        print(f"\n=== Check 2: No technical names [{args.process}] ===")
        results.append(_check_no_technical_names(args.process))

    print()
    if all(results):
        print("All checks PASSED.")
        return 0
    else:
        passed = sum(results)
        print(f"{passed}/{len(results)} checks passed. See failures above.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
