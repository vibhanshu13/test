#!/usr/bin/env python3
"""One-shot live sanity check: call Gemini on exactly ONE block and print the
parsed JSON. Validates V3.2 manually without burning a full process build.

Usage:
    env/bin/python process_analysis/scripts/sanity_check_llm.py
    env/bin/python process_analysis/scripts/sanity_check_llm.py --process C400 --file temp/asm/xh88.asm --block XH88

Picks the first ASM block + first C++ function in the process by default.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from process_analysis.backend.config import settings
from process_analysis.backend.llm import call_llm_json
from process_analysis.backend.pipeline.enumerate import enumerate_file
from process_analysis.backend.pipeline.runner import (
    BLOCK_ASM_TPL,
    BLOCK_CPP_TPL,
    BLOCK_REQUIRED_KEYS,
    BLOCK_SCHEMA,
    _load_process_inputs,
    _read_source_lines,
)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--process", default="C400")
    ap.add_argument("--file", default=None, help="repo-relative file path; default = first asm and cpp")
    ap.add_argument("--block", default=None, help="block id; default = first block in file")
    args = ap.parse_args()

    process = _load_process_inputs(args.process)
    targets = []   # list of (file_rel_path, block, kind)

    if args.file:
        fe = enumerate_file(settings.REPO_ROOT, args.file)
        chosen = next((b for b in fe.blocks if not args.block or b.id == args.block), None)
        if chosen is None:
            print(f"No block found matching {args.block}", file=sys.stderr)
            return 2
        targets.append((args.file, chosen, fe.file_kind))
    else:
        # First ASM file + first C++ file in the process.
        picked_kinds = set()
        for fp in process.files:
            try:
                fe = enumerate_file(settings.REPO_ROOT, fp)
            except FileNotFoundError:
                continue
            if not fe.blocks or fe.file_kind in picked_kinds:
                continue
            picked_kinds.add(fe.file_kind)
            targets.append((fp, fe.blocks[0], fe.file_kind))
            if len(picked_kinds) >= 2:
                break

    if not targets:
        print("No targets found", file=sys.stderr)
        return 1

    for fp, block, kind in targets:
        source_text = _read_source_lines(fp, block.line_start, block.line_end)
        tpl = BLOCK_ASM_TPL if kind == "asm" else BLOCK_CPP_TPL
        prompt = tpl.format(
            process_name=process.name,
            process_description=process.description,
            file_path=fp,
            file_kind=kind,
            block_id=block.id,
            line_start=block.line_start,
            line_end=block.line_end,
            callee_purposes="(no callee summaries available for sanity check)",
            source_text=source_text,
        )
        print("=" * 78)
        print(f"File   : {fp}")
        print(f"Block  : {block.id}  (lines {block.line_start}-{block.line_end})")
        print(f"Kind   : {kind}")
        print(f"Source : {len(source_text)} chars")
        print("=" * 78)
        try:
            result = call_llm_json(
                prompt,
                schema_hint=BLOCK_SCHEMA,
                required_keys=BLOCK_REQUIRED_KEYS,
                max_retries=3,
            )
        except Exception as exc:
            print(f"FAILED: {exc}", file=sys.stderr)
            return 3
        print(json.dumps(result, indent=2))
        print()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
