"""Reset the process_analysis knowledge.db — delete it and recreate from scratch
with the latest schema.

`init_schema()` is additive only (CREATE IF NOT EXISTS + ALTER-if-missing), so it
can never give you a truly clean database. This script does: it removes the
SQLite file at ``settings.DB_PATH`` (plus its ``-wal`` / ``-shm`` sidecars), then
calls ``init_schema()`` to rebuild every table and index from ``schema.sql``.

Portable: the path is derived from the repo location (``settings.DB_PATH``), so
running this on another machine resets that machine's own knowledge.db.

Usage:
    python3 process_analysis/scripts/reset_db.py          # asks for confirmation
    python3 process_analysis/scripts/reset_db.py --yes     # no prompt (CI / scripted)
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))  # repo root on sys.path

from process_analysis.backend.config import settings  # noqa: E402
from process_analysis.backend.db import get_conn, init_schema  # noqa: E402


def _sidecars(db_path: Path) -> list[Path]:
    """The SQLite file and its WAL-mode sidecars."""
    return [db_path, Path(f"{db_path}-wal"), Path(f"{db_path}-shm")]


def reset(db_path: Path) -> None:
    # 1) Delete the existing DB + sidecars.
    for p in _sidecars(db_path):
        if p.exists():
            p.unlink()
            print(f"[deleted] {p}")
        else:
            print(f"[skip]    {p} (not present)")

    # 2) Recreate with the latest schema.
    db_path.parent.mkdir(parents=True, exist_ok=True)
    init_schema()
    print(f"[created] {db_path} with latest schema")

    # 3) Verify — list tables (sanity check that hier_* exist).
    with get_conn() as conn:
        tables = [
            r[0]
            for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            ).fetchall()
        ]
    hier = [t for t in tables if t.startswith("hier_")]
    print(f"[verify]  {len(tables)} tables created; hierwalk tables: {hier}")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--yes", action="store_true", help="skip the confirmation prompt")
    args = ap.parse_args()

    db_path = settings.DB_PATH
    print(f"Target database: {db_path}")

    # Warn about the known stray copy (created when a script runs from the wrong cwd).
    stray = settings.REPO_ROOT / "process_analysis" / "knowledge.db"
    if stray.exists() and stray.resolve() != db_path.resolve():
        print(f"[note]    a stray copy exists at {stray} — not touched by this script")

    if not args.yes:
        reply = input("This DELETES the entire database. Type 'yes' to proceed: ").strip()
        if reply.lower() != "yes":
            print("Aborted.")
            return

    reset(db_path)
    print("[done] database reset complete.")


if __name__ == "__main__":
    main()
