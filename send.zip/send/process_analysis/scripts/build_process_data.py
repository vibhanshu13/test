#!/usr/bin/env python3
"""
build_process_data.py
=====================

Regenerate ``data/processes/<PROC>/{file_graph.json, headers.json, macros.json}``
from REAL deterministic-pipeline outputs (no LLM, no random stubs).

Source of truth chain (existing repo scripts; we only consume their output):

  1. ``process/extract_function_processes.py``        → lu82_function_processes.json
  2. ``process/extract_process_guarded_file_calls.py`` → process_guarded_file_calls.json
  3. ``file_call_graph.py``                            → process/file_call_graph.json
  4. ``process/build_process_truncated_file_graph.py`` → process/process_truncated_file_graph.json

This script consumes step 4's output, slices the requested process, and emits
the three artifacts the UI/API layer expects.

Why source-scan headers + macros (instead of parser blueprints):
  - In ``temp/output_latest/asm/<file>.json`` the ``file_dependencies`` and
    ``macro_expansions`` fields are present but populated with empty arrays /
    None objects. Treating them as trusted would silently zero out the UI.
  - Source scans (``#include`` for C++, opcode-vs-macro-name match for HLASM)
    are short, auditable, and produce the same shape the prior stub used.

Usage:
    python3 process_analysis/scripts/build_process_data.py --process C400
    python3 process_analysis/scripts/build_process_data.py --process C400 --dry-run

Outputs are written atomically (``.tmp`` then ``os.replace``).
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from collections import OrderedDict
from pathlib import Path
from typing import Dict, List, Tuple

REPO_ROOT = Path(__file__).resolve().parents[2]
TEMP_ASM = REPO_ROOT / "temp" / "asm"
PROCESS_OUT = REPO_ROOT / "process" / "process_truncated_file_graph.json"
DATA_PROCESSES = REPO_ROOT / "data" / "processes"

# Extension → "side" used to derive edge_type strings.
SIDE_BY_EXT = {
    ".asm": "asm",
    ".mac": "asm",
    ".cpp": "cpp",
    ".hpp": "cpp",
    ".h":   "cpp",
}

INCLUDE_RE = re.compile(r'^\s*#\s*include\s*[<"]([^>"]+)[">]')

# HLASM comment lines start with ``*`` in column 1. Continuation lines have a
# non-blank char in column 72; we ignore that complexity for opcode scanning
# because macro names only appear at opcode position on statement-start lines.
ASM_OPCODE_RE = re.compile(
    r"^(?P<label>[A-Z@$#_][A-Z0-9@$#_]*)?\s+(?P<opcode>[A-Z@$#_][A-Z0-9@$#_]*)"
)


# ---------------------------------------------------------------------------
# File-id → physical path resolution
# ---------------------------------------------------------------------------

def _build_file_id_index(temp_asm: Path) -> Dict[str, Path]:
    """Map ``basename-no-ext (lowercase)`` → absolute Path under temp/asm."""
    index: Dict[str, Path] = {}
    if not temp_asm.is_dir():
        raise FileNotFoundError(f"temp/asm pool not found: {temp_asm}")
    for p in sorted(temp_asm.iterdir()):
        if not p.is_file():
            continue
        if p.suffix.lower() not in SIDE_BY_EXT:
            continue
        index[p.stem.lower()] = p
    return index


def _rel_path(p: Path) -> str:
    """Return repo-relative POSIX path string."""
    return p.relative_to(REPO_ROOT).as_posix()


def _edge_type(src_path: Path, tgt_path: Path) -> str:
    src_side = SIDE_BY_EXT.get(src_path.suffix.lower(), "asm")
    tgt_side = SIDE_BY_EXT.get(tgt_path.suffix.lower(), "asm")
    return f"{src_side}_to_{tgt_side}"


# ---------------------------------------------------------------------------
# file_graph.json
# ---------------------------------------------------------------------------

def build_file_graph(
    process: str,
    truncated_payload: dict,
    file_id_index: Dict[str, Path],
) -> Tuple[dict, List[Path]]:
    """Return (file_graph_dict, sorted_list_of_files_in_graph)."""

    procs = truncated_payload.get("processes") or {}
    if process not in procs:
        raise KeyError(
            f"Process '{process}' not present in {PROCESS_OUT.name}. "
            f"Available: {sorted(procs.keys())[:20]}..."
        )
    proc_payload = procs[process]
    nodes_in: List[str] = proc_payload.get("nodes") or []
    edges_in: List[dict] = proc_payload.get("edges") or []
    seed_edges: List[dict] = proc_payload.get("seed_edges") or []

    # Resolve node ids → physical paths.
    unresolved: List[str] = []
    resolved_files: List[Path] = []
    for nid in sorted(set(n.lower() for n in nodes_in)):
        p = file_id_index.get(nid)
        if p is None:
            unresolved.append(nid)
        else:
            resolved_files.append(p)

    if unresolved:
        raise RuntimeError(
            f"Cannot resolve file ids to temp/asm paths: {unresolved}. "
            "Update temp/asm corpus or extend SIDE_BY_EXT."
        )

    # Always include the seed file (lu82.asm) in the file list — the truncated
    # graph treats lu82 as the *source* of the seed edge but only enumerates
    # internal targets in `nodes`. The seed source belongs in the graph too.
    for se in seed_edges:
        edge = se.get("edge") or {}
        src = (edge.get("source") or "").lower()
        if src and src not in [p.stem.lower() for p in resolved_files]:
            p = file_id_index.get(src)
            if p is None:
                raise RuntimeError(f"Seed source '{src}' missing from temp/asm.")
            resolved_files.append(p)

    resolved_files = sorted(set(resolved_files), key=lambda p: p.name.lower())

    # Build edges in legacy shape (one row per call-site).
    out_edges: List[dict] = []
    edge_types_count: Dict[str, int] = OrderedDict(
        (k, 0) for k in ("cpp_to_cpp", "cpp_to_asm", "asm_to_asm", "asm_to_cpp")
    )

    # Combine seed edges + internal edges so the seed dispatch is captured.
    combined: List[dict] = []
    for se in seed_edges:
        e = dict(se.get("edge") or {})
        # Carry seed metadata as note on the first call_site.
        if e:
            combined.append({**e, "_seed_meta": {
                "lu82_line": se.get("lu82_line"),
                "target_segment": se.get("target_segment"),
                "resolved_target": se.get("resolved_target"),
            }})
    combined.extend(edges_in)

    for e in combined:
        src_id = (e.get("source") or "").lower()
        tgt_id = (e.get("target") or "").lower()
        if not src_id or not tgt_id:
            continue
        src_path = file_id_index.get(src_id)
        tgt_path = file_id_index.get(tgt_id)
        if src_path is None or tgt_path is None:
            # seed source might be lu82 (already added above) — try once more
            continue

        etype = _edge_type(src_path, tgt_path)
        call_sites = e.get("call_sites") or []
        if not call_sites:
            # Synthetic placeholder so the edge isn't dropped.
            call_sites = [{
                "source_block": None,
                "target_module": tgt_id.upper(),
                "instruction": (e.get("instructions") or [None])[0],
                "line": None,
            }]

        for cs in call_sites:
            row = {
                "from_file": _rel_path(src_path),
                "from_function": cs.get("source_block"),
                "to_function": cs.get("target_module"),
                "to_file": _rel_path(tgt_path),
                "edge_type": etype,
                "instruction": cs.get("instruction"),
                "line": cs.get("line"),
                "ambiguous": False,
            }
            seed_meta = e.get("_seed_meta")
            if seed_meta:
                row["seed_meta"] = seed_meta
            out_edges.append(row)
            edge_types_count[etype] = edge_types_count.get(etype, 0) + 1

    # Pick seed_function: source_block of the seed dispatch into the process.
    seed_block = None
    seed_segment = None
    if seed_edges:
        first_seed = seed_edges[0]
        seed_segment = first_seed.get("target_segment")
        for cs in (first_seed.get("edge") or {}).get("call_sites") or []:
            if cs.get("line") == first_seed.get("lu82_line"):
                seed_block = cs.get("source_block")
                break
        if seed_block is None and (first_seed.get("edge") or {}).get("call_sites"):
            seed_block = (first_seed["edge"]["call_sites"][0] or {}).get("source_block")

    file_graph = {
        "seed_file": _rel_path(file_id_index["lu82"]) if "lu82" in file_id_index else None,
        "seed_function": seed_block,
        "seed_segment": seed_segment,
        "process": process,
        "file_count": len(resolved_files),
        "edge_count": len(out_edges),
        "edge_types": edge_types_count,
        "files": [_rel_path(p) for p in resolved_files],
        "edges": out_edges,
        "source": {
            "pipeline": "process/build_process_truncated_file_graph.py",
            "input": _rel_path(PROCESS_OUT),
            "truncation_mode": proc_payload.get("truncation_mode"),
            "blocked_edges_filtered_count": len(proc_payload.get("blocked_edges_filtered") or []),
        },
    }
    return file_graph, resolved_files


# ---------------------------------------------------------------------------
# headers.json (scan #include in .cpp/.hpp inside the graph)
# ---------------------------------------------------------------------------

def build_headers(files: List[Path], temp_asm: Path) -> dict:
    cpp_like = [p for p in files if p.suffix.lower() in (".cpp", ".hpp", ".h")]
    cpp_files = [p for p in cpp_like if p.suffix.lower() == ".cpp"]
    hpp_files = [p for p in cpp_like if p.suffix.lower() in (".hpp", ".h")]

    found: Dict[str, dict] = {}      # include_path → record
    missing: Dict[str, dict] = {}    # include_path → record

    for cpp in cpp_like:
        try:
            text = cpp.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for raw in text.splitlines():
            m = INCLUDE_RE.match(raw)
            if not m:
                continue
            inc = m.group(1).strip()
            resolved = temp_asm / Path(inc).name
            if resolved.is_file():
                rec = found.setdefault(inc, {
                    "include_path": inc,
                    "resolved_path": _rel_path(resolved),
                    "included_from_cpp": [],
                })
                if cpp.name not in rec["included_from_cpp"]:
                    rec["included_from_cpp"].append(cpp.name)
            else:
                rec = missing.setdefault(inc, {
                    "include_path": inc,
                    "included_from_cpp": [],
                })
                if cpp.name not in rec["included_from_cpp"]:
                    rec["included_from_cpp"].append(cpp.name)

    for rec in found.values():
        rec["included_from_cpp"].sort()
    for rec in missing.values():
        rec["included_from_cpp"].sort()

    return {
        "source_graph": f"data/processes/{{PROC}}/file_graph.json",
        "files_scanned": len(cpp_like),
        "cpp_files_scanned": len(cpp_files),
        "hpp_files_scanned": len(hpp_files),
        "total_unique_headers_found": len(found),
        "total_unique_headers_missing": len(missing),
        "headers_found": sorted(found.values(), key=lambda r: r["include_path"]),
        "headers_missing": sorted(missing.values(), key=lambda r: r["include_path"]),
    }


# ---------------------------------------------------------------------------
# macros.json (scan .asm files for opcodes that match known macro names)
# ---------------------------------------------------------------------------

def _build_macro_index(temp_asm: Path) -> Dict[str, Path]:
    """macro_name (uppercase) → path to .mac file."""
    out: Dict[str, Path] = {}
    for p in sorted(temp_asm.iterdir()):
        if p.suffix.lower() == ".mac":
            out[p.stem.upper()] = p
    return out


def build_macros(files: List[Path], temp_asm: Path) -> dict:
    macro_index = _build_macro_index(temp_asm)
    macro_names = set(macro_index.keys())

    asm_files = [p for p in files if p.suffix.lower() == ".asm"]
    results: Dict[str, dict] = OrderedDict()

    for asm in asm_files:
        try:
            text = asm.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        used: List[str] = []
        seen = set()
        for raw in text.splitlines():
            # Skip HLASM comment lines (asterisk in column 1) and blanks.
            if not raw.strip() or raw[:1] == "*":
                continue
            m = ASM_OPCODE_RE.match(raw)
            if not m:
                continue
            opcode = (m.group("opcode") or "").upper()
            if opcode in macro_names and opcode not in seen:
                seen.add(opcode)
                used.append(opcode)
        used.sort()
        mac_files = sorted({macro_index[name].name for name in used})
        results[asm.name] = {
            "macros_used": used,
            "mac_files": mac_files,
        }

    return {
        "macro_index_size": len(macro_index),
        "asm_files": sorted(p.name for p in asm_files),
        "results": results,
    }


# ---------------------------------------------------------------------------
# Atomic write
# ---------------------------------------------------------------------------

def _atomic_write_json(path: Path, payload: dict, dry_run: bool) -> None:
    if dry_run:
        print(f"[dry-run] would write {path} ({len(json.dumps(payload))} bytes)")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    os.replace(tmp, path)
    print(f"  wrote {path.relative_to(REPO_ROOT)}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    ap.add_argument("--process", required=True, help="Process name (e.g. C400)")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument(
        "--purge",
        action="store_true",
        help="Delete any other files in data/processes/<PROC>/ (besides "
             "metadata.json and predefined_questions.json) before writing.",
    )
    args = ap.parse_args()

    proc = args.process.strip().upper()

    if not PROCESS_OUT.is_file():
        sys.stderr.write(
            f"Missing {PROCESS_OUT}.\n"
            "Run the pipeline first:\n"
            "  python3 process/build_process_truncated_file_graph.py "
            "--process-json process/lu82_function_processes.json "
            "--guarded-json process/process_guarded_file_calls.json "
            "--file-call-graph process/file_call_graph.json "
            "--output process/process_truncated_file_graph.json\n"
        )
        return 2

    truncated = json.loads(PROCESS_OUT.read_text(encoding="utf-8"))
    file_id_index = _build_file_id_index(TEMP_ASM)

    file_graph, files_in_graph = build_file_graph(proc, truncated, file_id_index)
    headers = build_headers(files_in_graph, TEMP_ASM)
    macros = build_macros(files_in_graph, TEMP_ASM)

    out_dir = DATA_PROCESSES / proc
    target_paths = {
        "file_graph.json": file_graph,
        "headers.json": {**headers, "source_graph": f"data/processes/{proc}/file_graph.json"},
        "macros.json": macros,
    }

    print(f"Process: {proc}")
    print(f"  files in graph : {len(files_in_graph)}")
    print(f"  edges          : {file_graph['edge_count']}  ({file_graph['edge_types']})")
    print(f"  headers found  : {headers['total_unique_headers_found']}, "
          f"missing: {headers['total_unique_headers_missing']}")
    print(f"  asm files      : {len(macros['asm_files'])}, "
          f"macro index     : {macros['macro_index_size']}")

    if args.purge and out_dir.is_dir() and not args.dry_run:
        keep = {"metadata.json", "predefined_questions.json"}
        for child in out_dir.iterdir():
            if child.is_file() and child.name not in keep:
                child.unlink()
                print(f"  purged {child.relative_to(REPO_ROOT)}")

    for fname, payload in target_paths.items():
        _atomic_write_json(out_dir / fname, payload, args.dry_run)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
