"""Live validation for V6.4 (usage-flows manifest) + V7.1–V7.3 (investigation SSE).

Hits the running backend on http://127.0.0.1:8010 and writes
``docs/v6_v7_validation.json`` with the captured manifests, the parsed SSE
event sequence, and a pass/fail verdict per validation row.

Validations (per VALIDATION_TRACKER.md):
  V6.4  — /usage-flows endpoint serves a complete manifest + dep_vars summary.
          Run for one ASM and one C++ variable; assert response shape and
          that the in-scope counts are positive.
  V7.1  — SSE stream emits exactly N message events plus exactly one ``done``.
  V7.2  — Every message references at least one source with (file, line_range).
  V7.3  — Messages are connected: each Mk paraphrases or shares a source with
          a prior Mi. Heuristic: share ≥1 source file with prior, OR Mk's
          paragraph contains the variable name (which Mi must by definition).
  V7.4  — UI-side (Explain more re-fire). Documented as deferred.

Exits 0 on full pass, 1 on any failure.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Tuple

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_BASE = "http://127.0.0.1:8010/demo/v1"


# ── HTTP helpers ────────────────────────────────────────────────────────────


def _post_json(url: str, body: dict, timeout: int = 120) -> Tuple[int, dict]:
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, {"error": e.read().decode(errors="replace")}


def _stream_sse(
    url: str, body: dict, timeout: int = 240
) -> List[Tuple[str, dict | str]]:
    """POST and parse SSE frames until EOF.

    Returns a list of (event_name, payload) tuples. Payload is JSON-decoded
    when possible, otherwise raw string.
    """
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode(),
        headers={
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        },
        method="POST",
    )
    events: List[Tuple[str, dict | str]] = []
    pending_event = "message"
    data_lines: List[str] = []
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        for raw in resp:
            line = raw.decode("utf-8", errors="replace").rstrip("\n")
            if line == "":
                if data_lines:
                    payload_str = "\n".join(data_lines)
                    try:
                        payload: dict | str = json.loads(payload_str)
                    except json.JSONDecodeError:
                        payload = payload_str
                    events.append((pending_event, payload))
                pending_event = "message"
                data_lines = []
                continue
            if line.startswith("event:"):
                pending_event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                data_lines.append(line.split(":", 1)[1].lstrip())
    return events


# ── V6.4: /usage-flows ──────────────────────────────────────────────────────


REQUIRED_USAGEFLOWS_FIELDS = {
    "process",
    "variable",
    "declaration_file",
    "files_in_scope",
    "node_count_raw",
    "node_count_in_scope",
    "role_counts",
    "setter_like_count",
    "overwrite_count",
    "cross_file_call_count",
    "dep_var_count",
    "dep_var_count_in_scope",
    "dep_vars",
    "truncated",
    "elapsed_sec",
}


def validate_usage_flows(base: str, variable: str, declaration_file: str, *, expect_dep_vars: bool) -> dict:
    url = f"{base}/processes/C400/variables/{variable}/usage-flows"
    status, body = _post_json(url, {"declaration_file": declaration_file})
    errors: List[str] = []
    if status != 200:
        errors.append(f"HTTP {status} (not 200): {str(body)[:200]}")
        return {"variable": variable, "ok": False, "status": status, "errors": errors}

    missing = REQUIRED_USAGEFLOWS_FIELDS - set(body.keys())
    if missing:
        errors.append(f"missing fields: {sorted(missing)}")
    if body.get("node_count_in_scope", 0) <= 0:
        errors.append(f"node_count_in_scope must be > 0 (got {body.get('node_count_in_scope')})")
    if not body.get("files_in_scope"):
        errors.append("files_in_scope is empty")
    if expect_dep_vars and not body.get("dep_vars"):
        errors.append("dep_vars list is empty for a variable with expected fan-out")

    return {
        "variable": variable,
        "declaration_file": declaration_file,
        "ok": len(errors) == 0,
        "status": status,
        "node_count_in_scope": body.get("node_count_in_scope"),
        "setter_like_count": body.get("setter_like_count"),
        "dep_var_count_in_scope": body.get("dep_var_count_in_scope"),
        "role_counts": body.get("role_counts"),
        "errors": errors,
    }


# ── V7.1–V7.3: /investigation SSE ───────────────────────────────────────────


def validate_investigation(
    base: str,
    variable: str,
    direction: str,
    max_messages: int,
    declaration_file: str | None = None,
) -> dict:
    url = f"{base}/processes/C400/variables/{variable}/investigation/{direction}"
    body: Dict[str, Any] = {"max_messages": max_messages}
    if declaration_file:
        body["declaration_file"] = declaration_file
    started = time.monotonic()
    events = _stream_sse(url, body)
    elapsed = round(time.monotonic() - started, 2)

    errors: List[str] = []
    by_kind: Dict[str, List[Any]] = {}
    for name, payload in events:
        by_kind.setdefault(name, []).append(payload)

    if not events:
        errors.append("no SSE events at all")
        return {"variable": variable, "direction": direction, "ok": False, "errors": errors}

    if "error" in by_kind:
        errors.append(f"error event: {by_kind['error'][0]}")
        return {
            "variable": variable,
            "direction": direction,
            "ok": False,
            "events": [(k, v) for k, v in events],
            "errors": errors,
        }

    # V7.1 — exactly N message events + exactly 1 done. (N == plan.iteration_count.)
    msgs = by_kind.get("message", [])
    dones = by_kind.get("done", [])
    plans = by_kind.get("plan", [])
    expected_n = plans[0].get("iteration_count") if plans else None
    if expected_n is None:
        errors.append("no plan event observed")
    elif len(msgs) != expected_n:
        errors.append(
            f"V7.1: message count {len(msgs)} != plan.iteration_count {expected_n}"
        )
    if len(dones) != 1:
        errors.append(f"V7.1: expected exactly 1 done event, got {len(dones)}")

    # V7.2 — every message has ≥1 source citing (file AND (line_range OR block_id)).
    # The LLM prompt explicitly admits either anchor.
    for i, m in enumerate(msgs, 1):
        if not isinstance(m, dict):
            errors.append(f"V7.2: message #{i} is not a dict")
            continue
        srcs = m.get("sources") or []
        if not srcs:
            errors.append(f"V7.2: message #{i} has no sources")
            continue
        for j, s in enumerate(srcs, 1):
            ok = (
                isinstance(s, dict)
                and s.get("file")
                and (s.get("line_range") or s.get("block_id"))
            )
            if not ok:
                errors.append(
                    f"V7.2: message #{i} source #{j} missing file or line_range/block_id: {s}"
                )

    # V7.3 — connectedness. VALIDATION_TRACKER V7.3 explicitly admits "paraphrase"
    # OR "explicit anchor" as evidence of connection. We accept any of:
    #   (a) Mk shares ≥1 source file with M1..M_{k-1}        (shared-citation anchor)
    #   (b) Mk's paragraph mentions the variable name        (explicit symbol anchor)
    #   (c) Mk's first sentence opens with a continuation    (paraphrase anchor)
    #       lexical marker (Building on / Following / Continuing / After / Next /
    #       Then / Now / Previously / Above / Earlier).
    paraphrase_markers = (
        "building on",
        "following ",
        "continuing",
        "after ",
        "next,",
        "then,",
        "now ",
        "previously",
        "above",
        "earlier",
        "having ",
    )
    if len(msgs) >= 2:
        prior_files: set = set()
        for i, m in enumerate(msgs, 1):
            if not isinstance(m, dict):
                continue
            this_files = {s.get("file") for s in (m.get("sources") or []) if isinstance(s, dict)}
            if i >= 2:
                overlap = this_files & prior_files
                paragraph = (m.get("paragraph") or "").lower()
                opening = paragraph[:120]
                has_paraphrase = any(mk in opening for mk in paraphrase_markers)
                if not overlap and variable.lower() not in paragraph and not has_paraphrase:
                    errors.append(
                        f"V7.3: message #{i} not connected to priors "
                        f"(no source-file overlap, no '{variable}' mention, no paraphrase marker)"
                    )
            prior_files |= this_files

    return {
        "variable": variable,
        "direction": direction,
        "max_messages_requested": max_messages,
        "iteration_count_reported": expected_n,
        "message_count": len(msgs),
        "ok": len(errors) == 0,
        "elapsed_sec": elapsed,
        "errors": errors,
    }


# ── main ────────────────────────────────────────────────────────────────────


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=DEFAULT_BASE)
    ap.add_argument(
        "--out",
        default=str(ROOT / "process_analysis" / "docs" / "v6_v7_validation.json"),
    )
    args = ap.parse_args()

    print(f"[v6_v7] base={args.base}")

    print("[v6_v7] V6.4 — /usage-flows (ASM: WB1SW6, C++: bcis)…")
    v64_asm = validate_usage_flows(
        args.base, "WB1SW6", "temp/asm/xh80.asm", expect_dep_vars=True
    )
    v64_cpp = validate_usage_flows(
        args.base, "bcis", "temp/asm/dx740200.cpp", expect_dep_vars=False
    )

    print("[v6_v7] V7.1–V7.3 — /investigation SSE (setter direction, A7AFTERGLHIST)…")
    v7_setter = validate_investigation(args.base, "A7AFTERGLHIST", "setter", max_messages=2)

    print("[v6_v7] V7.1–V7.3 — /investigation SSE (usage direction, WB1SW6)…")
    v7_usage = validate_investigation(
        args.base,
        "WB1SW6",
        "usage",
        max_messages=2,
        declaration_file="temp/asm/xh80.asm",
    )

    all_ok = all(r["ok"] for r in (v64_asm, v64_cpp, v7_setter, v7_usage))

    summary = {
        "discharged_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "base": args.base,
        "validations": {
            "V6.4_usage_flows_manifest_asm": {
                "passed": v64_asm["ok"],
                "detail": v64_asm,
            },
            "V6.4_usage_flows_manifest_cpp": {
                "passed": v64_cpp["ok"],
                "detail": v64_cpp,
            },
            "V7.1_V7.2_V7.3_setter_direction": {
                "passed": v7_setter["ok"],
                "detail": v7_setter,
            },
            "V7.1_V7.2_V7.3_usage_direction": {
                "passed": v7_usage["ok"],
                "detail": v7_usage,
            },
        },
        "V7.4_explain_more_button": {
            "status": "deferred — UI-side check; this script only covers backend stream contract.",
        },
        "overall_ok": all_ok,
    }

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(summary, indent=2, default=str))
    print(f"[v6_v7] wrote {out_path}")

    for name, row in summary["validations"].items():
        marker = "✅" if row["passed"] else "❌"
        print(f"  {marker} {name}")
        for err in row["detail"].get("errors", []):
            print(f"     - {err}")

    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
