#!/usr/bin/env python3
"""Phase 4 live validation — sample N variable rows from SQLite, run BOTH:

  (a) Forbidden-token LINT — fail if `purpose` contains any HLASM opcode,
      register name, hex constant, or C++ syntax token.
  (b) LLM-as-JUDGE pass — for each sample, ask Gemini whether the
      `name + purpose` reads as a clear, business-language, jargon-free
      sentence. Validated via ``call_llm_model(VariablePurposeJudgement)``.

Approved per Q-P4d (2026-05-27).

Usage:
    env/bin/python process_analysis/scripts/validate_variable_purposes.py \\
        --process C400 --sample-size 50 --out docs/v4_validation_C400.json
"""

from __future__ import annotations

import argparse
import json
import random
import re
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Tuple

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from process_analysis.backend.config import settings   # noqa: E402
from process_analysis.backend.db import get_conn       # noqa: E402
from process_analysis.backend.llm import LLMJSONError, call_llm_model   # noqa: E402
from process_analysis.backend.schemas.llm import VariablePurposeJudgement   # noqa: E402


# ---------------------------------------------------------------------------
# (a) Forbidden-token lint
# ---------------------------------------------------------------------------

_FORBIDDEN_RE = re.compile(
    r"""
    \b(BAS|BAL|BALR|BR|BAS R\d+|MVC|MVI|CLC|CLI|CLR|L\b|LH|LR|LM|LA|ST|STM|STH|
       OI|OC|NI|NC|XI|XC|TM|TR|ED|EX|TRT|UNPK|PACK|CVB|CVD|
       ENTRC|ENTNC|ENTDC|CREEC|CREMC|SWISC|FUNCTION)\b
    | \b R[0-9]{1,2} \b
    | \b 0x[0-9A-Fa-f]+ \b
    | (?: -> | :: | \*\b | void\* | size_t\* )
    """,
    re.VERBOSE,
)


def lint_purpose(text: str) -> List[str]:
    """Return a list of forbidden-token matches; empty if clean."""
    if not text:
        return ["empty"]
    return [m.group(0) for m in _FORBIDDEN_RE.finditer(text)]


# ---------------------------------------------------------------------------
# (b) LLM-as-judge
# ---------------------------------------------------------------------------

JUDGE_PROMPT = (
    "You are evaluating a single ONE-SENTENCE description of a data item in "
    "a z/TPF mainframe codebase for a NON-TECHNICAL BUSINESS USER.\n\n"
    "Variable name : {name}\n"
    "Variable purpose : {purpose}\n\n"
    "Evaluate whether the purpose:\n"
    "  - Is written in plain business English (no opcodes, no C++ syntax, no "
    "    hex constants, no register names like R1-R15).\n"
    "  - Describes WHAT the variable represents and WHY it matters, not how "
    "    it is implemented.\n"
    "  - Is a single coherent sentence understandable to someone with no "
    "    programming background.\n"
    "  - Mentions a clearly business-relevant concept (transactions, accounts, "
    "    limits, statuses, etc.) when possible.\n\n"
    "Reply with the validation result.\n"
)


def judge_one(name: str, purpose: str) -> Dict[str, Any]:
    prompt = JUDGE_PROMPT.format(name=name, purpose=purpose)
    try:
        result = call_llm_model(prompt, VariablePurposeJudgement, max_retries=2)
        return {"passes": bool(result.passes), "reason": result.reason}
    except LLMJSONError as exc:
        return {"passes": False, "reason": f"judge_error: {exc}"}


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------

def sample_rows(process: str, n: int, seed: int) -> List[Tuple[str, str, str, str, int]]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT name, origin, purpose, declaration_file, declaration_line "
            "FROM variable WHERE process = ? AND purpose != ''",
            (process,),
        ).fetchall()
    rng = random.Random(seed)
    pool = [tuple(r) for r in rows]
    if not pool:
        return []
    return rng.sample(pool, min(n, len(pool)))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    ap.add_argument("--process", required=True)
    ap.add_argument("--sample-size", type=int, default=50)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--out", default=None)
    ap.add_argument("--skip-judge", action="store_true",
                    help="Run only the lint pass (no Gemini calls). Useful for fast iteration.")
    args = ap.parse_args()

    rows = sample_rows(args.process, args.sample_size, args.seed)
    if not rows:
        print(f"No variable rows with purpose found for {args.process}.", file=sys.stderr)
        return 2

    print(f"Sampled {len(rows)} variables from {args.process} (seed={args.seed})")

    # ── lint ──────────────────────────────────────────────────────────────
    lint_results: List[Dict[str, Any]] = []
    lint_failures = 0
    for name, origin, purpose, df, dl in rows:
        hits = lint_purpose(purpose)
        if hits:
            lint_failures += 1
        lint_results.append({
            "name": name, "origin": origin,
            "declaration_file": df, "declaration_line": dl,
            "purpose": purpose,
            "lint_hits": hits,
        })
    print(f"Lint: {len(rows) - lint_failures} passed, {lint_failures} failed")

    # ── LLM-as-judge ──────────────────────────────────────────────────────
    judge_results: List[Dict[str, Any]] = []
    judge_failures = 0
    if args.skip_judge:
        print("Judge: skipped (--skip-judge)")
    else:
        with ThreadPoolExecutor(max_workers=args.workers, thread_name_prefix="judge") as pool:
            futs = {
                pool.submit(judge_one, r["name"], r["purpose"]): r
                for r in lint_results
            }
            for fut in as_completed(futs):
                meta = futs[fut]
                verdict = fut.result()
                if not verdict["passes"]:
                    judge_failures += 1
                judge_results.append({
                    "name": meta["name"],
                    "purpose": meta["purpose"],
                    "judge": verdict,
                })
        print(f"Judge: {len(rows) - judge_failures} passed, {judge_failures} failed")

    out_path = (
        Path(args.out)
        if args.out
        else REPO / "process_analysis" / "docs" / f"v4_validation_{args.process}.json"
    )
    out_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "process": args.process,
        "sample_size": len(rows),
        "seed": args.seed,
        "lint": {
            "failures": lint_failures,
            "results": lint_results,
        },
        "judge": {
            "skipped": args.skip_judge,
            "failures": judge_failures,
            "results": judge_results,
        },
    }
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"Report: {out_path.relative_to(REPO)}")

    fail = lint_failures + (judge_failures if not args.skip_judge else 0)
    return 0 if fail == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
