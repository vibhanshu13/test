#!/usr/bin/env python3
"""V_FWD baseline — record the current forward_traversal output for several
variables before any Track-A/B/C gap-closure code lands.

For each picked variable:
  (a) Rule-6 source validation (line refs exist + non-blank + non-comment)
  (b) Setter-site cross-check vs parser blueprint: every direct write to the
      variable (SETTER opcodes targeting the variable name) in source should
      appear in the forward result as a SETTER / SIDE_EFFECT_SETTER /
      OVERWRITE node OR be explained by a tracer warning.
  (c) Process-scope correctness: every emitted node's file is in the
      process's file_graph.

Outputs ``process_analysis/docs/v_fwd_baseline.json``. Exit 0 when all
checks pass; 1 otherwise.

Usage:
    env/bin/python process_analysis/scripts/validate_forward_baseline.py
"""

from __future__ import annotations

import json
import sys
import tempfile
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Tuple

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from process_analysis.backend.config import settings
from process_analysis.forward_traversal.runner import run_forward_only


# Direct-write opcodes for ASM. If a flow entry has one of these as `inst`
# and the variable is the FIRST operand (destination), it's a setter site.
ASM_SETTER_OPCODES = {
    "MVC", "MVI", "MVCL", "ST", "STH", "STC", "STM", "STD", "STE",
    "OI", "OC", "NI", "NC", "XI", "XC",
    "MVCK", "MVZ", "MVN", "MVO",
    "L", "LH", "LR", "LA", "LM",   # loads — destination is reg, but for symmetry skip
    "PACK", "UNPK", "CVB", "CVD",
}
# Subset that have a symbolic destination (not just register).
DEST_SYMBOLIC = {"MVC", "MVI", "ST", "STH", "STC", "STM", "STD", "STE",
                 "OI", "OC", "NI", "NC", "XI", "XC", "MVCK", "MVZ", "MVN", "MVO",
                 "PACK", "UNPK"}


# 3 representative C400 variables chosen by trace expectations:
#   WB1SW6  — known to have direct OI writes in xh80 (3 setters discovered earlier)
#   WB1SW1  — same file, different switch byte
#   A7AFTERGLHIST — declared as CL16 constant; expect zero setters + tracer warning
TARGETS: List[Tuple[str, str]] = [
    ("WB1SW6", "temp/asm/xh80.asm"),
    ("WB1SW1", "temp/asm/xh80.asm"),
    ("A7AFTERGLHIST", "temp/asm/xh80.asm"),
]


def _parser_setter_sites(asm_file_rel: str, variable: str) -> List[Dict[str, Any]]:
    """Return the list of `(block, line, inst)` where the variable is the
    direct (destination) operand of a setter opcode in the parser blueprint."""
    bp_path = settings.TEMP_OUTPUT_DIR / "asm" / f"{Path(asm_file_rel).name}.json"
    if not bp_path.is_file():
        return []
    bp = json.loads(bp_path.read_text(encoding="utf-8"))
    out: List[Dict[str, Any]] = []
    for block in bp.get("blocks") or []:
        bid = block.get("id")
        for fe in block.get("flow") or []:
            inst = (fe.get("inst") or "").upper()
            if inst not in DEST_SYMBOLIC:
                continue
            args = fe.get("args") or []
            if not args:
                continue
            dest = str(args[0]).strip().upper()
            # OI dest is "VAR_NAME,X'80'"; MVC is "VAR_NAME(L),SRC" etc.
            # Extract the leading symbolic identifier.
            dest_token = dest.split("(", 1)[0].split(",", 1)[0]
            if dest_token == variable.upper():
                out.append({
                    "block": bid,
                    "line": fe.get("line"),
                    "inst": inst,
                    "raw": dest,
                })
    return out


def check_one(variable: str, asm_file_rel: str) -> Dict[str, Any]:
    out_dir = Path(tempfile.mkdtemp(prefix=f"vfwd_{variable}_"))
    manifest = run_forward_only(
        "C400", variable, out_dir, declaration_file=asm_file_rel
    )
    root_var = json.loads((out_dir / "root_var.json").read_text(encoding="utf-8"))
    nodes = root_var.get("nodes") or []
    warnings_payload = json.loads((out_dir / "warnings.json").read_text(encoding="utf-8"))

    # (a) Rule-6 source-validation counts
    rule6_total = manifest.validation_warnings
    rule6_reasons = Counter(w["reason"] for w in warnings_payload.get("validation") or [])

    # (b) Parser setter cross-check
    parser_setters = _parser_setter_sites(asm_file_rel, variable)
    setter_line_set = {s["line"] for s in parser_setters}
    forward_setter_lines = {
        n.get("line")
        for n in nodes
        if n.get("role") in ("SETTER", "SIDE_EFFECT_SETTER", "OVERWRITE")
        and isinstance(n.get("line"), int)
    }
    covered = setter_line_set & forward_setter_lines
    missing = setter_line_set - forward_setter_lines

    # (c) Process scope correctness
    files = set(manifest.files_in_scope)
    out_of_scope_files = sorted(
        {n.get("file") for n in nodes if n.get("file") and n.get("file") not in files}
    )

    return {
        "variable": variable,
        "declaration_file": asm_file_rel,
        "rule6_warnings_total": rule6_total,
        "rule6_warnings_by_reason": dict(rule6_reasons),
        "parser_setter_count": len(parser_setters),
        "forward_setter_count": len(forward_setter_lines),
        "setter_covered": len(covered),
        "setter_missing": sorted(int(x) for x in missing if isinstance(x, int)),
        "out_of_scope_files": out_of_scope_files,
        "manifest_summary": {
            "node_count_raw": manifest.node_count_raw,
            "node_count_in_scope": manifest.node_count_in_scope,
            "dep_var_count_in_scope": manifest.dep_var_count_in_scope,
            "tracer_warnings": manifest.tracer_warnings,
        },
        "tracer_warning_sample": (warnings_payload.get("tracer") or [])[:3],
        "output_dir": str(out_dir),
    }


def main() -> int:
    results: List[Dict[str, Any]] = []
    overall_pass = True
    for variable, file in TARGETS:
        try:
            r = check_one(variable, file)
        except Exception as exc:  # noqa: BLE001
            r = {"variable": variable, "error": repr(exc)}
            overall_pass = False
        # In-scope correctness must hold (zero out-of-scope files)
        if r.get("out_of_scope_files"):
            overall_pass = False
        # Setter cross-check: if the parser reports setters, the forward result
        # MUST cover all of them — otherwise the tracer is silently missing
        # direct writes.
        missing = r.get("setter_missing") or []
        if missing and r.get("parser_setter_count", 0) > 0:
            overall_pass = False
        results.append(r)

    payload = {
        "ok": overall_pass,
        "process": "C400",
        "targets": [{"variable": v, "declaration_file": f} for v, f in TARGETS],
        "results": results,
    }
    out = REPO / "process_analysis" / "docs" / "v_fwd_baseline.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    print(f"V_FWD baseline: overall_pass={overall_pass}")
    for r in results:
        v = r["variable"]
        if "error" in r:
            print(f"  {v}: ERROR — {r['error']}")
            continue
        print(
            f"  {v}: setters parser={r['parser_setter_count']} forward={r['forward_setter_count']} "
            f"covered={r['setter_covered']} missing={len(r.get('setter_missing') or [])} | "
            f"rule6={r['rule6_warnings_total']} {dict(r['rule6_warnings_by_reason'])} | "
            f"out_of_scope={len(r['out_of_scope_files'])}"
        )
    print(f"Wrote {out.relative_to(REPO)}")
    return 0 if overall_pass else 1


if __name__ == "__main__":
    raise SystemExit(main())
