"""Generate the COMPLETE hierarchical walkthrough for a process and export it as
a static mock JSON the frontend can serve without the analysis backend.

It builds the deterministic tree, then decomposes EVERY business node (root →
leaves) — one LLM call per node — running each level's nodes in parallel. The
result (every node's full view) is written to one JSON keyed by node_id.

Usage:
    python3 process_analysis/scripts/export_hierwalk_mock.py \
        --process plastic_authentication \
        --project default \
        --workers 8 \
        --out /Users/prathamgupta/Documents/Zenflow_Frontend/public/hierwalk/plastic_authentication.json
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))  # repo root

from process_analysis.backend.db import init_schema  # noqa: E402
from process_analysis.backend.hierwalk import builder, store  # noqa: E402
from process_analysis.backend.hierwalk import subprocess as sp  # noqa: E402


def decompose_all(process: str, workers: int, max_nodes: int) -> int:
    init_schema()
    manifest = builder.build_tree(process)
    print(f"[build] {manifest['node_count']} substrate nodes, depth {manifest['max_depth']}")
    sp.ensure_root(process)

    frontier = [sp.ROOT_ID]
    seen: set = set()
    total = 0
    level = 0
    while frontier and total < max_nodes:
        level += 1
        t0 = time.time()
        with ThreadPoolExecutor(max_workers=workers) as ex:
            list(ex.map(lambda nid: sp.decompose(process, nid), frontier))
        total += len(frontier)
        print(f"[level {level}] decomposed {len(frontier)} nodes in {time.time()-t0:.0f}s "
              f"(total {total})")
        nxt: list = []
        for nid in frontier:
            seen.add(nid)
            for ch in store.get_children(process, nid):
                if ch["node_id"] not in seen and ch["node_id"] not in nxt:
                    nxt.append(ch["node_id"])  # decompose every child (leaf or expandable)
        frontier = nxt
    return total


def export(process: str, out_path: Path) -> int:
    rows = store.all_subprocesses(process)
    nodes = {}
    for r in rows:
        v = sp.node_view(process, r["node_id"])
        if v:
            nodes[r["node_id"]] = v
    meta = store.get_meta(process) or {}
    data = {
        "process": process,
        "root_node_id": sp.ROOT_ID,
        "status": {
            "built": True,
            "root_node_id": sp.ROOT_ID,
            "substrate_nodes": meta.get("node_count"),
            "max_depth": meta.get("max_depth"),
            "built_at": meta.get("built_at"),
        },
        "nodes": nodes,
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(data, ensure_ascii=False, indent=1))
    return len(nodes)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--process", default="plastic_authentication")
    ap.add_argument("--project", default="default", help="(ignored — hierwalk is project-free)")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--max-nodes", type=int, default=600)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    t0 = time.time()
    n = decompose_all(args.process, args.workers, args.max_nodes)
    written = export(args.process, Path(args.out))
    print(f"[done] decomposed {n} nodes, exported {written} node views to {args.out} "
          f"in {time.time()-t0:.0f}s")


if __name__ == "__main__":
    main()
