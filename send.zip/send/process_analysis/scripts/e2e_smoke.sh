#!/usr/bin/env bash
# explanability_demo end-to-end smoke.
# Brings backend up, hits every public endpoint with curl, kills servers, prints a summary.
set -euo pipefail

REPO="/Users/prathamgupta/Documents/asm-modernizer"
LOG_DIR="/tmp/explanability_demo_logs"
mkdir -p "${LOG_DIR}"

cleanup() {
  pkill -f "uvicorn explanability_demo.backend.app:app" 2>/dev/null || true
  pkill -f "vite --port 5173" 2>/dev/null || true
}
trap cleanup EXIT

cd "${REPO}"
nohup env/bin/uvicorn explanability_demo.backend.app:app --host 127.0.0.1 --port 8010 \
  > "${LOG_DIR}/uvicorn.log" 2>&1 &
echo "uvicorn pid=$!"

# Wait for backend
for _ in $(seq 1 30); do
  if curl -sf http://127.0.0.1:8010/demo/v1/health > /dev/null 2>&1; then
    break
  fi
  sleep 0.5
done

pass=0; fail=0
check() {
  local name="$1"; local cmd="$2"; local expect_grep="${3:-}"
  out=$(eval "${cmd}" 2>&1) || true
  if [[ -n "${expect_grep}" && "${out}" != *"${expect_grep}"* ]]; then
    echo "  ❌ ${name}: missing pattern '${expect_grep}'"
    echo "     got: ${out:0:200}"
    fail=$((fail+1))
  else
    echo "  ✅ ${name}"
    pass=$((pass+1))
  fi
}

echo
echo "── Phase 2 endpoints ──"
check "/health"            'curl -s http://127.0.0.1:8010/demo/v1/health'                                                                     '"status":"ok"'
check "/processes"         'curl -s http://127.0.0.1:8010/demo/v1/processes'                                                                  '"name":"C400"'
check "/processes/C400"    'curl -s http://127.0.0.1:8010/demo/v1/processes/C400'                                                             '"seed_segment":"DX75"'
check "/file-graph"        'curl -s http://127.0.0.1:8010/demo/v1/processes/C400/file-graph'                                                  '"file_count":16'
check "/headers"           'curl -s http://127.0.0.1:8010/demo/v1/processes/C400/headers'                                                     '"headers_found"'
check "/macros"            'curl -s http://127.0.0.1:8010/demo/v1/processes/C400/macros'                                                      '"macro_index_size":9'

echo
echo "── Phase 4 variables ──"
check "/variables (list)"   'curl -s "http://127.0.0.1:8010/demo/v1/processes/C400/variables?page=1&page_size=3"'                              '"total":226'
check "/variables/{V}"      'curl -s http://127.0.0.1:8010/demo/v1/processes/C400/variables/bcis'                                              'BasicCreditInputSegment'

echo
echo "── Phase 5b.5 file detail ──"
check "/files/{rel}"        'curl -s http://127.0.0.1:8010/demo/v1/processes/C400/files/temp/asm/xh88.asm'                                     '"block_count"'

echo
echo "── Phase 6 forward-traversal ──"
check "/usage-flows (ASM)"  'curl -s -X POST http://127.0.0.1:8010/demo/v1/processes/C400/variables/WB1SW6/usage-flows -H "Content-Type: application/json" -d "{\"declaration_file\":\"temp/asm/xh80.asm\"}"' '"variable":"WB1SW6"'
check "/usage-flows (C++)"  'curl -s -X POST http://127.0.0.1:8010/demo/v1/processes/C400/variables/bcis/usage-flows -H "Content-Type: application/json" -d "{\"declaration_file\":\"temp/asm/dx740200.cpp\"}"' '"declaration_file":"temp/asm/dx740200.cpp"'

echo
echo "── Phase 8 chat (only the first SSE frame is checked to keep this fast) ──"
check "/chat SSE first frame" 'curl -s -X POST http://127.0.0.1:8010/demo/v1/processes/C400/chat -H "Content-Type: application/json" -d "{\"message\":\"List the files in this process.\"}" -m 60 | head -c 200' 'event: thought'

echo
echo "── V6.4 + V7.1–V7.3 deeper validations (live LLM) ──"
if env/bin/python explanability_demo/scripts/validate_v6_v7.py > "${LOG_DIR}/v6_v7.log" 2>&1; then
  echo "  ✅ V6.4 / V7.1 / V7.2 / V7.3 (see ${LOG_DIR}/v6_v7.log + docs/v6_v7_validation.json)"
  pass=$((pass+1))
else
  echo "  ❌ V6.4 / V7 validator failed — last 30 lines:"
  tail -n 30 "${LOG_DIR}/v6_v7.log"
  fail=$((fail+1))
fi

echo
echo "── Summary ──"
echo "  passed: ${pass}"
echo "  failed: ${fail}"
exit $fail
