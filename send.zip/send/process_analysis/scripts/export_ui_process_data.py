#!/usr/bin/env python3
"""
export_ui_process_data.py
=========================

Populate the explainability-demo fixtures under
``process_analysis/process_data/<Process>/`` with the **real data the running
app renders**, reshaped into the existing fixture contract so a *different*
frontend can render them statically (no backend needed).

It reads from the live backend HTTP API (default ``http://localhost:8010``,
project ``default``) — the same endpoints the demo UI calls — and writes the
7 JSON files per process, preserving every existing key.

Process mapping (output dir -> API process name):
    C400     -> C400
    Plastic  -> plastic_authentication

Fixture <- source mapping:
    process-summary.json   <- GET /narrative           (4 sections -> 1 markdown blob)
    overview-file-list.json<- GET /file-graph           (files[])
    includes-macros.json   <- GET /headers + /macros    (counts)
    complexity-metrics.json<- derived (file-graph + /variables + file details)
    variable-explorer.json <- GET /variables (+ /context per var)
    file-explorer.json     <- GET /files/<path> per file (business_name, blocks)
    walkthrough.json       <- kept as-is (generic UI feature boxes, not process data)

Usage:
    python3 process_analysis/scripts/export_ui_process_data.py
    python3 process_analysis/scripts/export_ui_process_data.py --process C400
    python3 process_analysis/scripts/export_ui_process_data.py --base-url http://localhost:8010 --dry-run

Outputs are written atomically (.tmp then os.replace).
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

SCRIPTS_DIR = Path(__file__).resolve().parent
DEMO_ROOT = SCRIPTS_DIR.parent                       # process_analysis/
REPO_ROOT = DEMO_ROOT.parent
PROCESS_DATA_DIR = DEMO_ROOT / "process_data"

# output-dir name -> API process name
PROCESS_MAP: Dict[str, str] = {
    "C400": "C400",
    "Plastic": "plastic_authentication",
}


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

class Api:
    def __init__(self, base_url: str, project: str):
        self.base = base_url.rstrip("/")
        self.project = project

    def _url(self, path: str) -> str:
        # path may contain slashes that must be preserved (file paths).
        return f"{self.base}/demo/v1/projects/{self.project}/{path.lstrip('/')}"

    def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        url = self._url(path)
        if params:
            url += "?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def get_or_none(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        try:
            return self.get(path, params)
        except Exception as exc:  # noqa: BLE001 — best-effort per-item fetch
            print(f"    warn: {path} -> {exc}", file=sys.stderr)
            return None


# ---------------------------------------------------------------------------
# Markdown builders (mirror the frontend variable-detail rendering)
# ---------------------------------------------------------------------------

def _has_evidence(level: Optional[str], content: Optional[str]) -> bool:
    if not content or not str(content).strip():
        return False
    return level != "not_found"


def _effects_to_md(items: Optional[List[dict]]) -> str:
    if not items:
        return ""
    lines: List[str] = []
    for p in items:
        if p.get("op") or p.get("target") or p.get("role") or p.get("description"):
            head = " · ".join(x for x in (p.get("op"), p.get("target")) if x)
            meta_parts = [
                p.get("role"),
                (None if p.get("mandatory") is None
                 else ("mandatory" if p.get("mandatory") else "optional")),
                p.get("depth") or None,
            ]
            meta = " · ".join(x for x in meta_parts if x)
            body = (p.get("description") or "").strip() or meta
            prefix = f"**{head}** — " if head else ""
            suffix = f" *({meta})*" if (p.get("description") and meta) else ""
            lines.append(f"- {prefix}{body}{suffix}")
        elif p.get("text"):
            lines.append(p["text"].strip())
    return "\n".join(x for x in lines if x)


def _variations_to_md(items: Optional[List[dict]]) -> str:
    if not items:
        return ""
    lines: List[str] = []
    for f in items:
        if f.get("condition") or f.get("branch"):
            cond = f"**{f['condition']}**" if f.get("condition") else ""
            branch = ""
            if f.get("branch"):
                branch = f"{' — ' if f.get('condition') else ''}{f['branch']}"
            lines.append(f"- {cond}{branch}")
        elif f.get("text"):
            lines.append(f["text"].strip())
    return "\n".join(x for x in lines if x)


def _declaration_analysis_md(d: dict) -> str:
    """Coverage-gated 6-question analysis for one declaration (UI buildAnalysis)."""
    cov = d.get("coverage") or {}
    availability_md = ""
    if d.get("availability"):
        cond = d.get("availability_condition")
        availability_md = f"**{d['availability']}**" + (f" — {cond}" if cond else "")
    persistence_md = _effects_to_md(d.get("persistence_effects"))
    flow_md = _variations_to_md(d.get("flow_variations"))

    sections: List[str] = []
    if _has_evidence(cov.get("purpose"), d.get("purpose")):
        sections.append(f"## Purpose & importance\n\n{d['purpose']}")
    if _has_evidence(cov.get("computation_source"), d.get("computation_source")):
        sections.append(f"## How it is computed\n\n{d['computation_source']}")
    if _has_evidence(cov.get("availability"), availability_md):
        sections.append(f"## Availability\n\n{availability_md}")
    if _has_evidence(cov.get("persistence_effects"), persistence_md):
        sections.append(f"## Persistence effects\n\n{persistence_md}")
    if _has_evidence(cov.get("flow_variations"), flow_md):
        sections.append(f"## Flow variations\n\n{flow_md}")
    if _has_evidence(cov.get("business_flow_context"), d.get("business_flow_context")):
        sections.append(f"## Business flow context\n\n{d['business_flow_context']}")
    return "\n\n".join(sections)


def build_variable_description(item: dict, ctx: Optional[dict]) -> str:
    """Markdown description: short purpose + the detail-view context analysis
    (everything the UI shows on click, minus the declaration location)."""
    parts: List[str] = []
    purpose = (item.get("purpose") or "").strip()
    if purpose:
        parts.append(purpose)

    # One labelled block per declaration site, so a variable declared in many
    # places (e.g. "addresses" appears in 16 blocks) renders as N clearly
    # separated, attributed sections instead of an anonymous run-on.
    blocks: List[str] = []
    if ctx:
        declarations = ctx.get("declarations") or []
        if not declarations:
            # synthetic single declaration from top-level fields (UI fallback)
            declarations = [{
                "declaration_file": ctx.get("declaration_file"),
                "declaration_line": ctx.get("declaration_line"),
                "purpose": ctx.get("purpose"),
                "computation_source": ctx.get("computation_source"),
                "availability": ctx.get("availability"),
                "availability_condition": ctx.get("availability_condition"),
                "persistence_effects": ctx.get("persistence_effects"),
                "flow_variations": ctx.get("flow_variations"),
                "business_flow_context": ctx.get("business_flow_context"),
                "coverage": ctx.get("coverage"),
            }]
        analysed = [(d, _declaration_analysis_md(d)) for d in declarations]
        analysed = [(d, md) for d, md in analysed if md]
        total = len(analysed)
        for idx, (d, md) in enumerate(analysed, 1):
            df = d.get("declaration_file")
            dl = d.get("declaration_line")
            prefix = f"Instance {idx} of {total} — declared in" if total > 1 else "Declared in"
            if df:
                loc = f"{df}" + (f", line {dl}" if dl else "")
                header = f"# {prefix} {loc}"
            elif total > 1:
                header = f"# Instance {idx} of {total}"
            else:
                header = "# Declaration"
            blocks.append(f"{header}\n\n{md}")

    if blocks:
        parts.append("\n\n---\n\n".join(blocks))
    elif (item.get("meaning") or "").strip():
        # Fall back to the rich meaning when no context analysis exists.
        parts.append(f"## Meaning\n\n{item['meaning'].strip()}")

    return "\n\n".join(parts).strip()


def build_walkthrough_description(card: dict) -> str:
    """Render every substantive card field (except the title heading and
    internal navigation/visualization plumbing) as markdown."""
    parts: List[str] = []

    meta = " · ".join(x for x in (card.get("section"), card.get("role_summary")) if x)
    if meta:
        parts.append(f"*{meta}*")

    body = (card.get("body") or "").strip()
    if body:
        parts.append(body)

    key_vars = card.get("key_variables") or []
    if key_vars:
        lines = []
        for v in key_vars:
            name = v.get("name", "")
            purpose = (v.get("purpose") or "").strip()
            why = (v.get("why_it_matters") or "").strip()
            tail = " ".join(x for x in (purpose, f"*{why}*" if why else "") if x)
            lines.append(f"- **{name}**{(' — ' + tail) if tail else ''}")
        parts.append("## Key Variables\n\n" + "\n".join(lines))

    io_events = card.get("io_events") or []
    if io_events:
        lines = []
        for e in io_events:
            what = (e.get("what_happens") or "").strip()
            target = (e.get("business_target") or "").strip()
            lines.append(f"- {what}" + (f" → {target}" if target else ""))
        parts.append("## Inputs & Outputs\n\n" + "\n".join(lines))

    conditions = card.get("conditions") or []
    if conditions:
        lines = []
        for c in conditions:
            cond = (c.get("condition") or "").strip()
            out = (c.get("outcomes") or "").strip()
            lines.append(f"- **{cond}**" + (f" → {out}" if out else ""))
        parts.append("## Decisions & Branches\n\n" + "\n".join(lines))

    bridge = (card.get("bridge_to_next") or "").strip()
    if bridge:
        parts.append(f"## Next\n\n{bridge}")

    return "\n\n".join(parts).strip()


def build_summary_markdown(narrative: Optional[dict]) -> str:
    if not narrative:
        return ""
    ordered = [
        ("Executive Summary", narrative.get("executive_summary")),
        ("End-to-End Flow", narrative.get("e2e_flows")),
        ("Variable Landscape", narrative.get("variable_landscape")),
        ("Persistence Footprint", narrative.get("persistence_footprint")),
    ]
    blocks = [f"## {title}\n\n{text.strip()}" for title, text in ordered if text and text.strip()]
    return "\n\n".join(blocks)


# ---------------------------------------------------------------------------
# Derived complexity
# ---------------------------------------------------------------------------

def _max_call_depth(file_graph: dict) -> int:
    """Longest call chain (in edges) over the file-level call graph."""
    adj: Dict[str, set] = {}
    for e in file_graph.get("edges", []):
        src, tgt = e.get("from_file"), e.get("to_file")
        if src and tgt and src != tgt:
            adj.setdefault(src, set()).add(tgt)

    memo: Dict[str, int] = {}

    def depth(node: str, stack: set) -> int:
        if node in memo:
            return memo[node]
        best = 0
        for nxt in adj.get(node, ()):  # guard cycles via stack
            if nxt in stack:
                continue
            best = max(best, 1 + depth(nxt, stack | {nxt}))
        memo[node] = best
        return best

    nodes = set(adj.keys()) | {t for s in adj.values() for t in s}
    seed = file_graph.get("seed_file")
    starts = [seed] if seed in nodes else list(nodes)
    return max((depth(n, {n}) for n in starts), default=0)


# ---------------------------------------------------------------------------
# Per-process build
# ---------------------------------------------------------------------------

def fetch_all_variables(api: Api, process: str) -> List[dict]:
    items: List[dict] = []
    page, page_size = 1, 100
    while True:
        resp = api.get(f"processes/{process}/variables",
                       {"page": page, "page_size": page_size})
        batch = resp.get("items", [])
        items.extend(batch)
        total = resp.get("total", len(items))
        if len(items) >= total or not batch:
            break
        page += 1
    return items


def build_process(api: Api, out_name: str, proc: str, existing_dir: Path) -> Dict[str, Any]:
    print(f"  fetching {proc} ...")
    narrative = api.get_or_none(f"processes/{proc}/narrative")
    file_graph = api.get(f"processes/{proc}/file-graph")
    headers = api.get(f"processes/{proc}/headers")
    macros = api.get(f"processes/{proc}/macros")

    files = file_graph.get("files", [])

    # --- file-explorer (per-file detail) + block totals ---
    file_explorer_files: List[dict] = []
    total_blocks = 0
    for fp in files:
        det = api.get_or_none(f"processes/{proc}/files/{fp}")
        if det is None:
            continue
        blocks_out = []
        for b in det.get("blocks", []):
            ls, le = b.get("line_start"), b.get("line_end")
            line_no = f"{ls}-{le}" if ls is not None and le is not None else None
            blocks_out.append({
                "name": b.get("block_id"),
                "businessName": b.get("business_name"),
                "lineNo": line_no,
                "purpose": b.get("purpose"),
            })
        total_blocks += det.get("block_count", len(blocks_out))
        file_explorer_files.append({
            "fileName": det.get("file_path", fp),
            "type": det.get("kind"),
            "businessName": det.get("business_name"),
            "purpose": det.get("purpose"),
            "blocks": blocks_out,
        })

    # --- variables (+ context) ---
    # /variables returns one row per declaration site; the explorer lists one
    # entry per unique variable name (first row wins; context fetched once).
    var_rows = fetch_all_variables(api, proc)
    total_var_rows = len(var_rows)
    seen_names: set = set()
    variable_explorer: List[dict] = []
    for v in var_rows:
        name = v.get("name")
        if name in seen_names:
            continue
        seen_names.add(name)
        labels = v.get("labels") or []
        category = labels[0] if labels else (v.get("kind") or None)
        ctx = api.get_or_none(f"processes/{proc}/variables/{name}/context")
        variable_explorer.append({
            "name": name,
            "category": category,
            "description": build_variable_description(v, ctx),
        })

    # --- derived complexity ---
    complexity = {
        "files": file_graph.get("file_count", len(files)),
        "callEdges": file_graph.get("edge_count", len(file_graph.get("edges", []))),
        "blocks": total_blocks,
        "variables": total_var_rows,
        "maxCallDepth": _max_call_depth(file_graph),
    }

    # --- includes / macros counts ---
    includes_macros = {
        "asmFiles": len(macros.get("asm_files", [])),
        "cppFiles": headers.get("cpp_files_scanned", 0),
        "hppFiles": headers.get("hpp_files_scanned", 0),
        "macrosFiles": macros.get("macro_index_size", 0),
    }

    # --- walkthrough (real narrative cards) ---
    wt_resp = api.get_or_none(f"processes/{proc}/walkthrough", {"limit": 200})
    walkthrough: List[dict] = []
    for card in (wt_resp or {}).get("items", []):
        walkthrough.append({
            "box_name": card.get("title"),
            "description": build_walkthrough_description(card),
        })

    payloads: Dict[str, Any] = {
        "process-summary.json": {"markdown": build_summary_markdown(narrative)},
        "overview-file-list.json": {"files": files},
        "includes-macros.json": includes_macros,
        "complexity-metrics.json": complexity,
        "variable-explorer.json": variable_explorer,
        "file-explorer.json": {"files": file_explorer_files},
    }

    # walkthrough.json: real process narrative cards mapped into the
    # {box_name, description} shape. If none are built, keep what's on disk.
    if walkthrough:
        payloads["walkthrough.json"] = walkthrough
    else:
        wt = existing_dir / "walkthrough.json"
        if wt.is_file():
            payloads["walkthrough.json"] = json.loads(wt.read_text(encoding="utf-8"))

    return payloads


# ---------------------------------------------------------------------------
# Post-processing: collapse any code-file path to its basename everywhere
# ---------------------------------------------------------------------------

# Matches a slash-separated path that ends in a known source-file extension,
# e.g. "temp/asm/da78.asm" or "temp/plastic_files/av200100.cpp". Only such
# tokens are collapsed to their basename — prose like "and/or" is untouched.
_PATH_TOKEN_RE = re.compile(r"(?:[\w.\-]+/)+([\w.\-]+\.(?:asm|cpp|hpp|h|mac))\b")


def _basename_paths(obj: Any) -> Any:
    """Recursively rewrite any code-file path to just its file name."""
    if isinstance(obj, str):
        return _PATH_TOKEN_RE.sub(lambda m: m.group(1), obj)
    if isinstance(obj, list):
        return [_basename_paths(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _basename_paths(v) for k, v in obj.items()}
    return obj


def _clean_markdown(obj: Any) -> Any:
    """Strip trailing whitespace per line (avoids stray <br> in strict markdown
    renderers) and collapse 3+ blank lines to a single blank line."""
    if isinstance(obj, str):
        s = "\n".join(line.rstrip() for line in obj.split("\n"))
        return re.sub(r"\n{3,}", "\n\n", s)
    if isinstance(obj, list):
        return [_clean_markdown(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _clean_markdown(v) for k, v in obj.items()}
    return obj


def _assert_no_absolute(payloads: Dict[str, Any]) -> None:
    """Fail loudly if any machine-specific absolute path leaked into output."""
    bad: List[str] = []

    def walk(o: Any, path: str) -> None:
        if isinstance(o, str):
            if "/Users/" in o or "prathamgupta" in o:
                bad.append(f"{path}: {o[:80]!r}")
        elif isinstance(o, list):
            for i, x in enumerate(o):
                walk(x, f"{path}[{i}]")
        elif isinstance(o, dict):
            for k, v in o.items():
                walk(v, f"{path}.{k}")

    walk(payloads, "")
    if bad:
        raise RuntimeError(
            "Absolute/machine-specific paths leaked into output:\n  "
            + "\n  ".join(bad)
        )


# ---------------------------------------------------------------------------
# Write
# ---------------------------------------------------------------------------

def _atomic_write(path: Path, payload: Any, dry_run: bool) -> None:
    text = json.dumps(payload, indent=2, ensure_ascii=False) + "\n"
    if dry_run:
        print(f"    [dry-run] {path.relative_to(REPO_ROOT)} ({len(text)} bytes)")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)
    print(f"    wrote {path.relative_to(REPO_ROOT)} ({len(text)} bytes)")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    ap.add_argument("--base-url", default="http://localhost:8010")
    ap.add_argument("--project", default="default")
    ap.add_argument("--process", choices=sorted(PROCESS_MAP), help="Only this output process.")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    api = Api(args.base_url, args.project)
    targets = [args.process] if args.process else list(PROCESS_MAP)

    for out_name in targets:
        proc = PROCESS_MAP[out_name]
        out_dir = PROCESS_DATA_DIR / out_name
        print(f"Process: {out_name} (API: {proc}) -> {out_dir.relative_to(REPO_ROOT)}")
        payloads = build_process(api, out_name, proc, out_dir)
        # Post-process: file paths -> basenames, then guard against leaked
        # machine-specific absolute paths.
        payloads = {fname: _basename_paths(p) for fname, p in payloads.items()}
        payloads = {fname: _clean_markdown(p) for fname, p in payloads.items()}
        _assert_no_absolute(payloads)
        for fname, payload in payloads.items():
            _atomic_write(out_dir / fname, payload, args.dry_run)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
