#!/usr/bin/env python3
"""validate_parser_output.py — Validate parser-blueprint fields against source.

Required by PROJECT_RULES.md Rule 6. Run this before trusting any new parser
field, after corpus regeneration, and any time the process scope expands.

What it checks (per file in the process scope):

  ASM (`temp/asm/<f>.asm`):
    PA1. Every block id appears as a labeled symbol at or near start_line.
    PA2. start_line <= end_line and within source bounds.
    PA3. Subroutine ids exist in the blocks list (already a warning in enumerate.py).
    PA4. For a sample of call_graph.edges, the source line contains the
         instruction (e.g. BAS, BAL, ENTRC) AND a reference that resolves
         to the target id (textual match, since macro expansion may rewrite).

  C++ (`temp/asm/<f>.cpp`):
    PC1. For every symbols.global_symbols entry of type 'entry', the
         provenance.original_line in source contains the function name AND a
         '(' or function-signature hint.
    PC2. Derived function end_line (next_start - 1) does not chop into the
         next function's signature.
    PC3. For a sample of call_graph.edges, the source line at edge.line
         mentions the target function (textual match).

Per-process invocation:

    python3 process_analysis/scripts/validate_parser_output.py --process C400

Exit code 0 = all gates ✅; 1 = at least one ❌; the report is printed and
written to ``process_analysis/docs/parser_validation_<P>.json``.
"""

from __future__ import annotations

import argparse
import json
import random
import re
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from process_analysis.backend.config import settings   # noqa: E402
from process_analysis.backend.pipeline.enumerate import (   # noqa: E402
    blueprint_path_for,
    file_kind_for,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

ASM_LABEL_RE = re.compile(r"^([A-Z@$#_][A-Z0-9@$#_]*)(?:\s|$|,)", re.MULTILINE)


def _read_source(path: Path) -> List[str]:
    return path.read_text(encoding="utf-8", errors="replace").splitlines()


def _line(src: List[str], n: int) -> str:
    if 1 <= n <= len(src):
        return src[n - 1]
    return ""


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------

@dataclass
class Check:
    id: str
    passed: bool
    detail: str
    sample: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class FileReport:
    file_path: str
    file_kind: str
    checks: List[Check] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(c.passed for c in self.checks)


# ---------------------------------------------------------------------------
# ASM checks
# ---------------------------------------------------------------------------

def _validate_asm(file_rel: str, bp: dict, src: List[str], rng: random.Random) -> FileReport:
    report = FileReport(file_path=file_rel, file_kind="asm")
    blocks = bp.get("blocks") or []
    subs = bp.get("subroutines") or []
    edges = ((bp.get("call_graph") or {}).get("edges") or [])

    n_lines = len(src)

    # ── PA2: line range sanity ────────────────────────────────────────────
    bad_range = []
    for b in blocks:
        if not isinstance(b, dict):
            continue
        s, e = b.get("start_line"), b.get("end_line")
        if not isinstance(s, int) or not isinstance(e, int) or s < 1 or e > n_lines or e < s:
            bad_range.append({"id": b.get("id"), "start": s, "end": e, "src_lines": n_lines})
    report.checks.append(
        Check(
            id="PA2",
            passed=(not bad_range),
            detail=f"{len(bad_range)} blocks have invalid line ranges out of {len(blocks)}",
            sample=bad_range[:5],
        )
    )

    # ── PA1: block id appears at/near start_line as a label ───────────────
    # The parser uses a documented convention: the first executable section
    # of an ASM file gets a SYNTHETIC block id equal to the file basename
    # uppercased (e.g. ``LU82`` block in ``lu82.asm`` covering the
    # macro-definition + dispatch area). These synthetic ids are intentional
    # and do NOT appear as literal labels in source. PA1 excludes them; the
    # softer PA1b check below covers them.
    file_stem_up = Path(file_rel).stem.upper()
    real_blocks = [b for b in blocks if isinstance(b, dict) and b.get("id") != file_stem_up]
    synthetic_blocks = [b for b in blocks if isinstance(b, dict) and b.get("id") == file_stem_up]

    sample_blocks = rng.sample(real_blocks, min(10, len(real_blocks))) if real_blocks else []
    label_mismatches = []
    for b in sample_blocks:
        bid = b.get("id")
        s = b.get("start_line")
        if not (bid and isinstance(s, int)):
            continue
        # Search a window: start_line and the 2 lines around it (label may be
        # on a continuation line in HLASM).
        window = "\n".join(_line(src, n) for n in (s - 1, s, s + 1) if n >= 1)
        if bid not in window.upper():
            label_mismatches.append({
                "id": bid, "start_line": s,
                "got_lines": [_line(src, s - 1)[:80], _line(src, s)[:80], _line(src, s + 1)[:80]],
            })
    report.checks.append(
        Check(
            id="PA1",
            passed=(not label_mismatches),
            detail=(
                f"{len(label_mismatches)} of {len(sample_blocks)} sampled REAL "
                "(non-synthetic) blocks did not have their id present at/near start_line; "
                f"{len(synthetic_blocks)} synthetic file-entry blocks excluded "
                f"(id == file stem uppercased '{file_stem_up}')"
            ),
            sample=label_mismatches[:5],
        )
    )

    # ── PA1b: synthetic file-entry block has a sensible start_line ────────
    # We don't require a literal label, but the line should not be a comment
    # or blank, and should be inside the file.
    pa1b_issues = []
    for b in synthetic_blocks:
        s = b.get("start_line")
        if not isinstance(s, int) or s < 1 or s > n_lines:
            pa1b_issues.append({"id": b.get("id"), "start_line": s, "reason": "out_of_range"})
            continue
        line = _line(src, s)
        stripped = line.strip()
        if not stripped or stripped.startswith("*"):
            pa1b_issues.append({
                "id": b.get("id"), "start_line": s, "reason": "blank_or_comment",
                "got": line[:80],
            })
    report.checks.append(
        Check(
            id="PA1b",
            passed=(not pa1b_issues),
            detail=(
                f"{len(pa1b_issues)} of {len(synthetic_blocks)} synthetic file-entry "
                "block(s) start on a blank/comment line"
            ),
            sample=pa1b_issues[:5],
        )
    )

    # ── PA3: subroutine ids exist in blocks list ──────────────────────────
    block_ids = {b.get("id") for b in blocks if isinstance(b, dict)}
    missing_subs = []
    for s_ in subs:
        sid = s_.get("id") if isinstance(s_, dict) else None
        if sid and sid not in block_ids:
            missing_subs.append({"id": sid, "start_line": s_.get("start_line")})
    report.checks.append(
        Check(
            id="PA3",
            passed=(not missing_subs),
            detail=f"{len(missing_subs)} subroutines have no corresponding block",
            sample=missing_subs[:5],
        )
    )

    # ── PA4: call_graph.edges line contains instruction + target ─────────
    if edges:
        sample_edges = rng.sample(edges, min(10, len(edges)))
    else:
        sample_edges = []
    edge_mismatches = []
    for e in sample_edges:
        line_no = e.get("line")
        inst = (e.get("instruction") or "").upper()
        target = e.get("target") or ""
        if not isinstance(line_no, int):
            continue
        # Look at a 3-line window — HLASM continuation lines do exist.
        window = "\n".join(_line(src, n) for n in (line_no, line_no + 1) if n >= 1).upper()
        ok = (inst in window) and (target.upper() in window)
        if not ok:
            edge_mismatches.append({
                "source": e.get("source"), "target": target, "instruction": inst,
                "line": line_no, "got": _line(src, line_no)[:100],
            })
    report.checks.append(
        Check(
            id="PA4",
            passed=(not edge_mismatches),
            detail=(
                f"{len(edge_mismatches)} of {len(sample_edges)} sampled edges did not match "
                "source: instruction or target not present at edge.line"
            ),
            sample=edge_mismatches[:5],
        )
    )

    return report


# ---------------------------------------------------------------------------
# C++ checks
# ---------------------------------------------------------------------------

def _validate_cpp(file_rel: str, bp: dict, src: List[str], rng: random.Random) -> FileReport:
    report = FileReport(file_path=file_rel, file_kind="cpp")
    abs_path = str(settings.REPO_ROOT / file_rel)

    symbols = (bp.get("symbols") or {}).get("global_symbols") or {}
    entries: List[Tuple[str, int]] = []
    for name, val in symbols.items():
        if not (isinstance(val, dict) and val.get("type") == "entry"):
            continue
        if str(val.get("file") or "") != abs_path:
            continue
        s = (val.get("provenance") or {}).get("original_line")
        if isinstance(s, int):
            entries.append((name, s))
    entries.sort(key=lambda t: t[1])

    # ── PC1: function name + '(' present at provenance.original_line ──────
    sample_entries = rng.sample(entries, min(10, len(entries))) if entries else []
    name_mismatches = []
    for name, s in sample_entries:
        window = "\n".join(_line(src, n) for n in (s - 1, s, s + 1) if n >= 1)
        if name not in window:
            name_mismatches.append({"name": name, "line": s, "got": _line(src, s)[:120]})
    report.checks.append(
        Check(
            id="PC1",
            passed=(not name_mismatches),
            detail=(
                f"{len(name_mismatches)} of {len(sample_entries)} sampled C++ entries did not "
                "have their function name present at/near provenance.original_line"
            ),
            sample=name_mismatches[:5],
        )
    )

    # ── PC2: derived end_line doesn't cut into next function signature ───
    overlaps = []
    for i, (name, s) in enumerate(entries[:-1]):
        next_name, next_start = entries[i + 1]
        derived_end = next_start - 1
        if derived_end < s:
            overlaps.append({"name": name, "start": s, "next_start": next_start})
    report.checks.append(
        Check(
            id="PC2",
            passed=(not overlaps),
            detail=f"{len(overlaps)} adjacent C++ entries overlap (next start <= this start+1)",
            sample=overlaps[:5],
        )
    )

    # ── PC3: call_graph.edges line mentions target function ──────────────
    edges = ((bp.get("call_graph") or {}).get("edges") or [])
    sample_edges = rng.sample(edges, min(10, len(edges))) if edges else []
    edge_mismatches = []
    for e in sample_edges:
        line_no = e.get("line")
        target = e.get("target") or ""
        if not isinstance(line_no, int):
            continue
        window = "\n".join(_line(src, n) for n in (line_no, line_no + 1) if n >= 1)
        if target not in window:
            edge_mismatches.append({
                "source": e.get("source"), "target": target, "line": line_no,
                "got": _line(src, line_no)[:120],
            })
    report.checks.append(
        Check(
            id="PC3",
            passed=(not edge_mismatches),
            detail=(
                f"{len(edge_mismatches)} of {len(sample_edges)} sampled C++ edges did not "
                "mention the target name at edge.line"
            ),
            sample=edge_mismatches[:5],
        )
    )

    return report


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------

def validate_process(process_name: str, seed: int = 42) -> Dict[str, Any]:
    pdir = settings.DATA_PROCESSES_DIR / process_name
    fg_path = pdir / "file_graph.json"
    if not fg_path.is_file():
        raise FileNotFoundError(f"file_graph.json missing for {process_name}")
    fg = json.loads(fg_path.read_text(encoding="utf-8"))
    files = list(fg.get("files") or [])

    rng = random.Random(seed)
    reports: List[FileReport] = []
    skipped: List[Dict[str, str]] = []

    for fp in files:
        bp_path = blueprint_path_for(settings.REPO_ROOT, fp)
        src_path = settings.REPO_ROOT / fp
        if not bp_path.is_file():
            skipped.append({"file": fp, "reason": f"blueprint missing: {bp_path}"})
            continue
        if not src_path.is_file():
            skipped.append({"file": fp, "reason": f"source missing: {src_path}"})
            continue
        bp = json.loads(bp_path.read_text(encoding="utf-8"))
        src = _read_source(src_path)
        kind = file_kind_for(fp)
        if kind == "asm":
            reports.append(_validate_asm(fp, bp, src, rng))
        else:
            reports.append(_validate_cpp(fp, bp, src, rng))

    overall_pass = all(r.passed for r in reports)

    payload = {
        "process": process_name,
        "seed": seed,
        "files_checked": len(reports),
        "files_skipped": skipped,
        "overall_pass": overall_pass,
        "reports": [
            {
                "file_path": r.file_path,
                "file_kind": r.file_kind,
                "checks": [asdict(c) for c in r.checks],
                "passed": r.passed,
            }
            for r in reports
        ],
    }
    return payload


def _aggregate_failures(payload: Dict[str, Any]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for r in payload["reports"]:
        for c in r["checks"]:
            if not c["passed"]:
                counts[c["id"]] = counts.get(c["id"], 0) + 1
    return counts


# ---------------------------------------------------------------------------
# Variable-universe validation (Phase 4 pre-flight; Rule 6)
# ---------------------------------------------------------------------------

ASM_DECL_RE = re.compile(r"\b(DS|DC|EQU|CSECT|DSECT)\b")
CPP_DECL_HINT_RE = re.compile(
    r"\b(int|short|long|char|unsigned|signed|float|double|bool|void|"
    r"struct|union|enum|class|auto|const|static|extern|register|typedef|"
    r"size_t|uint8_t|uint16_t|uint32_t|uint64_t|"
    r"[A-Z][A-Za-z0-9_]*)\b"
)


def _validate_asm_universe_entry(entry: dict, src_by_path: Dict[str, List[str]]) -> Optional[Dict[str, Any]]:
    name = entry.get("name") or ""
    file_path = entry.get("file") or ""
    line = entry.get("line")
    decl_type = (entry.get("declaration_type") or "").upper()
    if not (name and isinstance(line, int) and file_path):
        return {"reason": "missing_fields", "entry": {"name": name, "file": file_path, "line": line}}
    p = Path(file_path)
    if not p.is_absolute():
        p = settings.REPO_ROOT / file_path
    rel = str(p.relative_to(settings.REPO_ROOT)) if p.is_relative_to(settings.REPO_ROOT) else str(p)
    if rel not in src_by_path:
        if not p.is_file():
            return {"reason": "source_missing", "file": rel}
        src_by_path[rel] = _read_source(p)
    src = src_by_path[rel]
    if line < 1 or line > len(src):
        return {"reason": "line_out_of_range", "file": rel, "line": line, "src_lines": len(src)}
    window = "\n".join(_line(src, n) for n in (line - 1, line, line + 1) if n >= 1).upper()
    if name.upper() not in window:
        return {
            "reason": "name_not_at_line",
            "name": name, "file": rel, "line": line,
            "got": _line(src, line)[:100],
        }
    if decl_type and decl_type in ("DS", "DC", "EQU"):
        if decl_type not in window:
            return {
                "reason": "declaration_type_not_at_line",
                "name": name, "expected": decl_type, "file": rel, "line": line,
                "got": _line(src, line)[:100],
            }
    elif not ASM_DECL_RE.search(window):
        return {
            "reason": "no_declaration_keyword_at_line",
            "name": name, "file": rel, "line": line,
            "got": _line(src, line)[:100],
        }
    return None


def _validate_cpp_universe_entry(entry: dict, src_by_path: Dict[str, List[str]]) -> Optional[Dict[str, Any]]:
    name = entry.get("name") or ""
    file_path = entry.get("file") or ""
    line = entry.get("line")
    if not (name and isinstance(line, int) and file_path):
        return {"reason": "missing_fields", "entry": {"name": name, "file": file_path, "line": line}}
    p = Path(file_path)
    if not p.is_absolute():
        p = settings.REPO_ROOT / file_path
    rel = str(p.relative_to(settings.REPO_ROOT)) if p.is_relative_to(settings.REPO_ROOT) else str(p)
    if rel not in src_by_path:
        if not p.is_file():
            return {"reason": "source_missing", "file": rel}
        src_by_path[rel] = _read_source(p)
    src = src_by_path[rel]
    if line < 1 or line > len(src):
        return {"reason": "line_out_of_range", "file": rel, "line": line, "src_lines": len(src)}
    # ±5 line tolerance — C++ enum members and struct fields are declared
    # inside container braces; tree-sitter reports the enum/struct opener
    # as the parent line. Up to 5 lines of slack absorbs that.
    window_start, window_end = max(1, line - 5), min(len(src), line + 5)
    window = "\n".join(_line(src, n) for n in range(window_start, window_end + 1))
    if name not in window:
        return {
            "reason": "name_not_in_window",
            "name": name, "file": rel, "line": line,
            "window_lines": [window_start, window_end],
            "got": _line(src, line)[:120],
        }
    return None


def validate_variable_universes(
    sample_size: int = 50, seed: int = 42, restrict_to_process: Optional[str] = None
) -> Dict[str, Any]:
    """Sample variables from asm_variable_universe.json + cpp_variable_universe.json
    and check each one's (file, line) anchor against source.

    If ``restrict_to_process`` is given, sample only variables whose declaration
    file is in that process's file_graph.
    """
    rng = random.Random(seed)
    asm_uni_path = settings.TEMP_OUTPUT_DIR / "asm_variable_universe.json"
    cpp_uni_path = settings.TEMP_OUTPUT_DIR / "cpp_variable_universe.json"

    asm_uni = json.loads(asm_uni_path.read_text(encoding="utf-8"))
    cpp_uni = json.loads(cpp_uni_path.read_text(encoding="utf-8"))

    # The universe shape (validated 2026-05-27): root dict with key
    # ``variables`` whose value is ``{name: [entry, entry, ...]}`` — a dict
    # of NAME → LIST of declaration sites (one entry per location). We
    # flatten by iterating both levels.
    def _flatten(uni: Any) -> List[dict]:
        if isinstance(uni, list):
            return [e for e in uni if isinstance(e, dict)]
        if not isinstance(uni, dict):
            return []
        vars_field = uni.get("variables")
        if isinstance(vars_field, list):
            return [e for e in vars_field if isinstance(e, dict)]
        if isinstance(vars_field, dict):
            out: List[dict] = []
            for k, v in vars_field.items():
                if isinstance(v, dict):
                    v.setdefault("name", k)
                    out.append(v)
                elif isinstance(v, list):
                    for entry in v:
                        if isinstance(entry, dict):
                            entry.setdefault("name", k)
                            out.append(entry)
            return out
        for k in ("entries", "items", "data"):
            if isinstance(uni.get(k), list):
                return [e for e in uni[k] if isinstance(e, dict)]
        return []

    asm_entries = _flatten(asm_uni)
    cpp_entries = _flatten(cpp_uni)

    file_filter: Optional[set] = None
    if restrict_to_process:
        fg = json.loads(
            (settings.DATA_PROCESSES_DIR / restrict_to_process / "file_graph.json").read_text(encoding="utf-8")
        )
        file_filter = {f for f in (fg.get("files") or [])}

    def _in_scope(entry: dict) -> bool:
        if file_filter is None:
            return True
        fp = entry.get("file") or ""
        rel = fp
        if Path(fp).is_absolute():
            try:
                rel = str(Path(fp).relative_to(settings.REPO_ROOT))
            except ValueError:
                rel = fp
        return rel in file_filter

    asm_scoped = [e for e in asm_entries if _in_scope(e)]
    cpp_scoped = [e for e in cpp_entries if _in_scope(e)]

    src_cache: Dict[str, List[str]] = {}

    def _sample_and_check(entries: List[dict], check_fn) -> Tuple[int, List[Dict[str, Any]]]:
        if not entries:
            return 0, []
        n = min(sample_size, len(entries))
        sample = rng.sample(entries, n)
        issues: List[Dict[str, Any]] = []
        for e in sample:
            r = check_fn(e, src_cache)
            if r is not None:
                issues.append(r)
        return n, issues

    asm_n, asm_issues = _sample_and_check(asm_scoped, _validate_asm_universe_entry)
    cpp_n, cpp_issues = _sample_and_check(cpp_scoped, _validate_cpp_universe_entry)

    payload = {
        "seed": seed,
        "sample_size": sample_size,
        "restrict_to_process": restrict_to_process,
        "asm_universe": {
            "total_entries": len(asm_entries),
            "in_scope_entries": len(asm_scoped),
            "sampled": asm_n,
            "issues": asm_issues,
            "passed": (not asm_issues),
        },
        "cpp_universe": {
            "total_entries": len(cpp_entries),
            "in_scope_entries": len(cpp_scoped),
            "sampled": cpp_n,
            "issues": cpp_issues,
            "passed": (not cpp_issues),
        },
        "overall_pass": (not asm_issues) and (not cpp_issues),
    }
    return payload


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    ap.add_argument("--process", required=True)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default=None, help="JSON output path (default: docs/parser_validation_<P>.json)")
    ap.add_argument(
        "--mode",
        choices=("blueprints", "universes", "all"),
        default="blueprints",
        help="What to validate. 'blueprints' = per-file blueprint vs source; "
             "'universes' = variable-universe JSONs vs source; 'all' = both.",
    )
    ap.add_argument("--sample-size", type=int, default=50, help="Variable universe sample size")
    args = ap.parse_args()

    overall_pass = True
    summaries: List[str] = []

    if args.mode in ("blueprints", "all"):
        payload = validate_process(args.process, seed=args.seed)
        out_path = (
            Path(args.out)
            if args.out
            else REPO / "process_analysis" / "docs" / f"parser_validation_{args.process}.json"
        )
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

        fail_counts = _aggregate_failures(payload)
        summaries.append(f"Blueprints — files checked: {payload['files_checked']}, skipped: {len(payload['files_skipped'])}, pass: {payload['overall_pass']}")
        if fail_counts:
            for cid, n in sorted(fail_counts.items()):
                summaries.append(f"  {cid}: {n} file(s) failed")
        summaries.append(f"  -> {out_path.relative_to(REPO)}")
        overall_pass = overall_pass and payload["overall_pass"]

    if args.mode in ("universes", "all"):
        vpayload = validate_variable_universes(
            sample_size=args.sample_size, seed=args.seed, restrict_to_process=args.process
        )
        vout = REPO / "process_analysis" / "docs" / f"parser_validation_universe_{args.process}.json"
        vout.parent.mkdir(parents=True, exist_ok=True)
        vout.write_text(json.dumps(vpayload, indent=2), encoding="utf-8")
        a = vpayload["asm_universe"]
        c = vpayload["cpp_universe"]
        summaries.append(
            f"ASM universe — total: {a['total_entries']}, in-scope: {a['in_scope_entries']}, "
            f"sampled: {a['sampled']}, issues: {len(a['issues'])}, pass: {a['passed']}"
        )
        summaries.append(
            f"C++ universe — total: {c['total_entries']}, in-scope: {c['in_scope_entries']}, "
            f"sampled: {c['sampled']}, issues: {len(c['issues'])}, pass: {c['passed']}"
        )
        summaries.append(f"  -> {vout.relative_to(REPO)}")
        overall_pass = overall_pass and vpayload["overall_pass"]

    print(f"Process: {args.process}  (mode={args.mode})")
    for s in summaries:
        print("  " + s)
    print(f"  overall pass  : {overall_pass}")
    return 0 if overall_pass else 1


if __name__ == "__main__":
    raise SystemExit(main())
