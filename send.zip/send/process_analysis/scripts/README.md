# explanability_demo/scripts

> Two different generators live here. `build_process_data.py` builds the
> **backend** graph artifacts under `data/processes/<PROC>/`.
> `export_ui_process_data.py` builds the **demo UI** fixtures under
> `explanability_demo/process_data/<Process>/`. They do not overlap.

## `export_ui_process_data.py`

Populates the 7 demo-UI fixtures for **both** demo processes under
`explanability_demo/process_data/<Process>/` with the **real data the running
app renders**, reshaped into the existing fixture contract so a *different*
frontend can render them statically (no backend needed).

It reads from the **live backend HTTP API** (default `http://localhost:8010`,
project `default`) — the same endpoints the demo UI calls — and preserves
every existing JSON key. Process mapping: `C400 -> C400`,
`Plastic -> plastic_authentication`.

| Fixture | Source endpoint(s) | Transform |
|---|---|---|
| `process-summary.json` | `GET /narrative` | 4 sections → one `{markdown}` blob |
| `overview-file-list.json` | `GET /file-graph` | `files[]` verbatim |
| `includes-macros.json` | `GET /headers` + `/macros` | counts |
| `complexity-metrics.json` | derived | `files`/`callEdges` from file-graph, `variables` from `/variables` total, `blocks` summed from file details, `maxCallDepth` computed from the call graph |
| `variable-explorer.json` | `GET /variables` (+ `/context` per name) | one entry per **unique** variable; `category`=primary label; `description`=short purpose + the coverage-gated `/context` analysis as markdown (declaration location excluded; identical declaration analyses collapsed) |
| `file-explorer.json` | per-file `GET /files/<path>` | file `business_name`/`purpose`/`kind` + blocks (`block_id`, `business_name`, `line_start-line_end`, `purpose`) |
| `walkthrough.json` | — | kept as-is (generic UI feature boxes, not process data) |

```bash
# Backend must be running (e.g. uvicorn ... --port 8010) with both processes built.
python3 explanability_demo/scripts/export_ui_process_data.py
python3 explanability_demo/scripts/export_ui_process_data.py --process C400
python3 explanability_demo/scripts/export_ui_process_data.py --base-url http://localhost:8010 --dry-run
```

Note: a few heavily-declared cpp variables (e.g. Plastic `lwrCommon` has 49
declarations) produce large markdown descriptions because the UI shows one
analysis per declaration. The full `variable-explorer.json` is ~0.5 MB (C400)
and ~1.5 MB (Plastic).

**Post-processing (every run):** any code-file path is collapsed to its file
name (`temp/asm/da78.asm` → `da78.asm`) across all output, and the run fails
loudly if any machine-specific absolute path (`/Users/...`) leaks into a
fixture. Prose containing slashes (e.g. "and/or") is left untouched — only
tokens ending in `.asm/.cpp/.hpp/.h/.mac` are rewritten.

## `build_process_data.py`

Regenerates `data/processes/<PROC>/{file_graph,headers,macros}.json` from the
**real** deterministic pipeline outputs in `process/`. Replaces the random
stub previously emitted by `data/processes/_generate_seeds.py`.

### Prereqs

The four-step pipeline in [`process/Algorithm.md`](../../process/Algorithm.md)
must have produced `process/process_truncated_file_graph.json`. If it hasn't:

```bash
python3 process/build_process_truncated_file_graph.py \
  --process-json process/lu82_function_processes.json \
  --guarded-json process/process_guarded_file_calls.json \
  --file-call-graph process/file_call_graph.json \
  --output process/process_truncated_file_graph.json
```

### Usage

```bash
# Dry-run (no writes, prints stats only):
python3 explanability_demo/scripts/build_process_data.py --process C400 --dry-run

# Real run, replacing any prior file_graph/headers/macros json:
python3 explanability_demo/scripts/build_process_data.py --process C400 --purge
```

`--purge` deletes other files in `data/processes/<PROC>/` *except*
`metadata.json` and `predefined_questions.json` (those are hand-curated).

### Output shapes

- **`file_graph.json`** — `{seed_file, seed_function, seed_segment, process,
  file_count, edge_count, edge_types{}, files[], edges[], source{}}`.
  Each edge is one call-site (so multiple call sites between the same pair of
  files produce multiple rows). The `seed_segment` is the LU82 FUNCTION
  segment token (e.g., `DX75` → resolves to `dx750000`).
- **`headers.json`** — counts + `headers_found[]` + `headers_missing[]`
  obtained by source-scanning `#include` directives in every `.cpp`/`.hpp`
  of the process graph against `temp/asm/`. Parser blueprints'
  `file_dependencies` field is empty in this corpus and is **not** consumed.
- **`macros.json`** — per-`.asm`-file `macros_used[]` + `mac_files[]`,
  obtained by source-scanning opcodes against the set of `.mac` basenames in
  `temp/asm/`. Parser blueprints' `macro_expansions` field is null-populated
  in this corpus and is **not** consumed.

### Validation done for C400

- DFS from `temp/asm/lu82.asm` reproduces the chain
  `lu82 → dx750000 → dx710000 → dx730000 → dx740200 → da78 → ...` exactly
  as specified.
- 16 nodes, 20 edges. Edge types: `cpp_to_cpp:6 cpp_to_asm:1 asm_to_asm:9
  asm_to_cpp:4`.
- `lu82.asm` confirmed to use 0 of the 9 macros in `temp/asm/` (verified
  independently with `grep`); macro scan output is `[]` for it.
- 2 headers resolved (`ccda7gl.hpp`, `cclg1g1.hpp`), 41 missing (all are
  external system / TPF headers not shipped with `temp/asm/`).

### Re-running for other processes

`process_truncated_file_graph.json` lists all 24 processes that have
reachable subgraphs in the current `temp/asm/` corpus. Examples:

```bash
python3 explanability_demo/scripts/build_process_data.py --process C112
python3 explanability_demo/scripts/build_process_data.py --process plastic_authentication --purge
```

If the process is in `process_truncated_file_graph.json` but has zero
reachable nodes, the script raises a clear error. If the process name is not
in the LU82 catalog at all, the error message lists available names.
