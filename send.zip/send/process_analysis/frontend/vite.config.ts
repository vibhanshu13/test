import path from 'node:path'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { TanStackRouterVite } from '@tanstack/router-plugin/vite'

// explanability_demo frontend
// - Proxies /demo/v1/* to the local backend on :8010 so we can use relative URLs
//   in code and avoid CORS during dev.
// - Path alias `@/` -> `./src` (matches shadcn convention).
// - TanStackRouterVite generates the typed route tree from src/routes/*.
export default defineConfig({
  plugins: [
    TanStackRouterVite({ routesDirectory: './src/routes', generatedRouteTree: './src/routeTree.gen.ts' }),
    react(),
    tailwindcss(),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 5173,
    proxy: {
      '/demo': {
        target: 'http://127.0.0.1:8010',
        changeOrigin: false,
      },
    },
  },
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./src/test/setup.ts'],
  },
})
