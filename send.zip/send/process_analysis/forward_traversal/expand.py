"""G6 — subroutine expansion + G8 — 4-level target resolution + G13 — instruction classification.

The upstream ``forward_trace_lineage.py`` records ``SUBROUTINE_CALL`` nodes
but does NOT walk into the called subroutine's body (probed and confirmed
2026-05-27). For business-language explanations we need that body visible.

This module post-processes the wrapper's already-filtered node list:

  * **expand_subroutines(...)**  — for each SUBROUTINE_CALL, resolve target
    via backward's 4-level resolver, fetch body flow entries from the
    blueprint, and append synthetic ``SUBROUTINE_BODY`` nodes annotated
    with ``expansion_depth``. Bounded by ``max_subroutine_depth`` and
    ``max_subroutine_nodes`` (mirrors backward's defaults).

  * **classify_instructions(...)** — annotate every node with an
    ``inst_class`` list (any of ``"setter"``, ``"trigger"``, ``"branch"``,
    ``"subroutine"``, ``"return"``, ``"cross_file"``, ``"register_move"``)
    derived from backward's authoritative instruction sets. Useful for
    business-language synthesis (Phase 7+).

All inputs from ``backward_traversal/*`` are imported READ-ONLY per Rule 5.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from backward_traversal.glossary.instructions import (  # noqa: E402
    BRANCH_INST,
    CROSS_FILE_INST,
    REGISTER_INDIRECT_MOVE_INST,
    RETURN_OPCODES,
    SETTER_INST,
    SUBROUTINE_CALL_OPCODES,
    TRIGGER_INST,
)
from backward_traversal.utils.subroutine_resolution import (  # noqa: E402
    extract_subroutine_target,
    resolve_subroutine_target,
)

from process_analysis.backend.config import settings
from process_analysis.forward_traversal.blueprint_cache import load_blueprint

logger = logging.getLogger("process_analysis.forward_traversal.expand")


# ---------------------------------------------------------------------------
# G13 — instruction classification
# ---------------------------------------------------------------------------

def _classes_for(inst: str) -> List[str]:
    if not inst:
        return []
    u = inst.upper()
    out: List[str] = []
    if u in SETTER_INST:
        out.append("setter")
    if u in TRIGGER_INST:
        out.append("trigger")
    if u in BRANCH_INST:
        out.append("branch")
    if u in SUBROUTINE_CALL_OPCODES:
        out.append("subroutine")
    if u in RETURN_OPCODES:
        out.append("return")
    if u in CROSS_FILE_INST:
        out.append("cross_file")
    if u in REGISTER_INDIRECT_MOVE_INST:
        out.append("register_move")
    return out


def classify_instructions(nodes: List[Dict[str, Any]]) -> None:
    """Add an ``inst_class`` list (in-place) to every node with an ``inst``."""
    for n in nodes:
        cls = _classes_for(n.get("inst") or "")
        if cls:
            n["inst_class"] = cls


# ---------------------------------------------------------------------------
# G14 — OC self-zero + BZ pattern reclassification
# ---------------------------------------------------------------------------

_BZ_LIKE: Set[str] = {"BZ", "BZR", "JZ"}


def reclassify_oc_bz_patterns(nodes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Re-classify OC self-zero + BZ pairs as CONDITION_TEST.

    Pattern: a node with inst='OC' where the operand is <field>,<field>
    (self-OR, e.g. 'OC WB1SW6,WB1SW6') immediately preceding a node
    with inst in {'BZ', 'BZR', 'JZ'} in the same file+block sequence.
    The OC node's role is changed from SIDE_EFFECT_SETTER → CONDITION_TEST.
    The BZ node's role is changed from FALLTHROUGH_ENTRY/BRANCH_ENTRY → BRANCH_ON_CONDITION.
    """
    # Group nodes by (file, block), preserving original list indices.
    from collections import defaultdict
    groups: Dict[Tuple[str, str], List[Tuple[int, Dict[str, Any]]]] = defaultdict(list)
    for idx, node in enumerate(nodes):
        key = (node.get("file") or "", node.get("block") or "")
        groups[key].append((idx, node))

    # For each group sorted by line, detect consecutive OC+BZ pairs.
    for key, indexed_nodes in groups.items():
        # Sort by line number; treat None lines as 0 for ordering.
        indexed_nodes.sort(key=lambda t: t[1].get("line") or 0)

        for i in range(len(indexed_nodes) - 1):
            _idx_i, node_i = indexed_nodes[i]
            _idx_j, node_j = indexed_nodes[i + 1]

            # Check OC self-zero pattern on node_i.
            inst_i = (node_i.get("inst") or "").upper()
            if inst_i != "OC":
                continue

            detail = node_i.get("detail") or ""
            if "," not in detail:
                continue
            parts = [p.strip() for p in detail.split(",", 1)]
            if len(parts) != 2 or not parts[0] or parts[0] != parts[1]:
                continue

            # Check BZ-like instruction on node_j within 2 lines.
            inst_j = (node_j.get("inst") or "").upper()
            if inst_j not in _BZ_LIKE:
                continue

            line_i = node_i.get("line") or 0
            line_j = node_j.get("line") or 0
            if isinstance(line_i, int) and isinstance(line_j, int):
                if abs(line_j - line_i) > 2:
                    continue

            # Reclassify.
            node_i["role"] = "CONDITION_TEST"
            node_j["role"] = "BRANCH_ON_CONDITION"

    return nodes


# ---------------------------------------------------------------------------
# G6 — subroutine expansion
# ---------------------------------------------------------------------------

def _flow_entries_for_target(
    blueprint: Dict[str, Any],
    target_label: str,
    asm_file_abs: Optional[Path],
) -> Tuple[List[Dict[str, Any]], Optional[Dict[str, Any]], Optional[str]]:
    """Resolve target → return (flow_entries, resolution_info, resolved_block_id).

    ``resolution_info`` is the raw dict from
    ``resolve_subroutine_target(...)`` — schema verified 2026-05-27:
        {requested_target, normalized_target, resolved_label,
         start_line, end_line, resolution_confidence, ...}

    A non-empty ``resolution_confidence`` (not ``"unresolved"``) means the
    target landed on either a subroutine or block. ``resolved_label`` is the
    block (or subroutine-id, which is also a block label) we should fetch
    from ``blueprint['blocks']``.
    """
    info = resolve_subroutine_target(blueprint, target_label, asm_file=asm_file_abs)
    if not info:
        return [], None, None
    conf = (info.get("resolution_confidence") or "").lower()
    if not conf or conf in ("unresolved", "not_found", "none"):
        return [], info, None

    resolved_label = info.get("resolved_label") or info.get("normalized_target")
    if not resolved_label:
        return [], info, None

    blocks = {b.get("id"): b for b in (blueprint.get("blocks") or [])}
    body_block = blocks.get(resolved_label)
    if not body_block:
        # Fall back: find any block whose id starts with the resolved label
        # or whose start_line matches the resolver's start_line.
        target_start = info.get("start_line")
        for bid, b in blocks.items():
            if target_start and b.get("start_line") == target_start:
                body_block = b
                resolved_label = bid
                break
    if not body_block:
        return [], info, None

    flow = body_block.get("flow") or []
    return list(flow), info, resolved_label


def _expand_one_call(
    parent_node: Dict[str, Any],
    blueprint_dir: Path,
    asm_dir: Path,
    depth: int,
    visited: Set[Tuple[str, str]],
) -> List[Dict[str, Any]]:
    """Return synthetic body nodes for ``parent_node`` (a SUBROUTINE_CALL).

    The visited set keys on ``(file, target_block_id)`` so we don't expand
    the same subroutine more than once per trace.
    """
    file_rel = parent_node.get("file") or ""
    if not file_rel:
        return []
    file_name = Path(file_rel).name
    blueprint_path = blueprint_dir / f"{file_name}.json"
    bp = load_blueprint(str(blueprint_path))
    if not bp:
        return []

    args = parent_node.get("args") or []
    detail = parent_node.get("detail") or ""
    target_label = extract_subroutine_target(args, detail)
    if not target_label:
        return []

    flow, info, resolved_block_id = _flow_entries_for_target(
        bp, target_label, asm_dir / file_name if asm_dir else None
    )
    if not flow or not resolved_block_id:
        return []
    key = (file_rel, str(resolved_block_id))
    if key in visited:
        return []
    visited.add(key)

    body: List[Dict[str, Any]] = []
    for fe in flow:
        body.append({
            "file": file_rel,
            "block": str(resolved_block_id),
            "line": fe.get("line"),
            "inst": fe.get("inst"),
            "args": fe.get("args"),
            "role": "SUBROUTINE_BODY",
            "expansion_depth": depth,
            "expansion_parent_block": parent_node.get("block"),
            "expansion_parent_line": parent_node.get("line"),
            "resolution_confidence": (info or {}).get("resolution_confidence"),
        })
    return body


def expand_subroutines(
    nodes: List[Dict[str, Any]],
    blueprint_dir: Path,
    asm_dir: Path,
    *,
    max_subroutine_depth: int = 1,
    max_subroutine_nodes: int = 400,
) -> Dict[str, int]:
    """Expand SUBROUTINE_CALL bodies in-place into ``nodes``.

    Inserts SUBROUTINE_BODY nodes immediately after each call site.
    Honors ``max_subroutine_depth`` (recursive expansion of nested calls)
    and ``max_subroutine_nodes`` (total cap across the whole expansion).

    Returns counters for the manifest.
    """
    if max_subroutine_depth < 1:
        return {"call_sites_expanded": 0, "body_nodes_added": 0, "cap_hit": False}

    counters = {"call_sites_expanded": 0, "body_nodes_added": 0, "cap_hit": False}
    visited: Set[Tuple[str, str]] = set()
    work: List[Dict[str, Any]] = list(nodes)
    out: List[Dict[str, Any]] = []
    queue: List[Tuple[Dict[str, Any], int]] = []  # (call_node, depth)

    for n in work:
        out.append(n)
        if n.get("role") == "SUBROUTINE_CALL":
            queue.append((n, 1))

    cursor = 0
    while cursor < len(queue):
        call_node, depth = queue[cursor]
        cursor += 1
        if counters["body_nodes_added"] >= max_subroutine_nodes:
            counters["cap_hit"] = True
            break
        body = _expand_one_call(call_node, blueprint_dir, asm_dir, depth, visited)
        if not body:
            continue
        # Insert after the call node's position
        insert_at = out.index(call_node) + 1
        # Trim if we would exceed the cap
        room = max_subroutine_nodes - counters["body_nodes_added"]
        if len(body) > room:
            body = body[:room]
            counters["cap_hit"] = True
        out[insert_at:insert_at] = body
        counters["call_sites_expanded"] += 1
        counters["body_nodes_added"] += len(body)
        if depth < max_subroutine_depth:
            for bn in body:
                if bn.get("inst", "").upper() in SUBROUTINE_CALL_OPCODES:
                    queue.append((bn, depth + 1))

    nodes[:] = out
    return counters
