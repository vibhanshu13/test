"""G16 — Blueprint in-memory LRU cache with retry.

Centralises all blueprint JSON reads behind a single cached entry point so
that repeated reads of the same file during a BFS run are O(1) after the
first access.

Usage::

    from process_analysis.forward_traversal.blueprint_cache import (
        load_blueprint,
        clear_blueprint_cache,
    )

    bp = load_blueprint(str(abs_path))   # {} on any permanent failure
"""

from functools import lru_cache
from pathlib import Path
import json
import logging
import time

_log = logging.getLogger(__name__)
_MAX_RETRIES = 3
_RETRY_DELAY = 0.1  # seconds


@lru_cache(maxsize=512)
def load_blueprint(path: str) -> dict:
    """Load a parser blueprint, cached by absolute path string.

    Uses ``blueprint_io.load_blueprint`` which handles all on-disk formats:
    - Seekable per-key zstd frames with ``.bpidx`` sidecar (returns LazyBlueprint)
    - Legacy monolithic zstd+msgpack
    - Plain JSON

    Falls back to the legacy ``_read_json_bytes`` decoder if ``blueprint_io``
    is not importable.  Retries up to _MAX_RETRIES times on OSError (transient
    I/O).  Returns {} on permanent failure (missing file, undecodable content).
    """
    for attempt in range(_MAX_RETRIES):
        try:
            try:
                from blueprint_io import load_blueprint as _load_bp
                result = _load_bp(Path(path), skip_global_lineage=True)
            except ImportError:
                # Fallback: legacy decoder for plain-JSON / monolithic zstd+msgpack.
                from process_analysis.backend.pipeline.enumerate import _read_json_bytes
                result = _read_json_bytes(Path(path).read_bytes())
            return result if isinstance(result, dict) else {}
        except FileNotFoundError:
            return {}  # missing blueprint — not retryable
        except OSError as exc:
            if attempt < _MAX_RETRIES - 1:
                time.sleep(_RETRY_DELAY)
            else:
                _log.warning(
                    "Blueprint read failed after %d retries: %s — %s",
                    _MAX_RETRIES,
                    path,
                    exc,
                )
                return {}
        except (json.JSONDecodeError, ValueError, Exception) as exc:
            _log.warning("Blueprint decode error: %s — %s", path, exc)
            return {}
    return {}  # unreachable but satisfies type checkers


def clear_blueprint_cache() -> None:
    """For testing — reset the LRU cache."""
    load_blueprint.cache_clear()
