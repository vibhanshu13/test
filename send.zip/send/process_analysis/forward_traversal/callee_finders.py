"""G2 — Cross-file CALLEE finders (forward analog of backward's caller-finders).

Given a source file and the process file_graph edges, these finders locate all
files the source calls into, together with their entry-point block/symbol.

Rule 1: No LLM calls — purely deterministic graph traversal.
Rule 5: Only reads from backward_traversal (read-only); all new code lives here.

Each finder returns a list of dicts with shape:
    {
        "callee_file":        str,       # repo-relative path of the callee file
        "callee_entry_block": str | None, # first block/symbol in the callee blueprint
        "edge_type":          str,       # asm_to_asm | asm_to_cpp | cpp_to_cpp | cpp_to_asm
    }
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from process_analysis.forward_traversal.blueprint_cache import load_blueprint

logger = logging.getLogger("process_analysis.forward_traversal.callee_finders")


def _resolve_blueprint_path(callee_file: str, repo_root: Path) -> Optional[Path]:
    """Given a repo-relative callee file path, find its blueprint JSON.

    Blueprint naming convention (confirmed from expand.py and blueprint_utils):
        temp/output_latest/asm/<filename>.json
    where <filename> is the basename of the callee file (e.g. "da78.asm" or
    "dx710000.cpp"), giving "da78.asm.json" / "dx710000.cpp.json".
    """
    callee_path = Path(callee_file)
    callee_name = callee_path.name  # e.g. "da78.asm" or "dx710000.cpp"

    # Primary location: temp/output_latest/asm/
    bp_dir = repo_root / "temp" / "output_latest" / "asm"
    candidate = bp_dir / f"{callee_name}.json"
    if candidate.is_file():
        return candidate

    # Fallback: check alongside the callee file itself (rare)
    sibling = callee_path.parent / f"{callee_name}.json"
    sibling_abs = repo_root / sibling
    if sibling_abs.is_file():
        return sibling_abs

    return None


# ---------------------------------------------------------------------------
# Entry-point extraction helpers
# ---------------------------------------------------------------------------

def _asm_entry_block(bp: Dict[str, Any]) -> Optional[str]:
    """Return the id of the first block in an ASM/MAC blueprint."""
    blocks = bp.get("blocks") or []
    if blocks:
        return blocks[0].get("id") or None
    return None


def _cpp_entry_symbol(bp: Dict[str, Any]) -> Optional[str]:
    """Return the first key in symbols.global_symbols for a C++ blueprint."""
    gs = (bp.get("symbols") or {}).get("global_symbols") or {}
    if isinstance(gs, dict):
        for key in gs:
            return key  # dict preserves insertion order (Python 3.7+)
    return None


# ---------------------------------------------------------------------------
# The 4 public finders
# ---------------------------------------------------------------------------

def find_asm_to_asm_callees(
    from_file: str,
    file_graph_edges: List[Dict[str, Any]],
    repo_root: Path,
) -> List[Dict[str, Any]]:
    """Given an ASM file, find ASM files it calls into.

    Matches outgoing ``asm_to_asm`` edges where ``from_file`` equals the
    given file, then reads the callee ASM blueprint to get the entry block.

    Args:
        from_file: repo-relative path of the caller ASM file.
        file_graph_edges: list of edge dicts from file_graph.json["edges"].
        repo_root: absolute path to the repository root.

    Returns:
        List of ``{callee_file, callee_entry_block, edge_type}`` dicts.
    """
    results: List[Dict[str, Any]] = []
    for edge in file_graph_edges:
        if edge.get("edge_type") != "asm_to_asm":
            continue
        if edge.get("from_file") != from_file:
            continue
        callee_file = edge.get("to_file") or ""
        if not callee_file:
            continue

        entry_block: Optional[str] = None
        bp_path = _resolve_blueprint_path(callee_file, repo_root)
        if bp_path is not None:
            bp = load_blueprint(str(bp_path))
            if bp:
                entry_block = _asm_entry_block(bp)

        results.append({
            "callee_file": callee_file,
            "callee_entry_block": entry_block,
            "edge_type": "asm_to_asm",
        })

    return results


def find_asm_to_cpp_callees(
    from_file: str,
    file_graph_edges: List[Dict[str, Any]],
    repo_root: Path,
) -> List[Dict[str, Any]]:
    """Given an ASM file, find C++ files it calls into.

    Matches outgoing ``asm_to_cpp`` edges and reads the callee C++ blueprint
    to get the first global symbol as the entry point.

    Args:
        from_file: repo-relative path of the caller ASM file.
        file_graph_edges: list of edge dicts from file_graph.json["edges"].
        repo_root: absolute path to the repository root.

    Returns:
        List of ``{callee_file, callee_entry_block, edge_type}`` dicts.
    """
    results: List[Dict[str, Any]] = []
    for edge in file_graph_edges:
        if edge.get("edge_type") != "asm_to_cpp":
            continue
        if edge.get("from_file") != from_file:
            continue
        callee_file = edge.get("to_file") or ""
        if not callee_file:
            continue

        entry_block: Optional[str] = None
        bp_path = _resolve_blueprint_path(callee_file, repo_root)
        if bp_path is not None:
            bp = load_blueprint(str(bp_path))
            if bp:
                entry_block = _cpp_entry_symbol(bp)

        results.append({
            "callee_file": callee_file,
            "callee_entry_block": entry_block,
            "edge_type": "asm_to_cpp",
        })

    return results


def find_cpp_to_cpp_callees(
    from_file: str,
    file_graph_edges: List[Dict[str, Any]],
    repo_root: Path,
) -> List[Dict[str, Any]]:
    """Given a C++ file, find C++ files it calls into.

    Matches outgoing ``cpp_to_cpp`` edges and reads the callee C++ blueprint
    to get the first global symbol as the entry point.

    Args:
        from_file: repo-relative path of the caller C++ file.
        file_graph_edges: list of edge dicts from file_graph.json["edges"].
        repo_root: absolute path to the repository root.

    Returns:
        List of ``{callee_file, callee_entry_block, edge_type}`` dicts.
    """
    results: List[Dict[str, Any]] = []
    for edge in file_graph_edges:
        if edge.get("edge_type") != "cpp_to_cpp":
            continue
        if edge.get("from_file") != from_file:
            continue
        callee_file = edge.get("to_file") or ""
        if not callee_file:
            continue

        entry_block: Optional[str] = None
        bp_path = _resolve_blueprint_path(callee_file, repo_root)
        if bp_path is not None:
            bp = load_blueprint(str(bp_path))
            if bp:
                entry_block = _cpp_entry_symbol(bp)

        results.append({
            "callee_file": callee_file,
            "callee_entry_block": entry_block,
            "edge_type": "cpp_to_cpp",
        })

    return results


def find_cpp_to_asm_callees(
    from_file: str,
    file_graph_edges: List[Dict[str, Any]],
    repo_root: Path,
) -> List[Dict[str, Any]]:
    """Given a C++ file, find ASM files it calls into.

    Matches outgoing ``cpp_to_asm`` edges and reads the callee ASM blueprint
    to get the first block as the entry point.

    Args:
        from_file: repo-relative path of the caller C++ file.
        file_graph_edges: list of edge dicts from file_graph.json["edges"].
        repo_root: absolute path to the repository root.

    Returns:
        List of ``{callee_file, callee_entry_block, edge_type}`` dicts.
    """
    results: List[Dict[str, Any]] = []
    for edge in file_graph_edges:
        if edge.get("edge_type") != "cpp_to_asm":
            continue
        if edge.get("from_file") != from_file:
            continue
        callee_file = edge.get("to_file") or ""
        if not callee_file:
            continue

        entry_block: Optional[str] = None
        bp_path = _resolve_blueprint_path(callee_file, repo_root)
        if bp_path is not None:
            bp = load_blueprint(str(bp_path))
            if bp:
                entry_block = _asm_entry_block(bp)

        results.append({
            "callee_file": callee_file,
            "callee_entry_block": entry_block,
            "edge_type": "cpp_to_asm",
        })

    return results


# ---------------------------------------------------------------------------
# Convenience union
# ---------------------------------------------------------------------------

def find_all_callees(
    from_file: str,
    file_graph_edges: List[Dict[str, Any]],
    repo_root: Path,
) -> List[Dict[str, Any]]:
    """Union of all 4 finders for the given file.

    Calls each typed finder in turn and concatenates results. Ordering:
    asm_to_asm, asm_to_cpp, cpp_to_cpp, cpp_to_asm — matching edge_type
    alphabetical order so the output is deterministic.

    Args:
        from_file: repo-relative path of the source file (ASM or C++).
        file_graph_edges: list of edge dicts from file_graph.json["edges"].
        repo_root: absolute path to the repository root.

    Returns:
        Combined list of ``{callee_file, callee_entry_block, edge_type}`` dicts.
    """
    return (
        find_asm_to_asm_callees(from_file, file_graph_edges, repo_root)
        + find_asm_to_cpp_callees(from_file, file_graph_edges, repo_root)
        + find_cpp_to_cpp_callees(from_file, file_graph_edges, repo_root)
        + find_cpp_to_asm_callees(from_file, file_graph_edges, repo_root)
    )
