# explanability_demo/forward_traversal

Phase 6 — forward variable-usage lineage. Approved strategy (Q-P6a, 2026-05-27):
**wrap** the existing root-level `forward_trace_lineage.py` rather than
reimplement it from scratch. Rule 5 says we don't modify root-level code;
everything below is layered ON TOP of that file.

## Module map

```
forward_traversal/
├── __init__.py
├── runner.py          ← run_forward_only(process, variable, output_dir, ...)
│                        - resolves declaration_file from Phase-4 inventory
│                        - invokes ForwardLineageTracer.trace_forward()
│                        - filters to process scope (file_graph.json)
│                        - G10 dep-var BFS (opt-in via max_dep_var_depth)
│                        - Rule-6 source validation
│                        - emits partitioned JSON
└── validate.py        ← Rule-6 source-gate: (file, line) must exist + be
                         non-blank + non-comment
```

## Run

```python
from explanability_demo.forward_traversal.runner import run_forward_only
from pathlib import Path

manifest = run_forward_only(
    process="C400",
    variable="WB1SW6",
    output_dir=Path("/tmp/fwd_out"),
    declaration_file="temp/asm/xh80.asm",   # optional; auto-looked-up otherwise
    max_dep_var_depth=2,                    # G10 BFS depth; 0 disables
    max_dep_vars=20,                        # G10 BFS total cap
)
```

Or via HTTP:

```
POST /demo/v1/processes/{P}/variables/{V}/usage-flows
Content-Type: application/json
{}                       # all options have defaults
```

## Output (partitioned, mirrors backward_traversal's Q6 shape)

```
<output_dir>/
├── manifest.json                 # ForwardManifest dict
├── root_var.json                 # nodes (lineage_chain in scope) + edges
├── dep_vars/<NAME>.json          # in-scope dep_var occurrences (one file per name)
├── dep_var_traces/<NAME>.json    # G10 BFS expansions (depth, status, role_counts, children)
├── dep_files/cross_calls.json    # CROSS_FILE_CALL targets
└── warnings.json                 # tracer + Rule-6 validation warnings
```

## Phase-6 closed gaps (vs backward_traversal/)

See [`../docs/p6_gap_analysis.md`](../docs/p6_gap_analysis.md) for the full
table. Closed in this iteration:

| Gap | Capability | Status |
|---|---|---|
| **G10** | Two-pass dep-var BFS up to depth=2 | ✅ Wrapper recursively traces dep_vars (capped at max_dep_vars, default 20) |
| **G6** | Subroutine expansion + call-graph merging | ✅ `expand.py::expand_subroutines` — body nodes inserted after each call site with `expansion_depth` annotation |
| **G8** | 4-level subroutine target resolver | ✅ Read-only import from `backward_traversal.utils.subroutine_resolution` |
| **G13** | Instruction classification with 64-bit variants | ✅ `expand.py::classify_instructions` — every node tagged with `inst_class` list (setter/trigger/branch/subroutine/return/cross_file) |
| **G1** | C++ GVL forward tracer | ✅ `cpp_forward_tracer.py` — multi-seed BFS over GVL edges, mirrors backward cost model (assign/define/arg_bind +1, ecb_bridge/ce1cr_level_bridge +2, alias 0). Runner dispatches by file extension. |
| **G5** | C++ field/register alias extraction | ✅ Read-only import from `backward_traversal.utils.cpp_lineage_utils` |

## Still open (deferred per Q-P6d Track A→B→C)

| Gap | Capability | Track |
|---|---|---|
| G6 | Subroutine expansion + call-graph merging | A |
| G7 | Richer full-flow graph collection | A |
| G8 | 4-level subroutine resolver (read-only import) | A |
| G13/G14/G16 | Backward glossaries + blueprint cache | A |
| G1 | C++ GVL forward tracer | B (Critical) |
| G2 | All 4 cross-file caller types | B |
| G4 | Variable name identity resolver | B |
| G5 | C++ field / register alias extraction | B |
| G3 | Resumable session state machine | C |

## Validation

`scripts/validate_forward_baseline.py` records the current behavior across
3 representative C400 variables (WB1SW6, WB1SW1, A7AFTERGLHIST). All three
pass:
- Setter cross-check against parser blueprints: 100% coverage of direct
  writes.
- Rule-6 source validation: only 6.5% blank-line / comment-line false
  positives (CFG navigation nodes anchored to non-instruction lines).
- Out-of-scope file count: 0.

Report: `docs/v_fwd_baseline.json`. Re-run after every gap-closure to
confirm no regression.
