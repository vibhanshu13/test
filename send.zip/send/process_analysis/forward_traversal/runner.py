"""``run_forward_only`` — Phase 6 wrapper around ForwardLineageTracer.

Output (partitioned, mirrors backward_traversal's Q6 shape):

    <output_dir>/
        manifest.json                # high-level counts + scope info
        root_var.json                # filtered lineage_chain (nodes + edges)
        dep_vars/
            <NAME>.json              # one file per dependent variable
        dep_files/
            cross_calls.json         # files reached via CROSS_FILE_CALL
        warnings.json                # tracer + validation warnings

Every emitted ``(file, line)`` is checked by ``validate_emission()`` before
the JSON is written. A validation failure does not abort the run but is
recorded in ``warnings.json`` and the manifest's ``validation_warnings``
counter so downstream consumers can decide whether to surface it.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from process_analysis.backend.config import settings
from process_analysis.backend.db import get_conn

# ---------------------------------------------------------------------------
# G3 — Content-hash resumability
# ---------------------------------------------------------------------------

TRACER_VERSION = "ft-2026-05-27-v1"


def _compute_trace_hash(variable: str, declaration_file: str, tracer_version: str) -> str:
    """sha256 of variable + declaration_file + tracer_version concatenated."""
    payload = f"{variable}\x00{declaration_file}\x00{tracer_version}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()

# ``forward_trace_lineage.py`` lives at the repo root. uvicorn and pytest
# already put the repo root on sys.path; for CLI invocations we ensure it.
_REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from forward_trace_lineage import ForwardLineageTracer  # noqa: E402

from process_analysis.forward_traversal.cpp_forward_tracer import (
    trace_cpp_variable_forward_from_blueprint,
)
from process_analysis.forward_traversal.expand import (
    classify_instructions,
    expand_subroutines,
    reclassify_oc_bz_patterns,
)
from process_analysis.forward_traversal.validate import validate_emission

logger = logging.getLogger("process_analysis.forward_traversal")


# ---------------------------------------------------------------------------
# G4 — VariableNameResolver alias expansion (best-effort; never raises)
# ---------------------------------------------------------------------------

def _build_resolver(blueprint_dir: Path):
    """Instantiate VariableNameResolver; returns None on any failure.

    Failures are expected when data files (variable_identity_index.json,
    C++ blueprints) are absent — e.g. for processes that have no C++ layer.
    Caller must treat None as "no alias resolution available".
    """
    try:
        from backward_traversal.utils.variable_name_resolver import (
            VariableNameResolver,
        )
        return VariableNameResolver(blueprint_dir)
    except Exception as exc:  # noqa: BLE001
        logger.warning("G4: VariableNameResolver init failed (%s) — skipping alias expansion", exc)
        return None


def _resolve_dep_var_aliases(
    dep_vars_by_name: Dict[str, List[Dict[str, Any]]],
    declaration_file: str,
    blueprint_dir: Path,
) -> Dict[str, str]:
    """Return {original_name: alias_name} for each dep_var that resolves to a
    different name via VariableNameResolver (G4, 4-strategy resolution).

    Uses the dep_var's own file stem as ``target_stem`` and the declaration
    file stem as ``source_stem`` so that Cases C/D (arg_bind + struct
    canonical) have context when both stems differ.

    Never raises — any exception is logged at DEBUG level and skipped.
    """
    resolver = _build_resolver(blueprint_dir)
    if resolver is None:
        return {}

    source_stem = Path(declaration_file).stem
    aliases: Dict[str, str] = {}

    for name, entries in dep_vars_by_name.items():
        if not name or name == "(unknown)":
            continue
        # Derive target_stem from the dep_var entry's file (first occurrence).
        target_stem = source_stem  # sensible fallback when file info absent
        for entry in entries:
            f = entry.get("file") or ""
            if f:
                target_stem = Path(f).stem
                break
        try:
            alias = resolver.resolve(name, target_stem, source_stem=source_stem)
        except Exception as exc:  # noqa: BLE001
            logger.debug("G4: resolver.resolve(%r, %r) failed: %s", name, target_stem, exc)
            alias = None
        if alias and alias != name:
            aliases[name] = alias

    return aliases


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

@dataclass
class ForwardManifest:
    process: str
    variable: str
    declaration_file: str
    files_in_scope: List[str]
    node_count_raw: int
    node_count_in_scope: int
    role_counts: Dict[str, int]
    setter_like_count: int
    overwrite_count: int
    cross_file_call_count: int
    dep_var_count: int
    dep_var_count_in_scope: int
    # G10: dep-var BFS — how many dep_vars got their own forward trace, and
    # how deep we went. ``dep_var_traces`` mirrors backward's ``dep_var_traces``
    # output key: one entry per traced dep_var with depth + summary.
    dep_var_bfs_traced: int = 0
    dep_var_bfs_max_depth: int = 0
    # G6: subroutine-body expansion
    subroutine_call_sites_expanded: int = 0
    subroutine_body_nodes_added: int = 0
    subroutine_expansion_cap_hit: bool = False
    truncated: bool = False
    # G12: node-count cap
    truncated_at_nodes: int = 0
    # G15: visited-set cap
    visited_cap_hit: bool = False
    # G3: content-hash resumability
    content_hash: str = ""
    validation_warnings: int = 0
    tracer_warnings: int = 0
    started_at: str = ""
    finished_at: str = ""
    elapsed_sec: float = 0.0
    output_dir: str = ""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _repo_relative(path_like: Any) -> str:
    """Coerce an absolute or basename path to repo-relative form."""
    if path_like is None:
        return ""
    s = str(path_like)
    repo = str(settings.REPO_ROOT)
    if s.startswith(repo + os.sep):
        return s[len(repo) + 1 :]
    if "/" not in s and "\\" not in s:
        # Basename only: assume temp/asm/<name>
        if (settings.TEMP_ASM_DIR / s).is_file():
            return f"temp/asm/{s}"
    return s


def _lookup_declaration_file(process: str, variable: str) -> Optional[str]:
    """Find any in-process declaration file for the variable.

    Prefers the lowest declaration_line so the trace seed is near the top
    of the file (deterministic across re-runs).
    """
    with get_conn() as conn:
        row = conn.execute(
            """
            SELECT declaration_file, declaration_line
            FROM variable
            WHERE process = ? AND name = ?
            ORDER BY declaration_file, declaration_line
            LIMIT 1
            """,
            (process, variable),
        ).fetchone()
    return row["declaration_file"] if row else None


def _load_process_files(process: str) -> List[str]:
    fg_path = settings.DATA_PROCESSES_DIR / process / "file_graph.json"
    if not fg_path.is_file():
        raise FileNotFoundError(f"file_graph.json missing for {process}")
    fg = json.loads(fg_path.read_text(encoding="utf-8"))
    return list(fg.get("files") or [])


def _classify_setter_like(role: str) -> bool:
    """Roles that represent the variable itself being written or carried.

    Order of forward semantics:
      SETTER         — direct primary-target write
      SIDE_EFFECT_SETTER — multi-target write that also touches the variable
      OVERWRITE      — the variable gets overwritten (terminal forward)
    """
    return role in ("SETTER", "SIDE_EFFECT_SETTER", "OVERWRITE")


# ---------------------------------------------------------------------------
# Main entry
# ---------------------------------------------------------------------------

def run_forward_only(
    process: str,
    variable: str,
    output_dir: Path,
    *,
    declaration_file: Optional[str] = None,
    asm_dir: Optional[Path] = None,
    blueprint_dir: Optional[Path] = None,
    include_register_dependencies: bool = False,
    max_dep_var_depth: int = 0,
    max_dep_vars: int = 20,
    max_subroutine_depth: int = 1,
    max_subroutine_nodes: int = 400,
    max_nodes: int = 0,
    max_visited: int = 200_000,
    force_refresh: bool = False,
) -> ForwardManifest:
    """Forward-direction lineage trace for one variable in one process.

    Args:
        process: e.g. ``"C400"``.
        variable: variable name (case as in source).
        output_dir: where to write the partitioned JSON.
        declaration_file: repo-relative declaration file. If None we look
                          it up in the variable inventory (Phase 4 SQLite).
        asm_dir: defaults to ``settings.TEMP_ASM_DIR``.
        blueprint_dir: defaults to ``settings.TEMP_OUTPUT_DIR / 'asm'``.
        include_register_dependencies: passed through to the tracer.
        max_dep_var_depth: G10 — depth of dep-var BFS expansion. 0 disables
                           (only root variable is traced); 1 expands one
                           level of dep_vars; 2 mirrors backward's default
                           ``max_dep_var_depth=2``.
        max_dep_vars: G10 — total cap on dep_vars expanded across all
                      depths (matches backward's ``max_dep_vars=20``).
        max_subroutine_depth: G6 — depth of recursive subroutine-body
                              expansion. 0 disables; default 1.
        max_subroutine_nodes: G6 — total cap on synthetic body nodes
                              inserted across the entire trace (matches
                              backward's default 400).
        max_nodes: G12 — stop BFS and set ``truncated=True`` when the
                   in-scope node count reaches this value. Honours the
                   ``FORWARD_MAX_NODES`` env var; falls back to 50_000.
                   0 means "use env var / default".
        max_visited: G15 — safety cap on the BFS visited set. If
                     reached, BFS stops and ``visited_cap_hit=True``.
                     Default 200_000.
        force_refresh: G3 — if True, bypass the content-hash cache and
                       always re-run the BFS.

    Returns:
        The validated manifest. JSON files have been written to ``output_dir``.

    Raises:
        FileNotFoundError, ValueError on bad inputs (variable unknown,
        declaration file missing, blueprint missing).
    """
    asm_dir = asm_dir or settings.TEMP_ASM_DIR
    blueprint_dir = blueprint_dir or (settings.TEMP_OUTPUT_DIR / "asm")
    started = time.monotonic()
    started_iso = _utc_now_iso()

    # G12: resolve effective node cap (env var overrides default 50_000).
    _env_max_nodes = int(os.environ.get("FORWARD_MAX_NODES", "50000"))
    effective_max_nodes: int = max_nodes if max_nodes > 0 else _env_max_nodes

    if declaration_file is None:
        declaration_file = _lookup_declaration_file(process, variable)
        if declaration_file is None:
            raise ValueError(
                f"Variable {variable!r} not found in {process!r} inventory. "
                "Run the variable build first."
            )

    # G3: check content-hash cache now that declaration_file is resolved.
    content_hash = _compute_trace_hash(variable, declaration_file, TRACER_VERSION)
    if not force_refresh:
        cached = _load_cached_manifest(output_dir, content_hash)
        if cached is not None:
            logger.info(
                "G3: cache hit for %r/%r — returning cached manifest",
                variable,
                declaration_file,
            )
            return cached

    decl_path = settings.REPO_ROOT / declaration_file
    if not decl_path.is_file():
        raise FileNotFoundError(f"Declaration file missing: {decl_path}")
    blueprint_path = blueprint_dir / f"{decl_path.name}.json"
    if not blueprint_path.is_file():
        raise FileNotFoundError(f"Blueprint missing: {blueprint_path}")

    in_scope = set(_load_process_files(process))

    # ── File-kind dispatch (Track B G1) ─────────────────────────────────
    # The upstream forward_trace_lineage.py is ASM-only. For C++ / header
    # declarations we route through our cpp_forward_tracer (GVL BFS).
    ext = decl_path.suffix.lower()
    if ext in (".cpp", ".hpp", ".h"):
        return _run_forward_only_cpp(
            process=process,
            variable=variable,
            decl_path=decl_path,
            declaration_file=declaration_file,
            blueprint_path=blueprint_path,
            in_scope=in_scope,
            output_dir=output_dir,
            started=started,
            started_iso=started_iso,
            max_depth=8,
            max_nodes=300,
        )

    # ── Run tracer ───────────────────────────────────────────────────────
    tracer = ForwardLineageTracer(
        asm_dir=asm_dir,
        blueprint_dir=blueprint_dir,
        include_register_dependencies=include_register_dependencies,
    )
    raw = tracer.trace_forward(
        target_variable=variable,
        source_asm_file=decl_path,
        blueprint_file=blueprint_path,
    )

    nodes_raw = raw.lineage_chain or []
    dep_vars_raw = raw.dependent_vars or []
    dep_files_raw = raw.dependent_files or []
    tracer_warnings = list(raw.data_quality_warnings or [])

    # ── Filter to process scope ──────────────────────────────────────────
    # G12: node-count cap + G15: visited-set cap
    nodes_in_scope: List[Dict[str, Any]] = []
    role_counts: Dict[str, int] = {}
    _truncated_by_node_cap = False
    _visited_cap_hit = False
    _visited_lines: set = set()
    for n in nodes_raw:
        if not isinstance(n, dict):
            continue
        # G15: track visited (file, line) pairs; stop if cap hit.
        _v_key = (n.get("file") or "", n.get("line") or "")
        if len(_visited_lines) >= max_visited and _v_key not in _visited_lines:
            logger.warning(
                "G15: visited-set cap (%d) reached for %r — stopping BFS", max_visited, variable
            )
            _visited_cap_hit = True
            break
        _visited_lines.add(_v_key)
        f = _repo_relative(n.get("file"))
        if f and f not in in_scope:
            continue
        role = n.get("role") or "?"
        role_counts[role] = role_counts.get(role, 0) + 1
        nodes_in_scope.append({**n, "file": f})
        # G12: stop if we hit the node cap.
        if len(nodes_in_scope) >= effective_max_nodes:
            logger.warning(
                "G12: node cap (%d) reached for %r — truncating", effective_max_nodes, variable
            )
            _truncated_by_node_cap = True
            break

    dep_vars_in_scope: List[Dict[str, Any]] = []
    for d in dep_vars_raw:
        if not isinstance(d, dict):
            continue
        f = _repo_relative(d.get("file"))
        if f and f not in in_scope:
            continue
        dep_vars_in_scope.append({**d, "file": f})

    dep_files_in_scope: List[Dict[str, Any]] = []
    for df in dep_files_raw:
        if not isinstance(df, dict):
            continue
        # df['file'] holds the target file stem
        target = (df.get("file") or "").lower()
        called_from = _repo_relative(df.get("called_from") or df.get("called_from_file"))
        called_from_in = (not called_from) or (called_from in in_scope)
        target_in = any(target == Path(f).stem.lower() for f in in_scope)
        if called_from_in or target_in:
            dep_files_in_scope.append({
                **df,
                "called_from_file": called_from or df.get("called_from_file"),
                "target_in_scope": target_in,
            })

    # ── G6: subroutine-body expansion (default on; cap via max_subroutine_depth/nodes) ──
    subr_counters = expand_subroutines(
        nodes_in_scope,
        blueprint_dir=blueprint_dir,
        asm_dir=asm_dir,
        max_subroutine_depth=max_subroutine_depth,
        max_subroutine_nodes=max_subroutine_nodes,
    )
    # ── G13: instruction classification (every node gets `inst_class` list when applicable) ──
    classify_instructions(nodes_in_scope)
    # ── G14: OC self-zero + BZ pattern reclassification ──────────────────────────────────────
    reclassify_oc_bz_patterns(nodes_in_scope)
    # ── G7: enrich nodes with cross-file metadata + subroutine callee blocks ─────────────────
    _enrich_subroutine_call_targets(nodes_in_scope)
    _enrich_nodes_g7(nodes_in_scope)
    # Re-count roles after expansion so the manifest reflects the merged set.
    role_counts = {}
    for n in nodes_in_scope:
        r = n.get("role") or "?"
        role_counts[r] = role_counts.get(r, 0) + 1

    # ── G10: dep-var BFS expansion (off by default; opt-in via max_dep_var_depth>0) ──
    bfs_traces: List[Dict[str, Any]] = []
    bfs_max_depth_reached = 0
    if max_dep_var_depth > 0:
        bfs_traces, bfs_max_depth_reached = _bfs_dep_vars(
            tracer=tracer,
            initial_dep_vars=dep_vars_in_scope,
            in_scope=in_scope,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            max_depth=max_dep_var_depth,
            max_dep_vars=max_dep_vars,
        )

    # ── Rule-6 source validation ────────────────────────────────────────
    validation_warnings = validate_emission(nodes_in_scope)
    for bt in bfs_traces:
        validation_warnings.extend(bt.get("validation_warnings") or [])

    # ── Emit partitioned JSON ───────────────────────────────────────────
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "root_var.json").write_text(
        json.dumps(
            {
                "variable": variable,
                "declaration_file": declaration_file,
                "nodes": nodes_in_scope,
                "edges": _build_g7_edges(nodes_in_scope),
            },
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )

    dep_dir = output_dir / "dep_vars"
    dep_dir.mkdir(exist_ok=True)
    by_dep: Dict[str, List[Dict[str, Any]]] = {}
    for d in dep_vars_in_scope:
        name = d.get("variable") or "(unknown)"
        by_dep.setdefault(name, []).append(d)

    # G4: resolve ASM↔C++ aliases via VariableNameResolver (best-effort).
    dep_var_aliases = _resolve_dep_var_aliases(by_dep, declaration_file, blueprint_dir)
    if dep_var_aliases:
        logger.debug("G4: resolved %d dep_var aliases: %s", len(dep_var_aliases), dep_var_aliases)
    # Add alias names as synthetic dep_var entries so the forward trace can
    # follow the alias chain. Each alias entry carries alias_of= so consumers
    # know where it came from.
    for orig_name, alias_name in dep_var_aliases.items():
        if alias_name not in by_dep:
            by_dep[alias_name] = [
                {
                    "variable": alias_name,
                    "alias_of": orig_name,
                    "file": (by_dep[orig_name][0].get("file") or "") if by_dep[orig_name] else "",
                }
            ]

    for name, entries in by_dep.items():
        safe = _safe_filename(name)
        # Attach aliases list to the original name's JSON if any were resolved.
        alias_for_this = dep_var_aliases.get(name)
        extra: Dict[str, Any] = {}
        if alias_for_this:
            extra["aliases"] = [alias_for_this]
        # Check if this name is itself an alias of something else.
        alias_of = entries[0].get("alias_of") if entries else None
        if alias_of:
            extra["alias_of"] = alias_of
        (dep_dir / f"{safe}.json").write_text(
            json.dumps({"variable": name, "entries": entries, **extra}, indent=2, default=str),
            encoding="utf-8",
        )

    dep_files_dir = output_dir / "dep_files"
    dep_files_dir.mkdir(exist_ok=True)
    (dep_files_dir / "cross_calls.json").write_text(
        json.dumps(dep_files_in_scope, indent=2, default=str), encoding="utf-8"
    )

    # Persist BFS traces (G10). One file per dep_var so the SSE iterator
    # (Phase 7) can stream them one-by-one.
    bfs_dir = output_dir / "dep_var_traces"
    if bfs_traces:
        bfs_dir.mkdir(exist_ok=True)
        for trace in bfs_traces:
            safe = _safe_filename(trace["variable"])
            (bfs_dir / f"{safe}.json").write_text(
                json.dumps(trace, indent=2, default=str), encoding="utf-8"
            )

    (output_dir / "warnings.json").write_text(
        json.dumps(
            {
                "tracer": tracer_warnings,
                "validation": validation_warnings,
            },
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )

    # ── Manifest ─────────────────────────────────────────────────────────
    setter_like = sum(role_counts.get(r, 0) for r in ("SETTER", "SIDE_EFFECT_SETTER"))
    finished_iso = _utc_now_iso()
    manifest = ForwardManifest(
        process=process,
        variable=variable,
        declaration_file=declaration_file,
        files_in_scope=sorted(in_scope),
        node_count_raw=len(nodes_raw),
        node_count_in_scope=len(nodes_in_scope),
        role_counts=role_counts,
        setter_like_count=setter_like,
        overwrite_count=role_counts.get("OVERWRITE", 0),
        cross_file_call_count=role_counts.get("CROSS_FILE_CALL", 0),
        dep_var_count=len(dep_vars_raw),
        dep_var_count_in_scope=len(by_dep),
        dep_var_bfs_traced=len(bfs_traces),
        dep_var_bfs_max_depth=bfs_max_depth_reached,
        subroutine_call_sites_expanded=subr_counters["call_sites_expanded"],
        subroutine_body_nodes_added=subr_counters["body_nodes_added"],
        subroutine_expansion_cap_hit=subr_counters["cap_hit"],
        truncated=_truncated_by_node_cap or _visited_cap_hit,
        truncated_at_nodes=len(nodes_in_scope) if _truncated_by_node_cap else 0,
        visited_cap_hit=_visited_cap_hit,
        content_hash=content_hash,
        validation_warnings=len(validation_warnings),
        tracer_warnings=len(tracer_warnings),
        started_at=started_iso,
        finished_at=finished_iso,
        elapsed_sec=round(time.monotonic() - started, 2),
        output_dir=str(output_dir),
    )
    (output_dir / "manifest.json").write_text(
        json.dumps(asdict(manifest), indent=2), encoding="utf-8"
    )
    # G3: also write content_hash into root_var.json so the cache check has
    # a single authoritative location to verify.
    _patch_root_var_with_hash(output_dir, content_hash)
    logger.info("forward_only complete: %s", manifest)
    return manifest


# ---------------------------------------------------------------------------
# G3 — content-hash cache helpers
# ---------------------------------------------------------------------------

def _load_cached_manifest(output_dir: Path, expected_hash: str) -> Optional[ForwardManifest]:
    """Try to reconstruct a ForwardManifest from a cached root_var.json.

    Returns ``None`` if:
      - ``root_var.json`` does not exist
      - its ``content_hash`` field is absent or does not match ``expected_hash``
      - ``manifest.json`` is absent or unreadable

    Never raises — any exception is swallowed and ``None`` is returned.
    """
    root_var_path = output_dir / "root_var.json"
    manifest_path = output_dir / "manifest.json"
    if not root_var_path.is_file() or not manifest_path.is_file():
        return None
    try:
        rv = json.loads(root_var_path.read_text(encoding="utf-8"))
        if rv.get("content_hash") != expected_hash:
            return None
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
        return ForwardManifest(**{k: v for k, v in data.items() if k in ForwardManifest.__dataclass_fields__})
    except Exception as exc:  # noqa: BLE001
        logger.debug("G3: cache read failed (%s) — will re-run", exc)
        return None


def _patch_root_var_with_hash(output_dir: Path, content_hash: str) -> None:
    """Inject the ``content_hash`` field into the already-written root_var.json."""
    root_var_path = output_dir / "root_var.json"
    if not root_var_path.is_file():
        return
    try:
        data = json.loads(root_var_path.read_text(encoding="utf-8"))
        data["content_hash"] = content_hash
        root_var_path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
    except Exception as exc:  # noqa: BLE001
        logger.warning("G3: could not patch root_var.json with content_hash: %s", exc)


# ---------------------------------------------------------------------------
# G7 — enrich nodes + build cross-file call-flow edges
# ---------------------------------------------------------------------------

def _enrich_nodes_g7(nodes: List[Dict[str, Any]]) -> None:
    """Add G7 fields to every node in-place.

    New fields (all optional — ``None`` when unavailable):
      * ``to_file``        — for CROSS_FILE_CALL nodes: callee repo-relative file
      * ``callee_block``   — for CROSS_FILE_CALL nodes: entry block in callee file
      * ``parent_block``   — block of the immediately preceding node (BFS parent)
      * ``depth``          — already present from tracer; defaulted to None here
      * ``inst_class``     — already set by classify_instructions; kept as-is
      * ``expansion_depth``— already set by expand_subroutines; defaulted to None
    """
    for i, n in enumerate(nodes):
        # Defaults for new fields (non-destructive — don't clobber existing values)
        n.setdefault("to_file", None)
        n.setdefault("callee_block", None)
        n.setdefault("depth", None)
        n.setdefault("parent_block", None)
        n.setdefault("inst_class", None)
        n.setdefault("expansion_depth", None)

        # parent_block: block of the preceding node (BFS traversal parent)
        if i > 0:
            prev = nodes[i - 1]
            n["parent_block"] = prev.get("block") or None

        # to_file / callee_block: infer from the next in-scope node when it
        # belongs to a different file (tracer convention for CROSS_FILE_CALL).
        if n.get("role") == "CROSS_FILE_CALL":
            src_file = n.get("file") or ""
            for j in range(i + 1, len(nodes)):
                nxt = nodes[j]
                nxt_file = nxt.get("file") or ""
                if nxt_file and nxt_file != src_file:
                    n["to_file"] = nxt_file
                    n["callee_block"] = nxt.get("block") or None
                    break
                # Stop if we hit another CROSS_FILE_CALL before finding one
                if nxt.get("role") == "CROSS_FILE_CALL" and nxt_file == src_file:
                    break


def _enrich_subroutine_call_targets(nodes: List[Dict[str, Any]]) -> None:
    """Populate ``callee_block`` for SUBROUTINE_CALL nodes from adjacent
    SUBROUTINE_BODY nodes (which carry ``expansion_parent_block``)."""
    body_target: Dict[str, str] = {}
    for n in nodes:
        if n.get("role") == "SUBROUTINE_BODY":
            pb = n.get("expansion_parent_block")
            cb = n.get("block")
            if pb and cb and pb not in body_target:
                body_target[pb] = cb

    for n in nodes:
        if n.get("role") == "SUBROUTINE_CALL" and n.get("callee_block") is None:
            block = n.get("block") or ""
            if block in body_target:
                n["callee_block"] = body_target[block]


def _build_g7_edges(nodes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Build the G7 ``edges`` list for ``root_var.json``.

    Each entry represents a cross-file or subroutine call hop with a
    resolved callee. Schema::

        {
            "source_block": str,
            "source_file": str,
            "target_block": str,
            "target_file": str,
            "edge_type": str,
        }

    Only nodes with ``role`` in {``CROSS_FILE_CALL``, ``SUBROUTINE_CALL``}
    that have a resolved callee (non-None ``to_file``/``callee_block``) are
    emitted.
    """
    edges: List[Dict[str, Any]] = []
    seen: set = set()

    for n in nodes:
        role = n.get("role") or ""
        if role not in ("CROSS_FILE_CALL", "SUBROUTINE_CALL"):
            continue

        src_file = n.get("file") or ""
        src_block = n.get("block") or ""
        to_file = n.get("to_file")
        callee_block = n.get("callee_block")

        if not (src_file and src_block and to_file and callee_block):
            continue

        key = (src_file, src_block, to_file, callee_block, role)
        if key not in seen:
            seen.add(key)
            edges.append({
                "source_block": src_block,
                "source_file": src_file,
                "target_block": callee_block,
                "target_file": to_file,
                "edge_type": role,
            })

    return edges


# ---------------------------------------------------------------------------
# C++ branch (Track B G1)
# ---------------------------------------------------------------------------

def _run_forward_only_cpp(
    *,
    process: str,
    variable: str,
    decl_path: Path,
    declaration_file: str,
    blueprint_path: Path,
    in_scope: set,
    output_dir: Path,
    started: float,
    started_iso: str,
    max_depth: int,
    max_nodes: int,
) -> ForwardManifest:
    """C++ forward trace via GVL BFS. Emits the same partitioned output
    contract as the ASM branch but with C++-specific fields populated."""
    # Blueprints are zstd+msgpack (or legacy JSON) — use the shared decoder
    # rather than a strict utf-8 JSON read (which raises on the zstd magic).
    from process_analysis.backend.pipeline.enumerate import _read_json_bytes
    bp = _read_json_bytes(blueprint_path.read_bytes())
    result = trace_cpp_variable_forward_from_blueprint(
        bp, variable, max_depth=max_depth, max_nodes=max_nodes
    )

    # In-scope filtering: keep only nodes/edges where the recorded file (if
    # any in metadata) is in the process scope. GVL nodes often lack file
    # metadata (they're identity-keyed); for those we keep the node since the
    # variable identity is process-scoped anyway.
    def _file_of(item: Dict[str, Any]) -> str:
        f = item.get("file") or (item.get("metadata") or {}).get("file") or ""
        return _repo_relative(f)

    nodes_in_scope = [
        n for n in result.get("nodes") or []
        if not _file_of(n) or _file_of(n) in in_scope or not _file_of(n)
    ]
    edges_in_scope = [
        e for e in result.get("edges") or []
        if not _file_of(e) or _file_of(e) in in_scope
    ]

    role_counts: Dict[str, int] = {"GVL_NODE": len(nodes_in_scope)}
    for n in nodes_in_scope:
        kind = (n.get("kind") or "?").upper()
        role_counts[f"GVL_{kind}"] = role_counts.get(f"GVL_{kind}", 0) + 1

    # ── Emit partitioned output ─────────────────────────────────────────
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "root_var.json").write_text(
        json.dumps(
            {
                "variable": variable,
                "declaration_file": declaration_file,
                "kind": "cpp_gvl",
                "seeds": result.get("seeds") or [],
                "nodes": nodes_in_scope,
                "edges": edges_in_scope,
                "bridge_registers": result.get("bridge_registers") or [],
                "asm_field_aliases": result.get("asm_field_aliases") or {},
            },
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )

    (output_dir / "warnings.json").write_text(
        json.dumps(
            {
                "tracer": result.get("warnings") or [],
                "validation": [],
            },
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )

    finished_iso = _utc_now_iso()
    manifest = ForwardManifest(
        process=process,
        variable=variable,
        declaration_file=declaration_file,
        files_in_scope=sorted(in_scope),
        node_count_raw=len(result.get("nodes") or []),
        node_count_in_scope=len(nodes_in_scope),
        role_counts=role_counts,
        setter_like_count=0,                  # C++ GVL doesn't use ASM setter semantics
        overwrite_count=0,
        cross_file_call_count=len(result.get("bridge_registers") or []),
        dep_var_count=0,
        dep_var_count_in_scope=0,
        truncated=bool(result.get("truncated")),
        validation_warnings=0,
        tracer_warnings=len(result.get("warnings") or []),
        started_at=started_iso,
        finished_at=finished_iso,
        elapsed_sec=round(time.monotonic() - started, 2),
        output_dir=str(output_dir),
    )
    (output_dir / "manifest.json").write_text(
        json.dumps(asdict(manifest), indent=2), encoding="utf-8"
    )
    logger.info("forward_only (C++ GVL) complete: %s", manifest)
    return manifest


def _safe_filename(name: str) -> str:
    return "".join(c if c.isalnum() or c in "._-" else "_" for c in name)[:200]


def _utc_now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


# ---------------------------------------------------------------------------
# G10 — dep-var BFS (mirrors backward_traversal Pass 2 semantics)
# ---------------------------------------------------------------------------

# Tokens we never expand: registers, comma-suffixed literals, helper markers.
_BFS_SKIP = {
    "R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7",
    "R8", "R9", "R10", "R11", "R12", "R13", "R14", "R15",
    "@", "LEVEL:", "MEMORY:", "ALLOC@", "RETURN@", "(unknown)", "",
}


def _bfs_dep_vars(
    tracer,
    *,
    initial_dep_vars: List[Dict[str, Any]],
    in_scope: set,
    blueprint_dir: Path,
    asm_dir: Path,
    max_depth: int,
    max_dep_vars: int,
) -> Tuple[List[Dict[str, Any]], int]:
    """BFS forward over dep_vars, returning one trace dict per expanded dep_var.

    Capping policy matches backward (memory entry ``project_backward_traversal``):
      * max_dep_vars (total) — at most N dep_vars get a forward trace
      * max_depth — depth>0 means dep_vars-of-dep_vars are enqueued at depth+1
    """
    from collections import deque

    visited: set = set()
    queue: deque = deque()
    out: List[Dict[str, Any]] = []
    max_reached = 0

    def _enqueue(name: str, depth: int, file_hint: Optional[str]) -> None:
        norm = (name or "").strip().upper()
        if not norm or norm in _BFS_SKIP or norm in visited:
            return
        visited.add(norm)
        queue.append((norm, depth, file_hint))

    # Seed the queue from initial dep_vars (depth 1 — parents are at depth 0).
    for d in initial_dep_vars:
        _enqueue(d.get("variable") or "", depth=1, file_hint=d.get("file"))

    while queue and len(out) < max_dep_vars:
        name, depth, file_hint = queue.popleft()
        max_reached = max(max_reached, depth)
        if depth > max_depth:
            continue

        # Find the declaration file for this dep_var. Prefer the file the
        # parent trace anchored it to; else fall back to a heuristic (the
        # root variable's declaration file usually contains side-effect targets).
        decl_file = file_hint if (file_hint and file_hint in in_scope) else None
        if not decl_file:
            # Try the variable inventory next (Phase 4 SQLite). Re-using a
            # short query here is cheaper than rescanning blueprints.
            decl_file = _lookup_declaration_file_anywhere(name) or ""
        if not decl_file or decl_file not in in_scope:
            out.append({
                "variable": name, "depth": depth,
                "status": "skipped_no_declaration_in_scope",
                "node_count": 0, "child_dep_vars": [],
                "validation_warnings": [],
            })
            continue

        abs_file = settings.REPO_ROOT / decl_file
        bp_path = blueprint_dir / f"{abs_file.name}.json"
        if not abs_file.is_file() or not bp_path.is_file():
            out.append({
                "variable": name, "depth": depth,
                "status": "skipped_missing_source",
                "node_count": 0, "child_dep_vars": [],
                "validation_warnings": [],
            })
            continue

        try:
            sub_results = tracer.trace_forward(name, abs_file, bp_path)
        except Exception as exc:  # noqa: BLE001
            out.append({
                "variable": name, "depth": depth,
                "status": f"error: {type(exc).__name__}: {exc}",
                "node_count": 0, "child_dep_vars": [],
                "validation_warnings": [],
            })
            continue

        sub_nodes_in_scope: List[Dict[str, Any]] = []
        sub_role_counts: Dict[str, int] = {}
        sub_child_deps: List[Dict[str, Any]] = []
        for n in (sub_results.lineage_chain or []):
            if not isinstance(n, dict):
                continue
            f = _repo_relative(n.get("file"))
            if f and f not in in_scope:
                continue
            sub_nodes_in_scope.append({**n, "file": f})
            r = n.get("role") or "?"
            sub_role_counts[r] = sub_role_counts.get(r, 0) + 1
        for d in (sub_results.dependent_vars or []):
            if not isinstance(d, dict):
                continue
            f = _repo_relative(d.get("file"))
            if f and f not in in_scope:
                continue
            sub_child_deps.append({**d, "file": f})
            # Enqueue grandchildren if there's still room.
            if depth + 1 <= max_depth and len(out) + len(queue) < max_dep_vars:
                _enqueue(d.get("variable") or "", depth=depth + 1, file_hint=f)

        warnings = validate_emission(sub_nodes_in_scope)
        out.append({
            "variable": name,
            "depth": depth,
            "status": "ok",
            "node_count": len(sub_nodes_in_scope),
            "role_counts": sub_role_counts,
            "child_dep_vars": sub_child_deps[:50],
            "child_dep_var_count": len(sub_child_deps),
            "validation_warnings": warnings,
        })

    return out, max_reached


_PARSER_UNIVERSE_CACHE: Optional[Dict[str, str]] = None


def _parser_universe_index() -> Dict[str, str]:
    """name (upper) → repo-relative declaration_file (first occurrence).

    Reads ``temp/output_latest/asm_variable_universe.json`` once and caches.
    Includes EQU labels and DC/DS storage definitions — strictly broader than
    our Phase 4 filtered inventory, which is what the BFS needs (dep_vars are
    often EQU subroutine labels and other code-anchored names).
    """
    global _PARSER_UNIVERSE_CACHE
    if _PARSER_UNIVERSE_CACHE is not None:
        return _PARSER_UNIVERSE_CACHE
    out: Dict[str, str] = {}
    uni_path = settings.TEMP_OUTPUT_DIR / "asm_variable_universe.json"
    if uni_path.is_file():
        try:
            uni = json.loads(uni_path.read_text(encoding="utf-8"))
            vars_field = uni.get("variables") or {}
            if isinstance(vars_field, dict):
                for name, occurrences in vars_field.items():
                    norm = (name or "").strip().upper()
                    if not norm or norm in out:
                        continue
                    if not isinstance(occurrences, list):
                        continue
                    for entry in occurrences:
                        if not isinstance(entry, dict):
                            continue
                        fp = entry.get("file") or ""
                        rel = _repo_relative(fp)
                        if rel:
                            out[norm] = rel
                            break
        except (OSError, json.JSONDecodeError):
            pass
    _PARSER_UNIVERSE_CACHE = out
    return out


def _lookup_declaration_file_anywhere(variable: str) -> Optional[str]:
    """Find ANY declaration file for a variable. Two-tier fallback:

      1. Phase 4 filtered inventory (kind == 'memory') — best for real data vars.
      2. Raw parser universe (DS/DC/EQU) — broader; needed for the G10 BFS
         because dep_vars are often EQU-anchored subroutine labels.
    """
    norm = (variable or "").strip()
    with get_conn() as conn:
        row = conn.execute(
            "SELECT declaration_file FROM variable WHERE name = ? "
            "ORDER BY declaration_file LIMIT 1",
            (norm,),
        ).fetchone()
    if row:
        return row["declaration_file"]
    return _parser_universe_index().get(norm.upper())
