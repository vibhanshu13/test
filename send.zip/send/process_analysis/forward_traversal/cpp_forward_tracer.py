"""G1 — C++ GVL forward tracer.

Mirror of ``backward_traversal.tracing.cpp_backward_tracer`` but the BFS
follows **outgoing** edges (source → target) instead of incoming. The
relation-weight cost model is identical (DEPTH_WEIGHTS); the BFS frontier
expansion logic is symmetric in direction.

Seed discovery, name resolution, and register-bridge marker extraction are
**read-only-imported** from backward (Rule 5 / Q-P6d Track B): they're
direction-agnostic data-mapping utilities. Only the BFS algorithm needed a
parallel implementation here.
"""

from __future__ import annotations

import logging
import os
import re
from collections import defaultdict, deque
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from backward_traversal.utils.cpp_lineage_utils import (  # noqa: E402
    extract_asm_field_aliases,
    extract_tpf_regs_slots,
    find_cpp_seed_nodes,
)

logger = logging.getLogger("process_analysis.forward_traversal.cpp_forward_tracer")


# ---------------------------------------------------------------------------
# Configuration (mirrors backward defaults)
# ---------------------------------------------------------------------------

DEFAULT_MAX_DEPTH = 6
DEFAULT_MAX_NODES = 300
DEFAULT_MAX_ALIAS_HOPS = 20

# Per-relation depth cost (audit-verified 2026-05-27 vs backward).
DEPTH_WEIGHTS: Dict[str, int] = {
    "assign": 1,
    "define": 1,
    "arg_bind": 1,
    "ecb_bridge": 2,
    "ce1cr_level_bridge": 2,
    "alias": 0,
    "use": 1,             # forward-specific: 'use' is a normal data step forward
    # default for any other relation: 1
}

# Node kinds that terminate the forward walk. In forward direction, the
# variable's data has "arrived" at a use/memory/literal sink so we don't
# expand further.
TERMINAL_KINDS: Set[str] = {"literal", "memory", "clobbered"}

# Configurable GVL size cap (in bytes) to skip BFS on very large blueprints.
_GVL_BFS_MAX_BYTES = int(os.environ.get("ASM_GVL_BFS_MAX_MB", "1024")) * 1024 * 1024


# ---------------------------------------------------------------------------
# Index building
# ---------------------------------------------------------------------------

def _build_forward_index(gvl: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    """source-id → list of outgoing edges."""
    idx: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for e in gvl.get("edges") or []:
        if isinstance(e, dict) and e.get("source"):
            idx[str(e["source"])].append(e)
    return idx


def _build_node_lookup(gvl: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for n in gvl.get("nodes") or []:
        if isinstance(n, dict) and n.get("id"):
            out[str(n["id"])] = n
    return out


# ---------------------------------------------------------------------------
# Register bridge — mirrors backward's _extract_bridge_reg
# ---------------------------------------------------------------------------

_REG_RE = re.compile(r"\bR(?:1[0-5]|[0-9])\b")


def _extract_bridge_reg(node: Dict[str, Any]) -> Optional[str]:
    for field in ("name", "id"):
        v = node.get(field) or ""
        m = _REG_RE.search(str(v))
        if m:
            return m.group(0)
    return None


# ---------------------------------------------------------------------------
# Core BFS — single seed
# ---------------------------------------------------------------------------

def trace_cpp_variable_forward(
    seed_id: str,
    gvl: Dict[str, Any],
    *,
    max_depth: int = DEFAULT_MAX_DEPTH,
    max_nodes: int = DEFAULT_MAX_NODES,
    _forward_idx: Optional[Dict[str, List[Dict[str, Any]]]] = None,
    _node_lookup: Optional[Dict[str, Dict[str, Any]]] = None,
    _seed_ids: Optional[Set[str]] = None,
) -> Dict[str, Any]:
    """Forward BFS from one seed node ID.

    Returns ``{seed, nodes, edges, bridge_registers, truncated, warnings}``.
    """
    if _forward_idx is None:
        _forward_idx = _build_forward_index(gvl)
    if _node_lookup is None:
        _node_lookup = _build_node_lookup(gvl)
    if _seed_ids is None:
        _seed_ids = {seed_id}

    visited_nodes: Set[str] = set()
    out_nodes: Dict[str, Dict[str, Any]] = {}
    out_edges: List[Dict[str, Any]] = []
    seen_edge_keys: Set[Tuple[str, str, str]] = set()
    bridge_regs: List[Dict[str, Any]] = []
    truncated = False

    queue: deque = deque()
    queue.append((seed_id, 0))

    while queue and len(out_nodes) < max_nodes:
        node_id, depth = queue.popleft()
        if node_id in visited_nodes:
            continue
        visited_nodes.add(node_id)

        node = _node_lookup.get(node_id)
        if node is None:
            # Edge refers to a node id not in the lookup — record a synthetic stub
            out_nodes[node_id] = {"id": node_id, "kind": "(unknown)", "name": node_id}
            continue
        out_nodes[node_id] = node

        # Register-bridge detection (forward semantics: the variable's data
        # is flowing OUT to a register, which is the ASM boundary).
        reg = _extract_bridge_reg(node)
        if reg:
            bridge_regs.append({
                "node_id": node_id,
                "register": reg,
                "direction": "forward_to_asm",
            })

        kind = (node.get("kind") or "").lower()
        if kind in TERMINAL_KINDS:
            continue
        if depth >= max_depth:
            continue

        for edge in _forward_idx.get(node_id, []):
            tgt = edge.get("target")
            relation = (edge.get("relation") or "").lower()
            if not tgt:
                continue
            ekey = (str(node_id), str(tgt), relation)
            if ekey not in seen_edge_keys:
                seen_edge_keys.add(ekey)
                out_edges.append(edge)
            weight = DEPTH_WEIGHTS.get(relation, 1)
            new_depth = depth + weight
            if new_depth > max_depth:
                continue
            queue.append((tgt, new_depth))

    if len(out_nodes) >= max_nodes and queue:
        truncated = True

    return {
        "seed": seed_id,
        "nodes": list(out_nodes.values()),
        "edges": out_edges,
        "bridge_registers": bridge_regs,
        "truncated": truncated,
        "warnings": [],
    }


# ---------------------------------------------------------------------------
# Multi-seed entry — mirrors trace_cpp_variable_backward_multi
# ---------------------------------------------------------------------------

def trace_cpp_variable_forward_multi(
    seed_ids: List[str],
    gvl: Dict[str, Any],
    *,
    max_depth: int = DEFAULT_MAX_DEPTH,
    max_nodes: int = DEFAULT_MAX_NODES,
) -> Dict[str, Any]:
    """Forward BFS from multiple seeds. Shares forward index + node lookup
    + node budget across seeds (mirrors backward FIX-4 / FIX-7)."""
    if not seed_ids or not gvl:
        return {
            "seeds": seed_ids or [], "nodes": [], "edges": [],
            "bridge_registers": [], "per_seed_traces": {},
            "truncated": False, "warnings": [],
        }

    gvl_size = gvl.get("file_size_bytes", 0) if isinstance(gvl, dict) else 0
    if gvl_size and gvl_size > _GVL_BFS_MAX_BYTES:
        return {
            "seeds": seed_ids, "nodes": [], "edges": [],
            "bridge_registers": [], "per_seed_traces": {},
            "truncated": True,
            "warnings": [
                f"GVL exceeds {_GVL_BFS_MAX_BYTES // (1024 * 1024)} MB BFS limit; skipped."
            ],
        }

    forward_idx = _build_forward_index(gvl)
    node_lookup = _build_node_lookup(gvl)

    merged_nodes: Dict[str, Dict[str, Any]] = {}
    merged_edges: List[Dict[str, Any]] = []
    seen_edge_keys: Set[Tuple[str, str, str]] = set()
    all_bridge_regs: List[Dict[str, Any]] = []
    seen_bridge_keys: Set[Tuple[str, str]] = set()
    per_seed: Dict[str, Dict[str, Any]] = {}
    truncated_any = False
    warnings: List[str] = []

    remaining = max_nodes
    seed_set = set(seed_ids)

    for seed in seed_ids:
        if remaining <= 0:
            warnings.append(
                f"multi-seed: global max_nodes={max_nodes} budget exhausted at seed {seed}"
            )
            break
        already = len(merged_nodes)
        per_seed_cap = max(1, remaining + already - already)   # full budget reach
        trace = trace_cpp_variable_forward(
            seed_id=seed,
            gvl=gvl,
            max_depth=max_depth,
            max_nodes=per_seed_cap,
            _forward_idx=forward_idx,
            _node_lookup=node_lookup,
            _seed_ids=seed_set,
        )
        per_seed[seed] = {
            "node_count": len(trace["nodes"]),
            "edge_count": len(trace["edges"]),
            "truncated": trace["truncated"],
        }
        if trace["truncated"]:
            truncated_any = True

        for n in trace["nodes"]:
            nid = n.get("id")
            if nid and nid not in merged_nodes:
                merged_nodes[nid] = n
        for e in trace["edges"]:
            key = (str(e.get("source")), str(e.get("target")), str(e.get("relation")))
            if key not in seen_edge_keys:
                seen_edge_keys.add(key)
                merged_edges.append(e)
        for br in trace["bridge_registers"]:
            k = (br["node_id"], br["register"])
            if k not in seen_bridge_keys:
                seen_bridge_keys.add(k)
                all_bridge_regs.append(br)

        remaining = max_nodes - len(merged_nodes)

    return {
        "seeds": seed_ids,
        "nodes": list(merged_nodes.values()),
        "edges": merged_edges,
        "bridge_registers": all_bridge_regs,
        "per_seed_traces": per_seed,
        "truncated": truncated_any,
        "warnings": warnings,
    }


# ---------------------------------------------------------------------------
# Public convenience: find seeds + run forward
# ---------------------------------------------------------------------------

def trace_cpp_variable_forward_from_blueprint(
    cpp_blueprint: Dict[str, Any],
    variable: str,
    *,
    max_depth: int = DEFAULT_MAX_DEPTH,
    max_nodes: int = DEFAULT_MAX_NODES,
    transitive_vars: Iterable[str] = (),
) -> Dict[str, Any]:
    """End-to-end: find seeds for ``variable`` in this C++ blueprint, then
    run a forward GVL BFS. Returns the multi-seed trace dict.

    Both seed discovery and BFS are run; if no seeds found, returns an empty
    trace with a warning.
    """
    gvl = cpp_blueprint.get("global_variable_lineage") or {}
    if not gvl or not gvl.get("nodes"):
        return {
            "seeds": [], "nodes": [], "edges": [],
            "bridge_registers": [], "per_seed_traces": {},
            "truncated": False,
            "warnings": ["C++ blueprint has no global_variable_lineage."],
        }
    asm_aliases = extract_asm_field_aliases(cpp_blueprint, variable, transitive_vars)
    # callee param unused for find_cpp_seed_nodes' inner TPF_regs slot lookup;
    # backward's signature requires a dict-shaped value, so we pass an empty.
    tpf_regs: Dict[str, Dict[str, Any]] = {}
    seeds = find_cpp_seed_nodes(gvl, variable, asm_aliases, tpf_regs)
    if not seeds:
        return {
            "seeds": [], "nodes": [], "edges": [],
            "bridge_registers": [], "per_seed_traces": {},
            "truncated": False,
            "warnings": [f"No GVL seeds found for variable {variable!r}"],
        }
    result = trace_cpp_variable_forward_multi(
        seeds, gvl, max_depth=max_depth, max_nodes=max_nodes
    )
    result["asm_field_aliases"] = asm_aliases
    return result
