"""Forward variable-usage lineage for process_analysis (Phase 6).

This package WRAPS the existing repo-root ``forward_trace_lineage.py``
(Strategy B, approved Q-P6a 2026-05-27). It does NOT duplicate the
tracer's logic — it adds:

  * a clean ``run_forward_only(process, variable, ...)`` API;
  * **process-scope filtering** (clip results to the process's
    ``file_graph.json`` files);
  * **Rule-6 source validation** (every emitted ``(file, line)`` must
    exist in source and be non-blank);
  * **partitioned output** matching backward_traversal's shape
    (Q6 / Q-P6b approved).

Per PROJECT_RULES Rule 5, we never modify ``forward_trace_lineage.py``.
If it grows new fields, this wrapper picks them up; if shapes drift, the
``validate.py`` gate catches regressions.
"""
