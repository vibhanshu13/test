"""Rule-6 source-validation gate for forward_traversal output.

Every node the wrapper emits to JSON must point at a real (file, line) that
exists in source and is non-blank. The gate is non-fatal — failures are
recorded as warning dicts in the returned list, so the runner can include
them in ``warnings.json`` and the manifest's ``validation_warnings`` counter.

Sample warnings:
- "line_out_of_range"  — line < 1 or > EOF
- "blank_line"         — line in range but stripped to empty
- "comment_line"       — line starts with '*' (HLASM full-line comment)
- "source_missing"     — file path doesn't exist
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, List

from process_analysis.backend.config import settings


@lru_cache(maxsize=64)
def _read_lines(repo_rel: str) -> tuple:
    p = settings.REPO_ROOT / repo_rel
    if not p.is_file():
        return ()
    try:
        return tuple(p.read_text(encoding="utf-8", errors="replace").splitlines())
    except OSError:
        return ()


def validate_emission(nodes: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Return a list of validation-warning dicts (empty if everything checks out)."""
    out: List[Dict[str, Any]] = []
    for n in nodes:
        f = (n.get("file") or "").strip()
        line = n.get("line")
        if not f or not isinstance(line, int) or line <= 0:
            continue   # tracer sometimes emits sentinel rows (line=0 GLOBAL); skip
        src = _read_lines(f)
        if not src:
            out.append({
                "reason": "source_missing",
                "file": f, "line": line,
                "block": n.get("block"), "role": n.get("role"),
            })
            continue
        if line > len(src):
            out.append({
                "reason": "line_out_of_range",
                "file": f, "line": line, "src_lines": len(src),
                "block": n.get("block"), "role": n.get("role"),
            })
            continue
        text = src[line - 1]
        stripped = text.strip()
        if not stripped:
            out.append({
                "reason": "blank_line", "file": f, "line": line,
                "block": n.get("block"), "role": n.get("role"),
            })
        elif stripped.startswith("*"):
            out.append({
                "reason": "comment_line", "file": f, "line": line,
                "block": n.get("block"), "role": n.get("role"),
                "got": text[:80],
            })
    return out
