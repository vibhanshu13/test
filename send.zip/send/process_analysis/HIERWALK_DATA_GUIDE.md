# Hierarchical Walkthrough — Quick Setup

The walkthrough reads a process's parser output + source and generates
business explanations with an LLM (cached in `knowledge.db`).

---

## What it needs (inputs)

For a process `<p>` (e.g. `plastic_authentication`), three things must be on disk:

1. **Process definition** → `data/processes/<p>/file_graph.json`
   (the seed entry point + the list of files in scope + cross-file edges).
2. **Source files** → read from **whatever path each file uses in
   `file_graph.json`** (resolved relative to the repo root).
3. **Parser files (blueprints)** → `temp/output_latest/asm/<name>.json`
   (one per file listed in `file_graph.json`).

---

## Prerequisites

- **`GEMINI_API_KEY` in `.env`** (repo root) — the walkthrough makes LLM calls:
  ```
  GEMINI_API_KEY=<your key>
  LLM_MODEL_NAME=gemini-2.5-pro
  ```

---

## Steps

1. **Start the analysis backend** (port 8010):
   ```
   env/bin/uvicorn process_analysis.backend.app:app --port 8010 --host 127.0.0.1
   ```
2. **Build the walkthrough** (deterministic tree + one LLM call for the top level):
   ```
   curl -X POST "http://localhost:8010/demo/v1/projects/default/processes/<p>/hierwalk/build?eager=true"
   ```
3. **View it:** `http://localhost:3000/hw-preview/<p>`
   (the preview page auto-calls build on first open, so step 2 is optional).

> Cached in `knowledge.db`. Re-running build rebuilds the top level; deeper
> steps generate on first open (~20–30s each) and are instant afterwards.

### Pre-generate ALL cards (batch — async, Celery + poll)

Generates every card up front so each later click is a pure cache read. It runs
as a **background Celery task** (queue `q_llm`) and follows the 202 + poll
contract (same as the main pipeline build).

**1. Kick it off** — returns immediately with a `task_id`:

```
curl -X POST "http://localhost:8010/demo/v1/projects/default/processes/<p>/hierwalk/batch?workers=8"
# → 202 {"process":"<p>","task_id":"<id>","started":true,"mode":"celery"}
```

**2. Poll** until `status` is `done` (or `failed`):

```
curl "http://localhost:8010/demo/v1/projects/default/processes/<p>/hierwalk/batch/status/<task_id>"
# → {"status":"running","progress":{"level":"2","generated":"5","skipped":"0","total":"12","failed":"0"}, …}
# → {"status":"done","all_generated":true,"result":{"status":"completed","total_nodes":67,"generated":67,"skipped_cached":0,"failed":[]}}
```

- **Resumable / checkpointed.** If a run fails or is interrupted, dispatch again —
  it resumes from where it stopped (checkpoint = each node's `decomposed` flag)
  and only generates the missing cards. Failed nodes are in `result.failed[]`.
- **Idempotent.** When everything is already generated the result is
  `status:"already_complete"`, `all_generated:true`, `generated:0` — **no LLM
  calls**. No need to hit it again.
- **`?restart=true`** wipes the substrate + all cards and regenerates from scratch.
- **Fallback.** If Celery/Redis are unavailable, the same call transparently runs
  in a background thread (`mode:"threading"`); the status endpoint reads from an
  in-memory registry instead of Redis. Same `task_id` poll contract.

**Running the worker** (LLM tasks import the top-level `llm` package, so the repo
root must be on `PYTHONPATH`):

```
PYTHONPATH=$(pwd) celery -A process_analysis.backend.celery_app worker -Q q_llm -c 4 --loglevel=info
```
Requires Redis running (`redis://localhost:6379`).

### Project-free / global cache

The walkthrough is keyed only by `(process, node_id)` — there is **no project /
job dimension**. A process name always maps to the same code, so the cache is
global. The `{project_id}` URL segment is kept for frontend compatibility but is
ignored (any value returns the same cached cards). Inputs always resolve from the
demo locations (`data/processes/<p>/` + `temp/output_latest/asm/`).

---

## The LLM call

- **Where:** `process_analysis/backend/hierwalk/subprocess.py` → `decompose()`
  calls **`call_llm_model(prompt, Decomposition)`** (one call per node).
- **Gateway:** `call_llm_model` (`process_analysis/backend/llm.py`) →
  `llm.caller.call_llm` (single Gemini entry point) → **`gemini-2.5-pro`**
  (`settings.LLM_MODEL_NAME`).
- **`.env` required:** `GEMINI_API_KEY` (mandatory), `LLM_MODEL_NAME`
  (defaults to `gemini-2.5-pro`).
