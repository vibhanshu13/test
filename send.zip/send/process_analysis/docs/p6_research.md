# Phase 6 — forward_traversal Research Round (per PROJECT_RULES Rule 2)

Goal: enable variable usage-flow investigation (V8 stats + V9 chunked
explanation) by producing the forward equivalent of
`backward_traversal/runner/backward_only_runner.run_backward_only(...)`.

DESIGN.md §7 originally proposed *mirroring backward_traversal from scratch*.
The audit shows that's the **wrong path** — the existing
`forward_trace_lineage.py` is much more complete than the §7 plan assumed.
This doc presents the corrected options.

Date: 2026-05-27

---

## What already exists in the repo

Audited 2026-05-27. Details: `docs/p6_audit_findings.md` (full Explore agent
report saved separately).

| File | LOC | Importable API | Cross-file? |
|---|---|---|---|
| `forward_trace_lineage.py` | 2,110 | `ForwardLineageTracer.trace_forward(var, asm_file, bp)` + `trace_forward_from_setter(var, asm, bp, block_id, line)` | Yes — records outbound calls + inbound caller discovery; does NOT auto-recurse |
| `filter_forward_from_setter.py` | 308 | `trace_one(var, stem, block, line, bp_dir, asm_dir)`, `from_lineage(lineage_path, var, ...)` | Wraps tracer; useful for "single setter → next overwrite" |
| `filter_forward_strict.py` | 154 | CLI-only | (post-processor over lineage.json) |
| `filter_forward_overwrite.py` | 179 | CLI-only | (post-processor over lineage.json) |

Direction-agnostic helpers in `backward_traversal/utils/` reusable for both
directions (audited):

- `blueprint_utils.py` — discovery, caching, resolve_asm_blueprint
- `token_utils.py` — normalize_token, is_dep_var_candidate, dep_vars_from_args
- `subroutine_resolution.py` — extract / resolve BAS/BAL target
- `variable_name_resolver.py` — multi-file alias tracking

Backward-only (not reusable as-is):

- `cpp_lineage_utils.py::extract_tpf_regs_slots` (z/TPF register tracking is
  backward-semantics)
- `cpp_lineage_utils.py::find_cpp_seed_nodes` (GVL-based variable seeding is
  backward-direction)
- `lazy_gvl.py` (backward-specific lazy loading)

---

## Three strategies (only A or B are realistic under Rule 5)

### Strategy A — **Harvest** (lift code into `explanability_demo/`)

Copy direction-agnostic utils and the `_trace_file_forward()` / cross-file
recursion logic from `forward_trace_lineage.py` into
`explanability_demo/forward_traversal/`. Refactor for a clean API.

| Pros | Cons |
|---|---|
| Self-contained, no transitive deps on root-level modules | Duplicates ~1000 LOC of utilities |
| Free to refactor (no Rule 5 constraint on copies) | Future fixes in `forward_trace_lineage.py` won't propagate |
| Cleanest test surface (everything under our tree) | ~2–3 days work |

### Strategy B — **Wrap** (import existing tracer + provide clean API) 🟢

Keep `forward_trace_lineage.py` in place (untouched per Rule 5). In
`explanability_demo/forward_traversal/`, build a thin wrapper that:
1. Imports `ForwardLineageTracer`.
2. Provides a clean `run_forward_only(variable, process, ...) -> manifest`
   function with the same partitioned-output contract as backward_traversal.
3. Adds **process-scope filtering** (current tracer is corpus-wide; we filter
   to the process's `file_graph.json` files).
4. Validates the tracer output against source per Rule 6.

| Pros | Cons |
|---|---|
| Reuses 2,110 LOC of working logic | Transitively pins us to `forward_trace_lineage.py` API |
| ~1 day work — fastest path to V7/V8 | Future fixes need to either land upstream (not blocked by Rule 5; the original author can patch it) or be wrapper-side workarounds |
| Single source of truth for forward semantics | If the root files are refactored or moved we have to react |
| No duplication | |

### Strategy C — **Rewrite from scratch**

Mirror backward_traversal/'s two-pass architecture from scratch (the
original DESIGN §7 plan).

| Pros | Cons |
|---|---|
| Perfect symmetry with backward output shape | ~3–4 weeks; 40% test coverage at best |
| Cleanest semantics | Likely to miss edge cases backward learned over months (case sensitivity, literal addresses, non-returning ENTNC, range-write offsets) |
| | High risk of regressions against existing forward-lineage outputs the team relies on |

---

## Recommended path: **B (Wrap), with parser-validation gate**

Pragmatic, low-risk, fastest unlock for the V7/V8 UI. We add a Rule 6
parser-validation step over the tracer's output before any UI consumes it.

Specifically:

```
explanability_demo/forward_traversal/
├── __init__.py
├── README.md
├── runner.py                      ← run_forward_only(process, variable, ...)
│                                    - resolves variable's declaration file from
│                                      the variable inventory (Phase 4 SQLite)
│                                    - calls ForwardLineageTracer.trace_forward()
│                                    - filters results to in-process files only
│                                    - validates line refs against source
│                                    - emits partitioned JSON (Q6 shape):
│                                        manifest.json
│                                        root_var.json
│                                        full_file_flow.json
│                                        dep_vars/<NAME>.json
├── filter.py                      ← in-process file slicing
└── validate.py                    ← Rule-6 gate: every reported (file,line)
                                     exists in source and is a non-blank line
```

Output schema (matches backward partitioned shape):

```json
manifest.json:
  {
    "traversal_mode": "forward_only",
    "root_variable": "...", "selected_process": "...",
    "files_in_scope": [...], "dep_var_files": [...],
    "truncated": false, "warnings": [...]
  }
root_var.json:
  { "setter_sites": [...], "usage_sites_by_file": {...}, "call_graph": {...} }
full_file_flow.json:
  { "nodes": [{id, file_type, in_selected_chain, scope_variables, roles}],
    "edges": [{source, target, instructions, scope_variables, lines}] }
dep_vars/<NAME>.json:
  { "depth": int, "truncated": bool, "chain_file_results": {...},
    "downstream_file_results": {...} }
```

Caps (mirror backward defaults, configurable):
- `max_depth=8, max_dep_vars=20, max_dep_var_depth=2, max_trace_nodes=5000`

API endpoints (Phase 6 surface, planned):

| Method | Path | Returns |
|---|---|---|
| POST | `/demo/v1/processes/{P}/variables/{V}/usage-flows` | summary stats (count of usage paths, files touched, max depth) + manifest |
| POST | `/demo/v1/processes/{P}/variables/{V}/forward-trace/{flow_id}` | one dep_var file's JSON (paginated for the SSE V9 explanation loop) |

Live validation plan:
1. Run `run_forward_only` on a known C400 variable (e.g., one from the 226
   already in the variable table).
2. Manually verify: every emitted (file, line) exists in source, every block
   id exists in the corresponding blueprint.
3. Compare directional symmetry with backward on the same variable (setter
   sites should match between backward's modifier discovery and forward's
   setter detection).

---

## Three open questions for your approval

| # | Decision | Recommendation |
|---|---|---|
| Q-P6a | Strategy A (Harvest) vs B (Wrap) vs C (Rewrite) | **B — Wrap.** Fastest unlock, lowest risk, no duplication. Rule 5 preserved. |
| Q-P6b | Output schema | **Partitioned, mirroring backward's** (Q6 already approved). Adds `usage_sites_by_file` instead of backward's `setter_sites`. |
| Q-P6c | Live validation gate before V7/V8 consumes the tracer | **Required.** Compare on at least one variable for which we already know the backward modifier; assert symmetry. Failure ⇒ block frontend integration until resolved. |

---

## Sources

- `forward_trace_lineage.py` — read in full, audit recorded above
- `filter_forward_from_setter.py` — read in full
- `backward_traversal/utils/{blueprint_utils,token_utils,subroutine_resolution,variable_name_resolver}.py` — verified direction-agnostic by reading
- Memory entry `project_backward_traversal.md` — backward two-pass architecture reference
