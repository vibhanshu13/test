# Phase 6 — backward → forward Capability Gap Analysis

Triggered by the user (2026-05-27): "read through backward_traversal/ and
see what from it can we add in forward_traversal, which is currently
missing there."

This doc enumerates every capability of `backward_traversal/` that has no
counterpart in `forward_trace_lineage.py` (the upstream root-level file
our Phase 6 wrapper currently uses), and proposes which gaps to close —
all inside `explanability_demo/forward_traversal/` per Rule 5.

---

## Full gap table

| # | Capability | backward source | Forward equivalent? | Severity | Where to add it |
|---|---|---|---|---|---|
| **G1** | **C++ GVL backward tracer** — `trace_cpp_variable_backward_multi()`, BFS over GVL edges (assign/define/arg_bind/bridge/alias), terminal detection | `cpp_backward_tracer.py` | **NONE** — forward only walks ASM | **CRITICAL** | `forward_traversal/cpp_forward_tracer.py` (new) |
| **G2** | **Cross-file bridge — all 4 caller types** (ASM↔ASM, ASM↔C++, C++↔ASM, C++↔C++) | `bridge/cross_file_bridge_backward.py` | ASM↔ASM only | HIGH | `forward_traversal/bridge_forward.py` (new) |
| **G3** | **Resumable session state machine** — msgpack-persisted phase machine (PASS1 / PASS1B / PASS2B / COMPLETE) | `runner/chunked_session.py` | Stateless | HIGH | `forward_traversal/session.py` (SQLite-backed in our case, mirrors phase concept) |
| **G4** | **Variable name identity resolver** — 4-strategy lookup (identity index, ASM↔C++ alias, arg_bind param binding, struct canonical via enclosing_type) | `utils/variable_name_resolver.py` | None | HIGH | `forward_traversal/identity.py` (new) |
| **G5** | **C++ field / register alias extraction** — `extract_asm_field_aliases()`, `extract_tpf_regs_slots()` | `utils/cpp_lineage_utils.py` | None | HIGH | `forward_traversal/cpp_aliases.py` (new) |
| **G6** | **Subroutine expansion + call-graph merging** — walk into BAS/BAL, merge subroutine body with parent CFG, dedup | `tracing/asm_backward_tracer.py::merge_call_graphs()` | Forward stops at the call site | HIGH | `forward_traversal/subroutine_expand.py` (new) — can wrap forward tracer outputs |
| **G7** | **Full-flow graph collection + indirection metadata** — collector class, node/edge aggregation, indirect-call envelope | `runner/backward_only_runner.py::_new_full_flow_collector()` | Flat lineage_chain only | HIGH | Already partially built in our wrapper's `_derive_edges()`; needs richer aggregation |
| **G8** | **4-level BAS/BAL target resolution** — literal `=A(SYM)`, register tokens, symbol extraction, normalization | `utils/subroutine_resolution.py` | Basic ID indexing | MED | Reuse `backward_traversal.utils.subroutine_resolution` (Rule 5 OK — read-only import) |
| **G9** | **C++ function source extraction** — brace-aware function body extraction with string/comment handling | `utils/cpp_source_utils.py::build_func_source_index()` | None | MED | Reuse `backward_traversal.utils.cpp_source_utils` (read-only import) |
| **G10** | **Two-pass dep-var BFS up to depth=2** — dep-vars-of-dep-vars get their own trace at depth+1 | `runner/backward_only_runner.py` Pass 2 | Forward has dep_vars but no recursive BFS over them | HIGH | `forward_traversal/dep_var_bfs.py` (new) — wraps our existing wrapper |
| **G11** | **Pass 1b: root_var downstream via ENTRC subroutine_call** | `runner/backward_only_runner.py` Pass 1b | Forward records cross-file calls but doesn't auto-recurse | MED | Part of G10 |
| **G12** | **Output partitioning per dep_var with depth + truncated flag** | `runner/backward_only_runner.py::_build_dep_var_file_result()` | We already emit `dep_vars/<NAME>.json` but no per-file split inside | MED | Refine wrapper's emitter |
| **G13** | **Instruction glossary 64-bit variants (GAP-026)** — LGR, STGRL, AGHI, CGHI etc. in SETTER/TRIGGER/BRANCH sets | `glossary/instructions.py` | `trace_lineage.py` base (older) — possibly stale | MED | Reuse `backward_traversal.glossary.instructions` for our reader filters (read-only import) |
| **G14** | **Special-case patterns** — OC + BZ self-zero-test detection | `glossary/special_cases.py::match_special_dependency_pattern()` | None | LOW | Reuse `backward_traversal.glossary.special_cases` (read-only import) |
| **G15** | **Non-fatal blueprint consistency diagnostics** | `utils/blueprint_consistency.py::diagnose_blueprint_consistency()` | None | LOW | Optional wrapper diagnostics step |
| **G16** | **Cached blueprint I/O + retry-on-read** | `utils/blueprint_utils.py` | Forward has plain JSON load | LOW | Reuse `backward_traversal.utils.blueprint_utils` (read-only import) |
| **G17** | **T8/FIX18 cross-chain C++ dep-var search** | `runner/chunked_session.py` (`max_scan` option) | None | LOW | Defer — only matters for very deep C++ chains |

---

## Rule 5 reminder

We cannot modify `backward_traversal/*`, `forward_trace_lineage.py`, or any
other root-level file. Everything below either:
- **Reuses** an existing backward util by `import` (no change to source).
- **Wraps** the existing forward tracer with new behavior in
  `explanability_demo/forward_traversal/`.

If a gap truly needs upstream modification (e.g., G13 64-bit variants
inside `trace_lineage.py`), we **flag it** for a separate upstream patch
session rather than swallow the limitation silently.

---

## Recommended close-in-this-track priorities

Grouped by deliverable value. Total effort estimate for each option group.

### Track A — "Make forward minimally credible" (≈ 3-4 days)
Closes the biggest correctness gaps for the V7/V8 UI on the current
ASM-only corpus:

- **G10** Two-pass dep-var BFS over forward results (recursive expansion to depth=2)
- **G6** Subroutine expansion + call-graph merging
- **G8** Reuse backward's 4-level subroutine resolver (just an import)
- **G7** Richer full-flow graph collector to feed React Flow without UI-side glue
- **G13/G14/G16** Reuse backward glossaries + blueprint cache (read-only imports)

Outcome: ASM forward lineage matches backward's depth and shape. UI can render forward graphs the same way as backward.

### Track B — "Cross language" (≈ 5-7 days)
Adds the C++ forward layer. Critical for production 3k+ corpora where C++ files own ~40% of variable provenance.

- **G1** New `forward_traversal/cpp_forward_tracer.py` mirroring backward's GVL BFS but forward-direction
- **G2** New `forward_traversal/bridge_forward.py` with all 4 caller types
- **G4** New `forward_traversal/identity.py` for the variable-name resolver
- **G5** Reuse backward's `cpp_lineage_utils` for ASM-field aliases (read-only import)
- **G9** Reuse backward's `cpp_source_utils` for C++ function-source extraction (read-only import)

Outcome: forward lineage works on C++ variables too. C++ ↔ ASM data flow becomes traceable in both directions.

### Track C — "Make it scale" (≈ 3 days)
Persistence, resumability, robustness:

- **G3** SQLite-backed session state machine (mirror `chunked_session.py`'s phase model — but persist to our existing demo DB rather than msgpack)
- **G12** Output partition refinement (per-file results inside each dep_var file)
- **G15** Optional blueprint consistency diagnostics (non-fatal, surfaced in `warnings.json`)

Outcome: long forward traces survive process restarts and re-runs are incremental.

---

## What I recommend doing next

**Track A first.** It's the smallest, most-defensible step and unblocks the
V7/V8 UI for the ASM-heavy slice of C400 (which is most of it). Track B is
the big-bang capability but is expensive — should be sequenced **after** the
adaptive-RAG agentic-retrieval layer (Phase 8) so that the chat UI can
actually surface what the C++ tracer would find. Track C is operational
polish that benefits Track B more than Track A; defer.

If you'd rather do Track B first because "answer anything" must cover C++:
that's a 5-7 day budget commitment but unlocks 40% more of the codebase
immediately.

---

## Open questions for your approval

I'll ask via `AskUserQuestion` so we lock in the plan before any new code:

- **Q-P6d** Track to close first: A (ASM polish, 3-4d), B (C++ layer, 5-7d), or C (scale/resumability, 3d)?
- **Q-P6e** Should we discharge V_FWD live validation (Rule 6 source checks + backward-symmetry check on one variable) before any new tracker code lands?
