# Phase 4 — Tech Research Round (per PROJECT_RULES Rule 2)

Goal: surface a **variable inventory** for a process — per-variable
1-sentence business-language purpose + `/variables` endpoints. Two
mechanisms need a research-and-approve round before any code: (1)
structured-output enforcement, (2) variable-purpose extraction. (3) is a
parser-validation gate that's already executed.

Date: 2026-05-27

---

## 1. Variable-universe parser validation ✅ (Rule 6, pre-flight)

Ran `validate_parser_output.py --process C400 --mode all --sample-size 50`.

| Source | Total entries | In C400 scope | Sampled | Issues | Verdict |
|---|---|---|---|---|---|
| `asm_variable_universe.json::variables` | 2,794 occurrences across ~1,180 names | 833 | 50 | 0 | ✅ Trustable |
| `cpp_variable_universe.json::variables` | 421 occurrences across ~280 names | 160 | 50 | 0 (after ±5-line tolerance for enum/struct members) | ✅ Trustable |

Notes:
- Shape gotcha caught by validation: `variables` is `{name: [entry, entry…]}` (one list-of-occurrences per name), not `{name: entry}`. The flattener handles both. After fix, the `total` count went from "3" to "2794 / 421" — exactly the kind of silent zero the validation rule is meant to catch.
- One C++ false positive (`GlosOffset` reported at the enclosing `enum {` line, 5 lines off) — absorbed by the relaxed window. This is documented imprecision, not a parser bug.

**Phase 4 will consume `variables` directly.** Filter rules from DESIGN §6 still apply:
- ASM: keep only entries with `metadata.is_runtime_symbol == true`.
- C++: keep all entries.

Reports: `docs/parser_validation_C400.json`, `docs/parser_validation_universe_C400.json`.

---

## 2. Structured-output enforcement — research outcome

The use case: every Phase 4+ LLM call returns a small JSON object
(`{name, purpose}` for variables; later, larger objects for chunked
explanation and chat). We need to **guarantee** the response is parseable
JSON with the required shape, and **react cleanly** when it isn't.

### Constraint recap (Rule 1)
Every LLM call must go through `llm/caller.py::call_llm(prompt) -> str`. No
embedding API, no native Gemini `responseSchema` (that requires extra
config arg). No vendor SDKs imported inside `explanability_demo/`.

### Candidates surveyed (2025-2026 SOTA)

| Tool | Approach | Fits our constraint? | Notes |
|---|---|---|---|
| **Outlines** (~13.3k★) | Pre-generation token constraint — guarantees valid JSON by masking invalid tokens | **No** | Requires token-level control over the model (logits or local LM). Not exposed through Gemini API. |
| **Gemini native JSON mode** (`responseSchema`) | Server-side schema enforcement | **No** | Needs an extra arg passed to `generate_content`. `call_llm` doesn't pass it. Adding it would violate Rule 1 — we'd be back to one-off LLM SDK config knobs. |
| **Instructor** (3M downloads/mo, ~11k★) | Post-generation validation + retry, on top of provider SDK | **Wrappable** | Expects an SDK-shaped client (`openai`, `anthropic`, `google.genai`). We'd have to write a fake-OpenAI adapter pointing at `call_llm`. ~50–80 lines, fragile to upgrades. |
| **PydanticAI** (14.5k★) | Agent framework + structured output | **Wrappable, heavier** | Same client expectation as Instructor; agent abstractions overshoot our needs. |
| **Custom parse-or-retry + required_keys** (today) | Post-generation validation, raw string in, raw string out | **Native** | Already implemented in `backend/llm.py::call_llm_json`. ~120 LOC. Catches our two real failure modes: (a) malformed JSON, (b) missing top-level keys. Has been validated against real Gemini truncation in P3 (V3.8). |
| **Pydantic models** (already in venv, no new dep) | Type-safe schema definitions | **Native, additive** | Replace ad-hoc `required_keys=("a","b")` with `pydantic.BaseModel` subclasses → free field-level type validation, defaulting, and richer error messages. No new dependency (FastAPI already pulls in Pydantic). |

### Recommended approach

**Keep `call_llm_json`'s parse-or-retry skeleton, layer Pydantic models on
top** (in a new sub-package `backend/schemas/llm/`, with one BaseModel per
LLM response shape we use). The wrapper calls `Model.model_validate(parsed)`
and treats `ValidationError` exactly like our current key-mismatch path —
re-prompts with the error message.

**Why this over Instructor:**
- Zero new external deps.
- No fake-SDK adapter to maintain.
- Same retry-on-shape-error UX that Instructor offers, with one less moving
  part.
- Pydantic is the *same* tech that Instructor and PydanticAI lean on
  internally — we're just consuming the foundation directly.

**What we DON'T get vs Instructor**: streaming validation, partial-object
extraction, "patches" (incremental field updates). None of those are needed
in Phase 4–8 per DESIGN.

### Public sources reviewed (please verify any I should re-check)

- [Top 5 Structured Output Libraries for LLMs in 2026 — dev.to](https://dev.to/thedailyagent/top-5-structured-output-libraries-for-llms-in-2026-48g0)
- [5 Python Tools for Structured LLM Outputs — CodeCut](https://codecut.ai/structured-llm-outputs-tools-comparison/)
- [Comparing Python Libraries for Structured LLM Extraction — McGinnis 2025](https://mcginniscommawill.com/posts/2025-11-27-structured-extraction-with-llms/)
- [Pydantic vs Instructor vs BAML 2026 — Raj Kundalia](https://medium.com/@rajkundalia/how-baml-brings-engineering-discipline-to-llm-powered-systems-983c06d31bf8)
- [PydanticAI vs Instructor — Mahadevan Varadhan](https://medium.com/@mahadevan.varadhan/pydanticai-vs-instructor-structured-llm-ai-outputs-with-python-tools-c7b7b202eb23)
- [Structured Output with Gemini Models — Saverio Terracciano (Google Cloud)](https://medium.com/google-cloud/structured-output-with-gemini-models-begging-borrowing-and-json-ing-f70ffd60eae6)

---

## 3. Variable-purpose extraction — research outcome

The use case: given a single variable's declaration (name, type, scope,
file, line) and a few usage examples extracted from source, generate **one
business-language sentence** describing the variable's purpose, suitable
for surfacing in the V5 variables list and the V7 variable detail header.

### Candidates surveyed (2025-2026 SOTA)

| Approach | Suitable? | Notes |
|---|---|---|
| **XMainframe** (Mainframe-specialized LLM, 2024) | **No** | Specialized model, not Gemini. Violates Rule 1. |
| **C-ing Clearly (arxiv 2512.14500)** | Inspirational, not adoptable | Two-pass: decompile binary → enriched C summary. Uses fine-tuned model. Wrong shape for us. |
| **Anthropic LLM-for-legacy-modernization study (arxiv 2411.14971)** | Reference, no library | Shows line-wise prompting with surrounding context produces reliable HLASM comments. Our prompts can directly apply this finding. |
| **Single-shot Gemini prompt with declaration + 3-5 usage sites** | Yes | Cheapest, most controllable. Uses the existing `call_llm_json` wrapper. |
| **Two-pass: name-only first, then refine with usage** | Optional | If single-shot output is inconsistent in early validations. Adds latency + cost; only adopt if needed. |

### Recommended approach

**Single-shot prompt** per variable, structured as:
```
You are summarizing one mainframe data item for a non-technical business user.
- Variable name: <name>
- Declared in: <file>:<line>
- Type: <data_type>
- Scope: <scope>
- Used at (sample): <up-to-5 lines of source where the name appears>

Return only:
{"purpose": "<one business-language sentence>"}
```

Validated via `call_llm_json` with Pydantic model `VariablePurpose`. Batch
parallelism via `concurrent.futures.ThreadPoolExecutor` (stdlib, no new
tool) since each call is independent.

**Live validation plan** for V4.*: after the batch runs, randomly sample 10
variables, run a lint check (no opcode/operator tokens in `purpose`), and
do a manual eyeball on 5.

### Public sources reviewed

- [Leveraging LLMs for Legacy Code Modernization — arxiv 2411.14971](https://arxiv.org/abs/2411.14971)
- [XMainframe paper — arxiv 2408.04660](https://arxiv.org/pdf/2408.04660)
- [LLM Legacy System Modernization — mayhemcode.com 2026-02](https://www.mayhemcode.com/2026/02/llm-legacy-system-modernization.html)

---

## 4. Summary — what needs your approval

| # | Decision | Recommendation |
|---|---|---|
| Q-P4a | Structured-output mechanism | **Keep `call_llm_json` skeleton; add Pydantic models for per-call schemas.** No new external dependency. |
| Q-P4b | Variable-purpose prompt strategy | **Single-shot per variable**, with declaration + ≤5 usage lines, parallelized via stdlib `ThreadPoolExecutor`. |
| Q-P4c | Scope (which variables get a purpose) | **C400 in-scope (~993 total = 833 ASM occurrences across ~518 unique names + 160 C++ in-scope)**. ASM filtered to `metadata.is_runtime_symbol == true`. |
| Q-P4d | Live validation gate | **Mandatory live run after pipeline**: random sample of 10 variables, lint for forbidden syntax + manual eyeball on 5. Recorded in VALIDATION_TRACKER. |

If you approve all four, I implement P4 with these choices and no other
dependencies. If you'd rather adopt Instructor / PydanticAI / a different
prompt strategy, say which and I'll adjust.
