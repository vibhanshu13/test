# Phase 1 Audit Table — §16 Script Status

Generated: 2026-05-28

| Script | Location | Status | Notes |
|---|---|---|---|
| conditional_parser | `/conditional_parser.py` (project root) | VERIFIED | Read-only ASM conditional expression parser; 9,819 bytes; no DB writes |
| conditional_evaluator | `/conditional_evaluator.py` (project root) | VERIFIED | Evaluates parsed conditional expressions; 9,949 bytes; read-only |
| instruction_classifier | `/instruction_classifier.py` (project root) | PARTIAL | Classifies ASM instructions; 5,902 bytes; recent edits (2026-05-26); may need §16 sign-off |
| operation_classifier | `/operation_classifier.py` (project root) | VERIFIED | Classifies operation types from ASM opcode patterns; 9,492 bytes; read-only |
| find_call_conditions | `/find_call_conditions.py` (project root) | VERIFIED | Discovers call-site conditions from ASM blocks; 21,996 bytes; read-only pass |
| get_call_conditions | `/get_call_conditions.py` (project root) | VERIFIED | Retrieves resolved call conditions from index; 56,085 bytes; read-only |
| passes/data_flow_tracker.py | `/passes/data_flow_tracker.py` | VERIFIED | Read-only data-flow tracking pass; part of the `passes/` pipeline package |
| passes/c_family_parser.py | `/passes/c_family_parser.py` | VERIFIED | C/C++ source parser pass; read-only; used by cross-language alias pipeline |
| cross_file_bridge.py | `/cross_file_bridge.py` (project root) | VERIFIED | Cross-file call/variable bridge resolver; read-only output emitter |
| cpp_call_chain/traversal.py | `/cpp_call_chain/traversal.py` | VERIFIED | C++ backward call-chain traversal; read-only walk |
| cpp_call_chain/index_builder.py | `/cpp_call_chain/index_builder.py` | VERIFIED | Builds C++ call-chain index from parsed blueprints; read-only output |
| cpp_call_chain/source_scanner.py | `/cpp_call_chain/source_scanner.py` | VERIFIED | Scans C++ source for function definitions; read-only |
| fixes/phase1_memcpy_as_assignment | `/fixes/phase1_memcpy_as_assignment/` | PARTIAL | Upstream fix not yet integrated into main pipeline; plan.md + test present |
| fixes/phase2_field_asm_aliases | `/fixes/phase2_field_asm_aliases/` | PARTIAL | Upstream fix not yet integrated; plan.md + test present |
| fixes/phase3_asm_alias_nodes | `/fixes/phase3_asm_alias_nodes/` | PARTIAL | Upstream fix not yet integrated |
| fixes/phase4_cross_language_alias_edges | `/fixes/phase4_cross_language_alias_edges/` | PARTIAL | Upstream fix not yet integrated |
| fixes/phase5_enum_value_resolution | `/fixes/phase5_enum_value_resolution/` | PARTIAL | Upstream fix not yet integrated |
| fixes/phase5b_enum_conditional_tracking | `/fixes/phase5b_enum_conditional_tracking/` | PARTIAL | Upstream fix not yet integrated |
| fixes/phase6_ecb_mapping | `/fixes/phase6_ecb_mapping/` | PARTIAL | Upstream fix not yet integrated |
| fixes/phase7_glob_globals | `/fixes/phase7_glob_globals/` | PARTIAL | Upstream fix not yet integrated |
| fixes/phase_backward_traversal_cpp_alias_materialization | `/fixes/phase_backward_traversal_cpp_alias_materialization/` | PARTIAL | Upstream fix not yet integrated |
| fixes/phase_backward_traversal_cpp_bridge | `/fixes/phase_backward_traversal_cpp_bridge/` | PARTIAL | Upstream fix not yet integrated |
| fixes/phase_block_flow_pipeline | `/fixes/phase_block_flow_pipeline/` | PARTIAL | Upstream fix not yet integrated |
| fixes/phase_equivalent_variable_resolution | `/fixes/phase_equivalent_variable_resolution/` | PARTIAL | Upstream fix not yet integrated |
| fixes/phase_tpf_regs_register_bridge | `/fixes/phase_tpf_regs_register_bridge/` | PARTIAL | Upstream fix not yet integrated |
| fixes/phase_variable_flow | `/fixes/phase_variable_flow/` | PARTIAL | Upstream fix not yet integrated |

## Notes

- **VERIFIED**: File exists and is a read-only analysis/extraction pass with no side-effecting writes.
- **PARTIAL**: File exists but is either incomplete, recently modified without §16 sign-off, or is an upstream fix not yet integrated into the main pipeline adapters in `explanability_demo/backend/pipeline/parent_adapters/`.
- **MISSING**: File does not exist at the expected path.
- All `fixes/` directories are PARTIAL because their plans/tests exist but the fixes are not yet wired into the production pipeline.
- Paths are relative to the project root (`/Users/prathamgupta/Documents/asm-modernizer/`).
