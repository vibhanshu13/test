# Scale + "Answer Anything" — Architecture Proposal

Triggered by two user constraints (2026-05-27):
1. Production data will be **3k+ files** with a **dense call graph**, not the
   16-file C400 sample we have today.
2. The process-level chat must be able to **answer ANY question** — including
   deep explanations of arbitrary internal flows, all in business language.

This document re-evaluates every architectural choice that's impacted, per
PROJECT_RULES Rule 2 (research-and-approve). Sources cited at the end.

---

## 1. Scale extrapolation (what 3k+ files actually means)

| Dimension | C400 today | 3k-file corpus (estimated) | Per-process scope (estimated) |
|---|---|---|---|
| Files in corpus | 35 | 3,000+ | (unchanged) |
| Files in process slice | 16 | (unchanged) | 50–500 per process |
| Blocks in process slice | 788 | ~150,000 corpus-wide | 5,000–30,000 per process |
| Variables in process scope | 226 | 100k+ corpus-wide | 500–5,000 per process |
| LLM calls per process build (P3) | ~800 | ~5k–30k per process | same |
| Wall time at 8s/call sequential | ~2h | 11–67h per process | unacceptable for on-demand |

**Conclusion**: the current P3 runner (sequential within a process) doesn't
scale. We need topological parallelism, and the retrieval / QA layer needs to
go beyond single-shot BM25.

---

## 2. Affected decisions and proposed changes

### 2.A — Build pipeline parallelism (P3 retrofit)

**Current**: Within one process, blocks are summarized sequentially in topo
order. Same for files.

**Problem**: At scale, a single process build takes 10–60+ hours.

**Proposed** — **Levelized DAG parallelism** (2026 SOTA for compound LLM
workflows, e.g., [LLMSched arxiv 2504.03444](https://arxiv.org/pdf/2504.03444)):

```
topo_levels(nodes, edges) →
  level 0 = nodes with no callees (sinks)
  level 1 = nodes whose callees are all in level 0
  level 2 = nodes whose callees are all in levels 0 or 1
  ...
```

Within a level, all blocks/files are independent (no callee dependencies
between them) → summarize them in parallel with a `ThreadPoolExecutor`. Move
to next level only when current level is fully done.

**Caps** (configurable):
- `MAX_CONCURRENT_LLM_CALLS = 16` — protects against Gemini RPM limits and
  RAM pressure. Tunable per process.
- Same correctness invariant as today: callee summaries always available
  before caller summaries.

**Expected speedup**: For graphs with ~16 average level-width, ~10-15x. For
denser graphs (which is what the user expects), ~30-50x. A 30h sequential
build becomes ~1–3h.

**No new dependency**: stdlib `concurrent.futures.ThreadPoolExecutor`. The
existing `call_llm`'s internal pool is per-call; multiple concurrent callers
share the singleton `genai.Client` correctly (already documented in
`llm/caller.py`).

### 2.B — Retrieval / QA capability ("answer anything")

**Current DESIGN §8**: BM25 + LLM-rerank + LLM-synthesis. Single-shot.

**Problem**: Adequate for "what does file X do?" but cannot answer:
- "Why does C400 fail when the credit limit field is empty?" (requires
  cross-file lineage)
- "How does the response message reach the requester?" (multi-hop)
- "Which variables in dx740200 are derived from values set in da78?"
  (lineage + filtering)
- "Compare what XH80 and XH85 do — when is each invoked?" (multi-entity)

**Proposed** — **Adaptive RAG with agentic fallback** (2026 SOTA per
[GraphRAG vs RAG 2026](https://aithinkerlab.com/graphrag-vs-rag-the-ultimate-guide-to-building-reasoning-ai-search-in-2026/),
[Agentic Data Architecture 2026](https://hyperight.com/agentic-data-architecture-graphrag-mcp-2026/),
[SWE-QA arxiv 2509.14635](https://arxiv.org/pdf/2509.14635)):

```
                         ┌─────────────────────┐
   user question ──▶     │ Query classifier    │  1 call_llm
                         │ (simple/structural/ │
                         │  multi-hop)         │
                         └─────────┬───────────┘
                                   │
        ┌──────────────────────────┼──────────────────────────┐
        ▼                          ▼                          ▼
  ┌───────────┐         ┌──────────────────┐       ┌──────────────────┐
  │ Simple    │         │ Structural       │       │ Multi-hop /      │
  │ BM25 +    │         │ Single tool call │       │ Agentic ReAct    │
  │ rerank +  │         │ → synthesize     │       │ loop (1-8 iter)  │
  │ synth     │         │                  │       │ with tool catalog│
  │ (3 calls) │         │ (2 calls)        │       │ (3-15 calls)     │
  └───────────┘         └──────────────────┘       └──────────────────┘
```

**Tool catalog** (each tool is a plain Python function; the agent picks via
structured JSON output):

| Tool | Backed by | Cost |
|---|---|---|
| `search_chunks(query, top_k=8)` | BM25 over `chunk_fts` | sub-second |
| `get_process_summary()` | `process` row | sub-second |
| `get_file_summary(file)` | `file` row | sub-second |
| `get_block_summary(file, block_id)` | `block` row | sub-second |
| `get_variable_purpose(name)` | `variable` row | sub-second |
| `list_callers(file, block_id)` | block + edges query | sub-second |
| `list_callees(file, block_id)` | block row | sub-second |
| `backward_lineage(variable, process)` | `backward_traversal` package | seconds |
| `forward_lineage(variable, process)` | new `forward_traversal` (P6) | seconds |
| `read_source(file, line_start, line_end, max_lines=30)` | filesystem | sub-second |

The agent emits one of two JSON shapes per turn:
```json
{"thought": "...", "tool": "...", "args": {...}}
```
or
```json
{"thought": "...", "final_answer": "...", "sources": [{...}]}
```

Validated via `call_llm_model(AgentStep)` with a Pydantic discriminated
union. Max 8 iterations (configurable cap). All deterministic data — no
hallucinated function names or files — because every claim is grounded in a
tool result.

**Why this over GraphRAG alone**: we already have a *deterministic*
authoritative graph (file_call_graph, process truncation, backward/forward
lineage). GraphRAG's value is **reconstructing** a graph from text. We
don't need that — we should USE our graph as the agent's tool surface. This
is "graph-of-tools" agentic RAG, which is what the 2026 enterprise
architecture pattern recommends (Hyperight, Neo4j refs).

**Rule 1 preserved**: every LLM call (classifier, tool-pick, synthesizer)
flows through `call_llm` / `call_llm_model`. Tools are Python.

### 2.C — Retrieval index — stay with sqlite-fts5 or move?

**Current plan (DESIGN §8.6)**: sqlite-fts5 BM25.

**Scale concern**: at 3k files × ~50 chunks/file = ~150k chunks across the
entire knowledge base.

**Findings**:
- FTS5 handles tens of thousands of documents comfortably; the
  [Simon Willison search benchmarks](https://simonwillison.net/tags/full-text-search/)
  show sub-second performance at 10–50k.
- For per-process scope, we filter to ~5k–30k chunks first, so query-time
  cost stays low.
- Tantivy (via Turso) is a known upgrade path but a new dep.

**Proposed**: keep sqlite-fts5 for the demo and ship a measurable validation
gate. If query latency exceeds 500ms p95 at production scale, swap in
Tantivy. This is a *deferred research* with a triggering threshold rather
than a premature optimization.

### 2.D — Frontend rendering at scale

**Current plan**: React Flow + ELK layout for file graph + block graph.

**Concern**: at 200+ nodes per process, React Flow rendering can stutter.

**Proposed**:
- React Flow with built-in **virtualization** (only render in-viewport nodes).
- ELK layout computed in a Web Worker for graphs >100 nodes.
- "Group by file" cluster view when >50 nodes are visible (collapse
  intra-file blocks; expand on click).

No new dep — React Flow supports both features natively in v12+.

### 2.E — Build cost projection (with parallelism)

Empirical from C400 today: ~8s/call wall time, sequential.

With levelized parallelism at concurrency=16 on an average-DAG-width-of-16
process:
- 5,000-block process: ~5000/16 × 8s = ~42 min
- 15,000-block process: ~15000/16 × 8s = ~2h

At Gemini 2.5 Pro pricing (~$0.011/call), per-process build cost:
- 5,000 blocks: ~$55 once, then cached
- 15,000 blocks: ~$165 once

**On-demand build** policy (Q2) means this is paid only when a process is
first opened. Re-runs after prompt-template bumps cache-skip everything that
hasn't changed.

---

## 3. Decisions you need to approve

(All four are recommendations consistent with PROJECT_RULES; I'll ask in a
single AskUserQuestion call after this doc.)

| # | Decision | Recommendation |
|---|---|---|
| Q-S1 | Levelized DAG parallelism in P3 build pipeline (retrofit) | Adopt. Stdlib `ThreadPoolExecutor`, configurable concurrency cap (default 16). Same correctness as today. |
| Q-S2 | "Answer anything" QA approach for P8 | **Adaptive RAG**: classifier routes to (i) simple BM25 + rerank + synth, (ii) single-tool, or (iii) **agentic ReAct loop with deterministic tool catalog over our existing graph + SQLite knowledge base**. Cap iterations at 8. |
| Q-S3 | Retrieval index choice | Keep sqlite-fts5 for now with an explicit "p95 < 500ms" gate; swap to Tantivy if breached. |
| Q-S4 | Frontend graph virtualization | React Flow built-in virtualization + ELK in Web Worker + cluster-by-file view above 50 nodes. No new deps. |

If you approve all four, I'll:
- Retrofit P3 runner with levelized parallelism (small change).
- Lock the agentic-RAG architecture into DESIGN.md §8.
- Add measurable gates to VALIDATION_TRACKER for query latency and agent-loop iteration count.
- Proceed with P5 (frontend) using these constraints baked in.

---

## 4. Sources

- [GraphRAG vs RAG 2026 — AiThinkerLab](https://aithinkerlab.com/graphrag-vs-rag-the-ultimate-guide-to-building-reasoning-ai-search-in-2026/)
- [Why GraphRAG and MCP Are the New Standard for Agentic Data Architecture — Hyperight](https://hyperight.com/agentic-data-architecture-graphrag-mcp-2026/)
- [SWE-QA: Can Language Models Answer Repository-level Code Questions? — arxiv 2509.14635](https://arxiv.org/pdf/2509.14635)
- [LLMSched: Uncertainty-Aware Workload Scheduling for Compound LLM Applications — arxiv 2504.03444](https://arxiv.org/pdf/2504.03444)
- [Batch Query Processing and Optimization for Agentic Workflows — arxiv 2509.02121](https://arxiv.org/html/2509.02121v2)
- [10 RAG Architectures in 2026 — Techment](https://www.techment.com/blogs/rag-architectures-enterprise-use-cases-2026/)
- [GraphRAG and Agentic Architecture with Neo4j NeoConverse — Neo4j blog](https://neo4j.com/blog/developer/graphrag-and-agentic-architecture-with-neoconverse/)
- [AI Agents in Production: Frameworks, Protocols, and What Actually Works in 2026 — 47billion.com](https://47billion.com/blog/ai-agents-in-production-frameworks-protocols-and-what-actually-works-in-2026/)
- [Simon Willison on full-text search](https://simonwillison.net/tags/full-text-search/)
