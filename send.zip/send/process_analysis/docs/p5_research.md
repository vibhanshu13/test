# Phase 5 — Frontend Tech Research Round (per PROJECT_RULES Rule 2)

Goal: scaffold the React frontend that renders the 10 views in DESIGN §10.
Phase 5a (this round) covers foundation + V1 (process list) + V2 (process
detail overview). 5b adds graphs (V3/V4/V8). 5c adds chat/SSE (V6/V9/V10).
5d wires V5/V7 variable surfaces.

Already-approved (Q1, Q-S4 — no re-decision needed):
- React 18 + Vite + TypeScript
- Tailwind CSS + shadcn/ui (Radix primitives)
- TanStack Query (DESIGN §10.1)
- React Flow v12+ (@xyflow/react) — Phase 5b
- ELK.js in Web Worker — Phase 5b

This doc covers the three **new** tech decisions still open for Phase 5a:
routing, API client generation, test framework. All sources cited at the end.

Date: 2026-05-27

---

## Q-P5a1 — Routing library

| Candidate | Type-safety | Active dev | Bundle | Recommendation |
|---|---|---|---|---|
| **TanStack Router** | First-class — params, search, loaders fully typed | Very active, 1.2M weekly downloads, growing fast | ~12 KB gz | ✅ Recommended |
| **React Router v7** (SPA mode) | Manual casting needed for typesafe routes; codegen for framework mode | Development slowed; mature | ~16 KB gz | Stable but type-safety lags |
| **Wouter** | Minimal, no built-in types | Stable, niche | <2 KB gz | Too minimal for 10-view app |

**Choice rationale**: TanStack Router's URL-as-typed-state model fits our
shape (process names, file paths, variable names all flow through routes).
Free TanStack Query integration (same team) for loader → cache.

[Source: pkgpulse.com tanstack-router-vs-react-router-v7-2026](https://www.pkgpulse.com/blog/tanstack-router-vs-react-router-v7-2026),
[Source: bswen.com 2026 migration guide](https://docs.bswen.com/blog/2026-03-11-react-router-vs-tanstack-router/)

---

## Q-P5a2 — API client generation

FastAPI auto-generates OpenAPI 3.1 at `/openapi.json`. We can either
hand-roll typed `fetch` calls or generate a typed client.

| Candidate | Approach | Hooks | Mocking | Recommendation |
|---|---|---|---|---|
| **@hey-api/openapi-ts** | OpenAPI → TypeScript + plugins (TanStack Query plugin = typed hooks for free) | ✅ via plugin | ✗ | ✅ Recommended |
| **Orval** | Codegen with built-in mocks | ✅ generates `useXxx` hooks per route | ✅ | Heavier; built-in mocks not needed here |
| **openapi-typescript** | Types only — you write fetch calls yourself | ✗ | ✗ | Less code generated; manual integration |
| **Hand-rolled fetch with custom types** | Write `getProcesses()` etc. by hand | manual | manual | Tedious; types drift if backend changes |

**Choice rationale**: Hey API is the 2026 frontrunner; used by Vercel, OpenCode, PayPal. Its TanStack Query plugin generates `useGetProcessesQuery()` hooks pre-wired with type-safe params and response shapes. Backend schema change → re-generate → TypeScript errors flag every consumer. No drift possible.

Operational note: regeneration runs as a single `npm run generate:api` from a saved `openapi.json` snapshot. The CI gate compares the committed `openapi.json` to FastAPI's live one and fails on drift.

[Source: dev.to OpenAPI codegen 2026 comparison](https://dev.to/nyaomaru/which-openapi-codegen-should-you-choose-openapi-typescript-vs-hey-api-vs-orval-vs-kubb-100p),
[Source: hey-api GitHub](https://github.com/hey-api/openapi-ts),
[Source: FastAPI generating SDKs docs](https://fastapi.tiangolo.com/advanced/generate-clients/)

---

## Q-P5a3 — Test framework

| Candidate | Unit/Component | E2E | Bundle on dev | Recommendation |
|---|---|---|---|---|
| **Vitest** (alone) | ✅ — first-class with Vite | ✗ | adds nothing in prod | Sufficient for 5a |
| **Vitest + Playwright** | Vitest for components, Playwright for E2E | ✅ | adds nothing in prod | ✅ Recommended once V3+ ship |
| **Jest + React Testing Library** | ✅ | needs Cypress/Playwright | requires babel-jest, more config | Older, more setup |

**Choice rationale**: Vitest is the natural fit with Vite (shares the
config, same plugins). For 5a (no graphs / no SSE yet), Vitest alone is
fine. Add Playwright for V9 chat-stream and V3 graph-interaction tests in
5b/5c. Defer the Playwright install until then.

---

## Phased delivery breakdown (sub-phases of P5)

| Sub-phase | Deliverable | Approx. |
|---|---|---|
| **5a** | Scaffold + V1 (process list) + V2 Overview tab + V5 Variables list. Hits `/demo/v1/processes`, `.../{P}`, `.../{P}/variables`. No graphs. Vitest unit tests. | 1–2 days |
| **5b** | V3 Files (React Flow + ELK + 50/50 split) + V4 File detail. Add Playwright. | 2 days |
| **5c** | V6 process chat + V9 chunked explanation (SSE) + V10 variable chat — depends on Phase 8 backend. | 2 days |
| **5d** | V7 variable detail + V8 investigation chooser — depends on Phase 6 forward_traversal. | 1 day |

5a can start now and ship today — it only needs Phase 2 + Phase 4 endpoints,
both already live.

---

## Folder structure (proposed)

```
explanability_demo/frontend/
├── package.json
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.js
├── postcss.config.js
├── index.html
├── src/
│   ├── main.tsx
│   ├── App.tsx
│   ├── routes/                # TanStack Router file-based routes
│   │   ├── __root.tsx
│   │   ├── index.tsx          # V1 process list
│   │   ├── p.$P.tsx           # V2 process detail layout
│   │   ├── p.$P.index.tsx     # V2 Overview tab
│   │   └── p.$P.variables.tsx # V5
│   ├── api/                   # Hey API generated
│   │   ├── client.gen.ts
│   │   ├── sdk.gen.ts
│   │   └── types.gen.ts
│   ├── components/
│   │   ├── ui/                # shadcn/ui generated
│   │   ├── primitives/        # lightly modified shadcn
│   │   └── blocks/            # product-level compositions (ProcessCard, etc.)
│   ├── hooks/
│   ├── lib/
│   │   └── utils.ts           # shadcn cn() helper
│   └── styles/
│       └── globals.css        # Tailwind base + CSS vars
└── tests/
    └── (vitest configs + first smoke tests)
```

---

## CI / build flow (for the demo)

```bash
# Generate types from the running backend
curl -s http://127.0.0.1:8010/openapi.json > frontend/openapi.json
cd frontend && npm run generate:api    # invokes hey-api

# Dev
npm run dev                # Vite on :5173, proxies /demo/v1/* to :8010

# Build
npm run build              # → dist/, static, no SSR

# Test
npm run test               # vitest watch
```

---

## Sources

- [TanStack Router vs React Router v7 — pkgpulse 2026](https://www.pkgpulse.com/blog/tanstack-router-vs-react-router-v7-2026)
- [React Router vs TanStack Router migration guide — bswen 2026-03](https://docs.bswen.com/blog/2026-03-11-react-router-vs-tanstack-router/)
- [TanStack Router comparison docs](https://tanstack.com/router/latest/docs/framework/react/comparison)
- [Which OpenAPI Codegen Should You Choose — dev.to](https://dev.to/nyaomaru/which-openapi-codegen-should-you-choose-openapi-typescript-vs-hey-api-vs-orval-vs-kubb-100p)
- [hey-api/openapi-ts GitHub](https://github.com/hey-api/openapi-ts)
- [Generating SDKs — FastAPI docs](https://fastapi.tiangolo.com/advanced/generate-clients/)
- [shadcn/ui Best Practices 2026 — DesignRevision](https://designrevision.com/blog/shadcn-ui-guide)
- [Shadcn UI Best Practices 2026 — Medium / Vaibhav Gupta](https://medium.com/write-a-catalyst/shadcn-ui-best-practices-for-2026-444efd204f44)
- [React Flow Migrate to v12](https://reactflow.dev/learn/troubleshooting/migrate-to-v12)
- [React Flow ELK.js example](https://reactflow.dev/examples/layout/elkjs)
