# Process Analysis Redesign — Top-Down Conditional Walk + Variable Footprints

**Author:** Pratham + Claude (design sessions, 2026-05-27)
**Status:** DESIGN — no code yet. Awaiting agreement before Phase 1 wiring.
**Scope:** `explanability_demo/` consumes the parent `asm-modernizer/` codebase
as deterministic substrate; LLM (Gemini 2.5 Pro, via the single `call_llm_model`
entry point) sits on top only where deterministic facts cannot answer.

This document is the **single source of truth** for the redesign. Edit it in
place when decisions change — see §20 for the maintenance protocol.

---

## 1. Why this redesign

### What we have today (bottom-up)

The existing pipeline summarises **every** block of **every** file in a process,
then rolls those up into file-level and process-level summaries. It is complete
but noisy:

- A 5 000-line ASM file produces ~50 block summaries even though most blocks
  are utility/boilerplate/error-handling and irrelevant to the process's
  business purpose.
- Call-graph edges are unconditional — we know `A → B` but not "A calls B
  *when* the input is type X".
- Variables have no classification — `business` vs `intermediate` vs
  `persistence` vs `input` vs `output` is invisible.
- Process inputs and outputs are mentioned in free-text summaries, never
  structured.
- Persistence-layer touches (z/TPFDF DB macros, file/storage ops, transaction
  scope boundaries) are not flagged on either blocks or variables.

### What we want (top-down, conditional, classified)

1. **Full conditional call graph** — every edge carries the condition that
   gates it, at file *and* block resolution.
2. **Block-wise and file-wise analysis** with purpose attached.
3. **Variable inventory with classification** — five categories: `business` /
   `process-io` / `persistence` / `control` / `infrastructure`.
4. **Top-down walk from the process entry point**, with relevance filtering
   so we don't deep-dive into utility plumbing.
5. **Explicit process input / output spec.**
6. **Persistence-layer flags** on blocks, functions, and variables, derived
   from general IBM z/TPF and z/TPFDF patterns — not a hard-coded macro list.
7. **Business-language Q&A** at process / file / block / variable level.
8. **All four cross-language patterns**: ASM↔ASM, ASM↔C++, C++↔ASM, C++↔C++.
9. **All variables** get a footprint (no pre-filtering — relevance becomes
   a label, not a gate).
10. **Mixed-codebase posture** — never assume any file is ASM-only or
    C++-only; entry points and footprint roots can be either; every cross-
    language transition is first-class.

---

## 2. Design principles

| Principle | Implication |
|---|---|
| **Deterministic where feasible, LLM only on top** | Parsers, classifiers, propagators — all parent-codebase scripts. LLM does ranking, labelling, business-language synthesis. |
| **Reuse parent codebase; verify before consuming** | Every script we pull in goes through the audit workflow (§15). Never copy-paste; always wrap. |
| **Rule 1 — one `call_llm_model`, Gemini 2.5 Pro only** | Every new LLM-touching module imports `explanability_demo.backend.llm.call_llm_model`. No exceptions. |
| **Rule 1-E — one `call_embedding`, `text-embedding-004` only** | Every embedding call goes through `explanability_demo.backend.embedding.call_embedding`. Analogous to Rule 1 for generation. See §11.5. |
| **Rule 5 — code changes only in `explanability_demo/`** | Adapters wrap parent scripts; fixes to parent scripts are a separate concern. |
| **Rule 6 — validate parser output against the files** | Every Phase 1 output gets a validator that re-reads the source and confirms the row is correct. |
| **Celery for all async work** | Every pipeline phase and any API operation that takes > 500 ms dispatches a Celery task routed to the correct queue (`q_emit` / `q_io` / `q_llm`). No `threading.Thread` in route handlers. See §19.5 for full mandate. |
| **202 Accepted + poll** | Any route that starts a pipeline task returns HTTP 202 with `{"task_id": "…", "status": "pending"}`. A Redis pending marker is written **before** `apply_async` is called. A `GET /…/status/{task_id}` endpoint polls Redis for completion. |
| **No duplicate LLM calls** | Each piece of information is produced by exactly one LLM call. Block summary and business name are combined into a single Phase 2 prompt per block. `variable_meaning` rows are populated from `variable_context.purpose` (no extra call). `condition_human` is generated in one post-Phase-3 pass, deduplicated by expression text. |
| **Rows not blobs at request time** | No route loads a file or in-memory structure whose size is proportional to codebase size. All data is stored in indexed SQLite tables; routes read individual rows with `LIMIT`/`OFFSET`. See §19.5. |
| **Everything we capture is queryable** | New SQLite tables with `BLOB` embedding columns (pgvector Python adapter, SQLite mode) for guards, footprints, classifications, I/O sites, embeddings. Chat agent gets new tools to query them. |
| **No hidden state** | Every LLM call's inputs are derivable from the database; every output is persisted with a content hash for resumability. |
| **Hybrid retrieval by default** | Every text-search surface uses BM25 (FTS5) + ANN (pgvector `cosine_distance`, SQLite mode) fused via RRF, then LLM-reranked. Pure BM25 is the fallback only when the embedding index is cold. |
| **Mixed-language by default** | No phase assumes a single language. Language is detected per file/block at analysis time. |
| **IBM TPF/DF patterns as anchors** | We model the canonical IBM patterns (DB lifecycle, storage lifecycle, commit scopes, keyed LREC access, ECB/DBIFB context, ASM↔C linkage) explicitly. They are the deterministic skeleton. |
| **Codebase-scale-agnostic by construction** | Every detector uses pattern-based / structural rules, never closed lists. Path conventions, build-system signals, fan-in statistics, cross-process call indexes are first-class inputs. The same code works on 16 files or 22 000 files. |
| **Per-process semantics** | Utility-ness, domain-types, classification labels are all **per-process**, not absolute. The same file/block can be utility for one process and business for another. |

---

## 3. Outcome at a glance

After the pipeline runs for a process P, we will have, queryable in SQLite:

- A **conditional call graph** at file *and* block resolution, every edge
  carrying its guard expression.
- A **top-down walk tree** rooted at the entry block, with each node tagged
  `data-path` / `validation` / `data-transformation` / `persistence-write` /
  `error-handling` / `logging` / `infrastructure` / `skipped-utility`.
- A **variable footprint** for every variable: the exact `(file, block)`
  pairs we need to read to understand it, the edge types that brought us
  there, the guard conditions on each step.
- A **variable classification** per variable.
- An **I/O site table** with hybrid (deterministic + LLM) detection,
  recording op type, target record, key, inputs, outputs, transaction scope.
- A **storage lifecycle table** (GETCC/RELCC/DETAC/ATTAC and C equivalents).
- A **commit scope table** (TXBGC/TXCMC/TXRBC and C equivalents).
- A **process input/output spec.**
- A **flow enumeration** — for each output kind, all paths from entry to
  that output with guards and children analyses attached.
- All the existing block/file/process summaries we already have, enriched
  with the new metadata.

The UI gets: filterable Variables tab, flows view, conditional call graph
view, persistence-touches view, transaction-scope view, and substantially
better chat answers because the index is richer.

---

## 4. Phase-by-phase pipeline

The pipeline is **five phases**, executed in order. Each phase reads only
the previous phase's outputs (no skipping back). Phases 1, 2, 4 are
parallelisable; 3 and 5 are sequential but bounded.

```
  ┌─────────────┐   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐
  │  Phase 1    │   │  Phase 2    │   │  Phase 3    │   │  Phase 4    │   │  Phase 5    │
  │ Static      │ → │ Block       │ → │ Top-down    │ → │ Variable    │ → │ Process     │
  │ foundation  │   │ summaries   │   │ walk +      │   │ footprint + │   │ synthesis   │
  │ (no LLM)    │   │ (LLM, par)  │   │ relevance   │   │ classify    │   │ (LLM, seq)  │
  │             │   │             │   │ (LLM, seq)  │   │ (LLM, par)  │   │             │
  └─────────────┘   └─────────────┘   └─────────────┘   └─────────────┘   └─────────────┘
```

**Celery queue assignments (MANDATORY — see §19.5):**

| Phase / task | Celery queue | Rationale |
|---|---|---|
| Full pipeline orchestration (Phase 1→5 in sequence) | `q_emit` | CPU-heavy, multi-hour; one slot per process |
| Phase 1a-1d sub-tasks (static analysis, wrapping parent scripts) | `q_io` | I/O-bound disk reads; no LLM |
| Phase 2 block summaries + business names (parallel LLM) | `q_llm` | LLM API calls, rate-limited |
| Phase 3 top-down walk (sequential LLM, one call per block) | `q_llm` | LLM API calls; sequential so bounded |
| Phase 4 variable context (parallel LLM) | `q_llm` | LLM API calls, rate-limited |
| Phase 5 synthesis (sequential LLM + walkthrough parallel) | `q_llm` | LLM API calls |
| Variable build orchestration | `q_emit` | Orchestration, same pattern as full build |
| Schema migration, DB maintenance | `q_io` | DB-bound, no LLM |
| SPEC rebuild, index rebuild | `q_io` | File I/O, no LLM |

---

### 4.0 Language posture (applies to every phase)

**Every file's language is inferred at analysis time** (extension + content
sniffing). **No phase assumes a single language.** The system supports:

- ASM-only processes (entry ASM, body ASM)
- C++-only processes (entry C++, body C++)
- Mixed processes with ASM entry — descends into C++ via `CALLC` / ENTxC
  and back via callbacks/returns
- Mixed processes with C++ entry — descends into ASM via `CALL_ALIAS` or
  direct dispatch
- N-language transitions at any depth in the walk

Concrete enforcement:

| Site | Language-agnostic mechanism |
|---|---|
| Process entry | `entry.kind ∈ {asm-routine, cpp-function}`. The walker dispatches to the right "read-before-write" routine based on `kind`. |
| Each walk frontier element | `(file, block)` carries `language ∈ {asm, cpp}`. Frontier expansion uses the language-appropriate detector. |
| Cross-file edges | Always go through `cross_file_bridge.py`, which auto-detects which of the 4 patterns (ASM↔ASM, ASM↔C++, C++↔ASM, C++↔C++) applies. |
| Variable footprint root | `decl_kind` covers every ASM and C++ declaration shape. The BFS uses propagators applicable to `decl_kind`. |
| Propagators | Each propagator declares which language pairs it applies to. The BFS only invokes propagators where source/target language pair matches. |
| Input/output identification | Has separate ASM and C++ rules (§8 + §10). |
| Guards | `guard_kind` enumerates both ASM (`aif`, `cmp-branch`, `clc-branch`, `tm-branch`, `enum-equals`, `macro-arg-gate`) and C++ (`cpp-if`, `cpp-switch-case`, `cpp-ternary`) kinds. |
| Validators | Separate ASM and C++ validators per phase. Both run; whichever applies to the file's language is the authority. |

---

### 4.1 Phase 1 — Static foundation (deterministic, no LLM)

**Purpose:** extract every machine-checkable fact about the process. Output
is reviewable by hand.

**Sub-tasks and where each one comes from:**

| Sub-task | Parent-codebase source | Wrapper in explanability_demo |
|---|---|---|
| File call graph (already produced) | `file_call_graph.py` | already wired |
| Process-scoped truncated file graph | `process/build_process_truncated_file_graph.py` | wrap, validate edge count against source |
| Process-guarded file calls | `process/extract_process_guarded_file_calls.py` | wrap, validate guards against ASM/C++ source |
| Conditional file→file calls (4 patterns) | `find_call_conditions.py`, `get_call_conditions.py` | wrap; expose via `call_edge_guard` |
| Block-level flow within a file | `call_graph/topological_block_flow.py` | wrap; expose via `block_flow` table |
| Cross-file block flow | `call_graph/cross_file_flow.py` | wrap; reconcile with current `block` table |
| Block-edge conditions (intra-file) | `conditional_parser.py` + `conditional_evaluator.py` + `instruction_classifier.py` | new module: derive guards on intra-file branch edges |
| **I/O site detection (hybrid)** | `passes/db_operation_extractor.py`, `macro_classifier.py`, IBM TPF/DF patterns from `docs/ibm/` | new hybrid detector (see §4.1.1) |
| Storage lifecycle (GETCC/RELCC/...) | `passes/db_operation_extractor.py` extended; `instruction_classifier.py` for macro recognition | new wrapper; emits `storage_lifecycle` rows |
| Commit scope detection | new module (deterministic macro scan) | emits `commit_scope` rows |
| Variable lineage per file | `passes/variable_lineage_builder.py`, `passes/global_lineage_stitcher.py` | wrap; enrich existing `variable` table |
| Cross-language identity (C++↔ASM) | `passes/cross_file_access_identity.py`, `fixes/phase4_cross_language_alias_edges/`, `trace_cpp_to_asm.py`, `get_equivalent_variable.py` | wrap; expose via `variable_alias` |
| ECB alias mapping | `passes/ecb_alias_table.py`, `fixes/phase6_ecb_mapping/` | wrap; expose via `ecb_alias` |
| Field ↔ ASM aliases (struct fields) | `fixes/phase2_field_asm_aliases/` | wrap |
| Connected variables between files (detect) | `find_connected_variables.py` | wrap; called on demand during Phase 4 variable context extraction. Detects 4 connection types: `call_boundary_registers`, `return_registers`, `shared_dsects`, `shared_memory_fields`. |
| Connected variables between files (map) | `map_connected_variables.py` | wrap; called immediately after `find_connected_variables.py` for each file pair. Builds named variable-to-variable mappings with confidence + evidence tracing (`from_var`, `to_var`, `via_register`, `from_evidence`, `to_evidence`). Three mapping types: `call_boundary_register`, `return_register`, `shared_memory_field`. `MAX_WALK_DEPTH=3` for lineage graph traversal. |
| Variable modifiers across files | `find_variable_modifiers.py`, `build_modifier_index.py` | wrap; build process-wide modifier index |
| Variable identity (5-layer) | `build_variable_identity_index.py`, `fixes/phase_equivalent_variable_resolution/` | wrap |
| Variable hop index | `build_variable_hop_index.py` | wrap |
| Enum value resolution | `fixes/phase5_enum_value_resolution/`, `fixes/phase5b_enum_conditional_tracking/` | wrap; needed for human-readable guards |
| Utility/business file classification | `utility_detector_v2.py` (hard rules layer 1) | wrap |
| Conditional assembly directives | `conditional_parser.py` (AIF/AGO/ANOP/SETA/SETB/SETC) | wrap |
| Macro expansion | `passes/macro_expansion_pass.py`, `macro_expander.py`, `macro_library.py` | wrap |
| Literal resolution | `literal_resolver.py` | wrap |
| Memcpy-as-assignment (C++) | `fixes/phase1_memcpy_as_assignment/` | wrap |
| Glob globals (C++) | `fixes/phase7_glob_globals/` | wrap |
| TPF regs ↔ register bridge | `fixes/phase_tpf_regs_register_bridge/` | wrap |
| ASM alias nodes | `fixes/phase3_asm_alias_nodes/` | wrap |
| Indirect call envelope (already in branch) | commit `0f6d46a` work | already in this repo branch |

**Phase 1 output is fully reviewable** — every row in every new table can be
spot-checked by reading the source file. No LLM uncertainty.

---

#### 4.1.1 I/O site detection — hybrid (deterministic + heuristic + LLM)

The IBM z/TPFDF macro family is broad and process codebases include
in-house wrapper macros, custom DBOps abstractions, and bespoke
persistence patterns. Therefore we use a **three-layer hybrid detector**
modelled on `utility_detector_v2.py` (HYBRID_UTILITY_DETECTION.md):

##### Layer 1 — IBM-pattern hard rules (deterministic, `confidence = 1.0`)

**Status: LOCKED 2026-05-27.** Strategy = inclusive with sub-category.
Every macro in `macro_classifier.py` catalog is L1; each row tagged with
`op_category`. Storage lifecycle and transactions stay in dedicated
tables (`storage_lifecycle`, `commit_scope`).

Anchor on the canonical IBM z/TPF and z/TPFDF macros and their C
counterparts. Sources: `docs/ibm/macros/ztpfdf-db-macros.md`,
`docs/ibm/macros/ztpf-system-macros.md`,
`docs/ibm/functions/ztpfdf-c-functions.md`,
`docs/ibm/functions/ztpf-os-c-functions.md`.

**`op_category` taxonomy** — every L1 io_site row gets one:

| op_category | Macros / functions | Semantics |
|---|---|---|
| `READ` | DBRED, dfred*, DBGET, dfget* | Read LREC(s) |
| `WRITE` | DBWRT, DBPUT, dfwrt*, dfput* | Write LREC(s) — covered by file ops as well |
| `INSERT` | DBADD, dfadd* | Add new LREC(s) |
| `UPDATE` | DBMOD, dfmod, dfmod_all*, DBREP, dfrep* | Modify / replace existing LREC |
| `DELETE` | DBDEL, dfdel* | Delete LREC(s) |
| `KEY-STATE` | DBKEY, DBSETK, dfkey, df_setkey, df_nbrkeys | Activate / build keys (affects subsequent reads) |
| `OPEN` | DBOPN, dfopn* | Open subfile context |
| `CLOSE` | DBCLS, dfcls | Close subfile context |
| `LOCK` | DBHOLD, DBUHLD, dfhold, dfuhld | Hold / unhold (locking, not data change) |
| `INDEX` | DBIDX, DBDIX, dfidx, dfdix | Index ref create / delete |
| `POSITION` | DBRET, dfret | Retain LREC position |
| `WORK-SPACE` | DBSPA, dfspa | Allocate DB-managed work area |
| `CONTEXT` | DBIFB, dfifb, DBADR, dfadr | DB context / address operations |
| `CHECKPOINT` | DBCKP, dfckp | Checkpoint state |
| `MERGE-SORT` | DBMRG, DBSRT, dfmrg, dfsrt | Bulk merge / sort |
| `RESTORE` | DBRST, dfrst | Restore / reset |
| `COPY` | DBCPY, dfcpy | Copy subfile |
| `CREATE` | DBCRE, dfcre | Create subfile |
| `EXIT-DIRTY` | DBCLR | Exit with open files, no dump |
| `MISC-NEEDS-VERIFY` | DBTLD, DBTLG, DBTRD, DBUKY, dftld, dftlg, dftrd, dfuky | IBM docs mark as `needs verification` — included but tagged for audit |

**Persistence views and chat tools** filter by op_category. The
"persistence summary" UI shows op_category ∈ {WRITE, INSERT, UPDATE,
DELETE} by default; "data reads" filters to {READ}; "DB lifecycle" view
includes {OPEN, CLOSE, LOCK}; key state appears separately because keys
affect what later reads return.

**`MISC-NEEDS-VERIFY` rows** are tagged in `evidence_json` with
`{"audit_required": true, "ibm_doc_status": "needs-verification"}` so
they show up in the audit dashboard for manual review during Phase 0.

**Persistence ops beyond DB at L1** (locked 2026-05-27):

In addition to the DB macros above, L1 also covers the **z/TPF file I/O
family**:

| op_category | Macros / functions | Semantics |
|---|---|---|
| `FILE-READ` | FINDC, FINHC, findc*, finhc* | Find/read a record without write-allocation |
| `FILE-WRITE` | FILEC, FINWC, FIWHC, finwc*, fiwhc* | File / write record (may include header) |
| `FILE-READ-ALLOC` | (subset of FINDC/FINHC variants that allocate as a side effect of read) | Read + storage allocation in one op |

A `FILE-READ-ALLOC` site emits BOTH an `io_site` row (op_category =
FILE-READ-ALLOC) AND a paired `storage_lifecycle` row (op = matching
macro), so the storage handoff is queryable from either side.

**Out of scope for L1 (handled by L2 heuristics):**
- Queue / message ops (ROUTC, SONIC, etc.) — codebase-specific.
- Audit / logging APIs — usually noise; H2/H5 heuristics catch real
  cases (e.g. a function named `audit_persist()` matches H2).
- External service writes — H5 ORM/DAO pattern catches these.

**Out of scope for `io_site` entirely:**
- `GETCC COMMON=YES` / protected storage — stays in `storage_lifecycle`
  with a `shared=true` flag, because it's shared memory rather than
  durable persistence.
- Async spawn data handoff (`CREEC` etc.) — already tagged
  `async-spawn` in the walk; not duplicated as a persistence op.

---

#### 4.1.2 Utility detection — seven-layer hybrid (scale-aware)

**Status: REVISED 2026-05-28.** Designed for codebases up to 22 000+
files. Utility-ness is **per-process** — the same block can be utility
for process A and business for process B. Every layer below contributes
a `utility_confidence ∈ [0, 1]`; the highest non-conflicting signal
wins, with manual override (L5) always taking precedence.

##### Layer 0 — Path / build-system signals (cheapest, very high precision)

Runs before parsing — pure path lookups + makefile/CMake/build-descriptor reads.

| Signal | Treatment |
|---|---|
| File under `vendor/`, `third_party/`, `external/`, `extern/` | `utility_confidence = 1.0` |
| File is a build-target inclusion of a "library" target (Makefile, CMakeLists.txt, z/TPF build descriptor) | 1.0 |
| File under `*/util/*`, `*/utils/*`, `*/common/*`, `*/lib/*`, `*/libs/*`, `*/helpers?/*`, `*/shared/*`, `*/infra/*`, `*/system/*`, `*/base/*`, `*/aux/*`, `*/support/*` | 1.0 |
| File under `test/`, `tests/`, `mock/`, `mocks/`, `fixtures/`, `testdata/` | 1.0 (test-time only) |
| File header contains markers like `auto-generated`, `DO NOT EDIT`, `generated by`, `@generated` | 1.0 (generated code) |
| File is a `.mac` macro library | 1.0 |
| **ASM DSECT-only file** — file contains one or more `DSECT` statements but zero `CSECT` / `RSECT` / `START` statements (pure data-structure definition, no executable code) | 1.0 |
| **ASM MACRO-definition-only file** — file begins with `MACRO` and ends with `MEND`, no `CSECT` / `RSECT` in between (pure macro library member) | 1.0 |
| **COPY member in a standard library path** — file is referenced exclusively via `COPY` / `INCLUDE` (not `BAL` / `CALLC`) and resides under paths matching `*/copy/*`, `*/copybooks/*`, `*/maclib/*`, `*/syslib/*`, or the build descriptor's `SYSLIB` concatenation | 1.0 |

##### Layer 1 — Structural rules (deterministic, 13 rules)

A `(file, block)` is hard-utility for process P if **ALL** of:

1. **No persistence** — zero `io_site` rows with op_category ∈ {WRITE, INSERT, UPDATE, DELETE, READ, FILE-WRITE, FILE-READ, FILE-READ-ALLOC}.
2. **No transaction control** — zero TXBGC / TXCMC / TXRBC / TXSPC / TXRSC.
3. **No async spawn** — zero CREEC / CREMC / CREDC / CREXC / CRETC / CRESC.
4. **No business-type touches** — zero variables in `variables_touched_json` whose declaration is in P's `domain_types`.
5. **No commit scope participation** — block not inside any `commit_scope` row of P.
6. **Generic-op density > 0.8** — ratio of `(MVC|MVI|MVZ|CLC|CLI|L|LA|ST|N|O|X|AR|SR|LR)` (ASM) or `(=, ==, +, -, memcpy, memset, strcpy)` (C++) to total instructions/statements.
7. **High fan-in** — block called from ≥ 5 distinct `(process, block)` callers codebase-wide.
8. **Pure / side-effect-free** — no global write, no ECB field write, no static/class-member write, no out-param write. Determined by `passes/data_flow_tracker.py`.
9. **Cross-process generic** — block reached by ≥ 3 *unrelated* processes (no shared `domain_types`).
10. **No control-flow influence on persistence** — this block's outputs never feed a guard that gates a persistence op in P's walk.

All 10 hold → `utility_confidence = 1.0`.

**Additional file-level hard rules (apply at file scope, not per-block):**

11. **ASM DSECT-only file** — file has ≥ 1 `DSECT` statement and zero `CSECT`/`RSECT`/`START` statements → `utility_confidence = 1.0`. Detected structurally (no parsing of instruction body needed); confirmed by L0 DSECT-only signal.
12. **Pure abstract base class (C++)** — C++ class/struct where every declared method is `= 0` (pure virtual), zero non-virtual, non-static member functions with a body → `utility_confidence = 1.0`. Detected via `cpp_call_chain/index_builder.py` class shape.
13. **Declaration-only header (C++)** — `.h`/`.hpp` file with zero function **definitions** (only declarations, typedefs, enums, constants, `extern` declarations) → `utility_confidence = 0.95`. Detected by checking that no function has a body `{...}` in the header; template headers with full definitions do NOT qualify.

##### Layer 2 — Naming heuristics (expanded patterns)

| Source | Patterns |
|---|---|
| File paths | `*util*`, `*helper*`, `*common*`, `*shared*`, `*lib*`, `*infra*`, `*support*`, `*base*`, `*aux*`, `*misc*`, `*tool*`, `*system*` |
| C++ namespaces / paths | `::detail`, `::internal`, `::impl`, `::__private`, `boost::*`, `std::*`, `IBM_*` runtime |
| ASM block / routine names | `*_CONV`, `*_FMT`, `*_PARSE`, `*_VALIDATE_GENERIC`, `*_HELPER`, `*_INIT`, `*_FINI`, `*_SAVE`, `*_RESTORE`, `*_TRACE`, `*_DEBUG`, `*_DUMP`, `*_PAD`, `*_PACK`, `*_UNPACK` |
| C++ method names | `get*`, `set*`, `has*`, `is*`, `to*` (only when body is trivial), `format*`, `parse*`, `convert*`, `validate_generic`, `init`, `dispose`, `cleanup` |
| Macro libraries | Any macro defined in a `*.mac` shared file |
| File-header comments | Containing `utility`, `helper`, `internal`, `library`, `common`, `infrastructure`, `auto-generated` |

→ `utility_confidence ∈ [0.7, 0.95]` (0.95 when path-token AND structural rules 1+2+3 also hold; 0.7 for name match alone).

##### Layer 3 — Cross-process generic (codebase-wide, deterministic)

Built from the `cross_process_call_index` table (populated once in
Phase 0, updated incrementally). A block is **cross-process generic**
if its set of distinct `caller_process` values has size ≥ 3 AND those
processes have **disjoint** `domain_types`.

`utility_confidence = 1.0` for any process that doesn't explicitly
mark it business via L5 override. This is the most reliable signal in
a 22k-file codebase — true infrastructure shows up everywhere.

##### Layer 3.5 — LLM verification (targeted, two triggers)

**ADDED 2026-05-28.** Runs as a separate bounded pass after L0-L3
complete, before Phase 3. Two independent triggers:

**Trigger A — L2-only classifications (confidence not yet 1.0):**

When the highest layer that fired for a `(file, block)` is L2
(naming heuristics, `utility_confidence ∈ [0.7, 0.95]`) and no
L0/L1/L3 rule achieved 1.0, the block is ambiguous. An LLM call is
made with:

**Retrieval-augmented few-shot (pgvector/SQLite):** Query `block_embedding` for
k=3 nearest blocks already labelled `utility_confidence ≥ 0.9` (known utility)
AND k=3 nearest blocks labelled `utility_confidence < 0.4` (known business).
These 6 examples are injected into the prompt with their labels to anchor
the LLM's judgment on this codebase's specific patterns.

```
File: <path>
Block label: <name>
Language: <ASM|C++>
Block body (≤ 80 lines, or summarised if longer):
<source>

Domain types for this process: <domain_types list>
Existing io_site rows for this block: <list or "none">

Similar blocks from this codebase (for reference):
[UTILITY] <block_a summary>
[UTILITY] <block_b summary>
[UTILITY] <block_c summary>
[BUSINESS] <block_d summary>
[BUSINESS] <block_e summary>
[BUSINESS] <block_f summary>

Question: Is this block utility/infrastructure (no business logic of
its own), or does it contain business-significant logic for the
process? Respond with one of: UTILITY | BUSINESS | UNCERTAIN.
If UTILITY or BUSINESS, explain in ≤ 2 sentences why.
```

Output mapping:
- `UTILITY` → `utility_confidence = 0.95`; `detection_layer = L3.5-llm-utility`
- `BUSINESS` → `utility_confidence = 0.1`; `detection_layer = L3.5-llm-business`
- `UNCERTAIN` → confidence unchanged; walk treats it as `[0.4, 0.7)` tier (walk 1 deeper)

**Trigger B — Safety-net: io_site rows on an L1/L3-classified utility block:**

If a block is classified `utility_confidence = 1.0` by L1 or L3
**but** Phase 1 later finds `io_site` rows for that block (can happen
when L1 rule 1 was evaluated before all macros were expanded), the
block is re-queued for an L3.5 LLM call with the io_site evidence
included. If LLM returns `BUSINESS`, the classification is
downgraded to `utility_confidence = 0.3`; the walk includes the
block and re-classifies it in Phase 3.

**Bounding cost:** L3.5 runs only on blocks where Trigger A or B
fires. At 22k-file scale, Trigger A targets < 15 % of blocks (those
that have no path signal, no structural signal, no cross-process
signal — only a name match). Trigger B is rare (macro expansion
ordering issue); expected < 1 % of classified blocks.

**Schema addition:**

```sql
ALTER TABLE block_utility_classification ADD COLUMN
  l35_trigger TEXT;  -- 'l2-ambiguous' | 'io-site-safety-net' | NULL
```

##### Layer 4 — LLM classification (folded into Phase 3 walk)

No separate LLM pass. The Phase 3 walk decision (§4.3) returns BOTH
the role classification AND the utility judgment in a single
structured response. Runs only on blocks the walk's frontier reaches
and that L0-L3.5 didn't decide.

##### Layer 5 — Manual override (always wins)

In `process.json` / `process_meta.json`:

```json
{
  "utility_overrides": {
    "force_utility":  ["temp/asm/some_file.asm",
                       "temp/asm/some_file.asm::BLOCK_X"],
    "force_business": ["temp/asm/business_lib.asm::CRITICAL_FN"]
  }
}
```

Overrides all other layers. Domain experts use this for cases where
auto-detection is provably wrong.

##### Walk treatment (4 tiers)

| `utility_confidence` | Walk behaviour | walk_node.status |
|---|---|---|
| `≥ 0.9` (L0 / L1 / L3 / L3.5-llm-utility hard) | Stop at the call edge; no recursion | `skipped-utility` |
| `[0.7, 0.9)` (L2 medium, L3.5 UNCERTAIN) | One-line LLM summary, no recursion | `skipped-utility-summarised` |
| `[0.4, 0.7)` (L3.5 UNCERTAIN → walk deeper, L4 mixed) | Walk 1 deeper, re-classify | `mixed-utility` |
| `< 0.4` (L3.5-llm-business or no utility signal) | Walk normally | regular status |

##### Domain types — how `process.domain_types` is populated

For L1 rules 4 and 9, each process needs a `domain_types` list. It
is derived automatically (union of derived signals) with optional
user override:

1. **Auto-derived** (default):
   - All `target_record` values from L1 `io_site` rows of the process
   - All DSECT / struct names appearing in `entry.inputs_declared` /
     `entry.outputs_declared`
   - All ECB-field names read or written by the entry block's
     read-before-write / write-before-exit sets
2. **User override** — `process.json` may include a `domain_types`
   list that adds to or replaces the auto-derived set.

##### Schema additions

```sql
CREATE TABLE block_utility_classification (
  process TEXT NOT NULL,
  file TEXT NOT NULL,
  block TEXT NOT NULL,
  utility_confidence REAL NOT NULL,
  detection_layer TEXT NOT NULL,    -- L0 / L1 / L2 / L3 / L3.5-llm-utility / L3.5-llm-business / L4 / override
  signals_json TEXT,
  llm_rationale TEXT,
  PRIMARY KEY (process, file, block)
);

CREATE TABLE cross_process_call_index (
  callee_file TEXT NOT NULL,
  callee_block TEXT NOT NULL,
  caller_process TEXT NOT NULL,
  caller_file TEXT NOT NULL,
  caller_block TEXT NOT NULL,
  PRIMARY KEY (callee_file, callee_block, caller_process, caller_file, caller_block)
);
```

##### Validation

- **L0 validator** — confirm path/build-system signal still holds when
  the file moves directory (re-run on file rename events).
- **L1 validator** — re-evaluate all 10 rules against the source;
  must still hold for the classification to remain `utility_confidence = 1.0`.
- **L2 validator** — confirm the naming pattern is still present in
  the file's path or block's label.
- **L3 validator** — re-query `cross_process_call_index`; if caller
  count dropped below 3 or processes now share domain_types, downgrade.
- **L3.5 validator** — for Trigger A: confirm the block's source body
  hasn't changed (content hash). For Trigger B: re-query `io_site`
  rows; if the io_site evidence that triggered it is no longer present,
  reinstate the L1/L3 classification.
- **L4 validator** — confirm the LLM's rationale matches at least one
  L1/L2 signal; quarantine if not.

##### Scalability notes (22k codebase)

- `cross_process_call_index` is the most expensive table — populated
  once per codebase-build, indexed on `(callee_file, callee_block)`.
- Generic-op density (rule 6) is per-block O(instructions), computed
  during block extraction.
- Fan-in (rule 7) is O(call_edges) — computed once after Phase 1.
- L4 LLM calls are bounded by the walk's frontier size, which is
  capped by `MAX_WALK_NODES`.
- Cache invalidation: each row carries a `content_hash` of the
  inputs that produced it; recomputation runs only when inputs change.

**Persistent-data operations (z/TPFDF macro family):**

| Op category | ASM macros | C functions |
|---|---|---|
| Open subfile (acquires SW00SR) | `DBOPN` | `dfopn*` |
| Close subfile | `DBCLS` | `dfcls` |
| Read LREC(s) | `DBRED` | `dfred*` |
| Add LREC(s) | `DBADD` | `dfadd*` |
| Delete LREC(s) | `DBDEL` | `dfdel*` |
| Replace LREC | `DBREP` | `dfrep*` |
| Mark current LREC modified | `DBMOD` | `dfmod`, `dfmod_all*` |
| Activate keys | `DBKEY`, `DBSETK` | `dfkey`, `df_setkey`, `df_nbrkeys` |
| Retain position | `DBRET` | `dfret` |
| z/TPFDF work space | `DBSPA` | `dfspa` |
| Checkpoint | `DBCKP` | `dfckp` |
| Interface block | `DBIFB` | `dfifb` |
| Exit-with-open-files | `DBCLR` | — |
| Address/reference | `DBADR` | `dfadr` |
| Copy subfile | `DBCPY` | `dfcpy` |
| Create subfile | `DBCRE` | `dfcre` |
| Index ops | `DBIDX`, `DBDIX` | `dfidx`, `dfdix` |
| Hold / unhold | `DBHOLD`, `DBUHLD` | `dfhold`, `dfuhld` |
| Merge / sort / restore | `DBMRG`, `DBSRT`, `DBRST` | `dfmrg`, `dfsrt`, `dfrst` |
| Other DB ops (T-list / unkey / etc.) | `DBTLD`, `DBTLG`, `DBTRD`, `DBUKY` | `dftld`, `dftlg`, `dftrd`, `dfuky` |

Layer 1 is **macro-family pattern matching, not a closed list**. Any macro
or function whose name matches the regex family `^DB[A-Z]{2,4}$` and is
backed by `passes/db_operation_extractor.py` → `macro_classifier.py` is
treated as a candidate. The classifier's catalog is the authoritative
mapping; new macros added to that catalog automatically flow through.

**Storage/file lifecycle operations (signal of resource ownership, not
persistence on its own but tracked because they bound DB ops):**

| Op category | ASM macros | C functions |
|---|---|---|
| Allocate working storage on ECB level | `GETCC` | `getcc` |
| Release working storage | `RELCC` | `relcc` |
| File-pool address allocation | `GETFC` | `getfc` |
| Release file-pool address | `RELFC` | `relfc` |
| Release both core + file | `RCRFC` | `tpf_rcrfc` |
| Detach / attach | `DETAC` / `ATTAC` (+ `_id`, `_ext` variants) | `detac*`, `attac*` |
| File/find + read with allocation | `FINDC`, `FINHC`, `FINWC`, `FIWHC` | `findc*`, `finhc*`, `finwc*`, `fiwhc*` |
| File (write) record | `FILEC` | (verification needed) |

Layer 1 also recognises:

**Transaction commit scope operations** (bound a unit of persistence):

| Op | ASM | C |
|---|---|---|
| Begin scope | `TXBGC` | `tx_begin` |
| Commit scope | `TXCMC` | `tx_commit` |
| Roll back scope | `TXRBC` | `tx_rollback` |
| Suspend | `TXSPC` | `tx_suspend_tpf` |
| Resume | `TXRSC` | `tx_resume_tpf` |

**Detection mechanism:**
1. Scan every ASM block's parsed instruction stream for macros whose
   `macro_classifier.py` row resolves to a `DBOperationType` or one of
   the storage/transaction categories above.
2. Scan every C++ block for calls to the C function names above. The
   C parser already recognises them via `passes/c_family_parser.py`.
3. For each match, emit a row to `io_site` (DB ops) or
   `storage_lifecycle` (GETCC/RELCC/DETAC/...) or `commit_scope`
   (TXBGC/TXCMC/...).

##### Layer 2 — Structural heuristics (deterministic, `confidence = 0.85`)

Layer 2 catches **custom wrapper macros / in-house DB helpers / enterprise
integration patterns** that the Layer 1 catalog doesn't directly know.
**All patterns below are configurable** via `heuristics.json` so new
codebases can add their own conventions without code changes.

| Rule | Signal |
|---|---|
| H1 — transitive macro | An ASM macro whose expanded body contains a Layer 1 op → the wrapper macro is itself a persistence touch |
| H2 — naming convention | Macro/function name matching `*_(WRITE|READ|PERSIST|STORE|LOAD|FETCH|SAVE|GET|PUT)_*` or `db_*` / `DAO_*` patterns |
| H3 — z/TPFDF context fields | A block that reads/writes `SW00SR`, `SW00REC`, `SW00WKA`, `SW01*` (key area), or `R3` while crossing a macro boundary — persistence context active |
| H4 — DB context REF= operand | An unknown macro invoked with a `REF=` operand that names a known subfile from the file inventory |
| H5 — C++ ORM/DAO patterns | C++ methods named `.save()`, `.insert()`, `.update()`, `.delete()`, `.persist()`, `.find()`, `.findBy*()` on objects whose type matches `*Repository*`, `*DAO*`, `*Dao*`, `*Manager*` |
| H6 — known C function patterns | C++ calls to `dfopn` / `dfred` / etc. wrapped via thin shims |
| H7 — file I/O on persistent paths | C++ `fopen` / `open` / `write` on paths matching `*.dat` / `*.idx` / persistence directories |
| H8 — JNI/native bridge | C++ calls into Java/JNI bridges that persist (e.g. via Spring Data) |
| H9 — protobuf / serialisation patterns | Calls to `*::SerializeToString` / `*::ParseFromArray` / `*::SerializeToOstream` near write sites (often persistence boundary) |
| H10 — queue / MQ patterns | Calls to `MQPUT` / `MQGET` (IBM MQ) or queue-publish patterns |
| H11 — internal framework patterns | Calls to in-house DAO / persistence framework methods (codebase-specific list in `heuristics.json`) |
| H12 — REST/RPC service writes | Calls to `*Service::send*` / `*Client::post*` / `*Stub::call*` / `*Stub::Invoke*` patterns |
| H13 — audit-channel loggers | Calls to logging APIs with channel names matching `audit.*` / `compliance.*` / `regulatory.*` — these are business audit trail, not noise |

`heuristics.json` schema:

```json
{
  "h2_naming_patterns": [...],     // regex list
  "h5_orm_method_names": [...],
  "h5_orm_class_patterns": [...],
  "h7_persistent_path_patterns": [...],
  "h11_internal_framework_patterns": [...],
  "h12_service_call_patterns": [...],
  "h13_audit_channel_patterns": [...]
}
```

##### Layer 3 — LLM classifier (probabilistic, `confidence ∈ [0.4, 0.95]`)

**Gate (LOCKED 2026-05-27):** L3 runs only on blocks satisfying ALL of:
- (a) Layer 1 + Layer 2 did not flag this block as I/O.
- (b) Block is on the Phase 3 walk's data path (status ∈ {data-path,
  validation, data-transformation, error-handling}).
- (c) Block contains at least one write-like instruction (MVC to a
  non-local address, STM to a global, callout to a non-utility file)
  OR at least one read that doesn't resolve to a known local.

**Per-process override** (via `process_meta`):

```json
{
  "io_detection": {
    "force_l3_on_blocks":  ["temp/asm/da78.asm::SUSPICIOUS_BLOCK"],
    "skip_l3":             false
  }
}
```

`force_l3_on_blocks` runs L3 even when the gate would otherwise skip
(use when bespoke persistence is suspected). `skip_l3 = true` disables
L3 entirely for cost-conscious runs.

At 22k scale, the default gate keeps L3 to ~50-200 calls per process.

**Retrieval-augmented few-shot (pgvector/SQLite):** Before calling the LLM, query
`chunk_embedding` for the k=5 nearest blocks (by cosine similarity of their
embeddings) that already have confirmed `io_site` rows in the current
knowledge base. These are injected into the prompt as labelled examples:
```
Similar blocks already classified as persistence sites:
Example 1: [block summary] → {op_type: DBWRT, target: LM1M1}
...
```
This grounds the LLM on codebase-specific patterns before it sees the
unknown block. The few-shot examples are retrieved cold (no process filter)
so cross-process patterns from the full knowledge base inform the call.

The LLM is prompted: "Given this block summary, its variables_touched,
outgoing calls, and the similar examples above, does it perform persistence?
If yes: what op_type, what target, what inputs, what outputs?"

LLM output: structured `IOSiteCandidate` with self-reported confidence.

##### Composition + validation

- Layer 1 runs first on every block (cheap, exhaustive).
- Layer 2 runs on Layer-1 misses with write-like signals.
- Layer 3 runs only after Phase 3 is complete (so we know which blocks
  are on the data path). Bounded to <20 LLM calls per process by the
  filter condition (c).

Each `io_site` row records `detection_layer`, `confidence`, `evidence`:
- L1: `evidence = {macro: "DBWRT", catalog_row: "macro_classifier:DBWRT"}`
- L2: `evidence = {rule: "H3", signal: "SW00REC write detected"}`
- L3: `evidence = {llm_rationale: "...", input_tokens: N}`

Validators (§14):
- **L1 validator** — re-open source at `(file, line)`, confirm macro name
  matches.
- **L2 validator** — re-confirm the structural signal.
- **L3 validator** — confirm at least one of: write to non-local
  address, call to a known persistence function, file/queue op. If none
  is found, downgrade to `confidence = 0` and mark `quarantined`.

##### Outputs

For each I/O site we record:

```
io_id:           unique id
file:            "temp/asm/da78.asm"
block:           "DA7_GLHIST"
op_type:         "DBWRT"
op_category:     "WRITE"    -- WRITE / READ / UPDATE / INSERT / DELETE /
                            -- HOLD / KEY-ACTIVATE / SCOPE-BEGIN / SCOPE-COMMIT /
                            -- STORAGE-ALLOC / STORAGE-RELEASE / etc.
target_record:   "LM1M1"
target_ref:      "IR73DF"   -- the REF= operand (DB context identifier)
key_operand:     "WK_REC_KEY"
keys_active:     [...]      -- snapshot of active DBKEY state at this line
hold_state:      "HOLD"     -- HOLD / NOHOLD / DETAC if known
prefetch:        false
commit_scope_id: 7          -- which scope this site is inside
storage_alloc:   "SW00WKA"  -- if writing via DBSPA-allocated space
source_line:     3847
detection_layer: "L1-hard"
confidence:      1.0
evidence:        "{...}"

inputs:   [WK_RRC, WK_REC_DATE, A7AFTERGLHIST]   -- variables flowing in
outputs:  [LM1RC, LM1STAT]                       -- variables read out
```

##### Why this is robust across IBM TPF/DF patterns

- We do **not** rely on a closed list of macros. The `macro_classifier`
  catalog grows as new macros are encountered, and Layer 2 catches
  wrappers we haven't catalogued.
- We follow the **IBM canonical lifecycle** (DBOPN → DBKEY → DBRED/...
  → DBMOD/... → DBCLS), so the persistence narrative aligns with
  IBM's mental model. The chat agent can answer "what's the DB lifecycle
  for this process?" by joining `io_site` rows by `target_ref`.
- We track **DBKEY state**: key activations affect the meaning of
  subsequent `DBRED` / `DBDEL` operations (keys persist across calls).
  See §9.3 below.
- We track **DETAC/ATTAC** ownership transfers separately from
  RELCC release.
- We track **commit scope membership** for every I/O site, so we
  can answer "what writes will be rolled back if this scope rolls
  back?" deterministically.

---

### 4.2 Phase 2 — Block-level baseline (LLM, parallel)

**Purpose:** keep what we already have. The existing block summaries are
the cheap context that Phase 3 reads when scoring relevance.

We **do not** rebuild block summaries. The ~800 we already have for C400
are reused. New blocks (if any) get summarised on demand.

The block summary schema gets a few new optional columns sourced from
Phase 1:

- `touches_persistence: bool` — any `io_site` row in this block with op_category in {WRITE, READ, UPDATE, INSERT, DELETE}
- `touches_storage_lifecycle: bool` — any `storage_lifecycle` row (GETCC/RELCC/DETAC/...)
- `inside_commit_scope: int | null` — `commit_scope_id` if the block is inside an active scope
- `incoming_guards: list[guard_id]` — guards that must be true to reach this block
- `outgoing_guards: list[guard_id]` — guards on calls leaving this block
- `is_callc_bridge: bool` — block contains a CALLC or CPROC declaration

These columns are filled deterministically — no LLM. They just lift Phase 1
facts onto the block row.

#### Business names — files and blocks

**Decision 2026-05-28.** Every file and every block in the walk gets a
2–5 word plain-English business name shown alongside the technical name
in all UI surfaces: `DA78.ASM (Account History Processor)`,
`DA7_VALIDATE (Date Validation)`.

**No-duplicate-LLM rule: block summary and business name are returned by a
SINGLE LLM call per block.** The Phase 2 block prompt is extended to return
a `business_name` field alongside `purpose` and `behavior`. This eliminates
a separate naming call per block.

Extended block summary prompt schema:
```json
{
  "purpose":       "one sentence business-language purpose",
  "behavior":      "2-4 sentences describing what the block does",
  "business_name": "2-5 word plain-English name (e.g. 'Date Validation', 'Account History Write')"
}
```

**File business names — parent codebase, wrap only:**
`llm/business_name.py::generate_business_name(summary: str) → str`
already exists and is production-ready. It takes a file's `business_summary`
and returns a short name. Call it once per file immediately after the file
summary LLM call completes (same `ThreadPoolExecutor` pass) — this IS a
separate call but is the one canonical call for file naming. Store in
`entity_business_name` with `entity_type='file'`.

**Block business names** are extracted from the combined block LLM call
result (no separate call). Stored in `entity_business_name` with
`entity_type='block'`.

**DB record business names** — e.g. `LM1M1` → `"Account History Record"`.
These are generated ONCE per unique `target_record` value found in `io_site`
rows during Phase 2, using a single LLM call per unique record name. Stored
in `entity_business_name` with `entity_type='record'`. Used by
`translate_to_business_language()` for macro/DB output substitution.

**Caching:** `entity_business_name.content_hash` = SHA-256 of the summary
input. On re-run, skip if hash matches — same pattern as all other
resumable rows.

---

### 4.3 Phase 3 — Top-down walk + relevance (LLM, sequential, bounded)

**Purpose:** decide which blocks are on the process's data path versus
plumbing. Skip the plumbing in subsequent phases.

**Inputs:**
- Process entry point (declared in process metadata — see §7).
- Phase 1: truncated file graph + block flow + I/O sites + storage
  lifecycle + commit scopes + utility tags.
- Phase 2: block summaries.

**Inputs from process_meta:**
Phase 3 reads `process_meta.entry_json` (from the `process_meta` table, §17
decision #11) to find the entry point(s). If `process_meta` has no row for
this process, it falls back to the first block of the seed file in
`file_graph.json`. It also reads `process_meta.limits_json` for `MAX_WALK_NODES`
and `MAX_DEPTH` overrides.

**Phase 3 reads `block_utility_classification` (not `utility_detector_v2` directly):**
The `block_utility_classification` table (populated by Phase 1c) is the
authoritative source for utility status. Phase 3 queries:
```sql
SELECT utility_confidence FROM block_utility_classification
WHERE process=? AND file=? AND block=?
```
A block is `skipped-utility` if `utility_confidence >= 0.9`. This avoids
re-running the 7-layer detector at walk time and ensures consistent results.

**Algorithm:**

```
queue   = [(entry_file, entry_block, context={"role": "process-entry"})]
visited = {}
walk    = []

while queue and len(walk) < MAX_WALK_NODES:
    (file, block, ctx) = queue.popleft()
    if (file, block) in visited:    continue
    visited.add((file, block))

    # Hard filters — read from block_utility_classification table
    uc = query_utility_confidence(process, file, block)  # 0.0 if no row
    if uc >= 0.9:
        walk.append({file, block, status: "skipped-utility", ctx})
        continue
    if block contains a Layer-1 I/O site:
        # Persistence sites are ALWAYS kept regardless of LLM judgment.
        force_keep = True

    summary   = block_summary(file, block)             # Phase 2
    children  = outgoing_calls(file, block)            # Phase 1 — every
                                                       # call_edge from this
                                                       # block, language-agnostic
    io_sites  = io_sites_for_block(file, block)        # Phase 1
    storage   = storage_lifecycle_for_block(file, block)
    scope     = commit_scope_for_block(file, block)

    # Single LLM call per surviving block
    decision = call_llm_model(
        ProcessWalkDecision,
        prompt=...,
        system_prompt=...,
    )

    walk.append({
        file, block,
        status: decision.role if not force_keep else "persistence-write",
        inputs_consumed: decision.inputs_consumed,
        outputs_produced: decision.outputs_produced,
        transformations: decision.transformations,
        commit_scope_id: scope,
        ctx,
    })

    # Only descend into children the LLM marks relevant
    # (or force-kept persistence sites)
    for child in decision.relevant_children:
        queue.append((child.file, child.block,
                      ctx + {child.condition_to_reach,
                             decision.outputs_produced}))
```

**Status values** (multi-label is allowed but one primary):

- `process-entry` — root node
- `data-path` — performs computation that contributes to an output
- `validation` — checks input correctness
- `data-transformation` — derives an intermediate from inputs
- `persistence-read` — block contains a Layer-1 READ I/O site
- `persistence-write` — block contains a Layer-1 WRITE/UPDATE/INSERT/DELETE I/O site
- `error-handling` — runs on the error/rejection path
- `logging` — emits a log/trace but doesn't affect data
- `infrastructure` — control-flow plumbing
- `skipped-utility` — block in a utility-classified file
- `async-spawn` — block contains `CREEC` / `CREMC` / `credc` / etc.
- `cross-language-bridge` — block contains `CALLC` / `CPROC` / `CALL_ALIAS`
- `scope-boundary` — block contains `TXBGC` / `TXCMC` / `TXRBC`
- `revisited-in-context-X` — reached again via a different parent

**Safety caps (LOCKED 2026-05-27):**
- `MAX_WALK_NODES` — default 1500, per-process override via `process.limits.max_walk_nodes`
- `MAX_DEPTH` — default 10, per-process override via `process.limits.max_walk_depth`
- Cycle detection on `(file, block)` per context
- Every truncation event writes a row to `walk_truncation` log and is surfaced in the UI (e.g. "walk hit cap at 1500 nodes; X output-producing blocks possibly missed — raise `process.limits.max_walk_nodes` to see more")

**Why this scales to 3 000+ node graphs:**
1. `utility_detector_v2` hard-rules layer eliminates most files before
   the LLM sees them.
2. Only blocks the LLM declares relevant extend the frontier.
3. Each LLM call is small (one block + outgoing calls + short running context).
4. Persistence sites are force-kept so we never miss an output, even if
   the LLM mis-classifies.

**Error-handling tag:**
We do **not** discard error-handling paths. They get tagged
`error-handling` and stored in the walk. Chat queries about "what
happens on error?" hit them.

---

### 4.4 Phase 4 — Variable context extraction + classification (LLM, parallel)

**REVISED 2026-05-28 — replaces unbounded BFS footprint.**

**Purpose:** for **every** variable in the process, produce:
- A **1-level-up / 1-level-down context snapshot** — all semantic information reachable in exactly one call-graph hop in each direction from every block that touches the variable (declaration file for declared variables; all process files for block-ref variables), covering all cross-language patterns.
- Six structured information categories extracted by LLM from that snapshot.
- A **classification label** (17 multi-labels).
- A **one-line business meaning**.

This phase runs for **all** variables — both formal `variable_universe`
entries and `block-ref` variables. No pre-filtering.

**Rationale for change:** the prior unbounded BFS (MAX_FOOTPRINT_DEPTH=8,
MAX_FOOTPRINT_NODES=500) produced exhaustive `(file, block)` coverage but
the marginal information beyond 1 hop was low — variables that matter
cross boundaries only once or twice in practice. The 1-level-up/1-level-down
approach captures purpose, conditions, validations, and business flow
context at a fraction of the traversal cost, with no depth cap needed.

---

#### 4.4a — 1-Level Context Extraction (deterministic collection → single LLM call)

Three steps, executed in order, all deterministic except the final LLM call.

---

##### Step 1 — Anchor scan (all touching blocks, no hop limit)

The anchor set differs by variable kind:

- **Declared variable** (`variable_universe` entry with a known `declaration_file`): find every block in the **declaration file** that references the variable via `variables_touched_json` from the `variable_lineage_builder` pass.
- **Block-ref variable** (no formal declaration in this process — may be declared in another process or be an external data structure): scan **all files in the process** for blocks where `variables_touched_json` references this variable name (or any alias in `variable_alias`). Every such block becomes an anchor block. Because there is no single home file, the 1-level-up/1-level-down hops in Steps 2 and 3 are applied to each anchor block independently.

For each anchor block collect:

| What to collect | Source |
|---|---|
| Read / write / read-write role | `variables_touched_json.role` |
| Guards the variable is an operand of | `guard` table WHERE expression references variable name or any alias from `variable_alias` |
| I/O operations involving the variable | `io_site` rows WHERE variable appears as `key_var`, or in `inputs_json` / `outputs_json` |
| Commit-scope context | `commit_scope` rows whose `(begin_file, begin_block)` → `(end_file, end_block)` span covers this anchor block |
| Storage lifecycle events | `storage_lifecycle` rows WHERE `pointer_register` or variable name is this variable |
| Conditional flows the variable gates | `call_edge_guard` rows WHERE guard expression references this variable (i.e. the variable's value determines which callee is called) |

---

##### Step 2 — 1 Level DOWN (callees — what happens to the variable after it leaves this file)

For each outgoing `call_edge` from an anchor block, check whether the
variable **actually flows** across the edge using the pattern-matched
detector. If it does, read the first relevant block of the callee and
collect information about what happens to the variable there.

**Cross-language patterns — all 8 downward patterns covered:**

| Edge pattern | How variable flows across | Detector |
|---|---|---|
| ASM → ASM via ENTRC / ENTNC / ENTDC | Caller loads variable into a register before the call; callee reads that register before writing it | `find_connected_variables.py` → `call_boundary_registers` to confirm the register is passed; then `map_connected_variables.py` → `call_boundary_register` mapping to resolve the **variable name in the callee** (`to_var`, `to_evidence`). Confidence + evidence stored in `down_contexts_json`. |
| ASM → ASM via BAL / BAS / BASSM | Same register convention; also shared DSECT field or shared memory field | `find_connected_variables.py` → `shared_dsects`, `shared_memory_fields`; `map_connected_variables.py` → `shared_memory_field` mapping for named variable resolution; `instruction_classifier.py` MODE_TRANSITION |
| **ASM → ASM (return value received from callee)** | Variable is assigned from the register that the callee sets before `BR R14`/`BACKC` (i.e. the anchor block contains an assignment from a return register immediately after an ENTRC call returns) | `find_connected_variables.py` → `return_registers` to identify which register the callee sets as return value; `map_connected_variables.py` → `return_register` mapping to resolve the callee-side variable name (`from_var` in callee file) and what computation produced it. This captures: "variable X in file_A received value computed as Y in file_B." |
| ASM → ASM via async spawn (CREEC / CREMC / CREDC / CREXC / CRETC) | Variable is in ECB payload passed to spawned process | `file_call_graph.py` async_spawn edges + `passes/ecb_alias_table.py` |
| ASM → ASM via ISC / macro wrapper (SWISC / FUNCTION macro) | Variable in ECB or register at dispatch point | `file_call_graph.py` |
| ASM → C++ via CALLC / CPROC | Positional CALLC argument maps to CPROC-declared parameter by position | `cross_file_bridge.py` + IBM CPROC/CALLC pattern (`docs/ibm/patterns/asm-c-interoperability.md`) |
| ASM → C++ via ENTxC (ENTNC / ENTDC / ENTRC) | ECB field or register passed to C++ entry point; resolved via ECB alias table | `cross_file_bridge.py`, `passes/ecb_alias_table.py` |
| C++ → ASM via CALL_ALIAS / direct call | Parameter maps to register / ECB field in ASM callee; alias edges used | `cross_file_bridge.py`, `cpp_call_chain/traversal.py`, `fixes/phase4_cross_language_alias_edges/` |
| C++ → C++ via function call / method / virtual / lambda / template | Standard argument passing; virtual targets resolved via CHA; indirect via envelope (commit `0f6d46a`) | `cpp_call_chain/traversal.py`, `cpp_call_chain/index_builder.py` |

**For each 1-level-down hop that fires, collect from the callee's first relevant block:**

| Information category | What to collect |
|---|---|
| **What is happening** | All operations on the variable in the callee block: read / write / DB op / passed-through |
| **Conditions it participates in** | All guards in the callee block where this variable (or its callee alias) is an operand — the 26 guard kinds apply |
| **Business validations** | Null / zero / range / key-active / error-flag checks the callee performs on the variable; classify as mandatory (on the data-path walk_node) or optional (on error-handling / validation walk_node) using Phase 3 `walk_node.block_tag` |
| **Which flows are invoked** | Branch targets in the callee that are gated by this variable's value (`call_edge_guard` rows in callee) |
| **Downstream I/O** | `io_site` rows in the callee block WHERE variable (or its callee alias) appears as key or data operand |
| **Checks triggered** | Any guard in the callee whose outcome routes to a persistence-write or process-output block |

---

##### Step 3 — 1 Level UP (callers — where the variable comes from and under what conditions)

For each incoming `call_edge` into any file that contains an anchor block,
read the call-site block in the caller and collect how the variable is
prepared and under what conditions. For block-ref variables this may span
multiple anchor files; apply the same logic to each.

**Cross-language patterns — all 8 upward patterns covered:**

| Edge pattern | How variable flows from caller | Detector |
|---|---|---|
| ASM ← ASM (caller BAL / BAS / ENTRC — argument passing) | Caller loads variable into a register immediately before the call instruction | `call_edge` table → source block; `find_connected_variables.py` → `call_boundary_registers`; `map_connected_variables.py` → `call_boundary_register` mapping to get the **caller-side variable name** (`from_var`, `from_evidence`) — i.e. "this variable in the callee was originally `WK_RRC` in the caller." `find_variable_modifiers.py` for the exact register-load instruction line. |
| ASM ← ASM (shared DSECT / global field) | Caller sets a DSECT field or global that is aliased to the variable in the callee | `find_connected_variables.py` → `shared_dsects`; `map_connected_variables.py` → `shared_memory_field` mapping; `passes/global_lineage_stitcher.py` |
| ASM ← ASM (ECB field set before call) | Caller writes an ECB field; callee reads the aliased ASM field | `passes/ecb_alias_table.py`, `fixes/phase6_ecb_mapping/` |
| **ASM ← ASM (return value delivered to caller — UP perspective)** | Variable in the callee is written before `BR R14`/`BACKC` and read by the caller's call-site block as the returned value; this UP hop shows the callee variable's provenance from the caller's point of view | `find_connected_variables.py` → `return_registers` (confirm this variable is indeed placed in a return register); `map_connected_variables.py` → `return_register` mapping to resolve how the caller uses the returned value (`to_var` in caller file, conditions under which the caller acts on it). The UP perspective answers: "under what conditions does the caller use what I return?" |
| ASM ← C++ (C++ CALL_ALIAS → ASM declaration file) | C++ sets the parameter or ECB field before the call; variable arrives as that value | `cross_file_bridge.py`, `passes/ecb_alias_table.py` |
| C++ ← ASM (ASM CALLC → C++ declaration file) | ASM loads CALLC positional args before call; variable is one of those args | `cross_file_bridge.py` + IBM CPROC/CALLC pattern |
| C++ ← C++ (direct call / method call) | Calling C++ function passes variable as argument; collect how the argument is computed | `cpp_call_chain/traversal.py`, `call_edge` table |
| C++ ← C++ (virtual / indirect caller) | Virtual or function-pointer caller; target resolved via CHA / indirect-call envelope | `cpp_call_chain/traversal.py`, commit `0f6d46a` |
| C++ ← C++ (constructor / initializer / template) | Variable initialized in the constructor call or template instantiation site | `cpp_call_chain/index_builder.py`, `cpp_call_chain/traversal.py` |

**For each 1-level-up hop, collect from the caller's call-site block:**

| Information category | What to collect |
|---|---|
| **Conditions for its setting** | All guards in the caller block that must be true for the variable to be assigned its value before the call — e.g. `AIF (COND).SET_VAR` before `BAL` |
| **How the variable is set** | The specific assignment instruction in the caller: register load (`L`, `LR`, `MVC`), struct field write, C++ assignment expression |
| **Mandatory vs optional path** | Is the call-site block on a `data-path` / `persistence-write` walk_node (mandatory) or `error-handling` / `validation` walk_node (optional)? Sourced from Phase 3 `walk_node.block_tag` |
| **Business context of the call** | What business operation in the caller triggers this call — e.g. "after reading customer record, calls validation routine with result code" |
| **Flow context** | Which branch / path in the caller leads to this call being made — the guard stack from Phase 3 walk_edge rows leading to this call-site |

---

##### Step 4 — LLM synthesis (single prompt per variable, parallel, ThreadPoolExecutor(8))

After Steps 1–3 complete deterministically, one LLM call receives the
aggregated anchor + down + up context and answers **six questions** about
the variable. These are the exact questions a human analyst would ask when
encountering a variable for the first time.

#### The 6 questions answered (and what feeds each)

| Q | Question | Primary data source | Can be partial / not found at 1-depth? |
|---|---|---|---|
| **Q1** | What is the purpose of this variable and why is it important? | `anchor_blocks_json` (role + guards) + `down_contexts_json.what_happens` + classification label | Rarely null — anchor scan always finds the declaration file. May be shallow if the variable only appears in utility blocks. |
| **Q2** | How is it computed, and from which input or source? | `up_contexts_json.how_set` + `up_contexts_json.conditions_for_setting` + `map_connected_variables.py` return-register mapping | **Partial when 1 level isn't enough** — e.g. a variable that is itself computed from a value returned from a callee two hops up. Reported as "source not resolved at 1-depth." |
| **Q3** | Is it always available, or only populated under conditional logic? | `up_contexts_json.conditions_for_setting` + guard rows at anchor blocks (Step 1) + mandatory/optional classification from `walk_node.block_tag` | Generally answerable; may be "not determined" if no caller context exists (entry-point variable with no up-hop). |
| **Q4** | What updates happen in the persistence layer (DB, PMF)? | `anchor_blocks_json.io_ops` (direct io_site at anchor) + `down_contexts_json.io_ops` (1-level-down callee io_site where variable is key or payload) | **Only captures direct + 1-hop.** Deeper persistence effects (variable flows 2+ hops then gets written) are not captured. Reported as "persistence effects visible at 1-depth only." |
| **Q5** | Are there flow variations based on product, status, partner, or condition? | `flows_invoked_json` (branch targets gated by this variable at anchor and 1-hop callee) + `conditions_json` (guard expressions the variable is operand of) | **1-depth only.** If the variable's value causes branching 2 hops away, that branch is not visible here. Partial coverage flagged in `coverage.flow_variations`. |
| **Q6** | What is the business flow where this variable is used? | Phase 3 `walk_node.block_tag` for each anchor block + `down_contexts_json.flow_context` (which named flow the callee belongs to) + Phase 5 flow enumeration reference | Generally answerable; richer after Phase 5 flow names are available. |

**Honest limitation across all questions:** the analysis goes exactly 1 hop
in each direction. For most variables this is sufficient context. For deeply
computed or broadly propagated variables, some answers will be partial. The
output explicitly records this via a `coverage` object so the UI and chat
agent can surface "this answer is based on 1-depth context only" where relevant.

#### Step 4 LLM output

```json
{
  "purpose":               "plain-English: what this variable represents and why it matters to the process",
  "computation_source":    "how and from what input/register/field this variable gets its value; null if not resolvable at 1 caller depth",
  "availability":          "always | conditional | entry-point-only | not-determined",
  "availability_condition":"guard expression or business condition under which the variable is populated; null if always-available",
  "persistence_effects":   [{"op": "DBWRT|DBRED|PMF|...", "target": "record name", "role": "key|payload", "mandatory": true, "depth": "anchor|1-down"}],
  "flow_variations":       [{"condition": "guard or value that triggers the branch", "branch": "what happens in that flow path"}],
  "business_flow_context": "which named flow(s) this variable participates in and what role it plays in the end-to-end story",
  "coverage": {
    "purpose":             "full | partial | not_found",
    "computation_source":  "full | partial | not_found",
    "availability":        "full | partial | not_found",
    "persistence_effects": "full | partial | not_found",
    "flow_variations":     "full | partial | not_found",
    "business_flow_context":"full | partial | not_found"
  }
}
```

`coverage` is populated by the LLM itself, instructed to be honest about
what it could not resolve with the 1-depth data provided. `"partial"` means
the answer is directionally correct but incomplete (e.g. one persistence
target found, deeper ones may exist). `"not_found"` means the 1-depth
context contains no signal for that question.

Content-hash covers: variable name + declaration_file + declaration_line +
anchor_blocks_json + down_contexts_json + up_contexts_json + template_version.
Unchanged variables are skipped on re-run.

**Output: `variable_context` table** (replaces old `variable_footprint`):

```sql
CREATE TABLE variable_context (
    process                  TEXT NOT NULL,
    name                     TEXT NOT NULL,
    declaration_file         TEXT NOT NULL,
    declaration_line         INTEGER NOT NULL,
    -- Step 1
    anchor_blocks_json       TEXT,  -- [{block_id, role, guards, io_ops, commit_scope, storage_lifecycle}]
    -- Step 2 (1 level down)
    down_contexts_json       TEXT,  -- [{edge_type, lang_pair, callee_file, callee_block,
                                    --   what_happens, conditions, io_ops, flows, checks, mandatory}]
    -- Step 3 (1 level up)
    up_contexts_json         TEXT,  -- [{edge_type, lang_pair, caller_file, caller_block,
                                    --   how_set, conditions_for_setting, mandatory,
                                    --   business_context, flow_context}]
    -- Step 4 LLM output (6-question framework)
    purpose                  TEXT,
    computation_source       TEXT,
    availability             TEXT,  -- always | conditional | entry-point-only | not-determined
    availability_condition   TEXT,
    persistence_effects_json TEXT,  -- [{op, target, role, mandatory, depth}]
    flow_variations_json     TEXT,  -- [{condition, branch}]
    business_flow_context    TEXT,
    coverage_json            TEXT,  -- {purpose, computation_source, availability,
                                    --  persistence_effects, flow_variations, business_flow_context}
    content_hash             TEXT,
    PRIMARY KEY (process, name, declaration_file, declaration_line)
);
```

No depth cap is needed — the extraction is exactly 1 hop in each direction.
The only bound is the number of call-edges in/out of the anchor blocks,
which is already computed and finite from Phase 1.

---

#### 4.4b — Classification (LLM per variable, parallel)

For each variable, inputs to the classifier (updated for 1-level context):
- Declaration metadata (kind: dsect_field / register / global / equate /
  literal / cpp-local / cpp-class-member / cpp-global / ecb-field / etc.)
- Anchor-block role distribution (read / write / read-write counts from `variable_context.anchor_blocks_json`)
- I/O involvement (does it appear in any `io_site` row? as key, input, or output?)
- Process input/output binding (does it match an entry block's read-before-write registers/parameters or exit-write?)
- Guard involvement (does it appear in any guard expression in anchor or 1-hop blocks?)
- Storage lifecycle involvement (allocated via GETCC? released via RELCC?)
- Commit-scope involvement (used inside a TX scope?)
- 1-level-down context (does a callee perform a DB op with this variable?)
- 1-level-up context (is this variable set only under a specific business condition in the caller?)

**Labels** (REVISED 2026-05-28 — 5 categories, multi-label; variable can hold multiple):

| Label | What it covers | Deterministic signal | LLM role |
|---|---|---|---|
| `business` | Directly implements business function: transforms or gates domain data (amounts, dates, record content, business flags, audit records) | Affects a guard gating a process-output or persistence-output; appears in `io_site_variable` for an audit-record target | confirm via reasoning |
| `process-io` | Crosses a process boundary: inputs at entry, outputs at exit, cross-process payloads (CREEC/CREMC/queue/SWISC handoffs) | Bound to entry block's read-before-write registers/parameters OR written before exit/return register OR appears in async_spawn edge payload | confirm |
| `persistence` | Interfaces with stored data: DB record fields read/written, key operands (DBKEY/dfkey state), DB context bags (SW00SR slot, `REF=`, `dft_fil*`), transaction-scoped state | Appears in `io_site` (any role) OR in `io_site` keys_active snapshot OR `variable_context.anchor_blocks_json` has commit_scope_id set | confirm |
| `control` | Directs execution flow without being primary business data: validation flags, enum constants gating branches, intermediate results, loop counters | No 1-level-down hop fires AND not on path to a process-output/persistence-output OR kind=equate/literal with no write-backs | confirm |
| `infrastructure` | Pure technical plumbing with no business meaning: register saves, ECB context bags passed opaquely, pointer aliases, storage pointers (GETCC handles), utility/library variables | All anchor blocks in utility files OR kind=register AND role=infrastructure in `instruction_classifier` OR purely an alias in `data_flow_tracker` | from deterministic signals; LLM confirms edge cases |

**Mapping from prior 17-label taxonomy (absorbed into 5):**

| Old label | → New label |
|---|---|
| `business`, `audit-trail` | → `business` |
| `process-input`, `process-output`, `cross-process-input`, `cross-process-output` | → `process-io` |
| `persistence-input`, `persistence-output`, `db-context`, `key-state`, `transaction-scoped` | → `persistence` |
| `intermediate`, `enum-value` | → `control` |
| `infrastructure`, `utility`, `ecb-context`, `pointer-alias` | → `infrastructure` |

**Boolean flags (in addition to labels):**
- `is_unused` — declared but never read in this process. Derived deterministically from `variable_context.anchor_blocks_json` (all roles are `write` only, zero `read` or `read-write` rows) plus no 1-level-down hop fires.

**Retrieval-augmented few-shot (pgvector/SQLite):** Before the LLM call, query
`variable_context_embedding` for k=5 nearest already-classified variables
(across all processes in the knowledge base). Inject their `purpose` +
`business_flow_context` text + classification labels as examples in the
prompt. This is especially useful for unusual variable patterns (ECB context
bags, pointer aliases, async payload variables) where the deterministic
rules return low-confidence signals.

```
Similar variables already classified (examples for your reference):
[business, persistence] WK_RRC: "carries account number loaded from
  DBRED; passed to the validation routine before the DBWRT"
[infrastructure] CE1CR0: "ECB base register used as address anchor across
  all calls; never gates any business decision"
[process-io] WA1_TYPE: "transaction type received at process entry;
  drives dispatch logic"
...
```

LLM call: produces multi-label list + one-line business meaning +
confidence flag. Persisted in `variable_classification`.

---

### 4.5 Phase 5 — Process synthesis (LLM, sequential)

**Purpose:** with phases 1–4 complete, generate the artifacts the UI and
chat need.

#### Artifacts produced

1. **Input spec** — explicit list of process inputs.
2. **Output spec** — explicit list of process outputs.
3. **Flow enumeration** — distinct paths from entry to each output.
4. **Persistence summary** — what gets persisted, when, conditionally.
5. **Commit-scope summary** — what scopes exist and what they bound (process-level).
6. **Per-scope narrative** *(Decision 2026-05-28)* — for each `commit_scope` row,
   one LLM call that produces: (a) a plain-English narrative of what business
   outcome this transaction achieves, and (b) a ranked list of the key variables
   inside the scope — their role (input / output / intermediate) and significance.
   Stored in `commit_scope_narrative` table (see §11). Each scope = 1 LLM call,
   parallel across scopes.
7. **Process-level business-language narrative** *(Decision 2026-05-28)* —
   a structured, multi-section document assembled from targeted LLM calls,
   NOT one monolithic call. See §4.5.1 for full detail.
8. **Payload lineage chains** *(Decision 2026-05-28)* — for each `process-io`
   input variable, a forward trace through the flow showing how it transforms
   step-by-step into a final output. Graph traversal over Phase 3 data +
   Phase 1 cross-boundary mappings + Phase 4 classification; LLM confirmation
   for ambiguous variable identity cases. See §4.5.2.
9. **Process walkthrough — card-paginated business-language description**
   *(Decision 2026-05-28)* — a complete, execution-ordered walkthrough of
   the entire process: every walked block, every condition, every variable,
   every I/O event translated into plain business language with **zero
   technical names**. Output is split into ~50-100 cards for C400 (more for
   larger processes), each card 3-8 sentences with its own visualization
   payload. Stored in `process_narrative_card` table. See §4.5.3 for full
   design.

#### Per-scope narrative — LLM prompt inputs

For each `commit_scope` row the LLM receives:

- The scope bounds: begin file/block/line, end file/block/line, `end_kind`
  (commit / rollback / unclosed).
- All `io_site` rows nested inside the scope (op_type, op_category,
  target_record, key_operand, hold_state).
- All variables touched via `io_site_variable` within this scope, joined with
  their `variable_classification` labels and `variable_meaning.meaning`.
- Walk-node summaries (Phase 2 block purpose + Phase 3 role) for every block
  whose `commit_scope_id` matches this scope.

LLM output schema (two fields):

```json
{
  "narrative": "string — plain-English: what business outcome this TX achieves,
                what happens on commit vs. rollback",
  "key_variables": [
    {
      "name": "string",
      "role": "input | output | intermediate | key",
      "significance": "string — one sentence on why this variable matters to the TX"
    }
  ]
}
```

Variables are ranked by significance (business > persistence > intermediate).
Top-5 surfaced in the UI; full list stored in JSON.

#### Flow enumeration — completeness guarantees

A **flow** = a path through the walk tree from entry to a node that
produces an output, with every step's analysis attached.

**Output set enumeration (deterministic, exhaustive):**

```
all_outputs(P) =
   process_return_outputs(P)         # registers/return values written before exit
 ∪ ecb_global_outputs(P)             # ECB fields / globals written + read by caller
 ∪ persistence_outputs(P)            # io_site WHERE op_category ∈
                                     #   {WRITE, UPDATE, INSERT, DELETE}
 ∪ persistence_read_outputs(P)       # io_site WHERE op_category ∈ {READ, GET}
                                     #   AND record fields read downstream
 ∪ async_outputs(P)                  # walk_node WHERE call_type IN async_spawn family
 ∪ queue_message_outputs(P)          # io_site for queue/message ops
 ∪ error_outputs(P)                  # persistence writes reachable only via
                                     #   error-handling walk status
 ∪ scope_commit_outputs(P)           # TXCMC sites with DB ops in scope
 ∪ storage_handoff_outputs(P)        # DETAC sites where storage is handed off
```

No LLM judgment in selecting outputs — they're a deterministic union.

**Producer search (exhaustive):**

For each output O, find every walk node that produces it. No pruning.

**Path-trace (exhaustive):**

For each producer node, trace back through `parent_walk_id` to entry. If
a producer has multiple parents (revisited-in-context-X), each parent
path becomes a separate flow.

**Attach analyses:**

For each step in the flow, attach Phase 2's block summary + Phase 3's
role, inputs_consumed, outputs_produced, transformations + Phase 4's
variable classifications + Phase 1's guard, I/O site, storage lifecycle,
commit scope rows.

**Children's analysis is INCLUDED, not linked:**

Phase 3 walks depth-first. When a flow reaches a producer node, all
descendants ON THE FLOW'S PATH are already analysed and rendered as part
of the flow's `path` array. Siblings outside the flow belong to a
different flow.

**Where coverage can honestly fail:**
- Walk truncated at `MAX_WALK_NODES`. Flows whose producer is past the
  cap are recorded as `truncated`.
- Walk's relevance LLM misclassified an output-producing block as
  `infrastructure`. Mitigation: persistence outputs are deterministic
  (from `io_site` table) and persistence-write blocks are force-kept in
  the walk.
- Conditional detector missed a guard. Mitigation: §15 audit items.

**Worked example — flow JSON shape:**

```json
{
  "flow_id": "C400::F1",
  "output": {
    "kind": "persistence-write",
    "target_record": "LM1M1",
    "io_site_id": "C400::da78.asm::DA7_GLHIST::3847"
  },
  "trigger_summary": "Transaction type = AFTERGL AND validation succeeded",
  "guards_along_path": [
    { "step": 2, "kind": "cmp-branch", "human": "transaction type is AFTERGL" },
    { "step": 4, "kind": "aif",        "human": "date is valid format" }
  ],
  "commit_scope": { "scope_id": 7, "begun_at_step": 1, "commits_at_step": 6 },
  "path": [
    { "step": 1, "file": "da78.asm", "block": "DA7",
      "role": "process-entry",
      "summary": "Receives transaction, looks up account history record",
      "inputs_consumed":  ["WA1_TYPE", "WA1_DATE", "R5 (acct)"],
      "outputs_produced": ["A7AFTERGLHIST"] },
    { "step": 2, "file": "da78.asm", "block": "DA7_DISPATCH",
      "role": "data-path",
      "summary": "Dispatches by transaction type; AFTERGL falls through here",
      "inputs_consumed":  ["WA1_TYPE"], "outputs_produced": [] },
    { "step": 3, "file": "da78.asm", "block": "DA7_VALIDATE",
      "role": "validation",
      "summary": "Validates date format; sets WK_VALID",
      "inputs_consumed":  ["WA1_DATE"], "outputs_produced": ["WK_VALID"] },
    { "step": 4, "file": "xh80.asm", "block": "XH80_BUILD_HIST",
      "role": "data-transformation",
      "summary": "Constructs new history record from prior + transaction",
      "inputs_consumed":  ["A7AFTERGLHIST (prior)", "WA1_DATE", "R5"],
      "outputs_produced": ["WK_NEW_RECORD"] },
    { "step": 5, "file": "da78.asm", "block": "DA7_GLHIST",
      "role": "persistence-write",
      "summary": "Writes new history record to LM1M1",
      "inputs_consumed":  ["WK_NEW_RECORD"],
      "io_site_id":       "C400::da78.asm::DA7_GLHIST::3847" }
  ],
  "children_analysis_included": true,
  "completeness": { "all_walk_children_visited": true, "truncated_at_node": null }
}
```

Each flow = 1 row in `process_flow` table + 1 LLM call for the narrative.

---

### 4.5.1 Process-level narrative — structure and generation strategy

**The problem:** the walk, variable context, flows, persistence, and
commit-scope data for a large process can span thousands of rows. A single
LLM call synthesising all of it would blow context limits and produce an
unfocused wall of text.

**The solution:** a **four-section structured document**, each section
generated by a separate targeted LLM call (or assembled deterministically
where possible). The API stitches sections together; the UI renders them as
a navigable document with collapsible sections.

#### Sections

| # | Section | Content | Generation |
|---|---|---|---|
| 1 | **Executive summary** | 3–5 sentences: what does this process do, what triggers it, what are its primary outputs | 1 LLM call; inputs = input spec + output spec + flow count + persistence overview |
| 2 | **End-to-end flow narrative** | Prose that traces the process from entry through every major path to every output; covers dispatch logic, guard conditions in plain English, what happens on each branch | 1 LLM call; inputs = walk tree (walk_node rows, statuses, parent chain) + all flow trigger_summaries + key guard condition_human values along each path |
| 3 | **Variable landscape** | Ranked list of the key `business` + `persistence` variables: what each one carries, how it moves through the process, what it gates | 1 LLM call; inputs = top-N `business`/`persistence` variables by anchor_block count + their `variable_meaning.meaning` + `variable_context` summaries |
| 4 | **Persistence & transaction footprint** | What gets stored, when, conditionally; commit scopes and their business outcomes | Assembled deterministically from `persistence-summary` artifact + per-scope narratives (§4.5); no extra LLM call |

**Total LLM calls for the narrative: 3** (sections 1, 2, 3). Section 4 is
free — already generated by Phase 5 artifacts 4, 5, 6.

**Pre-translation mandate for §4.5.1 narrative sections (component usage, added 2026-05-28):**
Sections 1–3 inputs are pre-translated via `translate_to_business_language(text, process)`
(the same function used by §4.5.3 Stage 2) before reaching any LLM call. This
ensures narrative prose generated by sections 1–3 is also technical-name-free.
The translation runs on: walk_node.file, walk_node.block, variable codes in
`inputs_consumed`/`outputs_produced`, macro names in io_site rows, guard expressions
in flow paths. Section 4 is assembled deterministically and inherits translated text
from sections 1–3 and per-scope narratives.

#### End-to-end flow narrative — prompt inputs

Section 2 is the most important and the one that must always include the
end-to-end journey. The LLM receives:

```
Entry point: <file, block, description>

Walk tree (compressed):
  [walk_id=1] process-entry  DA78::DA7
    [walk_id=2] data-path     DA78::DA7_DISPATCH    guard: "transaction type is AFTERGL"
      [walk_id=3] validation  DA78::DA7_VALIDATE    guard: "date is valid format"
        [walk_id=4] persistence-write  DA78::DA7_GLHIST
    [walk_id=5] error-handling DA78::DA7_ERR        guard: "date is invalid"

Flows to outputs:
  Flow F1: "AFTERGL valid → write history to LM1M1 and commit"
  Flow F2: "AFTERGL invalid date → write rejection to audit, rollback"

Key guard conditions along each path: [condition_human list]
```

LLM output: a coherent prose narrative, 300–800 words, that reads like
a technical spec describing the process from start to finish — covering
what triggers each branch, what data moves where, and how every path
concludes. Must explicitly name the entry point, every major dispatch,
and every output.

#### Storage

Each section is a separate row in `process_artifact`:

| `artifact_kind` | Content |
|---|---|
| `narrative-executive-summary` | Short prose (3–5 sentences) |
| `narrative-e2e-flows` | End-to-end flow prose (the main narrative) |
| `narrative-variable-landscape` | Variable landscape prose |
| `narrative-persistence-footprint` | Assembled from persistence-summary + scope narratives |

**`GET /processes/{P}/narrative`** returns all four sections as a JSON
object `{ executive_summary, e2e_flows, variable_landscape, persistence_footprint }`.
Each section is a string (prose). The UI renders them as a scrollable
document with collapsible panels per section.

#### UI surface

- **Process homepage card** — shows `narrative-executive-summary` only
  (3–5 sentences). "Read full summary →" link opens the full narrative page.
- **Full narrative page** (new route `/p/:P/narrative`) — four collapsible
  sections rendered as markdown prose. Section 2 (end-to-end flows) is
  expanded by default; others collapsed. Each section has a "copy" button.
  If the process is large, section 2 may be long — the UI paginates it by
  flow group if it exceeds a threshold (e.g. > 10 flows).

---

### 4.5.2 Payload lineage chains — multi-phase forward trace

**Concept:** for each `process-io` input variable, trace forward through
every flow it participates in, following how it transforms step-by-step
until it reaches a terminal output (persistence write, process return,
async spawn, ECB write).

**This is NOT purely deterministic.** The chain algorithm is a graph
traversal, but it depends on data from all prior phases:

| Input | Source | Deterministic? |
|---|---|---|
| `inputs_consumed` / `outputs_produced` per step | Phase 3 LLM walk | No — LLM-derived |
| Cross-call-boundary variable mappings | Phase 1 `map_connected_variables.py` | Yes |
| Root variable identification (`process-io`) | Phase 4 classification | Partly LLM |
| Terminal identification (persistence / return) | Phase 1 io_site + Phase 3 walk | Yes |
| Variable name consistency across steps | Phase 3 prompt discipline | Risky assumption |
| Ambiguous identity (same logical variable, different names) | LLM confirmation pass | No |

**Key limitation:** the Phase 3 LLM may use different names for the same
logical variable at different steps (e.g. `WA1_DATE` in step 1, `date_field`
in step 4). Deterministic string matching over `inputs_consumed` /
`outputs_produced` would silently break the chain. A lightweight LLM
confirmation pass is needed for ambiguous cases.

#### Algorithm

```
Step 1 — Root identification (Phase 4 output):
  V_roots = variables WHERE classification includes 'process-io'

Step 2 — Flow participation (Phase 3 output):
  for each V in V_roots:
    candidate_flows = flows WHERE V ∈ path[0].inputs_consumed

Step 3 — Within-flow chain traversal (deterministic given Phase 3 data):
  for each (V, flow F) in candidate_flows:
    active_vars = {V}
    steps = []
    for step in F.path:
      touched = active_vars ∩ step.inputs_consumed
      if touched:
        steps.append({step, file, block, role, vars_in=touched,
                       vars_out=step.outputs_produced, summary=step.summary})
        active_vars = (active_vars − touched) ∪ step.outputs_produced
    → draft lineage chain

Step 4 — Cross-boundary resolution (Phase 1 deterministic):
  For any step where the block is in a different file from the previous step,
  use map_connected_variables.py output to resolve variable identity across
  the call boundary. Replace register names (e.g. R5) with the callee's
  local variable name for the same value.

Step 5 — Variable identity confirmation (LLM, targeted):
  For any active_var where the name in step.inputs_consumed does not
  exactly match the name produced in a prior step.outputs_produced
  (fuzzy name, alias, or sub-field reference):
    ask LLM: "Is [name_in_consumer] the same logical value as
              [name_from_producer]? Context: [block summaries]"
  Binary yes/no — one call per ambiguous pair. Skip if exact match.

Step 6 — Terminal attachment (Phase 1 + Phase 3 output):
  Terminal = F.output: io_site for persistence-write, walk_node
  exit classification for process-return / async-spawn / ecb-write.
  Attach to lineage chain.
```

The LLM is only called in Step 5 — only for genuinely ambiguous name
pairs. Clean codebases with consistent naming may need zero LLM calls
for lineage; heavily aliased ASM codebases may need several.

#### Example — WA1_DATE through flow F1

```
WA1_DATE  [process-io, business]
  step 1 · DA78::DA7           (process-entry)
           in:  WA1_DATE
           out: A7AFTERGLHIST
           "Received at entry; date read from ECB"
  step 3 · DA78::DA7_VALIDATE  (validation)
           in:  WA1_DATE
           out: WK_VALID
           "Validates date format — gates the AFTERGL path"
  step 4 · XH80::XH80_BUILD_HIST (data-transformation)
           in:  WA1_DATE, A7AFTERGLHIST
           out: WK_NEW_RECORD
           "Incorporates validated date into new history record"
  step 5 · DA78::DA7_GLHIST    (persistence-write)
           in:  WK_NEW_RECORD
           out: —
           terminal: persistence-write → LM1M1
```

#### New table

```sql
CREATE TABLE payload_lineage (
  process          TEXT NOT NULL,
  lineage_id       TEXT PRIMARY KEY,   -- e.g. C400::WA1_DATE::F1
  root_variable    TEXT NOT NULL,      -- the process-io input variable
  flow_id          TEXT NOT NULL,      -- which flow this lineage belongs to
  steps_json       TEXT NOT NULL,      -- [{step_num, file, block, role,
                                       --   vars_in, vars_out, summary}]
  terminal_kind    TEXT NOT NULL,      -- persistence-write / process-return /
                                       -- async-spawn / ecb-write
  terminal_target  TEXT,               -- LM1M1, register name, etc.
  terminal_io_site_id TEXT,
  content_hash     TEXT NOT NULL
);
```

One row per (root_variable, flow). A variable that appears in 3 flows
produces 3 lineage rows.

#### Where consumed

| Consumer | Purpose |
|---|---|
| `GET /processes/{P}/payload-lineage` | All chains; filterable by `root_variable` or `terminal_target` |
| `GET /processes/{P}/variables/{V}/lineage` | All chains for one input variable across all flows |
| Chat tool `get_payload_lineage(P, V?)` | "How does WA1_DATE end up in LM1M1?" / "Show all data paths through C400" |
| **Payload flows tab** on narrative page | Step-list per chain; filterable by input or output; shows the full transformation journey |

---

### 4.5.3 Process walkthrough — card-paginated business-language description (ADDED 2026-05-28)

**Goal:** an exhaustive, execution-ordered, plain-business-language walkthrough
of the entire process — covering every walked block, every condition, every
key variable, every I/O event, every flow branch — with **zero technical
names** in the rendered text. Designed for non-technical readers (business
analysts, product managers, compliance) who need to understand exactly what
the process does step by step.

**Why this is separate from §4.5.1:**

| §4.5.1 narrative | §4.5.3 walkthrough |
|---|---|
| Topic-organized (4 sections: summary / e2e flow / variables / persistence) | Execution-ordered (linear, follows the walk) |
| High-level (page-long sections) | Granular (3-8 sentence cards) |
| Generated by ~3 LLM calls | Generated by ~50-100 LLM calls (one per segment) |
| Shown on `/p/:P/narrative` page | Shown on `/p/:P/walkthrough` page, paginated 2-cards-at-a-time |

They are **complementary**. The narrative answers "what does this process do, at a glance." The walkthrough answers "walk me through every single step."

---

#### Hard constraints driving the design

1. **Complete coverage** — every walked block (`walk_node` where `status != 'skipped-utility'`) must be covered by at least one card.
2. **Zero technical names** — the rendered text must never contain a file name, block name, macro name, register name, variable code, or DB record code. Only business equivalents.
3. **Each card is self-contained** — a reader can land on any card and understand what's happening at that point.
4. **Each card is visualizable** — a `Visualise` button opens a small call graph showing exactly the blocks/edges/variables this card describes.
5. **Linear connection** — the user always knows where they are in the walkthrough (which section, which card number, what the previous and next cards cover).

---

#### Generation pipeline — 4 stages

##### Stage 1 — Deterministic clustering of walk_nodes into "narrative segments"

Input: ordered list of `walk_node` rows for the process, in DFS traversal
order from the entry block.

A new segment **starts** whenever ANY of:

- `walk_node.block_tag` transitions (e.g., `data-path` → `validation` → `persistence-write`)
- `commit_scope_id` changes (entering / leaving a transaction)
- File boundary crossed by the immediately preceding `call_edge` (cross-file step)
- A `persistence-write` or `async-spawn` block is hit (gets its own segment for emphasis)
- A conditional branch with `call_edge_guard` splits execution
- Accumulated block count exceeds **N=10** (configurable per process)

A segment **closes** at the next start trigger or at the walk's leaf.

Output: ordered list of segment candidates, each:
- `segment_ordinal` (0-based)
- `segment_type` — assigned by the rules below
- `block_ids[]`
- `commit_scope_ids[]` spanned
- `io_site_ids[]` contained
- `variable_names[]` touched (from `variables_touched_json`)
- `incoming_guards[]` (the guards that route execution INTO this segment)

**`segment_type` assignment rules (deterministic, evaluated top-to-bottom — first match wins):**

| Rule | Condition | segment_type |
|---|---|---|
| R1 | `segment_ordinal == 0` | `opening` |
| R2 | `segment_ordinal == last` | `closing` |
| R3 | any block in segment has `block_tag == 'async-spawn'` | `async` |
| R4 | any block in segment has `block_tag == 'persistence-write'` | `persistence` |
| R5 | any incoming guard exists (segment entered through a `call_edge_guard`) AND at least one sibling segment shares the same caller block (i.e., this is one branch of a split) | `branch` |
| R6 | all blocks in segment have `block_tag == 'error-handling'` OR segment contains a `storage_lifecycle` RELCC event without a corresponding GETCC inside the segment | `cleanup` |
| R7 | segment precedes any I/O site or persistence-write in the entire process AND has only `block_tag == 'data-path'` blocks | `setup` |
| R8 | (default) | `main` |

Rules are pure functions of walk_node + call_edge_guard + storage_lifecycle + io_site columns. No LLM, no heuristics that could go either way.

Fully deterministic. No LLM calls.

**Next-segment hint computation (deterministic, used in Stage 2):**

After Stage 1 produces the ordered segment list, each segment gets a
`next_segment_hint` built deterministically from segment N+1's metadata:
- N+1's `segment_type`
- Business names of N+1's `io_site` targets (if any)
- Business names of N+1's distinct files
- N+1's first guard's `condition_human` (if entered through a guard)

Example: `"Segment N+1 type=persistence, writes to Account History Subfile, gated by: customer is active"`.

This hint enables Stage 2 to write a good `bridge_to_next` even though all
LLM calls run in parallel — the LLM never needs to know N+1's actual title,
only what N+1 is *about*.

##### Stage 2 — Card generation (LLM, 1 call per segment, parallel)

Each segment becomes one card via one `call_llm_model` call.

**Step 2a — Input pre-translation (deterministic, runs BEFORE the LLM call):**

Phase 2 block summaries are not guaranteed to be free of technical tokens
(they may still mention register codes, macro names, or variable codes).
Before any text reaches the LLM, it is scrubbed by a deterministic
`backend/pipeline/translate.py::translate_to_business_language(text, process)`
function which:

1. Replaces every known technical token with its business equivalent using a
   single lookup table built per process. For each token type there is a
   **two-tier resolution: primary lookup → deterministic fallback** (never the
   raw technical code):
   - **File codes** → primary: `entity_business_name` for `entity_type='file'`. Fallback (no row): use file's `block_tag` summary — e.g. "the validation module" if all its blocks are `validation`, else "the {file_purpose_from_block_summary}" or "an unnamed module".
   - **Block codes** → primary: `entity_business_name` for `entity_type='block'`. Fallback: use `walk_node.block_tag` to synthesize ("the validation step", "the persistence-write step", "the data-path step"). Never emit the raw code.
   - **Variable codes** → primary: `variable_context.purpose` first-clause. Fallback chain: `variable_meaning.meaning` → variable classification label-derived phrase ("a business value", "a control flag", "an infrastructure value") → "an internal value". Never emit the raw code.
   - **Macro / op codes** (`DBWRT`, `DBRED`, `DBADD`, `DBDEL`, `GETCC`, `RELCC`, `TXBGC`, `TXCMC`, `CREEC`, `CREMC`, etc.) → primary: static dictionary in `backend/pipeline/macro_business_map.py` (e.g. `DBWRT` → "writes a record to", `GETCC` → "reserves working storage"). Fallback for unknown macros: `op_category` from `io_site` → "performs a {op_category_business} operation" (e.g., `WRITE` → "performs a write"). Never emit the raw mnemonic.
   - **DB record codes** (`LM1M1`, `SW00SR`, etc.) → primary: `entity_business_name` for `entity_type='record'`. Fallback: `op_category` + "target" (e.g., "the audit-log target", "the configuration target"). Never emit the raw record code.
   - **Register codes** (`R0`–`R15`, `WA1`, `WK_*`, `CE\d+CR\d+`) → primary: resolved to the variable name they alias via `variable_alias`, then run through Variable rule above. Fallback: if `variable_classification.label='infrastructure'`, strip the register reference AND a configurable surrounding window (1 sentence containing only register-talk is dropped entirely; 1 register reference inside a multi-clause sentence is replaced with "an intermediate value").
2. Any token that still doesn't resolve after primary + fallback is logged
   in `untranslated_tokens` AND **replaced inline with a safe filler phrase**
   so the surrounding prose stays grammatical: nouns → "an unnamed item",
   actions → "performs an unspecified operation". The raw token is never
   passed through to the LLM input or the output.
3. Returns `(translated_text, untranslated_tokens_list)`. The list is
   persisted in the card row's `untranslated_tokens_json` for audit and
   for the validator to surface to maintainers (so missing business names
   can be added to `entity_business_name` over time).

The LLM only ever sees pre-translated text. This collapses the "LLM might leak technical names" failure mode from runtime to build time — the validator at the end is now a belt-and-braces check, not the first line of defence.

**Step 2b — LLM call inputs (all post-translation):**

| Source | Translated to |
|---|---|
| `walk_node.file` | `entity_business_name.business_name` for that file (Phase 2) |
| `walk_node.block` | `entity_business_name.business_name` for that block (Phase 2) |
| Variable codes (e.g., `WA1_DATE`) | `variable_context.purpose` + `variable_meaning.meaning` (Phase 2 + 4) |
| Macro / op_category (e.g., `DBWRT`) | Static business-language mapping from `macro_business_map.py` |
| `target_record` (e.g., `LM1M1`) | Business name of that record from `entity_business_name` with `entity_type='record'` (or fallback) |
| Guard expressions | `call_edge_guard.condition_human` (post-Phase-3 humanizer pass) |
| Block summaries | `block_summary.purpose` + `block_summary.behavior`, run through `translate_to_business_language()` |
| **Commit-scope narrative (persistence segments)** | When `segment.segment_type == 'persistence'` AND any block in the segment has a `commit_scope_id`: include `commit_scope_narrative.narrative` for that scope as an additional `transaction_context` field in the LLM prompt. This wires the commit-scope narrative component into the walkthrough — so persistence cards describe not just what was written but the business transaction outcome. |

**The LLM is given:**
- Process business name (from `entity_business_name` for the process entity)
- This segment's pre-translated inputs (above) — guaranteed technical-name-free
- The title of the **previous** segment (from Stage 1 ordering)
- The deterministic `next_segment_hint` (from Stage 1)
- A strict instruction: "Do not output any code identifier, file name, block name, macro name, register code, or database record code. Use only the business names provided. If a business name is missing, describe by behaviour."

**LLM output** (Pydantic-validated `NarrativeCard` model):

```json
{
  "title":               "5-8 word business-language title for this step",
  "body":                "3-8 sentence narrative in plain business language",
  "key_variables":       [{"business_name": "...", "why_it_matters": "..."}],
  "conditions":          [{"condition": "...", "outcomes": [{"value": "...", "leads_to": "..."}]}],
  "io_events":           [{"what_happens": "writes/reads/etc", "business_target": "...", "why": "...",
                           "transaction_context": "one sentence from commit_scope_narrative (only for persistence segments with a scope)"}],
  "bridge_to_next":      "one sentence connecting this step to the next"
}
```

LLM call uses `call_llm_model` (Rule 1) with the `NarrativeCard` schema.
Parallel via `ThreadPoolExecutor` capped at 16 (Q-S1).

**Cost estimate:** C400 → ~50-100 segments → 50-100 LLM calls (parallel, ~2 minutes wall-clock). Same order as Phase 2.

##### Stage 3 — Visualization payload (deterministic)

For each card, deterministically build the visualization payload from the
segment's block_ids and surrounding edges:

```json
{
  "focus_blocks":    [{"file_business_name": "...", "block_business_name": "...", "role": "data-path"}],
  "focus_edges":     [{"from_block": "...", "to_block": "...", "condition_business": "..."}],
  "focus_variables": [{"business_name": "...", "role_in_card": "validated|read|written|gates"}],
  "focus_io_events": [{"op_business": "writes", "target_business": "...", "key_variables_business": [...]}],
  "neighbour_hint":  {"previous_card_title": "...", "next_card_title": "..."}
}
```

No LLM call. All translation reused from Stage 2's deterministic lookups
(`translate_to_business_language()` + `entity_business_name` + `macro_business_map`).

**Sizing for readability:** `focus_blocks` is capped at **N=20** per card.
Stage 1's block-count trigger fires at 10, so most cards have 1–10 blocks
in their visualization — well under React Flow's comfortable-rendering
threshold. When a segment legitimately exceeds 20 (e.g., a wide branch fan),
the payload keeps only the boundary blocks and inserts a summary placeholder
node ("…and 8 intermediate steps…") so the graph stays readable.

**What the user sees in the Visualise modal (per B-11):**

| Element | Rendering |
|---|---|
| Nodes | One node per `focus_block`, labelled with `block_business_name`; tooltip on hover shows `file_business_name` and `role` |
| Edges | One edge per `focus_edge`, labelled with `condition_business` (truncated; full text in tooltip) |
| Node color | Coded by `role`: data-path = primary blue, validation = amber, persistence-write = red, error-handling = grey |
| Variables | Side panel of chips outside the graph (one chip per `focus_variable`), each chip shows `business_name` with `role_in_card` badge — keeps the graph itself clutter-free |
| I/O events | Inline callout on the persistence-write node (e.g., "writes Account History Record"); not a separate node |
| Layout | ELK auto-layout, top-to-bottom direction (matches reading order of the card body) |
| Legend | Small static legend at the top of the modal explaining the 4 colors |

Result: every label is a business name (zero technical leak), the graph never
exceeds ~20 nodes, and the layout matches the prose direction of the card —
so users read the card body and the graph reinforces what they just read.

##### Stage 4 — Card persistence + section grouping + transition stitching

- Group cards by `segment_type` into sections (preserving order).
- Compute `section_ordinal` (position within section) and `ordinal` (overall position).
- Set `total_cards` and `total_sections` (denormalized for fast pagination).
- Persist all cards in a single transaction to `process_narrative_card`.

---

#### Storage schema

```sql
CREATE TABLE process_narrative_card (
  process              TEXT NOT NULL,
  card_id              TEXT NOT NULL,            -- e.g. C400::card-007
  ordinal              INTEGER NOT NULL,         -- 0-based linear order
  section              TEXT NOT NULL,            -- opening|setup|main|branch|persistence|async|cleanup|closing
  section_ordinal      INTEGER NOT NULL,         -- 0-based within section
  title                TEXT NOT NULL,
  body                 TEXT NOT NULL,
  bridge_to_next       TEXT,                     -- 1-sentence transition
  key_variables_json   TEXT,                     -- [{business_name, why_it_matters}]
  conditions_json      TEXT,                     -- [{condition, outcomes}]
  io_events_json       TEXT,                     -- [{what_happens, business_target, why}]
  visualization_payload_json TEXT NOT NULL,      -- {focus_blocks, focus_edges, focus_variables, focus_io_events, neighbour_hint}
  source_block_ids_json TEXT NOT NULL,           -- audit: which walk_node rows this card covers
  untranslated_tokens_json TEXT,                 -- audit: tokens that fell through to filler phrases
  total_cards          INTEGER NOT NULL,         -- denormalized for breadcrumb
  total_sections       INTEGER NOT NULL,         -- denormalized
  generated_at         TEXT NOT NULL,
  content_hash         TEXT NOT NULL,            -- per-segment hash (see §4.5.3) for incremental rebuild
  PRIMARY KEY (process, card_id)
);
CREATE INDEX ix_narrative_card_ord ON process_narrative_card(process, ordinal);
CREATE INDEX ix_narrative_card_section ON process_narrative_card(process, section, section_ordinal);
```

---

#### API endpoints

| Endpoint | Returns |
|---|---|
| `GET /processes/{P}/walkthrough?offset=0&limit=2` | Paginated cards + `total_cards`, `total_sections`, `section_breadcrumb`, current section name/progress |
| `GET /processes/{P}/walkthrough/sections` | Section list: `[{section, card_count, first_ordinal, last_ordinal, first_card_title}]` for the section-nav tabs and mini-map |
| `GET /processes/{P}/walkthrough/cards/{card_id}` | Full single card (used for deep-linking) |
| `GET /processes/{P}/walkthrough/cards/{card_id}/visualization` | Just the `visualization_payload_json` for the Visualise modal (already inline in card response, but a thin endpoint for lazy fetch) |

Default `limit=2` matches the 2-at-a-time UI; clients can override.

---

#### Coverage validator

A `pytest` validator confirms every walked block landed in at least one
card's `source_block_ids_json`. If any walk_node is missing, the validator
fails and reports the orphan blocks. Run as part of the Stage C pipeline
gate.

---

#### When this runs

Phase 5, after artifacts 1–8 are complete (needs Phase 3 walk + Phase 2
business names + Phase 4 variable purposes + Phase 5 flow enumeration).
Implemented as `backend/pipeline/walkthrough.py::build_walkthrough_cards(process)`.

**Per-segment content hash for incremental rebuild:** each card row stores
a SHA-256 covering ONLY the inputs that fed THAT single card — not
process-wide hashes — so a change to one block summary only regenerates the
cards that touch that block:

```
card.content_hash = sha256(
  sorted(block_ids),
  [walk_node.content_hash for block in segment],
  [block_summary.content_hash for block in segment],
  [variable_context.content_hash for var in variables_touched],
  [entity_business_name.content_hash for entity in (files ∪ blocks ∪ records in segment)],
  next_segment_hint,
  previous_segment_title,
  template_version
)
```

On re-run, only segments whose hash changed are regenerated. The
`total_cards` / `total_sections` denormalized columns are recomputed
atomically at the END of the build pass (single UPDATE statement over all
card rows for the process) so they never drift even when only some segments
rebuild.

---

### 4.6 Process complexity metrics (ADDED 2026-05-28)

**Purpose:** eight simple, immediately-readable dimensions that show the
size and structural complexity of a process at a glance. Displayed on the
process homepage; queryable by the chat agent. Fully deterministic —
no LLM calls. All metrics come from Phase 1–3 table data, cached in
`process_artifact` (artifact_kind `'complexity_metrics'`).

#### The 8 metrics

| # | Metric name | UI label | Source (SQL / algorithm) | Low | Medium | High |
|---|---|---|---|---|---|---|
| M1 | **File span** | "Files in scope" | `COUNT(DISTINCT file) FROM walk_node WHERE process=P AND status != 'skipped-utility'` | 1 – 5 | 6 – 15 | 16 + |
| M2 | **Total blocks** | "Total blocks" | `COUNT(*) FROM walk_node WHERE process=P AND status != 'skipped-utility'` | 1 – 50 | 51 – 300 | 301 + |
| M3 | **Max call depth** | "Max call depth" | BFS on `call_edge` DAG from entry block; longest hop count to any leaf | 1 – 4 | 5 – 9 | 10 + |
| M4 | **Total call edges** | "Call edges" | `COUNT(*) FROM call_edge WHERE process=P` | 1 – 30 | 31 – 100 | 101 + |
| M5 | **Conditional branches** | "Conditional branches" | `COUNT(*) FROM call_edge WHERE process=P AND condition_expression IS NOT NULL` | 0 – 10 | 11 – 40 | 41 + |
| M6 | **Total variables** | "Variables" | `COUNT(*) FROM variable_context WHERE process=P` | 1 – 100 | 101 – 500 | 501 + |
| M7 | **Cross-file connections** | "Cross-file connections" | `COUNT(DISTINCT (source_file, target_file)) FROM call_edge WHERE process=P AND source_file != target_file` | 1 – 10 | 11 – 30 | 31 + |
| M8 | **Data-path blocks** | "Core logic blocks" | `COUNT(*) FROM walk_node WHERE process=P AND block_tag = 'data-path'` | 1 – 20 | 21 – 100 | 101 + |

**What each metric tells you:**

- **M1 file span** — how many source files a reader must open to understand the process end-to-end.
- **M2 total blocks** — raw size of the process: how many discrete code blocks exist inside the scope.
- **M3 max call depth** — how deep the call stack goes; deep chains increase the cognitive load of tracing any single execution.
- **M4 total call edges** — total connections in the call graph; dense graphs have many cross-links to reason about.
- **M5 conditional branches** — how many call edges carry a guard condition; more conditions = more distinct execution paths to test.
- **M6 total variables** — all variables tracked by the analysis; a proxy for total in-memory state.
- **M7 cross-file connections** — distinct file-to-file edges; tells you how tightly coupled the files are. High coupling = harder to isolate and change one file without touching others.
- **M8 data-path blocks** — blocks that sit on the primary execution path (not validation, error-handling, or utility); directly sizes the core business logic.

#### Composite complexity score

A single headline score (0 – 100) aggregates all 8 dimensions. Each metric
is normalised to 0 – 10 using the High threshold as the ceiling, then averaged:

```
score_i = min(value_i / high_threshold_i, 1.0) * 10
composite = round(mean([score_1 … score_8]) * 10)   # → 0-100
```

Composite ranges: **0–30** = Simple, **31–60** = Moderate, **61–80** = Complex,
**81–100** = Very Complex.

The composite and all 8 raw values (+ Low/Medium/High band) are stored in
the `process_artifact` JSON payload. Recomputed whenever the pipeline reruns
and any contributing table changes (content_hash check).

#### Backend computation

`backend/pipeline/complexity.py::compute_complexity_metrics(process: str, conn) → dict`

Executes the 8 SQL queries + the BFS depth walk on `call_edge` in a single
function. All 8 source tables (`walk_node`, `call_edge`, `variable_context`)
are populated by the end of Phase 3, so the function runs once after Phase 3
completes. Writes/upserts a `process_artifact` row with artifact_kind
`'complexity_metrics'`.

No new table required — result lives in `process_artifact.payload_json`.

---

## 5. IBM TPF/DF semantic patterns we model explicitly

These are the IBM canonical patterns that anchor our deterministic
analysis. Each one becomes a first-class concept in the schema and is
visible to the chat agent.

### 5.1 DB subfile lifecycle (DBOPN → ... → DBCLS)

Sources: `docs/ibm/patterns/db-open-read-update-close.md`,
`docs/ibm/macros/ztpfdf-db-macros.md`,
`docs/ibm/functions/ztpfdf-c-functions.md`.

The canonical lifecycle:
1. `DBOPN REF=X` — allocates or reuses a DBIFB slot (SW00SR).
2. Optional key setup: `DBKEY`/`DBSETK` or `KEYn=`/`KEYLIST=`.
3. Read/update/add/delete: `DBRED`, `DBADD`, `DBDEL`, `DBREP`, `DBMOD`.
4. `DBCLS REF=X` — finalises I/O, releases or retains SW00SR.

We capture this as a **subfile session** = a chain of `io_site` rows
sharing the same `target_ref` between an `DBOPN` and its matching
`DBCLS`. New table `subfile_session`.

For each session we know:
- `target_record`, `target_ref`
- `hold_state`, `prefetch`, `detac` flags
- ordered list of ops inside the session
- commit scope membership

### 5.2 Storage allocation lifecycle (GETCC → use → RELCC)

Sources: `docs/ibm/patterns/storage-and-ecb-lifecycle.md`.

- `GETCC Dn` → returns pointer in `R14`, attaches storage to ECB level `Dn`.
- Subsequent `LR Rx, R14` / `ST R14, field` create aliases of that pointer.
- `RELCC Dn` invalidates the block; aliases become dangling.
- `DETAC Dn` transfers ownership; matching `ATTAC` restores.
- `FINDC` / `FINHC` / `FINWC` / `FIWHC` may allocate as a side effect of read.

New table `storage_lifecycle` tracks each `(file, block, line, op, level, pointer_register)` event. The footprint BFS uses this to stop following dead aliases after `RELCC`.

### 5.3 Keyed LREC access (active keys persist)

Sources: `docs/ibm/patterns/keyed-lrec-access.md`.

Active key state lives in `SW01*` fields and persists across DB calls
until replaced or deactivated by `NOKEY` / `DBKEY` with a different list.

Implication: a keyless `DBRED` is NOT necessarily an unfiltered read. We
record the active key snapshot at every read site (`keys_active` column
of `io_site`) so the meaning of the read is unambiguous.

### 5.4 Transaction commit scopes (TXBGC → TXCMC/TXRBC)

Sources: `docs/ibm/patterns/transactions-and-commit-scopes.md`.

`TXBGC` opens a scope; `TXCMC` commits; `TXRBC` rolls back.
`TXSPC`/`TXRSC` suspend/resume.

IBM rule: all `DBOPN`-through-`DBCLS` references must stay in the same
commit scope when opened in that scope.

New table `commit_scope` with rows `(scope_id, process, begin_file,
begin_block, begin_line, end_file, end_block, end_line, end_kind:
'commit'|'rollback'|'unclosed')`. Every `io_site` and
`storage_lifecycle` row carries the `scope_id` they're nested inside.

Phase 5's persistence summary distinguishes "permanent" outputs (after
commit) from "scoped" outputs (will be rolled back if `TXRBC` fires).

Phase 5 also generates a **per-scope narrative** for each `commit_scope`
row: plain-English business outcome + ranked key variables inside that scope.
Stored in `commit_scope_narrative` (see §11). One LLM call per scope,
parallel. Surfaced in the commit-scope view and via the
`get_commit_scope_narrative` chat tool.

### 5.5 ECB / DBIFB context

Sources: `docs/ibm/patterns/storage-and-ecb-lifecycle.md`,
`docs/ibm/macros/ztpfdf-db-macros.md`.

- ECB = Entry Control Block, base typically in `R9`.
- DBIFB = DB Interface Block, accessed via `SW00SR` slot.
- ECB fields (CBRWs) are first-class variables tracked by
  `passes/ecb_alias_table.py`.
- DBIFB context = persistent state across DB calls within a session.

The chat agent can answer "what is in the ECB at this point?" by
querying the variable table for `decl_kind='ecb-field'` constrained to
the variables touched up to and including the asked block.

### 5.6 ASM ↔ C linkage (CALLC / CPROC / ENTxC / PRLGC / EPLGC)

Sources: `docs/ibm/patterns/asm-c-interoperability.md`.

Cross-language bridge mechanisms:

| Pattern | Meaning |
|---|---|
| `CPROC RETURN=t, name, (typelist)` | Declares C function prototype — type metadata for parser |
| `CALLC name(args)` | ASM calls C function; up to 12 params; return in R15/F0 |
| `ENTDC target` | Enter and drop previous; no return |
| `ENTNC target` | Enter, no return expected |
| `ENTRC target` | Enter, return expected |
| `BACKC` | Return from `ENTRC` |
| `PRLGC` / `EPLGC` | Prologue/epilogue for new BAL library functions |
| `CLINKC` / `RLINKC` / `SLINKC` | Linkage variants |
| `TMSPC` / `TMSEC` | Migration-compatibility linkage (older style) |
| `UPROC` | Bundle of `CPROC` declarations |

Each is a candidate edge in the call graph with known calling-convention
semantics. The footprint propagator for "ASM → C++ via CALLC" uses the
matching `CPROC` to map register-passed arguments to function parameters.

---

## 6. Variable declaration: what counts as "decl_file, decl_block"

To root the typed BFS, every variable needs a canonical declaration site.

| Variable kind | Declaration site rule |
|---|---|
| ASM EQU | `<name> EQU <expr>` line |
| ASM DC/DS in a CSECT | The `DC`/`DS` line under the appropriate CSECT |
| ASM DSECT field | Field offset within its DSECT |
| ASM macro parameter | The macro invocation's argument site |
| ASM ECB field (CBRW) | The ECB definition referenced; alias table entry |
| ASM SW00* field | The SW00 macro / DBDEF entry |
| C++ local | The variable's declaration line in the function |
| C++ class member | The class definition (header) |
| C++ global | The translation unit's global decl |
| C++ struct field with ASM alias | Both the C++ field site and aliased ASM field site |
| C++ function parameter | Parameter slot in function signature |
| Register-only "variable" | First write at the process entry block |
| GETCC-backed pointer | The `GETCC` line; alias chain follows until matching `RELCC` |
| z/TPFDF-managed buffer (SW00REC, SW00WKA) | The `DBOPN`/`DBSPA` site that allocated it |
| Block-ref variable (no formal declaration) | First block where it appears in `variables_touched_json` |
| Enum constant | Enum definition site |

This taxonomy comes from `build_variable_identity_index.py` +
`fixes/phase_equivalent_variable_resolution/` + IBM TPF docs.

---

## 7. Process entry point — how it's declared

**Status: LOCKED 2026-05-27.** Schema as below. `entry` may be either a
single object (single-entry process) or a list of conditional entries
(multi-entry dispatch pattern, common in z/TPF where one process serves
multiple message types).

We extend `process.json` (or add `process_meta.json`) with:

```json
{
  "name": "C400",
  "title": "Afterglow / General Ledger History Processing",
  "entry": {
    "file": "temp/asm/da78.asm",
    "kind": "asm-routine",            // or "cpp-function"
    "routine_or_function": "DA7",     // ASM routine label or C++ symbol
    "line": 130                       // optional, for disambiguation
  },
  "inputs_declared": [
    { "name": "WA1_TYPE", "source": "ecb-field" }
  ],
  "outputs_declared": [
    { "name": "LM1M1_record", "destination": "persistence-write" }
  ]
}
```

### Multi-entry processes (locked addition)

When a process can be entered from multiple points based on a
dispatcher's decision, `entry` may instead be a JSON array:

```json
{
  "name": "C400",
  "entry": [
    {
      "condition": "msg_type == 'AFTERGL'",
      "file": "temp/asm/da78.asm",
      "kind": "asm-routine",
      "routine_or_function": "DA7_AFTERGL",
      "line": 130
    },
    {
      "condition": "msg_type == 'BEFOREGL'",
      "file": "temp/asm/da78.asm",
      "kind": "asm-routine",
      "routine_or_function": "DA7_BEFOREGL",
      "line": 280
    }
  ]
}
```

Each list element is treated as a distinct entry point. The top-down
walk runs once per entry and produces a tree per entry; flows
(§4.5) are enumerated per-entry and tagged with the `condition` so the
chat agent can answer "what happens for AFTERGL transactions?" by
filtering the flow set.

The `condition` is free-form text describing the dispatcher's
predicate; it is NOT evaluated, just rendered. It's a label for the
human and for the LLM-generated narrative.

### Optional hint fields

`inputs_declared` / `outputs_declared` are optional human hints that
seed Phase 5; the system derives them deterministically when absent.

### Language

For C++-entry processes, `kind = "cpp-function"` and
`routine_or_function` is the fully-qualified symbol (e.g.
`namespace::ClassName::methodName`). Everything else works identically.

### Fallback

If `entry` is absent we fall back to today's behaviour (treat all
blueprint files as equal). The redesign's full value depends on having
`entry` declared.

---

## 8. Conditional call-graph capture — every guard kind

Sources: `conditional_parser.py`, `conditional_evaluator.py`,
`operation_classifier.py`, `passes/c_family_parser.py`,
`docs/ibm/macros/ztpf-system-macros.md`, `fixes/phase5*_enum_*`.

New SQLite table `call_edge_guard`:

```
(guard_id, edge_id, guard_kind, guard_expression, when_value,
 source_file, source_line, condition_human)
```

Guard kinds covered:

| `guard_kind` | Source | Detector |
|---|---|---|
| `aif` | z/TPF conditional assembly `AIF` | `conditional_parser.py` |
| `ago` | `AGO` jump | `conditional_parser.py` |
| `anop` | `ANOP` no-op label target | `conditional_parser.py` |
| `set-symbol` | `SETA`/`SETB`/`SETC` value gating expansion | `conditional_parser.py` + `conditional_evaluator.py` |
| `cmp-branch` | Preceding `C`/`CR`/`CH`/`CL`/`CLR` + conditional `B*` | `operation_classifier.py`, `instruction_classifier.py` |
| `clc-branch` | `CLC`/`CLI`/`CHI` + branch | `operation_classifier.py` |
| `tm-branch` | `TM` (test mask) + `BO`/`BZ`/etc. | `operation_classifier.py` |
| `ts-branch` | `TS` (test and set) + branch | `operation_classifier.py` |
| `ltr-branch` | `LTR`/`LT` (load and test) + branch | `instruction_classifier.py` |
| `bct-branch` | `BCT`/`BCTR` (branch on count) | `instruction_classifier.py` |
| `ex-resolved` | `EX` executed instruction resolved to a branch | `instruction_classifier.py` |
| `cpp-if` | Enclosing C++ `if`/`else` | `passes/c_family_parser.py` |
| `cpp-switch-case` | `switch (x) { case K: ... }` arm | `passes/c_family_parser.py` |
| `cpp-ternary` | `cond ? a : b` arm | `passes/c_family_parser.py` |
| `cpp-while` | Inside a `while` body | `passes/c_family_parser.py` |
| `cpp-for` | Inside a `for` body | `passes/c_family_parser.py` |
| `cpp-do-while` | Inside a `do-while` body | `passes/c_family_parser.py` |
| `cpp-noexcept-branch` | Reached only on the noexcept path | `passes/c_family_parser.py` |
| `cpp-try-catch` | Reached only via catch handler | `passes/c_family_parser.py` |
| `enum-equals` | `if (x == ENUM_NAME)` resolved to symbolic value | `fixes/phase5_enum_value_resolution/`, `fixes/phase5b_enum_conditional_tracking/` |
| `loop-iteration` | Inside a loop iterating a collection/range | `passes/c_family_parser.py` |
| `macro-arg-gate` | Macro invocation parameter value gates expansion | `macro_expander.py` + `conditional_evaluator.py` |
| `dbfound-yes/no` | z/TPFDF `#IF (DBFOUND,YES/NO)` pseudo-condition | derived from DB op outcome + structured-programming macro state |
| `keyactive-condition` | Reached when specific active key list matches | derived from `io_site.keys_active` |
| `commit-scope-active` | Reached only inside an open TX scope | derived from `commit_scope` |
| `error-flag-set` | Post-call flag check (e.g. `LTR R15,R15 + BNZ`) typical for `CALLC` error returns | `operation_classifier.py` + IBM linkage pattern |

`condition_human` is the LLM-rendered, business-language phrasing of the
guard (e.g. "transaction is a credit reversal" instead of `CLI
WA1IND,X'07' + BE`).

**Timing — post-Phase-3 pass (no-duplicate-LLM rule):**
After Phase 3 walk completes (and before Phase 4 begins), a dedicated
`backend/pipeline/condition_humanizer.py::humanize_guards(process)` pass
runs. It:
1. Queries all distinct `guard_expression` values from `call_edge_guard` for
   the process (deduplicated by text — the same expression may appear on many
   edges).
2. Makes ONE `call_llm_model` call per unique expression (not per edge
   occurrence). A single batched prompt can handle up to 20 guards at once
   via a JSON list response.
3. Writes the `condition_human` value back to every matching row in
   `call_edge_guard`.

Phase 3 walk itself uses raw `guard_expression` text. The UI and Phase 5
prompts use `condition_human`. This ensures zero duplicate LLM calls for
guards that appear multiple times in the walk.

---

## 9. All call patterns — coverage matrix

Sources: `file_call_graph.py`, `instruction_classifier.py`,
`cpp_call_chain/traversal.py`, `cross_file_bridge.py`,
`docs/ibm/macros/ztpf-system-macros.md`,
`docs/ibm/functions/ztpf-os-c-functions.md`,
`docs/ibm/patterns/asm-c-interoperability.md`.

### 9.0 Indirection envelope — shared metadata convention

**Authoritative reference:** `INDIRECT_CALL_COVERAGE.md` in the parent
codebase documents all six covered call categories with response shapes
and suppression rules. The wrapper code in `explanability_demo/` MUST
consult it before implementing any new indirect-call detector.

Every `call_edge` row that represents an indirect call carries a
structured `indirection_json` blob sourced from the parent codebase's
envelope utilities:

| Module | Purpose |
|---|---|
| `api/utils/indirection.py` | `envelope_from_fields()` — build envelope from named fields; `extract_indirection()` — read envelope from raw edge dict; `merge_indirection()` — carry envelope across transform layers |
| `api/schemas/_indirection.py` | `IndirectionEnvelope` Pydantic model (`extra="allow"` for forward compat) |

Envelope fields (all stored in `call_edge.indirection_json`):

| Field | Type | Meaning |
|---|---|---|
| `is_indirect` | bool | Edge reached via function-pointer or register-based call |
| `indirect_via` | string | FP variable name or register that held target address (e.g. `"R15"`, `"fp_callback"`) |
| `is_virtual_dispatch` | bool | Edge added by CHA expansion |
| `cha_base_class` | string | Base class whose virtual call triggered CHA |

**Rule:** every wrapper or new module in `explanability_demo/` that emits
a call edge for an indirect pattern MUST call `envelope_from_fields()`
(not roll its own fields). This ensures the rendering layer, chat tools,
and Phase 3 walk all see a consistent shape regardless of whether the
edge came from C++, ASM, or the LLM fallback.

### 9.1 Within ASM

| Pattern | Instruction(s) | Detector |
|---|---|---|
| Subroutine call (local) | `BAL`, `BALR`, `BAS`, `BASR`, `BRAS`, `BRASL` | `instruction_classifier.py` SUBROUTINE_CALL |
| Mode-transition call | `BASSM`, `BASM`, `BSM` | `instruction_classifier.py` MODE_TRANSITION |
| Branch (intra-file) | `B`, `BC`, `BCR`, `BE`, `BZ`, `BNE`, `BNZ`, … | `instruction_classifier.py` BRANCH |
| Branch on count | `BCT`, `BCTR` | `instruction_classifier.py` |
| Execute | `EX`, `EXRL` | `instruction_classifier.py` EXECUTE |
| **EX + BC jump table (static)** | `EX R2, TABLE_BC` where `TABLE_BC` is a run of `BC 15,LABEL` entries | `call_graph_builder.py` — parser walks table at parse time and emits one direct `branch` edge per `BC` entry; all edges are direct (no `is_indirect`). Dynamic tables (index computed at runtime) emit nothing — fundamental static limit. See `INDIRECT_CALL_COVERAGE.md` Pattern 4. |
| **Indirect subroutine call via register** | `BALR R14,Rx` / `BASR R14,Rx` where `Rx ≠ R0` | `call_graph_builder.py` → emits edge with `is_indirect=True`, `indirect_via=Rx`; envelope built via `envelope_from_fields()`. Backward trace in `asm_indirect_branch_resolver.py` (§9.6) then tries to resolve `Rx`. |
| **Indirect conditional branch via register** | `BCR mask,Rx` where `Rx ≠ R14` and `mask ≠ 0` | Same envelope as above; `indirect_via=Rx`; guard carries mask condition. |
| Return | `BR R14`, `BACKC`, `BCR 15,R14` | `instruction_classifier.py` RETURN |
| Cross-module subroutine | `ENTRC` (return expected) | `file_call_graph.py` |
| Cross-module no-return | `ENTNC`, `ENTDC` | `file_call_graph.py` |
| Async spawn — deferred entry | `CREDC` | `file_call_graph.py` + IBM docs |
| Async spawn — with storage | `CREEC` | `file_call_graph.py` |
| Async spawn — immediate ready-list | `CREMC` | `file_call_graph.py` |
| Async spawn — time-initiated | `CRETC` | IBM docs (needs verify) |
| Async spawn — lower-priority deferred | `CREXC` | IBM docs |
| Synchronous create + suspend caller | `CRESC` | IBM docs |
| Processor/I-stream comms | `SIPCC` | IBM docs |
| ISC dispatch | `SWISC` | `file_call_graph.py` |
| Macro wrapper (expands to ENTDC) | `FUNCTION <name>` | `file_call_graph.py` |
| Conditional cross-file | Any of above behind `AIF`/`CMP+B`/`TM+B` | `find_call_conditions.py` |
| Indirect branch via register | `BR Rx` where `Rx ≠ R14` | `asm_indirect_branch_resolver.py` (new) — see §9.5 |

### 9.2 Within C++

All indirect-call edges carry the `indirection` envelope (§9.0).
Full sub-pattern coverage with suppression rules: `INDIRECT_CALL_COVERAGE.md`
Patterns 1–3 (direct, function-pointer, virtual dispatch).

| Pattern | Detector |
|---|---|
| Direct function call (namespace-qualified, static, constructor, FQN) | `passes/c_family_parser.py`, `cpp_call_chain/source_scanner.py` — see INDIRECT_CALL_COVERAGE.md Pattern 1 |
| Method call on object | `cpp_call_chain/traversal.py` |
| Virtual call via CHA (same-file + cross-TU) | `cpp_call_chain/traversal.py` (`virtual_dispatch_cha`); cross-TU via `cpp_cross_lang_index.msgpack.zst`; envelope: `is_virtual_dispatch=true`, `cha_base_class=<base>` |
| `CALL_ALIAS` wrapper to ASM | `passes/c_family_parser.py`, `cross_file_bridge.py` |
| FP — local / global variable: `fp = target; fp(wa)` | `cpp_call_chain/source_scanner.py` `fp_sources` — single-identifier init resolved to direct edge; unresolvable at runtime → `is_indirect=true, indirect_via=fp` |
| FP — `std::function<>` with direct init | Same `fp_sources` path |
| FP — re-assignment (multiple targets): `fp = fn1; fp = fn2` | Both targets accumulated in `fp_sources` |
| FP — struct-field: `d.fn = target; d.fn(w)` | Field assignment traced to initialiser |
| FP — array: `FnArr fns[] = {a, b}; fns[i](w)` | All array members resolved to direct edges |
| FP — ternary: `fp = cond ? a : b; fp(w)` | Both branches accumulated |
| FP — member pointer: `(obj.*mfp)(w)` | FQN resolved via CHA |
| Functor `operator()`: `BetaFunctor bf; bf(wa)` | FQN `BetaFunctor::operator()` emitted (not raw `bf`) |
| Lambda invocation | `cpp_call_chain/traversal.py` (`is_local_var` suppresses FP leaf) |
| Template instantiation | `cpp_call_chain/index_builder.py` (per-instantiation node) |
| Operator overload (`+`, `==`, `+=`, `[]`, `++`, `=`) | `cpp_call_chain/traversal.py` — FQN operator resolved |
| `try/catch` cross-block jump | `passes/c_family_parser.py` |

### 9.3 Cross-language linkage (ASM ↔ C/C++)

| Pattern | Direction | Detector |
|---|---|---|
| `CPROC RETURN=t, name, (typelist)` | metadata for type-aware call | IBM doc, `passes/c_family_parser.py` |
| `CALLC name(args)` | ASM → C/C++ | IBM doc + `cross_file_bridge.py` |
| `UPROC` (CPROC bundle include) | metadata | IBM doc |
| `ENTRC` to a C entry | ASM → C/C++ (with return) | `cross_file_bridge.py` + `passes/ecb_alias_table.py` |
| `ENTNC` to a C entry | ASM → C/C++ (no return) | `cross_file_bridge.py` |
| `ENTDC` to a C entry | ASM → C/C++ (enter and drop) | `cross_file_bridge.py` |
| `BACKC` from C-callable BAL | C/C++ → ASM (return) | IBM doc |
| `PRLGC` / `EPLGC` | new BAL library entry/exit | IBM doc — recognised as edge endpoints |
| `CLINKC` / `RLINKC` / `SLINKC` | linkage variants | IBM doc |
| `TMSPC` / `TMSEC` | old TPF 4.1 migration linkage | IBM doc |
| `CALL_ALIAS` (C++ wrapper) | C++ → ASM | `cross_file_bridge.py` (C++→ASM mode) |
| Direct C++ call to ASM-exported symbol | C++ → ASM | `cross_file_bridge.py` |
| C++ call to z/TPF C API → may call ASM | C++ → ASM (via TPF C library) | `external_call_identifier.py` + IBM C/macro mapping |
| ECB field write read across boundary | bidirectional | `passes/ecb_alias_table.py`, `fixes/phase6_ecb_mapping/` |

### 9.4 Entry creation family (async/scheduled — IBM-specific)

| Macro | C function | Behaviour | Walk treatment |
|---|---|---|---|
| `CREDC` | `credc` | Deferred entry | `async-spawn`, follow as separate process boundary |
| `CREEC` | `creec` | Entry with attached storage block | `async-spawn`, track storage handoff |
| `CREMC` | `cremc` | Immediate ready-list entry | `async-spawn` |
| `CRETC` | `cretc` / `cretc_level` | Time-initiated entry | `async-spawn`, tag with timing |
| `CREXC` | `crexc` | Lower-priority deferred | `async-spawn` |
| `CRESC` | `tpf_cresc` | Synchronous + suspend caller | follow synchronously, mark suspend |
| `SIPCC` | `sipcc` | Processor/I-stream comm | system-level, mark for manual review |
| (none) | `swisc_create` | ECB on another I-stream | `async-spawn` cross I-stream |
| (none) | `tpf_fork` | Async ECB on I-stream | `async-spawn` |
| (none) | `system()` | Synchronous main + suspend | follow synchronously |

These all appear in the walk but are tagged so Phase 5 can describe them
as "process spawns a deferred entry to do X" rather than as part of the
synchronous data path.

### 9.5 Macro-mediated calls

`passes/macro_expansion_pass.py` + `macro_expander.py` resolve macros so
a call appearing inside a macro body shows up correctly in the call
graph after expansion. Audit gap: confirm expansion always runs before
`call_graph_builder.py` (§15).

---

### 9.6 ASM indirect branch via register — resolution algorithm

**ADDED 2026-05-28.**

`BR Rx` where `Rx = R14` is a standard return and stays classified as
`RETURN` (existing behaviour, correct). `BR Rx` where `Rx ≠ R14` is a
computed jump whose target must be resolved before a call edge can be
emitted. New module: `asm_indirect_branch_resolver.py` — mirrors the
approach of the C++ indirect-call envelope (commit `0f6d46a`).

#### Detection

`instruction_classifier.py` is extended: when it sees `BR Rx` and
`Rx` is not the current link register (R14, or whichever register was
loaded by the last `BALR Rx,0` / `BASR Rx,0` in scope), it emits an
`INDIRECT_BRANCH` token instead of `RETURN` and hands the line to
`asm_indirect_branch_resolver.py`.

#### Resolution — 4-step backward trace

For each `BR Rx` classified as `INDIRECT_BRANCH`, trace backward
through the block (and, if needed, immediate predecessor blocks in
`block_flow`) to find the last instruction that wrote `Rx`. Apply the
first matching rule.

**All emitted edges use `envelope_from_fields(is_indirect=True, indirect_via=Rx)`
from `api/utils/indirection.py`** — the `call_type` field distinguishes
resolution quality; the `indirection_json` blob distinguishes it from
a direct call.

| Load pattern | Resolution | Emit |
|---|---|---|
| `L Rx, =A(SYMBOL)` or `L Rx, =V(SYMBOL)` | `literal_resolver.py` resolves the literal pool entry → symbolic name | One `call_edge` to `SYMBOL`; `call_type = indirect-resolved`; envelope: `is_indirect=true, indirect_via=Rx` |
| `LA Rx, LABEL` (load address of a local label) | The label is within the same file; resolve to the block containing `LABEL` | One `call_edge` to that block; `call_type = indirect-resolved`; same envelope |
| **Table-driven dispatch**: `LA Rb,TABLE` + `SLL Ri,2` + `L Rx,0(Ri,Rb)` + `BR Rx` | Scan the data section for `TABLE: DC A(...)` entries; enumerate all address constants | One `call_edge` per table entry; `call_type = indirect-table-dispatch`; guard carries the index-range condition if detectable; same envelope |
| `LR Rx, Ry` register copy | Follow the copy chain backward (repeat from step 1 with `Ry`) | Recurse until a load instruction is found or the chain terminates |
| `L Rx, FIELD(Rb)` — load from DSECT/struct field | Target is data-dependent; cannot be statically resolved | Mark block as `indirect-unresolved`; emit one row to `walk_truncation`; `call_type = indirect-unresolved`; envelope still carries `is_indirect=true, indirect_via=Rx` |

#### Guard attachment

After the target(s) are resolved, any `AIF`/`CMP+B`/`TM+B` guards
enclosing the `BR Rx` instruction are attached to each emitted
`call_edge_guard` row in the normal way — exactly as for explicit
branch patterns.

#### LLM fallback for `indirect-unresolved` (`L Rx, FIELD(Rb)`)

**ADDED 2026-05-28.** When the backward trace terminates at a
`L Rx, FIELD(Rb)` load (data-dependent target), the static resolver
cannot continue. Before emitting `indirect-unresolved`, the following
LLM call is attempted using `call_llm_model` (Gemini 2.5 Pro):

```
Context: IBM z/TPF Assembly. Block <block_label> in <file>.
Indirect branch instruction at line <N>: BR <Rx>
Register <Rx> was loaded from DSECT field <DSECT_NAME>+<offset>
(field name: <field_name_from_dsect>).

DSECT definition (abridged):
<DSECT source, ≤ 30 lines>

Surrounding block source (±15 lines around the BR):
<source>

Block summary (from Phase 2): <block_summary_text>

Based on this context, what are the most likely branch targets
(by ASM label / routine name) for this indirect branch?
List each candidate as a JSON object:
  {"target": "<label>", "confidence": <0.0-1.0>, "rationale": "<why>"}
Return a JSON array. If you cannot determine any target with
confidence > 0.3, return an empty array [].
```

**Output handling:**

| LLM response | Action |
|---|---|
| ≥ 1 candidate with `confidence ≥ 0.7` | Emit one `call_edge` per candidate; `call_type = indirect-llm-resolved`; store `llm_rationale` in the edge row; walk follows these edges normally |
| Candidates exist but all `confidence < 0.7` | Emit edges with `call_type = indirect-llm-low-confidence`; `walk_status = skipped-indirect`; surface in UI for analyst review with LLM rationale visible |
| Empty array `[]` | Fall through to `indirect-unresolved` (existing behaviour) |

**Schema addition to `call_edge`:**

```sql
ALTER TABLE call_edge ADD COLUMN llm_rationale TEXT;
-- populated only for indirect-llm-resolved / indirect-llm-low-confidence rows
```

**Cost note:** L3.5 LLM calls here are strictly bounded — one call per
`L Rx, FIELD(Rb)` that was not resolved by steps 1-4. In practice,
most indirect branches resolve statically; this fallback targets the
small residual set.

#### Walk treatment

- `indirect-resolved` and `indirect-table-dispatch` edges are walked
  normally — Phase 3 follows them as concrete call edges.
- `indirect-llm-resolved` (confidence ≥ 0.7) edges are walked normally;
  Phase 3 treats them as concrete call edges with a `llm_derived` flag.
- `indirect-llm-low-confidence` and `indirect-unresolved` edges are
  tagged `walk_status = skipped-indirect` and surfaced in the UI
  alongside other truncation events so an analyst can review the source
  line and classify the target manually.

#### Detectors used

| Task | Script |
|---|---|
| Classify `BR Rx` as INDIRECT_BRANCH | `instruction_classifier.py` (extend existing RETURN check) |
| Resolve `=A(SYMBOL)` / `=V(SYMBOL)` literals | `literal_resolver.py` (existing, already in Phase 1) |
| Enumerate `DC A(...)` table entries | `asm_indirect_branch_resolver.py` (new) — scans data section of same file |
| Follow `LR` register copy chains | `asm_indirect_branch_resolver.py` — uses `build_variable_identity_index.py` register alias layer |
| Emit `walk_truncation` for unresolved cases | `walk_truncation` table (existing from Phase 3 walk cap logging) |
| LLM fallback for `L Rx, FIELD(Rb)` | `call_llm_model` (Gemini 2.5 Pro) via `backend/llm.py`; prompt includes DSECT definition + surrounding source + Phase 2 block summary |

---

## 10. Process input/output identification rules (language-specific)

### 10.1 Inputs

| Concept | ASM rule | C++ rule |
|---|---|---|
| Register-passed input | `R0..R15` read before any write in the entry block | function parameter declared with that register's pseudonym |
| ECB-field input | ECB field read before any write in the entry path | C++ field reads via ECB/DBIFB struct |
| Global input | Global symbol read before any write | C++ global / class-member read before any write |
| Persisted input | `DBRED`/`DBGET` reachable on the input-decoding portion of the walk | `dfred*`/`dfgrd*` in entry function or directly-called function |
| Macro-parameter input | Macro invocation's args bound to formal parameters | template parameter / function parameter |
| Storage input (allocated by caller) | Pointer in `R14` from caller's `GETCC` reused | `getcc`-returned pointer passed in |

### 10.2 Outputs

| Concept | ASM rule | C++ rule |
|---|---|---|
| Process return | Register written before `BACKC` / `BR R14` / `EXITC` (typically R15) | function return statement |
| ECB / global output | ECB field written and not overwritten downstream | C++ class-member / global / out-parameter write |
| Persisted output | `DBWRT`/`DBADD`/`DBMOD`/`DBREP`/`DBDEL` reachable from entry | `dfwrt`/`dfadd`/`dfmod`/`dfrep`/`dfdel` reachable |
| Async output (side effect) | `CREEC`/`CREMC`/`CREDC`/`CREXC`/`CRETC` | `creec`/`cremc`/`credc`/`crexc`/`cretc` |
| Synchronous-spawn output | `CRESC` | `tpf_cresc` |
| Storage handoff output | `DETAC` (storage now owned by another ECB) | `detac*` |
| Status flag output | Designated status field write before exit | return code, enum |
| Error output | Persistence write reachable only via error-handling walk status | exception thrown, error-out-parameter |
| Commit-scope output | `TXCMC` after a sequence of DB ops in scope | `tx_commit` after writes |

---

## 11. Database schema — SQLite (+ pgvector Python adapter)

**REVISED 2026-05-28.** SQLite remains the single database for all pipeline
tables. The `pgvector` Python library (SQLite mode, `pgvector.sqlite`) is
registered on each connection to add `cosine_distance` / `l2_distance` functions
and BLOB vector serialization — no external database or server required.

**Project scoping (added 2026-05-28).** Every table carries a `project_id TEXT NOT NULL DEFAULT 'default'`
column. All queries filter by `project_id` before anything else. A top-level
`project` table holds project metadata. The `DEFAULT 'default'` allows the
pipeline runner to write rows without knowing the project_id; the build route
retagging pass updates them to the correct project after each build completes.
Disk layout (`data/processes/<name>/`) remains flat for the current demo;
migration to `data/projects/<project_id>/processes/<name>/` is a future task.

```sql
CREATE TABLE IF NOT EXISTS project (
  id          TEXT PRIMARY KEY,
  name        TEXT,
  description TEXT,
  created_at  TEXT NOT NULL
);
```

Existing tables kept and enriched with new optional columns:
`process`, `file`, `block`, `variable`, `chunk_fts` (existing FTS5 virtual
table) supplemented by `chunk_embedding` (see §11.5),
`conversation_message`.

**`investigation_message` — DEPRECATED (Decision 2026-05-28).** The
per-variable investigation page (setter / usage streaming) has been
removed from the frontend. The table is retained in the schema for
backward compatibility but will not be written to by the new pipeline.
Investigation seeding into chat is also removed.

New tables (each gets a `content_hash` column for resumability; omitted
below for brevity):

```sql
-- One row per call edge.
CREATE TABLE call_edge (
  edge_id TEXT PRIMARY KEY,
  process TEXT NOT NULL,
  from_file TEXT NOT NULL,
  from_block TEXT,
  to_file TEXT NOT NULL,
  to_block TEXT,
  call_type TEXT NOT NULL,        -- ENTRC / ENTNC / ENTDC / CREEC / CREMC /
                                  -- CREDC / CRETC / CREXC / CRESC / SWISC /
                                  -- FUNCTION / CALLC / CALL_ALIAS / CALL /
                                  -- INDIRECT / virtual_dispatch_cha /
                                  -- cpp-method / lambda / template-call /
                                  -- indirect-resolved / indirect-table-dispatch /
                                  -- indirect-llm-resolved / indirect-llm-low-confidence /
                                  -- indirect-unresolved
  source_line INTEGER,
  source_language TEXT NOT NULL,  -- 'asm' / 'cpp'
  target_language TEXT NOT NULL,  -- 'asm' / 'cpp'
  is_cross_language INTEGER NOT NULL,
  is_async INTEGER NOT NULL,      -- true for CREEC/CREMC/CREDC/CREXC/CRETC
  is_suspend INTEGER NOT NULL,    -- true for CRESC / system()
  indirection_json TEXT,          -- JSON blob from envelope_from_fields() in api/utils/indirection.py;
                                  -- NULL for direct calls. Fields: is_indirect, indirect_via,
                                  -- is_virtual_dispatch, cha_base_class. See §9.0.
  llm_rationale TEXT              -- populated only for indirect-llm-resolved /
                                  -- indirect-llm-low-confidence rows (§9.6)
);

CREATE TABLE call_edge_guard (
  guard_id TEXT PRIMARY KEY,
  edge_id TEXT NOT NULL,
  guard_kind TEXT NOT NULL,
  guard_expression TEXT,
  when_value TEXT,                -- 'true' / 'false' / 'case=X'
  source_file TEXT NOT NULL,
  source_line INTEGER,
  condition_human TEXT            -- LLM-generated business phrasing
);

-- I/O sites — hybrid detection (Layer 1/2/3).
CREATE TABLE io_site (
  io_id TEXT PRIMARY KEY,
  process TEXT NOT NULL,
  file TEXT NOT NULL,
  block TEXT NOT NULL,
  op_type TEXT NOT NULL,           -- DBRED / DBWRT / DBADD / DBMOD / DBDEL /
                                   -- DBREP / DBKEY / DBSETK / DBSPA / ...
  op_category TEXT NOT NULL,       -- READ / WRITE / UPDATE / INSERT / DELETE /
                                   -- HOLD / KEY-ACTIVATE / SCOPE-* / STORAGE-* /
                                   -- ASYNC-SPAWN / FILE-READ / FILE-WRITE
  target_record TEXT,
  target_ref TEXT,                 -- REF= operand
  key_operand TEXT,
  keys_active TEXT,                -- JSON snapshot of active DBKEY state
  hold_state TEXT,                 -- HOLD / NOHOLD / DETAC / null
  prefetch INTEGER,                -- 0/1
  commit_scope_id INTEGER,
  storage_alloc TEXT,              -- SW00WKA / GETCC-pointer / null
  source_line INTEGER,
  source_language TEXT NOT NULL,
  detection_layer TEXT NOT NULL,   -- L1-hard / L2-heuristic / L3-llm
  confidence REAL NOT NULL,
  evidence TEXT,                   -- JSON
  validated INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE io_site_variable (
  io_id TEXT NOT NULL,
  variable_name TEXT NOT NULL,
  role TEXT NOT NULL,              -- 'input' / 'output' / 'key'
  PRIMARY KEY (io_id, variable_name, role)
);

-- z/TPFDF subfile sessions — chains of io_site rows between DBOPN and DBCLS.
CREATE TABLE subfile_session (
  session_id INTEGER PRIMARY KEY,
  process TEXT NOT NULL,
  target_record TEXT NOT NULL,
  target_ref TEXT NOT NULL,
  open_io_id TEXT NOT NULL,        -- DBOPN site
  close_io_id TEXT,                -- DBCLS site (NULL if unclosed)
  hold_state TEXT,
  detac INTEGER,
  prefetch INTEGER,
  ops_count INTEGER,
  commit_scope_id INTEGER
);

-- Storage lifecycle (GETCC/RELCC/DETAC/ATTAC and equivalents).
CREATE TABLE storage_lifecycle (
  event_id TEXT PRIMARY KEY,
  process TEXT NOT NULL,
  file TEXT NOT NULL,
  block TEXT NOT NULL,
  source_line INTEGER,
  source_language TEXT NOT NULL,
  op TEXT NOT NULL,                -- GETCC / RELCC / GETFC / RELFC / RCRFC /
                                   -- DETAC / ATTAC / FINDC / FINHC / FINWC /
                                   -- FIWHC / FILEC
  level TEXT,                      -- D0..DF or DECB
  size_class TEXT,                 -- L0/L1/L2/L4
  pointer_register TEXT,           -- typically R14 after GETCC
  paired_event_id TEXT             -- matching release event, if found
);

-- Commit scopes (TXBGC/TXCMC/TXRBC and equivalents).
CREATE TABLE commit_scope (
  scope_id INTEGER PRIMARY KEY,
  process TEXT NOT NULL,
  begin_file TEXT NOT NULL,
  begin_block TEXT NOT NULL,
  begin_line INTEGER,
  end_file TEXT,
  end_block TEXT,
  end_line INTEGER,
  end_kind TEXT,                   -- commit / rollback / suspend / unclosed
  source_language TEXT NOT NULL
);

-- Variable context — 1-level-up / 1-level-down context snapshot per variable.
-- Replaces variable_footprint (removed 2026-05-28). See §4.4a for schema rationale.
-- Step 4 LLM output answers the 6-question framework (see §4.4a).
CREATE TABLE variable_context (
  process                  TEXT NOT NULL,
  name                     TEXT NOT NULL,
  declaration_file         TEXT NOT NULL,
  declaration_line         INTEGER NOT NULL,
  -- Step 1 anchor scan
  anchor_blocks_json       TEXT,  -- [{block_id, role, guards, io_ops, commit_scope, storage_lifecycle}]
  -- Step 2 (1 level down)
  down_contexts_json       TEXT,  -- [{edge_type, lang_pair, callee_file, callee_block,
                                  --   what_happens, conditions, io_ops, flows, checks, mandatory}]
  -- Step 3 (1 level up)
  up_contexts_json         TEXT,  -- [{edge_type, lang_pair, caller_file, caller_block,
                                  --   how_set, conditions_for_setting, mandatory,
                                  --   business_context, flow_context}]
  -- Step 4 LLM output — 6-question framework
  purpose                  TEXT,                 -- Q1: what it is and why it matters
  computation_source       TEXT,                 -- Q2: how computed, from which source
  availability             TEXT,                 -- Q3: always | conditional | entry-point-only | not-determined
  availability_condition   TEXT,                 -- Q3: guard/condition under which it is populated
  persistence_effects_json TEXT,                 -- Q4: [{op, target, role, mandatory, depth}]
  flow_variations_json     TEXT,                 -- Q5: [{condition, branch}]
  business_flow_context    TEXT,                 -- Q6: which named flows + role in end-to-end story
  coverage_json            TEXT,                 -- {q1..q6: full|partial|not_found}
  content_hash             TEXT,
  PRIMARY KEY (process, name, declaration_file, declaration_line)
);

CREATE TABLE variable_classification (
  process TEXT NOT NULL,
  variable TEXT NOT NULL,
  label TEXT NOT NULL,             -- business / process-io / persistence /
                                   -- control / infrastructure
                                   -- (multi-label: one row per label)
  confidence REAL,
  evidence_json TEXT,
  PRIMARY KEY (process, variable, label)
);

-- NOTE (no-duplicate-LLM rule): variable_meaning rows are populated as a
-- derived write from variable_context.purpose — NO extra LLM call.
-- After Phase 4 Step 4 persists variable_context rows, the pipeline writes:
--   INSERT OR REPLACE INTO variable_meaning(process, variable, meaning, generated_at)
--   SELECT process, name, purpose, generated_at FROM variable_context WHERE process=?
-- This means translate_to_business_language() can use variable_meaning for
-- token substitution without triggering new LLM work.
CREATE TABLE variable_meaning (
  process TEXT NOT NULL,
  variable TEXT NOT NULL,
  meaning TEXT NOT NULL,
  generated_at TEXT NOT NULL,
  PRIMARY KEY (process, variable)
);

CREATE TABLE variable_alias (
  process TEXT NOT NULL,
  variable_a TEXT NOT NULL,
  variable_b TEXT NOT NULL,
  alias_kind TEXT NOT NULL,        -- cpp-asm / ecb-field / struct-field /
                                   -- equivalent-5layer / register-bridge /
                                   -- getcc-pointer / dbifb-context
  PRIMARY KEY (process, variable_a, variable_b, alias_kind)
);

CREATE TABLE ecb_alias (
  process TEXT NOT NULL,
  ecb_field TEXT NOT NULL,
  asm_name TEXT,
  cpp_name TEXT,
  offset INTEGER,
  PRIMARY KEY (process, ecb_field)
);

CREATE TABLE walk_node (
  process TEXT NOT NULL,
  walk_id INTEGER NOT NULL,
  file TEXT NOT NULL,
  block TEXT NOT NULL,
  parent_walk_id INTEGER,
  status TEXT NOT NULL,            -- process-entry / data-path / validation /
                                   -- data-transformation / persistence-read /
                                   -- persistence-write / error-handling /
                                   -- logging / infrastructure / skipped-utility /
                                   -- async-spawn / cross-language-bridge /
                                   -- scope-boundary / revisited-in-context-X
  role_in_process TEXT,
  inputs_consumed TEXT,            -- JSON list
  outputs_produced TEXT,           -- JSON list
  condition_to_reach TEXT,         -- guard_id chain
  commit_scope_id INTEGER,
  depth INTEGER,
  PRIMARY KEY (process, walk_id)
);

-- Flow enumeration — one row per flow from entry to a producer node.
CREATE TABLE process_flow (
  flow_id TEXT PRIMARY KEY,
  process TEXT NOT NULL,
  output_kind TEXT NOT NULL,       -- process-return / ecb-global / persistence-write /
                                   -- persistence-read / async / queue-message /
                                   -- scope-commit / storage-handoff / error
  output_target TEXT,              -- e.g. LM1M1 / WA1_STAT / queue-name
  output_io_id TEXT,               -- if persistence-related
  trigger_summary TEXT,            -- LLM-generated business summary
  path_json TEXT NOT NULL,         -- ordered list of walk_id + analysis
  guards_json TEXT,                -- guards along path
  commit_scope_id INTEGER,
  truncated INTEGER NOT NULL DEFAULT 0
);

-- Business names for files, blocks, and DB records (Phase 2, one row per entity).
CREATE TABLE entity_business_name (
  process       TEXT NOT NULL,
  entity_type   TEXT NOT NULL,  -- 'file' | 'block' | 'record'
                                -- 'record' = DB record code (e.g. LM1M1 → 'Account History Record')
                                --   entity_id for records = target_record value from io_site
  entity_id     TEXT NOT NULL,  -- file_path for files;
                                --   file_path || '::' || block_id for blocks;
                                --   target_record value for records (e.g. 'LM1M1')
  business_name TEXT NOT NULL,  -- 2-5 word plain-English name
  content_hash  TEXT NOT NULL,  -- SHA-256 of the summary used to generate it
  PRIMARY KEY (process, entity_type, entity_id)
);

-- Payload lineage chains (Phase 5, artifact #8 — deterministic, no LLM).
CREATE TABLE payload_lineage (
  process          TEXT NOT NULL,
  lineage_id       TEXT PRIMARY KEY,
  root_variable    TEXT NOT NULL,
  flow_id          TEXT NOT NULL,
  steps_json       TEXT NOT NULL,      -- [{step_num, file, block, role, vars_in, vars_out, summary}]
  terminal_kind    TEXT NOT NULL,      -- persistence-write / process-return / async-spawn / ecb-write
  terminal_target  TEXT,
  terminal_io_site_id TEXT,
  content_hash     TEXT NOT NULL
);
CREATE INDEX ix_payload_lineage_root ON payload_lineage(process, root_variable);
CREATE INDEX ix_payload_lineage_flow ON payload_lineage(process, flow_id);

-- Per-commit-scope narrative and key variables (Phase 5, artifact #6).
CREATE TABLE commit_scope_narrative (
  process      TEXT NOT NULL,
  scope_id     INTEGER NOT NULL,
  narrative    TEXT NOT NULL,          -- LLM-generated business narrative
  key_variables_json TEXT NOT NULL,   -- [{name, role, significance}] ranked top-5 first
  generated_at TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  PRIMARY KEY (process, scope_id)
);

-- Process-level synthesised artifacts.
CREATE TABLE process_artifact (
  process TEXT NOT NULL,
  artifact_kind TEXT NOT NULL,     -- input-spec / output-spec / persistence-summary /
                                   -- commit-scope-summary / narrative
  payload_json TEXT NOT NULL,
  generated_at TEXT NOT NULL,
  PRIMARY KEY (process, artifact_kind)
);

-- Process walkthrough cards: card-paginated business-language description
-- (Phase 5 artifact #9). ADDED 2026-05-28. See §4.5.3 for generation pipeline.
CREATE TABLE process_narrative_card (
  process              TEXT NOT NULL,
  card_id              TEXT NOT NULL,            -- e.g. C400::card-007
  ordinal              INTEGER NOT NULL,         -- 0-based linear order
  section              TEXT NOT NULL,            -- opening|setup|main|branch|persistence|async|cleanup|closing
  section_ordinal      INTEGER NOT NULL,         -- 0-based within section
  title                TEXT NOT NULL,            -- business-language title (5-8 words)
  body                 TEXT NOT NULL,            -- 3-8 sentence narrative
  bridge_to_next       TEXT,                     -- 1-sentence transition
  key_variables_json   TEXT,                     -- [{business_name, why_it_matters}]
  conditions_json      TEXT,                     -- [{condition, outcomes}]
  io_events_json       TEXT,                     -- [{what_happens, business_target, why}]
  visualization_payload_json TEXT NOT NULL,      -- {focus_blocks, focus_edges, focus_variables, focus_io_events, neighbour_hint}
  source_block_ids_json TEXT NOT NULL,           -- audit: which walk_node rows this card covers
  untranslated_tokens_json TEXT,                 -- audit: tokens that fell through to filler phrases
  total_cards          INTEGER NOT NULL,         -- denormalized for breadcrumb
  total_sections       INTEGER NOT NULL,         -- denormalized
  generated_at         TEXT NOT NULL,
  content_hash         TEXT NOT NULL,            -- per-segment hash (see §4.5.3) for incremental rebuild
  PRIMARY KEY (process, card_id)
);
CREATE INDEX ix_narrative_card_ord ON process_narrative_card(process, ordinal);
CREATE INDEX ix_narrative_card_section ON process_narrative_card(process, section, section_ordinal);

-- Chat session memory: turn-by-turn history for session continuity.
-- ADDED 2026-05-28 (Q-C1). Enables multi-turn coherence without
-- re-sending the full KB on every request.
CREATE TABLE chat_session (
  session_id    TEXT NOT NULL,          -- UUID, client-generated per conversation
  process       TEXT NOT NULL,          -- which process this conversation is about
  turn_index    INTEGER NOT NULL,       -- 0-based ordinal within the session
  role          TEXT NOT NULL,          -- 'user' | 'assistant' | 'tool_result'
  content       TEXT NOT NULL,          -- message text; JSON string for tool results
  tool_calls    TEXT,                   -- JSON array of {name, args, result} (assistant turns only)
  created_at    TEXT NOT NULL,
  PRIMARY KEY (session_id, turn_index)
);
CREATE INDEX ix_chat_session_process ON chat_session(process, session_id);
```

---

## 11.5 Embedding + semantic retrieval infrastructure

**ADDED 2026-05-28.** The `pgvector` Python package (SQLite mode) is registered
on every SQLite connection in `backend/db.py`. All embedding calls go through
a single entry point analogous to Rule 1 for LLM calls.

### Embedding model

| Item | Value |
|---|---|
| Model | `text-embedding-004` (Google) — 768-dimensional, stable, via `google.genai` SDK |
| Entry point | `explanability_demo/backend/embedding.py::call_embedding(texts: list[str]) → list[list[float]]` |
| Batching | Up to 250 texts per API call (model limit); `ThreadPoolExecutor(4)` for pipeline-time embedding |
| Index rule | Analogous to Rule 1 — no direct `genai.embed_content` calls outside `backend/embedding.py` |

`backend/embedding.py` wraps `google.genai.embed_content(model="text-embedding-004", ...)`.
It is the ONE embedding entry point; every other module imports only this.

### pgvector adapter registration (SQLite mode)

`backend/db.py::_connect` calls `register_vector(conn)` immediately after the
existing WAL PRAGMA. This is the only place the adapter is registered.

```python
from pgvector.sqlite import register_vector
# inside _connect():
register_vector(conn)
```

`register_vector` adds `cosine_distance(v1, v2)`, `l2_distance(v1, v2)`, and
`inner_product(v1, v2)` as custom SQLite scalar functions, and registers
BLOB adapters so Python `list[float]` values are stored/retrieved as packed
`float32` bytes automatically.

Vector dimension: **768**, matching `text-embedding-004` output. Stored as
BLOB columns in regular SQLite tables — no virtual tables or extensions needed.

### Tables that carry embeddings

```sql
-- One row per chunk (block / file / process / variable).
-- BM25 retrieval uses existing chunk_fts FTS5 virtual table (unchanged).
-- ANN retrieval uses cosine_distance(embedding, ?) on the embedding BLOB column.
CREATE TABLE chunk_embedding (
  chunk_id        TEXT PRIMARY KEY,
  process         TEXT NOT NULL,
  kind            TEXT NOT NULL,       -- block | file | process | variable
  file_path       TEXT,
  block_id        TEXT,
  context_prefix  TEXT NOT NULL,       -- same structured prose as the current FTS index
  body            TEXT NOT NULL,
  embedding       BLOB,                -- float32 BLOB via pgvector.sqlite adapter
  content_hash    TEXT NOT NULL,
  built_at        TEXT NOT NULL
);
CREATE INDEX ix_chunk_emb_process ON chunk_embedding(process);

-- One row per variable — semantic similarity for few-shot classification.
CREATE TABLE variable_context_embedding (
  process             TEXT NOT NULL,
  name                TEXT NOT NULL,
  declaration_file    TEXT NOT NULL,
  declaration_line    INTEGER NOT NULL,
  embedding           BLOB,            -- float32 BLOB via pgvector.sqlite adapter
  content_hash        TEXT NOT NULL,
  PRIMARY KEY (process, name, declaration_file, declaration_line)
);

-- One row per block — semantic similarity for utility detection few-shot.
CREATE TABLE block_embedding (
  process      TEXT NOT NULL,
  file         TEXT NOT NULL,
  block        TEXT NOT NULL,
  embedding    BLOB,                   -- float32 BLOB via pgvector.sqlite adapter
  content_hash TEXT NOT NULL,
  PRIMARY KEY (process, file, block)
);
```

### Hybrid search pipeline (replaces BM25-only)

```
query text
  ├─ BM25 leg   →  FTS5 MATCH on chunk_fts (BM25 rank)             → top-50 by rank
  ├─ ANN leg    →  cosine_distance(embedding, call_embedding([q]))  → top-50 by dist
  │               ORDER BY cosine_distance ASC LIMIT 50
  └─ RRF fusion →  score = 1/(k + rank_bm25) + 1/(k + rank_ann), k=60   → top-20
       └─ LLM rerank  →  call_llm_model(RerankedIndices, top_n=5)        → top-5
```

**Reciprocal Rank Fusion (RRF, k=60)** merges FTS5 BM25 and pgvector ANN
rankings without requiring score normalisation. Originally dropped in the
current demo because there were no embeddings; now reinstated.

When the embedding index is cold (embedding IS NULL), the pipeline falls
back to BM25-only with LLM rerank — same as the current demo.

### When embeddings are built

| Phase | What gets embedded | Trigger |
|---|---|---|
| Phase 2 | `chunk_embedding` rows for every block (body = purpose + behavior) | After block summary LLM call completes; same ThreadPoolExecutor pass |
| Phase 2 | `chunk_embedding` rows for every file (body = purpose + narrative) | After file summary LLM call completes |
| Phase 2 | `chunk_embedding` for process-level chunk | After process summary |
| Phase 4 | `variable_context_embedding` for each variable | After Step 4 LLM synthesis; embedded text = `purpose` + `business_flow_context` + top-3 classification labels |
| Phase 4 | `block_embedding` for each block in the walk | After Phase 3 walk completes; embedded text = Phase 2 block purpose + Phase 3 role |

### Where embeddings are consumed

| Consumer | Purpose | Tables queried |
|---|---|---|
| Chat agent `search_chunks` tool | Hybrid retrieval for every free-form question | `chunk_fts` (BM25) + `chunk_embedding` ANN via `cosine_distance` → RRF → LLM rerank |
| §4.1.1 L3 I/O site LLM classifier | Few-shot: retrieve k=5 similar blocks already classified as io_site | `chunk_embedding` ANN via `cosine_distance` |
| §4.1.2 L3.5 utility verification | Few-shot: retrieve k=3 known-utility + k=3 known-business blocks | `block_embedding` ANN via `cosine_distance` |
| §4.4b variable classification | Few-shot: retrieve k=5 nearest classified variables as examples | `variable_context_embedding` ANN via `cosine_distance` |
| §8 guard `condition_human` quality | Few-shot: retrieve similar guard expressions from prior runs | `chunk_embedding` filtered to guard-bearing blocks |

---

## 12. API additions

**202 Accepted + poll (MANDATORY):** all build and variable-build routes
return HTTP 202 with `{"task_id": "…", "status": "pending"}`. A Redis
pending marker is written before `apply_async`. Poll via
`GET .../build/status/{task_id}`. See §19.5.2.

**Pagination (MANDATORY on all list endpoints):**
Every list endpoint accepts `?limit=50&offset=0` (max `le=200`) and returns
`{"items": [...], "total": N, "limit": 50, "offset": 0}`.

**Business name convention (Decision 2026-05-28):** every API response
that includes a file path or block ID also includes a `business_name`
field (from `entity_business_name`). Clients always receive both:

```json
{ "file": "da78.asm", "file_business_name": "Account History Processor",
  "block": "DA7_VALIDATE", "block_business_name": "Date Validation" }
```

`business_name` is `null` when the Phase 2 naming pass has not yet run
(e.g. during an in-progress build). Existing endpoints (`/walk`, `/call-edges`,
`/io-sites`, `/flows`, `/variables`, etc.) all join `entity_business_name`
before returning.

All endpoints are project-scoped: `{project_id}` is always the first path segment after `/demo/v1/projects/`.

**Project endpoints:**

| Endpoint | Returns |
|---|---|
| `GET /projects` | All projects |
| `GET /projects/{project_id}` | One project |
| `POST /projects` | Create project `{id, name, description}` |
| `GET /projects/{project_id}/processes` | Processes in this project |

**Per-process endpoints (prefix `/projects/{project_id}/processes/{P}`):**

| Endpoint | Returns |
|---|---|
| `GET .../entry` | Process entry point spec |
| `GET .../walk` | Top-down walk tree |
| `GET .../io-sites?op_category=&target_record=` | I/O sites with filters |
| `GET .../io-sites/{io_id}` | One I/O site detail |
| `GET .../subfile-sessions` | DBOPN→DBCLS sessions |
| `GET .../storage-lifecycle` | GETCC/RELCC events |
| `GET .../commit-scopes` | TX scope rows + `narrative` and `key_variables` from `commit_scope_narrative` inline |
| `GET .../commit-scopes/{scope_id}/narrative` | Full narrative + ranked key_variables for one scope |
| `GET .../call-edges?from_file=&with_guards=true` | Call edges + guards |
| `GET .../variables/{V}/footprint` | Typed BFS result |
| `GET .../variables/{V}/classification` | Labels + evidence |
| `GET .../variables?label=business` | Filter by classification label |
| `GET .../flows?output_kind=` | Flows |
| `GET .../flows/{flow_id}` | One flow with full path |
| `GET .../inputs` | Process input spec |
| `GET .../outputs` | Process output spec |
| `GET .../persistence-summary` | Phase 5 persistence-summary artifact |
| `GET .../commit-scope-summary` | Phase 5 commit-scope-summary artifact |
| `GET .../payload-lineage?root_variable=&terminal_target=` | All payload lineage chains |
| `GET .../variables/{V}/lineage` | All lineage chains for variable V |
| `GET .../narrative` | Full structured narrative — all 4 sections |
| `GET .../narrative/executive-summary` | Short summary only (for homepage card) |
| `GET .../complexity-metrics` | All 8 metrics + composite score (§4.6) |
| `GET .../walkthrough?offset=0&limit=2` | Paginated walkthrough cards + `total_cards`, `total_sections`, `section_breadcrumb`, current section progress |
| `GET .../walkthrough/sections` | Section list for the section-nav tabs |
| `GET .../walkthrough/cards/{card_id}` | Full single card (used for deep-linking) |
| `GET .../walkthrough/cards/{card_id}/visualization` | Just the visualization payload (lazy fetch) |

---

## 13. Chat agent — new tool catalogue

The agent's tool catalogue grows from 6 to ~18:

| Tool | Endpoint wrapped | Use case |
|---|---|---|
| `get_process_narrative(P, section?)` | `/narrative` (all 4 sections) or `/narrative/executive-summary` | "What does C400 do end to end?" / "Give me the full flow of C400" |
| `get_payload_lineage(P, variable?, terminal?)` | `/payload-lineage` or `/variables/{V}/lineage` | "How does WA1_DATE end up in LM1M1?" / "Show all data paths through C400" |
| `get_process_inputs(P)` | `/inputs` | "What inputs does C400 take?" |
| `get_process_outputs(P)` | `/outputs` | "What outputs does C400 produce?" |
| `get_process_flows(P, filter?)` | `/flows` | "Show flows that produce X" |
| `get_io_sites(P, op?, target?)` | `/io-sites` | "Where does C400 persist data?" |
| `get_subfile_sessions(P)` | `/subfile-sessions` | "How does C400 use the LM1M1 subfile?" |
| `get_storage_lifecycle(P)` | `/storage-lifecycle` | "Where are storage blocks allocated/released?" |
| `get_commit_scopes(P)` | `/commit-scopes` | "What's the transaction structure?" |
| `get_commit_scope_narrative(P, scope_id)` | `/commit-scopes/{scope_id}/narrative` | "What does TX scope 2 do? Which variables are key to it?" |
| `get_variable_context(P, V)` | `/variables/{V}/context` | "What is WK_RRC and why does it matter?" / "How is WK_RRC computed?" / "Is WA1_DATE always set or only under certain conditions?" / "What DB writes involve WK_RRC?" / "What flow variations does WA1_TYPE drive?" / "Where in the business flow is WK_RRC used?" |
| `get_variable_classification(P, V?)` | `/variables/{V}/classification` | "Is WK_RRC a business variable?" |
| `list_variables_by_label(P, label)` | `/variables?label=` | "Show me all business variables" |
| `get_walk_nodes(P, status?, output?)` | `/walk?filter=` | "Show validation blocks" |
| `get_call_edges(P, with_guards?, target_op?)` | `/call-edges` | "What conditions gate the DBWRT to LM1M1?" |
| `get_persistence_summary(P)` | `/persistence-summary` | "Summarise C400's persistence behaviour" |
| `search_chunks(P, query, top_k=8)` | **Hybrid retrieval (§11.5)**: FTS5 BM25 + pgvector `cosine_distance` ANN → RRF(k=60) → LLM rerank → top-5 | primary tool for all free-form questions; falls back to BM25-only when embedding IS NULL |
| `get_block_summary(P, file, block)` | existing | drill into a specific block |
| `get_complexity_metrics(P)` | `/complexity-metrics` | "How complex is C400?" / "What is the transaction scope count for C400?" / "How many DB records does C400 touch?" |
| `get_walkthrough_card(P, ordinal_or_card_id)` | `/walkthrough/cards/{card_id}` | "Walk me through step 7" / "What happens at the persistence step?" / pull a specific card from the business-language walkthrough |
| `list_walkthrough_sections(P)` | `/walkthrough/sections` | "How is C400's walkthrough structured?" / "How many cards are in the Main Flow section?" |

**Investigation seeding removed (Decision 2026-05-28).** The per-variable
investigation page has been removed; `investigation_message` rows are no
longer written or read. Chat retains access to all variable data through
the structured tools (`get_variable_context`, `get_classification`,
`list_variables_by_label`, etc.) without requiring a prior investigation
session.

---

## 13.5 Chat agent architecture (ADDED 2026-05-28)

Current implementation (Q-S2-impl): BM25-only retrieval, 6 tools, hand-rolled
ReAct JSON parser, no session memory, no query routing, no context caching.

Upgrade targets SOTA for structured-KB QA over a legacy ASM codebase. Three
tiers of increasing complexity; each tier is independently shippable.

---

### Tier 1 — Native function calling + 16-tool catalogue + ReAct hardening

**Goal:** replace the 6-tool hand-rolled loop with Gemini-native function
calling over all 16+ pipeline endpoints; add two guard rails that
prevent the most common failure modes with no new dependencies.

| Component | Current | Tier 1 |
|---|---|---|
| Tool dispatch | Hand-parsed `{"tool": ..., "args": ...}` JSON in agent loop | Gemini native `tools=` parameter; SDK parses function call blocks automatically |
| Tool count | 6 | 16+ (all §13 endpoints) |
| Reiteration | None | Agent re-states the original question at the start of each Thought step to prevent mid-chain drift |
| Critic pass | None | After final answer is drafted, one additional `call_llm` validates the answer against the retrieved facts; if contradiction found, agent retries once |
| Tool call | `call_llm_model` (string prompt) | `call_llm_model` with `tools=` kwarg (Gemini `FunctionDeclaration` list) |

**Implementation:** `backend/chat/agent.py` — replace string-matching dispatch
with `response.function_calls` iteration. Tool schemas auto-generated from
§13 endpoint contracts. Reiteration: prepend `"Original question: {q}"` to
each Thought. Critic: second `call_llm` with prompt `"Does this answer
contradict any retrieved fact? Reply YES/NO + reason."`.

**No new external dependencies.** All within `google.genai` SDK already in
the venv (Rule 1, Rule 3, Q3).

---

### Tier 2 — Query routing + session memory + Gemini context caching

**Goal:** route cheap questions to single-tool paths; maintain conversation
history without re-embedding the full KB; amortise the process KB token cost
across turns via Gemini context caching.

#### Query routing

One lightweight `call_llm` classifies the incoming question before any tool
call:

| Route | Trigger | Action |
|---|---|---|
| `direct` | question names a specific tool entity (variable/file/scope) | skip agent loop; call 1 targeted tool; format + return |
| `search` | general question answerable from chunk text | call `search_chunks` only; LLM synthesises from top-5 chunks |
| `agent` | multi-hop, comparative, or "explain path" questions | full Tier-1 agent ReAct loop |

Routing adds ~200 ms latency for direct/search routes that previously burned
2–5 full agent turns (1–3 s).

Router module: `backend/chat/router.py::classify_query(question: str, process: str) → Route`.

#### Session memory

`chat_session` table (§11) stores every turn. On each request:

1. Load last **N=10** turns from `chat_session` for `(session_id, process)`.
2. Prepend as conversation history into the Gemini `contents` list.
3. After generation, write the new user + assistant turns back.

`backend/chat/session.py::load_history(session_id, process, n=10) → list[Turn]`
`backend/chat/session.py::save_turn(session_id, process, role, content, tool_calls)`

The session_id is a client-generated UUID (no auth required; consistent with
Q4 session-local memory decision).

#### Gemini context caching

Gemini 2.5 Pro supports cached content (stable prefix). The process knowledge
base — all `chunk_embedding.body` text, variable context rows, narrative
sections — is uploaded once per process per day as a Gemini cached content
object. Subsequent turns reference the cache by `cached_content_id`; Gemini
charges cached-token reads at ~4× lower cost than full input tokens.

| Item | Detail |
|---|---|
| Cache content | All block summaries + variable context text for the process (~500k tokens for C400) |
| Invalidation | `content_hash` check on pipeline re-run; cache rebuilt if any block changed |
| Storage | `cache_id` and `expires_at` persisted in `process_artifact` (artifact_kind `'gemini_cache'`) |
| Module | `backend/chat/cache.py::get_or_create_cache(process) → cached_content_id` |

Context caching requires no new Python library (in `google.genai` SDK ≥1.5).

---

### Tier 3 — IRCoT + dynamic retrieval alpha

**Goal:** multi-hop reasoning that retrieves between steps (not just at the
start); adaptive weighting of BM25 vs. ANN legs based on query type.

#### IRCoT (Interleaved Retrieval with Chain-of-Thought)

Standard ReAct retrieves once at the start. IRCoT interleaves retrieval
*between* reasoning steps: after each Thought, the agent may call
`search_chunks` again with the refined sub-question from that Thought.

```
Turn 1  User: "How does WA1_DATE flow to LM1M1?"
  Thought 1: "Need to find WA1_DATE's classification."
  → search_chunks("WA1_DATE variable classification")
  Thought 2: "Need to find call path from C400 to LM1M1."
  → get_call_edges("C400", target_op="LM1M1")
  Thought 3: "Need payload lineage joining both."
  → get_payload_lineage("C400", "WA1_DATE")
  Answer: ...
```

IRCoT is activated only on `agent` route (Tier 2 classifier) and only when
`max_iterations > 3`. No new dependency — it is a prompting pattern inside
`backend/chat/agent.py`.

#### Dynamic retrieval alpha

The RRF fusion in §11.5 treats BM25 and ANN legs equally. Dynamic alpha
adjusts weights before fusion based on query type (detected by router):

| Query type | BM25 weight | ANN weight | Rationale |
|---|---|---|---|
| Exact identifier (variable/file name) | 0.7 | 0.3 | BM25 wins on exact-match tokens |
| Semantic / "what does X mean" | 0.3 | 0.7 | Dense wins on paraphrase |
| Mixed | 0.5 | 0.5 | Default RRF |

Implemented as `alpha` parameter to `backend/retrieval/search.py::hybrid_search`.
RRF score = `alpha * (1/(k+rank_bm25)) + (1-alpha) * (1/(k+rank_ann))`.

#### Cross-encoder reranking (pending approval)

**Decision Q-C3 (pending).** Replace the LLM rerank step in the hybrid
pipeline with a local cross-encoder (e.g., `BAAI/bge-reranker-v2-m3` via
`sentence-transformers`). A cross-encoder scores each (query, chunk) pair
directly; it is more accurate than LLM rerank for retrieval precision and
burns zero LLM tokens.

Trade-off: adds `sentence-transformers` (~500 MB model download, GPU optional).
If approved, the LLM rerank step in §11.5 is replaced; `call_llm` rerank
stays as fallback when cross-encoder is unavailable.

**Default:** LLM rerank (current §11.5 design) remains in effect until Q-C3
is explicitly approved.

---

### Architecture summary

```
User question
  │
  ▼ Tier 2: router.py
  ├─ direct  → 1 tool call → format → SSE stream
  ├─ search  → search_chunks (hybrid §11.5) → LLM synthesise → SSE stream
  └─ agent   → Tier 1 ReAct loop (native function calling)
                 ├─ reiteration: prepend original question each Thought
                 ├─ IRCoT: search_chunks between Thoughts (Tier 3)
                 ├─ up to max_iterations=8 tool calls
                 ├─ Tier 2: session history (last 10 turns) in context
                 ├─ Tier 2: Gemini cached KB prefix
                 └─ critic pass: validate answer → retry once if contradiction
```

New modules:
- `backend/chat/router.py` — query classifier (direct / search / agent)
- `backend/chat/session.py` — load_history / save_turn against `chat_session`
- `backend/chat/cache.py` — get_or_create_cache for Gemini context caching
- `backend/chat/agent.py` — upgraded from hand-rolled to native function calling + Tier 3 IRCoT

All LLM calls go through `call_llm` / `call_llm_model` (Rule 1). All
embedding calls go through `call_embedding` (Rule 1-E). No new external
Python libraries required for Tier 1 or Tier 2.

---

## 14. UI implications

See §18 Stage B for the full frontend task breakdown (dependency order,
stub endpoint mapping, component detail). Summary:

| UI surface | Change | Stage B task |
|---|---|---|
| ~~Variable detail / Investigation~~ | **Removed (Decision 2026-05-28).** Route + right-click link deleted. | B-0 |
| Variables tab | Label filter chips (`business` / `process-io` / `persistence` / `control` / `infrastructure`); `purpose` column added to each row; `block-refs` toggle stays. | B-1 |
| Process homepage | Inputs panel, Outputs panel, Persistence summary card, Commit scopes list; **executive summary card** (3–5 sentence narrative) with "Read full summary →" link | B-2 |
| Full narrative page (new route `/p/:P/narrative`) | Four collapsible sections: executive summary, **end-to-end flow narrative** (expanded by default), variable landscape, persistence footprint; plus **Payload flows tab** showing lineage chains (input → steps → output) for each process-io variable | B-2 |
| Call graph view | Edge labels show `condition_human` (tooltip); skipped-utility subgraphs faded; persistence-site nodes highlighted | B-3 |
| File detail / block list | Block status badge (`data-path` / `validation` / `persistence-write` / `error-handling` / `skipped-utility` / etc.) | B-4 |
| Flows view (new route `/p/:P/flows`) | List of flows; expandable path with per-step analysis and guard chain | B-5 |
| Persistence view (new route `/p/:P/persistence`) | I/O sites grouped by target_record; subfile-session timelines; storage lifecycle collapsible | B-6 |
| Commit-scope view (new route `/p/:P/commit-scopes`) | Horizontal timeline per scope; DB ops as tick marks; end_kind badge; **narrative card + key-variables ranked list per scope** | B-7 |
| Chat | ~10 new tools wired to stub endpoints; works on fixture data until Stage C | B-8 |
| All surfaces showing files or blocks | `technical_name (Business Name)` format everywhere — file list, call graph nodes, block list, walk nodes, flows, persistence view, variable list, commit-scope view, narrative page, breadcrumbs | B-9 |
| Process homepage — Complexity panel (new) | 8-metric dashboard: composite score badge + 4×2 metric tiles each showing value + Low/Medium/High band. Sits between the executive summary card and the inputs/outputs panels. | B-10 |
| **Process Walkthrough page (new route `/p/:P/walkthrough`)** | Card-paginated business-language walkthrough; shows 2 cards at a time; section breadcrumb at top; "Card N of M · Section · Step X of Y" progress; per-card **Visualise** button opens mini call graph modal showing just that card's blocks/edges/variables; bridge sentence + card chain peek at bottom for navigation context. | B-11 |

---

## 15. Validation strategy

Every Phase 1 wrapper ships with a validator that re-reads the source
and confirms the row is correct.

- **Call-edge validator** — open source at `(source_file, source_line)`,
  assert the line contains the claimed instruction.
- **Guard validator** — walk upwards from `source_line` to the nearest
  matching `AIF`/`CMP`/`if`, confirm guard expression matches.
- **I/O site validator (L1)** — confirm macro name + operands match.
- **I/O site validator (L2)** — confirm the heuristic signal is present.
- **I/O site validator (L3)** — confirm at least one of (write to
  non-local, call to known persistence fn, file/queue op). If none,
  downgrade to `confidence = 0`, mark `quarantined`.
- **Storage lifecycle validator** — confirm GETCC/RELCC pairing or
  flag as `unpaired`.
- **Commit scope validator** — confirm TXBGC pairs with TXCMC/TXRBC
  in the same process; otherwise mark `unclosed`.
- **Footprint validator** — confirm the variable's name (or alias)
  appears in the block's source range.
- **Walkthrough coverage validator** *(Decision 2026-05-28, §4.5.3)* —
  the union of `source_block_ids_json` across all `process_narrative_card`
  rows must equal the **eligible-walk-node set**, defined as:
  ```
  eligible = { wn ∈ walk_node[process]
               WHERE status != 'skipped-utility'
                 AND wn NOT IN walk_truncation.skipped_block_ids }
  ```
  i.e. the validator scopes to blocks the Phase 3 walk actually reached
  and decided were not utility. Truncated nodes (logged in `walk_truncation`
  when `MAX_WALK_NODES` is hit) are explicitly excluded — otherwise a
  truncated walk would fail this gate every time. Orphan blocks (eligible
  walk_nodes missing from every card's `source_block_ids_json`) and
  orphan cards (`source_block_ids_json` referencing rows not in the
  eligible set) both fail the gate. The truncation count is surfaced
  in the failure message so it's clear when the walk itself is the limit,
  not the walkthrough generator.
- **Walkthrough no-technical-names validator** *(Decision 2026-05-28, §4.5.3)* —
  scan every `title`, `body`, and `bridge_to_next` field for forbidden tokens:
  file extensions (`.asm`, `.cpp`, `.h`), macro patterns (`DB[A-Z]{3,}`, `TX[A-Z]{3}`,
  `CREE?C`, `GET[CD]C`, `RELCC`), register patterns (`R\d+`, `WA\d+`, `WK[_A-Z0-9]+`,
  `CE\d+CR\d+`), uppercase 4–8-char identifier patterns that match the
  `entity_business_name.entity_id` blacklist. Any hit fails the gate so the
  LLM never silently leaks a technical name.

Validators run as part of `pytest` and as a CI gate.

---

## 16. Reuse audit checklist (workflow per parent script)

For each parent script, the workflow is:
1. Run against C400 (and one C++-heavy process if available).
2. Capture stdout/stderr/output files.
3. Compare output to source files by hand on 5–10 samples.
4. Classify: **VERIFIED** / **NEEDS-FIX** / **PARTIAL** / **REPLACE**.
5. Wrap in `explanability_demo/backend/pipeline/parent_adapters/<name>.py`.

### Audit table

| Script / module | Status | Notes |
|---|---|---|
| `file_call_graph.py` | already in use | — |
| `process/build_process_truncated_file_graph.py` | — | — |
| `process/extract_process_guarded_file_calls.py` | — | likely centrepiece; verify guard accuracy |
| `find_call_conditions.py` | — | — |
| `get_call_conditions.py` | — | — |
| `conditional_parser.py` | — | — |
| `conditional_evaluator.py` | — | — |
| `instruction_classifier.py` | — | — |
| `operation_classifier.py` | — | — |
| `macro_classifier.py` | — | — |
| `external_call_identifier.py` | — | — |
| `passes/db_operation_extractor.py` | — | Layer-1 persistence detection |
| `passes/variable_lineage_builder.py` | — | — |
| `passes/global_lineage_stitcher.py` | — | — |
| `passes/data_flow_tracker.py` | — | — |
| `passes/cross_file_access_identity.py` | — | — |
| `passes/ecb_alias_table.py` | — | — |
| `passes/c_family_parser.py` | — | — |
| `passes/asm_line_metadata_collector.py` | — | — |
| `passes/c_line_metadata_collector.py` | — | — |
| `passes/block_extractor.py` | — | — |
| `passes/call_graph_builder.py` | — | — |
| `passes/macro_expansion_pass.py` | — | confirm runs before call_graph_builder |
| `passes/symbol_resolver.py` | — | — |
| `find_connected_variables.py` | — | propagator backbone (4 connection types: call_boundary_registers, return_registers, shared_dsects, shared_memory_fields) |
| `map_connected_variables.py` | — | builds named variable-to-variable mappings on top of find_connected_variables; verify call_boundary_register + return_register + shared_memory_field mapping types |
| `api/utils/indirection.py` | — | indirection envelope utilities: verify `envelope_from_fields` / `extract_indirection` / `merge_indirection` used consistently for ALL indirect edges |
| `api/schemas/_indirection.py` | — | IndirectionEnvelope schema — verify `extra="allow"` is preserved in wrapper |
| `find_variable_modifiers.py` | — | — |
| `build_modifier_index.py` | — | — |
| `build_variable_hop_index.py` | — | — |
| `build_variable_identity_index.py` | — | — |
| `get_equivalent_variable.py` | — | — |
| `cross_file_bridge.py` | — | 4-pattern auto-detect; verify all 4 |
| `cpp_call_chain/source_scanner.py` | — | — |
| `cpp_call_chain/index_builder.py` | — | — |
| `cpp_call_chain/traversal.py` | — | virtual/indirect/lambda — verify each |
| `trace_cpp_to_asm.py` | — | — |
| `trace_cpp_lineage.py` | — | — |
| `trace_cross_file_lineage.py` | — | — |
| `trace_lineage.py` | — | — |
| `forward_trace_lineage.py` | — | — |
| `llm/business_name.py` | `generate_business_name` | wrap only — takes file `business_summary`, returns 2–5 word name; has own cache; called once per file in Phase 2 |
| `trace_backward_cfg.py` | — | — |
| `utility_detector_v2.py` | — | Layer-1 hard rules only |
| `macro_expander.py` | — | — |
| `macro_library.py` | — | — |
| `literal_resolver.py` | — | — |
| `call_graph/topological_block_flow.py` | — | — |
| `call_graph/cross_file_flow.py` | — | — |
| `traversal/trace_variable.py` | — | — |
| `fixes/phase1_memcpy_as_assignment/` | — | — |
| `fixes/phase2_field_asm_aliases/` | — | — |
| `fixes/phase3_asm_alias_nodes/` | — | — |
| `fixes/phase4_cross_language_alias_edges/` | — | — |
| `fixes/phase5_enum_value_resolution/` | — | — |
| `fixes/phase5b_enum_conditional_tracking/` | — | — |
| `fixes/phase6_ecb_mapping/` | — | — |
| `fixes/phase7_glob_globals/` | — | — |
| `fixes/phase_tpf_regs_register_bridge/` | — | — |
| `fixes/phase_equivalent_variable_resolution/` | — | — |
| `fixes/phase_backward_traversal_cpp_bridge/` | — | — |
| `fixes/phase_backward_traversal_cpp_alias_materialization/` | — | — |
| `fixes/phase_block_flow_pipeline/` | — | — |
| `fixes/phase_variable_flow/` | — | — |
| `explainability/explain.py` | — | review against new design |
| `explainability/evidence_collector.py` | — | — |

### New audit items (specific edge-case verifications)

These were identified during the design conversations as gaps to verify
before relying on the parent detectors:

| Item | Why | Where to check |
|---|---|---|
| Indirect `BR Rx` vectored jump | `instruction_classifier` may tag as RETURN, missing the actual target | `instruction_classifier.py` + sample da78.asm jump tables |
| Macro expansion ordering | If `call_graph_builder` runs before `macro_expansion_pass`, calls inside macro bodies are missed | `passes/call_graph_builder.py` invocation order |
| C++ function pointer assigned via struct field | Indirect-call envelope may not follow through struct member of fn ptr type | `cpp_call_chain/traversal.py` indirect handling |
| C++ → ASM via inline assembly (`asm volatile`) | Rare in this codebase; if present, detectors miss | grep for `asm volatile` |
| z/TPF C library calls that internally dispatch to ASM | Some z/TPF C functions (e.g. `dfopn`) ultimately reach ASM macros | verify via `external_call_identifier.py` + IBM C→macro mapping table |
| `TMSPC`/`TMSEC` old migration linkage | If used in this codebase, must be recognised as call edges | IBM docs say "may exist for migration"; grep for occurrences |
| `EX` resolving to a branch | Executed instruction must be analysed at the EX target, not the EX line | `instruction_classifier.py` EXECUTE handling |
| `SWISC` cross-I-stream | Recognised but semantics need verification | IBM docs; verify `file_call_graph.py` SWISC handling |
| `CRESC` synchronous-suspend semantics | Walker treatment must match: follow synchronously but mark wait | IBM docs vs `file_call_graph.py` |
| z/TPFDF macros not in current catalog | Layer-1 catalog may miss `DBADR`/`DBCKP`/`DBCPY`/`DBCRE`/etc. that IBM docs list as `needs verification` | `passes/db_operation_extractor.py` + `macro_classifier.py` catalog |

---

## 17. Open decisions (need your sign-off before Phase 1)

1. ~~**Entry-point format**~~ — **LOCKED 2026-05-27.** Schema as §7, with multi-entry list support for dispatch-style processes.
2. ~~**Persistence macro list**~~ — **LOCKED 2026-05-27.** Inclusive with sub-category strategy: every macro in `macro_classifier.py` catalog is L1, each tagged with `op_category` from the §4.1.1 taxonomy. `MISC-NEEDS-VERIFY` rows surface in the Phase 0 audit dashboard.
3. ~~**Persistence ops beyond DB**~~ — **LOCKED 2026-05-27.** L1 covers DB + z/TPF file I/O family (FINDC/FINHC/FINWC/FIWHC/FILEC and C equivalents) with op_categories FILE-READ / FILE-WRITE / FILE-READ-ALLOC. Queue/message/audit ops go through L2 heuristics. GETCC COMMON=YES stays in storage_lifecycle; async spawns stay in walk.
3.5. ~~**Utility detection**~~ — **REVISED 2026-05-28.** Seven-layer scale-aware hybrid per §4.1.2: L0 path/build-system (+ DSECT-only, MACRO-only, COPY-member signals), L1 13-rule structural (+ DSECT file rule 11, pure-abstract-base rule 12, declaration-only header rule 13), L2 expanded naming, L3 cross-process generic, **L3.5 targeted LLM verification** (Trigger A: L2-only ambiguous blocks; Trigger B: io_site-on-utility safety net), L4 folded into Phase 3 walk, L5 manual override. Domain types per-process (auto-derived union, user-overridable). New tables `block_utility_classification` + `cross_process_call_index`. Designed for codebases up to 22k+ files.
4. ~~**Error-handling treatment**~~ — **LOCKED 2026-05-27.** Walk into non-utility error-handling blocks normally; tag `walk_node.status = error-handling`. Their persistence writes count as `error_outputs` in flow enumeration. Pure utility error handlers are filtered out by §4.1.2 automatically.
5. ~~**Walk caps**~~ — **LOCKED 2026-05-27.** `MAX_WALK_NODES=1500`, `MAX_DEPTH=10` for Phase 3 walk. **`MAX_FOOTPRINT_NODES` and `MAX_FOOTPRINT_DEPTH` are superseded** — variable context extraction is exactly 1 hop in each direction; no cap needed. See §4.4a.
6. ~~**Classification taxonomy**~~ — **REVISED 2026-05-28.** 5 labels (multi-label) + `is_unused` boolean: `business` / `process-io` / `persistence` / `control` / `infrastructure`. Absorbs all 17 prior labels — see §4.4b mapping table.
7. ~~**Every variable gets a footprint**~~ — **REVISED 2026-05-28.** Every variable gets a `variable_context` row (1-level-up / 1-level-down, §4.4a) instead of an unbounded BFS footprint. Same "no pre-filtering" policy applies.
8. ~~**Phase 3 LLM batching**~~ — **LOCKED 2026-05-27.** One LLM call per surviving block. Simpler, predictable, easy to stream walk progress to UI. Cost is higher but acceptable. Revisit if 22k-scale benchmarking shows it as a bottleneck.
9. ~~**Cycle handling in walk**~~ — **LOCKED 2026-05-27.** Visit per context. Each context = new `walk_node` row (walk_id monotonic). Cycle detected when same `(file, block, context_hash)` repeats. Per-`(file, block)` revisit cap = 10. Protects flow enumeration cleanliness and bounds fan-out.
10. ~~**Re-running cost & cache strategy**~~ — **LOCKED 2026-05-27.** Content-hash incremental rebuild. Every LLM-derived row carries `content_hash` of its inputs; recompute only when input hash changes; cascade to dependents. New `pipeline_version` table tracks wrapper-script versions; row produced by old version is recomputed. Extends current block-summary pattern to walk/footprint/classification.
11. ~~**Process metadata location**~~ — **LOCKED 2026-05-27.** Database table `process_meta`. Queryable, versionable, single source of truth. Edited via API (and eventually a UI), not files. Existing machine-generated `process.json` stays as the pipeline output; `process_meta` is the human-authored input layer.

Schema:

```sql
CREATE TABLE process_meta (
  process TEXT PRIMARY KEY,
  entry_json TEXT,                  -- single object or list (decision #1)
  inputs_declared_json TEXT,
  outputs_declared_json TEXT,
  domain_types_json TEXT,           -- list of DSECT/struct names
  utility_overrides_json TEXT,      -- {force_utility: [...], force_business: [...]}
  limits_json TEXT,                 -- {max_walk_nodes, max_walk_depth, max_footprint_nodes, max_footprint_depth}
  updated_at TEXT NOT NULL,
  updated_by TEXT
);
```
12. ~~**C++ virtual call without CHA hit**~~ — **LOCKED 2026-05-27.** LLM-guess from search candidates: (1) when CHA returns empty, run search-based candidate enumeration, (2) LLM given call site + declared interface + candidates + walk context picks likely targets with confidence, (3) walk follows targets with confidence ≥ 0.7, tagged `inferred-virtual`, (4) lower-confidence ones recorded as `unresolved-virtual-candidate`.
13. ~~**Async spawn treatment**~~ — **LOCKED 2026-05-27.** Terminal output. The async spawn ends that branch of the current process's walk. Spawn data recorded as `async_output` in flow enumeration. New `process_to_process_edge` table tracks the spawn relationship so chat/UI can navigate to the spawned process's separate walk. Data-handoff variables preserved per edge.
14. ~~**`SIPCC` / I-stream comms / `tpf_fork`**~~ — **LOCKED 2026-05-27.** Same terminal-output treatment as async spawn (#13), PLUS `requires_manual_review = true` set on both `walk_node` and `process_to_process_edge`. UI surfaces this prominently: "this process performs I-stream-level communication at block X; outcomes depend on platform configuration".
15. ~~**Layer 2 heuristic list**~~ — **LOCKED 2026-05-27.** 13 heuristics (H1–H13). H1–H7 cover original z/TPF / in-codebase patterns; H8–H13 add JNI bridges, protobuf, MQ, internal frameworks, REST/RPC writes, audit-channel loggers for production-scale codebases. All patterns configurable via `heuristics.json`.
16. ~~**L3 LLM gate**~~ — **LOCKED 2026-05-27.** L3 runs when (a) L1+L2 missed AND (b) block is on data-path AND (c) has write-like signal. Per-process override via `process_meta.io_detection.{force_l3_on_blocks, skip_l3}`. Bounded ~50-200 calls per process at 22k scale.

---

## 18. Implementation order (when greenlit)

**Decision 2026-05-28: Frontend-first.** All UI changes are built before the
backend pipeline runs. Stub endpoints (real schemas, fixture JSON bodies) gate
every frontend task so shapes never drift.

---

### Stage A — Stub endpoints (½–1 day, backend)

Define all Pydantic response models for every new endpoint in §12. Each
route handler returns a hardcoded fixture that matches the schema exactly.
No pipeline logic — just `return fixture_data`. This stage unblocks all
frontend work immediately.

Endpoints to stub (see §12 for full signatures). All process endpoints are under
`/projects/{project_id}/processes/{P}/` — abbreviated as `.../{P}/` below.

| Endpoint | Fixture shape |
|---|---|
| `GET /projects` | [{id:"demo", name:"Demo Project", ...}] |
| `GET /projects/{project_id}` | one project object |
| `POST /projects` | created project object |
| `GET /projects/{project_id}/processes` | same as existing process list |
| `GET .../{P}/entry` | one entry-point object |
| `GET .../{P}/walk` | 3–5 walk_node rows (mixed statuses) |
| `GET .../{P}/io-sites` | 2–3 io_site rows |
| `GET .../{P}/subfile-sessions` | 1 session |
| `GET .../{P}/storage-lifecycle` | 2 events |
| `GET .../{P}/commit-scopes` | 1 scope with inline narrative + 2 key variables |
| `GET .../{P}/commit-scopes/{scope_id}/narrative` | 1 narrative + 3 key variables |
| `GET .../{P}/call-edges?with_guards=true` | 3 edges with 1 guard each |
| `GET .../{P}/variables?label=` | filtered subset of existing variables |
| `GET .../{P}/variables/{V}/context` | 1 variable_context row |
| `GET .../{P}/variables/{V}/classification` | 2 labels |
| `GET .../{P}/flows` | 2 flows |
| `GET .../{P}/flows/{flow_id}` | 1 flow with path |
| `GET .../{P}/inputs` | 2–3 input specs |
| `GET .../{P}/outputs` | 1–2 output specs |
| `GET .../{P}/persistence-summary` | narrative artifact |
| `GET .../{P}/commit-scope-summary` | narrative artifact |
| `GET .../{P}/payload-lineage` | 2 lineage chains (WA1_DATE → LM1M1, WA1_TYPE → process-return) |
| `GET .../{P}/variables/{V}/lineage` | 1 lineage chain for V |
| `GET .../{P}/narrative` | all 4 sections with fixture prose |
| `GET .../{P}/narrative/executive-summary` | 2-sentence fixture |
| `GET .../{P}/complexity-metrics` | fixture: {file_span:16, total_blocks:800, max_call_depth:7, total_call_edges:88, conditional_branches:42, total_variables:935, cross_file_connections:24, data_path_blocks:210, composite_score:74, composite_band:"Complex"} |
| `GET .../{P}/walkthrough?offset=0&limit=2` | fixture: 4 cards (1 Opening, 1 Setup, 1 Main Flow, 1 Persistence), total_cards=4, total_sections=4, full visualization_payload on each |
| `GET .../{P}/walkthrough/sections` | fixture: 4 sections with 1 card each, card titles + ordinal ranges |
| `GET .../{P}/walkthrough/cards/{card_id}` | fixture: single card matching the above |
| `GET .../{P}/walkthrough/cards/{card_id}/visualization` | fixture: focus_blocks (2-3), focus_edges (1-2), focus_variables (2), focus_io_events (0-1), neighbour_hint |

---

### Stage B — Frontend (built against Stage A stubs)

Tasks in dependency order; each task maps to a stub endpoint(s).

**B-0 — Remove variable investigation page** *(zero backend dependency)*
- Delete route `p.$P.v.$V.investigation.$direction.tsx` and its link from the
  variable row right-click menu. No stub needed.

**B-1 — Variables tab enrichment**
- Add `purpose` column to each variable row (from `variable_meaning.meaning`
  — already produced today; no new endpoint).
- Add label filter chip strip: `business` / `process-io` / `persistence` /
  `control` / `infrastructure`. Chips filter via `GET /variables?label=` stub.
- Stub: `/projects/{project_id}/processes/{P}/variables?label=`

**B-2 — Process homepage panels**
- Add **Inputs** panel and **Outputs** panel (cards listing variable name +
  kind + description) fed from `/inputs` and `/outputs` stubs.
- Add **Persistence summary** text card from `/persistence-summary` stub.
- Add **Commit scopes** count badge / collapsible list from `/commit-scopes`
  stub.
- Stubs: `.../{P}/inputs`, `.../{P}/outputs`, `.../{P}/persistence-summary`, `.../{P}/commit-scopes`

**B-3 — Call graph enhancements**
- Each call edge: show `condition_human` as an edge label (tooltip on hover if
  long). Source: `/call-edges?with_guards=true` stub.
- Skipped-utility subgraphs: faded opacity (status = `skipped-utility` in
  walk_node). Source: `/walk` stub.
- Blocks with I/O ops: highlight node border in a persistence colour. Source:
  `/io-sites` stub cross-referenced by file+block.
- Stubs: `.../{P}/call-edges`, `.../{P}/walk`, `.../{P}/io-sites`

**B-4 — File detail / block status markers**
- Each block row / node shows its `walk_node.status` as a badge
  (`data-path` / `validation` / `persistence-write` / `error-handling` /
  `skipped-utility` / etc.).
- Stub: `.../{P}/walk`

**B-5 — Flows view (new route)**
- New route: `/p/:P/flows`
- List view: one row per flow (`output_kind`, `output_target`,
  `trigger_summary`). Expandable panel shows the ordered path with per-step
  analysis and guard chain.
- Stub: `.../{P}/flows`, `.../{P}/flows/{flow_id}`

**B-6 — Persistence view (new route)**
- New route: `/p/:P/persistence`
- Table grouped by `target_record`: all I/O sites, op_type badges, hold_state,
  commit_scope_id. Subfile sessions shown as DBOPN→…→DBCLS timeline rows.
  Storage lifecycle events in a separate collapsible.
- Stubs: `.../{P}/io-sites`, `.../{P}/subfile-sessions`, `.../{P}/storage-lifecycle`

**B-7 — Commit-scope view (new route)**
- New route: `/p/:P/commit-scopes`
- Timeline: each scope is a horizontal bar from begin_line to end_line;
  DB ops inside it shown as tick marks. `end_kind` badge (commit / rollback /
  unclosed).
- Below (or alongside) each scope's timeline: a **narrative card** showing
  the LLM-generated business narrative for that scope, and a **key variables**
  ranked list (name, role badge, one-sentence significance). Top-5 variables
  shown; "Show all" expands to full list.
- Stubs: `/commit-scopes`, `/commit-scopes/{scope_id}/narrative`

**B-9 — Business names everywhere**
- Every place a file path or block ID appears in the UI, show it as
  `technical_name (Business Name)`. `business_name` comes from the API
  response field already present on all endpoints (see §12 convention).
- Surfaces to update:
  - File list / file graph nodes
  - Call graph nodes (file) and edge labels (from_file / to_file)
  - Block list rows in file detail view
  - Walk node rows in Flows view (B-5)
  - Persistence view table (file + block columns)
  - Variable list `declaration_file` column
  - Commit-scope view (begin/end file + block)
  - Narrative page wherever files or blocks are named
  - Any breadcrumb, tooltip, or header mentioning a file or block
- If `business_name` is `null` (build in progress), show technical name
  only — no placeholder needed.
- No new stub endpoint needed — all stubs already carry the `business_name`
  field (null or fixture string) per the §12 API convention.

**B-11 — Process walkthrough page** *(largest single frontend task)*

- New route: `/p/:P/walkthrough`
- **Layout (top to bottom):**
  - **Header bar:** process technical + business name; small Complexity score chip linking back to homepage.
  - **Section breadcrumb tabs:** one clickable tab per section returned by `/walkthrough/sections` (e.g., Opening / Setup / Main Flow / Branches / Persistence / Async / Cleanup / Closing). Current section highlighted. Clicking a tab jumps to that section's first card.
  - **Progress line:** "Card N of M · Section · Step X of Y in this section."
  - **Pagination controls:** "← Previous 2" | "Next 2 →" buttons, disabled at edges. Also a "Jump to card #__" input for power users and a "View all cards" toggle that switches to a single linear scroll (one-at-a-time, infinite scroll).
  - **Two-card row:** the two visible cards rendered side-by-side on wide screens, stacked on narrow screens. Each card is a self-contained component (see below).
  - **Card-chain peek at the bottom:** small horizontal strip showing titles of cards N-1, N, N+1, N+2, N+3 with the visible pair highlighted. Lets the user see the immediate neighbourhood.

- **Each card renders:**
  - **Title** (large, business-language)
  - **Visualise button** (top-right of card) — opens a modal/sheet rendering the §4.5.3 Stage 3 spec: React Flow mini graph using `visualization_payload_json.focus_blocks` (max 20, color-coded by role) + `focus_edges` (labelled by `condition_business`); ELK top-to-bottom layout; side-panel chips for `focus_variables` (with `role_in_card` badge); inline callouts for `focus_io_events` on persistence-write nodes; small legend at top. All labels are business names — no fallback to technical IDs even if a business name is missing (show "(unnamed step)" instead).
  - **Body** (3-8 sentence paragraph)
  - **Key variables** row — chips with business names; hover tooltip shows `why_it_matters`.
  - **Conditions** list — each condition + branch outcomes in plain language.
  - **What gets persisted** chips — one chip per I/O event with business target name.
  - **Bridge sentence** at the bottom in a muted style: "↓ {bridge_to_next}" connecting to the next card.

- **Data fetching:**
  - On route mount: fetch `/walkthrough/sections` once for the tab list.
  - For the visible pair: `/walkthrough?offset={offset}&limit=2`; cards include their inline visualization payloads so Visualise modal is instant (no extra fetch).
  - URL state: `?card={ordinal}` keeps the current position deep-linkable.

- **Connection mechanism (so user knows where they are) — 4 layers:**
  1. Section breadcrumb tabs at top
  2. Linear "Card N of M" progress text
  3. Bridge sentence on each card connecting to the next
  4. Card-chain peek at bottom showing the 5-card neighbourhood

- **Empty / loading / error states:**
  - Loading: skeleton cards in the 2-card layout.
  - Empty (no walkthrough yet — pipeline still running): "Walkthrough is being generated. Try the process narrative for a high-level summary." with link to `/p/:P/narrative`.
  - Partial (some cards missing): show what we have; surface a banner about partial state.

- **Accessibility:** Left/Right arrow keys advance pagination; `v` opens the focused card's Visualise modal.

- Stubs: all 4 walkthrough endpoints from Stage A.

**B-10 — Process complexity dashboard**
- Add a **Complexity panel** to the process homepage, positioned between the
  executive summary card and the inputs/outputs panels.
- **Header row:** "Process Complexity" label + composite score badge (e.g.
  "67 / 100 — Complex") with a colour-coded band (green/yellow/orange/red for
  Simple/Moderate/Complex/Very Complex).
- **Metric grid:** 4×2 grid of metric tiles. Each tile:
  - Metric name (e.g. "Files in scope")
  - Raw value (large, bold)
  - Band badge: Low (grey) / Medium (amber) / High (red)
  - Tooltip on hover: one-sentence explanation of what this metric measures
    and why it signals complexity.
- Metric order: M1 File span, M2 Max call depth, M3 Conditional branches,
  M4 DB records touched, M5 Transaction scopes, M6 Active variables,
  M7 Payload lineage chains, M8 DB subfile sessions.
- Stub: `/complexity-metrics`
- Chat integration: `get_complexity_metrics` tool wired in B-8.

**B-8 — Chat tool catalogue wiring**
- Add ~10 new tools to the agentic-RAG tool list (§13), each calling its
  stub endpoint. The agent can now answer questions about variables,
  persistence, flows, commit scopes, and process complexity — fixture data
  only until Stage C populates real rows.
- Stubs: all Stage A endpoints (including `/complexity-metrics`)

---

### Stage C — Backend pipeline (stubs automatically replaced by real data)

Pipeline runs and writes real rows; stub handlers replaced by real DB reads.
No frontend changes needed — shapes are already stable from Stage A.

1. **Phase 0** — Reuse audit (§16). Two days max. Output: filled audit table.
2. **Phase 1a** — Conditional call graph (file level), I/O sites L1, variable lineage. Validators.
3. **Phase 1b** — Block-level conditional graph, variable identity, ECB aliases, C++↔ASM bridge.
4. **Phase 1c** — Utility detector hard rules, storage lifecycle, commit scopes.
5. **Phase 1d** — I/O sites L2 heuristics.
5a. **Complexity metrics** — Run `backend/pipeline/complexity.py` after Phase 3 (all 8 source tables populated). Writes `process_artifact` row for `'complexity_metrics'`.
6. **Phase 2** — Block summaries; embed into `chunk_embedding` (pgvector BLOB).
7. **Phase 3** — Top-down walker + relevance LLM. Tested on C400.
8. **Phase 4** — Variable context extraction; per-variable classifier; embed into `variable_context_embedding` + `block_embedding`.
9. **Phase 1e** — I/O sites L3 LLM classifier (needs Phase 3 walk to identify data-path blocks).
10. **Phase 5** — Synthesis artifacts; flow enumeration; then run `backend/pipeline/walkthrough.py::build_walkthrough_cards(process)` to generate the §4.5.3 card-paginated walkthrough (Stage 1 clustering deterministic; Stage 2 LLM parallel; Stage 3+4 deterministic). Coverage validator gates: every walked block must land in at least one card.
11. **Stub → real** — Remove fixture returns from all Stage A handlers; wire to DB queries.

---

### Stage D — Hybrid search + chat architecture upgrade (after Phase 2 embeddings exist)

#### D-1 Hybrid search

Replace BM25-only `search_chunks` with the full FTS5 BM25 + pgvector
`cosine_distance` → RRF → LLM rerank pipeline in
`backend/retrieval/search.py`. Add `backend/embedding.py` (Rule 1-E).
Wire pgvector adapter in `backend/db.py`.

#### D-2 Native function calling + reiteration + critic (Tier 1, §13.5)

1. Define Gemini `FunctionDeclaration` objects for all 16+ tools in §13.
2. Replace hand-rolled JSON dispatch in `backend/chat/agent.py` with
   `response.function_calls` iteration (no new external dep).
3. Add reiteration: prepend `"Original question: {q}"` to each Thought.
4. Add critic pass: one extra `call_llm` validates final answer against
   retrieved facts; agent retries once on contradiction.

#### D-3 Query routing + session memory (Tier 2, §13.5)

1. Implement `backend/chat/router.py::classify_query` — lightweight `call_llm`
   that returns `direct | search | agent`.
2. Implement `backend/chat/session.py` — `load_history` / `save_turn` against
   the `chat_session` table (§11).
3. Wire session_id (client UUID) into the `/chat` SSE endpoint; load last 10
   turns on every request.

#### D-4 Gemini context caching (Tier 2, §13.5)

1. Implement `backend/chat/cache.py::get_or_create_cache(process)`.
2. On first chat turn for a process, upload all block summaries + variable
   context text as a Gemini cached content object.
3. Store `cache_id` + `expires_at` in `process_artifact` (artifact_kind
   `'gemini_cache'`). Invalidate and rebuild if any `content_hash` changes.

#### D-5 IRCoT + dynamic alpha (Tier 3, §13.5)

1. Add `alpha` parameter to `backend/retrieval/search.py::hybrid_search`.
2. Router (D-3) detects query type (identifier / semantic / mixed) and sets
   alpha before calling `search_chunks`.
3. Add IRCoT to agent loop: after each Thought, allow another `search_chunks`
   call with the refined sub-question. Active only on `agent` route with
   `max_iterations > 3`.

---

## 19. Scalability — diving deeper later

Today's C400 demo: 1 process, 16 files, ~88 edges, ~800 blocks, ~935
variables. Production codebase will be 100x–1000x larger. The design
already scales sub-linearly for LLM cost because:

- Phase 1 is deterministic, O(blocks) for parsing.
- Phase 2 stays at one LLM call per block — same as today, parallel.
- Phase 3 walk's frontier is bounded by `MAX_WALK_NODES` + relevance
  pruning + utility filter. For a 3 000-node graph we expect ~100–300
  LLM calls, not 3 000.
- Phase 4 footprint BFS is deterministic. Classification is one LLM
  call per variable, parallel.
- Phase 5 is bounded — one call per artifact plus one per flow.

### Concerns to dive into later

| Concern | Today | Production-scale concern | Mitigation already in design |
|---|---|---|---|
| Walk LLM cost | ~50 calls | could be 5 000 for big process | utility filter + walk cap + relevance pruning |
| Footprint per variable | ~5 hops | could be 50+ hops | depth cap + visited cap + skip-list + dead-pointer cutoff |
| Storage growth | ~30 MB SQLite (demo) | SQLite + pgvector BLOB columns; embedding vectors add ~3 KB/chunk at 768-dim; 22k-file process ≈ ~66 MB for embeddings alone | BLOB columns sit in the same SQLite file; partition by process; archive old processes |
| Cross-process flows | N/A | process can call another process | new `process_to_process_edge` table — design extension |
| Macro library scale | small | thousands | macro_library already lazy-loads; profile |
| Multiple entry points per process | one | several conditional entries | extend `entry` to a list with guards |
| Real-time updates | rebuild whole DB | incremental on file change | content_hash already supports; needs orchestration |
| Validation coverage | sample-based | property-based + fuzzing | add later |
| Process-of-processes walk | N/A | multi-process flows | extend walk to cross `tpf_fork`/`creec` to a different process |
| Embedding index cold-start | N/A | first run has no embeddings; ANN leg empty | BM25-only fallback is wired; embeddings are built inline during Phase 2/4 so by Phase 5 the index is warm |
| ANN performance (pgvector/SQLite) | N/A | pgvector `cosine_distance` in SQLite is a flat/brute-force scan; query time scales linearly with row count | filter by `process` before ANN scan (index on `process` column); at <22k chunks flat scan is < 20 ms in-process; pre-filter to process-local rows reduces scan to <2k for typical process |

### Next-steps when going deeper

1. Performance benchmark on C400 first — per-phase LLM cost + wall-clock.
2. Generate a synthetic 100+-file process and run end-to-end.
3. Profile typed-BFS propagators; cache parent-script re-reads aggressively.
4. Add `process_to_process_edge` and a process-of-processes walk.
5. Macro expansion caching with file-hash invalidation.
6. Debug/inspect mode logging every walk pruning + BFS stop reason.

---

## 19.5 Scalability and async dispatch mandates (implementation constraints)

This section codifies the implementation rules derived from
`temp/scalability_guide.md`. Every developer touching `explanability_demo/`
must satisfy these before shipping any feature.

### 19.5.1 Celery queue topology

Three queues. Every task must be explicitly routed.

| Queue | `concurrency` | For | Examples |
|---|---|---|---|
| `q_emit` | 2 | CPU-heavy, multi-hour orchestration | `full_pipeline`, `variable_pipeline` |
| `q_io` | 4 | I/O-bound disk / DB work | `phase1_static`, `schema_migrate`, `index_rebuild` |
| `q_llm` | 2 | LLM API calls, rate-limited | `phase2_summaries`, `phase3_walk`, `phase4_variable_context`, `phase5_synthesis` |

**Celery global settings (do not override without reason):**

```python
worker_prefetch_multiplier = 1      # fetch one task at a time
worker_max_tasks_per_child = 5      # recycle worker to release heap
task_soft_time_limit       = 47 * 3600   # 47 h SIGTERM
task_time_limit            = 48 * 3600   # 48 h SIGKILL
```

**Task definition rules:**
1. Route in `celery_app.task_routes` — never rely on default queue.
2. Decorate with `ignore_result=True` if result stored in Redis / SQLite.
3. `task_id` is the first positional argument (for signal handler extraction).
4. Catch `SoftTimeLimitExceeded`; set Redis status to `"failed"`.

### 19.5.2 202 Accepted + poll pattern (MANDATORY for all build routes)

Any route that triggers pipeline work MUST:

```python
# POST /…/build
task_id = uuid.uuid4().hex
redis = get_redis()
redis.setex(f"build:{project_id}:{process}:{task_id}", 86400, '{"status":"pending"}')
run_pipeline.apply_async(args=[task_id, project_id, process], queue="q_emit")
return JSONResponse(status_code=202, content={"task_id": task_id, "status": "pending"})

# GET /…/build/status/{task_id}
raw = get_redis().get(f"build:{project_id}:{process}:{task_id}")
if raw is None:
    raise HTTPException(404, "Task not found or expired")
return json.loads(raw)
```

**Rules (non-negotiable):**
- Redis pending marker written **before** `apply_async`. If the task starts
  before the marker is written, poll returns 404 during active execution.
- TTL ≥ `task_time_limit`. Use 86 400 s (24 h) for pipeline tasks.
- 202 body includes all synchronously-available metadata (process name,
  started_at, task_id).

### 19.5.3 Per-phase progress via Redis HSET

```python
# Inside Celery task — update phase progress
redis.hset(f"pipeline:progress:{task_id}", "current_phase", "phase2")
redis.hset(f"pipeline:progress:{task_id}", "blocks_done", blocks_done)
redis.hset(f"pipeline:progress:{task_id}", "blocks_total", blocks_total)
```

Never read-modify-write a full JSON blob for progress updates. `HGET` per
field is O(1) and concurrent-safe.

The poll endpoint reads:
```python
progress = redis.hgetall(f"pipeline:progress:{task_id}")
```

### 19.5.4 Rows not blobs — storage rules

**FORBIDDEN at request time:**
- `json.loads(Path("file_call_graph.json").read_text())` on request path
- `msgpack.load(open("chain_summaries.msgpack"))` on request path
- Any `SELECT *` that returns all rows of a table that grows with codebase size

**REQUIRED:**
- All pipeline output in indexed SQLite tables with `LIMIT`/`OFFSET` queries
- Pagination on ALL list endpoints: `limit: int = Query(50, le=200)`, `offset: int = Query(0, ge=0)`
- Response schemas include `total`, `limit`, `offset` for every list response

### 19.5.5 In-process cache caps

Every module-level LRU cache MUST have an explicit `_MAX` constant enforced at write time.

```python
_CONN_CACHE_MAX = 2      # SQLite connection cache
_EMBED_CACHE_MAX = 100   # embedding result cache (small strings, safe)
```

Never cache objects whose size scales with the number of files (adjacency
dicts, full JSON graphs, full variable universes).

### 19.5.6 Redis connection pooling

```python
# backend/redis_client.py — single entry point (analogous to Rule 1)
from redis import Redis, ConnectionPool

_pool = ConnectionPool(host=settings.REDIS_HOST, port=settings.REDIS_PORT,
                       max_connections=50, decode_responses=True)

def get_redis() -> Redis:
    return Redis(connection_pool=_pool)
```

All route and task code imports `get_redis()` from this module. Never create
a bare `Redis(...)` instance in route or task code.

### 19.5.7 N+1 query prohibition

No route may issue a query per-item over a result set. Use `JOIN` or
`WHERE id IN (?)`. Batch inserts use parameterized `executemany`.

### 19.5.8 Signal handlers — mark jobs failed on worker death

Celery `task_failure` and `task_revoked` signal handlers in `celery_app.py`
must update the Redis status key to `{"status": "failed", "error": "..."}`.
This prevents jobs from staying in `"pending"` after an OOM kill.

### 19.5.9 Scalability checklist (run before every merge)

- [ ] No request-path code loads a file whose size grows with codebase size
- [ ] All new data stored in SQLite tables row-by-row (not JSON blobs on disk)
- [ ] All list endpoints have `limit` / `offset`; response has `total`
- [ ] Long operations use 202 + Celery; pending marker written before dispatch
- [ ] Redis progress uses `HSET` per field (not JSON read-modify-write)
- [ ] `get_redis()` used everywhere (not bare `Redis()`)
- [ ] No N+1 queries
- [ ] Module-level caches have explicit `_MAX` cap
- [ ] Task is routed to the correct Celery queue
- [ ] `SoftTimeLimitExceeded` caught in every Celery task

---

## 20. Glossary

| Term | Meaning |
|---|---|
| Process | A z/TPF transaction handler — one entry point, one logical business flow |
| Process entry block | The first executable block when the process is invoked |
| Block | A contiguous sequence of instructions in a file |
| Block-ref variable | Variable referenced in blocks but not formally declared |
| Formal variable | Variable in `variable_universe` |
| Footprint | Minimal set of `(file, block)` pairs needed to understand a variable |
| Typed BFS | BFS where each edge has a known type and a deterministic propagation rule |
| Propagator | A function deciding "does V cross this typed edge?" |
| Guard | A condition that must be true for an edge to fire |
| I/O site | A block containing a persistence/file/queue operation |
| Subfile session | Chain of I/O sites between matching DBOPN and DBCLS |
| Storage lifecycle event | GETCC/RELCC/DETAC/ATTAC or C equivalent |
| Commit scope | Region bounded by TXBGC and TXCMC/TXRBC |
| Walk node | One entry in the Phase 3 top-down walk |
| Flow | A path from entry to an output, with analyses attached |
| ECB | z/TPF Entry Control Block |
| DBIFB | z/TPFDF Interface Block; per-subfile context |
| SW00SR | DBIFB slot identifier |
| DSECT | ASM dummy section — layout-only structure |
| Equivalent variable | Two names referring to the same identity through aliases |
| CPROC/CALLC | IBM C-function prototype declaration / call from ASM |
| ENTRC/ENTNC/ENTDC | Cross-module ASM call (return / no-return / enter-drop) |
| BACKC | ASM return to ENTRC caller |
| CREEC/CREMC/CREDC/CREXC/CRETC | Async ECB creation macros |
| CRESC | Synchronous-suspend create |
| Active keys | DBKEY/DBSETK state that persists across DB calls |
| HOLD / NOHOLD / DETAC | DBOPN access modes affecting locking and detach behaviour |

---

## 21. Document maintenance

This document is the single source of truth for the redesign. As we make
decisions, **edit this document** rather than starting a new one. Each
change should:

- Update the relevant section in place
- Add a one-line entry at the bottom of section 21 with the date + change
- If the change affects implementation order or audit checklist, reflect
  immediately

### Change log

- 2026-05-28 — comprehensive scalability + Celery + no-duplicate-LLM + component-usage audit:
  (1) §2 added 4 new principles: Celery mandate, 202 pattern, no-duplicate-LLM, rows-not-blobs.
  (2) §4 added Celery queue routing table for all 5 phases.
  (3) §4.2 combined block summary + business name into ONE LLM call per block (extended schema).
      DB record business names added to entity_business_name with entity_type='record'.
  (4) §4.3 Phase 3 now reads from block_utility_classification table (not calls detector directly);
      added process_meta.entry_json read for entry point; added process_meta.limits_json read.
  (5) §8 condition_human: added post-Phase-3 humanizer pass (deduplicated by expression, batched).
  (6) §4.5.1 narrative: added pre-translation mandate via translate_to_business_language for sections 1-3.
  (7) §4.5.3 Stage 2: persistence segments now include commit_scope_narrative.narrative as
      transaction_context in LLM prompt and NarrativeCard.io_events. Wires commit_scope_narrative
      component into walkthrough.
  (8) §11 entity_business_name: added entity_type='record' for DB record codes.
  (9) §11 variable_meaning: added NOTE — populated from variable_context.purpose (no extra LLM call).
  (10) §12 added 202 pattern + pagination mandates.
  (11) New §19.5 "Scalability and async dispatch mandates" — comprehensive implementation constraints
       from temp/scalability_guide.md: Celery topology, 202 pattern, HSET progress, rows-not-blobs,
       cache caps, Redis pooling, N+1 prohibition, signal handlers, scalability checklist.
- 2026-05-27 — initial draft (Pratham + Claude)
- 2026-05-27 — major update: added IBM TPF/DF pattern anchoring (§5),
  hybrid I/O detection §4.1.1, language posture §4.0, flow
  enumeration completeness in Phase 5, expanded call patterns matrix §9
  with full IBM C↔ASM linkage (CALLC/CPROC/PRLGC/EPLGC/CLINKC/RLINKC/SLINKC/
  TMSPC/TMSEC) and full async-spawn family
  (CREDC/CREEC/CREMC/CRETC/CREXC/CRESC/SIPCC/system), expanded guard
  kinds §8, new tables `subfile_session`/`storage_lifecycle`/`commit_scope`/
  `process_flow`, added §13 chat tool catalogue and §19 Scalability,
  added §16 edge-case audit items
- 2026-05-27 — locked decision #1 (entry-point format §7, with multi-entry list)
- 2026-05-27 — locked decision #2 (L1 persistence macro list: inclusive with sub-category, §4.1.1)
- 2026-05-27 — locked decision #3 (persistence beyond DB: L1 covers file I/O family, §4.1.1)
- 2026-05-27 — locked decision #3.5: utility detection — six-layer scale-aware
  hybrid (§4.1.2), with `block_utility_classification` and
  `cross_process_call_index` tables. Added "Codebase-scale-agnostic by
  construction" + "Per-process semantics" to §2 principles.
- 2026-05-28 — pgvector (SQLite mode) + hybrid retrieval: SQLite remains the
  sole database; `pgvector` Python library registered via `pgvector.sqlite.register_vector`
  adds `cosine_distance` and BLOB vector serialization; new §11.5 embedding infrastructure
  (`text-embedding-004`, 768-dim, single `call_embedding` entry point Rule 1-E);
  new tables `chunk_embedding`, `variable_context_embedding`, `block_embedding`
  (each with BLOB `embedding` column); hybrid search pipeline FTS5 BM25 +
  pgvector `cosine_distance` ANN → RRF(k=60) → LLM rerank; §4.1.1 L3 and §4.1.2 L3.5
  and §4.4b variable classification all gain pgvector few-shot retrieval;
  §13 `search_chunks` updated to hybrid; §2 principle added; §19 scalability updated.
- 2026-05-28 — wired in parent-codebase mechanisms: (1) indirection envelope
  (`api/utils/indirection.py` + `api/schemas/_indirection.py`) now mandated for
  ALL indirect call edges via new §9.0; `call_edge.indirection_json` column added;
  §9.1 EX+BC jump table + BALR/BCR indirect patterns added; §9.2 C++ FP sub-patterns
  expanded; §9.6 asm_indirect_branch_resolver.py updated to use `envelope_from_fields()`.
  (2) `map_connected_variables.py` added to Phase 1 sub-tasks; Phase 4 Steps 2 and 3
  updated to use `map_connected_variables.py` for named variable resolution (not just
  connection detection); `return_register` pattern added to both Step 2 (DOWN) and
  Step 3 (UP) tables.
- 2026-05-28 — revised decision #3.5: seven-layer hybrid. Added to L0: DSECT-only
  ASM, MACRO-definition-only, COPY-member-in-syslib. Added to L1: rules 11-13
  (DSECT-only file, pure-abstract-base C++, declaration-only header). Added new
  L3.5 targeted LLM verification (Trigger A: L2-only ambiguous; Trigger B: io_site
  safety-net). Added LLM fallback for §9.6 `indirect-unresolved` (`L Rx, FIELD(Rb)`)
  → `indirect-llm-resolved` / `indirect-llm-low-confidence` call types.
- 2026-05-27 — locked decision #4 (error handling: walk + tag non-utility paths).
- 2026-05-27 — locked decision #5 (walk caps: production-scale defaults + per-process override; truncation surfaced).
- 2026-05-27 — locked decision #6 (variable taxonomy: 17 labels + is_unused flag). REVISED 2026-05-28 → 5 labels.
- 2026-05-27 — locked decision #8 (Phase 3 LLM batching: one call per block).
- 2026-05-27 — locked decision #9 (cycle handling: visit per context, 10x revisit cap).
- 2026-05-27 — locked decision #10 (caching: content-hash incremental rebuild + pipeline_version).
- 2026-05-27 — locked decision #11 (process metadata: `process_meta` DB table).
- 2026-05-27 — locked decision #12 (C++ virtual w/o CHA: LLM-guess from search candidates).
- 2026-05-27 — locked decision #13 (async spawn: terminal output + `process_to_process_edge` table).
- 2026-05-28 — business names for files and blocks: file names wrap existing
  `llm/business_name.py::generate_business_name` (parent codebase, production-ready);
  block names are new via `backend/naming.py::generate_block_business_name` (Rule 1,
  calls `call_llm_model`). Both generated in Phase 2 immediately after each summary
  LLM call; stored in new `entity_business_name` table. All API responses now include
  `file_business_name` + `block_business_name` fields. UI task B-9 added: show
  `technical_name (Business Name)` at every file/block surface. §4.2, §11, §12,
  §14, §16, §18 updated; TECH_REGISTRY updated.
- 2026-05-28 — payload lineage chains added (§4.5.2, artifact #8): forward trace
  per process-io input variable — graph traversal over Phase 3 inputs_consumed/
  outputs_produced + Phase 1 map_connected_variables.py for cross-boundary hops +
  Phase 4 classification for root/terminal identification + targeted LLM confirmation
  for ambiguous variable identity (Step 5 only). New table `payload_lineage`; new
  endpoints `/payload-lineage` + `/variables/{V}/lineage`; new chat tool
  `get_payload_lineage`; Payload flows tab added to narrative page.
  §4.5, §11, §12, §13, §14, §18 updated.
- 2026-05-28 — process narrative redesigned as 4-section structured document
  (§4.5.1): executive summary (1 LLM call), end-to-end flow narrative (1 LLM call
  from walk tree + flow summaries + guard conditions), variable landscape (1 LLM
  call on top business+persistence vars), persistence footprint (assembled
  deterministically — free). Stored as 4 `process_artifact` rows. New route
  `/p/:P/narrative`; new endpoints `/narrative` + `/narrative/executive-summary`;
  process homepage shows executive summary card. Addresses context-limit and
  readability concerns for large processes.
- 2026-05-28 — variable classification taxonomy simplified: 17 labels → 5
  (`business` / `process-io` / `persistence` / `control` / `infrastructure`).
  `business` = any variable involving business function logic. `process-io` absorbs
  all process-input/output + cross-process variants. `persistence` absorbs
  persistence-input/output + db-context + key-state + transaction-scoped.
  `control` absorbs intermediate + enum-value. `infrastructure` absorbs
  infrastructure + utility + ecb-context + pointer-alias. Multi-label and
  `is_unused` flag unchanged. §4.4b mapping table added; §11, §14, §17 updated.
- 2026-05-28 — per-scope transaction narrative: Phase 5 now generates one
  LLM call per `commit_scope` row producing a business-language narrative +
  ranked key-variables list (name, role, significance). New table
  `commit_scope_narrative`; new endpoint `GET /commit-scopes/{scope_id}/narrative`;
  new chat tool `get_commit_scope_narrative`; commit-scope view (B-7) shows
  narrative card + key-variables per scope. §4.5, §5.4, §11, §12, §13, §14, §18 updated.
- 2026-05-28 — implementation order revised: frontend-first. §18 restructured into
  Stage A (stub endpoints, ½–1 day), Stage B (8 frontend tasks B-0 through B-8),
  Stage C (backend pipeline, replaces stubs with real data), Stage D (hybrid search).
  §14 UI implications expanded to map each surface to its Stage B task and stub endpoint(s).
- 2026-05-28 — process walkthrough added as Phase 5 artifact #9 (§4.5.3).
  Card-paginated, execution-ordered, business-language description covering
  every walked block / condition / variable / I/O event with ZERO technical
  names. Generation pipeline: Stage 1 deterministic walk_node clustering →
  Stage 2 LLM card-per-segment (parallel, ~50-100 calls for C400) →
  Stage 3 deterministic visualization payload → Stage 4 persistence.
  Storage: new `process_narrative_card` table. API: 4 endpoints under
  `/walkthrough`. Chat: `get_walkthrough_card`, `list_walkthrough_sections`
  tools. UI: new route `/p/:P/walkthrough` (task B-11) — section breadcrumb +
  2-cards-at-a-time pagination + bridge sentences + card-chain peek +
  per-card Visualise button opens mini call graph modal. Two validators
  added: walkthrough coverage (no orphan blocks/cards) and no-technical-names
  scan. **Tightened same day after sanity-check (pass 1):** (1) explicit
  deterministic `segment_type` assignment rules R1–R8 (was vague "inferred
  from block_tag"), (2) deterministic `next_segment_hint` computation so
  parallel LLM calls can still write coherent `bridge_to_next` without
  knowing N+1's actual title, (3) `backend/pipeline/translate.py::translate_to_business_language()`
  pre-translation step before any text reaches the LLM — collapses the
  technical-leak failure mode from runtime validation to build-time
  guarantee, (4) explicit Visualise-modal rendering spec (color coding,
  ELK layout, side-panel variable chips, inline I/O callouts, 20-node cap
  with summary placeholder for overflow).
  **Pass 2 (deeper audit):** (A) two-tier fallback for every translation
  category — primary lookup → deterministic fallback (block_tag-derived
  phrase / op_category-derived phrase / classification-label phrase) →
  NEVER the raw technical code, (B) untranslated tokens replaced inline
  with safe filler phrases ("an unnamed item" / "performs an unspecified
  operation") so prose stays grammatical; raw token never reaches the LLM
  or the output; persisted in new `untranslated_tokens_json` column for
  maintainer follow-up, (C) `content_hash` narrowed from process-wide to
  per-segment inputs so a single block_summary change rebuilds only the
  cards that touched that block; `total_cards`/`total_sections` recomputed
  atomically at end-of-build to prevent drift, (D) coverage validator scoped
  to the eligible-walk-node set (excludes `walk_truncation.skipped_block_ids`)
  so a `MAX_WALK_NODES`-truncated walk doesn't fail the gate. §4.5, §4.5.3,
  §11, §12, §13, §14, §15, §18 updated.
- 2026-05-28 — variable context redesigned around 6-question framework (§4.4a):
  Q1 purpose+importance, Q2 computation source, Q3 availability (always vs conditional),
  Q4 persistence effects (DB/PMF), Q5 flow variations (product/status/partner/condition),
  Q6 business flow context. Step 4 LLM output now produces these 6 fields explicitly +
  a `coverage_json` object (full|partial|not_found per question) so UI and chat can
  surface "1-depth only" caveats. `variable_context` table columns renamed/restructured
  to match. Not all questions answerable for all variables; design is explicit about that.
  §4.4a, §11 `variable_context` table updated.
- 2026-05-28 — process complexity metrics added (§4.6): 8 quantitative
  dimensions (file span, max call depth, conditional branches, DB record
  surface, transaction scope count, active variable count, payload chain
  count, DB subfile sessions) + composite score 0-100. Fully deterministic,
  no LLM calls. Computed by `backend/pipeline/complexity.py`; cached in
  `process_artifact` (artifact_kind 'complexity_metrics'). New endpoint
  `GET /complexity-metrics`; new chat tool `get_complexity_metrics`; new
  UI surface B-10 (4×2 metric tile grid + composite badge on process homepage);
  Stage A stub + Stage C pipeline steps updated. §4.6, §12, §13, §14, §18 updated.
- 2026-05-28 — chat agent architecture upgraded (§13.5 added). Gap analysis vs SOTA
  identified: 6 tools → 16+ tools (already in §13), hand-rolled ReAct → native Gemini
  function calling (Tier 1), no session memory → `chat_session` table + `backend/chat/session.py`
  (Tier 2, Q-C1), no query routing → `backend/chat/router.py` direct/search/agent classifier
  (Tier 2), no context caching → Gemini cached content per process (Tier 2), no IRCoT →
  interleaved retrieval between Thoughts (Tier 3), no dynamic alpha → BM25/ANN weight
  by query type (Tier 3), cross-encoder reranking → pending decision Q-C3.
  New modules: `backend/chat/router.py`, `backend/chat/session.py`, `backend/chat/cache.py`.
  New table: `chat_session` (§11). Stage D expanded to D-1 through D-5. §11, §13.5, §18, TECH_REGISTRY updated.
- 2026-05-27 — locked decision #14 (SIPCC / I-stream / tpf_fork: same as #13 + `requires_manual_review` flag).
- 2026-05-27 — locked decision #15 (L2 heuristics: H1–H13, configurable via heuristics.json).
- 2026-05-27 — locked decision #16 (L3 LLM gate: (a)+(b)+(c) + per-process override).
- 2026-05-27 — **ALL 16 DECISIONS LOCKED.** Design ready for Phase 0 reuse audit.
