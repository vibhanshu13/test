# explanability_demo

Standalone subsystem for a business-user-facing explanation experience over
the ASM/C++ codebase. Lives entirely inside this directory — no code outside
`explanability_demo/` is modified.

## Status

| Phase | Status | Artifact |
|---|---|---|
| P0 — Fix `data/processes/C400/{file_graph, headers, macros}.json` from real lu82 chain | ✅ done | `scripts/build_process_data.py` |
| P1 — Comprehensive design + tech selections | ✅ for review | [`DESIGN.md`](./DESIGN.md) |
| P2–P9 — Implementation (backend, knowledge extraction, frontend) | ⏳ blocked on P1 review | see DESIGN §13 |

## What to read first

1. [`PROJECT_RULES.md`](./PROJECT_RULES.md) — non-negotiable rules: single `call_llm`, research-before-adoption, live validations, code-only-in-this-dir, parser-output-validation.
2. [`TECH_REGISTRY.md`](./TECH_REGISTRY.md) — every tech / tool / library / algorithm in use, with the approval id and where it's used. Single source of truth.
3. [`DESIGN.md`](./DESIGN.md) — full architecture, tech choices, phased plan, **open questions** at §14.
4. [`DEV_TRACKER.md`](./DEV_TRACKER.md) — every implementation item, per phase.
5. [`VALIDATION_TRACKER.md`](./VALIDATION_TRACKER.md) — every validation checkpoint with method, status, date.
6. [`docs/scale_and_qa_proposal.md`](./docs/scale_and_qa_proposal.md) — scale (3k+ files) and "answer anything" architecture proposal (Q-S1/2/3/4 approved 2026-05-27).
7. [`docs/p4_research.md`](./docs/p4_research.md) — Phase 4 tech research round (structured output, variable purpose extraction).
8. [`scripts/README.md`](./scripts/README.md) — how to regenerate process data for any process.

## Quick repro of Phase 0

```bash
# Regenerate the deterministic process-truncated graph (run once, idempotent):
python3 process/build_process_truncated_file_graph.py \
  --process-json process/lu82_function_processes.json \
  --guarded-json process/process_guarded_file_calls.json \
  --file-call-graph process/file_call_graph.json \
  --output process/process_truncated_file_graph.json

# Emit data/processes/C400/{file_graph,headers,macros}.json from real lu82 chain:
python3 explanability_demo/scripts/build_process_data.py --process C400 --purge
```

Output for C400 (verified): 16 files, 20 edges, full DFS trace from `lu82 →
dx750000 → dx710000 → dx730000 → dx740200 → da78 → xh80 → ...` as specified.

## Layout (current + planned)

```
explanability_demo/
├── README.md                  ← this file
├── DESIGN.md                  ← the design contract
├── scripts/
│   ├── README.md              ← how-to for data generators
│   └── build_process_data.py  ← P0 deliverable (done)
├── docs/                      ← validation reports (audit results live here)
├── backend/                   ← (planned, P2) FastAPI service
└── frontend/                  ← (planned, P5) React + Vite app
```
