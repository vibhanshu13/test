import { useEffect, useState } from 'react'
import { getToken } from './lib/auth'
import { AuthPage } from './pages/AuthPage'
import { ProjectPage } from './pages/ProjectPage'
import { LineagePage } from './pages/LineagePage'

export interface LineageTarget {
  kbId: string
  sessionId: string    // empty string = run mode (create new session via /run endpoint)
  variable: string
  chain: string[]
  isRun?: boolean      // true = use /run endpoint to generate the trace live
}

type Page = 'auth' | 'project' | 'lineage'

export default function App() {
  const [page, setPage] = useState<Page>(() => getToken() ? 'project' : 'auth')
  const [target, setTarget] = useState<LineageTarget | null>(null)

  // Re-check auth on focus (e.g., after token expiry)
  useEffect(() => {
    const onFocus = () => {
      if (!getToken() && page !== 'auth') setPage('auth')
    }
    window.addEventListener('focus', onFocus)
    return () => window.removeEventListener('focus', onFocus)
  }, [page])

  if (page === 'auth') {
    return <AuthPage onSuccess={() => setPage('project')} />
  }

  if (page === 'lineage' && target) {
    return (
      <LineagePage
        target={target}
        onBack={() => { setTarget(null); setPage('project') }}
      />
    )
  }

  return (
    <ProjectPage
      onExplain={(t) => { setTarget(t); setPage('lineage') }}
      onSignOut={() => setPage('auth')}
    />
  )
}
