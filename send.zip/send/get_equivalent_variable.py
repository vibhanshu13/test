#!/usr/bin/env python3
"""
get_equivalent_variable.py

Traces a variable's identity through a chain of assembly files to find its
equivalent name in a target downstream file.

Outputs a JSON object with:
- name: The short name (without prefix).
- full_name: The full node ID (with prefix).
- explanation: A step-by-step trace of how the variable was matched.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple


# Node kinds that represent addressable data.
# "register" is included so Strategy 6 can cross the CPP→ASM boundary when the
# landing node in the ASM file is a register:RN node (CPP-ASM Pattern F fix).
# Strategy 6b remains for the reverse ASM→CPP direction (register:RN as source).
MEMORY_KINDS: Set[str] = {"memory", "parameter", "struct_field", "variable", "register"}

# Global-lineage relation types that represent cross-file connections.
BRIDGE_RELATIONS: Set[str] = {
    "alias", "assign", "arg_bind", "bridge",
    "ecb_bridge", "level_bridge", "ce1cr_level_bridge",
}

# Module-level cache for macro DSECT table: {blueprint_dir: {field_name_upper: (dsect, byte_offset)}}
_macro_dsect_cache: Dict[str, Dict[str, Tuple[str, int]]] = {}


def _strip_macro_suffix(name: str) -> str:
    """Strip &A/&B macro parameter suffix from a name. e.g. 'LG1OSI&A' -> 'LG1OSI'."""
    idx = name.find("&")
    return name[:idx] if idx >= 0 else name


def _build_macro_dsect_table(blueprint_dir: str) -> Dict[str, Tuple[str, int]]:
    """Scan all .mac.json files in blueprint_dir and build a field->DSECT lookup table.

    Returns: {field_name_upper: (dsect_name, byte_offset)}
    """
    if blueprint_dir in _macro_dsect_cache:
        return _macro_dsect_cache[blueprint_dir]

    table: Dict[str, Tuple[str, int]] = {}
    bdir = Path(blueprint_dir)
    for mac_path in bdir.glob("*.mac.json"):
        try:
            from blueprint_io import load_blueprint as _io_load
            bp = _io_load(mac_path)
        except Exception:
            continue
        for n in bp.get("variable_lineage", {}).get("nodes", []):
            if n.get("kind") not in MEMORY_KINDS:
                continue
            meta = n.get("metadata") or {}
            dsect = meta.get("dsect")
            offset = meta.get("byte_offset")
            if dsect is None or offset is None:
                continue
            # Get the field name: strip prefix (memory:) and macro suffix (&A)
            raw_name = n["id"].split(":", 1)[1] if ":" in n["id"] else n["id"]
            stripped = _strip_macro_suffix(raw_name).upper()
            dsect_stripped = _strip_macro_suffix(dsect)
            if stripped not in table:
                table[stripped] = (dsect_stripped, offset)

    _macro_dsect_cache[blueprint_dir] = table
    return table


def load_blueprint(bdir: str, name: str) -> Optional[dict]:
    from blueprint_io import load_blueprint as _io_load
    for suffix in (f"{name}.asm.json", f"{name}.cpp.json"):
        p = Path(bdir) / suffix
        if p.exists():
            return _io_load(p)
    return None


def _mem_node_ids(vl: dict) -> Set[str]:
    """Return IDs of all memory-class nodes in a variable_lineage section."""
    return {
        n["id"]
        for n in vl.get("nodes", [])
        if n.get("kind") in MEMORY_KINDS
    }


def get_physical_identity(
    bp: dict, node_id: str, blueprint_dir: Optional[str] = None,
) -> Tuple[Optional[str], Optional[int], Optional[str], Optional[str]]:
    """Resolve the physical address of a node.

    Returns ``(dsect, byte_offset, access_identity, symbolic_identity)``.

    If dsect/byte_offset are not found on the node or its edges and blueprint_dir
    is provided, falls back to the macro DSECT table built from .mac.json files.
    """
    if not bp:
        return None, None, None, None

    vl = bp.get("variable_lineage", {})
    nodes = vl.get("nodes", [])
    edges = vl.get("edges", [])

    dsect: Optional[str] = None
    offset: Optional[int] = None
    access_id: Optional[str] = None
    symbolic_id: Optional[str] = None

    for n in nodes:
        if n["id"] == node_id:
            meta = n.get("metadata", {})
            dsect = meta.get("dsect") or meta.get("cpp_struct")
            offset = meta.get("byte_offset")
            access_id = meta.get("access_identity")
            if access_id:
                return dsect, offset, access_id, symbolic_id
            break

    for e in edges:
        if e.get("source") == node_id or e.get("target") == node_id:
            aid = e.get("access_identity")
            si = e.get("symbolic_identity")
            if si and symbolic_id is None:
                symbolic_id = si
            if aid:
                return (
                    e.get("dsect") or dsect,
                    e.get("field_offset") if e.get("field_offset") is not None else offset,
                    aid,
                    symbolic_id,
                )
            if dsect is None and e.get("dsect"):
                dsect = e.get("dsect")
            if offset is None and e.get("field_offset") is not None:
                offset = e.get("field_offset")

    # Fallback: look up in macro DSECT table if local metadata is incomplete
    if dsect is None and offset is None and blueprint_dir:
        short_name = node_id.split(":", 1)[1] if ":" in node_id else node_id
        table = _build_macro_dsect_table(blueprint_dir)
        entry = table.get(short_name.upper())
        if entry:
            dsect, offset = entry

    return dsect, offset, access_id, symbolic_id


def _get_ecb_field(bp: dict, node_id: str) -> Optional[str]:
    """Return the ecb_field metadata value for a node, or None."""
    if not bp:
        return None
    for n in bp.get("variable_lineage", {}).get("nodes", []):
        if n["id"] == node_id:
            return (n.get("metadata") or {}).get("ecb_field")
    return None


def _collect_ecb_field_map(bp: dict) -> Dict[str, Set[str]]:
    """Build a map: ecb_field -> set of memory node IDs in this blueprint."""
    vl = bp.get("variable_lineage", {})
    mem_ids = _mem_node_ids(vl)
    efmap: Dict[str, Set[str]] = {}
    for n in vl.get("nodes", []):
        nid = n["id"]
        if nid not in mem_ids:
            continue
        ef = (n.get("metadata") or {}).get("ecb_field")
        if ef:
            efmap.setdefault(ef, set()).add(nid)
    return efmap


def _collect_access_identities(bp: dict) -> Dict[str, Set[str]]:
    vl = bp.get("variable_lineage", {})
    nodes = vl.get("nodes", [])
    edges = vl.get("edges", [])
    mem_ids = _mem_node_ids(vl)

    aid_map: Dict[str, Set[str]] = {}

    for n in nodes:
        nid = n["id"]
        if nid not in mem_ids:
            continue
        aid = (n.get("metadata") or {}).get("access_identity")
        if aid:
            aid_map.setdefault(aid, set()).add(nid)

    for e in edges:
        aid = e.get("access_identity")
        if not aid:
            continue
        for side in ("source", "target"):
            nid = e.get(side)
            if nid and nid in mem_ids:
                aid_map.setdefault(aid, set()).add(nid)

    return aid_map


def _collect_symbolic_identity_map(bp: dict) -> Dict[str, Set[str]]:
    """Build a map: symbolic_identity → set of memory node IDs.

    symbolic_identity format: ``"DSECT:FIELD_NAME"``, e.g. ``"LG1G1:LG1OSI"``.
    """
    vl = bp.get("variable_lineage", {})
    mem_ids = _mem_node_ids(vl)
    smap: Dict[str, Set[str]] = {}
    for e in vl.get("edges", []):
        si = e.get("symbolic_identity")
        if not si:
            continue
        for side in ("source", "target"):
            nid = e.get(side)
            if nid and nid in mem_ids:
                smap.setdefault(si, set()).add(nid)
    return smap


def _collect_dsect_offset_map(
    bp: dict, blueprint_dir: Optional[str] = None,
) -> Dict[Tuple[str, int], Set[str]]:
    vl = bp.get("variable_lineage", {})
    nodes = vl.get("nodes", [])
    edges = vl.get("edges", [])
    mem_ids = _mem_node_ids(vl)

    dmap: Dict[Tuple[str, int], Set[str]] = {}

    # Load macro DSECT table for fallback enrichment
    macro_table = _build_macro_dsect_table(blueprint_dir) if blueprint_dir else {}

    for n in nodes:
        nid = n["id"]
        if nid not in mem_ids:
            continue
        meta = n.get("metadata", {})
        d = meta.get("dsect") or meta.get("cpp_struct")
        o = meta.get("byte_offset")
        # Fallback to macro DSECT table if metadata is missing
        if (d is None or o is None) and macro_table:
            short = nid.split(":", 1)[1] if ":" in nid else nid
            entry = macro_table.get(short.upper())
            if entry:
                if d is None:
                    d = entry[0]
                if o is None:
                    o = entry[1]
        if d and o is not None:
            dmap.setdefault((d, o), set()).add(nid)

    for e in edges:
        d = e.get("dsect")
        o = e.get("field_offset")
        if not d or o is None:
            continue
        for side in ("source", "target"):
            nid = e.get(side)
            if nid and nid in mem_ids:
                dmap.setdefault((d, o), set()).add(nid)

    return dmap


def find_match_in_file(
    prev_bp: Optional[dict],
    curr_bp: dict,
    prev_name: str,
    target_dsect: Optional[str],
    target_offset: Optional[int],
    target_access_id: Optional[str],
    target_ecb_field: Optional[str] = None,
    blueprint_dir: Optional[str] = None,
    target_symbolic_id: Optional[str] = None,
) -> Tuple[Optional[str], Optional[str]]:
    """Returns (node_id, strategy_name) or (None, None)."""
    vl = curr_bp.get("variable_lineage", {})
    mem_nodes = _mem_node_ids(vl)

    # Strategy 0.5: SPAWN parameter bridge — CREEC spawn arg resolves to CE1CR0 receiver.
    # arg@callee:SPAWN1 → CE1CR0, SPAWN2 → CE1CR1, etc. (1-based index → 0-based level)
    _spawn_m = re.search(r':SPAWN(\d+)$', prev_name, re.IGNORECASE)
    if _spawn_m:
        spawn_idx = int(_spawn_m.group(1))
        ce_level = spawn_idx - 1
        ce1cr = f"CE1CR{format(ce_level, 'X')}"
        if ce1cr in mem_nodes:
            return ce1cr, "SPAWN Parameter Bridge"
        level_name = f"D{format(ce_level, 'X')}"
        if level_name in mem_nodes:
            return level_name, "SPAWN Level Bridge"

    # Strategy 1: Parameter Bridge
    if "caller_param" in prev_name and prev_name in mem_nodes:
        return prev_name, "Parameter Bridge"

    # Strategy 2: Access Identity Match
    if target_access_id:
        aid_map = _collect_access_identities(curr_bp)
        candidates = aid_map.get(target_access_id, set())
        if candidates:
            if prev_name in candidates:
                return prev_name, "Access Identity Match (Name + CE-slot)"
            return sorted(candidates)[0], "Access Identity Match (CE-slot)"

    # Strategy 2.5: Symbolic Identity Match (DSECT:FIELD_NAME)
    if target_symbolic_id:
        smap = _collect_symbolic_identity_map(curr_bp)
        candidates = smap.get(target_symbolic_id, set())
        if candidates:
            if prev_name in candidates:
                return prev_name, "Symbolic Identity Match (Name + DSECT:Field)"
            return sorted(candidates)[0], "Symbolic Identity Match (DSECT:Field)"

    # Strategy 3: ECB Field Match
    if target_ecb_field:
        efmap = _collect_ecb_field_map(curr_bp)
        candidates = efmap.get(target_ecb_field, set())
        if candidates:
            if prev_name in candidates:
                return prev_name, "ECB Field Match (Name + ecb_field)"
            return sorted(candidates)[0], "ECB Field Match"

    # Strategy 4: Direct Name Match
    if prev_name in mem_nodes:
        d, o, curr_aid, _ = get_physical_identity(curr_bp, prev_name, blueprint_dir)
        if target_access_id and curr_aid:
            if curr_aid == target_access_id:
                return prev_name, "Direct Name Match (CE-slot confirmed)"
        elif target_dsect and target_offset is not None and d and o is not None:
            if d == target_dsect and o == target_offset:
                return prev_name, "Direct Name Match (DSECT+Offset confirmed)"
        else:
            return prev_name, "Direct Name Match"

    # Strategy 5: DSECT + Offset
    if target_dsect and target_offset is not None:
        dmap = _collect_dsect_offset_map(curr_bp, blueprint_dir)
        candidates = dmap.get((target_dsect, target_offset), set())
        if candidates and target_access_id:
            filtered = set()
            for c in candidates:
                _, _, c_aid, _ = get_physical_identity(curr_bp, c, blueprint_dir)
                if c_aid is None:
                    filtered.add(c)
            candidates = filtered
        if candidates:
            match = prev_name if prev_name in candidates else sorted(candidates)[0]
            return match, "DSECT + Offset"

    # Strategy 6: Global Alias / Bridge
    if prev_bp:
        gl_prev = prev_bp.get("global_variable_lineage", {}).get("edges", [])
        gl_curr = curr_bp.get("global_variable_lineage", {}).get("edges", [])
        for edge in gl_prev + gl_curr:
            rel = edge.get("relation")
            if rel not in BRIDGE_RELATIONS:
                continue
            src, tgt = edge.get("source"), edge.get("target")
            # Forward: our variable is the source, target is the equivalent
            if src == prev_name and tgt in mem_nodes:
                return tgt, f"Global {rel.capitalize()}"
            # Reverse: our variable is the target — only valid for symmetric
            # relations (alias, bridge). For directional relations like assign,
            # reverse means "src was assigned TO our var" — src is a predecessor,
            # not an equivalent.
            if tgt == prev_name and src in mem_nodes and rel != "assign":
                return src, f"Global {rel.capitalize()}"

    # Strategy 6b: cross-language register-projection bridge.
    # Fires only when the current node is a register (ASM→CPP boundary).
    # Looks for a GVL alias connecting prev_name to a register:arg@CALLEE:RN
    # node, then walks backward through curr_bp's local variable_lineage to
    # find the MEMORY_KINDS source (e.g. struct_field:fn::regs.r1) that fed it.
    if prev_bp and prev_name.startswith("register:"):
        _gl = (
            prev_bp.get("global_variable_lineage", {}).get("edges", [])
            + curr_bp.get("global_variable_lineage", {}).get("edges", [])
        )
        _arg_node: Optional[str] = None
        for _e in _gl:
            if _e.get("relation") != "alias":
                continue
            _s, _t = _e.get("source", ""), _e.get("target", "")
            if _t == prev_name and "arg@" in _s:
                _arg_node = _s
                break
            if _s == prev_name and "arg@" in _t:
                _arg_node = _t
                break
        if _arg_node:
            for _e in curr_bp.get("variable_lineage", {}).get("edges", []):
                if _e.get("target") != _arg_node:
                    continue
                if _e.get("relation") not in ("assign", "arg_bind"):
                    continue
                _src = _e.get("source", "")
                if _src.split(":", 1)[0] in MEMORY_KINDS:
                    return _src, "Register Projection Bridge"

    return None, None


def resolve_node_id(bp: dict, name: str) -> str:
    if not bp: return name
    vl = bp.get("variable_lineage", {})
    nodes = vl.get("nodes", [])
    for n in nodes:
        if n["id"] == name: return name
    for n in nodes:
        if n.get("name") == name: return n["id"]
    for kind in MEMORY_KINDS:
        prefixed = f"{kind}:{name}"
        for n in nodes:
            if n["id"] == prefixed: return prefixed
    return name


def strip_prefix(node_id: str) -> str:
    return node_id.split(":", 1)[1] if ":" in node_id else node_id


def _get_base_reg_for_variable(bp: dict, node_id: str) -> Optional[str]:
    """Return the base register used to access node_id in bp, or None if not found.

    Scans edges in the variable lineage for any edge where the node appears as
    source or target and has a non-empty ``base_reg`` field.
    """
    for edge in bp.get("variable_lineage", {}).get("edges", []):
        if edge.get("source") == node_id or edge.get("target") == node_id:
            br = edge.get("base_reg")
            if br:
                return br
    return None


def _check_register_carry_safety(
    curr_bp: dict,
    base_reg: str,
    target_dsect: Optional[str],
    target_access_id: Optional[str],
) -> Tuple[bool, str]:
    """Check if carrying a register-based variable identity through curr_bp is safe.

    Implements the 5-point register liveness rule:

    1. Check whether the register is preserved across the call boundary.
    2. Check whether the callee USING changes the register's DSECT mapping.
    3. Check whether the callee writes a new value into the register before USING.
    4. Kill the carried identity if any of checks 1-3 indicate the register changed.
    5. CE-slot variables (access_identity starting with CE1CR) are always safe —
       CE registers are architectural constants loaded from the TCB.

    Returns:
        (kill, reason) — kill=True means the identity chain should be broken.
    """
    # Rule 5: CE-slot exception — architectural CE registers always carry safely
    if target_access_id and target_access_id.upper().startswith("CE1CR"):
        return False, f"CE register identity ({target_access_id}) — always safe"

    entry_state = curr_bp.get("register_entry_state", {})
    inherited = entry_state.get("inherited_regs", [])
    self_loaded = entry_state.get("self_loaded_regs", [])

    # Rule 3: callee self-loaded the register before its first USING → identity overwritten
    if base_reg in self_loaded:
        return True, (
            f"callee self-loaded {base_reg} before USING — identity overwritten"
        )

    if base_reg in inherited:
        # Rule 2: if the callee establishes a USING for base_reg with a different
        # DSECT than expected, the register's base meaning has changed → kill
        if target_dsect:
            line_meta = curr_bp.get("line_metadata", {})
            sorted_lines = sorted(
                line_meta.items(),
                key=lambda x: int(x[0]) if x[0].isdigit() else 0,
            )
            for _line_str, snap in sorted_lines:
                if isinstance(snap, dict):
                    active_usings = snap.get("active_usings", {})
                    if base_reg in active_usings:
                        callee_dsect = active_usings[base_reg]
                        if callee_dsect.upper() != target_dsect.upper():
                            return True, (
                                f"callee USING {base_reg},{callee_dsect} conflicts with "
                                f"expected {target_dsect} — base meaning changed"
                            )
                        break
        # Rule 1: register was inherited from caller and DSECT is consistent → safe
        return False, f"{base_reg} inherited from caller — identity carried safely"

    # No register_entry_state data available (old blueprint or non-USING file) —
    # be conservative and allow the carry rather than breaking valid chains.
    return False, "no register entry state — carrying conservatively"


def resolve_equivalent_variable(
    chain: List[str],
    target_stem: str,
    variable: str,
    blueprint_dir: str,
) -> Optional[str]:
    """Return the local name of `variable` in `target_stem`, or None if unresolvable.

    `chain` is an ordered list of file stems leading up to (but not including)
    `target_stem` — the first entry is the file where `variable` is already known.
    """
    if not chain:
        return None

    full_chain = list(chain) + [target_stem]

    origin_bp = load_blueprint(blueprint_dir, full_chain[0])
    if not origin_bp:
        return None

    current_name = resolve_node_id(origin_bp, variable)
    target_dsect, target_offset, target_access_id, target_symbolic_id = get_physical_identity(
        origin_bp, current_name, blueprint_dir,
    )
    target_ecb_field = _get_ecb_field(origin_bp, current_name)

    prev_bp = origin_bp

    for i in range(1, len(full_chain)):
        file_stem = full_chain[i]
        is_final = (i == len(full_chain) - 1)
        curr_bp = load_blueprint(blueprint_dir, file_stem)

        if not curr_bp:
            if is_final:
                return None
            continue

        match, _ = find_match_in_file(
            prev_bp, curr_bp, current_name,
            target_dsect, target_offset, target_access_id,
            target_ecb_field, blueprint_dir, target_symbolic_id,
        )

        if match:
            current_name = match
            d, o, aid, si = get_physical_identity(curr_bp, current_name, blueprint_dir)
            if aid:
                target_access_id = aid
            if si:
                target_symbolic_id = si
            if d and o is not None:
                target_dsect, target_offset = d, o
            ef = _get_ecb_field(curr_bp, current_name)
            if ef:
                target_ecb_field = ef
            prev_bp = curr_bp
        else:
            has_identity = (
                target_access_id
                or target_symbolic_id
                or (target_dsect and target_offset is not None)
            )
            if is_final or not has_identity:
                return None
            # Register liveness check: only carry identity if the base register
            # is still live and unmodified in the intermediate file.
            base_reg = _get_base_reg_for_variable(prev_bp, current_name)
            if base_reg:
                kill, _reason = _check_register_carry_safety(
                    curr_bp, base_reg, target_dsect, target_access_id
                )
                if kill:
                    return None

    return strip_prefix(current_name)


def main():
    parser = argparse.ArgumentParser(description="Find equivalent variable name.")
    parser.add_argument("--flow", required=True, help="File chain (comma-separated)")
    parser.add_argument("--current", required=True, help="Target file")
    parser.add_argument("--variable", required=True, help="Origin variable name/ID")
    parser.add_argument("--blueprint-dir", required=True, help="Blueprint directory")
    parser.add_argument("--verbose", action="store_true", help="Print debug to stderr")
    args = parser.parse_args()

    chain = args.flow.split(",") + [args.current]
    verbose = args.verbose
    explanation_steps = []

    # 1. Establish Origin
    origin_bp = load_blueprint(args.blueprint_dir, chain[0])
    if not origin_bp:
        print(json.dumps({
            "name": None, "full_name": None,
            "explanation": f"Blueprint not found for origin: {chain[0]}"
        }, indent=2))
        return

    current_name = resolve_node_id(origin_bp, args.variable)
    target_dsect, target_offset, target_access_id, target_symbolic_id = get_physical_identity(
        origin_bp, current_name, args.blueprint_dir,
    )
    target_ecb_field = _get_ecb_field(origin_bp, current_name)
    explanation_steps.append(f"Started at {chain[0]} with {current_name}")

    prev_bp = origin_bp

    # 2. Walk the Chain
    for i in range(1, len(chain)):
        file_stem = chain[i]
        is_final = (i == len(chain) - 1)
        curr_bp = load_blueprint(args.blueprint_dir, file_stem)

        if not curr_bp:
            explanation_steps.append(f"Skipped {file_stem} (blueprint missing)")
            continue

        match, strategy = find_match_in_file(
            prev_bp, curr_bp, current_name,
            target_dsect, target_offset, target_access_id,
            target_ecb_field, args.blueprint_dir, target_symbolic_id,
        )

        if match:
            old_name = current_name
            current_name = match
            explanation_steps.append(f"Matched in {file_stem} as {current_name} via {strategy}")

            d, o, aid, si = get_physical_identity(curr_bp, current_name, args.blueprint_dir)
            if aid: target_access_id = aid
            if si: target_symbolic_id = si
            if d and o is not None: target_dsect, target_offset = d, o
            ef = _get_ecb_field(curr_bp, current_name)
            if ef: target_ecb_field = ef
            prev_bp = curr_bp
        else:
            has_identity = (
                target_access_id
                or target_symbolic_id
                or (target_dsect and target_offset is not None)
            )
            if is_final or not has_identity:
                reason = "target file reached" if is_final else "identity trail went cold"
                explanation_steps.append(f"Trail stopped at {file_stem} ({reason})")
                print(json.dumps({
                    "name": None, "full_name": None,
                    "explanation": "; ".join(explanation_steps)
                }, indent=2))
                return
            # Register liveness check before carrying identity forward
            base_reg = _get_base_reg_for_variable(prev_bp, current_name)
            if base_reg:
                kill, kill_reason = _check_register_carry_safety(
                    curr_bp, base_reg, target_dsect, target_access_id
                )
                if kill:
                    explanation_steps.append(
                        f"Trail killed at {file_stem}: {kill_reason}"
                    )
                    print(json.dumps({
                        "name": None, "full_name": None,
                        "explanation": "; ".join(explanation_steps)
                    }, indent=2))
                    return
            explanation_steps.append(f"Carried identity through {file_stem} (not referenced here)")

    # 3. Success
    print(json.dumps({
        "name": strip_prefix(current_name),
        "full_name": current_name,
        "explanation": "; ".join(explanation_steps)
    }, indent=2))


if __name__ == "__main__":
    main()