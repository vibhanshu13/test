"""Single file analyzer for Phase 1 of multi-file analysis."""
import logging
import os
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

_log = logging.getLogger(__name__)
_SLOW_FILE_THRESHOLD: float = float(os.environ.get("SLOW_FILE_THRESHOLD_SECONDS", "10"))
from file_reader import FileReader
from statement_id_generator import StatementIDGenerator
from passes.symbol_resolver import SymbolResolverPass
from passes.call_graph_builder import CallGraphBuilderPass
from passes.data_flow_tracker import DataFlowTracker
from passes.db_operation_extractor import DBOperationExtractorPass
from passes.file_dependency_builder import FileDependencyBuilderPass
from passes.block_extractor import BlockExtractorPass
from passes.variable_lineage_builder import VariableLineageBuilder
from passes.asm_line_metadata_collector import ASMLineMetadataCollector
from passes.line_metadata_enricher import LineMetadataEnricher
from models.analysis_context import AnalysisContext, Statement
from models.symbol import SymbolType, SymbolTable
from models.call_graph import CallGraph
from models.line_metadata import LineMetadataIndex
from asm_scope import annotate_provenance_scope
from passes.asm_meta_collector import ASMMetaCollectorPass


@dataclass
class FileAnalysisResult:
    """Result of analyzing a single file."""
    file_path: Path
    exports: List[str]  # ENTRY symbols
    imports: List[str]  # EXTRN/WXTRN symbols
    sections: List[str]  # CSECT/DSECT names
    symbol_table: SymbolTable
    call_graph: Optional[CallGraph]
    analysis_context: AnalysisContext


class SingleFileAnalyzer:
    """Analyzes a single assembly file independently."""

    def __init__(self, search_paths: List[Path]):
        """
        Initialize single file analyzer.

        Args:
            search_paths: Directories to search for COPY includes
        """
        self.search_paths = search_paths

    def analyze(self, file_path: Path, file_content: str) -> FileAnalysisResult:
        """
        Analyze a single assembly file.

        Args:
            file_path: Path to the file
            file_content: Content of the file

        Returns:
            Analysis results for the file
        """
        _t0 = time.perf_counter()
        _log.debug("SingleFileAnalyzer.analyze start: %s", file_path)
        # Parse file
        id_gen = StatementIDGenerator()
        reader = FileReader(id_gen, search_paths=[str(p) for p in self.search_paths])

        # Initialize line metadata collector
        line_collector = ASMLineMetadataCollector()

        # Write content to temp location for reading
        temp_path = None
        with tempfile.NamedTemporaryFile(mode='w', suffix='.asm', delete=False) as f:
            f.write(file_content)
            temp_path = Path(f.name)

        try:
            # FileReader.read_file returns an Iterator, we need to convert to list
            parsed_lines = list(reader.read_file(str(temp_path)))
            # Preserve real source path in provenance instead of temp file path.
            for line in parsed_lines:
                line.provenance.original_file = str(file_path)
            # Populate routine/section context for downstream passes (e.g., lineage scope).
            # Also collect line metadata during this process
            annotate_provenance_scope(parsed_lines, line_collector, file_path)
        finally:
            if temp_path and temp_path.exists():
                temp_path.unlink()

        # Run analysis passes
        context = AnalysisContext(file_path=file_path)

        # Heuristic: mark pure macro-library files using parsed opcodes.
        # This avoids comment-text false positives (e.g., "entry point" in comments).
        opcodes = {(line.opcode or "").upper() for line in parsed_lines if line.opcode}
        has_macro = "MACRO" in opcodes
        has_mend = "MEND" in opcodes
        has_anchor = bool(opcodes.intersection({"CSECT", "DSECT", "RSECT", "ENTRY"}))
        if has_macro and has_mend and not has_anchor:
            context.add_metadata("is_macro_library", True)

        # Store statements for downstream passes (e.g., macro expansion)
        for line in parsed_lines:
            if line.opcode:
                operands = ",".join(line.operands) if line.operands else ""
                context.statements.append(Statement(
                    line_num=line.provenance.original_line,
                    label=line.label or "",
                    opcode=line.opcode,
                    operands=operands
                ))

        symbol_pass = SymbolResolverPass()
        symbol_pass.process(parsed_lines, context)

        asm_meta_pass = ASMMetaCollectorPass()
        asm_meta_pass.process(parsed_lines, context)

        call_graph_pass = CallGraphBuilderPass()
        call_graph_pass.process(parsed_lines, context)

        data_flow_pass = DataFlowTracker()
        data_flow_pass.process(parsed_lines, context)

        db_pass = DBOperationExtractorPass()
        db_pass.process(parsed_lines, context)

        lineage_pass = VariableLineageBuilder()
        lineage_pass.process_assembly(parsed_lines, context)

        file_dep_pass = FileDependencyBuilderPass()
        file_dep_pass.process(context)

        block_extractor_pass = BlockExtractorPass()
        block_extractor_pass.process(parsed_lines, context)

        # Extract exports and imports
        exports = self._extract_exports(context.symbol_table)
        imports = self._extract_imports(context.symbol_table)
        sections = self._extract_sections(context.symbol_table)

        # Get call_graph from metadata
        call_graph = context.get_metadata("call_graph")

        # Create and populate line metadata index
        line_metadata_index = LineMetadataIndex()
        for metadata in line_collector.metadata_list:
            line_metadata_index.add(metadata)
        context.line_metadata_index = line_metadata_index

        # Enrich line metadata with call information from CallGraph
        if call_graph and line_metadata_index:
            enricher = LineMetadataEnricher(call_graph, line_metadata_index)
            enricher.enrich_all()

        _elapsed = time.perf_counter() - _t0
        if _elapsed >= _SLOW_FILE_THRESHOLD:
            _log.warning(
                "SingleFileAnalyzer.analyze slow file (%.1fs): %s", _elapsed, file_path
            )
        else:
            _log.debug(
                "SingleFileAnalyzer.analyze done in %.3fs: %s", _elapsed, file_path
            )

        return FileAnalysisResult(
            file_path=file_path,
            exports=exports,
            imports=imports,
            sections=sections,
            symbol_table=context.symbol_table,
            call_graph=call_graph,
            analysis_context=context
        )

    def _extract_exports(self, symbol_table: SymbolTable) -> List[str]:
        """Extract ENTRY symbols (exports)."""
        exports = []
        for symbol in symbol_table.all_symbols:
            if symbol.symbol_type == SymbolType.ENTRY:
                exports.append(symbol.name)
        return exports

    def _extract_imports(self, symbol_table: SymbolTable) -> List[str]:
        """Extract EXTRN/WXTRN symbols (imports)."""
        imports = []
        for symbol in symbol_table.all_symbols:
            if symbol.symbol_type in (SymbolType.EXTRN, SymbolType.WXTRN):
                imports.append(symbol.name)
        return imports

    def _extract_sections(self, symbol_table: SymbolTable) -> List[str]:
        """Extract CSECT/DSECT names."""
        sections = []
        for symbol in symbol_table.all_symbols:
            if symbol.symbol_type in (SymbolType.CSECT, SymbolType.DSECT, SymbolType.RSECT):
                sections.append(symbol.name)
        return sections
