"""Single file analyzer for Makefiles."""

from pathlib import Path
from typing import List
from multi_file.single_file_analyzer import FileAnalysisResult
from models.analysis_context import AnalysisContext
from models.line_metadata import (
    LineMetadataIndex,
    LineMetadata,
    CodeblockContext,
    ConditionalContext,
    CallContext,
)
from passes.makefile_parser import MakefileParser


class MakefileAnalyzer:
    """Analyze Makefile/.mak for build metadata."""

    def __init__(self) -> None:
        self.parser = MakefileParser()

    def analyze(self, file_path: Path, file_content: str) -> FileAnalysisResult:
        context = AnalysisContext(file_path=file_path)
        build_metadata = self.parser.parse(file_path, file_content)
        context.add_metadata("build_metadata", build_metadata)
        context.line_metadata_index = self._build_line_metadata_index(file_path, file_content)

        return FileAnalysisResult(
            file_path=file_path,
            exports=[],
            imports=[],
            sections=[],
            symbol_table=context.symbol_table,
            call_graph=None,
            analysis_context=context
        )

    def _build_line_metadata_index(self, file_path: Path, file_content: str) -> LineMetadataIndex:
        """Create basic per-line metadata for significant makefile lines."""
        index = LineMetadataIndex()
        for line_no, raw_line in enumerate(file_content.splitlines(), start=1):
            stripped = raw_line.strip()
            if not stripped or stripped.startswith("#"):
                continue

            metadata = LineMetadata(
                file=str(file_path),
                line_number=line_no,
                codeblock=CodeblockContext(
                    enclosing_function=None,
                    enclosing_section=None,
                    enclosing_routine=None,
                    in_executable_block=False,
                ),
                conditional=ConditionalContext(
                    is_conditional=False,
                    depth=0,
                    active_conditions=[],
                    condition_types=[],
                ),
                calls=CallContext(
                    calls_functions=[],
                    calls_routines=[],
                    invokes_macros=[],
                ),
                is_comment=False,
            )
            index.add(metadata)
        return index
