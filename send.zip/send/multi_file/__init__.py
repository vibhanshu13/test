"""Multi-file analysis support."""
