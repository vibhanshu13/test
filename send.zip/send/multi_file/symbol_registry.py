"""Global symbol registry for cross-file resolution."""
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List
from models.symbol import Symbol


class Confidence(Enum):
    """Confidence level for symbol resolution."""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class ResolutionResult:
    """Result of resolving an EXTRN reference."""
    resolved: bool
    targets: List[Symbol]
    confidence: Confidence
    reason: str = ""


class GlobalSymbolRegistry:
    """Linker-like symbol resolution across files."""

    def __init__(self):
        """Initialize global symbol registry."""
        self.entries: Dict[str, List[Symbol]] = {}  # Symbol name → list of ENTRY defs
        self.extrns: Dict[str, List[Symbol]] = {}   # Symbol name → list of EXTRN refs
        self.wxtrns: Dict[str, List[Symbol]] = {}   # Symbol name → list of WXTRN refs
        self.warnings: List[Dict] = []

    @property
    def total_count(self) -> int:
        """Combined count of all ENTRY, EXTRN, and WXTRN symbols.

        Use this instead of ``.symbols`` (which does not exist) when you
        only need a count for logging — avoids the AttributeError that
        previously crashed the orchestrator immediately after Phase 1
        (Issue 7).
        """
        return len(self.entries) + len(self.extrns) + len(self.wxtrns)

    def add_entry(self, symbol: Symbol) -> None:
        """
        Add ENTRY symbol (public definition).

        Args:
            symbol: ENTRY symbol to add
        """
        if symbol.name not in self.entries:
            self.entries[symbol.name] = []

        self.entries[symbol.name].append(symbol)

        # Check for duplicates
        if len(self.entries[symbol.name]) > 1:
            self._warn_duplicate_entry(symbol)

    def add_extrn(self, symbol: Symbol) -> None:
        """
        Add EXTRN symbol (external reference).

        Args:
            symbol: EXTRN symbol to add
        """
        if symbol.name not in self.extrns:
            self.extrns[symbol.name] = []

        self.extrns[symbol.name].append(symbol)

    def add_wxtrn(self, symbol: Symbol) -> None:
        """
        Add WXTRN symbol (weak external reference).

        Weak externals allow multiple definitions without error.

        Args:
            symbol: WXTRN symbol to add
        """
        if symbol.name not in self.wxtrns:
            self.wxtrns[symbol.name] = []

        self.wxtrns[symbol.name].append(symbol)

    def resolve_extrn(self, extrn_symbol: Symbol) -> ResolutionResult:
        """
        Resolve EXTRN reference to ENTRY definition(s).

        Args:
            extrn_symbol: EXTRN symbol to resolve

        Returns:
            Resolution result with targets and confidence
        """
        matches = self.entries.get(extrn_symbol.name, [])

        if not matches:
            # Unresolved - likely external library
            return ResolutionResult(
                resolved=False,
                targets=[],
                confidence=Confidence.LOW,
                reason="No ENTRY definition found"
            )

        if len(matches) == 1:
            # Clean resolution
            return ResolutionResult(
                resolved=True,
                targets=matches,
                confidence=Confidence.HIGH,
                reason="Single ENTRY definition"
            )

        # Multiple matches - apply priority rules if available
        best_match = self._apply_priority_rules(extrn_symbol, matches)
        if best_match:
            return ResolutionResult(
                resolved=True,
                targets=[best_match],
                confidence=Confidence.HIGH,
                reason="Resolved using priority rules"
            )

        # Multiple matches - report all with medium confidence
        return ResolutionResult(
            resolved=True,
            targets=matches,
            confidence=Confidence.MEDIUM,
            reason=f"Multiple ENTRY definitions ({len(matches)})"
        )

    def resolve_wxtrn(self, wxtrn_symbol: Symbol) -> ResolutionResult:
        """
        Resolve WXTRN (weak external) reference to ENTRY definition(s).

        Weak externals allow multiple definitions - chooses first or reports alternatives.

        Args:
            wxtrn_symbol: WXTRN symbol to resolve

        Returns:
            Resolution result with targets and confidence
        """
        matches = self.entries.get(wxtrn_symbol.name, [])

        if not matches:
            # Unresolved - weak externals can be optional
            return ResolutionResult(
                resolved=False,
                targets=[],
                confidence=Confidence.MEDIUM,  # Higher than EXTRN since weak is optional
                reason="WXTRN not defined (optional)"
            )

        if len(matches) == 1:
            # Clean resolution
            return ResolutionResult(
                resolved=True,
                targets=matches,
                confidence=Confidence.HIGH,
                reason="Single ENTRY definition for WXTRN"
            )

        # Multiple matches allowed for WXTRN - choose first, note alternatives
        return ResolutionResult(
            resolved=True,
            targets=[matches[0]],  # Use first definition
            confidence=Confidence.MEDIUM,
            reason=f"WXTRN with {len(matches)} definitions (using first)"
        )

    def _warn_duplicate_entry(self, symbol: Symbol) -> None:
        """Record warning for duplicate ENTRY symbol."""
        self.warnings.append({
            "type": "duplicate_entry",
            "symbol": symbol.name,
            "file": symbol.file,
            "message": f"Symbol {symbol.name} has multiple ENTRY definitions"
        })

    def _apply_priority_rules(self, reference_symbol: Symbol, candidates: List[Symbol]) -> Symbol:
        """
        Apply priority rules to choose best symbol from multiple candidates.

        Priority rules:
        1. Prefer symbol from same directory as reference
        2. Prefer symbol from same filename prefix
        3. Return None if no clear winner

        Args:
            reference_symbol: The EXTRN/WXTRN symbol doing the referencing
            candidates: List of possible ENTRY matches

        Returns:
            Best match symbol, or None if no clear winner
        """
        if not candidates:
            return None

        if len(candidates) == 1:
            return candidates[0]

        # Rule 1: Prefer symbol from same directory
        from pathlib import Path
        ref_dir = Path(reference_symbol.file).parent if reference_symbol.file else None

        if ref_dir:
            same_dir_matches = [c for c in candidates if Path(c.file).parent == ref_dir]
            if len(same_dir_matches) == 1:
                return same_dir_matches[0]

        # Rule 2: Prefer symbol from file with same prefix
        if reference_symbol.file:
            ref_stem = Path(reference_symbol.file).stem
            same_prefix_matches = [
                c for c in candidates
                if Path(c.file).stem.startswith(ref_stem[:3])  # Match first 3 chars
            ]
            if len(same_prefix_matches) == 1:
                return same_prefix_matches[0]

        # No clear winner
        return None
