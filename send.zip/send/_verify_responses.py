"""Run all 5 sessions and print full answers for human review."""
import asyncio
import sys
import time


async def run_session(label, questions):
    from explainability.explain import ExplainabilitySession

    CODEBASE = "/app/temp/asm"
    OUTPUT = "/app/output"

    print(f"\n{'='*80}")
    print(f"SESSION: {label}")
    print(f"{'='*80}")
    sys.stdout.flush()

    async with ExplainabilitySession(CODEBASE, OUTPUT) as sess:
        for i, q in enumerate(questions, 1):
            print(f"\n--- Turn {i} ---")
            print(f"Q: {q}")
            print(f"{'.'*60}")
            sys.stdout.flush()

            t0 = time.monotonic()
            try:
                ans = await sess.ask(q)
                elapsed = time.monotonic() - t0
                if ans:
                    print(f"A ({elapsed:.1f}s, {len(ans)} chars):\n{ans}")
                else:
                    print(f"A ({elapsed:.1f}s): [EMPTY RESPONSE]")
            except Exception as exc:
                elapsed = time.monotonic() - t0
                print(f"A ({elapsed:.1f}s): [ERROR: {type(exc).__name__}: {exc}]")
            sys.stdout.flush()


SESSIONS = [
    (
        "S1 — INPDAT1 date field (ae48.asm)",
        [
            "What does INPDAT1 represent in ae48.asm? Describe what it stores and list every bit flag it uses.",
            "Which modules write to INPDAT1 and what date format do they store?",
            "How does ae48.asm validate the date stored in INPDAT1 — what error handling exists?",
        ],
    ),
    (
        "S2 — Module pipeline da76 → da78",
        [
            "Walk me through the high-level processing pipeline: how does da76.asm hand off work to da78.asm?",
            "What shared data structures or work blocks does da76.asm pass to da78.asm during the handoff?",
            "Are there any error paths where da76.asm bypasses da78.asm entirely?",
        ],
    ),
    (
        "S3 — Error return code flow from ae48",
        [
            "What return codes does ae48.asm set when it encounters an error, and where in the code are they set?",
            "Which calling module checks that return code and what action does it take on a non-zero value?",
            "Which C++ variable receives this status, what is its type, and where is it first read after the call?",
        ],
    ),
    (
        "S4 — C++ variable casGlosInputMessage",
        [
            "I see casGlosInputMessage used in the C++ modernised code. What is the original ASM variable or register it maps to?",
            "What fields inside casGlosInputMessage correspond to date or time information originally stored in ASM data areas?",
            "Show me every place in the modernised C++ where casGlosInputMessage is both read and written within a single function.",
        ],
    ),
    (
        "S5 — Shared work block WB1RTC",
        [
            "What is WB1RTC in the ASM codebase — describe its structure and purpose.",
            "Which modules read from WB1RTC and which modules write to it?",
            "How is WB1RTC represented in the modernised C++ code — what struct or class replaces it?",
        ],
    ),
]


async def main():
    total_start = time.monotonic()
    for label, questions in SESSIONS:
        await run_session(label, questions)
    print(f"\n\n{'='*80}")
    print(f"Total wall time: {time.monotonic() - total_start:.1f}s")
    sys.stdout.flush()


asyncio.run(main())
