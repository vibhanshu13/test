#!/usr/bin/env python3
"""
trace_cross_file_lineage.py

Orchestrates end-to-end cross-file lineage tracing for an ASM variable.

Steps:
  1. Find all .asm.json files that modify the variable (SETTER instructions).
  2. Retrieve call chains through each modifier from the file call graph.
  3. Deduplicate chains — keep only longest (prefixes are redundant).
  4. Let the user select a chain interactively (or via --chain N).
  5. Trace lineage along the selected chain:
       - Modifier ASM file: intra-file lineage + dependent vars/blocks
       - Backward C++ callers: call site bridge → backward function tree
       - Backward ASM callers: call site bridge → guard conditions
       - Forward (downstream): setter check only; stop if no setters found

Usage:
  python trace_cross_file_lineage.py WK_RRC
  python trace_cross_file_lineage.py WK_RRC --chain 0 --output out.json
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from blueprint_io import iter_flow, load_blueprint
from find_variable_modifiers import scan_blueprint_for_setters, scan_blueprint_for_usages, find_chains_through
from find_connected_variables import find_all_connections
from cross_file_bridge import (
    find_cpp_to_cpp_callers,
    find_cpp_callers,
    find_asm_callers,
    find_asm_to_cpp_callers,
    _discover_blueprint_dir,
    _discover_asm_dir,
)
from trace_lineage import (
    LineageTracer,
    build_lineage_graph,
    normalize_token,
    TRIGGER_INST,
    CROSS_FILE_INST,
    is_dep_var_candidate,
)
from forward_trace_lineage import ForwardLineageTracer, apply_forward_graph_wiring
from filter_lineage import find_setters, walk_to_root, find_secondary_paths
from trace_cpp_function_lineage import (
    build_indexes,
    build_same_file_adjacency,
    build_tree,
    extract_dependent_files,
    build_owner_index,
    discover_cpp_blueprints,
    discover_asm_stems,
)


# ---------------------------------------------------------------------------
# Cross-file call target extraction
# ---------------------------------------------------------------------------

def _cross_file_target_stem(call: Dict[str, Any]) -> str:
    """Return the lowercase stem of the program called by a CROSS_FILE_CALL entry.

    For multi-operand instructions like CREEC the first arg is the program name
    and the rest are register/parm designators; args[0] is authoritative.
    Falls back to the first token of `detail` when args is absent.
    """
    args = call.get("args") or []
    if args:
        raw = str(args[0]).strip()
    else:
        raw = str(call.get("detail") or "").split(",")[0].split()[0].strip()
    if not raw:
        return ""
    # Keep only the first token; some payloads append comments in args[0].
    tok = raw.split(",")[0].split()[0].strip()
    if not tok:
        return ""
    if tok.lower().endswith(".asm"):
        tok = tok[:-4]
    s = normalize_token(tok).lower()
    return s


def _collect_cross_file_targets_from_entries(entries: List[Dict[str, Any]]) -> Set[str]:
    """Collect lowercase callee stems from lineage entries with role CROSS_FILE_CALL."""
    discovered: Set[str] = set()
    for entry in entries or []:
        if entry.get("role") != "CROSS_FILE_CALL":
            continue
        stem = _cross_file_target_stem(entry)
        if stem:
            discovered.add(stem)
    return discovered


def _cross_file_target_stem_from_flow_entry(entry: Dict[str, Any]) -> str:
    """Return lowercase callee stem from a blueprint flow entry."""
    args = entry.get("args") or []
    if isinstance(args, str):
        args = [args]
    return _cross_file_target_stem({
        "args": args,
        "detail": ", ".join(str(a) for a in args),
    })


def _is_dep_var_candidate(
    raw_arg: str,
    skip_var: str = "",
    constant_symbols: Optional[Set[str]] = None,
) -> bool:
    """Canonical dependent-variable filter (delegates to trace_lineage rules)."""
    return is_dep_var_candidate(
        raw_arg=raw_arg,
        skip_var=skip_var,
        allow_register_dependencies=False,
        constant_symbols=constant_symbols,
    )


# ---------------------------------------------------------------------------
# Auto-discovery helpers
# ---------------------------------------------------------------------------

def _discover_graph_file(blueprint_dir: Optional[Path]) -> Optional[Path]:
    candidates: List[Path] = []
    if blueprint_dir:
        candidates += [
            blueprint_dir / "file_call_graph.json",
            blueprint_dir.parent / "file_call_graph.json",
        ]
    cwd = Path.cwd()
    candidates += [
        cwd / "temp" / "output_latest" / "file_call_graph.json",
        cwd / "output" / "file_call_graph.json",
        cwd / "file_call_graph.json",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


# ---------------------------------------------------------------------------
# ASM → C++ field alias reverse lookup (Phase 4 / plan §9.1)
# ---------------------------------------------------------------------------

def _find_cpp_field_aliases_for_asm(
    blueprint_dir: Path,
    asm_variable: str,
) -> List[Dict[str, Any]]:
    """Reverse lookup: given an ASM variable name (e.g. LG1UPT), find every
    C++ struct field that maps to it via `field_asm_aliases` in cc*.hpp.

    Scans every *.cpp.json blueprint's `field_asm_aliases` section. For each
    match, enriches the record with:
      - hpp_source: the cc*.hpp filename that supplied the mapping (from the
        parallel `field_asm_alias_sources` section).
      - via_call:   if Phase-4 stitched a node annotation for this field in
        the same blueprint's global_variable_lineage, surface the ASM routine
        the stitcher inferred (otherwise omitted).
      - cpp_writers: list of enclosing functions that write to this field,
        sourced from the blueprint's local variable_lineage assign edges.
        Empty list means "no C++ writer in this corpus" (useful signal).

    Sample record:
        {"cpp_field": "CasGLRec.onlineSrcInd",
         "asm_variable": "LG1OSI",
         "blueprint": "dx740200.cpp.json",
         "hpp_source": "cclg1g1.hpp",
         "via_call":   "DA78",
         "cpp_writers": ["globalLimitsUpdate"]}

    Returns an empty list when no mapping exists. ASM-name matching is
    case-insensitive.
    """
    target = asm_variable.strip().upper()
    if not target:
        return []

    results: List[Dict[str, Any]] = []
    seen: Set[Tuple[str, str]] = set()
    for bp_path in sorted(blueprint_dir.rglob("*.cpp.json")):
        try:
            payload = load_blueprint(bp_path)
        except (OSError, json.JSONDecodeError):
            continue
        field_aliases = payload.get("field_asm_aliases")
        if not isinstance(field_aliases, dict):
            continue
        sources_map = payload.get("field_asm_alias_sources") or {}
        # Build via_call index from Phase-4 annotations on struct_field nodes.
        via_call_index: Dict[str, str] = {}
        for node in (payload.get("global_variable_lineage") or {}).get("nodes") or []:
            md = node.get("metadata") or {}
            alias = md.get("asm_alias")
            vc = md.get("via_call")
            if isinstance(alias, str) and isinstance(vc, str):
                via_call_index.setdefault(alias.upper(), vc)
        for cpp_field, asm_name in field_aliases.items():
            if not isinstance(asm_name, str):
                continue
            if asm_name.strip().upper() != target:
                continue
            key = (str(cpp_field), bp_path.name)
            if key in seen:
                continue
            seen.add(key)
            # Find C++ functions that write to this field (suffix match on
            # .fieldName in assign edges). Enclosing function names live in
            # edge.scope.
            field_suffix = "." + str(cpp_field).split(".", 1)[-1]
            pointer_suffix = "->" + str(cpp_field).split(".", 1)[-1]
            writers: Set[str] = set()
            for edge in (payload.get("variable_lineage") or {}).get("edges") or []:
                if edge.get("relation") != "assign":
                    continue
                tgt = str(edge.get("target") or "")
                if field_suffix in tgt or pointer_suffix in tgt:
                    scope = edge.get("scope")
                    if scope:
                        writers.add(scope)
            record: Dict[str, Any] = {
                "cpp_field": str(cpp_field),
                "asm_variable": target,
                "blueprint": bp_path.name,
                "hpp_source": sources_map.get(cpp_field, ""),
                "cpp_writers": sorted(writers),
            }
            via = via_call_index.get(target)
            if via:
                record["via_call"] = via
            results.append(record)
    return results


# ---------------------------------------------------------------------------
# C++ function source extraction
# ---------------------------------------------------------------------------

def _extract_one_function(lines: List[str], start_line: int) -> str:
    """Extract the complete function body starting at *start_line* (1-indexed).

    Reads forward tracking brace depth and stops after the closing ``}`` that
    brings depth back to zero.  Handles single-line comments (``//``) and
    block comments (``/* … */``) so stray braces inside them are ignored.
    """
    depth = 0
    in_block_comment = False
    result: List[str] = []
    found_open = False

    for raw in lines[start_line - 1 :]:
        result.append(raw.rstrip())
        i = 0
        while i < len(raw):
            if in_block_comment:
                if raw[i : i + 2] == "*/":
                    in_block_comment = False
                    i += 2
                else:
                    i += 1
                continue
            if raw[i : i + 2] == "//":
                break  # rest of line is comment
            if raw[i : i + 2] == "/*":
                in_block_comment = True
                i += 2
                continue
            if raw[i] == '"':  # skip string literals
                i += 1
                while i < len(raw):
                    if raw[i] == '\\':
                        i += 2
                        continue
                    if raw[i] == '"':
                        i += 1
                        break
                    i += 1
                continue
            if raw[i] == '{':
                depth += 1
                found_open = True
            elif raw[i] == '}':
                depth -= 1
            i += 1

        if found_open and depth == 0:
            break

    return "\n".join(result)


def _build_func_source_index(
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    stem: str,
) -> Dict[str, str]:
    """Return ``{func_name: source_code}`` for all functions in *stem*.cpp.

    Discovers line ranges via ``line_metadata`` in the blueprint, then slices
    the ``.cpp`` source file.  Returns an empty dict on any failure.
    """
    bp = blueprint_dir / f"{stem}.cpp.json"
    if not bp.exists():
        return {}

    try:
        payload = load_blueprint(bp)
    except Exception:
        return {}

    lm = payload.get("line_metadata", {})
    if not lm:
        return {}

    # Group lines by enclosing_function
    func_starts: Dict[str, int] = {}
    for line_key, meta in lm.items():
        enc_func = meta.get("codeblock", {}).get("enclosing_function")
        if not enc_func:
            continue
        ln = int(line_key)
        if enc_func not in func_starts or ln < func_starts[enc_func]:
            func_starts[enc_func] = ln

    if not func_starts:
        return {}

    # Locate the .cpp source file
    cpp_source: Optional[Path] = None
    candidates: List[Path] = []
    if asm_dir:
        candidates.append(asm_dir / f"{stem}.cpp")
    candidates += [
        blueprint_dir.parent.parent / "asm" / f"{stem}.cpp",
        blueprint_dir.parent / "asm" / f"{stem}.cpp",
        blueprint_dir / f"{stem}.cpp",
    ]
    for c in candidates:
        if c.exists():
            cpp_source = c
            break

    if cpp_source is None:
        return {}

    try:
        source_lines = cpp_source.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return {}

    index: Dict[str, str] = {}
    for func_name, start in func_starts.items():
        if start < 1 or start > len(source_lines):
            continue
        index[func_name] = _extract_one_function(source_lines, start)

    return index


def _load_dc_constants(bp_data: Dict[str, Any]) -> Set[str]:
    """Return uppercased DC-defined symbol names from a blueprint symbol table."""
    constants: Set[str] = set()
    syms = bp_data.get("symbols", {})
    scopes = [syms.get("global_symbols", {})] + [
        sec.get("symbols", {}) for sec in syms.get("sections", {}).values()
    ]
    for scope in scopes:
        for name, sym in (scope or {}).items():
            if (sym.get("type") or sym.get("symbol_type")) == "dc":
                constants.add(name.upper())
    return constants


def _apply_dc_filter(graph: Dict[str, Any], dc_constants: Set[str]) -> None:
    """In-place: remove DC constant names from dependent_variables in every node."""
    if not dc_constants:
        return
    for node in graph.get("nodes", []) or []:
        node["dependent_variables"] = [
            v for v in (node.get("dependent_variables") or [])
            if v.upper() not in dc_constants
        ]


def _build_asm_block_source_index(
    blueprint_data: Dict[str, Any],
    asm_file: Optional[Path],
) -> Dict[str, str]:
    """Build {block_id: full_source_code} for all blocks in an ASM blueprint.

    Block line range is [min(flow[].line), max(flow[].line)] inclusive.
    Returns empty dict if asm_file is missing or unreadable.
    """
    if not asm_file or not asm_file.exists():
        return {}
    try:
        src_lines = asm_file.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return {}

    index: Dict[str, str] = {}
    for block in blueprint_data.get("blocks", []):
        block_id = block.get("id")
        if not block_id:
            continue
        lines_in_flow = [e["line"] for e in iter_flow(block) if e.get("line")]
        if not lines_in_flow:
            continue
        start = min(lines_in_flow)
        end = max(lines_in_flow)
        index[block_id] = "\n".join(src_lines[start - 1 : end])
    return index


def _enrich_tree_with_code(
    node: Dict[str, Any],
    source_index: Dict[str, str],
) -> None:
    """Recursively add ``function_code`` to every node in *node* tree."""
    func_name = node.get("function")
    if func_name and func_name in source_index:
        node["function_code"] = source_index[func_name]
    for child in node.get("children", []):
        _enrich_tree_with_code(child, source_index)


# ---------------------------------------------------------------------------
# Chain deduplication
# ---------------------------------------------------------------------------

def deduplicate_chains(chains: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Keep only chains that are not strict prefixes of a longer chain."""
    sorted_c = sorted(chains, key=lambda c: len(c["files"]), reverse=True)
    kept: List[Dict[str, Any]] = []
    kept_tuples: List[Tuple[str, ...]] = []
    for c in sorted_c:
        key = tuple(c["files"])
        is_prefix = any(key == t[: len(key)] for t in kept_tuples)
        if not is_prefix:
            kept.append(c)
            kept_tuples.append(key)
    return sorted(kept, key=lambda c: (c["length"], c["files"]))


# ---------------------------------------------------------------------------
# Edge classification
# ---------------------------------------------------------------------------

def _classify_edge(
    caller: str,
    callee: str,
    file_type_map: Dict[str, str],
) -> str:
    """Return one of: cpp_to_asm | cpp_to_cpp | asm_to_cpp | asm_to_asm"""
    c_type = file_type_map.get(caller, "asm")
    e_type = file_type_map.get(callee, "asm")
    return f"{c_type}_to_{e_type}"


# ---------------------------------------------------------------------------
# Modifier ASM file — intra-file trace
# ---------------------------------------------------------------------------

def _trace_modifier_asm(
    variable: str,
    stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    tracer: LineageTracer,
    warnings: List[str],
    fwd_tracer: Optional["ForwardLineageTracer"] = None,
) -> Dict[str, Any]:
    bp = blueprint_dir / f"{stem}.asm.json"
    asm_file: Optional[Path] = None
    if asm_dir:
        candidate = asm_dir / f"{stem}.asm"
        if candidate.exists():
            asm_file = candidate
    if asm_file is None:
        for search in [blueprint_dir.parent.parent / "asm",
                       blueprint_dir.parent / "asm",
                       blueprint_dir]:
            candidate = search / f"{stem}.asm"
            if candidate.exists():
                asm_file = candidate
                break
    if asm_file is None:
        msg = f"Could not find {stem}.asm source file."
        warnings.append(msg)
        print(f"  WARNING: {msg}", file=sys.stderr)
        return {
            "role": "modifier", "file_type": "asm",
            "lineage_chain": [], "dependent_vars": [],
            "dependent_files": [],
        }

    print(f"  [modifier asm]  {asm_file}", file=sys.stderr)

    # Build block source index
    bp_data = load_blueprint(bp)
    block_source_index = _build_asm_block_source_index(bp_data, asm_file)

    # ── Backward lineage ─────────────────────────────────────────────────────
    results = tracer.trace(variable, asm_file, bp)

    # Restrict to intra-file entries only; strip internal cross-file wiring metadata
    # (_cross_file_parent is set when the tracer re-enters this file via a cross-file
    # path, e.g. da78 → da76 → da78. It's an internal field for build_lineage_graph
    # and must not appear in the output chains.)
    intra_chain = [
        {k: v for k, v in e.items() if k != "_cross_file_parent"}
        for e in results.lineage_chain
        if e.get("file") == asm_file.name
    ]

    # ── Ensure fwd_tracer is initialised ────────────────────────────────────
    if fwd_tracer is None:
        fwd_tracer = ForwardLineageTracer(
            asm_dir=asm_dir or blueprint_dir,
            blueprint_dir=blueprint_dir,
        )

    # ── Per-setter paths via filter_lineage ──────────────────────────────────
    print(f"  [modifier graph] building lineage graph for setter paths", file=sys.stderr)
    setter_paths: List[Dict[str, Any]] = []
    try:
        graph = build_lineage_graph(
            variable, asm_file, results,
            blueprint_file=bp,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
        )
        # Restrict to intra-file nodes to avoid false matches from cross-file deps
        intra_nodes = [n for n in graph.get("nodes", [])
                       if n.get("file") == asm_file.name]
        node_by_id = {n["chunk_id"]: n for n in intra_nodes}
        setters = find_setters(intra_nodes, variable)
        block_predecessors = graph.get("block_predecessors", {})
        print(f"  [modifier graph] found {len(setters)} setter node(s)", file=sys.stderr)
        for setter_node in setters:
            primary_path, cycle_id, _ = walk_to_root(setter_node, node_by_id)
            all_paths = [{"label": "primary", "path": primary_path}]

            # Secondary paths via SHARED_INBOUND_CALL (subroutine callers)
            for sec_path in find_secondary_paths(primary_path, node_by_id, intra_nodes):
                first_blk = sec_path[0].get("block", sec_path[0].get("chunk_id", "?"))
                all_paths.append({"label": f"via {first_blk}", "path": sec_path})

            # Additional secondary paths via block_predecessors (branch/guard predecessors
            # of any block on the primary path — these are the "many paths" that would be
            # found by a full backward traversal but are dropped by the single-parent tree).
            path_id_to_idx = {n["chunk_id"]: i for i, n in enumerate(primary_path)}
            for attach_cid, sec_cids in block_predecessors.items():
                if attach_cid not in path_id_to_idx:
                    continue
                attach_idx = path_id_to_idx[attach_cid]
                for sec_cid in sec_cids:
                    sec_node = node_by_id.get(sec_cid)
                    if sec_node is None:
                        continue
                    sec_path, _, _ = walk_to_root(sec_node, node_by_id)
                    full_path = sec_path + primary_path[attach_idx:]
                    sec_block = sec_node.get("block", sec_cid)
                    all_paths.append({"label": f"via {sec_block}", "path": full_path})

            setter_paths.append({
                "setter_chunk_id": setter_node.get("chunk_id"),
                "setter_block":    setter_node.get("block"),
                "setter_line":     setter_node.get("line"),
                "setter_inst":     setter_node.get("inst"),
                "setter_detail":   setter_node.get("detail"),
                "path":            primary_path,
                "all_paths":       all_paths,
                "cycle_at":        cycle_id,
            })
    except Exception as exc:
        msg = f"Could not build lineage graph for setter paths: {exc}"
        warnings.append(msg)
        print(f"  WARNING: {msg}", file=sys.stderr)

    # ── Forward-from-setter paths ─────────────────────────────────────────────
    # For each setter found above, trace forward FROM that write and collect:
    #   uses       — READER / CONDITION_TEST / BRANCH_ON_CONDITION
    #   overwrites — the next write to the variable on each execution path
    #   side_effects, cross_file_calls — other notable nodes along the path
    # This replaces the old "forward_overwrite_paths" which incorrectly showed
    # paths *leading to* the write (same information as backward, just reversed).
    print(f"  [modifier fwd-from-setter] tracing forward from each setter", file=sys.stderr)
    forward_from_setter_paths: List[Dict[str, Any]] = []
    FORWARD_USE_ROLES = {"READER", "CONDITION_TEST", "BRANCH_ON_CONDITION"}
    SIDE_EFFECT_ROLES = {"SIDE_EFFECT_SETTER", "SUBROUTINE_USAGE"}
    for sp in setter_paths:
        s_block = str(sp.get("setter_block", ""))
        s_line  = int(sp.get("setter_line",  0))
        if not s_block or not s_line:
            continue
        print(f"    from {stem}:{s_block}:{s_line}", file=sys.stderr)
        try:
            fwd_from = fwd_tracer.trace_forward_from_setter(
                target_variable=variable,
                source_asm_file=asm_file,
                blueprint_file=bp,
                start_block_id=s_block,
                start_line=s_line,
            )
            chain = fwd_from.lineage_chain
            block_edges = fwd_tracer.compute_cfg_block_edges(bp, s_block, s_line)
            forward_from_setter_paths.append({
                "setter_chunk_id":  sp.get("setter_chunk_id"),
                "setter_block":     s_block,
                "setter_line":      s_line,
                "setter_detail":    sp.get("setter_detail"),
                "uses":             [e for e in chain if e.get("role") in FORWARD_USE_ROLES],
                "next_overwrites":  [e for e in chain if e.get("role") == "OVERWRITE"],
                "side_effects":     [e for e in chain if e.get("role") in SIDE_EFFECT_ROLES],
                "cross_file_calls": [e for e in chain if e.get("role") == "CROSS_FILE_CALL"],
                "block_edges":      block_edges,
                "warnings":         [str(w) for w in fwd_from.data_quality_warnings],
            })
        except Exception as exc:
            msg = f"Could not trace forward from {stem}:{s_block}:{s_line}: {exc}"
            warnings.append(msg)
            print(f"    WARNING: {msg}", file=sys.stderr)

    graph = _build_modifier_graph(variable, setter_paths, forward_from_setter_paths, block_source_index,
                                   raw_backward_chain=intra_chain)
    _apply_dc_filter(graph, _load_dc_constants(bp_data))

    # ── Usage sites in the same file ─────────────────────────────────────────
    # A modifier file may also READ the variable (condition tests, readers).
    # Trace those sites backward + forward so their guard conditions are captured.
    usage_graph: Optional[Dict[str, Any]] = None
    usage_discovered: List[str] = []
    usage_hits, _uerr = scan_blueprint_for_usages(bp, variable)
    if _uerr:
        warnings.append(_uerr)
    if usage_hits:
        print(f"  [modifier usage] {len(usage_hits)} usage site(s) found alongside setter(s)", file=sys.stderr)
        usage_graph, usage_discovered = _trace_usage_sites_in_asm(
            variable, stem, bp, bp_data, asm_file, usage_hits,
            fwd_tracer, block_source_index, warnings,
        )

    # ── Collect dynamically discovered downstream files ───────────────────────
    # Sources: backward tracer (ENTRC/ENTNC/ENTDC/CREEC/CREMC/SWISC) + forward cross-file calls
    discovered_downstream: Set[str] = set(usage_discovered)

    # Backward setter walk contributions:
    # 1) dependent_files emitted by the backward tracer
    # 2) explicit CROSS_FILE_CALL nodes encountered in backward lineage paths
    discovered_downstream.update(_collect_cross_file_targets_from_entries(intra_chain))
    for sp in setter_paths:
        for path_variant in (sp.get("all_paths") or []):
            discovered_downstream.update(
                _collect_cross_file_targets_from_entries(path_variant.get("path") or [])
            )

    for dep in results.dependent_files:
        s = str(dep.get("file", "")).strip().lower()
        if s:
            discovered_downstream.add(s)
    for fp in forward_from_setter_paths:
        for call in fp.get("cross_file_calls", []):
            s = _cross_file_target_stem(call)
            if s:
                discovered_downstream.add(s)

    result: Dict[str, Any] = {
        "role": "modifier",
        "file_type": "asm",
        "modifier_graph": graph,
        "_discovered_downstream": sorted(discovered_downstream),
    }
    if usage_graph is not None:
        result["usage_graph"] = usage_graph
    return result


# ---------------------------------------------------------------------------
# Upstream C++ hop — backward function tree
# ---------------------------------------------------------------------------

def _trace_cpp_upstream(
    caller: str,
    callee: str,
    callee_type: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    edge_instruction: str,
    functions_by_file: Dict[str, Any],
    owner_index: Dict[str, Set[str]],
    known_asm_stems: Dict[str, str],
    all_edges: List[Dict[str, Any]],
    max_depth: Optional[int],
    warnings: List[str],
    entry_function: Optional[str] = None,
) -> Dict[str, Any]:
    print(f"  [cpp upstream]  {caller} -{edge_instruction}-> {callee}", file=sys.stderr)

    # 0. Build function source index for this caller file
    source_index = _build_func_source_index(blueprint_dir, asm_dir, caller)
    if source_index:
        print(f"  [cpp source]    indexed {len(source_index)} function(s) in {caller}.cpp",
              file=sys.stderr)
    else:
        print(f"  [cpp source]    no source index for {caller}.cpp", file=sys.stderr)

    # 1. Get call sites
    if callee_type == "asm":
        sites = find_cpp_callers(caller, callee, blueprint_dir)
        func_key = "function"
    else:
        sites = find_cpp_to_cpp_callers(caller, callee, blueprint_dir)
        func_key = "caller_function"

    if not sites:
        msg = f"No call sites found from '{caller}' to '{callee}'."
        warnings.append(msg)
        print(f"  WARNING: {msg}", file=sys.stderr)

    # Enrich call sites with the calling function's source code
    for site in sites:
        fn = site.get(func_key)
        if fn and fn in source_index:
            site["function_code"] = source_index[fn]

    # 2. Build same-file adjacency for caller
    root_functions: Set[str] = functions_by_file.get(caller, set())
    out_adj, in_adj, _ = build_same_file_adjacency(
        caller, root_functions, owner_index, all_edges
    )

    graph = _build_cpp_call_graph(sites, entry_function, func_key, in_adj, source_index)
    return {
        "role": "upstream",
        "file_type": "cpp",
        "edge_type": edge_instruction,
        "call_graph": graph,
    }


# ---------------------------------------------------------------------------
# Upstream ASM hop — guard conditions via trace_from_call_site
# ---------------------------------------------------------------------------

def _trace_asm_upstream(
    caller: str,
    callee: str,
    callee_type: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    edge_instruction: str,
    tracer: LineageTracer,
    warnings: List[str],
) -> Dict[str, Any]:
    print(f"  [asm upstream]  {caller} -{edge_instruction}-> {callee}", file=sys.stderr)

    # 1. Resolve caller .asm and .asm.json paths
    bp = blueprint_dir / f"{caller}.asm.json"
    if not bp.exists():
        msg = f"Blueprint not found: {bp}"
        warnings.append(msg)
        return {"role": "upstream", "file_type": "asm",
                "edge_type": edge_instruction}

    caller_asm: Optional[Path] = None
    if asm_dir:
        candidate = asm_dir / f"{caller}.asm"
        if candidate.exists():
            caller_asm = candidate
    if caller_asm is None:
        for search in [blueprint_dir.parent.parent / "asm",
                       blueprint_dir.parent / "asm",
                       blueprint_dir]:
            candidate = search / f"{caller}.asm"
            if candidate.exists():
                caller_asm = candidate
                break

    if caller_asm is None:
        msg = f"Could not find {caller}.asm source file."
        warnings.append(msg)
        print(f"  WARNING: {msg}", file=sys.stderr)
        return {
            "role": "upstream", "file_type": "asm",
            "edge_type": edge_instruction,
            "asm_source_unavailable": True,
        }

    # 2. Build block source index
    bp_data = load_blueprint(bp)
    block_source_index = _build_asm_block_source_index(bp_data, caller_asm)

    # 3. Get call sites
    if callee_type == "cpp":
        sites = find_asm_to_cpp_callers(caller, callee, blueprint_dir, asm_dir)
    else:
        sites = find_asm_callers(caller, callee, blueprint_dir, asm_dir)

    if not sites:
        msg = f"No call sites found from '{caller}' to '{callee}'."
        warnings.append(msg)
        print(f"  WARNING: {msg}", file=sys.stderr)

    # 3. Backward-trace each call site
    enriched: List[Dict[str, Any]] = []
    for site in sites:
        routine = site.get("routine") or ""
        line = site.get("line") or 0
        instruction = site.get("instruction") or ""
        raw_line = site.get("raw_line") or f"{instruction} {callee.upper()}"

        trace = tracer.trace_from_call_site(
            source_asm_file=caller_asm,
            blueprint_file=bp,
            call_block_id=routine,
            call_line=line,
            call_instruction=instruction,
            call_detail=raw_line.strip(),
        )

        # Build a structured lineage graph from the call-site TraceResults so
        # filter_lineage.py can be run on it independently.
        call_site_graph: Optional[Dict[str, Any]] = None
        try:
            call_site_graph = build_lineage_graph(
                f"CALL_TO_{callee.upper()}",
                caller_asm,
                trace,
                blueprint_file=bp,
                blueprint_dir=blueprint_dir,
                asm_dir=asm_dir,
            )
        except Exception as exc:
            msg = f"Could not build lineage graph for {caller}→{callee} call site: {exc}"
            warnings.append(msg)
            print(f"  WARNING: {msg}", file=sys.stderr)

        # ── call_paths: backward trace from each CALL_SITE node to root ──────
        # Same algorithm as setter_paths in _trace_modifier_asm, but instead of
        # finding SETTER nodes we find CALL_SITE nodes and walk up to the entry
        # block of the caller file.
        call_paths: List[Dict[str, Any]] = []
        if call_site_graph is not None:
            try:
                intra_nodes = [
                    n for n in call_site_graph.get("nodes", [])
                    if n.get("file") == caller_asm.name
                ]
                cs_node_by_id = {n["chunk_id"]: n for n in intra_nodes}
                cs_nodes = [n for n in intra_nodes if n.get("role") == "CALL_SITE"]
                bp_predecessors = call_site_graph.get("block_predecessors", {})

                for cs_node in cs_nodes:
                    primary_path, cycle_id, _ = walk_to_root(cs_node, cs_node_by_id)
                    all_paths = [{"label": "primary", "path": primary_path}]

                    # Secondary paths via SHARED_INBOUND_CALL nodes
                    for sec_path in find_secondary_paths(primary_path, cs_node_by_id, intra_nodes):
                        first_blk = sec_path[0].get("block", sec_path[0].get("chunk_id", "?"))
                        all_paths.append({"label": f"via {first_blk}", "path": sec_path})

                    # Additional paths via block_predecessors (branch/guard predecessors)
                    path_id_to_idx = {n["chunk_id"]: i for i, n in enumerate(primary_path)}
                    for attach_cid, sec_cids in bp_predecessors.items():
                        if attach_cid not in path_id_to_idx:
                            continue
                        attach_idx = path_id_to_idx[attach_cid]
                        for sec_cid in sec_cids:
                            sec_node = cs_node_by_id.get(sec_cid)
                            if sec_node is None:
                                continue
                            sec_path, _, _ = walk_to_root(sec_node, cs_node_by_id)
                            full_path = sec_path + primary_path[attach_idx:]
                            sec_block = sec_node.get("block", sec_cid)
                            all_paths.append({"label": f"via {sec_block}", "path": full_path})

                    call_paths.append({
                        "call_chunk_id": cs_node.get("chunk_id"),
                        "call_block":    cs_node.get("block"),
                        "call_line":     cs_node.get("line"),
                        "path":          primary_path,
                        "all_paths":     all_paths,
                        "cycle_at":      cycle_id,
                    })
            except Exception as exc:
                msg = f"Could not compute call_paths for {caller}→{callee}: {exc}"
                warnings.append(msg)
                print(f"  WARNING: {msg}", file=sys.stderr)

        enriched.append({
            "routine": routine,
            "line": line,
            "instruction": instruction,
            "raw_line": site.get("raw_line"),
            "guard_conditions": [
                e for e in trace.lineage_chain if e.get("role") != "CALL_SITE"
            ],
            "dependent_vars": trace.dependent_vars,
            "lineage_graph": call_site_graph,
            "call_paths": call_paths,
            "warnings": [str(w) for w in trace.data_quality_warnings],
        })

    graph = _build_backward_call_graph(enriched, block_source_index)
    _apply_dc_filter(graph, _load_dc_constants(bp_data))
    return {
        "role": "upstream",
        "file_type": "asm",
        "edge_type": edge_instruction,
        "call_graph": graph,
    }


# ---------------------------------------------------------------------------
# Upstream C++ — bounded backward call graph (function-level nodes+edges)
# ---------------------------------------------------------------------------

def _build_cpp_call_graph(
    call_sites: List[Dict[str, Any]],
    entry_function: Optional[str],
    func_key: str,
    in_adj: Dict[str, List[Dict[str, Any]]],
    source_index: Dict[str, str],
) -> Dict[str, Any]:
    """Build a bounded backward call graph for a C++ upstream file.

    Starts from each call site function (the one making the downstream call)
    and walks backward through same-file callers until ``entry_function`` is
    reached or no more callers exist.  If ``entry_function`` is None the walk
    terminates naturally at the call tree root(s).
    """
    node_data: Dict[str, Dict[str, Any]] = {}
    edge_data: Dict[tuple, Dict[str, Any]] = {}

    def ensure_node(fn: str) -> None:
        if fn not in node_data:
            node_data[fn] = {}

    def add_edge(src: str, tgt: str, scope: str) -> None:
        key = (src, tgt, "CALL")
        if key not in edge_data:
            edge_data[key] = {"scopes": set(), "directions": {"backward"}}
        edge_data[key]["scopes"].add(scope)

    for site in call_sites:
        call_func = site.get(func_key) or ""
        if not call_func:
            continue
        call_line = site.get("line", 0)
        scope = f"{call_func}:{call_line}"

        ensure_node(call_func)

        # Bounded backward BFS: call_func → … → entry_function
        visited: set = set()
        queue: List[str] = [call_func]
        while queue:
            current = queue.pop(0)
            if current in visited:
                continue
            visited.add(current)
            ensure_node(current)

            if entry_function and current == entry_function:
                continue  # reached top anchor — stop expanding

            for caller_edge in in_adj.get(current, []):
                caller_func = caller_edge.get("source") or ""
                if not caller_func:
                    continue
                ensure_node(caller_func)
                add_edge(current, caller_func, scope)
                if caller_func not in visited:
                    queue.append(caller_func)

    nodes = [
        {"id": fn, "code": source_index.get(fn, "")}
        for fn in node_data
    ]
    edges = [
        {
            "source": src,
            "target": tgt,
            "type": typ,
            "direction": sorted(d["directions"]),
            "scopes": sorted(d["scopes"]),
        }
        for (src, tgt, typ), d in edge_data.items()
    ]
    return {"nodes": nodes, "edges": edges}


# ---------------------------------------------------------------------------
# Upstream ASM — merge per-call-site backward traces into a unified nodes+edges graph
# ---------------------------------------------------------------------------

_BACKWARD_RELEVANT_ROLES = {"TRIGGER", "GUARD_BRANCH", "MACRO_BRANCH"}
_TRIGGER_ROLES = {"TRIGGER"}

# Instruction-specific role names — overrides the generic lineage role in
# relevant_code_lines so consumers can see exactly what each instruction does.
_INST_ROLE_MAP: Dict[str, str] = {
    # ── Compare / condition-test ────────────────────────────────────────────
    "CLC": "COMPARE",           "CLI": "COMPARE_IMMEDIATE",
    "TM":  "TEST_MASK",         "CP":  "COMPARE_PACKED",
    "LTR": "LOAD_AND_TEST",     "C":   "COMPARE",
    "CR":  "COMPARE",           "CH":  "COMPARE_HALFWORD",
    "CL":  "COMPARE_LOGICAL",   "CLR": "COMPARE_LOGICAL",
    # ── Conditional branches ────────────────────────────────────────────────
    "B":    "BRANCH",           "BE":   "BRANCH_EQUAL",
    "BNE":  "BRANCH_NOT_EQUAL", "BZ":   "BRANCH_ZERO",
    "BNZ":  "BRANCH_NOT_ZERO",  "BH":   "BRANCH_HIGH",
    "BNH":  "BRANCH_NOT_HIGH",  "BM":   "BRANCH_MINUS",
    "BNM":  "BRANCH_NOT_MINUS", "BO":   "BRANCH_OVERFLOW",
    "BNO":  "BRANCH_NOT_OVERFLOW", "BP": "BRANCH_POSITIVE",
    "BNP":  "BRANCH_NOT_POSITIVE", "BCT": "BRANCH_ON_COUNT",
    "J":    "BRANCH",           "JE":   "BRANCH_EQUAL",
    "JNE":  "BRANCH_NOT_EQUAL", "JZ":   "BRANCH_ZERO",
    "JNZ":  "BRANCH_NOT_ZERO",  "JH":   "BRANCH_HIGH",
    "JNH":  "BRANCH_NOT_HIGH",  "JL":   "BRANCH_LOW",
    "JNL":  "BRANCH_NOT_LOW",   "JM":   "BRANCH_MINUS",
    "JNM":  "BRANCH_NOT_MINUS", "JO":   "BRANCH_OVERFLOW",
    "JNO":  "BRANCH_NOT_OVERFLOW", "JP": "BRANCH_POSITIVE",
    "JNP":  "BRANCH_NOT_POSITIVE",
    "JXHG": "BRANCH_INDEX_HIGH", "JXLE": "BRANCH_INDEX_LOW_EQUAL",
    # ── Move / store ────────────────────────────────────────────────────────
    "MVC":  "MOVE",             "MVCL": "MOVE_LONG",
    "MVCP": "MOVE_WITH_KEY",    "MVCS": "MOVE_WITH_KEY",
    "MVI":  "MOVE_IMMEDIATE",   "MVN":  "MOVE_NUMERICS",
    "MVZ":  "MOVE_ZONES",       "MVO":  "MOVE_OFFSET",
    "XC":   "CLEAR",            "ZAP":  "ZERO_AND_ADD_PACKED",
    "ST":   "STORE",            "STM":  "STORE_MULTIPLE",
    "STH":  "STORE_HALFWORD",   "STC":  "STORE_CHAR",
    "STCM": "STORE_CHARS_MASK", "STCK": "STORE_CLOCK",
    "PACK": "PACK",             "CVB":  "CONVERT_TO_BINARY",
    "CVD":  "CONVERT_TO_DECIMAL",
    # ── Load / insert ───────────────────────────────────────────────────────
    "L":    "LOAD",             "LH":   "LOAD_HALFWORD",
    "LR":   "LOAD_REGISTER",    "IC":   "INSERT_CHAR",
    "ICM":  "INSERT_CHARS_MASK", "LA":  "LOAD_ADDRESS",
    # ── Bitwise immediate ───────────────────────────────────────────────────
    "OI":   "OR_IMMEDIATE",     "NI":   "AND_IMMEDIATE",
    "XI":   "XOR_IMMEDIATE",    "OC":   "OR",
    "NC":   "AND",
    # ── Arithmetic ──────────────────────────────────────────────────────────
    "AH":   "ADD_HALFWORD",     "SH":   "SUBTRACT_HALFWORD",
    "API":  "ADD_IMMEDIATE",    "SPI":  "SUBTRACT_IMMEDIATE",
    "MP":   "MULTIPLY_PACKED",  "DP":   "DIVIDE_PACKED",
    # ── Translate ───────────────────────────────────────────────────────────
    "TR":   "TRANSLATE",        "TRT":  "TRANSLATE_AND_TEST",
}


def _inst_to_role(inst: str, fallback: str) -> str:
    """Return an instruction-specific role name, falling back to the generic role."""
    return _INST_ROLE_MAP.get(inst.upper(), fallback)


def _normalize_backward_edge_type(raw: str) -> str:
    if raw in ("FALLTHROUGH", "SEQUENTIAL"):
        return "FALLTHROUGH"
    if raw in ("BRANCH", "RETURN"):
        return "BRANCH"
    return raw  # SUBROUTINE_CALL etc. pass through


def _role_to_backward_edge_type(role: str) -> str:
    return {
        "FALLTHROUGH_ENTRY": "FALLTHROUGH",
        "BRANCH_ENTRY": "BRANCH",
        "CROSS_FILE_CALL": "CROSS_FILE_CALL",
        "GUARD_BRANCH": "BRANCH",
        "MACRO_BRANCH": "BRANCH",
        "SUBROUTINE_CALL": "SUBROUTINE_CALL",
    }.get(role, "UNKNOWN")


def _build_backward_call_graph(
    call_sites: List[Dict[str, Any]],
    block_source_index: Dict[str, str] = {},
) -> Dict[str, Any]:
    """Merge per-call-site backward traces into a unified nodes+edges graph.

    Edge direction follows the backward traversal: source is closer to the call
    site, target is a predecessor (farther from the call site).  Each edge
    carries a ``scopes`` list of ``"block:line"`` identifiers — one per call
    site whose backward path includes that edge.
    """
    node_data: Dict[str, Dict[str, Any]] = {}
    edge_scopes: Dict[tuple, set] = {}

    def ensure_node(block_id: str) -> None:
        if block_id not in node_data:
            node_data[block_id] = {"relevant_lines": [], "dep_vars": set()}

    for call_site in call_sites:
        call_block = call_site.get("routine", "")
        call_line = call_site.get("line", 0)
        scope = f"{call_block}:{call_line}"
        ensure_node(call_block)

        # Call site block gets a CALL_SITE relevant_code_line
        node_data[call_block]["relevant_lines"].append({
            "line": call_line,
            "inst": call_site.get("instruction", ""),
            "role": "CALL_SITE",
            "detail": (call_site.get("raw_line") or "").strip(),
        })

        lg_nodes = (call_site.get("lineage_graph") or {}).get("nodes", [])
        if lg_nodes:
            chunk_to_block: Dict[str, str] = {
                n["chunk_id"]: n.get("block", "")
                for n in lg_nodes
                if "chunk_id" in n
            }

            for node in lg_nodes:
                block_id = node.get("block", "")
                if not block_id:
                    continue
                ensure_node(block_id)

                role = node.get("role", "")

                if role in _BACKWARD_RELEVANT_ROLES:
                    _inst = node.get("inst", "")
                    rl = {
                        "line": node.get("line", 0),
                        "inst": _inst,
                        "role": _inst_to_role(_inst, role),
                        "detail": node.get("detail", ""),
                    }
                    existing = node_data[block_id]["relevant_lines"]
                    if not any(
                        e["line"] == rl["line"] and e["role"] == rl["role"]
                        for e in existing
                    ):
                        existing.append(rl)

                    if role in _TRIGGER_ROLES:
                        for arg in (node.get("args") or []):
                            if _is_dep_var_candidate(arg):
                                node_data[block_id]["dep_vars"].add(normalize_token(arg))

                parent_cid = node.get("parent_chunk_id")
                if parent_cid:
                    parent_block = chunk_to_block.get(parent_cid, "")
                    if parent_block and parent_block != block_id:
                        eto = node.get("edge_to_parent") or {}
                        edge_type = _normalize_backward_edge_type(
                            eto.get("type", "UNKNOWN")
                        )
                        key = (block_id, parent_block, edge_type)
                        edge_scopes.setdefault(key, set()).add(scope)
                        ensure_node(parent_block)
        else:
            # Fallback: derive from guard_conditions
            # guard_conditions are ordered root→call-site (high depth first).
            # Reverse so we walk call-site-outward.
            gcs = list(reversed(call_site.get("guard_conditions", [])))
            prev_block = call_block
            for entry in gcs:
                entry_block = entry.get("block", "")
                if not entry_block:
                    continue
                ensure_node(entry_block)
                role = entry.get("role", "")

                if role in _BACKWARD_RELEVANT_ROLES:
                    _inst = entry.get("inst", "")
                    rl = {
                        "line": entry.get("line", 0),
                        "inst": _inst,
                        "role": _inst_to_role(_inst, role),
                        "detail": entry.get("detail", ""),
                    }
                    existing = node_data[entry_block]["relevant_lines"]
                    if not any(
                        e["line"] == rl["line"] and e["role"] == rl["role"]
                        for e in existing
                    ):
                        existing.append(rl)
                    if role in _TRIGGER_ROLES:
                        for arg in (entry.get("args") or []):
                            if _is_dep_var_candidate(arg):
                                node_data[entry_block]["dep_vars"].add(normalize_token(arg))

                if entry_block != prev_block:
                    edge_type = _role_to_backward_edge_type(role)
                    key = (prev_block, entry_block, edge_type)
                    edge_scopes.setdefault(key, set()).add(scope)
                    prev_block = entry_block

    nodes = [
        {
            "id": block_id,
            "code": block_source_index.get(block_id, ""),
            "relevant_code_lines": sorted(
                data["relevant_lines"], key=lambda x: x["line"]
            ),
            "dependent_variables": sorted(data["dep_vars"]),
        }
        for block_id, data in node_data.items()
        if block_id != "$IS$"
    ]
    edges = [
        {"source": src, "target": tgt, "type": typ, "direction": ["backward"], "scopes": sorted(scopes)}
        for (src, tgt, typ), scopes in edge_scopes.items()
        if src != "$IS$" and tgt != "$IS$"
    ]
    return {"nodes": nodes, "edges": edges}


# ---------------------------------------------------------------------------
# Modifier — merge per-setter backward+forward traces into one nodes+edges graph
# ---------------------------------------------------------------------------

_MODIFIER_BACKWARD_ROLES = {"SETTER", "TRIGGER", "GUARD_BRANCH", "MACRO_BRANCH"}
_MODIFIER_FORWARD_ROLES  = {"CONDITION_TEST", "READER", "BRANCH_ON_CONDITION", "OVERWRITE", "SIDE_EFFECT_SETTER"}
_MODIFIER_DEP_ROLES      = {"TRIGGER", "CONDITION_TEST", "READER"}


def _build_modifier_graph(
    variable: str,
    setter_paths: List[Dict[str, Any]],
    forward_from_setter_paths: List[Dict[str, Any]],
    block_source_index: Dict[str, str] = {},
    raw_backward_chain: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Merge per-setter backward and forward traces into a single nodes+edges graph.

    Backward edges (setter→entry direction) have ``direction: ["backward"]``.
    Forward edges (setter→usage direction) have ``direction: ["forward"]``.
    Edges that appear in both traces carry ``direction: ["backward", "forward"]``.
    All edges carry a ``scopes`` list of ``"setterBlock:setterLine"`` identifiers.
    """
    node_data: Dict[str, Dict[str, Any]] = {}
    edge_data: Dict[tuple, Dict[str, Any]] = {}  # (src, tgt, type) -> {scopes, directions}

    def ensure_node(block_id: str) -> None:
        if block_id not in node_data:
            node_data[block_id] = {"relevant_lines": [], "dep_vars": set()}

    def add_relevant_line(block_id: str, line: int, inst: str, role: str, detail: str) -> None:
        specific_role = _inst_to_role(inst, role)
        existing = node_data[block_id]["relevant_lines"]
        if not any(e["line"] == line and e["role"] == specific_role for e in existing):
            existing.append({"line": line, "inst": inst, "role": specific_role, "detail": detail})

    def add_dep_vars(block_id: str, args: List[str]) -> None:
        for arg in (args or []):
            if _is_dep_var_candidate(arg, skip_var=variable):
                node_data[block_id]["dep_vars"].add(normalize_token(arg))

    def add_edge(src: str, tgt: str, etype: str, scope: str, direction: str) -> None:
        key = (src, tgt, etype)
        if key not in edge_data:
            edge_data[key] = {"scopes": set(), "directions": set()}
        edge_data[key]["scopes"].add(scope)
        edge_data[key]["directions"].add(direction)

    # ── BACKWARD ─────────────────────────────────────────────────────────────
    for sp in setter_paths:
        scope = f"{sp['setter_block']}:{sp['setter_line']}"
        for path_variant in sp.get("all_paths") or []:
            path = path_variant.get("path") or []
            chunk_to_block: Dict[str, str] = {
                n["chunk_id"]: n.get("block", "")
                for n in path
                if "chunk_id" in n
            }
            for node in path:
                block_id = node.get("block", "")
                if not block_id:
                    continue
                ensure_node(block_id)
                role = node.get("role", "")
                if role in _MODIFIER_BACKWARD_ROLES:
                    add_relevant_line(block_id, node.get("line", 0), node.get("inst", ""),
                                      role, node.get("detail", ""))
                    if role in _MODIFIER_DEP_ROLES:
                        add_dep_vars(block_id, node.get("args") or [])

                parent_cid = node.get("parent_chunk_id")
                if parent_cid:
                    parent_block = chunk_to_block.get(parent_cid, "")
                    if parent_block and parent_block != block_id:
                        etype = _normalize_backward_edge_type(
                            (node.get("edge_to_parent") or {}).get("type", "UNKNOWN")
                        )
                        ensure_node(parent_block)
                        add_edge(block_id, parent_block, etype, scope, "backward")

    # ── SUPPLEMENTAL BACKWARD ────────────────────────────────────────────────
    # The walk_to_root paths above follow parent_chunk_id chains and can miss
    # TRIGGER/GUARD_BRANCH nodes that lie on alternative execution paths to the
    # setter (e.g. a block that conditionally branches into the setter block but
    # whose chunk is not an ancestor in the primary parent chain).
    # Sweep the raw intra-file lineage chain to pick up any such nodes.
    for entry in (raw_backward_chain or []):
        block_id = entry.get("block", "")
        role = entry.get("role", "")
        if not block_id or block_id == "$IS$" or role not in _MODIFIER_BACKWARD_ROLES:
            continue
        ensure_node(block_id)
        add_relevant_line(block_id, entry.get("line", 0), entry.get("inst", ""),
                          role, entry.get("detail", ""))
        if role in _MODIFIER_DEP_ROLES:
            add_dep_vars(block_id, entry.get("args") or [])

    # ── FORWARD ──────────────────────────────────────────────────────────────
    for fp in forward_from_setter_paths:
        scope = f"{fp['setter_block']}:{fp['setter_line']}"
        for entry in (fp.get("uses") or []) + (fp.get("next_overwrites") or []) + (fp.get("side_effects") or []):
            block_id = entry.get("block", "")
            if not block_id:
                continue
            ensure_node(block_id)
            role = entry.get("role", "")
            if role in _MODIFIER_FORWARD_ROLES:
                add_relevant_line(block_id, entry.get("line", 0), entry.get("inst", ""),
                                  role, entry.get("detail", ""))
                if role in _MODIFIER_DEP_ROLES:
                    add_dep_vars(block_id, entry.get("args") or [])

        for edge in (fp.get("block_edges") or []):
            src = edge.get("from", "")
            tgt = edge.get("to", "")
            etype = edge.get("type", "UNKNOWN")
            if not src or not tgt:
                continue
            ensure_node(src)
            ensure_node(tgt)
            add_edge(src, tgt, etype, scope, "forward")

    # ── BUILD OUTPUT ──────────────────────────────────────────────────────────
    nodes = [
        {
            "id": block_id,
            "code": block_source_index.get(block_id, ""),
            "relevant_code_lines": sorted(data["relevant_lines"], key=lambda x: x["line"]),
            "dependent_variables": sorted(data["dep_vars"]),
        }
        for block_id, data in node_data.items()
        if block_id != "$IS$"
    ]
    edges = [
        {
            "source": src,
            "target": tgt,
            "type": typ,
            "direction": sorted(d["directions"]),
            "scopes": sorted(d["scopes"]),
        }
        for (src, tgt, typ), d in edge_data.items()
    ]
    return {"nodes": nodes, "edges": edges}


# ---------------------------------------------------------------------------
# Downstream — merge per-usage-node traces into a unified nodes+edges graph
# ---------------------------------------------------------------------------

_RELEVANT_ROLES = {"CONDITION_TEST", "READER", "BRANCH_ON_CONDITION", "OVERWRITE", "SIDE_EFFECT_SETTER"}
_VAR_READ_ROLES = {"CONDITION_TEST", "READER"}


def _build_forward_usage_graph(
    variable: str,
    usage_locations: List[Dict[str, Any]],
    forward_from_usage_paths: List[Dict[str, Any]],
    block_source_index: Dict[str, str] = {},
    usage_backward_guards: Optional[Dict[str, List[Dict[str, Any]]]] = None,
) -> Dict[str, Any]:
    """Merge multiple per-usage-node forward traces into a single nodes+edges graph.

    Nodes: every block visited across all traces, annotated with relevant code
           lines (CONDITION_TEST / READER / BRANCH_ON_CONDITION / OVERWRITE) and
           dependent_variables (co-operands of the target variable in read lines).

    Edges: deduplicated (source, target, type) with a 'scopes' list recording
           which usage node(s) — identified as "block:line" — reach each edge.
    """
    var_upper = variable.upper()

    # block_id -> {relevant_lines: list, dependent_vars: set}
    node_data: Dict[str, Dict[str, Any]] = {}
    # (from, to, type) -> set of scope strings
    edge_scopes: Dict[Tuple[str, str, str], Set[str]] = {}

    def _ensure_node(bid: str) -> None:
        if bid not in node_data:
            node_data[bid] = {"relevant_lines": [], "dependent_vars": set()}

    def _dep_vars_from_args(args: List[str]) -> List[str]:
        """Extract co-operands that are genuine storage variables."""
        return [normalize_token(str(a)) for a in args if _is_dep_var_candidate(str(a), skip_var=variable)]

    # ── Seed: the usage lines themselves (CONDITION_TEST / READER) ────────────
    for loc in usage_locations:
        block_id = str(loc.get("block", ""))
        line     = loc.get("line")
        inst     = str(loc.get("inst", "")).upper()
        detail   = str(loc.get("detail", ""))
        args     = loc.get("args", []) or []
        if isinstance(args, str):
            args = [args]

        _ensure_node(block_id)
        node_data[block_id]["relevant_lines"].append({
            "line": line, "inst": inst,
            "role": _inst_to_role(inst, "CONDITION_TEST"), "detail": detail,
        })
        node_data[block_id]["dependent_vars"].update(_dep_vars_from_args(args))

    # ── Forward trace paths ───────────────────────────────────────────────────
    for path in forward_from_usage_paths:
        usage_block = str(path.get("usage_block", ""))
        usage_line  = path.get("usage_line", 0)
        scope       = f"{usage_block}:{usage_line}"

        _ensure_node(usage_block)  # start block always a node

        # Relevant entries: uses (CONDITION_TEST/READER/BRANCH_ON_CONDITION),
        # next_overwrites (OVERWRITE), and side_effects (SIDE_EFFECT_SETTER)
        relevant_entries = (list(path.get("uses", []) or []) +
                            list(path.get("next_overwrites", []) or []) +
                            list(path.get("side_effects", []) or []))

        for entry in relevant_entries:
            role    = str(entry.get("role", ""))
            if role not in _RELEVANT_ROLES:
                continue
            bid     = str(entry.get("block", ""))
            e_line  = entry.get("line")
            e_inst  = str(entry.get("inst", "")).upper()
            e_detail= str(entry.get("detail", ""))
            e_args  = entry.get("args", []) or []
            if isinstance(e_args, str):
                e_args = [e_args]

            _ensure_node(bid)
            node_data[bid]["relevant_lines"].append({
                "line": e_line, "inst": e_inst,
                "role": _inst_to_role(e_inst, role), "detail": e_detail,
            })
            if role in _VAR_READ_ROLES:
                node_data[bid]["dependent_vars"].update(_dep_vars_from_args(e_args))

        # CFG edges
        for edge in path.get("block_edges", []) or []:
            src  = str(edge.get("from", ""))
            tgt  = str(edge.get("to", ""))
            etype= str(edge.get("type", "BRANCH"))
            if not src or not tgt:
                continue
            _ensure_node(src)
            _ensure_node(tgt)
            key = (src, tgt, etype)
            edge_scopes.setdefault(key, set()).add(scope)

    # ── Backward guard conditions from predecessor blocks ────────────────────
    # usage_backward_guards: block_id -> list of TRIGGER instruction dicts
    # found by walking backward through the CFG from each usage site.
    for block_id, guard_lines in (usage_backward_guards or {}).items():
        _ensure_node(block_id)
        for g in guard_lines:
            node_data[block_id]["relevant_lines"].append({
                "line":   g.get("line", 0),
                "inst":   g.get("inst", ""),
                "role":   _inst_to_role(g.get("inst", ""), "TRIGGER"),
                "detail": g.get("detail", ""),
            })
            node_data[block_id]["dependent_vars"].update(
                _dep_vars_from_args(g.get("args") or [])
            )

    # ── Build final nodes (dedup relevant_lines by (line, inst, role)) ────────
    nodes: List[Dict[str, Any]] = []
    for bid in sorted(node_data.keys()):
        data = node_data[bid]
        seen: Set[Tuple] = set()
        deduped: List[Dict[str, Any]] = []
        for entry in data["relevant_lines"]:
            key = (entry.get("line"), entry.get("inst"), entry.get("role"))
            if key not in seen:
                seen.add(key)
                deduped.append(entry)
        deduped.sort(key=lambda e: (e.get("line") or 0))
        nodes.append({
            "id": bid,
            "code": block_source_index.get(bid, ""),
            "relevant_code_lines": deduped,
            "dependent_variables": sorted(data["dependent_vars"]),
        })

    # ── Build final edges ─────────────────────────────────────────────────────
    edges: List[Dict[str, Any]] = [
        {"source": src, "target": tgt, "type": etype, "direction": ["forward"], "scopes": sorted(scopes)}
        for (src, tgt, etype), scopes in sorted(edge_scopes.items())
    ]

    return {"nodes": nodes, "edges": edges}


# ---------------------------------------------------------------------------
# Shared helper — forward + backward guard trace for a set of usage hits
# ---------------------------------------------------------------------------

def _trace_usage_sites_in_asm(
    variable: str,
    stem: str,
    bp: Path,
    bp_data: Dict[str, Any],
    asm_file: Path,
    usage_hits: List[Dict[str, Any]],
    fwd_tracer: "ForwardLineageTracer",
    block_source_index: Dict[str, str],
    warnings: List[str],
) -> Tuple[Dict[str, Any], List[str]]:
    """Forward + backward guard trace for usage (read) sites in an ASM file.

    Returns ``(usage_graph, discovered_downstream)`` where discovered_downstream
    is a sorted list of stem strings found via forward cross-file calls.

    Called from both ``_trace_modifier_asm`` (usage sites alongside setters) and
    ``_trace_downstream_usages`` (usage-only files).
    """
    FORWARD_USE_ROLES = {"READER", "CONDITION_TEST", "BRANCH_ON_CONDITION"}
    SIDE_EFFECT_ROLES = {"SIDE_EFFECT_SETTER", "SUBROUTINE_USAGE"}

    # ── Forward trace from each usage site ───────────────────────────────────
    forward_from_usage_paths: List[Dict[str, Any]] = []
    for hit in usage_hits:
        s_block = str(hit.get("block", ""))
        s_line = int(hit.get("line", 0))
        if not s_block or not s_line:
            continue
        print(f"    from {stem}:{s_block}:{s_line}", file=sys.stderr)
        try:
            fwd_from = fwd_tracer.trace_forward_from_setter(
                target_variable=variable,
                source_asm_file=asm_file,
                blueprint_file=bp,
                start_block_id=s_block,
                start_line=s_line - 1,
            )
            chain = fwd_from.lineage_chain
            block_edges = fwd_tracer.compute_cfg_block_edges(bp, s_block, s_line)
            forward_from_usage_paths.append({
                "usage_block":      s_block,
                "usage_line":       s_line,
                "usage_inst":       hit.get("inst"),
                "usage_detail":     hit.get("detail"),
                "uses":             [e for e in chain if e.get("role") in FORWARD_USE_ROLES],
                "next_overwrites":  [e for e in chain if e.get("role") == "OVERWRITE"],
                "side_effects":     [e for e in chain if e.get("role") in SIDE_EFFECT_ROLES],
                "cross_file_calls": [e for e in chain if e.get("role") == "CROSS_FILE_CALL"],
                "block_edges":      block_edges,
                "warnings":         [str(w) for w in fwd_from.data_quality_warnings],
            })
        except Exception as exc:
            msg = f"Could not trace forward from {stem}:{s_block}:{s_line}: {exc}"
            warnings.append(msg)
            print(f"    WARNING: {msg}", file=sys.stderr)

    # ── Backward guard conditions: walk CFG from each usage block ────────────
    # block_id -> list of TRIGGER instruction dicts whose co-operands are dep_vars
    usage_backward_guards: Dict[str, List[Dict[str, Any]]] = {}
    backward_usage_cross_file_targets: Set[str] = set()
    print(f"  [usage bwd] {stem} — tracing backward guards from usage blocks", file=sys.stderr)
    try:
        block_map = {b["id"]: b for b in bp_data.get("blocks", [])}
        usage_line_by_block: Dict[str, int] = {}
        for hit in usage_hits:
            ub = str(hit.get("block", ""))
            ul = int(hit.get("line") or 0)
            if ub and ul:
                if ub not in usage_line_by_block or ul < usage_line_by_block[ub]:
                    usage_line_by_block[ub] = ul

        visited: Set[str] = set()
        in_queue: Set[str] = set()
        queue: List[Tuple[str, int]] = [(ub, 0) for ub in usage_line_by_block]
        in_queue.update(usage_line_by_block.keys())
        MAX_DEPTH = 8

        while queue:
            cur_block, depth = queue.pop(0)
            if cur_block in visited or depth > MAX_DEPTH:
                continue
            visited.add(cur_block)

            cur_data = block_map.get(cur_block)
            if not cur_data:
                continue

            cutoff = usage_line_by_block.get(cur_block)
            guard_lines: List[Dict[str, Any]] = []
            for entry in (cur_data.get("flow", []) or []):
                inst = str(entry.get("inst", "")).upper()
                e_line = int(entry.get("line") or 0)
                if cutoff is not None and e_line >= cutoff:
                    continue

                # Backward usage walk contribution to downstream discovery:
                # include cross-file calls found in predecessor blocks and in
                # earlier lines of the usage block.
                if inst in CROSS_FILE_INST:
                    stem2 = _cross_file_target_stem_from_flow_entry(entry)
                    if stem2:
                        backward_usage_cross_file_targets.add(stem2)

                if inst not in TRIGGER_INST:
                    continue
                args = list(entry.get("args", []) or [])
                dep_candidates = [a for a in args if _is_dep_var_candidate(str(a), skip_var=variable)]
                if not dep_candidates:
                    continue
                detail = ",".join(str(a) for a in args)
                guard_lines.append({"line": e_line, "inst": inst, "args": args, "detail": detail})

            if guard_lines:
                if cur_block not in usage_backward_guards:
                    usage_backward_guards[cur_block] = []
                seen_keys = {(g["line"], g["inst"]) for g in usage_backward_guards[cur_block]}
                for g in guard_lines:
                    if (g["line"], g["inst"]) not in seen_keys:
                        usage_backward_guards[cur_block].append(g)
                        seen_keys.add((g["line"], g["inst"]))

            for inc in (cur_data.get("incoming_branches") or []):
                src = str(inc.get("source", ""))
                if src and src not in in_queue and src not in visited:
                    in_queue.add(src)
                    queue.append((src, depth + 1))
    except Exception as exc:
        msg = f"Could not trace backward guards for {stem} usages: {exc}"
        warnings.append(msg)
        print(f"  WARNING: {msg}", file=sys.stderr)

    usage_graph = _build_forward_usage_graph(
        variable, usage_hits, forward_from_usage_paths, block_source_index,
        usage_backward_guards=usage_backward_guards,
    )
    _apply_dc_filter(usage_graph, _load_dc_constants(bp_data))

    discovered: List[str] = sorted({
        s for fp in forward_from_usage_paths
        for call in fp.get("cross_file_calls", [])
        for s in [_cross_file_target_stem(call)] if s
    } | backward_usage_cross_file_targets)
    return usage_graph, discovered


# ---------------------------------------------------------------------------
# Downstream — forward + backward trace from each usage line
# ---------------------------------------------------------------------------

def _trace_downstream_usages(
    variable: str,
    stem: str,
    bp: Path,
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    usage_hits: List[Dict[str, Any]],
    fwd_tracer: "ForwardLineageTracer",
    warnings: List[str],
) -> Dict[str, Any]:
    """Forward + backward guard trace from each usage (read) line in a downstream ASM file."""
    asm_file: Optional[Path] = None
    if asm_dir:
        candidate = asm_dir / f"{stem}.asm"
        if candidate.exists():
            asm_file = candidate
    if asm_file is None:
        for search in [blueprint_dir.parent.parent / "asm",
                       blueprint_dir.parent / "asm",
                       blueprint_dir]:
            candidate = search / f"{stem}.asm"
            if candidate.exists():
                asm_file = candidate
                break

    if asm_file is None:
        msg = f"Could not find {stem}.asm source file."
        warnings.append(msg)
        print(f"  WARNING: {msg}", file=sys.stderr)
        return {
            "role": "downstream",
            "file_type": "asm",
            "ref_check": "has_usages",
            "asm_source_unavailable": True,
            "warnings": [msg],
        }

    print(f"  [usage fwd] {asm_file} ({len(usage_hits)} usage(s))", file=sys.stderr)
    bp_data = load_blueprint(bp)
    block_source_index = _build_asm_block_source_index(bp_data, asm_file)

    usage_graph, discovered = _trace_usage_sites_in_asm(
        variable, stem, bp, bp_data, asm_file, usage_hits,
        fwd_tracer, block_source_index, warnings,
    )
    return {
        "role": "downstream",
        "file_type": "asm",
        "ref_check": "has_usages",
        "usage_graph": usage_graph,
        "_discovered_downstream": discovered,
    }


# ---------------------------------------------------------------------------
# Downstream — per-file dispatch (setter → full, usage-only → forward, none → skip)
# ---------------------------------------------------------------------------

def _trace_downstream_file(
    variable: str,
    stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    tracer: LineageTracer,
    fwd_tracer: "ForwardLineageTracer",
    warnings: List[str],
    caller_stem: Optional[str] = None,
) -> Dict[str, Any]:
    """Decide what to trace in a downstream file and do it.

    - C++ file       → record call sites + function source via find_asm_to_cpp_callers
    - setter found   → full backward + forward treatment (same as modifier)
    - usage only     → forward trace from each usage line
    - no references  → record no_references, nothing to trace
    """
    bp = blueprint_dir / f"{stem}.asm.json"
    if not bp.exists():
        bp = blueprint_dir / f"{stem}.cpp.json"
    if not bp.exists():
        return {"role": "downstream", "file_type": "unknown", "ref_check": "blueprint_not_found"}

    file_type = "asm" if bp.name.endswith(".asm.json") else "cpp"

    # ── C++ downstream: record call sites + function source ──────────────────
    if file_type == "cpp":
        if not caller_stem:
            return {"role": "downstream_cpp", "file_type": "cpp",
                    "ref_check": "no_caller_stem_provided"}
        print(f"  [downstream cpp] {stem} (called from {caller_stem})", file=sys.stderr)
        try:
            call_sites = find_asm_to_cpp_callers(caller_stem, stem, blueprint_dir, asm_dir)
        except Exception as exc:
            msg = f"Could not get call sites for {caller_stem}→{stem}: {exc}"
            warnings.append(msg)
            print(f"  WARNING: {msg}", file=sys.stderr)
            return {"role": "downstream_cpp", "file_type": "cpp", "ref_check": "error",
                    "warnings": [msg]}
        source_index = _build_func_source_index(blueprint_dir, asm_dir, stem)
        for site in call_sites:
            fn = site.get("cpp_function")
            if fn and fn in source_index:
                site["function_code"] = source_index[fn]
        print(f"  [downstream cpp] found {len(call_sites)} call site(s)", file=sys.stderr)
        return {
            "role": "downstream_cpp",
            "file_type": "cpp",
            "call_sites": call_sites,
        }

    setter_hits, err = scan_blueprint_for_setters(bp, variable)
    if err:
        warnings.append(err)

    usage_hits, err2 = scan_blueprint_for_usages(bp, variable)
    if err2:
        warnings.append(err2)

    if not setter_hits and not usage_hits:
        print(f"  No references to '{variable}' in '{stem}'.", file=sys.stderr)
        return {"role": "downstream", "file_type": file_type, "ref_check": "no_references"}

    result: Dict[str, Any] = {"file_type": "asm"}

    if setter_hits:
        print(f"  Setter(s) found in '{stem}' — running backward + forward trace.", file=sys.stderr)
        setter_result = _trace_modifier_asm(variable, stem, blueprint_dir, asm_dir, tracer,
                                            warnings, fwd_tracer=fwd_tracer)
        result.update(setter_result)
        result["setter_locations"] = setter_hits

    if usage_hits:
        print(f"  Usage(s) found in '{stem}' — running forward + backward trace.", file=sys.stderr)
        usage_result = _trace_downstream_usages(variable, stem, bp, blueprint_dir, asm_dir,
                                                usage_hits, fwd_tracer, warnings)
        if "usage_graph" in usage_result:
            result["usage_graph"] = usage_result["usage_graph"]
        # Merge discovered downstream from both traces
        existing = set(result.get("_discovered_downstream", []))
        new_ones = set(usage_result.get("_discovered_downstream", []))
        result["_discovered_downstream"] = sorted(existing | new_ones)

    if setter_hits and usage_hits:
        result["role"] = "downstream_modifier"
        result["ref_check"] = "has_setters_and_usages"
        result["usage_locations"] = usage_hits
    elif setter_hits:
        result["role"] = "downstream_modifier"
        result["ref_check"] = "has_setters"
    else:
        result["role"] = "downstream"
        result["ref_check"] = "has_usages"

    return result


# ---------------------------------------------------------------------------
# Unified modifier/downstream traversal (file_queue + variable_pool)
# ---------------------------------------------------------------------------

def _resolve_file_type(
    stem: str,
    blueprint_dir: Path,
    file_type_map: Dict[str, str],
) -> str:
    stem_norm = str(stem).strip()
    stem_lower = stem_norm.lower()
    t = (
        file_type_map.get(stem_norm)
        or file_type_map.get(stem_lower)
        or file_type_map.get(stem_norm.upper())
    )
    if t in {"asm", "cpp"}:
        return t
    if (
        (blueprint_dir / f"{stem_norm}.asm.json").exists()
        or (blueprint_dir / f"{stem_lower}.asm.json").exists()
        or (blueprint_dir / f"{stem_norm}.mac.json").exists()
        or (blueprint_dir / f"{stem_lower}.mac.json").exists()
    ):
        return "asm"
    if (blueprint_dir / f"{stem_norm}.cpp.json").exists() or (blueprint_dir / f"{stem_lower}.cpp.json").exists():
        return "cpp"
    return "unknown"


def _collect_related_vars_from_trace_payload(
    variable: str,
    payload: Dict[str, Any],
) -> Set[str]:
    related: Set[str] = set()
    for graph_key in ("modifier_graph", "usage_graph", "call_graph"):
        graph = payload.get(graph_key) or {}
        for node in graph.get("nodes", []) or []:
            for dep in (node.get("dependent_variables") or []):
                dep_tok = normalize_token(str(dep))
                if not dep_tok:
                    continue
                if is_dep_var_candidate(
                    dep_tok,
                    skip_var=variable,
                    allow_register_dependencies=False,
                ):
                    related.add(dep_tok)
    return related


def _trace_cpp_downstream_calls(
    stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    graph_payload: Dict[str, Any],
    file_type_map: Dict[str, str],
    warnings: List[str],
) -> Tuple[Dict[str, Any], List[str]]:
    """Collect downstream call flow from a C++ file without variable scanning."""
    calls: List[Dict[str, Any]] = []
    discovered: Set[str] = set()
    source_index = _build_func_source_index(blueprint_dir, asm_dir, stem)

    for edge in sorted(
        [e for e in (graph_payload.get("edges", []) or []) if e.get("source") == stem],
        key=lambda e: (str(e.get("target", "")), str((e.get("instructions") or ["?"])[0])),
    ):
        target = str(edge.get("target", "")).strip()
        if not target:
            continue
        instruction = str((edge.get("instructions") or ["?"])[0])
        target_type = _resolve_file_type(target, blueprint_dir, file_type_map)
        call_sites: List[Dict[str, Any]] = []
        try:
            if target_type == "asm":
                call_sites = find_cpp_callers(stem, target, blueprint_dir)
                func_key = "function"
            elif target_type == "cpp":
                call_sites = find_cpp_to_cpp_callers(stem, target, blueprint_dir)
                func_key = "caller_function"
            else:
                func_key = ""
        except Exception as exc:
            msg = f"Could not collect C++ downstream call sites for {stem}->{target}: {exc}"
            warnings.append(msg)
            print(f"  WARNING: {msg}", file=sys.stderr)
            func_key = ""

        if func_key:
            for site in call_sites:
                fn = site.get(func_key)
                if fn and fn in source_index:
                    site["function_code"] = source_index[fn]

        calls.append({
            "target_file": target,
            "target_type": target_type,
            "instruction": instruction,
            "call_sites": call_sites,
        })
        discovered.add(target.lower())

    return {
        "role": "downstream_cpp",
        "file_type": "cpp",
        "downstream_calls": calls,
    }, sorted(discovered)


def _run_unified_modifier_downstream_traversal(
    root_variable: str,
    modifier_stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    tracer: LineageTracer,
    fwd_tracer: "ForwardLineageTracer",
    graph_payload: Dict[str, Any],
    file_type_map: Dict[str, str],
    warnings: List[str],
    max_variable_depth: int,
    max_file_depth: int,
    files: Dict[str, Any],
) -> Dict[str, Any]:
    """Unified queue traversal for modifier + downstream files.

    - File queue starts from modifier only.
    - Global variable pool grows via related vars found in traces.
    - One pass per file; while active, process newly discovered variables too.
    """
    file_queue: List[Tuple[str, int, Optional[str]]] = [(modifier_stem, 0, None)]
    enqueued: Set[str] = {modifier_stem}
    visited_files: Set[str] = set()

    variable_pool_depth: Dict[str, int] = {normalize_token(root_variable): 0}

    def _record_discovery(file_stem: str, parent_stem: str) -> None:
        """Preserve all discovery parents, not just the first queue parent."""
        child_rec = files.setdefault(file_stem, {})
        child_rec.setdefault("discovered_from", [])
        if parent_stem and parent_stem not in child_rec["discovered_from"]:
            child_rec["discovered_from"].append(parent_stem)

    while file_queue:
        stem, file_depth, discovered_from = file_queue.pop(0)
        if stem in visited_files:
            continue
        visited_files.add(stem)

        file_type = _resolve_file_type(stem, blueprint_dir, file_type_map)
        rec = files.setdefault(stem, {})
        rec.setdefault("file_type", file_type)
        rec["queue_depth"] = file_depth
        rec.setdefault("discovered_from", [])
        if discovered_from and discovered_from not in rec["discovered_from"]:
            rec["discovered_from"].append(discovered_from)
        discovered_files_set: Set[str] = set(rec.get("discovered_files", []))

        if file_type == "cpp":
            cpp_payload, cpp_discovered = _trace_cpp_downstream_calls(
                stem=stem,
                blueprint_dir=blueprint_dir,
                asm_dir=asm_dir,
                graph_payload=graph_payload,
                file_type_map=file_type_map,
                warnings=warnings,
            )
            rec["downstream_cpp"] = cpp_payload
            for nf in cpp_discovered:
                discovered_files_set.add(nf)
                _record_discovery(nf, stem)
                if nf in visited_files or nf in enqueued:
                    continue
                next_depth = file_depth + 1
                if max_file_depth >= 0 and next_depth > max_file_depth:
                    continue
                file_queue.append((nf, next_depth, stem))
                enqueued.add(nf)
            rec["discovered_files"] = sorted(discovered_files_set)
            continue

        if file_type != "asm":
            rec["status"] = "blueprint_not_found"
            rec["discovered_files"] = sorted(discovered_files_set)
            continue

        bp_asm = blueprint_dir / f"{stem}.asm.json"
        bp_mac = blueprint_dir / f"{stem}.mac.json"
        bp = bp_asm if bp_asm.exists() else bp_mac if bp_mac.exists() else None
        if bp is None:
            rec["status"] = "blueprint_not_found"
            rec["discovered_files"] = sorted(discovered_files_set)
            continue

        rec.setdefault("variables", {})
        processed_vars: Set[str] = set()

        # Process all vars currently in pool, including vars discovered during this file's processing.
        while True:
            pending = [
                v for v, depth in variable_pool_depth.items()
                if v not in processed_vars and (max_variable_depth < 0 or depth <= max_variable_depth)
            ]
            if not pending:
                break
            pending.sort(key=lambda v: (variable_pool_depth.get(v, 10**9), v))
            variable = pending[0]
            processed_vars.add(variable)

            setter_hits, serr = scan_blueprint_for_setters(bp, variable)
            if serr:
                warnings.append(serr)
            usage_hits, uerr = scan_blueprint_for_usages(bp, variable)
            if uerr:
                warnings.append(uerr)

            var_rec: Dict[str, Any] = {
                "variable_depth": variable_pool_depth.get(variable, 0),
                "setter_locations": setter_hits,
                "usage_locations": usage_hits,
            }

            discovered_here: Set[str] = set()
            related_here: Set[str] = set()

            if setter_hits or usage_hits:
                trace_payload = _trace_modifier_asm(
                    variable=variable,
                    stem=stem,
                    blueprint_dir=blueprint_dir,
                    asm_dir=asm_dir,
                    tracer=tracer,
                    warnings=warnings,
                    fwd_tracer=fwd_tracer,
                )
                discovered_here = set(trace_payload.pop("_discovered_downstream", []))
                related_here = _collect_related_vars_from_trace_payload(variable, trace_payload)
                var_rec["trace"] = trace_payload
            else:
                var_rec["trace"] = {
                    "role": "variable_scan",
                    "file_type": "asm",
                    "ref_check": "no_references",
                }

            var_rec["discovered_files"] = sorted(discovered_here)
            var_rec["related_variables_discovered"] = sorted(related_here)
            rec["variables"][variable] = var_rec

            # Grow variable pool by one level from current variable.
            next_var_depth = variable_pool_depth.get(variable, 0) + 1
            if max_variable_depth < 0 or next_var_depth <= max_variable_depth:
                for rv in sorted(related_here):
                    rv_up = normalize_token(str(rv))
                    if not rv_up:
                        continue
                    if not is_dep_var_candidate(rv_up, skip_var=variable, allow_register_dependencies=False):
                        continue
                    old = variable_pool_depth.get(rv_up)
                    if old is None or next_var_depth < old:
                        variable_pool_depth[rv_up] = next_var_depth

            # Grow file queue from discovered callees.
            for nf in sorted(discovered_here):
                discovered_files_set.add(nf)
                _record_discovery(nf, stem)
                if nf in visited_files or nf in enqueued:
                    continue
                next_depth = file_depth + 1
                if max_file_depth >= 0 and next_depth > max_file_depth:
                    continue
                file_queue.append((nf, next_depth, stem))
                enqueued.add(nf)

        rec["processed_variables"] = sorted(
            processed_vars,
            key=lambda v: (variable_pool_depth.get(v, 10**9), v),
        )
        rec["discovered_files"] = sorted(discovered_files_set)

    return {
        "visited_files": sorted(visited_files),
        "variable_pool_depth": dict(sorted(variable_pool_depth.items(), key=lambda kv: (kv[1], kv[0]))),
    }


def _synchronize_variable_depths_with_pool(
    files: Dict[str, Any],
    variable_pool_depth: Dict[str, int],
) -> int:
    """Align per-file variable_depth with final global pool depth.

    A variable may first be discovered at a deeper level in one file, then later
    found at a shallower level through another path. This pass keeps output
    metadata consistent by using the final minimum depth from variable_pool_depth.
    Returns the number of variable records updated.
    """
    updated = 0
    for _stem, rec in files.items():
        for var_name, var_rec in (rec.get("variables") or {}).items():
            if var_name not in variable_pool_depth:
                continue
            canonical_depth = variable_pool_depth[var_name]
            if var_rec.get("variable_depth") != canonical_depth:
                var_rec["variable_depth"] = canonical_depth
                updated += 1
    return updated


# ---------------------------------------------------------------------------
# Dependent variable leveled lineage
# ---------------------------------------------------------------------------

def _find_dep_var_line(dep_var: str, relevant_lines: List[Dict[str, Any]]) -> Optional[int]:
    """Return the first line number in relevant_lines whose detail contains dep_var."""
    dep_upper = dep_var.upper()
    for rl in relevant_lines:
        for part in (rl.get("detail", "") or "").replace(",", " ").split():
            if normalize_token(part).upper() == dep_upper:
                return rl.get("line")
    return relevant_lines[0].get("line") if relevant_lines else None


def _extract_dep_var_contexts(sections: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Collect (variable, file, block, line) for every dep var across all section nodes.

    Deduplicates by (variable, file) keeping the entry with the smallest line number,
    so trace_dependent_variable starts from the earliest usage of each dep var per file.
    """
    seen: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for file_stem, section in sections.items():
        for graph_key in ("modifier_graph", "call_graph", "usage_graph"):
            for node in (section.get(graph_key) or {}).get("nodes", []):
                block_id = node.get("id", "")
                relevant_lines = node.get("relevant_code_lines", [])
                for dep_var in node.get("dependent_variables", []):
                    usage_line = _find_dep_var_line(dep_var, relevant_lines)
                    if usage_line is None:
                        continue
                    key = (dep_var.upper(), file_stem)
                    if key not in seen or usage_line < seen[key]["line"]:
                        seen[key] = {
                            "variable": dep_var,
                            "file": file_stem,
                            "block": block_id,
                            "line": usage_line,
                        }
    return list(seen.values())


_DEP_VAR_SKIP_ROLES  = {"DEPENDENT_VAR_USAGE", "FALLTHROUGH_ENTRY", "BRANCH_ENTRY", "SEQUENTIAL"}
_DEP_VAR_DATA_ROLES  = {"SETTER", "TRIGGER", "GUARD_BRANCH", "MACRO_BRANCH"}  # roles whose args → dep_vars


def _build_dep_var_trace_graph(
    results: Any,
    dep_variable: str,
    usage_file: Path,
) -> Dict[str, Any]:
    """Build a simple nodes+edges graph from a dep-var TraceResults."""
    file_name = usage_file.name
    dep_upper = dep_variable.upper()
    node_data: Dict[str, Dict[str, Any]] = {}

    for entry in results.lineage_chain:
        if entry.get("file") != file_name:
            continue
        role = entry.get("role", "")
        if role in _DEP_VAR_SKIP_ROLES:
            continue
        block_id = entry.get("block", "")
        # Skip the synthetic root block used internally by the tracer
        if not block_id or block_id == "$IS$":
            continue
        if block_id not in node_data:
            node_data[block_id] = {"relevant_lines": [], "dep_vars": set()}
        inst = entry.get("inst", "")
        mapped_role = _inst_to_role(inst, role)
        rl = {
            "line": entry.get("line", 0),
            "inst": inst,
            "role": mapped_role,
            "detail": entry.get("detail", ""),
        }
        existing = node_data[block_id]["relevant_lines"]
        if not any(e["line"] == rl["line"] and e["role"] == rl["role"] for e in existing):
            existing.append(rl)
        # Only collect dep_vars from data-relevant roles (conditions/guards),
        # not from navigation or cross-file call entries.
        if role in _DEP_VAR_DATA_ROLES:
            for arg in (entry.get("args") or []):
                if _is_dep_var_candidate(str(arg), skip_var=dep_variable):
                    node_data[block_id]["dep_vars"].add(normalize_token(str(arg)))

    nodes = [
        {
            "id": block_id,
            "relevant_code_lines": sorted(data["relevant_lines"], key=lambda x: x["line"]),
            "dependent_variables": sorted(data["dep_vars"]),
        }
        for block_id, data in node_data.items()
    ]

    # Build edges from consecutive non-skipped, non-root blocks in traversal order
    seen_blocks: List[str] = []
    for entry in results.lineage_chain:
        if entry.get("file") != file_name:
            continue
        if entry.get("role") in _DEP_VAR_SKIP_ROLES:
            continue
        block_id = entry.get("block", "")
        if block_id and block_id != "$IS$" and (not seen_blocks or seen_blocks[-1] != block_id):
            seen_blocks.append(block_id)

    edge_set: Set[Tuple[str, str]] = set()
    edges = []
    for i in range(len(seen_blocks) - 1):
        src, tgt = seen_blocks[i], seen_blocks[i + 1]
        if (src, tgt) not in edge_set:
            edges.append({"source": src, "target": tgt, "type": "BACKWARD", "direction": ["backward"]})
            edge_set.add((src, tgt))

    cross_file_calls = [
        {
            "file": dep.get("file", ""),
            "called_from_block": dep.get("called_from_block", ""),
            "line": dep.get("line", 0),
            "type": dep.get("type", ""),
        }
        for dep in results.dependent_files
    ]

    return {"nodes": nodes, "edges": edges, "cross_file_calls": cross_file_calls}


def _trace_dep_var_levels(
    level1_contexts: List[Dict[str, Any]],
    tracer: "LineageTracer",
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    max_depth: int = 2,
) -> Dict[str, Any]:
    """Trace each dependent variable backward through the chain, leveled by dep distance.

    level_1: direct deps of the primary variable (already collected from sections).
    level_2: deps found while tracing level_1 vars backward.
    ... up to max_depth.
    Cross-file following is unrestricted — dep vars are traced into any reachable file.
    """
    if max_depth <= 0:
        return {"max_depth": max_depth}

    output: Dict[str, Any] = {"max_depth": max_depth}
    already_traced: Set[str] = set()  # variable names already assigned a level

    current_contexts = level1_contexts
    level_num = 1

    while current_contexts and level_num <= max_depth:
        level_key = f"level_{level_num}"
        level_result: Dict[str, Any] = {}
        next_contexts: List[Dict[str, Any]] = []

        # Deduplicate by (variable, file) keeping smallest line
        deduped: Dict[Tuple[str, str], Dict[str, Any]] = {}
        for ctx in current_contexts:
            var_up = ctx["variable"].upper()
            if var_up in already_traced:
                continue
            key = (var_up, ctx["file"])
            if key not in deduped or ctx["line"] < deduped[key]["line"]:
                deduped[key] = ctx

        for (var_up, file_stem), ctx in deduped.items():
            dep_var = ctx["variable"]
            if var_up in already_traced:
                continue

            # Resolve paths
            asm_file = (asm_dir or blueprint_dir) / f"{file_stem}.asm"
            bp_file = blueprint_dir / f"{file_stem}.asm.json"
            if not asm_file.exists() or not bp_file.exists():
                continue

            print(f"  [dep_var L{level_num}] {dep_var} in {file_stem} @ block {ctx['block']} line {ctx['line']}",
                  file=sys.stderr)

            try:
                results = tracer.trace_dependent_variable(
                    dep_variable=dep_var,
                    usage_file=asm_file,
                    usage_block=ctx["block"],
                    usage_line=ctx["line"],
                    blueprint_file=bp_file,
                    primary_variable=dep_var,
                    reason=f"dep var at {file_stem}:{ctx['block']}:{ctx['line']}",
                )
            except Exception as exc:
                print(f"  WARNING: dep var trace failed for {dep_var} in {file_stem}: {exc}",
                      file=sys.stderr)
                continue

            trace_graph = _build_dep_var_trace_graph(results, dep_var, asm_file)
            try:
                _apply_dc_filter(trace_graph, _load_dc_constants(load_blueprint(bp_file)))
            except (OSError, ValueError, KeyError) as exc:
                print(f"  WARNING: could not load DC constants from {bp_file.name}: {exc}", file=sys.stderr)

            # Accumulate found_in entries across (var, file) — may appear in multiple blocks
            entry = level_result.setdefault(dep_var, {
                "found_in": [],
                "trace": trace_graph,
            })
            entry["found_in"].append({
                "file": file_stem,
                "block": ctx["block"],
                "line": ctx["line"],
            })
            # Add found_while_tracing for level 2+
            if level_num > 1 and "found_while_tracing" not in entry:
                entry["found_while_tracing"] = ctx.get("traced_from", dep_var)

            # Collect next-level contexts from this trace
            for dv in results.dependent_vars:
                next_var_up = dv["variable"].upper()
                if next_var_up not in already_traced and next_var_up != var_up:
                    next_contexts.append({
                        "variable": dv["variable"],
                        "file": file_stem,
                        "block": dv["block"],
                        "line": dv["line"],
                        "traced_from": dep_var,
                    })
            # Follow cross-file calls into any reachable file (no chain restriction)
            for dep_file_entry in results.dependent_files:
                dep_file_stem = str(dep_file_entry.get("file", "")).strip().lower()
                if dep_file_stem:
                    next_contexts.append({
                        "variable": dep_var,
                        "file": dep_file_stem,
                        "block": dep_file_entry.get("called_from_block", ""),
                        "line": dep_file_entry.get("line", 0),
                        "traced_from": dep_var,
                    })

            already_traced.add(var_up)

        if level_result:
            output[level_key] = level_result

        current_contexts = next_contexts
        level_num += 1

    return output


# ---------------------------------------------------------------------------
# Register dep vars via find_connected_variables
# ---------------------------------------------------------------------------

def _collect_register_dep_vars(
    edges: List[Tuple[str, str]],
    blueprint_dir: Path,
    asm_dir: Optional[Path],
) -> List[Dict[str, Any]]:
    """For each (caller, callee) edge, call find_all_connections().

    Returns a list of register dep-var entries to merge into dep_var_lineage.level_1.
    Each entry has: variable (register name), found_via, at_edge, direction,
    set_at, consumed_at (for passed) or set_at (for return).
    """
    register_deps: List[Dict[str, Any]] = []
    for caller, callee in edges:
        try:
            conn = find_all_connections(
                caller, callee,
                blueprint_dir,
                asm_dir or blueprint_dir,
            )
            edge_label = f"{caller}->{callee}"
            for cb in conn.get("connections", {}).get("call_boundary_registers", []):
                direction = cb.get("direction", "")
                for pr in cb.get("passed_registers", []):
                    register_deps.append({
                        "variable": pr["register"],
                        "found_via": "call_boundary",
                        "at_edge": edge_label,
                        "direction": direction,
                        "set_at": pr.get("set_by_caller"),
                        "consumed_at": pr.get("consumed_by_callee"),
                    })
                for rr in cb.get("return_registers", []):
                    register_deps.append({
                        "variable": rr["register"],
                        "found_via": "return_boundary",
                        "at_edge": edge_label,
                        "direction": direction,
                        "set_at": rr.get("set_by_callee"),
                    })
        except Exception as exc:
            print(
                f"  WARNING: find_connected_variables failed for {caller}->{callee}: {exc}",
                file=sys.stderr,
            )
    return register_deps


# ---------------------------------------------------------------------------
# Mode runners
# ---------------------------------------------------------------------------

def _run_simple_modifier_downstream(
    variable: str,
    modifier_stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    tracer: LineageTracer,
    fwd_tracer: "ForwardLineageTracer",
    graph_payload: Dict[str, Any],
    file_type_map: Dict[str, str],
    warnings: List[str],
    max_variable_depth: int,
    max_file_depth: int,
    files: Dict[str, Any],
) -> Dict[str, Any]:
    print(
        f"\n--- Unified modifier/downstream traversal "
        f"(var_depth={max_variable_depth}, file_depth={'infinite' if max_file_depth < 0 else max_file_depth}) ---",
        file=sys.stderr,
    )
    return _run_unified_modifier_downstream_traversal(
        root_variable=variable,
        modifier_stem=modifier_stem,
        blueprint_dir=blueprint_dir,
        asm_dir=asm_dir,
        tracer=tracer,
        fwd_tracer=fwd_tracer,
        graph_payload=graph_payload,
        file_type_map=file_type_map,
        warnings=warnings,
        max_variable_depth=max_variable_depth,
        max_file_depth=max_file_depth,
        files=files,
    )


def _run_legacy_modifier_downstream(
    variable: str,
    modifier_stem: str,
    chain_files: List[str],
    sections: Dict[str, Any],
    warnings: List[str],
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    tracer: LineageTracer,
    fwd_tracer: "ForwardLineageTracer",
    max_dep_depth: int,
) -> Dict[str, Any]:
    print(f"\n--- Tracing modifier: {modifier_stem} ---", file=sys.stderr)
    modifier_result = _trace_modifier_asm(
        variable=variable,
        stem=modifier_stem,
        blueprint_dir=blueprint_dir,
        asm_dir=asm_dir,
        tracer=tracer,
        warnings=warnings,
        fwd_tracer=fwd_tracer,
    )
    discovered_downstream: List[str] = modifier_result.pop("_discovered_downstream", [])
    sections[modifier_stem] = modifier_result

    visited_downstream: Set[str] = set(sections.keys()) | {modifier_stem}
    downstream_queue: List[Tuple[str, str]] = [
        (s, modifier_stem)
        for s in discovered_downstream
        if s not in visited_downstream
    ]
    for s, _ in downstream_queue:
        visited_downstream.add(s)

    downstream_edges: List[Tuple[str, str]] = []
    if downstream_queue:
        print(
            f"\n--- Tracing downstream files (BFS seed: "
            f"{', '.join(s for s, _ in downstream_queue)}) ---",
            file=sys.stderr,
        )

    while downstream_queue:
        stem, caller_for_stem = downstream_queue.pop(0)
        downstream_edges.append((caller_for_stem, stem))
        print(f"\n--- Downstream: {stem} (discovered from {caller_for_stem}) ---",
              file=sys.stderr)
        result = _trace_downstream_file(
            variable=variable,
            stem=stem,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            tracer=tracer,
            fwd_tracer=fwd_tracer,
            warnings=warnings,
            caller_stem=caller_for_stem,
        )
        newly_discovered: List[str] = result.pop("_discovered_downstream", [])
        sections[stem] = result

        for new_stem in newly_discovered:
            if new_stem not in visited_downstream:
                visited_downstream.add(new_stem)
                downstream_queue.append((new_stem, stem))
                print(f"  [downstream BFS] enqueued '{new_stem}' (discovered from {stem})",
                      file=sys.stderr)

    dep_var_lineage: Dict[str, Any] = {}
    if max_dep_depth > 0:
        print(f"\n--- Tracing dependent variable levels (max depth: {max_dep_depth}) ---",
              file=sys.stderr)
        level1_contexts = _extract_dep_var_contexts(sections)
        print(f"  Found {len(level1_contexts)} unique (dep_var, file) contexts from main trace.",
              file=sys.stderr)
        dep_var_lineage = _trace_dep_var_levels(
            level1_contexts=level1_contexts,
            tracer=tracer,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            max_depth=max_dep_depth,
        )

        chain_edges: List[Tuple[str, str]] = [
            (chain_files[i], chain_files[i + 1]) for i in range(len(chain_files) - 1)
        ]
        all_edges = chain_edges + downstream_edges
        print(
            f"\n--- Collecting register connections "
            f"({len(chain_edges)} chain + {len(downstream_edges)} downstream edge(s)) ---",
            file=sys.stderr,
        )
        register_dep_vars = _collect_register_dep_vars(all_edges, blueprint_dir, asm_dir)
        if register_dep_vars:
            print(f"  Found {len(register_dep_vars)} register connection(s).", file=sys.stderr)
            level_1 = dep_var_lineage.setdefault("level_1", {})
            for rdv in register_dep_vars:
                reg = rdv["variable"]
                if reg not in level_1:
                    level_1[reg] = {"register_connections": []}
                level_1[reg].setdefault("register_connections", []).append(rdv)

    return dep_var_lineage


# ---------------------------------------------------------------------------
# Output cleanup helpers
# ---------------------------------------------------------------------------

def _clean_simple_output_files(
    files: Dict[str, Any],
) -> Tuple[Dict[str, Any], Dict[str, int]]:
    """Return a reduced simple-mode files payload and cleanup stats.

    Cleanup policy:
    - Drop files with blueprint_not_found status.
    - Drop variables with no setter/usage refs in that file.
    - Drop empty helper arrays/fields to reduce JSON size.
    - Drop processed_variables (redundant in clean output).
    """
    cleaned: Dict[str, Any] = {}
    dropped_files = 0
    dropped_vars = 0
    pruned_file_discovered_refs = 0
    pruned_var_discovered_refs = 0

    for stem, rec in files.items():
        if rec.get("status") == "blueprint_not_found":
            dropped_files += 1
            continue

        out: Dict[str, Any] = {}
        for key in (
            "file_type",
            "queue_depth",
            "upstream",
            "downstream_cpp",
            "status",
        ):
            if key in rec:
                out[key] = rec[key]

        discovered_from = rec.get("discovered_from") or []
        if discovered_from:
            out["discovered_from"] = discovered_from
        discovered_files = rec.get("discovered_files") or []
        if discovered_files:
            out["discovered_files"] = discovered_files

        vars_in = rec.get("variables") or {}
        if vars_in:
            vars_out: Dict[str, Any] = {}
            for var_name, var_rec in vars_in.items():
                setter_locs = var_rec.get("setter_locations") or []
                usage_locs = var_rec.get("usage_locations") or []
                if not setter_locs and not usage_locs:
                    dropped_vars += 1
                    continue

                vout: Dict[str, Any] = {
                    "variable_depth": var_rec.get("variable_depth", 0),
                    "trace": var_rec.get("trace", {}),
                }
                if setter_locs:
                    vout["setter_locations"] = setter_locs
                if usage_locs:
                    vout["usage_locations"] = usage_locs

                v_disc = var_rec.get("discovered_files") or []
                if v_disc:
                    vout["discovered_files"] = v_disc
                v_rel = var_rec.get("related_variables_discovered") or []
                if v_rel:
                    vout["related_variables_discovered"] = v_rel

                vars_out[var_name] = vout

            if vars_out:
                out["variables"] = vars_out

        if out:
            cleaned[stem] = out

    # Second pass: prune discovered_files refs to entries that remain in cleaned
    # output so links are internally consistent after dropping files/variables.
    kept_files = set(cleaned.keys())
    for stem, rec in cleaned.items():
        file_disc = rec.get("discovered_files")
        if file_disc is not None:
            filtered = [d for d in file_disc if d in kept_files and d != stem]
            pruned_file_discovered_refs += max(0, len(file_disc) - len(filtered))
            if filtered:
                rec["discovered_files"] = filtered
            else:
                rec.pop("discovered_files", None)

        for _var_name, var_rec in (rec.get("variables") or {}).items():
            var_disc = var_rec.get("discovered_files")
            if var_disc is None:
                continue
            filtered = [d for d in var_disc if d in kept_files and d != stem]
            pruned_var_discovered_refs += max(0, len(var_disc) - len(filtered))
            if filtered:
                var_rec["discovered_files"] = filtered
            else:
                var_rec.pop("discovered_files", None)

    stats = {
        "dropped_blueprint_not_found_files": dropped_files,
        "dropped_no_reference_variables": dropped_vars,
        "pruned_file_discovered_refs": pruned_file_discovered_refs,
        "pruned_variable_discovered_refs": pruned_var_discovered_refs,
    }
    return cleaned, stats


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Trace cross-file lineage of an ASM variable through a call chain, "
            "combining find_variable_modifiers, cross_file_bridge, trace_lineage, "
            "and trace_cpp_function_lineage."
        )
    )
    parser.add_argument("variable", help="Variable name to trace (e.g. WK_RRC)")
    parser.add_argument("--blueprint-dir", metavar="DIR",
                        help="Directory containing .asm.json / .cpp.json files")
    parser.add_argument("--asm-dir", metavar="DIR",
                        help="Directory containing .asm source files")
    parser.add_argument("--graph", metavar="FILE",
                        help="Path to file_call_graph.json")
    parser.add_argument("--chain", metavar="N", type=int,
                        help="Chain index to select non-interactively (0-based)")
    parser.add_argument("--chain-files", metavar="FILES",
                        help="Comma-separated file stems defining the chain to trace "
                             "(e.g. da76,da78,xh80). Bypasses chain selection entirely.")
    parser.add_argument("--output", metavar="FILE",
                        help="Output JSON path (default: <variable>_cross_lineage.json)")
    parser.add_argument("--max-depth", metavar="N", type=int,
                        help="Max depth for C++ backward tree traversal")
    parser.add_argument("--max-subroutine-depth", metavar="N", type=int, default=2,
                        help="Backward-only mode: max nested subroutine expansion depth (default: 2).")
    parser.add_argument("--max-subroutine-nodes", metavar="N", type=int, default=400,
                        help="Backward-only mode: max relevant lines per subroutine expansion (default: 400).")
    parser.add_argument("--max-trace-nodes", metavar="N", type=int, default=5000,
                        help="Backward-only mode: max relevant lines per call-site trace (default: 5000).")
    parser.add_argument("--simple-traversal", action="store_true",
                        help="Enable unified queue-based traversal. Default is legacy traversal.")
    parser.add_argument("--backward-only", action="store_true",
                        help="Run isolated backward-only chain traversal via backward_traversal package.")
    parser.add_argument("--clean-output", action="store_true",
                        help="Simple mode: remove blueprint_not_found files and no-reference variables from output.")
    parser.add_argument("--var-depth", metavar="N", type=int, default=2,
                        help="Simple mode: max dependency variable depth (default: 2)")
    parser.add_argument("--file-depth", metavar="N", type=int, default=-1,
                        help="Simple mode: max file-queue depth (-1 means infinite)")
    parser.add_argument("--dep-depth", metavar="N", type=int,
                        help="Legacy mode: dep-var levels (default: 2). Simple mode: deprecated alias for --var-depth.")
    args = parser.parse_args()

    if args.backward_only:
        from backward_traversal.runner.backward_only_runner import run_backward_only_from_namespace

        return run_backward_only_from_namespace(args)

    variable: str = args.variable
    output_path = Path(args.output) if args.output else Path(f"{variable}_cross_lineage.json")
    warnings: List[str] = []
    use_simple_traversal: bool = bool(args.simple_traversal)

    if use_simple_traversal:
        if args.dep_depth is not None:
            msg = "WARNING: --dep-depth is deprecated in --simple-traversal mode; use --var-depth instead."
            print(msg, file=sys.stderr)
            warnings.append(msg)
        max_variable_depth = args.dep_depth if args.dep_depth is not None else args.var_depth
        max_file_depth = args.file_depth
        max_dep_depth = None
    else:
        max_dep_depth = args.dep_depth if args.dep_depth is not None else 2
        max_variable_depth = None
        max_file_depth = None
        if args.clean_output:
            msg = "WARNING: --clean-output is ignored in legacy mode (use --simple-traversal to enable it)."
            print(msg, file=sys.stderr)
            warnings.append(msg)
        if args.var_depth != 2:
            msg = "WARNING: --var-depth is ignored in legacy mode (use --simple-traversal to enable it)."
            print(msg, file=sys.stderr)
            warnings.append(msg)
        if args.file_depth != -1:
            msg = "WARNING: --file-depth is ignored in legacy mode (use --simple-traversal to enable it)."
            print(msg, file=sys.stderr)
            warnings.append(msg)

    # ── Resolve directories ──────────────────────────────────────────────────
    if args.blueprint_dir:
        blueprint_dir = Path(args.blueprint_dir)
        if not blueprint_dir.exists():
            print(f"ERROR: Blueprint dir not found: {blueprint_dir}", file=sys.stderr)
            return 1
    else:
        blueprint_dir = _discover_blueprint_dir()
        if blueprint_dir is None:
            print("ERROR: Could not discover blueprint directory. Pass --blueprint-dir.",
                  file=sys.stderr)
            return 1
    print(f"[blueprints]  {blueprint_dir}", file=sys.stderr)

    if args.asm_dir:
        asm_dir: Optional[Path] = Path(args.asm_dir)
    else:
        asm_dir = _discover_asm_dir(blueprint_dir)
    if asm_dir:
        print(f"[asm-source]  {asm_dir}", file=sys.stderr)

    # ── Load call graph ──────────────────────────────────────────────────────
    graph_file: Optional[Path] = Path(args.graph) if args.graph else _discover_graph_file(blueprint_dir)
    if graph_file is None or not graph_file.exists():
        print("ERROR: Cannot find file_call_graph.json. Pass --graph.", file=sys.stderr)
        return 1
    print(f"[call graph]  {graph_file}", file=sys.stderr)

    graph_payload: Dict[str, Any] = json.loads(graph_file.read_text(encoding="utf-8"))
    file_type_map: Dict[str, str] = {n["id"]: n.get("type", "asm")
                                      for n in graph_payload.get("nodes", [])}
    edge_type_map: Dict[Tuple[str, str], str] = {
        (e["source"], e["target"]): (e.get("instructions") or ["?"])[0]
        for e in graph_payload.get("edges", [])
    }

    # ── Find modifier files ──────────────────────────────────────────────────
    # .asm.json and .mac.json scanned; .cpp.json and .hpp.json excluded —
    # cpp/hpp blueprints carry no block-level SETTER flow data.
    blueprint_files = sorted(
        list(blueprint_dir.glob("*.asm.json")) +
        list(blueprint_dir.glob("*.mac.json"))
    )
    if not blueprint_files:
        print(f"ERROR: No .asm.json / .mac.json files found in {blueprint_dir}", file=sys.stderr)
        return 1

    n_asm = sum(1 for f in blueprint_files if f.name.endswith(".asm.json"))
    n_mac = sum(1 for f in blueprint_files if f.name.endswith(".mac.json"))
    print(f"\nScanning {len(blueprint_files)} blueprints ({n_asm} asm, {n_mac} mac) for '{variable}'...", file=sys.stderr)
    setter_hits: Dict[str, List[Dict[str, Any]]] = {}
    for bp_path in blueprint_files:
        hits, err = scan_blueprint_for_setters(bp_path, variable)
        if err:
            warnings.append(err)
        if hits:
            stem = hits[0]["file_stem"]
            setter_hits[stem] = hits

    # Reverse lookup: C++ struct fields (via cc*.hpp field_asm_aliases) that
    # alias this ASM variable. Independent of the setter scan — useful even
    # when no ASM setter exists (e.g., field is only written from C++).
    cpp_field_aliases = _find_cpp_field_aliases_for_asm(blueprint_dir, variable)
    if cpp_field_aliases:
        summary = ", ".join(sorted({m["cpp_field"] for m in cpp_field_aliases}))
        print(f"[cpp-alias]   {variable} ↔ {summary}", file=sys.stderr)

    if not setter_hits:
        print(f"ERROR: Variable '{variable}' not found as a SETTER target in any blueprint.",
              file=sys.stderr)
        return 1

    print(f"Found modifier file(s): {', '.join(sorted(setter_hits.keys()))}", file=sys.stderr)

    # ── Build and deduplicate chains per modifier ─────────────────────────────
    graph_node_ids: Set[str] = {n["id"] for n in graph_payload.get("nodes", [])}

    all_chains: List[Dict[str, Any]] = []
    for stem in sorted(setter_hits.keys()):
        if stem not in graph_node_ids:
            msg = f"Modifier '{stem}' not in call graph; skipping chain lookup."
            warnings.append(msg)
            print(f"  WARNING: {msg}", file=sys.stderr)
            continue
        raw_chains = find_chains_through(graph_payload, stem, args.max_depth)
        deduped = deduplicate_chains(raw_chains)
        for c in deduped:
            c["modifier_file"] = stem
        all_chains.extend(deduped)

    if not all_chains:
        print("ERROR: No call chains found for any modifier file.", file=sys.stderr)
        return 1

    # Truncate every chain to upstream + modifier (drop downstream files), then re-deduplicate
    for c in all_chains:
        idx = c["files"].index(c["modifier_file"])
        c["files"] = c["files"][: idx + 1]
        c["length"] = len(c["files"]) - 1
    all_chains = deduplicate_chains(all_chains)

    if not all_chains:
        print("ERROR: No chains remain after upstream truncation.", file=sys.stderr)
        return 1

    # ── Select chain ─────────────────────────────────────────────────────────
    if args.chain_files:
        # Direct chain specification — bypass the displayed list entirely.
        explicit_files = [f.strip() for f in args.chain_files.split(",") if f.strip()]
        if not explicit_files:
            print("ERROR: --chain-files is empty.", file=sys.stderr)
            return 1
        # Find the modifier file within the explicit list.
        explicit_modifiers = [f for f in explicit_files if f in setter_hits]
        if not explicit_modifiers:
            print(
                f"ERROR: None of the files in --chain-files ({', '.join(explicit_files)}) "
                f"is a known modifier of '{variable}'. "
                f"Known modifier(s): {', '.join(sorted(setter_hits.keys()))}",
                file=sys.stderr,
            )
            return 1
        explicit_modifier = explicit_modifiers[0]
        selected = {
            "files": explicit_files,
            "length": len(explicit_files) - 1,
            "modifier_file": explicit_modifier,
        }
        print(f"\nUsing explicit chain: {' -> '.join(explicit_files)}", file=sys.stderr)
    else:
        # Index-based selection from the internally generated list.
        print("\nAvailable chains (deduplicated — longest only):", file=sys.stderr)
        for idx, c in enumerate(all_chains):
            chain_str = " -> ".join(c["files"])
            print(f"  [{idx}] (modifier: {c['modifier_file']}, hops: {c['length']}) {chain_str}",
                  file=sys.stderr)

        if args.chain is not None:
            chosen_idx = args.chain
        else:
            print("\nEnter chain index: ", end="", file=sys.stderr)
            try:
                chosen_idx = int(input())
            except (ValueError, EOFError):
                print("ERROR: Invalid selection.", file=sys.stderr)
                return 1

        if not (0 <= chosen_idx < len(all_chains)):
            print(f"ERROR: Index {chosen_idx} out of range (0–{len(all_chains)-1}).",
                  file=sys.stderr)
            return 1

        selected = all_chains[chosen_idx]
    chain_files: List[str] = selected["files"]  # already truncated to upstream + modifier
    modifier_stem: str = selected["modifier_file"]
    modifier_idx: int = chain_files.index(modifier_stem)
    print(f"\nSelected chain (upstream only): {' -> '.join(chain_files)}", file=sys.stderr)
    print(f"Modifier: {modifier_stem} (position {modifier_idx})", file=sys.stderr)

    # ── Prepare shared tools ──────────────────────────────────────────────────
    tracer = LineageTracer(
        asm_dir=asm_dir or blueprint_dir,
        blueprint_dir=blueprint_dir,
    )
    fwd_tracer = ForwardLineageTracer(
        asm_dir=asm_dir or blueprint_dir,
        blueprint_dir=blueprint_dir,
    )

    # Build C++ indexes once (reused across all C++ hops)
    print("\nBuilding C++ function indexes...", file=sys.stderr)
    cpp_blueprints = discover_cpp_blueprints(blueprint_dir)
    function_defs, functions_by_file, all_cpp_edges, _ = build_indexes(cpp_blueprints)
    owner_index = build_owner_index(function_defs)
    known_asm_stems = discover_asm_stems(blueprint_dir)

    files: Dict[str, Any] = {}
    sections: Dict[str, Any] = {}

    # ── Steps 6 & 7: Trace upstream callers ──────────────────────────────────
    upstream_pairs: List[Tuple[str, str]] = [
        (chain_files[i], chain_files[i + 1])
        for i in range(modifier_idx - 1, -1, -1)
    ]

    # Pre-compute entry function for each C++ file in the chain.
    # The entry function is the function in that file called by the file above
    # it in the chain — used to bound the backward BFS in _build_cpp_call_graph.
    callee_entry_map: Dict[str, str] = {}
    for _caller, _callee in upstream_pairs:
        _c_type = file_type_map.get(_caller, "asm")
        _e_type = file_type_map.get(_callee, "asm")
        if _c_type == "cpp" and _e_type == "cpp":
            _pre = find_cpp_to_cpp_callers(_caller, _callee, blueprint_dir)
            if _pre:
                callee_entry_map[_callee] = _pre[0].get("callee_function") or ""
        elif _c_type == "asm" and _e_type == "cpp":
            _pre = find_asm_to_cpp_callers(_caller, _callee, blueprint_dir, asm_dir)
            if _pre:
                callee_entry_map[_callee] = _pre[0].get("cpp_function") or ""

    for caller, callee in upstream_pairs:
        edge_instr = edge_type_map.get((caller, callee), "?")
        caller_type = file_type_map.get(caller, "asm")
        callee_type = file_type_map.get(callee, "asm")
        edge_class = _classify_edge(caller, callee, file_type_map)

        print(f"\n--- Tracing upstream: {caller} -{edge_instr}-> {callee} ({edge_class}) ---",
              file=sys.stderr)

        if caller_type == "cpp":
            upstream_payload = _trace_cpp_upstream(
                caller=caller,
                callee=callee,
                callee_type=callee_type,
                blueprint_dir=blueprint_dir,
                asm_dir=asm_dir,
                edge_instruction=edge_instr,
                functions_by_file=functions_by_file,
                owner_index=owner_index,
                known_asm_stems=known_asm_stems,
                all_edges=all_cpp_edges,
                max_depth=args.max_depth,
                warnings=warnings,
                entry_function=callee_entry_map.get(caller),
            )
        elif caller_type == "asm":
            upstream_payload = _trace_asm_upstream(
                caller=caller,
                callee=callee,
                callee_type=callee_type,
                blueprint_dir=blueprint_dir,
                asm_dir=asm_dir,
                edge_instruction=edge_instr,
                tracer=tracer,
                warnings=warnings,
            )
        else:
            msg = f"Unknown caller type for '{caller}': {caller_type}"
            warnings.append(msg)
            upstream_payload = {"role": "upstream", "warnings": [msg]}

        if use_simple_traversal:
            rec = files.setdefault(caller, {})
            rec.setdefault("file_type", caller_type)
            rec["upstream"] = upstream_payload
        else:
            sections[caller] = upstream_payload

    # ── Mode-specific modifier + downstream traversal ────────────────────────
    if use_simple_traversal:
        traversal_meta = _run_simple_modifier_downstream(
            variable=variable,
            modifier_stem=modifier_stem,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            tracer=tracer,
            fwd_tracer=fwd_tracer,
            graph_payload=graph_payload,
            file_type_map=file_type_map,
            warnings=warnings,
            max_variable_depth=max_variable_depth if max_variable_depth is not None else 2,
            max_file_depth=max_file_depth if max_file_depth is not None else -1,
            files=files,
        )
        _synchronize_variable_depths_with_pool(
            files,
            traversal_meta.get("variable_pool_depth", {}),
        )
        files_for_output = files
        cleanup_summary: Optional[Dict[str, int]] = None
        if args.clean_output:
            files_for_output, cleanup_summary = _clean_simple_output_files(files)

        output: Dict[str, Any] = {
            "traversal_mode": "simple",
            "root_variable": variable,
            "selected_chain": chain_files,
            "modifier_file": modifier_stem,
            "cpp_field_aliases": cpp_field_aliases,
            "limits": {
                "max_variable_depth": max_variable_depth,
                "max_file_depth": None if (max_file_depth is not None and max_file_depth < 0) else max_file_depth,
            },
            "traversal": traversal_meta,
            "files": files_for_output,
        }
        if cleanup_summary is not None:
            output["cleanup"] = cleanup_summary
    else:
        dep_var_lineage = _run_legacy_modifier_downstream(
            variable=variable,
            modifier_stem=modifier_stem,
            chain_files=chain_files,
            sections=sections,
            warnings=warnings,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            tracer=tracer,
            fwd_tracer=fwd_tracer,
            max_dep_depth=max_dep_depth if max_dep_depth is not None else 2,
        )
        output = {
            "traversal_mode": "legacy",
            "variable": variable,
            "selected_chain": chain_files,
            "modifier_file": modifier_stem,
            "cpp_field_aliases": cpp_field_aliases,
            "sections": sections,
        }
        if dep_var_lineage:
            output["dep_var_lineage"] = dep_var_lineage

    if warnings:
        output["warnings"] = sorted(set(str(w) for w in warnings))
    output_path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(f"\nWrote results to: {output_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
