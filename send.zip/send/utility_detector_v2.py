#!/usr/bin/env python3
"""
utility_detector_v2.py — Hybrid Utility Detection (pipeline-integrated)

Implements the design in HYBRID_UTILITY_DETECTION.md:

  Layer 0  PIPELINE INGESTION   — read blueprints + call graph + var modifiers → SQLite
  Layer 1  HARD CLASSIFICATION  — deterministic rules (C1–C4, U1–U5, U1_ASM) ~90% of files
  Layer 2  HYBRID CLASSIFICATION— LLM resolves the ambiguous 5–15%
  Layer 3  CLUSTER BUILDER      — BFS + variable co-modification + semantic match
  Layer 4  FILE CLUSTER API     — CLI query interface

Key differences from utility_detector.py (old approach):
  • Uses pipeline blueprint files (msgpack-encoded) instead of raw source scanning
  • Hard rules derived from blueprint facts, not heuristics
  • Three-pass cluster builder (structural + data-coupled + semantic)
  • Streaming JSON via ijson for large files (file_call_graph.json can be 100+ MB)

Usage:
    # One-time index build (run after /pipeline completes)
    python3 utility_detector_v2.py ingest \\
        --pipeline-output output/ --src temp/asm \\
        --db utility_index_v2.db

    # Classify all files (hard rules + scoring)
    python3 utility_detector_v2.py classify-hard --db utility_index_v2.db

    # Build FTS5 index for semantic cluster search (Pass C)
    python3 utility_detector_v2.py build-embeddings --db utility_index_v2.db

    # (Optional) LLM for ambiguous files
    python3 utility_detector_v2.py classify-llm --db utility_index_v2.db

    # Query
    python3 utility_detector_v2.py analyze --db utility_index_v2.db
    python3 utility_detector_v2.py cluster --entry da78 --db utility_index_v2.db
    python3 utility_detector_v2.py explain --stem da7gl --db utility_index_v2.db
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sqlite3
import sys
import textwrap
from pathlib import Path
from typing import Any, Iterator

try:
    import msgpack
except ImportError:
    sys.exit("msgpack required: pip install msgpack")

try:
    import ijson
    _HAVE_IJSON = True
except ImportError:
    _HAVE_IJSON = False

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_CROSS_FILE_CALL_TYPES = frozenset({
    "subroutine_call", "no_return_call", "async_spawn", "isc_route", "call_alias",
})

_BUSINESS_OPCODES = frozenset({
    "ENTRC", "ENTNC", "ENTDC", "CREEC", "CREMC", "SWISC",
    "MVC", "MVI", "MVN", "MVO", "MVZ", "MVCL",
    "AP", "SP", "MP", "DP", "ZAP", "CP", "CVB", "CVD",
    "L", "ST", "LA", "LR", "STM", "LM",
    "BCT", "BC", "BAS", "BASR", "BALR", "BAL",
    "CLC", "CLI", "CLR", "C", "CH",
    "TM", "OC", "XC", "NC", "OI", "XI", "NI",
    "PACK", "UNPK", "ED", "EDMK",
})

_WRITE_RELATIONS = frozenset({"store", "assign", "define"})

_BEGIN_NAME_RE = re.compile(r"\bBEGIN\s+NAME\s*=", re.IGNORECASE)

_EXT_TO_LANG: dict[str, str] = {
    ".asm": "asm", ".hsm": "asm",
    ".mac": "mac", ".copy": "mac", ".cpy": "mac",
    ".cpp": "cpp", ".hpp": "cpp", ".h": "cpp",
}
_LANG_TO_EXT: dict[str, str] = {
    "asm": ".asm", "hsm": ".hsm", "mac": ".mac", "cpp": ".cpp",
}

# ---------------------------------------------------------------------------
# SQLite schema  (Section 8 of HYBRID_UTILITY_DETECTION.md)
# ---------------------------------------------------------------------------

_DDL = """
-- Core file registry
CREATE TABLE IF NOT EXISTS files (
    stem                TEXT PRIMARY KEY,
    path                TEXT,
    ext                 TEXT,
    language            TEXT,
    loc                 INTEGER DEFAULT 0,
    non_blank_lines     INTEGER DEFAULT 1,

    -- Blueprint signals
    has_begin_name      INTEGER DEFAULT 0,
    entry_point_count   INTEGER DEFAULT 0,
    has_extern_c        INTEGER DEFAULT 0,
    dsect_field_count   INTEGER DEFAULT 0,
    ds_equ_line_count   INTEGER DEFAULT 0,
    instruction_count   INTEGER DEFAULT 0,
    macro_def_count     INTEGER DEFAULT 0,
    unique_vars_written INTEGER DEFAULT 0,
    call_out_count      INTEGER DEFAULT 0,
    is_leaf             INTEGER DEFAULT 1,
    purpose_hint        TEXT    DEFAULT '',

    -- Graph signals (populated after edge import)
    in_degree           INTEGER DEFAULT 0,
    in_degree_from_cpp  INTEGER DEFAULT 0,
    out_degree          INTEGER DEFAULT 0,
    fan_in_score        REAL    DEFAULT 0.0,

    -- Scoring signals (-1.0 = not yet computed)
    ext_score           REAL    DEFAULT -1.0,
    content_score       REAL    DEFAULT -1.0,
    entry_score         REAL    DEFAULT -1.0,
    name_score          REAL    DEFAULT -1.0,

    -- Classification results
    hard_rule           TEXT,
    utility_score       REAL    DEFAULT -1.0,
    role                TEXT,
    fused_score         REAL    DEFAULT -1.0,
    score_source        TEXT    DEFAULT 'pending',
    indexed_at          TEXT,
    classified_at       TEXT
);

-- File-to-file call graph
CREATE TABLE IF NOT EXISTS edges (
    src_stem    TEXT NOT NULL,
    dst_stem    TEXT NOT NULL,
    edge_type   TEXT,
    PRIMARY KEY (src_stem, dst_stem, edge_type)
);
CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(src_stem);
CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(dst_stem);

-- Variable co-modification map
CREATE TABLE IF NOT EXISTS var_modifiers (
    stem        TEXT NOT NULL,
    var_name    TEXT NOT NULL,
    PRIMARY KEY (stem, var_name)
);
CREATE INDEX IF NOT EXISTS idx_vm_var  ON var_modifiers(var_name);
CREATE INDEX IF NOT EXISTS idx_vm_stem ON var_modifiers(stem);

-- LLM classification decisions
CREATE TABLE IF NOT EXISTS llm_decisions (
    stem                TEXT NOT NULL,
    content_hash        TEXT NOT NULL,
    label               TEXT NOT NULL,
    confidence          REAL NOT NULL,
    reason              TEXT,
    fused_score         REAL NOT NULL,
    score_source        TEXT NOT NULL,
    mode                TEXT NOT NULL DEFAULT 'global',
    functionality_id    TEXT NOT NULL DEFAULT '',
    model_id            TEXT,
    classified_at       TEXT,
    PRIMARY KEY (stem, mode, functionality_id)
);

-- Cluster cache
CREATE TABLE IF NOT EXISTS cluster_cache (
    entry_stems         TEXT NOT NULL,
    functionality_hash  TEXT NOT NULL,
    include_flags       TEXT NOT NULL,
    max_depth           INTEGER NOT NULL DEFAULT 10,
    ingest_generation   INTEGER NOT NULL,
    result_json         TEXT NOT NULL,
    cached_at           TEXT,
    PRIMARY KEY (entry_stems, functionality_hash, include_flags, max_depth)
);

-- Ingest metadata
CREATE TABLE IF NOT EXISTS ingest_meta (
    key     TEXT PRIMARY KEY,
    value   TEXT
);

-- Human overrides
CREATE TABLE IF NOT EXISTS human_overrides (
    stem        TEXT PRIMARY KEY,
    label       TEXT NOT NULL,
    reason      TEXT,
    set_by      TEXT,
    set_at      TEXT
);

-- Review queue
CREATE TABLE IF NOT EXISTS review_queue (
    stem            TEXT NOT NULL,
    reason          TEXT NOT NULL,
    det_score       REAL,
    llm_label       TEXT,
    llm_confidence  REAL,
    queued_at       TEXT,
    resolved        INTEGER DEFAULT 0
);

-- High-frequency variable exclusion list
CREATE TABLE IF NOT EXISTS excluded_vars (
    var_name     TEXT PRIMARY KEY,
    writer_count INTEGER NOT NULL,
    excluded_at  TEXT
);

-- FTS5 for Pass C semantic search
CREATE VIRTUAL TABLE IF NOT EXISTS file_hints
    USING fts5(stem UNINDEXED, hint_text);
"""

# ---------------------------------------------------------------------------
# Blueprint helpers  (Section 3.2)
# ---------------------------------------------------------------------------

def _ext_to_language(ext: str) -> str:
    return _EXT_TO_LANG.get(ext.lower(), "asm")


def _lang_to_ext(lang: str) -> str:
    return _LANG_TO_EXT.get(lang.lower(), ".asm")


def _load_blueprint(path: Path) -> dict:
    """Load a pipeline blueprint file (msgpack-encoded despite .json extension)."""
    raw = path.read_bytes()
    return msgpack.unpackb(raw, raw=False)


def _line_counts(bp: dict) -> tuple[int, float]:
    """Return (non_blank_lines, comment_ratio) from coverage_review.line_audit.

    non_blank = total_lines - blank_line  (floored at 1 to prevent div/0).
    Actual blueprint: excluded_breakdown has blank_line, comment_line,
    directive_or_declaration.  We exclude only blank_line from non_blank.
    """
    audit   = bp.get("coverage_review", {}).get("line_audit", {})
    total   = audit.get("total_lines", 1)
    eb      = audit.get("excluded_breakdown", {})
    blank   = eb.get("blank_line", 0)
    comment = eb.get("comment_line", 0)
    non_blank = max(1, total - blank)
    return non_blank, comment / non_blank


def _compute_instruction_lines(bp: dict) -> int:
    """Count business-logic opcode occurrences across all blocks.

    blocks is a LIST; each block's flow["i"] is a list of mnemonic strings.
    Only opcodes in _BUSINESS_OPCODES count (excludes branches, returns, etc.)
    """
    count = 0
    for block in bp.get("blocks", []):
        for mnemonic in block.get("flow", {}).get("i", []):
            if str(mnemonic).upper() in _BUSINESS_OPCODES:
                count += 1
    return count


def _compute_ds_equ_lines(bp: dict) -> int:
    """Count DS/EQU/DC data-definition symbols from symbols.global_symbols.

    Symbol type values observed in actual blueprints: 'ds', 'equ', 'dc',
    'dsect', 'csect', 'extrn', 'entry'.
    We count: ds, equ, dc (explicit data definitions).
    DSECT fields are captured separately by _compute_dsect_field_count.
    """
    return sum(
        1 for sym in bp.get("symbols", {}).get("global_symbols", {}).values()
        if sym.get("type") in ("ds", "equ", "dc")
    )


def _compute_dsect_field_count(bp: dict) -> int:
    """Count total DSECT field entries across all dsect_layouts.

    dsect_layouts: {layout_name: {field_name: {"offset": int, "length": int}}}
    No line_count field exists — field count is the proxy for DSECT complexity.
    Empty ({}) for .asm/.cpp files.
    """
    return sum(len(fields) for fields in bp.get("dsect_layouts", {}).values())


def _compute_macro_def_lines(bp: dict) -> int:
    """Count MACRO/MEND boundary symbols from symbols.global_symbols."""
    return sum(
        1 for sym in bp.get("symbols", {}).get("global_symbols", {}).values()
        if sym.get("type") in ("macro", "mend")
    )


def _has_begin_name(bp: dict, source_path: str | None = None) -> bool:
    """True if this file declares BEGIN NAME= (standalone HLASM program).

    Detection order (cheapest first):
    1. coverage_review.errors — pipeline parser notes BEGIN NAME= in error messages
       when it can't map it to call_graph.edges.  Reliable for .asm/.hsm.
    2. asm_entry_point_map type field — works for .cpp blueprints.
    3. Raw source scan — fallback when source_path is provided.

    IMPORTANT: asm_entry_point_map is always {} for .asm/.hsm blueprints in
    the current pipeline version.  Raw scan or error-message heuristic is
    the only way to detect BEGIN NAME= for these file types.
    """
    # Primary: pipeline coverage errors contain the source line text
    for err in bp.get("coverage_review", {}).get("errors", []):
        if "BEGIN NAME=" in str(err).upper():
            return True

    # Secondary: asm_entry_point_map (populated for .cpp only)
    for ep in bp.get("asm_entry_point_map", {}).values():
        if isinstance(ep, dict) and ep.get("type") in ("start", "begin", "entry"):
            return True

    # Tertiary: raw source scan
    if source_path:
        try:
            with open(source_path, encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    if _BEGIN_NAME_RE.search(line):
                        return True
        except OSError:
            pass

    return False


def _entry_point_count(bp: dict) -> int:
    """Count declared entry points (from asm_entry_point_map).

    For .cpp: populated with #pragma map / #pragma export entries.
    For .asm/.hsm: always {} in current pipeline — returns 0.
    NOTE: ENTRC is an *outgoing* call opcode, NOT an entry declaration.
    """
    return len(bp.get("asm_entry_point_map", {}))


def _variable_writes(bp: dict) -> list[str]:
    """Return list of memory variable names written by this file.

    Filters variable_lineage.edges by relation in _WRITE_RELATIONS where
    target is 'memory:varname'.
    """
    written: set[str] = set()
    for edge in bp.get("variable_lineage", {}).get("edges", []):
        if edge.get("relation") in _WRITE_RELATIONS:
            target = str(edge.get("target", ""))
            if ":" in target:
                kind, name = target.split(":", 1)
                if kind == "memory":
                    written.add(name)
    return list(written)


def _compute_purpose_hint(bp: dict, source_path: str | None = None,
                           ext: str = ".asm") -> str:
    """Build a purpose_hint string for Pass C semantic search.

    Requires raw source scan — blueprints do not persist raw comment text.
    Returns "" if source_path is None or unreadable (safe: no Pass C hits).

    - .asm/.hsm: first 5 '* ' comment lines + CSECT label + TITLE text
    - .mac/.copy/.cpy: macro name + first 5 comment lines
    - .cpp/.hpp/.h: first block comment (/** ... */ or /* ... */)
    """
    if not source_path:
        return ""
    ext_lower = ext.lower()
    try:
        with open(source_path, encoding="utf-8", errors="replace") as fh:
            lines = [ln.rstrip() for ln in fh]
    except OSError:
        return ""

    if ext_lower in (".asm", ".hsm"):
        comment_words: list[str] = []
        csect_label = ""
        title_text = ""
        for ln in lines[:60]:
            s = ln.strip()
            if s.startswith("*"):
                comment_words.append(s.lstrip("* ").strip())
                if len(comment_words) >= 5:
                    break
            elif "CSECT" in s.upper() and not csect_label:
                parts = s.split()
                if parts:
                    csect_label = parts[0]
            elif s.upper().lstrip().startswith("TITLE"):
                title_text = s.strip()[5:].strip().strip("'")
        tokens = [t for t in [" ".join(comment_words), csect_label, title_text] if t]
        return " ".join(tokens).upper()[:256]

    elif ext_lower in (".mac", ".copy", ".cpy"):
        macro_name = next(
            (name for name, sym in bp.get("symbols", {})
                                     .get("global_symbols", {}).items()
             if sym.get("type") == "macro"),
            "",
        )
        comment_words = []
        for ln in lines[:30]:
            s = ln.strip()
            if s.startswith("*"):
                comment_words.append(s.lstrip("* ").strip())
                if len(comment_words) >= 5:
                    break
        tokens = [t for t in [macro_name, " ".join(comment_words)] if t]
        return " ".join(tokens).upper()[:256]

    elif ext_lower in (".cpp", ".hpp", ".h"):
        in_block = False
        comment_lines: list[str] = []
        for ln in lines[:80]:
            s = ln.strip()
            if not in_block and (s.startswith("/**") or s.startswith("/*")):
                in_block = True
                comment_lines.append(s.lstrip("/*").strip())
            elif in_block:
                if "*/" in s:
                    comment_lines.append(s.replace("*/", "").lstrip("* ").strip())
                    break
                comment_lines.append(s.lstrip("* ").strip())
        return " ".join(w for ln in comment_lines for w in ln.split())[:256]

    return ""


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

def _connect(db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect(db_path)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("PRAGMA cache_size=-64000")   # 64 MB cache
    con.row_factory = sqlite3.Row
    return con


def _init_schema(con: sqlite3.Connection) -> None:
    con.executescript(_DDL)
    con.execute(
        "INSERT OR IGNORE INTO ingest_meta VALUES ('generation','0')"
    )
    con.execute(
        "INSERT OR IGNORE INTO ingest_meta VALUES ('total_files','0')"
    )
    con.commit()


def _blueprint_dir(pipeline_output: str) -> Path:
    """Locate the directory that holds blueprint .json files.

    Pipeline writes to <pipeline_output>/asm/asm/*.json.
    """
    base = Path(pipeline_output)
    deep = base / "asm" / "asm"
    if deep.exists():
        return deep
    if (base / "asm").exists():
        return base / "asm"
    return base


# ---------------------------------------------------------------------------
# Layer 0 — Blueprint ingestion  (Section 3.2)
# ---------------------------------------------------------------------------

def _ingest_blueprints(con: sqlite3.Connection, bp_dir: Path,
                        src_dir: str | None, verbose: bool) -> int:
    """Read every blueprint file and upsert one row per file into `files`.

    Returns number of files processed.
    """
    processed = 0
    ts = _now()

    for bp_path in sorted(bp_dir.glob("*.json")):
        # Skip non-blueprint files
        if "msgpack" in bp_path.name or "function_index" in bp_path.name:
            continue

        # Derive stem and ext from filename: "da78.asm.json" → stem="da78", ext=".asm"
        name = bp_path.name          # e.g. "da78.asm.json"
        if not name.endswith(".json"):
            continue
        src_name = name[:-5]         # strip .json  → "da78.asm"
        src_path_obj = Path(src_name)
        stem = src_path_obj.stem     # "da78"
        ext  = src_path_obj.suffix.lower()   # ".asm"

        if ext not in _EXT_TO_LANG:
            continue

        # Locate raw source for has_begin_name / purpose_hint
        source_path: str | None = None
        if src_dir:
            candidate = Path(src_dir) / src_name
            if candidate.exists():
                source_path = str(candidate)

        try:
            bp = _load_blueprint(bp_path)
        except Exception as exc:
            if verbose:
                print(f"  WARN: failed to load {bp_path.name}: {exc}")
            continue

        non_blank, _ = _line_counts(bp)
        loc = bp.get("coverage_review", {}).get("line_audit", {}).get("total_lines", 0)
        instr  = _compute_instruction_lines(bp)
        ds_equ = _compute_ds_equ_lines(bp)
        dsect  = _compute_dsect_field_count(bp)
        macro  = _compute_macro_def_lines(bp)
        has_bn = int(_has_begin_name(bp, source_path))
        ep_cnt = _entry_point_count(bp)
        var_wr = len(_variable_writes(bp))
        hint   = _compute_purpose_hint(bp, source_path, ext)
        lang   = _ext_to_language(ext)

        # has_extern_c: UNVERIFIED FIELD — see HYBRID_UTILITY_DETECTION.md §3.2
        # If "extern_c_bridges" is absent in .cpp blueprints, defaults to 0 (safe).
        has_ec = int(len(bp.get("extern_c_bridges", [])) > 0)

        path_val = str(bp_path)

        con.execute("""
            INSERT OR REPLACE INTO files (
                stem, path, ext, language, loc, non_blank_lines,
                has_begin_name, entry_point_count, has_extern_c,
                dsect_field_count, ds_equ_line_count, instruction_count,
                macro_def_count, unique_vars_written,
                call_out_count, is_leaf,
                purpose_hint, indexed_at
            ) VALUES (?,?,?,?,?,?, ?,?,?, ?,?,?,?,?, ?,?, ?,?)
        """, (
            stem, path_val, ext, lang, loc, non_blank,
            has_bn, ep_cnt, has_ec,
            dsect, ds_equ, instr,
            macro, var_wr,
            0, 1,       # call_out_count / is_leaf updated later from file_call_graph
            hint, ts,
        ))
        processed += 1
        if verbose:
            print(f"  {stem}{ext}  loc={loc}  instr={instr}  ds_equ={ds_equ}"
                  f"  has_begin_name={has_bn}")

    con.commit()
    return processed


# ---------------------------------------------------------------------------
# Layer 0 — Call graph ingestion  (Section 3.3)
# ---------------------------------------------------------------------------

def _ingest_call_graph(con: sqlite3.Connection, fcg_path: Path,
                        verbose: bool) -> tuple[int, int]:
    """Import file_call_graph.json → edges table.

    Returns (nodes_upserted, edges_inserted).
    Streams with ijson if available; falls back to json.load().
    """
    node_count = 0
    edge_count = 0

    if verbose:
        print(f"  Loading {fcg_path} ...")

    # Load the full graph (streaming or full load)
    if _HAVE_IJSON and fcg_path.stat().st_size > 50_000_000:
        # Large file: stream with ijson
        nodes = []
        edges = []
        with open(fcg_path, "rb") as fh:
            for item in ijson.items(fh, "nodes.item"):
                nodes.append(item)
            fh.seek(0)
            for item in ijson.items(fh, "edges.item"):
                edges.append(item)
    else:
        with open(fcg_path, encoding="utf-8") as fh:
            fcg = json.load(fh)
        nodes = fcg.get("nodes", [])
        edges = fcg.get("edges", [])

    # Upsert nodes (these may be files not in blueprints, e.g. external modules)
    for node in nodes:
        stem = node.get("id", "")
        lang = node.get("type", "asm")
        ext  = _lang_to_ext(lang)
        file_val = node.get("file", "")
        con.execute("""
            INSERT OR IGNORE INTO files (stem, path, ext, language)
            VALUES (?,?,?,?)
        """, (stem, file_val, ext, lang))
        node_count += 1

    # Insert edges (src_stem, dst_stem, edge_type)
    con.execute("DELETE FROM edges")
    for edge in edges:
        src  = edge.get("source", "")
        dst  = edge.get("target", "")
        # edge_type: from first call_site; default "unknown"
        call_sites = edge.get("call_sites", [])
        etype = call_sites[0].get("call_type", "unknown") if call_sites else "unknown"
        if src and dst:
            con.execute("""
                INSERT OR IGNORE INTO edges (src_stem, dst_stem, edge_type)
                VALUES (?,?,?)
            """, (src, dst, etype))
            edge_count += 1

    con.commit()

    # Recompute graph metrics
    if verbose:
        print("  Recomputing in_degree / out_degree / fan_in_score ...")
    _recompute_graph_metrics(con)

    return node_count, edge_count


def _recompute_graph_metrics(con: sqlite3.Connection) -> None:
    """Recompute in_degree, in_degree_from_cpp, out_degree, call_out_count,
    is_leaf, and fan_in_score for all files.  Run after any edge table change.
    """
    con.execute("""
        UPDATE files SET in_degree = (
            SELECT COUNT(*) FROM edges WHERE dst_stem = files.stem
        )
    """)
    con.execute("""
        UPDATE files SET in_degree_from_cpp = (
            SELECT COUNT(*) FROM edges e
            JOIN files f2 ON f2.stem = e.src_stem
            WHERE e.dst_stem = files.stem AND f2.ext = '.cpp'
        )
    """)
    con.execute("""
        UPDATE files SET out_degree = (
            SELECT COUNT(*) FROM edges WHERE src_stem = files.stem
        )
    """)
    # Update call_out_count and is_leaf from the authoritative edge table
    con.execute("""
        UPDATE files SET
            call_out_count = (SELECT COUNT(*) FROM edges WHERE src_stem = files.stem),
            is_leaf        = CASE
                                WHEN (SELECT COUNT(*) FROM edges WHERE src_stem = files.stem) = 0
                                THEN 1 ELSE 0
                             END
    """)
    # fan_in_score via PERCENT_RANK (requires SQLite 3.25+)
    # Use temp table to avoid CTEs-in-UPDATE (requires SQLite 3.35+)
    con.execute("""
        CREATE TEMP TABLE IF NOT EXISTS _fan_in_ranks AS
            SELECT stem, PERCENT_RANK() OVER (ORDER BY in_degree) AS pct_rank
            FROM files
    """)
    # Re-populate if it already existed
    con.execute("DELETE FROM _fan_in_ranks")
    con.execute("""
        INSERT INTO _fan_in_ranks
            SELECT stem, PERCENT_RANK() OVER (ORDER BY in_degree) AS pct_rank
            FROM files
    """)
    con.execute("""
        UPDATE files SET fan_in_score = (
            SELECT r.pct_rank *
                   CASE WHEN files.entry_point_count = 0 THEN 0.6 ELSE 0.1 END
            FROM _fan_in_ranks r WHERE r.stem = files.stem
        )
    """)
    con.execute("DROP TABLE IF EXISTS _fan_in_ranks")
    con.commit()


# ---------------------------------------------------------------------------
# Layer 0 — Variable modifier ingestion  (Section 3.4)
# ---------------------------------------------------------------------------

def _ingest_var_modifiers(con: sqlite3.Connection, vmi_path: Path,
                           verbose: bool) -> int:
    """Import variable_modifier_index.json → var_modifiers table.

    IMPORTANT: data lives under modifier_index["index"], NOT at root.
    Returns number of (stem, var_name) rows inserted.
    """
    with open(vmi_path, encoding="utf-8") as fh:
        vmi = json.load(fh)

    index = vmi.get("index", {})
    con.execute("DELETE FROM var_modifiers")
    rows: list[tuple[str, str]] = []
    for var_name, stems in index.items():
        for stem in stems:
            rows.append((stem, var_name))
        if len(rows) >= 10_000:
            con.executemany(
                "INSERT OR IGNORE INTO var_modifiers (stem, var_name) VALUES (?,?)",
                rows,
            )
            rows.clear()
    if rows:
        con.executemany(
            "INSERT OR IGNORE INTO var_modifiers (stem, var_name) VALUES (?,?)",
            rows,
        )
    con.commit()

    total = sum(len(v) for v in index.values())
    if verbose:
        print(f"  Imported {len(index)} variables × stems = {total} rows")
    return total


def _rebuild_excluded_vars(con: sqlite3.Connection, verbose: bool) -> int:
    """Rebuild excluded_vars from var_modifiers using the 2% threshold.

    Must run AFTER total_files is updated in ingest_meta.
    Variables written by > 2% of files are excluded from Pass B (noise).
    """
    # Update total_files FIRST (threshold depends on current count)
    con.execute("""
        UPDATE ingest_meta
        SET value = (SELECT COUNT(*) FROM files)
        WHERE key = 'total_files'
    """)
    con.commit()

    con.execute("DELETE FROM excluded_vars")
    con.execute("""
        INSERT INTO excluded_vars (var_name, writer_count, excluded_at)
        SELECT var_name,
               COUNT(DISTINCT stem) AS writer_count,
               datetime('now')
        FROM var_modifiers
        GROUP BY var_name
        HAVING COUNT(DISTINCT stem) > (
            SELECT MAX(10, CAST(value AS REAL) * 0.02)
            FROM ingest_meta WHERE key = 'total_files'
        )
    """)
    con.commit()

    cnt = con.execute("SELECT COUNT(*) FROM excluded_vars").fetchone()[0]
    if verbose:
        print(f"  Excluded {cnt} high-frequency variables from Pass B")
    return cnt


# ---------------------------------------------------------------------------
# Layer 1 — Hard classification  (Section 4.2, 4.3)
# ---------------------------------------------------------------------------

# Hard rule SQL — fills the gap in the spec (Section 4.4, step 1 & 2)
# CRITICAL rules are applied first; UTILITY rules second.
# Each UPDATE sets hard_rule + role + score_source + classified_at for matching files.

_HARD_CRITICAL_SQL: list[tuple[str, str]] = [
    # C1 — Standalone business program (BEGIN NAME=)
    ("C1", """
        UPDATE files SET
            hard_rule     = 'C1',
            role          = 'HARD_CRITICAL',
            score_source  = 'hard_rule',
            classified_at = datetime('now')
        WHERE hard_rule IS NULL
          AND has_begin_name = 1
    """),
    # C2 — C++ bridge program (entry-dense, not called by other CPP files)
    ("C2", """
        UPDATE files SET
            hard_rule     = 'C2',
            role          = 'HARD_CRITICAL',
            score_source  = 'hard_rule',
            classified_at = datetime('now')
        WHERE hard_rule IS NULL
          AND ext = '.cpp'
          AND entry_point_count >= 3
          AND in_degree_from_cpp = 0
    """),
    # C3 — Instruction-dense ASM/HSM subroutine, single caller
    ("C3", """
        UPDATE files SET
            hard_rule     = 'C3',
            role          = 'HARD_CRITICAL',
            score_source  = 'hard_rule',
            classified_at = datetime('now')
        WHERE hard_rule IS NULL
          AND ext IN ('.asm', '.hsm')
          AND CAST(instruction_count AS REAL) / MAX(1, non_blank_lines) > 0.50
          AND has_begin_name = 0
          AND in_degree = 1
          AND entry_point_count = 0
    """),
    # C4 — Instruction-dense non-leaf subroutine, single caller
    ("C4", """
        UPDATE files SET
            hard_rule     = 'C4',
            role          = 'HARD_CRITICAL',
            score_source  = 'hard_rule',
            classified_at = datetime('now')
        WHERE hard_rule IS NULL
          AND ext IN ('.asm', '.hsm', '.cpp')
          AND in_degree = 1
          AND is_leaf = 0
          AND CAST(instruction_count AS REAL) / MAX(1, non_blank_lines) > 0.40
          AND has_begin_name = 0
          AND entry_point_count = 0
    """),
]

_HARD_UTILITY_SQL: list[tuple[str, str]] = [
    # U1 — Pure DSECT / data layout (.mac, .hsm, .h, .copy, .cpy)
    ("U1", """
        UPDATE files SET
            hard_rule     = 'U1',
            role          = 'HARD_UTILITY',
            score_source  = 'hard_rule',
            classified_at = datetime('now')
        WHERE hard_rule IS NULL
          AND ext IN ('.mac', '.hsm', '.h', '.copy', '.cpy')
          AND CAST(ds_equ_line_count AS REAL) / MAX(1, non_blank_lines) > 0.80
          AND instruction_count = 0
          AND entry_point_count = 0
    """),
    # U2 — C++ / C data-structure header (no extern "C" bridge, no instructions)
    ("U2", """
        UPDATE files SET
            hard_rule     = 'U2',
            role          = 'HARD_UTILITY',
            score_source  = 'hard_rule',
            classified_at = datetime('now')
        WHERE hard_rule IS NULL
          AND ext IN ('.hpp', '.h')
          AND has_extern_c = 0
          AND instruction_count = 0
    """),
    # U4 — Zero-logic macro / HSM template file
    ("U4", """
        UPDATE files SET
            hard_rule     = 'U4',
            role          = 'HARD_UTILITY',
            score_source  = 'hard_rule',
            classified_at = datetime('now')
        WHERE hard_rule IS NULL
          AND ext IN ('.mac', '.hsm')
          AND instruction_count = 0
          AND has_begin_name = 0
    """),
    # U1_ASM — Pure DSECT / data layout in a .asm file
    ("U1_ASM", """
        UPDATE files SET
            hard_rule     = 'U1_ASM',
            role          = 'HARD_UTILITY',
            score_source  = 'hard_rule',
            classified_at = datetime('now')
        WHERE hard_rule IS NULL
          AND ext = '.asm'
          AND CAST(ds_equ_line_count AS REAL) / MAX(1, non_blank_lines) > 0.80
          AND instruction_count = 0
          AND has_begin_name = 0
          AND entry_point_count = 0
    """),
    # U5 — Copy book / include-only file
    ("U5", """
        UPDATE files SET
            hard_rule     = 'U5',
            role          = 'HARD_UTILITY',
            score_source  = 'hard_rule',
            classified_at = datetime('now')
        WHERE hard_rule IS NULL
          AND ext IN ('.mac', '.hsm', '.copy', '.cpy', '.h', '.hpp')
          AND call_out_count = 0
          AND has_begin_name = 0
          AND entry_point_count = 0
          AND in_degree > 0
    """),
]

# Scoring signals SQL  (Section 4.6)
_SCORING_SQL = """
-- Signal 1: ext_score
UPDATE files SET ext_score = CASE ext
    WHEN '.copy' THEN 0.92  WHEN '.cpy'  THEN 0.92
    WHEN '.mac'  THEN 0.85
    WHEN '.h'    THEN 0.80
    WHEN '.hpp'  THEN 0.75
    WHEN '.hsm'  THEN 0.35
    WHEN '.asm'  THEN 0.30
    WHEN '.cpp'  THEN 0.40
    ELSE 0.50
END;

-- Signal 2: content_score
UPDATE files SET content_score = MIN(1.0, MAX(0.0,
    CAST(ds_equ_line_count AS REAL) / MAX(1, non_blank_lines) * 1.0
  + CAST(macro_def_count   AS REAL) / MAX(1, non_blank_lines) * 0.5
  - CAST(instruction_count AS REAL) / MAX(1, non_blank_lines) * 0.8
));

-- Signal 4: entry_score (Signal 3 = fan_in_score, already computed in ingestion)
UPDATE files SET entry_score = CASE
    WHEN entry_point_count > 0 THEN 0.0
    ELSE 0.75
END;

-- Signal 5: name_score
UPDATE files SET name_score = CASE
    WHEN LOWER(stem) LIKE '%gl%'      OR LOWER(stem) LIKE '%comm%'
      OR LOWER(stem) LIKE '%work%'    OR LOWER(stem) LIKE '%wrk%'
      OR LOWER(stem) LIKE '%dsect%'   OR LOWER(stem) LIKE '%layout%'
      OR LOWER(stem) LIKE '%util%'    OR LOWER(stem) LIKE '%lib%'
      OR LOWER(stem) LIKE '%common%'  OR LOWER(stem) LIKE '%hdr%'
      OR LOWER(stem) LIKE '%incl%'    OR LOWER(stem) LIKE '%const%'
      OR LOWER(stem) LIKE '%def%'     OR LOWER(stem) LIKE '%dfhe%'
        THEN 0.80
    WHEN LOWER(stem) LIKE '%main%'    OR LOWER(stem) LIKE '%entry%'
      OR LOWER(stem) LIKE '%proc%'    OR LOWER(stem) LIKE '%batch%'
      OR LOWER(stem) LIKE '%job%'     OR LOWER(stem) LIKE '%pgmr%'
        THEN 0.20
    WHEN stem GLOB '[a-zA-Z][a-zA-Z][0-9][0-9]*'
        THEN 0.20
    WHEN stem GLOB '[0-9][0-9][0-9][0-9]*'
        THEN 0.20
    ELSE 0.50
END;

-- Final utility_score (AMBIGUOUS files only; hard-classified files skip)
UPDATE files SET utility_score = MIN(1.0, MAX(0.0,
    ext_score     * 0.30
  + content_score * 0.25
  + fan_in_score  * 0.25
  + entry_score   * 0.10
  + name_score    * 0.10
))
WHERE hard_rule IS NULL;
"""


def cmd_classify_hard(args: argparse.Namespace) -> None:
    """Apply all hard rules then compute scoring signals for ambiguous files."""
    con = _connect(args.db)

    # Reset previous classifications (allow re-run)
    con.execute("""
        UPDATE files SET
            hard_rule=NULL, role=NULL, utility_score=-1.0,
            score_source='pending', classified_at=NULL,
            ext_score=-1.0, content_score=-1.0,
            entry_score=-1.0, name_score=-1.0
    """)
    con.commit()

    total = con.execute("SELECT COUNT(*) FROM files").fetchone()[0]
    print(f"Classifying {total} files ...")

    # Step 1: HARD_CRITICAL rules (checked first — higher priority)
    for rule_id, sql in _HARD_CRITICAL_SQL:
        con.execute(sql)
        cnt = con.execute(
            "SELECT COUNT(*) FROM files WHERE hard_rule=?", (rule_id,)
        ).fetchone()[0]
        print(f"  {rule_id}: {cnt} files → HARD_CRITICAL")

    # Step 2: HARD_UTILITY rules
    for rule_id, sql in _HARD_UTILITY_SQL:
        con.execute(sql)
        cnt = con.execute(
            "SELECT COUNT(*) FROM files WHERE hard_rule=?", (rule_id,)
        ).fetchone()[0]
        print(f"  {rule_id}: {cnt} files → HARD_UTILITY")

    con.commit()

    # Step 3: Compute scoring signals for remaining (AMBIGUOUS) files
    print("  Computing scoring signals for ambiguous files ...")
    con.executescript(_SCORING_SQL)
    con.commit()

    # Step 4: Assign zone labels based on utility_score
    con.execute("""
        UPDATE files SET role = 'SOFT_UTILITY', score_source = 'score'
        WHERE hard_rule IS NULL AND utility_score > 0.70
    """)
    con.execute("""
        UPDATE files SET role = 'SOFT_CRITICAL', score_source = 'score'
        WHERE hard_rule IS NULL AND utility_score < 0.30 AND utility_score >= 0.0
    """)
    con.execute("""
        UPDATE files SET role = 'AMBIGUOUS', score_source = 'score'
        WHERE hard_rule IS NULL AND utility_score >= 0.30 AND utility_score <= 0.70
    """)
    con.execute("UPDATE files SET classified_at = datetime('now') WHERE classified_at IS NULL")
    con.commit()

    # Summary
    rows = con.execute("""
        SELECT role, COUNT(*) AS cnt
        FROM files GROUP BY role ORDER BY cnt DESC
    """).fetchall()
    print("\nClassification summary:")
    for r in rows:
        pct = r["cnt"] / max(1, total) * 100
        print(f"  {r['role'] or 'UNCLASSIFIED':<18} {r['cnt']:>6}  ({pct:.1f}%)")


# ---------------------------------------------------------------------------
# Layer 3 — Cluster builder  (Section 6.1)
# ---------------------------------------------------------------------------

def _build_cluster(con: sqlite3.Connection, entry_stems: list[str],
                   description: str | None = None,
                   max_depth: int = 10,
                   include_callers: bool = False,
                   pass_b: bool = True,
                   pass_c: bool = True) -> dict:
    """Build a functionality cluster using three passes.

    Pass A — BFS on call graph (STRUCTURAL confidence)
    Pass B — Variable co-modification (DATA_COUPLED confidence)
    Pass C — Semantic match on purpose_hint (SEMANTIC confidence, requires description)

    Returns a dict matching the cluster output structure in Section 6.3.
    """
    # ── Pass A: BFS via SQLite recursive CTE ─────────────────────────────
    con.execute("CREATE TEMP TABLE IF NOT EXISTS seeds (stem TEXT PRIMARY KEY)")
    con.execute("DELETE FROM seeds")
    for stem in entry_stems:
        con.execute("INSERT OR IGNORE INTO seeds VALUES (?)", (stem,))

    # Forward BFS
    forward_rows = con.execute("""
        WITH RECURSIVE reachable(stem, depth) AS (
            SELECT stem, 0 FROM seeds
            UNION
            SELECT e.dst_stem, r.depth + 1
            FROM edges e
            JOIN reachable r ON e.src_stem = r.stem
            WHERE r.depth < ?
        )
        SELECT r.stem, MIN(r.depth) AS depth, f.ext, f.language, f.role,
               f.in_degree, f.out_degree
        FROM reachable r
        JOIN files f ON f.stem = r.stem
        GROUP BY r.stem
    """, (max_depth,)).fetchall()

    visited: dict[str, dict] = {}
    for row in forward_rows:
        stem = row["stem"]
        depth = row["depth"]
        direction = "seed" if stem in entry_stems else "callee"
        visited[stem] = {
            "stem":           stem,
            "ext":            row["ext"] or "",
            "language":       row["language"] or "",
            "role":           row["role"] or "UNKNOWN",
            "depth":          depth,
            "direction":      direction,
            "confidence_tag": "STRUCTURAL",
            "reason":         "entry point" if depth == 0 else f"depth {depth} callee",
            "in_degree":      row["in_degree"],
            "out_degree":     row["out_degree"],
        }

    # Backward BFS (--include-callers)
    if include_callers:
        caller_rows = con.execute("""
            WITH RECURSIVE callers(stem, depth) AS (
                SELECT stem, 0 FROM seeds
                UNION
                SELECT e.src_stem, c.depth + 1
                FROM edges e
                JOIN callers c ON e.dst_stem = c.stem
                WHERE c.depth < ?
            )
            SELECT stem, MIN(depth) AS depth FROM callers GROUP BY stem
        """, (max_depth,)).fetchall()

        for row in caller_rows:
            stem = row["stem"]
            if stem not in visited:
                f_row = con.execute(
                    "SELECT ext, language, role, in_degree, out_degree FROM files WHERE stem=?",
                    (stem,)
                ).fetchone()
                visited[stem] = {
                    "stem":           stem,
                    "ext":            f_row["ext"] if f_row else "",
                    "language":       f_row["language"] if f_row else "",
                    "role":           f_row["role"] if f_row else "UNKNOWN",
                    "depth":          row["depth"],
                    "direction":      "caller",
                    "confidence_tag": "STRUCTURAL",
                    "reason":         f"depth {row['depth']} caller",
                    "in_degree":      f_row["in_degree"] if f_row else 0,
                    "out_degree":     f_row["out_degree"] if f_row else 0,
                }

    con.execute("DROP TABLE IF EXISTS seeds")

    # ── Pass B: Variable co-modification ─────────────────────────────────
    if pass_b and visited:
        cluster_stems_list = list(visited.keys())
        # Get non-excluded variables written by the cluster
        placeholders = ",".join("?" * len(cluster_stems_list))
        cluster_vars = [
            r[0] for r in con.execute(f"""
                SELECT DISTINCT vm.var_name
                FROM var_modifiers vm
                WHERE vm.stem IN ({placeholders})
                  AND vm.var_name NOT IN (SELECT var_name FROM excluded_vars)
            """, cluster_stems_list).fetchall()
        ]

        if cluster_vars:
            # Find co-modifiers not already in cluster
            var_placeholders = ",".join("?" * len(cluster_vars))
            comod_rows = con.execute(f"""
                SELECT vm.stem,
                       COUNT(DISTINCT vm.var_name) AS shared_vars,
                       COUNT(DISTINCT vm.var_name) * 1.0 / MAX(1, f.unique_vars_written)
                           AS density
                FROM var_modifiers vm
                JOIN files f ON f.stem = vm.stem
                WHERE vm.var_name IN ({var_placeholders})
                  AND vm.stem NOT IN ({placeholders})
                GROUP BY vm.stem
                HAVING shared_vars >= 5 AND density >= 0.10
                ORDER BY shared_vars DESC
            """, cluster_vars + cluster_stems_list).fetchall()

            for row in comod_rows:
                stem = row["stem"]
                shared = row["shared_vars"]
                density = row["density"]
                f_row = con.execute(
                    "SELECT ext, language, role, in_degree, out_degree FROM files WHERE stem=?",
                    (stem,)
                ).fetchone()
                visited[stem] = {
                    "stem":           stem,
                    "ext":            f_row["ext"] if f_row else "",
                    "language":       f_row["language"] if f_row else "",
                    "role":           f_row["role"] if f_row else "UNKNOWN",
                    "depth":          -1,
                    "direction":      "data_coupled",
                    "confidence_tag": "DATA_COUPLED",
                    "reason":         (f"shares {shared} variable writes with cluster "
                                       f"(density={density:.0%})"),
                    "in_degree":      f_row["in_degree"] if f_row else 0,
                    "out_degree":     f_row["out_degree"] if f_row else 0,
                }

    # ── Pass C: Semantic match ────────────────────────────────────────────
    if pass_c and description:
        # FTS5 keyword search on purpose_hint
        fts_query = " OR ".join(description.split())
        try:
            sem_rows = con.execute("""
                SELECT stem, bm25(file_hints) AS rank
                FROM file_hints
                WHERE file_hints MATCH ?
                ORDER BY rank ASC
                LIMIT 50
            """, (fts_query,)).fetchall()

            for row in sem_rows:
                stem = row["stem"]
                if stem not in visited:
                    f_row = con.execute(
                        "SELECT ext, language, role, purpose_hint, in_degree, out_degree "
                        "FROM files WHERE stem=?", (stem,)
                    ).fetchone()
                    visited[stem] = {
                        "stem":           stem,
                        "ext":            f_row["ext"] if f_row else "",
                        "language":       f_row["language"] if f_row else "",
                        "role":           f_row["role"] if f_row else "UNKNOWN",
                        "depth":          -2,
                        "direction":      "semantic",
                        "confidence_tag": "SEMANTIC",
                        "reason":         (f"blueprint header matches description "
                                           f"(hint: {f_row['purpose_hint'][:60] if f_row else ''})"),
                        "in_degree":      f_row["in_degree"] if f_row else 0,
                        "out_degree":     f_row["out_degree"] if f_row else 0,
                    }
        except sqlite3.OperationalError:
            pass  # FTS5 table may be empty

    # ── Build result ──────────────────────────────────────────────────────
    # Sort: seeds first, then by confidence_tag, then by depth
    _tag_order = {"STRUCTURAL": 0, "DATA_COUPLED": 1, "SEMANTIC": 2}
    files_list = sorted(
        visited.values(),
        key=lambda f: (
            0 if f["stem"] in entry_stems else 1,
            _tag_order.get(f["confidence_tag"], 9),
            f["depth"],
            f["stem"],
        ),
    )

    confidence_summary: dict[str, int] = {}
    for f in files_list:
        tag = f["confidence_tag"]
        confidence_summary[tag] = confidence_summary.get(tag, 0) + 1

    return {
        "entries":             entry_stems,
        "description":         description or "",
        "cluster_size":        len(files_list),
        "files":               files_list,
        "confidence_summary":  confidence_summary,
    }


# ---------------------------------------------------------------------------
# Layer 2 — LLM hybrid classification  (Section 5)
# ---------------------------------------------------------------------------

def cmd_classify_llm(args: argparse.Namespace) -> None:
    """Send AMBIGUOUS / SOFT_ zone files to the LLM for resolution."""
    con = _connect(args.db)

    try:
        from llm.caller import LLMCaller  # type: ignore
    except ImportError:
        print("ERROR: llm.caller not importable. Ensure the llm/ package is on PYTHONPATH.")
        return

    rows = con.execute("""
        SELECT stem, ext, loc, non_blank_lines, utility_score,
               has_begin_name, entry_point_count, instruction_count,
               ds_equ_line_count, unique_vars_written, call_out_count,
               in_degree, out_degree, purpose_hint, role
        FROM files
        WHERE role IN ('AMBIGUOUS', 'SOFT_UTILITY', 'SOFT_CRITICAL')
    """).fetchall()

    if not rows:
        print("No ambiguous files found — run classify-hard first.")
        return

    print(f"Sending {len(rows)} ambiguous files to LLM ...")
    caller = LLMCaller(model=args.model)
    batch_size = args.batch_size

    for i in range(0, len(rows), batch_size):
        batch = rows[i: i + batch_size]
        packets = []
        for r in batch:
            packets.append({
                "stem":  r["stem"],
                "ext":   r["ext"],
                "loc":   r["loc"],
                "utility_score": r["utility_score"],
                "zone":  r["role"],
                "blueprint_signals": {
                    "has_begin_name":    bool(r["has_begin_name"]),
                    "instruction_ratio": round(r["instruction_count"] /
                                               max(1, r["non_blank_lines"]), 3),
                    "ds_equ_ratio":      round(r["ds_equ_line_count"] /
                                               max(1, r["non_blank_lines"]), 3),
                    "unique_vars_written": r["unique_vars_written"],
                    "in_degree":  r["in_degree"],
                    "out_degree": r["out_degree"],
                },
                "purpose_hint": r["purpose_hint"] or "",
            })

        try:
            results = caller.classify_utility_batch(packets)
        except Exception as exc:
            print(f"  WARN: LLM batch {i//batch_size + 1} failed: {exc}")
            continue

        for res in results:
            stem  = res.get("stem")
            label = res.get("label", "AMBIGUOUS")
            conf  = float(res.get("confidence", 0.0))
            if conf < 0.50:
                label = "AMBIGUOUS"
            fused = float(res.get("fused_score", -1.0))
            reason = res.get("reason", "")

            con.execute("""
                INSERT OR REPLACE INTO llm_decisions
                    (stem, content_hash, label, confidence, reason,
                     fused_score, score_source, model_id, classified_at)
                VALUES (?,?,?,?,?,?,'llm',?,datetime('now'))
            """, (stem, "", label, conf, reason, fused, args.model))

            # Update files table
            if label not in ("AMBIGUOUS",):
                role = f"SOFT_{label}" if label in ("UTILITY", "CRITICAL") else label
                con.execute("""
                    UPDATE files SET role=?, fused_score=?,
                        score_source='llm', classified_at=datetime('now')
                    WHERE stem=?
                """, (role, fused, stem))

        con.commit()
        print(f"  Processed batch {i//batch_size + 1}/{-(-len(rows)//batch_size)}")

    print("LLM classification complete.")


# ---------------------------------------------------------------------------
# CLI commands
# ---------------------------------------------------------------------------

def cmd_ingest(args: argparse.Namespace) -> None:
    """Layer 0: ingest pipeline outputs → SQLite."""
    con = _connect(args.db)
    _init_schema(con)

    # Increment generation counter on re-ingest
    if getattr(args, "incremental", False):
        con.execute("""
            UPDATE ingest_meta
            SET value = CAST(CAST(value AS INTEGER)+1 AS TEXT)
            WHERE key = 'generation'
        """)
        con.commit()

    bp_dir  = _blueprint_dir(args.pipeline_output)
    src_dir = getattr(args, "src", None)
    verbose = getattr(args, "verbose", False)

    print(f"Blueprint directory: {bp_dir}")

    # Step 2: ingest blueprints
    n = _ingest_blueprints(con, bp_dir, src_dir, verbose)
    print(f"  Blueprints ingested: {n} files")

    # Step 3: update total_files
    con.execute("""
        UPDATE ingest_meta
        SET value = (SELECT COUNT(*) FROM files)
        WHERE key = 'total_files'
    """)
    con.commit()

    # Steps 4: call graph
    fcg = Path(args.pipeline_output) / "file_call_graph.json"
    if fcg.exists():
        nodes, edges = _ingest_call_graph(con, fcg, verbose)
        print(f"  Call graph: {nodes} nodes, {edges} edges")
    else:
        print(f"  WARN: {fcg} not found — graph metrics will be zero")

    # Step 5: variable modifiers
    vmi = Path(args.pipeline_output) / "variable_modifier_index.json"
    if vmi.exists():
        rows = _ingest_var_modifiers(con, vmi, verbose)
        print(f"  Variable modifiers: {rows} rows")
        excl = _rebuild_excluded_vars(con, verbose)
    else:
        print(f"  WARN: {vmi} not found — Pass B disabled")

    total = con.execute("SELECT COUNT(*) FROM files").fetchone()[0]
    print(f"\nIndex built: {total} files in {args.db}")
    print("Next: python3 utility_detector_v2.py classify-hard --db", args.db)


def cmd_build_embeddings(args: argparse.Namespace) -> None:
    """Layer 0, step 8: populate FTS5 file_hints table from purpose_hint."""
    con = _connect(args.db)

    # Repopulate FTS5
    con.execute("DELETE FROM file_hints")
    con.execute("""
        INSERT INTO file_hints (stem, hint_text)
        SELECT stem, purpose_hint
        FROM files
        WHERE purpose_hint IS NOT NULL AND purpose_hint != ''
    """)
    con.commit()

    cnt = con.execute("SELECT COUNT(*) FROM file_hints").fetchone()[0]
    print(f"FTS5 index built: {cnt} files with purpose hints")


def cmd_analyze(args: argparse.Namespace) -> None:
    """Show utility ranking and classification summary."""
    con = _connect(args.db)

    total = con.execute("SELECT COUNT(*) FROM files").fetchone()[0]
    print(f"\nTotal files indexed: {total}")

    # Classification breakdown
    rows = con.execute("""
        SELECT role, COUNT(*) AS cnt
        FROM files
        GROUP BY role
        ORDER BY cnt DESC
    """).fetchall()

    print("\nClassification breakdown:")
    print(f"  {'Role':<22} {'Count':>7}  {'%':>6}")
    print(f"  {'-'*22} {'-'*7}  {'-'*6}")
    for r in rows:
        pct = r["cnt"] / max(1, total) * 100
        print(f"  {r['role'] or 'UNCLASSIFIED':<22} {r['cnt']:>7}  {pct:>5.1f}%")

    # Hard rule breakdown
    print("\nHard rule breakdown:")
    rule_rows = con.execute("""
        SELECT hard_rule, role, COUNT(*) AS cnt
        FROM files
        WHERE hard_rule IS NOT NULL
        GROUP BY hard_rule
        ORDER BY cnt DESC
    """).fetchall()
    for r in rule_rows:
        print(f"  {r['hard_rule']:<8} {r['role']:<18} {r['cnt']}")

    # Top AMBIGUOUS files by utility_score
    ambig = con.execute("""
        SELECT stem, ext, utility_score, in_degree, instruction_count, purpose_hint
        FROM files
        WHERE role = 'AMBIGUOUS'
        ORDER BY utility_score DESC
        LIMIT 20
    """).fetchall()

    if ambig:
        print(f"\nTop ambiguous files ({len(ambig)} shown):")
        print(f"  {'Stem':<16} {'Ext':<6} {'Score':>6}  {'FanIn':>6}  {'Hint'}")
        print(f"  {'-'*16} {'-'*6} {'-'*6}  {'-'*6}  {'-'*30}")
        for r in ambig:
            hint = (r["purpose_hint"] or "")[:40]
            print(f"  {r['stem']:<16} {r['ext']:<6} {r['utility_score']:>6.3f}"
                  f"  {r['in_degree']:>6}  {hint}")


def cmd_cluster(args: argparse.Namespace) -> None:
    """Build and display a functionality cluster."""
    con = _connect(args.db)

    # Support both --entry (single) and --entries (comma-separated)
    if hasattr(args, "entries") and args.entries:
        entry_stems = [s.strip() for s in args.entries.split(",") if s.strip()]
    elif hasattr(args, "entry") and args.entry:
        entry_stems = [args.entry.strip()]
    else:
        print("ERROR: --entry or --entries required")
        return

    result = _build_cluster(
        con,
        entry_stems    = entry_stems,
        description    = getattr(args, "description", None),
        max_depth      = getattr(args, "max_depth", 10),
        include_callers= getattr(args, "include_callers", False),
        pass_b         = True,
        pass_c         = bool(getattr(args, "description", None)),
    )

    # Display
    entries_str = ", ".join(entry_stems)
    desc        = result["description"]
    print(f"\nCluster for: {entries_str}" + (f'  ("{desc}")' if desc else ""))
    print("━" * 70)

    current_tag = None
    for f in result["files"]:
        tag = f["confidence_tag"]
        if tag != current_tag:
            conf_count = result["confidence_summary"].get(tag, 0)
            pct = {"STRUCTURAL": "100%", "DATA_COUPLED": "~90%", "SEMANTIC": "~75%"}.get(tag, "?")
            print(f"\n{tag} ({conf_count} files — {pct} confidence):")
            current_tag = tag

        marker = "★ " if f["stem"] in entry_stems else "  "
        shared = f.get("shared_vars", [])
        shared_str = f"  shares {shared[:3]}" if shared else ""
        print(f"{marker}{f['stem']:<16} {f['ext']:<6} {f['role'] or '?':<18} "
              f"depth={f['depth']:>3}  {f['direction']:<12} "
              f"  {f['reason'][:50]}{shared_str}")

    print(f"\nCluster size: {result['cluster_size']} files")
    print(f"Confidence: " + "  ".join(
        f"{k}={v}" for k, v in result["confidence_summary"].items()
    ))

    # JSON output
    output = getattr(args, "output", None)
    if output:
        with open(output, "w") as fh:
            json.dump(result, fh, indent=2)
        print(f"\nSaved to {output}")


def cmd_explain(args: argparse.Namespace) -> None:
    """Explain a file's classification: which rule fired, signal values."""
    con = _connect(args.db)
    stem = args.stem

    row = con.execute("""
        SELECT stem, ext, loc, non_blank_lines, has_begin_name, entry_point_count,
               instruction_count, ds_equ_line_count, dsect_field_count, macro_def_count,
               unique_vars_written, call_out_count, is_leaf,
               in_degree, in_degree_from_cpp, out_degree, fan_in_score,
               ext_score, content_score, entry_score, name_score, utility_score,
               hard_rule, role, score_source, purpose_hint, classified_at
        FROM files WHERE stem = ?
    """, (stem,)).fetchone()

    if not row:
        print(f"ERROR: stem '{stem}' not found in {args.db}")
        return

    print(f"\n{'─'*60}")
    print(f"  Stem:      {row['stem']}")
    print(f"  Extension: {row['ext']}   LOC: {row['loc']}   Non-blank: {row['non_blank_lines']}")
    print(f"  Role:      {row['role'] or 'UNCLASSIFIED'}")
    print(f"  Source:    {row['score_source']}   Classified: {row['classified_at']}")

    print(f"\nBlueprint signals:")
    print(f"  has_begin_name     : {bool(row['has_begin_name'])}")
    print(f"  entry_point_count  : {row['entry_point_count']}")
    print(f"  instruction_count  : {row['instruction_count']}  "
          f"(ratio: {row['instruction_count']/max(1,row['non_blank_lines']):.3f})")
    print(f"  ds_equ_line_count  : {row['ds_equ_line_count']}  "
          f"(ratio: {row['ds_equ_line_count']/max(1,row['non_blank_lines']):.3f})")
    print(f"  dsect_field_count  : {row['dsect_field_count']}")
    print(f"  macro_def_count    : {row['macro_def_count']}")
    print(f"  unique_vars_written: {row['unique_vars_written']}")
    print(f"  call_out_count     : {row['call_out_count']}   is_leaf: {bool(row['is_leaf'])}")

    print(f"\nGraph signals:")
    print(f"  in_degree         : {row['in_degree']}")
    print(f"  in_degree_from_cpp: {row['in_degree_from_cpp']}")
    print(f"  out_degree        : {row['out_degree']}")
    print(f"  fan_in_score      : {row['fan_in_score']:.4f}")

    if row["hard_rule"]:
        print(f"\nHard rule fired: {row['hard_rule']} → {row['role']}")
    else:
        print(f"\nScoring signals (ambiguous zone):")
        print(f"  ext_score     : {row['ext_score']:.4f}  × 0.30")
        print(f"  content_score : {row['content_score']:.4f}  × 0.25")
        print(f"  fan_in_score  : {row['fan_in_score']:.4f}  × 0.25")
        print(f"  entry_score   : {row['entry_score']:.4f}  × 0.10")
        print(f"  name_score    : {row['name_score']:.4f}  × 0.10")
        print(f"  utility_score : {row['utility_score']:.4f}")

    if row["purpose_hint"]:
        print(f"\nPurpose hint: {row['purpose_hint'][:120]}")

    # Show callers and callees
    callers = con.execute(
        "SELECT src_stem FROM edges WHERE dst_stem=? LIMIT 10", (stem,)
    ).fetchall()
    callees = con.execute(
        "SELECT dst_stem FROM edges WHERE src_stem=? LIMIT 10", (stem,)
    ).fetchall()
    if callers:
        print(f"\nCallers ({len(callers)} shown): " + ", ".join(r[0] for r in callers))
    if callees:
        print(f"Callees ({len(callees)} shown): " + ", ".join(r[0] for r in callees))
    print("─" * 60)


def cmd_override(args: argparse.Namespace) -> None:
    """Set a human override for a file's classification."""
    con = _connect(args.db)
    con.execute("""
        INSERT OR REPLACE INTO human_overrides (stem, label, reason, set_by, set_at)
        VALUES (?, ?, ?, ?, datetime('now'))
    """, (args.stem, args.label.upper(), getattr(args, "reason", ""),
          os.environ.get("USER", "unknown")))
    con.execute("""
        UPDATE files SET role=?, score_source='human_override',
            classified_at=datetime('now')
        WHERE stem=?
    """, (args.label.upper(), args.stem))
    con.commit()
    print(f"Override set: {args.stem} → {args.label.upper()}")


def cmd_review_queue(args: argparse.Namespace) -> None:
    """Show files pending human review."""
    con = _connect(args.db)
    rows = con.execute("""
        SELECT rq.stem, rq.reason, rq.queued_at, f.role, f.utility_score
        FROM review_queue rq
        LEFT JOIN files f ON f.stem = rq.stem
        WHERE rq.resolved = 0
        ORDER BY rq.queued_at DESC
        LIMIT 50
    """).fetchall()

    if not rows:
        print("Review queue is empty.")
        return

    print(f"\nReview queue ({len(rows)} items):")
    print(f"  {'Stem':<16} {'Role':<18} {'Score':>6}  {'Reason'}")
    print(f"  {'-'*16} {'-'*18} {'-'*6}  {'-'*40}")
    for r in rows:
        score = f"{r['utility_score']:.3f}" if r["utility_score"] is not None else "  n/a"
        print(f"  {r['stem']:<16} {r['role'] or '?':<18} {score:>6}  {r['reason'][:60]}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Hybrid Utility Detection — pipeline-integrated (v2)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""
            Typical workflow:
              python3 utility_detector_v2.py ingest \\
                  --pipeline-output output/ --src temp/asm \\
                  --db utility_index_v2.db
              python3 utility_detector_v2.py classify-hard --db utility_index_v2.db
              python3 utility_detector_v2.py build-embeddings --db utility_index_v2.db
              python3 utility_detector_v2.py analyze --db utility_index_v2.db
              python3 utility_detector_v2.py cluster --entry da78 \\
                  --description "credit limit maintenance" \\
                  --db utility_index_v2.db
        """),
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # ingest
    p = sub.add_parser("ingest", help="Ingest pipeline outputs into SQLite index")
    p.add_argument("--pipeline-output", default="output/",
                   help="Directory containing pipeline output files (default: output/)")
    p.add_argument("--src", default=None,
                   help="Source file directory for has_begin_name detection "
                        "(e.g. temp/asm). Optional but recommended for .asm/.hsm.")
    p.add_argument("--db", default="utility_index_v2.db")
    p.add_argument("--incremental", action="store_true",
                   help="Increment generation counter (incremental re-index)")
    p.add_argument("--verbose", "-v", action="store_true")
    p.set_defaults(func=cmd_ingest)

    # classify-hard
    p = sub.add_parser("classify-hard",
                        help="Apply hard rules (C1–C4, U1–U5) + score ambiguous files")
    p.add_argument("--db", default="utility_index_v2.db")
    p.set_defaults(func=cmd_classify_hard)

    # build-embeddings
    p = sub.add_parser("build-embeddings",
                        help="Build FTS5 full-text index for Pass C semantic search")
    p.add_argument("--db", default="utility_index_v2.db")
    p.set_defaults(func=cmd_build_embeddings)

    # build-exclusions  (alias for the exclusion rebuild)
    p = sub.add_parser("build-exclusions",
                        help="Rebuild excluded_vars table (high-frequency var noise filter)")
    p.add_argument("--db", default="utility_index_v2.db")
    p.add_argument("--threshold", type=float, default=0.02)
    p.set_defaults(func=lambda a: (
        _rebuild_excluded_vars(_connect(a.db), True),
        print("Done."),
    ))

    # classify-llm
    p = sub.add_parser("classify-llm",
                        help="LLM classification for ambiguous/soft zone files (Layer 2)")
    p.add_argument("--db", default="utility_index_v2.db")
    p.add_argument("--model", default="claude-sonnet-4-6")
    p.add_argument("--batch-size", type=int, default=20)
    p.add_argument("--dry-run", action="store_true")
    p.set_defaults(func=cmd_classify_llm)

    # analyze
    p = sub.add_parser("analyze", help="Show utility rankings and classification summary")
    p.add_argument("--db", default="utility_index_v2.db")
    p.set_defaults(func=cmd_analyze)

    # cluster
    p = sub.add_parser("cluster", help="Get functionality cluster for an entry point")
    p.add_argument("--entry",  help="Single entry stem (e.g. da78)")
    p.add_argument("--entries", help="Comma-separated entry stems (e.g. da76,da78)")
    p.add_argument("--description", "-d", default=None,
                   help="Natural-language functionality description (enables Pass C)")
    p.add_argument("--max-depth", type=int, default=10)
    p.add_argument("--include-callers", action="store_true")
    p.add_argument("--output", "-o", default=None, help="Save cluster JSON to file")
    p.add_argument("--db", default="utility_index_v2.db")
    p.set_defaults(func=cmd_cluster)

    # explain
    p = sub.add_parser("explain", help="Explain a file's classification")
    p.add_argument("--stem", required=True)
    p.add_argument("--db", default="utility_index_v2.db")
    p.set_defaults(func=cmd_explain)

    # override
    p = sub.add_parser("override", help="Set a human override for a file's role")
    p.add_argument("--stem", required=True)
    p.add_argument("--label", required=True,
                   choices=["UTILITY", "CRITICAL", "HARD_UTILITY", "HARD_CRITICAL"])
    p.add_argument("--reason", default="")
    p.add_argument("--db", default="utility_index_v2.db")
    p.set_defaults(func=cmd_override)

    # review-queue
    p = sub.add_parser("review-queue", help="Show files pending human review")
    p.add_argument("--db", default="utility_index_v2.db")
    p.set_defaults(func=cmd_review_queue)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
