#!/usr/bin/env python3
"""
filter_block_lineage.py

Filter a block-level forward-lineage graph down to the ancestry of a target block.

Given a target block, this script:
1) Collects all blocks that can reach the target (including the target block).
2) Keeps edges between those selected blocks.
3) Prints the selected edges and full source code for each selected block.

Usage:
    python3 filter_block_lineage.py <lineage_block_graph.json> <target_block> [--output <file>]

Examples:
    python3 filter_block_lineage.py \
      temp/asm/output/xh72_CR21GLLMPD_forward_lineage.json XH721612

    python3 filter_block_lineage.py \
      temp/asm/output/xh72_CR21GLLMPD_forward_lineage.json xh72:XH721612 \
      --output temp/output/xh72_XH721612_lineage.txt
"""

from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict, deque
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from blueprint_io import iter_flow, load_blueprint as _io_load_blueprint


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Filter block-lineage graph to ancestry of a target block.")
    p.add_argument("lineage_json", help="Block-level lineage JSON produced by forward_trace_lineage.py")
    p.add_argument("target_block", help="Target block id (e.g. XH721612 or xh72:XH721612)")
    p.add_argument("--output", dest="output_file", help="Optional output text file")
    p.add_argument("--source-asm", dest="source_asm", help="Optional ASM file path override")
    p.add_argument("--blueprint", dest="blueprint", help="Optional blueprint JSON path override")
    p.add_argument("--asm-dir", dest="asm_dir", help="Optional ASM directory for source file lookup")
    p.add_argument("--blueprint-dir", dest="blueprint_dir", help="Optional blueprint directory for block ranges")
    return p.parse_args()


def _norm(s: str) -> str:
    return str(s or "").strip().lower()


def load_json(path: Path) -> Dict[str, Any]:
    return _io_load_blueprint(path)


def resolve_target_block_id(nodes: List[Dict[str, Any]], query: str) -> str:
    q = _norm(query)
    by_bid = {str(n.get("block_id", "")): n for n in nodes if n.get("block_id")}
    if q in {_norm(k) for k in by_bid}:
        for k in by_bid:
            if _norm(k) == q:
                return k

    by_block = defaultdict(list)
    for n in nodes:
        block_id = str(n.get("block_id", ""))
        block = str(n.get("block", ""))
        if block_id and block:
            by_block[_norm(block)].append(block_id)

    # Exact block label match (e.g., XH721612).
    hits = by_block.get(q, [])
    if len(hits) == 1:
        return hits[0]
    if len(hits) > 1:
        raise SystemExit(f"Ambiguous target block '{query}' matches multiple block_ids: {', '.join(sorted(hits))}")

    # Suffix match on block_id after file stem (e.g., xh72:XH721612 -> XH721612).
    suffix_hits = []
    for n in nodes:
        bid = str(n.get("block_id", ""))
        if ":" in bid and _norm(bid.split(":", 1)[1]) == q:
            suffix_hits.append(bid)
    if len(suffix_hits) == 1:
        return suffix_hits[0]
    if len(suffix_hits) > 1:
        raise SystemExit(
            f"Ambiguous target block suffix '{query}' matches multiple block_ids: {', '.join(sorted(suffix_hits))}"
        )

    raise SystemExit(f"Target block '{query}' not found in graph.")


def build_reverse_index(edges: List[Dict[str, Any]]) -> Dict[str, List[str]]:
    incoming: Dict[str, List[str]] = defaultdict(list)
    for e in edges:
        src = str(e.get("from_block_id", ""))
        dst = str(e.get("to_block_id", ""))
        if not src or not dst:
            continue
        incoming[dst].append(src)
    return incoming


def collect_ancestors(target_block_id: str, incoming: Dict[str, List[str]]) -> Set[str]:
    keep: Set[str] = set()
    stack = [target_block_id]
    while stack:
        cur = stack.pop()
        if cur in keep:
            continue
        keep.add(cur)
        for parent in incoming.get(cur, []):
            if parent not in keep:
                stack.append(parent)
    return keep


def distance_to_target(target_block_id: str, incoming: Dict[str, List[str]]) -> Dict[str, int]:
    dist: Dict[str, int] = {target_block_id: 0}
    q = deque([target_block_id])
    while q:
        cur = q.popleft()
        for parent in incoming.get(cur, []):
            if parent in dist:
                continue
            dist[parent] = dist[cur] + 1
            q.append(parent)
    return dist


def resolve_source_path(
    file_name: str,
    lineage_path: Path,
    source_override: Optional[Path],
    asm_dir: Optional[Path],
) -> Optional[Path]:
    if source_override:
        return source_override if source_override.exists() else None

    cwd = Path.cwd()
    candidates = []
    if asm_dir:
        candidates.append(asm_dir / file_name)
    candidates.extend(
        [
            lineage_path.parent / file_name,
            lineage_path.parent.parent / file_name,
            cwd / file_name,
            cwd / "temp" / "asm" / file_name,
        ]
    )
    for c in candidates:
        if c.exists():
            return c
    return None


def resolve_blueprint_path(
    file_name: str,
    lineage_path: Path,
    blueprint_override: Optional[Path],
    blueprint_dir: Optional[Path],
) -> Optional[Path]:
    if blueprint_override:
        return blueprint_override if blueprint_override.exists() else None

    stem = Path(file_name).stem
    cwd = Path.cwd()
    candidates = []
    if blueprint_dir:
        candidates.extend(
            [
                blueprint_dir / f"{file_name}.json",
                blueprint_dir / f"{stem}.asm.json",
                blueprint_dir / f"{stem}.json",
            ]
        )
    candidates.extend(
        [
            cwd / "temp" / "parser_run" / f"{file_name}.json",
            cwd / "temp" / "parser_run" / f"{stem}.asm.json",
            lineage_path.parent.parent.parent / "parser_run" / f"{file_name}.json",
            lineage_path.parent.parent.parent / "parser_run" / f"{stem}.asm.json",
        ]
    )
    for c in candidates:
        if c.exists():
            return c
    return None


def find_label_line(source_lines: List[str], label: str) -> Optional[int]:
    pat = re.compile(rf"^\s*{re.escape(label)}\b", re.IGNORECASE)
    for idx, raw in enumerate(source_lines, start=1):
        if pat.match(raw):
            return idx
    return None


def build_block_ranges_from_blueprint(source_lines: List[str], blueprint: Dict[str, Any]) -> Dict[str, Tuple[int, int]]:
    starts: List[Tuple[str, int]] = []
    for block in blueprint.get("blocks", []) or []:
        block_id = str(block.get("id", "")).strip()
        if not block_id:
            continue
        flow_lines = [int(e.get("line", 0)) for e in list(iter_flow(block)) if int(e.get("line", 0)) > 0]
        label_line = find_label_line(source_lines, block_id)
        candidates = [x for x in [label_line, min(flow_lines) if flow_lines else None] if x and x > 0]
        if not candidates:
            continue
        starts.append((block_id, min(candidates)))

    starts.sort(key=lambda x: (x[1], x[0]))
    ranges: Dict[str, Tuple[int, int]] = {}
    for i, (block_id, start) in enumerate(starts):
        if i + 1 < len(starts):
            end = starts[i + 1][1] - 1
        else:
            end = len(source_lines)
        if end < start:
            end = start
        ranges[block_id] = (start, end)
    return ranges


def fallback_block_ranges(nodes: List[Dict[str, Any]]) -> Dict[str, Tuple[int, int]]:
    ranges: Dict[str, Tuple[int, int]] = {}
    for n in nodes:
        block = str(n.get("block", ""))
        first_line = int(n.get("first_line", 0) or 0)
        last_line = int(n.get("last_line", 0) or 0)
        if not block or first_line <= 0:
            continue
        if last_line < first_line:
            last_line = first_line
        ranges[block] = (first_line, last_line)
    return ranges


def format_output(
    lineage_file: Path,
    target_block_id: str,
    target_block: str,
    selected_nodes: List[Dict[str, Any]],
    selected_edges: List[Dict[str, Any]],
    dist: Dict[str, int],
    source_lines: List[str],
    block_ranges: Dict[str, Tuple[int, int]],
) -> str:
    lines: List[str] = []
    lines.append(f"Target Block: {target_block_id} ({target_block})")
    lines.append(f"Source Graph: {lineage_file}")
    lines.append(f"Selected Blocks (ancestors + target): {len(selected_nodes)}")
    lines.append(f"Selected Edges: {len(selected_edges)}")
    lines.append("")

    lines.append("EDGES (toward target)")
    lines.append("=" * 90)
    lines.append("From Block                -> To Block                  Type                 Line")
    lines.append("------------------------- --------------------------- -------------------- -----")
    for e in selected_edges:
        src = str(e.get("from_block_id", ""))[:25].ljust(25)
        dst = str(e.get("to_block_id", ""))[:27].ljust(27)
        typ = str(e.get("type", ""))[:20].ljust(20)
        ln = str(e.get("line", "")).rjust(5)
        lines.append(f"{src} {dst} {typ} {ln}")

    lines.append("")
    lines.append("BLOCKS")
    lines.append("=" * 90)
    lines.append("Block ID                  Dist->Target  Line Range  Parents")
    lines.append("------------------------- ------------  ----------  ----------------------------------")
    for n in selected_nodes:
        bid = str(n.get("block_id", ""))
        block = str(n.get("block", ""))
        d = dist.get(bid, "")
        rng = block_ranges.get(block, (int(n.get("first_line", 0) or 0), int(n.get("last_line", 0) or 0)))
        parents = ", ".join(n.get("parent_block_ids", []) or [])
        lines.append(f"{bid[:25].ljust(25)} {str(d).rjust(12)}  {str(rng[0]).rjust(4)}-{str(rng[1]).ljust(4)}  {parents}")

    lines.append("")
    lines.append("BLOCK SOURCE")
    lines.append("=" * 90)
    for n in selected_nodes:
        bid = str(n.get("block_id", ""))
        block = str(n.get("block", ""))
        rng = block_ranges.get(block, (int(n.get("first_line", 0) or 0), int(n.get("last_line", 0) or 0)))
        start, end = rng
        if start <= 0:
            start = 1
        if end <= 0:
            end = start
        if end > len(source_lines):
            end = len(source_lines)

        lines.append("")
        lines.append("-" * 90)
        lines.append(f"BLOCK {bid}  [{start}-{end}]")
        lines.append("-" * 90)
        for ln in range(start, end + 1):
            src = source_lines[ln - 1] if 1 <= ln <= len(source_lines) else ""
            lines.append(f"{str(ln).rjust(5)}  {src}")

    lines.append("")
    return "\n".join(lines)


def main() -> int:
    args = parse_args()
    lineage_file = Path(args.lineage_json).expanduser().resolve()
    if not lineage_file.exists():
        raise SystemExit(f"Lineage JSON not found: {lineage_file}")

    data = load_json(lineage_file)
    if str(data.get("graph_level", "")).lower() != "block":
        raise SystemExit(
            "Expected block-level graph JSON (graph_level='block'). "
            "Re-run forward_trace_lineage.py with current block-graph output."
        )

    nodes = data.get("nodes", []) or []
    edges = data.get("edges", []) or []
    if not nodes:
        raise SystemExit("Graph has no nodes.")

    target_block_id = resolve_target_block_id(nodes, args.target_block)
    node_by_id = {str(n.get("block_id", "")): n for n in nodes if n.get("block_id")}
    target_node = node_by_id[target_block_id]
    target_block = str(target_node.get("block", ""))

    incoming = build_reverse_index(edges)
    keep_ids = collect_ancestors(target_block_id, incoming)
    dist = distance_to_target(target_block_id, incoming)

    selected_nodes = [n for n in nodes if str(n.get("block_id", "")) in keep_ids]
    selected_nodes.sort(
        key=lambda n: (
            -int(dist.get(str(n.get("block_id", "")), 0)),
            str(n.get("file", "")),
            int(n.get("first_line", 0) or 0),
            str(n.get("block_id", "")),
        )
    )

    selected_edges = []
    for e in edges:
        src = str(e.get("from_block_id", ""))
        dst = str(e.get("to_block_id", ""))
        if src in keep_ids and dst in keep_ids:
            selected_edges.append(e)
    selected_edges.sort(
        key=lambda e: (
            -int(dist.get(str(e.get("from_block_id", "")), 0)),
            -int(dist.get(str(e.get("to_block_id", "")), 0)),
            int(e.get("line", 0) or 0),
            str(e.get("from_block_id", "")),
            str(e.get("to_block_id", "")),
        )
    )

    file_name = str(data.get("file", "")).strip()
    source_override = Path(args.source_asm).expanduser().resolve() if args.source_asm else None
    asm_dir = Path(args.asm_dir).expanduser().resolve() if args.asm_dir else None
    source_path = resolve_source_path(file_name, lineage_file, source_override, asm_dir)
    if not source_path:
        raise SystemExit(
            f"Could not resolve source ASM file for '{file_name}'. "
            f"Pass --source-asm explicitly."
        )
    source_lines = source_path.read_text(encoding="utf-8", errors="ignore").splitlines()

    blueprint_override = Path(args.blueprint).expanduser().resolve() if args.blueprint else None
    blueprint_dir = Path(args.blueprint_dir).expanduser().resolve() if args.blueprint_dir else None
    blueprint_path = resolve_blueprint_path(file_name, lineage_file, blueprint_override, blueprint_dir)

    if blueprint_path and blueprint_path.exists():
        blueprint = load_json(blueprint_path)
        block_ranges = build_block_ranges_from_blueprint(source_lines, blueprint)
    else:
        block_ranges = fallback_block_ranges(selected_nodes)

    report = format_output(
        lineage_file=lineage_file,
        target_block_id=target_block_id,
        target_block=target_block,
        selected_nodes=selected_nodes,
        selected_edges=selected_edges,
        dist=dist,
        source_lines=source_lines,
        block_ranges=block_ranges,
    )
    print(report, end="")

    if args.output_file:
        out = Path(args.output_file).expanduser().resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(report, encoding="utf-8")
        print(f"\nOutput saved to: {out}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
