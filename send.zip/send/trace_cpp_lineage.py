#!/usr/bin/env python3
"""Trace C++ variable lineage from blueprint JSON.

This tool consumes `variable_lineage` from a `.cpp.json` blueprint and emits a
JSON report with:
- root resolution details
- backward/forward level traversal
- dependent variables (1-hop neighbors)
- argument bindings (1-hop call_arg neighbors)
- dependent files/callees inferred from traversed edges + call graph
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict, deque
from pathlib import Path
from typing import Any, Deque, Dict, Iterable, List, Optional, Sequence, Set, Tuple


EXIT_SUCCESS = 0
EXIT_INPUT_ERROR = 2
EXIT_JSON_ERROR = 3
EXIT_MISSING_LINEAGE = 4
EXIT_NO_MATCH = 5
EXIT_AMBIGUOUS = 6

ROOT_KINDS: Set[str] = {
    "parameter",
    "variable",
    "member",
    "struct_field",
    "array_element",
    "memory",
}

VAR_LIKE_FOR_CONTEXT: Set[str] = {
    "parameter",
    "variable",
    "member",
    "struct_field",
    "array_element",
    "memory",
    "return_value",
    "call_arg",
}

KIND_PRIORITY: Dict[str, int] = {
    "parameter": 0,
    "variable": 1,
    "member": 2,
    "struct_field": 3,
    "array_element": 4,
    "memory": 5,
}


def eprint(message: str) -> None:
    print(message, file=sys.stderr)


def edge_key(edge: Dict[str, Any]) -> Tuple[Any, ...]:
    return (
        edge.get("source"),
        edge.get("target"),
        edge.get("relation"),
        edge.get("file"),
        edge.get("line"),
        edge.get("statement_id"),
        edge.get("expression"),
    )


def node_name_from_id(node_id: str) -> str:
    if ":" not in node_id:
        return node_id
    return node_id.split(":", 1)[1]


def tail_name(name: str) -> str:
    if not name:
        return ""
    return name.split("::")[-1]


def strip_ref_prefix(name: str) -> str:
    return name.lstrip("*&")


def normalize_scope_string(scope: Optional[str]) -> str:
    return str(scope or "").strip()


def resolve_node_scope(node: Dict[str, Any], define_edges: Sequence[Dict[str, Any]]) -> Optional[str]:
    metadata = node.get("metadata", {}) if isinstance(node.get("metadata"), dict) else {}
    scope = metadata.get("enclosing_function") or metadata.get("scope")
    if scope:
        return str(scope)
    for edge in define_edges:
        scope = edge.get("scope")
        if scope:
            return str(scope)

    # Fallback for scoped names like `func::var`.
    name = str(node.get("name") or "")
    if "::" in name:
        return name.split("::", 1)[0]
    return None


def resolve_node_line(define_edges: Sequence[Dict[str, Any]]) -> Optional[int]:
    lines = [edge.get("line") for edge in define_edges if isinstance(edge.get("line"), int) and edge.get("line", 0) > 0]
    return min(lines) if lines else None


def match_rank(candidate_name: str, query: str) -> Optional[int]:
    if not candidate_name:
        return None
    c_full = candidate_name
    c_tail = tail_name(candidate_name)
    c_full_stripped = strip_ref_prefix(candidate_name)
    c_tail_stripped = tail_name(c_full_stripped)
    q = query
    q_low = query.lower()

    if c_full == q:
        return 0
    if c_tail == q:
        return 1
    if c_full_stripped == q:
        return 2
    if c_tail_stripped == q:
        return 3
    if c_full.lower() == q_low:
        return 4
    if c_tail.lower() == q_low:
        return 5
    if c_full_stripped.lower() == q_low:
        return 6
    if c_tail_stripped.lower() == q_low:
        return 7
    return None


def load_blueprint(path: Path) -> Dict[str, Any]:
    from blueprint_io import load_blueprint as _io_load
    try:
        return _io_load(path)
    except FileNotFoundError:
        eprint(f"Input file not found: {path}")
        raise SystemExit(EXIT_INPUT_ERROR)
    except OSError as exc:
        eprint(f"Failed to read input file: {path} ({exc})")
        raise SystemExit(EXIT_INPUT_ERROR)
    except Exception as exc:
        eprint(f"Failed to parse blueprint: {path} ({exc})")
        raise SystemExit(EXIT_JSON_ERROR)


def validate_lineage_shape(payload: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    lineage = payload.get("variable_lineage")
    if not isinstance(lineage, dict):
        eprint("Missing `variable_lineage` object in blueprint JSON.")
        raise SystemExit(EXIT_MISSING_LINEAGE)

    nodes = lineage.get("nodes")
    edges = lineage.get("edges")
    if not isinstance(nodes, list) or not isinstance(edges, list):
        eprint("`variable_lineage.nodes` and `variable_lineage.edges` must be lists.")
        raise SystemExit(EXIT_MISSING_LINEAGE)

    return nodes, edges


def dedupe_edges(edges: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen: Set[Tuple[Any, ...]] = set()
    deduped: List[Dict[str, Any]] = []
    for edge in edges:
        key = edge_key(edge)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(edge)
    return deduped


def build_index(
    nodes: Sequence[Dict[str, Any]],
    edges: Sequence[Dict[str, Any]],
) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, List[Dict[str, Any]]], Dict[str, List[Dict[str, Any]]], Dict[str, List[Dict[str, Any]]]]:
    node_map: Dict[str, Dict[str, Any]] = {}
    for node in nodes:
        node_id = node.get("id")
        if isinstance(node_id, str) and node_id:
            node_map[node_id] = node

    out_adj: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    in_adj: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    define_edges_by_node: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    for edge in edges:
        src = edge.get("source")
        tgt = edge.get("target")
        if isinstance(src, str) and src:
            out_adj[src].append(edge)
        if isinstance(tgt, str) and tgt:
            in_adj[tgt].append(edge)
        if (
            edge.get("relation") == "define"
            and isinstance(src, str)
            and isinstance(tgt, str)
            and src == tgt
        ):
            define_edges_by_node[src].append(edge)

    return node_map, out_adj, in_adj, define_edges_by_node


def node_display_name(node_id: str, node_map: Dict[str, Dict[str, Any]]) -> str:
    node = node_map.get(node_id)
    if node and node.get("name"):
        return str(node.get("name"))
    return node_name_from_id(node_id)


def node_kind(node_id: str, node_map: Dict[str, Dict[str, Any]]) -> str:
    node = node_map.get(node_id)
    if node and node.get("kind"):
        return str(node.get("kind"))
    if ":" in node_id:
        return node_id.split(":", 1)[0]
    return "unknown"


def resolve_candidates(
    query: str,
    scope_filter: Optional[str],
    node_map: Dict[str, Dict[str, Any]],
    define_edges_by_node: Dict[str, List[Dict[str, Any]]],
) -> List[Dict[str, Any]]:
    candidates: List[Dict[str, Any]] = []
    for node_id, node in node_map.items():
        kind = str(node.get("kind") or "")
        if kind not in ROOT_KINDS:
            continue

        name = str(node.get("name") or node_name_from_id(node_id))
        rank = match_rank(name, query)
        if rank is None:
            continue

        define_edges = define_edges_by_node.get(node_id, [])
        scope = resolve_node_scope(node, define_edges)
        if scope_filter and normalize_scope_string(scope) != normalize_scope_string(scope_filter):
            continue
        line = resolve_node_line(define_edges)
        candidates.append(
            {
                "id": node_id,
                "name": name,
                "kind": kind,
                "scope": scope,
                "line": line,
                "match_rank": rank,
                "has_define": bool(define_edges),
            }
        )

    candidates.sort(
        key=lambda row: (
            row["match_rank"],
            0 if row["has_define"] else 1,
            KIND_PRIORITY.get(row["kind"], 99),
            normalize_scope_string(row.get("scope")),
            row.get("line") if isinstance(row.get("line"), int) else 10**9,
            row["id"],
        )
    )
    return candidates


def print_ambiguity(candidates: Sequence[Dict[str, Any]], query: str, scope_filter: Optional[str]) -> None:
    scope_msg = f" with scope='{scope_filter}'" if scope_filter else ""
    eprint(f"Ambiguous variable '{query}'{scope_msg}. Multiple candidates found:")
    for idx, row in enumerate(candidates, start=1):
        scope = row.get("scope") or "(unknown)"
        line = row.get("line") if isinstance(row.get("line"), int) else "-"
        eprint(
            f"  {idx}. id={row['id']} kind={row['kind']} "
            f"scope={scope} line={line} name={row['name']}"
        )
    eprint("Provide `--scope` or `--node-id` to disambiguate.")


def read_snippet(file_path: str, line_no: int, cache: Dict[str, List[str]]) -> str:
    if not file_path or line_no <= 0:
        return ""
    try:
        if file_path not in cache:
            cache[file_path] = Path(file_path).read_text(encoding="utf-8", errors="replace").splitlines()
        lines = cache[file_path]
    except OSError:
        cache[file_path] = []
        lines = []
    if not lines:
        return ""
    idx = line_no - 1
    lo = max(0, idx - 1)
    hi = min(len(lines), idx + 2)
    return "\n".join(lines[lo:hi]).rstrip("\n")


def unique_list(values: Iterable[str]) -> List[str]:
    out: List[str] = []
    seen: Set[str] = set()
    for value in values:
        if not value or value in seen:
            continue
        seen.add(value)
        out.append(value)
    return out


def is_var_like(node_id: str, node_map: Dict[str, Dict[str, Any]]) -> bool:
    return node_kind(node_id, node_map) in VAR_LIKE_FOR_CONTEXT


def parse_call_arg_name(call_arg_name: str) -> Tuple[str, Optional[int]]:
    if "#" not in call_arg_name:
        return call_arg_name, None
    base, idx_str = call_arg_name.rsplit("#", 1)
    try:
        return base, int(idx_str)
    except ValueError:
        return call_arg_name, None


def build_level_contexts(
    level_node_ids: Sequence[str],
    level_edges: Sequence[Dict[str, Any]],
    node_map: Dict[str, Dict[str, Any]],
    snippet_cache: Dict[str, List[str]],
) -> List[Dict[str, Any]]:
    groups: Dict[Tuple[str, int, str], List[Dict[str, Any]]] = defaultdict(list)
    for edge in level_edges:
        file_path = str(edge.get("file") or "")
        line = int(edge.get("line") or 0)
        scope = str(edge.get("scope") or "")
        groups[(file_path, line, scope)].append(edge)

    level_node_set = set(level_node_ids)
    contexts: List[Dict[str, Any]] = []
    for (file_path, line, scope), edges in sorted(groups.items(), key=lambda item: (item[0][0], item[0][1], item[0][2])):
        context_nodes: Set[str] = set()
        for edge in edges:
            src = edge.get("source")
            tgt = edge.get("target")
            if isinstance(src, str):
                context_nodes.add(src)
            if isinstance(tgt, str):
                context_nodes.add(tgt)

        focus = unique_list(
            node_display_name(node_id, node_map)
            for node_id in context_nodes
            if node_id in level_node_set and is_var_like(node_id, node_map)
        )
        related = unique_list(
            node_display_name(node_id, node_map)
            for node_id in context_nodes
            if node_id not in level_node_set and is_var_like(node_id, node_map)
        )

        snippet = ""
        if line > 0:
            snippet = read_snippet(file_path, line, snippet_cache)

        contexts.append(
            {
                "file_path": file_path,
                "line_numbers": [line] if line > 0 else [],
                "focus_vars": focus,
                "related_vars": related,
                "source_types": sorted(unique_list(str(edge.get("relation") or "") for edge in edges)),
                "paragraph_names": sorted(unique_list(str(edge.get("scope") or "") for edge in edges)),
                "snippets": [snippet] if snippet else [],
            }
        )

    return contexts


def traverse_levels(
    direction: str,
    roots: Sequence[str],
    node_map: Dict[str, Dict[str, Any]],
    out_adj: Dict[str, List[Dict[str, Any]]],
    in_adj: Dict[str, List[Dict[str, Any]]],
    max_depth: Optional[int],
    snippet_cache: Dict[str, List[str]],
) -> Tuple[List[Dict[str, Any]], Set[str], List[Dict[str, Any]]]:
    visited_nodes: Set[str] = set(roots)
    visited_edge_keys: Set[Tuple[Any, ...]] = set()
    traversed_edges: List[Dict[str, Any]] = []

    frontier: Deque[str] = deque(roots)
    depth = 0
    levels: List[Dict[str, Any]] = []

    while frontier and (max_depth is None or depth < max_depth):
        depth += 1
        level_nodes = list(frontier)
        frontier.clear()
        next_nodes: List[str] = []
        level_edges: List[Dict[str, Any]] = []

        for node_id in level_nodes:
            candidates = out_adj.get(node_id, []) if direction == "forward" else in_adj.get(node_id, [])
            for edge in candidates:
                key = edge_key(edge)
                if key in visited_edge_keys:
                    continue
                visited_edge_keys.add(key)
                level_edges.append(edge)
                traversed_edges.append(edge)

                neighbor = edge.get("target") if direction == "forward" else edge.get("source")
                if isinstance(neighbor, str) and neighbor and neighbor not in visited_nodes:
                    visited_nodes.add(neighbor)
                    next_nodes.append(neighbor)

        level_edges.sort(
            key=lambda edge: (
                str(edge.get("file") or ""),
                int(edge.get("line") or 0),
                str(edge.get("relation") or ""),
                str(edge.get("source") or ""),
                str(edge.get("target") or ""),
                str(edge.get("statement_id") or ""),
                str(edge.get("expression") or ""),
            )
        )

        levels.append(
            {
                "direction": direction,
                "level": depth,
                "variables": unique_list(
                    node_display_name(node_id, node_map)
                    for node_id in level_nodes
                    if is_var_like(node_id, node_map)
                ),
                "contexts": build_level_contexts(level_nodes, level_edges, node_map, snippet_cache),
            }
        )

        for node_id in next_nodes:
            frontier.append(node_id)

    return levels, visited_nodes, traversed_edges


def extract_dependent_variables(
    roots: Sequence[str],
    node_map: Dict[str, Dict[str, Any]],
    out_adj: Dict[str, List[Dict[str, Any]]],
    in_adj: Dict[str, List[Dict[str, Any]]],
    define_edges_by_node: Dict[str, List[Dict[str, Any]]],
) -> List[Dict[str, Any]]:
    records: Dict[Tuple[str, str, str], Dict[str, Any]] = {}
    root_set = set(roots)

    for root in roots:
        for edge in in_adj.get(root, []):
            src = edge.get("source")
            if not isinstance(src, str) or src in root_set:
                continue
            kind = node_kind(src, node_map)
            if kind not in ROOT_KINDS:
                continue
            node = node_map.get(src, {})
            define_edges = define_edges_by_node.get(src, [])
            scope = resolve_node_scope(node, define_edges) or str(edge.get("scope") or "")
            name = node_display_name(src, node_map)
            key = (name, kind, normalize_scope_string(scope))
            line = edge.get("line") if isinstance(edge.get("line"), int) and edge.get("line", 0) > 0 else resolve_node_line(define_edges)
            row = {
                "variable": name,
                "kind": kind,
                "scope": scope or None,
                "line": line,
                "relation": edge.get("relation"),
                "direction": "backward",
                "reason": f"1-hop backward dependency via {edge.get('relation')}",
            }
            existing = records.get(key)
            if existing is None or (isinstance(line, int) and (existing.get("line") is None or line < existing["line"])):
                records[key] = row

        for edge in out_adj.get(root, []):
            tgt = edge.get("target")
            if not isinstance(tgt, str) or tgt in root_set:
                continue
            kind = node_kind(tgt, node_map)
            if kind not in ROOT_KINDS:
                continue
            node = node_map.get(tgt, {})
            define_edges = define_edges_by_node.get(tgt, [])
            scope = resolve_node_scope(node, define_edges) or str(edge.get("scope") or "")
            name = node_display_name(tgt, node_map)
            key = (name, kind, normalize_scope_string(scope))
            line = edge.get("line") if isinstance(edge.get("line"), int) and edge.get("line", 0) > 0 else resolve_node_line(define_edges)
            row = {
                "variable": name,
                "kind": kind,
                "scope": scope or None,
                "line": line,
                "relation": edge.get("relation"),
                "direction": "forward",
                "reason": f"1-hop forward dependency via {edge.get('relation')}",
            }
            existing = records.get(key)
            if existing is None or (isinstance(line, int) and (existing.get("line") is None or line < existing["line"])):
                records[key] = row

    rows = list(records.values())
    rows.sort(
        key=lambda row: (
            str(row.get("variable") or ""),
            str(row.get("kind") or ""),
            normalize_scope_string(row.get("scope")),
            row.get("line") if isinstance(row.get("line"), int) else 10**9,
            str(row.get("direction") or ""),
            str(row.get("relation") or ""),
        )
    )
    return rows


def extract_dependent_files(
    traversed_edges: Sequence[Dict[str, Any]],
    call_graph_edges: Sequence[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    rows: Dict[Tuple[str, str, int, str], Dict[str, Any]] = {}

    traversed_scope_line: Set[Tuple[str, int]] = set()
    for edge in traversed_edges:
        scope = str(edge.get("scope") or "")
        line = edge.get("line")
        if isinstance(line, int) and line > 0 and scope:
            traversed_scope_line.add((scope, line))

        callee = edge.get("callee")
        if callee:
            line_value = line if isinstance(line, int) else 0
            key = (str(callee), scope, int(line_value), "arg_bind_callee")
            rows[key] = {
                "target": str(callee),
                "called_from_scope": scope or None,
                "line": line_value if line_value > 0 else None,
                "type": "arg_bind_callee",
                "status": "resolved",
            }

    for edge in call_graph_edges:
        source = str(edge.get("source") or "")
        line = edge.get("line")
        if not source or not isinstance(line, int) or line <= 0:
            continue
        if (source, line) not in traversed_scope_line:
            continue
        target = str(edge.get("target") or "")
        if not target:
            continue
        call_type = str(edge.get("call_type") or "call")
        key = (target, source, line, call_type)
        rows[key] = {
            "target": target,
            "called_from_scope": source,
            "line": line,
            "type": call_type,
            "status": "resolved",
        }

    output = list(rows.values())
    output.sort(
        key=lambda row: (
            str(row.get("target") or ""),
            normalize_scope_string(row.get("called_from_scope")),
            row.get("line") if isinstance(row.get("line"), int) else 10**9,
            str(row.get("type") or ""),
        )
    )
    return output


def extract_argument_bindings(
    roots: Sequence[str],
    node_map: Dict[str, Dict[str, Any]],
    out_adj: Dict[str, List[Dict[str, Any]]],
    in_adj: Dict[str, List[Dict[str, Any]]],
) -> List[Dict[str, Any]]:
    rows: Dict[Tuple[str, str, str, int, str], Dict[str, Any]] = {}
    root_set = set(roots)

    def add_binding(edge: Dict[str, Any], neighbor_id: str, direction: str) -> None:
        kind = node_kind(neighbor_id, node_map)
        if kind != "call_arg":
            return

        call_arg_name = node_display_name(neighbor_id, node_map)
        call_name, argument_index = parse_call_arg_name(call_arg_name)
        scope = str(edge.get("scope") or "")
        line_raw = edge.get("line")
        line_value = int(line_raw) if isinstance(line_raw, int) and line_raw > 0 else 0
        relation = str(edge.get("relation") or "")
        file_path = str(edge.get("file") or "")
        key = (call_arg_name, direction, scope, line_value, relation)

        row = {
            "call_arg": call_arg_name,
            "call": call_name,
            "argument_index": argument_index,
            "direction": direction,
            "scope": scope or None,
            "line": line_value if line_value > 0 else None,
            "relation": relation or None,
            "file_path": file_path or None,
            "reason": f"1-hop {direction} argument binding via {relation or 'edge'}",
        }

        existing = rows.get(key)
        if existing is None:
            rows[key] = row

    for root in roots:
        for edge in in_adj.get(root, []):
            src = edge.get("source")
            if not isinstance(src, str) or src in root_set:
                continue
            add_binding(edge, src, "backward")

        for edge in out_adj.get(root, []):
            tgt = edge.get("target")
            if not isinstance(tgt, str) or tgt in root_set:
                continue
            add_binding(edge, tgt, "forward")

    output = list(rows.values())
    output.sort(
        key=lambda row: (
            str(row.get("call") or ""),
            row.get("argument_index") if isinstance(row.get("argument_index"), int) else 10**9,
            normalize_scope_string(row.get("scope")),
            row.get("line") if isinstance(row.get("line"), int) else 10**9,
            str(row.get("direction") or ""),
            str(row.get("relation") or ""),
        )
    )
    return output


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Trace C++ variable lineage from blueprint JSON.")
    parser.add_argument("--cpp-json", required=True, help="Path to .cpp.json blueprint")
    parser.add_argument("--var", required=True, help="Variable name to trace")
    parser.add_argument("--node-id", help="Explicit root node id (overrides variable matching)")
    parser.add_argument("--scope", help="Scope filter for ambiguous variable names")
    parser.add_argument(
        "--direction",
        default="both",
        choices=["backward", "forward", "both"],
        help="Traversal direction (default: both)",
    )
    parser.add_argument(
        "--max-depth",
        type=int,
        default=None,
        help="Maximum traversal depth per direction (default: unlimited)",
    )
    parser.add_argument("--out", help="Output JSON path (default: trace_<var>.json)")
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)

    if args.max_depth is not None and args.max_depth < 0:
        eprint("--max-depth must be >= 0")
        return EXIT_INPUT_ERROR

    input_path = Path(args.cpp_json)
    payload = load_blueprint(input_path)
    nodes, edges_raw = validate_lineage_shape(payload)
    edges = dedupe_edges(edges_raw)

    node_map, out_adj, in_adj, define_edges_by_node = build_index(nodes, edges)

    if args.node_id:
        if args.node_id not in node_map:
            eprint(f"--node-id not found in variable_lineage.nodes: {args.node_id}")
            return EXIT_NO_MATCH
        selected_candidates = [
            {
                "id": args.node_id,
                "name": node_display_name(args.node_id, node_map),
                "kind": node_kind(args.node_id, node_map),
                "scope": resolve_node_scope(node_map.get(args.node_id, {}), define_edges_by_node.get(args.node_id, [])),
                "line": resolve_node_line(define_edges_by_node.get(args.node_id, [])),
                "match_rank": None,
                "has_define": bool(define_edges_by_node.get(args.node_id)),
            }
        ]
    else:
        candidates = resolve_candidates(args.var, args.scope, node_map, define_edges_by_node)
        if not candidates:
            scope_msg = f" with scope='{args.scope}'" if args.scope else ""
            eprint(f"No matching variable nodes found for '{args.var}'{scope_msg}.")
            return EXIT_NO_MATCH
        if len(candidates) > 1:
            print_ambiguity(candidates, args.var, args.scope)
            return EXIT_AMBIGUOUS
        selected_candidates = [candidates[0]]

    roots = [selected_candidates[0]["id"]]
    snippet_cache: Dict[str, List[str]] = {}

    levels: Dict[str, Any] = {
        "root": [
            {
                "direction": "root",
                "variables": unique_list(node_display_name(root, node_map) for root in roots),
                "contexts": [],
            }
        ],
        "backward": [],
        "forward": [],
    }

    traversed_edges_all: List[Dict[str, Any]] = []
    visited_nodes_all: Set[str] = set(roots)

    directions: List[str]
    if args.direction == "both":
        directions = ["backward", "forward"]
    else:
        directions = [args.direction]

    for direction in directions:
        dir_levels, dir_visited_nodes, dir_traversed_edges = traverse_levels(
            direction=direction,
            roots=roots,
            node_map=node_map,
            out_adj=out_adj,
            in_adj=in_adj,
            max_depth=args.max_depth,
            snippet_cache=snippet_cache,
        )
        levels[direction] = dir_levels
        visited_nodes_all.update(dir_visited_nodes)
        traversed_edges_all.extend(dir_traversed_edges)

    traversed_edges_all = dedupe_edges(traversed_edges_all)

    dependent_variables = extract_dependent_variables(
        roots=roots,
        node_map=node_map,
        out_adj=out_adj,
        in_adj=in_adj,
        define_edges_by_node=define_edges_by_node,
    )
    argument_bindings = extract_argument_bindings(
        roots=roots,
        node_map=node_map,
        out_adj=out_adj,
        in_adj=in_adj,
    )
    call_graph = payload.get("call_graph") if isinstance(payload.get("call_graph"), dict) else {}
    call_graph_edges = call_graph.get("edges") if isinstance(call_graph.get("edges"), list) else []
    dependent_files = extract_dependent_files(traversed_edges_all, call_graph_edges)

    output = {
        "keyword": args.var,
        "root_nodes": roots,
        "resolved_candidates": selected_candidates,
        "config": {
            "cpp_json": str(input_path),
            "direction": args.direction,
            "max_depth": args.max_depth,
            "scope": args.scope,
            "node_id": args.node_id,
        },
        "levels": levels,
        "dependent_variables": dependent_variables,
        "argument_bindings": argument_bindings,
        "dependent_files": dependent_files,
        "stats": {
            "nodes_total": len(node_map),
            "edges_total_raw": len(edges_raw),
            "edges_total_dedup": len(edges),
            "matched_roots": len(roots),
            "visited_nodes": len(visited_nodes_all),
            "visited_edges": len(traversed_edges_all),
            "argument_bindings": len(argument_bindings),
        },
    }

    out_path = Path(args.out) if args.out else Path(f"trace_{args.var}.json")
    try:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    except OSError as exc:
        eprint(f"Failed to write output file: {out_path} ({exc})")
        return EXIT_INPUT_ERROR

    print(f"Wrote: {out_path}")
    return EXIT_SUCCESS


if __name__ == "__main__":
    raise SystemExit(main())
