#!/usr/bin/env python3
"""
find_call_conditions.py

Given a caller file and a callee file, list every call site in the caller
that targets the callee AND the conditions under which each call fires.

Supports all four cross-file patterns (auto-detected from blueprints):
  ASM  → ASM
  ASM  → C++
  C++  → ASM
  C++  → C++

Call-site discovery reuses cross_file_bridge.find_*_callers().
Condition extraction is added here:

  ASM caller  → walk backward in the call's block.flow to find the nearest
                guard BRANCH (BE/BNE/BZ/BNZ/BH/BL/BNH/BNL/BM/BP/BC...) and
                its TRIGGER (CLC/CLI/TM/OC/LTR/C/CR/CH/CL/CLR/CP). If the
                branch target is not the call's block, the call fires under
                the INVERSE of the branch condition. Block-level entry
                conditions (incoming_branches) are also included.

  C++ caller  → blueprint has no CFG, so read the source and walk backward
                from the call line tracking brace depth, capturing every
                enclosing 'if (...)' header (innermost first).

Usage:
  python find_call_conditions.py <caller_stem> <callee_stem> [options]

Options:
  --blueprint-dir DIR   Directory containing .cpp.json / .asm.json blueprints
  --asm-dir DIR         Directory containing .asm / .cpp sources
  --output FILE         Output JSON path (default <caller>_calls_<callee>_conditions.json)
  --max-guards N        Max number of guards to walk back per call site (default 4)
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from blueprint_io import iter_flow, load_blueprint
from cross_file_bridge import (
    _discover_asm_dir,
    _discover_blueprint_dir,
    find_asm_callers,
    find_asm_to_cpp_callers,
    find_cpp_callers,
    find_cpp_to_cpp_callers,
)


# ---------------------------------------------------------------------------
# ASM condition-code semantics
# ---------------------------------------------------------------------------

# Map branch mnemonic → human-readable condition that makes the branch TAKE.
# Includes both short (B*) and long-jump (J*) variants; HLASM uses both.
BRANCH_COND: Dict[str, str] = {
    "B":   "always",   "J":   "always",
    "BR":  "always",   "JR":  "always",
    "NOP": "never",
    "BE":  "equal",    "JE":  "equal",
    "BNE": "not equal","JNE": "not equal",
    "BZ":  "zero",     "JZ":  "zero",
    "BNZ": "non-zero", "JNZ": "non-zero",
    "BL":  "low",      "JL":  "low",
    "BNL": "not low (high or equal)",  "JNL": "not low (high or equal)",
    "BH":  "high",     "JH":  "high",
    "BNH": "not high (low or equal)",  "JNH": "not high (low or equal)",
    "BM":  "minus",    "JM":  "minus",
    "BNM": "not minus","JNM": "not minus",
    "BP":  "plus",     "JP":  "plus",
    "BNP": "not plus", "JNP": "not plus",
    "BO":  "overflow", "JO":  "overflow",
    "BNO": "no overflow",  "JNO": "no overflow",
    # Index-style jumps (Z/Architecture). These compare an index register to a
    # limit (after auto-increment) and branch when the comparison holds.
    "JXH":  "index > limit",   "JXLE": "index <= limit",
    "JXHG": "index >= limit",  "JXLEG": "index <= limit",
    "BXH":  "index > limit",   "BXLE": "index <= limit",
    "BXHG": "index >= limit",  "BXLEG": "index <= limit",
}

NEGATE: Dict[str, str] = {
    "always": "never", "never": "always",
    "equal": "not equal", "not equal": "equal",
    "zero": "non-zero", "non-zero": "zero",
    "low": "not low (high or equal)", "not low (high or equal)": "low",
    "high": "not high (low or equal)", "not high (low or equal)": "high",
    "minus": "not minus", "not minus": "minus",
    "plus": "not plus", "not plus": "plus",
    "overflow": "no overflow", "no overflow": "overflow",
}

# BC <mask>, <addr> — mask bits: 8=zero/equal, 4=low/minus, 2=high/plus, 1=overflow.
BC_MASK_COND: Dict[int, str] = {
    0:  "never",
    8:  "zero/equal",
    4:  "low/minus",
    2:  "high/plus",
    1:  "overflow",
    12: "zero or low",
    10: "zero or high",
    14: "not overflow (zero/low/high)",
    7:  "non-zero (low/high/overflow)",
    13: "not high",
    11: "not low",
    15: "always",
}

# Canonical TRIGGER_INST from backward_traversal/glossary/instructions.py:10
# is {CLC, CLI, TM, CP, LTR, C, CR, CH, CL, CLR}. We extend it with idioms
# that also set the condition code and are routinely used as guards in
# real HLASM (TMH/TML — TM variants; OC/NC/XC self-test for zero; TR/TRT
# translate-and-test; LTGR/LCR — long load-and-test; ICM — insert-under-mask
# also sets CC). Kept as a SUPERSET so we don't miss real guards.
TRIGGER_INST = {
    # canonical (backward_traversal/glossary/instructions.py:10)
    "CLC", "CLI", "TM", "CP", "LTR", "C", "CR", "CH", "CL", "CLR",
    # extensions: variants and idioms observed before real branch sites
    "TMH", "TML", "OC", "NC", "XC",                     # bitwise / self-test
    "TR", "TRT",                                         # translate-and-test
    "TP",                                                # test-packed (CC: -/0/+ / bad)
    "LTGR", "LTGFR", "LCR", "LCGR", "LNR", "LPR",        # load-and-test variants
    "ICM",                                               # insert under mask (CC set)
    "CDS", "CLM", "CGR", "CGRL", "CLGR", "CGHI", "CHI", "CGFI",  # extra compares
}

# Canonical BRANCH_INST plus the variants we observe. BC/BRC carry a mask
# operand; BCR/BCTR/BRCT are register-form and counting branches.
BRANCH_INST = set(BRANCH_COND.keys()) | {
    "BC", "BCR", "BCT", "BCTR", "BRC", "BRCT",
    # long-jump (relative) forms — mirror BE/BNE/BZ/...
    "J", "JE", "JNE", "JZ", "JNZ", "JH", "JNH", "JL", "JNL",
    "JM", "JNM", "JO", "JNO", "JP", "JNP", "JXHG", "JXLE",
}


def _branch_condition(inst: str, args: List[str]) -> str:
    """Return a human-readable condition for the given branch instruction."""
    if inst in BRANCH_COND:
        return BRANCH_COND[inst]
    if inst in ("BC", "BRC") and args:
        try:
            mask = int(args[0])
            return BC_MASK_COND.get(mask, f"mask={mask}")
        except (TypeError, ValueError):
            pass
    if inst in ("BCT", "BCTR", "BRCT"):
        return "count != 0 after decrement"
    return f"{inst}-condition"


def _branch_target(inst: str, args: List[str]) -> Optional[str]:
    """Extract the branch target label (last operand for most; arg[1] for BC)."""
    if not args:
        return None
    if inst in ("BC", "BRC") and len(args) >= 2:
        return str(args[1])
    return str(args[-1])


# ---------------------------------------------------------------------------
# ASM condition extraction
# ---------------------------------------------------------------------------

def _build_block_index(asm_bp: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    return {b["id"]: b for b in asm_bp.get("blocks", []) if b.get("id")}


def _find_block_for_line(asm_bp: Dict[str, Any], line_no: int) -> Optional[Dict[str, Any]]:
    for b in asm_bp.get("blocks", []):
        s = b.get("start_line") or 0
        e = b.get("end_line") or 0
        if s and e and s <= line_no <= e:
            return b
    return None


def _label_to_block(asm_bp: Dict[str, Any], label: str) -> Optional[str]:
    """Resolve a branch-target label to a block id, if possible."""
    if not label:
        return None
    norm = label.strip().upper()
    for b in asm_bp.get("blocks", []):
        if (b.get("id") or "").upper() == norm:
            return b["id"]
    for sub in asm_bp.get("subroutines", []) or []:
        if (sub.get("id") or sub.get("name") or "").upper() == norm:
            entry = sub.get("entry_block") or sub.get("id")
            if entry:
                return entry
    return None


def _asm_guards_for_call(
    asm_bp: Dict[str, Any],
    block: Dict[str, Any],
    call_line: int,
    max_guards: int,
) -> List[Dict[str, Any]]:
    """Walk backward from call_line in block.flow, collecting guard pairs."""
    guards: List[Dict[str, Any]] = []
    flow = list(iter_flow(block))
    # Find entries strictly before the call line, in reverse order.
    prior = [e for e in flow if (e.get("line") or 0) < call_line]
    prior.sort(key=lambda e: e.get("line") or 0, reverse=True)

    i = 0
    while i < len(prior) and len(guards) < max_guards:
        entry = prior[i]
        inst = (entry.get("inst") or "").upper()
        args = entry.get("args") or []

        if inst in BRANCH_INST:
            tgt_label = _branch_target(inst, args)
            tgt_block = _label_to_block(asm_bp, tgt_label) if tgt_label else None
            # Default to "branches away" (the common case for a guard preceding
            # a call). Only treat it as in-block if we positively resolved the
            # target to this same block.
            branches_away = not (tgt_block and tgt_block == block.get("id"))
            cond_true = _branch_condition(inst, args)
            # Pair with a TRIGGER on the line(s) immediately above.
            trigger: Optional[Dict[str, Any]] = None
            j = i + 1
            while j < len(prior) and j < i + 4:
                t = prior[j]
                t_inst = (t.get("inst") or "").upper()
                if t_inst in TRIGGER_INST:
                    trigger = {
                        "line": t.get("line"),
                        "inst": t_inst,
                        "args": t.get("args") or [],
                    }
                    break
                if t_inst in BRANCH_INST:
                    break  # another branch — stop searching for trigger
                j += 1

            call_fires_when = (
                NEGATE.get(cond_true, f"not ({cond_true})") if branches_away
                else cond_true
            )
            guards.append({
                "guard_branch": {
                    "line": entry.get("line"),
                    "inst": inst,
                    "args": args,
                    "target_label": tgt_label,
                    "target_block": tgt_block,
                    "branches_away_from_call": branches_away,
                    "condition_when_taken": cond_true,
                },
                "trigger": trigger,
                "call_fires_when": call_fires_when,
            })
            # After consuming a guard, keep walking back to find earlier nested guards.
            i = j + 1 if trigger else i + 1
            continue
        i += 1

    return guards


def _block_entry_conditions(
    asm_bp: Dict[str, Any],
    block: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Return the block's incoming_branches so callers can see how this block
    can be entered (FALLTHROUGH vs BRANCH from predecessor X)."""
    out: List[Dict[str, Any]] = []
    for ib in block.get("incoming_branches") or []:
        out.append({
            "from_block": ib.get("source"),
            "type": ib.get("type"),
        })
    return out


def annotate_asm_call_site(
    asm_bp: Dict[str, Any],
    site: Dict[str, Any],
    max_guards: int,
) -> Dict[str, Any]:
    """Add 'guards' and 'block_entry_conditions' fields to an ASM call site."""
    line = site.get("line")
    block = _find_block_for_line(asm_bp, line) if line else None
    if block is None:
        return {**site, "block_id": None, "guards": [], "block_entry_conditions": []}

    guards = _asm_guards_for_call(asm_bp, block, line, max_guards)
    entries = _block_entry_conditions(asm_bp, block)
    return {
        **site,
        "block_id": block.get("id"),
        "block_range": [block.get("start_line"), block.get("end_line")],
        "guards": guards,
        "block_entry_conditions": entries,
        "unconditional": len(guards) == 0,
    }


# ---------------------------------------------------------------------------
# C++ condition extraction (source-based, brace tracking)
# ---------------------------------------------------------------------------

_IF_HEAD_RE = re.compile(r"\b(if|while|for)\s*\(")


def _strip_comments_strings(line: str) -> str:
    """Best-effort: remove // line comments and string/char literals."""
    out = []
    i = 0
    in_str = None
    while i < len(line):
        ch = line[i]
        if in_str:
            if ch == "\\" and i + 1 < len(line):
                i += 2
                continue
            if ch == in_str:
                in_str = None
            i += 1
            continue
        if ch == "/" and i + 1 < len(line) and line[i + 1] == "/":
            break
        if ch in ('"', "'"):
            in_str = ch
            i += 1
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def _strip_comments_only(line: str) -> str:
    """Remove // line comments but KEEP string/char literals.

    Used for the human-readable condition text so a comparison like
    ``lstknpoa == 'Y'`` keeps its literal, while paren/brace counting still
    uses the fully-stripped form (so a ``)`` inside a string never miscounts).
    """
    out = []
    i = 0
    in_str = None
    while i < len(line):
        ch = line[i]
        if in_str:
            out.append(ch)
            if ch == "\\" and i + 1 < len(line):
                out.append(line[i + 1])
                i += 2
                continue
            if ch == in_str:
                in_str = None
            i += 1
            continue
        if ch == "/" and i + 1 < len(line) and line[i + 1] == "/":
            break
        if ch in ('"', "'"):
            in_str = ch
            out.append(ch)
            i += 1
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def _count_braces(line: str) -> Tuple[int, int]:
    cleaned = _strip_comments_strings(line)
    return cleaned.count("{"), cleaned.count("}")


def _extract_if_header(lines: List[str], idx: int) -> Optional[Dict[str, Any]]:
    """If lines[idx] (or a span ending at idx) starts an `if (...)` whose body
    opens at the next `{`, return the header text and line. Walks back to glue
    multi-line headers like `if (a &&\n    b)`."""
    cleaned = _strip_comments_strings(lines[idx])
    m = _IF_HEAD_RE.search(cleaned)
    if m:
        depth = 0
        text_parts: List[str] = []
        for j in range(idx, min(idx + 10, len(lines))):
            seg = _strip_comments_strings(lines[j])          # for paren counting
            text_parts.append(_strip_comments_only(lines[j]).strip())  # display: keep literals
            for ch in seg:
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                    if depth == 0:
                        return {
                            "line": idx + 1,
                            "keyword": m.group(1),
                            "text": " ".join(text_parts).strip(),
                        }
        return {
            "line": idx + 1,
            "keyword": m.group(1),
            "text": " ".join(text_parts).strip(),
        }
    # Look upward for a multi-line header continued onto idx.
    for back in range(1, 6):
        k = idx - back
        if k < 0:
            break
        cleaned_k = _strip_comments_strings(lines[k])
        m2 = _IF_HEAD_RE.search(cleaned_k)
        if m2:
            joined = " ".join(
                _strip_comments_only(lines[x]).strip() for x in range(k, idx + 1)
            )
            return {"line": k + 1, "keyword": m2.group(1), "text": joined.strip()}
    return None


def cpp_conditions_for_call(src_path: Path, call_line: int) -> List[Dict[str, Any]]:
    """Walk backward from call_line tracking brace depth; collect every
    enclosing if/while/for header (innermost first)."""
    try:
        lines = src_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []
    if not (1 <= call_line <= len(lines)):
        return []

    # depth = number of unmatched '}' walked past going backward; when we hit
    # a '{' with depth == 0, that '{' opens the enclosing scope.
    depth = 0
    conds: List[Dict[str, Any]] = []
    for i in range(call_line - 2, -1, -1):  # start one line above the call
        opens, closes = _count_braces(lines[i])
        # process right-to-left within the line: each '}' adds, each '{' subtracts.
        # We don't need exact positions — net effect across the line is enough
        # for our heuristic of finding enclosing scopes.
        net = closes - opens
        if net > 0:
            depth += net
            continue
        if net < 0:
            opens_consumed = -net
            for _ in range(opens_consumed):
                if depth == 0:
                    hdr = _extract_if_header(lines, i)
                    if hdr:
                        conds.append(hdr)
                else:
                    depth -= 1
        # net == 0 → balanced line, skip.
    return conds  # innermost-first ordering


def annotate_cpp_call_site(
    site: Dict[str, Any],
    asm_dir: Optional[Path],
) -> Dict[str, Any]:
    file_field = site.get("file", "")
    line = site.get("line")
    src = Path(file_field) if file_field else None
    if src and not src.exists() and asm_dir:
        src = asm_dir / Path(file_field).name
    conds: List[Dict[str, Any]] = []
    if src and src.exists() and line:
        conds = cpp_conditions_for_call(src, line)
    return {
        **site,
        "enclosing_conditions": conds,
        "unconditional": len(conds) == 0,
    }


# ---------------------------------------------------------------------------
# Pattern routing
# ---------------------------------------------------------------------------

def annotate_asm_caller_sites(
    caller_stem: str,
    sites: List[Dict[str, Any]],
    blueprint_dir: Path,
    max_guards: int,
) -> List[Dict[str, Any]]:
    bp_path = blueprint_dir / f"{caller_stem}.asm.json"
    bp = load_blueprint(bp_path)
    return [annotate_asm_call_site(bp, s, max_guards) for s in sites]


def annotate_cpp_caller_sites(
    sites: List[Dict[str, Any]],
    asm_dir: Optional[Path],
) -> List[Dict[str, Any]]:
    return [annotate_cpp_call_site(s, asm_dir) for s in sites]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        description=(
            "List call sites from caller to callee and the conditions under "
            "which each call fires. Auto-detects pattern from blueprints."
        )
    )
    ap.add_argument("caller_stem")
    ap.add_argument("callee_stem")
    ap.add_argument("--blueprint-dir", metavar="DIR")
    ap.add_argument("--asm-dir", metavar="DIR")
    ap.add_argument("--output", metavar="FILE")
    ap.add_argument("--max-guards", type=int, default=4)
    args = ap.parse_args()

    if args.blueprint_dir:
        bp_dir = Path(args.blueprint_dir)
    else:
        bp_dir = _discover_blueprint_dir()
        if bp_dir is None:
            print("ERROR: could not discover blueprint dir; pass --blueprint-dir",
                  file=sys.stderr)
            return 1

    asm_dir: Optional[Path] = (
        Path(args.asm_dir) if args.asm_dir else _discover_asm_dir(bp_dir)
    )
    print(f"[blueprints] {bp_dir}", file=sys.stderr)
    if asm_dir:
        print(f"[source]     {asm_dir}", file=sys.stderr)

    caller_cpp = bp_dir / f"{args.caller_stem}.cpp.json"
    caller_asm = bp_dir / f"{args.caller_stem}.asm.json"
    callee_cpp = bp_dir / f"{args.callee_stem}.cpp.json"
    callee_asm = bp_dir / f"{args.callee_stem}.asm.json"

    result: Dict[str, Any] = {
        "caller": args.caller_stem,
        "callee": args.callee_stem,
    }

    if caller_asm.exists() and callee_cpp.exists() and not callee_asm.exists():
        # ASM → C++
        sites = find_asm_to_cpp_callers(
            args.caller_stem, args.callee_stem, bp_dir, asm_dir
        )
        annotated = annotate_asm_caller_sites(
            args.caller_stem, sites, bp_dir, args.max_guards
        )
        result["pattern"] = "ASM->C++"
        result["call_sites"] = annotated

    elif caller_asm.exists() and callee_asm.exists():
        # ASM → ASM
        sites = find_asm_callers(
            args.caller_stem, args.callee_stem, bp_dir, asm_dir
        )
        annotated = annotate_asm_caller_sites(
            args.caller_stem, sites, bp_dir, args.max_guards
        )
        result["pattern"] = "ASM->ASM"
        result["call_sites"] = annotated

    elif caller_cpp.exists() and callee_cpp.exists():
        # C++ → C++
        sites = find_cpp_to_cpp_callers(
            args.caller_stem, args.callee_stem, bp_dir, asm_dir
        )
        annotated = annotate_cpp_caller_sites(sites, asm_dir)
        result["pattern"] = "C++->C++"
        result["call_sites"] = annotated

    elif caller_cpp.exists() and callee_asm.exists():
        # C++ → ASM
        sites = find_cpp_callers(args.caller_stem, args.callee_stem, bp_dir)
        # find_cpp_callers omits file/line context; refetch from blueprint.
        bp = load_blueprint(caller_cpp)
        callee_upper = args.callee_stem.upper()
        rich_sites: List[Dict[str, Any]] = []
        for edge in bp.get("call_graph", {}).get("edges", []):
            if (edge.get("target") or "").upper() == callee_upper:
                rich_sites.append({
                    "function": edge.get("source"),
                    "line": edge.get("line"),
                    "file": edge.get("file"),
                    "instruction": edge.get("instruction"),
                    "call_type": edge.get("call_type"),
                })
        annotated = annotate_cpp_caller_sites(rich_sites, asm_dir)
        result["pattern"] = "C++->ASM"
        result["call_sites"] = annotated

    else:
        print(
            f"ERROR: no blueprint pair found for "
            f"caller='{args.caller_stem}' callee='{args.callee_stem}' in {bp_dir}",
            file=sys.stderr,
        )
        return 1

    if not result["call_sites"]:
        print(
            f"No calls from '{args.caller_stem}' to '{args.callee_stem}' found.",
            file=sys.stderr,
        )

    # Summary stats
    n = len(result["call_sites"])
    n_uncond = sum(1 for s in result["call_sites"] if s.get("unconditional"))
    result["summary"] = {
        "total_call_sites": n,
        "unconditional_calls": n_uncond,
        "conditional_calls": n - n_uncond,
    }

    out_path = (
        Path(args.output)
        if args.output
        else Path(f"{args.caller_stem}_calls_{args.callee_stem}_conditions.json")
    )
    out_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(
        f"[{result['pattern']}] {n} call site(s) — "
        f"{n - n_uncond} conditional, {n_uncond} unconditional. "
        f"Wrote {out_path}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
