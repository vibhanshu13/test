"""Track section boundaries and nesting in assembly code."""

from dataclasses import dataclass
from typing import Optional, List


@dataclass
class Section:
    """Represents a section (CSECT, DSECT, RSECT) with boundaries."""
    name: str
    section_type: str  # "CSECT", "DSECT", "RSECT"
    start_line: int
    end_line: Optional[int] = None
    file: str = ""


class SectionTracker:
    """Track section boundaries and nesting.

    Sections can nest (e.g., DSECT inside CSECT).
    Maintains a stack for proper nesting tracking.
    """

    def __init__(self):
        self.sections: dict[str, Section] = {}
        self.section_stack: List[Section] = []
        self.current_section: Optional[str] = None
        self.current_section_type: Optional[str] = None

    def enter_section(self, name: str, section_type: str, line: int, file: str):
        """Enter a new section.

        Args:
            name: Section name
            section_type: "CSECT", "DSECT", or "RSECT"
            line: Line number where section starts
            file: Source file
        """
        section = Section(
            name=name,
            section_type=section_type,
            start_line=line,
            file=file
        )

        self.sections[name] = section
        self.section_stack.append(section)
        self.current_section = name
        self.current_section_type = section_type

    def exit_section(self, line: int):
        """Exit the current section.

        Args:
            line: Line number where section ends
        """
        if not self.section_stack:
            return

        section = self.section_stack.pop()
        section.end_line = line

        # Update current section to parent (if any)
        if self.section_stack:
            parent = self.section_stack[-1]
            self.current_section = parent.name
            self.current_section_type = parent.section_type
        else:
            self.current_section = None
            self.current_section_type = None

    def get_section(self, name: str) -> Optional[Section]:
        """Get section by name.

        Args:
            name: Section name

        Returns:
            Section if found, None otherwise
        """
        return self.sections.get(name)

    def get_all_sections(self) -> List[Section]:
        """Get all sections.

        Returns:
            List of all sections
        """
        return list(self.sections.values())
