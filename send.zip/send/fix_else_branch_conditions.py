#!/usr/bin/env python3
"""
fix_else_branch_conditions.py

Post-process existing .cpp.json blueprint files to fix the else-branch
condition polarity bug, without re-running the full analysis pipeline.

The C++ blueprint parser previously emitted the positive if-condition for
assignments that live in else-branches instead of the correct NOT(condition).

This script:
  1. Loads each .cpp.json blueprint (gzip + msgpack)
  2. Re-runs ONLY the lightweight tree-sitter parse (CFamilyParser.parse)
     on the matching source file — much faster than the full pipeline
  3. Builds a {(function_scope, line) -> [conditions]} map from the
     fixed parser output
  4. Replaces conditional_context on variable_lineage edges where the
     stored conditions differ from the corrected ones
  5. Writes the patched blueprint back in-place

Run from the project root:
    python3 fix_else_branch_conditions.py \\
        --blueprint-dir /var/asm-jobs/<job_id>/output \\
        --source-dir    /var/asm-source/asm \\
        [--dry-run]     print what would change, don't write \\
        [--file STEM]   process only this stem, e.g. dw780000
"""
from __future__ import annotations

import argparse
import gzip
import logging
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    import msgpack
except ImportError:
    msgpack = None  # plain-JSON files still work without msgpack

# Allow imports from the project root regardless of cwd.
sys.path.insert(0, str(Path(__file__).resolve().parent))

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Build the corrected {(scope, line): [conditions]} map
# ---------------------------------------------------------------------------

def _build_condition_map(
    source_text: str,
    file_path: Path,
) -> Dict[Tuple[str, int], List[str]]:
    """
    Run CFamilyParser.parse() — now with the else-branch fix — and return
    {(function_name, line_number): [conditional_context]} for every CAssignment
    in the unit.

    This is the only parsing done; no call-graph, no lineage builder, no DB
    writes.  Typical runtime: 0.5–5 s per file depending on size.
    """
    try:
        from passes.c_family_parser import CFamilyParser
    except ImportError as exc:
        log.error("Cannot import CFamilyParser: %s", exc)
        return {}

    try:
        unit = CFamilyParser("cpp").parse(file_path, source_text)
    except Exception as exc:
        log.error("[%s] parse failed: %s", file_path.name, exc)
        return {}

    result: Dict[Tuple[str, int], List[str]] = {}
    for asn in unit.assignments:
        key = (asn.function or "", asn.line)
        # Keep the first assignment found at each (scope, line); they all share
        # the same enclosing control-flow conditions.
        if key not in result:
            result[key] = list(asn.conditional_context or [])
    return result


# ---------------------------------------------------------------------------
# Blueprint I/O helpers  (supports gzip+msgpack and plain JSON)
# ---------------------------------------------------------------------------

def _load_blueprint(path: Path):
    """Load a blueprint file.  Auto-detects gzip+msgpack vs plain JSON."""
    raw = path.read_bytes()
    # gzip magic bytes: 1f 8b
    if raw[:2] == b"\x1f\x8b":
        decompressed = gzip.decompress(raw)
        # msgpack files begin with a map fixmap (0x8x) or map16/32 marker
        if decompressed[:1] not in (b"{", b"[") and msgpack is not None:
            return msgpack.unpackb(decompressed, raw=False)
        # compressed but JSON inside (rare)
        import json
        return json.loads(decompressed.decode("utf-8", errors="replace"))
    # plain JSON
    import json
    return json.loads(raw.decode("utf-8", errors="replace"))


def _save_blueprint(path: Path, data, original_format: str) -> None:
    """Write a blueprint file in the same format it was loaded from."""
    import json
    if original_format == "gzip_msgpack":
        assert msgpack is not None
        with gzip.open(path, "wb") as fh:
            fh.write(msgpack.packb(data, use_bin_type=True))
    elif original_format == "gzip_json":
        with gzip.open(path, "wt", encoding="utf-8") as fh:
            json.dump(data, fh)
    else:
        path.write_text(json.dumps(data), encoding="utf-8")


def _detect_format(path: Path) -> str:
    """Return 'gzip_msgpack', 'gzip_json', or 'plain_json'."""
    raw = path.read_bytes()
    if raw[:2] == b"\x1f\x8b":
        decompressed = gzip.decompress(raw)
        if decompressed[:1] not in (b"{", b"["):
            return "gzip_msgpack"
        return "gzip_json"
    return "plain_json"


# ---------------------------------------------------------------------------
# Edge patching
# ---------------------------------------------------------------------------

def _patch_edges(
    edges: List[dict],
    cond_map: Dict[Tuple[str, int], List[str]],
    stem: str,
    verbose: bool = False,
) -> int:
    """
    Update conditional_context on variable_lineage assign/define edges
    in-place.  Returns the number of edges changed.
    """
    changed = 0
    for edge in edges:
        rel = str(edge.get("relation") or "").lower()
        if rel not in ("assign", "define"):
            continue

        old_conds = edge.get("conditional_context")
        if not old_conds:
            # No conditions stored — nothing to fix.
            continue

        scope = str(edge.get("scope") or "")
        line  = int(edge.get("line") or 0)
        new_conds = cond_map.get((scope, line))

        if new_conds is None:
            # Line not captured by the parser (e.g., implicit struct-member
            # define edges generated purely by the lineage builder).
            # Fall back: try stripping class:: qualifier from scope.
            bare_scope = scope.split("::")[-1]
            new_conds = cond_map.get((bare_scope, line))

        if new_conds is None or new_conds == old_conds:
            continue

        if verbose:
            tgt = str(edge.get("target") or "")[:60]
            log.debug(
                "  [%s] line %d scope=%s\n    OLD: %s\n    NEW: %s",
                stem, line, scope, old_conds, new_conds,
            )

        edge["conditional_context"] = list(new_conds)
        changed += 1

    return changed


# ---------------------------------------------------------------------------
# Per-file entry point
# ---------------------------------------------------------------------------

def process_file(
    blueprint_path: Path,
    source_path: Path,
    dry_run: bool = False,
    verbose: bool = False,
) -> bool:
    """Process one blueprint file.  Returns True on success."""
    stem = blueprint_path.name.replace(".cpp.json", "")

    if not source_path.exists():
        log.warning("[%s] source not found: %s — skipping", stem, source_path)
        return False

    # ── Load blueprint ────────────────────────────────────────────────────
    log.info("[%s] loading blueprint …", stem)
    try:
        fmt = _detect_format(blueprint_path)
        bp  = _load_blueprint(blueprint_path)
    except Exception as exc:
        log.error("[%s] failed to load blueprint: %s", stem, exc)
        return False

    lineage = bp.get("variable_lineage") or {}
    edges   = lineage.get("edges") or []
    if not edges:
        log.info("[%s] no variable_lineage edges — nothing to do", stem)
        return True

    # ── Build corrected condition map ─────────────────────────────────────
    log.info("[%s] parsing source for corrected conditions …", stem)
    source_text = source_path.read_text(encoding="utf-8", errors="replace")
    cond_map = _build_condition_map(source_text, source_path)

    if not cond_map:
        log.warning("[%s] condition map is empty — skipping", stem)
        return False

    # ── Patch edges ───────────────────────────────────────────────────────
    changed = _patch_edges(edges, cond_map, stem, verbose=verbose)

    edges_with_conds = sum(
        1 for e in edges
        if str(e.get("relation") or "").lower() in ("assign", "define")
        and e.get("conditional_context")
    )
    log.info(
        "[%s] %d conditional edges checked, %d updated",
        stem, edges_with_conds, changed,
    )

    if changed == 0:
        log.info("[%s] already correct — no write needed", stem)
        return True

    # ── Write back ────────────────────────────────────────────────────────
    if dry_run:
        log.info("[%s] DRY RUN — not writing", stem)
    else:
        log.info("[%s] writing patched blueprint (%s) …", stem, fmt)
        try:
            _save_blueprint(blueprint_path, bp, fmt)
            log.info("[%s] saved", stem)
        except Exception as exc:
            log.error("[%s] failed to write: %s", stem, exc)
            return False

    return True


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument(
        "--blueprint-dir", required=True,
        help="Directory containing *.cpp.json blueprint files",
    )
    ap.add_argument(
        "--source-dir", required=True,
        help="Directory containing *.cpp source files",
    )
    ap.add_argument(
        "--dry-run", action="store_true",
        help="Report what would change but do not write anything",
    )
    ap.add_argument(
        "--file", metavar="STEM",
        help="Process only this file stem (e.g. dw780000)",
    )
    ap.add_argument(
        "--verbose", "-v", action="store_true",
        help="Log each changed edge (old vs new conditions)",
    )
    args = ap.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    bp_dir  = Path(args.blueprint_dir)
    src_dir = Path(args.source_dir)

    if not bp_dir.is_dir():
        sys.exit(f"--blueprint-dir not found: {bp_dir}")
    if not src_dir.is_dir():
        sys.exit(f"--source-dir not found: {src_dir}")

    blueprints = sorted(bp_dir.glob("*.cpp.json"))
    if args.file:
        blueprints = [p for p in blueprints if p.name.startswith(args.file)]
    if not blueprints:
        sys.exit("No matching *.cpp.json files found in blueprint-dir")

    log.info("Processing %d blueprint file(s) …", len(blueprints))

    ok = failed = skipped = 0
    for bp_path in blueprints:
        stem     = bp_path.name.replace(".cpp.json", "")
        src_path = src_dir / f"{stem}.cpp"
        try:
            success = process_file(
                bp_path, src_path,
                dry_run=args.dry_run,
                verbose=args.verbose,
            )
            if success:
                ok += 1
            else:
                skipped += 1
        except Exception as exc:
            log.error("[%s] unexpected error: %s", stem, exc, exc_info=True)
            failed += 1

    log.info(
        "Done — %d OK, %d skipped/not-found, %d errors",
        ok, skipped, failed,
    )
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
