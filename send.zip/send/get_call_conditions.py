#!/usr/bin/env python3
"""
get_call_conditions.py

Return the conditions in file A that must be true for a call from A to B to
happen. Supports all four cross-file patterns (auto-detected):

  ASM → ASM,  ASM → C++,  C++ → ASM,  C++ → C++.

Output JSON shape:
  {
    "caller": "<stem>",
    "callee": "<stem>",
    "pattern": "ASM->ASM" | ...,
    "call_sites": [
      {
        "call_line": <int>,
        "call_instruction": "ENTRC" | "CALL_ALIAS" | "CALL" | ...,
        "conditions": [
          {"condition": "<text>", "line_no": <int>},
          ...
        ]
      },
      ...
    ]
  }

Usage:
  python get_call_conditions.py <file_a> <file_b> [--blueprint-dir DIR]
                                                  [--asm-dir DIR]
                                                  [--output FILE]

`file_a` and `file_b` may be stems (e.g. da76) or full paths (e.g.
temp/asm/da76.asm or .../dx740200.cpp).
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from blueprint_io import iter_flow, load_blueprint
from cross_file_bridge import (
    _discover_asm_dir,
    _discover_blueprint_dir,
    find_asm_callers,
    find_asm_to_cpp_callers,
    find_cpp_callers,
    find_cpp_to_cpp_callers,
)
from find_call_conditions import (
    BRANCH_INST,
    NEGATE,
    TRIGGER_INST,
    _branch_condition,
    _branch_target,
    _label_to_block,
    _strip_comments_strings,
    cpp_conditions_for_call,
)


# ---------------------------------------------------------------------------
# ASM: render a trigger + branch pair as a readable "fires-when" expression
# ---------------------------------------------------------------------------

# Map effective condition → infix operator for compare-style triggers.
_COMPARE_OPS: Dict[str, str] = {
    "equal":     "==",  "zero":          "==",
    "not equal": "!=",  "non-zero":      "!=",
    "high":      ">",   "plus":          ">",
    "low":       "<",   "minus":         "<",
    "not high (low or equal)": "<=", "not plus":  "<=",
    "not low (high or equal)": ">=", "not minus": ">=",
}


_REG_RE = re.compile(r"^R(?:1[0-5]|[0-9])$", re.IGNORECASE)


def _is_register_target(target: Optional[str]) -> bool:
    """True when a branch target operand is a register (e.g. BR R14, BCR m,Rn).
    Indicates an indirect branch — runtime register value determines target."""
    if not target:
        return False
    return bool(_REG_RE.match(target.strip()))


def _stem(file_path_or_stem: str) -> str:
    """Strip directory and .asm/.cpp/.asm.json/.cpp.json suffixes."""
    name = Path(file_path_or_stem).name
    for suf in (".asm.json", ".cpp.json", ".asm", ".cpp"):
        if name.endswith(suf):
            return name[: -len(suf)]
    return name


def _asm_condition_text(
    trigger: Optional[Dict[str, Any]],
    branch_cond_when_taken: str,
    branches_away_from_call: bool,
) -> str:
    """Build a 'condition that must hold for the call to fire' expression."""
    effective = (
        NEGATE.get(branch_cond_when_taken, f"not ({branch_cond_when_taken})")
        if branches_away_from_call
        else branch_cond_when_taken
    )

    if trigger is None:
        # No trigger paired — express as "condition code is <state>" so the
        # reader knows the CC was set somewhere upstream (likely by a setter
        # earlier in the block or in a prior block).
        return f"CC = {effective}"

    inst = (trigger.get("inst") or "").upper()
    args = trigger.get("args") or []

    # TP (Test Decimal / Test Packed): CC 0 = valid packed-decimal format,
    # CC 1/2/3 = various format errors. NOT a value comparison.
    if inst == "TP":
        a = args[0] if args else "?"
        if effective in ("zero", "equal"):
            return f"{a} is valid packed-decimal"
        if effective in ("non-zero", "not equal"):
            return f"{a} is invalid packed-decimal"
        return f"TP {a} ({effective})"

    # Compare-style: CLC, CLI, CL, CLR, C, CR, CH, CP, CDS, CHI, CGFI, CGHI
    if inst in ("CLC", "CLI", "CL", "CLR", "C", "CR", "CH", "CP", "CDS",
                "CHI", "CGFI", "CGHI", "CGR", "CGRL", "CLGR"):
        a = args[0] if len(args) > 0 else "?"
        b = args[1] if len(args) > 1 else "?"
        # Strip trailing inline comments captured in the operand (HLASM convention).
        b = b.split()[0] if b else b
        op = _COMPARE_OPS.get(effective, f"<{effective}>")
        return f"{a} {op} {b}"

    # TM: test mask
    if inst in ("TM", "TMH", "TML"):
        a = args[0] if len(args) > 0 else "?"
        m = args[1].split()[0] if len(args) > 1 and args[1] else "?"
        if effective in ("zero", "equal"):
            return f"({a} & {m}) == 0"
        if effective in ("non-zero", "not equal"):
            return f"({a} & {m}) != 0"
        if effective == "overflow":
            return f"({a} & {m}) == {m}"  # all masked bits set
        if effective == "no overflow":
            return f"({a} & {m}) != {m}"
        return f"TM {a},{m} ({effective})"

    # OC X,X (self-OR for zero-test); NC X,X / XC X,X analogously
    if inst in ("OC", "NC", "XC") and len(args) >= 2:
        a, b = args[0], (args[1].split()[0] if args[1] else "")
        if a == b:
            if effective in ("zero", "equal"):
                return f"{a} == 0"
            if effective in ("non-zero", "not equal"):
                return f"{a} != 0"

    # LTR/LTGR/LCR: load-and-test register
    if inst in ("LTR", "LTGR", "LCR", "ICM"):
        r = args[0] if args else "?"
        if effective in ("zero", "equal"):
            return f"{r} == 0"
        if effective in ("non-zero", "not equal"):
            return f"{r} != 0"
        if effective == "minus":
            return f"{r} < 0"
        if effective == "plus":
            return f"{r} > 0"
        if effective in ("not minus",):
            return f"{r} >= 0"
        if effective in ("not plus",):
            return f"{r} <= 0"

    # Fallback: raw form
    return f"{inst} {','.join(args)} ({effective})"


# ---------------------------------------------------------------------------
# ASM condition extraction
#
# Three guard sources are chased, depth-bounded:
#   1. Intra-block:  TRIGGER + BRANCH pairs before the call line in the call's
#                    own block.flow (the common case).
#   2. Cross-block:  walking incoming_branches predecessors recursively; the
#                    branch that lands in (or fallthrough that bypasses skip
#                    away from) the current block is captured as an entry
#                    guard. Multiple alternatives → combined as OR.
#   3. Subroutine:   if the call's block belongs to a subroutine, every
#                    BAS/BAL caller of that subroutine contributes its own
#                    guards (intra-block before the BAS line). Multiple BAS
#                    callers → combined as OR.
# ---------------------------------------------------------------------------

def _intra_block_guards(
    asm_bp: Dict[str, Any],
    block: Dict[str, Any],
    before_line: int,
    max_guards: int,
) -> List[Dict[str, Any]]:
    """TRIGGER + BRANCH pairs in block.flow strictly before before_line.
    Unconditional branches (B/J/NOP) are skipped — they don't contribute a
    condition (the call is reachable in all cases for one side of them)."""
    flow = list(iter_flow(block))
    prior = sorted(
        (e for e in flow if (e.get("line") or 0) < before_line),
        key=lambda e: e.get("line") or 0,
        reverse=True,
    )
    out: List[Dict[str, Any]] = []
    i = 0
    while i < len(prior) and len(out) < max_guards:
        e = prior[i]
        inst = (e.get("inst") or "").upper()
        args = e.get("args") or []
        if inst in BRANCH_INST:
            cond_taken = _branch_condition(inst, args)
            if cond_taken in ("always", "never"):
                # Unconditional or never-taken — no condition to record.
                i += 1
                continue
            tgt_label = _branch_target(inst, args)
            # Indirect (register) branch: target depends on runtime register value.
            # Emit an explicit flag rather than guessing direction.
            if _is_register_target(tgt_label):
                out.append({
                    "condition": f"indirect branch via {tgt_label} (runtime-dependent)",
                    "line_no": e.get("line"),
                    "opcode": f"{inst} (indirect)",
                })
                i += 1
                continue
            tgt_block = _label_to_block(asm_bp, tgt_label) if tgt_label else None
            branches_away = not (tgt_block and tgt_block == block.get("id"))
            trigger: Optional[Dict[str, Any]] = None
            j = i + 1
            while j < len(prior) and j < i + 4:
                t = prior[j]
                t_inst = (t.get("inst") or "").upper()
                if t_inst in TRIGGER_INST:
                    trigger = {
                        "line": t.get("line"),
                        "inst": t_inst,
                        "args": t.get("args") or [],
                    }
                    break
                if t_inst in BRANCH_INST:
                    break
                j += 1
            if trigger is None:
                # Drop unpaired branches: without a paired compare, "CC = <state>"
                # is noise — the compare is out of reach (set by a macro upstream
                # or by an instruction the parser didn't classify as a trigger).
                i += 1
                continue
            text = _asm_condition_text(trigger, cond_taken, branches_away)
            line_no = trigger.get("line") or e.get("line")
            opcode = trigger["inst"]
            out.append({"condition": text, "line_no": line_no, "opcode": opcode})
            i = j + 1
            continue
        i += 1
    out.reverse()
    return out


def _entry_guard_from_branch(
    asm_bp: Dict[str, Any],
    pred_block: Dict[str, Any],
    target_block_id: str,
    invert: bool,
) -> Optional[Dict[str, Any]]:
    """Find the conditional branch in pred_block whose target is target_block_id
    (when invert=False) or the last conditional branch (when invert=True,
    representing fallthrough). Return a guard entry or None."""
    flow = list(iter_flow(pred_block))
    for idx in range(len(flow) - 1, -1, -1):
        fe = flow[idx]
        inst = (fe.get("inst") or "").upper()
        if inst not in BRANCH_INST:
            continue
        cond_taken = _branch_condition(inst, fe.get("args") or [])
        if invert:
            # Fallthrough case: last conditional branch in pred did NOT take.
            if cond_taken == "always":
                # Unconditional branch can't fall through past it.
                return None
            trig = _find_trigger_above(flow, idx)
            if trig is None:
                # Drop unpaired branches — "CC = <state>" is too vague.
                return None
            text = _asm_condition_text(trig, cond_taken, branches_away_from_call=True)
            line_no = trig.get("line") or fe.get("line")
            opcode = trig["inst"]
            return {"condition": text, "line_no": line_no, "opcode": opcode}
        # Branch case: the branch must target our block.
        tgt = _branch_target(inst, fe.get("args") or [])
        tgt_block = _label_to_block(asm_bp, tgt) if tgt else None
        if tgt_block != target_block_id:
            continue
        if cond_taken in ("always", "never"):
            # Unconditional jump into our block is not a condition.
            return None
        trig = _find_trigger_above(flow, idx)
        if trig is None:
            return None
        text = _asm_condition_text(trig, cond_taken, branches_away_from_call=False)
        line_no = trig.get("line") or fe.get("line")
        opcode = trig["inst"]
        return {"condition": text, "line_no": line_no, "opcode": opcode}
    return None


def _find_trigger_above(
    flow: List[Dict[str, Any]],
    branch_idx: int,
) -> Optional[Dict[str, Any]]:
    """Look up to 3 entries above branch_idx for a TRIGGER, stopping at any other branch."""
    for j in range(1, 4):
        k = branch_idx - j
        if k < 0:
            return None
        inst = (flow[k].get("inst") or "").upper()
        if inst in TRIGGER_INST:
            return {
                "line": flow[k].get("line"),
                "inst": inst,
                "args": flow[k].get("args") or [],
            }
        if inst in BRANCH_INST:
            return None
    return None


def _entry_paths_for_predecessor(
    asm_bp: Dict[str, Any],
    block: Dict[str, Any],
    pred: Dict[str, Any],
    types: set,
) -> Tuple[List[Dict[str, Any]], int]:
    """Compute the entry guards and recurse_focus for ONE predecessor of block.
    Returns (alternatives, recurse_focus). True tautology (BRANCH+FALLTHROUGH
    from same compare) → ([], focus)."""
    pred_flow = list(iter_flow(pred))
    branch_into_block_line: Optional[int] = None
    if "BRANCH" in types:
        for fe in pred_flow:
            inst = (fe.get("inst") or "").upper()
            if inst not in BRANCH_INST:
                continue
            cond = _branch_condition(inst, fe.get("args") or [])
            if cond in ("always", "never"):
                continue
            tgt = _branch_target(inst, fe.get("args") or [])
            tgt_block = _label_to_block(asm_bp, tgt) if tgt else None
            if tgt_block == block.get("id"):
                branch_into_block_line = fe.get("line")
                break
    fallthrough_branch_line: Optional[int] = None
    if "FALLTHROUGH" in types:
        for fe in reversed(pred_flow):
            inst = (fe.get("inst") or "").upper()
            if inst not in BRANCH_INST:
                continue
            cond = _branch_condition(inst, fe.get("args") or [])
            if cond not in ("always", "never"):
                fallthrough_branch_line = fe.get("line")
                break
    captured_lines = [l for l in (branch_into_block_line, fallthrough_branch_line) if l]
    recurse_focus = (
        min(captured_lines)
        if captured_lines
        else (pred.get("end_line") or 0) + 1
    )
    alternatives: List[Dict[str, Any]] = []
    if "BRANCH" in types:
        g = _entry_guard_from_branch(asm_bp, pred, block["id"], invert=False)
        if g:
            alternatives.append(g)
    if "FALLTHROUGH" in types:
        g = _entry_guard_from_branch(asm_bp, pred, block["id"], invert=True)
        if g:
            alternatives.append(g)
    if (
        len(alternatives) == 2
        and alternatives[0].get("line_no") == alternatives[1].get("line_no")
        and alternatives[0].get("opcode") == alternatives[1].get("opcode")
    ):
        return [], recurse_focus
    return alternatives, recurse_focus


def _block_entry_paths(
    asm_bp: Dict[str, Any],
    block: Dict[str, Any],
    block_index: Dict[str, Dict[str, Any]],
) -> List[Tuple[List[Dict[str, Any]], Dict[str, Any], int]]:
    """Return a list of (entry_guards, pred_block, recurse_focus_line) — one
    tuple per distinct predecessor that may enter `block`. The caller is
    expected to walk into each predecessor independently and OR-combine
    when there is more than one."""
    inb = block.get("incoming_branches") or []
    by_src: Dict[str, set] = {}
    for entry in inb:
        src = entry.get("source")
        typ = entry.get("type")
        # SUBROUTINE_CALL is handled by the subroutine chase; ignore here.
        if src in (None, "$IS$", "$END$"):
            continue
        if typ not in ("BRANCH", "FALLTHROUGH"):
            continue
        by_src.setdefault(src, set()).add(typ)

    out: List[Tuple[List[Dict[str, Any]], Dict[str, Any], int]] = []
    for src_id, types in by_src.items():
        pred = block_index.get(src_id)
        if pred is None:
            continue
        alts, focus = _entry_paths_for_predecessor(asm_bp, block, pred, types)
        if len(alts) == 0:
            out.append(([], pred, focus))
        elif len(alts) == 1:
            out.append((alts, pred, focus))
        else:
            # BRANCH+FALLTHROUGH from same pred → OR them into one entry guard.
            combined = {
                "condition": " OR ".join(f"({a['condition']})" for a in alts),
                "line_no": min(a["line_no"] or 0 for a in alts) or alts[0]["line_no"],
                "opcode": "OR",
            }
            out.append(([combined], pred, focus))
    return out


# ---- Subroutine entry (BAS/BAL chase) -----------------------------------

def _containing_subroutine(
    asm_bp: Dict[str, Any],
    line_no: Optional[int],
) -> Optional[Dict[str, Any]]:
    if not line_no:
        return None
    for sub in asm_bp.get("subroutines") or []:
        s, e = sub.get("start_line") or 0, sub.get("end_line") or 0
        if s and e and s <= line_no <= e:
            return sub
    return None


def _bas_callers_of(asm_bp: Dict[str, Any], sub_id: str) -> List[Dict[str, Any]]:
    """Return [{caller_block, line}] for every BAS/BAL/BASR into sub_id."""
    out: List[Dict[str, Any]] = []
    sub_upper = sub_id.upper()
    for edge in asm_bp.get("call_graph", {}).get("edges", []):
        inst = (edge.get("instruction") or "").upper()
        if inst not in ("BAS", "BAL", "BASR"):
            continue
        if (edge.get("target") or "").upper() != sub_upper:
            continue
        out.append({
            "caller_block": edge.get("source"),
            "line": edge.get("line"),
        })
    return out


# ---- Top-level ASM extractor --------------------------------------------

def _find_innermost_block_for_line(
    asm_bp: Dict[str, Any],
    line_no: int,
) -> Optional[Dict[str, Any]]:
    """Return the NARROWEST block whose [start_line, end_line] contains line_no.

    Blueprints can emit overlapping/nested blocks: a large section-level block
    (e.g. the whole based area) plus the precise basic block inside it. The
    shared `_find_block_for_line` returns the *first* match in list order,
    which is often the giant enclosing block — its flow/incoming_branches do
    not describe the local guards around the call, so guard extraction comes
    back empty. Picking the smallest-span container gives the true basic block
    whose intra-block flow and predecessors hold the call's guards.
    """
    best: Optional[Dict[str, Any]] = None
    best_span: Optional[int] = None
    for b in asm_bp.get("blocks") or []:
        s = b.get("start_line") or 0
        e = b.get("end_line") or 0
        if not (s and e and s <= line_no <= e):
            continue
        span = e - s
        if best_span is None or span < best_span:
            best = b
            best_span = span
    return best


def _asm_call_site_conditions(
    asm_bp: Dict[str, Any],
    call_line: int,
    max_total: int = 30,
    max_depth: int = 10,
    max_intra: int = 8,
) -> List[Dict[str, Any]]:
    """Recursive ASM guard extraction returning a flat list of guards.

    walk() returns the guards collected at and above a given (blk, focus_line).
    Multi-predecessor join points and multi-BAS-caller subroutines are
    combined as OR over per-path AND-ed guards."""
    block_index: Dict[str, Dict[str, Any]] = {
        b["id"]: b for b in asm_bp.get("blocks") or [] if b.get("id")
    }
    block = _find_innermost_block_for_line(asm_bp, call_line)
    if block is None:
        return []
    visited: set = set()

    def _dedup_path(path: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Drop repeated guards within a single path (by condition text)."""
        seen_p: set = set()
        out: List[Dict[str, Any]] = []
        for g in path:
            cond = g.get("condition")
            if cond in seen_p:
                continue
            seen_p.add(cond)
            out.append(g)
        return out

    def _or_combine(paths: List[List[Dict[str, Any]]], opcode: str) -> Optional[Dict[str, Any]]:
        non_empty = [_dedup_path(p) for p in paths if p]
        non_empty = [p for p in non_empty if p]
        if not non_empty:
            return None
        parts = [" AND ".join(g["condition"] for g in p) for p in non_empty]
        line_no = min(
            (g["line_no"] or 0 for p in non_empty for g in p),
            default=0,
        )
        # Drop any identical OR alternatives.
        seen_parts: set = set()
        uniq_parts: List[str] = []
        for p in parts:
            if p in seen_parts:
                continue
            seen_parts.add(p)
            uniq_parts.append(p)
        if len(uniq_parts) == 1:
            return {"condition": uniq_parts[0], "line_no": line_no, "opcode": opcode}
        return {
            "condition": " OR ".join(f"({p})" for p in uniq_parts),
            "line_no": line_no,
            "opcode": opcode,
        }

    def walk(
        blk: Dict[str, Any],
        focus_line: int,
        depth: int,
    ) -> List[Dict[str, Any]]:
        if depth > max_depth:
            return []
        key = (blk.get("id"), focus_line)
        if key in visited:
            return []
        visited.add(key)

        guards: List[Dict[str, Any]] = []

        # 1. intra-block guards strictly before focus_line
        guards.extend(_intra_block_guards(asm_bp, blk, focus_line, max_intra))

        # 2. cross-block entry: every predecessor that may enter this block
        paths = _block_entry_paths(asm_bp, blk, block_index)
        if len(paths) == 1:
            entry_guards, pred, recurse_focus = paths[0]
            guards.extend(entry_guards)
            guards.extend(walk(pred, recurse_focus, depth + 1))
        elif len(paths) > 1:
            # Multi-predecessor join. Each alternative captures its direct
            # entry guards + the predecessor's intra-block guards only.
            # Going deeper recursively per path causes combinatorial blow-up
            # and tangled OR(path) expressions; bounded depth keeps the
            # output readable while still showing every distinct entry path.
            per_path: List[List[Dict[str, Any]]] = []
            for entry_guards, pred, recurse_focus in paths:
                p_guards = list(entry_guards)
                p_guards.extend(_intra_block_guards(asm_bp, pred, recurse_focus, max_intra))
                per_path.append(p_guards)
            combined = _or_combine(per_path, "OR(path)")
            if combined:
                guards.append(combined)

        # 3. subroutine entry: every BAS caller of the containing subroutine
        sub = _containing_subroutine(asm_bp, blk.get("start_line"))
        if sub:
            callers = _bas_callers_of(asm_bp, sub["id"])
            if len(callers) == 1:
                c = callers[0]
                caller_blk = block_index.get(c["caller_block"])
                if caller_blk and c.get("line"):
                    guards.extend(walk(caller_blk, c["line"], depth + 1))
            elif len(callers) > 1:
                per_caller: List[List[Dict[str, Any]]] = []
                for c in callers:
                    caller_blk = block_index.get(c["caller_block"])
                    if not (caller_blk and c.get("line")):
                        continue
                    per_caller.append(walk(caller_blk, c["line"], depth + 1))
                combined = _or_combine(per_caller, "OR(BAS)")
                if combined:
                    guards.append(combined)

        return guards

    all_guards = walk(block, call_line, 0)

    # Dedupe by (condition, line_no, opcode), keep stable order, then sort.
    seen: set = set()
    dedup: List[Dict[str, Any]] = []
    for g in all_guards:
        key = (g.get("condition"), g.get("line_no"), g.get("opcode"))
        if key in seen:
            continue
        seen.add(key)
        dedup.append(g)
    dedup.sort(key=lambda g: g.get("line_no") or 0)
    return dedup[:max_total]


# ---------------------------------------------------------------------------
# C++ switch/case detection (walks backward, brace-depth tracked)
# ---------------------------------------------------------------------------

_CASE_RE = re.compile(r"^\s*case\s+(.+?)\s*:")
_DEFAULT_RE = re.compile(r"^\s*default\s*:")
_CATCH_RE = re.compile(r"\bcatch\s*\(\s*(.+?)\s*\)\s*$")


def _find_catch_header(lines: List[str], brace_idx: int) -> Optional[Dict[str, Any]]:
    """If the `{` at lines[brace_idx] is the body opener of a `catch(...)`,
    return `{'expr': str, 'line': int}`. Tolerates multi-line headers."""
    glued: List[str] = []
    for k in range(brace_idx, max(-1, brace_idx - 6), -1):
        seg = _strip_comments_strings(lines[k])
        if k == brace_idx:
            idx = seg.rfind("{")
            if idx >= 0:
                seg = seg[:idx]
        if k != brace_idx and re.search(r"[;{}]", seg):
            break
        glued.insert(0, seg.strip())
    combined = " ".join(s for s in glued if s).strip()
    m = _CATCH_RE.search(combined)
    if not m:
        return None
    expr = m.group(1).strip()
    for k in range(brace_idx, max(-1, brace_idx - 6), -1):
        if "catch" in lines[k]:
            return {"expr": expr, "line": k + 1}
    return {"expr": expr, "line": brace_idx + 1}


def _find_switch_header(lines: List[str], brace_idx: int) -> Optional[Dict[str, Any]]:
    """If the `{` at lines[brace_idx] is the body opener of a `switch(...)`,
    return `{'expr': str, 'line': int}`. Tolerates the header being split
    across up to 6 lines above the brace."""
    glued: List[str] = []
    for k in range(brace_idx, max(-1, brace_idx - 6), -1):
        seg = _strip_comments_strings(lines[k])
        if k == brace_idx:
            idx = seg.rfind("{")
            if idx >= 0:
                seg = seg[:idx]
        # Stop if we walked past prior unrelated code (a `;` or another brace).
        if k != brace_idx and re.search(r"[;{}]", seg):
            break
        glued.insert(0, seg.strip())
    combined = " ".join(s for s in glued if s).strip()
    m = re.search(r"\bswitch\s*\((.+)\)\s*$", combined)
    if not m:
        return None
    expr = m.group(1).strip()
    for k in range(brace_idx, max(-1, brace_idx - 6), -1):
        if "switch" in lines[k]:
            return {"expr": expr, "line": k + 1}
    return {"expr": expr, "line": brace_idx + 1}


def _cpp_switch_case_conditions(
    src_path: Path,
    call_line: int,
    max_nested: int = 4,
) -> List[Dict[str, Any]]:
    """Find enclosing switch/case scopes for the call. Innermost-first.

    Algorithm: walk backward from call line tracking brace depth (relative
    to call's scope). At depth 0, collect the most recent `case X:` /
    `default:` label. When a `{` is hit at depth 0 and is preceded by
    `switch (expr)`, emit `expr == case_label` and continue searching outer
    scopes for further enclosing switches."""
    try:
        lines = src_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []
    if not (1 <= call_line <= len(lines)):
        return []

    out: List[Dict[str, Any]] = []
    depth = 0
    case_label: Optional[str] = None
    case_label_line: Optional[int] = None

    for i in range(call_line - 2, -1, -1):
        line = lines[i]
        cleaned = _strip_comments_strings(line)

        # Detect a case/default label at our current scope before braces.
        if depth == 0 and case_label is None:
            m = _CASE_RE.match(line)
            if m:
                case_label = m.group(1).strip()
                case_label_line = i + 1
            elif _DEFAULT_RE.match(line):
                case_label = "default"
                case_label_line = i + 1

        # Process braces right-to-left so that `} catch (...) {` works:
        # walking back we hit the trailing `{` first (which opens the
        # catch/scope we're in), then the leading `}` (which descends into
        # the prior sibling scope).
        for ch in reversed(cleaned):
            if ch == "}":
                depth += 1
            elif ch == "{":
                if depth == 0:
                    # `{` opens our current enclosing scope. First check
                    # catch — it has highest priority for any `{`.
                    catch = _find_catch_header(lines, i)
                    if catch is not None:
                        out.append({
                            "condition": f"exception caught: {catch['expr']}",
                            "line_no": catch["line"],
                            "opcode": "catch",
                        })
                        if len(out) >= max_nested:
                            return out
                        case_label = None
                        case_label_line = None
                        continue
                    if case_label is not None:
                        sw = _find_switch_header(lines, i)
                        if sw is not None:
                            cond = (
                                f"{sw['expr']} == {case_label}"
                                if case_label != "default"
                                else f"{sw['expr']} (default case)"
                            )
                            out.append({
                                "condition": cond,
                                "line_no": case_label_line,
                                "opcode": "case",
                            })
                            if len(out) >= max_nested:
                                return out
                    case_label = None
                    case_label_line = None
                else:
                    depth -= 1
    return out


# ---------------------------------------------------------------------------
# C++ helpers: function-body discovery and brace/paren balanced extraction
# ---------------------------------------------------------------------------


def _capture_paren_block(
    lines: List[str], start_line: int, paren_open_col: int,
) -> Tuple[Optional[str], int, int]:
    """Starting at lines[start_line][paren_open_col] == '(', return
    (interior_text, close_line, col_after_close). interior_text excludes the
    outer parens. Returns (None, start_line, paren_open_col) on failure."""
    depth = 0
    pieces: List[str] = []
    line = start_line
    col = paren_open_col
    while line < len(lines):
        seg = _strip_comments_strings(lines[line])
        local_start = col if line == start_line else 0
        for k in range(local_start, len(seg)):
            ch = seg[k]
            if ch == "(":
                depth += 1
                if depth > 1:
                    pieces.append(ch)
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    return "".join(pieces).strip(), line, k + 1
                pieces.append(ch)
            else:
                if depth >= 1:
                    pieces.append(ch)
        line += 1
        col = 0
    return None, start_line, paren_open_col


def _capture_brace_block(
    lines: List[str], start_line: int, brace_open_col: int,
) -> Tuple[Optional[str], int]:
    """Starting at lines[start_line][brace_open_col] == '{', return
    (interior_text, close_line). interior_text excludes outer braces."""
    depth = 0
    pieces: List[str] = []
    line = start_line
    col = brace_open_col
    while line < len(lines):
        seg = _strip_comments_strings(lines[line])
        local_start = col if line == start_line else 0
        for k in range(local_start, len(seg)):
            ch = seg[k]
            if ch == "{":
                depth += 1
                if depth > 1:
                    pieces.append(ch)
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return "".join(pieces).strip(), line
                pieces.append(ch)
            else:
                if depth >= 1:
                    pieces.append(ch)
        pieces.append("\n")
        line += 1
        col = 0
    return None, start_line


def _find_function_start(lines: List[str], call_line: int) -> Optional[int]:
    """Return the 0-based line index of the `{` opening the innermost function
    body that contains call_line (1-based). Heuristic: walk backward tracking
    brace depth; the first `{` reached at depth 0 (going back from call_line)
    that has a `)` shortly above it is the function-body opener."""
    if not (1 <= call_line <= len(lines)):
        return None
    depth = 0
    for i in range(call_line - 2, -1, -1):
        seg = _strip_comments_strings(lines[i])
        opens = seg.count("{")
        closes = seg.count("}")
        net = closes - opens
        if net > 0:
            depth += net
        elif net < 0:
            consumed = -net
            for _ in range(consumed):
                if depth == 0:
                    # Found the opening brace of the enclosing scope. Is it a
                    # function body? Look back for the `)` of a function header
                    # within ~12 lines and depth-0 token continuity.
                    if _looks_like_function_header_above(lines, i):
                        return i
                    # Otherwise treat this as a block; continue searching outer.
                    # (For if/while/for/do bodies we want the function above.)
                else:
                    depth -= 1
    return None


def _looks_like_function_header_above(lines: List[str], brace_line: int) -> bool:
    """Heuristic: lines preceding lines[brace_line] should end with a `)` and
    no control-keyword token (if/while/for/switch/catch/do/else)."""
    glued: List[str] = []
    for k in range(brace_line, max(-1, brace_line - 8), -1):
        seg = _strip_comments_strings(lines[k])
        if k == brace_line:
            idx = seg.rfind("{")
            if idx >= 0:
                seg = seg[:idx]
        if k != brace_line and re.search(r"[;{}]", seg):
            break
        glued.insert(0, seg)
    combined = " ".join(s.strip() for s in glued if s.strip())
    if not combined.endswith(")"):
        return False
    # Anti-match: control keywords whose body opens with `{`.
    if re.search(r"\b(if|while|for|switch|catch|else\s+if)\s*\($", combined):
        return False
    if re.search(r"\b(else|do|try)\s*$", combined):
        return False
    # Must contain a `(` paired with the trailing `)`.
    if "(" not in combined:
        return False
    return True


# ---------------------------------------------------------------------------
# C++ early-return / guard-clause detection
#
# Detects guards of the shape:
#     if (cond) return ...;
#     if (cond) { return ...; }
#     if (cond) throw ...;
#     if (cond) { throw ...; }
#     if (cond) exit(...);
#     if (cond) abort();
#     if (cond) goto LABEL;        (forward goto, by position)
# For each such pattern occurring in the call's function before the call
# line, emit `!(cond)` — the call is reached only when the guard did NOT exit.
# ---------------------------------------------------------------------------

_EARLY_EXIT_RE = re.compile(
    r"^\s*(return\b|throw\b|exit\s*\(|abort\s*\(|std::terminate\b|std::exit\s*\()"
)
_GOTO_RE = re.compile(r"^\s*goto\s+(\w+)\s*;")


def _cpp_early_return_guards(
    src_path: Path,
    call_line: int,
) -> List[Dict[str, Any]]:
    try:
        lines = src_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []
    if not (1 <= call_line <= len(lines)):
        return []
    fn_start_brace = _find_function_start(lines, call_line)
    if fn_start_brace is None:
        return []

    # Pre-compute forward goto labels (label → line) in case we need to check
    # that a `goto LABEL` jumps past the call.
    labels: Dict[str, int] = {}
    for k, ln in enumerate(lines):
        cleaned = _strip_comments_strings(ln)
        m = re.match(r"^\s*(\w+)\s*:\s*$", cleaned)
        if m and not re.match(r"^\s*(case|default)\b", cleaned):
            labels[m.group(1)] = k + 1

    out: List[Dict[str, Any]] = []
    i = fn_start_brace + 1  # walk inside the function body
    while i < call_line - 1:
        line = lines[i]
        cleaned = _strip_comments_strings(line)
        m = re.search(r"\bif\s*\(", cleaned)
        if not m:
            i += 1
            continue
        paren_col = cleaned.find("(", m.start())
        cond, end_line, end_col = _capture_paren_block(lines, i, paren_col)
        if cond is None:
            i += 1
            continue

        # Find what comes after the closing ')'
        after = _strip_comments_strings(lines[end_line])[end_col:].lstrip()
        body_text: Optional[str] = None
        consumed_to_line = end_line

        if after.startswith("{"):
            brace_col = _strip_comments_strings(lines[end_line]).index("{", end_col)
            body_text, body_end_line = _capture_brace_block(lines, end_line, brace_col)
            consumed_to_line = body_end_line
        elif after:
            # Body is on same line as ')'.
            body_text = after.rstrip()
            consumed_to_line = end_line
        else:
            # Body on next line(s).
            for j in range(end_line + 1, min(end_line + 4, len(lines))):
                seg = _strip_comments_strings(lines[j]).strip()
                if not seg:
                    continue
                if seg.startswith("{"):
                    brace_col = _strip_comments_strings(lines[j]).index("{")
                    body_text, body_end_line = _capture_brace_block(lines, j, brace_col)
                    consumed_to_line = body_end_line
                else:
                    body_text = seg
                    consumed_to_line = j
                break

        if body_text is not None:
            body_stripped = body_text.strip()
            is_exit = bool(_EARLY_EXIT_RE.match(body_stripped))
            if not is_exit:
                # goto LABEL where LABEL is past the call line counts as exit too.
                gm = _GOTO_RE.match(body_stripped)
                if gm and labels.get(gm.group(1), 0) > call_line:
                    is_exit = True
            if is_exit:
                out.append({
                    "condition": f"!({cond})",
                    "line_no": i + 1,
                    "opcode": "guard-clause",
                })
        i = consumed_to_line + 1

    return out


# ---------------------------------------------------------------------------
# C++ short-circuit / ternary detection
#
# Walks the *statement* containing the call (terminated by `;`, `{`, or `}`
# at brace-depth 0 going backward) and looks for short-circuit / ternary
# operators immediately preceding the call's function name. Reports the
# left-hand predicate as a condition.
#
#   `<expr> && fn(args)`   → call fires when `<expr>` is true
#   `<expr> || fn(args)`   → call fires when `!(<expr>)`
#   `<expr> ? fn(args)`    → call fires when `<expr>`         (true arm)
#   `<expr> ? ... : fn(`   → call fires when `!(<expr>)`      (false arm)
# ---------------------------------------------------------------------------


def _extract_call_function_name(line: str, prefer_before_paren: bool = True) -> Optional[str]:
    """Pull out the function identifier from a line containing `fn(`."""
    cleaned = _strip_comments_strings(line)
    m = re.search(r"(\w+)\s*\(", cleaned)
    return m.group(1) if m else None


def _gather_statement_before(lines: List[str], call_line: int) -> str:
    """Collect text of the statement up to (but not including) the call's
    function-name `(`. Walks back from the function name through preceding
    lines until a `;`, `{`, or `}` is hit at brace-depth 0."""
    if not (1 <= call_line <= len(lines)):
        return ""
    pieces: List[str] = []

    # First include the prefix on the call line itself, up to the function `(`.
    call_seg = _strip_comments_strings(lines[call_line - 1])
    m = re.search(r"(\w+)\s*\(", call_seg)
    if m:
        pieces.append(call_seg[: m.start()])

    # Walk back to earlier lines until a statement terminator at depth 0.
    depth = 0
    for i in range(call_line - 2, -1, -1):
        seg = _strip_comments_strings(lines[i])
        terminator_pos = -1
        for k in range(len(seg) - 1, -1, -1):
            ch = seg[k]
            if ch == ")":
                depth += 1
            elif ch == "(":
                depth -= 1
            elif depth == 0 and ch in ";{}":
                terminator_pos = k
                break
        if terminator_pos >= 0:
            pieces.insert(0, seg[terminator_pos + 1:])
            break
        pieces.insert(0, seg)
    return " ".join(p.strip() for p in pieces if p.strip())


def _cpp_short_circuit_conditions(
    src_path: Path,
    call_line: int,
) -> List[Dict[str, Any]]:
    """Detect short-circuit / ternary guards by examining the statement text
    immediately preceding the call's function name."""
    try:
        lines = src_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []
    if not (1 <= call_line <= len(lines)):
        return []

    stmt = _gather_statement_before(lines, call_line).rstrip()
    if not stmt:
        return []

    out: List[Dict[str, Any]] = []

    if stmt.endswith("&&"):
        cond = stmt[:-2].strip()
        if cond:
            out.append({"condition": cond, "line_no": call_line, "opcode": "&&"})
        return out

    if stmt.endswith("||"):
        cond = stmt[:-2].strip()
        if cond:
            out.append({"condition": f"!({cond})", "line_no": call_line, "opcode": "||"})
        return out

    if stmt.endswith("?"):
        cond = stmt[:-1].strip()
        if cond:
            out.append({"condition": cond, "line_no": call_line, "opcode": "?"})
        return out

    if stmt.endswith(":") and "?" in stmt:
        # Ternary false arm: split at the LAST `?` not balanced inside parens.
        depth = 0
        q_idx = -1
        for k in range(len(stmt) - 1, -1, -1):
            ch = stmt[k]
            if ch == ")":
                depth += 1
            elif ch == "(":
                depth -= 1
            elif depth == 0 and ch == "?":
                q_idx = k
                break
        if q_idx >= 0:
            cond = stmt[:q_idx].strip()
            if cond:
                out.append({"condition": f"!({cond})", "line_no": call_line, "opcode": "?:"})
        return out

    return out


# ---------------------------------------------------------------------------
# C++ inter-procedural caller chain
#
# For a call in function F, the call is reached only when (the path from F's
# caller to the call in F's own body holds). We scan every .cpp.json blueprint
# for CALL edges targeting F, then collect guards at each of those caller
# sites (intra-function only, then recurse). Multiple callers → OR.
# ---------------------------------------------------------------------------


def _cpp_inter_procedural_guards(
    caller_function: Optional[str],
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    visited: set,
    depth: int,
    max_depth: int,
) -> List[Dict[str, Any]]:
    if not caller_function or depth >= max_depth or caller_function in visited:
        return []
    visited = set(visited)
    visited.add(caller_function)

    per_caller_groups: List[List[Dict[str, Any]]] = []
    for bp_path in sorted(blueprint_dir.glob("*.cpp.json")):
        try:
            bp = load_blueprint(bp_path)
        except Exception:
            continue
        for edge in bp.get("call_graph", {}).get("edges", []):
            tgt = edge.get("target") or ""
            inst = (edge.get("instruction") or "").upper()
            if tgt != caller_function or inst != "CALL":
                continue
            line = edge.get("line")
            file_field = edge.get("file", "")
            if not (line and file_field):
                continue
            src = Path(file_field)
            if not src.exists() and asm_dir:
                src = asm_dir / Path(file_field).name
            if not src.exists():
                continue
            # Intra-function guards at the caller's call site.
            local = _cpp_intra_function_conditions(src, line)
            # Recurse: this caller's own function may itself be called only under conditions.
            outer_fn = edge.get("source")
            ancestor = _cpp_inter_procedural_guards(
                outer_fn, blueprint_dir, asm_dir,
                visited, depth + 1, max_depth,
            )
            per_caller_groups.append(local + ancestor)

    if not per_caller_groups:
        return []
    if len(per_caller_groups) == 1:
        return per_caller_groups[0]

    non_empty = [p for p in per_caller_groups if p]
    if not non_empty:
        return []
    parts = [" AND ".join(g["condition"] for g in p) for p in non_empty]
    uniq: List[str] = []
    seen: set = set()
    for p in parts:
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    line_no = min(
        (g["line_no"] or 0 for p in non_empty for g in p if g.get("line_no")),
        default=0,
    )
    if len(uniq) == 1:
        return [{"condition": uniq[0], "line_no": line_no, "opcode": "OR(caller)"}]
    return [{
        "condition": " OR ".join(f"({p})" for p in uniq),
        "line_no": line_no,
        "opcode": "OR(caller)",
    }]


# ---------------------------------------------------------------------------
# Extract intra-function C++ guards (no inter-procedural — used as a building
# block by both the top-level conditions function and the inter-procedural
# walker so we don't recurse twice).
# ---------------------------------------------------------------------------


def _cpp_intra_function_conditions(
    src_path: Path,
    call_line: int,
) -> List[Dict[str, Any]]:
    headers = cpp_conditions_for_call(src_path, call_line)  # if/while/for
    try:
        raw_lines = src_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        raw_lines = []
    out: List[Dict[str, Any]] = []
    for h in headers:
        kw = h.get("keyword") or "if"
        line_no = h.get("line") or 0
        idx0 = line_no - 1
        text = ""
        if 0 <= idx0 < len(raw_lines):
            buf: List[str] = []
            depth = 0
            started = False
            for k in range(idx0, min(idx0 + 10, len(raw_lines))):
                seg = raw_lines[k]
                buf.append(seg)
                for ch in seg:
                    if ch == "(":
                        depth += 1
                        started = True
                    elif ch == ")":
                        depth -= 1
                if started and depth == 0:
                    break
            text = " ".join(s.strip() for s in buf).strip()
        cleaned = text
        idx = cleaned.find(kw)
        if idx >= 0:
            cleaned = cleaned[idx + len(kw):].lstrip()
        if cleaned.startswith("("):
            d = 0
            end = -1
            for k, ch in enumerate(cleaned):
                if ch == "(":
                    d += 1
                elif ch == ")":
                    d -= 1
                    if d == 0:
                        end = k
                        break
            if end > 0:
                cleaned = cleaned[1:end].strip()
        out.append({"condition": cleaned, "line_no": line_no, "opcode": kw})

    out.extend(_cpp_switch_case_conditions(src_path, call_line))
    out.extend(_cpp_short_circuit_conditions(src_path, call_line))
    out.extend(_cpp_early_return_guards(src_path, call_line))

    # Filter out the imported helper's false positives: when an `if`
    # enclosing-scope entry shares its line number with a guard-clause entry
    # (i.e. the `if` was actually a brace-less guard-clause, not a real
    # scope), drop the `if` entry.
    guard_lines = {
        o["line_no"]: o["condition"]
        for o in out
        if o.get("opcode") == "guard-clause"
    }
    out = [
        o for o in out
        if not (
            o.get("opcode") == "if"
            and o.get("line_no") in guard_lines
            and guard_lines[o["line_no"]] == f"!({o.get('condition')})"
        )
    ]

    seen: set = set()
    dedup: List[Dict[str, Any]] = []
    for o in out:
        key = (o.get("condition"), o.get("line_no"), o.get("opcode"))
        if key in seen:
            continue
        seen.add(key)
        dedup.append(o)
    dedup.sort(key=lambda x: x.get("line_no") or 0)
    return dedup


# ---------------------------------------------------------------------------
# Extract conditions for a C++ call site (uses cpp_conditions_for_call helper)
# ---------------------------------------------------------------------------

def _cpp_call_site_conditions(
    src_path: Path,
    call_line: int,
    containing_function: Optional[str] = None,
    blueprint_dir: Optional[Path] = None,
    asm_dir: Optional[Path] = None,
    max_depth: int = 10,
) -> List[Dict[str, Any]]:
    # 1. Intra-function guards (if/while/for + switch/case + && / || / ?: +
    #    early-return + try/catch).
    out = _cpp_intra_function_conditions(src_path, call_line)

    # 2. Inter-procedural: walk back through callers of the containing function.
    if containing_function and blueprint_dir is not None:
        inter = _cpp_inter_procedural_guards(
            containing_function, blueprint_dir, asm_dir,
            visited=set(), depth=0, max_depth=max_depth,
        )
        out.extend(inter)

    # Dedupe by (condition, line_no, opcode).
    seen: set = set()
    dedup: List[Dict[str, Any]] = []
    for o in out:
        key = (o.get("condition"), o.get("line_no"), o.get("opcode"))
        if key in seen:
            continue
        seen.add(key)
        dedup.append(o)
    dedup.sort(key=lambda x: x.get("line_no") or 0)
    return dedup


# ---------------------------------------------------------------------------
# Programmatic entry point
# ---------------------------------------------------------------------------


def compute_call_conditions(
    caller_stem: str,
    callee_stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path] = None,
    max_depth: int = 10,
    max_total: int = 30,
) -> Dict[str, Any]:
    """Auto-detect the caller/callee pattern and return per-call-site conditions.

    Importable counterpart of the CLI. Returns:
      {
        "caller": str,
        "callee": str,
        "pattern": "ASM->ASM"|"ASM->C++"|"C++->ASM"|"C++->C++"|"unknown",
        "call_sites": List[{"call_line", "call_instruction", "conditions": [...]}],
      }
    On missing blueprint pair, returns the dict with `pattern="unknown"` and an
    empty `call_sites` list — callers do not need to handle exceptions for
    routine "no edge between these files" cases.
    """
    caller = _stem(caller_stem)
    callee = _stem(callee_stem)

    caller_cpp = blueprint_dir / f"{caller}.cpp.json"
    caller_asm = blueprint_dir / f"{caller}.asm.json"
    callee_cpp = blueprint_dir / f"{callee}.cpp.json"
    callee_asm = blueprint_dir / f"{callee}.asm.json"

    pattern: str = "unknown"
    sites_raw: List[Dict[str, Any]] = []
    caller_kind: Optional[str] = None  # "asm" | "cpp"

    if caller_asm.exists() and callee_cpp.exists() and not callee_asm.exists():
        pattern = "ASM->C++"
        sites_raw = find_asm_to_cpp_callers(caller, callee, blueprint_dir, asm_dir)
        caller_kind = "asm"
    elif caller_asm.exists() and callee_asm.exists():
        pattern = "ASM->ASM"
        sites_raw = find_asm_callers(caller, callee, blueprint_dir, asm_dir)
        caller_kind = "asm"
    elif caller_cpp.exists() and callee_cpp.exists():
        pattern = "C++->C++"
        sites_raw = find_cpp_to_cpp_callers(caller, callee, blueprint_dir, asm_dir)
        caller_kind = "cpp"
    elif caller_cpp.exists() and callee_asm.exists():
        pattern = "C++->ASM"
        # find_cpp_callers drops file/line context; pull edges directly.
        try:
            bp = load_blueprint(caller_cpp)
        except Exception:
            bp = {}
        callee_up = callee.upper()
        for edge in bp.get("call_graph", {}).get("edges", []) if bp else []:
            if (edge.get("target") or "").upper() == callee_up:
                sites_raw.append({
                    "function": edge.get("source"),
                    "line": edge.get("line"),
                    "file": edge.get("file"),
                    "instruction": edge.get("instruction"),
                })
        caller_kind = "cpp"

    if caller_kind is None:
        return {"caller": caller, "callee": callee, "pattern": pattern, "call_sites": []}

    call_sites_out: List[Dict[str, Any]] = []
    if caller_kind == "asm":
        try:
            asm_bp = load_blueprint(blueprint_dir / f"{caller}.asm.json")
        except Exception:
            return {"caller": caller, "callee": callee, "pattern": pattern, "call_sites": []}
        for s in sites_raw:
            line = s.get("line")
            if not line:
                continue
            conds = _asm_call_site_conditions(
                asm_bp, line, max_total=max_total, max_depth=max_depth,
            )
            call_sites_out.append({
                "call_line": line,
                "call_instruction": s.get("instruction"),
                "conditions": conds,
            })
    else:  # cpp caller
        for s in sites_raw:
            line = s.get("line")
            file_field = s.get("file") or ""
            if not (line and file_field):
                continue
            src = Path(file_field)
            if not src.exists() and asm_dir:
                src = asm_dir / Path(file_field).name
            containing_fn = s.get("caller_function") or s.get("function")
            conds = (
                _cpp_call_site_conditions(
                    src, line,
                    containing_function=containing_fn,
                    blueprint_dir=blueprint_dir,
                    asm_dir=asm_dir,
                    max_depth=max_depth,
                )
                if src.exists()
                else []
            )
            call_sites_out.append({
                "call_line": line,
                "call_instruction": s.get("instruction"),
                "conditions": conds,
            })

    return {
        "caller": caller,
        "callee": callee,
        "pattern": pattern,
        "call_sites": call_sites_out,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        description="List conditions in file A that gate a call to file B.",
    )
    ap.add_argument("file_a", help="Caller file (stem or path, .asm or .cpp)")
    ap.add_argument("file_b", help="Callee file (stem or path, .asm or .cpp)")
    ap.add_argument("--blueprint-dir", metavar="DIR")
    ap.add_argument("--asm-dir", metavar="DIR")
    ap.add_argument("--output", metavar="FILE")
    ap.add_argument(
        "--max-depth", type=int, default=10,
        help="Max ASM cross-block / subroutine / inter-procedural recursion depth (default 10).",
    )
    ap.add_argument(
        "--max-total", type=int, default=30,
        help="Max guards reported per call site (default 30).",
    )
    args = ap.parse_args()

    if args.blueprint_dir:
        bp_dir = Path(args.blueprint_dir)
    else:
        bp_dir = _discover_blueprint_dir()
        if bp_dir is None:
            print("ERROR: could not discover blueprint dir; pass --blueprint-dir",
                  file=sys.stderr)
            return 1
    asm_dir: Optional[Path] = (
        Path(args.asm_dir) if args.asm_dir else _discover_asm_dir(bp_dir)
    )

    result = compute_call_conditions(
        caller_stem=args.file_a,
        callee_stem=args.file_b,
        blueprint_dir=bp_dir,
        asm_dir=asm_dir,
        max_depth=args.max_depth,
        max_total=args.max_total,
    )

    if result["pattern"] == "unknown" and not result["call_sites"]:
        print(
            f"ERROR: no blueprint pair for caller='{result['caller']}' "
            f"callee='{result['callee']}' in {bp_dir}",
            file=sys.stderr,
        )
        return 1

    caller = result["caller"]
    callee = result["callee"]
    out_path = (
        Path(args.output)
        if args.output
        else Path(f"{caller}_to_{callee}_conditions.json")
    )
    out_path.write_text(json.dumps(result, indent=2), encoding="utf-8")

    n_sites = len(result["call_sites"])
    n_conds = sum(len(s["conditions"]) for s in result["call_sites"])
    print(
        f"[{result['pattern']}] {caller} → {callee}: "
        f"{n_sites} call site(s), {n_conds} total condition(s). "
        f"Wrote {out_path}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
