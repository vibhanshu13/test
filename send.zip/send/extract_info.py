import msgpack
import sys
import json

def extract_info(file_path, var_name):
    with open(file_path, 'rb') as f:
        data = msgpack.unpack(f)
    
    info = {}
    
    # Check variable lineage
    if 'variable_lineage' in data:
        for key, lineage in data['variable_lineage'].items():
            if var_name in key:
                info['lineage'] = lineage
    
    # Check blocks for usage
    usage_blocks = []
    if 'blocks' in data:
        for index, block in enumerate(data['blocks']):
            if var_name in str(block.get('instructions', [])):
                usage_blocks.append(index)
    info['usage_blocks'] = usage_blocks
    
    # Check symbol aliases
    if 'field_asm_aliases' in data:
        if var_name in data['field_asm_aliases']:
            info['alias'] = data['field_asm_aliases'][var_name]

    print(json.dumps(info, indent=2))

if __name__ == "__main__":
    extract_info(sys.argv[1], sys.argv[2])
