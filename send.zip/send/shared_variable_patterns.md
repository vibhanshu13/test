# Shared Variable Patterns: z/TPF ASM ↔ C++

Complete, verified catalogue of all mechanisms by which data, state, and identity
cross the assembler/C++ boundary in z/TPF codebases.

**Verified against:**
- Source files in `./temp/asm` (74 blueprints: .asm, .mac, .cpp, .hpp)
- IBM z/TPF 1.1.2025 documentation in `./temp/ibm`
- IBM HLASM Language Reference (`asmr1022.pdf`)
- z/Architecture Principles of Operation (`dz9zr006.pdf`)
- z/TPF and z/TPFDF Programming Standards PDF

---

## Category A — Symbol / Name Binding

How a name in one language resolves to code or data in the other.

---

### P1 — `extern "C"` implicit symbol binding

**ASM side:** Any 8-char CSECT/ENTRY name is callable via `ENTRC`, `ENTNC`, or `ENTDC`.

**C++ side:** A function declared `extern "C"` with a name ≤ 8 characters produces
an unmangled external symbol that the linker resolves against the ASM CSECT.

```cpp
// C++ declares the ASM program as a callable function
extern "C" void NB81(TPF_regs*);   // symbol = "NB81    "
extern "C" void XH89(int, dft_fil*, dft_kyl*, dft_kyl*);
```

```asm
* ASM entry point — CSECT name = external symbol
         BEGIN NAME=NB81,VERSION=18,...
```

**Evidence:** `av200100.cpp`, `rh73Iw00.cpp`, `dx740200.cpp`

---

### P2 — `extern "C"` + `asm("SYMBOL")` explicit name override

When the C++ function name does not match the 8-char ASM symbol, `asm("name")`
overrides the linker symbol without renaming the C++ identifier.

```cpp
extern "C" void callXH89(int, dft_fil*, ...) asm("XH89    ");
```

**Evidence:** `dx740200.cpp` (multiple occurrences for long C++ names)

---

### P3 — `#pragma map(cppIdentifier, "ASMNAME")`

IBM z/TPF compiler pragma. Maps a C++ function to an arbitrary 8-char external
symbol. Used when the C++ name and the ASM program name differ.

```cpp
#pragma map(getTms, "PB31")
#pragma map(ckXc,   "TE90")
```

The C++ code calls `getTms(...)` while the linker resolves it to the ASM program `PB31`.

**Evidence:** `rh73Iw00.cpp`

---

### P4 — `#pragma export(symbol)`

Forces the C++ compiler to generate an external symbol for a function, making it
visible for ASM `ENTRC`/`CALLC` calls without requiring `extern "C"` linkage.

```cpp
#pragma export(myFunction)
```

**Evidence:** IBM compiler documentation; used when C++ programs are called from ASM
via `CALLC` with a `CPROC`-defined prototype.

---

### P5 — `__attribute__((visibility("hidden")))`

Restricts a C++ symbol from being exported to the external linker table, preventing
unintended ASM programs from reaching it by name.

```cpp
__attribute__((visibility("hidden"))) void internalHelper() { ... }
```

**Evidence:** IBM z/TPF C/C++ compiler extension; verified in codebase style patterns.

---

### P6 — `BEGIN NAME=...,TV=(...)` — entry point with transfer vector

The ASM `BEGIN` macro defines the CSECT name (= external linker symbol) for the
program. The optional `TV=` parameter lists additional entry points exported from
this CSECT as transfer vectors, enabling multiple named entry points in one object.

```asm
         BEGIN NAME=DA76,VERSION=17,TV=(DA7G)
```

This exports both `DA76` and `DA7G` as callable symbols. C++ can `extern "C"`
declare either name. The IBM migration note states `TV=` is required for z/TPF
migration; BEGIN without TV= produces a standard single-entry CSECT.

**Evidence:** `da76.asm`; IBM "Assembler programs" migration page.

---

## Category B — Register-Based Parameter Passing

Values passed through z/Architecture GPRs R0–R15 at program call boundaries.

---

### P7 — `TPF_regs*` struct — full register frame

z/TPF provides a C struct that mirrors all 16 GPRs. An ASM program loads values
into registers before calling a C++ function; the C++ function receives a pointer
to this struct and reads fields by name.

```cpp
// C++ function called from ASM with registers already set
extern "C" void NB81(TPF_regs* regs) {
    EcbOverlay* ecb = (EcbOverlay*)&ecbptr()->ebw000;
    // regs->r14 holds return address set by ASM caller
}
```

The opposite direction also works: C++ fills a `TPF_regs` and calls an ASM entry
point, passing the struct pointer in R1 as per z/TPF calling convention.

**Evidence:** `av200100.cpp`; IBM z/TPF C/C++ interoperability guidelines.

---

### P8 — `ENTRC`/`ENTNC` inline register pre-load

Before a cross-program branch, the calling ASM program loads specific general
registers (R1, R14, R15 commonly; R0–R15 generally) with parameter values or
addresses. The called program reads those registers directly.

```asm
         LA    R1,WB1XH89RN     POINT TO PARAMETER AREA
         ENTRC XH89             ENTER XH89 WITH R1 POINTING TO PARAMS
```

In C++, the callee receives these as the function's arguments when the entry is
declared via `extern "C"` with matching parameter types, or via a `CPROC`-typed
prototype when called with `CALLC`.

**Evidence:** `xh88.asm`, `ae48.asm`, `da76.asm`; IBM ENTRC/CALLC pages.

---

### P9 — `CREEC`/`creec()` R14/R15 entry creation parameters

`CREEC` creates a new independent ECB and allows passing parameters in R14 and R15
to the newly created entry. The created program begins execution with those register
values already loaded.

```asm
* ASM: create entry for CINFC with R14/R15 set to parameter block addresses
         CREEC PROGNM=CINFC,R14=...,R15=...
```

```cpp
// C++ equivalent
creec("CINFC   ", r14_val, r15_val);
```

This is the primary mechanism for passing initial data to asynchronously created
entries. C++ `creec()` function accepts the same parameters. `credc()` (deferred)
and `cremc()` (immediate ready list) follow the same pattern.

**Evidence:** IBM `Create macros and functions` page; `ztpf-os-c-functions.md`.

---

### P33 — `CALLC`/`CPROC`/`UPROC` — Typed C function invocation from ASM

`CPROC` declares a C++ function prototype inside ASM, specifying the return type and
parameter types. `CALLC` then invokes the declared function, marshaling the named
register values as typed arguments. The linker resolves the symbol against the matching
`extern "C"` C++ definition. `UPROC` includes a library of pre-defined CPROC declarations.

```asm
* Declare C++ function prototype — RETURN=i means int; (p,i) = (pointer,int) params
         CPROC RETURN=i,validate_customer,(p,i)
* Load parameters
         LA    R2,CUSTREC          POINT TO CUSTOMER RECORD (pointer arg)
         LHI   R3,80               RECORD LENGTH (int arg)
* Call C++ function
         CALLC validate_customer(R2,R3)
* Read integer return from R15
         LTR   R15,R15
         BNZ   BAD_CUSTOMER
```

```cpp
// C++ function callable via CALLC
extern "C" int validate_customer(void* custrec, int length) {
    // operate on custrec ...
    return 0;  // 0 = success; non-zero signals error to ASM via R15
}
```

Return value conventions: integer or pointer results in R15; floating-point results
in F0. **R15 cannot be used as a CALLC input register.** Structures cannot be returned
by value; use a pointer.

`CALLC` supports up to 12 parameters. `UPROC` includes a bundle of `CPROC` statements
from a library member, allowing multiple C++ functions to be called without individual
prototype declarations.

This is the preferred cross-language bridge for new z/TPF BAL code because it carries
full type information; ENTxC parameter passing lacks this metadata.

**Evidence:** IBM `asm-c-interoperability.md` (dedicated to CALLC/CPROC/UPROC);
`migration-notes.md` ("Prefer CALLC for explicit C function calls").

---

### P34 — `ENTDC` — Non-returning entry with program level drop

`ENTDC` (Enter and Drop) branches to the named target program **and releases all ECB
data levels belonging to the calling program** before the target begins. Every pointer
into a dropped level becomes invalid the moment ENTDC executes.

This is distinct from `ENTRC` (enters and returns) and `ENTNC` (chains without return
but **preserves** all caller levels so the target can access workblocks directly).

```asm
* Dispatch table: scan 4-char name then ENTDC to the handler segment
         MACRO
&LABEL   FUNCTION &NAME,&SEG
&LABEL   DC    CL4'&NAME'          NAME TO MATCH AGAINST
         ENTDC &SEG                ENTER SEGMENT — DROPS CALLER LEVELS
         MEND
         ...
         B     LU82+4(RGA)         RUNTIME BRANCH INTO TABLE (ENTDC)
```

```asm
* ENTNC chain: levels survive, target sees caller's workblocks
         ENTNC DA78               GO BUILD LG1G1 — D0/D4/WB pointers intact
         ...
         ENTNC XH88               CONTINUE WITH MORE UPDATES — levels survive
```

Variable-lifetime implication: after `ENTDC`, the target must **not** access any
storage that was on the caller's dropped levels (DSECT-mapped areas, getcc blocks,
CE1CRx-saved pointers from those levels). By contrast, after `ENTNC`, all CE1CRx
slots, workblock pointers, and data level blocks remain intact and the chained program
may access them immediately.

**Evidence:** `lu82.asm:125` (ENTDC in dispatch macro); `da76.asm:130` (ENTNC DA78);
`xh82.asm:139` (ENTNC XH88); `xh81.asm:44` (ENTNC XH72); IBM asm-c-interoperability.md.

---

## Category C — ECB Memory Map Sharing

Both ASM and C++ access fixed-offset fields within the Entry Control Block (ECB)
by name, using the same physical byte addresses.

---

### P10 — `CE1CRx` pointer save slots

The ECB contains pointer slots CE1CR0 through CE1CR7 (and CE1CRA, etc.) that are
used to save/restore data-level block addresses across calls.

```asm
         L     R7,CE1CR7(,R9)     LOAD POINTER SAVED IN CR7
         ST    R7,CE1CR7(,R9)     SAVE POINTER INTO CR7
```

```cpp
Da7gl* pDa7gl = (Da7gl*)ecbptr()->ce1cr7;
ecbptr()->ce1cr7 = (uint64_t)ptr;
```

R9 is the ECB base register by z/TPF convention. `CE1CRx` is a DSECT offset in ASM;
`ecbptr()->ce1crx` is the typed C++ accessor.

The full slot assignment table observed across the codebase:

| Slot | Conventional contents | Example |
|------|----------------------|---------|
| CE1CR0 | LG1G1 / BCIS (BasicCreditInputSegment) | `xh82.asm:127`, `dx710000.cpp:324` |
| CE1CR1 | LM1M1 / M1 block | `xh87.asm:207` |
| CE1CR2 | WG1G1 limit file maint / L7e7e CCR | `xh82.asm:123`, `dx710000.cpp:326` |
| CE1CR3 | L0k0k / L6a6a (ISO data variants) | `rh73Iw00.cpp:127,130` |
| CE1CR4 | HUBGL data / output block | `da76.asm:94`, `dx740200.cpp:101` |
| CE1CR5 | FM table / WB limit | various |
| CE1CR6 | LI1I1 log record | `da76.asm:554` |
| CE1CR7 | A7 LREC / primary workblock (Da7gl) | `xh82.asm:125`, `rh73Iw00.cpp:592` |
| CE1CR8 | LG1G1 TYPE-26 data | `da76.asm:538` |
| CE1CR9 | LG1G1 TYPE-16 data | `da76.asm:534` |
| CE1CRA | WB1WB application workblock base | `xh80.asm:99`, `xh82.asm:121` |
| CE1CRE | LI1I1 base pointer | `da76.asm:652` |
| CE1CRF | Extended workblock | `da76.asm:562` |

Slots are program-convention, not hardware-defined; the convention is established by
the program's initialization and documented in workblock DSECT comments.

**Evidence:** `dx740200.cpp`, `xh71.asm`, `xh72.asm`, `rh73Iw00.cpp`, `da76.asm`;
IBM ECB layout conventions.

---

### P11 — `EBW000`/`ebw000` ECB scratch overlay

The first 64 bytes of the ECB working area (`EBW000`, offset 0 from ECB base) are
used as a general-purpose scratch area. Both languages overlay this area with
purpose-specific structs.

```asm
         MVC   EBW000(8,R9),SOMEDATA    WRITE 8 BYTES AT ECB BASE
```

```cpp
EcbOverlay* ecb = (EcbOverlay*)&ecbptr()->ebw000;
```

A common pattern: ASM program sets `EBW000` fields, then branches to a C++ program
that reads them via the `EcbOverlay` struct (or vice versa).

**Evidence:** `av200100.cpp`; IBM ECB conventions.

---

### P12 — `EB0Uxxx`/`EB7Uxxx` Region Zero parameter area

Region Zero is a 64-byte area within the ECB (`EB0U000`–`EB0U03F`) used for
inter-program parameter passing. Both the calling and called program address it via
the same named DSECT offsets or C++ struct fields.

```asm
         MVC   EB0U000(4,R9),=F'1234'  SET PARAMETER IN REGION ZERO
         ENTRC TARGETPGM
```

```cpp
// Called program reads region zero
uint32_t param = *(uint32_t*)&ecbptr()->eb0u000;
```

Region Zero survives the program entry because both programs share the same ECB.

**Evidence:** `av200100.cpp`, multiple ASM files; IBM ECB map conventions.

---

### P13 — `CE1DTn` detach state byte

ECB fields `CE1DT3`–`CE1DT9` are per-level detach state bytes. When a data-level
block is detached (see P15), this byte is set to indicate the level is free; the
receiving program tests it before attaching.

```asm
         CLI   CE1DT6,X'00'     IS LEVEL 6 DETACHED?
         ATTAC D6               RE-ATTACH IF DETACHED
```

```cpp
if (ecbptr()->ce1dt6 == 0x00) {
    attac(D6);
}
```

Used as a shared flag bit between coordinating programs that pass storage via
DETAC/ATTAC (P15).

**Evidence:** `xh88.asm` (CE1DT6 test before ATTAC D6); IBM ECB field map.

### P41 — `CE1USA` + `REGNA` — ECB user save area for context passing

`CE1USA` is an ECB pointer to the application user save area — a contiguous byte buffer
(typically 64–128 bytes) distinct from both `EBW000` (P11) and `EB0U000` (P12).
Programs use it to save and restore application-specific context across subroutine calls
or cross-program transfers, directly writing typed data at fixed offsets.

```cpp
// C++: save context into CE1USA at fixed offsets
char tempSaveArea[1432];
memcpy(tempSaveArea, (ecbptr()->ce1usa), sizeof tempSaveArea);   // save
*ecbptr()->ce1usa         = 'S';                                 // type indicator
memcpy(ecbptr()->ce1usa + 1,  &amexCmNumber, sizeof(AmexCmNumber)); // account
memcpy(ecbptr()->ce1usa + 16, cscBlock, 12);                     // context block
```

```asm
* ASM: REGNA macro provides named structured access to the same area
         REGNA 2              DECLARE/ACCESS USER REGION 2 (EB2USER)
* COPY, FLIP, and CLEAR operations between regions:
         REGNA COPY,1,2       COPY REGION 1 INTO REGION 2
         REGNA FLIP,0,1       EXCHANGE REGIONS 0 AND 1
         REGNA CLEAR,3        ZERO OUT REGION 3
```

`REGNA` declares named user regions within the CE1USA area — `EB0USER` through
`EB7USER`, each 64 bytes — and provides COPY, FLIP, and CLEAR operations between them.
Both ASM and C++ read and write the same physical bytes; ASM uses REGNA-declared names,
C++ uses `ecbptr()->ce1usa` with byte offsets or `memcpy`.

**Evidence:** `dw712100.cpp:1420–1424`; `cf580100.cpp:78–82`; `regna.mac` (REGNA macro
definition with EB0USER–EB7USER regions); 15 ASM files using REGNA.

---

## Category D — Working Storage and Data Level Sharing

Mechanisms for allocating, owning, and transferring heap-like storage blocks
that both languages address via pointer.

---

### P14 — `GETCC`/`getcc()` data level block

`GETCC` (ASM) and `getcc()` (C++) allocate a working storage block attached to a
specific ECB data level (D0–DF). After allocation, both languages access the same
block by casting a pointer to the appropriate DSECT/struct type.

```asm
         GETCC D7,L4096         ALLOCATE 4096-BYTE BLOCK ON LEVEL 7
* R14 now points to the allocated block
         L     R5,CE1CR7(,R9)   RETRIEVE SAVED POINTER
         USING DA7GL,R5         ESTABLISH DSECT ADDRESSABILITY
```

```cpp
Da7gl* pDa7gl = (Da7gl*)getcc(D7);           // allocate
Da7gl* pDa7gl = (Da7gl*)ecbptr()->ce1cr7;    // retrieve saved
```

After `GETCC`, the block address is in R14 (ASM) or the return value (C++). Programs
conventionally save this pointer in a `CE1CRx` ECB slot (P10) for later retrieval.
`relcc(Dn)`/`RELCC Dn` releases the block; `relcc()` invalidates all pointers to it.

**Evidence:** `dx740200.cpp`, `dx730000.cpp`, `da78.asm`, `xh71.asm`.

---

### P15 — `DETAC`/`ATTAC` + `detac()`/`attac()` — storage ownership transfer

`DETAC Dn` / `detac(Dn)` detaches a working storage block from an ECB data level
without freeing it. The block remains in memory. `ATTAC Dn` / `attac(Dn)` attaches
a previously detached block to a level in the current ECB.

This is the mechanism for transferring exclusive ownership of a large data block
between programs (or between invocations of the same program):

```asm
* Program A: detach before passing control
         DETAC D6,CHECK=NO           DETACH LI1I1 DATA FROM LEVEL 6
         OI    WB1DTC1,WB#D6         SET INDICATOR: D6 IS DETACHED
         ENTRC XH88                  ENTER XH88; D6 IS DETACHED IN ECB
```

```asm
* Program B (XH88): check indicator, re-attach
         CLI   CE1DT6,X'00'          DETACHED BLOCK ON LEVEL 6?
         ATTAC D6                    ATTACH LI1I1 LOG RECORD
         OI    WB1DTC1,WB#D6         INDICATE LEVEL 6 ATTACHED
```

```cpp
// C++ equivalent
detac(D1);     // detach level 1 block before sub-call
// ... call other code ...
attac(D1);     // re-attach
```

The `WB1DTC1`/`WB#D6` bitflag (in the workblock DSECT — P19/P21) serves as the
shared indicator that coordinates attach/detach state between programs (see also P13).

**Evidence:** `ae48.asm`, `xh71.asm`, `xh88.asm`, `da78.asm`, `dp710100.cpp`.

---

### P16 — `RELCC`/`relcc()` + `DETAC`/`detac()` cross-program storage lifetime

`DETAC`+`ATTAC` (P15) enables ownership transfer. A complementary pattern is
lifetime extension: a program DETACs a block before `RELCC`ing a data level,
preserving the block so the next invocation can pick it up.

The IBM convention (from `storage-and-ecb-lifecycle.md`) is:
- `GETCC` → allocate; pointer in R14
- Work with block via DSECT/struct
- `DETAC` → unlink from level (block survives)
- `ATTAC` in another program → take ownership
- `RELCC` when fully done → free the block

Both ASM and C++ participate in this lifecycle using the same macro/function names.

`CRUSA Sn=level` is a shorthand macro that releases one or more ECB data levels
simultaneously (equivalent to multiple sequential `RELCC` calls): `CRUSA S0=6`
releases level 6; `CRUSA S0=2,S1=7` releases levels 2 and 7 in a single macro
invocation. Found in 7 ASM files as cleanup before re-attachment sequences.

**Evidence:** `ae48.asm` (DETAC DE / ATTAC DE pattern); IBM storage lifecycle docs;
`xh83.asm`, `da76.asm`, `da78.asm`, `xh80.asm`, `xh87.asm`, `xh93.asm` (CRUSA).

---

### P37 — `FLIPC`/`flipc()` — Level content swap

`FLIPC D0,D4` atomically exchanges the contents (CBRW ownership) of two ECB data
levels. After the swap, the block previously on D0 is now on D4 and vice versa.
In C++ the equivalent is `flipc(D0, D4)`. This is bidirectional and distinct from
`DETAC`/`ATTAC` (P15), which is a unidirectional ownership handoff.

```asm
         FLIPC D0,D4          MOVE HUBGL FROM D0 TO D4 (SWAP)
         LEVTA LEVEL=4,NOTUSED=DA7_9200  IS LEVEL 4 NOW OCCUPIED?
         L     R3,CE1CR4      ACCESS BLOCK NOW ON D4
```

```cpp
flipc(D0, D6);          // exchange levels 0 and 6
flipc(D6, DE);          // exchange levels 6 and E
// block that was on D6 is now addressable as level E
memcpy(&ecbptr()->ce1fme,
       &tdr->standardTmsHeader.forwardChainAddress,
       sizeof tdr->standardTmsHeader.forwardChainAddress);
```

**Evidence:** `da76.asm` (multiple); `dx710000.cpp:321`; `dx740200.cpp:570`.

---

### P38 — `LEVTA`/`levtest()` — Level occupancy test

`LEVTA LEVEL=n,NOTUSED=label` branches to `label` if ECB data level `n` is currently
empty (no allocated block attached). `LEVTA LEVEL=n,INUSE=label` branches if the
level already holds a block. Used for conditional storage allocation and coordination
logic between programs that may or may not have pre-allocated a level.

The C++ equivalent is `levtest(Dn)`, which returns non-zero (truthy) if the level is
**in use** and zero if it is empty. Both forms test the same ECB level occupancy state.

```asm
         LEVTA LEVEL=0,NOTUSED=DA7_9000  HUBGL ON D0? BRANCH IF NOT
         L     R3,CE1CR0                 YES — USE THE BLOCK ON D0
         ...
DA7_9000 EQU   *                         NO BLOCK ON D0 — ALLOCATE
         GETCC D0,L4                     ALLOCATE NOW
```

```asm
         LEVTA LEVEL=6,INUSE=XH851130   ALREADY USING LEVEL 6?
         GETCC D6,L4                    NOT IN USE — ALLOCATE
XH851130 EQU   *                        ALREADY IN USE — SKIP ALLOC
```

```cpp
// C++ equivalent — levtest returns non-zero if level in use
if (!levtest(D6)) {
    // level 6 is empty — allocate
    GlobalLimitsLogRecord* rec = (GlobalLimitsLogRecord*)getcc(D6, ...);
}

if (levtest(D4) != 0) {
    // level 4 already occupied — retrieve existing block
    Hubgl* hubgl = (Hubgl*)ecbptr()->ce1cr4;
}
```

Both forms are used extensively to avoid double-allocating a level when a program
may be re-entered or called after a sibling program already allocated the level.

**Evidence:** `da76.asm` (10+ usages, NOTUSED= and INUSE= variants);
`dx710000.cpp:318`; `dx740200.cpp:179,392,395,413`; `rh73Iw00.cpp:120,525,593`;
`av200100.cpp:82`; `dp710100.cpp:114,125,488,494`; `dh720200.cpp:130`.

---

### P39 — `GETFC`/`RELFC` — File-address pool allocation

`GETFC` obtains a file-pool address (stored in the FARW — File Address Reference
Word), which is used to "file" (persist) a core storage block to the file pool.
`RELFC` releases the file-pool address. This is distinct from `GETCC`/`RELCC`
(P14/P16), which manages working-storage core blocks (CBRW).

```asm
         GETCC D2,L4          ALLOCATE CORE BLOCK (CBRW)
         LR    R6,R14         R6 → CORE BLOCK
         ...FILL BLOCK...
         GETFC                OBTAIN FILE-POOL ADDRESS (FARW) INTO R14
         ST    R14,FILEADDR   SAVE FILE ADDRESS
         FILEC                PERSIST CORE TO FILE (CBRW + FARW)
         RELFC                RELEASE FILE-POOL ADDRESS
         RELCC D2             RELEASE CORE BLOCK
```

Both CBRW (core block) and FARW (file address) must be managed together for
programs that both work with data in memory and persist it to file. Release order
matters: file the core before releasing the FARW, then release core.

**Evidence:** IBM `ztpf-system-macros.md` ("Obtains file pool address… FARW/file-address
ownership"); IBM storage lifecycle docs.

---

### P40 — `RCRFC`/`tpf_rcrfc()` — Combined core and file release

`RCRFC Dn` / `tpf_rcrfc(level)` atomically releases both the CBRW (working-storage
core block) and the FARW (file-pool address) for the specified data level in a
single operation. It combines `RELCC` + `RELFC` (P39) into one call, providing
paired lifetime cleanup for programs that have both allocated a block and obtained
a file-pool address.

```asm
         RCRFC D1             RELEASE BOTH CBRW AND FARW FOR LEVEL 1
```

```cpp
tpf_rcrfc(D1);               // C++ equivalent
```

The key implication: after `RCRFC`, all pointers to the level's core block and all
references to its file-pool address are simultaneously invalid. This must be used
when both resources were obtained together and must be released atomically (e.g.,
to avoid a state where the core block is freed but the file address is still held).

**Evidence:** IBM `ztpf-system-macros.md` ("Releases both core block and file address…
combines RELCC and RELFC behavior"); IBM `storage-and-ecb-lifecycle.md`.

---

## Category E — Database Context Sharing

z/TPFDF database contexts (SW00SR / DBIFB) are shared objects that both languages
open, pass, and close using equivalent constructs.

---

### P17 — `DBOPN`/`dfopn()` → `SW00SR`/`dft_fil*` file handle

`DBOPN REF=NAME` (ASM) opens a subfile and allocates a DBIFB slot; the SW00SR
register (R3 by convention) holds the context address. `dfopn()` (C++) returns a
`dft_fil*` pointer to the same structure.

```asm
         SW00SR REG=R3          ESTABLISH R3 AS SW00SR BASE
         DBOPN REF=CR21AEFM,REG=R7,HOLD,ALG=EBW000
         DBRED REF=CR21AEFM
         CLI   SW00RTN,#ACPDBOK    LREC FOUND?
         DBCLS REF=CR21AEFM
```

```cpp
dft_fil* cr21aeFile = dfopn_acc("CR21AE  ", CR21AEI, DFOPN_HOLD);
dft_kyl keys;
dfkey(cr21aeFile, &keys);
Cr21LRec61* rec = (Cr21LRec61*)dfred(cr21aeFile, DFRED_BEGIN);
if (rec != nullptr) {
    dfmod(cr21aeFile);
}
dfcls(cr21aeFile, DFCLS_RELEASE);
```

`SW00RTN` (ASM) and the return value/null check (C++) are the equivalent status
indicators after each read operation.

`dfopn_acc()` is a named variant of `dfopn()` that takes a separate 2-character
subfile access-code parameter in addition to the file name, index ID, and flags:

```cpp
// Standard form
dft_fil* file = dfopn("CR21AE  ", CR21AEI, DFOPN_HOLD);

// Access-code variant: extra "AC" parameter selects a specific access path
dft_fil* file = dfopn_acc("CR21AE  ", "AC", CR21AEI, DFOPN_HOLD);
```

Use `dfopn_acc` whenever the subfile has multiple named access paths and the caller
must select one explicitly. Both forms return a `dft_fil*` and the remainder of the
API (`dfred`, `dfmod`, `dfcls`, etc.) is identical.

**Evidence:** `xh71.asm`, `xh72.asm`, `dw710000.cpp`, `dw780000.cpp`, `xh89000.cpp`;
`dw710500.cpp:3274–3276`, `dw780000.cpp:3662–3664` (`dfopn_acc` call sites).

---

### P18 — `DBIFB REF=` — SW00SR context retrieval and passing

`DBIFB REF=NAME` retrieves the SW00SR address for an already-open subfile into R3,
enabling the context to be stored in a parameter area and passed to another program.

```asm
         DBIFB REF=CR21AEFM        GET CR21AEFM SW00SR ADDRESS INTO R3
         ST    R3,WB1XH89SW        STORE IN WORKBLOCK FOR XH89
         LA    R1,WB1XH89RN        POINT TO FULL PARAMETER AREA
         ENTRC XH89                ENTER XH89 WITH PARAMETERS IN WB
```

The called program (XH89) receives the SW00SR address and can use it for further
DB operations on the already-open file. This is the ASM equivalent of C++
passing a `dft_fil*` as a function parameter.

`DBIFB REF=A,NEWREF=B` additionally renames the open reference: the same open
subfile becomes addressable under a different REF name within the same program,
enabling multiple code sections to share a single open DB context.

**Evidence:** `xh88.asm` (DBIFB + ST R3,WB1XH89SW + ENTRC XH89).

---

### P19 — `DBSPA`/`dfspa()` + `SW00WKA`/`file->sw00wka` — DB-managed work area

`DBSPA REF=file` / `dfspa(file, fill, size)` allocates an initialized work area
scoped to the open DB context. The address of this area is stored in `SW00WKA`
(ASM) or `file->sw00wka` (C++). Maximum size is 4069 bytes. There is exactly one
space area per open SW00SR slot.

```asm
         DBSPA REF=IRT1DF,SPACEF=(70,R5,=C'*')
         MVC   IRT1SIZ,=H'70'
         MVI   IRT1KEY,X'80'
         DBADD REF=IRT1DF,NEWLREC=IRT1REC
```

```cpp
dfspa(file, 0x5c, 70);
struct irt1df* new_lrec = file->sw00wka;
dfadd(file, DFADD_NEWLREC, 0, new_lrec);
```

This work area is shared in the sense that both the ASM and C++ forms of the same
operation use the same DB-managed backing memory. It must not be used as a
long-lived heap object; its lifetime ends at `dfcls`/`DBCLS`.

**Evidence:** IBM `ztpfdf-db-macros.md`, `ztpfdf-c-functions.md`.

---

### P20 — `dft_kyl`/`dft_kyl_ext` key list — shared selection parameters

Key list structures are built by the calling code and passed to `dfkey()`/`DBKEY`
or inline to `dfred()`/`DBRED`. In C++ the type is `dft_kyl` (standard) or
`dft_kyl_ext` (extended). In ASM, the key list is a storage area filled via
`DBSETK` directives.

```cpp
dft_kyl keys;
df_nbrkeys(&keys, 2);
df_setkey(&keys, 1, offsetof(Cr21, field1), 4, DF_EQ, arg1, 0, DF_UPORG, DF_CHAR);
dfkey(cr21aeFile, &keys);
dft_rec* rec = dfred(cr21aeFile, DFRED_BEGIN);
```

```asm
         DBSETK BASE=R5,KEYNUM=1,DIS=I/2,LEN=I/1,SEA=ARG1,ID1=#DF_UP
         DBKEY  REF=CUSTDF,KEYLIST=KEYAREA
         DBRED  REF=CUSTDF
```

The key list is a shared input parameter: both languages build and consume the
same logical structure to select LREC records. Active keys persist after `DBKEY`
until replaced or deactivated.

**Evidence:** `dw780000.cpp` (`dft_kyl`, `dft_kyl_ext`), `dw710000.cpp`, `xh71.asm`; IBM keyed LREC access docs.

---

### P35 — `DBMOD`/`dfmod()` — In-place current LREC mutation

After `DBRED`/`dfred()` returns, the current LREC resides in main storage. Both ASM
and C++ may overwrite bytes of this live buffer directly — ASM via MVC/MVI/OI/NI/SI
on DSECT-named fields, C++ via typed struct member assignments. `DBMOD REF=`/`dfmod()`
marks the record dirty for deferred write without re-reading it.

```asm
* ASM: read → overwrite fields in live LREC → mark dirty
         DBRED REF=CR21AEFM            READ A7 LREC
         CLI   SW00RTN,#ACPDBOK        FOUND?
         BNE   XH961390                 N — SKIP
         NI    CR21ACST1,X'FF'-X'80'   CLEAR BIT IN LIVE LREC BUFFER
         MVI   CR21GLBASICO,C'Y'        SET FIELD IN LIVE LREC BUFFER
         DBMOD REF=CR21AEFM            MARK DIRTY — SCHEDULE WRITE
```

```cpp
// C++: read → overwrite struct fields → mark dirty
Cr21LRec* rec = (Cr21LRec*)dfred(cr21aeFile, DFRED_CURRENT);
if (rec != nullptr) {
    rec->fixedData.glosSuppPresent = LRecHeader::No;  // direct write to live buffer
    rec->dataExistIndicator5.spare &= 0xF7;           // bit clear in live buffer
    dfmod(cr21aeFile);                                 // mark dirty
}
```

**Critical constraint (IBM migration note):** `DBMOD`/`dfmod()` must be issued before
any intervening `DBRED`/`dfred()` that advances the current pointer, and before
`DBCLS`/`dfcls()`. Reading a second record invalidates the first — `DBMOD` on a
stale pointer is silently incorrect.

`DBMOD` is valid only for **fixed-length** in-place field changes. For records whose
**length** changes (variable-length LRECs), use `DBREP`/`dfrep()` instead. ASM
`xh90.asm:275` documents this explicitly: "we cannot merely do a DBMOD on the LREC"
for variable-length sections.

`DBDEL REF=X,ALL` / `dfdel(file, DFDEL_ALL)` deletes the current LREC (and all
additional logical records under the same key when `ALL` is specified). Like `DBMOD`,
`DBDEL`/`dfdel` must be called while the deleted record is still current. After
deletion the current-record pointer is cleared; any subsequent `DBRED`/`dfred`
starts a fresh scan.

```cpp
// Delete current record (single) vs. all matching records
dfdel(glAccountFilePtr, 0);           // delete current LREC only
dfdel(glAccountFilePtr, DFDEL_ALL);   // delete all LRECs for current key
```

```asm
         DBDEL REF=CR21AEFM,ALL,      DELETE ALL LRECs FOR CURRENT KEY  +
               KEYFIELD=CR21AEKEY
```

**Evidence:** `xh96.asm:441,507,561`; `xh87.asm:446`; `da78.asm:2103`;
`xh93.asm:941,978,1434`; `xh890000.cpp:236,269`; `dw712100.cpp:1786`;
`dw780000.cpp:3712,3743`; migration-notes.md ("Current LREC: In-place updates require
DBMOD before current record moves"); `xh890000.cpp:142,240` (`dfdel`);
`xh96.asm:363`; `xh93.asm:1442` (`DBDEL`).

---

### P36 — `TXBGC`/`tx_begin` + `TXCMC`/`tx_commit` + `TXRBC`/`tx_rollback` — Transaction commit scope

`TXBGC`/`tx_begin()` opens a z/TPFDF commit scope. All DB opens, reads, updates, and
closes inside the scope are tentative: other ECBs cannot see the changes until the
root scope commits with `TXCMC`/`tx_commit()`. `TXRBC`/`tx_rollback()` discards all
DB side effects inside the scope without affecting already-computed in-memory state.

```asm
* ASM: commit-scoped update
         TXBGC
         DBOPN REF=ACCTDF,HOLD,ALG=ACCTKEY
         DBRED REF=ACCTDF
         MVC   ACCTSTAT,=C'C'          MODIFY FIELD IN LIVE LREC
         DBMOD REF=ACCTDF
         DBCLS REF=ACCTDF
         TXCMC
```

```cpp
// C++ equivalent
tx_begin();
dft_fil* file = dfopn("ACCTDF  ", ACCTDFI, DFOPN_HOLD);
Acct* rec = (Acct*)dfred(file, DFRED_BEGIN);
if (rec) { rec->status = 'C'; dfmod(file); }
dfcls(file, 0);
tx_commit();
```

Shared-variable implication: all code — ASM or C++ — executing within the same ECB
shares a single commit-scope context. A z/TPFDF file opened inside a scope **must**
be closed within the same scope (IBM programming convention). Nested scopes delay
visibility to outer ECBs until the root scope commits. `TXRBC`/`tx_rollback()` reverts
only DB side effects; in-memory mutations to LREC buffers already copied into working
storage are unaffected by rollback.

`TXSPC`/`tx_suspend_tpf` and `TXRSC`/`tx_resume_tpf` suspend and resume the
transaction context; code between suspend and resume runs outside the scope. This
is an advanced pattern: mark any TXSPC/TXRSC pair for manual review if found around
DB operations, as DB opens inside the suspended region may not be scope-bound.

**Evidence:** IBM `transactions-and-commit-scopes.md`; IBM "Defining a commit scope"
and "z/TPF transaction services" documentation.

---

### P43 — `FIWHC`/`fiwhc()` — Find with hold and core allocation

`FIWHC` (Find with Hold, Core) performs a file read **and** simultaneously allocates
a core storage block on the specified ECB data level, placing the retrieved record
in that block. The C++ function `fiwhc(level)` returns a typed pointer to the
newly allocated, populated core block.

This is a combined I/O + allocation pattern distinct from the two-step sequence
`GETCC` + `DBOPN`/`DBRED`. The storage allocation is managed by the operation
itself; the caller does not issue a separate `GETCC`.

```cpp
// C++: FIWHC — allocates core on level DE and reads record into it
L3t3t* tdr = (L3t3t*)fiwhc(DE);
if (tdr != nullptr) {
    // tdr points to the newly allocated block containing the read record
    L8uScrollingData* l8uScroll = (L8uScrollingData*)
        (tdr->standardTmsHeader.forwardChainAddress);
    // ... use tdr fields ...
    flipc(D6, DE);          // may swap level to transfer ownership
}
```

```asm
* ASM: FINDC/FINHC/FINWC/FIWHC macros follow the same pattern
         FINHC LEVEL=DE,FILE=TDRFILE    FIND WITH HOLD + CORE
         LR    R5,R14                   R14 = POINTER TO ALLOCATED BLOCK
         USING L3T3T,R5                 ESTABLISH ADDRESSABILITY
```

Return convention: R14 (ASM) or function return value (C++) points to the allocated
block. If the record is not found, R14/return is zero.

`FINDC` (no hold), `FINHC` (hold), `FINWC` (write), and `FIWHC` (hold+write) are
variants with different hold and write-intent semantics but the same combined
I/O+allocation model.

**Evidence:** `dx740200.cpp:502` (`tdr = (L3t3t*)fiwhc(DE)`); IBM `ztpf-system-macros.md`
("May allocate storage on a data level before read starts. Parser should model both
I/O read and allocation").

---

### P44 — `DBWAIT`/`dfwait()` — Prefetch completion synchronization

When `DBOPN REF=X,PREFETCH=PRIME` (ASM) or `dfopn(..., DFOPN_PREFETCH_PRIME)` (C++)
is used, z/TPFDF begins a background prefetch of the prime block. The program must
call `DBWAIT REF=X` / `dfwait(file)` before any subsequent z/TPFDF API call on that
file to ensure the prefetch I/O has completed.

```asm
         DBOPN REF=CUSTDF,HOLD,PREFETCH=PRIME,ALG=ACCTKEY
         * ... do other work while I/O runs in background ...
         DBWAIT REF=CUSTDF            BLOCK UNTIL PREFETCH COMPLETES
         DBRED REF=CUSTDF             NOW SAFE TO READ
```

```cpp
dft_fil* file = dfopn("CUSTDF  ", CUSTDFI, DFOPN_HOLD | DFOPN_PREFETCH_PRIME,
                      DFOPN_ALG, acctKey);
// ... do other work ...
dfwait(file);             // synchronize: wait for prefetch I/O
Cust* rec = (Cust*)dfred(file, DFRED_BEGIN);
```

The shared-variable aspect: `DFOPN_PREFETCH_PRIME` sets a pending-I/O flag in the
SW00SR context block. `DBWAIT`/`dfwait()` tests and waits on that same flag.
Omitting `DBWAIT` means reading data that may not yet be in memory.

**Evidence:** IBM `db-open-read-update-close.md` ("If PREFETCH=PRIME appears, IBM
indicates a later DBWAIT/dfwait is required before another z/TPFDF API for that
subfile. Add a TODO if DBWAIT is absent").

---

## Category F — Structural Layout Identity

The same bytes in memory are interpreted as the same structure by both ASM and C++
through byte-exact layout equivalence.

---

### P21 — DSECT ↔ `#pragma pack(1)` struct

A z/TPF DSECT (Data Section) defines a data structure as a set of named offsets
without allocating storage. A C++ header mirrors the identical layout using
`#pragma pack(1)` (byte alignment) so the struct fields map to the same byte
offsets.

```asm
* da7gl.mac — DSECT definition
DA7GL    DSECT
DA7GREG  DS    CL4         R-register save area
DA7GDAT  DS    PL3         3-byte packed decimal date
         ...
```

```cpp
// ccda7gl.hpp — mirror struct
#pragma pack(1)
struct Da7gl {
    char     da7greg[4];       // same offset as DA7GREG
    decimal<5,0> da7gdat;      // same 3 bytes as DS PL3
    ...
};
#pragma pack()
```

ASM addresses the structure via `USING DA7GL,Rx` (Rx = base pointer). C++ casts
a `void*` to `Da7gl*`. Both read/write the identical bytes.

**Evidence:** `da7gl.mac` + `ccda7gl.hpp`; `lg1lg1.mac` + `cclg1g1.hpp`.

---

### P22 — `DS PLn` ↔ `decimal<N,0>` — packed decimal field

IBM packed decimal (BCD) occupies `n` bytes and stores `(2n-1)` digits plus a sign
nibble. The ASM declaration `DS PL11` (11 bytes = 21 decimal digits) maps to
the C++ template type `decimal<21,0>`.

```asm
DA7GAMT  DS    PL11        21-digit packed decimal amount
```

```cpp
decimal<21,0> da7gamt;     // same 11 bytes, same encoding
```

This is the most common numeric shared-variable pattern in financial z/TPF code.
Reading one from ASM and writing the other in C++ (or vice versa) works without
any conversion because the bit pattern is identical.

**Evidence:** `da7gl.mac` / `ccda7gl.hpp` (PL3, PL8, PL11 fields).

---

### P23 — `DS XL4` ↔ `__ptr32_t` — 31-bit pointer field

A 4-byte field in a DSECT that holds a 31-bit address maps to `__ptr32_t` in the
C++ struct. This is required because z/TPF has historically used 31-bit addressing
for some storage areas.

```asm
DA7GPTR  DS    XL4         31-bit pointer to something
```

```cpp
__ptr32_t da7gptr;         // 4 bytes, IBM compiler 31-bit pointer type
```

Storing a C++ pointer into this field via `__ptr32_t` and reading it back in ASM
via `L Rx,DA7GPTR(Rb)` (31-bit load) accesses the same value.

**Evidence:** `da7gl.mac` / `ccda7gl.hpp`; IBM `__ptr32_t` documentation.

---

### P24 — `EQU` bitmask ↔ C++ bitfield struct — flag bytes

Named bit constants defined in ASM via `EQU` are equivalent to bitfield members in
the matching C++ struct. Both describe the same byte at the same offset.

```asm
WB#M1NFND EQU  X'80'      bit 0: M1 basic not found
WB#OTB    EQU  X'40'      bit 1: OTB account
WB1SW1    DS   XL1        flag byte at defined offset
```

```cpp
struct Wb1sw1Flags {
    uint8_t m1NotFound : 1;   // bit 7 (MSB)
    uint8_t otb        : 1;   // bit 6
    ...
};
```

ASM tests: `TM WB1SW1,WB#OTB` / `OI WB1SW1,WB#OTB` / `NI WB1SW1,X'FF'-WB#OTB`.
C++ tests: `if (flags.otb)` / `flags.otb = 1` / `flags.otb = 0`.

**Evidence:** `wb1wb.mac`, `xh71.asm` (WB1SW1/WB1SW6/WB1DTC1 flag bytes); `da7gl.mac`.

---

### P25 — DSECT `ORG *-n` ↔ C++ `union` — overlapping field variants

When a DSECT uses `ORG *-n` to rewind the location counter, it creates overlapping
field definitions at the same byte offset. The C++ equivalent is a `union` inside
the struct.

```asm
LG1G1    DSECT
LG1G1REC DS   CL4             common header
         ORG  LG1G1REC        rewind to record start
LG1GCREC DS   CL100           CAS GL variant at same offset
         ORG  LG1G1REC
LG1GTMP  DS   CL80            temp limits variant at same offset
```

```cpp
struct Lg1g1 {
    union G1Data {
        HeaderRecord         hdr;
        CasGLRec             cas;
        TempLimitsRecord     tmp;
        ...
    } data;
};
```

**Evidence:** `lg1lg1.mac` / `cclg1g1.hpp` (multiple record type variants in one union).

---

### P26 — Repeating DSECT group ↔ C++ struct array

When a DSECT contains a repeated block of fields (defined by `DS nCL(size)` or
explicit repetition), the C++ mirror uses a fixed-size array of the element struct.

```asm
LG1CYCL  DS   46CL(LG1CYCLEN)   46 cycle-limit records
```

```cpp
struct CycleLimitRecord { ... };
CycleLimitRecord cyclicalLimitsBySe[46];
```

Both ASM and C++ index into the array using the same stride (`LG1CYCLEN` bytes).

**Evidence:** `lg1lg1.mac` / `cclg1g1.hpp` (`cyclicalLimitsBySe[46]`, `mccGroupLimits[50]`, `tempLimitSlots[43]`).

---

### P27 — DSECT `SUFFIX=` ↔ two C++ typed pointer convention

The `SUFFIX=` parameter on a DSECT or COPY statement generates a secondary name
variant (e.g., `HUBGL` and `HUBGL_B`), allowing two distinct pointer types to the
same underlying structure. The C++ header defines both:

```asm
         COPY  HUBGL,SUFFIX=_B   generates HUBGL and HUBGL_B symbols
```

```cpp
// Two distinct pointer types to the same memory layout
struct Hubgl   { ... };
struct Hubgl_B { ... };   // same bytes, different declared type
```

Callers use whichever type is appropriate for their intent (e.g., one for input
frame, one for output frame, at different CE1CRx slots).

**Evidence:** `ccda7gl.hpp`, `dx740200.cpp`; IBM DSECT SUFFIX= naming convention.

---

## Category G — Global and System-Wide Storage

Named global storage fields accessible by both languages through system-provided
headers or base registers.

---

### P28 — `GLOBZ` `@MMU...` ↔ `tpfglbl.h` — system global storage

`GLOBZ` establishes a base register pointing to the z/TPF global storage area.
Named offsets beginning with `@MMU` are DSECT symbols for fields within that area.
C++ includes `tpfglbl.h` (or equivalent) which provides the same fields as typed
struct members.

```asm
         GLOBZ                   LOAD GLOBAL STORAGE BASE REG
         MVC   @MMUFOO(4),DATA   ACCESS GLOBAL FIELD BY NAME
```

```cpp
#include <tpfglbl.h>
tpfglbl.mmufoo = value;         // same global field
```

Both languages read and write the same system-global memory locations. Changes in
C++ are immediately visible to ASM programs running in the same ECB partition.

The ASM-side mechanism for including global storage DSECT definitions is
`COPY TPFGLB` — a standard HLASM COPY statement that pulls in the global storage
DSECT layout member. This is the exact ASM equivalent of `#include <tpfglbl.h>` in
C++: both expose the same named field symbols to their respective language.

```asm
         COPY  TPFGLB          INCLUDE GLOBAL STORAGE DSECT DEFINITIONS
         GLOBZ                  LOAD GLOBAL BASE REG
         MVC   @MMUFOO(4),DATA  NOW ACCESS GLOBAL FIELD
```

**Evidence:** IBM z/TPF Global Storage conventions; `nb81.asm:396` (`COPY TPFGLB`);
pattern confirmed in ASM files using `GLOBZ`.

---

### P29 — `ALASW` application-level work area

`ALASW` is a DSECT defining the application-level switch/work area, a region of
ECB memory reserved for application-specific flags and state. Both ASM programs
and C++ code access named fields within `ALASW` to communicate state.

```asm
         USING ALASW,Rx          ESTABLISH ALASW ADDRESSABILITY
         OI    ALAFLAG1,AL#DONE  SET APPLICATION FLAG
```

```cpp
Alasw* pAla = (Alasw*)ecbptr()->ce1alasw;
pAla->alaflag1 |= AL_DONE;
```

**Evidence:** Referenced across multiple ASM modules; IBM z/TPF application area conventions.

---

### P30 — `CINFC` system state information

`CINFC` provides access to system configuration and state information. ASM calls
it as a subroutine; C++ calls the equivalent C function. The data returned is
placed in a shared parameter area (typically ECB region zero or a workblock field).

```asm
         LA    R1,PARMAREA       POINT TO CINFC PARAMETER BLOCK
         ENTRC CINFC
```

```cpp
creec("CINFC   ", r14_parm, r15_parm);   // or direct call
```

**Evidence:** `ae48.asm`; IBM system call conventions.

### P42 — `TMSMA` — TMS table lookup with shared work area

`TMSMA` (Table Management System Macro) performs an in-memory table lookup. The
macro requires a **32-byte work area** (`WK_TMS DS CL32` in the workblock DSECT)
to hold its input/output parameters. The TMSMA result indicator is returned in
`EBL8URTN` (ECB field), which both ASM and the calling program test to determine
whether the lookup succeeded.

```asm
* Workblock definition reserves the TMSMA work area
WK_TMS&A    DS   CL32                    TMSMA WORK AREA

* Usage: set up key in LGMKEY (a DSECT field in WK_TMS area), then call TMSMA
         TMSMA GM,                        TMS TABLE ID = GM (GLOS MARKET)    X
               XH881857,                  RETURN ADDRESS (subroutine-style)  X
               FUNC=FIND,                 FIND COUNTRY/PRODUCT IN TABLE      X
               KEY=LGMKEY                 KEY DATA IN WK_TMS AREA

XH881857 EQU  *
         L     R4,CE1CRA                  RESTORE WB1WB BASE AFTER TMSMA
         TM    EBL8URTN,X'01'             TMSMA RETURN CODE (1 = NOT FOUND)
         BZ    XH881865                   FOUND — CONTINUE PROCESSING
```

```asm
* Another variant: SY database record lookup via TMSMA
         TMSMA SY,                        TMS TABLE ID = SY           X
               XH722550,                  ERROR/NOTFOUND ROUTINE      X
               FUNC=RTN,                  RTN = TABLE ACCESS FUNCTION X
               KEY=WB1SY_KEY              KEY IN WORKBLOCK FIELD
```

The shared-variable pattern: the 32-byte `WK_TMS` area in the workblock DSECT
(P21) is the communication buffer for TMSMA. Both the ASM code that sets the key
fields and the code that reads the result share this area. `EBL8URTN` is the
standard ECB return-code byte for TMSMA results, analogous to `SW00RTN` for DB
operations.

**Evidence:** `da7gl.mac:61` (`WK_TMS DS CL32`); `xh71.asm:1021–1028`;
`xh72.asm:941–948`; `xh80.asm`; `xh88.asm`.

---

## Category H — Stack Frame and Entry Linkage

64-bit stack frame conventions used by modern z/TPF programs at CSECT entry/exit.

---

### P31 — `APSTKC`/`USRSTK` + `STMG`/`LMG` — 64-bit register save area

Modern z/TPF entry points use `APSTKC` to allocate a 64-bit stack frame and save
all GPRs via `STMG`. On exit, `USRSTK` deallocates the frame and `LMG` restores
registers. This is the ASM analog of the C++ function prologue/epilogue generated
by the IBM compiler.

```asm
PROGNAME CSECT
         APSTKC DSECT=STKSAVE,SIZE=256    ALLOCATE STACK FRAME
         STMG  R14,R12,STKSAVE_REGS       SAVE ALL GPRs
         ...
         LMG   R14,R12,STKSAVE_REGS       RESTORE GPRs
         USRSTK                           FREE STACK FRAME
         BR    R14                        RETURN
```

```cpp
extern "C" void MyFunc(...) {
    // IBM compiler generates equivalent STMG/APSTKC/LMG/USRSTK
}
```

When a C++ function calls an ASM program (or vice versa), this shared save-area
convention ensures GPRs are consistently preserved across the language boundary.

**Evidence:** `ae48.asm`, `xh71.asm`; IBM z/TPF 64-bit programming conventions.

---

### P32 — `TMSPC`/`TMSEC` and `PRLGC`/`EPLGC` — BAL library linkage

Older z/TPF programs use `TMSPC`/`TMSEC` (save/restore conventional prolog/epilog).
The IBM migration guide recommends `PRLGC`/`EPLGC` for new BAL library routines
(called as regular subroutines via `BAS Rx,label`). C++ code calling these routines
uses normal function call ABI; the ASM side handles register save/restore.

```asm
SUBR     PRLGC                   SAVE REGISTERS (MODERN FORM)
         ...
         EPLGC                   RESTORE REGISTERS AND RETURN
```

The shared variable aspect is the save area: both forms reserve the same-sized
GPR save region on the stack, allowing C++ to call ASM subroutines and vice versa
with consistent register preservation.

**Evidence:** IBM "Assembler programs" migration page; `migration-notes.md`.

---

## Summary Table

| # | Pattern | ASM Keyword | C++ Keyword | Category |
|---|---------|-------------|-------------|----------|
| P1 | extern "C" implicit binding | `BEGIN NAME=`, `ENTRC` | `extern "C" void Fn()` | Name Binding |
| P2 | extern "C" + asm() explicit symbol | `BEGIN NAME=` | `extern "C" ... asm("NAME")` | Name Binding |
| P3 | #pragma map | `BEGIN NAME=` (external) | `#pragma map(fn,"NAME")` | Name Binding |
| P4 | #pragma export | `CALLC`/`ENTRC` target | `#pragma export(fn)` | Name Binding |
| P5 | visibility hidden | — | `__attribute__((visibility("hidden")))` | Name Binding |
| P6 | BEGIN + TV= transfer vector | `BEGIN NAME=X,TV=(Y)` | `extern "C" void Y()` | Name Binding |
| P7 | TPF_regs* register frame | registers R0–R15 | `TPF_regs*` struct | Register Passing |
| P8 | ENTRC/CALLC inline register load | `LA/L Rn,...` + `ENTRC` | args via `CALLC` prototype | Register Passing |
| P9 | CREEC R14/R15 parameters | `CREEC R14=,R15=` | `creec(name,r14,r15)` | Register Passing |
| P10 | CE1CRx pointer slots | `L Rx,CE1CRn(R9)` | `ecbptr()->ce1crn` | ECB Map |
| P11 | EBW000 ECB scratch overlay | `EBW000(R9)` | `ecbptr()->ebw000` | ECB Map |
| P12 | EB0Uxxx Region Zero params | `EB0U000(R9)` | `ecbptr()->eb0u000` | ECB Map |
| P13 | CE1DTn detach state byte | `CLI CE1DT6,X'00'` | `ecbptr()->ce1dt6` | ECB Map |
| P14 | GETCC/getcc() data level | `GETCC Dn,Lx` / `USING ds,R14` | `getcc(Dn)` → struct* | Working Storage |
| P15 | DETAC/ATTAC ownership transfer | `DETAC Dn` / `ATTAC Dn` | `detac(Dn)` / `attac(Dn)` | Working Storage |
| P16 | RELCC + DETAC storage lifetime | `RELCC Dn` | `relcc(Dn)` | Working Storage |
| P17 | DBOPN/dfopn SW00SR file handle | `DBOPN REF=X` / `SW00RTN` | `dfopn(...)→dft_fil*` | DB Context |
| P18 | DBIFB context retrieval/passing | `DBIFB REF=X` → R3 | pass `dft_fil*` as arg | DB Context |
| P19 | DBSPA/dfspa + SW00WKA work area | `DBSPA REF=X` / `SW00WKA` | `dfspa(f,...)` / `f->sw00wka` | DB Context |
| P20 | dft_kyl key list passing | `DBSETK`/`DBKEY KEYLIST=` | `dft_kyl`/`dft_kyl_ext` | DB Context |
| P21 | DSECT ↔ #pragma pack(1) struct | `DSECT` / `DS` fields | `#pragma pack(1) struct` | Struct Layout |
| P22 | DS PLn ↔ decimal<N,0> | `DS PL11` | `decimal<21,0>` | Struct Layout |
| P23 | DS XL4 ↔ __ptr32_t | `DS XL4` | `__ptr32_t` | Struct Layout |
| P24 | EQU bitmask ↔ bitfield | `EQU X'80'` / `TM`/`OI`/`NI` | `struct { uint8_t f:1; }` | Struct Layout |
| P25 | ORG *-n ↔ union variant | `ORG *-n` | `union { TypeA; TypeB; }` | Struct Layout |
| P26 | Repeating group ↔ struct array | `DS nCL(len)` | `struct T arr[n]` | Struct Layout |
| P27 | DSECT SUFFIX= ↔ two-pointer pair | `COPY X,SUFFIX=_B` | `struct X {}; struct X_B {}` | Struct Layout |
| P28 | GLOBZ @MMU... ↔ tpfglbl.h | `GLOBZ` / `@MMUxxx` | `#include <tpfglbl.h>` field | Global Storage |
| P29 | ALASW application work area | `USING ALASW,Rx` | `(Alasw*)ecbptr()->ce1alasw` | Global Storage |
| P30 | CINFC system state | `ENTRC CINFC` | `creec("CINFC   ",...)` | Global Storage |
| P31 | APSTKC/USRSTK + STMG/LMG | `APSTKC` / `STMG` / `LMG` | compiler prolog/epilog | Stack/Linkage |
| P32 | TMSPC/TMSEC / PRLGC/EPLGC | `TMSPC`/`PRLGC` | BAL subroutine call ABI | Stack/Linkage |
| P33 | CALLC/CPROC typed C call | `CPROC RETURN=t,fn,(types)` / `CALLC fn(regs)` | `extern "C" ret fn(...)` | Register Passing |
| P34 | ENTDC level drop entry | `ENTDC target` | — (target receives dropped context) | Register Passing |
| P35 | DBMOD in-place LREC mutation | `DBRED` → field writes → `DBMOD REF=` | `dfred()` → struct writes → `dfmod()` | DB Context |
| P36 | TXBGC/TXCMC/TXRBC transaction scope | `TXBGC` / `TXCMC` / `TXRBC` | `tx_begin()` / `tx_commit()` / `tx_rollback()` | DB Context |
| P37 | FLIPC/flipc level content swap | `FLIPC Dn,Dm` | `flipc(Dn, Dm)` | Working Storage |
| P38 | LEVTA/levtest level occupancy test | `LEVTA LEVEL=n,NOTUSED=lbl` | `levtest(Dn)` → non-zero if in use | Working Storage |
| P39 | GETFC/RELFC file-address pool | `GETFC` / `RELFC` | `getfc()` / `relfc()` | Working Storage |
| P40 | RCRFC combined core+file release | `RCRFC Dn` | `tpf_rcrfc(level)` | Working Storage |
| P41 | CE1USA + REGNA ECB user area | `REGNA n` / `CE1USA` field | `ecbptr()->ce1usa` + `memcpy` | ECB Map |
| P42 | TMSMA table lookup work area | `TMSMA id,ret,FUNC=,KEY=` / `EBL8URTN` | — (result via `EBL8URTN` ECB field) | Global/System |
| P43 | FIWHC/fiwhc find+allocate | `FINHC`/`FIWHC LEVEL=Dn,FILE=` | `fiwhc(level)` → typed ptr | DB Context |
| P44 | DBWAIT/dfwait prefetch sync | `DBWAIT REF=X` | `dfwait(file)` | DB Context |

**Total: 44 distinct shared variable / cross-language interface patterns.**

---

## Key Rules (IBM-Documented)

1. **R9** must point to the ECB at all times during macro calls; transformations must not clobber it.
2. **R3** is the SW00SR register for z/TPFDF macros; track all R3 writes between DB calls.
3. **R14** holds the new block address after `GETCC`; model this as a data-flow edge.
4. **`DBMOD`** must be called while the mutated LREC is still current — before any intervening `DBRED`.
5. **Commit scope**: all z/TPFDF open-to-close references must stay within the same `TXBGC`/`TXCMC` scope.
6. **Below-the-bar**: most z/TPFDF macro parameters and storage areas must be below 2 GB unless explicitly documented otherwise.
7. **Active keys persist** after `DBKEY`/`DBOPN` with KEY operands — a `DBRED` without visible keys is not unfiltered.
8. **`DETAC` block addresses are invalidated** after `RELCC` — do not hold a C++ pointer to a released level.
9. **SPMs** (structured programming macros) cannot be called in 64-bit addressing mode.
10. **`DBCLS ABORT`** discards pending DETAC changes; do not substitute plain `DBCLS` in abort paths.
11. **R15 cannot be a `CALLC` input register**; integer/pointer return values come from R15, floating-point return comes from F0. Do not read an input value from R15 after CALLC.
12. **After `ENTDC`**, all storage blocks on the caller's data levels are released and invalid; never retain a pointer across an ENTDC boundary. After `ENTNC`, all levels and CE1CRx pointers remain intact.
