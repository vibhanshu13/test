#!/usr/bin/env python3
"""Build a cross-file variable identity index from blueprint output.

Scans every .asm.json blueprint and maps each memory variable to its
canonical identity (access_identity, symbolic_identity, dsect+offset, or
file_label).  Writes ``variable_identity_index.json`` for fast cross-file
variable lookup without rescanning blueprints.

Canonical key priority (highest → lowest):
  1. access_identity   — "CE1CR5:17"          (L1, architecture-constant ECB slot)
  2. symbolic_identity — "LG1G1:LG1OSI"       (L2, DSECT:FIELD, cross-file)
  3. file_label        — "da76:WB1ACCTC"       (L4, file-scoped local label)
  4. name_upper        — "MYVAR"               (name only, last resort)

Usage (CLI):
    python3 build_variable_identity_index.py <blueprint_dir> [--output PATH]

The index is also built automatically by ``pipeline_task.py`` as Step 5.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor, TimeoutError as _FuturesTimeoutError, as_completed  # noqa: F401 (kept for CLI compat)
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from blueprint_io import load_blueprint

INDEX_FILENAME = "variable_identity_index.json"
_BP_IO_TIMEOUT = 60.0  # max seconds to wait for a single blueprint file read

# Memory-class node kinds — same set as get_equivalent_variable.py MEMORY_KINDS.
# "register" is included to allow CPP→ASM register-node crossing (CPP-ASM Pattern F).
_MEMORY_KINDS: Set[str] = {"memory", "parameter", "struct_field", "variable", "register"}

# Register names that should not appear in the variable identity index.
# These are architectural names, not memory variables.
_REGISTER_NAMES: Set[str] = {
    f"R{i}" for i in range(16)
} | {f"GR{i}" for i in range(16)} | {f"G{i}" for i in range(16)}


def _is_noise_node(node_id: str) -> bool:
    """Return True for node_ids that represent non-variable entities.

    Filters out:
      - Synthetic/allocation nodes (contain '@' marker)
      - Numeric literals   (memory:-1, memory:0, memory:4096)
      - Register names     (memory:R0 … memory:R15, memory:GR0 …)
      - Literal-pool refs  (memory:=C'01', memory:=F'0')
      - Length attributes  (memory:L'FOO)
    """
    if ":" not in node_id:
        return False
    # Synthetic allocation nodes contain '@' (e.g. "parameter:detach@OPEN_CR21:541:ARG1")
    if "@" in node_id:
        return True
    leaf = node_id.split(":")[-1].strip()
    if not leaf:
        return True
    # Purely numeric (including negative)
    try:
        int(leaf)
        return True
    except ValueError:
        pass
    # Literal pool reference or length attribute
    if leaf.startswith("=") or leaf.startswith("L'"):
        return True
    # Register name
    if leaf.upper() in _REGISTER_NAMES:
        return True
    return False


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _stem(path: Path) -> str:
    """Return the file stem by stripping composite suffixes (.asm.json etc.)."""
    name = path.name
    for suffix in (".asm.json", ".mac.json", ".json"):
        if name.endswith(suffix):
            return name[: -len(suffix)].lower()
    return path.stem.lower()


def _name_upper(node_id: str) -> str:
    """Extract the leaf name from a node_id, uppercased.

    'memory:LG1G1:LG1OSI' -> 'LG1OSI'
    'memory:LG1OSI'        -> 'LG1OSI'
    'memory:WB1ACCTC'      -> 'WB1ACCTC'
    """
    short = node_id.split(":", 1)[1] if ":" in node_id else node_id
    # If DSECT-qualified (e.g. LG1G1:LG1OSI), take only the field part
    if ":" in short:
        return short.split(":", 1)[1].upper()
    return short.upper()


def _collect_memory_node_ids(vl: dict) -> Set[str]:
    """Return the set of memory-class node IDs in a variable_lineage section.

    Excludes numeric literals, register names, and literal-pool references
    which are not semantic variables.
    """
    return {
        n["id"]
        for n in vl.get("nodes", [])
        if n.get("kind") in _MEMORY_KINDS and not _is_noise_node(n["id"])
    }


def _field_name_from_node(node_id: str) -> str:
    """Extract the leaf field name from a node_id (uppercased).

    'memory:WB1WB:WB1ACCTC' → 'WB1ACCTC'
    'memory:WB1ACCTC'       → 'WB1ACCTC'
    'memory:R5'             → 'R5'
    """
    if ":" not in node_id:
        return node_id.upper()
    # Strip kind prefix (e.g. "memory:")
    rest = node_id.split(":", 1)[1]
    # If still colon-separated (DSECT:FIELD), take the last component
    if ":" in rest:
        return rest.rsplit(":", 1)[1].upper()
    return rest.upper()


def _symbolic_field_matches_node(symbolic_id: str, node_id: str) -> bool:
    """Return True if the field part of *symbolic_id* agrees with the node name.

    This detects cases where the wrong DSECT context was recorded on an edge
    (e.g. symbolic_id='LG1G1:LG1ACT' on a node 'memory:WB1ACCTC'):
      'LG1G1:LG1ACT'  vs node 'memory:WB1ACCTC' → False  (LG1ACT ≠ WB1ACCTC)
      'WB1WB:WB1ACCTC' vs node 'memory:WB1ACCTC' → True   (WB1ACCTC = WB1ACCTC)
    """
    if not symbolic_id or ":" not in symbolic_id:
        return True  # can't validate, allow it
    field_in_sym = symbolic_id.split(":", 1)[1].upper()
    node_field = _field_name_from_node(node_id)
    # Allow the symbolic field to be a prefix/alias (handles LG1G1:LG1OSI for node LG1OSI)
    return field_in_sym == node_field or node_field.startswith(field_in_sym) or field_in_sym.startswith(node_field)


def _canonical_key_for_node(
    node_id: str,
    edges: List[Dict[str, Any]],
) -> str:
    """Determine the canonical identity key for a memory node.

    Scans edges that reference this node and picks the strongest identity
    field available (access_identity > symbolic_identity > file_label > name_upper).

    When multiple conflicting identities exist (e.g. caused by wrong DSECT context
    being tracked for a variable in one file), preference is given to identities
    whose symbolic_identity field name agrees with the node's own field name.
    """
    # Collect all candidate identities, scored by whether the symbolic field matches
    access_matching: Optional[str] = None   # L1 with field-name match
    access_any: Optional[str] = None        # L1 any (fallback)
    symbolic_matching: Optional[str] = None # L2 with field-name match
    symbolic_any: Optional[str] = None      # L2 any (fallback)
    file_lbl: Optional[str] = None

    for edge in edges:
        if edge.get("source") != node_id and edge.get("target") != node_id:
            continue
        si = edge.get("symbolic_identity") or ""
        ai = edge.get("access_identity") or ""
        fl = edge.get("file_label") or ""
        matches = _symbolic_field_matches_node(si, node_id)

        if ai:
            if matches and access_matching is None:
                access_matching = ai
            elif access_any is None:
                access_any = ai
        if si:
            if matches and symbolic_matching is None:
                symbolic_matching = si
            elif symbolic_any is None:
                symbolic_any = si
        if fl and file_lbl is None:
            file_lbl = fl

        # Early exit once we have the best possible match
        if access_matching:
            break

    access_id = access_matching or access_any
    symbolic_id = symbolic_matching or symbolic_any

    if access_id:
        return access_id
    if symbolic_id:
        return symbolic_id
    if file_lbl:
        # file_label is already scoped: "da76:WB1ACCTC" — use as-is so
        # local labels from different files never merge into the same key.
        return file_lbl
    return _name_upper(node_id)


def _extract_identity_fields(
    node_id: str,
    edges: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Extract all five identity fields for a node by scanning its edges.

    Prefers edges whose symbolic_identity field name agrees with the node's
    own field name, to avoid picking up wrong-DSECT-context assignments.
    """
    result: Dict[str, Any] = {
        "access_identity": None,
        "symbolic_identity": None,
        "dsect": None,
        "field_offset": None,
        "file_label": None,
    }
    # Separate matching vs non-matching candidates for each field
    candidates: Dict[str, List] = {k: [] for k in result}

    for edge in edges:
        if edge.get("source") != node_id and edge.get("target") != node_id:
            continue
        si = edge.get("symbolic_identity") or ""
        matches = _symbolic_field_matches_node(si, node_id)

        for field in ("access_identity", "symbolic_identity", "dsect", "file_label"):
            val = edge.get(field)
            if val:
                candidates[field].append((matches, val))
        fo = edge.get("field_offset")
        if fo is not None:
            candidates["field_offset"].append((matches, fo))

    # Pick matching candidate first, then any candidate
    for field, cands in candidates.items():
        matching = [v for (m, v) in cands if m]
        fallback = [v for (_, v) in cands]
        best = (matching or fallback)
        if best:
            result[field] = best[0]

    return result


# ---------------------------------------------------------------------------
# Per-blueprint worker
# ---------------------------------------------------------------------------

def _load_one_blueprint(
    bp_path: Path,
) -> Optional[Tuple[str, Set[str], List[Dict[str, Any]]]]:
    """Load one blueprint and return (file_stem, mem_ids, edges).

    Returns None on error (warning printed to stderr).
    """
    try:
        bp = load_blueprint(bp_path, skip_global_lineage=True, keys={"variable_lineage"})
    except Exception as exc:
        print(f"WARNING: Skipping {bp_path.name}: {exc}", file=sys.stderr)
        return None
    vl = bp.get("variable_lineage") or {}
    return (_stem(bp_path), _collect_memory_node_ids(vl), vl.get("edges") or [])


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_index(
    blueprint_dir: Path,
    output_path: Optional[Path] = None,
    *,
    job_id: Optional[str] = None,
) -> Optional[Path]:
    """Scan all .asm.json blueprints in *blueprint_dir* and build the identity index.

    Args:
        blueprint_dir: Directory containing .asm.json files.
        output_path:   Where to write the index JSON.
                       Defaults to ``blueprint_dir.parent / INDEX_FILENAME``.
                       Ignored when *job_id* is provided (data goes to index.db).
        job_id:        When provided, write directly to the index DB via
                       ``ingest_identity_index_from_dict`` instead of writing
                       a JSON file.  No JSON file is created.

    Returns:
        Path to the written index file, or ``None`` when *job_id* is provided.
    """
    if output_path is None and job_id is None:
        output_path = blueprint_dir.parent / INDEX_FILENAME

    blueprint_files = sorted(blueprint_dir.glob("*.asm.json"))

    # by_identity[canonical_key] = {names, access_identity, symbolic_identity,
    #                                dsect, field_offset, file_label, files}
    by_identity: Dict[str, Dict[str, Any]] = {}
    # by_name[name_upper] = canonical_key  (last-writer wins for ambiguous names)
    by_name: Dict[str, str] = {}

    # Phase 1 + 2 combined: load blueprints in parallel and aggregate inline.
    # Processing each result immediately as futures complete — rather than
    # accumulating all (file_stem, mem_ids, edges) tuples in a 'loaded' list
    # first — keeps peak RSS proportional to one blueprint's edge data at a time
    # instead of holding all 14K+ blueprints' edge lists simultaneously.
    total = len(blueprint_files)
    # Load blueprints sequentially (one at a time) to avoid accumulating
    # multiple large decompressed variable_lineage payloads in memory
    # simultaneously.  The bottleneck here is Python dict aggregation
    # (CPU-bound), not I/O, so concurrency provides little throughput gain
    # while costing significant peak RAM.
    for i, bp_path in enumerate(blueprint_files, 1):
        try:
            result = _load_one_blueprint(bp_path)
        except Exception as exc:
            print(f"WARNING: Error loading {bp_path.name}: {exc}", file=sys.stderr)
            result = None
        if result is not None:
            file_stem, mem_ids, edges = result
            for node_id in mem_ids:
                canonical_key = _canonical_key_for_node(node_id, edges)
                leaf_name = _name_upper(node_id)

                if canonical_key not in by_identity:
                    fields = _extract_identity_fields(node_id, edges)
                    by_identity[canonical_key] = {
                        "names": [],
                        "access_identity": fields["access_identity"],
                        "symbolic_identity": fields["symbolic_identity"],
                        "dsect": fields["dsect"],
                        "field_offset": fields["field_offset"],
                        "file_label": fields["file_label"],
                        "files": {},
                    }

                entry = by_identity[canonical_key]

                # Accumulate names (deduplicated)
                if leaf_name not in entry["names"]:
                    entry["names"].append(leaf_name)

                # Enrich identity fields if this node/edge set has more info
                if entry["access_identity"] is None or entry["dsect"] is None:
                    fields = _extract_identity_fields(node_id, edges)
                    for field in ("access_identity", "symbolic_identity", "dsect",
                                  "field_offset", "file_label"):
                        if fields[field] is not None and entry[field] is None:
                            entry[field] = fields[field]

                # Record file → node_id mapping (first occurrence wins per file)
                if file_stem not in entry["files"]:
                    entry["files"][file_stem] = node_id

                # Build name → key lookup (most-specific wins: keep if key has access_id)
                existing_key = by_name.get(leaf_name)
                if existing_key is None:
                    by_name[leaf_name] = canonical_key
                elif existing_key != canonical_key:
                    # Prefer the key with an access_identity over a weaker one
                    existing_entry = by_identity.get(existing_key, {})
                    new_entry = by_identity[canonical_key]
                    if new_entry.get("access_identity") and not existing_entry.get("access_identity"):
                        by_name[leaf_name] = canonical_key
                    elif new_entry.get("symbolic_identity") and not existing_entry.get("access_identity") and not existing_entry.get("symbolic_identity"):
                        by_name[leaf_name] = canonical_key

        if i % 1000 == 0 or i == total:
            pct = i * 100 // total
            print(
                f"  Identity index load: {i}/{total} blueprints ({pct}%)",
                flush=True,
            )

    # Sort names within each entry for deterministic output
    for entry in by_identity.values():
        entry["names"] = sorted(entry["names"])

    payload: Dict[str, Any] = {
        "_meta": {
            "built_at": datetime.now(timezone.utc).isoformat(),
            "blueprints_scanned": len(blueprint_files),
            "unique_identities": len(by_identity),
            "unique_names": len(by_name),
        },
        "by_name": dict(sorted(by_name.items())),
        "by_identity": dict(sorted(by_identity.items())),
    }

    if job_id is not None:
        # Write directly to the index DB — no JSON file created.
        try:
            from api.index_db.writers import ingest_identity_index_from_dict
            ingest_identity_index_from_dict(job_id, payload)
        except Exception as exc:
            print(f"WARNING: ingest_identity_index_from_dict failed: {exc}", file=sys.stderr)
        print(
            f"Identity index written to index DB "
            f"({len(blueprint_files)} blueprints, {len(by_identity)} identities, "
            f"{len(by_name)} name entries)",
            file=sys.stderr,
        )
        return None

    # JSON path (CLI or job_id not provided).
    output_path.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
    print(
        f"Wrote identity index: {output_path} "
        f"({len(blueprint_files)} blueprints, {len(by_identity)} identities, "
        f"{len(by_name)} name entries)",
        file=sys.stderr,
    )
    return output_path


def load_index(index_path: Path) -> Optional[Dict[str, Any]]:
    """Load the identity index from *index_path*.

    Returns the full payload dict (with ``by_name`` and ``by_identity`` keys)
    or ``None`` if the file is absent or unreadable.
    """
    if not index_path.exists():
        return None
    try:
        return json.loads(index_path.read_text(encoding="utf-8"))
    except Exception:
        return None


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Build variable_identity_index.json from blueprint output."
    )
    parser.add_argument("blueprint_dir", help="Directory containing .asm.json files")
    parser.add_argument(
        "--output",
        help=f"Output path (default: <blueprint_dir>/../{INDEX_FILENAME})",
    )
    args = parser.parse_args()

    bp_dir = Path(args.blueprint_dir)
    out = Path(args.output) if args.output else None
    build_index(bp_dir, out)
