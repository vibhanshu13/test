#!/usr/bin/env python3
"""Trace same-file C++ function lineage and report cross-file dependencies.

This tool consumes C++ blueprint call graphs (`*.cpp.json`) from a blueprint
directory and produces:
- same-file forward/backward function lineage trees
- dependent files/modules referenced by visited same-file functions
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from blueprint_io import load_blueprint


EXIT_SUCCESS = 0
EXIT_INPUT_ERROR = 2
EXIT_JSON_ERROR = 3
EXIT_MISSING_CALL_GRAPH = 4
EXIT_NO_MATCH = 5
EXIT_AMBIGUOUS = 6


def eprint(message: str) -> None:
    print(message, file=sys.stderr)


def normalize_name(value: str) -> str:
    return value.strip()


def tail_name(value: str) -> str:
    if not value:
        return ""
    return value.split("::")[-1]


def match_rank(candidate_name: str, query: str) -> Optional[int]:
    c = normalize_name(candidate_name)
    q = normalize_name(query)
    if not c or not q:
        return None

    if c == q:
        return 0
    if tail_name(c) == q:
        return 1
    if c.lower() == q.lower():
        return 2
    if tail_name(c).lower() == q.lower():
        return 3
    return None


def cpp_stem_from_blueprint_path(path: Path) -> str:
    name = path.name
    if name.endswith(".cpp.json"):
        return name[: -len(".cpp.json")]
    return path.stem


def stem_from_source_path(path_value: str) -> str:
    if not path_value:
        return ""
    path = Path(path_value)
    name = path.name
    if name.endswith(".cpp"):
        return name[: -len(".cpp")]
    if name.endswith(".asm"):
        return name[: -len(".asm")]
    return path.stem


def edge_key(edge: Dict[str, Any]) -> Tuple[Any, ...]:
    return (
        edge.get("source"),
        edge.get("target"),
        edge.get("line"),
        edge.get("call_type"),
        edge.get("instruction"),
        edge.get("file"),
    )


def discover_cpp_blueprints(blueprint_dir: Path) -> List[Path]:
    if not blueprint_dir.exists() or not blueprint_dir.is_dir():
        eprint(f"Blueprint directory not found: {blueprint_dir}")
        raise SystemExit(EXIT_INPUT_ERROR)
    # Only *.cpp.json blueprints are scanned. *.hpp.json blueprints are excluded
    # because header files contain only declarations (extern "C", constants, struct defs)
    # — no executable function bodies — so they would yield zero tracing hits.
    # If inline function bodies are ever added to .hpp files, include "*.hpp.json" here.
    return sorted(path for path in blueprint_dir.rglob("*.cpp.json") if path.is_file())


def discover_asm_stems(blueprint_dir: Path) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for path in blueprint_dir.rglob("*.asm.json"):
        if not path.is_file():
            continue
        stem = path.name[: -len(".asm.json")] if path.name.endswith(".asm.json") else path.stem
        out[stem.lower()] = stem
    return out


def load_json(path: Path) -> Dict[str, Any]:
    try:
        return load_blueprint(path)
    except OSError as exc:
        eprint(f"Failed to read blueprint: {path} ({exc})")
        raise SystemExit(EXIT_INPUT_ERROR)
    except Exception as exc:
        eprint(f"Failed to decode blueprint: {path} ({exc})")
        raise SystemExit(EXIT_JSON_ERROR)


def dedupe_edges(edges: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen: Set[Tuple[Any, ...]] = set()
    out: List[Dict[str, Any]] = []
    for edge in edges:
        key = edge_key(edge)
        if key in seen:
            continue
        seen.add(key)
        out.append(edge)
    return out


def extract_entry_functions(payload: Dict[str, Any]) -> List[Tuple[str, Optional[int], Optional[str]]]:
    out: List[Tuple[str, Optional[int], Optional[str]]] = []
    symbols = payload.get("symbols")
    if not isinstance(symbols, dict):
        return out
    global_symbols = symbols.get("global_symbols")
    if not isinstance(global_symbols, dict):
        return out

    for func_name, symbol in global_symbols.items():
        if not isinstance(func_name, str) or not isinstance(symbol, dict):
            continue
        if str(symbol.get("type") or "").lower() != "entry":
            continue
        line: Optional[int] = None
        provenance = symbol.get("provenance")
        if isinstance(provenance, dict):
            original_line = provenance.get("original_line")
            if isinstance(original_line, int) and original_line > 0:
                line = original_line
        source_file = symbol.get("file") if isinstance(symbol.get("file"), str) else None
        out.append((func_name, line, source_file))
    return out


def build_indexes(
    blueprint_paths: Sequence[Path],
) -> Tuple[
    Dict[str, List[Dict[str, Any]]],
    Dict[str, Set[str]],
    List[Dict[str, Any]],
    int,
]:
    function_defs: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    functions_by_file: Dict[str, Set[str]] = defaultdict(set)
    all_edges_raw: List[Dict[str, Any]] = []

    for bp_path in blueprint_paths:
        payload = load_json(bp_path)
        cpp_stem = cpp_stem_from_blueprint_path(bp_path)

        for func_name, line, source_file in extract_entry_functions(payload):
            row = {
                "function": func_name,
                "file_stem": cpp_stem,
                "blueprint_path": str(bp_path),
                "source_file": source_file,
                "line": line,
                "source": "symbols.entry",
            }
            function_defs[func_name].append(row)
            functions_by_file[cpp_stem].add(func_name)

        call_graph = payload.get("call_graph")
        if not isinstance(call_graph, dict):
            continue
        edges = call_graph.get("edges")
        if not isinstance(edges, list):
            continue

        for edge in edges:
            if not isinstance(edge, dict):
                continue
            source = edge.get("source")
            target = edge.get("target")
            if not isinstance(source, str) or not source or not isinstance(target, str) or not target:
                continue

            edge_file = edge.get("file") if isinstance(edge.get("file"), str) else ""
            edge_source_file_stem = stem_from_source_path(edge_file) or cpp_stem
            line = edge.get("line")
            if not isinstance(line, int):
                line = None
            call_type = str(edge.get("call_type") or "call")
            instruction = str(edge.get("instruction") or "")

            all_edges_raw.append(
                {
                    "source": source,
                    "target": target,
                    "line": line,
                    "call_type": call_type,
                    "instruction": instruction,
                    "file": edge_file,
                    "source_file_stem": edge_source_file_stem,
                    "blueprint_path": str(bp_path),
                }
            )

            # Fallback definitions for source functions when symbol table misses entries.
            if source not in functions_by_file[edge_source_file_stem]:
                function_defs[source].append(
                    {
                        "function": source,
                        "file_stem": edge_source_file_stem,
                        "blueprint_path": str(bp_path),
                        "source_file": edge_file or None,
                        "line": line,
                        "source": "call_graph.source_fallback",
                    }
                )
                functions_by_file[edge_source_file_stem].add(source)

    deduped_defs: Dict[str, List[Dict[str, Any]]] = {}
    for function, rows in function_defs.items():
        seen: Set[Tuple[str, str, Optional[int]]] = set()
        merged: List[Dict[str, Any]] = []
        for row in rows:
            key = (str(row.get("file_stem") or ""), str(row.get("blueprint_path") or ""), row.get("line"))
            if key in seen:
                continue
            seen.add(key)
            merged.append(row)
        merged.sort(
            key=lambda row: (
                str(row.get("file_stem") or ""),
                row.get("line") if isinstance(row.get("line"), int) else 10**9,
                str(row.get("blueprint_path") or ""),
            )
        )
        deduped_defs[function] = merged

    return deduped_defs, functions_by_file, dedupe_edges(all_edges_raw), len(all_edges_raw)


def resolve_root_candidates(
    query: str,
    file_stem_filter: Optional[str],
    function_defs: Dict[str, List[Dict[str, Any]]],
) -> List[Dict[str, Any]]:
    candidates: List[Dict[str, Any]] = []
    file_stem_filter_norm = file_stem_filter.strip().lower() if file_stem_filter else None

    for func_name, defs in function_defs.items():
        rank = match_rank(func_name, query)
        if rank is None:
            continue
        for row in defs:
            file_stem = str(row.get("file_stem") or "")
            if file_stem_filter_norm and file_stem.lower() != file_stem_filter_norm:
                continue
            candidates.append(
                {
                    "id": f"{file_stem}::{func_name}",
                    "function": func_name,
                    "file_stem": file_stem,
                    "line": row.get("line"),
                    "source_file": row.get("source_file"),
                    "blueprint_path": row.get("blueprint_path"),
                    "match_rank": rank,
                }
            )

    candidates.sort(
        key=lambda row: (
            row.get("match_rank"),
            str(row.get("file_stem") or ""),
            row.get("line") if isinstance(row.get("line"), int) else 10**9,
            str(row.get("function") or ""),
            str(row.get("blueprint_path") or ""),
        )
    )
    return candidates


def print_ambiguity(candidates: Sequence[Dict[str, Any]], query: str, file_stem_filter: Optional[str]) -> None:
    scope_msg = f" with file-stem='{file_stem_filter}'" if file_stem_filter else ""
    eprint(f"Ambiguous function '{query}'{scope_msg}. Multiple candidates found:")
    for idx, row in enumerate(candidates, start=1):
        line = row.get("line") if isinstance(row.get("line"), int) else "-"
        eprint(
            f"  {idx}. id={row['id']} file={row['file_stem']} "
            f"line={line} function={row['function']}"
        )
    eprint("Provide `--file-stem` to disambiguate.")


def build_owner_index(function_defs: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Set[str]]:
    out: Dict[str, Set[str]] = {}
    for func, rows in function_defs.items():
        out[func] = {str(row.get("file_stem") or "") for row in rows if row.get("file_stem")}
    return out


def group_neighbor_edges(
    node: str,
    direction: str,
    out_adj: Dict[str, List[Dict[str, Any]]],
    in_adj: Dict[str, List[Dict[str, Any]]],
) -> Dict[str, List[Dict[str, Any]]]:
    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    edges = out_adj.get(node, []) if direction == "forward" else in_adj.get(node, [])
    for edge in edges:
        neighbor = edge.get("target") if direction == "forward" else edge.get("source")
        if not isinstance(neighbor, str) or not neighbor:
            continue
        grouped[neighbor].append(edge)
    return grouped


def summarize_edge_group(edges: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    lines = sorted(
        {
            int(edge.get("line"))
            for edge in edges
            if isinstance(edge.get("line"), int) and int(edge.get("line")) > 0
        }
    )
    call_types = sorted({str(edge.get("call_type") or "call") for edge in edges if edge.get("call_type") is not None})
    instructions = sorted({str(edge.get("instruction") or "") for edge in edges if edge.get("instruction")})
    return {
        "lines": lines,
        "call_types": call_types,
        "instructions": instructions,
        "edge_count": len(edges),
    }


def build_tree(
    root_function: str,
    root_file_stem: str,
    direction: str,
    out_adj: Dict[str, List[Dict[str, Any]]],
    in_adj: Dict[str, List[Dict[str, Any]]],
    max_depth: Optional[int],
) -> Tuple[Dict[str, Any], Set[str], Set[Tuple[Any, ...]], int]:
    visited_nodes: Set[str] = set()
    traversed_edges: Set[Tuple[Any, ...]] = set()
    max_depth_reached = 0

    def rec(node: str, depth: int, path: Set[str]) -> Dict[str, Any]:
        nonlocal max_depth_reached
        visited_nodes.add(node)
        if depth > max_depth_reached:
            max_depth_reached = depth

        node_obj: Dict[str, Any] = {
            "function": node,
            "file_stem": root_file_stem,
            "direction": direction,
            "depth": depth,
            "children": [],
        }

        if max_depth is not None and depth >= max_depth:
            node_obj["truncated"] = True
            return node_obj

        grouped = group_neighbor_edges(node, direction, out_adj, in_adj)
        for neighbor in sorted(grouped.keys()):
            edge_group = grouped[neighbor]
            for edge in edge_group:
                traversed_edges.add(edge_key(edge))
            edge_summary = summarize_edge_group(edge_group)

            child: Dict[str, Any] = {
                "function": neighbor,
                "file_stem": root_file_stem,
                "edge": edge_summary,
                "children": [],
            }
            if neighbor in path:
                child["cycle_cut"] = True
                node_obj["children"].append(child)
                continue

            child_tree = rec(neighbor, depth + 1, set(path) | {neighbor})
            child["children"] = child_tree.get("children", [])
            if child_tree.get("truncated"):
                child["truncated"] = True
            node_obj["children"].append(child)

        return node_obj

    tree = rec(root_function, 0, {root_function})
    return tree, visited_nodes, traversed_edges, max_depth_reached


def build_same_file_adjacency(
    root_file_stem: str,
    root_file_functions: Set[str],
    owner_index: Dict[str, Set[str]],
    all_edges: Sequence[Dict[str, Any]],
) -> Tuple[Dict[str, List[Dict[str, Any]]], Dict[str, List[Dict[str, Any]]], List[Dict[str, Any]]]:
    out_adj: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    in_adj: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    intra_edges: List[Dict[str, Any]] = []

    for edge in all_edges:
        source = str(edge.get("source") or "")
        target = str(edge.get("target") or "")
        source_file_stem = str(edge.get("source_file_stem") or "")
        if not source or not target:
            continue
        if source_file_stem != root_file_stem:
            continue
        if source not in root_file_functions:
            continue

        target_owner_stems = owner_index.get(target, set())
        is_same_file_target = (target in root_file_functions) or (root_file_stem in target_owner_stems)
        if not is_same_file_target:
            continue

        out_adj[source].append(edge)
        in_adj[target].append(edge)
        intra_edges.append(edge)

    for key in list(out_adj.keys()):
        out_adj[key].sort(
            key=lambda edge: (
                str(edge.get("target") or ""),
                edge.get("line") if isinstance(edge.get("line"), int) else 10**9,
                str(edge.get("call_type") or ""),
                str(edge.get("instruction") or ""),
            )
        )
    for key in list(in_adj.keys()):
        in_adj[key].sort(
            key=lambda edge: (
                str(edge.get("source") or ""),
                edge.get("line") if isinstance(edge.get("line"), int) else 10**9,
                str(edge.get("call_type") or ""),
                str(edge.get("instruction") or ""),
            )
        )

    return out_adj, in_adj, intra_edges


def extract_dependent_files(
    root_file_stem: str,
    visited_functions: Set[str],
    root_file_functions: Set[str],
    owner_index: Dict[str, Set[str]],
    known_asm_stems: Dict[str, str],
    all_edges: Sequence[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    grouped: Dict[Tuple[str, str], Dict[str, Any]] = {}

    for edge in all_edges:
        source = str(edge.get("source") or "")
        target = str(edge.get("target") or "")
        source_file_stem = str(edge.get("source_file_stem") or "")
        if not source or not target:
            continue
        if source_file_stem != root_file_stem:
            continue
        if source not in visited_functions:
            continue

        owner_stems = owner_index.get(target, set())
        is_same_file_target = (target in root_file_functions) or (root_file_stem in owner_stems)
        if is_same_file_target:
            continue

        call_type = str(edge.get("call_type") or "call")
        instruction = str(edge.get("instruction") or "")
        line = edge.get("line") if isinstance(edge.get("line"), int) and edge.get("line") > 0 else None

        target_lower = target.lower()
        cpp_owner_stems = sorted(stem for stem in owner_stems if stem and stem != root_file_stem)
        if cpp_owner_stems:
            for owner in cpp_owner_stems:
                key = (owner, "cpp")
                status = "resolved" if len(cpp_owner_stems) == 1 else "ambiguous_target_owner"
                row = grouped.setdefault(
                    key,
                    {
                        "file_or_module": owner,
                        "language": "cpp",
                        "functions": set(),
                        "called_from": set(),
                        "lines": set(),
                        "call_types": set(),
                        "status": status,
                    },
                )
                row["functions"].add(target)
                row["called_from"].add(source)
                if line is not None:
                    row["lines"].add(line)
                row["call_types"].add(call_type)
                if row["status"] == "resolved" and status != "resolved":
                    row["status"] = status
            continue

        if target_lower in known_asm_stems:
            module = known_asm_stems[target_lower]
            language = "asm"
            status = "resolved_module"
            bucket_name = module
        elif call_type == "subroutine_call" or instruction.upper() == "CALL_ALIAS":
            language = "asm"
            status = "alias_or_module"
            bucket_name = target
        else:
            language = "external"
            status = "unresolved_external"
            bucket_name = target

        key = (bucket_name, language)
        row = grouped.setdefault(
            key,
            {
                "file_or_module": bucket_name,
                "language": language,
                "functions": set(),
                "called_from": set(),
                "lines": set(),
                "call_types": set(),
                "status": status,
            },
        )
        row["functions"].add(target)
        row["called_from"].add(source)
        if line is not None:
            row["lines"].add(line)
        row["call_types"].add(call_type)

    rows: List[Dict[str, Any]] = []
    for row in grouped.values():
        rows.append(
            {
                "file_or_module": row["file_or_module"],
                "language": row["language"],
                "functions": sorted(row["functions"]),
                "called_from": sorted(row["called_from"]),
                "lines": sorted(row["lines"]),
                "call_types": sorted(row["call_types"]),
                "status": row["status"],
            }
        )

    rows.sort(
        key=lambda row: (
            str(row.get("language") or ""),
            str(row.get("file_or_module") or ""),
        )
    )
    return rows


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Trace same-file C++ function lineage from blueprint call graphs."
    )
    parser.add_argument("--blueprint-dir", required=True, help="Directory containing *.cpp.json blueprints")
    parser.add_argument("--func", required=True, help="Root function name to trace")
    parser.add_argument("--file-stem", help="Restrict root resolution to a specific file stem")
    parser.add_argument(
        "--direction",
        default="both",
        choices=["forward", "backward", "both"],
        help="Traversal direction (default: both)",
    )
    parser.add_argument(
        "--max-depth",
        type=int,
        default=None,
        help="Maximum depth per direction (default: unlimited)",
    )
    parser.add_argument("--out", help="Output JSON path (default: trace_func_<func>.json)")
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)

    if args.max_depth is not None and args.max_depth < 0:
        eprint("--max-depth must be >= 0")
        return EXIT_INPUT_ERROR

    blueprint_dir = Path(args.blueprint_dir)
    blueprint_paths = discover_cpp_blueprints(blueprint_dir)
    if not blueprint_paths:
        eprint(f"No C++ blueprints found under: {blueprint_dir}")
        return EXIT_MISSING_CALL_GRAPH

    known_asm_stems = discover_asm_stems(blueprint_dir)
    function_defs, functions_by_file, all_edges, edges_total_raw = build_indexes(blueprint_paths)
    if not function_defs:
        eprint("No function definitions discovered from C++ blueprints.")
        return EXIT_MISSING_CALL_GRAPH

    candidates = resolve_root_candidates(args.func, args.file_stem, function_defs)
    if not candidates:
        stem_msg = f" with file-stem='{args.file_stem}'" if args.file_stem else ""
        eprint(f"No matching functions found for '{args.func}'{stem_msg}.")
        return EXIT_NO_MATCH
    if len(candidates) > 1:
        print_ambiguity(candidates, args.func, args.file_stem)
        return EXIT_AMBIGUOUS

    root = candidates[0]
    root_function = str(root["function"])
    root_file_stem = str(root["file_stem"])
    root_file_functions = set(functions_by_file.get(root_file_stem, set()))
    owner_index = build_owner_index(function_defs)

    out_adj, in_adj, intra_edges = build_same_file_adjacency(
        root_file_stem=root_file_stem,
        root_file_functions=root_file_functions,
        owner_index=owner_index,
        all_edges=all_edges,
    )

    forward_tree: Optional[Dict[str, Any]] = None
    backward_tree: Optional[Dict[str, Any]] = None
    visited_functions: Set[str] = {root_function}
    traversed_edge_keys: Set[Tuple[Any, ...]] = set()
    depth_reached_forward = 0
    depth_reached_backward = 0

    directions = ["forward", "backward"] if args.direction == "both" else [args.direction]
    for direction in directions:
        if direction == "forward":
            tree, visited, traversed, depth_reached_forward = build_tree(
                root_function=root_function,
                root_file_stem=root_file_stem,
                direction="forward",
                out_adj=out_adj,
                in_adj=in_adj,
                max_depth=args.max_depth,
            )
            forward_tree = tree
            visited_functions.update(visited)
            traversed_edge_keys.update(traversed)
        else:
            tree, visited, traversed, depth_reached_backward = build_tree(
                root_function=root_function,
                root_file_stem=root_file_stem,
                direction="backward",
                out_adj=out_adj,
                in_adj=in_adj,
                max_depth=args.max_depth,
            )
            backward_tree = tree
            visited_functions.update(visited)
            traversed_edge_keys.update(traversed)

    dependent_files = extract_dependent_files(
        root_file_stem=root_file_stem,
        visited_functions=visited_functions,
        root_file_functions=root_file_functions,
        owner_index=owner_index,
        known_asm_stems=known_asm_stems,
        all_edges=all_edges,
    )

    output = {
        "keyword": args.func,
        "root": {
            "function": root_function,
            "file_stem": root_file_stem,
            "id": root["id"],
        },
        "resolved_candidates": candidates,
        "config": {
            "blueprint_dir": str(blueprint_dir),
            "direction": args.direction,
            "max_depth": args.max_depth,
            "file_stem": args.file_stem,
        },
        "forward_tree": forward_tree if args.direction in ("forward", "both") else None,
        "backward_tree": backward_tree if args.direction in ("backward", "both") else None,
        "dependent_files": dependent_files,
        "stats": {
            "blueprints_loaded": len(blueprint_paths),
            "functions_defined": sum(len(rows) for rows in function_defs.values()),
            "unique_function_names": len(function_defs),
            "edges_total_raw": edges_total_raw,
            "edges_total_dedup": len(all_edges),
            "intra_edges_total": len(intra_edges),
            "visited_functions": len(visited_functions),
            "visited_edges": len(traversed_edge_keys),
            "dependent_files": len(dependent_files),
            "depth_reached_forward": depth_reached_forward,
            "depth_reached_backward": depth_reached_backward,
        },
    }

    default_out_name = f"trace_func_{args.func}.json"
    out_path = Path(args.out) if args.out else Path(default_out_name)
    try:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    except OSError as exc:
        eprint(f"Failed to write output file: {out_path} ({exc})")
        return EXIT_INPUT_ERROR

    print(f"Wrote: {out_path}")
    return EXIT_SUCCESS


if __name__ == "__main__":
    raise SystemExit(main())
