#!/usr/bin/env python3
"""Focused verification for KB chain summaries precompute + cache-first modifiers."""

from __future__ import annotations

import json
import shutil
import sys
import uuid
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))

from api.config import settings
from api.db import SessionLocal
from api.models.knowledge_base import KnowledgeBase
from api.models.user import User
from api.routes.knowledge_base import ChainSummariesRequest, precompute_kb_chain_summaries
from api.storage.workspace import WorkspaceManager
from api.tasks import kb_modifiers_task
from api.tasks.kb_chain_summaries_task import _build_root_chains, _run as run_chain_summaries
import llm.chain_explainer as chain_explainer


PASS = 0
FAIL = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS   {name}" + (f"   -- {detail}" if detail else ""))
    else:
        FAIL += 1
        print(f"  FAIL   {name}" + (f"   -- {detail}" if detail else ""))


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _build_sample_graph() -> dict:
    return {
        "nodes": [
            {"id": "root", "type": "asm", "file": "root.asm"},
            {"id": "mod", "type": "asm", "file": "mod.asm"},
            {"id": "ext", "type": "external", "file": "ext.asm"},
            {"id": "proj_missing", "type": "cpp", "file": "proj_missing.cpp"},
        ],
        "edges": [
            {
                "source": "root",
                "target": "mod",
                "is_internal": True,
                "instructions": ["ENTRC"],
                "call_sites": [],
            },
            {
                "source": "mod",
                "target": "ext",
                "is_internal": False,
                "instructions": ["ENTRC"],
                "call_sites": [],
            },
            {
                "source": "root",
                "target": "proj_missing",
                "is_internal": True,
                "instructions": ["ENTRC"],
                "call_sites": [],
            },
        ],
    }


def _build_cycle_graph() -> dict:
    return {
        "nodes": [
            {"id": "a", "type": "asm"},
            {"id": "b", "type": "asm"},
            {"id": "c", "type": "asm"},
        ],
        "edges": [
            {"source": "a", "target": "b", "instructions": ["ENTRC"], "is_internal": True},
            {"source": "b", "target": "c", "instructions": ["ENTRC"], "is_internal": True},
            {"source": "c", "target": "b", "instructions": ["ENTRC"], "is_internal": True},
        ],
    }


def _build_blueprint(summary: str | None, include_setter: bool = False) -> dict:
    flow_entry = {"line": 1, "inst": "MVC", "args": ["X", "Y"]}
    if include_setter:
        flow_entry = {"line": 5, "inst": "OI", "var": "LG1OSI", "val": "C400"}
    payload = {
        "meta": {"aliases": []},
        "blocks": [{"id": "B1", "flow": [flow_entry]}],
    }
    if summary is not None:
        payload["business_summary"] = summary
    return payload


def test_chain_helpers() -> None:
    print("\n" + "=" * 78)
    print("chain traversal helpers")
    print("=" * 78)

    roots, chains, node_types = _build_root_chains(_build_sample_graph(), max_depth=None)
    chain_files = [tuple(c["files"]) for c in chains]
    check("root detection (indegree zero)", roots == ["root"], detail=str(roots))
    check("chain root->mod exists", ("root", "mod") in chain_files)
    check("chain root->mod->ext exists", ("root", "mod", "ext") in chain_files)
    check("external node type retained", node_types.get("ext") == "external")
    check(
        "single-node chains excluded",
        all(len(c["files"]) > 1 for c in chains),
        detail=str(chain_files),
    )

    roots2, chains2, _ = _build_root_chains(_build_cycle_graph(), max_depth=None)
    has_repeated = any(len(set(c["files"])) != len(c["files"]) for c in chains2)
    check("cycle graph still has roots", roots2 == ["a"], detail=str(roots2))
    check("cycle handling avoids repeated nodes in a chain", not has_repeated)

    key1 = chain_explainer.chain_files_key(["root", "mod"])
    key2 = chain_explainer.chain_files_key(["root", "mod"])
    check("stable key for same files", key1 == key2, detail=f"{key1} == {key2}")


def test_prompt_labeling() -> None:
    print("\n" + "=" * 78)
    print("missing summary labeling")
    print("=" * 78)

    chain = {"files": ["root", "ext", "proj_missing"], "hops": []}
    file_summaries = {"root": "Root business summary."}
    node_types = {"root": "asm", "ext": "external", "proj_missing": "cpp"}

    with mock.patch.object(
        chain_explainer,
        "call_llm",
        side_effect=lambda prompt, system_prompt=None: prompt,
    ):
        prompt = chain_explainer.summarize_chain(chain, file_summaries, node_types)

    check(
        "external files marked explicitly",
        "(external module/dependency; no parser summary available)" in prompt,
    )
    check(
        "project missing summary marked explicitly",
        "(project file; parser summary unavailable)" in prompt,
    )


def test_precompute_and_modifiers_cache() -> None:
    print("\n" + "=" * 78)
    print("precompute cache + modifiers cache-first integration")
    print("=" * 78)

    kb_id = f"kb-chain-test-{uuid.uuid4()}"
    ws = WorkspaceManager(kb_id)
    for d in (ws.root, ws.input_dir, ws.output_dir, ws.cache_dir):
        d.mkdir(parents=True, exist_ok=True)

    try:
        output_dir = ws.output_dir
        _write_json(output_dir / "file_call_graph.json", _build_sample_graph())
        _write_json(output_dir / "root.asm.json", _build_blueprint("Root entry flow summary."))
        _write_json(output_dir / "mod.asm.json", _build_blueprint("Modifier flow summary.", include_setter=True))

        with mock.patch.object(
            chain_explainer,
            "call_llm",
            side_effect=lambda prompt, system_prompt=None: "SYNTHETIC_CHAIN_SUMMARY",
        ):
            result1 = run_chain_summaries(
                ws,
                {"kb_id": kb_id, "force_refresh": False, "max_depth": None, "max_workers": 2},
            )
            result2 = run_chain_summaries(
                ws,
                {"kb_id": kb_id, "force_refresh": False, "max_depth": None, "max_workers": 2},
            )
            result3 = run_chain_summaries(
                ws,
                {"kb_id": kb_id, "force_refresh": True, "max_depth": None, "max_workers": 2},
            )

        check("first run generated summaries", result1["generated_count"] > 0, detail=str(result1))
        check("second run reuses cache", result2["reused_count"] > 0, detail=str(result2))
        check("force refresh regenerates summaries", result3["generated_count"] > 0, detail=str(result3))

        cache_path = output_dir / "chain_summaries.msgpack"
        report_path = output_dir / "chain_summaries_report.json"
        check("chain_summaries.msgpack created", cache_path.exists(), detail=str(cache_path))
        check("chain_summaries_report.json created", report_path.exists(), detail=str(report_path))

        orig_explain_chain = chain_explainer.explain_chain
        try:
            chain_explainer.explain_chain = lambda *args, **kwargs: (_ for _ in ()).throw(
                RuntimeError("legacy fallback should not be used when cache is warm")
            )
            modifiers_result = kb_modifiers_task._run(
                ws,
                {
                    "kb_id": kb_id,
                    "variable_name": "LG1OSI",
                    "max_depth": None,
                    "no_chains": False,
                    "filter_subsets": True,
                },
            )
        finally:
            chain_explainer.explain_chain = orig_explain_chain

        output_file = output_dir / "variable_modifiers" / "LG1OSI_modifiers.json"
        payload = json.loads(output_file.read_text(encoding="utf-8"))
        chains = payload["results"]["mod"]["call_chains"]
        explanations = [c.get("chain_explanation") for c in chains if c.get("files") == ["root", "mod"]]
        check("modifiers task succeeded", modifiers_result["status"] == "success", detail=str(modifiers_result))
        check("cached explanation attached for root->mod chain", explanations == ["SYNTHETIC_CHAIN_SUMMARY"], detail=str(explanations))
    finally:
        shutil.rmtree(ws.root, ignore_errors=True)


def test_api_entrypoint_contract() -> None:
    print("\n" + "=" * 78)
    print("API entrypoint contract")
    print("=" * 78)

    kb_id = f"kb-chain-api-{uuid.uuid4()}"
    ws = WorkspaceManager(kb_id)
    for d in (ws.root, ws.input_dir, ws.output_dir, ws.cache_dir):
        d.mkdir(parents=True, exist_ok=True)
    _write_json(ws.output_dir / "file_call_graph.json", _build_sample_graph())

    db = SessionLocal()
    try:
        kb = KnowledgeBase(
            id=kb_id,
            name="KB Chain API Test",
            created_by="admin",
            datasource_username=None,
            datasource_folder=None,
            source_path="/tmp/src",
            status="success",
            error=None,
        )
        db.add(kb)
        db.commit()

        admin_user = User(
            username="admin_chain_test",
            hashed_password="x",
            role="admin",
            is_active=True,
        )

        with mock.patch(
            "api.tasks.kb_chain_summaries_task.run_kb_chain_summaries.apply_async",
            return_value=SimpleNamespace(id="task-chain-123"),
        ):
            response = precompute_kb_chain_summaries(
                kb_id=kb_id,
                body=ChainSummariesRequest(force_refresh=False, max_depth=None, max_workers=4),
                db=db,
                current_user=admin_user,
            )
        check("endpoint returns pending status", response.status.value == "pending", detail=str(response.status))
        check("endpoint operation is kb_chain_summaries", response.operation == "kb_chain_summaries")
        check("endpoint returns celery task id", response.celery_task_id == "task-chain-123")
    finally:
        try:
            db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).delete()
            db.commit()
        finally:
            db.close()
        shutil.rmtree(ws.root, ignore_errors=True)


def main() -> int:
    test_chain_helpers()
    test_prompt_labeling()
    test_precompute_and_modifiers_cache()
    test_api_entrypoint_contract()

    print("\n" + "=" * 78)
    print(f"RESULT: PASS={PASS} FAIL={FAIL}")
    print("=" * 78)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
