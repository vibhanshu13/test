"""pytest fixtures for fixes/ tests."""
from __future__ import annotations

import sys
import uuid
from pathlib import Path
from typing import Dict

import pytest
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from api.app import app  # noqa: E402
from api.auth import create_access_token, hash_password  # noqa: E402
from api.db import SessionLocal, create_tables  # noqa: E402
from api.models.user import User  # noqa: E402


def _make_headers(username: str, role: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {create_access_token(username, role)}"}


@pytest.fixture(scope="session", autouse=True)
def _ensure_tables():
    create_tables()


@pytest.fixture(scope="session")
def admin_username():
    suffix = uuid.uuid4().hex[:8]
    username = f"kff_admin_{suffix}"
    db = SessionLocal()
    try:
        db.add(User(
            username=username,
            hashed_password=hash_password("TestPass123!"),
            role="admin",
            is_active=True,
        ))
        db.commit()
    finally:
        db.close()
    yield username
    db = SessionLocal()
    try:
        db.query(User).filter(User.username == username).delete()
        db.commit()
    finally:
        db.close()


@pytest.fixture(scope="session")
def user_username():
    suffix = uuid.uuid4().hex[:8]
    username = f"kff_user_{suffix}"
    db = SessionLocal()
    try:
        db.add(User(
            username=username,
            hashed_password=hash_password("TestPass123!"),
            role="user",
            is_active=True,
        ))
        db.commit()
    finally:
        db.close()
    yield username
    db = SessionLocal()
    try:
        db.query(User).filter(User.username == username).delete()
        db.commit()
    finally:
        db.close()


@pytest.fixture(scope="session")
def admin_headers(admin_username):
    return _make_headers(admin_username, "admin")


@pytest.fixture(scope="session")
def user_headers(user_username):
    return _make_headers(user_username, "user")


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c
