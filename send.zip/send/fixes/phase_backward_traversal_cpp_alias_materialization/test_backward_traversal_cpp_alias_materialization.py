#!/usr/bin/env python3
"""Verification for alias-only C++ field materialization."""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO_ROOT))

from models.analysis_context import AnalysisContext  # noqa: E402
from models.variable_lineage import VariableLineageGraph  # noqa: E402


RESULTS: list[tuple[str, str, str]] = []


def check(label: str, cond: bool, detail: str = "") -> None:
    status = "PASS" if cond else "FAIL"
    RESULTS.append((status, label, detail))
    tail = f"   — {detail}" if detail else ""
    print(f"  {status}   {label}{tail}")


def _mk_ctx(
    graph: VariableLineageGraph | None = None,
    *,
    file_path: str = "fake.json",
    field_asm_aliases: dict[str, str] | None = None,
    field_asm_alias_sources: dict[str, str] | None = None,
) -> AnalysisContext:
    ctx = AnalysisContext(file_path=Path(file_path))
    ctx.add_metadata("variable_lineage", graph or VariableLineageGraph())

    class U:
        pass

    unit = U()
    unit.symbol_aliases = {}
    unit.functions = []
    unit.field_asm_aliases = dict(field_asm_aliases or {})
    unit.field_asm_alias_sources = dict(field_asm_alias_sources or {})
    ctx.add_metadata("c_family_unit", unit)
    return ctx


def _find_node(graph: VariableLineageGraph, name: str, kind: str):
    return graph.nodes.get(f"{kind}:{name}")


def _find_edges(graph: VariableLineageGraph, source: str, target: str, relation: str):
    return [
        edge for edge in graph.edges
        if edge.source == source and edge.target == target and edge.relation == relation
    ]


def test_alias_only_materialization() -> None:
    print("\n" + "=" * 78)
    print("6.1  alias-only field is materialized and bridged to ASM memory")
    print("=" * 78)

    asm_graph = VariableLineageGraph()
    asm_graph.add_definition(
        "LG1OSI",
        "memory",
        file="lg1lg1.mac",
        line=312,
        expression="DS",
        scope="LG1G1&A",
        statement_id="ASM_1",
        macro_expansion_parent=None,
    )

    contexts = {
        "dx740200.cpp.json": _mk_ctx(
            file_path="dx740200.cpp.json",
            field_asm_aliases={"CasGLRec.onlineSrcInd": "LG1OSI"},
            field_asm_alias_sources={"CasGLRec.onlineSrcInd": "cclg1g1.hpp"},
        ),
        "lg1lg1.mac.json": _mk_ctx(asm_graph, file_path="lg1lg1.mac.json"),
    }

    from passes.global_lineage_stitcher import GlobalLineageStitcher  # noqa: E402

    stitcher = GlobalLineageStitcher()
    stitcher.process_contexts(contexts)
    gg = stitcher.global_graph

    node = _find_node(gg, "CasGLRec.onlineSrcInd", "struct_field")
    check("canonical CasGLRec.onlineSrcInd node exists", node is not None)
    if node:
        md = node.metadata or {}
        check("canonical node carries asm_alias=LG1OSI", md.get("asm_alias") == "LG1OSI", detail=str(md))
        check("canonical node is marked alias_materialized", md.get("alias_materialized") is True, detail=str(md))

    mem_id = "memory:LG1OSI"
    field_id = "struct_field:CasGLRec.onlineSrcInd"
    check("memory -> canonical assign edge exists", bool(_find_edges(gg, mem_id, field_id, "assign")))
    check("canonical -> memory assign edge exists", bool(_find_edges(gg, field_id, mem_id, "assign")))
    check("memory -> canonical alias edge exists", bool(_find_edges(gg, mem_id, field_id, "alias")))
    check("canonical -> memory alias edge exists", bool(_find_edges(gg, field_id, mem_id, "alias")))


def test_runtime_field_bridge() -> None:
    print("\n" + "=" * 78)
    print("6.2  runtime struct_field is bridged to canonical alias field")
    print("=" * 78)

    cpp_graph = VariableLineageGraph()
    cpp_graph.add_definition(
        "globalLimitsUpdate::da7gl->cmSystem",
        "struct_field",
        file="dx740200.cpp",
        line=122,
        expression="assignment",
        scope="globalLimitsUpdate",
        statement_id="CPP_1",
        macro_expansion_parent=None,
    )
    cpp_graph.annotate_node(
        "globalLimitsUpdate::da7gl->cmSystem",
        "struct_field",
        asm_alias="WK_CMO",
        enclosing_type="Da7gl",
    )

    asm_graph = VariableLineageGraph()
    asm_graph.add_definition(
        "WK_CMO",
        "memory",
        file="da7gl.mac",
        line=1,
        expression="DS",
        scope="DA7GL",
        statement_id="ASM_1",
        macro_expansion_parent=None,
    )

    contexts = {
        "dx740200.cpp.json": _mk_ctx(
            cpp_graph,
            file_path="dx740200.cpp.json",
            field_asm_aliases={"Da7gl.cmSystem": "WK_CMO"},
            field_asm_alias_sources={"Da7gl.cmSystem": "ccda7gl.hpp"},
        ),
        "da7gl.mac.json": _mk_ctx(asm_graph, file_path="da7gl.mac.json"),
    }

    from passes.global_lineage_stitcher import GlobalLineageStitcher  # noqa: E402

    stitcher = GlobalLineageStitcher()
    stitcher.process_contexts(contexts)
    gg = stitcher.global_graph

    canonical_id = "struct_field:Da7gl.cmSystem"
    runtime_id = "struct_field:globalLimitsUpdate::da7gl->cmSystem"
    check("canonical Da7gl.cmSystem node exists", canonical_id in gg.nodes)
    check("runtime -> canonical assign edge exists", bool(_find_edges(gg, runtime_id, canonical_id, "assign")))
    check("canonical -> runtime assign edge exists", bool(_find_edges(gg, canonical_id, runtime_id, "assign")))


def test_real_file_smoke() -> None:
    print("\n" + "=" * 78)
    print("6.3  real-file smoke: dx740200 include aliases can materialize LG1OSI")
    print("=" * 78)

    cpp = REPO_ROOT.parent / "asm" / "dx740200.cpp"
    if not cpp.exists():
        check("real-file smoke skipped because dx740200.cpp missing", True)
        return

    from multi_file.c_family_analyzer import CFamilyAnalyzer  # noqa: E402
    from passes.global_lineage_stitcher import GlobalLineageStitcher  # noqa: E402

    analyzer = CFamilyAnalyzer("cpp", search_paths=[cpp.parent])
    result = analyzer.analyze(cpp, cpp.read_text(errors="replace"))
    unit = result.analysis_context.get_metadata("c_family_unit")
    aliases = dict(getattr(unit, "field_asm_aliases", {}) or {})
    check("real file has CasGLRec.onlineSrcInd -> LG1OSI alias", aliases.get("CasGLRec.onlineSrcInd") == "LG1OSI",
          detail=str(aliases.get("CasGLRec.onlineSrcInd")))

    asm_graph = VariableLineageGraph()
    asm_graph.add_definition(
        "LG1OSI",
        "memory",
        file="lg1lg1.mac",
        line=312,
        expression="DS",
        scope="LG1G1&A",
        statement_id="ASM_1",
        macro_expansion_parent=None,
    )
    asm_ctx = _mk_ctx(asm_graph, file_path="lg1lg1.mac.json")

    stitcher = GlobalLineageStitcher()
    stitcher.process_contexts({
        "dx740200.cpp.json": result.analysis_context,
        "lg1lg1.mac.json": asm_ctx,
    })
    gg = stitcher.global_graph
    node = _find_node(gg, "CasGLRec.onlineSrcInd", "struct_field")
    check("real-file stitch materializes CasGLRec.onlineSrcInd", node is not None)
    check("real-file stitch creates memory -> canonical assign edge",
          bool(_find_edges(gg, "memory:LG1OSI", "struct_field:CasGLRec.onlineSrcInd", "assign")))


def test_runner_smoke() -> None:
    print("\n" + "=" * 78)
    print("6.4  regenerated blueprints feed the backward runner with alias seed")
    print("=" * 78)

    asm_dir = REPO_ROOT.parent / "asm"
    required = [
        asm_dir / "lg1lg1.mac",
        asm_dir / "cclg1g1.hpp",
        asm_dir / "dx740200.cpp",
        asm_dir / "dx730000.cpp",
        asm_dir / "da78.asm",
    ]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        check("runner smoke skipped because required source files are missing", True, detail=", ".join(missing))
        return

    with tempfile.TemporaryDirectory() as td:
        out_dir = Path(td) / "out"
        out_dir.mkdir(parents=True, exist_ok=True)
        graph_file = out_dir / "file_call_graph.json"
        result_file = out_dir / "lg1osi_backward.json"

        subprocess.run(
            [
                sys.executable,
                str(REPO_ROOT / "main.py"),
                "-s",
                str(asm_dir),
                "-o",
                str(out_dir),
                *[str(path) for path in required],
            ],
            cwd=REPO_ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            [
                sys.executable,
                str(REPO_ROOT / "file_call_graph.py"),
                "--asm-dir",
                str(asm_dir),
                "--blueprint-dir",
                str(out_dir),
                "--output",
                str(graph_file),
            ],
            cwd=REPO_ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            [
                sys.executable,
                "-m",
                "backward_traversal.cli",
                "LG1OSI",
                "--chain-files",
                "dx730000,dx740200,da78",
                "--blueprint-dir",
                str(out_dir),
                "--asm-dir",
                str(asm_dir),
                "--graph",
                str(graph_file),
                "--output",
                str(result_file),
            ],
            cwd=REPO_ROOT,
            check=True,
            capture_output=True,
            text=True,
        )

        payload = json.loads(result_file.read_text())
        upstream = payload["files"]["dx740200"]["upstream"]
        trace = upstream.get("cpp_lineage_trace") or {}
        seeds = trace.get("seeds") or []
        check("runner output surfaces LG1OSI alias mapping",
              upstream.get("asm_field_aliases", {}).get("LG1OSI") == ["CasGLRec.onlineSrcInd"],
              detail=str(upstream.get("asm_field_aliases")))
        check("runner output includes alias-field seed",
              any("CasGLRec.onlineSrcInd" in seed for seed in seeds),
              detail=str(seeds))


def main() -> int:
    print("=" * 78)
    print("  Backward traversal alias-field materialization verification")
    print("=" * 78)

    test_alias_only_materialization()
    test_runtime_field_bridge()
    test_real_file_smoke()
    test_runner_smoke()

    passed = sum(1 for status, _, _ in RESULTS if status == "PASS")
    failed = sum(1 for status, _, _ in RESULTS if status == "FAIL")
    skipped = sum(1 for status, _, _ in RESULTS if status == "SKIP")
    print("\n" + "=" * 78)
    print(f"  Results: {passed} PASS / {failed} FAIL / {skipped} SKIP   (total {len(RESULTS)})")
    print("=" * 78)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
