# Backward Traversal — Alias-Only C++ Field Materialization

**Status:** DONE.
**Source gap:** Backward traversal bridge integration is present, but alias-only fields such as `CasGLRec.onlineSrcInd -> LG1OSI` do not become walkable C++ lineage nodes in `global_variable_lineage`.
**Depends on:** `354a818` (`Add backward traversal C++ lineage bridge`).

---

## 1. The gap

For some variables, the cross-language mapping exists only in metadata:

- ASM macro field exists, e.g. `LG1OSI&A` in `lg1lg1.mac`
- C++ header field exists, e.g. `CasGLRec.onlineSrcInd` in `cclg1g1.hpp`
- Blueprint records `field_asm_aliases["CasGLRec.onlineSrcInd"] = "LG1OSI"`

But the stitched `global_variable_lineage` graph has no `struct_field`
node for `CasGLRec.onlineSrcInd`, and no `cpp_field_to_asm` stitch edge for
that field. As a result:

- backward traversal sees the alias metadata,
- but it cannot actually seed the C++ walk from the field itself,
- so it falls back to register-seeded traversal when a TPF bridge exists.

This is why `LG1OSI` is only partially bridged today.

---

## 2. What this phase adds

Materialize alias-backed C++ struct fields into the stitched global graph even
when they only exist in `field_asm_aliases` metadata and not in local `.cpp`
assignments.

Three concrete behaviors:

1. Create a canonical `struct_field` node per alias mapping:
   - Example: `struct_field:CasGLRec.onlineSrcInd`
2. Bridge that canonical node to the ASM memory node:
   - Example: `memory:LG1OSI <-> struct_field:CasGLRec.onlineSrcInd`
3. When a concrete runtime `struct_field` already exists for the same field,
   bridge the runtime node to the canonical declaration node:
   - Example: `globalLimitsUpdate::da7gl->cmSystem <-> Da7gl.cmSystem`

This gives the traversal a stable field-level entry point and preserves real
runtime lineage when it exists.

---

## 3. Scope

### In scope
- `global_variable_lineage` completeness for alias-only C++ fields.
- Canonical declaration-style struct-field nodes derived from
  `field_asm_aliases`.
- Bidirectional assign/alias bridges:
  - canonical C++ field ↔ ASM memory
  - canonical C++ field ↔ concrete runtime C++ field
- Backward traversal seedability for alias-only fields like `LG1OSI`.

### Out of scope
- Rebuilding parser semantics for header files.
- New ASM-side DSECT offset inference.
- Downstream traversal redesign.

---

## 4. Files touched

| File | Change |
|---|---|
| `passes/global_lineage_stitcher.py` | Add alias-field materialization pass and canonical/runtime field bridging helpers. |
| `fixes/phase_backward_traversal_cpp_alias_materialization/test_backward_traversal_cpp_alias_materialization.py` | Verification for alias-only field materialization and stitched traversal seedability. |
| `fixes/README.md` | Mark this phase when complete. |

---

## 5. Implementation notes

### 5.1 Canonical field nodes

For each `field_asm_aliases` entry from C/C++ contexts:

```python
"CasGLRec.onlineSrcInd" -> "LG1OSI"
```

materialize:

```python
struct_field:CasGLRec.onlineSrcInd
```

with metadata:

```python
{
  "asm_alias": "LG1OSI",
  "enclosing_type": "CasGLRec",
  "alias_materialized": True,
  "alias_source": "field_asm_aliases",
  "hpp_source": "cclg1g1.hpp",
}
```

### 5.2 Canonical ↔ ASM memory bridge

If `memory:LG1OSI` exists in the merged graph, bridge it to the canonical
field node using the existing bridge helper shape so the field is reachable
from ASM and vice versa.

### 5.3 Canonical ↔ runtime field bridge

If a real runtime `struct_field` node already exists and its suffix matches the
canonical field path, add assign/alias glue edges in both directions so:

- declaration-only canonical fields remain stable cross-file anchors
- runtime traces still reach actual executable lineage

### 5.4 Stitcher ordering

Run materialization before `_stitch_asm_alias_struct_fields()` so the existing
Phase-4 stitcher can annotate/link the canonical nodes too.

---

## 6. Verification (exit criteria)

`fixes/phase_backward_traversal_cpp_alias_materialization/test_backward_traversal_cpp_alias_materialization.py`

### 6.1 Synthetic alias-only materialization

Build two contexts:
- C++ context with `field_asm_aliases = {"CasGLRec.onlineSrcInd": "LG1OSI"}`
- ASM/global graph side with `memory:LG1OSI`

After stitch:
- canonical node `struct_field:CasGLRec.onlineSrcInd` exists
- node metadata includes `asm_alias=LG1OSI`
- assign/alias bridge exists between canonical field and `memory:LG1OSI`

### 6.2 Runtime-field bridge

Add an existing runtime field node such as
`struct_field:globalLimitsUpdate::da7gl->cmSystem` with `asm_alias=WK_CMO`
and a canonical alias entry `Da7gl.cmSystem -> WK_CMO`.

After stitch:
- canonical `Da7gl.cmSystem` exists
- glue edges connect runtime field ↔ canonical field

### 6.3 Real blueprint smoke — LG1OSI

Use `integration_out/asm/dx740200.cpp.json`:
- confirm `field_asm_aliases["CasGLRec.onlineSrcInd"] == "LG1OSI"`
- rebuild/inspect stitched graph path
- assert a canonical `CasGLRec.onlineSrcInd` struct-field node exists in
  global lineage and is bridge-connected to `memory:LG1OSI`

### 6.4 Backward runner smoke — LG1OSI

Run backward-only on:

```bash
python3 -m backward_traversal.cli LG1OSI \
  --chain-files dx730000,dx740200,da78 ...
```

Assert:
- `upstream.asm_field_aliases["LG1OSI"] == ["CasGLRec.onlineSrcInd"]`
- `upstream.cpp_lineage_trace.seeds` contains an alias-field seed
  referencing `CasGLRec.onlineSrcInd`

### 6.5 Regression

- Existing `fixes/phase_backward_traversal_cpp_bridge/test_backward_traversal_cpp_bridge.py` still passes.
- Representative `WK_CMO` run still contains field-level seeds.

---

## 7. Resume

1. Read this plan.
2. Write the verification script first.
3. Patch `passes/global_lineage_stitcher.py`.
4. Run synthetic + real smoke tests repeatedly.
5. Re-run backward traversal bridge tests.
6. Commit when the alias-field seed path is confirmed in real output.
