# Variable Flow — Architecture & Logic Reference

> **Last updated:** 2026-05-11
> **Branch:** `dev_tabish`
> **Key files:** `api/routes/knowledge_base.py` · `get_equivalent_variable.py` · `passes/variable_lineage_builder.py` · `json_emitter.py`

---

## 1. What the Flow Does

`GET_VARIABLE_FLOW` traces a named variable from a **source file** to a **target file** across the inter-file call graph, producing a hop-by-hop chain that shows:

- which node in each intermediate file represents the same memory location
- which matching **strategy** was used at each hop
- the variable's name in the target file (may differ due to aliases/DSECT renaming)
- any hops where the variable was not referenced locally but was **carried** on a live register

---

## 2. Entry Point

```
POST /v1/knowledge-bases/{kb_id}/variable-flow
```

**Request schema** (`VariableFlowRequest`):

| Field | Type | Required | Description |
|---|---|---|---|
| `source_file` | string | ✓ | File stem where the variable is known (e.g. `da76`) |
| `variable` | string | ✓ | Short name or `node_id` in the source file (e.g. `LG1OSI`) |
| `target_file` | string | ✓ | File stem to trace into (e.g. `xh80`) |
| `max_path_length` | int | — | Max hops per path (default 15, max 50) |
| `max_paths` | int | — | Max paths enumerated by DFS (default 100, max 1000) |

**Response** contains:

- `canonical_key` / `canonical_identity` — resolved identity fingerprint for the variable
- `resolved_count` / `chains` — paths that successfully found the variable in the target
- `unresolved_chains` — paths where the chain broke, each with `failure_at` indicating the first file that couldn't resolve
- `warnings` — non-fatal issues (fallback to full graph, missing blueprints, etc.)

---

## 3. Handler — Step by Step

### Step 1: Resolve the origin node

`resolve_node_id(bp, variable)` searches the source blueprint for a node matching the given name. Checks:

1. Exact `node_id` match
2. `variable_name` suffix match
3. Case-insensitive fallback

Fails fast with 404 if not found.

### Step 2: Identify canonical key and identity fingerprint

`get_physical_identity(bp, node_id)` extracts the four-layer identity from the source node:

| Layer | Field | Example |
|---|---|---|
| L1 | `access_identity` | `CE1CRA:35` |
| L2 | `symbolic_identity` | `LG1G1:LG1OSI` |
| L4 | `dsect` + `field_offset` | `LG1G1`, `28` |
| L5 | `name_upper` | `LG1OSI` |

The strongest available fingerprint becomes the **canonical key** used to look up the `variable_hop_index`.

### Step 3: Build the filtered subgraph

`_build_filtered_subgraph(call_graph, var_files, source_file, target_file)`

Collects the set of files where the variable appears in the hop index (`var_files`). Restricts the DFS to `var_files ∪ {source_file, target_file}`. This reduces a 1400-file graph to typically 5–15 nodes, giving a **100–1000× speedup** over full-graph DFS.

If the filtered subgraph produces **zero paths**, the handler falls back to the full call graph and emits a warning.

### Step 4: Enumerate all call-graph paths (DFS)

`_find_paths(graph, source, target, max_length, max_paths)`

Depth-first search with:
- visited-set cycle detection (no file visited twice per path)
- `max_path_length` prune (path abandoned if it exceeds the limit)
- `max_paths` prune (DFS stopped once enough paths are collected)

### Step 5: Trace each path

For every path found, `_trace_variable_along_path(path, kb_id, bp, node_id, ...)` walks the path file by file.

---

## 4. Per-Hop Tracing Logic

Each file `f` in the path (except the origin) goes through the following in order:

```
1. Load blueprint for f
   └── if missing → record strategy=blueprint_missing_carried, continue

2. find_match_in_file(curr_bp, prev_match_id, physical_identity)
   └── runs Strategies 1–6 (see §5)

3. If no match found AND identity exists:
   ├── Register liveness check (see §6)
   │   └── if KILL → failure_at=f, break
   └── record strategy=no_match_carried, carry identity to next file

4. If no match found AND no identity:
   └── failure_at=f, break

5. If match found:
   └── record hop with matched node_id and strategy, update current_name/identity
```

The chain is marked **resolved** only if a match is found in the **target file**.

---

## 5. Six Matching Strategies (in priority order)

### Strategy 1 — Parameter Bridge

Checks for a `parameter_bridge` or `param_alias` edge between the previous file's node and a node in the current file. Handles formal-parameter passing at ENTRC/CALL boundaries.

### Strategy 2 — Access Identity Match

Compares `access_identity` (CE-slot + byte offset, e.g. `CE1CRA:35`). Exact string match. Finds renamed variables that live at the same TCB/ECB slot.

**Example:** `WB1ACCTC` in da76 (access id `CE1CRA:35`) → `WORKACCT` in xh87 (same slot).

### Strategy 2.5 — Symbolic Identity Match

Compares `symbolic_identity` (DSECT name + field name, e.g. `LG1G1:LG1OSI`). Exact match after uppercasing. Finds variables that share DSECT membership across files even when the DSECT is mapped to different registers.

**Example:** `LG1OSI` resolved across da76→da78→xh80→xh85 via `LG1G1:LG1OSI`.

### Strategy 3 — ECB Field Match

Matches on `ecb_field` annotation plus variable name. Used for CE/ECB control-block fields that appear by the same name in multiple files without a DSECT qualifier.

**Example:** `SW00RTN`, `CE1CR7`, `D6` matched via ECB field across all files they appear in.

### Strategy 4 — Direct Name Match

Falls back to matching by `variable_name` (uppercased) with no identity check. Only fires when no identity fingerprint is available. Prevents trivially matching DSECT-qualified variables of a different kind.

### Strategy 5 — DSECT + Offset Match

Matches by `(dsect_name, field_offset)` pair. Finds the variable even when it has been renamed in the target file, provided the DSECT membership and byte offset are identical.

**Example:** `WB1ACCTC` (offset 35) → `CZEROS INIT REPL` (same DSECT, same offset) in xh80.

### Strategy 6 — Global Alias / Bridge

Checks the `global_variable_lineage` graph for `arg_bind`, `bridge`, or `store` edges connecting the previous file's node to any node in the current file. Handles inter-file variable passing via explicit alias or write-through.

---

## 6. Register Liveness Check

Fires **only** when `find_match_in_file` returns no match but the variable has an identity fingerprint (the `no_match_carried` path). This prevents false carries when the register holding the variable's base address was overwritten.

### `_check_register_carry_safety(curr_bp, base_reg, target_dsect, target_access_id)`

**Rule 1 — CE exception:**
If `target_access_id` starts with `CE1CR`, the variable lives at a fixed TCB offset that is always valid. Skip all register checks → **safe**.

**Rule 2 — Self-loaded kill:**
If `base_reg` is in `curr_bp["register_entry_state"]["self_loaded_regs"]` → the callee wrote its own value into the register before its first USING. The caller's identity is gone. **KILL**.

**Rule 3 — Inherited + DSECT conflict:**
If `base_reg` is in `inherited_regs` but the callee's USING maps `base_reg` to a **different** DSECT than `target_dsect` → the register means something else in this file. **KILL**.

**Rule 4 — Inherited + same DSECT (or no DSECT to compare):**
Register is inherited from caller and DSECT mapping is consistent → identity **carried safely**.

**Rule 5 — No register entry state data:**
Blueprint pre-dates register tracking (legacy). Carry conservatively.

### How `register_entry_state` is populated (parser)

`passes/variable_lineage_builder.py` tracks two sets as it processes each file:

- `_regs_written_so_far` — updated by every `L`, `LR`, `LTR`, `LA`, `LM` instruction
- `_using_established_regs` — updated when a `USING` directive is processed

At the first `USING reg,DSECT` for a register:
- if `reg` is in `_regs_written_so_far` → add to `self_loaded_regs` (callee loaded it)
- otherwise → add to `inherited_regs` (caller provided it)

The result is written to the blueprint as:

```json
"register_entry_state": {
  "inherited_regs": ["R1", "R3", "R4", "R5", "R6", "R7"],
  "self_loaded_regs": ["R14", "R15"]
}
```

`R14`/`R15` are return-address/code registers — always self-loaded. DSECT base registers (`R3`–`R7`) are typically inherited from the caller in z/TPF.

---

## 7. Removed: Name Fallback (Strategy 7)

A previous "leaf scan" strategy matched nodes by their last colon-delimited name component regardless of DSECT qualification or node kind. **This was removed** because it produced false matches:

- A variable named `MYVAR` in DSECT `LG1G1` would match a parameter also named `MYVAR` from a completely different context.
- It bypassed the rigorous L1/L2/L4 identity checks that all other strategies respect.

SC-18, SC-19, SC-20, SC-24 in the E2E suite explicitly assert that these cases are now correctly reported as **unresolved** rather than falsely resolved.

---

## 8. Response Shape

```jsonc
{
  "variable": "LG1OSI",
  "source_file": "da76",
  "target_file": "xh85",
  "canonical_key": "LG1G1:LG1OSI",
  "canonical_identity": {
    "access_identity": null,
    "symbolic_identity": "LG1G1:LG1OSI",
    "dsect": "LG1G1",
    "field_offset": 28
  },
  "total_paths_found": 1,
  "resolved_count": 1,
  "chains": [
    {
      "path": ["da76", "da78", "xh80", "xh85"],
      "resolved": true,
      "target_variable": "LG1OSI",
      "target_node_id": "memory:LG1OSI",
      "hops": [
        { "file": "da76", "variable": "LG1OSI",        "strategy": "origin",                              "occurrences": [] },
        { "file": "da78", "variable": "LG1OSI",        "strategy": "DSECT + Offset",                     "occurrences": [...] },
        { "file": "xh80", "variable": "LG1OSI",        "strategy": "Symbolic Identity Match (Name + DSECT:Field)", "occurrences": [...] },
        { "file": "xh85", "variable": "LG1OSI",        "strategy": "Symbolic Identity Match (Name + DSECT:Field)", "occurrences": [...] }
      ],
      "failure_at": null
    }
  ],
  "unresolved_chains": [],
  "warnings": []
}
```

---

## 9. Supporting Indexes (pre-built)

### `variable_hop_index.json`

Built by `build_variable_hop_index.py`. Maps:

```
canonical_key → file_stem → [ {line, expression, operation_type, transformation, relation, node_id, variable_name} ]
```

Used to:
1. Determine `var_files` for filtered subgraph pruning
2. Provide occurrence records (line/expression) for each hop in the chain

Keys are the strongest canonical fingerprint available: `access_identity` > `symbolic_identity` > `DSECT:offset` > `file_label:name`.

### `file_call_graph.json`

Nodes are file stems; edges are directed caller→callee links extracted from `ENTRC`/`CALL` instructions. The DFS runs over this graph.

---

## 10. Architecture Diagram

```
POST /variable-flow
        │
        ▼
resolve_node_id()        ← find source node in source blueprint
        │
        ▼
get_physical_identity()  ← extract L1/L2/L4/L5 fingerprint
        │
        ▼
variable_hop_index       ← look up var_files (files where var appears)
        │
        ▼
_build_filtered_subgraph()
  ├── restricted DFS graph: var_files ∪ {src, tgt}
  └── fallback to full graph if 0 paths found
        │
        ▼
_find_paths() [DFS]      ← enumerate all call-graph paths src→tgt
        │
        ▼
_trace_variable_along_path()   ← for each path
  │
  ├─ for each intermediate file f:
  │   ├── load blueprint
  │   ├── find_match_in_file()   ← Strategies 1–6
  │   │     Strategy 1: Parameter Bridge
  │   │     Strategy 2: Access Identity Match
  │   │     Strategy 2.5: Symbolic Identity Match
  │   │     Strategy 3: ECB Field Match
  │   │     Strategy 4: Direct Name Match
  │   │     Strategy 5: DSECT + Offset Match
  │   │     Strategy 6: Global Alias / Bridge
  │   │
  │   ├── if no match + identity exists:
  │   │     _check_register_carry_safety()   ← 5-point liveness check
  │   │     ├── CE exception      → safe
  │   │     ├── self_loaded kill  → KILL (break chain)
  │   │     ├── DSECT conflict    → KILL (break chain)
  │   │     └── inherited OK      → no_match_carried
  │   │
  │   └── if no match + no identity → failure_at=f, break
  │
  └─ chain resolved if target file matched
```

---

## 11. Key Constants

| Constant | Value | Meaning |
|---|---|---|
| `max_path_length` default | 15 | Max files in a single path |
| `max_paths` default | 100 | Max paths enumerated |
| CE prefix | `CE1CR` | Registers always safe to carry |
| Strategy priority | 1→2→2.5→3→4→5→6 | Earlier strategies win |
