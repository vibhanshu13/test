#!/usr/bin/env python3
"""Tests for Variable Flow Tracing System.

Covers:
  A. Internal helpers in build_variable_identity_index.py
  B. build_index() / load_index()
  C. _find_paths() DFS helper
  D. _trace_variable_along_path() per-hop resolver
  E. Real blueprint verification (conditional on Docker data)

Run from the project root:
    python3 fixes/phase_variable_flow/test_variable_flow.py
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# ---------------------------------------------------------------------------
# Stub out heavy server-side dependencies so pure utility functions inside
# api.routes.knowledge_base can be imported without a running Redis / DB.
# ---------------------------------------------------------------------------

import types as _types


def _make_stub(name: str) -> _types.ModuleType:
    """Return a minimal module stub that silently absorbs attribute access."""

    class _Stub:
        def __getattr__(self, item):
            return _Stub()

        def __call__(self, *a, **kw):
            return _Stub()

        def __class_getitem__(cls, item):
            return cls

    mod = _types.ModuleType(name)
    mod.__dict__["__path__"] = []  # make it look like a package
    stub = _Stub()
    mod.__getattr__ = lambda item: stub  # type: ignore[assignment]
    return mod


# Pre-register stubs for server-side modules not available in the test environment.
# This allows importing pure utility functions from api.routes.knowledge_base without
# needing a running Redis / database.
#
# Strategy: register a meta-path hook that intercepts any import under the listed
# prefixes that hasn't already been resolved (i.e. isn't in sys.modules yet).
# We explicitly skip checking installed packages to avoid recursion issues.

_ALWAYS_STUB_PREFIXES = (
    # These are definitely NOT installed in the plain test environment:
    "redis",
    "celery",
    "kombu",
    "amqp",
    "billiard",
    "vine",
)

# For packages that ARE installed (pydantic, fastapi, sqlalchemy, etc.),
# we do NOT stub them — they will import normally.
# Only stub the ones listed above.

for _prefix in _ALWAYS_STUB_PREFIXES:
    if _prefix not in sys.modules:
        sys.modules[_prefix] = _make_stub(_prefix)


class _StubFinder:
    """Meta path finder: auto-create stubs for submodules of always-stub prefixes."""

    def find_module(self, fullname, path=None):  # noqa: D102
        # Already resolved (real or stub) → don't intercept
        if fullname in sys.modules:
            return None
        # If this is a submodule of a stub prefix, stub it
        for prefix in _ALWAYS_STUB_PREFIXES:
            if fullname == prefix or fullname.startswith(prefix + "."):
                return self
        return None

    def load_module(self, fullname):  # noqa: D102
        if fullname in sys.modules:
            return sys.modules[fullname]
        mod = _make_stub(fullname)
        sys.modules[fullname] = mod
        return mod


sys.meta_path.insert(0, _StubFinder())

# ---------------------------------------------------------------------------
# Test counters + helpers
# ---------------------------------------------------------------------------

PASS: List[str] = []
FAIL: List[str] = []
SKIP: List[str] = []


def check(condition: bool, name: str, detail: str = "") -> None:
    if condition:
        PASS.append(name)
        print(f"  PASS  {name}")
    else:
        FAIL.append(name)
        msg = f"  FAIL  {name}"
        if detail:
            msg += f"\n        {detail}"
        print(msg)


def skip(name: str, reason: str = "") -> None:
    SKIP.append(name)
    msg = f"  SKIP  {name}"
    if reason:
        msg += f"  ({reason})"
    print(msg)


# ---------------------------------------------------------------------------
# Blueprint fixture helpers
# ---------------------------------------------------------------------------

def _mem_node(name: str, **meta) -> Dict[str, Any]:
    """Build a memory-kind node dict."""
    return {"id": f"memory:{name}", "name": name, "kind": "memory", **meta}


def _edge(src: str, tgt: str, rel: str = "assign", **fields) -> Dict[str, Any]:
    """Build an edge dict (node_ids are taken as-is, caller must prefix them)."""
    return {
        "source": src,
        "target": tgt,
        "relation": rel,
        "file": "test",
        "line": 1,
        **fields,
    }


def _make_vl(nodes: list, edges: list) -> Dict[str, Any]:
    """Wrap nodes/edges in a variable_lineage dict."""
    return {"nodes": nodes, "edges": edges}


def _make_bp(nodes: list, edges: list) -> Dict[str, Any]:
    """Build a minimal blueprint dict."""
    return {"variable_lineage": _make_vl(nodes, edges)}


def _write_bp_json(directory: Path, stem: str, bp: Dict[str, Any]) -> Path:
    """Write a blueprint as a JSON .asm.json file (load_blueprint auto-detects JSON)."""
    path = directory / f"{stem}.asm.json"
    path.write_text(json.dumps(bp), encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# Forward adjacency builder (mirrors _build_adjacency from find_variable_modifiers)
# ---------------------------------------------------------------------------

def _simple_forward(edges: List[Tuple[str, str]]) -> Dict[str, List[Tuple[str, str]]]:
    """Build a forward adjacency map from a list of (source, target) pairs."""
    fwd: Dict[str, List[Tuple[str, str]]] = {}
    for s, t in edges:
        fwd.setdefault(s, []).append((t, "CALL"))
    return fwd


# ---------------------------------------------------------------------------
# A. Internal helpers in build_variable_identity_index.py
# ---------------------------------------------------------------------------

def test_A_internal_helpers() -> None:
    print("\n=== A. Internal helpers (build_variable_identity_index) ===")

    from build_variable_identity_index import (
        _stem,
        _name_upper,
        _collect_memory_node_ids,
        _canonical_key_for_node,
        _extract_identity_fields,
    )

    # A1: _stem strips composite suffixes
    check(
        _stem(Path("da76.asm.json")) == "da76",
        "A1a: _stem strips .asm.json",
    )
    check(
        _stem(Path("MYFILE.mac.json")) == "myfile",
        "A1b: _stem strips .mac.json and lowercases",
    )
    check(
        _stem(Path("xh80.json")) == "xh80",
        "A1c: _stem strips .json",
    )
    check(
        _stem(Path("da76.asm.json")) == "da76",
        "A1d: _stem result is lowercase",
        f"got: {_stem(Path('da76.asm.json'))!r}",
    )

    # A2: _name_upper extracts leaf name uppercase
    check(
        _name_upper("memory:LG1G1:LG1OSI") == "LG1OSI",
        "A2a: _name_upper extracts field from DSECT-qualified node_id",
    )
    check(
        _name_upper("memory:WB1ACCTC") == "WB1ACCTC",
        "A2b: _name_upper simple node",
    )
    check(
        _name_upper("memory:lg1osi") == "LG1OSI",
        "A2c: _name_upper uppercases",
    )

    # A3: _collect_memory_node_ids returns only memory-class nodes
    vl = {
        "nodes": [
            {"id": "memory:FOO", "kind": "memory"},
            {"id": "register:R5", "kind": "register"},
            {"id": "use@test:10", "kind": "use"},
            {"id": "parameter:BAR", "kind": "parameter"},
            {"id": "variable:BAZ", "kind": "variable"},
            {"id": "struct_field:QUX", "kind": "struct_field"},
        ]
    }
    collected = _collect_memory_node_ids(vl)
    check(
        collected == {"memory:FOO", "parameter:BAR", "variable:BAZ", "struct_field:QUX"},
        "A3: _collect_memory_node_ids includes memory, parameter, variable, struct_field",
        f"got: {collected}",
    )

    # A4: _canonical_key_for_node priority
    edges_access = [
        _edge("memory:MYVAR", "memory:MYVAR", access_identity="CE1CR5:17",
              symbolic_identity="LG1G1:MYVAR", file_label="da76:MYVAR"),
    ]
    key = _canonical_key_for_node("memory:MYVAR", edges_access)
    check(key == "CE1CR5:17", "A4a: access_identity is highest priority canonical key", f"got: {key!r}")

    edges_symbolic = [
        _edge("memory:MYVAR", "memory:MYVAR", symbolic_identity="LG1G1:MYVAR",
              file_label="da76:MYVAR"),
    ]
    key = _canonical_key_for_node("memory:MYVAR", edges_symbolic)
    check(key == "LG1G1:MYVAR", "A4b: symbolic_identity is 2nd priority", f"got: {key!r}")

    edges_label = [
        _edge("memory:MYVAR", "memory:MYVAR", file_label="da76:MYVAR"),
    ]
    key = _canonical_key_for_node("memory:MYVAR", edges_label)
    check(key == "da76:MYVAR", "A4c: file_label is 3rd priority", f"got: {key!r}")

    edges_name_only = [
        _edge("memory:MYVAR", "memory:MYVAR"),
    ]
    key = _canonical_key_for_node("memory:MYVAR", edges_name_only)
    check(key == "MYVAR", "A4d: name_upper is fallback", f"got: {key!r}")

    edges_unrelated = [
        _edge("memory:OTHER", "memory:OTHER", access_identity="CE1CR5:99"),
    ]
    key = _canonical_key_for_node("memory:MYVAR", edges_unrelated)
    check(key == "MYVAR", "A4e: unrelated edges don't contribute", f"got: {key!r}")

    # A5: _extract_identity_fields picks up all five fields from edges
    edges_full = [
        _edge("memory:FOO", "memory:FOO",
              access_identity="CE1CR5:5",
              symbolic_identity="DS1:FOO",
              dsect="DS1",
              field_offset=5,
              file_label="da76:FOO"),
    ]
    fields = _extract_identity_fields("memory:FOO", edges_full)
    check(fields["access_identity"] == "CE1CR5:5", "A5a: access_identity extracted", f"got: {fields!r}")
    check(fields["symbolic_identity"] == "DS1:FOO", "A5b: symbolic_identity extracted")
    check(fields["dsect"] == "DS1", "A5c: dsect extracted")
    check(fields["field_offset"] == 5, "A5d: field_offset extracted")
    check(fields["file_label"] == "da76:FOO", "A5e: file_label extracted")

    fields_empty = _extract_identity_fields("memory:UNKNOWN", edges_full)
    check(
        all(v is None for v in fields_empty.values()),
        "A5f: non-matching node → all None",
        f"got: {fields_empty!r}",
    )


# ---------------------------------------------------------------------------
# B. build_index() / load_index()
# ---------------------------------------------------------------------------

def test_B_build_load_index() -> None:
    print("\n=== B. build_index() / load_index() ===")

    from build_variable_identity_index import build_index, load_index

    with tempfile.TemporaryDirectory() as tmpdir:
        bp_dir = Path(tmpdir) / "blueprints"
        bp_dir.mkdir()
        out_path = Path(tmpdir) / "variable_identity_index.json"

        # B1: Empty blueprint dir → empty index
        result_path = build_index(bp_dir, out_path)
        idx = json.loads(out_path.read_text())
        check(result_path == out_path, "B1a: build_index returns output path")
        check(idx["_meta"]["blueprints_scanned"] == 0, "B1b: 0 blueprints scanned")
        check(idx["_meta"]["unique_identities"] == 0, "B1c: 0 identities")
        check(idx["by_identity"] == {}, "B1d: empty by_identity")
        check(idx["by_name"] == {}, "B1e: empty by_name")

        # B2: Single blueprint with access_identity
        bp2 = _make_bp(
            nodes=[_mem_node("LG1OSI")],
            edges=[
                _edge("memory:LG1OSI", "memory:LG1OSI",
                      access_identity="CE1CR5:17",
                      symbolic_identity="LG1G1:LG1OSI",
                      dsect="LG1G1",
                      field_offset=17,
                      file_label="da76:LG1OSI"),
            ],
        )
        _write_bp_json(bp_dir, "da76", bp2)
        build_index(bp_dir, out_path)
        idx = json.loads(out_path.read_text())

        check("CE1CR5:17" in idx["by_identity"], "B2a: access_identity used as canonical key")
        entry = idx["by_identity"].get("CE1CR5:17", {})
        check(entry.get("access_identity") == "CE1CR5:17", "B2b: access_identity stored in entry")
        check(entry.get("symbolic_identity") == "LG1G1:LG1OSI", "B2c: symbolic_identity stored")
        check(entry.get("dsect") == "LG1G1", "B2d: dsect stored")
        check(entry.get("field_offset") == 17, "B2e: field_offset stored")
        check("da76" in entry.get("files", {}), "B2f: da76 recorded in files")
        check("LG1OSI" in entry.get("names", []), "B2g: LG1OSI in names list")
        check(idx["by_name"].get("LG1OSI") == "CE1CR5:17", "B2h: by_name maps LG1OSI → CE1CR5:17")

        # B3: Symbolic identity only (no access_identity)
        bp3 = _make_bp(
            nodes=[_mem_node("WB1SUPP")],
            edges=[
                _edge("memory:WB1SUPP", "memory:WB1SUPP",
                      symbolic_identity="LG1G1:WB1SUPP",
                      dsect="LG1G1",
                      field_offset=100),
            ],
        )
        _write_bp_json(bp_dir, "xh71", bp3)
        build_index(bp_dir, out_path)
        idx = json.loads(out_path.read_text())
        check("LG1G1:WB1SUPP" in idx["by_identity"], "B3a: symbolic_identity used as key when no access_identity")
        check(idx["by_name"].get("WB1SUPP") == "LG1G1:WB1SUPP", "B3b: by_name maps WB1SUPP → LG1G1:WB1SUPP")

        # B4: file_label only
        bp4 = _make_bp(
            nodes=[_mem_node("LOCALVAR")],
            edges=[
                _edge("memory:LOCALVAR", "memory:LOCALVAR", file_label="xh80:LOCALVAR"),
            ],
        )
        _write_bp_json(bp_dir, "xh80", bp4)
        build_index(bp_dir, out_path)
        idx = json.loads(out_path.read_text())
        check("xh80:LOCALVAR" in idx["by_identity"], "B4a: file_label used as key when no access/symbolic")
        check(idx["by_name"].get("LOCALVAR") == "xh80:LOCALVAR", "B4b: by_name maps name → file_label key")

        # B5: name_upper fallback (no identity fields at all)
        bp5 = _make_bp(
            nodes=[_mem_node("ORPHAN")],
            edges=[
                _edge("memory:ORPHAN", "memory:ORPHAN"),
            ],
        )
        _write_bp_json(bp_dir, "da99", bp5)
        build_index(bp_dir, out_path)
        idx = json.loads(out_path.read_text())
        check("ORPHAN" in idx["by_identity"], "B5a: name_upper used as key when no identity")
        check(idx["by_name"].get("ORPHAN") == "ORPHAN", "B5b: by_name maps name → name_upper key")

    # B6: Same access_identity in two blueprints → single entry, two files
    with tempfile.TemporaryDirectory() as tmpdir:
        bp_dir = Path(tmpdir) / "blueprints"
        bp_dir.mkdir()
        out_path = Path(tmpdir) / "variable_identity_index.json"

        for stem in ("file_a", "file_b"):
            bp = _make_bp(
                nodes=[_mem_node("LG1OSI")],
                edges=[
                    _edge("memory:LG1OSI", "memory:LG1OSI",
                          access_identity="CE1CR5:17",
                          symbolic_identity="LG1G1:LG1OSI",
                          dsect="LG1G1",
                          field_offset=17),
                ],
            )
            _write_bp_json(bp_dir, stem, bp)

        build_index(bp_dir, out_path)
        idx = json.loads(out_path.read_text())
        entry = idx["by_identity"].get("CE1CR5:17", {})
        check(
            set(entry.get("files", {}).keys()) == {"file_a", "file_b"},
            "B6: same access_identity in two files → merged entry",
            f"files: {set(entry.get('files', {}).keys())}",
        )

    # B7: load_index returns None for missing file
    result = load_index(Path("/nonexistent/path/variable_identity_index.json"))
    check(result is None, "B7: load_index returns None for missing file")

    # B8: load_index reads back written index
    with tempfile.TemporaryDirectory() as tmpdir:
        bp_dir = Path(tmpdir) / "blueprints"
        bp_dir.mkdir()
        out_path = Path(tmpdir) / "variable_identity_index.json"
        bp = _make_bp(
            nodes=[_mem_node("TESTVR")],
            edges=[_edge("memory:TESTVR", "memory:TESTVR", access_identity="X:1")],
        )
        _write_bp_json(bp_dir, "test_stem", bp)
        build_index(bp_dir, out_path)
        loaded = load_index(out_path)
        check(loaded is not None, "B8a: load_index returns dict for existing file")
        check("by_identity" in loaded, "B8b: loaded index has by_identity key")
        check("by_name" in loaded, "B8c: loaded index has by_name key")
        check("X:1" in loaded.get("by_identity", {}), "B8d: identity persisted and readable")

    # B9: _meta counts are correct
    with tempfile.TemporaryDirectory() as tmpdir:
        bp_dir = Path(tmpdir) / "blueprints"
        bp_dir.mkdir()
        out_path = Path(tmpdir) / "variable_identity_index.json"
        for i in range(3):
            bp = _make_bp(
                nodes=[_mem_node(f"VAR{i}")],
                edges=[_edge(f"memory:VAR{i}", f"memory:VAR{i}", access_identity=f"X:{i}")],
            )
            _write_bp_json(bp_dir, f"file{i}", bp)
        build_index(bp_dir, out_path)
        idx = json.loads(out_path.read_text())
        check(idx["_meta"]["blueprints_scanned"] == 3, "B9a: blueprints_scanned is 3")
        check(idx["_meta"]["unique_identities"] == 3, "B9b: unique_identities is 3")
        check(idx["_meta"]["unique_names"] == 3, "B9c: unique_names is 3")

    # B10: DSECT-qualified node_id extracts correct leaf name
    with tempfile.TemporaryDirectory() as tmpdir:
        bp_dir = Path(tmpdir) / "blueprints"
        bp_dir.mkdir()
        out_path = Path(tmpdir) / "variable_identity_index.json"
        bp = _make_bp(
            nodes=[{"id": "memory:LG1G1:LG1OSI", "name": "LG1G1:LG1OSI", "kind": "memory"}],
            edges=[_edge("memory:LG1G1:LG1OSI", "memory:LG1G1:LG1OSI",
                         access_identity="CE1CR5:17")],
        )
        _write_bp_json(bp_dir, "da76", bp)
        build_index(bp_dir, out_path)
        idx = json.loads(out_path.read_text())
        entry = idx["by_identity"].get("CE1CR5:17", {})
        check(
            "LG1OSI" in entry.get("names", []),
            "B10: DSECT-qualified node_id → leaf name (LG1OSI) stored in names",
            f"names: {entry.get('names')}",
        )


# ---------------------------------------------------------------------------
# C. _find_paths() DFS helper
# ---------------------------------------------------------------------------

def test_C_find_paths() -> None:
    print("\n=== C. _find_paths() DFS helper ===")

    try:
        from api.routes.knowledge_base import _find_paths
    except Exception as exc:
        skip("C (all)", f"Cannot import _find_paths from api.routes.knowledge_base: {exc}")
        return

    # C1: source == target → single path containing only that node
    result = _find_paths("A", "A", {}, 10, 100)
    check(result == [["A"]], "C1: source == target returns [[source]]", f"got: {result}")

    # C2: Direct single edge A→B
    fwd = _simple_forward([("A", "B")])
    result = _find_paths("A", "B", fwd, 10, 100)
    check(result == [["A", "B"]], "C2: direct edge A→B", f"got: {result}")

    # C3: Two-hop path A→B→C
    fwd = _simple_forward([("A", "B"), ("B", "C")])
    result = _find_paths("A", "C", fwd, 10, 100)
    check(result == [["A", "B", "C"]], "C3: two-hop path A→B→C", f"got: {result}")

    # C4: Two parallel paths A→B→C and A→C (direct shortcut)
    fwd = _simple_forward([("A", "B"), ("B", "C"), ("A", "C")])
    result = _find_paths("A", "C", fwd, 10, 100)
    result_as_tuples = sorted(tuple(p) for p in result)
    check(
        ("A", "B", "C") in result_as_tuples and ("A", "C") in result_as_tuples,
        "C4: both paths found (A→B→C and A→C)",
        f"got: {result}",
    )
    check(len(result) == 2, "C4b: exactly 2 paths found", f"got: {len(result)}")

    # C5: No path exists → empty list
    fwd = _simple_forward([("A", "B"), ("C", "D")])
    result = _find_paths("A", "D", fwd, 10, 100)
    check(result == [], "C5: no path → empty list", f"got: {result}")

    # C6: max_paths=1 limits results
    fwd = _simple_forward([("A", "B"), ("B", "C"), ("A", "C")])
    result = _find_paths("A", "C", fwd, 10, 1)
    check(len(result) == 1, "C6: max_paths=1 → exactly 1 result", f"got: {result}")

    # C7: max_path_length prunes long paths
    # Chain A→B→C→D but max_path_length=2 (2 nodes = 1 hop max)
    fwd = _simple_forward([("A", "B"), ("B", "C"), ("C", "D")])
    result = _find_paths("A", "D", fwd, max_path_length=2, max_paths=100)
    check(result == [], "C7: max_path_length=2 prunes 4-node path", f"got: {result}")

    # C7b: max_path_length=4 allows 4-node path
    result = _find_paths("A", "D", fwd, max_path_length=4, max_paths=100)
    check(result == [["A", "B", "C", "D"]], "C7b: max_path_length=4 allows A→B→C→D", f"got: {result}")

    # C8: Cycles don't cause infinite recursion (A→B→A loop with target C elsewhere)
    fwd = _simple_forward([("A", "B"), ("B", "A"), ("B", "C")])
    result = _find_paths("A", "C", fwd, 10, 100)
    check(result == [["A", "B", "C"]], "C8: cycle A↔B handled correctly, path A→B→C found", f"got: {result}")

    # C9: Multi-fork with 3 paths to target
    fwd = _simple_forward([("S", "X"), ("S", "Y"), ("S", "Z"), ("X", "T"), ("Y", "T"), ("Z", "T")])
    result = _find_paths("S", "T", fwd, 10, 100)
    check(len(result) == 3, "C9: 3 parallel paths found", f"got: {result}")

    # C10: Target not in graph → empty list
    fwd = _simple_forward([("A", "B")])
    result = _find_paths("A", "UNKNOWN", fwd, 10, 100)
    check(result == [], "C10: target not in graph → empty list", f"got: {result}")

    # C11: Source not in graph → empty list (no outgoing edges)
    fwd = _simple_forward([("A", "B")])
    result = _find_paths("UNKNOWN", "B", fwd, 10, 100)
    check(result == [], "C11: source not in graph → empty list", f"got: {result}")


# ---------------------------------------------------------------------------
# D. _trace_variable_along_path()
# ---------------------------------------------------------------------------

def test_D_trace_variable_along_path() -> None:
    print("\n=== D. _trace_variable_along_path() ===")

    try:
        from api.routes.knowledge_base import _trace_variable_along_path
    except Exception as exc:
        skip("D (all)", f"Cannot import _trace_variable_along_path: {exc}")
        return

    # D1: Single-file path [origin] — variable exists in origin, resolved=True
    bp_origin = _make_bp(
        nodes=[_mem_node("LG1OSI")],
        edges=[
            _edge("memory:LG1OSI", "memory:LG1OSI",
                  access_identity="CE1CR5:17",
                  symbolic_identity="LG1G1:LG1OSI",
                  dsect="LG1G1",
                  field_offset=17),
        ],
    )
    blueprints = {"da76": bp_origin}
    result = _trace_variable_along_path(["da76"], "LG1OSI", blueprints, "")
    check(result["resolved"] is True, "D1a: single-file path resolves", f"got: {result}")
    check(len(result["hops"]) == 1, "D1b: exactly 1 hop", f"hops: {result['hops']}")
    check(result["hops"][0]["file"] == "da76", "D1c: hop file is da76")
    check(result["hops"][0]["strategy"] == "origin", "D1d: hop strategy is 'origin'")
    check(result["failure_at"] is None, "D1e: failure_at is None when resolved")

    # D2: Missing origin blueprint → unresolved immediately
    result = _trace_variable_along_path(["missing_file", "da76"], "LG1OSI", {"da76": bp_origin}, "")
    check(result["resolved"] is False, "D2: missing origin → unresolved", f"got: {result}")

    # D3: Direct name match across two files
    bp_target = _make_bp(
        nodes=[_mem_node("LG1OSI")],
        edges=[
            _edge("memory:LG1OSI", "memory:LG1OSI",
                  symbolic_identity="LG1G1:LG1OSI",
                  dsect="LG1G1",
                  field_offset=17),
        ],
    )
    blueprints = {"origin": bp_origin, "target": bp_target}
    result = _trace_variable_along_path(["origin", "target"], "LG1OSI", blueprints, "")
    check(result["resolved"] is True, "D3a: direct name match resolves", f"got: {result}")
    check(len(result["hops"]) == 2, "D3b: 2 hops for 2-file path", f"hops: {result['hops']}")
    final_hop = result["hops"][-1]
    check(final_hop["file"] == "target", "D3c: final hop is in target file")
    check(result["target_variable"] is not None, "D3d: target_variable is set")

    # D4: Missing intermediate blueprint — variable has strong identity, should be carried
    bp_final = _make_bp(
        nodes=[_mem_node("LG1OSI")],
        edges=[
            _edge("memory:LG1OSI", "memory:LG1OSI",
                  access_identity="CE1CR5:17",
                  symbolic_identity="LG1G1:LG1OSI",
                  dsect="LG1G1",
                  field_offset=17),
        ],
    )
    blueprints = {"origin": bp_origin, "missing": None, "final": bp_final}
    result = _trace_variable_along_path(["origin", "missing", "final"], "LG1OSI", blueprints, "")
    # Middle file is missing but variable has access_identity, so it should be carried
    middle_hop = result["hops"][1] if len(result["hops"]) > 1 else {}
    check(
        "carried" in middle_hop.get("strategy", ""),
        "D4: missing intermediate blueprint marked as 'carried' strategy",
        f"middle hop: {middle_hop}, all hops: {result['hops']}",
    )

    # D5: No matching variable in target file → unresolved
    bp_no_match = _make_bp(
        nodes=[_mem_node("COMPLETELY_DIFFERENT")],
        edges=[
            _edge("memory:COMPLETELY_DIFFERENT", "memory:COMPLETELY_DIFFERENT"),
        ],
    )
    blueprints = {"origin": bp_origin, "no_match": bp_no_match}
    result = _trace_variable_along_path(["origin", "no_match"], "LG1OSI", blueprints, "")
    check(result["resolved"] is False, "D5: no match in final file → unresolved", f"got: {result}")
    check(result["failure_at"] == "no_match", "D5b: failure_at is the target file", f"got: {result['failure_at']}")

    # D6: Path order — hops match path order
    bp_hop1 = _make_bp(
        nodes=[_mem_node("LG1OSI")],
        edges=[_edge("memory:LG1OSI", "memory:LG1OSI",
                     symbolic_identity="LG1G1:LG1OSI", dsect="LG1G1", field_offset=17)],
    )
    bp_hop2 = _make_bp(
        nodes=[_mem_node("LG1OSI")],
        edges=[_edge("memory:LG1OSI", "memory:LG1OSI",
                     symbolic_identity="LG1G1:LG1OSI", dsect="LG1G1", field_offset=17)],
    )
    blueprints = {"f0": bp_origin, "f1": bp_hop1, "f2": bp_hop2}
    result = _trace_variable_along_path(["f0", "f1", "f2"], "LG1OSI", blueprints, "")
    if result["resolved"]:
        check(
            [h["file"] for h in result["hops"]] == ["f0", "f1", "f2"],
            "D6: hops are in path order",
            f"got files: {[h['file'] for h in result['hops']]}",
        )
    else:
        skip("D6", "path did not fully resolve in this environment")

    # D7: Return structure has all required keys
    result = _trace_variable_along_path(["origin"], "LG1OSI", {"origin": bp_origin}, "")
    for key in ("path", "hops", "resolved", "target_variable", "target_node_id", "failure_at"):
        check(key in result, f"D7: result has '{key}' key")


# ---------------------------------------------------------------------------
# E. Real blueprint verification (conditional)
# ---------------------------------------------------------------------------

DOCKER_OUTPUT_GLOB = "/var/asm-jobs/*/output"


def _find_real_output_dir() -> Optional[Path]:
    import glob as _glob
    matches = _glob.glob(DOCKER_OUTPUT_GLOB)
    for m in sorted(matches):
        p = Path(m)
        bp_dir = p / "asm"
        if not bp_dir.exists():
            bp_dir = p
        if list(bp_dir.glob("*.asm.json")):
            call_graph = p / "file_call_graph.json"
            if call_graph.exists():
                return p
    return None


def test_E_real_blueprints() -> None:
    print("\n=== E. Real blueprint verification ===")

    from build_variable_identity_index import build_index, load_index

    output_dir = _find_real_output_dir()
    if output_dir is None:
        skip("E (all)", "No real KB output with call graph found at /var/asm-jobs/*/output")
        return

    bp_dir = output_dir / "asm"
    if not bp_dir.exists() or not list(bp_dir.glob("*.asm.json")):
        bp_dir = output_dir
    if not list(bp_dir.glob("*.asm.json")):
        skip("E (all)", "No *.asm.json files found")
        return

    print(f"  Using KB output: {output_dir}")

    # E1: build_index produces non-trivial results on real blueprints
    with tempfile.TemporaryDirectory() as tmpdir:
        out_path = Path(tmpdir) / "test_identity_index.json"
        build_index(bp_dir, out_path)
        idx = json.loads(out_path.read_text())
        meta = idx["_meta"]

        check(meta["blueprints_scanned"] >= 1, "E1a: at least 1 blueprint scanned")
        check(meta["unique_identities"] >= 10, "E1b: at least 10 unique identities",
              f"got: {meta['unique_identities']}")
        check(meta["unique_names"] >= 10, "E1c: at least 10 name entries")

        # Check identity tier distribution
        entries = list(idx["by_identity"].values())
        access_id_count = sum(1 for e in entries if e.get("access_identity"))
        sym_count = sum(1 for e in entries if e.get("symbolic_identity") and not e.get("access_identity"))
        label_count = sum(1 for e in entries if e.get("file_label")
                          and not e.get("access_identity") and not e.get("symbolic_identity"))
        print(f"    L1 (access_id): {access_id_count}  "
              f"L2 (symbolic): {sym_count}  "
              f"L4 (file_label): {label_count}")
        if access_id_count + sym_count + label_count == 0:
            skip("E1d: at least some identities have identity fields",
                 "KB was built before identity enrichment — re-run the pipeline to populate fields")
        else:
            check(True, "E1d: at least some identities have identity fields (not all name-only)")

        # E2: by_name lookup works for a known variable
        # Try some common names
        well_known = ["LG1OSI", "WB1SUPP", "WB1ACCTC"]
        found_any = any(name in idx["by_name"] for name in well_known)
        if not found_any:
            skip("E2: by_name lookup for known variables", "none of LG1OSI/WB1SUPP/WB1ACCTC present")
        else:
            found = [n for n in well_known if n in idx["by_name"]]
            for name in found:
                key = idx["by_name"][name]
                check(key in idx["by_identity"],
                      f"E2: by_name[{name}]={key!r} exists in by_identity")

    # E3: _find_paths on real call graph
    call_graph_file = output_dir / "file_call_graph.json"
    try:
        from api.routes.knowledge_base import _find_paths
    except Exception as exc:
        skip("E3", f"Cannot import _find_paths: {exc}")
        return

    try:
        graph = json.loads(call_graph_file.read_text(encoding="utf-8"))
    except Exception as exc:
        skip("E3", f"Cannot read call graph: {exc}")
        return

    try:
        from find_variable_modifiers import _build_adjacency
        forward, _reverse = _build_adjacency(graph)
    except Exception as exc:
        skip("E3", f"Cannot build adjacency: {exc}")
        return

    nodes = [str(n.get("id") or "") for n in graph.get("nodes", []) if n.get("id")]
    if len(nodes) < 2:
        skip("E3", "Need at least 2 nodes in call graph")
        return

    # Pick first node as source, try to find any node reachable from it
    source = nodes[0]
    reachable = list(forward.get(source, []))
    if not reachable:
        skip("E3", f"Source node {source!r} has no outgoing edges")
        return

    direct_target = reachable[0][0]
    paths = _find_paths(source, direct_target, forward, max_path_length=20, max_paths=50)
    check(len(paths) >= 1, "E3: found at least 1 path in real call graph",
          f"source={source}, target={direct_target}, paths={len(paths)}")
    for p in paths[:3]:
        check(p[0] == source and p[-1] == direct_target,
              f"E3b: path starts at source and ends at target: {p}")

    # E4: _trace_variable_along_path on real data (if LG1OSI is available)
    try:
        from api.routes.knowledge_base import _trace_variable_along_path
        from get_equivalent_variable import load_blueprint as _load_bp
    except Exception as exc:
        skip("E4", f"Cannot import trace helpers: {exc}")
        return

    # Find a known stem pair from the real index
    with tempfile.TemporaryDirectory() as tmpdir:
        out_path = Path(tmpdir) / "test_identity_index.json"
        build_index(bp_dir, out_path)
        idx = json.loads(out_path.read_text())

    if "LG1OSI" not in idx["by_name"]:
        skip("E4", "LG1OSI not in real identity index")
        return

    lg1osi_entry = idx["by_identity"].get(idx["by_name"]["LG1OSI"], {})
    files_with_lg1osi = list(lg1osi_entry.get("files", {}).keys())
    if len(files_with_lg1osi) < 2:
        skip("E4", "LG1OSI appears in fewer than 2 files")
        return

    src_stem = files_with_lg1osi[0]
    tgt_stem = files_with_lg1osi[-1]
    paths = _find_paths(src_stem, tgt_stem, forward, max_path_length=20, max_paths=10)
    if not paths:
        skip("E4", f"No call-graph path from {src_stem} to {tgt_stem}")
        return

    all_stems: Set[str] = set()
    for p in paths:
        all_stems.update(p)
    blueprints: Dict[str, Any] = {}
    for stem in all_stems:
        bp = _load_bp(str(bp_dir), stem)
        blueprints[stem] = bp

    chain = _trace_variable_along_path(paths[0], "LG1OSI", blueprints, str(bp_dir))
    print(f"    LG1OSI trace {src_stem}→{tgt_stem}: resolved={chain['resolved']}, "
          f"{len(chain['hops'])} hops, strategies={[h['strategy'] for h in chain['hops']]}")
    check(len(chain["hops"]) >= 1, "E4: at least 1 hop recorded for real trace")
    check(chain["hops"][0]["strategy"] == "origin", "E4b: first hop strategy is 'origin'")


# ---------------------------------------------------------------------------
# Main runner
# ---------------------------------------------------------------------------

def main() -> int:
    print("=" * 60)
    print("Variable Flow Tracing System — test suite")
    print("=" * 60)

    test_A_internal_helpers()
    test_B_build_load_index()
    test_C_find_paths()
    test_D_trace_variable_along_path()
    test_E_real_blueprints()

    total = len(PASS) + len(FAIL) + len(SKIP)
    print()
    print("=" * 60)
    print(f"{len(PASS)} PASS / {len(FAIL)} FAIL / {len(SKIP)} SKIP  (total {total})")
    if FAIL:
        print("\nFailed tests:")
        for name in FAIL:
            print(f"  - {name}")
    print("=" * 60)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
