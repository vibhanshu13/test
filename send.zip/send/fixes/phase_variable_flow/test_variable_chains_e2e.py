#!/usr/bin/env python3
"""End-to-end variable chain tracing test suite.

Exercises every scenario the variable-flow pipeline can encounter:
  - All 7 identity-resolution strategies
  - Multi-hop chains and variable renaming
  - Multiple parallel paths (resolved / unresolved mix)
  - Bridge files (variable absent in intermediate)
  - Missing blueprints
  - Name-search fallback (DSECT-qualified and kind-mismatch nodes)
  - Source == target, no call-graph path, variable absent in source
  - Complex diamond/fork topologies
  - Identity acquired mid-chain

Each test case:
  1. Describes the scenario
  2. Shows the simulated request body (JSON)
  3. Produces the full response in the exact format the endpoint returns
  4. Checks against expectations (PASS / FAIL)

Output file:
    fixes/phase_variable_flow/chain_test_report.json

Run:
    python3 fixes/phase_variable_flow/test_variable_chains_e2e.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# ---------------------------------------------------------------------------
# Stub heavy server-side modules (same pattern as test_variable_flow.py)
# ---------------------------------------------------------------------------
import types as _types

_STUB_PREFIXES = ("redis", "celery", "kombu", "amqp", "billiard", "vine")


def _make_stub(name: str) -> _types.ModuleType:
    class _S:
        def __getattr__(self, i): return _S()
        def __call__(self, *a, **k): return _S()
        def __class_getitem__(cls, i): return cls
    m = _types.ModuleType(name)
    m.__dict__["__path__"] = []
    m.__getattr__ = lambda i: _S()  # type: ignore
    return m


class _SF:
    def find_module(self, n, p=None):
        if n in sys.modules: return None
        for px in _STUB_PREFIXES:
            if n == px or n.startswith(px + "."): return self
        return None
    def load_module(self, n):
        if n in sys.modules: return sys.modules[n]
        m = _make_stub(n); sys.modules[n] = m; return m


for _px in _STUB_PREFIXES:
    if _px not in sys.modules:
        sys.modules[_px] = _make_stub(_px)
sys.meta_path.insert(0, _SF())

# ---------------------------------------------------------------------------
# Import the helpers under test
# ---------------------------------------------------------------------------
from api.routes.knowledge_base import _find_paths, _trace_variable_along_path  # noqa: E402
from get_equivalent_variable import resolve_node_id, get_physical_identity, strip_prefix  # noqa: E402

# ---------------------------------------------------------------------------
# Test infrastructure
# ---------------------------------------------------------------------------
PASS: List[str] = []
FAIL: List[str] = []
REPORT: List[Dict[str, Any]] = []   # written to chain_test_report.json


def check(cond: bool, name: str, detail: str = "") -> None:
    if cond:
        PASS.append(name)
        print(f"  PASS  {name}")
    else:
        FAIL.append(name)
        msg = f"  FAIL  {name}"
        if detail:
            msg += f"\n        {detail}"
        print(msg)


# ---------------------------------------------------------------------------
# Blueprint / call-graph fixture helpers
# ---------------------------------------------------------------------------

def _node(node_id: str, kind: str = "memory", **meta) -> Dict[str, Any]:
    return {"id": node_id, "name": node_id.split(":")[-1], "kind": kind,
            "metadata": meta if meta else {}}


def _edge(src: str, tgt: str, rel: str = "assign", **fields) -> Dict[str, Any]:
    return {"source": src, "target": tgt, "relation": rel, "line": 1,
            "expression": f"{src} → {tgt}", **fields}


def _bp(nodes: list, edges: list,
        global_edges: Optional[list] = None) -> Dict[str, Any]:
    bp: Dict[str, Any] = {"variable_lineage": {"nodes": nodes, "edges": edges}}
    if global_edges is not None:
        bp["global_variable_lineage"] = {"edges": global_edges}
    return bp


def _fwd(pairs: List[Tuple[str, str]]) -> Dict[str, List[Tuple[str, str]]]:
    """Build a forward-adjacency dict from (src, tgt) pairs."""
    d: Dict[str, List[Tuple[str, str]]] = {}
    for s, t in pairs:
        d.setdefault(s, []).append((t, "CALL"))
    return d


# ---------------------------------------------------------------------------
# Simulate the endpoint response (mirrors get_variable_flow internals)
# ---------------------------------------------------------------------------

def _simulate(
    variable: str,
    source_file: str,
    target_file: str,
    forward: Dict[str, List[Tuple[str, str]]],
    blueprints: Dict[str, Optional[Dict[str, Any]]],
    max_path_length: int = 15,
    max_paths: int = 100,
) -> Dict[str, Any]:
    """
    Produce the same JSON structure as POST /{kb_id}/variable-flow without
    needing a running server, database, or auth layer.
    """
    paths = _find_paths(source_file, target_file, forward, max_path_length, max_paths)

    warnings: List[str] = []

    if not paths:
        return {
            "variable": variable,
            "source_file": source_file,
            "target_file": target_file,
            "canonical_identity": None,
            "total_paths_found": 0,
            "resolved_count": 0,
            "chains": [],
            "unresolved_chains": [],
            "warnings": [
                f"No directed call-graph path found from '{source_file}' to '{target_file}'."
            ],
        }

    if len(paths) >= max_paths:
        warnings.append(
            f"Path search hit max_paths={max_paths} limit; some paths may be omitted."
        )

    for stem in {s for p in paths for s in p}:
        if blueprints.get(stem) is None:
            warnings.append(
                f"Blueprint not found for file '{stem}'; identity tracing may be degraded."
            )

    # Canonical identity from source blueprint
    canonical_identity: Optional[Dict[str, Any]] = None
    source_bp = blueprints.get(source_file)
    if source_bp:
        src_node = resolve_node_id(source_bp, variable)
        dsect, offset, access_id, symbolic_id = get_physical_identity(source_bp, src_node, "")
        canonical_identity = {
            "access_identity": access_id,
            "symbolic_identity": symbolic_id,
            "dsect": dsect,
            "field_offset": offset,
        }
    else:
        warnings.append(f"Source blueprint '{source_file}' not found; canonical identity unavailable.")

    resolved_chains: List[Dict[str, Any]] = []
    unresolved_chains: List[Dict[str, Any]] = []

    for path in paths:
        chain = _trace_variable_along_path(path, variable, blueprints, "")
        if chain["resolved"]:
            chain.pop("failure_at", None)
            resolved_chains.append(chain)
        else:
            unresolved_chains.append(chain)

    return {
        "variable": variable,
        "source_file": source_file,
        "target_file": target_file,
        "canonical_identity": canonical_identity,
        "total_paths_found": len(paths),
        "resolved_count": len(resolved_chains),
        "chains": resolved_chains,
        "unresolved_chains": unresolved_chains,
        "warnings": warnings,
    }


def _run(label: str, description: str, request: Dict[str, Any],
         response: Dict[str, Any], checks: List[Tuple[bool, str, str]]) -> None:
    """Record a scenario, run its checks, and append to REPORT."""
    print(f"\n{'─'*64}")
    print(f"  {label}: {description}")
    print(f"{'─'*64}")
    for cond, name, detail in checks:
        check(cond, name, detail)
    REPORT.append({
        "label":       label,
        "description": description,
        "request":     request,
        "response":    response,
    })


# ============================================================
# SCENARIO 1 — Source == Target (single-file path)
# ============================================================
def scenario_01() -> None:
    bp = _bp(
        nodes=[_node("memory:WB1ACCTC", access_identity="CE1CRA:35")],
        edges=[_edge("memory:WB1ACCTC", "memory:WB1ACCTC",
                     access_identity="CE1CRA:35", symbolic_identity="WB1WB:WB1ACCTC",
                     dsect="WB1WB", field_offset=35)],
    )
    req = dict(variable="WB1ACCTC", source_file="xh80", target_file="xh80")
    resp = _simulate("WB1ACCTC", "xh80", "xh80", {}, {"xh80": bp})
    _run("SC-01", "source == target → single-hop identity chain", req, resp, [
        (resp["total_paths_found"] == 1,
         "SC-01a: exactly 1 path found", f"got {resp['total_paths_found']}"),
        (resp["resolved_count"] == 1,
         "SC-01b: chain is resolved", f"got {resp['resolved_count']}"),
        (len(resp["chains"][0]["hops"]) == 1,
         "SC-01c: single hop in chain", f"got {len(resp['chains'][0]['hops'])}"),
        (resp["chains"][0]["hops"][0]["strategy"] == "origin",
         "SC-01d: hop strategy is 'origin'",
         f"got {resp['chains'][0]['hops'][0]['strategy']!r}"),
        (resp["canonical_identity"]["access_identity"] == "CE1CRA:35",
         "SC-01e: canonical_identity shows access_identity",
         f"got {resp['canonical_identity']}"),
        (resp["chains"][0]["target_variable"] == "WB1ACCTC",
         "SC-01f: target_variable is WB1ACCTC",
         f"got {resp['chains'][0].get('target_variable')!r}"),
    ])


# ============================================================
# SCENARIO 2 — Direct 2-hop via Access Identity Match (Strategy 2)
# ============================================================
def scenario_02() -> None:
    bp_src = _bp(
        nodes=[_node("memory:WB1ACCTC")],
        edges=[_edge("memory:WB1ACCTC", "memory:WB1ACCTC",
                     access_identity="CE1CRA:35", dsect="WB1WB", field_offset=35)],
    )
    bp_tgt = _bp(
        nodes=[_node("memory:WB1ACCTC")],
        edges=[_edge("memory:WB1ACCTC", "memory:WB1ACCTC",
                     access_identity="CE1CRA:35", dsect="WB1WB", field_offset=35)],
    )
    fwd = _fwd([("xh80", "xh87")])
    req = dict(variable="WB1ACCTC", source_file="xh80", target_file="xh87")
    resp = _simulate("WB1ACCTC", "xh80", "xh87", fwd, {"xh80": bp_src, "xh87": bp_tgt})
    chain = resp["chains"][0] if resp["chains"] else {}
    hops = chain.get("hops", [])
    _run("SC-02", "Direct 2-hop: Access Identity Match (Strategy 2)", req, resp, [
        (resp["total_paths_found"] == 1, "SC-02a: 1 path found", str(resp["total_paths_found"])),
        (resp["resolved_count"] == 1, "SC-02b: resolved", str(resp["resolved_count"])),
        (len(hops) == 2, "SC-02c: 2 hops", str(len(hops))),
        (hops[0]["strategy"] == "origin", "SC-02d: hop[0] is origin", hops[0].get("strategy", "")),
        ("Access Identity Match" in hops[1]["strategy"],
         "SC-02e: hop[1] uses Access Identity Match",
         f"got {hops[1].get('strategy')!r}"),
        (chain.get("target_variable") == "WB1ACCTC",
         "SC-02f: target_variable=WB1ACCTC", str(chain.get("target_variable"))),
    ])


# ============================================================
# SCENARIO 3 — Symbolic Identity Match (Strategy 2.5)
# ============================================================
def scenario_03() -> None:
    bp_src = _bp(
        nodes=[_node("memory:LG1OSI")],
        edges=[_edge("memory:LG1OSI", "memory:LG1OSI",
                     symbolic_identity="LG1G1:LG1OSI", dsect="LG1G1", field_offset=28)],
    )
    bp_tgt = _bp(
        nodes=[_node("memory:LG1OSI")],
        edges=[_edge("memory:LG1OSI", "memory:LG1OSI",
                     symbolic_identity="LG1G1:LG1OSI", dsect="LG1G1", field_offset=28)],
    )
    fwd = _fwd([("da76", "xh71")])
    req = dict(variable="LG1OSI", source_file="da76", target_file="xh71")
    resp = _simulate("LG1OSI", "da76", "xh71", fwd, {"da76": bp_src, "xh71": bp_tgt})
    chain = resp["chains"][0] if resp["chains"] else {}
    hops = chain.get("hops", [])
    _run("SC-03", "Symbolic Identity Match (Strategy 2.5 — DSECT:FIELD)", req, resp, [
        (resp["resolved_count"] == 1, "SC-03a: resolved", str(resp["resolved_count"])),
        ("Symbolic Identity Match" in (hops[1].get("strategy") if len(hops) > 1 else ""),
         "SC-03b: hop[1] uses Symbolic Identity Match",
         f"got {hops[1].get('strategy') if len(hops) > 1 else 'no hop'}"),
        (resp["canonical_identity"]["symbolic_identity"] == "LG1G1:LG1OSI",
         "SC-03c: canonical symbolic_identity is LG1G1:LG1OSI",
         str(resp["canonical_identity"])),
    ])


# ============================================================
# SCENARIO 4 — DSECT + Offset match with variable rename (Strategy 5)
# ============================================================
def scenario_04() -> None:
    bp_src = _bp(
        nodes=[_node("memory:ORIGVAR", dsect="MYST", byte_offset=42)],
        edges=[_edge("memory:ORIGVAR", "memory:ORIGVAR",
                     dsect="MYST", field_offset=42)],
    )
    bp_tgt = _bp(
        nodes=[_node("memory:ALIASVAR", dsect="MYST", byte_offset=42)],
        edges=[_edge("memory:ALIASVAR", "memory:ALIASVAR",
                     dsect="MYST", field_offset=42)],
    )
    fwd = _fwd([("fA", "fB")])
    req = dict(variable="ORIGVAR", source_file="fA", target_file="fB")
    resp = _simulate("ORIGVAR", "fA", "fB", fwd, {"fA": bp_src, "fB": bp_tgt})
    chain = resp["chains"][0] if resp["chains"] else {}
    hops = chain.get("hops", [])
    _run("SC-04", "Variable rename via DSECT+Offset (Strategy 5): ORIGVAR → ALIASVAR", req, resp, [
        (resp["resolved_count"] == 1, "SC-04a: resolved despite name change", str(resp["resolved_count"])),
        ("DSECT" in (hops[1].get("strategy") if len(hops) > 1 else ""),
         "SC-04b: hop[1] uses DSECT+Offset",
         f"got {hops[1].get('strategy') if len(hops) > 1 else 'no hop'}"),
        (chain.get("target_variable") == "ALIASVAR",
         "SC-04c: target_variable is the renamed ALIASVAR",
         f"got {chain.get('target_variable')!r}"),
    ])


# ============================================================
# SCENARIO 5 — Direct Name Match, no identity (Strategy 4)
# ============================================================
def scenario_05() -> None:
    bp_src = _bp(nodes=[_node("memory:LOCALVAR")],
                 edges=[_edge("memory:LOCALVAR", "memory:LOCALVAR")])
    bp_tgt = _bp(nodes=[_node("memory:LOCALVAR")],
                 edges=[_edge("memory:LOCALVAR", "memory:LOCALVAR")])
    fwd = _fwd([("s", "t")])
    req = dict(variable="LOCALVAR", source_file="s", target_file="t")
    resp = _simulate("LOCALVAR", "s", "t", fwd, {"s": bp_src, "t": bp_tgt})
    chain = resp["chains"][0] if resp["chains"] else {}
    hops = chain.get("hops", [])
    _run("SC-05", "Direct Name Match with no identity (Strategy 4)", req, resp, [
        (resp["resolved_count"] == 1, "SC-05a: resolved", str(resp["resolved_count"])),
        ("Direct Name Match" in (hops[1].get("strategy") if len(hops) > 1 else ""),
         "SC-05b: strategy is Direct Name Match",
         f"got {hops[1].get('strategy') if len(hops) > 1 else 'no hop'}"),
        (resp["canonical_identity"]["access_identity"] is None,
         "SC-05c: no access_identity on canonical",
         str(resp["canonical_identity"])),
    ])


# ============================================================
# SCENARIO 6 — Global Alias match (Strategy 6)
# ============================================================
def scenario_06() -> None:
    bp_src = _bp(
        nodes=[_node("memory:VARA")],
        edges=[_edge("memory:VARA", "memory:VARA")],
        global_edges=[{"source": "memory:VARA", "target": "memory:VARB",
                       "relation": "alias", "file": "fA", "line": 10}],
    )
    bp_tgt = _bp(
        nodes=[_node("memory:VARB")],
        edges=[_edge("memory:VARB", "memory:VARB")],
    )
    fwd = _fwd([("fA", "fB")])
    req = dict(variable="VARA", source_file="fA", target_file="fB")
    resp = _simulate("VARA", "fA", "fB", fwd, {"fA": bp_src, "fB": bp_tgt})
    chain = resp["chains"][0] if resp["chains"] else {}
    hops = chain.get("hops", [])
    _run("SC-06", "Global Alias cross-file bridge (Strategy 6)", req, resp, [
        (resp["resolved_count"] == 1, "SC-06a: resolved via global alias", str(resp["resolved_count"])),
        ("Global" in (hops[1].get("strategy") if len(hops) > 1 else ""),
         "SC-06b: strategy contains 'Global'",
         f"got {hops[1].get('strategy') if len(hops) > 1 else 'no hop'}"),
        (chain.get("target_variable") == "VARB",
         "SC-06c: target_variable is VARB (aliased name)",
         f"got {chain.get('target_variable')!r}"),
    ])


# ============================================================
# SCENARIO 7 — 3-hop chain with identity stable throughout
# ============================================================
def scenario_07() -> None:
    def _bp_with_ai(name: str) -> Dict[str, Any]:
        return _bp(
            nodes=[_node(f"memory:{name}")],
            edges=[_edge(f"memory:{name}", f"memory:{name}",
                         access_identity="CE1CRA:35",
                         symbolic_identity="WB1WB:WB1ACCTC",
                         dsect="WB1WB", field_offset=35)],
        )
    blueprints = {s: _bp_with_ai("WB1ACCTC") for s in ("xh80", "xh71", "xh87")}
    fwd = _fwd([("xh80", "xh71"), ("xh71", "xh87")])
    req = dict(variable="WB1ACCTC", source_file="xh80", target_file="xh87")
    resp = _simulate("WB1ACCTC", "xh80", "xh87", fwd, blueprints)
    chain = resp["chains"][0] if resp["chains"] else {}
    hops = chain.get("hops", [])
    _run("SC-07", "3-hop chain: xh80 → xh71 → xh87 (access_identity stable)", req, resp, [
        (resp["total_paths_found"] == 1, "SC-07a: 1 path", str(resp["total_paths_found"])),
        (resp["resolved_count"] == 1, "SC-07b: resolved", str(resp["resolved_count"])),
        (len(hops) == 3, "SC-07c: 3 hops", str(len(hops))),
        (chain.get("path") == ["xh80", "xh71", "xh87"],
         "SC-07d: path is xh80→xh71→xh87", str(chain.get("path"))),
        (all(h["variable"] == "WB1ACCTC" for h in hops),
         "SC-07e: variable name unchanged at all hops",
         str([h["variable"] for h in hops])),
    ])


# ============================================================
# SCENARIO 8 — Multiple parallel paths: one resolved, one fails
#
# Key: variable has NO identity (name-only).  When the trail hits
# mid_bad (which doesn't have MYVAR), has_identity=False and the
# chain fails immediately at mid_bad (not carried forward).
# mid_good has MYVAR → Direct Name Match → chain resolves.
# ============================================================
def scenario_08() -> None:
    # No-identity blueprints — name-only matching
    def _bp_plain(name: str) -> Dict[str, Any]:
        return _bp(
            nodes=[_node(f"memory:{name}")],
            edges=[_edge(f"memory:{name}", f"memory:{name}")],  # no identity fields
        )
    bp_nope = _bp(nodes=[_node("memory:UNRELATED")],
                  edges=[_edge("memory:UNRELATED", "memory:UNRELATED")])
    blueprints = {
        "src":      _bp_plain("MYVAR"),
        "mid_good": _bp_plain("MYVAR"),    # path 1 — Direct Name Match at mid_good → resolves
        "mid_bad":  bp_nope,               # path 2 — no match, no identity → trail cold → fails
        "tgt":      _bp_plain("MYVAR"),
    }
    fwd = _fwd([("src", "mid_good"), ("mid_good", "tgt"),
                ("src", "mid_bad"),  ("mid_bad",  "tgt")])
    req = dict(variable="MYVAR", source_file="src", target_file="tgt")
    resp = _simulate("MYVAR", "src", "tgt", fwd, blueprints)
    _run("SC-08", "Two parallel paths (no-identity var): path1 resolves, path2 fails at mid_bad", req, resp, [
        (resp["total_paths_found"] == 2, "SC-08a: 2 paths found", str(resp["total_paths_found"])),
        (resp["resolved_count"] == 1, "SC-08b: exactly 1 resolved chain", str(resp["resolved_count"])),
        (len(resp["unresolved_chains"]) == 1, "SC-08c: exactly 1 unresolved chain",
         str(len(resp["unresolved_chains"]))),
        (resp["chains"][0]["path"] == ["src", "mid_good", "tgt"],
         "SC-08d: resolved chain goes through mid_good",
         str(resp["chains"][0]["path"])),
        (resp["unresolved_chains"][0].get("failure_at") == "mid_bad",
         "SC-08e: failure_at=mid_bad on unresolved chain",
         str(resp["unresolved_chains"][0].get("failure_at"))),
    ])


# ============================================================
# SCENARIO 9 — Both parallel paths resolved (diamond topology)
# ============================================================
def scenario_09() -> None:
    def _bp_ai() -> Dict[str, Any]:
        return _bp(
            nodes=[_node("memory:WB1ACCTC")],
            edges=[_edge("memory:WB1ACCTC", "memory:WB1ACCTC",
                         access_identity="CE1CRA:35", dsect="WB1WB", field_offset=35)],
        )
    blueprints = {s: _bp_ai() for s in ("src", "branch_a", "branch_b", "tgt")}
    fwd = _fwd([("src", "branch_a"), ("branch_a", "tgt"),
                ("src", "branch_b"), ("branch_b", "tgt")])
    req = dict(variable="WB1ACCTC", source_file="src", target_file="tgt")
    resp = _simulate("WB1ACCTC", "src", "tgt", fwd, blueprints)
    _run("SC-09", "Diamond topology: both branches resolve (2 resolved chains)", req, resp, [
        (resp["total_paths_found"] == 2, "SC-09a: 2 paths found", str(resp["total_paths_found"])),
        (resp["resolved_count"] == 2, "SC-09b: both chains resolved", str(resp["resolved_count"])),
        (len(resp["unresolved_chains"]) == 0, "SC-09c: no unresolved chains",
         str(len(resp["unresolved_chains"]))),
        ({tuple(c["path"]) for c in resp["chains"]} ==
         {("src","branch_a","tgt"), ("src","branch_b","tgt")},
         "SC-09d: both paths present in chains",
         str([c["path"] for c in resp["chains"]])),
    ])


# ============================================================
# SCENARIO 10 — Bridge file: variable absent in intermediate, carried forward
# ============================================================
def scenario_10() -> None:
    def _bp_ai() -> Dict[str, Any]:
        return _bp(
            nodes=[_node("memory:WB1ACCTC")],
            edges=[_edge("memory:WB1ACCTC", "memory:WB1ACCTC",
                         access_identity="CE1CRA:35", dsect="WB1WB", field_offset=35)],
        )
    # bridge_file has UNRELATED variable — variable not found → no_match_carried
    bp_bridge = _bp(nodes=[_node("memory:BRIDGE_LOCAL")],
                    edges=[_edge("memory:BRIDGE_LOCAL", "memory:BRIDGE_LOCAL")])
    blueprints = {
        "src": _bp_ai(),
        "bridge_file": bp_bridge,
        "tgt": _bp_ai(),
    }
    fwd = _fwd([("src", "bridge_file"), ("bridge_file", "tgt")])
    req = dict(variable="WB1ACCTC", source_file="src", target_file="tgt")
    resp = _simulate("WB1ACCTC", "src", "tgt", fwd, blueprints)
    chain = resp["chains"][0] if resp["chains"] else {}
    hops = chain.get("hops", [])
    _run("SC-10", "Bridge file: variable absent in intermediate, carried by access_identity", req, resp, [
        (resp["resolved_count"] == 1, "SC-10a: chain resolves despite bridge file",
         str(resp["resolved_count"])),
        (len(hops) == 3, "SC-10b: 3 hops recorded", str(len(hops))),
        (hops[1]["strategy"] == "no_match_carried",
         "SC-10c: bridge hop strategy is 'no_match_carried'",
         f"got {hops[1].get('strategy')!r}"),
        (hops[1]["variable"] == "WB1ACCTC",
         "SC-10d: carried variable name unchanged at bridge hop",
         f"got {hops[1].get('variable')!r}"),
    ])


# ============================================================
# SCENARIO 11 — Missing blueprint for intermediate file
# ============================================================
def scenario_11() -> None:
    def _bp_ai() -> Dict[str, Any]:
        return _bp(
            nodes=[_node("memory:WB1ACCTC")],
            edges=[_edge("memory:WB1ACCTC", "memory:WB1ACCTC",
                         access_identity="CE1CRA:35", dsect="WB1WB", field_offset=35)],
        )
    blueprints = {"src": _bp_ai(), "MISSING": None, "tgt": _bp_ai()}
    fwd = _fwd([("src", "MISSING"), ("MISSING", "tgt")])
    req = dict(variable="WB1ACCTC", source_file="src", target_file="tgt")
    resp = _simulate("WB1ACCTC", "src", "tgt", fwd, blueprints)
    chain = resp["chains"][0] if resp["chains"] else {}
    hops = chain.get("hops", [])
    _run("SC-11", "Missing blueprint for intermediate: variable carried, chain still resolves", req, resp, [
        (resp["resolved_count"] == 1, "SC-11a: chain resolves despite missing blueprint",
         str(resp["resolved_count"])),
        (any("blueprint_missing_carried" in h.get("strategy", "") for h in hops),
         "SC-11b: blueprint_missing_carried strategy recorded for missing file",
         str([h.get("strategy") for h in hops])),
        (any("MISSING" in w for w in resp["warnings"]),
         "SC-11c: warning issued for missing blueprint",
         str(resp["warnings"])),
    ])


# ============================================================
# SCENARIO 12 — No call-graph path exists
# ============================================================
def scenario_12() -> None:
    bp = _bp(nodes=[_node("memory:MYVAR")],
             edges=[_edge("memory:MYVAR", "memory:MYVAR")])
    fwd = _fwd([("A", "B"), ("C", "D")])  # src and tgt in disconnected subgraphs
    req = dict(variable="MYVAR", source_file="A", target_file="D")
    resp = _simulate("MYVAR", "A", "D", fwd, {"A": bp, "D": bp})
    _run("SC-12", "No call-graph path from source to target", req, resp, [
        (resp["total_paths_found"] == 0, "SC-12a: 0 paths found", str(resp["total_paths_found"])),
        (resp["resolved_count"] == 0, "SC-12b: 0 resolved", str(resp["resolved_count"])),
        (len(resp["chains"]) == 0, "SC-12c: empty chains list", str(len(resp["chains"]))),
        (any("No directed call-graph path" in w for w in resp["warnings"]),
         "SC-12d: warning about no path present",
         str(resp["warnings"])),
    ])


# ============================================================
# SCENARIO 13 — Variable not in source blueprint
# ============================================================
def scenario_13() -> None:
    bp_src = _bp(nodes=[_node("memory:DIFFERENT")],
                 edges=[_edge("memory:DIFFERENT", "memory:DIFFERENT")])
    bp_tgt = _bp(nodes=[_node("memory:MYVAR")],
                 edges=[_edge("memory:MYVAR", "memory:MYVAR")])
    fwd = _fwd([("src", "tgt")])
    req = dict(variable="MYVAR", source_file="src", target_file="tgt")
    resp = _simulate("MYVAR", "src", "tgt", fwd, {"src": bp_src, "tgt": bp_tgt})
    # With no identity the chain may still resolve via Direct Name Match in tgt
    chain_0 = resp["chains"][0] if resp["chains"] else (resp["unresolved_chains"][0] if resp["unresolved_chains"] else {})
    _run("SC-13", "Variable not in source blueprint (origin has DIFFERENT)", req, resp, [
        (resp["total_paths_found"] == 1, "SC-13a: 1 path in graph", str(resp["total_paths_found"])),
        # canonical_identity should have all None fields (variable not found in src)
        (resp["canonical_identity"]["access_identity"] is None,
         "SC-13b: no access_identity from source",
         str(resp["canonical_identity"])),
    ])


# ============================================================
# SCENARIO 14 — All paths unresolved
#
# Variable has NO identity (name-only).  The single path src→tgt
# goes through a direct edge.  tgt has COMPLETELY_DIFFERENT only.
# Fallback also fails (leaf "MYVAR" absent) → failure_at=tgt.
# ============================================================
def scenario_14() -> None:
    bp_src = _bp(
        nodes=[_node("memory:MYVAR")],
        edges=[_edge("memory:MYVAR", "memory:MYVAR")],   # no identity
    )
    bp_tgt = _bp(nodes=[_node("memory:COMPLETELY_DIFFERENT")],
                 edges=[_edge("memory:COMPLETELY_DIFFERENT", "memory:COMPLETELY_DIFFERENT")])
    fwd = _fwd([("src", "tgt")])
    blueprints = {"src": bp_src, "tgt": bp_tgt}
    req = dict(variable="MYVAR", source_file="src", target_file="tgt")
    resp = _simulate("MYVAR", "src", "tgt", fwd, blueprints)
    _run("SC-14", "All paths unresolved: no-identity var, target has completely different variable", req, resp, [
        (resp["resolved_count"] == 0, "SC-14a: 0 resolved chains", str(resp["resolved_count"])),
        (len(resp["unresolved_chains"]) == 1, "SC-14b: 1 unresolved chain",
         str(len(resp["unresolved_chains"]))),
        (resp["unresolved_chains"][0].get("failure_at") == "tgt",
         "SC-14c: failure_at=tgt",
         str(resp["unresolved_chains"][0].get("failure_at"))),
    ])


# ============================================================
# SCENARIO 15 — Variable rename at every hop (3-file chain)
# ============================================================
def scenario_15() -> None:
    # Each file uses a different variable name but same DSECT+Offset
    def _bp_do(name: str) -> Dict[str, Any]:
        return _bp(
            nodes=[_node(f"memory:{name}", dsect="COMM", byte_offset=10)],
            edges=[_edge(f"memory:{name}", f"memory:{name}",
                         dsect="COMM", field_offset=10)],
        )
    blueprints = {
        "f0": _bp_do("ALPHA"),
        "f1": _bp_do("BETA"),
        "f2": _bp_do("GAMMA"),
    }
    fwd = _fwd([("f0", "f1"), ("f1", "f2")])
    req = dict(variable="ALPHA", source_file="f0", target_file="f2")
    resp = _simulate("ALPHA", "f0", "f2", fwd, blueprints)
    chain = resp["chains"][0] if resp["chains"] else {}
    hops = chain.get("hops", [])
    _run("SC-15", "Variable renamed at every hop: ALPHA→BETA→GAMMA (same DSECT+Offset)", req, resp, [
        (resp["resolved_count"] == 1, "SC-15a: resolved", str(resp["resolved_count"])),
        (len(hops) == 3, "SC-15b: 3 hops", str(len(hops))),
        (hops[0]["variable"] == "ALPHA", "SC-15c: hop[0] variable=ALPHA", hops[0].get("variable", "")),
        (hops[1]["variable"] == "BETA",  "SC-15d: hop[1] variable=BETA",  hops[1].get("variable", "") if len(hops)>1 else ""),
        (hops[2]["variable"] == "GAMMA", "SC-15e: hop[2] variable=GAMMA", hops[2].get("variable", "") if len(hops)>2 else ""),
        (chain.get("target_variable") == "GAMMA",
         "SC-15f: target_variable is GAMMA", str(chain.get("target_variable"))),
    ])


# ============================================================
# SCENARIO 16 — Identity acquired mid-chain (starts name-only)
# ============================================================
def scenario_16() -> None:
    # f0: MYVAR has no identity
    bp_f0 = _bp(nodes=[_node("memory:MYVAR")],
                edges=[_edge("memory:MYVAR", "memory:MYVAR")])
    # f1: MYVAR acquires access_identity
    bp_f1 = _bp(
        nodes=[_node("memory:MYVAR")],
        edges=[_edge("memory:MYVAR", "memory:MYVAR",
                     access_identity="CE1CRA:99", dsect="MYDS", field_offset=20)],
    )
    # f2: same access_identity under a new name NEWVAR
    bp_f2 = _bp(
        nodes=[_node("memory:NEWVAR")],
        edges=[_edge("memory:NEWVAR", "memory:NEWVAR",
                     access_identity="CE1CRA:99", dsect="MYDS", field_offset=20)],
    )
    fwd = _fwd([("f0", "f1"), ("f1", "f2")])
    req = dict(variable="MYVAR", source_file="f0", target_file="f2")
    resp = _simulate("MYVAR", "f0", "f2", fwd, {"f0": bp_f0, "f1": bp_f1, "f2": bp_f2})
    chain = resp["chains"][0] if resp["chains"] else {}
    hops = chain.get("hops", [])
    _run("SC-16", "Identity acquired mid-chain: name-only → access_id at f1 → renamed at f2", req, resp, [
        (resp["resolved_count"] == 1, "SC-16a: eventually resolved", str(resp["resolved_count"])),
        (len(hops) == 3, "SC-16b: 3 hops", str(len(hops))),
        (chain.get("target_variable") == "NEWVAR",
         "SC-16c: target_variable=NEWVAR (renamed after identity acquired)",
         str(chain.get("target_variable"))),
    ])


# ============================================================
# SCENARIO 17 — 3 parallel paths (3 branches fan-out/fan-in)
# ============================================================
def scenario_17() -> None:
    def _bp_ai() -> Dict[str, Any]:
        return _bp(
            nodes=[_node("memory:WB1SUPP")],
            edges=[_edge("memory:WB1SUPP", "memory:WB1SUPP",
                         access_identity="CE1CRA:65", dsect="WB1WB", field_offset=65)],
        )
    blueprints = {s: _bp_ai() for s in ("s", "bA", "bB", "bC", "t")}
    fwd = _fwd([("s","bA"), ("bA","t"),
                ("s","bB"), ("bB","t"),
                ("s","bC"), ("bC","t")])
    req = dict(variable="WB1SUPP", source_file="s", target_file="t")
    resp = _simulate("WB1SUPP", "s", "t", fwd, blueprints)
    _run("SC-17", "3-branch fan-out/fan-in: all 3 paths resolve", req, resp, [
        (resp["total_paths_found"] == 3, "SC-17a: 3 paths", str(resp["total_paths_found"])),
        (resp["resolved_count"] == 3, "SC-17b: all 3 resolved", str(resp["resolved_count"])),
        (len(resp["unresolved_chains"]) == 0, "SC-17c: no unresolved chains",
         str(len(resp["unresolved_chains"]))),
    ])


# ============================================================
# SCENARIO 18 — FALLBACK: DSECT-qualified node in target
# ============================================================
def scenario_18() -> None:
    # All 7 strategies fail: no identity on either side, Strategy 4 misses
    # because exact node_id "memory:MYVAR" ≠ "memory:DS1:MYVAR".
    # Without Name Fallback, the chain is unresolved — the DSECT-qualified form
    # is a different node_id and no identity fingerprint bridges the gap.
    bp_src = _bp(nodes=[_node("memory:MYVAR")],
                 edges=[_edge("memory:MYVAR", "memory:MYVAR")])
    bp_tgt = _bp(nodes=[_node("memory:DS1:MYVAR")],
                 edges=[_edge("memory:DS1:MYVAR", "memory:DS1:MYVAR")])
    fwd = _fwd([("src", "tgt")])
    req = dict(variable="MYVAR", source_file="src", target_file="tgt")
    resp = _simulate("MYVAR", "src", "tgt", fwd, {"src": bp_src, "tgt": bp_tgt})
    unresolved = resp["unresolved_chains"]
    _run("SC-18", "No identity + DSECT-qualified target → unresolved (Name Fallback removed)", req, resp, [
        (resp["resolved_count"] == 0,
         "SC-18a: 0 resolved (no identity bridge, no fallback)", str(resp["resolved_count"])),
        (len(unresolved) == 1,
         "SC-18b: 1 unresolved chain", str(len(unresolved))),
        (unresolved[0].get("failure_at") == "tgt" if unresolved else False,
         "SC-18c: failure_at=tgt",
         str(unresolved[0].get("failure_at") if unresolved else None)),
    ])


# ============================================================
# SCENARIO 19 — FALLBACK: kind mismatch (memory → parameter)
# ============================================================
def scenario_19() -> None:
    # Kind mismatch: origin is memory:MYVAR, target is parameter:MYVAR.
    # Strategy 4 compares exact node_id strings — "memory:MYVAR" ≠ "parameter:MYVAR".
    # Without Name Fallback, the variable is unresolved.
    bp_src = _bp(nodes=[_node("memory:MYVAR")],
                 edges=[_edge("memory:MYVAR", "memory:MYVAR")])
    bp_tgt = _bp(
        nodes=[{"id": "parameter:MYVAR", "name": "MYVAR", "kind": "parameter"}],
        edges=[_edge("parameter:MYVAR", "parameter:MYVAR")],
    )
    fwd = _fwd([("src", "tgt")])
    req = dict(variable="MYVAR", source_file="src", target_file="tgt")
    resp = _simulate("MYVAR", "src", "tgt", fwd, {"src": bp_src, "tgt": bp_tgt})
    unresolved = resp["unresolved_chains"]
    _run("SC-19", "Kind mismatch (memory→parameter) → unresolved (Name Fallback removed)", req, resp, [
        (resp["resolved_count"] == 0,
         "SC-19a: 0 resolved (no identity, kind mismatch)", str(resp["resolved_count"])),
        (len(unresolved) == 1,
         "SC-19b: 1 unresolved chain", str(len(unresolved))),
        (unresolved[0].get("failure_at") == "tgt" if unresolved else False,
         "SC-19c: failure_at=tgt",
         str(unresolved[0].get("failure_at") if unresolved else None)),
    ])


# ============================================================
# SCENARIO 20 — FALLBACK fires at intermediate file, chain continues
# ============================================================
def scenario_20() -> None:
    # Three-file chain with no identity on any node.
    # f0: memory:MYVAR (origin) → f1: memory:DS1:MYVAR (intermediate) → f2: memory:MYVAR
    # Without Name Fallback, Strategy 4 misses f1 (exact string mismatch),
    # and there is no identity to carry (has_identity=False) → chain fails at f1.
    bp_f0 = _bp(nodes=[_node("memory:MYVAR")],
                edges=[_edge("memory:MYVAR", "memory:MYVAR")])
    bp_f1 = _bp(nodes=[_node("memory:DS1:MYVAR")],
                edges=[_edge("memory:DS1:MYVAR", "memory:DS1:MYVAR")])
    bp_f2 = _bp(nodes=[_node("memory:MYVAR")],
                edges=[_edge("memory:MYVAR", "memory:MYVAR")])
    fwd = _fwd([("f0", "f1"), ("f1", "f2")])
    req = dict(variable="MYVAR", source_file="f0", target_file="f2")
    resp = _simulate("MYVAR", "f0", "f2", fwd, {"f0": bp_f0, "f1": bp_f1, "f2": bp_f2})
    unresolved = resp["unresolved_chains"]
    _run("SC-20", "No identity: chain fails at DSECT-qualified intermediate (Name Fallback removed)", req, resp, [
        (resp["resolved_count"] == 0, "SC-20a: 0 resolved", str(resp["resolved_count"])),
        (len(unresolved) == 1, "SC-20b: 1 unresolved chain", str(len(unresolved))),
        (unresolved[0].get("failure_at") == "f1" if unresolved else False,
         "SC-20c: failure_at=f1 (no identity to carry past mismatch)",
         str(unresolved[0].get("failure_at") if unresolved else None)),
    ])


# ============================================================
# SCENARIO 21 — FALLBACK: variable truly absent → unresolved
# ============================================================
def scenario_21() -> None:
    bp_src = _bp(nodes=[_node("memory:MYVAR")],
                 edges=[_edge("memory:MYVAR", "memory:MYVAR")])
    bp_tgt = _bp(nodes=[_node("memory:COMPLETELY_OTHER")],
                 edges=[_edge("memory:COMPLETELY_OTHER", "memory:COMPLETELY_OTHER")])
    fwd = _fwd([("src", "tgt")])
    req = dict(variable="MYVAR", source_file="src", target_file="tgt")
    resp = _simulate("MYVAR", "src", "tgt", fwd, {"src": bp_src, "tgt": bp_tgt})
    _run("SC-21", "Variable truly absent from target — unresolved", req, resp, [
        (resp["resolved_count"] == 0, "SC-21a: 0 resolved", str(resp["resolved_count"])),
        (len(resp["unresolved_chains"]) == 1, "SC-21b: 1 unresolved chain",
         str(len(resp["unresolved_chains"]))),
        (resp["unresolved_chains"][0]["failure_at"] == "tgt",
         "SC-21c: failure_at=tgt",
         str(resp["unresolved_chains"][0].get("failure_at"))),
    ])


# ============================================================
# SCENARIO 22 — Complex: 5-file chain, identity changes twice
# ============================================================
def scenario_22() -> None:
    # f0: VARA, dsect+offset only
    # f1: VARA, acquires access_identity CE1CRA:77
    # f2: VARB, same access_identity (renamed but found via access_id)
    # f3: VARB, bridge (not present — carried)
    # f4: VARB, found again
    def _bp_ao(name: str, ai: Optional[str] = None) -> Dict[str, Any]:
        fields: Dict[str, Any] = {"dsect": "STRU", "field_offset": 77}
        if ai:
            fields["access_identity"] = ai
        return _bp(
            nodes=[_node(f"memory:{name}", dsect="STRU", byte_offset=77)],
            edges=[_edge(f"memory:{name}", f"memory:{name}", **fields)],
        )
    bp_bridge = _bp(nodes=[_node("memory:UNRELATED")],
                    edges=[_edge("memory:UNRELATED", "memory:UNRELATED")])
    blueprints = {
        "f0": _bp_ao("VARA"),
        "f1": _bp_ao("VARA", ai="CE1CRA:77"),
        "f2": _bp_ao("VARB", ai="CE1CRA:77"),
        "f3": bp_bridge,
        "f4": _bp_ao("VARB", ai="CE1CRA:77"),
    }
    fwd = _fwd([("f0","f1"), ("f1","f2"), ("f2","f3"), ("f3","f4")])
    req = dict(variable="VARA", source_file="f0", target_file="f4")
    resp = _simulate("VARA", "f0", "f4", fwd, blueprints)
    chain = resp["chains"][0] if resp["chains"] else {}
    hops = chain.get("hops", [])
    _run("SC-22", "Complex 5-file: VARA→VARA+AI→VARB(renamed)→bridge→VARB", req, resp, [
        (resp["resolved_count"] == 1, "SC-22a: resolved", str(resp["resolved_count"])),
        (len(hops) == 5, "SC-22b: 5 hops", str(len(hops))),
        (hops[0]["variable"] == "VARA", "SC-22c: origin is VARA", hops[0].get("variable","")),
        (chain.get("target_variable") == "VARB",
         "SC-22d: final target_variable=VARB", str(chain.get("target_variable"))),
        # hop[3] is the bridge — should be no_match_carried (access_id exists)
        ("carried" in (hops[3].get("strategy") if len(hops) > 3 else ""),
         "SC-22e: bridge hop (f3) has 'carried' strategy",
         f"got {hops[3].get('strategy') if len(hops)>3 else 'no hop'}"),
    ])


# ============================================================
# SCENARIO 23 — max_path_length prunes long paths
# ============================================================
def scenario_23() -> None:
    def _bp_ai() -> Dict[str, Any]:
        return _bp(
            nodes=[_node("memory:WB1ACCTC")],
            edges=[_edge("memory:WB1ACCTC", "memory:WB1ACCTC",
                         access_identity="CE1CRA:35")],
        )
    bps = {f"n{i}": _bp_ai() for i in range(8)}
    # Linear chain n0→n1→…→n7 (8 nodes = 7 hops)
    fwd = _fwd([(f"n{i}", f"n{i+1}") for i in range(7)])
    req = dict(variable="WB1ACCTC", source_file="n0", target_file="n7",
               max_path_length=5)
    resp = _simulate("WB1ACCTC", "n0", "n7", fwd, bps, max_path_length=5)
    _run("SC-23", "max_path_length=5 prunes 8-node linear chain", req, resp, [
        (resp["total_paths_found"] == 0, "SC-23a: path pruned → 0 paths found",
         str(resp["total_paths_found"])),
        (any("No directed call-graph path" in w for w in resp["warnings"]),
         "SC-23b: warning issued",
         str(resp["warnings"])),
    ])


# ============================================================
# SCENARIO 24 — FALLBACK: multiple candidates, deterministic first
# ============================================================
def scenario_24() -> None:
    # Target has DS1:MYVAR and DS2:MYVAR but no identity fingerprint.
    # Without Name Fallback, Strategy 4 misses both (exact string mismatch with
    # "memory:MYVAR"), and there is no identity to carry → unresolved.
    bp_src = _bp(nodes=[_node("memory:MYVAR")],
                 edges=[_edge("memory:MYVAR", "memory:MYVAR")])
    bp_tgt = _bp(
        nodes=[
            {"id": "memory:DS2:MYVAR", "name": "MYVAR", "kind": "memory"},
            {"id": "memory:DS1:MYVAR", "name": "MYVAR", "kind": "memory"},
        ],
        edges=[
            _edge("memory:DS1:MYVAR", "memory:DS1:MYVAR"),
            _edge("memory:DS2:MYVAR", "memory:DS2:MYVAR"),
        ],
    )
    fwd = _fwd([("src", "tgt")])
    req = dict(variable="MYVAR", source_file="src", target_file="tgt")
    resp = _simulate("MYVAR", "src", "tgt", fwd, {"src": bp_src, "tgt": bp_tgt})
    unresolved = resp["unresolved_chains"]
    _run("SC-24", "No identity + multiple DSECT candidates → unresolved (Name Fallback removed)", req, resp, [
        (resp["resolved_count"] == 0, "SC-24a: 0 resolved", str(resp["resolved_count"])),
        (len(unresolved) == 1, "SC-24b: 1 unresolved chain", str(len(unresolved))),
        (unresolved[0].get("failure_at") == "tgt" if unresolved else False,
         "SC-24c: failure_at=tgt",
         str(unresolved[0].get("failure_at") if unresolved else None)),
    ])


# ============================================================
# SCENARIO 25 — Access_identity match with name change (explicit rename)
# ============================================================
def scenario_25() -> None:
    bp_src = _bp(
        nodes=[_node("memory:WB1ACCTC")],
        edges=[_edge("memory:WB1ACCTC", "memory:WB1ACCTC",
                     access_identity="CE1CRA:35")],
    )
    # Target file uses a completely different variable name for the same CE slot
    bp_tgt = _bp(
        nodes=[_node("memory:WORKACCT")],
        edges=[_edge("memory:WORKACCT", "memory:WORKACCT",
                     access_identity="CE1CRA:35")],
    )
    fwd = _fwd([("src", "tgt")])
    req = dict(variable="WB1ACCTC", source_file="src", target_file="tgt")
    resp = _simulate("WB1ACCTC", "src", "tgt", fwd, {"src": bp_src, "tgt": bp_tgt})
    chain = resp["chains"][0] if resp["chains"] else {}
    hops = chain.get("hops", [])
    _run("SC-25", "Access_identity match: WB1ACCTC (src) → WORKACCT (tgt), same CE1CRA:35 slot", req, resp, [
        (resp["resolved_count"] == 1, "SC-25a: resolved", str(resp["resolved_count"])),
        ("Access Identity Match" in (hops[1].get("strategy") if len(hops)>1 else ""),
         "SC-25b: Access Identity Match strategy used",
         f"got {hops[1].get('strategy') if len(hops)>1 else 'no hop'}"),
        (chain.get("target_variable") == "WORKACCT",
         "SC-25c: target_variable=WORKACCT (renamed in target file)",
         f"got {chain.get('target_variable')!r}"),
        (hops[0]["variable"] == "WB1ACCTC",
         "SC-25d: origin hop shows WB1ACCTC",
         f"got {hops[0].get('variable')!r}"),
    ])


# ============================================================
# Run all scenarios and write report
# ============================================================

def main() -> int:
    print("=" * 64)
    print("  Variable Chain E2E Test Suite")
    print("=" * 64)

    scenario_01()
    scenario_02()
    scenario_03()
    scenario_04()
    scenario_05()
    scenario_06()
    scenario_07()
    scenario_08()
    scenario_09()
    scenario_10()
    scenario_11()
    scenario_12()
    scenario_13()
    scenario_14()
    scenario_15()
    scenario_16()
    scenario_17()
    scenario_18()
    scenario_19()
    scenario_20()
    scenario_21()
    scenario_22()
    scenario_23()
    scenario_24()
    scenario_25()

    total = len(PASS) + len(FAIL)
    print(f"\n{'='*64}")
    print(f"  {len(PASS)} PASS / {len(FAIL)} FAIL  (total {total})")
    if FAIL:
        print("\n  Failed:")
        for name in FAIL:
            print(f"    - {name}")
    print("=" * 64)

    # Write detailed report
    out_path = Path(__file__).parent / "chain_test_report.json"
    out_path.write_text(json.dumps(
        {
            "_summary": {
                "total_scenarios": len(REPORT),
                "total_checks": total,
                "pass": len(PASS),
                "fail": len(FAIL),
                "failed_checks": FAIL,
            },
            "scenarios": REPORT,
        },
        indent=2,
    ), encoding="utf-8")
    print(f"\n  Report written → {out_path}")

    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
