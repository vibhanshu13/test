#!/usr/bin/env python3
"""Focused verification for map_connected_variables.py."""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))

from map_connected_variables import build_variable_mappings


PASS = 0
FAIL = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS   {name}" + (f"   — {detail}" if detail else ""))
    else:
        FAIL += 1
        print(f"  FAIL   {name}" + (f"   — {detail}" if detail else ""))


def _write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def test_register_handoff_mapping() -> None:
    print("\n==============================================================================")
    print("register handoff maps different variable names across files")
    print("==============================================================================")

    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        asm_dir = root / "asm"
        bp_dir = root / "bp"
        asm_dir.mkdir()
        bp_dir.mkdir()

        file_a = asm_dir / "filea.asm"
        file_b = asm_dir / "fileb.asm"
        file_a.write_text("         L R1,WK_RRC\n         ENTRC FILEB\n", encoding="utf-8")
        file_b.write_text("         ST R1,WK_RRC2\n         BR R14\n", encoding="utf-8")

        _write_json(
            bp_dir / "filea.asm.json",
            {
                "global_variable_lineage": {
                    "nodes": [],
                    "edges": [
                        {
                            "source": "memory:WK_RRC",
                            "target": "register:R1",
                            "relation": "assign",
                            "line": 10,
                            "file": str(file_a),
                            "scope": "FILEA",
                            "expression": "L R1,WK_RRC",
                        }
                    ],
                }
            },
        )
        _write_json(
            bp_dir / "fileb.asm.json",
            {
                "global_variable_lineage": {
                    "nodes": [],
                    "edges": [
                        {
                            "source": "register:R1",
                            "target": "memory:WK_RRC2",
                            "relation": "assign",
                            "line": 5,
                            "file": str(file_b),
                            "scope": "FILEB",
                            "expression": "ST R1,WK_RRC2",
                        }
                    ],
                }
            },
        )

        raw = {
            "file_a": "filea",
            "file_b": "fileb",
            "warnings": [],
            "connections": {
                "call_boundary_registers": [
                    {
                        "direction": "A_calls_B",
                        "caller": "filea",
                        "callee": "fileb",
                        "call_site": {"line": 20, "instruction": "ENTRC"},
                        "passed_registers": [
                            {
                                "register": "R1",
                                "set_by_caller": {"line": 10},
                                "consumed_by_callee": {"line": 5},
                            }
                        ],
                        "return_registers": [],
                        "caller_block_scan": {"scan_start_line": 1, "call_line": 20},
                        "callee_entry_scan": {"entry_start_line": 1, "entry_end_line": 10},
                    }
                ],
                "shared_memory_fields": [],
            },
        }

        result = build_variable_mappings("filea", "fileb", raw, bp_dir, asm_dir)
        mappings = result["register_handoff_mappings"]
        check("one register handoff mapping emitted", len(mappings) == 1, detail=str(mappings))
        if mappings:
            mapping = mappings[0]
            check("caller variable inferred from register source", mapping["from_var"] == "WK_RRC", detail=str(mapping))
            check("callee variable inferred from register sink", mapping["to_var"] == "WK_RRC2", detail=str(mapping))


def test_shared_field_mapping() -> None:
    print("\n==============================================================================")
    print("shared fields are strengthened by DSECT and CE-anchor identity")
    print("==============================================================================")

    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        asm_dir = root / "asm"
        bp_dir = root / "bp"
        asm_dir.mkdir()
        bp_dir.mkdir()
        (asm_dir / "a.asm").write_text(
            "         L     R5,CE1CR5\n"
            "         USING LG1G1,R5\n"
            "         CLI   LG1OSI,LG#C400\n",
            encoding="utf-8",
        )
        (asm_dir / "b.asm").write_text(
            "         L     R5,CE1CR5\n"
            "         USING LG1G1,R5\n"
            "         CLI   LG1OSI,LG#C400\n",
            encoding="utf-8",
        )
        _write_json(
            bp_dir / "a.asm.json",
            {
                "global_variable_lineage": {
                    "nodes": [
                        {
                            "id": "memory:LG1OSI",
                            "kind": "memory",
                            "name": "LG1OSI",
                            "metadata": {"dsect": "LG1G1"},
                        }
                    ],
                    "edges": [
                        {
                            "source": "memory:CE1CR5",
                            "target": "register:R5",
                            "relation": "assign",
                            "line": 1,
                            "file": str(asm_dir / "a.asm"),
                            "scope": "$IS$",
                            "expression": "L R5,CE1CR5",
                        },
                        {
                            "source": "memory:LG1OSI",
                            "target": "use:use@a:3",
                            "relation": "use",
                            "line": 3,
                            "file": str(asm_dir / "a.asm"),
                            "scope": "$IS$",
                            "expression": "CLI",
                        },
                    ],
                }
            },
        )
        _write_json(
            bp_dir / "b.asm.json",
            {
                "global_variable_lineage": {
                    "nodes": [
                        {
                            "id": "memory:LG1OSI",
                            "kind": "memory",
                            "name": "LG1OSI",
                            "metadata": {"dsect": "LG1G1"},
                        }
                    ],
                    "edges": [
                        {
                            "source": "memory:CE1CR5",
                            "target": "register:R5",
                            "relation": "assign",
                            "line": 1,
                            "file": str(asm_dir / "b.asm"),
                            "scope": "$IS$",
                            "expression": "L R5,CE1CR5",
                        },
                        {
                            "source": "memory:LG1OSI",
                            "target": "use:use@b:3",
                            "relation": "use",
                            "line": 3,
                            "file": str(asm_dir / "b.asm"),
                            "scope": "$IS$",
                            "expression": "CLI",
                        },
                    ],
                }
            },
        )

        raw = {
            "file_a": "a",
            "file_b": "b",
            "warnings": [],
            "connections": {
                "call_boundary_registers": [],
                "shared_memory_fields": [
                    {
                        "field": "LG1OSI",
                        "in_file_a": [{"line": 3, "scope": "$IS$"}],
                        "in_file_b": [{"line": 3, "scope": "$IS$"}],
                    }
                ],
            },
        }

        result = build_variable_mappings("a", "b", raw, bp_dir, asm_dir)
        mappings = result["shared_field_mappings"]
        check("one shared-field mapping emitted", len(mappings) == 1, detail=str(mappings))
        if mappings:
            check("shared field maps to same name", mappings[0]["from_var"] == "LG1OSI" and mappings[0]["to_var"] == "LG1OSI", detail=str(mappings[0]))
            check("same DSECT detected", mappings[0]["identity_match"]["same_dsect"] is True, detail=str(mappings[0]["identity_match"]))
            check("same CE anchor detected", mappings[0]["identity_match"]["same_anchor"] is True, detail=str(mappings[0]["identity_match"]))
            check("confidence upgraded to high", mappings[0]["confidence"] == "high", detail=str(mappings[0]))


def test_shared_field_different_anchor() -> None:
    print("\n==============================================================================")
    print("same field name but different CE anchors stays low confidence")
    print("==============================================================================")

    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        asm_dir = root / "asm"
        bp_dir = root / "bp"
        asm_dir.mkdir()
        bp_dir.mkdir()
        (asm_dir / "a.asm").write_text(
            "         L     R5,CE1CR5\n"
            "         USING LG1G1,R5\n"
            "         CLI   LG1OSI,LG#C400\n",
            encoding="utf-8",
        )
        (asm_dir / "b.asm").write_text(
            "         L     R5,CE1CR7\n"
            "         USING LG1G1,R5\n"
            "         CLI   LG1OSI,LG#C400\n",
            encoding="utf-8",
        )
        _write_json(
            bp_dir / "a.asm.json",
            {
                "global_variable_lineage": {
                    "nodes": [{"id": "memory:LG1OSI", "kind": "memory", "name": "LG1OSI", "metadata": {"dsect": "LG1G1"}}],
                    "edges": [
                        {"source": "memory:CE1CR5", "target": "register:R5", "relation": "assign", "line": 1, "file": str(asm_dir / "a.asm"), "scope": "$IS$", "expression": "L R5,CE1CR5"},
                        {"source": "memory:LG1OSI", "target": "use:use@a:3", "relation": "use", "line": 3, "file": str(asm_dir / "a.asm"), "scope": "$IS$", "expression": "CLI"},
                    ],
                }
            },
        )
        _write_json(
            bp_dir / "b.asm.json",
            {
                "global_variable_lineage": {
                    "nodes": [{"id": "memory:LG1OSI", "kind": "memory", "name": "LG1OSI", "metadata": {"dsect": "LG1G1"}}],
                    "edges": [
                        {"source": "memory:CE1CR7", "target": "register:R5", "relation": "assign", "line": 1, "file": str(asm_dir / "b.asm"), "scope": "$IS$", "expression": "L R5,CE1CR7"},
                        {"source": "memory:LG1OSI", "target": "use:use@b:3", "relation": "use", "line": 3, "file": str(asm_dir / "b.asm"), "scope": "$IS$", "expression": "CLI"},
                    ],
                }
            },
        )

        raw = {
            "file_a": "a",
            "file_b": "b",
            "warnings": [],
            "connections": {
                "call_boundary_registers": [],
                "shared_memory_fields": [
                    {
                        "field": "LG1OSI",
                        "in_file_a": [{"line": 3, "scope": "$IS$"}],
                        "in_file_b": [{"line": 3, "scope": "$IS$"}],
                    }
                ],
            },
        }

        result = build_variable_mappings("a", "b", raw, bp_dir, asm_dir)
        mappings = result["shared_field_mappings"]
        check("one shared-field mapping emitted", len(mappings) == 1, detail=str(mappings))
        if mappings:
            check("same DSECT still detected", mappings[0]["identity_match"]["same_dsect"] is True, detail=str(mappings[0]["identity_match"]))
            check("different CE anchors detected", mappings[0]["identity_match"]["same_anchor"] is False, detail=str(mappings[0]["identity_match"]))
            check("confidence stays medium without anchor match", mappings[0]["confidence"] == "medium", detail=str(mappings[0]))


def main() -> int:
    print("==============================================================================")
    print("  Connected variable map verification")
    print("==============================================================================")
    test_register_handoff_mapping()
    test_shared_field_mapping()
    test_shared_field_different_anchor()
    print("\n==============================================================================")
    print(f"  Results: {PASS} PASS / {FAIL} FAIL")
    print("==============================================================================")
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
