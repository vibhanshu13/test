#!/usr/bin/env python3
"""Phase 7 verification — glob(_name) named globals."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO_ROOT))


RESULTS: list[tuple[str, str, str]] = []


def check(label: str, cond: bool, detail: str = "") -> None:
    status = "PASS" if cond else "FAIL"
    RESULTS.append((status, label, detail))
    tail = f"   — {detail}" if detail else ""
    print(f"  {status}   {label}{tail}")


# ---------------------------------------------------------------------------
# 6.1 Synthetic extraction
# ---------------------------------------------------------------------------

def test_extraction() -> None:
    print("\n" + "=" * 78)
    print("6.1  Extraction: unit.globals_used populated in first-seen order")
    print("=" * 78)
    from passes.c_family_parser import CFamilyParser
    src = """
int f() {
  char* p = (char*) glob(_tpfcv83);
  const int x = *(int*) glob(_CSADTE);
  int y = *(int*) glob(_tpfcv83);  // duplicate — should be deduped
  return (int)*p + x + y;
}
"""
    parser = CFamilyParser(language="cpp")
    if not hasattr(parser, "_extract_glob_globals"):
        check("_extract_glob_globals method exists", False,
              detail="Phase 7 patch missing")
        return
    got = parser._extract_glob_globals(src)
    check("2 unique globals captured", len(got) == 2, detail=f"got {got}")
    check("TPFCV83 first (first-seen)",
          len(got) >= 1 and got[0] == "TPFCV83", detail=f"got {got}")
    check("CSADTE second", len(got) >= 2 and got[1] == "CSADTE",
          detail=f"got {got}")


# ---------------------------------------------------------------------------
# 6.2 Node emission
# ---------------------------------------------------------------------------

def test_node_emission() -> None:
    print("\n" + "=" * 78)
    print("6.2  Lineage graph has global:TPFCV83 and global:CSADTE nodes")
    print("=" * 78)
    from multi_file.c_family_analyzer import CFamilyAnalyzer
    src = """
int f() {
  char* p = (char*) glob(_tpfcv83);
  int x = *(int*) glob(_CSADTE);
  return x;
}
"""
    with tempfile.TemporaryDirectory() as td:
        cpp = Path(td) / "t.cpp"
        cpp.write_text(src)
        a = CFamilyAnalyzer(language="cpp", search_paths=[Path(td)])
        res = a.analyze(cpp, src)
        graph = res.analysis_context.get_metadata("variable_lineage")
        d = graph.to_dict() if hasattr(graph, "to_dict") else graph
        nodes = d.get("nodes", []) if d else []
        for nm in ("TPFCV83", "CSADTE"):
            hit = next((n for n in nodes
                        if n.get("kind") == "global" and n.get("name") == nm),
                       None)
            check(f"global:{nm} node present", hit is not None,
                  detail=f"node={hit}")


# ---------------------------------------------------------------------------
# 6.3 / 6.4 / 6.5 Stitcher
# ---------------------------------------------------------------------------

def _ctx_with_graph(graph):
    from models.analysis_context import AnalysisContext
    ctx = AnalysisContext(file_path=Path("fake.json"))
    ctx.add_metadata("variable_lineage", graph)
    return ctx


def test_stitcher_positive() -> None:
    print("\n" + "=" * 78)
    print("6.3  Stitcher: global:TPFCV83 ↔ memory:TPFCV83 alias edge")
    print("=" * 78)
    from models.variable_lineage import VariableLineageGraph
    from passes.global_lineage_stitcher import GlobalLineageStitcher
    cpp_g = VariableLineageGraph()
    cpp_g.add_definition("TPFCV83", "global",
                         file="t.cpp", line=1, expression="glob(_tpfcv83)",
                         scope="system", statement_id="G", macro_expansion_parent=None)
    asm_g = VariableLineageGraph()
    asm_g.add_definition("TPFCV83", "memory",
                         file="a.asm", line=1, expression="",
                         scope="R", statement_id="A", macro_expansion_parent=None)
    stitcher = GlobalLineageStitcher()
    stitcher.process_contexts({
        "t.cpp.json": _ctx_with_graph(cpp_g),
        "a.asm.json": _ctx_with_graph(asm_g),
    })
    gg = stitcher.global_graph
    edges = [e for e in gg.edges
             if (e.expression or "") == "global_lineage_stitch:cpp_global_to_asm"]
    check("exactly 1 cpp_global_to_asm edge",
          len(edges) == 1, detail=f"count={len(edges)}")
    if edges:
        e = edges[0]
        check("edge scope == 'system'", e.scope == "system",
              detail=f"scope={e.scope}")


def test_stitcher_negative() -> None:
    print("\n" + "=" * 78)
    print("6.4  Stitcher negative: global without ASM memory counterpart")
    print("=" * 78)
    from models.variable_lineage import VariableLineageGraph
    from passes.global_lineage_stitcher import GlobalLineageStitcher
    cpp_g = VariableLineageGraph()
    cpp_g.add_definition("ONLYINCPP", "global",
                         file="t.cpp", line=1, expression="glob(_onlyincpp)",
                         scope="system", statement_id="G", macro_expansion_parent=None)
    stitcher = GlobalLineageStitcher()
    stitcher.process_contexts({"t.cpp.json": _ctx_with_graph(cpp_g)})
    gg = stitcher.global_graph
    node = next((n for n in gg.nodes.values() if n.name == "ONLYINCPP"), None)
    check("global node still exists",
          node is not None and node.kind == "global")
    if node:
        md = node.metadata or {}
        check("alias_type stamped (documentation)",
              md.get("alias_type") == "cpp_global_to_asm",
              detail=f"md={md}")
    edges = [e for e in gg.edges
             if (e.expression or "") == "global_lineage_stitch:cpp_global_to_asm"]
    check("no alias edge when ASM memory absent",
          len(edges) == 0, detail=f"count={len(edges)}")


def test_stitcher_idempotent() -> None:
    print("\n" + "=" * 78)
    print("6.5  Stitcher idempotent across two runs")
    print("=" * 78)
    from models.variable_lineage import VariableLineageGraph
    from passes.global_lineage_stitcher import GlobalLineageStitcher
    cpp_g = VariableLineageGraph()
    cpp_g.add_definition("CSADTE", "global",
                         file="t.cpp", line=1, expression="",
                         scope="system", statement_id="G", macro_expansion_parent=None)
    asm_g = VariableLineageGraph()
    asm_g.add_definition("CSADTE", "memory",
                         file="a.asm", line=1, expression="",
                         scope="R", statement_id="A", macro_expansion_parent=None)
    stitcher = GlobalLineageStitcher()
    contexts = {"t.cpp.json": _ctx_with_graph(cpp_g),
                "a.asm.json": _ctx_with_graph(asm_g)}
    stitcher.process_contexts(contexts)
    first = sum(1 for e in stitcher.global_graph.edges
                if (e.expression or "") == "global_lineage_stitch:cpp_global_to_asm")
    stitcher.process_contexts(contexts)
    second = sum(1 for e in stitcher.global_graph.edges
                 if (e.expression or "") == "global_lineage_stitch:cpp_global_to_asm")
    check("idempotent global alias edge count",
          first == second, detail=f"first={first} second={second}")


def main() -> int:
    tests = [test_extraction, test_node_emission,
             test_stitcher_positive, test_stitcher_negative,
             test_stitcher_idempotent]
    for t in tests:
        try:
            t()
        except Exception as exc:
            RESULTS.append(("FAIL", t.__name__, f"raised {type(exc).__name__}: {exc}"))
            print(f"  FAIL   {t.__name__} raised {exc!r}")
    fails = [r for r in RESULTS if r[0] == "FAIL"]
    print("\n" + "=" * 78)
    if fails:
        print(f">>> PHASE 7: {len(fails)}/{len(RESULTS)} FAILED.")
        for _, lbl, detail in fails:
            print(f"    - {lbl}  {detail}")
        return 1
    print(f">>> PHASE 7: ALL {len(RESULTS)} CHECKS PASSED.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
