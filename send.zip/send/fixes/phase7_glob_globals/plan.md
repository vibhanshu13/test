# Phase 7 — `glob(_name)` Named Global Variables

**Status:** NOT STARTED.
**Source plan:** `docs/plans/2026-04-23-cpp-variable-lineage-strategy 1.md` §3.6, §6.7.
**Depends on:** TPF_regs bridge (commit `73898fa`).

---

## 1. Problem

z/TPF exposes process-wide constants through the `glob()` runtime call:

```cpp
if (*((char*) glob(_tpfcv83)) & 0x80)          // system TPF flags
memcpy(... , (char*)glob(_csadte), 6);          // system date
const CasVision1& vis = *(CasVision1*) glob(_casvis1);  // app config
```

The argument `_tpfcv83` / `_csadte` / `_casvis1` names an ASM global
(`TPFCV83`, `CSADTE`, `CASVIS1` — uppercased, underscore stripped).
Currently the parser captures `glob` as a plain function call; the
named global identity is buried in the argument and invisible to
lineage traversal.

---

## 2. Goal

Extract the global name from every `glob(_name)` call, emit a lineage
node `kind="global"` named after the uppercased symbol, and stitch
that global to its ASM memory counterpart when present.

After Phase 7:

- Each blueprint gains a top-level `globals_used: ["TPFCV83", "CSADTE", …]`.
- A lineage node `global:TPFCV83` exists whenever the file touches
  `glob(_tpfcv83)`, with `scope="system"`.
- The global stitcher creates `cpp_global_to_asm` alias edges when the
  ASM side exposes a memory node of the same name.

---

## 3. Scope

### In scope
- `glob(_name)` and `glob(_NAME)` — case-insensitive on the underscore
  prefix. Argument is a single identifier.
- Writes (`*(T*)glob(_x) = v;`) AND reads (`x = *(T*)glob(_x);`) — both
  produce usage edges; only writes produce assign edges.
- Transitively via `#include`d headers: if a header `#define`-maps
  something to `glob(_x)`, we still catch it at the call site.

### Out of scope
- `glob(someExpr)` with non-identifier arg — too ambiguous; skipped.
- Preprocessor `#define GLOBAL glob(_x)` one-liners — treat the expanded
  call the same way; no special handling.
- The 0x80 bit-mask semantics at `if (*((char*) glob(_tpfcv83)) & 0x80)`
  — Phase 5b already captures the comparison; we only add the global
  node.

---

## 4. Files touched

| File | Change |
|---|---|
| `models/c_family.py` | Add `globals_used: List[str]` to `CTranslationUnit`. |
| `passes/c_family_parser.py` | `_extract_glob_globals()` — regex on cleaned text; called from `parse()`. |
| `passes/variable_lineage_builder.py` | Emit a `global:<NAME>` node per unique global seen in the unit. |
| `json_emitter.py` | Emit `globals_used` section on every blueprint. |
| `passes/global_lineage_stitcher.py` | `_stitch_global_bindings` — same idempotent pattern as Phase 6: annotate + alias edge when the ASM memory node exists. |

---

## 5. Implementation sketch

### 5.1 Parser

```python
_GLOB_CALL_RE = re.compile(r"\bglob\s*\(\s*_([A-Za-z_]\w*)\s*\)", re.IGNORECASE)

def _extract_glob_globals(self, text: str) -> List[str]:
    cleaned = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    cleaned = re.sub(r"//[^\n]*", "", cleaned)
    out: List[str] = []
    for m in self._GLOB_CALL_RE.finditer(cleaned):
        name = m.group(1).upper()
        if name not in out:
            out.append(name)
    return out
```

### 5.2 Lineage builder

At the end of `process_c_family`, for each name in `unit.globals_used`,
create a `global:<NAME>` node:

```python
for gname in getattr(unit, "globals_used", []) or []:
    graph.add_definition(gname, "global", file, 0, f"glob(_{gname.lower()})",
                         "system", f"GLOBAL_{gname}", None)
```

Intentionally no per-call edges for this MVP — just the node. A follow-up
could add use/assign edges tied to each call site; the plan notes this as
the minimum "see the global in the graph" deliverable.

### 5.3 Stitcher

```python
def _stitch_global_bindings(self):
    existing = {(e.source, e.target) for e in self.global_graph.edges if e.relation == "alias"}
    for node in list(self.global_graph.nodes.values()):
        if node.kind != "global":
            continue
        asm_id = self.global_graph.get_node_id(node.name, "memory")
        self.global_graph.annotate_node(node.name, "global",
                                        alias_type="cpp_global_to_asm")
        if not asm_id:
            continue
        key = (node.node_id, asm_id)
        if key in existing:
            continue
        existing.add(key)
        self.global_graph.add_alias(
            node.name, "global", node.name, "memory",
            file="(glob_bindings)", line=0,
            expression="global_lineage_stitch:cpp_global_to_asm",
            scope="system",
            statement_id="GLOBAL_STITCH_GLOB",
            macro_expansion_parent=None,
        )
```

---

## 6. Verification

`fixes/phase7_glob_globals/test_glob_globals.py`.

### 6.1 Synthetic extraction
```cpp
int f() {
  char* p = (char*) glob(_tpfcv83);
  const int x = *(int*) glob(_CSADTE);
  return (int)*p + x;
}
```
Assert `unit.globals_used == ["TPFCV83", "CSADTE"]` (order = first-seen,
uppercased).

### 6.2 Node emission
Same source → lineage graph has `global:TPFCV83` and `global:CSADTE`
with `kind="global"`.

### 6.3 Stitcher positive
Synthetic cpp with `global:TPFCV83`, synthetic asm with
`memory:TPFCV83`. After stitching, alias edge exists with
`expression="global_lineage_stitch:cpp_global_to_asm"`.

### 6.4 Stitcher negative
Same cpp but no ASM memory node → annotation only, no edge.

### 6.5 Idempotence — two runs, same count.

### 6.6 Regression — phases 1–6 + 5b + TPF_regs all PASS.

---

## 7. Resume

1. Read plan.
2. Baseline test — expect FAIL on extraction + stitcher.
3. Patch parser → model → lineage builder → emitter → stitcher.
4. Rerun — PASS.
5. Commit, update fixes/README.md.
