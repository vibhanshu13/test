# Phase 2 — Comment-Based Field Mapping Extraction

**Status:** NOT STARTED (awaiting approval to edit).
**Source plan:** `docs/plans/2026-04-23-cpp-variable-lineage-strategy 1.md` §4, §6.2.
**Depends on:** Phase 1 (merged as commit `2d2eab1`).

---

## The problem in one picture

In `cc*.hpp` headers, every struct field that has an ASM counterpart carries a trailing single-line comment naming the ASM symbol:

```cpp
// ccda7gl.hpp
struct Da7gl {
    char cmSystem;                  // WK_CMO
    char processedByDX74;           // WK_DX74
    HubglGnaHubReplyMessage reply;  // WK_REPLY
};

// cclg1g1.hpp
struct CasGLRec {
    char fmUptInd;                  // lg1upt
    OnlineSourceInd onlineSrcInd;   // lg1osi
    char accountNumber[15];         // lg1act
};
```

The ASM side declares the same layout in a DSECT:

```asm
WK_CMO    DS   CL1          CM SYSTEM INDICATOR
LG1UPT    DS   CL1          FM UPDATE INDICATOR
```

These comments are the **ground truth** that says "C++ field `X` is the same memory as ASM variable `Y`." Without them, we have no way to link a C++ struct-field write to its ASM counterpart.

**Current behavior:** `_extract_symbol_aliases()` strips all comments before processing (c_family_parser.py:1975–1976), so these annotations are discarded. The parser has no record that a mapping exists.

## What Phase 2 adds

Extract those trailing comments, produce a `Dict[str, str]` of `{"StructName.fieldName": "ASM_NAME"}`, and hang it off `CTranslationUnit.field_asm_aliases`. Phase 3 will attach the alias to lineage nodes; Phase 4 will stitch cross-language edges.

Phase 2 is purely extraction — no lineage-graph changes yet.

---

## Scope rules (non-negotiable)

Per plan §4.4:

- **Only files whose name starts with `cc`** (case-insensitive, e.g. `ccda7gl.hpp`, `cclg1g1.hpp`, `cchubgl.hpp`) are scanned. Other headers like `pipeline.hpp`, `lm1api.hpp` return an empty dict immediately.
- This gate is the single most important design constraint. Non-cc headers must not produce spurious mappings.

---

## Comment-token classification rules

The comment on a field line may contain:

| Example comment | Keep? | Why |
|---|---|---|
| `// lg1upt` | yes → `LG1UPT` | single identifier-shaped token |
| `// WK_CMO` | yes → `WK_CMO` | already uppercase, valid |
| `// lg126_updr` | yes → `LG126_UPDR` | underscore + digits ok (z/TPF convention) |
| `// WK_SW1 R001` | yes → `WK_SW1` | first token is asm name; revision markers after it ignored |
| `// lg1ptfm R003` | yes → `LG1PTFM` | same |
| `// R002` | **NO** | revision marker only — no asm name |
| `// R003` | **NO** | ditto |
| `// effective date of ia..` | **NO** | multi-word prose, not an identifier |
| `// C = card member attributes only` | **NO** | comment that describes a field's semantic, not a mapping |
| (no comment) | **NO** | no mapping exists |

Filter, applied to the first whitespace-separated token after `//`:

1. Must match `^[A-Za-z@#$_][A-Za-z0-9@#$_]*$`.
2. Length 1–16 (z/TPF symbols are typically 1–8 but we see `lg126_updr` = 10; 16 gives safety margin).
3. Must NOT match `^R\d{2,4}[A-Z]?$` (revision marker).
4. The first token is kept; any trailing tokens that look like revision markers (`R003`, `R001`) are stripped. Prose trailing the first token (4+ words) → reject the whole comment.

Output: ASM name **uppercased** (ASM is case-insensitive; source comments are sometimes lowercase like `lg1upt`).

---

## Struct-name qualification

Every captured mapping is qualified by the enclosing *named* struct:

- `struct Da7gl { ... char cmSystem; // WK_CMO }` → key `Da7gl.cmSystem`.
- `struct CasGLRec { ... char fmUptInd; // lg1upt }` → key `CasGLRec.fmUptInd`.

### Anonymous nested struct

```cpp
struct Da7gl {
    ...
    struct {
        unsigned int tmpLmtAddChg : 1;      // R003      <-- rejected
        unsigned int tmpLmtChg    : 1;      // R003      <-- rejected
    } processingIndicator1;                 // WK_SW1 R001  <-- captured
};
```

Rules:
- Fields **inside** the anonymous struct have their own trailing comments. If those comments are revision markers (the common case), they're rejected by rule 3. No special handling.
- The **outer member** (`processingIndicator1`) gets captured at the outer struct's scope → `Da7gl.processingIndicator1 → WK_SW1`.

### Typedef / forward-declaration / enum

- `enum { ... };` — skip. Enum values aren't field→asm mappings.
- `union { ... } x;` — if the union is a field of a named struct and has a trailing comment, treat like a nested anonymous struct (record the union's member name). If it's top-level, skip.
- `typedef struct ...` — supported; the name after the `}` is the typedef alias.

---

## Files touched

### 1. `models/c_family.py`
Add one field to `CTranslationUnit`:
```python
field_asm_aliases: Dict[str, str] = field(default_factory=dict)
```
Default empty. Zero risk to any existing consumer.

### 2. `passes/c_family_parser.py`
Three additions:

**(a)** A helper `_extract_field_asm_aliases(self, text: str, file_path: Path) -> Dict[str, str]` that:
1. Gates on `Path(file_path).name.lower().startswith("cc")` → else return `{}`.
2. Strips `/* ... */` block comments (preserving line numbers is not needed here; we only need text).
3. Scans for `struct NAME {` blocks with brace-balanced body extraction (handles one level of anonymous nesting).
4. For each line inside a named-struct body that ends in `;` followed by `// token ...`, extracts (field_name, asm_name) via the token rules above.
5. For each anonymous `struct { ... } member_name;  // asm_name` inside a named struct, records `NamedStruct.member_name → asm_name`.
6. Emits `{"Da7gl.cmSystem": "WK_CMO", ...}`.

**(b)** Call it from `parse()` (once per parse call, idempotent):
```python
unit.field_asm_aliases = self._extract_field_asm_aliases(text, file_path)
```

**(c)** (Future-proofing, not in Phase 2) — `multi_file/c_family_analyzer.py` will later need `_collect_include_field_aliases` to follow `#include <cchubgl.hpp>` chains. Deferred to Phase 3/4 when the stitcher needs it. Phase 2 only populates per-file aliases.

---

## Implementation approach: regex scanner, not AST

Two reasons:
1. This environment can't load `tree_sitter_languages` (Python 3.14 gap); regex works in both paths.
2. The tree-sitter C/C++ grammar discards `//` comments at the sibling level — you'd have to read them from the raw byte range anyway. A line-level scanner is simpler and no less accurate for this specific task.

Approach:

```python
STRUCT_OPEN_RE = re.compile(r'\bstruct\s+(?P<name>[A-Za-z_]\w*)?\s*\{')
STRUCT_END_RE  = re.compile(r'\}\s*(?P<name>[A-Za-z_]\w*)?\s*;')

FIELD_LINE_RE = re.compile(
    r'^\s*(?P<body>.*?)\s*;\s*//\s*(?P<comment>.*?)\s*$'
)
FIELD_NAME_RE = re.compile(
    r'(?P<name>[A-Za-z_]\w*)\s*(?:\[[^\]]*\])*\s*$'
)
ASM_TOKEN_RE = re.compile(
    r'^(?P<asm>[A-Za-z@#$_][A-Za-z0-9@#$_]{0,15})'
    r'(?:\s+R\d{2,4}[A-Z]?)*\s*$'
)
REVISION_RE = re.compile(r'^R\d{2,4}[A-Z]?$')
```

Scanner state: a stack of `(struct_name_or_None, opened_depth)` tuples. Depth tracked by counting `{` and `}` on each line (after stripping strings and block comments).

Per line:
1. If `struct NAME {` appears, push `(NAME, depth)`.
2. If bare `struct {` appears (no name), push `(None, depth)`.
3. If `} member_name;  // asm_name` appears, that's the end of an anonymous nested struct used as a field; emit `outer_named.member_name → asm_name` and pop.
4. If `};` at matching depth without a member name, pop.
5. Else if inside a named struct and line matches `FIELD_LINE_RE` with a valid `ASM_TOKEN_RE` comment, extract field name via `FIELD_NAME_RE` on `body`, emit.

This is ~80 lines of Python. No external deps.

---

## Verification (exit criteria)

Run `python3 fixes/phase2_field_asm_aliases/test_field_asm_aliases.py`.

### Synthetic tests (gate + classification rules)
- Non-`cc` filename → empty dict.
- `cc*.hpp` filename + trailing `// WK_CMO` → captured uppercase.
- `// R002` → **not** captured.
- `// WK_SW1 R001` → captured as `WK_SW1` (first token, revisions stripped).
- Anonymous nested struct with revision-marker-only children → only the outer member captured.

### Real-file tests (authoritative)
Runs against `../asm/ccda7gl.hpp` and `../asm/cclg1g1.hpp`.

Must produce at least these specific mappings:

**`ccda7gl.hpp` (struct Da7gl):**
- `Da7gl.cmSystem → WK_CMO`
- `Da7gl.processedByDX74 → WK_DX74`
- `Da7gl.noOfLimits → WK_CNT`
- `Da7gl.reply → WK_REPLY`
- `Da7gl.dateWorkArea → WK_DATE`
- `Da7gl.processingIndicator1 → WK_SW1` (anonymous nested struct)
- `Da7gl.packedAcctNbr → WK_ACCTP`

Must NOT produce any mapping whose value matches `^R\d{2,4}[A-Z]?$` (revision markers).

**`cclg1g1.hpp`:**
- `CasGLRec.typeOfMaintenance → LG1TYP`
- `CasGLRec.accountNumber → LG1ACT`
- `CasGLRec.fmUptInd → LG1UPT`
- `CasGLRec.onlineSrcInd → LG1OSI`
- `CasGLRec.transactionLimitHome → LG1TXLH`
- `HeaderRecord.batchNumber → LG1OBC`
- `TempLimitsRecord.tempTranLimitHome → LG126_TXOH`

Total mapping count: expected ≥ 30 for `ccda7gl.hpp`, ≥ 100 for `cclg1g1.hpp` (rough; exact count is whatever the scanner produces — the test asserts key specific mappings plus a lower-bound count).

### Regression check
- Phase 1 test (`fixes/phase1_memcpy_as_assignment/test_memcpy_as_assignment.py`) still passes.
- A parse of a non-`cc` file produces empty `field_asm_aliases` (old behavior preserved).
