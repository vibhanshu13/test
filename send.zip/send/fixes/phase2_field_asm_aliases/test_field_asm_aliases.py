#!/usr/bin/env python3
"""Phase 2 verification — field_asm_aliases extraction from cc*.hpp.

Usage:
    python3 fixes/phase2_field_asm_aliases/test_field_asm_aliases.py

BEFORE the patch: every synthetic check prints MISSING; real-file keys print MISSING.
AFTER the patch: every row prints PASS and the mapping count meets the threshold.

Gate on 'cc*.hpp' filename is enforced — a non-cc header must yield {}.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Dict

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))

from passes.c_family_parser import CFamilyParser  # noqa: E402


REVISION_RE = re.compile(r'^R\d{2,4}[A-Z]?$')


# --- Synthetic snippets ------------------------------------------------------

CC_SNIPPET = """\
#pragma pack(1)
struct Da7gl {
    int  registerSaveArea[10];      // R002
    char cmSystem;                  // WK_CMO
    char processedByDX74;           // WK_DX74

    struct {
        unsigned int tmpLmtAddChg : 1;      // R003
        unsigned int tmpLmtChg    : 1;      // R003
    } processingIndicator1;                 // WK_SW1 R001

    char prose;                      // some prose that is not an asm name
    char plain;
};

struct CasGLRec {
    char typeOfMaintenance;     // lg1typ
    char fmUptInd;              // lg1upt
    char onlineSrcInd;          // lg1osi
};
"""

NON_CC_SNIPPET = """\
struct ShouldBeIgnored {
    char cmSystem;                 // WK_CMO
    char processedByDX74;          // WK_DX74
};
"""


SYNTHETIC_MUST_INCLUDE = [
    ("Da7gl.cmSystem",              "WK_CMO"),
    ("Da7gl.processedByDX74",       "WK_DX74"),
    ("Da7gl.processingIndicator1",  "WK_SW1"),  # anonymous nested struct
    ("CasGLRec.typeOfMaintenance",  "LG1TYP"),
    ("CasGLRec.fmUptInd",           "LG1UPT"),
    ("CasGLRec.onlineSrcInd",       "LG1OSI"),
]

SYNTHETIC_MUST_EXCLUDE = [
    "Da7gl.registerSaveArea",   # // R002  — revision marker only
    "Da7gl.tmpLmtAddChg",       # // R003
    "Da7gl.tmpLmtChg",          # // R003
    "Da7gl.prose",              # multi-word prose
    "Da7gl.plain",              # no comment at all
]


# --- Real-file expectations --------------------------------------------------

CCDA7GL_MUST_INCLUDE = [
    ("Da7gl.cmSystem",              "WK_CMO"),
    ("Da7gl.processedByDX74",       "WK_DX74"),
    ("Da7gl.noOfLimits",            "WK_CNT"),
    ("Da7gl.reply",                 "WK_REPLY"),
    ("Da7gl.dateWorkArea",          "WK_DATE"),
    ("Da7gl.processingIndicator1",  "WK_SW1"),
    ("Da7gl.packedAcctNbr",         "WK_ACCTP"),
    ("Da7gl.hubcnt",                "WK_HUBCNT"),
    ("Da7gl.doubleWordWorkArea",    "WK_DBL"),
]
CCDA7GL_MIN_COUNT = 25

CCLG1G1_MUST_INCLUDE = [
    ("CasGLRec.typeOfMaintenance",       "LG1TYP"),
    ("CasGLRec.accountNumber",           "LG1ACT"),
    ("CasGLRec.fmUptInd",                "LG1UPT"),
    ("CasGLRec.onlineSrcInd",            "LG1OSI"),
    ("CasGLRec.transactionLimitHome",    "LG1TXLH"),
    ("HeaderRecord.batchNumber",         "LG1OBC"),
    ("TempLimitsRecord.tempTranLimitHome", "LG126_TXOH"),
    ("CycleCutRecord.cycleCutType",      "LG1CTD"),
]
CCLG1G1_MIN_COUNT = 100


# --- Helpers -----------------------------------------------------------------


def _aliases_for(text: str, filename: str) -> Dict[str, str]:
    parser = CFamilyParser(language="cpp")
    unit = parser.parse(Path(f"/tmp/{filename}"), text)
    return dict(getattr(unit, "field_asm_aliases", {}) or {})


def _check_inclusions(label: str, aliases: Dict[str, str], expected) -> int:
    failed = 0
    for key, asm in expected:
        got = aliases.get(key)
        if got == asm:
            print(f"  PASS   {label}  {key} -> {asm}")
        else:
            print(f"  MISSING {label}  {key} -> {asm} (got: {got!r})")
            failed += 1
    return failed


def _check_exclusions(label: str, aliases: Dict[str, str], excluded) -> int:
    failed = 0
    for key in excluded:
        if key not in aliases:
            print(f"  PASS   {label}  {key} correctly NOT captured")
        else:
            print(f"  WRONG  {label}  {key} should NOT be captured (got {aliases[key]!r})")
            failed += 1
    return failed


def _check_no_revision_markers(label: str, aliases: Dict[str, str]) -> int:
    bad = [k for k, v in aliases.items() if REVISION_RE.match(v)]
    if bad:
        print(f"  WRONG  {label}  revision markers captured as ASM names: {bad[:5]}")
        return 1
    print(f"  PASS   {label}  no revision markers in captured values")
    return 0


# --- Runners -----------------------------------------------------------------


def run_synthetic() -> int:
    print("=" * 78)
    print("Synthetic tests")
    print("=" * 78)

    # Gate test first.
    non_cc = _aliases_for(NON_CC_SNIPPET, "pipeline.hpp")
    if non_cc == {}:
        print("  PASS   non-cc filename gate: 'pipeline.hpp' yields {}")
        failed = 0
    else:
        print(f"  WRONG  non-cc gate leaked {len(non_cc)} mapping(s): {non_cc}")
        failed = 1

    # cc*.hpp extraction test.
    aliases = _aliases_for(CC_SNIPPET, "ccda7gl.hpp")
    print(f"  (cc snippet produced {len(aliases)} mapping(s))")
    for k in sorted(aliases):
        print(f"    {k} -> {aliases[k]}")

    failed += _check_inclusions("synth", aliases, SYNTHETIC_MUST_INCLUDE)
    failed += _check_exclusions("synth", aliases, SYNTHETIC_MUST_EXCLUDE)
    failed += _check_no_revision_markers("synth", aliases)
    return failed


def run_real_files() -> int:
    failed = 0
    for filename, must, min_count in [
        ("ccda7gl.hpp", CCDA7GL_MUST_INCLUDE, CCDA7GL_MIN_COUNT),
        ("cclg1g1.hpp", CCLG1G1_MUST_INCLUDE, CCLG1G1_MIN_COUNT),
    ]:
        target = (REPO_ROOT.parent / "asm" / filename).resolve()
        print()
        print("=" * 78)
        print(f"Real file: {target}")
        print("=" * 78)
        if not target.exists():
            print(f"  SKIP   file not found (looked at {target})")
            continue

        text = target.read_text(errors="replace")
        aliases = _aliases_for(text, filename)
        print(f"  total mappings captured: {len(aliases)}")
        for k in sorted(aliases)[:12]:
            print(f"    {k} -> {aliases[k]}")
        if len(aliases) > 12:
            print(f"    ... ({len(aliases) - 12} more)")

        # Key mappings.
        failed += _check_inclusions(filename, aliases, must)
        # No revision markers.
        failed += _check_no_revision_markers(filename, aliases)
        # Lower-bound count.
        if len(aliases) >= min_count:
            print(f"  PASS   {filename}  count >= {min_count} ({len(aliases)} captured)")
        else:
            print(f"  FAIL   {filename}  count {len(aliases)} < {min_count}")
            failed += 1

    return failed


def run_regression() -> int:
    """Confirm non-cc path + Phase 1 parsing still work."""
    print()
    print("=" * 78)
    print("Regression")
    print("=" * 78)
    parser = CFamilyParser(language="cpp")
    # Non-cc .cpp file — must have empty field_asm_aliases.
    u = parser.parse(Path("/tmp/some.cpp"), "int x = 5;\n")
    got = dict(getattr(u, "field_asm_aliases", {}) or {})
    if got == {}:
        print("  PASS   non-cc .cpp parse: field_asm_aliases == {}")
        return 0
    print(f"  FAIL   non-cc .cpp parse leaked: {got}")
    return 1


if __name__ == "__main__":
    f1 = run_synthetic()
    f2 = run_real_files()
    f3 = run_regression()
    total = f1 + f2 + f3

    print()
    if total == 0:
        print(">>> PHASE 2: ALL CHECKS PASSED.")
        sys.exit(0)
    else:
        print(f">>> PHASE 2: {total} checks failed. Patch not yet applied (or incomplete).")
        sys.exit(1)
