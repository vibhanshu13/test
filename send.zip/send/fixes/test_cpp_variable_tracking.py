#!/usr/bin/env python3
"""Exhaustive test suite for C++ variable tracking and dependent-variable resolution.

Covers every implemented mechanism:

  SECTION 1 – cpp_lineage_utils (all 5 seed strategies, alias extraction, TPF regs)
  SECTION 2 – cpp_backward_tracer (BFS, register bridge, cycle guard, caps)
  SECTION 3 – VariableNameResolver (Cases A, B, C, D, D-ext / T12)
  SECTION 4 – build_chain_neighbor_set (T9)
  SECTION 5 – find_cpp_files_for_dep_var (T8 / FIX 18)
  SECTION 6 – T12 parser: canonical_name emission in variable_lineage_builder
  SECTION 7 – Integration: real blueprints (dx740200, dx710000)
  SECTION 8 – CPP-only tracking (no ASM interaction)
  SECTION 9 – Mixed CPP+ASM tracking (asm_alias, TPF regs, stitching)
  SECTION 10 – Edge cases and graceful degradation
  SECTION 11 – FIX 9 exact suffix guard (no short-name false positives)
  SECTION 12 – FIX 21 struct field via any pointer variable name
  SECTION 13 – Cross-file bridge helpers

Run:
    python3 fixes/test_cpp_variable_tracking.py

Exit 0 = all PASS/SKIP; exit 1 = any FAIL.
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

# ---------------------------------------------------------------------------
# Import all modules under test
# ---------------------------------------------------------------------------

IMPORT_ERRORS: Dict[str, str] = {}

try:
    from backward_traversal.utils.cpp_lineage_utils import (
        extract_asm_field_aliases,
        extract_tpf_regs_slots,
        find_cpp_seed_nodes,
        reverse_field_alias_map,
        build_chain_neighbor_set,
        find_cpp_files_for_dep_var,
        _build_struct_canonical_map,
    )
    IMPORT_ERRORS["cpp_lineage_utils"] = ""
except Exception as exc:
    IMPORT_ERRORS["cpp_lineage_utils"] = f"{type(exc).__name__}: {exc}"

try:
    from backward_traversal.tracing.cpp_backward_tracer import (
        trace_cpp_variable_backward,
        trace_cpp_variable_backward_multi,
    )
    IMPORT_ERRORS["cpp_backward_tracer"] = ""
except Exception as exc:
    IMPORT_ERRORS["cpp_backward_tracer"] = f"{type(exc).__name__}: {exc}"

try:
    from backward_traversal.utils.variable_name_resolver import (
        VariableNameResolver,
        _parse_arg_bind_target,
    )
    IMPORT_ERRORS["variable_name_resolver"] = ""
except Exception as exc:
    IMPORT_ERRORS["variable_name_resolver"] = f"{type(exc).__name__}: {exc}"

try:
    from backward_traversal.utils.blueprint_utils import load_json
    IMPORT_ERRORS["blueprint_utils"] = ""
except Exception as exc:
    IMPORT_ERRORS["blueprint_utils"] = f"{type(exc).__name__}: {exc}"

BLUEPRINT_DIR = REPO_ROOT / "output" / "asm" / "asm"
CALL_GRAPH_PATH = REPO_ROOT / "output" / "file_call_graph.json"
BLUEPRINTS_AVAILABLE = BLUEPRINT_DIR.exists() and any(BLUEPRINT_DIR.glob("*.cpp.json"))

# ---------------------------------------------------------------------------
# Test runner helpers
# ---------------------------------------------------------------------------

RESULTS: list[tuple[str, str, str]] = []
_SECTION: str = ""


def section(title: str) -> None:
    global _SECTION
    _SECTION = title
    print(f"\n{'=' * 78}")
    print(f"  {title}")
    print("=" * 78)


def check(label: str, cond: bool, detail: str = "") -> None:
    status = "PASS" if cond else "FAIL"
    RESULTS.append((status, f"{_SECTION} | {label}", detail))
    tail = f"   — {detail[:120]}" if detail else ""
    prefix = "  ✓" if status == "PASS" else "  ✗"
    print(f"{prefix}  {label}{tail}")


def skip(label: str, reason: str = "") -> None:
    RESULTS.append(("SKIP", f"{_SECTION} | {label}", reason))
    print(f"  ·  SKIP  {label}   — {reason}")


def _require(module: str) -> bool:
    err = IMPORT_ERRORS.get(module, "")
    if err:
        skip(f"[module {module}]", err)
        return False
    return True


# ===========================================================================
# SECTION 1 — cpp_lineage_utils
# ===========================================================================

def test_s1_reverse_field_alias_map() -> None:
    section("S1-A  reverse_field_alias_map")
    if not _require("cpp_lineage_utils"):
        return

    bp = {"field_asm_aliases": {
        "Da7gl.cmSystem": "WK_CMO",
        "Da7gl.noOfLimits": "WK_CNT",
        "CasGLRec.onlineSrcInd": "LG1OSI",
    }}
    rev = reverse_field_alias_map(bp)
    check("WK_CMO → [Da7gl.cmSystem]", rev.get("WK_CMO") == ["Da7gl.cmSystem"])
    check("WK_CNT → [Da7gl.noOfLimits]", rev.get("WK_CNT") == ["Da7gl.noOfLimits"])
    check("LG1OSI → [CasGLRec.onlineSrcInd]", rev.get("LG1OSI") == ["CasGLRec.onlineSrcInd"])
    check("empty blueprint → empty map", reverse_field_alias_map({}) == {})
    check("None field_asm_aliases → empty map", reverse_field_alias_map({"field_asm_aliases": None}) == {})


def test_s1_extract_asm_field_aliases() -> None:
    section("S1-B  extract_asm_field_aliases")
    if not _require("cpp_lineage_utils"):
        return

    bp = {"field_asm_aliases": {
        "Da7gl.cmSystem": "WK_CMO",
        "Da7gl.noOfLimits": "WK_CNT",
        "CasGLRec.onlineSrcInd": "LG1OSI",
    }}
    r1 = extract_asm_field_aliases(bp, "WK_CMO")
    check("WK_CMO maps to Da7gl.cmSystem", r1.get("WK_CMO") == ["Da7gl.cmSystem"], str(r1))

    r2 = extract_asm_field_aliases(bp, "wk_cmo")
    check("case-insensitive match (lowercase)", "WK_CMO" in r2, str(r2))

    r3 = extract_asm_field_aliases(bp, "UNKNOWN")
    check("unknown variable → empty dict", r3 == {}, str(r3))

    r4 = extract_asm_field_aliases(bp, "WK_CMO", transitive_vars=["LG1OSI"])
    check("transitive_vars expand filter", "WK_CMO" in r4 and "LG1OSI" in r4, str(r4))

    r5 = extract_asm_field_aliases({}, "WK_CMO")
    check("empty blueprint → empty dict", r5 == {}, str(r5))

    # Empty transitive_vars (edge case)
    r6 = extract_asm_field_aliases(bp, "WK_CNT", transitive_vars=[])
    check("empty transitive_vars stays single-var filter", list(r6.keys()) == ["WK_CNT"], str(r6))


def test_s1_extract_tpf_regs_slots() -> None:
    section("S1-C  extract_tpf_regs_slots")
    if not _require("cpp_lineage_utils"):
        return

    gvl = {"nodes": [], "edges": [
        {"source": "struct_field:glUpdate::regs.r7",
         "target": "register:arg@DA78:R7", "relation": "assign",
         "expression": "call buildLg1g1", "line": 76, "file": "dx740200.cpp"},
        {"source": "struct_field:glUpdate::regs.r1",
         "target": "register:arg@DA78:R1", "relation": "assign",
         "expression": "call buildLg1g1", "line": 76, "file": "dx740200.cpp"},
        # different callee — must NOT appear in DA78 result
        {"source": "struct_field:foo::regs.r0",
         "target": "register:arg@DB71:R0", "relation": "assign",
         "expression": "call other", "line": 44, "file": "dx740200.cpp"},
        # parameter: (not register:arg@) — must be ignored
        {"source": "struct_field:glUpdate::regs.r2",
         "target": "parameter:arg@DA78:R2", "relation": "assign",
         "expression": "call buildLg1g1", "line": 77, "file": "dx740200.cpp"},
    ]}

    r = extract_tpf_regs_slots(gvl, "DA78")
    check("DA78 has R7 slot", "R7" in r, str(list(r.keys())))
    check("DA78 has R1 slot", "R1" in r, str(list(r.keys())))
    check("DA78 does NOT include DB71 R0", "R0" not in r, str(list(r.keys())))

    r7 = r.get("R7") or {}
    check("R7 cpp_sources contains regs.r7",
          any("regs.r7" in s for s in (r7.get("cpp_sources") or [])), str(r7))
    check("R7 call_sites has line 76",
          any(cs.get("line") == 76 for cs in (r7.get("call_sites") or [])), str(r7))

    # Also test 'parameter:arg@' form (strategy also matches this)
    r2 = extract_tpf_regs_slots(gvl, "DA78")
    check("DA78 R2 captured via parameter:arg@ form",
          "R2" in r2, str(list(r2.keys())))

    check("missing callee → empty dict",
          extract_tpf_regs_slots(gvl, "NONEXISTENT") == {})
    check("empty gvl → empty dict",
          extract_tpf_regs_slots({}, "DA78") == {})
    check("None callee → empty dict",
          extract_tpf_regs_slots(gvl, "") == {})


def test_s1_find_cpp_seed_nodes_all_strategies() -> None:
    section("S1-D  find_cpp_seed_nodes — all 5 strategies")
    if not _require("cpp_lineage_utils"):
        return

    # ---------- Strategy 1: metadata.asm_alias ----------
    gvl1 = {"nodes": [
        {"id": "struct_field:f::da7gl->cmSystem",
         "kind": "struct_field", "name": "da7gl->cmSystem",
         "metadata": {"asm_alias": "WK_CMO"}},
        {"id": "struct_field:f::da7gl->noOfLimits",
         "kind": "struct_field", "name": "da7gl->noOfLimits",
         "metadata": {"asm_alias": "WK_CNT"}},  # different variable — must NOT match
    ], "edges": []}
    seeds1 = find_cpp_seed_nodes(gvl1, "WK_CMO", {}, {})
    check("Strategy 1: metadata.asm_alias exact match",
          "struct_field:f::da7gl->cmSystem" in seeds1, str(seeds1))
    check("Strategy 1: other asm_alias not included",
          "struct_field:f::da7gl->noOfLimits" not in seeds1, str(seeds1))

    # ---------- Strategy 2: field alias path suffix matching ----------
    gvl2 = {"nodes": [
        {"id": "struct_field:processA::da7gl->cmSystem",
         "kind": "struct_field", "name": "da7gl->cmSystem",
         "metadata": {}},
        {"id": "struct_field:processB::record->cmSystem",
         "kind": "struct_field", "name": "record->cmSystem",
         "metadata": {}},  # different pointer prefix — both should match
    ], "edges": []}
    asm_aliases = {"WK_CMO": ["Da7gl.cmSystem"]}  # Da7gl.cmSystem → parts: [da7gl, cmsystem]
    seeds2 = find_cpp_seed_nodes(gvl2, "WK_CMO", asm_aliases, {})
    check("Strategy 2: field alias suffix match (same field, different pointer)",
          "struct_field:processA::da7gl->cmSystem" in seeds2, str(seeds2))

    # ---------- Strategy 3: cpp_field_to_asm stitching edges ----------
    gvl3 = {"nodes": [
        {"id": "struct_field:processA::da7gl->cmSystem",
         "kind": "struct_field", "name": "da7gl->cmSystem",
         "metadata": {}}
    ], "edges": [
        {"source": "struct_field:processA::da7gl->cmSystem",
         "target": "memory:WK_CMO",
         "expression": "global_lineage_stitch:cpp_field_to_asm",
         "relation": "alias"},
    ]}
    seeds3 = find_cpp_seed_nodes(gvl3, "WK_CMO", {}, {})
    check("Strategy 3: cpp_field_to_asm edge source found",
          "struct_field:processA::da7gl->cmSystem" in seeds3, str(seeds3))

    # ---------- FIX 9: Strategy 3 exact suffix guard ----------
    # "WK_CMO" must NOT match "memory:R7_WK_CMO_STORE" (false substring match)
    gvl3b = {"nodes": [
        {"id": "struct_field:processA::da7gl->someField",
         "kind": "struct_field", "name": "da7gl->someField",
         "metadata": {}}
    ], "edges": [
        {"source": "struct_field:processA::da7gl->someField",
         "target": "memory:R7_WK_CMO",      # terminal is R7_WK_CMO, NOT WK_CMO
         "expression": "global_lineage_stitch:cpp_field_to_asm",
         "relation": "alias"},
    ]}
    seeds3b = find_cpp_seed_nodes(gvl3b, "WK_CMO", {}, {})
    check("FIX 9: Strategy 3 exact suffix guard (no false substring match)",
          "struct_field:processA::da7gl->someField" not in seeds3b, str(seeds3b))

    # ---------- Strategy 4: tpf_regs_slots cpp_sources ----------
    tpf_slots = {"R7": {"cpp_sources": ["struct_field:glUpdate::regs.r7"], "call_sites": []}}
    gvl4 = {"nodes": [], "edges": []}
    seeds4 = find_cpp_seed_nodes(gvl4, "R7", {}, tpf_slots)
    check("Strategy 4: tpf_regs cpp_sources included",
          "struct_field:glUpdate::regs.r7" in seeds4, str(seeds4))

    # ---------- Strategy 5: direct name/id match ----------
    gvl5 = {"nodes": [
        {"id": "variable:fileA.cpp::cmSystem",
         "kind": "variable", "name": "cmSystem",
         "metadata": {}},
        {"id": "struct_field:processA::da7gl->cmSystem",
         "kind": "struct_field", "name": "cmSystem",
         "metadata": {}},
        {"id": "struct_field:processB::record->cmSystem",
         "kind": "struct_field", "name": "cmSystem",
         "metadata": {}},
    ], "edges": []}
    seeds5 = find_cpp_seed_nodes(gvl5, "cmSystem", {}, {})
    check("Strategy 5: variable id exact match",
          "variable:fileA.cpp::cmSystem" in seeds5, str(seeds5))
    check("Strategy 5: struct field via ->cmSystem suffix",
          "struct_field:processA::da7gl->cmSystem" in seeds5, str(seeds5))
    check("Strategy 5: struct field via different pointer ->cmSystem",
          "struct_field:processB::record->cmSystem" in seeds5, str(seeds5))

    # ---------- Strategy 5 FIX 21: struct field via any pointer ----------
    gvl21 = {"nodes": [
        {"id": "struct_field:proc::ptrA->cmSys",
         "kind": "struct_field", "name": "ptrA->cmSys", "metadata": {}},
        {"id": "struct_field:proc::ptrB->cmSys",
         "kind": "struct_field", "name": "ptrB->cmSys", "metadata": {}},
    ], "edges": []}
    seeds21 = find_cpp_seed_nodes(gvl21, "cmSys", {}, {})
    check("FIX 21: Strategy 5 finds field under any pointer variable name",
          len(seeds21) == 2, f"seeds={seeds21}")

    # ---------- Deduplication: same node ID from multiple strategies ----------
    gvl_dup = {"nodes": [
        {"id": "struct_field:f::da7gl->cmSystem",
         "kind": "struct_field", "name": "da7gl->cmSystem",
         "metadata": {"asm_alias": "WK_CMO"}},
    ], "edges": [
        {"source": "struct_field:f::da7gl->cmSystem",
         "target": "memory:WK_CMO",
         "expression": "global_lineage_stitch:cpp_field_to_asm",
         "relation": "alias"},
    ]}
    asm_dup = {"WK_CMO": ["Da7gl.cmSystem"]}
    seeds_dup = find_cpp_seed_nodes(gvl_dup, "WK_CMO", asm_dup, {})
    check("Deduplication: same node from multiple strategies counted once",
          seeds_dup.count("struct_field:f::da7gl->cmSystem") == 1,
          f"seeds={seeds_dup}")


# ===========================================================================
# SECTION 2 — cpp_backward_tracer
# ===========================================================================

def test_s2_tracer_basic() -> None:
    section("S2-A  cpp_backward_tracer — basic BFS")
    if not _require("cpp_backward_tracer"):
        return

    # Linear chain: literal → struct_field (one assign)
    gvl = {"nodes": [
        {"id": "literal:'Y'", "kind": "literal", "name": "'Y'"},
        {"id": "struct_field:f::da7gl->cmSystem",
         "kind": "struct_field", "name": "cmSystem",
         "metadata": {"asm_alias": "WK_CMO"}},
    ], "edges": [
        {"source": "literal:'Y'",
         "target": "struct_field:f::da7gl->cmSystem",
         "relation": "assign", "line": 10, "expression": "da7gl->cmSystem = 'Y'"},
    ]}
    res = trace_cpp_variable_backward("struct_field:f::da7gl->cmSystem", gvl,
                                      max_depth=4, max_nodes=100)
    check("returns dict", isinstance(res, dict))
    check("has nodes key", isinstance(res.get("nodes"), list))
    check("has edges key", isinstance(res.get("edges"), list))
    check("has dep_vars key", isinstance(res.get("dep_vars"), list))
    check("seed node in result",
          any("da7gl->cmSystem" in str(n.get("id", "")) for n in (res.get("nodes") or [])),
          str([n.get("id") for n in res.get("nodes", [])]))
    check("literal terminal recorded",
          any(n.get("kind") == "literal" for n in (res.get("nodes") or [])),
          str([n.get("kind") for n in res.get("nodes", [])]))


def test_s2_tracer_register_bridge() -> None:
    section("S2-B  cpp_backward_tracer — register terminal → bridge_back_to_asm")
    if not _require("cpp_backward_tracer"):
        return

    gvl = {"nodes": [
        {"id": "register:R7", "kind": "register", "name": "R7"},
        {"id": "register:arg@DA78:R7", "kind": "register", "name": "arg@DA78:R7"},
    ], "edges": [
        {"source": "register:R7",
         "target": "register:arg@DA78:R7",
         "relation": "alias",
         "expression": "global_lineage_stitch:tpf_regs_register_bridge"},
    ]}
    res = trace_cpp_variable_backward("register:arg@DA78:R7", gvl, max_depth=4, max_nodes=100)
    br = res.get("bridge_registers") or []
    dep_vars = res.get("dep_vars") or []
    check("register terminal in bridge_registers",
          any("R7" in str(b) for b in br), str(br))
    check("bridge register appears in dep_vars",
          any("R7" in str(d) for d in dep_vars), str(dep_vars))


def test_s2_tracer_cycle_prevention() -> None:
    section("S2-C  cpp_backward_tracer — cycle prevention")
    if not _require("cpp_backward_tracer"):
        return

    # nodeA ← nodeB ← nodeA (cycle)
    gvl = {"nodes": [
        {"id": "variable:fA::varA", "kind": "variable", "name": "varA"},
        {"id": "variable:fA::varB", "kind": "variable", "name": "varB"},
    ], "edges": [
        {"source": "variable:fA::varB", "target": "variable:fA::varA",
         "relation": "assign"},
        {"source": "variable:fA::varA", "target": "variable:fA::varB",
         "relation": "assign"},  # creates a cycle
    ]}
    # Should NOT raise or loop forever
    try:
        res = trace_cpp_variable_backward("variable:fA::varA", gvl, max_depth=10, max_nodes=100)
        check("cycle does not raise", True)
        check("result has finite nodes",
              isinstance(res.get("nodes"), list) and len(res.get("nodes", [])) < 10,
              f"nodes={[n.get('id') for n in res.get('nodes', [])]}")
    except Exception as exc:
        check("cycle does not raise", False, str(exc))


def test_s2_tracer_depth_and_node_caps() -> None:
    section("S2-D  cpp_backward_tracer — depth and node caps")
    if not _require("cpp_backward_tracer"):
        return

    # Build a linear chain longer than max_depth
    nodes = []
    edges = []
    for i in range(20):
        nodes.append({"id": f"variable:f::v{i}", "kind": "variable", "name": f"v{i}"})
        if i > 0:
            edges.append({"source": f"variable:f::v{i-1}",
                          "target": f"variable:f::v{i}",
                          "relation": "assign"})
    gvl = {"nodes": nodes, "edges": edges}

    res3 = trace_cpp_variable_backward(f"variable:f::v19", gvl, max_depth=3, max_nodes=100)
    check("max_depth=3 limits traversal depth",
          len(res3.get("nodes", [])) <= 4, f"{len(res3.get('nodes', []))} nodes")

    res5 = trace_cpp_variable_backward(f"variable:f::v19", gvl, max_depth=100, max_nodes=5)
    check("max_nodes=5 limits total nodes",
          len(res5.get("nodes", [])) <= 5, f"{len(res5.get('nodes', []))} nodes")
    check("warning emitted for node cap",
          len(res5.get("warnings") or []) > 0 or len(res5.get("nodes", [])) <= 5)


def test_s2_tracer_multi() -> None:
    section("S2-E  trace_cpp_variable_backward_multi — merge + dedup")
    if not _require("cpp_backward_tracer"):
        return

    gvl = {"nodes": [
        {"id": "literal:'Y'", "kind": "literal", "name": "'Y'"},
        {"id": "literal:'N'", "kind": "literal", "name": "'N'"},
        {"id": "struct_field:f::da7gl->cmSystem",
         "kind": "struct_field", "name": "cmSystem", "metadata": {}},
        {"id": "struct_field:f::da7gl->noOfLimits",
         "kind": "struct_field", "name": "noOfLimits", "metadata": {}},
    ], "edges": [
        {"source": "literal:'Y'", "target": "struct_field:f::da7gl->cmSystem",
         "relation": "assign"},
        {"source": "literal:'N'", "target": "struct_field:f::da7gl->cmSystem",
         "relation": "assign"},
        {"source": "literal:'Y'", "target": "struct_field:f::da7gl->noOfLimits",
         "relation": "assign"},
    ]}
    seeds = ["struct_field:f::da7gl->cmSystem", "struct_field:f::da7gl->noOfLimits"]
    res = trace_cpp_variable_backward_multi(seeds, gvl, max_depth=4, max_nodes=200)
    check("multi result has seeds key", isinstance(res.get("seeds"), list))
    check("both seeds listed", all(s in (res.get("seeds") or []) for s in seeds))
    # literal 'Y' is reached from both seeds — should be deduplicated in nodes
    y_nodes = [n for n in (res.get("nodes") or []) if n.get("id") == "literal:'Y'"]
    check("shared literal deduplicated in merged result", len(y_nodes) == 1, str(len(y_nodes)))


def test_s2_tracer_stitching_edge_skipped() -> None:
    section("S2-F  cpp_backward_tracer — stitching edge filtering rules")
    if not _require("cpp_backward_tracer"):
        return

    # RULE: alias-relation edges are ALWAYS followed (same-variable-different-name
    # links like cpp_field_to_asm). Only assign/define/arg_bind stitching edges
    # with recognised skip-expressions are filtered.
    gvl_alias = {"nodes": [
        {"id": "struct_field:f::da7gl->cmSystem",
         "kind": "struct_field", "name": "cmSystem", "metadata": {}},
        {"id": "memory:WK_CMO", "kind": "memory", "name": "WK_CMO"},
    ], "edges": [
        {"source": "memory:WK_CMO",
         "target": "struct_field:f::da7gl->cmSystem",
         "relation": "alias",       # alias is ALWAYS followed
         "expression": "global_lineage_stitch:cpp_field_to_asm"},
    ]}
    res_alias = trace_cpp_variable_backward("struct_field:f::da7gl->cmSystem",
                                            gvl_alias, max_depth=4, max_nodes=100)
    node_ids_alias = [n.get("id") for n in (res_alias.get("nodes") or [])]
    check("alias-relation stitching edge IS followed (by design)",
          "memory:WK_CMO" in node_ids_alias, str(node_ids_alias))

    # assign-relation edge with tpf_regs stitch prefix → MUST be skipped
    gvl_assign_stitch = {"nodes": [
        {"id": "variable:f::varA", "kind": "variable", "name": "varA", "metadata": {}},
        {"id": "variable:f::varB", "kind": "variable", "name": "varB", "metadata": {}},
    ], "edges": [
        {"source": "variable:f::varA",
         "target": "variable:f::varB",
         "relation": "assign",
         "expression": "global_lineage_stitch:tpf_regs_register_bridge something"},
    ]}
    res_stitch = trace_cpp_variable_backward("variable:f::varB", gvl_assign_stitch,
                                             max_depth=4, max_nodes=100)
    node_ids_stitch = [n.get("id") for n in (res_stitch.get("nodes") or [])]
    check("assign-relation tpf_regs stitch edge is NOT followed",
          "variable:f::varA" not in node_ids_stitch, str(node_ids_stitch))


# ===========================================================================
# SECTION 3 — VariableNameResolver
# ===========================================================================

def test_s3_parse_arg_bind_target() -> None:
    section("S3-A  _parse_arg_bind_target helper")
    if not _require("variable_name_resolver"):
        return

    fn, idx = _parse_arg_bind_target("call_arg:getDateAndTime#0")
    check("parses function name", fn == "getDateAndTime", str(fn))
    check("parses index 0", idx == 0, str(idx))

    fn2, idx2 = _parse_arg_bind_target("call_arg:buildLg1#7")
    check("parses index 7", idx2 == 7, str(idx2))

    fn3, idx3 = _parse_arg_bind_target("parameter:funcName::paramName")
    check("non-call_arg: prefix → (None, None)", fn3 is None and idx3 is None)

    fn4, idx4 = _parse_arg_bind_target("call_arg:noHashHere")
    check("missing # → (None, None)", fn4 is None and idx4 is None)

    fn5, idx5 = _parse_arg_bind_target("")
    check("empty string → (None, None)", fn5 is None and idx5 is None)

    fn6, idx6 = _parse_arg_bind_target("call_arg:fn#notanint")
    check("non-int index → (None, None)", fn6 is None and idx6 is None)


def _make_resolver_no_blueprints() -> "VariableNameResolver":
    """Resolver with no blueprint dir and no identity index (tests fallback)."""
    import tempfile
    d = Path(tempfile.mkdtemp())
    return VariableNameResolver(d)


def test_s3_resolver_case_a_asm_to_cpp() -> None:
    """Case A: ASM name → C++ field via field_asm_aliases reverse lookup."""
    section("S3-B  Case A — ASM name → C++ field (field_asm_aliases reverse)")
    if not _require("variable_name_resolver"):
        return

    # Build a minimal temp blueprint dir with a cpp.json that has field_asm_aliases
    import tempfile, msgpack
    tmp_dir = Path(tempfile.mkdtemp())

    # Write fake cpp.json as msgpack (matching the project's format)
    bp_data = {
        "field_asm_aliases": {
            "Da7gl.cmSystem": "WK_CMO",
            "Da7gl.noOfLimits": "WK_CNT",
        },
        "global_variable_lineage": {"nodes": [], "edges": []}
    }
    bp_path = tmp_dir / "testfile.cpp.json"
    bp_path.write_bytes(msgpack.packb(bp_data, use_bin_type=True))

    resolver = VariableNameResolver(tmp_dir)
    result = resolver.resolve("WK_CMO", "testfile")
    check("Case A: WK_CMO → Da7gl.cmSystem", result == "Da7gl.cmSystem", str(result))

    result2 = resolver.resolve("wk_cmo", "testfile")
    check("Case A: case-insensitive ASM name", result2 == "Da7gl.cmSystem", str(result2))

    result3 = resolver.resolve("WK_CNT", "testfile")
    check("Case A: WK_CNT → Da7gl.noOfLimits", result3 == "Da7gl.noOfLimits", str(result3))

    result_none = resolver.resolve("UNKNOWN_VAR", "testfile")
    check("Case A: unknown var → None", result_none is None, str(result_none))


def test_s3_resolver_case_b_cpp_to_asm() -> None:
    """Case B: C++ field → ASM name via field_asm_aliases forward lookup."""
    section("S3-C  Case B — C++ field → ASM name (field_asm_aliases forward)")
    if not _require("variable_name_resolver"):
        return

    import tempfile, msgpack
    tmp_dir = Path(tempfile.mkdtemp())
    bp_data = {
        "field_asm_aliases": {
            "Da7gl.cmSystem": "WK_CMO",
        },
        "global_variable_lineage": {"nodes": [], "edges": []}
    }
    bp_path = tmp_dir / "testfile.cpp.json"
    bp_path.write_bytes(msgpack.packb(bp_data, use_bin_type=True))

    resolver = VariableNameResolver(tmp_dir)
    result = resolver.resolve("Da7gl.cmSystem", "testfile")
    check("Case B: Da7gl.cmSystem → WK_CMO", result == "WK_CMO", str(result))


def test_s3_resolver_case_c_arg_bind() -> None:
    """Case C: pure C++→C++ dep_var rename via arg_bind parameter binding."""
    section("S3-D  Case C — arg_bind parameter binding (cross-C++ rename)")
    if not _require("variable_name_resolver"):
        return

    import tempfile, msgpack
    tmp_dir = Path(tempfile.mkdtemp())

    # Source file: has arg_bind edge from localVar to call_arg:targetFn#0
    src_bp = {
        "field_asm_aliases": {},
        "global_variable_lineage": {
            "nodes": [
                {"id": "variable:source::localVar", "kind": "variable",
                 "name": "source::localVar", "metadata": {}},
            ],
            "edges": [
                {"source": "variable:source::localVar",
                 "target": "call_arg:targetFn#0",
                 "relation": "arg_bind"},
            ]
        }
    }
    # Target file: has parameter node for targetFn at index 0
    tgt_bp = {
        "field_asm_aliases": {},
        "global_variable_lineage": {
            "nodes": [
                {"id": "parameter:targetFn::paramA", "kind": "parameter",
                 "name": "targetFn::paramA",
                 "metadata": {"enclosing_function": "targetFn"}},
                {"id": "parameter:targetFn::paramB", "kind": "parameter",
                 "name": "targetFn::paramB",
                 "metadata": {"enclosing_function": "targetFn"}},
            ],
            "edges": []
        }
    }
    (tmp_dir / "sourceFile.cpp.json").write_bytes(msgpack.packb(src_bp, use_bin_type=True))
    (tmp_dir / "targetFile.cpp.json").write_bytes(msgpack.packb(tgt_bp, use_bin_type=True))

    resolver = VariableNameResolver(tmp_dir)

    # localVar in sourceFile is arg 0 of targetFn → paramA in targetFile
    result = resolver.resolve("localVar", "targetFile", source_stem="sourceFile")
    check("Case C: localVar → paramA (arg_bind index 0)", result == "paramA", str(result))

    # Without source_stem → Case C cannot run
    result_no_src = resolver.resolve("localVar", "targetFile")
    check("Case C: no source_stem → skips arg_bind (returns None or Case A/B)",
          result_no_src != "paramA" or result_no_src is None,
          f"got {result_no_src!r} (Case C must require source_stem)")

    # Test index 1: would need a second arg_bind edge; confirm index 0 is correct
    result_b = resolver.resolve("localVar", "targetFile", source_stem="sourceFile")
    check("Case C: caching returns same result on repeat call", result_b == "paramA",
          str(result_b))


def test_s3_resolver_case_d_struct_canonical() -> None:
    """Case D: struct field canonical matching via (enclosing_type, field_name)."""
    section("S3-E  Case D — struct canonical (enclosing_type + field_name)")
    if not _require("variable_name_resolver"):
        return

    import tempfile, msgpack
    tmp_dir = Path(tempfile.mkdtemp())

    # Source: Da7gl.cmSystem via 'da7gl' pointer
    src_bp = {
        "field_asm_aliases": {},
        "global_variable_lineage": {
            "nodes": [
                {"id": "struct_field:sourceFunc::da7gl->cmSystem",
                 "kind": "struct_field", "name": "da7gl->cmSystem",
                 "metadata": {"enclosing_type": "Da7gl"}},
            ],
            "edges": []
        }
    }
    # Target: same field accessed via 'gl' pointer
    tgt_bp = {
        "field_asm_aliases": {},
        "global_variable_lineage": {
            "nodes": [
                {"id": "struct_field:targetFunc::gl->cmSystem",
                 "kind": "struct_field", "name": "gl->cmSystem",
                 "metadata": {"enclosing_type": "Da7gl"}},
            ],
            "edges": []
        }
    }
    (tmp_dir / "srcFile.cpp.json").write_bytes(msgpack.packb(src_bp, use_bin_type=True))
    (tmp_dir / "tgtFile.cpp.json").write_bytes(msgpack.packb(tgt_bp, use_bin_type=True))

    resolver = VariableNameResolver(tmp_dir)
    result = resolver.resolve("cmSystem", "tgtFile", source_stem="srcFile")
    # Same field name in both — Case D returns None (Strategy 5 handles same-name)
    check("Case D: same field name → returns None (Strategy 5 handles it)",
          result is None, str(result))

    # Case D uses (enclosing_type, field_name) as the canonical key.
    # Same type + SAME field name but different pointer variable = Case D match.
    # Different field name under same type = NOT a Case D match (canonical keys differ).
    # This is by design: T11's purpose is to handle pointer-variable renames, not
    # field renames within a struct (which would require separate alias information).
    tgt_bp2 = {
        "field_asm_aliases": {},
        "global_variable_lineage": {
            "nodes": [
                {"id": "struct_field:targetFunc::gl->cmSysField",
                 "kind": "struct_field", "name": "gl->cmSysField",
                 "metadata": {"enclosing_type": "Da7gl"}},
            ],
            "edges": []
        }
    }
    (tmp_dir / "tgtFile2.cpp.json").write_bytes(msgpack.packb(tgt_bp2, use_bin_type=True))
    result2 = resolver.resolve("cmSystem", "tgtFile2", source_stem="srcFile")
    # cmSystem and cmSysField have DIFFERENT field names → canonical keys differ
    # → Case D cannot match → returns None (Strategy 5 handles same-name lookup)
    check("Case D: different field name under same type → None (canonical keys differ, by design)",
          result2 is None, str(result2))

    # Case D DOES match when same type AND same field name, different pointer prefix
    tgt_bp3 = {
        "field_asm_aliases": {},
        "global_variable_lineage": {
            "nodes": [
                {"id": "struct_field:targetFunc::gl->cmSystem",   # same field, different pointer
                 "kind": "struct_field", "name": "gl->cmSystem",
                 "metadata": {"enclosing_type": "Da7gl"}},
            ],
            "edges": []
        }
    }
    (tmp_dir / "tgtFile3.cpp.json").write_bytes(msgpack.packb(tgt_bp3, use_bin_type=True))
    result3 = resolver.resolve("cmSystem", "tgtFile3", source_stem="srcFile")
    # Same field name in both → Case D returns None (Strategy 5 handles same-name lookup)
    check("Case D: same field name, different pointer → None (Strategy 5 handles same-name)",
          result3 is None, str(result3))

    # Missing source struct field → Case D returns None gracefully
    result3 = resolver.resolve("unknownField", "tgtFile", source_stem="srcFile")
    check("Case D: unknown field in source → None", result3 is None, str(result3))

    # No enclosing_type in source → Case D returns None
    src_no_etype = {
        "field_asm_aliases": {},
        "global_variable_lineage": {
            "nodes": [
                {"id": "struct_field:f::ptr->cmSystem",
                 "kind": "struct_field", "name": "ptr->cmSystem",
                 "metadata": {}},  # no enclosing_type
            ],
            "edges": []
        }
    }
    (tmp_dir / "srcNoType.cpp.json").write_bytes(msgpack.packb(src_no_etype, use_bin_type=True))
    result4 = resolver.resolve("cmSystem", "tgtFile", source_stem="srcNoType")
    check("Case D: missing enclosing_type in source → None", result4 is None, str(result4))


def test_s3_resolver_case_d_ext_t12() -> None:
    """Case D-ext (T12): file-scope variable canonical matching."""
    section("S3-F  Case D-ext T12 — variable canonical_name cross-file")
    if not _require("variable_name_resolver"):
        return

    import tempfile, msgpack
    tmp_dir = Path(tempfile.mkdtemp())

    # Source: g_systemLimit with canonical_name = "fileA::g_systemLimit"
    src_bp = {
        "field_asm_aliases": {},
        "global_variable_lineage": {
            "nodes": [
                {"id": "variable:fileA.cpp::g_systemLimit",
                 "kind": "variable", "name": "g_systemLimit",
                 "metadata": {"canonical_name": "fileA::g_systemLimit",
                               "is_file_scope": True}},
            ],
            "edges": []
        }
    }
    # Target: different local name for the same canonical variable
    tgt_bp = {
        "field_asm_aliases": {},
        "global_variable_lineage": {
            "nodes": [
                {"id": "variable:fileB.cpp::systemLimitCap",
                 "kind": "variable", "name": "systemLimitCap",
                 "metadata": {"canonical_name": "fileA::g_systemLimit",
                               "is_file_scope": True}},
            ],
            "edges": []
        }
    }
    (tmp_dir / "fileA.cpp.json").write_bytes(msgpack.packb(src_bp, use_bin_type=True))
    (tmp_dir / "fileB.cpp.json").write_bytes(msgpack.packb(tgt_bp, use_bin_type=True))

    resolver = VariableNameResolver(tmp_dir)
    result = resolver.resolve("g_systemLimit", "fileB", source_stem="fileA")
    check("Case D-ext: cross-file rename via canonical_name",
          result == "systemLimitCap", str(result))

    # Same name in target → returns None (Strategy 5 handles it)
    tgt_same_bp = {
        "field_asm_aliases": {},
        "global_variable_lineage": {
            "nodes": [
                {"id": "variable:fileC.cpp::g_systemLimit",
                 "kind": "variable", "name": "g_systemLimit",
                 "metadata": {"canonical_name": "fileA::g_systemLimit",
                               "is_file_scope": True}},
            ],
            "edges": []
        }
    }
    (tmp_dir / "fileC.cpp.json").write_bytes(msgpack.packb(tgt_same_bp, use_bin_type=True))
    result_same = resolver.resolve("g_systemLimit", "fileC", source_stem="fileA")
    check("Case D-ext: same name in target → None (no redundant translation)",
          result_same is None, str(result_same))

    # Pre-T12 blueprint (no canonical_name) → graceful None
    src_old_bp = {
        "field_asm_aliases": {},
        "global_variable_lineage": {
            "nodes": [
                {"id": "variable:fileD.cpp::g_systemLimit",
                 "kind": "variable", "name": "g_systemLimit",
                 "metadata": {}},  # no canonical_name
            ],
            "edges": []
        }
    }
    (tmp_dir / "fileD.cpp.json").write_bytes(msgpack.packb(src_old_bp, use_bin_type=True))
    result_old = resolver.resolve("g_systemLimit", "fileB", source_stem="fileD")
    check("Case D-ext: pre-T12 blueprint (no canonical_name) → graceful None",
          result_old is None, str(result_old))

    # No source_stem → Case D-ext does not run
    result_no_src = resolver.resolve("g_systemLimit", "fileB")
    check("Case D-ext: no source_stem → skipped",
          result_no_src != "systemLimitCap", f"got {result_no_src!r}")


def test_s3_resolver_resolution_order() -> None:
    """Verify that Cases A/B/C/D/D-ext run in correct priority order."""
    section("S3-G  Resolution order — Cases tried in A→B→C→D→D-ext sequence")
    if not _require("variable_name_resolver"):
        return

    import tempfile, msgpack
    tmp_dir = Path(tempfile.mkdtemp())

    # Build a blueprint where Case A would match first
    bp_data = {
        "field_asm_aliases": {"Da7gl.cmSystem": "WK_CMO"},
        "global_variable_lineage": {"nodes": [], "edges": []}
    }
    (tmp_dir / "priorityTest.cpp.json").write_bytes(msgpack.packb(bp_data, use_bin_type=True))

    resolver = VariableNameResolver(tmp_dir)

    # Case A: ASM name in a target C++ file → should return C++ field name
    r = resolver.resolve("WK_CMO", "priorityTest")
    check("Case A takes priority over later cases",
          r == "Da7gl.cmSystem", str(r))

    # Resolver with no blueprint dir → all Cases return None immediately
    no_bp_resolver = _make_resolver_no_blueprints()
    r2 = no_bp_resolver.resolve("WK_CMO", "noSuchFile", source_stem="alsoNoSuchFile")
    check("No blueprints → all cases gracefully return None", r2 is None, str(r2))


def test_s3_resolver_cache() -> None:
    """FIFO cache eviction does not corrupt results."""
    section("S3-H  FIFO cache eviction correctness")
    if not _require("variable_name_resolver"):
        return

    import tempfile, msgpack
    tmp_dir = Path(tempfile.mkdtemp())

    # Write a blueprint and verify result is cached correctly
    bp_data = {
        "field_asm_aliases": {"Da7gl.cmSystem": "WK_CMO"},
        "global_variable_lineage": {"nodes": [], "edges": []}
    }
    (tmp_dir / "cachefile.cpp.json").write_bytes(msgpack.packb(bp_data, use_bin_type=True))

    resolver = VariableNameResolver(tmp_dir)
    # First call populates cache
    r1 = resolver.resolve("WK_CMO", "cachefile")
    # Second call should hit cache and return same result
    r2 = resolver.resolve("WK_CMO", "cachefile")
    check("Cached result matches first call", r1 == r2, f"r1={r1} r2={r2}")


# ===========================================================================
# SECTION 4 — build_chain_neighbor_set (T9)
# ===========================================================================

def test_s4_chain_neighbor_set() -> None:
    section("S4  build_chain_neighbor_set (T9)")
    if not _require("cpp_lineage_utils"):
        return

    # Build a mini call graph in a temp file
    import tempfile, msgpack
    tmp_dir = Path(tempfile.mkdtemp())

    cg_data = {
        "edges": [
            {"source": "fileA", "target": "fileB"},
            {"source": "fileB", "target": "fileC"},
            {"source": "fileC", "target": "fileD"},  # 3 hops from fileA
        ]
    }
    cg_path = tmp_dir / "file_call_graph.json"
    cg_path.write_bytes(msgpack.packb(cg_data, use_bin_type=True))

    # max_hops=1: should get fileA, fileB (direct neighbour of fileA)
    ns1 = build_chain_neighbor_set(["fileA"], cg_path, max_hops=1)
    check("1 hop: fileA in set", "fileA" in ns1)
    check("1 hop: fileB (direct neighbour) in set", "fileB" in ns1)
    check("1 hop: fileC (2 hops) NOT in set", "fileC" not in ns1)

    # max_hops=2: should get fileA, fileB, fileC
    ns2 = build_chain_neighbor_set(["fileA"], cg_path, max_hops=2)
    check("2 hops: fileC in set", "fileC" in ns2)
    check("2 hops: fileD (3 hops) NOT in set", "fileD" not in ns2)

    # Undirected: fileC can also reach fileB (caller direction)
    ns3 = build_chain_neighbor_set(["fileC"], cg_path, max_hops=1)
    check("undirected: fileC's 1-hop includes fileB (caller)", "fileB" in ns3)
    check("undirected: fileC's 1-hop includes fileD (callee)", "fileD" in ns3)

    # Multi-seed: seed from two files simultaneously
    ns4 = build_chain_neighbor_set(["fileA", "fileD"], cg_path, max_hops=1)
    check("multi-seed: fileA and fileD both in set", "fileA" in ns4 and "fileD" in ns4)
    check("multi-seed: fileB (fileA neighbour) in set", "fileB" in ns4)
    check("multi-seed: fileC (fileD neighbour) in set", "fileC" in ns4)

    # Empty chain returns empty set (fallback)
    ns5 = build_chain_neighbor_set([], cg_path, max_hops=2)
    check("empty chain → empty neighbor set", len(ns5) == 0, str(ns5))

    # Non-existent graph file → fallback to selected_chain
    ns6 = build_chain_neighbor_set(["fileA", "fileB"], tmp_dir / "nonexistent.json", max_hops=2)
    check("missing graph → fallback to selected_chain",
          "fileA" in ns6 and "fileB" in ns6, str(ns6))
    check("missing graph → no extras beyond chain",
          ns6 == {"fileA", "fileB"}, str(ns6))


# ===========================================================================
# SECTION 5 — find_cpp_files_for_dep_var (T8 / FIX 18)
# ===========================================================================

def test_s5_find_cpp_files_for_dep_var() -> None:
    section("S5  find_cpp_files_for_dep_var (T8 + FIX 18)")
    if not _require("cpp_lineage_utils"):
        return

    import tempfile, msgpack
    tmp_dir = Path(tempfile.mkdtemp())

    # Create two blueprints: one with a matching variable, one without
    match_bp = {
        "global_variable_lineage": {
            "nodes": [
                {"id": "struct_field:f::da7gl->cmSystem",
                 "kind": "struct_field", "name": "cmSystem",
                 "metadata": {"asm_alias": "WK_CMO"}},
            ],
            "edges": []
        }
    }
    no_match_bp = {
        "global_variable_lineage": {
            "nodes": [
                {"id": "variable:f::otherVar",
                 "kind": "variable", "name": "otherVar", "metadata": {}},
            ],
            "edges": []
        }
    }
    (tmp_dir / "matchFile.cpp.json").write_bytes(msgpack.packb(match_bp, use_bin_type=True))
    (tmp_dir / "noMatchFile.cpp.json").write_bytes(msgpack.packb(no_match_bp, use_bin_type=True))

    file_type_map = {"matchFile": "cpp", "noMatchFile": "cpp", "asmFile": "asm"}

    # max_scan=0 (FIX 18 default) → always returns empty
    r0 = find_cpp_files_for_dep_var("WK_CMO", tmp_dir, file_type_map, max_scan=0)
    check("FIX 18: max_scan=0 returns empty list", r0 == [], str(r0))

    # max_scan>0 → scans and finds the matching file
    r1 = find_cpp_files_for_dep_var("WK_CMO", tmp_dir, file_type_map, max_scan=10)
    check("T8: max_scan>0 finds matchFile", "matchFile" in r1, str(r1))
    check("T8: noMatchFile not returned", "noMatchFile" not in r1, str(r1))
    check("T8: asmFile not scanned (type=asm)", "asmFile" not in r1, str(r1))

    # neighbor_set filtering: only scan files in neighbor_set
    r2 = find_cpp_files_for_dep_var("WK_CMO", tmp_dir, file_type_map,
                                     max_scan=10, neighbor_set={"noMatchFile"})
    check("T9 neighbor_set: matchFile excluded by neighbor filter", "matchFile" not in r2, str(r2))
    check("T9 neighbor_set: noMatchFile scanned but not found (no match)", r2 == [], str(r2))

    # Variable not found anywhere
    r3 = find_cpp_files_for_dep_var("NONEXISTENT_VAR_XYZ", tmp_dir, file_type_map, max_scan=10)
    check("T8: variable not found anywhere → empty list", r3 == [], str(r3))


# ===========================================================================
# SECTION 6 — T12 parser: canonical_name emission
# ===========================================================================

def test_s6_t12_canonical_name_emission() -> None:
    section("S6  T12 parser: canonical_name emitted for file-scope variable nodes")
    # This tests the logic added to variable_lineage_builder.py

    from pathlib import Path as _Path

    # Simulate the T12 block conditions
    file = "/some/project/dx740200.cpp"
    stem = _Path(file).stem
    check("stem extraction: dx740200.cpp → dx740200", stem == "dx740200", str(stem))

    # Test each scope variant
    for scope_val in ("global", "extern", "static"):
        node_metadata: Dict[str, Any] = {}

        class FakeDecl:
            kind = "variable"
            function = None
            scope = scope_val
            name = "g_testVar"

        decl = FakeDecl()
        if (decl.kind == "variable" and not decl.function
                and decl.scope in ("global", "extern", "static")):
            node_metadata["canonical_name"] = f"{_Path(file).stem}::{decl.name}"
            node_metadata["is_file_scope"] = True

        check(f"scope={scope_val!r}: canonical_name emitted",
              node_metadata.get("canonical_name") == "dx740200::g_testVar",
              str(node_metadata))
        check(f"scope={scope_val!r}: is_file_scope=True",
              node_metadata.get("is_file_scope") is True)

    # Function-local variable must NOT get canonical_name
    nm_local: Dict[str, Any] = {}

    class FakeLocalDecl:
        kind = "variable"
        function = "someFunc"
        scope = "local"
        name = "localVar"

    d2 = FakeLocalDecl()
    if (d2.kind == "variable" and not d2.function
            and d2.scope in ("global", "extern", "static")):
        nm_local["canonical_name"] = "should_not_be_set"

    check("function-local variable: no canonical_name", nm_local == {})

    # Parameter node must NOT get canonical_name
    nm_param: Dict[str, Any] = {}

    class FakeParam:
        kind = "parameter"
        function = None
        scope = "global"
        name = "param1"

    d3 = FakeParam()
    if (d3.kind == "variable" and not d3.function
            and d3.scope in ("global", "extern", "static")):
        nm_param["canonical_name"] = "should_not_be_set"

    check("parameter kind: no canonical_name", nm_param == {})

    # Member (struct field) must NOT get canonical_name
    nm_member: Dict[str, Any] = {}

    class FakeMember:
        kind = "member"
        function = None
        scope = "global"
        name = "fieldX"

    d4 = FakeMember()
    if (d4.kind == "variable" and not d4.function
            and d4.scope in ("global", "extern", "static")):
        nm_member["canonical_name"] = "should_not_be_set"

    check("member (struct field): no canonical_name", nm_member == {})

    # Unknown scope → NO canonical_name (not in the target set)
    nm_local_scope: Dict[str, Any] = {}

    class FakeLocalScope:
        kind = "variable"
        function = None
        scope = "local_static"  # not in ("global","extern","static")
        name = "ls_var"

    d5 = FakeLocalScope()
    if (d5.kind == "variable" and not d5.function
            and d5.scope in ("global", "extern", "static")):
        nm_local_scope["canonical_name"] = "should_not_be_set"

    check("local_static scope: no canonical_name", nm_local_scope == {})


# ===========================================================================
# SECTION 7 — Integration with real blueprints
# ===========================================================================

def test_s7_real_blueprint_dx740200() -> None:
    section("S7-A  Integration: dx740200.cpp.json — field aliases + seed strategies")
    if not BLUEPRINTS_AVAILABLE:
        skip("real blueprints", "output/asm/asm/ not available")
        return
    if not _require("cpp_lineage_utils") or not _require("blueprint_utils"):
        return

    bp = load_json(BLUEPRINT_DIR / "dx740200.cpp.json")
    aliases = bp.get("field_asm_aliases") or {}
    check("dx740200 has field_asm_aliases", len(aliases) > 0,
          f"{len(aliases)} entries")

    # Known alias pair
    check("Da7gl.cmSystem → WK_CMO", aliases.get("Da7gl.cmSystem") == "WK_CMO",
          str(aliases.get("Da7gl.cmSystem")))
    check("Da7gl.noOfLimits → WK_CNT", aliases.get("Da7gl.noOfLimits") == "WK_CNT",
          str(aliases.get("Da7gl.noOfLimits")))

    # Reverse map
    rev = reverse_field_alias_map(bp)
    check("reverse: WK_CMO → contains Da7gl.cmSystem",
          "Da7gl.cmSystem" in (rev.get("WK_CMO") or []), str(rev.get("WK_CMO")))

    gvl = bp.get("global_variable_lineage") or {}

    # Strategy 1: asm_alias metadata
    seeds_s1 = find_cpp_seed_nodes(gvl, "WK_CMO", {}, {})
    check("Strategy 1: WK_CMO found via asm_alias metadata",
          len(seeds_s1) > 0, str(seeds_s1[:3]))

    # Strategy 2: field alias path
    asm_aliases = extract_asm_field_aliases(bp, "WK_CMO")
    seeds_s2 = find_cpp_seed_nodes(gvl, "WK_CMO", asm_aliases, {})
    check("Strategy 2: WK_CMO seeds via field alias path",
          len(seeds_s2) > 0, str(seeds_s2[:3]))

    # Strategy 3: cpp_field_to_asm edges
    check("Strategy 3: cpp_field_to_asm edges present",
          any("cpp_field_to_asm" in str(e.get("expression", ""))
              for e in (gvl.get("edges") or [])))

    # TPF regs slots for DA78
    slots = extract_tpf_regs_slots(gvl, "DA78")
    check("TPF regs: DA78 has at least one slot",
          isinstance(slots, dict) and len(slots) >= 1,
          f"{len(slots)} slots: {sorted(slots.keys())}")


def test_s7_real_blueprint_tracer() -> None:
    section("S7-B  Integration: trace_cpp_variable_backward on real dx740200 seeds")
    if not BLUEPRINTS_AVAILABLE:
        skip("real blueprints", "output/asm/asm/ not available")
        return
    if not _require("cpp_lineage_utils") or not _require("cpp_backward_tracer") or not _require("blueprint_utils"):
        return

    bp = load_json(BLUEPRINT_DIR / "dx740200.cpp.json")
    gvl = bp.get("global_variable_lineage") or {}
    asm_aliases = extract_asm_field_aliases(bp, "WK_CMO")
    seeds = find_cpp_seed_nodes(gvl, "WK_CMO", asm_aliases, {})
    if not seeds:
        skip("tracer on real WK_CMO", "no seeds found — check blueprint")
        return

    res = trace_cpp_variable_backward_multi(seeds[:3], gvl, max_depth=6, max_nodes=500)
    check("multi-seed trace returns nodes",
          len(res.get("nodes") or []) > 0,
          f"{len(res.get('nodes', []))} nodes")
    check("multi-seed trace returns dep_vars",
          isinstance(res.get("dep_vars"), list),
          str(res.get("dep_vars", [])[:5]))


def test_s7_real_resolver_case_a() -> None:
    section("S7-C  Integration: VariableNameResolver Case A on real blueprints")
    if not BLUEPRINTS_AVAILABLE:
        skip("real blueprints", "output/asm/asm/ not available")
        return
    if not _require("variable_name_resolver"):
        return

    resolver = VariableNameResolver(BLUEPRINT_DIR)
    result = resolver.resolve("WK_CMO", "dx740200")
    check("Case A on real: WK_CMO → Da7gl.cmSystem (or similar)",
          result is not None and "cmsystem" in str(result or "").lower(),
          str(result))

    result2 = resolver.resolve("WK_CNT", "dx740200")
    check("Case A on real: WK_CNT → noOfLimits (or similar)",
          result2 is not None and "limits" in str(result2).lower(),
          str(result2))


def test_s7_chain_neighbor_set_real() -> None:
    section("S7-D  Integration: build_chain_neighbor_set with real call graph")
    if not CALL_GRAPH_PATH.exists():
        skip("real call graph", "output/file_call_graph.json not available")
        return
    if not _require("cpp_lineage_utils"):
        return

    # Known chain: lu82 → da76 → da78 → dx740200 → DA78
    chain = ["lu82", "da76", "dx740200"]
    ns = build_chain_neighbor_set(chain, CALL_GRAPH_PATH, max_hops=1)
    check("chain stems are in the neighbor set",
          all(s in ns for s in chain), str(sorted(ns)))
    check("da78 (direct neighbour of dx740200) is in set",
          "da78" in ns, str(sorted(ns)))
    check("neighbor set is larger than chain",
          len(ns) > len(chain), f"len(ns)={len(ns)}")


# ===========================================================================
# SECTION 8 — CPP-only tracking (no ASM interaction)
# ===========================================================================

def test_s8_cpp_only_tracking() -> None:
    section("S8  CPP-only variable tracking (no ASM interaction)")
    if not _require("cpp_backward_tracer"):
        return

    # Pure C++ variable flow: literal → local var → parameter → struct field
    gvl = {"nodes": [
        {"id": "literal:42", "kind": "literal", "name": "42"},
        {"id": "variable:countTx::counter", "kind": "variable",
         "name": "countTx::counter", "metadata": {}},
        {"id": "parameter:buildFn::count", "kind": "parameter",
         "name": "buildFn::count",
         "metadata": {"enclosing_function": "buildFn"}},
        {"id": "struct_field:buildFn::record->count", "kind": "struct_field",
         "name": "record->count", "metadata": {"enclosing_type": "Record"}},
    ], "edges": [
        {"source": "literal:42", "target": "variable:countTx::counter",
         "relation": "assign"},
        {"source": "variable:countTx::counter", "target": "parameter:buildFn::count",
         "relation": "arg_bind"},
        {"source": "parameter:buildFn::count",
         "target": "struct_field:buildFn::record->count",
         "relation": "assign"},
    ]}

    res = trace_cpp_variable_backward(
        "struct_field:buildFn::record->count", gvl, max_depth=8, max_nodes=100)
    node_ids = {n.get("id") for n in (res.get("nodes") or [])}
    check("CPP-only: struct field seed in result",
          "struct_field:buildFn::record->count" in node_ids, str(node_ids))
    check("CPP-only: parameter node in result",
          "parameter:buildFn::count" in node_ids, str(node_ids))
    check("CPP-only: variable node in result",
          "variable:countTx::counter" in node_ids, str(node_ids))
    check("CPP-only: literal terminal reached",
          "literal:42" in node_ids, str(node_ids))
    check("CPP-only: no bridge_registers (pure C++)",
          not (res.get("bridge_registers") or []))


def test_s8_cpp_only_dep_vars() -> None:
    section("S8-B  CPP-only: dep_vars collected from pure C++ trace")
    if not _require("cpp_backward_tracer"):
        return

    gvl = {"nodes": [
        {"id": "variable:fn::srcVar", "kind": "variable",
         "name": "fn::srcVar", "metadata": {}},
        {"id": "variable:fn::destVar", "kind": "variable",
         "name": "fn::destVar", "metadata": {}},
    ], "edges": [
        {"source": "variable:fn::srcVar", "target": "variable:fn::destVar",
         "relation": "assign"},
    ]}
    res = trace_cpp_variable_backward("variable:fn::destVar", gvl,
                                      max_depth=4, max_nodes=50)
    dep_vars = res.get("dep_vars") or []
    check("CPP-only dep_vars: srcVar surfaced",
          any("srcVar" in str(d) for d in dep_vars) or
          any("srcVar" in str(n.get("name", "")) for n in (res.get("nodes") or [])),
          f"dep_vars={dep_vars}")


def test_s8_cpp_multifile_arg_bind_resolver() -> None:
    section("S8-C  CPP-only: Case C resolves arg_bind across C++ files")
    if not _require("variable_name_resolver"):
        return

    import tempfile, msgpack
    tmp_dir = Path(tempfile.mkdtemp())

    # File A: calls file B's function with 'myVar' as first argument
    src_bp = {
        "field_asm_aliases": {},
        "global_variable_lineage": {
            "nodes": [
                {"id": "variable:funcA::myVar", "kind": "variable",
                 "name": "funcA::myVar", "metadata": {}},
            ],
            "edges": [
                {"source": "variable:funcA::myVar",
                 "target": "call_arg:processData#0",
                 "relation": "arg_bind"},
            ]
        }
    }
    # File B: processData's first parameter is 'inputData'
    tgt_bp = {
        "field_asm_aliases": {},
        "global_variable_lineage": {
            "nodes": [
                {"id": "parameter:processData::inputData",
                 "kind": "parameter", "name": "processData::inputData",
                 "metadata": {"enclosing_function": "processData"}},
            ],
            "edges": []
        }
    }
    (tmp_dir / "fileA.cpp.json").write_bytes(msgpack.packb(src_bp, use_bin_type=True))
    (tmp_dir / "fileB.cpp.json").write_bytes(msgpack.packb(tgt_bp, use_bin_type=True))

    resolver = VariableNameResolver(tmp_dir)
    result = resolver.resolve("myVar", "fileB", source_stem="fileA")
    check("Case C CPP-only: myVar → inputData via arg_bind", result == "inputData", str(result))


# ===========================================================================
# SECTION 9 — Mixed CPP+ASM tracking
# ===========================================================================

def test_s9_mixed_asm_alias_strategy1() -> None:
    section("S9-A  Mixed CPP+ASM: Strategy 1 asm_alias metadata → seed")
    if not _require("cpp_lineage_utils"):
        return

    gvl = {"nodes": [
        {"id": "struct_field:globalLimitsUpdate::da7gl->onlineSrcInd",
         "kind": "struct_field", "name": "da7gl->onlineSrcInd",
         "metadata": {"asm_alias": "LG1OSI", "enclosing_type": "Da7gl"}},
    ], "edges": []}

    seeds = find_cpp_seed_nodes(gvl, "LG1OSI", {}, {})
    check("ASM alias LG1OSI finds C++ struct_field node",
          any("onlineSrcInd" in s for s in seeds), str(seeds))


def test_s9_mixed_tpf_regs_and_tracer() -> None:
    section("S9-B  Mixed CPP+ASM: TPF regs slots + tracer bridge_registers")
    if not _require("cpp_lineage_utils") or not _require("cpp_backward_tracer"):
        return

    gvl = {"nodes": [
        {"id": "struct_field:f::regs.r7", "kind": "struct_field",
         "name": "regs.r7", "metadata": {}},
        {"id": "register:arg@DA78:R7", "kind": "register",
         "name": "arg@DA78:R7", "metadata": {}},
        {"id": "literal:'Y'", "kind": "literal", "name": "'Y'"},
    ], "edges": [
        {"source": "struct_field:f::regs.r7",
         "target": "register:arg@DA78:R7",
         "relation": "assign",
         "expression": "call buildLg1g1", "line": 76, "file": "dx740200.cpp"},
        {"source": "literal:'Y'",
         "target": "struct_field:f::regs.r7",
         "relation": "assign"},
    ]}

    tpf_slots = extract_tpf_regs_slots(gvl, "DA78")
    check("TPF slots: R7 found for DA78", "R7" in tpf_slots, str(list(tpf_slots.keys())))

    # Trace backward from R7 slot
    seeds = find_cpp_seed_nodes(gvl, "R7", {}, tpf_slots)
    check("Strategy 4: R7 seed found via tpf_slots", len(seeds) > 0, str(seeds))

    # Tracer finds the literal source
    if seeds:
        res = trace_cpp_variable_backward(seeds[0], gvl, max_depth=4, max_nodes=50)
        node_ids = {n.get("id") for n in (res.get("nodes") or [])}
        check("TPF tracer: literal terminal reached from R7 slot",
              "literal:'Y'" in node_ids, str(node_ids))


def test_s9_mixed_field_to_asm_stitch() -> None:
    section("S9-C  Mixed CPP+ASM: cpp_field_to_asm stitching → seed (Strategy 3)")
    if not _require("cpp_lineage_utils"):
        return

    gvl = {"nodes": [
        {"id": "struct_field:Da7gl.cmSystem",
         "kind": "struct_field", "name": "Da7gl.cmSystem",
         "metadata": {"alias_materialized": True, "asm_alias": "WK_CMO"}},
        {"id": "memory:WK_CMO", "kind": "memory", "name": "WK_CMO"},
    ], "edges": [
        {"source": "struct_field:Da7gl.cmSystem",
         "target": "memory:WK_CMO",
         "expression": "global_lineage_stitch:cpp_field_to_asm",
         "relation": "alias"},
    ]}

    seeds = find_cpp_seed_nodes(gvl, "WK_CMO", {}, {})
    check("Strategy 3: cpp_field_to_asm source found for WK_CMO",
          "struct_field:Da7gl.cmSystem" in seeds, str(seeds))


def test_s9_mixed_resolver_case_a_real() -> None:
    section("S9-D  Mixed CPP+ASM: VariableNameResolver Case A on real blueprints")
    if not BLUEPRINTS_AVAILABLE:
        skip("real blueprints", "output/asm/asm/ not available")
        return
    if not _require("variable_name_resolver"):
        return

    resolver = VariableNameResolver(BLUEPRINT_DIR)

    # ASM variables mapped to C++ fields in dx740200
    pairs = [
        ("WK_CMO", "cmSystem"),
        ("WK_CNT", "noOfLimits"),
        ("WK_DBL", "doubleWordWorkArea"),
    ]
    for asm_name, cpp_field_substr in pairs:
        result = resolver.resolve(asm_name, "dx740200")
        # Lowercase both the haystack and the needle before comparison
        result_lower = str(result or "").lower()
        needle_lower = cpp_field_substr.lower()
        check(f"Case A real: {asm_name} → contains '{cpp_field_substr}'",
              result is not None and needle_lower in result_lower,
              str(result))


# ===========================================================================
# SECTION 10 — Edge cases and graceful degradation
# ===========================================================================

def test_s10_graceful_degradation() -> None:
    section("S10  Edge cases and graceful degradation")
    if not _require("cpp_lineage_utils"):
        return

    # All functions handle empty dict gracefully (normal "nothing found" path)
    check("extract_asm_field_aliases: empty bp → empty",
          extract_asm_field_aliases({}, "X") == {})
    check("extract_tpf_regs_slots: empty gvl → empty",
          extract_tpf_regs_slots({}, "X") == {})
    check("find_cpp_seed_nodes: empty gvl → empty list",
          find_cpp_seed_nodes({}, "X", {}, {}) == [])

    # None blueprint is not a valid input; verify extract_asm_field_aliases
    # handles it safely via try/except (documents actual behaviour)
    try:
        r_none = extract_asm_field_aliases(None, "X")  # type: ignore
        check("extract_asm_field_aliases: None bp → empty (handles gracefully)",
              r_none == {}, str(r_none))
    except (AttributeError, TypeError):
        # None bp raises AttributeError in reverse_field_alias_map — document
        check("extract_asm_field_aliases: None bp → AttributeError (expected — None is not a valid blueprint)",
              True)

    # None gvl in extract_tpf_regs_slots (has explicit guard: `if not callee or not gvl`)
    r_none_gvl = extract_tpf_regs_slots(None, "X")  # type: ignore
    check("extract_tpf_regs_slots: None gvl → empty (guard handles it)",
          r_none_gvl == {}, str(r_none_gvl))

    # None gvl in find_cpp_seed_nodes
    try:
        r_seed_none = find_cpp_seed_nodes(None, "X", {}, {})  # type: ignore
        check("find_cpp_seed_nodes: None gvl → empty list (handles gracefully)",
              r_seed_none == [], str(r_seed_none))
    except (AttributeError, TypeError):
        check("find_cpp_seed_nodes: None gvl → AttributeError (expected — None is not a valid GVL)",
              True)

    if _require("cpp_backward_tracer"):
        # Missing seed node in GVL → empty-but-shaped result
        gvl_empty = {"nodes": [], "edges": []}
        res = trace_cpp_variable_backward("nonexistent:seed", gvl_empty,
                                          max_depth=4, max_nodes=100)
        # Tracer creates a synthetic "unknown" node for the seed even if absent from
        # the GVL (it records the starting point regardless). So nodes may have 1 entry.
        check("tracer: nonexistent seed → returns shaped result",
              isinstance(res.get("nodes"), list) and len(res.get("nodes", [])) <= 1,
              str(res))
        check("tracer: nonexistent seed → empty dep_vars",
              isinstance(res.get("dep_vars"), list), str(res))

    if _require("variable_name_resolver"):
        r = _make_resolver_no_blueprints()
        check("resolver: no blueprint dir → all cases return None",
              r.resolve("WK_CMO", "noFile") is None)
        check("resolver: empty variable → None",
              r.resolve("", "noFile") is None)

    check("extract_tpf_regs_slots: empty callee string → empty",
          extract_tpf_regs_slots({"nodes": [], "edges": []}, "") == {})
    check("find_cpp_files_for_dep_var: max_scan=0 always empty",
          find_cpp_files_for_dep_var("WK_CMO", Path("/tmp"), {}, max_scan=0) == [])


def test_s10_none_values_in_gvl() -> None:
    section("S10-B  Nodes with None metadata handled gracefully")
    if not _require("cpp_lineage_utils"):
        return

    # Nodes with None metadata (valid, can happen): id/name/metadata may be None
    # but the NODE itself is not None. Blueprints never produce None node entries.
    gvl_null_meta = {"nodes": [
        {"id": None, "kind": "struct_field", "name": None, "metadata": None},
        {"id": "struct_field:f::cmSystem", "kind": "struct_field",
         "name": "cmSystem", "metadata": {"asm_alias": "WK_CMO"}},
    ], "edges": [
        {"source": None, "target": "struct_field:f::cmSystem", "relation": "assign"},
    ]}
    try:
        seeds = find_cpp_seed_nodes(gvl_null_meta, "WK_CMO", {}, {})
        check("None id/name/metadata in nodes do not raise", True, f"seeds: {seeds}")
        check("Valid node found despite null-field neighbours",
              "struct_field:f::cmSystem" in seeds, str(seeds))
    except Exception as exc:
        check("None id/name/metadata in nodes do not raise", False, str(exc))

    # None NODE entries (list contains None) — this is NOT a valid blueprint format,
    # but we document that the code raises AttributeError in this case.
    gvl_none_node = {"nodes": [None, {"id": "struct_field:f::cmSystem",
                                      "kind": "struct_field", "name": "cmSystem",
                                      "metadata": {"asm_alias": "WK_CMO"}}],
                     "edges": []}
    try:
        find_cpp_seed_nodes(gvl_none_node, "WK_CMO", {}, {})
        check("None NODE entry in list: handled or raises (None nodes are not valid blueprint data)",
              True)
    except (AttributeError, TypeError):
        check("None NODE entry raises AttributeError (expected — None nodes never occur in real blueprints)",
              True)


# ===========================================================================
# SECTION 11 — FIX 9: Strategy 3 exact suffix guard
# ===========================================================================

def test_s11_fix9_exact_suffix() -> None:
    section("S11  FIX 9: Strategy 3 exact terminal suffix (no false positives)")
    if not _require("cpp_lineage_utils"):
        return

    # Test that short var name "R7" doesn't match "R7G_STORE" or "WK_R7"
    gvl = {"nodes": [
        {"id": "struct_field:f::fieldA", "kind": "struct_field",
         "name": "fieldA", "metadata": {}},
        {"id": "struct_field:f::fieldB", "kind": "struct_field",
         "name": "fieldB", "metadata": {}},
        {"id": "struct_field:f::fieldC", "kind": "struct_field",
         "name": "fieldC", "metadata": {}},
    ], "edges": [
        # target terminal is R7G — NOT R7
        {"source": "struct_field:f::fieldA", "target": "memory:R7G",
         "expression": "global_lineage_stitch:cpp_field_to_asm", "relation": "alias"},
        # target terminal is WK_R7 — NOT R7
        {"source": "struct_field:f::fieldB", "target": "memory:WK_R7",
         "expression": "global_lineage_stitch:cpp_field_to_asm", "relation": "alias"},
        # Exact match: target terminal IS R7
        {"source": "struct_field:f::fieldC", "target": "memory:R7",
         "expression": "global_lineage_stitch:cpp_field_to_asm", "relation": "alias"},
    ]}
    seeds = find_cpp_seed_nodes(gvl, "R7", {}, {})
    check("FIX 9: R7G target does NOT match R7 variable", "struct_field:f::fieldA" not in seeds)
    check("FIX 9: WK_R7 target does NOT match R7 variable", "struct_field:f::fieldB" not in seeds)
    check("FIX 9: exact R7 target DOES match R7 variable", "struct_field:f::fieldC" in seeds)


# ===========================================================================
# SECTION 12 — FIX 21: struct field via any pointer variable name
# ===========================================================================

def test_s12_fix21_any_pointer_name() -> None:
    section("S12  FIX 21: Strategy 5 matches field regardless of pointer variable name")
    if not _require("cpp_lineage_utils"):
        return

    gvl = {"nodes": [
        # Same field (cmSystem) but accessed via different pointer variables
        {"id": "struct_field:funcA::da7gl->cmSystem",
         "kind": "struct_field", "name": "da7gl->cmSystem", "metadata": {}},
        {"id": "struct_field:funcB::record->cmSystem",
         "kind": "struct_field", "name": "record->cmSystem", "metadata": {}},
        {"id": "struct_field:funcC::ptr->cmSystem",
         "kind": "struct_field", "name": "ptr->cmSystem", "metadata": {}},
        # Different field — should NOT match
        {"id": "struct_field:funcD::da7gl->OTHER",
         "kind": "struct_field", "name": "da7gl->OTHER", "metadata": {}},
    ], "edges": []}

    seeds = find_cpp_seed_nodes(gvl, "cmSystem", {}, {})
    check("FIX 21: da7gl->cmSystem found", "struct_field:funcA::da7gl->cmSystem" in seeds)
    check("FIX 21: record->cmSystem found", "struct_field:funcB::record->cmSystem" in seeds)
    check("FIX 21: ptr->cmSystem found", "struct_field:funcC::ptr->cmSystem" in seeds)
    check("FIX 21: different field name NOT found",
          "struct_field:funcD::da7gl->OTHER" not in seeds, str(seeds))


# ===========================================================================
# SECTION 13 — Cross-file bridge helpers
# ===========================================================================

def test_s13_bridge_helpers() -> None:
    section("S13  Cross-file bridge: find_cpp_to_asm_callers")
    if not BLUEPRINTS_AVAILABLE:
        skip("bridge helpers", "output/asm/asm/ not available")
        return

    try:
        from backward_traversal.bridge.cross_file_bridge_backward import (
            find_cpp_to_asm_callers,
            find_asm_callers,
            find_asm_to_cpp_callers,
        )
    except Exception as exc:
        skip("bridge helpers import", str(exc))
        return

    # dx740200 (C++) calls da78 (ASM)
    call_sites = find_cpp_to_asm_callers("dx740200", "da78", BLUEPRINT_DIR)
    check("find_cpp_to_asm_callers: dx740200→da78 returns list",
          isinstance(call_sites, list), str(type(call_sites)))
    check("find_cpp_to_asm_callers: at least one call site found",
          len(call_sites) > 0,
          f"{len(call_sites)} sites found")

    if call_sites:
        site = call_sites[0]
        check("call site has 'function' key", "function" in site, str(list(site.keys())))
        check("call site has 'line' key", "line" in site, str(list(site.keys())))

    # Non-existent pair → empty list (graceful)
    empty = find_cpp_to_asm_callers("dx740200", "NONEXISTENT", BLUEPRINT_DIR)
    check("find_cpp_to_asm_callers: non-existent callee → empty list",
          empty == [], str(empty))


def test_s13_asm_callers() -> None:
    section("S13-B  Cross-file bridge: find_asm_callers (ASM→ASM)")
    if not BLUEPRINTS_AVAILABLE:
        skip("ASM bridge helpers", "output/asm/asm/ not available")
        return

    try:
        from backward_traversal.bridge.cross_file_bridge_backward import find_asm_callers
    except Exception as exc:
        skip("find_asm_callers import", str(exc))
        return

    # xh80 (ASM) calls xh71 (ASM) per call graph
    sites = find_asm_callers("xh80", "xh71", BLUEPRINT_DIR)
    check("find_asm_callers: returns list", isinstance(sites, list))
    # Result may be empty if call graph edges show it differently
    if sites:
        check("ASM call site has 'routine' key",
              "routine" in sites[0], str(list(sites[0].keys())))

    # Non-existent pair
    empty = find_asm_callers("da78", "NONEXISTENT999", BLUEPRINT_DIR)
    check("find_asm_callers: non-existent pair → empty", empty == [], str(empty))


# ===========================================================================
# SECTION 14 — _build_struct_canonical_map
# ===========================================================================

def test_s14_struct_canonical_map() -> None:
    section("S14  _build_struct_canonical_map helper (T11 backbone)")
    if not _require("cpp_lineage_utils"):
        return

    gvl = {"nodes": [
        {"id": "struct_field:funcA::da7gl->cmSystem",
         "kind": "struct_field", "name": "da7gl->cmSystem",
         "metadata": {"enclosing_type": "Da7gl"}},
        {"id": "struct_field:funcA::da7gl->noOfLimits",
         "kind": "struct_field", "name": "da7gl->noOfLimits",
         "metadata": {"enclosing_type": "Da7gl"}},
        {"id": "struct_field:funcB::rec->onlineSrcInd",
         "kind": "struct_field", "name": "rec->onlineSrcInd",
         "metadata": {"enclosing_type": "CasGLRec"}},
        # No enclosing_type — must be excluded
        {"id": "struct_field:funcC::ptr->unknownField",
         "kind": "struct_field", "name": "ptr->unknownField",
         "metadata": {}},
        # Not a struct_field kind
        {"id": "variable:f::someVar",
         "kind": "variable", "name": "someVar", "metadata": {"enclosing_type": "Foo"}},
    ], "edges": []}

    cmap = _build_struct_canonical_map(gvl)
    check("canonical map: (da7gl, cmsystem) → has entry",
          ("da7gl", "cmsystem") in cmap,
          str(list(cmap.keys())[:5]))
    check("canonical map: (da7gl, nooflimits) → has entry",
          ("da7gl", "nooflimits") in cmap)
    check("canonical map: (casglrec, onlinesrcind) → has entry",
          ("casglrec", "onlinesrcind") in cmap)
    check("canonical map: no enclosing_type → excluded",
          ("", "unknownfield") not in cmap)
    check("canonical map: variable kind → excluded",
          ("foo", "somevar") not in cmap)

    # Multiple nodes for same (type, field)
    gvl2 = {"nodes": [
        {"id": "struct_field:fA::da7gl->cmSystem",
         "kind": "struct_field", "name": "da7gl->cmSystem",
         "metadata": {"enclosing_type": "Da7gl"}},
        {"id": "struct_field:fB::da7gl->cmSystem",
         "kind": "struct_field", "name": "da7gl->cmSystem",
         "metadata": {"enclosing_type": "Da7gl"}},
    ], "edges": []}
    cmap2 = _build_struct_canonical_map(gvl2)
    ids = cmap2.get(("da7gl", "cmsystem"), [])
    check("canonical map: multiple nodes for same key → list of IDs",
          len(ids) == 2, f"ids={ids}")


# ===========================================================================
# Main runner
# ===========================================================================

def main() -> int:
    print("=" * 78)
    print("  C++ Variable Tracking — Exhaustive Test Suite")
    print("=" * 78)
    print(f"  Blueprint dir: {BLUEPRINT_DIR}")
    print(f"  Blueprints available: {BLUEPRINTS_AVAILABLE}")
    for mod, err in IMPORT_ERRORS.items():
        status = "OK" if not err else f"FAILED: {err}"
        print(f"  Import {mod}: {status}")
    print()

    # --- run all tests ---
    test_s1_reverse_field_alias_map()
    test_s1_extract_asm_field_aliases()
    test_s1_extract_tpf_regs_slots()
    test_s1_find_cpp_seed_nodes_all_strategies()

    test_s2_tracer_basic()
    test_s2_tracer_register_bridge()
    test_s2_tracer_cycle_prevention()
    test_s2_tracer_depth_and_node_caps()
    test_s2_tracer_multi()
    test_s2_tracer_stitching_edge_skipped()

    test_s3_parse_arg_bind_target()
    test_s3_resolver_case_a_asm_to_cpp()
    test_s3_resolver_case_b_cpp_to_asm()
    test_s3_resolver_case_c_arg_bind()
    test_s3_resolver_case_d_struct_canonical()
    test_s3_resolver_case_d_ext_t12()
    test_s3_resolver_resolution_order()
    test_s3_resolver_cache()

    test_s4_chain_neighbor_set()
    test_s5_find_cpp_files_for_dep_var()
    test_s6_t12_canonical_name_emission()

    test_s7_real_blueprint_dx740200()
    test_s7_real_blueprint_tracer()
    test_s7_real_resolver_case_a()
    test_s7_chain_neighbor_set_real()

    test_s8_cpp_only_tracking()
    test_s8_cpp_only_dep_vars()
    test_s8_cpp_multifile_arg_bind_resolver()

    test_s9_mixed_asm_alias_strategy1()
    test_s9_mixed_tpf_regs_and_tracer()
    test_s9_mixed_field_to_asm_stitch()
    test_s9_mixed_resolver_case_a_real()

    test_s10_graceful_degradation()
    test_s10_none_values_in_gvl()

    test_s11_fix9_exact_suffix()
    test_s12_fix21_any_pointer_name()

    test_s13_bridge_helpers()
    test_s13_asm_callers()

    test_s14_struct_canonical_map()

    # --- summary ---
    print("\n" + "=" * 78)
    passed  = sum(1 for r in RESULTS if r[0] == "PASS")
    failed  = sum(1 for r in RESULTS if r[0] == "FAIL")
    skipped = sum(1 for r in RESULTS if r[0] == "SKIP")
    total   = len(RESULTS)
    print(f"  RESULTS: {passed} PASS / {failed} FAIL / {skipped} SKIP   (total {total})")
    print("=" * 78)

    if failed:
        print("\n  FAILURES:")
        for status, label, detail in RESULTS:
            if status == "FAIL":
                tail = f"\n      detail: {detail[:200]}" if detail else ""
                print(f"  ✗  {label}{tail}")
    print()
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
