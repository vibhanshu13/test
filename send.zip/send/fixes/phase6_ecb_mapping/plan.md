# Phase 6 — ECB Control-Block Mapping

**Status:** NOT STARTED.
**Source plan:** `docs/plans/2026-04-23-cpp-variable-lineage-strategy 1.md` §3.5, §6.6.
**Depends on:** Phase 5 (commit `10eca53`). Independent of Phase 5b.

---

## 1. Problem

The z/TPF runtime exposes a process-wide control block (ECB) that is the
primary inter-module data-sharing mechanism. C++ accesses it as a struct:

```cpp
regs.r7 = (int)  ecbptr()->ce1cr7;    // level-7 work block pointer
regs.r2 = (long) ecbptr()->ce1cr0;    // level-0 BCIS pointer
L7e7e* ccr = (L7e7e*) ecbptr()->ce1cr2;
ecbptr()->ebsw01 = 0x00;              // ECB switch byte
*(int*) ecbptr()->ce1usa = counter;
```

ASM accesses the same bytes by DSECT name:

```asm
         L     R7,CE1CR7
         ST    R0,CE1USA
         MVI   EBSW01,X'00'
```

The equivalence `ecbptr()->ce1crN` ↔ ASM `CE1CRN` is a **well-known,
stable z/TPF convention** — a hard-coded mapping table can cover it.
Today this mapping is not represented in the lineage graph, so a trace
through an ECB slot on one side cannot follow it to the other.

---

## 2. What Phase 6 adds

Two concrete artefacts:

1. **A canonical ECB-alias table** shipped in the repo, mapping every
   well-known `ecbptr()->FIELD` to its ASM counterpart. This is static
   metadata — not inferred from the corpus, but transcribed from the TPF
   control-block layout.

2. **A new stitcher** (`_stitch_ecb_field_bindings`) that, for every C++
   `struct_field` node whose `target_field` matches a table key, attaches
   `ecb_alias` metadata and creates a cross-language alias edge to the
   corresponding ASM `memory:` node **if that node exists in the merged
   graph**. Mirrors the Phase-4 behaviour for cc*.hpp field aliases.

---

## 3. The mapping table

Starter set, drawn from the plan §3.5 examples plus the tokens seen in
the local corpus. Values follow the z/TPF ECB layout convention: C field
name lowercase, ASM name uppercase.

```python
ECB_FIELD_TO_ASM = {
    # Level control registers (level 0..F)
    "ce1cr0":  "CE1CR0",
    "ce1cr1":  "CE1CR1",
    "ce1cr2":  "CE1CR2",
    "ce1cr3":  "CE1CR3",
    "ce1cr4":  "CE1CR4",
    "ce1cr5":  "CE1CR5",
    "ce1cr6":  "CE1CR6",
    "ce1cr7":  "CE1CR7",
    "ce1cr8":  "CE1CR8",
    "ce1cr9":  "CE1CR9",
    "ce1cra":  "CE1CRA",
    "ce1crb":  "CE1CRB",
    "ce1crc":  "CE1CRC",
    "ce1crd":  "CE1CRD",
    "ce1cre":  "CE1CRE",
    "ce1crf":  "CE1CRF",
    # User save area + app area + switches
    "ce1usa":  "CE1USA",
    "ce1app":  "CE1APP",
    "ebsw00":  "EBSW00",
    "ebsw01":  "EBSW01",
    "ebsw02":  "EBSW02",
    "ebsw03":  "EBSW03",
    # Return reason code + common work register slots
    "ce1rrc":  "CE1RRC",
    "ebr00":   "EBR00",
    "ebr01":   "EBR01",
    "ebr02":   "EBR02",
    "ebr03":   "EBR03",
}
```

The table lives in `passes/ecb_alias_table.py`. It is deliberately static
— extending it is a one-line code change.

---

## 4. Stitcher behaviour

Add `_stitch_ecb_field_bindings(self, contexts)` to
`passes/global_lineage_stitcher.py`. Hook it into `process_contexts`
right after `_stitch_asm_alias_struct_fields` (so Phase-4 edges land
first). Logic — mirrors Phase 4:

```
for node in global_graph.nodes.values():
    if node.kind != "struct_field":
        continue
    # Node name patterns include "ecbptr::ce1cr7" or
    # "funcName::ecbptr->ce1cr7" — extract the final field token.
    tail = node.name.split("::")[-1]
    for sep in ("->", "."):
        tail = tail.split(sep)[-1]
    tail = tail.lstrip("*").lower()
    asm_name = ECB_FIELD_TO_ASM.get(tail)
    if not asm_name:
        continue

    # Annotate the C++ node (even if no ASM memory node exists).
    graph.annotate_node(node.name, "struct_field",
                        ecb_alias=asm_name,
                        alias_type="cpp_ecb_to_asm")

    # Create a scoped alias edge only when the ASM memory node exists.
    if global_graph.get_node_id(asm_name, "memory"):
        graph.add_alias(node.name, "struct_field",
                        asm_name, "memory",
                        file="(ecb_alias_table)",
                        line=0,
                        expression="global_lineage_stitch:cpp_ecb_to_asm",
                        scope=node.name.split("::", 1)[0] if "::" in node.name else None,
                        statement_id="GLOBAL_STITCH_ECB",
                        macro_expansion_parent=None)
```

Same idempotence pattern as Phase 4 — maintain a `seen` set to avoid
duplicate edges across runs.

---

## 5. Files touched

| File | Change |
|---|---|
| `passes/ecb_alias_table.py` | **New** — `ECB_FIELD_TO_ASM` constant dict. |
| `passes/global_lineage_stitcher.py` | Import the table; add `_stitch_ecb_field_bindings`; call from `process_contexts`. |

No parser / model / emitter / tracer changes — all plumbing already
exists. This phase is essentially "use the table we didn't have."

---

## 6. Verification

Test: `fixes/phase6_ecb_mapping/test_ecb_mapping.py`.

### 6.1 Table coverage
- `ECB_FIELD_TO_ASM` contains at minimum: `ce1cr0..ce1crf`, `ce1usa`,
  `ebsw01`.

### 6.2 Synthetic stitching
Build a synthetic merged graph containing:
- C++ node `struct_field:globalLimitsUpdate::ecbptr->ce1cr7` (from a
  hypothetical `regs.r7 = (int) ecbptr()->ce1cr7;`).
- ASM node `memory:CE1CR7` (from a synthetic ASM blueprint's
  variable_lineage).

Run `GlobalLineageStitcher().process_contexts({...})`. Assert:
- Node metadata on the C++ node gains `ecb_alias=CE1CR7` and
  `alias_type=cpp_ecb_to_asm`.
- One alias edge exists with `source=struct_field:globalLimitsUpdate::ecbptr->ce1cr7`,
  `target=memory:CE1CR7`, `expression="global_lineage_stitch:cpp_ecb_to_asm"`.

### 6.3 Negative — no matching ASM node
Same C++ node, but the ASM graph has no `memory:CE1CR7`. Assert:
- Node metadata still has `ecb_alias=CE1CR7` (documentation preserved).
- Zero new alias edges.

### 6.4 Negative — non-ECB struct field
C++ node `struct_field:f::somevar->x`. Assert no change.

### 6.5 Idempotence
Run `process_contexts` twice. Assert edge count stays the same.

### 6.6 Regression
Phases 1-5 (and 5b if already landed) tests all PASS.

---

## 7. Resume

1. Read this plan.
2. Baseline: `python3 fixes/phase6_ecb_mapping/test_ecb_mapping.py` — expect FAIL on table import and stitching assertions.
3. Write `passes/ecb_alias_table.py` (5 lines of imports + the dict).
4. Patch `passes/global_lineage_stitcher.py` — one new method + one call site.
5. Re-run test — expect PASS.
6. Commit; update `fixes/README.md`.
