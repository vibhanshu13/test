#!/usr/bin/env python3
"""Phase 6 verification — ECB control-block mapping.

Usage:
    python3 fixes/phase6_ecb_mapping/test_ecb_mapping.py
"""
from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO_ROOT))

from models.analysis_context import AnalysisContext  # noqa: E402
from models.variable_lineage import VariableLineageGraph  # noqa: E402


RESULTS: list[tuple[str, str, str]] = []


def check(label: str, cond: bool, detail: str = "") -> None:
    status = "PASS" if cond else "FAIL"
    RESULTS.append((status, label, detail))
    tail = f"   — {detail}" if detail else ""
    print(f"  {status}   {label}{tail}")


def _ctx_with_graph(graph: VariableLineageGraph) -> AnalysisContext:
    ctx = AnalysisContext(file_path=Path("fake.json"))
    ctx.add_metadata("variable_lineage", graph)
    return ctx


# ---------------------------------------------------------------------------
# 6.1 Table coverage
# ---------------------------------------------------------------------------

def test_table_coverage() -> None:
    print("\n" + "=" * 78)
    print("6.1  ECB_FIELD_TO_ASM table coverage")
    print("=" * 78)
    try:
        from passes.ecb_alias_table import ECB_FIELD_TO_ASM
    except ImportError as exc:
        check("ECB_FIELD_TO_ASM importable", False, detail=str(exc))
        return
    check("ECB_FIELD_TO_ASM importable", True)
    required = ["ce1cr0", "ce1cr7", "ce1crf", "ce1usa", "ebsw01"]
    for k in required:
        check(f"{k} present in table",
              k in ECB_FIELD_TO_ASM,
              detail=f"value={ECB_FIELD_TO_ASM.get(k)}")
    # Uppercase value convention
    bad = [k for k, v in ECB_FIELD_TO_ASM.items() if v != v.upper()]
    check("all ASM names uppercase", not bad, detail=f"lowercase={bad}")


# ---------------------------------------------------------------------------
# 6.2 Synthetic positive — C++ ECB access + matching ASM memory node
# ---------------------------------------------------------------------------

def test_positive_stitch() -> None:
    print("\n" + "=" * 78)
    print("6.2  Positive: cpp ecbptr->ce1cr7 ↔ memory:CE1CR7")
    print("=" * 78)
    # Build a cpp context whose variable_lineage has the ECB struct_field.
    cpp_g = VariableLineageGraph()
    cpp_g.add_definition("globalLimitsUpdate::ecbptr->ce1cr7", "struct_field",
                         file="dx740200.cpp", line=1, expression="regs.r7 = ecbptr()->ce1cr7;",
                         scope="globalLimitsUpdate", statement_id="C_1", macro_expansion_parent=None)
    # ASM context: a synthetic blueprint whose graph has CE1CR7 as memory node.
    asm_g = VariableLineageGraph()
    asm_g.add_definition("CE1CR7", "memory",
                         file="da78.asm", line=1, expression="L R7,CE1CR7",
                         scope="DA78", statement_id="A_1", macro_expansion_parent=None)

    contexts = {
        "dx740200.cpp.json": _ctx_with_graph(cpp_g),
        "da78.asm.json":     _ctx_with_graph(asm_g),
    }
    from passes.global_lineage_stitcher import GlobalLineageStitcher
    stitcher = GlobalLineageStitcher()
    stitcher.process_contexts(contexts)

    gg = stitcher.global_graph
    # Locate the C++ node in global graph and inspect metadata.
    cpp_node = next(
        (n for n in gg.nodes.values()
         if n.kind == "struct_field"
         and n.name == "globalLimitsUpdate::ecbptr->ce1cr7"),
        None,
    )
    check("cpp struct_field node exists in global graph", cpp_node is not None)
    if cpp_node:
        md = cpp_node.metadata or {}
        check("metadata.ecb_alias == 'CE1CR7'",
              md.get("ecb_alias") == "CE1CR7", detail=f"md={md}")
        check("metadata.alias_type == 'cpp_ecb_to_asm'",
              md.get("alias_type") == "cpp_ecb_to_asm")
    # Alias edge must exist
    cpp_to_asm = [
        e for e in gg.edges
        if e.relation == "alias"
        and (e.expression or "") == "global_lineage_stitch:cpp_ecb_to_asm"
    ]
    check("exactly 1 cpp_ecb_to_asm alias edge",
          len(cpp_to_asm) == 1, detail=f"count={len(cpp_to_asm)}")
    if cpp_to_asm:
        e = cpp_to_asm[0]
        check("edge targets memory:CE1CR7", "CE1CR7" in str(e.target))


# ---------------------------------------------------------------------------
# 6.3 Negative — ECB field present in C++ but no matching ASM node
# ---------------------------------------------------------------------------

def test_negative_no_asm_node() -> None:
    print("\n" + "=" * 78)
    print("6.3  Negative: cpp ECB field but no ASM memory node")
    print("=" * 78)
    cpp_g = VariableLineageGraph()
    cpp_g.add_definition("f::ecbptr->ce1cr3", "struct_field",
                         file="t.cpp", line=1, expression="x = ecbptr()->ce1cr3;",
                         scope="f", statement_id="C_1", macro_expansion_parent=None)
    contexts = {"t.cpp.json": _ctx_with_graph(cpp_g)}
    from passes.global_lineage_stitcher import GlobalLineageStitcher
    stitcher = GlobalLineageStitcher()
    stitcher.process_contexts(contexts)
    gg = stitcher.global_graph
    cpp_node = next(
        (n for n in gg.nodes.values()
         if n.kind == "struct_field"
         and n.name == "f::ecbptr->ce1cr3"),
        None,
    )
    check("cpp node exists", cpp_node is not None)
    if cpp_node:
        md = cpp_node.metadata or {}
        check("ecb_alias metadata preserved (documentation)",
              md.get("ecb_alias") == "CE1CR3", detail=f"md={md}")
    dangling = [
        e for e in gg.edges
        if e.relation == "alias"
        and (e.expression or "") == "global_lineage_stitch:cpp_ecb_to_asm"
    ]
    check("no dangling alias edge when ASM node missing",
          len(dangling) == 0, detail=f"count={len(dangling)}")


# ---------------------------------------------------------------------------
# 6.4 Negative — non-ECB struct field untouched
# ---------------------------------------------------------------------------

def test_non_ecb_unchanged() -> None:
    print("\n" + "=" * 78)
    print("6.4  Negative: non-ECB struct field untouched")
    print("=" * 78)
    cpp_g = VariableLineageGraph()
    cpp_g.add_definition("f::somevar->fieldA", "struct_field",
                         file="t.cpp", line=1, expression="somevar->fieldA = 0;",
                         scope="f", statement_id="C_1", macro_expansion_parent=None)
    contexts = {"t.cpp.json": _ctx_with_graph(cpp_g)}
    from passes.global_lineage_stitcher import GlobalLineageStitcher
    stitcher = GlobalLineageStitcher()
    stitcher.process_contexts(contexts)
    gg = stitcher.global_graph
    n = next((x for x in gg.nodes.values() if x.name == "f::somevar->fieldA"), None)
    check("non-ECB node present", n is not None)
    if n:
        md = n.metadata or {}
        check("no ecb_alias stamped on non-ECB field",
              "ecb_alias" not in md, detail=f"md={md}")


# ---------------------------------------------------------------------------
# 6.5 Idempotence
# ---------------------------------------------------------------------------

def test_idempotence() -> None:
    print("\n" + "=" * 78)
    print("6.5  Idempotence: two runs → same edge count")
    print("=" * 78)
    cpp_g = VariableLineageGraph()
    cpp_g.add_definition("f::ecbptr->ce1cr0", "struct_field",
                         file="t.cpp", line=1, expression="...",
                         scope="f", statement_id="C_1", macro_expansion_parent=None)
    asm_g = VariableLineageGraph()
    asm_g.add_definition("CE1CR0", "memory",
                         file="a.asm", line=1, expression="...",
                         scope="R", statement_id="A_1", macro_expansion_parent=None)
    contexts = {"t.cpp.json": _ctx_with_graph(cpp_g),
                "a.asm.json": _ctx_with_graph(asm_g)}
    from passes.global_lineage_stitcher import GlobalLineageStitcher

    stitcher = GlobalLineageStitcher()
    stitcher.process_contexts(contexts)
    first = sum(
        1 for e in stitcher.global_graph.edges
        if e.relation == "alias"
        and (e.expression or "") == "global_lineage_stitch:cpp_ecb_to_asm"
    )
    stitcher.process_contexts(contexts)
    second = sum(
        1 for e in stitcher.global_graph.edges
        if e.relation == "alias"
        and (e.expression or "") == "global_lineage_stitch:cpp_ecb_to_asm"
    )
    check("idempotent alias edge count", first == second,
          detail=f"first={first} second={second}")


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def main() -> int:
    tests = [
        test_table_coverage,
        test_positive_stitch,
        test_negative_no_asm_node,
        test_non_ecb_unchanged,
        test_idempotence,
    ]
    for t in tests:
        try:
            t()
        except Exception as exc:
            RESULTS.append(("FAIL", t.__name__, f"raised {type(exc).__name__}: {exc}"))
            print(f"  FAIL   {t.__name__} raised {exc!r}")

    fails = [r for r in RESULTS if r[0] == "FAIL"]
    print("\n" + "=" * 78)
    if fails:
        print(f">>> PHASE 6: {len(fails)}/{len(RESULTS)} FAILED.")
        for _, lbl, detail in fails:
            print(f"    - {lbl}  {detail}")
        return 1
    print(f">>> PHASE 6: ALL {len(RESULTS)} CHECKS PASSED.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
