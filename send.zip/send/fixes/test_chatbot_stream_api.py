#!/usr/bin/env python3
"""Validation tests for POST .../chatbot/stream (streaming SSE endpoint).

Tests verify:
  1. Auth / routing (401, 403, 404, 422)
  2. SSE event contract — chunk events, done event with cm- msg_id, full text, created_at
  3. Persistence — user message pre-saved, bot message post-saved, stable cm- msg_ids
  4. GET /chatbot returns cm- prefixed ids for streamed messages
  5. Multi-turn — second call appends 2 messages, no duplication
"""
from __future__ import annotations

import json
import shutil
import sys
import uuid
from pathlib import Path
from typing import Any, Dict, List
from unittest import mock

import msgpack
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from api.app import app  # noqa: E402
from api.auth import create_access_token, hash_password  # noqa: E402
from api.config import settings  # noqa: E402
from api.db import SessionLocal, create_tables  # noqa: E402
from api.models.knowledge_base import KnowledgeBase, KnowledgeBaseAccess  # noqa: E402
from api.models.user import User  # noqa: E402
from api.storage.workspace import WorkspaceManager  # noqa: E402

# ---------------------------------------------------------------------------
# Test accounting
# ---------------------------------------------------------------------------

PASS = 0
FAIL = 0
_CREATED_KBS: List[str] = []
_CREATED_USERS: List[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS  {name}" + (f"  [{detail}]" if detail else ""))
    else:
        FAIL += 1
        print(f"  FAIL  {name}" + (f"  [{detail}]" if detail else ""))


# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------

def _create_user(db, username: str, role: str = "user") -> User:
    user = User(
        username=username,
        hashed_password=hash_password("TestPass123!"),
        role=role,
        is_active=True,
    )
    db.add(user)
    _CREATED_USERS.append(username)
    return user


def _create_kb(
    db, kb_id: str, *, status: str = "success", created_by: str = "admin"
) -> KnowledgeBase:
    kb = KnowledgeBase(
        id=kb_id,
        name=f"ChatStream Test {kb_id[:8]}",
        created_by=created_by,
        datasource_username=None,
        datasource_folder=None,
        source_path="/tmp/src",
        status=status,
        error=None,
    )
    db.add(kb)
    _CREATED_KBS.append(kb_id)
    return kb


def _auth_headers(username: str, role: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {create_access_token(username, role)}"}


def _prepare_kb(db, admin_username: str) -> str:
    kb_id = str(uuid.uuid4())
    _create_kb(db, kb_id, status="success", created_by=admin_username)
    db.commit()
    ws = WorkspaceManager(kb_id)
    for d in (ws.root, ws.input_dir, ws.output_dir, ws.cache_dir):
        d.mkdir(parents=True, exist_ok=True)
    return kb_id


def _write_conversation(
    kb_id: str,
    conv_id: str,
    *,
    root_variable: str = "LG1OSI",
    chat_session_id: str | None = None,
) -> None:
    """Write a minimal conversation msgpack file for chatbot testing."""
    conv_dir = WorkspaceManager(kb_id).output_dir / "conversations"
    conv_dir.mkdir(parents=True, exist_ok=True)
    conv: Dict[str, Any] = {
        "version": 1,
        "conv_id": conv_id,
        "process": "lu82",
        "keyword": root_variable,
        "backward_session_id": None,
        "root_variable": root_variable,
        "selected_chain": [],
        "keyword_file_flows": [],
        "messages": [],
        "chat_session_id": chat_session_id,
        "created_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-01T00:00:00+00:00",
    }
    (conv_dir / f"{conv_id}.msgpack").write_bytes(msgpack.packb(conv, use_bin_type=True))


def _parse_sse(content: str) -> List[Dict[str, Any]]:
    """Parse SSE data lines from a full response body into a list of JSON dicts."""
    events: List[Dict[str, Any]] = []
    for line in content.splitlines():
        line = line.strip()
        if line.startswith("data:"):
            payload = line[5:].strip()
            try:
                events.append(json.loads(payload))
            except json.JSONDecodeError:
                pass
    return events


def _load_conv(kb_id: str, conv_id: str) -> Dict[str, Any]:
    path = WorkspaceManager(kb_id).output_dir / "conversations" / f"{conv_id}.msgpack"
    return msgpack.unpackb(path.read_bytes(), raw=False)


def _load_chat_session(kb_id: str, chat_session_id: str) -> Dict[str, Any]:
    path = (
        settings.JOBS_BASE_DIR
        / kb_id
        / "output"
        / "chat_sessions"
        / f"{chat_session_id}.msgpack"
    )
    return msgpack.unpackb(path.read_bytes(), raw=False)


# Controlled LLM output — four chunks whose concatenation is the full reply
_CHUNKS: List[str] = ["What ", "does ", "LG1OSI ", "mean? It is a key variable."]
_FULL_REPLY: str = "".join(_CHUNKS)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_auth_and_routing(
    client: TestClient,
    admin_headers: Dict[str, str],
    user_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("1. auth + routing")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/chatbot/stream"

        # Unauthenticated
        resp = client.post(url, json={"text": "test"})
        check("unauthenticated → 401", resp.status_code == 401, str(resp.status_code))

        # Regular user without KB access
        resp = client.post(url, json={"text": "test"}, headers=user_headers)
        check("no-access user → 403", resp.status_code == 403, str(resp.status_code))

        # Unknown KB
        resp = client.post(
            f"/v1/knowledge-bases/{uuid.uuid4()}/conversations/{conv_id}/chatbot/stream",
            json={"text": "test"},
            headers=admin_headers,
        )
        check("unknown KB → 404", resp.status_code == 404, str(resp.status_code))

        # Unknown conversation
        resp = client.post(
            f"/v1/knowledge-bases/{kb_id}/conversations/{uuid.uuid4()}/chatbot/stream",
            json={"text": "test"},
            headers=admin_headers,
        )
        check("unknown conv → 404", resp.status_code == 404, str(resp.status_code))

        # Empty text (Pydantic min_length=1)
        resp = client.post(url, json={"text": ""}, headers=admin_headers)
        check("empty text → 422", resp.status_code == 422, str(resp.status_code))

        # Missing text field
        resp = client.post(url, json={}, headers=admin_headers)
        check("missing text field → 422", resp.status_code == 422, str(resp.status_code))

        # Valid request (with mocked LLM)
        with mock.patch("llm.variable_chat.stream_llm", return_value=iter(_CHUNKS)):
            resp = client.post(url, json={"text": "What is LG1OSI?"}, headers=admin_headers)
        check("valid request → 200", resp.status_code == 200, str(resp.status_code))
    finally:
        db.close()


def test_sse_event_contract(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("2. SSE event contract")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/chatbot/stream"

        with mock.patch("llm.variable_chat.stream_llm", return_value=iter(_CHUNKS)):
            resp = client.post(url, json={"text": "What is LG1OSI?"}, headers=admin_headers)

        check("status 200", resp.status_code == 200, str(resp.status_code))
        check(
            "Content-Type: text/event-stream",
            "text/event-stream" in resp.headers.get("content-type", ""),
            resp.headers.get("content-type", ""),
        )

        events = _parse_sse(resp.text)
        check(f"parsed ≥ {len(_CHUNKS) + 1} events", len(events) >= len(_CHUNKS) + 1,
              f"got {len(events)}")

        chunk_events = [e for e in events if e.get("type") == "chunk"]
        done_events  = [e for e in events if e.get("type") == "done"]

        check(f"exactly {len(_CHUNKS)} chunk events", len(chunk_events) == len(_CHUNKS),
              f"got {len(chunk_events)}")
        check("exactly 1 done event", len(done_events) == 1, f"got {len(done_events)}")

        # Every chunk event must have a non-empty text field
        for i, ce in enumerate(chunk_events):
            check(f"chunk[{i}].type == 'chunk'", ce.get("type") == "chunk", str(ce))
            check(f"chunk[{i}].text present", "text" in ce and ce["text"] != "", str(ce))

        # Verify chunk texts match the mock output in order
        got_chunks = [ce["text"] for ce in chunk_events]
        check("chunk texts match mock output in order", got_chunks == _CHUNKS, str(got_chunks))

        # Done event shape
        done = done_events[0] if done_events else {}

        check("done.type == 'done'", done.get("type") == "done", str(done))
        check("done.msg_id present", bool(done.get("msg_id")), str(done))
        check(
            "done.msg_id starts with 'cm-' (not an integer)",
            str(done.get("msg_id", "")).startswith("cm-"),
            done.get("msg_id", ""),
        )
        check(
            "done.msg_id is NOT a bot-user prefix (cm-u- reserved for user msgs)",
            not str(done.get("msg_id", "")).startswith("cm-u-"),
            done.get("msg_id", ""),
        )
        check("done.text present", bool(done.get("text")), str(done))
        check("done.created_at present", bool(done.get("created_at")), str(done))
        check(
            "done.text == concatenation of all chunk texts",
            done.get("text") == _FULL_REPLY,
            f"got={done.get('text')!r}  want={_FULL_REPLY!r}",
        )

        # done event must be the LAST event in the stream
        check("done event is last in stream", events[-1].get("type") == "done",
              str(events[-1]))
    finally:
        db.close()


def test_persistence(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("3. persistence — user pre-save, bot post-save, stable msg_ids")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/chatbot/stream"

        with mock.patch("llm.variable_chat.stream_llm", return_value=iter(_CHUNKS)):
            resp = client.post(url, json={"text": "What is LG1OSI?"}, headers=admin_headers)

        assert resp.status_code == 200, f"POST failed: {resp.status_code}"

        events = _parse_sse(resp.text)
        done = next((e for e in events if e.get("type") == "done"), {})
        bot_msg_id_from_done = done.get("msg_id", "")

        # Read back the conv to get the chat_session_id that was auto-created
        conv_data = _load_conv(kb_id, conv_id)
        chat_session_id = conv_data.get("chat_session_id")
        check("chat_session_id written to conversation file", bool(chat_session_id),
              str(chat_session_id))

        if not chat_session_id:
            return  # remaining checks are meaningless without a session id

        session = _load_chat_session(kb_id, chat_session_id)
        msgs = session.get("messages") or []

        check("exactly 2 messages persisted (user + bot)", len(msgs) == 2, str(len(msgs)))

        user_msg = msgs[0] if len(msgs) > 0 else {}
        bot_msg  = msgs[1] if len(msgs) > 1 else {}

        # User message
        check("user message role == 'user'",
              user_msg.get("role") == "user", str(user_msg.get("role")))
        check("user message content matches question",
              user_msg.get("content") == "What is LG1OSI?",
              user_msg.get("content", ""))
        check("user message has cm-u- prefixed msg_id",
              str(user_msg.get("msg_id", "")).startswith("cm-u-"),
              user_msg.get("msg_id", ""))

        # Bot message
        check("bot message role == 'assistant'",
              bot_msg.get("role") == "assistant", str(bot_msg.get("role")))
        check("bot message content == full reply",
              bot_msg.get("content") == _FULL_REPLY,
              bot_msg.get("content", ""))
        check("bot msg_id starts with 'cm-'",
              str(bot_msg.get("msg_id", "")).startswith("cm-"),
              bot_msg.get("msg_id", ""))
        check("bot msg_id matches done event msg_id",
              bot_msg.get("msg_id") == bot_msg_id_from_done,
              f"session={bot_msg.get('msg_id')}  done={bot_msg_id_from_done}")
    finally:
        db.close()


def test_get_chatbot_returns_cm_ids(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("4. GET /chatbot returns cm- prefixed msg_ids")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        stream_url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/chatbot/stream"
        list_url   = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/chatbot"

        with mock.patch("llm.variable_chat.stream_llm", return_value=iter(_CHUNKS)):
            stream_resp = client.post(stream_url, json={"text": "What is LG1OSI?"},
                                      headers=admin_headers)
        assert stream_resp.status_code == 200

        done = next(
            (e for e in _parse_sse(stream_resp.text) if e.get("type") == "done"), {}
        )
        done_msg_id = done.get("msg_id", "")

        list_resp = client.get(list_url, headers=admin_headers)
        check("GET /chatbot → 200", list_resp.status_code == 200,
              str(list_resp.status_code))

        msgs = list_resp.json().get("messages", [])
        check("GET /chatbot returns 2 messages", len(msgs) == 2, str(len(msgs)))

        user_m = next((m for m in msgs if m.get("role") == "user"), {})
        bot_m  = next((m for m in msgs if m.get("role") == "bot"),  {})

        check("user msg_id starts with 'cm-u-'",
              str(user_m.get("id", "")).startswith("cm-u-"),
              user_m.get("id", ""))
        check("bot role is 'bot' (not 'assistant')",
              bot_m.get("role") == "bot",
              bot_m.get("role", ""))
        check("bot msg_id starts with 'cm-'",
              str(bot_m.get("id", "")).startswith("cm-"),
              bot_m.get("id", ""))
        check("bot msg_id from GET == done event msg_id",
              bot_m.get("id") == done_msg_id,
              f"GET={bot_m.get('id')}  done={done_msg_id}")
        check("no msg_id is a plain integer string",
              all(not m.get("id", "0").lstrip("-").isdigit() for m in msgs),
              str([m.get("id") for m in msgs]))
    finally:
        db.close()


def test_multi_turn_no_duplication(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("5. multi-turn — second call appends 2 messages, no duplication")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/chatbot/stream"

        # Turn 1
        with mock.patch("llm.variable_chat.stream_llm", return_value=iter(_CHUNKS)):
            resp1 = client.post(url, json={"text": "First question"}, headers=admin_headers)
        assert resp1.status_code == 200

        # Turn 2
        with mock.patch("llm.variable_chat.stream_llm", return_value=iter(["Second reply."])):
            resp2 = client.post(url, json={"text": "Second question"}, headers=admin_headers)
        assert resp2.status_code == 200

        conv_data = _load_conv(kb_id, conv_id)
        session   = _load_chat_session(kb_id, conv_data["chat_session_id"])
        msgs      = session.get("messages") or []

        check("exactly 4 messages after 2 turns (no duplication)",
              len(msgs) == 4, str(len(msgs)))

        roles = [m.get("role") for m in msgs]
        check("roles alternate user/assistant",
              roles == ["user", "assistant", "user", "assistant"],
              str(roles))

        msg_ids = [m.get("msg_id", "") for m in msgs]
        check("all 4 msg_ids are unique", len(set(msg_ids)) == 4, str(msg_ids))
        check("all msg_ids start with 'cm-'",
              all(mid.startswith("cm-") for mid in msg_ids),
              str(msg_ids))

        events2 = _parse_sse(resp2.text)
        done2 = next((e for e in events2 if e.get("type") == "done"), {})
        check("second done.text == 'Second reply.'",
              done2.get("text") == "Second reply.",
              done2.get("text", ""))

        # Second turn's bot msg_id must be different from first turn's
        done1 = next((e for e in _parse_sse(resp1.text) if e.get("type") == "done"), {})
        check("turn-1 and turn-2 bot msg_ids are distinct",
              done1.get("msg_id") != done2.get("msg_id"),
              f"t1={done1.get('msg_id')}  t2={done2.get('msg_id')}")
    finally:
        db.close()


def test_get_chatbot_response_contract(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("6. GET /chatbot response contract — roles, sort order, empty state")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)

        # --- 6a: empty history returns 200 + empty array (not 404) ---
        conv_id_empty = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id_empty)

        empty_resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id_empty}/chatbot",
            headers=admin_headers,
        )
        check("empty history → 200", empty_resp.status_code == 200,
              str(empty_resp.status_code))
        check("empty history → messages: []",
              empty_resp.json().get("messages") == [],
              str(empty_resp.json()))

        # --- 6b: unknown conv → 404 ---
        resp_404 = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{uuid.uuid4()}/chatbot",
            headers=admin_headers,
        )
        check("unknown conv → 404", resp_404.status_code == 404,
              str(resp_404.status_code))

        # --- 6c: old /chatbot/messages path is NOT the registered route ---
        # FastAPI will return 405 (Method Not Allowed on POST) or 404 for paths
        # that don't exist; what matters is that the frontend only calls /chatbot.
        # We just confirm /chatbot works and has the right URL.
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)
        stream_url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/chatbot/stream"

        with mock.patch("llm.variable_chat.stream_llm", return_value=iter(_CHUNKS)):
            client.post(stream_url, json={"text": "Q1"}, headers=admin_headers)

        # A second turn so we get two user messages with different timestamps
        with mock.patch("llm.variable_chat.stream_llm", return_value=iter(["A2"])):
            client.post(stream_url, json={"text": "Q2"}, headers=admin_headers)

        list_resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/chatbot",
            headers=admin_headers,
        )
        check("GET /chatbot → 200", list_resp.status_code == 200,
              str(list_resp.status_code))

        msgs = list_resp.json().get("messages", [])
        check("top-level key is 'messages'", "messages" in list_resp.json(),
              str(list(list_resp.json().keys())))
        check("4 messages after 2 turns", len(msgs) == 4, str(len(msgs)))

        # --- 6d: role mapping — no message should have role 'assistant' ---
        roles = [m.get("role") for m in msgs]
        check("no message has role 'assistant'",
              "assistant" not in roles,
              str(roles))
        check("bot messages have role 'bot'",
              all(r in ("user", "bot") for r in roles),
              str(roles))
        check("roles alternate user/bot",
              roles == ["user", "bot", "user", "bot"],
              str(roles))

        # --- 6e: ascending sort by createdAt ---
        timestamps = [m.get("created_at", "") for m in msgs]
        check("messages sorted ascending by created_at",
              timestamps == sorted(timestamps),
              str(timestamps))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

def cleanup() -> None:
    db = SessionLocal()
    try:
        for kb_id in _CREATED_KBS:
            db.query(KnowledgeBaseAccess).filter(
                KnowledgeBaseAccess.kb_id == kb_id
            ).delete()
            db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).delete()
            shutil.rmtree(WorkspaceManager(kb_id).root, ignore_errors=True)
        for username in _CREATED_USERS:
            db.query(User).filter(User.username == username).delete()
        db.commit()
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    create_tables()
    suffix = uuid.uuid4().hex[:8]
    admin_username = f"cs_admin_{suffix}"
    user_username  = f"cs_user_{suffix}"

    db = SessionLocal()
    try:
        _create_user(db, admin_username, role="admin")
        _create_user(db, user_username,  role="user")
        db.commit()
    finally:
        db.close()

    admin_headers = _auth_headers(admin_username, "admin")
    user_headers  = _auth_headers(user_username,  "user")

    try:
        with TestClient(app) as client:
            test_auth_and_routing(client, admin_headers, user_headers, admin_username)
            test_sse_event_contract(client, admin_headers, admin_username)
            test_persistence(client, admin_headers, admin_username)
            test_get_chatbot_returns_cm_ids(client, admin_headers, admin_username)
            test_multi_turn_no_duplication(client, admin_headers, admin_username)
            test_get_chatbot_response_contract(client, admin_headers, admin_username)
    finally:
        cleanup()

    print(f"\n{'=' * 70}")
    print(f"Results: {PASS} PASS / {FAIL} FAIL / {PASS + FAIL} total")
    print(f"{'=' * 70}")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
