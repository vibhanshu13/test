#!/usr/bin/env python3
"""Validation tests for the explain streaming endpoints.

Endpoints under test:
  S1  POST /{kb_id}/conversations/{conv_id}/keyword-file-flow/explain/stream
  S2  POST /{kb_id}/conversations/{conv_id}/messages/{msg_id}/explain-more/stream

Tests verify:
  1. Auth / routing (401, 403, 404, 409)
  2. S1 SSE event contract — chunk events, done event with all required fields
  3. S1 progressive_summary — contains step 0 explanation after stream
  4. S2 SSE event contract — done event fields including tuple_index, progressive_summary
  5. S2 progressive_summary accumulation — steps 0..N present
  6. is_complete flag — True when last tuple, False otherwise
  7. Error cases — no backward session, no more tuples, tuple not available
"""
from __future__ import annotations

import json
import shutil
import sys
import uuid
from pathlib import Path
from typing import Any, Dict, List
from unittest import mock

import msgpack
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from api.app import app  # noqa: E402
from api.auth import create_access_token, hash_password  # noqa: E402
from api.db import SessionLocal, create_tables  # noqa: E402
from api.models.knowledge_base import KnowledgeBase, KnowledgeBaseAccess  # noqa: E402
from api.models.user import User  # noqa: E402
from api.storage.workspace import WorkspaceManager  # noqa: E402

# ---------------------------------------------------------------------------
# Test accounting
# ---------------------------------------------------------------------------

PASS = 0
FAIL = 0
_CREATED_KBS: List[str] = []
_CREATED_USERS: List[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS  {name}" + (f"  [{detail}]" if detail else ""))
    else:
        FAIL += 1
        print(f"  FAIL  {name}" + (f"  [{detail}]" if detail else ""))


# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------

def _create_user(db, username: str, role: str = "user") -> User:
    user = User(
        username=username,
        hashed_password=hash_password("TestPass123!"),
        role=role,
        is_active=True,
    )
    db.add(user)
    _CREATED_USERS.append(username)
    return user


def _create_kb(db, kb_id: str, *, status: str = "success", created_by: str = "admin") -> KnowledgeBase:
    kb = KnowledgeBase(
        id=kb_id,
        name=f"ExplainStream Test {kb_id[:8]}",
        created_by=created_by,
        datasource_username=None,
        datasource_folder=None,
        source_path="/tmp/src",
        status=status,
        error=None,
    )
    db.add(kb)
    _CREATED_KBS.append(kb_id)
    return kb


def _auth_headers(username: str, role: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {create_access_token(username, role)}"}


def _prepare_kb(db, admin_username: str) -> str:
    kb_id = str(uuid.uuid4())
    _create_kb(db, kb_id, status="success", created_by=admin_username)
    db.commit()
    ws = WorkspaceManager(kb_id)
    for d in (ws.root, ws.input_dir, ws.output_dir, ws.cache_dir):
        d.mkdir(parents=True, exist_ok=True)
    return kb_id


_FLOW_ID = "flow-001"
_SESSION_ID = "bsess-001"
_ROOT_VAR = "LG1OSI"
_CHAIN = ["entry.asm", "middle.asm", "setter.asm"]


def _write_conversation_s1(kb_id: str, conv_id: str) -> None:
    """Conversation with a keyword_file_flow entry for S1 testing."""
    conv_dir = WorkspaceManager(kb_id).output_dir / "conversations"
    conv_dir.mkdir(parents=True, exist_ok=True)
    conv: Dict[str, Any] = {
        "version": 1,
        "conv_id": conv_id,
        "process": "lu82",
        "keyword": _ROOT_VAR,
        "backward_session_id": None,
        "root_variable": _ROOT_VAR,
        "selected_chain": [],
        "keyword_file_flows": [
            {
                "id": _FLOW_ID,
                "chain": _CHAIN,
                "modifier_file": "setter.asm",
            }
        ],
        "messages": [],
        "created_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-01T00:00:00+00:00",
    }
    (conv_dir / f"{conv_id}.msgpack").write_bytes(msgpack.packb(conv, use_bin_type=True))


def _write_conversation_s2(
    kb_id: str,
    conv_id: str,
    *,
    backward_session_id: str | None = _SESSION_ID,
    prior_msg_id: str = "msg-prior-001",
    prior_tuple_index: int = 0,
) -> None:
    """Conversation with a backward session and a prior explain message for S2."""
    conv_dir = WorkspaceManager(kb_id).output_dir / "conversations"
    conv_dir.mkdir(parents=True, exist_ok=True)
    conv: Dict[str, Any] = {
        "version": 1,
        "conv_id": conv_id,
        "process": "lu82",
        "keyword": _ROOT_VAR,
        "backward_session_id": backward_session_id,
        "root_variable": _ROOT_VAR,
        "selected_chain": _CHAIN,
        "keyword_file_flows": [],
        "messages": [
            {
                "msg_id": prior_msg_id,
                "tuple_index": prior_tuple_index,
                "file_stem": "entry",
                "file_type": "asm",
                "phase": "INIT",
                "phase_label": "Initialization",
                "explanation": "Step 0 was already explained.",
                "is_complete": False,
                "created_at": "2026-01-01T00:00:00+00:00",
            }
        ],
        "created_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-01T00:00:00+00:00",
    }
    (conv_dir / f"{conv_id}.msgpack").write_bytes(msgpack.packb(conv, use_bin_type=True))


def _parse_sse(content: str) -> List[Dict[str, Any]]:
    """Parse SSE data lines from a full response body into a list of JSON dicts."""
    events: List[Dict[str, Any]] = []
    for line in content.splitlines():
        line = line.strip()
        if line.startswith("data:"):
            payload = line[5:].strip()
            try:
                events.append(json.loads(payload))
            except json.JSONDecodeError:
                pass
    return events


# ---------------------------------------------------------------------------
# Mock LLM chunks
# ---------------------------------------------------------------------------

_CHUNKS: List[str] = ["LG1OSI ", "is a ", "session ", "indicator variable."]
_FULL_TEXT: str = "".join(_CHUNKS)
_STEP0_PRIOR_TEXT = "Step 0 prior explanation text."


def _make_explain_stream_mock(expected_index: int):
    """Return a mock generator that yields chunks and updates session.explanations."""
    def _mock_stream(
        kb_id, backward_session_id, session, tuple_data, tuple_index,
        total_tuples, selected_chain
    ):
        for chunk in _CHUNKS:
            yield chunk
        session.setdefault("explanations", {})[str(tuple_index)] = _FULL_TEXT
    return _mock_stream


def _meta(total: int = 3, complete: bool = False) -> Dict[str, Any]:
    return {
        "is_complete": complete,
        "total_tuples": total,
        "selected_chain": _CHAIN,
        "root_variable": _ROOT_VAR,
    }


def _tuple_data(index: int = 0) -> Dict[str, Any]:
    stems = ["entry", "middle", "setter"]
    return {
        "file_stem": stems[min(index, len(stems) - 1)],
        "file_type": "asm",
        "phase": "MAIN",
    }


# ---------------------------------------------------------------------------
# Group 1: S1 — Auth / Routing
# ---------------------------------------------------------------------------

def test_s1_auth_and_routing(
    client: TestClient,
    admin_headers: Dict[str, str],
    user_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("1. S1 auth + routing")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation_s1(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/keyword-file-flow/explain/stream"

        # Unauthenticated
        resp = client.post(url, json={"keyword_file_flow_id": _FLOW_ID})
        check("S1 unauthenticated → 401", resp.status_code == 401, str(resp.status_code))

        # User without KB access
        resp = client.post(url, json={"keyword_file_flow_id": _FLOW_ID}, headers=user_headers)
        check("S1 no-access user → 403", resp.status_code == 403, str(resp.status_code))

        # Unknown KB
        resp = client.post(
            f"/v1/knowledge-bases/{uuid.uuid4()}/conversations/{conv_id}/keyword-file-flow/explain/stream",
            json={"keyword_file_flow_id": _FLOW_ID},
            headers=admin_headers,
        )
        check("S1 unknown KB → 404", resp.status_code == 404, str(resp.status_code))

        # Unknown conversation
        resp = client.post(
            f"/v1/knowledge-bases/{kb_id}/conversations/{uuid.uuid4()}/keyword-file-flow/explain/stream",
            json={"keyword_file_flow_id": _FLOW_ID},
            headers=admin_headers,
        )
        check("S1 unknown conv → 404", resp.status_code == 404, str(resp.status_code))

        # Unknown keyword_file_flow_id
        resp = client.post(
            url,
            json={"keyword_file_flow_id": "no-such-flow"},
            headers=admin_headers,
        )
        check("S1 unknown flow_id → 404", resp.status_code == 404, str(resp.status_code))

        # Valid request with mocks
        with (
            mock.patch("api.routes.conversations._ensure_backward_session", return_value=_SESSION_ID),
            mock.patch("api.routes.conversations._backward_session_meta", return_value=_meta(3)),
            mock.patch("api.routes.conversations._load_backward_tuple", return_value=_tuple_data(0)),
            mock.patch("llm.variable_explainer.load_explain_session", return_value=None),
            mock.patch("llm.variable_explainer.create_explain_session",
                       return_value={"explanations": {}, "tuple_facts": {}, "synthesis": ""}),
            mock.patch("llm.variable_explainer.explain_tuple_stream",
                       side_effect=_make_explain_stream_mock(0)),
        ):
            resp = client.post(url, json={"keyword_file_flow_id": _FLOW_ID}, headers=admin_headers)
        check("S1 valid request → 200", resp.status_code == 200, str(resp.status_code))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 2: S1 — SSE event contract
# ---------------------------------------------------------------------------

def test_s1_sse_event_contract(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("2. S1 SSE event contract")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation_s1(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/keyword-file-flow/explain/stream"

        explain_session: Dict[str, Any] = {"explanations": {}, "tuple_facts": {}, "synthesis": ""}

        with (
            mock.patch("api.routes.conversations._ensure_backward_session", return_value=_SESSION_ID),
            mock.patch("api.routes.conversations._backward_session_meta", return_value=_meta(3)),
            mock.patch("api.routes.conversations._load_backward_tuple", return_value=_tuple_data(0)),
            mock.patch("llm.variable_explainer.load_explain_session", return_value=explain_session),
            mock.patch("llm.variable_explainer.explain_tuple_stream",
                       side_effect=_make_explain_stream_mock(0)),
        ):
            resp = client.post(url, json={"keyword_file_flow_id": _FLOW_ID}, headers=admin_headers)

        check("S1 status 200", resp.status_code == 200, str(resp.status_code))
        check(
            "S1 Content-Type: text/event-stream",
            "text/event-stream" in resp.headers.get("content-type", ""),
            resp.headers.get("content-type", ""),
        )

        events = _parse_sse(resp.text)
        chunk_events = [e for e in events if e.get("type") == "chunk"]
        done_events  = [e for e in events if e.get("type") == "done"]

        check(f"S1 exactly {len(_CHUNKS)} chunk events", len(chunk_events) == len(_CHUNKS),
              f"got {len(chunk_events)}")
        check("S1 exactly 1 done event", len(done_events) == 1, f"got {len(done_events)}")
        check("S1 done event is last in stream", events[-1].get("type") == "done",
              str(events[-1].get("type")))

        # Chunk events
        for i, ce in enumerate(chunk_events):
            check(f"S1 chunk[{i}].type == 'chunk'", ce.get("type") == "chunk", str(ce))
            check(f"S1 chunk[{i}].text present", bool(ce.get("text")), str(ce))
        got_chunks = [ce["text"] for ce in chunk_events]
        check("S1 chunk texts match mock output", got_chunks == _CHUNKS, str(got_chunks))

        # Done event — shape
        done = done_events[0] if done_events else {}
        check("S1 done.msg_id present", bool(done.get("msg_id")), str(done.get("msg_id")))
        check("S1 done.tuple_index == 0", done.get("tuple_index") == 0,
              str(done.get("tuple_index")))
        check("S1 done.file_stem present", bool(done.get("file_stem")),
              str(done.get("file_stem")))
        check("S1 done.file_type present", bool(done.get("file_type")),
              str(done.get("file_type")))
        check("S1 done.phase present", "phase" in done, str(done.get("phase")))
        check("S1 done.phase_label present", "phase_label" in done, str(done.get("phase_label")))
        check("S1 done.explanation == full text",
              done.get("explanation") == _FULL_TEXT,
              f"got={done.get('explanation')!r}  want={_FULL_TEXT!r}")
        check("S1 done.is_complete is bool", isinstance(done.get("is_complete"), bool),
              str(type(done.get("is_complete"))))
        check("S1 done.created_at present", bool(done.get("created_at")),
              str(done.get("created_at")))
        check("S1 done.progressive_summary present",
              "progressive_summary" in done,
              str(list(done.keys())))
        check("S1 done.progressive_summary is str",
              isinstance(done.get("progressive_summary"), str),
              str(type(done.get("progressive_summary"))))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 3: S1 — progressive_summary content
# ---------------------------------------------------------------------------

def test_s1_progressive_summary(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("3. S1 progressive_summary content")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation_s1(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/keyword-file-flow/explain/stream"

        explain_session: Dict[str, Any] = {"explanations": {}, "tuple_facts": {}, "synthesis": ""}

        with (
            mock.patch("api.routes.conversations._ensure_backward_session", return_value=_SESSION_ID),
            mock.patch("api.routes.conversations._backward_session_meta", return_value=_meta(3)),
            mock.patch("api.routes.conversations._load_backward_tuple", return_value=_tuple_data(0)),
            mock.patch("llm.variable_explainer.load_explain_session", return_value=explain_session),
            mock.patch("llm.variable_explainer.explain_tuple_stream",
                       side_effect=_make_explain_stream_mock(0)),
        ):
            resp = client.post(url, json={"keyword_file_flow_id": _FLOW_ID}, headers=admin_headers)

        assert resp.status_code == 200
        events = _parse_sse(resp.text)
        done = next((e for e in events if e.get("type") == "done"), {})

        prog = done.get("progressive_summary", "")

        # Step 0 explanation must appear in progressive_summary
        check("S1 progressive_summary contains '**Step 0:**'",
              "**Step 0:**" in prog,
              repr(prog))
        check("S1 progressive_summary contains the step 0 full text",
              _FULL_TEXT in prog,
              repr(prog))

        # Only step 0 — no step 1 references
        check("S1 progressive_summary has no '**Step 1:**' (only 1 tuple explained)",
              "**Step 1:**" not in prog,
              repr(prog))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 4: S2 — Auth / Routing
# ---------------------------------------------------------------------------

def test_s2_auth_and_routing(
    client: TestClient,
    admin_headers: Dict[str, str],
    user_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("4. S2 auth + routing")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        prior_msg_id = "msg-s2-route"
        _write_conversation_s2(kb_id, conv_id, prior_msg_id=prior_msg_id)

        url_tpl = (
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}"
            f"/messages/{prior_msg_id}/explain-more/stream"
        )

        # Unauthenticated
        resp = client.post(url_tpl)
        check("S2 unauthenticated → 401", resp.status_code == 401, str(resp.status_code))

        # User without KB access
        resp = client.post(url_tpl, headers=user_headers)
        check("S2 no-access user → 403", resp.status_code == 403, str(resp.status_code))

        # Unknown KB
        resp = client.post(
            f"/v1/knowledge-bases/{uuid.uuid4()}/conversations/{conv_id}"
            f"/messages/{prior_msg_id}/explain-more/stream",
            headers=admin_headers,
        )
        check("S2 unknown KB → 404", resp.status_code == 404, str(resp.status_code))

        # Unknown conversation
        resp = client.post(
            f"/v1/knowledge-bases/{kb_id}/conversations/{uuid.uuid4()}"
            f"/messages/{prior_msg_id}/explain-more/stream",
            headers=admin_headers,
        )
        check("S2 unknown conv → 404", resp.status_code == 404, str(resp.status_code))

        # Unknown msg_id
        resp = client.post(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}"
            f"/messages/no-such-msg/explain-more/stream",
            headers=admin_headers,
        )
        check("S2 unknown msg_id → 404", resp.status_code == 404, str(resp.status_code))

        # 409 when backward_session_id is missing
        conv_no_session = str(uuid.uuid4())
        no_sess_msg_id = "msg-nosess-001"
        _write_conversation_s2(
            kb_id, conv_no_session,
            backward_session_id=None,
            prior_msg_id=no_sess_msg_id,
        )
        resp = client.post(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_no_session}"
            f"/messages/{no_sess_msg_id}/explain-more/stream",
            headers=admin_headers,
        )
        check("S2 no backward_session_id → 409", resp.status_code == 409, str(resp.status_code))

        # 409 when next_index >= total_tuples (already at last)
        conv_last = str(uuid.uuid4())
        last_msg_id = "msg-last-001"
        _write_conversation_s2(
            kb_id, conv_last,
            prior_msg_id=last_msg_id,
            prior_tuple_index=2,  # next_index=3, total=3 → exhausted
        )
        with mock.patch("api.routes.conversations._backward_session_meta", return_value=_meta(3)):
            resp = client.post(
                f"/v1/knowledge-bases/{kb_id}/conversations/{conv_last}"
                f"/messages/{last_msg_id}/explain-more/stream",
                headers=admin_headers,
            )
        check("S2 no more tuples → 409", resp.status_code == 409, str(resp.status_code))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 5: S2 — SSE event contract
# ---------------------------------------------------------------------------

def test_s2_sse_event_contract(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("5. S2 SSE event contract")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        prior_msg_id = "msg-s2-contract"
        _write_conversation_s2(kb_id, conv_id, prior_msg_id=prior_msg_id, prior_tuple_index=0)

        url = (
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}"
            f"/messages/{prior_msg_id}/explain-more/stream"
        )
        explain_session: Dict[str, Any] = {
            "explanations": {"0": _STEP0_PRIOR_TEXT},
            "tuple_facts": {},
            "synthesis": "",
        }

        with (
            mock.patch("api.routes.conversations._ensure_backward_session", return_value=_SESSION_ID),
            mock.patch("api.routes.conversations._backward_session_meta", return_value=_meta(3)),
            mock.patch("api.routes.conversations._load_backward_tuple", return_value=_tuple_data(1)),
            mock.patch("llm.variable_explainer.load_explain_session", return_value=explain_session),
            mock.patch("llm.variable_explainer.explain_tuple_stream",
                       side_effect=_make_explain_stream_mock(1)),
        ):
            resp = client.post(url, headers=admin_headers)

        check("S2 status 200", resp.status_code == 200, str(resp.status_code))
        check(
            "S2 Content-Type: text/event-stream",
            "text/event-stream" in resp.headers.get("content-type", ""),
            resp.headers.get("content-type", ""),
        )

        events = _parse_sse(resp.text)
        chunk_events = [e for e in events if e.get("type") == "chunk"]
        done_events  = [e for e in events if e.get("type") == "done"]

        check(f"S2 exactly {len(_CHUNKS)} chunk events", len(chunk_events) == len(_CHUNKS),
              f"got {len(chunk_events)}")
        check("S2 exactly 1 done event", len(done_events) == 1, f"got {len(done_events)}")
        check("S2 done event is last in stream", events[-1].get("type") == "done",
              str(events[-1].get("type")))

        # Chunk texts
        got_chunks = [ce["text"] for ce in chunk_events]
        check("S2 chunk texts match mock output", got_chunks == _CHUNKS, str(got_chunks))

        done = done_events[0] if done_events else {}

        # Required done fields
        check("S2 done.msg_id present", bool(done.get("msg_id")), str(done.get("msg_id")))
        check("S2 done.tuple_index == 1", done.get("tuple_index") == 1,
              str(done.get("tuple_index")))
        check("S2 done.file_stem present", bool(done.get("file_stem")),
              str(done.get("file_stem")))
        check("S2 done.file_type present", bool(done.get("file_type")),
              str(done.get("file_type")))
        check("S2 done.phase present", "phase" in done, str(done.get("phase")))
        check("S2 done.phase_label present", "phase_label" in done)
        check("S2 done.explanation == full text",
              done.get("explanation") == _FULL_TEXT,
              f"got={done.get('explanation')!r}  want={_FULL_TEXT!r}")
        check("S2 done.is_complete is bool", isinstance(done.get("is_complete"), bool),
              str(type(done.get("is_complete"))))
        check("S2 done.created_at present", bool(done.get("created_at")))
        check("S2 done.progressive_summary present",
              "progressive_summary" in done,
              str(list(done.keys())))
        check("S2 done.progressive_summary is str",
              isinstance(done.get("progressive_summary"), str),
              str(type(done.get("progressive_summary"))))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 6: S2 — progressive_summary accumulation
# ---------------------------------------------------------------------------

def test_s2_progressive_summary_accumulation(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("6. S2 progressive_summary — accumulates steps 0..N")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        prior_msg_id = "msg-accum-001"
        _write_conversation_s2(kb_id, conv_id, prior_msg_id=prior_msg_id, prior_tuple_index=0)

        url = (
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}"
            f"/messages/{prior_msg_id}/explain-more/stream"
        )

        # Step 0 was already explained in this explain_session
        explain_session: Dict[str, Any] = {
            "explanations": {"0": _STEP0_PRIOR_TEXT},
            "tuple_facts": {},
            "synthesis": "",
        }

        with (
            mock.patch("api.routes.conversations._ensure_backward_session", return_value=_SESSION_ID),
            mock.patch("api.routes.conversations._backward_session_meta", return_value=_meta(3)),
            mock.patch("api.routes.conversations._load_backward_tuple", return_value=_tuple_data(1)),
            mock.patch("llm.variable_explainer.load_explain_session", return_value=explain_session),
            mock.patch("llm.variable_explainer.explain_tuple_stream",
                       side_effect=_make_explain_stream_mock(1)),
        ):
            resp = client.post(url, headers=admin_headers)

        assert resp.status_code == 200
        events = _parse_sse(resp.text)
        done = next((e for e in events if e.get("type") == "done"), {})
        prog = done.get("progressive_summary", "")

        # Step 0 text (loaded from prior explain_session)
        check("progressive_summary contains '**Step 0:**'",
              "**Step 0:**" in prog, repr(prog))
        check("progressive_summary contains step-0 prior text",
              _STEP0_PRIOR_TEXT in prog, repr(prog))

        # Step 1 text (just streamed)
        check("progressive_summary contains '**Step 1:**'",
              "**Step 1:**" in prog, repr(prog))
        check("progressive_summary contains step-1 full text",
              _FULL_TEXT in prog, repr(prog))

        # Step 0 comes before step 1
        step0_pos = prog.find("**Step 0:**")
        step1_pos = prog.find("**Step 1:**")
        check("step 0 appears before step 1 in progressive_summary",
              0 <= step0_pos < step1_pos,
              f"step0@{step0_pos} step1@{step1_pos}")

        # No step 2 reference (only 0 and 1 explained)
        check("progressive_summary has no '**Step 2:**'",
              "**Step 2:**" not in prog, repr(prog))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 7: is_complete flag
# ---------------------------------------------------------------------------

def test_is_complete_flag(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("7. is_complete flag")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)

        # --- 7a: not last tuple → is_complete = False ---
        conv_mid = str(uuid.uuid4())
        mid_msg_id = "msg-mid-001"
        _write_conversation_s2(kb_id, conv_mid, prior_msg_id=mid_msg_id, prior_tuple_index=0)

        explain_session: Dict[str, Any] = {"explanations": {}, "tuple_facts": {}, "synthesis": ""}
        url_mid = (
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_mid}"
            f"/messages/{mid_msg_id}/explain-more/stream"
        )
        with (
            mock.patch("api.routes.conversations._ensure_backward_session", return_value=_SESSION_ID),
            mock.patch("api.routes.conversations._backward_session_meta", return_value=_meta(3)),
            mock.patch("api.routes.conversations._load_backward_tuple", return_value=_tuple_data(1)),
            mock.patch("llm.variable_explainer.load_explain_session", return_value=explain_session),
            mock.patch("llm.variable_explainer.explain_tuple_stream",
                       side_effect=_make_explain_stream_mock(1)),
        ):
            resp = client.post(url_mid, headers=admin_headers)

        events = _parse_sse(resp.text)
        done = next((e for e in events if e.get("type") == "done"), {})
        check("is_complete == False when not at last tuple",
              done.get("is_complete") is False,
              str(done.get("is_complete")))

        # --- 7b: last tuple → is_complete = True ---
        conv_last = str(uuid.uuid4())
        last_msg_id = "msg-last-002"
        # prior_tuple_index=1, total=3 → next_index=2 which is total-1=2 → is_complete=True
        _write_conversation_s2(kb_id, conv_last, prior_msg_id=last_msg_id, prior_tuple_index=1)

        explain_session2: Dict[str, Any] = {"explanations": {}, "tuple_facts": {}, "synthesis": ""}
        url_last = (
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_last}"
            f"/messages/{last_msg_id}/explain-more/stream"
        )
        with (
            mock.patch("api.routes.conversations._ensure_backward_session", return_value=_SESSION_ID),
            mock.patch("api.routes.conversations._backward_session_meta", return_value=_meta(3)),
            mock.patch("api.routes.conversations._load_backward_tuple", return_value=_tuple_data(2)),
            mock.patch("llm.variable_explainer.load_explain_session", return_value=explain_session2),
            mock.patch("llm.variable_explainer.explain_tuple_stream",
                       side_effect=_make_explain_stream_mock(2)),
        ):
            resp = client.post(url_last, headers=admin_headers)

        events = _parse_sse(resp.text)
        done = next((e for e in events if e.get("type") == "done"), {})
        check("is_complete == True when at last tuple",
              done.get("is_complete") is True,
              str(done.get("is_complete")))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 8: progressive_summary with no prior explanations
# ---------------------------------------------------------------------------

def test_progressive_summary_no_prior(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("8. progressive_summary — no prior explanations (fresh session)")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        prior_msg_id = "msg-fresh-001"
        _write_conversation_s2(kb_id, conv_id, prior_msg_id=prior_msg_id, prior_tuple_index=0)

        url = (
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}"
            f"/messages/{prior_msg_id}/explain-more/stream"
        )

        # No prior explanations — fresh session for tuple index 1
        explain_session: Dict[str, Any] = {
            "explanations": {},   # step 0 not yet explained
            "tuple_facts": {},
            "synthesis": "",
        }

        with (
            mock.patch("api.routes.conversations._ensure_backward_session", return_value=_SESSION_ID),
            mock.patch("api.routes.conversations._backward_session_meta", return_value=_meta(3)),
            mock.patch("api.routes.conversations._load_backward_tuple", return_value=_tuple_data(1)),
            mock.patch("llm.variable_explainer.load_explain_session", return_value=explain_session),
            mock.patch("llm.variable_explainer.explain_tuple_stream",
                       side_effect=_make_explain_stream_mock(1)),
        ):
            resp = client.post(url, headers=admin_headers)

        assert resp.status_code == 200
        events = _parse_sse(resp.text)
        done = next((e for e in events if e.get("type") == "done"), {})
        prog = done.get("progressive_summary", "")

        # Step 0 is missing (empty string in explanations) → not in summary
        check("no '**Step 0:**' when step 0 explanation is absent",
              "**Step 0:**" not in prog, repr(prog))

        # Step 1 was just explained by the mock → should appear
        check("progressive_summary contains '**Step 1:**'",
              "**Step 1:**" in prog, repr(prog))
        check("progressive_summary contains step-1 full text",
              _FULL_TEXT in prog, repr(prog))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

def cleanup() -> None:
    db = SessionLocal()
    try:
        for kb_id in _CREATED_KBS:
            db.query(KnowledgeBaseAccess).filter(
                KnowledgeBaseAccess.kb_id == kb_id
            ).delete()
            db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).delete()
            shutil.rmtree(WorkspaceManager(kb_id).root, ignore_errors=True)
        for username in _CREATED_USERS:
            db.query(User).filter(User.username == username).delete()
        db.commit()
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    create_tables()
    suffix = uuid.uuid4().hex[:8]
    admin_username = f"es_admin_{suffix}"
    user_username  = f"es_user_{suffix}"

    db = SessionLocal()
    try:
        _create_user(db, admin_username, role="admin")
        _create_user(db, user_username,  role="user")
        db.commit()
    finally:
        db.close()

    admin_headers = _auth_headers(admin_username, "admin")
    user_headers  = _auth_headers(user_username,  "user")

    try:
        with TestClient(app) as client:
            test_s1_auth_and_routing(client, admin_headers, user_headers, admin_username)
            test_s1_sse_event_contract(client, admin_headers, admin_username)
            test_s1_progressive_summary(client, admin_headers, admin_username)
            test_s2_auth_and_routing(client, admin_headers, user_headers, admin_username)
            test_s2_sse_event_contract(client, admin_headers, admin_username)
            test_s2_progressive_summary_accumulation(client, admin_headers, admin_username)
            test_is_complete_flag(client, admin_headers, admin_username)
            test_progressive_summary_no_prior(client, admin_headers, admin_username)
    finally:
        cleanup()

    print(f"\n{'=' * 70}")
    print(f"Results: {PASS} PASS / {FAIL} FAIL / {PASS + FAIL} total")
    print(f"{'=' * 70}")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
