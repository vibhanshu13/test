#!/usr/bin/env python3
"""Validation tests for:
    GET /v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/variable-lineage

Follows the same pattern as fixes/test_file_graph_api.py.
"""
from __future__ import annotations

import json
import shutil
import sys
import uuid
from pathlib import Path
from typing import Any, Dict, List

import msgpack
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

# ---------------------------------------------------------------------------
# blueprint_io.iter_flow polyfill
# This symbol is used by backward_traversal.utils.blueprint_utils but is
# absent from the current blueprint_io package.  Add it before any import
# that triggers the backward_traversal import chain.
# ---------------------------------------------------------------------------
import blueprint_io as _bio  # noqa: E402
if not hasattr(_bio, "iter_flow"):
    def _iter_flow(block):  # type: ignore[override]
        """Yield each instruction dict in a block's 'flow' list."""
        yield from (block.get("flow") or [])
    _bio.iter_flow = _iter_flow

from api.app import app  # noqa: E402
from api.auth import create_access_token, hash_password  # noqa: E402
from api.db import SessionLocal, create_tables  # noqa: E402
from api.models.knowledge_base import KnowledgeBase, KnowledgeBaseAccess  # noqa: E402
from api.models.user import User  # noqa: E402
from api.storage.workspace import WorkspaceManager  # noqa: E402
from backward_traversal.runner.chunked_session import get_session_dir, get_session_file  # noqa: E402

# ---------------------------------------------------------------------------
# Test accounting
# ---------------------------------------------------------------------------

PASS = 0
FAIL = 0
_CREATED_KBS: List[str] = []
_CREATED_USERS: List[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS  {name}" + (f"  [{detail}]" if detail else ""))
    else:
        FAIL += 1
        print(f"  FAIL  {name}" + (f"  [{detail}]" if detail else ""))


# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------

def _graph_payload() -> Dict[str, Any]:
    """Two-file call graph: root.asm → mod.asm (ENTRC) and mod.asm → leaf.cpp (CALL)."""
    return {
        "nodes": [
            {"id": "root", "type": "asm", "file": "root.asm"},
            {"id": "mod",  "type": "asm", "file": "mod.asm"},
            {"id": "leaf", "type": "cpp", "file": "leaf.cpp"},
        ],
        "edges": [
            {
                "source": "root",
                "target": "mod",
                "instructions": ["ENTRC"],
                "call_sites": [{"line": 10}],
                "is_internal": False,
            },
            {
                "source": "mod",
                "target": "leaf",
                "instructions": ["CALL"],
                "call_sites": [{"line": 20}],
                "is_internal": False,
            },
        ],
    }


def _write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _write_session_and_chunks(
    kb_id: str,
    session_id: str,
    tuples: List[Dict[str, Any]],
    root_variable: str = "WK_VAR",
    selected_chain: List[str] | None = None,
) -> None:
    """Write a synthetic completed session with one chunk file per tuple entry.

    Each entry in *tuples* must have:
        file_stem, file_type, variable, phase
    and optionally:
        phase_metadata  (dict, inserted into chunk metadata)
        nodes           (list, defaults to [{"id": "n0"}])
    """
    session_dir = get_session_dir(kb_id, session_id)
    session_dir.mkdir(parents=True, exist_ok=True)

    tuple_index_map: List[Dict[str, Any]] = []
    for i, t in enumerate(tuples):
        chunk_filename = f"chunk_{i}.json"
        nodes = t.get("nodes") or [{"id": f"n{i}"}]
        phase_metadata = t.get("phase_metadata") or {}
        chunk = {
            "variable": t["variable"],
            "phase": t["phase"],
            "metadata": {
                "bp_path": None,
                "asm_file": None,
                "anchor_blocks": [],
                "scope_label": None,
                "summary": f"synthetic tuple {i}",
                "phase_metadata": phase_metadata,
                "intra_tuple_edges": [],
                "cross_file_calls_out": [],
            },
            "nodes": nodes,
        }
        (session_dir / chunk_filename).write_text(json.dumps(chunk), encoding="utf-8")
        tuple_index_map.append({
            "chunk_file": chunk_filename,
            "file_stem": t["file_stem"],
            "file_type": t["file_type"],
            "variable": t["variable"],
            "phase": t["phase"],
            "node_count": len(nodes),
        })

    state: Dict[str, Any] = {
        "session_id": session_id,
        "kb_id": kb_id,
        "root_variable": root_variable,
        "selected_chain": selected_chain or [t["file_stem"] for t in tuples],
        "phase": "COMPLETE",
        "tuple_index_map": tuple_index_map,
        "empty_tuples": [],
        "warnings": [],
        "file_type_map": {t["file_stem"]: t["file_type"] for t in tuples},
        "full_flow_serial": {"nodes": {}, "edges": {}},
    }
    sf = get_session_file(kb_id, session_id)
    sf.parent.mkdir(parents=True, exist_ok=True)
    sf.write_bytes(msgpack.packb(state, use_bin_type=True))


def _write_conversation(
    kb_id: str,
    conv_id: str,
    session_id: str | None,
    root_variable: str,
    messages: List[Dict[str, Any]],
    selected_chain: List[str] | None = None,
) -> None:
    conv_dir = WorkspaceManager(kb_id).output_dir / "conversations"
    conv_dir.mkdir(parents=True, exist_ok=True)
    conv: Dict[str, Any] = {
        "version": 1,
        "conv_id": conv_id,
        "process": "lu82",
        "keyword": root_variable,
        "backward_session_id": session_id,
        "root_variable": root_variable,
        "selected_chain": selected_chain,
        "keyword_file_flows": [],
        "messages": messages,
        "chat_session_id": None,
        "created_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-01T00:00:00+00:00",
    }
    (conv_dir / f"{conv_id}.msgpack").write_bytes(msgpack.packb(conv, use_bin_type=True))


def _make_message(msg_id: str, tuple_index: int, file_stem: str = "root",
                   file_type: str = "asm", phase: str = "modifier") -> Dict[str, Any]:
    return {
        "msg_id": msg_id,
        "tuple_index": tuple_index,
        "file_stem": file_stem,
        "file_type": file_type,
        "phase": phase,
        "phase_label": phase.capitalize(),
        "explanation": "synthetic",
        "is_complete": False,
        "created_at": "2026-01-01T00:00:00+00:00",
    }


def _create_user(db, username: str, role: str = "user") -> User:
    user = User(
        username=username,
        hashed_password=hash_password("TestPass123!"),
        role=role,
        is_active=True,
    )
    db.add(user)
    _CREATED_USERS.append(username)
    return user


def _create_kb(db, kb_id: str, *, status: str = "success", created_by: str = "admin") -> KnowledgeBase:
    kb = KnowledgeBase(
        id=kb_id,
        name=f"Lineage API Test {kb_id[:8]}",
        created_by=created_by,
        datasource_username=None,
        datasource_folder=None,
        source_path="/tmp/src",
        status=status,
        error=None,
    )
    db.add(kb)
    _CREATED_KBS.append(kb_id)
    return kb


def _auth_headers(username: str, role: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {create_access_token(username, role)}"}


def _prepare_kb(db, admin_username: str) -> str:
    """Create a success KB with call graph on disk."""
    kb_id = str(uuid.uuid4())
    _create_kb(db, kb_id, status="success", created_by=admin_username)
    db.commit()
    ws = WorkspaceManager(kb_id)
    for d in (ws.root, ws.input_dir, ws.output_dir, ws.cache_dir):
        d.mkdir(parents=True, exist_ok=True)
    _write_json(ws.output_dir / "file_call_graph.json", _graph_payload())
    return kb_id


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_auth_and_routing(
    client: TestClient,
    admin_headers: Dict[str, str],
    user_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("auth + routing checks")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        msg_id = str(uuid.uuid4())
        session_id = "aabbccdd00112233"

        _write_session_and_chunks(kb_id, session_id, [
            {"file_stem": "root", "file_type": "asm", "variable": "WK_VAR", "phase": "modifier"},
        ])
        _write_conversation(kb_id, conv_id, session_id, "WK_VAR",
                            messages=[_make_message(msg_id, 0)])

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/variable-lineage"

        resp = client.get(url)
        check("unauthenticated returns 401", resp.status_code == 401, str(resp.json()))

        resp = client.get(url, headers=user_headers)
        check("user without KB access returns 403", resp.status_code == 403, str(resp.json()))

        resp = client.get(
            f"/v1/knowledge-bases/{uuid.uuid4()}/conversations/{conv_id}/messages/{msg_id}/variable-lineage",
            headers=admin_headers,
        )
        check("missing KB returns 404", resp.status_code == 404, str(resp.json()))

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{uuid.uuid4()}/messages/{msg_id}/variable-lineage",
            headers=admin_headers,
        )
        check("missing conversation returns 404", resp.status_code == 404, str(resp.json()))

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{uuid.uuid4()}/variable-lineage",
            headers=admin_headers,
        )
        check("missing message returns 404", resp.status_code == 404, str(resp.json()))
    finally:
        db.close()


def test_predefined_and_no_session(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("predefined message + no-session guard → empty graph")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        pred_msg_id = str(uuid.uuid4())
        no_sess_msg_id = str(uuid.uuid4())

        predefined_msg = {
            "msg_id": pred_msg_id,
            "tuple_index": -1,
            "file_stem": "",
            "file_type": "asm",
            "phase": "predefined",
            "phase_label": "Predefined question",
            "explanation": "some answer",
            "is_complete": True,
            "created_at": "2026-01-01T00:00:00+00:00",
        }
        no_session_msg = _make_message(no_sess_msg_id, 0)

        # Conversation with no backward_session_id
        _write_conversation(kb_id, conv_id, None, "WK_VAR",
                            messages=[predefined_msg, no_session_msg])

        base = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages"

        resp = client.get(f"{base}/{pred_msg_id}/variable-lineage", headers=admin_headers)
        body = resp.json()
        check("predefined msg returns 200", resp.status_code == 200, str(body))
        check("predefined msg → empty nodes", body["full_file_flow"]["nodes"] == [], str(body))
        check("predefined msg → empty edges", body["full_file_flow"]["edges"] == [], str(body))
        check("predefined msg → root_variable set", body["root_variable"] == "WK_VAR", str(body))

        resp = client.get(f"{base}/{no_sess_msg_id}/variable-lineage", headers=admin_headers)
        body = resp.json()
        check("no-session msg returns 200", resp.status_code == 200, str(body))
        check("no-session msg → empty nodes", body["full_file_flow"]["nodes"] == [], str(body))
    finally:
        db.close()


def test_single_tuple(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("single tuple → one node, no edges")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        session_id = "1111111111111111"
        conv_id = str(uuid.uuid4())
        msg0_id = str(uuid.uuid4())

        _write_session_and_chunks(kb_id, session_id, [
            {"file_stem": "root", "file_type": "asm", "variable": "WK_VAR", "phase": "modifier"},
        ], root_variable="WK_VAR", selected_chain=["root", "mod"])

        _write_conversation(kb_id, conv_id, session_id, "WK_VAR",
                            messages=[_make_message(msg0_id, 0, "root", "asm", "modifier")],
                            selected_chain=["root", "mod"])

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg0_id}/variable-lineage",
            headers=admin_headers,
        )
        body = resp.json()
        check("single tuple returns 200", resp.status_code == 200, str(body))
        check("root_variable is WK_VAR", body["root_variable"] == "WK_VAR", str(body))

        flow = body["full_file_flow"]
        nodes = flow["nodes"]
        edges = flow["edges"]

        check("exactly 1 node returned", len(nodes) == 1, str(nodes))
        node = nodes[0]
        check("node id is root.asm", node["id"] == "root.asm", str(node))
        check("node type is asm", node["type"] == "asm", str(node))
        check("node has WK_VAR in variables", "WK_VAR" in node["variables"], str(node))
        check("no edges when only one file seen", len(edges) == 0, str(edges))
    finally:
        db.close()


def test_two_tuples_accumulate(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("two tuples → two nodes accumulated, edge appears")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        session_id = "2222222222222222"
        conv_id = str(uuid.uuid4())
        msg0_id = str(uuid.uuid4())
        msg1_id = str(uuid.uuid4())

        _write_session_and_chunks(kb_id, session_id, [
            {"file_stem": "root", "file_type": "asm", "variable": "WK_VAR", "phase": "modifier"},
            {"file_stem": "mod",  "file_type": "asm", "variable": "WK_VAR", "phase": "upstream"},
        ], root_variable="WK_VAR", selected_chain=["root", "mod"])

        _write_conversation(kb_id, conv_id, session_id, "WK_VAR",
                            messages=[
                                _make_message(msg0_id, 0, "root", "asm", "modifier"),
                                _make_message(msg1_id, 1, "mod",  "asm", "upstream"),
                            ],
                            selected_chain=["root", "mod"])

        # After tuple 0: root only, still no edges
        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg0_id}/variable-lineage",
            headers=admin_headers,
        )
        body = resp.json()
        check("after tuple-0: 1 node", len(body["full_file_flow"]["nodes"]) == 1, str(body))
        check("after tuple-0: 0 edges", len(body["full_file_flow"]["edges"]) == 0, str(body))

        # After tuple 1: both root and mod, edge should appear
        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg1_id}/variable-lineage",
            headers=admin_headers,
        )
        body = resp.json()
        check("after tuple-1: returns 200", resp.status_code == 200, str(body))

        flow = body["full_file_flow"]
        node_ids = {n["id"] for n in flow["nodes"]}
        check("after tuple-1: root.asm present", "root.asm" in node_ids, str(node_ids))
        check("after tuple-1: mod.asm present",  "mod.asm"  in node_ids, str(node_ids))
        check("after tuple-1: 2 nodes total", len(flow["nodes"]) == 2, str(flow["nodes"]))

        edges = flow["edges"]
        check("after tuple-1: 1 edge", len(edges) == 1, str(edges))
        edge = edges[0]
        check("edge source is root.asm", edge["source"] == "root.asm", str(edge))
        check("edge target is mod.asm",  edge["target"] == "mod.asm",  str(edge))
        check("ENTRC instruction maps to FUNCTION label", edge["label"] == "FUNCTION", str(edge))
    finally:
        db.close()


def test_dep_var_accumulation(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("dep_var in phase_metadata is accumulated into node variables")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        session_id = "3333333333333333"
        conv_id = str(uuid.uuid4())
        msg0_id = str(uuid.uuid4())
        msg1_id = str(uuid.uuid4())
        msg2_id = str(uuid.uuid4())

        _write_session_and_chunks(kb_id, session_id, [
            {"file_stem": "root", "file_type": "asm", "variable": "WK_VAR", "phase": "modifier"},
            {"file_stem": "mod",  "file_type": "asm", "variable": "WK_VAR", "phase": "upstream"},
            # Tuple 2: still on mod, but dep_var phase introduces DEP_X
            {
                "file_stem": "mod",
                "file_type": "asm",
                "variable": "WK_VAR",
                "phase": "dep_var_chain",
                "phase_metadata": {"dep_var": "DEP_X"},
            },
        ], root_variable="WK_VAR", selected_chain=["root", "mod"])

        _write_conversation(kb_id, conv_id, session_id, "WK_VAR",
                            messages=[
                                _make_message(msg0_id, 0, "root", "asm", "modifier"),
                                _make_message(msg1_id, 1, "mod",  "asm", "upstream"),
                                _make_message(msg2_id, 2, "mod",  "asm", "dep_var_chain"),
                            ],
                            selected_chain=["root", "mod"])

        # After tuple 2, mod.asm should have both WK_VAR and DEP_X
        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg2_id}/variable-lineage",
            headers=admin_headers,
        )
        body = resp.json()
        check("dep_var tuple returns 200", resp.status_code == 200, str(body))

        flow = body["full_file_flow"]
        mod_node = next((n for n in flow["nodes"] if n["id"] == "mod.asm"), None)
        check("mod.asm node present", mod_node is not None, str(flow["nodes"]))
        if mod_node:
            check("mod.asm has WK_VAR", "WK_VAR" in mod_node["variables"], str(mod_node))
            check("mod.asm has DEP_X from phase_metadata", "DEP_X" in mod_node["variables"], str(mod_node))
    finally:
        db.close()


def test_three_file_chain(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("three-file chain: root → mod → leaf (cpp), progressive accumulation")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        session_id = "4444444444444444"
        conv_id = str(uuid.uuid4())
        msg0_id = str(uuid.uuid4())
        msg1_id = str(uuid.uuid4())
        msg2_id = str(uuid.uuid4())

        _write_session_and_chunks(kb_id, session_id, [
            {"file_stem": "root", "file_type": "asm", "variable": "WK_VAR", "phase": "modifier"},
            {"file_stem": "mod",  "file_type": "asm", "variable": "WK_VAR", "phase": "upstream"},
            {"file_stem": "leaf", "file_type": "cpp", "variable": "HUBTXN", "phase": "cpp_dep_var_extended"},
        ], root_variable="WK_VAR", selected_chain=["root", "mod", "leaf"])

        _write_conversation(kb_id, conv_id, session_id, "WK_VAR",
                            messages=[
                                _make_message(msg0_id, 0, "root", "asm", "modifier"),
                                _make_message(msg1_id, 1, "mod",  "asm", "upstream"),
                                _make_message(msg2_id, 2, "leaf", "cpp", "cpp_dep_var_extended"),
                            ],
                            selected_chain=["root", "mod", "leaf"])

        # After tuple 2: all three files, two edges
        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg2_id}/variable-lineage",
            headers=admin_headers,
        )
        body = resp.json()
        check("three-file chain returns 200", resp.status_code == 200, str(body))

        flow = body["full_file_flow"]
        node_ids = {n["id"] for n in flow["nodes"]}
        check("root.asm present", "root.asm" in node_ids, str(node_ids))
        check("mod.asm present",  "mod.asm"  in node_ids, str(node_ids))
        check("leaf.cpp present", "leaf.cpp" in node_ids, str(node_ids))
        check("3 nodes total", len(flow["nodes"]) == 3, str(flow["nodes"]))

        leaf_node = next((n for n in flow["nodes"] if n["id"] == "leaf.cpp"), None)
        check("leaf.cpp type is cpp", leaf_node is not None and leaf_node["type"] == "cpp",
              str(leaf_node))
        check("leaf.cpp has HUBTXN", leaf_node is not None and "HUBTXN" in leaf_node["variables"],
              str(leaf_node))

        edges = flow["edges"]
        check("2 edges for 3-file chain", len(edges) == 2, str(edges))
        edge_pairs = {(e["source"], e["target"]) for e in edges}
        check("root→mod edge present", ("root.asm", "mod.asm") in edge_pairs, str(edges))
        check("mod→leaf edge present", ("mod.asm",  "leaf.cpp") in edge_pairs, str(edges))

        # CALL instruction for mod→leaf should also map to FUNCTION
        mod_leaf = next((e for e in edges if e["source"] == "mod.asm" and e["target"] == "leaf.cpp"), None)
        check("CALL instruction maps to FUNCTION label",
              mod_leaf is not None and mod_leaf["label"] == "FUNCTION", str(mod_leaf))
    finally:
        db.close()


def test_response_schema_shape(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("response schema shape validation")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        session_id = "5555555555555555"
        conv_id = str(uuid.uuid4())
        msg_id = str(uuid.uuid4())

        _write_session_and_chunks(kb_id, session_id, [
            {"file_stem": "root", "file_type": "asm", "variable": "WK_VAR", "phase": "modifier"},
        ], root_variable="WK_VAR")

        _write_conversation(kb_id, conv_id, session_id, "WK_VAR",
                            messages=[_make_message(msg_id, 0)])

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/variable-lineage",
            headers=admin_headers,
        )
        body = resp.json()
        check("status 200", resp.status_code == 200, str(resp.status_code))
        check("top-level has root_variable", "root_variable" in body, str(list(body.keys())))
        check("top-level has full_file_flow", "full_file_flow" in body, str(list(body.keys())))
        ff = body.get("full_file_flow", {})
        check("full_file_flow has nodes list", isinstance(ff.get("nodes"), list), str(ff))
        check("full_file_flow has edges list", isinstance(ff.get("edges"), list), str(ff))
        if ff.get("nodes"):
            node = ff["nodes"][0]
            check("node has id field",        "id"        in node, str(node))
            check("node has type field",       "type"      in node, str(node))
            check("node has variables field",  "variables" in node, str(node))
            check("node.variables is list",    isinstance(node["variables"], list), str(node))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Non-stubbing / dynamic-correctness tests
# ---------------------------------------------------------------------------

def test_output_reflects_session_data(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    """Prove output is driven entirely by session data, not any hardcoded value.

    Strategy: use UUID-derived variable/file names that could never appear in
    any hardcoded fixture, then assert they appear verbatim in the response.
    """
    print("\n" + "=" * 70)
    print("output reflects session data — UUID-unique names, no hardcoding")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        session_id = "aaaa000000000001"

        # Generate truly unique names at runtime
        u = uuid.uuid4().hex.upper()
        file_a = f"FILE_{u[:6]}"   # e.g. FILE_3F2A1C
        var_a  = f"VAR_{u[6:12]}"  # e.g. VAR_9D4B7E
        file_b = f"FILE_{u[12:18]}"
        var_b  = f"VAR_{u[18:24]}"

        # Add these two nodes to the call graph so the edge appears
        ws = WorkspaceManager(kb_id)
        graph = json.loads((ws.output_dir / "file_call_graph.json").read_text())
        graph["nodes"] += [
            {"id": file_a, "type": "asm", "file": f"{file_a}.asm"},
            {"id": file_b, "type": "asm", "file": f"{file_b}.asm"},
        ]
        graph["edges"].append({
            "source": file_a, "target": file_b,
            "instructions": ["ENTRC"], "call_sites": [],
        })
        _write_json(ws.output_dir / "file_call_graph.json", graph)

        conv_id = str(uuid.uuid4())
        msg0_id = str(uuid.uuid4())
        msg1_id = str(uuid.uuid4())

        _write_session_and_chunks(kb_id, session_id, [
            {"file_stem": file_a, "file_type": "asm", "variable": var_a, "phase": "modifier"},
            {"file_stem": file_b, "file_type": "asm", "variable": var_b, "phase": "upstream"},
        ], root_variable=var_a, selected_chain=[file_a, file_b])

        _write_conversation(kb_id, conv_id, session_id, var_a,
                            messages=[
                                _make_message(msg0_id, 0, file_a, "asm", "modifier"),
                                _make_message(msg1_id, 1, file_b, "asm", "upstream"),
                            ],
                            selected_chain=[file_a, file_b])

        # ------ tuple 0: only file_a, var_a ------
        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg0_id}/variable-lineage",
            headers=admin_headers,
        )
        body = resp.json()
        check("UUID-var tuple-0 returns 200", resp.status_code == 200)
        check("root_variable matches session data", body["root_variable"] == var_a,
              f"got={body['root_variable']} want={var_a}")

        nodes0 = body["full_file_flow"]["nodes"]
        ids0 = [n["id"] for n in nodes0]
        check("tuple-0 node id is runtime-generated file_a",
              ids0 == [f"{file_a}.asm"], str(ids0))
        check("tuple-0 variable is runtime-generated var_a",
              nodes0[0]["variables"] == [var_a],
              str(nodes0[0]["variables"]))
        check("tuple-0 no edges (file_b not yet seen)",
              body["full_file_flow"]["edges"] == [], str(body["full_file_flow"]["edges"]))

        # ------ tuple 1: both files ------
        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg1_id}/variable-lineage",
            headers=admin_headers,
        )
        body = resp.json()
        node_map = {n["id"]: n for n in body["full_file_flow"]["nodes"]}
        check("tuple-1 node for file_a present", f"{file_a}.asm" in node_map,
              str(list(node_map.keys())))
        check("tuple-1 node for file_b present", f"{file_b}.asm" in node_map,
              str(list(node_map.keys())))
        check("file_b node has var_b (runtime-generated)",
              var_b in (node_map.get(f"{file_b}.asm") or {}).get("variables", []),
              str(node_map.get(f"{file_b}.asm")))
        edges1 = body["full_file_flow"]["edges"]
        check("edge between file_a → file_b appears",
              any(e["source"] == f"{file_a}.asm" and e["target"] == f"{file_b}.asm"
                  for e in edges1),
              str(edges1))
    finally:
        db.close()


def test_two_sessions_same_kb_are_independent(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    """Two conversations in the same KB with different sessions must not contaminate
    each other — proves data is keyed per session, not globally cached."""
    print("\n" + "=" * 70)
    print("cross-session isolation — same KB, two sessions, independent data")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)

        u1 = uuid.uuid4().hex.upper()
        u2 = uuid.uuid4().hex.upper()
        var_x = f"XVAR_{u1[:6]}"
        var_y = f"YVAR_{u2[:6]}"

        sess_x = "bbbb000000000001"
        sess_y = "cccc000000000001"
        conv_x = str(uuid.uuid4())
        conv_y = str(uuid.uuid4())
        msg_x  = str(uuid.uuid4())
        msg_y  = str(uuid.uuid4())

        _write_session_and_chunks(kb_id, sess_x, [
            {"file_stem": "root", "file_type": "asm", "variable": var_x, "phase": "modifier"},
        ], root_variable=var_x)

        _write_session_and_chunks(kb_id, sess_y, [
            {"file_stem": "root", "file_type": "asm", "variable": var_y, "phase": "modifier"},
        ], root_variable=var_y)

        _write_conversation(kb_id, conv_x, sess_x, var_x,
                            messages=[_make_message(msg_x, 0)])
        _write_conversation(kb_id, conv_y, sess_y, var_y,
                            messages=[_make_message(msg_y, 0)])

        base = f"/v1/knowledge-bases/{kb_id}/conversations"

        body_x = client.get(f"{base}/{conv_x}/messages/{msg_x}/variable-lineage",
                            headers=admin_headers).json()
        body_y = client.get(f"{base}/{conv_y}/messages/{msg_y}/variable-lineage",
                            headers=admin_headers).json()

        vars_x = body_x["full_file_flow"]["nodes"][0]["variables"]
        vars_y = body_y["full_file_flow"]["nodes"][0]["variables"]

        check("session-X returns var_x", var_x in vars_x, f"vars_x={vars_x}")
        check("session-X does NOT return var_y", var_y not in vars_x, f"vars_x={vars_x}")
        check("session-Y returns var_y", var_y in vars_y, f"vars_y={vars_y}")
        check("session-Y does NOT return var_x", var_x not in vars_y, f"vars_y={vars_y}")
        check("root_variable for X is var_x", body_x["root_variable"] == var_x)
        check("root_variable for Y is var_y", body_y["root_variable"] == var_y)
    finally:
        db.close()


def test_edges_sourced_from_graph_file_not_session(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    """Edges must come from file_call_graph.json, not from the session's
    full_flow_edges.  We write conflicting data: the session has no edges,
    but file_call_graph.json has one — it must appear.  Then we remove the
    graph file and verify edges disappear."""
    print("\n" + "=" * 70)
    print("edges sourced from file_call_graph.json, not session full_flow_edges")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)  # creates graph with root→mod, mod→leaf
        session_id = "dddd000000000001"
        conv_id = str(uuid.uuid4())
        msg_id  = str(uuid.uuid4())

        # Session covers both root and mod but full_flow_serial has NO edges
        _write_session_and_chunks(kb_id, session_id, [
            {"file_stem": "root", "file_type": "asm", "variable": "WK_VAR", "phase": "modifier"},
            {"file_stem": "mod",  "file_type": "asm", "variable": "WK_VAR", "phase": "upstream"},
        ], root_variable="WK_VAR")

        _write_conversation(kb_id, conv_id, session_id, "WK_VAR",
                            messages=[
                                _make_message(str(uuid.uuid4()), 0),
                                _make_message(msg_id, 1, "mod", "asm", "upstream"),
                            ])

        # Graph file present → edge should appear
        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/variable-lineage",
            headers=admin_headers,
        )
        body_with_graph = resp.json()
        edges_with = body_with_graph["full_file_flow"]["edges"]
        check("edge present when graph file exists",
              any(e["source"] == "root.asm" and e["target"] == "mod.asm" for e in edges_with),
              str(edges_with))

        # Remove graph file → edges must disappear (nodes still there)
        graph_path = WorkspaceManager(kb_id).output_dir / "file_call_graph.json"
        graph_path.unlink()
        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/variable-lineage",
            headers=admin_headers,
        )
        body_no_graph = resp.json()
        check("returns 200 even without graph file", resp.status_code == 200)
        check("nodes still present without graph file",
              len(body_no_graph["full_file_flow"]["nodes"]) == 2,
              str(body_no_graph["full_file_flow"]["nodes"]))
        check("edges empty when graph file removed",
              body_no_graph["full_file_flow"]["edges"] == [],
              str(body_no_graph["full_file_flow"]["edges"]))
    finally:
        db.close()


def test_file_type_authoritative_from_graph(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    """If file_call_graph.json says a file is 'cpp' but the session reported
    'asm', the response must use 'cpp' — the graph is authoritative."""
    print("\n" + "=" * 70)
    print("file type is authoritative from file_call_graph.json")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)

        # Override: make the 'leaf' node type conflict with what the session says
        ws = WorkspaceManager(kb_id)
        # leaf is already cpp in _graph_payload(); session will claim asm
        session_id = "eeee000000000001"
        conv_id    = str(uuid.uuid4())
        msg_id     = str(uuid.uuid4())

        # Deliberately write leaf with file_type="asm" in the session
        _write_session_and_chunks(kb_id, session_id, [
            {"file_stem": "leaf", "file_type": "asm",  # session says asm …
             "variable": "TYVAR", "phase": "modifier"},
        ], root_variable="TYVAR")

        _write_conversation(kb_id, conv_id, session_id, "TYVAR",
                            messages=[_make_message(msg_id, 0, "leaf", "asm")])

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/variable-lineage",
            headers=admin_headers,
        )
        body = resp.json()
        leaf_node = next((n for n in body["full_file_flow"]["nodes"] if "leaf" in n["id"]), None)
        check("leaf node present", leaf_node is not None, str(body["full_file_flow"]["nodes"]))
        check("leaf node id uses graph-authoritative type (leaf.cpp)",
              leaf_node is not None and leaf_node["id"] == "leaf.cpp",
              str(leaf_node))
        check("leaf node type field is cpp",
              leaf_node is not None and leaf_node["type"] == "cpp",
              str(leaf_node))
    finally:
        db.close()


def test_edge_deduplication(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    """Multiple edges between the same (source, target) pair in
    file_call_graph.json must collapse to a single edge in the response."""
    print("\n" + "=" * 70)
    print("duplicate graph edges collapse to one edge in output")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)

        # Add duplicate edges between root→mod in the graph file
        ws = WorkspaceManager(kb_id)
        graph = json.loads((ws.output_dir / "file_call_graph.json").read_text())
        graph["edges"] += [
            {"source": "root", "target": "mod", "instructions": ["BALR"],  "call_sites": []},
            {"source": "root", "target": "mod", "instructions": ["ENTRC"], "call_sites": []},
        ]
        _write_json(ws.output_dir / "file_call_graph.json", graph)

        session_id = "ffff000000000001"
        conv_id    = str(uuid.uuid4())
        msg_id     = str(uuid.uuid4())

        _write_session_and_chunks(kb_id, session_id, [
            {"file_stem": "root", "file_type": "asm", "variable": "WK_VAR", "phase": "modifier"},
            {"file_stem": "mod",  "file_type": "asm", "variable": "WK_VAR", "phase": "upstream"},
        ], root_variable="WK_VAR")

        _write_conversation(kb_id, conv_id, session_id, "WK_VAR",
                            messages=[
                                _make_message(str(uuid.uuid4()), 0),
                                _make_message(msg_id, 1, "mod", "asm", "upstream"),
                            ])

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/variable-lineage",
            headers=admin_headers,
        )
        body = resp.json()
        edges = body["full_file_flow"]["edges"]
        root_mod = [e for e in edges if e["source"] == "root.asm" and e["target"] == "mod.asm"]
        check("multiple graph edges collapse to exactly 1", len(root_mod) == 1, str(edges))
    finally:
        db.close()


def test_tuple_variable_from_index_map_not_chunk_file(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    """The variable shown in the node must come from tuple_index_map[i].variable
    (what assemble_tuple returns), not from the chunk file's own 'variable' key.
    We write conflicting values and verify the map wins."""
    print("\n" + "=" * 70)
    print("variable source-of-truth is tuple_index_map (not raw chunk file)")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        session_id = "9999000000000001"
        conv_id    = str(uuid.uuid4())
        msg_id     = str(uuid.uuid4())

        # Write session normally (map_var = chunk_var here)
        _write_session_and_chunks(kb_id, session_id, [
            {"file_stem": "root", "file_type": "asm",
             "variable": "MAP_VAR", "phase": "modifier"},
        ], root_variable="MAP_VAR")

        # Now corrupt only the chunk file's 'variable' field
        sess_dir = WorkspaceManager(kb_id).output_dir / "backward_lineage" / "chunked" / session_id
        chunk_path = sess_dir / "chunk_0.json"
        chunk_data = json.loads(chunk_path.read_text())
        chunk_data["variable"] = "CHUNK_VAR_SHOULD_NOT_APPEAR"
        chunk_path.write_text(json.dumps(chunk_data))

        _write_conversation(kb_id, conv_id, session_id, "MAP_VAR",
                            messages=[_make_message(msg_id, 0)])

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/variable-lineage",
            headers=admin_headers,
        )
        body = resp.json()
        node = body["full_file_flow"]["nodes"][0] if body["full_file_flow"]["nodes"] else {}
        check("MAP_VAR (from tuple_index_map) appears in variables",
              "MAP_VAR" in node.get("variables", []), str(node))
        check("CHUNK_VAR_SHOULD_NOT_APPEAR is absent",
              "CHUNK_VAR_SHOULD_NOT_APPEAR" not in node.get("variables", []), str(node))
    finally:
        db.close()


def test_graph_grows_monotonically(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    """Each successive msg_id must return a graph that is a superset of the
    previous one — no nodes or edges disappear as the index advances."""
    print("\n" + "=" * 70)
    print("graph grows monotonically across successive msg_ids")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        session_id = "8888000000000001"
        conv_id    = str(uuid.uuid4())
        ids        = [str(uuid.uuid4()) for _ in range(3)]

        _write_session_and_chunks(kb_id, session_id, [
            {"file_stem": "root", "file_type": "asm", "variable": "V0", "phase": "modifier"},
            {"file_stem": "mod",  "file_type": "asm", "variable": "V1", "phase": "upstream"},
            {"file_stem": "leaf", "file_type": "cpp", "variable": "V2", "phase": "cpp_dep_var_extended"},
        ], root_variable="V0", selected_chain=["root", "mod", "leaf"])

        _write_conversation(kb_id, conv_id, session_id, "V0",
                            messages=[
                                _make_message(ids[0], 0, "root", "asm"),
                                _make_message(ids[1], 1, "mod",  "asm"),
                                _make_message(ids[2], 2, "leaf", "cpp"),
                            ],
                            selected_chain=["root", "mod", "leaf"])

        base = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages"
        snapshots = []
        for mid in ids:
            r = client.get(f"{base}/{mid}/variable-lineage", headers=admin_headers)
            snapshots.append(r.json()["full_file_flow"])

        # Node counts must be non-decreasing
        node_counts = [len(s["nodes"]) for s in snapshots]
        check("node count never decreases (monotone)",
              all(node_counts[i] <= node_counts[i + 1] for i in range(len(node_counts) - 1)),
              str(node_counts))
        check("node counts are 1, 2, 3", node_counts == [1, 2, 3], str(node_counts))

        # Each snapshot's node-id set must be a subset of the next
        id_sets = [{n["id"] for n in s["nodes"]} for s in snapshots]
        check("snapshot-0 nodes ⊆ snapshot-1 nodes", id_sets[0] <= id_sets[1], str(id_sets))
        check("snapshot-1 nodes ⊆ snapshot-2 nodes", id_sets[1] <= id_sets[2], str(id_sets))

        # Edge counts must be non-decreasing
        edge_counts = [len(s["edges"]) for s in snapshots]
        check("edge count never decreases (monotone)",
              all(edge_counts[i] <= edge_counts[i + 1] for i in range(len(edge_counts) - 1)),
              str(edge_counts))
        check("edge counts are 0, 1, 2", edge_counts == [0, 1, 2], str(edge_counts))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

def cleanup() -> None:
    db = SessionLocal()
    try:
        for kb_id in _CREATED_KBS:
            db.query(KnowledgeBaseAccess).filter(KnowledgeBaseAccess.kb_id == kb_id).delete()
            db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).delete()
            shutil.rmtree(WorkspaceManager(kb_id).root, ignore_errors=True)
        for username in _CREATED_USERS:
            db.query(User).filter(User.username == username).delete()
        db.commit()
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    create_tables()
    suffix = uuid.uuid4().hex[:8]
    admin_username = f"vl_admin_{suffix}"
    user_username  = f"vl_user_{suffix}"

    db = SessionLocal()
    try:
        _create_user(db, admin_username, role="admin")
        _create_user(db, user_username,  role="user")
        db.commit()
    finally:
        db.close()

    admin_headers = _auth_headers(admin_username, "admin")
    user_headers  = _auth_headers(user_username,  "user")

    try:
        with TestClient(app) as client:
            test_auth_and_routing(client, admin_headers, user_headers, admin_username)
            test_predefined_and_no_session(client, admin_headers, admin_username)
            test_single_tuple(client, admin_headers, admin_username)
            test_two_tuples_accumulate(client, admin_headers, admin_username)
            test_dep_var_accumulation(client, admin_headers, admin_username)
            test_three_file_chain(client, admin_headers, admin_username)
            test_response_schema_shape(client, admin_headers, admin_username)
            # Dynamic-correctness / non-stubbing tests
            test_output_reflects_session_data(client, admin_headers, admin_username)
            test_two_sessions_same_kb_are_independent(client, admin_headers, admin_username)
            test_edges_sourced_from_graph_file_not_session(client, admin_headers, admin_username)
            test_file_type_authoritative_from_graph(client, admin_headers, admin_username)
            test_edge_deduplication(client, admin_headers, admin_username)
            test_tuple_variable_from_index_map_not_chunk_file(client, admin_headers, admin_username)
            test_graph_grows_monotonically(client, admin_headers, admin_username)
    finally:
        cleanup()

    print("\n" + "=" * 70)
    print(f"RESULT  PASS={PASS}  FAIL={FAIL}")
    print("=" * 70)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
