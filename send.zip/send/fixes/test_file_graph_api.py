#!/usr/bin/env python3
"""Focused validation for the chunked backward-lineage file-graph API."""

from __future__ import annotations

import json
import shutil
import sys
import uuid
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, List
from unittest import mock

import msgpack
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from api.app import app  # noqa: E402
from api.auth import create_access_token, hash_password  # noqa: E402
from api.db import SessionLocal, create_tables  # noqa: E402
from api.models.knowledge_base import KnowledgeBase, KnowledgeBaseAccess  # noqa: E402
from api.models.user import User  # noqa: E402
from api.storage.workspace import WorkspaceManager  # noqa: E402
from backward_traversal.runner.chunked_session import compute_session_id, get_session_dir, get_session_file  # noqa: E402

PASS = 0
FAIL = 0
_CREATED_KBS: List[str] = []
_CREATED_USERS: List[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS   {name}" + (f" -- {detail}" if detail else ""))
    else:
        FAIL += 1
        print(f"  FAIL   {name}" + (f" -- {detail}" if detail else ""))


def _write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _graph_payload() -> Dict[str, Any]:
    return {
        "nodes": [
            {"id": "root", "type": "asm", "file": "root.asm"},
            {"id": "mod", "type": "asm", "file": "mod.asm"},
        ],
        "edges": [
            {
                "source": "root",
                "target": "mod",
                "instructions": ["ENTRC"],
                "call_sites": [{"line": 7}],
                "is_internal": True,
            }
        ],
    }


def _modifier_blueprint(variable: str = "WK_VAR") -> Dict[str, Any]:
    return {
        "meta": {"aliases": []},
        "blocks": [
            {
                "id": "B1",
                "flow": [
                    {"line": 5, "inst": "MVC", "args": [variable, "SOURCE"]},
                ],
            }
        ],
    }


def _non_setter_blueprint() -> Dict[str, Any]:
    return {
        "meta": {"aliases": []},
        "blocks": [
            {
                "id": "B1",
                "flow": [
                    {"line": 5, "inst": "CLC", "args": ["WK_VAR", "SOURCE"]},
                ],
            }
        ],
    }


def _session_state(kb_id: str, session_id: str, *, state_kb_id: str | None = None, malformed_graph: bool = False) -> Dict[str, Any]:
    full_flow_serial: Dict[str, Any]
    if malformed_graph:
        full_flow_serial = {"nodes": {"root": {"file_type": "asm"}}, "edges": {}}
    else:
        full_flow_serial = {
            "nodes": {
                "root": {
                    "id": "root",
                    "file_type": "asm",
                    "scope_variables": ["WK_VAR"],
                    "in_selected_chain": True,
                    "roles": ["selected_chain"],
                },
                "mod": {
                    "id": "mod",
                    "file_type": "asm",
                    "scope_variables": ["WK_VAR"],
                    "in_selected_chain": True,
                    "roles": ["modifier", "selected_chain"],
                },
            },
            "edges": {
                "root|mod": {
                    "source": "root",
                    "target": "mod",
                    "instructions": ["ENTRC"],
                    "scope_variables": ["WK_VAR"],
                    "discovered_from": ["chain_upstream"],
                    "source_blocks": [],
                    "lines": [7],
                }
            },
        }
    return {
        "session_id": session_id,
        "kb_id": state_kb_id or kb_id,
        "root_variable": "WK_VAR",
        "selected_chain": ["root", "mod"],
        "phase": "COMPLETE",
        "tuple_index_map": [
            {
                "chunk_file": "chunk_0.json",
                "file_stem": "mod",
                "file_type": "asm",
                "variable": "WK_VAR",
                "phase": "modifier",
                "node_count": 1,
            }
        ],
        "warnings": ["synthetic warning"],
        "full_flow_serial": full_flow_serial,
    }


def _write_session(kb_id: str, session_id: str, state: Dict[str, Any]) -> None:
    path = get_session_file(kb_id, session_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(msgpack.packb(state, use_bin_type=True))
    _write_json(
        get_session_dir(kb_id, session_id) / "chunk_0.json",
        {
            "variable": "WK_VAR",
            "phase": "modifier",
            "metadata": {
                "bp_path": None,
                "asm_file": None,
                "anchor_blocks": [],
                "scope_label": None,
                "summary": "synthetic tuple",
                "phase_metadata": {},
                "intra_tuple_edges": [],
                "cross_file_calls_out": [],
            },
            "nodes": [{"id": "n1", "line": 5}],
        },
    )


def _create_user(db, username: str, role: str = "user") -> User:
    user = User(
        username=username,
        hashed_password=hash_password("TestPass123!"),
        role=role,
        is_active=True,
    )
    db.add(user)
    _CREATED_USERS.append(username)
    return user


def _create_kb(db, kb_id: str, *, status: str = "success", created_by: str = "admin") -> KnowledgeBase:
    kb = KnowledgeBase(
        id=kb_id,
        name=f"File Graph API Test {kb_id}",
        created_by=created_by,
        datasource_username=None,
        datasource_folder=None,
        source_path="/tmp/src",
        status=status,
        error=None,
    )
    db.add(kb)
    _CREATED_KBS.append(kb_id)
    return kb


def _auth_headers(username: str, role: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {create_access_token(username, role)}"}


def _prepare_success_kb(db, admin_username: str) -> str:
    kb_id = str(uuid.uuid4())
    _create_kb(db, kb_id, status="success", created_by=admin_username)
    db.commit()
    ws = WorkspaceManager(kb_id)
    for d in (ws.root, ws.input_dir, ws.output_dir, ws.cache_dir):
        d.mkdir(parents=True, exist_ok=True)
    _write_json(ws.output_dir / "file_call_graph.json", _graph_payload())
    _write_json(ws.output_dir / "mod.asm.json", _modifier_blueprint())
    return kb_id


def test_new_file_graph_endpoint(client: TestClient, admin_headers: Dict[str, str], user_headers: Dict[str, str], admin_username: str) -> None:
    print("\n" + "=" * 78)
    print("new file-graph endpoint validation")
    print("=" * 78)

    db = SessionLocal()
    try:
        kb_id = _prepare_success_kb(db, admin_username)
        valid_session = "0123456789abcdef"
        _write_session(kb_id, valid_session, _session_state(kb_id, valid_session))

        resp = client.get(f"/v1/knowledge-bases/{kb_id}/backward-lineage/sessions/{valid_session}/file-graph")
        check("unauthenticated request returns 401", resp.status_code == 401, detail=str(resp.json()))

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/backward-lineage/sessions/{valid_session}/file-graph",
            headers=user_headers,
        )
        check("inaccessible KB returns 403", resp.status_code == 403, detail=str(resp.json()))

        resp = client.get(
            f"/v1/knowledge-bases/{uuid.uuid4()}/backward-lineage/sessions/{valid_session}/file-graph",
            headers=admin_headers,
        )
        check("missing KB returns 404", resp.status_code == 404, detail=str(resp.json()))

        pending_kb = str(uuid.uuid4())
        _create_kb(db, pending_kb, status="running", created_by=admin_username)
        db.commit()
        resp = client.get(
            f"/v1/knowledge-bases/{pending_kb}/backward-lineage/sessions/{valid_session}/file-graph",
            headers=admin_headers,
        )
        check("KB not success returns 409", resp.status_code == 409, detail=str(resp.json()))

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/backward-lineage/sessions/NOT_HEX/file-graph",
            headers=admin_headers,
        )
        check("invalid session id returns 422", resp.status_code == 422, detail=str(resp.json()))

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/backward-lineage/sessions/ffffffffffffffff/file-graph",
            headers=admin_headers,
        )
        check("missing session returns 404", resp.status_code == 404, detail=str(resp.json()))

        malformed_id = "aaaaaaaaaaaaaaaa"
        bad_path = get_session_file(kb_id, malformed_id)
        bad_path.parent.mkdir(parents=True, exist_ok=True)
        bad_path.write_bytes(b"not-msgpack")
        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/backward-lineage/sessions/{malformed_id}/file-graph",
            headers=admin_headers,
        )
        check("malformed session returns 422", resp.status_code == 422, detail=str(resp.json()))

        mismatch_id = "bbbbbbbbbbbbbbbb"
        _write_session(kb_id, mismatch_id, _session_state(kb_id, mismatch_id, state_kb_id=str(uuid.uuid4())))
        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/backward-lineage/sessions/{mismatch_id}/file-graph",
            headers=admin_headers,
        )
        check("session KB mismatch returns 409", resp.status_code == 409, detail=str(resp.json()))

        graph_malformed_id = "cccccccccccccccc"
        _write_session(kb_id, graph_malformed_id, _session_state(kb_id, graph_malformed_id, malformed_graph=True))
        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/backward-lineage/sessions/{graph_malformed_id}/file-graph",
            headers=admin_headers,
        )
        check("malformed graph state returns 422", resp.status_code == 422, detail=str(resp.json()))

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/backward-lineage/sessions/{valid_session}/file-graph",
            headers=admin_headers,
        )
        body = resp.json()
        check("valid session returns 200", resp.status_code == 200, detail=str(body))
        check("valid response has kb_id", body.get("kb_id") == kb_id, detail=str(body))
        check("valid response has session_id", body.get("session_id") == valid_session, detail=str(body))
        check("valid response has root_variable", body.get("root_variable") == "WK_VAR", detail=str(body))
        check("valid response has selected_chain", body.get("selected_chain") == ["root", "mod"], detail=str(body))
        check("valid response has tuple_count", body.get("tuple_count") == 1, detail=str(body))
        check("valid response has warnings", body.get("warnings") == ["synthetic warning"], detail=str(body))
        flow = body.get("full_file_flow") or {}
        check("full_file_flow.nodes is list", isinstance(flow.get("nodes"), list), detail=str(flow))
        check("full_file_flow.edges is list", isinstance(flow.get("edges"), list), detail=str(flow))
        check("full_file_flow includes selected node", any(n.get("id") == "mod" for n in flow.get("nodes", [])), detail=str(flow))
        check("full_file_flow includes selected edge", any(e.get("source") == "root" and e.get("target") == "mod" for e in flow.get("edges", [])), detail=str(flow))
    finally:
        db.close()


def test_existing_chunked_api_contract(client: TestClient, admin_headers: Dict[str, str], admin_username: str) -> None:
    print("\n" + "=" * 78)
    print("existing chunked API contract regression")
    print("=" * 78)

    db = SessionLocal()
    try:
        kb_id = _prepare_success_kb(db, admin_username)
        graph_file = WorkspaceManager(kb_id).output_dir / "file_call_graph.json"
        session_id = compute_session_id(
            kb_id=kb_id,
            variable="WK_VAR",
            chain_files=["root", "mod"],
            options={
                "max_depth": 8,
                "max_subroutine_depth": 2,
                "max_subroutine_nodes": 400,
                "max_trace_nodes": 5000,
                "max_dep_vars": 20,
                "max_dep_var_depth": 2,
                "max_downstream_depth": 2,
                "max_downstream_files": 30,
                "t8_max_scan": 0,
            },
            graph_file_mtime=graph_file.stat().st_mtime,
        )
        _write_session(kb_id, session_id, _session_state(kb_id, session_id))

        resp = client.post(
            f"/v1/knowledge-bases/{kb_id}/backward-lineage/chunks",
            headers=admin_headers,
            json={
                "variable_name": "WK_VAR",
                "chain_files": ["root", "mod"],
                "start_tuple_index": 0,
            },
        )
        check("chunked cache-hit request still succeeds", resp.status_code == 202, detail=str(resp.json()))
        job_body = resp.json()
        check("chunked JobResponse operation unchanged", job_body.get("operation") == "kb_backward_lineage_chunked", detail=str(job_body))
        check("chunked JobResponse has no graph field", "full_file_flow" not in job_body, detail=str(job_body))

        chunk_resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/files/backward_lineage/WK_VAR_tuple_0.json",
            headers=admin_headers,
        )
        check("chunked output page is downloadable", chunk_resp.status_code == 200, detail=chunk_resp.text[:300])
        page = chunk_resp.json()
        check("chunked page has no top-level full_file_flow", "full_file_flow" not in page, detail=str(page))
        check("chunked page still has tuple", isinstance(page.get("tuple"), dict), detail=str(page))
        tuple_obj = page.get("tuple") or {}
        check("tuple.full_flow_edges remains present", "full_flow_edges" in tuple_obj, detail=str(tuple_obj))
        check("tuple.full_flow_edges contains graph edge", any(e.get("source") == "root" and e.get("target") == "mod" for e in tuple_obj.get("full_flow_edges", [])), detail=str(tuple_obj))
    finally:
        db.close()


def test_existing_chunked_api_validation_and_dispatch(client: TestClient, admin_headers: Dict[str, str], admin_username: str) -> None:
    print("\n" + "=" * 78)
    print("existing chunked API validation + dispatch")
    print("=" * 78)

    from api.tasks import kb_backward_lineage_chunked_task

    db = SessionLocal()
    try:
        kb_id = _prepare_success_kb(db, admin_username)

        resp = client.post(
            f"/v1/knowledge-bases/{kb_id}/backward-lineage/chunks",
            json={"variable_name": "WK_VAR", "chain_files": ["root", "mod"]},
        )
        check("chunked unauthenticated request returns 401", resp.status_code == 401, detail=str(resp.json()))

        resp = client.post(
            f"/v1/knowledge-bases/{uuid.uuid4()}/backward-lineage/chunks",
            headers=admin_headers,
            json={"variable_name": "WK_VAR", "chain_files": ["root", "mod"]},
        )
        check("chunked missing KB returns 404", resp.status_code == 404, detail=str(resp.json()))

        running_kb = str(uuid.uuid4())
        _create_kb(db, running_kb, status="running", created_by=admin_username)
        db.commit()
        resp = client.post(
            f"/v1/knowledge-bases/{running_kb}/backward-lineage/chunks",
            headers=admin_headers,
            json={"variable_name": "WK_VAR", "chain_files": ["root", "mod"]},
        )
        check("chunked KB not success returns 409", resp.status_code == 409, detail=str(resp.json()))

        no_graph_kb = str(uuid.uuid4())
        _create_kb(db, no_graph_kb, status="success", created_by=admin_username)
        db.commit()
        ws_no_graph = WorkspaceManager(no_graph_kb)
        for d in (ws_no_graph.root, ws_no_graph.input_dir, ws_no_graph.output_dir, ws_no_graph.cache_dir):
            d.mkdir(parents=True, exist_ok=True)
        resp = client.post(
            f"/v1/knowledge-bases/{no_graph_kb}/backward-lineage/chunks",
            headers=admin_headers,
            json={"variable_name": "WK_VAR", "chain_files": ["root", "mod"]},
        )
        check("chunked missing graph returns 409", resp.status_code == 409, detail=str(resp.json()))

        resp = client.post(
            f"/v1/knowledge-bases/{kb_id}/backward-lineage/chunks",
            headers=admin_headers,
            json={"variable_name": "WK_VAR", "chain_files": ["root", "missing"]},
        )
        check("chunked missing chain node returns 422", resp.status_code == 422, detail=str(resp.json()))

        resp = client.post(
            f"/v1/knowledge-bases/{kb_id}/backward-lineage/chunks",
            headers=admin_headers,
            json={
                "variable_name": "WK_VAR",
                "chain_files": ["root", "mod"],
                "asm_dir": "/definitely/not/a/real/asm/dir",
            },
        )
        check("chunked invalid asm_dir returns 422", resp.status_code == 422, detail=str(resp.json()))

        no_modifier_kb = _prepare_success_kb(db, admin_username)
        ws_no_modifier = WorkspaceManager(no_modifier_kb)
        (ws_no_modifier.output_dir / "mod.asm.json").unlink(missing_ok=True)
        _write_json(ws_no_modifier.output_dir / "root.asm.json", _modifier_blueprint())
        resp = client.post(
            f"/v1/knowledge-bases/{no_modifier_kb}/backward-lineage/chunks",
            headers=admin_headers,
            json={"variable_name": "WK_VAR", "chain_files": ["root", "mod"]},
        )
        check("chunked missing modifier blueprint returns 422", resp.status_code == 422, detail=str(resp.json()))

        no_setter_kb = _prepare_success_kb(db, admin_username)
        _write_json(WorkspaceManager(no_setter_kb).output_dir / "mod.asm.json", _non_setter_blueprint())
        resp = client.post(
            f"/v1/knowledge-bases/{no_setter_kb}/backward-lineage/chunks",
            headers=admin_headers,
            json={"variable_name": "WK_VAR", "chain_files": ["root", "mod"]},
        )
        check("chunked modifier without setter returns 422", resp.status_code == 422, detail=str(resp.json()))

        resp = client.post(
            f"/v1/knowledge-bases/{kb_id}/backward-lineage/chunks",
            headers=admin_headers,
            json={"variable_name": "WK_VAR", "chain_files": ["root", "mod"], "start_tuple_index": 1},
        )
        check("chunked first request cannot start after zero", resp.status_code == 400, detail=str(resp.json()))

        graph_file = WorkspaceManager(kb_id).output_dir / "file_call_graph.json"
        session_id = compute_session_id(
            kb_id=kb_id,
            variable="WK_VAR",
            chain_files=["root", "mod"],
            options={
                "max_depth": 8,
                "max_subroutine_depth": 2,
                "max_subroutine_nodes": 400,
                "max_trace_nodes": 5000,
                "max_dep_vars": 20,
                "max_dep_var_depth": 2,
                "max_downstream_depth": 2,
                "max_downstream_files": 30,
                "t8_max_scan": 0,
            },
            graph_file_mtime=graph_file.stat().st_mtime,
        )
        _write_session(kb_id, session_id, _session_state(kb_id, session_id))
        resp = client.post(
            f"/v1/knowledge-bases/{kb_id}/backward-lineage/chunks",
            headers=admin_headers,
            json={"variable_name": "WK_VAR", "chain_files": ["root", "mod"], "start_tuple_index": 1},
        )
        check("chunked complete session rejects out-of-range tuple", resp.status_code == 409, detail=str(resp.json()))

        dispatch_kb = _prepare_success_kb(db, admin_username)
        with mock.patch.object(
            kb_backward_lineage_chunked_task.run_kb_backward_lineage_chunked,
            "apply_async",
            return_value=SimpleNamespace(id="task-chunked-123"),
        ):
            resp = client.post(
                f"/v1/knowledge-bases/{dispatch_kb}/backward-lineage/chunks",
                headers=admin_headers,
                json={"variable_name": "WK_VAR", "chain_files": ["root", "mod"], "start_tuple_index": 0},
            )
        body = resp.json()
        check("chunked non-cache dispatch returns 202", resp.status_code == 202, detail=str(body))
        check("chunked dispatch status is pending", body.get("status") == "pending", detail=str(body))
        check("chunked dispatch operation unchanged", body.get("operation") == "kb_backward_lineage_chunked", detail=str(body))
        check("chunked dispatch returns celery task id", body.get("celery_task_id") == "task-chunked-123", detail=str(body))
        check("chunked dispatch JobResponse has no graph field", "full_file_flow" not in body, detail=str(body))
    finally:
        db.close()


def cleanup() -> None:
    db = SessionLocal()
    try:
        for kb_id in _CREATED_KBS:
            db.query(KnowledgeBaseAccess).filter(KnowledgeBaseAccess.kb_id == kb_id).delete()
            db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).delete()
            shutil.rmtree(WorkspaceManager(kb_id).root, ignore_errors=True)
        for username in _CREATED_USERS:
            db.query(User).filter(User.username == username).delete()
        db.commit()
    finally:
        db.close()


def main() -> int:
    create_tables()
    suffix = uuid.uuid4().hex[:8]
    admin_username = f"fg_admin_{suffix}"
    user_username = f"fg_user_{suffix}"

    db = SessionLocal()
    try:
        _create_user(db, admin_username, role="admin")
        _create_user(db, user_username, role="user")
        db.commit()
    finally:
        db.close()

    admin_headers = _auth_headers(admin_username, "admin")
    user_headers = _auth_headers(user_username, "user")

    try:
        with TestClient(app) as client:
            test_new_file_graph_endpoint(client, admin_headers, user_headers, admin_username)
            test_existing_chunked_api_contract(client, admin_headers, admin_username)
            test_existing_chunked_api_validation_and_dispatch(client, admin_headers, admin_username)
    finally:
        cleanup()

    print("\n" + "=" * 78)
    print(f"RESULT: PASS={PASS} FAIL={FAIL}")
    print("=" * 78)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
