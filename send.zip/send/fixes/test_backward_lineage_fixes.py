#!/usr/bin/env python3
"""Comprehensive validation tests for all BACKWARD_LINEAGE_TEST_SPEC.md fixes.

Coverage:
  C1.3  — visited_dep_vars starts empty in new ChunkedBackwardSession
  C1.4  — _is_followable_cross_file_call imported and used (not _is_returning_)
  C2.1  — find_cpp_seed_nodes emits warning when returning empty list
  C2.3  — GAP B routing in chunked_session + backward_only_runner warns on no next_asm
  C2.4  — cpp_backward_tracer BFS queue is 3-tuple (per-path alias budget)
  C2.5  — gvl.get() with isinstance check (not getattr)
  C3.2  — VariableNameResolver warns when identity index absent
  C4.1  — STMG: 2 in DEST_ARG_INDEX_BY_INST
  C4.2  — LGH, LT, LTG in REGISTER_LOAD_FROM_MEM; LTGR in REGISTER_COPY_FROM_REG
  C4.3  — LLGFR: 1 in REGISTER_COPY_FROM_REG
  C5.1  — _dedup_key includes line as 4th element
  C5.2  — find_asm_callers warns when asm_dir is None and call sites have line numbers
  C6.1  — page_data includes job_id and kb_id in KB chunked task + route cache-hit
  C6.2  — filter_tuple_to_scope applied in both KB chunked paths
  C6.3  — output_name honoured in process chunked task
  C6.4  — edge pair validation (422 for non-edge chain) in KB chunked route
  C6.5  — compress_output field in ChunkedBackwardLineageRequest + wired through
  C6.6  — _resolve_asm_dir warns when returning None (both tasks)
  C6.7  — .hpp chain entry rejected (422) in KB chunked route
  C7.1  — call_line=0 guard in asm_backward_tracer start-block skip
  C7.2  — unresolved subroutine expansion warning includes caller_block + call_line
"""
from __future__ import annotations

import inspect
import json
import logging
import shutil
import sys
import uuid
from pathlib import Path
from typing import Any, Dict, List
from unittest.mock import patch

import msgpack
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

# Polyfill blueprint_io.iter_flow if not present
try:
    import blueprint_io as _bio
    if not hasattr(_bio, "iter_flow"):
        def _iter_flow(block):
            yield from (block.get("flow") or [])
        _bio.iter_flow = _iter_flow
except ImportError:
    pass

from api.app import app
from api.auth import create_access_token, hash_password
from api.config import settings
from api.db import SessionLocal, create_tables
from api.models.knowledge_base import KnowledgeBase, KnowledgeBaseAccess
from api.models.user import User
from api.storage.workspace import WorkspaceManager

# ---------------------------------------------------------------------------
# Test accounting
# ---------------------------------------------------------------------------

PASS = 0
FAIL = 0
_CREATED_KBS: List[str] = []
_CREATED_USERS: List[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS  {name}" + (f"  [{detail}]" if detail else ""))
    else:
        FAIL += 1
        print(f"  FAIL  {name}" + (f"  [{detail}]" if detail else ""))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _create_user(db, username: str, role: str = "user") -> User:
    user = User(
        username=username,
        hashed_password=hash_password("TestPass123!"),
        role=role,
        is_active=True,
    )
    db.add(user)
    _CREATED_USERS.append(username)
    return user


def _create_kb(db, kb_id: str, *, created_by: str, source_path: str = "/tmp/src") -> KnowledgeBase:
    kb = KnowledgeBase(
        id=kb_id,
        name=f"BL Fix Test {kb_id[:8]}",
        created_by=created_by,
        datasource_username=None,
        datasource_folder=None,
        source_path=source_path,
        status="success",
    )
    db.add(kb)
    access = KnowledgeBaseAccess(kb_id=kb_id, username=created_by, granted_by=created_by)
    db.add(access)
    _CREATED_KBS.append(kb_id)
    return kb


def _setup_kb_output(kb_id: str, graph_nodes: list, graph_edges: list,
                     blueprint_stems: list | None = None) -> Path:
    """Write minimal KB output directory for route handler tests."""
    kb_output = settings.JOBS_BASE_DIR / kb_id / "output"
    kb_output.mkdir(parents=True, exist_ok=True)

    # file_call_graph.json
    (kb_output / "file_call_graph.json").write_text(
        json.dumps({"nodes": graph_nodes, "edges": graph_edges}),
        encoding="utf-8",
    )

    # Minimal .asm.json blueprints
    bp_dir = kb_output / "asm"
    bp_dir.mkdir(exist_ok=True)
    for stem in (blueprint_stems or []):
        (bp_dir / f"{stem}.asm.json").write_text(
            json.dumps({
                "file": f"{stem}.asm",
                "blocks": [],
                "call_graph": {"edges": []},
                "symbols": {"global_symbols": {}},
                "subroutines": [],
            }),
            encoding="utf-8",
        )

    # variable_identity_index.json (empty)
    (kb_output / "variable_identity_index.json").write_text("{}", encoding="utf-8")
    return kb_output


def _teardown_kb(kb_id: str) -> None:
    kb_dir = settings.JOBS_BASE_DIR / kb_id
    if kb_dir.exists():
        shutil.rmtree(kb_dir)


# ---------------------------------------------------------------------------
# Section 1 — Instruction table checks (C4.1, C4.2, C4.3)
# ---------------------------------------------------------------------------

def test_instruction_tables() -> None:
    print("\n=== C4.1 / C4.2 / C4.3 — Instruction tables ===")
    from backward_traversal.glossary.instructions import (
        DEST_ARG_INDEX_BY_INST,
        REGISTER_COPY_FROM_REG,
        REGISTER_LOAD_FROM_MEM,
    )
    check("C4.1 STMG in DEST_ARG_INDEX_BY_INST", "STMG" in DEST_ARG_INDEX_BY_INST)
    check("C4.1 STMG index == 2", DEST_ARG_INDEX_BY_INST.get("STMG") == 2)
    check("C4.2 LGH in REGISTER_LOAD_FROM_MEM", "LGH" in REGISTER_LOAD_FROM_MEM)
    check("C4.2 LT  in REGISTER_LOAD_FROM_MEM", "LT" in REGISTER_LOAD_FROM_MEM)
    check("C4.2 LTG in REGISTER_LOAD_FROM_MEM", "LTG" in REGISTER_LOAD_FROM_MEM)
    check("C4.2 LTGR in REGISTER_COPY_FROM_REG", "LTGR" in REGISTER_COPY_FROM_REG)
    check("C4.3 LLGFR in REGISTER_COPY_FROM_REG", "LLGFR" in REGISTER_COPY_FROM_REG)
    check("C4.3 LLGFR index == 1", REGISTER_COPY_FROM_REG.get("LLGFR") == 1)


# ---------------------------------------------------------------------------
# Section 2 — C5.1 dedup key includes line number
# ---------------------------------------------------------------------------

def test_dedup_key() -> None:
    print("\n=== C5.1 — _dedup_key includes line ===")
    from backward_traversal.bridge.cross_file_bridge_backward import find_cpp_to_cpp_callers
    src = inspect.getsource(find_cpp_to_cpp_callers)
    # The _dedup_key lambda should include p.get("line")
    check("C5.1 dedup key contains 'line'", "p.get(\"line\")" in src or "get('line')" in src)

    # Also verify _dedup_key returns a 4-tuple by direct inspection of nested fn
    import backward_traversal.bridge.cross_file_bridge_backward as _mod
    full_src = inspect.getsource(_mod)
    check("C5.1 4-element dedup tuple",
          "caller_function" in full_src and "callee_function" in full_src
          and "file" in full_src and "line" in full_src)


# ---------------------------------------------------------------------------
# Section 3 — C5.2 find_asm_callers warns when asm_dir=None
# ---------------------------------------------------------------------------

def test_find_asm_callers_warns_no_asm_dir() -> None:
    print("\n=== C5.2 — find_asm_callers warns when asm_dir=None ===")
    from backward_traversal.bridge.cross_file_bridge_backward import find_asm_callers

    # Build a minimal blueprint dir with one edge that has a line number
    tmp = Path(f"/tmp/bl_fix_test_{uuid.uuid4().hex[:8]}")
    tmp.mkdir()
    try:
        caller_bp = {
            "call_graph": {
                "edges": [
                    {"source": "ROUTINE_A", "target": "CALLEE_MODULE",
                     "line": 42, "file": "caller.asm",
                     "instruction": "ENTRC", "call_type": "subroutine_call"}
                ]
            },
            "blocks": [],
        }
        (tmp / "caller.asm.json").write_text(json.dumps(caller_bp))

        with patch("backward_traversal.bridge.cross_file_bridge_backward.logger") as mock_log:
            result = find_asm_callers("caller", "CALLEE_MODULE", tmp, asm_dir=None)
            warned = mock_log.warning.called
            check("C5.2 call sites returned without asm_dir", len(result) >= 1)
            check("C5.2 warning emitted when asm_dir=None and line exists", warned)
            check("C5.2 raw_line is None when asm_dir=None",
                  all(cs.get("raw_line") is None for cs in result))
    finally:
        shutil.rmtree(tmp)


# ---------------------------------------------------------------------------
# Section 4 — C2.1 find_cpp_seed_nodes warns when empty
# ---------------------------------------------------------------------------

def test_find_cpp_seed_nodes_warns_empty() -> None:
    print("\n=== C2.1 — find_cpp_seed_nodes warns when no seeds found ===")
    import logging as _logging_mod
    from backward_traversal.utils.cpp_lineage_utils import find_cpp_seed_nodes

    empty_gvl: Dict[str, Any] = {"nodes": [], "edges": []}

    # Capture all warnings emitted during the call via a log handler
    captured: List[str] = []

    class _CapHandler(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            if record.levelno >= logging.WARNING:
                captured.append(self.format(record))

    handler = _CapHandler()
    root_logger = _logging_mod.getLogger()
    root_logger.addHandler(handler)
    old_level = root_logger.level
    root_logger.setLevel(logging.WARNING)
    try:
        seeds = find_cpp_seed_nodes(empty_gvl, "NONEXISTENT_VAR", {}, {})
    finally:
        root_logger.removeHandler(handler)
        root_logger.setLevel(old_level)

    check("C2.1 returns empty list when no seeds", seeds == [])
    check("C2.1 warning emitted", len(captured) > 0, f"captured: {captured}")
    if captured:
        combined = " ".join(captured)
        check("C2.1 warning mentions variable name", "NONEXISTENT_VAR" in combined)


# ---------------------------------------------------------------------------
# Section 5 — C7.2 subroutine expansion warning includes caller_block
# ---------------------------------------------------------------------------

def test_subroutine_expansion_warning() -> None:
    print("\n=== C7.2 — Unresolved subroutine warning includes caller_block ===")
    from backward_traversal.tracing import asm_backward_tracer
    src = inspect.getsource(asm_backward_tracer._trace_subroutine_expansion)
    # C7.2 fix appends a warning with [C7.2] tag and includes caller_block/call_line
    check("C7.2 [C7.2] tag in unresolved warning", "[C7.2]" in src)
    check("C7.2 caller_block referenced in warning", "caller_block" in src)
    check("C7.2 call_line referenced in warning", "call_line" in src)
    check("C7.2 warning appended before returning unresolved",
          "warnings.append" in src and "unresolved" in src.lower())


# ---------------------------------------------------------------------------
# Section 6 — C7.1 call_line=0 guard in start-block skip
# ---------------------------------------------------------------------------

def test_call_line_zero_guard() -> None:
    print("\n=== C7.1 — call_line=0 guard prevents skipping start block ===")
    from backward_traversal.tracing import asm_backward_tracer
    src = inspect.getsource(asm_backward_tracer)
    # The guard: `if call_line and e_line >= call_line` (truthy prevents line 0 case)
    check("C7.1 truthy call_line guard present",
          "if call_line and" in src or "call_line and e_line" in src)


# ---------------------------------------------------------------------------
# Section 7 — C4.2 via instructions import (already in section 1, confirm LG/LGR exist)
# ---------------------------------------------------------------------------

def test_lg_lgr_present() -> None:
    print("\n=== C4.4 — LG and LGR present in instruction sets ===")
    from backward_traversal.glossary.instructions import (
        REGISTER_LOAD_FROM_MEM, REGISTER_COPY_FROM_REG
    )
    check("C4.4 LG in REGISTER_LOAD_FROM_MEM", "LG" in REGISTER_LOAD_FROM_MEM)
    check("C4.4 LGR in REGISTER_COPY_FROM_REG", "LGR" in REGISTER_COPY_FROM_REG)


# ---------------------------------------------------------------------------
# Section 8 — C2.4 BFS queue is 3-tuple in cpp_backward_tracer
# ---------------------------------------------------------------------------

def test_cpp_bfs_3tuple_queue() -> None:
    print("\n=== C2.4 — cpp_backward_tracer uses 3-tuple BFS queue ===")
    from backward_traversal.tracing import cpp_backward_tracer
    src = inspect.getsource(cpp_backward_tracer)
    # Queue entries should be (node_id, depth, alias_hops_on_path)
    check("C2.4 alias_hops_on_path in source", "alias_hops_on_path" in src)
    check("C2.4 no global alias_hops_taken counter",
          "alias_hops_taken: int = 0" not in src and
          "alias_hops_taken = 0" not in src)


# ---------------------------------------------------------------------------
# Section 9 — C2.5 gvl.get() with isinstance in cpp_backward_tracer
# ---------------------------------------------------------------------------

def test_gvl_get_isinstance() -> None:
    print("\n=== C2.5 — gvl.get() with isinstance check ===")
    from backward_traversal.tracing import cpp_backward_tracer
    src = inspect.getsource(cpp_backward_tracer)
    check("C2.5 isinstance(gvl, dict) check present", "isinstance(gvl, dict)" in src)
    check("C2.5 getattr(gvl, 'file_size_bytes' pattern removed",
          "getattr(gvl, \"file_size_bytes\"" not in src and
          "getattr(gvl, 'file_size_bytes'" not in src)


# ---------------------------------------------------------------------------
# Section 10 — C1.3 visited_dep_vars starts empty in new session
# ---------------------------------------------------------------------------

def test_visited_dep_vars_empty_init() -> None:
    print("\n=== C1.3 — visited_dep_vars starts empty in new ChunkedBackwardSession ===")
    from backward_traversal.runner.chunked_session import ChunkedBackwardSession

    # Inspect _new_state or similar initialization
    src = inspect.getsource(ChunkedBackwardSession)
    # Should NOT pre-seed with root_var:  "visited_dep_vars": [root_var]  is the old bug
    check("C1.3 visited_dep_vars not pre-seeded",
          '"visited_dep_vars": [root_var]' not in src and
          "'visited_dep_vars': [root_var]" not in src)
    # Should init as empty list
    check("C1.3 visited_dep_vars initialized empty",
          '"visited_dep_vars": []' in src or "'visited_dep_vars': []" in src)


# ---------------------------------------------------------------------------
# Section 11 — C1.4 _is_followable_cross_file_call used (not _is_returning_)
# ---------------------------------------------------------------------------

def test_followable_filter_used() -> None:
    print("\n=== C1.4 — _is_followable_cross_file_call used at downstream call sites ===")
    from backward_traversal.runner import chunked_session
    src = inspect.getsource(chunked_session)
    check("C1.4 _is_followable_cross_file_call imported",
          "_is_followable_cross_file_call" in src)
    # Count usages in filter expressions
    usage_count = src.count("_is_followable_cross_file_call(")
    check("C1.4 used at ≥4 call sites", usage_count >= 4, f"found {usage_count} usages")


# ---------------------------------------------------------------------------
# Section 12 — C2.3 GAP B routing in chunked_session
# ---------------------------------------------------------------------------

def test_gap_b_routing_chunked_session() -> None:
    print("\n=== C2.3 — GAP B routing implemented in chunked_session ===")
    from backward_traversal.runner.chunked_session import ChunkedBackwardSession
    src = inspect.getsource(ChunkedBackwardSession._update_dep_var_map_cpp)
    check("C2.3 bridge_back_to_asm routing present", "bridge_back_to_asm:" in src)
    check("C2.3 next_asm routing logic present", "next_asm" in src)
    check("C2.3 warning when no next_asm",
          "logger.warning" in src and "bridge_back_to_asm" in src)
    check("C2.3 forward search present", "selected_chain[stem_idx + 1:]" in src)
    check("C2.3 backward search present", "reversed(selected_chain[" in src)


# ---------------------------------------------------------------------------
# Section 13 — C2.3 GAP B warning in backward_only_runner
# ---------------------------------------------------------------------------

def test_gap_b_warning_backward_only_runner() -> None:
    print("\n=== C2.3 — backward_only_runner warns when no next_asm ===")
    from backward_traversal.runner import backward_only_runner
    src = inspect.getsource(backward_only_runner)
    # Find the section after the backward search loop for bridge_back_to_asm
    check("C2.3 BOR: GAP B warning present",
          "bridge_back_to_asm" in src and "no adjacent" in src)


# ---------------------------------------------------------------------------
# Section 14 — C3.2 VariableNameResolver warns when index absent
# ---------------------------------------------------------------------------

def test_resolver_warns_no_index() -> None:
    print("\n=== C3.2 — VariableNameResolver warns when identity index absent ===")
    from backward_traversal.utils.variable_name_resolver import VariableNameResolver
    src = inspect.getsource(VariableNameResolver)
    check("C3.2 warning in _get_index when path None",
          "not found" in src.lower() or "warning" in src.lower())

    # Use __init__ with a blueprint_dir that has no variable_identity_index.json
    # so _find_index_path returns None → _path is None → warning fires in _get_index
    tmp = Path(f"/tmp/bl_fix_nr_{uuid.uuid4().hex[:8]}")
    tmp.mkdir()
    captured: List[str] = []

    class _Cap(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            if record.levelno >= logging.WARNING:
                captured.append(record.getMessage())

    handler = _Cap()
    root_logger = logging.getLogger()
    root_logger.addHandler(handler)
    old_level = root_logger.level
    root_logger.setLevel(logging.WARNING)
    try:
        # __init__ calls _find_index_path which returns None → _path = None
        resolver = VariableNameResolver(tmp)
        check("C3.2 _path is None when index file absent", resolver._path is None)
        # calling _get_index triggers the warning (first call only)
        resolver._get_index()
        check("C3.2 warning emitted when index file missing",
              len(captured) > 0, f"captured={captured}")
    finally:
        root_logger.removeHandler(handler)
        root_logger.setLevel(old_level)
        shutil.rmtree(tmp)


# ---------------------------------------------------------------------------
# Section 15 — C6.5 compress_output field in ChunkedBackwardLineageRequest
# ---------------------------------------------------------------------------

def test_compress_output_schema() -> None:
    print("\n=== C6.5 — compress_output in ChunkedBackwardLineageRequest ===")
    from api.routes.knowledge_base import ChunkedBackwardLineageRequest
    fields = ChunkedBackwardLineageRequest.model_fields
    check("C6.5 compress_output field exists", "compress_output" in fields)
    check("C6.5 compress_output default is False",
          fields["compress_output"].default is False)


# ---------------------------------------------------------------------------
# Section 16 — C6.1 page_data has job_id + kb_id (source inspection)
# ---------------------------------------------------------------------------

def test_page_data_schema_alignment() -> None:
    print("\n=== C6.1 — page_data includes job_id + kb_id ===")
    from api.tasks import kb_backward_lineage_chunked_task
    src = inspect.getsource(kb_backward_lineage_chunked_task)
    check("C6.1 job_id in task page_data", '"job_id": job_id' in src)
    check("C6.1 kb_id in task page_data", '"kb_id": kb_id' in src)

    from api.routes import knowledge_base
    route_src = inspect.getsource(knowledge_base.submit_kb_backward_lineage_chunked)
    check("C6.1 job_id in route cache-hit page_data", '"job_id": job_id' in route_src)
    check("C6.1 kb_id in route cache-hit page_data", '"kb_id": kb_id' in route_src)


# ---------------------------------------------------------------------------
# Section 17 — C6.6 _resolve_asm_dir warns when returning None
# ---------------------------------------------------------------------------

def test_resolve_asm_dir_warns() -> None:
    print("\n=== C6.6 — _resolve_asm_dir warns when returning None ===")
    from api.tasks import kb_backward_lineage_chunked_task, process_lineage_chunked_task
    kb_src = inspect.getsource(kb_backward_lineage_chunked_task._resolve_asm_dir)
    proc_src = inspect.getsource(process_lineage_chunked_task._resolve_asm_dir)
    check("C6.6 KB task _resolve_asm_dir warns", "logger.warning" in kb_src)
    check("C6.6 process task _resolve_asm_dir warns", "logger.warning" in proc_src)


# ---------------------------------------------------------------------------
# Section 18 — C6.3 output_name honoured in process task
# ---------------------------------------------------------------------------

def test_output_name_honoured() -> None:
    print("\n=== C6.3 — output_name honoured in process_lineage_chunked_task ===")
    from api.tasks import process_lineage_chunked_task
    src = inspect.getsource(process_lineage_chunked_task._run)
    check("C6.3 output_name read from options", "output_name" in src)
    check("C6.3 page_filename set from output_name", "_oname" in src)


# ---------------------------------------------------------------------------
# Section 19 — C6.2 filter_tuple_to_scope applied in KB chunked paths
# ---------------------------------------------------------------------------

def test_filter_tuple_to_scope_applied() -> None:
    print("\n=== C6.2 — filter_tuple_to_scope applied in KB chunked task + route ===")
    from api.tasks import kb_backward_lineage_chunked_task
    task_src = inspect.getsource(kb_backward_lineage_chunked_task)
    check("C6.2 filter_tuple_to_scope imported in KB task",
          "filter_tuple_to_scope" in task_src)
    check("C6.2 ProcessScope built from chain in KB task",
          "ProcessScope" in task_src)

    from api.routes import knowledge_base
    route_src = inspect.getsource(knowledge_base.submit_kb_backward_lineage_chunked)
    check("C6.2 filter_tuple_to_scope in route cache-hit", "filter_tuple_to_scope" in route_src)
    check("C6.2 ProcessScope in route cache-hit", "ProcessScope" in route_src)


# ---------------------------------------------------------------------------
# Section 20 — C6.4 / C6.7 via API (FastAPI TestClient)
# ---------------------------------------------------------------------------

def test_api_edge_and_hpp_validation() -> None:
    print("\n=== C6.4 / C6.7 — API: edge validation + .hpp rejection ===")
    create_tables()
    db = SessionLocal()
    kb_id = str(uuid.uuid4())
    username = f"bl_fix_user_{uuid.uuid4().hex[:8]}"
    try:
        user = _create_user(db, username, role="admin")
        db.flush()
        _create_kb(db, kb_id, created_by=user.username)
        db.flush()
        db.commit()

        # Set up KB output with two nodes and one edge: foo→bar
        _setup_kb_output(
            kb_id,
            graph_nodes=[{"id": "foo"}, {"id": "bar"}, {"id": "baz"}],
            graph_edges=[{"source": "foo", "target": "bar"}],
            blueprint_stems=["foo", "bar", "baz"],
        )

        token = create_access_token(user.username, user.role)
        headers = {"Authorization": f"Bearer {token}"}
        client = TestClient(app, raise_server_exceptions=False)
        base_url = f"/v1/knowledge-bases/{kb_id}/backward-lineage/chunks"

        # C6.7 — .hpp entry in chain should return 422
        r = client.post(base_url, headers=headers, json={
            "variable_name": "MYVAR",
            "chain_files": ["foo", "my_header.hpp"],
        })
        check("C6.7 .hpp stem rejected with 422", r.status_code == 422,
              f"got {r.status_code}")
        if r.status_code == 422:
            check("C6.7 error mentions .hpp", ".hpp" in r.text.lower())

        # C6.4 — chain with no call-graph edge between foo and baz → 422
        r = client.post(base_url, headers=headers, json={
            "variable_name": "MYVAR",
            "chain_files": ["foo", "baz"],
        })
        check("C6.4 missing-edge chain rejected with 422", r.status_code == 422,
              f"got {r.status_code}")
        if r.status_code == 422:
            check("C6.4 error mentions edge or chain",
                  "edge" in r.text.lower() or "chain" in r.text.lower())

        # C6.4 — valid chain foo→bar should NOT get a 422 from edge check
        # (it will fail later since there's no blueprint pipeline output, but not a 422 edge error)
        r_valid = client.post(base_url, headers=headers, json={
            "variable_name": "MYVAR",
            "chain_files": ["foo", "bar"],
        })
        check("C6.4 valid chain not rejected for missing edge",
              r_valid.status_code != 422 or "edge" not in r_valid.text.lower(),
              f"got {r_valid.status_code}")

        # C6.5 — compress_output field accepted without error (schema-level)
        r_compress = client.post(base_url, headers=headers, json={
            "variable_name": "MYVAR",
            "chain_files": ["foo", "bar"],
            "compress_output": True,
        })
        # compress_output is a valid schema field; any 422 here comes from later
        # business-logic validation (modifier check), not schema rejection.
        check("C6.5 compress_output accepted by schema (no schema-422)",
              r_compress.status_code != 422 or "compress_output" not in r_compress.text.lower(),
              f"got {r_compress.status_code}")

    finally:
        db.close()
        _teardown_kb(kb_id)


# ---------------------------------------------------------------------------
# Section 21 — C6.5 compress_outputs wired in task + route
# ---------------------------------------------------------------------------

def test_compress_output_wired() -> None:
    print("\n=== C6.5 — compress_output wired through task and route cache-hit ===")
    from api.tasks import kb_backward_lineage_chunked_task
    task_src = inspect.getsource(kb_backward_lineage_chunked_task._run)
    check("C6.5 compress_output check in task", "compress_output" in task_src)
    check("C6.5 compress_outputs called in task", "compress_outputs" in task_src)

    from api.routes import knowledge_base
    route_src = inspect.getsource(knowledge_base.submit_kb_backward_lineage_chunked)
    check("C6.5 compress_output check in route cache-hit", "compress_output" in route_src)
    check("C6.5 compress_outputs called in route cache-hit", "compress_outputs" in route_src)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    test_instruction_tables()
    test_dedup_key()
    test_find_asm_callers_warns_no_asm_dir()
    test_find_cpp_seed_nodes_warns_empty()
    test_subroutine_expansion_warning()
    test_call_line_zero_guard()
    test_lg_lgr_present()
    test_cpp_bfs_3tuple_queue()
    test_gvl_get_isinstance()
    test_visited_dep_vars_empty_init()
    test_followable_filter_used()
    test_gap_b_routing_chunked_session()
    test_gap_b_warning_backward_only_runner()
    test_resolver_warns_no_index()
    test_compress_output_schema()
    test_page_data_schema_alignment()
    test_resolve_asm_dir_warns()
    test_output_name_honoured()
    test_filter_tuple_to_scope_applied()
    test_api_edge_and_hpp_validation()
    test_compress_output_wired()

    print(f"\n{'='*50}")
    print(f"  Results: {PASS} passed, {FAIL} failed")
    print(f"{'='*50}")
    if FAIL:
        sys.exit(1)


if __name__ == "__main__":
    main()
