#!/usr/bin/env python3
"""Validation tests for POST .../predefined-question/stream (SSE endpoint).

Tests verify:
  1. Auth / routing (401, 403, 404, 422)
  2. Unknown question_id → 404
  3. SSE event contract — chunk events + done event with type/msg_id/text/explanation/created_at
  4. explanation == text in done event
  5. User message pre-persisted with question_id field before streaming
  6. Bot message post-persisted with same msg_id as done event
  7. GET /chatbot returns predefined-question messages with correct roles
  8. Old non-streaming POST .../predefined-question is retired (404)
"""
from __future__ import annotations

import json
import shutil
import sys
import uuid
from pathlib import Path
from typing import Any, Dict, List
from unittest import mock

import msgpack
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from api.app import app  # noqa: E402
from api.auth import create_access_token, hash_password  # noqa: E402
from api.config import settings  # noqa: E402
from api.db import SessionLocal, create_tables  # noqa: E402
from api.models.knowledge_base import KnowledgeBase, KnowledgeBaseAccess  # noqa: E402
from api.models.user import User  # noqa: E402
from api.storage.workspace import WorkspaceManager  # noqa: E402

# ---------------------------------------------------------------------------
# Test accounting
# ---------------------------------------------------------------------------

PASS = 0
FAIL = 0
_CREATED_KBS: List[str] = []
_CREATED_USERS: List[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS  {name}" + (f"  [{detail}]" if detail else ""))
    else:
        FAIL += 1
        print(f"  FAIL  {name}" + (f"  [{detail}]" if detail else ""))


# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------

def _create_user(db, username: str, role: str = "user") -> User:
    user = User(
        username=username,
        hashed_password=hash_password("TestPass123!"),
        role=role,
        is_active=True,
    )
    db.add(user)
    _CREATED_USERS.append(username)
    return user


def _create_kb(
    db, kb_id: str, *, status: str = "success", created_by: str = "admin"
) -> KnowledgeBase:
    kb = KnowledgeBase(
        id=kb_id,
        name=f"PredQ Test {kb_id[:8]}",
        created_by=created_by,
        datasource_username=None,
        datasource_folder=None,
        source_path="/tmp/src",
        status=status,
        error=None,
    )
    db.add(kb)
    _CREATED_KBS.append(kb_id)
    return kb


def _auth_headers(username: str, role: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {create_access_token(username, role)}"}


def _prepare_kb(db, admin_username: str) -> str:
    kb_id = str(uuid.uuid4())
    _create_kb(db, kb_id, status="success", created_by=admin_username)
    db.commit()
    ws = WorkspaceManager(kb_id)
    for d in (ws.root, ws.input_dir, ws.output_dir, ws.cache_dir):
        d.mkdir(parents=True, exist_ok=True)
    # Seed predefined questions for the test process ("lu82") so the
    # endpoint's _load_process_questions lookup succeeds.
    q_dir = ws.output_dir / "processes" / "lu82"
    q_dir.mkdir(parents=True, exist_ok=True)
    (q_dir / "predefined_questions.json").write_text(
        json.dumps({"questions": [
            {"id": _QUESTION_ID, "text": _QUESTION_TEXT},
            {"id": "q2", "text": "Can you summarize this process?"},
        ]}),
        encoding="utf-8",
    )
    return kb_id


def _write_conversation(
    kb_id: str,
    conv_id: str,
    *,
    keyword: str = "WK_TIME",
    chat_session_id: str | None = None,
) -> None:
    conv_dir = WorkspaceManager(kb_id).output_dir / "conversations"
    conv_dir.mkdir(parents=True, exist_ok=True)
    conv: Dict[str, Any] = {
        "version": 1,
        "conv_id": conv_id,
        "process": "lu82",
        "keyword": keyword,
        "backward_session_id": None,
        "root_variable": keyword,
        "selected_chain": [],
        "keyword_file_flows": [],
        "messages": [],
        "chat_session_id": chat_session_id,
        "created_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-01T00:00:00+00:00",
    }
    (conv_dir / f"{conv_id}.msgpack").write_bytes(msgpack.packb(conv, use_bin_type=True))


def _parse_sse(content: str) -> List[Dict[str, Any]]:
    events: List[Dict[str, Any]] = []
    for line in content.splitlines():
        line = line.strip()
        if line.startswith("data:"):
            payload = line[5:].strip()
            try:
                events.append(json.loads(payload))
            except json.JSONDecodeError:
                pass
    return events


def _load_conv(kb_id: str, conv_id: str) -> Dict[str, Any]:
    path = WorkspaceManager(kb_id).output_dir / "conversations" / f"{conv_id}.msgpack"
    return msgpack.unpackb(path.read_bytes(), raw=False)


def _load_chat_session(kb_id: str, chat_session_id: str) -> Dict[str, Any]:
    path = (
        settings.JOBS_BASE_DIR
        / kb_id
        / "output"
        / "chat_sessions"
        / f"{chat_session_id}.msgpack"
    )
    return msgpack.unpackb(path.read_bytes(), raw=False)


# Known predefined question IDs (from _PREDEFINED_QUESTIONS in conversations.py)
_QUESTION_ID = "q1"
_QUESTION_TEXT = "What is this variable used for?"

# Controlled LLM output
_CHUNKS: List[str] = ["WK_TIME ", "tracks ", "the work ", "timestamp."]
_FULL_REPLY: str = "".join(_CHUNKS)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_auth_and_routing(
    client: TestClient,
    admin_headers: Dict[str, str],
    user_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("1. auth + routing")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/predefined-question/stream"

        # Unauthenticated
        resp = client.post(url, json={"question_id": _QUESTION_ID})
        check("unauthenticated → 401", resp.status_code == 401, str(resp.status_code))

        # Regular user without KB access
        resp = client.post(url, json={"question_id": _QUESTION_ID}, headers=user_headers)
        check("no-access user → 403", resp.status_code == 403, str(resp.status_code))

        # Unknown KB
        resp = client.post(
            f"/v1/knowledge-bases/{uuid.uuid4()}/conversations/{conv_id}/predefined-question/stream",
            json={"question_id": _QUESTION_ID},
            headers=admin_headers,
        )
        check("unknown KB → 404", resp.status_code == 404, str(resp.status_code))

        # Unknown conversation
        resp = client.post(
            f"/v1/knowledge-bases/{kb_id}/conversations/{uuid.uuid4()}/predefined-question/stream",
            json={"question_id": _QUESTION_ID},
            headers=admin_headers,
        )
        check("unknown conv → 404", resp.status_code == 404, str(resp.status_code))

        # Empty question_id (Pydantic min_length=1)
        resp = client.post(url, json={"question_id": ""}, headers=admin_headers)
        check("empty question_id → 422", resp.status_code == 422, str(resp.status_code))

        # Missing question_id field
        resp = client.post(url, json={}, headers=admin_headers)
        check("missing question_id → 422", resp.status_code == 422, str(resp.status_code))

        # Valid request (with mocked LLM)
        with mock.patch("llm.caller.stream_llm", return_value=iter(_CHUNKS)):
            resp = client.post(url, json={"question_id": _QUESTION_ID}, headers=admin_headers)
        check("valid request → 200", resp.status_code == 200, str(resp.status_code))
    finally:
        db.close()


def test_unknown_question_id_404(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("2. unknown question_id → 404")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/predefined-question/stream"

        resp = client.post(url, json={"question_id": "q999"}, headers=admin_headers)
        check("unknown question_id → 404", resp.status_code == 404, str(resp.status_code))

        body = resp.json()
        check("error detail mentions question_id",
              "q999" in body.get("detail", ""),
              body.get("detail", ""))
    finally:
        db.close()


def test_sse_event_contract(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("3. SSE event contract")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/predefined-question/stream"

        with mock.patch("llm.caller.stream_llm", return_value=iter(_CHUNKS)):
            resp = client.post(url, json={"question_id": _QUESTION_ID}, headers=admin_headers)

        check("status 200", resp.status_code == 200, str(resp.status_code))
        check(
            "Content-Type: text/event-stream",
            "text/event-stream" in resp.headers.get("content-type", ""),
            resp.headers.get("content-type", ""),
        )

        events = _parse_sse(resp.text)
        check(f"parsed ≥ {len(_CHUNKS) + 1} events", len(events) >= len(_CHUNKS) + 1,
              f"got {len(events)}")

        chunk_events = [e for e in events if e.get("type") == "chunk"]
        done_events  = [e for e in events if e.get("type") == "done"]

        check(f"exactly {len(_CHUNKS)} chunk events", len(chunk_events) == len(_CHUNKS),
              f"got {len(chunk_events)}")
        check("exactly 1 done event", len(done_events) == 1, f"got {len(done_events)}")

        for i, ce in enumerate(chunk_events):
            check(f"chunk[{i}].type == 'chunk'", ce.get("type") == "chunk", str(ce))
            check(f"chunk[{i}].text present", "text" in ce and ce["text"] != "", str(ce))

        got_chunks = [ce["text"] for ce in chunk_events]
        check("chunk texts match mock output in order", got_chunks == _CHUNKS, str(got_chunks))

        done = done_events[0] if done_events else {}

        check("done.type == 'done'", done.get("type") == "done", str(done))
        check("done.msg_id present", bool(done.get("msg_id")), str(done))
        check("done.msg_id starts with 'cm-'",
              str(done.get("msg_id", "")).startswith("cm-"),
              done.get("msg_id", ""))
        check("done.msg_id is bot id (not cm-u- prefix)",
              not str(done.get("msg_id", "")).startswith("cm-u-"),
              done.get("msg_id", ""))
        check("done.text present", bool(done.get("text")), str(done))
        check("done.explanation present", bool(done.get("explanation")), str(done))
        check("done.created_at present", bool(done.get("created_at")), str(done))
        check(
            "done.text == concatenation of all chunk texts",
            done.get("text") == _FULL_REPLY,
            f"got={done.get('text')!r}  want={_FULL_REPLY!r}",
        )
        check(
            "done.explanation == done.text",
            done.get("explanation") == done.get("text"),
            f"explanation={done.get('explanation')!r}  text={done.get('text')!r}",
        )
        check("done event is last in stream", events[-1].get("type") == "done",
              str(events[-1]))
    finally:
        db.close()


def test_user_message_pre_persisted(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("4. user message pre-persisted with question_id field")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/predefined-question/stream"

        with mock.patch("llm.caller.stream_llm", return_value=iter(_CHUNKS)):
            resp = client.post(url, json={"question_id": _QUESTION_ID}, headers=admin_headers)
        assert resp.status_code == 200, f"POST failed: {resp.status_code}"

        conv_data = _load_conv(kb_id, conv_id)
        chat_session_id = conv_data.get("chat_session_id")
        check("chat_session_id written to conversation", bool(chat_session_id),
              str(chat_session_id))

        if not chat_session_id:
            return

        session = _load_chat_session(kb_id, chat_session_id)
        msgs = session.get("messages") or []
        check("session has ≥ 1 message", len(msgs) >= 1, str(len(msgs)))

        user_msg = next((m for m in msgs if m.get("role") == "user"), None)
        check("user message exists in session", user_msg is not None,
              str([m.get("role") for m in msgs]))

        if user_msg is None:
            return

        check("user message content == question text",
              user_msg.get("content") == _QUESTION_TEXT,
              f"got={user_msg.get('content')!r}")
        check("user message has question_id field",
              "question_id" in user_msg,
              str(list(user_msg.keys())))
        check("user message question_id == submitted question_id",
              user_msg.get("question_id") == _QUESTION_ID,
              f"got={user_msg.get('question_id')!r}")
        check("user message msg_id starts with 'cm-u-'",
              str(user_msg.get("msg_id", "")).startswith("cm-u-"),
              user_msg.get("msg_id", ""))
    finally:
        db.close()


def test_bot_message_post_persisted(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("5. bot message post-persisted, msg_id matches done event")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/predefined-question/stream"

        with mock.patch("llm.caller.stream_llm", return_value=iter(_CHUNKS)):
            resp = client.post(url, json={"question_id": _QUESTION_ID}, headers=admin_headers)
        assert resp.status_code == 200

        events = _parse_sse(resp.text)
        done = next((e for e in events if e.get("type") == "done"), {})
        done_msg_id = done.get("msg_id", "")

        conv_data = _load_conv(kb_id, conv_id)
        chat_session_id = conv_data.get("chat_session_id")
        if not chat_session_id:
            check("chat_session_id present (required)", False, "chat_session_id missing")
            return

        session = _load_chat_session(kb_id, chat_session_id)
        msgs = session.get("messages") or []
        check("exactly 2 messages in session (user + bot)", len(msgs) == 2, str(len(msgs)))

        bot_msg = next((m for m in msgs if m.get("role") == "assistant"), None)
        check("bot message exists in session (role=assistant)",
              bot_msg is not None,
              str([m.get("role") for m in msgs]))

        if bot_msg is None:
            return

        check("bot message content == full reply",
              bot_msg.get("content") == _FULL_REPLY,
              f"got={bot_msg.get('content')!r}")
        check("bot message msg_id starts with 'cm-'",
              str(bot_msg.get("msg_id", "")).startswith("cm-"),
              bot_msg.get("msg_id", ""))
        check("bot message msg_id matches done event msg_id",
              bot_msg.get("msg_id") == done_msg_id,
              f"session={bot_msg.get('msg_id')}  done={done_msg_id}")

        # Also verify conv["messages"] was updated
        conv_msgs = conv_data.get("messages") or []
        check("conv messages includes predefined-question entry",
              any(m.get("phase") == "predefined" for m in conv_msgs),
              str([m.get("phase") for m in conv_msgs]))
        predefined_msg = next((m for m in conv_msgs if m.get("phase") == "predefined"), {})
        check("conv predefined entry msg_id matches done event",
              predefined_msg.get("msg_id") == done_msg_id,
              f"conv={predefined_msg.get('msg_id')}  done={done_msg_id}")
    finally:
        db.close()


def test_get_chatbot_returns_messages(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("6. GET /chatbot returns predefined-question messages")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        stream_url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/predefined-question/stream"
        list_url   = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/chatbot"

        with mock.patch("llm.caller.stream_llm", return_value=iter(_CHUNKS)):
            stream_resp = client.post(stream_url, json={"question_id": _QUESTION_ID},
                                      headers=admin_headers)
        assert stream_resp.status_code == 200

        done = next(
            (e for e in _parse_sse(stream_resp.text) if e.get("type") == "done"), {}
        )
        done_msg_id = done.get("msg_id", "")

        list_resp = client.get(list_url, headers=admin_headers)
        check("GET /chatbot → 200", list_resp.status_code == 200,
              str(list_resp.status_code))

        msgs = list_resp.json().get("messages", [])
        check("GET /chatbot returns 2 messages (user + bot)", len(msgs) == 2,
              str(len(msgs)))

        user_m = next((m for m in msgs if m.get("role") == "user"), {})
        bot_m  = next((m for m in msgs if m.get("role") == "bot"),  {})

        check("user message present with role='user'",
              bool(user_m), str([m.get("role") for m in msgs]))
        check("user message content == question text",
              user_m.get("text") == _QUESTION_TEXT,
              f"got={user_m.get('text')!r}")
        check("user msg_id starts with 'cm-u-'",
              str(user_m.get("id", "")).startswith("cm-u-"),
              user_m.get("id", ""))

        check("bot message present with role='bot' (not 'assistant')",
              bool(bot_m), str([m.get("role") for m in msgs]))
        check("bot msg_id starts with 'cm-'",
              str(bot_m.get("id", "")).startswith("cm-"),
              bot_m.get("id", ""))
        check("bot msg_id from GET == done event msg_id",
              bot_m.get("id") == done_msg_id,
              f"GET={bot_m.get('id')}  done={done_msg_id}")
        check("bot text == full reply",
              bot_m.get("text") == _FULL_REPLY,
              f"got={bot_m.get('text')!r}")
    finally:
        db.close()


def test_old_endpoint_retired(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("7. old non-streaming POST .../predefined-question is retired")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        old_url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/predefined-question"
        resp = client.post(old_url, json={"question_id": _QUESTION_ID},
                           headers=admin_headers)
        check("old non-streaming endpoint returns 404 or 405",
              resp.status_code in (404, 405),
              str(resp.status_code))
        check("old endpoint does NOT return 200",
              resp.status_code != 200,
              str(resp.status_code))
    finally:
        db.close()


def test_multi_question_no_duplication(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("8. multi-question — second call appends 2 more messages, no duplication")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/predefined-question/stream"

        # Turn 1 — q1
        with mock.patch("llm.caller.stream_llm", return_value=iter(_CHUNKS)):
            resp1 = client.post(url, json={"question_id": "q1"}, headers=admin_headers)
        assert resp1.status_code == 200

        # Turn 2 — q2
        with mock.patch("llm.caller.stream_llm", return_value=iter(["Second answer."])):
            resp2 = client.post(url, json={"question_id": "q2"}, headers=admin_headers)
        assert resp2.status_code == 200

        conv_data = _load_conv(kb_id, conv_id)
        session   = _load_chat_session(kb_id, conv_data["chat_session_id"])
        msgs      = session.get("messages") or []

        check("exactly 4 messages after 2 predefined questions (no duplication)",
              len(msgs) == 4, str(len(msgs)))

        roles = [m.get("role") for m in msgs]
        check("roles alternate user/assistant",
              roles == ["user", "assistant", "user", "assistant"],
              str(roles))

        # Verify both user messages carry their respective question_ids
        user_msgs = [m for m in msgs if m.get("role") == "user"]
        q_ids = [m.get("question_id") for m in user_msgs]
        check("first user message has question_id q1",
              q_ids[0] == "q1" if q_ids else False,
              str(q_ids))
        check("second user message has question_id q2",
              q_ids[1] == "q2" if len(q_ids) > 1 else False,
              str(q_ids))

        # Verify done events have distinct msg_ids
        done1 = next((e for e in _parse_sse(resp1.text) if e.get("type") == "done"), {})
        done2 = next((e for e in _parse_sse(resp2.text) if e.get("type") == "done"), {})
        check("turn-1 and turn-2 done msg_ids are distinct",
              done1.get("msg_id") != done2.get("msg_id"),
              f"t1={done1.get('msg_id')}  t2={done2.get('msg_id')}")
        check("turn-2 done.text == 'Second answer.'",
              done2.get("text") == "Second answer.",
              done2.get("text", ""))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

def cleanup() -> None:
    db = SessionLocal()
    try:
        for kb_id in _CREATED_KBS:
            db.query(KnowledgeBaseAccess).filter(
                KnowledgeBaseAccess.kb_id == kb_id
            ).delete()
            db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).delete()
            shutil.rmtree(WorkspaceManager(kb_id).root, ignore_errors=True)
        for username in _CREATED_USERS:
            db.query(User).filter(User.username == username).delete()
        db.commit()
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    create_tables()
    suffix = uuid.uuid4().hex[:8]
    admin_username = f"pqs_admin_{suffix}"
    user_username  = f"pqs_user_{suffix}"

    db = SessionLocal()
    try:
        _create_user(db, admin_username, role="admin")
        _create_user(db, user_username,  role="user")
        db.commit()
    finally:
        db.close()

    admin_headers = _auth_headers(admin_username, "admin")
    user_headers  = _auth_headers(user_username,  "user")

    try:
        with TestClient(app) as client:
            test_auth_and_routing(client, admin_headers, user_headers, admin_username)
            test_unknown_question_id_404(client, admin_headers, admin_username)
            test_sse_event_contract(client, admin_headers, admin_username)
            test_user_message_pre_persisted(client, admin_headers, admin_username)
            test_bot_message_post_persisted(client, admin_headers, admin_username)
            test_get_chatbot_returns_messages(client, admin_headers, admin_username)
            test_old_endpoint_retired(client, admin_headers, admin_username)
            test_multi_question_no_duplication(client, admin_headers, admin_username)
    finally:
        cleanup()

    print(f"\n{'=' * 70}")
    print(f"Results: {PASS} PASS / {FAIL} FAIL / {PASS + FAIL} total")
    print(f"{'=' * 70}")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
