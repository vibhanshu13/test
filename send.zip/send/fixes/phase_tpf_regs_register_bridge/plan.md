# TPF_regs End-to-End Register Bridge

**Status:** NOT STARTED.
**Source plan:** `docs/plans/2026-04-23-cpp-variable-lineage-strategy 1.md` §3.4, §6.4 (explicitly deferred within Phase 4).
**Depends on:** Phase 6 (commit `1543e55`).

---

## 1. The gap

C++ passes data to ASM via a register-bearing struct (`TPF_regs`):

```cpp
TPF_regs regs;
regs.r7 = (int) ecbptr()->ce1cr7;     // R7 = work block ptr
regs.r4 = (int) ecbptr()->ce1cr6;     // R4 = log record ptr
regs.r3 = (int) ecbptr()->ce1cr4;     // R3 = input message
buildLg1g1(&regs);                    // calls ASM routine DA78
returnCode = regs.r0;                 // R0 = ASM return code
```

ASM side inside DA78:
```asm
*   R7 = work block pointer, R4 = log, R3 = input
         USING WK_REC, R7
         L     R5, 0(R4)
```

Current handling (`passes/variable_lineage_builder.py::model_tpf_regs_passthrough`,
line ~2908) hard-codes only R0 (return), R1 (input), R2 (return). Slots
R3–RF — which carry the majority of real data in z/TPF calls — are
**not represented** in the lineage graph. The plan explicitly called
this out as deferred.

---

## 2. What this phase adds

1. **Input register coverage R0–RF.** Extend
   `model_tpf_regs_passthrough` to emit one assign edge per register slot
   actually written on the regs object *before* a TPF_regs-style call,
   rather than the current R0/R1/R2 hardcode.

2. **Return register coverage R0/R2/R15.** Same treatment for reads of
   `regs.rN` *after* the call. (R15 is the z/TPF return-code convention
   in some routines.)

3. **ASM-side narrow alias.** A new stitcher pass
   `_stitch_tpf_regs_register_bridge` that, for each `arg@<callee>:R<n>`
   node produced by step 1, annotates the node with
   `{bridge_to: "R<n>", callee_asm: "<routine>"}` metadata AND — when an
   ASM routine of that name exists in the merged graph — creates a
   narrow alias edge to the ASM `register:R<n>` node with `scope=<callee>`
   and `expression="global_lineage_stitch:tpf_regs_register_bridge"`.
   The scope qualifier disambiguates the shared `register:R<n>` node
   across routines.

Steps 1 and 2 are pure C++ lineage enrichment. Step 3 is the
cross-language bridge. Together they let a reader trace
`ecbptr()->ce1cr7 → regs.r7 → arg@buildLg1g1:R7 → register:R7` (scoped
to DA78) and forward into the ASM routine's usages.

---

## 3. Scope

### In scope
- All 16 registers (R0–RF / R0–R15).
- Both `regs.rN` and `regs->rN` member-access forms.
- The existing heuristic for *which* function call binds the TPF_regs
  pointer (already done by the builder via `bridge_callee` detection).

### Out of scope
- Per-routine register scoping in the ASM graph (`register:R7@DA78`).
  We use the narrow-alias-edge approach (plan §6.4 option b).
- Condition-register slots (`r0h`, `r0l` sub-halves). The bridge
  operates at the word-register level only.
- Legacy SVC / macro-based register passing. TPF_regs convention only.

---

## 4. Files touched

| File | Change |
|---|---|
| `passes/variable_lineage_builder.py` | Generalize `model_tpf_regs_passthrough` to accept discovered input/return slot sets; compute them from `register_slots` already gathered at the call site. |
| `passes/global_lineage_stitcher.py` | New `_stitch_tpf_regs_register_bridge` pass + hook in `process_contexts`. |

No parser/model/emitter/tracer changes.

---

## 5. Implementation notes

### 5.1 `model_tpf_regs_passthrough`
Change signature:
```python
def model_tpf_regs_passthrough(
    callee, scope, line_no, expression, statement_id, qarg,
    input_slots=None, return_slots=None, include_input=True,
):
```
Defaults preserve legacy behaviour (R1 input, R0/R2 return) when the
caller doesn't provide slot sets. The call-site processing already
populates `register_slots`; pass it in as `input_slots`. Return slots
use a fixed convention (R0, R2, R15) since they're read-after-call, not
declared up front.

### 5.2 Stitcher pass
```python
def _stitch_tpf_regs_register_bridge(self, contexts):
    import re
    arg_pattern = re.compile(r"^arg@(?P<callee>[A-Za-z_]\w*):R(?P<num>\d+)$")
    for node in list(self.global_graph.nodes.values()):
        m = arg_pattern.match(node.name)
        if not m:
            continue
        callee = m.group("callee")
        reg = f"R{m.group('num')}"
        # Look up callee's ASM counterpart from the union of all unit.symbol_aliases.
        asm_routine = self._lookup_asm_alias(callee, contexts)
        self.global_graph.annotate_node(
            node.name, node.kind,
            bridge_to=reg,
            callee_asm=asm_routine,
        )
        asm_reg_id = self.global_graph.get_node_id(reg, "register")
        if asm_reg_id:
            self.global_graph.add_alias(
                node.name, node.kind,
                reg, "register",
                file="(tpf_regs_bridge)",
                line=0,
                expression="global_lineage_stitch:tpf_regs_register_bridge",
                scope=callee,
                statement_id="GLOBAL_STITCH_TPF_REGS",
                macro_expansion_parent=None,
            )
```

`_lookup_asm_alias` scans `unit.symbol_aliases` across all cpp contexts
— reuses existing machinery.

---

## 6. Verification (exit criteria)

`fixes/phase_tpf_regs_register_bridge/test_tpf_regs_register_bridge.py`.

### 6.1 Input slot coverage
Synthetic cpp: writes to regs.r3, regs.r4, regs.r7 then calls
buildLg1g1(&regs). Assert that `arg@buildLg1g1:R3`, `R4`, `R7` nodes
exist in the lineage graph AND each has an assign edge from the
corresponding `regs.rN` struct_field.

### 6.2 Return slot coverage
Synthetic cpp: reads regs.r0 and regs.r2 after the call. Assert
`return@buildLg1g1:R0` and `R2` nodes drive assignments into the read
targets.

### 6.3 Stitcher — synthetic positive
Build a merged graph containing both the cpp `arg@buildLg1g1:R7` node
and an ASM `register:R7` node plus a symbol alias
`{"buildLg1g1": "DA78"}`. Run `GlobalLineageStitcher.process_contexts`.
Assert one alias edge with `scope=buildLg1g1` and
`expression="global_lineage_stitch:tpf_regs_register_bridge"`; node
metadata carries `bridge_to=R7, callee_asm=DA78`.

### 6.4 Stitcher — no ASM register node
Drop `register:R7`. Assert no alias edge, but annotation metadata still
attached.

### 6.5 Idempotence + regression
Two runs → same edge count. Phases 1–6 tests all PASS.

---

## 7. Resume

1. Read plan.
2. Baseline test run — expect FAIL on 6.1/6.2/6.3.
3. Patch builder, then stitcher.
4. Re-run — expect PASS.
5. Commit; update `fixes/README.md`.
