#!/usr/bin/env python3
"""TPF_regs register bridge verification."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO_ROOT))

from models.analysis_context import AnalysisContext  # noqa: E402
from models.variable_lineage import VariableLineageGraph  # noqa: E402


RESULTS: list[tuple[str, str, str]] = []


def check(label: str, cond: bool, detail: str = "") -> None:
    status = "PASS" if cond else "FAIL"
    RESULTS.append((status, label, detail))
    tail = f"   — {detail}" if detail else ""
    print(f"  {status}   {label}{tail}")


def build_cpp_graph(source: str) -> dict:
    from multi_file.c_family_analyzer import CFamilyAnalyzer
    with tempfile.TemporaryDirectory() as td:
        cpp = Path(td) / "t.cpp"
        cpp.write_text(source)
        a = CFamilyAnalyzer(language="cpp", search_paths=[Path(td)])
        res = a.analyze(cpp, source)
        graph = res.analysis_context.get_metadata("variable_lineage")
        return graph.to_dict() if hasattr(graph, "to_dict") else (graph or {"edges": [], "nodes": []})


def has_node(d: dict, name: str, kind: str | None = None) -> bool:
    for n in d.get("nodes", []):
        if n.get("name") == name and (kind is None or n.get("kind") == kind):
            return True
    return False


def has_edge(d: dict, source_has: str, target_has: str, relation: str = "assign") -> bool:
    for e in d.get("edges", []):
        if e.get("relation") != relation:
            continue
        if source_has in str(e.get("source","")) and target_has in str(e.get("target","")):
            return True
    return False


# ---------------------------------------------------------------------------
# 6.1 input slot coverage
# ---------------------------------------------------------------------------

def test_input_slot_coverage() -> None:
    print("\n" + "=" * 78)
    print("6.1  input slots R3/R4/R7 captured")
    print("=" * 78)
    src = """
struct TPF_regs { int r0, r1, r2, r3, r4, r5, r6, r7, r8, r9; };
extern "C" void buildLg1g1(TPF_regs*);
int ecb_cr7(); int ecb_cr6(); int ecb_cr4();
int f() {
  TPF_regs regs;
  regs.r3 = ecb_cr4();
  regs.r4 = ecb_cr6();
  regs.r7 = ecb_cr7();
  buildLg1g1(&regs);
  return 0;
}
"""
    d = build_cpp_graph(src)
    for slot in (3, 4, 7):
        check(f"arg@buildLg1g1:R{slot} node exists",
              has_node(d, f"arg@buildLg1g1:R{slot}", "register"))
    for slot in (3, 4, 7):
        check(f"regs.r{slot} → arg@buildLg1g1:R{slot} edge exists",
              has_edge(d, f"regs.r{slot}", f"arg@buildLg1g1:R{slot}")
              or has_edge(d, f"regs->r{slot}", f"arg@buildLg1g1:R{slot}"))


# ---------------------------------------------------------------------------
# 6.2 return slot coverage
# ---------------------------------------------------------------------------

def test_return_slot_coverage() -> None:
    print("\n" + "=" * 78)
    print("6.2  return slots R0/R2 captured")
    print("=" * 78)
    src = """
struct TPF_regs { int r0, r1, r2; };
extern "C" void callAlert(TPF_regs*);
int g() {
  TPF_regs regs;
  callAlert(&regs);
  int rc = regs.r0;
  int out = regs.r2;
  return rc + out;
}
"""
    d = build_cpp_graph(src)
    check("return@callAlert:R0 node exists",
          has_node(d, "return@callAlert:R0", "return_value"))
    check("return@callAlert:R2 node exists",
          has_node(d, "return@callAlert:R2", "return_value"))


# ---------------------------------------------------------------------------
# 6.3 stitcher positive
# ---------------------------------------------------------------------------

def _mk_ctx_with_graph(graph: VariableLineageGraph,
                       symbol_aliases: dict | None = None) -> AnalysisContext:
    ctx = AnalysisContext(file_path=Path("fake.json"))
    ctx.add_metadata("variable_lineage", graph)
    if symbol_aliases is not None:
        # Minimal CTranslationUnit shim — the stitcher reads unit.symbol_aliases.
        class U:
            pass
        unit = U()
        unit.symbol_aliases = dict(symbol_aliases)
        unit.functions = []
        ctx.add_metadata("c_family_unit", unit)
    return ctx


def test_stitcher_positive() -> None:
    print("\n" + "=" * 78)
    print("6.3  Stitcher: arg@buildLg1g1:R7 ↔ register:R7 (with alias DA78)")
    print("=" * 78)
    cpp_g = VariableLineageGraph()
    # Create the arg@ node as produced by model_tpf_regs_passthrough.
    cpp_g.add_assignment(
        "f::regs.r7", "struct_field",
        "arg@buildLg1g1:R7", "register",
        file="t.cpp", line=1, expression="regs.r7 = x;",
        scope="f", statement_id="C_1", macro_expansion_parent=None,
    )
    asm_g = VariableLineageGraph()
    # Simulate an ASM routine using R7.
    asm_g.add_definition("R7", "register",
                         file="da78.asm", line=1, expression="L R7,CE1CR7",
                         scope="DA78", statement_id="A_1", macro_expansion_parent=None)

    contexts = {
        "t.cpp.json":    _mk_ctx_with_graph(cpp_g, symbol_aliases={"buildLg1g1": "DA78"}),
        "da78.asm.json": _mk_ctx_with_graph(asm_g, symbol_aliases={}),
    }
    from passes.global_lineage_stitcher import GlobalLineageStitcher
    stitcher = GlobalLineageStitcher()
    stitcher.process_contexts(contexts)

    gg = stitcher.global_graph
    arg_node = next((n for n in gg.nodes.values()
                     if n.name == "arg@buildLg1g1:R7"), None)
    check("arg node present in global graph", arg_node is not None)
    if arg_node:
        md = arg_node.metadata or {}
        check("metadata.bridge_to == 'R7'",
              md.get("bridge_to") == "R7", detail=f"md={md}")
        check("metadata.callee_asm == 'DA78'",
              md.get("callee_asm") == "DA78", detail=f"md={md}")
    bridge_edges = [
        e for e in gg.edges
        if e.relation == "alias"
        and (e.expression or "") == "global_lineage_stitch:tpf_regs_register_bridge"
    ]
    check("exactly 1 tpf_regs bridge edge",
          len(bridge_edges) == 1, detail=f"count={len(bridge_edges)}")
    if bridge_edges:
        e = bridge_edges[0]
        check("edge scope == buildLg1g1", e.scope == "buildLg1g1",
              detail=f"scope={e.scope}")


# ---------------------------------------------------------------------------
# 6.4 stitcher negative — no register node
# ---------------------------------------------------------------------------

def test_stitcher_no_asm_register() -> None:
    print("\n" + "=" * 78)
    print("6.4  Stitcher: no ASM register:R7 → FIX: synthetic node emitted, bridge created")
    print("=" * 78)
    cpp_g = VariableLineageGraph()
    cpp_g.add_assignment(
        "f::regs.r7", "struct_field",
        "arg@buildLg1g1:R7", "register",
        file="t.cpp", line=1, expression="regs.r7 = x;",
        scope="f", statement_id="C_1", macro_expansion_parent=None,
    )
    contexts = {
        "t.cpp.json": _mk_ctx_with_graph(cpp_g, symbol_aliases={"buildLg1g1": "DA78"}),
    }
    from passes.global_lineage_stitcher import GlobalLineageStitcher
    stitcher = GlobalLineageStitcher()
    stitcher.process_contexts(contexts)
    gg = stitcher.global_graph
    arg_node = next((n for n in gg.nodes.values()
                     if n.name == "arg@buildLg1g1:R7"), None)
    check("arg node present", arg_node is not None)
    if arg_node:
        md = arg_node.metadata or {}
        check("annotation preserved (bridge_to)",
              md.get("bridge_to") == "R7", detail=f"md={md}")
    # Pattern A fix: stitcher now emits a synthetic register:R7 node and
    # creates the bridge edge even when no ASM file has used R7 explicitly.
    bridge_edges = [
        e for e in gg.edges
        if e.relation == "alias"
        and (e.expression or "") == "global_lineage_stitch:tpf_regs_register_bridge"
    ]
    check("FIX: bridge edge created via synthetic register node",
          len(bridge_edges) == 1, detail=f"count={len(bridge_edges)}")
    # Verify the synthetic register:R7 node was materialized in the global graph.
    r7_node_present = any(
        n.name == "R7" and n.kind == "register" for n in gg.nodes.values()
    )
    check("FIX: synthetic register:R7 node present in global graph",
          r7_node_present)


# ---------------------------------------------------------------------------
# 6.5 idempotence
# ---------------------------------------------------------------------------

def test_stitcher_idempotent() -> None:
    print("\n" + "=" * 78)
    print("6.5  Stitcher idempotent (two runs, same edge count)")
    print("=" * 78)
    cpp_g = VariableLineageGraph()
    cpp_g.add_assignment(
        "f::regs.r7", "struct_field",
        "arg@buildLg1g1:R7", "register",
        file="t.cpp", line=1, expression="...",
        scope="f", statement_id="C_1", macro_expansion_parent=None,
    )
    asm_g = VariableLineageGraph()
    asm_g.add_definition("R7", "register",
                         file="a.asm", line=1, expression="...",
                         scope="DA78", statement_id="A_1",
                         macro_expansion_parent=None)
    contexts = {
        "t.cpp.json": _mk_ctx_with_graph(cpp_g, symbol_aliases={"buildLg1g1": "DA78"}),
        "a.asm.json": _mk_ctx_with_graph(asm_g),
    }
    from passes.global_lineage_stitcher import GlobalLineageStitcher
    stitcher = GlobalLineageStitcher()
    stitcher.process_contexts(contexts)
    first = sum(
        1 for e in stitcher.global_graph.edges
        if e.relation == "alias"
        and (e.expression or "") == "global_lineage_stitch:tpf_regs_register_bridge"
    )
    stitcher.process_contexts(contexts)
    second = sum(
        1 for e in stitcher.global_graph.edges
        if e.relation == "alias"
        and (e.expression or "") == "global_lineage_stitch:tpf_regs_register_bridge"
    )
    check("idempotent bridge edge count", first == second,
          detail=f"first={first} second={second}")


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def main() -> int:
    tests = [
        test_input_slot_coverage,
        test_return_slot_coverage,
        test_stitcher_positive,
        test_stitcher_no_asm_register,
        test_stitcher_idempotent,
    ]
    for t in tests:
        try:
            t()
        except Exception as exc:
            RESULTS.append(("FAIL", t.__name__, f"raised {type(exc).__name__}: {exc}"))
            print(f"  FAIL   {t.__name__} raised {exc!r}")
    fails = [r for r in RESULTS if r[0] == "FAIL"]
    print("\n" + "=" * 78)
    if fails:
        print(f">>> TPF_REGS: {len(fails)}/{len(RESULTS)} FAILED.")
        for _, lbl, detail in fails:
            print(f"    - {lbl}  {detail}")
        return 1
    print(f">>> TPF_REGS: ALL {len(RESULTS)} CHECKS PASSED.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
