# Phase 5 — Enum Value Resolution (AddLimit → 'A')

**Status:** NOT STARTED (awaiting approval to patch).
**Source plan:** `docs/plans/2026-04-23-cpp-variable-lineage-strategy 1.md` §3.3, §6.5.
**Depends on:** Phases 1–4 (last commit `7fd2304`).

---

## 1. The problem in one picture

`cclg1g1.hpp` (and similar cc-prefixed headers) defines named enums whose
values are **character literals**:

```cpp
// cclg1g1.hpp
enum TypeOfMaintenance
{
    AddLimit    = 'A',
    ChangeLimit = 'C',
    DeleteLimit = 'D'
};

enum ProductCode
{
    PersonalCard  = 'P',
    CompanyCard   = 'M',
    ...
};

enum OnlineSourceInd
{
    C112 = 'A',
    G116 = 'B',
    C400 = 'D',
    PSGL = 'P'
};
```

C++ code uses the enum identifier (`AddLimit`, `PersonalCard`, `C400`) in
assignments and conditions:

```cpp
task = AddLimit;
if (typeOfMaintenance == DeleteLimit) { ... }
da7gl->onlineSrcInd = C400;
```

The corresponding ASM code uses the literal value directly:

```asm
         CLI   LG1TYP,C'A'          TYPE = ADD LIMIT?
         CLI   LG1OSI,C'D'          SOURCE = C400?
```

**Current parser behavior (pre-Phase 5):** the enum identifier (`AddLimit`)
is captured as a plain source identifier in `CAssignment.sources`. The
**value** (`'A'`) is never resolved — so a consumer reading the lineage JSON
cannot know that `AddLimit` corresponds to literal `'A'` and therefore
cannot automatically match the C++ branch to the ASM `CLI` check.

---

## 2. What Phase 5 adds

A compile-time enum index per translation unit, surfaced in the blueprint:

```json
{
  "enum_values": {
    "AddLimit":      {"enum_type": "TypeOfMaintenance",  "value": "'A'"},
    "ChangeLimit":   {"enum_type": "TypeOfMaintenance",  "value": "'C'"},
    "DeleteLimit":   {"enum_type": "TypeOfMaintenance",  "value": "'D'"},
    "PersonalCard":  {"enum_type": "ProductCode",        "value": "'P'"},
    "C400":          {"enum_type": "OnlineSourceInd",    "value": "'D'"}
  }
}
```

And the lineage edges that reference an enum constant get enriched:

```json
{
  "source": "variable:someFunc::AddLimit",   // or identifier:AddLimit
  "target": "variable:someFunc::task",
  "relation": "assign",
  "metadata": {
    "resolved_value": "'A'",
    "enum_type": "TypeOfMaintenance"
  }
}
```

Phase 5 is **pure extraction + annotation** — no graph topology changes.
Cross-language *matching* against ASM `CLI ...,C'A'` remains a downstream
task (tracer / consumer concern). Phase 5 just makes the data available.

---

## 3. Scope rules

### In scope
- Extract every `enum Name { K = VAL, ... };` from the translation unit
  (top-level or nested) plus all files reached via the existing
  `_collect_include_field_asm_aliases`-style include walk.
- Record `{identifier → (enum_type, literal_value)}`.
- When building the lineage graph, look up each source identifier in the
  enum index. If it matches, add `resolved_value` and `enum_type` to the
  edge metadata.

### Deliberately out of scope
- **Anonymous enums** (`enum { FOO = 1 }`). The plan mentions the named
  cases; anonymous values can be added later if needed.
- **Constant expressions** (`AddLimit + 1`, bitwise combinations). Only
  direct enum-constant references are resolved.
- **Cross-language matching against ASM CLI/CLC instructions.** This is a
  consumer concern, not a data-production concern. Downstream consumers
  (trace tools, LLM prompts) can join enum metadata with ASM literal
  operands themselves.
- `#define` constants. Different track (preprocessor). Not an enum.

---

## 4. Files touched

| File | Change |
|---|---|
| `models/c_family.py` | Add `enum_values: Dict[str, Dict[str, str]]` to `CTranslationUnit`. Empty by default. |
| `passes/c_family_parser.py` | New `_extract_enum_values(text, file_path)` returning `{identifier: {enum_type, value}}`. Call from `parse()`. |
| `multi_file/c_family_analyzer.py` | New `_collect_include_enum_values(file_path, content)` following the same include-walk pattern used for field aliases. Merge into unit. |
| `passes/variable_lineage_builder.py` | In `process_c_family()`, when emitting assign/use edges whose source identifier matches the enum index, attach `resolved_value` and `enum_type` to `edge.metadata`. |
| `json_emitter.py` | Emit `enum_values` section in blueprint JSON. |

No changes to the stitcher or tracer. No schema breakage — the new fields
default to empty dict on legacy blueprints.

---

## 5. Implementation approach (regex-based, matches phase 2 style)

Enums in this codebase follow a narrow syntactic form:

```
enum NAME
{
    IDENT [= VALUE] ,
    ...
};
```

Grammar is simpler than structs; a regex scanner handles everything seen
in `cclg1g1.hpp`:

```python
ENUM_RE = re.compile(
    r"\benum\s+([A-Za-z_]\w*)\s*\{([^{}]*)\}\s*;",
    re.DOTALL
)
MEMBER_RE = re.compile(
    r"([A-Za-z_]\w*)\s*(?:=\s*([^,}\n]+?))?\s*(?:,|$)"
)
```

For each match:
1. `enum_name` = group 1.
2. Walk members in body. Explicit values are kept verbatim (`'A'`, `0x80`,
   `42`) — no constant folding. Implicit values (C enum auto-increment)
   are resolved against the running counter; start = 0 or last explicit + 1.
3. Emit `{ident: {"enum_type": enum_name, "value": literal_str}}`.

Edge enrichment in `process_c_family()` looks up each `source` identifier
against `unit.enum_values`. If found, stamp the edge metadata.

---

## 6. Verification (exit criteria)

Test script: `fixes/phase5_enum_value_resolution/test_enum_value_resolution.py`.

### 6.1 Synthetic tests (extraction)
- Named enum with explicit char-literal values → all 3 members captured.
- Named enum with implicit auto-increment (`enum { A, B = 5, C }`) →
  values resolved as `"0"`, `"5"`, `"6"`.
- Multiple enums in one file → each member qualified with its enum_type.
- Enum with hex literal (`FOO = 0x80`) → value kept as `"0x80"`.
- Non-`cc` file with enum → still extracted (this gate is field-specific,
  not enum-specific).

### 6.2 Real-file test (`cclg1g1.hpp`)
Produced enum_values must contain at minimum:
- `AddLimit → ('TypeOfMaintenance', "'A'")`
- `ChangeLimit → ('TypeOfMaintenance', "'C'")`
- `DeleteLimit → ('TypeOfMaintenance', "'D'")`
- `PersonalCard → ('ProductCode', "'P'")`
- `C400 → ('OnlineSourceInd', "'D'")`
- `OnlineCasUpdate → ('SourceIndicator', "'1'")`
- Count ≥ 5 distinct enum types; ≥ 20 total members.

### 6.3 Include-walk test
A `.cpp` file that `#include`s `cclg1g1.hpp` must surface its enum values
via `unit.enum_values` (like field aliases do via include walking).

### 6.4 Edge-enrichment test
Synthetic C++:
```cpp
enum E { X = 'x' };
int f() { int v = X; return v; }
```
Expected: the assign edge `... → v` has `metadata.resolved_value = "'x'"`
and `metadata.enum_type = "E"`.

### 6.5 Regression
- Phase 1–4 test scripts still PASS.
- A `.cpp.json` blueprint that had no enum references produces
  `enum_values: {}` without breaking consumers.

---

## 7. Resume next session

1. Read this plan.
2. Baseline run:
   `python3 fixes/phase5_enum_value_resolution/test_enum_value_resolution.py`
   — expect failures on extraction and enrichment assertions.
3. Apply the patches in order: parser → model → analyzer → lineage
   builder → emitter.
4. Re-run the test — expect PASS.
5. Commit (same style as phases 1–4, no co-author trailer).
6. Update `fixes/README.md` status row for Phase 5.
