#!/usr/bin/env python3
"""Phase 5 verification — enum value resolution.

Usage:
    python3 fixes/phase5_enum_value_resolution/test_enum_value_resolution.py

Exit 0 on all-PASS, 1 on any FAIL.
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO_ROOT))

from passes.c_family_parser import CFamilyParser  # noqa: E402


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

RESULTS: list[tuple[str, str, str]] = []


def check(label: str, cond: bool, detail: str = "") -> None:
    status = "PASS" if cond else "FAIL"
    RESULTS.append((status, label, detail))
    tail = f"   — {detail}" if detail else ""
    print(f"  {status}   {label}{tail}")


def parse_text(text: str, name: str = "t.hpp") -> dict:
    """Run the parser's enum extractor directly on a blob of text."""
    with tempfile.NamedTemporaryFile("w", suffix=f"_{name}", delete=False) as f:
        f.write(text)
        fp = Path(f.name)
    try:
        parser = CFamilyParser(language="cpp")
        if hasattr(parser, "_extract_enum_values"):
            return parser._extract_enum_values(text, fp)
        raise AttributeError(
            "CFamilyParser._extract_enum_values is not defined yet — "
            "Phase 5 patch has not been applied."
        )
    finally:
        try:
            fp.unlink()
        except OSError:
            pass


# ---------------------------------------------------------------------------
# 6.1 Synthetic extraction
# ---------------------------------------------------------------------------

def test_synthetic_char_literal_enum() -> None:
    print("\n" + "=" * 78)
    print("6.1.a  Named enum with explicit char-literal values")
    print("=" * 78)
    src = """
    enum Kind {
        AddLimit    = 'A',
        ChangeLimit = 'C',
        DeleteLimit = 'D'
    };
    """
    got = parse_text(src)
    check("AddLimit extracted as Kind='A'",
          got.get("AddLimit") == {"enum_type": "Kind", "value": "'A'"},
          detail=f"got {got.get('AddLimit')}")
    check("ChangeLimit extracted as Kind='C'",
          got.get("ChangeLimit") == {"enum_type": "Kind", "value": "'C'"})
    check("DeleteLimit extracted as Kind='D'",
          got.get("DeleteLimit") == {"enum_type": "Kind", "value": "'D'"})


def test_synthetic_implicit_values() -> None:
    print("\n" + "=" * 78)
    print("6.1.b  Implicit auto-increment values")
    print("=" * 78)
    src = """
    enum Counter {
        A,
        B = 5,
        C
    };
    """
    got = parse_text(src)
    check("A defaults to '0'",
          got.get("A", {}).get("value") == "0",
          detail=f"got {got.get('A')}")
    check("B explicit '5'",
          got.get("B", {}).get("value") == "5",
          detail=f"got {got.get('B')}")
    check("C auto-increments to '6'",
          got.get("C", {}).get("value") == "6",
          detail=f"got {got.get('C')}")


def test_synthetic_multiple_enums() -> None:
    print("\n" + "=" * 78)
    print("6.1.c  Multiple enums distinguished by enum_type")
    print("=" * 78)
    src = """
    enum TypeA {
        One = 1,
        Two = 2
    };
    enum TypeB {
        Red  = 'R',
        Blue = 'B'
    };
    """
    got = parse_text(src)
    check("Two.enum_type == TypeA",
          got.get("Two", {}).get("enum_type") == "TypeA",
          detail=f"got {got.get('Two')}")
    check("Red.enum_type == TypeB",
          got.get("Red", {}).get("enum_type") == "TypeB",
          detail=f"got {got.get('Red')}")


def test_synthetic_hex_literal() -> None:
    print("\n" + "=" * 78)
    print("6.1.d  Hex-literal enum value preserved verbatim")
    print("=" * 78)
    src = """
    enum Mask {
        FULL = 0xFF,
        HIGH = 0x80
    };
    """
    got = parse_text(src)
    check("FULL = 0xFF kept",
          got.get("FULL", {}).get("value") == "0xFF",
          detail=f"got {got.get('FULL')}")
    check("HIGH = 0x80 kept",
          got.get("HIGH", {}).get("value") == "0x80")


# ---------------------------------------------------------------------------
# 6.2 Real-file test (cclg1g1.hpp)
# ---------------------------------------------------------------------------

def test_real_cclg1g1() -> None:
    print("\n" + "=" * 78)
    print("6.2  Real file: cclg1g1.hpp")
    print("=" * 78)
    hpp = REPO_ROOT.parent / "asm" / "cclg1g1.hpp"
    if not hpp.exists():
        print(f"  SKIP — {hpp} not found (expected in adjacent ../asm/)")
        return
    text = hpp.read_text(errors="replace")
    got = parse_text(text, name="cclg1g1.hpp")
    print(f"  extracted {len(got)} enum members")
    expected = {
        "AddLimit":         ("TypeOfMaintenance", "'A'"),
        "ChangeLimit":      ("TypeOfMaintenance", "'C'"),
        "DeleteLimit":      ("TypeOfMaintenance", "'D'"),
        "PersonalCard":     ("ProductCode",       "'P'"),
        "CompanyCard":      ("ProductCode",       "'M'"),
        "C400":             ("OnlineSourceInd",   "'D'"),
        "OnlineCasUpdate":  ("SourceIndicator",   "'1'"),
    }
    for name, (etype, val) in expected.items():
        rec = got.get(name) or {}
        check(f"{name}  →  {etype}={val}",
              rec.get("enum_type") == etype and rec.get("value") == val,
              detail=f"got {rec}")
    types = {rec["enum_type"] for rec in got.values() if "enum_type" in rec}
    check("≥ 5 distinct enum types", len(types) >= 5,
          detail=f"types={sorted(types)}")
    check("≥ 20 total enum members", len(got) >= 20,
          detail=f"count={len(got)}")


# ---------------------------------------------------------------------------
# 6.3 Include-walk test (analyzer)
# ---------------------------------------------------------------------------

def test_include_walk() -> None:
    print("\n" + "=" * 78)
    print("6.3  Include-walk: .cpp that #includes cclg1g1.hpp")
    print("=" * 78)
    hpp = REPO_ROOT.parent / "asm" / "cclg1g1.hpp"
    if not hpp.exists():
        print(f"  SKIP — {hpp} not found")
        return
    from multi_file.c_family_analyzer import CFamilyAnalyzer  # noqa: E402

    with tempfile.TemporaryDirectory() as td:
        tdp = Path(td)
        (tdp / "cclg1g1.hpp").write_text(hpp.read_text(errors="replace"))
        cpp = tdp / "main.cpp"
        cpp.write_text(
            '#include "cclg1g1.hpp"\n'
            'int f() { int x = AddLimit; return x; }\n'
        )
        a = CFamilyAnalyzer(language="cpp", search_paths=[tdp])
        res = a.analyze(cpp, cpp.read_text())
        unit = res.analysis_context.get_metadata("c_family_unit")
        enum_values = getattr(unit, "enum_values", None) or {}
        rec = enum_values.get("AddLimit") or {}
        check("AddLimit surfaces via include walk",
              rec.get("value") == "'A'"
              and rec.get("enum_type") == "TypeOfMaintenance",
              detail=f"got {rec}")


# ---------------------------------------------------------------------------
# 6.4 Edge enrichment
# ---------------------------------------------------------------------------

def test_edge_enrichment() -> None:
    print("\n" + "=" * 78)
    print("6.4  Edge enrichment: assign with enum identifier as source")
    print("=" * 78)
    src = """
    enum E { X = 'x' };
    int f() { int v = X; return v; }
    """
    with tempfile.TemporaryDirectory() as td:
        cpp = Path(td) / "t.cpp"
        cpp.write_text(src)
        from multi_file.c_family_analyzer import CFamilyAnalyzer  # noqa: E402
        a = CFamilyAnalyzer(language="cpp", search_paths=[Path(td)])
        res = a.analyze(cpp, src)
        ctx = res.analysis_context
        _ = ctx  # unused — kept for clarity; lineage is read below
        # Trigger lineage construction if it isn't auto-invoked.
        try:
            from passes.variable_lineage_builder import VariableLineageBuilder
            builder = VariableLineageBuilder()
            graph = builder.process(ctx)
        except Exception:
            graph = ctx.get_metadata("variable_lineage")
        edges = (graph.to_dict() if hasattr(graph, "to_dict") else graph).get("edges") if graph else []
        enriched = [
            e for e in (edges or [])
            if (e.get("metadata") or {}).get("enum_type") == "E"
            and (e.get("metadata") or {}).get("resolved_value") == "'x'"
        ]
        check(">=1 edge carries resolved_value='x' and enum_type=E",
              len(enriched) >= 1,
              detail=f"count={len(enriched)}")


# ---------------------------------------------------------------------------
# 6.5 Regression: blueprint without enums produces empty index
# ---------------------------------------------------------------------------

def test_regression_no_enum() -> None:
    print("\n" + "=" * 78)
    print("6.5  Regression: file with no enum → empty dict")
    print("=" * 78)
    src = "int f() { return 0; }\n"
    got = parse_text(src)
    check("no enum → empty dict", got == {}, detail=f"got {got}")


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def main() -> int:
    tests = [
        test_synthetic_char_literal_enum,
        test_synthetic_implicit_values,
        test_synthetic_multiple_enums,
        test_synthetic_hex_literal,
        test_real_cclg1g1,
        test_include_walk,
        test_edge_enrichment,
        test_regression_no_enum,
    ]
    for t in tests:
        try:
            t()
        except Exception as exc:
            RESULTS.append(("FAIL", t.__name__, f"raised {type(exc).__name__}: {exc}"))
            print(f"  FAIL   {t.__name__} raised {exc!r}")

    print("\n" + "=" * 78)
    fails = [r for r in RESULTS if r[0] == "FAIL"]
    if fails:
        print(f">>> PHASE 5: {len(fails)}/{len(RESULTS)} FAILED.")
        for _, lbl, detail in fails:
            print(f"    - {lbl}  {detail}")
        return 1
    print(f">>> PHASE 5: ALL {len(RESULTS)} CHECKS PASSED.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
