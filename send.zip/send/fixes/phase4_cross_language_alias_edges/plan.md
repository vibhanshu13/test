# Phase 4 — Scoped Cross-Language Alias Edges (C++ struct_field ↔ ASM memory)

**Status:** NOT STARTED (awaiting approval to patch).
**Source plan:** `docs/plans/2026-04-23-cpp-variable-lineage-strategy 1.md` §6.4, §8.2.
**Depends on:** Phase 3 (commit `66a297b`).

---

## Goal in one paragraph

Phase 3 attached `metadata.asm_alias="WK_CMO"` and `metadata.enclosing_type=
"Da7gl"` to C++ `struct_field` nodes. Phase 4 wires those annotations into
actual graph edges: if the merged global graph contains both the C++ node
`struct_field:globalLimitsUpdate::da7gl->cmSystem` and an ASM node
`memory:WK_CMO`, stitch an `alias` edge between them (source-cpp → target-asm)
with `alias_type=cpp_field_to_asm` metadata and, when resolvable, a `via_call`
hint pointing at the ASM routine in the C++ function's call graph. No dangling
edges: if the ASM node is absent, skip silently — the node's `asm_alias`
metadata still documents the mapping.

---

## Scope — what Phase 4 covers, what it does not

### In scope

- **4a. Struct-field alias edges.** For every C++ `struct_field` node whose
  metadata contains `asm_alias`, create an `alias` edge to the corresponding
  ASM `memory` node IF such a node exists in the merged graph. Edge carries
  `alias_type`, `enclosing_type`, and (best-effort) `via_call` metadata.

### Deliberately out of scope (deferred to a follow-up phase)

- **TPF_regs end-to-end register bridge.** The builder creates `arg@{callee}:
  R<n>` and `return@{callee}:R<n>` nodes for the TPF_regs passthrough
  convention (`passes/variable_lineage_builder.py::model_tpf_regs_passthrough`,
  line ~2908). Bridging those to the ASM routine's `register:R<n>` nodes
  requires (a) per-routine register scoping in the ASM graph — currently
  `register:R0` is a single shared node across all routines — or (b) a
  statement_id-based narrow alias that touches only the argument/return
  boundary. That is a separate design question; punt to a future phase.
- Enum value resolution (Phase 5).
- ECB `ce1crN` ↔ `CE1CRN` mapping (Phase 6). The existing
  `_stitch_ce1cr_level_bindings` already handles much of this — untouched
  here.
- `glob(_name)` (Phase 7).

This keeps Phase 4 small, testable, and valuable on its own.

---

## Design: one new stitcher method

### Hook point

`passes/global_lineage_stitcher.py::GlobalLineageStitcher.process_contexts`
calls eight stitch methods around line 113–122. Add one more, scheduled after
`_stitch_memory_struct_fields` and before `_stitch_callarg_dsect_struct_fields`
(line 117–118):

```python
self._stitch_asm_alias_struct_fields(contexts)
```

### The method

```python
def _stitch_asm_alias_struct_fields(self, contexts: Dict[str, AnalysisContext]) -> None:
    """Phase 4: bridge C++ struct_field nodes to ASM memory nodes via asm_alias metadata."""
    # Step 1: per-file symbol_aliases (callable→ASM-routine map) + file owners of each function.
    file_aliases: Dict[str, Dict[str, str]] = {}
    function_file: Dict[str, str] = {}
    for fp, ctx in contexts.items():
        unit = ctx.get_metadata("c_family_unit")
        if not unit:
            continue
        file_aliases[fp] = dict(getattr(unit, "symbol_aliases", {}) or {})
        for func in getattr(unit, "functions", []) or []:
            function_file[func.name] = fp

    existing_alias_keys: Set[Tuple[str, str]] = {
        (e.source, e.target) for e in self.global_graph.edges if e.relation == "alias"
    }

    for node in list(self.global_graph.nodes.values()):
        if node.kind != "struct_field":
            continue
        asm_name = node.metadata.get("asm_alias")
        if not asm_name:
            continue
        asm_node_id = self.global_graph.get_node_id(asm_name, "memory")
        if not asm_node_id:
            # No ASM setter exists for this variable in the analyzed set;
            # leave metadata in place for documentation, skip edge creation.
            continue

        # Resolve enclosing function from the qualified name (before first '::').
        name = node.name
        if "::" in name:
            owner = name.split("::", 1)[0].lstrip("*")
        else:
            owner = ""
        scope = owner or None
        via_call = None
        fp = function_file.get(owner)
        if fp:
            aliases = file_aliases.get(fp, {})
            # Best-effort: if any aliased callable in this file resolves to an ASM
            # routine that also exists in the graph, record the first one we see.
            for callable_name, asm_alias in aliases.items():
                if asm_alias and self.global_graph.get_node_id(asm_alias, "function"):
                    via_call = asm_alias
                    break

        edge_key = (node.node_id, asm_node_id)
        if edge_key in existing_alias_keys:
            continue
        existing_alias_keys.add(edge_key)

        self.global_graph.add_alias(
            node.name, "struct_field",
            asm_name, "memory",
            file=fp or "(global_stitch)",
            line=0,
            expression="global_lineage_stitch:cpp_field_to_asm",
            scope=scope,
            statement_id="GLOBAL_STITCH_CPP_FIELD_ASM",
            macro_expansion_parent=None,
        )
        # Attach metadata on the C++ node so consumers can see via_call/alias_type
        # without having to inspect edges.
        self.global_graph.annotate_node(
            node.name, "struct_field",
            asm_alias_linked=True,
            alias_type="cpp_field_to_asm",
            **({"via_call": via_call} if via_call else {}),
        )
```

### Edge semantics

- `relation="alias"` (same relation the stitcher already uses for other
  cross-language bridges).
- `source` = C++ struct_field node (includes function scope qualifier).
- `target` = ASM memory node (raw DSECT variable name).
- One direction: C++ → ASM. Downstream traversers already walk aliases in
  both directions, so we don't need a reciprocal edge.

### Multiple lineage preservation

Two C++ functions writing to `da7gl->cmSystem` produce two distinct C++
struct_field nodes (`globalLimitsUpdate::da7gl->cmSystem`,
`countRealTimeTransactions::da7gl->cmSystem`) — Phase 3 already annotates
each with the same `asm_alias`. Phase 4 creates two separate alias edges, each
scoped to its own function. No merging, no shared path.

---

## Files touched

| File | Change |
|---|---|
| `passes/global_lineage_stitcher.py` | Add `_stitch_asm_alias_struct_fields` method + call site in `process_contexts`. |

No model changes, no parser changes, no other files.

---

## Exit criteria

Located at `fixes/phase4_cross_language_alias_edges/test_cross_language_alias_edges.py`.

### 1. Synthetic stitch test (constructed global graph)

Manually build two `AnalysisContext` objects:
- **Context A** (cpp): a `VariableLineageGraph` with one struct_field node
  `globalLimitsUpdate::da7gl->cmSystem` carrying
  `metadata.asm_alias="WK_CMO"` and `metadata.enclosing_type="Da7gl"`.
  `c_family_unit` metadata includes `symbol_aliases={"buildLg1g1": "DA78"}`
  and a `functions` list with `globalLimitsUpdate`.
- **Context B** (asm): a `VariableLineageGraph` with:
  - `memory:WK_CMO` (from a synthetic ASM setter),
  - `function:DA78` (routine entry).

Run `GlobalLineageStitcher().process_contexts({...})`. Assert:
- Exactly one `alias` edge exists with
  `source=struct_field:globalLimitsUpdate::da7gl->cmSystem`,
  `target=memory:WK_CMO`, `relation=alias`.
- That edge has `scope="globalLimitsUpdate"` and
  `expression="global_lineage_stitch:cpp_field_to_asm"`.
- Struct_field node gains `metadata.asm_alias_linked=True`,
  `metadata.alias_type="cpp_field_to_asm"`, and `metadata.via_call="DA78"`.

### 2. Negative — no matching ASM node

Same Context A, Context B has no `memory:WK_CMO` node. Assert:
- Zero `alias` edges from the C++ struct_field node.
- The C++ node still has `metadata.asm_alias="WK_CMO"` (Phase 3 documentation
  preserved).
- The C++ node does NOT have `metadata.asm_alias_linked=True`.

### 3. Negative — no asm_alias metadata

Context A's struct_field node has no `asm_alias` metadata (Phase 3 didn't
attach one because the field has no cc*.hpp mapping). Assert: zero new alias
edges introduced by Phase 4.

### 4. Idempotence

Run `process_contexts` twice on the same inputs. Assert: same edge count both
times — no duplicate alias edges.

### 5. Multiple C++ functions, same field

Two C++ struct_field nodes (`funcA::da7gl->cmSystem`,
`funcB::da7gl->cmSystem`), one ASM `memory:WK_CMO`. Assert: two alias edges,
each scoped to its own enclosing function, pointing at the same ASM node.

### 6. Regression

Phase 1, 2, and 3 tests all still PASS.

---

## What about Phase 4 on real files?

A real-file integration test would require a cpp file (e.g., dx740200.cpp)
and at least one ASM routine whose lineage graph contains a `memory:WK_CMO`
node. Building that end-to-end in one test is brittle and depends on fixtures
outside the repo. For this phase, synthetic coverage is sufficient — the
mechanics are fully exercised, and downstream integration (when real ASM
blueprints are present in a full analysis run) naturally picks up the edges
because the stitcher runs at the global level.

If real-file verification becomes desirable, add a smoke script under
`scripts/` that runs the full pipeline against `../asm/` and greps the emitted
blueprint for `"alias_type": "cpp_field_to_asm"` edges — that's a verification
step, not a unit test.

---

## Resume next session

1. Read this plan.
2. Baseline: `python3 fixes/phase4_cross_language_alias_edges/test_cross_language_alias_edges.py`
   — expect failing checks on each alias-edge assertion.
3. Apply the patch (one method in `global_lineage_stitcher.py`).
4. Re-run test — expect PASS.
5. Commit (same style as Phases 1–3, no co-author trailer).
6. Phase 4 lands. Remaining phases (5–7, TPF_regs register bridge) are
   deliberately out of scope for this track.
