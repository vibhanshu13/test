#!/usr/bin/env python3
"""Phase 4 verification — cross-language alias edges in GlobalLineageStitcher.

Usage:
    python3 fixes/phase4_cross_language_alias_edges/test_cross_language_alias_edges.py

BEFORE the patch: every alias-edge assertion prints MISSING / WRONG.
AFTER the patch: every row prints PASS.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Dict, List, Optional

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))

from models.analysis_context import AnalysisContext  # noqa: E402
from models.c_family import CFunction, CTranslationUnit  # noqa: E402
from models.variable_lineage import VariableLineageGraph  # noqa: E402
from passes.global_lineage_stitcher import GlobalLineageStitcher  # noqa: E402


# --- Helpers to construct contexts ------------------------------------------


def _cpp_context(
    cpp_path: str,
    struct_field_nodes: List[Dict[str, object]],
    symbol_aliases: Optional[Dict[str, str]] = None,
    function_names: Optional[List[str]] = None,
) -> AnalysisContext:
    path = Path(cpp_path)
    ctx = AnalysisContext(file_path=path)
    graph = VariableLineageGraph()
    for spec in struct_field_nodes:
        name = str(spec["name"])
        graph.annotate_node(name, "struct_field", **spec.get("metadata", {}))
    ctx.add_metadata("variable_lineage", graph)

    unit = CTranslationUnit(file_path=path, language="cpp")
    unit.symbol_aliases = dict(symbol_aliases or {})
    for fn in (function_names or []):
        unit.functions.append(CFunction(name=fn, start_line=1, end_line=1))
    ctx.add_metadata("c_family_unit", unit)
    return ctx


def _asm_context(
    asm_path: str,
    memory_nodes: List[str],
    function_nodes: List[str],
) -> AnalysisContext:
    path = Path(asm_path)
    ctx = AnalysisContext(file_path=path)
    graph = VariableLineageGraph()
    for m in memory_nodes:
        graph.annotate_node(m, "memory")
    for f in function_nodes:
        graph.annotate_node(f, "function")
    ctx.add_metadata("variable_lineage", graph)
    return ctx


def _count_alias_edges(graph: VariableLineageGraph, source_substr: str, target: str) -> int:
    n = 0
    for e in graph.edges:
        if e.relation != "alias":
            continue
        if source_substr in e.source and e.target.endswith(target):
            n += 1
    return n


def _find_alias_edge(graph: VariableLineageGraph, source_name: str, target_name: str):
    for e in graph.edges:
        if (e.relation == "alias"
                and e.source == f"struct_field:{source_name}"
                and e.target == f"memory:{target_name}"):
            return e
    return None


def _find_node(graph: VariableLineageGraph, name: str, kind: str):
    return graph.nodes.get(f"{kind}:{name}")


# --- Tests -------------------------------------------------------------------


def run_positive_single_bridge() -> int:
    print("=" * 78)
    print("1. Positive: single struct_field bridges to matching ASM memory")
    print("=" * 78)
    failed = 0

    contexts = {
        "/tmp/dx.cpp": _cpp_context(
            "/tmp/dx.cpp",
            struct_field_nodes=[{
                "name": "globalLimitsUpdate::da7gl->cmSystem",
                "metadata": {"asm_alias": "WK_CMO", "enclosing_type": "Da7gl"},
            }],
            symbol_aliases={"buildLg1g1": "DA78"},
            function_names=["globalLimitsUpdate"],
        ),
        "/tmp/da78.asm": _asm_context(
            "/tmp/da78.asm",
            memory_nodes=["WK_CMO"],
            function_nodes=["DA78"],
        ),
    }
    graph = GlobalLineageStitcher().process_contexts(contexts)
    edge = _find_alias_edge(graph, "globalLimitsUpdate::da7gl->cmSystem", "WK_CMO")
    if edge is None:
        print("  MISSING alias edge cpp_field→asm not created")
        return failed + 1

    print("  PASS   alias edge created")
    if edge.scope == "globalLimitsUpdate":
        print("  PASS   edge scoped to enclosing function")
    else:
        print(f"  WRONG  edge scope is {edge.scope!r}, expected 'globalLimitsUpdate'")
        failed += 1
    if edge.expression == "global_lineage_stitch:cpp_field_to_asm":
        print("  PASS   edge expression tag set")
    else:
        print(f"  WRONG  edge expression is {edge.expression!r}")
        failed += 1

    node = _find_node(graph, "globalLimitsUpdate::da7gl->cmSystem", "struct_field")
    md = (node.metadata or {}) if node else {}
    if md.get("asm_alias_linked") is True:
        print("  PASS   node metadata.asm_alias_linked=True")
    else:
        print(f"  MISSING node metadata.asm_alias_linked (got {md.get('asm_alias_linked')!r})")
        failed += 1
    if md.get("alias_type") == "cpp_field_to_asm":
        print("  PASS   node metadata.alias_type=cpp_field_to_asm")
    else:
        print(f"  MISSING node metadata.alias_type (got {md.get('alias_type')!r})")
        failed += 1
    if md.get("via_call") == "DA78":
        print("  PASS   node metadata.via_call=DA78")
    else:
        print(f"  MISSING node metadata.via_call=DA78 (got {md.get('via_call')!r})")
        failed += 1

    return failed


def run_negative_no_matching_asm() -> int:
    print()
    print("=" * 78)
    print("2. Negative: asm_alias set but no matching ASM memory node")
    print("=" * 78)
    failed = 0

    contexts = {
        "/tmp/dx.cpp": _cpp_context(
            "/tmp/dx.cpp",
            struct_field_nodes=[{
                "name": "globalLimitsUpdate::da7gl->cmSystem",
                "metadata": {"asm_alias": "WK_CMO", "enclosing_type": "Da7gl"},
            }],
            function_names=["globalLimitsUpdate"],
        ),
        "/tmp/elsewhere.asm": _asm_context(
            "/tmp/elsewhere.asm",
            memory_nodes=[],
            function_nodes=[],
        ),
    }
    graph = GlobalLineageStitcher().process_contexts(contexts)
    n = _count_alias_edges(graph, "globalLimitsUpdate::da7gl->cmSystem", "WK_CMO")
    if n == 0:
        print("  PASS   no dangling alias edge created")
    else:
        print(f"  WRONG  {n} alias edge(s) created without ASM node present")
        failed += 1

    node = _find_node(graph, "globalLimitsUpdate::da7gl->cmSystem", "struct_field")
    md = (node.metadata or {}) if node else {}
    if md.get("asm_alias") == "WK_CMO":
        print("  PASS   Phase 3 documentation metadata preserved")
    else:
        print(f"  WRONG  Phase 3 asm_alias metadata lost (got {md.get('asm_alias')!r})")
        failed += 1
    if not md.get("asm_alias_linked"):
        print("  PASS   node not marked asm_alias_linked")
    else:
        print("  WRONG  node incorrectly marked asm_alias_linked")
        failed += 1

    return failed


def run_negative_no_metadata() -> int:
    print()
    print("=" * 78)
    print("3. Negative: struct_field node without asm_alias metadata")
    print("=" * 78)
    failed = 0

    contexts = {
        "/tmp/dx.cpp": _cpp_context(
            "/tmp/dx.cpp",
            struct_field_nodes=[{
                "name": "globalLimitsUpdate::localVar->f",
                "metadata": {},
            }],
            function_names=["globalLimitsUpdate"],
        ),
        "/tmp/da78.asm": _asm_context(
            "/tmp/da78.asm",
            memory_nodes=["WK_CMO"],
            function_nodes=["DA78"],
        ),
    }
    graph = GlobalLineageStitcher().process_contexts(contexts)
    new_aliases = [e for e in graph.edges
                   if e.relation == "alias"
                   and e.expression == "global_lineage_stitch:cpp_field_to_asm"]
    if not new_aliases:
        print("  PASS   no cpp_field_to_asm alias edges produced")
        return failed
    print(f"  WRONG  {len(new_aliases)} unexpected alias edge(s) produced")
    return failed + 1


def run_idempotence() -> int:
    print()
    print("=" * 78)
    print("4. Idempotence: two runs produce same edge count")
    print("=" * 78)
    failed = 0

    def build_contexts():
        return {
            "/tmp/dx.cpp": _cpp_context(
                "/tmp/dx.cpp",
                struct_field_nodes=[{
                    "name": "globalLimitsUpdate::da7gl->cmSystem",
                    "metadata": {"asm_alias": "WK_CMO", "enclosing_type": "Da7gl"},
                }],
                function_names=["globalLimitsUpdate"],
            ),
            "/tmp/da78.asm": _asm_context(
                "/tmp/da78.asm",
                memory_nodes=["WK_CMO"],
                function_nodes=["DA78"],
            ),
        }

    stitcher = GlobalLineageStitcher()
    g1 = stitcher.process_contexts(build_contexts())
    count1 = len([e for e in g1.edges if e.relation == "alias"])
    g2 = stitcher.process_contexts(build_contexts())
    count2 = len([e for e in g2.edges if e.relation == "alias"])
    if count1 == count2:
        print(f"  PASS   idempotent alias edge count ({count1})")
    else:
        print(f"  WRONG  edge count drifted: {count1} → {count2}")
        failed += 1
    return failed


def run_multiple_functions_same_field() -> int:
    print()
    print("=" * 78)
    print("5. Multiple C++ functions write the same field → separate scoped edges")
    print("=" * 78)
    failed = 0

    contexts = {
        "/tmp/dx.cpp": _cpp_context(
            "/tmp/dx.cpp",
            struct_field_nodes=[
                {
                    "name": "funcA::da7gl->cmSystem",
                    "metadata": {"asm_alias": "WK_CMO", "enclosing_type": "Da7gl"},
                },
                {
                    "name": "funcB::da7gl->cmSystem",
                    "metadata": {"asm_alias": "WK_CMO", "enclosing_type": "Da7gl"},
                },
            ],
            function_names=["funcA", "funcB"],
        ),
        "/tmp/da78.asm": _asm_context(
            "/tmp/da78.asm",
            memory_nodes=["WK_CMO"],
            function_nodes=[],
        ),
    }
    graph = GlobalLineageStitcher().process_contexts(contexts)
    edge_a = _find_alias_edge(graph, "funcA::da7gl->cmSystem", "WK_CMO")
    edge_b = _find_alias_edge(graph, "funcB::da7gl->cmSystem", "WK_CMO")
    if edge_a and edge_b:
        print("  PASS   two scoped alias edges created (funcA and funcB)")
    else:
        if not edge_a:
            print("  MISSING funcA alias edge")
            failed += 1
        if not edge_b:
            print("  MISSING funcB alias edge")
            failed += 1
    if edge_a and edge_a.scope == "funcA":
        print("  PASS   funcA edge scoped correctly")
    elif edge_a:
        print(f"  WRONG  funcA edge scope is {edge_a.scope!r}")
        failed += 1
    if edge_b and edge_b.scope == "funcB":
        print("  PASS   funcB edge scoped correctly")
    elif edge_b:
        print(f"  WRONG  funcB edge scope is {edge_b.scope!r}")
        failed += 1
    return failed


# --- Main --------------------------------------------------------------------


if __name__ == "__main__":
    f1 = run_positive_single_bridge()
    f2 = run_negative_no_matching_asm()
    f3 = run_negative_no_metadata()
    f4 = run_idempotence()
    f5 = run_multiple_functions_same_field()
    total = f1 + f2 + f3 + f4 + f5

    print()
    if total == 0:
        print(">>> PHASE 4: ALL CHECKS PASSED.")
        sys.exit(0)
    else:
        print(f">>> PHASE 4: {total} checks failed. Patch not yet applied (or incomplete).")
        sys.exit(1)
