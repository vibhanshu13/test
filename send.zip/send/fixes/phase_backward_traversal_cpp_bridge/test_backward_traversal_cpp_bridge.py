#!/usr/bin/env python3
"""Backward-traversal ↔ C++ lineage bridge verification.

Run: python fixes/phase_backward_traversal_cpp_bridge/test_backward_traversal_cpp_bridge.py

Covers the six exit criteria in plan.md §6:
  6.1 extract_asm_field_aliases     (unit)
  6.2 extract_tpf_regs_slots        (unit)
  6.3 trace_cpp_variable_backward   (unit)
  6.4 runner integration — field bridge      (smoke, uses integration_out fixture)
  6.5 runner integration — TPF_regs slots    (smoke, uses integration_out fixture)
  6.6 graceful degradation                  (unit)

6.7 regression (pre/post-change diff on a real chain) is a manual step
documented in the plan — it requires running backward_only before and
after the patch and diffing JSON. Not automated here.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO_ROOT))

# Modules under test — all NEW files this phase introduces.
# Until implemented, these imports will fail and the whole suite reports
# "NOT IMPLEMENTED" for every test. That's the expected baseline state.
try:
    from backward_traversal.utils.cpp_lineage_utils import (  # noqa: E402
        extract_asm_field_aliases,
        find_cpp_seed_nodes,
        extract_tpf_regs_slots,
        reverse_field_alias_map,
    )
    from backward_traversal.tracing.cpp_backward_tracer import (  # noqa: E402
        trace_cpp_variable_backward,
    )
    IMPORT_OK = True
    IMPORT_ERR = ""
except Exception as exc:  # noqa: BLE001
    IMPORT_OK = False
    IMPORT_ERR = f"{type(exc).__name__}: {exc}"


RESULTS: list[tuple[str, str, str]] = []


def check(label: str, cond: bool, detail: str = "") -> None:
    status = "PASS" if cond else "FAIL"
    RESULTS.append((status, label, detail))
    tail = f"   — {detail}" if detail else ""
    print(f"  {status}   {label}{tail}")


def skip(label: str, detail: str = "") -> None:
    RESULTS.append(("SKIP", label, detail))
    tail = f"   — {detail}" if detail else ""
    print(f"  SKIP   {label}{tail}")


# ---------------------------------------------------------------------------
# 6.1 extract_asm_field_aliases
# ---------------------------------------------------------------------------

def test_extract_asm_field_aliases() -> None:
    print("\n" + "=" * 78)
    print("6.1  extract_asm_field_aliases — reverse map + variable filter")
    print("=" * 78)
    if not IMPORT_OK:
        skip("6.1 extract_asm_field_aliases", IMPORT_ERR)
        return

    bp = {
        "field_asm_aliases": {
            "Da7gl.cmSystem": "WK_CMO",
            "Da7gl.noOfLimits": "WK_CNT",
            "CasGLRec.onlineSrcInd": "LG1OSI",
        }
    }
    r1 = extract_asm_field_aliases(bp, "WK_CMO", transitive_vars=[])
    check("WK_CMO maps to Da7gl.cmSystem",
          r1.get("WK_CMO") == ["Da7gl.cmSystem"],
          detail=str(r1))

    r2 = extract_asm_field_aliases(bp, "UNKNOWN", transitive_vars=[])
    check("unknown variable yields empty dict", r2 == {}, detail=str(r2))

    r3 = extract_asm_field_aliases(bp, "wk_cmo", transitive_vars=[])
    check("case-insensitive on ASM name", "WK_CMO" in r3, detail=str(r3))

    r4 = extract_asm_field_aliases(bp, "WK_CMO", transitive_vars=["LG1OSI"])
    check("transitive_vars expand the filter",
          "WK_CMO" in r4 and "LG1OSI" in r4, detail=str(r4))

    alias_only_gvl = {
        "nodes": [
            {
                "id": "struct_field:globalLimitsUpdate::casGlRec->onlineSrcInd",
                "kind": "struct_field",
                "name": "globalLimitsUpdate::casGlRec->onlineSrcInd",
                "metadata": {},
            }
        ],
        "edges": [],
    }
    seeds = find_cpp_seed_nodes(alias_only_gvl, "LG1OSI", r4, {})
    check("alias-only field paths can be rediscovered as C++ seeds",
          any("onlineSrcInd" in s for s in seeds), detail=str(seeds))


# ---------------------------------------------------------------------------
# 6.2 extract_tpf_regs_slots
# ---------------------------------------------------------------------------

def test_extract_tpf_regs_slots() -> None:
    print("\n" + "=" * 78)
    print("6.2  extract_tpf_regs_slots — scan global_variable_lineage for TPF edges")
    print("=" * 78)
    if not IMPORT_OK:
        skip("6.2 extract_tpf_regs_slots", IMPORT_ERR)
        return

    gvl = {
        "nodes": [],
        "edges": [
            {
                "source": "struct_field:globalLimitsUpdate::regs.r7",
                "target": "register:arg@DA78:R7",
                "relation": "assign",
                "expression": "call buildLg1g1",
                "line": 76,
                "file": "dx740200.cpp",
            },
            {
                "source": "struct_field:globalLimitsUpdate::regs.r1",
                "target": "register:arg@DA78:R1",
                "relation": "assign",
                "expression": "call buildLg1g1",
                "line": 76,
                "file": "dx740200.cpp",
            },
            # unrelated edge to verify filtering
            {
                "source": "struct_field:foo::regs.r0",
                "target": "register:arg@DB71:R0",
                "relation": "assign",
                "expression": "call otherCall",
                "line": 44,
                "file": "dx740200.cpp",
            },
        ],
    }

    r = extract_tpf_regs_slots(gvl, "DA78")
    check("DA78 has R7 slot", "R7" in r, detail=str(list(r.keys())))
    check("DA78 has R1 slot", "R1" in r, detail=str(list(r.keys())))
    check("DA78 does NOT include unrelated DB71 edges",
          "R0" not in r, detail=str(list(r.keys())))

    r7 = r.get("R7") or {}
    check("R7 slot carries cpp_sources",
          any("regs.r7" in s for s in (r7.get("cpp_sources") or [])),
          detail=str(r7))
    check("R7 slot carries call_sites with line",
          any((cs.get("line") == 76) for cs in (r7.get("call_sites") or [])),
          detail=str(r7))

    r_empty = extract_tpf_regs_slots(gvl, "NONEXISTENT")
    check("missing callee yields empty dict", r_empty == {}, detail=str(r_empty))


# ---------------------------------------------------------------------------
# 6.3 trace_cpp_variable_backward
# ---------------------------------------------------------------------------

def test_trace_cpp_variable_backward() -> None:
    print("\n" + "=" * 78)
    print("6.3  trace_cpp_variable_backward — BFS over global lineage edges")
    print("=" * 78)
    if not IMPORT_OK:
        skip("6.3 trace_cpp_variable_backward", IMPORT_ERR)
        return

    # Simple chain: literal "Y" → struct_field:da7gl.cmSystem (one assign)
    gvl = {
        "nodes": [
            {"id": "literal:'Y'", "kind": "literal", "name": "'Y'"},
            {"id": "struct_field:f::da7gl->cmSystem",
             "kind": "struct_field",
             "name": "f::da7gl->cmSystem",
             "metadata": {"asm_alias": "WK_CMO"}},
        ],
        "edges": [
            {"source": "literal:'Y'",
             "target": "struct_field:f::da7gl->cmSystem",
             "relation": "assign",
             "line": 122,
             "expression": "da7gl->cmSystem = 'Y'"},
        ],
    }

    res = trace_cpp_variable_backward(
        "struct_field:f::da7gl->cmSystem",
        gvl,
        max_depth=4,
        max_nodes=100,
    )
    check("returns dict with nodes key", isinstance(res.get("nodes"), list))
    check("returns dict with dep_vars key", isinstance(res.get("dep_vars"), list))
    check("seed node present in trace",
          any("da7gl->cmSystem" in str(n.get("id", "")) for n in (res.get("nodes") or [])),
          detail=str([n.get("id") for n in res.get("nodes") or []]))
    check("literal terminal recorded",
          any("literal" in str(n.get("kind", "")) for n in (res.get("nodes") or [])),
          detail=str([n.get("kind") for n in res.get("nodes") or []]))

    # Register terminal should surface as bridge_back_to_asm
    gvl2 = {
        "nodes": [
            {"id": "register:R7", "kind": "register", "name": "R7"},
            {"id": "register:arg@DA78:R7", "kind": "register", "name": "arg@DA78:R7"},
        ],
        "edges": [
            {"source": "register:R7",
             "target": "register:arg@DA78:R7",
             "relation": "alias",
             "expression": "global_lineage_stitch:tpf_regs_register_bridge"},
        ],
    }
    res2 = trace_cpp_variable_backward(
        "register:arg@DA78:R7", gvl2, max_depth=4, max_nodes=100,
    )
    dep_vars_joined = " ".join(str(d) for d in (res2.get("dep_vars") or []))
    check("register terminal surfaces as bridge_back_to_asm",
          "R7" in dep_vars_joined, detail=dep_vars_joined)


# ---------------------------------------------------------------------------
# 6.4 + 6.5 runner integration (requires an integration_out cpp.json fixture)
# ---------------------------------------------------------------------------

def _fixture_cpp_json() -> Path | None:
    candidates = [
        REPO_ROOT / "integration_out" / "asm" / "dx740200.cpp.json",
        REPO_ROOT / "temp" / "output_latest" / "asm" / "dx740200.cpp.json",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def test_runner_field_bridge_smoke() -> None:
    print("\n" + "=" * 78)
    print("6.4  runner integration — asm_field_aliases surfaced at upstream")
    print("=" * 78)
    fx = _fixture_cpp_json()
    if fx is None:
        skip("6.4 runner field bridge", "no integration_out fixture found")
        return
    if not IMPORT_OK:
        skip("6.4 runner field bridge", IMPORT_ERR)
        return

    bp = json.loads(fx.read_text())
    aliases = extract_asm_field_aliases(bp, "WK_CMO", transitive_vars=[])
    check("real fixture: WK_CMO reverses to Da7gl.cmSystem",
          aliases.get("WK_CMO") == ["Da7gl.cmSystem"]
          or "Da7gl.cmSystem" in (aliases.get("WK_CMO") or []),
          detail=str(aliases))


def test_runner_tpf_regs_smoke() -> None:
    print("\n" + "=" * 78)
    print("6.5  runner integration — tpf_regs_slots populated from real fixture")
    print("=" * 78)
    fx = _fixture_cpp_json()
    if fx is None:
        skip("6.5 runner tpf_regs", "no integration_out fixture found")
        return
    if not IMPORT_OK:
        skip("6.5 runner tpf_regs", IMPORT_ERR)
        return

    bp = json.loads(fx.read_text())
    gvl = bp.get("global_variable_lineage") or {}
    slots = extract_tpf_regs_slots(gvl, "DA78")
    check("real fixture: DA78 has at least one TPF slot",
          isinstance(slots, dict) and len(slots) >= 1,
          detail=f"{len(slots)} slots: {sorted(slots.keys())}")
    check("real fixture: DA78 R7 slot is present",
          "R7" in slots or any(s.startswith("R") for s in slots),
          detail=str(sorted(slots.keys())))


# ---------------------------------------------------------------------------
# 6.6 graceful degradation
# ---------------------------------------------------------------------------

def test_graceful_degradation() -> None:
    print("\n" + "=" * 78)
    print("6.6  graceful degradation — missing sections handled")
    print("=" * 78)
    if not IMPORT_OK:
        skip("6.6 graceful degradation", IMPORT_ERR)
        return

    # Missing everything
    bp_empty: dict = {}
    r1 = extract_asm_field_aliases(bp_empty, "WK_CMO", transitive_vars=[])
    check("empty blueprint → empty asm_field_aliases", r1 == {}, detail=str(r1))

    r2 = extract_tpf_regs_slots({}, "DA78")
    check("empty gvl → empty tpf_regs_slots", r2 == {}, detail=str(r2))

    # Walker on empty gvl
    r3 = trace_cpp_variable_backward("struct_field:x", {}, max_depth=4, max_nodes=10)
    check("empty gvl → walker returns empty-but-shaped result",
          isinstance(r3, dict)
          and isinstance(r3.get("nodes"), list)
          and isinstance(r3.get("edges"), list)
          and isinstance(r3.get("dep_vars"), list),
          detail=str(r3))


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def main() -> int:
    print("=" * 78)
    print("  Backward-traversal ↔ C++ lineage bridge — phase verification")
    print("=" * 78)
    if not IMPORT_OK:
        print(f"\nNOT IMPLEMENTED yet — import failed: {IMPORT_ERR}")
        print("Baseline run expected to skip all tests; implement per plan.md §7.\n")

    test_extract_asm_field_aliases()
    test_extract_tpf_regs_slots()
    test_trace_cpp_variable_backward()
    test_runner_field_bridge_smoke()
    test_runner_tpf_regs_smoke()
    test_graceful_degradation()

    print("\n" + "=" * 78)
    passed = sum(1 for r in RESULTS if r[0] == "PASS")
    failed = sum(1 for r in RESULTS if r[0] == "FAIL")
    skipped = sum(1 for r in RESULTS if r[0] == "SKIP")
    print(f"  Results: {passed} PASS / {failed} FAIL / {skipped} SKIP   (total {len(RESULTS)})")
    print("=" * 78)

    if failed:
        for status, label, detail in RESULTS:
            if status == "FAIL":
                print(f"  FAIL  {label}  — {detail}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
