# Backward-Traversal ↔ C++ Lineage Bridge

**Status:** NOT STARTED.
**Source plans:** `docs/plans/2026-04-23-cpp-variable-lineage-strategy 1.md` §9 (tracing scenarios), §11 (file to modify: `trace_cross_file_lineage.py`). Couples to `backward_traversal/` (Pratham's backward-only chain traversal).
**Depends on:** Phases 1–7 + TPF_regs (all DONE) — the enrichment they produce is what this phase consumes.

---

## 1. The gap

Two systems live side-by-side but don't talk:

- **Pratham's backward traversal** (`backward_traversal/`) walks ASM CFGs backward to find where a variable gets set. When the chain hits a C++ upstream file it records "function X called ASM Y at line Z" and stops. No C++-side tracing, no register/field name translation.
- **C++ lineage enrichment** (Phases 1–7 + TPF) produces `field_asm_aliases`, `variable_lineage`, and `global_variable_lineage` inside each `cpp.json` blueprint. This contains the exact bridges needed (`Da7gl.cmSystem → WK_CMO` field bridge, `regs.r1 → arg@DA78:R1 → register:R1` TPF bridge) but the traversal never reads them.

### Concrete symptoms
- Traversal output shows C++ call site but not **what C++ variable carries the data** across the boundary.
- Register operands (`R7`, `R4`) are filtered as dep_var candidates by `is_dep_var_candidate()` — chain through registers dies at the first ASM→C++ handoff.
- Asking "where does ASM `LG1OSI` ultimately come from?" stops at the first C++ file even though `field_asm_aliases["CasGLRec.onlineSrcInd"] = "LG1OSI"` and `variable_lineage` has the full C++ side.

---

## 2. What this phase adds

Wire the traversal's C++-upstream step to consume the cpp blueprint's stitched lineage. Three deliverables, ordered by value / risk:

### 2.1 Bridge surfacing at boundaries (required)
In `_build_cpp_upstream_payload()` (`backward_traversal/runner/backward_only_runner.py`), when `callee_type == "asm"`, also emit:
- **`asm_field_aliases`** — reverse-map from the cpp blueprint's `field_asm_aliases` (ASM DSECT name → C++ qualified struct field), filtered to the variable being traced and transitive dep_vars.
- **`tpf_regs_slots`** — from `global_variable_lineage`, the `struct_field:…regs.rN → register:arg@<callee>:RN` edges at this specific call site (found by matching `callee` against the asm routine stem).

These are pure annotations on the existing upstream payload. No behavior change; no C++ walk. Readers and downstream tools can use them to trace by hand or as seeds for later phases.

### 2.2 C++ lineage backward walker (required)
New module `backward_traversal/tracing/cpp_backward_tracer.py` that mirrors `trace_asm_call_site_backward` but walks `global_variable_lineage` edges instead of ASM CFG blocks:
```
trace_cpp_variable_backward(
    cpp_node_name, cpp_node_kind,
    global_lineage_graph,
    max_depth,
) → { "nodes": [...], "edges": [...], "dep_vars": [...] }
```
The walker is BFS-backward over edges (`target == current_node`), stopping at:
- `literal:*` and `return_value:return@<callee>:*` terminals
- `register:RN` terminals (these are bridges into ASM — surfaced as dep_vars, not followed)
- depth cap

Seeds come from 2.1: the `asm_field_aliases` and `tpf_regs_slots` tell the walker where to start.

### 2.3 Register-bridge lookup in ASM dep_var collection (optional / stretch)
In `trace_asm_call_site_backward`, when a setter/trigger instruction has a register operand that today is silently dropped (e.g. `ST R7, WK_REC` — R7 filtered), record it on the node as `bridge_candidates: ["R7"]` rather than dropping. At the next C++ upstream boundary, pair those candidates with the call site's `tpf_regs_slots` to complete the chain.

Only ship 2.3 if 2.1 + 2.2 land cleanly — it edits the hot path of the ASM tracer and could cause regressions.

---

## 3. Scope

### In scope
- Reading `global_variable_lineage`, `variable_lineage`, `field_asm_aliases` from `*.cpp.json` blueprints.
- Surfacing bridge annotations in the existing backward-only output schema under `files[stem].upstream.*`.
- A new C++-lineage BFS walker that produces node/edge/dep_var output shape-compatible with the existing ASM tracer output (so the merged `call_graph` semantics still hold, one file at a time).
- Wiring 2.1 + 2.2 into `run_backward_only` so the final JSON contains C++ trace results at C++ upstream positions.

### Out of scope
- Modifying any pass in `passes/*.py` or any parser code. The enrichment producers are DONE — we only consume.
- Running the C++ walker across C++ *downstream* files (Pass 2 dep_var downstream BFS currently skips C++). Downstream walks stay ASM-only in this phase.
- Per-function DSECT/USING resolution (`USING WK_REC, R7` → `LG1OSI` at offset X) on the ASM side. This is a separate open problem and would need a different data source (parsed USING directives from the ASM blueprint).
- Forward traversal. This phase is backward-only.
- Cross-blueprint resolution: we trust whatever `global_variable_lineage` block is present in the cpp.json the traversal loads for that stem. If multiple cpp files disagree, the one belonging to the current chain file wins.

---

## 4. Files touched

| File | Change |
|---|---|
| `backward_traversal/utils/cpp_lineage_utils.py` (NEW) | `load_global_lineage(bp_path)`, `extract_asm_field_aliases(bp, variable, transitive_vars)`, `extract_tpf_regs_slots(gvl, callee)`, `reverse_field_alias_map(field_asm_aliases)`. Pure helpers, no side effects. |
| `backward_traversal/tracing/cpp_backward_tracer.py` (NEW) | `trace_cpp_variable_backward(seed_name, seed_kind, gvl, max_depth, max_nodes)`. BFS backward over `global_variable_lineage` edges; returns `{nodes, edges, dep_vars, terminals}`. |
| `backward_traversal/runner/backward_only_runner.py` | In `_build_cpp_upstream_payload()`, after existing call-site discovery, load the cpp blueprint, compute `asm_field_aliases` + `tpf_regs_slots`, then run `trace_cpp_variable_backward` from each bridge seed. Attach results under `upstream.cpp_traces`, `upstream.asm_field_aliases`, `upstream.tpf_regs_slots`. |
| `backward_traversal/README.md` | Add a "C++ Bridge" section documenting the three new output keys and the scope labels used on C++-side traces. |

No changes to `glossary/instructions.py`, `token_utils.py`, or `asm_backward_tracer.py` in this phase (2.3 is deferred).

---

## 5. Implementation notes

### 5.1 `extract_asm_field_aliases`
```python
def extract_asm_field_aliases(bp, variable, transitive_vars):
    """From cpp blueprint's field_asm_aliases ({struct.field: ASMNAME}),
    build reverse map filtered to the ASM names the traversal cares about.

    Returns: { "LG1OSI": ["CasGLRec.onlineSrcInd", ...], ... }
    """
    wanted = {variable.upper(), *{v.upper() for v in transitive_vars}}
    rev = {}
    for cpp_field, asm_name in (bp.get("field_asm_aliases") or {}).items():
        a = asm_name.upper()
        if a in wanted:
            rev.setdefault(a, []).append(cpp_field)
    return rev
```

### 5.2 `extract_tpf_regs_slots`
Scan `global_variable_lineage.edges` for the distinctive pattern:
```
source startswith "struct_field:" and ".r" or "->r" in source
target startswith "register:arg@<CALLEE_UPPER>:R" or "parameter:arg@…"
relation == "assign"
expression startswith "call " OR contains callee name
```
Group by register slot. Output:
```json
{
  "R1": {
    "cpp_sources": ["struct_field:globalLimitsUpdate::regs.r1"],
    "call_sites": [{"file": "dx740200.cpp", "line": 76, "expression": "call buildLg1g1"}]
  },
  "R7": { ... }
}
```

### 5.3 `trace_cpp_variable_backward`
BFS-backward with depth cap. Node output mirrors existing ASM call_graph nodes:
```json
{
  "id": "struct_field:globalLimitsUpdate::da7gl.cmSystem",
  "kind": "struct_field",
  "asm_alias": "WK_CMO",
  "relevant_edges": [
    {"source": "...", "relation": "assign", "line": 122, "expression": "..."}
  ],
  "dependent_variables": ["hubgl->message.input.cmSystemId"]
}
```
Terminals (literal, return_value, register) mark `kind` but are not expanded further. Register terminals become `bridge_back_to_asm` entries in the dep_var list so downstream consumers can pivot back to ASM if needed.

### 5.4 Wiring into `_build_cpp_upstream_payload`
Add a block after the existing `call_sites` assembly for the `callee_type == "asm"` branch:
```python
bp_path = blueprint_dir / f"{caller}.cpp.json"
bp = load_json(bp_path) if bp_path.exists() else None
gvl = (bp or {}).get("global_variable_lineage") or {}

asm_field_aliases = extract_asm_field_aliases(bp or {}, variable, transitive_vars=[])
tpf_regs_slots   = extract_tpf_regs_slots(gvl, callee)

cpp_traces = []
for seed in _seeds_from_bridges(asm_field_aliases, tpf_regs_slots, gvl):
    cpp_traces.append(trace_cpp_variable_backward(seed, gvl, max_depth=max_depth))

return {
    "role": "upstream",
    "file_type": "cpp",
    "edge_type": edge_instruction,
    "call_sites": call_sites,
    "asm_field_aliases": asm_field_aliases,
    "tpf_regs_slots": tpf_regs_slots,
    "cpp_traces": cpp_traces,
    "call_graph": {...}   # existing
}
```
`variable` threads through to this helper from `run_backward_only`; `transitive_vars` is wired later if we want filtering by dep_var set (optional).

### 5.5 Graceful degradation
- Missing `cpp.json` → existing behavior, emit empty `asm_field_aliases`/`tpf_regs_slots`, no cpp_traces.
- `global_variable_lineage` absent or empty → emit empty, no crash.
- `field_asm_aliases` empty → `asm_field_aliases` empty.
- No bridge seeds match the variable → `cpp_traces: []`, still records `call_sites` as today.

---

## 6. Verification (exit criteria)

`fixes/phase_backward_traversal_cpp_bridge/test_backward_traversal_cpp_bridge.py`.

### 6.1 `extract_asm_field_aliases` — unit
Fixture `field_asm_aliases = {"Da7gl.cmSystem": "WK_CMO", "Da7gl.noOfLimits": "WK_CNT"}`.
- Trace variable `WK_CMO` → result `{"WK_CMO": ["Da7gl.cmSystem"]}`.
- Trace variable `UNKNOWN` → `{}`.
- Case-insensitive on ASM name.

### 6.2 `extract_tpf_regs_slots` — unit
Synthetic `global_variable_lineage` with edge `struct_field:f::regs.r7 → register:arg@DA78:R7 assign expr="call buildLg1g1"`.
- `extract_tpf_regs_slots(gvl, "DA78")` → dict with key `"R7"`, `cpp_sources` containing the struct_field, call_sites with the line/expression.
- `extract_tpf_regs_slots(gvl, "DB71")` → `{}` (no match).

### 6.3 `trace_cpp_variable_backward` — unit
Synthetic gvl: `literal:"Y" → struct_field:f::da7gl->cmSystem` assign line 122.
- Seed `struct_field:f::da7gl->cmSystem` → one-node trace with literal terminal, `dependent_variables` empty.
- With a register terminal: `register:R7 → parameter:arg@DA78:R7`, seed `arg@DA78:R7` → dep_var list contains `bridge_back_to_asm:R7`.

### 6.4 Runner integration — smoke
Uses real `integration_out/asm/dx740200.cpp.json` fixture.
- Chain `[something_that_calls_dx740200, dx740200]` with variable `WK_CMO`.
- Assert `files["dx740200"].upstream.asm_field_aliases["WK_CMO"]` contains `"Da7gl.cmSystem"`.
- Assert `files["dx740200"].upstream.cpp_traces` is non-empty and traces at least one `da7gl->cmSystem` assignment.

### 6.5 TPF_regs bridge — smoke
Same fixture, chain with variable corresponding to R7 usage.
- Assert `files[<cpp>].upstream.tpf_regs_slots` has R1–R7 entries for DA78 call site.

### 6.6 Graceful degradation
- Synthetic cpp.json with no `global_variable_lineage` → runner still completes, `cpp_traces: []`, no crash.
- Non-cc cpp file (dx750000 — 0 field_asm_aliases) → `asm_field_aliases: {}` empty but `tpf_regs_slots` still populated from replicated `global_variable_lineage`.

### 6.7 Regression
Run existing backward-only fixture (e.g. the `LG1OSI` chain the README documents) before and after; diff output — all pre-existing keys unchanged, only new keys added under `upstream`.

---

## 7. Resume

1. Read this plan.
2. Run baseline test — expect FAIL on 6.1–6.6, PASS on 6.7 (no changes yet).
3. Implement `cpp_lineage_utils.py` (§5.1, §5.2) — unit tests 6.1, 6.2 pass.
4. Implement `cpp_backward_tracer.py` (§5.3) — unit test 6.3 passes.
5. Wire into runner (§5.4) — smoke tests 6.4, 6.5, 6.6 pass.
6. Re-run 6.7 regression — assert no pre-existing keys changed.
7. Update `backward_traversal/README.md` with the new output keys.
8. Commit; mark `fixes/README.md` row for this phase DONE.

Optional follow-up: Phase 2.3 (register bridge lookup in ASM tracer) as a separate plan.
