#!/usr/bin/env python3
"""Validation tests for POST .../keyword-file-flow.

Tests verify:
  1. Auth / routing (401, 403, 404)
  2. Per-flow fields: chain, steps (alias), modifier_file, name, length_files, summary
  3. Top-level overview fields: file_count, top_files, total_usage, direct_flows, all_files
  4. all_files entry shape: name, directory, path, type, usage_count
  5. User message persisted to chat session on each call
  6. Empty flows → 200 + empty keyword_file_flows, overview fields default to 0/[]
  7. Overview fields populated when search_variable_usages returns data
"""
from __future__ import annotations

import json
import shutil
import sys
import uuid
from pathlib import Path
from typing import Any, Dict, List
from unittest import mock

import msgpack
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from api.app import app  # noqa: E402
from api.auth import create_access_token, hash_password  # noqa: E402
from api.config import settings  # noqa: E402
from api.db import SessionLocal, create_tables  # noqa: E402
from api.models.knowledge_base import KnowledgeBase, KnowledgeBaseAccess  # noqa: E402
from api.models.user import User  # noqa: E402
from api.storage.workspace import WorkspaceManager  # noqa: E402

# ---------------------------------------------------------------------------
# Test accounting
# ---------------------------------------------------------------------------

PASS = 0
FAIL = 0
_CREATED_KBS: List[str] = []
_CREATED_USERS: List[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS  {name}" + (f"  [{detail}]" if detail else ""))
    else:
        FAIL += 1
        print(f"  FAIL  {name}" + (f"  [{detail}]" if detail else ""))


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _create_user(db, username: str, role: str = "user") -> User:
    user = User(
        username=username,
        hashed_password=hash_password("TestPass123!"),
        role=role,
        is_active=True,
    )
    db.add(user)
    _CREATED_USERS.append(username)
    return user


def _create_kb(db, kb_id: str, *, status: str = "success", created_by: str = "admin") -> KnowledgeBase:
    kb = KnowledgeBase(
        id=kb_id,
        name=f"KFF Test {kb_id[:8]}",
        created_by=created_by,
        datasource_username=None,
        datasource_folder=None,
        source_path="/tmp/src",
        status=status,
        error=None,
    )
    db.add(kb)
    _CREATED_KBS.append(kb_id)
    return kb


def _auth_headers(username: str, role: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {create_access_token(username, role)}"}


def _prepare_kb(db, admin_username: str) -> str:
    kb_id = str(uuid.uuid4())
    _create_kb(db, kb_id, status="success", created_by=admin_username)
    db.commit()
    ws = WorkspaceManager(kb_id)
    for d in (ws.root, ws.input_dir, ws.output_dir, ws.cache_dir):
        d.mkdir(parents=True, exist_ok=True)
    # Write a minimal file_call_graph.json so _find_file_flows doesn't error
    (ws.output_dir / "file_call_graph.json").write_text(
        json.dumps({"nodes": [], "edges": []}), encoding="utf-8"
    )
    return kb_id


def _write_conversation(kb_id: str, conv_id: str) -> None:
    conv_dir = WorkspaceManager(kb_id).output_dir / "conversations"
    conv_dir.mkdir(parents=True, exist_ok=True)
    conv: Dict[str, Any] = {
        "version": 1,
        "conv_id": conv_id,
        "process": "lu82",
        "keyword": None,
        "backward_session_id": None,
        "root_variable": None,
        "selected_chain": [],
        "keyword_file_flows": [],
        "messages": [],
        "chat_session_id": None,
        "created_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-01T00:00:00+00:00",
    }
    (conv_dir / f"{conv_id}.msgpack").write_bytes(msgpack.packb(conv, use_bin_type=True))


def _load_conv(kb_id: str, conv_id: str) -> Dict[str, Any]:
    path = WorkspaceManager(kb_id).output_dir / "conversations" / f"{conv_id}.msgpack"
    return msgpack.unpackb(path.read_bytes(), raw=False)


def _load_chat_session(kb_id: str, chat_session_id: str) -> Dict[str, Any]:
    path = (
        settings.JOBS_BASE_DIR
        / kb_id / "output" / "chat_sessions"
        / f"{chat_session_id}.msgpack"
    )
    return msgpack.unpackb(path.read_bytes(), raw=False)


# Fake flows returned by _find_file_flows
_FAKE_FLOWS: List[Dict[str, Any]] = [
    {"chain": ["lu82", "mn04", "ux12"], "modifier_file": "lu82"},
    {"chain": ["au03", "dx70"],         "modifier_file": "au03"},
]

# Fake search_variable_usages result
_FAKE_USAGE_RESULT: Dict[str, Any] = {
    "found": True,
    "total_files": 4,
    "total_locations": 27,
    "files": [
        {"file_path": "lu82.asm", "file_stem": "lu82", "total_locations": 12},
        {"file_path": "mn04.asm", "file_stem": "mn04", "total_locations": 8},
        {"file_path": "ux12.asm", "file_stem": "ux12", "total_locations": 5},
        {"file_path": "src/cpp/auth.cpp", "file_stem": "auth", "total_locations": 2},
    ],
}


# ---------------------------------------------------------------------------
# Group 1: Auth / Routing
# ---------------------------------------------------------------------------

def test_auth_and_routing(
    client: TestClient,
    admin_headers: Dict[str, str],
    user_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("1. auth + routing")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/keyword-file-flow"

        # Unauthenticated
        resp = client.post(url, json={"keyword": "LG1OSI"})
        check("unauthenticated → 401", resp.status_code == 401, str(resp.status_code))

        # User without KB access
        resp = client.post(url, json={"keyword": "LG1OSI"}, headers=user_headers)
        check("no-access user → 403", resp.status_code == 403, str(resp.status_code))

        # Unknown KB
        resp = client.post(
            f"/v1/knowledge-bases/{uuid.uuid4()}/conversations/{conv_id}/keyword-file-flow",
            json={"keyword": "LG1OSI"}, headers=admin_headers,
        )
        check("unknown KB → 404", resp.status_code == 404, str(resp.status_code))

        # Unknown conversation
        resp = client.post(
            f"/v1/knowledge-bases/{kb_id}/conversations/{uuid.uuid4()}/keyword-file-flow",
            json={"keyword": "LG1OSI"}, headers=admin_headers,
        )
        check("unknown conv → 404", resp.status_code == 404, str(resp.status_code))

        # Valid request — mock flows and overview
        with (
            mock.patch("api.routes.conversations._find_file_flows", return_value=(_FAKE_FLOWS, None)),
            mock.patch("api.utils.variable_search.search_variable_usages",
                       return_value=_FAKE_USAGE_RESULT),
        ):
            resp = client.post(url, json={"keyword": "LG1OSI"}, headers=admin_headers)
        check("valid request → 200", resp.status_code == 200, str(resp.status_code))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 2: Per-flow fields
# ---------------------------------------------------------------------------

def test_per_flow_fields(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("2. per-flow fields")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/keyword-file-flow"

        with (
            mock.patch("api.routes.conversations._find_file_flows", return_value=(_FAKE_FLOWS, None)),
            mock.patch("api.utils.variable_search.search_variable_usages",
                       return_value=_FAKE_USAGE_RESULT),
        ):
            resp = client.post(url, json={"keyword": "LG1OSI"}, headers=admin_headers)

        assert resp.status_code == 200
        data = resp.json()
        flows = data.get("keyword_file_flows", [])

        check("2 flows returned", len(flows) == 2, str(len(flows)))

        f0 = flows[0] if flows else {}

        # id (stable internal key)
        check("flow.id present", bool(f0.get("id")), str(f0.get("id")))

        # chain field
        check("flow.chain is list", isinstance(f0.get("chain"), list),
              str(type(f0.get("chain"))))
        check("flow.chain == ['lu82','mn04','ux12']",
              f0.get("chain") == ["lu82", "mn04", "ux12"],
              str(f0.get("chain")))

        # steps = alias for chain
        check("flow.steps is list", isinstance(f0.get("steps"), list),
              str(type(f0.get("steps"))))
        check("flow.steps == flow.chain",
              f0.get("steps") == f0.get("chain"),
              f"steps={f0.get('steps')}  chain={f0.get('chain')}")

        # modifier_file
        check("flow.modifier_file present", bool(f0.get("modifier_file")),
              str(f0.get("modifier_file")))
        check("flow.modifier_file == 'lu82'", f0.get("modifier_file") == "lu82",
              str(f0.get("modifier_file")))

        # name
        check("flow.name present", bool(f0.get("name")), str(f0.get("name")))
        check("flow.name contains chain items joined by →",
              "lu82" in f0.get("name", "") and "→" in f0.get("name", ""),
              str(f0.get("name")))

        # length_files
        check("flow.length_files == 3",
              f0.get("length_files") == 3, str(f0.get("length_files")))

        # summary
        check("flow.summary present", bool(f0.get("summary")), str(f0.get("summary")))

        # Second flow
        f1 = flows[1] if len(flows) > 1 else {}
        check("flow[1].chain == ['au03','dx70']",
              f1.get("chain") == ["au03", "dx70"], str(f1.get("chain")))
        check("flow[1].steps == ['au03','dx70']",
              f1.get("steps") == ["au03", "dx70"], str(f1.get("steps")))
        check("flow[1].length_files == 2",
              f1.get("length_files") == 2, str(f1.get("length_files")))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 3: Top-level overview fields presence and types
# ---------------------------------------------------------------------------

def test_overview_fields_present(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("3. overview fields — presence and types")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/keyword-file-flow"

        with (
            mock.patch("api.routes.conversations._find_file_flows", return_value=(_FAKE_FLOWS, None)),
            mock.patch("api.utils.variable_search.search_variable_usages",
                       return_value=_FAKE_USAGE_RESULT),
        ):
            resp = client.post(url, json={"keyword": "LG1OSI"}, headers=admin_headers)

        assert resp.status_code == 200
        data = resp.json()

        # _lightweight_overview derives overview from flows_raw (5 unique stems)
        check("file_count present", "file_count" in data, str(list(data.keys())))
        check("file_count is int", isinstance(data.get("file_count"), int),
              str(type(data.get("file_count"))))
        check("file_count == 5 (unique stems in flows)", data.get("file_count") == 5,
              str(data.get("file_count")))

        check("top_files present", "top_files" in data, str(list(data.keys())))
        check("top_files is list", isinstance(data.get("top_files"), list),
              str(type(data.get("top_files"))))
        check("top_files has 3 entries", len(data.get("top_files", [])) == 3,
              str(data.get("top_files")))

        check("total_usage present", "total_usage" in data, str(list(data.keys())))
        check("total_usage is int", isinstance(data.get("total_usage"), int),
              str(type(data.get("total_usage"))))
        check("total_usage == 5 (sum of stem flow counts)", data.get("total_usage") == 5,
              str(data.get("total_usage")))

        check("direct_flows present", "direct_flows" in data, str(list(data.keys())))
        check("direct_flows is int", isinstance(data.get("direct_flows"), int),
              str(type(data.get("direct_flows"))))
        check("direct_flows == 2 (len of flows_raw)",
              data.get("direct_flows") == 2, str(data.get("direct_flows")))

        check("all_files present", "all_files" in data, str(list(data.keys())))
        check("all_files is list", isinstance(data.get("all_files"), list),
              str(type(data.get("all_files"))))
        check("all_files has 5 entries (unique stems)", len(data.get("all_files", [])) == 5,
              str(len(data.get("all_files", []))))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 4: all_files entry shape
# ---------------------------------------------------------------------------

def test_all_files_entry_shape(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("4. all_files entry shape")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/keyword-file-flow"

        with (
            mock.patch("api.routes.conversations._find_file_flows", return_value=(_FAKE_FLOWS, None)),
            mock.patch("api.utils.variable_search.search_variable_usages",
                       return_value=_FAKE_USAGE_RESULT),
        ):
            resp = client.post(url, json={"keyword": "LG1OSI"}, headers=admin_headers)

        assert resp.status_code == 200
        all_files = resp.json().get("all_files", [])

        # _lightweight_overview: 5 stems from flows, all count=1, sorted stable by insertion order
        f0 = all_files[0] if all_files else {}
        check("all_files[0].name present", bool(f0.get("name")), str(f0.get("name")))
        check("all_files[0].name is string", isinstance(f0.get("name"), str),
              str(type(f0.get("name"))))
        check("all_files[0].directory present", "directory" in f0, str(list(f0.keys())))
        check("all_files[0].path present", bool(f0.get("path")), str(f0.get("path")))
        check("all_files[0].type in ('asm','cpp')",
              f0.get("type") in ("asm", "cpp"), str(f0.get("type")))
        check("all_files[0].usage_count is int",
              isinstance(f0.get("usage_count"), int), str(type(f0.get("usage_count"))))
        check("all_files[0].usage_count == 1 (one flow per stem)",
              f0.get("usage_count") == 1, str(f0.get("usage_count")))
        check("all_files[0].name == 'lu82.asm' (first stem in chain order)",
              f0.get("name") == "lu82.asm", str(f0.get("name")))

        # Last entry: dx70.asm (5th stem, type=asm since call graph has no nodes)
        f_last = all_files[-1] if len(all_files) >= 5 else {}
        check("last entry type == 'asm' (no cpp nodes in call graph)",
              f_last.get("type") == "asm", str(f_last.get("type")))
        check("last entry name == 'dx70.asm'",
              f_last.get("name") == "dx70.asm", str(f_last.get("name")))

        # Sorted descending by usage_count
        counts = [f.get("usage_count", 0) for f in all_files]
        check("all_files sorted descending by usage_count",
              counts == sorted(counts, reverse=True), str(counts))

        # top_files = first 3 names
        top = resp.json().get("top_files", [])
        names_first3 = [f.get("name") for f in all_files[:3]]
        check("top_files == first 3 all_files names",
              top == names_first3, f"top={top}  first3={names_first3}")
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 5: User message persisted to chat session
# ---------------------------------------------------------------------------

def test_user_message_persisted(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("5. user message persisted to chat session")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/keyword-file-flow"

        with (
            mock.patch("api.routes.conversations._find_file_flows", return_value=(_FAKE_FLOWS, None)),
            mock.patch("api.utils.variable_search.search_variable_usages",
                       return_value=_FAKE_USAGE_RESULT),
        ):
            resp = client.post(url, json={"keyword": "lg1osi"}, headers=admin_headers)

        assert resp.status_code == 200

        # chat_session_id must be written to the conversation
        conv_data = _load_conv(kb_id, conv_id)
        chat_session_id = conv_data.get("chat_session_id")
        check("chat_session_id written to conversation",
              bool(chat_session_id), str(chat_session_id))

        if not chat_session_id:
            return

        session = _load_chat_session(kb_id, chat_session_id)
        msgs = session.get("messages") or []

        check("at least 1 message in chat session", len(msgs) >= 1, str(len(msgs)))

        user_msg = msgs[0] if msgs else {}
        check("user message role == 'user'",
              user_msg.get("role") == "user", str(user_msg.get("role")))
        check("user message content == keyword (original case)",
              user_msg.get("content") == "lg1osi", str(user_msg.get("content")))
        check("user message has cm-u- prefixed msg_id",
              str(user_msg.get("msg_id", "")).startswith("cm-u-"),
              str(user_msg.get("msg_id")))
        check("user message has timestamp",
              bool(user_msg.get("timestamp")), str(user_msg.get("timestamp")))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 6: GET /conversations/{conv_id} returns user msg in chatbot_messages
# ---------------------------------------------------------------------------

def test_user_msg_visible_in_conversation_detail(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("6. GET /conversations/{conv_id} returns keyword user msg in chatbot_messages")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        kff_url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/keyword-file-flow"
        detail_url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}"

        with (
            mock.patch("api.routes.conversations._find_file_flows", return_value=(_FAKE_FLOWS, None)),
            mock.patch("api.utils.variable_search.search_variable_usages",
                       return_value=_FAKE_USAGE_RESULT),
        ):
            client.post(kff_url, json={"keyword": "LG1OSI"}, headers=admin_headers)

        resp = client.get(detail_url, headers=admin_headers)
        check("GET conversation → 200", resp.status_code == 200, str(resp.status_code))

        data = resp.json()
        chatbot_msgs = data.get("chatbot_messages", [])
        check("chatbot_messages contains at least 1 entry",
              len(chatbot_msgs) >= 1, str(len(chatbot_msgs)))

        user_msgs = [m for m in chatbot_msgs if m.get("role") == "user"]
        check("at least 1 user-role message in chatbot_messages",
              len(user_msgs) >= 1, str(chatbot_msgs))

        if user_msgs:
            um = user_msgs[0]
            check("keyword user msg text == 'LG1OSI'",
                  um.get("text") == "LG1OSI", str(um.get("text")))
            check("keyword user msg msg_id starts with 'cm-u-'",
                  str(um.get("id", "")).startswith("cm-u-"),
                  str(um.get("id")))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 7: Empty flows
# ---------------------------------------------------------------------------

def test_empty_flows(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("7. empty flows → 200 with default overview")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/keyword-file-flow"

        with mock.patch("api.routes.conversations._find_file_flows", return_value=([], None)):
            resp = client.post(url, json={"keyword": "UNKNOWN"}, headers=admin_headers)

        check("empty flows → 200", resp.status_code == 200, str(resp.status_code))
        data = resp.json()
        check("keyword_file_flows is []",
              data.get("keyword_file_flows") == [], str(data.get("keyword_file_flows")))
        check("file_count == 0", data.get("file_count") == 0, str(data.get("file_count")))
        check("top_files == []", data.get("top_files") == [], str(data.get("top_files")))
        check("total_usage == 0", data.get("total_usage") == 0, str(data.get("total_usage")))
        check("direct_flows == 0", data.get("direct_flows") == 0, str(data.get("direct_flows")))
        check("all_files == []", data.get("all_files") == [], str(data.get("all_files")))

        # user message still persisted even when no flows found
        conv_data = _load_conv(kb_id, conv_id)
        check("chat_session_id written even when no flows",
              bool(conv_data.get("chat_session_id")), str(conv_data.get("chat_session_id")))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Group 8: overview falls back gracefully if search raises
# ---------------------------------------------------------------------------

def test_overview_fallback_on_error(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("8. overview falls back to zeros if search_variable_usages raises")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username)
        conv_id = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id)

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/keyword-file-flow"

        # _lightweight_overview never calls search_variable_usages, so the side_effect
        # won't fire. Overview is derived from flows_raw (5 unique stems).
        with (
            mock.patch("api.routes.conversations._find_file_flows", return_value=(_FAKE_FLOWS, None)),
            mock.patch("api.utils.variable_search.search_variable_usages",
                       side_effect=FileNotFoundError("asm_variable_universe.json not found")),
        ):
            resp = client.post(url, json={"keyword": "LG1OSI"}, headers=admin_headers)

        check("still returns 200", resp.status_code == 200, str(resp.status_code))
        data = resp.json()
        check("flows still returned",
              len(data.get("keyword_file_flows", [])) == 2,
              str(len(data.get("keyword_file_flows", []))))
        check("file_count derived from flows == 5",
              data.get("file_count") == 5, str(data.get("file_count")))
        check("direct_flows still = len(flows_raw) = 2",
              data.get("direct_flows") == 2, str(data.get("direct_flows")))
        check("all_files derived from flows has 5 entries",
              len(data.get("all_files", [])) == 5, str(len(data.get("all_files", []))))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

def cleanup() -> None:
    db = SessionLocal()
    try:
        for kb_id in _CREATED_KBS:
            db.query(KnowledgeBaseAccess).filter(
                KnowledgeBaseAccess.kb_id == kb_id
            ).delete()
            db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).delete()
            shutil.rmtree(WorkspaceManager(kb_id).root, ignore_errors=True)
        for username in _CREATED_USERS:
            db.query(User).filter(User.username == username).delete()
        db.commit()
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    create_tables()
    suffix = uuid.uuid4().hex[:8]
    admin_username = f"kff_admin_{suffix}"
    user_username  = f"kff_user_{suffix}"

    db = SessionLocal()
    try:
        _create_user(db, admin_username, role="admin")
        _create_user(db, user_username,  role="user")
        db.commit()
    finally:
        db.close()

    admin_headers = _auth_headers(admin_username, "admin")
    user_headers  = _auth_headers(user_username,  "user")

    try:
        with TestClient(app) as client:
            test_auth_and_routing(client, admin_headers, user_headers, admin_username)
            test_per_flow_fields(client, admin_headers, admin_username)
            test_overview_fields_present(client, admin_headers, admin_username)
            test_all_files_entry_shape(client, admin_headers, admin_username)
            test_user_message_persisted(client, admin_headers, admin_username)
            test_user_msg_visible_in_conversation_detail(client, admin_headers, admin_username)
            test_empty_flows(client, admin_headers, admin_username)
            test_overview_fallback_on_error(client, admin_headers, admin_username)
    finally:
        cleanup()

    print(f"\n{'=' * 70}")
    print(f"Results: {PASS} PASS / {FAIL} FAIL / {PASS + FAIL} total")
    print(f"{'=' * 70}")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
