from __future__ import annotations

import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))

from blueprint_io import pack_blueprint
from call_graph.topological_block_flow import build_block_flow


def _write_compressed_blueprint(path: Path, payload: dict) -> None:
    path.write_bytes(pack_blueprint(payload, compress=True))


def test_block_flow_reads_compressed_blueprints(tmp_path: Path) -> None:
    parser_dir = tmp_path / "parser"
    out_dir = tmp_path / "out"
    parser_dir.mkdir(parents=True, exist_ok=True)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Minimal ASM blueprint: B1 flows into B2.
    asm_blueprint = {
        "blocks": [
            {
                "id": "B1",
                "incoming_branches": [],
                "flow": [{"line": 10, "inst": "NOP"}],
                "start_line": 10,
                "end_line": 12,
            },
            {
                "id": "B2",
                "incoming_branches": [{"source": "B1"}],
                "flow": [{"line": 20, "inst": "NOP"}],
                "start_line": 20,
                "end_line": 25,
            },
        ]
    }
    _write_compressed_blueprint(parser_dir / "sample.asm.json", asm_blueprint)

    # Minimal C++ blueprint: foo calls bar, so bar should appear before foo.
    cpp_src = parser_dir / "sample.cpp"
    cpp_src.write_text(
        "int bar(){return 1;}\n"
        "int foo(){return bar();}\n",
        encoding="utf-8",
    )
    cpp_blueprint = {
        "variable_lineage": {
            "edges": [
                {"scope": "foo", "line": 2, "file": str(cpp_src)},
                {"scope": "bar", "line": 1, "file": str(cpp_src)},
            ]
        },
        "call_graph": {"edges": [{"source": "foo", "target": "bar"}]},
    }
    _write_compressed_blueprint(parser_dir / "sample.cpp.json", cpp_blueprint)

    result = build_block_flow(str(parser_dir), str(out_dir))

    files = result.get("files", [])
    assert len(files) == 2
    assert sum(1 for f in files if f.get("type") == "asm") == 1
    assert sum(1 for f in files if f.get("type") == "cpp") == 1

    asm_entry = next(f for f in files if f.get("type") == "asm")
    cpp_entry = next(f for f in files if f.get("type") == "cpp")

    assert [b["id"] for b in asm_entry["blocks"]] == ["B1", "B2"]
    assert [b["id"] for b in cpp_entry["blocks"]] == ["bar", "foo"]

    output_file = out_dir / "block_flow.json"
    assert output_file.exists()
    saved = json.loads(output_file.read_text(encoding="utf-8"))
    assert len(saved.get("files", [])) == 2
