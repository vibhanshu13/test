# Phase: Equivalent Variable Resolution in Backward Traversal

## Problem

`backward_only_runner.py` always searches for a variable by its **exact same name**
when crossing file boundaries — whether tracing the root variable upstream through
the selected chain, or tracing the root/dep variables into downstream files discovered
via cross-file calls.

Variables often have different local names across files (different DSECT field aliases,
different symbol names for the same physical memory location). This means setter sites
go undetected in any file where the variable is not referenced under the exact same
symbol.

## Root Cause

Three call sites in `run_backward_only` pass the variable name as-is across file
boundaries without resolving the local equivalent:

1. **Pass 1 — upstream chain pairs** (line ~951):
   `_build_asm_upstream_payload(variable=variable, caller=caller, ...)` — the same
   `root_var` string is used for every file in the chain regardless of how that file
   refers to the variable.

2. **Pass 1b — root_var downstream BFS** (line ~1111):
   `_build_dep_var_file_result(root_var, ..., ds_stem, ...)` — root_var name is used
   verbatim in every downstream file encountered via cross-file ENTRC calls.

3. **Pass 2-B — dep_var downstream BFS** (line ~1259):
   `_build_dep_var_file_result(Di, ..., ds_stem, ...)` — dep_var name used verbatim
   when entering downstream files.

`get_equivalent_variable.py` already exists on this branch and implements 5 resolution
strategies (Access Identity, DSECT+Offset, Direct Name, Parameter Bridge, Global Alias).
It is only wired as a CLI tool; it has no programmatic API.

## Changes Required

### Change 1 — `get_equivalent_variable.py`: expose programmatic API

Extract the chain-walk logic into a public callable:

```python
def resolve_equivalent_variable(
    chain: List[str],     # source file(s) where the variable is known
    target_stem: str,     # file to resolve the variable name in
    variable: str,        # name/id in the source file
    blueprint_dir: str,
) -> Optional[str]:       # local name in target_stem, or None if unresolvable
```

`main()` becomes a thin wrapper around this function.

Also extend `load_blueprint` to try `.cpp.json` as a fallback when `.asm.json` is
absent, so chains that include C++ files do not silently skip resolution.

### Change 2 — Pass 1: root_var in upstream chain pairs

In the `for caller, callee in upstream_pairs:` loop, before calling
`_build_asm_upstream_payload` or `_build_cpp_upstream_payload`, resolve the root_var
equivalent in `caller`:

```python
caller_var = resolve_equivalent_variable(
    chain=[callee],
    target_stem=caller,
    variable=variable,
    blueprint_dir=str(blueprint_dir),
) or variable
```

Pass `caller_var` as `variable=` to both upstream payload builders.

Source context: `callee` — the next file downstream where the variable name is
already known.

### Change 3 — Pass 1b: root_var downstream BFS

Before `_build_dep_var_file_result(root_var, ..., ds_stem, ...)`, resolve:

```python
ds_root_var = resolve_equivalent_variable(
    chain=[stem],
    target_stem=ds_stem,
    variable=root_var,
    blueprint_dir=str(blueprint_dir),
) or root_var
```

Use `ds_root_var` in the call. For recursive BFS hops from `ds_stem`, carry the
resolved name forward (it becomes the new `root_var` for that sub-path).

Source context: `stem` — the chain file that triggered the cross-file call to `ds_stem`.

### Change 4 — Pass 2-B: dep_var downstream BFS

Before `_build_dep_var_file_result(Di, ..., ds_stem, ...)`, resolve:

```python
di_source_stem = next(iter(dep_var_collection_map.get(Di, {})), None)
ds_Di = resolve_equivalent_variable(
    chain=[di_source_stem] if di_source_stem else [],
    target_stem=ds_stem,
    variable=Di,
    blueprint_dir=str(blueprint_dir),
) or Di
```

Use `ds_Di` in the call.

Source context: the first chain file in `dep_var_collection_map[Di]` — the file where
the dep_var was originally collected, which establishes its physical identity.

### Change 5 — Pass 2-B: dep_var in chain files (defensive)

Before `_build_dep_var_file_result(Di, ..., stem, ...)` for chain files, resolve using
`modifier_stem` as the source context. This guards against dep_vars that leaked in from
a different chain file via the `dep_var_collection_map` union with a different local name.

## Exit Criteria

The following are verified by the test suite in this directory:

| # | Description |
|---|-------------|
| 1.1 | `resolve_equivalent_variable` callable exists and is importable |
| 1.2 | Access Identity match returns correct node id |
| 1.3 | DSECT + Offset match returns correct node id |
| 1.4 | Global alias/bridge match returns correct node id |
| 1.5 | Unresolvable variable returns `None` |
| 1.6 | Missing blueprint returns `None` without exception |
| 1.7 | `load_blueprint` falls back to `.cpp.json` |
| 2.1 | Pass 1 upstream: resolved name is passed to `_build_asm_upstream_payload` |
| 2.2 | Pass 1 upstream: falls back to original name when resolution fails |
| 3.1 | Pass 1b downstream: resolved root_var name used in `_build_dep_var_file_result` |
| 3.2 | Pass 1b downstream: falls back to original root_var when resolution fails |
| 4.1 | Pass 2-B downstream: resolved dep_var name used in `_build_dep_var_file_result` |
| 4.2 | Pass 2-B downstream: falls back to original dep_var when resolution fails |
| 5.1 | Graceful: empty blueprint dict does not raise |
| 5.2 | Graceful: empty chain list does not raise |

## Manual Regression Step

Run a real backward-only trace on a known chain before and after the patch, then diff
the JSON output. Setter sites that were previously missing because of name mismatch
should now appear. Document in the PR description which variables and which files
gained new setter sites.
