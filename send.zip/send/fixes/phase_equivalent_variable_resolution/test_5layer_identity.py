#!/usr/bin/env python3
"""5-Layer Variable Identity System — comprehensive edge-case test suite.

Tests all identity layers, complex cross-file rename chains, strategy
fallback ordering, helper functions, and end-to-end tracing on real
blueprint data.

Run:
    python fixes/phase_equivalent_variable_resolution/test_5layer_identity.py
"""
from __future__ import annotations

import sys
import tempfile
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO_ROOT))

# ---------------------------------------------------------------------------
# Import guard
# ---------------------------------------------------------------------------
try:
    from get_equivalent_variable import (
        resolve_equivalent_variable,
        find_match_in_file,
        get_physical_identity,
        _collect_symbolic_identity_map,
        _collect_access_identities,
        _collect_dsect_offset_map,
    )
    from models.variable_lineage import VariableEdge
    from passes.cross_file_access_identity import (
        _symbolic_name_from_node,
        _extract_plain_label,
        enrich_access_identity,
    )
    IMPORT_OK = True
    IMPORT_ERR = ""
except Exception as exc:
    IMPORT_OK = False
    IMPORT_ERR = f"{type(exc).__name__}: {exc}"

RESULTS: list = []


def check(label: str, cond: bool, detail: str = "") -> None:
    status = "PASS" if cond else "FAIL"
    RESULTS.append((status, label, detail))
    tail = f"   — {detail}" if detail else ""
    print(f"  {status}   {label}{tail}")


def skip(label: str, detail: str = "") -> None:
    RESULTS.append(("SKIP", label, detail))
    tail = f"   — {detail}" if detail else ""
    print(f"  SKIP   {label}{tail}")


# ---------------------------------------------------------------------------
# Blueprint factory helpers
# ---------------------------------------------------------------------------

def _make_bp(
    *,
    nodes: Optional[List[Dict]] = None,
    edges: Optional[List[Dict]] = None,
    gvl_edges: Optional[List[Dict]] = None,
) -> Dict[str, Any]:
    """Build a blueprint dict directly from provided nodes/edges."""
    return {
        "variable_lineage": {
            "nodes": nodes or [],
            "edges": edges or [],
        },
        "global_variable_lineage": {
            "nodes": [],
            "edges": gvl_edges or [],
        },
    }


def _mem_node(name: str, **meta) -> Dict:
    """Build a memory-kind node."""
    d = {"id": f"memory:{name}", "name": name, "kind": "memory"}
    if meta:
        d["metadata"] = meta
    return d


def _edge(src: str, tgt: str, rel: str = "assign", **fields) -> Dict:
    """Build an edge dict. src/tgt are full node IDs."""
    e = {"source": src, "target": tgt, "relation": rel, "file": "test.asm", "line": 1}
    e.update(fields)
    return e


# ---------------------------------------------------------------------------
# A. VariableEdge model — new fields
# ---------------------------------------------------------------------------

def test_model_fields() -> None:
    print("\n" + "=" * 78)
    print("A. VariableEdge model — symbolic_identity and file_label fields")
    print("=" * 78)
    if not IMPORT_OK:
        skip("A1 symbolic_identity field exists", IMPORT_ERR)
        skip("A2 file_label field exists", IMPORT_ERR)
        skip("A3 Neither field appears in to_dict() when None", IMPORT_ERR)
        skip("A4 Both fields serialise when set", IMPORT_ERR)
        return

    e = VariableEdge(
        source="memory:FOO", target="memory:BAR",
        relation="assign", file="test.asm", line=1,
    )
    check("A1 symbolic_identity field exists (default None)",
          hasattr(e, "symbolic_identity") and e.symbolic_identity is None,
          f"symbolic_identity={e.symbolic_identity!r}")
    check("A2 file_label field exists (default None)",
          hasattr(e, "file_label") and e.file_label is None,
          f"file_label={e.file_label!r}")

    d = e.to_dict()
    check("A3 symbolic_identity absent from dict when None",
          "symbolic_identity" not in d, str(list(d.keys())))
    check("A4 file_label absent from dict when None",
          "file_label" not in d, str(list(d.keys())))

    e.symbolic_identity = "LG1G1:LG1OSI"
    e.file_label = "da76:WB1ACCTC"
    d2 = e.to_dict()
    check("A5 symbolic_identity serialises when set",
          d2.get("symbolic_identity") == "LG1G1:LG1OSI",
          str(d2.get("symbolic_identity")))
    check("A6 file_label serialises when set",
          d2.get("file_label") == "da76:WB1ACCTC",
          str(d2.get("file_label")))


# ---------------------------------------------------------------------------
# B. Helper: _symbolic_name_from_node / _extract_plain_label
# ---------------------------------------------------------------------------

def test_helper_functions() -> None:
    print("\n" + "=" * 78)
    print("B. Helper functions: _symbolic_name_from_node, _extract_plain_label")
    print("=" * 78)
    if not IMPORT_OK:
        for i in range(1, 13):
            skip(f"B{i}", IMPORT_ERR)
        return

    # _symbolic_name_from_node
    check("B1  DSECT-qualified node → field name",
          _symbolic_name_from_node("memory:LG1G1:LG1OSI", "LG1G1") == "LG1OSI",
          repr(_symbolic_name_from_node("memory:LG1G1:LG1OSI", "LG1G1")))

    check("B2  Numeric field → None (L3 not L2)",
          _symbolic_name_from_node("memory:LG1G1:17", "LG1G1") is None,
          repr(_symbolic_name_from_node("memory:LG1G1:17", "LG1G1")))

    check("B3  DSECT mismatch → None",
          _symbolic_name_from_node("memory:WB1WB:WB1SUPP", "LG1G1") is None,
          repr(_symbolic_name_from_node("memory:WB1WB:WB1SUPP", "LG1G1")))

    check("B4  Non-memory kind → None",
          _symbolic_name_from_node("register:R5", "LG1G1") is None,
          repr(_symbolic_name_from_node("register:R5", "LG1G1")))

    check("B5  Displacement suffix stripped (LG1G1:WB1ACCTC+12 → WB1ACCTC)",
          _symbolic_name_from_node("memory:LG1G1:WB1ACCTC+12", "LG1G1") == "WB1ACCTC+12".split("+")[0],
          repr(_symbolic_name_from_node("memory:LG1G1:WB1ACCTC+12", "LG1G1")))

    check("B6  Base register suffix stripped (memory:LG1G1:LG1OSI(R5) → LG1OSI)",
          _symbolic_name_from_node("memory:LG1G1:LG1OSI(R5)", "LG1G1") == "LG1OSI",
          repr(_symbolic_name_from_node("memory:LG1G1:LG1OSI(R5)", "LG1G1")))

    # _extract_plain_label
    check("B7  Plain memory label extracted",
          _extract_plain_label("memory:WB1SUPP") == "WB1SUPP",
          repr(_extract_plain_label("memory:WB1SUPP")))

    check("B8  Numeric node → None",
          _extract_plain_label("memory:17") is None,
          repr(_extract_plain_label("memory:17")))

    check("B9  Negative numeric → None",
          _extract_plain_label("memory:-1") is None,
          repr(_extract_plain_label("memory:-1")))

    check("B10 DSECT-qualified → None (already handled by Pass 1)",
          _extract_plain_label("memory:LG1G1:LG1OSI") is None,
          repr(_extract_plain_label("memory:LG1G1:LG1OSI")))

    check("B11 Synthetic node (@) → None",
          _extract_plain_label("memory:alloc@/foo:123") is None,
          repr(_extract_plain_label("memory:alloc@/foo:123")))

    check("B12 Register kind → None",
          _extract_plain_label("register:R5") is None,
          repr(_extract_plain_label("register:R5")))

    check("B13 Displacement suffix stripped before numeric check (WB1SUPP+4 → WB1SUPP)",
          _extract_plain_label("memory:WB1SUPP+4") == "WB1SUPP",
          repr(_extract_plain_label("memory:WB1SUPP+4")))

    check("B14 Base-register stripped (memory:WB1SUPP(R7) → WB1SUPP)",
          _extract_plain_label("memory:WB1SUPP(R7)") == "WB1SUPP",
          repr(_extract_plain_label("memory:WB1SUPP(R7)")))


# ---------------------------------------------------------------------------
# C. _collect_symbolic_identity_map
# ---------------------------------------------------------------------------

def test_collect_symbolic_identity_map() -> None:
    print("\n" + "=" * 78)
    print("C. _collect_symbolic_identity_map")
    print("=" * 78)
    if not IMPORT_OK:
        for i in range(1, 7):
            skip(f"C{i}", IMPORT_ERR)
        return

    # C1: basic map
    bp = _make_bp(
        nodes=[_mem_node("LG1OSI"), _mem_node("WB1SUPP")],
        edges=[
            _edge("memory:LG1OSI", "use:x", symbolic_identity="LG1G1:LG1OSI"),
            _edge("memory:WB1SUPP", "use:y", symbolic_identity="WB1WB:WB1SUPP"),
        ],
    )
    smap = _collect_symbolic_identity_map(bp)
    check("C1 LG1G1:LG1OSI maps to memory:LG1OSI",
          "memory:LG1OSI" in smap.get("LG1G1:LG1OSI", set()),
          str(smap.get("LG1G1:LG1OSI")))
    check("C2 WB1WB:WB1SUPP maps to memory:WB1SUPP",
          "memory:WB1SUPP" in smap.get("WB1WB:WB1SUPP", set()),
          str(smap.get("WB1WB:WB1SUPP")))

    # C3: non-memory nodes are excluded
    bp2 = _make_bp(
        nodes=[{"id": "register:R5", "name": "R5", "kind": "register"}],
        edges=[_edge("register:R5", "use:z", symbolic_identity="LG1G1:LG1OSI")],
    )
    smap2 = _collect_symbolic_identity_map(bp2)
    check("C3 register node excluded from symbolic_identity map",
          len(smap2.get("LG1G1:LG1OSI", set())) == 0,
          str(smap2))

    # C4: multiple nodes with same symbolic_identity → set union
    bp3 = _make_bp(
        nodes=[_mem_node("ALIAS_A"), _mem_node("ALIAS_B")],
        edges=[
            _edge("memory:ALIAS_A", "use:a", symbolic_identity="LG1G1:LG1OSI"),
            _edge("memory:ALIAS_B", "use:b", symbolic_identity="LG1G1:LG1OSI"),
        ],
    )
    smap3 = _collect_symbolic_identity_map(bp3)
    check("C4 two nodes with same symbolic_identity → both in set",
          smap3.get("LG1G1:LG1OSI", set()) == {"memory:ALIAS_A", "memory:ALIAS_B"},
          str(smap3.get("LG1G1:LG1OSI")))

    # C5: empty blueprint
    smap4 = _collect_symbolic_identity_map({})
    check("C5 empty blueprint → empty map",
          smap4 == {}, str(smap4))

    # C6: edges without symbolic_identity are ignored
    bp4 = _make_bp(
        nodes=[_mem_node("PLAIN")],
        edges=[_edge("memory:PLAIN", "use:p")],  # no symbolic_identity
    )
    smap5 = _collect_symbolic_identity_map(bp4)
    check("C6 edges without symbolic_identity excluded",
          len(smap5) == 0, str(smap5))


# ---------------------------------------------------------------------------
# D. get_physical_identity — now returns 4-tuple
# ---------------------------------------------------------------------------

def test_get_physical_identity() -> None:
    print("\n" + "=" * 78)
    print("D. get_physical_identity — 4-tuple with symbolic_identity")
    print("=" * 78)
    if not IMPORT_OK:
        for i in range(1, 8):
            skip(f"D{i}", IMPORT_ERR)
        return

    # D1: empty blueprint → (None, None, None, None)
    result = get_physical_identity({}, "memory:FOO")
    check("D1 empty blueprint returns 4-tuple of Nones",
          result == (None, None, None, None), str(result))

    # D2: access_identity from edge
    bp = _make_bp(
        nodes=[_mem_node("LG1OSI")],
        edges=[_edge("memory:LG1OSI", "use:x",
                     dsect="LG1G1", field_offset=28,
                     access_identity="CE1CR5:28",
                     symbolic_identity="LG1G1:LG1OSI")],
    )
    d, o, ai, si = get_physical_identity(bp, "memory:LG1OSI")
    check("D2a access_identity returned from edge",
          ai == "CE1CR5:28", f"ai={ai!r}")
    check("D2b symbolic_identity returned alongside access_identity",
          si == "LG1G1:LG1OSI", f"si={si!r}")

    # D3: symbolic_identity from edge, no access_identity
    bp2 = _make_bp(
        nodes=[_mem_node("WB1SUPP")],
        edges=[_edge("memory:WB1SUPP", "use:y",
                     dsect="WB1WB", field_offset=65,
                     symbolic_identity="WB1WB:WB1SUPP")],
    )
    d2, o2, ai2, si2 = get_physical_identity(bp2, "memory:WB1SUPP")
    check("D3a dsect returned when no access_identity",
          d2 == "WB1WB", f"dsect={d2!r}")
    check("D3b field_offset returned",
          o2 == 65, f"offset={o2!r}")
    check("D3c access_identity is None",
          ai2 is None, f"ai={ai2!r}")
    check("D3d symbolic_identity captured from edge",
          si2 == "WB1WB:WB1SUPP", f"si={si2!r}")

    # D4: node_id not in blueprint → all Nones
    d3, o3, ai3, si3 = get_physical_identity(bp2, "memory:UNKNOWN")
    check("D4 unknown node_id → all Nones",
          (d3, o3, ai3, si3) == (None, None, None, None), str((d3, o3, ai3, si3)))


# ---------------------------------------------------------------------------
# E. Strategy 2.5 — Symbolic Identity Match in find_match_in_file
# ---------------------------------------------------------------------------

def test_strategy_symbolic_identity() -> None:
    print("\n" + "=" * 78)
    print("E. Strategy 2.5 — Symbolic Identity Match")
    print("=" * 78)
    if not IMPORT_OK:
        for i in range(1, 9):
            skip(f"E{i}", IMPORT_ERR)
        return

    # E1: Matches when symbolic_identity is the only identity key available
    curr = _make_bp(
        nodes=[_mem_node("RENAMED_FIELD")],
        edges=[_edge("memory:RENAMED_FIELD", "use:x",
                     symbolic_identity="LG1G1:LG1OSI")],
    )
    match, strat = find_match_in_file(
        None, curr, "memory:LG1OSI",
        None, None, None,
        target_symbolic_id="LG1G1:LG1OSI",
    )
    check("E1 Matches via symbolic_identity alone (variable renamed)",
          match == "memory:RENAMED_FIELD",
          f"match={match!r}")
    check("E1b Strategy name mentions Symbolic",
          strat and "Symbolic" in strat,
          f"strat={strat!r}")

    # E2: Prefers prev_name when it's in the candidate set
    curr2 = _make_bp(
        nodes=[_mem_node("LG1OSI"), _mem_node("ALIAS_LG1OSI")],
        edges=[
            _edge("memory:LG1OSI", "use:a", symbolic_identity="LG1G1:LG1OSI"),
            _edge("memory:ALIAS_LG1OSI", "use:b", symbolic_identity="LG1G1:LG1OSI"),
        ],
    )
    match2, strat2 = find_match_in_file(
        None, curr2, "memory:LG1OSI",
        None, None, None,
        target_symbolic_id="LG1G1:LG1OSI",
    )
    check("E2 Prefers prev_name when it is in candidates",
          match2 == "memory:LG1OSI",
          f"match={match2!r}")
    check("E2b Strategy name includes 'Name + DSECT'",
          strat2 and "Name" in strat2,
          f"strat={strat2!r}")

    # E3: Strategy 2.5 fires BEFORE strategy 3 (ECB Field Match)
    # Set up: curr has both symbolic_identity AND ecb_field, but with DIFFERENT nodes
    curr3 = _make_bp(
        nodes=[_mem_node("SYM_NODE"), _mem_node("ECB_NODE")],
        edges=[
            _edge("memory:SYM_NODE", "use:s", symbolic_identity="LG1G1:LG1OSI"),
        ],
    )
    # ECB field would find ECB_NODE, but symbolic should find SYM_NODE first
    match3, strat3 = find_match_in_file(
        None, curr3, "memory:ORIG",
        None, None, None,
        target_ecb_field="MY_ECB_FIELD",  # ECB matches ECB_NODE
        target_symbolic_id="LG1G1:LG1OSI",  # Symbolic matches SYM_NODE
    )
    check("E3 Strategy 2.5 fires before Strategy 3 (ECB Field)",
          match3 == "memory:SYM_NODE" and strat3 and "Symbolic" in strat3,
          f"match={match3!r}, strat={strat3!r}")

    # E4: Falls through to Strategy 3 when no symbolic_identity candidates
    curr4 = _make_bp(
        nodes=[_mem_node("ECB_VAR")],
        edges=[],
    )
    # Add ecb_field to node metadata
    curr4["variable_lineage"]["nodes"][0]["metadata"] = {"ecb_field": "MY_ECB_FIELD"}
    match4, strat4 = find_match_in_file(
        None, curr4, "memory:ORIG",
        None, None, None,
        target_ecb_field="MY_ECB_FIELD",
        target_symbolic_id="LG1G1:NONEXISTENT",  # no match
    )
    check("E4 Falls through to ECB Field when no symbolic match",
          strat4 and ("ECB" in strat4 or "Field" in strat4),
          f"match={match4!r}, strat={strat4!r}")

    # E5: Access Identity (L1) still fires first before Symbolic (L2)
    curr5 = _make_bp(
        nodes=[_mem_node("AI_NODE"), _mem_node("SYM_NODE2")],
        edges=[
            _edge("memory:AI_NODE", "use:a", access_identity="CE1CR5:28"),
            _edge("memory:SYM_NODE2", "use:b", symbolic_identity="LG1G1:LG1OSI"),
        ],
    )
    match5, strat5 = find_match_in_file(
        None, curr5, "memory:ORIG",
        None, None, "CE1CR5:28",
        target_symbolic_id="LG1G1:LG1OSI",
    )
    check("E5 Strategy 2 (access_identity) fires before 2.5 (symbolic)",
          match5 == "memory:AI_NODE" and strat5 and "Access Identity" in strat5,
          f"match={match5!r}, strat={strat5!r}")

    # E6: Returns (None, None) when no strategies match
    curr6 = _make_bp(
        nodes=[_mem_node("UNRELATED")],
        edges=[_edge("memory:UNRELATED", "use:u")],
    )
    match6, strat6 = find_match_in_file(
        None, curr6, "memory:ORIG",
        None, None, None,
        target_symbolic_id="LG1G1:DOES_NOT_EXIST",
    )
    check("E6 Returns (None, None) when nothing matches",
          match6 is None and strat6 is None,
          f"match={match6!r}, strat={strat6!r}")


# ---------------------------------------------------------------------------
# F. Cross-file rename scenarios — single hop
# ---------------------------------------------------------------------------

def test_single_hop_rename() -> None:
    print("\n" + "=" * 78)
    print("F. Cross-file rename — single hop, all identity layers")
    print("=" * 78)
    if not IMPORT_OK:
        for i in range(1, 7):
            skip(f"F{i}", IMPORT_ERR)
        return

    def _chain(origin_bp, target_bp, origin_var: str) -> Optional[str]:
        """Run resolve_equivalent_variable using a tmpdir with fake blueprints."""
        import msgpack
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "file_a.asm.json").write_bytes(msgpack.packb(origin_bp, use_bin_type=True))
            (p / "file_b.asm.json").write_bytes(msgpack.packb(target_bp, use_bin_type=True))
            return resolve_equivalent_variable(["file_a", "file_b"], "file_b", origin_var, tmpdir)

    # F1: L1 — access_identity match
    origin = _make_bp(
        nodes=[_mem_node("LG1OSI")],
        edges=[_edge("memory:LG1OSI", "use:a", access_identity="CE1CR5:28")],
    )
    target = _make_bp(
        nodes=[_mem_node("OSI_RENAMED")],
        edges=[_edge("memory:OSI_RENAMED", "use:b", access_identity="CE1CR5:28")],
    )
    r1 = _chain(origin, target, "LG1OSI")
    check("F1 L1 access_identity: finds renamed variable",
          r1 == "OSI_RENAMED", f"result={r1!r}")

    # F2: L2 — symbolic_identity match (no access_identity)
    origin2 = _make_bp(
        nodes=[_mem_node("LG1OSI")],
        edges=[_edge("memory:LG1OSI", "use:a",
                     dsect="LG1G1", field_offset=28,
                     symbolic_identity="LG1G1:LG1OSI")],
    )
    target2 = _make_bp(
        nodes=[_mem_node("OSI_V2")],
        edges=[_edge("memory:OSI_V2", "use:b",
                     dsect="LG1G1", field_offset=28,
                     symbolic_identity="LG1G1:LG1OSI")],
    )
    r2 = _chain(origin2, target2, "LG1OSI")
    check("F2 L2 symbolic_identity: finds renamed variable",
          r2 == "OSI_V2", f"result={r2!r}")

    # F3: L3 — DSECT+Offset match (no symbolic_identity, no access_identity)
    origin3 = _make_bp(
        nodes=[_mem_node("LG1OSI")],
        edges=[_edge("memory:LG1OSI", "use:a", dsect="LG1G1", field_offset=28)],
    )
    target3 = _make_bp(
        nodes=[_mem_node("OSI_V3")],
        edges=[_edge("memory:OSI_V3", "use:b", dsect="LG1G1", field_offset=28)],
    )
    r3 = _chain(origin3, target3, "LG1OSI")
    check("F3 L3 DSECT+Offset: finds renamed variable",
          r3 == "OSI_V3", f"result={r3!r}")

    # F4: L4 file_label — NOT usable for cross-file rename (correct: returns None)
    origin4 = _make_bp(
        nodes=[_mem_node("LOCAL_VAR")],
        edges=[_edge("memory:LOCAL_VAR", "use:a", file_label="file_a:LOCAL_VAR")],
    )
    target4 = _make_bp(
        nodes=[_mem_node("SOME_OTHER")],
        edges=[_edge("memory:SOME_OTHER", "use:b", file_label="file_b:SOME_OTHER")],
    )
    r4 = _chain(origin4, target4, "LOCAL_VAR")
    check("F4 L4 file_label NOT used for cross-file (correctly returns None or name match only)",
          r4 is None or r4 == "LOCAL_VAR",   # may match by name if same name
          f"result={r4!r}")

    # F5: Same name in target — direct name match
    origin5 = _make_bp(
        nodes=[_mem_node("WB1STCK")],
        edges=[_edge("memory:WB1STCK", "use:a")],
    )
    target5 = _make_bp(
        nodes=[_mem_node("WB1STCK")],
        edges=[_edge("memory:WB1STCK", "use:b")],
    )
    r5 = _chain(origin5, target5, "WB1STCK")
    check("F5 Direct name match when variable has same name in target",
          r5 == "WB1STCK", f"result={r5!r}")

    # F6: Variable completely absent in target
    origin6 = _make_bp(
        nodes=[_mem_node("LG1OSI")],
        edges=[_edge("memory:LG1OSI", "use:a")],
    )
    target6 = _make_bp(
        nodes=[_mem_node("UNRELATED")],
        edges=[_edge("memory:UNRELATED", "use:b")],
    )
    r6 = _chain(origin6, target6, "LG1OSI")
    check("F6 Returns None when variable has no identity trail and not in target",
          r6 is None, f"result={r6!r}")


# ---------------------------------------------------------------------------
# G. Multi-hop rename chains
# ---------------------------------------------------------------------------

def test_multi_hop_rename() -> None:
    print("\n" + "=" * 78)
    print("G. Multi-hop rename chains (3+ files)")
    print("=" * 78)
    if not IMPORT_OK:
        for i in range(1, 7):
            skip(f"G{i}", IMPORT_ERR)
        return

    import msgpack

    def _run_chain(blueprints_by_stem: dict, chain: list, target: str, var: str) -> Optional[str]:
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            for stem, bp in blueprints_by_stem.items():
                (p / f"{stem}.asm.json").write_bytes(msgpack.packb(bp, use_bin_type=True))
            return resolve_equivalent_variable(chain, target, var, tmpdir)

    SYM_ID = "LG1G1:LG1OSI"

    # G1: 4-hop chain — renamed at every step
    # fileA: LG1OSI → fileB: OSI_V2 → fileC: OSI_V3 → fileD: OSI_FINAL
    def _bp_with_sym(var_name: str) -> dict:
        return _make_bp(
            nodes=[_mem_node(var_name)],
            edges=[_edge(f"memory:{var_name}", "use:x",
                         dsect="LG1G1", field_offset=28,
                         symbolic_identity=SYM_ID)],
        )

    bps = {
        "fileA": _bp_with_sym("LG1OSI"),
        "fileB": _bp_with_sym("OSI_V2"),
        "fileC": _bp_with_sym("OSI_V3"),
        "fileD": _bp_with_sym("OSI_FINAL"),
    }
    r1 = _run_chain(bps, ["fileA", "fileB", "fileC", "fileD"], "fileD", "LG1OSI")
    check("G1 4-hop chain: rename at every step, symbolic_identity traces to final name",
          r1 == "OSI_FINAL", f"result={r1!r}")

    # G2: Variable not present in middle file — identity carried through
    bps2 = {
        "f1": _bp_with_sym("LG1OSI"),
        "f2": _make_bp(nodes=[], edges=[]),   # middle file — doesn't reference variable
        "f3": _bp_with_sym("OSI_END"),
    }
    r2 = _run_chain(bps2, ["f1", "f2", "f3"], "f3", "LG1OSI")
    check("G2 Variable absent in middle file — identity carried, found at end",
          r2 == "OSI_END", f"result={r2!r}")

    # G3: Multiple identity layers across files — L1 in one, L2 in another
    bps3 = {
        "f1": _make_bp(
            nodes=[_mem_node("LG1OSI")],
            edges=[_edge("memory:LG1OSI", "use:a",
                         dsect="LG1G1", field_offset=28,
                         access_identity="CE1CR5:28",
                         symbolic_identity="LG1G1:LG1OSI")],
        ),
        "f2": _make_bp(
            nodes=[_mem_node("NEW_NAME")],
            edges=[_edge("memory:NEW_NAME", "use:b",
                         dsect="LG1G1", field_offset=28,
                         symbolic_identity="LG1G1:LG1OSI")],  # no access_identity
        ),
    }
    r3 = _run_chain(bps3, ["f1", "f2"], "f2", "LG1OSI")
    check("G3 L1 in origin, L2 in target — both work together",
          r3 == "NEW_NAME", f"result={r3!r}")

    # G4: 3-round rename simulation (A→B→C→D via same symbolic_identity)
    names = ["ORIGINAL", "ROUND1_NAME", "ROUND2_NAME", "ROUND3_NAME"]
    bps4 = {f"r{i}": _bp_with_sym(names[i]) for i in range(4)}
    r4 = _run_chain(bps4, ["r0", "r1", "r2", "r3"], "r3", "ORIGINAL")
    check("G4 3-round rename (A→B→C→D): all traceable via symbolic_identity",
          r4 == "ROUND3_NAME", f"result={r4!r}")

    # G5: 5-file chain, renamed only in first and last
    bps5 = {
        "s1": _bp_with_sym("ORIGINAL"),
        "s2": _bp_with_sym("ORIGINAL"),   # same name
        "s3": _make_bp(nodes=[], edges=[]),  # absent
        "s4": _bp_with_sym("ORIGINAL"),   # same name
        "s5": _bp_with_sym("FINAL_NAME"),  # renamed
    }
    r5 = _run_chain(bps5, ["s1", "s2", "s3", "s4", "s5"], "s5", "ORIGINAL")
    check("G5 5-file chain: renamed only at end, traced correctly",
          r5 == "FINAL_NAME", f"result={r5!r}")

    # G6: Identity trail goes cold (no dsect, no symbolic, no access_identity)
    bps6 = {
        "cold1": _make_bp(
            nodes=[_mem_node("LOCAL_A")],
            edges=[_edge("memory:LOCAL_A", "use:a", file_label="cold1:LOCAL_A")],
        ),
        "cold2": _make_bp(
            nodes=[_mem_node("LOCAL_B")],
            edges=[_edge("memory:LOCAL_B", "use:b", file_label="cold2:LOCAL_B")],
        ),
    }
    r6 = _run_chain(bps6, ["cold1", "cold2"], "cold2", "LOCAL_A")
    check("G6 Trail goes cold for file-local variables (no cross-file identity → None)",
          r6 is None, f"result={r6!r}")


# ---------------------------------------------------------------------------
# H. has_identity includes target_symbolic_id (trail continuity)
# ---------------------------------------------------------------------------

def test_identity_trail_continuity() -> None:
    print("\n" + "=" * 78)
    print("H. Identity trail continuity — symbolic_identity keeps trail alive")
    print("=" * 78)
    if not IMPORT_OK:
        for i in range(1, 4):
            skip(f"H{i}", IMPORT_ERR)
        return

    import msgpack

    SYM_ID = "LG1G1:LG1ACT"

    def _bp_sym(var_name: str) -> dict:
        return _make_bp(
            nodes=[_mem_node(var_name)],
            edges=[_edge(f"memory:{var_name}", "use:x",
                         dsect="LG1G1", field_offset=5,
                         symbolic_identity=SYM_ID)],
        )

    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir)
        # File 1: origin with LG1ACT + symbolic_identity
        (p / "f1.asm.json").write_bytes(msgpack.packb(_bp_sym("LG1ACT"), use_bin_type=True))
        # File 2: variable absent — identity carried through
        (p / "f2.asm.json").write_bytes(msgpack.packb(
            _make_bp(nodes=[], edges=[]), use_bin_type=True))
        # File 3: variable absent again
        (p / "f3.asm.json").write_bytes(msgpack.packb(
            _make_bp(nodes=[], edges=[]), use_bin_type=True))
        # File 4: final — found with different name
        (p / "f4.asm.json").write_bytes(msgpack.packb(_bp_sym("LG1ACT_NEW"), use_bin_type=True))

        r = resolve_equivalent_variable(["f1", "f2", "f3", "f4"], "f4", "LG1ACT", tmpdir)
        check("H1 symbolic_identity keeps trail alive through 2 empty intermediate files",
              r == "LG1ACT_NEW", f"result={r!r}")

        # H2: All identities absent → trail goes cold on first empty file
        (p / "g1.asm.json").write_bytes(msgpack.packb(
            _make_bp(nodes=[_mem_node("PLAIN")], edges=[
                _edge("memory:PLAIN", "use:x")  # no identity at all
            ]), use_bin_type=True))
        (p / "g2.asm.json").write_bytes(msgpack.packb(
            _make_bp(nodes=[], edges=[]), use_bin_type=True))
        (p / "g3.asm.json").write_bytes(msgpack.packb(
            _make_bp(nodes=[_mem_node("PLAIN")], edges=[
                _edge("memory:PLAIN", "use:y")
            ]), use_bin_type=True))
        r2 = resolve_equivalent_variable(["g1", "g2", "g3"], "g3", "PLAIN", tmpdir)
        check("H2 No identity → trail cold at empty intermediate, returns None or direct match",
              r2 is None or r2 == "PLAIN",  # None if trail cold, PLAIN if name match at final
              f"result={r2!r}")


# ---------------------------------------------------------------------------
# I. Rename in different positions of chain
# ---------------------------------------------------------------------------

def test_rename_position() -> None:
    print("\n" + "=" * 78)
    print("I. Rename position — beginning, middle, end of chain")
    print("=" * 78)
    if not IMPORT_OK:
        for i in range(1, 4):
            skip(f"I{i}", IMPORT_ERR)
        return

    import msgpack

    SYM_ID = "WB1WB:WB1SUPP"

    def _bp_sym(var_name: str) -> dict:
        return _make_bp(
            nodes=[_mem_node(var_name)],
            edges=[_edge(f"memory:{var_name}", "use:x",
                         dsect="WB1WB", field_offset=65,
                         symbolic_identity=SYM_ID)],
        )

    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir)
        original = "WB1SUPP"
        renamed = "SUPP_NEW"

        # I1: Renamed at position 1 (first hop)
        blueprints = {
            "i1_a": _bp_sym(original),
            "i1_b": _bp_sym(renamed),   # renamed immediately
            "i1_c": _bp_sym(renamed),   # still renamed name
        }
        for stem, bp in blueprints.items():
            (p / f"{stem}.asm.json").write_bytes(msgpack.packb(bp, use_bin_type=True))

        r1 = resolve_equivalent_variable(["i1_a", "i1_b", "i1_c"], "i1_c", original, tmpdir)
        check("I1 Rename at position 1 (first hop): traces to final name",
              r1 == renamed, f"result={r1!r}")

        # I2: Renamed at position 2 (middle of 4-file chain)
        blueprints2 = {
            "i2_a": _bp_sym(original),
            "i2_b": _bp_sym(original),   # same name
            "i2_c": _bp_sym(renamed),    # renamed in middle
            "i2_d": _bp_sym(renamed),    # stays renamed
        }
        for stem, bp in blueprints2.items():
            (p / f"{stem}.asm.json").write_bytes(msgpack.packb(bp, use_bin_type=True))

        r2 = resolve_equivalent_variable(["i2_a", "i2_b", "i2_c", "i2_d"], "i2_d", original, tmpdir)
        check("I2 Rename at position 2 (middle hop): traces to final name",
              r2 == renamed, f"result={r2!r}")

        # I3: Renamed only at last hop
        blueprints3 = {
            "i3_a": _bp_sym(original),
            "i3_b": _bp_sym(original),
            "i3_c": _bp_sym(original),
            "i3_d": _bp_sym(renamed),   # renamed only at last hop
        }
        for stem, bp in blueprints3.items():
            (p / f"{stem}.asm.json").write_bytes(msgpack.packb(bp, use_bin_type=True))

        r3 = resolve_equivalent_variable(["i3_a", "i3_b", "i3_c", "i3_d"], "i3_d", original, tmpdir)
        check("I3 Rename only at last hop: traces correctly",
              r3 == renamed, f"result={r3!r}")


# ---------------------------------------------------------------------------
# J. Edge cases and robustness
# ---------------------------------------------------------------------------

def test_edge_cases() -> None:
    print("\n" + "=" * 78)
    print("J. Edge cases and robustness")
    print("=" * 78)
    if not IMPORT_OK:
        for i in range(1, 9):
            skip(f"J{i}", IMPORT_ERR)
        return

    import msgpack

    # J1: Chain of length 1 (origin = target)
    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir)
        bp = _make_bp(
            nodes=[_mem_node("FOO")],
            edges=[_edge("memory:FOO", "use:x", symbolic_identity="LG1G1:FOO")],
        )
        (p / "only_file.asm.json").write_bytes(msgpack.packb(bp, use_bin_type=True))
        r = resolve_equivalent_variable(["only_file"], "only_file", "FOO", tmpdir)
        check("J1 Single-file chain (source = target) returns original name",
              r == "FOO", f"result={r!r}")

    # J2: Empty chain list
    r2 = resolve_equivalent_variable([], "x", "FOO", "/tmp")
    check("J2 Empty chain returns None without exception",
          r2 is None, f"result={r2!r}")

    # J3: Missing blueprint at intermediate step — skips gracefully
    import msgpack
    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir)
        bp_a = _make_bp(
            nodes=[_mem_node("VAR")],
            edges=[_edge("memory:VAR", "use:x", symbolic_identity="LG1G1:VAR")],
        )
        bp_c = _make_bp(
            nodes=[_mem_node("VAR_END")],
            edges=[_edge("memory:VAR_END", "use:y", symbolic_identity="LG1G1:VAR")],
        )
        (p / "a.asm.json").write_bytes(msgpack.packb(bp_a, use_bin_type=True))
        # b.asm.json intentionally missing
        (p / "c.asm.json").write_bytes(msgpack.packb(bp_c, use_bin_type=True))

        r3 = resolve_equivalent_variable(["a", "b", "c"], "c", "VAR", tmpdir)
        check("J3 Missing intermediate blueprint skipped, still traces to end",
              r3 == "VAR_END", f"result={r3!r}")

    # J4: Variable with both access_identity AND symbolic_identity — L1 fires first
    bp_l1 = _make_bp(
        nodes=[_mem_node("AI_VAR")],
        edges=[_edge("memory:AI_VAR", "use:a", access_identity="CE1CR5:100")],
    )
    bp_target = _make_bp(
        nodes=[_mem_node("AI_RENAMED"), _mem_node("SYM_RENAMED")],
        edges=[
            _edge("memory:AI_RENAMED", "use:b", access_identity="CE1CR5:100"),
            _edge("memory:SYM_RENAMED", "use:c", symbolic_identity="LG1G1:AI_VAR"),
        ],
    )
    match, strat = find_match_in_file(
        None, bp_target, "memory:AI_VAR",
        None, None, "CE1CR5:100",
        target_symbolic_id="LG1G1:AI_VAR",
    )
    check("J4 L1 fires first even when both L1 and L2 are available",
          match == "memory:AI_RENAMED" and strat and "Access Identity" in strat,
          f"match={match!r}, strat={strat!r}")

    # J5: Two variables with same name in different DSECTs — distinguished by symbolic_identity
    bp_s = _make_bp(
        nodes=[_mem_node("COMMON_FIELD"), _mem_node("COMMON_FIELD_2")],
        edges=[
            _edge("memory:COMMON_FIELD", "use:a", symbolic_identity="DSECT_A:FIELD_X"),
            _edge("memory:COMMON_FIELD_2", "use:b", symbolic_identity="DSECT_B:FIELD_X"),
        ],
    )
    match5, strat5 = find_match_in_file(
        None, bp_s, "memory:ORIG",
        None, None, None,
        target_symbolic_id="DSECT_A:FIELD_X",
    )
    check("J5 Two variables with same field name in different DSECTs: correct one selected",
          match5 == "memory:COMMON_FIELD",
          f"match={match5!r}")

    # J6: Numeric-only memory node not given file_label (correctly excluded)
    result = _extract_plain_label("memory:0")
    check("J6 memory:0 (numeric constant) correctly excluded from file_label",
          result is None, f"result={result!r}")

    # J7: Ambiguous L2b (label in multiple DSECTs) — no symbolic_identity assigned
    # Simulated by testing the edge in _enrich_blueprint: when matches > 1, skip
    # We verify this indirectly: if field_to_dsect has 2+ entries, no symbolic_identity set
    from passes.cross_file_access_identity import _extract_plain_label as epl
    label = epl("memory:AMBIGUOUS_FIELD")
    check("J7 Ambiguous label extraction works (label found, ambiguity handled at map level)",
          label == "AMBIGUOUS_FIELD", f"label={label!r}")


# ---------------------------------------------------------------------------
# K. Real blueprint verification (Docker container)
# ---------------------------------------------------------------------------

def test_real_blueprints() -> None:
    print("\n" + "=" * 78)
    print("K. Real blueprint verification (actual pipeline output)")
    print("=" * 78)

    output_dir = Path("/var/asm-jobs/47018b86-3806-4ea1-a9e0-c548cbf48192/output")
    if not output_dir.exists():
        skip("K1 symbolic_identity set on DSECT edges", "Docker output dir not accessible")
        skip("K2 file_label set on local labels", "Docker output dir not accessible")
        skip("K3 Trace LG1OSI through real files", "Docker output dir not accessible")
        skip("K4 L2b: label upgrades are non-zero", "Docker output dir not accessible")
        skip("K5 Zero truly-unresolvable named variables", "Docker output dir not accessible")
        return

    if not IMPORT_OK:
        skip("K1-K5", IMPORT_ERR)
        return

    from blueprint_io import load_blueprint

    total_sym = 0
    total_fl = 0
    total_ai = 0
    total_edges = 0
    files_with_sym = 0

    for bp_path in sorted(output_dir.glob("*.asm.json")):
        bp = load_blueprint(bp_path)
        edges = bp.get("variable_lineage", {}).get("edges") or []
        total_edges += len(edges)
        ai  = sum(1 for e in edges if e.get("access_identity"))
        sym = sum(1 for e in edges if e.get("symbolic_identity"))
        fl  = sum(1 for e in edges if e.get("file_label"))
        total_ai += ai
        total_sym += sym
        total_fl += fl
        if sym > 0:
            files_with_sym += 1

    check("K1 symbolic_identity set on >=1500 edges (L2 + L2b combined)",
          total_sym >= 1500, f"total_sym={total_sym}")
    check("K2 file_label set on >=10000 edges (L4 local labels)",
          total_fl >= 10000, f"total_fl={total_fl}")
    check("K3 access_identity set on >=1000 edges (L1 after enrichment)",
          total_ai >= 1000, f"total_ai={total_ai}")
    check("K4 symbolic_identity present in all 15 asm blueprint files",
          files_with_sym == 15, f"files_with_sym={files_with_sym}")

    # K5: End-to-end trace of LG1OSI through real files using get_equivalent_variable
    from get_equivalent_variable import resolve_equivalent_variable as rev
    chain = ["da76", "xh71", "xh80"]
    result = rev(chain, "xh80", "LG1OSI", str(output_dir))
    check("K5 LG1OSI traces through real chain da76→xh71→xh80",
          result is not None, f"result={result!r}")

    # K6: WB1SUPP traces through multiple files
    wb_chain = ["xh71", "xh72", "xh80", "xh88"]
    wb_result = rev(wb_chain, "xh88", "WB1SUPP", str(output_dir))
    check("K6 WB1SUPP traces through 4-file real chain",
          wb_result is not None, f"result={wb_result!r}")

    # K7: Verify no named variable is completely unidentifiable in the real data
    # A named variable has symbolic label but no identity of any kind = problematic
    truly_unident = 0
    for bp_path in output_dir.glob("*.asm.json"):
        bp = load_blueprint(bp_path)
        edges = bp.get("variable_lineage", {}).get("edges") or []
        for e in edges:
            src, tgt = e.get("source", ""), e.get("target", "")
            # Is this a memory-access edge with a symbolic (non-numeric) label?
            for nid in (src, tgt):
                if not nid.startswith("memory:"): continue
                n = nid[7:].split("(")[0].split("+")[0].split("-")[0].strip()
                if not n or "@" in n: continue
                try:
                    int(n)
                    continue  # numeric — skip
                except ValueError:
                    pass
                # Named memory node — check if it has any identity
                if not any(e.get(k) for k in ("access_identity", "symbolic_identity",
                                               "file_label", "dsect")):
                    truly_unident += 1
                break

    check("K7 Zero named memory variables are completely unidentifiable",
          truly_unident == 0, f"unidentifiable={truly_unident}")


# ---------------------------------------------------------------------------
# L. All existing tests still pass (regression)
# ---------------------------------------------------------------------------

def test_regression_existing_tests() -> None:
    print("\n" + "=" * 78)
    print("L. Regression — existing test suite still passes")
    print("=" * 78)

    import subprocess, sys
    test_file = REPO_ROOT / "fixes/phase_equivalent_variable_resolution/test_equivalent_variable_resolution.py"
    result = subprocess.run(
        [sys.executable, str(test_file)],
        capture_output=True, text=True
    )
    passed = "25 PASS / 0 FAIL" in result.stdout
    check("L1 All 25 existing tests still pass",
          passed,
          "25 PASS / 0 FAIL" if passed else result.stdout[-200:])

    # Run other phase tests
    other_tests = [
        "fixes/phase6_ecb_mapping/test_ecb_mapping.py",
        "fixes/phase7_glob_globals/test_glob_globals.py",
    ]
    for test_path in other_tests:
        full = REPO_ROOT / test_path
        if not full.exists():
            continue
        r = subprocess.run([sys.executable, str(full)], capture_output=True, text=True)
        ok = r.returncode == 0
        name = full.name
        check(f"L2 {name} passes without regression",
              ok, f"rc={r.returncode}")


# ---------------------------------------------------------------------------
# Main runner
# ---------------------------------------------------------------------------

def main() -> None:
    print("=" * 78)
    print("5-Layer Variable Identity System — Comprehensive Test Suite")
    print("=" * 78)

    if not IMPORT_OK:
        print(f"\nFATAL: Cannot import required modules: {IMPORT_ERR}")
        print("Ensure you are running from the asm-modernizer root directory.")

    test_model_fields()
    test_helper_functions()
    test_collect_symbolic_identity_map()
    test_get_physical_identity()
    test_strategy_symbolic_identity()
    test_single_hop_rename()
    test_multi_hop_rename()
    test_identity_trail_continuity()
    test_rename_position()
    test_edge_cases()
    test_real_blueprints()
    test_regression_existing_tests()

    # Summary
    passed = sum(1 for s, _, _ in RESULTS if s == "PASS")
    failed = sum(1 for s, _, _ in RESULTS if s == "FAIL")
    skipped = sum(1 for s, _, _ in RESULTS if s == "SKIP")

    print("\n" + "=" * 78)
    print(f"  Results: {passed} PASS / {failed} FAIL / {skipped} SKIP   (total {len(RESULTS)})")
    print("=" * 78)

    if failed > 0:
        print("\nFAILED tests:")
        for s, label, detail in RESULTS:
            if s == "FAIL":
                print(f"  FAIL  {label}   — {detail}")

    sys.exit(0 if failed == 0 else 1)


if __name__ == "__main__":
    main()
