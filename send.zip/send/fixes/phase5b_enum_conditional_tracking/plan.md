# Phase 5b — Conditional Enum Tracking (Criteria Matching)

**Status:** NOT STARTED.
**Source plan:** `docs/plans/2026-04-23-cpp-variable-lineage-strategy 1.md` §2.4, §3.3, §6.5. Extends the gap analysis that Phase 5 only partially addressed.
**Depends on:** Phase 5 (commit `10eca53`).

---

## 1. What Phase 5 left on the table

Phase 5 resolves enum constants on the **RHS of assignments**:

```cpp
task = AddLimit;              // ← resolved: assign edge has resolved_value='A'
```

But the parser does NOT record enum identifiers that appear in **conditional comparisons**:

```cpp
if (typeOfMaintenance == AddLimit) { ... }   // ← NOT recorded anywhere
while (x != ChangeLimit) { ... }             // ← NOT recorded
task == PersonalCard ? foo() : bar();        // ← NOT recorded
switch (typeOfMaintenance) { case AddLimit: ... }  // ← case label not resolved
```

Demonstrated empirically — a file containing `if (task == Y)` where `Y` is an enum produces **zero lineage edges** mentioning `Y`.

The tech-lead pushback names this exactly:
> "When the code checks if a variable equals an enum value, that value is often moved into a register or an Assembly field. Because the parser doesn't have the mapping, it can't tell that the value sitting in the Assembly register is actually the AddLimit enum from the C++ side."

Phase 5b closes this gap.

---

## 2. Goal

For every **comparison-context** site in C++ code, emit a lineage record that:

1. Names the operands (LHS, RHS) as lineage nodes.
2. Carries `conditional_context` describing the comparison.
3. If an operand is an enum constant, stamps `metadata.resolved_value` and `metadata.enum_type` (reusing the Phase 5 enum index).

After Phase 5b, the earlier test case produces:

```json
{
  "source": "variable:f::Y",
  "target": "use:use@.../test.cpp:4",
  "relation": "use",
  "conditional_context": ["task == Y"],
  "metadata": {"resolved_value": "'y'", "enum_type": "E"}
}
```

An ASM tracer / LLM can now join `task == Y` with ASM `CLI ...,C'y'` by matching the literal value.

---

## 3. Scope

### In scope
Comparisons with one or two identifier operands:
- Binary comparisons: `==`, `!=`, `<`, `>`, `<=`, `>=`
- Inside: `if (…)`, `while (…)`, `for (…; cond; …)`, ternary `… ? … : …`, `do-while`.
- `switch` case labels (`case AddLimit:` — the case value is effectively compared against the switch expression).

### Out of scope
- Logical combinators (`&&`, `||`, `!`) — handled by recursing into operands.
- Bit-level tests (`& 0x80` in a condition) — plan §5.6 track.
- Complex operands with method calls / arithmetic — only bare identifier operands are resolved; others are captured but not enum-tagged.
- `assert`, `static_assert` macros.

---

## 4. Data model

Add a single new list on `CTranslationUnit`:

```python
@dataclass
class CCondition:
    function: Optional[str]
    scope: Optional[str]
    line: int
    expression: str              # e.g. "task == AddLimit"
    operator: str                # "==" / "!=" / "<" / ">" / "<=" / ">=" / "case"
    operands: List[str]          # bare identifiers found on either side
```

And:

```python
conditions: List[CCondition] = field(default_factory=list)
```

No schema break for existing consumers — default empty.

---

## 5. Implementation plan

### 5.1 Parser (`passes/c_family_parser.py`)

Two paths, same data model:

**Tree-sitter path (primary).** Walk AST nodes whose `type` is one of:
- `binary_expression` — check operator child is one of `==`, `!=`, `<`, `>`, `<=`, `>=`.
- `case_statement` — treat case-label value as an equality against the switch expression.

For each match, extract identifier tokens from `left` and `right` children (recursively, skipping function-call nodes). Emit a `CCondition`.

**Regex fallback.** For environments without tree-sitter, a forgiving regex covers the common simple form:
```
(if|while|for|case)\s*\(?.*?([A-Za-z_]\w*)\s*(==|!=|<=|>=|<|>)\s*([A-Za-z_]\w*)
```
Captures the same data with lower recall on complex expressions. Good enough for the single-identifier-vs-identifier case that matters here.

Store on `unit.conditions`.

### 5.2 Lineage builder (`passes/variable_lineage_builder.py`)

In `process_c_family()`, after existing assignment processing, add:

```python
for cond in unit.conditions:
    scope = cond.scope or cond.function or "(global)"
    stmt_id = f"C_{scope}_{cond.line}_cond"
    for operand in cond.operands:
        qoperand = qualify(operand, cond.scope, cond.function, None)
        graph.add_usage(
            qoperand, source_kind(operand, alias_map),
            file, cond.line, cond.expression, scope,
            stmt_id, None,
            conditional_context=[cond.expression],
        )
        # If the operand is an enum constant, enrich the edge we just emitted.
        enum_rec = enum_values.get(operand) if enum_values else None
        if enum_rec:
            graph.edges[-1].metadata["resolved_value"] = enum_rec["value"]
            graph.edges[-1].metadata["enum_type"] = enum_rec["enum_type"]
```

`graph.add_usage` already accepts `conditional_context` per the existing signature. This is purely additive.

### 5.3 JSON emitter

No new section needed — the data flows out through the existing
`variable_lineage.edges` section with populated `conditional_context` and
`metadata` fields.

### 5.4 Files touched

| File | Change |
|---|---|
| `models/c_family.py` | New `CCondition` dataclass; `CTranslationUnit.conditions` list. |
| `passes/c_family_parser.py` | `_extract_conditions()` (tree-sitter + regex fallback); call from `parse()`. |
| `passes/variable_lineage_builder.py` | Emit use edges for each condition's operands with conditional_context + enum metadata. |

No changes to the stitcher, tracer, analyzer, or emitter.

---

## 6. Verification (exit criteria)

Test: `fixes/phase5b_enum_conditional_tracking/test_conditional_enum_tracking.py`.

### 6.1 Synthetic — `if` with enum on RHS
```cpp
enum E { X = 'x', Y = 'y' };
int f(int task) {
  if (task == Y) return 1;
  return 0;
}
```
Assert there is a use-edge whose source is `variable:f::Y`, with
`conditional_context` containing `"task == Y"`, and
`metadata.resolved_value == "'y'"`, `metadata.enum_type == "E"`.

### 6.2 Synthetic — enum on LHS
```cpp
if (Y == task) { ... }
```
Same asserts but LHS form — both operands should emit use-edges.

### 6.3 Multiple operators
```cpp
if (x != Y) ...
while (x < Y) ...
for (; x <= Y; ++x) ...
```
Each produces a use-edge with the correct `conditional_context` and enum
resolution.

### 6.4 Switch case
```cpp
switch (task) {
  case AddLimit: ...
  case DeleteLimit: ...
}
```
Each `case` label emits a use-edge on the enum identifier with
`conditional_context` set to something like `"case AddLimit"`.

### 6.5 Negative — non-enum operand
```cpp
if (x == 42) ...
```
Use-edge emitted (so downstream tools see the condition), but no enum
metadata stamped.

### 6.6 Regression
- Phases 1-5 tests still PASS.
- A `.cpp` file without any comparisons produces empty `conditions` list.

---

## 7. Resume next session

1. Read this plan.
2. Baseline run — expect all Phase 5b checks FAIL (no CCondition yet).
3. Patch parser → model → lineage builder in that order.
4. Run the test — expect PASS.
5. Commit; update `fixes/README.md`.
