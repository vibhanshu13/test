#!/usr/bin/env python3
"""Phase 5b verification — conditional enum tracking.

Usage:
    python3 fixes/phase5b_enum_conditional_tracking/test_conditional_enum_tracking.py
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO_ROOT))

from multi_file.c_family_analyzer import CFamilyAnalyzer  # noqa: E402


RESULTS: list[tuple[str, str, str]] = []


def check(label: str, cond: bool, detail: str = "") -> None:
    status = "PASS" if cond else "FAIL"
    RESULTS.append((status, label, detail))
    tail = f"   — {detail}" if detail else ""
    print(f"  {status}   {label}{tail}")


def build_graph(source: str) -> dict:
    """Parse `source` via CFamilyAnalyzer and return the variable_lineage dict."""
    with tempfile.TemporaryDirectory() as td:
        cpp = Path(td) / "t.cpp"
        cpp.write_text(source)
        a = CFamilyAnalyzer(language="cpp", search_paths=[Path(td)])
        res = a.analyze(cpp, source)
        ctx = res.analysis_context
        graph = ctx.get_metadata("variable_lineage")
        if graph is None:
            return {"edges": [], "nodes": []}
        return graph.to_dict() if hasattr(graph, "to_dict") else graph


def find_conditional_use(
    edges: list[dict],
    operand: str,
    expect_context_substr: str,
    expect_enum_type: str | None = None,
    expect_value: str | None = None,
) -> dict | None:
    """Return the first `use` edge referencing `operand` whose
    `conditional_context` mentions the given substring (and optionally
    carrying enum metadata)."""
    for e in edges:
        if e.get("relation") != "use":
            continue
        src = str(e.get("source") or "")
        if operand not in src:
            continue
        ctx_list = e.get("conditional_context") or []
        if not any(expect_context_substr in (c or "") for c in ctx_list):
            continue
        if expect_enum_type is not None:
            md = e.get("metadata") or {}
            if md.get("enum_type") != expect_enum_type:
                continue
            if expect_value is not None and md.get("resolved_value") != expect_value:
                continue
        return e
    return None


# ---------------------------------------------------------------------------
# 6.1 if with enum on RHS
# ---------------------------------------------------------------------------

def test_if_enum_rhs() -> None:
    print("\n" + "=" * 78)
    print("6.1  if (task == Y) — enum on RHS")
    print("=" * 78)
    src = """
enum E { X = 'x', Y = 'y' };
int f(int task) {
  if (task == Y) return 1;
  return 0;
}
"""
    d = build_graph(src)
    edges = d.get("edges", [])
    hit = find_conditional_use(edges, "Y", "task == Y",
                               expect_enum_type="E", expect_value="'y'")
    check("use edge on Y with conditional_context + enum metadata",
          hit is not None,
          detail="" if hit else "no matching edge found")
    # Also confirm `task` gets its own use edge in the same condition.
    t_hit = find_conditional_use(edges, "task", "task == Y")
    check("use edge on task in same conditional", t_hit is not None)


# ---------------------------------------------------------------------------
# 6.2 if with enum on LHS
# ---------------------------------------------------------------------------

def test_if_enum_lhs() -> None:
    print("\n" + "=" * 78)
    print("6.2  if (Y == task) — enum on LHS")
    print("=" * 78)
    src = """
enum E { X = 'x', Y = 'y' };
int f(int task) {
  if (Y == task) return 1;
  return 0;
}
"""
    d = build_graph(src)
    edges = d.get("edges", [])
    hit = find_conditional_use(edges, "Y", "Y == task",
                               expect_enum_type="E", expect_value="'y'")
    check("use edge on Y with conditional_context + enum metadata (LHS form)",
          hit is not None)


# ---------------------------------------------------------------------------
# 6.3 multiple operators
# ---------------------------------------------------------------------------

def test_multiple_operators() -> None:
    print("\n" + "=" * 78)
    print("6.3  !=, <, <=, >=, > operators")
    print("=" * 78)
    src = """
enum E { X = 'x', Y = 'y' };
int f(int x) {
  if (x != Y) {}
  while (x < Y) {}
  for (; x <= Y; ++x) {}
  if (Y >= x) {}
  return 0;
}
"""
    d = build_graph(src)
    edges = d.get("edges", [])
    for op in ("!=", "<", "<=", ">="):
        hit = find_conditional_use(edges, "Y", op,
                                   expect_enum_type="E", expect_value="'y'")
        check(f"use edge on Y for operator {op!r}", hit is not None)


# ---------------------------------------------------------------------------
# 6.4 switch case labels
# ---------------------------------------------------------------------------

def test_switch_case() -> None:
    print("\n" + "=" * 78)
    print("6.4  switch case AddLimit / DeleteLimit")
    print("=" * 78)
    src = """
enum M { AddLimit = 'A', DeleteLimit = 'D' };
int f(int task) {
  switch (task) {
    case AddLimit:    return 1;
    case DeleteLimit: return 2;
  }
  return 0;
}
"""
    d = build_graph(src)
    edges = d.get("edges", [])
    a_hit = find_conditional_use(edges, "AddLimit", "AddLimit",
                                 expect_enum_type="M", expect_value="'A'")
    d_hit = find_conditional_use(edges, "DeleteLimit", "DeleteLimit",
                                 expect_enum_type="M", expect_value="'D'")
    check("case AddLimit    produces use+enum metadata", a_hit is not None)
    check("case DeleteLimit produces use+enum metadata", d_hit is not None)


# ---------------------------------------------------------------------------
# 6.5 non-enum operand — use edge emitted, no enum metadata
# ---------------------------------------------------------------------------

def test_non_enum_operand() -> None:
    print("\n" + "=" * 78)
    print("6.5  non-enum operand (if (x == 42))")
    print("=" * 78)
    src = """
int f(int x) { if (x == 42) return 1; return 0; }
"""
    d = build_graph(src)
    edges = d.get("edges", [])
    x_hit = find_conditional_use(edges, "::x", "x == 42")
    check("use edge on x with conditional_context set", x_hit is not None)
    if x_hit is not None:
        md = x_hit.get("metadata") or {}
        check("no enum metadata on non-enum operand",
              "enum_type" not in md, detail=f"md={md}")


# ---------------------------------------------------------------------------
# 6.6 regression — no comparisons → no new edges
# ---------------------------------------------------------------------------

def test_no_comparisons() -> None:
    print("\n" + "=" * 78)
    print("6.6  file with no comparisons — conditions list stays empty")
    print("=" * 78)
    src = "int f() { return 0; }\n"
    with tempfile.TemporaryDirectory() as td:
        cpp = Path(td) / "t.cpp"
        cpp.write_text(src)
        a = CFamilyAnalyzer(language="cpp", search_paths=[Path(td)])
        res = a.analyze(cpp, src)
        unit = res.analysis_context.get_metadata("c_family_unit")
        conds = getattr(unit, "conditions", None)
        check("unit.conditions exists", conds is not None)
        check("unit.conditions empty for no-cond file",
              (conds or []) == [], detail=f"got {conds}")


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def main() -> int:
    tests = [
        test_if_enum_rhs,
        test_if_enum_lhs,
        test_multiple_operators,
        test_switch_case,
        test_non_enum_operand,
        test_no_comparisons,
    ]
    for t in tests:
        try:
            t()
        except Exception as exc:
            RESULTS.append(("FAIL", t.__name__, f"raised {type(exc).__name__}: {exc}"))
            print(f"  FAIL   {t.__name__} raised {exc!r}")

    fails = [r for r in RESULTS if r[0] == "FAIL"]
    print("\n" + "=" * 78)
    if fails:
        print(f">>> PHASE 5b: {len(fails)}/{len(RESULTS)} FAILED.")
        for _, lbl, detail in fails:
            print(f"    - {lbl}  {detail}")
        return 1
    print(f">>> PHASE 5b: ALL {len(RESULTS)} CHECKS PASSED.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
