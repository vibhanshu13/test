#!/usr/bin/env python3
"""Phase 3 verification — attach asm_alias metadata to C++ struct-field nodes.

Usage:
    python3 fixes/phase3_asm_alias_nodes/test_asm_alias_nodes.py

BEFORE the patch: every asm_alias assertion prints MISSING / WRONG.
AFTER the patch: every row prints PASS.
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))

from models.analysis_context import AnalysisContext  # noqa: E402
from models.c_family import (  # noqa: E402
    CAssignment,
    CDeclaration,
    CTranslationUnit,
)
from multi_file.c_family_analyzer import CFamilyAnalyzer  # noqa: E402
from passes.variable_lineage_builder import VariableLineageBuilder  # noqa: E402


def _build_unit_and_graph(data_type: str, field_asm_aliases):
    unit = CTranslationUnit(file_path=Path("/tmp/x.cpp"), language="cpp")
    unit.field_asm_aliases = dict(field_asm_aliases)
    unit.declarations.append(CDeclaration(
        name="da7gl",
        kind="variable",
        line=5,
        function="globalLimitsUpdate",
        scope="local",
        data_type=data_type,
    ))
    unit.assignments.append(CAssignment(
        target="da7gl->cmSystem",
        target_kind="struct_field",
        sources=["'T'"],
        line=10,
        expression="da7gl->cmSystem = 'T';",
        function="globalLimitsUpdate",
        scope="local",
        target_base="da7gl",
        target_field="cmSystem",
    ))
    unit.assignments.append(CAssignment(
        target="da7gl->unmappedField",
        target_kind="struct_field",
        sources=["'X'"],
        line=11,
        expression="da7gl->unmappedField = 'X';",
        function="globalLimitsUpdate",
        scope="local",
        target_base="da7gl",
        target_field="unmappedField",
    ))

    context = AnalysisContext(file_path=unit.file_path)
    VariableLineageBuilder().process_c_family(unit, context)
    return context.get_metadata("variable_lineage")


def _find_node(graph, name_substr: str, kind: str):
    for node in graph.nodes.values():
        if node.kind == kind and name_substr in node.name:
            return node
    return None


# --- Synthetic process_c_family tests ---------------------------------------


def run_synthetic_process_c_family() -> int:
    print("=" * 78)
    print("Synthetic process_c_family tests (pure builder)")
    print("=" * 78)
    failed = 0

    # Positive: Da7gl* + mapped field
    g = _build_unit_and_graph("Da7gl*", {"Da7gl.cmSystem": "WK_CMO"})
    node = _find_node(g, "da7gl->cmSystem", "struct_field")
    if node and (node.metadata or {}).get("asm_alias") == "WK_CMO" \
            and (node.metadata or {}).get("enclosing_type") == "Da7gl":
        print("  PASS   Da7gl* + mapped field  -> asm_alias=WK_CMO, enclosing_type=Da7gl")
    else:
        print(f"  MISSING Da7gl* + mapped field  (node={node!r})")
        failed += 1

    # Negative: unmapped field has no asm_alias
    node = _find_node(g, "da7gl->unmappedField", "struct_field")
    if node and "asm_alias" not in (node.metadata or {}):
        print("  PASS   unmapped field correctly has no asm_alias")
    else:
        meta = getattr(node, "metadata", None)
        print(f"  WRONG  unmapped field should not have asm_alias (metadata={meta!r})")
        failed += 1

    # Negative: empty field_asm_aliases
    g = _build_unit_and_graph("Da7gl*", {})
    leaked = [n for n in g.nodes.values()
              if n.kind == "struct_field" and "asm_alias" in (n.metadata or {})]
    if not leaked:
        print("  PASS   empty field_asm_aliases -> no asm_alias annotations")
    else:
        print(f"  WRONG  empty aliases still produced asm_alias on {len(leaked)} node(s)")
        failed += 1

    # data_type variants all resolve the same
    for variant in ("Da7gl *", "const Da7gl*", "Da7gl&", "const Da7gl &"):
        g = _build_unit_and_graph(variant, {"Da7gl.cmSystem": "WK_CMO"})
        node = _find_node(g, "da7gl->cmSystem", "struct_field")
        if node and (node.metadata or {}).get("asm_alias") == "WK_CMO":
            print(f"  PASS   data_type {variant!r} resolves to Da7gl")
        else:
            print(f"  MISSING data_type {variant!r} should resolve to Da7gl "
                  f"(got metadata={getattr(node, 'metadata', None)!r})")
            failed += 1

    return failed


# --- Analyzer include-walk tests --------------------------------------------


def run_analyzer_include_walk() -> int:
    print()
    print("=" * 78)
    print("Analyzer include-walk tests (tmp dir)")
    print("=" * 78)
    failed = 0

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)

        (tmp_path / "ccfoo.hpp").write_text(
            "#pragma once\n"
            "struct Foo {\n"
            "    char x;    // WK_X\n"
            "    char y;    // WK_Y\n"
            "};\n"
        )
        (tmp_path / "ccbar.hpp").write_text(
            "struct Bar {\n"
            "    int z;    // LG1Z\n"
            "};\n"
        )
        (tmp_path / "pipeline.hpp").write_text(  # non-cc — must not leak
            "struct Leak {\n"
            "    char q;   // SHOULD_NOT_LEAK\n"
            "};\n"
        )
        (tmp_path / "main.cpp").write_text(
            '#include "ccfoo.hpp"\n'
            '#include <ccbar.hpp>\n'
            '#include "pipeline.hpp"\n'
            "void f() {\n"
            "    Foo* p;\n"
            "    p->x = 'A';\n"
            "    Bar* q;\n"
            "    q->z = 1;\n"
            "}\n"
        )

        analyzer = CFamilyAnalyzer("cpp", search_paths=[tmp_path])
        result = analyzer.analyze(tmp_path / "main.cpp",
                                  (tmp_path / "main.cpp").read_text())
        unit = result.analysis_context.get_metadata("c_family_unit")
        fa = dict(getattr(unit, "field_asm_aliases", {}) or {})

        if fa.get("Foo.x") == "WK_X":
            print("  PASS   quoted-include walk: Foo.x -> WK_X")
        else:
            print(f"  MISSING quoted-include walk: Foo.x (got {fa.get('Foo.x')!r})")
            failed += 1

        if fa.get("Bar.z") == "LG1Z":
            print("  PASS   angle-include walk: Bar.z -> LG1Z")
        else:
            print(f"  MISSING angle-include walk: Bar.z (got {fa.get('Bar.z')!r})")
            failed += 1

        if "Leak.q" not in fa:
            print("  PASS   non-cc header pipeline.hpp correctly NOT walked")
        else:
            print(f"  WRONG  pipeline.hpp leaked Leak.q -> {fa.get('Leak.q')!r}")
            failed += 1

    return failed


# --- Real-file smoke test ---------------------------------------------------


def run_real_file_smoke() -> int:
    print()
    print("=" * 78)
    print("Real-file smoke test: dx740200.cpp + ccda7gl.hpp")
    print("=" * 78)

    cpp = (REPO_ROOT.parent / "asm" / "dx740200.cpp").resolve()
    if not cpp.exists():
        print(f"  SKIP   {cpp} not found")
        return 0

    search_paths = [cpp.parent]
    analyzer = CFamilyAnalyzer("cpp", search_paths=search_paths)
    result = analyzer.analyze(cpp, cpp.read_text(errors="replace"))
    unit = result.analysis_context.get_metadata("c_family_unit")
    fa = dict(getattr(unit, "field_asm_aliases", {}) or {})

    failed = 0
    if fa.get("Da7gl.cmSystem") == "WK_CMO":
        print(f"  PASS   include walk captured Da7gl.cmSystem -> WK_CMO "
              f"(total {len(fa)} mappings)")
    else:
        print(f"  MISSING Da7gl.cmSystem -> WK_CMO "
              f"(got {fa.get('Da7gl.cmSystem')!r}; total {len(fa)} mappings)")
        failed += 1

    graph = result.analysis_context.get_metadata("variable_lineage")
    if graph is None:
        print("  MISSING variable_lineage graph not built")
        return failed + 1

    annotated = [n for n in graph.nodes.values()
                 if n.kind == "struct_field" and (n.metadata or {}).get("asm_alias") == "WK_CMO"]
    if annotated:
        print(f"  PASS   struct_field node(s) annotated with asm_alias=WK_CMO "
              f"({len(annotated)} node(s))")
        for n in annotated[:3]:
            print(f"         {n.name}")
    else:
        print("  MISSING no struct_field node annotated with asm_alias=WK_CMO")
        failed += 1

    return failed


# --- Main --------------------------------------------------------------------


if __name__ == "__main__":
    f1 = run_synthetic_process_c_family()
    f2 = run_analyzer_include_walk()
    f3 = run_real_file_smoke()
    total = f1 + f2 + f3

    print()
    if total == 0:
        print(">>> PHASE 3: ALL CHECKS PASSED.")
        sys.exit(0)
    else:
        print(f">>> PHASE 3: {total} checks failed. Patch not yet applied (or incomplete).")
        sys.exit(1)
