# Phase 3 — Attach asm_alias Metadata to Struct-Field Lineage Nodes

**Status:** NOT STARTED (awaiting approval to patch).
**Source plan:** `docs/plans/2026-04-23-cpp-variable-lineage-strategy 1.md` §6.3, §8.1.
**Depends on:** Phase 2 (commit `9a951c5`).

---

## Goal in one paragraph

Phase 2 extracts `{"StructName.fieldName": "ASM_NAME"}` mappings from `cc*.hpp`
headers into `CTranslationUnit.field_asm_aliases`. Phase 3 wires those mappings
through to the variable-lineage graph: when a `.cpp` writes to a struct field
(`da7gl->cmSystem = ...`), the resulting `struct_field` node gains
`metadata["asm_alias"] = "WK_CMO"`. No new edges are created; no existing edges
change. This is pure, opt-in metadata enrichment. Phase 4 will use this
annotation to create cross-language alias edges.

---

## Phase 3 is two parts

### 3a. Include-chain walk (cpp unit inherits cc*.hpp aliases)

A `.cpp` file does not itself contain `// ASM_NAME` comments — those live in
the `cc*.hpp` headers it includes. Phase 2 populates `field_asm_aliases` only
for files it parses directly, so `dx740200.cpp`'s unit currently sees `{}`.

Add `_collect_include_field_asm_aliases(self, file_path, file_content) -> dict`
to `multi_file/c_family_analyzer.py`, mirroring `_collect_include_symbol_aliases`:

1. BFS over `#include` directives — BOTH `"quoted"` AND `<angle>`.
2. For each resolved include, call
   `self.parser._extract_field_asm_aliases(include_text, include_path)` — which
   itself gates on the `cc*` filename prefix, so non-cc headers yield `{}`
   without any extra work.
3. Cycle-safe (`visited: Set[Path]`).
4. Reuse the existing `_resolve_local_include()` — works the same for
   `"foo.hpp"` and `<foo.hpp>` (header search is local-dir + configured search
   paths + sibling dirs).

Call from `analyze()` right after the existing
`_collect_include_symbol_aliases` block:

```python
include_field_aliases = self._collect_include_field_asm_aliases(file_path, file_content)
for key, asm_name in include_field_aliases.items():
    unit.field_asm_aliases.setdefault(key, asm_name)
```

Gate is preserved end-to-end: non-cc includes silently yield `{}` (Phase 2's
gate inside `_extract_field_asm_aliases`), so a `#include <stdlib.h>` never
leaks spurious mappings.

### 3b. Attach `asm_alias` to struct_field nodes in `process_c_family`

In `passes/variable_lineage_builder.py::process_c_family`:

1. Early in the method (before the assignment loop), build a local
   `type_by_qualified_var: Dict[str, str]` from `unit.declarations`:
   - For each `CDeclaration` with `kind in ("variable", "parameter", "member")`
     and a non-empty `data_type`, store:
     `qualify(decl.name, decl.scope, decl.function, decl.storage_class)` →
     `_strip_cv_ptr(decl.data_type)`.
   - Helper `_strip_cv_ptr(t)` removes leading `const `, `volatile `, trailing
     `*`, `&`, and whitespace. E.g. `Da7gl*` → `Da7gl`, `const CasGLRec &` →
     `CasGLRec`.
2. `field_asm_aliases = getattr(unit, "field_asm_aliases", {}) or {}`.
3. Inside the `for assignment in unit.assignments` loop, after the existing
   struct-field hierarchy block, add:

   ```python
   if (target_kind == "struct_field"
       and assignment.target_base
       and assignment.target_field
       and field_asm_aliases):
       base_q = qualify(assignment.target_base, assignment.scope,
                        assignment.function, assignment.storage_class)
       type_name = type_by_qualified_var.get(base_q)
       if type_name:
           asm = field_asm_aliases.get(f"{type_name}.{assignment.target_field}")
           if asm:
               graph.annotate_node(target, "struct_field",
                                   asm_alias=asm,
                                   enclosing_type=type_name)
               if assignment.target and assignment.target != target:
                   graph.annotate_node(assignment.target, "struct_field",
                                       asm_alias=asm,
                                       enclosing_type=type_name)
   ```

4. No new edges. No change to existing edges.

---

## Files touched

| File | Change |
|---|---|
| `multi_file/c_family_analyzer.py` | Add `_collect_include_field_asm_aliases` + angle-bracket include regex + call-site merge into `unit.field_asm_aliases`. |
| `passes/variable_lineage_builder.py` | Build type map; annotate struct_field nodes with `asm_alias` + `enclosing_type` when mapping exists. |

No changes to `models/`, `json_emitter.py`, or any downstream consumer — the
node's `metadata` dict is already serialized.

---

## Exit criteria

Located at `fixes/phase3_asm_alias_nodes/test_asm_alias_nodes.py`.

### 1. Synthetic `process_c_family` direct test (no parser, no analyzer)

Construct a `CTranslationUnit` by hand and feed it to
`VariableLineageBuilder.process_c_family`. Assert graph node metadata.

Checks:
- `Da7gl* da7gl` declared + `da7gl->cmSystem = 'T'` + `field_asm_aliases={"Da7gl.cmSystem":"WK_CMO"}`
  → node `globalLimitsUpdate::da7gl->cmSystem` (struct_field) has
  `metadata["asm_alias"] == "WK_CMO"`, `metadata["enclosing_type"] == "Da7gl"`.
- Second assignment to a field NOT in the map → no `asm_alias` on that node.
- `field_asm_aliases={}` → no node gets `asm_alias` (Phase 2 off).
- `data_type` variants `"Da7gl *"`, `"const Da7gl*"`, `"Da7gl&"` all resolve
  the same.

### 2. Analyzer include-walk test (synthetic files in tmp dir)

Write to a `tempfile.TemporaryDirectory()`:
- `ccfoo.hpp` — `struct Foo { char x; // WK_X };`
- `main.cpp` — `#include "ccfoo.hpp"` + declaration + assignment.

Run `CFamilyAnalyzer("cpp").analyze(...)`. Assert `unit.field_asm_aliases`
contains `Foo.x -> WK_X`.

Gate check: a second include `#include "pipeline.hpp"` (non-cc header with
matching syntax) must NOT leak.

Angle-bracket check: `#include <ccbar.hpp>` where `ccbar.hpp` is a sibling —
must be walked.

### 3. Real-file smoke test

Run the analyzer on `../asm/dx740200.cpp`. Expectation:
- `unit.field_asm_aliases` includes `Da7gl.cmSystem -> WK_CMO` (from the
  `<ccda7gl.hpp>` walk).
- At least one `struct_field` node in the graph has `asm_alias == "WK_CMO"`.

If the file isn't present, the test prints SKIP and doesn't fail.

### 4. Regression

Phase 1 and Phase 2 tests still pass.

---

## What Phase 3 deliberately does NOT do (deferred to Phase 4)

- Cross-language alias edges between C++ struct_field nodes and ASM DSECT
  variable nodes.
- TPF_regs register bridge end-to-end stitching.
- `ecbptr()->ce1crN` → `CE1CRN` mapping.
- Enum value resolution.
- `glob(_name)` → named global.

---

## Resume next session

1. Read this plan.
2. Baseline: `python3 fixes/phase3_asm_alias_nodes/test_asm_alias_nodes.py`
   — expect failing checks on every asm_alias assertion.
3. Apply 3a (`c_family_analyzer.py`) then 3b (`variable_lineage_builder.py`).
4. Re-run test — expect PASS.
5. Commit (same style as Phase 1/2, no co-author trailer — user preference).
6. Move to Phase 4.
