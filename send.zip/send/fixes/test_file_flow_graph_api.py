#!/usr/bin/env python3
"""Validation tests for GET .../messages/{msg_id}/file-flow-graph.

Checks:
  1. Auth / routing (401, 403, 404s)
  2. Empty graph when no selected_chain or no graph file
  3. Node shape — id, label, type present; label == filename
  4. Edge shape — source, target, label present; label derived from instructions
  5. root field — entry-point node id, matches a node.id
  6. Instruction → label mapping (ENTRC→FUNCTION, BALR→FUNCTION, BAL→FUNCTION, CALL→CALL)
  7. Determinism — same msg_id returns identical graph on two calls
"""
from __future__ import annotations

import json
import shutil
import sys
import uuid
from pathlib import Path
from typing import Any, Dict, List

import msgpack
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from api.app import app  # noqa: E402
from api.auth import create_access_token, hash_password  # noqa: E402
from api.db import SessionLocal, create_tables  # noqa: E402
from api.models.knowledge_base import KnowledgeBase, KnowledgeBaseAccess  # noqa: E402
from api.models.user import User  # noqa: E402
from api.storage.workspace import WorkspaceManager  # noqa: E402

# ---------------------------------------------------------------------------
# Test accounting
# ---------------------------------------------------------------------------

PASS = 0
FAIL = 0
_CREATED_KBS: List[str] = []
_CREATED_USERS: List[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS  {name}" + (f"  [{detail}]" if detail else ""))
    else:
        FAIL += 1
        print(f"  FAIL  {name}" + (f"  [{detail}]" if detail else ""))


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _create_user(db, username: str, role: str = "user") -> User:
    user = User(
        username=username,
        hashed_password=hash_password("TestPass123!"),
        role=role,
        is_active=True,
    )
    db.add(user)
    _CREATED_USERS.append(username)
    return user


def _create_kb(db, kb_id: str, *, created_by: str) -> KnowledgeBase:
    kb = KnowledgeBase(
        id=kb_id,
        name=f"FFG Test {kb_id[:8]}",
        created_by=created_by,
        datasource_username=None,
        datasource_folder=None,
        source_path="/tmp/src",
        status="success",
        error=None,
    )
    db.add(kb)
    _CREATED_KBS.append(kb_id)
    return kb


def _auth_headers(username: str, role: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {create_access_token(username, role)}"}


def _prepare_kb(db, admin_username: str, graph: Dict[str, Any]) -> str:
    kb_id = str(uuid.uuid4())
    _create_kb(db, kb_id, created_by=admin_username)
    db.commit()
    ws = WorkspaceManager(kb_id)
    for d in (ws.root, ws.input_dir, ws.output_dir, ws.cache_dir):
        d.mkdir(parents=True, exist_ok=True)
    (ws.output_dir / "file_call_graph.json").write_text(
        json.dumps(graph), encoding="utf-8"
    )
    return kb_id


def _write_conversation(
    kb_id: str,
    conv_id: str,
    selected_chain: List[str],
    messages: List[Dict[str, Any]],
) -> None:
    conv_dir = WorkspaceManager(kb_id).output_dir / "conversations"
    conv_dir.mkdir(parents=True, exist_ok=True)
    conv: Dict[str, Any] = {
        "version": 1,
        "conv_id": conv_id,
        "process": "lu82",
        "keyword": "WK_VAR",
        "backward_session_id": None,
        "root_variable": "WK_VAR",
        "selected_chain": selected_chain,
        "keyword_file_flows": [],
        "messages": messages,
        "chat_session_id": None,
        "created_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-01T00:00:00+00:00",
    }
    (conv_dir / f"{conv_id}.msgpack").write_bytes(msgpack.packb(conv, use_bin_type=True))


def _make_msg(msg_id: str, tuple_index: int = 0) -> Dict[str, Any]:
    return {
        "msg_id": msg_id,
        "tuple_index": tuple_index,
        "file_stem": "lu82",
        "file_type": "asm",
        "phase": "modifier",
        "phase_label": "Modifier",
        "explanation": "synthetic",
        "is_complete": False,
        "created_at": "2026-01-01T00:00:00+00:00",
    }


# ---------------------------------------------------------------------------
# Shared graph fixture
# ---------------------------------------------------------------------------

def _standard_graph() -> Dict[str, Any]:
    """lu82 → mn04 (ENTRC) → ux12 (BALR) → auth_service (CALL)"""
    return {
        "nodes": [
            {"id": "lu82",         "type": "asm", "file": "lu82.asm"},
            {"id": "mn04",         "type": "asm", "file": "mn04.asm"},
            {"id": "ux12",         "type": "asm", "file": "ux12.asm"},
            {"id": "auth_service", "type": "cpp", "file": "auth_service.cpp"},
        ],
        "edges": [
            {"source": "lu82", "target": "mn04",         "instructions": ["ENTRC"]},
            {"source": "mn04", "target": "ux12",         "instructions": ["BALR"]},
            {"source": "ux12", "target": "auth_service", "instructions": ["CALL"]},
        ],
    }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_auth_and_routing(
    client: TestClient,
    admin_headers: Dict[str, str],
    user_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("1. auth + routing")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username, _standard_graph())
        conv_id = str(uuid.uuid4())
        msg_id  = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id, ["lu82"], [_make_msg(msg_id)])

        url = f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/file-flow-graph"

        resp = client.get(url)
        check("unauthenticated → 401", resp.status_code == 401, str(resp.status_code))

        resp = client.get(url, headers=user_headers)
        check("no-access user → 403", resp.status_code == 403, str(resp.status_code))

        resp = client.get(
            f"/v1/knowledge-bases/{uuid.uuid4()}/conversations/{conv_id}/messages/{msg_id}/file-flow-graph",
            headers=admin_headers,
        )
        check("unknown KB → 404", resp.status_code == 404, str(resp.status_code))

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{uuid.uuid4()}/messages/{msg_id}/file-flow-graph",
            headers=admin_headers,
        )
        check("unknown conv → 404", resp.status_code == 404, str(resp.status_code))

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{uuid.uuid4()}/file-flow-graph",
            headers=admin_headers,
        )
        check("unknown msg → 404", resp.status_code == 404, str(resp.status_code))

        resp = client.get(url, headers=admin_headers)
        check("valid request → 200", resp.status_code == 200, str(resp.status_code))
    finally:
        db.close()


def test_empty_graph_cases(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("2. empty graph cases")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username, _standard_graph())

        # No selected_chain on conversation
        conv_id = str(uuid.uuid4())
        msg_id  = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id, [], [_make_msg(msg_id)])

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/file-flow-graph",
            headers=admin_headers,
        )
        body = resp.json()
        check("no chain → 200", resp.status_code == 200, str(resp.status_code))
        check("no chain → nodes: []", body.get("nodes") == [], str(body))
        check("no chain → edges: []", body.get("edges") == [], str(body))

        # Graph file removed
        conv_id2 = str(uuid.uuid4())
        msg_id2  = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id2, ["lu82"], [_make_msg(msg_id2)])
        (WorkspaceManager(kb_id).output_dir / "file_call_graph.json").unlink()

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id2}/messages/{msg_id2}/file-flow-graph",
            headers=admin_headers,
        )
        body = resp.json()
        check("no graph file → 200", resp.status_code == 200, str(resp.status_code))
        check("no graph file → nodes: []", body.get("nodes") == [], str(body))
        check("no graph file → edges: []", body.get("edges") == [], str(body))
    finally:
        db.close()


def test_node_shape(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("3. node shape — id, label, type")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id   = _prepare_kb(db, admin_username, _standard_graph())
        conv_id = str(uuid.uuid4())
        msg_id  = str(uuid.uuid4())
        chain   = ["lu82", "mn04", "ux12", "auth_service"]
        _write_conversation(kb_id, conv_id, chain, [_make_msg(msg_id)])

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/file-flow-graph",
            headers=admin_headers,
        )
        body  = resp.json()
        nodes = body.get("nodes", [])
        check("4 nodes returned", len(nodes) == 4, str(len(nodes)))

        node_map = {n["id"]: n for n in nodes}

        for stem, expected_file, expected_type in [
            ("lu82",         "lu82.asm",         "asm"),
            ("mn04",         "mn04.asm",         "asm"),
            ("ux12",         "ux12.asm",         "asm"),
            ("auth_service", "auth_service.cpp", "cpp"),
        ]:
            n = node_map.get(stem, {})
            check(f"{stem}: id present",    bool(n.get("id")),    str(n))
            check(f"{stem}: label == '{expected_file}'",
                  n.get("label") == expected_file,
                  f"got={n.get('label')!r}")
            check(f"{stem}: type == '{expected_type}'",
                  n.get("type") == expected_type,
                  f"got={n.get('type')!r}")

        # No x/y coordinates
        for n in nodes:
            check(f"node '{n['id']}' has no x field", "x" not in n, str(n))
            check(f"node '{n['id']}' has no y field", "y" not in n, str(n))
    finally:
        db.close()


def test_edge_shape_and_label_mapping(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("4. edge shape + instruction → label mapping")
    print("=" * 70)

    db = SessionLocal()
    try:
        # Build a graph that exercises every instruction variant
        graph = {
            "nodes": [
                {"id": "a", "type": "asm", "file": "a.asm"},
                {"id": "b", "type": "asm", "file": "b.asm"},
                {"id": "c", "type": "asm", "file": "c.asm"},
                {"id": "d", "type": "asm", "file": "d.asm"},
                {"id": "e", "type": "cpp", "file": "e.cpp"},
            ],
            "edges": [
                {"source": "a", "target": "b", "instructions": ["ENTRC"]},
                {"source": "b", "target": "c", "instructions": ["BALR"]},
                {"source": "c", "target": "d", "instructions": ["BAL"]},
                {"source": "d", "target": "e", "instructions": ["CALL"]},
            ],
        }
        kb_id   = _prepare_kb(db, admin_username, graph)
        conv_id = str(uuid.uuid4())
        msg_id  = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id, ["a", "b", "c", "d", "e"], [_make_msg(msg_id)])

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/file-flow-graph",
            headers=admin_headers,
        )
        edges = resp.json().get("edges", [])
        check("4 edges returned", len(edges) == 4, str(len(edges)))

        edge_map = {(e["source"], e["target"]): e for e in edges}

        ab = edge_map.get(("a", "b"), {})
        bc = edge_map.get(("b", "c"), {})
        cd = edge_map.get(("c", "d"), {})
        de = edge_map.get(("d", "e"), {})

        check("ENTRC → label 'FUNCTION'", ab.get("label") == "FUNCTION",
              f"got={ab.get('label')!r}")
        check("BALR → label 'FUNCTION'",  bc.get("label") == "FUNCTION",
              f"got={bc.get('label')!r}")
        check("BAL → label 'FUNCTION'",   cd.get("label") == "FUNCTION",
              f"got={cd.get('label')!r}")
        check("CALL → label 'CALL'",       de.get("label") == "CALL",
              f"got={de.get('label')!r}")

        # Every edge must have source, target, label
        for e in edges:
            check(f"edge ({e['source']}→{e['target']}) has source",
                  bool(e.get("source")), str(e))
            check(f"edge ({e['source']}→{e['target']}) has target",
                  bool(e.get("target")), str(e))
            check(f"edge ({e['source']}→{e['target']}) has label",
                  "label" in e, str(e))
    finally:
        db.close()


def test_root_field(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("5. root field — entry-point node, no incoming edges")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id   = _prepare_kb(db, admin_username, _standard_graph())
        conv_id = str(uuid.uuid4())
        msg_id  = str(uuid.uuid4())
        chain   = ["lu82", "mn04", "ux12", "auth_service"]
        _write_conversation(kb_id, conv_id, chain, [_make_msg(msg_id)])

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/file-flow-graph",
            headers=admin_headers,
        )
        body  = resp.json()
        root  = body.get("root")
        nodes = body.get("nodes", [])
        node_ids = {n["id"] for n in nodes}

        check("root field is present and non-null", root is not None, str(root))
        check("root matches a node.id", root in node_ids,
              f"root={root!r} node_ids={node_ids}")
        check("root is 'lu82' (only node with no incoming edges)", root == "lu82",
              f"got={root!r}")

        # Single-node graph — root must still be set
        kb_id2   = _prepare_kb(db, admin_username, {
            "nodes": [{"id": "solo", "type": "asm", "file": "solo.asm"}],
            "edges": [],
        })
        conv_id2 = str(uuid.uuid4())
        msg_id2  = str(uuid.uuid4())
        _write_conversation(kb_id2, conv_id2, ["solo"], [_make_msg(msg_id2)])

        resp2 = client.get(
            f"/v1/knowledge-bases/{kb_id2}/conversations/{conv_id2}/messages/{msg_id2}/file-flow-graph",
            headers=admin_headers,
        )
        body2 = resp2.json()
        check("single-node graph root == 'solo'",
              body2.get("root") == "solo",
              f"got={body2.get('root')!r}")
    finally:
        db.close()


def test_determinism(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("6. determinism — same msg_id returns identical graph on repeat calls")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id   = _prepare_kb(db, admin_username, _standard_graph())
        conv_id = str(uuid.uuid4())
        msg_id  = str(uuid.uuid4())
        chain   = ["lu82", "mn04", "ux12", "auth_service"]
        _write_conversation(kb_id, conv_id, chain, [_make_msg(msg_id)])

        url = (
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}"
            f"/messages/{msg_id}/file-flow-graph"
        )

        r1 = client.get(url, headers=admin_headers).json()
        r2 = client.get(url, headers=admin_headers).json()

        check("root identical across calls",
              r1.get("root") == r2.get("root"),
              f"r1={r1.get('root')!r}  r2={r2.get('root')!r}")

        ids1 = sorted(n["id"] for n in r1.get("nodes", []))
        ids2 = sorted(n["id"] for n in r2.get("nodes", []))
        check("node ids identical across calls", ids1 == ids2, str(ids1))

        edges1 = sorted((e["source"], e["target"], e.get("label", ""))
                        for e in r1.get("edges", []))
        edges2 = sorted((e["source"], e["target"], e.get("label", ""))
                        for e in r2.get("edges", []))
        check("edges identical across calls", edges1 == edges2, str(edges1))

        labels1 = sorted(n.get("label", "") for n in r1.get("nodes", []))
        labels2 = sorted(n.get("label", "") for n in r2.get("nodes", []))
        check("node labels identical across calls", labels1 == labels2, str(labels1))
    finally:
        db.close()


def test_chain_subgraph_filtering(
    client: TestClient,
    admin_headers: Dict[str, str],
    admin_username: str,
) -> None:
    print("\n" + "=" * 70)
    print("7. chain filtering — only nodes/edges in selected_chain appear")
    print("=" * 70)

    db = SessionLocal()
    try:
        kb_id = _prepare_kb(db, admin_username, _standard_graph())

        # Conversation with only the first two files in the chain
        conv_id = str(uuid.uuid4())
        msg_id  = str(uuid.uuid4())
        _write_conversation(kb_id, conv_id, ["lu82", "mn04"], [_make_msg(msg_id)])

        resp = client.get(
            f"/v1/knowledge-bases/{kb_id}/conversations/{conv_id}/messages/{msg_id}/file-flow-graph",
            headers=admin_headers,
        )
        body  = resp.json()
        nodes = body.get("nodes", [])
        edges = body.get("edges", [])
        node_ids = {n["id"] for n in nodes}

        check("only 2 nodes (chain subset)", len(nodes) == 2, str(node_ids))
        check("lu82 present", "lu82" in node_ids, str(node_ids))
        check("mn04 present", "mn04" in node_ids, str(node_ids))
        check("ux12 absent",  "ux12" not in node_ids, str(node_ids))
        check("auth_service absent", "auth_service" not in node_ids, str(node_ids))
        check("only 1 edge (lu82→mn04)", len(edges) == 1, str(edges))
        check("edge label is 'FUNCTION' (ENTRC)",
              edges[0].get("label") == "FUNCTION" if edges else False,
              str(edges))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

def cleanup() -> None:
    db = SessionLocal()
    try:
        for kb_id in _CREATED_KBS:
            db.query(KnowledgeBaseAccess).filter(
                KnowledgeBaseAccess.kb_id == kb_id
            ).delete()
            db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).delete()
            shutil.rmtree(WorkspaceManager(kb_id).root, ignore_errors=True)
        for username in _CREATED_USERS:
            db.query(User).filter(User.username == username).delete()
        db.commit()
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    create_tables()
    suffix = uuid.uuid4().hex[:8]
    admin_username = f"ffg_admin_{suffix}"
    user_username  = f"ffg_user_{suffix}"

    db = SessionLocal()
    try:
        _create_user(db, admin_username, role="admin")
        _create_user(db, user_username,  role="user")
        db.commit()
    finally:
        db.close()

    admin_headers = _auth_headers(admin_username, "admin")
    user_headers  = _auth_headers(user_username,  "user")

    try:
        with TestClient(app) as client:
            test_auth_and_routing(client, admin_headers, user_headers, admin_username)
            test_empty_graph_cases(client, admin_headers, admin_username)
            test_node_shape(client, admin_headers, admin_username)
            test_edge_shape_and_label_mapping(client, admin_headers, admin_username)
            test_root_field(client, admin_headers, admin_username)
            test_determinism(client, admin_headers, admin_username)
            test_chain_subgraph_filtering(client, admin_headers, admin_username)
    finally:
        cleanup()

    print(f"\n{'=' * 70}")
    print(f"Results: {PASS} PASS / {FAIL} FAIL / {PASS + FAIL} total")
    print(f"{'=' * 70}")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
