# fixes/

Phased work-in-progress folder for the C++ ↔ ASM variable lineage bridge
described in `docs/plans/2026-04-23-cpp-variable-lineage-strategy 1.md`.

Each phase lives in its own subdirectory with:
- `plan.md` — self-contained description of what the phase does, what it
  touches, and how to verify it.
- `test_*.py` — runnable verification script.

Phases land in order. Do not start N+1 until N's test script prints PASS.

| # | Phase | Status |
|---|---|---|
| 1 | `memcpy`/`memset`/etc. emit CAssignment in addition to CCall | DONE (`2d2eab1`) |
| 2 | Extract `// asm_name` trailing comments from `cc*.hpp` → `field_asm_aliases` | DONE (`9a951c5`) |
| 3 | Attach `asm_alias` metadata to C++ lineage nodes | DONE (`66a297b`) |
| 4 | Scoped cross-language alias edges in `GlobalLineageStitcher` | DONE |
| 5 | Enum value resolution (`AddLimit` → `'A'`) | DONE |
| 5b | Conditional enum tracking (`if (x == AddLimit)`) | DONE |
| 6 | ECB control-block mapping (`ce1crN` ↔ `CE1CRN`) | DONE |
| 7 | `glob(_name)` → named global variable | DONE |
| TPF | TPF_regs end-to-end register bridge | DONE |
| BT  | Backward-traversal ↔ C++ lineage bridge (integration) | DONE |
| BT2 | Alias-only C++ field materialization for backward traversal | DONE |
