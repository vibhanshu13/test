# Phase 1 — `memcpy` / `memset` / `strcpy` as Assignment

**Status:** NOT STARTED (awaiting approval to edit).
**Source plan:** `docs/plans/2026-04-23-cpp-variable-lineage-strategy 1.md` §5.1, §6.1.
**Why first:** Without this, ~65% of C++ struct-field writes are invisible. Every downstream phase (field-alias extraction, cross-language stitching) would operate on a graph that's missing the majority of writes.

---

## The problem in one picture

In z/TPF-style mixed C++/ASM code, both sides write to the same shared memory (ECB slots, Dsect-shaped structs).

```
C++ side:      memcpy(da7gl->reply.responseCode, "99", 2);   // writes WK_REPLY.responseCode
ASM side:      MVC  WK_REPLY,=C'99'                           // writes WK_REPLY
```

The ASM parser sees `MVC` and correctly records "WK_REPLY was written."
The C++ parser sees `memcpy(...)` and records "a call to memcpy happened" — it does **not** record that `da7gl->reply.responseCode` was written.

Consequence: when we trace a variable across files, the ASM writes show up; the C++ writes (via memcpy) are silent. A huge chunk of the lineage graph is missing.

Direct assignments (`a->b = c`) already work. Only the memory-copy intrinsics are blind.

## How dominant is this?

From `dx740200.cpp` alone: ~80 `memcpy` calls vs ~44 direct `=` writes. `memcpy` is the **primary** mutation mechanism in this codebase, not the exception.

---

## The fix

Teach the C++ parser that a bare call to a memory-write intrinsic is **also** an assignment. Keep the existing `CCall` (so the call graph is unchanged); additionally synthesize a `CAssignment` whose target is arg[0] and whose sources come from arg[1] (or the literal, for `memset`).

### Intrinsic table

| Pattern | Target | Source | operation_type |
|---|---|---|---|
| `memcpy(dst, src, n)` | arg[0] | arg[1] | `memcpy` |
| `memmove(dst, src, n)` | arg[0] | arg[1] | `memmove` |
| `memset(dst, val, n)` | arg[0] | literal(arg[1]) | `memset` |
| `strcpy(dst, src)` | arg[0] | arg[1] | `strcpy` |
| `strncpy(dst, src, n)` | arg[0] | arg[1] | `strncpy` |
| `sprintf(dst, fmt, ...)` | arg[0] | args from idx 2 onward | `sprintf` |
| `snprintf(dst, sz, fmt, ...)` | arg[0] | args from idx 3 onward | `snprintf` |
| `strftime(dst, sz, fmt, tm)` | arg[0] | arg[3] | `strftime` |

---

## Files touched (2 files, additive only)

### 1. `models/c_family.py`
Add one optional field to `CAssignment`:
```python
operation_type: Optional[str] = None   # "memcpy" | "memset" | ... | None for direct =
```
Default `None` — no existing caller breaks.

### 2. `passes/c_family_parser.py`
Two additions inside `parse()`:

**(a)** Table of intrinsics (near top of `parse()` or module-level):
```python
MEMORY_WRITE_INTRINSICS = {
    "memcpy":   {"target_arg": 0, "source_arg": 1},
    "memmove":  {"target_arg": 0, "source_arg": 1},
    "memset":   {"target_arg": 0, "source_arg": 1, "source_is_literal": True},
    "strcpy":   {"target_arg": 0, "source_arg": 1},
    "strncpy":  {"target_arg": 0, "source_arg": 1},
    "sprintf":  {"target_arg": 0, "source_args": "rest_from_2"},
    "snprintf": {"target_arg": 0, "source_args": "rest_from_3"},
    "strftime": {"target_arg": 0, "source_arg": 3},
}
```

**(b)** Right after `unit.calls.append(CCall(...))` at line 761, branch on `func_name in MEMORY_WRITE_INTRINSICS`:
- Walk `call_node.child_by_field_name("arguments")`, collect named arg nodes.
- Take `arg_nodes[spec["target_arg"]]` as the target node.
- If it's a `pointer_expression` with `&` prefix, drop the `&` so `&da7gl->reply.x` analyses as the struct field.
- Call the existing `determine_target(target_node)` — same classifier used for ordinary assignment LHS. Returns `(target, target_kind, pointer_depth, target_base, target_field)`.
- Build sources:
  - `source_is_literal` → `node_text(arg_nodes[source_arg]).strip()`.
  - `source_arg` → run `extract_identifiers` + `extract_string_literals` + `extract_access_path` on that node.
  - `source_args: "rest_from_N"` → same, over `arg_nodes[N:]`.
- Emit `CAssignment(..., operation_type=func_name, call_function=func_name, call_asm_target=None)`.

### What this does NOT change
- Direct assignments (`x = y`, `a->b = c`): unchanged.
- `x = memcpy(...)` (rare but legal): outer assignment_expression still fires and the new synth also fires. Two correct edges (`x ← memcpy_ret`, `arg0 ← arg1`), no collision.
- `variable_lineage_builder.process_c_family`: no change. It already walks `unit.assignments`; the new entries just appear.
- JSON emission: `operation_type` will either flow automatically via dataclass serialization or need a one-liner in `json_emitter.py` — will verify in test and adjust if needed.

---

## Unknowns to verify while editing (not guess)

1. **`&x` arg node type.** Need to confirm it's tree-sitter `pointer_expression` with `&` prefix. Will probe with a small AST-dump before committing the strip logic.
2. **Pointer-arith target** like `memcpy((char*)ptr + 43, src, 4)`. Will come out as `target_kind="variable"` with raw text as name — honest but noisy. Accept for Phase 1; refine later if needed.
3. **`operation_type` in emitted JSON.** If `json_emitter` uses dataclass asdict, it auto-flows. If it enumerates fields, one-line addition. Will find out in the test.

---

## Verification

Run `python3 fixes/phase1_memcpy_as_assignment/test_memcpy_as_assignment.py` from the repo root.

**BEFORE the patch:** the test prints rows showing each expected assignment as `MISSING` (because the parser today emits only CCall for these).

**AFTER the patch:** every expected assignment prints `PASS` with the right target, sources, and operation_type. CCall entries for each intrinsic also still appear (old behavior preserved).

The script also runs the parser against `../asm/dx740200.cpp` (the real file with ~80 memcpy calls) and reports the delta in `unit.assignments` count: before-patch ≈ 44, after-patch ≈ 120+.

## Exit criteria

- Synthetic-snippet test: every expected `(target, source, operation_type)` row PASSes.
- Real-file delta: `unit.assignments` count rises by ≥ 50 on `dx740200.cpp`.
- No existing unit or integration test regresses. (`passes/` suite + any prior `*_test_cases/` runners should still behave identically for non-intrinsic assignments.)
