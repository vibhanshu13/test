#!/usr/bin/env python3
"""Phase 1 verification — memcpy/memset/etc. as CAssignment.

Usage:
    python3 fixes/phase1_memcpy_as_assignment/test_memcpy_as_assignment.py

Run BEFORE the patch: every expected row prints MISSING.
Run AFTER the patch: every expected row prints PASS + the synthesized
CAssignment fields (target, sources, target_kind, operation_type).
Also runs the parser against ../asm/dx740200.cpp and reports the delta
in unit.assignments count.

This script is the authoritative exit gate for Phase 1. Move to Phase 2
only when every row prints PASS and the real-file delta is >= 50.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Make project root importable regardless of cwd.
REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))

from passes.c_family_parser import CFamilyParser  # noqa: E402


# --- Synthetic snippet covering every intrinsic + edge cases ----------------

SNIPPET = """\
#include <cstring>
#include <cstdio>

struct Reply {
    char responseCode[2];
    char msgReceivedDate[8];
    char pcn[10];
};

struct Da7gl {
    Reply reply;
    char dateWorkArea[8];
    char specialOptimaError[2];
    char tmsmaWorkArea[32];
};

void f(Da7gl* da7gl, const char* src, int n) {
    // Straight struct-field target, string-literal source.
    memcpy(da7gl->reply.responseCode, "99", sizeof da7gl->reply.responseCode);

    // memset with literal fill value.
    memset(da7gl->specialOptimaError, '0', 2);

    // Address-of target — should analyse as the struct field, not the &expr.
    memcpy(&da7gl->reply.msgReceivedDate, da7gl->dateWorkArea, 8);

    // Variable source.
    memcpy(da7gl->reply.pcn, src, 10);

    // strcpy with literal source.
    strcpy(da7gl->reply.pcn, "ABC");

    // strncpy with variable source.
    strncpy(da7gl->tmsmaWorkArea, src, n);

    // memmove between two struct fields.
    memmove(da7gl->dateWorkArea, da7gl->reply.msgReceivedDate, 8);

    // sprintf — target arg[0], sources args from index 2 onward.
    sprintf(da7gl->tmsmaWorkArea, "%s-%d", src, n);
}
"""


# (target substring, source substring that MUST appear, expected operation_type)
EXPECTED = [
    ("da7gl->reply.responseCode", '"99"',               "memcpy"),
    ("da7gl->specialOptimaError", "'0'",                "memset"),
    ("da7gl->reply.msgReceivedDate", "dateWorkArea",    "memcpy"),
    ("da7gl->reply.pcn",            "src",              "memcpy"),
    ("da7gl->reply.pcn",            '"ABC"',            "strcpy"),
    ("da7gl->tmsmaWorkArea",        "src",              "strncpy"),
    ("da7gl->dateWorkArea",         "msgReceivedDate",  "memmove"),
    ("da7gl->tmsmaWorkArea",        "src",              "sprintf"),
]


def _assignment_matches(asgn, target_sub: str, source_sub: str, op: str) -> bool:
    target = (getattr(asgn, "target", "") or "")
    sources = getattr(asgn, "sources", []) or []
    operation = getattr(asgn, "operation_type", None)

    if target_sub not in target:
        return False
    if operation != op:
        return False
    # source_sub may appear anywhere in any source string or in the expression
    joined = " | ".join(sources) + " || " + (getattr(asgn, "expression", "") or "")
    return source_sub in joined


def run_synthetic() -> int:
    """Return number of failing rows. 0 = all PASS."""
    parser = CFamilyParser(language="cpp")
    fake_path = Path("/tmp/_phase1_synth.cpp")
    unit = parser.parse(fake_path, SNIPPET)

    print("=" * 78)
    print(f"Synthetic snippet — assignments emitted: {len(unit.assignments)}")
    print(f"Synthetic snippet — calls emitted:       {len(unit.calls)}")
    print("=" * 78)

    # Show every assignment for context — helpful whether patched or not.
    for i, a in enumerate(unit.assignments):
        op = getattr(a, "operation_type", None)
        print(
            f"  [{i:02d}] line={a.line:3d}  op={op!r:>12}  "
            f"target_kind={a.target_kind:<13} target={a.target!r}"
        )
        print(f"         sources={a.sources}")
    print()

    failed = 0
    for target_sub, source_sub, op in EXPECTED:
        hit = any(
            _assignment_matches(a, target_sub, source_sub, op)
            for a in unit.assignments
        )
        status = "PASS   " if hit else "MISSING"
        print(f"  {status}  op={op:<9} target~{target_sub!r}  source~{source_sub!r}")
        if not hit:
            failed += 1

    # Preservation check: every intrinsic should still appear as a CCall too.
    print()
    intrinsic_names = {op for _, _, op in EXPECTED}
    for name in intrinsic_names:
        call_present = any(c.function == name for c in unit.calls)
        tag = "PASS   " if call_present else "MISSING"
        print(f"  {tag}  CCall preserved for {name}()")
        if not call_present:
            failed += 1

    return failed


def run_real_file() -> None:
    """Count assignments/calls in the real dx740200.cpp."""
    candidates = [
        REPO_ROOT.parent / "asm" / "dx740200.cpp",
        REPO_ROOT / ".." / "asm" / "dx740200.cpp",
    ]
    target = next((c.resolve() for c in candidates if c.exists()), None)
    if not target:
        print("\n(skipping real-file delta — dx740200.cpp not found)")
        return

    parser = CFamilyParser(language="cpp")
    text = target.read_text(errors="replace")
    unit = parser.parse(target, text)

    memcpy_like = {"memcpy", "memset", "memmove", "strcpy", "strncpy",
                   "sprintf", "snprintf", "strftime"}

    intrinsic_calls = sum(1 for c in unit.calls if c.function in memcpy_like)
    intrinsic_assignments = sum(
        1 for a in unit.assignments if getattr(a, "operation_type", None) in memcpy_like
    )

    print()
    print("=" * 78)
    print(f"Real file: {target.name}")
    print(f"  total assignments:              {len(unit.assignments)}")
    print(f"  total calls:                    {len(unit.calls)}")
    print(f"  calls to memory-write intrinsics: {intrinsic_calls}")
    print(f"  assignments w/ operation_type in intrinsics: {intrinsic_assignments}")
    print("=" * 78)
    print(
        "  Before-patch expectation: intrinsic-assignments == 0 (field or value absent)\n"
        "  After-patch expectation:  intrinsic-assignments approximately == intrinsic-calls"
    )


if __name__ == "__main__":
    failed = run_synthetic()
    run_real_file()

    print()
    if failed == 0:
        print(">>> PHASE 1: ALL SYNTHETIC CHECKS PASSED.")
        sys.exit(0)
    else:
        print(f">>> PHASE 1: {failed} checks MISSING/FAILED. Patch not yet applied (or incomplete).")
        sys.exit(1)
