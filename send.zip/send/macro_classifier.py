"""Classifier for z/TPFDF database macros and z/TPF system macros."""

from typing import Optional, Dict
from models.db_operation import DBOperationType


class MacroClassifier:
    """Classify z/TPFDF database macros and z/TPF system macros.

    Identifies database operation macros and z/TPF system macros.
    """

    def __init__(self):
        # Map z/TPFDF database macro names to operation types
        self.db_macro_map = {
            # Read operations
            "DBRED": DBOperationType.READ,
            "DBGET": DBOperationType.READ,

            # Write operations
            "DBWRT": DBOperationType.WRITE,
            "DBPUT": DBOperationType.WRITE,

            # Update operations
            "DBUPD": DBOperationType.UPDATE,

            # Delete operations
            "DBDEL": DBOperationType.DELETE,

            # Control operations
            "FILEC": DBOperationType.CONTROL,
            "FILET": DBOperationType.CONTROL,
            "DBOPN": DBOperationType.CONTROL,
            "DBCLS": DBOperationType.CONTROL,
        }

        # Common z/TPF system macros (non-database)
        self.ztpf_macros = {
            # Routine entry/exit and cross-segment transfers
            "ENTER", "EXIT", "ENTRC", "ENTNC", "ENTDC", "CREEC", "CREMC", "SWISC", "EXITC",
            # FUNCTION is a local macro wrapper that expands to ENTDC (args[1] is target segment)
            "FUNCTION",

            # Register save/restore
            "SAVE", "RETURN", "SAVEX", "RETRN",

            # Memory management
            "MALOC", "RELOC", "GETCC", "RELCC", "GETFC", "RELFC",

            # Pointer handling
            "PNTRP", "PNTRC",

            # Serialization
            "ENQ", "DEQ", "SERRC", "RELSC",

            # Message handling
            "SENDA", "RECVA", "SENDC", "RECVC",
            "ISCFA", "CRUSA",

            # Time/date
            "TODEC", "TIMC", "DATEC",

            # I/O operations
            "BACKF", "FORWD", "RFILE", "WFILE",

            # Debugging/error handling
            "SNAPC", "DUMPS", "ABEND",

            # Task management
            "ATTAC", "ATTC", "DETAC", "LEVTA", "CREEC",

            # ASM-to-C++ bridge helpers
            "CALLCPP",
        }

    def is_db_macro(self, opcode: str) -> bool:
        """Check if opcode is a z/TPFDF database macro.

        Args:
            opcode: Operation code to check

        Returns:
            True if opcode is a database macro
        """
        if not opcode:
            return False
        return opcode.upper() in self.db_macro_map

    def is_ztpf_macro(self, opcode: str) -> bool:
        """Check if opcode is a z/TPF system macro.

        Args:
            opcode: Operation code to check

        Returns:
            True if opcode is a z/TPF system macro
        """
        if not opcode:
            return False
        return opcode.upper() in self.ztpf_macros

    def is_macro(self, opcode: str) -> bool:
        """Check if opcode is any type of macro (database or system).

        Args:
            opcode: Operation code to check

        Returns:
            True if opcode is a macro
        """
        return self.is_db_macro(opcode) or self.is_ztpf_macro(opcode)

    def classify(self, opcode: str) -> Optional[Dict]:
        """Classify a database macro.

        Args:
            opcode: Operation code to classify

        Returns:
            Dictionary with operation_type and macro_name, or None
        """
        if not self.is_db_macro(opcode):
            return None

        opcode_upper = opcode.upper()
        return {
            "operation_type": self.db_macro_map[opcode_upper],
            "macro_name": opcode_upper
        }

    def get_macro_type(self, opcode: str) -> Optional[str]:
        """Get the type of macro (database or system).

        Args:
            opcode: Operation code to check

        Returns:
            "database" for z/TPFDF macros, "system" for z/TPF macros, None otherwise
        """
        if not opcode:
            return None

        if self.is_db_macro(opcode):
            return "database"
        elif self.is_ztpf_macro(opcode):
            return "system"
        else:
            return None
