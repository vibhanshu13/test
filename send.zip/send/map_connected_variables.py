#!/usr/bin/env python3
"""Map connected variables between two files using stitched lineage evidence.

This builds on top of ``find_connected_variables.py``:

- direct call-boundary register handoff
- return-register handoff
- shared memory field names

The output is intentionally evidence-driven and heuristic. It produces
candidate variable mappings with confidence and path details rather than
claiming a single perfect answer for every ASM pair.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, DefaultDict, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from find_connected_variables import (
    _discover_asm_dir,
    _discover_blueprint_dir,
    _load_blueprint,
    find_all_connections,
)
from trace_lineage import parse_instruction_line


FOLLOW_RELATIONS: Set[str] = {"assign", "alias", "arg_bind"}
FINAL_KINDS: Set[str] = {"memory", "variable", "struct_field", "parameter"}
PASS_THROUGH_KINDS: Set[str] = {"register", "return_value", "call_arg"}
SPECIAL_EDGE_FILES: Set[str] = {"", "<global>", "(tpf_regs_bridge)"}
NOISE_FIELD_NAMES: Set[str] = {"BLANKS", "SPACES", "ZEROES", "ZEROS"}
MAX_WALK_DEPTH = 3
MAX_SIDE_CANDIDATES = 4
ANCHOR_NAME_RE = re.compile(r"^(CE1CR[0-9A-F]+|LEVEL[0-9A-F]+|D[0-9A-F]+|alloc@D[0-9A-F]+:\d+)$", re.IGNORECASE)
USING_INST = {"USING", "DROP"}


def _split_node_id(node_id: str) -> Tuple[str, str]:
    text = str(node_id or "")
    if ":" not in text:
        return "", text
    kind, name = text.split(":", 1)
    return kind, name


def _edge_file_matches(edge: Dict[str, Any], asm_path: Path) -> bool:
    edge_file = str(edge.get("file") or "")
    if edge_file in SPECIAL_EDGE_FILES:
        return True
    try:
        return Path(edge_file).name == asm_path.name
    except Exception:
        return False


def _edge_line(edge: Dict[str, Any]) -> Optional[int]:
    line = edge.get("line")
    if line is None:
        return None
    try:
        return int(line)
    except Exception:
        return None


def _edge_in_window(edge: Dict[str, Any], line_start: Optional[int], line_end: Optional[int]) -> bool:
    line = _edge_line(edge)
    if line is None or line == 0:
        return True
    if line_start is not None and line < line_start:
        return False
    if line_end is not None and line > line_end:
        return False
    return True


def _candidate_is_passthrough(kind: str, name: str) -> bool:
    if kind in PASS_THROUGH_KINDS:
        return True
    if kind == "memory" and name.startswith("caller_param["):
        return True
    if kind == "parameter" and name.startswith("arg@"):
        return True
    return False


def _candidate_is_usable(kind: str, name: str) -> bool:
    if kind not in FINAL_KINDS:
        return False
    if _candidate_is_passthrough(kind, name):
        return False
    upper_name = str(name or "").upper()
    if not name or upper_name in NOISE_FIELD_NAMES:
        return False
    if re.fullmatch(r"\d+", str(name or "")):
        return False
    return True


def _normalize_register_name(token: str) -> Optional[str]:
    text = str(token or "").strip().rstrip(",").upper()
    if re.fullmatch(r"R(?:1[0-5]|[0-9])", text):
        return text
    if text.isdigit():
        value = int(text)
        if 0 <= value <= 15:
            return f"R{value}"
    return None


def _normalize_memory_variant(name: str) -> str:
    text = str(name or "").strip().upper()
    if text.endswith("&A"):
        text = text[:-2]
    return text


def _normalize_dsect_name(name: str) -> str:
    return _normalize_memory_variant(name)


def _collect_field_dsects(blueprint: Dict[str, Any], field_name: str) -> Set[str]:
    wanted = _normalize_memory_variant(field_name)
    dsects: Set[str] = set()
    gvl = blueprint.get("global_variable_lineage") or {}
    for node in gvl.get("nodes", []):
        if str(node.get("kind") or "").lower() != "memory":
            continue
        name = _normalize_memory_variant(str(node.get("name") or ""))
        if name != wanted:
            continue
        metadata = node.get("metadata") or {}
        for key in ("dsect", "cpp_struct"):
            value = _normalize_dsect_name(str(metadata.get(key) or "").strip().upper())
            if value:
                dsects.add(value)
    return dsects


def _read_asm_lines(path: Path) -> List[str]:
    if not path.exists():
        return []
    return path.read_text(encoding="utf-8", errors="replace").splitlines()


def _active_using_map_at_line(asm_lines: List[str], line_no: Optional[int]) -> Dict[str, str]:
    active: Dict[str, str] = {}
    if line_no is None:
        return active
    for lineno in range(1, min(len(asm_lines), int(line_no)) + 1):
        raw = asm_lines[lineno - 1]
        _, inst, args = parse_instruction_line(raw)
        opcode = str(inst).upper() if inst is not None else ""
        if not opcode:
            stripped = raw.strip()
            tokens = stripped.split(None, 2)
            if tokens:
                if tokens[0].upper() in USING_INST:
                    opcode = tokens[0].upper()
                    tail = tokens[1] if len(tokens) > 1 else ""
                elif len(tokens) >= 2 and tokens[1].upper() in USING_INST:
                    opcode = tokens[1].upper()
                    tail = tokens[2] if len(tokens) > 2 else ""
                else:
                    tail = ""
                if opcode in USING_INST:
                    args = [part.strip() for part in tail.split(",") if part.strip()]
        if not opcode:
            continue
        if opcode not in USING_INST:
            continue
        if opcode == "USING" and len(args) >= 2:
            dsect_name = _normalize_dsect_name(str(args[0] or "").strip().upper())
            for arg in args[1:]:
                reg = _normalize_register_name(arg)
                if reg and dsect_name:
                    active[reg] = dsect_name
        elif opcode == "DROP":
            for arg in args:
                reg = _normalize_register_name(arg)
                if reg:
                    active.pop(reg, None)
    return active


def _extract_anchor_name(node_name: str) -> Optional[str]:
    text = str(node_name or "").strip()
    if not text:
        return None
    if ANCHOR_NAME_RE.fullmatch(text):
        return text.upper()
    return None


def _find_anchor_for_register(
    blueprint: Dict[str, Any],
    asm_path: Path,
    register_name: str,
    line_no: Optional[int],
    scope: Optional[str],
) -> Optional[Dict[str, Any]]:
    gvl = blueprint.get("global_variable_lineage") or {}
    candidates: List[Dict[str, Any]] = []
    wanted_target = f"register:{register_name}"
    wanted_scope = str(scope or "").upper()
    for edge in gvl.get("edges", []):
        if str(edge.get("relation") or "").lower() != "assign":
            continue
        if str(edge.get("target") or "") != wanted_target:
            continue
        if not _edge_file_matches(edge, asm_path):
            continue
        edge_line = _edge_line(edge)
        if line_no is not None and edge_line not in (None, 0) and edge_line > int(line_no):
            continue
        src_kind, src_name = _split_node_id(str(edge.get("source") or ""))
        if src_kind != "memory":
            continue
        anchor_name = _extract_anchor_name(src_name)
        if not anchor_name:
            continue
        edge_scope = str(edge.get("scope") or "").upper()
        score = 0
        if wanted_scope and edge_scope == wanted_scope:
            score += 40
        elif wanted_scope and edge_scope:
            score -= 15
        if edge_line not in (None, 0) and line_no is not None:
            score -= min(abs(int(line_no) - int(edge_line)), 25)
        candidates.append(
            {
                "anchor": anchor_name,
                "register": register_name,
                "line": edge_line,
                "scope": edge.get("scope"),
                "expression": str(edge.get("expression") or ""),
                "score": score,
            }
        )
    if not candidates:
        return None
    return sorted(candidates, key=lambda item: (-int(item["score"]), str(item["anchor"])))[0]


def _infer_field_identity(
    blueprint: Dict[str, Any],
    asm_path: Path,
    field_name: str,
    evidence_entries: Sequence[Dict[str, Any]],
) -> Dict[str, Any]:
    asm_lines = _read_asm_lines(asm_path)
    dsects = _collect_field_dsects(blueprint, field_name)
    anchor_candidates: List[Dict[str, Any]] = []

    for entry in evidence_entries:
        line_no = int(entry.get("line") or 0) or None
        scope = str(entry.get("scope") or "")
        using_map = _active_using_map_at_line(asm_lines, line_no)
        matching_regs = [reg for reg, dsect in using_map.items() if not dsects or _normalize_dsect_name(str(dsect).upper()) in dsects]
        for reg in matching_regs:
            anchor = _find_anchor_for_register(blueprint, asm_path, reg, line_no, scope)
            if anchor:
                anchor_candidates.append(anchor)

    deduped_anchors: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for item in anchor_candidates:
        key = (str(item.get("anchor") or ""), str(item.get("register") or ""))
        prev = deduped_anchors.get(key)
        if prev is None or int(item.get("score", 0)) > int(prev.get("score", 0)):
            deduped_anchors[key] = item

    return {
        "field": field_name,
        "dsects": sorted(dsects),
        "anchors": sorted(deduped_anchors.values(), key=lambda item: (-int(item["score"]), str(item["anchor"]))),
    }


def _candidate_score(
    kind: str,
    name: str,
    depth: int,
    terminal_edge: Dict[str, Any],
    boundary_line: Optional[int],
) -> int:
    score = 100
    if kind == "parameter":
        score -= 15
    if name.startswith("caller_param["):
        score -= 30
    if re.search(r"\bCE1CR\d+\b", name.upper()):
        score -= 12
    if re.search(r"\bWB\d+DREG\b", name.upper()):
        score -= 8
    score -= depth * 15

    line = _edge_line(terminal_edge)
    if boundary_line is not None and line not in (None, 0):
        score -= min(abs(boundary_line - line), 25)
    return score


def _build_adjacency(
    blueprint: Dict[str, Any],
    asm_path: Path,
    line_start: Optional[int],
    line_end: Optional[int],
) -> Tuple[DefaultDict[str, List[Dict[str, Any]]], DefaultDict[str, List[Dict[str, Any]]]]:
    incoming: DefaultDict[str, List[Dict[str, Any]]] = defaultdict(list)
    outgoing: DefaultDict[str, List[Dict[str, Any]]] = defaultdict(list)

    gvl = blueprint.get("global_variable_lineage") or {}
    for edge in gvl.get("edges", []):
        relation = str(edge.get("relation") or "").lower()
        if relation not in FOLLOW_RELATIONS:
            continue
        if not _edge_file_matches(edge, asm_path):
            continue
        if not _edge_in_window(edge, line_start, line_end):
            continue
        src = str(edge.get("source") or "")
        tgt = str(edge.get("target") or "")
        if not src or not tgt:
            continue
        incoming[tgt].append(edge)
        outgoing[src].append(edge)

    return incoming, outgoing


def _walk_register_boundary(
    blueprint: Dict[str, Any],
    asm_path: Path,
    register_name: str,
    direction: str,
    line_start: Optional[int],
    line_end: Optional[int],
    boundary_line: Optional[int],
) -> List[Dict[str, Any]]:
    incoming, outgoing = _build_adjacency(blueprint, asm_path, line_start, line_end)
    adjacency = incoming if direction == "backward" else outgoing
    start_node = f"register:{register_name}"

    queue: deque[Tuple[str, int, List[Dict[str, Any]]]] = deque([(start_node, 0, [])])
    visited: Set[Tuple[str, int]] = {(start_node, 0)}
    candidates: Dict[str, Dict[str, Any]] = {}

    while queue:
        node_id, depth, path_edges = queue.popleft()
        if depth >= MAX_WALK_DEPTH:
            continue

        for edge in adjacency.get(node_id, []):
            next_node = str(edge.get("source") if direction == "backward" else edge.get("target"))
            next_kind, next_name = _split_node_id(next_node)
            next_path = path_edges + [edge]
            next_depth = depth + 1

            if _candidate_is_usable(next_kind, next_name):
                candidate = {
                    "node_id": next_node,
                    "kind": next_kind,
                    "name": next_name,
                    "score": _candidate_score(next_kind, next_name, next_depth, edge, boundary_line),
                    "path": [
                        {
                            "source": str(p.get("source") or ""),
                            "target": str(p.get("target") or ""),
                            "relation": str(p.get("relation") or ""),
                            "line": p.get("line"),
                            "expression": str(p.get("expression") or ""),
                        }
                        for p in next_path
                    ],
                    "terminal_line": _edge_line(edge),
                }
                prev = candidates.get(next_node)
                if prev is None or candidate["score"] > prev["score"]:
                    candidates[next_node] = candidate

            if _candidate_is_passthrough(next_kind, next_name) or next_kind == "register":
                state = (next_node, next_depth)
                if state not in visited:
                    visited.add(state)
                    queue.append((next_node, next_depth, next_path))

    ranked = sorted(
        candidates.values(),
        key=lambda item: (-int(item["score"]), str(item["kind"]), str(item["name"])),
    )
    return ranked[:MAX_SIDE_CANDIDATES]


def _estimate_confidence(left: Dict[str, Any], right: Dict[str, Any]) -> str:
    combined = int(left.get("score", 0)) + int(right.get("score", 0))
    if combined >= 170:
        return "high"
    if combined >= 125:
        return "medium"
    return "low"


def _mapping_key(mapping: Dict[str, Any]) -> Tuple[str, str, str, str, str]:
    return (
        str(mapping.get("mapping_type") or ""),
        str(mapping.get("direction") or ""),
        str(mapping.get("from_file") or ""),
        str(mapping.get("from_var") or ""),
        str(mapping.get("to_var") or ""),
    )


def build_variable_mappings(
    file_a: str,
    file_b: str,
    connection_result: Dict[str, Any],
    blueprint_dir: Path,
    asm_dir: Path,
) -> Dict[str, Any]:
    asm_paths = {
        file_a: asm_dir / f"{file_a}.asm",
        file_b: asm_dir / f"{file_b}.asm",
    }
    blueprints = {
        file_a: _load_blueprint(blueprint_dir / f"{file_a}.asm.json") or {},
        file_b: _load_blueprint(blueprint_dir / f"{file_b}.asm.json") or {},
    }

    register_maps: List[Dict[str, Any]] = []
    return_maps: List[Dict[str, Any]] = []
    shared_field_maps: List[Dict[str, Any]] = []
    warnings: List[str] = list(connection_result.get("warnings") or [])

    for conn in connection_result.get("connections", {}).get("call_boundary_registers", []):
        caller = str(conn.get("caller") or "")
        callee = str(conn.get("callee") or "")
        caller_bp = blueprints.get(caller) or {}
        callee_bp = blueprints.get(callee) or {}
        caller_asm = asm_paths.get(caller)
        callee_asm = asm_paths.get(callee)
        if caller_asm is None or callee_asm is None:
            continue

        caller_scan = conn.get("caller_block_scan") or {}
        callee_scan = conn.get("callee_entry_scan") or {}
        call_site = conn.get("call_site") or {}
        call_line = call_site.get("line")

        for passed in conn.get("passed_registers", []):
            register_name = str(passed.get("register") or "")
            if not register_name:
                continue
            caller_line = int((passed.get("set_by_caller") or {}).get("line") or 0) or None
            caller_candidates = _walk_register_boundary(
                caller_bp,
                caller_asm,
                register_name,
                direction="backward",
                line_start=caller_scan.get("scan_start_line"),
                line_end=caller_line,
                boundary_line=caller_line,
            )
            callee_candidates = _walk_register_boundary(
                callee_bp,
                callee_asm,
                register_name,
                direction="forward",
                line_start=callee_scan.get("entry_start_line"),
                line_end=callee_scan.get("entry_end_line"),
                boundary_line=int((passed.get("consumed_by_callee") or {}).get("line") or 0) or None,
            )

            for left in caller_candidates:
                for right in callee_candidates:
                    register_maps.append(
                        {
                            "mapping_type": "call_boundary_register",
                            "direction": str(conn.get("direction") or ""),
                            "from_file": caller,
                            "to_file": callee,
                            "from_var": str(left.get("name") or ""),
                            "to_var": str(right.get("name") or ""),
                            "via_register": register_name,
                            "confidence": _estimate_confidence(left, right),
                            "call_site": call_site,
                            "from_evidence": left,
                            "to_evidence": right,
                        }
                    )

        for ret in conn.get("return_registers", []):
            register_name = str(ret.get("register") or "")
            if not register_name:
                continue
            callee_line = int((ret.get("set_by_callee") or {}).get("line") or 0) or None
            callee_candidates = _walk_register_boundary(
                callee_bp,
                callee_asm,
                register_name,
                direction="backward",
                line_start=None,
                line_end=callee_line,
                boundary_line=callee_line,
            )
            caller_candidates = _walk_register_boundary(
                caller_bp,
                caller_asm,
                register_name,
                direction="forward",
                line_start=(int(call_line) + 1) if call_line else None,
                line_end=(int(call_line) + 20) if call_line else None,
                boundary_line=int(call_line) if call_line else None,
            )

            for left in callee_candidates:
                for right in caller_candidates:
                    return_maps.append(
                        {
                            "mapping_type": "return_register",
                            "direction": f"{callee}_returns_to_{caller}",
                            "from_file": callee,
                            "to_file": caller,
                            "from_var": str(left.get("name") or ""),
                            "to_var": str(right.get("name") or ""),
                            "via_register": register_name,
                            "confidence": _estimate_confidence(left, right),
                            "call_site": call_site,
                            "from_evidence": left,
                            "to_evidence": right,
                        }
                    )

    for shared in connection_result.get("connections", {}).get("shared_memory_fields", []):
        field_name = str(shared.get("field") or "")
        if not field_name or field_name.upper() in NOISE_FIELD_NAMES:
            continue
        identity_a = _infer_field_identity(
            blueprints.get(file_a) or {},
            asm_paths[file_a],
            field_name,
            list(shared.get("in_file_a") or []),
        )
        identity_b = _infer_field_identity(
            blueprints.get(file_b) or {},
            asm_paths[file_b],
            field_name,
            list(shared.get("in_file_b") or []),
        )
        dsect_overlap = sorted(set(identity_a.get("dsects") or []) & set(identity_b.get("dsects") or []))
        anchor_overlap = sorted(
            {str(item.get("anchor") or "") for item in identity_a.get("anchors") or []}
            & {str(item.get("anchor") or "") for item in identity_b.get("anchors") or []}
        )
        confidence = "low"
        if dsect_overlap and anchor_overlap:
            confidence = "high"
        elif dsect_overlap:
            confidence = "medium"
        shared_field_maps.append(
            {
                "mapping_type": "shared_memory_field",
                "direction": f"{file_a}<->{file_b}",
                "from_file": file_a,
                "to_file": file_b,
                "from_var": field_name,
                "to_var": field_name,
                "confidence": confidence,
                "identity_match": {
                    "same_dsect": bool(dsect_overlap),
                    "same_anchor": bool(anchor_overlap),
                    "matched_dsects": dsect_overlap,
                    "matched_anchors": anchor_overlap,
                },
                "from_identity": identity_a,
                "to_identity": identity_b,
                "evidence": shared,
            }
        )

    def _dedupe(items: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
        seen: Set[Tuple[str, str, str, str, str]] = set()
        output: List[Dict[str, Any]] = []
        for item in sorted(items, key=lambda row: (
            str(row.get("mapping_type") or ""),
            str(row.get("from_file") or ""),
            str(row.get("from_var") or ""),
            str(row.get("to_var") or ""),
            str(row.get("via_register") or ""),
        )):
            key = _mapping_key(item)
            if key in seen:
                continue
            seen.add(key)
            output.append(item)
        return output

    register_maps = _dedupe(register_maps)
    return_maps = _dedupe(return_maps)
    shared_field_maps = _dedupe(shared_field_maps)

    return {
        "file_a": file_a,
        "file_b": file_b,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "summary": {
            "register_handoff_mappings": len(register_maps),
            "return_register_mappings": len(return_maps),
            "shared_field_mappings": len(shared_field_maps),
        },
        "register_handoff_mappings": register_maps,
        "return_register_mappings": return_maps,
        "shared_field_mappings": shared_field_maps,
        "warnings": warnings,
    }


def _normalize_file_arg(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return text
    return Path(text).stem


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Map connected variables between two files using stitched lineage evidence."
    )
    parser.add_argument("file_a", help="First file stem or path (e.g. da78 or /path/da78.asm)")
    parser.add_argument("file_b", help="Second file stem or path")
    parser.add_argument("--asm-dir", type=Path, help="Directory containing .asm source files")
    parser.add_argument("--blueprint-dir", type=Path, help="Directory containing .asm.json files")
    parser.add_argument("--output", type=Path, help="Output JSON path")
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)

    file_a = _normalize_file_arg(args.file_a)
    file_b = _normalize_file_arg(args.file_b)

    blueprint_dir = args.blueprint_dir or _discover_blueprint_dir()
    if blueprint_dir is None:
        print("ERROR: Could not find blueprint directory. Use --blueprint-dir.", file=sys.stderr)
        return 1

    asm_dir = args.asm_dir or _discover_asm_dir(blueprint_dir)
    if asm_dir is None:
        print("ERROR: Could not find ASM source directory. Use --asm-dir.", file=sys.stderr)
        return 1

    raw_connections = find_all_connections(file_a, file_b, blueprint_dir, asm_dir)
    mapped = build_variable_mappings(file_a, file_b, raw_connections, blueprint_dir, asm_dir)

    output_path = args.output or Path(f"{file_a}_{file_b}_variable_map.json")
    output_path.write_text(json.dumps(mapped, indent=2), encoding="utf-8")

    print(f"Written: {output_path}")
    print(f"  register_handoff_mappings: {mapped['summary']['register_handoff_mappings']}")
    print(f"  return_register_mappings:  {mapped['summary']['return_register_mappings']}")
    print(f"  shared_field_mappings:     {mapped['summary']['shared_field_mappings']}")
    if mapped["warnings"]:
        for warning in mapped["warnings"]:
            print(f"  WARNING: {warning}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
