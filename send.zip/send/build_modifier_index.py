"""Build an inverted variable → [file_stems] modifier index from blueprints.

Scans every .asm.json and .mac.json blueprint once and writes
``variable_modifier_index.json`` so that subsequent KB modifier queries run in
O(1) (index lookup + scan a handful of files) instead of O(blueprints).

Alias-aware: if a SETTER writes ``BALANCE`` and the blueprint's ``meta.aliases``
maps ``BALANCE ↔ ACCTBAL``, both names are recorded in the index.

Usage (CLI):
    python3 build_modifier_index.py <blueprint_dir> [--output PATH]

The index is also built automatically by ``pipeline_task.py`` as Step 4.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, TimeoutError as _FuturesTimeoutError, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from blueprint_io import iter_flow, load_blueprint
from trace_lineage import SETTER_INST, DEST_ARG_INDEX_BY_INST, normalize_token, is_real_setter_site

INDEX_FILENAME = "variable_modifier_index.json"
_BP_IO_TIMEOUT = 60.0  # max seconds to wait for a single blueprint file read


def _extract_gvl_terminal_name(text: str) -> str:
    """Extract the terminal field name from a GVL node ID or name path.

    Priority: "." first (most common dotted path), then "->", then "::".
    Falls back to the last colon-delimited segment for bare kind:name IDs.
    """
    for sep in (".", "->", "::"):
        if sep in text:
            return text.rsplit(sep, 1)[-1].strip()
    return text.split(":")[-1].strip()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _stem(path: Path) -> str:
    """Return the file stem by stripping composite suffixes like .asm.json."""
    name = path.name
    for suffix in (".asm.json", ".mac.json", ".cpp.json", ".hpp.json", ".json"):
        if name.endswith(suffix):
            return name[: -len(suffix)].lower()
    return path.stem.lower()


def _extract_written_variables(
    blueprint: Dict[str, Any],
    stem: str,
) -> Dict[str, str]:
    """Return {normalized_variable_upper: stem} for all SETTER destinations.

    Alias-expands so that if MVC writes BALANCE and BALANCE is an alias of
    ACCTBAL, both BALANCE and ACCTBAL are recorded for this stem.
    """
    aliases: List[Dict[str, Any]] = blueprint.get("meta", {}).get("aliases", []) or []
    alias_pairs: List[tuple] = [
        (str(a.get("name", "")).upper(), str(a.get("target", "")).upper())
        for a in aliases
        if a.get("name") and a.get("target")
    ]

    written: Dict[str, str] = {}

    for block in blueprint.get("blocks", []) or []:
        for entry in iter_flow(block):
            inst = str(entry.get("inst", "")).upper()
            if inst not in SETTER_INST:
                continue

            # Resolve destination operand
            if "var" in entry:
                raw_dest = str(entry.get("var", "")).strip().upper()
            else:
                args = entry.get("args", []) or []
                if isinstance(args, str):
                    args = [args]
                # Audit §3a/§3b/§3c/§3d: skip value-preserving / spec-exception /
                # zero-mask / nonzero-displacement writes (not real modifiers).
                if args and not is_real_setter_site(inst, args):
                    continue
                dest_idx = DEST_ARG_INDEX_BY_INST.get(inst, 0)
                if dest_idx >= len(args):
                    continue
                raw_dest = str(args[dest_idx]).strip().upper()

            if not raw_dest:
                continue

            norm = normalize_token(raw_dest) or raw_dest

            # Collect this var and all its aliases in this blueprint
            names: Set[str] = {norm}
            for alias_name, alias_target in alias_pairs:
                if alias_name == norm:
                    names.add(alias_target)
                elif alias_target == norm:
                    names.add(alias_name)

            for n in names:
                if n:
                    written[n] = stem

    return written


def _build_cpp_index_from_gvl(blueprint_dir: Path) -> Dict[str, Set[str]]:
    """Scan the shared GVL once to index all C++ variable assignments.

    Per-file .cpp.json blueprints have global_variable_lineage=null; the real
    GVL lives in an external global_variable_lineage.json/.msgpack file located
    via find_gvl_path().  A single streaming pass is O(edges) rather than
    O(blueprints × edges).

    Returns {variable_upper: set(stems)} or an empty dict on any error.
    """
    try:
        from backward_traversal.utils.lazy_gvl import make_lazy_gvl, find_gvl_path
    except ImportError as exc:
        print(f"WARNING: C++ GVL indexing unavailable (import error): {exc}", flush=True)
        return {}

    any_cpp = next(blueprint_dir.glob("*.cpp.json"), None)
    if not any_cpp:
        return {}

    gvl_path = find_gvl_path(any_cpp)
    if gvl_path and gvl_path.exists():
        gvl = make_lazy_gvl({"_gvl_path": str(gvl_path)})
    else:
        # GVL file absent (deleted after DB ingestion) — use DB fallback.
        # Passing blueprint_path triggers make_lazy_gvl's DbLazyGVL path,
        # which streams gvl_nodes/gvl_edges from the index.db found by
        # walking up from blueprint_path.
        gvl = make_lazy_gvl({}, blueprint_path=any_cpp)
        if not gvl:
            print(
                "WARNING: global_variable_lineage not found on disk or in DB; "
                "C++ variables will not be indexed.",
                flush=True,
            )
            return {}

    if not gvl:
        return {}

    cpp_stems: Set[str] = {_stem(p) for p in blueprint_dir.glob("*.cpp.json")}
    result: Dict[str, Set[str]] = defaultdict(set)

    for edge in (gvl.get("edges") or []):
        if edge.get("relation") not in ("assign", "define"):
            continue
        target_id = str(edge.get("target") or "")
        if not target_id:
            continue
        src_file = str(edge.get("file") or "")
        if not src_file:
            continue
        stem = os.path.splitext(os.path.basename(src_file))[0].lower()
        if stem not in cpp_stems:
            continue
        norm = _extract_gvl_terminal_name(target_id).upper()
        if norm:
            result[norm].add(stem)

    return dict(result)


# ---------------------------------------------------------------------------
# Per-blueprint worker (module-level so ThreadPoolExecutor can pickle it)
# ---------------------------------------------------------------------------

def _process_one_blueprint(bp_path: Path) -> Dict[str, str]:
    """Load one ASM/MAC blueprint and return its {variable_upper: stem} mapping.

    Returns an empty dict on any error (warning printed to stdout so the
    job log captures it).
    """
    try:
        blueprint = load_blueprint(
            bp_path, skip_global_lineage=True, keys={"meta", "blocks"}
        )
    except Exception as exc:
        print(f"WARNING: Skipping {bp_path.name}: {exc}", flush=True)
        return {}
    return _extract_written_variables(blueprint, _stem(bp_path))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_index(
    blueprint_dir: Path,
    output_path: Optional[Path] = None,
    *,
    job_id: Optional[str] = None,
) -> Optional[Path]:
    """Scan all blueprints in *blueprint_dir* and build the inverted modifier index.

    Args:
        blueprint_dir: Directory containing .asm.json, .mac.json, and .cpp.json files.
        output_path:   Where to write the index JSON.
                       Defaults to ``blueprint_dir.parent / INDEX_FILENAME``.
                       Ignored when *job_id* is provided (data goes to index.db).
        job_id:        When provided, write directly to the index DB via
                       ``ingest_modifier_index_from_dict`` instead of writing
                       a JSON file.  No JSON file is created.

    Returns:
        Path to the written index file, or ``None`` when *job_id* is provided
        (data written to DB, no file created).
    """
    if output_path is None and job_id is None:
        output_path = blueprint_dir.parent / INDEX_FILENAME

    asm_mac_files = sorted(
        list(blueprint_dir.glob("*.asm.json"))
        + list(blueprint_dir.glob("*.mac.json"))
    )
    cpp_files = sorted(blueprint_dir.glob("*.cpp.json"))

    # index[variable_upper] = set of stems that write it
    index: Dict[str, Set[str]] = defaultdict(set)

    total = len(asm_mac_files) + len(cpp_files)
    # Cap workers to match build_variable_identity_index: each worker must
    # decompress the full blueprint before key-pruning, so large blueprints
    # (with populated variable_lineage) can spike RAM significantly per worker.
    _workers = min(8, (os.cpu_count() or 4))
    completed = 0

    # ASM/MAC files: per-blueprint workers (blocks[].flow contains setter instructions).
    with ThreadPoolExecutor(max_workers=_workers) as pool:
        futures: Dict[Any, Path] = {
            pool.submit(_process_one_blueprint, p): p for p in asm_mac_files
        }

        for fut in as_completed(futures):
            try:
                result = fut.result(timeout=_BP_IO_TIMEOUT)
            except _FuturesTimeoutError:
                print(
                    f"WARNING: Timed out processing {futures[fut].name} (>{_BP_IO_TIMEOUT:.0f}s), skipping.",
                    flush=True,
                )
                result = {}
            except Exception as exc:
                print(f"WARNING: Error processing {futures[fut].name}: {exc}", flush=True)
                result = {}
            for var_name, file_stem in result.items():
                index[var_name].add(file_stem)
            completed += 1
            if completed % 1000 == 0 or completed == total:
                pct = completed * 100 // total
                print(
                    f"  Modifier index build: {completed}/{total} blueprints ({pct}%)",
                    flush=True,
                )

    # C++ files: single GVL pass (per-file blueprints have global_variable_lineage=null;
    # the real assignments live in the shared external GVL file).
    if cpp_files:
        print(f"  Building C++ modifier index via GVL scan ({len(cpp_files)} C++ blueprints)...", flush=True)
        cpp_index = _build_cpp_index_from_gvl(blueprint_dir)
        for var_name, stems in cpp_index.items():
            for stem in stems:
                index[var_name].add(stem)
        completed += len(cpp_files)
        pct = completed * 100 // total
        print(
            f"  Modifier index build: {completed}/{total} blueprints ({pct}%) — "
            f"C++ GVL scan added {len(cpp_index)} unique variable(s)",
            flush=True,
        )

    serialised = {var: sorted(stems) for var, stems in sorted(index.items())}

    payload: Dict[str, Any] = {
        "_meta": {
            "built_at": datetime.now(timezone.utc).isoformat(),
            "blueprints_scanned": total,
            "unique_variables": len(serialised),
        },
        "index": serialised,
    }

    if job_id is not None:
        # Write directly to the index DB — no JSON file created.
        try:
            from api.index_db.writers import ingest_modifier_index_from_dict
            ingest_modifier_index_from_dict(job_id, payload)
        except Exception as exc:
            print(f"WARNING: ingest_modifier_index_from_dict failed: {exc}", flush=True)
        print(
            f"Modifier index written to index DB "
            f"({total} blueprints, {len(serialised)} unique variables)",
            flush=True,
        )
        return None

    # JSON path (CLI or job_id not provided).
    output_path.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
    # Use stdout so this completion message is visible in the job log.
    print(
        f"Wrote modifier index: {output_path} "
        f"({total} blueprints, {len(serialised)} unique variables)",
        flush=True,
    )
    return output_path


def load_index(index_path: Path) -> Optional[Dict[str, List[str]]]:
    """Load the index from *index_path*.

    Returns the ``index`` dict (variable_upper → [stems]) or ``None`` if the
    file is absent or unreadable.
    """
    if not index_path.exists():
        return None
    try:
        data = json.loads(index_path.read_text(encoding="utf-8"))
        return data.get("index")
    except Exception:
        return None


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Build variable_modifier_index.json from blueprint output."
    )
    parser.add_argument("blueprint_dir", help="Directory containing .asm.json / .mac.json files")
    parser.add_argument(
        "--output",
        help=f"Output path (default: <blueprint_dir>/../{INDEX_FILENAME})",
    )
    args = parser.parse_args()

    bp_dir = Path(args.blueprint_dir)
    out = Path(args.output) if args.output else None
    build_index(bp_dir, out)
