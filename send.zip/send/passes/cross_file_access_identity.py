"""Post-processing pass: back-fill access_identity on variable-lineage edges.

The main analysis pipeline processes each source file in isolation, so a
builder processing ``da76.asm`` never sees the DSECT field definitions that
live in ``hubgl.mac`` (a different builder instance).  This pass runs
*after* all blueprints have been emitted and:

1. Collects every DSECT layout from every blueprint file in the output dir.
2. For each ``.asm.json`` blueprint, resolves any edge that has ``dsect``
   set but ``field_offset`` or ``ce_slot`` still null.
3. Upgrades plain-label edges (no dsect) to DSECT:FIELD identity where possible.
4. Assigns file_label to truly local labels that have no DSECT match.
5. Re-saves modified blueprints in their original format (msgpack).

Only ECB-resident DSECTs (those whose base register traces back to a
``CE1CRx`` control slot) can receive ``access_identity``; local workarea
DSECTs that are never loaded from a CE slot are left as-is.

Identity layers assigned by this pass:
  L1  access_identity   = "CE1CR5:28"     (ECB-resident field, CE slot known)
  L2  symbolic_identity = "LG1G1:LG1OSI"  (DSECT field, symbolic name in node_id)
  L2b symbolic_identity = "WB1WB:WB1SUPP" (plain label upgraded via field→DSECT map)
  L4  file_label        = "da76:WB1ACCTC"  (local label, no DSECT match)
"""
from __future__ import annotations

import bisect
import logging
import os
from concurrent.futures import ThreadPoolExecutor, TimeoutError as _FuturesTimeoutError, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from blueprint_io import load_blueprint, write_blueprint

logger = logging.getLogger(__name__)

_BP_IO_TIMEOUT = 60.0  # max seconds to wait for a single blueprint file read


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def enrich_access_identity(output_dir: Path) -> Dict[str, Any]:
    """Enrich all ``.asm.json`` blueprints in *output_dir* with identity fields.

    Returns a summary dict with coverage stats.
    """
    output_dir = Path(output_dir)

    # --- Step 1: build global DSECT layout from ALL blueprint files ----------
    global_dsect_offsets = _collect_global_dsect_layouts(output_dir)
    logger.info(
        "cross_file_access_identity: loaded %d DSECTs from %s",
        len(global_dsect_offsets),
        output_dir,
    )

    # Build reverse map: field_name_upper → [(dsect, offset, length)]
    # Used for L2b: plain memory label → DSECT:FIELD_NAME upgrade
    field_to_dsect: Dict[str, List[Tuple[str, int, int]]] = {}
    for _dsect_name, _fields in global_dsect_offsets.items():
        for _fname, (_off, _len) in _fields.items():
            field_to_dsect.setdefault(_fname.upper(), []).append((_dsect_name, _off, _len))

    # --- Step 2: enrich each ASM blueprint (parallel — each file is independent)
    asm_files = sorted(output_dir.glob("*.asm.json"))
    total_edges = 0
    total_with_dsect = 0
    total_newly_enriched = 0
    total_l2b_upgraded = 0
    total_l4_labeled = 0

    # Cap at 8 workers: each loads line_metadata + variable_lineage (~2–8 MB).
    # Previous value of min(32, cpu*2) could spike to 32×50 MB = 1.6 GB with
    # the old unfiltered load; now ~8×8 MB = 64 MB peak with the key filter.
    _workers = min(8, (os.cpu_count() or 4))
    with ThreadPoolExecutor(max_workers=_workers) as pool:
        futures = {
            pool.submit(_enrich_blueprint, bp_path, global_dsect_offsets, field_to_dsect): bp_path
            for bp_path in asm_files
        }
        for fut in as_completed(futures):
            try:
                e, d, n, l2b, l4 = fut.result(timeout=_BP_IO_TIMEOUT)
            except _FuturesTimeoutError:
                logger.warning("Timed out enriching %s (%.0fs)", futures[fut].name, _BP_IO_TIMEOUT)
                e = d = n = l2b = l4 = 0
            except Exception as exc:
                logger.warning("Failed to enrich %s: %s", futures[fut].name, exc)
                e = d = n = l2b = l4 = 0
            total_edges += e
            total_with_dsect += d
            total_newly_enriched += n
            total_l2b_upgraded += l2b
            total_l4_labeled += l4

    coverage = (
        round(100.0 * total_newly_enriched / total_with_dsect, 1)
        if total_with_dsect
        else 0.0
    )
    result = {
        "dsect_layouts_collected": len(global_dsect_offsets),
        "asm_files_processed": len(asm_files),
        "total_edges": total_edges,
        "edges_with_dsect": total_with_dsect,
        "edges_newly_enriched": total_newly_enriched,
        "enrichment_coverage_pct": coverage,
        "label_upgraded_to_dsect": total_l2b_upgraded,
        "file_label_assigned": total_l4_labeled,
    }
    logger.info("cross_file_access_identity result: %s", result)
    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _load_dsect_layouts_from_blueprint(
    bp_path: Path,
) -> Dict[str, Dict[str, Tuple[int, int]]]:
    """Worker: load one blueprint and return its normalised DSECT layouts."""
    local: Dict[str, Dict[str, Tuple[int, int]]] = {}
    try:
        bp = load_blueprint(bp_path, skip_global_lineage=True, keys={"dsect_layouts"})
    except Exception as exc:
        logger.warning("Skipping %s: %s", bp_path, exc)
        return local
    for dsect_name, fields in bp.get("dsect_layouts", {}).items():
        amp = dsect_name.find("&")
        canonical = dsect_name[:amp] if amp >= 0 else dsect_name
        dst = local.setdefault(canonical, {})
        for field_name, info in fields.items():
            famp = field_name.find("&")
            canonical_field = field_name[:famp] if famp >= 0 else field_name
            if canonical_field not in dst:
                try:
                    dst[canonical_field] = (int(info["offset"]), int(info["length"]))
                except (KeyError, TypeError, ValueError):
                    pass
    return local


def _collect_global_dsect_layouts(
    output_dir: Path,
) -> Dict[str, Dict[str, Tuple[int, int]]]:
    """Return {dsect_name: {field_name: (offset, length)}} from all blueprints."""
    all_paths: List[Path] = []
    for suffix in ("*.asm.json", "*.mac.json", "*.cpp.json"):
        all_paths.extend(output_dir.glob(suffix))

    global_offsets: Dict[str, Dict[str, Tuple[int, int]]] = {}
    # cap at 16: each worker loads only dsect_layouts (~1–10 KB per blueprint),
    # so 16 concurrent is cheap while still providing good I/O parallelism.
    _workers = min(16, (os.cpu_count() or 4) * 2)

    with ThreadPoolExecutor(max_workers=_workers) as pool:
        futures = {pool.submit(_load_dsect_layouts_from_blueprint, p): p for p in all_paths}
        for fut in as_completed(futures):
            try:
                local = fut.result(timeout=_BP_IO_TIMEOUT)
            except _FuturesTimeoutError:
                logger.warning(
                    "_collect_global_dsect_layouts: timed out reading %s (%.0fs)",
                    futures[fut].name, _BP_IO_TIMEOUT,
                )
                continue
            except Exception as exc:
                logger.warning(
                    "_collect_global_dsect_layouts: error reading %s: %s",
                    futures[fut].name, exc,
                )
                continue
            for dsect_name, fields in local.items():
                dst = global_offsets.setdefault(dsect_name, {})
                for field_name, fdata in fields.items():
                    dst.setdefault(field_name, fdata)  # first writer wins

    return global_offsets


def _build_dsect_to_ce_slot(
    line_metadata: Dict[str, Any],
) -> Dict[str, str]:
    """Return {dsect_name: ce_slot} from all USING snapshots in *line_metadata*.

    Uses ``setdefault`` so the first observed CE-slot mapping wins.
    """
    dsect_to_ce: Dict[str, str] = {}
    for lm in line_metadata.values():
        active_usings: Dict[str, str] = lm.get("active_usings") or {}
        ce_slots: Dict[str, str] = lm.get("register_ce_slots") or {}
        for reg, dsect in active_usings.items():
            if reg in ce_slots:
                dsect_to_ce.setdefault(dsect, ce_slots[reg])
    return dsect_to_ce


def _nearest_snapshot(
    snap_lines: List[int],
    line_metadata: Dict[str, Any],
    edge_line: int,
) -> Optional[Dict[str, Any]]:
    """Return the line-metadata entry whose line is <= *edge_line*, or None."""
    idx = bisect.bisect_right(snap_lines, edge_line) - 1
    if idx < 0:
        return None
    return line_metadata.get(str(snap_lines[idx]))


def _field_offset_from_node(
    node_id: str,
    dsect: str,
    global_dsect_offsets: Dict[str, Dict[str, Tuple[int, int]]],
) -> Optional[int]:
    """Resolve byte offset for a node given its blueprint ID and the edge's DSECT.

    node_id format: ``"kind:name"`` where *name* is one of:
    - ``"FIELDNAME"``           — plain symbolic name
    - ``"DSECT_NAME:FIELDNAME"``— USING-qualified symbolic name
    - ``"DSECT_NAME:17"``       — USING-qualified numeric displacement
    - ``"17(Rn)"``              — displacement + base-register

    Returns the byte offset (int) or None if not resolvable.
    """
    colon = node_id.find(":")
    if colon < 0:
        return None
    node_name = node_id[colon + 1:]  # strip the leading "kind:"

    # Strip trailing base-register suffix like "(R5)" or "(R3,R5)"
    paren = node_name.find("(")
    if paren >= 0:
        node_name = node_name[:paren]

    # Strip DSECT qualifier prefix if present ("LG1G1:LG1OSI" → "LG1OSI", "LG1G1:17" → "17")
    if ":" in node_name:
        _, node_name = node_name.split(":", 1)

    # Strip arithmetic displacement suffix like "+12" or "-4"  ("WB1ACCTC+12" → "WB1ACCTC")
    for op in ("+", "-"):
        op_pos = node_name.find(op)
        if op_pos > 0:
            node_name = node_name[:op_pos]
            break

    # Pure numeric displacement → direct byte offset
    try:
        return int(node_name)
    except ValueError:
        pass

    # Symbolic field name → lookup in global DSECT layouts
    fields = global_dsect_offsets.get(dsect, {})
    # Case-insensitive lookup: blueprints may store labels in mixed case
    upper = node_name.upper()
    if node_name in fields:
        return fields[node_name][0]
    if upper in fields:
        return fields[upper][0]
    # Fallback: linear scan (handles mixed-case mismatches)
    for k, (off, _) in fields.items():
        if k.upper() == upper:
            return off
    return None


def _symbolic_name_from_node(node_id: str, dsect: str) -> Optional[str]:
    """Extract the symbolic field name from a DSECT-qualified memory node_id.

    E.g. ``"memory:LG1G1:LG1OSI"`` with dsect=``"LG1G1"`` → ``"LG1OSI"``.
    Returns None for numeric displacements or non-matching DSECT prefixes.
    """
    if not node_id.startswith("memory:"):
        return None
    n = node_id[7:]
    p = n.find("(")
    if p >= 0:
        n = n[:p]
    if ":" in n:
        parts = n.split(":", 1)
        if parts[0].upper() == dsect.upper():
            field = parts[1]
            for op in ("+", "-"):
                pos = field.find(op)
                if pos > 0:
                    field = field[:pos]
                    break
            field = field.strip()
            if field:
                try:
                    int(field)
                    return None  # numeric displacement → L3 not L2
                except ValueError:
                    return field
    return None


def _extract_plain_label(node_id: str) -> Optional[str]:
    """Extract plain symbolic label from a memory node_id, or None.

    Returns None for: non-memory nodes, numeric displacements,
    synthetic nodes (``@``), DSECT-qualified names (``:``).
    """
    if not node_id.startswith("memory:"):
        return None
    n = node_id[7:]
    p = n.find("(")
    if p >= 0:
        n = n[:p]
    for op in ("+", "-"):
        pos = n.find(op)
        if pos > 0:
            n = n[:pos]
            break
    n = n.strip()
    if not n:
        return None
    try:
        int(n)
        return None  # purely numeric
    except ValueError:
        pass
    if "@" in n or ":" in n:
        return None  # synthetic or already DSECT-qualified
    return n


def _enrich_blueprint(
    bp_path: Path,
    global_dsect_offsets: Dict[str, Dict[str, Tuple[int, int]]],
    field_to_dsect: Dict[str, List[Tuple[str, int, int]]],
) -> Tuple[int, int, int, int, int]:
    """Enrich a single ASM blueprint with all identity layers.

    Returns ``(total_edges, dsect_edges, new_ai, l2b_upgraded, l4_labeled)``.

    - ``new_ai``:       edges that received ``access_identity`` (L1)
    - ``l2b_upgraded``: plain labels upgraded to ``symbolic_identity`` (L2b)
    - ``l4_labeled``:   local labels that received ``file_label`` (L4)
    """
    try:
        # Load only the fields needed for enrichment — skipping blocks,
        # subroutines, call_graph, and other large sections that _enrich_blueprint
        # never reads.  For a large ASM blueprint this reduces the in-memory
        # footprint from ~20–50 MB (full blueprint) to ~2–8 MB.
        bp = load_blueprint(
            bp_path,
            skip_global_lineage=True,
            keys={"line_metadata", "variable_lineage"},
        )
    except Exception as exc:
        logger.warning("Cannot load %s: %s", bp_path, exc)
        return 0, 0, 0, 0, 0

    line_metadata: Dict[str, Any] = bp.get("line_metadata") or {}

    # Build CE-slot mapping from this file's snapshots
    dsect_to_ce_slot = _build_dsect_to_ce_slot(line_metadata)

    # Sorted list of snapshot line-numbers for bisect lookup
    snap_lines = sorted(
        int(k) for k in line_metadata if (line_metadata[k].get("active_usings"))
    )

    edges: List[Dict[str, Any]] = (
        bp.get("variable_lineage", {}).get("edges") or []
    )

    total_edges = len(edges)
    dsect_edges = 0
    newly_enriched = 0
    changed = False

    # ── Pass 1: L1 access_identity + L2 symbolic_identity for DSECT edges ────
    for edge in edges:
        if not edge.get("dsect"):
            continue
        dsect_edges += 1

        dsect: str = edge["dsect"]

        # L2: set symbolic_identity from field name in node_id (if not already set)
        if not edge.get("symbolic_identity"):
            for nid in (edge.get("source") or "", edge.get("target") or ""):
                sym = _symbolic_name_from_node(nid, dsect)
                if not sym:
                    # Fallback: node_id is a plain label (e.g. "memory:TOT_LEN") but
                    # the edge already carries dsect=RESPONSE. If the plain label
                    # exists as a field in that DSECT layout, derive L2 directly.
                    plain = _extract_plain_label(nid)
                    if plain:
                        dsect_fields = global_dsect_offsets.get(dsect, {})
                        upper = plain.upper()
                        for fname in dsect_fields:
                            if fname.upper() == upper:
                                sym = upper
                                break
                if sym:
                    edge["symbolic_identity"] = f"{dsect}:{sym}"
                    changed = True
                    break

        if edge.get("access_identity"):
            continue  # L1 already set

        # ---- resolve field_offset ----------------------------------------
        field_offset: Optional[int] = edge.get("field_offset")

        if field_offset is None:
            for node_id in (edge.get("source") or "", edge.get("target") or ""):
                off = _field_offset_from_node(node_id, dsect, global_dsect_offsets)
                if off is not None:
                    field_offset = off
                    break

        if field_offset is None:
            continue  # cannot compute access_identity without offset

        # ---- resolve ce_slot ---------------------------------------------
        ce_slot: Optional[str] = edge.get("ce_slot")

        if not ce_slot:
            ce_slot = dsect_to_ce_slot.get(dsect)

        if not ce_slot:
            snap = _nearest_snapshot(snap_lines, line_metadata, edge.get("line") or 0)
            if snap:
                active_usings: Dict[str, str] = snap.get("active_usings") or {}
                snap_ce_slots: Dict[str, str] = snap.get("register_ce_slots") or {}
                for reg, snap_dsect in active_usings.items():
                    if snap_dsect == dsect and reg in snap_ce_slots:
                        ce_slot = snap_ce_slots[reg]
                        break

        if not ce_slot:
            continue  # no CE-slot traceable → not an ECB-resident DSECT

        # ---- write back L1 -----------------------------------------------
        edge["field_offset"] = field_offset
        edge["ce_slot"] = ce_slot
        edge["access_identity"] = f"{ce_slot}:{field_offset}"
        newly_enriched += 1
        changed = True

    # ── Pass 2: L2b label-upgrade and L4 file_label ───────────────────────────
    # bp_path.stem is e.g. "da76.asm" for "da76.asm.json"; strip the ".asm" part.
    bp_stem = bp_path.stem
    for ext in (".asm", ".cpp"):
        if bp_stem.endswith(ext):
            bp_stem = bp_stem[: -len(ext)]
            break

    l2b_upgraded = 0
    l4_labeled = 0

    for edge in edges:
        # Skip edges that already have all identity resolved
        if edge.get("symbolic_identity") or edge.get("access_identity") or edge.get("file_label"):
            continue
        # DSECT edges that still have no symbolic_identity after Pass 1 get L4 fallback
        # (local DSECTs with no CE-slot or non-DSECT-qualified node_ids that Pass 1 missed).
        # Non-DSECT edges go through the normal L2b / L4 path below.

        # Try to extract a plain label from source or target node_id
        label: Optional[str] = None
        for nid in (edge.get("source") or "", edge.get("target") or ""):
            lbl = _extract_plain_label(nid)
            if lbl:
                label = lbl
                break

        if label is None:
            continue

        matches = field_to_dsect.get(label.upper(), [])
        if len(matches) == 1:
            # L2b: unique match — upgrade plain label to DSECT:FIELD identity
            dsect_name, off, _ = matches[0]
            edge["dsect"] = dsect_name
            edge["field_offset"] = off
            edge["symbolic_identity"] = f"{dsect_name}:{label.upper()}"
            # Also try to promote to L1 if a CE-slot is traceable
            ce: Optional[str] = dsect_to_ce_slot.get(dsect_name)
            if not ce:
                snap = _nearest_snapshot(snap_lines, line_metadata, edge.get("line") or 0)
                if snap:
                    au: Dict[str, str] = snap.get("active_usings") or {}
                    cs: Dict[str, str] = snap.get("register_ce_slots") or {}
                    for reg, sd in au.items():
                        if sd.upper() == dsect_name.upper() and reg in cs:
                            ce = cs[reg]
                            break
            if ce:
                edge["ce_slot"] = ce
                edge["access_identity"] = f"{ce}:{off}"
            changed = True
            l2b_upgraded += 1

        elif not matches:
            # L4: no DSECT match anywhere — truly file-local label
            edge["file_label"] = f"{bp_stem}:{label}"
            changed = True
            l4_labeled += 1
        # len(matches) > 1: ambiguous — leave without identity
        # (L2c = 0 proven on real codebase; guard here for edge cases)

    if changed:
        # Reload the full blueprint so we only update variable_lineage.edges
        # while preserving blocks, call_graph, coverage_review, and all other
        # sections that were intentionally skipped in the initial filtered load.
        try:
            full_bp = load_blueprint(bp_path, skip_global_lineage=True)
        except Exception as exc:
            logger.warning("Cannot reload full %s for write-back: %s", bp_path, exc)
            full_bp = bp  # fallback: write what we have (avoids silent data loss)
        if full_bp is not bp:
            vl = full_bp.get("variable_lineage")
            if isinstance(vl, dict):
                vl["edges"] = edges
            else:
                full_bp["variable_lineage"] = bp.get("variable_lineage", {})
        write_blueprint(bp_path, full_bp)
        logger.debug(
            "%s: L1=%d, L2b=%d, L4=%d",
            bp_path.name, newly_enriched, l2b_upgraded, l4_labeled,
        )

    return total_edges, dsect_edges, newly_enriched, l2b_upgraded, l4_labeled
