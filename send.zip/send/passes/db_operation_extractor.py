"""Pass 5: DB Operation Extractor.

Extracts z/TPFDF database operations from assembly code.
"""

from typing import List, Optional
import re
from tokenizer import ParsedLine
from models.analysis_context import AnalysisContext
from models.db_operation import DBOperation, DBOperationCatalog, DBOperationType
from macro_classifier import MacroClassifier


class DBOperationExtractorPass:
    """Pass 5: Extract database operations from assembly code.

    Identifies z/TPFDF macros (DBRED, DBWRT, etc.) and extracts:
    - Operation type (read/write/update/delete)
    - Target file/record
    - Key operands
    - Access mode
    - Source location
    """

    def __init__(self):
        self.macro_classifier = MacroClassifier()
        self.catalog = DBOperationCatalog()
        self.current_routine: Optional[str] = None
        self.current_section: Optional[str] = None

    def process(self, lines: List[ParsedLine], context: AnalysisContext):
        """Process all lines and extract database operations.

        Args:
            lines: Parsed assembly lines
            context: Shared analysis context
        """
        for line in lines:
            # Track current routine/section
            if line.label and line.opcode:
                opcode_upper = line.opcode.upper()
                if opcode_upper in ("CSECT", "ENTRY"):
                    self.current_routine = line.label
                    self.current_section = line.label

            # Check if this is a DB macro
            if line.opcode and self.macro_classifier.is_db_macro(line.opcode):
                self._extract_operation(line)

        # Store catalog in context
        context.add_metadata("db_operation_catalog", self.catalog)

    def _extract_operation(self, line: ParsedLine):
        """Extract database operation from a DB macro line.

        Args:
            line: Parsed line containing DB macro
        """
        # Classify the macro
        classification = self.macro_classifier.classify(line.opcode)
        if not classification:
            return

        # Extract file/record identifier from operands
        file_record = self._extract_file_record(line.operands)

        # Extract key operands
        key_operands = self._extract_keys(line.operands)

        # Extract access mode
        access_mode = self._extract_access_mode(line.operands)

        # Determine confidence
        confidence = self._determine_confidence(file_record, key_operands)

        # Create operation
        operation = DBOperation(
            operation_type=classification["operation_type"],
            macro_name=classification["macro_name"],
            calling_routine=self.current_routine or "UNKNOWN",
            file_record_identifier=file_record,
            key_operands=key_operands,
            access_mode=access_mode,
            source_file=line.provenance.original_file,
            source_line=line.provenance.original_line,
            source_section=self.current_section,
            confidence=confidence
        )

        self.catalog.add_operation(operation)

    def _extract_file_record(self, operands: List[str]) -> Optional[str]:
        """Extract file/record identifier from operands.

        Args:
            operands: Macro operands

        Returns:
            File/record identifier or None
        """
        if not operands:
            return None

        # Look for FILE=, REC=, or REF= operand (REF= is used by DBOPN/DBRED/etc.)
        for operand in operands:
            if "=" in operand:
                key, value = operand.split("=", 1)
                if key.upper() in ("FILE", "REC", "RECORD", "REF"):
                    return value

        # Positional fallback: first non-keyword, non-mode-flag operand.
        _MODE_FLAGS = {"HOLD", "EXCL", "R", "W", "U", "D", "SHARE"}
        for operand in operands:
            if "=" not in operand and operand.upper() not in _MODE_FLAGS:
                return operand

        return None

    def _extract_keys(self, operands: List[str]) -> List[str]:
        """Extract key operands.

        Args:
            operands: Macro operands

        Returns:
            List of key identifiers
        """
        keys = []
        if not operands:
            return keys

        for operand in operands:
            if "=" in operand:
                key, value = operand.split("=", 1)
                if key.upper() in ("KEY", "KEYS", "ALG", "ALGKEY"):
                    keys.append(value)

        # Positional fallback: second non-keyword, non-mode-flag operand is the key.
        if not keys:
            _MODE_FLAGS = {"HOLD", "EXCL", "R", "W", "U", "D", "SHARE"}
            non_kw = [op for op in operands if "=" not in op and op.upper() not in _MODE_FLAGS]
            if len(non_kw) >= 2:
                keys.append(non_kw[1])

        return keys

    def _extract_access_mode(self, operands: List[str]) -> Optional[str]:
        """Extract access mode from operands.

        Access modes:
        - "keyed": Access using a key (most common for DBRED, DBWRT, etc.)
        - "sequential": Sequential access through records
        - "direct": Direct access by RBA (Relative Byte Address)
        - "random": Random access pattern
        - "control": Control/setup operations (FILEC, FILET, etc.)

        Args:
            operands: Macro operands

        Returns:
            Access mode or None
        """
        if not operands:
            return None

        # Check for specific patterns in operands
        operands_upper = [op.upper() for op in operands]
        operands_str = " ".join(operands_upper)

        # Check for RBA (Relative Byte Address) - indicates direct access
        if "RBA" in operands_str or "=RBA" in operands_str:
            return "direct"

        # Check for sequential access indicators
        if "SEQ" in operands_str or "SEQUENTIAL" in operands_str:
            return "sequential"

        # Check for key-based access (most common)
        # If there are 2+ operands and second operand looks like a key
        if len(operands) >= 2:
            second_operand = operands[1].upper()
            # Common key patterns: KEY, xxxKEY, KEYxxx, or register-based keys
            if "KEY" in second_operand or second_operand.startswith("R"):
                return "keyed"

        # Default to keyed for most database macros
        # This is the most common access mode in z/TPFDF
        return "keyed"

    def _determine_confidence(self, file_record: Optional[str],
                             key_operands: List[str]) -> str:
        """Determine confidence level for extracted operation.

        Args:
            file_record: Extracted file/record identifier
            key_operands: Extracted key operands

        Returns:
            Confidence level: "high", "medium", or "low"
        """
        if file_record and key_operands:
            return "high"
        if file_record:
            # Record identified but no key operand parsed (e.g. positional-only)
            return "medium"
        if key_operands:
            # Key operand found (e.g. ALG=WK_ACCTP) but REF=/FILE= absent
            return "medium"
        return "low"
