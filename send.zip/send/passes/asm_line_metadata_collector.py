"""Collects line metadata during ASM parsing."""

from typing import List, Optional, Tuple
from models.line_metadata import (
    LineMetadata,
    CodeblockContext,
    ConditionalContext,
    CallContext
)


class ASMLineMetadataCollector:
    """Collects line metadata during ASM parsing."""

    def __init__(self):
        self.metadata_list: List[LineMetadata] = []
        self.current_section: Optional[str] = None
        self.current_routine: Optional[str] = None
        self.conditional_stack: List[Tuple[str, str]] = []  # [(condition_expr, type)]

    def enter_section(self, section_name: str, line: int):
        """Called when parser enters CSECT/DSECT/RSECT.

        Args:
            section_name: Name of the section
            line: Line number where section starts
        """
        self.current_section = section_name
        self.current_routine = None  # Reset routine when entering new section

    def exit_section(self, line: int):
        """Called when parser exits a section.

        Args:
            line: Line number where section ends
        """
        self.current_section = None
        self.current_routine = None

    def enter_routine(self, routine_name: str, line: int):
        """Called when parser encounters a label that starts a routine.

        Args:
            routine_name: Name of the routine/label
            line: Line number where routine starts
        """
        self.current_routine = routine_name

    def push_condition(self, condition_expr: str, condition_type: str, line: int):
        """Called when parser encounters BC, AIF, or conditional directive.

        Args:
            condition_expr: The condition expression (e.g., "&DEBUG EQ 1")
            condition_type: Type of conditional ("BC", "AIF", "AGO")
            line: Line number of the conditional
        """
        self.conditional_stack.append((condition_expr, condition_type))

    def pop_condition(self, line: int):
        """Called when conditional scope ends.

        Args:
            line: Line number where conditional ends
        """
        if self.conditional_stack:
            self.conditional_stack.pop()

    def set_conditions(self, conditions: List[Tuple[str, str]]):
        """Replace active conditional stack from external flow tracker.

        Args:
            conditions: Ordered stack entries as (condition_expr, type)
        """
        self.conditional_stack = list(conditions)

    def record_line(self, file: str, line: int):
        """Record metadata for current line (skips comments).

        Args:
            file: Source file path
            line: Line number to record
        """
        codeblock = CodeblockContext(
            enclosing_function=None,
            enclosing_section=self.current_section,
            enclosing_routine=self.current_routine,
            in_executable_block=self.current_section is not None
        )

        conditional = ConditionalContext(
            is_conditional=len(self.conditional_stack) > 0,
            depth=len(self.conditional_stack),
            active_conditions=[expr for expr, _ in self.conditional_stack],
            condition_types=[ctype for _, ctype in self.conditional_stack]
        )

        # Calls will be empty initially, filled in enrichment phase
        calls = CallContext(
            calls_functions=[],
            calls_routines=[],
            invokes_macros=[]
        )

        metadata = LineMetadata(
            file=file,
            line_number=line,
            codeblock=codeblock,
            conditional=conditional,
            calls=calls,
            is_comment=False
        )
        self.metadata_list.append(metadata)
