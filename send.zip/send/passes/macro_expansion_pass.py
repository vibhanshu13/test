"""Macro expansion pass - expands all macro invocations in analysis context."""

import logging
import time
from typing import List
from macro_library import MacroLibrary
from macro_expander import MacroExpander
from models.analysis_context import AnalysisContext
from models.macro_expansion import ExpansionResult, ExpansionError

_log = logging.getLogger(__name__)


class MacroExpansionPass:
    """Pass 2.75: Expand all macro invocations in the analysis context.

    Identifies macro invocations in statements and expands them with
    full conditional assembly processing.
    """

    def __init__(self, macro_library: MacroLibrary):
        """Initialize the macro expansion pass.

        Args:
            macro_library: Library of macro definitions
        """
        self.macro_library = macro_library
        self.expander = MacroExpander(macro_library)

    def identify_macro_invocations(self, context: AnalysisContext) -> List:
        """Identify which statements are macro invocations.

        Args:
            context: Analysis context with statements

        Returns:
            List of statements that are macro invocations
        """
        invocations = []

        for statement in context.statements:
            # Check if opcode matches a known macro
            if self.macro_library.has_macro(statement.opcode):
                invocations.append(statement)

        return invocations

    def expand_all(self, context: AnalysisContext) -> List[ExpansionResult]:
        """Expand all macro invocations in the context.

        Args:
            context: Analysis context

        Returns:
            List of ExpansionResult objects
        """
        _t0 = time.perf_counter()
        _log.debug("MacroExpansionPass.expand_all start: %s", context.file_path)
        results = []

        invocations = self.identify_macro_invocations(context)

        for statement in invocations:
            macro_def = self.macro_library.get_macro(statement.opcode)

            if macro_def:
                # Build invocation string
                if statement.label:
                    if statement.operands:
                        invocation = f"{statement.label}  {statement.opcode} {statement.operands}"
                    else:
                        invocation = f"{statement.label}  {statement.opcode}"
                else:
                    invocation = f"{statement.opcode} {statement.operands}".strip()

                # Expand
                result = self.expander.expand(
                    invocation,
                    macro_def,
                    str(context.file_path),
                    statement.line_num
                )
                results.append(result)
            else:
                # No definition - create error result
                error_result = ExpansionResult(
                    expansion_id=f"error_{statement.line_num}",
                    invocation=f"{statement.opcode} {statement.operands}",
                    invocation_file=str(context.file_path),
                    invocation_line=statement.line_num,
                    macro_name=statement.opcode,
                    definition_file="",
                    definition_line_start=0,
                    definition_line_end=0,
                    expansion_status="no_definition",
                    parameters={},
                    expanded_instructions=[],
                    error=ExpansionError(
                        macro_name=statement.opcode,
                        error_type="not_found",
                        message=f"Macro '{statement.opcode}' not found",
                        location_file=str(context.file_path),
                        location_line=statement.line_num
                    )
                )
                results.append(error_result)

        _log.debug(
            "MacroExpansionPass.expand_all done in %.3fs (%d expansions): %s",
            time.perf_counter() - _t0,
            len(results),
            context.file_path,
        )
        return results

    def update_context(
        self,
        context: AnalysisContext,
        results: List[ExpansionResult]
    ):
        """Update analysis context with expansion results.

        Args:
            context: Analysis context to update
            results: Expansion results to add
        """
        # Add macro_expansions attribute if not present
        if not hasattr(context, 'macro_expansions'):
            context.macro_expansions = []

        context.macro_expansions.extend(results)
