"""Collects line metadata during C/C++ parsing."""

from typing import List, Optional, Tuple
from models.line_metadata import (
    LineMetadata,
    CodeblockContext,
    ConditionalContext,
    CallContext
)


class CLineMetadataCollector:
    """Collects line metadata during C/C++ parsing."""

    def __init__(self):
        self.metadata_list: List[LineMetadata] = []
        self.current_function: Optional[str] = None
        self.conditional_stack: List[Tuple[str, str]] = []  # [(condition_expr, type)]

    def enter_function(self, function_name: str, start_line: int, end_line: int):
        """Called when parser enters function definition.

        Args:
            function_name: Name of the function
            start_line: Starting line number
            end_line: Ending line number
        """
        self.current_function = function_name

    def exit_function(self):
        """Called when parser exits function."""
        self.current_function = None

    def push_condition(self, condition_expr: str, condition_type: str):
        """Called for if/while/for/switch statements.

        Args:
            condition_expr: The condition expression (e.g., "x > 0")
            condition_type: Type of conditional ("if", "while", "for", "switch")
        """
        self.conditional_stack.append((condition_expr, condition_type))

    def pop_condition(self):
        """Called when conditional block ends."""
        if self.conditional_stack:
            self.conditional_stack.pop()

    def record_line(self, file: str, line: int):
        """Record metadata for current line.

        Args:
            file: Source file path
            line: Line number to record
        """
        codeblock = CodeblockContext(
            enclosing_function=self.current_function,
            enclosing_section=None,
            enclosing_routine=None,
            in_executable_block=self.current_function is not None
        )

        conditional = ConditionalContext(
            is_conditional=len(self.conditional_stack) > 0,
            depth=len(self.conditional_stack),
            active_conditions=[expr for expr, _ in self.conditional_stack],
            condition_types=[ctype for _, ctype in self.conditional_stack]
        )

        calls = CallContext(
            calls_functions=[],
            calls_routines=[],
            invokes_macros=[]
        )

        metadata = LineMetadata(
            file=file,
            line_number=line,
            codeblock=codeblock,
            conditional=conditional,
            calls=calls,
            is_comment=False
        )
        self.metadata_list.append(metadata)

    def record_span(self, file: str, start_line: int, end_line: int):
        """Record metadata for an inclusive source line span."""
        if start_line <= 0 or end_line <= 0:
            return
        lo = min(start_line, end_line)
        hi = max(start_line, end_line)
        for line in range(lo, hi + 1):
            self.record_line(file, line)
