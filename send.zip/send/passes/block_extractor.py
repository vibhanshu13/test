"""Pass 7: Block and Subroutine Extractor.

Classifies all labeled routines in the file as either 'subroutines'
(reached by SUBROUTINE_CALL edges) or 'blocks' (reached only by branches
or never reached from the call graph). Builds flow lists and cross-reference
metadata for each.
"""

from collections import defaultdict
import re
from pathlib import Path
from typing import Dict, List, Optional, Set

from models.analysis_context import AnalysisContext
from models.block_analysis import BlockAnalysisResult, BlockInfo, BranchRef, FlowItem, SubroutineInfo
from models.call_graph import CallGraph, CallType
from models.symbol import SymbolType
from tokenizer import ParsedLine


# MVC-family: emit {var, val} instead of {args}
_MVC_OPCODES: Set[str] = {"MVC", "MVCL", "MVI", "MOVEX"}

# Pure assembler directives: skip from flow entirely
_SKIP_OPCODES: Set[str] = {
    "CSECT", "DSECT", "RSECT",
    "EQU", "DC", "DS",
    "USING", "DROP",
    "LTORG", "END",
    "MACRO", "MEND",
    "COPY",
    "ENTRY", "EXTRN", "WXTRN",
    "EJECT", "SPACE", "TITLE", "PUSH", "POP",
}

# Opcodes that unconditionally transfer control (no sequential fall-through).
# B  = BC 15 (always branch); BR = branch-to-register; BACKC = z/TPF return to C++.
# ENTNC = TPF non-returning tail-call to another segment (control never comes back).
_UNCONDITIONAL_OPCODES: Set[str] = {"B", "BR", "J", "BACKC", "ENTNC", "EXITC"}


class BlockExtractorPass:
    """Pass 7: Classify routines into blocks/subroutines and build flow lists."""

    def process(self, lines: List[ParsedLine], context: AnalysisContext) -> None:
        """Extract blocks and subroutines from parsed lines.

        Args:
            lines: Parsed assembly lines (with provenance.routine already set)
            context: Shared analysis context (call_graph must already be stored)
        """
        call_graph: Optional[CallGraph] = context.get_metadata("call_graph")
        result = BlockAnalysisResult()

        # ------------------------------------------------------------------
        # Step 1: Collect the set of routine names that are subroutine targets
        # ------------------------------------------------------------------
        subroutine_targets: Set[str] = set()
        if call_graph:
            for edge in call_graph.edges:
                if edge.call_type == CallType.SUBROUTINE_CALL and edge.target:
                    subroutine_targets.add(edge.target)

        # ------------------------------------------------------------------
        # Step 2: Build set of DSECT section names — these are data layouts,
        # not executable code, and must be excluded from blocks/subroutines.
        # ------------------------------------------------------------------
        dsect_sections: Set[str] = set()
        for symbol in context.symbol_table.all_symbols:
            if symbol.symbol_type == SymbolType.DSECT and symbol.name:
                dsect_sections.add(symbol.name)

        # ------------------------------------------------------------------
        # Step 3: Group parsed lines by provenance.routine
        # Skip: pre-CSECT preamble (section is None), macro definition bodies
        # from COPY-included files (section is None before first CSECT), and
        # any lines belonging to DSECT sections (data layouts, not code).
        # ------------------------------------------------------------------
        routine_lines: Dict[str, List[ParsedLine]] = defaultdict(list)
        for line in lines:
            section = line.provenance.section
            if section is None:
                # Lines before any CSECT/EQU* label.  Pure directives and macro
                # definition bodies (MACRO/MEND) are genuine preamble and should
                # be skipped.  Executable instructions here are the unlabeled
                # mainline prologue (files with no explicit CSECT declaration);
                # assign them to a synthetic entry block named after the file so
                # their control-flow edges can be resolved.
                if not line.opcode or line.opcode.upper() in _SKIP_OPCODES:
                    continue
                section = Path(line.provenance.original_file).stem.upper()
            if section in dsect_sections:
                continue  # data layout section, not executable code
            routine = line.provenance.routine
            if routine is None:
                # Pre-label entry code (before first labeled block in this CSECT).
                # Assign to an implicit entry block named after the section so that
                # instructions like ENTNC at the top of a segment are captured.
                routine = section
            routine_lines[routine].append(line)

        # ------------------------------------------------------------------
        # Step 3b: Build alias map for co-located labels (consecutive EQU *).
        # When multiple labels share the same address, only the first becomes
        # the routine/block ID.  Branches targeting a folded alias label need
        # to be resolved to the canonical block ID.
        # ------------------------------------------------------------------
        alias_map: Dict[str, str] = {}
        for routine_id, rlines in routine_lines.items():
            for line in rlines:
                if line.label and line.label != routine_id:
                    alias_map[line.label] = routine_id

        # Resolve any alias labels in subroutine_targets to canonical IDs.
        subroutine_targets = {alias_map.get(t, t) for t in subroutine_targets}

        # ------------------------------------------------------------------
        # Step 4: Build incoming_branches and called_by indexes from call_graph
        # ------------------------------------------------------------------
        branch_sources: Dict[str, Set[str]] = defaultdict(set)
        call_sources: Dict[str, Set[str]] = defaultdict(set)

        if call_graph:
            for edge in call_graph.edges:
                if edge.target is None:
                    continue
                # Resolve alias labels to canonical block/routine IDs
                target = alias_map.get(edge.target, edge.target)
                source = alias_map.get(edge.source, edge.source)
                if edge.call_type == CallType.BRANCH:
                    branch_sources[target].add(source)
                elif edge.call_type == CallType.SUBROUTINE_CALL:
                    call_sources[target].add(source)

        # Promote any block ending with a real return (BR Rn / BACKC) that also
        # has at least one confirmed BAS/BAL caller not already captured above.
        _detect_implicit_subroutines(routine_lines, subroutine_targets, call_sources=call_sources)

        # ------------------------------------------------------------------
        # Step 4b: Detect implicit fall-through edges.
        # A block that does not end with an unconditional transfer implicitly
        # passes control to the next block in source order.
        # ------------------------------------------------------------------
        fallthrough_sources: Dict[str, Set[str]] = defaultdict(set)
        ordered_ids = sorted(
            routine_lines.keys(),
            key=lambda rid: min(l.provenance.original_line for l in routine_lines[rid]),
        )
        for i in range(len(ordered_ids) - 1):
            src_id = ordered_ids[i]
            tgt_id = ordered_ids[i + 1]
            last_op, last_operands = _last_opcode_and_operands(routine_lines[src_id])
            if not _is_terminal_opcode(last_op, last_operands):
                fallthrough_sources[tgt_id].add(src_id)

        # ------------------------------------------------------------------
        # Step 5: For each routine group, build FlowItems and classify
        # ------------------------------------------------------------------
        for routine_id, rlines in routine_lines.items():
            flow_items = _build_flow(rlines)
            all_line_nums = [l.provenance.original_line for l in rlines]
            start_line = min(all_line_nums)
            end_line = max(all_line_nums)

            incoming = [
                BranchRef(source=src, edge_type="BRANCH")
                for src in sorted(branch_sources.get(routine_id, set()))
            ]
            incoming += [
                BranchRef(source=src, edge_type="FALLTHROUGH")
                for src in sorted(fallthrough_sources.get(routine_id, set()))
            ]
            incoming += [
                BranchRef(source=src, edge_type="SUBROUTINE_CALL")
                for src in sorted(call_sources.get(routine_id, set()))
            ]

            block = BlockInfo(
                id=routine_id,
                start_line=start_line,
                end_line=end_line,
                flow=flow_items,
                incoming_branches=incoming,
            )
            result.blocks.append(block)

            if routine_id in subroutine_targets:
                sub = SubroutineInfo(
                    id=routine_id,
                    start_line=start_line,
                    end_line=end_line,
                    called_by=sorted(call_sources.get(routine_id, set())),
                )
                result.subroutines.append(sub)

        # ------------------------------------------------------------------
        # Step 6: Stable ordering by first appearance in source
        # ------------------------------------------------------------------
        def _first_line(routine_id: str) -> int:
            rlines = routine_lines.get(routine_id, [])
            if not rlines:
                return 0
            return min(l.provenance.original_line for l in rlines)

        result.blocks.sort(key=lambda b: _first_line(b.id))
        result.subroutines.sort(key=lambda s: s.start_line)

        context.add_metadata("block_analysis", result)


def _build_flow(lines: List[ParsedLine]) -> List[FlowItem]:
    """Convert a routine's parsed lines into FlowItem objects.

    Args:
        lines: All parsed lines belonging to one routine, in source order

    Returns:
        List of FlowItem objects (directives excluded)
    """
    items: List[FlowItem] = []
    for line in lines:
        opcode = (line.opcode or "").upper()
        if not opcode:
            continue
        # Skip macro parameter/prototype lines (e.g. "&ACCTID,&OLDBAL,...")
        if opcode.startswith("&"):
            continue
        # Skip continuation fragments that were tokenized as pseudo-opcodes.
        if "=" in opcode or opcode.endswith(",") or opcode.startswith("("):
            continue
        if opcode in _SKIP_OPCODES:
            continue

        line_num = line.provenance.original_line
        operands = line.operands  # already split, trimmed, nesting-aware

        if opcode == "BR" and operands and re.fullmatch(r"R(?:1[0-5]|[0-9])", operands[0].strip().upper()):
            continue

        if opcode in _MVC_OPCODES:
            var = operands[0] if len(operands) > 0 else ""
            val = operands[1] if len(operands) > 1 else ""
            items.append(FlowItem(line=line_num, inst=line.opcode, var=var, val=val))
        else:
            items.append(FlowItem(line=line_num, inst=line.opcode, args=list(operands)))

    return items


def _last_opcode_and_operands(rlines: List[ParsedLine]):
    """Return (opcode_upper, operands) of the last non-directive instruction in rlines."""
    for line in reversed(rlines):
        opcode = (line.opcode or "").upper()
        if not opcode:
            continue
        if opcode.startswith("&") or "=" in opcode or opcode.endswith(",") or opcode.startswith("("):
            continue
        if opcode in _SKIP_OPCODES:
            continue
        return opcode, list(line.operands or [])
    return "", []


def _is_terminal_opcode(opcode: str, operands: List[str]) -> bool:
    """Return True if opcode unconditionally transfers control (no fall-through possible)."""
    if not opcode:
        return False
    if opcode in _UNCONDITIONAL_OPCODES:
        return True
    # BC 15,... and BCR 15,... are always-taken branches
    if opcode in ("BC", "BCR") and operands and operands[0].strip() == "15":
        return True
    # SERRC E aborts the transaction (segment death); SERRC R returns to the OS/caller.
    # Neither falls through to the next sequential instruction.
    if opcode == "SERRC" and operands and operands[0].strip().upper() in ("E", "R"):
        return True
    return False


def _detect_implicit_subroutines(
    routine_lines: Dict[str, List[ParsedLine]],
    subroutine_targets: Set[str],
    call_sources: Optional[Dict[str, Set[str]]],
) -> None:
    """Promote routines with confirmed BAS/BAL callers that end with a real return.

    A block is only added to subroutine_targets when:
      1. It has at least one confirmed SUBROUTINE_CALL (BAS/BAL) edge in call_sources.
      2. It ends with BR Rn or BACKC.

    Blocks reached only via branch instructions (B, BNE, BO, macro-generated) are
    NOT subroutines even if they end with BR R14.
    """
    for routine_id, rlines in routine_lines.items():
        if routine_id in subroutine_targets:
            continue
        # Require at least one confirmed BAS/BAL caller.
        if not call_sources or not call_sources.get(routine_id):
            continue
        for line in rlines:
            opcode = (line.opcode or "").upper()
            operands = line.operands or []
            if opcode == "BACKC":
                subroutine_targets.add(routine_id)
                break
            if opcode == "BR" and operands and re.fullmatch(r"R(?:1[0-5]|[0-9])", operands[0].strip().upper()):
                subroutine_targets.add(routine_id)
                break
