"""Post-processes LineMetadata to add call information from CallGraph."""

from typing import Dict, List
from models.call_graph import CallGraph, CallType
from models.line_metadata import LineMetadataIndex, CallContext


class LineMetadataEnricher:
    """Post-processes LineMetadata to add call information from CallGraph."""

    def __init__(self, call_graph: CallGraph, line_metadata_index: LineMetadataIndex):
        """Initialize enricher.

        Args:
            call_graph: CallGraph built during parsing
            line_metadata_index: LineMetadataIndex to enrich
        """
        self.call_graph = call_graph
        self.index = line_metadata_index

    def enrich_all(self):
        """Populate call information for all tracked lines."""
        # Build function/routine → calls mapping from CallGraph
        codeblock_calls = self._build_codeblock_call_map()

        # Enrich each LineMetadata entry
        for metadata in self.index._index.values():
            # Try to find calls for the most specific enclosing context
            # Priority: function > routine > section
            # Fall back to section if routine/function not found in CallGraph
            enclosing = None
            if metadata.codeblock.enclosing_function:
                enclosing = metadata.codeblock.enclosing_function
            elif metadata.codeblock.enclosing_routine:
                # Try routine first
                if metadata.codeblock.enclosing_routine in codeblock_calls:
                    enclosing = metadata.codeblock.enclosing_routine
                # Fall back to section if routine not in CallGraph
                elif metadata.codeblock.enclosing_section:
                    enclosing = metadata.codeblock.enclosing_section
            elif metadata.codeblock.enclosing_section:
                enclosing = metadata.codeblock.enclosing_section

            if enclosing and enclosing in codeblock_calls:
                calls_info = codeblock_calls[enclosing]
                metadata.calls = CallContext(
                    calls_functions=calls_info['functions'],
                    calls_routines=calls_info['routines'],
                    invokes_macros=calls_info['macros']
                )

    def _build_codeblock_call_map(self) -> Dict[str, Dict[str, List[str]]]:
        """Extract call information from CallGraph.

        Returns:
            Dict mapping codeblock name → {functions: [...], routines: [...], macros: [...]}
        """
        codeblock_calls = {}

        for edge in self.call_graph.edges:
            source = edge.source
            target = edge.target

            if not target:  # Skip indirect calls with no target
                continue

            # Initialize if needed
            if source not in codeblock_calls:
                codeblock_calls[source] = {
                    'functions': [],
                    'routines': [],
                    'macros': []
                }

            # Classify call type
            if edge.call_type == CallType.CALL:
                # C/C++ function call
                if target not in codeblock_calls[source]['functions']:
                    codeblock_calls[source]['functions'].append(target)

            elif edge.call_type == CallType.MACRO_INVOCATION:
                # Macro invocation
                if target not in codeblock_calls[source]['macros']:
                    codeblock_calls[source]['macros'].append(target)

            elif edge.call_type in (
                CallType.SUBROUTINE_CALL,
                CallType.NO_RETURN_CALL,
                CallType.ASYNC_SPAWN,
                CallType.BRANCH,
            ):
                # ASM routine/label call
                if target not in codeblock_calls[source]['routines']:
                    codeblock_calls[source]['routines'].append(target)

        return codeblock_calls
