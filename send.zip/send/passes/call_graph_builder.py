"""Pass 3: Call Graph Builder.

Identifies control flow and builds call graph.
"""

import logging
import re
import time
from pathlib import Path
from typing import List, Optional, Dict, Any

_log = logging.getLogger(__name__)
from models.analysis_context import AnalysisContext
from tokenizer import ParsedLine
from instruction_classifier import InstructionClassifier, ControlFlowType
from models.call_graph import CallGraph, CallType
from macro_classifier import MacroClassifier
from external_call_identifier import ExternalCallIdentifier
from models.macro_expansion import ExpansionResult
from asm_scope import ScopeState, apply_scope_transition


class CallGraphBuilderPass:
    """Pass 3: Build call graph from control flow instructions.

    Identifies:
    - Subroutine calls (BAL, BALR, BAS, BASR, BRAS, BRASL)
    - Mode transitions (BASSM, BASM, BSM)
    - Branches (B*, BC, BCR, etc.)
    - Returns (BR R14)
    - Execute instructions (EX)
    - Macro invocations (z/TPF and z/TPFDF)
    - External calls (C functions, OS services)

    Flags indirect calls for data flow refinement.
    """

    # Opcodes that are assembler directives / declarations, not macro calls.
    # Lines with these opcodes are never treated as custom macro invocations.
    _DIRECTIVE_OPCODES: frozenset = frozenset({
        "EQU", "DC", "DS", "CSECT", "DSECT", "RSECT", "ENTRY", "EXTRN", "WXTRN",
        "USING", "DROP", "LTORG", "END", "MACRO", "MEND", "COPY",
        "EJECT", "SPACE", "TITLE", "PUSH", "POP", "ORG", "COM",
        "START", "AMODE", "RMODE", "ALIAS", "CATTR", "XATTR",
        "PRINT", "PUNCH", "REPRO", "ICTL", "ISEQ",
        # Structured programming macro-directives (not real macro calls)
        "DO", "DOEXIT", "DOIF", "ELSE", "ELSEIF", "ENDIF", "ENDDO",
        "SELECT", "WHEN", "OTHERWISE", "ENDSELECT",
        # Conditional assembly directives
        "AIF", "AGO", "ANOP", "ACTR", "SETA", "SETB", "SETC", "LCLA", "LCLB",
        "LCLC", "GBLA", "GBLB", "GBLC",
    })

    # IBM System z/Architecture machine instruction mnemonics that the
    # InstructionClassifier does not cover (it only tracks control flow).
    # These must not be misclassified as custom macro invocations.
    _MACHINE_INSTRUCTION_MNEMONICS: frozenset = frozenset({
        # 1-character (RX/RR arithmetic/logical)
        "A", "C", "D", "L", "M", "N", "O", "S", "X",
        # 2-character
        "AD", "AE", "AER", "AF", "AH", "AL", "ALR", "AR", "AU", "AW", "AXR",
        "CD", "CE", "CER", "CH", "CL", "CLR", "CR",
        "DD", "DE", "DER", "DR",
        "IC", "LA", "LCR", "LD", "LE", "LER", "LH", "LM", "LNR", "LPR", "LR",
        "MD", "ME", "MER", "MH", "MR", "MS", "MX", "MXD", "MXDR", "MXR",
        "NH", "NI", "NR",
        "OC", "OH", "OI", "OR",
        "SH", "SL", "SLR", "SR", "ST", "STD", "STE", "STH", "STM", "STR", "SU",
        "SW", "SXR",
        "TM", "TR", "TRT",
        "XC", "XI", "XR",
        # 3-character common instructions
        "ADB", "ADE", "AGHI", "AGR", "AHI", "AIH", "ALG", "ALGR",
        "CDB", "CDSG", "CEB", "CEBR", "CFI", "CGFI", "CGHI", "CGIB", "CGIJ",
        "CGIT", "CGR", "CGRT", "CHF", "CHHR", "CHLR", "CHI", "CHLR",
        "CIB", "CIJ", "CIT", "CLC", "CLFI", "CLG", "CLGFI", "CLGR", "CLI",
        "CLIH", "CLIJ", "CLRB", "CLRJ", "CLRT", "CLT", "CMH", "COMP",
        "CPY", "CRB", "CRJ", "CRT", "CSG", "CSP", "CVB", "CVD",
        "DDB", "DEB", "DER",
        "EAR", "EX",
        "ICM", "IEDTR", "IIHF", "IIHH", "IIHL", "IILF", "IILH", "IILL",
        "IPM",
        "LAM", "LAO", "LBR", "LCDBR", "LCDFR", "LCDR", "LCEBR", "LCGFR",
        "LCGR", "LCHER", "LDR", "LDXBR", "LDXR", "LER",
        "LFH", "LFHAT", "LGBR", "LGDR", "LGF", "LGFI", "LGFR", "LGHI",
        "LGHR", "LGR", "LHHR", "LHLR", "LHI", "LHR", "LLCR", "LLGCR",
        "LLGFR", "LLGHR", "LLGTR", "LLHFR", "LLHR", "LLZRGF", "LNR",
        "LPDFR", "LPEBR", "LPGFR", "LPR", "LRL", "LTDBR", "LTEBR", "LTGFR",
        "LTGR", "LTR", "LXDBR", "LXEBR", "LXLDR", "LXLER", "LXLR",
        "MAD", "MAE", "MADB", "MADR", "MAEB", "MAEBR", "MAR", "MDB", "MEB",
        "MGHI", "MLGR", "MLR", "MSB", "MSDB", "MSDR", "MSEB", "MSEBR",
        "MSR", "MVC", "MVCL", "MVCS", "MVCSD", "MVCU", "MVI", "MVIY",
        "MVPG", "MVZ", "MXB", "MXBR",
        "NCL", "NGR", "NOP", "NR",
        "OGR", "OR",
        "PKA", "PKU", "PLO",
        "SAR", "SDB", "SEB", "SGFR", "SGR", "SHR", "SLBGR", "SLBR", "SLGFR",
        "SLGR", "SLHHR", "SLHLR", "SLHR", "SLR", "SQD", "SQE", "SQDB",
        "SQEB", "SQR", "SQXBR", "SRK", "SRL", "SRLG", "SRLK", "SRST",
        "STAM", "STCK", "STCKE", "STCMH", "STCY", "STFLE", "STFPC",
        "STGRL", "STGSB", "STHH", "STHY", "STMFD", "STMG", "STMH",
        "STRV", "STRVG", "STRVH", "STY", "SUB", "SXB", "SXBR",
        "TMH", "TMHH", "TMHL", "TML", "TMLH", "TMLL",
        "TROO", "TROT", "TRT", "TRTE", "TRTO", "TRTR", "TRTRE", "TRTT",
        "TS", "TXB", "TXBR",
        "UNPK", "UNPKA", "UNPKU", "UPT",
        "XGR", "XRK",
        # Extended branch / conditional mnemonics not starting with B or J
        "NOP", "NOPR",
        # 64-bit arithmetic
        "AG", "AGF", "AHI", "ALG", "ALGF",
        "CG", "CGF", "CLGF", "CLH",
        "LG", "LGF", "LGH",
        "SG", "SGF",
        "STG",
        # Floating point
        "ADB", "AEB", "MDB", "MEB", "SDB", "SEB", "DDB", "DEB",
        # Compare logical long
        "CLCL", "MVCL",
        # Pack/unpack
        "PACK", "UNPK",
        # Shift
        "SLA", "SLL", "SRA", "SRL", "SLAG", "SLLG", "SRAG", "SRLG",
        # Multiply halfword
        "MHI", "MGHI",
        # Load/store multiple
        "LMD", "LMG", "STMG",
        # Branch-relative (already in InstructionClassifier but added for completeness)
        "BRC", "BRCL", "BRUL",
        # Translate
        "TRE",
        # Vector mnemonics (z14+) — common ones
        "VL", "VST", "VLR", "VA", "VS", "VM", "VN", "VO", "VX",
        # Miscellaneous
        "LLGF", "LLILL", "LLILH", "LLIHL", "LLIHH", "LGFI",
        "IILL", "IILH", "IIHL", "IIHH",
    })

    def __init__(self):
        self.classifier = InstructionClassifier()
        self.macro_classifier = MacroClassifier()
        self.external_identifier = ExternalCallIdentifier()
        self.current_routine: Optional[str] = None
        self._level_symbol_re = re.compile(r"^LEVEL_?(\d+)$", re.IGNORECASE)
        self._level_data_re = re.compile(r"^D([0-9A-Fa-f])$", re.IGNORECASE)
        self._integer_literal_re = re.compile(r"^[+-]?(?:0[xX][0-9A-Fa-f]+|\d+)(?:[uUlL]+)?$")
        self._c_block_comment_re = re.compile(r"/\*.*?\*/", re.DOTALL)
        self._macro_branch_keyword_params = {"NOTUSED", "BAD", "ERROR"}
        self._symbol_target_re = re.compile(r"[A-Za-z@$_#][A-Za-z0-9@$_#]*")
        # Regex for opcodes that look like custom macro names: 1–8 uppercase
        # alphanumeric chars (plus $, @, #, _) with no special chars.
        self._custom_macro_re = re.compile(r"^[A-Z@$#_][A-Z0-9@$#_]{0,7}$")

    def _is_custom_macro_opcode(self, opcode: str) -> bool:
        """Return True if *opcode* looks like a custom (unrecognised) macro call.

        Heuristic: all-uppercase alphanumeric (plus ``$``, ``@``, ``#``, ``_``),
        1–8 characters, not a known assembler directive or IBM z machine instruction.
        """
        op_upper = opcode.upper()
        if op_upper in self._DIRECTIVE_OPCODES:
            return False
        if op_upper in self._MACHINE_INSTRUCTION_MNEMONICS:
            return False
        if not self._custom_macro_re.match(op_upper):
            return False
        # Exclude opcodes the instruction classifier can classify (branches,
        # subroutine calls, etc.).
        if self.classifier.classify(op_upper) is not None:
            return False
        return True

    def process(self, lines: List[ParsedLine], context: AnalysisContext):
        """Process all lines and build call graph.

        Args:
            lines: Parsed assembly lines
            context: Shared analysis context
        """
        call_graph = CallGraph()
        scope_state = ScopeState()
        # Track MACRO body state: lines inside MACRO…MEND are template code
        # and must not generate call-graph edges against the definition site.
        in_macro_body: bool = False

        for line in lines:
            opcode_upper = (line.opcode or "").upper()

            # Update MACRO body tracking before processing the line so that
            # the MACRO directive itself is handled outside the body.
            if opcode_upper == "MACRO":
                in_macro_body = True
            elif opcode_upper == "MEND":
                in_macro_body = False

            entered_section, entered_routine = apply_scope_transition(line, scope_state)
            if entered_routine:
                self.current_routine = scope_state.current_routine
            elif line.provenance.routine:
                self.current_routine = line.provenance.routine

            # Track current routine/section
            if entered_section and line.label and line.opcode:
                node_kind = "control_section" if opcode_upper == "CSECT" else "routine"
                call_graph.add_node(
                    line.label,
                    file=line.provenance.original_file,
                    node_kind=node_kind,
                )

            # Classify instruction
            if not line.opcode:
                continue

            # Skip call-graph edges for lines inside MACRO body definitions.
            if in_macro_body:
                continue

            # Check if it's a recognised macro invocation first
            if self.macro_classifier.is_macro(line.opcode):
                self._handle_macro(line, call_graph)
                continue

            flow_type = self.classifier.classify(line.opcode)

            if flow_type is None:
                # Unknown to both classifier and macro_classifier.  If the
                # opcode matches the shape of a custom macro name, record a
                # generic MACRO_INVOCATION edge so downstream enrichment can
                # populate invokes_macros in line_metadata.
                if self._is_custom_macro_opcode(opcode_upper):
                    self._handle_macro(line, call_graph)
                continue

            # Handle different control flow types
            if flow_type == ControlFlowType.SUBROUTINE_CALL:
                self._handle_call(line, call_graph)
            elif flow_type == ControlFlowType.BRANCH:
                # Check if it's a return first
                if self.classifier.is_return(line.opcode, line.operands):
                    self._handle_return(line, call_graph)
                else:
                    self._handle_branch(line, call_graph)
            elif flow_type == ControlFlowType.MODE_TRANSITION:
                self._handle_mode_transition(line, call_graph)
            elif flow_type == ControlFlowType.EXECUTE:
                self._handle_execute(line, call_graph)

        # Store call graph in context
        context.add_metadata("call_graph", call_graph)

    def build_expanded_graphs(self, context: AnalysisContext) -> None:
        """Build expanded call graphs for macro expansions in context.

        Args:
            context: Analysis context that may contain macro expansions
        """
        _t0 = time.perf_counter()
        _log.debug("CallGraphBuilderPass.build_expanded_graphs start: %s", context.file_path)
        if not hasattr(context, 'macro_expansions'):
            return

        for expansion in context.macro_expansions:
            if expansion.expansion_status != "success":
                continue

            expansion.expanded_call_graph = self.build_expanded_call_graph(expansion)

        _log.debug(
            "CallGraphBuilderPass.build_expanded_graphs done in %.3fs: %s",
            time.perf_counter() - _t0,
            context.file_path,
        )

    def build_expanded_call_graph(self, expansion: ExpansionResult) -> Dict[str, Any]:
        """Build a call graph for expanded macro instructions.

        Args:
            expansion: Macro expansion result

        Returns:
            Dictionary with nodes and edges
        """
        nodes = []
        edges = []

        for idx, instruction in enumerate(expansion.expanded_instructions):
            node_id = f"{expansion.expansion_id}_instr_{idx}"

            nodes.append({
                "id": node_id,
                "instruction": instruction.instruction,
                "line": expansion.invocation_line,
                "macro_context": expansion.macro_name
            })

            if idx < len(expansion.expanded_instructions) - 1:
                next_id = f"{expansion.expansion_id}_instr_{idx + 1}"
                edge_type = "sequential"

                if self._is_branch_instruction(instruction.instruction):
                    edge_type = "conditional"

                edges.append({
                    "from": node_id,
                    "to": next_id,
                    "type": edge_type
                })

        return {
            "nodes": nodes,
            "edges": edges
        }

    def _is_branch_instruction(self, instruction: str) -> bool:
        """Check if instruction is a branch.

        Args:
            instruction: Instruction text

        Returns:
            True if branch instruction
        """
        if not instruction:
            return False

        opcode = instruction.split()[0]
        branch_opcodes = {"B", "BR", "BC", "BCR", "BNZ", "BZ", "BE", "BNE"}
        return opcode.upper() in branch_opcodes

    def _extract_entrc_target(self, operands: List[str]) -> Optional[str]:
        """Extract ENTRC/ENTNC/CREEC target module name from operands.

        Handles:
          - Simple positional: "DA78"  → "DA78"
          - Inline comment:    "XH72 CONTINUE XH81 PROCESSING" → "XH72"
          - Comma-separated:   "GA71,D0,R" → "GA71"  (CREEC pattern)
          - Keyword:           "ENTRY=DA78" → "DA78"
        """
        for operand in operands:
            candidate = operand.strip().rstrip(",")
            if not candidate:
                continue
            if "=" in candidate:
                _, value = candidate.split("=", 1)
                candidate = value.strip().rstrip(",")
            normalized = self._normalize_symbol_target(candidate)
            if normalized:
                return normalized
        return None

    def _extract_creec_target(self, operands: List[str]) -> Optional[str]:
        """Extract CREEC spawn target entry from operands."""
        for operand in operands:
            if not operand:
                continue
            for segment in [part.strip() for part in operand.split(",") if part.strip()]:
                candidate = segment
                if "=" in candidate:
                    key, value = candidate.split("=", 1)
                    key = key.strip().upper().lstrip("&")
                    if key not in {"ENTRY", "SEG", "SEGMENT", "TARGET"}:
                        continue
                    candidate = value.strip()
                normalized = self._normalize_symbol_target(candidate)
                if normalized:
                    return normalized
        return None

    def _extract_attac_target(self, operands: List[str]) -> Optional[str]:
        """Extract ATTAC attach target entry from operands."""
        for operand in operands:
            if not operand:
                continue
            for segment in [part.strip() for part in operand.split(",") if part.strip()]:
                candidate = segment
                if "=" in candidate:
                    key, value = candidate.split("=", 1)
                    key = key.strip().upper().lstrip("&")
                    if key not in {"ENTRY", "SEG", "SEGMENT", "TARGET"}:
                        continue
                    candidate = value.strip()
                normalized = self._normalize_symbol_target(candidate)
                if normalized:
                    return normalized
        return None

    def _extract_callcpp_target(self, operands: List[str]) -> Optional[str]:
        """Extract CALLCPP target function symbol from operands."""
        for operand in operands:
            if not operand:
                continue
            for segment in [part.strip() for part in operand.split(",") if part.strip()]:
                candidate = segment
                if "=" in candidate:
                    key, value = candidate.split("=", 1)
                    key = key.strip().upper().lstrip("&")
                    if key not in {"ENTRY", "TARGET", "FUNC", "FUNCTION", "NAME", "SEG", "SEGMENT"}:
                        continue
                    candidate = value.strip()
                normalized = self._normalize_symbol_target(candidate)
                if normalized:
                    return normalized
        return None

    def _normalize_symbol_target(self, raw: str) -> Optional[str]:
        """Normalize noisy target operands to routine/function symbol tokens."""
        if not raw:
            return None
        cleaned = self._c_block_comment_re.sub("", str(raw))
        cleaned = re.sub(r"//.*", "", cleaned).strip()
        if not cleaned:
            return None

        if "=" in cleaned:
            _, cleaned = cleaned.split("=", 1)
            cleaned = cleaned.strip()
        if not cleaned:
            return None

        cleaned = cleaned.split(",")[0].split()[0].strip()
        cleaned = cleaned.split("(")[0].strip()
        cleaned = cleaned.lstrip("=*&").rstrip(").,;:")
        if not cleaned or cleaned.startswith("&"):
            return None

        match = self._symbol_target_re.search(cleaned)
        if not match:
            return None
        token = match.group(0)
        if not token:
            return None
        if self._is_register_like_operand(token):
            return None
        if self._integer_literal_re.match(token):
            return None
        if self._contains_level_marker(token):
            return None
        if token.upper() in {"R", "N", "Y", "YES", "NO"}:
            return None
        return token

    def _parse_level_token(self, token: str) -> Optional[int]:
        """Parse level-like tokens such as LEVEL0, D0, or 0."""
        if not token:
            return None
        cleaned = self._c_block_comment_re.sub("", token)
        cleaned = re.sub(r"//.*", "", cleaned).strip()
        if not cleaned:
            return None

        while cleaned.startswith("(") and cleaned.endswith(")"):
            cleaned = cleaned[1:-1].strip()
            if not cleaned:
                return None

        compact = re.sub(r"\s+", "", cleaned)
        if not compact:
            return None

        level_match = self._level_symbol_re.match(compact)
        if level_match:
            return int(level_match.group(1))

        data_match = self._level_data_re.match(compact)
        if data_match:
            return int(data_match.group(1), 16)

        if self._integer_literal_re.match(compact):
            normalized = re.sub(r"(?i)[uUlL]+$", "", compact)
            try:
                return int(normalized, 0)
            except ValueError:
                return None

        return None

    def _contains_level_marker(self, token: str) -> bool:
        if not token:
            return False
        compact = re.sub(r"\s+", "", token.upper())
        return bool(re.fullmatch(r"LEVEL_?\d+|D[0-9A-Fa-f]", compact))

    def _extract_macro_level_number(self, operands: List[str]) -> Optional[int]:
        """Extract a macro level number from key/value or positional operands."""
        for operand in operands:
            if not operand:
                continue
            for segment in [part.strip() for part in operand.split(",") if part.strip()]:
                if "=" in segment:
                    key, value = segment.split("=", 1)
                    key = key.strip().upper().lstrip("&")
                    value = value.strip()
                    if key == "LEVEL":
                        parsed = self._parse_level_token(value)
                        if parsed is not None:
                            return parsed
                        continue
                    if self._contains_level_marker(value):
                        parsed = self._parse_level_token(value)
                        if parsed is not None:
                            return parsed
                    continue

                parsed = self._parse_level_token(segment)
                if parsed is not None and self._contains_level_marker(segment):
                    return parsed
        return None

    @staticmethod
    def _file_entry_id(file_path: str) -> str:
        """Synthetic entry-block ID for unlabeled file prologue code."""
        return Path(file_path).stem.upper()

    def _effective_source(self, line: ParsedLine) -> str:
        """Return the best available source ID for a control-flow edge.

        Priority: current labeled routine → current section → file stem.
        The file-stem fallback covers files where executable mainline code
        appears before any CSECT/EQU* label, so current_routine is still None.
        """
        return (
            self.current_routine
            or line.provenance.section
            or self._file_entry_id(line.provenance.original_file)
        )

    def _handle_call(self, line: ParsedLine, call_graph: CallGraph):
        """Handle subroutine call instructions.

        Args:
            line: Parsed line
            call_graph: Call graph being built
        """
        if not line.operands or len(line.operands) < 2:
            return

        source = self._effective_source(line)
        call_graph.add_node(source, file=line.provenance.original_file, node_kind="routine")

        # Check if indirect call
        is_indirect = self.classifier.is_indirect(line.opcode, line.operands)

        if is_indirect:
            # Indirect call - target unknown, register holds address
            target_register = line.operands[1]
            call_graph.add_edge(
                source=source,
                target=None,
                call_type=CallType.SUBROUTINE_CALL,
                instruction=line.opcode,
                file=line.provenance.original_file,
                line=line.provenance.original_line,
                is_indirect=True,
                register=target_register
            )
        else:
            # Direct call - target is label
            raw_target = line.operands[1] if len(line.operands) > 1 else line.operands[0]
            target = self._normalize_symbol_target(raw_target)
            if not target:
                return

            # Check if target is an external call
            is_external = self.external_identifier.is_external_call(target)

            # Add node if it's external
            if is_external:
                call_graph.add_node(target, is_external=True, file=line.provenance.original_file, node_kind="function")
            else:
                call_graph.add_node(target, file=line.provenance.original_file, node_kind="routine")

            call_graph.add_edge(
                source=source,
                target=target,
                call_type=CallType.SUBROUTINE_CALL,
                instruction=line.opcode,
                file=line.provenance.original_file,
                line=line.provenance.original_line
            )

    def _handle_return(self, line: ParsedLine, call_graph: CallGraph):
        """Handle return instructions (BR R14).

        Args:
            line: Parsed line
            call_graph: Call graph being built
        """
        source = self._effective_source(line)
        call_graph.add_node(source, file=line.provenance.original_file, node_kind="routine")

        call_graph.add_edge(
            source=source,
            target=None,  # Return target is dynamic
            call_type=CallType.RETURN,
            instruction=line.opcode,
            file=line.provenance.original_file,
            line=line.provenance.original_line
        )

    def _handle_branch(self, line: ParsedLine, call_graph: CallGraph):
        """Handle branch instructions.

        Args:
            line: Parsed line
            call_graph: Call graph being built
        """
        if not line.operands or len(line.operands) < 1:
            return

        source = self._effective_source(line)
        call_graph.add_node(source, file=line.provenance.original_file, node_kind="routine")

        # BR Rx (Rx != R14) and BCR mask,Rx (mask != 0, Rx != R14) are
        # register-indirect branches — the target address is held in a register
        # at runtime, making them indirect calls.
        if self.classifier.is_register_indirect_branch(line.opcode, line.operands):
            instr_upper = line.opcode.upper()
            reg = (line.operands[0].strip() if instr_upper == "BR"
                   else line.operands[1].strip())
            call_graph.add_edge(
                source=source,
                target=None,
                call_type=CallType.SUBROUTINE_CALL,
                instruction=line.opcode,
                file=line.provenance.original_file,
                line=line.provenance.original_line,
                is_indirect=True,
                register=reg,
            )
            return

        target = self._extract_branch_target(line.opcode, line.operands)
        if not target:
            return
        call_graph.add_node(target, file=line.provenance.original_file, node_kind="routine")

        call_graph.add_edge(
            source=source,
            target=target,
            call_type=CallType.BRANCH,
            instruction=line.opcode,
            file=line.provenance.original_file,
            line=line.provenance.original_line
        )

    def _extract_branch_target(self, opcode: str, operands: List[str]) -> Optional[str]:
        """Extract a symbolic branch target from operands.

        For most branch forms, the target is the last operand.
        Register-indirect branches (e.g., BR R15, BCR 15,R14) do not
        produce a symbolic target and return None.
        """
        if not operands:
            return None

        candidate = operands[-1].strip().rstrip(",")
        if not candidate:
            return None
        if "=" in candidate:
            return None
        return self._normalize_symbol_target(candidate)

    def _is_register_like_operand(self, operand: str) -> bool:
        """Return True if operand looks like a register token."""
        token = operand.strip().upper()
        if re.fullmatch(r"R(?:1[0-5]|[0-9])", token):
            return True
        if token.isdigit():
            value = int(token)
            return 0 <= value <= 15
        return False

    def _handle_mode_transition(self, line: ParsedLine, call_graph: CallGraph):
        """Handle mode transition instructions (BASSM, BASM, BSM).

        Args:
            line: Parsed line
            call_graph: Call graph being built
        """
        if not line.operands or len(line.operands) < 2:
            return

        source = self._effective_source(line)
        call_graph.add_node(source, file=line.provenance.original_file, node_kind="routine")
        raw_target = line.operands[1]

        # When the second operand is a register, this is a register-indirect
        # mode transition (e.g. BASSM R14,R15 — save mode/link in R14, branch
        # to the address held in R15).  R0/0 is the special "no-branch, save
        # mode only" form and is silently skipped.
        if self._is_register_like_operand(raw_target):
            reg_upper = raw_target.strip().upper()
            if reg_upper not in ("R0", "0"):
                call_graph.add_edge(
                    source=source,
                    target=None,
                    call_type=CallType.MODE_TRANSITION,
                    instruction=line.opcode,
                    file=line.provenance.original_file,
                    line=line.provenance.original_line,
                    is_indirect=True,
                    register=raw_target.strip(),
                )
            return

        # Direct symbolic mode transition — target is a label, not a register.
        target = self._normalize_symbol_target(raw_target)
        if not target:
            return
        call_graph.add_node(target, file=line.provenance.original_file, node_kind="routine")
        call_graph.add_edge(
            source=source,
            target=target,
            call_type=CallType.MODE_TRANSITION,
            instruction=line.opcode,
            file=line.provenance.original_file,
            line=line.provenance.original_line
        )

    def _handle_execute(self, line: ParsedLine, call_graph: CallGraph):
        """Handle EX (execute) instructions.

        Args:
            line: Parsed line
            call_graph: Call graph being built
        """
        if not line.operands or len(line.operands) < 2:
            return

        source = self._effective_source(line)
        call_graph.add_node(source, file=line.provenance.original_file, node_kind="routine")
        target = line.operands[1]
        call_graph.add_node(target, file=line.provenance.original_file, node_kind="routine")

        call_graph.add_edge(
            source=source,
            target=target,
            call_type=CallType.EXECUTE,
            instruction=line.opcode,
            file=line.provenance.original_file,
            line=line.provenance.original_line
        )

    def _handle_macro(self, line: ParsedLine, call_graph: CallGraph):
        """Handle macro invocations (z/TPF and z/TPFDF).

        Args:
            line: Parsed line
            call_graph: Call graph being built
        """
        source = self._effective_source(line)
        macro_name = line.opcode.upper()
        level_number = self._extract_macro_level_number(line.operands)
        call_graph.add_node(source, file=line.provenance.original_file, node_kind="routine")

        # Cross-segment transfer macros:
        # ENTRC  — subroutine call with return
        # ENTNC  — non-returning transfer (tail-call / goto another segment)
        # ENTDC  — direct segment dispatch, same semantics as ENTNC
        # CREEC  — spawns a new ECB and runs another segment independently (fire-and-forget)
        # CREMC  — async task creation, similar to CREEC
        # SWISC  — ISC-routed message dispatch to another segment
        # FUNCTION — local macro wrapper that expands to ENTDC; args[1] is the target segment
        if macro_name in ("ENTRC", "ENTNC", "ENTDC", "CREEC", "CREMC", "CREDC", "CRETC", "CREXC", "CRESC",
                         "EXSR", "SWISC", "FUNCTION", "CLINKC") and line.operands:
            # FUNCTION macro: first operand is a 4-char message code, second is the target segment
            if macro_name == "FUNCTION":
                operands_list = [op.strip() for op in ",".join(line.operands).split(",")]
                target = operands_list[1].split()[0] if len(operands_list) > 1 else ""
                effective_inst = "ENTDC"  # FUNCTION expands to ENTDC
            else:
                target = self._extract_entrc_target(line.operands)
                effective_inst = macro_name
            if target:
                # Target node's file = target segment (not source).  This
                # ensures forward traversal derives the correct file_stem
                # and loads the target's blueprint, not the source's.
                call_graph.add_node(target, file=f"{target.lower()}.asm", node_kind="function")
                if effective_inst in ("ENTRC", "EXSR", "CLINKC"):
                    ctype = CallType.SUBROUTINE_CALL
                elif effective_inst in ("ENTNC", "ENTDC"):
                    ctype = CallType.NO_RETURN_CALL
                elif effective_inst in ("CREEC", "CREMC", "CREDC", "CRETC", "CREXC"):
                    ctype = CallType.ASYNC_SPAWN
                elif effective_inst == "CRESC":
                    ctype = CallType.SYNC_SPAWN
                else:  # SWISC
                    ctype = CallType.ISC_ROUTE
                call_graph.add_edge(
                    source=source,
                    target=target,
                    call_type=ctype,
                    instruction=macro_name,
                    file=line.provenance.original_file,
                    line=line.provenance.original_line,
                    level_number=level_number,
                )
                return

        # ATTAC/ATTC attach a child ECB/task and continue asynchronously.
        if macro_name in ("ATTAC", "ATTC") and line.operands:
            target = self._extract_attac_target(line.operands)
            if target:
                call_graph.add_node(target, file=f"{target.lower()}.asm", node_kind="function")
                call_graph.add_edge(
                    source=source,
                    target=target,
                    call_type=CallType.ASYNC_SPAWN,
                    instruction=macro_name,
                    file=line.provenance.original_file,
                    line=line.provenance.original_line,
                    level_number=level_number,
                )
                return

        # CALLCPP/CALLC bridge ASM to C/C++ symbol entry and return to caller.
        # CALLCPP is the project convention; CALLC is IBM's preferred z/TPF form.
        if macro_name in ("CALLCPP", "CALLC") and line.operands:
            target = self._extract_callcpp_target(line.operands)
            if target:
                call_graph.add_node(target, is_external=True, file=line.provenance.original_file, node_kind="function")
                call_graph.add_edge(
                    source=source,
                    target=target,
                    call_type=CallType.CALL,
                    instruction=macro_name,
                    file=line.provenance.original_file,
                    line=line.provenance.original_line,
                    level_number=level_number,
                )
                return

        # EXIT-family and BACKC macros are explicit return boundaries.
        if macro_name in ("EXIT", "EXITC", "RETURN", "RETRN", "BACKC", "RLINKC"):
            call_graph.add_edge(
                source=source,
                target=None,
                call_type=CallType.RETURN,
                instruction=macro_name,
                file=line.provenance.original_file,
                line=line.provenance.original_line,
                level_number=level_number,
            )
            return

        # Add macro invocation to call graph
        # Target is the macro name itself
        call_graph.add_node(macro_name, file=line.provenance.original_file, kind="macro")
        call_graph.add_edge(
            source=source,
            target=macro_name,
            call_type=CallType.MACRO_INVOCATION,
            instruction=macro_name,
            file=line.provenance.original_file,
            line=line.provenance.original_line,
            level_number=level_number,
        )

        for target in self._extract_macro_branch_targets(line.operands or []):
            call_graph.add_node(target, file=line.provenance.original_file, node_kind="routine")
            call_graph.add_edge(
                source=source,
                target=target,
                call_type=CallType.BRANCH,
                instruction=macro_name,
                file=line.provenance.original_file,
                line=line.provenance.original_line,
                level_number=level_number,
            )

    def _extract_macro_branch_targets(self, operands: List[str]) -> List[str]:
        targets: List[str] = []
        for operand in operands:
            if "=" not in operand:
                continue
            key, value = operand.split("=", 1)
            if key.strip().upper() not in self._macro_branch_keyword_params:
                continue
            target = self._normalize_symbol_target(value)
            if target:
                targets.append(target)
        return targets
