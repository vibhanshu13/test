"""Global lineage stitcher for multi-file analysis.

This module provides the GlobalLineageStitcher class which merges variable lineage
information from multiple assembly files into a unified global graph. It handles:
- Symbol resolution across files (ENTRY/EXTRN symbols)
- Lineage graph merging from multiple AnalysisContext objects
- Cross-file symbol tracking and mapping

The stitcher is designed to work at scale, efficiently merging lineage data from
hundreds of files while maintaining accurate cross-file references.
"""

import logging
import os
import re
import time
from typing import Any, Dict, List, Iterable, Tuple, Set, Optional
from models.variable_lineage import VariableLineageGraph
from models.analysis_context import AnalysisContext
from models.symbol import SymbolTable, SymbolType

_log = logging.getLogger(__name__)

# Fraction of cgroup memory limit at which Phase 2 stops merging new contexts
# and Phase 4 skips individual files, preventing SIGKILL of the entire process.
_MEM_SKIP_RATIO = 0.88


def _rss_ratio() -> float:
    """Return RSS / cgroup_memory_limit as a float in [0, 1].

    Tries cgroup v2 first, then v1.  Returns 0.0 when the limit cannot be
    determined (e.g. running outside Docker or limit set to 'max').
    """
    for limit_path, usage_path in (
        ("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory.current"),
        (
            "/sys/fs/cgroup/memory/memory.limit_in_bytes",
            "/sys/fs/cgroup/memory/memory.usage_in_bytes",
        ),
    ):
        try:
            raw = open(limit_path).read().strip()
            if raw in ("max", ""):
                continue
            limit = int(raw)
            if limit >= (1 << 62):   # "unlimited" sentinel value
                continue
            usage = int(open(usage_path).read().strip())
            return usage / limit
        except Exception:
            continue
    return 0.0


class _CompactEdgeSet:
    """Memory-efficient edge deduplication set.

    Stores ``hash(key)`` (an int, 28 bytes) instead of the full key tuple
    (~250 bytes for 3-string tuples).  For 15 M edges this saves ~3 GB of
    RSS vs a plain ``set[tuple]``.

    Hash collisions (~10⁻⁸ probability for 15 M entries on a 64-bit hash)
    would only cause one duplicate edge to be skipped — not a correctness
    problem for the stitched graph.
    """
    __slots__ = ("_data",)

    def __init__(self, iterable=None):
        self._data: Set[int] = set()
        if iterable is not None:
            for item in iterable:
                self._data.add(hash(item))

    def __contains__(self, item) -> bool:
        return hash(item) in self._data

    def add(self, item) -> None:
        self._data.add(hash(item))

    def __len__(self) -> int:
        return len(self._data)


class GlobalLineageStitcher:
    """
    Merge lineage graphs from multiple files into a unified global graph.

    This class is responsible for integrating variable lineage information across
    multiple assembly files, handling external symbol resolution and creating a
    complete picture of data flow throughout the entire codebase.

    Handles:
    - Memory symbol unification across CSECTs
    - External symbol resolution (EXTRN/ENTRY)
    - Cross-file call edges
    - Symbol-to-file mapping for provenance tracking

    Attributes:
        global_graph: The merged VariableLineageGraph containing all nodes and edges
        symbol_to_file: Maps symbol names to their defining source files
        entry_points: Maps ENTRY symbols to (file_path, section) tuples
        external_refs: Maps EXTRN symbols to lists of files that reference them
    """

    # Bucket size threshold: buckets with ≤ this many nodes get a full mesh;
    # larger buckets use a bidirectional chain to keep edge count O(N).
    _FULL_MESH_LIMIT: int = 20

    def __init__(self):
        """Initialize the GlobalLineageStitcher with empty data structures."""
        self.global_graph = VariableLineageGraph()
        self.symbol_to_file: Dict[str, str] = {}  # {symbol_name: source_file}
        self.entry_points: Dict[str, tuple] = {}  # {entry_symbol: (file, scope)}
        self.external_refs: Dict[str, List[str]] = {}  # {extrn_symbol: [referencing_files]}

        # Shared Phase 3 deduplication sets — built once before Phase 3 and
        # updated incrementally by each step.  Eliminates O(15×E) per-step
        # full-scan rebuilds that would otherwise occur at 10K+ file scale.
        # _CompactEdgeSet stores hash(key) instead of the full tuple, cutting
        # memory from ~4 GB to ~120 MB for 15 M edges.
        self._phase3_edges: _CompactEdgeSet = _CompactEdgeSet()
        self._phase3_level_edges: _CompactEdgeSet = _CompactEdgeSet()
        # Per-run caches for level-buffer collection (called from two Phase 3 steps).
        self._cpp_level_buffers_cache: Optional[Dict[int, Set[Tuple[str, str]]]] = None
        self._asm_level_buffers_cache: Optional[Dict[int, Set[Tuple[str, str]]]] = None

        # Phase-2 edge pre-computed data — populated by _prepare_phase3_from_phase2_edges().
        # These compact structures let three Phase-3 passes avoid re-iterating
        # global_graph.edges after the Phase-2 edges have been evicted to disk.
        self._p2_ai_nodes: Dict[str, Set[str]] = {}          # {access_identity: {node_ids}}
        self._p2_slot_registers: Dict[Tuple[str, int], Set[str]] = {}  # {(scope,slot):{regs}}
        self._p2_mem_reg_scoped: List[Tuple[str, str, str]] = []  # (scope, dsect_key, reg)
        self._p2_arg_bind_ca_mem: List[Tuple[str, str, str]] = []  # (callee, src_id, dst_name)
        self._p2_arg_bind_sf_ca: List[Tuple[str, str, str]] = []  # (src_id, src_name, dst_id)
        self._p2_r15_candidates: Dict[str, Set[str]] = {}    # {return_src: {variable_tgts}}

        # Set to True when Phase-2 edges have already been streamed to disk
        # inline during the merge loop.  _prepare_phase3_from_phase2_edges()
        # checks this and becomes a no-op, avoiding a redundant second pass.
        self._p2_streaming_done: bool = False

    def process_contexts(self, contexts: Dict[str, AnalysisContext], lineage_loader=None, sym_cache_dir=None) -> VariableLineageGraph:
        """
        Merge lineage from multiple file contexts.

        This method performs a two-phase merge:
        1. Phase 1: Collect ENTRY and EXTRN symbols from symbol tables to establish
           cross-file symbol references
        2. Phase 2: Merge all lineage graph nodes and edges into the global graph

        The algorithm is designed for scalability:
        - O(n) iteration over contexts where n = number of files
        - O(m) iteration over symbols where m = total symbols across all files
        - O(e) merge of edges where e = total edges across all graphs

        Args:
            contexts: Dictionary mapping file paths to their AnalysisContext objects
            lineage_loader: Optional callable ``(file_path: str) -> VariableLineageGraph | None``.
                When provided, Phase 2 fetches each file's lineage graph via this
                loader and immediately frees it after merging — only one graph lives
                in memory at a time instead of all N.  When None, lineage is read
                directly from ``context.get_metadata("variable_lineage")`` as before.

        Returns:
            The merged global VariableLineageGraph containing all nodes and edges
            from all input contexts
        """
        _t0 = time.perf_counter()
        total_contexts = len(contexts)
        _log.info(
            "GlobalLineageStitcher.process_contexts start: %d file contexts", total_contexts
        )

        # Reset state for idempotent runs.
        self.global_graph = VariableLineageGraph()
        self.symbol_to_file = {}
        self.entry_points = {}
        self.external_refs = {}

        # Phase 1: Collect ENTRY and EXTRN symbols from symbol tables
        # This establishes the cross-file symbol resolution map
        for file_path, context in contexts.items():
            for symbol_name, symbol_type, section, definition_file in self._iter_symbols(context):
                if symbol_type == "ENTRY":
                    self.entry_points[symbol_name] = (file_path, section)
                if symbol_type == "EXTRN":
                    if symbol_name not in self.external_refs:
                        self.external_refs[symbol_name] = []
                    self.external_refs[symbol_name].append(file_path)
                if definition_file:
                    self.symbol_to_file[symbol_name] = definition_file
                elif symbol_type == "ENTRY":
                    self.symbol_to_file[symbol_name] = file_path

        _log.info(
            "GlobalLineageStitcher Phase 1 done in %.1fs: %d entry points, %d extrns",
            time.perf_counter() - _t0,
            len(self.entry_points),
            len(self.external_refs),
        )

        # Save symbol_tables to disk then free them before Phase 2 lineage merge.
        #
        # symbol_table is consumed by _iter_symbols() above and is never read
        # again by the stitcher.  For large corpora (15K+ files) the accumulated
        # SymbolTable objects can hold 2–5 GB of live heap.  Freeing them here,
        # before Phase 2's memory-guard check fires, allows significantly more
        # contexts to complete cross-file stitching before the 88% threshold.
        #
        # When sym_cache_dir is provided (normal pipeline path), each symbol_table
        # is pickled to disk first so json_emitter.py can reload it at blueprint
        # emission time (context.symbol_table.to_dict()).  When sym_cache_dir is
        # None the table is simply freed (legacy / unit-test path).
        import hashlib as _hl2, pickle as _pk2, os as _os2
        _n_st_freed = 0
        _n_st_saved = 0
        for _fp_str, _ctx in contexts.items():
            if _ctx.symbol_table is not None:
                if sym_cache_dir is not None:
                    try:
                        _sym_key = _hl2.md5(_fp_str.encode()).hexdigest() + "_sym.pkl"
                        _sym_dest = sym_cache_dir / _sym_key
                        with open(_sym_dest, "wb") as _sfh:
                            _pk2.dump(_ctx.symbol_table, _sfh, protocol=_pk2.HIGHEST_PROTOCOL)
                            try:
                                _os2.posix_fadvise(_sfh.fileno(), 0, 0, 4)  # DONTNEED
                            except Exception:
                                pass
                        _n_st_saved += 1
                    except Exception as _e:
                        _log.warning(
                            "GlobalLineageStitcher: could not save symbol_table for %s: %s",
                            _fp_str, _e,
                        )
                _ctx.symbol_table = None
                _n_st_freed += 1
            _ctx.metadata.pop("symbol_table", None)
        try:
            import gc as _gc2
            _gc2.collect()
            import ctypes as _ct2
            for _libc_name in ("libc.so.6", "libc.so", "libSystem.B.dylib", "libc.dylib"):
                try:
                    _ct2.CDLL(_libc_name).malloc_trim(0)
                    break
                except Exception:
                    pass
        except Exception:
            pass
        _log.info(
            "GlobalLineageStitcher Phase 1→2: freed symbol_tables from %d context(s) "
            "(%d saved to disk); trimmed heap before lineage merge.",
            _n_st_freed, _n_st_saved,
        )

        # Phase 2: Merge lineage graphs from all contexts
        #
        # STREAMING EDGE EVICTION — eliminates the ~7–9 GB RSS peak.
        #
        # Previously Phase 2 appended all edges to global_graph.edges (a Python
        # list), then _prepare_phase3_from_phase2_edges() iterated that list
        # once to build compact indices + write edges to a msgpack temp file,
        # then cleared global_graph.edges.  The peak was hit at the boundary:
        # the full 18.5 M-edge list existed simultaneously with the growing
        # dedup sets and the msgpack file being written.
        #
        # Now the same per-edge processing is done INLINE in the merge loop,
        # so global_graph.edges never grows.  Peak memory during Phase 2 is:
        #   nodes (~500 MB) + dedup sets (~300 MB) + one local_graph (~100 MB)
        # instead of ~9–12 GB.
        _p2_start = time.perf_counter()

        # --- Streaming edge eviction setup (same logic as _prepare_phase3_…) ---
        import tempfile as _tempfile
        try:
            import msgpack as _mp2
            _packer2 = _mp2.Packer(use_bin_type=True)
            _use_mp2 = True
        except ImportError:
            _packer2 = None
            _use_mp2 = False

        # Reset Phase-3 dedup sets and pre-computed indices upfront so they
        # grow incrementally during the merge loop.
        self._phase3_edges = _CompactEdgeSet()
        self._phase3_level_edges = _CompactEdgeSet()
        self._p2_ai_nodes = {}
        self._p2_slot_registers = {}
        self._p2_mem_reg_scoped = []
        self._p2_arg_bind_ca_mem = []
        self._p2_arg_bind_sf_ca = []
        self._p2_r15_candidates = {}

        _p2_tmp_path: Optional[str] = None
        _p2_tmp_fh = None
        _p2_edge_count = 0
        _p2_write_ok = False

        if _use_mp2:
            try:
                _tf2 = _tempfile.NamedTemporaryFile(
                    suffix=".p2edges.msgpack", delete=False, mode="wb"
                )
                _p2_tmp_path = _tf2.name
                _p2_tmp_fh = _tf2
                _p2_write_ok = True
                _log.debug(
                    "GlobalLineageStitcher Phase 2: streaming edges to %s",
                    _p2_tmp_path,
                )
            except Exception as _exc2:
                _log.debug(
                    "GlobalLineageStitcher: Phase-2 streaming disabled "
                    "(could not create temp file: %s)", _exc2,
                )

        _merged = 0
        for file_path, context in contexts.items():
            # When lineage_loader is supplied, fetch and immediately free each
            # graph so only one lives in memory at a time (streaming merge).
            # Fall back to reading directly from context for backward compat.
            if lineage_loader is not None:
                local_graph = lineage_loader(file_path)
            else:
                local_graph = context.get_metadata("variable_lineage")
            if not local_graph:
                continue

            # Merge nodes (same as before).
            for node in local_graph.nodes.values():
                self.global_graph.nodes[node.node_id] = node

            # Process edges inline: stream to disk + build Phase-3 indices.
            # When streaming is active (_p2_write_ok), edges are NOT appended
            # to global_graph.edges — this eliminates the 7–9 GB list peak.
            for edge in local_graph.edges:
                # 1. Compact dedup sets.
                _ek2 = (edge.source, edge.target, edge.relation)
                self._phase3_edges.add(_ek2)
                if edge.level_number is not None:
                    self._phase3_level_edges.add(
                        (edge.source, edge.target, edge.relation, edge.level_number)
                    )

                # 2. Stream edge to temp file.
                if _p2_write_ok:
                    try:
                        _p2_tmp_fh.write(_packer2.pack(edge.to_dict()))
                        _p2_edge_count += 1
                    except Exception:
                        _p2_write_ok = False
                        _log.warning(
                            "GlobalLineageStitcher: Phase-2 edge stream write failed; "
                            "falling back to in-memory accumulation for remaining edges."
                        )
                        self.global_graph.edges.append(edge)
                else:
                    # Fallback: accumulate in memory (no msgpack or write failed).
                    self.global_graph.edges.append(edge)

                # 3. access_identity index.
                if edge.access_identity:
                    for _nid2 in (edge.source, edge.target):
                        self._p2_ai_nodes.setdefault(
                            edge.access_identity, set()
                        ).add(_nid2)

                # 4. callarg / dsect / slot indices.
                if edge.relation == "assign" and edge.scope:
                    _sk2, _sn2 = self._split_node_id(edge.source)
                    _dk2, _dn2 = self._split_node_id(edge.target)
                    if _sk2 == "memory" and _dk2 == "register":
                        _reg2 = self._normalize_register_name(_dn2)
                        if _reg2:
                            _slot2 = self._parse_caller_param_slot(_sn2)
                            if _slot2 is not None:
                                self._p2_slot_registers.setdefault(
                                    (edge.scope.upper(), _slot2), set()
                                ).add(_reg2)
                            self._p2_mem_reg_scoped.append(
                                (edge.scope.upper(), _sn2.strip().upper(), _reg2)
                            )
                elif edge.relation == "arg_bind":
                    _sk2, _sn2 = self._split_node_id(edge.source)
                    _dk2, _dn2 = self._split_node_id(edge.target)
                    if _sk2 == "call_arg" and _dk2 == "memory" and edge.callee:
                        self._p2_arg_bind_ca_mem.append(
                            (edge.callee.upper(), edge.source, _dn2)
                        )
                    elif _sk2 == "struct_field" and _dk2 == "call_arg":
                        self._p2_arg_bind_sf_ca.append(
                            (edge.source, _sn2, edge.target)
                        )

                # 5. R15 return bridge candidates.
                if (
                    edge.relation == "assign"
                    and edge.target.startswith("variable:")
                    and not edge.target.startswith("variable:return@")
                    and edge.source.startswith("return_value:return@")
                ):
                    self._p2_r15_candidates.setdefault(
                        edge.source, set()
                    ).add(edge.target)

            # Annotate local nodes with a canonical cross-language field key so
            # downstream consumers can connect C++/ASM even without global edges.
            self._annotate_ecb_field_metadata(local_graph)

            if lineage_loader is not None:
                del local_graph  # free immediately; next iteration loads the next one

            _merged += 1
            if _merged % 1000 == 0:
                _log.info(
                    "GlobalLineageStitcher Phase 2 merging: %d/%d contexts, "
                    "%d nodes, %d edges (%.1fs elapsed)",
                    _merged, total_contexts,
                    len(self.global_graph.nodes),
                    _p2_edge_count + len(self.global_graph.edges),
                    time.perf_counter() - _p2_start,
                )

            # Memory guard — checked every 100 contexts to amortise syscall cost.
            # If RSS exceeds _MEM_SKIP_RATIO of the cgroup limit, stop merging
            # new contexts instead of growing until SIGKILL.  Already-merged
            # contexts stay in the global graph; skipped ones retain their local
            # lineage only (no cross-file stitching for those files).
            if _merged % 100 == 0:
                _ratio = _rss_ratio()
                if _ratio > _MEM_SKIP_RATIO:
                    _skipped = total_contexts - _merged
                    _log.warning(
                        "GlobalLineageStitcher Phase 2: memory at %.1f%% of cgroup limit "
                        "(threshold %.0f%%) — stopping merge early at %d/%d contexts. "
                        "%d context(s) will have local lineage only (no cross-file stitching).",
                        _ratio * 100, _MEM_SKIP_RATIO * 100,
                        _merged, total_contexts, _skipped,
                    )
                    break

        # Finalise the temp file and record its path on global_graph so
        # _stream_write_gvl and other consumers can stream from disk later.
        if _p2_tmp_fh is not None:
            try:
                _p2_tmp_fh.close()
                try:
                    with open(_p2_tmp_path, "rb") as _fh2:
                        os.posix_fadvise(_fh2.fileno(), 0, 0, 4)  # POSIX_FADV_DONTNEED
                except Exception:
                    pass
            except Exception:
                _p2_write_ok = False

        _in_mem_edges = len(self.global_graph.edges)
        if _p2_write_ok and _in_mem_edges == 0:
            # All edges streamed to disk; global_graph.edges already empty.
            self.global_graph._p2_edges_path = _p2_tmp_path
            self.global_graph._p2_edge_count = _p2_edge_count
            _log.info(
                "GlobalLineageStitcher Phase 2 done in %.1fs: "
                "%d nodes, %d edges streamed to disk (in-memory peak eliminated)",
                time.perf_counter() - _p2_start,
                len(self.global_graph.nodes),
                _p2_edge_count,
            )
        else:
            # Fallback: partial or full in-memory accumulation.
            if _p2_tmp_path:
                try:
                    os.unlink(_p2_tmp_path)
                except Exception:
                    pass
            self.global_graph._p2_edges_path = None
            self.global_graph._p2_edge_count = 0
            _log.info(
                "GlobalLineageStitcher Phase 2 done in %.1fs: "
                "%d nodes, %d edges merged from %d contexts (in-memory fallback)",
                time.perf_counter() - _p2_start,
                len(self.global_graph.nodes),
                _in_mem_edges,
                _merged,
            )

        # Return OS pages freed by the edge streaming and node merging.
        try:
            import gc as _gc_p2
            _gc_p2.collect()
            import ctypes as _ct_p2
            for _libc_n2 in ("libc.so.6", "libc.so", "libSystem.B.dylib", "libc.dylib"):
                try:
                    _ct_p2.CDLL(_libc_n2).malloc_trim(0)
                    break
                except Exception:
                    pass
        except Exception:
            pass

        # Signal to _prepare_phase3_from_phase2_edges() that all index building
        # was already performed inline and it can return immediately.
        self._p2_streaming_done = True

        # Phase 3: Add cross-language stitching edges after merge.
        _p3_start = time.perf_counter()

        # Single-pass over Phase-2 edges: build _phase3_edges / _phase3_level_edges,
        # write all edges to a msgpack temp file, clear global_graph.edges to free
        # ~4–5 GB of RSS, and pre-compute compact dicts for three Phase-3 passes.
        # Falls back to keeping edges in memory when msgpack is unavailable.
        self._prepare_phase3_from_phase2_edges()
        self._cpp_level_buffers_cache = None
        self._asm_level_buffers_cache = None
        _log.info(
            "GlobalLineageStitcher Phase 3: pre-built dedup sets "
            "(%d 3-hashes, %d level-hashes); "
            "%d Phase-2 edges evicted to disk, %d edges in graph",
            len(self._phase3_edges),
            len(self._phase3_level_edges),
            getattr(self.global_graph, "_p2_edge_count", 0),
            len(self.global_graph.edges),
        )

        # Boundary between (possibly non-evicted) Phase-2 edges and the
        # Phase-3 stitch edges appended below — used to canonically sort
        # only the Phase-3 tail after all steps run.
        _p3_edge_boundary = len(self.global_graph.edges)

        def _p3_step(name: str, fn) -> None:
            _t = time.perf_counter()
            fn()
            _log.info(
                "Phase 3 step %-45s  %.1fs  nodes=%d edges=%d",
                name,
                time.perf_counter() - _t,
                len(self.global_graph.nodes),
                len(self.global_graph.edges),
            )

        _p3_step("annotate_ecb_field_metadata",        lambda: self._annotate_ecb_field_metadata(self.global_graph))
        _p3_step("stitch_return_nodes",                lambda: self._stitch_return_nodes(contexts))
        _p3_step("stitch_memory_nodes",                lambda: self._stitch_memory_nodes())
        _p3_step("stitch_memory_nodes_by_access_id",   lambda: self._stitch_memory_nodes_by_access_identity())
        _p3_step("stitch_memory_struct_fields",        lambda: self._stitch_memory_struct_fields())
        _p3_step("materialize_asm_alias_struct_fields", lambda: self._materialize_asm_alias_struct_fields(contexts))
        _p3_step("stitch_asm_alias_struct_fields",     lambda: self._stitch_asm_alias_struct_fields(contexts))
        _p3_step("stitch_ecb_field_bindings",          lambda: self._stitch_ecb_field_bindings())
        _p3_step("stitch_ecb_ptr_cast_aliases",        lambda: self._stitch_ecb_ptr_cast_aliases())
        _p3_step("stitch_cpp_callarg_to_parameter_bridge", lambda: self._stitch_cpp_callarg_to_parameter_bridge())
        _p3_step("stitch_ref_write_back",              lambda: self._stitch_ref_write_back())
        _p3_step("stitch_floating_ref_write_back",     lambda: self._stitch_floating_ref_write_back())
        _p3_step("stitch_virtual_ref_write_back",      lambda: self._stitch_virtual_ref_write_back(contexts))
        _p3_step("stitch_tpf_regs_register_bridge",    lambda: self._stitch_tpf_regs_register_bridge(contexts))
        _p3_step("stitch_global_bindings",             lambda: self._stitch_global_bindings())
        _p3_step("stitch_glob_cross_file_deref",       lambda: self._stitch_glob_cross_file_deref())
        _p3_step("stitch_callarg_dsect_struct_fields", lambda: self._stitch_callarg_dsect_struct_fields())
        _p3_step("stitch_memory_variable_fields",      lambda: self._stitch_memory_variable_fields())
        _p3_step("stitch_data_level_buffers",          lambda: self._stitch_data_level_buffers(contexts))
        _p3_step("stitch_ce1cr_level_bindings",        lambda: self._stitch_ce1cr_level_bindings(contexts))
        _p3_step("stitch_ecb_slot_coop_aliases",       lambda: self._stitch_ecb_slot_coop_aliases())
        _p3_step("stitch_r15_return_receivers",        lambda: self._stitch_r15_return_receivers())
        _p3_step("stitch_creec_spawn_receivers",       lambda: self._stitch_creec_spawn_receivers())

        # Canonical order for the Phase-3 stitch edges.  The 15 passes above
        # iterate sets/dicts whose order is PYTHONHASHSEED-dependent, so the
        # same corpus appends these edges in a different order on every
        # rebuild — and GVL emission order feeds seed-capped consumers
        # downstream.  Sorting the tail (the Phase-2 prefix keeps its
        # deterministic merge order) makes the emitted GVL byte-stable.
        from dataclasses import fields as _dc_fields
        _edge_fields = None
        def _edge_key(e):
            nonlocal _edge_fields
            if _edge_fields is None:
                _edge_fields = [f.name for f in _dc_fields(e)]
            return tuple(str(getattr(e, f, None)) for f in _edge_fields)
        _tail = self.global_graph.edges[_p3_edge_boundary:]
        _tail.sort(key=_edge_key)
        self.global_graph.edges[_p3_edge_boundary:] = _tail

        _p2_evicted = getattr(self.global_graph, "_p2_edge_count", 0)
        _log.info(
            "GlobalLineageStitcher Phase 3 done in %.1fs: "
            "total graph has %d nodes, %d edges (%d base on disk + %d Phase-3 new)",
            time.perf_counter() - _p3_start,
            len(self.global_graph.nodes),
            _p2_evicted + len(self.global_graph.edges),
            _p2_evicted,
            len(self.global_graph.edges),
        )
        # Release Phase 3 working sets to allow GC of the compact dedup sets.
        self._phase3_edges = _CompactEdgeSet()
        self._phase3_level_edges = _CompactEdgeSet()
        self._cpp_level_buffers_cache = None
        self._asm_level_buffers_cache = None
        # Release pre-computed Phase-2 dicts (no longer needed after Phase 3).
        self._p2_ai_nodes = {}
        self._p2_slot_registers = {}
        self._p2_mem_reg_scoped = []
        self._p2_arg_bind_ca_mem = []
        self._p2_arg_bind_sf_ca = []
        self._p2_r15_candidates = {}

        _log.info(
            "GlobalLineageStitcher.process_contexts total time: %.1fs",
            time.perf_counter() - _t0,
        )
        return self.global_graph

    # ------------------------------------------------------------------
    # Phase-2 → Phase-3 edge eviction
    # ------------------------------------------------------------------

    def _prepare_phase3_from_phase2_edges(self) -> None:
        """Single pass over Phase-2 merged edges that does five things at once:

        1. Builds ``_phase3_edges`` and ``_phase3_level_edges`` (compact hash sets
           for O(1) dedup during Phase 3), replacing the old double-scan at
           Phase-3 start.
        2. Writes every Phase-2 edge to a temp msgpack file, then clears
           ``global_graph.edges``, freeing ~4–5 GB of RSS at 25K-file scale.
           The path and count are stored as ``global_graph._p2_edges_path`` /
           ``global_graph._p2_edge_count`` so ``_stream_write_gvl`` can stream
           them later without reloading into Python memory.
        3. Pre-computes ``_p2_ai_nodes`` for ``_stitch_memory_nodes_by_access_identity``.
        4. Pre-computes filtered edge lists for ``_stitch_callarg_dsect_struct_fields``:
           ``_p2_slot_registers``, ``_p2_mem_reg_scoped``,
           ``_p2_arg_bind_ca_mem``, ``_p2_arg_bind_sf_ca``.
        5. Pre-computes ``_p2_r15_candidates`` for ``_stitch_r15_return_receivers``.

        Falls back silently — keeping all edges in memory — when msgpack is
        unavailable or the temp-file write fails mid-way.

        When called after ``process_contexts()`` has already performed inline
        streaming during Phase 2, this method is a no-op — all five tasks were
        completed during the merge loop and ``_p2_streaming_done`` is True.
        """
        # If Phase-2 edges were streamed inline during the merge loop, all
        # dedup sets and pre-computed indices are already built.  Nothing to do.
        if self._p2_streaming_done:
            _log.debug(
                "GlobalLineageStitcher: _prepare_phase3_from_phase2_edges skipped "
                "(streaming was done inline during Phase 2)"
            )
            return

        import tempfile as _tempfile

        # Try to load msgpack for the edge-eviction path.
        try:
            import msgpack as _mp
            _packer = _mp.Packer(use_bin_type=True)
            _use_mp = True
        except ImportError:
            _packer = None
            _use_mp = False

        # Initialise compact dedup sets (replaces old Phase-3 double-scan).
        self._phase3_edges = _CompactEdgeSet()
        self._phase3_level_edges = _CompactEdgeSet()

        # Reset Phase-2 pre-computed data structures.
        self._p2_ai_nodes = {}
        self._p2_slot_registers = {}
        self._p2_mem_reg_scoped = []
        self._p2_arg_bind_ca_mem = []
        self._p2_arg_bind_sf_ca = []
        self._p2_r15_candidates = {}

        # Temp-file state for edge eviction.
        _p2_tmp_path: Optional[str] = None
        _p2_tmp_fh = None
        _p2_edge_count = 0
        _p2_write_ok = False

        if _use_mp and self.global_graph.edges:
            try:
                _tf = _tempfile.NamedTemporaryFile(
                    suffix=".p2edges.msgpack", delete=False, mode="wb"
                )
                _p2_tmp_path = _tf.name
                _p2_tmp_fh = _tf
                _p2_write_ok = True
            except Exception as exc:
                _log.debug(
                    "GlobalLineageStitcher: Phase-2 edge eviction disabled "
                    "(could not create temp file: %s)", exc,
                )

        for edge in self.global_graph.edges:
            # 1. Compact dedup sets.
            _ek = (edge.source, edge.target, edge.relation)
            self._phase3_edges.add(_ek)
            if edge.level_number is not None:
                self._phase3_level_edges.add(
                    (edge.source, edge.target, edge.relation, edge.level_number)
                )

            # 2. Temp-file write.
            if _p2_write_ok:
                try:
                    _p2_tmp_fh.write(_packer.pack(edge.to_dict()))
                    _p2_edge_count += 1
                except Exception:
                    _p2_write_ok = False  # abort eviction; edges stay in memory

            # 3. access_identity index for _stitch_memory_nodes_by_access_identity.
            if edge.access_identity:
                for _nid in (edge.source, edge.target):
                    self._p2_ai_nodes.setdefault(edge.access_identity, set()).add(_nid)

            # 4. Filtered edges for _stitch_callarg_dsect_struct_fields.
            if edge.relation == "assign" and edge.scope:
                _sk, _sn = self._split_node_id(edge.source)
                _dk, _dn = self._split_node_id(edge.target)
                if _sk == "memory" and _dk == "register":
                    _reg = self._normalize_register_name(_dn)
                    if _reg:
                        _slot = self._parse_caller_param_slot(_sn)
                        if _slot is not None:
                            self._p2_slot_registers.setdefault(
                                (edge.scope.upper(), _slot), set()
                            ).add(_reg)
                        self._p2_mem_reg_scoped.append(
                            (edge.scope.upper(), _sn.strip().upper(), _reg)
                        )
            elif edge.relation == "arg_bind":
                _sk, _sn = self._split_node_id(edge.source)
                _dk, _dn = self._split_node_id(edge.target)
                if _sk == "call_arg" and _dk == "memory" and edge.callee:
                    self._p2_arg_bind_ca_mem.append(
                        (edge.callee.upper(), edge.source, _dn)
                    )
                elif _sk == "struct_field" and _dk == "call_arg":
                    self._p2_arg_bind_sf_ca.append((edge.source, _sn, edge.target))

            # 5. R15 return bridge candidates.
            if (
                edge.relation == "assign"
                and edge.target.startswith("variable:")
                and not edge.target.startswith("variable:return@")
                and edge.source.startswith("return_value:return@")
            ):
                self._p2_r15_candidates.setdefault(edge.source, set()).add(edge.target)

        # Close and advise kernel to drop temp-file page cache.
        if _p2_tmp_fh is not None:
            try:
                _p2_tmp_fh.close()
                try:
                    with open(_p2_tmp_path, "rb") as _fh:
                        os.posix_fadvise(_fh.fileno(), 0, 0, 4)  # POSIX_FADV_DONTNEED
                except Exception:
                    pass
            except Exception:
                _p2_write_ok = False

        # Evict Phase-2 edges if the temp write completed without errors.
        _orig_count = len(self.global_graph.edges)
        if _p2_write_ok and _p2_edge_count == _orig_count:
            self.global_graph._p2_edges_path = _p2_tmp_path
            self.global_graph._p2_edge_count = _p2_edge_count
            self.global_graph.edges = []
            _log.info(
                "GlobalLineageStitcher: evicted %d Phase-2 edges to %s "
                "(freed ~%.1f GB RSS)",
                _p2_edge_count, _p2_tmp_path,
                _p2_edge_count * 180 / 1024 ** 3,
            )
        else:
            # Fallback: edges stay in memory; clean up any partial temp file.
            if _p2_tmp_path:
                try:
                    os.unlink(_p2_tmp_path)
                except Exception:
                    pass
            self.global_graph._p2_edges_path = None
            self.global_graph._p2_edge_count = 0
            _log.debug(
                "GlobalLineageStitcher: Phase-2 edge eviction skipped "
                "(msgpack=%s, write_ok=%s, expected=%d, written=%d)",
                _use_mp, _p2_write_ok, _orig_count, _p2_edge_count,
            )

    def _iter_symbols(self, context: AnalysisContext) -> Iterable[Tuple[str, str, str, str]]:
        """Yield symbols in a normalized form across legacy/new metadata layouts."""
        meta_symbols = context.get_metadata("symbol_table")
        if isinstance(meta_symbols, dict):
            for symbol_name, symbol_info in meta_symbols.items():
                if isinstance(symbol_info, dict):
                    symbol_type = str(symbol_info.get("type", "")).upper()
                    section = symbol_info.get("section")
                    definition_file = symbol_info.get("definition_file")
                    yield symbol_name, symbol_type, section, definition_file
            return

        symbol_table = context.symbol_table
        if isinstance(symbol_table, SymbolTable):
            for symbol in symbol_table.all_symbols:
                symbol_type = symbol.symbol_type
                if isinstance(symbol_type, SymbolType):
                    symbol_type = symbol_type.value.upper()
                else:
                    symbol_type = str(symbol_type).upper()
                definition_file = symbol.file or None
                yield symbol.name, symbol_type, symbol.section, definition_file

    # ------------------------------------------------------------------
    # Topology helpers – called by every Phase-3 stitch method.
    # ------------------------------------------------------------------

    def _bucket_pairs(self, names: List[str]) -> List[Tuple[str, str]]:
        """Return directed pairs to connect for a same-type equivalence bucket.

        ≤ _FULL_MESH_LIMIT nodes  →  full mesh (all ordered pairs, no self-loops).
        Larger buckets            →  bidirectional consecutive chain.

        Chain topology keeps edge count O(N) while preserving full BFS/DFS
        reachability through transitive closure: any node can reach any other
        in at most N-1 hops along the chain.
        """
        if len(names) <= self._FULL_MESH_LIMIT:
            return [(l, r) for l in names for r in names if l != r]
        pairs: List[Tuple[str, str]] = []
        for i in range(len(names) - 1):
            pairs.append((names[i], names[i + 1]))
            pairs.append((names[i + 1], names[i]))
        return pairs

    def _cross_bucket_pairs(
        self, names_a: List[str], names_b: List[str]
    ) -> List[Tuple[str, str]]:
        """Return (a, b) pairs to connect two buckets of *different* node kinds.

        Small combined size  →  full cross product (≤ _FULL_MESH_LIMIT² pairs).
        Large                →  fan topology:
            • every a-node connects to pivot_b (names_b[0])
            • pivot_a (names_a[0]) connects to every b-node

        BFS reachability from any a_i to any b_j is preserved through the
        same-type chain stitching that runs before cross-type stitching:
            a_i → pivot_b ← a_1 → b_j   (through memory chain a_i↔…↔a_1)
        Maximum hop distance from a_i to b_j: 3 hops.
        """
        if not names_a or not names_b:
            return []
        if len(names_a) * len(names_b) <= self._FULL_MESH_LIMIT ** 2:
            return [(a, b) for a in names_a for b in names_b]
        pivot_b = names_b[0]
        pivot_a = names_a[0]
        pairs: List[Tuple[str, str]] = [(a, pivot_b) for a in names_a]
        pairs.extend((pivot_a, b) for b in names_b[1:])
        return pairs

    def _stitch_return_nodes(self, contexts: Dict[str, AnalysisContext]) -> None:
        """Normalize return nodes and add cross-language glue edges."""
        existing_edges = self._phase3_edges

        def add_assign(src_name: str, src_kind: str, dst_name: str, dst_kind: str, file_hint: str, line_hint: int):
            src_id = self.global_graph.get_node_id(src_name, src_kind)
            dst_id = self.global_graph.get_node_id(dst_name, dst_kind)
            if not src_id or not dst_id:
                return
            key = (src_id, dst_id, "assign")
            if key in existing_edges:
                return
            self.global_graph.add_assignment(
                src_name, src_kind, dst_name, dst_kind,
                file=file_hint, line=line_hint,
                expression="global_lineage_stitch:return_unify",
                scope="(global_stitch)",
                statement_id="GLOBAL_STITCH_RETURN",
                macro_expansion_parent=None,
            )
            existing_edges.add(key)

        # Bridge `return_value:return@func:R15` to canonical `return_value:return@func`.
        for node in list(self.global_graph.nodes.values()):
            if node.kind != "return_value":
                continue
            if not node.name.startswith("return@"):
                continue
            if ":" in node.name:
                canonical = node.name.split(":", 1)[0]
                add_assign(node.name, "return_value", canonical, "return_value", "<global>", 0)
                add_assign(canonical, "return_value", node.name, "return_value", "<global>", 0)

        # Bridge legacy variable return nodes with return_value nodes.
        variable_returns = [n for n in self.global_graph.nodes.values() if n.kind == "variable" and n.name.startswith("return@")]
        for node in variable_returns:
            if self.global_graph.get_node_id(node.name, "return_value"):
                add_assign(node.name, "variable", node.name, "return_value", "<global>", 0)
                add_assign(node.name, "return_value", node.name, "variable", "<global>", 0)

        # Bridge return nodes across case/language spelling variants.
        return_nodes = [n for n in self.global_graph.nodes.values() if n.kind == "return_value" and n.name.startswith("return@")]
        buckets: Dict[str, List[str]] = {}
        for node in return_nodes:
            normalized = self._normalize_return_name(node.name)
            suffix = ""
            if ":" in node.name:
                suffix = node.name.split(":", 1)[1].lower()
            bucket_key = f"{normalized}:{suffix}" if suffix else normalized
            buckets.setdefault(bucket_key, []).append(node.name)

        for names in buckets.values():
            if len(names) < 2:
                continue
            for left, right in self._bucket_pairs(names):
                add_assign(left, "return_value", right, "return_value", "<global>", 0)

    def _stitch_memory_nodes(self) -> None:
        """Create glue edges for equivalent memory nodes across CSECT/DSECT boundaries."""
        existing_edges = self._phase3_edges
        memory_nodes = [n for n in self.global_graph.nodes.values() if n.kind == "memory"]
        buckets: Dict[str, List[str]] = {}
        for node in memory_nodes:
            canonical = self._normalize_memory_name(node.name)
            buckets.setdefault(canonical, []).append(node.name)

        for names in buckets.values():
            if len(names) < 2:
                continue
            for left, right in self._bucket_pairs(names):
                src_id = self.global_graph.get_node_id(left, "memory")
                dst_id = self.global_graph.get_node_id(right, "memory")
                if not src_id or not dst_id:
                    continue
                key = (src_id, dst_id, "assign")
                if key in existing_edges:
                    continue
                self.global_graph.add_assignment(
                    left, "memory", right, "memory",
                    file="<global>", line=0,
                    expression="global_lineage_stitch:memory_unify",
                    scope="(global_stitch)",
                    statement_id="GLOBAL_STITCH_MEMORY",
                    macro_expansion_parent=None,
                )
                existing_edges.add(key)

    def _stitch_memory_nodes_by_access_identity(self) -> None:
        """Create glue edges for memory nodes that share the same access_identity.

        access_identity (CE-slot:offset) is the stable cross-file key for physical
        memory identity. Two nodes with the same access_identity but different names
        (e.g., LG1OSI in one file, WB1FLAG in another) are the same physical byte.
        """
        existing_edges = self._phase3_edges

        # Group memory nodes by access_identity.
        # When Phase-2 edges have been evicted to disk, use the pre-built
        # _p2_ai_nodes dict (populated during _prepare_phase3_from_phase2_edges)
        # to avoid re-reading 4+ GB of edge data from disk.
        identity_to_nodes: Dict[str, Set[str]] = {}
        if getattr(self.global_graph, "_p2_edges_path", None) is not None:
            for identity, node_ids in self._p2_ai_nodes.items():
                for node_id in node_ids:
                    node = self.global_graph.nodes.get(node_id)
                    if node and node.kind == "memory":
                        identity_to_nodes.setdefault(identity, set()).add(node.name)
        else:
            for edge in self.global_graph.edges:
                if edge.access_identity:
                    for node_id in (edge.source, edge.target):
                        node = self.global_graph.nodes.get(node_id)
                        if node and node.kind == "memory":
                            identity_to_nodes.setdefault(edge.access_identity, set()).add(node.name)

        # Create alias edges between nodes with the same access_identity
        for identity, names in identity_to_nodes.items():
            if len(names) < 2:
                continue
            name_list = sorted(names)
            for left, right in self._bucket_pairs(name_list):
                src_id = self.global_graph.get_node_id(left, "memory")
                dst_id = self.global_graph.get_node_id(right, "memory")
                if not src_id or not dst_id:
                    continue
                key = (src_id, dst_id, "alias")
                if key in existing_edges:
                    continue
                self.global_graph.add_alias(
                    left, "memory", right, "memory",
                    file="<global>", line=0,
                    expression=f"access_identity_match:{identity}",
                    scope="(global_stitch)",
                    statement_id="GLOBAL_STITCH_ACCESS_IDENTITY",
                )
                existing_edges.add(key)
                # Annotate both nodes with the match classification
                self.global_graph.annotate_node(left, "memory", access_identity=identity)
                self.global_graph.annotate_node(right, "memory", access_identity=identity)

    def _stitch_memory_struct_fields(self) -> None:
        """Create glue edges between ASM memory labels and C/C++ struct fields."""
        existing_edges = self._phase3_edges
        memory_nodes = [n for n in self.global_graph.nodes.values() if n.kind == "memory"]
        struct_nodes = [n for n in self.global_graph.nodes.values() if n.kind == "struct_field"]

        memory_buckets: Dict[str, List[str]] = {}
        for node in memory_nodes:
            canonical = self._normalize_memory_name(node.name)
            memory_buckets.setdefault(canonical, []).append(node.name)

        struct_buckets: Dict[str, List[str]] = {}
        for node in struct_nodes:
            canonical = self._normalize_memory_name(node.name)
            struct_buckets.setdefault(canonical, []).append(node.name)

        shared_keys = set(memory_buckets.keys()) & set(struct_buckets.keys())
        for key in shared_keys:
            for mem_name, struct_name in self._cross_bucket_pairs(memory_buckets[key], struct_buckets[key]):
                src_id = self.global_graph.get_node_id(mem_name, "memory")
                dst_id = self.global_graph.get_node_id(struct_name, "struct_field")
                if not src_id or not dst_id:
                    continue
                forward = (src_id, dst_id, "assign")
                if forward not in existing_edges:
                    self.global_graph.add_assignment(
                        mem_name, "memory", struct_name, "struct_field",
                        file="<global>", line=0,
                        expression="global_lineage_stitch:memory_struct_bridge",
                        scope="(global_stitch)",
                        statement_id="GLOBAL_STITCH_MEMORY_STRUCT",
                        macro_expansion_parent=None,
                    )
                    existing_edges.add(forward)
                reverse = (dst_id, src_id, "assign")
                if reverse not in existing_edges:
                    self.global_graph.add_assignment(
                        struct_name, "struct_field", mem_name, "memory",
                        file="<global>", line=0,
                        expression="global_lineage_stitch:memory_struct_bridge",
                        scope="(global_stitch)",
                        statement_id="GLOBAL_STITCH_MEMORY_STRUCT",
                        macro_expansion_parent=None,
                    )
                    existing_edges.add(reverse)
                alias_forward = (src_id, dst_id, "alias")
                if alias_forward not in existing_edges:
                    self.global_graph.add_alias(
                        mem_name, "memory", struct_name, "struct_field",
                        file="<global>", line=0,
                        expression="global_lineage_stitch:memory_struct_alias",
                        scope="(global_stitch)",
                        statement_id="GLOBAL_STITCH_MEMORY_STRUCT_ALIAS",
                        macro_expansion_parent=None,
                    )
                    existing_edges.add(alias_forward)
                alias_reverse = (dst_id, src_id, "alias")
                if alias_reverse not in existing_edges:
                    self.global_graph.add_alias(
                        struct_name, "struct_field", mem_name, "memory",
                        file="<global>", line=0,
                        expression="global_lineage_stitch:memory_struct_alias",
                        scope="(global_stitch)",
                        statement_id="GLOBAL_STITCH_MEMORY_STRUCT_ALIAS",
                        macro_expansion_parent=None,
                    )
                    existing_edges.add(alias_reverse)
                self._add_ecb_bridge_edge(
                    source_name=mem_name,
                    source_kind="memory",
                    target_name=struct_name,
                    target_kind="struct_field",
                    existing_edges=existing_edges,
                )
                self._add_ecb_bridge_edge(
                    source_name=struct_name,
                    source_kind="struct_field",
                    target_name=mem_name,
                    target_kind="memory",
                    existing_edges=existing_edges,
                )

    def _stitch_memory_variable_fields(self) -> None:
        """Create glue edges between ASM memory labels and C/C++ variable field aliases."""
        existing_edges = self._phase3_edges
        memory_nodes = [n for n in self.global_graph.nodes.values() if n.kind == "memory"]
        variable_nodes = [n for n in self.global_graph.nodes.values() if n.kind == "variable"]

        memory_buckets: Dict[str, List[str]] = {}
        for node in memory_nodes:
            canonical = self._normalize_memory_name(node.name)
            memory_buckets.setdefault(canonical, []).append(node.name)

        variable_buckets: Dict[str, List[str]] = {}
        for node in variable_nodes:
            canonical = self._normalize_memory_name(node.name)
            variable_buckets.setdefault(canonical, []).append(node.name)

        for key in set(memory_buckets.keys()) & set(variable_buckets.keys()):
            for mem_name, var_name in self._cross_bucket_pairs(memory_buckets[key], variable_buckets[key]):
                src_id = self.global_graph.get_node_id(mem_name, "memory")
                dst_id = self.global_graph.get_node_id(var_name, "variable")
                if not src_id or not dst_id:
                    continue
                pair = (src_id, dst_id, "assign")
                if pair in existing_edges:
                    continue
                self.global_graph.add_assignment(
                    mem_name, "memory", var_name, "variable",
                    file="<global>", line=0,
                    expression="global_lineage_stitch:memory_variable_bridge",
                    scope="(global_stitch)",
                    statement_id="GLOBAL_STITCH_MEMORY_VARIABLE",
                    macro_expansion_parent=None,
                )
                existing_edges.add(pair)
                self._add_ecb_bridge_edge(
                    source_name=mem_name,
                    source_kind="memory",
                    target_name=var_name,
                    target_kind="variable",
                    existing_edges=existing_edges,
                )
                self._add_ecb_bridge_edge(
                    source_name=var_name,
                    source_kind="variable",
                    target_name=mem_name,
                    target_kind="memory",
                    existing_edges=existing_edges,
                )

    def _materialize_asm_alias_struct_fields(self, contexts: Dict[str, AnalysisContext]) -> None:
        """Materialize alias-backed C++ fields as canonical struct_field nodes.

        Some fields only exist in `field_asm_aliases` metadata pulled from cc*.hpp
        headers and never appear in local `.cpp` assignments. Create a stable
        declaration-like struct_field node for those aliases so the stitched graph
        stays probeable from either ASM or C++.
        """
        existing_edges = self._phase3_edges
        materialized_fields: Set[str] = set()

        # Pre-build a suffix-token index over all existing struct_field nodes so
        # the inner "find matching node" scan is O(index lookup) instead of O(all_nodes).
        # Index: tuple(suffix_tokens) -> list of struct_field nodes whose name ends with
        # those tokens.  Built once before the outer loop; new nodes materialized inside
        # the loop are skipped (they have no struct_field bridge candidates yet).
        _sf_suffix_index: Dict[tuple, list] = {}
        for _sfn in self.global_graph.nodes.values():
            if _sfn.kind != "struct_field":
                continue
            _sft = self._field_path_tokens(_sfn.name)
            for _sfl in range(1, len(_sft) + 1):
                _sfk = tuple(_sft[-_sfl:])
                _sf_suffix_index.setdefault(_sfk, []).append(_sfn)

        for file_path, context in contexts.items():
            unit = context.get_metadata("c_family_unit")
            if unit is None:
                continue

            field_aliases = getattr(unit, "field_asm_aliases", {}) or {}
            field_sources = getattr(unit, "field_asm_alias_sources", {}) or {}
            for cpp_field, asm_name in field_aliases.items():
                cpp_field_name = str(cpp_field or "").strip()
                asm_field_name = str(asm_name or "").strip()
                if not cpp_field_name or not asm_field_name:
                    continue

                type_name = cpp_field_name.split(".", 1)[0] if "." in cpp_field_name else ""
                self.global_graph.annotate_node(
                    cpp_field_name,
                    "struct_field",
                    asm_alias=asm_field_name,
                    enclosing_type=type_name or None,
                    alias_materialized=True,
                    alias_source="field_asm_aliases",
                    hpp_source=str(field_sources.get(cpp_field_name) or ""),
                )
                if cpp_field_name not in materialized_fields:
                    materialized_fields.add(cpp_field_name)
                    self.global_graph.add_definition(
                        cpp_field_name,
                        "struct_field",
                        file=str(field_sources.get(cpp_field_name) or file_path),
                        line=0,
                        expression="global_lineage_stitch:materialized_cpp_field_alias",
                        scope=type_name or "(global_stitch)",
                        statement_id="GLOBAL_STITCH_MATERIALIZED_CPP_FIELD",
                        macro_expansion_parent=None,
                    )

                if self.global_graph.get_node_id(asm_field_name, "memory"):
                    self._add_memory_struct_bridge_pair(
                        mem_name=asm_field_name,
                        struct_name=cpp_field_name,
                        expression="global_lineage_stitch:materialized_cpp_field_to_asm",
                        statement_id="GLOBAL_STITCH_MATERIALIZED_CPP_FIELD_ASM",
                        existing_edges=existing_edges,
                    )

                alias_tokens = self._field_path_tokens(cpp_field_name)
                if not alias_tokens:
                    continue
                alias_key = tuple(alias_tokens)
                asm_upper = asm_field_name.upper()
                for node in _sf_suffix_index.get(alias_key, []):
                    if node.name == cpp_field_name:
                        continue
                    node_alias = str((node.metadata or {}).get("asm_alias") or "").strip().upper()
                    if node_alias and node_alias != asm_upper:
                        continue
                    self._add_struct_field_bridge_pair(
                        left_name=node.name,
                        right_name=cpp_field_name,
                        expression="global_lineage_stitch:materialized_cpp_field_runtime_bridge",
                        statement_id="GLOBAL_STITCH_MATERIALIZED_CPP_FIELD_RUNTIME",
                        existing_edges=existing_edges,
                    )

    def _stitch_asm_alias_struct_fields(self, contexts: Dict[str, AnalysisContext]) -> None:
        """Phase 4: bridge C++ struct_field nodes to ASM memory nodes via asm_alias metadata.

        Phase 3 attached `metadata.asm_alias="WK_CMO"` and
        `metadata.enclosing_type="Da7gl"` to struct_field nodes when a cc*.hpp
        mapping was found. Here we materialize those annotations as actual
        `alias` edges from the C++ node to the ASM `memory` node (when the
        latter exists in the merged graph). Edge is scoped to the enclosing
        C++ function; no dangling edges.
        """
        file_aliases: Dict[str, Dict[str, str]] = {}
        function_file: Dict[str, str] = {}
        for fp, ctx in contexts.items():
            unit = ctx.get_metadata("c_family_unit")
            if not unit:
                continue
            file_aliases[fp] = dict(getattr(unit, "symbol_aliases", {}) or {})
            for func in getattr(unit, "functions", []) or []:
                function_file[func.name] = fp

        for node in list(self.global_graph.nodes.values()):
            if node.kind != "struct_field":
                continue
            asm_name = (node.metadata or {}).get("asm_alias")
            if not asm_name:
                continue
            asm_node_id = self.global_graph.get_node_id(asm_name, "memory")
            if not asm_node_id:
                continue

            name = node.name
            owner = name.split("::", 1)[0].lstrip("*") if "::" in name else ""
            scope = owner or None

            via_call: Optional[str] = None
            fp = function_file.get(owner) if owner else None
            if fp:
                for _callable, asm_alias in file_aliases.get(fp, {}).items():
                    if asm_alias and self.global_graph.get_node_id(asm_alias, "function"):
                        via_call = asm_alias
                        break

            _alias_key = (node.node_id, asm_node_id, "alias")
            if _alias_key in self._phase3_edges:
                continue
            self._phase3_edges.add(_alias_key)

            self.global_graph.add_alias(
                node.name, "struct_field",
                asm_name, "memory",
                file=fp or "(global_stitch)",
                line=0,
                expression="global_lineage_stitch:cpp_field_to_asm",
                scope=scope,
                statement_id="GLOBAL_STITCH_CPP_FIELD_ASM",
                macro_expansion_parent=None,
            )
            annotate_kwargs: Dict[str, object] = {
                "asm_alias_linked": True,
                "alias_type": "cpp_field_to_asm",
            }
            if via_call:
                annotate_kwargs["via_call"] = via_call
            self.global_graph.annotate_node(node.name, "struct_field", **annotate_kwargs)

    def _stitch_ecb_field_bindings(self) -> None:
        """Phase 6 — bridge C++ ECB struct-field nodes (``ecbptr->ce1crN``,
        ``ebsw01``, etc.) to their ASM memory counterparts using the canonical
        ECB_FIELD_TO_ASM table.

        For every ``struct_field`` node whose trailing field-name token
        matches a table key:
          - stamp ``metadata.ecb_alias`` and ``metadata.alias_type`` on the
            node (documentation — useful even when the ASM side isn't loaded);
          - if the corresponding ``memory:<ASM>`` node exists in the merged
            graph, emit a scoped ``alias`` edge identical in shape to the
            Phase-4 cpp_field_to_asm edges, tagged ``cpp_ecb_to_asm``.
        """
        try:
            from passes.ecb_alias_table import ECB_FIELD_TO_ASM
        except ImportError:
            return

        for node in list(self.global_graph.nodes.values()):
            # C++ emits ECB field accesses in three shapes depending on the
            # expression form: `ecbptr()->ebsw01` lands as struct_field,
            # `ecbptr()->ce1cr7` in a cast/deref chain often lands as
            # variable (bare trailing token), and `ecbptr()->ce1usa[10]`
            # lands as array_element.  Accept all three.
            if node.kind not in ("struct_field", "variable", "array_element"):
                continue
            # Extract the final field-name token from names like
            # "globalLimitsUpdate::ecbptr->ce1cr7" or "*f::ecbptr->ebsw01"
            # or "globalLimitsUpdate::ce1cr7" (variable form)
            # or "getEcrSupplement::ecbptr()->ce1usa[10]" (array_element form).
            tail = node.name.split("::")[-1]
            for sep in ("->", "."):
                tail = tail.split(sep)[-1]
            tail = tail.lstrip("*").strip().lower()
            # Strip array subscripts before table lookup so ce1usa[10] is
            # looked up as ce1usa.  Also capture the index for array_element
            # nodes so we can compute the offset ASM name (CE1USA+10).
            _arr_m = re.search(r"\[(\d+)\]$", tail)
            _arr_index: Optional[int] = int(_arr_m.group(1)) if _arr_m else None
            tail_bare = re.sub(r"\[\d+\]", "", tail)
            asm_name = ECB_FIELD_TO_ASM.get(tail_bare)
            if not asm_name:
                # EBW000–EBWFFF and EBX000–EBXFFF are not in the table;
                # map them directly to their uppercase ASM memory label.
                if tail_bare.startswith(("ebw", "ebx")):
                    asm_name = tail_bare.upper()
                else:
                    continue
            # Append the byte offset when a [N] subscript is present, regardless
            # of the node kind.  The c_family_parser may emit ce1usa[3] as any of
            # struct_field, variable, or array_element; all three should resolve to
            # CE1USA+3.  Previously only array_element triggered this path (Pattern B fix).
            if _arr_index is not None:
                asm_name = f"{asm_name}+{_arr_index}"

            # Always annotate — preserves mapping as documentation even when
            # the ASM memory node is absent from the analyzed set.
            self.global_graph.annotate_node(
                node.name, node.kind,
                ecb_alias=asm_name,
                alias_type="cpp_ecb_to_asm",
            )

            asm_node_id = self.global_graph.get_node_id(asm_name, "memory")
            if not asm_node_id:
                continue

            _alias_key = (node.node_id, asm_node_id, "alias")
            if _alias_key in self._phase3_edges:
                continue
            self._phase3_edges.add(_alias_key)

            scope = node.name.split("::", 1)[0] if "::" in node.name else None
            self.global_graph.add_alias(
                node.name, node.kind,
                asm_name, "memory",
                file="(ecb_alias_table)",
                line=0,
                expression="global_lineage_stitch:cpp_ecb_to_asm",
                scope=scope,
                statement_id="GLOBAL_STITCH_ECB",
                macro_expansion_parent=None,
            )

        # Pattern C fix: emit pairwise CPP↔CPP alias edges between any two C++
        # struct_field/variable nodes that were annotated with the same
        # ecb_alias value.  The existing loop only bridged CPP→ASM; two CPP
        # files accessing the same ECB byte range (e.g. l7l7l->returnCode in
        # dw710000.cpp and ecbOverlay->returnCode in dw710300.cpp) had no edge
        # connecting them.  Grouping by asm_name gives us that for free.
        nodes_by_ecb_alias: Dict[str, list] = {}
        for node in self.global_graph.nodes.values():
            _ea = (node.metadata or {}).get("ecb_alias")
            if _ea:
                nodes_by_ecb_alias.setdefault(_ea, []).append(node)

        for _asm_key, _cpp_nodes in nodes_by_ecb_alias.items():
            if len(_cpp_nodes) < 2:
                continue
            for _i in range(len(_cpp_nodes)):
                for _j in range(_i + 1, len(_cpp_nodes)):
                    _na = _cpp_nodes[_i]
                    _nb = _cpp_nodes[_j]
                    _fwd = (_na.node_id, _nb.node_id, "alias")
                    _rev = (_nb.node_id, _na.node_id, "alias")
                    _scope_a = _na.name.split("::", 1)[0] if "::" in _na.name else None
                    if _fwd not in self._phase3_edges:
                        self._phase3_edges.add(_fwd)
                        self.global_graph.add_alias(
                            _na.name, _na.kind,
                            _nb.name, _nb.kind,
                            file="(ecb_alias_table)",
                            line=0,
                            expression="global_lineage_stitch:cpp_ecb_cpp_alias",
                            scope=_scope_a,
                            statement_id="GLOBAL_STITCH_ECB_CPP",
                            macro_expansion_parent=None,
                        )
                    if _rev not in self._phase3_edges:
                        self._phase3_edges.add(_rev)
                        self.global_graph.add_alias(
                            _nb.name, _nb.kind,
                            _na.name, _na.kind,
                            file="(ecb_alias_table)",
                            line=0,
                            expression="global_lineage_stitch:cpp_ecb_cpp_alias",
                            scope=_scope_a,
                            statement_id="GLOBAL_STITCH_ECB_CPP",
                            macro_expansion_parent=None,
                        )

    def _stitch_ecb_ptr_cast_aliases(self) -> None:
        """Bridge ECB raw-pointer-cast accesses to their ASM memory nodes.

        When C++ code casts an ECB region to a typed struct pointer:

            SomeStruct *p = (SomeStruct*)ecbptr()->ebw000;
            p->someField   = value;

        ``_stitch_ecb_field_bindings`` annotates ``ecbptr()->ebw000`` with
        ``ecb_alias=EBW000``, but the downstream ``p->someField`` struct_field
        node receives no annotation because ``someField`` is absent from
        ``ECB_FIELD_TO_ASM`` and does not start with the EBW/EBX prefix.

        This pass propagates the ``ecb_alias`` from the ECB expression node
        through the variable assignment edge to every struct_field/variable
        node that is accessed through the aliased pointer:

            struct_field: ecbptr()->ebw000   (ecb_alias = EBW000)
                   ↓ assign
            variable:     ptrVar
                   ↓  (name contains "ptrVar->" or "ptrVar.")
            struct_field: funcScope::ptrVar->someField  → ecb_alias = EBW000

        If the corresponding ``memory:EBW000`` ASM node exists, an alias edge
        is emitted so the stitcher bridges the C++ field to the ASM region.

        ASM-CPP Patterns B and F fix: covers the raw pointer cast case that
        ``_stitch_ecb_field_bindings`` cannot handle via the prefix fallback.
        """
        # Step 1: collect all nodes already annotated with an ecb_alias.
        ecb_alias_by_node_id: Dict[str, str] = {}
        for node in self.global_graph.nodes.values():
            ea = (node.metadata or {}).get("ecb_alias")
            if ea:
                ecb_alias_by_node_id[node.node_id] = str(ea)

        if not ecb_alias_by_node_id:
            return

        # Step 2: find assign edges FROM annotated ECB nodes TO variable nodes.
        # These represent: ecbptr()->ebw000  →  ptrVar  (pointer assignment).
        ecb_alias_by_ptr_name: Dict[str, str] = {}  # "scopedPtrName" → asm_name
        for edge in self.global_graph.edges:
            if edge.relation != "assign":
                continue
            asm_name = ecb_alias_by_node_id.get(edge.source)
            if not asm_name:
                continue
            dst_k, dst_n = self._split_node_id(edge.target)
            if dst_k != "variable":
                continue
            ecb_alias_by_ptr_name[dst_n] = asm_name

        if not ecb_alias_by_ptr_name:
            return

        # Step 3: find struct_field/variable nodes accessed through the pointer.
        # Match "scope::ptrVar->field" and "scope::ptrVar.field" (both separators).
        propagated: list = []  # list of (node_name, node_kind, asm_name)
        for node in self.global_graph.nodes.values():
            if node.kind not in ("struct_field", "variable"):
                continue
            if (node.metadata or {}).get("ecb_alias"):
                continue  # already annotated; skip
            node_name = node.name
            for ptr_name, asm_name in ecb_alias_by_ptr_name.items():
                ptr_tail = ptr_name.split("::")[-1]
                for sep in ("->", "."):
                    if (f"::{ptr_tail}{sep}" in node_name
                            or node_name.startswith(f"{ptr_tail}{sep}")):
                        propagated.append((node_name, node.kind, asm_name))
                        break

        if not propagated:
            return

        # Step 4: annotate each matched node and emit alias edge if ASM node present.
        for node_name, node_kind, asm_name in propagated:
            self.global_graph.annotate_node(
                node_name, node_kind,
                ecb_alias=asm_name,
                alias_type="cpp_ecb_ptr_cast",
            )
            asm_node_id = self.global_graph.get_node_id(asm_name, "memory")
            if not asm_node_id:
                continue
            src_node_id = self.global_graph.get_node_id(node_name, node_kind)
            if not src_node_id:
                continue
            _alias_key = (src_node_id, asm_node_id, "alias")
            if _alias_key in self._phase3_edges:
                continue
            self._phase3_edges.add(_alias_key)
            scope = node_name.split("::", 1)[0] if "::" in node_name else None
            self.global_graph.add_alias(
                node_name, node_kind,
                asm_name, "memory",
                file="(ecb_ptr_cast)",
                line=0,
                expression="global_lineage_stitch:cpp_ecb_ptr_cast",
                scope=scope,
                statement_id="GLOBAL_STITCH_ECB_PTR_CAST",
                macro_expansion_parent=None,
            )

    def _stitch_tpf_regs_register_bridge(
        self, contexts: Dict[str, AnalysisContext]
    ) -> None:
        """Bridge `arg@<callee>:R<n>` / `return@<callee>:R<n>` nodes (emitted
        by ``model_tpf_regs_passthrough`` in the C++ lineage builder) to the
        ASM-side ``register:R<n>`` node — narrow scoped alias, not a shared
        global one. Mirrors Phase 4 / Phase 6 shape.

        Always annotates the arg/return node with ``bridge_to`` +
        ``callee_asm`` metadata (useful even when no ASM register node is
        available). Creates an alias edge only when the ASM register node
        exists in the merged graph. Scope = callee name so downstream
        traversers can disambiguate multiple routines sharing the same
        shared ``register:R<n>`` node.
        """
        import re

        # Union of symbol_aliases across all cpp units — lets us translate
        # a C++ callable name to its ASM routine label.
        alias_map: Dict[str, str] = {}
        for ctx in contexts.values():
            unit = ctx.get_metadata("c_family_unit")
            if unit is None:
                continue
            for k, v in (getattr(unit, "symbol_aliases", {}) or {}).items():
                if k and v:
                    alias_map.setdefault(str(k), str(v))

        node_pattern = re.compile(
            r"^(?P<kind>arg|return)@(?P<callee>[A-Za-z_]\w*):R(?P<num>\d+)$"
        )

        for node in list(self.global_graph.nodes.values()):
            m = node_pattern.match(node.name)
            if not m:
                continue
            callee = m.group("callee")
            reg = f"R{m.group('num')}"
            asm_routine = alias_map.get(callee) or callee

            # Documentation metadata — always stamped.
            self.global_graph.annotate_node(
                node.name, node.kind,
                bridge_to=reg,
                callee_asm=asm_routine,
                alias_type="cpp_tpf_regs_to_asm",
            )

            # Edge only when the ASM register node actually exists.
            # If the ASM file never used this register explicitly, emit a
            # synthetic definition so the bridge can still be created —
            # Pattern A fix: don't silently skip unloaded parameter slots.
            asm_reg_id = self.global_graph.get_node_id(reg, "register")
            if not asm_reg_id:
                self.global_graph.add_definition(
                    reg, "register",
                    file="(synthetic_tpf_regs_bridge)",
                    line=0,
                    expression=f"synthetic: {asm_routine} ENTRC declares {reg} as parameter slot",
                    scope=asm_routine,
                    statement_id=f"SYNTHETIC_REG_{reg}_{asm_routine}",
                    macro_expansion_parent=None,
                )
                asm_reg_id = self.global_graph.get_node_id(reg, "register")
            _alias_key = (node.node_id, asm_reg_id, "alias")
            if _alias_key in self._phase3_edges:
                continue
            self._phase3_edges.add(_alias_key)
            self.global_graph.add_alias(
                node.name, node.kind,
                reg, "register",
                file="(tpf_regs_bridge)",
                line=0,
                expression="global_lineage_stitch:tpf_regs_register_bridge",
                scope=callee,
                statement_id="GLOBAL_STITCH_TPF_REGS",
                macro_expansion_parent=None,
            )

    def _stitch_global_bindings(self) -> None:
        """Phase 7 — bridge C++ ``global:<NAME>`` nodes (emitted from
        ``glob(_name)`` calls) to the matching ASM ``memory:<NAME>`` node
        when both are present in the merged graph. Annotation (``alias_type``)
        is always stamped so the mapping is visible even when the ASM side
        isn't loaded."""
        for node in list(self.global_graph.nodes.values()):
            if node.kind != "global":
                continue
            self.global_graph.annotate_node(
                node.name, "global",
                alias_type="cpp_global_to_asm",
            )
            asm_node_id = self.global_graph.get_node_id(node.name, "memory")
            if not asm_node_id:
                continue
            _alias_key = (node.node_id, asm_node_id, "alias")
            if _alias_key in self._phase3_edges:
                continue
            self._phase3_edges.add(_alias_key)
            self.global_graph.add_alias(
                node.name, "global",
                node.name, "memory",
                file="(glob_bindings)",
                line=0,
                expression="global_lineage_stitch:cpp_global_to_asm",
                scope="system",
                statement_id="GLOBAL_STITCH_GLOB",
                macro_expansion_parent=None,
            )

    def _stitch_glob_cross_file_deref(self) -> None:
        """GAP-D: Propagate glob()-alias metadata across C++ call boundaries.

        When TU-A stores ``ptr = glob(_NAME)`` and passes ``ptr`` as an
        argument to TU-B's function, TU-B dereferences it as ``*param``.
        The intra-TU alias ``global:NAME ↔ memory:*ptr`` is invisible in
        TU-B because ``_glob_ptr_map`` is per-TU state.

        This pass closes the gap by following the arg_bind / ARG_BRIDGE chain:

          variable:ptr  →arg_bind→  call_arg:F#N
          call_arg:F#N  →assign→    parameter:arg@F:RN      (B-1 bridge)
          parameter:arg@F:RN  →assign→  parameter:F::p      (ARG_BRIDGE)
          look up memory:*F::p  →  emit global:NAME ↔ memory:*F::p
        """
        # Step 1: collect all glob-aliased variable nodes {node_id -> glob_name}.
        glob_aliased: Dict[str, str] = {}
        for node in self.global_graph.nodes.values():
            if node.kind != "variable":
                continue
            g = (node.metadata or {}).get("glob_alias")
            if g:
                glob_aliased[node.node_id] = str(g)

        if not glob_aliased:
            return

        # Step 2: follow arg_bind edges to call_arg nodes.
        # callarg_to_glob: {call_arg_node_id -> glob_name}
        callarg_to_glob: Dict[str, str] = {}
        for edge in self.global_graph.edges:
            if edge.relation != "arg_bind":
                continue
            if edge.source in glob_aliased:
                callarg_to_glob[edge.target] = glob_aliased[edge.source]

        if not callarg_to_glob:
            return

        # Step 3: follow B-1 assign edges call_arg → parameter:arg@F:RN.
        # callarg_to_param: {call_arg_node_id -> parameter_node_id}
        callarg_to_param: Dict[str, str] = {}
        for edge in self.global_graph.edges:
            if edge.relation != "assign":
                continue
            if edge.source not in callarg_to_glob:
                continue
            tgt = self.global_graph.nodes.get(edge.target)
            if tgt and tgt.kind == "parameter":
                callarg_to_param[edge.source] = edge.target

        if not callarg_to_param:
            return

        # Reverse map: param_node_id -> glob_name (for ARG_BRIDGE scan).
        param_ids_of_interest: Dict[str, str] = {}
        for ca_id, param_id in callarg_to_param.items():
            if ca_id in callarg_to_glob:
                param_ids_of_interest[param_id] = callarg_to_glob[ca_id]

        # Step 4: follow ARG_BRIDGE assign edges parameter:arg@F:RN → parameter:F::p.
        # param_to_callee_params: {arg_param_node_id -> [callee_param_node_id, ...]}
        param_to_callee_params: Dict[str, List[str]] = {}
        for edge in self.global_graph.edges:
            if edge.relation != "assign":
                continue
            if not (edge.statement_id or "").endswith("_ARG_BRIDGE"):
                continue
            if edge.source not in param_ids_of_interest:
                continue
            param_to_callee_params.setdefault(edge.source, []).append(edge.target)

        # Step 5: for each callee param node, look up memory:*param_name and emit alias.
        for ca_id, glob_name in callarg_to_glob.items():
            param_node_id = callarg_to_param.get(ca_id)
            if not param_node_id:
                continue
            callee_param_ids = param_to_callee_params.get(param_node_id, [])
            for cp_id in callee_param_ids:
                cp_node = self.global_graph.nodes.get(cp_id)
                if not cp_node:
                    continue
                cp_name = cp_node.name  # e.g. "funcName::paramName"
                # Build candidate deref names: *funcName::paramName, *paramName
                candidates = {f"*{cp_name}"}
                if "::" in cp_name:
                    candidates.add(f"*{cp_name.split('::', 1)[1]}")
                for cand in candidates:
                    deref_id = self.global_graph.get_node_id(cand, "memory")
                    if not deref_id:
                        continue
                    glob_node_id = f"global:{glob_name}"
                    fwd = (glob_node_id, deref_id, "alias")
                    if fwd not in self._phase3_edges:
                        self._phase3_edges.add(fwd)
                        self.global_graph.add_alias(
                            glob_name, "global",
                            cand, "memory",
                            file="(glob_cross_file_deref)",
                            line=0,
                            expression="global_lineage_stitch:glob_cross_file_deref",
                            scope="(global_stitch)",
                            statement_id="GLOBAL_STITCH_GLOB_XFILE",
                            macro_expansion_parent=None,
                        )
                    rev = (deref_id, glob_node_id, "alias")
                    if rev not in self._phase3_edges:
                        self._phase3_edges.add(rev)
                        self.global_graph.add_alias(
                            cand, "memory",
                            glob_name, "global",
                            file="(glob_cross_file_deref)",
                            line=0,
                            expression="global_lineage_stitch:glob_cross_file_deref:reverse",
                            scope="(global_stitch)",
                            statement_id="GLOBAL_STITCH_GLOB_XFILE",
                            macro_expansion_parent=None,
                        )

    def _stitch_callarg_dsect_struct_fields(self) -> None:
        """Bridge C/C++ struct fields to ASM DSECT fields through call-arg slot + USING mapping."""
        existing_edges = self._phase3_edges

        memory_nodes = [n for n in self.global_graph.nodes.values() if n.kind == "memory"]

        dsect_fields_by_name: Dict[str, Set[str]] = {}
        for node in memory_nodes:
            md = node.metadata or {}
            dsect_name = md.get("cpp_struct")
            byte_offset = md.get("byte_offset")
            if not dsect_name or byte_offset is None:
                continue
            dsect_key = str(dsect_name).strip().upper()
            if not dsect_key:
                continue
            dsect_fields_by_name.setdefault(dsect_key, set()).add(node.name)
            # Persist explicit DSECT metadata for downstream consumers.
            self.global_graph.annotate_node(node.name, "memory", dsect=dsect_key, byte_offset=byte_offset)

        if not dsect_fields_by_name:
            return

        # When Phase-2 edges have been evicted to disk, use pre-built compact
        # structures from _prepare_phase3_from_phase2_edges; otherwise fall
        # back to the original four edge-iteration loops.
        _use_pre = getattr(self.global_graph, "_p2_edges_path", None) is not None

        # Map (callee_scope, param_slot) -> base register(s), inferred from ASM loads.
        if _use_pre:
            slot_registers = dict(self._p2_slot_registers)  # already built in Phase 2
        else:
            slot_registers: Dict[Tuple[str, int], Set[str]] = {}
            for edge in self.global_graph.edges:
                if edge.relation != "assign":
                    continue
                if not edge.scope:
                    continue
                src_kind, src_name = self._split_node_id(edge.source)
                dst_kind, dst_name = self._split_node_id(edge.target)
                if src_kind != "memory" or dst_kind != "register":
                    continue
                slot = self._parse_caller_param_slot(src_name)
                if slot is None:
                    continue
                reg_name = self._normalize_register_name(dst_name)
                if not reg_name:
                    continue
                key = (edge.scope.upper(), slot)
                slot_registers.setdefault(key, set()).add(reg_name)

        # Map (callee_scope, param_slot) -> DSECT name(s).
        slot_dsects: Dict[Tuple[str, int], Set[str]] = {}
        if _use_pre:
            # _p2_mem_reg_scoped = [(scope_upper, dsect_key, reg_name)]
            for scope_up, dsect_key, reg_name in self._p2_mem_reg_scoped:
                if dsect_key not in dsect_fields_by_name:
                    continue
                for (callee_scope, slot), regs in slot_registers.items():
                    if callee_scope != scope_up:
                        continue
                    if reg_name in regs:
                        slot_dsects.setdefault((callee_scope, slot), set()).add(dsect_key)
        else:
            for edge in self.global_graph.edges:
                if edge.relation != "assign":
                    continue
                if not edge.scope:
                    continue
                src_kind, src_name = self._split_node_id(edge.source)
                dst_kind, dst_name = self._split_node_id(edge.target)
                if src_kind != "memory" or dst_kind != "register":
                    continue
                reg_name = self._normalize_register_name(dst_name)
                if not reg_name:
                    continue
                dsect_key = src_name.strip().upper()
                if dsect_key not in dsect_fields_by_name:
                    continue
                scope_key = edge.scope.upper()
                for (callee_scope, slot), regs in slot_registers.items():
                    if callee_scope != scope_key:
                        continue
                    if reg_name in regs:
                        slot_dsects.setdefault((callee_scope, slot), set()).add(dsect_key)

        if not slot_dsects:
            return

        # Map call_arg node -> (callee_scope, param_slot).
        call_arg_slots: Dict[str, Tuple[str, int]] = {}
        if _use_pre:
            # _p2_arg_bind_ca_mem = [(callee_upper, src_id, dst_name)]
            for callee_up, src_id, dst_name in self._p2_arg_bind_ca_mem:
                slot = self._parse_caller_param_slot(dst_name)
                if slot is None:
                    continue
                call_arg_slots[src_id] = (callee_up, slot)
        else:
            for edge in self.global_graph.edges:
                if edge.relation != "arg_bind":
                    continue
                if not edge.callee:
                    continue
                src_kind, src_name = self._split_node_id(edge.source)
                dst_kind, dst_name = self._split_node_id(edge.target)
                if src_kind != "call_arg" or dst_kind != "memory":
                    continue
                slot = self._parse_caller_param_slot(dst_name)
                if slot is None:
                    continue
                call_arg_slots[edge.source] = (edge.callee.upper(), slot)

        if not call_arg_slots:
            return

        # Map call_arg node -> struct field node names handed off at callsite.
        struct_fields_by_call_arg: Dict[str, Set[str]] = {}
        if _use_pre:
            # _p2_arg_bind_sf_ca = [(src_id, src_name, dst_id)]
            for src_id, src_name, dst_id in self._p2_arg_bind_sf_ca:
                if dst_id not in call_arg_slots:
                    continue
                struct_fields_by_call_arg.setdefault(dst_id, set()).add(src_name)
        else:
            for edge in self.global_graph.edges:
                if edge.relation != "arg_bind":
                    continue
                src_kind, src_name = self._split_node_id(edge.source)
                dst_kind, _ = self._split_node_id(edge.target)
                if src_kind != "struct_field" or dst_kind != "call_arg":
                    continue
                if edge.target not in call_arg_slots:
                    continue
                struct_fields_by_call_arg.setdefault(edge.target, set()).add(src_name)

        # Pattern B fix: variable-kind arg_bind bridge.
        # When a TPF_regs* pointer is passed as a variable (not a struct_field directly),
        # the loops above miss it because they filter on struct_field sources only.
        # Build a one-time index of struct_field→variable assign edges, then supplement
        # struct_fields_by_call_arg with the struct_fields that fed into any variable
        # later arg-bound into a call_arg slot.
        _var_sf_index: Dict[str, Set[str]] = {}
        for _be in self.global_graph.edges:
            if _be.relation != "assign":
                continue
            _bsk, _bsn = self._split_node_id(_be.source)
            _btk, _ = self._split_node_id(_be.target)
            if _bsk == "struct_field" and _btk == "variable":
                _var_sf_index.setdefault(_be.target, set()).add(_bsn)
        for _be in self.global_graph.edges:
            if _be.relation != "arg_bind":
                continue
            _bsk, _ = self._split_node_id(_be.source)
            _bdk, _ = self._split_node_id(_be.target)
            if _bsk != "variable" or _bdk != "call_arg":
                continue
            if _be.target not in call_arg_slots:
                continue
            for _sf in _var_sf_index.get(_be.source, set()):
                struct_fields_by_call_arg.setdefault(_be.target, set()).add(_sf)

        if not struct_fields_by_call_arg:
            return

        for call_arg_id, struct_fields in struct_fields_by_call_arg.items():
            callee_scope, slot = call_arg_slots.get(call_arg_id, ("", -1))
            if slot < 0 or not callee_scope:
                continue
            dsects = slot_dsects.get((callee_scope, slot), set())
            if not dsects:
                continue

            dsect_field_nodes: Set[str] = set()
            for dsect_name in dsects:
                dsect_field_nodes.update(dsect_fields_by_name.get(dsect_name, set()))
            if not dsect_field_nodes:
                continue

            for struct_name in struct_fields:
                struct_key = self._normalized_struct_field_key(struct_name)
                if not struct_key:
                    continue
                cpp_field = self._extract_struct_field_tail(struct_name)
                for mem_name in dsect_field_nodes:
                    memory_key = self._normalized_memory_field_key(mem_name)
                    if not memory_key or memory_key != struct_key:
                        continue

                    self._add_memory_struct_bridge_pair(
                        mem_name=mem_name,
                        struct_name=struct_name,
                        expression="global_lineage_stitch:callarg_dsect_field_bridge",
                        statement_id="GLOBAL_STITCH_CALLARG_DSECT_FIELD",
                        existing_edges=existing_edges,
                    )
                    if cpp_field:
                        self.global_graph.annotate_node(mem_name, "memory", cpp_field=cpp_field)

    def _add_struct_field_bridge_pair(
        self,
        left_name: str,
        right_name: str,
        expression: str,
        statement_id: str,
        existing_edges: Set[Tuple[str, str, str]],
    ) -> None:
        """Add symmetric assign/alias glue between two C++ struct_field nodes."""
        left_id = self.global_graph.get_node_id(left_name, "struct_field")
        right_id = self.global_graph.get_node_id(right_name, "struct_field")
        if not left_id or not right_id:
            return

        forward = (left_id, right_id, "assign")
        if forward not in existing_edges:
            self.global_graph.add_assignment(
                left_name, "struct_field", right_name, "struct_field",
                file="<global>", line=0,
                expression=expression,
                scope="(global_stitch)",
                statement_id=statement_id,
                macro_expansion_parent=None,
            )
            existing_edges.add(forward)

        reverse = (right_id, left_id, "assign")
        if reverse not in existing_edges:
            self.global_graph.add_assignment(
                right_name, "struct_field", left_name, "struct_field",
                file="<global>", line=0,
                expression=expression,
                scope="(global_stitch)",
                statement_id=statement_id,
                macro_expansion_parent=None,
            )
            existing_edges.add(reverse)

        alias_forward = (left_id, right_id, "alias")
        if alias_forward not in existing_edges:
            self.global_graph.add_alias(
                left_name, "struct_field", right_name, "struct_field",
                file="<global>", line=0,
                expression=f"{expression}:alias",
                scope="(global_stitch)",
                statement_id=f"{statement_id}_ALIAS",
                macro_expansion_parent=None,
            )
            existing_edges.add(alias_forward)

        alias_reverse = (right_id, left_id, "alias")
        if alias_reverse not in existing_edges:
            self.global_graph.add_alias(
                right_name, "struct_field", left_name, "struct_field",
                file="<global>", line=0,
                expression=f"{expression}:alias",
                scope="(global_stitch)",
                statement_id=f"{statement_id}_ALIAS",
                macro_expansion_parent=None,
            )
            existing_edges.add(alias_reverse)

    def _add_memory_struct_bridge_pair(
        self,
        mem_name: str,
        struct_name: str,
        expression: str,
        statement_id: str,
        existing_edges: Set[Tuple[str, str, str]],
    ) -> None:
        """Add bidirectional assign/alias/ecb_bridge edges for a memory<->struct field pair."""
        src_id = self.global_graph.get_node_id(mem_name, "memory")
        dst_id = self.global_graph.get_node_id(struct_name, "struct_field")
        if not src_id or not dst_id:
            return

        forward = (src_id, dst_id, "assign")
        if forward not in existing_edges:
            self.global_graph.add_assignment(
                mem_name, "memory", struct_name, "struct_field",
                file="<global>", line=0,
                expression=expression,
                scope="(global_stitch)",
                statement_id=statement_id,
                macro_expansion_parent=None,
            )
            existing_edges.add(forward)

        reverse = (dst_id, src_id, "assign")
        if reverse not in existing_edges:
            self.global_graph.add_assignment(
                struct_name, "struct_field", mem_name, "memory",
                file="<global>", line=0,
                expression=expression,
                scope="(global_stitch)",
                statement_id=statement_id,
                macro_expansion_parent=None,
            )
            existing_edges.add(reverse)

        alias_forward = (src_id, dst_id, "alias")
        if alias_forward not in existing_edges:
            self.global_graph.add_alias(
                mem_name, "memory", struct_name, "struct_field",
                file="<global>", line=0,
                expression=f"{expression}:alias",
                scope="(global_stitch)",
                statement_id=f"{statement_id}_ALIAS",
                macro_expansion_parent=None,
            )
            existing_edges.add(alias_forward)

        alias_reverse = (dst_id, src_id, "alias")
        if alias_reverse not in existing_edges:
            self.global_graph.add_alias(
                struct_name, "struct_field", mem_name, "memory",
                file="<global>", line=0,
                expression=f"{expression}:alias",
                scope="(global_stitch)",
                statement_id=f"{statement_id}_ALIAS",
                macro_expansion_parent=None,
            )
            existing_edges.add(alias_reverse)

        self._add_ecb_bridge_edge(
            source_name=mem_name,
            source_kind="memory",
            target_name=struct_name,
            target_kind="struct_field",
            existing_edges=existing_edges,
        )
        self._add_ecb_bridge_edge(
            source_name=struct_name,
            source_kind="struct_field",
            target_name=mem_name,
            target_kind="memory",
            existing_edges=existing_edges,
        )

    def _split_node_id(self, node_id: str) -> Tuple[str, str]:
        """Split a node id like 'memory:TXNTYPE' into ('memory', 'TXNTYPE')."""
        if not node_id or ":" not in node_id:
            return "", node_id
        kind, name = node_id.split(":", 1)
        return kind, name

    def _parse_caller_param_slot(self, memory_name: str) -> Optional[int]:
        """Parse caller_param slot index from memory names such as caller_param[0](R1)."""
        if not memory_name:
            return None
        match = re.search(r"caller_param\[(\d+)\]", memory_name, flags=re.IGNORECASE)
        if not match:
            return None
        try:
            return int(match.group(1))
        except ValueError:
            return None

    def _normalize_register_name(self, name: str) -> Optional[str]:
        if not name:
            return None
        normalized = name.strip().upper()
        if re.fullmatch(r"R\d+", normalized):
            return normalized
        return None

    def _extract_struct_field_tail(self, struct_name: str) -> str:
        """Extract the leaf field token from a qualified struct field path."""
        if not struct_name:
            return ""
        token = struct_name.split("::")[-1]
        token = token.replace("->", ".")
        if "." in token:
            token = token.split(".")[-1]
        return token.strip()

    def _normalized_struct_field_key(self, struct_name: str) -> str:
        """Normalize struct field token to a compact alphanumeric key."""
        tail = self._extract_struct_field_tail(struct_name)
        if not tail:
            return ""
        return re.sub(r"[^a-z0-9]+", "", tail.lower())

    def _normalized_memory_field_key(self, memory_name: str) -> str:
        """Normalize ASM memory field label to a compact alphanumeric key."""
        if not memory_name:
            return ""
        canonical = self._normalize_memory_name(memory_name)
        if not canonical:
            return ""
        return re.sub(r"[^a-z0-9]+", "", canonical.lower())

    def _add_ecb_bridge_edge(self, source_name: str, source_kind: str, target_name: str, target_kind: str,
                             existing_edges: Set[Tuple[str, str, str]]) -> None:
        """Add a dedicated neutral-buffer bridge edge for ECB-backed cross-language flow."""
        src_id = self.global_graph.get_node_id(source_name, source_kind)
        dst_id = self.global_graph.get_node_id(target_name, target_kind)
        if not src_id or not dst_id:
            return
        key = (src_id, dst_id, "ecb_bridge")
        if key in existing_edges:
            return
        self.global_graph.add_bridge(
            source_name=source_name,
            source_kind=source_kind,
            target_name=target_name,
            target_kind=target_kind,
            file="<global>",
            line=0,
            relation="ecb_bridge",
            expression="global_lineage_stitch:ecb_neutral_buffer",
            scope="ECB",
            statement_id="GLOBAL_STITCH_ECB_BRIDGE",
            macro_expansion_parent=None,
        )
        existing_edges.add(key)

    def _stitch_data_level_buffers(self, contexts: Dict[str, AnalysisContext]) -> None:
        """Bridge C/C++ get_level(level) buffers to ASM level-buffer pointers by level number."""
        existing_edges = self._phase3_level_edges
        cpp_buffers = self._collect_cpp_level_buffers(contexts)
        asm_buffers = self._collect_asm_level_buffers(contexts)

        shared_levels = set(cpp_buffers.keys()) & set(asm_buffers.keys())
        for level in shared_levels:
            for cpp_name, cpp_kind in cpp_buffers[level]:
                for asm_name, asm_kind in asm_buffers[level]:
                    self._add_level_bridge_edge(
                        source_name=cpp_name,
                        source_kind=cpp_kind,
                        target_name=asm_name,
                        target_kind=asm_kind,
                        level_number=level,
                        existing_edges=existing_edges,
                    )
                    self._add_level_bridge_edge(
                        source_name=asm_name,
                        source_kind=asm_kind,
                        target_name=cpp_name,
                        target_kind=cpp_kind,
                        level_number=level,
                        existing_edges=existing_edges,
                    )

    def _collect_cpp_level_buffers(self, contexts: Dict[str, AnalysisContext]) -> Dict[int, Set[Tuple[str, str]]]:
        """Collect C/C++ buffer-like receiver nodes for get_level(level, ...) calls."""
        if self._cpp_level_buffers_cache is not None:
            return self._cpp_level_buffers_cache
        level_to_buffers: Dict[int, Set[Tuple[str, str]]] = {}
        for context in contexts.values():
            unit = context.get_metadata("c_family_unit")
            call_graph = context.get_metadata("call_graph")
            if unit is None or call_graph is None:
                continue

            for edge in getattr(call_graph, "edges", []):
                level_number = getattr(edge, "level_number", None)
                target = getattr(edge, "target", None)
                if level_number is None or not self._is_get_level_target(target):
                    continue

                source_function = getattr(edge, "source", None) or "(global)"
                line_no = int(getattr(edge, "line", 0) or 0)
                # All nodes are already merged into global_graph by Phase 2,
                # so using it here instead of the (no longer held) per-file
                # local_graph is both correct and avoids reloading 14K graphs.
                receivers = self._find_cpp_get_level_receivers(
                    unit=unit,
                    local_graph=self.global_graph,
                    function=source_function,
                    call_line=line_no,
                )
                if not receivers:
                    continue
                level_to_buffers.setdefault(int(level_number), set()).update(receivers)
        self._cpp_level_buffers_cache = level_to_buffers
        return level_to_buffers

    def _find_cpp_get_level_receivers(self, unit, local_graph: VariableLineageGraph,
                                      function: str, call_line: int) -> Set[Tuple[str, str]]:
        """Find local lineage nodes receiving get_level(...) values near a call site."""
        receivers: Set[Tuple[str, str]] = set()
        supported_kinds = {"variable", "memory", "struct_field", "array_element"}

        for assignment in getattr(unit, "assignments", []):
            expr = (assignment.expression or "")
            if "get_level" not in expr.lower():
                continue
            if (assignment.function or "(global)") != function:
                continue
            if call_line and assignment.line and abs(int(assignment.line) - call_line) > 3:
                continue

            target_kind = (assignment.target_kind or "variable")
            if target_kind not in supported_kinds:
                continue

            for candidate in self._candidate_cpp_names(
                target=assignment.target,
                function=assignment.function,
                scope=assignment.scope,
            ):
                if local_graph.get_node_id(candidate, target_kind):
                    receivers.add((candidate, target_kind))
                elif target_kind != "variable" and local_graph.get_node_id(candidate, "variable"):
                    receivers.add((candidate, "variable"))

        if receivers:
            return receivers

        # Fallback when c_family_unit assignment metadata is unavailable/partial:
        # infer receivers directly from lineage edges near the call line.
        for edge in getattr(local_graph, "edges", []):
            if edge.relation not in ("assign", "alias"):
                continue
            if (edge.scope or "(global)") != function:
                continue
            if call_line and edge.line and abs(int(edge.line) - call_line) > 3:
                continue
            if "get_level" not in (edge.expression or "").lower():
                continue
            if ":" not in edge.target:
                continue
            target_kind, target_name = edge.target.split(":", 1)
            if target_kind in supported_kinds:
                receivers.add((target_name, target_kind))
        return receivers

    def _candidate_cpp_names(self, target: str, function: str, scope: str) -> List[str]:
        """Return likely qualified/unqualified node names for C/C++ assignment targets."""
        if not target:
            return []
        names = [target]
        if function and scope in ("local", "local_static") and "::" not in target:
            names.insert(0, f"{function}::{target}")
        # De-duplicate while preserving order.
        seen = set()
        result = []
        for name in names:
            if name in seen:
                continue
            seen.add(name)
            result.append(name)
        return result

    def _collect_asm_level_buffers(self, contexts: Dict[str, AnalysisContext]) -> Dict[int, Set[Tuple[str, str]]]:
        """Collect ASM memory buffer nodes bound to level-bearing macros (e.g., ISCFA DATA/RECPTR)."""
        if self._asm_level_buffers_cache is not None:
            return self._asm_level_buffers_cache
        level_to_buffers: Dict[int, Set[Tuple[str, str]]] = {}
        for context in contexts.values():
            for expansion in getattr(context, "macro_expansions", []) or []:
                if getattr(expansion, "expansion_status", None) != "success":
                    continue
                parameters = getattr(expansion, "parameters", {}) or {}
                if not isinstance(parameters, dict):
                    continue

                level_number = self._extract_level_from_macro_parameters(parameters)
                if level_number is None:
                    continue

                recptr_symbol = self._extract_recptr_symbol(parameters)
                if not recptr_symbol:
                    continue

                # global_graph already contains all memory nodes after Phase 2;
                # _resolve_memory_symbol_name also checks global_graph internally.
                resolved_name = self._resolve_memory_symbol_name(self.global_graph, recptr_symbol)
                if not resolved_name:
                    continue

                level_to_buffers.setdefault(level_number, set()).add((resolved_name, "memory"))
        self._asm_level_buffers_cache = level_to_buffers
        return level_to_buffers

    def _extract_level_from_macro_parameters(self, parameters: Dict[str, str]) -> Optional[int]:
        """Extract integer level number from macro parameters (LEVEL=..., DATA=LEVEL...)."""
        for key, value in parameters.items():
            normalized_key = self._normalize_macro_param_key(key)
            if normalized_key not in ("LEVEL", "DATA"):
                continue
            parsed = self._parse_level_number(str(value))
            if parsed is not None:
                return parsed

        for key, value in parameters.items():
            normalized_key = self._normalize_macro_param_key(key)
            if "LEVEL" not in normalized_key:
                continue
            parsed = self._parse_level_number(str(value))
            if parsed is not None:
                return parsed
        return None

    def _extract_recptr_symbol(self, parameters: Dict[str, str]) -> Optional[str]:
        """Extract receiving buffer symbol from macro parameters (RECPTR=...)."""
        for key, value in parameters.items():
            normalized_key = self._normalize_macro_param_key(key)
            if normalized_key != "RECPTR" and not normalized_key.endswith("RECPTR"):
                continue
            symbol = self._sanitize_symbol_token(str(value))
            if symbol:
                return symbol
        return None

    def _normalize_macro_param_key(self, key: str) -> str:
        if not key:
            return ""
        return key.strip().upper().lstrip("&")

    def _sanitize_symbol_token(self, token: str) -> Optional[str]:
        """Best-effort normalization for macro-symbol parameter values."""
        if not token:
            return None
        value = re.sub(r"/\*.*?\*/", "", token, flags=re.DOTALL)
        value = re.sub(r"//.*", "", value)
        value = value.strip().strip(",")
        if not value or value.startswith("&"):
            return None
        if value.startswith("(") and value.endswith(")"):
            value = value[1:-1].strip()
        if not value or "(" in value or ")" in value:
            return None
        if not re.fullmatch(r"[A-Za-z_@$#][A-Za-z0-9_@$#.]*", value):
            return None
        return value

    def _parse_level_number(self, token: str) -> Optional[int]:
        """Parse LEVEL-like tokens such as LEVEL0, D0, or 0."""
        if token is None:
            return None
        value = re.sub(r"/\*.*?\*/", "", str(token), flags=re.DOTALL)
        value = re.sub(r"//.*", "", value).strip()
        if not value:
            return None
        while value.startswith("(") and value.endswith(")"):
            value = value[1:-1].strip()
            if not value:
                return None
        compact = re.sub(r"\s+", "", value)
        if not compact:
            return None
        level_match = re.fullmatch(r"LEVEL_?(\d+)", compact, flags=re.IGNORECASE)
        if level_match:
            return int(level_match.group(1))
        d_level_match = re.fullmatch(r"D([0-9A-Fa-f])", compact, flags=re.IGNORECASE)
        if d_level_match:
            return int(d_level_match.group(1), 16)
        integer_match = re.fullmatch(r"[+-]?(?:0[xX][0-9A-Fa-f]+|\d+)(?:[uUlL]+)?", compact)
        if integer_match:
            normalized = re.sub(r"(?i)[uUlL]+$", "", compact)
            try:
                return int(normalized, 0)
            except ValueError:
                return None
        return None

    def _is_get_level_target(self, target: str) -> bool:
        if not target:
            return False
        tail = target.split("::")[-1].strip()
        tail = re.sub(r"^[\s*&()]+|[\s*&()]+$", "", tail)
        tail = re.sub(r"<[^>]+>$", "", tail).strip()
        return tail.lower() == "get_level"

    def _resolve_memory_symbol_name(self, local_graph: VariableLineageGraph, symbol: str) -> Optional[str]:
        """Resolve a macro parameter symbol against known memory nodes."""
        if not symbol:
            return None
        candidates = [symbol]
        if "::" in symbol:
            candidates.append(symbol.split("::")[-1])
        for name in candidates:
            if local_graph.get_node_id(name, "memory") or self.global_graph.get_node_id(name, "memory"):
                return name
        return None

    def _add_level_bridge_edge(self, source_name: str, source_kind: str, target_name: str, target_kind: str,
                               level_number: int, existing_edges: Set[Tuple[str, str, str, int]]) -> None:
        """Add a neutral buffer bridge edge between nodes participating in same data level."""
        src_id = self.global_graph.get_node_id(source_name, source_kind)
        dst_id = self.global_graph.get_node_id(target_name, target_kind)
        if not src_id or not dst_id or src_id == dst_id:
            return
        key = (src_id, dst_id, "level_bridge", level_number)
        if key in existing_edges:
            return
        self.global_graph.add_bridge(
            source_name=source_name,
            source_kind=source_kind,
            target_name=target_name,
            target_kind=target_kind,
            file="<global>",
            line=0,
            relation="level_bridge",
            expression="global_lineage_stitch:level_neutral_buffer",
            scope=f"LEVEL{level_number}",
            statement_id="GLOBAL_STITCH_LEVEL_BRIDGE",
            macro_expansion_parent=None,
            level_number=level_number,
        )
        existing_edges.add(key)

    def _stitch_ce1cr_level_bindings(self, contexts: Dict[str, AnalysisContext]) -> None:
        """Bridge CE1CRn slot nodes to LEVELn/Dn buffer nodes explicitly."""
        existing_level_edges = self._phase3_level_edges
        existing_ecb_edges = self._phase3_edges

        ce1cr_nodes = self._collect_ce1cr_nodes()
        if not ce1cr_nodes:
            return

        level_nodes = self._collect_explicit_level_nodes()
        for level, buffers in self._collect_cpp_level_buffers(contexts).items():
            level_nodes.setdefault(level, set()).update(buffers)
        for level, buffers in self._collect_asm_level_buffers(contexts).items():
            level_nodes.setdefault(level, set()).update(buffers)

        for slot, ce_nodes in ce1cr_nodes.items():
            targets = level_nodes.get(slot, set())
            if not targets:
                continue

            for ce_name, ce_kind in ce_nodes:
                self.global_graph.annotate_node(
                    ce_name,
                    ce_kind,
                    ce1cr_slot=slot,
                    level_number=slot,
                )
                for level_name, level_kind in targets:
                    self.global_graph.annotate_node(level_name, level_kind, level_number=slot)
                    self._add_ce1cr_level_bridge_edge(
                        source_name=ce_name,
                        source_kind=ce_kind,
                        target_name=level_name,
                        target_kind=level_kind,
                        level_number=slot,
                        existing_edges=existing_level_edges,
                    )
                    self._add_ce1cr_level_bridge_edge(
                        source_name=level_name,
                        source_kind=level_kind,
                        target_name=ce_name,
                        target_kind=ce_kind,
                        level_number=slot,
                        existing_edges=existing_level_edges,
                    )
                    self._add_ecb_bridge_edge(
                        source_name=ce_name,
                        source_kind=ce_kind,
                        target_name=level_name,
                        target_kind=level_kind,
                        existing_edges=existing_ecb_edges,
                    )
                    self._add_ecb_bridge_edge(
                        source_name=level_name,
                        source_kind=level_kind,
                        target_name=ce_name,
                        target_kind=ce_kind,
                        existing_edges=existing_ecb_edges,
                    )

    def _collect_ce1cr_nodes(self) -> Dict[int, Set[Tuple[str, str]]]:
        """Collect lineage nodes that represent CE1CR slot pointers by slot index."""
        result: Dict[int, Set[Tuple[str, str]]] = {}
        for node in self.global_graph.nodes.values():
            if node.kind not in ("memory", "struct_field", "variable"):
                continue
            slot = self._extract_ce1cr_slot(node.name)
            if slot is None:
                continue
            result.setdefault(slot, set()).add((node.name, node.kind))
        return result

    def _collect_explicit_level_nodes(self) -> Dict[int, Set[Tuple[str, str]]]:
        """Collect nodes that clearly encode data-level identity (e.g., D4, LEVEL4)."""
        result: Dict[int, Set[Tuple[str, str]]] = {}
        for node in self.global_graph.nodes.values():
            if node.kind not in ("memory", "struct_field", "variable"):
                continue
            level = self._extract_level_from_node(node)
            if level is None:
                continue
            result.setdefault(level, set()).add((node.name, node.kind))
        return result

    def _extract_level_from_node(self, node) -> Optional[int]:
        metadata = getattr(node, "metadata", None) or {}
        level_meta = metadata.get("level_number")
        if isinstance(level_meta, int) and 0 <= level_meta <= 15:
            return level_meta
        return self._extract_explicit_level(node.name)

    def _extract_ce1cr_slot(self, name: str) -> Optional[int]:
        """Extract CE1CR slot number from memory/field-like names."""
        canonical = self._normalize_memory_name(name or "")
        if not canonical:
            return None
        match = re.search(r"(?:^|[^a-z0-9])ce1cr([0-9a-f])(?:$|[^a-z0-9])", canonical.lower())
        if not match:
            return None
        return int(match.group(1), 16)

    def _stitch_ecb_slot_coop_aliases(self) -> None:
        """Alias CE1CR slot nodes from multiple source files.

        When two ASM files read/write the same CE1CR slot without a direct call
        edge between them, their per-file nodes have no cross-file link in the
        GVL.  This pass emits bidirectional ``alias`` edges for every distinct-
        name pair that maps to the same slot so Strategy 6 can traverse the
        ECB slot as a shared carrier across files.
        """
        existing_edges = self._phase3_edges
        ce1cr_nodes = self._collect_ce1cr_nodes()

        for slot, node_set in ce1cr_nodes.items():
            nodes = list(node_set)  # [(name, kind), ...]
            if len(nodes) < 2:
                continue
            slot_name = f"CE1CR{format(slot, 'X')}"
            for i, (name_a, kind_a) in enumerate(nodes):
                for name_b, kind_b in nodes[i + 1:]:
                    src_id = self.global_graph.get_node_id(name_a, kind_a)
                    dst_id = self.global_graph.get_node_id(name_b, kind_b)
                    if not src_id or not dst_id or src_id == dst_id:
                        continue
                    key_fwd = (src_id, dst_id, "alias")
                    key_rev = (dst_id, src_id, "alias")
                    if key_fwd not in existing_edges:
                        existing_edges.add(key_fwd)
                        self.global_graph.add_alias(
                            name_a, kind_a, name_b, kind_b,
                            file="(ecb_slot_coop_bridge)",
                            line=0,
                            expression="global_lineage_stitch:ecb_slot_coop_aliases",
                            scope=slot_name,
                            statement_id=f"GLOBAL_STITCH_ECB_COOP_{slot_name}",
                            macro_expansion_parent=None,
                        )
                    if key_rev not in existing_edges:
                        existing_edges.add(key_rev)
                        self.global_graph.add_alias(
                            name_b, kind_b, name_a, kind_a,
                            file="(ecb_slot_coop_bridge)",
                            line=0,
                            expression="global_lineage_stitch:ecb_slot_coop_aliases",
                            scope=slot_name,
                            statement_id=f"GLOBAL_STITCH_ECB_COOP_{slot_name}",
                            macro_expansion_parent=None,
                        )

    def _extract_explicit_level(self, name: str) -> Optional[int]:
        """Extract level from explicit tokens like D4/DF or LEVEL4."""
        canonical = self._normalize_memory_name(name or "")
        if not canonical:
            return None

        tokens = [token for token in re.split(r"[^a-z0-9]+", canonical.lower()) if token]
        for token in tokens:
            dmatch = re.fullmatch(r"d([0-9a-f])", token)
            if dmatch:
                return int(dmatch.group(1), 16)
            lmatch = re.fullmatch(r"level_?([0-9a-f]{1,2})", token)
            if lmatch:
                try:
                    level = int(lmatch.group(1), 16)
                except ValueError:
                    continue
                if 0 <= level <= 15:
                    return level
        return None

    def _add_ce1cr_level_bridge_edge(
        self,
        source_name: str,
        source_kind: str,
        target_name: str,
        target_kind: str,
        level_number: int,
        existing_edges: Set[Tuple[str, str, str, Optional[int]]],
    ) -> None:
        src_id = self.global_graph.get_node_id(source_name, source_kind)
        dst_id = self.global_graph.get_node_id(target_name, target_kind)
        if not src_id or not dst_id or src_id == dst_id:
            return
        key = (src_id, dst_id, "ce1cr_level_bridge", level_number)
        if key in existing_edges:
            return
        self.global_graph.add_bridge(
            source_name=source_name,
            source_kind=source_kind,
            target_name=target_name,
            target_kind=target_kind,
            file="<global>",
            line=0,
            relation="ce1cr_level_bridge",
            expression="global_lineage_stitch:ce1cr_level_binding",
            scope=f"LEVEL{level_number}",
            statement_id="GLOBAL_STITCH_CE1CR_LEVEL_BRIDGE",
            macro_expansion_parent=None,
            level_number=level_number,
        )
        existing_edges.add(key)

    def _stitch_r15_return_receivers(self) -> None:
        """Add direct bridge from ASM R15 to C/C++ variables receiving return values."""
        existing_edges = self._phase3_edges
        return_to_targets: Dict[str, Set[str]] = {}

        def is_asm_return_source(source_node: str) -> bool:
            if not source_node.startswith("return_value:return@"):
                return False
            callee = source_node[len("return_value:return@"):]
            callee = callee.split(":", 1)[0]
            callee_lower = callee.lower()
            if callee_lower.startswith("asm_"):
                return True
            if callee.isupper() and "_" in callee:
                return True
            candidates = [callee]
            if "::" in callee:
                candidates.append(callee.split("::")[-1])
            expanded = []
            for name in candidates:
                expanded.extend([name, name.lower(), name.upper()])
            for name in expanded:
                file_path = self.symbol_to_file.get(name)
                if not file_path:
                    continue
                lower = file_path.lower()
                if lower.endswith((".asm", ".s", ".mac", ".cpy", ".inc")):
                    return True
            return False

        # When Phase-2 edges are evicted, use the pre-built candidate dict
        # (all nodes with `return_value:return@` → variable edges, filtered here
        # by is_asm_return_source).  Otherwise iterate global_graph.edges directly.
        if getattr(self.global_graph, "_p2_edges_path", None) is not None:
            for source, targets in self._p2_r15_candidates.items():
                if is_asm_return_source(source):
                    return_to_targets[source] = set(targets)
        else:
            for edge in self.global_graph.edges:
                if edge.relation != "assign":
                    continue
                if not edge.target.startswith("variable:"):
                    continue
                if edge.target.startswith("variable:return@"):
                    continue
                if not edge.source.startswith("return_value:return@"):
                    continue
                if not is_asm_return_source(edge.source):
                    continue
                return_to_targets.setdefault(edge.source, set()).add(edge.target)
        if not return_to_targets:
            return

        all_targets: Set[str] = set()
        for source_node, targets in return_to_targets.items():
            canonical = source_node.rsplit(":", 1)[0] if ":" in source_node else source_node
            all_targets.update(targets)
            all_targets.update(return_to_targets.get(canonical, set()))

        # Pattern E fix: infer which register to bridge from the source node
        # suffix (return@callee:R0 → R0, return@callee:R1 → R1, else → R15).
        # Collect per-register target sets so each register gets its own edges.
        reg_to_targets: Dict[str, Set[str]] = {}
        for source_node, targets in return_to_targets.items():
            # source_node is "return_value:return@CALLEE" or "return_value:return@CALLEE:Rn"
            suffix = source_node.rsplit(":", 1)[-1]
            inferred_reg = suffix if suffix in ("R0", "R1", "R15") else "R15"
            reg_to_targets.setdefault(inferred_reg, set()).update(targets)
            canonical = source_node.rsplit(":", 1)[0] if ":" in source_node else source_node
            reg_to_targets[inferred_reg].update(return_to_targets.get(canonical, set()))

        for ret_reg, targets in reg_to_targets.items():
            for target in targets:
                key = (f"register:{ret_reg}", target, "assign")
                if key in existing_edges:
                    continue
                self.global_graph.add_assignment(
                    ret_reg, "register", target.split(":", 1)[1], "variable",
                    file="<global>", line=0,
                    expression="global_lineage_stitch:r15_return_bridge",
                    scope="(global_stitch)",
                    statement_id="GLOBAL_STITCH_R15_RETURN",
                    macro_expansion_parent=None,
                )
                existing_edges.add(key)

    def _stitch_creec_spawn_receivers(self) -> None:
        """Pattern K: emit level_bridge edges from CE1CRx to arg@callee:SPAWNn nodes.

        When CREEC GA71,D0,R spawns a callee, variable_lineage_builder emits:
            memory:D0 → parameter:arg@GA71:SPAWN1
        on the *caller* side. But callees that receive data exclusively via the
        SPAWN mechanism have no ``CE1CR0 → arg@GA71:SPAWN1`` receiver edge in
        their own blueprint; the get_equivalent_variable Strategy 0.5 heuristic
        only works when CE1CR0 already exists as a mem_node through another path.

        This pass closes the gap by scanning all ``parameter:arg@CALLEE:SPAWNn``
        nodes in the merged global graph and emitting a bidirectional ecb_bridge
        edge from the corresponding CE1CRx node (if present), making the callee
        side structurally self-consistent for forward and backward traversal.
        """
        existing = self._phase3_edges

        for node in list(self.global_graph.nodes.values()):
            if node.kind != "parameter":
                continue
            # Match arg@CALLEE:SPAWNn (1-based index)
            _m = re.match(r"^arg@(\w+):SPAWN(\d+)$", node.name, re.IGNORECASE)
            if not _m:
                continue
            spawn_idx = int(_m.group(2))
            ce_level = spawn_idx - 1                      # SPAWN1 → level 0 → CE1CR0
            ce1cr_name = f"CE1CR{format(ce_level, 'X')}"  # hex slot (0–F)
            dn_name = f"D{format(ce_level, 'X')}"         # level designator fallback

            # Prefer CE1CRx; fall back to the level designator (Dx) if CE1CRx
            # is absent but the level itself is present in the merged graph.
            ce_name: Optional[str] = None
            ce_kind: Optional[str] = None
            for _cname, _ckind in [(ce1cr_name, "memory"), (dn_name, "memory")]:
                if self.global_graph.get_node_id(_cname, _ckind):
                    ce_name, ce_kind = _cname, _ckind
                    break

            if not ce_name:
                # GAP-K: callee has no independent CE1CRx/Dx reference in the
                # merged graph.  Emit a synthetic memory:CE1CRx definition so
                # the ecb_bridge can still be created — mirroring the synthetic
                # register:RN node emitted by _stitch_tpf_regs_register_bridge
                # (lines 1546-1555) for the same situation on the register side.
                callee_name = _m.group(1)
                self.global_graph.add_definition(
                    ce1cr_name, "memory",
                    file="(synthetic_creec_spawn_receiver)",
                    line=0,
                    expression=(
                        f"synthetic: {callee_name} SPAWN{spawn_idx} receiver"
                        f" declares {ce1cr_name}"
                    ),
                    scope=callee_name,
                    statement_id=f"SYNTHETIC_CE1CR_{ce1cr_name}_{callee_name}",
                    macro_expansion_parent=None,
                )
                ce_name, ce_kind = ce1cr_name, "memory"

            # Emit ecb_bridge in both directions so both forward and backward
            # traversal can cross the SPAWN caller→callee boundary.
            self._add_ecb_bridge_edge(
                source_name=ce_name,
                source_kind=ce_kind,
                target_name=node.name,
                target_kind="parameter",
                existing_edges=existing,
            )
            self._add_ecb_bridge_edge(
                source_name=node.name,
                source_kind="parameter",
                target_name=ce_name,
                target_kind=ce_kind,
                existing_edges=existing,
            )

    def _normalize_return_name(self, name: str) -> str:
        if not name.startswith("return@"):
            return name.lower()
        value = name[len("return@"):]
        value = value.split(":", 1)[0]
        value = value.split("::")[-1]
        return f"return@{value.lower()}"

    def _field_path_tokens(self, name: str) -> List[str]:
        """Tokenize a C++ field path for suffix-based alias matching."""
        if not name:
            return []
        base = name.split("::")[-1]
        base = base.replace("->", ".")
        return [tok.lower() for tok in re.split(r"[^A-Za-z0-9_@$#]+", base) if tok]

    def _annotate_ecb_field_metadata(self, graph: VariableLineageGraph) -> None:
        """Annotate memory/field-like nodes with a canonical cross-language key."""
        for node in list(graph.nodes.values()):
            if node.kind not in ("memory", "struct_field", "variable"):
                continue
            canonical = self._normalize_memory_name(node.name)
            if not canonical:
                continue
            # Skip purely numeric or register-like canonical names.
            if re.fullmatch(r"[0-9+\-()\[\],]+", canonical):
                continue
            if re.fullmatch(r"r\d+", canonical):
                continue
            graph.annotate_node(node.name, node.kind, ecb_field=canonical)

    # ------------------------------------------------------------------
    # Pattern B — C++ call-boundary bridge and reference write-back
    # ------------------------------------------------------------------

    def _stitch_cpp_callarg_to_parameter_bridge(self) -> None:
        """B-1: Connect caller-side ``call_arg:funcName#N`` nodes to the
        corresponding callee-side ``parameter:arg@funcName:RN`` receiver nodes.

        The C++ lineage builder emits both node types but leaves them
        disconnected: the caller records ``source → arg_bind → funcName#N``
        and the callee records ``arg@funcName:R0 → assign → funcName::param``.
        Without an explicit edge between ``funcName#N`` and
        ``arg@funcName:RN``, the tracer cannot cross a pure C++→C++ call
        boundary.

        Emit:
          call_arg:funcName#N  →assign→  parameter:arg@funcName:RN  (forward)
          parameter:arg@funcName:RN  →alias→  call_arg:funcName#N   (reverse)
        """
        for node in list(self.global_graph.nodes.values()):
            if node.kind != "call_arg":
                continue
            name = node.name
            if "#" not in name:
                continue
            try:
                func_name, slot_str = name.rsplit("#", 1)
                slot = int(slot_str)
            except ValueError:
                continue
            if slot >= 12:
                continue
            reg = f"R{slot}"
            arg_node_name = f"arg@{func_name}:{reg}"
            arg_node_id = self.global_graph.get_node_id(arg_node_name, "parameter")
            if not arg_node_id:
                continue

            fwd = (node.node_id, arg_node_id, "assign")
            if fwd not in self._phase3_edges:
                self._phase3_edges.add(fwd)
                self.global_graph.add_assignment(
                    name, "call_arg",
                    arg_node_name, "parameter",
                    file="(cpp_call_bridge)",
                    line=0,
                    expression="global_lineage_stitch:cpp_callarg_to_parameter",
                    scope=func_name,
                    statement_id="GLOBAL_STITCH_CPP_CALLARG",
                    macro_expansion_parent=None,
                )

            rev = (arg_node_id, node.node_id, "alias")
            if rev not in self._phase3_edges:
                self._phase3_edges.add(rev)
                self.global_graph.add_alias(
                    arg_node_name, "parameter",
                    name, "call_arg",
                    file="(cpp_call_bridge)",
                    line=0,
                    expression="global_lineage_stitch:cpp_callarg_to_parameter:reverse",
                    scope=func_name,
                    statement_id="GLOBAL_STITCH_CPP_CALLARG",
                    macro_expansion_parent=None,
                )

    def _stitch_ref_write_back(self) -> None:
        """B-2: Emit field-level alias edges from callee-written struct_fields
        back to the corresponding caller-side struct_fields for reference/
        pointer parameters.

        After B-1 bridges ``call_arg:funcName#N ↔ parameter:arg@funcName:RN``,
        this step closes the loop for callee modifications that the caller
        should see:

          caller_var.fieldX  →arg_bind→  funcName#N   (already exists)
          funcName::param.fieldX  [written by callee]
          ↕ (new bidirectional alias emitted here)

        Matching key: the unscoped field portion after stripping the function
        scope prefix (``funcScope::``) must be identical on both sides.
        """
        existing = self._phase3_edges

        # Step 1: caller struct_fields bound to each call_arg node.
        # Also accept memory: kind sources — these represent address-of passes
        # (e.g. `memory:processAccountMaintenance::ResponseMsg` → `call_arg:maintenancePipeline#N`)
        # which occur when a caller passes a pointer-to-local as an output parameter.
        caller_fields_by_call_arg: Dict[str, Set[str]] = {}
        for edge in self.global_graph.edges:
            if edge.relation != "arg_bind":
                continue
            src_k, src_n = self._split_node_id(edge.source)
            dst_k, _ = self._split_node_id(edge.target)
            if src_k not in ("struct_field", "variable", "memory"):
                continue
            if dst_k != "call_arg":
                continue
            caller_fields_by_call_arg.setdefault(edge.target, set()).add(edge.source)

        if not caller_fields_by_call_arg:
            return

        # Step 2: ARG_BRIDGE assignments: parameter:arg@func:RN → parameter:func::param
        # Statement IDs have the form C_{func}_ARG_BRIDGE.
        callee_param_by_arg_id: Dict[str, str] = {}
        for edge in self.global_graph.edges:
            if edge.relation != "assign":
                continue
            if not (edge.statement_id or "").endswith("_ARG_BRIDGE"):
                continue
            src_k, src_n = self._split_node_id(edge.source)
            dst_k, dst_n = self._split_node_id(edge.target)
            if src_k == "parameter" and dst_k == "parameter":
                callee_param_by_arg_id[edge.source] = edge.target  # "parameter:arg@func:RN" → "parameter:func::param"

        # Step 3: scoped struct_field and variable nodes written inside each callee scope.
        # Accept both struct_field (the ideal case) and variable (common when the C++
        # parser emits callee writes to named local variables that correspond to a
        # caller-visible field — e.g., "processCidDbRecord::record.someField" emitted
        # as variable kind when the assignment is to a named local copy).
        # GAP-B: also handle pointer dereference writes — assign target
        # memory:*scope::paramBase (whole-struct write through a pointer parameter,
        # e.g. `*ptr = newValue`).  These are missed by the struct_field filter
        # but represent an equally valid callee write-back path.
        callee_writes_by_param_id: Dict[str, Set[str]] = {}
        for edge in self.global_graph.edges:
            if edge.relation != "assign":
                continue
            dst_k, dst_n = self._split_node_id(edge.target)
            if dst_k == "memory":
                # Pointer dereference write: *scope::paramBase = value.
                if not dst_n.startswith("*"):
                    continue
                deref_base = dst_n[1:]
                if "::" not in deref_base:
                    continue
                scope_part, rest = deref_base.split("::", 1)
                base = rest.split(".")[0].split("->")[0]
            elif dst_k in ("struct_field", "variable"):
                # dst_n looks like "func::paramBase.fieldX" or "func::paramBase->fieldX".
                if "::" not in dst_n:
                    continue
                scope_part, rest = dst_n.split("::", 1)
                # Reconstruct fully-qualified parameter node ID candidates.
                # The param base is the identifier before the first dot/arrow.
                base = rest.split(".")[0].split("->")[0]
            else:
                continue
            param_id_candidates = [
                f"parameter:{scope_part}::{base}",
                f"parameter:{base}",
            ]
            for pid in param_id_candidates:
                if self.global_graph.get_node_id(pid.split(":", 1)[1] if ":" in pid else pid, "parameter"):
                    callee_writes_by_param_id.setdefault(pid, set()).add(edge.target)

        if not callee_writes_by_param_id:
            return

        # Step 4: for each call_arg that has caller struct_fields, walk the
        # chain to callee writes and match by normalised field tail.
        for call_arg_id, caller_sf_ids in caller_fields_by_call_arg.items():
            _, ca_name = self._split_node_id(call_arg_id)
            if "#" not in ca_name:
                continue
            try:
                func_name, slot_str = ca_name.rsplit("#", 1)
                slot = int(slot_str)
            except ValueError:
                continue
            if slot >= 12:
                continue

            arg_node_id = f"parameter:arg@{func_name}:R{slot}"
            callee_param_id = callee_param_by_arg_id.get(arg_node_id)
            if not callee_param_id:
                continue

            callee_writes = callee_writes_by_param_id.get(callee_param_id, set())
            if not callee_writes:
                continue

            # GAP-B: split callee writes into field-level (struct_field/variable)
            # and whole-struct pointer dereference (memory:*X) writes.  Tail
            # matching is only meaningful for field writes; dereference writes are
            # bridged directly to every caller-side node for this slot.
            callee_deref_writes = {
                w for w in callee_writes if self._split_node_id(w)[0] == "memory"
            }
            callee_field_writes = callee_writes - callee_deref_writes

            # Build normalised field tails for struct_field/variable callee writes.
            # "struct_field:func::paramBase.field" → tail "paramBase.field"
            callee_tails: Dict[str, str] = {}  # tail → full node id
            for csf_id in callee_field_writes:
                _, csf_n = self._split_node_id(csf_id)
                tail = csf_n.split("::")[-1] if "::" in csf_n else csf_n
                callee_tails[tail.lower()] = csf_id

            for caller_sf_id in caller_sf_ids:
                _, caller_n = self._split_node_id(caller_sf_id)
                caller_tail = (caller_n.split("::")[-1] if "::" in caller_n else caller_n).lower()
                callee_sf_id = callee_tails.get(caller_tail)

                # Pattern B fallback: when the exact tail doesn't match (different
                # parameter base names, e.g. caller has `lwrCommon.process.links.field`
                # but callee has `pa.process.links.field`), try matching on the
                # field-path portion *after* the first dot (ignores the base name).
                if not callee_sf_id:
                    dot_pos = caller_tail.find(".")
                    if dot_pos >= 0:
                        caller_field_path = caller_tail[dot_pos + 1:]
                        for _ct_key, _ct_sfid in callee_tails.items():
                            _ct_dot = _ct_key.find(".")
                            if _ct_dot >= 0 and _ct_key[_ct_dot + 1:] == caller_field_path:
                                callee_sf_id = _ct_sfid
                                break

                if not callee_sf_id:
                    continue
                _, callee_sf_n = self._split_node_id(callee_sf_id)
                _, caller_sf_n = self._split_node_id(caller_sf_id)
                # Resolve the actual graph kinds for both sides.  Prefer
                # struct_field; fall back to variable; fall back to memory
                # (address-of pass from caller side).
                callee_sf_k = (
                    "struct_field" if self.global_graph.get_node_id(callee_sf_n, "struct_field")
                    else "variable" if self.global_graph.get_node_id(callee_sf_n, "variable")
                    else None
                )
                caller_sf_k = (
                    "struct_field" if self.global_graph.get_node_id(caller_sf_n, "struct_field")
                    else "variable" if self.global_graph.get_node_id(caller_sf_n, "variable")
                    else "memory" if self.global_graph.get_node_id(caller_sf_n, "memory")
                    else None
                )
                if not callee_sf_k or not caller_sf_k:
                    continue
                if callee_sf_k == "struct_field" and caller_sf_k == "struct_field":
                    # Use the dedicated helper which emits both directions.
                    self._add_struct_field_bridge_pair(
                        left_name=callee_sf_n,
                        right_name=caller_sf_n,
                        expression="global_lineage_stitch:ref_write_back",
                        statement_id="GLOBAL_STITCH_REF_WRITEBACK",
                        existing_edges=existing,
                    )
                else:
                    # Cross-kind bridge (variable↔struct_field or variable↔variable).
                    # Emit bidirectional assign edges so forward and backward traversal
                    # can cross the write-back boundary regardless of the emitted kind.
                    for _src_n, _src_k, _dst_n, _dst_k in [
                        (callee_sf_n, callee_sf_k, caller_sf_n, caller_sf_k),
                        (caller_sf_n, caller_sf_k, callee_sf_n, callee_sf_k),
                    ]:
                        _src_id = self.global_graph.get_node_id(_src_n, _src_k)
                        _dst_id = self.global_graph.get_node_id(_dst_n, _dst_k)
                        if not _src_id or not _dst_id:
                            continue
                        _key = (_src_id, _dst_id, "assign")
                        if _key in existing:
                            continue
                        self.global_graph.add_assignment(
                            _src_n, _src_k, _dst_n, _dst_k,
                            file="<global>", line=0,
                            expression="global_lineage_stitch:ref_write_back",
                            scope="(global_stitch)",
                            statement_id="GLOBAL_STITCH_REF_WRITEBACK",
                            macro_expansion_parent=None,
                        )
                        existing.add(_key)

            # GAP-B: whole-struct pointer dereference writes (memory:*scope::param).
            # No field-tail matching is possible; emit a direct bidirectional assign
            # bridge from the memory dereference node to each caller-side node so
            # the write-back path is visible for forward and backward traversal.
            for mem_id in callee_deref_writes:
                _, mem_n = self._split_node_id(mem_id)
                mem_node_id = self.global_graph.get_node_id(mem_n, "memory")
                if not mem_node_id:
                    continue
                for caller_sf_id in caller_sf_ids:
                    _, caller_sf_n = self._split_node_id(caller_sf_id)
                    # Prefer struct_field/variable; also accept memory: when the
                    # caller passed a pointer-typed local (address-of argument).
                    caller_sf_k = (
                        "struct_field"
                        if self.global_graph.get_node_id(caller_sf_n, "struct_field")
                        else "variable"
                        if self.global_graph.get_node_id(caller_sf_n, "variable")
                        else "memory"
                        if self.global_graph.get_node_id(caller_sf_n, "memory")
                        else None
                    )
                    if not caller_sf_k:
                        continue
                    for _src_n, _src_k, _dst_n, _dst_k in [
                        (mem_n, "memory", caller_sf_n, caller_sf_k),
                        (caller_sf_n, caller_sf_k, mem_n, "memory"),
                    ]:
                        _src_id = self.global_graph.get_node_id(_src_n, _src_k)
                        _dst_id = self.global_graph.get_node_id(_dst_n, _dst_k)
                        if not _src_id or not _dst_id:
                            continue
                        _key = (_src_id, _dst_id, "assign")
                        if _key in existing:
                            continue
                        self.global_graph.add_assignment(
                            _src_n, _src_k, _dst_n, _dst_k,
                            file="<global>", line=0,
                            expression="global_lineage_stitch:ref_write_back:ptr_deref",
                            scope="(global_stitch)",
                            statement_id="GLOBAL_STITCH_REF_WRITEBACK_PTR",
                            macro_expansion_parent=None,
                        )
                        existing.add(_key)

    def _stitch_floating_ref_write_back(self) -> None:
        """B-2b: Fallback write-back bridge for callee functions whose
        ``parameter:arg@funcName:RN`` receiver nodes are absent — e.g. when
        the callee body was parsed in a different translation unit that was not
        included in the analysis, or when the call is dispatched through a
        function pointer where the callee identity is known by name in the
        ``call_arg:funcName#N`` node but the callee-side ARG_BRIDGE chain was
        never emitted.

        Strategy (no ARG_BRIDGE required):
          1. Scan ``arg_bind`` edges ``struct_field/variable → call_arg:funcName#N``
             to build ``caller_fields_by_callee_func``.
             Skip functions that already have a ``parameter:arg@funcName:RN``
             node (the normal B-2 path covers those).
          2. Scan all ``assign`` edges whose target is a scoped
             ``struct_field/variable`` of the form ``funcName::…`` for the
             callee functions collected in step 1.
          3. Match by normalised field-path suffix (exact, then first-dot
             strip) and emit bidirectional bridge edges.
        """
        existing = self._phase3_edges

        # Pre-build the set of function names that already have a COMPLETE
        # ARG_BRIDGE chain (an assign edge from parameter:arg@func:RN to
        # parameter:func::param tagged with _ARG_BRIDGE).  Functions that have
        # arg@func:RN parameter nodes but NO ARG_BRIDGE assign edge are NOT
        # excluded — _stitch_ref_write_back cannot handle them either (it also
        # requires the ARG_BRIDGE edge), so this fallback path must process them.
        # GAP-B: previously this was built from node presence alone, which wrongly
        # excluded pointer-parameter functions that have arg@ nodes but no bridge.
        funcs_with_arg_bridge: Set[str] = set()
        for _edge in self.global_graph.edges:
            if _edge.relation != "assign":
                continue
            if not (_edge.statement_id or "").endswith("_ARG_BRIDGE"):
                continue
            _src_k, _src_n = self._split_node_id(_edge.source)
            if _src_k == "parameter" and _src_n.startswith("arg@"):
                _m = re.match(r"arg@(.+):[A-Z]\d+$", _src_n)
                if _m:
                    funcs_with_arg_bridge.add(_m.group(1))

        # Step 1: caller struct_fields grouped by callee function name.
        # Also accept memory: kind sources (address-of pointer passes).
        caller_fields_by_callee_func: Dict[str, Set[str]] = {}
        for edge in self.global_graph.edges:
            if edge.relation != "arg_bind":
                continue
            src_k, _ = self._split_node_id(edge.source)
            dst_k, dst_n = self._split_node_id(edge.target)
            if src_k not in ("struct_field", "variable", "memory"):
                continue
            if dst_k != "call_arg":
                continue
            if "#" not in dst_n:
                continue
            try:
                func_name, slot_str = dst_n.rsplit("#", 1)
                int(slot_str)
            except ValueError:
                continue
            if func_name in funcs_with_arg_bridge:
                continue
            caller_fields_by_callee_func.setdefault(func_name, set()).add(edge.source)

        if not caller_fields_by_callee_func:
            return

        # Step 2: callee writes (assign edges targeting scoped struct_field/variable)
        # grouped by function scope name, keyed by normalised tail.
        callee_writes_by_func: Dict[str, Dict[str, str]] = {}
        for edge in self.global_graph.edges:
            if edge.relation != "assign":
                continue
            dst_k, dst_n = self._split_node_id(edge.target)
            if dst_k not in ("struct_field", "variable"):
                continue
            if "::" not in dst_n:
                continue
            scope_part, rest = dst_n.split("::", 1)
            if scope_part not in caller_fields_by_callee_func:
                continue
            tail = rest.lower()
            callee_writes_by_func.setdefault(scope_part, {})[tail] = edge.target

        # Step 3: field-path suffix matching and bridge emission.
        for func_name, caller_sf_ids in caller_fields_by_callee_func.items():
            callee_tails = callee_writes_by_func.get(func_name)
            if not callee_tails:
                continue

            for caller_sf_id in caller_sf_ids:
                _, caller_n = self._split_node_id(caller_sf_id)
                caller_tail = (
                    caller_n.split("::")[-1] if "::" in caller_n else caller_n
                ).lower()

                callee_sf_id = callee_tails.get(caller_tail)

                # Fallback: match on field-path after the first dot (ignores
                # differing base parameter names).
                if not callee_sf_id:
                    dot_pos = caller_tail.find(".")
                    if dot_pos >= 0:
                        caller_field_path = caller_tail[dot_pos + 1:]
                        for _ct_key, _ct_sfid in callee_tails.items():
                            _ct_dot = _ct_key.find(".")
                            if _ct_dot >= 0 and _ct_key[_ct_dot + 1:] == caller_field_path:
                                callee_sf_id = _ct_sfid
                                break

                if not callee_sf_id:
                    continue

                _, callee_sf_n = self._split_node_id(callee_sf_id)
                _, caller_sf_n = self._split_node_id(caller_sf_id)

                callee_sf_k = (
                    "struct_field" if self.global_graph.get_node_id(callee_sf_n, "struct_field")
                    else "variable" if self.global_graph.get_node_id(callee_sf_n, "variable")
                    else None
                )
                caller_sf_k = (
                    "struct_field" if self.global_graph.get_node_id(caller_sf_n, "struct_field")
                    else "variable" if self.global_graph.get_node_id(caller_sf_n, "variable")
                    else "memory" if self.global_graph.get_node_id(caller_sf_n, "memory")
                    else None
                )
                if not callee_sf_k or not caller_sf_k:
                    continue

                if callee_sf_k == "struct_field" and caller_sf_k == "struct_field":
                    self._add_struct_field_bridge_pair(
                        left_name=callee_sf_n,
                        right_name=caller_sf_n,
                        expression="global_lineage_stitch:floating_ref_write_back",
                        statement_id="GLOBAL_STITCH_FLOAT_WRITEBACK",
                        existing_edges=existing,
                    )
                else:
                    for _src_n, _src_k, _dst_n, _dst_k in [
                        (callee_sf_n, callee_sf_k, caller_sf_n, caller_sf_k),
                        (caller_sf_n, caller_sf_k, callee_sf_n, callee_sf_k),
                    ]:
                        _src_id = self.global_graph.get_node_id(_src_n, _src_k)
                        _dst_id = self.global_graph.get_node_id(_dst_n, _dst_k)
                        if not _src_id or not _dst_id:
                            continue
                        _key = (_src_id, _dst_id, "assign")
                        if _key in existing:
                            continue
                        self.global_graph.add_assignment(
                            _src_n, _src_k, _dst_n, _dst_k,
                            file="<global>", line=0,
                            expression="global_lineage_stitch:floating_ref_write_back",
                            scope="(global_stitch)",
                            statement_id="GLOBAL_STITCH_FLOAT_WRITEBACK",
                            macro_expansion_parent=None,
                        )
                        existing.add(_key)

    def _stitch_virtual_ref_write_back(self, contexts: Dict[str, Any]) -> None:
        """B-2c: Write-back bridge for virtual method dispatch (CHA expansion).

        Complements ``_stitch_floating_ref_write_back``: while that step handles
        function-pointer calls where the callee name appears literally in the
        ``call_arg`` node but lacks an ARG_BRIDGE chain, this step additionally
        covers virtual method calls where the ``call_arg`` is qualified with a
        **base-class** name and the actual implementation is in a **derived** class.

        Example
        -------
        ::

            caller  →arg_bind→  call_arg:IProcessor::process#0
            IProcessor has subclass ConcreteProcessor  (from class_bases CHA map)
            ConcreteProcessor::process writes struct_field:ConcreteProcessor::process::pa.fieldX
            caller has struct_field:lwrCommon.fieldX  →arg_bind→  call_arg:IProcessor::process#0
            ↕ bridge emitted here

        Strategy
        --------
        1. Build ``global_subclasses`` (base → [derived]) by reading ``class_bases``
           from all C++ context units — mirrors ``file_call_graph._build_global_subclasses``.
        2. Pre-build ``funcs_with_arg_bridge`` to avoid double-counting with the normal
           B-2 write-back path.
        3. Scan ``call_arg`` nodes for the pattern ``BaseName::method#N``.
           Skip if ``BaseName`` has no CHA subclasses or if the normal path already
           handles this callee.
        4. For each matching node collect caller struct_fields via ``arg_bind`` edges.
        5. Expand to derived callee names (``DerivedName::method``) and scan ``assign``
           edges for writes scoped to those callees.
        6. Match by normalised field-path suffix (exact, then first-dot-stripped) and
           emit bidirectional bridge edges.
        """
        existing = self._phase3_edges

        # --- Step 1: build CHA subclass map from blueprint contexts --------
        global_subclasses: Dict[str, List[str]] = {}  # base → [derived]
        for _fp, _ctx in contexts.items():
            _unit = _ctx.get_metadata("c_family_unit")
            if _unit is None:
                continue
            for _derived, _bases in (getattr(_unit, "class_bases", None) or {}).items():
                for _base in (_bases or []):
                    if _base and _derived not in global_subclasses.get(_base, []):
                        global_subclasses.setdefault(_base, []).append(_derived)

        if not global_subclasses:
            return  # no CHA data available — nothing to do

        # --- Step 2: pre-build ARG_BRIDGE guard set -------------------------
        funcs_with_arg_bridge: Set[str] = set()
        for _node in self.global_graph.nodes.values():
            if _node.kind != "parameter":
                continue
            if not _node.name.startswith("arg@"):
                continue
            _m = re.match(r"arg@(.+):[A-Z]\d+$", _node.name)
            if _m:
                funcs_with_arg_bridge.add(_m.group(1))

        # --- Step 3: scan call_arg nodes for BaseClass::method#N -----------
        # caller_fields_by_derived_callee: derived callee name → Set[caller SF ids]
        caller_fields_by_derived_callee: Dict[str, Set[str]] = {}

        for _node in list(self.global_graph.nodes.values()):
            if _node.kind != "call_arg":
                continue
            _ca_name = _node.name
            if "#" not in _ca_name or "::" not in _ca_name:
                continue
            try:
                _func_name, _slot_str = _ca_name.rsplit("#", 1)
                int(_slot_str)
            except ValueError:
                continue
            if _func_name in funcs_with_arg_bridge:
                continue
            # Split BaseClass::method (last :: separates method from class chain)
            _dcolon = _func_name.rfind("::")
            if _dcolon < 0:
                continue
            _base_class = _func_name[:_dcolon]
            _method_name = _func_name[_dcolon + 2:]
            if not _base_class or not _method_name:
                continue
            _subclasses = global_subclasses.get(_base_class, [])
            if not _subclasses:
                continue

            # Collect caller struct_fields bound to this call_arg via arg_bind.
            _caller_sfs: Set[str] = set()
            for _edge in self.global_graph.edges:
                if _edge.relation != "arg_bind":
                    continue
                if _edge.target != _node.node_id:
                    continue
                _src_k, _ = self._split_node_id(_edge.source)
                if _src_k in ("struct_field", "variable"):
                    _caller_sfs.add(_edge.source)
            if not _caller_sfs:
                continue

            for _sub in _subclasses:
                _derived_callee = f"{_sub}::{_method_name}"
                if _derived_callee in funcs_with_arg_bridge:
                    continue
                caller_fields_by_derived_callee.setdefault(
                    _derived_callee, set()
                ).update(_caller_sfs)

        if not caller_fields_by_derived_callee:
            return

        # --- Step 4 & 5: callee writes scoped to derived callee names -------
        callee_writes_by_func: Dict[str, Dict[str, str]] = {}  # func → {tail → node_id}
        for _edge in self.global_graph.edges:
            if _edge.relation != "assign":
                continue
            _dst_k, _dst_n = self._split_node_id(_edge.target)
            if _dst_k not in ("struct_field", "variable"):
                continue
            if "::" not in _dst_n:
                continue
            _scope, _rest = _dst_n.split("::", 1)
            # Only consider callee scopes in our derived-callee set.
            # The scope is the first segment; look for derived callee prefixes.
            for _dc in list(caller_fields_by_derived_callee.keys()):
                # _dc = "DerivedClass::method"; the node scope uses "::" separator
                # so the struct_field name starts with the derived class prefix.
                _dc_class = _dc.split("::")[0]
                if _scope == _dc_class:
                    _tail = _rest.lower()
                    callee_writes_by_func.setdefault(_dc, {})[_tail] = _edge.target

        # --- Step 6: field-path suffix matching and bridge emission ---------
        for _dc, _caller_sf_ids in caller_fields_by_derived_callee.items():
            _callee_tails = callee_writes_by_func.get(_dc)
            if not _callee_tails:
                continue

            for _caller_sf_id in _caller_sf_ids:
                _, _caller_n = self._split_node_id(_caller_sf_id)
                _caller_tail = (
                    _caller_n.split("::")[-1] if "::" in _caller_n else _caller_n
                ).lower()

                _callee_sf_id = _callee_tails.get(_caller_tail)

                # Fallback: strip the base parameter name (first-dot prefix)
                if not _callee_sf_id:
                    _dp = _caller_tail.find(".")
                    if _dp >= 0:
                        _fp = _caller_tail[_dp + 1:]
                        for _ck, _csid in _callee_tails.items():
                            _cdp = _ck.find(".")
                            if _cdp >= 0 and _ck[_cdp + 1:] == _fp:
                                _callee_sf_id = _csid
                                break

                if not _callee_sf_id:
                    continue

                _, _callee_sf_n = self._split_node_id(_callee_sf_id)
                _, _caller_sf_n = self._split_node_id(_caller_sf_id)

                _callee_sf_k = (
                    "struct_field"
                    if self.global_graph.get_node_id(_callee_sf_n, "struct_field")
                    else "variable"
                    if self.global_graph.get_node_id(_callee_sf_n, "variable")
                    else None
                )
                _caller_sf_k = (
                    "struct_field"
                    if self.global_graph.get_node_id(_caller_sf_n, "struct_field")
                    else "variable"
                    if self.global_graph.get_node_id(_caller_sf_n, "variable")
                    else None
                )
                if not _callee_sf_k or not _caller_sf_k:
                    continue

                if _callee_sf_k == "struct_field" and _caller_sf_k == "struct_field":
                    self._add_struct_field_bridge_pair(
                        left_name=_callee_sf_n,
                        right_name=_caller_sf_n,
                        expression="global_lineage_stitch:virtual_ref_write_back",
                        statement_id="GLOBAL_STITCH_VIRTUAL_WRITEBACK",
                        existing_edges=existing,
                    )
                else:
                    for _sn, _sk, _dn, _dk in [
                        (_callee_sf_n, _callee_sf_k, _caller_sf_n, _caller_sf_k),
                        (_caller_sf_n, _caller_sf_k, _callee_sf_n, _callee_sf_k),
                    ]:
                        _sid = self.global_graph.get_node_id(_sn, _sk)
                        _did = self.global_graph.get_node_id(_dn, _dk)
                        if not _sid or not _did:
                            continue
                        _ekey = (_sid, _did, "assign")
                        if _ekey in existing:
                            continue
                        self.global_graph.add_assignment(
                            _sn, _sk, _dn, _dk,
                            file="<global>", line=0,
                            expression="global_lineage_stitch:virtual_ref_write_back",
                            scope="(global_stitch)",
                            statement_id="GLOBAL_STITCH_VIRTUAL_WRITEBACK",
                            macro_expansion_parent=None,
                        )
                        existing.add(_ekey)

    def _normalize_memory_name(self, name: str) -> str:
        """Normalize memory name to improve cross-CSECT stitching."""
        base = name
        if ":" in base and "::" not in base:
            parts = base.split(":", 1)
            left, right = parts[0], parts[1]
            if left and left.replace("_", "").isalnum():
                base = right
        if "::" in base:
            base = base.split("::")[-1]
        # Normalize any simple accessor-function prefix, e.g. ecbptr()->field or ctx().field.
        base = re.sub(r"^(?:[A-Za-z_]\w*::)*[A-Za-z_]\w*\(\)\s*(?:->|\.)\s*", "", base)
        base = base.replace("->", ".")
        base = base.lower()
        # Bridge common z/TPF field aliases (ASM labels <-> C++ field paths).
        if base == "appstat":
            return "flags.status"
        if base == "scratch_p8":
            return "scratch"
        if ".flags.status" in base:
            return "flags.status"
        if ".scratch" in base:
            return "scratch"
        if "(" in base and ")" in base and not base.startswith("="):
            base = base.replace("(", "").replace(")", "")
        base = base.replace(" ", "")
        return base
