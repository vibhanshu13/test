"""GVL-completeness emitters for the chainless tracer's hard C++ cases (Step 5b).

The chainless backward tracer can only recover what the C++ GVL encodes.  These
PURE helpers produce the extra edges / metadata the tracer's ``cha_resolver``
and downstream walker consume so that union aliasing, pointer arithmetic,
short-circuit guards, exception paths, virtual dispatch and function pointers
become traceable (exactly where possible, sound over-approximation otherwise).

This module is additive and side-effect-free: the parser passes call these
during ``variable_lineage`` construction; activating them requires a one-time
C++ re-ingest to populate the new edges.  Existing ingestion is unaffected until
the calls are wired in.

Consumer side (already built + tested):
  backward_traversal/runner/cha_resolver.py  — cha_candidate_seeds / fnptr_candidate_seeds / follow_may_alias
  backward_traversal/runner/chainless_dep_resolver.py — guard handling
"""

from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Union member aliasing (over-approx: every member may-aliases every other)
# ---------------------------------------------------------------------------

def union_may_alias_edges(
    union_name: str, members: Iterable[str], *, file: str = "", line: int = 0
) -> List[Dict[str, Any]]:
    """``may_alias`` edges among all members of a union.

    A write to one member may change reads of any other, so we link every
    ordered pair (the tracer follows either direction).  Sound over-approx.
    """
    ms = [str(m) for m in members if m]
    edges: List[Dict[str, Any]] = []
    for i, a in enumerate(ms):
        for b in ms[i + 1:]:
            sa = f"struct_field:{union_name}.{a}"
            sb = f"struct_field:{union_name}.{b}"
            edges.append({"source": sa, "target": sb, "relation": "may_alias",
                          "kind": "union", "file": file, "line": line})
    return edges


# ---------------------------------------------------------------------------
# Pointer-arithmetic aliasing (deref of p+/-k may-aliases the base object)
# ---------------------------------------------------------------------------

def pointer_arith_may_alias_edge(
    deref_node: str, base_node: str, *, file: str = "", line: int = 0
) -> Optional[Dict[str, Any]]:
    """``may_alias`` edge from a ``*(p+k)`` / ``p[i]`` deref to its base object."""
    if not deref_node or not base_node or deref_node == base_node:
        return None
    return {"source": deref_node, "target": base_node, "relation": "may_alias",
            "kind": "ptr_arith", "file": file, "line": line}


# ---------------------------------------------------------------------------
# Short-circuit guard decomposition (&&/||  →  atomic guard conditions)
# ---------------------------------------------------------------------------

_SPLIT_RE = re.compile(r"\s*(?:&&|\|\|)\s*")


def decompose_shortcircuit(condition: str) -> List[str]:
    """Split a composite guard into atomic operand conditions, preserving each.

    ``a && (b == 2) || c``  ->  ["a", "(b == 2)", "c"].  Parentheses are kept so
    the dep-resolver can still extract operator/constant from each atom.
    """
    raw = str(condition or "").strip()
    if not raw:
        return []
    atoms = [a.strip() for a in _SPLIT_RE.split(raw) if a.strip()]
    return atoms or [raw]


# ---------------------------------------------------------------------------
# Exception-path guard tagging
# ---------------------------------------------------------------------------

def exception_path_tag(handler_type: str = "") -> str:
    """A conditional_context tag marking an assignment as on a catch path."""
    ht = str(handler_type or "...").strip() or "..."
    return f"exception_path:{ht}"


# ---------------------------------------------------------------------------
# CHA: normalise the class hierarchy into a derived/base closure
# ---------------------------------------------------------------------------

def cha_class_closure(class_bases: Dict[str, List[str]]) -> Dict[str, List[str]]:
    """Transitive base closure per class, for class-hierarchy analysis.

    Returns ``{class: [all transitive bases]}``.  The ``cha_resolver`` walks the
    full set of classes (keys + base values) to enumerate every override
    candidate (over-approx — never misses an override).
    """
    closure: Dict[str, List[str]] = {}
    for cls in class_bases:
        seen: List[str] = []
        stack = list(class_bases.get(cls, []) or [])
        while stack:
            b = stack.pop()
            if b in seen:
                continue
            seen.append(b)
            stack.extend(class_bases.get(b, []) or [])
        closure[cls] = seen
    return closure


# ---------------------------------------------------------------------------
# Address-taken function table (for function-pointer over-approximation)
# ---------------------------------------------------------------------------

def address_taken_table(
    funcs: Iterable[Tuple[str, str]]
) -> Dict[str, List[str]]:
    """Build ``{signature: [func, ...]}`` from ``(func_name, signature)`` pairs.

    Functions whose address is taken are candidate function-pointer targets; the
    tracer over-approximates by seeding every same-signature candidate.
    """
    table: Dict[str, List[str]] = {}
    for fn, sig in funcs:
        if not fn:
            continue
        key = str(sig or "*")
        table.setdefault(key, [])
        if fn not in table[key]:
            table[key].append(fn)
    return table
