"""Analysis passes for assembly code."""

from passes.symbol_resolver import SymbolResolverPass
from passes.call_graph_builder import CallGraphBuilderPass
from passes.data_flow_tracker import DataFlowTracker
from passes.db_operation_extractor import DBOperationExtractorPass
from passes.file_dependency_builder import FileDependencyBuilderPass

__all__ = ['SymbolResolverPass', 'CallGraphBuilderPass', 'DataFlowTracker', 'DBOperationExtractorPass', 'FileDependencyBuilderPass']
