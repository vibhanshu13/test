"""Pass 2: Symbol Resolver.

Extracts all symbol definitions and populates the symbol table.
"""

from typing import List
from models.analysis_context import AnalysisContext
from tokenizer import ParsedLine
from symbol_parser import SymbolParser
from section_tracker import SectionTracker
from models.symbol import SymbolType


class SymbolResolverPass:
    """Pass 2: Resolve symbols and build symbol table.

    Processes all symbol-defining directives:
    - ENTRY, EXTRN, WXTRN
    - CSECT, DSECT, RSECT
    - EQU

    Populates AnalysisContext.symbol_table with complete mappings.
    """

    def __init__(self):
        self.parser = SymbolParser()
        self.section_tracker = SectionTracker()

    def process(self, lines: List[ParsedLine], context: AnalysisContext):
        """Process all lines and extract symbols.

        Args:
            lines: Preprocessed assembly lines
            context: Shared analysis context
        """
        for line in lines:
            # Track section boundaries
            if line.opcode and line.opcode.upper() in ("CSECT", "DSECT", "RSECT"):
                if line.label:
                    self.section_tracker.enter_section(
                        name=line.label,
                        section_type=line.opcode.upper(),
                        line=line.provenance.original_line,
                        file=line.provenance.original_file
                    )

            # Parse symbols
            current_section = self.section_tracker.current_section
            symbols = self.parser.parse_line(line, current_section=current_section)

            # Add to symbol table
            for symbol in symbols:
                if symbol.symbol_type in (SymbolType.EQU,):
                    # Section-scoped symbols
                    context.symbol_table.add_symbol(symbol, section=current_section)
                else:
                    # Global symbols
                    context.symbol_table.add_symbol(symbol)

        # Store section metadata in context
        context.add_metadata("sections", self.section_tracker.get_all_sections())
        context.add_metadata("section_count", len(self.section_tracker.get_all_sections()))
