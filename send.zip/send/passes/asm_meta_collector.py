"""Collect additional ASM blueprint metadata such as aliases and base registers."""

import re
from typing import Dict, List, Optional, Set

from models.analysis_context import AnalysisContext
from models.symbol import SymbolType
from tokenizer import ParsedLine


class ASMMetaCollectorPass:
    """Collect alias and base-register metadata for ASM blueprint consumers."""

    _plain_symbol_re = re.compile(r"^[A-Za-z.$@#_][A-Za-z0-9.$@#_]*$")
    _wk_alias_re = re.compile(r"^WK_[A-Z0-9_]+$", re.IGNORECASE)

    def process(self, lines: List[ParsedLine], context: AnalysisContext) -> None:
        aliases = self._collect_aliases(context)
        aliases.update(self._collect_layout_aliases(lines))
        register_aliases = self._collect_register_aliases(context)
        base_registers = self._collect_base_registers(lines, aliases, register_aliases)
        context.add_metadata(
            "asm_meta",
            {
                "aliases": aliases,
                "base_registers": base_registers,
            },
        )

    def _collect_aliases(self, context: AnalysisContext) -> Dict[str, str]:
        aliases: Dict[str, str] = {}
        for symbol in getattr(context.symbol_table, "all_symbols", []):
            if symbol.symbol_type != SymbolType.EQU:
                continue
            expr = (symbol.expression or "").strip()
            if not expr or expr == "*":
                continue
            if self._looks_like_alias_expression(expr):
                aliases[symbol.name] = expr
        return aliases

    def _collect_register_aliases(self, context: AnalysisContext) -> Dict[str, str]:
        register_aliases: Dict[str, str] = {}
        for symbol in getattr(context.symbol_table, "all_symbols", []):
            if symbol.symbol_type != SymbolType.EQU:
                continue
            normalized = self._normalize_register_token(symbol.expression)
            if normalized:
                register_aliases[symbol.name] = normalized
        return register_aliases

    def _collect_layout_aliases(self, lines: List[ParsedLine]) -> Dict[str, str]:
        """Infer DSECT-style aliases such as WK_RRC -> EBW002 from anchor labels.

        This is intentionally narrow: it only promotes zero-length anchor labels
        that match the common WK_* working-storage alias pattern and resolves them
        to the next concrete storage label within the same section.
        """
        aliases: Dict[str, str] = {}
        pending_aliases_by_section: Dict[str, List[str]] = {}

        for line in lines:
            section = line.provenance.section or ""
            opcode = (line.opcode or "").upper()
            label = (line.label or "").strip()
            if not section or not label:
                continue
            if opcode not in {"DS", "DC", "EQU"}:
                continue

            if self._is_alias_anchor(opcode, line.operands, label):
                pending_aliases_by_section.setdefault(section, []).append(label)
                continue

            if not self._is_concrete_storage(opcode, line.operands, label):
                continue

            pending_aliases = pending_aliases_by_section.get(section, [])
            if not pending_aliases:
                continue
            for alias in pending_aliases:
                aliases.setdefault(alias, label)
            pending_aliases_by_section[section] = []

        return aliases

    def _collect_base_registers(
        self,
        lines: List[ParsedLine],
        aliases: Dict[str, str],
        register_aliases: Dict[str, str],
    ) -> Dict[str, str]:
        base_registers: Dict[str, str] = {}
        for line in lines:
            opcode = (line.opcode or "").upper()
            if opcode != "USING" or len(line.operands) < 2:
                continue
            base_symbol = self._resolve_base_symbol(line.operands[0].strip(), aliases)
            for raw_reg in line.operands[1:]:
                reg = self._normalize_register_token(raw_reg, register_aliases)
                if reg and base_symbol:
                    base_registers[reg] = base_symbol
        return base_registers

    def _resolve_base_symbol(self, symbol: str, aliases: Dict[str, str]) -> str:
        current = symbol
        seen: Set[str] = set()
        while current in aliases and current not in seen and self._plain_symbol_re.match(aliases[current]):
            seen.add(current)
            current = aliases[current]
        return current

    def _normalize_register_token(
        self,
        token: Optional[str],
        register_aliases: Optional[Dict[str, str]] = None,
    ) -> Optional[str]:
        if not token:
            return None
        normalized = token.strip().rstrip(",").upper()
        if register_aliases and normalized in register_aliases:
            return register_aliases[normalized]
        if re.fullmatch(r"R(?:1[0-5]|[0-9])", normalized):
            return normalized
        if normalized.isdigit():
            value = int(normalized)
            if 0 <= value <= 15:
                return f"R{value}"
        return None

    def _looks_like_alias_expression(self, expr: str) -> bool:
        if expr.isdigit():
            return False
        if self._normalize_register_token(expr):
            return False
        if expr.startswith("="):
            return False
        return True

    def _is_alias_anchor(self, opcode: str, operands: List[str], label: str) -> bool:
        if not self._wk_alias_re.match(label):
            return False
        if opcode == "EQU":
            return bool(operands) and operands[0].strip() == "*"
        if opcode in {"DS", "DC"} and operands:
            return operands[0].strip().startswith("0")
        return False

    def _is_concrete_storage(self, opcode: str, operands: List[str], label: str) -> bool:
        if not label:
            return False
        if opcode == "EQU":
            return False
        if opcode not in {"DS", "DC"}:
            return False
        if not operands:
            return False
        return not operands[0].strip().startswith("0")
