"""Data flow tracker for register state analysis.

Pass 4: Track data flow through registers to resolve indirect calls.
"""

from typing import Optional, List
from tokenizer import ParsedLine
from models.register_state import RegisterState, RegisterValue, ValueType
from literal_resolver import LiteralResolver
from models.analysis_context import AnalysisContext
from models.call_graph import CallGraph, CallType
from operation_classifier import (
    classify_asm_operation,
    extract_variables_from_line,
    ConditionalContextTracker,
    get_transformation_description
)


class DataFlowTracker:
    """Track data flow through registers.

    Analyzes load operations (L, LR, LA, etc.) to track what values
    are loaded into registers. This enables resolution of indirect calls.
    """

    def __init__(self):
        self.register_state = RegisterState()
        self.literal_resolver = LiteralResolver()
        self.resolved_calls = []
        self.current_routine: Optional[str] = None
        self.conditional_tracker = ConditionalContextTracker()

    def process_line(self, line: ParsedLine, current_section: str):
        """Process a line and update register state.

        Args:
            line: Parsed assembly line
            current_section: Current section name
        """
        # Skip if no opcode
        if not line.opcode:
            return

        operation = line.opcode.upper()

        # Handle different load operations
        if operation == "L":
            self._handle_load(line)
        elif operation == "LR":
            self._handle_load_register(line)
        elif operation == "LA":
            self._handle_load_address(line)
        # Handle store operations
        elif operation == "ST":
            self._handle_store(line)
        elif operation == "STM":
            self._handle_store_multiple(line)
        elif operation == "STH":
            self._handle_store_halfword(line)
        # Handle data movement operations
        elif operation == "MVC":
            self._handle_move_characters(line)
        elif operation == "MVCL":
            self._handle_move_long(line)
        elif operation == "MVCIN":
            self._handle_move_inverse(line)
        # Handle data transformation operations
        elif operation in ("AR", "A", "AH"):  # Add
            self._handle_arithmetic_operation(line, "add")
        elif operation in ("SR", "S", "SH"):  # Subtract
            self._handle_arithmetic_operation(line, "subtract")
        elif operation in ("MR", "M", "MH"):  # Multiply
            self._handle_arithmetic_operation(line, "multiply")
        elif operation in ("DR", "D"):  # Divide
            self._handle_arithmetic_operation(line, "divide")
        elif operation in ("NR", "N"):  # AND
            self._handle_logical_operation(line, "and")
        elif operation in ("OR", "O"):  # OR
            self._handle_logical_operation(line, "or")
        elif operation in ("XR", "X"):  # XOR
            self._handle_logical_operation(line, "xor")
        elif operation in ("SLA", "SRA", "SLL", "SRL"):  # Shift
            self._handle_shift_operation(line)
        # Add more operations as needed

    def _handle_load(self, line: ParsedLine):
        """Handle L (Load) instruction.

        L R1,D2(X2,B2) - Load word from memory into register
        Common pattern: L R15,=V(SYMBOL) - Load address of external symbol
        """
        if not line.operands or len(line.operands) < 2:
            return

        target_reg = line.operands[0]
        source = line.operands[1]

        # Check if source is a literal
        if self.literal_resolver.is_literal(source):
            literal_info = self.literal_resolver.resolve(source)
            if literal_info and "symbol" in literal_info:
                # Address literal: =V(symbol) or =A(symbol)
                self.register_state.set_register(
                    target_reg,
                    RegisterValue(
                        value_type=ValueType.LITERAL,
                        literal=source
                    )
                )
                return

        # For now, mark as unknown if not a recognized literal
        self.register_state.clear_register(target_reg)

    def _handle_load_register(self, line: ParsedLine):
        """Handle LR (Load Register) instruction.

        LR R1,R2 - Copy value from R2 to R1
        """
        if not line.operands or len(line.operands) < 2:
            return

        dest_reg = line.operands[0]
        source_reg = line.operands[1]

        # Copy register value
        self.register_state.copy_register(dest_reg, source_reg)

    def _handle_load_address(self, line: ParsedLine):
        """Handle LA (Load Address) instruction.

        LA R1,SYMBOL - Load address of symbol into register
        """
        if not line.operands or len(line.operands) < 2:
            return

        target_reg = line.operands[0]
        address = line.operands[1]

        # Store as address type
        self.register_state.set_register(
            target_reg,
            RegisterValue(
                value_type=ValueType.ADDRESS,
                address=address
            )
        )

    def _handle_store(self, line: ParsedLine):
        """Handle ST (Store) instruction.

        ST R1,D2(X2,B2) - Store word from register to memory
        """
        if not line.operands or len(line.operands) < 2:
            return

        source_reg = line.operands[0]
        target_address = line.operands[1]

        # Get value from source register
        reg_value = self.register_state.get_register(source_reg)

        # Note: We're storing from register to memory
        # In a full implementation, we would track memory state
        # For now, we just acknowledge the store operation occurred
        # This is useful for data lineage tracking

    def _handle_store_multiple(self, line: ParsedLine):
        """Handle STM (Store Multiple) instruction.

        STM R1,R3,D2(B2) - Store multiple registers to memory
        """
        if not line.operands or len(line.operands) < 3:
            return

        # STM stores registers from R1 to R3 into consecutive memory locations
        start_reg = line.operands[0]
        end_reg = line.operands[1]
        target_address = line.operands[2]

        # Parse register numbers
        try:
            start_num = int(start_reg.replace("R", "").replace("r", ""))
            end_num = int(end_reg.replace("R", "").replace("r", ""))

            # Track that these registers were stored
            # In a full implementation, would track memory state
            for reg_num in range(start_num, end_num + 1):
                reg_name = f"R{reg_num}"
                reg_value = self.register_state.get_register(reg_name)
        except ValueError:
            # Could not parse register numbers
            pass

    def _handle_store_halfword(self, line: ParsedLine):
        """Handle STH (Store Halfword) instruction.

        STH R1,D2(X2,B2) - Store halfword (2 bytes) from register to memory
        """
        if not line.operands or len(line.operands) < 2:
            return

        source_reg = line.operands[0]
        target_address = line.operands[1]

        # Get value from source register (lower 2 bytes)
        reg_value = self.register_state.get_register(source_reg)

        # Track the store operation
        # In a full implementation, would track memory state

    def _handle_move_characters(self, line: ParsedLine):
        """Handle MVC (Move Characters) instruction.

        MVC D1(L,B1),D2(B2) - Move up to 256 characters from source to destination
        Example: MVC TARGET(10),SOURCE
        """
        if not line.operands or len(line.operands) < 2:
            return

        destination = line.operands[0]
        source = line.operands[1]

        # Parse length from destination operand if present
        # Format: DEST(LEN) or DEST(LEN,BASE)
        # Track that data moved from source to destination
        # In a full implementation, would track memory-to-memory data flow

    def _handle_move_long(self, line: ParsedLine):
        """Handle MVCL (Move Long) instruction.

        MVCL R1,R3 - Move variable-length data
        R1 contains destination address, R1+1 contains length
        R3 contains source address, R3+1 contains length/pad
        """
        if not line.operands or len(line.operands) < 2:
            return

        dest_reg = line.operands[0]
        source_reg = line.operands[1]

        # Get the destination and source addresses from registers
        dest_value = self.register_state.get_register(dest_reg)
        source_value = self.register_state.get_register(source_reg)

        # Track that data moved between memory locations
        # The length is in the next odd register (R1+1, R3+1)

    def _handle_move_inverse(self, line: ParsedLine):
        """Handle MVCIN (Move Inverse) instruction.

        MVCIN D1(L,B1),D2(B2) - Move characters in reverse order
        Similar to MVC but moves data in reverse
        """
        if not line.operands or len(line.operands) < 2:
            return

        destination = line.operands[0]
        source = line.operands[1]

        # Track that data moved from source to destination in reverse
        # In a full implementation, would track memory-to-memory data flow

    def _handle_arithmetic_operation(self, line: ParsedLine, operation: str):
        """Handle arithmetic operations (add, subtract, multiply, divide).

        Examples:
        - AR R1,R2 (add R2 to R1)
        - A R1,VALUE (add memory value to R1)
        - SR R3,R4 (subtract R4 from R3)
        """
        if not line.operands or len(line.operands) < 2:
            return

        target_reg = line.operands[0]

        # After arithmetic operation, register contains computed value
        # Mark as UNKNOWN since we can't determine exact value statically
        self.register_state.clear_register(target_reg)

    def _handle_logical_operation(self, line: ParsedLine, operation: str):
        """Handle logical operations (AND, OR, XOR).

        Examples:
        - NR R1,R2 (AND R1 with R2)
        - OR R3,R4 (OR R3 with R4)
        - XR R5,R6 (XOR R5 with R6)
        """
        if not line.operands or len(line.operands) < 2:
            return

        target_reg = line.operands[0]

        # After logical operation, register contains computed value
        # Mark as UNKNOWN since we can't determine exact value statically
        self.register_state.clear_register(target_reg)

    def _handle_shift_operation(self, line: ParsedLine):
        """Handle shift operations (SLA, SRA, SLL, SRL, etc.).

        Examples:
        - SLA R1,4 (shift left arithmetic R1 by 4 bits)
        - SRL R2,8 (shift right logical R2 by 8 bits)
        """
        if not line.operands or len(line.operands) < 1:
            return

        target_reg = line.operands[0]

        # After shift operation, register contains computed value
        # Mark as UNKNOWN since we can't determine exact value statically
        self.register_state.clear_register(target_reg)

    def process(self, lines: List[ParsedLine], context: AnalysisContext):
        """Process all lines and track data flow.

        Args:
            lines: Parsed assembly lines
            context: Shared analysis context
        """
        # Get variable names from context
        var_set = context.get_variable_names("asm")

        # Get or create lineage graph
        lineage_graph = context.get_metadata("variable_lineage")

        for line in lines:
            # Track current routine
            if line.label and line.opcode and line.opcode.upper() in ("CSECT", "ENTRY"):
                self.current_routine = line.label
                # Clear register state on new routine
                self.register_state.clear_all()
                # Clear conditional tracker on new routine
                self.conditional_tracker.clear()

            # Process instruction for register tracking
            if line.opcode:
                opcode_upper = line.opcode.upper()

                # Track conditional context
                self.conditional_tracker.process_line(line, var_set)

                # Process line to update register state
                self.process_line(line, self.current_routine or "")

                # Universe-aware variable tracking
                if var_set and lineage_graph:
                    self._track_variable_operations(line, var_set, lineage_graph, context)

                # Check if this is an indirect call instruction
                if opcode_upper in ("BALR", "BASR"):
                    # Try to resolve indirect call
                    self._resolve_indirect_call(line, context)

        # Store tracker and resolved calls in context
        context.add_metadata("data_flow_tracker", self)
        context.add_metadata("resolved_indirect_calls", self.resolved_calls)

    def _resolve_indirect_call(self, line: ParsedLine, context: AnalysisContext):
        """Try to resolve an indirect call using register state.

        Pattern: L R15,=V(TARGET) followed by BASR R14,R15
        We can resolve BASR target by looking at R15 state.

        Args:
            line: Parsed line (call instruction)
            context: Analysis context
        """
        if not line.operands or len(line.operands) < 2:
            return

        # Get target register
        target_register = line.operands[1]

        # Get register state
        reg_value = self.register_state.get_register(target_register)

        if reg_value.value_type == ValueType.LITERAL and reg_value.literal:
            # Resolve the literal to get symbol
            literal_info = self.literal_resolver.resolve(reg_value.literal)
            if literal_info and "symbol" in literal_info:
                target_symbol = literal_info["symbol"]

                # Record resolved call
                self.resolved_calls.append({
                    "routine": self.current_routine,
                    "register": target_register,
                    "target": target_symbol,
                    "file": line.provenance.original_file,
                    "line": line.provenance.original_line,
                    "instruction": line.opcode
                })

    def _track_variable_operations(self, line: ParsedLine, var_set, lineage_graph, context: AnalysisContext):
        """Track variable operations with universe-aware enrichment.

        Args:
            line: Parsed line
            var_set: Set of known variable names from universe
            lineage_graph: Variable lineage graph
            context: Analysis context
        """
        if not line.opcode:
            return

        # Extract variables on this line
        variables = extract_variables_from_line(line, var_set)

        if not variables:
            return

        # Classify the operation
        operation_type = classify_asm_operation(line.opcode)

        # Get transformation description
        transformation = get_transformation_description(
            line.opcode,
            line.operands if line.operands else []
        )

        # For each variable, get its conditional context and record the operation
        for var in variables:
            conditional_context = self.conditional_tracker.get_conditions_for_variable(var)

            # Determine if this is an initialization
            initialization_method = None
            if operation_type == "initialize":
                # Check if it's a DS/DC/EQU initialization
                if line.opcode.upper() in ("DS", "DC"):
                    initialization_method = "direct"
                elif line.opcode.upper() == "EQU":
                    initialization_method = "direct"

            # For now, we add this as metadata to existing edges
            # The lineage graph should already have edges for this variable
            # We're enriching them with operation_type, conditional_context, etc.

            # Store enriched operation info as metadata
            # This will be picked up when lineage edges are created elsewhere
            if not hasattr(context, '_variable_operation_cache'):
                context._variable_operation_cache = {}

            key = f"{var}_{line.provenance.original_file}_{line.provenance.original_line}"
            context._variable_operation_cache[key] = {
                "operation_type": operation_type,
                "initialization_method": initialization_method,
                "conditional_context": conditional_context if conditional_context else None,
                "transformation": transformation
            }
