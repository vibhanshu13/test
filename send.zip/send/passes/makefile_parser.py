"""Lightweight Makefile parser for build metadata extraction."""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Set


@dataclass
class MakefileTarget:
    name: str
    deps: List[str]
    line: int


@dataclass
class MakefileAssignment:
    name: str
    op: str
    value: str
    line: int


@dataclass
class MakefileRecipe:
    line: int
    command: str


class MakefileParser:
    """Parse Makefiles (.mak/Makefile) for build-related metadata."""

    SOURCE_EXTS = (".c", ".cc", ".cpp", ".cxx", ".h", ".hpp", ".asm", ".s", ".mac", ".cpy", ".copy")

    def parse(self, file_path: Path, content: str) -> Dict[str, object]:
        lines = self._join_continuations(content.splitlines())

        variables: Dict[str, str] = {}
        assignments: List[MakefileAssignment] = []
        includes: List[str] = []
        targets: List[MakefileTarget] = []
        recipes: List[MakefileRecipe] = []

        referenced_vars: Set[str] = set()
        defines: Set[str] = set()
        include_dirs: Set[str] = set()
        lib_dirs: Set[str] = set()
        libs: Set[str] = set()
        outputs: Set[str] = set()
        shared_objects: Set[str] = set()
        source_files: Set[str] = set()

        for idx, raw_line in enumerate(lines, start=1):
            if not raw_line.strip():
                continue

            is_recipe = raw_line.startswith("\t")
            line = raw_line if is_recipe else self._strip_comment(raw_line)
            stripped = line.strip()
            if not stripped:
                continue

            if not is_recipe:
                include_match = re.match(r'^\s*-?include\s+(.+)$', stripped)
                if include_match:
                    include_files = self._split_words(include_match.group(1))
                    includes.extend(include_files)
                    continue

                assign_match = re.match(
                    r'^\s*(export\s+)?([A-Za-z0-9_.-]+)\s*([:+?]?=)\s*(.*)$',
                    line
                )
                if assign_match:
                    name = assign_match.group(2)
                    op = assign_match.group(3)
                    value = assign_match.group(4).strip()
                    assignments.append(MakefileAssignment(name=name, op=op, value=value, line=idx))

                    if op == "+=" and name in variables:
                        variables[name] = f"{variables[name]} {value}".strip()
                    elif op == "?=":
                        if name not in variables:
                            variables[name] = value
                    else:
                        variables[name] = value

                    referenced_vars.update(self._extract_var_refs(value))
                    self._extract_flags(value, defines, include_dirs, lib_dirs, libs, outputs, shared_objects)
                    self._collect_sources(value, source_files)
                    continue

                target_match = re.match(r'^\s*([^\s:]+)\s*:(.*)$', line)
                if target_match:
                    target = target_match.group(1)
                    deps = self._split_words(target_match.group(2))
                    targets.append(MakefileTarget(name=target, deps=deps, line=idx))
                    if target.endswith(".so"):
                        shared_objects.add(target)
                        outputs.add(target)
                    for dep in deps:
                        self._collect_sources(dep, source_files)
                    continue

            if is_recipe:
                command = stripped
                recipes.append(MakefileRecipe(line=idx, command=command))
                referenced_vars.update(self._extract_var_refs(command))
                self._extract_flags(command, defines, include_dirs, lib_dirs, libs, outputs, shared_objects)
                self._collect_sources(command, source_files)

        defined_vars = set(variables.keys())
        external_vars = sorted(v for v in referenced_vars if v not in defined_vars)

        return {
            "file": str(file_path),
            "variables": variables,
            "variable_assignments": [assignment.__dict__ for assignment in assignments],
            "includes": includes,
            "targets": [target.__dict__ for target in targets],
            "recipes": [recipe.__dict__ for recipe in recipes],
            "defines": sorted(defines),
            "include_dirs": sorted(include_dirs),
            "lib_dirs": sorted(lib_dirs),
            "libs": sorted(libs),
            "outputs": sorted(outputs),
            "shared_objects": sorted(shared_objects),
            "source_files": sorted(source_files),
            "referenced_variables": sorted(referenced_vars),
            "external_variables": external_vars,
        }

    def _join_continuations(self, lines: List[str]) -> List[str]:
        joined: List[str] = []
        buffer: List[str] = []
        for line in lines:
            if line.rstrip().endswith("\\"):
                buffer.append(line.rstrip()[:-1])
                continue
            if buffer:
                buffer.append(line)
                joined.append(" ".join(part.strip() for part in buffer))
                buffer = []
            else:
                joined.append(line)
        if buffer:
            joined.append(" ".join(part.strip() for part in buffer))
        return joined

    def _strip_comment(self, line: str) -> str:
        escaped = False
        for idx, char in enumerate(line):
            if char == "\\" and not escaped:
                escaped = True
                continue
            if char == "#" and not escaped:
                return line[:idx]
            escaped = False
        return line

    def _split_words(self, value: str) -> List[str]:
        return [token for token in value.strip().split() if token]

    def _extract_var_refs(self, value: str) -> Set[str]:
        refs = set()
        for match in re.finditer(r'\$\(([^)]+)\)|\${([^}]+)}', value):
            name = match.group(1) or match.group(2)
            if name:
                refs.add(name.strip())
        return refs

    def _extract_flags(
        self,
        value: str,
        defines: Set[str],
        include_dirs: Set[str],
        lib_dirs: Set[str],
        libs: Set[str],
        outputs: Set[str],
        shared_objects: Set[str],
    ) -> None:
        tokens = self._split_words(value)
        i = 0
        while i < len(tokens):
            token = tokens[i]
            if token == "-D" and i + 1 < len(tokens):
                defines.add(tokens[i + 1])
                i += 2
                continue
            if token.startswith("-D") and len(token) > 2:
                defines.add(token[2:])
            elif token == "-I" and i + 1 < len(tokens):
                include_dirs.add(tokens[i + 1])
                i += 2
                continue
            elif token.startswith("-I") and len(token) > 2:
                include_dirs.add(token[2:])
            elif token == "-L" and i + 1 < len(tokens):
                lib_dirs.add(tokens[i + 1])
                i += 2
                continue
            elif token.startswith("-L") and len(token) > 2:
                lib_dirs.add(token[2:])
            elif token == "-l" and i + 1 < len(tokens):
                libs.add(tokens[i + 1])
                i += 2
                continue
            elif token.startswith("-l") and len(token) > 2:
                libs.add(token[2:])
            elif token == "-o" and i + 1 < len(tokens):
                output = tokens[i + 1]
                outputs.add(output)
                if output.endswith(".so"):
                    shared_objects.add(output)
                i += 2
                continue
            else:
                if token.endswith(".so"):
                    shared_objects.add(token)
                    outputs.add(token)
                if token.endswith(".a"):
                    libs.add(token)
            i += 1

    def _collect_sources(self, value: str, source_files: Set[str]) -> None:
        tokens = self._split_words(value)
        for token in tokens:
            lowered = token.lower()
            if lowered.endswith(self.SOURCE_EXTS):
                source_files.add(token)
