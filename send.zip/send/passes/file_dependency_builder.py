"""Pass 6: File Dependency Graph Builder.

Builds file-level dependency graph from analysis context.
"""

from models.analysis_context import AnalysisContext
from models.file_dependency import (
    FileDependencyGraph,
    DependencyEvidence,
    DependencyType
)
from models.symbol import SymbolType


class FileDependencyBuilderPass:
    """Pass 6: Build file dependency graph.

    Aggregates dependencies from:
    - Pass 1: COPY includes
    - Pass 2: Symbol references (EXTRN → ENTRY)
    - Pass 3: Cross-file calls
    """

    def process(self, context: AnalysisContext):
        """Build file dependency graph from context.

        Args:
            context: Analysis context with results from previous passes
        """
        graph = FileDependencyGraph()

        # Extract COPY include dependencies (Pass 1)
        self._process_copy_includes(context, graph)

        # Extract symbol reference dependencies (Pass 2)
        self._process_symbol_references(context, graph)

        # Extract cross-file call dependencies (Pass 3)
        self._process_cross_file_calls(context, graph)

        # Detect circular dependencies
        self._detect_cycles(graph)

        # Store graph in context
        context.add_metadata("file_dependency_graph", graph)

    def _process_copy_includes(self, context: AnalysisContext, graph: FileDependencyGraph):
        """Process COPY include dependencies from Pass 1.

        Args:
            context: Analysis context
            graph: File dependency graph to populate
        """
        # Get all COPY includes from context
        all_includes = context.get_all_copy_includes()

        for include in all_includes:
            # Create evidence
            evidence = DependencyEvidence(
                dependency_type=DependencyType.COPY_INCLUDE,
                source_file=include.including_file,
                source_line=include.line_number,
                details=f"COPY {include.included_file}"
            )

            # Add edge to graph
            graph.add_edge(
                from_file=include.including_file,
                to_file=include.included_file,
                evidence=evidence
            )

    def _process_symbol_references(self, context: AnalysisContext, graph: FileDependencyGraph):
        """Process symbol reference dependencies from Pass 2.

        Args:
            context: Analysis context
            graph: File dependency graph to populate
        """
        symbol_table = context.metadata.get("symbol_table")
        if not symbol_table:
            return

        # Collect all EXTRN and ENTRY symbols from all_symbols list
        # This preserves all declarations, even when same symbol name appears multiple times
        extrn_symbols = {}  # name → list of files
        entry_symbols = {}  # name → file

        for symbol in symbol_table.all_symbols:
            if symbol.symbol_type == SymbolType.ENTRY:
                entry_symbols[symbol.name] = symbol.file
            elif symbol.symbol_type == SymbolType.EXTRN:
                if symbol.name not in extrn_symbols:
                    extrn_symbols[symbol.name] = []
                extrn_symbols[symbol.name].append(symbol.file)

        # Match EXTRN symbols to ENTRY definitions
        for symbol_name, extrn_files in extrn_symbols.items():
            if symbol_name in entry_symbols:
                # Found matching ENTRY
                target_file = entry_symbols[symbol_name]
                for source_file in extrn_files:
                    if source_file != target_file:
                        evidence = DependencyEvidence(
                            dependency_type=DependencyType.SYMBOL_REFERENCE,
                            source_file=source_file,
                            source_line=0,
                            details=f"EXTRN {symbol_name} → ENTRY in {target_file}"
                        )
                        graph.add_edge(source_file, target_file, evidence)
            else:
                # Unresolved EXTRN - external dependency
                for source_file in extrn_files:
                    evidence = DependencyEvidence(
                        dependency_type=DependencyType.EXTERNAL_LIBRARY,
                        source_file=source_file,
                        source_line=0,
                        details=f"EXTRN {symbol_name} (external)"
                    )
                    graph.add_edge(source_file, symbol_name, evidence)
                    graph.nodes[symbol_name].is_external = True

    def _process_cross_file_calls(self, context: AnalysisContext, graph: FileDependencyGraph):
        """Process cross-file call dependencies from Pass 3.

        Args:
            context: Analysis context
            graph: File dependency graph to populate
        """
        call_graph = context.get_metadata("call_graph")
        if not call_graph:
            return

        # Build a mapping of routine names to files from call graph nodes
        routine_to_file = {}
        for node_name, node in call_graph.nodes.items():
            if node.file:
                routine_to_file[node_name] = node.file

        # Process call edges to find cross-file calls
        for edge in call_graph.edges:
            # Skip if target is unknown (indirect calls)
            if not edge.target:
                continue

            # Get source file from the edge
            source_file = edge.file
            if not source_file:
                continue

            # Get target file from the node mapping
            target_file = routine_to_file.get(edge.target)
            if not target_file:
                # Target not found in nodes - might be external
                continue

            # Only create dependency if files are different
            if source_file != target_file:
                evidence = DependencyEvidence(
                    dependency_type=DependencyType.CROSS_FILE_CALL,
                    source_file=source_file,
                    source_line=edge.line,
                    details=f"Call from {edge.source} to {edge.target} ({edge.call_type.value})"
                )
                graph.add_edge(source_file, target_file, evidence)

    def _detect_cycles(self, graph: FileDependencyGraph):
        """Detect circular dependencies using DFS.

        Args:
            graph: File dependency graph
        """
        # Build adjacency list
        adjacency = {}
        for node in graph.nodes:
            adjacency[node] = []

        for edge in graph.edges:
            if edge.from_file not in adjacency:
                adjacency[edge.from_file] = []
            adjacency[edge.from_file].append(edge.to_file)

        # DFS-based cycle detection
        visited = set()
        rec_stack = set()
        cycles_found = []

        def dfs(node, path):
            visited.add(node)
            rec_stack.add(node)
            path.append(node)

            for neighbor in adjacency.get(node, []):
                if neighbor not in visited:
                    dfs(neighbor, path)
                elif neighbor in rec_stack:
                    # Found cycle
                    cycle_start = path.index(neighbor)
                    cycle = path[cycle_start:] + [neighbor]
                    cycles_found.append(cycle)

            path.pop()
            rec_stack.remove(node)

        # Check all nodes
        for node in adjacency:
            if node not in visited:
                dfs(node, [])

        # Deduplicate cycles using frozensets
        seen_cycles = set()
        unique_cycles = []

        for cycle in cycles_found:
            # Create a normalized representation: use frozenset to ignore order
            # Remove the duplicate last element for comparison (cycle[:-1])
            cycle_set = frozenset(cycle[:-1])

            if cycle_set not in seen_cycles:
                seen_cycles.add(cycle_set)
                unique_cycles.append(cycle)

        # Classify and store unique cycles
        for cycle in unique_cycles:
            # Count unique files (the cycle list has first == last, so use set)
            unique_files = len(set(cycle))
            # Simple cycle: 2 unique files (A → B → A)
            # Complex cycle: 3+ unique files (A → B → C → A)
            cycle_type = "simple" if unique_files == 2 else "complex"

            from models.file_dependency import CircularDependency
            graph.circular_dependencies.append(CircularDependency(
                files=cycle,
                cycle_type=cycle_type
            ))
