"""Macro collector pass - discovers and loads macro definitions."""

import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from macro_library import MacroLibrary
from macro_definition_parser import MacroDefinitionParser
from models.macro_definition import MacroDefinition

_log = logging.getLogger(__name__)


# Module-level cache: tuple(sorted search paths) -> list of discovered MacroDefinitions.
# Scoped to the process lifetime (one Celery worker); safe across jobs in the same
# worker because the filesystem content under those paths does not change during a job.
# auto_discover() always returns a FRESH MacroLibrary built from the cached list, so
# callers can mutate the returned library (e.g. collect_from_files) without corrupting
# the cache.
_discovery_cache: Dict[Tuple[str, ...], List[MacroDefinition]] = {}


class MacroCollector:
    """Collects macro definitions from files and directories.

    Supports:
    - Auto-discovery from search paths
    - Explicit file paths
    - Inline macros from source files
    """

    def __init__(self, search_paths: List[Path]):
        """Initialize macro collector.

        Args:
            search_paths: Directories to search for macro files
        """
        self.search_paths = search_paths
        self.parser = MacroDefinitionParser()
        # Per-instance cache: resolved file path -> MacroLibrary built from that file.
        # Phase 4 of the orchestrator calls collect_inline_macros() once per ASM file
        # using the same MacroCollector instance, so this avoids re-parsing unchanged
        # files from disk on every iteration.
        self._inline_macro_cache: Dict[Path, MacroLibrary] = {}

    def collect_from_file(self, file_path: Path) -> MacroLibrary:
        """Collect macros from a single file.

        Args:
            file_path: Path to macro definition file

        Returns:
            MacroLibrary with macros from file
        """
        library = MacroLibrary()

        macros = self.parser.parse_file(file_path)
        for macro in macros:
            try:
                library.add_macro(macro)
            except ValueError:
                # Duplicate macro - skip
                pass

        return library

    def collect_from_files(
        self,
        file_paths: List[Path],
        existing_library: Optional[MacroLibrary] = None
    ) -> MacroLibrary:
        """Collect macros from multiple files.

        Args:
            file_paths: List of macro definition files
            existing_library: Optional existing library to add to

        Returns:
            MacroLibrary with all macros
        """
        library = existing_library if existing_library else MacroLibrary()

        for file_path in file_paths:
            macros = self.parser.parse_file(file_path)
            for macro in macros:
                # Explicit files override existing
                library.add_macro(macro, override=True)

        return library

    def auto_discover(self) -> MacroLibrary:
        """Auto-discover macro files in search paths.

        Searches for *.asm, *.mac, *.cpy, and *.copy files in all search paths.
        Results are cached by search-path set so repeated calls within the same
        process (e.g. multiple jobs in one Celery worker) skip the filesystem scan.
        Always returns a fresh MacroLibrary instance so callers may mutate it
        freely without corrupting the cache.

        Returns:
            MacroLibrary with discovered macros
        """
        cache_key: Tuple[str, ...] = tuple(sorted(str(p) for p in self.search_paths))

        if cache_key in _discovery_cache:
            # Rebuild a fresh library from the cached macro list — O(macros), not O(files).
            library = MacroLibrary()
            for macro in _discovery_cache[cache_key]:
                try:
                    library.add_macro(macro)
                except ValueError:
                    pass
            return library

        # Cache miss: scan the filesystem.
        library = MacroLibrary()
        discovered: List[MacroDefinition] = []

        for search_path in self.search_paths:
            if not search_path.exists():
                continue

            all_files = (
                list(search_path.rglob("*.asm"))
                + list(search_path.rglob("*.mac"))
                + list(search_path.rglob("*.cpy"))
                + list(search_path.rglob("*.copy"))
            )

            for file_path in all_files:
                macros = self.parser.parse_file(file_path)
                for macro in macros:
                    try:
                        library.add_macro(macro)
                        discovered.append(macro)
                    except ValueError:
                        # Duplicate - skip
                        pass

        _discovery_cache[cache_key] = discovered
        return library

    def collect_inline_macros(self, source_file: Path) -> MacroLibrary:
        """Collect inline macros from a source file.

        Results are cached by file path so that repeated calls for the same
        file (common in the Phase 4 macro expansion loop) skip disk I/O and
        re-parsing.

        Args:
            source_file: Source file that may contain MACRO definitions

        Returns:
            MacroLibrary with inline macros (marked as local scope).
            The same cached instance is returned on cache hits — callers
            must not mutate the returned library.
        """
        resolved = source_file.resolve()
        cached = self._inline_macro_cache.get(resolved)
        if cached is not None:
            _log.debug("collect_inline_macros cache hit: %s", resolved)
            return cached

        library = MacroLibrary()
        macros = self.parser.parse_file(source_file)
        for macro in macros:
            # Mark as local scope
            macro.scope = "local"
            try:
                library.add_macro(macro)
            except ValueError:
                # Duplicate - skip
                pass

        self._inline_macro_cache[resolved] = library
        return library
