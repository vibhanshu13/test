"""Central LLM caller — use call_llm() anywhere in the pipeline."""

from __future__ import annotations

import logging
import threading
import time

from google import genai
from google.genai import types

logger = logging.getLogger(__name__)

# HTTP status codes that indicate a transient server-side problem worth retrying.
_RETRYABLE_HTTP_STATUS = frozenset({429, 500, 502, 503, 504})


def _is_retryable(exc: Exception) -> bool:
    """Return True when *exc* represents a transient error that is safe to retry."""
    # httpx transport-level timeout (may propagate before the SDK wraps it)
    try:
        import httpx
        if isinstance(exc, httpx.TimeoutException):
            return True
    except ImportError:
        pass
    # Google GenAI SDK error hierarchy
    try:
        from google.genai import errors as _ge
        if isinstance(exc, _ge.ServerError):          # 5xx
            return True
        if isinstance(exc, _ge.ClientError):          # 4xx — only 429 is retryable
            return getattr(exc, "status_code", None) == 429
    except (ImportError, AttributeError):
        pass
    # Last-resort string scan for when the SDK version doesn't expose the classes above
    msg = str(exc).lower()
    return any(kw in msg for kw in ("timeout", "timed out", "rate limit", "429", "503", "502"))

# ── Global concurrency cap ──────────────────────────────────────────────────
# A process-wide BoundedSemaphore bounds the number of Gemini calls in flight at
# once, no matter how many requests (or how wide a fan-out within one request)
# pile up. Without it, a single keyword-file-flow request could launch ~20
# parallel calls and a few concurrent users would exhaust threads/connections
# and hang every route. Built lazily so settings import stays deferred.
_semaphore_lock: threading.Lock = threading.Lock()
_semaphore_instance: threading.BoundedSemaphore | None = None


def _get_semaphore() -> threading.BoundedSemaphore:
    global _semaphore_instance
    if _semaphore_instance is None:
        with _semaphore_lock:
            if _semaphore_instance is None:
                n = max(1, int(getattr(_settings(), "LLM_MAX_CONCURRENCY", 6) or 1))
                _semaphore_instance = threading.BoundedSemaphore(n)
    return _semaphore_instance


# ── Singleton client ────────────────────────────────────────────────────────
# genai.Client is a heavyweight object (httpx connection pool, TLS context,
# proto descriptor cache, etc.).  Creating a new instance per call causes
# reference cycles that the generational GC cannot immediately collect,
# leading to hundreds of MB of stranded objects accumulating between GC runs
# during bulk emission (15 K files × N MB/client = multi-GB leak).
#
# A single shared client is safe: httpx.Client internally uses a thread-safe
# ConnectionPool, so concurrent calls from multiple ThreadPoolExecutor threads
# are fully supported.
_client_lock: threading.Lock = threading.Lock()
_client_instance: genai.Client | None = None


def _get_client() -> genai.Client:
    global _client_instance
    if _client_instance is None:
        with _client_lock:
            if _client_instance is None:
                from api.config import settings as _s
                _client_instance = genai.Client(api_key=_s.GEMINI_API_KEY)
    return _client_instance


def _settings():
    from api.config import settings
    return settings


def _build_config(
    s,
    system_prompt: str | None,
    apply_timeout: bool,
) -> types.GenerateContentConfig:
    """Assemble a GenerateContentConfig with optional system prompt + native timeout."""
    kwargs = {
        "max_output_tokens": s.LLM_MAX_TOKENS,
        "temperature": s.LLM_TEMPERATURE,
    }
    if system_prompt:
        kwargs["system_instruction"] = system_prompt
    # Native SDK timeout (milliseconds): the underlying httpx request is aborted
    # by the transport itself, so we no longer spawn a watchdog thread per call.
    if apply_timeout and int(s.LLM_CALL_TIMEOUT) > 0:
        kwargs["http_options"] = types.HttpOptions(timeout=int(s.LLM_CALL_TIMEOUT) * 1000)
    return types.GenerateContentConfig(**kwargs)


def call_llm(prompt: str, system_prompt: str | None = None) -> str:
    """Call the configured Gemini model and return the response text.

    The hard timeout is enforced natively by the SDK transport via
    ``settings.LLM_CALL_TIMEOUT`` seconds (0 = no timeout) — no watchdog thread.
    A process-wide semaphore caps concurrent calls.  Transient errors (timeout,
    rate-limit, 5xx) are retried up to ``settings.LLM_MAX_RETRIES`` times with
    exponential backoff (1 s, 2 s, 4 s, …).  The semaphore is released between
    attempts so other callers are not starved during the back-off sleep.
    """
    s = _settings()
    client = _get_client()  # reuse shared singleton — no per-call allocation
    config = _build_config(s, system_prompt, apply_timeout=True)
    max_retries = max(0, int(getattr(s, "LLM_MAX_RETRIES", 3)))

    last_exc: Exception | None = None
    for attempt in range(max_retries + 1):
        if attempt > 0:
            wait = 2 ** (attempt - 1)  # 1 s, 2 s, 4 s, …
            logger.warning(
                "[call_llm] transient error on attempt %d/%d — retrying in %d s: %s",
                attempt, max_retries + 1, wait, last_exc,
            )
            time.sleep(wait)

        try:
            with _get_semaphore():
                response = client.models.generate_content(
                    model=s.LLM_MODEL_NAME,
                    contents=prompt,
                    config=config,
                )
        except Exception as exc:
            last_exc = exc
            if attempt < max_retries and _is_retryable(exc):
                continue
            raise

        # Extract only text parts to avoid SDK warnings about thought_signature
        # parts that thinking models include alongside the response.
        text = "".join(
            part.text
            for candidate in (response.candidates or [])
            for part in (candidate.content.parts or [])
            if hasattr(part, "text") and part.text
        )
        if not text:
            raise ValueError("LLM returned an empty response (possible content safety block)")
        return text

    # Unreachable — the loop always raises or returns — but satisfies type checkers.
    raise last_exc  # type: ignore[misc]


def stream_llm(prompt: str, system_prompt: str | None = None):
    """Yield text chunks from Gemini's streaming API.

    The generator holds one semaphore permit for the duration of the stream and
    releases it even if the caller abandons the iterator partway through. No
    hard wall-clock timeout is applied — the caller controls the lifetime.
    """
    s = _settings()
    client = _get_client()
    config = _build_config(s, system_prompt, apply_timeout=False)

    sem = _get_semaphore()
    sem.acquire()
    try:
        stream = client.models.generate_content_stream(
            model=s.LLM_MODEL_NAME,
            contents=prompt,
            config=config,
        )
        for chunk in stream:
            # Prefer the convenience .text attribute; fall back to candidate
            # iteration so this works with both regular and thinking models.
            text: str = ""
            if hasattr(chunk, "text") and chunk.text:
                text = chunk.text
            else:
                text = "".join(
                    part.text
                    for candidate in (chunk.candidates or [])
                    for part in (candidate.content.parts or [])
                    if hasattr(part, "text") and part.text
                )
            if text:
                yield text
    finally:
        sem.release()


def list_models() -> list[str]:
    """Return names of all Gemini models that support generateContent."""
    return [
        m.name
        for m in _get_client().models.list()
        if m.supported_actions and "generateContent" in m.supported_actions
    ]
