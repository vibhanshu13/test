"""Deterministic reasoning scaffold for backward variable lineage.

Extracts the *why* from a chunked-session tuple into an explicit StepReasoning
dict that the LLM receives instead of raw tuple JSON.  No LLM calls, no network.

Design: every piece of "why" lives in the tuple already — scope_label,
discovered_from, origin_chain, depth, relevant_code_lines[].role, setter_sites,
cross_file_calls_out, subroutine_summary.  This module makes it explicit.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple


_SRC_EXT_RE = re.compile(r"\.(?:cpp|cc|cxx|hpp|hh|hxx|c|h)$", re.IGNORECASE)


def _cpp_enc_fn_from_id(node_id: str) -> str:
    """Extract enclosing function name from a GVL node ID ('kind:fn::field' → 'fn').

    Mirrors _enc_fn_from_gvl_id in backward_only_runner without circular import.
    Rejects file-path scopes (file-level globals) so a source path is never
    returned as a function name.
    """
    if "::" not in node_id:
        return ""
    after_kind = node_id.split(":", 1)[-1] if ":" in node_id else node_id
    fn = after_kind.split("::")[0]
    if "/" in fn or "\\" in fn or _SRC_EXT_RE.search(fn):
        return ""
    return fn

# ---------------------------------------------------------------------------
# Role → plain label maps
# ---------------------------------------------------------------------------

_ROLE_PLAIN: Dict[str, str] = {
    "SETTER_STEP":           "writes the value",
    "CALL_SITE":             "is the setter instruction found here",
    "COMPARE":               "checks a condition",
    "COMPARE_IMMEDIATE":     "checks a condition (immediate value)",
    "COMPARE_REGISTERS":     "compares two register values",
    "COMPARE_HALFWORD":      "compares a halfword value",
    "COMPARE_LOGICAL":       "logical comparison",
    "COMPARE_PACKED":        "compares packed decimal values",
    "TEST_MASK":             "tests a flag bit",
    "TEST_REGISTER":         "tests if a register is zero",
    "CONDITION_CHECK":       "checks if a value is zero or blank",
    "BRANCH_EQUAL":          "branches when values are equal",
    "BRANCH_NOT_EQUAL":      "branches when values are not equal",
    "BRANCH_ZERO":           "branches when result is zero",
    "BRANCH_NOT_ZERO":       "branches when result is not zero",
    "BRANCH_PLUS":           "branches when result is positive",
    "BRANCH_NOT_PLUS":       "branches when result is not positive",
    "BRANCH_HIGH":           "branches when first operand is higher",
    "BRANCH_NOT_HIGH":       "branches when first operand is not higher",
    "BRANCH_MINUS":          "branches when result is negative",
    "BRANCH_NOT_MINUS":      "branches when result is not negative",
    "BRANCH_OVERFLOW":       "branches on overflow",
    "BRANCH_NO_OVERFLOW":    "branches when no overflow",
    "BRANCH_STEP":           "loop branch (decrements counter)",
    "BRANCH":                "unconditional branch",
    "SUBROUTINE_CALL":       "calls an internal subroutine",
    "CROSS_FILE_CALL":       "calls a routine in another file",
    "REGISTER_INDIRECT_MOVE":"indirect memory move via register (coverage gap)",
}

# Roles that are "conditions" (guard chain)
_CONDITION_ROLES = frozenset({
    "COMPARE", "COMPARE_IMMEDIATE", "COMPARE_REGISTERS", "COMPARE_HALFWORD",
    "COMPARE_LOGICAL", "COMPARE_PACKED", "TEST_MASK", "TEST_REGISTER",
    "CONDITION_CHECK",
})

# Roles that are "branch" outcomes
_BRANCH_ROLES = frozenset({
    "BRANCH_EQUAL", "BRANCH_NOT_EQUAL", "BRANCH_ZERO", "BRANCH_NOT_ZERO",
    "BRANCH_PLUS", "BRANCH_NOT_PLUS", "BRANCH_HIGH", "BRANCH_NOT_HIGH",
    "BRANCH_MINUS", "BRANCH_NOT_MINUS", "BRANCH_OVERFLOW", "BRANCH_NO_OVERFLOW",
    "BRANCH_STEP", "BRANCH",
})

# discovered_from values → plain prose
_DISCOVERED_FROM_PLAIN: Dict[str, str] = {
    "chain_upstream":               "it is part of the selected call chain",
    "root_var_scope":               "it was found in the backward-reachable scope of the root variable's setter",
    "dep_var_scope":                "it was found while tracing a dependent variable",
    "root_var_downstream_scope":    "it consumes or reads the root variable after it is set",
    "dep_var_downstream_scope":     "it consumes a dependent variable downstream",
}

# scope_label → plain prose
_SCOPE_PLAIN: Dict[str, str] = {
    "collection_based": "the specific blocks where this variable was collected (a narrow, precise scope)",
    "anchor_based":     "backward from the block where this variable is set (anchored at the setter site)",
    "full_file":        "the entire file — no narrower anchor was available, so the analysis was exhaustive",
}

# Valid identifier pattern (to strip noise from compare operands)
_IDENT_RE = re.compile(r"^[A-Z_@$#][A-Z0-9_@$#.]*$")

# ---------------------------------------------------------------------------
# Opcode → plain-English mechanical meaning (for business-user explanations).
# This is what the assembly instruction DOES at the machine level, phrased for
# someone who has never seen assembly.  Fed to the LLM so its prose is accurate
# and consistent.  Keep entries one sentence, no jargon beyond the unavoidable.
# ---------------------------------------------------------------------------
OPCODE_MEANING: Dict[str, str] = {
    # --- bit / logical operations on storage ---
    "OI":   "a logical OR with a constant that switches specific bits ON inside a byte, leaving the other bits untouched",
    "OIY":  "a logical OR with a constant that switches specific bits ON inside a byte (long-displacement form)",
    "NI":   "a logical AND with a constant that switches specific bits OFF (masks them out), leaving the others untouched",
    "NIY":  "a logical AND with a constant that switches specific bits OFF (long-displacement form)",
    "XI":   "a logical XOR with a constant that flips specific bits to their opposite state",
    "XIY":  "a logical XOR with a constant that flips specific bits (long-displacement form)",
    "OC":   "a logical OR of two storage fields; when both operands are the same field it is the classic idiom for testing whether that field is all zeros",
    "NC":   "a logical AND of two storage fields, bit by bit",
    "XC":   "a logical XOR of two storage fields; when both operands are the same field it clears that field to zeros",
    # --- moves / copies ---
    "MVC":  "a move of a block of bytes, copying the contents of one storage field into another",
    "MVCIN":"a move of bytes in reversed order from one field to another",
    "MVI":  "a move of a single constant byte into a storage field",
    "MVIY": "a move of a single constant byte into a storage field (long-displacement form)",
    "MVN":  "a move of the numeric (low) half of each byte from one field to another",
    "MVZ":  "a move of the zone (high) half of each byte from one field to another",
    "MVO":  "a move-with-offset that shifts a packed-decimal value as it copies it",
    # --- store from register to storage ---
    "ST":   "a store that saves a 4-byte register value into a storage field",
    "STH":  "a store that saves a 2-byte (halfword) value into a storage field",
    "STC":  "a store that saves a single byte into a storage field",
    "STM":  "a store of several registers at once into consecutive storage",
    "STCM": "a store of selected bytes of a register into storage under a mask",
    "STG":  "a store that saves an 8-byte (64-bit) register value into storage",
    "STY":  "a store that saves a 4-byte register value into storage (long-displacement form)",
    # --- packed-decimal arithmetic ---
    "ZAP":  "a 'zero and add packed' that clears a numeric field and sets it to a given value",
    "AP":   "an add of two packed-decimal numbers, leaving the sum in the first field",
    "SP":   "a subtract of one packed-decimal number from another",
    "MP":   "a multiply of two packed-decimal numbers",
    "DP":   "a divide of two packed-decimal numbers",
    "SRP":  "a shift-and-round of a packed-decimal number",
    "PACK": "a conversion of a human-readable (zoned) number into compact packed-decimal form",
    "PKA":  "a conversion of character data into packed-decimal form",
    "UNPK": "a conversion of a packed-decimal number back into human-readable (zoned) digits",
    "ED":   "an edit that formats a packed-decimal number into a printable layout with punctuation",
    "EDMK": "an edit-and-mark that formats a number for printing and marks the first significant digit",
    "CVD":  "a convert-to-decimal that turns a binary register value into a packed-decimal number in storage",
    # --- translate ---
    "TR":   "a translate that replaces each byte of a field using a lookup table",
    # --- comparisons (condition checks) ---
    "CLC":  "a compare of two storage fields, byte by byte",
    "CLI":  "a compare of a single byte in storage against a constant",
    "CLIY": "a compare of a single byte in storage against a constant (long-displacement form)",
    "CP":   "a compare of two packed-decimal numbers",
    "C":    "a compare of a register against a 4-byte value in storage",
    "CH":   "a compare of a register against a 2-byte (halfword) value",
    "CL":   "an unsigned compare of a register against a value in storage",
    "CR":   "a compare of two registers",
    "CLR":  "an unsigned compare of two registers",
    "CGR":  "a compare of two 64-bit registers",
    "TM":   "a test-under-mask that checks whether specific bits in a byte are on or off",
    "TMY":  "a test-under-mask that checks specific bits in a byte (long-displacement form)",
    "LTR":  "a load-and-test that checks whether a value is zero, negative, or positive",
    "LTGR": "a load-and-test of a 64-bit value (zero, negative, or positive)",
    # --- branches (control flow) ---
    "B":    "an unconditional jump to another part of the program",
    "BE":   "a jump taken only when the previous comparison was equal",
    "BNE":  "a jump taken only when the previous comparison was NOT equal",
    "BZ":   "a jump taken only when the previous result was zero",
    "BNZ":  "a jump taken only when the previous result was NOT zero",
    "BH":   "a jump taken only when the first compared value was higher",
    "BNH":  "a jump taken only when the first compared value was NOT higher",
    "BL":   "a jump taken only when the first compared value was lower",
    "BNL":  "a jump taken only when the first compared value was NOT lower",
    "BP":   "a jump taken only when the result was positive",
    "BNP":  "a jump taken only when the result was NOT positive",
    "BM":   "a jump taken only when the result was negative (minus)",
    "BNM":  "a jump taken only when the result was NOT negative",
    "BO":   "a jump taken only when an overflow / ones-condition occurred",
    "BNO":  "a jump taken only when no overflow occurred",
    "BCT":  "a loop control that decrements a counter and jumps back while it is not yet zero",
    "BCTR": "a loop control that decrements a counter in a register",
    # --- subroutine / cross-file calls ---
    "BAS":  "a call to an internal subroutine, remembering where to return afterwards",
    "BAL":  "a call to an internal subroutine, remembering the return point",
    "BASR": "a call to a subroutine whose address is held in a register",
    "BALR": "a call to a subroutine whose address is held in a register",
    "ENTRC":"a call into a routine in another program that returns control afterwards",
    "ENTNC":"a transfer of control into another program that does NOT return",
    "ENTDC":"a transfer of control into another program that does NOT return",
    "CALLC":"a typed call into a routine in another program (C-style), returning afterwards",
    "CREEC":"a call that creates and enters a new program entry",
    "EXSR": "a call to execute a named subroutine",
}


def opcode_meaning(inst: str) -> str:
    """Return the plain-English mechanical meaning of an assembly opcode, or ''."""
    return OPCODE_MEANING.get(str(inst or "").upper().strip(), "")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_step_reasoning(
    tuple_data: Dict[str, Any],
    root_variable: str,
    prior_facts: Optional[List[str]] = None,
    step_index: int = 0,
) -> Dict[str, Any]:
    """Extract deterministic reasoning from a single chunked-session tuple.

    Returns a StepReasoning dict with all the 'why' fields made explicit.
    All values are plain-English strings ready to be injected into an LLM prompt.
    Never raises; returns safe empty structures on missing data.
    """
    prior_facts = prior_facts or []

    stem      = tuple_data.get("file_stem") or tuple_data.get("file_type") or "?"
    variable  = tuple_data.get("variable") or root_variable
    phase     = tuple_data.get("phase") or "?"
    file_type = tuple_data.get("file_type") or "asm"
    pm        = tuple_data.get("phase_metadata") or {}
    nodes     = tuple_data.get("nodes") or []
    summary   = tuple_data.get("summary") or ""

    # ------------------------------------------------------------------
    # 1. Why we are examining this file at all
    # ------------------------------------------------------------------
    why_examined = _build_why_examined(
        stem=stem, phase=phase, variable=variable, root_variable=root_variable,
        pm=pm, tuple_data=tuple_data,
    )

    # ------------------------------------------------------------------
    # 2. Statements — all relevant lines with role + plain meaning
    # ------------------------------------------------------------------
    statements = _build_statements(nodes, pm, file_type)

    # ------------------------------------------------------------------
    # 3. Guard chain — conditions that must hold to reach the setter
    # ------------------------------------------------------------------
    conditions_to_reach_setter = _build_condition_chain(nodes, pm)

    # ------------------------------------------------------------------
    # 4. Dependent variables introduced in this step + why each matters
    # ------------------------------------------------------------------
    dependent_vars_introduced = _build_dep_vars(nodes, pm, root_variable, phase)

    # ------------------------------------------------------------------
    # 5. Cross-file calls this step follows (and why)
    # ------------------------------------------------------------------
    cross_file_follow = _build_cross_file_follow(tuple_data)

    # ------------------------------------------------------------------
    # 6. Setter detail
    # ------------------------------------------------------------------
    setter_detail = _build_setter_detail(pm)

    # ------------------------------------------------------------------
    # 7. Coverage note (honest gaps)
    # ------------------------------------------------------------------
    coverage_note = _build_coverage_note(pm, nodes)

    # ------------------------------------------------------------------
    # 8. Scope plain text
    # ------------------------------------------------------------------
    scope_label = pm.get("scope_label") or pm.get("scope") or "unknown"
    scope_plain = _SCOPE_PLAIN.get(scope_label, scope_label)

    # ------------------------------------------------------------------
    # 9. File-level role badge
    # ------------------------------------------------------------------
    phase_badge = _phase_badge(phase)

    return {
        "file_stem":                  stem,
        "file_type":                  file_type,
        "variable":                   variable,
        "root_variable":              root_variable,
        "phase":                      phase,
        "phase_badge":                phase_badge,
        "step_index":                 step_index,
        "summary":                    summary,
        "why_examined":               why_examined,
        "scope_label":                scope_label,
        "scope_plain":                scope_plain,
        "statements":                 statements,
        "conditions_to_reach_setter": conditions_to_reach_setter,
        "dependent_vars_introduced":  dependent_vars_introduced,
        "cross_file_follow":          cross_file_follow,
        "setter_detail":              setter_detail,
        "coverage_note":              coverage_note,
        "prior_facts_count":          len(prior_facts),
    }


def build_step_fact(reasoning: Dict[str, Any]) -> str:
    """One-line structured fact from a StepReasoning — used as 'story so far' context.

    Never calls the LLM.  Fast, deterministic.
    """
    stem    = reasoning.get("file_stem", "?")
    phase   = reasoning.get("phase", "?")
    var     = reasoning.get("variable", "")
    root    = reasoning.get("root_variable", "")
    badge   = reasoning.get("phase_badge", phase)
    setter  = reasoning.get("setter_detail") or {}
    conds   = reasoning.get("conditions_to_reach_setter") or []
    dep_vars = reasoning.get("dependent_vars_introduced") or []

    parts: List[str] = [f"{stem} [{badge}]"]

    if setter.get("instruction"):
        inst = setter["instruction"]
        line = setter.get("line", "?")
        parts.append(f"{inst} at line {line} sets {root}")

    if conds:
        cond_names = [c.get("variable_checked") or c.get("check", "") for c in conds[:3] if c.get("variable_checked") or c.get("check")]
        if cond_names:
            parts.append(f"guarded by: {', '.join(cond_names)}")

    if dep_vars and phase not in ("modifier",):
        dv_names = [d.get("name", "") for d in dep_vars[:3] if d.get("name")]
        if dv_names:
            parts.append(f"dep_vars: {', '.join(dv_names)}")

    if var and var != root:
        parts.append(f"(var alias: {var})")

    return " — ".join(parts)


def render_step_mermaid(
    all_reasoning: List[Dict[str, Any]],
    current_step: int,
    chain_files: Optional[List[str]] = None,
) -> str:
    """Emit a Mermaid flowchart snippet for the steps seen so far.

    The current step's node is highlighted with :::current styling.
    Only includes steps up to and including current_step.
    """
    if not all_reasoning:
        return "flowchart LR\n  (no steps yet)"

    seen = all_reasoning[: current_step + 1]

    lines: List[str] = ["flowchart LR", "  classDef current fill:#6366f1,color:#fff,stroke:#6366f1"]

    # Collect unique file nodes from steps seen so far
    file_nodes: Dict[str, str] = {}  # id → label
    edges_seen: List[Tuple[str, str, str]] = []

    # Add chain files as a backbone first (if provided)
    if chain_files:
        for i, f in enumerate(chain_files):
            nid = _mermaid_id(f)
            file_nodes[nid] = f
            if i > 0:
                prev = _mermaid_id(chain_files[i - 1])
                edges_seen.append((prev, nid, ""))

    for r in seen:
        stem = r.get("file_stem", "?")
        nid = _mermaid_id(stem)
        badge = r.get("phase_badge", r.get("phase", ""))
        var = r.get("variable", "")
        label = f"{stem}\\n[{badge}]"
        if var and var != r.get("root_variable", ""):
            label += f"\\n{var}"
        file_nodes[nid] = label

        # Cross-file calls from this step
        for cf in (r.get("cross_file_follow") or []):
            target = cf.get("target_file", "")
            if not target:
                continue
            tid = _mermaid_id(target)
            label_cf = cf.get("instruction", "")
            edges_seen.append((nid, tid, label_cf))
            file_nodes.setdefault(tid, target)

    # Emit node definitions
    current_file = all_reasoning[current_step].get("file_stem", "") if current_step < len(all_reasoning) else ""
    current_id = _mermaid_id(current_file)

    for nid, label in file_nodes.items():
        if nid == current_id:
            lines.append(f'  {nid}["{label}"]:::current')
        else:
            lines.append(f'  {nid}["{label}"]')

    # Emit edges (deduplicated)
    seen_edges: set = set()
    for src, tgt, lbl in edges_seen:
        key = (src, tgt)
        if key in seen_edges:
            continue
        seen_edges.add(key)
        if lbl:
            lines.append(f"  {src} -->|{lbl}| {tgt}")
        else:
            lines.append(f"  {src} --> {tgt}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _mermaid_id(name: str) -> str:
    """Sanitize a file stem to a valid Mermaid node ID."""
    return re.sub(r"[^A-Za-z0-9_]", "_", name)


def _phase_badge(phase: str) -> str:
    badges = {
        "modifier":             "SETTER FILE",
        "upstream":             "UPSTREAM CALLER",
        "root_var_downstream":  "DOWNSTREAM CONSUMER",
        "dep_var_chain":        "DEPENDENT VARIABLE",
        "dep_var_downstream":   "DEPENDENT (DOWNSTREAM)",
        "cpp_dep_var_extended": "C++ DEPENDENCY",
    }
    return badges.get(phase, phase.upper().replace("_", " "))


def _build_why_examined(
    stem: str,
    phase: str,
    variable: str,
    root_variable: str,
    pm: Dict[str, Any],
    tuple_data: Dict[str, Any],
) -> str:
    """Build plain-English 'why we are examining this file' prose."""
    scope_label = pm.get("scope_label") or pm.get("scope") or ""
    scope_plain = _SCOPE_PLAIN.get(scope_label, "")
    origin_chain = pm.get("origin_chain") or []
    depth = pm.get("depth")
    dep_var = pm.get("dep_var") or (variable if variable != root_variable else None)

    # full_flow_edges tells us discovered_from for cross-file edges leading here
    discovered_set: set = set()
    for edge in (tuple_data.get("full_flow_edges") or []):
        if edge.get("target") == stem:
            for df in (edge.get("discovered_from") or []):
                discovered_set.add(df)
    discovered_plain = [_DISCOVERED_FROM_PLAIN.get(df, df) for df in sorted(discovered_set)]

    if phase == "modifier":
        why = f"This is the modifier file — where `{root_variable}` is finally written. "
        why += f"The algorithm found the setter instruction here and traced backward to discover every condition that must hold for the setter to fire."
    elif phase == "upstream":
        alias_note = f" (referred to as `{variable}` in this file)" if variable != root_variable else ""
        why = f"This file is an upstream caller in the chain that eventually reaches the `{root_variable}` setter{alias_note}. "
        if discovered_plain:
            why += f"It was reached because {'; and '.join(discovered_plain)}. "
        why += "The analysis traced backward here to find the business logic that decides whether the setter will be reached."
    elif phase == "root_var_downstream":
        why = f"This file is a downstream consumer — it reads or acts on `{root_variable}` after it has been set. "
        why += "The analysis followed it to understand the downstream impact of the setter."
    elif phase in ("dep_var_chain", "dep_var_downstream", "cpp_dep_var_extended"):
        dv = dep_var or variable
        why = f"`{dv}` is a dependent variable that gates the setter of `{root_variable}` — its value must be correctly established before `{root_variable}` can be set. "
        if origin_chain:
            origin_str = " → ".join(origin_chain)
            why += f"It was first discovered via the chain `{origin_str}`. "
        if depth is not None:
            why += f"This is dependency level {depth} (0 = directly gates the root setter, higher = indirect gate). "
        if discovered_plain:
            why += f"This file was examined because {'; and '.join(discovered_plain)}. "
    else:
        why = f"Phase: {phase}."
        if discovered_plain:
            why += f" Reached because {'; and '.join(discovered_plain)}."

    if scope_plain:
        why += f"\n\nScope of the search within this file: {scope_plain}."

    return why.strip()


def _build_statements(
    nodes: List[Dict[str, Any]],
    pm: Dict[str, Any],
    file_type: str,
) -> List[Dict[str, Any]]:
    """Collect all relevant_code_lines across all nodes into statements list."""
    seen_lines: set = set()
    statements: List[Dict[str, Any]] = []

    # Setter sites first (most important — carry raw_line)
    for site in (pm.get("setter_sites") or []):
        line = site.get("line") or 0
        if line in seen_lines:
            continue
        seen_lines.add(line)
        raw = (site.get("raw_line") or "").strip()
        inst = site.get("instruction") or ""
        call_type = site.get("call_type") or "setter_site"
        role_plain = "writes the value"
        if call_type == "implicit_setter":
            role_plain = "implicitly writes the value (side-effect instruction)"
        flipc = site.get("flipc_alias_of")
        if flipc:
            role_plain += f" (via FLIPC alias of {flipc})"
        statements.append({
            "line":        line,
            "raw_statement": raw or f"{inst} (setter site at line {line})",
            "role":        "SETTER_STEP",
            "role_plain":  role_plain,
            "opcode":      inst,
            "opcode_meaning": opcode_meaning(inst),
            "routine":     site.get("routine") or "",
            "is_setter":   True,
        })

    # Then relevant_code_lines from all nodes
    for node in nodes:
        for rcl in (node.get("relevant_code_lines") or []):
            line = rcl.get("line") or 0
            if line in seen_lines:
                continue
            seen_lines.add(line)
            role = rcl.get("role") or ""
            inst = rcl.get("inst") or ""
            detail = rcl.get("detail") or ""
            role_plain = _ROLE_PLAIN.get(role, role.replace("_", " ").lower())
            statements.append({
                "line":          line,
                "raw_statement": f"{inst}  {detail}".strip() if detail else inst,
                "role":          role,
                "role_plain":    role_plain,
                "opcode":        inst,
                "opcode_meaning": opcode_meaning(inst),
                "routine":       node.get("id") or "",
                "is_setter":     role in ("SETTER_STEP", "CALL_SITE"),
            })

    # C++ call_sites from phase_metadata (no relevant_code_lines on C++ nodes)
    if file_type == "cpp":
        for cs in (pm.get("call_sites") or []):
            line = cs.get("line") or 0
            if line in seen_lines:
                continue
            seen_lines.add(line)
            inst = cs.get("instruction") or ""
            tgt = cs.get("target_entry_point") or ""
            fn = cs.get("function") or ""
            statements.append({
                "line":          line,
                "raw_statement": f"{inst} → {tgt}" if tgt else f"{fn}() call at line {line}",
                "role":          "CROSS_FILE_CALL",
                "role_plain":    "calls a routine in another file",
                "routine":       fn,
                "is_setter":     False,
            })
        for cp in (pm.get("call_pairs") or []):
            line = cp.get("line") or 0
            if line in seen_lines:
                continue
            seen_lines.add(line)
            caller = cp.get("caller_function") or ""
            callee = cp.get("callee_function") or ""
            inst = cp.get("instruction") or ""
            statements.append({
                "line":          line,
                "raw_statement": f"{inst}  {caller}() → {callee}()",
                "role":          "CROSS_FILE_CALL",
                "role_plain":    "calls another function",
                "routine":       caller,
                "is_setter":     False,
            })

        # C++ GVL assignment edges: surface actual source-code expressions.
        # Each edge with relation=assign/define/arg_bind carries the original C++
        # statement in its `expression` field — this is the closest equivalent to
        # ASM relevant_code_lines for C++ files.
        #
        # This is a FALLBACK only for nodes that carry no relevant_code_lines
        # (e.g. the C++ upstream-caller case, whose call_graph nodes are plain
        # function stubs).  When the nodes are enriched cg_nodes (modifier /
        # chain dep_var, built by _build_cpp_cg_nodes) the generic
        # relevant_code_lines loop above already emitted these statements, so
        # running this block too would double-list every setter.
        _nodes_have_rcl = any((n.get("relevant_code_lines") for n in nodes))
        # Use a SEPARATE seen_lines set so C++ edge lines don't collide with ASM
        # rcl line numbers that may happen to share the same integer value.
        _seen_stmt_keys: set = set()
        _seen_lines_cpp: set = set()
        for _trace_key in (() if _nodes_have_rcl else ("cpp_lineage_trace", "lineage_trace")):
            _cpp_lt = pm.get(_trace_key) or {}
            for _edge in (_cpp_lt.get("edges") or []):
                _relation = str(_edge.get("relation") or "").lower()
                if _relation not in ("assign", "define", "arg_bind"):
                    continue
                _expr = str(_edge.get("expression") or "").strip()
                _line = _edge.get("line") or 0
                if not _expr or not _line:
                    continue
                # Deduplicate by (line, first 100 chars of expression)
                _stmt_key = (_line, _expr[:100])
                if _stmt_key in _seen_stmt_keys:
                    continue
                _seen_stmt_keys.add(_stmt_key)
                if _line in _seen_lines_cpp:
                    continue
                _seen_lines_cpp.add(_line)
                _fn = _cpp_enc_fn_from_id(str(_edge.get("target") or ""))
                _role = "SETTER_STEP" if _relation in ("assign", "define") else "CALL_SITE"
                _role_plain = (
                    "assigns a value to the field" if _relation == "assign" else
                    "defines the variable" if _relation == "define" else
                    "passes the value as a function argument"
                )
                statements.append({
                    "line":           _line,
                    "raw_statement":  _expr.replace("\n", " "),
                    "role":           _role,
                    "role_plain":     _role_plain,
                    "opcode":         _relation.upper(),
                    "opcode_meaning": f"C++ {_role_plain}",
                    "routine":        _fn,
                    "is_setter":      _role == "SETTER_STEP",
                })

    statements.sort(key=lambda s: s.get("line") or 0)
    return statements


def _build_condition_chain(
    nodes: List[Dict[str, Any]],
    pm: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Build the ordered guard chain — pairs of (condition check, branch outcome).

    Each entry explains a check that must pass for the algorithm to reach the setter.
    """
    # Collect all rcl lines ordered by (node_id, line)
    all_rcl: List[Dict[str, Any]] = []
    for node in nodes:
        for rcl in (node.get("relevant_code_lines") or []):
            all_rcl.append({**rcl, "_node_id": node.get("id", "")})

    all_rcl.sort(key=lambda r: r.get("line") or 0)

    conditions: List[Dict[str, Any]] = []
    i = 0
    while i < len(all_rcl):
        rcl = all_rcl[i]
        role = rcl.get("role") or ""

        if role in _CONDITION_ROLES:
            detail = rcl.get("detail") or ""
            inst = rcl.get("inst") or ""
            line = rcl.get("line") or 0

            # Extract variable(s) being checked
            vars_checked = _extract_idents_from_detail(detail)

            # Look for the following BRANCH role
            branch_role = ""
            branch_inst = ""
            branch_target = ""
            branch_line = 0
            j = i + 1
            while j < len(all_rcl) and j <= i + 3:
                next_rcl = all_rcl[j]
                if (next_rcl.get("role") or "") in _BRANCH_ROLES:
                    branch_role = next_rcl.get("role") or ""
                    branch_inst = next_rcl.get("inst") or ""
                    branch_target = (next_rcl.get("detail") or "").split(",")[0].strip()
                    branch_line = next_rcl.get("line") or 0
                    break
                j += 1

            branch_plain = _ROLE_PLAIN.get(branch_role, branch_role.replace("_", " ").lower())

            # Human-readable check description
            check_plain = _condition_check_plain(inst, detail, vars_checked)
            decides_plain = ""
            if branch_inst:
                decides_plain = branch_plain
                if branch_target:
                    decides_plain += f" (jumps to {branch_target})"

            conditions.append({
                "check":            f"{inst}  {detail}".strip(),
                "line":             line,
                "opcode":           inst,
                "opcode_meaning":   opcode_meaning(inst),
                "branch_opcode_meaning": opcode_meaning(branch_inst) if branch_inst else "",
                "in_plain_terms":   check_plain,
                "decides":          decides_plain,
                "variable_checked": vars_checked[0] if vars_checked else "",
                "all_vars_checked": vars_checked,
                "branch_role":      branch_role,
                "branch_target":    branch_target,
                "routine":          rcl.get("_node_id", ""),
            })

        i += 1

    return conditions


def _condition_check_plain(inst: str, detail: str, vars_checked: List[str]) -> str:
    """Build a plain-language description of a condition check."""
    operands = [o.strip() for o in detail.split(",")]
    left = operands[0] if operands else ""
    right = operands[1] if len(operands) > 1 else ""

    inst_upper = inst.upper()

    if inst_upper in ("CLC", "CLG", "CL"):
        return f"Compare `{left}` with `{right}` (logical character comparison)"
    elif inst_upper in ("CLI", "CLFI", "CLGFI"):
        return f"Compare `{left}` with immediate value `{right}`"
    elif inst_upper in ("CR", "CLR", "CGR", "CLGR"):
        return f"Compare register `{left}` with register `{right}`"
    elif inst_upper in ("CP",):
        return f"Compare packed decimal `{left}` with `{right}`"
    elif inst_upper in ("TM",):
        return f"Test bit mask on `{left}` for flag `{right}`"
    elif inst_upper in ("LTR", "LTGR"):
        return f"Test register `{left}` — is it zero?"
    elif inst_upper in ("OC",):
        return f"Logical OR `{left}` against itself — check if all bits are zero (is blank?)"
    elif inst_upper in ("CH", "CG", "CGF"):
        return f"Compare `{left}` with halfword value `{right}`"
    else:
        return f"{inst} — checks `{', '.join(vars_checked)}`" if vars_checked else f"{inst} check"


def _extract_idents_from_detail(detail: str) -> List[str]:
    """Extract variable-like identifiers from an instruction detail string."""
    results: List[str] = []
    for token in re.split(r"[,\s()+\-]+", detail.upper()):
        token = token.strip("'\"").strip()
        if token and _IDENT_RE.match(token) and not _is_noise_token(token):
            if token not in results:
                results.append(token)
    return results


def _is_noise_token(token: str) -> bool:
    """Return True for tokens that are not variable names (registers, literals, etc.)."""
    noise = frozenset({
        "R0","R1","R2","R3","R4","R5","R6","R7","R8","R9",
        "R10","R11","R12","R13","R14","R15",
        "ZEROS","BLANKS","CHARF","SPACES","ZERO","BLANK",
        "HIGH_VALUES","LOW_VALUES","NULLS","MINUS1","MINUS2",
        # C++ control-flow keywords leaking from condition detail text
        # (e.g. "if(linkSourceArea != 0)") — never variable names.
        "IF","ELSE","WHILE","FOR","SWITCH","CASE","RETURN","DO",
    })
    if token in noise:
        return True
    if token.startswith("=") or token.startswith("X'") or token.startswith("C'") or token.startswith("P'"):
        return True
    if re.match(r"^[0-9]+$", token):
        return True
    if re.match(r"^=", token):
        return True
    return False


def _build_dep_vars(
    nodes: List[Dict[str, Any]],
    pm: Dict[str, Any],
    root_variable: str,
    phase: str,
) -> List[Dict[str, Any]]:
    """Collect dependent variables introduced in this step with why-they-matter."""
    # Gather from node.dependent_variables
    seen: set = set()
    dep_vars: List[Dict[str, Any]] = []

    # Build a map: dep_var_name → list of routines/contexts it appears in
    var_contexts: Dict[str, List[str]] = {}
    for node in nodes:
        node_id = node.get("id") or ""
        for dv in (node.get("dependent_variables") or []):
            dv_upper = str(dv).upper().strip()
            if dv_upper and dv_upper not in seen:
                seen.add(dv_upper)
                var_contexts.setdefault(dv_upper, []).append(node_id)
            elif dv_upper:
                var_contexts.setdefault(dv_upper, []).append(node_id)

    # Build a map of dep_var → which conditions check it (for why_it_matters)
    # This is derived from relevant_code_lines across nodes
    var_to_conditions: Dict[str, List[str]] = {}
    for node in nodes:
        for rcl in (node.get("relevant_code_lines") or []):
            role = rcl.get("role") or ""
            if role in _CONDITION_ROLES:
                detail = rcl.get("detail") or ""
                inst = rcl.get("inst") or ""
                idents = _extract_idents_from_detail(detail)
                for ident in idents:
                    if ident in seen:  # only dep vars
                        entry = f"{inst} at line {rcl.get('line','?')}"
                        var_to_conditions.setdefault(ident, []).append(entry)

    # Also get the "explicit dep_var" from phase_metadata (Pass 2B tuple)
    explicit_dv = pm.get("dep_var")
    if explicit_dv:
        dv_upper = str(explicit_dv).upper().strip()
        if dv_upper and dv_upper not in seen:
            seen.add(dv_upper)
            var_contexts[dv_upper] = []

    # For C++ steps, dep_vars come from the GVL backward trace, not node.dependent_variables.
    # Read them from cpp_lineage_trace (upstream/modifier) or lineage_trace (dep_var steps).
    for _trace_key in ("cpp_lineage_trace", "lineage_trace"):
        _cpp_lt = pm.get(_trace_key) or {}
        for _dv in (_cpp_lt.get("dep_vars") or []):
            _dv_str = str(_dv or "").strip()
            if not _dv_str or _dv_str.startswith("bridge_back_to_asm:"):
                continue
            _dv_up = _dv_str.upper()
            # Filter C++ infrastructure noise: return@func, alloc@D7, LEVEL:*, MEMORY:*
            # (interior @ = C++ name@address separator, not a valid HLASM name prefix)
            if (len(_dv_up) > 1 and "@" in _dv_up[1:]) or _dv_up.startswith(("LEVEL:", "MEMORY:")):
                continue
            if _dv_up and _dv_up not in seen:
                seen.add(_dv_up)
                var_contexts[_dv_up] = []

    for dv_name in sorted(seen):
        if dv_name == root_variable.upper():
            continue  # never list the root as its own dep_var

        ctxs = var_contexts.get(dv_name) or []
        conds = var_to_conditions.get(dv_name) or []

        if phase in ("dep_var_chain", "dep_var_downstream", "cpp_dep_var_extended"):
            why = f"This is the variable being traced in this step — its setter is being located."
        elif conds:
            why = f"Appears in condition check(s) that gate the setter: {'; '.join(conds[:2])}."
        elif ctxs:
            why = f"Found in routine(s) {', '.join(ctxs[:2])} — its value influences the code path to the setter."
        else:
            why = "Collected from the backward trace — its value influences the path to the setter."

        dep_vars.append({
            "name":             dv_name,
            "why_it_was_traced": why,
            "appears_in":        ctxs[:3],
            "checked_by":        conds[:3],
        })

    return dep_vars


def _build_cross_file_follow(tuple_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Build cross-file call records with plain-language reasoning."""
    result: List[Dict[str, Any]] = []
    seen_targets: set = set()

    # From cross_file_calls_out
    for cf in (tuple_data.get("cross_file_calls_out") or []):
        target = cf.get("target_file") or ""
        if not target or target in seen_targets:
            continue
        seen_targets.add(target)

        inst = cf.get("instruction") or ""
        call_type = cf.get("call_type") or ""
        line = cf.get("line") or 0
        src_block = cf.get("source_block") or ""

        call_type_plain = _call_type_plain(call_type, inst)

        # discovered_from from full_flow_edges matching this (source→target)
        stem = tuple_data.get("file_stem") or ""
        discovered_set: set = set()
        for edge in (tuple_data.get("full_flow_edges") or []):
            if edge.get("source") == stem and edge.get("target") == target:
                for df in (edge.get("discovered_from") or []):
                    discovered_set.add(df)
        discovered_plain = [_DISCOVERED_FROM_PLAIN.get(df, df) for df in sorted(discovered_set)]

        result.append({
            "target_file":        target,
            "instruction":        inst,
            "call_type":          call_type,
            "call_type_plain":    call_type_plain,
            "line":               line,
            "source_block":       src_block,
            "discovered_from":    list(discovered_set),
            "discovered_from_plain": discovered_plain,
        })

    # Supplement from full_flow_edges for targets not in cross_file_calls_out
    stem = tuple_data.get("file_stem") or ""
    for edge in (tuple_data.get("full_flow_edges") or []):
        if edge.get("source") != stem:
            continue
        target = edge.get("target") or ""
        if not target or target in seen_targets:
            continue
        seen_targets.add(target)
        instructions = edge.get("instructions") or []
        inst = instructions[0] if instructions else ""
        discovered_set = set(edge.get("discovered_from") or [])
        discovered_plain = [_DISCOVERED_FROM_PLAIN.get(df, df) for df in sorted(discovered_set)]
        result.append({
            "target_file":           target,
            "instruction":           inst,
            "call_type":             "cross_file_call",
            "call_type_plain":       _call_type_plain("", inst),
            "line":                  (edge.get("lines") or [0])[0],
            "source_block":          (edge.get("source_blocks") or [""])[0],
            "discovered_from":       list(discovered_set),
            "discovered_from_plain": discovered_plain,
        })

    return result


def _call_type_plain(call_type: str, inst: str) -> str:
    mapping = {
        "subroutine_call":   "calls and returns (subroutine)",
        "non_return_call":   "transfers control without returning (non-returning call)",
        "cross_file_call":   "cross-file call",
    }
    if call_type in mapping:
        return mapping[call_type]
    inst_upper = inst.upper()
    if inst_upper in ("ENTRC", "CALLC"):
        return "enters a C-linked subroutine and returns"
    if inst_upper in ("ENTNC", "ENTDC"):
        return "enters a non-returning transfer (may contain setter logic)"
    if inst_upper in ("BAS", "BAL"):
        return "branch-and-save (subroutine call within the file)"
    if inst_upper in ("BALR",):
        return "register-indirect branch-and-link (dynamic subroutine target)"
    return "calls another file or routine"


def _build_setter_detail(pm: Dict[str, Any]) -> Dict[str, Any]:
    sites = pm.get("setter_sites") or []
    if sites:
        # ASM path: exact instruction, raw_line, opcode meaning
        s = sites[0]
        flipc = s.get("flipc_alias_of")
        inst = s.get("instruction") or ""
        return {
            "instruction":    inst,
            "opcode_meaning": opcode_meaning(inst),
            "line":           s.get("line") or 0,
            "routine":        s.get("routine") or "",
            "call_type":      s.get("call_type") or "setter_site",
            "raw_line":       (s.get("raw_line") or "").strip(),
            "implicit_via":   s.get("implicit_instruction") or "",
            "flipc_alias_of": flipc or "",
            "all_sites":      len(sites),
        }

    # C++ path: derive from the first assign/define edge in the GVL trace.
    # setter_sites is always [] for C++ files; the equivalent setter info lives
    # in the GVL backward trace edges (relation="assign" or "define").
    for _trace_key in ("cpp_lineage_trace", "lineage_trace"):
        _lt = pm.get(_trace_key) or {}
        _assign_edges = [
            e for e in (_lt.get("edges") or [])
            if str(e.get("relation") or "").lower() in ("assign", "define")
            and (e.get("line") or 0)
            and str(e.get("expression") or "").strip()
        ]
        if not _assign_edges:
            continue
        e = _assign_edges[0]
        rel  = str(e.get("relation") or "").lower()
        expr = str(e.get("expression") or "").strip().replace("\n", " ")
        line = e.get("line") or 0
        fn   = _cpp_enc_fn_from_id(str(e.get("target") or ""))
        return {
            "instruction":    rel.upper(),
            "opcode_meaning": f"C++ {rel}s a value to the field",
            "line":           line,
            "routine":        fn,
            "call_type":      "setter_site",
            "raw_line":       expr,
            "implicit_via":   "",
            "flipc_alias_of": "",
            "all_sites":      len(_assign_edges),
        }

    return {}


def _build_coverage_note(pm: Dict[str, Any], nodes: List[Dict[str, Any]]) -> str:
    notes: List[str] = []
    sub = pm.get("subroutine_summary") or {}
    if sub.get("capped"):
        notes.append(
            f"Search was capped at {sub['capped']} subroutine node(s) — "
            "some paths through subroutines may not have been explored fully."
        )
    if sub.get("unresolved"):
        notes.append(
            f"{sub['unresolved']} subroutine target(s) could not be resolved "
            "and were skipped."
        )
    for node in nodes:
        for rcl in (node.get("relevant_code_lines") or []):
            if (rcl.get("role") or "") == "REGISTER_INDIRECT_MOVE":
                inst = rcl.get("inst") or ""
                notes.append(
                    f"Register-indirect move ({inst} at line {rcl.get('line','?')}) — "
                    "destination determined at runtime; analysis could not follow this path."
                )
                break

    for w in (pm.get("warnings") or [])[:3]:
        if "capped" in str(w).lower() or "unresolved" in str(w).lower():
            notes.append(str(w))

    return " ".join(notes) if notes else ""


# ---------------------------------------------------------------------------
# Variable-level graph delta (variables as nodes, dep-var relationships as edges)
# ---------------------------------------------------------------------------

def _build_variable_graph_delta(
    all_reasonings: List[Dict[str, Any]],
    current_step: int,
    root_variable: str,
) -> Dict[str, Any]:
    """Build a growing variable-dependency graph from reasoning steps.

    Each node is a variable name.  Each edge is a dependency relationship:
    source → target means 'source's setter is influenced by target'.
    Edge labels carry the plain-language condition that connects them.
    """
    nodes: Dict[str, Dict[str, Any]] = {}
    edges: Dict[Tuple[str, str], Dict[str, Any]] = {}

    root_up = str(root_variable or "").upper()

    def _ensure_node(vid: str, **attrs: Any) -> Dict[str, Any]:
        n = nodes.get(vid)
        if n is None:
            n = {"id": vid, "label": vid, "badge": "", "kind": "guard", "has_setter": False}
            nodes[vid] = n
        # Only upgrade fields that are provided and "stronger"
        for k, v in attrs.items():
            if v not in (None, "", False) or k not in n:
                n[k] = v
        return n

    def _ensure_edge(src: str, tgt: str, label: str, cond: str, has_setter: bool) -> None:
        if not src or not tgt or src == tgt:
            return
        key = (src, tgt)
        if key not in edges:
            edges[key] = {"source": src, "target": tgt, "label": label,
                          "conditionHuman": cond, "has_setter": has_setter}

    # Root node
    if root_up:
        _ensure_node(root_up, badge="ROOT", kind="root", is_root=True)

    for i, r in enumerate(all_reasonings[: current_step + 1]):
        if not isinstance(r, dict):
            continue

        phase      = r.get("phase", "")
        variable   = str(r.get("variable") or "").upper().strip()
        setter     = r.get("setter_detail") or {}
        conditions = r.get("conditions_to_reach_setter") or []
        dep_vars_intro = r.get("dependent_vars_introduced") or []

        # condition text lookup: var → first plain-English condition mentioning it
        cond_by_var: Dict[str, str] = {}
        for c in conditions:
            for checked in (c.get("all_vars_checked") or []):
                up = str(checked).upper()
                if up and up not in cond_by_var:
                    cond_by_var[up] = c.get("in_plain_terms", "")[:70]

        # Determine the OWNING variable for this step's dependency edges:
        #   - dep_var_chain step: the dep_var being traced owns its own dependents
        #   - modifier/upstream step: the ROOT variable owns the dependents found here
        if phase in ("dep_var_chain", "dep_var_downstream", "cpp_dep_var_extended"):
            owner = variable or root_up
            has_setter = bool(setter.get("instruction"))
            # Upgrade/define the dep_var node with its setter info
            _ensure_node(
                owner,
                badge=("DEP VAR" if has_setter else "LEAF"),
                kind=("dep_var" if has_setter else "leaf"),
                has_setter=has_setter,
                setter_inst=setter.get("instruction", ""),
                setter_line=setter.get("line", 0),
                setter_raw=(setter.get("raw_line") or "").strip(),
            )
            # Link root → this dep_var (it was discovered while tracing the root)
            inst = setter.get("instruction", "")
            _ensure_edge(
                root_up, owner,
                label=(f"setter: {inst}" if inst else "dependency"),
                cond=cond_by_var.get(owner, ""),
                has_setter=bool(inst),
            )
        else:
            owner = root_up

        # Attach every dependent introduced in this step to the OWNER
        for dv in dep_vars_intro:
            dv_name = str(dv.get("name") or "").upper()
            if not dv_name or dv_name == owner:
                continue
            _ensure_node(dv_name)  # defaults to guard; upgraded later if traced
            _ensure_edge(
                owner, dv_name,
                label="depends on",
                cond=cond_by_var.get(dv_name, "influences the value"),
                has_setter=False,
            )

    # Mark the current-step variable
    current_r = all_reasonings[current_step] if current_step < len(all_reasonings) else {}
    current_var = str(current_r.get("variable") or "").upper()
    if current_var in nodes and current_var != root_up:
        nodes[current_var]["kind"] = "current"

    return {
        "nodes":       list(nodes.values()),
        "edges":       list(edges.values()),
        "current_var": current_var,
        "root_var":    root_up,
    }
