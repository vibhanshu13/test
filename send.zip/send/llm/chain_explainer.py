"""Generate and cache business-level summaries for call chains."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import msgpack

from llm.caller import call_llm

CHAIN_SUMMARY_CACHE_VERSION = 1

_SYSTEM_PROMPT = (
    "You are explaining a software execution path to a business stakeholder. "
    "Use plain English. Tell the story from the entry point to the point where "
    "the tracked variable is modified. Describe what business event triggers this "
    "flow and what business outcome the modification achieves. "
    "Each hop between files has zero or more guard conditions that must hold for "
    "the call to fire — translate EACH condition (every one, do not gloss them as "
    "'a few checks') into plain business language and weave it into the narrative so "
    "the reader understands when one file invokes the next. Name each file by its "
    "specific business purpose, never vaguely 'processes some data'. "
    "3 to 5 sentences. No technical jargon, no register names, no instruction codes."
)

_GENERIC_SYSTEM_PROMPT = (
    "You are explaining a software execution path to a business stakeholder. "
    "Use plain English and business language. Explain what business scenario this call "
    "chain represents from entry to outcome. "
    "Each hop between files has zero or more guard conditions that must hold for "
    "the call to fire — translate EACH condition (every one, do not gloss them as "
    "'a few checks') into plain business language and weave it into the narrative so "
    "the reader understands when one file invokes the next. Do not invent guards for "
    "hops listed as unconditional. "
    "Keep it to 3 to 5 sentences. "
    "Some files may be external modules with no parser summary; mention those only as "
    "external dependencies and do not invent internal behavior for them. "
    "No technical jargon, register names, or instruction codes."
)


def _render_hop_conditions_block(
    hops: List[Dict[str, Any]],
    hop_conditions: Optional[Dict[Tuple[str, str], List[Dict[str, Any]]]],
) -> str:
    """Render the per-hop conditions section, in chain order. Returns "" if
    hop_conditions is None (caller chose not to provide it)."""
    if not hop_conditions or not hops:
        return ""
    lines: List[str] = ["Conditions under which each file calls the next:"]
    for hop in hops:
        frm = hop.get("from", "?")
        to = hop.get("to", "?")
        lines.append(f"- {frm} -> {to}:")
        sites = hop_conditions.get((frm, to)) or []
        if not sites:
            lines.append("    (no call sites located between these files)")
            continue
        for site in sites:
            call_line = site.get("call_line", "?")
            inst = site.get("call_instruction") or ""
            conds = site.get("conditions") or []
            inst_label = f" {inst}" if inst else ""
            if not conds:
                lines.append(f"    site at line {call_line}{inst_label}: unconditional")
                continue
            lines.append(f"    site at line {call_line}{inst_label}:")
            for c in conds:
                cond_text = c.get("condition", "")
                lines.append(f"      - {cond_text}")
    return "\n".join(lines)


def _legacy_chain_cache_path(kb_id: str) -> Path:
    from api.config import settings
    return settings.JOBS_BASE_DIR / kb_id / "output" / "chain_explanations.msgpack"


def chain_summaries_cache_path(kb_id: str) -> Path:
    from api.config import settings
    return settings.JOBS_BASE_DIR / kb_id / "output" / "chain_summaries.msgpack"


def chain_files_key(files: list[str]) -> str:
    raw = ":".join(files or [])
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Path cards: one business name + one whole-path description per chain.
# Cached on disk keyed by chain_files_key so repeat loads are instant.
# ---------------------------------------------------------------------------

_PATH_CARD_SYSTEM_PROMPT = (
    "You name and describe an entire software execution PATH (a chain of files "
    "that call one another) for a business stakeholder. You are given the files "
    "in the path, in order, with each file's business purpose. Produce ONE name "
    "and descriptions for the PATH AS A WHOLE — not for any single file.\n\n"
    "Return ONLY a JSON object, no markdown, with exactly these keys:\n"
    '  "business_name": a short business title for the whole path, 3 to 7 words, '
    "Title Case, naming the end-to-end business activity (e.g. \"Credit Card "
    'Authorization Flow"). No file names, no codes.\n'
    '  "description": ONE short plain-English sentence (max ~25 words) capturing '
    "what the whole path does end to end — the business event that starts it and "
    "the outcome at the end. This is a list-card subtitle; be concise.\n"
    '  "detailed_description": a fuller plain-English explanation, 3 to 5 '
    "sentences, describing the whole path as a single journey — the business "
    "event that triggers it, what happens as control moves from the entry point "
    "through the chain to the final file, the key decisions or checks along the "
    "way, and the business outcome at the end. Do not list files one by one. "
    "No technical jargon, register names, or instruction codes."
)


def path_cards_cache_path(kb_id: str) -> Path:
    # v3: adds detailed_description alongside the short description.
    from api.config import settings
    return settings.JOBS_BASE_DIR / kb_id / "output" / "path_cards_v3.msgpack"


def _db_get_path_card(kb_id: str, chain_key: str) -> Any:
    """Read a path card from users.db (survives job directory deletion)."""
    try:
        import json as _json
        from api.db import SessionLocal
        from api.models.knowledge_base import FileSummary
        db = SessionLocal()
        try:
            row = db.query(FileSummary).filter(
                FileSummary.kb_id == kb_id,
                FileSummary.file_path == f"path_card:{chain_key}",
            ).first()
            if row and row.summary:
                return _json.loads(row.summary)
        finally:
            db.close()
    except Exception:
        pass
    return None


def _db_save_path_card(kb_id: str, chain_key: str, card: dict) -> None:
    """Persist a path card to users.db."""
    try:
        import json as _json
        from api.db import SessionLocal
        from api.models.knowledge_base import FileSummary
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        db = SessionLocal()
        try:
            fp = f"path_card:{chain_key}"
            row = db.query(FileSummary).filter(
                FileSummary.kb_id == kb_id,
                FileSummary.file_path == fp,
            ).first()
            serialized = _json.dumps(card)
            if row:
                row.summary = serialized
                row.kb_updated_at = now
            else:
                db.add(FileSummary(
                    kb_id=kb_id,
                    file_path=fp,
                    summary=serialized,
                    kb_updated_at=now,
                    created_at=now,
                ))
            db.commit()
        finally:
            db.close()
    except Exception:
        pass


def load_path_cards_cache(kb_id: str) -> dict[str, Any]:
    """Load the {chain_key: {business_name, description}} card cache for kb_id.

    Reads from msgpack file first; if missing, rebuilds from users.db.
    """
    p = path_cards_cache_path(kb_id)
    if p.exists():
        try:
            data = msgpack.unpackb(p.read_bytes(), raw=False)
            if isinstance(data, dict) and data:
                return data
        except Exception:
            pass
    # Msgpack missing or empty — rebuild from users.db
    try:
        import json as _json
        from api.db import SessionLocal
        from api.models.knowledge_base import FileSummary
        db = SessionLocal()
        try:
            rows = db.query(FileSummary).filter(
                FileSummary.kb_id == kb_id,
                FileSummary.file_path.like("path_card:%"),
            ).all()
            cache = {}
            for row in rows:
                key = row.file_path[len("path_card:"):]
                try:
                    cache[key] = _json.loads(row.summary)
                except Exception:
                    pass
            if cache:
                # Restore the msgpack for fast future loads
                try:
                    p.parent.mkdir(parents=True, exist_ok=True)
                    p.write_bytes(msgpack.packb(cache, use_bin_type=True))
                except Exception:
                    pass
            return cache
        finally:
            db.close()
    except Exception:
        return {}


def save_path_cards_cache(kb_id: str, cache: dict[str, Any]) -> None:
    """Save path cards to msgpack on disk and persist any new cards to users.db."""
    p = path_cards_cache_path(kb_id)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(msgpack.packb(cache, use_bin_type=True))
    except Exception:
        pass
    # Also persist each card to users.db for durability
    for chain_key, card in cache.items():
        if isinstance(card, dict) and card.get("business_name"):
            _db_save_path_card(kb_id, chain_key, card)


def _build_path_card_context(files: list[str], file_summaries: dict[str, str]) -> str:
    """Compact per-file context for the card prompt. For very long chains
    (100s of files) sample head + tail and note the omitted middle so the
    prompt stays small."""
    HEAD, TAIL = 18, 6
    n = len(files)

    def _line(stem: str) -> str:
        s = (file_summaries.get(stem) or "").strip()
        # One sentence per file is plenty of signal for a path-level card.
        if s:
            s = s.split(". ")[0].strip()
        return f"- {stem}: {s or '(no summary available)'}"

    if n <= HEAD + TAIL:
        body = "\n".join(_line(s) for s in files)
    else:
        head = "\n".join(_line(s) for s in files[:HEAD])
        tail = "\n".join(_line(s) for s in files[-TAIL:])
        body = f"{head}\n- … ({n - HEAD - TAIL} more intermediate files) …\n{tail}"
    return body


def _parse_card_json(raw: str) -> Optional[dict[str, str]]:
    """Defensively pull {business_name, description} out of an LLM response."""
    if not raw:
        return None
    text = raw.strip()
    # Strip ```json fences if present.
    if text.startswith("```"):
        text = text.split("\n", 1)[-1]
        if text.endswith("```"):
            text = text[: -3]
    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        text = text[start : end + 1]
    try:
        obj = json.loads(text)
    except Exception:
        return None
    if not isinstance(obj, dict):
        return None
    name = str(obj.get("business_name") or "").strip()
    desc = str(obj.get("description") or "").strip()
    detailed = str(obj.get("detailed_description") or "").strip()
    if not name and not desc and not detailed:
        return None
    return {
        "business_name": name,
        "description": desc,
        "detailed_description": detailed or desc,
    }


def summarize_path_card(
    files: list[str],
    file_summaries: dict[str, str],
) -> dict[str, str]:
    """Return {'business_name', 'description'} for the whole path via one LLM call.

    Falls back to a deterministic name/description on any failure so the caller
    always gets usable text."""
    files = list(files or [])
    fallback_name = " → ".join(files) if files else "Execution Path"
    if not files:
        return {"business_name": fallback_name, "description": "", "detailed_description": ""}

    context = _build_path_card_context(files, file_summaries)
    flow_str = " -> ".join(files)
    prompt = (
        f"Execution path (entry point -> end), {len(files)} file(s):\n"
        f"  {flow_str}\n\n"
        f"Business purpose of each file in the path:\n{context}\n\n"
        "Name and describe this path as a whole. Respond with the JSON object only."
    )
    try:
        raw = call_llm(prompt, system_prompt=_PATH_CARD_SYSTEM_PROMPT)
        card = _parse_card_json(raw)
    except Exception:
        card = None

    if not card:
        # Deterministic fallback: stitch first sentences into a path narrative.
        first = (file_summaries.get(files[0]) or "").split(". ")[0].strip()
        last = (file_summaries.get(files[-1]) or "").split(". ")[0].strip()
        if first and last and files[0] != files[-1]:
            desc = f"This path begins in {files[0]} ({first.lower()}) and ends in {files[-1]} ({last.lower()})."
        elif first:
            desc = first
        else:
            desc = f"Propagation path across {len(files)} files."
        return {"business_name": fallback_name, "description": desc, "detailed_description": desc}

    if not card.get("business_name"):
        card["business_name"] = fallback_name
    card.setdefault("detailed_description", card.get("description", ""))
    return card


def _chain_key(variable: str, chain: dict, setter: dict) -> str:
    """Stable SHA256-based key for a (variable, chain, setter) triple."""
    raw = ":".join([
        variable,
        ":".join(chain.get("files", [])),
        setter.get("file_stem", ""),
        setter.get("inst", ""),
        str(setter.get("line", "")),
    ])
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def graph_fingerprint(graph_payload: dict[str, Any]) -> str:
    """Stable hash for graph metadata + structure."""
    normalized = json.dumps(graph_payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def _load_legacy_chain_cache(kb_id: str) -> dict:
    path = _legacy_chain_cache_path(kb_id)
    if not path.exists():
        return {}
    try:
        return msgpack.unpackb(path.read_bytes(), raw=False)
    except Exception:
        return {}


def _save_legacy_chain_cache(kb_id: str, cache: dict) -> None:
    path = _legacy_chain_cache_path(kb_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(msgpack.packb(cache, use_bin_type=True))


def _empty_chain_summaries_cache() -> dict[str, Any]:
    return {
        "version": CHAIN_SUMMARY_CACHE_VERSION,
        "graph_fingerprint": "",
        "entries": {},
    }


def load_chain_summaries_cache(kb_id: str) -> dict[str, Any]:
    path = chain_summaries_cache_path(kb_id)
    if not path.exists():
        return _empty_chain_summaries_cache()
    try:
        raw = msgpack.unpackb(path.read_bytes(), raw=False)
    except Exception:
        return _empty_chain_summaries_cache()

    if not isinstance(raw, dict):
        return _empty_chain_summaries_cache()

    cache = _empty_chain_summaries_cache()
    version = raw.get("version")
    if isinstance(version, int):
        cache["version"] = version
    fingerprint = raw.get("graph_fingerprint")
    if isinstance(fingerprint, str):
        cache["graph_fingerprint"] = fingerprint

    entries_raw = raw.get("entries", {})
    if isinstance(entries_raw, dict):
        for key, value in entries_raw.items():
            if not isinstance(key, str):
                continue
            if isinstance(value, dict):
                summary = value.get("summary")
                files = value.get("files")
                if isinstance(summary, str):
                    cache["entries"][key] = {
                        "summary": summary,
                        "files": files if isinstance(files, list) else [],
                    }
            elif isinstance(value, str):
                cache["entries"][key] = {"summary": value, "files": []}

    return cache


def save_chain_summaries_cache(kb_id: str, cache: dict[str, Any]) -> None:
    path = chain_summaries_cache_path(kb_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": int(cache.get("version", CHAIN_SUMMARY_CACHE_VERSION)),
        "graph_fingerprint": str(cache.get("graph_fingerprint", "")),
        "entries": cache.get("entries", {}),
    }
    path.write_bytes(msgpack.packb(payload, use_bin_type=True))


def get_cached_chain_summary(cache: dict[str, Any], chain: dict[str, Any]) -> Optional[str]:
    files = chain.get("files") or []
    if not files:
        return None
    key = chain_files_key(files)
    item = (cache.get("entries") or {}).get(key)
    if isinstance(item, dict):
        summary = item.get("summary")
        if isinstance(summary, str) and summary.strip():
            return summary
    return None


def set_cached_chain_summary(cache: dict[str, Any], chain: dict[str, Any], summary: str) -> str:
    files = list(chain.get("files") or [])
    key = chain_files_key(files)
    entries = cache.setdefault("entries", {})
    entries[key] = {"files": files, "summary": summary}
    return key


def _build_prompt(
    variable: str,
    chain: dict,
    setter_locations: list[dict],
    file_summaries: dict[str, str],
    hop_conditions: Optional[Dict[Tuple[str, str], List[Dict[str, Any]]]] = None,
) -> str:
    files: list[str] = chain.get("files", [])
    hops: list[dict] = chain.get("hops", [])

    if hops:
        flow_parts = []
        for hop in hops:
            frm = hop.get("from", "?")
            to = hop.get("to", "?")
            flow_parts.append(f"  {frm} -> {to}")
        flow_str = "\n".join(flow_parts)
    elif files:
        flow_str = f"  {files[0]} (direct - no intermediate hops)"
    else:
        flow_str = "  (no chain information)"

    setter_lines = []
    for s in setter_locations:
        detail = s.get("detail", "")
        line = s.get("line", "?")
        setter_lines.append(
            f'  File "{s.get("file_stem","?")}" modifies {variable} at line {line}'
            + (f" ({detail})" if detail else "")
        )
    setter_str = "\n".join(setter_lines) if setter_lines else f"  {files[-1] if files else '?'} modifies {variable}"

    context_parts = []
    for stem in files:
        summary = file_summaries.get(stem)
        if summary:
            context_parts.append(f"- {stem}: {summary}")
        else:
            context_parts.append(f"- {stem}: (no summary available)")
    context_str = "\n".join(context_parts)

    conditions_block = _render_hop_conditions_block(hops, hop_conditions)
    conditions_section = f"{conditions_block}\n\n" if conditions_block else ""

    return (
        f"Variable being tracked: {variable}\n\n"
        f"Call chain (entry point -> modifier):\n{flow_str}\n\n"
        f"Modification point:\n{setter_str}\n\n"
        f"Business context of files in this chain:\n{context_str}\n\n"
        f"{conditions_section}"
        "Explain what business scenario is happening in this chain for a business audience."
    )


def _build_generic_prompt(
    chain: dict[str, Any],
    file_summaries: dict[str, str],
    node_types: dict[str, str],
    hop_conditions: Optional[Dict[Tuple[str, str], List[Dict[str, Any]]]] = None,
) -> str:
    files: list[str] = chain.get("files", [])
    hops: list[dict] = chain.get("hops", [])

    if hops:
        flow_parts = []
        for hop in hops:
            frm = hop.get("from", "?")
            to = hop.get("to", "?")
            flow_parts.append(f"  {frm} -> {to}")
        flow_str = "\n".join(flow_parts)
    elif files:
        flow_str = f"  {' -> '.join(files)}"
    else:
        flow_str = "  (no chain information)"

    context_parts = []
    for stem in files:
        summary = file_summaries.get(stem)
        if summary:
            context_parts.append(f"- {stem}: {summary}")
            continue

        node_type = (node_types.get(stem) or "").lower()
        if node_type == "external":
            context_parts.append(
                f"- {stem}: (external module/dependency; no parser summary available)"
            )
        else:
            context_parts.append(
                f"- {stem}: (project file; parser summary unavailable)"
            )
    context_str = "\n".join(context_parts)

    conditions_block = _render_hop_conditions_block(hops, hop_conditions)
    conditions_section = f"{conditions_block}\n\n" if conditions_block else ""

    return (
        "Call chain (entry point -> downstream dependency):\n"
        f"{flow_str}\n\n"
        "Business context of files in this chain:\n"
        f"{context_str}\n\n"
        f"{conditions_section}"
        "Explain what business scenario is happening across this chain."
    )


def summarize_chain(
    chain: dict[str, Any],
    file_summaries: dict[str, str],
    node_types: dict[str, str],
    hop_conditions: Optional[Dict[Tuple[str, str], List[Dict[str, Any]]]] = None,
) -> str:
    prompt = _build_generic_prompt(
        chain=chain,
        file_summaries=file_summaries,
        node_types=node_types,
        hop_conditions=hop_conditions,
    )
    return call_llm(prompt, system_prompt=_GENERIC_SYSTEM_PROMPT)


def explain_chain(
    variable: str,
    chain: dict,
    setter_locations: list[dict],
    file_summaries: dict[str, str],
    kb_id: str,
    hop_conditions: Optional[Dict[Tuple[str, str], List[Dict[str, Any]]]] = None,
) -> str:
    """Return a variable-specific business explanation, using legacy cache first."""
    primary_setter = setter_locations[0] if setter_locations else {}
    key = _chain_key(variable, chain, primary_setter)

    cache = _load_legacy_chain_cache(kb_id)
    if key in cache:
        return cache[key]

    prompt = _build_prompt(
        variable, chain, setter_locations, file_summaries, hop_conditions=hop_conditions,
    )
    explanation = call_llm(prompt, system_prompt=_SYSTEM_PROMPT)

    cache[key] = explanation
    _save_legacy_chain_cache(kb_id, cache)

    return explanation
