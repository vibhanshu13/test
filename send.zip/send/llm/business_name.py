"""Generate short, human-friendly business names for source files.

A *business name* is a 2–5 word label derived from the file's existing
``business_summary`` (produced by ``llm/summarizer.py``). It is rendered as a
subtitle under the filename in the file-flow graph so non-technical readers can
recognise a file's purpose at a glance — e.g. ``lu82.asm`` → "Message Router".

Names are cached per knowledge base on disk so the LLM is only consulted the
first time a file is requested. The cache lives next to the rest of the KB's
analysis output and is therefore naturally project-scoped: a name generated for
``lu82.asm`` in KB A is never reused for KB B's ``lu82.asm`` (whose summary may
describe a completely different file).

CLI usage::

    python -m llm.business_name --kb-output <path>            # populate cache for every file in the KB
    python -m llm.business_name --kb-output <path> --file lu82.asm   # one file
"""

from __future__ import annotations

import argparse
import json
import logging
import re
from pathlib import Path
from threading import Lock
from typing import Dict, List, Optional

from llm.caller import call_llm

logger = logging.getLogger(__name__)

_CACHE_FILENAME = "business_names.json"

_SYSTEM_PROMPT = (
    "You generate ultra-short business labels for mainframe and C++ source files. "
    "Given a multi-sentence business summary of one file, return a 2 to 5 word "
    "title-case label that captures its primary business purpose. "
    "Examples of the style: \"Message Router\", \"Global Limits Processor\", "
    "\"Plastic Card Authenticator\", \"Pin Management Service\". "
    "Hard rules: "
    "(1) Output the label only — no quotes, no trailing period, no preface. "
    "(2) Use title case. "
    "(3) Never mention low-level details like opcodes, registers, or file names. "
    "(4) If the summary is empty or uninformative, return the single word \"Unknown\"."
)

# In-process lock to keep concurrent requests from corrupting the cache file.
_cache_lock = Lock()


# ---------------------------------------------------------------------------
# Cache I/O
# ---------------------------------------------------------------------------

def _cache_path(kb_output: Path) -> Path:
    return Path(kb_output) / _CACHE_FILENAME


def load_cache(kb_output: Path) -> Dict[str, str]:
    """Load the per-KB business-name cache. Returns ``{}`` on first run."""
    p = _cache_path(kb_output)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8")) or {}
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning("business_name cache at %s unreadable (%s); starting fresh", p, exc)
        return {}


def save_cache(kb_output: Path, data: Dict[str, str]) -> None:
    """Atomically write the cache to disk."""
    p = _cache_path(kb_output)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(p)


# ---------------------------------------------------------------------------
# LLM call
# ---------------------------------------------------------------------------

_INVALID_PREFIX_RE = re.compile(r"^[\s\-•*\"']+|[\s\.\"']+$")


def _clean_label(raw: str) -> str:
    """Strip the common ways an LLM ignores 'no quotes / no preface' rules."""
    text = (raw or "").strip()
    # Collapse to first non-empty line
    for line in text.splitlines():
        line = line.strip()
        if line:
            text = line
            break
    # Trim stray punctuation/bullets
    text = _INVALID_PREFIX_RE.sub("", text)
    # Reject obvious failure modes
    if not text or len(text) > 60:
        return ""
    return text


def generate_business_name(summary: str) -> str:
    """Produce a short business label from a file-level summary.

    Returns an empty string on LLM failure or unusable output; callers should
    treat that as "no label available" rather than caching it.
    """
    s = (summary or "").strip()
    if not s:
        return ""
    prompt = (
        "FILE BUSINESS SUMMARY\n"
        f"{s}\n\n"
        "Return the 2–5 word business label only."
    )
    try:
        raw = call_llm(prompt, system_prompt=_SYSTEM_PROMPT)
    except Exception as exc:
        logger.warning("business_name LLM call failed: %s", exc)
        return ""
    label = _clean_label(raw)
    if not label or label.lower() == "unknown":
        return ""
    return label


# ---------------------------------------------------------------------------
# Public API used by the conversations route
# ---------------------------------------------------------------------------

def _file_id_to_stem(file_id: str) -> str:
    """Strip the language extension to derive a blueprint stem from a file_id."""
    for ext in (".asm", ".mac", ".cpp", ".hpp"):
        if file_id.endswith(ext):
            return file_id[: -len(ext)]
    return file_id


def _load_summary_for_file(bp_dir: Path, file_id: str, kb_id: Optional[str] = None) -> str:
    """Load the business_summary for ``file_id`` from its blueprint.

    When ``kb_id`` is supplied and the blueprint has no usable summary, fall
    back to :func:`api.tasks.file_summary_fallback.ensure_file_business_summary`
    (LLM call + write-back). Returns "" if no summary could be produced.
    """
    bp_path = Path(bp_dir) / f"{file_id}.json"
    summary = ""
    if bp_path.exists():
        try:
            from blueprint_io import load_blueprint
            bp = load_blueprint(bp_path, skip_global_lineage=True, keys={"business_summary"})
            summary = (bp.get("business_summary") or "").strip()
        except Exception as exc:
            logger.debug("business_name: could not load blueprint %s (%s)", bp_path, exc)
    if not summary and kb_id:
        try:
            from api.tasks.file_summary_fallback import ensure_file_business_summary
            generated = ensure_file_business_summary(kb_id, _file_id_to_stem(file_id), bp_dir=Path(bp_dir))
            if generated:
                summary = generated.strip()
        except Exception as exc:
            logger.debug("business_name: fallback failed for %s (%s)", file_id, exc)
    return summary


def get_business_name(
    kb_output: Path,
    bp_dir: Path,
    file_id: str,
    kb_id: Optional[str] = None,
) -> Optional[str]:
    """Return the cached business name for ``file_id``, generating it if absent.

    The cache is scoped to ``kb_output`` so names from one project never leak
    into another. Returns ``None`` if no usable label could be produced — this
    is what the route should serialize as JSON ``null``.
    """
    if not file_id:
        return None

    cache = load_cache(kb_output)
    if file_id in cache:
        # Treat empty-string cache entries as "tried and failed" — fall back to
        # None so the wire shape is consistent. Don't retry: the summary is
        # static, so a repeat call would burn an LLM credit for the same result.
        return cache[file_id] or None

    summary = _load_summary_for_file(bp_dir, file_id, kb_id=kb_id)
    if not summary:
        # Persist the negative so we don't keep loading the blueprint either.
        with _cache_lock:
            cache = load_cache(kb_output)
            cache[file_id] = ""
            save_cache(kb_output, cache)
        return None

    label = generate_business_name(summary)
    with _cache_lock:
        cache = load_cache(kb_output)  # re-load to merge concurrent writes
        cache[file_id] = label
        save_cache(kb_output, cache)

    return label or None


def get_business_names(
    kb_output: Path,
    bp_dir: Path,
    file_ids: list[str],
    kb_id: Optional[str] = None,
) -> Dict[str, Optional[str]]:
    """Batch version: returns ``{file_id: business_name or None}`` for every id.

    Cheaper than calling ``get_business_name`` in a loop because the cache file
    is only opened twice (once to read, once to write the merged result) even
    when several names need to be generated. When ``kb_id`` is supplied,
    file_ids whose blueprint has no business_summary are populated via the
    shared file-summary fallback before the business-name label is generated.
    """
    cache = load_cache(kb_output)
    result: Dict[str, Optional[str]] = {}
    dirty = False

    # First pass: collect the file_ids that still need a summary so we can
    # parallelise their LLM generation in one call.
    needs_summary: List[str] = []
    for fid in file_ids:
        if fid and fid not in cache:
            needs_summary.append(fid)

    prefilled: Dict[str, str] = {}
    if needs_summary and kb_id:
        try:
            from api.tasks.file_summary_fallback import ensure_many_business_summaries
            stems = [_file_id_to_stem(fid) for fid in needs_summary]
            filled = ensure_many_business_summaries(kb_id, stems, max_workers=4)
            for fid, stem in zip(needs_summary, stems):
                text = filled.get(stem)
                if text and text.strip():
                    prefilled[fid] = text.strip()
        except Exception as exc:
            logger.debug("business_name: batch fallback failed (%s)", exc)

    for fid in file_ids:
        if not fid:
            result[fid] = None
            continue
        if fid in cache:
            result[fid] = cache[fid] or None
            continue
        summary = prefilled.get(fid) or _load_summary_for_file(bp_dir, fid, kb_id=kb_id)
        if not summary:
            cache[fid] = ""
            result[fid] = None
            dirty = True
            continue
        label = generate_business_name(summary)
        cache[fid] = label
        result[fid] = label or None
        dirty = True

    if dirty:
        with _cache_lock:
            # Merge against the on-disk copy to avoid clobbering parallel writes.
            on_disk = load_cache(kb_output)
            on_disk.update(cache)
            save_cache(kb_output, on_disk)

    return result


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _main() -> int:
    parser = argparse.ArgumentParser(
        description="Generate (or refresh) business_name cache for a KB."
    )
    parser.add_argument(
        "--kb-output",
        required=True,
        type=Path,
        help="Path to the KB's output dir (e.g. jobs/<kb_id>/output)",
    )
    parser.add_argument(
        "--bp-dir",
        type=Path,
        default=None,
        help="Blueprint dir (defaults to <kb-output>/asm)",
    )
    parser.add_argument(
        "--file",
        action="append",
        default=None,
        help="Specific file id (e.g. lu82.asm). Repeatable. Default: every blueprint in the dir.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Re-generate even if a cached value exists.",
    )
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    bp_dir = args.bp_dir or (args.kb_output / "asm")
    if not bp_dir.is_dir():
        print(f"error: blueprint dir {bp_dir} does not exist", flush=True)
        return 2

    if args.file:
        file_ids = list(args.file)
    else:
        file_ids = sorted(p.name[:-len(".json")] for p in bp_dir.glob("*.json"))

    if args.force:
        cache = load_cache(args.kb_output)
        for fid in file_ids:
            cache.pop(fid, None)
        save_cache(args.kb_output, cache)

    results = get_business_names(args.kb_output, bp_dir, file_ids)
    for fid in file_ids:
        print(f"  {fid:40s} → {results.get(fid) or '(none)'}")
    print(f"Done. {sum(1 for v in results.values() if v)} / {len(results)} named.")
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
