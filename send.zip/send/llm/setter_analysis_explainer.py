"""Setter Analysis LLM explainer (the prose layer over the chainless scaffold).

Public entry point: ``explain_setter_root`` — given ONE setter site's structural
tuple (the ``process_single_root`` shape) plus the setter root dict, build a
deterministic step plan (``setter_analysis_reasoning.build_setter_reasoning``),
narrate every step with the LLM, then synthesise one end-to-end summary.

Mirrors ``llm/lineage_explainer.py`` discipline: reuse its system prompts,
reuse ``StepExplanation`` / ``SynthesisExplanation`` as the LLM structured
outputs, and reuse ``process_analysis.backend.llm.call_llm_model`` to call the
model.  The output validates as ``api.schemas.setter_analysis.ProsePayload``.

Business mode (business_mode=True): leave ``SetterConditionItem.check`` empty and
fill ``in_plain_terms`` with concrete VALUES; no file stems / routines / code.
Technical mode: fill ``check`` verbatim and attach a ``source`` code chunk when
code lines are available.

Robustness: each LLM call is wrapped so one failure degrades to a minimal
deterministic step rather than aborting the whole analysis.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional

from api.schemas.lineage_explain import StepExplanation, SynthesisExplanation
from api.schemas.setter_analysis import (
    ConditionGroup,
    SetterConditionItem,
    SetterDepVar,
    SetterStep,
    SetterStepSource,
    SetterSummary,
    VariableDefinition,
)
from llm.lineage_explainer import (
    _BUSINESS_SYSTEM_PROMPT,
    _PURE_BUSINESS_SYNTHESIS_PROMPT,
    _PURE_BUSINESS_SYSTEM_PROMPT,
    _SYNTHESIS_SYSTEM_PROMPT,
)
from llm.setter_analysis_reasoning import (
    ORIGIN_CALLER_CALL_CONDITION,
    ORIGIN_DEPENDENT_VARIABLE,
    ORIGIN_SETTER_LOCAL,
    build_setter_reasoning,
    build_variable_definition_facts,
)

logger = logging.getLogger(__name__)

_ORIGIN_HEADINGS = {
    ORIGIN_SETTER_LOCAL: "Conditions inside the setter file",
    ORIGIN_CALLER_CALL_CONDITION: "Conditions on the call into this file",
    ORIGIN_DEPENDENT_VARIABLE: "Conditions on the dependent values",
}

# We hand the LLM at most this many conditions / deps PER STEP to phrase (a
# single step can carry 100+). COMPLETENESS does not depend on these caps — the
# deterministic mappers reattach every scaffold item; the cap only bounds the
# phrasing sample given to the model.
# Conditions and deps are paginated across multiple LLM calls so every item
# gets phrased without the prompt growing too large to complete.
# Each batch goes in a separate parallel call; results are merged by expression text.
_COND_BATCH_SIZE = 25    # smaller batches → the LLM reliably returns every item
_DEP_BATCH_SIZE = 25     # deps per LLM call


# ---------------------------------------------------------------------------
# Prompt builders (mirror _build_step_prompt / _build_synthesis_prompt)
# ---------------------------------------------------------------------------

def _fmt_conditions(conds: List[Dict[str, Any]], business_mode: bool) -> str:
    lines: List[str] = []
    for c in conds:
        expr = c.get("expression") or c.get("raw") or ""
        if not expr:
            continue
        if business_mode:
            lines.append(f"  Business decision (value tested: {expr})")
        else:
            loc = ""
            if c.get("file_stem") or c.get("line"):
                loc = f" [in {c.get('file_stem','?')}" + (f" line {c.get('line')}" if c.get("line") else "") + "]"
            lines.append(f"  `{expr}`{loc}")
    return "\n".join(lines)


def _fmt_deps(deps: List[Dict[str, Any]], business_mode: bool) -> str:
    lines: List[str] = []
    for d in deps:
        nm = d.get("name") or ""
        kind = d.get("kind") or ""
        constraint = d.get("constraint") or ""
        rel = "" if d.get("relevant", True) else f" (provably pruned: {d.get('pruned_reason','')})"
        if business_mode:
            cval = f" — value tested: {constraint}" if constraint else ""
            lines.append(f"  {nm}{cval}{rel}")
        else:
            cstr = f" constraint `{constraint}`" if constraint else ""
            lines.append(f"  {nm} ({kind}){cstr}{rel}")
    return "\n".join(lines)


def _build_setter_step_prompt(
    scaffold_step: Dict[str, Any],
    root_variable: str,
    business_mode: bool,
) -> str:
    kind = scaffold_step.get("kind", "")
    file_stem = scaffold_step.get("file_stem", "?")
    file_type = scaffold_step.get("file_type", "asm")
    variable = scaffold_step.get("variable_in_step", root_variable)

    sections: List[str] = []
    sections.append(
        "SETTER ANALYSIS — STEP GOAL\n"
        f"We are explaining how the variable '{root_variable}' gets set, working OUTWARD from its setter site.\n"
        f"This step (kind={kind}) is about file '{file_stem}' ({file_type.upper()}), variable '{variable}'.\n"
        f"Step {scaffold_step.get('index', 0) + 1} of {scaffold_step.get('total_steps', 1)}."
    )

    cur: List[str] = [f"WHY WE ARE HERE (the connecting thread):\n{scaffold_step.get('why_we_are_here','')}"]

    setter = scaffold_step.get("setter") or {}
    if setter and setter.get("instruction"):
        if business_mode:
            cur.append("THE SETTER (what value is written here):\n  the variable is assigned its value at this site")
        else:
            cur.append(
                "THE SETTER (where this variable gets its value):\n"
                f"  exact statement: {setter.get('raw') or setter.get('instruction')}\n"
                f"  operation: {setter.get('instruction')}\n"
                f"  role: {setter.get('role') or '(setter)'}"
            )

    # Conditions, grouped by origin. We may CAP the sample handed to the LLM for
    # phrasing (a step can carry 100+ conditions); completeness is guaranteed in
    # the deterministic mapper, which matches the LLM phrasing back by text.
    for origin, conds in (scaffold_step.get("conditions") or {}).items():
        conds = [c for c in conds if (c.get("expression") or c.get("raw"))]
        if not conds:
            continue
        heading = _ORIGIN_HEADINGS.get(origin, origin)
        header = (
            f"CONDITIONS — {heading} (describe each as a business decision, include the concrete value):\n"
            if business_mode else
            f"CONDITIONS — {heading} (verbatim guards in order):\n"
        )
        # Send ALL conditions — no truncation. Large sets get a pagination note.
        body = _fmt_conditions(conds, business_mode)
        cur.append(header + body)

    deps = scaffold_step.get("deps") or []
    if deps:
        cur.append(
            "DEPENDENT VARIABLES (values that influence this setter — give each a business name):\n"
            + _fmt_deps(deps, business_mode)
        )

    notes = scaffold_step.get("notes") or []
    if notes:
        cur.append("COVERAGE / NOTES:\n" + "\n".join(f"  - {n}" for n in notes))

    sections.append("\n\n".join(cur))

    # Task — reuse the lineage_explainer field contract.
    if business_mode:
        sections.append(
            "YOUR TASK — fill the StepExplanation JSON for a non-technical executive.\n"
            "- headline: ONE plain-business sentence about what happens at this step (no code, no file stems).\n"
            f"- variable_business_name: the readable Title-Case business name of '{variable}'.\n"
            "- narrative: CRISP Markdown bullets — what is checked, what decision is made, what value is recorded. "
            "Keep every concrete value the scaffold gives (codes, versions, return codes, identifiers). Refer to any "
            "file ONLY by a business name for what it does, never its code stem.\n"
            "- statements: leave EMPTY [].\n"
            "- conditions: return EVERY condition listed above — one entry each, IN THE SAME ORDER, none skipped. "
            "Set `check` to the EXACT expression text shown for that condition (it is used only to line up your "
            "answer with the source — it is NOT shown to the reader). Fill `in_plain_terms` (the business question, "
            "INCLUDING the concrete value tested) and `decides` (what each outcome means).\n"
            "- dependent_variables: each one — `name`, `business_name`, `why_it_was_traced` in business terms.\n"
            "- what_happens_next: one sentence on what is examined next and why.\n"
            "REMEMBER: any assembly mnemonic, raw code, file stem, or routine name is a failure."
        )
    else:
        sections.append(
            "YOUR TASK — fill the StepExplanation JSON for a business reader who knows no assembly.\n"
            "- headline: ONE clear sentence stating what this step is about; start with the variable's business name.\n"
            f"- variable_business_name: the readable Title-Case business name of '{variable}'.\n"
            "- narrative: CRISP Markdown bullets covering this file — how the variable is set here (if it is), each "
            "condition, each dependent value. Put the meaning in the sentence and the EXACT statement + routine in "
            "parentheses (NEVER line numbers). Name each variable as its business name then its code name in parentheses.\n"
            "- statements: every key statement — verbatim `statement`, `opcode_meaning`, `means`.\n"
            "- conditions: one entry per condition above — `check` verbatim, `in_plain_terms`, `decides`.\n"
            "- dependent_variables: each one — `name`, `business_name`, `why_it_was_traced`.\n"
            "- what_happens_next: one sentence on what is examined next and why.\n"
            "Never print a bare mnemonic without explaining it. Never invent facts not in the scaffold."
        )

    return "\n\n---\n\n".join(sections)


def _build_setter_synthesis_prompt(
    root_variable: str,
    reasoning: Dict[str, Any],
    step_explanations: List[Dict[str, Any]],
    business_mode: bool,
) -> str:
    steps = reasoning.get("steps") or []
    cov = reasoning.get("coverage") or {}
    sections: List[str] = []
    sections.append(
        "SETTER ANALYSIS — FINAL SUMMARY GOAL\n"
        f"Produce the complete end-to-end explanation of how '{root_variable}' gets set at ONE setter site, "
        "walking from the outermost caller down to the setter and covering every condition that had to be true."
    )

    # The SPECIFIC value THIS setter site writes. The summary must describe ONLY
    # this one value — never enumerate the other values the field takes at other
    # sites (each site is analysed separately).
    setter0 = (steps[0].get("setter") if steps else {}) or {}
    set_value = str(setter0.get("raw") or setter0.get("instruction") or "").strip()
    if set_value:
        sections.append(
            "THE VALUE THIS SETTER SITE WRITES (describe ONLY this one):\n"
            f"  {set_value}\n"
            "CRITICAL: `what_its_set_to` / `how_it_is_set` must describe THIS SINGLE value at THIS one site. "
            "Do NOT list or compare the other values the field can take at other setter sites — this analysis is "
            "scoped to this one site only."
        )

    # Hard totals so the prose states full scale and never reads complete when it
    # isn't. These are the AUTHORITATIVE counts (from the deterministic scaffold).
    sections.append(
        "COVERAGE TOTALS — state these scale figures in the prose so the reader knows the full extent:\n"
        f"  - distinct conditions that had to be true: {int(cov.get('distinct_condition_count') or 0)} "
        f"(setter-local) — plus call-conditions across callers\n"
        f"  - distinct dependent variables: {int(cov.get('distinct_dep_count') or 0)}\n"
        f"  - distinct caller files reaching this setter: {int(cov.get('distinct_caller_files') or 0)}\n"
        f"  - deepest caller depth: {int(cov.get('max_caller_depth') or 0)}\n"
        f"  - total reasoning steps: {int(cov.get('total_steps') or 0)}\n"
        f"Mention these totals naturally, e.g. \"set here; gated by N distinct conditions; depends on M variables; "
        f"reachable from K caller files (depth ≤ D)\"."
    )

    # One-line fact per step (always — cheap shape of the whole plan).
    fact_lines: List[str] = []
    for s in steps:
        fact_lines.append(
            f"  • Step {s.get('index')}: [{s.get('kind')}] file {s.get('file_stem')} — {s.get('why_we_are_here','')}"
        )
    if fact_lines:
        sections.append("STEP-BY-STEP FACTS (every step, one line each)\n" + "\n".join(fact_lines))

    # Conditions grouped by origin (the subheadings the user wants).
    grouped: Dict[str, List[str]] = {}
    for s in steps:
        for origin, conds in (s.get("conditions") or {}).items():
            for c in conds:
                expr = c.get("expression") or c.get("raw")
                if expr:
                    locus = s.get("file_stem", "")
                    grouped.setdefault(origin, []).append(f"{expr}" + (f" (in {locus})" if locus and not business_mode else ""))
    if grouped:
        gparts: List[str] = []
        for origin, items in grouped.items():
            gparts.append(_ORIGIN_HEADINGS.get(origin, origin) + ":\n" + "\n".join(f"    - {x}" for x in items[:20]))
        sections.append("CONDITIONS BY ORIGIN (group your condition_groups under these subheadings)\n" + "\n\n".join(gparts))

    # ALL dep vars from the scaffold — the prompt explicitly lists every one so
    # the LLM can write one bullet per var in dependent_variables_story.
    all_deps: Dict[str, Dict] = {}
    for s in steps:
        for d in (s.get("deps") or []):
            nm = str(d.get("name") or "")
            if nm and nm.upper() not in all_deps:
                all_deps[nm.upper()] = d
    if all_deps:
        dep_lines = []
        for d in all_deps.values():
            nm = d.get("name", "")
            kind = d.get("kind", "")
            cstr = d.get("constraint", "")
            relevant = d.get("relevant", True)
            tag = "" if relevant else " [provably pruned — value contradicts the guard; can note briefly]"
            if business_mode:
                dep_lines.append(f"  • {nm} ({kind}{', ' + cstr if cstr else ''}){tag}")
            else:
                dep_lines.append(f"  • {nm} | kind={kind} | constraint={cstr}{tag}")
        sections.append(
            f"ALL DEPENDENT VARIABLES ({len(all_deps)} total) — write ONE bullet for EACH in dependent_variables_story:\n"
            + "\n".join(dep_lines)
        )

    # Bounded full detail from the LLM step narratives.
    detail: List[str] = []
    for exp in step_explanations[:12]:
        if not isinstance(exp, dict):
            continue
        head = exp.get("headline") or ""
        narr = (exp.get("narrative") or "")[:600]
        if head or narr:
            detail.append(f"[step] {head}\n{narr}".strip())
    if detail:
        sections.append("KEY STEP NARRATIVES (use for the story; the facts above cover the rest)\n\n" + "\n\n".join(detail))

    if business_mode:
        sections.append(
            f"YOUR TASK — write the SynthesisExplanation JSON for '{root_variable}', for a non-technical executive.\n"
            "Only the variable's own code name (in parentheses after its business name) may appear; NEVER file stems, "
            "routines, opcodes, or raw statements. Keep concrete business VALUES.\n"
            "- variable_business_name; what_it_is (2-4 sentences).\n"
            "- how_it_is_set: CRISP bullets — the SINGLE value THIS site writes (see 'THE VALUE THIS SETTER SITE "
            "WRITES' above) and what it means, in business terms. Do NOT list other values from other sites.\n"
            "- what_had_to_be_true: CRISP bullets — EVERY condition that had to hold, grouped naturally, with the "
            "concrete value tested.\n"
            "- dependent_variables_story: CRISP bullet list — ONE bullet per dependent variable, NO prose intro, NO 'key examples'. "
            "Every bullet: '• Business Name (CODE_NAME): what value/state it must have and why that matters for setting the target.' "
            "Cover ALL dep vars (the scaffold listed them all). Keep each bullet under 25 words.\n"
            "- chain_narrative: the journey from the outermost caller down to the setter, programs named by what they do.\n"
            "- full_story: a short point-based end-to-end account.\n"
            "- setting_rule_groups: one group per variable that gets set (the main one first)."
        )
    else:
        sections.append(
            f"YOUR TASK — write the SynthesisExplanation JSON for '{root_variable}', for a business reader who knows no assembly.\n"
            "- variable_business_name; what_it_is (2-4 sentences).\n"
            "- how_it_is_set: CRISP bullets — file, routine, operation in plain words + exact statement in parentheses, "
            "the SINGLE value THIS site writes (see 'THE VALUE THIS SETTER SITE WRITES' above). Do NOT list other "
            "values from other sites.\n"
            "- what_had_to_be_true: CRISP bullets — the full chain of conditions as business decisions, from caller to setter.\n"
            "- dependent_variables_story: ONE bullet per dependent variable — NO 'key examples', cover ALL of them. "
            "Each bullet: '• Code Name (type/kind): constraint it must satisfy — why it affects the target.' Under 25 words each.\n"
            "- chain_narrative: the caller journey to the setter, control passing file to file.\n"
            "- full_story: a short point-based end-to-end account.\n"
            "- setting_rule_groups: one group per variable that gets set (the main one first), each rule specific.\n"
            "Follow THE ONE WRITING DESIGN: operation meaning in prose, exact statement + routine in parentheses, never line numbers."
        )

    return "\n\n---\n\n".join(sections)


# ---------------------------------------------------------------------------
# Mappers: LLM output -> Setter* schema
# ---------------------------------------------------------------------------

def _norm_text(s: Any) -> str:
    """Normalise condition text for matching (lower, collapse whitespace)."""
    return " ".join(str(s or "").strip().lower().split())


def _index_llm_conditions(llm_conditions: List[Any]) -> Dict[str, Dict[str, Any]]:
    """Index LLM ConditionExplained items by normalised `check` text for matching."""
    by_text: Dict[str, Dict[str, Any]] = {}
    for c in llm_conditions or []:
        cd = c if isinstance(c, dict) else c.model_dump()
        key = _norm_text(cd.get("check") or cd.get("in_plain_terms"))
        if key and key not in by_text:
            by_text[key] = cd
    return by_text


def _condition_groups_for_step(
    scaffold_step: Dict[str, Any],
    llm_conditions: List[Any],
    business_mode: bool,
) -> List[ConditionGroup]:
    """Build condition groups DETERMINISTICALLY from the scaffold (every distinct
    condition) and ENRICH each with the best-matching LLM phrasing.

    COMPLETENESS: the output always contains every scaffold condition for every
    origin on this step. The LLM only fills ``in_plain_terms`` / ``decides`` — it
    can never drop an item. Matching is by normalised verbatim text, falling back
    to positional order for any condition the LLM didn't echo.
    """
    scaffold_conds = scaffold_step.get("conditions") or {}
    by_text = _index_llm_conditions(llm_conditions)
    # Ordered fallback list (LLM items in the order they came back).
    llm_ordered: List[Dict[str, Any]] = [
        (c if isinstance(c, dict) else c.model_dump()) for c in (llm_conditions or [])
    ]

    groups: List[ConditionGroup] = []
    for origin in (scaffold_step.get("origins") or [ORIGIN_SETTER_LOCAL]):
        raw_conds = scaffold_conds.get(origin) or []
        if not raw_conds:
            continue
        items: List[SetterConditionItem] = []
        used_ordered = 0
        for rc in raw_conds:
            expr = rc.get("expression") or rc.get("raw") or ""
            match = by_text.get(_norm_text(rc.get("expression") or rc.get("raw")))
            if match is None and used_ordered < len(llm_ordered):
                # Positional fallback: only consume if its `check` isn't a better
                # match for some other scaffold cond (best-effort, order-based).
                match = llm_ordered[used_ordered]
                used_ordered += 1
            occ = int(rc.get("occurrences") or 1)
            ipt = str((match or {}).get("in_plain_terms") or "").strip()
            # COMPLETENESS GUARANTEE: a condition is NEVER blank. If the LLM didn't
            # phrase this one (long-list drop, batch miss), fall back to the raw
            # expression so the row is always readable.
            if not ipt:
                ipt = str(expr)
            items.append(SetterConditionItem(
                # Keep the raw expression in `check` always — the UI uses it as a
                # muted fallback and (in technical modes) as the verbatim guard.
                check=str(expr),
                in_plain_terms=ipt,
                decides=str((match or {}).get("decides") or ""),
                file_stem=str(rc.get("file_stem") or scaffold_step.get("file_stem") or ""),
                line=int(rc.get("line") or 0),
                occurrences=occ,
            ))
        where = "" if business_mode else str(scaffold_step.get("file_stem") or "")
        groups.append(ConditionGroup(
            origin=origin,
            heading=_ORIGIN_HEADINGS.get(origin, origin),
            where=where,
            conditions=items,
        ))
    return groups


def _dep_vars_for_step(
    scaffold_step: Dict[str, Any],
    llm_dep_vars: List[Any],
) -> List[SetterDepVar]:
    """Build dep-var list DETERMINISTICALLY from the scaffold (every distinct dep)
    and ENRICH with the LLM ``business_name`` / ``why_it_was_traced`` matched by
    name. COMPLETENESS: never drops a scaffold dep; un-phrased ones just lack a
    business name."""
    llm_by_name: Dict[str, Dict[str, Any]] = {}
    for dv in llm_dep_vars or []:
        dd = dv if isinstance(dv, dict) else dv.model_dump()
        nm = str(dd.get("name") or "").upper()
        if nm and nm not in llm_by_name:
            llm_by_name[nm] = dd
    out: List[SetterDepVar] = []
    for raw in (scaffold_step.get("deps") or []):
        name = str(raw.get("name") or "")
        if not name:
            continue
        llm = llm_by_name.get(name.upper(), {})
        out.append(SetterDepVar(
            name=name,
            business_name=str(llm.get("business_name") or ""),
            kind=str(raw.get("kind") or ""),
            constraint=str(raw.get("constraint") or ""),
            why_it_matters=str(llm.get("why_it_was_traced") or ""),
            relevant=bool(raw.get("relevant", True)),
            pruned_reason=str(raw.get("pruned_reason") or ""),
            occurrences=int(raw.get("occurrences") or 1),
        ))
    return out


def _source_for_step(scaffold_step: Dict[str, Any], business_mode: bool) -> Optional[SetterStepSource]:
    if business_mode:
        return None
    code = scaffold_step.get("relevant_code_lines") or ""
    setter = scaffold_step.get("setter") or {}
    if not code and not (setter and setter.get("raw")):
        return None
    line = int(setter.get("line") or 0)
    return SetterStepSource(
        file=str(scaffold_step.get("file_stem") or ""),
        file_type=str(scaffold_step.get("file_type") or "asm"),
        start_line=line,
        end_line=line,
        code=code or str(setter.get("raw") or ""),
        highlight_lines=[line] if line else [],
    )


def _fallback_step(scaffold_step: Dict[str, Any], business_mode: bool) -> SetterStep:
    """Minimal deterministic step when the LLM call fails — never abort."""
    return SetterStep(
        index=int(scaffold_step.get("index", 0)),
        total_steps=int(scaffold_step.get("total_steps", 1)),
        kind=str(scaffold_step.get("kind", "setter_site")),
        headline=str(scaffold_step.get("why_we_are_here") or scaffold_step.get("phase_label") or ""),
        file_stem=str(scaffold_step.get("file_stem") or ""),
        file_type=str(scaffold_step.get("file_type") or "asm"),
        variable_in_step=str(scaffold_step.get("variable_in_step") or ""),
        phase_label=str(scaffold_step.get("phase_label") or ""),
        caller_depth=int(scaffold_step.get("caller_depth", 0)),
        parent_index=scaffold_step.get("parent_index"),
        why_we_are_here=str(scaffold_step.get("why_we_are_here") or ""),
        explanation="(Automated explanation unavailable for this step; raw facts preserved.)",
        condition_groups=_condition_groups_for_step(scaffold_step, [], business_mode),
        dependent_variables=_dep_vars_for_step(scaffold_step, []),
        source=_source_for_step(scaffold_step, business_mode),
        warnings=list(scaffold_step.get("notes") or []),
    )


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def _default_band_size() -> int:
    import os
    try:
        return max(1, int(os.getenv("SETTER_ANALYSIS_BAND_SIZE", "8")))
    except ValueError:
        return 8


def _n_bands(total_steps: int, band_size: int) -> int:
    if total_steps <= 0:
        return 1            # still one (empty) band → one running summary + final
    bs = max(1, band_size)
    return (total_steps + bs - 1) // bs


def plan_llm_calls(structural: Dict[str, Any], variable: str, band_size: Optional[int] = None) -> int:
    """Count the LLM calls ONE variant will make for this setter root.

    Progressive generation makes ONE call per scaffold step, plus ONE running
    summary per BAND, plus ONE final end-to-end summary::

        total = n_steps + n_bands + 1

    Makes NO LLM call — only builds the reasoning scaffold and counts.
    """
    root_variable = (variable or "").upper()
    reasoning = build_setter_reasoning(structural, root_variable)
    n_steps = len(reasoning.get("steps") or [])
    bs = band_size if band_size else _default_band_size()
    # +1 per path that has conditions (each gets its own parallel LLM call).
    n_path_calls = sum(
        1 for p in (reasoning.get("paths") or [])
        if any(c.get("expression") or c.get("raw") for c in (p.get("conditions") or []))
    )
    return n_steps + _n_bands(n_steps, bs) + 1 + n_path_calls


def build_structural_payload(structural: Dict[str, Any], *, variable: str) -> Dict[str, Any]:
    """Deterministic TECHNICAL payload — NO LLM.

    Renders the structural scaffold directly (verbatim setter statement, every
    condition with its line number, every dependent variable, the caller walk),
    so 'Technical' mode is instant and 100% faithful — no narration, no
    hallucination. Returns the same payload shape as the progressive explainer
    (validates as ProsePayload), with empty narrative fields."""
    root_variable = (variable or "").upper()
    reasoning = build_setter_reasoning(structural, root_variable)
    scaffold_steps = reasoning.get("steps") or []
    total = len(scaffold_steps)

    steps: List[Dict[str, Any]] = []
    for sc in scaffold_steps:
        kind = str(sc.get("kind", "setter_site"))
        setter = sc.get("setter") or {}
        if kind == "setter_site":
            headline = str(setter.get("raw") or "").strip() or f"Sets {root_variable}"
        else:
            callees = sc.get("callees") or []
            headline = (f"{sc.get('file_stem','')} → {', '.join(callees)}"
                        if callees else str(sc.get("file_stem") or ""))
        step = SetterStep(
            index=int(sc.get("index", 0)),
            total_steps=total,
            kind=kind,
            headline=headline,
            file_stem=str(sc.get("file_stem") or ""),
            file_type=str(sc.get("file_type") or "asm"),
            variable_in_step=str(sc.get("variable_in_step") or root_variable),
            phase_label=str(sc.get("phase_label") or ""),
            caller_depth=int(sc.get("caller_depth", 0)),
            parent_index=sc.get("parent_index"),
            why_we_are_here=str(sc.get("why_we_are_here") or ""),
            explanation="",  # technical mode: no AI narration
            condition_groups=_condition_groups_for_step(sc, [], business_mode=False),
            dependent_variables=_dep_vars_for_step(sc, []),
            source=_source_for_step(sc, business_mode=False),
            warnings=list(sc.get("notes") or []),
        )
        steps.append(step.model_dump())

    cov = reasoning.get("coverage") or {}
    setter0 = (scaffold_steps[0].get("setter") if scaffold_steps else {}) or {}
    # "what it's set to" — prefer the raw statement; fall back to the setter
    # step's headline (which itself falls back to "Sets <VAR>") so it's never blank.
    set_to = str(setter0.get("raw") or "").strip()
    if not set_to and steps:
        set_to = str(steps[0].get("headline") or "")
    all_groups: List[ConditionGroup] = []
    for sc in scaffold_steps:
        all_groups.extend(_condition_groups_for_step(sc, [], business_mode=False))
    deps0 = _dep_vars_for_step(scaffold_steps[0], []) if scaffold_steps else []

    summary = SetterSummary(
        variable_business_name=root_variable,
        what_it_is=f"Structural view of {root_variable} — raw facts, no AI narration.",
        what_its_set_to=set_to,
        condition_groups=all_groups,
        dependent_variables=deps0,
        total_conditions=int(cov.get("distinct_condition_count", 0) or 0),
        total_dependent_variables=int(cov.get("distinct_dep_count", 0) or 0),
        total_caller_files=int(cov.get("distinct_caller_files", 0) or 0),
        total_caller_sites=int(cov.get("raw_caller_count", 0) or 0),
        max_caller_depth=int(cov.get("max_caller_depth", 0) or 0),
    ).model_dump()

    return {
        "summary": summary,
        "steps": steps,
        "graph": reasoning.get("graph"),
        "coverage": cov,
        "paths": reasoning.get("paths") or [],
        "partial": False,
    }


def _make_step_builder(root_variable: str, total: int, business_mode: bool,
                       step_sys: str, call_llm_model: Callable[..., Any], variant: str):
    """Return a ``_build_one_step(i, sc) -> (i, SetterStep, raw_dict)`` closure.

    The closure runs in worker threads → it MUST NOT touch any DB session; it
    only calls the (blocking, thread-safe) ``call_llm_model``.
    """
    def _build_one_step(i: int, sc: Dict[str, Any]):
        """Explain one scaffold step, paginating if conditions/deps are large.

        Large steps (e.g. the setter step with 68 conditions + 89 deps) are split
        into multiple LLM calls — each covering a batch — and their condition/dep
        phrasings are merged so EVERY item gets a plain-English description without
        the prompt growing large enough to time out.
        """
        try:
            # Collect all conditions and deps from this step.
            all_conds_by_origin: Dict[str, List] = {}
            for origin, conds in (sc.get("conditions") or {}).items():
                conds = [c for c in conds if (c.get("expression") or c.get("raw"))]
                if conds:
                    all_conds_by_origin[origin] = conds
            all_deps = [d for d in (sc.get("deps") or []) if d.get("name")]

            # Determine if we need batching (any origin > BATCH or deps > BATCH).
            needs_batch = (
                any(len(v) > _COND_BATCH_SIZE for v in all_conds_by_origin.values())
                or len(all_deps) > _DEP_BATCH_SIZE
            )

            if not needs_batch:
                # Single call — fast path.
                prompt = _build_setter_step_prompt(sc, root_variable, business_mode)
                exp: StepExplanation = call_llm_model(prompt, StepExplanation, system_prompt=step_sys)
                merged_exp_d = exp.model_dump()
            else:
                # Paginated path: split large condition/dep lists into batches,
                # make one call per batch, merge phrasings by expression text / name.
                merged_conds: List = []
                merged_deps: List = []

                # Batch conditions per origin.
                for origin, conds in all_conds_by_origin.items():
                    for batch_start in range(0, len(conds), _COND_BATCH_SIZE):
                        batch = conds[batch_start: batch_start + _COND_BATCH_SIZE]
                        sc_batch = dict(sc)
                        sc_batch["conditions"] = {origin: batch}
                        sc_batch["deps"] = []
                        prompt = _build_setter_step_prompt(sc_batch, root_variable, business_mode)
                        try:
                            r = call_llm_model(prompt, StepExplanation, system_prompt=step_sys)
                            merged_conds.extend(r.model_dump().get("conditions") or [])
                        except Exception as be:
                            logger.debug("batch cond call failed: %s", be)

                # Batch deps.
                first_exp_d: Dict = {}
                for batch_start in range(0, len(all_deps), _DEP_BATCH_SIZE):
                    batch = all_deps[batch_start: batch_start + _DEP_BATCH_SIZE]
                    sc_batch = dict(sc)
                    sc_batch["conditions"] = {}
                    sc_batch["deps"] = batch
                    prompt = _build_setter_step_prompt(sc_batch, root_variable, business_mode)
                    try:
                        r = call_llm_model(prompt, StepExplanation, system_prompt=step_sys)
                        rd = r.model_dump()
                        merged_deps.extend(rd.get("dependent_variables") or [])
                        if not first_exp_d:
                            first_exp_d = rd  # headline / narrative from the first call
                    except Exception as be:
                        logger.debug("batch dep call failed: %s", be)

                # If no dep batches, get headline/narrative from a small conditions call.
                if not first_exp_d and merged_conds:
                    sc_small = dict(sc)
                    sc_small["conditions"] = {k: v[:5] for k, v in all_conds_by_origin.items()}
                    sc_small["deps"] = []
                    try:
                        r = call_llm_model(
                            _build_setter_step_prompt(sc_small, root_variable, business_mode),
                            StepExplanation, system_prompt=step_sys)
                        first_exp_d = r.model_dump()
                    except Exception:
                        pass

                merged_exp_d = first_exp_d or {}
                merged_exp_d["conditions"] = merged_conds
                merged_exp_d["dependent_variables"] = merged_deps

            step = SetterStep(
                index=int(sc.get("index", i)),
                total_steps=total,
                kind=str(sc.get("kind", "setter_site")),
                headline=merged_exp_d.get("headline") or "",
                file_stem=str(sc.get("file_stem") or ""),
                file_type=str(sc.get("file_type") or "asm"),
                variable_in_step=str(sc.get("variable_in_step") or root_variable),
                phase_label=str(sc.get("phase_label") or ""),
                caller_depth=int(sc.get("caller_depth", 0)),
                parent_index=sc.get("parent_index"),
                why_we_are_here=str(sc.get("why_we_are_here") or ""),
                explanation=merged_exp_d.get("narrative") or "",
                condition_groups=_condition_groups_for_step(sc, merged_exp_d.get("conditions") or [], business_mode),
                dependent_variables=_dep_vars_for_step(sc, merged_exp_d.get("dependent_variables") or []),
                source=_source_for_step(sc, business_mode),
                warnings=list(sc.get("notes") or []),
            )
            return i, step, merged_exp_d
        except Exception as exc:
            logger.warning(
                "setter step %d/%d (%s) LLM failed: %s — using fallback", i + 1, total, variant, exc
            )
            return i, _fallback_step(sc, business_mode), {}
    return _build_one_step


def _reasoning_over(reasoning: Dict[str, Any], scaffold_steps: List[Dict[str, Any]]) -> Dict[str, Any]:
    """A shallow copy of ``reasoning`` whose ``steps`` are the given subset.

    Used to synthesise a RUNNING summary over only the steps explained so far,
    while keeping the full ``coverage`` totals so partial summaries still state
    the true scale (nothing reads complete when it isn't)."""
    r = dict(reasoning)
    r["steps"] = list(scaffold_steps)
    return r


def explain_setter_root_progressive(
    structural: Dict[str, Any],
    *,
    variable: str,
    root: Dict[str, Any],
    business_mode: bool,
    kb_id: str = "",
    on_band: Optional[Callable[[Dict[str, Any]], None]] = None,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    band_size: Optional[int] = None,
    resume_steps: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Explain ONE setter site PROGRESSIVELY, in bands of ``band_size`` steps.

    The scaffold steps are already ordered setter→deps→callers (closest-first).
    They are split into BANDS of ``band_size`` consecutive steps (chunks, NOT by
    depth — depth can be 59 with only a handful of files). For each band:

    1. its steps are explained IN PARALLEL (thread pool over ``call_llm_model``);
    2. a RUNNING summary is synthesised over everything explained so far (1 call);
    3. ``on_band(partial_payload)`` is fired so the caller can persist + stream it.

    After the last band, a FULL end-to-end synthesis runs over ALL steps and the
    FINAL payload is returned (``partial=False``).

    Thread-safety: ``on_band`` and ``progress_cb`` run ONLY on this (main) thread;
    worker threads only call ``call_llm_model``. The caller's DB session is thus
    never touched off-thread.

    ``progress_cb(done, total, label)`` reports LLM calls completed within THIS
    variant; ``total`` matches ``plan_llm_calls(...)`` (steps + running summaries
    + final). Returns a dict validating as ``api.schemas.setter_analysis.ProsePayload``.
    """
    import os
    from concurrent.futures import ThreadPoolExecutor, as_completed

    from process_analysis.backend.llm import call_llm_model

    root_variable = (variable or (root or {}).get("variable") or "").upper()
    reasoning = build_setter_reasoning(structural, root_variable)
    scaffold_steps = reasoning.get("steps") or []
    total = len(scaffold_steps)
    graph = reasoning.get("graph")
    coverage = reasoning.get("coverage") or {}
    variant = "business" if business_mode else "technical"

    bs = band_size if band_size else _default_band_size()
    n_bands = _n_bands(total, bs)
    total_calls = total + n_bands + 1  # steps + running summaries + final synthesis

    step_sys = _PURE_BUSINESS_SYSTEM_PROMPT if business_mode else _BUSINESS_SYSTEM_PROMPT
    synth_sys = _PURE_BUSINESS_SYNTHESIS_PROMPT if business_mode else _SYNTHESIS_SYSTEM_PROMPT

    done = {"n": 0}

    def _progress(label: str) -> None:
        if progress_cb:
            try:
                progress_cb(int(done["n"]), int(total_calls), label)
            except Exception:
                pass

    try:
        max_workers = int(os.getenv("SETTER_ANALYSIS_STEP_CONCURRENCY", "8"))
    except ValueError:
        max_workers = 8

    build_one_llm = _make_step_builder(root_variable, total, business_mode, step_sys, call_llm_model, variant)

    # RESUME: reuse already-generated steps (from a prior partial payload) instead
    # of re-calling the LLM — so a worker that was killed mid-run picks up from the
    # last completed band rather than restarting from step 0.
    resume_by_index: Dict[int, Dict[str, Any]] = {}
    for s in (resume_steps or []):
        if isinstance(s, dict) and s.get("index") is not None:
            resume_by_index[int(s["index"])] = s

    def build_one(idx: int, sc: Dict[str, Any]):
        cached = resume_by_index.get(int(sc.get("index", idx)))
        if cached:
            try:
                step = SetterStep(**cached)
                # Reconstruct a minimal raw explanation for the synthesis context.
                exp_d = {
                    "headline": cached.get("headline", ""),
                    "narrative": cached.get("explanation", ""),
                    "conditions": [], "dependent_variables": [],
                }
                return idx, step, exp_d
            except Exception:
                pass  # fall through to a fresh LLM build on any reconstruction issue
        return build_one_llm(idx, sc)

    # ----- Variable definition facts (filled with meaning after first summary) -
    vd_facts = build_variable_definition_facts(structural, root_variable)

    def _variable_definition(summary: SetterSummary) -> Dict[str, Any]:
        return VariableDefinition(
            variable=root_variable,
            business_name=summary.variable_business_name,
            what_it_is=summary.what_it_is,
            declaration_file="" if business_mode else vd_facts.get("declaration_file", ""),
            declaration_line=0 if business_mode else int(vd_facts.get("declaration_line", 0)),
            data_type="" if business_mode else vd_facts.get("data_type", ""),
            role=vd_facts.get("role", ""),
        ).model_dump()

    steps_done: List[SetterStep] = []
    scaffold_done: List[Dict[str, Any]] = []
    raw_done: List[Dict[str, Any]] = []

    # Split the ordered scaffold into consecutive bands (chunks, not by depth).
    bands: List[List[int]] = [list(range(s, min(s + bs, total))) for s in range(0, total, bs)] or [[]]

    for k, band_indices in enumerate(bands):
        band_scaffold = [scaffold_steps[i] for i in band_indices]
        # Explain this band's steps in parallel; collect on the main thread.
        if band_scaffold:
            mw = max(1, min(max_workers, len(band_scaffold)))
            local: List[Optional[tuple]] = [None] * len(band_scaffold)
            with ThreadPoolExecutor(max_workers=mw) as ex:
                futures = {ex.submit(build_one, idx, sc): pos
                           for pos, (idx, sc) in enumerate(zip(band_indices, band_scaffold))}
                for fut in as_completed(futures):
                    pos = futures[fut]
                    local[pos] = fut.result()
                    done["n"] += 1
                    res = local[pos]
                    _progress(f"step {done['n']}/{total}: {res[1].file_stem}")
            # Append in scaffold order (stable thread for parent_index links).
            for res in local:
                if res is None:
                    continue
                _i, step, exp_d = res
                steps_done.append(step)
                scaffold_done.append(scaffold_steps[_i])
                raw_done.append(exp_d)

        # Running summary over everything explained so far (one call).
        running_reasoning = _reasoning_over(reasoning, scaffold_done)
        running_summary = _synthesise(
            root_variable, running_reasoning, raw_done, business_mode, synth_sys, call_llm_model
        )
        done["n"] += 1
        _progress(f"running summary (band {k + 1}/{n_bands})")

        is_final_band = (k == len(bands) - 1)
        if on_band and not is_final_band:
            partial_payload = {
                "summary": running_summary.model_dump(),
                "steps": [s.model_dump() for s in steps_done],
                "graph": graph,
                "variable_definition": _variable_definition(running_summary),
                "coverage": coverage,
                "paths": reasoning.get("paths") or [],   # enriched only in the final payload
                "partial": True,
                "bands_done": k + 1,
                "bands_total": n_bands,
            }
            try:
                on_band(partial_payload)
            except Exception:
                logger.exception("setter_analysis on_band callback failed (band %d/%d)", k + 1, n_bands)

    # ----- Final end-to-end synthesis over ALL steps (one call) -----------
    final_summary = _synthesise(
        root_variable, reasoning, raw_done, business_mode, synth_sys, call_llm_model
    )
    done["n"] += 1
    _progress("final summary")

    _progress("explaining paths")
    enriched_paths = _explain_paths(
        reasoning.get("paths") or [], root_variable, business_mode, call_llm_model
    )
    done["n"] += len([p for p in (reasoning.get("paths") or []) if p.get("conditions")])

    return {
        "summary": final_summary.model_dump(),
        "steps": [s.model_dump() for s in steps_done],
        "graph": graph,
        "variable_definition": _variable_definition(final_summary),
        "coverage": coverage,
        "paths": enriched_paths,
        "partial": False,
        "bands_done": n_bands,
        "bands_total": n_bands,
    }


def _build_path_prompt(
    path: Dict[str, Any],
    root_variable: str,
    business_mode: bool,
) -> str:
    """One focused prompt for one alternative entry→setter path."""
    files = path.get("files") or []
    entry = files[0] if files else "?"
    setter = files[-1] if files else "?"
    route = " → ".join(files)
    conds = [c for c in (path.get("conditions") or []) if (c.get("expression") or c.get("raw"))]

    if business_mode:
        cond_block = "\n".join(
            f"  {i+1}. {c.get('expression') or c.get('raw')}"
            for i, c in enumerate(conds)
        ) or "  (no specific conditions recorded for this path)"
        return (
            f"This is ONE of the alternative paths that leads to '{root_variable}' being set.\n"
            f"Path: {route}\n"
            f"Entry point: {entry} (the first program in this call chain)\n"
            f"Setter: {setter} (the program that sets the value)\n\n"
            f"These conditions ALL had to be true for the system to take this path "
            f"(AND semantics — every one of them must hold):\n{cond_block}\n\n"
            "YOUR TASK:\n"
            "1. Write a single `narrative` — 2-4 plain-business sentences explaining what had to be "
            "true for the transaction to travel this route. Name the business checks and decisions in "
            "plain English (no code, no file stems, no opcodes). Frame it as: "
            "'For the transaction to reach the setter via this path, the system had to determine that…'\n"
            "2. For EACH condition in the numbered list, fill `in_plain_terms` (what business decision "
            "it represents, including the specific value) and `decides` (what each outcome means).\n"
            "Reply as JSON: {\"narrative\": \"...\", \"conditions\": [{\"expression\": \"<exact expression from list>\", "
            "\"in_plain_terms\": \"...\", \"decides\": \"...\"}]}"
        )
    else:
        cond_block = "\n".join(
            f"  {i+1}. {c.get('expression') or c.get('raw')}"
            for i, c in enumerate(conds)
        ) or "  (no specific conditions recorded)"
        return (
            f"Path to setter '{root_variable}': {route}\n"
            f"Conditions (all must hold):\n{cond_block}\n\n"
            "Reply as JSON: {\"narrative\": \"<2-3 technical sentences summarising the guard chain>\", "
            "\"conditions\": [{\"expression\": \"<exact>\", \"in_plain_terms\": \"...\", \"decides\": \"...\"}]}"
        )


def _explain_paths(
    paths: List[Dict[str, Any]],
    root_variable: str,
    business_mode: bool,
    call_llm_fn: Callable,
) -> List[Dict[str, Any]]:
    """Make one LLM call per path IN PARALLEL — each gets a business-language narrative
    and per-condition in_plain_terms.  Paths without conditions skip the LLM call.
    Falls back gracefully on failure (leaves raw expressions, no crash)."""
    import json as _json
    from concurrent.futures import ThreadPoolExecutor, as_completed

    def _explain_one(i: int, path: Dict[str, Any]):
        conds = [c for c in (path.get("conditions") or []) if (c.get("expression") or c.get("raw"))]
        if not conds:
            return i, path  # nothing to enrich
        try:
            prompt = _build_path_prompt(path, root_variable, business_mode)
            raw = call_llm_fn(prompt)
            text = (raw or "").strip()
            if text.startswith("```"):
                text = text.split("```")[1]
                if text.startswith("json"):
                    text = text[4:]
                text = text.strip()
            result = _json.loads(text)
        except Exception as exc:
            logger.debug("path %d explanation failed: %s", i, exc)
            return i, path  # return unchanged on failure

        # Merge: narrative on path, in_plain_terms on each condition
        narrative = str(result.get("narrative") or "").strip()
        llm_conds: Dict[str, Dict] = {}
        for lc in (result.get("conditions") or []):
            key = str(lc.get("expression") or "").strip().lower()
            if key:
                llm_conds[key] = lc

        new_path = dict(path)
        if narrative:
            new_path["narrative"] = narrative
        new_conds = []
        for c in (path.get("conditions") or []):
            expr = (c.get("expression") or c.get("raw") or "").strip()
            lc = llm_conds.get(expr.lower(), {})
            nc = dict(c)
            if lc.get("in_plain_terms"):
                nc["in_plain_terms"] = lc["in_plain_terms"]
            if lc.get("decides"):
                nc["decides"] = lc["decides"]
            if business_mode:
                nc["check"] = ""  # hide raw code in business mode
            new_conds.append(nc)
        new_path["conditions"] = new_conds
        return i, new_path

    if not paths:
        return paths

    result_map: Dict[int, Dict] = {}
    with ThreadPoolExecutor(max_workers=min(8, len(paths))) as ex:
        futs = [ex.submit(_explain_one, i, p) for i, p in enumerate(paths)]
        for fut in as_completed(futs):
            try:
                idx, enriched = fut.result()
                result_map[idx] = enriched
            except Exception:
                pass

    return [result_map.get(i, paths[i]) for i in range(len(paths))]


def explain_setter_root(
    structural: Dict[str, Any],
    *,
    variable: str,
    root: Dict[str, Any],
    business_mode: bool,
    kb_id: str = "",
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
) -> Dict[str, Any]:
    """Explain ONE setter site for one prose variant (non-progressive convenience).

    Thin wrapper over ``explain_setter_root_progressive`` with ``on_band=None``:
    bands are still rendered + running-summarised internally (so progress is
    smooth), but only the FINAL payload is returned. Used by the route's lazy
    fallback path, whose signature it preserves.
    """
    return explain_setter_root_progressive(
        structural,
        variable=variable,
        root=root,
        business_mode=business_mode,
        kb_id=kb_id,
        on_band=None,
        progress_cb=progress_cb,
    )


def _synthesise(
    root_variable: str,
    reasoning: Dict[str, Any],
    raw_explanations: List[Dict[str, Any]],
    business_mode: bool,
    synth_sys: str,
    call_llm_model: Callable[..., Any],
) -> SetterSummary:
    prompt = _build_setter_synthesis_prompt(root_variable, reasoning, raw_explanations, business_mode)
    try:
        synth: SynthesisExplanation = call_llm_model(prompt, SynthesisExplanation, system_prompt=synth_sys)
        sd = synth.model_dump()
    except Exception as exc:
        logger.warning("setter synthesis (%s) failed: %s — using minimal summary", root_variable, exc)
        sd = {}

    # Assemble grouped condition subheadings (setter-local / per-caller / dep).
    condition_groups = _summary_condition_groups(reasoning, business_mode, raw_explanations)
    dep_vars = _summary_dep_vars(reasoning, sd, raw_explanations)
    cov = reasoning.get("coverage") or {}

    return SetterSummary(
        variable_business_name=str(sd.get("variable_business_name") or ""),
        what_it_is=str(sd.get("what_it_is") or ""),
        what_its_set_to=str(sd.get("how_it_is_set") or sd.get("how_is_set") or ""),
        conditions_overview=str(sd.get("what_had_to_be_true") or ""),
        condition_groups=condition_groups,
        dependent_variables_story=str(sd.get("dependent_variables_story") or ""),
        dependent_variables=dep_vars,
        chain_narrative=str(sd.get("chain_narrative") or ""),
        full_story=str(sd.get("full_story") or ""),
        total_conditions=_distinct_condition_total(reasoning),
        total_dependent_variables=int(cov.get("distinct_dep_count") or 0),
        total_caller_files=int(cov.get("distinct_caller_files") or 0),
        total_caller_sites=int(cov.get("raw_caller_count") or 0),
        max_caller_depth=int(cov.get("max_caller_depth") or 0),
    )


def _distinct_condition_total(reasoning: Dict[str, Any]) -> int:
    """Count distinct condition texts across ALL steps (the true total)."""
    seen: set = set()
    for s in reasoning.get("steps") or []:
        for _origin, conds in (s.get("conditions") or {}).items():
            for c in conds:
                expr = c.get("expression") or c.get("raw")
                if expr:
                    seen.add(_norm_text(expr))
    return len(seen)


def _summary_condition_groups(
    reasoning: Dict[str, Any],
    business_mode: bool,
    raw_explanations: Optional[List[Dict[str, Any]]] = None,
) -> List[ConditionGroup]:
    """The COMPLETE deduped conditions across all steps, grouped by origin.

    Built deterministically from the scaffold (every distinct condition).
    Enriched with LLM plain-English phrasings from ``raw_explanations`` (the
    step-level LLM results) using a normalised-text lookup — same pattern as
    ``_summary_dep_vars``.  This ensures the summary conditions panel is in
    business language even though it's rebuilt independently from the steps.
    """
    # Build lookup: norm_text → {in_plain_terms, decides} from step LLM output.
    ipt_lookup: Dict[str, Dict[str, str]] = {}
    for exp in (raw_explanations or []):
        for cond in (exp.get("conditions") or []):
            key = _norm_text(cond.get("check") or cond.get("in_plain_terms") or "")
            # Also index by check verbatim (the expression text in technical mode)
            check_key = _norm_text(cond.get("check") or "")
            ipt = str(cond.get("in_plain_terms") or "").strip()
            decides = str(cond.get("decides") or "").strip()
            for k in (key, check_key):
                if k and k not in ipt_lookup and (ipt or decides):
                    ipt_lookup[k] = {"in_plain_terms": ipt, "decides": decides}

    buckets: Dict[str, List[SetterConditionItem]] = {}
    seen: Dict[str, int] = {}
    locus: Dict[str, str] = {}
    for s in reasoning.get("steps") or []:
        for origin, conds in (s.get("conditions") or {}).items():
            arr = buckets.setdefault(origin, [])
            for c in conds:
                expr = c.get("expression") or c.get("raw")
                if not expr:
                    continue
                occ = int(c.get("occurrences") or 1)
                key = (origin, _norm_text(expr))
                if key in seen:
                    arr[seen[key]].occurrences += occ
                    continue
                seen[key] = len(arr)
                enrich = ipt_lookup.get(_norm_text(expr), {})
                arr.append(SetterConditionItem(
                    check=str(expr),   # always carry for matching; UI hides it in business mode
                    in_plain_terms=str(enrich.get("in_plain_terms") or ""),
                    decides=str(enrich.get("decides") or ""),
                    file_stem="" if business_mode else str(c.get("file_stem") or s.get("file_stem") or ""),
                    line=0 if business_mode else int(c.get("line") or 0),
                    occurrences=occ,
                ))
                if origin == ORIGIN_CALLER_CALL_CONDITION:
                    locus.setdefault(origin, str(s.get("file_stem") or ""))
    groups: List[ConditionGroup] = []
    for origin in (ORIGIN_SETTER_LOCAL, ORIGIN_CALLER_CALL_CONDITION, ORIGIN_DEPENDENT_VARIABLE):
        if origin in buckets:
            groups.append(ConditionGroup(
                origin=origin,
                heading=_ORIGIN_HEADINGS.get(origin, origin),
                where="" if business_mode else locus.get(origin, ""),
                conditions=buckets[origin],
            ))
    return groups


def _summary_dep_vars(
    reasoning: Dict[str, Any],
    synth: Dict[str, Any],
    raw_explanations: Optional[List[Dict[str, Any]]] = None,
) -> List[SetterDepVar]:
    """All dep vars from the scaffold, enriched with LLM business names + influence.

    Merges three sources:
    1. Scaffold raw facts (name, kind, constraint, relevance) — AUTHORITATIVE for completeness.
    2. Step-level LLM enrichment from ``raw_explanations`` (business_name, why_it_was_traced).
    3. Synthesis LLM output (variable_summary items) if present.
    """
    # Build lookup: normalized name → {business_name, why_it_matters} from step explanations.
    enrich: Dict[str, Dict[str, str]] = {}
    for exp in (raw_explanations or []):
        for dv in (exp.get("dependent_variables") or []):
            nm = str(dv.get("name") or "").upper()
            if nm and nm not in enrich:
                enrich[nm] = {
                    "business_name": str(dv.get("business_name") or ""),
                    "why_it_matters": str(dv.get("why_it_was_traced") or ""),
                }

    # Also pull from synthesis variable_summary if the LLM returned it.
    for row in (synth.get("variable_summary") or []):
        nm = str(row.get("variable") or "").upper()
        if nm and nm not in enrich:
            enrich[nm] = {
                "business_name": str(row.get("business_name") or ""),
                "why_it_matters": str(row.get("how_set") or ""),
            }

    out: List[SetterDepVar] = []
    seen: set = set()
    for s in reasoning.get("steps") or []:
        for d in (s.get("deps") or []):
            nm = str(d.get("name") or "")
            if not nm or nm.upper() in seen:
                continue
            seen.add(nm.upper())
            e = enrich.get(nm.upper(), {})
            out.append(SetterDepVar(
                name=nm,
                business_name=str(e.get("business_name") or ""),
                kind=str(d.get("kind") or ""),
                constraint=str(d.get("constraint") or ""),
                why_it_matters=str(e.get("why_it_matters") or ""),
                relevant=bool(d.get("relevant", True)),
                pruned_reason=str(d.get("pruned_reason") or ""),
                occurrences=int(d.get("occurrences") or 1),
            ))
    return out
