"""Variable lineage chatbot — answers follow-up questions about an explained variable.

Context assembled per turn (all in-memory from existing session files):
  1. All tuple_facts from the explain session (compact one-liners)
  2. All LLM explanations generated so far (plain-English narrative)
  3. Full conversation history (all prior turns in this chat session)

# TODO(vector-db): Replace _assemble_context() with vector DB retrieval once
#   embeddings are available. Each tuple's explanation, summary, and structured
#   facts should be stored as separate vectors with metadata:
#     {kb_id, backward_session_id, root_variable, file_stem, phase, artifact_type}
#   Query the user's message as the search vector, filter by
#   {kb_id, backward_session_id}, and retrieve top-K chunks by similarity.
#   This will scale to large sessions and enable cross-variable search.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import msgpack

from llm.caller import call_llm, stream_llm

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = (
    "You are answering follow-up questions about a mainframe variable's lineage for an "
    "ASM/mainframe engineer who needs to understand, navigate, and modify this codebase. "
    "You have access to a top-level synthesis, per-step explanations, and structured "
    "facts already generated for this variable, plus the full conversation history. "
    "Ground every answer in that context. Match the technical depth of the question: "
    "when asked about implementation, cite specific instruction mnemonics (OI, MVC, "
    "CLC, TM, etc.), operands and constants, line numbers, routine or function names, "
    "and branch conditions; when asked about business purpose or high-level flow, "
    "stay at that level. Prefer 3–6 sentences but expand for multi-part questions or "
    "when a structured list (e.g. enumerating gates or dep_vars) is clearly better. "
    "If the answer is not in the provided context, say so explicitly rather than "
    "guessing or fabricating instructions.\n\n"
    "When your answer references specific source lines, append a <source_refs> block "
    "after your answer in this exact format (one entry per line, nothing else inside "
    "the tags):\n"
    "<source_refs>\n"
    "filename.ext:start_line:end_line:brief label\n"
    "</source_refs>\n"
    "Only include lines you actually cited. Omit the block entirely if no specific "
    "source lines were referenced.\n\n"
    "COMPLETENESS: when you describe conditions or called processes, never gloss at a high level — "
    "the words 'a few', 'some', 'several', 'various', and 'a series of' are forbidden when the facts are "
    "available. Enumerate EVERY condition and name EVERY called routine/process specifically; never write "
    "'goes through a few checks' or 'calls some other processes and checks their success'."
)

# Business-persona chatbot — no assembly/code/file leakage; only the variable's own code in brackets.
_BUSINESS_CHAT_SYSTEM_PROMPT = (
    "You are answering follow-up questions about how a business data field gets its value inside a payment "
    "system, for a NON-TECHNICAL business reader. You have a top-level summary, per-step explanations, and "
    "structured facts for this variable, plus the conversation history. Ground every answer in that context; "
    "if the answer is not there, say so rather than guessing.\n\n"
    "BUSINESS-ONLY NAMING — the ONLY technical token allowed anywhere is the variable's own code name in "
    "parentheses after its business name (e.g. 'the Online Source Indicator (LG1OSI)'). Never mention file "
    "names/stems (refer to each program by a business name for what it does), routine names, opcodes, "
    "mnemonics, registers, hex, bits/bytes, or raw statements. Describe every action as a business operation. "
    "Keep concrete business VALUES (versions, return/status codes, counts, identifiers like 'C400').\n\n"
    "COMPLETENESS: never gloss at a high level — 'a few', 'some', 'several', 'various', 'a series of' are "
    "forbidden when the facts are available. Enumerate EVERY condition and name EVERY called program/operation "
    "by what it does; never 'goes through a few checks' or 'calls some other processes'.\n\n"
    "Do NOT emit a <source_refs> block (business readers don't use source lines). Be crisp — short bullet "
    "points where a list fits, one fact per bullet."
)


def _chat_system_prompt(business_mode: bool) -> str:
    return _BUSINESS_CHAT_SYSTEM_PROMPT if business_mode else _SYSTEM_PROMPT


_SOURCE_REFS_RE = __import__('re').compile(
    r'<source_refs>(.*?)</source_refs>', __import__('re').DOTALL | __import__('re').IGNORECASE
)


def _parse_source_refs(text: str):
    """Strip <source_refs> block from text and return (clean_text, refs list).

    Each ref: {file, line_start, line_end, label}
    Format inside block: filename.ext:start_line:end_line:label
    """
    match = _SOURCE_REFS_RE.search(text)
    refs = []
    if not match:
        return text, refs
    for line in match.group(1).strip().splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(':', 3)
        if len(parts) < 3:
            continue
        try:
            refs.append({
                'file':       parts[0].strip(),
                'line_start': int(parts[1].strip()),
                'line_end':   int(parts[2].strip()),
                'label':      parts[3].strip() if len(parts) > 3 else '',
            })
        except ValueError:
            continue
    return _SOURCE_REFS_RE.sub('', text).strip(), refs


# ---------------------------------------------------------------------------
# Session persistence
# ---------------------------------------------------------------------------

def _chat_session_path(kb_id: str, chat_session_id: str) -> Path:
    from api.config import settings
    d = settings.JOBS_BASE_DIR / kb_id / "output" / "chat_sessions"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{chat_session_id}.msgpack"


def load_chat_session(kb_id: str, chat_session_id: str) -> Optional[Dict[str, Any]]:
    path = _chat_session_path(kb_id, chat_session_id)
    if not path.exists():
        return None
    try:
        return msgpack.unpackb(path.read_bytes(), raw=False)
    except Exception:
        return None


def _save_chat_session(kb_id: str, session: Dict[str, Any]) -> None:
    path = _chat_session_path(kb_id, session["chat_session_id"])
    path.write_bytes(msgpack.packb(session, use_bin_type=True))


def create_chat_session(
    kb_id: str,
    backward_session_id: str,
    root_variable: str,
) -> Dict[str, Any]:
    """Create and persist a new chat session linked to a backward-lineage session."""
    session: Dict[str, Any] = {
        "version": 1,
        "chat_session_id": str(uuid.uuid4()),
        "backward_session_id": backward_session_id,
        "root_variable": root_variable.upper(),
        "messages": [],
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    _save_chat_session(kb_id, session)
    return session


# ---------------------------------------------------------------------------
# Context assembly
# ---------------------------------------------------------------------------

def _assemble_context(
    root_variable: str,
    selected_chain: List[str],
    explain_session: Optional[Dict[str, Any]],
) -> str:
    """Assemble grounding context from the explain session for the LLM.

    Includes all tuple_facts (compact one-liners) and all explanations generated
    so far. Both are already available in the explain session msgpack — no extra
    disk reads or LLM calls needed.

    # TODO(vector-db): Replace with a semantic retrieval call once embeddings
    #   are stored. Pass the user's question as the query; retrieve top-K chunks
    #   filtered by {kb_id, backward_session_id}. This function becomes a thin
    #   wrapper around the retrieval client.
    """
    chain_str = " → ".join(selected_chain) if selected_chain else "(chain unknown)"
    parts: List[str] = [
        f"VARIABLE: {root_variable}",
        f"LINEAGE CHAIN (entry point → setter): {chain_str}",
    ]

    if not explain_session:
        parts.append("\n(No explanations have been generated yet for this variable.)")
        return "\n".join(parts)

    tuple_facts:  Dict[str, str] = explain_session.get("tuple_facts") or {}
    explanations: Dict[str, str] = explain_session.get("explanations") or {}
    synthesis:    str            = (explain_session.get("synthesis") or "").strip()

    # Synthesis first — it's the highest-signal context block
    if synthesis:
        parts.append("UNIFIED SYNTHESIS (top-level end-to-end explanation):\n" + synthesis)

    if tuple_facts:
        fact_lines = ["STEP-BY-STEP FACTS (one line per file in the lineage):"]
        for i in sorted(int(k) for k in tuple_facts):
            fact_lines.append(f"  • Step {i}: {tuple_facts[str(i)]}")
        parts.append("\n".join(fact_lines))

    if explanations:
        expl_lines = ["EXPLANATIONS GENERATED SO FAR:"]
        for i in sorted(int(k) for k in explanations):
            expl_lines.append(f"[Step {i}]\n{explanations[str(i)]}")
        parts.append("\n\n".join(expl_lines))

    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

def _build_chat_prompt(
    question: str,
    messages: List[Dict[str, str]],
    context: str,
) -> str:
    """Combine grounding context, conversation history, and current question."""
    sections: List[str] = [context]

    if messages:
        history_lines = ["CONVERSATION HISTORY:"]
        for m in messages:
            label = "User" if m["role"] == "user" else "Assistant"
            history_lines.append(f"{label}: {m['content']}")
        sections.append("\n".join(history_lines))

    sections.append(f"CURRENT QUESTION:\n{question}")
    return "\n\n---\n\n".join(sections)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def answer_question_stream(
    kb_id: str,
    session: Dict[str, Any],
    question: str,
    explain_session: Optional[Dict[str, Any]],
    selected_chain: List[str],
    business_mode: bool = False,
):
    """Yield chatbot reply text chunks; persist the full turn on completion."""
    root_variable: str = session["root_variable"]
    messages: List[Dict[str, str]] = list(session.get("messages") or [])

    context = _assemble_context(root_variable, selected_chain, explain_session)
    prompt = _build_chat_prompt(question, messages, context)

    logger.info(
        "Streaming chat reply for %s (session %s, turn %d)",
        root_variable, session["chat_session_id"], len(messages) // 2 + 1,
    )

    full_text = ""
    for chunk in stream_llm(prompt, system_prompt=_chat_system_prompt(business_mode)):
        full_text += chunk
        yield chunk

    now = datetime.now(timezone.utc).isoformat()
    messages.append({"role": "user",      "content": question,   "timestamp": now})
    messages.append({"role": "assistant", "content": full_text,  "timestamp": now})
    session["messages"] = messages
    _save_chat_session(kb_id, session)


def answer_question_stream_v2(
    kb_id: str,
    session: Dict[str, Any],
    question: str,
    explain_session: Optional[Dict[str, Any]],
    selected_chain: List[str],
    user_msg_id: str,
    bot_msg_id: str,
    business_mode: bool = False,
):
    """Yield chatbot reply chunks with stable cm- msg_ids and proper persistence ordering.

    Pre-persists the user message before the first chunk is yielded so that
    GET /chatbot shows it immediately while the stream is in progress.
    The bot message is persisted once all chunks have been yielded.
    """
    root_variable: str = session["root_variable"]
    messages: List[Dict[str, str]] = list(session.get("messages") or [])

    context = _assemble_context(root_variable, selected_chain, explain_session)
    prompt = _build_chat_prompt(question, messages, context)

    logger.info(
        "Streaming chat reply for %s (session %s, turn %d)",
        root_variable, session["chat_session_id"], len(messages) // 2 + 1,
    )

    now = datetime.now(timezone.utc).isoformat()
    # Pre-persist user message before streaming begins
    messages.append({"role": "user", "content": question, "timestamp": now, "msg_id": user_msg_id})
    session["messages"] = messages
    _save_chat_session(kb_id, session)

    full_text = ""
    for chunk in stream_llm(prompt, system_prompt=_chat_system_prompt(business_mode)):
        full_text += chunk
        yield chunk

    # Strip <source_refs> from streamed text and store them separately
    clean_text, source_refs = _parse_source_refs(full_text)

    # Post-persist bot message with its stable msg_id
    messages.append({
        "role": "assistant",
        "content": clean_text,
        "timestamp": now,
        "msg_id": bot_msg_id,
        "source_refs": source_refs,
    })
    session["messages"] = messages
    _save_chat_session(kb_id, session)


def answer_question(
    kb_id: str,
    session: Dict[str, Any],
    question: str,
    explain_session: Optional[Dict[str, Any]],
    selected_chain: List[str],
    extra_context: str = "",
    business_mode: bool = False,
) -> str:
    """Generate a reply, persist the turn to the chat session, and return the reply."""
    root_variable: str = session["root_variable"]
    messages: List[Dict[str, str]] = list(session.get("messages") or [])

    context = _assemble_context(root_variable, selected_chain, explain_session)
    if extra_context:
        context = context + "\n\n" + extra_context
    prompt  = _build_chat_prompt(question, messages, context)

    logger.info(
        "Chat reply for %s (session %s, turn %d)",
        root_variable, session["chat_session_id"], len(messages) // 2 + 1,
    )
    reply = call_llm(prompt, system_prompt=_chat_system_prompt(business_mode))

    now = datetime.now(timezone.utc).isoformat()
    messages.append({"role": "user",      "content": question, "timestamp": now})
    messages.append({"role": "assistant", "content": reply,    "timestamp": now})
    session["messages"] = messages
    _save_chat_session(kb_id, session)
    return reply
