"""LLM prose layer for the chained multi-setter analysis (chain-files lineage).

Turns the deterministic ``chain_setter_orchestrator`` structural payload into the
frontend-shaped payload (the ChainSetterAnalysisView contract): per-field
``{b, t}`` variants, where ``b`` = business (LLM, plain English, ZERO technical
references) and ``t`` = technical (deterministic: raw conditions / enum values /
line numbers, minimal English).  The 3 UI modes render from this single payload:

  business        → ``b``, refs hidden
  business_refs   → ``b``, refs shown   (refs are structural data the UI toggles —
                    same business prose, so NOT a separate LLM generation)
  technical       → ``t``               (deterministic, no LLM)

Design rules (from project_chain_setter_ui_design memory):
  * business prose carries NO file/function/variable names, no enum/hex.
  * conditions are stated CONCRETELY (never "a prior error" — say which condition).
  * one CANONICAL business name per variable, reused everywhere on the page.
  * descriptions are detailed but in BULLETS.
  * minimise LLM calls; never dump the whole forest into one prompt — batch per setter.

Graceful degradation: if the LLM is unavailable or a call fails, ``b`` falls back
to the deterministic technical text so the API always returns a usable payload.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# LLM structured outputs (one call per setter; one call for canonical names)
# ---------------------------------------------------------------------------

class _NameItem(BaseModel):
    code: str = Field(description="the raw variable code / identifier")
    business_name: str = Field(description="a short, good plain-English business name (Title Case)")

class _NamesOut(BaseModel):
    names: List[_NameItem] = Field(default_factory=list)

class _CondPhrase(BaseModel):
    raw: str = Field(description="the raw condition text, copied VERBATIM from the list you were given (used only to line your answer up with the source — never shown to the reader)")
    plain: str = Field(description=(
        "the SAME condition stated in plain business English — a FAITHFUL, LITERAL restatement of "
        "exactly what the condition checks, nothing more. State the actual thing tested and the actual "
        "value it is tested against. NEVER guess what it means for the business beyond what the text "
        "literally says (never turn `flag == 'Y'` into 'the action was successful' unless the text names "
        "success). Keep the polarity (equals / does not equal / is present / is absent / is on / is off)."
    ))

class _DepOut(BaseModel):
    code: str
    context: str = Field(description="one sentence: how this input connects to the outcome and to the other inputs")
    role: List[str] = Field(default_factory=list, description="detailed bullets: what it is and the role it plays")
    set_logic: List[str] = Field(default_factory=list, description="bullets: how this input itself gets its value (empty if it is a terminal input)")

class _SetterProseOut(BaseModel):
    summary: List[str] = Field(default_factory=list, description="detailed bullets: what this outcome means and when it is recorded")
    value_plain: str = Field(default="", description="plain-English name of the value it is set to")
    table_rule: str = Field(default="", description="one concise readable sentence summarising the rule for the table")
    conditions: List[_CondPhrase] = Field(default_factory=list)
    dep_vars: List[_DepOut] = Field(default_factory=list)
    step_bullets: List[List[str]] = Field(default_factory=list, description="for each step (in order): detailed bullets in plain English")


_NAME_SYS = (
    "You name mainframe/credit-card processing variables in plain business English. "
    "Return a short, good Title-Case business name for each code. No code, no abbreviations "
    "unless they are the business term. Be specific and meaningful."
)
_SETTER_SYS = (
    "You explain how a value is set in a credit-card authorization system, for a BUSINESS "
    "audience. Use ONLY plain English — never mention file names, function names, variable "
    "codes, enum values, hex, or line numbers in the `plain` / business text. State every "
    "condition CONCRETELY: say exactly what must be true (never vague phrases like 'a prior "
    "error occurred' — say which check).\n\n"
    "FAITHFULNESS IS THE #1 RULE — phrase each condition as a LITERAL, FAITHFUL restatement of "
    "exactly what it checks, and NOTHING the condition does not state. You will be given each "
    "condition's raw text and the plain business names of the values it involves. Translate it "
    "mechanically, using these patterns:\n"
    "  • Comparison to a constant value (`X == 5`, `X = 'A'`): say \"<X's business name> equals "
    "<that value>\". For `!=` / `<>`: \"<X's business name> is not <that value>\". Always state the "
    "ACTUAL value being compared against, in plain words.\n"
    "  • A pointer / area / handle check (`area != 0`, `ptr != null`, `X is not null`): say "
    "\"<that area's business name> is present\" (or \"... is available\"). For `== 0` / `== null`: "
    "\"<that area> is not present\".\n"
    "  • A bitmask / flag test (`X & mask`, `TM X,mask`, an on/off bit): say \"<that flag/setting's "
    "business name> is turned on\" (or for the negated test, \"... is turned off\"). Do NOT invent "
    "what the flag means — just say the named flag is on or off.\n"
    "  • An enum / coded-value compare: state the ACTUAL value in plain words "
    "(\"<X> is set to <that value/state>\"), without inventing a meaning the code doesn't give.\n"
    "  • A range / magnitude test (`X > N`, `X <= N`): say \"<X> is greater than <N>\" / "
    "\"<X> is at most <N>\", keeping the actual number.\n"
    "  • A negation `!(...)` / `NOT(...)` / `BNE`: KEEP the polarity — restate the inner check and "
    "flip it (\"... is NOT the case that ...\").\n\n"
    "FORBIDDEN: inventing domain meaning that is not literally in the condition. Do NOT say a check "
    "means a transaction's origin, that a step 'succeeded', that something is 'valid', or any "
    "narrative the raw text does not state. If a condition compares a value named only by its code "
    "and you have no business name for it, describe it by its plain humanised name — never fabricate "
    "a business story. When unsure of meaning, restate the literal comparison and STOP.\n\n"
    "Be detailed; write in bullets. Keep each condition's plain phrasing a faithful restatement of "
    "its raw meaning, in business English, with NO variable codes, file names, or hex."
)


# ---------------------------------------------------------------------------
# Public entry
# ---------------------------------------------------------------------------

def explain_chain_setters(structural: Dict[str, Any]) -> Dict[str, Any]:
    """Build the frontend payload (b/t variants) from the structural result.

    ``structural`` is ``chain_setter_orchestrator.analyze_chain_setters`` output.
    Returns ``{business_name, chain, setters, variable_graph}`` matching the
    ChainSetterAnalysisView contract.
    """
    setters_in = structural.get("setters", [])
    variable = structural.get("variable", "")

    # 1) canonical business names: variable + every dep-var code (ONE batched call).
    codes = {variable}
    for s in setters_in:
        for d in s.get("dep_vars", []):
            codes.add(d.get("name", ""))
        for n in (s.get("variable_graph", {}) or {}).get("nodes", []):
            codes.add(n.get("id", ""))
    names = _canonical_names(sorted(c for c in codes if c))

    # 2) per setter: one LLM call → business prose; technical = deterministic.
    #    Parallelised: call_llm is thread-safe (singleton client + BoundedSemaphore
    #    capped at LLM_MAX_CONCURRENCY=6), so we can run up to 6 setter-prose calls
    #    concurrently.  With 23 setters @ ~60 s each, this cuts Phase B from ~23 min
    #    to ~4 min.  Results are collected by index to preserve the original order.
    from concurrent.futures import ThreadPoolExecutor, as_completed

    _workers = min(6, len(setters_in)) or 1
    with ThreadPoolExecutor(max_workers=_workers) as pool:
        futures = {pool.submit(_build_setter, i, s, names): i
                   for i, s in enumerate(setters_in, 1)}
        indexed: Dict[int, Dict[str, Any]] = {}
        for fut in as_completed(futures):
            idx = futures[fut]
            try:
                indexed[idx] = fut.result()
            except Exception:
                logger.warning("setter prose failed for setter #%d, using technical fallback", idx, exc_info=True)
                indexed[idx] = _build_setter(idx, setters_in[idx - 1], names)
    out_setters = [indexed[i] for i in sorted(indexed)]

    # variable graph from the (richest) first setter, labelled per mode.
    vg = (setters_in[0].get("variable_graph") if setters_in else {}) or {}
    graph = {
        "root": vg.get("root", variable),
        "nodes": [{"id": n.get("id"), "role": n.get("role", "input"),
                   "b": names.get(n.get("id"), n.get("id"))} for n in vg.get("nodes", [])],
        "edges": vg.get("edges", []),
    }

    return {
        "business_name": names.get(variable, variable),
        "variable_code": variable,
        "chain": structural.get("entry", {}),
        "setters": out_setters,
        "variable_graph": graph,
    }


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _llm():
    try:
        from process_analysis.backend.llm import call_llm_model
        return call_llm_model
    except Exception as exc:  # pragma: no cover
        logger.warning("LLM unavailable, degrading to deterministic text: %s", exc)
        return None


def _canonical_names(codes: List[str]) -> Dict[str, str]:
    call = _llm()
    if not call or not codes:
        return {c: _humanize(c) for c in codes}
    try:
        prompt = "Give a plain-English business name for each of these identifiers:\n" + \
                 "\n".join(f"- {c}" for c in codes)
        out: _NamesOut = call(prompt, _NamesOut, system_prompt=_NAME_SYS)
        m = {it.code: it.business_name for it in out.names if it.code}
        return {c: m.get(c) or _humanize(c) for c in codes}
    except Exception as exc:
        logger.warning("name generation failed: %s", exc)
        return {c: _humanize(c) for c in codes}


def _build_setter(sno: int, s: Dict[str, Any], names: Dict[str, str]) -> Dict[str, Any]:
    rule = s.get("rule", {})
    deps = s.get("dep_vars", [])
    steps = s.get("steps", [])
    prose: Optional[_SetterProseOut] = _setter_prose(s, names)

    # condition phrasing map: raw -> plain (business). Fallback: raw text.
    phr = {p.raw: p.plain for p in (prose.conditions if prose else [])}

    def leaf_bt(node: Dict[str, Any]) -> Dict[str, Any]:
        raw = node.get("text", "")
        return {"b": phr.get(raw, _soften(raw)), "t": raw, "vars": _vars_in(raw)}

    rule_bt = _rule_to_bt(rule, leaf_bt)

    dep_by_code = {d.code: d for d in (prose.dep_vars if prose else [])}
    dep_out = []
    for d in deps:
        code = d.get("name", "")
        pd = dep_by_code.get(code)
        setter = d.get("setter")
        # Build a meaningful role fallback from the conditions that reference
        # this dep-var — the condition text itself tells us what the variable does
        # even when the LLM had no domain knowledge for cryptic codes like @TPFCV09.
        role_b = pd.role if (pd and pd.role and any(len(r) > 20 for r in pd.role)) else None
        if not role_b:
            conds_for_dv = [str(c.get("text","")) for c in _all_condition_leaves(rule)
                            if code.upper() in str(c.get("text","")).upper()]
            if conds_for_dv:
                role_b = [f"Used in the condition: {conds_for_dv[0][:120]}"]
            else:
                role_b = None   # will be filtered on the frontend
        dep_out.append({
            "code": code, "name": names.get(code, _humanize(code)),
            "context": {"b": (pd.context if pd else ""), "t": _dep_context_t(d)},
            "role": {"b": role_b or [_humanize(code)],
                     "t": [f"{code}" + (f" — set at {setter['file']}:{setter['line']}" if setter else " — terminal input")]},
            "set_logic": {"b": (pd.set_logic if pd else []),
                          "t": ([f"set at {setter['file']}:{setter['line']} ({setter.get('routine','')})"] if setter else ["terminal input — set outside this chain"])},
            "set_rule": _dep_set_rule(d),
        })

    # steps: business bullets from prose; technical = raw file/role.
    step_bullets = (prose.step_bullets if prose else [])
    flows = [{
        "business_name": _humanize(s.get("function") or s.get("file")),
        "description": {"b": "Reached through the authorization flow to where the outcome is recorded.",
                        "t": " → ".join(st.get("file", "") for st in steps)},
        "long_description": {"b": "", "t": " → ".join(st.get("file", "") for st in steps)},
        "files": [st.get("file", "") for st in steps],
        "steps": [{
            "heading": {"b": (step_bullets[j][0] if j < len(step_bullets) and step_bullets[j] else _humanize(st.get("file"))),
                        "t": f"{st.get('file')} ({st.get('role')})"},
            "ref": f"{st.get('file')}",
            "body": {"b": (step_bullets[j] if j < len(step_bullets) else []),
                     "t": [f"{st.get('role')} step in {st.get('file')}"]},
            "conditions": [],
        } for j, st in enumerate(steps)],
    }]

    value_b = (prose.value_plain if prose and prose.value_plain else _humanize(s.get("value", "")))
    table_rule_b = (prose.table_rule if prose and prose.table_rule else "")
    # Deterministic fallback: when the LLM omits table_rule (common with 20+
    # conditions), synthesize from the already-phrased condition leaves + value.
    if not table_rule_b and prose:
        table_rule_b = _synthesize_table_rule_b(value_b, phr, rule)
    # Last resort: first summary bullet is a reasonable one-liner.
    if not table_rule_b and prose and prose.summary:
        table_rule_b = prose.summary[0]

    return {
        "sno": sno, "file": s.get("file"), "function": s.get("function"), "line": s.get("line"),
        "file_type": s.get("file_type"),
        "value": {"b": value_b,
                  "t": s.get("value", "")},
        "summary": {"b": (prose.summary if prose and prose.summary else [_humanize(s.get("value", ""))]),
                    "t": [f"Set to {s.get('value','')} at {s.get('file')}::{s.get('function')}:{s.get('line')}"]},
        "table_rule": {"b": table_rule_b,
                       "t": _rule_flat_t(rule)},
        "rule": rule_bt,
        "dep_vars": dep_out,
        "flows": flows,
    }


def _setter_prose(s: Dict[str, Any], names: Optional[Dict[str, str]] = None) -> Optional[_SetterProseOut]:
    call = _llm()
    if not call:
        return None
    names = names or {}

    def _name_hint(code: str) -> str:
        bn = names.get(code) or _humanize(code)
        return f"'{bn}'"

    def _cond_line(leaf: Dict[str, Any]) -> str:
        """One condition, with its raw text + the business names of the values it
        involves, so the LLM can phrase it FAITHFULLY (not guess domain meaning)."""
        raw = str(leaf.get("text", "")).strip()
        vs = _vars_in(raw)
        hints = ", ".join(f"{v} = {_name_hint(v)}" for v in vs)
        line = leaf.get("line")
        loc = f" [near line {line}]" if line else ""
        names_part = f"   (values involved: {hints})" if hints else ""
        return f"- raw condition: `{raw}`{loc}{names_part}"

    try:
        leaves = _all_condition_leaves(s.get("rule", {}))
        deps = [d.get("name", "") for d in s.get("dep_vars", [])]
        dep_hints = ", ".join(f"{d} = {_name_hint(d)}" for d in deps[:30] if d)
        steps = [f"{st.get('file')} ({st.get('role')})" for st in s.get("steps", [])]
        # The setter's source EXPRESSION grounds the value phrasing (what literally
        # gets written), so the LLM names the value faithfully rather than guessing.
        value_expr = str(s.get("value", "") or "(unknown)")
        prompt = (
            f"A value is set. The literal source expression assigned is: `{value_expr}`.\n"
            f"Give a faithful plain-English name for that value (what it literally is — do not "
            f"invent a business meaning the expression does not state).\n\n"
            f"It is recorded only when ALL of these raw conditions hold. For EACH one, return a "
            f"`plain` phrasing that is a FAITHFUL, LITERAL restatement of exactly what the raw "
            f"condition checks — using the business names given for the values, stating the actual "
            f"value compared against, and keeping the polarity. Do NOT invent meaning the condition "
            f"does not state. Copy the raw text VERBATIM into `raw` so it lines up:\n"
            + ("\n".join(_cond_line(l) for l in leaves[:40]) if leaves
               else "- (no gating conditions — the value is set unconditionally on this path)")
            + "\n\nDependent inputs (with their business names): " + (dep_hints or "(none)")
            + "\n\nProcessing steps (in order): " + (" ; ".join(steps) or "(none)")
            + "\n\nReturn ALL of the following (every field is REQUIRED — never leave any empty):\n"
              "1. `summary`: detailed bulleted summary of what this outcome means and when it is "
              "recorded (stated faithfully from the conditions, not invented).\n"
              "2. `value_plain`: a plain value name grounded in the source expression above.\n"
              "3. `table_rule`: ONE concise readable sentence (max ~40 words) that summarises "
              "WHEN this value is set — name the 2-3 most important conditions. This field is "
              "MANDATORY; it appears as the single-line summary in the table view.\n"
              "4. `conditions`: the faithful plain phrasing of EACH condition (one per raw "
              "condition listed above — same count).\n"
              "5. `dep_vars`: for each input its context/role/how-it-is-set bullets.\n"
              "6. `step_bullets`: per step, detailed plain-English bullets."
        )
        return call(prompt, _SetterProseOut, system_prompt=_SETTER_SYS)
    except Exception as exc:
        logger.warning("setter prose failed for %s:%s: %s", s.get("file"), s.get("line"), exc)
        return None


def _rule_to_bt(node: Dict[str, Any], leaf_bt) -> Dict[str, Any]:
    if node.get("op"):
        return {"op": node["op"], "label": node.get("label", ""),
                "items": [_rule_to_bt(it, leaf_bt) for it in node.get("items", [])]}
    return leaf_bt(node)


def _dep_set_rule(d: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    conds = d.get("conditions") or []
    if not conds:
        return None
    return {"op": "AND", "label": {"b": "It is set only when", "t": "Set when"},
            "items": [{"b": _soften(c), "t": c, "vars": _vars_in(c)} for c in conds]}


# --- deterministic / fallback text -----------------------------------------

import re as _re

def _vars_in(raw: str) -> List[str]:
    return _re.findall(r"[A-Za-z_@][A-Za-z0-9_.:>-]{2,}", str(raw))[:4]

def _all_condition_texts(node: Dict[str, Any]) -> List[str]:
    out: List[str] = []
    if node.get("op"):
        for it in node.get("items", []):
            out.extend(_all_condition_texts(it))
    elif node.get("text"):
        out.append(node["text"])
    return out

def _all_condition_leaves(node: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Flatten the boolean rule tree to its leaf condition nodes (each carries
    ``text`` + optional ``line``/``opcode``/``file`` from the structural payload),
    so the LLM gets per-condition context for faithful phrasing."""
    out: List[Dict[str, Any]] = []
    if node.get("op"):
        for it in node.get("items", []):
            out.extend(_all_condition_leaves(it))
    elif node.get("text"):
        out.append(node)
    return out

def _rule_flat_t(node: Dict[str, Any]) -> str:
    if node.get("op"):
        sep = f" {node['op']} "
        inner = sep.join(_rule_flat_t(it) for it in node.get("items", []) if _rule_flat_t(it))
        return f"({inner})" if node["op"] == "OR" else inner
    return node.get("text", "")

def _dep_context_t(d: Dict[str, Any]) -> str:
    s = d.get("setter")
    return (f"Set at {s['file']}:{s['line']}." if s else "Terminal input (set outside this chain).")

def _synthesize_table_rule_b(
    value_b: str,
    phr: Dict[str, str],
    rule: Dict[str, Any],
) -> str:
    """Build a table_rule business sentence from already-phrased conditions.

    Called when the LLM returned prose for everything else but left table_rule
    empty (common when there are 20+ conditions — the model skips the field).
    Uses the business-phrased condition map ``phr`` that was already built from
    the LLM's ``conditions`` output, so the sentence is still LLM-quality text.
    """
    leaves = _all_condition_leaves(rule)
    phrased = [phr.get(l.get("text", ""), "").strip() for l in leaves]
    phrased = [p for p in phrased if p]
    if not phrased:
        return ""
    # Pick the first 3 most meaningful conditions (skip very short ones
    # like single-word flags — prefer the ones with real comparisons).
    ranked = sorted(phrased, key=lambda p: len(p), reverse=True)
    pick = ranked[:3]
    rest = len(phrased) - len(pick)
    cond_text = "; ".join(pick)
    tail = f"; plus {rest} additional conditions" if rest > 0 else ""
    return f"Set to '{value_b}' when: {cond_text}{tail}."


def _soften(raw: str) -> str:
    return str(raw)

def _humanize(code: str) -> str:
    c = str(code or "").split("::")[-1].split(".")[-1].lstrip("@")
    c = _re.sub(r"(?<=[a-z])(?=[A-Z])", " ", c)
    return c.replace("_", " ").strip().title() or str(code)
