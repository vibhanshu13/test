"""Deterministic reasoning scaffold for Setter Analysis (NO LLM).

Setter Analysis explains, for ONE setter site (``root``), every condition that
had to be true to set the value there — walking outward from the setter through
its local guards, its dependent variables, and the whole caller tree (each
caller carrying its own call-conditions).  This module turns the raw structural
tuple produced by ``process_single_root`` into an ordered, *connected* step plan
that the LLM explainer (``setter_analysis_explainer.py``) only has to phrase.

It is the analogue of ``lineage_reasoning.build_step_reasoning`` for the
chainless setter-centric view: pure data shaping, no model calls, no I/O.

The structural tuple (``process_single_root`` shape) we consume::

    {
      "root_id": str,
      "node": {file_stem, file_type, variable, line, instruction, role,
               conditions, relevant_lines, warnings},
      "conditions": [guard dict ...],          # setter-local guards
      "deps": [DepVar dict ...],               # dependent variables
      "caller_keys": [str ...],
      "callers": [CallerNode dict ...],        # FLAT list; tree via child_keys
      "downstream": [str ...],
      "truncated": bool,
      "warnings": [str ...],
    }

A guard-condition dict typically has keys like ``file`` / ``line`` / ``scope`` /
``expression`` / ``raw`` (best-effort — we read several aliases).  A caller's
``call_sites`` entries typically carry ``routine`` / ``line`` / ``instruction``
/ ``raw_line`` and (for C++) optional ``conditions``.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

# Origins (must match api.schemas.setter_analysis.ConditionGroup.origin)
ORIGIN_SETTER_LOCAL = "setter_local"
ORIGIN_CALLER_CALL_CONDITION = "caller_call_condition"
ORIGIN_DEPENDENT_VARIABLE = "dependent_variable"

# NO bounds. Completeness is the priority: every DISTINCT condition, dependent
# variable and caller FILE is kept (deduped, never truncated). Volume is handled
# at GENERATION time by the progressive/banded explainer (depth band 0, then 1,
# then 2, … — each band is rendered + summarised as it finishes and streamed to
# the UI), and a full end-to-end summary is produced at the end. So the user is
# never stuck waiting for a huge forest, yet nothing is dropped. Deduping callers
# by file is correctness (collapsing a path-exploded edge list), not a cap.


def _dedupe_conditions(conds: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Collapse conditions by their expression text; keep ALL distinct ones.

    Returns each distinct condition once with an ``occurrences`` count (how many
    raw guard sites shared that text). No truncation."""
    out: List[Dict[str, Any]] = []
    seen: Dict[str, int] = {}
    for c in conds:
        key = (c.get("expression") or c.get("raw") or "").strip().lower()
        if not key:
            continue
        if key in seen:
            out[seen[key]]["occurrences"] += 1
            continue
        seen[key] = len(out)
        d = dict(c)
        d["occurrences"] = 1
        out.append(d)
    return out


def _dedupe_deps(deps: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Collapse dependent variables by name; keep ALL distinct ones.

    Prefers a relevant/constrained record over a pruned/bare one when merging
    duplicates; carries an ``occurrences`` count. No truncation."""
    out: List[Dict[str, Any]] = []
    seen: Dict[str, int] = {}
    for d in deps:
        key = (d.get("name") or "").strip().upper()
        if not key:
            continue
        if key in seen:
            cur = out[seen[key]]
            cur["occurrences"] += 1
            # Prefer the more-informative record (relevant + has a constraint).
            if (not cur.get("relevant") and d.get("relevant")) or (
                not cur.get("constraint") and d.get("constraint")
            ):
                occ = cur["occurrences"]
                nd = dict(d)
                nd["occurrences"] = occ
                out[seen[key]] = nd
            continue
        seen[key] = len(out)
        nd = dict(d)
        nd["occurrences"] = 1
        out.append(nd)
    return out


# ---------------------------------------------------------------------------
# Small extractors (defensive — the upstream dicts vary by file_type / bridge)
# ---------------------------------------------------------------------------

def _first(d: Dict[str, Any], *keys: str, default: Any = "") -> Any:
    for k in keys:
        if k in d and d[k] not in (None, ""):
            return d[k]
    return default


def _norm_condition(cond: Any) -> Dict[str, Any]:
    """Normalise a guard dict (or bare string) to a uniform raw-fact record."""
    if not isinstance(cond, dict):
        text = str(cond or "").strip()
        return {"raw": text, "expression": text, "file_stem": "", "line": 0, "scope": ""}
    raw = str(_first(cond, "raw", "expression", "raw_line", "text", "check") or "").strip()
    expr = str(_first(cond, "expression", "raw", "check", "text") or "").strip()
    return {
        "raw": raw,
        "expression": expr or raw,
        "file_stem": str(_first(cond, "file_stem", "file", "stem") or ""),
        "line": int(_first(cond, "line", default=0) or 0),
        "scope": str(_first(cond, "scope", "routine", "block_id") or ""),
    }


def _norm_dep(dep: Dict[str, Any]) -> Dict[str, Any]:
    """Normalise a DepVar dict to the raw facts the LLM phrases."""
    constraint = dep.get("constraint") or {}
    if not isinstance(constraint, dict):
        constraint = {}
    raw_c = str(_first(constraint, "raw", default="") or "")
    op = constraint.get("operator")
    const = constraint.get("constant")
    if not raw_c and (op or const):
        raw_c = f"{op or ''} {const or ''}".strip()
    return {
        "name": str(dep.get("name") or ""),
        "kind": str(dep.get("kind") or "data_flow"),
        "constraint": raw_c,
        "constraint_operator": op,
        "constraint_constant": const,
        "relevant": bool(dep.get("relevant", True)),
        "pruned_reason": str(dep.get("pruned_reason") or ""),
        "discovered_in_stem": str(dep.get("discovered_in_stem") or ""),
        "discovered_at_line": int(dep.get("discovered_at_line") or 0),
    }


def _dep_has_guard(dep: Dict[str, Any]) -> bool:
    """A dep that itself carries a constraint is eligible for its own step."""
    return dep.get("kind") == "conditional_guard" and bool(dep.get("constraint"))


def _call_site_conditions(site: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Conditions guarding a particular call site (C++ if-guards etc.)."""
    out: List[Dict[str, Any]] = []
    for c in (site.get("conditions") or site.get("conditional_context") or []):
        nc = _norm_condition(c)
        if nc["raw"] or nc["expression"]:
            out.append(nc)
    return out


def _call_site_brief(site: Dict[str, Any]) -> Dict[str, Any]:
    """One call-site's raw facts (line / instruction / source hint)."""
    return {
        "line": int(_first(site, "call_line", "line", default=0) or 0),
        "instruction": str(_first(site, "call_instruction", "instruction") or ""),
        "routine": str(_first(site, "routine", "scope", "block_id") or ""),
        "raw_line": str(_first(site, "raw_line", "raw") or ""),
        "call_type": str(_first(site, "call_type") or ""),
        "conditions": _call_site_conditions(site),
    }


# ---------------------------------------------------------------------------
# Public — variable definition facts (deterministic)
# ---------------------------------------------------------------------------

def build_variable_definition_facts(structural_tuple: Dict[str, Any], variable: str) -> Dict[str, Any]:
    """Deterministic facts for the shared VariableDefinition (LLM phrases meaning).

    Pulls declaration file/line, data_type and role from the setter node when
    present — anything absent is returned empty for the explainer to fill.
    """
    node = (structural_tuple or {}).get("node") or {}
    return {
        "variable": (variable or node.get("variable") or "").upper(),
        "declaration_file": str(node.get("file_stem") or ""),
        "declaration_line": int(node.get("line") or 0),
        "data_type": str(_first(node, "data_type", "type") or ""),
        "role": str(node.get("role") or ""),
        "file_type": str(node.get("file_type") or "asm"),
    }


# ---------------------------------------------------------------------------
# Public — the ordered, connected step plan
# ---------------------------------------------------------------------------

def build_setter_reasoning(structural_tuple: Dict[str, Any], variable: str) -> Dict[str, Any]:
    """Build an ordered, connected scaffold for ONE setter site.

    Returns ``{"variable", "root_id", "steps": [scaffold step dict], "warnings",
    "truncated", "graph": {nodes, edges}}``.  Each scaffold step is a flat dict
    of RAW facts (no prose) keyed for easy consumption by the explainer:

        {
          "index": int,
          "kind": "setter_site" | "caller_hop" | "dependent_variable",
          "caller_depth": int,            # 0 = setter site
          "parent_index": int | None,     # the step this one feeds into
          "phase_label": str,
          "file_stem": str, "file_type": str,
          "variable_in_step": str,
          "why_we_are_here": str,         # plain reason (the connecting thread)
          "origins": [origin ...],        # which ConditionGroup origins apply
          "setter": {instruction, role, raw, line} | None,
          "conditions": {origin: [normalised cond ...]},
          "deps": [normalised dep ...],
          "relevant_code_lines": str,     # source hint if the node carries one
          "notes": [str ...],             # indirection / virtual / truncation
        }
    """
    st = structural_tuple or {}
    node = st.get("node") or {}
    root_variable = (variable or node.get("variable") or "").upper()
    file_stem = str(node.get("file_stem") or "")
    file_type = str(node.get("file_type") or "asm")

    warnings: List[str] = list(st.get("warnings") or [])
    truncated = bool(st.get("truncated"))
    steps: List[Dict[str, Any]] = []

    # ----- Step 0: the setter site itself ---------------------------------
    # COMPLETE + deduped: every distinct setter-local condition and dependent
    # variable is kept (no cap), so the explainer/UI can show all of them.
    setter_conds_raw = [_norm_condition(c) for c in (st.get("conditions") or node.get("conditions") or [])]
    setter_conds_raw = [c for c in setter_conds_raw if c["raw"] or c["expression"]]
    setter_conds = _dedupe_conditions(setter_conds_raw)
    deps_raw = [_norm_dep(d) for d in (st.get("deps") or []) if isinstance(d, dict)]
    deps_all = _dedupe_deps(deps_raw)

    relevant_lines = ""
    rl = node.get("relevant_lines")
    if isinstance(rl, list) and rl:
        # node.relevant_lines is typically [{"count": N}] but may carry code.
        for item in rl:
            if isinstance(item, dict) and item.get("code"):
                relevant_lines = str(item["code"])
                break

    setter_origins = [ORIGIN_SETTER_LOCAL]
    if deps_all:
        setter_origins.append(ORIGIN_DEPENDENT_VARIABLE)

    steps.append({
        "index": 0,
        "kind": "setter_site",
        "caller_depth": 0,
        "parent_index": None,
        "phase_label": "Setter site",
        "file_stem": file_stem,
        "file_type": file_type,
        "variable_in_step": root_variable,
        "why_we_are_here": (
            f"This is where {root_variable} is written. "
            "Everything else is traced outward from this point."
        ),
        "origins": setter_origins,
        "setter": {
            "instruction": str(node.get("instruction") or ""),
            "role": str(node.get("role") or ""),
            "raw": str(_first(node, "setter_expression", "raw", "raw_line") or ""),
            "line": int(node.get("line") or 0),
        },
        "conditions": {ORIGIN_SETTER_LOCAL: setter_conds},
        "deps": deps_all,
        "condition_count": len(setter_conds),
        "raw_condition_count": len(setter_conds_raw),
        "dep_count": len(deps_all),
        "relevant_code_lines": relevant_lines,
        "notes": list(node.get("warnings") or []),
    })

    # File node index for the caller thread: file_stem -> step index that "lives"
    # in that file (so a caller of X points at the step whose file is X).
    file_to_step: Dict[str, int] = {file_stem: 0}

    # ----- Caller hops — DEDUPED BY FILE ----------------------------------
    # The structural `callers` list is per-edge and path-exploded (the same few
    # dozen files revisited across many depths). We aggregate by caller FILE so
    # the walk is one step per DISTINCT caller — no path explosion, no loss.
    callers: List[Dict[str, Any]] = list(st.get("callers") or [])
    raw_caller_count = len([c for c in callers if isinstance(c, dict)])
    max_caller_depth = 0

    by_stem: Dict[str, Dict[str, Any]] = {}
    for c in callers:
        if not isinstance(c, dict):
            continue
        stem = str(c.get("stem") or "")
        if not stem:
            continue
        depth = int(c.get("depth") or 1)
        max_caller_depth = max(max_caller_depth, depth)
        g = by_stem.setdefault(stem, {
            "stem": stem, "file_type": str(c.get("file_type") or "asm"),
            "callees": set(), "min_depth": depth, "max_depth": depth,
            "edges": 0, "call_sites": [], "conds_raw": [],
            "cycle": False, "indir": {}, "edge_kind": str(c.get("edge_kind") or ""),
        })
        g["callees"].add(str(c.get("callee_stem") or ""))
        g["min_depth"] = min(g["min_depth"], depth)
        g["max_depth"] = max(g["max_depth"], depth)
        g["edges"] += 1
        if c.get("cycle"):
            g["cycle"] = True
        ind = c.get("indirection") or {}
        if isinstance(ind, dict) and (ind.get("unresolved") or ind.get("is_virtual_dispatch")):
            g["indir"] = ind
        for site in (c.get("call_sites") or []):
            if isinstance(site, dict):
                brief = _call_site_brief(site)
                g["call_sites"].append(brief)
                g["conds_raw"].extend(brief["conditions"])

    distinct_caller_files = len(by_stem)
    # Closest-first so a caller's callee already has a step (clean parent thread).
    # NO cap — every distinct caller file becomes a step; the progressive
    # explainer renders them in depth bands so volume never blocks the user.
    ordered = sorted(by_stem.values(), key=lambda g: (g["min_depth"], g["stem"]))

    for g in ordered:
        stem = g["stem"]
        callees = sorted(x for x in g["callees"] if x)
        # Parent = the step of the closest callee that already has one.
        parent_index = 0
        best_idx: Optional[int] = None
        for callee in callees:
            si = file_to_step.get(callee)
            if si is not None and (best_idx is None or si < best_idx):
                best_idx = si
        if best_idx is not None:
            parent_index = best_idx

        call_conds = _dedupe_conditions(g["conds_raw"])

        notes: List[str] = []
        if g["cycle"]:
            notes.append("Cyclic caller edge — recursion stopped here to avoid looping.")
        indir = g["indir"] or {}
        if indir.get("unresolved"):
            notes.append(
                "Some call target(s) could not be statically resolved "
                f"(indirect via {indir.get('indirect_via') or 'a register/computed target'}); "
                "the path is surfaced but its exact origin is unknown."
            )
        if indir.get("is_virtual_dispatch"):
            notes.append(
                "Includes a virtual-dispatch call"
                + (f" (base class {indir.get('cha_base_class')})" if indir.get("cha_base_class") else "")
                + " — the concrete implementation is resolved by class hierarchy analysis."
            )

        callees_txt = ", ".join(callees) if callees else "the program below it"
        why = (
            f"{stem} calls {callees_txt} — this is how control reaches the setter "
            f"on the way to writing {root_variable}."
        )
        if call_conds:
            why += " The call itself happens only under the conditions listed for this step."

        idx = len(steps)
        steps.append({
            "index": idx,
            "kind": "caller_hop",
            "caller_depth": int(g["min_depth"] or 1),
            "depth_min": int(g["min_depth"] or 1),
            "depth_max": int(g["max_depth"] or 1),
            "parent_index": parent_index,
            "phase_label": "Caller",
            "file_stem": stem,
            "file_type": g["file_type"],
            "variable_in_step": root_variable,
            "why_we_are_here": why,
            "origins": [ORIGIN_CALLER_CALL_CONDITION],
            "setter": None,
            "conditions": {ORIGIN_CALLER_CALL_CONDITION: call_conds},
            "deps": [],
            "relevant_code_lines": "",
            "call_sites": g["call_sites"],
            "call_site_count": len(g["call_sites"]),
            "edge_count": g["edges"],
            "callees": callees,
            "edge_kind": g["edge_kind"],
            "cycle": g["cycle"],
            "indirection": dict(indir) if isinstance(indir, dict) else {},
            "notes": notes,
        })
        # This caller's own file now anchors any of ITS callers (the thread).
        file_to_step.setdefault(stem, idx)

    # NOTE: dependent variables are NOT promoted to individual LLM-narrated steps.
    # The COMPLETE deduped dep list already lives on the setter step (and is
    # explained in the summary's dependent_variables_story), so narrating ~60
    # deps as separate steps was pure cost with no added coverage. The step walk
    # is the setter site + the caller PATH walk; deps are a complete panel.

    # ----- Reindex + total + graph ----------------------------------------
    total = len(steps)
    for i, s in enumerate(steps):
        s["index"] = i
        s["total_steps"] = total

    graph = _build_graph(file_stem, root_variable, callers, deps_all)

    # Alternative entry→setter PATHS. The setter is reachable by several distinct
    # paths (A→B→C, D→C, …); satisfying ANY ONE of them reaches the setter (OR
    # across paths, AND of the call-conditions within a path). Enumerated bounded
    # to avoid path-explosion.
    paths, paths_capped, total_paths_seen, unverified_entries = _enumerate_paths(file_stem, callers)

    coverage = {
        "raw_condition_count": len(setter_conds_raw),
        "distinct_condition_count": len(setter_conds),
        "raw_dep_count": len(deps_raw),
        "distinct_dep_count": len(deps_all),
        "raw_caller_count": raw_caller_count,
        "distinct_caller_files": distinct_caller_files,
        "max_caller_depth": max_caller_depth,
        "total_steps": total,
        "distinct_paths": total_paths_seen,
        "paths_shown": len(paths),
        "paths_capped": paths_capped,
        "unverified_entries": unverified_entries,
    }

    return {
        "variable": root_variable,
        "root_id": str(st.get("root_id") or ""),
        "steps": steps,
        "warnings": warnings,
        "truncated": truncated,
        "graph": graph,
        "paths": paths,
        "coverage": coverage,
    }


def _enumerate_paths(
    setter_stem: str,
    callers: List[Dict[str, Any]],
    *,
    max_paths: int = 60,
    max_len: int = 16,
) -> tuple:
    """Enumerate distinct entry→setter paths (bounded).

    Returns ``(paths, capped, total_seen)`` where each path is
    ``{"files": [entry,…,setter], "length": int, "conditions": [deduped hop
    conds]}``. Edges are caller→callee (toward the setter); an "entry" is a
    caller file that nobody else calls. Simple paths only (no repeated file);
    bounded by ``max_paths`` so a dense forest can't explode.
    """
    if not setter_stem:
        return [], False, 0

    # Forward adjacency caller -> {callee}, plus per-edge call-conditions.
    #
    # ONLY verified edges (those with confirmed call sites) form paths.  A caller
    # node with no call_sites is either a cycle back-edge or an indirection the
    # bridge could not verify (register-indirect / computed target).  Weaving
    # those into "PATH N" chains fabricates control-flow paths that were never
    # confirmed to reach the setter (they inflated a handful of real paths into
    # hundreds).  They are surfaced separately as ``unverified_entries`` — never
    # silently dropped — so coverage stays honest.
    adj: Dict[str, set] = {}
    edge_conds: Dict[tuple, List[Dict[str, Any]]] = {}
    callees_seen: set = set()
    callers_seen: set = set()
    unverified: set = set()
    for c in callers:
        if not isinstance(c, dict):
            continue
        a = str(c.get("stem") or "")
        b = str(c.get("callee_stem") or "")
        if not a or not b:
            continue
        if not (c.get("call_sites") or []):
            # cycle marker or unresolved indirection — not a verified path edge
            if not c.get("cycle"):
                unverified.add(a)
            continue
        adj.setdefault(a, set()).add(b)
        callers_seen.add(a)
        callees_seen.add(b)
        conds: List[Dict[str, Any]] = []
        for site in (c.get("call_sites") or []):
            if isinstance(site, dict):
                conds.extend(_call_site_brief(site)["conditions"])
        if conds:
            edge_conds.setdefault((a, b), []).extend(conds)

    # Entries = caller files nobody calls (tops of the control-flow paths).
    entries = sorted(callers_seen - callees_seen)
    if not entries:
        # Cyclic / no clean tops — fall back to depth-1 callers as entries.
        entries = sorted({str(c.get("stem")) for c in callers
                          if isinstance(c, dict) and int(c.get("depth") or 0) == 1})

    paths: List[Dict[str, Any]] = []
    seen_sigs: set = set()
    total_seen = 0
    capped = False

    def dfs(node: str, trail: List[str], conds: List[Dict[str, Any]], visiting: set) -> None:
        nonlocal capped, total_seen
        if capped:
            return
        if len(trail) > max_len:
            return
        if node == setter_stem:
            total_seen += 1
            sig = tuple(trail)
            if sig not in seen_sigs:
                seen_sigs.add(sig)
                paths.append({
                    "files": list(trail),
                    "length": len(trail) - 1,
                    "conditions": _dedupe_conditions(conds),
                })
                if len(paths) >= max_paths:
                    capped = True
            return
        for nxt in sorted(adj.get(node, ())):
            if nxt in visiting:
                continue  # avoid cycles
            visiting.add(nxt)
            dfs(nxt, trail + [nxt],
                conds + edge_conds.get((node, nxt), []), visiting)
            visiting.discard(nxt)
            if capped:
                return

    for e in entries:
        if capped:
            break
        dfs(e, [e], [], {e})

    # Shortest paths first (most direct ways to reach the setter).
    paths.sort(key=lambda p: (p["length"], p["files"]))
    # Unverified caller candidates the bridge could not confirm (e.g. register-
    # indirect) — reported, not woven into the verified paths.
    return paths, capped, total_seen, sorted(unverified - callees_seen)


def _build_graph(
    setter_stem: str,
    variable: str,
    callers: List[Dict[str, Any]],
    deps: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """A small caller/dep graph for the UI right-rail (nodes + caller->callee edges)."""
    nodes: List[Dict[str, Any]] = []
    seen_nodes: set = set()

    def _add_node(node_id: str, label: str, kind: str) -> None:
        if node_id and node_id not in seen_nodes:
            seen_nodes.add(node_id)
            nodes.append({"id": node_id, "label": label, "kind": kind})

    _add_node(setter_stem or variable, setter_stem or variable, "setter")
    edges: List[Dict[str, Any]] = []
    for c in callers:
        if not isinstance(c, dict):
            continue
        stem = str(c.get("stem") or "")
        callee = str(c.get("callee_stem") or "")
        _add_node(stem, stem, "caller")
        _add_node(callee, callee, "caller")
        if stem and callee:
            edges.append({"source": stem, "target": callee, "kind": "calls"})
    for d in deps:
        nm = str(d.get("name") or "")
        if nm:
            _add_node(f"dep:{nm}", nm, "dependent_variable")
            edges.append({"source": f"dep:{nm}", "target": setter_stem or variable, "kind": "feeds"})
    return {"nodes": nodes, "edges": edges}
