"""Business-user variable lineage explainer.

Produces structured StepExplanation objects (pydantic) by feeding the
deterministic reasoning scaffold from lineage_reasoning.py to the LLM.
The LLM narrates a pre-reasoned scaffold — it cannot produce disconnected
or high-level output because the 'why' is handed to it explicitly.

Session persistence: msgpack under jobs/{kb_id}/output/lineage_explain_sessions/.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional

import msgpack

from api.schemas.lineage_explain import (
    BridgeExplanation,
    ConditionExplained,
    DepVarExplained,
    RollOutput,
    StatementExplained,
    StepExplanation,
    SynthesisExplanation,
    SynthesisSection,
)
from llm.lineage_reasoning import (
    build_step_fact,
    build_step_reasoning,
    render_step_mermaid,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# System prompts
# ---------------------------------------------------------------------------

_DESIGN_RULE = """THE ONE WRITING DESIGN — follow it for EVERY code reference, with no exceptions:
  • State the BUSINESS action and the MEANING of the assembly operation in your own words, in the sentence.
  • Then put the EXACT statement and the routine name in parentheses.
  • Format:  <business action> by <plain meaning of the operation> (statement: `EXACT CODE`, routine NAME).
  • Example: "The program switches the online-source indicator on by performing a logical OR that turns a
    single status bit on inside the byte (statement: `OI LG1OSI,LG#C400`, routine DA780000)."
  • NEVER mention line numbers anywhere in your prose — they are meaningless to a business reader. Cite the
    exact statement and the routine name only.
  • ALWAYS name a variable as its BUSINESS NAME FIRST, then its code name in parentheses, like
    "the Work Return Code (`WK_RRC`)" or "the Online Source Indicator (`LG1OSI`)".
    Never the business name alone, never the bare code name alone.
  • NEVER write a bare mnemonic (OI, CLC, TM, MVC...) without explaining what it does in plain words first.
  • Derive a variable's business name from its code name AND the inline source comments provided
    (e.g. a comment "VALID NBR OF LIMIT ITEMS?" tells you the field counts limit items)."""

_COMPLETENESS_RULE = (
    "COMPLETENESS — write the FULL detail, never a high-level gloss:\n"
    "  • The words 'a few', 'some', 'several', 'various', 'multiple', 'a number of', 'certain', and "
    "'a series of' are FORBIDDEN whenever the scaffold actually lists the items. Never write 'goes through "
    "a few checks', 'after several conditions', 'calls some other processes and checks their success', or "
    "'performs various operations'.\n"
    "  • Enumerate EVERY condition individually — if five conditions must hold, state all five and what each "
    "one decides. Do not collapse them into one vague phrase.\n"
    "  • Name EVERY process / called operation specifically and say what each one does — never 'calls some "
    "other processes'; describe each call and its purpose, one by one.\n"
    "  • If the scaffold provides N items (conditions, calls, dependent variables, values), your output must "
    "account for all N. Omitting detail to be brief is a failure."
)

# Business-mode only: the variable's own code name (in parentheses) is the ONLY technical token allowed.
_BUSINESS_ONLY_RULE = (
    "BUSINESS-ONLY NAMING — the ONLY technical token allowed ANYWHERE in your output is the variable's own "
    "code name, in parentheses right after its business name (e.g. 'the Online Source Indicator (LG1OSI)'). "
    "Nothing else technical may appear:\n"
    "  • NEVER write a file's code name or stem (e.g. 'da78', 'da78.asm', 'dx750000', 'lu82'). Refer to each "
    "file ONLY by a business name for what it does (e.g. 'the transaction-validation program', 'the program "
    "that finalises the update'), and briefly explain that file's role.\n"
    "  • NEVER write routine/subroutine names, opcodes, mnemonics, or raw statements. Describe what each "
    "operation does in plain business terms.\n"
    "  • Concrete business VALUES stay (version numbers, return/status codes, counts, identifiers like 'C400') "
    "— those are business facts, not technical names."
)

_BUSINESS_SYSTEM_PROMPT = (
    "You are a senior systems analyst writing for a BUSINESS reader who wants to fully understand how one "
    "data field in a mainframe program gets its value. The reader is intelligent but knows NOTHING about "
    "assembly language, mnemonics, registers, hex, or z/TPF. Your job is to make the setting logic of this "
    "variable completely understandable to them.\n\n"
    "You receive a structured scaffold that already tells you WHY each file, statement, and condition was "
    "examined, plus the plain meaning of each assembly opcode. Trust it; never invent facts. If the scaffold "
    "says coverage was incomplete, say so honestly.\n\n"
    "BE CRISP. Write in short bullet points, NOT paragraphs. Lead with one short sentence, then bullet the key "
    "facts — what is checked, what decision is made, what value is recorded — one fact per bullet. Cover everything "
    "that matters but cut all filler: no restating prior steps, no padding, no throat-clearing.\n\n"
    + _DESIGN_RULE +
    "\n\n" + _COMPLETENESS_RULE +
    "\n\nTONE: clear, patient, concrete. Every sentence should tie back to the variable being explained. "
    "Translate every technical idea into something a business person can picture."
)

_SYNTHESIS_SYSTEM_PROMPT = (
    "You are writing the FINAL, complete explanation of how one mainframe variable gets set, for a business "
    "reader who knows nothing about assembly. This is the summary they will read on its own to understand "
    "the whole story, so it must stand alone and be thorough.\n\n"
    "Cover, in order and in depth: (1) what the variable represents in the real business, (2) exactly how it "
    "finally gets set — the file, the routine, the operation in plain words, and the exact statement, (3) the "
    "full chain of conditions that had to be true for it to be set, as business decisions, and (4) every "
    "dependent variable that mattered: what it is, HOW IT ITSELF was set, and how it influenced the main "
    "variable.\n\n"
    "BE CRISP. Use short bullet points, NOT multi-paragraph prose. Each section: a one-line lead, then bullets — "
    "one fact per bullet, no filler. Name every variable as its business name followed by its code name in "
    "parentheses, e.g. the Online Source Indicator (`LG1OSI`).\n\n"
    + _DESIGN_RULE
    + "\n\n" + _COMPLETENESS_RULE
)

_PURE_BUSINESS_SYSTEM_PROMPT = (
    "You are a senior business analyst explaining, to a non-technical executive, how one business data field "
    "gets its value inside a mainframe payment system. The reader has ZERO knowledge of assembly language, "
    "registers, opcodes, hex values, or any technical implementation detail.\n\n"
    "CRITICAL RULES — violating any of these is a failure:\n"
    "  1. NEVER mention any assembly mnemonic (OI, MVC, CLC, TM, BNE, LA, BC, etc.).\n"
    "  2. NEVER show or quote raw source code statements.\n"
    "  3. NEVER mention register names, raw hex, bit masks, or storage addresses. BUT you MUST keep every "
    "concrete BUSINESS-meaningful value the scaffold gives you — version numbers, status/return codes, counts, "
    "source codes or identifiers (e.g. 'C400'), and the specific value a field is checked against — stated in "
    "plain decimal or character form. Do NOT vaguely say 'a required version' or 'a specific value' when the "
    "actual value is known.\n"
    "  4. NEVER use the words 'assembly', 'opcode', 'mnemonic', 'branch', 'byte', 'bit', 'flag', "
    "'routine', 'instruction', 'z/TPF', or any technical implementation term.\n"
    "  5. Describe EVERY action as a business operation: 'the system records...', 'the process checks...',"
    " 'the application marks...', 'the transaction is verified...'.\n"
    "  6. ALWAYS name a variable as its business name FOLLOWED BY its code name in parentheses, e.g. 'the "
    "Online Source Indicator (LG1OSI)'. Never the business name alone, never the code name alone.\n"
    "  7. Describe conditions as business decisions, but INCLUDE the concrete value being checked: instead of a "
    "bare 'confirms the previous step succeeded', say 'confirms the previous database step succeeded (its return "
    "code is 0)'; instead of 'checks the version is correct', say 'checks the Hub Version (HUBVER) equals the "
    "required version <the actual value>'.\n\n"
    "You receive a structured scaffold that tells you exactly what was found. Narrate it as a business "
    "story — what the system does, why it does it, and what it means for the business process.\n\n"
    "BE CRISP, NOT INCOMPLETE: short bullet points, NOT paragraphs; one business fact per bullet; no wasted "
    "words. 'Crisp' means cutting filler, NOT dropping facts — never omit a concrete value, code, count, "
    "threshold, or condition the scaffold provides. Do NOT add generic framing such as 'this only happens after "
    "a series of prerequisite checks' — state the specific checks themselves, and never restate what the "
    "conditions list already covers.\n\n"
    + _BUSINESS_ONLY_RULE
    + "\n\n" + _COMPLETENESS_RULE
)

_PURE_BUSINESS_SYNTHESIS_PROMPT = (
    "You are writing a complete, standalone business summary of how one payment-system data field gets set, "
    "for a senior executive who has no technical background. They need to understand the full business logic "
    "end to end — what the field represents, under what business conditions it gets set, and what that means "
    "for the transaction or process.\n\n"
    "CRITICAL RULES — violating any of these is a failure:\n"
    "  1. NEVER mention assembly mnemonics, opcodes, raw code, registers, raw hex, bits, bytes, or any "
    "implementation detail. BUT you MUST keep every concrete BUSINESS-meaningful value the scaffold gives you — "
    "version numbers, status/return codes, counts, source codes or identifiers (e.g. 'C400'), and the specific "
    "value a field is checked against — in plain decimal/character form. Never say 'a required version' or 'a "
    "specific value' when the actual value is known.\n"
    "  2. NEVER use the words 'assembly', 'routine', 'instruction', 'branch', 'opcode', 'mnemonic', "
    "'z/TPF', 'bit', 'byte', 'flag', 'register'.\n"
    "  3. Describe every action as a business operation — 'the system verifies...', 'the application "
    "records...', 'the process confirms...'.\n"
    "  4. ALWAYS name a variable as its business name FOLLOWED BY its code name in parentheses, e.g. 'the "
    "Online Source Indicator (LG1OSI)'. Never the business name alone, never the code name alone.\n"
    "  5. Describe conditions as business decisions, but INCLUDE the concrete value being checked (e.g. "
    "'confirms the database read returned success (return code 0)', 'requires the Hub Version (HUBVER) to equal "
    "the required version <value>'), not a vague paraphrase.\n\n"
    "Cover, in depth: (1) what the field represents in the real business, (2) what business conditions must "
    "be true for it to be set, (3) how control flows through the system to reach the point where it is set, "
    "and (4) what each dependent field represents and how it influences the outcome. "
    "BE CRISP: use short bullet points, NOT paragraphs — one business fact per bullet, no filler. The document "
    "should still read coherently on its own.\n\n"
    + _BUSINESS_ONLY_RULE
    + "\n\n" + _COMPLETENESS_RULE
)

_BRIDGE_SYSTEM_PROMPT = (
    "You are explaining, to a business reader who knows nothing about assembly or C++, the relationship "
    "between a mainframe (assembly) variable and its C++ counterpart — they represent the same business "
    "concept in two parts of the system. Explain what that shared business concept is, how the cc-header "
    "mapping connects them, how their setting logic compares, and why the cross-language link matters. "
    "Be crisp — short bullet points, one fact per bullet, no filler; name each variable as its business name "
    "followed by its code name in parentheses.\n\n"
    + _DESIGN_RULE
    + "\n\n" + _COMPLETENESS_RULE
)

# Context limits — keep prompts bounded so a large-codebase lineage (many files,
# many dependent variables) never overflows the model's context window. We never
# feed the WHOLE end-to-end lineage verbatim; we feed one-line facts for every
# step plus FULL detail only for a bounded, prioritised subset.
_MAX_STORY_STEPS = 8
_MAX_PRIOR_FULL = 3           # full prior explanations included verbatim in a step prompt
_MAX_PRIOR_NARRATIVE_CHARS = 600   # truncate each prior narrative to this in a step prompt
_MAX_SYNTH_FULL_STEPS = 12   # how many steps get FULL detail in the synthesis prompt
_MAX_SYNTH_NARRATIVE_CHARS = 700   # truncate each narrative to this in the synthesis prompt


# ---------------------------------------------------------------------------
# Session persistence
# ---------------------------------------------------------------------------

def _session_path(kb_id: str, explain_session_id: str) -> Path:
    from api.config import settings
    d = settings.JOBS_BASE_DIR / kb_id / "output" / "lineage_explain_sessions"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{explain_session_id}.msgpack"


def create_explain_session(
    kb_id: str,
    backward_session_id: str,
    root_variable: str,
    selected_chain: List[str],
) -> Dict[str, Any]:
    session: Dict[str, Any] = {
        "version":              2,
        "kb_id":                kb_id,
        "backward_session_id":  backward_session_id,
        "root_variable":        root_variable.upper(),
        "selected_chain":       list(selected_chain),
        "current_step_index":   0,
        "step_explanations":    {},   # str(idx) → StepExplanation dict
        "step_reasonings":      {},   # str(idx) → StepReasoning dict
        "step_facts":           {},   # str(idx) → one-line fact
        "synthesis":            None,
        "created_at":           datetime.now(timezone.utc).isoformat(),
    }
    _save_session(kb_id, backward_session_id, session)
    return session


def load_explain_session(kb_id: str, backward_session_id: str) -> Optional[Dict[str, Any]]:
    path = _session_path(kb_id, backward_session_id)
    if not path.exists():
        return None
    try:
        return msgpack.unpackb(path.read_bytes(), raw=False)
    except Exception:
        return None


def _save_session(kb_id: str, backward_session_id: str, session: Dict[str, Any]) -> None:
    path = _session_path(kb_id, backward_session_id)
    path.write_bytes(msgpack.packb(session, use_bin_type=True))


# ---------------------------------------------------------------------------
# KB-level canonical business-name cache
# ---------------------------------------------------------------------------

def _biz_cache_path(kb_id: str) -> Path:
    import json as _json
    from api.config import settings
    return settings.JOBS_BASE_DIR / kb_id / "output" / "variable_business_names.json"


def load_biz_cache(kb_id: str) -> Dict[str, str]:
    """Return {VAR_NAME_UPPER: business_name} from the KB-level cache."""
    import json as _json
    p = _biz_cache_path(kb_id)
    try:
        return _json.loads(p.read_text()) if p.exists() else {}
    except Exception:
        return {}


def _update_biz_cache(kb_id: str, updates: Dict[str, str]) -> None:
    """Merge updates into the KB-level cache; write only when something changes."""
    import json as _json
    if not updates:
        return
    p = _biz_cache_path(kb_id)
    try:
        existing: Dict[str, str] = _json.loads(p.read_text()) if p.exists() else {}
        dirty = False
        for k, v in updates.items():
            key = k.upper()
            if key and v and key not in existing:
                existing[key] = v
                dirty = True
        if dirty:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(_json.dumps(existing, indent=2))
    except Exception as exc:
        logger.debug("biz_cache update failed: %s", exc)


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

def _build_step_prompt(
    reasoning: Dict[str, Any],
    root_variable: str,
    selected_chain: List[str],
    step_index: int,
    total_steps: int,
    prior_facts: Dict[str, str],
    prior_explanations: Dict[str, Any],
    business_mode: bool = False,
    known_biz_names: Optional[Dict[str, str]] = None,
) -> str:
    chain_str = " → ".join(selected_chain)
    phase_badge = reasoning.get("phase_badge", reasoning.get("phase", "?"))
    file_stem = reasoning.get("file_stem", "?")
    file_type = reasoning.get("file_type", "asm")
    variable = reasoning.get("variable", root_variable)

    sections: List[str] = []

    # --- Goal ---
    goal_lines = [
        f"ANALYSIS GOAL",
        f"We are explaining variable '{root_variable}' through its data lineage.",
        f"Full chain (entry point → setter): {chain_str}",
        f"This is step {step_index + 1} of {total_steps}.",
    ]
    if known_biz_names:
        name_hints = "; ".join(
            f"{k} → \"{v}\"" for k, v in list(known_biz_names.items())[:20]
        )
        goal_lines.append(
            f"CANONICAL BUSINESS NAMES (use exactly as given — do NOT invent alternatives):\n  {name_hints}"
        )
    sections.append("\n".join(goal_lines))

    # --- Story so far ---
    story_parts: List[str] = []
    if prior_facts and step_index > 0:
        facts = [
            f"  • Step {i}: {prior_facts[str(i)]}"
            for i in range(step_index)
            if str(i) in prior_facts
        ]
        if facts:
            story_parts.append("Quick reference (one line per prior step):\n" + "\n".join(facts))

    # Include full prior explanations (limited)
    if prior_explanations:
        detail_parts: List[str] = []
        start = max(0, step_index - _MAX_PRIOR_FULL)
        for i in range(start, step_index):
            exp = prior_explanations.get(str(i))
            if exp:
                if isinstance(exp, dict):
                    # Reconstruct brief narrative from structured explanation
                    headline = exp.get("headline") or exp.get("why_we_are_here", "")
                    next_step = exp.get("what_happens_next", "")
                    detail_parts.append(f"[Step {i}] {headline} {next_step}".strip())
                else:
                    detail_parts.append(f"[Step {i}] {str(exp)[:500]}")
        if detail_parts:
            story_parts.append("Recent step summaries:\n" + "\n\n".join(detail_parts))

    if story_parts:
        sections.append("STORY SO FAR\n" + "\n\n".join(story_parts))
    else:
        sections.append("STORY SO FAR\n  (this is the first step)")

    # --- Current step context ---
    why_examined = reasoning.get("why_examined", "")
    scope_plain = reasoning.get("scope_plain", "")
    var_note = ""
    if variable != root_variable:
        phase = reasoning.get("phase", "")
        if phase in ("dep_var_chain", "dep_var_downstream", "cpp_dep_var_extended"):
            var_note = f" — this is a dependent variable of '{root_variable}'"
        else:
            var_note = f" — '{root_variable}' is known as '{variable}' in this file"

    current_header = (
        f"CURRENT STEP: file={file_stem} ({file_type.upper()}) | "
        f"variable={variable}{var_note} | role={phase_badge}"
    )

    current_parts: List[str] = [current_header, f"Why we are here:\n{why_examined}"]

    # Setter detail
    setter = reasoning.get("setter_detail") or {}
    if setter.get("instruction"):
        inst = setter["instruction"]
        routine = setter.get("routine", "")
        raw = setter.get("raw_line", "")
        op_mean = setter.get("opcode_meaning", "")
        all_sites = setter.get("all_sites", 1)
        if business_mode:
            setter_lines = [
                f"  what happens: {op_mean or 'the variable is assigned its value'}",
                f"  module: {routine}",
            ]
        else:
            setter_lines = [
                f"  exact statement: {raw or inst}",
                f"  routine: {routine}",
                f"  opcode `{inst}` means: {op_mean or '(see opcode glossary)'}",
            ]
        if all_sites > 1:
            setter_lines.append(f"  (+ {all_sites - 1} additional setter site(s) for this variable)")
        current_parts.append("THE SETTER (where this variable gets its value):\n" + "\n".join(setter_lines))

    # Statements
    statements = reasoning.get("statements") or []
    if statements:
        stmt_lines: List[str] = []
        for s in statements[:24]:
            raw = s.get("raw_statement", "")
            routine = s.get("routine", "")
            op_mean = s.get("opcode_meaning", "") or s.get("role_plain", "")
            if business_mode:
                # Omit raw code; provide only the business meaning of the operation
                if op_mean:
                    stmt_lines.append(f"  Event: {op_mean}" + (f" [module {routine}]" if routine else ""))
            else:
                routine_str = f" [routine {routine}]" if routine else ""
                stmt_lines.append(f"  `{raw}`{routine_str}")
                if op_mean:
                    stmt_lines.append(f"            → this operation is {op_mean}")
        header = (
            "KEY BUSINESS EVENTS (describe each as a business action — do NOT quote code):\n"
            if business_mode else
            "EVERY RELEVANT SOURCE STATEMENT (verbatim code + what the operation does):\n"
        )
        current_parts.append(header + "\n".join(stmt_lines))

    # Guard chain
    conditions = reasoning.get("conditions_to_reach_setter") or []
    if conditions:
        cond_lines: List[str] = []
        for c in conditions[:14]:
            check = c.get("check", "")
            plain = c.get("in_plain_terms", "")
            decides = c.get("decides", "")
            op_mean = c.get("opcode_meaning", "")
            if business_mode:
                # Only expose the plain-language meaning; omit raw check code
                if plain:
                    cond_lines.append(f"  Business check: {plain}")
                if decides:
                    cond_lines.append(f"    → outcome: {decides}")
            else:
                cond_lines.append(f"  `{check}`")
                if op_mean:
                    cond_lines.append(f"           → the check operation is {op_mean}")
                if plain:
                    cond_lines.append(f"           → in plain terms: {plain}")
                if decides:
                    cond_lines.append(f"           → outcome: {decides}")
        header = (
            "BUSINESS DECISIONS THAT MUST BE TRUE (describe each as a business rule):\n"
            if business_mode else
            "CONDITIONS THAT MUST HOLD TO REACH THE SETTER (the guard chain, in order):\n"
        )
        current_parts.append(header + "\n".join(cond_lines))

    # Dependent variables
    dep_vars = reasoning.get("dependent_vars_introduced") or []
    if dep_vars:
        dv_lines: List[str] = []
        for dv in dep_vars[:12]:
            name = dv.get("name", "")
            why = dv.get("why_it_was_traced", "")
            conds_for_dv = dv.get("checked_by") or []
            dv_lines.append(f"  {name}: {why}")
            if conds_for_dv and not business_mode:
                dv_lines.append(f"    (checked by: {'; '.join(conds_for_dv[:2])})")
        current_parts.append(
            "DEPENDENT VARIABLES introduced here (values that influence this variable — give each a business name):\n"
            + "\n".join(dv_lines)
        )

    # Cross-file calls
    cross_file = reasoning.get("cross_file_follow") or []
    if cross_file:
        cf_lines: List[str] = []
        for cf in cross_file[:6]:
            target = cf.get("target_file", "")
            inst = cf.get("instruction", "")
            call_type_plain = cf.get("call_type_plain", "")
            df_plain = cf.get("discovered_from_plain") or []
            reason = "; ".join(df_plain) if df_plain else "part of the call chain"
            if business_mode:
                cf_lines.append(f"  Control passes to module {target} ({call_type_plain}) — because {reason}")
            else:
                line = cf.get("line", 0)
                cf_lines.append(f"  {inst} → {target} at line {line} ({call_type_plain}) — followed because {reason}")
        current_parts.append("Cross-file calls followed from here:\n" + "\n".join(cf_lines))

    # Coverage
    coverage = reasoning.get("coverage_note", "")
    if coverage:
        current_parts.append(f"Coverage note: {coverage}")

    if file_type == "cpp":
        current_parts.append("(This is a C++ file — the analysis used the global variable lineage graph rather than assembly instruction tracing.)")

    sections.append("\n\n".join(current_parts))

    # --- Task ---
    # C++ files have if-guards in the scaffold (not ASM COMPARE/BRANCH pairs) — explicit override.
    _cpp_conditions_technical = (
        f"- conditions: The scaffold above contains C++ `if`-guard conditions. "
        f"For EACH condition listed, populate one entry: `check` = the verbatim condition expression "
        f"(e.g. `if(securityCode.length == Keyed4dbc)`), `in_plain_terms` = one plain-English sentence "
        f"stating what the check tests in business terms (name the variables), `decides` = what happens "
        f"when the check passes and when it fails. Do NOT leave this array empty when the scaffold has conditions.\n"
    )
    _cpp_conditions_business = (
        f"- conditions: The scaffold above contains C++ `if`-guard conditions (business decisions). "
        f"For EACH one, populate one entry: leave `check` as an empty string '', "
        f"`in_plain_terms` = the business question being asked in plain English, "
        f"`decides` = what each outcome (yes/no) means for the process in business terms. "
        f"Do NOT leave this array empty when the scaffold lists conditions.\n"
    )

    if business_mode:
        sections.append(
            f"YOUR TASK — fill in the StepExplanation JSON for this step, for a senior executive who knows "
            f"nothing about technology.\n\n"
            f"- headline: ONE clear opening sentence stating in pure business terms what happens at this stage. "
            f"Name what the system DOES, not how. No code names, no assembly, no technical jargon.\n"
            f"- variable_business_name: the readable business name of the variable ('{variable}'), Title Case.\n"
            f"- narrative: the MAIN explanation — CRISP Markdown bullet points, NOT paragraphs. One short lead "
            f"sentence, then bullets: what the system checks, what decision it makes, what value it records — one "
            f"fact per bullet. KEEP every concrete business value the scaffold gives (the actual version, code, "
            f"count, return-code, or identifier such as 'C400', and the specific value a field is checked "
            f"against) — state it plainly, never 'a required version' / 'a specific value'. Crisp means no filler, "
            f"NOT dropping facts. Enumerate EVERY condition individually (never 'a few checks' / 'several "
            f"conditions'), and when control calls other programs or operations, name and describe EACH one and "
            f"what it does (never 'calls some other processes and checks their success'). Refer to ANY file ONLY "
            f"by a business name for what it does (e.g. 'the transaction-validation program') — NEVER its code "
            f"stem like 'da78' or 'da78.asm'. Do NOT add generic framing like 'this happens after a series of "
            f"prerequisite checks'. Use language like 'the system confirms...', 'the "
            f"application marks...'. **Bold** the single most important business fact. "
            f"NO code, NO mnemonics, NO raw statements, NO file stems, NO routine names, NO 'assembly', NO 'byte', "
            f"NO 'bit', NO 'flag'. The ONLY code token allowed anywhere is the variable's own code name in "
            f"parentheses after its business name, e.g. the Online Source Indicator (LG1OSI).\n"
            f"- statements: leave as an EMPTY ARRAY []. Do not populate.\n"
            + (_cpp_conditions_business if file_type == "cpp" else
               f"- conditions: enumerate EVERY business decision (list them ALL — never omit any or collapse "
               f"into 'a few checks') — leave `check` as an empty string '', "
               f"fill `in_plain_terms` (the business question being asked, INCLUDING the concrete value being "
               f"checked — the actual version / code / count / return-code, never 'a required version' or 'a "
               f"specific value'), fill `decides` (what each answer means for the process).\n")
            + f"- dependent_variables: each one — `name` (code name only as an identifier), "
            f"`business_name` (its readable name), `why_it_was_traced` in pure business terms.\n"
            f"- what_happens_next: one plain-English sentence on what the analysis looks at next and why.\n"
            f"- coverage_note: only if the scaffold flagged a gap; otherwise leave empty.\n\n"
            f"REMEMBER: if you write any assembly mnemonic or raw code statement anywhere in your output, that is a failure."
        )
    else:
        sections.append(
            f"YOUR TASK — fill in the StepExplanation JSON for this step, for a business reader who knows no assembly.\n\n"
            f"- headline: ONE clear opening sentence stating in business terms what this step is about. Start with a "
            f"concrete subject (the variable's business name). This is the first line the reader sees — make it land.\n"
            f"- variable_business_name: the readable business name of the variable being explained ('{variable}'), Title Case.\n"
            f"- narrative: the MAIN explanation — CRISP Markdown bullet points, NOT paragraphs. One short lead "
            f"sentence, then bullets covering what matters in file {file_stem}: how the variable is set here (if it "
            f"is), each condition, and each dependent value — one fact per bullet, no filler, no restating prior "
            f"steps. Obey THE ONE WRITING DESIGN strictly: the meaning of each operation goes in the sentence, and "
            f"the exact statement + routine go in parentheses (NEVER line numbers). Name every variable as its "
            f"business name followed by its code name in parentheses. **Bold** the single most important finding, "
            f"and wrap code/variables in `backticks`.\n"
            f"- statements: every key source statement — verbatim `statement`, `opcode_meaning` (what the operation does "
            f"mechanically, plain words), and `means` (the business effect, naming the variables).\n"
            + (_cpp_conditions_technical if file_type == "cpp" else
               f"- conditions: each guard condition — `check` (verbatim), `in_plain_terms` (what it tests, named), `decides` "
               f"(what each outcome means for the business).\n")
            + f"- dependent_variables: each one — `name`, `business_name` (inferred from name + comments), `why_it_was_traced`.\n"
            f"- what_happens_next: one sentence on what the analysis examines next and why.\n"
            f"- coverage_note: ONLY if the scaffold flagged a gap; otherwise leave empty.\n\n"
            f"Be crisp — bullet points, no filler. Never print a bare mnemonic without explaining it. Never invent facts not in the scaffold."
        )

    return "\n\n---\n\n".join(sections)


def _build_synthesis_prompt(
    root_variable: str,
    selected_chain: List[str],
    step_facts: Dict[str, str],
    step_explanations: Dict[str, Any],
    step_reasonings: Optional[Dict[str, Any]] = None,
    business_mode: bool = False,
) -> str:
    chain_str = " → ".join(selected_chain)
    sections: List[str] = []
    step_reasonings = step_reasonings or {}

    sections.append(
        f"ANALYSIS GOAL\n"
        f"Produce the final unified explanation of variable '{root_variable}'.\n"
        f"Chain: {chain_str}"
    )

    # --- Which variables actually get SET (have their own setter) + cross-file calls ---
    set_vars: List[str] = []        # ordered: root first, then dep vars with setters
    setter_info: Dict[str, str] = {}
    cross_calls: List[str] = []
    for i in sorted(int(k) for k in step_reasonings):
        r = step_reasonings.get(str(i)) or {}
        if not isinstance(r, dict):
            continue
        v = str(r.get("variable") or "").upper()
        sd = r.get("setter_detail") or {}
        if v and sd.get("instruction") and v not in setter_info:
            set_vars.append(v)
            setter_info[v] = f"`{(sd.get('raw_line') or sd.get('instruction'))}` in routine {sd.get('routine','?')}"
        # cross-file calls (external operations) seen in this step
        for cf in (r.get("cross_file_follow") or []):
            tgt = cf.get("target_file", "")
            inst = cf.get("instruction", "")
            ctp = cf.get("call_type_plain", "")
            if tgt:
                cross_calls.append(f"  • `{inst} {tgt}` (in file {r.get('file_stem','?')}) — {ctp}")

    if set_vars:
        sv_lines = [f"  • {v} — set by {setter_info.get(v,'?')}" for v in set_vars]
        sections.append(
            "VARIABLES THAT GET SET IN THIS LINEAGE (make a rule group for EACH of these):\n"
            + "\n".join(sv_lines)
        )
    if cross_calls:
        # dedupe preserving order
        seen_cc = set(); uniq_cc = []
        for c in cross_calls:
            if c not in seen_cc:
                seen_cc.add(c); uniq_cc.append(c)
        sections.append(
            "EXTERNAL OPERATIONS CALLED (use these to name 'the external operation' precisely in rules):\n"
            + "\n".join(uniq_cc[:15])
        )

    # Facts summary — one line per step (cheap; ALWAYS include every step so the
    # synthesis knows the full shape of the lineage even when we omit full detail).
    fact_lines = [
        f"  • Step {i}: {step_facts[str(i)]}"
        for i in sorted(int(k) for k in step_facts)
        if str(i) in step_facts
    ]
    sections.append("STEP-BY-STEP FACTS (every step, one line each)\n" + "\n".join(fact_lines) if fact_lines else "STEP-BY-STEP FACTS\n(none)")

    # --- Chain stages: map each chain file to the step facts found in it -------
    # Gives the model what it needs to produce chain_stages / chain_narrative
    # without re-reading every step in full.
    facts_by_stem: Dict[str, List[str]] = {}
    for i in sorted(int(k) for k in step_reasonings):
        r = step_reasonings.get(str(i)) or {}
        if not isinstance(r, dict):
            continue
        stem = str(r.get("file_stem") or "")
        if stem:
            facts_by_stem.setdefault(stem, []).append(step_facts.get(str(i), r.get("phase_badge", "")))
    if selected_chain:
        stage_lines = []
        for n, f in enumerate(selected_chain, start=1):
            ctx = "; ".join(x for x in (facts_by_stem.get(f) or [])[:2] if x)
            role = "ENTRY POINT" if n == 1 else ("SETTER FILE" if n == len(selected_chain) else "intermediate")
            stage_lines.append(f"  Stage {n} — file {f} ({role}): {ctx or 'passes control along the chain'}")
        sections.append(
            "CALL CHAIN STAGES (produce one chain_stages entry per file, in THIS order):\n"
            + "\n".join(stage_lines)
        )

    # --- Bounded full detail ---------------------------------------------------
    # NEVER dump every step's full narrative (a large codebase lineage can have
    # dozens of files / dependent variables). Prioritise the steps that carry the
    # actual setting logic, include FULL detail only for a bounded subset, and
    # rely on the one-line facts above for the rest.
    all_idx = sorted(int(k) for k in step_explanations)

    def _priority(i: int) -> tuple:
        r = step_reasonings.get(str(i)) or {}
        phase = r.get("phase", "")
        has_setter = bool((r.get("setter_detail") or {}).get("instruction"))
        is_endpoint = (i == all_idx[0] or i == all_idx[-1]) if all_idx else False
        # lower sort key = higher priority
        rank = 0 if has_setter else (1 if phase in ("modifier", "upstream") else (2 if is_endpoint else 3))
        return (rank, i)

    chosen = sorted(all_idx, key=_priority)[:_MAX_SYNTH_FULL_STEPS]
    chosen_set = set(chosen)
    omitted = [i for i in all_idx if i not in chosen_set]

    expl_parts: List[str] = []
    for i in all_idx:
        if i not in chosen_set:
            continue
        exp = step_explanations.get(str(i))
        if not exp or not isinstance(exp, dict):
            continue
        headline = exp.get("headline") or exp.get("why_we_are_here", "")
        lines = [f"[Step {i}] {headline}"]
        narr = (exp.get("narrative", "") or "").strip()
        if narr:
            if len(narr) > _MAX_SYNTH_NARRATIVE_CHARS:
                narr = narr[:_MAX_SYNTH_NARRATIVE_CHARS].rstrip() + " …"
            lines.append(narr)
        for s in [s for s in (exp.get("statements") or []) if s.get("means")][:5]:
            lines.append(f"  • `{s.get('statement','')}` — {s.get('means','')}")
        for c in (exp.get("conditions") or [])[:5]:
            lines.append(f"  • condition `{c.get('check','')}` — {c.get('in_plain_terms','')}")
        for dv in (exp.get("dependent_variables") or [])[:5]:
            bn = dv.get("business_name", "")
            bn_str = f" [{bn}]" if bn else ""
            lines.append(f"  • dependent variable {dv.get('name','')}{bn_str} — {dv.get('why_it_was_traced','')}")
        expl_parts.append("\n".join(lines))
    if expl_parts:
        header = "KEY STEPS — FULL DETAIL (the steps carrying the setting logic"
        if omitted:
            header += f"; {len(omitted)} further step(s) are summarised in the one-line facts above to keep this prompt bounded"
        header += "):"
        sections.append(header + "\n\n" + "\n\n".join(expl_parts))

    if business_mode:
        sections.append(
            f"YOUR TASK\n"
            f"Write the final SynthesisExplanation JSON for '{root_variable}', for a non-technical executive.\n"
            f"THE ONLY technical token allowed anywhere is the variable's own code name in parentheses after its "
            f"business name (e.g. the Online Source Indicator (LG1OSI)). NEVER write file stems (e.g. 'da78'), "
            f"routine names, opcodes, or raw statements — refer to each program ONLY by a business name for what "
            f"it does. Keep concrete business VALUES (versions, return codes, counts, identifiers like 'C400').\n"
            f"- variable_business_name: the readable Title-Case business name of '{root_variable}'.\n"
            f"- chain_stages: ONE entry per file in the call chain, SAME order. Give each a business stage_title "
            f"(e.g. 'Routing the request') and a one-sentence what_happens describing what that program does. "
            f"Cover EVERY file, skip none. (The `file` field is an internal id — fine to set, but never put a "
            f"file stem in any prose field.)\n"
            f"- chain_narrative: a few short sentences telling the journey from entry to setter, naming each stage "
            f"by a business name (never a file stem) and how control passes from one program to the next.\n"
            f"- what_it_is: 2-4 sentences on what '{root_variable}' represents in the real business.\n"
            f"- how_it_is_set: CRISP bullets — exactly how it finally gets its value: the program (by business "
            f"name) that does it, the operation in plain words, the value written and what it means. One fact per bullet.\n"
            f"- what_had_to_be_true: CRISP bullets — EVERY condition that had to hold (enumerate ALL, never 'a few "
            f"checks'), as business decisions with the concrete value checked, naming each variable Business Name "
            f"(CODE). One condition per bullet.\n"
            f"- dependent_variables_story: CRISP bullets — for EACH dependent variable, what it is, HOW IT ITSELF "
            f"was set (in business terms — the program by business name and the business operation, NOT file/"
            f"routine/statement), and how it influenced '{root_variable}'. If one had no setter (a leaf/input), "
            f"say so and where its value comes from. One dependent variable per bullet.\n"
            f"- full_story: a short, point-based end-to-end account — one lead sentence then bullets from entry to "
            f"setter. Name every called program/operation specifically by what it does (never 'calls some other "
            f"processes'). No file stems, no statements.\n"
            f"- setting_rule_groups: ONE GROUP PER VARIABLE-THAT-GETS-SET (see 'VARIABLES THAT GET SET'). First "
            f"group is '{root_variable}'; then one per dependent variable with its own setter. Skip pure inputs. "
            f"Each rule: a SPECIFIC business condition naming the operation by what it DOES (use the EXTERNAL "
            f"OPERATIONS list to be specific — e.g. 'the account-record database read must succeed', NOT 'the read "
            f"from file DB72'). Set `depends_on` to the variable code names. Leave `evidence` EMPTY (no raw "
            f"statements in business mode). Each group: `variable`, `business_name`, `rules`."
        )
    else:
        sections.append(
            f"YOUR TASK\n"
            f"Write the final SynthesisExplanation JSON for '{root_variable}', for a business reader who knows no assembly.\n"
            f"- variable_business_name: the readable Title-Case business name of '{root_variable}'.\n"
            f"- chain_stages: ONE entry per file in the call chain, in the SAME order as the chain above. Give each a short "
            f"business stage_title (e.g. 'Routing the request') and a one-sentence what_happens. Use the CALL CHAIN STAGES list "
            f"above; cover EVERY file, skip none.\n"
            f"- chain_narrative: a few short sentences telling the chain as a journey from entry point to setter, naming each "
            f"stage in business terms and how control passes file to file. No assembly jargon. Tight, not a long paragraph.\n"
            f"- what_it_is: 2-4 sentences on what '{root_variable}' represents in the real business.\n"
            f"- how_it_is_set: CRISP bullet points — exactly how it finally gets its value: file, routine, the "
            f"operation in plain words, and the exact statement in parentheses, plus what the written value means. One fact per bullet.\n"
            f"- what_had_to_be_true: CRISP bullet points — the full chain of conditions as business decisions, from entry point to "
            f"setter, naming each variable (business name + code name in parentheses). Enumerate EVERY condition. One condition per bullet.\n"
            f"- dependent_variables_story: CRISP bullet points — for EACH dependent variable that mattered, what it is, HOW IT "
            f"ITSELF was set (file/routine/statement), and how it influenced '{root_variable}'. If one had no setter (a "
            f"leaf/input), say so and where its value comes from. One dependent variable per bullet.\n"
            f"- full_story: a short, point-based end-to-end account the reader can read alone — one short lead sentence, then "
            f"bullets walking from entry point to setter. No multi-paragraph prose.\n"
            f"- setting_rule_groups: ONE GROUP PER VARIABLE-THAT-GETS-SET (see the 'VARIABLES THAT GET SET' list above). "
            f"The first group is for '{root_variable}' and lists every rule that must hold for IT to be set. Then add one "
            f"group for EACH dependent variable that has its own setter (e.g. WK_CMO) listing the rules that gate ITS setter. "
            f"Do NOT make a group for pure input variables that are never set in the traced code. For every rule: write a "
            f"clear, SPECIFIC business condition (name the actual operation/file/routine — use the EXTERNAL OPERATIONS list "
            f"above so you never write vague phrases like 'the first major external operation'; instead say e.g. 'the "
            f"database read from file DB72 must succeed'), set `depends_on` to the variable code names, and `evidence` to "
            f"the exact source statement in backticks (NO line numbers). Each group: `variable`, `business_name`, `rules`.\n\n"
            f"Be CRISP — bullet points, not paragraphs; one fact per bullet, no filler. Follow THE ONE WRITING DESIGN for every "
            f"code reference (operation meaning in prose, exact statement + routine in parentheses, NEVER line numbers). Name "
            f"every variable as its business name followed by its code name in parentheses."
        )

    return "\n\n---\n\n".join(sections)


def _build_bridge_prompt(
    primary_var: str,
    counterpart_var: str,
    primary_language: str,
    counterpart_language: str,
    cc_header: Optional[str],
    certainty: Optional[float],
    certainty_label: Optional[str],
    mapping_via: Optional[str],
    struct_name: Optional[str],
    primary_synthesis: Optional[Dict[str, Any]],
    counterpart_synthesis: Optional[Dict[str, Any]],
) -> str:
    sections: List[str] = []

    sections.append(
        f"BRIDGE CONTEXT\n"
        f"Primary variable: '{primary_var}' ({primary_language.upper()})\n"
        f"Counterpart variable: '{counterpart_var}' ({counterpart_language.upper()})\n"
        f"Connection via cc-header: {cc_header or '(not specified)'}\n"
        f"Struct name: {struct_name or '(not determined)'}\n"
        f"Mapping method: {mapping_via or 'cc_hpp_comment'}\n"
        f"Certainty: {certainty_label or 'unknown'} ({certainty or 0.0:.2f})"
    )

    if primary_synthesis:
        bm = primary_synthesis.get("business_meaning", "")
        bf = primary_synthesis.get("business_flow_narrative", "")
        if bm or bf:
            sections.append(
                f"PRIMARY LINEAGE SUMMARY ({primary_var})\n"
                f"Business meaning: {bm}\n"
                f"Flow: {bf}"
            )

    if counterpart_synthesis:
        bm = counterpart_synthesis.get("business_meaning", "")
        bf = counterpart_synthesis.get("business_flow_narrative", "")
        if bm or bf:
            sections.append(
                f"COUNTERPART LINEAGE SUMMARY ({counterpart_var})\n"
                f"Business meaning: {bm}\n"
                f"Flow: {bf}"
            )

    sections.append(
        f"YOUR TASK\n"
        f"Write a BridgeExplanation JSON explaining the relationship between "
        f"'{primary_var}' (ASM) and '{counterpart_var}' (C++).\n"
        f"- what_they_share: the business concept both variables represent\n"
        f"- how_they_connect: the cc-header link, struct field, and certainty level\n"
        f"- lineage_comparison: similarities and differences in how they are set\n"
        f"- business_implication: what this cross-language relationship means for the business process"
    )

    return "\n\n---\n\n".join(sections)


# ---------------------------------------------------------------------------
# Main entry points
# ---------------------------------------------------------------------------

def explain_step(
    kb_id: str,
    backward_session_id: str,
    session: Dict[str, Any],
    tuple_data: Dict[str, Any],
    step_index: int,
    total_steps: int,
    selected_chain: List[str],
    business_mode: bool = False,
) -> StepExplanation:
    """Generate (or return cached) StepExplanation for one tuple."""
    from process_analysis.backend.llm import call_llm_model

    idx_str = str(step_index)
    cache_key = f"b_{idx_str}" if business_mode else idx_str

    # Cache hit
    cached = (session.get("step_explanations") or {}).get(cache_key)
    if cached:
        try:
            return StepExplanation(**cached)
        except Exception:
            pass

    root_variable: str = session["root_variable"]
    prior_facts = session.get("step_facts") or {}
    prior_explanations = session.get("step_explanations") or {}

    # Load KB-level canonical business names so the LLM uses consistent names
    known_biz_names = load_biz_cache(kb_id)

    # Build deterministic reasoning scaffold
    prior_facts_list = [prior_facts[str(i)] for i in range(step_index) if str(i) in prior_facts]
    reasoning = build_step_reasoning(
        tuple_data=tuple_data,
        root_variable=root_variable,
        prior_facts=prior_facts_list,
        step_index=step_index,
    )

    prompt = _build_step_prompt(
        reasoning=reasoning,
        root_variable=root_variable,
        selected_chain=selected_chain,
        step_index=step_index,
        total_steps=total_steps,
        prior_facts=prior_facts,
        prior_explanations=prior_explanations,
        business_mode=business_mode,
        known_biz_names=known_biz_names or None,
    )

    logger.info(
        "Explaining '%s' step %d/%d — %s [%s] phase=%s",
        root_variable, step_index + 1, total_steps,
        tuple_data.get("file_stem"), tuple_data.get("file_type"), tuple_data.get("phase"),
    )

    sys_prompt = _PURE_BUSINESS_SYSTEM_PROMPT if business_mode else _BUSINESS_SYSTEM_PROMPT
    explanation = call_llm_model(prompt, StepExplanation, system_prompt=sys_prompt)

    # Persist (use separate cache keys per mode so both can coexist)
    fact = build_step_fact(reasoning)
    session.setdefault("step_explanations", {})[cache_key] = explanation.model_dump()
    # step_reasonings and step_facts are mode-independent (deterministic)
    session.setdefault("step_reasonings", {})[idx_str] = reasoning
    session.setdefault("step_facts", {})[idx_str] = fact
    session["current_step_index"] = step_index
    _save_session(kb_id, backward_session_id, session)

    # Update KB-level canonical business name cache with freshly generated names
    biz_updates: Dict[str, str] = {}
    if explanation.variable_business_name:
        current_var = reasoning.get("variable", root_variable)
        biz_updates[current_var.upper()] = explanation.variable_business_name
    for dv in (explanation.dependent_variables or []):
        dv_d = dv if isinstance(dv, dict) else dv.model_dump()
        if dv_d.get("name") and dv_d.get("business_name"):
            biz_updates[dv_d["name"].upper()] = dv_d["business_name"]
    _update_biz_cache(kb_id, biz_updates)

    return explanation


def explain_step_stream(
    kb_id: str,
    backward_session_id: str,
    session: Dict[str, Any],
    tuple_data: Dict[str, Any],
    step_index: int,
    total_steps: int,
    selected_chain: List[str],
) -> Generator[str, None, None]:
    """Stream the explanation text for one step; persist on completion."""
    from llm.caller import stream_llm
    from process_analysis.backend.llm import call_llm_model

    idx_str = str(step_index)

    # Cache hit — yield as one chunk
    cached = (session.get("step_explanations") or {}).get(idx_str)
    if cached:
        try:
            exp = StepExplanation(**cached)
            import json
            yield json.dumps(exp.model_dump())
            return
        except Exception:
            pass

    root_variable: str = session["root_variable"]
    prior_facts = session.get("step_facts") or {}
    prior_explanations = session.get("step_explanations") or {}

    prior_facts_list = [prior_facts[str(i)] for i in range(step_index) if str(i) in prior_facts]
    reasoning = build_step_reasoning(
        tuple_data=tuple_data,
        root_variable=root_variable,
        prior_facts=prior_facts_list,
        step_index=step_index,
    )

    prompt = _build_step_prompt(
        reasoning=reasoning,
        root_variable=root_variable,
        selected_chain=selected_chain,
        step_index=step_index,
        total_steps=total_steps,
        prior_facts=prior_facts,
        prior_explanations=prior_explanations,
    )

    logger.info(
        "Streaming explanation for '%s' step %d/%d — %s phase=%s",
        root_variable, step_index + 1, total_steps,
        tuple_data.get("file_stem"), tuple_data.get("phase"),
    )

    # For SSE streaming we stream raw text; then do a second structured call
    full_text = ""
    for chunk in stream_llm(prompt, system_prompt=_BUSINESS_SYSTEM_PROMPT):
        full_text += chunk
        yield chunk

    # Now produce structured output for persistence
    try:
        explanation = call_llm_model(prompt, StepExplanation, system_prompt=_BUSINESS_SYSTEM_PROMPT)
    except Exception as e:
        logger.warning("Structured output failed after stream, synthesizing from text: %s", e)
        explanation = StepExplanation(
            headline=full_text[:200] if full_text else "(explanation unavailable)",
            variable_business_name="",
            narrative=full_text or "(explanation unavailable)",
            statements=[],
            conditions=[],
            dependent_variables=[],
            what_happens_next="",
        )

    fact = build_step_fact(reasoning)
    session.setdefault("step_explanations", {})[idx_str] = explanation.model_dump()
    session.setdefault("step_reasonings", {})[idx_str] = reasoning
    session.setdefault("step_facts", {})[idx_str] = fact
    session["current_step_index"] = step_index
    _save_session(kb_id, backward_session_id, session)


def generate_synthesis(
    kb_id: str,
    backward_session_id: str,
    session: Dict[str, Any],
    business_mode: bool = False,
    roll_size: int = 12,
    progress_cb: Optional[Any] = None,
) -> SynthesisExplanation:
    """Generate the final synthesis from all completed steps.

    When total steps > roll_size, delegates to generate_synthesis_rolling for
    append-only rolling synthesis that scales to 1000+ steps without forgetting.
    """
    from process_analysis.backend.llm import call_llm_model

    synth_cache_key = "synthesis_biz" if business_mode else "synthesis"

    # Cache hit
    if session.get(synth_cache_key):
        try:
            return SynthesisExplanation(**session[synth_cache_key])
        except Exception:
            pass

    # Auto-route to rolling synthesis when step count exceeds roll_size
    step_explanations_all = session.get("step_explanations") or {}
    if business_mode:
        step_explanations = {k[2:]: v for k, v in step_explanations_all.items() if k.startswith("b_")}
    else:
        step_explanations = {k: v for k, v in step_explanations_all.items() if not k.startswith("b_")}
    if len(step_explanations) > roll_size:
        return generate_synthesis_rolling(
            kb_id=kb_id,
            backward_session_id=backward_session_id,
            session=session,
            business_mode=business_mode,
            roll_size=roll_size,
            progress_cb=progress_cb,
        )

    root_variable: str = session["root_variable"]
    selected_chain: List[str] = session.get("selected_chain") or []
    step_facts = session.get("step_facts") or {}
    step_reasonings = session.get("step_reasonings") or {}
    # step_explanations already built above (before the roll_size check)

    prompt = _build_synthesis_prompt(
        root_variable=root_variable,
        selected_chain=selected_chain,
        step_facts=step_facts,
        step_explanations=step_explanations,
        step_reasonings=step_reasonings,
        business_mode=business_mode,
    )

    sys_prompt = _PURE_BUSINESS_SYNTHESIS_PROMPT if business_mode else _SYNTHESIS_SYSTEM_PROMPT
    logger.info(
        "Generating synthesis for '%s' (%d steps, business_mode=%s)",
        root_variable, len(step_explanations), business_mode,
    )
    synthesis = call_llm_model(prompt, SynthesisExplanation, system_prompt=sys_prompt)

    session[synth_cache_key] = synthesis.model_dump()
    _save_session(kb_id, backward_session_id, session)

    # Update KB-level canonical business name cache from synthesis
    biz_updates: Dict[str, str] = {}
    if synthesis.variable_business_name:
        biz_updates[root_variable.upper()] = synthesis.variable_business_name
    for rg in (synthesis.setting_rule_groups or []):
        rg_d = rg if isinstance(rg, dict) else rg.model_dump()
        if rg_d.get("variable") and rg_d.get("business_name"):
            biz_updates[rg_d["variable"].upper()] = rg_d["business_name"]
    _update_biz_cache(kb_id, biz_updates)

    return synthesis


_ROLL_RECOMPRESS_EVERY = 6   # re-compress carry context every N rolls


def _build_roll_prompt(
    root_variable: str,
    selected_chain: List[str],
    carry_abstract: str,
    open_threads: List[str],
    setters_established: List[str],
    window_explanations: Dict[str, Any],
    window_facts: Dict[str, str],
    window_reasonings: Dict[str, Any],
    step_start: int,
    step_end: int,
    business_mode: bool = False,
) -> str:
    """Build the prompt for one roll window in generate_synthesis_rolling."""
    chain_str = " → ".join(selected_chain)
    sections: List[str] = []

    sections.append(
        f"ROLLING SYNTHESIS — variable '{root_variable}' | chain: {chain_str}\n"
        f"You are explaining one batch of steps (steps {step_start}–{step_end}) in a long lineage. "
        f"The carry context below tells the story so far. Produce a CRISP, point-based SynthesisSection that "
        f"covers EVERY step in this batch as short bullets — one fact per bullet, no filler."
    )

    if carry_abstract:
        carry_lines = [f"Story so far: {carry_abstract}"]
        if setters_established:
            carry_lines.append(f"Setters confirmed so far: {', '.join(setters_established)}")
        if open_threads:
            carry_lines.append(f"Open threads (dep vars not yet resolved): {', '.join(open_threads)}")
        sections.append("CARRY CONTEXT (story so far)\n" + "\n".join(carry_lines))

    # Step facts for this window
    fact_lines = [
        f"  Step {i}: {window_facts[str(i)]}"
        for i in sorted(int(k) for k in window_facts)
        if str(i) in window_facts
    ]
    if fact_lines:
        sections.append("STEPS IN THIS BATCH\n" + "\n".join(fact_lines))

    # Full step detail for window
    detail_parts: List[str] = []
    for i in sorted(int(k) for k in window_explanations):
        exp = window_explanations.get(str(i)) or {}
        r = window_reasonings.get(str(i)) or {}
        if not isinstance(exp, dict):
            continue
        headline = exp.get("headline") or r.get("summary") or ""
        narrative = exp.get("narrative") or ""
        conditions = exp.get("conditions") or []
        dep_vars = exp.get("dependent_variables") or []
        parts = [f"--- Step {i}: {headline}"]
        if narrative:
            parts.append(narrative[:1200])
        if conditions:
            cond_strs = [f"  • {c.get('check','')} → {c.get('in_plain_terms','')}" for c in conditions[:6]]
            parts.append("Conditions:\n" + "\n".join(cond_strs))
        if dep_vars:
            dv_strs = [f"  • {d.get('name','')} ({d.get('business_name','')}): {d.get('why_it_was_traced','')[:80]}" for d in dep_vars[:6]]
            parts.append("Dep vars:\n" + "\n".join(dv_strs))
        detail_parts.append("\n".join(parts))
    if detail_parts:
        sections.append("FULL STEP DETAIL\n" + "\n\n".join(detail_parts))

    if business_mode:
        sections.append(
            "YOUR TASK — fill in RollOutput for this batch.\n"
            "- section.title: a short title for steps {step_start}–{step_end}, e.g. 'Steps {step_start}–{step_end}: <what happens>'\n"
            "- section.narrative: CRISP bullet points covering EVERY step — one fact per bullet, no filler. Pure business "
            "language. The ONLY technical token allowed is the variable's own code name in parentheses after its business "
            "name; NO file stems (refer to each program by a business name for what it does), NO routine names, NO opcodes, "
            "NO raw statements. Enumerate EVERY condition individually and name EVERY called program/operation by what it "
            "does (never 'a few checks' / 'some other processes'). Keep concrete values (versions, codes like 'C400', counts).\n"
            "- section.setters_established, key_conditions, resolved_threads, open_threads: as appropriate.\n"
            "- carry_abstract: a short paragraph (max 200 words) replacing the prior story-so-far.\n"
            "- open_threads: dep vars introduced but not yet traced upstream.\n"
            "- setters_established: ALL setters confirmed so far (including prior rolls)."
        )
    else:
        sections.append(
            "YOUR TASK — fill in RollOutput for this batch.\n"
            "- section.title: a short title for steps {step_start}–{step_end}.\n"
            "- section.narrative: CRISP bullet points covering EVERY step — one fact per bullet, no filler. Name each "
            "variable as its business name followed by its code name in parentheses. Follow the writing design: opcode "
            "meaning in the bullet, exact statement in parentheses. Enumerate EVERY condition individually and name EVERY "
            "called process/operation specifically (never 'a few checks' / 'some other processes').\n"
            "- section.setters_established, key_conditions, resolved_threads, open_threads: as appropriate.\n"
            "- carry_abstract: a compact paragraph (max 200 words) replacing the prior story-so-far.\n"
            "- open_threads: dep vars introduced but not yet traced upstream.\n"
            "- setters_established: ALL setters confirmed so far (including prior rolls)."
        )

    return "\n\n---\n\n".join(sections)


def _build_capstone_prompt(
    root_variable: str,
    selected_chain: List[str],
    carry_abstract: str,
    open_threads: List[str],
    setters_established: List[str],
    sections: List[Dict[str, Any]],
    step_facts: Dict[str, str],
    step_reasonings: Dict[str, Any],
    business_mode: bool = False,
) -> str:
    """Build the capstone prompt that synthesises the full section index into SynthesisExplanation."""
    chain_str = " → ".join(selected_chain)
    parts: List[str] = []

    parts.append(
        f"CAPSTONE SYNTHESIS — variable '{root_variable}' | chain: {chain_str}\n"
        f"The rolling synthesis is complete. {len(sections)} section(s) were produced covering all steps. "
        f"Use the carry context and section index below to fill in SynthesisExplanation."
    )

    if carry_abstract:
        parts.append(
            f"FINAL CARRY CONTEXT\n"
            f"Story: {carry_abstract}\n"
            f"Setters confirmed: {', '.join(setters_established) or 'none'}\n"
            f"Remaining open threads: {', '.join(open_threads) or 'none'}"
        )

    # Section index — one line per section
    sec_lines = []
    for s in sections:
        if isinstance(s, dict):
            sec_lines.append(
                f"  Steps {s.get('step_start','?')}–{s.get('step_end','?')}: {s.get('title','')}"
            )
    if sec_lines:
        parts.append("SECTION INDEX (all {} sections)\n".format(len(sections)) + "\n".join(sec_lines))

    # Chain stages from step_reasonings (same logic as _build_synthesis_prompt)
    facts_by_stem: Dict[str, List[str]] = {}
    for i in sorted(int(k) for k in step_reasonings):
        r = step_reasonings.get(str(i)) or {}
        if not isinstance(r, dict):
            continue
        stem = str(r.get("file_stem") or "")
        if stem:
            facts_by_stem.setdefault(stem, []).append(step_facts.get(str(i), r.get("phase_badge", "")))
    if selected_chain:
        stage_lines = []
        for n, f in enumerate(selected_chain, start=1):
            ctx = "; ".join(x for x in (facts_by_stem.get(f) or [])[:2] if x)
            role = "ENTRY POINT" if n == 1 else ("SETTER FILE" if n == len(selected_chain) else "intermediate")
            stage_lines.append(f"  Stage {n} — file {f} ({role}): {ctx or 'passes control'}")
        parts.append("CHAIN STAGES\n" + "\n".join(stage_lines))

    if business_mode:
        parts.append(
            "YOUR TASK — fill in SynthesisExplanation (the capstone fields only).\n"
            "The ONLY technical token allowed anywhere is the variable's own code name in parentheses after its "
            "business name. NO file stems (name each program by what it does in business terms), NO routine names, "
            "NO opcodes, NO raw statements. Keep concrete values (versions, codes like 'C400', counts). Enumerate "
            "EVERY condition and name EVERY called program/operation specifically — never 'a few checks' / 'some processes'.\n"
            "- variable_business_name, chain_stages, chain_narrative: as appropriate (no file stems in prose).\n"
            "- what_it_is: 2-4 sentences on what this variable represents in the real business.\n"
            "- how_it_is_set: CRISP bullets, pure business language, no code. One fact per bullet.\n"
            "- what_had_to_be_true: CRISP bullets — every business decision, one per bullet, with the concrete value checked.\n"
            "- dependent_variables_story: CRISP bullets — one dep var per bullet, plain language.\n"
            "- full_story: short lead sentence + bullets, pure business language, no assembly. NOT paragraphs.\n"
            "- setting_rule_groups: one group per variable that gets set. Name each variable as its business name "
            "followed by its code name in parentheses. Leave `evidence` EMPTY (no raw statements in business mode).\n"
            "- sections: leave as an EMPTY LIST [] — it is pre-populated by the rolling pass."
        )
    else:
        parts.append(
            "YOUR TASK — fill in SynthesisExplanation (the capstone fields only).\n"
            "Follow the writing design for all code references (opcode meaning in prose, exact statement in parentheses).\n"
            "- variable_business_name, chain_stages, chain_narrative: as appropriate.\n"
            "- what_it_is: 2-4 sentences on the real-world business meaning.\n"
            "- how_it_is_set: CRISP bullets naming the routine, assembly op, statement. One fact per bullet.\n"
            "- what_had_to_be_true: CRISP bullets walking the full guard chain — one condition per bullet.\n"
            "- dependent_variables_story: CRISP bullets — one dep var per bullet.\n"
            "- full_story: short lead sentence + bullets — the complete end-to-end account. NOT paragraphs.\n"
            "- setting_rule_groups: one group per variable that gets set, every rule named specifically. Name each "
            "variable as its business name followed by its code name in parentheses.\n"
            "- sections: leave as an EMPTY LIST [] — it is pre-populated by the rolling pass."
        )

    return "\n\n---\n\n".join(parts)


def generate_synthesis_rolling(
    kb_id: str,
    backward_session_id: str,
    session: Dict[str, Any],
    business_mode: bool = False,
    roll_size: int = 12,
    progress_cb: Optional[Any] = None,
) -> SynthesisExplanation:
    """Rolling append-only synthesis for large lineages (> roll_size steps).

    Each roll produces one SynthesisSection (appended, never rewritten) plus an
    updated bounded carry context. A final capstone call fills the executive framing
    fields (what_it_is, how_it_is_set, full_story, …) from the carry + section index.

    Resumable: progress is persisted to the session after each roll so a re-run
    of the same job picks up from where it left off.
    """
    from process_analysis.backend.llm import call_llm_model

    synth_cache_key = "synthesis_biz" if business_mode else "synthesis"
    mode_key = "biz" if business_mode else "tech"

    # Cache hit — complete synthesis already persisted
    if session.get(synth_cache_key):
        try:
            return SynthesisExplanation(**session[synth_cache_key])
        except Exception:
            pass

    root_variable: str = session["root_variable"]
    selected_chain: List[str] = session.get("selected_chain") or []
    step_facts: Dict[str, str] = session.get("step_facts") or {}
    step_reasonings: Dict[str, Any] = session.get("step_reasonings") or {}
    step_explanations_all: Dict[str, Any] = session.get("step_explanations") or {}

    if business_mode:
        step_explanations = {k[2:]: v for k, v in step_explanations_all.items() if k.startswith("b_")}
    else:
        step_explanations = {k: v for k, v in step_explanations_all.items() if not k.startswith("b_")}

    total = len(step_explanations)
    if total == 0:
        logger.warning("generate_synthesis_rolling: no step explanations available for mode=%s", mode_key)
        return SynthesisExplanation(
            what_it_is="",
            how_it_is_set="",
            what_had_to_be_true="",
            dependent_variables_story="",
            full_story="",
        )

    all_idx = sorted(int(k) for k in step_explanations)

    # --- Resume state from session ---
    roll_state = session.setdefault("synth_roll_state", {}).setdefault(mode_key, {})
    completed_sections: List[Dict[str, Any]] = roll_state.get("sections") or []
    carry_abstract: str = roll_state.get("carry_abstract") or ""
    open_threads: List[str] = roll_state.get("open_threads") or []
    setters_established: List[str] = roll_state.get("setters_established") or []
    cursor: int = roll_state.get("cursor") or 0  # index into all_idx already processed

    sys_prompt = _PURE_BUSINESS_SYNTHESIS_PROMPT if business_mode else _SYNTHESIS_SYSTEM_PROMPT
    roll_num = len(completed_sections)  # how many rolls already done

    logger.info(
        "generate_synthesis_rolling: '%s' %d steps, roll_size=%d, mode=%s, resuming from cursor=%d",
        root_variable, total, roll_size, mode_key, cursor,
    )

    # --- Roll loop ---
    while cursor < len(all_idx):
        window_idx = all_idx[cursor: cursor + roll_size]
        step_start = window_idx[0]
        step_end = window_idx[-1]

        window_explanations = {str(i): step_explanations[str(i)] for i in window_idx if str(i) in step_explanations}
        window_facts = {str(i): step_facts[str(i)] for i in window_idx if str(i) in step_facts}
        window_reasonings = {str(i): step_reasonings[str(i)] for i in window_idx if str(i) in step_reasonings}

        prompt = _build_roll_prompt(
            root_variable=root_variable,
            selected_chain=selected_chain,
            carry_abstract=carry_abstract,
            open_threads=open_threads,
            setters_established=setters_established,
            window_explanations=window_explanations,
            window_facts=window_facts,
            window_reasonings=window_reasonings,
            step_start=step_start,
            step_end=step_end,
            business_mode=business_mode,
        )

        logger.info(
            "  roll %d: steps %d–%d (%d steps)", roll_num + 1, step_start, step_end, len(window_idx)
        )
        roll_out: RollOutput = call_llm_model(prompt, RollOutput, system_prompt=sys_prompt)

        completed_sections.append(roll_out.section.model_dump())
        carry_abstract = roll_out.carry_abstract or carry_abstract
        open_threads = roll_out.open_threads
        # Merge setters_established (accumulate, never shrink)
        for sv in roll_out.setters_established:
            if sv not in setters_established:
                setters_established.append(sv)

        cursor += len(window_idx)
        roll_num += 1

        # Persist rolling state after each roll for resumability
        roll_state["sections"] = completed_sections
        roll_state["carry_abstract"] = carry_abstract
        roll_state["open_threads"] = open_threads
        roll_state["setters_established"] = setters_established
        roll_state["cursor"] = cursor
        _save_session(kb_id, backward_session_id, session)

        if progress_cb:
            try:
                progress_cb(f"roll_{mode_key}_{roll_num}", f"Rolled steps {step_start}–{step_end}")
            except Exception:
                pass

    # --- Capstone call ---
    logger.info("  capstone: %d sections → SynthesisExplanation", len(completed_sections))
    capstone_prompt = _build_capstone_prompt(
        root_variable=root_variable,
        selected_chain=selected_chain,
        carry_abstract=carry_abstract,
        open_threads=open_threads,
        setters_established=setters_established,
        sections=completed_sections,
        step_facts=step_facts,
        step_reasonings=step_reasonings,
        business_mode=business_mode,
    )
    synthesis: SynthesisExplanation = call_llm_model(
        capstone_prompt, SynthesisExplanation, system_prompt=sys_prompt
    )
    # Attach the append-only body
    synthesis.sections = [SynthesisSection(**s) for s in completed_sections]

    session[synth_cache_key] = synthesis.model_dump()
    _save_session(kb_id, backward_session_id, session)

    if progress_cb:
        try:
            progress_cb(f"capstone_{mode_key}", "Capstone synthesis complete")
        except Exception:
            pass

    return synthesis


def generate_bridge(
    primary_var: str,
    counterpart_var: str,
    primary_language: str,
    counterpart_language: str,
    cc_header: Optional[str],
    certainty: Optional[float],
    certainty_label: Optional[str],
    mapping_via: Optional[str],
    struct_name: Optional[str],
    primary_session: Optional[Dict[str, Any]],
    counterpart_session: Optional[Dict[str, Any]],
) -> BridgeExplanation:
    """Generate the bridge explanation linking primary and counterpart lineages."""
    from process_analysis.backend.llm import call_llm_model

    primary_synthesis = (primary_session or {}).get("synthesis")
    counterpart_synthesis = (counterpart_session or {}).get("synthesis")

    prompt = _build_bridge_prompt(
        primary_var=primary_var,
        counterpart_var=counterpart_var,
        primary_language=primary_language,
        counterpart_language=counterpart_language,
        cc_header=cc_header,
        certainty=certainty,
        certainty_label=certainty_label,
        mapping_via=mapping_via,
        struct_name=struct_name,
        primary_synthesis=primary_synthesis,
        counterpart_synthesis=counterpart_synthesis,
    )

    logger.info("Generating bridge explanation: %s (%s) <-> %s (%s)", primary_var, primary_language, counterpart_var, counterpart_language)
    return call_llm_model(prompt, BridgeExplanation, system_prompt=_BRIDGE_SYSTEM_PROMPT)


def build_variable_table(session: Dict[str, Any], business_mode: bool = False) -> List[Dict[str, Any]]:
    """Build a business-language summary table of every variable that has setting logic.

    The ROW SELECTION is deterministic (root + dependent variables whose own setter
    was found — pure inputs are excluded, as before), but the ROLE and HOW-IT-IS-SET
    prose for each row is authored by the LLM from per-variable setter facts. This
    keeps the table accurate and scalable to any codebase/opcode instead of relying
    on hardcoded English templates. Result is cached on the session (per persona).
    """
    from llm.lineage_reasoning import _build_variable_graph_delta, opcode_meaning

    # Cache hit (per-persona key so business and technical tables never cross-contaminate)
    cache_key = "variable_table_biz" if business_mode else "variable_table"
    cached = session.get(cache_key)
    if cached:
        return cached

    root = str(session.get("root_variable") or "").upper()
    reasonings_map = session.get("step_reasonings") or {}
    explanations_map = session.get("step_explanations") or {}
    n = max((int(k) for k in reasonings_map), default=-1) + 1
    reasonings = [reasonings_map.get(str(i), {}) for i in range(n)]

    # business-name lookup from every step's dependent_variables + variable_business_name
    bn: Dict[str, str] = {}
    for exp in explanations_map.values():
        if not isinstance(exp, dict):
            continue
        if exp.get("variable_business_name"):
            pass
        for dv in (exp.get("dependent_variables") or []):
            name = str(dv.get("name") or "").upper()
            if name and dv.get("business_name") and name not in bn:
                bn[name] = dv["business_name"]
    syn = session.get("synthesis") or {}
    if syn.get("variable_business_name"):
        bn.setdefault(root, syn["variable_business_name"])

    # setter lookup: var → setter_detail for variables with a found setter
    setter_by_var: Dict[str, Dict[str, Any]] = {}
    for r in reasonings:
        if not isinstance(r, dict):
            continue
        v = str(r.get("variable") or "").upper()
        sd = r.get("setter_detail") or {}
        if v and sd.get("instruction") and v not in setter_by_var:
            setter_by_var[v] = sd

    graph = _build_variable_graph_delta(reasonings, n - 1, root) if n else {"nodes": []}

    # Deterministic row selection + factual context for the LLM.
    selected: List[Dict[str, Any]] = []
    for node in graph.get("nodes", []):
        name = node["id"]
        sd = setter_by_var.get(name)
        is_root = bool(node.get("is_root"))
        if not is_root and not sd:
            continue  # pure input/guard values are excluded from the table
        inst = (sd or {}).get("instruction", "")
        selected.append({
            "variable":      name,
            "business_name": bn.get(name, ""),
            "is_root":       is_root,
            "setter_inst":   inst,
            "opcode_meaning": opcode_meaning(inst),
            "routine":       (sd or {}).get("routine", ""),
            "raw_line":      ((sd or {}).get("raw_line") or "").strip(),
            "has_setter":    bool(sd),
        })

    if not selected:
        return []

    selected.sort(key=lambda r: (0 if r["is_root"] else 1, r["variable"]))

    # LLM call — author role + how_set in business prose for every selected variable.
    rows = _llm_variable_table(root, syn.get("variable_business_name", ""), selected, business_mode)

    session[cache_key] = rows
    # Persist so the (LLM-authored) table is cached across requests, not regenerated
    # on every final-step view. Older sessions without kb_id simply skip the save.
    kb_id = session.get("kb_id")
    bsid = session.get("backward_session_id")
    if kb_id and bsid:
        try:
            _save_session(kb_id, bsid, session)
        except Exception:
            pass
    return rows


def _llm_variable_table(
    root_variable: str,
    root_business_name: str,
    selected: List[Dict[str, Any]],
    business_mode: bool = False,
) -> List[Dict[str, Any]]:
    """One structured LLM call producing the role + how_set prose for each row."""
    from process_analysis.backend.llm import call_llm_model

    lines: List[str] = []
    for s in selected:
        bits = [f"variable {s['variable']}"]
        if s["business_name"]:
            bits.append(f"(business name so far: {s['business_name']})")
        bits.append("— the ROOT variable being explained" if s["is_root"] else "— a dependent variable")
        if s["has_setter"]:
            om = s["opcode_meaning"] or s["setter_inst"]
            bits.append(
                f"; its setter: `{s['raw_line'] or s['setter_inst']}`"
                + (f" in routine {s['routine']}" if s["routine"] else "")
                + (f"; the operation {s['setter_inst']} is {om}" if om else "")
            )
        lines.append("  • " + " ".join(bits))

    if business_mode:
        how_set_rule = (
            "- how_set: how it gets its value, in PURE business terms — name the program by what it does (NEVER "
            "a file stem), describe the operation plainly, and keep concrete values (the actual value written, "
            "codes like 'C400', counts). NO statements, NO routine names, NO opcodes. The ONLY code token allowed "
            "anywhere is the variable's own code name in parentheses after its business name."
        )
        tail_rule = (
            "Return one row per variable, in the same order. Be precise and COMPLETE — describe the full setting "
            "logic, never 'a few checks' / 'some processes'. NO file stems / statements / routine names; only the "
            "variable's own code in parentheses."
        )
    else:
        how_set_rule = (
            "- how_set: how it gets its value — describe the operation in business words and put the exact "
            "statement + routine in parentheses (NEVER line numbers)."
        )
        tail_rule = (
            "Return one row per variable, in the same order. Be precise, concrete and COMPLETE (never 'a few "
            "checks' / 'some processes'); never write a bare mnemonic without explaining what it does."
        )

    prompt = (
        f"You are documenting the variables involved in how '{root_variable}' "
        f"({root_business_name or 'the field being explained'}) gets its value, for a BUSINESS reader "
        f"who knows nothing about assembly.\n\n"
        f"For EACH variable below, write a VariableTableRow:\n"
        f"- variable: the code name (keep it exactly as given).\n"
        f"- business_name: a readable Title-Case business name (refine the provided one if any, else infer "
        f"it from the code name and setter).\n"
        f"- role: what part this variable plays in the lineage, in plain business English (no assembly jargon).\n"
        f"{how_set_rule}\n\n"
        f"Variables (with the factual setter evidence you must use — do not invent):\n"
        + "\n".join(lines)
        + "\n\n" + tail_rule
    )

    from api.schemas.lineage_explain import VariableTable
    sys_prompt = _PURE_BUSINESS_SYSTEM_PROMPT if business_mode else _BUSINESS_SYSTEM_PROMPT
    try:
        table = call_llm_model(prompt, VariableTable, system_prompt=sys_prompt)
        out = [r.model_dump() for r in table.rows]
        # guard: if the model dropped/renamed variables, fall back to factual stubs for any missing
        by_var = {str(r.get("variable", "")).upper(): r for r in out}
        result: List[Dict[str, Any]] = []
        for s in selected:
            r = by_var.get(s["variable"].upper())
            if r:
                r["variable"] = s["variable"]
                if not r.get("business_name"):
                    r["business_name"] = s["business_name"]
                result.append(r)
            else:
                result.append(_table_row_stub(s))
        return result
    except Exception as e:
        logger.warning("LLM variable table failed (%s); falling back to factual stubs", e)
        return [_table_row_stub(s) for s in selected]


def _table_row_stub(s: Dict[str, Any]) -> Dict[str, Any]:
    """Factual, non-LLM fallback row (only used if the LLM call fails)."""
    om = s.get("opcode_meaning") or s.get("setter_inst", "")
    raw = s.get("raw_line") or s.get("setter_inst", "")
    routine = s.get("routine", "")
    how = (
        (f"Set by {om} (`{raw}`" + (f", routine {routine}" if routine else "") + ")")
        if s.get("has_setter") else "Value arrives from outside the traced code."
    )
    return {
        "variable":      s["variable"],
        "business_name": s.get("business_name", ""),
        "role":          "The field being explained" if s.get("is_root") else "A dependent value in the lineage",
        "how_set":       how,
    }


def get_graph_delta(
    session: Dict[str, Any],
    step_index: int,
    all_reasonings: List[Dict[str, Any]],
    chain_files: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Build the graph delta for the frontend — nodes/edges visible up to this step."""
    nodes: List[Dict[str, Any]] = []
    edges: List[Dict[str, Any]] = []
    seen_nodes: set = set()
    seen_edges: set = set()

    current_stem = ""
    if step_index < len(all_reasonings):
        current_stem = all_reasonings[step_index].get("file_stem", "")

    for i, r in enumerate(all_reasonings[: step_index + 1]):
        stem = r.get("file_stem", "")
        phase = r.get("phase", "")
        phase_badge = r.get("phase_badge", phase)
        var = r.get("variable", "")
        root = r.get("root_variable", "")
        is_current = stem == current_stem and i == step_index

        if stem and stem not in seen_nodes:
            seen_nodes.add(stem)
            nodes.append({
                "id":        stem,
                "label":     stem,
                "sublabel":  var if var != root else "",
                "badge":     phase_badge,
                "kind":      "current" if is_current else "default",
                "step_order": i,
                "reason":    r.get("why_examined", "")[:120],
            })

        # Edges from cross-file calls
        for cf in (r.get("cross_file_follow") or []):
            target = cf.get("target_file", "")
            if not target:
                continue
            edge_key = (stem, target)
            if edge_key in seen_edges:
                continue
            seen_edges.add(edge_key)

            # Add target node if not seen
            if target not in seen_nodes:
                seen_nodes.add(target)
                nodes.append({
                    "id":    target,
                    "label": target,
                    "badge": "",
                    "kind":  "default",
                    "step_order": i,
                    "reason": f"called from {stem}",
                })

            # Edge label: plain-language guard or instruction
            cond_label = cf.get("instruction", "")
            df_plain = (cf.get("discovered_from_plain") or [])
            if df_plain:
                cond_label = df_plain[0][:40]

            edges.append({
                "source":         stem,
                "target":         target,
                "label":          cf.get("instruction", ""),
                "conditionHuman": cond_label,
                "step_order":     i,
            })

    return {"nodes": nodes, "edges": edges, "current_file": current_stem}
