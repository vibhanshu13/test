"""Generate business-friendly summaries for parsed source files."""

from __future__ import annotations

from pathlib import Path

from llm.caller import call_llm

_MAX_SOURCE_BYTES = 50 * 1024  # 50 KB — keeps prompt within token limits

_SYSTEM_PROMPT = (
    "You are a senior technical analyst explaining mainframe and C++ source code "
    "to non-technical business stakeholders. Analyze the full source file provided "
    "and produce a clear, jargon-free business summary. Cover: what business function "
    "this file implements, what key processes or decisions it contains, what external "
    "systems or data sources it interacts with, and what important data it manages. "
    "Do not mention register names, opcodes, memory addresses, or other low-level "
    "technical details. Write 4 to 6 sentences."
)


def generate_business_summary(file_path: Path) -> str:
    """Read *file_path* and return a business-level summary from the LLM."""
    raw = file_path.read_bytes()
    truncated = False
    if len(raw) > _MAX_SOURCE_BYTES:
        raw = raw[:_MAX_SOURCE_BYTES]
        truncated = True

    try:
        source_code = raw.decode("utf-8", errors="replace")
    except Exception:
        source_code = raw.decode("latin-1", errors="replace")

    truncation_note = (
        "\n[Note: file was truncated to 50 KB for analysis]" if truncated else ""
    )

    prompt = (
        f"File: {file_path.name}{truncation_note}\n\n"
        f"Full source code:\n{source_code}\n\n"
        "Provide a business-level summary of this file."
    )

    return call_llm(prompt, system_prompt=_SYSTEM_PROMPT)
