"""Step-by-step variable explanation driven by backward-lineage/chunks tuples.

Each explain call covers one (file_stem, variable, phase) tuple.
Context accumulates across calls via tuple_facts — structured one-liners
extracted directly from each tuple's metadata (no extra LLM call needed).
By the final tuple the accumulated story gives the LLM enough context to
produce a coherent, complete understanding of the variable's full lineage.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import msgpack

from llm.caller import call_llm, stream_llm

logger = logging.getLogger(__name__)

# Valid mainframe/C identifier: uppercase letter/underscore start, then alnum + _ # @ .
# Used to drop offset-notation fragments like "0(2," or "6(1," from compare-operand parsing.
_IDENT_RE = re.compile(r"^[A-Z_][A-Z0-9_#@.]*$")

# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = (
    "You are explaining mainframe / C++ source code to an ASM/mainframe engineer "
    "who needs full technical detail to understand, navigate, and modify this codebase. "
    "You receive one step at a time from a variable's lineage chain. "
    "Each step tells you: which file, which routine or function, which variable name, "
    "the role (setter / upstream caller / dependent variable), "
    "the relevant source instructions, and a running summary of prior steps. "
    "Write 4–6 sentences. Build on the prior context — do not repeat it. "
    "Always cite the specific instruction mnemonic (e.g. OI, MVC, STH, CLI, TM), "
    "the operands and constants used (e.g. LG#C400, =P'-2', =C'Y'), "
    "the routine or function name, the exact line numbers, "
    "and the branch conditions or guard checks that control execution. "
    "For C++ files cite the function name, the call expression, and any conditional guards. "
    "Focus on WHAT the instruction does at the bit/byte level, UNDER WHAT CONDITIONS it fires, "
    "and WHAT ROUTINE is called immediately after.\n\n"
    "COMPLETENESS: never gloss at a high level. The words 'a few', 'some', 'several', 'various', and 'a series "
    "of' are forbidden when the facts are available — enumerate EVERY condition individually and name EVERY "
    "called routine/process specifically with what it does. Never write 'goes through a few checks' or 'calls "
    "some other processes and checks their success'; list each check and each call explicitly."
)

_SYNTHESIS_SYSTEM_PROMPT = (
    "You are producing the final, unified end-to-end explanation of a mainframe variable's "
    "lineage for an ASM/mainframe engineer. You have access to every per-step explanation "
    "that has already been generated, plus the full call chain and structured facts. "
    "Synthesise these into ONE coherent narrative that explains the variable end-to-end: "
    "(a) what the variable represents in the system, "
    "(b) how it is set — the exact instruction, line, and routine, "
    "(c) the precondition chain that gates the setter (every CLC/CLI/TM compare and "
    "every conditional branch on the path to the setter), "
    "(d) which dependent variables matter and which gate each one feeds, "
    "(e) how upstream callers reach the setter and which business decision they make. "
    "Cite specific instruction mnemonics, operands, line numbers, routine names, and "
    "branch conditions throughout. Weave the steps into a coherent story rather than a flat list, "
    "but do NOT drop detail: enumerate EVERY precondition and name EVERY called routine/process specifically. "
    "The words 'a few', 'some', 'several', 'various', and 'a series of' are forbidden when the facts are "
    "available — never 'goes through a few checks' or 'calls some other processes'. "
    "Open with the variable's role; close with the business state it records when set successfully."
)

# ---------------------------------------------------------------------------
# Phase labels
# ---------------------------------------------------------------------------

_PHASE_LABELS: Dict[str, str] = {
    "modifier":              "Setter File",
    "upstream":              "Upstream Caller",
    "root_var_downstream":   "Downstream Consumer",
    "dep_var_chain":         "Dependent Variable",
    "dep_var_downstream":    "Dependent Variable (Downstream)",
    "cpp_dep_var_extended":  "Extended C++ Dependency",
}


def phase_label(phase: str) -> str:
    return _PHASE_LABELS.get(phase, phase.replace("_", " ").title())


# ---------------------------------------------------------------------------
# Session persistence
# ---------------------------------------------------------------------------

def _session_path(kb_id: str, backward_session_id: str) -> Path:
    from api.config import settings
    d = settings.JOBS_BASE_DIR / kb_id / "output" / "explain_sessions"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{backward_session_id}.msgpack"


def load_explain_session(kb_id: str, backward_session_id: str) -> Optional[Dict[str, Any]]:
    path = _session_path(kb_id, backward_session_id)
    if not path.exists():
        return None
    try:
        return msgpack.unpackb(path.read_bytes(), raw=False)
    except Exception:
        return None


def _save_session(kb_id: str, backward_session_id: str, session: Dict[str, Any]) -> None:
    path = _session_path(kb_id, backward_session_id)
    path.write_bytes(msgpack.packb(session, use_bin_type=True))


def create_explain_session(kb_id: str, backward_session_id: str, root_variable: str) -> Dict[str, Any]:
    session: Dict[str, Any] = {
        "version": 1,
        "backward_session_id": backward_session_id,
        "root_variable": root_variable.upper(),
        "current_tuple_index": 0,
        "explanations": {},   # str(idx) → full explanation text
        "tuple_facts": {},    # str(idx) → one-line structured fact (no LLM needed)
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    _save_session(kb_id, backward_session_id, session)
    return session


# ---------------------------------------------------------------------------
# tuple_fact extraction (from metadata, no LLM)
# ---------------------------------------------------------------------------

def _extract_tuple_fact(tuple_data: Dict[str, Any], root_variable: str) -> str:
    """Build a one-line structured fact from tuple metadata — used as 'story so far' context."""
    stem     = tuple_data.get("file_stem", "?")
    variable = tuple_data.get("variable", "?")
    phase    = tuple_data.get("phase", "?")
    pm       = tuple_data.get("phase_metadata") or {}

    if phase == "modifier":
        sites = pm.get("setter_sites") or []
        site_str = ""
        if sites:
            s = sites[0]
            site_str = f"{s.get('instruction','?')} at line {s.get('line','?')}"
        # Find conditions (COMPARE + BRANCH lines)
        cond_vars: List[str] = []
        for node in (tuple_data.get("nodes") or []):
            for rcl in (node.get("relevant_code_lines") or []):
                if rcl.get("role") == "COMPARE":
                    detail = rcl.get("detail", "")
                    # Extract first operand as the condition variable
                    first_op = detail.split(",")[0].strip()
                    # Drop offset-notation fragments like "0(2", "6(1", "8(R2"
                    if first_op and _IDENT_RE.match(first_op) and first_op not in cond_vars:
                        cond_vars.append(first_op)
        if cond_vars:
            cond_str = f", conditions checked: {', '.join(cond_vars[:3])}"
        else:
            # No COMPARE roles in this file means the setter has no local guards;
            # gating typically lives in the upstream caller (common for inner XHnn/DAnn writers).
            cond_str = ", no local guards (gating in upstream caller)"
        alias_str = f" (as {variable})" if variable != root_variable else ""
        return f"{stem}: {root_variable}{alias_str} set via {site_str}{cond_str}"

    elif phase == "upstream":
        calls_out = tuple_data.get("cross_file_calls_out") or []
        targets = list({c.get("target_file", "") for c in calls_out if c.get("target_file")})
        if not targets:
            # C++ nodes: cross_file_calls_out is empty; fall back to full_flow_edges
            # Only take edges where source is THIS file to avoid picking up other hops.
            for edge in (tuple_data.get("full_flow_edges") or []):
                if edge.get("source", "") == stem:
                    tgt = edge.get("target", "")
                    if tgt and tgt not in targets:
                        targets.append(tgt)
        call_str = f" → calls {', '.join(targets[:3])}" if targets else ""
        alias_str = f" (as {variable})" if variable != root_variable else ""
        return f"{stem}: upstream caller{alias_str}{call_str}"

    elif phase == "root_var_downstream":
        return f"{stem}: receives {root_variable} after it is set (downstream consumer)"

    elif phase in ("dep_var_chain", "dep_var_downstream", "cpp_dep_var_extended"):
        dep = pm.get("dep_var") or variable
        sites = pm.get("setter_sites") or []
        site_str = f" set at line {sites[0].get('line','?')}" if sites else ""
        origin = pm.get("origin_chain") or []
        # origin_chain[-1] is the file that sets root_variable; stem is the file
        # where this dep_var is computed. When they differ the dep_var crosses a
        # file boundary — say so explicitly so the LLM can name the cross-file gate.
        setter_file = origin[-1] if origin else ""
        if setter_file and setter_file != stem:
            return (
                f"{stem}: dep_var {dep}{site_str}, "
                f"must be correct for {setter_file} to set {root_variable}"
            )
        return f"{stem}: dep_var {dep}{site_str}, must be correct for {root_variable}"

    return f"{stem}: {variable} ({phase})"


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

_MAX_CODE_CHARS     = 8192   # ASM block excerpt (setter routine node)
_MAX_CPP_CODE_CHARS = 12000  # C++ function full-text (function context is critical)
_MAX_STORY_ITEMS    = 12     # max prior tuple_facts to include
_MAX_REL_LINES      = 25     # max relevant_code_lines per tuple


def _cpp_call_info(phase_metadata: Dict[str, Any]) -> List[str]:
    """Synthesise relevant-line entries for C++ upstream nodes from call metadata.

    C++ nodes have no relevant_code_lines; we reconstruct the key call-site
    facts from phase_metadata.call_sites (dx740200-style) or call_pairs
    (dx710000/dx750000-style) so the LLM always sees the actual call expression,
    target, and line number.
    """
    lines: List[str] = []
    for cs in (phase_metadata.get("call_sites") or []):
        fn   = cs.get("function", "?")
        line = cs.get("line", "?")
        inst = cs.get("instruction", "")
        tgt  = cs.get("target_entry_point", "")
        tgt_str = f" → {tgt}" if tgt else ""
        lines.append(f"  line {str(line):>5}  [CALL_SITE             ]  {inst}  {fn}(){tgt_str}")
    for cp in (phase_metadata.get("call_pairs") or []):
        caller = cp.get("caller_function", "?")
        callee = cp.get("callee_function", "?")
        line   = cp.get("line", "?")
        inst   = cp.get("instruction", "")
        lines.append(f"  line {str(line):>5}  [CALL_PAIR             ]  {inst}  {caller}() → {callee}()")
    return lines


def _format_relevant_lines(
    nodes: List[Dict[str, Any]],
    file_type: str = "asm",
    phase_metadata: Optional[Dict[str, Any]] = None,
) -> str:
    """Collect relevant_code_lines from all nodes, deduplicated by line number.

    For C++ upstream nodes that have no relevant_code_lines, falls back to
    synthesised call-site lines extracted from phase_metadata.
    """
    seen: set = set()
    lines: List[str] = []
    for node in nodes:
        for rcl in (node.get("relevant_code_lines") or []):
            lineno = rcl.get("line", 0)
            if lineno in seen:
                continue
            seen.add(lineno)
            role   = rcl.get("role", "")
            inst   = rcl.get("inst", "")
            detail = rcl.get("detail", "")
            lines.append(f"  line {lineno:5d}  [{role:<22}]  {inst}  {detail}")
            if len(lines) >= _MAX_REL_LINES:
                break
        if len(lines) >= _MAX_REL_LINES:
            break

    if not lines and file_type == "cpp" and phase_metadata:
        lines = _cpp_call_info(phase_metadata)

    return "\n".join(lines) if lines else "  (no relevant lines extracted)"


def _format_code_excerpt(
    nodes: List[Dict[str, Any]],
    phase: str = "",
    phase_metadata: Optional[Dict[str, Any]] = None,
    file_type: str = "asm",
) -> str:
    """Return a focused code excerpt for this tuple.

    Priority order:
    1. ASM modifier/dep_var: find the node whose id matches the setter routine
       so we show the exact setter block, not the program header.
    2. C++ upstream: use function_code from call_sites / call_pairs / node,
       giving the LLM the full function body where the call lives.
    3. Fallback: first node with non-empty code (original behaviour).
    """
    pm = phase_metadata or {}

    # --- ASM setter-targeted excerpt ---
    if file_type == "asm" and phase in ("modifier", "dep_var_chain", "dep_var_downstream"):
        setter_sites = pm.get("setter_sites") or []
        if setter_sites:
            target_routine = setter_sites[0].get("routine", "")
            if target_routine:
                for node in nodes:
                    if node.get("id") == target_routine:
                        code = (node.get("code") or "").strip()
                        if code:
                            truncated = code[:_MAX_CODE_CHARS]
                            suffix = "..." if len(code) > _MAX_CODE_CHARS else ""
                            return f"Routine {target_routine}:\n{truncated}{suffix}"

    # --- C++ upstream: use function_code from metadata or node ---
    if file_type == "cpp":
        # Prefer call_sites function_code (dx740200 style)
        for cs in (pm.get("call_sites") or []):
            fc = (cs.get("function_code") or "").strip()
            if fc:
                fn = cs.get("function", "")
                truncated = fc[:_MAX_CPP_CODE_CHARS]
                suffix = "..." if len(fc) > _MAX_CPP_CODE_CHARS else ""
                return f"Function {fn}:\n{truncated}{suffix}"
        # Fallback: call_pairs function_code (dx710000 / dx750000 style)
        for cp in (pm.get("call_pairs") or []):
            fc = (cp.get("function_code") or "").strip()
            if fc:
                caller = cp.get("caller_function", "")
                truncated = fc[:_MAX_CPP_CODE_CHARS]
                suffix = "..." if len(fc) > _MAX_CPP_CODE_CHARS else ""
                return f"Function {caller}:\n{truncated}{suffix}"
        # Fallback: function_code on node itself
        for node in nodes:
            fc = (node.get("function_code") or "").strip()
            if fc:
                nid = node.get("id", "")
                truncated = fc[:_MAX_CPP_CODE_CHARS]
                suffix = "..." if len(fc) > _MAX_CPP_CODE_CHARS else ""
                return f"Function {nid}:\n{truncated}{suffix}"

    # --- Original fallback: first node with non-empty code ---
    for node in nodes:
        code = (node.get("code") or "").strip()
        if code:
            nid = node.get("id", "")
            truncated = code[:_MAX_CODE_CHARS]
            suffix = "..." if len(code) > _MAX_CODE_CHARS else ""
            return f"Block {nid}:\n{truncated}{suffix}"

    return "(no source code available)"


def _format_setter_sites(phase_metadata: Dict[str, Any]) -> str:
    sites = phase_metadata.get("setter_sites") or []
    if not sites:
        return ""
    lines = []
    for s in sites[:5]:
        raw     = (s.get("raw_line") or "").strip()
        routine = s.get("routine", "")
        routine_str = f" in {routine}" if routine else ""
        lines.append(f"  line {s.get('line','?')} ({s.get('instruction','?')}){routine_str}: {raw}")
    return "\n".join(lines)


def _format_cross_file_calls(tuple_data: Dict[str, Any]) -> str:
    calls = tuple_data.get("cross_file_calls_out") or []
    if not calls:
        return ""
    parts: List[str] = []
    seen: set = set()
    for c in calls[:6]:
        target = c.get("target_file", "?")
        if target in seen:
            continue
        seen.add(target)
        inst = c.get("instruction", "")
        line = c.get("line", "?")
        parts.append(f"{target} (line {line}, {inst})")
    return ", ".join(parts)


def _load_business_summary(bp_path: str) -> str:
    """Load file-level business_summary from a blueprint msgpack file.

    Returns empty string on any failure — business_summary is a nice-to-have
    context, not load-bearing.
    """
    if not bp_path:
        return ""
    try:
        path = Path(bp_path)
        if not path.exists():
            return ""
        with open(path, "rb") as f:
            bp = msgpack.unpackb(f.read(), raw=False)
        return (bp.get("business_summary") or "").strip()
    except Exception as e:
        logger.debug("Failed to load business_summary from %s: %s", bp_path, e)
        return ""


def _phase_task(phase: str, variable: str, root_variable: str) -> str:
    if phase == "modifier":
        return (
            f"This file is the SETTER for '{root_variable}'. Explain:\n"
            f"(1) The exact setter instruction — mnemonic, operands, constants, line number, "
            f"and what the bit/byte change means at the bit level.\n"
            f"(2) The FULL precondition chain leading to the setter: every preceding subroutine "
            f"call (BAS/ENTRC), every compare (CLC/CLI/TM/CP), and every conditional branch "
            f"(BNE/BE/BZ/BNZ) that must evaluate a particular way for the setter to fire. "
            f"Cite line numbers for each.\n"
            f"(3) The business state this setter records (what real-world event/condition it represents).\n"
            f"(4) What routine/instruction runs immediately after the setter."
        )
    elif phase == "upstream":
        alias = f" (this file refers to it as '{variable}')" if variable != root_variable else ""
        return (
            f"This file is upstream of the setter for '{root_variable}'{alias} — it eventually "
            f"causes the setter to be reached. Explain:\n"
            f"(1) The function/routine in this file that issues the call moving toward the setter, "
            f"the exact call expression, and the line number.\n"
            f"(2) The immediate downstream target (the next file/function this call enters).\n"
            f"(3) Every guard condition (if/switch/TM/CLC) at the call site that must pass for "
            f"the downstream call to be reached — cite line numbers.\n"
            f"(4) The business decision this file makes that determines whether '{root_variable}' "
            f"will be touched at all."
        )
    elif phase == "root_var_downstream":
        return (
            f"This file CONSUMES '{variable}' after it has been set. Explain:\n"
            f"(1) The instruction(s) that read '{variable}' (mnemonic, operands, line number) "
            f"and what bit/value is checked.\n"
            f"(2) The business action triggered by each check outcome.\n"
            f"(3) Whether this consumer is a hard gate (blocks further processing) or a soft "
            f"branch (changes processing direction)."
        )
    else:  # dep_var_chain / dep_var_downstream / cpp_dep_var_extended
        return (
            f"'{variable}' is a DEPENDENT VARIABLE of '{root_variable}': its value must be correctly "
            f"established before '{root_variable}' can be set. Explain:\n"
            f"(1) What '{variable}' represents — length, format, business meaning.\n"
            f"(2) The instruction(s) that compute or validate '{variable}' in this file "
            f"(mnemonic, operands, line numbers).\n"
            f"(3) **Link it back to '{root_variable}'**: reference the specific gate site at the "
            f"setter (the CLC/CLI/TM line and the conditional branch) where '{variable}' is "
            f"consumed to decide whether '{root_variable}' is set. Use the STORY SO FAR for the "
            f"setter's gate context. If the link is not visible in the metadata, state that "
            f"explicitly rather than inventing one."
        )


def build_tuple_prompt(
    tuple_data: Dict[str, Any],
    root_variable: str,
    selected_chain: List[str],
    tuple_index: int,
    total_tuples: int,
    tuple_facts: Dict[str, str],
    prior_explanations: Optional[Dict[str, str]] = None,
) -> str:
    stem     = tuple_data.get("file_stem", "?")
    variable = tuple_data.get("variable", root_variable)
    phase    = tuple_data.get("phase", "?")
    summary  = tuple_data.get("summary", "")
    nodes    = tuple_data.get("nodes") or []
    pm       = tuple_data.get("phase_metadata") or {}
    bp_path  = tuple_data.get("bp_path", "")

    chain_str = " → ".join(selected_chain) if selected_chain else "(chain unknown)"

    # Section 1: goal
    goal = (
        f"ANALYSIS GOAL\n"
        f"We are building a complete step-by-step understanding of variable '{root_variable}' "
        f"through its variable-file lineage chain.\n"
        f"Full selected chain (entry point → setter): {chain_str}\n"
        f"This is step {tuple_index + 1} of {total_tuples}."
    )

    # Section 2: story so far — metadata facts + full prior LLM explanations
    story_lines: List[str] = []
    if tuple_facts and tuple_index > 0:
        # Quick-reference facts for all prior tuples
        fact_items = [
            f"  • Step {i}: {tuple_facts[str(i)]}"
            for i in range(tuple_index)
            if str(i) in tuple_facts
        ]
        if fact_items:
            story_lines.append("Quick reference (one-liner per prior step):")
            story_lines.extend(fact_items)

        # Full prior LLM explanations — Gemini handles long context, so include them all
        if prior_explanations:
            detail_items: List[str] = []
            for i in range(tuple_index):
                exp = prior_explanations.get(str(i))
                if exp:
                    detail_items.append(f"[Step {i}]\n{exp.strip()}")
            if detail_items:
                story_lines.append("")
                story_lines.append("Detailed prior explanations:")
                story_lines.append("")
                story_lines.append("\n\n".join(detail_items))

    if story_lines:
        story = "STORY SO FAR\n" + "\n".join(story_lines)
    else:
        story = "STORY SO FAR\n  (this is the first step)"

    # Section 3: file-level business context (from blueprint)
    biz = _load_business_summary(bp_path)
    if biz:
        file_context = (
            f"FILE CONTEXT — what '{stem}' does in the system\n{biz}"
        )
    else:
        file_context = ""

    # Section 4: current tuple
    if variable != root_variable:
        if phase in ("dep_var_chain", "dep_var_downstream", "cpp_dep_var_extended"):
            var_note = f" (this is a dependent variable of '{root_variable}', not an alias)"
        else:
            var_note = f" ('{root_variable}' is known by this name in this file)"
    else:
        var_note = ""
    current_header = (
        f"CURRENT STEP: {stem} | variable: {variable}{var_note} | "
        f"role: {phase_label(phase)}\n"
        f"Pre-analysis summary: {summary}"
    )

    file_type  = tuple_data.get("file_type", "asm")
    setter_str = _format_setter_sites(pm)
    rel_lines  = _format_relevant_lines(nodes, file_type=file_type, phase_metadata=pm)
    code_exc   = _format_code_excerpt(nodes, phase=phase, phase_metadata=pm, file_type=file_type)
    calls_str  = _format_cross_file_calls(tuple_data)

    data_parts = [current_header]
    if setter_str:
        data_parts.append(f"Write/setter sites:\n{setter_str}")
    data_parts.append(f"Relevant source instructions:\n{rel_lines}")
    if calls_str:
        data_parts.append(f"Cross-file calls from this block: {calls_str}")
    data_parts.append(f"Source code excerpt:\n{code_exc}")

    current_section = "\n\n".join(data_parts)

    # Section 5: task
    task = "YOUR TASK\n" + _phase_task(phase, variable, root_variable)

    sections = [goal, story]
    if file_context:
        sections.append(file_context)
    sections.append(current_section)
    sections.append(task)
    return "\n\n---\n\n".join(sections)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def explain_tuple(
    kb_id: str,
    backward_session_id: str,
    session: Dict[str, Any],
    tuple_data: Dict[str, Any],
    tuple_index: int,
    total_tuples: int,
    selected_chain: List[str],
) -> str:
    """Generate (or return cached) explanation for this tuple index."""
    idx_str = str(tuple_index)

    # Cache hit
    cached = (session.get("explanations") or {}).get(idx_str)
    if cached:
        return cached

    root_variable: str = session["root_variable"]
    tuple_facts: Dict[str, str] = session.get("tuple_facts") or {}
    prior_explanations: Dict[str, str] = session.get("explanations") or {}

    # Build and call
    prompt = build_tuple_prompt(
        tuple_data=tuple_data,
        root_variable=root_variable,
        selected_chain=selected_chain,
        tuple_index=tuple_index,
        total_tuples=total_tuples,
        tuple_facts=tuple_facts,
        prior_explanations=prior_explanations,
    )

    logger.info(
        "Explaining %s tuple %d/%d (%s, %s, %s)",
        root_variable, tuple_index + 1, total_tuples,
        tuple_data.get("file_stem"), tuple_data.get("variable"), tuple_data.get("phase"),
    )
    explanation = call_llm(prompt, system_prompt=_SYSTEM_PROMPT)

    # Persist: store explanation + extract fact for future context
    if "explanations" not in session:
        session["explanations"] = {}
    if "tuple_facts" not in session:
        session["tuple_facts"] = {}

    session["explanations"][idx_str] = explanation
    session["tuple_facts"][idx_str]   = _extract_tuple_fact(tuple_data, root_variable)
    session["current_tuple_index"]    = tuple_index

    _save_session(kb_id, backward_session_id, session)
    return explanation


def explain_tuple_stream(
    kb_id: str,
    backward_session_id: str,
    session: Dict[str, Any],
    tuple_data: Dict[str, Any],
    tuple_index: int,
    total_tuples: int,
    selected_chain: List[str],
):
    """Yield explanation text chunks; save to the explain session on completion.

    If the explanation is already cached, yields the cached text in one chunk.
    """
    idx_str = str(tuple_index)

    cached = (session.get("explanations") or {}).get(idx_str)
    if cached:
        yield cached
        return

    root_variable: str = session["root_variable"]
    tuple_facts: Dict[str, str] = session.get("tuple_facts") or {}
    prior_explanations: Dict[str, str] = session.get("explanations") or {}

    prompt = build_tuple_prompt(
        tuple_data=tuple_data,
        root_variable=root_variable,
        selected_chain=selected_chain,
        tuple_index=tuple_index,
        total_tuples=total_tuples,
        tuple_facts=tuple_facts,
        prior_explanations=prior_explanations,
    )

    logger.info(
        "Streaming explanation for %s tuple %d/%d (%s, %s, %s)",
        root_variable, tuple_index + 1, total_tuples,
        tuple_data.get("file_stem"), tuple_data.get("variable"), tuple_data.get("phase"),
    )

    full_text = ""
    for chunk in stream_llm(prompt, system_prompt=_SYSTEM_PROMPT):
        full_text += chunk
        yield chunk

    if not full_text:
        full_text = "(No explanation generated)"

    session.setdefault("explanations", {})[idx_str] = full_text
    session.setdefault("tuple_facts", {})[idx_str] = _extract_tuple_fact(tuple_data, root_variable)
    session["current_tuple_index"] = tuple_index
    _save_session(kb_id, backward_session_id, session)


# ---------------------------------------------------------------------------
# Final synthesis pass
# ---------------------------------------------------------------------------

def build_synthesis_prompt(
    root_variable: str,
    selected_chain: List[str],
    explanations: Dict[str, str],
    tuple_facts: Dict[str, str],
    index_map: Optional[List[Dict[str, Any]]] = None,
) -> str:
    """Build the prompt for the final unified explanation pass.

    Receives every per-tuple explanation and structured fact; expects the LLM
    to weave them into a single narrative covering the variable's full lineage.
    """
    chain_str = " → ".join(selected_chain) if selected_chain else "(chain unknown)"

    header = (
        f"ANALYSIS GOAL\n"
        f"Produce the FINAL, unified explanation of variable '{root_variable}'. "
        f"You will be shown the lineage chain, the structured facts for every "
        f"step, and the full per-step explanations that have already been "
        f"generated. Synthesise into a single coherent end-to-end narrative."
    )

    chain_section = f"LINEAGE CHAIN (entry point → setter)\n{chain_str}"

    # Build phase summary from index_map (if available)
    phase_lines: List[str] = []
    if index_map:
        for entry in index_map:
            idx   = entry.get("tuple_index", "?")
            file_ = entry.get("file_stem", "?")
            phase = entry.get("phase", "?")
            var   = entry.get("variable", "?")
            phase_lines.append(f"  • Step {idx} ({file_}, {phase}): variable={var}")
        phases_section = "TUPLE INDEX\n" + "\n".join(phase_lines)
    else:
        phases_section = ""

    # Compact facts
    fact_lines: List[str] = []
    if tuple_facts:
        for i in sorted(int(k) for k in tuple_facts):
            fact_lines.append(f"  • Step {i}: {tuple_facts[str(i)]}")
    facts_section = "STEP-BY-STEP FACTS\n" + ("\n".join(fact_lines) if fact_lines else "  (none)")

    # Full prior explanations
    expl_lines: List[str] = []
    if explanations:
        for i in sorted(int(k) for k in explanations):
            expl_lines.append(f"[Step {i}]\n{explanations[str(i)].strip()}")
    expls_section = (
        "PER-STEP EXPLANATIONS\n\n" + "\n\n".join(expl_lines)
        if expl_lines else "PER-STEP EXPLANATIONS\n(none)"
    )

    task = (
        "YOUR TASK\n"
        f"Write the unified end-to-end explanation of '{root_variable}' for an "
        f"ASM/mainframe engineer. Cover: (a) what '{root_variable}' represents, "
        f"(b) the exact setter (instruction, line, routine), (c) the full "
        f"precondition chain and gates, (d) the dependent variables and which "
        f"gate each one feeds, (e) how upstream callers reach the setter. "
        f"Cite instructions, line numbers, routines, and branch conditions. "
        f"Weave into a story — do NOT list each step. 10–15 sentences."
    )

    sections = [header, chain_section]
    if phases_section:
        sections.append(phases_section)
    sections.append(facts_section)
    sections.append(expls_section)
    sections.append(task)
    return "\n\n---\n\n".join(sections)


def generate_synthesis(
    root_variable: str,
    selected_chain: List[str],
    explanations: Dict[str, str],
    tuple_facts: Dict[str, str],
    index_map: Optional[List[Dict[str, Any]]] = None,
) -> str:
    """Produce the final unified explanation. One LLM call."""
    prompt = build_synthesis_prompt(
        root_variable=root_variable,
        selected_chain=selected_chain,
        explanations=explanations,
        tuple_facts=tuple_facts,
        index_map=index_map,
    )
    logger.info("Generating synthesis for %s (%d explanations)", root_variable, len(explanations))
    return call_llm(prompt, system_prompt=_SYNTHESIS_SYSTEM_PROMPT)
