"""
cross_file_flow.py — Merge block_flow.json + file_call_graph.json into a single
cross_file_block_flow.json that shows, for every block in every file, whether it
makes a cross-file call and where it goes.

Input:
  block_flow.json       — within-file block ordering (blocks[] + incoming_from)
  file_call_graph.json  — cross-file edges with call_sites[].source_block

Output:
  cross_file_block_flow.json — block_flow extended with calls_file[] on relevant blocks

Output format (new field added to blocks that make cross-file calls):
  "calls_file": [
    {
      "target_file":    "da78.asm",
      "target_block":   "$IS$",
      "instruction":    "ENTNC",
      "line":           130
    }
  ]

  When target_block could NOT be found by exact match and a fallback was used:
  "calls_file": [
    {
      "target_file":             "da78.asm",
      "target_block":            "$IS$",          <- best-effort fallback (first block)
      "target_block_unresolved": true,             <- flag: this is NOT an exact match
      "target_module_requested": "DA78",           <- what the call instruction named
      "instruction":             "CALL_ALIAS",
      "line":                    145
    }
  ]

Usage:
    python cross_file_flow.py
    python cross_file_flow.py --block-flow output_latest2/topological_sort/block_flow.json \
                               --fcg        output_latest2/file_call_graph.json \
                               --output-dir output_latest2/topological_sort
"""

import argparse
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path


ASM_XFILE_INSTRUCTIONS = {"ENTRC", "ENTNC", "ENTDC", "CREEC", "CREMC", "SWISC", "FUNCTION"}


def _first_block_id(file_entry):
    return next((b["id"] for b in file_entry.get("blocks", []) if b.get("block_order") == 1), None)


def _entry_like_ids(file_entry):
    """Return candidate externally-entered blocks for a file.

    Heuristic:
    - block_order=1 is always entry-like
    - any block directly entered from the first block is entry-like
    This preserves real labels like DA76 when $IS$ is synthetic root.
    """
    blocks = file_entry.get("blocks", [])
    first = _first_block_id(file_entry)
    if not blocks:
        return set()

    entry_like = set()
    if first:
        entry_like.add(first)
    if first:
        for b in blocks:
            incoming = b.get("incoming_from", []) or []
            if first in incoming:
                entry_like.add(b["id"])
    return entry_like


def resolve_target_block(file_entry, target_module: str, instruction: str = ""):
    """Resolve call-site target to a block in target file.

    Accurate behavior (non-strict):
    - For ASM cross-file instructions, prefer exact matches only when the matched
      block is entry-like; otherwise fall back to file entry block.
    - For non-ASM bridge calls (e.g. C++ CALL), keep exact match semantics.
    """
    if not file_entry:
        return None

    blocks = file_entry.get("blocks", [])
    first = _first_block_id(file_entry)
    entry_like = _entry_like_ids(file_entry)
    inst = (instruction or "").upper()

    exact_ci = [b["id"] for b in blocks if b["id"].upper() == (target_module or "").upper()]
    exact_cs = [b["id"] for b in blocks if b["id"] == (target_module or "")]

    if inst in ASM_XFILE_INSTRUCTIONS:
        # Prefer case-sensitive entry-like match, then case-insensitive entry-like match.
        for bid in exact_cs:
            if bid in entry_like:
                return bid
        for bid in exact_ci:
            if bid in entry_like:
                return bid
        # If exact match exists but looks internal, treat as unresolved external entry and use file entry.
        if first:
            return first
        return exact_cs[0] if exact_cs else (exact_ci[0] if exact_ci else None)

    # Non-ASM xfile calls (e.g., C++ CALL) should remain function/block precise.
    if exact_cs:
        return exact_cs[0]
    if exact_ci:
        return exact_ci[0]
    return first


def build_cross_file_flow(block_flow_path: str, fcg_path: str, output_dir: str) -> dict:
    # ── load inputs ──────────────────────────────────────────────────────────
    with open(block_flow_path) as f:
        block_flow = json.load(f)
    with open(fcg_path) as f:
        fcg = json.load(f)

    # index block_flow by file name (stem = "da78.asm") and by stem ("da78")
    file_entry_by_name = {e["file"]: e for e in block_flow["files"]}
    file_entry_by_stem = {e["stem"]: e for e in block_flow["files"]}

    # ── build calls_file_map: {file_name: {block_id: [call_info]}} ───────────
    # source: file_call_graph.json internal edges only
    calls_file_map = defaultdict(lambda: defaultdict(list))

    for edge in fcg.get("edges", []):
        if not edge.get("is_internal"):
            continue

        src_stem = edge["source"]   # e.g. "da76"
        tgt_stem = edge["target"]   # e.g. "da78"

        src_entry = file_entry_by_stem.get(src_stem)
        tgt_entry = file_entry_by_stem.get(tgt_stem)
        if not src_entry or not tgt_entry:
            continue

        src_file = src_entry["file"]   # e.g. "da76.asm"
        tgt_file = tgt_entry["file"]   # e.g. "da78.asm"

        for site in edge.get("call_sites", []):
            src_block = site.get("source_block", "")
            target_module = site.get("target_module", "")
            if not src_block:
                continue

            tgt_block = resolve_target_block(tgt_entry, target_module, site.get("instruction", ""))
            if not tgt_block:
                continue

            call_info = {
                "target_file":  tgt_file,
                "target_block": tgt_block,
                "instruction":  site.get("instruction", ""),
                "line":         site.get("line", ""),
            }

            # avoid exact duplicates on same edge (multiple call_sites with same coords)
            existing = calls_file_map[src_file][src_block]
            if call_info not in existing:
                existing.append(call_info)

    # ── merge into block_flow ─────────────────────────────────────────────────
    total_annotated = 0
    result_files = []

    for file_entry in block_flow["files"]:
        fname = file_entry["file"]
        file_calls = calls_file_map.get(fname, {})

        new_blocks = []
        for block in file_entry.get("blocks", []):
            b = dict(block)
            calls = file_calls.get(block["id"], [])
            if calls:
                b["calls_file"] = calls
                total_annotated += 1
            new_blocks.append(b)

        result_files.append({**file_entry, "blocks": new_blocks})

    result = {
        "metadata": {
            "generated_at":   datetime.now(tz=timezone.utc).isoformat(),
            "block_flow":     str(block_flow_path),
            "file_call_graph": str(fcg_path),
            "total_files":    len(result_files),
            "total_blocks":   sum(len(e["blocks"]) for e in result_files),
            "blocks_with_cross_file_calls": total_annotated,
        },
        "files": result_files,
    }

    out_path = Path(output_dir) / "cross_file_block_flow.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)

    print(f"  Saved → {out_path}")
    print(f"  {len(result_files)} files  |  "
          f"{result['metadata']['total_blocks']} total blocks  |  "
          f"{total_annotated} blocks with cross-file calls")
    return result


if __name__ == "__main__":
    import os
    os.chdir(Path(__file__).parent.parent)

    parser = argparse.ArgumentParser(
        description="Merge block_flow.json + file_call_graph.json → cross_file_block_flow.json",
        epilog="Example: python cross_file_flow.py --block-flow output_latest2/topological_sort/block_flow.json "
               "--fcg output_latest2/file_call_graph.json",
    )
    parser.add_argument(
        "--block-flow", default="output_latest2/topological_sort/block_flow.json",
        help="Path to block_flow.json (default: output_latest2/topological_sort/block_flow.json)",
    )
    parser.add_argument(
        "--fcg", default="output_latest2/file_call_graph.json",
        help="Path to file_call_graph.json (default: output_latest2/file_call_graph.json)",
    )
    parser.add_argument(
        "--output-dir", default="output_latest2/topological_sort",
        help="Directory to write cross_file_block_flow.json (default: output_latest2/topological_sort)",
    )
    args = parser.parse_args()

    build_cross_file_flow(args.block_flow, args.fcg, args.output_dir)
