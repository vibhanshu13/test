"""
topological_file_flow.py — File-level topological sort only.

Reads file_call_graph.json + scans parser_json_dir for ALL files (including
isolated ones not in file_call_graph.json), applies Kahn's algorithm on
internal edges, and writes output_latest/topological_sort/file_flow.json.

Usage:
    python topological_file_flow.py
    python topological_file_flow.py --fcg output_latest/file_call_graph.json \
                                    --parser-json-dir output_latest/asm \
                                    --output-dir output_latest/topological_sort
"""

import argparse
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List


def build_file_flow(fcg_path: str, parser_json_dir: str, output_dir: str) -> Dict:
    """
    Load file_call_graph.json + scan parser_json_dir for all files.
    Sort by dependency order. Write file_flow.json.
    Returns the result dict.
    """
    fcg_path = Path(fcg_path)
    if not fcg_path.exists():
        raise FileNotFoundError(f"file_call_graph.json not found: {fcg_path}")

    with open(fcg_path) as f:
        fcg = json.load(f)

    # Build node registry from file_call_graph nodes (skip external)
    node_map: Dict[str, Dict] = {}
    for node in fcg.get("nodes", []):
        if node.get("type") != "external":
            node_map[node["id"]] = {
                "file": node.get("file"),
                "type": node.get("type", "unknown"),
            }

    # Also scan parser_json_dir — pick up files not registered in file_call_graph
    parser_dir = Path(parser_json_dir)
    if parser_dir.exists():
        for json_file in sorted(parser_dir.glob("*.json")):
            if json_file.name.endswith(".mac.json"):
                continue
            # e.g. "da78.asm.json" → stem="da78.asm" → source_file="da78.asm", stem_id="da78"
            source_file = json_file.stem          # "da78.asm"
            stem_id = Path(source_file).stem      # "da78"
            if stem_id not in node_map:
                ext = Path(source_file).suffix.lower()
                file_type = "cpp" if ext == ".cpp" else "asm"
                node_map[stem_id] = {"file": source_file, "type": file_type}

    all_stems = list(node_map.keys())

    # Build file-level dependency graph from internal edges only
    # "source calls target" → source depends on target → target processed first
    in_degree: Dict[str, int] = {s: 0 for s in all_stems}
    dependents: Dict[str, List[str]] = defaultdict(list)
    calls_map: Dict[str, List[str]] = defaultdict(list)
    called_by_map: Dict[str, List[str]] = defaultdict(list)
    seen: set = set()

    for edge in fcg.get("edges", []):
        if not edge.get("is_internal"):
            continue
        src = edge.get("source", "")
        tgt = edge.get("target", "")
        if src not in node_map or tgt not in node_map:
            continue
        pair = (src, tgt)
        if pair in seen:
            continue
        seen.add(pair)
        in_degree[src] += 1
        dependents[tgt].append(src)
        calls_map[src].append(node_map[tgt]["file"])
        called_by_map[tgt].append(node_map[src]["file"])

    # Kahn's algorithm — callees before callers
    queue = sorted([s for s, deg in in_degree.items() if deg == 0])
    file_order: List[str] = []
    while queue:
        stem = queue.pop(0)
        file_order.append(stem)
        for dependent in sorted(dependents[stem]):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)

    # Append remaining (cycles)
    visited = set(file_order)
    file_order.extend(sorted(s for s in all_stems if s not in visited))

    # Build output entries
    asm_count = sum(1 for s in file_order if node_map[s]["type"] == "asm")
    cpp_count = sum(1 for s in file_order if node_map[s]["type"] == "cpp")
    isolated = [s for s in file_order if not calls_map.get(s) and not called_by_map.get(s)]

    entries = []
    for idx, stem in enumerate(file_order, 1):
        info = node_map[stem]
        entries.append({
            "file_order": idx,
            "file": info["file"],
            "stem": stem,
            "type": info["type"],
            "calls_files": calls_map.get(stem, []),
            "called_by_files": called_by_map.get(stem, []),
            "isolated": stem in isolated,
        })

    result = {
        "metadata": {
            "generated_at": datetime.now(tz=timezone.utc).isoformat(),
            "file_call_graph": str(fcg_path),
            "parser_json_dir": str(parser_json_dir),
            "total_files": len(file_order),
            "asm_files": asm_count,
            "cpp_files": cpp_count,
            "connected_files": len(file_order) - len(isolated),
            "isolated_files": len(isolated),
            "internal_edges": len(seen),
        },
        "file_order": entries,
    }

    out_path = Path(output_dir) / "file_flow.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)

    print(f"  Saved file_flow.json → {out_path}")
    print(f"  {len(file_order)} files total  ({asm_count} asm, {cpp_count} cpp)")
    print(f"  {len(file_order) - len(isolated)} connected  |  {len(isolated)} isolated: {[node_map[s]['file'] for s in isolated]}")
    return result


if __name__ == "__main__":
    import os
    os.chdir(Path(__file__).parent.parent)  # run from project root

    parser = argparse.ArgumentParser(
        description="Build file-level topological sort from file_call_graph.json.",
        epilog="Example: python topological_file_flow.py --fcg output_latest/file_call_graph.json --parser-json-dir output_latest/asm",
    )
    parser.add_argument(
        "--fcg", default="output_latest/file_call_graph.json",
        help="Path to file_call_graph.json (default: output_latest/file_call_graph.json)",
    )
    parser.add_argument(
        "--parser-json-dir", default="output_latest/asm",
        help="Parser JSON directory to find all files (default: output_latest/asm)",
    )
    parser.add_argument(
        "--output-dir", default="output_latest/topological_sort",
        help="Directory to write file_flow.json (default: output_latest/topological_sort)",
    )
    args = parser.parse_args()

    build_file_flow(args.fcg, args.parser_json_dir, args.output_dir)
