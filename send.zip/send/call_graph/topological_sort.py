"""
topological_sort.py — Two-level topological ordering for the business rules pipeline.

File-level order uses file_call_graph.json (internal edges only).
Within each file, scope order uses calls_internal from the scope_map.

Public API:
    build_topological_sort(parser_json_dir, scope_map, output_dir) -> List[str]
        Returns scope_map keys in processing order and writes topological_sort.json.

    sort_scopes(scope_map) -> List[str]
        Kahn's algorithm on a single scope_map dict. Used for per-file within-file ordering.
"""

import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional


# ── public entry point ────────────────────────────────────────────────────────

def build_topological_sort(
    parser_json_dir: str,
    scope_map: Dict,
    output_dir: str,
) -> List[str]:
    """
    Two-level topological sort: file order first (from file_call_graph.json),
    then within-file scope order (Kahn's on calls_internal per file).
    Writes {output_dir}/topological_sort.json.
    Returns ordered list of scope_map keys.
    """
    # 1. Group scope_map keys by file
    file_to_keys: Dict[str, List[str]] = defaultdict(list)
    for key, entry in scope_map.items():
        file_to_keys[entry["file"]].append(key)
    all_files = list(file_to_keys.keys())

    # 2. Load file_call_graph.json
    fcg_data = load_file_call_graph(parser_json_dir)

    # 3. Build stem → file_name mapping from file_call_graph nodes
    stem_to_file: Dict[str, str] = {}
    file_to_stem: Dict[str, str] = {}
    if fcg_data:
        for node in fcg_data.get("nodes", []):
            if node.get("file") and node.get("type") != "external":
                stem_to_file[node["id"]] = node["file"]
                file_to_stem[node["file"]] = node["id"]
    # Supplement with any files in scope_map not covered by file_call_graph
    for f in all_files:
        if f not in file_to_stem:
            stem = Path(f).stem
            stem_to_file[stem] = f
            file_to_stem[f] = stem

    # 4. Build file-level dependency graph from internal edges
    # "source calls target" → source depends on target → target processed first
    file_in_degree: Dict[str, int] = {f: 0 for f in all_files}
    file_dependents: Dict[str, List[str]] = defaultdict(list)
    seen_file_deps: set = set()
    if fcg_data:
        for edge in fcg_data.get("edges", []):
            if not edge.get("is_internal"):
                continue
            src_file = stem_to_file.get(edge.get("source", ""))
            tgt_file = stem_to_file.get(edge.get("target", ""))
            if (src_file and tgt_file and src_file != tgt_file
                    and src_file in file_in_degree and tgt_file in file_in_degree):
                dep_pair = (src_file, tgt_file)
                if dep_pair not in seen_file_deps:
                    seen_file_deps.add(dep_pair)
                    file_in_degree[src_file] += 1
                    file_dependents[tgt_file].append(src_file)

    # 5. Kahn's algorithm on files — callees before callers
    queue = sorted([f for f, deg in file_in_degree.items() if deg == 0])
    file_order: List[str] = []
    while queue:
        f = queue.pop(0)
        file_order.append(f)
        for dependent in sorted(file_dependents[f]):
            file_in_degree[dependent] -= 1
            if file_in_degree[dependent] == 0:
                queue.append(dependent)
    # Append remaining (cycles)
    visited_files = set(file_order)
    file_order.extend(sorted(f for f in all_files if f not in visited_files))

    # 6. Within each file: sort scopes by within-file dependency order
    all_ordered_keys: List[str] = []
    for source_file in file_order:
        keys_in_file = file_to_keys[source_file]
        if len(keys_in_file) <= 1:
            all_ordered_keys.extend(keys_in_file)
            continue
        mini_scope_map = {k: scope_map[k] for k in keys_in_file}
        all_ordered_keys.extend(sort_scopes(mini_scope_map))

    # 7. Write topological_sort.json
    _write_topological_sort_json(
        parser_json_dir, scope_map, file_order, all_ordered_keys,
        file_to_keys, file_to_stem, fcg_data, output_dir,
    )

    return all_ordered_keys


def sort_scopes(scope_map: Dict[str, Dict]) -> List[str]:
    """
    Kahn's algorithm on scope_map. Scopes with no internal dependencies first.
    Handles cycles by appending remaining nodes at the end.
    """
    in_degree: Dict[str, int] = {k: 0 for k in scope_map}
    dependents: Dict[str, List[str]] = defaultdict(list)

    for key, entry in scope_map.items():
        for dep_name in entry["calls_internal"]:
            dep_key = f"{entry['file']}::{dep_name}"
            if dep_key in scope_map:
                in_degree[key] += 1
                dependents[dep_key].append(key)

    queue = sorted([k for k, deg in in_degree.items() if deg == 0])
    result: List[str] = []

    while queue:
        node = queue.pop(0)
        result.append(node)
        for dependent in sorted(dependents[node]):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)

    # Append any nodes not reached (cycles)
    visited = set(result)
    result.extend(sorted(k for k in scope_map if k not in visited))
    return result


# ── helpers ───────────────────────────────────────────────────────────────────

def load_file_call_graph(parser_json_dir: str) -> Optional[Dict]:
    """Find and load file_call_graph.json from parser_json_dir or its parents."""
    for d in [
        Path(parser_json_dir),
        Path(parser_json_dir).parent,
        Path(parser_json_dir).parent.parent,
    ]:
        p = d / "file_call_graph.json"
        if p.exists():
            try:
                with open(p) as f:
                    return json.load(f)
            except Exception:
                pass
    return None


def _write_topological_sort_json(
    parser_json_dir: str,
    scope_map: Dict,
    file_order: List[str],
    ordered_keys: List[str],
    file_to_keys: Dict,
    file_to_stem: Dict,
    fcg_data: Optional[Dict],
    output_dir: str,
) -> None:
    """Write topological_sort.json to {output_dir}/."""
    # Build file-level calls/called_by from file_call_graph
    file_calls: Dict[str, List[str]] = defaultdict(list)
    file_called_by: Dict[str, List[str]] = defaultdict(list)
    if fcg_data:
        fcg_nodes = {n["id"]: n.get("file") for n in fcg_data.get("nodes", [])}
        seen: set = set()
        for edge in fcg_data.get("edges", []):
            if not edge.get("is_internal"):
                continue
            src_file = fcg_nodes.get(edge.get("source", ""))
            tgt_file = fcg_nodes.get(edge.get("target", ""))
            if src_file and tgt_file and src_file != tgt_file:
                pair = (src_file, tgt_file)
                if pair not in seen:
                    seen.add(pair)
                    file_calls[src_file].append(tgt_file)
                    file_called_by[tgt_file].append(src_file)

    # Build file type mapping
    file_type_map: Dict[str, str] = {}
    if fcg_data:
        for node in fcg_data.get("nodes", []):
            if node.get("file"):
                file_type_map[node["file"]] = node.get("type", "unknown")
    for f in file_order:
        if f not in file_type_map:
            file_type_map[f] = "cpp" if Path(f).suffix.lower() == ".cpp" else "asm"

    key_to_order = {key: i + 1 for i, key in enumerate(ordered_keys)}

    file_order_entries = []
    for file_idx, source_file in enumerate(file_order, 1):
        keys_in_file = file_to_keys[source_file]
        sorted_keys = sorted(keys_in_file, key=lambda k: key_to_order.get(k, 9999))
        scopes_list = [
            {
                "scope_order": sidx,
                "scope": scope_map[k]["scope"],
                "calls_internal": scope_map[k]["calls_internal"],
                "called_by": scope_map[k]["called_by"],
            }
            for sidx, k in enumerate(sorted_keys, 1)
        ]
        file_order_entries.append({
            "file_order": file_idx,
            "file": source_file,
            "stem": file_to_stem.get(source_file, Path(source_file).stem),
            "type": file_type_map.get(source_file, "asm"),
            "calls_files": file_calls.get(source_file, []),
            "called_by_files": file_called_by.get(source_file, []),
            "scopes": scopes_list,
        })

    total_scopes = sum(len(v) for v in file_to_keys.values())
    asm_count = sum(1 for f in file_order if file_type_map.get(f, "asm") == "asm")
    cpp_count = sum(1 for f in file_order if file_type_map.get(f, "asm") == "cpp")

    fcg_path = "not found"
    for d in [Path(parser_json_dir), Path(parser_json_dir).parent]:
        candidate = d / "file_call_graph.json"
        if candidate.exists():
            fcg_path = str(candidate)
            break

    topo = {
        "metadata": {
            "generated_at": datetime.now(tz=timezone.utc).isoformat(),
            "parser_json_dir": str(parser_json_dir),
            "file_call_graph": fcg_path,
            "total_files": len(file_order),
            "asm_files": asm_count,
            "cpp_files": cpp_count,
            "total_scopes": total_scopes,
        },
        "file_order": file_order_entries,
    }

    out_path = Path(output_dir) / "topological_sort.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(topo, f, indent=2)
    print(f"  Saved topological_sort.json ({len(file_order)} files, {total_scopes} scopes)")


# ── standalone entry point ────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Generate topological_sort.json from parser JSONs.",
        epilog="Example: python topological_sort.py --parser-json-dir output_latest/asm --output-dir output_latest",
    )
    parser.add_argument(
        "--parser-json-dir", default="output_latest/asm",
        help="Directory containing parser JSON files (default: output_latest/asm)",
    )
    parser.add_argument(
        "--output-dir", default="output_latest",
        help="Directory to write topological_sort.json (default: output_latest)",
    )
    args = parser.parse_args()

    # Build a minimal scope_map by reading variable_lineage.edges[].scope from each JSON
    from collections import defaultdict as _dd
    import os as _os

    _os.chdir(Path(__file__).parent.parent)  # run from project root

    parser_dir = Path(args.parser_json_dir)
    if not parser_dir.exists():
        print(f"ERROR: parser-json-dir not found: {parser_dir}")
        raise SystemExit(1)

    scope_map: Dict = {}
    for json_file in sorted(parser_dir.rglob("*.json")):
        if json_file.name.endswith(".mac.json"):
            continue
        try:
            data = json.loads(json_file.read_text())
        except Exception as e:
            print(f"  Warning: could not read {json_file.name}: {e}")
            continue

        vl = data.get("variable_lineage", {})
        edges = vl.get("edges", []) if isinstance(vl, dict) else []
        cg = data.get("call_graph", {})
        call_edges = cg.get("edges", []) if isinstance(cg, dict) else []

        # Infer source file name (stem of JSON minus the trailing .json)
        source_file = json_file.stem  # e.g. "da78.asm" from "da78.asm.json"

        scope_names: set = set()
        scope_edges_map: Dict = _dd(list)
        for e in edges:
            if isinstance(e, dict):
                s = e.get("scope")
                name = str(s).strip() if s else "(global)"
                scope_names.add(name)
                scope_edges_map[name].append(e)

        calls_by_scope: Dict = _dd(list)
        for e in call_edges:
            if isinstance(e, dict) and e.get("source"):
                calls_by_scope[str(e["source"]).strip()].append(e)

        for scope_name in scope_names:
            if not scope_edges_map[scope_name]:
                continue
            calls_internal = []
            calls_external = []
            for ce in calls_by_scope.get(scope_name, []):
                tgt = str(ce.get("target", "")).strip()
                if not tgt:
                    continue
                if tgt in scope_names and tgt != scope_name:
                    if tgt not in calls_internal:
                        calls_internal.append(tgt)
                else:
                    if tgt not in calls_external:
                        calls_external.append(tgt)

            key = f"{source_file}::{scope_name}"
            scope_map[key] = {
                "file": source_file,
                "scope": scope_name,
                "calls_internal": calls_internal,
                "calls_external": calls_external,
                "called_by": [],
            }

    # Fill called_by
    for key, entry in scope_map.items():
        for dep in entry["calls_internal"]:
            dep_key = f"{entry['file']}::{dep}"
            if dep_key in scope_map and entry["scope"] not in scope_map[dep_key]["called_by"]:
                scope_map[dep_key]["called_by"].append(entry["scope"])

    if not scope_map:
        print("No scopes found — check --parser-json-dir path.")
        raise SystemExit(1)

    print(f"  Loaded {len(scope_map)} scopes from {parser_dir}")
    build_topological_sort(args.parser_json_dir, scope_map, args.output_dir)
    print(f"  Done → {args.output_dir}/topological_sort.json")
