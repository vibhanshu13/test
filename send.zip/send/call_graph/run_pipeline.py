"""
run_pipeline.py — One-command cross-file analysis pipeline.

Runs all four steps in sequence:
  1. topological_block_flow.py  →  block_flow.json              (intermediate)
  2. file_call_graph.py         →  file_call_graph.json         (intermediate)
  3. cross_file_flow.py         →  cross_file_block_flow.json   ← backend final JSON
  4. generate_viewer.py         →  cross_file_graph_data.json   ← loaded by HTML at runtime

The HTML (cross_file_flow_viewer.html) is a static file — the pipeline never touches it.
Only cross_file_graph_data.json is updated on each run. Refresh the browser to see new data.

Usage:
    python run_pipeline.py --parser-json-dir output_latest2/asm
    python run_pipeline.py --parser-json-dir output_latest2/asm \\
                           --asm-dir   test_data_raw \\
                           --output-dir output_latest2/topological_sort

cross_file_graph_data.json is written to <output-dir>/../ (one level up),
so it sits next to cross_file_flow_viewer.html and the browser fetch() finds it.
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent

if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from topological_block_flow import build_block_flow               # step 1
from cross_file_flow import build_cross_file_flow                 # step 3
from generate_viewer import build_tree, generate_graph_data_json  # step 4


def main():
    p = argparse.ArgumentParser(
        description="Cross-file analysis pipeline → cross_file_graph_data.json",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples
--------
  python run_pipeline.py --parser-json-dir output_latest2/asm
  python run_pipeline.py --parser-json-dir output_latest2/asm --output-dir output_latest2/topological_sort

To view the result:
  cd output_latest2 && python3 -m http.server 8080
  open http://localhost:8080/cross_file_flow_viewer.html
""",
    )
    p.add_argument(
        "--parser-json-dir", required=True,
        help="Directory containing .asm.json and .cpp.json parser output files",
    )
    p.add_argument(
        "--asm-dir", default=None,
        help="Directory of raw .asm source files — improves ENTNC/CREEC detection (optional)",
    )
    p.add_argument(
        "--output-dir", default=None,
        help="Where to write intermediate JSON files "
             "(default: <parser-json-dir>/../cross_file_out/)",
    )
    args = p.parse_args()

    # ── resolve paths ─────────────────────────────────────────────────────────
    parser_json_dir = Path(args.parser_json_dir).resolve()
    if not parser_json_dir.exists():
        sys.exit(f"ERROR: --parser-json-dir not found: {parser_json_dir}")

    output_dir = (
        Path(args.output_dir).resolve()
        if args.output_dir
        else parser_json_dir.parent / "cross_file_out"
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    asm_dir = Path(args.asm_dir).resolve() if args.asm_dir else None

    # cross_file_graph_data.json lives one level up from output_dir,
    # next to the HTML so the browser fetch() resolves it correctly
    graph_data_path = output_dir.parent / "cross_file_graph_data.json"

    print(f"Parser JSON dir : {parser_json_dir}")
    print(f"Output dir      : {output_dir}")
    print(f"Viewer data out : {graph_data_path}")
    if asm_dir:
        print(f"ASM source dir  : {asm_dir}")
    print()

    # ── Step 1: block_flow.json ───────────────────────────────────────────────
    print("[1/4] Building block flow (within-file block ordering)…")
    build_block_flow(str(parser_json_dir), str(output_dir))

    # ── Step 2: file_call_graph.json ─────────────────────────────────────────
    print("\n[2/4] Building file call graph (cross-file call edges)…")
    fcg_path = output_dir / "file_call_graph.json"
    cmd = [
        sys.executable, str(SCRIPT_DIR.parent / "file_call_graph.py"),
        "--blueprint-dir", str(parser_json_dir),
        "--output", str(fcg_path),
    ]
    if asm_dir:
        cmd += ["--asm-dir", str(asm_dir)]
    result = subprocess.run(cmd, text=True, capture_output=True)
    if result.stderr.strip():
        print(result.stderr.strip())
    if result.stdout.strip():
        print(result.stdout.strip())
    if result.returncode != 0:
        sys.exit(f"ERROR: file_call_graph.py exited with code {result.returncode}")
    if not fcg_path.exists():
        sys.exit(f"ERROR: file_call_graph.py ran but {fcg_path} was not created")
    print(f"  Saved → {fcg_path}")

    # ── Step 3: cross_file_block_flow.json ───────────────────────────────────
    print("\n[3/4] Merging into cross-file block flow…")
    build_cross_file_flow(
        block_flow_path=str(output_dir / "block_flow.json"),
        fcg_path=str(fcg_path),
        output_dir=str(output_dir),
    )

    # ── Step 4: cross_file_graph_data.json ───────────────────────────────────
    print("\n[4/4] Generating viewer data JSON…")
    cf_json_path = output_dir / "cross_file_block_flow.json"
    if not cf_json_path.exists():
        sys.exit(f"ERROR: cross_file_block_flow.json not found at {cf_json_path}")

    with open(cf_json_path) as f:
        cf_data = json.load(f)

    levels, edges = build_tree(cf_data)
    total_nodes = sum(len(lv) for lv in levels)
    dup_nodes   = sum(1 for lv in levels for n in lv if n["is_dup"])
    print(f"  {len(levels)} levels | {total_nodes} nodes ({dup_nodes} duplicates) | {len(edges)} edges")

    generate_graph_data_json(levels, edges, graph_data_path)
    print(f"  Saved → {graph_data_path}")

    print(f"\nDone.")
    print(f"  Backend JSON  →  {cf_json_path}")
    print(f"  Viewer data   →  {graph_data_path}")
    print(f"\nTo view:")
    print(f"  cd {output_dir.parent} && python3 -m http.server 8080")
    print(f"  open http://localhost:8080/cross_file_flow_viewer.html")


if __name__ == "__main__":
    main()
