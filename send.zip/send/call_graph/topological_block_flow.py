"""
topological_block_flow.py — Within-file scope-level topological sort for ASM and C++ files.

ASM  (.asm.json): reads blocks[] + incoming_branches — predecessors before successors.
C++  (.cpp.json): reads variable_lineage.edges[].scope + call_graph.edges — callees before callers.

Both use the same Kahn's algorithm. Output format is identical (block_order, id, incoming_from).
Blocks that make cross-file calls also carry a calls_file[] list (from file_call_graph.json).

Writes output_latest/topological_sort/block_flow.json.

Usage:
    python topological_block_flow.py
    python topological_block_flow.py --parser-json-dir output_latest/asm \
                                     --output-dir output_latest/topological_sort
    python topological_block_flow.py --parser-json-dir output_latest/asm \
                                     --fcg output_latest/file_call_graph.json
"""

import argparse
import json
import re
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from blueprint_io import iter_flow, load_blueprint


# ── ASM ───────────────────────────────────────────────────────────────────────

def _sort_asm_blocks(blocks: List[Dict]) -> List[Dict]:
    """
    Topological sort of ASM blocks[] using incoming_branches only.
    If A appears in B's incoming_branches → A flows into B → A before B.
    Handles cycles and self-loops by appending remaining blocks at end.
    Returns ordered list with block_order, id, start_line, end_line, incoming_from.
    """
    block_ids: Set[str] = {b["id"] for b in blocks if b.get("id")}

    in_degree: Dict[str, int] = {b["id"]: 0 for b in blocks if b.get("id")}
    successors: Dict[str, List[str]] = defaultdict(list)  # A → [blocks A flows into]

    for block in blocks:
        b_id = block.get("id")
        if not b_id:
            continue
        for branch in block.get("incoming_branches", []):
            src = branch.get("source", "")
            if not src or src == "(unknown)" or src == b_id:
                continue
            if src not in block_ids:
                continue
            if b_id not in successors[src]:
                in_degree[b_id] += 1
                successors[src].append(b_id)

    queue = sorted([b for b, deg in in_degree.items() if deg == 0])
    ordered: List[str] = []
    while queue:
        node = queue.pop(0)
        ordered.append(node)
        for successor in sorted(successors[node]):
            in_degree[successor] -= 1
            if in_degree[successor] == 0:
                queue.append(successor)

    visited = set(ordered)
    ordered.extend(sorted(b for b in block_ids if b not in visited))

    block_by_id = {b["id"]: b for b in blocks if b.get("id")}
    result = []
    for idx, b_id in enumerate(ordered, 1):
        block = block_by_id[b_id]
        flow_lines = [item["line"] for item in iter_flow(block) if item.get("line")]
        # Prefer parser-provided block boundaries from blueprint JSON.
        # Fallback to flow-derived min/max only when boundaries are absent.
        start_line = block.get("start_line")
        end_line = block.get("end_line")
        if start_line is None and flow_lines:
            start_line = min(flow_lines)
        if end_line is None and flow_lines:
            end_line = max(flow_lines)
        predecessors = [
            br["source"]
            for br in block.get("incoming_branches", [])
            if br.get("source") and br["source"] != "(unknown)" and br["source"] in block_ids
        ]
        result.append({
            "block_order": idx,
            "id": b_id,
            "start_line": start_line,
            "end_line": end_line,
            "instruction_count": len(flow_lines),
            "incoming_from": predecessors,
        })
    return result


# ── C++ ──────────────────────────────────────────────────────────────────────

def _find_function_bounds(
    src_lines: List[str], func_name: str, hint_line: Optional[int]
) -> Tuple[Optional[int], Optional[int]]:
    """
    Locate the true 1-indexed start/end of a C++ function definition in source.
    Searches a window around hint_line (the vl_edges min line). Returns
    (start_line, end_line) or (None, None) when not found.

    start_line: the line containing the function name in its signature.
    end_line:   the line containing the matching closing '}'.
    Falls back gracefully — caller should keep vl-derived values on (None, None).
    """
    n = len(src_lines)
    pattern = re.compile(r'\b' + re.escape(func_name) + r'\b')

    # Search 15 lines before hint and 5 lines after to cover multi-line signatures.
    lo = max(0, (hint_line - 1 if hint_line else 0) - 15)
    hi = min(n, (hint_line - 1 if hint_line else n) + 6)

    for i in range(lo, hi):
        line = src_lines[i]
        # Skip pure comment lines — function name there is documentation, not code.
        stripped = line.lstrip()
        if stripped.startswith(("//", "*", "/*")):
            continue
        if not pattern.search(line):
            continue
        # Require '(' within the next 3 lines — distinguishes definitions/calls
        # from bare name mentions (macros, typedefs, etc.).
        has_paren = any(
            '(' in src_lines[j].split('//')[0]
            for j in range(i, min(i + 3, n))
        )
        if not has_paren:
            continue
        # Look ahead (up to 20 lines) for '{' (definition body) before ';' (declaration).
        brace_line = None
        for j in range(i, min(i + 20, n)):
            code = src_lines[j].split('//')[0]
            if '{' in code:
                brace_line = j
                break
            if ';' in code:
                break
        if brace_line is None:
            continue
        # Track brace depth from opening '{' to find the matching '}'.
        depth = 0
        end_line = None
        for k in range(brace_line, n):
            code = src_lines[k].split('//')[0]
            for ch in code:
                if ch == '{':
                    depth += 1
                elif ch == '}':
                    depth -= 1
                    if depth == 0:
                        end_line = k + 1  # convert to 1-indexed
                        break
            if end_line is not None:
                break
        if end_line is not None:
            return i + 1, end_line  # 1-indexed
    return None, None


def _sort_cpp_scopes(
    call_edges: List[Dict],
    scope_names: Set[str],
    vl_edges: List[Dict],
    src_lines: Optional[List[str]] = None,
) -> List[Dict]:
    """
    Topological sort of C++ function scopes using call_graph.edges.
    If function A calls function B → B processed before A (callee first).
    Returns ordered list with block_order, id, start_line, end_line, instruction_count, incoming_from.

    Line ranges: if src_lines is provided, _find_function_bounds() locates the true function
    signature line and closing brace by scanning the source. vl_edges min/max are used as the
    search hint and as fallback when source lookup fails.
    """
    in_degree: Dict[str, int] = {s: 0 for s in scope_names}
    # callee → [callers that depend on it]
    successors: Dict[str, List[str]] = defaultdict(list)
    seen: Set[tuple] = set()

    for edge in call_edges:
        src = str(edge.get("source", "")).strip()
        tgt = str(edge.get("target", "")).strip()
        if not src or not tgt or src == tgt:
            continue
        if src not in scope_names or tgt not in scope_names:
            continue
        pair = (src, tgt)
        if pair in seen:
            continue
        seen.add(pair)
        # src calls tgt → src depends on tgt → process tgt first
        in_degree[src] += 1
        successors[tgt].append(src)

    queue = sorted([s for s, deg in in_degree.items() if deg == 0])
    ordered: List[str] = []
    while queue:
        node = queue.pop(0)
        ordered.append(node)
        for successor in sorted(successors[node]):
            in_degree[successor] -= 1
            if in_degree[successor] == 0:
                queue.append(successor)

    visited = set(ordered)
    ordered.extend(sorted(s for s in scope_names if s not in visited))

    # incoming_from = the callees this scope depends on (already processed before it)
    callees_map: Dict[str, List[str]] = defaultdict(list)
    for edge in call_edges:
        src = str(edge.get("source", "")).strip()
        tgt = str(edge.get("target", "")).strip()
        if src in scope_names and tgt in scope_names and src != tgt:
            if tgt not in callees_map[src]:
                callees_map[src].append(tgt)

    # Build per-scope line ranges from variable_lineage edges (skip synthetic line=0 entries)
    scope_lines: Dict[str, List[int]] = defaultdict(list)
    for edge in vl_edges:
        if not isinstance(edge, dict):
            continue
        scope = str(edge.get("scope", "")).strip()
        line = edge.get("line")
        if scope in scope_names and line is not None:
            try:
                line_int = int(line)
                if line_int > 0:
                    scope_lines[scope].append(line_int)
            except (TypeError, ValueError):
                pass

    result = []
    for idx, scope in enumerate(ordered, 1):
        lines = scope_lines.get(scope, [])
        # vl-derived bounds as baseline/fallback
        vl_start = min(lines) if lines else None
        vl_end   = max(lines) if lines else None
        start_line, end_line = vl_start, vl_end
        # Refine with exact source scan when source is available
        if src_lines is not None:
            src_start, src_end = _find_function_bounds(src_lines, scope, vl_start)
            if src_start is None:
                # hint-based window missed (stale/wrong line in blueprint); scan whole file
                src_start, src_end = _find_function_bounds(src_lines, scope, None)
            if src_start is not None:
                start_line = src_start
            if src_end is not None:
                end_line = src_end
        result.append({
            "block_order": idx,
            "id": scope,
            "start_line": start_line,
            "end_line": end_line,
            "instruction_count": len(lines),
            "incoming_from": sorted(callees_map.get(scope, [])),
        })
    return result


# ── main builder ─────────────────────────────────────────────────────────────

def build_block_flow(parser_json_dir: str, output_dir: str) -> Dict:
    """
    Process all .asm.json and .cpp.json files in parser_json_dir.
    Write block_flow.json with per-file scope ordering.
    """
    parser_dir = Path(parser_json_dir)
    if not parser_dir.exists():
        raise FileNotFoundError(f"parser_json_dir not found: {parser_dir}")

    file_entries = []
    asm_count = cpp_count = total_scopes = 0

    # ── ASM files ─────────────────────────────────────────────────────────────
    for json_file in sorted(parser_dir.glob("*.asm.json")):
        try:
            # Blueprints may be plain JSON, msgpack, or compressed payloads.
            # load_blueprint() transparently decodes all supported formats.
            data = load_blueprint(
                json_file,
                skip_global_lineage=True,
                keys={"blocks"},
            )
        except Exception as e:
            print(f"  Warning: could not read {json_file.name}: {e}")
            continue

        blocks = data.get("blocks", [])
        if not blocks:
            continue

        source_file = json_file.stem  # e.g. "da78.asm"
        ordered = _sort_asm_blocks(blocks)
        total_scopes += len(ordered)
        asm_count += 1

        file_entries.append({
            "file": source_file,
            "stem": Path(source_file).stem,
            "type": "asm",
            "total_blocks": len(ordered),
            "blocks": ordered,
        })

    # ── C++ files ─────────────────────────────────────────────────────────────
    for json_file in sorted(parser_dir.glob("*.cpp.json")):
        try:
            # Blueprints may be plain JSON, msgpack, or compressed payloads.
            # load_blueprint() transparently decodes all supported formats.
            data = load_blueprint(
                json_file,
                skip_global_lineage=True,
                keys={"variable_lineage", "call_graph"},
            )
        except Exception as e:
            print(f"  Warning: could not read {json_file.name}: {e}")
            continue

        vl = data.get("variable_lineage", {})
        vl_edges = vl.get("edges", []) if isinstance(vl, dict) else []
        cg = data.get("call_graph", {})
        call_edges = cg.get("edges", []) if isinstance(cg, dict) else []

        # Collect all unique non-null scope names
        scope_names: Set[str] = set()
        for edge in vl_edges:
            if isinstance(edge, dict):
                s = edge.get("scope")
                if s and str(s).strip() and str(s).strip() != "(global)":
                    scope_names.add(str(s).strip())

        if not scope_names:
            continue

        # Try to load the actual C++ source for precise function boundary detection.
        src_lines: Optional[List[str]] = None
        for edge in vl_edges:
            src_path = edge.get("file") if isinstance(edge, dict) else None
            if src_path:
                p = Path(src_path)
                if not p.exists():
                    # Also try next to the json file (in case paths differ between machines)
                    p = json_file.parent / json_file.stem
                if p.exists():
                    try:
                        src_lines = p.read_text(errors="replace").splitlines()
                    except Exception:
                        pass
                break

        source_file = json_file.stem  # e.g. "xh890000.cpp"
        ordered = _sort_cpp_scopes(call_edges, scope_names, vl_edges, src_lines)
        if src_lines is None:
            print(f"  Warning: source file not found for {source_file}, using vl_edges line fallback")
        total_scopes += len(ordered)
        cpp_count += 1

        file_entries.append({
            "file": source_file,
            "stem": Path(source_file).stem,
            "type": "cpp",
            "total_blocks": len(ordered),
            "blocks": ordered,
        })

    result = {
        "metadata": {
            "generated_at": datetime.now(tz=timezone.utc).isoformat(),
            "parser_json_dir": str(parser_json_dir),
            "total_asm_files": asm_count,
            "total_cpp_files": cpp_count,
            "total_scopes": total_scopes,
        },
        "files": file_entries,
    }

    out_path = Path(output_dir) / "block_flow.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)

    print(f"  Saved block_flow.json → {out_path}")
    print(f"  {asm_count} ASM files  |  {cpp_count} C++ files  |  {total_scopes} scopes total")
    return result


if __name__ == "__main__":
    import os
    os.chdir(Path(__file__).parent.parent)

    parser = argparse.ArgumentParser(
        description="Build within-file scope ordering for ASM (blocks[]+incoming_branches) and C++ (call_graph.edges).",
        epilog="Example: python topological_block_flow.py --parser-json-dir output_latest/asm",
    )
    parser.add_argument(
        "--parser-json-dir", default="output_latest/asm",
        help="Directory containing .asm.json and .cpp.json files (default: output_latest/asm)",
    )
    parser.add_argument(
        "--output-dir", default="output_latest/topological_sort",
        help="Directory to write block_flow.json (default: output_latest/topological_sort)",
    )
    args = parser.parse_args()

    build_block_flow(args.parser_json_dir, args.output_dir)
