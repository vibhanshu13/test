# file_block_call_graph — Topological Sort Pipeline

Generates the two pre-requisite JSONs consumed by `business_rules_extraction/`:
- `file_flow.json` — which file to process first (cross-file dependency order)
- `block_flow.json` — which block/scope to process first within each file

These run **once before extraction**. The extraction pipeline reads them as inputs and never recomputes ordering.

---

## Scripts

| Script | Input | Output | Purpose |
|--------|-------|--------|---------|
| `file_call_graph.py` | raw `.asm` files + parser JSONs | `file_call_graph.json` | Discovers which files call which (ENTRC/ENTNC/CALL_ALIAS instructions) |
| `topological_file_flow.py` | `file_call_graph.json` + parser JSONs | `file_flow.json` | Kahn's sort on file-level call graph → file processing order |
| `topological_block_flow.py` | parser JSONs | `block_flow.json` | Kahn's sort within each file → block/scope processing order |
| `topological_sort.py` | parser JSONs | `topological_sort.json` | Standalone combined sort (reference tool, not required by pipeline) |

---

## Run Order

Step 1 must run before Step 2. Steps 2 and 3 are independent.

### Step 1 — Build file-level call graph
```bash
cd test_data_run/

python3 file_block_call_graph/file_call_graph.py \
  --blueprint-dir output_latest/asm \
  --output output_latest/file_call_graph.json
```

### Step 2 — File-level topological sort
```bash
python3 file_block_call_graph/topological_file_flow.py \
  --fcg output_latest/file_call_graph.json \
  --parser-json-dir output_latest/asm \
  --output-dir output_latest/topological_sort
```

### Step 3 — Within-file block/scope sort (ASM + C++)
```bash
python3 file_block_call_graph/topological_block_flow.py \
  --parser-json-dir output_latest/asm \
  --output-dir output_latest/topological_sort
```

---

## Output

```
output_latest/
├── file_call_graph.json           # File-level call graph (nodes + edges)
└── topological_sort/
    ├── file_flow.json             # File processing order (20 files)
    └── block_flow.json            # Block/scope order per file (ASM + C++)
```

### file_flow.json structure
```json
{
  "file_order": [
    {
      "file_order": 1,
      "file": "da76.asm",
      "stem": "da76",
      "type": "asm",
      "calls_files": ["da78.asm"],
      "called_by_files": [],
      "isolated": false
    }
  ]
}
```

### block_flow.json structure
Identical format for both ASM and C++:
```json
{
  "files": [
    {
      "file": "da78.asm",
      "type": "asm",
      "total_blocks": 67,
      "blocks": [
        {"block_order": 1, "id": "DA780000", "incoming_from": [], "start_line": 808, "end_line": 1009},
        {"block_order": 2, "id": "DA7_LVL1", "incoming_from": ["DA780000"], ...}
      ]
    },
    {
      "file": "xh890000.cpp",
      "type": "cpp",
      "total_blocks": 3,
      "blocks": [
        {"block_order": 1, "id": "deleteAllGLoSLrec", "incoming_from": []},
        {"block_order": 2, "id": "deleteGlAccount",   "incoming_from": ["deleteAllGLoSLrec"]},
        {"block_order": 3, "id": "XH89",              "incoming_from": ["deleteAllGLoSLrec", "deleteGlAccount"]}
      ]
    }
  ]
}
```

---

## Ordering Logic

**File order** (`topological_file_flow.py`):
- Source: `file_call_graph.json` internal edges only (`is_internal: true`)
- Rule: if file A calls file B → B processed first (so B's summaries are ready when processing A)
- Files not in `file_call_graph.json` → placed first, sorted alphabetically

**ASM block order** (`topological_block_flow.py`):
- Source: `blocks[]` array in each `.asm.json`, `incoming_branches` field only
- Rule: if block A appears in block B's `incoming_branches` → A processed first
- Skips: `(unknown)` sources, self-loops, cross-file references

**C++ scope order** (`topological_block_flow.py`):
- Source: `variable_lineage.edges[].scope` (scope names) + `call_graph.edges` (dependencies)
- Rule: if function A calls function B → B processed first (callee before caller)
- Same output format as ASM blocks (`block_order`, `id`, `incoming_from`)
