"""
generate_viewer.py — Build cross_file_flow_viewer.html from cross_file_block_flow.json.

Reads the JSON (which is the single source of truth for what calls what), runs a
BFS traversal to build the tree of nodes and edges, then injects the result into
the HTML template to produce the interactive viewer.

Usage:
    python generate_viewer.py
    python generate_viewer.py --input  output_latest2/topological_sort/cross_file_block_flow.json
                               --output output_latest2/cross_file_flow_viewer.html
                               --template output_latest2/cross_file_flow_viewer.html
"""

import argparse
import json
from collections import defaultdict, deque
from pathlib import Path


# ---------------------------------------------------------------------------
# BFS tree builder
# ---------------------------------------------------------------------------

def build_tree(cf_data: dict):
    """
    BFS over the cross-file call graph.

    Returns (levels, edges) where:
      levels — list of lists of node-dicts, one sublist per BFS depth
      edges  — list of edge-dicts (all arrows downward, DUP nodes ensure this)

    DUP rule: every file gets exactly ONE PRIMARY node at its shallowest BFS
    level.  Any subsequent appearance (because multiple callers point to it, or
    the same caller calls it from multiple blocks) becomes a DUP leaf placed
    directly below the node that makes the call.
    """
    file_entry = {fe["file"]: fe for fe in cf_data["files"]}
    all_files  = set(file_entry)

    # adjacency[src_file] = ordered list of call dicts, deduplicated by
    # (src_block, tgt_file, tgt_block).  A single block often contains many
    # FUNCTION calls to the same target at different line numbers; for the tree
    # we need exactly one edge per (source_block → target) pair.
    adjacency = defaultdict(list)
    for fe in cf_data["files"]:
        fname = fe["file"]
        seen_calls: set = set()
        for block in fe["blocks"]:
            for c in block.get("calls_file", []):
                if c["target_file"] not in all_files:
                    continue
                dedup_key = (block["id"], c["target_file"], c["target_block"])
                if dedup_key in seen_calls:
                    continue
                seen_calls.add(dedup_key)
                adjacency[fname].append({
                    "src_block": block["id"],
                    "src_order": block["block_order"],
                    "src_sl":    block.get("start_line"),
                    "src_el":    block.get("end_line"),
                    "tgt_file":  c["target_file"],
                    "tgt_block": c["target_block"],
                    "inst":      c["instruction"],
                    "line":      c["line"],
                })

    # Root files: no other file in the set calls them
    called_files = {c["tgt_file"] for calls in adjacency.values() for c in calls}
    roots = sorted(all_files - called_files)

    visited_primary = {}          # file → (level, cid)
    dup_counter     = defaultdict(int)  # file → next dup index
    levels_dict     = defaultdict(list)
    edges           = []

    queue = deque()
    for r in roots:
        cid = f"card-{r}"
        visited_primary[r] = (0, cid)
        queue.append({"file": r, "level": 0, "cid": cid,
                      "is_dup": False, "dup_idx": 0, "entry_from": None})

    while queue:
        item     = queue.popleft()
        cur_file = item["file"]
        cur_lv   = item["level"]
        cur_cid  = item["cid"]
        is_dup   = item["is_dup"]
        dup_idx  = item["dup_idx"]
        entry_from = item["entry_from"]

        fe = file_entry[cur_file]

        # ── entry block ───────────────────────────────────────────────────
        entry_block      = None
        entry_block_data = None
        if entry_from:
            tgt_id = entry_from["to_block"]
            for blk in fe["blocks"]:
                if blk["id"] == tgt_id:
                    entry_block = blk["id"]
                    entry_block_data = {
                        "id":    blk["id"],
                        "order": blk["block_order"],
                        "sl":    blk.get("start_line"),
                        "el":    blk.get("end_line"),
                    }
                    break

        # ── caller blocks (blocks with outgoing cross-file calls) ─────────
        caller_blocks = []
        for blk in fe["blocks"]:
            if blk.get("calls_file"):
                caller_blocks.append({
                    "id":           blk["id"],
                    "order":        blk["block_order"],
                    "sl":           blk.get("start_line"),
                    "el":           blk.get("end_line"),
                    "calls":        [{"target_file":  c["target_file"],
                                      "target_block": c["target_block"],
                                      "instruction":  c["instruction"],
                                      "line":         c["line"]}
                                     for c in blk["calls_file"]],
                    "is_also_entry": blk["id"] == entry_block,
                })

        # ── all blocks (for the detail side-panel) ────────────────────────
        all_blocks = []
        for blk in fe["blocks"]:
            all_blocks.append({
                "id":           blk["id"],
                "order":        blk["block_order"],
                "sl":           blk.get("start_line"),
                "el":           blk.get("end_line"),
                "incoming_from": blk.get("incoming_from", []),
                "calls":        [{"target_file":  c["target_file"],
                                  "target_block": c["target_block"],
                                  "instruction":  c["instruction"],
                                  "line":         c["line"]}
                                 for c in blk.get("calls_file", [])],
            })

        node = {
            "file":             cur_file,
            "ftype":            fe["type"],
            "is_dup":           is_dup,
            "dup_idx":          dup_idx,
            "cid":              cur_cid,
            "level":            cur_lv,
            "entry_from":       entry_from,
            "entry_block":      entry_block,
            "entry_block_data": entry_block_data,
            "caller_blocks":    caller_blocks,
            "all_blocks":       all_blocks,
        }
        levels_dict[cur_lv].append(node)

        # DUP nodes are leaf nodes — no children
        if is_dup:
            continue

        # ── process outgoing calls → children ─────────────────────────────
        for c in adjacency.get(cur_file, []):
            tgt_file = c["tgt_file"]
            tgt_fe   = file_entry[tgt_file]
            ef = {
                "from_file":  cur_file,
                "from_block": c["src_block"],
                "to_block":   c["tgt_block"],
                "instruction": c["inst"],
            }

            if tgt_file in visited_primary:
                # Target already has a PRIMARY → create DUP below current node
                dup_counter[tgt_file] += 1
                d_idx   = dup_counter[tgt_file]
                tgt_cid = f"card-{tgt_file}-d{d_idx}"
                queue.append({"file": tgt_file, "level": cur_lv + 1, "cid": tgt_cid,
                               "is_dup": True, "dup_idx": d_idx, "entry_from": ef})
                is_dup_tgt = True
            else:
                # First visit → PRIMARY
                tgt_cid = f"card-{tgt_file}"
                visited_primary[tgt_file] = (cur_lv + 1, tgt_cid)
                queue.append({"file": tgt_file, "level": cur_lv + 1, "cid": tgt_cid,
                               "is_dup": False, "dup_idx": 0, "entry_from": ef})
                is_dup_tgt = False

            edges.append({
                "from_cid":    cur_cid,
                "from_block":  c["src_block"],
                "from_file":   cur_file,
                "to_cid":      tgt_cid,
                "to_file":     tgt_file,
                "to_block":    c["tgt_block"],
                "instruction": c["inst"],
                "from_type":   fe["type"],
                "to_type":     tgt_fe["type"],
                "is_dup_target": is_dup_tgt,
            })

    max_lv = max(levels_dict) if levels_dict else 0
    levels = [levels_dict.get(i, []) for i in range(max_lv + 1)]
    return levels, edges


# ---------------------------------------------------------------------------
# HTML generation
# ---------------------------------------------------------------------------

def generate_html(levels, edges, template_path: Path) -> str:
    """Inject levels + edges JSON into the HTML template."""
    with open(template_path) as f:
        lines = f.readlines()

    # Find the two data lines by prefix so this works even if line numbers shift
    before_lines, after_lines = [], []
    in_data = False
    data_count = 0

    for line in lines:
        stripped = line.lstrip()
        is_levels = stripped.startswith("const levels ")
        is_edges  = stripped.startswith("const edges ")
        if is_levels or is_edges:
            data_count += 1
            in_data = True
            continue
        if in_data and data_count >= 2:
            in_data = False
        if not in_data or data_count < 2:
            if data_count == 0:
                before_lines.append(line)
            else:
                after_lines.append(line)

    levels_json = json.dumps(levels, separators=(",", ":"))
    edges_json  = json.dumps(edges,  separators=(",", ":"))

    return (
        "".join(before_lines)
        + f"const levels = {levels_json};\n"
        + f"const edges  = {edges_json};\n"
        + "".join(after_lines)
    )


def generate_graph_data_json(levels, edges, output_path: Path) -> None:
    """Write the pre-computed BFS tree as cross_file_graph_data.json.

    The viewer HTML fetches this file at runtime — no data is embedded in the HTML.
    This is the single final JSON consumed by the frontend.
    """
    data = {"levels": levels, "edges": edges}
    output_path.write_text(json.dumps(data, separators=(",", ":")))


def generate_data_js(levels, edges, output_path: Path) -> None:
    """Write levels + edges as a JS sidecar file (cross_file_data.js).

    Kept for backwards compatibility. Prefer generate_graph_data_json() for
    clean JSON/HTML separation.
    """
    levels_json = json.dumps(levels, separators=(",", ":"))
    edges_json  = json.dumps(edges,  separators=(",", ":"))
    output_path.write_text(
        f"const levels = {levels_json};\n"
        f"const edges  = {edges_json};\n"
    )


def make_html_dynamic(html_path: Path) -> bool:
    """Strip embedded const levels/edges from the HTML and add a
    <script src="cross_file_data.js"> tag so the HTML loads data externally.

    Idempotent — safe to call on every pipeline run.
    Returns True if the HTML was modified, False if already dynamic.
    """
    lines = html_path.read_text().splitlines(keepends=True)

    has_src  = any('src="cross_file_data.js"' in l for l in lines)
    has_data = any(l.lstrip().startswith("const levels ") for l in lines)

    if has_src and not has_data:
        return False  # Already dynamic

    # Split into before / after using same logic as generate_html()
    before_lines, after_lines = [], []
    in_data    = False
    data_count = 0

    for line in lines:
        stripped  = line.lstrip()
        is_levels = stripped.startswith("const levels ")
        is_edges  = stripped.startswith("const edges ")
        if is_levels or is_edges:
            data_count += 1
            in_data = True
            continue
        if in_data and data_count >= 2:
            in_data = False
        if not in_data or data_count < 2:
            if data_count == 0:
                before_lines.append(line)
            else:
                after_lines.append(line)

    if data_count == 0:
        return False  # No embedded data found — nothing to strip

    # Insert <script src="cross_file_data.js"></script> before the opening
    # <script> tag at the end of before_lines.
    script_idx = None
    for i in range(len(before_lines) - 1, max(len(before_lines) - 10, -1), -1):
        if before_lines[i].strip() == "<script>":
            script_idx = i
            break

    if script_idx is not None:
        before_lines.insert(script_idx, '<script src="cross_file_data.js"></script>\n')
    else:
        before_lines.append('<script src="cross_file_data.js"></script>\n')

    html_path.write_text("".join(before_lines) + "".join(after_lines))
    return True


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    import os
    os.chdir(Path(__file__).parent.parent)

    p = argparse.ArgumentParser(description="Generate cross_file_flow_viewer.html from cross_file_block_flow.json")
    p.add_argument("--input",    default="output_latest2/topological_sort/cross_file_block_flow.json",
                   help="Path to cross_file_block_flow.json")
    p.add_argument("--template", default="output_latest2/cross_file_flow_viewer.html",
                   help="Existing viewer HTML used as template (only CSS/JS kept, data replaced)")
    p.add_argument("--output",   default="output_latest2/cross_file_flow_viewer.html",
                   help="Where to write the new viewer HTML")
    args = p.parse_args()

    cf_path = Path(args.input)
    if not cf_path.exists():
        raise FileNotFoundError(f"Input not found: {cf_path}")
    template_path = Path(args.template)
    if not template_path.exists():
        raise FileNotFoundError(f"Template not found: {template_path}")

    print(f"Reading  {cf_path}")
    with open(cf_path) as f:
        cf_data = json.load(f)
    m = cf_data["metadata"]
    print(f"  {m['total_files']} files | {m['total_blocks']} blocks | "
          f"{m['blocks_with_cross_file_calls']} blocks with cross-file calls")

    print("Building BFS tree …")
    levels, edges = build_tree(cf_data)
    total_nodes = sum(len(lv) for lv in levels)
    dup_nodes   = sum(1 for lv in levels for n in lv if n["is_dup"])
    print(f"  {len(levels)} levels | {total_nodes} nodes ({dup_nodes} duplicates) | {len(edges)} edges")

    print(f"Using template {template_path}")
    html = generate_html(levels, edges, template_path)

    out_path = Path(args.output)
    out_path.write_text(html)
    print(f"Saved  → {out_path}  ({len(html):,} bytes)")


if __name__ == "__main__":
    main()
