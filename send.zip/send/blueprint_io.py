"""Blueprint I/O helpers: load blueprints and iterate flow entries (T2+T3).

Format detection for load_blueprint():
  - JSON  : first byte is 0x7b (ASCII '{')
  - msgpack: any other first byte (map16 0xde, fixmap 0x8x, etc.)

On-disk formats
---------------
Legacy (monolithic): zstd( msgpack(full_dict) ) or gzip( msgpack ) or raw JSON.
  Written by pack_blueprint().  Detected by absence of a .bpidx sidecar file.

Seekable (per-key frames): concatenated independent zstd frames, one per
  top-level key, with a companion .bpidx sidecar that maps key → {offset, len}.
  Written by write_blueprint().  Detected by presence of the .bpidx file.

  Disk footprint: ~9–10 GB for 22K files (vs 8 GB monolithic) because
  per-key frames have slightly less compression context.  The trade-off is
  that load_blueprint(..., keys={k}) reads only that key's frame (~300 bytes
  for business_summary) instead of the full 8–15 MB blueprint file.

Flow format detection for iter_flow():
  - Old format : "flow" is a list of entry dicts
  - New columnar: "flow" is a dict with keys "l", "i", "a", "v", "x"

Global lineage injection:
  global_variable_lineage was previously embedded in every per-file blueprint
  (causing O(N) storage blowup for large codebases).  It is now written once as
  global_variable_lineage.json in the same output directory.  load_blueprint()
  injects a shared reference so all downstream consumers continue to see it at
  bp["global_variable_lineage"] without any code changes — and without the N-fold
  memory replication.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional, Set, Union

# Per-directory cache: blueprint_dir_str → LazyGVL proxy.
# All blueprint dicts in the same directory share the exact same LazyGVL
# object.  The GVL file is never loaded into RAM — nodes/edges are streamed
# from disk on demand so peak allocation is O(one_item) regardless of file
# size (7.78 GB on large corpora).
_global_lineage_cache: Dict[str, Any] = {}

# Sidecar index suffix used by the seekable per-key frame format.
_BPIDX_SUFFIX = ".bpidx"


def iter_flow(block: Dict[str, Any]) -> Generator[Dict[str, Any], None, None]:
    """Yield flow entry dicts from a block, handling both old and columnar formats.

    Old format (list-of-dicts)::

        "flow": [{"line": 10, "inst": "MVC", "var": "X", "val": "Y"}, ...]

    New columnar format (T2)::

        "flow": {"l": [10, ...], "i": ["MVC", ...], "a": [null, ...],
                 "v": ["X", ...], "x": ["Y", ...]}

    In the columnar format entries with a ``var`` value use ``v``/``x`` columns;
    entries without use the ``a`` (args) column.
    """
    flow = block.get("flow") or []
    if isinstance(flow, list):
        yield from flow
        return

    # Columnar format
    lines = flow.get("l") or []
    insts = flow.get("i") or []
    args_col = flow.get("a") or []
    var_col = flow.get("v") or []
    val_col = flow.get("x") or []

    for idx in range(len(lines)):
        var = var_col[idx] if idx < len(var_col) else None
        if var is not None:
            yield {
                "line": lines[idx],
                "inst": insts[idx] if idx < len(insts) else "",
                "var": var,
                "val": val_col[idx] if idx < len(val_col) else None,
            }
        else:
            yield {
                "line": lines[idx],
                "inst": insts[idx] if idx < len(insts) else "",
                "args": args_col[idx] if idx < len(args_col) else [],
            }


_ZSTD_MAGIC = b"\x28\xb5\x2f\xfd"  # zstd frame magic bytes
_GZIP_MAGIC = b"\x1f\x8b"           # gzip magic bytes


def _decompress_if_needed(raw: bytes) -> bytes:
    """Transparently decompress zstd or gzip-compressed data."""
    if raw[:4] == _ZSTD_MAGIC:
        try:
            import zstandard  # type: ignore[import]
        except ImportError:
            raise RuntimeError(
                "Blueprint is zstd-compressed but zstandard is not installed.\n"
                "Run: pip install zstandard"
            )
        dctx = zstandard.ZstdDecompressor()
        try:
            # Fast path: single-shot decompression when content size is in frame.
            return dctx.decompress(raw)
        except zstandard.ZstdError:
            # Streaming-written frames omit the content size header field.
            # Fall back to stream_reader which works regardless of frame type.
            with dctx.stream_reader(raw) as reader:
                return reader.read()
    if raw[:2] == _GZIP_MAGIC:
        import gzip
        return gzip.decompress(raw)
    return raw


def _decode_bytes(raw: bytes) -> Dict[str, Any]:
    """Decode raw bytes as JSON or msgpack (with optional zstd/gzip decompression)."""
    if not raw:
        return {}
    raw = _decompress_if_needed(raw)
    if raw[0] == ord("{"):
        return json.loads(raw.decode("utf-8"))
    import msgpack  # type: ignore[import]
    return msgpack.unpackb(raw, raw=False, strict_map_key=False)


def _get_global_lineage(blueprint_path: Path):
    """Return (and cache) a LazyGVL proxy for a blueprint's directory.

    Searches for ``global_variable_lineage.json`` (or its msgpack equivalent)
    first in the same directory as the blueprint, then one level up (for nested
    layouts such as ``output/asm/``).

    Returns a ``LazyGVL`` proxy that streams nodes/edges from disk on demand —
    the full 7.78 GB file is never loaded into RAM.  The proxy is falsy when
    the GVL file cannot be found (same semantics as returning ``{}``).
    """
    bdir_str = str(blueprint_path.parent.resolve())
    if bdir_str in _global_lineage_cache:
        return _global_lineage_cache[bdir_str]

    from backward_traversal.utils.lazy_gvl import LazyGVL, find_gvl_path
    gvl_path = find_gvl_path(blueprint_path)
    proxy = LazyGVL(gvl_path)
    _global_lineage_cache[bdir_str] = proxy
    return proxy


# ---------------------------------------------------------------------------
# LazyBlueprint — lazy per-key loading proxy
# ---------------------------------------------------------------------------

class LazyBlueprint(dict):
    """Blueprint dict that loads top-level keys lazily from a ``.bpidx`` sidecar.

    Returned by :func:`load_blueprint` when a ``.bpidx`` sidecar exists and no
    explicit ``keys=`` filter is provided.  Each top-level key (``blocks``,
    ``call_graph``, ``variable_lineage``, …) is decompressed from its own zstd
    frame only on the **first** ``bp.get(key)`` or ``bp[key]`` access.  Once
    loaded the value is stored in the underlying ``dict`` so subsequent accesses
    are O(1) dict look-ups with no further I/O.

    Unused keys — ``line_metadata``, ``macro_expansions``, ``build_metadata``,
    etc. — are **never** loaded.  For a typical backward traversal this cuts
    peak cold-read RAM per blueprint from ~15 MB (all keys decoded) to ~3–5 MB
    (only the handful of keys actually accessed).

    Design notes
    ------------
    * Subclasses ``dict`` so ``isinstance(bp, dict)`` guards in the codebase
      pass unchanged.
    * Injected metadata (``_gvl_path``, ``_gvl_db_path``, ``_gvl_job_id``)
      is set by :func:`blueprint_utils._load_json_cached` after construction
      via normal ``bp[key] = value`` assignment — these keys are NOT in the
      sidecar so ``__missing__`` is never triggered for them.
    * ``dict.get()`` does **not** call ``__missing__``, so ``get()`` is
      overridden to route through ``self[key]``.
    * ``__contains__`` returns ``True`` for any key present in the sidecar
      (even if not yet loaded) so ``if "blocks" in bp`` works correctly.
    """

    __slots__ = ("_bp_path", "_sidecar")

    def __init__(self, path: Path, sidecar: Dict[str, Any]) -> None:
        super().__init__()
        self._bp_path: Path = path
        self._sidecar: Dict[str, Any] = sidecar

    # ------------------------------------------------------------------
    # Lazy loading hooks
    # ------------------------------------------------------------------

    def __missing__(self, key: str) -> Any:
        """Load a single key's zstd frame on first access and cache it."""
        if key not in self._sidecar.get("keys", {}):
            raise KeyError(key)
        frame_data = _load_frames_partial(self._bp_path, self._sidecar, {key})
        val = frame_data.get(key)
        # Store in the underlying dict so future accesses are free.
        super().__setitem__(key, val)
        return val

    def get(self, key: str, default: Any = None) -> Any:  # type: ignore[override]
        """Return value for *key*, lazy-loading its frame if necessary."""
        try:
            return self[key]
        except KeyError:
            return default

    def __contains__(self, key: object) -> bool:
        """Return True if *key* is loaded OR exists in the sidecar index."""
        return dict.__contains__(self, key) or (
            isinstance(key, str) and key in self._sidecar.get("keys", {})
        )

    # ------------------------------------------------------------------
    # Full-dict iteration — required so write_blueprint() and similar
    # dict consumers see ALL keys (sidecar + injected), not only the
    # subset that has been loaded so far.
    # ------------------------------------------------------------------

    def keys(self):  # type: ignore[override]
        """Return all keys: already-loaded dict keys + unloaded sidecar keys.

        Returns a list (not a set) so iteration order is deterministic and
        consistent with ``items()`` — loaded/injected keys first, then
        unloaded sidecar keys in sidecar-index order.
        """
        loaded = set(dict.keys(self))
        result = list(dict.keys(self))
        for k in self._sidecar.get("keys", {}):
            if k not in loaded:
                result.append(k)
        return result

    def __iter__(self):  # type: ignore[override]
        """Iterate all available keys (sidecar + loaded injected keys)."""
        return iter(self.keys())

    def __len__(self) -> int:  # type: ignore[override]
        """Total key count: sidecar keys + any extra injected keys."""
        return len(self.keys())

    def items(self):  # type: ignore[override]
        """Yield (key, value) pairs, lazy-loading each sidecar key on demand.

        Already-loaded and injected keys are yielded first (no I/O).
        Remaining sidecar keys are loaded one frame at a time via
        ``__missing__``.
        """
        loaded_keys = set(dict.keys(self))
        for k, v in dict.items(self):
            yield k, v
        for k in self._sidecar.get("keys", {}):
            if k not in loaded_keys:
                yield k, self[k]  # triggers __missing__, caches result

    def values(self):  # type: ignore[override]
        """Yield all values, lazy-loading sidecar keys on demand."""
        for _, v in self.items():
            yield v

    def __repr__(self) -> str:  # pragma: no cover
        loaded = set(dict.keys(self)) - {"_gvl_path", "_gvl_db_path", "_gvl_job_id"}
        available = set(self._sidecar.get("keys", {}).keys())
        return (
            f"LazyBlueprint({self._bp_path.name!r}, "
            f"loaded={sorted(loaded)}, available={sorted(available)})"
        )


# ---------------------------------------------------------------------------
# Seekable per-key frame helpers
# ---------------------------------------------------------------------------

def _sidecar_path(blueprint_path: Path) -> Path:
    """Return the .bpidx sidecar index path for a blueprint file."""
    return Path(str(blueprint_path) + _BPIDX_SUFFIX)


def _try_load_sidecar(path: Path) -> Optional[Dict[str, Any]]:
    """Return the parsed .bpidx sidecar dict if present and valid, else None."""
    sp = _sidecar_path(path)
    if not sp.exists():
        return None
    try:
        return json.loads(sp.read_text(encoding="utf-8"))
    except Exception:
        return None


def _load_frames_partial(
    path: Path, sidecar: Dict[str, Any], keys: Set[str]
) -> Dict[str, Any]:
    """Seek-load only the requested keys from a seekable-frame blueprint.

    For each requested key the function seeks directly to its frame offset,
    reads exactly ``len`` bytes, decompresses the single zstd frame, and
    unpacks the msgpack value — without reading or decompressing any other
    frame.

    Peak RAM per call = O(largest single requested frame decompressed)
    instead of O(entire blueprint decompressed).
    """
    import msgpack  # type: ignore[import]
    import zstandard  # type: ignore[import]

    key_index: Dict[str, Any] = sidecar["keys"]
    result: Dict[str, Any] = {}
    if not keys:
        return result

    dctx = zstandard.ZstdDecompressor()
    with open(path, "rb") as f:
        for k in keys:
            entry = key_index.get(k)
            if entry is None:
                continue
            f.seek(entry["offset"])
            frame_bytes = f.read(entry["len"])
            raw = dctx.decompress(frame_bytes)
            result[k] = msgpack.unpackb(raw, raw=False, strict_map_key=False)
    return result


def _load_frames_all(path: Path, sidecar: Dict[str, Any]) -> Dict[str, Any]:
    """Load all keys from a seekable-frame blueprint into a dict.

    Reads the entire file in one I/O call for throughput, then decompresses
    each frame independently using the byte ranges in the sidecar.  Key order
    matches the original insertion order preserved in the sidecar.

    Peak transient RAM = file on disk (8–15 MB compressed) + one decompressed
    frame at a time, rather than all frames simultaneously.
    """
    import msgpack  # type: ignore[import]
    import zstandard  # type: ignore[import]

    key_index: Dict[str, Any] = sidecar["keys"]
    data = path.read_bytes()
    dctx = zstandard.ZstdDecompressor()
    result: Dict[str, Any] = {}
    for k, entry in key_index.items():
        frame_bytes = data[entry["offset"] : entry["offset"] + entry["len"]]
        raw = dctx.decompress(frame_bytes)
        result[k] = msgpack.unpackb(raw, raw=False, strict_map_key=False)
    return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_blueprint(
    path: Union[str, Path],
    *,
    skip_global_lineage: bool = False,
    keys: Optional[Set[str]] = None,
) -> Dict[str, Any]:
    """Load a blueprint file, auto-detecting format and encoding.

    **Seekable per-key frame format** (new, written by :func:`write_blueprint`):
    When a ``.bpidx`` sidecar exists alongside the blueprint, each top-level
    key lives in its own independent zstd frame.  If ``keys`` is provided,
    only those frames are read from disk; all other frames are never touched.
    For ``keys={"business_summary"}`` this reads ~300 bytes from disk instead
    of the full 8–15 MB blueprint file.

    **Legacy monolithic format** (written by :func:`pack_blueprint`):
    The entire file is decompressed and decoded.  When ``keys`` is provided
    the unrequested keys are discarded immediately after parsing so the GC
    can reclaim them before any further processing.

    Args:
        path: Path to a ``.asm.json`` / ``.mac.json`` (or msgpack equivalent).
        skip_global_lineage: When ``True``, skip injecting the ``LazyGVL``
            proxy even when the blueprint doesn't contain
            ``global_variable_lineage``.  Pass ``True`` from indexing passes
            that do not need the global graph.
        keys: Optional set of top-level blueprint keys to return.  All other
            top-level keys are discarded.  In the seekable format their frames
            are never read; in the legacy format they are decoded then dropped.

            ``global_variable_lineage`` is only injected when it is absent
            from the file **and** either ``keys`` is ``None`` or
            ``"global_variable_lineage"`` is explicitly included in ``keys``.

    Returns:
        Parsed blueprint dict containing only the requested keys (or all keys
        when ``keys`` is ``None``).
    """
    path = Path(path)
    sidecar = _try_load_sidecar(path)

    if sidecar is not None:
        # Seekable per-key frame format.
        if keys is not None:
            # Caller requested specific keys: eager partial load into plain dict.
            bp: Dict[str, Any] = _load_frames_partial(path, sidecar, keys)
        else:
            # No key filter: return a LazyBlueprint proxy.  Each top-level key
            # is decompressed only on first access; unused keys are never loaded.
            # GVL injection below uses normal dict assignment on the proxy.
            lazy = LazyBlueprint(path, sidecar)
            if not skip_global_lineage and "global_variable_lineage" not in lazy:
                gvl = _get_global_lineage(path)
                if gvl:
                    lazy["global_variable_lineage"] = gvl
            return lazy
    else:
        # Legacy monolithic format: decompress entire file.
        bp = _decode_bytes(path.read_bytes())
        if keys is not None:
            bp = {k: bp[k] for k in keys if k in bp}

    # Inject the shared global lineage only when the caller actually needs it
    # (i.e. did not pass skip_global_lineage=True and either requested all
    # keys or explicitly included "global_variable_lineage" in keys).
    _want_gvl = (
        not skip_global_lineage
        and "global_variable_lineage" not in bp
        and (keys is None or "global_variable_lineage" in keys)
    )
    if _want_gvl:
        gvl = _get_global_lineage(path)
        if gvl:
            bp["global_variable_lineage"] = gvl

    return bp


def write_blueprint(path: Union[str, Path], data: Dict[str, Any]) -> None:
    """Write a blueprint dict as seekable per-key zstd frames with a sidecar index.

    Each top-level key is serialised to msgpack and compressed as an
    independent zstd frame (level 3).  All frames are concatenated into
    *path*.  A companion sidecar at *path* + ``.bpidx`` records the byte
    offset and compressed length of every frame so :func:`load_blueprint` can
    seek directly to any single key's frame without decompressing neighbours.

    Disk footprint is ~9–10 GB for a 22K-file codebase (vs 8 GB monolithic)
    because per-key frames have slightly less compression context than one
    combined stream.  The benefit is that::

        load_blueprint(p, keys={"business_summary"})

    reads ~300 bytes from disk (one small frame) instead of 8–15 MB.

    Falls back to :func:`pack_blueprint` (legacy format, no sidecar) when
    ``zstandard`` is not installed.

    Args:
        path: Destination blueprint file path.
        data: Blueprint dict to serialise.  Must not contain non-serialisable
            values such as ``LazyGVL`` proxies (these are injected at read
            time and must not be written back to disk).
    """
    import msgpack  # type: ignore[import]

    path = Path(path)
    try:
        import zstandard  # type: ignore[import]
    except ImportError:
        # zstandard unavailable: fall back to legacy single-stream format.
        # No sidecar is written; load_blueprint will use the legacy decode path.
        path.write_bytes(pack_blueprint(data))
        return

    cctx = zstandard.ZstdCompressor(level=3)
    frame_parts: List[bytes] = []
    key_index: Dict[str, Dict[str, int]] = {}
    offset = 0

    for key, value in data.items():
        raw = msgpack.packb(value, use_bin_type=True)
        frame = cctx.compress(raw)
        key_index[key] = {"offset": offset, "len": len(frame)}
        frame_parts.append(frame)
        offset += len(frame)

    path.write_bytes(b"".join(frame_parts))

    sidecar = {"version": 1, "format": "seekable_zstd_frames", "keys": key_index}
    _sidecar_path(path).write_text(
        json.dumps(sidecar, separators=(",", ":")), encoding="utf-8"
    )


def pack_blueprint(data: Dict[str, Any], *, compress: bool = True) -> bytes:
    """Serialise a blueprint dict to msgpack bytes, optionally zstd-compressed.

    Returns a **monolithic** compressed byte string (legacy format).  Use
    :func:`write_blueprint` when writing directly to disk — it produces the
    seekable per-key frame format that allows partial reads.

    Compression is enabled by default (``compress=True``).  Pass
    ``compress=False`` to get raw msgpack (e.g. for debugging).  Files written
    with compression are transparently decompressed by :func:`load_blueprint`
    and :func:`_decode_bytes` — no consumer changes needed.

    zstd at level 3 typically reduces 80 MB blueprints to 8–15 MB (~5–10×)
    with negligible CPU overhead.  Falls back to gzip if ``zstandard`` is not
    installed.

    **Memory design**: when compression is enabled this function uses streaming
    serialisation — msgpack bytes are piped directly into the compressor
    without materialising the full uncompressed byte string in memory.  The
    only transient allocations are:

    * zstd: the compressor's internal window (~512 KB at level 3) plus the
      compressed output buffer (~1–3 MB for a compact blueprint).
    * gzip fallback: gzip's 32 KB input/output buffers plus the compressed
      output buffer.

    Without streaming the naive approach would hold ``uncompressed_msgpack``
    (8–15 MB per file after format changes, or 80 MB in the old format) AND
    ``compressed_output`` simultaneously.

    Args:
        data: Blueprint dict (as returned by ``JSONEmitter.emit()``).
        compress: Whether to apply compression (default ``True``).

    Returns:
        msgpack-encoded (and optionally compressed) bytes.
    """
    import io
    import msgpack  # type: ignore[import]

    if not compress:
        return msgpack.packb(data, use_bin_type=True)

    buf = io.BytesIO()
    try:
        import zstandard  # type: ignore[import]
        cctx = zstandard.ZstdCompressor(level=3)
        with cctx.stream_writer(buf, closefd=False) as compressor:
            msgpack.pack(data, compressor, use_bin_type=True)
    except ImportError:
        import gzip
        with gzip.open(buf, "wb", compresslevel=6) as gz:
            msgpack.pack(data, gz, use_bin_type=True)
    return buf.getvalue()
