#!/usr/bin/env python3
"""
filter_forward_overwrite.py

Filter forward-lineage JSON by OVERWRITE value and print lineage slices.

Usage:
    python3 filter_forward_overwrite.py <lineage.json> <value> [--output <file>]

Examples:
    python3 filter_forward_overwrite.py temp/asm/output/da76_WK_RRC_forward_lineage.json 31
    python3 filter_forward_overwrite.py temp/asm/output/da76_WK_RRC_forward_lineage.json \"=C'31'\"
"""

from __future__ import annotations

import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List


def parse_args(argv: List[str]) -> tuple[Path, str, Path | None]:
    if len(argv) < 3:
        print(__doc__)
        raise SystemExit(1)

    lineage_file = Path(argv[1])
    value_query = argv[2]

    output_file = None
    if "--output" in argv:
        idx = argv.index("--output")
        if idx + 1 >= len(argv):
            print("Error: --output requires a file path.")
            raise SystemExit(1)
        output_file = Path(argv[idx + 1])

    return lineage_file, value_query, output_file


def normalize_query_variants(query: str) -> List[str]:
    q = query.strip().strip('"').strip("'").upper()
    variants = {q}
    if q.isdigit():
        variants.add(f"=C'{q}'")
        variants.add(f"C'{q}'")
    m = re.match(r"^=?C'([^']+)'$", q)
    if m:
        variants.add(m.group(1).upper())
        variants.add(f"=C'{m.group(1).upper()}'")
        variants.add(f"C'{m.group(1).upper()}'")
    return sorted(v for v in variants if v)


def overwrite_matches(node: Dict, variants: List[str]) -> bool:
    if node.get("role") != "OVERWRITE":
        return False

    haystack = " ".join(
        [
            str(node.get("new_value_expr", "")),
            str(node.get("detail", "")),
            str(node.get("source_line", "")),
            " ".join(str(x) for x in (node.get("args", []) or [])),
        ]
    ).upper()

    return any(v in haystack for v in variants)


def walk_to_root(node: Dict, node_by_id: Dict[str, Dict]) -> List[Dict]:
    path = []
    cur = node
    while cur:
        path.append(cur)
        pid = cur.get("parent_chunk_id")
        cur = node_by_id.get(pid) if pid else None
    path.reverse()
    return path


def enumerate_paths_from(start_id: str, children: Dict[str, List[Dict]]) -> List[List[Dict]]:
    start_nodes = children.get(start_id, [])
    if not start_nodes:
        return []

    paths: List[List[Dict]] = []
    stack: List[tuple[Dict, List[Dict]]] = [(child, [child]) for child in start_nodes]
    while stack:
        node, path = stack.pop()
        kids = children.get(node.get("chunk_id", ""), [])
        if not kids:
            paths.append(path)
            continue
        for k in kids:
            stack.append((k, path + [k]))
    return paths


def format_chain(path: List[Dict], title: str) -> str:
    lines = [title, "-" * len(title)]
    for i, n in enumerate(path):
        indent = "  " * i
        edge = (n.get("edge_to_parent") or {}).get("type", "ROOT")
        cid = n.get("chunk_id", "")
        role = n.get("role", "")
        src = n.get("source_line", "").strip()
        lines.append(f"{indent}[{edge}] {cid}  ({role})")
        lines.append(f"{indent}        {src}")
    return "\n".join(lines)


def main() -> int:
    lineage_file, value_query, output_file = parse_args(sys.argv)
    if not lineage_file.exists():
        print(f"Error: file not found: {lineage_file}")
        return 1

    data = json.loads(lineage_file.read_text(encoding="utf-8"))
    nodes = data.get("nodes", [])
    node_by_id = {n.get("chunk_id"): n for n in nodes if n.get("chunk_id")}

    children: Dict[str, List[Dict]] = defaultdict(list)
    for n in nodes:
        pid = n.get("parent_chunk_id")
        if pid:
            children[pid].append(n)

    variants = normalize_query_variants(value_query)
    matches = [n for n in nodes if overwrite_matches(n, variants)]

    if not matches:
        print(f"No OVERWRITE nodes matched value '{value_query}'.")
        return 1

    out: List[str] = []
    out.append(
        f"Found {len(matches)} OVERWRITE node(s) for value '{value_query}' "
        f"in variable '{data.get('variable', '')}':"
    )
    for n in matches:
        out.append(f"  {n.get('chunk_id')}  —  {n.get('source_line', '').strip()}")

    for idx, n in enumerate(matches, start=1):
        out.append("")
        out.append("=" * 80)
        out.append(f"Match {idx}: {n.get('chunk_id')}")
        out.append("=" * 80)

        context_path = walk_to_root(n, node_by_id)
        out.append(format_chain(context_path, "Context (root -> overwrite)"))

        forward_paths = enumerate_paths_from(n.get("chunk_id", ""), children)
        if not forward_paths:
            out.append("\nForward From Overwrite\n----------------------")
            out.append("(No downstream nodes. This overwrite is a leaf in the current lineage graph.)")
        else:
            for p_idx, p in enumerate(forward_paths, start=1):
                title = f"Forward Path {p_idx} (overwrite -> leaf)"
                out.append("")
                out.append(format_chain([n] + p, title))

    text = "\n".join(out) + "\n"
    print(text, end="")

    if output_file:
        output_file.parent.mkdir(parents=True, exist_ok=True)
        output_file.write_text(text, encoding="utf-8")
        print(f"Output saved to: {output_file}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
