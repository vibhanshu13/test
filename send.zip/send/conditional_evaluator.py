"""Conditional expression evaluator for z/TPF assembly.

Evaluates conditional expressions used in AIF directives, such as:
- &VAR EQ 5
- &COUNT GT &LIMIT
- &NAME NE 'TEST'

Supports both SET symbols and macro parameters in conditions.
"""

import re
from typing import Optional, Union, Dict
from models.conditional_assembly import SetSymbolTable, ConditionalAssemblyState


class ConditionalEvaluator:
    """Evaluates conditional expressions for assembly IF directives.

    Supports comparison operators: EQ, NE, LT, LE, GT, GE
    Can compare:
    - SET symbols against integer literals
    - SET symbols against string literals (quoted)
    - SET symbols against other SET symbols
    - Macro parameters against literals or other parameters
    """

    # Operator implementations using lambda functions
    OPERATORS = {
        'EQ': lambda a, b: a == b,
        'NE': lambda a, b: a != b,
        'LT': lambda a, b: a < b,
        'LE': lambda a, b: a <= b,
        'GT': lambda a, b: a > b,
        'GE': lambda a, b: a >= b,
    }

    def __init__(self):
        """Initialize the conditional evaluator."""
        # Regex pattern to parse condition: "&VAR OPERATOR VALUE"
        # Case-insensitive to handle EQ, eq, Eq, etc.
        self.condition_pattern = re.compile(
            r'(&\w+)\s+(EQ|NE|LT|LE|GT|GE)\s+(.+)',
            re.IGNORECASE
        )

        # Pattern to extract SET symbol references
        self.symbol_pattern = re.compile(r'&\w+')

    def _get_symbol_value(self, symbol_name: str, context: Union[SetSymbolTable, ConditionalAssemblyState]):
        """Get value for a symbol from either SET symbols or macro parameters.

        Args:
            symbol_name: Symbol or parameter name (e.g., "&VAR")
            context: SetSymbolTable or ConditionalAssemblyState

        Returns:
            Symbol/parameter value (converted to int if possible), or "UNKNOWN" if not defined
        """
        value = None

        if isinstance(context, ConditionalAssemblyState):
            # Check macro parameters first (they take precedence)
            macro_value = context.get_macro_param(symbol_name)
            if macro_value is not None:
                value = macro_value
            else:
                # Then check SET symbols
                value = context.set_symbols.get_value(symbol_name)
        else:
            # SetSymbolTable
            value = context.get_value(symbol_name)

        # If value is a string representation of an integer, convert it
        if isinstance(value, str) and value != "UNKNOWN":
            try:
                return int(value)
            except ValueError:
                pass

        return value

    def can_evaluate(self, condition: str, context: Union[SetSymbolTable, ConditionalAssemblyState]) -> bool:
        """Check if condition can be evaluated based on symbol/parameter availability.

        A condition can be evaluated if:
        1. All SET symbols/macro parameters referenced are defined
        2. No symbol/parameter has the value "UNKNOWN"

        Args:
            condition: Conditional expression (e.g., "&VAR EQ 5" or "&PARM1 NE ''")
            context: SetSymbolTable or ConditionalAssemblyState containing definitions

        Returns:
            True if condition can be evaluated, False otherwise
        """
        # Extract all SET symbol/parameter references from condition
        symbol_refs = self.symbol_pattern.findall(condition)

        if not symbol_refs:
            # No symbols in condition - cannot evaluate
            return False

        # Check if all symbols/parameters are defined and not UNKNOWN
        for symbol_name in symbol_refs:
            value = self._get_symbol_value(symbol_name, context)
            if value == "UNKNOWN":
                return False

        return True

    def evaluate(self, condition: str, context: Union[SetSymbolTable, ConditionalAssemblyState]) -> Optional[bool]:
        """Evaluate a conditional expression.

        Evaluates conditions like:
        - "&VAR EQ 5" - Compare SET symbol to integer
        - "&NAME EQ 'TEST'" - Compare SET symbol to string
        - "&COUNT GT &LIMIT" - Compare two SET symbols
        - "&PARM1 NE ''" - Compare macro parameter to empty string

        Args:
            condition: Conditional expression to evaluate
            context: SetSymbolTable or ConditionalAssemblyState containing definitions

        Returns:
            True if condition is true
            False if condition is false
            None if condition cannot be evaluated (unknown symbols/parameters or invalid syntax)
        """
        # First check if we can evaluate
        if not self.can_evaluate(condition, context):
            return None

        # Parse the condition
        match = self.condition_pattern.match(condition.strip())
        if not match:
            # Invalid syntax
            return None

        symbol_name, operator, right_value = match.groups()
        operator = operator.upper()  # Normalize to uppercase

        # Get the left side value (the symbol or parameter)
        left_value = self._get_symbol_value(symbol_name, context)
        if left_value == "UNKNOWN":
            return None

        # Parse the right side value
        right_parsed = self._parse_comparison_value(right_value.strip(), context)
        if right_parsed is None:
            return None

        # Apply the operator
        try:
            operator_func = self.OPERATORS.get(operator)
            if operator_func is None:
                return None

            result = operator_func(left_value, right_parsed)
            return result

        except (TypeError, ValueError):
            # Comparison failed (e.g., comparing incompatible types)
            return None

    def _parse_comparison_value(self, value: str, context: Union[SetSymbolTable, ConditionalAssemblyState]) -> Optional[any]:
        """Parse the right-hand side of a comparison.

        The value can be:
        1. An integer literal (e.g., "5")
        2. A string literal with quotes (e.g., "'TEST'")
        3. A SET symbol or macro parameter reference (e.g., "&LIMIT" or "&PARM1")

        Args:
            value: The value string to parse
            context: SetSymbolTable or ConditionalAssemblyState for resolving references

        Returns:
            Parsed value (int, str, or other), or None if cannot parse
        """
        # Try to parse as integer first
        try:
            return int(value)
        except ValueError:
            pass

        # Check if it's a quoted string
        if (value.startswith("'") and value.endswith("'")) or \
           (value.startswith('"') and value.endswith('"')):
            # Strip quotes
            return value[1:-1]

        # Check if it's a symbol or parameter reference
        if value.startswith('&'):
            ref_value = self._get_symbol_value(value, context)
            if ref_value == "UNKNOWN":
                return None
            return ref_value

        # Otherwise, treat as unquoted string literal
        return value

    def evaluate_with_params(
        self,
        condition: str,
        macro_params: Dict[str, str]
    ) -> bool:
        """Evaluate condition with macro parameter bindings.

        Args:
            condition: Conditional expression (e.g., "('&RC' EQ '0')")
            macro_params: Dictionary of parameter bindings

        Returns:
            True if condition is true, False otherwise
        """
        # Remove parentheses if present
        condition = condition.strip()
        if condition.startswith('(') and condition.endswith(')'):
            condition = condition[1:-1].strip()

        # Check for type attribute: T'&PARAM
        type_attr_pattern = re.compile(r"T'(&\w+)")
        type_match = type_attr_pattern.search(condition)

        if type_match:
            param_name = type_match.group(1)

            # Check if parameter is provided
            if param_name in macro_params and macro_params[param_name]:
                type_value = "'N'"  # Provided (not omitted)
            else:
                type_value = "'O'"  # Omitted

            # Replace T'&PARAM with its type value
            condition = type_attr_pattern.sub(type_value, condition)

        # Parse condition: 'VAR' OPERATOR VALUE or VAR OPERATOR VALUE or 'LITERAL' OPERATOR VALUE
        # Pattern needs to handle optional quotes and can start with either &param or literal
        param_condition_pattern = re.compile(
            r"('?[&\w]+'?)\s+(EQ|NE|LT|LE|GT|GE)\s+(.+)",
            re.IGNORECASE
        )
        match = param_condition_pattern.match(condition)
        if not match:
            return False

        left_side = match.group(1).strip()  # e.g., "&RC" or "'&RC'" or "'O'"
        operator = match.group(2).upper()
        right_side = match.group(3).strip()  # e.g., "'0'"

        # Remove quotes if present
        left_side = left_side.strip("'")
        right_side = right_side.strip("'")

        # Get value for left side - check if it's a parameter reference
        if left_side.startswith('&'):
            left_value = macro_params.get(left_side, "")
        else:
            # It's a literal value (e.g., from type attribute substitution)
            left_value = left_side

        # Get value for right side (could be literal or another parameter)
        if right_side.startswith('&'):
            right_value = macro_params.get(right_side, "")
        else:
            right_value = right_side

        # Try to convert to int if possible
        try:
            left_value = int(left_value)
            right_value = int(right_value)
        except (ValueError, TypeError):
            # Keep as strings
            pass

        # Evaluate condition
        if operator in self.OPERATORS:
            return self.OPERATORS[operator](left_value, right_value)

        return False
