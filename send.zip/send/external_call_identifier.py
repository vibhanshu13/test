"""Identifier for external calls (C functions, OS services, system libraries)."""

from typing import Optional


class ExternalCallIdentifier:
    """Identify external calls to C functions, OS services, and system libraries.

    Detects calls that are likely external based on naming conventions and patterns.
    """

    def __init__(self):
        # Common C standard library functions
        self.c_functions = {
            # String functions
            "sprintf", "snprintf", "strcpy", "strncpy", "strcat", "strncat",
            "strcmp", "strncmp", "strlen", "strchr", "strrchr", "strstr",
            "memcpy", "memmove", "memset", "memcmp", "memchr",

            # I/O functions
            "printf", "fprintf", "scanf", "fscanf", "fopen", "fclose",
            "fread", "fwrite", "fseek", "ftell", "rewind",

            # Memory functions
            "malloc", "calloc", "realloc", "free",

            # Other common functions
            "atoi", "atol", "atof", "strtol", "strtod",
            "qsort", "bsearch", "abs", "rand", "srand",
        }

        # z/OS system services (common ones)
        self.zos_services = {
            # Storage management
            "STORAGE", "GETMAIN", "FREEMAIN",

            # Task management
            "ATTACH", "DETACH", "WAIT", "POST",

            # I/O services
            "OPEN", "CLOSE", "READ", "WRITE", "GET", "PUT",

            # ENQ/DEQ
            "ENQ", "DEQ",

            # Time services
            "TIME", "STIMER", "STIMERM",

            # Program management
            "LOAD", "DELETE", "LINK", "XCTL", "CALL",

            # Other services
            "WTO", "WTOR", "SNAP", "ABEND",
        }

    def is_external_call(self, target_name: str) -> bool:
        """Check if target is likely an external call.

        Args:
            target_name: Name of the call target

        Returns:
            True if target is likely external
        """
        if not target_name:
            return False

        target_upper = target_name.upper()
        target_lower = target_name.lower()

        # Check if it's a known C function (exact match, case-sensitive)
        # C functions are lowercase, so check if target_name itself is in the set
        if target_name in self.c_functions:
            return True

        # Check if it's a z/OS service (case-insensitive)
        if target_upper in self.zos_services:
            return True

        # Check for common patterns
        # C functions typically start with lowercase AND are all lowercase
        if target_name[0].islower() and len(target_name) > 2:
            # Additional heuristics for C functions
            # Usually no underscores at start, and must be all lowercase
            if not target_name.startswith("_") and target_name == target_lower:
                return True

        return False

    def get_external_type(self, target_name: str) -> Optional[str]:
        """Get the type of external call.

        Args:
            target_name: Name of the call target

        Returns:
            "c_function", "zos_service", or None
        """
        if not target_name:
            return None

        target_upper = target_name.upper()
        target_lower = target_name.lower()

        # Check if it's a known C function (exact match, case-sensitive)
        if target_name in self.c_functions:
            return "c_function"

        # Check if it's a z/OS service (case-insensitive)
        if target_upper in self.zos_services:
            return "zos_service"

        # Heuristic: all lowercase = likely C function
        if target_name[0].islower() and not target_name.startswith("_") and target_name == target_lower:
            return "c_function"

        return None
