#!/usr/bin/env python3
"""Build a cross-file variable hop index from blueprint output.

For every edge in every blueprint, records the line number, expression,
operation_type, transformation, relation, node_id, and variable_name,
indexed by the variable's canonical_key (from the identity index) and
then by file stem.  This gives the variable-flow endpoint O(1) access to
all occurrence details for a variable in a specific file, without re-reading
blueprints at query time.

Usage (CLI):
    python3 build_variable_hop_index.py <blueprint_dir> <identity_index_path> [--output PATH]

The index is also built automatically by ``pipeline_task.py`` as Step 6.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor, TimeoutError as _FuturesTimeoutError, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from blueprint_io import load_blueprint
from build_variable_identity_index import (
    _MEMORY_KINDS,
    _is_noise_node,
    _stem,
    _name_upper,
)

INDEX_FILENAME = "variable_hop_index.json"
_BP_IO_TIMEOUT = 60.0  # max seconds to wait for a single blueprint file read

# Number of temp-file buckets used by the streaming sort-merge in build_index().
# Each bucket receives ~1/N of all hop records (routed by hash(canonical_key)).
# At 6M total records / 200 buckets the peak in-RAM bucket is ~30K records ≈ 12 MB,
# vs 3.2 GB for the old in-memory hop_index dict at 25K-file scale.
_N_BUCKETS = 200


# ---------------------------------------------------------------------------
# Per-blueprint worker
# ---------------------------------------------------------------------------

def _process_one_blueprint(
    bp_path: Path,
    by_name: Dict[str, str],
) -> List[Tuple[str, str, Dict[str, Any]]]:
    """Load one blueprint and return its hop records.

    Each record is ``(canonical_key, file_stem, hop_dict)``.
    Returns an empty list on error (warning printed to stderr).

    Per-blueprint deduplication is applied inside the worker via seen_local.
    Cross-blueprint duplicates cannot occur because file_stem is unique per
    blueprint — the outer seen set was therefore redundant and has been removed
    to save 1–2 GB on large corpora (14 K files × 5-field dedup tuples).
    """
    file_stem = _stem(bp_path)
    try:
        bp = load_blueprint(bp_path, skip_global_lineage=True, keys={"variable_lineage"})
    except Exception as exc:
        print(f"WARNING: Skipping {bp_path.name}: {exc}", file=sys.stderr)
        return []

    vl = bp.get("variable_lineage") or {}
    edges = vl.get("edges") or []
    nodes_by_id: Dict[str, Dict[str, Any]] = {
        n["id"]: n for n in vl.get("nodes", []) if "id" in n
    }

    records: List[Tuple[str, str, Dict[str, Any]]] = []
    seen_local: Set[Tuple] = set()

    for edge in edges:
        for relation, node_id in (
            ("source", edge.get("source")),
            ("target", edge.get("target")),
        ):
            if not node_id:
                continue
            node = nodes_by_id.get(node_id)
            if node is None or node.get("kind") not in _MEMORY_KINDS:
                continue
            if _is_noise_node(node_id):
                continue

            leaf_upper = _name_upper(node_id)
            canonical_key = by_name.get(leaf_upper, leaf_upper)

            line = edge.get("line")
            line_str = str(line) if line is not None else ""
            dedup_key = (canonical_key, file_stem, node_id, line_str, relation)
            if dedup_key in seen_local:
                continue
            seen_local.add(dedup_key)

            records.append((
                canonical_key,
                file_stem,
                {
                    "line": line,
                    "expression": edge.get("expression"),
                    "operation_type": edge.get("operation_type"),
                    "transformation": edge.get("transformation"),
                    "relation": relation,
                    "node_id": node_id,
                    "variable_name": node_id.split(":")[-1],
                },
            ))

    return records


def build_index(
    blueprint_dir: Path,
    identity_index_path: Path,
    output_path: Optional[Path] = None,
    *,
    job_id: Optional[str] = None,
) -> Optional[Path]:
    """Scan all .asm.json blueprints and build the hop index.

    For every edge in each blueprint, records each memory-class node
    endpoint as a hop entry keyed by the variable's canonical_key and file
    stem.  Enables O(1) occurrence lookup at query time.

    Args:
        blueprint_dir:        Directory containing .asm.json files.
        identity_index_path:  Path to variable_identity_index.json (built
                              by Step 5).  Used to resolve canonical keys.
        output_path:          Where to write the hop index JSON.
                              Defaults to ``blueprint_dir.parent / INDEX_FILENAME``.
                              Ignored when *job_id* is provided.
        job_id:               When provided, write directly to the index DB via
                              ``ingest_hop_index_from_buckets`` instead of
                              writing a JSON file.  No JSON file is created.

    Returns:
        Path to the written index file, or ``None`` when *job_id* is provided.
    """
    if output_path is None and job_id is None:
        output_path = blueprint_dir.parent / INDEX_FILENAME

    # Load identity index to resolve canonical keys by name.
    # DB-first: two-column query avoids loading the 96 MB JSON file into RAM.
    by_name: Dict[str, str] = {}
    try:
        from api.index_db.engine import job_id_from_path
        from api.index_db.readers import get_identity_by_name_bulk
        _jid = job_id_from_path(identity_index_path)
        by_name = get_identity_by_name_bulk(
            _jid or "",
            fallback_path=identity_index_path if identity_index_path.exists() else None,
        )
        if not by_name and not identity_index_path.exists():
            print(
                f"WARNING: Identity index not found at {identity_index_path}; "
                "hop index will use name-only canonical keys.",
                file=sys.stderr,
            )
    except Exception as exc:
        print(f"WARNING: Could not load identity index: {exc}", file=sys.stderr)
        by_name = {}

    blueprint_files = sorted(blueprint_dir.glob("*.asm.json"))
    total = len(blueprint_files)
    # I/O-bound: cap at 8 workers to limit concurrent variable_lineage blob loads.
    _workers = min(8, (os.cpu_count() or 4))
    completed = 0

    # Phase 1 — fan-out: route each hop record to one of _N_BUCKETS temp files
    # by hash(canonical_key).  At most one bucket worth of records (~total/_N_BUCKETS)
    # is held in RAM at any given moment during Phase 2, replacing the old
    # in-memory hop_index dict that peaked at 3.2 GB for 25K-file corpora.
    #
    # NOTE: No outer seen set — per-blueprint dedup inside _process_one_blueprint
    # is sufficient.  dedup_key always includes file_stem which is unique per
    # blueprint, so cross-blueprint collisions cannot occur.
    unique_keys: Set[str] = set()
    total_records = 0

    with tempfile.TemporaryDirectory(prefix="hop_idx_") as _tmpdir:
        _tmpdir_path = Path(_tmpdir)
        # Pre-open all bucket files with a 128 KiB write buffer each.
        _bucket_fhs = [
            open(_tmpdir_path / f"b{i:03d}.jsonl", "w", encoding="utf-8", buffering=1 << 17)
            for i in range(_N_BUCKETS)
        ]

        with ThreadPoolExecutor(max_workers=_workers) as pool:
            futures = {
                pool.submit(_process_one_blueprint, p, by_name): p
                for p in blueprint_files
            }
            for fut in as_completed(futures):
                try:
                    records = fut.result(timeout=_BP_IO_TIMEOUT)
                except _FuturesTimeoutError:
                    print(
                        f"WARNING: Timed out processing {futures[fut].name}"
                        f" (>{_BP_IO_TIMEOUT:.0f}s), skipping.",
                        file=sys.stderr,
                    )
                    records = []
                except Exception as exc:
                    print(
                        f"WARNING: Error processing {futures[fut].name}: {exc}",
                        file=sys.stderr,
                    )
                    records = []

                for canonical_key, file_stem, hop_dict in records:
                    bidx = (hash(canonical_key) & 0x7FFFFFFF) % _N_BUCKETS
                    _bucket_fhs[bidx].write(
                        json.dumps(
                            [canonical_key, file_stem, hop_dict], separators=(",", ":")
                        )
                        + "\n"
                    )
                    unique_keys.add(canonical_key)
                    total_records += 1

                completed += 1
                if completed % 1000 == 0 or completed == total:
                    pct = completed * 100 // total
                    print(
                        f"  Hop index build: {completed}/{total} blueprints ({pct}%)",
                        flush=True,
                    )

        for fh in _bucket_fhs:
            fh.close()
        del _bucket_fhs

        # Phase 2 — merge: either write directly to the index DB (when job_id
        # is provided) or write to a JSON file incrementally.
        # Peak RAM = one bucket's in-memory records
        # (≈ total_records / _N_BUCKETS × 420 B ≈ 12 MB for 6M total records).
        if job_id is not None:
            # DB path: stream bucket files directly into variable_hops table.
            try:
                from api.index_db.writers import ingest_hop_index_from_buckets
                ingest_hop_index_from_buckets(
                    job_id, _tmpdir_path, _N_BUCKETS,
                    batch_size=500,
                )
            except Exception as exc:
                print(f"WARNING: ingest_hop_index_from_buckets failed: {exc}", flush=True)
        else:
            with open(output_path, "w", encoding="utf-8") as out_fh:
                out_fh.write('{"_meta":')
                json.dump(
                    {
                        "built_at": datetime.now(timezone.utc).isoformat(),
                        "blueprints_scanned": total,
                        "unique_identities": len(unique_keys),
                        "total_hops": total_records,
                    },
                    out_fh,
                    separators=(",", ":"),
                )

                for bidx in range(_N_BUCKETS):
                    bucket_path = _tmpdir_path / f"b{bidx:03d}.jsonl"
                    bucket_records: List[Tuple[str, str, Dict[str, Any]]] = []
                    with open(bucket_path, "r", encoding="utf-8") as bfh:
                        for raw in bfh:
                            raw = raw.strip()
                            if raw:
                                ck, fstem, hop = json.loads(raw)
                                bucket_records.append((ck, fstem, hop))

                    if not bucket_records:
                        continue

                    # Group by canonical_key → file_stem within this bucket.
                    bucket_index: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
                    for ck, fstem, hop in bucket_records:
                        bucket_index.setdefault(ck, {}).setdefault(fstem, []).append(hop)
                    del bucket_records

                    # Write sorted entries for this bucket; each gets a leading comma
                    # because "_meta" is always written first.
                    for ck in sorted(bucket_index):
                        sorted_files = {
                            fstem: sorted(
                                bucket_index[ck][fstem],
                                key=lambda h: (h["line"] is None, h["line"] or 0),
                            )
                            for fstem in sorted(bucket_index[ck])
                        }
                        out_fh.write(",")
                        out_fh.write(json.dumps(ck))
                        out_fh.write(":")
                        json.dump(sorted_files, out_fh, separators=(",", ":"))

                    del bucket_index

                    if (bidx + 1) % 40 == 0 or bidx + 1 == _N_BUCKETS:
                        print(
                            f"  Hop index write: {bidx + 1}/{_N_BUCKETS} buckets merged",
                            flush=True,
                        )

                out_fh.write("}")

    if job_id is not None:
        print(
            f"Hop index written to index DB "
            f"({total} blueprints, {len(unique_keys)} identities, {total_records} hop records)",
            file=sys.stderr,
        )
        return None

    print(
        f"Wrote hop index: {output_path} "
        f"({total} blueprints, {len(unique_keys)} identities, {total_records} hop records)",
        file=sys.stderr,
    )
    return output_path


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Build variable_hop_index.json from blueprint output."
    )
    parser.add_argument("blueprint_dir", help="Directory containing .asm.json files")
    parser.add_argument("identity_index", help="Path to variable_identity_index.json")
    parser.add_argument(
        "--output",
        help=f"Output path (default: <blueprint_dir>/../{INDEX_FILENAME})",
    )
    args = parser.parse_args()

    bp_dir = Path(args.blueprint_dir)
    id_idx = Path(args.identity_index)
    out = Path(args.output) if args.output else None
    build_index(bp_dir, id_idx, out)
