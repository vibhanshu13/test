#!/usr/bin/env python3
"""Forward variable lineage tracer for assembler + blueprint JSON.

Implements forward lineage in a separate module so backward logic in
`trace_lineage.py` can remain unchanged.
"""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from trace_lineage import (
    BRANCH_INST,
    CROSS_FILE_INST,
    DEST_ARG_INDEX_BY_INST,
    REGISTERS,
    SETTER_INST,
    SUBROUTINE_INST,
    TRIGGER_INST,
    LineageTracer,
    TraceResults,
    _find_entry_dispatch_blocks,
    build_label_map,
    build_lineage_graph as build_shared_lineage_graph,
    expand_macro_branches,
    format_results,
    load_asm_lines,
    normalize_token,
    is_dep_var_candidate,
    is_real_setter_site,
)
from blueprint_io import iter_flow, load_blueprint

# Forward condition-test classification. `OC` is included because it can set
# condition codes and is useful as a condition producer in forward traces.
FORWARD_CONDITION_INST = set(TRIGGER_INST) | {"OC"}


@dataclass
class CrossFileResolution:
    stems: List[str]
    reason: str
    warning: Optional[str] = None


class ForwardLineageTracer(LineageTracer):
    """Forward tracer that reuses utility helpers from the backward tracer base."""

    def __init__(self, asm_dir: Path, blueprint_dir: Path, include_register_dependencies: bool = False):
        super().__init__(asm_dir, blueprint_dir, include_register_dependencies)
        self._indices_built: bool = False
        self._entry_to_files: Dict[str, Set[str]] = {}
        self._sub_to_files: Dict[str, Set[str]] = {}
        self._visited_forward_states: Set[Tuple[str, str, str, str]] = set()

    def trace_forward(self, target_variable: str, source_asm_file: Path, blueprint_file: Path) -> TraceResults:
        self.visited_files = set()
        self._visited_forward_states = set()
        results = TraceResults()
        self._trace_file_forward(
            target_variable=target_variable,
            source_asm_file=source_asm_file,
            blueprint_file=blueprint_file,
            results=results,
        )
        self._post_process(results)
        return results

    def _build_outgoing_map(self, blocks: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, str]]]:
        outgoing: Dict[str, List[Dict[str, str]]] = {}
        for block in blocks:
            target_id = str(block.get("id", ""))
            for ref in (block.get("incoming_branches", []) or []):
                source_id = str(ref.get("source", ""))
                if not source_id or not target_id:
                    continue
                outgoing.setdefault(source_id, []).append(
                    {
                        "target": target_id,
                        "type": str(ref.get("type", "BRANCH")),
                    }
                )
        return outgoing

    # Mnemonics that unconditionally transfer control — after one of these the
    # sequential fall-through path is dead.  B/BR/J are the canonical HLASM forms;
    # BC/BCR with mask 15 appear as 'B'/'BR' after macro expansion.
    _UNCONDITIONAL_BRANCH: Set[str] = {"B", "BR", "J", "JU", "ENTNC"}

    def _post_setter_successors(
        self,
        block: Dict[str, Any],
        start_line: int,
        outgoing_map: Dict[str, List[Dict[str, str]]],
        block_map: Dict[str, Dict[str, Any]],
    ) -> Dict[str, str]:
        """Return {successor_block_id: edge_type} for edges reachable after start_line.

        For the starting block (which contains the setter), branches that appear
        *before* the setter line must not be treated as forward edges — execution
        has already passed those instructions by the time the setter fires.

        Returns a dict so that the caller can emit edges with the *correct* type.
        FALLTHROUGH takes priority over BRANCH when both paths reach the same block
        (avoids leaking a pre-setter BRANCH type onto a post-setter fall-through).
        """
        block_id = str(block.get("id", ""))
        flow = list(iter_flow(block))
        post_flow = [e for e in flow if int(e.get("line", 0)) > start_line]

        if not post_flow:
            return {}

        # Labels explicitly referenced by branch / subroutine instructions after start_line.
        mentioned: Set[str] = set()
        for entry in post_flow:
            inst = str(entry.get("inst", "")).upper()
            args = self._entry_args(entry)
            if inst in BRANCH_INST and args:
                # Branch target is the last operand (covers J/B and multi-operand
                # forms like BCT R1,Lbl or JXHG R1,R3,Lbl).
                t = normalize_token(str(args[-1]))
                if t:
                    mentioned.add(t)
            elif inst in SUBROUTINE_INST and len(args) >= 2:
                t = normalize_token(str(args[1]))
                if t:
                    mentioned.add(t)

        # A fall-through is only reachable after the setter if the post-setter
        # code does NOT end with an unconditional branch.  If the last post-setter
        # flow entry is an unconditional branch (B, BR, J, …), execution always
        # transfers there and the sequential fall-through path is dead.
        last_post = max(post_flow, key=lambda e: int(e.get("line", 0)))
        ends_unconditional = (
            str(last_post.get("inst", "")).upper() in self._UNCONDITIONAL_BRANCH
        )

        valid: Dict[str, str] = {}  # successor_id -> edge_type

        # Pass 1: FALLTHROUGH edges (only when the block can reach its end).
        # Recorded first so they take priority over any BRANCH to the same block.
        if not ends_unconditional:
            for edge in outgoing_map.get(block_id, []):
                succ = str(edge.get("target", ""))
                if succ and str(edge.get("type", "")).upper() == "FALLTHROUGH":
                    valid[succ] = "FALLTHROUGH"

        # Pass 2: explicit BRANCH / SUBROUTINE_CALL edges from post-setter instructions.
        # Only added when not already covered by a FALLTHROUGH (FALLTHROUGH wins).
        for edge in outgoing_map.get(block_id, []):
            succ = str(edge.get("target", ""))
            if not succ or succ in valid:
                continue
            edge_type = str(edge.get("type", "BRANCH")).upper()
            if edge_type == "FALLTHROUGH":
                continue  # already handled
            succ_norm = normalize_token(succ)
            if succ_norm and succ_norm in mentioned:
                valid[succ] = edge_type

        return valid

    def compute_cfg_block_edges(
        self,
        blueprint_file: Path,
        start_block_id: str,
        start_line: int = 0,
    ) -> List[Dict[str, str]]:
        """Load blueprint and return all CFG block-to-block edges reachable from start_block_id.

        Each entry is: {"from": block_id, "to": block_id, "type": edge_type}
        where edge_type is BRANCH, FALLTHROUGH, or SUBROUTINE_CALL.

        start_line: when > 0, only outgoing edges of the *starting block* that are
                    triggered by instructions at/after this line are included.
                    All successor blocks are explored in full (their edges are
                    not line-filtered because control enters them from the top).
        """
        if not blueprint_file.exists():
            return []
        try:
            blueprint = load_blueprint(blueprint_file)
        except Exception:
            return []
        blocks = blueprint.get("blocks", []) or []
        block_map: Dict[str, Dict[str, Any]] = {str(b.get("id", "")): b for b in blocks}
        outgoing_map = self._build_outgoing_map(blocks)

        start_norm = normalize_token(start_block_id) or start_block_id.strip().upper()
        if start_norm not in block_map:
            start_norm = f"{start_norm}0000"
        if start_norm not in block_map:
            return []

        start_block = block_map[start_norm]

        # For the starting block, determine which successors are reachable from
        # instructions *after* start_line (pre-setter branches are excluded).
        # The dict value carries the correct edge type (FALLTHROUGH beats BRANCH).
        first_valid: Dict[str, str] = (
            self._post_setter_successors(start_block, start_line, outgoing_map, block_map)
            if start_line > 0
            else {}
        )

        from collections import deque
        edges: List[Dict[str, str]] = []
        visited: Set[str] = set()
        emitted: Set[Tuple[str, str]] = set()   # deduplicate (from, to) pairs
        queue: deque = deque([start_norm])

        while queue:
            bid = queue.popleft()
            if bid in visited:
                continue
            visited.add(bid)

            # Starting block with start_line: only emit post-setter edges, using
            # the type determined by _post_setter_successors (not the raw outgoing type).
            # All other blocks: emit all outgoing edges with their original types.
            if bid == start_norm and start_line > 0:
                for succ, edge_type in sorted(first_valid.items()):
                    pair = (bid, succ)
                    if pair in emitted:
                        continue
                    emitted.add(pair)
                    edges.append({"from": bid, "to": succ, "type": edge_type})
                    if succ not in visited and succ in block_map:
                        queue.append(succ)
            else:
                for edge in outgoing_map.get(bid, []):
                    succ = str(edge.get("target", ""))
                    if not succ:
                        continue
                    pair = (bid, succ)
                    if pair in emitted:
                        continue
                    emitted.add(pair)
                    edge_type = str(edge.get("type", "BRANCH"))
                    edges.append({"from": bid, "to": succ, "type": edge_type})
                    if succ not in visited and succ in block_map:
                        queue.append(succ)

        return edges

    def _routine_family_match(self, callee: str, enclosing_routine: str) -> bool:
        callee_up = normalize_token(callee)
        rout_up = normalize_token(enclosing_routine)
        if not callee_up or not rout_up:
            return False
        if callee_up == rout_up:
            return True
        m1 = re.match(r"^(.*?)(\\d{4})$", callee_up)
        m2 = re.match(r"^(.*?)(\\d{4})$", rout_up)
        if not m1 or not m2:
            return False
        if m1.group(1) != m2.group(1):
            return False
        return (int(m1.group(2)) // 1000) == (int(m2.group(2)) // 1000)

    def _entry_seed_blocks(
        self,
        entry_hint: str,
        block_map: Dict[str, Dict[str, Any]],
        blocks: List[Dict[str, Any]],
        label_map: Dict[str, int],
    ) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        seen_ids: Set[str] = set()
        hint = normalize_token(entry_hint)
        if not hint:
            return out

        def add_block(b: Optional[Dict[str, Any]]) -> None:
            if not b:
                return
            bid = str(b.get("id", ""))
            if not bid or bid in seen_ids:
                return
            seen_ids.add(bid)
            out.append(b)

        add_block(block_map.get(hint))
        add_block(block_map.get(f"{hint}0000"))

        target_line = label_map.get(hint)
        if target_line is not None:
            for b in blocks:
                if self._line_in_block(int(target_line), b):
                    add_block(b)
                    break

        if not out and blocks:
            # Last-resort fallback: earliest executable block.
            add_block(min(blocks, key=self._block_start_line))
        return out

    def _operand_matches_target(self, operand: str, match_names: Set[str]) -> bool:
        up = str(operand).strip().upper()
        if not up:
            return False
        if normalize_token(up) in match_names:
            return True
        for m in match_names:
            if up == m or up.startswith(m + "+") or up.startswith(m + "("):
                return True
        return False

    def _entry_args(self, entry: Dict[str, Any]) -> List[str]:
        args = entry.get("args", []) or []
        if isinstance(args, str):
            return [args]
        return [str(a) for a in args]

    def _resolve_target_block(
        self,
        target_label: str,
        block_map: Dict[str, Dict[str, Any]],
        label_map: Dict[str, int],
    ) -> Optional[str]:
        target = normalize_token(target_label)
        if not target:
            return None
        if target in block_map:
            return target
        target_line = label_map.get(target)
        if target_line is None:
            return None
        for bid, block in block_map.items():
            block_start = self._block_start_line(block)
            if self._line_in_block(int(target_line), block) or int(target_line) == (block_start - 1):
                return str(bid)
        return None

    def _read_match_line(
        self,
        entry: Dict[str, Any],
        match_names: Set[str],
        source_lines: Optional[List[str]] = None,
    ) -> Optional[int]:
        line = int(entry.get("line", 0))
        inst = str(entry.get("inst", "")).upper()

        # Structured var/val entries (MVC family and similar)
        if "val" in entry and self._operand_matches_target(str(entry.get("val", "")), match_names):
            return line if line > 0 else None

        args = self._entry_args(entry)
        if not args:
            return None

        if inst in {"OC", "NC", "XC"}:
            # Read-modify-write style instructions read both operands.
            return line if any(self._operand_matches_target(arg, match_names) for arg in args) else None

        if inst in SETTER_INST:
            dest_idx = DEST_ARG_INDEX_BY_INST.get(inst, 0)
            source_args = [arg for idx, arg in enumerate(args) if idx != dest_idx]
            return line if any(self._operand_matches_target(arg, match_names) for arg in source_args) else None

        if any(self._operand_matches_target(arg, match_names) for arg in args):
            return line if line > 0 else None

        # Fallback for multiline macro invocations (e.g., WTOPC SUB=...WK_RRC)
        # where parser args may only include the first line's key-value pairs.
        if source_lines:
            inst = str(entry.get("inst", "")).upper()
            if line > 0 and line <= len(source_lines) and inst not in SETTER_INST:
                known_inst = SETTER_INST | TRIGGER_INST | BRANCH_INST | SUBROUTINE_INST | CROSS_FILE_INST
                if inst in known_inst:
                    return None
                for ln in range(line, min(line + 4, len(source_lines) + 1)):
                    raw = source_lines[ln - 1]
                    if ln > line:
                        # Stop when the next physical line parses as its own
                        # instruction (i.e., not a continuation line).
                        _lbl, cont_inst, _cont_args = self._parse_instruction_line(raw)
                        if cont_inst:
                            break
                    up = raw.upper()
                    for name in match_names:
                        if re.search(rf"\b{re.escape(name)}\b", up):
                            return ln

        return None

    def _var_is_read_by(
        self,
        entry: Dict[str, Any],
        match_names: Set[str],
        source_lines: Optional[List[str]] = None,
    ) -> bool:
        return self._read_match_line(entry, match_names, source_lines=source_lines) is not None

    def _extract_overwrite(self, entry: Dict[str, Any], match_names: Set[str]) -> Optional[Tuple[str, str]]:
        setter_effect = self._extract_setter_effect(entry)
        if not setter_effect:
            return None
        overwrite_to, new_value = setter_effect
        if normalize_token(overwrite_to) not in match_names:
            return None
        return overwrite_to, new_value

    def _extract_setter_effect(self, entry: Dict[str, Any]) -> Optional[Tuple[str, str]]:
        inst = str(entry.get("inst", "")).upper()

        if "var" in entry:
            dest_raw = str(entry.get("var", ""))
            dest = normalize_token(dest_raw) or dest_raw.strip().upper()
            if not dest:
                return None
            new_value = str(entry.get("val", "")).strip() or "(implicit)"
            return dest, new_value

        args = self._entry_args(entry)
        if not args or inst not in SETTER_INST:
            return None

        # Audit §3a/§3b/§3c/§3d: value-preserving / spec-exception / zero-mask /
        # nonzero-displacement writes are not real setter effects.
        if not is_real_setter_site(inst, args):
            return None

        dest_idx = DEST_ARG_INDEX_BY_INST.get(inst, 0)
        if dest_idx >= len(args):
            return None

        dest_operand = args[dest_idx]
        dest = normalize_token(dest_operand) or dest_operand.strip().upper()
        if not dest:
            return None

        source_operands = [arg for idx, arg in enumerate(args) if idx != dest_idx]
        new_value = ", ".join(source_operands).strip() if source_operands else "(implicit)"
        return dest, new_value

    def _lineage_record(
        self,
        source_asm_file: Path,
        block_id: str,
        line: int,
        inst: str,
        role: str,
        detail: str,
        depth: int,
        args: Optional[List[str]] = None,
        note: Optional[str] = None,
        extra: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        row: Dict[str, Any] = {
            "file": source_asm_file.name,
            "line": line,
            "block": block_id,
            "inst": inst,
            "role": role,
            "detail": detail,
            "depth": depth,
        }
        if args is not None:
            row["args"] = args
        if note:
            row["note"] = note
        if extra:
            row.update(extra)
        return row

    def _scan_subroutine_forward(
        self,
        sub_info: Dict[str, Any],
        asm_lines: List[str],
        source_lines: List[str],
        match_names: Set[str],
        source_asm_file: Path,
        calling_block_id: str,
        call_line: int,
        depth: int,
        block_map: Dict[str, Dict[str, Any]],
        line_metadata: Dict[str, Any],
        results: TraceResults,
    ) -> None:
        start_line = int(sub_info.get("start_line", 0))
        end_line = int(sub_info.get("end_line", 0))
        sub_id = str(sub_info.get("id", ""))
        sub_entries: List[Dict[str, Any]] = []

        # Primary scan mode: use blueprint flow + line_metadata routine ownership.
        sub_id_up = normalize_token(sub_id)
        if sub_id_up and line_metadata:
            for block_id, block in block_map.items():
                for flow_entry in iter_flow(block):
                    line = int(flow_entry.get("line", 0))
                    if line <= 0:
                        continue
                    meta = line_metadata.get(str(line), {}) if isinstance(line_metadata, dict) else {}
                    codeblock = meta.get("codeblock", {}) if isinstance(meta, dict) else {}
                    enclosing = str(codeblock.get("enclosing_routine", "")).upper()
                    if not self._routine_family_match(sub_id_up, enclosing):
                        continue
                    e = dict(flow_entry)
                    e["_block"] = str(block_id)
                    sub_entries.append(e)

        # Fallback: raw asm range from subroutine metadata.
        if not sub_entries:
            if start_line <= 0 or end_line <= 0 or end_line < start_line:
                return
            current_real = 0
            for raw_line in asm_lines:
                is_synthetic = raw_line.lstrip().startswith("*$MACRO")
                if not is_synthetic:
                    current_real += 1
                if current_real < start_line:
                    continue
                if current_real > end_line:
                    break
                _, inst, args = self._parse_instruction_line(raw_line)
                if not inst:
                    continue
                sub_entries.append({"line": current_real, "inst": inst, "args": args, "_block": sub_id})

        sub_entries.sort(key=lambda e: int(e.get("line", 0)))

        for entry in sub_entries:
            line = int(entry.get("line", 0))
            inst = str(entry.get("inst", "")).upper()
            args = self._entry_args(entry)
            entry_block = str(entry.get("_block", sub_id or calling_block_id))

            overwrite = self._extract_overwrite(entry, match_names)
            if overwrite:
                overwrite_to, new_value = overwrite
                results.lineage_chain.append(
                    self._lineage_record(
                        source_asm_file=source_asm_file,
                        block_id=entry_block,
                        line=line,
                        inst=inst,
                        role="SUBROUTINE_USAGE",
                        detail=f"OVERWRITE in subroutine {sub_id}: {overwrite_to} <- {new_value}",
                        depth=depth,
                        args=args,
                        note=f"Called from {calling_block_id}:{call_line}",
                        extra={"overwrite_to": overwrite_to, "new_value_expr": new_value},
                    )
                )
                break

            read_line = self._read_match_line(entry, match_names, source_lines=source_lines)
            if read_line is not None:
                note = f"Called from {calling_block_id}:{call_line}"
                if inst in FORWARD_CONDITION_INST:
                    note = f"Condition test in subroutine. {note}"
                results.lineage_chain.append(
                    self._lineage_record(
                        source_asm_file=source_asm_file,
                        block_id=entry_block,
                        line=read_line,
                        inst=inst,
                        role="SUBROUTINE_USAGE",
                        detail=self._entry_detail(entry),
                        depth=depth,
                        args=args,
                        note=note,
                    )
                )

            if inst in CROSS_FILE_INST and args:
                target_label = normalize_token(str(args[0]))
                if target_label:
                    results.dependent_files.append(
                        {
                            "file": target_label,
                            "target": target_label,
                            "called_from_block": entry_block,
                            "line": line,
                            "type": "NO_RETURN" if inst == "ENTNC" else "RETURN",
                            "calling_file": source_asm_file.stem,
                        }
                    )
                    results.lineage_chain.append(
                        self._lineage_record(
                            source_asm_file=source_asm_file,
                            block_id=entry_block,
                            line=line,
                            inst=inst,
                            role="CROSS_FILE_CALL",
                            detail=", ".join(args),
                            depth=depth,
                            args=args,
                            note="Discovered in subroutine scan",
                        )
                    )

    def _forward_trace(
        self,
        block: Dict[str, Any],
        start_line: int,
        depth: int,
        visited_blocks: Set[str],
        outgoing_map: Dict[str, List[Dict[str, str]]],
        block_map: Dict[str, Dict[str, Any]],
        subroutines: List[Dict[str, Any]],
        asm_lines: List[str],
        source_lines: List[str],
        label_map: Dict[str, int],
        line_metadata: Dict[str, Any],
        match_names: Set[str],
        source_asm_file: Path,
        results: TraceResults,
    ) -> None:
        block_id = str(block.get("id", "UNKNOWN"))
        if block_id in visited_blocks:
            return
        visited_blocks.add(block_id)

        flow = sorted(iter_flow(block), key=lambda e: int(e.get("line", 0)))
        macro_successors: Set[str] = set()
        explicit_branch_successors: Dict[str, Dict[str, Any]] = {}
        block_start = self._block_start_line(block)
        block_end = self._block_end_line(block)
        if block_start > 0 and block_end > 0:
            current_real = 0
            for raw_line in asm_lines:
                is_synth = raw_line.lstrip().startswith("*$MACRO")
                if not is_synth:
                    current_real += 1
                if current_real < block_start:
                    continue
                if current_real > block_end:
                    break
                if not is_synth:
                    continue
                _, m_inst, m_args = self._parse_instruction_line(raw_line)
                m_inst_up = str(m_inst or "").upper()
                if m_inst_up not in BRANCH_INST:
                    continue
                if not m_args:
                    continue
                target_label = str(m_args[0])
                target_block = self._resolve_target_block(target_label, block_map, label_map)
                if target_block:
                    macro_successors.add(target_block)
                    results.lineage_chain.append(
                        self._lineage_record(
                            source_asm_file=source_asm_file,
                            block_id=block_id,
                            line=current_real,
                            inst=m_inst_up,
                            role="MACRO_BRANCH",
                            detail=", ".join([str(x) for x in m_args]),
                            depth=depth,
                            args=[str(x) for x in m_args],
                            note="macro-generated branch",
                        )
                    )
        for idx, entry in enumerate(flow):
            line = int(entry.get("line", 0))
            if line <= start_line:
                continue

            inst = str(entry.get("inst", "")).upper()
            args = self._entry_args(entry)

            if inst in BRANCH_INST and args:
                target_block = self._resolve_target_block(args[0], block_map, label_map)
                if target_block:
                    explicit_branch_successors[target_block] = {
                        "line": line,
                        "inst": inst,
                        "args": [target_block],
                        "raw_args": list(args),
                    }
                    results.lineage_chain.append(
                        self._lineage_record(
                            source_asm_file=source_asm_file,
                            block_id=block_id,
                            line=line,
                            inst=inst,
                            role="BRANCH_ENTRY",
                            detail=", ".join(args),
                            depth=depth,
                            args=[target_block],
                            note=f"Branch to {target_block}",
                        )
                    )

            overwrite = self._extract_overwrite(entry, match_names)
            if overwrite:
                overwrite_to, new_value = overwrite
                results.lineage_chain.append(
                    self._lineage_record(
                        source_asm_file=source_asm_file,
                        block_id=block_id,
                        line=line,
                        inst=inst,
                        role="OVERWRITE",
                        detail=f"{overwrite_to} <- {new_value}",
                        depth=depth,
                        args=args,
                        extra={"overwrite_to": overwrite_to, "new_value_expr": new_value},
                    )
                )
                return

            setter_effect = self._extract_setter_effect(entry)
            if setter_effect:
                effect_var, effect_val = setter_effect
                if not is_dep_var_candidate(
                    effect_var,
                    allow_register_dependencies=self.include_register_dependencies,
                ):
                    continue
                if normalize_token(effect_var) not in match_names:
                    results.lineage_chain.append(
                        self._lineage_record(
                            source_asm_file=source_asm_file,
                            block_id=block_id,
                            line=line,
                            inst=inst,
                            role="SIDE_EFFECT_SETTER",
                            detail=f"{effect_var} <- {effect_val}",
                            depth=depth,
                            args=args,
                            extra={"side_effect_to": effect_var, "new_value_expr": effect_val},
                        )
                    )
                    results.dependent_vars.append(
                        {
                            "variable": effect_var,
                            "block": block_id,
                            "line": line,
                            "reason": (
                                f"Setter reached in forward path of {sorted(match_names)[0] if match_names else 'TARGET'}"
                            ),
                        }
                    )

            read_line = self._read_match_line(entry, match_names, source_lines=source_lines)
            if read_line is not None:
                role = "CONDITION_TEST" if inst in FORWARD_CONDITION_INST else "READER"
                results.lineage_chain.append(
                    self._lineage_record(
                        source_asm_file=source_asm_file,
                        block_id=block_id,
                        line=read_line,
                        inst=inst,
                        role=role,
                        detail=self._entry_detail(entry),
                        depth=depth,
                        args=args,
                    )
                )

                if idx + 1 < len(flow):
                    next_entry = flow[idx + 1]
                    next_inst = str(next_entry.get("inst", "")).upper()
                    next_args = self._entry_args(next_entry)
                    if next_inst in BRANCH_INST:
                        branch_args = list(next_args)
                        if next_args:
                            target_block = self._resolve_target_block(next_args[0], block_map, label_map)
                            if target_block:
                                branch_args = [target_block]
                        results.lineage_chain.append(
                            self._lineage_record(
                                source_asm_file=source_asm_file,
                                block_id=block_id,
                                line=int(next_entry.get("line", 0)),
                                inst=next_inst,
                                role="BRANCH_ON_CONDITION",
                                detail=", ".join(next_args),
                                depth=depth,
                                args=branch_args,
                                note=f"Follows {inst} test at line {line}",
                            )
                        )

            if inst in SUBROUTINE_INST and len(args) >= 2:
                callee = normalize_token(str(args[1]))
                # Record the call itself so forward paths keep visible control-flow
                # context inside a block (e.g., BAS R14,DA7_8000 after a setter).
                results.lineage_chain.append(
                    self._lineage_record(
                        source_asm_file=source_asm_file,
                        block_id=block_id,
                        line=line,
                        inst=inst,
                        role="SUBROUTINE_CALL",
                        detail=", ".join(args),
                        depth=depth,
                        args=args,
                    )
                )
                for sub in subroutines:
                    if str(sub.get("id", "")).upper() != callee:
                        continue
                    self._scan_subroutine_forward(
                        sub_info=sub,
                        asm_lines=asm_lines,
                        source_lines=source_lines,
                        match_names=match_names,
                        source_asm_file=source_asm_file,
                        calling_block_id=block_id,
                        call_line=line,
                        depth=depth,
                        block_map=block_map,
                        line_metadata=line_metadata,
                        results=results,
                    )
                    break

            if inst in CROSS_FILE_INST and args:
                target_label = normalize_token(str(args[0]))
                if target_label:
                    results.dependent_files.append(
                        {
                            "file": target_label,
                            "target": target_label,
                            "called_from_block": block_id,
                            "line": line,
                            "type": "NO_RETURN" if inst == "ENTNC" else "RETURN",
                            "calling_file": source_asm_file.stem,
                        }
                    )
                    results.lineage_chain.append(
                        self._lineage_record(
                            source_asm_file=source_asm_file,
                            block_id=block_id,
                            line=line,
                            inst=inst,
                            role="CROSS_FILE_CALL",
                            detail=", ".join(args),
                            depth=depth,
                            args=args,
                        )
                    )

        # Phase 1.5: Return to Subroutine Callers
        # If this block has callers invoking it via SUBROUTINE_CALL, we must return to them.
        subroutine_callers = [
            ref.get("source") for ref in (block.get("incoming_branches", []) or [])
            if str(ref.get("type", "")).upper() == "SUBROUTINE_CALL" and ref.get("source")
        ]

        for caller_id in subroutine_callers:
            if caller_id in visited_blocks:
                continue
            caller_block = block_map.get(str(caller_id))
            if not caller_block:
                continue

            call_lines = []
            for e in iter_flow(caller_block):
                c_inst = str(e.get("inst", "")).upper()
                if c_inst in SUBROUTINE_INST:
                    c_args = self._entry_args(e)
                    if len(c_args) >= 2 and normalize_token(c_args[1]) == normalize_token(block_id):
                        call_lines.append(int(e.get("line", 0)))
            
            for c_line in call_lines:
                results.lineage_chain.append(
                    self._lineage_record(
                        source_asm_file=source_asm_file,
                        block_id=block_id,
                        line=max(start_line, block_end, 0),
                        inst="(return)",
                        role="RETURN_TO_CALLER",
                        detail=f"Return to {caller_id} after subroutine call",
                        depth=depth,
                        args=[str(caller_id)],
                    )
                )
                self._forward_trace(
                    block=caller_block,
                    start_line=c_line,
                    depth=depth + 1,
                    visited_blocks=visited_blocks,
                    outgoing_map=outgoing_map,
                    block_map=block_map,
                    subroutines=subroutines,
                    asm_lines=asm_lines,
                    source_lines=source_lines,
                    label_map=label_map,
                    line_metadata=line_metadata,
                    match_names=match_names,
                    source_asm_file=source_asm_file,
                    results=results,
                )

        successors: Dict[str, Dict[str, Any]] = {}
        for edge in outgoing_map.get(block_id, []):
            succ_id = str(edge.get("target", ""))
            if not succ_id:
                continue
            edge_type = str(edge.get("type", "BRANCH")).upper()
            if succ_id not in successors:
                successors[succ_id] = {
                    "edge_type": edge_type,
                    "line": 0,
                    "inst": "(fall-through)" if edge_type == "FALLTHROUGH" else "(branch)",
                    "args": [succ_id],
                    "detail": f"{edge_type} edge to {succ_id}",
                    "role": "FALLTHROUGH_ENTRY" if edge_type == "FALLTHROUGH" else "BRANCH_ENTRY",
                }
            if edge_type == "FALLTHROUGH":
                last_line = max((int(e.get("line", 0)) for e in flow), default=block_end if block_end > 0 else 0)
                # Use the next physical line so this synthetic marker does not
                # collide with a real branch instruction on the same line.
                successors[succ_id]["line"] = max(int(successors[succ_id].get("line", 0)), int(last_line) + 1)

        for succ_id, meta in explicit_branch_successors.items():
            existing = successors.get(succ_id)
            if existing and existing.get("edge_type") == "FALLTHROUGH":
                # Keep explicit branch metadata but preserve that a fall-through edge also exists.
                meta = dict(meta)
                meta["edge_type"] = "BRANCH"
            else:
                meta = dict(meta)
                meta["edge_type"] = "BRANCH"
            meta["role"] = "BRANCH_ENTRY"
            meta["detail"] = ", ".join(meta.get("args", []))
            successors[succ_id] = meta

        for succ_id in sorted(macro_successors):
            successors.setdefault(
                succ_id,
                {
                    "edge_type": "MACRO_BRANCH",
                    "line": 0,
                    "inst": "(macro-branch)",
                    "args": [succ_id],
                    "detail": f"MACRO_BRANCH edge to {succ_id}",
                    "role": "MACRO_BRANCH",
                },
            )

        for succ_id, meta in sorted(successors.items(), key=lambda kv: kv[0]):
            if succ_id in visited_blocks:
                continue
            successor = block_map.get(succ_id)
            if not successor:
                self._record_data_quality_warning(
                    block_id=block_id,
                    line=max(start_line, 0),
                    message=f"successor reference missing block: {succ_id}",
                    source_asm_file=source_asm_file,
                    results=results,
                )
                continue

            role = str(meta.get("role", ""))
            inst = str(meta.get("inst", ""))
            args = [str(x) for x in (meta.get("args", []) or [])]
            edge_line = int(meta.get("line", 0) or 0)
            if edge_line <= 0 and flow:
                edge_line = max(int(e.get("line", 0)) for e in flow)
            if role in {"FALLTHROUGH_ENTRY", "BRANCH_ENTRY"}:
                results.lineage_chain.append(
                    self._lineage_record(
                        source_asm_file=source_asm_file,
                        block_id=block_id,
                        line=edge_line,
                        inst=inst,
                        role=role,
                        detail=str(meta.get("detail", "")),
                        depth=depth,
                        args=args if args else [succ_id],
                    )
                )

            self._forward_trace(
                block=successor,
                start_line=0,
                depth=depth + 1,
                visited_blocks=visited_blocks,
                outgoing_map=outgoing_map,
                block_map=block_map,
                subroutines=subroutines,
                asm_lines=asm_lines,
                source_lines=source_lines,
                label_map=label_map,
                line_metadata=line_metadata,
                match_names=match_names,
                source_asm_file=source_asm_file,
                results=results,
            )

    def _parse_instruction_line(self, line: str) -> Tuple[Optional[str], Optional[str], List[str]]:
        from trace_lineage import parse_instruction_line

        return parse_instruction_line(line)

    def _stem_has_assets(self, stem: str) -> bool:
        asm = self.asm_dir / f"{stem}.asm"
        bp = self.blueprint_dir / f"{stem}.asm.json"
        return asm.exists() and bp.exists()

    def _build_cross_file_indices(self) -> None:
        if self._indices_built:
            return

        self._entry_to_files = {}
        self._sub_to_files = {}
        # Intentionally avoid call_graph indexing for resolution. In current
        # parser outputs this can create false-positive local matches.

        for bp_path in sorted(self.blueprint_dir.glob("*.json")):
            name = bp_path.name.lower()
            if name.endswith(".asm.json"):
                stem = name[:-9]
            else:
                stem = bp_path.stem.lower()

            try:
                blueprint = load_blueprint(bp_path)
            except Exception:
                continue

            for entry_label in _find_entry_dispatch_blocks(blueprint):
                lbl = normalize_token(str(entry_label))
                if lbl:
                    self._entry_to_files.setdefault(lbl, set()).add(stem)

            for sub in blueprint.get("subroutines", []) or []:
                sid = normalize_token(str(sub.get("id", "")))
                if sid:
                    self._sub_to_files.setdefault(sid, set()).add(stem)

        self._indices_built = True

    def _resolve_cross_file_target(self, target_label: str) -> CrossFileResolution:
        self._build_cross_file_indices()

        target = normalize_token(target_label)
        if not target:
            return CrossFileResolution(stems=[], reason="Empty cross-file target")

        # 1) Direct file-stem match.
        direct_stem = target.lower()
        if self._stem_has_assets(direct_stem):
            return CrossFileResolution(stems=[direct_stem], reason="DIRECT_FILE_STEM")

        # 2) Entry-dispatch index.
        entry_candidates = sorted(self._entry_to_files.get(target, set()))
        entry_valid = [s for s in entry_candidates if self._stem_has_assets(s)]
        if len(entry_valid) == 1:
            return CrossFileResolution(stems=entry_valid, reason="ENTRY_DISPATCH_INDEX")

        # 3) Subroutine-id index fallback.
        sub_candidates = sorted(self._sub_to_files.get(target, set()))
        sub_valid = [s for s in sub_candidates if self._stem_has_assets(s)]
        if len(sub_valid) == 1:
            return CrossFileResolution(stems=sub_valid, reason="SUBROUTINE_INDEX")

        # Merge candidates for ambiguity handling.
        merged = sorted(set(entry_valid) | set(sub_valid))
        if merged:
            chosen = merged[0]
            return CrossFileResolution(
                stems=[chosen],
                reason="AMBIGUOUS_RESOLVED_LEXICAL",
                warning=(
                    f"Ambiguous cross-file target {target}: candidates={','.join(merged)}. "
                    f"Chose {chosen} by lexical tie-break."
                ),
            )

        # If we had candidate labels but files are missing, report that explicitly.
        merged_unavailable = sorted(
            set(entry_candidates) | set(sub_candidates)
        )
        if merged_unavailable:
            return CrossFileResolution(
                stems=[],
                reason=(
                    f"Target label mapped to candidate files without complete ASM+blueprint assets: "
                    f"{','.join(merged_unavailable)}"
                ),
            )

        return CrossFileResolution(stems=[], reason="Target label not mapped to any file")

    def _trace_file_forward(
        self,
        target_variable: str,
        source_asm_file: Path,
        blueprint_file: Path,
        results: TraceResults,
        caller_chunk_id: Optional[str] = None,
        inbound_target: Optional[str] = None,
        entry_hint: Optional[str] = None,
    ) -> None:
        file_key = str(source_asm_file.resolve())
        state_key = (
            file_key,
            normalize_token(entry_hint or ""),
            normalize_token(inbound_target or ""),
            str(caller_chunk_id or ""),
        )
        if state_key in self._visited_forward_states:
            return
        self._visited_forward_states.add(state_key)
        self.visited_files.add(file_key)
        chain_len_before = len(results.lineage_chain)

        if not blueprint_file.exists():
            results.unresolved_files.append(
                {
                    "file": source_asm_file.stem.upper(),
                    "status": "Blueprint missing - manual review required",
                }
            )
            return

        blueprint = load_blueprint(blueprint_file)
        source_lines = load_asm_lines(source_asm_file)
        asm_lines = expand_macro_branches(source_lines)
        label_map = build_label_map(asm_lines)

        aliases = self._resolve_aliases(target_variable, blueprint.get("meta", {}).get("aliases", []))
        match_names = {target_variable.upper()} | aliases

        blocks = blueprint.get("blocks", []) or []
        block_map = {str(b.get("id", "")): b for b in blocks}
        outgoing_map = self._build_outgoing_map(blocks)

        setter_queue: List[Dict[str, Any]] = []

        # Phase 1: find setters for target variable.
        for block in blocks:
            block_id = str(block.get("id", "UNKNOWN"))
            for entry in iter_flow(block):
                inst = str(entry.get("inst", "")).upper()
                if inst not in SETTER_INST:
                    continue
                if not self._entry_touches_match(entry, match_names):
                    continue

                line = int(entry.get("line", 0))
                results.lineage_chain.append(
                    self._lineage_record(
                        source_asm_file=source_asm_file,
                        block_id=block_id,
                        line=line,
                        inst=inst,
                        role="SETTER",
                        detail=self._entry_detail(entry),
                        depth=0,
                        args=self._entry_args(entry),
                    )
                )
                setter_queue.append({"block": block, "setter_line": line})

        # Phase 1.25: collect usage/read seeds (earliest usage per block).
        usage_seed_by_block: Dict[str, Dict[str, Any]] = {}
        for block in blocks:
            block_id = str(block.get("id", "UNKNOWN"))
            for entry in iter_flow(block):
                read_line = self._read_match_line(entry, match_names, source_lines=source_lines)
                if read_line is None:
                    continue
                current = usage_seed_by_block.get(block_id)
                if current is None or int(read_line) < int(current.get("line", 0)):
                    usage_seed_by_block[block_id] = {
                        "line": int(read_line),
                        "inst": str(entry.get("inst", "")).upper(),
                        "args": self._entry_args(entry),
                        "detail": self._entry_detail(entry),
                    }

        # Phase 1.5: inbound caller anchor nodes.
        if inbound_target:
            inbound_target_up = inbound_target.upper()
            for block in blocks:
                block_id = str(block.get("id", "UNKNOWN"))
                for entry in iter_flow(block):
                    inst = str(entry.get("inst", "")).upper()
                    if inst not in CROSS_FILE_INST:
                        continue
                    args = self._entry_args(entry)
                    if not args:
                        continue
                    if str(args[0]).strip().upper() != inbound_target_up:
                        continue
                    results.lineage_chain.append(
                        {
                            "file": source_asm_file.name,
                            "line": int(entry.get("line", 0)),
                            "block": block_id,
                            "inst": inst,
                            "role": "CROSS_FILE_CALL",
                            "args": [inbound_target],
                            "detail": f"{inst} {inbound_target} (inbound entry caller)",
                            "depth": 0,
                            "_inbound_entry_call": {
                                "caller_file": source_asm_file.stem,
                                "entry": inbound_target,
                            },
                        }
                    )

        # Phase 2: forward trace setter seeds first and record covered blocks.
        setter_covered_blocks: Set[str] = set()
        for work in setter_queue:
            visited_blocks: Set[str] = set()
            self._forward_trace(
                block=work["block"],
                start_line=int(work["setter_line"]),
                depth=0,
                visited_blocks=visited_blocks,
                outgoing_map=outgoing_map,
                block_map=block_map,
                subroutines=blueprint.get("subroutines", []) or [],
                asm_lines=asm_lines,
                source_lines=source_lines,
                label_map=label_map,
                line_metadata=blueprint.get("line_metadata", {}) or {},
                match_names=match_names,
                source_asm_file=source_asm_file,
                results=results,
            )
            setter_covered_blocks.update(visited_blocks)

        # Phase 2.1: usage/read seeds for blocks not already covered by setter traces.
        def cfg_reachable_blocks(seed_block_id: str) -> Set[str]:
            seen: Set[str] = set()
            stack: List[str] = [seed_block_id]
            while stack:
                cur = stack.pop()
                if cur in seen:
                    continue
                seen.add(cur)
                for edge in outgoing_map.get(cur, []):
                    nxt = str(edge.get("target", ""))
                    if not nxt or nxt in seen or nxt not in block_map:
                        continue
                    stack.append(nxt)
            return seen

        usage_seed_queue: List[Dict[str, Any]] = []
        for block_id in sorted(usage_seed_by_block.keys()):
            if block_id in setter_covered_blocks:
                continue
            # Additional de-dup guard:
            # if this usage-seed block eventually merges into setter-covered CFG,
            # skip it to avoid widening previously-setter-covered ancestry slices.
            if setter_covered_blocks:
                reachable = cfg_reachable_blocks(block_id)
                if reachable & setter_covered_blocks:
                    continue
            seed = usage_seed_by_block[block_id]
            seed_line = int(seed.get("line", 0))
            if seed_line <= 0:
                continue
            usage_seed_queue.append(
                {
                    "block_id": block_id,
                    "seed_line": seed_line,
                    "seed_inst": str(seed.get("inst", "")),
                    "seed_args": [str(x) for x in (seed.get("args", []) or [])],
                    "seed_detail": str(seed.get("detail", "")),
                }
            )

        if not setter_queue and usage_seed_queue:
            self._record_data_quality_warning(
                block_id="GLOBAL",
                line=0,
                message=(
                    f"No setters found for {target_variable.upper()} in {source_asm_file.name}; "
                    "forward trace seeded from usage/read sites"
                ),
                source_asm_file=source_asm_file,
                results=results,
            )

        # Traverse uncovered usage seeds, skipping usage seeds already covered
        # by prior usage-seed traversals.
        usage_covered_blocks: Set[str] = set(setter_covered_blocks)
        for usage_seed in usage_seed_queue:
            block_id = str(usage_seed.get("block_id", ""))
            if block_id in usage_covered_blocks:
                continue
            seed_block = block_map.get(block_id)
            if not seed_block:
                continue

            seed_line = int(usage_seed.get("seed_line", 0))
            seed_inst = str(usage_seed.get("seed_inst", ""))
            seed_args = [str(x) for x in (usage_seed.get("seed_args", []) or [])]
            seed_role = "USAGE_SEED_CONDITION" if seed_inst in FORWARD_CONDITION_INST else "USAGE_SEED"
            if setter_queue:
                seed_note = "Usage seed not covered by setter-seeded traversal"
            else:
                seed_note = "No target setter found in file; seeded from variable usage"

            results.lineage_chain.append(
                self._lineage_record(
                    source_asm_file=source_asm_file,
                    block_id=block_id,
                    line=seed_line,
                    inst=seed_inst,
                    role=seed_role,
                    detail=str(usage_seed.get("seed_detail", "")),
                    depth=0,
                    args=seed_args,
                    note=seed_note,
                )
            )

            visited_blocks: Set[str] = set()
            self._forward_trace(
                block=seed_block,
                start_line=seed_line,
                depth=0,
                visited_blocks=visited_blocks,
                outgoing_map=outgoing_map,
                block_map=block_map,
                subroutines=blueprint.get("subroutines", []) or [],
                asm_lines=asm_lines,
                source_lines=source_lines,
                label_map=label_map,
                line_metadata=blueprint.get("line_metadata", {}) or {},
                match_names=match_names,
                source_asm_file=source_asm_file,
                results=results,
            )
            usage_covered_blocks.update(visited_blocks)

        # Phase 2.25: when forward trace crosses files, continue from entry
        # dispatch hints even if callee has no local setters yet.
        seed_hints: List[str] = []
        if entry_hint:
            seed_hints.append(entry_hint)
        if inbound_target and inbound_target not in seed_hints:
            seed_hints.append(inbound_target)
        for hint in seed_hints:
            for seed_block in self._entry_seed_blocks(hint, block_map, blocks, label_map):
                visited_blocks: Set[str] = set()
                self._forward_trace(
                    block=seed_block,
                    start_line=0,
                    depth=0,
                    visited_blocks=visited_blocks,
                    outgoing_map=outgoing_map,
                    block_map=block_map,
                    subroutines=blueprint.get("subroutines", []) or [],
                    asm_lines=asm_lines,
                    source_lines=source_lines,
                    label_map=label_map,
                    line_metadata=blueprint.get("line_metadata", {}) or {},
                    match_names=match_names,
                    source_asm_file=source_asm_file,
                    results=results,
                )

        # Phase 2.5: discover inbound entry callers for PRIMARY file.
        if caller_chunk_id is None and inbound_target is None and self.asm_dir and self.blueprint_dir:
            entry_dispatch = _find_entry_dispatch_blocks(blueprint)
            lineage_blocks = {
                str(entry.get("block", ""))
                for entry in results.lineage_chain[chain_len_before:]
                if entry.get("file") == source_asm_file.name
            }
            already_queued = {str(d.get("file", "")).strip().lower() for d in results.dependent_files}

            for entry_name in sorted(entry_dispatch & lineage_blocks):
                entry_up = entry_name.upper()
                pattern = re.compile(rf"\b(?:ENTNC|ENTRC)\s+{re.escape(entry_up)}\b", re.IGNORECASE)
                for asm_path in self.asm_dir.glob("*.asm"):
                    stem = asm_path.stem.lower()
                    if stem == source_asm_file.stem.lower():
                        continue
                    if str(asm_path.resolve()) in self.visited_files:
                        continue
                    if stem in already_queued:
                        continue
                    try:
                        content = asm_path.read_text(encoding="utf-8", errors="ignore")
                    except Exception:
                        continue
                    if pattern.search(content):
                        results.dependent_files.append(
                            {
                                "file": stem,
                                "calling_file": source_asm_file.stem,
                                "target": entry_name,
                                "type": "INBOUND_ENTRY",
                            }
                        )
                        already_queued.add(stem)

        # Mark all nodes added during this file trace with cross-file parent.
        if caller_chunk_id:
            for entry in results.lineage_chain[chain_len_before:]:
                entry["_cross_file_parent"] = caller_chunk_id

        # Phase 4: cross-file resolution and recursion.
        for dep in list(results.dependent_files):
            dep_type = str(dep.get("type", "")).upper()
            calling_file = str(dep.get("calling_file", ""))
            caller_cid = (
                f"{calling_file}:{dep.get('called_from_block', '')}:{dep.get('line', 0)}"
                if calling_file
                else None
            )

            # Inbound entries already carry concrete file stem in dep['file'].
            if dep_type == "INBOUND_ENTRY":
                dep_stem = str(dep.get("file", "")).strip().lower()
                if not dep_stem:
                    continue
                dep_asm = self.asm_dir / f"{dep_stem}.asm"
                dep_bp = self.blueprint_dir / f"{dep_stem}.asm.json"
                asm_exists = dep_asm.exists()
                bp_exists = dep_bp.exists()
                inbound = str(dep.get("target", "")) or None
                if asm_exists and bp_exists:
                    self._trace_file_forward(
                        target_variable=target_variable,
                        source_asm_file=dep_asm,
                        blueprint_file=dep_bp,
                        results=results,
                        caller_chunk_id=None,
                        inbound_target=inbound,
                        entry_hint=inbound,
                    )
                elif asm_exists and not bp_exists:
                    results.unresolved_files.append(
                        {"file": dep_stem.upper(), "status": "Blueprint missing - manual review required"}
                    )
                elif bp_exists and not asm_exists:
                    results.unresolved_files.append(
                        {"file": dep_stem.upper(), "status": "ASM file missing - manual review required"}
                    )
                else:
                    results.unresolved_files.append(
                        {"file": dep_stem.upper(), "status": "ASM + Blueprint missing - manual review required"}
                    )
                continue

            raw_target = str(dep.get("target", dep.get("file", "")))
            resolved = self._resolve_cross_file_target(raw_target)
            if resolved.warning:
                self._record_data_quality_warning(
                    block_id=str(dep.get("called_from_block", "")),
                    line=int(dep.get("line", 0) or 0),
                    message=resolved.warning,
                    source_asm_file=source_asm_file,
                    results=results,
                )

            if not resolved.stems:
                results.unresolved_files.append(
                    {"file": normalize_token(raw_target).upper(), "status": resolved.reason}
                )
                continue

            for dep_stem in resolved.stems:
                dep_asm = self.asm_dir / f"{dep_stem}.asm"
                dep_bp = self.blueprint_dir / f"{dep_stem}.asm.json"
                asm_exists = dep_asm.exists()
                bp_exists = dep_bp.exists()
                dep["file"] = dep_stem
                dep["resolution_reason"] = resolved.reason

                if asm_exists and bp_exists:
                    self._trace_file_forward(
                        target_variable=target_variable,
                        source_asm_file=dep_asm,
                        blueprint_file=dep_bp,
                        results=results,
                        caller_chunk_id=caller_cid,
                        inbound_target=None,
                        entry_hint=raw_target,
                    )
                elif asm_exists and not bp_exists:
                    results.unresolved_files.append(
                        {"file": dep_stem.upper(), "status": "Blueprint missing - manual review required"}
                    )
                elif bp_exists and not asm_exists:
                    results.unresolved_files.append(
                        {"file": dep_stem.upper(), "status": "ASM file missing - manual review required"}
                    )
                else:
                    results.unresolved_files.append(
                        {"file": dep_stem.upper(), "status": "ASM + Blueprint missing - manual review required"}
                    )

    def _post_process(self, results: TraceResults) -> None:
        def dedupe(items: List[Dict[str, Any]], key_fn):
            seen = set()
            out = []
            for item in items:
                k = key_fn(item)
                if k in seen:
                    continue
                seen.add(k)
                out.append(item)
            return out

        role_priority = {
            "OVERWRITE": 105,
            "SETTER": 100,
            "SETTER_IN_SUB": 95,
            "SIDE_EFFECT_SETTER": 94,
            "USAGE_SEED_CONDITION": 93,
            "USAGE_SEED": 91,
            "CONDITION_TEST": 92,
            "TRIGGER": 90,
            "BRANCH_ON_CONDITION": 89,
            "READER": 88,
            "GUARD_BRANCH": 85,
            "BRANCH_TO_SETTER": 80,
            "CROSS_FILE_CALL": 76,
            "BRANCH_ENTRY": 75,
            "FALLTHROUGH_ENTRY": 73,
            "MACRO_BRANCH": 70,
            "SUBROUTINE_USAGE": 68,
            "SUBROUTINE_CALL": 60,
        }

        best_by_key: Dict[Tuple[Any, Any, Any], Dict[str, Any]] = {}
        for row in results.lineage_chain:
            key = (row.get("file"), row.get("line"), row.get("block"))
            existing = best_by_key.get(key)
            if existing is None:
                best_by_key[key] = row
                continue

            existing_score = (
                role_priority.get(str(existing.get("role", "")), 0),
                -int(existing.get("depth", 0) or 0),
            )
            candidate_score = (
                role_priority.get(str(row.get("role", "")), 0),
                -int(row.get("depth", 0) or 0),
            )
            if candidate_score > existing_score:
                best_by_key[key] = row

        results.lineage_chain = sorted(
            best_by_key.values(),
            key=lambda x: (int(x.get("line", 0)), str(x.get("file", ""))),
        )

        filtered_dep_vars = []
        for row in results.dependent_vars:
            var = str(row.get("variable", "")).strip()
            if not is_dep_var_candidate(
                var,
                allow_register_dependencies=self.include_register_dependencies,
            ):
                continue
            if normalize_token(var) != var:
                row = {**row, "variable": normalize_token(var)}
            filtered_dep_vars.append(row)

        results.dependent_vars = sorted(
            dedupe(
                filtered_dep_vars,
                lambda x: (x.get("variable"), x.get("block"), x.get("line"), x.get("reason")),
            ),
            key=lambda x: (x.get("variable", ""), int(x.get("line", 0))),
        )

        results.dependent_files = sorted(
            dedupe(
                results.dependent_files,
                lambda x: (
                    x.get("file"),
                    x.get("target"),
                    x.get("called_from_block"),
                    x.get("line"),
                    x.get("type"),
                ),
            ),
            key=lambda x: (x.get("file", ""), int(x.get("line", 0))),
        )

        results.unresolved_files = dedupe(
            results.unresolved_files,
            lambda x: (x.get("file"), x.get("status")),
        )

        results.data_quality_warnings = dedupe(
            results.data_quality_warnings,
            lambda x: (x.get("file"), x.get("block"), x.get("line"), x.get("message")),
        )

    # -----------------------------------------------------------------------
    # Public entry point: trace forward from a SPECIFIC setter
    # -----------------------------------------------------------------------

    def trace_forward_from_setter(
        self,
        target_variable: str,
        source_asm_file: Path,
        blueprint_file: Path,
        start_block_id: str,
        start_line: int,
    ) -> TraceResults:
        """Trace forward from one specific setter instruction until the next OVERWRITE.

        Unlike trace_forward(), which auto-discovers every setter in the file,
        this method starts exactly at (start_block_id, start_line) and walks
        execution forward, collecting:
          - READER / CONDITION_TEST   — places the variable is *read*
          - BRANCH_ON_CONDITION       — conditional branches after a condition test
          - SIDE_EFFECT_SETTER        — writes to *other* variables along the path
          - OVERWRITE                 — first re-write of the target variable;
                                        each forward path stops here

        Cross-file calls (ENTNC/ENTRC) are noted but NOT followed — this is
        intentionally intra-file so the result stays in one file.

        Args:
            target_variable:  Variable name to trace (e.g. "WK_RRC").
            source_asm_file:  Path to the .asm source file.
            blueprint_file:   Path to the corresponding .asm.json blueprint.
            start_block_id:   Block that contains the setter (e.g. "DA7_1800").
            start_line:       Line number of the setter instruction (inclusive
                              start — the setter itself is NOT re-emitted; only
                              instructions *after* this line are traced).
        """
        self.visited_files = set()
        self._visited_forward_states = set()
        results = TraceResults()

        if not blueprint_file.exists():
            results.unresolved_files.append({
                "file": source_asm_file.stem.upper(),
                "status": "Blueprint missing - manual review required",
            })
            return results

        blueprint = load_blueprint(blueprint_file)
        source_lines = load_asm_lines(source_asm_file)
        asm_lines = expand_macro_branches(source_lines)
        label_map = build_label_map(asm_lines)

        aliases = self._resolve_aliases(
            target_variable, blueprint.get("meta", {}).get("aliases", [])
        )
        match_names: Set[str] = {target_variable.upper()} | aliases

        blocks = blueprint.get("blocks", []) or []
        block_map: Dict[str, Dict[str, Any]] = {str(b.get("id", "")): b for b in blocks}
        outgoing_map = self._build_outgoing_map(blocks)

        # Locate the starting block (case-insensitive, with and without trailing zeros).
        start_norm = normalize_token(start_block_id) or start_block_id.strip().upper()
        start_block = block_map.get(start_norm)
        if start_block is None:
            # Try appending "0000" suffix (common HLASM block naming convention).
            start_block = block_map.get(f"{start_norm}0000")
        if start_block is None:
            results.data_quality_warnings.append({
                "file": source_asm_file.name,
                "block": start_block_id,
                "line": start_line,
                "message": (
                    f"Block '{start_block_id}' not found in {source_asm_file.name}. "
                    f"Available blocks: {', '.join(sorted(block_map.keys())[:20])}"
                ),
            })
            return results

        visited_blocks: Set[str] = set()
        self._forward_trace(
            block=start_block,
            start_line=start_line,
            depth=0,
            visited_blocks=visited_blocks,
            outgoing_map=outgoing_map,
            block_map=block_map,
            subroutines=blueprint.get("subroutines", []) or [],
            asm_lines=asm_lines,
            source_lines=source_lines,
            label_map=label_map,
            line_metadata=blueprint.get("line_metadata", {}) or {},
            match_names=match_names,
            source_asm_file=source_asm_file,
            results=results,
        )

        self._post_process(results)
        return results


def apply_forward_graph_wiring(graph: Dict[str, Any]) -> Dict[str, Any]:
    """Forward-only parent rewiring.

    Keeps shared graph builder unchanged for backward lineage while allowing
    forward traces to prefer deeper/specific branch bridges.
    """
    nodes = graph.get("nodes", []) or []
    if not nodes:
        return graph

    from collections import defaultdict

    bridge_roles = {
        "BRANCH_ENTRY",
        "FALLTHROUGH_ENTRY",
        "BRANCH_ON_CONDITION",
        "GUARD_BRANCH",
        "MACRO_BRANCH",
        "BRANCH_TO_SETTER",
        "SUBROUTINE_CALL",
    }
    role_priority = {
        "GUARD_BRANCH": 85,
        "BRANCH_TO_SETTER": 80,
        "BRANCH_ENTRY": 75,
        "BRANCH_ON_CONDITION": 74,
        "FALLTHROUGH_ENTRY": 73,
        "MACRO_BRANCH": 70,
        "SUBROUTINE_CALL": 65,
    }

    def bridge_target(node: Dict[str, Any]) -> str:
        role = str(node.get("role", ""))
        args = node.get("args", []) or []
        if not args:
            return ""
        if role == "SUBROUTINE_CALL":
            return normalize_token(str(args[1])) if len(args) >= 2 else ""
        return normalize_token(str(args[0]))

    def bridge_score(node: Dict[str, Any]) -> Tuple[int, int, int]:
        role = str(node.get("role", ""))
        return (
            role_priority.get(role, 0),
            int(node.get("depth", 0) or 0),
            -int(node.get("line", 0) or 0),
        )

    blocks_entries: Dict[Tuple[str, str], List[Dict[str, Any]]] = defaultdict(list)
    node_by_id: Dict[str, Dict[str, Any]] = {}
    for n in nodes:
        cid = str(n.get("chunk_id", ""))
        if cid:
            node_by_id[cid] = n
        fs = Path(str(n.get("file", ""))).stem
        blk = str(n.get("block", ""))
        blocks_entries[(fs, blk)].append(n)
    for key in blocks_entries:
        blocks_entries[key].sort(key=lambda n: int(n.get("line", 0)))

    best_bridge: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for node in sorted(nodes, key=lambda n: (int(n.get("line", 0)), str(n.get("file", "")))):
        role = str(node.get("role", ""))
        if role not in bridge_roles:
            continue
        target = bridge_target(node)
        if not target:
            continue
        fs = Path(str(node.get("file", ""))).stem
        key = (fs, target)
        candidate = {
            "chunk_id": str(node.get("chunk_id", "")),
            "role": role,
            "inst": str(node.get("inst", "")),
            "parent_block": str(node.get("block", "")),
            "score": bridge_score(node),
        }
        existing = best_bridge.get(key)
        if not existing or candidate["score"] > existing["score"]:
            best_bridge[key] = candidate

    for (fs, blk), entries in blocks_entries.items():
        if not entries:
            continue
        first = entries[0]
        cand = best_bridge.get((fs, blk))
        if not cand:
            continue
        if cand["chunk_id"] == str(first.get("chunk_id", "")):
            continue

        existing_edge_type = str((first.get("edge_to_parent") or {}).get("type", ""))
        if existing_edge_type in {"CROSS_FILE_ENTRY", "INBOUND_ENTRY", "SHARED_INBOUND_ENTRY"}:
            continue

        current_score: Optional[Tuple[int, int, int]] = None
        current_parent_id = str(first.get("parent_chunk_id", ""))
        if current_parent_id and current_parent_id in node_by_id:
            parent_node = node_by_id[current_parent_id]
            prole = str(parent_node.get("role", ""))
            ptarget = bridge_target(parent_node)
            pfs = Path(str(parent_node.get("file", ""))).stem
            if prole in bridge_roles and pfs == fs and ptarget == blk:
                current_score = bridge_score(parent_node)
        if current_score is not None and current_score >= cand["score"]:
            continue

        first["parent_chunk_id"] = cand["chunk_id"]
        role = cand["role"]
        inst = cand["inst"]
        parent_blk = cand["parent_block"]
        if role == "FALLTHROUGH_ENTRY":
            first["edge_to_parent"] = {
                "type": "FALLTHROUGH",
                "description": f"Fall-through from {parent_blk} to {blk}",
            }
        elif role == "GUARD_BRANCH":
            first["edge_to_parent"] = {
                "type": "GUARD_BRANCH",
                "inst": inst,
                "target_block": blk,
                "description": f"Guard branch {inst} taken to {blk}",
            }
        elif role == "MACRO_BRANCH":
            first["edge_to_parent"] = {
                "type": "MACRO_BRANCH",
                "inst": inst,
                "target_block": blk,
                "description": f"Macro-generated branch {inst} to {blk}",
            }
        elif role == "BRANCH_TO_SETTER":
            first["edge_to_parent"] = {
                "type": "BRANCH_TO_SETTER",
                "inst": inst,
                "target_block": blk,
                "description": f"Branch {inst} directly to setter block {blk}",
            }
        elif role == "BRANCH_ON_CONDITION":
            first["edge_to_parent"] = {
                "type": "BRANCH_ON_CONDITION",
                "inst": inst,
                "target_block": blk,
                "description": f"Condition branch {inst} to {blk}",
            }
        else:
            first["edge_to_parent"] = {
                "type": "BRANCH",
                "inst": inst,
                "target_block": blk,
                "description": f"Branch via {inst} to {blk}",
            }

    return graph


def build_block_graph_from_lineage_graph(graph: Dict[str, Any]) -> Dict[str, Any]:
    """Convert instruction-level lineage graph to a block-level graph."""
    line_nodes = graph.get("nodes", []) or []
    if not line_nodes:
        return {
            "variable": graph.get("variable"),
            "file": graph.get("file"),
            "graph_level": "block",
            "nodes": [],
            "edges": [],
            "dependent_vars": graph.get("dependent_vars", []),
            "dependent_files": graph.get("dependent_files", []),
            "unresolved_files": graph.get("unresolved_files", []),
            "data_quality_warnings": graph.get("data_quality_warnings", []),
        }

    def block_uid(node: Dict[str, Any]) -> str:
        return f"{Path(str(node.get('file', ''))).stem}:{str(node.get('block', ''))}"

    node_by_chunk: Dict[str, Dict[str, Any]] = {}
    for node in line_nodes:
        cid = str(node.get("chunk_id", "")).strip()
        if cid:
            node_by_chunk[cid] = node

    block_nodes: Dict[str, Dict[str, Any]] = {}
    edge_rows: List[Dict[str, Any]] = []
    edge_seen: Set[Tuple[str, str, str, str, int]] = set()

    for node in line_nodes:
        b_uid = block_uid(node)
        line = int(node.get("line", 0) or 0)
        role = str(node.get("role", ""))
        inst = str(node.get("inst", ""))
        detail = str(node.get("detail", ""))
        file_name = str(node.get("file", ""))
        block_label = str(node.get("block", ""))
        scope = node.get("scope", {}) if isinstance(node.get("scope"), dict) else {}

        block_rec = block_nodes.get(b_uid)
        if not block_rec:
            block_rec = {
                "block_id": b_uid,
                "file": file_name,
                "block": block_label,
                "first_line": line if line > 0 else 0,
                "last_line": line if line > 0 else 0,
                "scope": scope,
                "roles": set(),
                "side_effects": [],
                "_parents": set(),
            }
            block_nodes[b_uid] = block_rec
        else:
            if line > 0:
                first_line = int(block_rec.get("first_line", 0) or 0)
                last_line = int(block_rec.get("last_line", 0) or 0)
                if first_line <= 0 or line < first_line:
                    block_rec["first_line"] = line
                if line > last_line:
                    block_rec["last_line"] = line
            if not block_rec.get("scope") and scope:
                block_rec["scope"] = scope

        block_rec["roles"].add(role)
        if role in {"SETTER", "OVERWRITE", "SIDE_EFFECT_SETTER"}:
            block_rec["side_effects"].append(
                {
                    "line": line,
                    "inst": inst,
                    "detail": detail,
                    "target": node.get("overwrite_to") or node.get("side_effect_to"),
                    "new_value_expr": node.get("new_value_expr"),
                }
            )

        parent_chunk = str(node.get("parent_chunk_id", "")).strip()
        if not parent_chunk:
            continue
        parent = node_by_chunk.get(parent_chunk)
        if not parent:
            continue

        parent_uid = block_uid(parent)
        if parent_uid == b_uid:
            continue

        edge_meta = node.get("edge_to_parent", {}) if isinstance(node.get("edge_to_parent"), dict) else {}
        edge_type = str(edge_meta.get("type", "SEQUENTIAL"))
        edge_inst = str(edge_meta.get("inst", ""))
        edge_line = int(node.get("line", 0) or 0)
        edge_key = (parent_uid, b_uid, edge_type, edge_inst, edge_line)
        if edge_key in edge_seen:
            continue
        edge_seen.add(edge_key)
        block_rec["_parents"].add(parent_uid)
        edge_rows.append(
            {
                "from_block_id": parent_uid,
                "to_block_id": b_uid,
                "type": edge_type,
                "inst": edge_inst,
                "line": edge_line,
                "description": str(edge_meta.get("description", "")),
            }
        )

    output_nodes: List[Dict[str, Any]] = []
    for b_uid, block in sorted(block_nodes.items(), key=lambda kv: (str(kv[1].get("file", "")), int(kv[1].get("first_line", 0)))):
        out = {
            "block_id": b_uid,
            "file": block.get("file"),
            "block": block.get("block"),
            "first_line": int(block.get("first_line", 0) or 0),
            "last_line": int(block.get("last_line", 0) or 0),
            "parent_block_ids": sorted(block.get("_parents", set())),
            "scope": block.get("scope", {}),
            "roles": sorted([r for r in block.get("roles", set()) if r]),
            "side_effects": sorted(
                block.get("side_effects", []),
                key=lambda x: (int(x.get("line", 0) or 0), str(x.get("inst", ""))),
            ),
        }
        output_nodes.append(out)

    output_edges = sorted(
        edge_rows,
        key=lambda e: (
            str(e.get("from_block_id", "")),
            str(e.get("to_block_id", "")),
            int(e.get("line", 0) or 0),
            str(e.get("type", "")),
        ),
    )

    return {
        "variable": graph.get("variable"),
        "file": graph.get("file"),
        "graph_level": "block",
        "nodes": output_nodes,
        "edges": output_edges,
        "dependent_vars": graph.get("dependent_vars", []),
        "dependent_files": graph.get("dependent_files", []),
        "unresolved_files": graph.get("unresolved_files", []),
        "data_quality_warnings": graph.get("data_quality_warnings", []),
    }


def infer_blueprint_path(source_asm_file: Path, blueprint_dir: Optional[Path] = None) -> Path:
    if blueprint_dir:
        candidate = blueprint_dir / f"{source_asm_file.stem.lower()}.asm.json"
        if candidate.exists():
            return candidate
    return source_asm_file.with_name(f"{source_asm_file.stem.lower()}.asm.json")


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Forward trace lineage for an assembler variable using blueprint JSON.")
    p.add_argument("target_variable", help="Variable to trace forward (e.g., WK_RRC)")
    p.add_argument("source_asm_file", help="Path to source asm file (e.g., da76.asm)")
    p.add_argument("blueprint_file", nargs="?", help="Optional path to blueprint JSON")
    p.add_argument("--output-file", dest="output_file", help="Optional report output file path")
    p.add_argument(
        "--include-register-dependencies",
        action="store_true",
        help="Include register operands (e.g., R2) when parsing operand symbols",
    )
    p.add_argument(
        "--output-format",
        choices=["text", "json"],
        default="text",
        dest="output_format",
        help="Output format: text (default) or json graph",
    )
    p.add_argument(
        "--asm-dir",
        dest="asm_dir",
        default=None,
        metavar="DIR",
        help="Directory containing cross-file ASM sources (default: directory of source_asm_file)",
    )
    p.add_argument(
        "--blueprint-dir",
        dest="blueprint_dir",
        default=None,
        metavar="DIR",
        help="Directory containing cross-file blueprint JSON files named <stem>.asm.json "
             "(default: directory of primary blueprint file)",
    )
    return p


def main() -> int:
    args = build_arg_parser().parse_args()
    source_asm_file = Path(args.source_asm_file).resolve()
    if source_asm_file.suffix.lower() == ".json":
        raise SystemExit(
            f"ERROR: '{source_asm_file.name}' looks like a JSON blueprint, not an ASM file.\n"
            "Usage: forward_trace_lineage.py <variable> <source.asm> [blueprint.json]"
        )

    if not source_asm_file.exists():
        raise SystemExit(f"Source ASM file not found: {source_asm_file}")

    asm_dir = Path(args.asm_dir).resolve() if args.asm_dir else source_asm_file.parent

    if args.blueprint_file:
        blueprint_file = Path(args.blueprint_file).resolve()
    else:
        blueprint_file = infer_blueprint_path(
            source_asm_file,
            Path(args.blueprint_dir).resolve() if args.blueprint_dir else None,
        ).resolve()

    blueprint_dir = Path(args.blueprint_dir).resolve() if args.blueprint_dir else blueprint_file.parent

    tracer = ForwardLineageTracer(
        asm_dir=asm_dir,
        blueprint_dir=blueprint_dir,
        include_register_dependencies=args.include_register_dependencies,
    )

    results = tracer.trace_forward(args.target_variable, source_asm_file, blueprint_file)

    if args.output_format == "json":
        line_graph = build_shared_lineage_graph(
            args.target_variable,
            source_asm_file,
            results,
            dep_var_traces=None,
            blueprint_file=blueprint_file,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
        )
        line_graph = apply_forward_graph_wiring(line_graph)
        block_graph = build_block_graph_from_lineage_graph(line_graph)
        report = json.dumps(block_graph, indent=2)
        if args.output_file:
            out_file = Path(args.output_file).expanduser().resolve()
        else:
            output_dir = source_asm_file.parent / "output"
            file_name = f"{source_asm_file.stem.lower()}_{args.target_variable.upper()}_forward_lineage.json"
            out_file = (output_dir / file_name).resolve()
        out_file.parent.mkdir(parents=True, exist_ok=True)
        out_file.write_text(report + "\n", encoding="utf-8")
        print(f"Wrote forward lineage graph to: {out_file}")
        return 0

    report = format_results(args.target_variable, source_asm_file, results)
    if args.output_file:
        out_file = Path(args.output_file).expanduser().resolve()
    else:
        output_dir = source_asm_file.parent / "output"
        file_name = f"{source_asm_file.stem.lower()}_{args.target_variable.upper()}_forward_lineage.txt"
        out_file = (output_dir / file_name).resolve()

    out_file.parent.mkdir(parents=True, exist_ok=True)
    out_file.write_text(report + "\n", encoding="utf-8")
    print(f"Wrote forward lineage report to: {out_file}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
