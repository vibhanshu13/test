#!/usr/bin/env python3
"""
utility_detector.py — Detect utility vs critical files in CPP/ASM codebases.

Two-phase approach designed for 50K+ files and 10M+ LOC without RAM exhaustion:

  Phase 1 — BUILD INDEX (run once)
    Streams every source file, extracts call edges + content metrics,
    stores everything in a SQLite database (~50–300 MB for 50K files).
    No file is ever fully loaded into RAM twice.

  Phase 2 — QUERY (run many times, sub-second)
    All graph operations (BFS, degree computation, scoring) run as SQL
    queries on the on-disk index.  Peak RAM ≈ O(BFS_frontier) ≈ a few MB.

Utility Score (0 = purely critical, 1 = purely utility):
    Weighted combination of:
      • Extension type  (.mac=1.0, .hpp=0.85, .asm=varies, .cpp=0.05)
      • Content density (DSECT/DS/MACRO/EQU ratio vs business opcodes)
      • Fan-in rank     (files called by many others → infrastructure)
      • Entry points    (has BEGIN NAME= or pragma export → standalone program)
      • Name patterns   (GL-suffix, cc-prefix headers → data layout files)

Usage:
    # Step 1 — index codebase (streaming, memory-safe)
    python3 utility_detector.py build --src temp/asm --db utility_index.db

    # Step 2 — view utility scores for all files
    python3 utility_detector.py analyze --db utility_index.db

    # Step 3 — find critical files for a given functionality
    python3 utility_detector.py filter --entry da78 --db utility_index.db
    python3 utility_detector.py filter --entry dx710000 --db utility_index.db
    python3 utility_detector.py filter --entry "global limits" --db utility_index.db

    # Export results to JSON
    python3 utility_detector.py filter --entry da78 --db utility_index.db --output result.json
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sqlite3
import sys
import textwrap
from collections import deque
from pathlib import Path
from typing import Dict, Iterator, List, NamedTuple, Optional, Set, Tuple

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SUPPORTED_EXTENSIONS = {".asm", ".cpp", ".mac", ".hpp", ".h"}

# Utility score thresholds → human-readable role label
ROLE_THRESHOLDS = [
    (0.80, "PURE_UTILITY"),    # .mac / header-only / data DSECTs
    (0.60, "SHARED_INFRA"),    # heavily reused modules, many callers
    (0.40, "BRIDGE"),          # used both as shared glue and logic
    (0.20, "FUNCTIONAL"),      # business logic with some shared use
    (0.00, "CRITICAL"),        # unique business logic, few/no callers
]

# BFS batch size when querying DB neighbours
_BFS_BATCH = 500
# Maximum number of rows printed in console tables
_TABLE_MAX_ROWS = 60


# ---------------------------------------------------------------------------
# SQLite schema
# ---------------------------------------------------------------------------

_DDL = """
CREATE TABLE IF NOT EXISTS files (
    id                  INTEGER PRIMARY KEY,
    stem                TEXT    UNIQUE NOT NULL,
    path                TEXT    NOT NULL,
    ext                 TEXT    NOT NULL,
    loc                 INTEGER DEFAULT 0,
    non_blank_lines     INTEGER DEFAULT 0,
    has_begin_name      INTEGER DEFAULT 0,   -- 1 = standalone program
    entry_point_count   INTEGER DEFAULT 0,
    dsect_ratio         REAL    DEFAULT 0.0, -- (DSECT+DS+EQU) / non_blank
    macro_def_ratio     REAL    DEFAULT 0.0, -- (MACRO+MEND) / non_blank
    instruction_ratio   REAL    DEFAULT 0.0, -- business opcodes / non_blank
    utility_score       REAL    DEFAULT -1.0 -- -1 = not yet computed
);

CREATE TABLE IF NOT EXISTS edges (
    src_id    INTEGER NOT NULL,
    dst_id    INTEGER NOT NULL,
    call_type TEXT    NOT NULL,
    PRIMARY KEY (src_id, dst_id, call_type)
);
CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(src_id);
CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(dst_id);

CREATE TABLE IF NOT EXISTS metrics (
    file_id      INTEGER PRIMARY KEY REFERENCES files(id),
    in_degree    INTEGER DEFAULT 0,
    out_degree   INTEGER DEFAULT 0,
    fan_in_score REAL    DEFAULT 0.0
);
"""

# ---------------------------------------------------------------------------
# ASM / CPP / MAC / HPP content analysis
# ---------------------------------------------------------------------------

# Opcodes that signal actual business-logic instructions (not data definitions)
_BUSINESS_OPCODES = frozenset({
    "ENTRC", "ENTNC", "ENTDC", "CREEC", "CREMC", "SWISC",
    "MVC", "MVI", "MVN", "MVO", "MVZ", "MVCL",
    "AP", "SP", "MP", "DP", "ZAP", "CP", "CVB", "CVD",
    "L", "ST", "LA", "LR", "STM", "LM",
    "BCT", "BC", "BAS", "BASR", "BALR", "BAL",
    "CLC", "CLI", "CLR", "C", "CH",
    "TM", "OC", "XC", "NC", "OI", "XI", "NI",
    "CALL", "CALL_ALIAS", "FUNCTION",
    "PACK", "UNPK", "ED", "EDMK",
})

# ASM lines that count as "data definition" (utility signal)
_DATA_DEF_RE = re.compile(
    r"^\s*(?:[A-Z#@$][A-Z0-9#@$_]*\s+)?"
    r"(?:DSECT|DS\s|DC\s|EQU\s|ORG\s|DXD\s|EXTRN\s|ENTRY\s|PUBLIC\s)",
    re.IGNORECASE,
)
_MACRO_DEF_RE = re.compile(r"^\s*(?:MACRO|MEND|MEXIT|MNOTE|AIF|AGO|ANOP|LCLA|LCLB|LCLC|GBLA|GBLB|GBLC|SETA|SETB|SETC)\b", re.IGNORECASE)
_BEGIN_NAME_RE = re.compile(r"\bBEGIN\s+NAME\s*=", re.IGNORECASE)

# CPP patterns
_CPP_ENTRY_RE = re.compile(r"#\s*pragma\s+export\s*\(|#\s*pragma\s+map\s*\(|extern\s+\"C\"\s+void\s+\w+\s*\(", re.IGNORECASE)
_CPP_INCLUDE_RE = re.compile(r"^\s*#\s*include\b")
_CPP_FUNC_DEF_RE = re.compile(r"^\s*(?:void|int|bool|char|short|long|unsigned|static|inline)\s+\w+\s*\(")

# ASM call instructions for edge extraction
_ASM_CALL_OPCODES = frozenset({"ENTRC", "ENTNC", "ENTDC", "CREEC", "CREMC", "SWISC", "FUNCTION"})
# C++ header include – treated as a soft dependency edge
_CPP_LOCAL_INCLUDE_RE = re.compile(r'#\s*include\s*[<"]([^>"]+)[>"]')
# C++ CALL_ALIAS / extern function declarations pointing to ASM targets
_CPP_ALIAS_RE = re.compile(r'#\s*pragma\s+map\s*\(\s*\w+\s*,\s*"([A-Z][A-Z0-9]{3,7})"\s*\)', re.IGNORECASE)
_CPP_EXTERN_C_RE = re.compile(r'extern\s+"C"\s+\w[\w\s*]*\b(\w+)\s*\(\s*TPF_regs', re.IGNORECASE)
# Module name pattern used in ASM operands
_MODULE_RE = re.compile(r"^[A-Z][A-Z0-9]{3,7}$")


class FileMetrics(NamedTuple):
    loc: int
    non_blank_lines: int
    has_begin_name: bool
    entry_point_count: int
    dsect_ratio: float
    macro_def_ratio: float
    instruction_ratio: float
    outgoing_edges: List[Tuple[str, str]]  # [(target_stem, call_type), ...]


# ---------------------------------------------------------------------------
# Content analyser (reads one file at a time → O(file_size) RAM)
# ---------------------------------------------------------------------------

def _analyse_asm(lines: List[str]) -> FileMetrics:
    loc = len(lines)
    non_blank = 0
    data_lines = 0
    macro_lines = 0
    instr_lines = 0
    has_begin = False
    entry_count = 0
    edges: List[Tuple[str, str]] = []

    for raw in lines:
        stripped = raw.strip()
        if not stripped or stripped.startswith("*"):
            continue
        non_blank += 1

        if _BEGIN_NAME_RE.search(raw):
            has_begin = True
            entry_count += 1

        if _DATA_DEF_RE.match(raw):
            data_lines += 1
            continue
        if _MACRO_DEF_RE.match(raw):
            macro_lines += 1
            continue

        # Tokenise to extract opcode
        tokens = raw.split()
        if not tokens:
            continue

        opcode_idx = 0 if raw[0] == " " else 1
        if opcode_idx >= len(tokens):
            continue
        opcode = tokens[opcode_idx].upper().rstrip(",")

        if opcode in _BUSINESS_OPCODES:
            instr_lines += 1

        if opcode in _ASM_CALL_OPCODES:
            operand_idx = opcode_idx + 1
            if operand_idx < len(tokens):
                operand = tokens[operand_idx]
                if opcode == "FUNCTION":
                    parts = operand.split(",")
                    target = parts[1].split()[0] if len(parts) > 1 else ""
                    call_type = "no_return_call"
                else:
                    target = operand.split(",")[0].split()[0]
                    call_type = {
                        "ENTRC": "subroutine_call",
                        "ENTNC": "no_return_call",
                        "ENTDC": "no_return_call",
                        "CREEC": "async_spawn",
                        "CREMC": "async_spawn",
                        "SWISC": "isc_route",
                    }.get(opcode, "call")
                target = target.upper()
                if _MODULE_RE.match(target):
                    edges.append((target.lower(), call_type))

    nb = max(non_blank, 1)
    return FileMetrics(
        loc=loc,
        non_blank_lines=non_blank,
        has_begin_name=has_begin,
        entry_point_count=entry_count,
        dsect_ratio=data_lines / nb,
        macro_def_ratio=macro_lines / nb,
        instruction_ratio=instr_lines / nb,
        outgoing_edges=edges,
    )


def _analyse_mac(lines: List[str]) -> FileMetrics:
    # MAC files are MACRO definitions — nearly always utility.
    # Re-use ASM analyser; ext_score handles the rest.
    m = _analyse_asm(lines)
    return m


def _analyse_cpp(lines: List[str]) -> FileMetrics:
    loc = len(lines)
    non_blank = 0
    include_lines = 0
    entry_count = 0
    func_def_lines = 0
    edges: List[Tuple[str, str]] = []

    for raw in lines:
        stripped = raw.strip()
        if not stripped or stripped.startswith("//"):
            continue
        non_blank += 1

        if _CPP_INCLUDE_RE.match(raw):
            include_lines += 1
            m = _CPP_LOCAL_INCLUDE_RE.match(raw)
            if m:
                header = Path(m.group(1)).stem.lower()
                edges.append((header, "include"))
            continue

        if _CPP_ENTRY_RE.search(raw):
            entry_count += 1

        # #pragma map(funcName, "ASMMODULE") — bridge to ASM
        for m in _CPP_ALIAS_RE.finditer(raw):
            target = m.group(1).lower()
            edges.append((target, "call_alias"))

        # extern "C" void MODNAME(TPF_regs*) — declaration of ASM entry
        for m in _CPP_EXTERN_C_RE.finditer(raw):
            target = m.group(1).lower()
            if _MODULE_RE.match(target.upper()):
                edges.append((target, "call_alias"))

        if _CPP_FUNC_DEF_RE.match(raw):
            func_def_lines += 1

    nb = max(non_blank, 1)
    include_ratio = include_lines / nb
    func_ratio = func_def_lines / nb
    return FileMetrics(
        loc=loc,
        non_blank_lines=non_blank,
        has_begin_name=False,
        entry_point_count=entry_count,
        dsect_ratio=include_ratio,     # re-use field: high include ratio → utility header
        macro_def_ratio=0.0,
        instruction_ratio=func_ratio,  # re-use field: high function ratio → logic
        outgoing_edges=edges,
    )


def _analyse_hpp(lines: List[str]) -> FileMetrics:
    loc = len(lines)
    non_blank = 0
    struct_lines = 0
    field_lines = 0
    include_lines = 0
    edges: List[Tuple[str, str]] = []

    for raw in lines:
        stripped = raw.strip()
        if not stripped or stripped.startswith("//") or stripped.startswith("/*"):
            continue
        non_blank += 1

        if re.match(r"^\s*(?:struct|class|union|typedef|enum)\b", raw, re.IGNORECASE):
            struct_lines += 1
        if re.match(r"^\s+\w[\w\s<>:*,\[\]]+;", raw):
            field_lines += 1
        if _CPP_INCLUDE_RE.match(raw):
            include_lines += 1
            m = _CPP_LOCAL_INCLUDE_RE.match(raw)
            if m:
                header = Path(m.group(1)).stem.lower()
                edges.append((header, "include"))

    nb = max(non_blank, 1)
    return FileMetrics(
        loc=loc,
        non_blank_lines=non_blank,
        has_begin_name=False,
        entry_point_count=0,
        dsect_ratio=(struct_lines + field_lines) / nb,
        macro_def_ratio=include_lines / nb,
        instruction_ratio=0.0,
        outgoing_edges=edges,
    )


def analyse_file(path: Path) -> Optional[FileMetrics]:
    """Read + analyse one file. Returns None on error."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    lines = text.splitlines()
    ext = path.suffix.lower()
    if ext == ".asm":
        return _analyse_asm(lines)
    if ext == ".mac":
        return _analyse_mac(lines)
    if ext in (".hpp", ".h"):
        return _analyse_hpp(lines)
    if ext == ".cpp":
        return _analyse_cpp(lines)
    return None


# ---------------------------------------------------------------------------
# Name-pattern heuristics
# ---------------------------------------------------------------------------

_GL_SUFFIX_RE = re.compile(r"[a-z0-9]gl[a-z0-9]?$", re.IGNORECASE)       # da7gl, lm1gl
_DATA_RECORD_RE = re.compile(r"^cc[a-z0-9]", re.IGNORECASE)               # ccda7gl.hpp
_DB_RECORD_RE = re.compile(r"^[a-z]{2}\d{2}[a-z]{2}$", re.IGNORECASE)    # cr21ae


def _name_score(stem: str, ext: str) -> float:
    """Heuristic utility score based purely on name/extension patterns."""
    s = stem.lower()
    if ext in (".mac",):
        return 1.0
    if ext in (".hpp", ".h"):
        if _DATA_RECORD_RE.match(s) or _GL_SUFFIX_RE.search(s):
            return 0.95
        return 0.80
    if _GL_SUFFIX_RE.search(s):      # data layout macro files
        return 0.85
    if _DB_RECORD_RE.match(s):       # database record definitions (cr21ae, wb1wb…)
        return 0.70
    return 0.20


def _ext_score(ext: str) -> float:
    return {
        ".mac": 1.00,
        ".hpp": 0.85,
        ".h":   0.80,
        ".asm": 0.30,   # uncertain; content score will differentiate
        ".cpp": 0.05,
    }.get(ext, 0.20)


# ---------------------------------------------------------------------------
# Index builder — streams files, writes to SQLite
# ---------------------------------------------------------------------------

class IndexBuilder:
    """Scans source files and populates the SQLite index.

    Memory profile: O(1) — one file read at a time, batch-inserted into DB.
    """

    def __init__(self, db_path: str):
        self.db_path = db_path
        self.con = sqlite3.connect(db_path)
        self.con.executescript(_DDL)
        self.con.commit()

    def close(self):
        self.con.close()

    # ------------------------------------------------------------------
    # File discovery
    # ------------------------------------------------------------------

    def _iter_source_files(self, src_dir: Path) -> Iterator[Path]:
        for dirpath, _dirs, files in os.walk(src_dir):
            for fname in sorted(files):
                p = Path(dirpath) / fname
                if p.suffix.lower() in SUPPORTED_EXTENSIONS:
                    yield p

    # ------------------------------------------------------------------
    # Build
    # ------------------------------------------------------------------

    def build(self, src_dir: Path, verbose: bool = True) -> None:
        """Full index build.  Idempotent: re-running updates existing rows."""
        src_dir = src_dir.resolve()
        total = 0
        skipped = 0

        # Pass 1: insert/update file rows and collect raw edges
        pending_edges: List[Tuple[str, str, str]] = []  # (src_stem, dst_stem, call_type)

        for path in self._iter_source_files(src_dir):
            rel = str(path.relative_to(src_dir))
            stem = path.stem.lower()
            ext = path.suffix.lower()

            metrics = analyse_file(path)
            if metrics is None:
                skipped += 1
                continue

            self.con.execute("""
                INSERT INTO files (stem, path, ext, loc, non_blank_lines,
                    has_begin_name, entry_point_count,
                    dsect_ratio, macro_def_ratio, instruction_ratio)
                VALUES (?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(stem) DO UPDATE SET
                    path=excluded.path, ext=excluded.ext, loc=excluded.loc,
                    non_blank_lines=excluded.non_blank_lines,
                    has_begin_name=excluded.has_begin_name,
                    entry_point_count=excluded.entry_point_count,
                    dsect_ratio=excluded.dsect_ratio,
                    macro_def_ratio=excluded.macro_def_ratio,
                    instruction_ratio=excluded.instruction_ratio,
                    utility_score=-1.0
            """, (stem, rel, ext, metrics.loc, metrics.non_blank_lines,
                  int(metrics.has_begin_name), metrics.entry_point_count,
                  metrics.dsect_ratio, metrics.macro_def_ratio, metrics.instruction_ratio))

            for (target_stem, call_type) in metrics.outgoing_edges:
                pending_edges.append((stem, target_stem.lower(), call_type))

            total += 1
            if verbose and total % 500 == 0:
                print(f"  indexed {total} files …", flush=True)

        self.con.commit()

        if verbose:
            print(f"  indexed {total} files ({skipped} skipped)")
            print("  resolving edges …", flush=True)

        # Pass 2: resolve edges to file IDs
        id_map: Dict[str, int] = {
            row[0]: row[1]
            for row in self.con.execute("SELECT stem, id FROM files")
        }

        inserted_edges = 0
        batch: List[Tuple[int, int, str]] = []
        for (src_stem, dst_stem, call_type) in pending_edges:
            src_id = id_map.get(src_stem)
            dst_id = id_map.get(dst_stem)
            if src_id is None or dst_id is None:
                continue
            batch.append((src_id, dst_id, call_type))
            if len(batch) >= 5000:
                self.con.executemany(
                    "INSERT OR IGNORE INTO edges(src_id,dst_id,call_type) VALUES(?,?,?)",
                    batch
                )
                inserted_edges += len(batch)
                batch = []
        if batch:
            self.con.executemany(
                "INSERT OR IGNORE INTO edges(src_id,dst_id,call_type) VALUES(?,?,?)",
                batch
            )
            inserted_edges += len(batch)
        self.con.commit()

        if verbose:
            print(f"  inserted {inserted_edges} call edges")

        # Pass 3: compute degree metrics
        self._compute_degrees(verbose=verbose)
        # Pass 4: compute utility scores
        self._compute_utility_scores(verbose=verbose)

    # ------------------------------------------------------------------
    # Degree metrics
    # ------------------------------------------------------------------

    def _compute_degrees(self, verbose: bool = True) -> None:
        if verbose:
            print("  computing degree metrics …", flush=True)

        # Ensure metrics rows exist for all files
        self.con.execute("""
            INSERT OR IGNORE INTO metrics(file_id, in_degree, out_degree, fan_in_score)
            SELECT id, 0, 0, 0.0 FROM files
        """)

        self.con.execute("""
            UPDATE metrics SET in_degree = (
                SELECT COUNT(DISTINCT src_id) FROM edges WHERE dst_id = metrics.file_id
            )
        """)
        self.con.execute("""
            UPDATE metrics SET out_degree = (
                SELECT COUNT(DISTINCT dst_id) FROM edges WHERE src_id = metrics.file_id
            )
        """)
        self.con.commit()

        # Percentile-normalise fan_in_score:
        #   rank each file's in_degree in [0..1] range using NTILE
        rows = self.con.execute(
            "SELECT file_id, in_degree FROM metrics ORDER BY in_degree ASC"
        ).fetchall()
        if rows:
            max_deg = max(r[1] for r in rows)
            if max_deg > 0:
                self.con.executemany(
                    "UPDATE metrics SET fan_in_score=? WHERE file_id=?",
                    [(r[1] / max_deg, r[0]) for r in rows]
                )
        self.con.commit()

    # ------------------------------------------------------------------
    # Utility score computation
    # ------------------------------------------------------------------

    def _compute_utility_scores(self, verbose: bool = True) -> None:
        if verbose:
            print("  computing utility scores …", flush=True)

        rows = self.con.execute("""
            SELECT f.id, f.stem, f.ext, f.has_begin_name, f.entry_point_count,
                   f.dsect_ratio, f.macro_def_ratio, f.instruction_ratio,
                   m.fan_in_score
            FROM files f
            JOIN metrics m ON m.file_id = f.id
        """).fetchall()

        updates: List[Tuple[float, int]] = []
        for (fid, stem, ext, has_begin, ep_count,
             dsect_r, macro_r, instr_r, fan_in_s) in rows:

            # 1. Extension score
            es = _ext_score(ext)

            # 2. Content score: data-heavy lines / all non-blank lines
            if ext in (".asm", ".mac"):
                cs = min(1.0, dsect_r + macro_r * 0.5)
                # Penalise for high instruction ratio (real business logic)
                cs = max(0.0, cs - instr_r * 0.8)
            elif ext in (".hpp", ".h"):
                cs = min(1.0, dsect_r + macro_r)  # struct density + include density
            else:  # .cpp
                cs = max(0.0, dsect_r - instr_r * 2.0)  # high func ratio → critical

            # 3. Entry point score (inverted: no entry point → more utility)
            if has_begin:
                eps = 0.0       # standalone program: not utility
            elif ep_count == 0:
                eps = 0.75
            else:
                eps = max(0.0, 0.75 - ep_count * 0.15)

            # 4. Name pattern score
            ns = _name_score(stem, ext)

            # 5. Fan-in score (percentile-normalised)
            fis = fan_in_s  # 0..1

            # Weighted combination
            score = (
                es  * 0.30 +
                cs  * 0.25 +
                fis * 0.25 +
                eps * 0.10 +
                ns  * 0.10
            )
            updates.append((round(min(1.0, max(0.0, score)), 4), fid))

        self.con.executemany("UPDATE files SET utility_score=? WHERE id=?", updates)
        self.con.commit()
        if verbose:
            print(f"  scored {len(updates)} files")


# ---------------------------------------------------------------------------
# Utility role classification
# ---------------------------------------------------------------------------

def _role(score: float) -> str:
    for threshold, label in ROLE_THRESHOLDS:
        if score >= threshold:
            return label
    return "CRITICAL"


# ---------------------------------------------------------------------------
# Critical path analyser — BFS on SQLite adjacency list
# ---------------------------------------------------------------------------

class CriticalPathAnalyzer:
    """Streaming BFS over the SQLite call graph.

    Memory profile: O(frontier_size) ≈ a few MB for any size graph.
    """

    def __init__(self, db_path: str):
        self.db_path = db_path
        self.con = sqlite3.connect(db_path)
        self.con.row_factory = sqlite3.Row

    def close(self):
        self.con.close()

    # ------------------------------------------------------------------
    # Seed resolution
    # ------------------------------------------------------------------

    def find_seeds(self, entry: str) -> List[sqlite3.Row]:
        """Find file rows matching the entry specification.

        Accepts:
          • Exact stem match:        "da78"
          • Partial stem match:      "dx71"
          • Substring in path:       "temp/asm/da78.asm"
          • Keyword in stem:         "global limits" (space-separated tokens)
        """
        entry_l = entry.lower().strip()
        tokens = entry_l.split()

        # Try exact stem first
        row = self.con.execute(
            "SELECT * FROM files WHERE stem=?", (entry_l,)
        ).fetchone()
        if row:
            return [row]

        # Prefix match
        rows = self.con.execute(
            "SELECT * FROM files WHERE stem LIKE ?", (entry_l + "%",)
        ).fetchall()
        if rows:
            return rows

        # Keyword search in stem (AND semantics: all tokens must appear)
        like_clauses = " AND ".join(["stem LIKE ?" for _ in tokens])
        params = [f"%{t}%" for t in tokens]
        rows = self.con.execute(
            f"SELECT * FROM files WHERE {like_clauses}", params
        ).fetchall()
        if rows:
            return rows

        # Keyword search in path
        like_clauses = " AND ".join(["path LIKE ?" for _ in tokens])
        rows = self.con.execute(
            f"SELECT * FROM files WHERE {like_clauses}", params
        ).fetchall()
        return rows

    # ------------------------------------------------------------------
    # Streaming BFS
    # ------------------------------------------------------------------

    def _bfs(self, seed_ids: List[int], direction: str, max_depth: Optional[int] = None) -> Dict[int, int]:
        """Returns {file_id: depth} for all reachable files.

        direction: "forward"  → follow callee edges  (src → dst)
                   "backward" → follow caller edges   (dst → src)
        """
        col_src, col_dst = ("src_id", "dst_id") if direction == "forward" else ("dst_id", "src_id")
        visited: Dict[int, int] = {fid: 0 for fid in seed_ids}
        frontier: List[int] = list(seed_ids)
        depth = 0

        while frontier:
            if max_depth is not None and depth >= max_depth:
                break
            next_frontier: List[int] = []
            # Process in batches to keep query size manageable
            for i in range(0, len(frontier), _BFS_BATCH):
                batch = frontier[i : i + _BFS_BATCH]
                ph = ",".join("?" * len(batch))
                rows = self.con.execute(
                    f"SELECT DISTINCT {col_dst} FROM edges WHERE {col_src} IN ({ph})",
                    batch,
                ).fetchall()
                for (nid,) in rows:
                    if nid not in visited:
                        visited[nid] = depth + 1
                        next_frontier.append(nid)
            frontier = next_frontier
            depth += 1

        return visited

    # ------------------------------------------------------------------
    # Main analysis
    # ------------------------------------------------------------------

    def analyse(
        self,
        entry: str,
        include_callers: bool = False,
        max_depth: Optional[int] = None,
        use_fused: bool = False,
        llm_context: Optional[str] = None,
        src_dir: Optional[str] = None,
        llm_model: Optional[str] = None,
    ) -> Dict:
        """Return a structured analysis dict for the given entry point.

        use_fused    — use fused_score (det + LLM global) if available
        llm_context  — plain-English functionality description; triggers
                       context-aware LLM re-classification of BRIDGE files on path
        src_dir      — source directory (required when llm_context is set)
        llm_model    — LLM model name (default: claude-sonnet-4-5)
        """
        seeds = self.find_seeds(entry)
        if not seeds:
            return {"error": f"No files found matching '{entry}'"}

        seed_ids = [r["id"] for r in seeds]
        seed_stems = [r["stem"] for r in seeds]

        # Forward BFS: all files transitively called FROM the entry
        callee_depths = self._bfs(seed_ids, direction="forward", max_depth=max_depth)

        # Optional backward BFS: all callers of the entry
        caller_depths: Dict[int, int] = {}
        if include_callers:
            caller_depths = self._bfs(seed_ids, direction="backward", max_depth=max_depth)

        all_ids = set(callee_depths) | set(caller_depths)
        if not all_ids:
            return {"error": "No reachable files found"}

        # Fetch file + metrics data for all reachable files
        ph = ",".join("?" * len(all_ids))
        rows = self.con.execute(f"""
            SELECT f.id, f.stem, f.path, f.ext,
                   f.loc, f.has_begin_name, f.entry_point_count,
                   f.utility_score,
                   COALESCE(CASE WHEN f.fused_score >= 0 THEN f.fused_score END, f.utility_score) AS effective_score,
                   f.score_source,
                   m.in_degree, m.out_degree
            FROM files f
            JOIN metrics m ON m.file_id = f.id
            WHERE f.id IN ({ph})
        """, list(all_ids)).fetchall()

        # Optional: functionality-context LLM re-classification of BRIDGE files on path
        llm_context_overrides: Dict[str, dict] = {}
        if llm_context and src_dir:
            try:
                from utility_llm_classifier import LLMClassifier, migrate_db
                migrate_db(self.db_path)
                path_stems = [r["stem"] for r in rows]
                classifier = LLMClassifier(
                    db_path=self.db_path,
                    src_dir=Path(src_dir),
                    model=llm_model or "claude-sonnet-4-5",
                )
                try:
                    llm_context_overrides = classifier.classify_functionality(
                        path_stems=path_stems,
                        functionality=llm_context,
                        entry_stem=seed_stems[0] if seed_stems else "",
                    )
                finally:
                    classifier.close()
            except ImportError:
                pass  # utility_llm_classifier not available; skip

        results = []
        for r in rows:
            fid = r["id"]
            stem = r["stem"]

            # Score selection priority: LLM context override > fused > deterministic
            if stem in llm_context_overrides:
                util_score = 1.0 - llm_context_overrides[stem]["fused_score"]
                score_used = "llm_context"
            elif use_fused:
                util_score = r["effective_score"] if r["effective_score"] >= 0 else 0.5
                score_used = r["score_source"] or "deterministic"
            else:
                util_score = r["utility_score"] if r["utility_score"] >= 0 else 0.5
                score_used = "deterministic"

            crit_score = round(1.0 - util_score, 4)
            depth = callee_depths.get(fid, caller_depths.get(fid, -1))
            is_seed = fid in seed_ids
            direction = "seed" if is_seed else (
                "callee" if fid in callee_depths else "caller"
            )

            entry_dict = {
                "stem": stem,
                "path": r["path"],
                "ext": r["ext"],
                "loc": r["loc"],
                "utility_score": r["utility_score"],
                "criticality_score": crit_score,
                "role": _role(util_score),
                "depth": depth,
                "direction": direction,
                "in_degree": r["in_degree"],
                "out_degree": r["out_degree"],
                "has_entry_point": bool(r["has_begin_name"]),
                "score_source": score_used,
            }
            if stem in llm_context_overrides:
                entry_dict["llm_reason"] = llm_context_overrides[stem].get("reason", "")
            results.append(entry_dict)

        # Sort: seeds first, then by criticality descending, then by depth
        results.sort(key=lambda x: (
            0 if x["direction"] == "seed" else 1,
            -x["criticality_score"],
            x["depth"],
        ))

        # Cluster summary
        role_summary: Dict[str, int] = {}
        for r in results:
            role_summary[r["role"]] = role_summary.get(r["role"], 0) + 1

        return {
            "entry": entry,
            "seeds": seed_stems,
            "total_reachable": len(results),
            "role_summary": role_summary,
            "files": results,
        }


# ---------------------------------------------------------------------------
# Global codebase analysis (utility ranking)
# ---------------------------------------------------------------------------

def analyze_all(db_path: str, top_n: Optional[int] = None, role_filter: Optional[str] = None) -> Dict:
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row

    where = ""
    params: List = []
    if role_filter:
        # Map role name to score range
        thresholds = dict(ROLE_THRESHOLDS)
        role_upper = role_filter.upper()
        labels = [label for _, label in ROLE_THRESHOLDS]
        if role_upper not in labels:
            con.close()
            return {"error": f"Unknown role '{role_filter}'. Choices: {labels}"}
        idx = labels.index(role_upper)
        low = ROLE_THRESHOLDS[idx][0]
        high = ROLE_THRESHOLDS[idx - 1][0] if idx > 0 else 1.01
        where = "WHERE f.utility_score >= ? AND f.utility_score < ?"
        params = [low, high]

    limit = f"LIMIT {top_n}" if top_n else ""
    rows = con.execute(f"""
        SELECT f.stem, f.path, f.ext, f.loc,
               f.utility_score, m.in_degree, m.out_degree,
               f.has_begin_name, f.entry_point_count
        FROM files f
        JOIN metrics m ON m.file_id = f.id
        {where}
        ORDER BY f.utility_score DESC
        {limit}
    """, params).fetchall()

    total = con.execute("SELECT COUNT(*) FROM files").fetchone()[0]
    summary = con.execute("""
        SELECT
            SUM(CASE WHEN utility_score >= 0.80 THEN 1 ELSE 0 END) AS pure_utility,
            SUM(CASE WHEN utility_score >= 0.60 AND utility_score < 0.80 THEN 1 ELSE 0 END) AS shared_infra,
            SUM(CASE WHEN utility_score >= 0.40 AND utility_score < 0.60 THEN 1 ELSE 0 END) AS bridge,
            SUM(CASE WHEN utility_score >= 0.20 AND utility_score < 0.40 THEN 1 ELSE 0 END) AS functional,
            SUM(CASE WHEN utility_score < 0.20 THEN 1 ELSE 0 END) AS critical
        FROM files WHERE utility_score >= 0
    """).fetchone()
    con.close()

    return {
        "total_files": total,
        "summary": {
            "PURE_UTILITY":  summary[0] or 0,
            "SHARED_INFRA":  summary[1] or 0,
            "BRIDGE":        summary[2] or 0,
            "FUNCTIONAL":    summary[3] or 0,
            "CRITICAL":      summary[4] or 0,
        },
        "files": [
            {
                "stem": r["stem"],
                "path": r["path"],
                "ext": r["ext"],
                "loc": r["loc"],
                "utility_score": r["utility_score"],
                "role": _role(r["utility_score"]),
                "in_degree": r["in_degree"],
                "out_degree": r["out_degree"],
            }
            for r in rows
        ],
    }


# ---------------------------------------------------------------------------
# Console output helpers
# ---------------------------------------------------------------------------

def _bar(score: float, width: int = 12) -> str:
    filled = round(score * width)
    return "█" * filled + "░" * (width - filled)


def _print_analysis_table(data: Dict, max_rows: int = _TABLE_MAX_ROWS) -> None:
    s = data.get("summary", {})
    print(f"\nTotal files indexed: {data['total_files']}")
    print("\nRole distribution:")
    for role, count in s.items():
        pct = count / max(data["total_files"], 1) * 100
        print(f"  {role:<15} {count:>6}  ({pct:5.1f}%)")

    files = data.get("files", [])
    print(f"\nTop {min(max_rows, len(files))} files by utility score:\n")
    print(f"  {'STEM':<22} {'EXT':<6} {'ROLE':<15} {'SCORE':>6}  {'BAR':<14} {'IN':>4} {'OUT':>4}  LOC")
    print("  " + "-" * 82)
    for r in files[:max_rows]:
        print(
            f"  {r['stem']:<22} {r['ext']:<6} {r['role']:<15} "
            f"{r['utility_score']:>6.3f}  {_bar(r['utility_score']):<14} "
            f"{r['in_degree']:>4} {r['out_degree']:>4}  {r['loc']:>6}"
        )


def _print_filter_table(data: Dict, max_rows: int = _TABLE_MAX_ROWS) -> None:
    if "error" in data:
        print(f"ERROR: {data['error']}")
        return

    print(f"\nEntry point : {data['entry']}")
    print(f"Matched seed: {', '.join(data['seeds'])}")
    print(f"Total reachable files: {data['total_reachable']}")
    print("\nRole distribution on path:")
    for role, count in data["role_summary"].items():
        print(f"  {role:<15} {count:>4}")

    files = data.get("files", [])
    has_source = any(r.get("score_source") not in (None, "deterministic") for r in files)
    print(f"\n{'STEM':<22} {'EXT':<6} {'ROLE':<15} {'CRIT':>6} {'UTIL':>6}  {'DIR':<8} {'DEPTH':>5}  {'IN':>4} {'OUT':>4}" +
          ("  SOURCE" if has_source else ""))
    print("-" * (86 + (8 if has_source else 0)))
    for r in files[:max_rows]:
        marker = "★ " if r["direction"] == "seed" else "  "
        src_col = f"  {r.get('score_source','det')[:10]}" if has_source else ""
        reason = f"\n    ↳ {r['llm_reason']}" if r.get("llm_reason") else ""
        print(
            f"{marker}{r['stem']:<20} {r['ext']:<6} {r['role']:<15} "
            f"{r['criticality_score']:>6.3f} {r['utility_score']:>6.3f}  "
            f"{r['direction']:<8} {r['depth']:>5}  "
            f"{r['in_degree']:>4} {r['out_degree']:>4}{src_col}{reason}"
        )
    if len(files) > max_rows:
        print(f"  … {len(files) - max_rows} more rows (use --output to export all)")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _build_cmd(args: argparse.Namespace) -> None:
    src = Path(args.src)
    if not src.exists():
        print(f"ERROR: source directory not found: {src}", file=sys.stderr)
        sys.exit(1)

    print(f"Building index from {src} → {args.db}")
    builder = IndexBuilder(args.db)
    try:
        builder.build(src, verbose=not args.quiet)
    finally:
        builder.close()
    print("Done.")


def _analyze_cmd(args: argparse.Namespace) -> None:
    if not Path(args.db).exists():
        print(f"ERROR: index not found: {args.db}. Run 'build' first.", file=sys.stderr)
        sys.exit(1)

    data = analyze_all(
        args.db,
        top_n=args.top,
        role_filter=args.role,
    )

    if args.output:
        Path(args.output).write_text(json.dumps(data, indent=2))
        print(f"Wrote {len(data['files'])} entries to {args.output}")
    else:
        _print_analysis_table(data, max_rows=args.top or _TABLE_MAX_ROWS)


def _filter_cmd(args: argparse.Namespace) -> None:
    if not Path(args.db).exists():
        print(f"ERROR: index not found: {args.db}. Run 'build' first.", file=sys.stderr)
        sys.exit(1)

    analyzer = CriticalPathAnalyzer(args.db)
    try:
        data = analyzer.analyse(
            entry=args.entry,
            include_callers=args.include_callers,
            max_depth=args.max_depth,
            use_fused=getattr(args, "use_fused", False),
            llm_context=getattr(args, "llm_context", None),
            src_dir=getattr(args, "src", None),
            llm_model=getattr(args, "llm_model", None),
        )
    finally:
        analyzer.close()

    if args.output:
        Path(args.output).write_text(json.dumps(data, indent=2))
        print(f"Wrote analysis for '{args.entry}' ({data.get('total_reachable', 0)} files) to {args.output}")
    else:
        _print_filter_table(data, max_rows=args.top or _TABLE_MAX_ROWS)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="utility_detector.py",
        description=textwrap.dedent(__doc__).split("Usage:")[0].strip(),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # ---- build ----
    p_build = sub.add_parser("build", help="Build SQLite index from source directory")
    p_build.add_argument("--src",  required=True, help="Source directory to scan")
    p_build.add_argument("--db",   default="utility_index.db", help="Output SQLite DB path")
    p_build.add_argument("--quiet", action="store_true")

    # ---- analyze ----
    p_analyze = sub.add_parser("analyze", help="Show utility scores for all files")
    p_analyze.add_argument("--db",     default="utility_index.db")
    p_analyze.add_argument("--top",    type=int, default=None, help="Show top N files")
    p_analyze.add_argument("--role",   help="Filter by role: PURE_UTILITY/SHARED_INFRA/BRIDGE/FUNCTIONAL/CRITICAL")
    p_analyze.add_argument("--output", help="Write full JSON to this file")

    # ---- filter ----
    p_filter = sub.add_parser("filter", help="Find critical files for a functionality")
    p_filter.add_argument("--entry",           required=True, help="Entry point: stem, partial name, or keyword")
    p_filter.add_argument("--db",              default="utility_index.db")
    p_filter.add_argument("--include-callers", action="store_true", help="Also include upstream callers")
    p_filter.add_argument("--max-depth",       type=int, default=None, help="BFS depth limit")
    p_filter.add_argument("--top",             type=int, default=None, help="Show top N in console table")
    p_filter.add_argument("--output",          help="Write full JSON to this file")
    # Hybrid (deterministic + LLM) flags
    p_filter.add_argument("--use-fused",       action="store_true",
                          help="Use fused scores (det+LLM) if llm-classify has been run")
    p_filter.add_argument("--llm-context",     help="Functionality description for context-aware LLM re-classification of BRIDGE files")
    p_filter.add_argument("--src",             help="Source directory (required with --llm-context)")
    p_filter.add_argument("--llm-model",       default="claude-sonnet-4-5",
                          help="LLM model for --llm-context (default: claude-sonnet-4-5)")

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "build":
        _build_cmd(args)
    elif args.command == "analyze":
        _analyze_cmd(args)
    elif args.command == "filter":
        _filter_cmd(args)


if __name__ == "__main__":
    main()
