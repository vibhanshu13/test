#!/usr/bin/env python3
"""
cross_file_bridge.py

Given a caller file and a callee file, find the exact call sites.

Supports four modes (auto-detected):
  - C++ → C++: finds which C++ function(s) in the caller call function(s) in the callee
  - C++ → ASM: finds which C++ function(s) call the ASM module
  - ASM → ASM: finds which routine(s) in the calling ASM file dispatch to the callee
  - ASM → C++: finds which routine(s) in the calling ASM file dispatch to a C++ entry point

Usage:
  python cross_file_bridge.py <caller_stem> <callee_stem> [options]

Options:
  --blueprint-dir DIR   Directory containing .cpp.json / .asm.json blueprint files
  --asm-dir DIR         Directory containing .asm source files (for raw line text)
  --output FILE         Output JSON path (default: <caller>_calls_<callee>.json)

Examples:
  python cross_file_bridge.py dx740200 da78    # C++ → ASM
  python cross_file_bridge.py lu82 da76        # ASM → ASM
  python cross_file_bridge.py xh88 xh890000   # ASM → C++
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from blueprint_io import load_blueprint


# ---------------------------------------------------------------------------
# Auto-discovery helpers
# ---------------------------------------------------------------------------

def _discover_blueprint_dir() -> Optional[Path]:
    cwd = Path.cwd()
    for candidate in [
        cwd / "temp" / "output_latest" / "asm",
        cwd / "output" / "asm",
        cwd / "temp" / "parser_run",
    ]:
        if candidate.exists() and (
            list(candidate.glob("*.cpp.json")) or list(candidate.glob("*.asm.json"))
        ):
            return candidate
    return None


def _discover_asm_dir(blueprint_dir: Path) -> Optional[Path]:
    """Try to find the directory containing raw .asm source files."""
    candidates = [
        blueprint_dir.parent.parent / "asm",  # e.g. temp/output_latest/asm → temp/asm
        blueprint_dir.parent / "asm",
        blueprint_dir,
    ]
    for candidate in candidates:
        if candidate.exists() and list(candidate.glob("*.asm")):
            return candidate
    return None


# ---------------------------------------------------------------------------
# Raw line fetching
# ---------------------------------------------------------------------------

def _fetch_raw_line(
    file_field: str,
    line_no: int,
    asm_dir: Optional[Path],
) -> Optional[str]:
    """Return the stripped source line at line_no (1-based) from file_field.

    Falls back to asm_dir/<filename> if the stored absolute path doesn't exist.
    Returns None on any failure.
    """
    candidates: List[Path] = [Path(file_field)]
    if asm_dir:
        candidates.append(asm_dir / Path(file_field).name)

    for path in candidates:
        if not path.exists():
            continue
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            if 1 <= line_no <= len(lines):
                return lines[line_no - 1].rstrip()
        except Exception:
            pass

    return None


# ---------------------------------------------------------------------------
# C++ → C++ bridge
# ---------------------------------------------------------------------------

def find_cpp_to_cpp_callers(
    caller_stem: str,
    callee_stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path] = None,
) -> List[Dict[str, Any]]:
    """Return all (caller_function, callee_function) pairs where a function
    in caller_stem.cpp calls a function defined in callee_stem.cpp.

    Each returned dict has:
      caller_function — C++ function name in the caller file
      callee_function — C++ function name in the callee file
      line            — source line number in the caller file (1-based)
      file            — absolute path to the caller source file
      instruction     — e.g. "CALL"
      call_type       — e.g. "call"
      raw_line        — stripped source text at that line (or None)
    """
    # ── Load callee blueprint to get the set of functions defined there ──────
    callee_bp_path = blueprint_dir / f"{callee_stem}.cpp.json"
    if not callee_bp_path.exists():
        print(f"ERROR: Blueprint not found: {callee_bp_path}", file=sys.stderr)
        sys.exit(1)

    try:
        callee_bp = load_blueprint(callee_bp_path)
    except Exception as exc:
        print(f"ERROR: Could not read {callee_bp_path.name}: {exc}", file=sys.stderr)
        sys.exit(1)

    # Primary: asm_entry_point_map values are the C++ function names defined here.
    callee_functions: set = set(
        (callee_bp.get("asm_entry_point_map") or {}).values()
    )

    # Fallback: entry-type global symbols (for older blueprints without the map).
    if not callee_functions:
        for name, sym in callee_bp.get("symbols", {}).get("global_symbols", {}).items():
            if (sym.get("type") or "") == "entry":
                callee_functions.add(name)

    if not callee_functions:
        print(
            f"WARNING: No entry functions found in '{callee_stem}.cpp.json'.",
            file=sys.stderr,
        )
        return []

    # ── Load caller blueprint and filter edges ───────────────────────────────
    caller_bp_path = blueprint_dir / f"{caller_stem}.cpp.json"
    if not caller_bp_path.exists():
        print(f"ERROR: Blueprint not found: {caller_bp_path}", file=sys.stderr)
        sys.exit(1)

    try:
        caller_bp = load_blueprint(caller_bp_path)
    except Exception as exc:
        print(f"ERROR: Could not read {caller_bp_path.name}: {exc}", file=sys.stderr)
        sys.exit(1)

    call_pairs: List[Dict[str, Any]] = []

    for edge in caller_bp.get("call_graph", {}).get("edges", []):
        target = edge.get("target") or ""
        if target not in callee_functions:
            continue

        line_no: Optional[int] = edge.get("line")
        file_field: str = edge.get("file", "")

        raw_line: Optional[str] = None
        if line_no is not None and file_field:
            # C++ source path is absolute in the blueprint; asm_dir not needed.
            raw_line = _fetch_raw_line(file_field, line_no, None)

        call_pairs.append({
            "caller_function": edge.get("source"),
            "callee_function": target,
            "line": line_no,
            "file": file_field,
            "instruction": edge.get("instruction"),
            "call_type": edge.get("call_type"),
            "raw_line": raw_line,
        })

    # Deduplicate: the C++ parser sometimes emits two edges for one multi-line
    # call (e.g. line N = "returnCode =" and line N+1 = "callee(args,").
    # Group by (caller_function, callee_function, file); within each group merge
    # entries whose line numbers are within 3 lines of each other, keeping the
    # entry whose raw_line actually contains the callee name (best signal of the
    # real call site), or the highest-numbered line as a tie-break.
    from itertools import groupby as _groupby

    def _dedup_key(p):
        return (p.get("caller_function"), p.get("callee_function"), p.get("file"))

    deduped: List[Dict[str, Any]] = []
    for _, group in _groupby(sorted(call_pairs, key=_dedup_key), key=_dedup_key):
        cluster: List[Dict[str, Any]] = []
        for site in sorted(group, key=lambda p: (p.get("line") or 0)):
            if not cluster:
                cluster.append(site)
                continue
            last_line = cluster[-1].get("line") or 0
            this_line = site.get("line") or 0
            if abs(this_line - last_line) <= 3:
                # Same multi-line call — keep the one whose raw_line names callee.
                callee_name = site.get("callee_function") or ""
                existing_raw = (cluster[-1].get("raw_line") or "")
                candidate_raw = (site.get("raw_line") or "")
                if callee_name and callee_name in candidate_raw and callee_name not in existing_raw:
                    cluster[-1] = site   # replace with better entry
                # else keep existing (already has callee name, or tie — keep first)
            else:
                cluster.append(site)
        deduped.extend(cluster)

    return deduped


# ---------------------------------------------------------------------------
# C++ → ASM bridge
# ---------------------------------------------------------------------------

def find_cpp_callers(
    caller_stem: str,
    callee_stem: str,
    blueprint_dir: Path,
) -> List[Dict[str, Any]]:
    """Return all C++ functions in caller_stem that call callee_stem."""
    bp_path = blueprint_dir / f"{caller_stem}.cpp.json"
    if not bp_path.exists():
        print(f"ERROR: Blueprint not found: {bp_path}", file=sys.stderr)
        sys.exit(1)

    try:
        bp = load_blueprint(bp_path)
    except Exception as exc:
        print(f"ERROR: Could not read {bp_path.name}: {exc}", file=sys.stderr)
        sys.exit(1)

    callee_upper = callee_stem.upper()
    callers: List[Dict[str, Any]] = []

    for edge in bp.get("call_graph", {}).get("edges", []):
        if edge.get("target", "").upper() == callee_upper:
            callers.append({
                "function": edge.get("source"),
                "line": edge.get("line"),
                "instruction": edge.get("instruction"),
            })

    return callers


# ---------------------------------------------------------------------------
# ASM → ASM bridge
# ---------------------------------------------------------------------------

def find_asm_callers(
    caller_stem: str,
    callee_stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path] = None,
) -> List[Dict[str, Any]]:
    """Return all call sites in caller_stem.asm that dispatch to callee_stem."""
    bp_path = blueprint_dir / f"{caller_stem}.asm.json"
    if not bp_path.exists():
        print(f"ERROR: Blueprint not found: {bp_path}", file=sys.stderr)
        sys.exit(1)

    try:
        bp = load_blueprint(bp_path)
    except Exception as exc:
        print(f"ERROR: Could not read {bp_path.name}: {exc}", file=sys.stderr)
        sys.exit(1)

    callee_upper = callee_stem.upper()
    call_sites: List[Dict[str, Any]] = []

    # All cross-file ASM call instructions store the callee file stem in edge.target,
    # so a single name comparison covers: ENTRC, ENTNC, FUNCTION (dispatch table macro),
    # CREEC, CREMC, SWISC. BAS edges are always intra-file (local labels) and will
    # never match a file stem. Indirect/register calls (BR Rn, BCR) are not captured
    # by the parser and will be absent from call_graph.edges entirely.
    for edge in bp.get("call_graph", {}).get("edges", []):
        if (edge.get("target") or "").upper() != callee_upper:
            continue

        line_no: Optional[int] = edge.get("line")
        file_field: str = edge.get("file", "")

        raw_line: Optional[str] = None
        if line_no is not None and file_field:
            raw_line = _fetch_raw_line(file_field, line_no, asm_dir)

        call_sites.append({
            "routine": edge.get("source"),
            "line": line_no,
            "instruction": edge.get("instruction"),
            "call_type": edge.get("call_type"),
            "raw_line": raw_line,
        })

    return call_sites


# ---------------------------------------------------------------------------
# ASM → C++ bridge
# ---------------------------------------------------------------------------

def find_asm_to_cpp_callers(
    caller_stem: str,
    callee_stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path] = None,
) -> List[Dict[str, Any]]:
    """Return all call sites in caller_stem.asm that dispatch to any entry
    point defined in callee_stem.cpp.

    Uses the asm_entry_point_map field baked into the C++ blueprint by the
    parser, so no source-file parsing is needed at query time.

    Each returned dict has:
      routine           — block/routine name in the caller ASM
      line              — source line number (1-based)
      instruction       — e.g. "ENTRC"
      call_type         — e.g. "subroutine_call"
      raw_line          — stripped source text at that line (or None)
      target_entry_point — the assembly-level name used in the ENTRC instruction
      cpp_function      — the C++ function name (may equal target_entry_point for
                          direct extern "C" functions with no asm alias)
    """
    cpp_bp_path = blueprint_dir / f"{callee_stem}.cpp.json"
    if not cpp_bp_path.exists():
        print(f"ERROR: Blueprint not found: {cpp_bp_path}", file=sys.stderr)
        sys.exit(1)

    try:
        cpp_bp = load_blueprint(cpp_bp_path)
    except Exception as exc:
        print(f"ERROR: Could not read {cpp_bp_path.name}: {exc}", file=sys.stderr)
        sys.exit(1)

    # asm_entry_point_map: {asm_name -> cpp_function_name}
    # Covers asm("NAME"), #pragma map (via symbol_aliases reverse), and direct
    # extern "C" entry points with no alias (identity). Populated by the parser.
    asm_map: Dict[str, str] = cpp_bp.get("asm_entry_point_map") or {}
    asm_names_upper: Dict[str, str] = {k.upper(): v for k, v in asm_map.items()}

    # Fallback for blueprints generated before asm_entry_point_map was added:
    # use only "entry" type symbols (defined in this file) as identity candidates.
    # Deliberately excludes "extrn" symbols (external calls) to avoid false positives.
    if not asm_names_upper:
        gs = cpp_bp.get("symbols", {}).get("global_symbols", {})
        for name, sym in gs.items():
            if (sym.get("type") or "") == "entry":
                asm_names_upper.setdefault(name.upper(), name)

    if not asm_names_upper:
        print(
            f"WARNING: No callable entry points found in '{callee_stem}.cpp.json'.",
            file=sys.stderr,
        )
        return []

    # Now scan caller ASM blueprint for edges targeting any of those names.
    asm_bp_path = blueprint_dir / f"{caller_stem}.asm.json"
    if not asm_bp_path.exists():
        print(f"ERROR: Blueprint not found: {asm_bp_path}", file=sys.stderr)
        sys.exit(1)

    try:
        asm_bp = load_blueprint(asm_bp_path)
    except Exception as exc:
        print(f"ERROR: Could not read {asm_bp_path.name}: {exc}", file=sys.stderr)
        sys.exit(1)

    call_sites: List[Dict[str, Any]] = []

    for edge in asm_bp.get("call_graph", {}).get("edges", []):
        target_raw = edge.get("target") or ""
        target_upper = target_raw.upper()
        if target_upper not in asm_names_upper:
            continue

        line_no: Optional[int] = edge.get("line")
        file_field: str = edge.get("file", "")

        raw_line: Optional[str] = None
        if line_no is not None and file_field:
            raw_line = _fetch_raw_line(file_field, line_no, asm_dir)

        cpp_function = asm_names_upper[target_upper]

        call_sites.append({
            "routine": edge.get("source"),
            "line": line_no,
            "instruction": edge.get("instruction"),
            "call_type": edge.get("call_type"),
            "raw_line": raw_line,
            "target_entry_point": target_raw,
            "cpp_function": cpp_function,
        })

    return call_sites


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Find call sites from a caller file to a callee file.\n"
            "Auto-detects mode (C++→C++, C++→ASM, ASM→C++, ASM→ASM) from available blueprints."
        )
    )
    parser.add_argument("caller_stem", help="Caller file stem (e.g. dx740200 or lu82)")
    parser.add_argument("callee_stem", help="Callee file stem (e.g. da78 or da76)")
    parser.add_argument("--blueprint-dir", metavar="DIR",
                        help="Directory containing blueprint (.cpp.json / .asm.json) files")
    parser.add_argument("--asm-dir", metavar="DIR",
                        help="Directory containing .asm source files (for raw line text)")
    parser.add_argument("--output", metavar="FILE",
                        help="Output JSON path (default: <caller>_calls_<callee>.json)")
    args = parser.parse_args()

    output_path = (
        Path(args.output)
        if args.output
        else Path(f"{args.caller_stem}_calls_{args.callee_stem}.json")
    )

    # ── Resolve blueprint directory ──────────────────────────────────────────
    if args.blueprint_dir:
        blueprint_dir = Path(args.blueprint_dir)
        if not blueprint_dir.exists():
            print(f"ERROR: Blueprint dir not found: {blueprint_dir}", file=sys.stderr)
            return 1
    else:
        blueprint_dir = _discover_blueprint_dir()
        if blueprint_dir is None:
            print(
                "ERROR: Could not discover blueprint directory. "
                "Pass --blueprint-dir explicitly.",
                file=sys.stderr,
            )
            return 1

    print(f"[blueprints] {blueprint_dir}", file=sys.stderr)

    # ── Resolve ASM source directory (for raw line fetching) ─────────────────
    if args.asm_dir:
        asm_dir: Optional[Path] = Path(args.asm_dir)
    else:
        asm_dir = _discover_asm_dir(blueprint_dir)
        if asm_dir:
            print(f"[asm-source] {asm_dir}", file=sys.stderr)

    # ── Auto-detect caller/callee types and route ────────────────────────────
    caller_cpp_bp = blueprint_dir / f"{args.caller_stem}.cpp.json"
    caller_asm_bp = blueprint_dir / f"{args.caller_stem}.asm.json"
    callee_cpp_bp = blueprint_dir / f"{args.callee_stem}.cpp.json"

    if caller_cpp_bp.exists() and callee_cpp_bp.exists():
        # C++ → C++ mode
        call_pairs = find_cpp_to_cpp_callers(
            args.caller_stem, args.callee_stem, blueprint_dir, asm_dir
        )

        if not call_pairs:
            print(
                f"No calls from '{args.caller_stem}' to '{args.callee_stem}' found.",
                file=sys.stderr,
            )
        else:
            fns = ", ".join(
                f"{p['caller_function']} → {p['callee_function']}"
                for p in call_pairs
            )
            print(f"Found {len(call_pairs)} call pair(s): {fns}", file=sys.stderr)

        result: Dict[str, Any] = {
            "cpp_caller": args.caller_stem,
            "cpp_callee": args.callee_stem,
            "call_pairs": call_pairs,
        }

    elif caller_cpp_bp.exists():
        # C++ → ASM mode
        callers = find_cpp_callers(args.caller_stem, args.callee_stem, blueprint_dir)

        if not callers:
            print(
                f"No calls from '{args.caller_stem}' to '{args.callee_stem}' found.",
                file=sys.stderr,
            )
        else:
            fns = ", ".join(c["function"] for c in callers)
            print(f"Found {len(callers)} caller(s): {fns}", file=sys.stderr)

        result = {
            "cpp_file": args.caller_stem,
            "asm_file": args.callee_stem,
            "callers": callers,
        }

    elif caller_asm_bp.exists() and callee_cpp_bp.exists():
        # ASM → C++ mode
        call_sites = find_asm_to_cpp_callers(
            args.caller_stem, args.callee_stem, blueprint_dir, asm_dir
        )

        if not call_sites:
            print(
                f"No calls from '{args.caller_stem}' to '{args.callee_stem}' found.",
                file=sys.stderr,
            )
        else:
            routines = ", ".join(
                cs["routine"] for cs in call_sites if cs.get("routine")
            )
            print(
                f"Found {len(call_sites)} call site(s) in routine(s): {routines}",
                file=sys.stderr,
            )

        result = {
            "asm_caller": args.caller_stem,
            "cpp_callee": args.callee_stem,
            "call_sites": call_sites,
        }

    elif caller_asm_bp.exists():
        # ASM → ASM mode
        call_sites = find_asm_callers(
            args.caller_stem, args.callee_stem, blueprint_dir, asm_dir
        )

        if not call_sites:
            print(
                f"No calls from '{args.caller_stem}' to '{args.callee_stem}' found.",
                file=sys.stderr,
            )
        else:
            routines = ", ".join(
                cs["routine"] for cs in call_sites if cs.get("routine")
            )
            print(
                f"Found {len(call_sites)} call site(s) in routine(s): {routines}",
                file=sys.stderr,
            )

        result = {
            "asm_caller": args.caller_stem,
            "asm_callee": args.callee_stem,
            "call_sites": call_sites,
        }

    else:
        print(
            f"ERROR: No blueprint found for '{args.caller_stem}' "
            f"(tried {caller_cpp_bp.name} and {caller_asm_bp.name} in {blueprint_dir})",
            file=sys.stderr,
        )
        return 1

    output_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"Wrote results to: {output_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
