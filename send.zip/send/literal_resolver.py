"""Resolve literal references in assembly code."""

import re
from typing import Optional, Dict


class LiteralResolver:
    """Resolve assembly literals like =V(symbol), =A(address), =F'100'.

    Literals in assembly:
    - =V(symbol): Address of external symbol (V-type address constant)
    - =A(symbol): Address of local symbol (A-type address constant)
    - =F'100': Fullword constant
    - =H'50': Halfword constant
    - =C'TEXT': Character constant
    """

    def __init__(self):
        # Pattern for =V(symbol) or =A(symbol)
        self.address_literal_pattern = re.compile(r"^=([VA])\(([^)]+)\)$")

        # Pattern for numeric literals like =F'100', =H'50'
        self.numeric_literal_pattern = re.compile(r"^=([FHDC])('([^']+)'|\(([^)]+)\))$")

    def is_literal(self, operand: str) -> bool:
        """Check if operand is a literal.

        Args:
            operand: Operand string

        Returns:
            True if operand is a literal
        """
        if not operand or not isinstance(operand, str):
            return False

        return operand.startswith("=")

    def resolve(self, operand: str) -> Optional[Dict]:
        """Resolve a literal operand.

        Args:
            operand: Operand string (e.g., "=V(DBREAD)", "=F'100'")

        Returns:
            Dictionary with literal info, or None if not a literal
        """
        if not self.is_literal(operand):
            return None

        # Try address literal (=V or =A)
        match = self.address_literal_pattern.match(operand)
        if match:
            literal_type = match.group(1)
            symbol = match.group(2)
            return {
                "type": literal_type,
                "symbol": symbol
            }

        # Try numeric literal (=F, =H, etc.)
        match = self.numeric_literal_pattern.match(operand)
        if match:
            literal_type = match.group(1)
            # Value can be in quotes or parentheses
            value = match.group(3) if match.group(3) else match.group(4)
            return {
                "type": literal_type,
                "value": value
            }

        # Unknown literal format
        return {
            "type": "UNKNOWN",
            "raw": operand
        }
