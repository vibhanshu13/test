#!/usr/bin/env python3
"""
lineage_levels.py
-----------------
Converts a flat .lineage.json (produced by main.py --lineage-export)
into a leveled BFS structure:

  {
    "root":  { "id": "register:R6", "name": "R6", "kind": "register" },
    "direction": "forward",
    "levels": [
      {
        "level": 1,
        "nodes": [ { "id": "...", "name": "...", "kind": "..." } ],
        "edges": [ { "from": "...", "to": "...", "relation": "...",
                     "expression": "...", "file": "...", "line": ... } ]
      },
      { "level": 2, ... },
      ...
    ],
    "summary": {
      "total_levels": 4,
      "total_nodes":  23,
      "total_edges":  31
    }
  }

Usage
-----
  python lineage_levels.py <lineage.json> --root <node-id-or-name> \
         --direction forward|backward --output leveled.json

  # Trace RAWRISK forward from the R6 lineage file:
  python lineage_levels.py output/lineage/r6_reg/RISKENGS.lineage.json \
         --root "register:R6" --direction forward \
         --output output/lineage/RAWRISK_leveled.json

  # Trace FINALRSK backward:
  python lineage_levels.py output/lineage/finalrsk/RISKENGS.lineage.json \
         --root "memory:FINALRSK" --direction backward \
         --output output/lineage/FINALRSK_leveled.json
"""

import argparse
import json
import pathlib
from collections import defaultdict, deque


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def short_file(path_str: str) -> str:
    """Return just the filename for display."""
    if not path_str:
        return ""
    p = pathlib.Path(path_str)
    return p.name


def find_node_id(nodes: list, query: str) -> str | None:
    """
    Resolve a query (full id like 'register:R6' OR just a name like 'R6')
    to the canonical node id.
    Returns the first match.
    """
    # Exact id match first
    for n in nodes:
        if n["id"] == query:
            return n["id"]
    # Name match (case-insensitive)
    query_lower = query.lower()
    for n in nodes:
        if n["name"].lower() == query_lower:
            return n["id"]
    return None


def build_adjacency(edges: list, direction: str) -> dict:
    """
    Build adjacency list: node_id -> list of (neighbor_id, edge_dict).
    direction='forward'  -> follow source->target
    direction='backward' -> follow target->source
    """
    adj = defaultdict(list)
    for e in edges:
        src = e["source"]
        tgt = e["target"]
        if direction == "forward":
            adj[src].append((tgt, e))
        else:
            adj[tgt].append((src, e))
    return adj


# ---------------------------------------------------------------------------
# BFS leveling
# ---------------------------------------------------------------------------

def bfs_levels(nodes: list, edges: list, root_id: str, direction: str,
               max_depth: int = 20) -> dict:
    """
    BFS from root_id following the given direction.
    Returns a leveled dict as described in the module docstring.
    """
    node_map = {n["id"]: n for n in nodes}
    adj = build_adjacency(edges, direction)

    visited_nodes = {root_id}
    visited_edges = set()   # (source, target, stmt_id) tuples

    levels = []
    frontier = deque([root_id])
    depth = 0

    while frontier and depth < max_depth:
        depth += 1
        next_frontier = deque()
        level_nodes = []
        level_edges = []

        while frontier:
            current = frontier.popleft()
            neighbors = adj.get(current, [])

            for neighbor_id, edge in neighbors:
                # Deduplicate edges by statement + relation
                edge_key = (edge["source"], edge["target"],
                            edge.get("statement_id", ""),
                            edge.get("relation", ""))
                if edge_key in visited_edges:
                    continue
                visited_edges.add(edge_key)

                level_edges.append({
                    "from":       edge["source"],
                    "from_name":  node_map.get(edge["source"], {}).get("name", edge["source"]),
                    "to":         edge["target"],
                    "to_name":    node_map.get(edge["target"], {}).get("name", edge["target"]),
                    "relation":   edge.get("relation", ""),
                    "expression": edge.get("expression", ""),
                    "file":       short_file(edge.get("file", "")),
                    "line":       edge.get("line"),
                    "statement_id": edge.get("statement_id", ""),
                })

                if neighbor_id not in visited_nodes:
                    visited_nodes.add(neighbor_id)
                    node_info = node_map.get(neighbor_id, {})
                    level_nodes.append({
                        "id":   neighbor_id,
                        "name": node_info.get("name", neighbor_id),
                        "kind": node_info.get("kind", "unknown"),
                    })
                    next_frontier.append(neighbor_id)

        if not level_edges and not level_nodes:
            break   # Nothing new — stop early

        levels.append({
            "level": depth,
            "nodes": level_nodes,
            "edges": level_edges,
        })
        frontier = next_frontier

    root_node = node_map.get(root_id, {"id": root_id, "name": root_id, "kind": "unknown"})
    total_edges = sum(len(lv["edges"]) for lv in levels)
    total_nodes = sum(len(lv["nodes"]) for lv in levels)

    return {
        "root": {
            "id":   root_node.get("id"),
            "name": root_node.get("name"),
            "kind": root_node.get("kind"),
        },
        "direction": direction,
        "levels": levels,
        "summary": {
            "total_levels": len(levels),
            "total_nodes":  total_nodes,
            "total_edges":  total_edges,
        },
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        description="Convert flat lineage JSON to BFS-leveled JSON",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    ap.add_argument("lineage_json",
                    help="Input .lineage.json from main.py --lineage-export")
    ap.add_argument("--root", required=True,
                    help="Root node id (e.g. 'register:R6') or just name ('R6')")
    ap.add_argument("--direction", default="forward",
                    choices=["forward", "backward"],
                    help="Traversal direction (default: forward)")
    ap.add_argument("--max-depth", type=int, default=20,
                    help="Maximum BFS depth (default: 20)")
    ap.add_argument("--output", default=None,
                    help="Output JSON file (default: <stem>_leveled.json)")
    args = ap.parse_args()

    # Load
    src = pathlib.Path(args.lineage_json)
    data = json.loads(src.read_text())
    nodes = data.get("nodes", [])
    edges = data.get("edges", [])

    print(f"Loaded: {len(nodes)} nodes, {len(edges)} edges from {src.name}")

    # Resolve root
    root_id = find_node_id(nodes, args.root)
    if root_id is None:
        print(f"ERROR: Node '{args.root}' not found in graph.")
        print("Available nodes (first 30):")
        for n in nodes[:30]:
            print(f"  id={n['id']!r:40s}  name={n['name']!r}")
        raise SystemExit(1)

    print(f"Root resolved: {root_id}  direction={args.direction}")

    # BFS
    result = bfs_levels(nodes, edges, root_id, args.direction, args.max_depth)

    print(f"\nLevels:      {result['summary']['total_levels']}")
    print(f"Nodes found: {result['summary']['total_nodes']}")
    print(f"Edges found: {result['summary']['total_edges']}")
    print()
    for lv in result["levels"]:
        node_names = ", ".join(n["name"] for n in lv["nodes"][:6])
        if len(lv["nodes"]) > 6:
            node_names += f" +{len(lv['nodes'])-6} more"
        print(f"  Level {lv['level']:>2}: {len(lv['nodes']):>3} nodes, "
              f"{len(lv['edges']):>3} edges  [ {node_names} ]")

    # Write output
    out_path = pathlib.Path(args.output) if args.output else \
               src.parent / f"{src.stem.split('.')[0]}_{args.direction}_leveled.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, indent=2))
    print(f"\nWrote: {out_path}")


if __name__ == "__main__":
    main()
