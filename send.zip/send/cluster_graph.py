#!/usr/bin/env python3
"""Build a cluster-level graph for a codebase (item #3 of the multi-level graph builder).

A *cluster* is a group of source files:
  * one cluster per makefile  — its members are the makefile's ``source_files``
    that are actually present in the codebase, and
  * one catch-all cluster (``unclustered``) holding every source file that no
    makefile builds.

For each cluster we emit:
  * the member files,
  * a business summary (LLM-synthesised from the member files' per-file
    ``business_summary`` blueprints, or a deterministic fallback with --no-llm),
  * cluster-to-cluster edges aggregated from the file-level call graph.

Inputs:
  --codebase-dir   directory of raw source files (e.g. temp/asm)
  --output-dir     parser-output root containing the per-file blueprints
                   (e.g. temp/output_latest — the *.asm.json / *.cpp.json /
                   *.mak.json files are located automatically beneath it)

The file-level call graph is rebuilt fresh from the current blueprints via
``file_call_graph.CallGraphBuilder`` (the committed file_call_graph.json is
often stale), so inter-cluster edges reflect the latest parser output.

Example:
    python cluster_graph.py \
        --codebase-dir temp/asm \
        --output-dir   temp/output_latest
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from blueprint_io import load_blueprint
from file_call_graph import CallGraphBuilder, format_json

# ── Recognised source extensions (mirrors the parser's file routing) ──────────
_ASM_EXTS = {".asm", ".mac", ".s", ".cpy", ".copy"}
_C_EXTS = {".c"}
_CPP_EXTS = {".cc", ".cpp", ".cxx", ".hpp", ".h"}
_SOURCE_EXTS = _ASM_EXTS | _C_EXTS | _CPP_EXTS
_MAKE_EXTS = {".mak"}
_MAKE_NAMES = {"Makefile", "makefile", "GNUmakefile"}

_CATCHALL_ID = "unclustered"


# ── Helpers ───────────────────────────────────────────────────────────────────
def _stem(name: str) -> str:
    """Return a filename's stem (basename without extension)."""
    return os.path.splitext(os.path.basename(name))[0]


def _is_makefile(name: str) -> bool:
    return name in _MAKE_NAMES or os.path.splitext(name)[1] in _MAKE_EXTS


def _find_blueprint_dir(output_dir: Path) -> Path:
    """Locate the directory holding per-file blueprints under *output_dir*.

    The blueprints are named ``<source>.json`` (e.g. ``lu82.asm.json``). They
    usually live in an ``asm`` subdir, but we search robustly: pick the
    directory containing the most blueprint files.
    """
    counts: Dict[Path, int] = defaultdict(int)
    for p in output_dir.rglob("*.json"):
        # A blueprint is "<name>.<srcext>.json"; require a double extension
        # whose inner part is a recognised source/makefile extension.
        inner = os.path.splitext(p.name[: -len(".json")])[1]
        if inner in _SOURCE_EXTS or inner in _MAKE_EXTS:
            counts[p.parent] += 1
    if not counts:
        raise SystemExit(
            f"error: no per-file blueprints (*.asm.json / *.cpp.json) found under {output_dir}"
        )
    return max(counts, key=counts.get)


def _enumerate_source_files(codebase_dir: Path) -> List[str]:
    """Return the recognised source filenames present in *codebase_dir*."""
    out: List[str] = []
    for p in sorted(codebase_dir.iterdir()):
        if not p.is_file() or _is_makefile(p.name):
            continue
        if os.path.splitext(p.name)[1] in _SOURCE_EXTS:
            out.append(p.name)
    return out


def _load_makefile_clusters(blueprint_dir: Path) -> Dict[str, dict]:
    """Return ``{makefile_stem: {file, source_files, app, app_type}}``."""
    clusters: Dict[str, dict] = {}
    for p in sorted(blueprint_dir.glob("*.json")):
        name = p.name[: -len(".json")]
        if not _is_makefile(name):
            continue
        try:
            bp = load_blueprint(p)
        except Exception as exc:  # noqa: BLE001 - skip unreadable blueprints
            print(f"warning: could not load makefile blueprint {p.name}: {exc}", file=sys.stderr)
            continue
        bm = bp.get("build_metadata") or {}
        variables = bm.get("variables") or {}
        clusters[_stem(name)] = {
            "makefile": os.path.basename(bm.get("file") or name),
            "source_files": list(bm.get("source_files") or []),
            "app": variables.get("APP"),
            "app_type": variables.get("APP_TYPE"),
            "outputs": list(bm.get("outputs") or []),
        }
    return clusters


def _load_business_summary(blueprint_dir: Path, filename: str) -> Optional[str]:
    """Return the per-file business_summary for *filename*, if available."""
    p = blueprint_dir / f"{filename}.json"
    if not p.exists():
        return None
    try:
        bp = load_blueprint(p, keys={"business_summary"})
    except Exception:  # noqa: BLE001
        return None
    return bp.get("business_summary")


# ── Cluster assignment ──────────────────────────────────────────────────────--
def assign_clusters(
    source_files: List[str],
    makefile_clusters: Dict[str, dict],
) -> Tuple[Dict[str, List[str]], Dict[str, List[str]]]:
    """Map files to clusters.

    Returns ``(cluster_members, file_to_clusters)`` where:
      * cluster_members[cluster_id] -> [filename, ...]
      * file_to_clusters[filename]  -> [cluster_id, ...]

    A file may belong to more than one makefile cluster. Files matched by no
    makefile land in the catch-all cluster.
    """
    present_stems: Dict[str, str] = {_stem(f): f for f in source_files}
    cluster_members: Dict[str, List[str]] = defaultdict(list)
    file_to_clusters: Dict[str, List[str]] = defaultdict(list)

    for cid, meta in makefile_clusters.items():
        for src in meta["source_files"]:
            fname = present_stems.get(_stem(src))
            if fname is None:
                continue  # makefile references a file not present in the codebase
            cluster_members[cid].append(fname)
            file_to_clusters[fname].append(cid)

    for fname in source_files:
        if fname not in file_to_clusters:
            cluster_members[_CATCHALL_ID].append(fname)
            file_to_clusters[fname].append(_CATCHALL_ID)

    return cluster_members, file_to_clusters


# ── Inter-cluster edges (from the file-level call + include graph) ────────────
def build_file_call_graph(codebase_dir: Path, blueprint_dir: Path) -> dict:
    """Rebuild the file-level call graph fresh from the current blueprints."""
    builder = CallGraphBuilder(
        asm_dir=codebase_dir, blueprint_dir=blueprint_dir, recursive=False
    )
    graph = builder.build()
    graph.__dict__["_blueprint_dir"] = str(blueprint_dir)
    graph.__dict__["_asm_dir"] = str(codebase_dir)
    return json.loads(format_json(graph, include_external=True))


def call_file_edges(file_graph: dict, stem_to_file: Dict[str, str]) -> List[dict]:
    """Internal file-to-file call edges, as ``{source_file, target_file, type, instructions}``."""
    edges: List[dict] = []
    for edge in file_graph.get("edges", []):
        if not edge.get("is_internal"):
            continue  # external edges point at unresolved modules, not files
        src = stem_to_file.get(edge["source"])
        tgt = stem_to_file.get(edge["target"])
        if not src or not tgt or src == tgt:
            continue
        edges.append(
            {"source_file": src, "target_file": tgt, "type": "call",
             "instructions": edge.get("instructions", [])}
        )
    return edges


def include_file_edges(blueprint_dir: Path, source_files: List[str]) -> Tuple[List[dict], int]:
    """C/C++ ``#include`` edges between codebase files, as ``{source_file, target_file, type}``.

    Returns ``(edges, external_include_count)`` — includes of headers that are not
    themselves codebase files are counted but not turned into edges.
    """
    by_basename = {f: f for f in source_files}
    edges: List[dict] = []
    external = 0
    for fname in source_files:
        bp_path = blueprint_dir / f"{fname}.json"
        if not bp_path.exists():
            continue
        try:
            bp = load_blueprint(bp_path, skip_global_lineage=True, keys={"file_dependencies"})
        except Exception:  # noqa: BLE001
            continue
        for dep in (bp.get("file_dependencies") or {}).get("edges", []):
            to_file = os.path.basename(dep.get("to_file", ""))
            target = by_basename.get(to_file)
            if target is None:
                external += 1
                continue
            if target == fname:
                continue
            edges.append({"source_file": fname, "target_file": target, "type": "include"})
    return edges, external


def aggregate_cluster_edges(
    file_edges: List[dict],
    file_to_clusters: Dict[str, List[str]],
) -> List[dict]:
    """Lift file-to-file edges to directed cluster-to-cluster edges.

    Accepts a unified list of ``{source_file, target_file, type}`` edges (both
    ``call`` and ``include``). Edges whose endpoints fall in the same cluster are
    dropped; the rest are aggregated per ``(source_cluster, target_cluster)`` with
    a total ``weight`` plus a ``call``/``include`` breakdown and full provenance.
    """
    agg: Dict[Tuple[str, str], dict] = {}
    for fe in file_edges:
        src_file, tgt_file = fe["source_file"], fe["target_file"]
        etype = fe.get("type", "call")
        for cs in file_to_clusters.get(src_file, []):
            for ct in file_to_clusters.get(tgt_file, []):
                if cs == ct:
                    continue  # intra-cluster — not an inter-cluster connection
                bucket = agg.setdefault(
                    (cs, ct),
                    {"source": cs, "target": ct, "weight": 0,
                     "call_weight": 0, "include_weight": 0, "file_edges": []},
                )
                bucket["weight"] += 1
                bucket["call_weight" if etype == "call" else "include_weight"] += 1
                bucket["file_edges"].append(fe)
    return sorted(agg.values(), key=lambda e: (-e["weight"], e["source"], e["target"]))


# ── Cluster summaries ─────────────────────────────────────────────────────────
_CLUSTER_SYSTEM_PROMPT = (
    "You are a senior technical analyst explaining a software module to non-technical "
    "business stakeholders. You are given the per-file business summaries of every file "
    "in one build unit (module). Synthesise a single, cohesive business summary of the "
    "module as a whole: what overall business capability it delivers, the main processes "
    "it coordinates, the external systems or data it relies on, and how the files work "
    "together. Do not mention file names, register names, opcodes, or low-level technical "
    "details. Write 4 to 6 sentences."
)


def _fallback_summary(cluster_id: str, meta: Optional[dict], file_summaries: List[Tuple[str, Optional[str]]]) -> str:
    label = (meta or {}).get("app") or cluster_id
    lines = [f"Cluster '{label}' groups {len(file_summaries)} file(s)."]
    for fname, summ in file_summaries:
        first = (summ.split(". ")[0].strip() + ".") if summ else "(no summary available)"
        lines.append(f"- {fname}: {first}")
    return "\n".join(lines)


def generate_cluster_summary(
    cluster_id: str,
    meta: Optional[dict],
    file_summaries: List[Tuple[str, Optional[str]]],
    use_llm: bool,
) -> str:
    """Produce a business summary for one cluster."""
    if not use_llm:
        return _fallback_summary(cluster_id, meta, file_summaries)

    header_bits = []
    if meta and meta.get("app"):
        header_bits.append(f"Module/application: {meta['app']}")
    if meta and meta.get("app_type"):
        header_bits.append(f"Build type: {meta['app_type']}")
    if cluster_id == _CATCHALL_ID:
        header_bits.append(
            "These files are not associated with any makefile; treat them as a loose "
            "collection rather than a single application."
        )
    header = "\n".join(header_bits)

    parts = []
    for fname, summ in file_summaries:
        parts.append(f"### {fname}\n{summ or '(no summary available)'}")
    body = "\n\n".join(parts)

    prompt = (
        f"{header}\n\n" if header else ""
    ) + (
        f"The module contains {len(file_summaries)} file(s). Per-file business "
        f"summaries follow.\n\n{body}\n\n"
        "Provide one cohesive business summary of this module."
    )

    try:
        from llm.caller import call_llm

        return call_llm(prompt, system_prompt=_CLUSTER_SYSTEM_PROMPT).strip()
    except Exception as exc:  # noqa: BLE001 - degrade gracefully without an API key
        print(
            f"warning: LLM summary failed for cluster '{cluster_id}' ({exc}); "
            "using deterministic fallback",
            file=sys.stderr,
        )
        return _fallback_summary(cluster_id, meta, file_summaries)


# ── Orchestration ─────────────────────────────────────────────────────────────
def build_cluster_graph(
    codebase_dir: Path,
    output_dir: Path,
    use_llm: bool = True,
) -> dict:
    blueprint_dir = _find_blueprint_dir(output_dir)
    source_files = _enumerate_source_files(codebase_dir)
    if not source_files:
        raise SystemExit(f"error: no recognised source files found in {codebase_dir}")

    makefile_clusters = _load_makefile_clusters(blueprint_dir)
    cluster_members, file_to_clusters = assign_clusters(source_files, makefile_clusters)

    file_graph = build_file_call_graph(codebase_dir, blueprint_dir)
    stem_to_file = {_stem(f): f for f in source_files}
    # Also let call-graph node ids that are real files resolve even if absent
    # from the codebase enumeration (blueprint-only files).
    for node in file_graph.get("nodes", []):
        if node.get("type") in {"asm", "cpp", "header"} and node["id"] not in stem_to_file:
            stem_to_file[node["id"]] = node.get("file") or node["id"]

    call_edges = call_file_edges(file_graph, stem_to_file)
    include_edges, _ = include_file_edges(blueprint_dir, source_files)
    cluster_edges = aggregate_cluster_edges(call_edges + include_edges, file_to_clusters)

    # Build cluster nodes with summaries.
    nodes: List[dict] = []
    for cid in sorted(cluster_members, key=lambda c: (c == _CATCHALL_ID, c)):
        members = sorted(cluster_members[cid])
        meta = makefile_clusters.get(cid)
        file_summaries = [
            (f, _load_business_summary(blueprint_dir, f)) for f in members
        ]
        summary = generate_cluster_summary(cid, meta, file_summaries, use_llm)
        node = {
            "id": cid,
            "type": "catchall" if cid == _CATCHALL_ID else "makefile",
            "makefile": (meta or {}).get("makefile"),
            "app": (meta or {}).get("app"),
            "app_type": (meta or {}).get("app_type"),
            "outputs": (meta or {}).get("outputs", []),
            "member_files": members,
            "file_count": len(members),
            "summary": summary,
        }
        nodes.append(node)

    return {
        "metadata": {
            "generator": "cluster_graph.py",
            "codebase_dir": str(codebase_dir),
            "blueprint_dir": str(blueprint_dir),
            "llm_summaries": use_llm,
        },
        "nodes": nodes,
        "edges": cluster_edges,
        "summary": {
            "cluster_count": len(nodes),
            "makefile_cluster_count": sum(1 for n in nodes if n["type"] == "makefile"),
            "inter_cluster_edge_count": len(cluster_edges),
            "inter_cluster_call_weight": sum(e["call_weight"] for e in cluster_edges),
            "inter_cluster_include_weight": sum(e["include_weight"] for e in cluster_edges),
            "total_files": len(source_files),
        },
    }


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="cluster_graph.py",
        description="Build a cluster-level graph (one cluster per makefile + a catch-all).",
    )
    p.add_argument("--codebase-dir", required=True, metavar="DIR", help="Directory of raw source files")
    p.add_argument(
        "--output-dir",
        required=True,
        metavar="DIR",
        help="Parser-output root containing the per-file blueprints",
    )
    p.add_argument("--output", metavar="FILE", help="Write JSON to FILE (default: <output-dir>/cluster_graph.json)")
    p.add_argument("--no-llm", action="store_true", help="Skip LLM summaries; use deterministic fallback")
    return p


def main() -> int:
    args = build_arg_parser().parse_args()
    codebase_dir = Path(args.codebase_dir).resolve()
    output_dir = Path(args.output_dir).resolve()
    for d in (codebase_dir, output_dir):
        if not d.exists():
            print(f"error: directory not found: {d}", file=sys.stderr)
            return 1

    graph = build_cluster_graph(codebase_dir, output_dir, use_llm=not args.no_llm)

    out_path = Path(args.output) if args.output else output_dir / "cluster_graph.json"
    out_path.write_text(json.dumps(graph, indent=2), encoding="utf-8")
    s = graph["summary"]
    print(
        f"Wrote cluster graph to: {out_path}\n"
        f"  clusters={s['cluster_count']} "
        f"(makefile={s['makefile_cluster_count']}, catch-all=1) "
        f"inter-cluster edges={s['inter_cluster_edge_count']} files={s['total_files']}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
