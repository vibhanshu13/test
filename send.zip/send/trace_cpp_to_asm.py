#!/usr/bin/env python3
"""
trace_cpp_to_asm.py

C++-first cross-language lineage tracer.

Use this when the input is a C++ variable name (e.g. ``onlineSrcInd``,
``Da7gl.cmSystem``) and you want the full story — C++ lineage per blueprint,
the ASM counterpart discovered via ``field_asm_aliases``, and the ASM-side
lineage of that counterpart — in one JSON document.

Orchestration only — delegates to:
  - ``trace_cpp_lineage.py`` for per-blueprint C++ lineage (backward + forward)
  - ``trace_cross_file_lineage.py`` for the ASM cross-file trace

Neither of those scripts is modified.

Usage
-----
  python3 trace_cpp_to_asm.py \\
      --var onlineSrcInd \\
      --blueprint-dir integration_out/asm \\
      --asm-dir ../asm \\
      --output outputs/trace/cpp_onlineSrcInd.json

Output shape
------------
  {
    "query":        "<input var>",
    "asm_mapping":  [{"cpp_field": "...", "asm_name": "...",
                       "hpp_source": "...", "blueprint": "..."}],
    "cpp_side":     {"<bp_stem>": <trace_cpp_lineage output>},
    "asm_side":     <trace_cross_file_lineage output or null>,
    "warnings":     [ ... ]
  }
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from blueprint_io import load_blueprint


REPO_ROOT = Path(__file__).resolve().parent


# ---------------------------------------------------------------------------
# ASM alias discovery
# ---------------------------------------------------------------------------

def _discover_asm_mappings(
    blueprint_dir: Path,
    cpp_var: str,
) -> List[Dict[str, str]]:
    """Scan every *.cpp.json for ASM counterparts of the C++ variable.

    Looks in three places:
      1. ``field_asm_aliases``       — cc*.hpp trailing-comment bridge (Phase 2).
      2. ECB table                   — Phase 6 ``ecbptr()->ce1crN`` convention.
      3. ``globals_used``            — Phase 7 ``glob(_name)`` globals.

    ``cpp_var`` can be bare (``onlineSrcInd``) or qualified
    (``CasGLRec.onlineSrcInd``). Matching is case-insensitive on the tail.
    """
    query = cpp_var.strip()
    needle = query.split(".")[-1].lower()
    if not needle:
        return []

    # Import the ECB table lazily so the tracer stays usable even if phase 6
    # hasn't been applied yet.
    try:
        from passes.ecb_alias_table import ECB_FIELD_TO_ASM
    except ImportError:
        ECB_FIELD_TO_ASM = {}

    results: List[Dict[str, Any]] = []
    seen: Set[Tuple[str, str, str]] = set()
    for bp in sorted(blueprint_dir.rglob("*.cpp.json")):
        try:
            payload = load_blueprint(bp)
        except (OSError, json.JSONDecodeError):
            continue

        # (1) Phase 2 cc*.hpp field aliases.
        aliases = payload.get("field_asm_aliases") or {}
        sources = payload.get("field_asm_alias_sources") or {}
        if isinstance(aliases, dict):
            for key, asm_name in aliases.items():
                if not isinstance(key, str) or not isinstance(asm_name, str):
                    continue
                field_part = key.split(".", 1)[-1].lower()
                if field_part == needle or key.lower() == query.lower():
                    k = (key, asm_name.upper(), "cc_hpp")
                    if k in seen:
                        continue
                    seen.add(k)
                    results.append({
                        "cpp_field":   key,
                        "asm_name":    asm_name.upper(),
                        "hpp_source":  sources.get(key, ""),
                        "blueprint":   bp.name,
                        "mapping_via": "cc_hpp_comment",
                    })

        # (2) Phase 6 ECB control block: match the bare tail against the table.
        ecb_match = ECB_FIELD_TO_ASM.get(needle)
        if ecb_match:
            k = (needle, ecb_match, "ecb")
            if k not in seen:
                seen.add(k)
                results.append({
                    "cpp_field":   f"ecbptr()->{needle}",
                    "asm_name":    ecb_match,
                    "hpp_source":  "(ecb_alias_table)",
                    "blueprint":   bp.name,
                    "mapping_via": "ecb_control_block",
                })

        # (3) Phase 7 globals: user may type "tpfcv83" or "_tpfcv83" or "TPFCV83".
        globals_used = payload.get("globals_used") or []
        if isinstance(globals_used, list):
            needle_norm = needle.lstrip("_").upper()
            for g in globals_used:
                if not isinstance(g, str):
                    continue
                if g.upper() == needle_norm:
                    k = (g, g.upper(), "glob")
                    if k in seen:
                        continue
                    seen.add(k)
                    results.append({
                        "cpp_field":   f"glob(_{g.lower()})",
                        "asm_name":    g.upper(),
                        "hpp_source":  "(glob_runtime_call)",
                        "blueprint":   bp.name,
                        "mapping_via": "glob_runtime",
                    })
    return results


# ---------------------------------------------------------------------------
# C++-side lineage across all cpp.json blueprints that reference the variable
# ---------------------------------------------------------------------------

def _find_cpp_declaration(
    asm_mapping: Dict[str, Any],
    hpp_search_dirs: List[Path],
) -> Optional[Dict[str, Any]]:
    """Locate the C++ declaration of a struct field in a cc*.hpp header.

    Called when ``cpp_side`` is empty but ``asm_mapping`` has an entry —
    tells the reader "this field IS declared in <hpp>:<line>, no .cpp
    file in this corpus touches it" rather than leaving the empty dict
    ambiguous.

    ``asm_mapping`` shape: the per-entry dict produced by
    ``_discover_asm_mappings`` (with ``cpp_field``, ``hpp_source``, …).
    """
    hpp_name = asm_mapping.get("hpp_source") or ""
    cpp_field = asm_mapping.get("cpp_field") or ""
    if not hpp_name or not cpp_field:
        return None
    # cpp_field is "StructName.fieldName" — we want the field part.
    parts = cpp_field.split(".", 1)
    struct_name = parts[0] if len(parts) == 2 else None
    field_name = parts[-1]
    if not field_name:
        return None

    for d in hpp_search_dirs:
        candidate = d / hpp_name
        if not candidate.exists():
            continue
        try:
            text = candidate.read_text(errors="replace")
        except OSError:
            continue
        # Simple line-by-line scan — look for "<type> <field>[...];" on any
        # line of the header.
        field_re = re.compile(
            rf"^\s*(?P<type>[\w:*&<>,\s]+?)\s+{re.escape(field_name)}\s*(?:\[[^\]]*\])?\s*;"
        )
        for lineno, raw in enumerate(text.splitlines(), start=1):
            # Strip trailing comment for matching; retain for display.
            core = re.sub(r"//.*$", "", raw).rstrip()
            m = field_re.match(core)
            if m:
                return {
                    "file":   str(candidate),
                    "line":   lineno,
                    "struct": struct_name,
                    "type":   m.group("type").strip(),
                    "field":  field_name,
                }
    return None


def _cpp_blueprints_referencing_var(
    blueprint_dir: Path,
    cpp_var: str,
) -> List[Path]:
    """Return cpp.json blueprints whose variable_lineage mentions ``cpp_var``.

    A blueprint "references" the variable if any node.name, edge.target, or
    edge.source contains the field suffix as a whole word-ish token.
    """
    suffix = cpp_var.strip().split(".")[-1]
    suffix_l = suffix.lower()
    hits: List[Path] = []
    for bp in sorted(blueprint_dir.rglob("*.cpp.json")):
        try:
            payload = load_blueprint(bp)
        except (OSError, json.JSONDecodeError):
            continue
        vl = payload.get("variable_lineage") or {}
        # Cheap scan — dump to text once.
        blob = json.dumps(vl).lower()
        # Require something resembling the field (either ".<suffix>" or "->":<suffix>).
        if f".{suffix_l}" in blob or f"->{suffix_l}" in blob or f":{suffix_l}" in blob:
            hits.append(bp)
    return hits


def _candidate_node_ids(payload: Dict[str, Any], cpp_var: str) -> List[Dict[str, str]]:
    """Enumerate every variable_lineage node in a blueprint that could match the
    query — so the orchestrator can trace each via --node-id and avoid the
    single-best-match collapse in trace_cpp_lineage.

    A node matches if its bare/suffix name equals the query suffix (e.g.
    ``cmSystem`` matches ``countTransaction::cmSystem``, ``da7gl->cmSystem``,
    and ``globalLimitsUpdate::da7gl->cmSystem``), OR if the full query string
    is present verbatim in the node name (e.g. ``da7gl->cmSystem`` qualified).

    Returned as a list of ``{id, name, kind}`` dicts preserving source order.
    Prefer-order for tracing: struct_field first (they cross the language
    boundary and matter most), then parameter, then variable, then everything
    else — so the merged output starts with the most cross-language-relevant
    lineage.
    """
    query = cpp_var.strip()
    needle = query.split(".")[-1].lower()
    query_lower = query.lower()
    vl = payload.get("variable_lineage") or {}

    def _node_tail(name: str) -> str:
        # Strip qualifiers: "globalLimitsUpdate::da7gl->cmSystem" → "cmSystem"
        # and "Da7gl.cmSystem" → "cmSystem".
        tail = name.split("::")[-1]
        for sep in ("->", ".", "["):
            tail = tail.split(sep)[-1]
        return tail.lower()

    matches: List[Dict[str, str]] = []
    for node in vl.get("nodes") or []:
        nm = node.get("name") or ""
        if not isinstance(nm, str) or not nm:
            continue
        # Match by exact tail (e.g., "cmSystem") or by full-query substring
        # (e.g., user passed "da7gl->cmSystem").
        if _node_tail(nm) == needle or query_lower in nm.lower():
            matches.append({
                "id": node.get("id") or f"{node.get('kind','variable')}:{nm}",
                "name": nm,
                "kind": node.get("kind") or "unknown",
            })

    kind_priority = {"struct_field": 0, "parameter": 1, "variable": 2}
    matches.sort(key=lambda m: (kind_priority.get(m["kind"], 9), m["name"]))
    return matches


def _invoke_trace_cpp_lineage(
    cpp_json: Path,
    cpp_var: str,
    direction: str,
    max_depth: Optional[int],
    node_id: Optional[str] = None,
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Run ``trace_cpp_lineage.py`` as a subprocess; return (payload, error_str).

    When ``node_id`` is supplied, invokes the underlying tool with
    ``--node-id`` which bypasses name-based candidate resolution entirely and
    traces from exactly that node. This is what lets the orchestrator trace
    every matching node (struct_field / parameter / variable) separately
    instead of collapsing to a single best match.
    """
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
        out_path = Path(tmp.name)
    try:
        cmd = [
            sys.executable,
            str(REPO_ROOT / "trace_cpp_lineage.py"),
            "--cpp-json", str(cpp_json),
            "--var", cpp_var,
            "--direction", direction,
            "--out", str(out_path),
        ]
        if node_id:
            cmd += ["--node-id", node_id]
        if max_depth is not None:
            cmd += ["--max-depth", str(max_depth)]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if proc.returncode != 0:
            # exit codes: 2 = no match, 3 = ambiguous (typical); include stderr tail.
            reason = (proc.stderr or "").strip().splitlines()[-1] if proc.stderr else ""
            return None, f"exit={proc.returncode}: {reason}"
        if not out_path.exists() or out_path.stat().st_size == 0:
            return None, "empty output"
        return json.loads(out_path.read_text(encoding="utf-8")), None
    except subprocess.TimeoutExpired:
        return None, "timeout"
    except Exception as exc:
        return None, f"exception: {exc}"
    finally:
        try:
            out_path.unlink()
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Downstream ASM stem discovery (Pattern G fix — follow variable into callees)
# ---------------------------------------------------------------------------

def _find_asm_downstream_stems(trace_payload: Dict[str, Any]) -> Set[str]:
    """Recursively extract ``_discovered_downstream`` stem lists from a
    ``trace_cross_file_lineage`` result payload.

    ``trace_cross_file_lineage`` embeds ``_discovered_downstream`` as an
    internal field on per-file result dicts.  This function walks the entire
    nested result tree collecting every such list so that ``trace_cpp_to_asm``
    can trace the same variable forward into callee files (section 3e).

    A stem is the lowercase base name of an ASM or CPP file without extension
    (e.g. ``"da76"``).  Only non-empty strings are returned.
    """
    found: Set[str] = set()

    def _walk(obj: Any, depth: int = 0) -> None:
        if depth > 6 or not isinstance(obj, dict):
            return
        dd = obj.get("_discovered_downstream")
        if isinstance(dd, list):
            found.update(s for s in dd if isinstance(s, str) and s)
        for val in obj.values():
            if isinstance(val, dict):
                _walk(val, depth + 1)
            elif isinstance(val, list):
                for item in val:
                    if isinstance(item, dict):
                        _walk(item, depth + 1)

    _walk(trace_payload)
    return found


# ---------------------------------------------------------------------------
# Depth-1 downstream variable-name mapping (Pattern G fix — register rename)
# ---------------------------------------------------------------------------

_REG_ARG_RE = re.compile(r"^parameter:arg@(\w+):R(\d+)$")


def _build_downstream_var_map(
    stem: str,
    asm_var: str,
    blueprint_dir: Path,
) -> Dict[str, str]:
    """After tracing ``asm_var`` in the ASM file ``stem``, load that file's
    blueprint and infer what variable to trace in each of its callee files.

    Two-step inference:
    1. Find ``memory:VAR`` nodes that received the value from ``register:asm_var``
       (i.e. ``register:asm_var → assign → memory:VAR`` edges). These are
       the memory locations where the register was stored inside the callee.
    2. Find callee-call edges where one of those stored variables (or the
       original register) was passed to a downstream callee via a register slot
       (``register:RN → assign → parameter:arg@CALLEE:RN``). The register RN
       is the variable name to trace in CALLEE.

    Returns ``{callee_stem_lower: var_to_trace}`` for depth-1 downstream files.
    Empty dict if the blueprint cannot be loaded or no propagation chain is found.
    """
    # Locate the blueprint for this stem.
    bp_candidates = list(blueprint_dir.rglob(f"{stem}.asm.json"))
    if not bp_candidates:
        return {}
    try:
        payload = load_blueprint(bp_candidates[0])
    except (OSError, json.JSONDecodeError):
        return {}

    vl = payload.get("variable_lineage") or {}
    edges = vl.get("edges") or []

    reg_src_prefix = f"register:{asm_var}"

    # Step 1: find memory nodes that asm_var (register) was stored into.
    stored_mem_vars: Set[str] = set()
    for edge in edges:
        if edge.get("relation") != "assign":
            continue
        if edge.get("source") != reg_src_prefix:
            continue
        tgt = edge.get("target", "")
        if tgt.startswith("memory:"):
            stored_mem_vars.add(tgt[len("memory:"):])

    # Step 2: find which downstream callees receive those memory vars (or the
    # register itself) through a register slot.
    # Approach: for each `register:RN → parameter:arg@CALLEE:RN` edge, check
    # whether RN was loaded from a stored_mem_var or is asm_var itself.
    # This requires matching a register-load edge (memory:VAR → register:RN)
    # with a subsequent register-to-arg edge. We approximate by collecting
    # all registers that ever held asm_var or a stored_mem_var.

    # Build: {register_name: True} for registers that held the tracked value.
    live_registers: Set[str] = {asm_var}  # the original incoming register
    for edge in edges:
        if edge.get("relation") != "assign":
            continue
        src = edge.get("source", "")
        tgt = edge.get("target", "")
        # memory:VAR → register:RN (load from tracked memory)
        if src.startswith("memory:") and src[len("memory:"):] in stored_mem_vars:
            if tgt.startswith("register:"):
                live_registers.add(tgt[len("register:"):])
        # register:RN → register:RM (register copy of tracked register)
        if src.startswith("register:") and src[len("register:"):] in live_registers:
            if tgt.startswith("register:"):
                live_registers.add(tgt[len("register:"):])

    # Now map: callee_stem → {register_used}
    result: Dict[str, str] = {}
    for edge in edges:
        if edge.get("relation") != "assign":
            continue
        src = edge.get("source", "")
        tgt = edge.get("target", "")
        if not src.startswith("register:"):
            continue
        reg = src[len("register:"):]
        if reg not in live_registers:
            continue
        m = _REG_ARG_RE.match(tgt)
        if not m:
            continue
        callee_stem = m.group(1).lower()
        callee_reg = f"R{m.group(2)}"
        # First mapping wins (lowest slot number due to sorted edge ordering).
        if callee_stem not in result:
            result[callee_stem] = callee_reg

    return result


# ---------------------------------------------------------------------------
# Global-alias projection discovery (Pattern G fix — non-register paths)
# ---------------------------------------------------------------------------

def _find_global_alias_projections(
    blueprint_dir: Path,
    cpp_var: str,
) -> List[Dict[str, str]]:
    """Scan CPP blueprints for assign/alias edges from the C++ variable into
    ``global:<NAME>`` nodes, then look for a matching ``memory:<NAME>`` node in
    any ASM blueprint.  Returns them as additional ASM entry points.

    This covers the case where a CPP variable is written to a z/TPF system
    control byte via ``*(char*)glob(TOKEN) = value`` and an ASM module reads
    the same TOKEN via GLOBZ.  The register-projection scan misses this path
    because the bridge does not go through a register slot.
    """
    needle = cpp_var.strip().split(".")[-1].lower()
    if not needle:
        return []

    _global_re = re.compile(r"^global:(.+)$")
    results: List[Dict[str, str]] = []
    seen: Set[str] = set()

    # Phase 1 — collect global:<NAME> targets reached from the CPP variable.
    global_names: Set[str] = set()
    for bp_path in sorted(blueprint_dir.rglob("*.cpp.json")):
        try:
            payload = load_blueprint(bp_path)
        except (OSError, json.JSONDecodeError):
            continue
        vl = payload.get("variable_lineage", {})
        for edge in vl.get("edges", []):
            if edge.get("relation") not in ("assign", "alias"):
                continue
            src = edge.get("source", "")
            tgt = edge.get("target", "")
            src_tail = src.split("::")[-1].lower()
            if needle not in src_tail:
                continue
            m = _global_re.match(tgt)
            if m:
                global_names.add(m.group(1))

    if not global_names:
        return []

    # Phase 2 — find ASM blueprints that have a matching memory:<NAME> node.
    for bp_path in sorted(blueprint_dir.rglob("*.asm.json")):
        try:
            payload = load_blueprint(bp_path)
        except (OSError, json.JSONDecodeError):
            continue
        vl = payload.get("variable_lineage", {})
        asm_mem_names = {
            n["id"].split(":", 1)[1]
            for n in vl.get("nodes", [])
            if n.get("kind") == "memory" and ":" in n.get("id", "")
        }
        for gname in global_names:
            if gname in asm_mem_names and gname not in seen:
                seen.add(gname)
                results.append({
                    "asm_name":     gname,
                    "global_name":  f"global:{gname}",
                    "cpp_var":      cpp_var,
                    "blueprint":    bp_path.name,
                    "mapping_via":  "global_alias_projection",
                })

    return results


# ---------------------------------------------------------------------------
# Struct-field projection discovery (Pattern G fix — field_asm_aliases paths)
# ---------------------------------------------------------------------------

def _find_struct_field_projections(
    blueprint_dir: Path,
    cpp_var: str,
) -> List[Dict[str, str]]:
    """Scan CPP blueprints for assign edges from the C++ variable into
    ``struct_field`` nodes that carry an ``asm_alias`` metadata annotation
    (populated from ``field_asm_aliases`` in cc*.hpp headers).  Return those
    ASM alias names as additional entry points for the cross-file ASM trace.

    This covers paths like:
        CPP var  →assign→  struct_field:func::regs.someField  (asm_alias=ASMFIELD)
                                    ↕ (field_asm_aliases bridge)
                           memory:ASMFIELD  →  ASM trace
    which are not captured by register projections (no ``register:arg@`` node)
    or global-alias projections (no ``global:`` node).
    """
    needle = cpp_var.strip().split(".")[-1].lower()
    if not needle:
        return []

    results: List[Dict[str, str]] = []
    seen: Set[str] = set()

    for bp_path in sorted(blueprint_dir.rglob("*.cpp.json")):
        try:
            payload = load_blueprint(bp_path)
        except (OSError, json.JSONDecodeError):
            continue

        vl = payload.get("variable_lineage", {})

        # Index asm_alias by node id.
        asm_alias_by_id: Dict[str, str] = {}
        for node in vl.get("nodes", []):
            aa = (node.get("metadata") or {}).get("asm_alias")
            if aa:
                asm_alias_by_id[node["id"]] = str(aa)

        if not asm_alias_by_id:
            continue

        for edge in vl.get("edges", []):
            if edge.get("relation") != "assign":
                continue
            src = edge.get("source", "")
            tgt = edge.get("target", "")
            if not src or not tgt:
                continue
            src_tail = src.split("::")[-1].lower()
            if needle not in src_tail:
                continue
            asm_alias = asm_alias_by_id.get(tgt)
            if not asm_alias or asm_alias in seen:
                continue
            seen.add(asm_alias)
            results.append({
                "asm_name":      asm_alias,
                "cpp_source":    src,
                "struct_field":  tgt,
                "blueprint":     bp_path.name,
                "mapping_via":   "struct_field_projection",
            })

    return results


# ---------------------------------------------------------------------------
# GVL ECB-alias projection discovery (CPP-ASM Pattern F/G fix)
# ---------------------------------------------------------------------------

def _find_ecb_alias_projections(
    blueprint_dir: Path,
    cpp_var: str,
) -> List[Dict[str, str]]:
    """Scan the Global Variable Lineage (GVL) for stitcher-created ECB bridge
    edges / node annotations (``ecb_alias`` / ``alias_type`` ``cpp_ecb_to_asm``
    or ``cpp_ecb_ptr_cast``) whose CPP-side node name tail matches the queried
    variable suffix.  Returns them as additional ASM entry points.

    Covers paths like::

        CPP var  →(assign)→  struct_field:func::ecbptr()->ce1cr5
                                   ↕ (GVL alias edge, cpp_ecb_to_asm)
                              memory:CE1CR5  →  ASM cross-file trace

    which are missed by ``_find_struct_field_projections`` because that finder
    reads per-blueprint ``variable_lineage`` nodes (which carry ``asm_alias``)
    rather than the merged GVL (which carries ``ecb_alias`` — a different key
    set by the stitcher, not the cc*.hpp Phase-2 pass).
    """
    needle = cpp_var.strip().split(".")[-1].lower()
    if not needle:
        return []

    # Locate the merged GVL — same discovery order as blueprint_io._get_global_lineage.
    gvl_data: Optional[Dict[str, Any]] = None
    for _gvl_candidate in [
        blueprint_dir / "global_variable_lineage.json",
        blueprint_dir.parent / "global_variable_lineage.json",
    ]:
        if _gvl_candidate.exists():
            try:
                gvl_data = json.loads(_gvl_candidate.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                pass
            break
    if not gvl_data:
        return []

    _ECB_EXPRS = ("cpp_ecb_to_asm", "cpp_ecb_ptr_cast")
    results: List[Dict[str, str]] = []
    seen: Set[str] = set()

    def _node_tail(name: str) -> str:
        tail = name.split("::")[-1]
        for sep in ("->", ".", "["):
            tail = tail.split(sep)[-1]
        return tail.lower()

    # ── Pass 1: node-based ──────────────────────────────────────────────────
    # _stitch_ecb_field_bindings / _stitch_ecb_ptr_cast_aliases annotate CPP
    # nodes in the GVL with {ecb_alias: "ASM_NAME", alias_type: "cpp_ecb_to_asm"|...}.
    for node in gvl_data.get("nodes", []):
        meta = node.get("metadata") or {}
        ecb_alias = meta.get("ecb_alias")
        if not ecb_alias:
            continue
        node_name = node.get("name") or ""
        if needle not in _node_tail(node_name):
            continue
        asm_name = str(ecb_alias).upper()
        if asm_name in seen:
            continue
        seen.add(asm_name)
        results.append({
            "asm_name":    asm_name,
            "cpp_node":    node.get("id", ""),
            "alias_type":  meta.get("alias_type", "ecb_alias"),
            "blueprint":   "(gvl)",
            "mapping_via": "ecb_alias_projection",
        })

    # ── Pass 2: edge-based ──────────────────────────────────────────────────
    # Catch alias edges emitted by the stitcher:
    #   source=CPP_node → target=memory:ASM_NAME
    #   expression="global_lineage_stitch:cpp_ecb_to_asm"
    # Also catch ecb_bridge edges scoped to "ECB" that connect CPP writes to
    # ASM memory nodes (source contains needle, target is memory:X).
    for edge in gvl_data.get("edges", []):
        relation = edge.get("relation", "")
        if relation not in ("alias", "ecb_bridge"):
            continue
        expr = edge.get("expression") or ""
        is_ecb_expr = any(t in expr for t in _ECB_EXPRS)
        is_ecb_bridge = relation == "ecb_bridge" and "ECB" in (edge.get("scope") or "")
        if not is_ecb_expr and not is_ecb_bridge:
            continue
        src = edge.get("source", "")
        tgt = edge.get("target", "")
        if not src or not tgt:
            continue
        # Source node name must contain the needle.
        _, src_name = src.split(":", 1) if ":" in src else ("", src)
        if needle not in _node_tail(src_name):
            continue
        # Target must be a memory node — that IS the ASM variable.
        tgt_kind, tgt_name = tgt.split(":", 1) if ":" in tgt else ("", tgt)
        if tgt_kind != "memory":
            continue
        asm_name = tgt_name.upper()
        if asm_name in seen:
            continue
        seen.add(asm_name)
        results.append({
            "asm_name":    asm_name,
            "cpp_source":  src,
            "expression":  expr,
            "blueprint":   "(gvl)",
            "mapping_via": "ecb_alias_projection",
        })

    return results


# ---------------------------------------------------------------------------
# Register-projection entry-point discovery (Pattern G fix)
# ---------------------------------------------------------------------------

def _find_register_projections(
    blueprint_dir: Path,
    cpp_var: str,
) -> List[Dict[str, str]]:
    """Scan CPP blueprints for assign edges from the C++ variable into
    ``register:arg@CALLEE:RN`` nodes and return them as ASM entry points.

    These edges represent the value passing through a CALLC register slot and
    provide a direct, value-flow-based starting point for the ASM backward
    trace — independent of ``field_asm_aliases`` name lookup.
    """
    needle = cpp_var.strip().split(".")[-1].lower()
    if not needle:
        return []

    _reg_proj_re = re.compile(r"^register:arg@(\w+):R(\d+)$")
    results: List[Dict[str, str]] = []
    seen: Set[Tuple[str, str]] = set()

    for bp_path in sorted(blueprint_dir.rglob("*.cpp.json")):
        try:
            payload = load_blueprint(bp_path)
        except (OSError, json.JSONDecodeError):
            continue

        vl = payload.get("variable_lineage", {})
        for edge in vl.get("edges", []):
            if edge.get("relation") != "assign":
                continue
            src = edge.get("source", "")
            tgt = edge.get("target", "")
            if not src or not tgt:
                continue
            # Source must contain the queried variable name (tail match).
            src_tail = src.split("::")[-1].lower()
            if needle not in src_tail:
                continue
            m = _reg_proj_re.match(tgt)
            if not m:
                continue
            callee = m.group(1).lower()
            reg = f"R{m.group(2)}"
            key = (callee, reg)
            if key in seen:
                continue
            seen.add(key)
            results.append({
                "callee":       callee,
                "register":     reg,
                "cpp_source":   src,
                "blueprint":    bp_path.name,
                "mapping_via":  "register_projection",
            })

    return results


# ---------------------------------------------------------------------------
# ASM-side cross-file lineage
# ---------------------------------------------------------------------------

def _invoke_trace_cross_file(
    asm_var: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    graph_file: Optional[Path],
    chain_index: int,
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
        out_path = Path(tmp.name)
    try:
        cmd = [
            sys.executable,
            str(REPO_ROOT / "trace_cross_file_lineage.py"),
            asm_var,
            "--blueprint-dir", str(blueprint_dir),
            "--chain", str(chain_index),
            "--simple-traversal",
            "--output", str(out_path),
        ]
        if asm_dir:
            cmd += ["--asm-dir", str(asm_dir)]
        if graph_file:
            cmd += ["--graph", str(graph_file)]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if proc.returncode != 0:
            reason = (proc.stderr or "").strip().splitlines()[-1] if proc.stderr else ""
            return None, f"exit={proc.returncode}: {reason}"
        if not out_path.exists() or out_path.stat().st_size == 0:
            return None, "empty output"
        return json.loads(out_path.read_text(encoding="utf-8")), None
    except subprocess.TimeoutExpired:
        return None, "timeout"
    except Exception as exc:
        return None, f"exception: {exc}"
    finally:
        try:
            out_path.unlink()
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Unified chain builder (CPP-ASM Pattern G fix)
# ---------------------------------------------------------------------------

def _build_unified_chain(
    cpp_side: Dict[str, Any],
    asm_mappings: List[Dict[str, str]],
    asm_side: Dict[str, Any],
    reg_projections: List[Dict[str, str]],
    glob_projections: List[Dict[str, str]],
    sf_projections: List[Dict[str, str]],
    ecb_projections: Optional[List[Dict[str, str]]] = None,
) -> List[Dict[str, Any]]:
    """Synthesise a single ordered narrative from cpp_side + asm_side data.

    The unified chain is a list of steps narrating the full data-flow path:
      CPP writer(s) → bridge (CALLC/field_alias) → ASM entry → downstream callee(s)

    Each step has:
      step       — 1-based sequential index
      phase      — "cpp" | "bridge" | "asm" | "asm_downstream"
      kind       — finer type within phase
      ref_key    — key in cpp_side or asm_side where the full trace lives
      (optional fields carrying summary metadata for quick review)

    Steps are ordered: CPP writers first, then bridge, then ASM entry routines
    (sorted by asm_name), then downstream callees in depth order.
    """
    chain: List[Dict[str, Any]] = []
    step = 1

    # ── 1. CPP writer steps ──────────────────────────────────────────────────
    for bp_stem, bp_val in sorted(cpp_side.items()):
        if not isinstance(bp_val, dict):
            continue
        traces = bp_val.get("traces")
        if isinstance(traces, list):
            for entry in traces:
                kind = entry.get("node_kind", "unknown")
                chain.append({
                    "step": step,
                    "phase": "cpp",
                    "kind": kind,
                    "blueprint": bp_stem,
                    "node_id": entry.get("node_id"),
                    "node_name": entry.get("node_name"),
                    "ref_key": f"cpp_side.{bp_stem}",
                })
                step += 1
        else:
            # Name-based fallback (single trace payload)
            chain.append({
                "step": step,
                "phase": "cpp",
                "kind": "trace",
                "blueprint": bp_stem,
                "ref_key": f"cpp_side.{bp_stem}",
            })
            step += 1

    # ── 2. Bridge steps (CPP→ASM mapping) ────────────────────────────────────
    # Emit one bridge step per unique mapping mechanism.
    _bridge_seen: Set[str] = set()

    for m in asm_mappings:
        bkey = f"{m.get('cpp_field','?')}→{m.get('asm_name','?')}"
        if bkey in _bridge_seen:
            continue
        _bridge_seen.add(bkey)
        chain.append({
            "step": step,
            "phase": "bridge",
            "kind": m.get("mapping_via", "field_alias"),
            "cpp_field": m.get("cpp_field"),
            "asm_name": m.get("asm_name"),
            "hpp_source": m.get("hpp_source"),
            "ref_key": f"asm_side.{m.get('asm_name','')}",
        })
        step += 1

    for rp in reg_projections:
        bkey = f"reg:{rp.get('callee','?')}:{rp.get('register','?')}"
        if bkey in _bridge_seen:
            continue
        _bridge_seen.add(bkey)
        chain.append({
            "step": step,
            "phase": "bridge",
            "kind": "register_projection",
            "callee": rp.get("callee"),
            "register": rp.get("register"),
            "cpp_source": rp.get("cpp_source"),
            "ref_key": f"asm_side.{rp.get('callee','')}:{rp.get('register','')}",
        })
        step += 1

    for gp in glob_projections:
        bkey = f"glob:{gp.get('asm_name','?')}"
        if bkey in _bridge_seen:
            continue
        _bridge_seen.add(bkey)
        chain.append({
            "step": step,
            "phase": "bridge",
            "kind": "global_alias",
            "global_name": gp.get("global_name"),
            "asm_name": gp.get("asm_name"),
            "ref_key": f"asm_side.{gp.get('asm_name','')}",
        })
        step += 1

    for sfp in sf_projections:
        bkey = f"sf:{sfp.get('asm_name','?')}"
        if bkey in _bridge_seen:
            continue
        _bridge_seen.add(bkey)
        chain.append({
            "step": step,
            "phase": "bridge",
            "kind": "struct_field_alias",
            "struct_field": sfp.get("struct_field"),
            "asm_name": sfp.get("asm_name"),
            "ref_key": f"asm_side.{sfp.get('asm_name','')}",
        })
        step += 1

    for ep in (ecb_projections or []):
        bkey = f"ecb:{ep.get('asm_name','?')}"
        if bkey in _bridge_seen:
            continue
        _bridge_seen.add(bkey)
        chain.append({
            "step": step,
            "phase": "bridge",
            "kind": "ecb_alias_projection",
            "cpp_node": ep.get("cpp_node") or ep.get("cpp_source"),
            "asm_name": ep.get("asm_name"),
            "alias_type": ep.get("alias_type"),
            "ref_key": f"asm_side.{ep.get('asm_name','')}",
        })
        step += 1

    # ── 3. ASM entry steps (primary non-downstream entries) ──────────────────
    for asm_key, asm_val in sorted(asm_side.items()):
        if asm_key.endswith(":downstream"):
            continue
        if not isinstance(asm_val, dict):
            continue
        has_error = "error" in asm_val and "trace" not in asm_val
        chain.append({
            "step": step,
            "phase": "asm",
            "kind": "entry",
            "asm_key": asm_key,
            "status": "error" if has_error else "ok",
            "ref_key": f"asm_side.{asm_key}",
        })
        step += 1

    # ── 4. Downstream callee steps (ordered by depth then stem) ──────────────
    downstream_entries = [
        (k, v) for k, v in asm_side.items()
        if k.endswith(":downstream") and isinstance(v, dict)
    ]
    downstream_entries.sort(key=lambda kv: (kv[1].get("depth", 0), kv[0]))
    for asm_key, asm_val in downstream_entries:
        has_error = "error" in asm_val and "trace" not in asm_val
        chain.append({
            "step": step,
            "phase": "asm_downstream",
            "kind": "callee",
            "asm_key": asm_key,
            "stem": asm_val.get("stem"),
            "depth": asm_val.get("depth"),
            "var_used": asm_val.get("var_used"),
            "status": "error" if has_error else "ok",
            "ref_key": f"asm_side.{asm_key}",
        })
        step += 1

    return chain


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    p = argparse.ArgumentParser(
        description=(
            "C++-first cross-language lineage tracer. Takes a C++ variable "
            "or struct field name, produces combined C++ + ASM lineage."
        ),
    )
    p.add_argument("--var", required=True,
                   help="C++ variable or field name (e.g. onlineSrcInd, Da7gl.cmSystem).")
    p.add_argument("--blueprint-dir", required=True,
                   help="Directory containing *.cpp.json / *.asm.json blueprints.")
    p.add_argument("--asm-dir", help="Directory of raw .asm source (for deeper ASM backward trace).")
    p.add_argument("--graph", help="Path to file_call_graph.json (auto-discovered if omitted).")
    p.add_argument("--chain", type=int, default=0,
                   help="ASM chain index to use (default 0 = shortest).")
    p.add_argument("--direction", choices=["backward", "forward", "both"], default="both",
                   help="C++ trace direction (default: both).")
    p.add_argument("--max-depth", type=int, help="Max C++ traversal depth.")
    p.add_argument("--output", required=True, help="Output JSON path.")
    args = p.parse_args()

    blueprint_dir = Path(args.blueprint_dir)
    if not blueprint_dir.is_dir():
        print(f"ERROR: blueprint dir not found: {blueprint_dir}", file=sys.stderr)
        return 1
    asm_dir = Path(args.asm_dir) if args.asm_dir else None
    graph_file = Path(args.graph) if args.graph else None

    warnings: List[str] = []
    print(f"[query]        {args.var}", file=sys.stderr)

    # ── 1. Discover ASM mapping via field_asm_aliases ────────────────────────
    asm_mappings = _discover_asm_mappings(blueprint_dir, args.var)
    if asm_mappings:
        for m in asm_mappings:
            print(f"[asm-mapping]  {m['cpp_field']}  →  {m['asm_name']}  "
                  f"[{m['hpp_source']}]", file=sys.stderr)
    else:
        msg = (f"No field_asm_aliases entry found for '{args.var}'. "
               "The C++ variable has no direct ASM counterpart in cc*.hpp headers.")
        print(f"[asm-mapping]  (none)", file=sys.stderr)
        warnings.append(msg)

    # ── 2. C++ side: per-blueprint lineage ───────────────────────────────────
    referencing_bps = _cpp_blueprints_referencing_var(blueprint_dir, args.var)
    print(f"[cpp-bps]      {len(referencing_bps)} blueprint(s) reference '{args.var}'",
          file=sys.stderr)

    cpp_side: Dict[str, Any] = {}
    for bp in referencing_bps:
        stem = bp.name.removesuffix(".cpp.json")
        try:
            bp_payload = load_blueprint(bp)
        except (OSError, json.JSONDecodeError) as exc:
            warnings.append(f"{stem}: cannot load blueprint — {exc}")
            cpp_side[stem] = {"error": str(exc)}
            continue

        candidates = _candidate_node_ids(bp_payload, args.var)
        if not candidates:
            # Fall back to name-based resolution (trace_cpp_lineage will decide).
            print(f"[cpp-trace]    {stem} (name-based) …", file=sys.stderr)
            payload, err = _invoke_trace_cpp_lineage(
                cpp_json=bp, cpp_var=args.var, direction=args.direction,
                max_depth=args.max_depth,
            )
            cpp_side[stem] = payload if payload else {"error": err}
            if err:
                warnings.append(f"{stem}: C++ trace failed — {err}")
            continue

        print(f"[cpp-trace]    {stem}  ({len(candidates)} candidate node(s))",
              file=sys.stderr)
        per_node: List[Dict[str, Any]] = []
        for cand in candidates:
            payload, err = _invoke_trace_cpp_lineage(
                cpp_json=bp, cpp_var=args.var, direction=args.direction,
                max_depth=args.max_depth, node_id=cand["id"],
            )
            entry: Dict[str, Any] = {
                "node_id": cand["id"],
                "node_name": cand["name"],
                "node_kind": cand["kind"],
            }
            if payload is not None:
                entry["trace"] = payload
            else:
                entry["error"] = err
                warnings.append(
                    f"{stem}/{cand['id']}: C++ trace failed — {err}"
                )
            per_node.append(entry)
        cpp_side[stem] = {
            "candidate_count": len(candidates),
            "traces": per_node,
        }

    # ── 3. ASM side: cross-file lineage for each discovered ASM counterpart ──
    asm_side: Dict[str, Any] = {}
    for m in asm_mappings:
        asm_name = m["asm_name"]
        if asm_name in asm_side:
            continue
        print(f"[asm-trace]    {asm_name} …", file=sys.stderr)
        payload, err = _invoke_trace_cross_file(
            asm_var=asm_name,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            graph_file=graph_file,
            chain_index=args.chain,
        )
        if payload is not None:
            asm_side[asm_name] = payload
        else:
            warnings.append(f"{asm_name}: ASM trace failed — {err}")
            asm_side[asm_name] = {"error": err}

    # ── 3b. Register-projection entry points (Pattern G fix) ─────────────────
    # Supplement name-based ASM traces with any register:arg@CALLEE:RN edges
    # found in CPP blueprints.  This connects the CPP trace to the ASM callee
    # via actual value-flow edges, independent of field_asm_aliases.
    reg_projections = _find_register_projections(blueprint_dir, args.var)
    for rp in reg_projections:
        key = f"{rp['callee']}:{rp['register']}"
        if key in asm_side:
            continue
        print(f"[reg-proj]     {rp['cpp_source']}  →  {key}", file=sys.stderr)
        payload, err = _invoke_trace_cross_file(
            asm_var=rp["register"],
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            graph_file=graph_file,
            chain_index=args.chain,
        )
        if payload is not None:
            asm_side[key] = {"mapping": rp, "trace": payload}
        else:
            warnings.append(f"{key}: register-projection ASM trace failed — {err}")
            asm_side[key] = {"mapping": rp, "error": err}

    # ── 3c. Global-alias entry points (Pattern G fix — non-register paths) ────
    # Covers CPP → global:<NAME> → memory:<NAME> (ASM) paths not captured by
    # field_asm_aliases or register projections.  Typical case: a CPP variable
    # written via *(char*)glob(TOKEN) consumed by ASM via GLOBZ macro.
    glob_projections = _find_global_alias_projections(blueprint_dir, args.var)
    for gp in glob_projections:
        gkey = gp["asm_name"]
        if gkey in asm_side:
            continue
        print(f"[glob-proj]    {gp['global_name']}  →  memory:{gkey}", file=sys.stderr)
        payload, err = _invoke_trace_cross_file(
            asm_var=gkey,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            graph_file=graph_file,
            chain_index=args.chain,
        )
        if payload is not None:
            asm_side[gkey] = {"mapping": gp, "trace": payload}
        else:
            warnings.append(f"{gkey}: global-alias ASM trace failed — {err}")
            asm_side[gkey] = {"mapping": gp, "error": err}

    # ── 3d. Struct-field / field_asm_aliases entry points (Pattern G fix) ────
    # Covers CPP var → struct_field:…::regs.rN (asm_alias=ASMFIELD) → ASM paths
    # that are not captured by register or global projections.  Typical case: a
    # C++ struct field annotated with an ASM DSECT name in a cc*.hpp header.
    sf_projections = _find_struct_field_projections(blueprint_dir, args.var)
    for sfp in sf_projections:
        sfkey = sfp["asm_name"]
        if sfkey in asm_side:
            continue
        print(f"[sf-proj]      {sfp['cpp_source']}  →  memory:{sfkey}  "
              f"[asm_alias]", file=sys.stderr)
        payload, err = _invoke_trace_cross_file(
            asm_var=sfkey,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            graph_file=graph_file,
            chain_index=args.chain,
        )
        if payload is not None:
            asm_side[sfkey] = {"mapping": sfp, "trace": payload}
        else:
            warnings.append(f"{sfkey}: struct-field-projection ASM trace failed — {err}")
            asm_side[sfkey] = {"mapping": sfp, "error": err}

    # ── 3e. GVL ECB alias projections (CPP-ASM Pattern F/G fix) ─────────────
    # Covers CPP var → struct_field/variable with ecb_alias=CE1CRx/EBWxxx in the
    # merged GVL — paths created by _stitch_ecb_field_bindings and
    # _stitch_ecb_ptr_cast_aliases that have no local asm_alias annotation on
    # the per-blueprint struct_field node and are therefore invisible to the
    # three existing projection finders.
    ecb_projections = _find_ecb_alias_projections(blueprint_dir, args.var)
    for ep in ecb_projections:
        epkey = ep["asm_name"]
        if epkey in asm_side:
            continue
        print(f"[ecb-proj]     {ep.get('cpp_node') or ep.get('cpp_source', '?')}  "
              f"→  memory:{epkey}  [{ep.get('alias_type', 'ecb_alias')}]",
              file=sys.stderr)
        payload, err = _invoke_trace_cross_file(
            asm_var=epkey,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            graph_file=graph_file,
            chain_index=args.chain,
        )
        if payload is not None:
            asm_side[epkey] = {"mapping": ep, "trace": payload}
        else:
            warnings.append(f"{epkey}: ECB-alias-projection ASM trace failed — {err}")
            asm_side[epkey] = {"mapping": ep, "error": err}

    # ── 3f. Follow _discovered_downstream into callee ASM files ──────────────
    # Sections 3a–3e discover ASM entry points and trace the variable in those
    # files.  Each trace result may contain ``_discovered_downstream`` — stems
    # of callee files that the modifier passes the variable into (via ENTRC /
    # CALLC / CREEC).  Section 3f collects those stems and traces the same
    # variable in the callee files, emitting additional ``asm_side`` entries
    # keyed as ``<stem>:downstream``.
    # A max-depth guard prevents unbounded recursion on call cycles.

    # Build a stem → variable-name map from register projections (section 3b).
    # When a downstream callee was reached via a register slot (e.g. da76
    # received R3), the variable lives in that callee under the *register* name,
    # not under args.var.  Tracing args.var in that file would return empty
    # results; tracing the register name is the correct first-hop approximation.
    _stem_var_map: Dict[str, str] = {
        rp["callee"].lower(): rp["register"]
        for rp in reg_projections
    }

    _downstream_visited: Set[str] = set(asm_side.keys())
    _downstream_queue: List[str] = []
    for _existing_payload in list(asm_side.values()):
        if isinstance(_existing_payload, dict):
            _inner = _existing_payload.get("trace") or _existing_payload
            _downstream_queue.extend(_find_asm_downstream_stems(_inner))
    _downstream_queue = [s for s in _downstream_queue if s not in _downstream_visited]

    # _next_stem_var_map accumulates depth-1 variable-name hints built from
    # each successful depth-0 trace.  When a depth-0 callee stores R3 into
    # WK_TEMP and then passes WK_TEMP to a depth-1 callee via R5, this map
    # will contain {depth1_callee_stem: "R5"} so we trace R5 there instead
    # of the original args.var.
    _next_stem_var_map: Dict[str, str] = {}

    _downstream_depth = 0
    _MAX_DOWNSTREAM_DEPTH = 3  # limit chain following to avoid large fan-outs
    while _downstream_queue and _downstream_depth < _MAX_DOWNSTREAM_DEPTH:
        _next_queue: List[str] = []
        _new_depth_var_map: Dict[str, str] = {}  # var hints for depth+1
        for _stem in sorted(set(_downstream_queue)):
            _dkey = f"{_stem}:downstream"
            if _dkey in asm_side or _stem in _downstream_visited:
                continue
            _downstream_visited.add(_stem)
            # Depth 0: use register name from _stem_var_map (built from section 3b
            #          register projections).
            # Depth ≥ 1: use _next_stem_var_map, built from each depth-0 trace by
            #             following the register→memory→register→arg chain inside the
            #             callee blueprint.  Falls back to args.var when not found.
            if _downstream_depth == 0:
                _asm_var_for_stem = _stem_var_map.get(_stem.lower(), args.var)
            else:
                _asm_var_for_stem = _next_stem_var_map.get(_stem.lower(), args.var)
            print(f"[downstream]   {_stem} ({_asm_var_for_stem}) …", file=sys.stderr)
            _payload, _err = _invoke_trace_cross_file(
                asm_var=_asm_var_for_stem,
                blueprint_dir=blueprint_dir,
                asm_dir=asm_dir,
                graph_file=graph_file,
                chain_index=args.chain,
            )
            if _payload is not None:
                asm_side[_dkey] = {
                    "stem": _stem,
                    "depth": _downstream_depth + 1,
                    "var_used": _asm_var_for_stem,
                    "trace": _payload,
                }
                _next_queue.extend(_find_asm_downstream_stems(_payload))
                # Build variable hints for the *next* depth level (rolling at every
                # depth, not just depth-0).  Depth-N produces depth-(N+1) hints so
                # that depth≥2 downstream traces use the correct register/variable
                # name rather than always falling back to args.var.
                _new_depth_var_map.update(
                    _build_downstream_var_map(_stem, _asm_var_for_stem, blueprint_dir)
                )
            else:
                warnings.append(f"{_stem} (downstream): ASM trace failed — {_err}")
                asm_side[_dkey] = {
                    "stem": _stem,
                    "depth": _downstream_depth + 1,
                    "var_used": _asm_var_for_stem,
                    "error": _err,
                }
        _next_stem_var_map = _new_depth_var_map   # roll forward for next iteration
        _downstream_queue = [s for s in _next_queue if s not in _downstream_visited]
        _downstream_depth += 1

    # ── 4. Flow-direction hint (heuristic, based on observed writers) ────────
    # Count C++ writers (assign-edge scopes on the field) and ASM setters.
    # Not a perfect inference — a field can flow both ways on different call
    # paths — but a useful top-level label for reviewers.
    # Count distinct C++ node-level matches that represent writers/struct-fields
    # across every blueprint. Struct-field nodes are the clearest writer signal
    # for the cross-language bridge.
    cpp_writer_count = 0
    for bp_payload in cpp_side.values():
        if not isinstance(bp_payload, dict):
            continue
        traces = bp_payload.get("traces")
        if isinstance(traces, list):
            for entry in traces:
                if entry.get("node_kind") in ("struct_field", "variable", "parameter"):
                    cpp_writer_count += 1
        else:
            # Fallback-path payload (direct trace_cpp_lineage output).
            cpp_writer_count += len(bp_payload.get("resolved_candidates") or [])
    asm_setter_count = 0
    for asm_payload in (asm_side or {}).values():
        if not isinstance(asm_payload, dict):
            continue
        for file_rec in (asm_payload.get("files") or {}).values():
            for var_rec in (file_rec.get("variables") or {}).values():
                asm_setter_count += len(var_rec.get("setter_locations") or [])

    # Origin detection — "where did this variable's value start?"
    # Heuristic: side with writers is the producer; the other side is the
    # consumer. For LLM-friendly causal ordering we emit the producer side
    # first, then the bridge, then the consumer side.
    if not asm_mappings:
        origin = "cpp"              # no ASM alias at all — pure C++ local
        flow_hint = "cpp_only"
    elif cpp_writer_count > 0 and asm_setter_count > 0:
        origin = "bidirectional"    # both sides write; caller must pick path
        flow_hint = "bidirectional"
    elif cpp_writer_count > 0:
        origin = "cpp"              # C++ writes → ASM reads
        flow_hint = "cpp_to_asm"
    elif asm_setter_count > 0:
        origin = "asm"              # ASM writes → C++ reads (or exposes)
        flow_hint = "asm_to_cpp"
    else:
        origin = "unknown"          # variable is declared but nobody writes
        flow_hint = "unknown"

    # ── 5. Declaration lookup when cpp_side is empty but a mapping exists ───
    # The variable has a documented ASM counterpart (cc*.hpp or ECB or glob)
    # but no .cpp file in this corpus writes/reads it — locate the header
    # declaration so the reader has something concrete to point at.
    cpp_declaration: Optional[Dict[str, Any]] = None
    if not cpp_side and asm_mappings:
        # Search both the blueprint dir's parent (likely contains the cc*.hpp)
        # and common z/TPF `../asm/` layout.
        search_dirs = [blueprint_dir.parent, blueprint_dir.parent / "asm"]
        if asm_dir:
            search_dirs.append(asm_dir)
        # de-dup while preserving order
        seen_dirs: Set[Path] = set()
        unique_dirs: List[Path] = []
        for d in search_dirs:
            rp = d.resolve()
            if rp in seen_dirs or not d.is_dir():
                continue
            seen_dirs.add(rp)
            unique_dirs.append(d)
        for m in asm_mappings:
            decl = _find_cpp_declaration(m, unique_dirs)
            if decl:
                cpp_declaration = decl
                warnings.append(
                    f"'{args.var}' is declared in {decl['file']}:{decl['line']} "
                    f"(struct {decl.get('struct')}, type {decl.get('type')}) "
                    f"but no analyzed .cpp file references it — cpp_side is "
                    f"empty by design, not by error."
                )
                break

    # ── 6. Build unified chain ────────────────────────────────────────────────
    # Stitch CPP writers → bridge → ASM entry → downstream callees into a
    # single ordered narrative list.  Each step has a ``ref_key`` pointing
    # into ``cpp_side`` or ``asm_side`` for the full trace detail.
    # This satisfies CPP-ASM Pattern G: a unified single-flow document that
    # narrates the complete path without side-by-side aggregation only.
    unified_chain = _build_unified_chain(
        cpp_side=cpp_side,
        asm_mappings=asm_mappings,
        asm_side=asm_side or {},
        reg_projections=reg_projections,
        glob_projections=glob_projections,
        sf_projections=sf_projections,
        ecb_projections=ecb_projections,
    )

    # ── 7. Emit combined payload with a STABLE schema ────────────────────────
    # Key order is fixed across all queries for downstream/LLM consumer
    # stability. The `origin` field tells the reader which side is the
    # producer — consumer can walk the trees in causal order by following
    # that hint without relying on key ordering.
    output: Dict[str, Any] = {
        "query": args.var,
        "origin": origin,
        "flow_hint": flow_hint,
        "flow_stats": {
            "cpp_writers_observed": cpp_writer_count,
            "asm_setters_observed": asm_setter_count,
        },
        "unified_chain": unified_chain,
        "cpp_side": cpp_side,
        "cpp_declaration": cpp_declaration,
        "asm_mapping": asm_mappings,
        "asm_side": asm_side if asm_side else None,
    }
    if warnings:
        output["warnings"] = warnings

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(f"\nWrote combined trace to: {out_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
