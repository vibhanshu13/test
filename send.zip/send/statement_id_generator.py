"""Statement ID generation for provenance tracking."""


class StatementIDGenerator:
    """Generates unique statement IDs for provenance tracking.

    Creates sequential IDs in format: prefix_NNNNN
    Default prefix is 'stmt'.
    """

    def __init__(self, prefix: str = "stmt"):
        """Initialize generator.

        Args:
            prefix: Prefix for generated IDs (default: "stmt")
        """
        self.prefix = prefix
        self.counter = 0

    def next_id(self) -> str:
        """Generate next sequential ID.

        Returns:
            Statement ID in format: prefix_NNNNN
        """
        self.counter += 1
        return f"{self.prefix}_{self.counter:05d}"

    def reset(self):
        """Reset counter to 0."""
        self.counter = 0
