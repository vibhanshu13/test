"""
C++ call chain BFS traversal engine.

Two traversal modes:

  forward  – enumerate all functions transitively called by the root.
             Blueprints are loaded on-demand via LRU cache; only the
             ``call_graph`` key is requested to minimise RAM.

  backward – enumerate all functions that transitively call the root.
             Uses the pre-built callers index (zero blueprint I/O per hop).
             Falls back to source scanning when the index has no entry.

Every output node includes:
  method_name, file_name, file_path, line_number,
  call_site_line, depth, call_type, instruction,
  is_external, parent_method, parent_file,
  return_type, parameters_raw, parameters

Blueprint loading
-----------------
Calls ``blueprint_io.load_blueprint(path, keys={"call_graph"},
skip_global_lineage=True)`` so that only the needed section is kept in
memory after the decode; the rest is freed immediately by Python's reference
counter.  Files are opened, read, and closed inside ``load_blueprint``.

Source fallback
---------------
When a blueprint is absent for a function's file, ``source_scanner`` is
used to:
  - Extract function parameters (always tried when source_path is given)
  - Find callees inside a function body (forward fallback)
  - Locate callers across the codebase (backward last-resort fallback)

Scalability
-----------
* BFS + visited set: each (method, file_stem) pair emitted at most once.
* Blueprint LRU cache (256 entries, module-level in knowledge_base.py):
  repeated requests for popular files serve from RAM with no disk I/O.
* The callers index is prebuilt and O(1) per lookup, so backward traversal
  adds no per-hop I/O.
* max_depth bound limits total work to O(reachable_nodes × branching_factor).
"""

from __future__ import annotations

import logging
from collections import deque
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from api.utils.indirection import envelope_from_fields, extract_indirection, merge_indirection

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Standard-library / OS functions to suppress by default
# ---------------------------------------------------------------------------

_STDLIB_EXACT: Set[str] = {
    "memcpy", "memset", "memcmp", "memchr", "memmove",
    "malloc", "calloc", "realloc", "free",
    "strlen", "strcmp", "strncmp", "strcpy", "strncpy",
    "strcat", "strncat", "strchr", "strrchr", "strstr",
    "sprintf", "snprintf", "printf", "fprintf", "sscanf", "scanf",
    "fopen", "fclose", "fread", "fwrite", "fseek", "ftell", "fflush",
    "exit", "abort", "assert", "_exit",
    "new", "delete", "operator new", "operator delete",
}
_MAX_SOURCE_FALLBACK_FILES = 500  # rglob file limit for source caller fallback

_STDLIB_PREFIXES: Tuple[str, ...] = (
    "std::", "boost::", "__", "operator",
    "tpf_", "df_",   # common TPF runtime prefixes
)


def _is_stdlib(name: str) -> bool:
    return name in _STDLIB_EXACT or name.startswith(_STDLIB_PREFIXES)


# ---------------------------------------------------------------------------
# File stem helper
# ---------------------------------------------------------------------------

def _file_stem(path: Optional[str]) -> Optional[str]:
    if not path:
        return None
    name = Path(path).name
    for ext in (".cpp", ".hpp", ".h", ".cc", ".cxx", ".c"):
        if name.endswith(ext):
            return name[: -len(ext)]
    return Path(path).stem


# ---------------------------------------------------------------------------
# Blueprint call-graph loader
# ---------------------------------------------------------------------------

def _load_cg(file_stem: str, blueprint_dir: str) -> Optional[Dict]:
    """Load only the call_graph section of a blueprint.

    Uses the API-level LRU cache (``_get_cached_blueprint``) when running
    inside the API process, to amortise repeated loads.  Falls back to a
    direct ``blueprint_io`` call in standalone contexts.

    The file is opened and closed inside ``blueprint_io.load_blueprint``
    (it reads all bytes then closes).  Only the ``call_graph`` dict is kept
    in memory; the rest is freed immediately.
    """
    bd = Path(blueprint_dir)

    # --- API LRU cache (preferred) ---
    try:
        from api.routes.knowledge_base import _get_cached_blueprint  # type: ignore
        bp = _get_cached_blueprint(blueprint_dir, file_stem, keys={"call_graph"})
        if bp and isinstance(bp, dict):
            cg = bp.get("call_graph")
            if cg:
                return cg
    except ImportError:
        pass

    # --- Direct load via blueprint_io ---
    try:
        from blueprint_io import load_blueprint  # type: ignore[import]
        for suffix in (".cpp.json", ".asm.json", ".mac.json"):
            candidate = bd / f"{file_stem}{suffix}"
            if candidate.exists():
                bp = load_blueprint(
                    candidate,
                    keys={"call_graph"},
                    skip_global_lineage=True,
                )
                cg = bp.get("call_graph") if bp else None
                if cg:
                    return cg
    except Exception as exc:
        logger.debug("Cannot load call graph for '%s': %s", file_stem, exc)

    return None


# ---------------------------------------------------------------------------
# Index lookups
# ---------------------------------------------------------------------------

def _resolve_def(
    func_name: str,
    file_stem: Optional[str],
    index: Dict,
) -> Dict[str, Any]:
    """Return the best-matching definition entry from the index."""
    entries: List[Dict] = index.get("definitions", {}).get(func_name, [])
    if not entries:
        return {}
    if file_stem:
        for e in entries:
            if e.get("file_stem") == file_stem:
                return e
    return entries[0]


def _resolve_node_from_blueprint(
    method: str,
    fstem: str,
    blueprint_dir: str,
) -> Dict[str, Any]:
    """Resolve an ASM/MAC routine's metadata from its blueprint call graph.

    Used as a fallback when the function is absent from the CPP-only definitions
    index (i.e., for ASM/MAC routines encountered during cross-language traversal).
    Returns a subset of the definition-entry schema:
        {file_path, definition_line, is_external, kind}
    Returns {} when the blueprint or the node cannot be found.
    """
    cg = _load_cg(fstem, blueprint_dir)
    if not cg:
        return {}
    node = (cg.get("nodes") or {}).get(method) or {}
    if not node:
        return {}
    return {
        "file_path": node.get("file") or "",
        "definition_line": None,   # line_metadata not loaded in _load_cg
        "is_external": bool(node.get("is_external", False)),
        "kind": node.get("kind", "routine"),
    }


# ---------------------------------------------------------------------------
# Parameter enrichment
# ---------------------------------------------------------------------------

def _get_params(
    func_name: str,
    file_path: Optional[str],
    hint_line: Optional[int],
    source_path: Optional[str],
) -> Dict[str, Any]:
    """Retrieve function signature (return type + params) from source.

    Uses source_scanner; returns {} when source is unavailable.
    """
    if not source_path and not (file_path and Path(file_path).exists()):
        return {}
    try:
        from cpp_call_chain.source_scanner import get_signature  # type: ignore
        return get_signature(func_name, file_path, hint_line, source_path)
    except Exception as exc:
        logger.debug("Signature lookup failed for %s: %s", func_name, exc)
        return {}


# ---------------------------------------------------------------------------
# Node factory
# ---------------------------------------------------------------------------

def _make_node(
    *,
    method_name: str,
    file_stem: Optional[str],
    file_path: Optional[str],
    line_number: Optional[int],
    call_site_line: Optional[int],
    depth: int,
    call_type: str,
    instruction: str,
    is_external: bool,
    parent_method: Optional[str],
    parent_file: Optional[str],
    return_type: str = "",
    parameters_raw: str = "",
    parameters: Optional[List[str]] = None,
    language: str = "cpp",
    indirection: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    node: Dict[str, Any] = {
        "method_name": method_name,
        "file_name": file_stem or "",
        "file_path": file_path or "",
        "line_number": line_number,       # function definition line (1-based)
        "call_site_line": call_site_line, # line in parent where call appears
        "depth": depth,
        "call_type": call_type,
        "instruction": instruction,
        "is_external": is_external,
        "parent_method": parent_method or "",
        "parent_file": parent_file or "",
        "return_type": return_type,
        "parameters_raw": parameters_raw,
        "parameters": parameters or [],
        "language": language,             # "cpp", "asm", "mac", or "unknown"
    }
    if indirection:
        node["indirection"] = dict(indirection)
    return node


# ---------------------------------------------------------------------------
# Cross-TU Class Hierarchy Analysis (CHA) expansion
# ---------------------------------------------------------------------------

def _apply_cha_expansion(
    method: str,
    fstem: Optional[str],
    depth: int,
    index: Dict,
    visited: Set[Tuple[str, str]],
    queue: deque,
    parent_call_info: Dict,
    *,
    max_depth: int,
    max_nodes: int,
    current_count: int,
) -> int:
    """Enqueue cross-TU virtual dispatch candidates via Class Hierarchy Analysis.

    When a method ``BaseClass::foo`` is traversed, this function checks if any
    known subclass also defines ``foo`` and enqueues those as CHA candidates.
    Only subclasses with a definition in the function index are emitted; the
    definitions check naturally scopes results to in-KB files.

    The function does NOT add entries to *visited* — the main BFS loop does
    that when it dequeues and processes each candidate.

    Returns the number of CHA expansions enqueued (0 when no indexed subclass
    overrides exist).  The caller uses this count to annotate the current node
    with CHA coverage information (CPP-CPP Pattern B & G fix).
    """
    if "::" not in method or depth >= max_depth or current_count >= max_nodes:
        return 0
    class_name, method_name = method.split("::", 1)
    hierarchy = index.get("class_hierarchy") or {}
    base_to_derived: Dict[str, List[str]] = hierarchy.get("base_to_derived") or {}
    enqueued = 0
    for sub in base_to_derived.get(class_name, []):
        sc_fqn = f"{sub}::{method_name}"
        sc_defs = (index.get("definitions") or {}).get(sc_fqn) or []
        if not sc_defs:
            continue
        sc_fstem = sc_defs[0].get("file_stem")
        vk = (sc_fqn, sc_fstem or "")
        if vk not in visited:
            cha_info = {
                **parent_call_info,
                "call_type": "virtual_dispatch_cha",
                "instruction": "",
                "line": None,
                "file_path": sc_defs[0].get("file_path") or "",
            }
            # Reset/overwrite indirection envelope to mark this as CHA-expanded
            cha_info["indirection"] = {
                "is_virtual_dispatch": True,
                "cha_base_class": class_name,
            }
            queue.append((
                sc_fqn, sc_fstem, depth + 1, method, fstem, cha_info,
            ))
            enqueued += 1
    return enqueued


def _apply_cha_expansion_backward(
    method: str,
    fstem: Optional[str],
    depth: int,
    index: Dict,
    visited: Set[Tuple[str, str]],
    queue: deque,
    parent_call_info: Dict,
    *,
    max_depth: int,
    max_nodes: int,
    current_count: int,
) -> int:
    """Enqueue base-class methods for backward CHA expansion.

    When traversing backward from ``Derived::foo``, callers of
    ``Base::foo`` (via pointer/reference) may dispatch to ``Derived::foo``
    at runtime.  This function enqueues ``Base::foo`` so its callers are
    also included in the backward chain.

    Complements ``_apply_cha_expansion`` (forward direction, base→derived)
    by providing the reverse direction (derived→base).

    Returns the number of base-class expansions enqueued.
    """
    if "::" not in method or depth >= max_depth or current_count >= max_nodes:
        return 0
    class_name, method_name = method.split("::", 1)
    hierarchy = index.get("class_hierarchy") or {}
    base_to_derived: Dict[str, List[str]] = hierarchy.get("base_to_derived") or {}
    enqueued = 0
    # Find all base classes whose derived list includes our class
    for base, derived_list in base_to_derived.items():
        if class_name not in derived_list:
            continue
        base_fqn = f"{base}::{method_name}"
        base_defs = (index.get("definitions") or {}).get(base_fqn) or []
        if not base_defs:
            continue
        base_fstem = base_defs[0].get("file_stem")
        vk = (base_fqn, base_fstem or "")
        if vk not in visited:
            cha_info = {
                **parent_call_info,
                "call_type": "virtual_dispatch_cha",
                "instruction": "",
                "line": None,
                "file_path": base_defs[0].get("file_path") or "",
            }
            cha_info["indirection"] = {
                "is_virtual_dispatch": True,
                "cha_base_class": base,
            }
            queue.append((
                base_fqn, base_fstem, depth + 1, method, fstem, cha_info,
            ))
            enqueued += 1
    return enqueued


# ---------------------------------------------------------------------------
# Forward traversal
# ---------------------------------------------------------------------------

def traverse_forward(
    method_name: str,
    file_stem: str,
    max_depth: int,
    index: Dict[str, Any],
    blueprint_dir: str,
    *,
    include_external: bool = False,
    source_path: Optional[str] = None,
    max_nodes: int = 10_000,
    cross_lang: Optional[Dict[str, Any]] = None,
    include_indirect_calls: bool = True,
    expand_virtual_dispatch: bool = True,
) -> Tuple[List[Dict[str, Any]], List[str]]:
    """BFS forward: enumerate all transitive callees of *method_name*.

    Traverses both CPP and ASM/MAC nodes.  When *cross_lang* is provided
    (built by ``build_cross_lang_index``), language boundaries are crossed
    automatically — e.g. a CPP function that calls an ASM entry point will
    have the ASM routine and its transitive callees included in the result.

    Returns (nodes, warnings) where nodes are ordered by BFS discovery
    (breadth-first, root at depth 0).
    """
    warnings: List[str] = []
    nodes: List[Dict[str, Any]] = []
    # visited: set of (method_name, file_stem_or_empty)
    visited: Set[Tuple[str, str]] = set()

    _cl_file_types: Dict[str, str] = (cross_lang or {}).get("file_types", {})
    _cl_forward: Dict = (cross_lang or {}).get("forward", {})
    # Index-level file types (populated for all blueprints, not just cross-lang boundaries)
    _idx_file_types: Dict[str, str] = index.get("file_types") or {}

    # Queue entry:
    #   (method, fstem, depth, parent_method, parent_file, call_info)
    # call_info = {call_type, instruction, line, file_path}
    queue: deque = deque()
    queue.append((method_name, file_stem, 0, None, None, {}))

    while queue:
        method, fstem, depth, par_method, par_file, call_info = queue.popleft()

        vkey = (method, fstem or "")
        if vkey in visited:
            continue
        visited.add(vkey)

        # Determine language of this node (cpp / asm / mac / unknown).
        # Priority: cross-lang boundary map > full index file_types > default "cpp"
        language: str = (
            _cl_file_types.get(fstem) or _idx_file_types.get(fstem) or "cpp"
        ) if fstem else "cpp"

        # --- Resolve metadata ---
        defn = _resolve_def(method, fstem, index)
        # Fallback for ASM/MAC nodes not in the CPP-only index
        if not defn and fstem and language != "cpp":
            defn = _resolve_node_from_blueprint(method, fstem, blueprint_dir)

        file_path = defn.get("file_path") or call_info.get("file_path") or ""
        if not fstem and file_path:
            fstem = _file_stem(file_path) or fstem
        def_line: Optional[int] = defn.get("definition_line")
        is_external: bool = bool(defn.get("is_external", not bool(defn)))
        if defn and "is_external" not in defn:
            is_external = False

        # Source-file resolution and definition-line lookup (CPP only)
        resolved_fp: Optional[str] = None
        if language == "cpp":
            resolved_fp = _resolve_fp(file_path, source_path)
            if def_line is None and resolved_fp:
                try:
                    def_line = _find_def_line_in_source(method, resolved_fp)
                except Exception:
                    pass

        # Signature enrichment (CPP only — ASM routines have no C++ signatures)
        sig: Dict[str, Any] = {}
        if language == "cpp":
            sig = _get_params(method, resolved_fp or file_path, def_line, source_path)

        nodes.append(
            _make_node(
                method_name=method,
                file_stem=fstem,
                file_path=file_path,
                line_number=def_line,
                call_site_line=call_info.get("line") if call_info else None,
                depth=depth,
                call_type=call_info.get("call_type", "") if call_info else "",
                instruction=call_info.get("instruction", "") if call_info else "",
                is_external=is_external,
                parent_method=par_method,
                parent_file=par_file,
                return_type=sig.get("return_type", ""),
                parameters_raw=sig.get("parameters_raw", ""),
                parameters=sig.get("parameters", []),
                language=language,
                indirection=extract_indirection(call_info),
            )
        )

        if max_nodes and len(nodes) >= max_nodes:
            warnings.append(
                f"Result truncated at {max_nodes} nodes (max_nodes limit). "
                "Increase max_nodes or reduce max_depth to see more."
            )
            break

        if depth >= max_depth:
            continue

        # Indirect call nodes are leaf nodes — no BFS into FP variable names
        _ci_env = extract_indirection(call_info) if call_info else None
        if _ci_env and _ci_env.get("is_indirect"):
            continue

        # Cross-TU CHA expansion: enqueue known subclass implementations.
        # CPP-CPP Pattern B & G fix: annotate the current node with CHA
        # coverage information so consumers know whether the indexed set is
        # complete or may miss unanalyzed translation units.
        if expand_virtual_dispatch:
            _cha_count = _apply_cha_expansion(
                method=method,
                fstem=fstem,
                depth=depth,
                index=index,
                visited=visited,
                queue=queue,
                parent_call_info=call_info or {},
                max_depth=max_depth,
                max_nodes=max_nodes,
                current_count=len(nodes),
            )
            if "::" in method:
                # Annotate this node with how many indexed override(s) CHA found.
                # cha_indexed_impls = 0 means no overrides are in the corpus — the
                # method may still be overridden in unanalyzed TUs (Pattern B gap).
                # cha_indexed_impls > 0 means CHA found implementations but there
                # may be additional ones outside the KB (Pattern G, conservative).
                _current_node = nodes[-1]
                _current_node.setdefault("indirection", {})["cha_indexed_impls"] = _cha_count
                if _cha_count == 0:
                    _current_node["indirection"]["cha_coverage"] = "no_overrides_indexed"
                    _current_node["indirection"]["cha_note"] = (
                        "No subclass overrides found in the KB corpus. "
                        "Unanalyzed translation units may define additional "
                        "implementations (CPP-CPP Pattern B)."
                    )
                else:
                    _current_node["indirection"]["cha_coverage"] = "indexed_only"
                    _current_node["indirection"]["cha_note"] = (
                        f"CHA found {_cha_count} indexed override(s). "
                        "Implementations in unanalyzed TUs are not visible "
                        "(CPP-CPP Pattern G — static type / runtime dispatch)."
                    )

        # --- Load blueprint call graph ---
        bp_cg: Optional[Dict] = None
        if fstem:
            bp_cg = _load_cg(fstem, blueprint_dir)

        if bp_cg is None:
            if language == "cpp":
                # CPP source fallback: scan function body for call sites
                if resolved_fp and not is_external:
                    try:
                        from cpp_call_chain.source_scanner import scan_callees_in_function
                        src_callees = scan_callees_in_function(method, resolved_fp, def_line)
                        for sc in src_callees:
                            callee = sc["callee"]
                            vk = (callee, "")
                            if vk not in visited:
                                queue.append((
                                    callee, None, depth + 1, method, fstem,
                                    {"call_type": "call", "instruction": "CALL",
                                     "line": sc["call_line"], "file_path": ""},
                                ))
                    except Exception as exc:
                        logger.debug("Source callee scan failed for %s: %s", method, exc)
                elif not is_external and fstem:
                    warnings.append(
                        f"Blueprint not found for '{fstem}'; "
                        f"callees of '{method}' may be incomplete."
                    )
            # ASM blueprints missing → just warn, no source scan
            elif not is_external and fstem:
                warnings.append(
                    f"ASM blueprint not found for '{fstem}'; "
                    f"callees of '{method}' may be incomplete."
                )
        else:
            bp_nodes: Dict = bp_cg.get("nodes") or {}
            bp_edges: List[Dict] = bp_cg.get("edges") or []

            for edge in bp_edges:
                if not isinstance(edge, dict):
                    continue
                if edge.get("source") != method:
                    continue

                edge_is_indirect = bool(edge.get("is_indirect", False))
                edge_indirect_via = edge.get("register") or ""
                target: Optional[str] = edge.get("target")

                # Skip indirect edges when caller opted out
                if edge_is_indirect and not include_indirect_calls:
                    continue

                if not target:
                    # Unresolved indirect call (e.g. BALR R14,R15 with no known target)
                    if not edge_is_indirect:
                        continue
                    reg = edge.get("register") or "?"
                    instr = edge.get("instruction") or "indirect"
                    synthetic = f"(indirect via {reg})"
                    vk = (synthetic, "")
                    if vk not in visited:
                        visited.add(vk)  # leaf — prevent re-processing
                        nodes.append(_make_node(
                            method_name=synthetic,
                            file_stem=None,
                            file_path=None,
                            line_number=None,
                            call_site_line=edge.get("line"),
                            depth=depth + 1,
                            call_type=edge.get("call_type") or "subroutine_call",
                            instruction=instr,
                            is_external=False,
                            parent_method=method,
                            parent_file=fstem,
                            indirection=envelope_from_fields(is_indirect=True, indirect_via=reg),
                        ))
                    continue

                t_node = bp_nodes.get(target) or {}
                t_ext: bool = bool(t_node.get("is_external", True))
                t_fp: str = t_node.get("file") or ""
                t_fstem = _file_stem(t_fp)

                # Prune stdlib for non-indirect calls only
                if not edge_is_indirect and t_ext and not include_external and _is_stdlib(target):
                    continue

                vk = (target, t_fstem or "")
                if vk not in visited:
                    next_info: Dict[str, Any] = {
                        "call_type": edge.get("call_type") or "call",
                        "instruction": edge.get("instruction") or "",
                        "line": edge.get("line"),
                        "file_path": t_fp,
                    }
                    if edge_is_indirect:
                        next_info["indirection"] = envelope_from_fields(
                            is_indirect=True,
                            indirect_via=edge_indirect_via or target,
                        )
                    queue.append((
                        target, t_fstem, depth + 1, method, fstem, next_info,
                    ))

        # --- Cross-language callees (cpp→asm or asm→cpp) ---
        # The per-file blueprint only knows about same-language edges.
        # Language boundaries are captured in the cross_lang index derived
        # from file_call_graph.json call_sites.
        if fstem:
            for cl in _cl_forward.get((fstem, method), []):
                if cl.get("file_type") not in ("asm", "mac", "cpp"):
                    continue  # skip external/unknown targets
                vk = (cl["method"], cl["stem"] or "")
                if vk not in visited:
                    queue.append((
                        cl["method"],
                        cl["stem"],
                        depth + 1,
                        method,
                        fstem,
                        {
                            "call_type": cl["call_type"],
                            "instruction": cl["instruction"],
                            "line": cl["line"],
                            "file_path": "",
                        },
                    ))

    return nodes, warnings


# ---------------------------------------------------------------------------
# Backward traversal
# ---------------------------------------------------------------------------

def traverse_backward(
    method_name: str,
    file_stem: str,
    max_depth: int,
    index: Dict[str, Any],
    blueprint_dir: str,
    *,
    include_external: bool = False,
    source_path: Optional[str] = None,
    max_nodes: int = 10_000,
    cross_lang: Optional[Dict[str, Any]] = None,
    include_indirect_calls: bool = True,
    expand_virtual_dispatch: bool = True,
) -> Tuple[List[Dict[str, Any]], List[str]]:
    """BFS backward: enumerate all transitive callers of *method_name*.

    Uses the pre-built callers index for O(1) lookup per CPP hop.
    For ASM/MAC nodes, inverts the blueprint edges to find intra-file callers.
    When *cross_lang* is provided, also follows language boundaries in reverse —
    e.g. finding the ASM routine that called a CPP function, or the CPP function
    that called an ASM entry point.

    Falls back to source scanning when the CPP callers index has no entry.
    """
    warnings: List[str] = []
    nodes: List[Dict[str, Any]] = []
    visited: Set[Tuple[str, str]] = set()
    callers_idx: Dict[str, List[Dict]] = index.get("callers") or {}

    _cl_file_types: Dict[str, str] = (cross_lang or {}).get("file_types", {})
    _cl_backward: Dict = (cross_lang or {}).get("backward", {})
    # Index-level file types (populated for all blueprints, not just cross-lang boundaries)
    _idx_file_types: Dict[str, str] = index.get("file_types") or {}

    # Queue: (method, fstem, depth, child_method, child_file, call_info)
    queue: deque = deque()
    queue.append((method_name, file_stem, 0, None, None, {}))

    while queue:
        method, fstem, depth, child_method, child_file, call_info = queue.popleft()

        vkey = (method, fstem or "")
        if vkey in visited:
            continue
        visited.add(vkey)

        # Determine language of this node.
        # Priority: cross-lang boundary map > full index file_types > default "cpp"
        language: str = (
            _cl_file_types.get(fstem) or _idx_file_types.get(fstem) or "cpp"
        ) if fstem else "cpp"

        defn = _resolve_def(method, fstem, index)
        # Fallback for ASM/MAC nodes not in the CPP-only index
        if not defn and fstem and language != "cpp":
            defn = _resolve_node_from_blueprint(method, fstem, blueprint_dir)

        file_path = defn.get("file_path") or call_info.get("file_path") or ""
        if not fstem and file_path:
            fstem = _file_stem(file_path) or fstem
        def_line: Optional[int] = defn.get("definition_line")
        is_external: bool = bool(defn.get("is_external", not bool(defn)))
        if defn and "is_external" not in defn:
            is_external = False

        resolved_fp: Optional[str] = None
        if language == "cpp":
            resolved_fp = _resolve_fp(file_path, source_path)
            if def_line is None and resolved_fp:
                try:
                    def_line = _find_def_line_in_source(method, resolved_fp)
                except Exception:
                    pass

        sig: Dict[str, Any] = {}
        if language == "cpp":
            sig = _get_params(method, resolved_fp or file_path, def_line, source_path)

        nodes.append(
            _make_node(
                method_name=method,
                file_stem=fstem,
                file_path=file_path,
                line_number=def_line,
                # call_site_line = where the callee is called inside this function
                call_site_line=call_info.get("call_line") if call_info else None,
                depth=depth,
                call_type=call_info.get("call_type", "") if call_info else "",
                instruction=call_info.get("instruction", "") if call_info else "",
                is_external=is_external,
                parent_method=child_method,   # "parent" in backward = callee
                parent_file=child_file,
                return_type=sig.get("return_type", ""),
                parameters_raw=sig.get("parameters_raw", ""),
                parameters=sig.get("parameters", []),
                language=language,
                indirection=extract_indirection(call_info),
            )
        )

        if max_nodes and len(nodes) >= max_nodes:
            warnings.append(
                f"Result truncated at {max_nodes} nodes (max_nodes limit). "
                "Increase max_nodes or reduce max_depth to see more."
            )
            break

        if depth >= max_depth:
            continue

        # --- Look up CPP callers from the pre-built callers index ---
        index_callers: List[Dict] = list(callers_idx.get(method, []))

        # For ASM/MAC nodes: invert blueprint edges to find intra-file callers.
        # The CPP callers index has no ASM entries, so this is the only source
        # of intra-file ASM backward relationships.
        if language in ("asm", "mac") and fstem:
            bp_cg = _load_cg(fstem, blueprint_dir)
            if bp_cg:
                for e in (bp_cg.get("edges") or []):
                    if not isinstance(e, dict):
                        continue
                    if e.get("target") == method and e.get("source") != method:
                        caller_func = e.get("source")
                        if caller_func:
                            entry: Dict[str, Any] = {
                                "caller_func": caller_func,
                                "file_stem": fstem,
                                "file_path": file_path,
                                "call_line": e.get("line"),
                                "call_type": e.get("call_type", "call"),
                                "instruction": e.get("instruction", ""),
                            }
                            merge_indirection(entry, e)
                            index_callers.append(entry)

        # CPP source fallback when index has nothing and language is cpp
        if not index_callers and language == "cpp" and source_path:
            if depth == 0:
                # Only scan source for root to keep cost bounded
                try:
                    from cpp_call_chain.source_scanner import scan_callers_in_source
                    _src_file_count = sum(1 for _ in Path(source_path).rglob("*.cpp"))
                    if _src_file_count > _MAX_SOURCE_FALLBACK_FILES:
                        warnings.append(
                            f"Source fallback skipped: {_src_file_count} .cpp files "
                            f"exceed limit of {_MAX_SOURCE_FALLBACK_FILES}. "
                            "Use the function index for callers lookup."
                        )
                    else:
                        src_callers = scan_callers_in_source(method, source_path)
                        if src_callers:
                            index_callers = src_callers
                            warnings.append(
                                f"'{method}' not in callers index; used source scan "
                                f"({len(src_callers)} hit(s) found)."
                            )
                except Exception as exc:
                    logger.debug("Source caller scan failed for %s: %s", method, exc)
            else:
                warnings.append(
                    f"No callers found in index for '{method}' at depth {depth}; "
                    "chain may be incomplete."
                )

        for ci in index_callers:
            caller_func = ci.get("caller_func")
            if not caller_func:
                continue
            caller_fstem: Optional[str] = ci.get("file_stem")
            ci_env = extract_indirection(ci)
            ci_is_indirect = bool(ci_env and ci_env.get("is_indirect"))

            # Skip indirect callers when opted out
            if ci_is_indirect and not include_indirect_calls:
                continue

            if not include_external and _is_stdlib(caller_func):
                continue

            vk = (caller_func, caller_fstem or "")
            if vk not in visited:
                next_info: Dict[str, Any] = {
                    "call_type": ci.get("call_type") or "call",
                    "instruction": ci.get("instruction") or "",
                    "call_line": ci.get("call_line"),
                    "file_path": ci.get("file_path") or "",
                }
                if ci_env is not None:
                    next_info["indirection"] = ci_env
                queue.append((
                    caller_func, caller_fstem, depth + 1, method, fstem, next_info,
                ))

        # --- Backward CHA expansion: Derived::foo → also find callers of Base::foo ---
        # CPP-CPP Pattern B & G fix: annotate the current node with backward CHA
        # coverage (number of base-class envelopes found in the KB).
        if expand_virtual_dispatch:
            _cha_back_count = _apply_cha_expansion_backward(
                method=method,
                fstem=fstem,
                depth=depth,
                index=index,
                visited=visited,
                queue=queue,
                parent_call_info=call_info or {},
                max_depth=max_depth,
                max_nodes=max_nodes,
                current_count=len(nodes),
            )
            if "::" in method:
                _current_node = nodes[-1]
                _current_node.setdefault("indirection", {})["cha_base_impls"] = _cha_back_count
                if _cha_back_count == 0:
                    _current_node["indirection"].setdefault("cha_coverage", "no_base_indexed")
                    _current_node["indirection"]["cha_backward_note"] = (
                        "No base-class counterpart found in the KB corpus. "
                        "Callers dispatching through the base interface from "
                        "unanalyzed TUs may be invisible (CPP-CPP Pattern B)."
                    )

        # --- Cross-language callers (asm→cpp or cpp→asm) ---
        # The CPP callers index and ASM blueprint inversion only cover
        # same-language relationships.  Language boundaries are read from
        # the cross_lang index derived from file_call_graph.json call_sites.
        if fstem:
            for cl in _cl_backward.get((fstem, method), []):
                if cl.get("file_type") not in ("asm", "mac", "cpp"):
                    continue  # skip external/unknown callers
                caller_func = cl["method"]
                caller_fstem = cl["stem"]
                if not include_external and _is_stdlib(caller_func):
                    continue
                vk = (caller_func, caller_fstem or "")
                if vk not in visited:
                    queue.append((
                        caller_func,
                        caller_fstem,
                        depth + 1,
                        method,
                        fstem,
                        {
                            "call_type": cl["call_type"],
                            "instruction": cl["instruction"],
                            "call_line": cl["line"],
                            "file_path": "",
                        },
                    ))

    return nodes, warnings


# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------

def _resolve_fp(file_path: Optional[str], source_path: Optional[str]) -> Optional[str]:
    """Resolve a blueprint-recorded file path to an accessible file."""
    if not file_path:
        return None
    p = Path(file_path)
    if p.exists():
        return str(p)
    if source_path:
        try:
            from cpp_call_chain.source_scanner import _locate_source_file
            return _locate_source_file(p.name, source_path)
        except Exception:
            pass
    return None


def _find_def_line_in_source(func_name: str, file_path: str) -> Optional[int]:
    """Scan *file_path* to find the first definition line of *func_name*.

    Reads the file line-by-line and closes immediately.  Returns None if not
    found.
    """
    import re
    func_re = re.compile(
        rf'(?:^|[\s;}}])(?:(?:static|inline|virtual|explicit|constexpr|extern\s*(?:"C"\s*)?)\s+)*'
        rf'[\w:*&<>\s,\[\]]+?\b{re.escape(func_name)}\s*\(',
        re.MULTILINE,
    )
    try:
        with open(file_path, 'r', encoding='utf-8', errors='replace') as fh:
            for lineno, line in enumerate(fh, start=1):
                if func_name in line and func_re.search(line):
                    # Heuristic: check there's no keyword before the name
                    before = line[:line.index(func_name)].strip()
                    if not re.search(r'\b(?:if|for|while|switch|return|do)\s*$', before):
                        return lineno
    except OSError:
        pass
    return None
