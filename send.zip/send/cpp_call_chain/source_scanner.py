"""
Source-code scanner for C++ call chain resolution.

Provides two capabilities:

1. **Signature extraction** – given a function name and (optionally) its
   definition file + line, extract the return type and parameter list directly
   from the source file.  Files are opened, read, then immediately closed;
   only the extracted signature dict is retained in a per-process LRU cache
   so that large source files do not remain in memory.

2. **Callsite / caller scanning** – when blueprint data is absent, fall back
   to regex-based scanning of source files to find who calls a given function
   (backward) or what a given function calls (forward).

All source-file reads use a targeted line-window where possible (only the
lines around the function definition are read) to keep I/O minimal on large
codebases.
"""

from __future__ import annotations

import logging
import os
import re
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Signature extraction
# ---------------------------------------------------------------------------

# LRU signature cache: file_path → {func_name → sig_dict}
# Keeps at most _SIG_CACHE_FILES recent source files' parsed signatures.
_SIG_CACHE_MAX = 128
_sig_cache: OrderedDict[str, Dict[str, Dict]] = OrderedDict()

# Source-file search cache: stem → absolute_path (avoids repeated glob scans)
_SRC_PATH_CACHE: Dict[str, Optional[str]] = {}
_SRC_PATH_CACHE_MAX = 4096


def _clean_return_type(raw: str) -> str:
    """Strip leading storage-class qualifiers from a raw return type string."""
    for qual in (
        '[[nodiscard]]', 'extern "C"', 'extern', 'EXPORT',
        'inline', 'static', 'virtual', 'explicit', 'constexpr',
        'consteval', '__forceinline', '__inline',
    ):
        if raw.startswith(qual):
            raw = raw[len(qual):].lstrip()
    return raw.strip()


def _parse_param_list(params_raw: str) -> List[str]:
    """Split a raw C++ parameter string into a list of individual parameters.

    Handles nested angle-brackets (templates) and balanced parens.
    E.g. "int a, const std::vector<int, A<B>> &v" → ["int a", "const std::vector<int, A<B>> &v"]
    """
    if not params_raw or params_raw in ('void', ''):
        return []
    params: List[str] = []
    depth = 0
    buf: List[str] = []
    for ch in params_raw:
        if ch in '(<':
            depth += 1
            buf.append(ch)
        elif ch in ')>':
            depth -= 1
            buf.append(ch)
        elif ch == ',' and depth == 0:
            p = ''.join(buf).strip()
            if p:
                params.append(p)
            buf = []
        else:
            buf.append(ch)
    tail = ''.join(buf).strip()
    if tail:
        params.append(tail)
    return params


def _strip_line_comment(s: str) -> str:
    """Remove trailing // ... comment from a source line.

    Uses a simple scan that respects double-quoted string literals so that
    ``//`` inside a string literal is not mistaken for a comment start.
    """
    in_str = False
    i = 0
    while i < len(s):
        c = s[i]
        if c == '"' and (i == 0 or s[i - 1] != '\\'):
            in_str = not in_str
        if not in_str and c == '/' and i + 1 < len(s) and s[i + 1] == '/':
            return s[:i].rstrip()
        i += 1
    return s


def _extract_sig_from_window(
    lines: List[str],
    func_name: str,
    hint_line_1: int,           # 1-based
    window: int = 8,
) -> Dict[str, Any]:
    """Search in a ±window around hint_line_1 for the function definition.

    Handles two common patterns:

    Pattern A – name and ``(`` on the same line (possibly multi-line params)::

        void foo(int a,
                 int b)

    Pattern B – name alone on one line, ``(`` on the next (sometimes seen
    when the source has trailing revision comments)::

        int globalLimitsUpdate        //R003
               (const Foo* inputMsg,  //R003
                Foo** outputMsg)      //R003

    In both cases inline ``//`` comments are stripped before matching so that
    revision markers such as ``//R003`` do not pollute the extracted signature.

    Returns ``{'return_type': str, 'parameters_raw': str, 'parameters': list}``
    or ``{}`` on failure.
    """
    lo = max(0, hint_line_1 - window - 1)   # convert to 0-based
    hi = min(len(lines), hint_line_1 + window)

    func_with_paren_re = re.compile(rf'\b{re.escape(func_name)}\s*\(')
    func_name_re = re.compile(rf'\b{re.escape(func_name)}\s*$')  # name at end of (cleaned) line

    def _clean(raw: str) -> str:
        return _strip_line_comment(raw)

    def _build_full_sig(start_idx: int) -> str:
        """Concatenate cleaned lines starting at start_idx until parens balance."""
        parts: List[str] = []
        depth = 0
        for k in range(start_idx, min(len(lines), start_idx + 15)):
            cl = _clean(lines[k]).strip()
            parts.append(cl)
            depth += cl.count('(') - cl.count(')')
            if depth <= 0 and k > start_idx:
                break
        return ' '.join(parts)

    for i in range(lo, hi):
        raw = lines[i]
        stripped_raw = raw.lstrip()
        # Skip pure comment / preprocessor lines (use original line)
        if (stripped_raw.startswith('//')
                or stripped_raw.startswith('*')
                or stripped_raw.startswith('#')):
            continue

        line = _clean(raw)  # strip inline comment for matching

        # ── Pattern A: func_name( on same line ──────────────────────────────
        if func_with_paren_re.search(line):
            m_pos = func_with_paren_re.search(line).start()
            before = line[:m_pos].strip()
            if not before or re.search(r'[{=]', before):
                continue
            if re.search(r'\b(?:if|for|while|switch|return|do)\s*$', before):
                continue
            if before.lstrip().startswith('//') or before.lstrip().startswith('*'):
                continue
            full_sig = _build_full_sig(i)

        # ── Pattern B: func_name at end of line, ( on subsequent line ───────
        elif func_name_re.search(line.rstrip()):
            m_pos = func_name_re.search(line.rstrip()).start()
            before = line[:m_pos].strip()
            if not before or re.search(r'[{=;]', before):
                continue
            if re.search(r'\b(?:if|for|while|switch|return|do)\b', before):
                continue
            full_sig = _build_full_sig(i)

        else:
            continue

        # ── Extract return type + params from the assembled signature ────────
        m2 = re.match(
            rf'^(.*?)\b{re.escape(func_name)}\s*\(([^)]*)\)',
            full_sig.strip(),
        )
        if not m2:
            continue

        ret_raw = _clean_return_type(m2.group(1))
        params_raw = m2.group(2).strip()
        return {
            'return_type': ret_raw,
            'parameters_raw': params_raw,
            'parameters': _parse_param_list(params_raw),
        }
    return {}


def get_signature(
    func_name: str,
    file_path: Optional[str],
    hint_line: Optional[int] = None,
    source_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Return the function signature extracted from source.

    Strategy:
    1. Check in-process LRU cache (zero I/O).
    2. Try to open *file_path* directly (blueprint-recorded absolute path).
    3. If *file_path* is not reachable and *source_path* is given, locate the
       file by stem under *source_path* using a cached glob.
    4. Read only the lines near *hint_line* (avoids loading entire large file).

    Returns a dict with keys:
        ``return_type``      – e.g. ``"void"``
        ``parameters_raw``   – raw parameter string e.g. ``"char *linkSourceCode"``
        ``parameters``       – list of individual parameter strings
    or ``{}`` when the signature cannot be determined.
    """
    # 1. Cache lookup
    cache_key = str(file_path or '') + ':' + func_name
    resolved_path: Optional[str] = None

    for fp_key in (cache_key,):
        if fp_key in _sig_cache:
            entry = _sig_cache.get(fp_key) or {}
            hit = entry.get(func_name)
            if hit is not None:
                _sig_cache.move_to_end(fp_key)
                return hit

    # 2. Resolve the source file on disk
    if file_path:
        p = Path(file_path)
        if p.exists():
            resolved_path = str(p)
        elif source_path:
            resolved_path = _locate_source_file(p.name, source_path)

    if not resolved_path and source_path:
        # Stem-based search (no file_path hint)
        stem_guess = _file_stem(func_name)  # not useful, but try
        # Try to find any file whose name matches what we can guess
        pass  # will fall through to {} below

    if not resolved_path:
        return {}

    # 3. Read a line window then search within it.
    #    _read_lines_window returns lines[0..N] where lines[0] corresponds to
    #    file line `start = max(1, hint_line - extra_before)`.  We convert the
    #    absolute hint_line to a 1-based index within the returned slice before
    #    passing it to _extract_sig_from_window.
    extra_before = 20
    extra_after = 40
    try:
        file_start = max(1, (hint_line or 1) - extra_before)
        lines = _read_lines_window(
            resolved_path,
            hint_line or 1,
            extra_before=extra_before,
            extra_after=extra_after,
        )
        # Relative hint: 1-based position of hint_line within the returned window
        rel_hint = (hint_line or 1) - file_start + 1 if hint_line else len(lines) // 2 + 1
        sig = _extract_sig_from_window(lines, func_name, rel_hint, window=max(rel_hint + 5, 15))
    except OSError as exc:
        logger.debug("Cannot read %s: %s", resolved_path, exc)
        return {}

    # 4. Cache and return
    _update_sig_cache(cache_key, func_name, sig)
    return sig


def _read_lines_window(
    file_path: str,
    center_line_1: int,
    extra_before: int = 20,
    extra_after: int = 40,
) -> List[str]:
    """Read a range of lines from a file without loading the whole file into RAM.

    For large source files (>100 K lines) this saves significant memory.
    Returns all collected lines (1-indexed subset of the file).
    """
    start = max(1, center_line_1 - extra_before)
    end = center_line_1 + extra_after
    collected: List[str] = []
    with open(file_path, 'r', encoding='utf-8', errors='replace') as fh:
        for lineno, line in enumerate(fh, start=1):
            if lineno < start:
                continue
            if lineno > end:
                break
            collected.append(line.rstrip('\n'))
    # Adjust hint_line for the collected window (make it relative)
    return collected


def _locate_source_file(filename: str, source_path: str) -> Optional[str]:
    """Find *filename* somewhere under *source_path*, using a glob cache."""
    cache_key = source_path + '::' + filename
    if cache_key in _SRC_PATH_CACHE:
        return _SRC_PATH_CACHE[cache_key]

    result: Optional[str] = None
    try:
        for p in Path(source_path).rglob(filename):
            if p.is_file():
                result = str(p)
                break
    except OSError:
        pass

    _SRC_PATH_CACHE[cache_key] = result
    if len(_SRC_PATH_CACHE) > _SRC_PATH_CACHE_MAX:
        # Evict oldest quarter
        for k in list(_SRC_PATH_CACHE)[: _SRC_PATH_CACHE_MAX // 4]:
            del _SRC_PATH_CACHE[k]
    return result


def _update_sig_cache(file_key: str, func_name: str, sig: Dict) -> None:
    global _sig_cache
    if file_key not in _sig_cache:
        _sig_cache[file_key] = {}
    _sig_cache[file_key][func_name] = sig
    _sig_cache.move_to_end(file_key)
    if len(_sig_cache) > _SIG_CACHE_MAX:
        _sig_cache.popitem(last=False)


def _file_stem(name: str) -> str:
    p = Path(name)
    for ext in ('.cpp', '.hpp', '.h', '.cc', '.cxx', '.c'):
        if p.name.endswith(ext):
            return p.name[:-len(ext)]
    return p.stem


# ---------------------------------------------------------------------------
# Forward callsite scanning (source fallback)
# ---------------------------------------------------------------------------

# Tokens that are control-flow keywords – never function calls
_CF_KEYWORDS = frozenset([
    'if', 'for', 'while', 'switch', 'return', 'do', 'catch',
    'sizeof', 'typeof', 'alignof', 'static_assert',
])

_CALL_TOKEN_RE = re.compile(r'\b([A-Za-z_][A-Za-z0-9_:~]*)\s*\(')


def scan_callees_in_function(
    func_name: str,
    file_path: str,
    def_line: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """Return list of {callee, call_line} found inside *func_name*'s body.

    Uses brace-counting to isolate the function body.  Opens and closes the
    file within this call.
    """
    try:
        with open(file_path, 'r', encoding='utf-8', errors='replace') as fh:
            lines = fh.readlines()
    except OSError:
        return []

    # Find function body start
    func_re = re.compile(rf'\b{re.escape(func_name)}\s*\(')
    body_start: Optional[int] = None
    brace_depth = 0
    in_sig = False

    search_lo = max(0, (def_line or 1) - 10) if def_line else 0

    for i in range(search_lo, len(lines)):
        line = lines[i]
        if not in_sig:
            if func_re.search(line):
                before = line[:func_re.search(line).start()].strip()
                # Skip if inside control-flow
                if not re.search(r'\b(?:if|for|while|switch|return|do)\s*$', before):
                    in_sig = True
                    brace_depth = 0
        if in_sig:
            brace_depth += line.count('{') - line.count('}')
            if '{' in line and body_start is None:
                body_start = i + 1
            if body_start is not None and brace_depth <= 0:
                break  # end of function

    if body_start is None:
        return []

    # Scan body for call sites
    results: List[Dict[str, Any]] = []
    for i in range(body_start, min(len(lines), i + 1)):
        line = lines[i]
        # Skip comment lines
        stripped = line.lstrip()
        if stripped.startswith('//') or stripped.startswith('*'):
            continue
        for m in _CALL_TOKEN_RE.finditer(line):
            callee = m.group(1)
            if callee in _CF_KEYWORDS:
                continue
            if callee == func_name:
                continue  # self-call handled separately
            results.append({'callee': callee, 'call_line': i + 1})

    # Free lines from memory
    del lines
    return results


# ---------------------------------------------------------------------------
# Backward caller scanning (source fallback for missing index entries)
# ---------------------------------------------------------------------------

def scan_callers_in_source(
    func_name: str,
    source_path: str,
    extensions: Tuple[str, ...] = ('.cpp', '.cc', '.cxx', '.c', '.hpp', '.h'),
) -> List[Dict[str, Any]]:
    """Grep all source files under *source_path* for calls to *func_name*.

    This is intentionally a last-resort: opens each file, scans for the
    call pattern, then closes immediately.  Memory stays flat.

    Returns list of {caller_func, file_stem, file_path, call_line, call_type}.
    """
    results: List[Dict[str, Any]] = []
    call_re = re.compile(rf'\b{re.escape(func_name)}\s*\(')
    enclosing_re = re.compile(
        r'^(?:(?:static|inline|virtual|explicit|constexpr|extern\s*(?:"C"\s*)?|\[\[nodiscard\]\])\s*)*'
        r'(?:[\w:*&<>\s,\[\]]+?)\s+([A-Za-z_][A-Za-z0-9_:~]*)\s*\([^;{#]*\)\s*'
        r'(?:const\s*)?(?:noexcept\s*)?(?:override\s*)?\{',
        re.MULTILINE,
    )

    sp = Path(source_path)
    for ext in extensions:
        for src in sp.rglob(f'*{ext}'):
            try:
                with open(src, 'r', encoding='utf-8', errors='replace') as fh:
                    text = fh.read()
            except OSError:
                continue

            if func_name not in text:
                continue  # fast-path: no mention at all

            # Find enclosing function for each call site
            # Build a map: line_number -> enclosing_function
            # (Use line_metadata-style approach from blueprint)
            func_ranges: List[Tuple[int, int, str]] = []  # (start, end, name)
            for m in enclosing_re.finditer(text):
                fn = m.group(1)
                if fn in _CF_KEYWORDS:
                    continue
                start_line = text[:m.start()].count('\n') + 1
                # Find closing brace by brace counting
                depth = 1
                pos = text.index('{', m.start())
                end_pos = pos + 1
                while depth > 0 and end_pos < len(text):
                    if text[end_pos] == '{':
                        depth += 1
                    elif text[end_pos] == '}':
                        depth -= 1
                    end_pos += 1
                end_line = text[:end_pos].count('\n') + 1
                func_ranges.append((start_line, end_line, fn))

            lines = text.splitlines()
            for lineno, line in enumerate(lines, start=1):
                if not call_re.search(line):
                    continue
                # Find enclosing function
                enclosing = '<module>'
                for (s, e, fn) in func_ranges:
                    if s <= lineno <= e:
                        enclosing = fn
                        break
                results.append({
                    'caller_func': enclosing,
                    'file_stem': _file_stem(str(src)),
                    'file_path': str(src),
                    'call_line': lineno,
                    'call_type': 'call',
                    'source': 'source_scan',
                })

            del text, lines, func_ranges
    return results


# ---------------------------------------------------------------------------
# Source file resolution helper (public)
# ---------------------------------------------------------------------------

def resolve_source_file(
    file_path: Optional[str],
    source_path: Optional[str],
) -> Optional[str]:
    """Resolve an absolute blueprint-recorded path to an accessible path.

    Tries the recorded path first, then searches *source_path* by filename.
    Returns None if the file cannot be found.
    """
    if file_path:
        p = Path(file_path)
        if p.exists():
            return str(p)
        if source_path:
            found = _locate_source_file(p.name, source_path)
            if found:
                return found
    return None
