"""C++ call chain traversal package."""
