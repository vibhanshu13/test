"""
C++ function call chain index builder.

Builds and caches a two-part index over all *.cpp.json blueprints:

  definitions[func_name] = [
      {file_stem, file_path, definition_line, kind}, ...
  ]
  callers[func_name] = [
      {caller_func, file_stem, file_path, call_line, call_type}, ...
  ]

Blueprint decoding
------------------
All blueprint reads go through ``blueprint_io.load_blueprint()`` with
``keys={"call_graph", "line_metadata"}`` and ``skip_global_lineage=True``.
This loads only the two sections needed for the index, immediately freeing
the rest of the parsed data via Python reference counting.  The underlying
format is auto-detected: zstd+msgpack (primary), gzip+msgpack (fallback),
or plain JSON.  File handles are closed as soon as bytes are read.

Large-index I/O
---------------
The index is written to disk as **zstd-compressed msgpack** using streaming
serialisation so that neither the full uncompressed buffer nor the full
compressed buffer must be held in RAM simultaneously.

On read the index is decompressed via a streaming zstd reader piped into
msgpack, then cached in process memory (one copy per KB per process).

Parallel build
--------------
Blueprint loading is I/O-bound.  A ``ThreadPoolExecutor`` with a bounded
worker count loads blueprints in parallel while keeping peak heap usage
predictable: with ``keys`` filtering, the retained data per blueprint is
~6 KB, so 16 concurrent workers use only ~96 KB of live data simultaneously
even though each individual decode temporarily allocates up to 80 MB.

Staleness detection
-------------------
The on-disk index records the wall-clock time it was built.  On load, the
newest blueprint mtime is compared against that timestamp; any newer
blueprint triggers a transparent rebuild.
"""

from __future__ import annotations

import gc
import itertools
import json
import logging
import os
import tempfile
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_INDEX_FILENAME = "cpp_function_index.msgpack.zst"

# Per-process memory cache: blueprint_dir_str -> (load_time_float, index_dict)
_index_mem_cache: OrderedDict[str, Tuple[float, Dict]] = OrderedDict()
_INDEX_CACHE_MAX = 8  # simultaneous KBs in memory

# Cross-language index cache: graph_path_str -> (mtime_float, index_dict)
_cross_lang_mem_cache: Dict[str, Tuple[float, Dict]] = {}


# ---------------------------------------------------------------------------
# Blueprint-level helpers
# ---------------------------------------------------------------------------

def _load_bp_minimal(bp_path: Path) -> Optional[Dict[str, Any]]:
    """Load call_graph, line_metadata, and class_bases from one blueprint.

    Uses ``blueprint_io`` for transparent zstd/gzip/msgpack/JSON decoding.
    The file is opened, read, and closed inside ``load_blueprint``; this
    function adds no additional file-handle lifetime.

    Returns the pruned blueprint dict, or None on any error.
    """
    try:
        from blueprint_io import load_blueprint  # type: ignore[import]
        return load_blueprint(
            bp_path,
            keys={"call_graph", "line_metadata", "class_bases"},
            skip_global_lineage=True,
        )
    except Exception as exc:
        logger.debug("Cannot load blueprint %s: %s", bp_path.name, exc)
        return None


def _file_stem_from_path(file_path: Optional[str]) -> Optional[str]:
    if not file_path:
        return None
    name = Path(file_path).name
    for ext in (".cpp", ".hpp", ".h", ".cc", ".cxx", ".c"):
        if name.endswith(ext):
            return name[: -len(ext)]
    return Path(file_path).stem


def _extract_func_start_lines(line_metadata: Dict) -> Dict[str, int]:
    """Return {func_name: first_line} from blueprint line_metadata."""
    starts: Dict[str, int] = {}
    if not isinstance(line_metadata, dict):
        return starts
    for lineno_str, meta in line_metadata.items():
        if not isinstance(meta, dict):
            continue
        enc = meta.get("codeblock", {})
        fn = enc.get("enclosing_function") if isinstance(enc, dict) else None
        if fn and fn not in starts:
            try:
                starts[fn] = int(lineno_str)
            except (ValueError, TypeError):
                pass
    return starts


# ---------------------------------------------------------------------------
# Per-blueprint processing
# ---------------------------------------------------------------------------

def _process_blueprint(
    bp_path: Path,
) -> Optional[Tuple[str, List[Dict], List[Dict], Dict]]:
    """Extract definition, caller entries, and class_bases from one blueprint.

    Returns ``(file_stem, def_entries, caller_entries, class_bases)`` or None
    on error.

    def_entry    = {func_name, file_stem, file_path, definition_line, kind}
    caller_entry = {callee, caller_func, file_stem, file_path, call_line,
                    call_type, instruction, is_indirect, indirect_via}
    class_bases  = {DerivedClass: [BaseClass, ...]}
    """
    bp = _load_bp_minimal(bp_path)
    if not bp:
        return None

    # Derive file_stem from blueprint filename:  dx710000.cpp.json → dx710000
    name = bp_path.name
    if name.endswith(".cpp.json"):
        file_stem = name[: -len(".cpp.json")]
    elif name.endswith(".asm.json"):
        file_stem = name[: -len(".asm.json")]
    else:
        file_stem = bp_path.stem

    cg: Dict = bp.get("call_graph") or {}
    lm: Dict = bp.get("line_metadata") or {}
    nodes: Dict = cg.get("nodes") or {}
    edges: List[Dict] = cg.get("edges") or []
    func_starts = _extract_func_start_lines(lm)

    def_entries: List[Dict] = []
    caller_entries: List[Dict] = []

    # --- definitions ---
    for func_name, node in nodes.items():
        if not isinstance(node, dict):
            continue
        node_file: Optional[str] = node.get("file")
        node_ext: bool = bool(node.get("is_external", True))
        # Only index functions that have a known source file (local or cross-file)
        if not node_file:
            continue
        stem = _file_stem_from_path(node_file) or file_stem
        def_entries.append({
            "func_name": func_name,
            "file_stem": stem,
            "file_path": node_file,
            "definition_line": func_starts.get(func_name),
            "kind": node.get("kind") or "function",
            "is_external": node_ext,
        })

    # --- caller relationships (from every edge in this blueprint) ---
    for edge in edges:
        if not isinstance(edge, dict):
            continue
        source: Optional[str] = edge.get("source")
        target: Optional[str] = edge.get("target")
        if not source or not target:
            continue
        edge_file: Optional[str] = edge.get("file")
        edge_stem = _file_stem_from_path(edge_file) or file_stem
        entry = {
            "callee": target,
            "caller_func": source,
            "file_stem": edge_stem,
            "file_path": edge_file or "",
            "call_line": edge.get("line"),
            "call_type": edge.get("call_type") or "call",
            "instruction": edge.get("instruction") or "",
        }
        # Carry indirect-call envelope (is_indirect/indirect_via/register/etc.)
        # opaquely so future Phase-2 producer fields flow through without code change.
        from api.utils.indirection import merge_indirection  # local import to avoid cycle
        merge_indirection(entry, edge)
        caller_entries.append(entry)

    # Collect class inheritance map for cross-TU CHA
    class_bases: Dict[str, List] = dict(bp.get("class_bases") or {})

    # Explicitly release large objects before returning
    del bp, cg, lm, nodes, edges, func_starts
    return file_stem, def_entries, caller_entries, class_bases


# ---------------------------------------------------------------------------
# Index assembly
# ---------------------------------------------------------------------------

def _build_index(blueprint_dir: Path, max_workers: int = 16) -> Dict[str, Any]:
    """Scan all *.cpp.json / *.asm.json / *.mac.json blueprints and assemble
    the function index.

    Worker count is intentionally conservative (default 8) to keep the
    concurrent peak heap under control: each worker decode temporarily
    allocates ~80 MB; at 8 workers that is ~640 MB peak heap before
    key-filtering drops it to ~6 KB retained.
    """
    all_bps = sorted(
        list(blueprint_dir.glob("*.cpp.json")) +
        list(blueprint_dir.glob("*.asm.json")) +
        list(blueprint_dir.glob("*.mac.json"))
    )
    logger.info(
        "cpp_call_chain: building index from %d blueprints in %s",
        len(all_bps),
        blueprint_dir,
    )
    t0 = time.monotonic()

    definitions: Dict[str, List[Dict]] = {}
    def_seen: Dict[str, set] = {}  # func_name → set of (file_stem, file_path)
    callers: Dict[str, List[Dict]] = {}
    # base_to_derived: base class → list of subclass names (cross-TU CHA)
    base_to_derived: Dict[str, List[str]] = {}
    # file_types: file_stem → "cpp" | "asm" | "mac"
    file_types: Dict[str, str] = {}

    workers = min(max_workers, max(1, len(all_bps)))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_process_blueprint, bp): bp for bp in all_bps}
        for future in as_completed(futures):
            try:
                result = future.result()
            except Exception as exc:
                logger.warning("Index build error on %s: %s", futures[future], exc)
                continue
            if result is None:
                continue
            file_stem_result, def_entries, caller_entries, class_bases = result

            # Record file language from blueprint suffix
            bp_path = futures[future]
            if bp_path.name.endswith(".asm.json"):
                file_types[file_stem_result] = "asm"
            elif bp_path.name.endswith(".mac.json"):
                file_types[file_stem_result] = "mac"
            else:
                file_types[file_stem_result] = "cpp"

            for entry in def_entries:
                fn = entry["func_name"]
                bucket = definitions.setdefault(fn, [])
                key = (entry["file_stem"], entry["file_path"])
                key_set = def_seen.setdefault(fn, set())
                if key not in key_set:
                    key_set.add(key)
                    bucket.append({
                        "file_stem": entry["file_stem"],
                        "file_path": entry["file_path"],
                        "definition_line": entry["definition_line"],
                        "kind": entry["kind"],
                        "is_external": entry["is_external"],
                    })

            for entry in caller_entries:
                callee = entry["callee"]
                out: Dict[str, Any] = {
                    "caller_func": entry["caller_func"],
                    "file_stem": entry["file_stem"],
                    "file_path": entry["file_path"],
                    "call_line": entry["call_line"],
                    "call_type": entry["call_type"],
                    "instruction": entry["instruction"],
                }
                if entry.get("indirection"):
                    out["indirection"] = dict(entry["indirection"])
                callers.setdefault(callee, []).append(out)

            # Accumulate class hierarchy (derived → [base]) into inverse map
            for derived, bases in (class_bases or {}).items():
                for base in (bases or []):
                    if base and derived not in base_to_derived.get(base, []):
                        base_to_derived.setdefault(base, []).append(derived)

    # Prompt GC to reclaim anything left from the parallel loads
    gc.collect()

    elapsed = time.monotonic() - t0
    logger.info(
        "cpp_call_chain index: %d definitions, %d callee entries, %d base classes, "
        "%d file stems (%d cpp / %d asm / %d mac) in %.1fs",
        len(definitions),
        len(callers),
        len(base_to_derived),
        len(file_types),
        sum(1 for v in file_types.values() if v == "cpp"),
        sum(1 for v in file_types.values() if v == "asm"),
        sum(1 for v in file_types.values() if v == "mac"),
        elapsed,
    )
    return {
        "generated_at": time.time(),
        # v4: callers entries carry an opaque `indirection` envelope instead of
        # individual is_indirect / indirect_via fields.
        "schema_version": 4,
        "blueprint_count": len(all_bps),
        "definitions": definitions,
        "callers": callers,
        "class_hierarchy": {"base_to_derived": base_to_derived},
        "file_types": file_types,
    }


# ---------------------------------------------------------------------------
# Streaming I/O
# ---------------------------------------------------------------------------

def _write_index(index: Dict[str, Any], path: Path) -> None:
    """Write the index as zstd-compressed msgpack using streaming serialisation.

    Streams msgpack bytes directly into the zstd compressor so that neither
    the full uncompressed buffer nor the full compressed buffer needs to be
    held in RAM simultaneously.

    Uses an atomic write (temp file → rename) to prevent partial reads if the
    process dies during the write.
    """
    import msgpack  # type: ignore[import]

    tmp_fd, tmp_path = tempfile.mkstemp(
        dir=path.parent, prefix=".tmp_cpp_idx_", suffix=".msgpack.zst"
    )
    try:
        with os.fdopen(tmp_fd, 'wb') as f_out:
            try:
                import zstandard  # type: ignore[import]
                cctx = zstandard.ZstdCompressor(level=3, write_content_size=True)
                with cctx.stream_writer(f_out, closefd=False) as compressor:
                    msgpack.pack(index, compressor, use_bin_type=True)
            except ImportError:
                import gzip
                with gzip.GzipFile(fileobj=f_out, mode='wb', compresslevel=6) as gz:
                    msgpack.pack(index, gz, use_bin_type=True)
        os.replace(tmp_path, path)
        logger.info("cpp_call_chain: saved index (%d B) to %s", path.stat().st_size, path)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def _read_index(path: Path) -> Dict[str, Any]:
    """Read the index from disk using streaming decompression.

    Decompresses via a streaming zstd reader piped into msgpack.Unpacker to
    avoid materialising the full uncompressed blob before starting the parse.
    Falls back to gzip and plain msgpack/JSON auto-detection.
    """
    import msgpack  # type: ignore[import]

    _ZSTD_MAGIC = b"\x28\xb5\x2f\xfd"
    _GZIP_MAGIC = b"\x1f\x8b"

    with open(path, 'rb') as fh:
        magic = fh.read(4)
        fh.seek(0)

        if magic[:4] == _ZSTD_MAGIC:
            try:
                import zstandard  # type: ignore[import]
                dctx = zstandard.ZstdDecompressor()
                with dctx.stream_reader(fh, closefd=False) as reader:
                    unpacker = msgpack.Unpacker(reader, raw=False, strict_map_key=False)
                    return unpacker.unpack()
            except ImportError:
                raise RuntimeError(
                    "Index file is zstd-compressed but zstandard is not installed. "
                    "Run: pip install zstandard"
                )
        elif magic[:2] == _GZIP_MAGIC:
            import gzip
            with gzip.GzipFile(fileobj=fh) as gz:
                unpacker = msgpack.Unpacker(gz, raw=False, strict_map_key=False)
                return unpacker.unpack()
        else:
            # Plain msgpack or JSON
            raw = fh.read()
            if raw and raw[0] == ord('{'):
                import json
                return json.loads(raw.decode('utf-8'))
            return msgpack.unpackb(raw, raw=False, strict_map_key=False)


# ---------------------------------------------------------------------------
# Staleness check
# ---------------------------------------------------------------------------

_STALE_CHECK_TTL = 300  # seconds – skip glob stat if index is fresher than this


def _is_stale(index: Dict, blueprint_dir: Path) -> bool:
    """True if any blueprint is newer than the saved index timestamp."""
    generated_at: float = index.get("generated_at") or 0.0
    # Short-circuit: if the index was built less than TTL seconds ago, treat it
    # as fresh without globbing all blueprint files (saves ~500 ms at 50K files).
    if time.time() - generated_at < _STALE_CHECK_TTL:
        return False
    try:
        latest = max(
            itertools.chain(
                (p.stat().st_mtime for p in blueprint_dir.glob("*.cpp.json")),
                (p.stat().st_mtime for p in blueprint_dir.glob("*.asm.json")),
                (p.stat().st_mtime for p in blueprint_dir.glob("*.mac.json")),
            ),
            default=0.0,
        )
        return latest > generated_at
    except OSError:
        return True


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_index(
    blueprint_dir: Path,
    force_rebuild: bool = False,
    max_workers: int = 16,
) -> Dict[str, Any]:
    """Return the function index for *blueprint_dir*.

    Load priority:
    1. In-memory LRU cache  (zero I/O)
    2. On-disk zstd+msgpack cache  (streaming decompress into msgpack)
    3. Full rebuild from blueprints  (parallel, one-time cost)
    """
    global _index_mem_cache

    mem_key = str(blueprint_dir)
    index_path = blueprint_dir / _INDEX_FILENAME

    # 1. Memory cache
    if not force_rebuild and mem_key in _index_mem_cache:
        _, cached = _index_mem_cache[mem_key]
        if not _is_stale(cached, blueprint_dir):
            _index_mem_cache.move_to_end(mem_key)
            return cached

    # 2. Disk cache
    if not force_rebuild and index_path.exists():
        try:
            index = _read_index(index_path)
            if not _is_stale(index, blueprint_dir) and index.get("schema_version", 1) >= 4:
                _put_mem_cache(mem_key, index)
                return index
            if index.get("schema_version", 1) < 4:
                logger.info("cpp_call_chain: disk index has old schema (v%s), rebuilding to v4",
                            index.get("schema_version", 1))
            else:
                logger.info("cpp_call_chain: disk index stale, rebuilding")
        except Exception as exc:
            logger.warning("Cannot read disk index (%s) — rebuilding: %s", index_path, exc)

    # 3. Full rebuild
    index = _build_index(blueprint_dir, max_workers=max_workers)

    try:
        _write_index(index, index_path)
    except Exception as exc:
        logger.warning("Cannot save index to %s: %s", index_path, exc)

    _put_mem_cache(mem_key, index)
    return index


def _put_mem_cache(key: str, index: Dict) -> None:
    global _index_mem_cache
    _index_mem_cache[key] = (time.time(), index)
    _index_mem_cache.move_to_end(key)
    if len(_index_mem_cache) > _INDEX_CACHE_MAX:
        _index_mem_cache.popitem(last=False)


def invalidate_cache(blueprint_dir: Path) -> None:
    """Evict both in-memory and on-disk cache for *blueprint_dir*."""
    _index_mem_cache.pop(str(blueprint_dir), None)
    idx = blueprint_dir / _INDEX_FILENAME
    if idx.exists():
        try:
            idx.unlink()
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Cross-language index (cpp ↔ asm boundaries from file_call_graph.json)
# ---------------------------------------------------------------------------

_CROSS_LANG_FILENAME = "cpp_cross_lang_index.msgpack.zst"


def build_cross_lang_index(graph_path: Path) -> Dict[str, Any]:
    """Build a cross-language call boundary index from file_call_graph.json.

    Reads the file-level call graph and extracts every call_site that crosses
    a language boundary (cpp→asm or asm→cpp).  Each call_site carries the
    exact function-level source (source_block) and target (target_module),
    which is what the BFS traversal needs to hop across language boundaries.

    Persistence strategy (same as the function index):
    1. In-memory cache  — zero I/O after first load per process.
    2. Disk cache (msgpack.zst alongside file_call_graph.json)  — avoids
       re-parsing the 100+ MB graph file on every process restart.  The disk
       file is rebuilt transparently whenever the graph file is newer.
    3. Full parse of file_call_graph.json  — one-time cost; extracts only the
       6 K cross-language entries and immediately frees the full payload.

    Returns:
        {
            "forward":    {(src_stem, src_method): [entry, ...]},
            "backward":   {(tgt_stem, tgt_method): [entry, ...]},
            "file_types": {stem: "cpp" | "asm" | "mac" | "unknown"},
        }
    Each entry: {stem, method, call_type, instruction, line, file_type}
    """
    global _cross_lang_mem_cache

    mem_key = str(graph_path)
    disk_path = graph_path.parent / _CROSS_LANG_FILENAME

    # --- 1. Memory cache ---
    if mem_key in _cross_lang_mem_cache:
        cached_mtime, cached = _cross_lang_mem_cache[mem_key]
        try:
            if graph_path.stat().st_mtime <= cached_mtime:
                return cached
        except OSError:
            return cached

    # --- 2. Disk cache ---
    try:
        graph_mtime = graph_path.stat().st_mtime
    except OSError:
        graph_mtime = 0.0

    if disk_path.exists():
        try:
            disk_index = _read_index(disk_path)
            if disk_index.get("graph_mtime", 0.0) >= graph_mtime:
                result = _deserialise_cross_lang(disk_index)
                _cross_lang_mem_cache[mem_key] = (graph_mtime, result)
                return result
            logger.info("cross_lang_index: disk cache stale, rebuilding")
        except Exception as exc:
            logger.warning("Cannot read cross-lang disk cache (%s): %s", disk_path, exc)

    # --- 3. Streaming parse ---
    # file_call_graph.json can be several GB at large KB scale.  Loading it
    # with json.load() would temporarily allocate 3–5× the file size in RAM.
    # Instead we make two sequential streaming passes with ijson so that only
    # one array element is live in memory at a time.
    #
    # Pass 1 — stream nodes[] to build the file-type lookup dict.
    # Pass 2 — stream edges[] and emit index entries on-the-fly.
    #
    # Two file reads add disk I/O (2× file size) but keep the heap flat.
    file_size_mb = graph_path.stat().st_size / 1e6
    logger.info("cross_lang_index: streaming %s (%.0f MB) in two passes",
                graph_path.name, file_size_mb)

    try:
        import ijson  # type: ignore[import]
    except ImportError:
        ijson = None  # type: ignore[assignment]

    file_types: Dict[str, str] = {}
    forward: Dict = {}   # (src_stem, src_method) → [target entries]
    backward: Dict = {}  # (tgt_stem, tgt_method) → [caller entries]
    _TRACKED = {"cpp", "asm", "mac"}

    if ijson is not None:
        # ── Pass 1: collect node types ──────────────────────────────────────
        try:
            with open(graph_path, "rb") as fh:
                for node in ijson.items(fh, "nodes.item"):
                    if isinstance(node, dict) and node.get("id"):
                        file_types[node["id"]] = node.get("type", "unknown")
        except Exception as exc:
            logger.warning("Cannot stream nodes from %s: %s", graph_path.name, exc)
            return {"forward": {}, "backward": {}, "file_types": {}}

        # ── Pass 2: stream edges and build index ─────────────────────────────
        try:
            with open(graph_path, "rb") as fh:
                for edge in ijson.items(fh, "edges.item"):
                    if not isinstance(edge, dict):
                        continue
                    src_stem = edge.get("source", "")
                    tgt_stem = edge.get("target", "")
                    if not src_stem or not tgt_stem:
                        continue

                    src_type = file_types.get(src_stem, "unknown")
                    tgt_type = file_types.get(tgt_stem, "unknown")

                    if src_type not in _TRACKED or tgt_type not in _TRACKED:
                        continue
                    if src_type == tgt_type:
                        continue

                    for cs in (edge.get("call_sites") or []):
                        if not isinstance(cs, dict):
                            continue
                        src_method = (cs.get("source_block") or "").strip()
                        tgt_method = (cs.get("target_module") or "").strip()
                        if not src_method or not tgt_method:
                            continue

                        forward.setdefault((src_stem, src_method), []).append({
                            "stem": tgt_stem,
                            "method": tgt_method,
                            "call_type": cs.get("call_type", "call"),
                            "instruction": cs.get("instruction", ""),
                            "line": cs.get("line"),
                            "file_type": tgt_type,
                        })
                        backward.setdefault((tgt_stem, tgt_method), []).append({
                            "stem": src_stem,
                            "method": src_method,
                            "call_type": cs.get("call_type", "call"),
                            "instruction": cs.get("instruction", ""),
                            "line": cs.get("line"),
                            "file_type": src_type,
                        })
        except Exception as exc:
            logger.warning("Cannot stream edges from %s: %s", graph_path.name, exc)
            return {"forward": {}, "backward": {}, "file_types": {}}

    else:
        # ── Fallback: full load (ijson unavailable) ──────────────────────────
        # Only safe for small files (<500 MB).  At large scale, install ijson:
        #   pip install ijson
        logger.warning(
            "ijson not installed — falling back to json.load() for %s (%.0f MB). "
            "This may use %.0f–%.0f MB of RAM.  Run: pip install ijson",
            graph_path.name, file_size_mb, file_size_mb * 3, file_size_mb * 5,
        )
        try:
            with open(graph_path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
        except Exception as exc:
            logger.warning("Cannot read %s: %s", graph_path.name, exc)
            return {"forward": {}, "backward": {}, "file_types": {}}

        file_types = {
            n["id"]: n.get("type", "unknown")
            for n in payload.get("nodes", [])
            if isinstance(n, dict) and n.get("id")
        }
        for edge in payload.get("edges", []):
            if not isinstance(edge, dict):
                continue
            src_stem = edge.get("source", "")
            tgt_stem = edge.get("target", "")
            if not src_stem or not tgt_stem:
                continue
            src_type = file_types.get(src_stem, "unknown")
            tgt_type = file_types.get(tgt_stem, "unknown")
            if src_type not in _TRACKED or tgt_type not in _TRACKED:
                continue
            if src_type == tgt_type:
                continue
            for cs in (edge.get("call_sites") or []):
                if not isinstance(cs, dict):
                    continue
                src_method = (cs.get("source_block") or "").strip()
                tgt_method = (cs.get("target_module") or "").strip()
                if not src_method or not tgt_method:
                    continue
                forward.setdefault((src_stem, src_method), []).append({
                    "stem": tgt_stem,
                    "method": tgt_method,
                    "call_type": cs.get("call_type", "call"),
                    "instruction": cs.get("instruction", ""),
                    "line": cs.get("line"),
                    "file_type": tgt_type,
                })
                backward.setdefault((tgt_stem, tgt_method), []).append({
                    "stem": src_stem,
                    "method": src_method,
                    "call_type": cs.get("call_type", "call"),
                    "instruction": cs.get("instruction", ""),
                    "line": cs.get("line"),
                    "file_type": src_type,
                })
        del payload

    result: Dict[str, Any] = {
        "forward": forward,
        "backward": backward,
        "file_types": file_types,
    }

    # Persist compact disk cache (msgpack.zst), serialising tuple keys as lists
    try:
        serialisable = _serialise_cross_lang(result, graph_mtime)
        _write_index(serialisable, disk_path)
    except Exception as exc:
        logger.warning("Cannot save cross-lang disk cache to %s: %s", disk_path, exc)

    _cross_lang_mem_cache[mem_key] = (graph_mtime, result)
    logger.info(
        "cross_lang_index: %d forward, %d backward cross-language boundaries",
        len(forward), len(backward),
    )
    return result


# ---------------------------------------------------------------------------
# Serialisation helpers for cross-lang index
# (msgpack requires string/bytes keys; we store tuple keys as "stem\x00method")
# ---------------------------------------------------------------------------

_SEP = "\x00"  # null byte separator — never appears in stems or method names


def _serialise_cross_lang(result: Dict[str, Any], graph_mtime: float) -> Dict[str, Any]:
    """Convert tuple-keyed dicts to string-keyed for msgpack serialisation."""
    def _encode(d: Dict) -> Dict[str, Any]:
        return {f"{k[0]}{_SEP}{k[1]}": v for k, v in d.items()}

    return {
        "graph_mtime": graph_mtime,
        "forward": _encode(result["forward"]),
        "backward": _encode(result["backward"]),
        "file_types": result["file_types"],
    }


def _deserialise_cross_lang(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Restore tuple-keyed dicts from string-keyed msgpack data."""
    def _decode(d: Dict) -> Dict:
        out: Dict = {}
        for k, v in d.items():
            if _SEP in k:
                stem, method = k.split(_SEP, 1)
                out[(stem, method)] = v
        return out

    return {
        "forward": _decode(raw.get("forward", {})),
        "backward": _decode(raw.get("backward", {})),
        "file_types": raw.get("file_types", {}),
    }
