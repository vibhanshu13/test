"""Assembly line tokenizer."""

from dataclasses import dataclass
from typing import Optional, List
from models.provenance import StatementProvenance


@dataclass
class ParsedLine:
    """Represents a parsed assembly line."""
    label: Optional[str]
    opcode: Optional[str]
    operands: List[str]
    comment: Optional[str]
    provenance: StatementProvenance


class Tokenizer:
    """Breaks assembly lines into structured tokens.

    Handles fixed-form assembly format:
    - Cols 1-8: Label (optional)
    - Col 9+: Space/Tab separator
    - Col 10+: Opcode
    - Operands (comma-separated)
    - Comments (after space or *)
    """

    _SINGLE_OPERAND_DIRECTIVES = {"DS", "DC", "EQU"}

    def _find_comment_delimiter(self, text: str) -> int:
        """Find comment delimiter as 2+ spaces outside literals/parens."""
        paren_depth = 0
        quote_char: Optional[str] = None
        i = 0

        while i < len(text):
            ch = text[i]
            if quote_char:
                if ch == quote_char:
                    if i + 1 < len(text) and text[i + 1] == quote_char:
                        i += 1
                    else:
                        quote_char = None
            else:
                if ch in ("'", '"'):
                    quote_char = ch
                elif ch == "(":
                    paren_depth += 1
                elif ch == ")" and paren_depth > 0:
                    paren_depth -= 1
                elif ch.isspace() and paren_depth == 0:
                    j = i
                    while j < len(text) and text[j].isspace():
                        j += 1
                    if j - i >= 2:
                        return i
                    i = j - 1
            i += 1

        return -1

    def _split_single_operand(self, text: str) -> tuple[str, Optional[str]]:
        """Split one operand from trailing comment for single-operand directives."""
        paren_depth = 0
        quote_char: Optional[str] = None
        started = False
        i = 0

        while i < len(text):
            ch = text[i]
            if not started and ch.isspace():
                i += 1
                continue
            started = True

            if quote_char:
                if ch == quote_char:
                    if i + 1 < len(text) and text[i + 1] == quote_char:
                        i += 1
                    else:
                        quote_char = None
            else:
                if ch in ("'", '"'):
                    quote_char = ch
                elif ch == "(":
                    paren_depth += 1
                elif ch == ")" and paren_depth > 0:
                    paren_depth -= 1
                elif ch.isspace() and paren_depth == 0:
                    operand = text[:i].strip()
                    comment = text[i:].strip() or None
                    return operand, comment
            i += 1

        return text.strip(), None

    def _split_operand_comment(self, opcode: Optional[str], operand_section: str) -> tuple[str, Optional[str]]:
        """Split operand content and comment with directive-aware heuristics."""
        if not operand_section:
            return "", None

        comment_idx = self._find_comment_delimiter(operand_section)
        if comment_idx != -1:
            return operand_section[:comment_idx].strip(), operand_section[comment_idx:].strip() or None

        op_upper = (opcode or "").upper()
        if op_upper in self._SINGLE_OPERAND_DIRECTIVES:
            return self._split_single_operand(operand_section)

        return operand_section.strip(), None

    def _split_operands(self, operand_str: str) -> List[str]:
        """Split operands on top-level commas only.

        Keeps commas inside parenthesized addressing modes and quoted literals.
        Examples:
        - "R9,0(R7,R2)" -> ["R9", "0(R7,R2)"]
        - "FIELD,=C'A,B'" -> ["FIELD", "=C'A,B'"]
        """
        operands: List[str] = []
        current: List[str] = []
        paren_depth = 0
        quote_char: Optional[str] = None
        i = 0

        while i < len(operand_str):
            ch = operand_str[i]

            if quote_char:
                current.append(ch)
                if ch == quote_char:
                    # Handle doubled quote escaping inside literals (e.g., '' or "").
                    if i + 1 < len(operand_str) and operand_str[i + 1] == quote_char:
                        current.append(operand_str[i + 1])
                        i += 1
                    else:
                        quote_char = None
            else:
                if ch in ("'", '"'):
                    quote_char = ch
                    current.append(ch)
                elif ch == "(":
                    paren_depth += 1
                    current.append(ch)
                elif ch == ")":
                    if paren_depth > 0:
                        paren_depth -= 1
                    current.append(ch)
                elif ch == "," and paren_depth == 0:
                    token = "".join(current).strip()
                    if token:
                        operands.append(token)
                    current = []
                else:
                    current.append(ch)

            i += 1

        tail = "".join(current).strip()
        if tail:
            operands.append(tail)

        return operands

    def tokenize_line(self, line: str, provenance: StatementProvenance) -> ParsedLine:
        """Parse assembly line into components.

        Args:
            line: Assembly source line
            provenance: Provenance for this line

        Returns:
            ParsedLine with extracted components
        """
        # Handle comment lines (start with *)
        if line.strip().startswith('*'):
            return ParsedLine(
                label=None,
                opcode=None,
                operands=[],
                comment=line.strip()[1:].strip(),
                provenance=provenance
            )

        # Extract label (columns 1-8, but flexible)
        label = None
        rest = line

        # If line doesn't start with space, first token is label
        if line and not line[0].isspace():
            parts = line.split(None, 1)
            if parts:
                label = parts[0]
                rest = parts[1] if len(parts) > 1 else ""
        else:
            rest = line.lstrip()

        # Split into opcode, operands, and comment
        opcode = None
        operands = []
        comment = None

        if rest:
            # Parse opcode and operands first
            parts = rest.split(None, 1)
            if parts:
                opcode = parts[0]
                if len(parts) > 1:
                    operand_section = parts[1]
                    operand_str, comment = self._split_operand_comment(opcode, operand_section)

                    # Parse operands (comma-separated)
                    if operand_str:
                        operands = self._split_operands(operand_str)

        return ParsedLine(
            label=label,
            opcode=opcode,
            operands=operands,
            comment=comment,
            provenance=provenance
        )
