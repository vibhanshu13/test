"""File analysis cache with hash-based invalidation."""
import hashlib
import json
from pathlib import Path
from typing import Optional, Dict, Any


class FileAnalysisCache:
    """Manages caching of individual file analysis results."""

    def __init__(self, cache_dir: Path):
        """
        Initialize file cache.

        Args:
            cache_dir: Directory to store cache files
        """
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _compute_hash(self, file_path: str, file_content: str) -> str:
        """
        Compute hash key for file and content.

        Args:
            file_path: Path to the file
            file_content: Content of the file

        Returns:
            Hash string for cache key
        """
        combined = f"{file_path}:{file_content}"
        return hashlib.sha256(combined.encode()).hexdigest()

    def _get_cache_path(self, cache_key: str) -> Path:
        """Get path to cache file for given key."""
        return self.cache_dir / f"{cache_key}.json"

    def store(self, file_path: str, file_content: str, analysis_data: Dict[str, Any]) -> None:
        """
        Store analysis results in cache.

        Args:
            file_path: Path to the analyzed file
            file_content: Content of the file
            analysis_data: Analysis results to cache
        """
        cache_key = self._compute_hash(file_path, file_content)
        cache_path = self._get_cache_path(cache_key)

        cache_entry = {
            "file_path": file_path,
            "cache_key": cache_key,
            "analysis": analysis_data
        }

        try:
            with open(cache_path, 'w') as f:
                json.dump(cache_entry, f, indent=2)
        except (IOError, OSError) as e:
            # Cache is optional - silently fail if write error occurs
            # Could add logging here in future
            pass

    def retrieve(self, file_path: str, file_content: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve analysis results from cache.

        Args:
            file_path: Path to the file
            file_content: Current content of the file

        Returns:
            Cached analysis data if valid, None if cache miss or invalid
        """
        cache_key = self._compute_hash(file_path, file_content)
        cache_path = self._get_cache_path(cache_key)

        if not cache_path.exists():
            return None

        try:
            with open(cache_path, 'r') as f:
                cache_entry = json.load(f)
            return cache_entry["analysis"]
        except (json.JSONDecodeError, KeyError):
            return None
