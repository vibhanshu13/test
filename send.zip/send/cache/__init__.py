"""Cache management for multi-file analysis."""
