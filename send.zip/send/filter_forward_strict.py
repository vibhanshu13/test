#!/usr/bin/env python3
"""
filter_forward_strict.py

Create a strict forward-lineage view from a given anchor chunk_id.

Strict view keeps:
- signal nodes: SETTER, CONDITION_TEST, READER, OVERWRITE
- minimal bridge nodes between consecutive signal nodes:
  - first bridge in segment
  - last bridge in segment
  - any CROSS_FILE_CALL bridge in segment

Usage:
    python3 filter_forward_strict.py <lineage.json> <anchor_chunk_id> [--output <file>]
"""

from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Set, Tuple


SIGNAL_ROLES = {"SETTER", "CONDITION_TEST", "READER", "OVERWRITE"}


def parse_args(argv: List[str]) -> Tuple[Path, str, Path | None]:
    if len(argv) < 3:
        print(__doc__)
        raise SystemExit(1)

    lineage_file = Path(argv[1])
    anchor = argv[2].strip()
    output = None
    if "--output" in argv:
        idx = argv.index("--output")
        if idx + 1 >= len(argv):
            print("Error: --output requires a file path")
            raise SystemExit(1)
        output = Path(argv[idx + 1])
    return lineage_file, anchor, output


def enumerate_paths(anchor: str, children: Dict[str, List[str]]) -> List[List[str]]:
    paths: List[List[str]] = []
    stack: List[Tuple[str, List[str], Set[str]]] = [(anchor, [anchor], {anchor})]
    while stack:
        cur, path, seen = stack.pop()
        kids = [k for k in children.get(cur, []) if k and k not in seen]
        if not kids:
            paths.append(path)
            continue
        for k in kids:
            stack.append((k, path + [k], seen | {k}))
    return paths


def strictify_path(path: List[str], node_by_id: Dict[str, Dict]) -> List[str]:
    signal_idx = [i for i, cid in enumerate(path) if str(node_by_id[cid].get("role", "")) in SIGNAL_ROLES]
    if not signal_idx:
        return [path[0]]

    out: List[str] = [path[signal_idx[0]]]
    for a, b in zip(signal_idx, signal_idx[1:]):
        segment = path[a + 1 : b]
        chosen: List[str] = []
        if segment:
            chosen.append(segment[0])
            for cid in segment:
                if node_by_id[cid].get("role") == "CROSS_FILE_CALL" and cid not in chosen:
                    chosen.append(cid)
            if segment[-1] not in chosen:
                chosen.append(segment[-1])
        out.extend(chosen)
        out.append(path[b])
    return out


def format_path(path: List[str], node_by_id: Dict[str, Dict], idx: int) -> str:
    lines = []
    lines.append("=" * 72)
    lines.append(f"Strict Path {idx} ({len(path)} nodes)")
    lines.append("=" * 72)
    for depth, cid in enumerate(path):
        n = node_by_id[cid]
        edge = (n.get("edge_to_parent") or {}).get("type", "ROOT") if depth > 0 else "ROOT"
        indent = "  " * depth
        lines.append(f"{indent}[{edge}] {cid} ({n.get('role', '')})")
        lines.append(f"{indent}        {str(n.get('source_line', '')).strip()}")
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    lineage_file, anchor, output = parse_args(sys.argv)
    if not lineage_file.exists():
        print(f"Error: file not found: {lineage_file}")
        return 1

    data = json.loads(lineage_file.read_text(encoding="utf-8"))
    nodes = data.get("nodes", [])
    node_by_id: Dict[str, Dict] = {n.get("chunk_id"): n for n in nodes if n.get("chunk_id")}
    if anchor not in node_by_id:
        print(f"Error: anchor not found: {anchor}")
        return 1

    children: Dict[str, List[str]] = defaultdict(list)
    for n in nodes:
        pid = n.get("parent_chunk_id")
        cid = n.get("chunk_id")
        if pid and cid:
            children[pid].append(cid)

    full_paths = enumerate_paths(anchor, children)
    strict_paths = [strictify_path(p, node_by_id) for p in full_paths]

    dedup: List[List[str]] = []
    seen = set()
    for p in strict_paths:
        key = tuple(p)
        if key in seen:
            continue
        seen.add(key)
        dedup.append(p)

    dedup.sort(key=len, reverse=True)

    header = [
        f"Strict forward paths from {anchor}",
        f"source: {str(node_by_id[anchor].get('source_line', '')).strip()}",
        f"total_full_paths: {len(full_paths)}",
        f"total_strict_paths: {len(dedup)}",
        "",
    ]
    body: List[str] = []
    for i, p in enumerate(dedup, start=1):
        body.append(format_path(p, node_by_id, i))

    text = "\n".join(header + body).rstrip() + "\n"
    print(text, end="")

    if output:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(text, encoding="utf-8")
        print(f"Output saved to: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
