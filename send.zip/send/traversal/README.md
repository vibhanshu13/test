# Trace Variable

This script traces a variable’s lineage across C++ and ASM using the parser output JSON files.

## Run

```bash
python3 traversal/trace_variable.py \
  --cpp-json output/final_test_data/cross_lang_callers.cpp.json \
  --asm-dir output/final_test_data \
  --var raw_input \
  --direction both \
  --follow-asm-calls \
  --include-global
```

Output is written to:

```
traversal/output/trace_<var>.txt
```

You can override the output path with `--out`.

## Current Variables (7)

```bash
python3 traversal/trace_variable.py --cpp-json output/final_test_data/cross_lang_callers.cpp.json --asm-dir output/final_test_data --var raw_input --out traversal/output/trace_raw_input.txt
python3 traversal/trace_variable.py --cpp-json output/final_test_data/tpf_regs_ops.cpp.json --asm-dir output/final_test_data --var regs.r4 --out traversal/output/trace_regs.r4.txt
python3 traversal/trace_variable.py --cpp-json output/final_test_data/entrc_handlers.cpp.json --asm-dir output/final_test_data --var EDACCT --out traversal/output/trace_EDACCT.txt
python3 traversal/trace_variable.py --cpp-json output/final_test_data/ecb_level_ops.cpp.json --asm-dir output/final_test_data --var 'app->flags.status' --out traversal/output/trace_app_flags_status.txt
python3 traversal/trace_variable.py --cpp-json output/final_test_data/ecb_level_ops.cpp.json --asm-dir output/final_test_data --var msg_ptr --out traversal/output/trace_msg_ptr.txt
python3 traversal/trace_variable.py --cpp-json output/final_test_data/tpf_regs_ops.cpp.json --asm-dir output/final_test_data --var registers.r1 --out traversal/output/trace_registers.r1.txt
python3 traversal/trace_variable.py --cpp-json output/final_test_data/cross_lang_callers.cpp.json --asm-dir output/final_test_data --var txn.txn_type --out traversal/output/trace_txn_txn_type.txt
python3 traversal/trace_variable.py --cpp-json output/final_test_data/ecb_level_ops.cpp.json --asm-dir output/final_test_data --var 'scratch_ints[0]' --out traversal/output/trace_scratch_ints_0.txt
python3 traversal/trace_variable.py --cpp-json output/final_test_data/entrc_handlers.cpp.json --asm-dir output/final_test_data --var STATUS --out traversal/output/trace_STATUS.txt
python3 traversal/trace_variable.py --cpp-json output/final_test_data/heap_decb_ops.cpp.json --asm-dir output/final_test_data --var 'PARAM_BLK' --out traversal/output/trace_PARAM_BLK.txt
```
