#!/usr/bin/env python3
"""Traverse variable lineage across C++ -> ASM using parser output."""

import argparse
import json
import shutil
from collections import defaultdict, deque
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple
import sys


DEFAULT_SOURCE_OUTPUT_DIR = Path("output/final_test_data_new")
DEFAULT_WORKING_OUTPUT_DIR = Path("output/final_test_data_working")
DEFAULT_ISSUE_LOG = Path("temp/level_lineage_parser_issues.md")


def log_issue(issue_log: Path, message: str) -> None:
    issue_log.parent.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with issue_log.open("a") as out:
        out.write(f"- [{timestamp}] {message}\n")


def load_json(path: Path, issue_log: Optional[Path] = None) -> dict:
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        if issue_log:
            log_issue(issue_log, f"Missing JSON file: {path}")
        return {}
    except json.JSONDecodeError as exc:
        if issue_log:
            log_issue(issue_log, f"Invalid JSON file: {path} ({exc})")
        return {}


def node_name(node_id: str) -> str:
    if not node_id:
        return ""
    return node_id.split(":", 1)[1] if ":" in node_id else node_id


def tail_name(name: str) -> str:
    if not name:
        return ""
    return name.split("::")[-1]


def source_matches_var(source_id: str, var: str) -> bool:
    name = node_name(source_id)
    tail = tail_name(name)
    # Handle literal nodes (e.g., literal:"PARAM_BLK")
    if source_id.startswith("literal:"):
        lit = name.strip()
        if (lit.startswith('"') and lit.endswith('"')) or (lit.startswith("'") and lit.endswith("'")):
            lit = lit[1:-1]
        if lit == var:
            return True
    if tail == var:
        return True
    # Normalize struct-field separators to improve matching (app->flags->status vs app->flags.status)
    norm_tail = tail.replace("->", ".")
    norm_var = var.replace("->", ".")
    return norm_tail == norm_var


def scope_from_node_id(node_id: str) -> Optional[str]:
    name = node_name(node_id)
    if "::" in name:
        return name.split("::", 1)[0]
    return None


def find_call_arg_edges(cpp_data: dict, var: str) -> Tuple[list, dict]:
    graph = cpp_data.get("variable_lineage", {})
    nodes = {n["id"]: n for n in graph.get("nodes", [])}
    edges = graph.get("edges", [])
    matches = []
    for e in edges:
        if e.get("relation") != "assign":
            continue
        target = e.get("target", "")
        if not target.startswith("call_arg:"):
            continue
        if source_matches_var(e.get("source", ""), var):
            matches.append(e)
    return matches, nodes


def find_call_arg_memory_bridge(cpp_data: dict, call_arg_id: str) -> Optional[str]:
    graph = cpp_data.get("variable_lineage", {})
    edges = graph.get("edges", [])
    # Prefer explicit caller_param mapping if present
    for e in edges:
        if e.get("source") == call_arg_id and str(e.get("target", "")).startswith("memory:caller_param"):
            return e.get("target")
    for e in edges:
        if e.get("source") == call_arg_id and str(e.get("target", "")).startswith("memory:"):
            return e.get("target")
    return None


def find_definition_edges(cpp_data: dict, var: str) -> list:
    graph = cpp_data.get("variable_lineage", {})
    edges = graph.get("edges", [])
    matches = []
    for e in edges:
        if e.get("relation") != "define":
            continue
        src = e.get("source", "")
        tgt = e.get("target", "")
        if src != tgt:
            continue
        if source_matches_var(src, var):
            matches.append(e)
    return matches


def find_cpp_start_nodes(cpp_data: dict, var: str) -> list:
    graph = cpp_data.get("variable_lineage", {})
    nodes = graph.get("nodes", [])
    starts = []
    for n in nodes:
        node_id = n.get("id", "")
        if not node_id:
            continue
        if source_matches_var(node_id, var):
            starts.append(node_id)
    return list(dict.fromkeys(starts))


def parse_call_arg(node: dict) -> Tuple[Optional[str], Optional[int], Optional[str]]:
    meta = node.get("metadata", {}) if node else {}
    callee = meta.get("callee")
    arg_index = meta.get("arg_index")
    callee_alias = meta.get("callee_alias")
    if callee is not None and arg_index is not None:
        return callee, int(arg_index), callee_alias

    name = node.get("name", "") if node else ""
    if "#" in name:
        callee, idx = name.rsplit("#", 1)
        if idx.isdigit():
            return callee, int(idx), None
    return None, None, None


def find_asm_start_nodes(asm_data: dict, var: str) -> list:
    """Find ASM node ids that correspond to the given variable name."""
    graph = asm_data.get("variable_lineage", {})
    nodes = graph.get("nodes", [])
    starts = []
    for n in nodes:
        node_id = n.get("id", "")
        if not node_id:
            continue
        if tail_name(node_name(node_id)) == var:
            starts.append(node_id)
    # Also allow direct id match for memory:VAR style
    if f"memory:{var}" not in starts:
        if any(n.get("id") == f"memory:{var}" for n in nodes):
            starts.append(f"memory:{var}")
    return list(dict.fromkeys(starts))


def stitch_asm_dir(asm_dir: Path, issue_log: Path) -> dict:
    """Stitch all ASM JSON files into one combined structure."""
    stitched = {
        "variable_lineage": {"nodes": [], "edges": []},
        "call_graph": {"nodes": {}, "edges": []},
        "symbols": {"global_symbols": {}, "sections": {}},
    }
    seen_nodes = set()
    seen_edges = set()

    for path in asm_dir.glob("*.asm.json"):
        data = load_json(path, issue_log=issue_log)
        if not data:
            continue

        # symbols
        symbols = data.get("symbols", {})
        for name, sym in (symbols.get("global_symbols", {}) or {}).items():
            stitched["symbols"]["global_symbols"].setdefault(name, sym)
        for sec, sec_syms in (symbols.get("sections", {}) or {}).items():
            stitched["symbols"]["sections"].setdefault(sec, {})
            for name, sym in sec_syms.items():
                stitched["symbols"]["sections"][sec].setdefault(name, sym)

        # call_graph
        cg = data.get("call_graph", {})
        for name, node in (cg.get("nodes", {}) or {}).items():
            stitched["call_graph"]["nodes"].setdefault(name, node)
        for edge in (cg.get("edges", []) or []):
            key = (edge.get("source"), edge.get("target"), edge.get("line"), edge.get("instruction"))
            if key in seen_edges:
                continue
            seen_edges.add(key)
            stitched["call_graph"]["edges"].append(edge)

        # variable_lineage
        vl = data.get("variable_lineage", {})
        for node in (vl.get("nodes", []) or []):
            node_id = node.get("id")
            if node_id and node_id not in seen_nodes:
                seen_nodes.add(node_id)
                stitched["variable_lineage"]["nodes"].append(node)
        for edge in (vl.get("edges", []) or []):
            key = (edge.get("source"), edge.get("target"), edge.get("relation"), edge.get("line"), edge.get("file"))
            if key in seen_edges:
                continue
            seen_edges.add(key)
            stitched["variable_lineage"]["edges"].append(edge)

    return stitched


def stitch_symbol_aliases(asm_dir: Path, issue_log: Path) -> dict:
    """Collect symbol_aliases from any JSON files in the directory."""
    aliases = {}
    for path in asm_dir.glob("*.json"):
        data = load_json(path, issue_log=issue_log)
        if not data:
            continue
        if isinstance(data.get("symbol_aliases"), dict):
            for key, val in data["symbol_aliases"].items():
                if key not in aliases:
                    aliases[key] = val
                    continue
                # Prefer non-identity aliases when available.
                if aliases[key] == key and val != key:
                    aliases[key] = val
    return aliases


def ensure_working_copy(source_dir: Path, working_dir: Path, issue_log: Path) -> None:
    if not source_dir.exists():
        log_issue(issue_log, f"Source parser output directory missing: {source_dir}")
        return
    if working_dir.exists():
        return
    try:
        shutil.copytree(source_dir, working_dir)
    except Exception as exc:
        log_issue(issue_log, f"Failed to copy parser outputs to working dir: {exc}")


def map_to_working(path: Path, source_dir: Path, working_dir: Path) -> Path:
    try:
        rel = path.relative_to(source_dir)
    except ValueError:
        return path
    return working_dir / rel


def node_display_name(node_id: str, node_map: dict) -> str:
    if node_id in node_map and node_map[node_id].get("name"):
        return node_map[node_id]["name"]
    if not node_id:
        return ""
    return node_id.split(":", 1)[1] if ":" in node_id else node_id


def node_kind(node_id: str, node_map: dict) -> str:
    if node_id in node_map and node_map[node_id].get("kind"):
        return node_map[node_id]["kind"]
    return "unknown"


def is_lineage_var(node_id: str, node_map: dict) -> bool:
    kind = node_kind(node_id, node_map)
    return kind in {"variable", "memory", "register", "struct_field", "array_element", "parameter"}


def extract_snippet(file_path: str, line_num: Optional[int], cache: dict, issue_log: Path) -> str:
    if not file_path or not isinstance(line_num, int) or line_num < 1:
        return ""
    if file_path not in cache:
        try:
            cache[file_path] = Path(file_path).read_text(encoding="latin-1").splitlines()
        except Exception as exc:
            log_issue(issue_log, f"Snippet read failed for {file_path}: {exc}")
            cache[file_path] = []
    lines = cache[file_path]
    if not lines:
        return ""
    idx = line_num - 1
    start = max(0, idx - 1)
    end = min(len(lines), idx + 2)
    return "\n".join(lines[start:end])


def build_levels_with_context(
    roots: list,
    edges: list,
    node_map: dict,
    direction: str,
    max_depth: int,
    issue_log: Path,
) -> list:
    if not roots:
        return []
    adj = defaultdict(list)
    for e in edges:
        src = e.get("source")
        tgt = e.get("target")
        if not src or not tgt:
            continue
        if direction == "forward":
            adj[src].append((tgt, e))
        else:
            adj[tgt].append((src, e))

    visited_nodes = set(roots)
    visited_edges = set()
    frontier = deque(roots)
    depth = 0
    levels = []
    snippet_cache = {}

    while frontier and depth < max_depth:
        depth += 1
        level_nodes = list(frontier)
        level_edges = []
        next_frontier = deque()

        while frontier:
            current = frontier.popleft()
            for neighbor_id, edge in adj.get(current, []):
                edge_key = (
                    edge.get("source"),
                    edge.get("target"),
                    edge.get("statement_id"),
                    edge.get("relation"),
                    edge.get("file"),
                    edge.get("line"),
                )
                if edge_key in visited_edges:
                    continue
                visited_edges.add(edge_key)
                level_edges.append(edge)
                if neighbor_id not in visited_nodes:
                    visited_nodes.add(neighbor_id)
                    next_frontier.append(neighbor_id)

        if not level_nodes and not level_edges:
            break

        level_vars = [
            node_display_name(node_id, node_map)
            for node_id in level_nodes
            if is_lineage_var(node_id, node_map)
        ]
        level_vars = list(dict.fromkeys(level_vars))

        contexts = []
        grouped = defaultdict(list)
        for e in level_edges:
            key = (e.get("file"), e.get("line"), e.get("statement_id"))
            grouped[key].append(e)

        for (file_path, line_num, _stmt_id), group_edges in grouped.items():
            context_nodes = set()
            for e in group_edges:
                for node_id in (e.get("source"), e.get("target")):
                    if isinstance(node_id, str) and is_lineage_var(node_id, node_map):
                        context_nodes.add(node_display_name(node_id, node_map))

            focus_vars = [v for v in level_vars if v in context_nodes]
            related_vars = set()
            if focus_vars:
                for e in group_edges:
                    src = e.get("source")
                    tgt = e.get("target")
                    if direction == "backward":
                        if tgt and node_display_name(tgt, node_map) in focus_vars:
                            if src and is_lineage_var(src, node_map):
                                related_vars.add(node_display_name(src, node_map))
                    else:
                        if src and node_display_name(src, node_map) in focus_vars:
                            if tgt and is_lineage_var(tgt, node_map):
                                related_vars.add(node_display_name(tgt, node_map))

            source_types = sorted({e.get("relation", "") for e in group_edges if e.get("relation")})
            paragraph_names = sorted({e.get("scope") for e in group_edges if e.get("scope")})
            snippet = extract_snippet(file_path, line_num, snippet_cache, issue_log)
            contexts.append({
                "file_path": file_path or "",
                "line_numbers": [line_num] if isinstance(line_num, int) else [],
                "focus_vars": focus_vars,
                "related_vars": sorted(related_vars),
                "source_types": source_types,
                "paragraph_names": paragraph_names,
                "snippets": [snippet] if snippet else [],
            })

        levels.append({
            "direction": direction,
            "level": depth,
            "variables": level_vars,
            "contexts": contexts,
        })

        frontier = next_frontier

    return levels


def build_level_map_entries(
    roots: list,
    edges: list,
    node_map: dict,
    direction: str,
    max_depth: int,
    issue_log: Path,
) -> list:
    levels = build_levels_with_context(roots, edges, node_map, direction, max_depth, issue_log)
    mapped = []
    for entry in levels:
        depth = entry.get("level")
        if not isinstance(depth, int):
            continue
        if direction == "backward":
            level_key = -depth
        else:
            level_key = depth + 1
        mapped.append((level_key, {
            "direction": direction,
            "variables": entry.get("variables", []),
            "contexts": entry.get("contexts", []),
        }))
    return mapped


def bfs_edges_scoped(data: dict, start: str, scope: str) -> list:
    graph = data.get("variable_lineage", {})
    edges = [e for e in graph.get("edges", []) if e.get("scope") == scope]
    fwd = defaultdict(list)
    rev = defaultdict(list)
    for e in edges:
        s, t = e.get("source"), e.get("target")
        if s and t:
            fwd[s].append(e)
            rev[t].append(e)

    return fwd, rev


def bfs_edges(adj: dict, start: str) -> list:
    seen = {start}
    q = deque([start])
    out = []
    while q:
        node = q.popleft()
        for e in adj.get(node, []):
            out.append(e)
            nxt = e.get("target") if e.get("source") == node else e.get("source")
            if nxt and nxt not in seen:
                seen.add(nxt)
                q.append(nxt)
    return out


def build_adj(edges: list) -> Tuple[dict, dict]:
    fwd = defaultdict(list)
    rev = defaultdict(list)
    for e in edges:
        s, t = e.get("source"), e.get("target")
        if s and t:
            fwd[s].append(e)
            rev[t].append(e)
    return fwd, rev


def print_chunk(file_path: str, line: int, edges: list, out) -> None:
    if not file_path or not line:
        return
    src = Path(file_path).read_text(encoding="latin-1").splitlines()
    code = src[line - 1] if 0 <= line - 1 < len(src) else ""
    print(f"{file_path}:{line}", file=out)
    print(code, file=out)
    seen = set()
    for e in edges:
        key = (e.get("source"), e.get("target"), e.get("relation"), e.get("expression"))
        if key in seen:
            continue
        seen.add(key)
        print(f"  {e.get('source')} -> {e.get('target')} ({e.get('relation')}) | {e.get('expression')}", file=out)
    print("-" * 60, file=out)


def dump_edges_by_location(edges: list, out) -> None:
    by_loc = defaultdict(list)
    for e in edges:
        file_path = e.get("file")
        line = e.get("line")
        if not file_path or not line:
            continue
        by_loc[(file_path, line)].append(e)
    for (file_path, line) in sorted(by_loc, key=lambda x: (x[0] or "", x[1] or -1)):
        print_chunk(file_path, line, by_loc[(file_path, line)], out)


def expand_cpp_start_nodes(cpp_nodes: dict, seeds: set) -> set:
    """Add variable:* equivalents for parameter:* seeds when available."""
    expanded = set(seeds)
    for node_id in list(seeds):
        if not isinstance(node_id, str):
            continue
        if node_id.startswith("parameter:") and "::" in node_id:
            var_id = node_id.replace("parameter:", "variable:", 1)
            if var_id in cpp_nodes:
                expanded.add(var_id)
    return expanded


def filter_r1_noise(edges: list, var: str) -> list:
    """Heuristic filter: drop R1 edges that are not driven by var-based load."""
    edacct_src = f"function:{var}"
    edacct_lit = f"literal:=A({var})"

    edacct_line = None
    for e in edges:
        if e.get("source") == edacct_src and e.get("target") == "register:R1" and e.get("relation") == "assign":
            line = e.get("line")
            if isinstance(line, int):
                edacct_line = line if edacct_line is None else min(edacct_line, line)
    if edacct_line is None:
        return edges

    def touches_r1(node_id: str) -> bool:
        if not isinstance(node_id, str):
            return False
        if node_id == "register:R1":
            return True
        if node_id.startswith("parameter:arg@") and node_id.endswith(":R1"):
            return True
        return False

    def assigns_r1(e: dict) -> bool:
        return e.get("target") == "register:R1" and e.get("relation") == "assign"

    filtered = []
    r1_live = False
    for e in sorted(edges, key=lambda x: (x.get("file") or "", x.get("line") or -1, x.get("expression") or "")):
        line = e.get("line")
        if isinstance(line, int) and line < edacct_line:
            if touches_r1(e.get("source")) or touches_r1(e.get("target")):
                continue
        if assigns_r1(e):
            src = e.get("source")
            if src in (edacct_src, edacct_lit, "register:R1"):
                r1_live = True
            else:
                r1_live = False
        if (touches_r1(e.get("source")) or touches_r1(e.get("target"))) and not r1_live:
            continue
        filtered.append(e)
    return filtered


def main() -> None:
    parser = argparse.ArgumentParser(description="Trace variable lineage across C++ and ASM.")
    parser.add_argument("--cpp-json", required=True, help="C++ JSON output file")
    parser.add_argument("--asm-dir", required=True, help="Directory with ASM JSON outputs")
    parser.add_argument("--var", required=True, help="Variable name (e.g., raw_input)")
    parser.add_argument("--out", help="Output file path (defaults to traversal/output/trace_<var>.txt)")
    parser.add_argument("--direction", default="backward", choices=["forward", "backward", "both"], help="Traversal direction")
    parser.add_argument("--include-global", action="store_true", help="Include global_variable_lineage matches")
    parser.add_argument("--follow-asm-calls", action="store_true", help="List reachable ASM call graph edges")
    parser.add_argument("--format", default="text", choices=["text", "json"], help="Output format (text or json)")
    parser.add_argument("--max-level", type=int, default=5, help="Maximum lineage levels for JSON output")
    parser.add_argument("--source-output-dir", default=str(DEFAULT_SOURCE_OUTPUT_DIR),
                        help="Source parser output directory (read-only)")
    parser.add_argument("--working-output-dir", default=str(DEFAULT_WORKING_OUTPUT_DIR),
                        help="Working parser output directory (editable)")
    parser.add_argument("--issue-log", default=str(DEFAULT_ISSUE_LOG),
                        help="Markdown file to log parser output issues")
    args = parser.parse_args()

    issue_log = Path(args.issue_log)
    source_dir = Path(args.source_output_dir)
    working_dir = Path(args.working_output_dir)

    ensure_working_copy(source_dir, working_dir, issue_log)

    cpp_path = Path(args.cpp_json)
    asm_dir = Path(args.asm_dir)

    cpp_working = map_to_working(cpp_path, source_dir, working_dir)
    asm_working = map_to_working(asm_dir, source_dir, working_dir)
    if cpp_path != cpp_working:
        cpp_path = cpp_working
    if asm_dir != asm_working:
        asm_dir = asm_working

    if not cpp_path.exists():
        log_issue(issue_log, f"C++ JSON output not found: {cpp_path}")
    if not asm_dir.exists():
        log_issue(issue_log, f"ASM output directory not found: {asm_dir}")
    var = args.var

    cpp_data = load_json(cpp_path, issue_log=issue_log)
    alias_map = cpp_data.get("symbol_aliases", {}) or {}
    alias_map.update(stitch_symbol_aliases(asm_dir, issue_log))
    cpp_nodes = {n["id"]: n for n in cpp_data.get("variable_lineage", {}).get("nodes", [])}

    call_edges, nodes = find_call_arg_edges(cpp_data, var)
    def_edges = find_definition_edges(cpp_data, var)
    stitched_asm = stitch_asm_dir(asm_dir, issue_log)

    if args.format == "json":
        output_path = Path(args.out) if args.out else Path("traversal/output") / f"trace_{var}.json"
        output_path.parent.mkdir(parents=True, exist_ok=True)

        cpp_nodes_list = cpp_data.get("variable_lineage", {}).get("nodes", []) or []
        asm_nodes_list = stitched_asm.get("variable_lineage", {}).get("nodes", []) or []
        node_map = {}
        for n in cpp_nodes_list + asm_nodes_list:
            node_id = n.get("id")
            if node_id and node_id not in node_map:
                node_map[node_id] = n

        cpp_edges = cpp_data.get("variable_lineage", {}).get("edges", []) or []
        asm_edges = stitched_asm.get("variable_lineage", {}).get("edges", []) or []
        all_edges = cpp_edges + asm_edges

        cpp_starts = find_cpp_start_nodes(cpp_data, var)
        asm_starts = find_asm_start_nodes(stitched_asm, var)
        start_nodes = list(dict.fromkeys(cpp_starts + asm_starts))
        if not start_nodes:
            log_issue(issue_log, f"No start nodes found for {var} in {cpp_path} or {asm_dir}")

        levels_map = defaultdict(list)

        root_vars = [
            node_display_name(node_id, node_map)
            for node_id in start_nodes
            if is_lineage_var(node_id, node_map)
        ]
        root_vars = list(dict.fromkeys(root_vars))
        levels_map["1"].append({
            "direction": "root",
            "variables": root_vars,
            "contexts": [],
        })

        if args.direction in ("backward", "both"):
            for level_key, entry in build_level_map_entries(start_nodes, all_edges, node_map, "backward", args.max_level, issue_log):
                levels_map[str(level_key)].append(entry)
        if args.direction in ("forward", "both"):
            for level_key, entry in build_level_map_entries(start_nodes, all_edges, node_map, "forward", args.max_level, issue_log):
                levels_map[str(level_key)].append(entry)

        output = {
            "keyword": var,
            "levels": dict(levels_map),
        }
        output_path.write_text(json.dumps(output, indent=2))
        print(f"Wrote: {output_path}")
        return

    output_path = Path(args.out) if args.out else Path("traversal/output") / f"trace_{var}.txt"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w") as out:
        if call_edges:
            if def_edges:
                print(f"C++ definition sites for {var}:", file=out)
                by_loc = defaultdict(list)
                for e in def_edges:
                    by_loc[(e.get("file"), e.get("line"))].append(e)
                for (file_path, line) in sorted(by_loc, key=lambda x: (x[0] or "", x[1] or -1)):
                    print_chunk(file_path, line, by_loc[(file_path, line)], out)
            else:
                print(f"No C++ definition edges found for {var}.", file=out)

            print(f"C++ callsite bindings for {var}:", file=out)
            by_loc = defaultdict(list)
            for e in call_edges:
                by_loc[(e.get("file"), e.get("line"))].append(e)
            for (file_path, line) in sorted(by_loc, key=lambda x: (x[0] or "", x[1] or -1)):
                print_chunk(file_path, line, by_loc[(file_path, line)], out)

            for e in call_edges:
                target_id = e.get("target")
                node = nodes.get(target_id)
                callee, arg_index, callee_alias = parse_call_arg(node)
                if callee is None or arg_index is None:
                    continue

                if callee_alias:
                    asm_name = alias_map.get(callee_alias, callee_alias)
                else:
                    asm_name = alias_map.get(callee, callee)
                asm_data = stitched_asm
                start = find_call_arg_memory_bridge(cpp_data, target_id) or f"memory:caller_param[{arg_index}]"
                fwd, rev = bfs_edges_scoped(asm_data, start, asm_name)
                asm_edges = []
                if args.direction in ("forward", "both"):
                    asm_edges.extend(bfs_edges(fwd, start))
                if args.direction in ("backward", "both"):
                    asm_edges.extend(bfs_edges(rev, start))
                if not asm_edges:
                    print(f"No ASM lineage edges from {start} in scope {asm_name}", file=out)
                    continue

                print(f"ASM lineage in stitched ASM scope {asm_name} starting at {start} ({args.direction}):", file=out)
                dump_edges_by_location(asm_edges, out)

                if args.follow_asm_calls:
                    cg_edges = asm_data.get("call_graph", {}).get("edges", [])
                    reachable = [ce for ce in cg_edges if ce.get("source") == asm_name]
                    if reachable:
                        print(f"ASM call graph edges from {asm_name}:", file=out)
                        for ce in reachable:
                            print(f"  {ce.get('source')} -> {ce.get('target')} | line {ce.get('line')} | {ce.get('instruction')}", file=out)
                        print("-" * 60, file=out)
        else:
            # No call_arg bindings: try C++-first, then ASM-first.
            cpp_starts = find_cpp_start_nodes(cpp_data, var)
            if cpp_starts:
                print(f"C++-first traversal for {var}", file=out)
                print(f"Start nodes: {', '.join(cpp_starts)}", file=out)

                cpp_edges = cpp_data.get("variable_lineage", {}).get("edges", [])
                cpp_fwd, cpp_rev = build_adj(cpp_edges)
                cpp_reached = []
                for n in sorted(cpp_starts):
                    if args.direction in ("forward", "both"):
                        cpp_reached.extend(bfs_edges(cpp_fwd, n))
                    if args.direction in ("backward", "both"):
                        cpp_reached.extend(bfs_edges(cpp_rev, n))

                if cpp_reached:
                    print("C++ lineage:", file=out)
                    dump_edges_by_location(cpp_reached, out)

                # Bridge into ASM via ecb_bridge / scratch_bridge / level_bridge / name_bridge / name_table_ptr_bridge / alias-to-memory edges
                ecb_targets = set()
                level_targets = set()
                mem_targets = set()
                name_targets = set()
                name_ptr_targets = set()
                for e in cpp_reached:
                    rel = e.get("relation")
                    tgt = e.get("target")
                    if isinstance(tgt, str) and tgt.startswith("memory:"):
                        if rel in ("ecb_bridge", "scratch_bridge"):
                            ecb_targets.add(tgt)
                        if rel == "level_bridge":
                            level_targets.add(tgt)
                        if rel == "name_table_ptr_bridge":
                            name_ptr_targets.add(tgt)
                        if rel in ("alias", "assign"):
                            # Avoid broad ASM noise from generic caller_param slots in C++-first traversal.
                            if not tgt.startswith("memory:caller_param"):
                                mem_targets.add(tgt)
                    if rel == "name_bridge":
                        name_targets.add(tgt)

                if ecb_targets:
                    asm_edges_all = stitched_asm.get("variable_lineage", {}).get("edges", [])
                    print("ASM lineage (ECB/SCRATCH bridge):", file=out)
                    asm_reached = []
                    for s in sorted(ecb_targets):
                        scopes = set()
                        for edge in asm_edges_all:
                            if edge.get("source") == s or edge.get("target") == s:
                                if edge.get("scope"):
                                    scopes.add(edge.get("scope"))
                        if not scopes:
                            scopes = {None}
                        for scope in scopes:
                            if scope:
                                fwd, rev = bfs_edges_scoped(stitched_asm, s, scope)
                            else:
                                asm_fwd, asm_rev = build_adj(asm_edges_all)
                                fwd, rev = asm_fwd, asm_rev
                            if args.direction in ("forward", "both"):
                                asm_reached.extend(bfs_edges(fwd, s))
                            if args.direction in ("backward", "both"):
                                asm_reached.extend(bfs_edges(rev, s))
                    if asm_reached:
                        dump_edges_by_location(asm_reached, out)
                if level_targets:
                    asm_edges_all = stitched_asm.get("variable_lineage", {}).get("edges", [])
                    print("ASM lineage (LEVEL bridge):", file=out)
                    asm_reached = []
                    for s in sorted(level_targets):
                        scopes = set()
                        for edge in asm_edges_all:
                            if edge.get("source") == s or edge.get("target") == s:
                                if edge.get("scope"):
                                    scopes.add(edge.get("scope"))
                        if not scopes:
                            scopes = {None}
                        for scope in scopes:
                            if scope:
                                fwd, rev = bfs_edges_scoped(stitched_asm, s, scope)
                            else:
                                asm_fwd, asm_rev = build_adj(asm_edges_all)
                                fwd, rev = asm_fwd, asm_rev
                            if args.direction in ("forward", "both"):
                                asm_reached.extend(bfs_edges(fwd, s))
                            if args.direction in ("backward", "both"):
                                asm_reached.extend(bfs_edges(rev, s))
                    if asm_reached:
                        dump_edges_by_location(asm_reached, out)
                if mem_targets:
                    asm_edges_all = stitched_asm.get("variable_lineage", {}).get("edges", [])
                    print("ASM lineage (memory alias bridge):", file=out)
                    asm_reached = []
                    for s in sorted(mem_targets):
                        scopes = set()
                        for edge in asm_edges_all:
                            if edge.get("source") == s or edge.get("target") == s:
                                if edge.get("scope"):
                                    scopes.add(edge.get("scope"))
                        if not scopes:
                            scopes = {None}
                        for scope in scopes:
                            if scope:
                                fwd, rev = bfs_edges_scoped(stitched_asm, s, scope)
                            else:
                                asm_fwd, asm_rev = build_adj(asm_edges_all)
                                fwd, rev = asm_fwd, asm_rev
                            if args.direction in ("forward", "both"):
                                asm_reached.extend(bfs_edges(fwd, s))
                            if args.direction in ("backward", "both"):
                                asm_reached.extend(bfs_edges(rev, s))
                    if asm_reached:
                        dump_edges_by_location(asm_reached, out)
                if name_targets:
                    asm_edges_all = stitched_asm.get("variable_lineage", {}).get("edges", [])
                    print("ASM lineage (name bridge):", file=out)
                    asm_reached = []
                    for s in sorted(name_targets):
                        scopes = set()
                        for edge in asm_edges_all:
                            if edge.get("source") == s or edge.get("target") == s:
                                if edge.get("scope"):
                                    scopes.add(edge.get("scope"))
                        if not scopes:
                            scopes = {None}
                        for scope in scopes:
                            if scope:
                                fwd, rev = bfs_edges_scoped(stitched_asm, s, scope)
                            else:
                                asm_fwd, asm_rev = build_adj(asm_edges_all)
                                fwd, rev = asm_fwd, asm_rev
                            if args.direction in ("forward", "both"):
                                asm_reached.extend(bfs_edges(fwd, s))
                            if args.direction in ("backward", "both"):
                                asm_reached.extend(bfs_edges(rev, s))
                    if asm_reached:
                        dump_edges_by_location(asm_reached, out)
                if name_ptr_targets:
                    asm_edges_all = stitched_asm.get("variable_lineage", {}).get("edges", [])
                    print("ASM lineage (name table ptr bridge):", file=out)
                    asm_reached = []
                    for s in sorted(name_ptr_targets):
                        scopes = set()
                        for edge in asm_edges_all:
                            if edge.get("source") == s or edge.get("target") == s:
                                if edge.get("scope"):
                                    scopes.add(edge.get("scope"))
                        if not scopes:
                            scopes = {None}
                        for scope in scopes:
                            if scope:
                                fwd, rev = bfs_edges_scoped(stitched_asm, s, scope)
                            else:
                                asm_fwd, asm_rev = build_adj(asm_edges_all)
                                fwd, rev = asm_fwd, asm_rev
                            if args.direction in ("forward", "both"):
                                asm_reached.extend(bfs_edges(fwd, s))
                            if args.direction in ("backward", "both"):
                                asm_reached.extend(bfs_edges(rev, s))
                    if asm_reached:
                        dump_edges_by_location(asm_reached, out)
                if not ecb_targets and not level_targets and not mem_targets and not name_targets and not name_ptr_targets:
                    print("No ECB/LEVEL/SCRATCH/NAME/PTR/memory bridge edges found in C++ lineage.", file=out)
                return

            # ASM-first traversal when no C++ start nodes exist.
            start_nodes = find_asm_start_nodes(stitched_asm, var)
            if not start_nodes:
                print(f"No call-arg bindings found for {var} in {cpp_path}", file=out)
                print(f"No C++ start nodes found for {var} in {cpp_path}", file=out)
                print(f"No ASM start nodes found for {var} in {asm_dir}", file=out)
                if var.endswith("-"):
                    print(
                        "Hint: your variable ends with '-', which often means the shell interpreted '>' as output redirection. "
                        "Try quoting the var, e.g. --var 'app->flags.status'.",
                        file=out,
                    )
            else:
                print(f"ASM-first traversal for {var}", file=out)
                print(f"Start nodes: {', '.join(start_nodes)}", file=out)

                asm_edges_all = stitched_asm.get("variable_lineage", {}).get("edges", [])
                scopes = set()
                for edge in asm_edges_all:
                    if edge.get("source") in start_nodes or edge.get("target") in start_nodes:
                        if edge.get("scope"):
                            scopes.add(edge.get("scope"))
                if not scopes:
                    scopes = {None}

                asm_reached = []
                for s in start_nodes:
                    for scope in scopes:
                        if scope:
                            fwd, rev = bfs_edges_scoped(stitched_asm, s, scope)
                        else:
                            asm_fwd, asm_rev = build_adj(asm_edges_all)
                            fwd, rev = asm_fwd, asm_rev
                        if args.direction in ("forward", "both"):
                            asm_reached.extend(bfs_edges(fwd, s))
                        if args.direction in ("backward", "both"):
                            asm_reached.extend(bfs_edges(rev, s))

                if asm_reached:
                    asm_reached = filter_r1_noise(asm_reached, var)
                    print("ASM lineage:", file=out)
                    dump_edges_by_location(asm_reached, out)

                # Bridge into C++ via parameter:arg@<callee>:R*
                arg_nodes = set()
                for edge in asm_reached:
                    for node_id in (edge.get("source"), edge.get("target")):
                        if isinstance(node_id, str) and node_id.startswith("parameter:arg@"):
                            arg_nodes.add(node_id)

                if not arg_nodes:
                    print("No ASM→C++ arg bridge nodes found.", file=out)
                else:
                    cpp_edges = cpp_data.get("variable_lineage", {}).get("edges", [])
                    cpp_fwd, cpp_rev = build_adj(cpp_edges)
                    cpp_reached = []
                    # Seed C++ traversal from arg nodes, and pull in immediate parameter targets.
                    cpp_starts = set(arg_nodes)
                    for e in cpp_edges:
                        if e.get("source") in cpp_starts and isinstance(e.get("target"), str) and e.get("target").startswith("parameter:"):
                            cpp_starts.add(e.get("target"))
                    cpp_starts = expand_cpp_start_nodes(cpp_nodes, cpp_starts)
                    for n in sorted(cpp_starts):
                        if args.direction in ("forward", "both"):
                            cpp_reached.extend(bfs_edges(cpp_fwd, n))
                        if args.direction in ("backward", "both"):
                            cpp_reached.extend(bfs_edges(cpp_rev, n))
                    if cpp_reached:
                        print("C++ lineage:", file=out)
                        dump_edges_by_location(cpp_reached, out)
                    else:
                        print("No C++ edges reachable from ASM arg bridge nodes.", file=out)

        if args.include_global:
            global_edges = cpp_data.get("global_variable_lineage", {}).get("edges", [])
            matches = []
            for e in global_edges:
                if source_matches_var(e.get("source", ""), var) or source_matches_var(e.get("target", ""), var):
                    matches.append(e)
            if matches:
                print(f"Global lineage matches for {var}:", file=out)
                by_loc = defaultdict(list)
                for e in matches:
                    by_loc[(e.get("file"), e.get("line"))].append(e)
                for (file_path, line) in sorted(by_loc, key=lambda x: (x[0] or "", x[1] or -1)):
                    print_chunk(file_path, line, by_loc[(file_path, line)], out)

    print(f"Wrote: {output_path}")


if __name__ == "__main__":
    main()
