#!/usr/bin/env python3
"""Validate dep_var quality in a cross-file lineage JSON output.

Usage:
    # Mode 1: pre-blueprint-regen (static DC list)
    python3 validate_dep_vars.py LG1OSI_cross_lineage_12.json

    # Mode 2: blueprint-aware (reads type=dc from .asm.json blueprints)
    python3 validate_dep_vars.py LG1OSI_cross_lineage_12.json --blueprint-dir temp/output_latest/asm

Exit codes: 0 = clean, 1 = LITERAL or PATTERN_FAIL tokens found.
"""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Dict, Optional, Set
from blueprint_io import load_blueprint

VALID_SYMBOL = re.compile(r"^[A-Z@$_][A-Z0-9@$_]*$")

STATIC_DC_CONSTANTS: Set[str] = {
    "ZEROS", "BLANKS", "PKDZERO", "HEXFF", "CHARF",
    "SPACES", "WCT", "CZEROS",
}



def load_blueprint_dc_constants(blueprint_dir: Path) -> Set[str]:
    """Load DC-defined symbol names from all .asm.json files in a directory."""
    constants: Set[str] = set()
    for bp_file in blueprint_dir.glob("*.asm.json"):
        try:
            data = load_blueprint(bp_file)
            syms = data.get("symbols", {})
            scopes = [syms.get("global_symbols", {})] + [
                sec.get("symbols", {}) for sec in syms.get("sections", {}).values()
            ]
            for scope in scopes:
                for name, sym in (scope or {}).items():
                    if (sym.get("type") or sym.get("symbol_type")) == "dc":
                        constants.add(name.upper())
        except Exception:
            continue
    return constants


def collect_all_dep_vars(data: dict) -> Dict[str, list]:
    """Walk the JSON and collect all dep_var occurrences.

    Returns {token: [path_str, ...]} where path_str describes where it was found.
    """
    occurrences: Dict[str, list] = {}

    def walk(obj, path: str) -> None:
        if isinstance(obj, dict):
            for k, v in obj.items():
                p = f"{path}.{k}"
                if k in ("dependent_variables", "related_variables_discovered") and isinstance(v, list):
                    for item in v:
                        if isinstance(item, str):
                            occurrences.setdefault(item, []).append(p)
                else:
                    walk(v, p)
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                walk(item, f"{path}[{i}]")

    walk(data, "root")
    return occurrences


def classify(token: str, dc_constants: Set[str]) -> str:
    """Classify a dep_var token AS STORED in the JSON (no re-normalization)."""
    if token.startswith("="):
        return "LITERAL"
    if not VALID_SYMBOL.match(token):
        return "PATTERN_FAIL"
    if token in dc_constants:
        return "DC_CONSTANT"
    return "CLEAN"


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate dep_var quality in cross-lineage JSON.")
    parser.add_argument("input", help="Path to cross-lineage JSON file")
    parser.add_argument("--blueprint-dir", help="Path to .asm.json blueprint directory (enables blueprint-aware DC detection)")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"ERROR: File not found: {input_path}", file=sys.stderr)
        return 1

    data = json.loads(input_path.read_text(encoding="utf-8"))

    if args.blueprint_dir:
        bp_dir = Path(args.blueprint_dir)
        dc_constants = load_blueprint_dc_constants(bp_dir)
        mode = f"blueprint-aware ({len(dc_constants)} DC symbols loaded)"
    else:
        dc_constants = STATIC_DC_CONSTANTS
        mode = f"static list ({len(dc_constants)} known DC constants)"

    print(f"Validating: {input_path.name}")
    print(f"DC detection: {mode}")
    print()

    occurrences = collect_all_dep_vars(data)

    categories: Dict[str, list] = {"LITERAL": [], "PATTERN_FAIL": [], "DC_CONSTANT": [], "CLEAN": []}
    for token in sorted(occurrences):
        cat = classify(token, dc_constants)
        categories[cat].append(token)

    total = sum(len(v) for v in categories.values())
    print(f"{'Category':<15} {'Count':>6}  Examples")
    print("-" * 70)
    for cat in ("LITERAL", "PATTERN_FAIL", "DC_CONSTANT", "CLEAN"):
        tokens = categories[cat]
        examples = ", ".join(repr(t) for t in tokens[:5])
        if len(tokens) > 5:
            examples += f" ... (+{len(tokens)-5} more)"
        print(f"{cat:<15} {len(tokens):>6}  {examples}")
    print("-" * 70)
    print(f"{'TOTAL':<15} {total:>6}")
    print()

    bad = len(categories["LITERAL"]) + len(categories["PATTERN_FAIL"])
    if bad:
        print(f"FAIL: {bad} token(s) should have been filtered by Layer 1.", file=sys.stderr)
        if categories["LITERAL"]:
            print("  LITERAL tokens:", categories["LITERAL"], file=sys.stderr)
        if categories["PATTERN_FAIL"]:
            print("  PATTERN_FAIL tokens:", categories["PATTERN_FAIL"], file=sys.stderr)
        return 1

    if categories["DC_CONSTANT"]:
        print(f"INFO: {len(categories['DC_CONSTANT'])} DC constant(s) still present (Layer 2 not yet active or blueprint not regenerated).")
    else:
        print("OK: All dep_vars pass validation.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
