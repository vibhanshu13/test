#!/usr/bin/env python3
"""Dev CLI: interactive chatbot for a variable lineage, using chunk_cli.py output.

Builds context in-memory from chunk output (tuple_facts derived from tuple
metadata) without needing the API server or an explain session file.
If explain_cli.py has already been run and produced explanations, they will
NOT be available here — this CLI builds its own lightweight context from the
raw chunk data. For richer context, run explain_cli.py first then use the
API /chat endpoint against a real explain session.

Usage:

    # Interactive REPL (requires GEMINI_API_KEY)
    GEMINI_API_KEY=your_key python chat_cli.py /tmp/lg1osi_chunks

    # One-shot question
    GEMINI_API_KEY=your_key python chat_cli.py /tmp/lg1osi_chunks \\
        --question "What triggers LG1OSI to be set?"

    # Dry-run: print assembled context + prompt without calling LLM
    python chat_cli.py /tmp/lg1osi_chunks --question "What triggers LG1OSI?" --dry-run
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def _load_tuple(output_dir: Path, variable: str, idx: int) -> dict | None:
    path = output_dir / f"{variable.upper()}_tuple_{idx}.json"
    if not path.exists():
        return None
    page = json.loads(path.read_text(encoding="utf-8"))
    return page.get("tuple")


def _build_in_memory_explain_session(
    output_dir: Path,
    variable: str,
    index_map: list[dict],
) -> dict:
    """Derive tuple_facts from chunk metadata — no LLM calls needed.

    Simulates the explain session's tuple_facts dict so that _assemble_context()
    has something useful to work with even without a real explain session.
    Explanations are left empty (only available after running explain_cli.py or
    calling the API explain-variable endpoints).
    """
    from llm.variable_explainer import _extract_tuple_fact

    tuple_facts: dict[str, str] = {}
    for entry in index_map:
        idx = entry["tuple_index"]
        tuple_data = _load_tuple(output_dir, variable, idx)
        if tuple_data is not None:
            tuple_facts[str(idx)] = _extract_tuple_fact(tuple_data, variable)

    return {
        "version": 1,
        "root_variable": variable.upper(),
        "tuple_facts": tuple_facts,
        "explanations": {},   # empty — explain_cli.py not run
    }


def main() -> int:
    p = argparse.ArgumentParser(
        description="Interactive variable lineage chatbot (CLI mode)."
    )
    p.add_argument(
        "output_dir",
        help="Directory produced by chunk_cli.py (contains *_tuple_*.json and tuple_index_map.json).",
    )
    p.add_argument(
        "--question", "-q",
        default=None,
        help="One-shot question. If omitted, enter interactive REPL.",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the assembled context + prompt without calling the LLM.",
    )
    args = p.parse_args()

    output_dir = Path(args.output_dir).resolve()
    if not output_dir.exists():
        print(f"ERROR: output_dir does not exist: {output_dir}", file=sys.stderr)
        return 1

    index_map_path = output_dir / "tuple_index_map.json"
    if not index_map_path.exists():
        print(f"ERROR: no tuple_index_map.json in {output_dir}", file=sys.stderr)
        print("Run chunk_cli.py first to generate the tuples.", file=sys.stderr)
        return 1

    index_map: list[dict] = json.loads(index_map_path.read_text(encoding="utf-8"))
    if not index_map:
        print("ERROR: tuple_index_map.json is empty.", file=sys.stderr)
        return 1

    first_page_path = output_dir / index_map[0]["file"]
    first_page = json.loads(first_page_path.read_text(encoding="utf-8"))
    variable: str       = first_page["root_variable"]
    selected_chain: list[str] = first_page.get("selected_chain") or []

    if not args.dry_run:
        api_key = os.environ.get("GEMINI_API_KEY", "").strip()
        if not api_key:
            print(
                "ERROR: GEMINI_API_KEY env var is not set. "
                "Use --dry-run to test without LLM.",
                file=sys.stderr,
            )
            return 1
        os.environ["GEMINI_API_KEY"] = api_key

    from llm.variable_chat import _assemble_context, _build_chat_prompt, _SYSTEM_PROMPT

    # Prefer the saved explain session from explain_cli.py (has real LLM explanations).
    # Fall back to building tuple_facts in-memory from raw chunk metadata.
    saved_session_path = output_dir / "explain_session.json"
    if saved_session_path.exists():
        explain_session = json.loads(saved_session_path.read_text(encoding="utf-8"))
        # selected_chain may be stored in the session file; use it if available
        if explain_session.get("selected_chain"):
            selected_chain = explain_session["selected_chain"]
        session_source = f"explain_session.json ({len(explain_session.get('explanations', {}))} explanation(s) loaded)"
    else:
        explain_session = _build_in_memory_explain_session(output_dir, variable, index_map)
        session_source = "tuple-facts only (run explain_cli.py for richer context)"

    chain_str = " → ".join(selected_chain) if selected_chain else "(unknown)"
    print(f"Variable : {variable}")
    print(f"Chain    : {chain_str}")
    print(f"Tuples   : {len(index_map)}")
    print(f"Context  : {session_source}")
    print()

    messages: list[dict] = []

    def _ask(question: str) -> str:
        context = _assemble_context(variable, selected_chain, explain_session)
        prompt  = _build_chat_prompt(question, messages, context)

        if args.dry_run:
            print("--- SYSTEM PROMPT ---")
            print(_SYSTEM_PROMPT)
            print("--- PROMPT ---")
            print(prompt)
            return "(dry-run: no LLM call)"

        from llm.caller import call_llm
        return call_llm(prompt, system_prompt=_SYSTEM_PROMPT)

    if args.question:
        reply = _ask(args.question)
        print(reply)
        return 0

    # Interactive REPL
    print("Type your question and press Enter. Type 'exit' or Ctrl-C to quit.\n")
    while True:
        try:
            question = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print()
            break

        if not question:
            continue
        if question.lower() in ("exit", "quit"):
            break

        if args.dry_run:
            _ask(question)
        else:
            print("Assistant: ", end="", flush=True)
            reply = _ask(question)
            print(reply)
            messages.append({"role": "user",      "content": question})
            messages.append({"role": "assistant", "content": reply})
        print()

    return 0


if __name__ == "__main__":
    sys.exit(main())
