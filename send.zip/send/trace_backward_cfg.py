#!/usr/bin/env python3
"""Backward CFG anchor tracer (line/block modes) for assembler blueprints.

Produces block-level graph JSON by reusing the backward traversal engine from
trace_lineage.py and the block graph serializer from forward_trace_lineage.py.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple

from blueprint_io import load_blueprint
from cross_file_bridge import _discover_asm_dir, _discover_blueprint_dir
from forward_trace_lineage import build_block_graph_from_lineage_graph
from trace_lineage import LineageTracer, TraceResults, build_label_map, build_lineage_graph, expand_macro_branches, load_asm_lines


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Trace backward CFG from a line anchor or block anchor.")
    p.add_argument(
        "--asm-file",
        required=True,
        help="ASM source path or stem (e.g., /path/da76.asm or da76).",
    )
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument("--line", type=int, help="Anchor source line number (1-based).")
    mode.add_argument("--block", help="Anchor block id (case-insensitive).")
    p.add_argument(
        "--asm-dir",
        default=None,
        metavar="DIR",
        help="Directory containing ASM sources (default: auto-discover).",
    )
    p.add_argument(
        "--blueprint-dir",
        default=None,
        metavar="DIR",
        help="Directory containing blueprint JSON files (default: auto-discover).",
    )
    p.add_argument(
        "--blueprint-file",
        default=None,
        metavar="FILE",
        help="Explicit blueprint JSON path override.",
    )
    p.add_argument(
        "--output",
        default=None,
        metavar="FILE",
        help="Output JSON path (default: <stem>_backward_cfg_<mode>.json).",
    )
    return p.parse_args()


def _resolve_source_file(asm_file_arg: str, asm_dir: Optional[Path]) -> Optional[Path]:
    raw = Path(asm_file_arg).expanduser()
    candidates: List[Path] = []

    # Direct path first.
    candidates.append(raw)
    if not raw.is_absolute():
        candidates.append((Path.cwd() / raw))

    # Stem/path fallback under asm_dir.
    if asm_dir is not None:
        candidates.append(asm_dir / asm_file_arg)
        if raw.suffix == "":
            candidates.append(asm_dir / f"{asm_file_arg}.asm")
            candidates.append(asm_dir / f"{asm_file_arg}.cpp")

    seen: Set[str] = set()
    for candidate in candidates:
        key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        if candidate.exists() and candidate.is_file():
            return candidate.resolve()
    return None


def _infer_blueprint_path(
    source_file: Path,
    blueprint_dir: Optional[Path],
    blueprint_file_override: Optional[str],
) -> Optional[Path]:
    if blueprint_file_override:
        path = Path(blueprint_file_override).expanduser()
        return path.resolve() if path.exists() else None

    candidates: List[Path] = []
    if blueprint_dir is not None:
        candidates.append(blueprint_dir / f"{source_file.name}.json")
        candidates.append(blueprint_dir / f"{source_file.stem}.asm.json")
        candidates.append(blueprint_dir / f"{source_file.stem}.cpp.json")

    candidates.append(source_file.with_name(f"{source_file.name}.json"))
    candidates.append(source_file.with_name(f"{source_file.stem}.asm.json"))
    candidates.append(source_file.with_name(f"{source_file.stem}.cpp.json"))

    seen: Set[str] = set()
    for candidate in candidates:
        key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        if candidate.exists() and candidate.is_file():
            return candidate.resolve()
    return None


def _block_line_span(tracer: LineageTracer, block: Dict[str, Any]) -> Tuple[int, int]:
    start = tracer._block_start_line(block)
    end = tracer._block_end_line(block)
    if start >= 10**9:
        start = 0
    return int(start), int(end)


def _resolve_block_from_line(
    tracer: LineageTracer,
    line_no: int,
    blocks: Sequence[Dict[str, Any]],
    source_file: Path,
) -> Tuple[Optional[Dict[str, Any]], List[Dict[str, Any]]]:
    warnings: List[Dict[str, Any]] = []
    candidates: List[Dict[str, Any]] = [b for b in blocks if tracer._line_in_block(line_no, b)]
    if not candidates:
        return None, warnings

    if len(candidates) == 1:
        return candidates[0], warnings

    def rank(block: Dict[str, Any]) -> Tuple[int, int]:
        start, end = _block_line_span(tracer, block)
        span = (end - start) if (start > 0 and end > 0 and end >= start) else 10**9
        return span, start if start > 0 else 10**9

    chosen = sorted(candidates, key=rank)[0]
    warnings.append(
        {
            "file": source_file.name,
            "block": str(chosen.get("id", "")),
            "line": int(line_no),
            "message": (
                "Line matched multiple blocks; chose smallest enclosing block "
                f"'{chosen.get('id', '')}'."
            ),
        }
    )
    return chosen, warnings


def _resolve_block_by_id(
    block_id: str,
    block_map: Dict[str, Dict[str, Any]],
) -> Tuple[Optional[str], Optional[Dict[str, Any]]]:
    block = block_map.get(block_id)
    if block is not None:
        return block_id, block
    target_upper = str(block_id).upper()
    for bid, b in block_map.items():
        if str(bid).upper() == target_upper:
            return str(bid), b
    return None, None


def _anchor_line_for_block(tracer: LineageTracer, block: Dict[str, Any]) -> int:
    start, _ = _block_line_span(tracer, block)
    return int(start) if start > 0 else 0


def _result_error(
    message: str,
    mode: str,
    source_file: Optional[Path] = None,
    anchor: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return {
        "mode": mode,
        "asm_file": source_file.name if source_file else None,
        "anchor": anchor or {},
        "graph_level": "block",
        "nodes": [],
        "edges": [],
        "dependent_files": [],
        "unresolved_files": [],
        "data_quality_warnings": [],
        "error": message,
    }


def _write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    args = _parse_args()
    mode = "line" if args.line is not None else "block"

    blueprint_dir = Path(args.blueprint_dir).expanduser().resolve() if args.blueprint_dir else _discover_blueprint_dir()
    if blueprint_dir is not None and not blueprint_dir.exists():
        print(f"ERROR: Blueprint dir not found: {blueprint_dir}", file=sys.stderr)
        return 1

    asm_dir: Optional[Path]
    if args.asm_dir:
        asm_dir = Path(args.asm_dir).expanduser().resolve()
        if not asm_dir.exists():
            print(f"ERROR: ASM dir not found: {asm_dir}", file=sys.stderr)
            return 1
    else:
        asm_dir = _discover_asm_dir(blueprint_dir) if blueprint_dir else None

    source_file = _resolve_source_file(args.asm_file, asm_dir)
    if source_file is None:
        print(
            "ERROR: Could not resolve --asm-file. Pass an absolute path or set --asm-dir.",
            file=sys.stderr,
        )
        return 1

    blueprint_file = _infer_blueprint_path(source_file, blueprint_dir, args.blueprint_file)
    if blueprint_file is None:
        print(
            f"ERROR: Could not resolve blueprint for {source_file.name}. "
            "Pass --blueprint-file or --blueprint-dir.",
            file=sys.stderr,
        )
        return 1

    if blueprint_dir is None:
        blueprint_dir = blueprint_file.parent
    if asm_dir is None:
        asm_dir = source_file.parent

    output_path = (
        Path(args.output).expanduser().resolve()
        if args.output
        else (source_file.parent / "output" / f"{source_file.stem}_backward_cfg_{mode}.json").resolve()
    )

    tracer = LineageTracer(asm_dir=asm_dir, blueprint_dir=blueprint_dir)
    results = TraceResults()

    try:
        blueprint = load_blueprint(blueprint_file)
    except Exception as exc:
        payload = _result_error(
            message=f"Failed to read blueprint: {exc}",
            mode=mode,
            source_file=source_file,
        )
        _write_json(output_path, payload)
        print(f"Wrote error output to: {output_path}", file=sys.stderr)
        return 1

    blocks = blueprint.get("blocks", []) or []
    block_map: Dict[str, Dict[str, Any]] = {str(b.get("id", "")): b for b in blocks}
    blocks_in_order = sorted(blocks, key=tracer._block_start_line)
    root_block_id = str(blocks_in_order[0].get("id", "")) if blocks_in_order else ""

    if not blocks:
        payload = _result_error(
            message="Blueprint has no executable blocks.",
            mode=mode,
            source_file=source_file,
        )
        _write_json(output_path, payload)
        print(f"Wrote error output to: {output_path}", file=sys.stderr)
        return 1

    asm_lines = expand_macro_branches(load_asm_lines(source_file))
    label_map = build_label_map(asm_lines)
    subroutines = blueprint.get("subroutines", []) or []

    anchor: Dict[str, Any]
    anchor_block_id: str
    anchor_block: Dict[str, Any]
    pivot_line: int
    focus_line: int
    skip_cross_file = False

    if mode == "line":
        line_no = int(args.line)
        if line_no <= 0:
            payload = _result_error(
                message="--line must be a positive integer.",
                mode=mode,
                source_file=source_file,
                anchor={"line": line_no},
            )
            _write_json(output_path, payload)
            print(f"Wrote error output to: {output_path}", file=sys.stderr)
            return 1

        resolved_block, resolution_warnings = _resolve_block_from_line(tracer, line_no, blocks, source_file)
        results.data_quality_warnings.extend(resolution_warnings)
        if resolved_block is None:
            payload = _result_error(
                message=f"Line {line_no} is outside executable blocks in blueprint.",
                mode=mode,
                source_file=source_file,
                anchor={"line": line_no},
            )
            payload["data_quality_warnings"] = results.data_quality_warnings
            _write_json(output_path, payload)
            print(f"Wrote error output to: {output_path}", file=sys.stderr)
            return 1

        anchor_block = resolved_block
        anchor_block_id = str(anchor_block.get("id", ""))
        pivot_line = line_no
        focus_line = line_no
        anchor = {"type": "LINE_ANCHOR", "line": line_no, "block": anchor_block_id}
        results.lineage_chain.append(
            {
                "file": source_file.name,
                "line": line_no,
                "block": anchor_block_id,
                "inst": "(line-anchor)",
                "role": "LINE_ANCHOR",
                "detail": f"Anchor at source line {line_no}",
                "depth": 0,
            }
        )
    else:
        block_id = str(args.block)
        resolved_id, resolved_block = _resolve_block_by_id(block_id, block_map)
        if resolved_block is None or resolved_id is None:
            payload = _result_error(
                message=f"Block '{block_id}' not found in blueprint.",
                mode=mode,
                source_file=source_file,
                anchor={"block": block_id},
            )
            _write_json(output_path, payload)
            print(f"Wrote error output to: {output_path}", file=sys.stderr)
            return 1

        anchor_block = resolved_block
        anchor_block_id = resolved_id
        anchor_line = _anchor_line_for_block(tracer, anchor_block)
        pivot_line = 0
        focus_line = 0
        skip_cross_file = True
        anchor = {"type": "BLOCK_ANCHOR", "block": anchor_block_id, "line": anchor_line}
        results.lineage_chain.append(
            {
                "file": source_file.name,
                "line": anchor_line,
                "block": anchor_block_id,
                "inst": "(block-anchor)",
                "role": "BLOCK_ANCHOR",
                "detail": f"Anchor at block {anchor_block_id}",
                "depth": 0,
            }
        )

    visited_blocks: Set[str] = set()
    visited_block_calls: Set[str] = set()

    tracer._backward_trace(
        block=anchor_block,
        pivot_line=pivot_line,
        focus_block_id=anchor_block_id,
        focus_line=focus_line,
        depth=0,
        block_map=block_map,
        blocks_in_order=blocks_in_order,
        root_block_id=root_block_id,
        label_map=label_map,
        match_names={"__CFG_ANCHOR__"},
        subroutines=subroutines,
        source_asm_file=source_file,
        asm_lines=asm_lines,
        visited_blocks=visited_blocks,
        visited_block_calls=visited_block_calls,
        results=results,
        skip_cross_file_discovery=skip_cross_file,
    )

    tracer._post_process(results)

    line_graph = build_lineage_graph(
        target_variable="CFG_ANCHOR",
        source_asm_file=source_file,
        results=results,
        dep_var_traces=None,
        blueprint_file=blueprint_file,
        blueprint_dir=blueprint_dir,
        asm_dir=asm_dir,
    )
    block_graph = build_block_graph_from_lineage_graph(line_graph)

    subroutine_ids = {str(s.get("id", "")).upper() for s in subroutines}
    for node in block_graph.get("nodes", []) or []:
        block_id = str(node.get("block", "")).upper()
        node["node_type"] = "SUBROUTINE" if block_id in subroutine_ids else "BLOCK"

    payload: Dict[str, Any] = {
        "mode": mode,
        "asm_file": source_file.name,
        "anchor": anchor,
        "graph_level": "block",
        "nodes": block_graph.get("nodes", []),
        "edges": block_graph.get("edges", []),
        "dependent_files": results.dependent_files,
        "unresolved_files": results.unresolved_files,
        "data_quality_warnings": results.data_quality_warnings,
    }

    _write_json(output_path, payload)
    print(f"Wrote backward CFG graph to: {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
