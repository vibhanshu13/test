"""Parser for conditional assembly directives.

This module provides parsing functionality for z/TPF conditional assembly
directives including AIF, AGO, ANOP, SETA, SETB, and SETC.
"""

import re
from typing import Optional, Dict, Any
from models.conditional_assembly import (
    AIFDirective,
    AGODirective,
    ANOPDirective
)


class ConditionalParser:
    """Parser for conditional assembly directives.

    Handles parsing of:
    - AIF: Conditional branch directive
    - AGO: Unconditional branch directive
    - ANOP: Sequence symbol label directive
    - SETA: Arithmetic SET symbol directive
    - SETB: Boolean SET symbol directive
    - SETC: Character SET symbol directive
    """

    def __init__(self):
        """Initialize the conditional parser with regex patterns.

        All patterns are case-insensitive to handle various assembly styles.
        """
        # AIF: Captures condition within parentheses and target sequence symbol
        # Example: "         AIF   (&VAR EQ 1).LABEL1"
        self.aif_pattern = re.compile(
            r'^\s*AIF\s+\(([^)]+)\)(\.\w+)',
            re.IGNORECASE
        )

        # AGO: Captures target sequence symbol
        # Example: "         AGO   .DONE"
        self.ago_pattern = re.compile(
            r'^\s*AGO\s+(\.\w+)',
            re.IGNORECASE
        )

        # ANOP: Captures label (sequence symbol)
        # Example: ".START   ANOP"
        self.anop_pattern = re.compile(
            r'^(\.\w+)\s+ANOP',
            re.IGNORECASE
        )

        # SETA: Captures symbol name and value/expression
        # Example: "&COUNT   SETA  5"
        self.seta_pattern = re.compile(
            r'^(&\w+)\s+SETA\s+(.+)',
            re.IGNORECASE
        )

        # SETB: Captures symbol name and value/expression
        # Example: "&FLAG    SETB  1"
        self.setb_pattern = re.compile(
            r'^(&\w+)\s+SETB\s+(.+)',
            re.IGNORECASE
        )

        # SETC: Captures symbol name and value/expression
        # Example: "&NAME    SETC  'TEST'"
        self.setc_pattern = re.compile(
            r'^(&\w+)\s+SETC\s+(.+)',
            re.IGNORECASE
        )

    def is_conditional_directive(self, line: str) -> bool:
        """Check if a line contains a conditional assembly directive.

        Args:
            line: Assembly source line to check

        Returns:
            True if line contains a conditional directive (AIF, AGO, ANOP, SETA, SETB, SETC)
        """
        if not line or not line.strip():
            return False

        # Check if line starts with comment
        if line.lstrip().startswith('*'):
            return False

        # Check each directive pattern
        return bool(
            self.aif_pattern.search(line) or
            self.ago_pattern.search(line) or
            self.anop_pattern.search(line) or
            self.seta_pattern.search(line) or
            self.setb_pattern.search(line) or
            self.setc_pattern.search(line)
        )

    def parse_aif(self, line: str, line_number: int) -> Optional[AIFDirective]:
        """Parse an AIF (conditional branch) directive.

        AIF format: "         AIF   (condition).target"

        Args:
            line: Assembly source line to parse
            line_number: Source line number for provenance tracking

        Returns:
            AIFDirective object if successfully parsed, None otherwise

        Example:
            >>> parser = ConditionalParser()
            >>> result = parser.parse_aif("         AIF   (&VAR EQ 1).LABEL1", 10)
            >>> result.condition
            '&VAR EQ 1'
            >>> result.target
            '.LABEL1'
        """
        match = self.aif_pattern.search(line)
        if not match:
            return None

        condition = match.group(1).strip()
        target = match.group(2).strip()

        return AIFDirective(
            condition=condition,
            target=target,
            source_line=line_number
        )

    def parse_ago(self, line: str, line_number: int) -> Optional[AGODirective]:
        """Parse an AGO (unconditional branch) directive.

        AGO format: "         AGO   .target"

        Args:
            line: Assembly source line to parse
            line_number: Source line number for provenance tracking

        Returns:
            AGODirective object if successfully parsed, None otherwise

        Example:
            >>> parser = ConditionalParser()
            >>> result = parser.parse_ago("         AGO   .DONE", 20)
            >>> result.target
            '.DONE'
        """
        match = self.ago_pattern.search(line)
        if not match:
            return None

        target = match.group(1).strip()

        return AGODirective(
            target=target,
            source_line=line_number
        )

    def parse_anop(self, line: str, line_number: int) -> Optional[ANOPDirective]:
        """Parse an ANOP (sequence symbol label) directive.

        ANOP format: ".label   ANOP"

        Args:
            line: Assembly source line to parse
            line_number: Source line number for provenance tracking

        Returns:
            ANOPDirective object if successfully parsed, None otherwise

        Example:
            >>> parser = ConditionalParser()
            >>> result = parser.parse_anop(".START   ANOP", 5)
            >>> result.label
            '.START'
        """
        match = self.anop_pattern.search(line)
        if not match:
            return None

        label = match.group(1).strip()

        return ANOPDirective(
            label=label,
            source_line=line_number
        )

    def parse_seta(self, line: str, line_number: int) -> Optional[Dict[str, Any]]:
        """Parse a SETA (arithmetic SET) directive.

        SETA format: "&symbol   SETA  value"

        Args:
            line: Assembly source line to parse
            line_number: Source line number for provenance tracking

        Returns:
            Dictionary with symbol, value, and type if successfully parsed, None otherwise
            - value is parsed as int if possible, otherwise stored as expression string

        Example:
            >>> parser = ConditionalParser()
            >>> result = parser.parse_seta("&COUNT   SETA  5", 15)
            >>> result
            {'symbol': '&COUNT', 'value': 5, 'type': 'arithmetic'}

            >>> result = parser.parse_seta("&COUNT   SETA  &VAR+1", 15)
            >>> result
            {'symbol': '&COUNT', 'value': '&VAR+1', 'type': 'arithmetic'}
        """
        match = self.seta_pattern.search(line)
        if not match:
            return None

        symbol = match.group(1).strip()
        value_str = match.group(2).strip()

        # Try to parse as integer, otherwise store as expression
        try:
            value = int(value_str)
        except ValueError:
            value = value_str

        return {
            "symbol": symbol,
            "value": value,
            "type": "arithmetic"
        }

    def parse_setb(self, line: str, line_number: int) -> Optional[Dict[str, Any]]:
        """Parse a SETB (boolean SET) directive.

        SETB format: "&symbol   SETB  value"

        Args:
            line: Assembly source line to parse
            line_number: Source line number for provenance tracking

        Returns:
            Dictionary with symbol, value, and type if successfully parsed, None otherwise
            - value is converted to boolean (1/T/TRUE → True, else False)

        Example:
            >>> parser = ConditionalParser()
            >>> result = parser.parse_setb("&FLAG    SETB  1", 10)
            >>> result
            {'symbol': '&FLAG', 'value': True, 'type': 'boolean'}

            >>> result = parser.parse_setb("&FLAG    SETB  0", 10)
            >>> result
            {'symbol': '&FLAG', 'value': False, 'type': 'boolean'}
        """
        match = self.setb_pattern.search(line)
        if not match:
            return None

        symbol = match.group(1).strip()
        value_str = match.group(2).strip().upper()

        # Convert to boolean: 1, T, TRUE → True, else False
        value = value_str in ('1', 'T', 'TRUE')

        return {
            "symbol": symbol,
            "value": value,
            "type": "boolean"
        }

    def parse_setc(self, line: str, line_number: int) -> Optional[Dict[str, Any]]:
        """Parse a SETC (character SET) directive.

        SETC format: "&symbol   SETC  'value'" or "&symbol   SETC  value"

        Args:
            line: Assembly source line to parse
            line_number: Source line number for provenance tracking

        Returns:
            Dictionary with symbol, value, and type if successfully parsed, None otherwise
            - quotes are stripped from value if present

        Example:
            >>> parser = ConditionalParser()
            >>> result = parser.parse_setc("&NAME    SETC  'TEST'", 25)
            >>> result
            {'symbol': '&NAME', 'value': 'TEST', 'type': 'character'}

            >>> result = parser.parse_setc("&NAME    SETC  TEST", 25)
            >>> result
            {'symbol': '&NAME', 'value': 'TEST', 'type': 'character'}
        """
        match = self.setc_pattern.search(line)
        if not match:
            return None

        symbol = match.group(1).strip()
        value_str = match.group(2).strip()

        # Strip quotes if present
        if value_str.startswith("'") and value_str.endswith("'"):
            value = value_str[1:-1]
        elif value_str.startswith('"') and value_str.endswith('"'):
            value = value_str[1:-1]
        else:
            value = value_str

        return {
            "symbol": symbol,
            "value": value,
            "type": "character"
        }
