"""Operation classification and conditional context tracking utilities."""

from typing import List, Optional, Set, Dict
from tokenizer import ParsedLine
import re


# ASM Instruction to Operation Type Mapping
ASM_OPERATION_MAP = {
    # Data Movement
    "MVC": "move",
    "MVCL": "move",
    "MVCIN": "move",
    "MVI": "move",
    "MVZ": "move",
    "MVN": "move",

    # Comparison
    "CLC": "compare",
    "CLI": "compare",
    "C": "compare",
    "CR": "compare",
    "CH": "compare",
    "CL": "compare",
    "CLR": "compare",

    # Load
    "L": "load",
    "LR": "load",
    "LA": "load",
    "LH": "load",
    "LM": "load",
    "LTR": "load",
    "LCR": "load",
    "LNR": "load",
    "LPR": "load",

    # Store
    "ST": "store",
    "STH": "store",
    "STM": "store",
    "STC": "store",

    # Arithmetic
    "A": "arithmetic",
    "AR": "arithmetic",
    "AH": "arithmetic",
    "AL": "arithmetic",
    "ALR": "arithmetic",
    "S": "arithmetic",
    "SR": "arithmetic",
    "SH": "arithmetic",
    "SL": "arithmetic",
    "SLR": "arithmetic",
    "M": "arithmetic",
    "MR": "arithmetic",
    "MH": "arithmetic",
    "D": "arithmetic",
    "DR": "arithmetic",

    # Logical
    "N": "logical",
    "NR": "logical",
    "O": "logical",
    "OR": "logical",
    "X": "logical",
    "XR": "logical",
    "NC": "logical",
    "OC": "logical",
    "XC": "logical",

    # Shift
    "SLA": "shift",
    "SRA": "shift",
    "SLL": "shift",
    "SRL": "shift",
    "SLDA": "shift",
    "SRDA": "shift",

    # Initialization/Declaration
    "DS": "initialize",
    "DC": "initialize",
    "EQU": "initialize",

    # Call
    "BAL": "call",
    "BALR": "call",
    "BAS": "call",
    "BASR": "call",
    "BASSM": "call",

    # Branch (conditional)
    "BC": "branch",
    "BCR": "branch",
    "BCT": "branch",
    "BCTR": "branch",
    "BXH": "branch",
    "BXLE": "branch",

    # Branch Extended Mnemonics
    "BE": "branch",
    "BNE": "branch",
    "BH": "branch",
    "BL": "branch",
    "BNH": "branch",
    "BNL": "branch",
    "BO": "branch",
    "BNO": "branch",
    "BP": "branch",
    "BM": "branch",
    "BZ": "branch",
    "BNZ": "branch",
}

# C/C++ AST node types to operation type mapping
CPP_OPERATION_MAP = {
    "declaration": "initialize",
    "assignment_expression": "assign",
    "update_expression": "modify",  # ++, --
    "call_expression": "call_arg",
    "binary_expression": "arithmetic",  # Will be refined based on operator
    "compound_assignment_operator": "modify",  # +=, -=, etc.
}


def classify_asm_operation(opcode: str) -> str:
    """Classify an ASM instruction into an operation type.

    Args:
        opcode: ASM instruction opcode

    Returns:
        Operation type string (move, compare, load, etc.) or "unknown"
    """
    if not opcode:
        return "unknown"

    opcode_upper = opcode.upper()
    return ASM_OPERATION_MAP.get(opcode_upper, "unknown")


def extract_variable_name(operand: str) -> str:
    """Extract variable name from an ASM operand.

    Handles various addressing modes:
    - BUFFER -> BUFFER
    - 0(R1) -> <empty> (register addressing)
    - BUFFER(R2) -> BUFFER
    - =V(SYMBOL) -> <empty> (literal)
    - LABEL+4 -> LABEL

    Args:
        operand: ASM operand string

    Returns:
        Variable name or empty string
    """
    if not operand:
        return ""

    # Remove whitespace
    operand = operand.strip()

    # Skip literals
    if operand.startswith("="):
        return ""

    # Skip numeric constants
    if operand.isdigit() or (operand.startswith("-") and operand[1:].isdigit()):
        return ""

    # Skip register-only references
    if operand.upper().startswith("R") and operand[1:].isdigit():
        return ""

    # Handle displacement addressing: BUFFER(R2) or 0(R1)
    if "(" in operand:
        base = operand.split("(")[0]
        # If base is numeric or empty, it's not a variable
        if not base or base.isdigit():
            return ""
        operand = base

    # Handle offset: LABEL+4 or LABEL-4
    if "+" in operand:
        operand = operand.split("+")[0]
    if "-" in operand:
        operand = operand.split("-")[0]

    # Remove any remaining special characters
    operand = re.sub(r'[^A-Za-z0-9_]', '', operand)

    return operand.strip()


def extract_variables_from_line(line: ParsedLine, var_set: Set[str]) -> List[str]:
    """Extract all variables that appear on a line.

    Args:
        line: Parsed assembly line
        var_set: Set of known variable names

    Returns:
        List of variable names found on this line
    """
    variables = []

    # Check label
    if line.label and line.label in var_set:
        variables.append(line.label)

    # Check operands
    if line.operands:
        for operand in line.operands:
            var_name = extract_variable_name(operand)
            if var_name and var_name in var_set:
                variables.append(var_name)

    return list(set(variables))  # Remove duplicates


class ConditionalContextTracker:
    """Tracks conditional context for variables in ASM code."""

    def __init__(self):
        self.recent_comparisons: List[Dict] = []
        self.max_history = 10  # Keep last 10 comparisons

    def process_line(self, line: ParsedLine, var_set: Set[str]):
        """Process a line and track comparisons/branches.

        Args:
            line: Parsed assembly line
            var_set: Set of known variable names
        """
        if not line.opcode:
            return

        opcode = line.opcode.upper()

        # Track comparisons involving variables
        if opcode in ("CLC", "CLI", "C", "CR", "CH", "CL", "CLR"):
            variables_in_comparison = extract_variables_from_line(line, var_set)

            if variables_in_comparison:
                condition = {
                    "variables": variables_in_comparison,
                    "condition": f"{opcode} {line.raw_text if hasattr(line, 'raw_text') else ''}",
                    "line": line.provenance.original_line if hasattr(line, 'provenance') else 0,
                    "file": line.provenance.original_file if hasattr(line, 'provenance') else "",
                    "branch_taken": None
                }
                self.recent_comparisons.append(condition)

                # Keep only recent history
                if len(self.recent_comparisons) > self.max_history:
                    self.recent_comparisons.pop(0)

        # Track branches (attach to most recent comparison)
        if opcode in ("BC", "BCR", "BNE", "BE", "BH", "BL", "BNH", "BNL", "BO", "BNO", "BP", "BM", "BZ", "BNZ"):
            if self.recent_comparisons:
                self.recent_comparisons[-1]["branch_taken"] = opcode

    def get_conditions_for_variable(self, var_name: str, max_conditions: int = 5) -> List[str]:
        """Get recent conditions that involve this specific variable.

        Args:
            var_name: Variable name
            max_conditions: Maximum number of conditions to return

        Returns:
            List of condition strings
        """
        conditions = []
        for comp in reversed(self.recent_comparisons):
            if var_name in comp["variables"]:
                cond_str = comp["condition"]
                if comp["branch_taken"]:
                    cond_str += f" -> {comp['branch_taken']}"
                conditions.append(cond_str)

                if len(conditions) >= max_conditions:
                    break

        return list(reversed(conditions))  # Return in chronological order

    def clear(self):
        """Clear all tracked conditions."""
        self.recent_comparisons.clear()


def get_transformation_description(opcode: str, operands: List[str]) -> str:
    """Get a human-readable description of what an operation does.

    Args:
        opcode: ASM instruction opcode
        operands: List of operands

    Returns:
        Description string
    """
    if not opcode:
        return ""

    opcode_upper = opcode.upper()
    op_type = classify_asm_operation(opcode)

    if op_type == "move":
        if len(operands) >= 2:
            return f"Move data from {operands[1]} to {operands[0]}"
        return "Move data"

    elif op_type == "compare":
        if len(operands) >= 2:
            return f"Compare {operands[0]} with {operands[1]}"
        return "Compare values"

    elif op_type == "load":
        if len(operands) >= 2:
            return f"Load {operands[1]} into {operands[0]}"
        return "Load value"

    elif op_type == "store":
        if len(operands) >= 2:
            return f"Store {operands[0]} to {operands[1]}"
        return "Store value"

    elif op_type == "arithmetic":
        if len(operands) >= 2:
            return f"Arithmetic operation on {operands[0]} and {operands[1]}"
        return "Arithmetic operation"

    elif op_type == "logical":
        if len(operands) >= 2:
            return f"Logical {opcode_upper} operation on {operands[0]} and {operands[1]}"
        return f"Logical {opcode_upper} operation"

    elif op_type == "shift":
        if len(operands) >= 2:
            return f"Shift {operands[0]} by {operands[1]}"
        return "Shift operation"

    elif op_type == "initialize":
        return f"Initialize with {opcode_upper}"

    elif op_type == "call":
        if operands:
            return f"Call routine via {operands[-1] if len(operands) > 1 else 'register'}"
        return "Call routine"

    return opcode_upper
