"""File reader with COPY directive expansion."""

from pathlib import Path
from typing import Iterator, List, Optional
from tokenizer import Tokenizer, ParsedLine
from statement_id_generator import StatementIDGenerator
from models.provenance import StatementProvenance
from models.copy_directive import CopyIncludeStack, parse_copy_directive
from conditional_parser import ConditionalParser
from conditional_evaluator import ConditionalEvaluator
from models.conditional_assembly import ConditionalAssemblyState


class FileReader:
    """Reads assembly files with COPY directive expansion.

    Handles:
    - COPY directive expansion
    - Circular include detection
    - Provenance tracking through includes
    """

    def __init__(
        self,
        id_gen: StatementIDGenerator,
        search_paths: Optional[List[str]] = None
    ):
        """Initialize file reader.

        Args:
            id_gen: Statement ID generator
            search_paths: Directories to search for COPY files
        """
        self.id_gen = id_gen
        self.search_paths = search_paths or ["."]
        self.tokenizer = Tokenizer()
        self.include_stack = CopyIncludeStack()
        self.conditional_parser = ConditionalParser()
        self.conditional_evaluator = ConditionalEvaluator()
        self.conditional_state = ConditionalAssemblyState()
        # Instance-level cache: include_name -> resolved path str, or None (not found).
        # Scoped to this FileReader (one job), so concurrent jobs can never cross-contaminate.
        # Do NOT use @functools.lru_cache here — that creates a global cache shared across
        # all instances/jobs, which would return wrong paths when two jobs have different
        # search_paths for the same include name.
        self._copy_cache: dict = {}

    def read_file(self, filepath: str) -> Iterator[ParsedLine]:
        """Read file and expand COPY directives.

        Args:
            filepath: Path to assembly file

        Yields:
            ParsedLine objects with provenance

        Raises:
            FileNotFoundError: If file or COPY target not found
        """
        self.include_stack.push(filepath)

        try:
            with open(filepath, 'r', encoding="latin-1") as f:
                for line_num, line in enumerate(f, start=1):
                    # Generate provenance
                    prov = StatementProvenance(
                        statement_id=self.id_gen.next_id(),
                        original_file=filepath,
                        original_line=line_num,
                        expanded_from_copy=None if self.include_stack.depth() == 1
                                          else self.include_stack.stack[-2]
                    )

                    # Tokenize
                    parsed = self.tokenizer.tokenize_line(line.rstrip('\n'), prov)

                    # Process conditional assembly directives
                    raw_line = line.rstrip('\n')
                    if self.conditional_parser.is_conditional_directive(raw_line):
                        # Handle ANOP (sequence label)
                        anop = self.conditional_parser.parse_anop(raw_line, line_num)
                        if anop:
                            self.conditional_state.define_sequence_label(anop.label, line_num)

                        # Handle SETA
                        seta = self.conditional_parser.parse_seta(raw_line, line_num)
                        if seta:
                            self.conditional_state.set_symbols.set_value(seta["symbol"], seta["value"])

                        # Handle SETB
                        setb = self.conditional_parser.parse_setb(raw_line, line_num)
                        if setb:
                            self.conditional_state.set_symbols.set_value(setb["symbol"], setb["value"])

                        # Handle SETC
                        setc = self.conditional_parser.parse_setc(raw_line, line_num)
                        if setc:
                            self.conditional_state.set_symbols.set_value(setc["symbol"], setc["value"])

                        # Handle AIF (conditional branch)
                        aif = self.conditional_parser.parse_aif(raw_line, line_num)
                        if aif:
                            can_eval = self.conditional_evaluator.can_evaluate(
                                aif.condition,
                                self.conditional_state.set_symbols
                            )
                            if can_eval:
                                result = self.conditional_evaluator.evaluate(
                                    aif.condition,
                                    self.conditional_state.set_symbols
                                )
                                # For now, just track - full skip logic would be implemented later
                                pass

                        # Handle AGO (unconditional branch)
                        ago = self.conditional_parser.parse_ago(raw_line, line_num)
                        if ago:
                            # For now, just track - full skip logic would be implemented later
                            pass

                    # Check if it's a COPY directive
                    copy_directive = parse_copy_directive(parsed)

                    if copy_directive:
                        # Expand COPY by recursively reading the included file
                        try:
                            included_path = self._find_copy_file(copy_directive.target_file)
                        except FileNotFoundError as e:
                            import sys
                            print(f"WARNING: Skipping missing COPY file: {e}", file=sys.stderr)
                            included_path = None

                        if included_path:
                            # Recursively read included file
                            yield from self.read_file(included_path)
                    else:
                        # Regular line
                        yield parsed
        finally:
            self.include_stack.pop()

    def _find_copy_file(self, filename: str) -> Optional[str]:
        """Find a COPY file in search paths.

        Args:
            filename: File to find

        Returns:
            Full path to file if found

        Raises:
            FileNotFoundError: If file not found in any search path
        """
        # Fast path: return cached result without any filesystem probing.
        if filename in self._copy_cache:
            cached = self._copy_cache[filename]
            if cached is None:
                raise FileNotFoundError(
                    f"COPY file not found: {filename}. "
                    f"Searched in: {', '.join(self.search_paths)}"
                )
            return cached

        # Slow path: probe filesystem, then cache the result.
        candidates = [filename]
        if not filename.lower().endswith(('.asm', '.cpy', '.mac')):
            candidates.append(f"{filename}.cpy")
            candidates.append(f"{filename.lower()}.cpy")
            candidates.append(f"{filename}.asm")
            candidates.append(f"{filename.lower()}.asm")
            candidates.append(f"{filename}.mac")
            candidates.append(f"{filename.lower()}.mac")

        for search_path in self.search_paths:
            for candidate in candidates:
                full_path = Path(search_path) / candidate
                if full_path.is_file():
                    self._copy_cache[filename] = str(full_path)
                    return str(full_path)

        self._copy_cache[filename] = None
        raise FileNotFoundError(
            f"COPY file not found: {filename}. "
            f"Searched in: {', '.join(self.search_paths)}"
        )
