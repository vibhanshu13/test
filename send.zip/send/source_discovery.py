"""Helpers for recursively discovering source files with generic exclusions."""

from __future__ import annotations

import fnmatch
import subprocess
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

DEFAULT_NON_PRODUCTION_DISCOVERY_PATTERNS: Tuple[str, ...] = (
    "test/",
    "tests/",
    "temp/",
    "tmp/",
    "fixture/",
    "fixtures/",
    "test_data/",
    "*_test.c",
    "*_test.cc",
    "*_test.cpp",
    "*_test.cxx",
    "test_*.c",
    "test_*.cc",
    "test_*.cpp",
    "test_*.cxx",
)


def merge_discovery_exclude_patterns(
    exclude_patterns: Optional[Sequence[str]] = None,
    *,
    include_test_sources: bool = False,
) -> List[str]:
    """Return effective recursive-discovery exclusions.

    By default we exclude common non-production paths (tests/temp/fixtures) so
    recursive scans prefer production code. Explicit file arguments are not
    affected by these defaults because they bypass recursive filtering.
    """
    combined: List[str] = []
    if not include_test_sources:
        combined.extend(DEFAULT_NON_PRODUCTION_DISCOVERY_PATTERNS)
    combined.extend(exclude_patterns or [])
    return _normalize_patterns(combined)


def filter_discovered_paths(
    candidates: Sequence[Tuple[Path, Path]],
    *,
    exclude_patterns: Optional[Sequence[str]] = None,
    respect_gitignore: bool = True,
) -> Tuple[List[Path], int]:
    """Filter recursively discovered paths using user globs and git ignore rules.

    Args:
        candidates: Sequence of ``(path, discovery_root)`` tuples.
        exclude_patterns: Optional glob patterns to exclude.
        respect_gitignore: When ``True``, drop paths ignored by git from each root.

    Returns:
        Tuple of ``(included_paths, excluded_count)``.
    """
    if not candidates:
        return [], 0

    normalized_patterns = _normalize_patterns(exclude_patterns or [])

    seen_paths: Set[Path] = set()
    ordered_candidates: List[Tuple[Path, Path]] = []
    for path, root in candidates:
        resolved_path = path.resolve()
        resolved_root = root.resolve()
        if resolved_path in seen_paths:
            continue
        seen_paths.add(resolved_path)
        ordered_candidates.append((resolved_path, resolved_root))

    remaining: List[Tuple[Path, Path]] = []
    excluded = 0
    for path, root in ordered_candidates:
        if _matches_any_pattern(path, root, normalized_patterns):
            excluded += 1
            continue
        remaining.append((path, root))

    if not respect_gitignore or not remaining:
        return [path for path, _ in remaining], excluded

    ignored_by_git: Set[Path] = set()
    git_root_cache: Dict[Path, Optional[Path]] = {}
    root_ignored_cache: Dict[Tuple[Path, Path], bool] = {}
    grouped_by_git_root: Dict[Path, List[Path]] = defaultdict(list)

    for path, root in remaining:
        git_root = _resolve_git_root(root, git_root_cache)
        if not git_root:
            continue
        if _is_git_ignored(git_root, root, root_ignored_cache):
            # If the caller explicitly chose an ignored root directory, we treat that
            # root as an inclusion scope and do not apply gitignore filtering inside it.
            continue
        try:
            path.relative_to(git_root)
        except ValueError:
            continue
        grouped_by_git_root[git_root].append(path)

    for git_root, paths in grouped_by_git_root.items():
        ignored_by_git.update(_git_ignored_paths(git_root, paths))

    included_paths: List[Path] = []
    for path, _ in remaining:
        if path in ignored_by_git:
            excluded += 1
            continue
        included_paths.append(path)

    return included_paths, excluded


def _normalize_patterns(patterns: Iterable[str]) -> List[str]:
    normalized: List[str] = []
    for raw in patterns:
        pattern = (raw or "").strip().replace("\\", "/")
        if not pattern or pattern.startswith("#"):
            continue
        normalized.append(pattern)
    return normalized


def _matches_any_pattern(path: Path, discovery_root: Path, patterns: Sequence[str]) -> bool:
    if not patterns:
        return False

    try:
        relative = path.relative_to(discovery_root).as_posix()
    except ValueError:
        relative = path.as_posix()

    path_parts = tuple(part for part in relative.split("/") if part and part != ".")
    abs_posix = path.as_posix()

    for pattern in patterns:
        dir_only = pattern.endswith("/")
        target = pattern.rstrip("/")

        if not target:
            continue

        if "/" in target:
            if _match_path_pattern(relative, target) or _match_path_pattern(abs_posix, target):
                return True
            if dir_only and _path_contains_directory(relative, target):
                return True
            continue

        if _parts_match_pattern(path_parts, target):
            return True

    return False


def _parts_match_pattern(parts: Sequence[str], pattern: str) -> bool:
    for part in parts:
        if fnmatch.fnmatch(part, pattern):
            return True
    return False


def _match_path_pattern(value: str, pattern: str) -> bool:
    return (
        fnmatch.fnmatch(value, pattern)
        or fnmatch.fnmatch(value, f"*/{pattern}")
        or fnmatch.fnmatch(value, f"{pattern}/*")
    )


def _path_contains_directory(value: str, directory_pattern: str) -> bool:
    candidates = tuple(part for part in value.split("/") if part and part != ".")
    target_parts = tuple(part for part in directory_pattern.split("/") if part and part != ".")
    if not candidates or not target_parts:
        return False
    target_len = len(target_parts)
    for idx in range(len(candidates) - target_len + 1):
        window = candidates[idx : idx + target_len]
        if all(fnmatch.fnmatch(window[i], target_parts[i]) for i in range(target_len)):
            return True
    return False


def _resolve_git_root(path: Path, cache: Dict[Path, Optional[Path]]) -> Optional[Path]:
    if path in cache:
        return cache[path]

    try:
        proc = subprocess.run(
            ["git", "-C", str(path), "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError:
        cache[path] = None
        return None

    if proc.returncode != 0:
        cache[path] = None
        return None

    git_root = Path(proc.stdout.strip()).resolve()
    cache[path] = git_root
    return git_root


def _git_ignored_paths(git_root: Path, paths: Sequence[Path]) -> Set[Path]:
    if not paths:
        return set()

    rel_to_abs: Dict[str, Path] = {}
    for path in paths:
        try:
            rel = path.relative_to(git_root).as_posix()
        except ValueError:
            continue
        rel_to_abs[rel] = path

    if not rel_to_abs:
        return set()

    query = "\n".join(rel_to_abs.keys()) + "\n"
    try:
        proc = subprocess.run(
            ["git", "-C", str(git_root), "check-ignore", "--stdin"],
            input=query,
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError:
        return set()

    if proc.returncode not in (0, 1):
        return set()

    ignored: Set[Path] = set()
    for line in proc.stdout.splitlines():
        matched = rel_to_abs.get(line.strip())
        if matched:
            ignored.add(matched)

    return ignored


def _is_git_ignored(
    git_root: Path,
    target: Path,
    cache: Dict[Tuple[Path, Path], bool],
) -> bool:
    key = (git_root, target)
    if key in cache:
        return cache[key]

    ignored = target in _git_ignored_paths(git_root, [target])
    cache[key] = ignored
    return ignored
