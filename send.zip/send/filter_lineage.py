#!/usr/bin/env python3
"""
filter_lineage.py — extract the ancestor path(s) to a specific setter.

Usage:
    python3 filter_lineage.py <lineage.json> <query> --output <file>

<query> can be:
    - a chunk_id              e.g.  da76:DA7_1810:294
    - a value/string literal  e.g.  '34'  or  ACCTA  or  ZEROS
    - a block name            e.g.  DA7_1810

Options:
    --output <file>   (REQUIRED) Save output to a file and print to stdout.

Prints every matching setter and its full root→setter path, followed by
a table of dependent variables discovered during the lineage trace.
Secondary callers (SHARED_INBOUND_CALL) are shown as additional numbered paths,
each sharing the suffix from the attachment point down to the setter.
"""

import json
import sys
from pathlib import Path


def find_setters(nodes: list, query: str) -> list:
    """Return setter nodes matching the query."""
    q = query.strip().strip("'").lower()
    matches = []
    for n in nodes:
        if n.get("role") != "SETTER":
            continue
        haystack = " ".join([
            n.get("chunk_id", ""),
            n.get("source_line", ""),
            n.get("block", ""),
            str(n.get("args", "")),
            n.get("detail", ""),
        ]).lower()
        if q in haystack:
            matches.append(n)
    return matches


def walk_to_root(node: dict, node_by_id: dict) -> tuple[list, str | None, bool]:
    """Walk parent_chunk_id chain from node up to root.

    Returns:
        ([root, ..., node], cycle_chunk_id_or_none, is_self_loop)

    is_self_loop is True when the cycle is a direct self-reference
    (parent_chunk_id == chunk_id), which indicates a data-integrity bug in
    the lineage generator rather than a real control-flow cycle.
    """
    path = []
    cur = node
    seen = set()
    cycle_at = None
    is_self_loop = False
    while cur:
        cid = cur.get("chunk_id")
        pid = cur.get("parent_chunk_id")
        # Detect self-loop before adding to seen so we can flag it distinctly.
        if pid and pid == cid:
            cycle_at = cid
            is_self_loop = True
            path.append(cur)
            break
        if cid in seen:
            cycle_at = cid
            break
        seen.add(cid)
        path.append(cur)
        cur = node_by_id.get(pid) if pid else None
    path.reverse()
    return path, cycle_at, is_self_loop


def find_secondary_paths(primary_path: list, node_by_id: dict, all_nodes: list) -> list:
    """Build full alternative paths for each SHARED_INBOUND_CALL node.

    For every node in all_nodes with edge_to_parent=SHARED_INBOUND_CALL whose
    parent_chunk_id lands on the primary path, build a new path:
        [caller_block_nodes...] + primary_path[attach_idx:]

    Returns a list of paths (each path is a list of nodes).
    """
    path_id_to_idx = {n["chunk_id"]: i for i, n in enumerate(primary_path)}
    secondary = []

    for n in all_nodes:
        edge = (n.get("edge_to_parent") or {}).get("type", "")
        if edge != "SHARED_INBOUND_CALL":
            continue
        attach_id = n.get("parent_chunk_id")
        if attach_id not in path_id_to_idx:
            continue
        attach_idx = path_id_to_idx[attach_id]

        # Collect this node plus SEQUENTIAL descendants in the same block
        blk = n.get("block")
        caller_nodes = [n]
        for sib in all_nodes:
            if sib is n:
                continue
            if sib.get("block") != blk:
                continue
            if (sib.get("edge_to_parent") or {}).get("type") != "SEQUENTIAL":
                continue
            cur = sib
            seen = set()
            while cur:
                cid = cur.get("chunk_id")
                if cid in seen:
                    break
                seen.add(cid)
                if cur.get("parent_chunk_id") == n["chunk_id"] or cur is n:
                    caller_nodes.append(sib)
                    break
                cur = node_by_id.get(cur.get("parent_chunk_id"))

        full_path = caller_nodes + primary_path[attach_idx:]
        secondary.append(full_path)

    return secondary


def format_path(path: list, index: int, label: str = "") -> str:
    header_label = f"  [{label}]" if label else ""
    lines = []
    lines.append(f"\n{'='*70}")
    lines.append(f"Path {index+1}{header_label}  ({len(path)} nodes)  →  {path[-1]['chunk_id']}")
    lines.append(f"{'='*70}")
    for i, n in enumerate(path):
        indent = "  " * i
        edge   = (n.get("edge_to_parent") or {}).get("type", "ROOT")
        role   = n.get("role", "?")
        cid    = n.get("chunk_id", "")
        src    = n.get("source_line", "").strip()
        lines.append(f"{indent}[{edge}] {cid}  ({role})")
        lines.append(f"{indent}        {src}")
    return "\n".join(lines)


def format_dependent_vars(dep_vars: list) -> str:
    """Format the dependent variables table."""
    lines = []
    lines.append(f"\n{'='*70}")
    lines.append(f"DEPENDENT VARIABLES  ({len(dep_vars)} found)")
    lines.append(f"{'='*70}")
    if not dep_vars:
        lines.append("  (none)")
        return "\n".join(lines)
    col_var  = max(len(d.get("variable", "")) for d in dep_vars)
    col_blk  = max(len(d.get("block", ""))    for d in dep_vars)
    col_var  = max(col_var, 8)
    col_blk  = max(col_blk, 5)
    header = f"  {'Variable':<{col_var}}  {'Block':<{col_blk}}  {'Line':>5}  Reason"
    lines.append(header)
    lines.append(f"  {'-'*col_var}  {'-'*col_blk}  {'-'*5}  {'-'*50}")
    for d in dep_vars:
        var    = d.get("variable", "")
        block  = d.get("block", "")
        line   = d.get("line", "")
        reason = d.get("reason", "")
        lines.append(f"  {var:<{col_var}}  {block:<{col_blk}}  {line:>5}  {reason}")
    return "\n".join(lines)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    lineage_file = Path(sys.argv[1])
    query        = sys.argv[2]

    # --output is required
    if "--output" not in sys.argv:
        print("Error: --output <file> is required.")
        print(__doc__)
        sys.exit(1)

    idx = sys.argv.index("--output")
    if idx + 1 >= len(sys.argv):
        print("Error: --output requires a file path.")
        sys.exit(1)
    output_file = Path(sys.argv[idx + 1])

    if not lineage_file.exists():
        print(f"Error: file not found: {lineage_file}")
        sys.exit(1)

    data       = json.loads(lineage_file.read_text())
    nodes      = data["nodes"]
    dep_vars   = data.get("dependent_vars", [])
    node_by_id = {n["chunk_id"]: n for n in nodes}

    setters = find_setters(nodes, query)

    if not setters:
        msg = f"No SETTER nodes matched '{query}'.\n\nAvailable setters:\n"
        for n in nodes:
            if n.get("role") == "SETTER":
                msg += f"  {n['chunk_id']}  —  {n.get('source_line','').strip()}\n"
        print(msg)
        sys.exit(1)

    output_lines = [f"Found {len(setters)} setter(s) matching '{query}':"]
    for n in setters:
        output_lines.append(f"  {n['chunk_id']}  —  {n.get('source_line','').strip()}")

    path_index = 0
    for setter in setters:
        primary, cycle_at, is_self_loop = walk_to_root(setter, node_by_id)
        if cycle_at:
            if is_self_loop:
                output_lines.append(
                    f"ERROR: self-loop detected at {cycle_at} (parent_chunk_id points to itself). "
                    "This is a lineage-generator bug — re-run trace_lineage.py to regenerate the JSON."
                )
            else:
                output_lines.append(
                    f"WARNING: cycle detected while walking parents for {setter['chunk_id']} at {cycle_at}. "
                    "Path truncated at cycle boundary."
                )
        output_lines.append(format_path(primary, path_index, label="primary"))
        path_index += 1

        for sec_path in find_secondary_paths(primary, node_by_id, nodes):
            first_blk = sec_path[0].get("block", sec_path[0].get("chunk_id", "?"))
            output_lines.append(format_path(sec_path, path_index, label=f"via {first_blk}"))
            path_index += 1

    output_lines.append(format_dependent_vars(dep_vars))
    output_lines.append("")
    text = "\n".join(output_lines)

    print(text)
    output_file.write_text(text)
    print(f"Output saved to: {output_file}")


if __name__ == "__main__":
    main()
