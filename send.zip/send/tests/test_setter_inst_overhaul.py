"""Comprehensive validation of the SETTER_INST overhaul.

Covers every row of backward_traversal/glossary/audit/SETTER_INST_COMPLETE.md:
§1 set membership, §2 DEST table, §3a SS self-operand, §3b SI/SIY immediate/mask,
§3c store family, §3d TR, §3e SYMBOL(REG), §5 Fixes #1–#4, §6 suppression +
MASK_TRIGGER + HLASM builtins, §7 normalize_token `$`, plus the three-copy sync
guard and an import smoke test for all stage-1 consumers.
"""

import re
import pytest

from backward_traversal.glossary import instructions as G
from backward_traversal.glossary.special_cases import (
    classify_setter,
    dest_has_nonzero_displacement,
)
from backward_traversal.utils.token_utils import (
    is_dep_var_candidate as bt_is_dep_var_candidate,
    normalize_token as bt_normalize_token,
)
from backward_traversal.utils.blueprint_utils import collect_constant_symbols
from backward_traversal.tracing.asm_backward_tracer import _collect_dep_vars

import trace_lineage as T
import process.instructions as P


# --------------------------------------------------------------------------- #
# §1 / §2 / §5 Fix #4 — set + table integrity and three-copy sync
# --------------------------------------------------------------------------- #

ADDED = [
    "AGSI", "ALGSI", "ALSI", "AP", "ASI", "CVDG", "CVDY", "ED", "EDMK", "MVCIN",
    "MVGHI", "MVHHI", "MVHI", "MVIY", "NIY", "OIY", "PKA", "PKU", "SP", "SRP",
    "STCKF", "STCMH", "STCMY", "STEY", "STFLE", "STHRL", "STMG", "STMH", "STMY",
    "STRL", "STRV", "STRVG", "STRVH", "UNPKA", "UNPKU", "XIY",
]
REMOVED = [
    "AG", "AGHI", "AGR", "AH", "AHI", "ALGR", "API", "AR", "CVB", "IC", "ICM",
    "L", "LA", "LAY", "LG", "LGF", "LGFRL", "LGHI", "LGR", "LGRL", "LH", "LHY",
    "LR", "LY", "SGR", "SH", "SLGR", "SLL", "SLR", "SPI", "SRA", "SRL", "TRT",
    "MVCL", "MVCP", "MVCS",
]


def test_setter_inst_is_65_members():
    assert len(G.SETTER_INST) == 65


def test_three_copies_byte_for_byte_identical():
    assert T.SETTER_INST == G.SETTER_INST == P.SETTER_INST
    assert T.DEST_ARG_INDEX_BY_INST == G.DEST_ARG_INDEX_BY_INST == P.DEST_ARG_INDEX_BY_INST


@pytest.mark.parametrize("op", ADDED)
def test_added_opcodes_present(op):
    assert op in G.SETTER_INST


@pytest.mark.parametrize("op", REMOVED)
def test_removed_opcodes_absent(op):
    assert op not in G.SETTER_INST


def test_dest_table_24_entries_and_keys_are_setters():
    assert len(G.DEST_ARG_INDEX_BY_INST) == 24
    for k in G.DEST_ARG_INDEX_BY_INST:
        assert k in G.SETTER_INST, k
    assert G.DEST_ARG_INDEX_BY_INST["STMG"] == 2  # §5 Fix #4


def test_suppress_table_keys_are_setters_and_srp_both_args():
    for k in G.SRC_ARG_SUPPRESS_BY_INST:
        assert k in G.SETTER_INST, k
    assert G.SRC_ARG_SUPPRESS_BY_INST["SRP"] == frozenset({1, 2})


def test_receiving_tables_populated():
    assert {"LGFRL", "LGRL"} <= set(G.REGISTER_LOAD_FROM_MEM)
    assert "LTR" in G.REGISTER_COPY_FROM_REG
    assert G.REGISTER_LOAD_ADDRESS == {"LA": 1, "LAY": 1}


def test_mask_trigger_live_in_trigger_inst():
    assert G.MASK_TRIGGER_AT_ARG1 == {"TM", "TMY", "CLI", "CLIY", "TRT"}
    assert G.MASK_TRIGGER_AT_ARG1 <= G.TRIGGER_INST


# --------------------------------------------------------------------------- #
# §3a — SS self-operand patterns (classify_setter verdicts)
# --------------------------------------------------------------------------- #

def _skip(inst, args, next_inst=""):
    return classify_setter(inst, args, next_inst=next_inst)["skip_setter_site"]


def _prior(inst, args):
    return classify_setter(inst, args)["prior_value_required"]


def test_oc_self_noop_skipped():
    assert _skip("OC", ["FIELD", "FIELD"]) is True


def test_oc_self_zero_test_kept_as_condition_check():
    v = classify_setter("OC", ["FIELD", "FIELD"], next_inst="BZ")
    assert v["skip_setter_site"] is False
    assert v["role"] == "CONDITION_CHECK"


def test_oc_self_displacement_same_base_skipped():
    assert _skip("OC", ["FIELD+4(2)", "FIELD"]) is True


def test_nc_self_skipped():
    assert _skip("NC", ["F", "F"]) is True


def test_xc_self_kept_no_deps():
    assert _skip("XC", ["F", "F"]) is False


def test_xc_zero_literal_skipped():
    assert _skip("XC", ["F", "=XL4'00'"]) is True


def test_zap_self_skipped():
    assert _skip("ZAP", ["F", "F"]) is True


def test_zap_distinct_displacement_not_self_op():
    # raw args differ -> zap_self_sign_norm requires raw equality -> not skipped
    assert _skip("ZAP", ["A+0(2)", "A+4(2)"]) is False


def test_ap_self_prior_value():
    v = classify_setter("AP", ["F", "F"])
    assert v["skip_setter_site"] is False and v["prior_value_required"] is True


def test_ap_zero_literal_skipped():
    assert _skip("AP", ["F", "=P'0'"]) is True


def test_sp_self_no_deps():
    v = classify_setter("SP", ["F", "F"])
    assert v["skip_setter_site"] is False and v["suppress_dep_vars"] is True


def test_sp_zero_literal_skipped():
    assert _skip("SP", ["F", "=P'0'"]) is True


def test_ap_sp_distinct_source_prior_value():
    # CRITICAL (§3a): AP/SP FIELD,SRC — prior value of FIELD IS a dep (PoO §8-6/§8-13)
    v = classify_setter("AP", ["FIELD", "SRC"])
    assert v["prior_value_required"] is True, "AP FIELD,SRC must have prior_value"
    assert v["skip_setter_site"] is False
    v = classify_setter("SP", ["FIELD", "SRC"])
    assert v["prior_value_required"] is True, "SP FIELD,SRC must have prior_value"
    assert v["skip_setter_site"] is False


def test_tr_self_translate_no_suppress_prior_value():
    # LOW (§3d): TR FIELD,FIELD — do NOT suppress args[1]; prior value matters (PoO §7-225)
    v = classify_setter("TR", ["F", "F"])
    assert v["prior_value_required"] is True, "TR self-translate must have prior_value"
    assert frozenset() == v["suppress_src_indexes"], "TR self-translate: suppression must not apply"
    # TR with distinct table must still suppress args[1]
    v2 = classify_setter("TR", ["F", "XTAB"])
    assert 1 in v2["suppress_src_indexes"], "TR distinct table must suppress args[1]"


def test_mp_dp_self_warn_and_skip():
    for inst in ("MP", "DP"):
        v = classify_setter(inst, ["F", "F"])
        assert v["skip_setter_site"] is True and v["warn"]


def test_mp_dp_distinct_prior_value():
    assert _prior("MP", ["D", "S"]) is True
    assert _prior("DP", ["D", "S"]) is True


def test_mvo_pack_self_prior_value():
    assert _prior("MVO", ["D(3)", "D(2)"]) is True
    assert _prior("PACK", ["F", "F"]) is True


def test_mvc_self_nop_skipped_but_propagation_kept():
    assert _skip("MVC", ["F", "F"]) is True
    v = classify_setter("MVC", ["F+1(3)", "F"])
    assert v["skip_setter_site"] is False and v["prior_value_required"] is True


def test_mvcin_self_warn_and_skip():
    v = classify_setter("MVCIN", ["F", "F"])
    assert v["skip_setter_site"] is True and v["warn"]


@pytest.mark.parametrize("op", ["ED", "EDMK", "MVCIN", "CVDG", "CVDY", "UNPKA", "UNPKU", "PKA", "PKU"])
def test_newly_added_normal_setters_not_skipped(op):
    # distinct operands -> genuine setter, not skipped
    assert _skip(op, ["DEST", "SRC"]) is False


# --------------------------------------------------------------------------- #
# §3b — SI/SIY immediate and mask operands (classify + _collect_dep_vars)
# --------------------------------------------------------------------------- #

def _deps(inst, args, var, **kw):
    return _collect_dep_vars(inst, args, var, **kw)


def test_ni_literal_no_deps():
    assert _deps("NI", ["FIELD", "X'0F'"], "FIELD") == []


def test_ni_all_ones_identity_skipped():
    assert _skip("NI", ["FIELD", "X'FF'"]) is True


def test_oi_xi_zero_identity_skipped():
    assert _skip("OI", ["FIELD", "X'00'"]) is True
    assert _skip("XI", ["FIELD", "X'00'"]) is True


def test_ni_copy_member_equ_suppressed():
    # OPNBIT is a COPY-member EQU mask with no # prefix; must not leak as dep_var.
    assert _deps("NI", ["FIELD", "OPNBIT"], "FIELD") == []


def test_ni_oi_xi_prior_value_annotated():
    for inst in ("NI", "OI", "XI", "NIY", "OIY", "XIY"):
        assert _prior(inst, ["FIELD", "MASK"]) is True


def test_mvi_immediate_suppressed():
    assert _deps("MVI", ["FIELD", "EQULBL"], "FIELD") == []


def test_mvi_space_builtin_filtered():
    cs = collect_constant_symbols({})
    assert "SPACE" in cs
    assert _deps("MVI", ["FIELD", "SPACE"], "FIELD", constant_symbols=cs) == []


def test_asi_family_prior_value_no_deps():
    for inst in ("ASI", "AGSI", "ALSI", "ALGSI"):
        assert _prior(inst, ["FIELD", "5"]) is True
        assert _deps(inst, ["FIELD", "5"], "FIELD") == []


def test_mvhi_family_no_deps():
    for inst in ("MVHI", "MVHHI", "MVGHI"):
        assert _deps(inst, ["FIELD", "10"], "FIELD") == []


def test_stcm_mask_zero_skipped():
    for m in ("0", "B'0000'", "X'00'"):
        assert _skip("STCM", ["R5", m, "FIELD"]) is True


def test_stcm_mask_equ_suppressed_and_full_mask_kept():
    # M3 is at args[1]; the destination is args[2].
    assert _deps("STCM", ["R5", "BYTMSK", "FIELD"], "FIELD") == []
    assert _skip("STCM", ["R5", "15", "FIELD"]) is False
    assert G.DEST_ARG_INDEX_BY_INST["STCMH"] == 2


def test_nc_second_operand_not_suppressed():
    # NC source operand is genuine storage data, must remain a dep_var.
    assert "MASKFLD" in _deps("NC", ["FIELD", "MASKFLD"], "FIELD")


def test_tm_cli_mask_trigger_only_arg0():
    assert _deps("TM", ["FIELD", "BITMASK"], "OTHER") == ["FIELD"]
    assert _deps("CLI", ["FIELD", "OPNBIT"], "OTHER") == ["FIELD"]


# --------------------------------------------------------------------------- #
# §3c — store family
# --------------------------------------------------------------------------- #

def test_store_named_dest_kept_no_deps():
    assert _skip("ST", ["R5", "FIELD"]) is False
    assert _deps("ST", ["R5", "FIELD"], "FIELD") == []


def test_field_plus_offset_skipped():
    assert _skip("ST", ["R5", "FIELD+8"]) is True
    assert dest_has_nonzero_displacement("FIELD+8") is True
    assert dest_has_nonzero_displacement("FIELD+0") is False
    assert dest_has_nonzero_displacement("FIELD") is False
    assert dest_has_nonzero_displacement("EBW000(4)") is False  # range write, not +N


def test_store_multiple_dest_indexes():
    for op in ("STM", "STMG", "STMH", "STMY"):
        assert G.DEST_ARG_INDEX_BY_INST[op] == 2
    # STMG dest matches -> sources are GPRs -> no deps
    assert _deps("STMG", ["R0", "R7", "CALLER_REGS"], "CALLER_REGS") == []


def test_rxy_ril_store_dest_index_one():
    for op in ("STRL", "STHRL", "STRV", "STRVG", "STRVH", "STEY"):
        assert G.DEST_ARG_INDEX_BY_INST[op] == 1


# --------------------------------------------------------------------------- #
# §5 Fix #1 — call-site dest-aware harvest (via _collect_dep_vars LHS guard)
# --------------------------------------------------------------------------- #

def test_fix1_st_dest_not_traced_no_leak():
    # ST R5,FIELDNAME while tracing OTHER_VAR -> dest != traced -> no harvest.
    assert _deps("ST", ["R5", "FIELDNAME"], "OTHER_VAR") == []


def test_fix1_stm_dest_match_sources_are_gprs():
    # STM R14,R7,WK_REGS while tracing WK_REGS -> sources R14,R7 -> filtered.
    assert _deps("STM", ["R14", "R7", "WK_REGS"], "WK_REGS") == []


# --------------------------------------------------------------------------- #
# §3d — TR translate-table suppression
# --------------------------------------------------------------------------- #

def test_tr_table_suppressed():
    # args[1] is the translate table, must not be a dep_var.
    assert _deps("TR", ["FIELD", "XTAB"], "FIELD") == []


# --------------------------------------------------------------------------- #
# §3e / Fix #2 — SYMBOL(REG) source operands (both token copies)
# --------------------------------------------------------------------------- #

FIX2_CASES = [
    ("SAVEAREA(R13)", True),
    ("SRCFIELD(R13)", True),
    ("FIELD+4(R13)", True),
    ("4(R3)", False),
    ("0(R13)", False),
    ("(R13)", False),
    ("R13(R13)", False),
    ("15(R5,R13)", False),
    ("WKAREA", True),
    ("R5", False),
    ("X'FF'", False),
    ("=CL8CONST", False),
]


@pytest.mark.parametrize("raw,expected", FIX2_CASES)
def test_fix2_backward_token_utils(raw, expected):
    assert bt_is_dep_var_candidate(raw) is expected


@pytest.mark.parametrize("raw,expected", FIX2_CASES)
def test_fix2_stage1_trace_lineage(raw, expected):
    assert T.is_dep_var_candidate(raw) is expected


# --------------------------------------------------------------------------- #
# §7 — normalize_token `$` parity between the two copies
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize("tok,expected", [("$WK_CMO", "$WK_CMO"), ("WK_CMO$", "WK_CMO$")])
def test_normalize_token_dollar_parity(tok, expected):
    assert bt_normalize_token(tok) == expected
    assert T.normalize_token(tok) == expected


# --------------------------------------------------------------------------- #
# Stage-1 parity: is_real_setter_site mirrors backward skip outcomes
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize("inst,args,expected_real", [
    ("OC", ["F", "F"], False),
    ("NC", ["F", "F"], False),
    ("ZAP", ["F", "F"], False),
    ("XC", ["F", "F"], True),
    ("MVC", ["F", "F"], False),
    ("MP", ["F", "F"], False),
    ("NI", ["F", "X'FF'"], False),
    ("OI", ["F", "X'00'"], False),
    ("AP", ["F", "=P'0'"], False),
    ("STCM", ["R5", "0", "F"], False),
    ("STCM", ["R5", "15", "F"], True),
    ("ST", ["R5", "F+8"], False),
    ("ST", ["R5", "F"], True),
    ("AP", ["F", "F"], True),   # real setter (prior value), not a no-op
])
def test_is_real_setter_site_matches_backward(inst, args, expected_real):
    assert T.is_real_setter_site(inst, args) is expected_real
    # backward classify_setter must agree on the skip decision
    assert classify_setter(inst, args)["skip_setter_site"] is (not expected_real)


# --------------------------------------------------------------------------- #
# Import smoke — all 5 stage-1 consumers + backward modules load post-change
# --------------------------------------------------------------------------- #

def test_import_smoke_all_consumers():
    import importlib
    for mod in [
        "trace_lineage", "find_variable_modifiers", "build_modifier_index",
        "forward_trace_lineage", "find_connected_variables", "trace_cross_file_lineage",
        "backward_traversal.runner.backward_only_runner",
        "backward_traversal.tracing.asm_backward_tracer",
    ]:
        assert importlib.import_module(mod) is not None
