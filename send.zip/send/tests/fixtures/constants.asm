* Common constants for customer processing
* Included via COPY directive
*
* Register equates
R0       EQU   0
R1       EQU   1
R2       EQU   2
R3       EQU   3
R4       EQU   4
R5       EQU   5
R6       EQU   6
R7       EQU   7
R8       EQU   8
R9       EQU   9
R10      EQU   10
R11      EQU   11
R12      EQU   12
R13      EQU   13
R14      EQU   14
R15      EQU   15
*
* Processing constants
MAXRECS  EQU   1000                 Maximum records to process
BUFSIZE  EQU   4096                 Buffer size
RECID    EQU   X'0001'              Record identifier
*
* Return codes
RCOK     EQU   0                    Success
RCWARN   EQU   4                    Warning
RCERROR  EQU   8                    Error
RCFATAL  EQU   12                   Fatal error
