         ENTRY MAIN,HELPER
         EXTRN DBREAD,DBWRITE
MAIN     CSECT
MAXLEN   EQU   256
R15      EQU   15
         L     R15,=V(DBREAD)
         BASR  R14,R15
HELPER   DS    0H
         BR    R14
         END
