* Simple test assembly file
TESTSECT CSECT
         ENTRY MAIN
MAIN     BAS   R14,SUBRTN1
         BR    R14

SUBRTN1  LA    R1,DATA
         BR    R14

DATA     DS    F
         END
