*
* Sample z/TPF program with database operations
*
         TITLE 'Database Operations Sample'
*
* Main routine - Customer record processing
*
CUSTMAIN CSECT
*
* Read customer record
         DBRED FILE=CUSTFILE,KEY=CUSTKEY,AREA=CUSTBUF
*
* Update customer balance
         DBUPD FILE=CUSTFILE,KEY=CUSTKEY,AREA=CUSTBUF
*
* Call helper routine
         BAL   R14,ORDPROC
*
* Return
         BR    R14
*
* Order processing routine
*
ORDPROC  CSECT
*
* Read order file
         DBRED FILE=ORDFILE,KEY=ORDKEY,AREA=ORDBUF
*
* Write order detail
         DBWRT FILE=ORDDETL,AREA=DETLBUF
*
* Delete temporary record
         DBDEL FILE=TEMPFILE,KEY=TEMPKEY
*
* Return
         BR    R14
*
* File control section
*
FILEINIT CSECT
*
* Open customer file
         DBOPN FILE=CUSTFILE
*
* File table
         FILEC NAME=CUSTFILE,TYPE=KSDS
*
* Return
         BR    R14
*
         END   CUSTMAIN
