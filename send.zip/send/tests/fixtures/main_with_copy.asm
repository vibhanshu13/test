* Main file with COPY directive
MAINSECT CSECT
         COPY  UTILS
MAIN     BAS   R14,SUBRTN
         BR    R14
         END
