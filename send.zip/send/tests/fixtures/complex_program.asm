* Complex z/TPF Assembly Program
* Demonstrates: ENTRY, EXTRN, CSECT, DSECT, EQU, COPY, continuations
* Purpose: Customer record processing with database operations
*
         PRINT NOGEN
*
* Entry points for this module
         ENTRY CUSTMAIN,CUSTPROC,CUSTNEW
*
* External database routines
         EXTRN DBREAD,DBWRT,DBDEL
         EXTRN GETMEM,FREEMEM
*
* External C functions
         WXTRN VALIDATE
*
*----------------------------------------------------------------
* Main customer processing routine
*----------------------------------------------------------------
CUSTMAIN CSECT
         USING *,R12
         SAVE  (14,12),,CUSTMAIN_&SYSDATE_&SYSTIME
         LR    R12,R15              Load base register
         LA    R13,SAVEAREA         Set up save area
*
* Copy common constants and macros
         COPY  CONSTANTS
*
* Initialize processing
         XR    R5,R5                Clear record counter
         L     R6,=A(MAXRECS)       Load max records
*
* Build database key with line continuation
         MVC   DBKEY(8),=CL8'CUST'   Key prefix                        X
               -RECID                 Record ID
*
MAINLOOP DS    0H
*
* Read customer record
         LA    R1,CUSTPARM          Point to parameter list
         L     R15,=V(DBREAD)       Load DB read routine address
         BALR  R14,R15              Call database read
         LTR   R15,R15              Check return code
         BNZ   DBERROR              Branch if error
*
* Validate customer data
         LA    R1,CUSTREC           Customer record address
         L     R15,=V(VALIDATE)     External validation
         BASR  R14,R15              Call validator
         LTR   R15,R15              Valid?
         BNZ   INVALID              No, skip
*
* Process valid record
         BAL   R14,CUSTPROC         Call processor
*
         LA    R5,1(R5)             Increment counter
         CR    R5,R6                Max reached?
         BL    MAINLOOP             Continue if not
*
DONE     DS    0H
         L     R13,SAVEAREA+4       Restore registers
         RETURN (14,12),RC=0
*
DBERROR  DS    0H
         WTO   'Database error'
         LA    R15,8                Set error code
         B     DONE
*
INVALID  DS    0H
         WTO   'Invalid customer record'
         B     MAINLOOP             Continue processing
*
*----------------------------------------------------------------
* Customer record processor
*----------------------------------------------------------------
CUSTPROC DS    0H
         STM   R14,R12,12(R13)      Save registers
*
* Get memory for work area
         LA    R0,WORKLEN           Work area length
         L     R15,=V(GETMEM)       Memory allocator
         BALR  R14,R15              Get memory
         LTR   R2,R1                Memory allocated?
         BZ    PROCERR              No, error
*
* Copy customer data to work area
         LR    R3,R2                Target address
         LA    R4,CUSTREC           Source record
         LA    R5,CUSTLEN           Record length
         MVCL  R2,R4                Copy data
*
* Update customer status
         MVI   STATUS,C'A'          Set to active
         MVC   LASTUPDT,=C'20260322' Update date
*
* Write updated record
         LA    R1,CUSTPARM          Parameter list
         L     R15,=V(DBWRT)        DB write routine
         BALR  R14,R15              Write record
*
* Free work memory
         LR    R1,R3                Work area address
         LA    R0,WORKLEN           Length
         L     R15,=V(FREEMEM)      Free memory
         BALR  R14,R15              Release it
*
PROCOK   LM    R14,R12,12(R13)      Restore registers
         BR    R14                  Return
*
PROCERR  LA    R15,12               Error code
         B     PROCOK
*
*----------------------------------------------------------------
* Create new customer record
*----------------------------------------------------------------
CUSTNEW  DS    0H
         STM   R14,R12,12(R13)      Save registers
*
* Initialize new record
         LA    R2,CUSTREC           Record address
         LA    R3,CUSTLEN           Record length
         XR    R4,R4                Fill character (nulls)
         XR    R5,R5                Fill length
         MVCL  R2,R4                Clear record
*
* Set default values
         MVC   CUSTID,=CL10'NEW000000' Default ID
         MVI   STATUS,C'N'          New status
         MVC   CREATED,=C'20260322'  Creation date
*
         LM    R14,R12,12(R13)      Restore registers
         BR    R14                  Return
*
*----------------------------------------------------------------
* Constants and work areas
*----------------------------------------------------------------
SAVEAREA DS    18F                  Register save area
DBKEY    DS    CL16                 Database key
CUSTPARM DS    0F                   DB parameter list
         DC    A(DBKEY)             Key address
         DC    A(CUSTREC)           Record address
         DC    F'0'                 Options
*
* Include customer record DSECT
         COPY  CUSTREC
*
*----------------------------------------------------------------
* Literal pool
*----------------------------------------------------------------
         LTORG
*
*----------------------------------------------------------------
* Customer record DSECT (inline version for testing)
*----------------------------------------------------------------
CUSTDATA DSECT
CUSTID   DS    CL10                 Customer ID
CUSTNAME DS    CL30                 Customer name
STATUS   DS    C                    Status (A/I/N)
CREATED  DS    CL8                  Creation date YYYYMMDD
LASTUPDT DS    CL8                  Last update date
BALANCE  DS    F                    Account balance
CUSTLEN  EQU   *-CUSTDATA           Record length
*
*----------------------------------------------------------------
* Work area DSECT
*----------------------------------------------------------------
WORKAREA DSECT
CUSTREC  DS    CL(CUSTLEN)          Customer record copy
WORKLEN  EQU   *-WORKAREA           Work area length
*
         END   CUSTMAIN
