* Customer record DSECT
* Shared structure for customer data
*
CUSTREC  DSECT
CUSTID   DS    CL10                 Customer ID
CUSTNAME DS    CL30                 Customer name
CUSTEMAL DS    CL50                 Email address
STATUS   DS    C                    Status: A=Active, I=Inactive, N=New
CUSTTYPE DS    C                    Type: P=Personal, B=Business
CREATED  DS    CL8                  Creation date YYYYMMDD
LASTUPDT DS    CL8                  Last update date YYYYMMDD
BALANCE  DS    F                    Account balance (signed)
CREDIT   DS    F                    Credit limit
TRANSCT  DS    H                    Transaction count
RESERVED DS    CL10                 Reserved for future use
CUSTLEN  EQU   *-CUSTREC            Total record length
