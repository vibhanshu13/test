* Utility routines
SUBRTN   LA    R1,DATA
         BR    R14
DATA     DS    F
