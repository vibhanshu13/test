import pytest
from pathlib import Path
from passes.macro_collector import MacroCollector
from macro_library import MacroLibrary
import tempfile


def test_collector_creation():
    """Test creating macro collector"""
    collector = MacroCollector(search_paths=[Path(".")])
    assert collector is not None


def test_collect_from_file(tmp_path):
    """Test collecting macros from a single file"""
    # Create temp macro file
    macro_file = tmp_path / "MACROS.asm"
    macro_file.write_text("""
         MACRO
         SETRC &RC
         LA    R15,&RC
         BR    R14
         MEND
*
         MACRO
         NOOP
         NOP
         MEND
""")

    collector = MacroCollector(search_paths=[tmp_path])
    library = collector.collect_from_file(macro_file)

    assert library.get_macro_count() == 2
    assert library.has_macro("SETRC")
    assert library.has_macro("NOOP")


def test_auto_discover_macros(tmp_path):
    """Test auto-discovery of macro files"""
    # Create directory structure
    macros_dir = tmp_path / "macros"
    macros_dir.mkdir()

    # Create macro file
    (macros_dir / "MACROS.asm").write_text("""
         MACRO
         TEST1
         NOP
         MEND
""")

    (macros_dir / "MORE.asm").write_text("""
         MACRO
         TEST2
         NOP
         MEND
""")

    collector = MacroCollector(search_paths=[tmp_path])
    library = collector.auto_discover()

    assert library.get_macro_count() == 2
    assert library.has_macro("TEST1")
    assert library.has_macro("TEST2")


def test_collect_with_explicit_paths(tmp_path):
    """Test collecting from explicit paths"""
    # Create macro files
    file1 = tmp_path / "file1.asm"
    file1.write_text("""
         MACRO
         MACRO1
         NOP
         MEND
""")

    file2 = tmp_path / "file2.asm"
    file2.write_text("""
         MACRO
         MACRO2
         NOP
         MEND
""")

    collector = MacroCollector(search_paths=[tmp_path])
    library = collector.collect_from_files([file1, file2])

    assert library.get_macro_count() == 2
    assert library.has_macro("MACRO1")
    assert library.has_macro("MACRO2")


def test_override_with_explicit_path(tmp_path):
    """Test that explicit paths override auto-discovered macros"""
    # Create two versions of same macro
    auto_file = tmp_path / "auto.asm"
    auto_file.write_text("""
         MACRO
         TEST
         LA    R1,1
         MEND
""")

    explicit_file = tmp_path / "explicit.asm"
    explicit_file.write_text("""
         MACRO
         TEST
         LA    R1,2
         MEND
""")

    collector = MacroCollector(search_paths=[tmp_path])

    # Auto-discover first
    library = collector.auto_discover()
    assert library.get_macro_count() == 1

    # Then add explicit (should override)
    library = collector.collect_from_files([explicit_file], library)

    # Should have explicit version
    test_macro = library.get_macro("TEST")
    assert "LA    R1,2" in test_macro.body[0]


def test_collect_inline_macros(tmp_path):
    """Test collecting macros inline from source files"""
    source_file = tmp_path / "program.asm"
    source_file.write_text("""
PROGRAM  CSECT
         MACRO
         LOCAL_MACRO
         NOP
         MEND
*
MAIN     DS    0H
         LOCAL_MACRO
         BR    R14
         END
""")

    collector = MacroCollector(search_paths=[tmp_path])
    library = collector.collect_inline_macros(source_file)

    assert library.get_macro_count() == 1
    assert library.has_macro("LOCAL_MACRO")

    # Check scope is local
    macro = library.get_macro("LOCAL_MACRO")
    assert macro.scope == "local"
