from pathlib import Path

import pytest

from passes.c_family_parser import CFamilyParser


def _require_parser(language: str):
    parser = CFamilyParser(language)
    if not parser.available:
        pytest.skip("tree-sitter parser unavailable")
    return parser


def test_parser_captures_scope_and_update_expressions():
    parser = _require_parser("c")
    text = """
static int GLOB;
int EXT;

void f(int *p) {
    int x = 1;
    ++x;
    GLOB = x;
}
"""
    unit = parser.parse(Path("demo.c"), text)

    names = {d.name for d in unit.declarations}
    assert "GLOB" in names
    assert "EXT" in names
    assert "x" in names

    assert any(a.expression and "++x" in a.expression for a in unit.assignments)


def test_parser_captures_struct_array_and_function_pointer_calls():
    parser = _require_parser("cpp")
    text = """
struct Rec { int value; };

extern "C" int asm_fraud_check(int);

int run(Rec* rec, int arr[], int i, int (*fp)(int), int in) {
    rec->value = arr[i];
    arr[i] = asm_fraud_check(in);
    return (*fp)(in);
}
"""
    unit = parser.parse(Path("demo.cpp"), text)

    assert any(a.target_kind == "struct_field" and "rec->value" in a.target for a in unit.assignments)
    assert any(a.target_kind == "array_element" and "arr[i]" in a.target for a in unit.assignments)
    assert any(a.call_function == "asm_fraud_check" for a in unit.assignments)
    assert any(call.function == "fp" for call in unit.calls)


def test_parser_keeps_symbol_offsets_correct_with_utf8_content():
    parser = _require_parser("cpp")
    text = """
// UTF-8 noise: — ✓ ₹
extern "C" int asm_bridge_call(int);

int stable_name(int input) {
    const char* marker = "unicode — marker";
    return asm_bridge_call(input);
}
"""
    unit = parser.parse(Path("utf8_demo.cpp"), text)

    assert any(func.name == "stable_name" for func in unit.functions)
    assert any(call.function == "asm_bridge_call" for call in unit.calls)


def test_parser_extracts_return_sources_from_expressions_and_calls():
    parser = _require_parser("cpp")
    text = """
extern "C" int asm_bridge_call(int);

int f(int x, int y) {
    int sum = x + y;
    if (sum > 0) {
        return x + y;
    }
    return asm_bridge_call(x);
}
"""
    unit = parser.parse(Path("ret_demo.cpp"), text)
    returns_by_line = {ret.line: ret for ret in unit.returns}

    # return x + y;
    line_return_expr = 7
    assert line_return_expr in returns_by_line
    expr_sources = set(returns_by_line[line_return_expr].sources)
    assert "x" in expr_sources
    assert "y" in expr_sources

    # return asm_bridge_call(x);
    line_return_call = 9
    assert line_return_call in returns_by_line
    call_sources = set(returns_by_line[line_return_call].sources)
    assert "asm_bridge_call" in call_sources
    assert "x" in call_sources


def test_parser_keeps_callee_name_and_tracks_asm_alias():
    parser = _require_parser("cpp")
    text = """
extern "C" int processBuffer(char* input, char* output, int size) asm("ASM_PROCBF");

int process_buffer_pipeline(char* raw_input, char* output, int input_size) {
    return processBuffer(
        const_cast<char*>(raw_input),
        output,
        input_size);
}
"""
    unit = parser.parse(Path("alias_call.cpp"), text)

    call = next((c for c in unit.calls if c.line == 5), None)
    assert call is not None
    assert call.function == "processBuffer"
    assert call.asm_target == "ASM_PROCBF"
    assert call.args[0] == "raw_input"


def test_parser_extracts_symbol_aliases_with_complex_parameters():
    parser = _require_parser("cpp")
    text = """
extern "C" int asm_process_level(
    int level,
    int (*post_hook)(int),
    int* count_out
) asm("LVLPROC");
"""
    unit = parser.parse(Path("complex_alias.cpp"), text)
    assert unit.symbol_aliases.get("asm_process_level") == "LVLPROC"


def test_parser_extracts_symbol_aliases_with_trailing_attributes_and_noexcept():
    parser = _require_parser("cpp")
    text = """
extern "C" int asm_ecb_read_flags(
    int* status_out,
    int* score_out
) asm("ECBREAD") __attribute__((weak)) noexcept;
"""
    unit = parser.parse(Path("alias_attr.cpp"), text)
    assert unit.symbol_aliases.get("asm_ecb_read_flags") == "ECBREAD"


def test_parser_regex_fallback_keeps_core_lineage_signals():
    parser = CFamilyParser("cpp")
    parser.available = False
    parser.parser = None
    text = """
extern "C" int asm_do_work(int input) asm("ASM_WORK");

int run(int input) {
    int local = asm_do_work(input);
    return local;
}
"""
    unit = parser.parse(Path("fallback.cpp"), text)

    assert "tree_sitter_unavailable" in unit.parse_errors
    assert any(func.name == "run" for func in unit.functions)
    assert any(decl.kind == "parameter" and decl.name == "input" for decl in unit.declarations)
    assert any(assign.target == "local" and assign.call_function == "asm_do_work" for assign in unit.assignments)
    assert any(call.function == "asm_do_work" and call.args == ["input"] for call in unit.calls)
    assert any(ret.function == "run" and "local" in ret.sources for ret in unit.returns)


def test_parser_regex_fallback_excludes_cast_and_sizeof_style_tokens_from_sources():
    parser = CFamilyParser("cpp")
    parser.available = False
    parser.parser = None
    text = """
int run(int input, float f, int* p) {
    int a = static_cast<int>(f);
    int b = sizeof(char);
    int c = alignof(int);
    int d = typeid(int) == typeid(float) ? 1 : 0;
    int e = reinterpret_cast<long>(p);
    return const_cast<int&>(a) + b + c + d + e;
}
"""
    unit = parser.parse(Path("fallback_keywords.cpp"), text)

    forbidden = {"static_cast", "reinterpret_cast", "const_cast", "sizeof", "alignof", "typeid"}
    all_decl_names = {decl.name for decl in unit.declarations}
    assert not forbidden.intersection(all_decl_names)

    all_sources = set()
    for assignment in unit.assignments:
        all_sources.update(assignment.sources)
    for ret in unit.returns:
        all_sources.update(ret.sources)
    assert not forbidden.intersection(all_sources)


def test_parser_regex_fallback_filters_literals_comments_numeric_and_cast_noise():
    parser = CFamilyParser("cpp")
    parser.available = False
    parser.parser = None
    text = """
int run(char* buffer, int input) {
    const char* level = "HIGH";
    strcpy(buffer, "CR21AERT");
    int status = 0; // R001 set result to zero
    uint8_t mask = 0xFF; /* MSG_TYPE validation */
    auto route = (char*)"ROUNDTRP";
    auto width = (size_t)8;
    log_line("A=B"); // '=' inside string should not be parsed as assignment
    status = validate(input); // copy as usual
    return status;
}
"""
    unit = parser.parse(Path("fallback_noise.cpp"), text)

    decl_names = {decl.name for decl in unit.declarations}
    assert {"buffer", "input", "level", "status", "mask", "route", "width"}.issubset(decl_names)

    banned_names = {
        '"HIGH"', "HIGH", '"CR21AERT"', "CR21AERT",
        "0", "0xFF", "xFF",
        "//R001", "/*MSG_TYPE*/",
        '(char*)"ROUNDTRP"', "(size_t)8", "size_t",
    }
    assert not decl_names.intersection(banned_names)

    all_assignment_sources = {src for assignment in unit.assignments for src in assignment.sources}
    assert '"HIGH"' in all_assignment_sources
    assert '"ROUNDTRP"' in all_assignment_sources
    assert "HIGH" not in all_assignment_sources
    assert "xFF" not in all_assignment_sources
    assert "size_t" not in all_assignment_sources
    assert not {src for src in all_assignment_sources if src.startswith("//") or src.startswith("/*")}

    strcpy_call = next((call for call in unit.calls if call.function == "strcpy"), None)
    assert strcpy_call is not None
    assert '"CR21AERT"' in strcpy_call.args

    log_call = next((call for call in unit.calls if call.function == "log_line"), None)
    assert log_call is not None
    assert '"A=B"' in log_call.args
