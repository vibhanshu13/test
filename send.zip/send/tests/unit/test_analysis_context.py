import pytest
from models.analysis_context import AnalysisContext
from models.symbol import Symbol, SymbolType, SymbolTable
from models.provenance import StatementProvenance


def test_analysis_context_creation():
    """Test creating empty AnalysisContext"""
    ctx = AnalysisContext()

    assert ctx.symbol_table is not None
    assert isinstance(ctx.symbol_table, SymbolTable)
    assert ctx.copy_includes == []
    assert ctx.metadata == {}


def test_analysis_context_add_copy_include():
    """Test tracking COPY includes"""
    ctx = AnalysisContext()

    ctx.add_copy_include("module1.asm", "utils.asm", 10)
    ctx.add_copy_include("module1.asm", "macros.asm", 20)

    assert len(ctx.copy_includes) == 2
    assert ctx.copy_includes[0].including_file == "module1.asm"
    assert ctx.copy_includes[0].included_file == "utils.asm"
    assert ctx.copy_includes[0].line_number == 10
    assert ctx.copy_includes[1].including_file == "module1.asm"
    assert ctx.copy_includes[1].included_file == "macros.asm"
    assert ctx.copy_includes[1].line_number == 20


def test_analysis_context_add_metadata():
    """Test adding metadata"""
    ctx = AnalysisContext()

    ctx.add_metadata("analyzed_files", ["module1.asm", "module2.asm"])
    ctx.add_metadata("timestamp", "2026-03-20T10:00:00Z")

    assert ctx.metadata["analyzed_files"] == ["module1.asm", "module2.asm"]
    assert ctx.metadata["timestamp"] == "2026-03-20T10:00:00Z"


def test_analysis_context_get_all_copy_includes():
    """Test retrieving all COPY includes"""
    ctx = AnalysisContext()

    ctx.add_copy_include("main.asm", "utils.asm", 10)
    ctx.add_copy_include("main.asm", "macros.asm", 20)
    ctx.add_copy_include("utils.asm", "common.asm", 30)

    all_includes = ctx.get_all_copy_includes()

    assert len(all_includes) == 3
    assert all_includes[0].including_file == "main.asm"
    assert all_includes[0].included_file == "utils.asm"
    assert all_includes[1].including_file == "main.asm"
    assert all_includes[1].included_file == "macros.asm"
    assert all_includes[2].including_file == "utils.asm"
    assert all_includes[2].included_file == "common.asm"


def test_analysis_context_get_includes_for_file():
    """Test getting COPY includes for specific file"""
    ctx = AnalysisContext()

    ctx.add_copy_include("main.asm", "utils.asm", 10)
    ctx.add_copy_include("main.asm", "macros.asm", 20)
    ctx.add_copy_include("utils.asm", "common.asm", 30)

    main_includes = ctx.get_includes_for_file("main.asm")

    assert len(main_includes) == 2
    assert "utils.asm" in main_includes
    assert "macros.asm" in main_includes

    utils_includes = ctx.get_includes_for_file("utils.asm")
    assert len(utils_includes) == 1
    assert "common.asm" in utils_includes


def test_analysis_context_line_metadata_index():
    """Test AnalysisContext stores LineMetadataIndex."""
    from pathlib import Path
    from models.line_metadata import LineMetadataIndex, LineMetadata, CodeblockContext, ConditionalContext, CallContext

    context = AnalysisContext(file_path=Path("test.c"))

    # Initially None
    assert context.line_metadata_index is None

    # Set index
    index = LineMetadataIndex()
    context.line_metadata_index = index

    assert context.line_metadata_index is index


def test_analysis_context_get_line_metadata():
    """Test get_line_metadata convenience method."""
    from pathlib import Path
    from models.line_metadata import LineMetadataIndex, LineMetadata, CodeblockContext, ConditionalContext, CallContext

    context = AnalysisContext(file_path=Path("test.c"))
    index = LineMetadataIndex()

    metadata = LineMetadata(
        file="test.c",
        line_number=42,
        codeblock=CodeblockContext(enclosing_function="main"),
        conditional=ConditionalContext(False, 0, [], []),
        calls=CallContext()
    )
    index.add(metadata)
    context.line_metadata_index = index

    # Test convenience method
    retrieved = context.get_line_metadata(42)
    assert retrieved is not None
    assert retrieved.line_number == 42
    assert retrieved.codeblock.enclosing_function == "main"


def test_analysis_context_get_line_metadata_no_index():
    """Test get_line_metadata returns None when no index."""
    from pathlib import Path

    context = AnalysisContext(file_path=Path("test.c"))
    result = context.get_line_metadata(42)
    assert result is None
