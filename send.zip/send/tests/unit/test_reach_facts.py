"""Tests for the block reachability facts index (Lineage Facts Index, Phase 2).

Covers:
- pack/unpack round-trip
- ingest_block_reach_facts → lookup_reach_facts parity with the live
  backward_reachable_blocks walk
- fallback semantics (before_line != 0, unknown block, absent table)
- skip_if_exists short-circuit
"""
import json
import sqlite3

import pytest

from backward_traversal.utils.reach_facts import (
    blueprint_stem,
    pack_reachable,
    unpack_reachable,
)


def test_pack_unpack_roundtrip():
    s = {"B1", "B2", "ENTRY_0001"}
    assert unpack_reachable(pack_reachable(s)) == s
    assert unpack_reachable(pack_reachable(set())) == set()


def test_blueprint_stem():
    from pathlib import Path
    assert blueprint_stem(Path("/x/y/XH72.asm.json")) == "xh72"
    assert blueprint_stem(Path("tf01.mac.json")) == "tf01"


@pytest.fixture()
def fake_job(tmp_path, monkeypatch):
    """A jobs/{id}/output/asm dir with one small blueprint + isolated engine cache."""
    from api.config import settings
    import api.index_db.engine as engine_mod

    monkeypatch.setattr(settings, "JOBS_BASE_DIR", tmp_path)
    # get_engine caches engines per job_id process-wide; isolate this test.
    monkeypatch.setattr(engine_mod, "_engines", {})

    job_id = "factsjob"
    out_dir = tmp_path / job_id / "output" / "asm"
    out_dir.mkdir(parents=True)

    bp = {
        "blocks": [
            {"id": "B1", "flow": []},
            {"id": "B2", "flow": [],
             "incoming_branches": [{"source": "B1", "type": "FALLTHROUGH"}]},
            {"id": "B3", "flow": [],
             "incoming_branches": [{"source": "B2", "type": "BRANCH"}]},
            {"id": "B4", "flow": []},
        ],
        "call_graph": {"edges": []},
    }
    bp_path = out_dir / "tf01.asm.json"
    bp_path.write_text(json.dumps(bp))
    return job_id, out_dir, bp_path, bp


def test_ingest_and_lookup_parity(fake_job):
    job_id, out_dir, bp_path, bp = fake_job
    from api.index_db.writers import ingest_block_reach_facts
    from backward_traversal.tracing.asm_backward_tracer import (
        backward_reachable_blocks,
    )
    from backward_traversal.utils import reach_facts as rf

    # Fresh reader so availability probes from other tests don't leak in.
    rf._reader = rf._ReachFactsReader()

    assert ingest_block_reach_facts(job_id, out_dir, skip_if_exists=False)

    db = out_dir.parents[1] / "index.db"
    rows = sqlite3.connect(db).execute(
        "SELECT file_stem, anchor_block, before_line FROM block_reach_facts"
    ).fetchall()
    assert len(rows) == 4
    assert all(r[0] == "tf01" and r[2] == 0 for r in rows)

    live = backward_reachable_blocks(
        bp, "B3", expand_subroutine_callers=True, bp_path=str(bp_path)
    )
    got = rf.lookup_reach_facts(str(bp_path), "B3", 0)
    assert got == live  # parity with the live CFG walk
    assert "B1" in got and "B2" in got and "B3" in got and "B4" not in got

    # Capped walks are not materialized — must fall back (None).
    assert rf.lookup_reach_facts(str(bp_path), "B3", 42) is None
    # Unknown block → None.
    assert rf.lookup_reach_facts(str(bp_path), "NOPE", 0) is None

    # skip_if_exists short-circuits without error.
    assert ingest_block_reach_facts(job_id, out_dir, skip_if_exists=True)

    rf.close_reach_facts_reader()


def test_lookup_absent_db_returns_none(tmp_path):
    """A blueprint with no index.db anywhere above it must return None."""
    from backward_traversal.utils import reach_facts as rf
    bp_path = tmp_path / "deep" / "output" / "asm" / "zz99.asm.json"
    bp_path.parent.mkdir(parents=True)
    bp_path.write_text("{}")
    assert rf.lookup_reach_facts(str(bp_path), "B1", 0) is None
