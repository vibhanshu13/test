"""Lineage edge emission must be PYTHONHASHSEED-independent.

Re-parsing the same corpus in a new worker process previously reordered
edges whose sources came from set iteration (register_sources unions in the
ASM path, resolve_aliases results in the C++ path).  Edge order feeds
seed-capped consumers downstream (ASM_MAX_SEEDS_PER_DEP_VAR BFS), so order
drift changes visible backward-lineage output between KB rebuilds.

The test parses fixtures in subprocesses under different hash seeds and
requires the exact edge sequence to match.
"""
import json
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]

ASM_FIXTURE = """\
TEST1    CSECT
         LM    R2,R4,SAVEAREA
         ICM   R10,15,LWRDCWA+4
         LA    R1,PARMLIST
         ENTRC AC71
SAVEAREA DS    3F
LWRDCWA  DS    F
PARMLIST DS    F
         END
"""

CPP_FIXTURE = """\
int helper() { int z = 1; return z; }
void f() {
    int logrec = 2;
    int myCmNumber = logrec;
    int* alias = &myCmNumber;
    int out = *alias;
    int got = helper();
}
"""

CHILD = """\
import json, sys
from pathlib import Path
sys.path.insert(0, {repo!r})
src_dir = Path({src_dir!r})

from multi_file.single_file_analyzer import SingleFileAnalyzer
from multi_file.c_family_analyzer import CFamilyAnalyzer

edges = []
asm_fp = src_dir / "t1.asm"
res = SingleFileAnalyzer([src_dir]).analyze(asm_fp, asm_fp.read_text())
g = res.analysis_context.get_metadata("variable_lineage")
edges += [(e.source, e.target, e.relation, e.line) for e in g.edges]

cpp_fp = src_dir / "t1.cpp"
res = CFamilyAnalyzer("cpp", search_paths=[src_dir]).analyze(cpp_fp, cpp_fp.read_text())
g = res.analysis_context.get_metadata("variable_lineage")
edges += [(e.source, e.target, e.relation, e.line) for e in g.edges]
print(json.dumps(edges))
"""


def test_edge_order_stable_across_hash_seeds(tmp_path):
    (tmp_path / "t1.asm").write_text(ASM_FIXTURE)
    (tmp_path / "t1.cpp").write_text(CPP_FIXTURE)
    script = CHILD.format(repo=str(REPO), src_dir=str(tmp_path))

    outputs = []
    for seed in ("0", "1", "2"):
        proc = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True, text=True, timeout=120,
            env={"PYTHONHASHSEED": seed, "PATH": "/usr/bin:/bin"},
        )
        assert proc.returncode == 0, proc.stderr[-2000:]
        outputs.append(json.loads(proc.stdout.strip().splitlines()[-1]))

    assert outputs[0], "fixture produced no lineage edges"
    assert outputs[0] == outputs[1] == outputs[2], (
        "edge emission order varies with PYTHONHASHSEED"
    )
