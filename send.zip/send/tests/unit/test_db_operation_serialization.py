"""Tests for DB operation serialization."""
import json
from models.db_operation import DBOperationType, DBOperation, DBOperationCatalog


def test_db_operation_to_dict():
    """Test DBOperation serialization to dict."""
    operation = DBOperation(
        operation_type=DBOperationType.READ,
        macro_name="DBRED",
        calling_routine="CUSTPROC",
        file_record_identifier="CUSTOMER",
        key_operands=["CUSTID"],
        access_mode="direct",
        source_file="cust.asm",
        source_line=200,
        source_section="CUSTCODE",
        confidence="high"
    )

    result = operation.to_dict()

    assert result == {
        "operation_type": "read",
        "macro_name": "DBRED",
        "calling_routine": "CUSTPROC",
        "file_record_identifier": "CUSTOMER",
        "key_operands": ["CUSTID"],
        "access_mode": "direct",
        "source_file": "cust.asm",
        "source_line": 200,
        "source_section": "CUSTCODE",
        "confidence": "high"
    }


def test_db_operation_catalog_to_dict():
    """Test DBOperationCatalog serialization to dict."""
    catalog = DBOperationCatalog()

    op1 = DBOperation(
        DBOperationType.READ, "DBRED", "PROC1", "FILE1", ["KEY1"],
        None, "test.asm", 1, "SECT1", "high"
    )
    op2 = DBOperation(
        DBOperationType.WRITE, "DBWRT", "PROC2", "FILE2", ["KEY2"],
        None, "test.asm", 2, "SECT1", "high"
    )

    catalog.add_operation(op1)
    catalog.add_operation(op2)

    result = catalog.to_dict()

    assert "operations" in result
    assert len(result["operations"]) == 2
    assert result["operations"][0]["operation_type"] == "read"
    assert result["operations"][1]["operation_type"] == "write"


def test_db_operation_to_json():
    """Test DBOperation can be JSON serialized."""
    operation = DBOperation(
        DBOperationType.UPDATE, "DBUPD", "UPDPROC", "ORDERS", [],
        None, "ord.asm", 50, None, "medium"
    )

    json_str = json.dumps(operation.to_dict())
    parsed = json.loads(json_str)

    assert parsed["operation_type"] == "update"
    assert parsed["macro_name"] == "DBUPD"
