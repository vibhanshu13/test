import pytest
from models.db_operation import (
    DBOperationType,
    DBOperation,
    DBOperationCatalog
)


def test_db_operation_creation():
    """Test creating a DB operation"""
    op = DBOperation(
        operation_type=DBOperationType.READ,
        macro_name="DBRED",
        calling_routine="FETCHREC",
        file_record_identifier="CUSTFILE",
        key_operands=["CUSTKEY"],
        access_mode="keyed",
        source_file="main.asm",
        source_line=42,
        source_section="FETCHREC",
        confidence="high"
    )

    assert op.operation_type == DBOperationType.READ
    assert op.macro_name == "DBRED"
    assert op.calling_routine == "FETCHREC"
    assert op.file_record_identifier == "CUSTFILE"
    assert op.key_operands == ["CUSTKEY"]


def test_db_operation_catalog_add():
    """Test adding operations to catalog"""
    catalog = DBOperationCatalog()

    op1 = DBOperation(
        operation_type=DBOperationType.READ,
        macro_name="DBRED",
        calling_routine="FETCHREC",
        file_record_identifier="CUSTFILE",
        key_operands=["CUSTKEY"],
        access_mode="keyed",
        source_file="main.asm",
        source_line=42,
        source_section="FETCHREC",
        confidence="high"
    )

    catalog.add_operation(op1)

    assert len(catalog.operations) == 1
    assert catalog.operations[0] == op1


def test_db_operation_catalog_filter_by_type():
    """Test filtering operations by type"""
    catalog = DBOperationCatalog()

    catalog.add_operation(DBOperation(
        operation_type=DBOperationType.READ,
        macro_name="DBRED",
        calling_routine="FETCHREC",
        file_record_identifier="CUSTFILE",
        key_operands=[],
        access_mode="keyed",
        source_file="main.asm",
        source_line=42,
        source_section="FETCHREC",
        confidence="high"
    ))

    catalog.add_operation(DBOperation(
        operation_type=DBOperationType.WRITE,
        macro_name="DBWRT",
        calling_routine="SAVEREC",
        file_record_identifier="CUSTFILE",
        key_operands=[],
        access_mode="keyed",
        source_file="main.asm",
        source_line=50,
        source_section="SAVEREC",
        confidence="high"
    ))

    reads = catalog.get_operations_by_type(DBOperationType.READ)
    assert len(reads) == 1
    assert reads[0].macro_name == "DBRED"


def test_db_operation_catalog_filter_by_routine():
    """Test filtering operations by calling routine"""
    catalog = DBOperationCatalog()

    catalog.add_operation(DBOperation(
        operation_type=DBOperationType.READ,
        macro_name="DBRED",
        calling_routine="FETCHREC",
        file_record_identifier="CUSTFILE",
        key_operands=[],
        access_mode="keyed",
        source_file="main.asm",
        source_line=42,
        source_section="FETCHREC",
        confidence="high"
    ))

    catalog.add_operation(DBOperation(
        operation_type=DBOperationType.READ,
        macro_name="DBRED",
        calling_routine="GETREC",
        file_record_identifier="ORDFILE",
        key_operands=[],
        access_mode="keyed",
        source_file="main.asm",
        source_line=60,
        source_section="GETREC",
        confidence="high"
    ))

    ops = catalog.get_operations_by_routine("FETCHREC")
    assert len(ops) == 1
    assert ops[0].calling_routine == "FETCHREC"
