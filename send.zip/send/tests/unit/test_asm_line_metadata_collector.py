"""Tests for ASM line metadata collector."""

from passes.asm_line_metadata_collector import ASMLineMetadataCollector


def test_collector_initialization():
    """Test collector initializes with empty state."""
    collector = ASMLineMetadataCollector()

    assert collector.metadata_list == []
    assert collector.current_section is None
    assert collector.current_routine is None
    assert collector.conditional_stack == []


def test_collector_enter_section():
    """Test entering a section updates state."""
    collector = ASMLineMetadataCollector()

    collector.enter_section("MAINSECT", line=10)

    assert collector.current_section == "MAINSECT"
    assert collector.current_routine is None


def test_collector_enter_routine():
    """Test entering a routine updates state."""
    collector = ASMLineMetadataCollector()
    collector.enter_section("MAINSECT", line=10)

    collector.enter_routine("INIT", line=20)

    assert collector.current_routine == "INIT"
    assert collector.current_section == "MAINSECT"


def test_collector_push_condition():
    """Test pushing conditional onto stack."""
    collector = ASMLineMetadataCollector()

    collector.push_condition("&DEBUG EQ 1", "AIF", line=30)

    assert len(collector.conditional_stack) == 1
    assert collector.conditional_stack[0] == ("&DEBUG EQ 1", "AIF")


def test_collector_nested_conditions():
    """Test nested conditional tracking."""
    collector = ASMLineMetadataCollector()

    collector.push_condition("&DEBUG EQ 1", "AIF", line=30)
    collector.push_condition("&MODE EQ 2", "AIF", line=35)

    assert len(collector.conditional_stack) == 2
    assert collector.conditional_stack[0][0] == "&DEBUG EQ 1"
    assert collector.conditional_stack[1][0] == "&MODE EQ 2"


def test_collector_pop_condition():
    """Test popping condition from stack."""
    collector = ASMLineMetadataCollector()
    collector.push_condition("&DEBUG EQ 1", "AIF", line=30)
    collector.push_condition("&MODE EQ 2", "AIF", line=35)

    collector.pop_condition(line=40)

    assert len(collector.conditional_stack) == 1
    assert collector.conditional_stack[0][0] == "&DEBUG EQ 1"


def test_collector_record_line_simple():
    """Test recording line with no context."""
    collector = ASMLineMetadataCollector()

    collector.record_line("test.asm", 100)

    assert len(collector.metadata_list) == 1
    metadata = collector.metadata_list[0]
    assert metadata.file == "test.asm"
    assert metadata.line_number == 100
    assert metadata.codeblock.in_executable_block is False
    assert metadata.conditional.is_conditional is False


def test_collector_record_line_in_section():
    """Test recording line inside section."""
    collector = ASMLineMetadataCollector()
    collector.enter_section("MAINSECT", line=10)

    collector.record_line("test.asm", 20)

    metadata = collector.metadata_list[0]
    assert metadata.codeblock.enclosing_section == "MAINSECT"
    assert metadata.codeblock.in_executable_block is True


def test_collector_record_line_in_routine():
    """Test recording line inside routine."""
    collector = ASMLineMetadataCollector()
    collector.enter_section("MAINSECT", line=10)
    collector.enter_routine("INIT", line=15)

    collector.record_line("test.asm", 20)

    metadata = collector.metadata_list[0]
    assert metadata.codeblock.enclosing_section == "MAINSECT"
    assert metadata.codeblock.enclosing_routine == "INIT"


def test_collector_record_line_in_conditional():
    """Test recording line inside conditional."""
    collector = ASMLineMetadataCollector()
    collector.enter_section("MAINSECT", line=10)
    collector.push_condition("&DEBUG EQ 1", "AIF", line=15)

    collector.record_line("test.asm", 20)

    metadata = collector.metadata_list[0]
    assert metadata.conditional.is_conditional is True
    assert metadata.conditional.depth == 1
    assert metadata.conditional.active_conditions == ["&DEBUG EQ 1"]
    assert metadata.conditional.condition_types == ["AIF"]


def test_collector_record_line_nested_conditionals():
    """Test recording line with nested conditionals."""
    collector = ASMLineMetadataCollector()
    collector.push_condition("&DEBUG EQ 1", "AIF", line=10)
    collector.push_condition("&MODE EQ 2", "AIF", line=15)

    collector.record_line("test.asm", 20)

    metadata = collector.metadata_list[0]
    assert metadata.conditional.depth == 2
    assert len(metadata.conditional.active_conditions) == 2
