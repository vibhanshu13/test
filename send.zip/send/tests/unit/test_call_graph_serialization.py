"""Tests for call graph serialization."""
import json
from models.call_graph import CallType, CallEdge, CallGraphNode, CallGraph


def test_call_edge_to_dict():
    """Test CallEdge serialization to dict."""
    edge = CallEdge(
        source="MAIN",
        target="HELPER",
        call_type=CallType.SUBROUTINE_CALL,
        instruction="BAL",
        file="main.asm",
        line=100
    )

    result = edge.to_dict()

    assert result == {
        "source": "MAIN",
        "target": "HELPER",
        "call_type": "subroutine_call",
        "instruction": "BAL",
        "file": "main.asm",
        "line": 100,
        "is_indirect": False,
        "register": None,
        "level_number": None,
    }


def test_call_graph_node_to_dict():
    """Test CallGraphNode serialization to dict."""
    node = CallGraphNode(
        name="PROCESS",
        section="CODE",
        file="proc.asm",
        is_external=False
    )

    result = node.to_dict()

    assert result == {
        "name": "PROCESS",
        "section": "CODE",
        "file": "proc.asm",
        "is_external": False,
        "kind": None,
    }


def test_call_graph_to_dict():
    """Test CallGraph serialization to dict."""
    graph = CallGraph()

    graph.add_node("MAIN", section="MAINCODE", file="main.asm", is_external=False)
    graph.add_node("HELPER", section="HELPERS", file="main.asm", is_external=False)

    graph.add_edge("MAIN", "HELPER", CallType.SUBROUTINE_CALL, "BAL", "main.asm", 10)

    result = graph.to_dict()

    assert "nodes" in result
    assert "edges" in result
    assert len(result["nodes"]) == 2
    assert len(result["edges"]) == 1
    assert result["nodes"]["MAIN"]["section"] == "MAINCODE"
