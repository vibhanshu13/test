import pytest
from macro_expander import MacroExpander
from models.macro_definition import MacroDefinition, MacroParameter
from pathlib import Path


@pytest.fixture
def chkrc_conditional_macro():
    """CHKRC macro with conditional assembly"""
    return MacroDefinition(
        name="CHKRC",
        parameters=[
            MacroParameter("&LABEL", None, True),
            MacroParameter("&RC", "0", False),
            MacroParameter("&ERROR", "ERROR", False)
        ],
        body=[
            "&LABEL   LTR   R15,R15",
            "         AIF   ('&RC' EQ '0').ZERO",
            "         C     R15,=F'&RC'",
            "         BNE   &ERROR",
            "         AGO   .DONE",
            ".ZERO    ANOP",
            "         BNZ   &ERROR",
            ".DONE    ANOP"
        ],
        source_file=Path("MACROS.asm"),
        start_line=12,
        end_line=21,
        scope="global"
    )


def test_expand_with_conditional_rc_zero(chkrc_conditional_macro):
    """Test expansion when RC=0 (takes .ZERO path)"""
    expander = MacroExpander()

    invocation = "CHKRC RC=0,ERROR=BADCARD"
    result = expander.expand(invocation, chkrc_conditional_macro)

    # Should skip non-zero path and go to .ZERO
    instructions = [i.instruction for i in result.expanded_instructions]

    assert "LTR   R15,R15" in " ".join(instructions)
    assert "BNZ   BADCARD" in " ".join(instructions)
    # Should NOT include the C and first BNE (skipped by AIF)
    assert "C     R15,=F'0'" not in " ".join(instructions)


def test_expand_with_conditional_rc_nonzero(chkrc_conditional_macro):
    """Test expansion when RC=4 (takes non-zero path)"""
    expander = MacroExpander()

    invocation = "CHKRC RC=4,ERROR=BADCARD"
    result = expander.expand(invocation, chkrc_conditional_macro)

    instructions = [i.instruction for i in result.expanded_instructions]

    assert "LTR   R15,R15" in " ".join(instructions)
    assert "C     R15,=F'4'" in " ".join(instructions)
    assert "BNE   BADCARD" in " ".join(instructions)


def test_expand_with_ago():
    """Test AGO (unconditional branch) processing"""
    macro = MacroDefinition(
        name="TESTAGO",
        parameters=[],
        body=[
            "         LA    R1,1",
            "         AGO   .SKIP",
            "         LA    R2,2",
            ".SKIP    ANOP",
            "         LA    R3,3"
        ],
        source_file=Path("test.asm"),
        start_line=1,
        end_line=6,
        scope="global"
    )

    expander = MacroExpander()
    result = expander.expand("TESTAGO", macro)

    instructions = [i.instruction for i in result.expanded_instructions]

    assert "LA    R1,1" in " ".join(instructions)
    assert "LA    R3,3" in " ".join(instructions)
    # LA R2,2 should be skipped
    assert "LA    R2,2" not in " ".join(instructions)


def test_expand_with_sequence_symbols():
    """Test that sequence symbols (.LABEL) are handled"""
    macro = MacroDefinition(
        name="TESTSEQ",
        parameters=[MacroParameter("&FLAG", "0", False)],
        body=[
            "         AIF   ('&FLAG' EQ '1').SET",
            "         LA    R1,0",
            "         AGO   .DONE",
            ".SET     ANOP",
            "         LA    R1,1",
            ".DONE    ANOP"
        ],
        source_file=Path("test.asm"),
        start_line=1,
        end_line=7,
        scope="global"
    )

    expander = MacroExpander()

    # Test with FLAG=0
    result = expander.expand("TESTSEQ FLAG=0", macro)
    instructions = [i.instruction for i in result.expanded_instructions]
    assert "LA    R1,0" in " ".join(instructions)

    # Test with FLAG=1
    result = expander.expand("TESTSEQ FLAG=1", macro)
    instructions = [i.instruction for i in result.expanded_instructions]
    assert "LA    R1,1" in " ".join(instructions)
