import pytest
from statement_id_generator import StatementIDGenerator


def test_statement_id_generator_sequential():
    """Test sequential ID generation"""
    gen = StatementIDGenerator()

    id1 = gen.next_id()
    id2 = gen.next_id()
    id3 = gen.next_id()

    assert id1 == "stmt_00001"
    assert id2 == "stmt_00002"
    assert id3 == "stmt_00003"


def test_statement_id_generator_reset():
    """Test resetting the generator"""
    gen = StatementIDGenerator()

    gen.next_id()
    gen.next_id()
    gen.reset()

    assert gen.next_id() == "stmt_00001"


def test_statement_id_generator_prefix():
    """Test custom prefix"""
    gen = StatementIDGenerator(prefix="test")

    assert gen.next_id() == "test_00001"
    assert gen.next_id() == "test_00002"
