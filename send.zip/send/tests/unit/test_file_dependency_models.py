import pytest
from models.file_dependency import (
    DependencyType,
    DependencyEvidence,
    FileDependencyNode,
    FileDependencyEdge,
    CircularDependency,
    FileDependencyGraph
)


def test_file_dependency_node_creation():
    """Test creating a file dependency node"""
    node = FileDependencyNode(
        file_path="main.asm",
        is_external=False
    )

    assert node.file_path == "main.asm"
    assert node.is_external is False


def test_file_dependency_edge_creation():
    """Test creating a file dependency edge"""
    evidence = DependencyEvidence(
        dependency_type=DependencyType.COPY_INCLUDE,
        source_file="main.asm",
        source_line=10,
        details="COPY MACROS"
    )

    edge = FileDependencyEdge(
        from_file="main.asm",
        to_file="macros.mac",
        evidence=[evidence]
    )

    assert edge.from_file == "main.asm"
    assert edge.to_file == "macros.mac"
    assert len(edge.evidence) == 1
    assert edge.evidence[0].dependency_type == DependencyType.COPY_INCLUDE


def test_file_dependency_graph_add_node():
    """Test adding nodes to graph"""
    graph = FileDependencyGraph()

    graph.add_node("main.asm")
    graph.add_node("helper.asm")

    assert "main.asm" in graph.nodes
    assert "helper.asm" in graph.nodes
    assert len(graph.nodes) == 2


def test_file_dependency_graph_add_edge():
    """Test adding edges to graph"""
    graph = FileDependencyGraph()

    evidence = DependencyEvidence(
        dependency_type=DependencyType.SYMBOL_REFERENCE,
        source_file="main.asm",
        source_line=5,
        details="EXTRN HELPER"
    )

    graph.add_edge("main.asm", "helper.asm", evidence)

    assert len(graph.edges) == 1
    edge = graph.edges[0]
    assert edge.from_file == "main.asm"
    assert edge.to_file == "helper.asm"


def test_file_dependency_graph_get_dependencies():
    """Test getting dependencies of a file"""
    graph = FileDependencyGraph()

    evidence1 = DependencyEvidence(
        dependency_type=DependencyType.COPY_INCLUDE,
        source_file="main.asm",
        source_line=1,
        details="COPY MACROS"
    )

    evidence2 = DependencyEvidence(
        dependency_type=DependencyType.SYMBOL_REFERENCE,
        source_file="main.asm",
        source_line=5,
        details="EXTRN HELPER"
    )

    graph.add_edge("main.asm", "macros.mac", evidence1)
    graph.add_edge("main.asm", "helper.asm", evidence2)

    deps = graph.get_dependencies("main.asm")
    assert len(deps) == 2
    assert "macros.mac" in deps
    assert "helper.asm" in deps


def test_circular_dependency_creation():
    """Test creating circular dependency record"""
    cycle = CircularDependency(
        files=["a.asm", "b.asm", "a.asm"],
        cycle_type="simple"
    )

    assert len(cycle.files) == 3
    assert cycle.cycle_type == "simple"
    assert cycle.files[0] == cycle.files[-1]  # Cycle
