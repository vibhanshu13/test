"""Tests for external call identifier."""

import pytest
from external_call_identifier import ExternalCallIdentifier


def test_identify_c_function():
    """Test identifying C standard library functions"""
    identifier = ExternalCallIdentifier()

    # Common C functions
    assert identifier.is_external_call("sprintf") is True
    assert identifier.is_external_call("memcpy") is True
    assert identifier.is_external_call("malloc") is True
    assert identifier.is_external_call("printf") is True
    assert identifier.is_external_call("strcpy") is True


def test_identify_zos_service():
    """Test identifying z/OS system services"""
    identifier = ExternalCallIdentifier()

    # Common z/OS services
    assert identifier.is_external_call("STORAGE") is True
    assert identifier.is_external_call("GETMAIN") is True
    assert identifier.is_external_call("ATTACH") is True
    assert identifier.is_external_call("WTO") is True


def test_not_external():
    """Test that local routines are not identified as external"""
    identifier = ExternalCallIdentifier()

    # Typical assembly routine names (uppercase, descriptive)
    assert identifier.is_external_call("MAINPROG") is False
    assert identifier.is_external_call("HELPER") is False
    assert identifier.is_external_call("PROCESS_DATA") is False
    assert identifier.is_external_call("INIT_SYSTEM") is False


def test_lowercase_heuristic():
    """Test that lowercase names are treated as likely C functions"""
    identifier = ExternalCallIdentifier()

    # Lowercase names (C function pattern)
    assert identifier.is_external_call("myfunction") is True
    assert identifier.is_external_call("helper") is True

    # But not names starting with underscore
    assert identifier.is_external_call("_internal") is False


def test_get_external_type_c_function():
    """Test getting external type for C functions"""
    identifier = ExternalCallIdentifier()

    assert identifier.get_external_type("sprintf") == "c_function"
    assert identifier.get_external_type("memcpy") == "c_function"
    assert identifier.get_external_type("malloc") == "c_function"

    # Heuristic: lowercase
    assert identifier.get_external_type("myfunction") == "c_function"


def test_get_external_type_zos_service():
    """Test getting external type for z/OS services"""
    identifier = ExternalCallIdentifier()

    assert identifier.get_external_type("STORAGE") == "zos_service"
    assert identifier.get_external_type("GETMAIN") == "zos_service"
    assert identifier.get_external_type("WTO") == "zos_service"


def test_get_external_type_not_external():
    """Test that local routines return None for external type"""
    identifier = ExternalCallIdentifier()

    assert identifier.get_external_type("MAINPROG") is None
    assert identifier.get_external_type("HELPER") is None
    assert identifier.get_external_type("PROCESS_DATA") is None


def test_case_insensitive_c_functions():
    """Test that C function detection is case-sensitive (lowercase expected)"""
    identifier = ExternalCallIdentifier()

    # Lowercase should match
    assert identifier.is_external_call("sprintf") is True

    # Uppercase should not match as known C function, but may match z/OS
    # (SPRINTF is not a z/OS service, so it would return False)
    assert identifier.is_external_call("SPRINTF") is False


def test_case_insensitive_zos_services():
    """Test that z/OS service detection works regardless of case"""
    identifier = ExternalCallIdentifier()

    # Uppercase should match
    assert identifier.is_external_call("STORAGE") is True

    # Lowercase should also match after uppercasing
    assert identifier.is_external_call("storage") is True
