import pytest
from models.conditional_assembly import (
    SetSymbol,
    SetSymbolTable,
    SequenceSymbol,
    AIFDirective,
    AGODirective,
    ANOPDirective,
    ConditionalAssemblyState
)


def test_set_symbol_creation():
    """Test creating SET symbols"""
    sym = SetSymbol(name="&VAR", value=10, symbol_type="SETA")

    assert sym.name == "&VAR"
    assert sym.value == 10
    assert sym.symbol_type == "SETA"


def test_set_symbol_table():
    """Test SET symbol table"""
    table = SetSymbolTable()

    table.set("&COUNT", 5, "SETA")
    table.set("&FLAG", True, "SETB")
    table.set("&NAME", "TEST", "SETC")

    assert table.get("&COUNT") == 5
    assert table.get("&FLAG") is True
    assert table.get("&NAME") == "TEST"


def test_set_symbol_table_update():
    """Test updating SET symbols"""
    table = SetSymbolTable()

    table.set("&VAR", 10, "SETA")
    assert table.get("&VAR") == 10

    table.set("&VAR", 20, "SETA")
    assert table.get("&VAR") == 20


def test_set_symbol_table_unknown():
    """Test getting unknown symbol returns None"""
    table = SetSymbolTable()

    assert table.get("&UNKNOWN") is None


def test_sequence_symbol():
    """Test sequence symbol (label for AGO/AIF)"""
    seq = SequenceSymbol(name=".LOOP", target_line=100)

    assert seq.name == ".LOOP"
    assert seq.target_line == 100


def test_aif_directive_creation():
    """Test AIF (conditional if) directive creation."""
    aif = AIFDirective(
        condition="&VAR EQ 1",
        target=".LABEL1",
        source_line=10
    )

    assert aif.condition == "&VAR EQ 1"
    assert aif.target == ".LABEL1"
    assert aif.source_line == 10


def test_ago_directive_creation():
    """Test AGO (unconditional goto) directive creation."""
    ago = AGODirective(
        target=".DONE",
        source_line=20
    )

    assert ago.target == ".DONE"
    assert ago.source_line == 20


def test_anop_directive_creation():
    """Test ANOP (label definition) directive creation."""
    anop = ANOPDirective(
        label=".START",
        source_line=5
    )

    assert anop.label == ".START"
    assert anop.source_line == 5


def test_conditional_assembly_state():
    """Test ConditionalAssemblyState initialization and sequence label tracking."""
    state = ConditionalAssemblyState()

    # Test initialization
    assert isinstance(state.set_symbols, SetSymbolTable)
    assert len(state.sequence_labels) == 0
    assert len(state.active_conditions) == 0

    # Test sequence label definition
    state.define_sequence_label(".LOOP", 100)
    assert state.has_sequence_label(".LOOP")
    assert state.get_sequence_label_line(".LOOP") == 100

    # Test undefined label
    assert not state.has_sequence_label(".UNDEFINED")
    assert state.get_sequence_label_line(".UNDEFINED") is None


def test_set_symbol_table_set_value():
    """Test SetSymbolTable.set_value convenience method."""
    table = SetSymbolTable()

    # Test with integer (SETA)
    table.set_value("&COUNT", 10)
    assert table.get_value("&COUNT") == 10

    # Test with boolean (SETB)
    table.set_value("&FLAG", True)
    assert table.get_value("&FLAG") is True

    # Test with string (SETC)
    table.set_value("&NAME", "TEST")
    assert table.get_value("&NAME") == "TEST"


def test_set_symbol_table_get_value_unknown():
    """Test SetSymbolTable.get_value returns 'UNKNOWN' for undefined symbols."""
    table = SetSymbolTable()

    assert table.get_value("&UNDEFINED") == "UNKNOWN"


def test_macro_param_set_and_get():
    """Test setting and getting macro parameters."""
    state = ConditionalAssemblyState()

    # Set macro parameters
    state.set_macro_param("&PARM1", "VALUE1")
    state.set_macro_param("&PARM2", "VALUE2")

    # Get macro parameters
    assert state.get_macro_param("&PARM1") == "VALUE1"
    assert state.get_macro_param("&PARM2") == "VALUE2"


def test_macro_param_has():
    """Test checking if macro parameter is defined."""
    state = ConditionalAssemblyState()

    state.set_macro_param("&DEFINED", "VALUE")

    assert state.has_macro_param("&DEFINED") is True
    assert state.has_macro_param("&UNDEFINED") is False


def test_macro_param_get_undefined():
    """Test getting undefined macro parameter returns None."""
    state = ConditionalAssemblyState()

    assert state.get_macro_param("&UNDEFINED") is None


def test_macro_param_clear():
    """Test clearing macro parameters."""
    state = ConditionalAssemblyState()

    # Set parameters
    state.set_macro_param("&PARM1", "VALUE1")
    state.set_macro_param("&PARM2", "VALUE2")
    assert len(state.macro_params) == 2

    # Clear parameters
    state.clear_macro_params()
    assert len(state.macro_params) == 0
    assert state.get_macro_param("&PARM1") is None


def test_macro_param_update():
    """Test updating macro parameter value."""
    state = ConditionalAssemblyState()

    # Set initial value
    state.set_macro_param("&PARM", "INITIAL")
    assert state.get_macro_param("&PARM") == "INITIAL"

    # Update value
    state.set_macro_param("&PARM", "UPDATED")
    assert state.get_macro_param("&PARM") == "UPDATED"
