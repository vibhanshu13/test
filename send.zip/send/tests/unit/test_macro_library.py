import pytest
from pathlib import Path
from macro_library import MacroLibrary
from models.macro_definition import MacroDefinition, MacroParameter


@pytest.fixture
def sample_macros():
    """Create sample macro definitions for testing"""
    chkrc = MacroDefinition(
        name="CHKRC",
        parameters=[
            MacroParameter("&LABEL", None, True),
            MacroParameter("&RC", "0", False),
            MacroParameter("&ERROR", "ERROR", False)
        ],
        body=["LTR   R15,R15", "BNZ   &ERROR"],
        source_file=Path("MACROS.asm"),
        start_line=12,
        end_line=21,
        scope="global"
    )

    setrc = MacroDefinition(
        name="SETRC",
        parameters=[MacroParameter("&RC", None, False)],
        body=["LA    R15,&RC", "BR    R14"],
        source_file=Path("MACROS.asm"),
        start_line=44,
        end_line=47,
        scope="global"
    )

    return [chkrc, setrc]


def test_macro_library_creation():
    """Test creating empty macro library"""
    lib = MacroLibrary()
    assert lib.get_macro_count() == 0


def test_add_macro(sample_macros):
    """Test adding a macro to library"""
    lib = MacroLibrary()
    lib.add_macro(sample_macros[0])

    assert lib.get_macro_count() == 1
    assert lib.has_macro("CHKRC")


def test_get_macro(sample_macros):
    """Test retrieving a macro from library"""
    lib = MacroLibrary()
    lib.add_macro(sample_macros[0])

    macro = lib.get_macro("CHKRC")
    assert macro is not None
    assert macro.name == "CHKRC"
    assert len(macro.parameters) == 3


def test_get_macro_case_insensitive(sample_macros):
    """Test macro lookup is case-insensitive"""
    lib = MacroLibrary()
    lib.add_macro(sample_macros[0])

    assert lib.has_macro("chkrc")
    assert lib.has_macro("CHKRC")
    assert lib.has_macro("ChKrC")


def test_get_nonexistent_macro():
    """Test retrieving macro that doesn't exist"""
    lib = MacroLibrary()

    macro = lib.get_macro("UNKNOWN")
    assert macro is None
    assert not lib.has_macro("UNKNOWN")


def test_override_macro(sample_macros):
    """Test overriding an existing macro definition"""
    lib = MacroLibrary()

    # Add first version
    lib.add_macro(sample_macros[0])
    assert lib.get_macro_count() == 1

    # Override with new definition
    new_chkrc = MacroDefinition(
        name="CHKRC",
        parameters=[],
        body=["NOP"],
        source_file=Path("custom.asm"),
        start_line=1,
        end_line=3,
        scope="local"
    )

    lib.add_macro(new_chkrc, override=True)
    assert lib.get_macro_count() == 1

    macro = lib.get_macro("CHKRC")
    assert macro.source_file == Path("custom.asm")
    assert macro.scope == "local"


def test_add_multiple_macros(sample_macros):
    """Test adding multiple macros"""
    lib = MacroLibrary()

    for macro in sample_macros:
        lib.add_macro(macro)

    assert lib.get_macro_count() == 2
    assert lib.has_macro("CHKRC")
    assert lib.has_macro("SETRC")


def test_get_all_macros(sample_macros):
    """Test getting all macros from library"""
    lib = MacroLibrary()

    for macro in sample_macros:
        lib.add_macro(macro)

    all_macros = lib.get_all_macros()
    assert len(all_macros) == 2
    macro_names = [m.name for m in all_macros]
    assert "CHKRC" in macro_names
    assert "SETRC" in macro_names
