"""Tests for C/C++ line metadata collector."""

from passes.c_line_metadata_collector import CLineMetadataCollector


def test_c_collector_initialization():
    """Test C collector initializes with empty state."""
    collector = CLineMetadataCollector()

    assert collector.metadata_list == []
    assert collector.current_function is None
    assert collector.conditional_stack == []


def test_c_collector_enter_function():
    """Test entering function updates state."""
    collector = CLineMetadataCollector()

    collector.enter_function("main", start_line=10, end_line=50)

    assert collector.current_function == "main"


def test_c_collector_exit_function():
    """Test exiting function clears state."""
    collector = CLineMetadataCollector()
    collector.enter_function("main", start_line=10, end_line=50)

    collector.exit_function()

    assert collector.current_function is None


def test_c_collector_push_condition():
    """Test pushing conditional."""
    collector = CLineMetadataCollector()

    collector.push_condition("x > 0", "if")

    assert len(collector.conditional_stack) == 1
    assert collector.conditional_stack[0] == ("x > 0", "if")


def test_c_collector_nested_conditions():
    """Test nested conditionals."""
    collector = CLineMetadataCollector()

    collector.push_condition("x > 0", "if")
    collector.push_condition("y < 10", "while")

    assert len(collector.conditional_stack) == 2


def test_c_collector_pop_condition():
    """Test popping condition."""
    collector = CLineMetadataCollector()
    collector.push_condition("x > 0", "if")
    collector.push_condition("y < 10", "while")

    collector.pop_condition()

    assert len(collector.conditional_stack) == 1
    assert collector.conditional_stack[0][0] == "x > 0"


def test_c_collector_record_line_in_function():
    """Test recording line inside function."""
    collector = CLineMetadataCollector()
    collector.enter_function("main", 10, 50)

    collector.record_line("test.c", 20)

    metadata = collector.metadata_list[0]
    assert metadata.codeblock.enclosing_function == "main"
    assert metadata.codeblock.in_executable_block is True


def test_c_collector_record_line_in_conditional():
    """Test recording line in conditional."""
    collector = CLineMetadataCollector()
    collector.enter_function("main", 10, 50)
    collector.push_condition("x > 0", "if")

    collector.record_line("test.c", 20)

    metadata = collector.metadata_list[0]
    assert metadata.conditional.is_conditional is True
    assert metadata.conditional.depth == 1
    assert metadata.conditional.active_conditions == ["x > 0"]
    assert metadata.conditional.condition_types == ["if"]


def test_c_collector_record_multiple_lines():
    """Test recording multiple lines tracks state correctly."""
    collector = CLineMetadataCollector()
    collector.enter_function("main", 10, 50)

    # Record line outside conditional
    collector.record_line("test.c", 15)

    # Enter conditional
    collector.push_condition("x > 0", "if")
    collector.record_line("test.c", 20)

    # Nested conditional
    collector.push_condition("y < 10", "while")
    collector.record_line("test.c", 25)

    assert len(collector.metadata_list) == 3
    assert collector.metadata_list[0].conditional.depth == 0
    assert collector.metadata_list[1].conditional.depth == 1
    assert collector.metadata_list[2].conditional.depth == 2
