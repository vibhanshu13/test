from pathlib import Path

import pytest

from multi_file.c_family_analyzer import CFamilyAnalyzer
from models.call_graph import CallType


def _require_cpp_analyzer() -> CFamilyAnalyzer:
    analyzer = CFamilyAnalyzer("cpp")
    if not analyzer.parser.available:
        pytest.skip("tree-sitter parser unavailable")
    return analyzer


def test_analyzer_filters_non_linkable_cxx_calls_from_extrn():
    analyzer = _require_cpp_analyzer()
    text = """
struct Obj {
    int size() const;
};

extern "C" int asm_real_external(int);

int run(int (*fp)(int), Obj obj, int raw) {
    int v = fp(raw);
    int n = static_cast<int>(obj.size());
    return asm_real_external(v + n);
}
"""

    result = analyzer.analyze(Path("demo.cpp"), text)
    imports = set(result.imports)

    assert "asm_real_external" in imports
    assert "fp" not in imports
    assert "static_cast<int>" not in imports
    assert "obj.size" not in imports


def test_analyzer_attaches_level_number_for_get_level_calls():
    analyzer = _require_cpp_analyzer()
    text = """
extern "C" void* get_level(int level, int type, int size);

void run() {
    void* p = get_level(LEVEL0, 1, 256);
    (void)p;
}
"""

    result = analyzer.analyze(Path("levels.cpp"), text)
    edges = [e for e in result.call_graph.edges if e.target == "get_level"]
    assert edges, "expected at least one get_level call edge"
    assert any(e.level_number == 0 for e in edges)
    assert result.call_graph.nodes["run"].kind == "function"
    assert result.call_graph.nodes["get_level"].kind == "function"


def test_analyzer_attaches_level_number_for_get_level_numeric_literal():
    analyzer = _require_cpp_analyzer()
    text = """
extern "C" void* get_level(int level, int type, int size);

void run() {
    void* p = get_level(0 /*LEVEL0*/, 1, 256);
    (void)p;
}
"""

    result = analyzer.analyze(Path("levels_numeric.cpp"), text)
    edges = [e for e in result.call_graph.edges if e.target == "get_level"]
    assert edges, "expected at least one get_level call edge"
    assert any(e.level_number == 0 for e in edges)


def test_analyzer_attaches_level_number_for_get_level_d_level_token():
    analyzer = _require_cpp_analyzer()
    text = """
extern "C" void* get_level(int level, int type, int size);

void run() {
    void* p = get_level(Df, 1, 256);
    (void)p;
}
"""

    result = analyzer.analyze(Path("levels_dhex.cpp"), text)
    edges = [e for e in result.call_graph.edges if e.target == "get_level"]
    assert edges, "expected at least one get_level call edge"
    assert any(e.level_number == 15 for e in edges)


def test_analyzer_emits_call_edge_and_asm_alias_symbol():
    analyzer = _require_cpp_analyzer()
    text = """
extern "C" int processBuffer(char* input, char* output, int size) asm("ASM_PROCBF");

int process_buffer_pipeline(char* raw_input, char* output, int input_size) {
    return processBuffer(raw_input, output, input_size);
}
"""

    result = analyzer.analyze(Path("bridge.cpp"), text)

    call_edges = [
        e for e in result.call_graph.edges
        if e.source == "process_buffer_pipeline" and e.target == "processBuffer" and e.line == 5
    ]
    assert call_edges
    assert any(e.call_type == CallType.CALL for e in call_edges)

    symbol = result.symbol_table.global_symbols.get("processBuffer")
    assert symbol is not None
    assert symbol.asm_name == "ASM_PROCBF"


def test_analyzer_emits_expression_callee_for_assignment_callsite():
    analyzer = _require_cpp_analyzer()
    text = """
extern "C" int processBuffer(char* input, char* output, int size) asm("ASM_PROCBF");

int process_buffer_pipeline(const char* raw_input, char* output, int input_size) {
    int checksum = processBuffer(raw_input, output, input_size);
    return checksum;
}
"""

    result = analyzer.analyze(Path("bridge_assign.cpp"), text)

    primary_edges = [
        e for e in result.call_graph.edges
        if e.source == "process_buffer_pipeline"
        and e.target == "processBuffer"
        and e.line == 5
    ]
    assert primary_edges
    assert any(e.call_type == CallType.CALL for e in primary_edges)

    alias_edges = [
        e for e in result.call_graph.edges
        if e.source == "process_buffer_pipeline"
        and e.target == "ASM_PROCBF"
        and e.line == 5
    ]
    assert alias_edges
    assert any(e.call_type == CallType.SUBROUTINE_CALL for e in alias_edges)
