import pytest
from models.copy_directive import CopyDirective, CopyIncludeStack, parse_copy_directive
from models.provenance import StatementProvenance
from tokenizer import ParsedLine


def test_copy_directive_creation():
    """Test creating a COPY directive"""
    prov = StatementProvenance("stmt_00001", "main.asm", 10)

    directive = CopyDirective(
        target_file="utils.asm",
        provenance=prov
    )

    assert directive.target_file == "utils.asm"
    assert directive.provenance == prov


def test_copy_include_stack_push():
    """Test pushing onto include stack"""
    stack = CopyIncludeStack()

    stack.push("main.asm")
    stack.push("utils.asm")

    assert stack.depth() == 2
    assert stack.current_file() == "utils.asm"


def test_copy_include_stack_pop():
    """Test popping from include stack"""
    stack = CopyIncludeStack()

    stack.push("main.asm")
    stack.push("utils.asm")
    stack.pop()

    assert stack.depth() == 1
    assert stack.current_file() == "main.asm"


def test_copy_include_circular_detection():
    """Test detecting circular includes"""
    stack = CopyIncludeStack()

    stack.push("main.asm")
    stack.push("utils.asm")

    # Try to include main.asm again (circular)
    assert stack.is_circular("main.asm") is True
    assert stack.is_circular("macros.asm") is False


def test_copy_include_max_depth():
    """Test max depth enforcement"""
    stack = CopyIncludeStack(max_depth=3)

    stack.push("file1.asm")
    stack.push("file2.asm")
    stack.push("file3.asm")

    # Should be at max depth
    with pytest.raises(ValueError, match="Maximum include depth"):
        stack.push("file4.asm")


def test_parse_copy_directive():
    """Test parsing COPY directive from ParsedLine"""
    prov = StatementProvenance("stmt_00001", "main.asm", 10)

    parsed = ParsedLine(
        label=None,
        opcode="COPY",
        operands=["UTILS"],
        comment=None,
        provenance=prov
    )

    directive = parse_copy_directive(parsed)

    assert directive is not None
    assert directive.target_file == "UTILS"
    assert directive.provenance == prov


def test_parse_copy_with_extension():
    """Test parsing COPY with file extension"""
    prov = StatementProvenance("stmt_00002", "main.asm", 20)

    parsed = ParsedLine(
        label=None,
        opcode="COPY",
        operands=["MACROS.ASM"],
        comment=None,
        provenance=prov
    )

    directive = parse_copy_directive(parsed)

    assert directive.target_file == "MACROS.ASM"


def test_parse_non_copy_directive():
    """Test that non-COPY directives return None"""
    prov = StatementProvenance("stmt_00003", "main.asm", 30)

    parsed = ParsedLine(
        label="LOOP",
        opcode="BAS",
        operands=["R14", "SUBRTN"],
        comment=None,
        provenance=prov
    )

    directive = parse_copy_directive(parsed)

    assert directive is None


def test_parse_copy_no_operands():
    """Test COPY with no operands returns None"""
    prov = StatementProvenance("stmt_00004", "main.asm", 40)

    parsed = ParsedLine(
        label=None,
        opcode="COPY",
        operands=[],
        comment=None,
        provenance=prov
    )

    directive = parse_copy_directive(parsed)

    assert directive is None
