"""Tests for global symbol registry."""
from multi_file.symbol_registry import GlobalSymbolRegistry, ResolutionResult, Confidence
from models.symbol import Symbol, SymbolType
from models.provenance import StatementProvenance


def test_registry_adds_entry_symbols():
    """Test registry can store ENTRY symbols."""
    registry = GlobalSymbolRegistry()

    prov = StatementProvenance("stmt_1", "module1.asm", 10)
    symbol = Symbol("MAIN", SymbolType.ENTRY, file="module1.asm", provenance=prov)

    registry.add_entry(symbol)

    assert "MAIN" in registry.entries
    assert len(registry.entries["MAIN"]) == 1
    assert registry.entries["MAIN"][0].name == "MAIN"


def test_registry_adds_extrn_symbols():
    """Test registry can store EXTRN symbols."""
    registry = GlobalSymbolRegistry()

    prov = StatementProvenance("stmt_1", "module2.asm", 5)
    symbol = Symbol("HELPER", SymbolType.EXTRN, file="module2.asm", provenance=prov)

    registry.add_extrn(symbol)

    assert "HELPER" in registry.extrns
    assert len(registry.extrns["HELPER"]) == 1


def test_registry_resolves_single_entry():
    """Test registry resolves EXTRN to single ENTRY."""
    registry = GlobalSymbolRegistry()

    # Add ENTRY
    prov1 = StatementProvenance("stmt_1", "module1.asm", 10)
    entry = Symbol("FUNC", SymbolType.ENTRY, file="module1.asm", provenance=prov1)
    registry.add_entry(entry)

    # Add EXTRN
    prov2 = StatementProvenance("stmt_2", "module2.asm", 20)
    extrn = Symbol("FUNC", SymbolType.EXTRN, file="module2.asm", provenance=prov2)

    # Resolve
    result = registry.resolve_extrn(extrn)

    assert result.resolved is True
    assert len(result.targets) == 1
    assert result.targets[0].name == "FUNC"
    assert result.confidence == Confidence.HIGH


def test_registry_handles_duplicate_entries():
    """Test registry detects duplicate ENTRY symbols."""
    registry = GlobalSymbolRegistry()

    # Add first ENTRY
    prov1 = StatementProvenance("stmt_1", "module1.asm", 10)
    entry1 = Symbol("DUP", SymbolType.ENTRY, file="module1.asm", provenance=prov1)
    registry.add_entry(entry1)

    # Add duplicate ENTRY
    prov2 = StatementProvenance("stmt_2", "module2.asm", 50)
    entry2 = Symbol("DUP", SymbolType.ENTRY, file="module2.asm", provenance=prov2)
    registry.add_entry(entry2)

    # Should have both
    assert len(registry.entries["DUP"]) == 2

    # Resolution should return both with medium confidence
    prov3 = StatementProvenance("stmt_3", "module3.asm", 5)
    extrn = Symbol("DUP", SymbolType.EXTRN, file="module3.asm", provenance=prov3)
    result = registry.resolve_extrn(extrn)

    assert result.resolved is True
    assert len(result.targets) == 2
    assert result.confidence == Confidence.MEDIUM


def test_registry_handles_unresolved_extrn():
    """Test registry handles EXTRN with no ENTRY."""
    registry = GlobalSymbolRegistry()

    # EXTRN with no matching ENTRY
    prov = StatementProvenance("stmt_1", "module1.asm", 10)
    extrn = Symbol("MISSING", SymbolType.EXTRN, file="module1.asm", provenance=prov)

    result = registry.resolve_extrn(extrn)

    assert result.resolved is False
    assert len(result.targets) == 0
    assert result.confidence == Confidence.LOW


def test_registry_adds_wxtrn_symbols():
    """Test registry can store WXTRN (weak external) symbols."""
    registry = GlobalSymbolRegistry()

    prov = StatementProvenance("stmt_1", "module2.asm", 5)
    symbol = Symbol("WEAKFUNC", SymbolType.WXTRN, file="module2.asm", provenance=prov)

    registry.add_wxtrn(symbol)

    assert "WEAKFUNC" in registry.wxtrns
    assert len(registry.wxtrns["WEAKFUNC"]) == 1


def test_registry_resolves_wxtrn_with_no_match():
    """Test WXTRN with no ENTRY has MEDIUM confidence (optional)."""
    registry = GlobalSymbolRegistry()

    # WXTRN with no matching ENTRY
    prov = StatementProvenance("stmt_1", "module1.asm", 10)
    wxtrn = Symbol("OPTIONAL", SymbolType.WXTRN, file="module1.asm", provenance=prov)

    result = registry.resolve_wxtrn(wxtrn)

    assert result.resolved is False
    assert len(result.targets) == 0
    assert result.confidence == Confidence.MEDIUM  # Higher than EXTRN since weak is optional
    assert "optional" in result.reason.lower()


def test_registry_resolves_wxtrn_with_single_match():
    """Test WXTRN resolves cleanly to single ENTRY."""
    registry = GlobalSymbolRegistry()

    # Add ENTRY
    prov1 = StatementProvenance("stmt_1", "module1.asm", 10)
    entry = Symbol("WEAKFUNC", SymbolType.ENTRY, file="module1.asm", provenance=prov1)
    registry.add_entry(entry)

    # Add WXTRN
    prov2 = StatementProvenance("stmt_2", "module2.asm", 20)
    wxtrn = Symbol("WEAKFUNC", SymbolType.WXTRN, file="module2.asm", provenance=prov2)

    # Resolve
    result = registry.resolve_wxtrn(wxtrn)

    assert result.resolved is True
    assert len(result.targets) == 1
    assert result.targets[0].name == "WEAKFUNC"
    assert result.confidence == Confidence.HIGH


def test_registry_resolves_wxtrn_with_multiple_matches():
    """Test WXTRN with multiple ENTRYs chooses first definition."""
    registry = GlobalSymbolRegistry()

    # Add multiple ENTRY symbols with same name
    prov1 = StatementProvenance("stmt_1", "module1.asm", 10)
    entry1 = Symbol("MULTI", SymbolType.ENTRY, file="module1.asm", provenance=prov1)
    registry.add_entry(entry1)

    prov2 = StatementProvenance("stmt_2", "module2.asm", 50)
    entry2 = Symbol("MULTI", SymbolType.ENTRY, file="module2.asm", provenance=prov2)
    registry.add_entry(entry2)

    # Add WXTRN
    prov3 = StatementProvenance("stmt_3", "module3.asm", 5)
    wxtrn = Symbol("MULTI", SymbolType.WXTRN, file="module3.asm", provenance=prov3)

    # Resolve
    result = registry.resolve_wxtrn(wxtrn)

    assert result.resolved is True
    assert len(result.targets) == 1  # Chooses first, not all
    assert result.targets[0] == entry1  # First definition
    assert result.confidence == Confidence.MEDIUM  # Multiple definitions present
    assert "2 definitions" in result.reason


def test_priority_rules_same_directory_preference():
    """Test priority rules prefer symbol from same directory."""
    registry = GlobalSymbolRegistry()

    # Add ENTRY symbols in different directories
    prov1 = StatementProvenance("stmt_1", "src/utils/helper.asm", 10)
    entry1 = Symbol("FUNC", SymbolType.ENTRY, file="src/utils/helper.asm", provenance=prov1)
    registry.add_entry(entry1)

    prov2 = StatementProvenance("stmt_2", "src/other/helper.asm", 20)
    entry2 = Symbol("FUNC", SymbolType.ENTRY, file="src/other/helper.asm", provenance=prov2)
    registry.add_entry(entry2)

    # EXTRN from src/utils directory - should prefer same directory
    prov3 = StatementProvenance("stmt_3", "src/utils/main.asm", 5)
    extrn = Symbol("FUNC", SymbolType.EXTRN, file="src/utils/main.asm", provenance=prov3)

    result = registry.resolve_extrn(extrn)

    assert result.resolved is True
    assert len(result.targets) == 1
    assert result.targets[0].file == "src/utils/helper.asm"
    assert result.confidence == Confidence.HIGH
    assert "priority" in result.reason.lower()


def test_priority_rules_filename_prefix_preference():
    """Test priority rules prefer symbol from file with same 3-char prefix."""
    registry = GlobalSymbolRegistry()

    # Add ENTRY symbols with different filename prefixes (3 chars)
    prov1 = StatementProvenance("stmt_1", "dbmhelper.asm", 10)
    entry1 = Symbol("FUNC", SymbolType.ENTRY, file="dbmhelper.asm", provenance=prov1)
    registry.add_entry(entry1)

    prov2 = StatementProvenance("stmt_2", "nethelper.asm", 20)
    entry2 = Symbol("FUNC", SymbolType.ENTRY, file="nethelper.asm", provenance=prov2)
    registry.add_entry(entry2)

    # EXTRN from dbmain.asm - should prefer "dbm" prefix (matches "dbmhelper")
    prov3 = StatementProvenance("stmt_3", "dbmain.asm", 5)
    extrn = Symbol("FUNC", SymbolType.EXTRN, file="dbmain.asm", provenance=prov3)

    result = registry.resolve_extrn(extrn)

    assert result.resolved is True
    assert len(result.targets) == 1
    assert result.targets[0].file == "dbmhelper.asm"
    assert result.confidence == Confidence.HIGH
    assert "priority" in result.reason.lower()


def test_priority_rules_no_clear_winner():
    """Test priority rules with no clear winner returns all matches."""
    registry = GlobalSymbolRegistry()

    # Add ENTRY symbols with similar characteristics
    prov1 = StatementProvenance("stmt_1", "module1.asm", 10)
    entry1 = Symbol("FUNC", SymbolType.ENTRY, file="module1.asm", provenance=prov1)
    registry.add_entry(entry1)

    prov2 = StatementProvenance("stmt_2", "module2.asm", 20)
    entry2 = Symbol("FUNC", SymbolType.ENTRY, file="module2.asm", provenance=prov2)
    registry.add_entry(entry2)

    # EXTRN from unrelated file - no clear winner
    prov3 = StatementProvenance("stmt_3", "other.asm", 5)
    extrn = Symbol("FUNC", SymbolType.EXTRN, file="other.asm", provenance=prov3)

    result = registry.resolve_extrn(extrn)

    assert result.resolved is True
    assert len(result.targets) == 2  # Returns all matches
    assert result.confidence == Confidence.MEDIUM
    assert "2" in result.reason  # Mentions multiple definitions


def test_priority_rules_with_single_candidate():
    """Test priority rules with single candidate returns it immediately."""
    registry = GlobalSymbolRegistry()

    # Only one ENTRY
    prov1 = StatementProvenance("stmt_1", "module1.asm", 10)
    entry = Symbol("FUNC", SymbolType.ENTRY, file="module1.asm", provenance=prov1)
    registry.add_entry(entry)

    # EXTRN
    prov2 = StatementProvenance("stmt_2", "other.asm", 5)
    extrn = Symbol("FUNC", SymbolType.EXTRN, file="other.asm", provenance=prov2)

    result = registry.resolve_extrn(extrn)

    assert result.resolved is True
    assert len(result.targets) == 1
    assert result.confidence == Confidence.HIGH
    assert "single" in result.reason.lower()
