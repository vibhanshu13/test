import pytest
from pathlib import Path
from file_reader import FileReader
from statement_id_generator import StatementIDGenerator


def test_file_reader_simple_file():
    """Test reading file without COPY directives"""
    fixture_path = Path(__file__).parent.parent / "fixtures" / "simple.asm"

    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen)

    lines = list(reader.read_file(str(fixture_path)))

    assert len(lines) == 11  # simple.asm has 11 lines
    assert all(line.provenance.original_file == str(fixture_path) for line in lines)


def test_file_reader_with_copy():
    """Test reading file with COPY directive"""
    fixture_path = Path(__file__).parent.parent / "fixtures" / "main_with_copy.asm"
    fixtures_dir = fixture_path.parent

    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen, search_paths=[str(fixtures_dir)])

    lines = list(reader.read_file(str(fixture_path)))

    # Should have main file lines + included file lines (minus COPY directive)
    # main_with_copy.asm: 6 lines
    # COPY directive gets replaced by included_utils.asm content: 4 lines
    # Total: 6 - 1 (COPY line) + 4 (included) = 9 lines
    assert len(lines) >= 8

    # Check that some lines have expanded_from_copy set
    copy_lines = [line for line in lines if line.provenance.expanded_from_copy]
    assert len(copy_lines) > 0


def test_file_reader_copy_not_found():
    """Test reading file with COPY to non-existent file"""
    fixture_path = Path(__file__).parent.parent / "fixtures" / "main_with_copy.asm"

    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen, search_paths=["/nonexistent"])

    # Should raise or log warning and continue
    with pytest.raises(FileNotFoundError):
        list(reader.read_file(str(fixture_path)))


def test_file_reader_circular_copy():
    """Test detecting circular COPY includes"""
    # This would need fixtures with circular includes
    # For now, just verify the mechanism exists
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen)

    # Verify include_stack exists
    assert hasattr(reader, 'include_stack')
