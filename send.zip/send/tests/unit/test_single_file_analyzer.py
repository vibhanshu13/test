"""Tests for single file analyzer."""
from pathlib import Path
from multi_file.single_file_analyzer import SingleFileAnalyzer, FileAnalysisResult


def test_analyzer_analyzes_simple_file():
    """Test analyzer can analyze a simple assembly file."""
    analyzer = SingleFileAnalyzer(search_paths=[Path("tests/fixtures")])

    file_path = Path("tests/fixtures/simple.asm")
    file_content = """
         ENTRY MAIN
         EXTRN HELPER
MAIN     CSECT
         BAL   R14,HELPER
         END
"""

    result = analyzer.analyze(file_path, file_content)

    assert result.file_path == file_path
    assert "MAIN" in result.exports
    assert "HELPER" in result.imports
    assert result.symbol_table is not None
    assert result.call_graph is not None


def test_analyzer_extracts_exports():
    """Test analyzer correctly identifies exported symbols."""
    analyzer = SingleFileAnalyzer(search_paths=[Path("tests/fixtures")])

    file_content = """
         ENTRY FUNC1
         ENTRY FUNC2
CSECT1   CSECT
         END
"""

    result = analyzer.analyze(Path("test.asm"), file_content)

    assert "FUNC1" in result.exports
    assert "FUNC2" in result.exports
    assert len(result.exports) == 2


def test_analyzer_extracts_imports():
    """Test analyzer correctly identifies imported symbols."""
    analyzer = SingleFileAnalyzer(search_paths=[Path("tests/fixtures")])

    file_content = """
         EXTRN DBUTIL
         EXTRN HELPER
         WXTRN OPTIONAL
MAIN     CSECT
         END
"""

    result = analyzer.analyze(Path("test.asm"), file_content)

    assert "DBUTIL" in result.imports
    assert "HELPER" in result.imports
    assert "OPTIONAL" in result.imports
    assert len(result.imports) == 3
