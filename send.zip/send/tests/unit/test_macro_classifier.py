import pytest
from macro_classifier import MacroClassifier
from models.db_operation import DBOperationType


def test_classify_dbred():
    """Test classifying DBRED macro"""
    classifier = MacroClassifier()

    result = classifier.classify("DBRED")

    assert result is not None
    assert result["operation_type"] == DBOperationType.READ
    assert result["macro_name"] == "DBRED"


def test_classify_dbwrt():
    """Test classifying DBWRT macro"""
    classifier = MacroClassifier()

    result = classifier.classify("DBWRT")

    assert result is not None
    assert result["operation_type"] == DBOperationType.WRITE


def test_classify_dbupd():
    """Test classifying DBUPD macro"""
    classifier = MacroClassifier()

    result = classifier.classify("DBUPD")

    assert result is not None
    assert result["operation_type"] == DBOperationType.UPDATE


def test_classify_dbdel():
    """Test classifying DBDEL macro"""
    classifier = MacroClassifier()

    result = classifier.classify("DBDEL")

    assert result is not None
    assert result["operation_type"] == DBOperationType.DELETE


def test_classify_filec():
    """Test classifying FILEC macro"""
    classifier = MacroClassifier()

    result = classifier.classify("FILEC")

    assert result is not None
    assert result["operation_type"] == DBOperationType.CONTROL


def test_is_db_macro():
    """Test identifying DB macros"""
    classifier = MacroClassifier()

    assert classifier.is_db_macro("DBRED") is True
    assert classifier.is_db_macro("DBWRT") is True
    assert classifier.is_db_macro("FILEC") is True
    assert classifier.is_db_macro("BAL") is False
    assert classifier.is_db_macro("L") is False


def test_classify_non_db_macro():
    """Test classifying non-DB macro returns None"""
    classifier = MacroClassifier()

    result = classifier.classify("BAL")

    assert result is None


def test_is_ztpf_macro():
    """Test identifying z/TPF system macros"""
    classifier = MacroClassifier()

    # Test common z/TPF macros
    assert classifier.is_ztpf_macro("ENTER") is True
    assert classifier.is_ztpf_macro("EXIT") is True
    assert classifier.is_ztpf_macro("MALOC") is True
    assert classifier.is_ztpf_macro("RELOC") is True
    assert classifier.is_ztpf_macro("PNTRP") is True
    assert classifier.is_ztpf_macro("ISCFA") is True
    assert classifier.is_ztpf_macro("CRUSA") is True
    assert classifier.is_ztpf_macro("CALLCPP") is True
    assert classifier.is_ztpf_macro("SAVE") is True
    assert classifier.is_ztpf_macro("RETURN") is True

    # Test non-macros
    assert classifier.is_ztpf_macro("BAL") is False
    assert classifier.is_ztpf_macro("L") is False
    assert classifier.is_ztpf_macro("DBRED") is False  # DB macro, not system


def test_is_macro_combined():
    """Test is_macro for both database and system macros"""
    classifier = MacroClassifier()

    # Database macros
    assert classifier.is_macro("DBRED") is True
    assert classifier.is_macro("DBWRT") is True
    assert classifier.is_macro("FILEC") is True

    # System macros
    assert classifier.is_macro("ENTER") is True
    assert classifier.is_macro("MALOC") is True
    assert classifier.is_macro("PNTRP") is True
    assert classifier.is_macro("ISCFA") is True
    assert classifier.is_macro("CRUSA") is True
    assert classifier.is_macro("CALLCPP") is True

    # Non-macros
    assert classifier.is_macro("BAL") is False
    assert classifier.is_macro("L") is False


def test_get_macro_type():
    """Test getting macro type"""
    classifier = MacroClassifier()

    # Database macros
    assert classifier.get_macro_type("DBRED") == "database"
    assert classifier.get_macro_type("DBWRT") == "database"
    assert classifier.get_macro_type("FILEC") == "database"

    # System macros
    assert classifier.get_macro_type("ENTER") == "system"
    assert classifier.get_macro_type("MALOC") == "system"
    assert classifier.get_macro_type("PNTRP") == "system"
    assert classifier.get_macro_type("ISCFA") == "system"
    assert classifier.get_macro_type("CRUSA") == "system"
    assert classifier.get_macro_type("CALLCPP") == "system"

    # Non-macros
    assert classifier.get_macro_type("BAL") is None
    assert classifier.get_macro_type("L") is None


def test_macro_case_insensitive():
    """Test that macro detection is case-insensitive"""
    classifier = MacroClassifier()

    # Lowercase
    assert classifier.is_macro("enter") is True
    assert classifier.is_macro("dbred") is True

    # Mixed case
    assert classifier.is_macro("MaLoC") is True
    assert classifier.is_macro("DbWrT") is True
