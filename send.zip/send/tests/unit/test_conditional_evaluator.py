"""Unit tests for conditional expression evaluator."""

import pytest
from conditional_evaluator import ConditionalEvaluator
from models.conditional_assembly import SetSymbolTable, ConditionalAssemblyState


def test_evaluate_simple_equality():
    """Test evaluating simple equality condition."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()
    symbols.set_value("&VAR", 5)

    result = evaluator.evaluate("&VAR EQ 5", symbols)

    assert result is True


def test_evaluate_inequality():
    """Test evaluating inequality (greater than) condition."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()
    symbols.set_value("&COUNT", 10)

    result = evaluator.evaluate("&COUNT GT 5", symbols)

    assert result is True


def test_evaluate_with_unknown_symbol():
    """Test evaluating condition with unknown symbol returns None."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()

    result = evaluator.evaluate("&UNKNOWN EQ 1", symbols)

    assert result is None


def test_can_evaluate():
    """Test checking if condition can be evaluated based on symbol availability."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()
    symbols.set_value("&VAR", 5)

    # Should be able to evaluate when symbol is defined
    assert evaluator.can_evaluate("&VAR EQ 5", symbols) is True

    # Should not be able to evaluate when symbol is undefined
    assert evaluator.can_evaluate("&UNKNOWN EQ 1", symbols) is False


# Additional comprehensive tests

def test_evaluate_not_equal():
    """Test evaluating NE (not equal) operator."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()
    symbols.set_value("&VAR", 5)

    assert evaluator.evaluate("&VAR NE 10", symbols) is True
    assert evaluator.evaluate("&VAR NE 5", symbols) is False


def test_evaluate_less_than():
    """Test evaluating LT (less than) operator."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()
    symbols.set_value("&VAR", 3)

    assert evaluator.evaluate("&VAR LT 5", symbols) is True
    assert evaluator.evaluate("&VAR LT 2", symbols) is False


def test_evaluate_less_than_or_equal():
    """Test evaluating LE (less than or equal) operator."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()
    symbols.set_value("&VAR", 5)

    assert evaluator.evaluate("&VAR LE 5", symbols) is True
    assert evaluator.evaluate("&VAR LE 6", symbols) is True
    assert evaluator.evaluate("&VAR LE 4", symbols) is False


def test_evaluate_greater_than_or_equal():
    """Test evaluating GE (greater than or equal) operator."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()
    symbols.set_value("&VAR", 5)

    assert evaluator.evaluate("&VAR GE 5", symbols) is True
    assert evaluator.evaluate("&VAR GE 4", symbols) is True
    assert evaluator.evaluate("&VAR GE 6", symbols) is False


def test_evaluate_symbol_to_symbol_comparison():
    """Test comparing two SET symbols."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()
    symbols.set_value("&COUNT", 10)
    symbols.set_value("&LIMIT", 5)

    assert evaluator.evaluate("&COUNT GT &LIMIT", symbols) is True
    assert evaluator.evaluate("&COUNT LT &LIMIT", symbols) is False


def test_evaluate_string_comparison():
    """Test comparing string values."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()
    symbols.set_value("&NAME", "TEST")

    assert evaluator.evaluate("&NAME EQ 'TEST'", symbols) is True
    assert evaluator.evaluate("&NAME NE 'OTHER'", symbols) is True


def test_evaluate_case_insensitive_operators():
    """Test that operators are case-insensitive."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()
    symbols.set_value("&VAR", 5)

    assert evaluator.evaluate("&VAR eq 5", symbols) is True
    assert evaluator.evaluate("&VAR Eq 5", symbols) is True
    assert evaluator.evaluate("&VAR GT 3", symbols) is True
    assert evaluator.evaluate("&VAR gt 3", symbols) is True


def test_evaluate_invalid_syntax():
    """Test that invalid condition syntax returns None."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()
    symbols.set_value("&VAR", 5)

    # Invalid syntax should return None
    assert evaluator.evaluate("INVALID", symbols) is None
    assert evaluator.evaluate("", symbols) is None


def test_can_evaluate_multiple_symbols():
    """Test can_evaluate with multiple symbols in condition."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()
    symbols.set_value("&VAR1", 5)
    symbols.set_value("&VAR2", 10)

    # Both symbols defined
    assert evaluator.can_evaluate("&VAR1 GT &VAR2", symbols) is True

    # One symbol undefined
    assert evaluator.can_evaluate("&VAR1 GT &UNKNOWN", symbols) is False


def test_evaluate_with_unknown_value():
    """Test that symbols with UNKNOWN value cannot be evaluated."""
    evaluator = ConditionalEvaluator()
    symbols = SetSymbolTable()

    # Manually create a symbol that will return UNKNOWN
    # (this simulates a symbol that was referenced but never defined)
    result = evaluator.evaluate("&UNDEFINED EQ 1", symbols)

    assert result is None


def test_evaluate_macro_param_with_conditional_state():
    """Test evaluating condition with macro parameter."""
    evaluator = ConditionalEvaluator()
    state = ConditionalAssemblyState()

    # Set macro parameter
    state.set_macro_param("&PARM1", "5")

    # Should be able to evaluate
    assert evaluator.can_evaluate("&PARM1 EQ 5", state) is True
    assert evaluator.evaluate("&PARM1 EQ 5", state) is True


def test_evaluate_macro_param_string_comparison():
    """Test evaluating macro parameter string comparison."""
    evaluator = ConditionalEvaluator()
    state = ConditionalAssemblyState()

    # Set macro parameter to string value
    state.set_macro_param("&PARM1", "TEST")

    # Should be able to compare with string literal
    assert evaluator.evaluate("&PARM1 EQ 'TEST'", state) is True
    assert evaluator.evaluate("&PARM1 NE 'OTHER'", state) is True


def test_evaluate_macro_param_undefined():
    """Test that undefined macro parameter returns None."""
    evaluator = ConditionalEvaluator()
    state = ConditionalAssemblyState()

    # Macro parameter not defined
    assert evaluator.can_evaluate("&UNDEFINED_PARM EQ 1", state) is False
    assert evaluator.evaluate("&UNDEFINED_PARM EQ 1", state) is None


def test_evaluate_mixed_set_symbol_and_macro_param():
    """Test evaluating condition with both SET symbol and macro parameter."""
    evaluator = ConditionalEvaluator()
    state = ConditionalAssemblyState()

    # Set both SET symbol and macro parameter
    state.set_symbols.set_value("&VAR", 10)
    state.set_macro_param("&PARM1", "5")

    # Should be able to evaluate both
    assert evaluator.evaluate("&VAR GT &PARM1", state) is True


def test_macro_param_takes_precedence_over_set_symbol():
    """Test that macro parameter takes precedence over SET symbol of same name."""
    evaluator = ConditionalEvaluator()
    state = ConditionalAssemblyState()

    # Define both with same name
    state.set_symbols.set_value("&NAME", 10)
    state.set_macro_param("&NAME", "20")

    # Macro parameter should take precedence
    assert evaluator.evaluate("&NAME EQ 20", state) is True
    assert evaluator.evaluate("&NAME EQ 10", state) is False


def test_can_evaluate_with_macro_param():
    """Test can_evaluate with macro parameters in ConditionalAssemblyState."""
    evaluator = ConditionalEvaluator()
    state = ConditionalAssemblyState()

    # Set macro parameter
    state.set_macro_param("&PARM1", "VALUE")

    # Should be able to evaluate
    assert evaluator.can_evaluate("&PARM1 NE ''", state) is True

    # Undefined parameter should not be evaluable
    assert evaluator.can_evaluate("&UNDEFINED NE ''", state) is False
