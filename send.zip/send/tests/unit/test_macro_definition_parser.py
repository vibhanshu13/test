import pytest
from pathlib import Path
from macro_definition_parser import MacroDefinitionParser


def test_parser_creation():
    """Test creating macro definition parser"""
    parser = MacroDefinitionParser()
    assert parser is not None


def test_parse_simple_macro():
    """Test parsing a simple macro without parameters"""
    content = """
         MACRO
&LABEL   NOOP
&LABEL   NOP
         MEND
"""
    parser = MacroDefinitionParser()
    macros = parser.parse_macro_definitions(content, Path("test.asm"))

    assert len(macros) == 1
    assert macros[0].name == "NOOP"
    assert len(macros[0].parameters) == 1  # Just &LABEL
    assert macros[0].parameters[0].is_label


def test_parse_macro_with_parameters():
    """Test parsing macro with named parameters"""
    content = """
         MACRO
&LABEL   CHKRC &RC=0,&ERROR=ERROR
&LABEL   LTR   R15,R15
         BNZ   &ERROR
         MEND
"""
    parser = MacroDefinitionParser()
    macros = parser.parse_macro_definitions(content, Path("MACROS.asm"))

    assert len(macros) == 1
    macro = macros[0]

    assert macro.name == "CHKRC"
    assert len(macro.parameters) == 3  # &LABEL, &RC, &ERROR

    # Check parameters
    param_names = [p.name for p in macro.parameters]
    assert "&LABEL" in param_names
    assert "&RC" in param_names
    assert "&ERROR" in param_names

    # Check defaults
    rc_param = [p for p in macro.parameters if p.name == "&RC"][0]
    assert rc_param.default_value == "0"

    error_param = [p for p in macro.parameters if p.name == "&ERROR"][0]
    assert error_param.default_value == "ERROR"


def test_parse_macro_body():
    """Test that macro body is captured correctly"""
    content = """
         MACRO
         SETRC &RC
         LA    R15,&RC
         BR    R14
         MEND
"""
    parser = MacroDefinitionParser()
    macros = parser.parse_macro_definitions(content, Path("test.asm"))

    assert len(macros) == 1
    macro = macros[0]

    assert macro.name == "SETRC"
    assert len(macro.body) == 2
    assert any("LA    R15,&RC" in line for line in macro.body)
    assert any("BR    R14" in line for line in macro.body)


def test_parse_multiple_macros():
    """Test parsing multiple macros from same file"""
    content = """
         MACRO
         MACRO1
         NOP
         MEND
*
         MACRO
         MACRO2
         LA    R1,0
         MEND
"""
    parser = MacroDefinitionParser()
    macros = parser.parse_macro_definitions(content, Path("test.asm"))

    assert len(macros) == 2
    assert macros[0].name == "MACRO1"
    assert macros[1].name == "MACRO2"


def test_parse_macro_with_conditionals():
    """Test parsing macro with AIF/AGO/ANOP directives"""
    content = """
         MACRO
&LABEL   CHKRC &RC=0,&ERROR=ERROR
&LABEL   LTR   R15,R15
         AIF   ('&RC' EQ '0').ZERO
         C     R15,=F'&RC'
         BNE   &ERROR
         AGO   .DONE
.ZERO    ANOP
         BNZ   &ERROR
.DONE    ANOP
         MEND
"""
    parser = MacroDefinitionParser()
    macros = parser.parse_macro_definitions(content, Path("MACROS.asm"))

    assert len(macros) == 1
    macro = macros[0]

    # Body should include conditional directives
    body_str = " ".join(macro.body)
    assert "AIF" in body_str
    assert "AGO" in body_str
    assert "ANOP" in body_str


def test_parse_macro_line_numbers():
    """Test that line numbers are tracked correctly"""
    content = """Line 1
Line 2
         MACRO
&LABEL   TEST
         NOP
         MEND
Line 7
"""
    parser = MacroDefinitionParser()
    macros = parser.parse_macro_definitions(content, Path("test.asm"))

    assert len(macros) == 1
    macro = macros[0]

    assert macro.start_line == 3
    assert macro.end_line == 6


def test_parse_no_macros():
    """Test parsing content with no macros"""
    content = """
         CSECT
MYCODE   DS    0H
         L     R1,=F'4'
         BR    R14
         END
"""
    parser = MacroDefinitionParser()
    macros = parser.parse_macro_definitions(content, Path("test.asm"))

    assert len(macros) == 0


def test_parse_macro_from_file(tmp_path):
    """Test parsing macros from an actual file"""
    # Create temporary macro file
    macro_file = tmp_path / "MACROS.asm"
    macro_file.write_text("""
         MACRO
         NOOP
         NOP
         MEND
""")

    parser = MacroDefinitionParser()
    macros = parser.parse_file(macro_file)

    assert len(macros) == 1
    assert macros[0].name == "NOOP"
    assert macros[0].source_file == macro_file
