import pytest
from literal_resolver import LiteralResolver


def test_resolve_v_literal():
    """Test resolving =V(symbol) literals"""
    resolver = LiteralResolver()

    result = resolver.resolve("=V(DBREAD)")

    assert result is not None
    assert result["type"] == "V"
    assert result["symbol"] == "DBREAD"


def test_resolve_a_literal():
    """Test resolving =A(symbol) literals"""
    resolver = LiteralResolver()

    result = resolver.resolve("=A(BUFFER)")

    assert result is not None
    assert result["type"] == "A"
    assert result["symbol"] == "BUFFER"


def test_resolve_numeric_literal():
    """Test resolving numeric literals"""
    resolver = LiteralResolver()

    result = resolver.resolve("=F'100'")

    assert result is not None
    assert result["type"] == "F"
    assert result["value"] == "100"


def test_is_literal():
    """Test identifying literals"""
    resolver = LiteralResolver()

    assert resolver.is_literal("=V(DBREAD)") is True
    assert resolver.is_literal("=A(BUFFER)") is True
    assert resolver.is_literal("=F'100'") is True
    assert resolver.is_literal("LABEL") is False
    assert resolver.is_literal("R15") is False


def test_non_literal():
    """Test non-literal operands return None"""
    resolver = LiteralResolver()

    assert resolver.resolve("LABEL") is None
    assert resolver.resolve("R15") is None
