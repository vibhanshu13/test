from pathlib import Path

import pytest

from passes.c_family_parser import CFamilyParser
from universe_builder import UniverseBuilder


def _write(tmp_path: Path, name: str, content: str) -> Path:
    path = tmp_path / name
    path.write_text(content)
    return path


def test_collects_macro_definitions_with_parameters_and_introduced_variables(tmp_path):
    asm_file = _write(
        tmp_path,
        "cr21ae.mac",
        """         MACRO
&LABEL   CR21AE &REG=,&SUFFIX=,&ORG=,&ACPDB=
CR21HDR&CG1 DS CL8
CR21VAR&CG1 DC F'0'
         MEND
""",
    )

    builder = UniverseBuilder()
    builder.build([asm_file])

    macro = builder.asm_universe.macro_definitions.get("CR21AE")
    assert macro is not None
    assert macro["parameters"] == ["&LABEL", "&REG", "&SUFFIX", "&ORG", "&ACPDB"]
    assert macro["defined_in"] == str(asm_file.resolve())
    assert macro["variables_introduced"] == ["CR21HDR&CG1", "CR21VAR&CG1"]


def test_equ_infers_data_type_and_populates_aliases_and_related_symbols(tmp_path):
    asm_file = _write(
        tmp_path,
        "aliases.asm",
        """ALIAS1   EQU   BASEVAL
ALIAS2   EQU   BASEVAL
BASEVAL  EQU   4
REGALIAS EQU   12
HEXVAL   EQU   X'FF'
EXPRVAL  EQU   *-BASEVAL
""",
    )

    builder = UniverseBuilder()
    builder.build([asm_file])

    alias1 = builder.asm_universe.get_variable_entries("ALIAS1")[0]
    alias2 = builder.asm_universe.get_variable_entries("ALIAS2")[0]
    regal = builder.asm_universe.get_variable_entries("REGALIAS")[0]
    hexval = builder.asm_universe.get_variable_entries("HEXVAL")[0]
    exprval = builder.asm_universe.get_variable_entries("EXPRVAL")[0]

    assert alias1.related_symbols == ["BASEVAL"]
    assert "ALIAS2" in alias1.aliased_as
    assert "ALIAS1" in alias2.aliased_as

    assert "R12" in regal.aliased_as
    assert regal.data_type == "integer"
    assert hexval.data_type == "hex"
    assert exprval.data_type == "expression"


def test_collects_extern_variants_and_usage_locations_across_files(tmp_path):
    defs_file = _write(
        tmp_path,
        "defs.asm",
        """MYVAR    DS    F
         EXTRN EXT_A,EXT_B(4)
         L     R1,MYVAR
         BAL   R14,EXT_A
""",
    )
    refs_file = _write(
        tmp_path,
        "refs.asm",
        """         WXTRN EXT_A,EXT_C
         ST    R1,MYVAR
""",
    )

    builder = UniverseBuilder()
    builder.build([defs_file, refs_file])

    externs = builder.asm_universe.extern_symbols
    assert "EXT_A" in externs
    assert "EXT_B" in externs
    assert "EXT_C" in externs

    myvar = builder.asm_universe.get_variable_entries("MYVAR")[0]
    locations = {(loc.file, loc.line, loc.context) for loc in myvar.all_locations}
    assert (str(defs_file.resolve()), 1, "definition") in locations
    assert (str(defs_file.resolve()), 3, "reference") in locations
    assert (str(refs_file.resolve()), 2, "reference") in locations


def test_missing_copy_falls_back_to_direct_file_read(tmp_path):
    asm_file = _write(
        tmp_path,
        "missingcopy.asm",
        """         COPY  UNKNOWNCPY
VAL1     DS    F
""",
    )

    builder = UniverseBuilder()
    builder.build([asm_file])

    entries = builder.asm_universe.get_variable_entries("VAL1")
    assert len(entries) == 1
    assert entries[0].line == 2


def test_asm_symbol_classification_marks_set_and_macro_parameterized_names(tmp_path):
    asm_file = _write(
        tmp_path,
        "classification.asm",
        """REALVAR      DS    F
TMP&SUFFIX   DS    F
#LOCALSYM    EQU   1
""",
    )

    builder = UniverseBuilder()
    builder.build([asm_file])

    realvar = builder.asm_universe.get_variable_entries("REALVAR")[0]
    macroized = builder.asm_universe.get_variable_entries("TMP&SUFFIX")[0]
    local_set = builder.asm_universe.get_variable_entries("#LOCALSYM")[0]

    assert realvar.metadata["is_runtime_symbol"] is True
    assert realvar.metadata["symbol_category"] == "runtime_symbol"

    assert macroized.metadata["has_macro_parameter_token"] is True
    assert macroized.metadata["is_runtime_symbol"] is False
    assert macroized.metadata["symbol_category"] == "macro_parameterized_symbol"

    assert local_set.kind == "set_variable"
    assert local_set.metadata["is_set_variable"] is True
    assert local_set.metadata["symbol_category"] == "set_variable_or_local_symbol"


def test_asm_variable_names_export_only_includes_runtime_symbols(tmp_path):
    asm_file = _write(
        tmp_path,
        "runtime_filter.asm",
        """PRODVAL      DS    F
TMP&SUFFIX   DS    F
#LOCALSYM    EQU   1
FLAGVAL      EQU   2
""",
    )

    builder = UniverseBuilder()
    builder.build([asm_file])

    output_dir = tmp_path / "out"
    builder.write_output(output_dir)

    asm_names = (output_dir / "asm_variable_names.json").read_text()

    assert "PRODVAL" in asm_names
    assert "FLAGVAL" in asm_names
    assert "TMP&SUFFIX" not in asm_names
    assert "#LOCALSYM" not in asm_names


def test_cpp_universe_populates_types_externs_macros_locations_and_aliases(tmp_path):
    if not CFamilyParser("cpp").available:
        pytest.skip("tree-sitter parser unavailable")

    header = _write(
        tmp_path,
        "sample.hpp",
        """#define STATUS_CODE_ALIAS kMAX_STATUS_CODES
#define MAX_COUNT 50
extern int g_external_counter;
extern "C" int asm_bridge(int value);
typedef int status_t;
using status_alias_t = status_t;
const int kMAX_STATUS_CODES = 50;
static status_alias_t g_static = 7;
""",
    )
    source = _write(
        tmp_path,
        "sample.cpp",
        """#include "sample.hpp"

int g_external_counter = 0;

int run() {
    int local = kMAX_STATUS_CODES;
    int* alias_ptr = &g_external_counter;
    status_alias_t copy = *alias_ptr;
    int value = STATUS_CODE_ALIAS;
    return asm_bridge(copy + value);
}
""",
    )

    builder = UniverseBuilder()
    builder.build([header, source])

    max_entries = builder.cpp_universe.get_variable_entries("kMAX_STATUS_CODES")
    assert max_entries
    max_entry = next((entry for entry in max_entries if entry.initial_value == "50"), max_entries[0])
    assert max_entry.data_type is not None
    assert "int" in max_entry.data_type
    assert max_entry.declaration_type is not None
    assert max_entry.initial_value == "50"
    assert any(loc.context == "reference" for loc in max_entry.all_locations)
    assert "STATUS_CODE_ALIAS" in max_entry.related_symbols

    alias_ptr_entries = builder.cpp_universe.get_variable_entries("alias_ptr")
    assert alias_ptr_entries
    assert any("g_external_counter" in entry.aliased_as for entry in alias_ptr_entries)

    g_static_entries = builder.cpp_universe.get_variable_entries("g_static")
    assert g_static_entries
    assert any("status_t" in entry.related_symbols for entry in g_static_entries)

    externs = builder.cpp_universe.extern_symbols
    assert "g_external_counter" in externs
    assert "asm_bridge" in externs

    macros = builder.cpp_universe.macro_definitions
    assert "STATUS_CODE_ALIAS" in macros
    assert "MAX_COUNT" in macros


def test_cpp_universe_normalizes_scope_storage_and_deduplicates_entries(tmp_path):
    if not CFamilyParser("cpp").available:
        pytest.skip("tree-sitter parser unavailable")

    cpp_file = _write(
        tmp_path,
        "scope_quality.cpp",
        """
static const int kMAX_STATUS_CODES = 50;
static int globalLimitsErrorCount = 0;

int compute_value(int input) {
    int local = kMAX_STATUS_CODES;
    int converted = static_cast<int>(input);
    return local + converted;
}
""",
    )

    builder = UniverseBuilder()
    builder.build([cpp_file])

    kmax_entries = builder.cpp_universe.get_variable_entries("kMAX_STATUS_CODES")
    assert kmax_entries
    assert any(entry.scope == "file" for entry in kmax_entries)
    assert any(entry.storage_class == "static" for entry in kmax_entries)

    all_entries = [
        entry
        for entries in builder.cpp_universe.variables.values()
        for entry in entries
        if entry.file == str(cpp_file.resolve())
    ]

    # No path-shaped or tokenization-noise scope fallbacks.
    assert all(not entry.scope.startswith("/") for entry in all_entries)
    assert all(not entry.scope.startswith("//") for entry in all_entries)

    # No synthetic cast tokens promoted as variables.
    assert "static_cast" not in builder.cpp_universe.variables
    assert "reinterpret_cast" not in builder.cpp_universe.variables

    # No duplicate registration for the exact same logical declaration site.
    keys = {(entry.name, entry.file, entry.line, entry.scope, entry.kind) for entry in all_entries}
    assert len(keys) == len(all_entries)

    # No placeholder line=1 fallback for this fixture (first line is blank).
    assert all(entry.line != 1 for entry in all_entries)


def test_cpp_universe_filters_synthetic_bridge_nodes_from_lineage_fallback(tmp_path):
    cpp_file = _write(
        tmp_path,
        "synthetic.cpp",
        "int run() { return 0; }\n",
    )

    builder = UniverseBuilder()
    synthetic_lineage = {
        "nodes": [
            {"id": "variable:arg@run:R0", "name": "arg@run:R0", "kind": "variable"},
            {"id": "variable:return@run", "name": "return@run", "kind": "variable"},
            {"id": "variable:sizeof(char)", "name": "sizeof(char)", "kind": "variable"},
            {"id": "variable:static_cast", "name": "static_cast", "kind": "variable"},
            {"id": "variable:realVar", "name": "realVar", "kind": "variable"},
        ],
        "edges": [
            {"source": "variable:realVar", "target": "variable:realVar", "relation": "define", "file": str(cpp_file), "line": 5},
            {"source": "variable:arg@run:R0", "target": "variable:realVar", "relation": "assign", "file": str(cpp_file), "line": 6},
        ],
    }

    builder._extract_cpp_from_lineage(synthetic_lineage, cpp_file, translation_unit=None)

    assert "realVar" in builder.cpp_universe.variables
    assert "arg@run:R0" not in builder.cpp_universe.variables
    assert "return@run" not in builder.cpp_universe.variables
    assert "sizeof(char)" not in builder.cpp_universe.variables
    assert "static_cast" not in builder.cpp_universe.variables
