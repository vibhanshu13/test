"""Tests for JSON emitter."""
import json
from pathlib import Path
from json_emitter import JSONEmitter
from models.analysis_context import AnalysisContext
from models.symbol import Symbol, SymbolType
from models.call_graph import CallType, CallEdge, CallGraph
from models.db_operation import DBOperationType, DBOperation, DBOperationCatalog
from models.provenance import StatementProvenance
from models.c_family import CTranslationUnit


def test_json_emitter_basic_structure():
    """Test JSONEmitter produces correct top-level structure."""
    context = AnalysisContext()
    emitter = JSONEmitter()

    result = emitter.emit(context)

    assert "metadata" in result
    assert "symbol_aliases" in result
    assert "symbols" in result
    assert "call_graph" in result
    assert "db_operations" in result
    assert "file_dependencies" in result
    assert "macro_expansions" in result
    assert "macro_errors" in result
    assert "variable_lineage" in result
    assert "build_metadata" in result


def test_json_emitter_with_build_metadata():
    """Test JSONEmitter serializes build metadata correctly."""
    context = AnalysisContext()
    context.add_metadata("build_metadata", {"defines": ["DEBUG"], "include_dirs": ["include"]})

    emitter = JSONEmitter()
    result = emitter.emit(context)

    assert result["build_metadata"]["defines"] == ["DEBUG"]


def test_json_emitter_with_symbols():
    """Test JSONEmitter serializes symbols correctly."""
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="TEST_1",
        original_file="test.asm",
        original_line=1
    )
    symbol = Symbol("TEST", SymbolType.ENTRY, "test.asm", provenance)
    context.symbol_table.add_symbol(symbol)

    emitter = JSONEmitter()
    result = emitter.emit(context)

    assert "TEST" in result["symbols"]["global_symbols"]
    assert result["symbols"]["global_symbols"]["TEST"]["type"] == "entry"


def test_json_emitter_with_call_graph():
    """Test JSONEmitter serializes call graph correctly."""
    context = AnalysisContext()

    from models.call_graph import CallGraph
    call_graph = CallGraph()
    call_graph.add_edge("MAIN", "HELPER", CallType.SUBROUTINE_CALL, "BAL", "test.asm", 10)
    context.add_metadata("call_graph", call_graph)

    emitter = JSONEmitter()
    result = emitter.emit(context)

    assert len(result["call_graph"]["edges"]) == 1
    assert result["call_graph"]["edges"][0]["source"] == "MAIN"


def test_json_emitter_with_db_operations():
    """Test JSONEmitter serializes DB operations correctly."""
    context = AnalysisContext()

    catalog = DBOperationCatalog()
    operation = DBOperation(
        DBOperationType.READ, "DBRED", "PROC", "FILE", [],
        None, "test.asm", 1, None, "high"
    )
    catalog.add_operation(operation)
    context.add_metadata("db_operation_catalog", catalog)

    emitter = JSONEmitter()
    result = emitter.emit(context)

    assert len(result["db_operations"]["operations"]) == 1
    assert result["db_operations"]["operations"][0]["macro_name"] == "DBRED"


def test_json_emitter_to_json_string():
    """Test JSONEmitter can produce valid JSON string."""
    context = AnalysisContext()
    emitter = JSONEmitter()

    json_str = emitter.emit_json(context)
    parsed = json.loads(json_str)

    assert "metadata" in parsed
    assert isinstance(json_str, str)


def test_json_emitter_includes_symbol_aliases_from_c_family_unit():
    context = AnalysisContext()
    unit = CTranslationUnit(file_path=Path("demo.cpp"), language="cpp")
    unit.symbol_aliases["asm_process_level"] = "LVLPROC"
    context.add_metadata("c_family_unit", unit)

    emitter = JSONEmitter()
    result = emitter.emit(context)
    assert result["symbol_aliases"]["asm_process_level"] == "LVLPROC"


def test_json_emitter_derives_symbol_aliases_from_symbol_table_when_unit_missing():
    context = AnalysisContext()
    provenance = StatementProvenance(
        statement_id="C_DECL_1",
        original_file="demo.cpp",
        original_line=1,
    )
    context.symbol_table.add_symbol(Symbol(
        name="asm_process_level",
        symbol_type=SymbolType.EXTRN,
        file="demo.cpp",
        provenance=provenance,
        asm_name="LVLPROC",
    ))

    emitter = JSONEmitter()
    result = emitter.emit(context)
    assert result["symbol_aliases"]["asm_process_level"] == "LVLPROC"
