import pytest
from symbol_parser import SymbolParser
from models.symbol import SymbolType
from models.provenance import StatementProvenance
from tokenizer import ParsedLine


def test_parse_entry_directive():
    """Test parsing ENTRY directive"""
    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    parsed_line = ParsedLine(
        label=None,
        opcode="ENTRY",
        operands=["MAIN", "HELPER"],
        comment=None,
        provenance=provenance
    )

    parser = SymbolParser()
    symbols = parser.parse_line(parsed_line, current_section=None)

    assert len(symbols) == 2
    assert symbols[0].name == "MAIN"
    assert symbols[0].symbol_type == SymbolType.ENTRY
    assert symbols[0].file == "test.asm"
    assert symbols[1].name == "HELPER"


def test_parse_entry_single():
    """Test parsing ENTRY with single symbol"""
    provenance = StatementProvenance(
        statement_id="S002",
        original_file="test.asm",
        original_line=11
    )

    parsed_line = ParsedLine(
        label=None,
        opcode="ENTRY",
        operands=["MAIN"],
        comment=None,
        provenance=provenance
    )

    parser = SymbolParser()
    symbols = parser.parse_line(parsed_line, current_section=None)

    assert len(symbols) == 1
    assert symbols[0].name == "MAIN"


def test_parse_extrn_directive():
    """Test parsing EXTRN directive"""
    provenance = StatementProvenance(
        statement_id="S003",
        original_file="test.asm",
        original_line=20
    )

    parsed_line = ParsedLine(
        label=None,
        opcode="EXTRN",
        operands=["DBREAD", "DBWRITE"],
        comment=None,
        provenance=provenance
    )

    parser = SymbolParser()
    symbols = parser.parse_line(parsed_line, current_section=None)

    assert len(symbols) == 2
    assert symbols[0].name == "DBREAD"
    assert symbols[0].symbol_type == SymbolType.EXTRN
    assert symbols[1].name == "DBWRITE"


def test_parse_wxtrn_directive():
    """Test parsing WXTRN directive"""
    provenance = StatementProvenance(
        statement_id="S004",
        original_file="test.asm",
        original_line=21
    )

    parsed_line = ParsedLine(
        label=None,
        opcode="WXTRN",
        operands=["EXTFUNC"],
        comment=None,
        provenance=provenance
    )

    parser = SymbolParser()
    symbols = parser.parse_line(parsed_line, current_section=None)

    assert len(symbols) == 1
    assert symbols[0].name == "EXTFUNC"
    assert symbols[0].symbol_type == SymbolType.WXTRN


def test_parse_csect_directive():
    """Test parsing CSECT directive"""
    provenance = StatementProvenance(
        statement_id="S005",
        original_file="test.asm",
        original_line=30
    )

    parsed_line = ParsedLine(
        label="MAIN",
        opcode="CSECT",
        operands=[],
        comment=None,
        provenance=provenance
    )

    parser = SymbolParser()
    symbols = parser.parse_line(parsed_line, current_section=None)

    assert len(symbols) == 1
    assert symbols[0].name == "MAIN"
    assert symbols[0].symbol_type == SymbolType.CSECT


def test_parse_dsect_directive():
    """Test parsing DSECT directive"""
    provenance = StatementProvenance(
        statement_id="S006",
        original_file="test.asm",
        original_line=40
    )

    parsed_line = ParsedLine(
        label="DATA",
        opcode="DSECT",
        operands=[],
        comment=None,
        provenance=provenance
    )

    parser = SymbolParser()
    symbols = parser.parse_line(parsed_line, current_section=None)

    assert len(symbols) == 1
    assert symbols[0].name == "DATA"
    assert symbols[0].symbol_type == SymbolType.DSECT


def test_parse_rsect_directive():
    """Test parsing RSECT directive"""
    provenance = StatementProvenance(
        statement_id="S007",
        original_file="test.asm",
        original_line=50
    )

    parsed_line = ParsedLine(
        label="REENT",
        opcode="RSECT",
        operands=[],
        comment=None,
        provenance=provenance
    )

    parser = SymbolParser()
    symbols = parser.parse_line(parsed_line, current_section=None)

    assert len(symbols) == 1
    assert symbols[0].name == "REENT"
    assert symbols[0].symbol_type == SymbolType.RSECT


def test_parse_equ_directive():
    """Test parsing EQU directive with numeric value"""
    provenance = StatementProvenance(
        statement_id="S008",
        original_file="test.asm",
        original_line=60
    )

    parsed_line = ParsedLine(
        label="MAXLEN",
        opcode="EQU",
        operands=["256"],
        comment=None,
        provenance=provenance
    )

    parser = SymbolParser()
    symbols = parser.parse_line(parsed_line, current_section="MAIN")

    assert len(symbols) == 1
    assert symbols[0].name == "MAXLEN"
    assert symbols[0].symbol_type == SymbolType.EQU
    assert symbols[0].value == 256
    assert symbols[0].section == "MAIN"


def test_parse_equ_symbolic():
    """Test parsing EQU directive with symbolic value (stores as 0)"""
    provenance = StatementProvenance(
        statement_id="S009",
        original_file="test.asm",
        original_line=61
    )

    parsed_line = ParsedLine(
        label="R15",
        opcode="EQU",
        operands=["15"],
        comment=None,
        provenance=provenance
    )

    parser = SymbolParser()
    symbols = parser.parse_line(parsed_line, current_section=None)

    assert len(symbols) == 1
    assert symbols[0].name == "R15"
    assert symbols[0].value == 15
