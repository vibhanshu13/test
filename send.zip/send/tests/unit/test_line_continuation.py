import pytest
from line_continuation import LineContinuationHandler


def test_no_continuation():
    """Test line without continuation"""
    handler = LineContinuationHandler()

    line = "         LA    R1,DATA"
    result = handler.process_line(line)

    assert result.is_complete is True
    assert result.text == "         LA    R1,DATA"
    assert result.continuation_count == 0


def test_single_continuation():
    """Test line with one continuation"""
    handler = LineContinuationHandler()

    # Line ending with continuation character (typically column 72)
    line1 = "         LA    R1,VERYLONGNAME                                         X"
    result1 = handler.process_line(line1)

    assert result1.is_complete is False
    assert result1.text is None

    # Continuation line
    line2 = "               PLUSMORE"
    result2 = handler.process_line(line2)

    assert result2.is_complete is True
    assert result2.text == "         LA    R1,VERYLONGNAMEPLUSMORE"
    assert result2.continuation_count == 1


def test_multiple_continuations():
    """Test line with multiple continuations"""
    handler = LineContinuationHandler()

    line1 = "         DC    CL80'VERY                                               X"
    result1 = handler.process_line(line1)
    assert result1.is_complete is False

    line2 = "               LONG                                                    X"
    result2 = handler.process_line(line2)
    assert result2.is_complete is False

    line3 = "               STRING'"
    result3 = handler.process_line(line3)

    assert result3.is_complete is True
    assert "VERYLONGSTRING" in result3.text
    assert result3.continuation_count == 2


def test_reset_on_complete():
    """Test handler resets after complete line"""
    handler = LineContinuationHandler()

    # First continued line
    handler.process_line("         LA    R1,NAME                                                X")
    result = handler.process_line("               CONT")
    assert result.is_complete is True

    # Next line should start fresh
    result = handler.process_line("         LA    R2,DATA")
    assert result.is_complete is True
    assert result.continuation_count == 0
