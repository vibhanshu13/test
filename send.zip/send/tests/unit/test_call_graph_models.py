import pytest
from models.call_graph import CallType, CallEdge, CallGraphNode, CallGraph


def test_call_edge_creation():
    """Test creating a call edge"""
    edge = CallEdge(
        source="MAIN",
        target="HELPER",
        call_type=CallType.SUBROUTINE_CALL,
        instruction="BAL",
        file="test.asm",
        line=100
    )

    assert edge.source == "MAIN"
    assert edge.target == "HELPER"
    assert edge.call_type == CallType.SUBROUTINE_CALL
    assert edge.is_indirect is False


def test_indirect_call_edge():
    """Test indirect call flagging"""
    edge = CallEdge(
        source="MAIN",
        target=None,
        call_type=CallType.SUBROUTINE_CALL,
        instruction="BASR",
        file="test.asm",
        line=100,
        is_indirect=True
    )

    assert edge.is_indirect is True
    assert edge.target is None


def test_call_graph_node():
    """Test call graph node"""
    node = CallGraphNode(
        name="MAIN",
        section="MAIN",
        file="test.asm",
        is_external=False
    )

    assert node.name == "MAIN"
    assert node.section == "MAIN"
    assert node.is_external is False


def test_call_graph_add_edge():
    """Test adding edges to call graph"""
    graph = CallGraph()

    graph.add_edge(
        source="MAIN",
        target="HELPER",
        call_type=CallType.SUBROUTINE_CALL,
        instruction="BAL",
        file="test.asm",
        line=100
    )

    assert len(graph.edges) == 1
    assert "MAIN" in graph.nodes
    assert "HELPER" in graph.nodes


def test_call_graph_get_callees():
    """Test getting callees of a node"""
    graph = CallGraph()

    graph.add_edge("MAIN", "HELPER1", CallType.SUBROUTINE_CALL, "BAL", "test.asm", 100)
    graph.add_edge("MAIN", "HELPER2", CallType.SUBROUTINE_CALL, "BAL", "test.asm", 110)

    callees = graph.get_callees("MAIN")
    assert len(callees) == 2
    assert "HELPER1" in callees
    assert "HELPER2" in callees


def test_call_graph_get_callers():
    """Test getting callers of a node"""
    graph = CallGraph()

    graph.add_edge("MAIN", "HELPER", CallType.SUBROUTINE_CALL, "BAL", "test.asm", 100)
    graph.add_edge("UTILS", "HELPER", CallType.SUBROUTINE_CALL, "BAL", "test.asm", 200)

    callers = graph.get_callers("HELPER")
    assert len(callers) == 2
    assert "MAIN" in callers
    assert "UTILS" in callers
