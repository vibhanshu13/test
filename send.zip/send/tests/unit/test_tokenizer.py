import pytest
from tokenizer import Tokenizer, ParsedLine
from models.provenance import StatementProvenance


def test_tokenize_simple_instruction():
    """Test tokenizing a simple instruction"""
    tokenizer = Tokenizer()
    prov = StatementProvenance("stmt_00001", "test.asm", 10)

    line = "         LA    R1,DATA"
    result = tokenizer.tokenize_line(line, prov)

    assert result.label is None
    assert result.opcode == "LA"
    assert result.operands == ["R1", "DATA"]
    assert result.comment is None
    assert result.provenance == prov


def test_tokenize_with_label():
    """Test tokenizing instruction with label"""
    tokenizer = Tokenizer()
    prov = StatementProvenance("stmt_00002", "test.asm", 20)

    line = "LOOP     BAS   R14,SUBRTN"
    result = tokenizer.tokenize_line(line, prov)

    assert result.label == "LOOP"
    assert result.opcode == "BAS"
    assert result.operands == ["R14", "SUBRTN"]


def test_tokenize_with_comment():
    """Test tokenizing instruction with comment"""
    tokenizer = Tokenizer()
    prov = StatementProvenance("stmt_00003", "test.asm", 30)

    line = "         L     R15,=V(FUNC)  Load function address"
    result = tokenizer.tokenize_line(line, prov)

    assert result.opcode == "L"
    assert result.operands == ["R15", "=V(FUNC)"]
    assert result.comment == "Load function address"


def test_tokenize_comment_line():
    """Test tokenizing comment-only line"""
    tokenizer = Tokenizer()
    prov = StatementProvenance("stmt_00004", "test.asm", 40)

    line = "* This is a comment"
    result = tokenizer.tokenize_line(line, prov)

    assert result.label is None
    assert result.opcode is None
    assert result.operands == []
    assert result.comment == "This is a comment"


def test_tokenize_directive():
    """Test tokenizing assembler directive"""
    tokenizer = Tokenizer()
    prov = StatementProvenance("stmt_00005", "test.asm", 50)

    line = "MAINSECT CSECT"
    result = tokenizer.tokenize_line(line, prov)

    assert result.label == "MAINSECT"
    assert result.opcode == "CSECT"
    assert result.operands == []


def test_tokenize_indexed_operand_preserves_inner_comma():
    """Test operand splitting keeps commas inside indexed addressing."""
    tokenizer = Tokenizer()
    prov = StatementProvenance("stmt_00006", "test.asm", 60)

    line = "         IC    R9,0(R7,R2)"
    result = tokenizer.tokenize_line(line, prov)

    assert result.opcode == "IC"
    assert result.operands == ["R9", "0(R7,R2)"]


def test_tokenize_literal_with_comma_preserves_literal():
    """Test operand splitting keeps commas inside quoted literals."""
    tokenizer = Tokenizer()
    prov = StatementProvenance("stmt_00007", "test.asm", 70)

    line = "         MVC   FIELD,=C'A,B'"
    result = tokenizer.tokenize_line(line, prov)

    assert result.opcode == "MVC"
    assert result.operands == ["FIELD", "=C'A,B'"]


def test_tokenize_ds_single_space_comment():
    """DS should treat trailing free text as comment even with single-space separator."""
    tokenizer = Tokenizer()
    prov = StatementProvenance("stmt_00008", "test.asm", 80)

    line = "MYFIELD  DS   XL2 LENGTH OF FIXED DATA 2.0"
    result = tokenizer.tokenize_line(line, prov)

    assert result.label == "MYFIELD"
    assert result.opcode == "DS"
    assert result.operands == ["XL2"]
    assert result.comment == "LENGTH OF FIXED DATA 2.0"


def test_tokenize_equ_single_space_comment():
    """EQU should keep expression and split trailing comment text."""
    tokenizer = Tokenizer()
    prov = StatementProvenance("stmt_00009", "test.asm", 90)

    line = "LG#SECNT EQU  LG#SEAREA/LG#SELEN NBR OF PREDEFINED SE LMT SLOTS"
    result = tokenizer.tokenize_line(line, prov)

    assert result.label == "LG#SECNT"
    assert result.opcode == "EQU"
    assert result.operands == ["LG#SEAREA/LG#SELEN"]
    assert result.comment == "NBR OF PREDEFINED SE LMT SLOTS"
