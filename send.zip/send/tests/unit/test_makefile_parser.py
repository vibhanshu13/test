"""Tests for Makefile parser."""

from pathlib import Path
from passes.makefile_parser import MakefileParser


def test_makefile_parser_extracts_build_metadata():
    content = """
CC=g++
CXXFLAGS=-Iinclude -DDEBUG=1 -DNAME
LDFLAGS=-L/usr/lib -lssl -lcrypto
TARGET=libdemo.so
SRCS=main.cpp util.cpp asm.S
include common.mak

all: $(TARGET)
\t$(CC) $(CXXFLAGS) -shared -o $(TARGET) $(SRCS) $(LDFLAGS)
"""
    parser = MakefileParser()
    result = parser.parse(Path("Makefile"), content)

    assert "DEBUG=1" in result["defines"]
    assert "NAME" in result["defines"]
    assert "include" in result["include_dirs"]
    assert "ssl" in result["libs"]
    assert "crypto" in result["libs"]
    assert "libdemo.so" in result["outputs"]
    assert "libdemo.so" in result["shared_objects"]
    assert "main.cpp" in result["source_files"]
    assert "util.cpp" in result["source_files"]
