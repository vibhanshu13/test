"""Tests for symbol serialization."""
import json
from models.symbol import Symbol, SymbolType, SymbolTable
from models.provenance import StatementProvenance


def test_symbol_to_dict():
    """Test Symbol serialization to dict."""
    provenance = StatementProvenance(
        statement_id="test_1",
        original_file="test.asm",
        original_line=42
    )
    symbol = Symbol(
        name="TESTFUNC",
        symbol_type=SymbolType.ENTRY,
        file="test.asm",
        provenance=provenance,
        value=0x1000,
        section="MAINCODE"
    )

    result = symbol.to_dict()

    assert result["name"] == "TESTFUNC"
    assert result["type"] == "entry"
    assert result["value"] == 0x1000
    assert result["section"] == "MAINCODE"
    assert result["file"] == "test.asm"
    assert result["is_duplicate"] is False
    assert "provenance" in result
    assert result["provenance"]["original_file"] == "test.asm"
    assert result["provenance"]["original_line"] == 42


def test_symbol_to_json():
    """Test Symbol can be JSON serialized."""
    provenance = StatementProvenance(
        statement_id="test_2",
        original_file="module.asm",
        original_line=10
    )
    symbol = Symbol(
        name="EXTVAR",
        symbol_type=SymbolType.EXTRN,
        file="module.asm",
        provenance=provenance
    )

    json_str = json.dumps(symbol.to_dict())
    parsed = json.loads(json_str)

    assert parsed["name"] == "EXTVAR"
    assert parsed["type"] == "extrn"
    assert parsed["value"] is None
    assert parsed["file"] == "module.asm"


def test_symbol_table_to_dict():
    """Test SymbolTable serialization to dict."""
    table = SymbolTable()

    prov1 = StatementProvenance("test_3", "test.asm", 1)
    prov2 = StatementProvenance("test_4", "test.asm", 2)

    symbol1 = Symbol("FUNC1", SymbolType.ENTRY, "test.asm", prov1)
    symbol2 = Symbol("VAR1", SymbolType.EXTRN, "test.asm", prov2)

    table.add_symbol(symbol1)
    table.add_symbol(symbol2)

    result = table.to_dict()

    assert "global_symbols" in result
    assert "sections" in result
    assert len(result["global_symbols"]) == 2
    assert "FUNC1" in result["global_symbols"]
    assert "VAR1" in result["global_symbols"]


def test_symbol_table_to_dict_includes_section_directives():
    table = SymbolTable()
    prov = StatementProvenance("test_5", "tpfregs.asm", 10)
    csect = Symbol("ASM_UPDSTS", SymbolType.CSECT, "tpfregs.asm", prov, section="ASM_UPDSTS")
    table.add_symbol(csect)

    result = table.to_dict()
    assert "ASM_UPDSTS" in result["sections"]
