import pytest
from models.provenance import StatementProvenance


def test_statement_provenance_creation():
    """Test basic provenance object creation"""
    prov = StatementProvenance(
        statement_id="stmt_00001",
        original_file="test.asm",
        original_line=42
    )

    assert prov.statement_id == "stmt_00001"
    assert prov.original_file == "test.asm"
    assert prov.original_line == 42
    assert prov.expanded_from_copy is None
    assert prov.macro_expansion_parent is None
    assert prov.section is None
    assert prov.routine is None


def test_statement_provenance_with_copy_expansion():
    """Test provenance with COPY directive expansion"""
    prov = StatementProvenance(
        statement_id="stmt_00100",
        original_file="module.asm",
        original_line=10,
        expanded_from_copy="utils.asm"
    )

    assert prov.expanded_from_copy == "utils.asm"


def test_statement_provenance_full_trace():
    """Test full expansion trace generation"""
    prov = StatementProvenance(
        statement_id="stmt_00200",
        original_file="module.asm",
        original_line=50,
        expanded_from_copy="macros.asm",
        section="MAINSECT",
        routine="HELPER"
    )

    trace = prov.get_full_trace()

    assert "module.asm:50" in trace
    assert "COPY macros.asm" in trace
    assert "section=MAINSECT" in trace
    assert "routine=HELPER" in trace
