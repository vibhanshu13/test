import pytest
from macro_expander import MacroExpander
from models.macro_definition import MacroDefinition, MacroParameter
from pathlib import Path


def test_substitute_simple_parameter():
    """Test simple parameter substitution"""
    macro = MacroDefinition(
        name="SETRC",
        parameters=[MacroParameter("&RC", None, False)],
        body=["LA    R15,&RC", "BR    R14"],
        source_file=Path("test.asm"),
        start_line=1,
        end_line=3,
        scope="global"
    )

    expander = MacroExpander()
    result = expander.expand("SETRC 4", macro)

    instructions = [i.instruction for i in result.expanded_instructions]
    assert "LA    R15,4" in instructions
    assert "BR    R14" in instructions


def test_substitute_multiple_parameters():
    """Test multiple parameter substitutions in one line"""
    macro = MacroDefinition(
        name="TEST",
        parameters=[
            MacroParameter("&REG", None, False),
            MacroParameter("&VALUE", None, False)
        ],
        body=["L     &REG,=F'&VALUE'"],
        source_file=Path("test.asm"),
        start_line=1,
        end_line=2,
        scope="global"
    )

    expander = MacroExpander()
    result = expander.expand("TEST R5,100", macro)

    instructions = [i.instruction for i in result.expanded_instructions]
    assert "L     R5,=F'100'" in instructions


def test_substitute_label_parameter():
    """Test label parameter substitution"""
    macro = MacroDefinition(
        name="CHKRC",
        parameters=[
            MacroParameter("&LABEL", None, True),
            MacroParameter("&RC", "0", False)
        ],
        body=["&LABEL   LTR   R15,R15"],
        source_file=Path("test.asm"),
        start_line=1,
        end_line=2,
        scope="global"
    )

    expander = MacroExpander()
    result = expander.expand("CHKVAL  CHKRC RC=0", macro)

    # Check that label was substituted
    instruction = result.expanded_instructions[0]
    assert instruction.label == "CHKVAL"
    assert "LTR   R15,R15" in instruction.instruction


def test_track_parameter_substitutions():
    """Test that parameter substitutions are tracked"""
    macro = MacroDefinition(
        name="TEST",
        parameters=[
            MacroParameter("&P1", None, False),
            MacroParameter("&P2", None, False)
        ],
        body=["L     &P1,&P2"],
        source_file=Path("test.asm"),
        start_line=1,
        end_line=2,
        scope="global"
    )

    expander = MacroExpander()
    result = expander.expand("TEST R5,DATA", macro)

    instruction = result.expanded_instructions[0]
    assert len(instruction.parameter_substitutions) == 2

    # Check substitutions are tracked
    sub_params = [s.param for s in instruction.parameter_substitutions]
    assert "&P1" in sub_params
    assert "&P2" in sub_params


def test_no_substitution_when_param_empty():
    """Test that empty parameters leave &PARAM in place"""
    macro = MacroDefinition(
        name="TEST",
        parameters=[MacroParameter("&LABEL", None, True)],
        body=["&LABEL   NOP"],
        source_file=Path("test.asm"),
        start_line=1,
        end_line=2,
        scope="global"
    )

    expander = MacroExpander()
    result = expander.expand("TEST", macro)  # No label provided

    # Should just remove the label, not leave &LABEL
    instruction = result.expanded_instructions[0]
    assert instruction.label is None or instruction.label == ""
    assert "NOP" in instruction.instruction
