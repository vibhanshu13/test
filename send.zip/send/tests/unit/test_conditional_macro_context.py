import pytest
from conditional_evaluator import ConditionalEvaluator


def test_evaluate_with_macro_parameters():
    """Test evaluating conditions with macro parameter bindings"""
    evaluator = ConditionalEvaluator()

    # Macro parameters provided as dict
    macro_params = {"&RC": "0", "&ERROR": "BADCARD"}

    # Test condition: ('&RC' EQ '0')
    condition = "('&RC' EQ '0')"
    result = evaluator.evaluate_with_params(condition, macro_params)

    assert result is True


def test_evaluate_macro_param_not_equal():
    """Test NE condition with macro parameters"""
    evaluator = ConditionalEvaluator()

    macro_params = {"&RC": "4", "&ERROR": "BADCARD"}

    condition = "('&RC' EQ '0')"
    result = evaluator.evaluate_with_params(condition, macro_params)

    assert result is False


def test_evaluate_macro_param_numeric():
    """Test numeric comparison with macro parameters"""
    evaluator = ConditionalEvaluator()

    macro_params = {"&COUNT": "10"}

    condition = "(&COUNT GT 5)"
    result = evaluator.evaluate_with_params(condition, macro_params)

    assert result is True


def test_evaluate_type_attribute():
    """Test type attribute T' for omitted parameters"""
    evaluator = ConditionalEvaluator()

    # Parameter not provided (omitted)
    macro_params = {"&PARM1": "value"}

    # T'&PARM2 should be 'O' (omitted)
    condition = "(T'&PARM2 EQ 'O')"
    result = evaluator.evaluate_with_params(condition, macro_params)

    assert result is True


def test_evaluate_type_attribute_provided():
    """Test type attribute for provided parameter"""
    evaluator = ConditionalEvaluator()

    macro_params = {"&PARM": "value"}

    # T'&PARM should not be 'O' (it's provided)
    condition = "(T'&PARM EQ 'O')"
    result = evaluator.evaluate_with_params(condition, macro_params)

    assert result is False
