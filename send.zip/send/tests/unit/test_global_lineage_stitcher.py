import pytest
from pathlib import Path
from passes.global_lineage_stitcher import GlobalLineageStitcher
from models.analysis_context import AnalysisContext
from models.variable_lineage import VariableLineageGraph
from models.symbol import Symbol, SymbolType
from models.provenance import StatementProvenance
from models.call_graph import CallGraph, CallType
from models.c_family import CTranslationUnit, CAssignment
from models.macro_expansion import ExpansionResult


def test_global_stitcher_initialization():
    """Test GlobalLineageStitcher initializes correctly."""
    stitcher = GlobalLineageStitcher()
    assert stitcher.global_graph is not None
    assert isinstance(stitcher.symbol_to_file, dict)
    assert isinstance(stitcher.entry_points, dict)
    assert isinstance(stitcher.external_refs, dict)


def test_collect_entry_points():
    """Test collecting ENTRY symbols from contexts."""
    stitcher = GlobalLineageStitcher()

    # Create context with symbol table
    context1 = AnalysisContext()
    context1.add_metadata("symbol_table", {
        "HELPER": {"type": "ENTRY", "section": "MAIN"},
        "WORKER": {"type": "ENTRY", "section": "CODE"}
    })

    contexts = {"file1.asm": context1}
    stitcher.process_contexts(contexts)

    assert "HELPER" in stitcher.entry_points
    assert stitcher.entry_points["HELPER"] == ("file1.asm", "MAIN")


def test_collect_external_refs():
    """Test collecting EXTRN symbols from contexts."""
    stitcher = GlobalLineageStitcher()

    # Create context with EXTRN references
    context1 = AnalysisContext()
    context1.add_metadata("symbol_table", {
        "DBFUNC": {"type": "EXTRN"},
        "UTIL": {"type": "EXTRN"}
    })

    context2 = AnalysisContext()
    context2.add_metadata("symbol_table", {
        "DBFUNC": {"type": "EXTRN"}
    })

    contexts = {"file1.asm": context1, "file2.asm": context2}
    stitcher.process_contexts(contexts)

    assert "DBFUNC" in stitcher.external_refs
    assert len(stitcher.external_refs["DBFUNC"]) == 2
    assert "file1.asm" in stitcher.external_refs["DBFUNC"]
    assert "file2.asm" in stitcher.external_refs["DBFUNC"]


def test_merge_lineage_graphs():
    """Test merging lineage graphs from multiple files."""
    stitcher = GlobalLineageStitcher()

    # Create two contexts with lineage graphs
    context1 = AnalysisContext()
    graph1 = VariableLineageGraph()
    graph1.add_definition("R6", "register", "file1.asm", 10, "L R6,VALUE")
    graph1.add_assignment("VALUE", "memory", "R6", "register", "file1.asm", 10, "L R6,VALUE")
    context1.add_metadata("variable_lineage", graph1)

    context2 = AnalysisContext()
    graph2 = VariableLineageGraph()
    graph2.add_definition("R7", "register", "file2.asm", 20, "L R7,DATA")
    graph2.add_assignment("DATA", "memory", "R7", "register", "file2.asm", 20, "L R7,DATA")
    context2.add_metadata("variable_lineage", graph2)

    contexts = {"file1.asm": context1, "file2.asm": context2}
    global_graph = stitcher.process_contexts(contexts)

    # Check nodes from both graphs are present
    assert global_graph.get_node_id("R6", "register") is not None
    assert global_graph.get_node_id("R7", "register") is not None
    assert global_graph.get_node_id("VALUE", "memory") is not None
    assert global_graph.get_node_id("DATA", "memory") is not None

    # Check edges from both graphs are present
    assert len(global_graph.edges) == 4  # 2 definitions + 2 assignments


def test_merge_empty_contexts():
    """Test merging contexts without lineage graphs."""
    stitcher = GlobalLineageStitcher()

    context1 = AnalysisContext()
    context2 = AnalysisContext()

    contexts = {"file1.asm": context1, "file2.asm": context2}
    global_graph = stitcher.process_contexts(contexts)

    assert global_graph is not None
    assert len(global_graph.nodes) == 0
    assert len(global_graph.edges) == 0


def test_symbol_to_file_mapping():
    """Test tracking which file defines each symbol."""
    stitcher = GlobalLineageStitcher()

    context1 = AnalysisContext()
    context1.add_metadata("symbol_table", {
        "HELPER": {"type": "ENTRY", "definition_file": "file1.asm"},
        "WORKER": {"type": "ENTRY", "definition_file": "file1.asm"}
    })

    contexts = {"file1.asm": context1}
    stitcher.process_contexts(contexts)

    assert "HELPER" in stitcher.symbol_to_file
    assert stitcher.symbol_to_file["HELPER"] == "file1.asm"
    assert "WORKER" in stitcher.symbol_to_file
    assert stitcher.symbol_to_file["WORKER"] == "file1.asm"


def test_stitcher_reads_symbol_table_objects():
    stitcher = GlobalLineageStitcher()
    context = AnalysisContext()
    context.symbol_table.add_symbol(Symbol(
        name="C_FUNC",
        symbol_type=SymbolType.ENTRY,
        file="mixed.c",
        provenance=StatementProvenance(statement_id="S1", original_file="mixed.c", original_line=1),
    ))
    stitcher.process_contexts({"mixed.c": context})
    assert stitcher.symbol_to_file["C_FUNC"] == "mixed.c"
    assert stitcher.entry_points["C_FUNC"] == ("mixed.c", None)


def test_stitcher_bridges_return_value_node_variants():
    stitcher = GlobalLineageStitcher()
    context = AnalysisContext()
    graph = VariableLineageGraph()
    graph.add_definition("return@HELPER", "variable", "a.c", 1, "return")
    graph.add_definition("return@HELPER", "return_value", "b.asm", 2, "BALR")
    graph.add_definition("return@HELPER:R15", "return_value", "b.asm", 3, "BALR")
    context.add_metadata("variable_lineage", graph)

    merged = stitcher.process_contexts({"a.c": context})
    edges = [e for e in merged.edges if e.relation == "assign"]
    assert any(e.source == "return_value:return@HELPER:R15" and e.target == "return_value:return@HELPER" for e in edges)
    assert any(e.source == "variable:return@HELPER" and e.target == "return_value:return@HELPER" for e in edges)


def test_stitcher_bridges_appstat_memory_to_struct_field():
    stitcher = GlobalLineageStitcher()
    context = AnalysisContext()
    graph = VariableLineageGraph()
    graph.add_definition("APPSTAT", "memory", "ecblevel.asm", 111, "APPSTAT DS CL1")
    graph.add_definition("CPP_AUTHZN::app->flags->status", "struct_field", "entrc_handlers.cpp", 73, "app->flags.status = 'A'")
    context.add_metadata("variable_lineage", graph)

    merged = stitcher.process_contexts({"mixed": context})
    assign_edges = [e for e in merged.edges if e.relation == "assign"]
    assert any(
        e.source == "memory:APPSTAT" and e.target == "struct_field:CPP_AUTHZN::app->flags->status"
        for e in assign_edges
    )


def test_stitcher_adds_alias_edge_for_appstat_memory_and_struct_field():
    stitcher = GlobalLineageStitcher()
    context = AnalysisContext()
    graph = VariableLineageGraph()
    graph.add_definition("APPSTAT", "memory", "ecblevel.asm", 111, "APPSTAT DS CL1")
    graph.add_definition("CPP_AUTHZN::app->flags->status", "struct_field", "entrc_handlers.cpp", 73, "app->flags.status = 'A'")
    context.add_metadata("variable_lineage", graph)

    merged = stitcher.process_contexts({"mixed": context})
    alias_edges = [e for e in merged.edges if e.relation == "alias"]
    assert any(
        e.source == "memory:APPSTAT" and e.target == "struct_field:CPP_AUTHZN::app->flags->status"
        for e in alias_edges
    )


def test_stitcher_adds_ecb_bridge_edge_for_appstat_memory_and_struct_field():
    stitcher = GlobalLineageStitcher()
    context = AnalysisContext()
    graph = VariableLineageGraph()
    graph.add_definition("APPSTAT", "memory", "ecblevel.asm", 111, "APPSTAT DS CL1")
    graph.add_definition("CPP_AUTHZN::app->flags->status", "struct_field", "entrc_handlers.cpp", 73, "app->flags.status = 'A'")
    context.add_metadata("variable_lineage", graph)

    merged = stitcher.process_contexts({"mixed": context})
    bridges = [e for e in merged.edges if e.relation == "ecb_bridge"]
    assert any(
        e.source == "struct_field:CPP_AUTHZN::app->flags->status"
        and e.target == "memory:APPSTAT"
        and e.scope == "ECB"
        for e in bridges
    )


def test_stitcher_annotates_ecb_field_metadata_on_memory_and_struct_nodes():
    stitcher = GlobalLineageStitcher()
    context = AnalysisContext()
    graph = VariableLineageGraph()
    graph.add_definition("APPSTAT", "memory", "ecblevel.asm", 111, "APPSTAT DS CL1")
    graph.add_definition("CPP_AUTHZN::app->flags->status", "struct_field", "entrc_handlers.cpp", 73, "app->flags.status = 'A'")
    context.add_metadata("variable_lineage", graph)

    merged = stitcher.process_contexts({"mixed": context})
    mem_node = merged.nodes.get("memory:APPSTAT")
    struct_node = merged.nodes.get("struct_field:CPP_AUTHZN::app->flags->status")
    assert mem_node is not None
    assert struct_node is not None
    assert mem_node.metadata.get("ecb_field") == "flags.status"
    assert struct_node.metadata.get("ecb_field") == "flags.status"


def test_stitcher_bridges_scratch_memory_to_cpp_variable():
    stitcher = GlobalLineageStitcher()
    context = AnalysisContext()
    graph = VariableLineageGraph()
    graph.add_definition("SCRATCH_P8", "memory", "ecblevel.asm", 1, "DS")
    graph.add_definition("ecb_scratch_write_and_call_asm::scratch", "variable", "ecb_level_ops.cpp", 2, "scratch")
    context.add_metadata("variable_lineage", graph)

    merged = stitcher.process_contexts({"mixed": context})
    edges = [e for e in merged.edges if e.relation == "assign"]
    assert any(
        e.source == "memory:SCRATCH_P8" and e.target == "variable:ecb_scratch_write_and_call_asm::scratch"
        for e in edges
    )


def test_stitcher_adds_direct_r15_to_return_receiver_edge():
    stitcher = GlobalLineageStitcher()
    context = AnalysisContext()
    context.symbol_table.add_symbol(Symbol(
        name="CPP_AUTHZN",
        symbol_type=SymbolType.ENTRY,
        file="entrydrv.asm",
        provenance=StatementProvenance(statement_id="S_CPP_AUTHZN", original_file="entrydrv.asm", original_line=69),
    ))
    graph = VariableLineageGraph()
    graph.add_assignment("return@CPP_AUTHZN:R15", "return_value", "R15", "register", "entrydrv.asm", 69, "ENTRC")
    graph.add_assignment("return@CPP_AUTHZN", "return_value", "caller::result", "variable", "entrc_handlers.cpp", 120, "call")
    context.add_metadata("variable_lineage", graph)

    merged = stitcher.process_contexts({"mixed": context})
    edges = [e for e in merged.edges if e.relation == "assign"]
    assert any(
        e.source == "register:R15" and e.target == "variable:caller::result"
        for e in edges
    )


def test_normalize_memory_name_strips_generic_function_accessor_prefix():
    stitcher = GlobalLineageStitcher()
    normalized = stitcher._normalize_memory_name("ctx_accessor()->flags->status")
    assert normalized == "flags.status"


def test_stitcher_adds_level_bridge_between_get_level_receiver_and_iscfa_recptr():
    stitcher = GlobalLineageStitcher()

    cpp_context = AnalysisContext()
    cpp_graph = VariableLineageGraph()
    cpp_graph.add_definition("level_produce_and_call_asm::msg_ptr", "variable", "ecb_level_ops.cpp", 123, "msg_ptr")
    cpp_context.add_metadata("variable_lineage", cpp_graph)

    cpp_call_graph = CallGraph()
    cpp_call_graph.add_edge(
        source="level_produce_and_call_asm",
        target="get_level",
        call_type=CallType.CALL,
        instruction="CALL",
        file="ecb_level_ops.cpp",
        line=124,
        level_number=0,
    )
    cpp_context.add_metadata("call_graph", cpp_call_graph)

    cpp_unit = CTranslationUnit(file_path=Path("ecb_level_ops.cpp"), language="cpp")
    cpp_unit.assignments.append(CAssignment(
        target="msg_ptr",
        target_kind="variable",
        sources=["get_level", "LEVEL0"],
        line=123,
        expression="msg_ptr = get_level(LEVEL0, 1, 512)",
        function="level_produce_and_call_asm",
        scope="local",
    ))
    cpp_context.add_metadata("c_family_unit", cpp_unit)

    asm_context = AnalysisContext()
    asm_graph = VariableLineageGraph()
    asm_graph.add_definition("LVRECPTR", "memory", "ecblevel.asm", 207, "DS")
    asm_context.add_metadata("variable_lineage", asm_graph)
    asm_context.macro_expansions = [
        ExpansionResult(
            expansion_id="EXP_ISCFA_1",
            invocation="ISCFA RECEIVE,DATA=LEVEL0,RECLEN=LVMSGSZ,RECPTR=LVRECPTR",
            invocation_file="ecblevel.asm",
            invocation_line=207,
            macro_name="ISCFA",
            definition_file="TPFAPI.mac",
            definition_line_start=1,
            definition_line_end=20,
            expansion_status="success",
            parameters={"&OP": "RECEIVE", "&DATA": "LEVEL0", "&RECPTR": "LVRECPTR"},
            expanded_instructions=[],
            error=None,
        )
    ]

    merged = stitcher.process_contexts({
        "ecb_level_ops.cpp": cpp_context,
        "ecblevel.asm": asm_context,
    })
    level_edges = [e for e in merged.edges if e.relation == "level_bridge"]

    assert any(
        e.source == "variable:level_produce_and_call_asm::msg_ptr"
        and e.target == "memory:LVRECPTR"
        and e.level_number == 0
        and e.scope == "LEVEL0"
        for e in level_edges
    )


def test_stitcher_bridges_struct_field_to_dsect_field_via_callarg_slot_and_using_map():
    stitcher = GlobalLineageStitcher()
    context = AnalysisContext()
    graph = VariableLineageGraph()

    # ASM DSECT labels.
    graph.add_definition("TXNREC", "memory", "RECPROC.asm", 127, "USING TXNREC,R5")
    graph.add_definition("TXNTYPE", "memory", "RECPROC.asm", 39, "TXNTYPE DS F")
    graph.annotate_node("TXNTYPE", "memory", byte_offset=8, cpp_struct="TXNREC")

    # Slot/register mapping in ASM callee RECPROC.
    graph.add_assignment("caller_param[0](R1)", "memory", "R5", "register", "RECPROC.asm", 126, "L R2,0(R1)", scope="RECPROC")
    graph.add_assignment("TXNREC", "memory", "R5", "register", "RECPROC.asm", 127, "USING TXNREC,R5", scope="RECPROC")

    # C++ call-arg handoff: struct field -> call arg -> caller_param[0].
    graph.add_definition("record_processing_pipeline::txn.txn_type", "struct_field", "cross_lang_callers.cpp", 206, "txn.txn_type = txn_type")
    graph.add_arg_bind(
        "record_processing_pipeline::txn.txn_type", "struct_field",
        "asm_process_txn_record#0", "call_arg",
        "cross_lang_callers.cpp", 230,
        expression="rc = asm_process_txn_record(&txn, &acct, &audit)",
        scope="record_processing_pipeline",
        statement_id="C_record_processing_pipeline_230",
        macro_expansion_parent=None,
    )
    graph.add_arg_bind(
        "asm_process_txn_record#0", "call_arg",
        "caller_param[0]", "memory",
        "cross_lang_callers.cpp", 230,
        expression="rc = asm_process_txn_record(&txn, &acct, &audit)",
        scope="record_processing_pipeline",
        statement_id="C_record_processing_pipeline_230",
        macro_expansion_parent=None,
        callee="RECPROC",
    )

    context.add_metadata("variable_lineage", graph)
    merged = stitcher.process_contexts({"mixed": context})

    assign_edges = [e for e in merged.edges if e.relation == "assign"]
    assert any(
        e.source == "memory:TXNTYPE"
        and e.target == "struct_field:record_processing_pipeline::txn.txn_type"
        for e in assign_edges
    )
    assert any(
        e.source == "struct_field:record_processing_pipeline::txn.txn_type"
        and e.target == "memory:TXNTYPE"
        for e in assign_edges
    )

    mem_node = merged.nodes.get("memory:TXNTYPE")
    assert mem_node is not None
    assert mem_node.metadata.get("dsect") == "TXNREC"
    assert mem_node.metadata.get("cpp_field") == "txn_type"


def test_stitcher_bridges_ce1cr_slot_to_matching_d_level_nodes():
    stitcher = GlobalLineageStitcher()
    context = AnalysisContext()
    graph = VariableLineageGraph()
    graph.add_definition("CE1CR4", "memory", "entrydrv.asm", 40, "CE1CR4 DS F")
    graph.add_definition("D4", "memory", "entrydrv.asm", 41, "GETCC D4")
    context.add_metadata("variable_lineage", graph)

    merged = stitcher.process_contexts({"entrydrv.asm": context})
    ce_bridges = [e for e in merged.edges if e.relation == "ce1cr_level_bridge"]
    ecb_bridges = [e for e in merged.edges if e.relation == "ecb_bridge"]

    assert any(
        e.source == "memory:CE1CR4"
        and e.target == "memory:D4"
        and e.level_number == 4
        and e.scope == "LEVEL4"
        for e in ce_bridges
    )
    assert any(
        e.source == "memory:D4"
        and e.target == "memory:CE1CR4"
        and e.level_number == 4
        for e in ce_bridges
    )
    assert any(
        e.source == "memory:CE1CR4"
        and e.target == "memory:D4"
        and e.scope == "ECB"
        for e in ecb_bridges
    )

    ce_node = merged.nodes.get("memory:CE1CR4")
    d4_node = merged.nodes.get("memory:D4")
    assert ce_node is not None
    assert d4_node is not None
    assert ce_node.metadata.get("ce1cr_slot") == 4
    assert ce_node.metadata.get("level_number") == 4
    assert d4_node.metadata.get("level_number") == 4


def test_stitcher_bridges_ce1cr_hex_slot_to_df_level():
    stitcher = GlobalLineageStitcher()
    context = AnalysisContext()
    graph = VariableLineageGraph()
    graph.add_definition("ecbptr()->ce1crf", "struct_field", "handler.cpp", 15, "regs.r15 = ecbptr()->ce1crf")
    graph.add_definition("DF", "memory", "entry.asm", 77, "GETCC DF")
    context.add_metadata("variable_lineage", graph)

    merged = stitcher.process_contexts({"mixed": context})
    ce_bridges = [e for e in merged.edges if e.relation == "ce1cr_level_bridge"]
    assert any(
        e.source == "struct_field:ecbptr()->ce1crf"
        and e.target == "memory:DF"
        and e.level_number == 15
        and e.scope == "LEVEL15"
        for e in ce_bridges
    )
