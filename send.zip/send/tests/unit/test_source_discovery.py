import shutil
import subprocess
from pathlib import Path

import pytest

from source_discovery import filter_discovered_paths, merge_discovery_exclude_patterns


def test_filter_discovered_paths_with_exclude_globs(tmp_path: Path):
    production = tmp_path / "src" / "PAYROUTE.asm"
    fixture = tmp_path / "temp" / "test_data" / "EQU_ALIASES.asm"
    production.parent.mkdir(parents=True)
    fixture.parent.mkdir(parents=True)
    production.write_text("PAYROUTE CSECT\n END\n")
    fixture.write_text("EQU_ALIASES CSECT\n END\n")

    candidates = [
        (production, tmp_path),
        (fixture, tmp_path),
    ]

    included, excluded_count = filter_discovered_paths(
        candidates,
        exclude_patterns=["temp/", "test_data/"],
        respect_gitignore=False,
    )

    assert included == [production.resolve()]
    assert excluded_count == 1


def test_merge_discovery_exclude_patterns_adds_default_non_production_patterns():
    merged = merge_discovery_exclude_patterns(["vendor/"], include_test_sources=False)
    assert "tests/" in merged
    assert "temp/" in merged
    assert "fixtures/" in merged
    assert "vendor/" in merged


def test_merge_discovery_exclude_patterns_can_include_test_sources():
    merged = merge_discovery_exclude_patterns(["vendor/"], include_test_sources=True)
    assert "vendor/" in merged
    assert "tests/" not in merged
    assert "temp/" not in merged


@pytest.mark.skipif(shutil.which("git") is None, reason="git is required")
def test_filter_discovered_paths_respects_gitignore(tmp_path: Path):
    tracked = tmp_path / "src" / "RISKENGS.asm"
    ignored_temp = tmp_path / "temp" / "test_data" / "CALLPARM.asm"
    ignored_final = tmp_path / "temp" / "final_test_data" / "CALLPARM.asm"

    tracked.parent.mkdir(parents=True)
    ignored_temp.parent.mkdir(parents=True)
    ignored_final.parent.mkdir(parents=True)

    tracked.write_text("RISKENGS CSECT\n END\n")
    ignored_temp.write_text("CALLPARM CSECT\n END\n")
    ignored_final.write_text("CALLPARM CSECT\n END\n")
    (tmp_path / ".gitignore").write_text("temp/\n")

    subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True, text=True)

    candidates = [
        (tracked, tmp_path),
        (ignored_temp, tmp_path),
        (ignored_final, tmp_path),
    ]

    included, excluded_count = filter_discovered_paths(
        candidates,
        respect_gitignore=True,
    )

    assert included == [tracked.resolve()]
    assert excluded_count == 2
