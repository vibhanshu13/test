"""Tests for the DB-backed seed finding tier (find_cpp_seed_nodes_db).

The DB tier must return EXACTLY what the streaming find_cpp_seed_nodes
returns — same membership AND same order (seed order feeds a node-capped
BFS, so order is semantics).  Covers the derived-column charset edge case
(# in HLASM names) and the FIX 16 fallback semantics.
"""
import json

import pytest

from backward_traversal.utils.cpp_lineage_utils import (
    find_cpp_seed_nodes,
    find_cpp_seed_nodes_db,
    db_setter_targets_for_stem,
    close_db_seed_state,
    node_terminal_base_lower,
    node_name_base_lower,
)


def test_terminal_base_lower_derivation():
    assert node_terminal_base_lower("struct_field:fn::ptr->cmSystem") == "cmsystem"
    assert node_terminal_base_lower("memory:LWRTS:#LTBKLN") == "ltbkln"  # '#' splits
    assert node_terminal_base_lower("x::lg1cycl[3]") == "lg1cycl"  # array idx stripped
    assert node_terminal_base_lower("memory:USEREG=R13") == "r13"
    assert node_terminal_base_lower("") is None


def test_name_base_lower_derivation():
    assert node_name_base_lower("lg1cycl[3]") == "lg1cycl"
    assert node_name_base_lower("CmSystem") == "cmsystem"
    assert node_name_base_lower("") is None


@pytest.fixture()
def seeded_db(tmp_path, monkeypatch):
    """A tiny index.db with gvl_nodes/gvl_edges rows mirroring a GVL dict."""
    from api.config import settings
    import api.index_db.engine as engine_mod

    monkeypatch.setattr(settings, "JOBS_BASE_DIR", tmp_path)
    monkeypatch.setattr(engine_mod, "_engines", {})
    close_db_seed_state()  # isolate cached connections/probes from other tests

    job_id = "seedjob"
    gvl = {
        "nodes": [
            {"id": "member:cmSystem", "kind": "member", "name": "cmSystem"},
            {"id": "struct_field:fn::ptr->cmSystem", "kind": "struct_field",
             "name": "cmSystem", "metadata": {"enclosing_type": "ptrT"}},
            {"id": "memory:LWRTS:#LTBKLN", "kind": "memory", "name": "#LTBKLN"},
            {"id": "register:R7", "kind": "register", "name": "R7"},  # skip-kind
            {"id": "variable:fn2::cmSystem", "kind": "variable", "name": "cmSystem"},
            {"id": "alias:da7gl", "kind": "struct_field", "name": "da7gl",
             "metadata": {"asm_alias": "WK_CMO"}},
            {"id": "struct_field:x::arr[3]", "kind": "struct_field", "name": "arr[3]"},
        ],
        "edges": [
            {"source": "struct_field:fn::ptr->cmSystem", "target": "memory:CMSYS",
             "relation": "assign", "file": "/src/aa11.cpp", "line": 5,
             "expression": "x"},
            {"source": "cppnode:y", "target": "mem:X:CMSYS",
             "relation": "assign", "file": "/src/aa11.cpp", "line": 9,
             "expression": "global_lineage_stitch:cpp_field_to_asm"},
        ],
    }

    from api.index_db.engine import get_engine
    from api.index_db.schema import gvl_nodes, gvl_edges
    engine = get_engine(job_id)
    with engine.begin() as conn:
        for n in gvl["nodes"]:
            meta = n.get("metadata") or {}
            extra = {k: v for k, v in n.items() if k not in {"id", "kind", "name"}}
            conn.execute(gvl_nodes.insert().values(
                job_id=job_id,
                node_id=n["id"], kind=n["kind"], name=n["name"],
                extra_json=json.dumps(extra) if extra else None,
                terminal_base_lower=node_terminal_base_lower(n["id"]) or "",
                name_base_lower=node_name_base_lower(n["name"]) or "",
                asm_alias_lower=str(meta.get("asm_alias") or "").lower(),
            ))
        for e in gvl["edges"]:
            conn.execute(gvl_edges.insert().values(
                job_id=job_id,
                source=e["source"], target=e["target"],
                source_lower=e["source"].lower(), target_lower=e["target"].lower(),
                relation=e["relation"], file=e["file"], line=e["line"],
                expression=e["expression"],
                file_stem="aa11",
            ))
    db_path = str(tmp_path / job_id / "index.db")
    yield db_path, job_id, gvl
    close_db_seed_state()


def _parity(db_path, job_id, gvl, var):
    stream = find_cpp_seed_nodes(gvl, var, {}, {})
    db = find_cpp_seed_nodes_db(db_path, job_id, var, include_fix16_fallback=False)
    assert db is not None, "DB tier unexpectedly unavailable"
    assert db == stream, f"{var}: db={db} stream={stream}"
    return stream


def test_db_seed_parity_basic(seeded_db):
    db_path, job_id, gvl = seeded_db
    seeds = _parity(db_path, job_id, gvl, "cmSystem")
    assert "struct_field:fn::ptr->cmSystem" in seeds
    assert "register:R7" not in seeds  # skip-kind respected


def test_db_seed_parity_hash_charset(seeded_db):
    """'#' is outside the component charset — the raw token alone would miss
    memory:LWRTS:#LTBKLN; the terminal-base token must recover it."""
    db_path, job_id, gvl = seeded_db
    seeds = _parity(db_path, job_id, gvl, "#LTBKLN")
    assert seeds == ["memory:LWRTS:#LTBKLN"]


def test_db_seed_parity_array_base(seeded_db):
    db_path, job_id, gvl = seeded_db
    seeds = _parity(db_path, job_id, gvl, "arrxyz")  # no match — both empty
    assert seeds == []


def test_db_seed_stitch_edges(seeded_db):
    """Strategy 3: cpp_field_to_asm stitch edge source becomes a seed."""
    db_path, job_id, gvl = seeded_db
    seeds = _parity(db_path, job_id, gvl, "CMSYS")
    assert "cppnode:y" in seeds


def test_db_setter_targets_for_stem(seeded_db):
    db_path, job_id, gvl = seeded_db
    res = db_setter_targets_for_stem(db_path, job_id, "aa11")
    assert res is not None
    targets, seen = res
    assert seen is True
    assert "memory:CMSYS" in targets
    res2 = db_setter_targets_for_stem(db_path, job_id, "nosuchstem")
    assert res2 is not None and res2[1] is False


def test_kill_switch(seeded_db, monkeypatch):
    db_path, job_id, gvl = seeded_db
    close_db_seed_state()
    monkeypatch.setenv("ASM_USE_DB_SEED_INDEX", "0")
    assert find_cpp_seed_nodes_db(db_path, job_id, "cmSystem") is None
    monkeypatch.delenv("ASM_USE_DB_SEED_INDEX")
    close_db_seed_state()
