import json
from pathlib import Path
from json_emitter import JSONEmitter
from models.analysis_context import AnalysisContext
from models.macro_expansion import (
    ExpansionResult, ExpandedInstruction,
    MacroProvenance, ParameterSubstitution
)


def _context_with_macros():
    ctx = AnalysisContext(file_path=Path("test.asm"))

    provenance = MacroProvenance(
        invocation_file="test.asm",
        invocation_line=10,
        invocation_macro="SETRC",
        definition_file="MACROS.asm",
        definition_line=44
    )

    instruction = ExpandedInstruction(
        instruction="LA    R15,0",
        label=None,
        parameter_substitutions=[
            ParameterSubstitution("&RC", "0", "operand2")
        ],
        provenance=provenance
    )

    expansion = ExpansionResult(
        expansion_id="expansion_1",
        invocation="SETRC 0",
        invocation_file="test.asm",
        invocation_line=10,
        macro_name="SETRC",
        definition_file="MACROS.asm",
        definition_line_start=44,
        definition_line_end=47,
        expansion_status="success",
        parameters={"&RC": "0"},
        expanded_instructions=[instruction],
        error=None
    )

    ctx.macro_expansions = [expansion]
    return ctx


def test_emitter_includes_macro_expansions():
    ctx = _context_with_macros()
    emitter = JSONEmitter()

    json_str = emitter.emit_json(ctx)
    data = json.loads(json_str)

    assert "macro_expansions" in data
    assert len(data["macro_expansions"]) == 1


def test_macro_expansion_structure():
    ctx = _context_with_macros()
    emitter = JSONEmitter()

    json_str = emitter.emit_json(ctx)
    data = json.loads(json_str)

    expansion = data["macro_expansions"][0]

    assert expansion["expansion_id"] == "expansion_1"
    assert expansion["expansion_status"] == "success"
    assert "parameters" in expansion
    assert "expanded_code" in expansion


def test_expanded_instruction_structure():
    ctx = _context_with_macros()
    emitter = JSONEmitter()

    json_str = emitter.emit_json(ctx)
    data = json.loads(json_str)

    instruction = data["macro_expansions"][0]["expanded_code"][0]

    assert instruction["instruction"] == "LA    R15,0"
    assert "parameter_substitutions" in instruction
    assert "provenance" in instruction


def test_empty_macro_expansions():
    ctx = AnalysisContext(file_path=Path("test.asm"))
    ctx.macro_expansions = []

    emitter = JSONEmitter()
    json_str = emitter.emit_json(ctx)
    data = json.loads(json_str)

    assert "macro_expansions" in data
    assert data["macro_expansions"] == []
