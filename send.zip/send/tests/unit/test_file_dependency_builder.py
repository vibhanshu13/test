import pytest
from passes.file_dependency_builder import FileDependencyBuilderPass
from models.analysis_context import AnalysisContext
from models.file_dependency import DependencyType
from models.call_graph import CallGraph, CallEdge, CallType


def test_file_dependency_builder_copy_includes():
    """Test extracting COPY include dependencies"""
    context = AnalysisContext()

    # Simulate Pass 1 context with COPY includes
    context.add_copy_include(
        including_file="main.asm",
        included_file="macros.mac",
        line_number=10
    )

    context.add_copy_include(
        including_file="main.asm",
        included_file="constants.mac",
        line_number=15
    )

    # Build dependency graph
    builder = FileDependencyBuilderPass()
    builder.process(context)

    # Verify graph was created
    graph = context.metadata.get("file_dependency_graph")
    assert graph is not None

    # Verify nodes
    assert "main.asm" in graph.nodes
    assert "macros.mac" in graph.nodes
    assert "constants.mac" in graph.nodes

    # Verify edges
    deps = graph.get_dependencies("main.asm")
    assert len(deps) == 2
    assert "macros.mac" in deps
    assert "constants.mac" in deps

    # Verify evidence
    copy_edges = [e for e in graph.edges if e.from_file == "main.asm"]
    assert len(copy_edges) == 2
    for edge in copy_edges:
        assert len(edge.evidence) >= 1
        assert edge.evidence[0].dependency_type == DependencyType.COPY_INCLUDE


def test_file_dependency_builder_symbol_references():
    """Test extracting symbol reference dependencies"""
    from models.symbol import Symbol, SymbolType, SymbolTable
    from models.provenance import StatementProvenance

    context = AnalysisContext()

    # Create symbol table (Pass 2 result)
    symbol_table = SymbolTable()

    # Create provenance for symbols
    prov = StatementProvenance(
        statement_id="test-001",
        original_file="main.asm",
        original_line=10
    )

    # File A declares EXTRN HELPER (defined in helper.asm)
    symbol_table.add_symbol(Symbol(
        name="HELPER",
        symbol_type=SymbolType.EXTRN,
        value=None,
        section=None,
        file="main.asm",
        provenance=prov
    ))

    # File B defines ENTRY HELPER
    prov2 = StatementProvenance(
        statement_id="test-002",
        original_file="helper.asm",
        original_line=5
    )

    symbol_table.add_symbol(Symbol(
        name="HELPER",
        symbol_type=SymbolType.ENTRY,
        value=0,
        section="HELPER",
        file="helper.asm",
        provenance=prov2
    ))

    context.add_metadata("symbol_table", symbol_table)

    # Build dependency graph
    builder = FileDependencyBuilderPass()
    builder.process(context)

    graph = context.metadata.get("file_dependency_graph")

    # Verify dependency from main.asm to helper.asm
    deps = graph.get_dependencies("main.asm")
    assert "helper.asm" in deps

    # Verify evidence
    edges = [e for e in graph.edges if e.from_file == "main.asm" and e.to_file == "helper.asm"]
    assert len(edges) >= 1
    assert edges[0].evidence[0].dependency_type == DependencyType.SYMBOL_REFERENCE


def test_file_dependency_builder_external_dependencies():
    """Test marking external dependencies"""
    from models.symbol import Symbol, SymbolType, SymbolTable
    from models.provenance import StatementProvenance

    context = AnalysisContext()

    # Create symbol table with unresolved external
    symbol_table = SymbolTable()

    # Create provenance
    prov = StatementProvenance(
        statement_id="test-003",
        original_file="main.asm",
        original_line=20
    )

    # EXTRN DBREAD (not defined anywhere - external library)
    symbol_table.add_symbol(Symbol(
        name="DBREAD",
        symbol_type=SymbolType.EXTRN,
        value=None,
        section=None,
        file="main.asm",
        provenance=prov
    ))

    context.add_metadata("symbol_table", symbol_table)

    # Build dependency graph
    builder = FileDependencyBuilderPass()
    builder.process(context)

    graph = context.metadata.get("file_dependency_graph")

    # Verify external dependency
    deps = graph.get_dependencies("main.asm")
    assert "DBREAD" in deps

    # Verify node is marked external
    assert graph.nodes["DBREAD"].is_external is True


def test_file_dependency_circular_detection_simple():
    """Test detecting simple circular dependency (2 files)"""
    context = AnalysisContext()

    # A → B via COPY
    context.add_copy_include("a.asm", "b.mac", 10)

    # B → A via COPY (creates cycle)
    context.add_copy_include("b.mac", "a.asm", 5)

    # Build dependency graph
    builder = FileDependencyBuilderPass()
    builder.process(context)

    graph = context.metadata.get("file_dependency_graph")

    # Verify cycle was detected
    assert len(graph.circular_dependencies) == 1

    cycle = graph.circular_dependencies[0]
    assert cycle.cycle_type == "simple"
    assert len(set(cycle.files)) == 2  # 2 unique files
    assert cycle.files[0] == cycle.files[-1]  # Forms a cycle


def test_file_dependency_circular_detection_complex():
    """Test detecting complex circular dependency (3+ files)"""
    context = AnalysisContext()

    # A → B → C → A (complex cycle)
    context.add_copy_include("a.asm", "b.asm", 10)
    context.add_copy_include("b.asm", "c.asm", 10)
    context.add_copy_include("c.asm", "a.asm", 10)

    # Build dependency graph
    builder = FileDependencyBuilderPass()
    builder.process(context)

    graph = context.metadata.get("file_dependency_graph")

    # Verify cycle was detected
    assert len(graph.circular_dependencies) == 1

    cycle = graph.circular_dependencies[0]
    assert cycle.cycle_type == "complex"
    assert len(set(cycle.files)) == 3  # 3 unique files


def test_file_dependency_no_cycles():
    """Test graph with no circular dependencies"""
    context = AnalysisContext()

    # A → B → C (no cycle)
    context.add_copy_include("a.asm", "b.asm", 10)
    context.add_copy_include("b.asm", "c.asm", 10)

    # Build dependency graph
    builder = FileDependencyBuilderPass()
    builder.process(context)

    graph = context.metadata.get("file_dependency_graph")

    # Verify no cycles
    assert len(graph.circular_dependencies) == 0


def test_file_dependency_multiple_independent_cycles():
    """Test detecting multiple independent cycles (Bug #1 fix verification)"""
    context = AnalysisContext()

    # First cycle: A ↔ B
    context.add_copy_include("a.asm", "b.asm", 10)
    context.add_copy_include("b.asm", "a.asm", 20)

    # Second cycle: C ↔ D (independent from first cycle)
    context.add_copy_include("c.asm", "d.asm", 10)
    context.add_copy_include("d.asm", "c.asm", 20)

    # Build dependency graph
    builder = FileDependencyBuilderPass()
    builder.process(context)

    graph = context.metadata.get("file_dependency_graph")

    # Verify both cycles were detected
    assert len(graph.circular_dependencies) == 2

    # Verify both are simple cycles
    for cycle in graph.circular_dependencies:
        assert cycle.cycle_type == "simple"
        assert len(set(cycle.files)) == 2


def test_file_dependency_multiple_paths_to_cycle():
    """Test cycle deduplication when same cycle reached from different nodes (Bug #2 fix verification)"""
    context = AnalysisContext()

    # Create a cycle: B → C → D → B
    context.add_copy_include("b.asm", "c.asm", 10)
    context.add_copy_include("c.asm", "d.asm", 20)
    context.add_copy_include("d.asm", "b.asm", 30)

    # Add multiple entry points to the cycle
    context.add_copy_include("a.asm", "b.asm", 5)  # A → B (enters cycle at B)
    context.add_copy_include("e.asm", "c.asm", 5)  # E → C (enters cycle at C)

    # Build dependency graph
    builder = FileDependencyBuilderPass()
    builder.process(context)

    graph = context.metadata.get("file_dependency_graph")

    # Verify only ONE cycle is detected (not multiple duplicates)
    assert len(graph.circular_dependencies) == 1

    # Verify it's the correct complex cycle
    cycle = graph.circular_dependencies[0]
    assert cycle.cycle_type == "complex"
    assert len(set(cycle.files)) == 3  # B, C, D


def test_file_dependency_cross_file_calls():
    """Test extracting cross-file call dependencies from Pass 3"""
    context = AnalysisContext()

    # Create call graph (Pass 3 result)
    call_graph = CallGraph()

    # Add nodes for routines in different files
    call_graph.add_node("MAIN", section="MAINPROG", file="main.asm")
    call_graph.add_node("HELPER", section="HELPER", file="helper.asm")
    call_graph.add_node("UTIL", section="UTIL", file="util.asm")

    # Add call edge from MAIN in main.asm to HELPER in helper.asm
    call_graph.edges.append(CallEdge(
        source="MAIN",
        target="HELPER",
        call_type=CallType.SUBROUTINE_CALL,
        instruction="BRAS",
        file="main.asm",
        line=50,
        is_indirect=False
    ))

    # Add call edge from HELPER in helper.asm to UTIL in util.asm
    call_graph.edges.append(CallEdge(
        source="HELPER",
        target="UTIL",
        call_type=CallType.SUBROUTINE_CALL,
        instruction="BAL",
        file="helper.asm",
        line=25,
        is_indirect=False
    ))

    # Add same-file call (should not create file dependency)
    call_graph.add_node("LOCALFUNC", section="MAIN", file="main.asm")
    call_graph.edges.append(CallEdge(
        source="MAIN",
        target="LOCALFUNC",
        call_type=CallType.SUBROUTINE_CALL,
        instruction="BAL",
        file="main.asm",
        line=60,
        is_indirect=False
    ))

    context.add_metadata("call_graph", call_graph)

    # Build dependency graph
    builder = FileDependencyBuilderPass()
    builder.process(context)

    graph = context.metadata.get("file_dependency_graph")

    # Verify cross-file dependencies were created
    main_deps = graph.get_dependencies("main.asm")
    assert "helper.asm" in main_deps

    helper_deps = graph.get_dependencies("helper.asm")
    assert "util.asm" in helper_deps

    # Verify same-file call did NOT create dependency
    # (main.asm should only depend on helper.asm, not itself)
    assert "main.asm" not in main_deps

    # Verify evidence type
    edges = [e for e in graph.edges if e.from_file == "main.asm" and e.to_file == "helper.asm"]
    assert len(edges) >= 1
    call_evidence = [ev for ev in edges[0].evidence if ev.dependency_type == DependencyType.CROSS_FILE_CALL]
    assert len(call_evidence) >= 1
    assert "MAIN" in call_evidence[0].details
    assert "HELPER" in call_evidence[0].details


def test_file_dependency_cross_file_calls_with_indirect():
    """Test that indirect calls (no target) are skipped"""
    context = AnalysisContext()

    # Create call graph with indirect call
    call_graph = CallGraph()

    call_graph.add_node("MAIN", section="MAINPROG", file="main.asm")

    # Indirect call (target unknown)
    call_graph.edges.append(CallEdge(
        source="MAIN",
        target=None,  # Indirect - target unknown
        call_type=CallType.SUBROUTINE_CALL,
        instruction="BASR",
        file="main.asm",
        line=50,
        is_indirect=True,
        register="R15"
    ))

    context.add_metadata("call_graph", call_graph)

    # Build dependency graph
    builder = FileDependencyBuilderPass()
    builder.process(context)

    graph = context.metadata.get("file_dependency_graph")

    # Verify no dependencies created for indirect calls
    if "main.asm" in graph.nodes:
        main_deps = graph.get_dependencies("main.asm")
        # Should be empty or not exist
        assert len(main_deps) == 0


def test_file_dependency_mixed_dependency_types():
    """Test that COPY includes, symbol references, and cross-file calls are all processed"""
    from models.symbol import Symbol, SymbolType, SymbolTable
    from models.provenance import StatementProvenance

    context = AnalysisContext()

    # Add COPY include dependency
    context.add_copy_include("main.asm", "macros.mac", 10)

    # Add symbol reference dependency
    symbol_table = SymbolTable()
    prov = StatementProvenance("test-001", "main.asm", 20)
    symbol_table.add_symbol(Symbol(
        name="HELPER",
        symbol_type=SymbolType.EXTRN,
        value=None,
        section=None,
        file="main.asm",
        provenance=prov
    ))
    prov2 = StatementProvenance("test-002", "helper.asm", 5)
    symbol_table.add_symbol(Symbol(
        name="HELPER",
        symbol_type=SymbolType.ENTRY,
        value=0,
        section="HELPER",
        file="helper.asm",
        provenance=prov2
    ))
    context.add_metadata("symbol_table", symbol_table)

    # Add cross-file call dependency
    call_graph = CallGraph()
    call_graph.add_node("MAIN", section="MAINPROG", file="main.asm")
    call_graph.add_node("UTIL", section="UTIL", file="util.asm")
    call_graph.edges.append(CallEdge(
        source="MAIN",
        target="UTIL",
        call_type=CallType.SUBROUTINE_CALL,
        instruction="BRAS",
        file="main.asm",
        line=30,
        is_indirect=False
    ))
    context.add_metadata("call_graph", call_graph)

    # Build dependency graph
    builder = FileDependencyBuilderPass()
    builder.process(context)

    graph = context.metadata.get("file_dependency_graph")

    # Verify all three types of dependencies
    main_deps = graph.get_dependencies("main.asm")
    assert "macros.mac" in main_deps
    assert "helper.asm" in main_deps
    assert "util.asm" in main_deps

    # Verify evidence for each dependency type
    edges_from_main = [e for e in graph.edges if e.from_file == "main.asm"]

    # Find evidence types
    evidence_types = set()
    for edge in edges_from_main:
        for ev in edge.evidence:
            evidence_types.add(ev.dependency_type)

    assert DependencyType.COPY_INCLUDE in evidence_types
    assert DependencyType.SYMBOL_REFERENCE in evidence_types
    assert DependencyType.CROSS_FILE_CALL in evidence_types
