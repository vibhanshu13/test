"""Tests for the Phase-1 C++ hot-path optimizations
(docs/plans/2026-06-10-parser-phase1-cpp-hotpath-design.md).

Covers the shared header-artifact cache (hit behavior, language isolation,
LRU bound, staleness) and a walk()-handler smoke test guarding the
named-children traversal change.
"""
import pytest

from multi_file import c_family_analyzer as mod
from multi_file.c_family_analyzer import CFamilyAnalyzer, clear_header_artifact_cache


HEADER = """\
#pragma map(getSysLimit, "GSYSLIM")
enum SysMode { MODE_A = 1, MODE_B = 2 };
struct ccDa7gl { int cmSystem; };
"""

MAIN_TMPL = """\
#include "shared.hpp"
int f{n}() {{ return MODE_A; }}
"""


@pytest.fixture()
def src_tree(tmp_path):
    clear_header_artifact_cache()
    (tmp_path / "shared.hpp").write_text(HEADER)
    for n in (1, 2):
        (tmp_path / f"main{n}.cpp").write_text(MAIN_TMPL.format(n=n))
    yield tmp_path
    clear_header_artifact_cache()


def test_header_read_once_across_files(src_tree, monkeypatch):
    """The second file including the same header must not re-read it."""
    analyzer = CFamilyAnalyzer("cpp", search_paths=[src_tree])
    header = (src_tree / "shared.hpp").resolve()

    reads = {"n": 0}
    orig_read_text = type(header).read_text

    def counting_read_text(self, *a, **kw):
        if self.name == "shared.hpp":
            reads["n"] += 1
        return orig_read_text(self, *a, **kw)

    monkeypatch.setattr(type(header), "read_text", counting_read_text)

    for n in (1, 2):
        fp = src_tree / f"main{n}.cpp"
        content = orig_read_text(fp)
        e1 = analyzer._collect_include_enum_values(fp, content)
        a1 = analyzer._collect_include_symbol_aliases(fp, content)
        assert "MODE_A" in e1
        assert a1.get("getSysLimit") == "GSYSLIM"

    # enum_values and symbol_aliases each need the text once (lazy per-kind
    # fill); all four collector calls together must not exceed 2 reads, and
    # the second file must add none.
    assert reads["n"] <= 2


def test_language_isolation(src_tree):
    """c and cpp analyzers must not share extraction entries."""
    cpp = CFamilyAnalyzer("cpp", search_paths=[src_tree])
    c = CFamilyAnalyzer("c", search_paths=[src_tree])
    fp = src_tree / "main1.cpp"
    content = fp.read_text()
    cpp._collect_include_enum_values(fp, content)
    c._collect_include_enum_values(fp, content)
    langs = {key[3] for key in mod._header_cache}
    assert langs == {"cpp", "c"}


def test_lru_bound(src_tree, monkeypatch):
    monkeypatch.setattr(mod, "_HEADER_CACHE_MAX", 1)
    analyzer = CFamilyAnalyzer("cpp", search_paths=[src_tree])
    (src_tree / "other.hpp").write_text("enum Other { O_1 = 9 };\n")
    (src_tree / "main3.cpp").write_text('#include "shared.hpp"\n#include "other.hpp"\n')
    fp = src_tree / "main3.cpp"
    analyzer._collect_include_enum_values(fp, fp.read_text())
    assert len(mod._header_cache) == 1  # capped, oldest evicted


def test_stale_entry_unreachable_after_modification(src_tree):
    analyzer = CFamilyAnalyzer("cpp", search_paths=[src_tree])
    fp = src_tree / "main1.cpp"
    enums = analyzer._collect_include_enum_values(fp, fp.read_text())
    assert "MODE_A" in enums and "MODE_Z" not in enums

    header = src_tree / "shared.hpp"
    header.write_text(HEADER.replace("MODE_B = 2", "MODE_Z = 7"))
    import os
    st = header.stat()
    os.utime(header, ns=(st.st_atime_ns, st.st_mtime_ns + 1_000_000))

    enums2 = analyzer._collect_include_enum_values(fp, fp.read_text())
    assert "MODE_Z" in enums2  # (path, mtime_ns, size) key → fresh extraction


def test_walk_handlers_still_fire_on_named_traversal(tmp_path):
    """Guard for the named-children walk change: condition contexts, struct
    fields, and assignments (handlers spread across walk()) still extract."""
    from passes.c_family_parser import CFamilyParser

    src = tmp_path / "w.cpp"
    src.write_text(
        "struct Box { int width; };\n"
        "int g(int x) {\n"
        "    Box b;\n"
        "    if (x > 0) { b.width = x; } else { b.width = 0; }\n"
        "    return b.width;\n"
        "}\n"
    )
    unit = CFamilyParser("cpp").parse(src, src.read_text())
    targets = {a.target for a in unit.assignments}
    assert any("width" in t for t in targets)
    width_assigns = [a for a in unit.assignments if "width" in a.target]
    contexts = {tuple(a.conditional_context or []) for a in width_assigns}
    # One branch under (x > 0), the else branch under NOT(x > 0).
    assert any("x > 0" in " ".join(c) for c in contexts if c)
    assert any("NOT" in " ".join(c) for c in contexts if c)
