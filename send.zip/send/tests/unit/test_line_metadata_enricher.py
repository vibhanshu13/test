"""Tests for line metadata enricher."""

from passes.line_metadata_enricher import LineMetadataEnricher
from models.line_metadata import LineMetadataIndex, LineMetadata, CodeblockContext, ConditionalContext, CallContext
from models.call_graph import CallGraph, CallType


def test_enricher_initialization():
    """Test enricher initializes with call graph and index."""
    call_graph = CallGraph()
    index = LineMetadataIndex()

    enricher = LineMetadataEnricher(call_graph, index)

    assert enricher.call_graph is call_graph
    assert enricher.index is index


def test_enricher_enrich_with_function_calls():
    """Test enriching metadata with C/C++ function calls."""
    call_graph = CallGraph()
    call_graph.add_edge(
        source="main",
        target="helper",
        call_type=CallType.CALL,
        instruction="CALL",
        file="test.c",
        line=20
    )

    index = LineMetadataIndex()
    metadata = LineMetadata(
        file="test.c",
        line_number=20,
        codeblock=CodeblockContext(enclosing_function="main"),
        conditional=ConditionalContext(False, 0, [], []),
        calls=CallContext()
    )
    index.add(metadata)

    enricher = LineMetadataEnricher(call_graph, index)
    enricher.enrich_all()

    # Check that calls were populated
    enriched = index.get("test.c", 20)
    assert "helper" in enriched.calls.calls_functions


def test_enricher_enrich_with_routine_calls():
    """Test enriching with ASM routine calls."""
    call_graph = CallGraph()
    call_graph.add_edge(
        source="INIT",
        target="SUBRTN1",
        call_type=CallType.SUBROUTINE_CALL,
        instruction="BAL",
        file="test.asm",
        line=100
    )

    index = LineMetadataIndex()
    metadata = LineMetadata(
        file="test.asm",
        line_number=100,
        codeblock=CodeblockContext(enclosing_routine="INIT"),
        conditional=ConditionalContext(False, 0, [], []),
        calls=CallContext()
    )
    index.add(metadata)

    enricher = LineMetadataEnricher(call_graph, index)
    enricher.enrich_all()

    enriched = index.get("test.asm", 100)
    assert "SUBRTN1" in enriched.calls.calls_routines


def test_enricher_enrich_with_macro_invocations():
    """Test enriching with macro invocations."""
    call_graph = CallGraph()
    call_graph.add_edge(
        source="INIT",
        target="ENTC",
        call_type=CallType.MACRO_INVOCATION,
        instruction="MACRO",
        file="test.asm",
        line=50
    )

    index = LineMetadataIndex()
    metadata = LineMetadata(
        file="test.asm",
        line_number=50,
        codeblock=CodeblockContext(enclosing_routine="INIT"),
        conditional=ConditionalContext(False, 0, [], []),
        calls=CallContext()
    )
    index.add(metadata)

    enricher = LineMetadataEnricher(call_graph, index)
    enricher.enrich_all()

    enriched = index.get("test.asm", 50)
    assert "ENTC" in enriched.calls.invokes_macros


def test_enricher_enrich_multiple_calls():
    """Test enriching with multiple calls from same codeblock."""
    call_graph = CallGraph()
    call_graph.add_edge("main", "foo", CallType.CALL, "CALL", "test.c", 20)
    call_graph.add_edge("main", "bar", CallType.CALL, "CALL", "test.c", 25)
    call_graph.add_edge("main", "baz", CallType.CALL, "CALL", "test.c", 30)

    index = LineMetadataIndex()
    for line in [20, 25, 30]:
        metadata = LineMetadata(
            file="test.c",
            line_number=line,
            codeblock=CodeblockContext(enclosing_function="main"),
            conditional=ConditionalContext(False, 0, [], []),
            calls=CallContext()
        )
        index.add(metadata)

    enricher = LineMetadataEnricher(call_graph, index)
    enricher.enrich_all()

    # All lines in "main" should have all three function calls
    for line in [20, 25, 30]:
        enriched = index.get("test.c", line)
        assert set(enriched.calls.calls_functions) == {"foo", "bar", "baz"}


def test_enricher_no_calls():
    """Test enriching codeblock with no calls."""
    call_graph = CallGraph()
    index = LineMetadataIndex()

    metadata = LineMetadata(
        file="test.c",
        line_number=10,
        codeblock=CodeblockContext(enclosing_function="empty"),
        conditional=ConditionalContext(False, 0, [], []),
        calls=CallContext()
    )
    index.add(metadata)

    enricher = LineMetadataEnricher(call_graph, index)
    enricher.enrich_all()

    enriched = index.get("test.c", 10)
    assert enriched.calls.calls_functions == []
    assert enriched.calls.calls_routines == []
    assert enriched.calls.invokes_macros == []


def test_enricher_indirect_call_skipped():
    """Test that indirect calls (no target) are skipped."""
    call_graph = CallGraph()
    call_graph.add_edge(
        source="main",
        target=None,  # Indirect call
        call_type=CallType.CALL,
        instruction="CALL",
        file="test.c",
        line=20,
        is_indirect=True
    )

    index = LineMetadataIndex()
    metadata = LineMetadata(
        file="test.c",
        line_number=20,
        codeblock=CodeblockContext(enclosing_function="main"),
        conditional=ConditionalContext(False, 0, [], []),
        calls=CallContext()
    )
    index.add(metadata)

    enricher = LineMetadataEnricher(call_graph, index)
    enricher.enrich_all()

    enriched = index.get("test.c", 20)
    # Should remain empty since indirect call has no target
    assert enriched.calls.calls_functions == []
