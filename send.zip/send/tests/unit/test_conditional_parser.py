"""Unit tests for conditional directive parser."""

import pytest
from conditional_parser import ConditionalParser
from models.conditional_assembly import (
    AIFDirective,
    AGODirective,
    ANOPDirective
)


def test_parse_aif_directive():
    """Test parsing AIF directive."""
    parser = ConditionalParser()
    line = "         AIF   (&VAR EQ 1).LABEL1"
    line_number = 10

    result = parser.parse_aif(line, line_number)

    assert result is not None
    assert isinstance(result, AIFDirective)
    assert result.condition == "&VAR EQ 1"
    assert result.target == ".LABEL1"
    assert result.source_line == 10


def test_parse_ago_directive():
    """Test parsing AGO directive."""
    parser = ConditionalParser()
    line = "         AGO   .DONE"
    line_number = 20

    result = parser.parse_ago(line, line_number)

    assert result is not None
    assert isinstance(result, AGODirective)
    assert result.target == ".DONE"
    assert result.source_line == 20


def test_parse_anop_directive():
    """Test parsing ANOP directive."""
    parser = ConditionalParser()
    line = ".START   ANOP"
    line_number = 5

    result = parser.parse_anop(line, line_number)

    assert result is not None
    assert isinstance(result, ANOPDirective)
    assert result.label == ".START"
    assert result.source_line == 5


def test_parse_seta_directive():
    """Test parsing SETA directive."""
    parser = ConditionalParser()
    line = "&COUNT   SETA  5"
    line_number = 15

    result = parser.parse_seta(line, line_number)

    assert result is not None
    assert isinstance(result, dict)
    assert result["symbol"] == "&COUNT"
    assert result["value"] == 5
    assert result["type"] == "arithmetic"


def test_is_conditional_directive():
    """Test identifying conditional directives vs regular assembly."""
    parser = ConditionalParser()

    # Test conditional directives (should return True)
    assert parser.is_conditional_directive("         AIF   (&VAR EQ 1).LABEL1") is True
    assert parser.is_conditional_directive("         AGO   .DONE") is True
    assert parser.is_conditional_directive(".START   ANOP") is True
    assert parser.is_conditional_directive("&COUNT   SETA  5") is True
    assert parser.is_conditional_directive("&FLAG    SETB  1") is True
    assert parser.is_conditional_directive("&NAME    SETC  'TEST'") is True

    # Test regular assembly instructions (should return False)
    assert parser.is_conditional_directive("LABEL    DS    0H") is False
    assert parser.is_conditional_directive("         L     R1,DATA") is False
    assert parser.is_conditional_directive("         BR    R14") is False
    assert parser.is_conditional_directive("") is False
    assert parser.is_conditional_directive("*        COMMENT LINE") is False


def test_parse_aif_case_insensitive():
    """Test that AIF parsing is case-insensitive."""
    parser = ConditionalParser()
    line = "         aif   (&VAR EQ 1).LABEL1"
    line_number = 10

    result = parser.parse_aif(line, line_number)

    assert result is not None
    assert result.condition == "&VAR EQ 1"
    assert result.target == ".LABEL1"


def test_parse_ago_case_insensitive():
    """Test that AGO parsing is case-insensitive."""
    parser = ConditionalParser()
    line = "         ago   .DONE"
    line_number = 20

    result = parser.parse_ago(line, line_number)

    assert result is not None
    assert result.target == ".DONE"


def test_parse_anop_case_insensitive():
    """Test that ANOP parsing is case-insensitive."""
    parser = ConditionalParser()
    line = ".START   anop"
    line_number = 5

    result = parser.parse_anop(line, line_number)

    assert result is not None
    assert result.label == ".START"


def test_parse_seta_case_insensitive():
    """Test that SETA parsing is case-insensitive."""
    parser = ConditionalParser()
    line = "&COUNT   seta  5"
    line_number = 15

    result = parser.parse_seta(line, line_number)

    assert result is not None
    assert result["symbol"] == "&COUNT"
    assert result["value"] == 5


def test_parse_seta_expression():
    """Test parsing SETA with expression (non-integer value)."""
    parser = ConditionalParser()
    line = "&COUNT   SETA  &VAR+1"
    line_number = 15

    result = parser.parse_seta(line, line_number)

    assert result is not None
    assert result["symbol"] == "&COUNT"
    assert result["value"] == "&VAR+1"  # Stored as expression string
    assert result["type"] == "arithmetic"


def test_parse_setb_directive():
    """Test parsing SETB directive with various boolean values."""
    parser = ConditionalParser()

    # Test with 1 (True)
    result = parser.parse_setb("&FLAG    SETB  1", 10)
    assert result is not None
    assert result["symbol"] == "&FLAG"
    assert result["value"] is True
    assert result["type"] == "boolean"

    # Test with 0 (False)
    result = parser.parse_setb("&FLAG    SETB  0", 10)
    assert result is not None
    assert result["value"] is False

    # Test with T (True)
    result = parser.parse_setb("&FLAG    SETB  T", 10)
    assert result is not None
    assert result["value"] is True

    # Test with TRUE (True)
    result = parser.parse_setb("&FLAG    SETB  TRUE", 10)
    assert result is not None
    assert result["value"] is True

    # Test with anything else (False)
    result = parser.parse_setb("&FLAG    SETB  &OTHER", 10)
    assert result is not None
    assert result["value"] is False


def test_parse_setc_directive():
    """Test parsing SETC directive."""
    parser = ConditionalParser()
    line = "&NAME    SETC  'TEST'"
    line_number = 25

    result = parser.parse_setc(line, line_number)

    assert result is not None
    assert isinstance(result, dict)
    assert result["symbol"] == "&NAME"
    assert result["value"] == "TEST"  # Quotes stripped
    assert result["type"] == "character"


def test_parse_setc_without_quotes():
    """Test parsing SETC directive without quotes."""
    parser = ConditionalParser()
    line = "&NAME    SETC  TEST"
    line_number = 25

    result = parser.parse_setc(line, line_number)

    assert result is not None
    assert result["symbol"] == "&NAME"
    assert result["value"] == "TEST"
    assert result["type"] == "character"


def test_parse_aif_invalid():
    """Test parsing invalid AIF directive returns None."""
    parser = ConditionalParser()

    # Invalid lines
    assert parser.parse_aif("         L     R1,DATA", 10) is None
    assert parser.parse_aif("", 10) is None


def test_parse_ago_invalid():
    """Test parsing invalid AGO directive returns None."""
    parser = ConditionalParser()

    # Invalid lines
    assert parser.parse_ago("         L     R1,DATA", 10) is None
    assert parser.parse_ago("", 10) is None


def test_parse_anop_invalid():
    """Test parsing invalid ANOP directive returns None."""
    parser = ConditionalParser()

    # Invalid lines
    assert parser.parse_anop("         L     R1,DATA", 10) is None
    assert parser.parse_anop("", 10) is None


def test_parse_seta_invalid():
    """Test parsing invalid SETA directive returns None."""
    parser = ConditionalParser()

    # Invalid lines
    assert parser.parse_seta("         L     R1,DATA", 10) is None
    assert parser.parse_seta("", 10) is None
