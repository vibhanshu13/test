"""Tests for file analysis cache manager."""
import json
import os
from pathlib import Path
from unittest.mock import patch, mock_open
from cache.file_cache import FileAnalysisCache


def test_cache_stores_and_retrieves_analysis(tmp_path):
    """Test cache can store and retrieve analysis results."""
    cache = FileAnalysisCache(cache_dir=tmp_path)

    file_path = "module1.asm"
    file_content = "ENTRY MAIN\n"
    analysis_data = {
        "exports": ["MAIN"],
        "imports": [],
        "symbols": {"MAIN": {"type": "entry"}}
    }

    # Store
    cache.store(file_path, file_content, analysis_data)

    # Retrieve
    result = cache.retrieve(file_path, file_content)

    assert result is not None
    assert result["exports"] == ["MAIN"]
    assert result["symbols"]["MAIN"]["type"] == "entry"


def test_cache_invalidates_on_content_change(tmp_path):
    """Test cache invalidates when file content changes."""
    cache = FileAnalysisCache(cache_dir=tmp_path)

    file_path = "module1.asm"
    old_content = "ENTRY MAIN\n"
    new_content = "ENTRY MAIN\nENTRY HELPER\n"

    analysis_data = {"exports": ["MAIN"]}
    cache.store(file_path, old_content, analysis_data)

    # Content changed - should return None
    result = cache.retrieve(file_path, new_content)

    assert result is None


def test_cache_miss_returns_none(tmp_path):
    """Test cache returns None for uncached file."""
    cache = FileAnalysisCache(cache_dir=tmp_path)

    result = cache.retrieve("nonexistent.asm", "content")

    assert result is None


def test_cache_store_handles_write_errors_gracefully(tmp_path):
    """Test cache.store() handles file write errors without crashing."""
    cache = FileAnalysisCache(cache_dir=tmp_path)

    file_path = "module1.asm"
    file_content = "ENTRY MAIN\n"
    analysis_data = {"exports": ["MAIN"]}

    # Mock open() to raise PermissionError
    with patch("builtins.open", side_effect=PermissionError("Permission denied")):
        # Should not raise exception - should silently fail
        cache.store(file_path, file_content, analysis_data)

    # Verify no exception was raised by reaching this point
    assert True


def test_cache_store_handles_ioerror_gracefully(tmp_path):
    """Test cache.store() handles IOError (disk full) without crashing."""
    cache = FileAnalysisCache(cache_dir=tmp_path)

    file_path = "module2.asm"
    file_content = "ENTRY FUNC\n"
    analysis_data = {"exports": ["FUNC"]}

    # Mock open() to raise IOError (simulating disk full)
    with patch("builtins.open", side_effect=IOError("No space left on device")):
        # Should not raise exception - should silently fail
        cache.store(file_path, file_content, analysis_data)

    # Verify no exception was raised by reaching this point
    assert True


def test_cache_store_handles_oserror_gracefully(tmp_path):
    """Test cache.store() handles OSError without crashing."""
    cache = FileAnalysisCache(cache_dir=tmp_path)

    file_path = "module3.asm"
    file_content = "ENTRY HELPER\n"
    analysis_data = {"exports": ["HELPER"]}

    # Mock open() to raise OSError
    with patch("builtins.open", side_effect=OSError("Read-only file system")):
        # Should not raise exception - should silently fail
        cache.store(file_path, file_content, analysis_data)

    # Verify no exception was raised by reaching this point
    assert True
