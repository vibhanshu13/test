"""Tests for line metadata models."""

from models.line_metadata import ConditionalContext, CodeblockContext, CallContext, LineMetadata, LineMetadataIndex


def test_conditional_context_creation():
    """Test ConditionalContext tracks conditional state."""
    ctx = ConditionalContext(
        is_conditional=True,
        depth=2,
        active_conditions=["if (x > 0)", "while (y < 10)"],
        condition_types=["if", "while"]
    )

    assert ctx.is_conditional is True
    assert ctx.depth == 2
    assert len(ctx.active_conditions) == 2
    assert ctx.condition_types == ["if", "while"]


def test_conditional_context_no_conditions():
    """Test ConditionalContext with no active conditions."""
    ctx = ConditionalContext(
        is_conditional=False,
        depth=0,
        active_conditions=[],
        condition_types=[]
    )

    assert ctx.is_conditional is False
    assert ctx.depth == 0
    assert len(ctx.active_conditions) == 0


def test_codeblock_context_c_function():
    """Test CodeblockContext for C/C++ function."""
    ctx = CodeblockContext(
        enclosing_function="main",
        enclosing_section=None,
        enclosing_routine=None,
        in_executable_block=True
    )

    assert ctx.enclosing_function == "main"
    assert ctx.enclosing_section is None
    assert ctx.in_executable_block is True


def test_codeblock_context_asm_section():
    """Test CodeblockContext for ASM section."""
    ctx = CodeblockContext(
        enclosing_function=None,
        enclosing_section="MAINSECT",
        enclosing_routine="INIT",
        in_executable_block=True
    )

    assert ctx.enclosing_section == "MAINSECT"
    assert ctx.enclosing_routine == "INIT"
    assert ctx.in_executable_block is True


def test_call_context_creation():
    """Test CallContext with mixed calls."""
    ctx = CallContext(
        calls_functions=["malloc", "printf"],
        calls_routines=["SUBRTN1"],
        invokes_macros=["ENTC"]
    )

    assert len(ctx.calls_functions) == 2
    assert len(ctx.calls_routines) == 1
    assert ctx.invokes_macros == ["ENTC"]


def test_line_metadata_creation():
    """Test LineMetadata with full context."""
    codeblock = CodeblockContext(
        enclosing_function="main",
        in_executable_block=True
    )
    conditional = ConditionalContext(
        is_conditional=True,
        depth=1,
        active_conditions=["if (x > 0)"],
        condition_types=["if"]
    )
    calls = CallContext(calls_functions=["helper"])

    metadata = LineMetadata(
        file="test.c",
        line_number=42,
        codeblock=codeblock,
        conditional=conditional,
        calls=calls
    )

    assert metadata.file == "test.c"
    assert metadata.line_number == 42
    assert metadata.codeblock.enclosing_function == "main"
    assert metadata.conditional.is_conditional is True
    assert metadata.calls.calls_functions == ["helper"]


def test_line_metadata_to_dict():
    """Test LineMetadata serialization."""
    codeblock = CodeblockContext(
        enclosing_section="MAINSECT",
        in_executable_block=True
    )
    conditional = ConditionalContext(
        is_conditional=False,
        depth=0,
        active_conditions=[],
        condition_types=[]
    )
    calls = CallContext()

    metadata = LineMetadata(
        file="app.asm",
        line_number=100,
        codeblock=codeblock,
        conditional=conditional,
        calls=calls
    )

    result = metadata.to_dict()

    assert result["file"] == "app.asm"
    assert result["line"] == 100
    assert result["codeblock"]["enclosing_section"] == "MAINSECT"
    assert result["conditional"]["is_conditional"] is False
    assert result["calls"]["calls_routines"] == []


def test_line_metadata_index_add_and_get():
    """Test adding and retrieving metadata."""
    index = LineMetadataIndex()

    metadata = LineMetadata(
        file="test.c",
        line_number=10,
        codeblock=CodeblockContext(enclosing_function="foo"),
        conditional=ConditionalContext(False, 0, [], []),
        calls=CallContext()
    )

    index.add(metadata)
    retrieved = index.get("test.c", 10)

    assert retrieved is not None
    assert retrieved.line_number == 10
    assert retrieved.codeblock.enclosing_function == "foo"


def test_line_metadata_index_get_nonexistent():
    """Test getting non-existent line."""
    index = LineMetadataIndex()
    result = index.get("missing.c", 999)
    assert result is None


def test_line_metadata_index_get_lines_in_function():
    """Test querying lines by function."""
    index = LineMetadataIndex()

    # Add lines in function "main"
    for line in [10, 15, 20]:
        index.add(LineMetadata(
            file="test.c",
            line_number=line,
            codeblock=CodeblockContext(enclosing_function="main"),
            conditional=ConditionalContext(False, 0, [], []),
            calls=CallContext()
        ))

    # Add line in different function
    index.add(LineMetadata(
        file="test.c",
        line_number=50,
        codeblock=CodeblockContext(enclosing_function="helper"),
        conditional=ConditionalContext(False, 0, [], []),
        calls=CallContext()
    ))

    main_lines = index.get_lines_in_function("main")
    assert len(main_lines) == 3
    assert all(m.codeblock.enclosing_function == "main" for m in main_lines)


def test_line_metadata_index_get_conditional_lines():
    """Test querying conditional lines."""
    index = LineMetadataIndex()

    # Add conditional line
    index.add(LineMetadata(
        file="test.c",
        line_number=10,
        codeblock=CodeblockContext(),
        conditional=ConditionalContext(True, 1, ["if (x)"], ["if"]),
        calls=CallContext()
    ))

    # Add non-conditional line
    index.add(LineMetadata(
        file="test.c",
        line_number=20,
        codeblock=CodeblockContext(),
        conditional=ConditionalContext(False, 0, [], []),
        calls=CallContext()
    ))

    conditional_lines = index.get_conditional_lines()
    assert len(conditional_lines) == 1
    assert conditional_lines[0].line_number == 10
