import pytest
from models.macro_expansion import (
    ParameterSubstitution,
    ExpandedInstruction,
    MacroProvenance,
    ExpansionResult,
    ExpansionError
)


def test_parameter_substitution_creation():
    """Test parameter substitution tracking"""
    sub = ParameterSubstitution(
        param="&RC",
        value="4",
        position="operand2"
    )

    assert sub.param == "&RC"
    assert sub.value == "4"
    assert sub.position == "operand2"


def test_expanded_instruction_basic():
    """Test expanded instruction without substitutions"""
    instr = ExpandedInstruction(
        instruction="LTR R15,R15",
        label=None,
        parameter_substitutions=[],
        provenance=None
    )

    assert instr.instruction == "LTR R15,R15"
    assert instr.label is None
    assert len(instr.parameter_substitutions) == 0


def test_expanded_instruction_with_substitutions():
    """Test expanded instruction with parameter substitutions"""
    subs = [
        ParameterSubstitution("&RC", "4", "operand2"),
        ParameterSubstitution("&ERROR", "BADCARD", "operand1")
    ]

    instr = ExpandedInstruction(
        instruction="C R15,=F'4'",
        label=None,
        parameter_substitutions=subs,
        provenance=None
    )

    assert len(instr.parameter_substitutions) == 2
    assert instr.parameter_substitutions[0].param == "&RC"


def test_macro_provenance_simple():
    """Test simple macro provenance"""
    prov = MacroProvenance(
        invocation_file="CARDVAL.asm",
        invocation_line=42,
        invocation_macro="CHKRC",
        definition_file="MACROS.asm",
        definition_line=12,
        nested_expansion=None
    )

    assert prov.invocation_file == "CARDVAL.asm"
    assert prov.invocation_line == 42
    assert prov.nested_expansion is None


def test_expansion_result_success():
    """Test successful expansion result"""
    result = ExpansionResult(
        expansion_id="expansion_1",
        invocation="CHKRC RC=4,ERROR=BADCARD",
        invocation_file="CARDVAL.asm",
        invocation_line=42,
        macro_name="CHKRC",
        definition_file="MACROS.asm",
        definition_line_start=12,
        definition_line_end=21,
        expansion_status="success",
        parameters={"&RC": "4", "&ERROR": "BADCARD", "&LABEL": ""},
        expanded_instructions=[],
        error=None
    )

    assert result.expansion_status == "success"
    assert result.error is None
    assert result.parameters["&RC"] == "4"


def test_expansion_error():
    """Test expansion error tracking"""
    error = ExpansionError(
        macro_name="UNKNOWN_MACRO",
        error_type="not_found",
        message="Macro definition not found",
        location_file="CARDVAL.asm",
        location_line=55
    )

    assert error.error_type == "not_found"
    assert error.macro_name == "UNKNOWN_MACRO"


def test_expansion_result_to_dict():
    """Test serialization of expansion result"""
    instr = ExpandedInstruction(
        instruction="LTR R15,R15",
        label=None,
        parameter_substitutions=[],
        provenance=None
    )

    result = ExpansionResult(
        expansion_id="expansion_1",
        invocation="SETRC 0",
        invocation_file="test.asm",
        invocation_line=10,
        macro_name="SETRC",
        definition_file="MACROS.asm",
        definition_line_start=44,
        definition_line_end=47,
        expansion_status="success",
        parameters={"&RC": "0"},
        expanded_instructions=[instr],
        error=None
    )

    result_dict = result.to_dict()

    assert result_dict["expansion_id"] == "expansion_1"
    assert result_dict["expansion_status"] == "success"
    assert "expanded_code" in result_dict
    assert len(result_dict["expanded_code"]) == 1
