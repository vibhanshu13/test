"""Unit tests for DSECT base register context tracking (Phase 0).

Tests cover:
  - DSECT field offset accumulation
  - CE-slot resolution (direct and transitive)
  - ORG directive handling
  - DROP/reload per-line USING snapshots
  - Edge enrichment with access_identity
"""

import pytest
from pathlib import Path
from models.analysis_context import AnalysisContext
from models.provenance import StatementProvenance
from tokenizer import ParsedLine
from passes.variable_lineage_builder import VariableLineageBuilder


def _line(label, opcode, operands, file="test.asm", line_no=1):
    """Helper to create a ParsedLine with minimal provenance."""
    return ParsedLine(
        label=label,
        opcode=opcode,
        operands=operands if isinstance(operands, list) else [operands] if operands else [],
        comment=None,
        provenance=StatementProvenance(
            statement_id=f"S{line_no:03d}",
            original_file=file,
            original_line=line_no,
        ),
    )


def _build(lines):
    """Run the lineage builder on a list of ParsedLines, return (builder, context, graph)."""
    context = AnalysisContext(file_path=Path("test.asm"))
    builder = VariableLineageBuilder()
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")
    return builder, context, graph


# ---------------------------------------------------------------------------
# 1. DSECT field offset accumulation
# ---------------------------------------------------------------------------

class TestDsectFieldOffsets:

    def test_basic_offset_accumulation(self):
        """Fields in a DSECT should have cumulative byte offsets."""
        lines = [
            _line("MYDSECT", "DSECT", [], line_no=1),
            _line("FLD1", "DS", ["CL1"], line_no=2),      # offset 0, len 1
            _line("FLD2", "DS", ["CL15"], line_no=3),      # offset 1, len 15
            _line("FLD3", "DS", ["CL1"], line_no=4),       # offset 16, len 1
            _line("FLD4", "DS", ["CL8"], line_no=5),       # offset 17, len 8
        ]
        builder, ctx, graph = _build(lines)

        offsets = builder.dsect_field_offsets
        assert "MYDSECT" in offsets
        assert offsets["MYDSECT"]["FLD1"] == (0, 1)
        assert offsets["MYDSECT"]["FLD2"] == (1, 15)
        assert offsets["MYDSECT"]["FLD3"] == (16, 1)
        assert offsets["MYDSECT"]["FLD4"] == (17, 8)

    def test_halfword_and_fullword_sizes(self):
        """DS H = 2 bytes, DS F = 4 bytes, DS D = 8 bytes."""
        lines = [
            _line("MYDSECT", "DSECT", [], line_no=1),
            _line("FHALF", "DS", ["H"], line_no=2),        # offset 0, len 2
            _line("FFULL", "DS", ["F"], line_no=3),         # offset 2, len 4
            _line("FDBL", "DS", ["D"], line_no=4),          # offset 6, len 8
        ]
        builder, ctx, graph = _build(lines)

        offsets = builder.dsect_field_offsets["MYDSECT"]
        assert offsets["FHALF"] == (0, 2)
        assert offsets["FFULL"] == (2, 4)
        assert offsets["FDBL"] == (6, 8)

    def test_multiple_dsects(self):
        """Each DSECT has independent offset tracking."""
        lines = [
            _line("DSECT1", "DSECT", [], line_no=1),
            _line("D1F1", "DS", ["CL4"], line_no=2),
            _line("D1F2", "DS", ["CL8"], line_no=3),
            _line("DSECT2", "DSECT", [], line_no=4),
            _line("D2F1", "DS", ["CL1"], line_no=5),
            _line("D2F2", "DS", ["CL2"], line_no=6),
        ]
        builder, ctx, graph = _build(lines)

        assert builder.dsect_field_offsets["DSECT1"]["D1F1"] == (0, 4)
        assert builder.dsect_field_offsets["DSECT1"]["D1F2"] == (4, 8)
        assert builder.dsect_field_offsets["DSECT2"]["D2F1"] == (0, 1)
        assert builder.dsect_field_offsets["DSECT2"]["D2F2"] == (1, 2)

    def test_csect_stops_dsect_tracking(self):
        """CSECT should stop DSECT offset tracking."""
        lines = [
            _line("MYDSECT", "DSECT", [], line_no=1),
            _line("FLD1", "DS", ["CL4"], line_no=2),
            _line("MYCSECT", "CSECT", [], line_no=3),
            _line("FLD2", "DS", ["CL4"], line_no=4),   # inside CSECT, not tracked in DSECT
        ]
        builder, ctx, graph = _build(lines)

        assert "FLD1" in builder.dsect_field_offsets["MYDSECT"]
        assert "FLD2" not in builder.dsect_field_offsets.get("MYDSECT", {})

    def test_offsets_stored_in_context(self):
        """dsect_field_offsets should be in context metadata for blueprint emission."""
        lines = [
            _line("MYDSECT", "DSECT", [], line_no=1),
            _line("FLD1", "DS", ["CL1"], line_no=2),
        ]
        builder, ctx, graph = _build(lines)

        ctx_offsets = ctx.get_metadata("dsect_field_offsets")
        assert ctx_offsets is not None
        assert "MYDSECT" in ctx_offsets
        assert ctx_offsets["MYDSECT"]["FLD1"] == (0, 1)


# ---------------------------------------------------------------------------
# 2. ORG directive handling
# ---------------------------------------------------------------------------

class TestOrgHandling:

    def test_org_with_label_resets_offset(self):
        """ORG LABEL should reset offset to that label's position."""
        lines = [
            _line("MYDSECT", "DSECT", [], line_no=1),
            _line("FLD1", "DS", ["CL4"], line_no=2),       # offset 0, len 4
            _line("FLD2", "DS", ["CL8"], line_no=3),        # offset 4, len 8
            _line(None, "ORG", ["FLD1"], line_no=4),        # reset to offset 0
            _line("OVERLAY", "DS", ["CL2"], line_no=5),     # offset 0, len 2 (overlays FLD1)
        ]
        builder, ctx, graph = _build(lines)

        offsets = builder.dsect_field_offsets["MYDSECT"]
        assert offsets["FLD1"] == (0, 4)
        assert offsets["FLD2"] == (4, 8)
        assert offsets["OVERLAY"] == (0, 2)   # overlays FLD1

    def test_org_bare_resets_to_high_water(self):
        """ORG with no operand should reset to high-water mark."""
        lines = [
            _line("MYDSECT", "DSECT", [], line_no=1),
            _line("FLD1", "DS", ["CL4"], line_no=2),       # offset 0, len 4
            _line("FLD2", "DS", ["CL8"], line_no=3),        # offset 4, len 8 → HWM = 12
            _line(None, "ORG", ["FLD1"], line_no=4),        # reset to offset 0
            _line("OVERLAY", "DS", ["CL2"], line_no=5),     # offset 0, len 2
            _line(None, "ORG", [], line_no=6),              # reset to HWM = 12
            _line("AFTER", "DS", ["CL1"], line_no=7),       # offset 12, len 1
        ]
        builder, ctx, graph = _build(lines)

        offsets = builder.dsect_field_offsets["MYDSECT"]
        assert offsets["AFTER"] == (12, 1)


# ---------------------------------------------------------------------------
# 3. CE-slot resolution
# ---------------------------------------------------------------------------

class TestCeSlotResolution:

    def test_direct_ce1cr_load(self):
        """L R5,CE1CR5 should resolve R5 → CE1CR5."""
        builder = VariableLineageBuilder()
        builder.register_sources["R5"] = {("CE1CR5", "memory")}

        result = builder._resolve_ce_slot_for_register("R5")
        assert result == "CE1CR5"

    def test_transitive_via_lr(self):
        """LR R3,R5 where R5←CE1CR5 should resolve R3 → CE1CR5."""
        builder = VariableLineageBuilder()
        builder.register_sources["R5"] = {("CE1CR5", "memory")}
        builder.register_sources["R3"] = {("R5", "register")}

        result = builder._resolve_ce_slot_for_register("R3")
        assert result == "CE1CR5"

    def test_no_ce_slot(self):
        """Register loaded from non-CE source should return None."""
        builder = VariableLineageBuilder()
        builder.register_sources["R5"] = {("SOMEADDR", "memory")}

        result = builder._resolve_ce_slot_for_register("R5")
        assert result is None

    def test_unknown_register(self):
        """Register with no sources should return None."""
        builder = VariableLineageBuilder()
        result = builder._resolve_ce_slot_for_register("R7")
        assert result is None

    def test_deep_transitive_chain(self):
        """R1←R2←R3←R4←CE1CR7 should resolve through 4 hops."""
        builder = VariableLineageBuilder()
        builder.register_sources["R4"] = {("CE1CR7", "memory")}
        builder.register_sources["R3"] = {("R4", "register")}
        builder.register_sources["R2"] = {("R3", "register")}
        builder.register_sources["R1"] = {("R2", "register")}

        result = builder._resolve_ce_slot_for_register("R1")
        assert result == "CE1CR7"

    def test_circular_chain_does_not_hang(self):
        """Circular register chain should return None, not loop forever."""
        builder = VariableLineageBuilder()
        builder.register_sources["R1"] = {("R2", "register")}
        builder.register_sources["R2"] = {("R1", "register")}

        result = builder._resolve_ce_slot_for_register("R1")
        assert result is None


# ---------------------------------------------------------------------------
# 4. DSECT context resolution
# ---------------------------------------------------------------------------

class TestDsectContextResolution:

    def test_full_context_resolution(self):
        """_resolve_dsect_context should resolve dsect, ce_slot, field_offset, access_identity."""
        builder = VariableLineageBuilder()
        builder.using_map["R5"] = "LG1G1"
        builder.register_sources["R5"] = {("CE1CR5", "memory")}
        builder.dsect_field_offsets["LG1G1"] = {"LG1OSI": (17, 1)}

        ctx = builder._resolve_dsect_context("LG1OSI", base_reg="R5")
        assert ctx["dsect"] == "LG1G1"
        assert ctx["base_reg"] == "R5"
        assert ctx["ce_slot"] == "CE1CR5"
        assert ctx["field_offset"] == 17
        assert ctx["access_identity"] == "CE1CR5:17"

    def test_context_without_ce_slot(self):
        """Missing CE-slot should still produce dsect and field_offset, but no access_identity."""
        builder = VariableLineageBuilder()
        builder.using_map["R5"] = "LG1G1"
        builder.register_sources["R5"] = {("HEAPADDR", "memory")}
        builder.dsect_field_offsets["LG1G1"] = {"LG1OSI": (17, 1)}

        ctx = builder._resolve_dsect_context("LG1OSI", base_reg="R5")
        assert ctx["dsect"] == "LG1G1"
        assert ctx["ce_slot"] is None
        assert ctx["field_offset"] == 17
        assert ctx["access_identity"] is None

    def test_auto_detect_base_reg(self):
        """When base_reg is not provided, find it by matching field to DSECT."""
        builder = VariableLineageBuilder()
        builder.using_map["R5"] = "LG1G1"
        builder.register_sources["R5"] = {("CE1CR5", "memory")}
        builder.dsect_field_offsets["LG1G1"] = {"LG1OSI": (17, 1)}

        ctx = builder._resolve_dsect_context("LG1OSI")  # no base_reg
        assert ctx["dsect"] == "LG1G1"
        assert ctx["base_reg"] == "R5"
        assert ctx["ce_slot"] == "CE1CR5"


# ---------------------------------------------------------------------------
# 5. Per-line USING snapshots + edge enrichment
# ---------------------------------------------------------------------------

class TestUsingSnapshotsAndEdgeEnrichment:

    def test_using_creates_snapshot(self):
        """USING directive should create a USING snapshot in context."""
        lines = [
            _line(None, "USING", ["MYDSECT", "R5"], line_no=10),
        ]
        builder, ctx, graph = _build(lines)

        snaps = ctx.get_metadata("line_using_snapshots")
        assert snaps is not None
        assert "10" in snaps
        assert snaps["10"]["active_usings"]["R5"] == "MYDSECT"

    def test_drop_updates_snapshot(self):
        """DROP should create a snapshot reflecting the removed USING."""
        lines = [
            _line(None, "USING", ["DSECT1", "R5"], line_no=10),
            _line(None, "USING", ["DSECT2", "R7"], line_no=11),
            _line(None, "DROP", ["R5"], line_no=20),
        ]
        builder, ctx, graph = _build(lines)

        snaps = ctx.get_metadata("line_using_snapshots")
        # After DROP R5, only R7→DSECT2 should remain
        snap_20 = snaps.get("20", {})
        usings = snap_20.get("active_usings", {})
        assert "R5" not in usings
        assert usings.get("R7") == "DSECT2"

    def test_register_load_updates_ce_slot_in_snapshot(self):
        """L R5,CE1CR5 after USING MYDSECT,R5 should produce CE-slot in snapshot."""
        lines = [
            _line("MYDSECT", "DSECT", [], line_no=1),
            _line("FLD1", "DS", ["CL4"], line_no=2),
            _line("MYCSECT", "CSECT", [], line_no=3),
            _line(None, "USING", ["MYDSECT", "R5"], line_no=10),
            _line(None, "L", ["R5", "CE1CR5"], line_no=11),
        ]
        builder, ctx, graph = _build(lines)

        snaps = ctx.get_metadata("line_using_snapshots")
        # Snapshot at line 11 (after L R5,CE1CR5) should have CE-slot
        snap_11 = snaps.get("11", {})
        ce_slots = snap_11.get("register_ce_slots", {})
        assert ce_slots.get("R5") == "CE1CR5"

    def test_edge_enrichment_with_dsect_context(self):
        """Edges for DSECT field accesses should get dsect + field_offset from node metadata."""
        lines = [
            _line("MYDSECT", "DSECT", [], line_no=1),
            _line("FLD1", "DS", ["CL4"], line_no=2),       # offset 0
            _line("FLD2", "DS", ["CL8"], line_no=3),        # offset 4
            _line("MYCSECT", "CSECT", [], line_no=4),
            _line(None, "USING", ["MYDSECT", "R5"], line_no=10),
            _line(None, "L", ["R5", "CE1CR5"], line_no=11),
            _line(None, "MVC", ["FLD2", "FLD1"], line_no=20),
        ]
        builder, ctx, graph = _build(lines)

        # Find edges that reference FLD2
        fld2_edges = [e for e in graph.edges if "FLD2" in e.source or "FLD2" in e.target]
        # At least the definition edge should have dsect context
        enriched = [e for e in graph.edges if e.dsect == "MYDSECT"]
        assert len(enriched) > 0, "Expected at least one edge enriched with DSECT context"

        # Check a definition edge for FLD2 has correct field_offset
        fld2_defs = [e for e in graph.edges if "FLD2" in e.source and e.relation == "define"]
        if fld2_defs:
            assert fld2_defs[0].field_offset == 4

    def test_access_identity_computed(self):
        """access_identity should be CE-slot:offset when both are available."""
        lines = [
            _line("MYDSECT", "DSECT", [], line_no=1),
            _line("FLD1", "DS", ["CL4"], line_no=2),
            _line("FLD2", "DS", ["CL1"], line_no=3),       # offset 4
            _line("MYCSECT", "CSECT", [], line_no=4),
            _line(None, "USING", ["MYDSECT", "R5"], line_no=10),
            _line(None, "L", ["R5", "CE1CR5"], line_no=11),
            _line(None, "CLI", ["FLD2", "C'Y'"], line_no=20),
        ]
        builder, ctx, graph = _build(lines)

        # Find edges with access_identity
        with_identity = [e for e in graph.edges if e.access_identity is not None]
        if with_identity:
            assert any(e.access_identity == "CE1CR5:4" for e in with_identity), \
                f"Expected CE1CR5:4, got {[e.access_identity for e in with_identity]}"


# ---------------------------------------------------------------------------
# 6. VariableEdge model serialization
# ---------------------------------------------------------------------------

class TestVariableEdgeSerialization:

    def test_new_fields_in_to_dict(self):
        """New DSECT fields should appear in to_dict() when set."""
        from models.variable_lineage import VariableEdge
        edge = VariableEdge(
            source="memory:LG1OSI",
            target="use:test:20",
            relation="use",
            file="test.asm",
            line=20,
            dsect="LG1G1",
            base_reg="R5",
            ce_slot="CE1CR5",
            field_offset=17,
            access_identity="CE1CR5:17",
        )
        d = edge.to_dict()
        assert d["dsect"] == "LG1G1"
        assert d["base_reg"] == "R5"
        assert d["ce_slot"] == "CE1CR5"
        assert d["field_offset"] == 17
        assert d["access_identity"] == "CE1CR5:17"

    def test_new_fields_omitted_when_none(self):
        """New DSECT fields should NOT appear in to_dict() when None."""
        from models.variable_lineage import VariableEdge
        edge = VariableEdge(
            source="memory:X",
            target="memory:Y",
            relation="assign",
            file="test.asm",
            line=1,
        )
        d = edge.to_dict()
        assert "dsect" not in d
        assert "base_reg" not in d
        assert "ce_slot" not in d
        assert "field_offset" not in d
        assert "access_identity" not in d

    def test_process_context_serialization(self):
        """process_context should serialize when set."""
        from models.variable_lineage import VariableEdge
        edge = VariableEdge(
            source="memory:X",
            target="memory:Y",
            relation="assign",
            file="test.asm",
            line=1,
            process_context=[{"discriminator": "LG1OSI", "constant": "LG#C400", "gate_type": "inclusive"}],
        )
        d = edge.to_dict()
        assert d["process_context"] == [{"discriminator": "LG1OSI", "constant": "LG#C400", "gate_type": "inclusive"}]
