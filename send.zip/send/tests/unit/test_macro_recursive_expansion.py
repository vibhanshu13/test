import pytest
from macro_expander import MacroExpander
from macro_library import MacroLibrary
from models.macro_definition import MacroDefinition, MacroParameter
from pathlib import Path


@pytest.fixture
def macro_library_with_nested():
    """Create library with nested macro calls"""
    lib = MacroLibrary()

    # Inner macro: SETRC
    setrc = MacroDefinition(
        name="SETRC",
        parameters=[MacroParameter("&RC", None, False)],
        body=["LA    R15,&RC", "BR    R14"],
        source_file=Path("MACROS.asm"),
        start_line=1,
        end_line=3,
        scope="global"
    )
    lib.add_macro(setrc)

    # Outer macro that calls SETRC
    wrapper = MacroDefinition(
        name="RETURN_OK",
        parameters=[],
        body=["SETRC 0"],
        source_file=Path("MACROS.asm"),
        start_line=5,
        end_line=7,
        scope="global"
    )
    lib.add_macro(wrapper)

    return lib


def test_recursive_expansion(macro_library_with_nested):
    """Test expanding macro that calls another macro"""
    expander = MacroExpander(macro_library_with_nested)

    result = expander.expand("RETURN_OK", macro_library_with_nested.get_macro("RETURN_OK"))

    # Should have expanded SETRC within RETURN_OK
    instructions = [i.instruction for i in result.expanded_instructions]
    assert "LA    R15,0" in instructions
    assert "BR    R14" in instructions


def test_nested_provenance(macro_library_with_nested):
    """Test that nested provenance is tracked"""
    expander = MacroExpander(macro_library_with_nested)

    result = expander.expand("RETURN_OK", macro_library_with_nested.get_macro("RETURN_OK"))

    # Check first instruction has nested provenance
    first_instr = result.expanded_instructions[0]
    assert first_instr.provenance is not None
    assert first_instr.provenance.invocation_macro == "RETURN_OK"
    assert first_instr.provenance.nested_expansion is not None
    assert first_instr.provenance.nested_expansion.invocation_macro == "SETRC"


def test_circular_detection():
    """Test detection of circular macro calls"""
    lib = MacroLibrary()

    # Macro A calls B
    macro_a = MacroDefinition(
        name="MACRO_A",
        parameters=[],
        body=["MACRO_B"],
        source_file=Path("test.asm"),
        start_line=1,
        end_line=2,
        scope="global"
    )
    lib.add_macro(macro_a)

    # Macro B calls A (circular!)
    macro_b = MacroDefinition(
        name="MACRO_B",
        parameters=[],
        body=["MACRO_A"],
        source_file=Path("test.asm"),
        start_line=4,
        end_line=5,
        scope="global"
    )
    lib.add_macro(macro_b)

    expander = MacroExpander(lib)
    result = expander.expand("MACRO_A", macro_a)

    # Should detect circular call and fail gracefully
    assert result.expansion_status == "failed"
    assert result.error is not None
    assert "circular" in result.error.message.lower()


def test_max_recursion_depth():
    """Test that max recursion depth is enforced"""
    lib = MacroLibrary()

    # Create chain of 60 macros
    for i in range(60):
        if i < 59:
            body = [f"MACRO_{i+1}"]
        else:
            body = ["NOP"]

        macro = MacroDefinition(
            name=f"MACRO_{i}",
            parameters=[],
            body=body,
            source_file=Path("test.asm"),
            start_line=i*3+1,
            end_line=i*3+2,
            scope="global"
        )
        lib.add_macro(macro)

    expander = MacroExpander(lib)
    result = expander.expand("MACRO_0", lib.get_macro("MACRO_0"))

    # Should hit max depth (50) and fail
    assert result.expansion_status == "failed"
    assert "depth" in result.error.message.lower()


def test_system_macro_no_expansion(macro_library_with_nested):
    """Test that unknown macros are left unexpanded"""
    lib = macro_library_with_nested

    # Macro that calls unknown system macro
    test_macro = MacroDefinition(
        name="TEST_SYS",
        parameters=[],
        body=["TODEC", "NOP"],
        source_file=Path("test.asm"),
        start_line=1,
        end_line=3,
        scope="global"
    )
    lib.add_macro(test_macro)

    expander = MacroExpander(lib)
    result = expander.expand("TEST_SYS", test_macro)

    # TODEC should remain as-is (no definition)
    instructions = [i.instruction for i in result.expanded_instructions]
    assert "TODEC" in instructions
    assert "NOP" in instructions
