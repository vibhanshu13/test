"""Tests for file dependency serialization."""
import json
from models.file_dependency import (
    DependencyType, DependencyEvidence, FileDependencyNode,
    FileDependencyEdge, CircularDependency, FileDependencyGraph
)


def test_dependency_evidence_to_dict():
    """Test DependencyEvidence serialization to dict."""
    evidence = DependencyEvidence(
        dependency_type=DependencyType.COPY_INCLUDE,
        source_file="main.asm",
        source_line=10,
        details="COPY UTILS"
    )

    result = evidence.to_dict()

    assert result == {
        "dependency_type": "copy_include",
        "source_file": "main.asm",
        "source_line": 10,
        "details": "COPY UTILS"
    }


def test_file_dependency_node_to_dict():
    """Test FileDependencyNode serialization to dict."""
    node = FileDependencyNode(
        file_path="module.asm",
        is_external=False
    )

    result = node.to_dict()

    assert result == {
        "file_path": "module.asm",
        "is_external": False
    }


def test_file_dependency_edge_to_dict():
    """Test FileDependencyEdge serialization to dict."""
    evidence1 = DependencyEvidence(
        DependencyType.COPY_INCLUDE, "main.asm", 5, "COPY UTILS"
    )
    evidence2 = DependencyEvidence(
        DependencyType.SYMBOL_REFERENCE, "main.asm", 20, "EXTRN HELPER"
    )

    edge = FileDependencyEdge(
        from_file="main.asm",
        to_file="utils.asm",
        evidence=[evidence1, evidence2]
    )

    result = edge.to_dict()

    assert result["from_file"] == "main.asm"
    assert result["to_file"] == "utils.asm"
    assert len(result["evidence"]) == 2
    assert result["evidence"][0]["dependency_type"] == "copy_include"


def test_circular_dependency_to_dict():
    """Test CircularDependency serialization to dict."""
    cycle = CircularDependency(
        files=["a.asm", "b.asm", "a.asm"],
        cycle_type="simple"
    )

    result = cycle.to_dict()

    assert result == {
        "files": ["a.asm", "b.asm", "a.asm"],
        "cycle_type": "simple"
    }


def test_file_dependency_graph_to_dict():
    """Test FileDependencyGraph serialization to dict."""
    graph = FileDependencyGraph()

    graph.add_node("main.asm", is_external=False)
    graph.add_node("utils.asm", is_external=False)

    evidence = DependencyEvidence(
        DependencyType.COPY_INCLUDE, "main.asm", 10, "COPY UTILS"
    )
    graph.add_edge("main.asm", "utils.asm", evidence)

    cycle = CircularDependency(["a.asm", "b.asm", "a.asm"], "simple")
    graph.circular_dependencies.append(cycle)

    result = graph.to_dict()

    assert "nodes" in result
    assert "edges" in result
    assert "circular_dependencies" in result
    assert len(result["nodes"]) == 2
    assert len(result["edges"]) == 1
    assert len(result["circular_dependencies"]) == 1
