import pytest
from models.analysis_context import AnalysisContext
from models.provenance import StatementProvenance
from tokenizer import ParsedLine
from passes.variable_lineage_builder import VariableLineageBuilder
from models.c_family import CTranslationUnit, CAssignment, CDeclaration, CCall
from pathlib import Path


def test_expand_register_range_sequential():
    """Test expanding sequential register range R6-R9."""
    builder = VariableLineageBuilder()
    result = builder._expand_register_range("R6", "R9")
    assert result == ["R6", "R7", "R8", "R9"]


def test_expand_register_range_wraparound():
    """Test expanding range that wraps around R14->R15->R0->R1."""
    builder = VariableLineageBuilder()
    result = builder._expand_register_range("R14", "R2")
    assert result == ["R14", "R15", "R0", "R1", "R2"]


def test_expand_register_range_single():
    """Test single register range R6-R6."""
    builder = VariableLineageBuilder()
    result = builder._expand_register_range("R6", "R6")
    assert result == ["R6"]


def test_expand_register_range_with_equ_alias_end():
    """Test expanding range when end register is provided via EQU alias."""
    builder = VariableLineageBuilder()
    builder.equ_symbols["BASEREG"] = "12"
    result = builder._expand_register_range("R14", "BASEREG")
    assert result == ["R14", "R15", "R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9", "R10", "R11", "R12"]


def test_legacy_variants_do_not_create_dangling_register_alias():
    """Legacy variants should not emit malformed register ids like R11)."""
    builder = VariableLineageBuilder()
    memory_variants, register_aliases = builder._legacy_variants_for_memory_name("0(R11)")
    assert "R11)" not in memory_variants
    assert all(alias != ("R11", "R11)") for alias in register_aliases)


def test_expand_register_range_with_equ_alias_end():
    """Test expanding range when end register is provided via EQU alias."""
    builder = VariableLineageBuilder()
    builder.equ_symbols["BASEREG"] = "12"
    result = builder._expand_register_range("R14", "BASEREG")
    assert result == ["R14", "R15", "R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9", "R10", "R11", "R12"]


def test_variable_lineage_assembly_register_to_memory():
    context = AnalysisContext(file_path=Path("test.asm"))
    builder = VariableLineageBuilder()

    lines = [
        ParsedLine(
            label=None,
            opcode="LA",
            operands=["R1", "FOO"],
            comment=None,
            provenance=StatementProvenance(
                statement_id="S1",
                original_file="test.asm",
                original_line=1
            )
        ),
        ParsedLine(
            label=None,
            opcode="ST",
            operands=["R1", "BAR"],
            comment=None,
            provenance=StatementProvenance(
                statement_id="S2",
                original_file="test.asm",
                original_line=2
            )
        )
    ]

    builder.process_assembly(lines, context)

    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    edges = [e for e in graph.edges if e.relation == "assign"]
    assert any("FOO" in e.source and "BAR" in e.target for e in edges)


def test_variable_lineage_c_assignments():
    context = AnalysisContext(file_path=Path("test.c"))
    builder = VariableLineageBuilder()

    unit = CTranslationUnit(file_path=Path("test.c"), language="c")
    unit.assignments.append(CAssignment(
        target="b",
        target_kind="variable",
        sources=["a"],
        line=3,
        expression="b = a + 1",
        function="C_FUNC"
    ))

    builder.process_c_family(unit, context)

    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    edges = [e for e in graph.edges if e.relation == "assign"]
    assert any(e.source.endswith("::a") and e.target.endswith("::b") for e in edges)


def test_variable_lineage_c_pointer_assignments():
    context = AnalysisContext(file_path=Path("test.c"))
    builder = VariableLineageBuilder()

    unit = CTranslationUnit(file_path=Path("test.c"), language="c")
    unit.assignments.append(CAssignment(
        target="p",
        target_kind="memory",
        sources=["x"],
        line=5,
        expression="*p = x",
        function="C_FUNC"
    ))

    builder.process_c_family(unit, context)

    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    edges = [e for e in graph.edges if e.relation == "assign"]
    assert any(e.source.endswith("::x") and e.target.endswith("::p") for e in edges)


def test_variable_lineage_trace():
    context = AnalysisContext(file_path=Path("test.asm"))
    builder = VariableLineageBuilder()

    lines = [
        ParsedLine(
            label=None,
            opcode="LA",
            operands=["R1", "FOO"],
            comment=None,
            provenance=StatementProvenance(
                statement_id="S1",
                original_file="test.asm",
                original_line=1
            )
        ),
        ParsedLine(
            label=None,
            opcode="ST",
            operands=["R1", "BAR"],
            comment=None,
            provenance=StatementProvenance(
                statement_id="S2",
                original_file="test.asm",
                original_line=2
            )
        )
    ]

    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    trace = graph.trace("FOO", "memory")
    assert len(trace) > 0


def test_variable_lineage_trace_scope_filter():
    from models.variable_lineage import VariableLineageGraph
    graph = VariableLineageGraph()

    graph.add_assignment("a", "variable", "b", "variable", "test.c", 1, "b=a", scope="FUNC1")
    graph.add_assignment("a", "variable", "c", "variable", "test.c", 2, "c=a", scope="FUNC2")

    trace = graph.trace("a", "variable", scope="FUNC1")
    assert all(edge.scope == "FUNC1" for edge in trace if edge.scope)


def test_variable_lineage_c_alias_tracking():
    context = AnalysisContext(file_path=Path("test.c"))
    builder = VariableLineageBuilder()

    unit = CTranslationUnit(file_path=Path("test.c"), language="c")
    unit.assignments.append(CAssignment(
        target="p",
        target_kind="variable",
        sources=["x"],
        line=1,
        expression="p = &x",
        function="C_FUNC"
    ))
    unit.assignments.append(CAssignment(
        target="y",
        target_kind="variable",
        sources=["p"],
        line=2,
        expression="y = p",
        function="C_FUNC"
    ))

    builder.process_c_family(unit, context)
    graph = context.get_metadata("variable_lineage")

    edges = [e for e in graph.edges if e.relation == "assign"]
    assert any(e.source.endswith("::x") and e.target.endswith("::y") for e in edges)


def test_load_multiple_instruction():
    """Test LM instruction creates lineage for register range."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # LM R6,R9,SAVEAREA
    line = ParsedLine(
        label=None,
        opcode="LM",
        operands=["R6", "R9", "SAVEAREA"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line], context)

    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    # Should have nodes for R6, R7, R8, R9
    assert graph.get_node_id("R6", "register") is not None
    assert graph.get_node_id("R7", "register") is not None
    assert graph.get_node_id("R8", "register") is not None
    assert graph.get_node_id("R9", "register") is not None

    # Should have nodes for memory locations
    assert graph.get_node_id("SAVEAREA+0", "memory") is not None
    assert graph.get_node_id("SAVEAREA+4", "memory") is not None
    assert graph.get_node_id("SAVEAREA+8", "memory") is not None
    assert graph.get_node_id("SAVEAREA+12", "memory") is not None

    # Should have assignment edges from memory to registers
    edges = [e for e in graph.edges if e.relation == "assign"]
    mem_to_reg_edges = [e for e in edges
                        if e.source.startswith("memory:SAVEAREA")
                        and e.target.startswith("register:R")]
    assert len(mem_to_reg_edges) == 4


def test_store_multiple_instruction():
    """Test STM instruction creates lineage for register range."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # STM R14,R12,12(R13)
    line = ParsedLine(
        label=None,
        opcode="STM",
        operands=["R14", "R12", "12(R13)"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line], context)

    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    # Should have assignment edges from registers to memory
    edges = [e for e in graph.edges if e.relation == "assign"]
    reg_to_mem_edges = [e for e in edges
                        if e.source.startswith("register:R")
                        and e.target.startswith("memory:12")]
    # R14, R15, R0-R12 = 15 registers
    assert len(reg_to_mem_edges) == 15


def test_shift_right_logical():
    """Test SRL instruction preserves existing sources."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # First load a value into R6
    line1 = ParsedLine(
        label=None,
        opcode="L",
        operands=["R6", "VALUE"],
        comment=None,
        provenance=provenance
    )

    # Then shift it
    line2 = ParsedLine(
        label=None,
        opcode="SRL",
        operands=["R6", "4"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line1, line2], context)

    graph = context.get_metadata("variable_lineage")

    # R6 should have VALUE as a source after the shift
    assert builder.register_sources["R6"] == {("VALUE", "memory")}


def test_shift_left_arithmetic_with_register_amount():
    """Test SLA with register shift amount."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # Load values
    line1 = ParsedLine(
        label=None,
        opcode="L",
        operands=["R5", "VALUE"],
        comment=None,
        provenance=provenance
    )

    line2 = ParsedLine(
        label=None,
        opcode="L",
        operands=["R9", "SHIFTAMT"],
        comment=None,
        provenance=provenance
    )

    # Shift R5 by amount in R9
    line3 = ParsedLine(
        label=None,
        opcode="SLA",
        operands=["R5", "R9"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line1, line2, line3], context)

    # R5 should have both VALUE and SHIFTAMT as sources
    assert ("VALUE", "memory") in builder.register_sources["R5"]
    assert ("SHIFTAMT", "memory") in builder.register_sources["R5"]


def test_insert_character():
    """Test IC instruction preserves existing register sources."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # Load full word
    line1 = ParsedLine(
        label=None,
        opcode="L",
        operands=["R6", "FULLWORD"],
        comment=None,
        provenance=provenance
    )

    # Insert character into rightmost byte
    line2 = ParsedLine(
        label=None,
        opcode="IC",
        operands=["R6", "CHARFIELD"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line1, line2], context)

    # R6 should have both FULLWORD and CHARFIELD as sources
    assert ("FULLWORD", "memory") in builder.register_sources["R6"]
    assert ("CHARFIELD", "memory") in builder.register_sources["R6"]


def test_insert_characters_under_mask():
    """Test ICM instruction with mask."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # ICM R7,B'1111',FULLWORD
    line = ParsedLine(
        label=None,
        opcode="ICM",
        operands=["R7", "B'1111'", "FULLWORD"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line], context)

    graph = context.get_metadata("variable_lineage")

    # Should have assignment edge from FULLWORD to R7
    edges = [e for e in graph.edges
             if e.relation == "assign"
             and "FULLWORD" in e.source
             and "R7" in e.target]
    assert len(edges) > 0


def test_store_character():
    """Test STC instruction stores rightmost byte."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # Load value
    line1 = ParsedLine(
        label=None,
        opcode="L",
        operands=["R6", "SOURCE"],
        comment=None,
        provenance=provenance
    )

    # Store character
    line2 = ParsedLine(
        label=None,
        opcode="STC",
        operands=["R6", "CHARFIELD"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line1, line2], context)

    graph = context.get_metadata("variable_lineage")

    # Should have edge from R6 to CHARFIELD
    edges = [e for e in graph.edges
             if e.relation == "assign"
             and "R6" in e.source
             and "CHARFIELD" in e.target]
    assert len(edges) > 0

    # Should also propagate SOURCE to CHARFIELD
    edges = [e for e in graph.edges
             if e.relation == "assign"
             and "SOURCE" in e.source
             and "CHARFIELD" in e.target]
    assert len(edges) > 0


def test_store_characters_under_mask():
    """Test STCM instruction with mask."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # STCM R7,B'1111',FULLWORD
    line = ParsedLine(
        label=None,
        opcode="STCM",
        operands=["R7", "B'1111'", "FULLWORD"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line], context)

    graph = context.get_metadata("variable_lineage")

    # Should have assignment edge from R7 to FULLWORD
    edges = [e for e in graph.edges
             if e.relation == "assign"
             and "R7" in e.source
             and "FULLWORD" in e.target]
    assert len(edges) > 0


def test_indexed_ic_stc_preserve_pointer_lineage():
    """Indexed IC/STC should retain base/index addressing lineage end-to-end."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    lines = [
        ParsedLine(
            label=None,
            opcode="L",
            operands=["R2", "PBFINPUT"],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="L",
            operands=["R3", "PBFOUTPUT"],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="SR",
            operands=["R7", "R7"],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="IC",
            operands=["R9", "0(R7,R2)"],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="STC",
            operands=["R9", "0(R7,R3)"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    assign_edges = [e for e in graph.edges if e.relation == "assign"]

    # Addressed memory nodes should preserve full indexed/base form.
    assert graph.get_node_id("0(R7,R2)", "memory") is not None
    assert graph.get_node_id("0(R7,R3)", "memory") is not None

    # Base register lineage should flow into the effective memory address node.
    assert any(e.source == "memory:PBFINPUT" and e.target == "memory:0(R7,R2)" for e in assign_edges)

    # IC reads from indexed input address into target register.
    assert any(e.source == "memory:0(R7,R2)" and e.target == "register:R9" for e in assign_edges)

    # STC propagates that byte lineage into indexed output address.
    assert any(e.source == "memory:0(R7,R2)" and e.target == "memory:0(R7,R3)" for e in assign_edges)


def test_n_instruction_keeps_self_dependency_and_mask_literal():
    """N should model in-place register update plus mask literal contribution."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance_load = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )
    provenance_mask = StatementProvenance(
        statement_id="S002",
        original_file="test.asm",
        original_line=11,
        routine="MAIN"
    )

    lines = [
        ParsedLine(label=None, opcode="L", operands=["R9", "INPUT"], comment=None, provenance=provenance_load),
        ParsedLine(label=None, opcode="N", operands=["R9", "=X'0000007F'"], comment=None, provenance=provenance_mask),
    ]

    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    assign_edges = [e for e in graph.edges if e.relation == "assign" and e.line == 11]
    assert any(e.source == "register:R9" and e.target == "register:R9" for e in assign_edges)
    assert any(e.source == "literal:=X'0000007F'" and e.target == "register:R9" for e in assign_edges)


def test_la_indexed_address_tracks_register_and_displacement_contributors():
    """LA with based displacement should include base register and displacement lineage."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance_base = StatementProvenance(
        statement_id="S010",
        original_file="test.asm",
        original_line=20,
        routine="MAIN"
    )
    provenance_la = StatementProvenance(
        statement_id="S011",
        original_file="test.asm",
        original_line=21,
        routine="MAIN"
    )

    lines = [
        ParsedLine(label=None, opcode="L", operands=["R7", "BASEPTR"], comment=None, provenance=provenance_base),
        ParsedLine(label=None, opcode="LA", operands=["R7", "1(R7)"], comment=None, provenance=provenance_la),
    ]

    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    assign_edges = [e for e in graph.edges if e.relation == "assign" and e.line == 21]
    assert any(e.source == "register:R7" and e.target == "register:R7" for e in assign_edges)
    assert any(e.source == "literal:1" and e.target == "register:R7" for e in assign_edges)


def test_bct_decrements_counter_register_lineage():
    """BCT should create an in-place counter update edge and decrement literal."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance_load = StatementProvenance(
        statement_id="S020",
        original_file="test.asm",
        original_line=30,
        routine="MAIN"
    )
    provenance_bct = StatementProvenance(
        statement_id="S021",
        original_file="test.asm",
        original_line=31,
        routine="MAIN"
    )

    lines = [
        ParsedLine(label=None, opcode="L", operands=["R6", "COUNT"], comment=None, provenance=provenance_load),
        ParsedLine(label=None, opcode="BCT", operands=["R6", "LOOP"], comment=None, provenance=provenance_bct),
    ]

    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    assign_edges = [e for e in graph.edges if e.relation == "assign" and e.line == 31]
    assert any(e.source == "register:R6" and e.target == "register:R6" for e in assign_edges)
    assert any(e.source == "literal:-1" and e.target == "register:R6" for e in assign_edges)


def test_ltr_creates_register_assignment_lineage():
    """LTR should be modeled as a register-defining move-and-test operation."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance_lr = StatementProvenance(
        statement_id="S030",
        original_file="test.asm",
        original_line=40,
        routine="MAIN"
    )
    provenance_ltr = StatementProvenance(
        statement_id="S031",
        original_file="test.asm",
        original_line=41,
        routine="MAIN"
    )

    lines = [
        ParsedLine(label=None, opcode="L", operands=["R5", "SRCVAL"], comment=None, provenance=provenance_lr),
        ParsedLine(label=None, opcode="LR", operands=["R6", "R5"], comment=None, provenance=provenance_lr),
        ParsedLine(label=None, opcode="LTR", operands=["R6", "R6"], comment=None, provenance=provenance_ltr),
    ]

    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    assign_edges = [e for e in graph.edges if e.relation == "assign" and e.line == 41]
    assert any(e.source == "register:R6" and e.target == "register:R6" for e in assign_edges)

def test_compare_register_to_memory():
    """Test C instruction creates use edges."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # Load value
    line1 = ParsedLine(
        label=None,
        opcode="L",
        operands=["R6", "VALUE1"],
        comment=None,
        provenance=provenance
    )

    # Compare
    line2 = ParsedLine(
        label=None,
        opcode="C",
        operands=["R6", "LIMIT"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line1, line2], context)

    graph = context.get_metadata("variable_lineage")

    # Should have use edges for R6 and LIMIT
    use_edges = [e for e in graph.edges if e.relation == "use"]
    assert any("R6" in e.source for e in use_edges)
    assert any("LIMIT" in e.source for e in use_edges)


def test_compare_register_to_register():
    """Test CR instruction creates use edges for both registers."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # CR R5,R7
    line = ParsedLine(
        label=None,
        opcode="CR",
        operands=["R5", "R7"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line], context)

    graph = context.get_metadata("variable_lineage")

    # Should have use edges for both R5 and R7
    use_edges = [e for e in graph.edges if e.relation == "use"]
    assert any("R5" in e.source for e in use_edges)
    assert any("R7" in e.source for e in use_edges)


def test_compare_logical_character():
    """Test CLC creates use edges for both memory operands."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # CLC FIELD1,FIELD2
    line = ParsedLine(
        label=None,
        opcode="CLC",
        operands=["FIELD1", "FIELD2"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line], context)

    graph = context.get_metadata("variable_lineage")

    # Should have use edges for both FIELD1 and FIELD2
    use_edges = [e for e in graph.edges if e.relation == "use"]
    assert any("FIELD1" in e.source for e in use_edges)
    assert any("FIELD2" in e.source for e in use_edges)


def test_using_directive_tracking():
    """Test USING directive establishes base register mapping."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # USING WORKAREA,R13
    line = ParsedLine(
        label=None,
        opcode="USING",
        operands=["WORKAREA", "R13"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line], context)

    # Check internal state
    assert "R13" in builder.using_map
    assert builder.using_map["R13"] == "WORKAREA"
    assert "WORKAREA" in builder.active_dsects
    assert builder.active_dsects["WORKAREA"] == "R13"


def test_drop_directive_removes_mapping():
    """Test DROP directive removes base register mapping."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # USING WORKAREA,R13
    line1 = ParsedLine(
        label=None,
        opcode="USING",
        operands=["WORKAREA", "R13"],
        comment=None,
        provenance=provenance
    )

    # DROP R13
    line2 = ParsedLine(
        label=None,
        opcode="DROP",
        operands=["R13"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line1, line2], context)

    # Check mapping is removed
    assert "R13" not in builder.using_map
    assert "WORKAREA" not in builder.active_dsects


def test_equ_symbol_resolution():
    """Test EQU symbols are resolved in operands."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # SAVEOFF EQU 72
    line1 = ParsedLine(
        label="SAVEOFF",
        opcode="EQU",
        operands=["72"],
        comment=None,
        provenance=provenance
    )

    # ST R14,SAVEOFF(R13)
    line2 = ParsedLine(
        label=None,
        opcode="ST",
        operands=["R14", "SAVEOFF(R13)"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line1, line2], context)

    # Check EQU was resolved
    assert "SAVEOFF" in builder.equ_symbols
    assert builder.equ_symbols["SAVEOFF"] == "72"


def test_equ_displacement_emits_symbolic_to_numeric_memory_alias():
    """EQU displacement should keep a generic symbolic<->numeric memory alias bridge."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    lines = [
        ParsedLine(
            label="REGS_R4",
            opcode="EQU",
            operands=["16"],
            comment=None,
            provenance=provenance,
        ),
        ParsedLine(
            label=None,
            opcode="L",
            operands=["R2", "REGS_R4(R1)"],
            comment=None,
            provenance=provenance,
        ),
    ]

    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    alias_edges = [e for e in graph.edges if e.relation == "alias"]
    assert any(
        e.source == "memory:REGS_R4" and e.target == "memory:16"
        for e in alias_edges
    )


def test_log_rec_counter_flow_preserves_base_register_and_store_edges():
    """Ensure LOG_REC-style counter update keeps 4(R2) and emits downstream stores."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="TPFREGS.asm",
        original_line=1,
        routine="LOG_REC"
    )

    lines = [
        ParsedLine(
            label="REGS_R0",
            opcode="EQU",
            operands=["0"],
            comment=None,
            provenance=provenance,
        ),
        ParsedLine(
            label=None,
            opcode="L",
            operands=["R4", "4(R2)"],
            comment=None,
            provenance=StatementProvenance(
                statement_id="S121",
                original_file="TPFREGS.asm",
                original_line=121,
                routine="LOG_REC",
            ),
        ),
        ParsedLine(
            label=None,
            opcode="A",
            operands=["R4", "=F'1'"],
            comment=None,
            provenance=StatementProvenance(
                statement_id="S125",
                original_file="TPFREGS.asm",
                original_line=125,
                routine="LOG_REC",
            ),
        ),
        ParsedLine(
            label=None,
            opcode="ST",
            operands=["R4", "4(R2)"],
            comment=None,
            provenance=StatementProvenance(
                statement_id="S126",
                original_file="TPFREGS.asm",
                original_line=126,
                routine="LOG_REC",
            ),
        ),
        ParsedLine(
            label=None,
            opcode="ST",
            operands=["R4", "LRSEQNO"],
            comment=None,
            provenance=StatementProvenance(
                statement_id="S127",
                original_file="TPFREGS.asm",
                original_line=127,
                routine="LOG_REC",
            ),
        ),
        ParsedLine(
            label=None,
            opcode="ST",
            operands=["R4", "REGS_R0(R1)"],
            comment=None,
            provenance=StatementProvenance(
                statement_id="S130",
                original_file="TPFREGS.asm",
                original_line=130,
                routine="LOG_REC",
            ),
        ),
    ]

    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    assign_edges = [e for e in graph.edges if e.relation == "assign"]

    assert any(
        e.line == 121
        and e.source == "memory:4(R2)"
        and e.target == "register:R4"
        for e in assign_edges
    )
    assert any(
        e.line == 125
        and e.source == "register:R4"
        and e.target == "register:R4"
        for e in assign_edges
    )
    assert any(
        e.line == 126
        and e.source == "register:R4"
        and e.target == "memory:4(R2)"
        for e in assign_edges
    )
    assert any(
        e.line == 127
        and e.source == "register:R4"
        and e.target == "memory:LRSEQNO"
        for e in assign_edges
    )
    assert any(
        e.line == 130
        and e.source == "register:R4"
        and e.target in ("memory:REGS_R0(R1)", "memory:caller_param[0](R1)")
        for e in assign_edges
    )


def test_nested_equ_resolution():
    """Test nested EQU references are resolved."""
    builder = VariableLineageBuilder()

    # R12 EQU 12
    builder.equ_symbols["R12"] = "12"

    # BASEREG EQU R12
    resolved = builder._resolve_equ_value("BASEREG")
    builder.equ_symbols["BASEREG"] = resolved

    # Second level
    builder.equ_symbols["BASEREG"] = "R12"
    final = builder._resolve_equ_value("BASEREG")

    # Should resolve to the register
    assert "R" in final or "12" in final


def test_normalize_operand_with_index_and_base():
    """Test full operand parsing extracts index and base registers."""
    builder = VariableLineageBuilder()

    # Parse offset(index,base)
    symbol, kind, index_reg, base_reg = builder._normalize_operand_full("12(R7,R13)")
    assert symbol == "12"
    assert kind == "memory"
    assert index_reg == "R7"
    assert base_reg == "R13"


def test_normalize_operand_with_base_only():
    """Test operand parsing with base register only."""
    builder = VariableLineageBuilder()

    # Parse offset(base)
    symbol, kind, index_reg, base_reg = builder._normalize_operand_full("72(R13)")
    assert symbol == "72"
    assert kind == "memory"
    assert index_reg is None
    assert base_reg == "R13"


def test_normalize_operand_with_using_qualification():
    """Test operand is qualified with DSECT when USING is active."""
    builder = VariableLineageBuilder()
    builder.using_map["R13"] = "WORKAREA"

    # Parse with USING active
    symbol, kind, index_reg, base_reg = builder._normalize_operand_full("FIELD1(R13)")
    assert "WORKAREA" in symbol
    assert kind == "memory"
    assert base_reg == "R13"


def test_normalize_operand_with_equ_resolution():
    """Test operand preserves EQU symbol in displacement for traceability."""
    builder = VariableLineageBuilder()
    builder.equ_symbols["SAVEOFF"] = "72"

    # Parse with EQU resolution
    symbol, kind, index_reg, base_reg = builder._normalize_operand_full("SAVEOFF(R13)")
    assert symbol == "SAVEOFF"
    assert kind == "memory"
    assert base_reg == "R13"


def test_normalize_operand_with_equ_register_alias_base():
    """Test EQU register alias is normalized for base register in address form."""
    builder = VariableLineageBuilder()
    builder.equ_symbols["PARMREG"] = "1"

    symbol, kind, index_reg, base_reg = builder._normalize_operand_full("0(PARMREG)")
    assert symbol == "caller_param[0]"
    assert kind == "memory"
    assert index_reg is None
    assert base_reg == "R1"


def test_normalize_operand_with_equ_register_alias_base():
    """Test EQU register alias is normalized for base register in address form."""
    builder = VariableLineageBuilder()
    builder.equ_symbols["PARMREG"] = "1"

    symbol, kind, index_reg, base_reg = builder._normalize_operand_full("0(PARMREG)")
    assert symbol == "caller_param[0]"
    assert kind == "memory"
    assert index_reg is None
    assert base_reg == "R1"


def test_normalize_operand_plain_register():
    """Test plain register operands."""
    builder = VariableLineageBuilder()

    symbol, kind, index_reg, base_reg = builder._normalize_operand_full("R7")
    assert symbol == "R7"
    assert kind == "register"
    assert index_reg is None
    assert base_reg is None


def test_normalize_operand_plain_symbol():
    """Test plain memory symbols."""
    builder = VariableLineageBuilder()

    symbol, kind, index_reg, base_reg = builder._normalize_operand_full("SAVEAREA")
    assert symbol == "SAVEAREA"
    assert kind == "memory"
    assert index_reg is None
    assert base_reg is None


def test_normalize_operand_literal():
    """Test literal operands are recognized."""
    builder = VariableLineageBuilder()

    symbol, kind, index_reg, base_reg = builder._normalize_operand_full("=V(HELPER)")
    assert symbol == "=V(HELPER)"
    assert kind == "literal"
    assert index_reg is None
    assert base_reg is None


def test_base_register_usage_tracking():
    """Test that base registers generate use edges."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # LA R13,SAVEAREA
    line1 = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R13", "SAVEAREA"],
        comment=None,
        provenance=provenance
    )

    # ST R14,72(R13)  - R13 is base register
    line2 = ParsedLine(
        label=None,
        opcode="ST",
        operands=["R14", "72(R13)"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line1, line2], context)

    graph = context.get_metadata("variable_lineage")

    # Should have use edge for R13 as base register
    use_edges = [e for e in graph.edges
                 if e.relation == "use"
                 and "R13" in e.source
                 and "(base)" in e.expression]
    assert len(use_edges) > 0


def test_index_register_usage_tracking():
    """Test that index registers generate use edges."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # L R6,TABLE(R7,R13)  - R7 is index, R13 is base
    line = ParsedLine(
        label=None,
        opcode="L",
        operands=["R6", "TABLE(R7,R13)"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line], context)

    graph = context.get_metadata("variable_lineage")

    # Should have use edge for R7 as index register
    use_edges = [e for e in graph.edges
                 if e.relation == "use"
                 and "R7" in e.source
                 and "(index)" in e.expression]
    assert len(use_edges) > 0


def test_balr_return_value_tracking():
    """Test BALR creates return value lineage."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # L R15,=V(HELPER)
    line1 = ParsedLine(
        label=None,
        opcode="L",
        operands=["R15", "=V(HELPER)"],
        comment=None,
        provenance=provenance
    )

    # BALR R14,R15
    line2 = ParsedLine(
        label=None,
        opcode="BALR",
        operands=["R14", "R15"],
        comment=None,
        provenance=provenance
    )

    builder.process_assembly([line1, line2], context)

    graph = context.get_metadata("variable_lineage")

    # Should have return value node
    assert graph.get_node_id("return@HELPER", "return_value") is not None

    # Should have edge from return value to R14
    edges = [e for e in graph.edges
             if e.relation == "assign"
             and "return@" in e.source
             and "R14" in e.target]
    assert len(edges) > 0

    # Should also track R15, R0, R1 as potential return value registers
    assert graph.get_node_id("return@HELPER:R15", "return_value") is not None
    assert graph.get_node_id("return@HELPER:R0", "return_value") is not None
    assert graph.get_node_id("return@HELPER:R1", "return_value") is not None


def test_call_clobbers_work_registers():
    """Test that call instructions clobber work registers."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10,
        routine="MAIN"
    )

    # Load values into R0, R1, R2
    for reg in ["R0", "R1", "R2"]:
        line = ParsedLine(
            label=None,
            opcode="L",
            operands=[reg, "VALUE"],
            comment=None,
            provenance=provenance
        )
        builder.process_assembly([line], context)

    # BALR R14,R15  - should clobber R0, R1, R2
    call_line = ParsedLine(
        label=None,
        opcode="BALR",
        operands=["R14", "R15"],
        comment=None,
        provenance=provenance
    )
    builder.process_assembly([call_line], context)

    # R0, R1, R2 should have clobbered sources
    for reg in ["R0", "R1", "R2"]:
        sources = builder.register_sources.get(reg, set())
        assert any("clobbered" in src[1] or "return" in src[1] for src in sources), f"{reg} should be clobbered or have return value"


def test_entrc_creates_argument_bridge_nodes():
    """ENTRC should bridge argument registers into callee arg nodes."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S010",
        original_file="entrydrv.asm",
        original_line=69,
        routine="ENTRYDRV"
    )

    lines = [
        ParsedLine(label=None, opcode="LA", operands=["R0", "2"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode="L", operands=["R1", "=A(EDACCT)"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode="ENTRC", operands=["CPP_AUTHZN"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    assert graph.get_node_id("arg@CPP_AUTHZN:R0", "parameter") is not None
    assert graph.get_node_id("arg@CPP_AUTHZN:R1", "parameter") is not None
    assert any(
        e.source == "register:R0" and e.target == "parameter:arg@CPP_AUTHZN:R0"
        for e in graph.edges
    )


def test_creec_creates_spawn_usage_and_argument_nodes():
    """CREEC should model async spawn usage and explicit spawn argument nodes."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011",
        original_file="spawn.asm",
        original_line=210,
        routine="PARENT"
    )

    lines = [
        ParsedLine(label=None, opcode="LA", operands=["R3", "WORKAREA"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode="CREEC", operands=["GA71", "D0", "R3"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    assert graph.get_node_id("GA71", "function") is not None
    assert graph.get_node_id("arg@GA71:SPAWN1", "parameter") is not None
    assert graph.get_node_id("arg@GA71:SPAWN2", "parameter") is not None
    assert any(
        e.relation == "use" and e.source == "function:GA71" and e.line == 210
        for e in graph.edges
    )


@pytest.mark.parametrize("opcode", ["GETCC", "GETFC"])
def test_getcc_getfc_create_level_pointer_and_r1_lineage(opcode):
    """GETCC/GETFC should allocate a level block and expose pointer via CE1CR and R1."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011A",
        original_file="alloc.asm",
        original_line=215,
        routine="PARENT"
    )

    lines = [
        ParsedLine(label=None, opcode=opcode, operands=["D7"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    assert graph.get_node_id("D7", "memory") is not None
    assert graph.get_node_id("CE1CR7", "memory") is not None
    assert any(
        e.source == "memory:D7" and e.target == "memory:CE1CR7"
        for e in graph.edges
    )
    assert any(
        e.source == "memory:CE1CR7" and e.target == "register:R1"
        for e in graph.edges
    )
    assert any(src == "CE1CR7" and kind == "memory" for src, kind in builder.register_sources.get("R1", set()))


@pytest.mark.parametrize("opcode", ["RELCC", "RELFC"])
def test_relcc_relfc_create_release_boundary_lineage(opcode):
    """RELCC/RELFC should emit release-boundary lineage and freed marker nodes."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011B",
        original_file="release.asm",
        original_line=216,
        routine="PARENT"
    )

    lines = [
        ParsedLine(label=None, opcode="LA", operands=["R8", "CE1CR7"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode=opcode, operands=["R8"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    release_node = "free@PARENT:216"
    arg1 = f"{release_node}:ARG1"

    assert graph.get_node_id(release_node, "parameter") is not None
    assert graph.get_node_id(arg1, "parameter") is not None
    assert any(
        e.source == "register:R8" and e.target == f"parameter:{arg1}"
        for e in graph.edges
    )
    assert any(
        e.source == "memory:CE1CR7" and e.target == f"parameter:{arg1}"
        for e in graph.edges
    )
    assert any(
        e.source == f"parameter:{arg1}" and e.target.startswith("clobbered:freed@PARENT:216:")
        for e in graph.edges
    )


def test_levta_reads_level_and_populates_r15_status():
    """LEVTA should read D-level state and set R15 status lineage."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011C",
        original_file="level.asm",
        original_line=217,
        routine="PARENT"
    )

    lines = [
        ParsedLine(label=None, opcode="LEVTA", operands=["LEVEL=0", "NOTUSED=LV_NOLVL"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    assert graph.get_node_id("D0", "memory") is not None
    assert graph.get_node_id("levta@D0:217", "parameter") is not None
    assert any(
        e.relation == "use" and e.source == "memory:D0" and e.line == 217
        for e in graph.edges
    )
    assert any(
        e.source == "parameter:levta@D0:217" and e.target == "register:R15"
        for e in graph.edges
    )
    assert any(src == "levta@D0:217" and kind == "parameter" for src, kind in builder.register_sources.get("R15", set()))
    assert any(
        e.relation == "use" and e.source == "memory:LV_NOLVL"
        for e in graph.edges
    )


@pytest.mark.parametrize("opcode", ["PNTRP", "PNTRC"])
def test_pntrp_pntrc_transfer_pointer_lineage(opcode):
    """PNTRP/PNTRC should transfer pointer lineage to destination register."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011D",
        original_file="pntr.asm",
        original_line=218,
        routine="PARENT"
    )

    lines = [
        ParsedLine(label=None, opcode="LA", operands=["R3", "CE1CR4"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode=opcode, operands=["R3", "R7"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    assert any(
        e.source == "register:R3" and e.target == "register:R7"
        for e in graph.edges
    )
    assert any(
        e.source == "memory:CE1CR4" and e.target == "register:R7"
        for e in graph.edges
    )
    assert any(src == "CE1CR4" and kind == "memory" for src, kind in builder.register_sources.get("R7", set()))


@pytest.mark.parametrize("opcode", ["ENTER", "SAVE", "SAVEX"])
def test_entry_family_macros_capture_entry_boundary_lineage(opcode):
    """ENTER/SAVE/SAVEX should capture boundary arguments and propagated sources."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011E",
        original_file="entry.asm",
        original_line=219,
        routine="MAIN"
    )

    lines = [
        ParsedLine(label=None, opcode="LA", operands=["R11", "SAVEAREA"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode=opcode, operands=["R11"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    boundary = "entry_boundary@MAIN:219"
    arg1 = f"{boundary}:ARG1"
    assert graph.get_node_id(boundary, "parameter") is not None
    assert graph.get_node_id(arg1, "parameter") is not None
    assert any(
        e.source == "register:R11" and e.target == f"parameter:{arg1}"
        for e in graph.edges
    )
    assert any(
        e.source == "memory:SAVEAREA" and e.target == f"parameter:{arg1}"
        for e in graph.edges
    )


@pytest.mark.parametrize("opcode", ["EXIT", "EXITC", "RETURN", "RETRN"])
def test_exit_family_macros_capture_exit_boundary_lineage(opcode):
    """EXIT/EXITC/RETURN/RETRN should emit exit boundary and return-register usage."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011F",
        original_file="exit.asm",
        original_line=220,
        routine="MAIN"
    )

    lines = [
        ParsedLine(label=None, opcode="L", operands=["R14", "=A(CALLER)"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode=opcode, operands=[], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    boundary = "exit_boundary@MAIN:220"
    assert graph.get_node_id(boundary, "parameter") is not None
    assert any(
        e.relation == "use" and e.source == "register:R14" and e.line == 220
        for e in graph.edges
    )
    assert any(
        e.relation == "use" and e.source == "parameter:exit_boundary@MAIN:220"
        for e in graph.edges
    )


@pytest.mark.parametrize("opcode", ["ENQ", "SERRC"])
def test_lock_acquire_macros_emit_lock_boundary_lineage(opcode):
    """ENQ/SERRC should capture lock operands into lock boundary nodes."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011G",
        original_file="lock.asm",
        original_line=221,
        routine="MAIN"
    )

    lines = [
        ParsedLine(label=None, opcode="LA", operands=["R5", "LOCKTOKEN"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode=opcode, operands=["ECB=R5"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    boundary = "lock@MAIN:221"
    arg1 = f"{boundary}:ARG1"
    assert graph.get_node_id(boundary, "parameter") is not None
    assert graph.get_node_id(arg1, "parameter") is not None
    assert any(
        e.source == "register:R5" and e.target == f"parameter:{arg1}"
        for e in graph.edges
    )
    assert any(
        e.source == "memory:LOCKTOKEN" and e.target == f"parameter:{arg1}"
        for e in graph.edges
    )


@pytest.mark.parametrize("opcode", ["DEQ", "RELSC"])
def test_lock_release_macros_emit_unlock_boundary_lineage(opcode):
    """DEQ/RELSC should capture lock operands into unlock boundary nodes."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011H",
        original_file="unlock.asm",
        original_line=222,
        routine="MAIN"
    )

    lines = [
        ParsedLine(label=None, opcode="LA", operands=["R5", "LOCKTOKEN"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode=opcode, operands=["ECB=R5"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    boundary = "unlock@MAIN:222"
    arg1 = f"{boundary}:ARG1"
    assert graph.get_node_id(boundary, "parameter") is not None
    assert graph.get_node_id(arg1, "parameter") is not None
    assert any(
        e.source == "register:R5" and e.target == f"parameter:{arg1}"
        for e in graph.edges
    )


def test_maloc_returns_heap_pointer_in_target_register():
    """MALOC should define heap allocation lineage and return it to the target register."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011I",
        original_file="heap.asm",
        original_line=223,
        routine="MAIN"
    )

    lines = [
        ParsedLine(label=None, opcode="MALOC", operands=["R2", "256"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    heap_node = "heap_alloc@MAIN:223"
    assert graph.get_node_id(heap_node, "memory") is not None
    assert any(
        e.source == f"memory:{heap_node}" and e.target == "register:R2"
        for e in graph.edges
    )
    assert any(src == heap_node and kind == "memory" for src, kind in builder.register_sources.get("R2", set()))


def test_reloc_preserves_old_pointer_lineage_and_updates_target_register():
    """RELOC should propagate old pointer lineage while producing new heap pointer output."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011J",
        original_file="reheap.asm",
        original_line=224,
        routine="MAIN"
    )

    lines = [
        ParsedLine(label=None, opcode="LA", operands=["R2", "OLDPTR"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode="RELOC", operands=["R2", "512"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    heap_node = "heap_realloc@MAIN:224"
    assert graph.get_node_id(heap_node, "memory") is not None
    assert any(
        e.source == f"memory:{heap_node}" and e.target == "register:R2"
        for e in graph.edges
    )
    assert any(
        e.source == "memory:OLDPTR" and e.target == f"memory:{heap_node}"
        for e in graph.edges
    )


def test_callcpp_bridges_register_args_and_return_to_r15():
    """CALLCPP should pass argument registers and model return value into R15."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011K",
        original_file="callcpp.asm",
        original_line=225,
        routine="MAIN"
    )

    lines = [
        ParsedLine(label=None, opcode="LA", operands=["R0", "REQ"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode="LA", operands=["R1", "ARGS"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode="CALLCPP", operands=["ENTRY=CPP_AUTHZN"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    assert graph.get_node_id("arg@CPP_AUTHZN:R0", "parameter") is not None
    assert graph.get_node_id("arg@CPP_AUTHZN:R1", "parameter") is not None
    assert graph.get_node_id("return@CPP_AUTHZN", "return_value") is not None
    assert any(
        e.source == "return_value:return@CPP_AUTHZN" and e.target == "register:R15"
        for e in graph.edges
    )


@pytest.mark.parametrize(
    "mode, op_node",
    [
        ("RECEIVE", "parameter:iscfa_receive@D0:226"),
        ("SEND", "parameter:iscfa_send@D0:226"),
    ],
)
def test_iscfa_models_level_to_buffer_direction(mode, op_node):
    """ISCFA should model RECEIVE/SEND direction between level and record buffer."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011L",
        original_file="iscfa.asm",
        original_line=226,
        routine="MAIN"
    )

    lines = [
        ParsedLine(
            label=None,
            opcode="ISCFA",
            operands=[mode, "DATA=LEVEL0", "RECLEN=LVMSGSZ", "RECPTR=LVRECPTR"],
            comment=None,
            provenance=provenance,
        ),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    if mode == "RECEIVE":
        assert any(e.source == "memory:D0" and e.target == op_node for e in graph.edges)
        assert any(e.source == op_node and e.target == "memory:LVRECPTR" for e in graph.edges)
    else:
        assert any(e.source == "memory:LVRECPTR" and e.target == op_node for e in graph.edges)
        assert any(e.source == op_node and e.target == "memory:D0" for e in graph.edges)


def test_crusa_clears_level_with_zero_literal_assignment():
    """CRUSA should assign zero literal into the target data level."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011M",
        original_file="crusa.asm",
        original_line=227,
        routine="MAIN"
    )

    lines = [
        ParsedLine(label=None, opcode="CRUSA", operands=["LEVEL=2"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    assert graph.get_node_id("D2", "memory") is not None
    assert graph.get_node_id("0", "literal") is not None
    assert any(
        e.source == "literal:0" and e.target == "memory:D2"
        for e in graph.edges
    )


@pytest.mark.parametrize(
    "opcode, expected_source, expected_target",
    [
        ("SENDA", "memory:MSGBUF", "parameter:msg_send@SENDA:MAIN:228"),
        ("RECVC", "parameter:msg_recv@RECVC:MAIN:228", "memory:MSGBUF"),
    ],
)
def test_send_recv_macros_model_message_payload_direction(opcode, expected_source, expected_target):
    """SENDA/RECVC should encode message payload directionality."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S011N",
        original_file="msg.asm",
        original_line=228,
        routine="MAIN"
    )

    lines = [
        ParsedLine(label=None, opcode=opcode, operands=["DATA=MSGBUF"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    assert any(e.source == expected_source and e.target == expected_target for e in graph.edges)


def test_attac_creates_attach_usage_and_argument_nodes():
    """ATTAC should model async attach usage and attach argument nodes."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S012",
        original_file="attach.asm",
        original_line=220,
        routine="PARENT"
    )

    lines = [
        ParsedLine(label=None, opcode="LA", operands=["R7", "HUBGL"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode="ATTAC", operands=["ENTRY=CHILDSEG", "D4", "R7"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    assert graph.get_node_id("CHILDSEG", "function") is not None
    assert graph.get_node_id("arg@CHILDSEG:ATTACH1", "parameter") is not None
    assert graph.get_node_id("arg@CHILDSEG:ATTACH2", "parameter") is not None
    assert any(
        e.source == "register:R7" and e.target == "parameter:arg@CHILDSEG:ATTACH2"
        for e in graph.edges
    )
    assert any(
        e.relation == "use" and e.source == "function:CHILDSEG" and e.line == 220
        for e in graph.edges
    )


def test_detac_creates_boundary_and_argument_lineage():
    """DETAC should emit a detach boundary node and bind operands into it."""
    builder = VariableLineageBuilder()
    context = AnalysisContext()

    provenance = StatementProvenance(
        statement_id="S013",
        original_file="detach.asm",
        original_line=300,
        routine="PARENT"
    )

    lines = [
        ParsedLine(label=None, opcode="L", operands=["R8", "ECBTOKEN"], comment=None, provenance=provenance),
        ParsedLine(label=None, opcode="DETAC", operands=["ECB=R8", "MODE=FORCE"], comment=None, provenance=provenance),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")

    detach_node = "detach@PARENT:300"
    arg1 = f"{detach_node}:ARG1"

    assert graph.get_node_id(detach_node, "parameter") is not None
    assert graph.get_node_id(arg1, "parameter") is not None
    assert any(
        e.source == "register:R8" and e.target == f"parameter:{arg1}"
        for e in graph.edges
    )
    assert any(
        e.source == "memory:ECBTOKEN" and e.target == f"parameter:{arg1}"
        for e in graph.edges
    )
    assert any(
        e.source == f"parameter:{arg1}" and e.target == f"parameter:{detach_node}"
        for e in graph.edges
    )


def test_c_family_parameter_nodes_bridge_from_entrc_arg_nodes():
    """C-family parameter declarations should connect from arg@func:R0/R1 bridge nodes."""
    context = AnalysisContext(file_path=Path("entrc_handlers.cpp"))
    builder = VariableLineageBuilder()
    unit = CTranslationUnit(file_path=Path("entrc_handlers.cpp"), language="cpp")
    unit.declarations.append(CDeclaration(name="code", kind="parameter", line=10, function="CPP_AUTHZN", scope="local"))
    unit.declarations.append(CDeclaration(name="acct_id", kind="parameter", line=10, function="CPP_AUTHZN", scope="local"))

    builder.process_c_family(unit, context)
    graph = context.get_metadata("variable_lineage")
    edges = [e for e in graph.edges if e.relation == "assign"]

    assert any(
        e.source == "parameter:arg@CPP_AUTHZN:R0" and e.target == "parameter:CPP_AUTHZN::code"
        for e in edges
    )
    assert any(
        e.source == "parameter:arg@CPP_AUTHZN:R1" and e.target == "parameter:CPP_AUTHZN::acct_id"
        for e in edges
    )


def test_dsect_field_annotation_includes_byte_offset():
    builder = VariableLineageBuilder()
    context = AnalysisContext(file_path=Path("ecblevel.asm"))

    lines = [
        ParsedLine(label="ECBDS", opcode="DSECT", operands=[], comment=None,
                   provenance=StatementProvenance("S1", "ecblevel.asm", 1)),
        ParsedLine(label="APPSTAT", opcode="DS", operands=["CL1"], comment=None,
                   provenance=StatementProvenance("S2", "ecblevel.asm", 2)),
        ParsedLine(label="APPSCOR", opcode="DS", operands=["F"], comment=None,
                   provenance=StatementProvenance("S3", "ecblevel.asm", 3)),
    ]
    builder.process_assembly(lines, context)
    graph = context.get_metadata("variable_lineage")
    node = graph.nodes.get("memory:APPSTAT")
    assert node is not None
    assert node.metadata.get("byte_offset") == 0
    assert node.metadata.get("cpp_struct") == "ECBDS"


def test_dc_constant_creates_literal_lineage_node():
    builder = VariableLineageBuilder()
    context = AnalysisContext(file_path=Path("const.asm"))
    line = ParsedLine(
        label="TAG",
        opcode="DC",
        operands=["CL8'PARAM_BLK'"],
        comment=None,
        provenance=StatementProvenance("S10", "const.asm", 10),
    )
    builder.process_assembly([line], context)
    graph = context.get_metadata("variable_lineage")
    assert graph.get_node_id("'PARAM_BLK'", "literal") is not None
    assert any(
        e.source == "literal:'PARAM_BLK'" and e.target == "memory:TAG"
        for e in graph.edges
    )


def test_heap_locate_variable_arg_resolves_to_string_literal_named_node():
    builder = VariableLineageBuilder()
    context = AnalysisContext(file_path=Path("heap_decb_ops.cpp"))
    unit = CTranslationUnit(file_path=Path("heap_decb_ops.cpp"), language="cpp")
    unit.assignments.append(CAssignment(
        target="tagName",
        target_kind="variable",
        sources=['"PARAM_BLK"'],
        line=40,
        function="param_block_flow",
        scope="local",
        expression='tagName = "PARAM_BLK"',
    ))
    unit.calls.append(CCall(
        function="heap_locate",
        line=41,
        enclosing_function="param_block_flow",
        args=["tagName"],
        address_of_args=[],
    ))

    builder.process_c_family(unit, context)
    graph = context.get_metadata("variable_lineage")
    assert graph.get_node_id("named:PARAM_BLK", "memory") is not None
    assert graph.get_node_id('"PARAM_BLK"', "literal") is not None


def test_variable_lineage_scope_qualification_for_c():
    context = AnalysisContext(file_path=Path("demo.c"))
    builder = VariableLineageBuilder()
    unit = CTranslationUnit(file_path=Path("demo.c"), language="c")
    unit.declarations.append(CDeclaration(name="g_counter", kind="variable", line=1, scope="global"))
    unit.assignments.append(CAssignment(
        target="g_counter",
        target_kind="variable",
        sources=["delta"],
        line=5,
        function="apply",
        scope="local",
        expression="g_counter = delta",
    ))

    builder.process_c_family(unit, context)
    graph = context.get_metadata("variable_lineage")
    assert graph is not None
    assert graph.get_node_id("demo.c::g_counter", "variable") is not None
    assert graph.get_node_id("apply::delta", "variable") is not None


def test_variable_lineage_struct_and_array_targets():
    context = AnalysisContext(file_path=Path("demo.c"))
    builder = VariableLineageBuilder()
    unit = CTranslationUnit(file_path=Path("demo.c"), language="c")
    unit.assignments.append(CAssignment(
        target="obj.total",
        target_kind="struct_field",
        sources=["sum"],
        line=10,
        function="compute",
        scope="local",
        target_base="obj",
        target_field="total",
        expression="obj.total = sum",
    ))
    unit.assignments.append(CAssignment(
        target="arr[i]",
        target_kind="array_element",
        sources=["value", "i"],
        line=11,
        function="compute",
        scope="local",
        target_base="arr",
        expression="arr[i] = value",
    ))

    builder.process_c_family(unit, context)
    graph = context.get_metadata("variable_lineage")
    assert graph is not None
    assert graph.get_node_id("obj.total", "struct_field") is not None
    assert graph.get_node_id("arr[i]", "array_element") is not None


def test_variable_lineage_multilevel_alias_chain():
    context = AnalysisContext(file_path=Path("alias.c"))
    builder = VariableLineageBuilder()
    unit = CTranslationUnit(file_path=Path("alias.c"), language="c")
    unit.assignments.append(CAssignment(
        target="p",
        target_kind="variable",
        sources=["x"],
        line=1,
        function="run",
        scope="local",
        expression="p = &x",
    ))
    unit.assignments.append(CAssignment(
        target="q",
        target_kind="variable",
        sources=["p"],
        line=2,
        function="run",
        scope="local",
        expression="q = p",
    ))
    unit.assignments.append(CAssignment(
        target="y",
        target_kind="variable",
        sources=["q"],
        line=3,
        function="run",
        scope="local",
        expression="y = *q",
    ))

    builder.process_c_family(unit, context)
    graph = context.get_metadata("variable_lineage")
    assign_edges = [e for e in graph.edges if e.relation == "assign"]
    assert any(e.source.endswith("::x") and e.target.endswith("::y") for e in assign_edges)


def test_variable_lineage_c_call_links_to_return_value_node():
    context = AnalysisContext(file_path=Path("bridge.cpp"))
    builder = VariableLineageBuilder()
    unit = CTranslationUnit(file_path=Path("bridge.cpp"), language="cpp")
    unit.assignments.append(CAssignment(
        target="risk",
        target_kind="variable",
        sources=[],
        line=20,
        function="main_flow",
        scope="local",
        call_function="asm_fraud_check",
        expression="risk = asm_fraud_check(txn)",
    ))

    builder.process_c_family(unit, context)
    graph = context.get_metadata("variable_lineage")
    assert graph.get_node_id("return@asm_fraud_check", "return_value") is not None
    edges = [e for e in graph.edges if e.relation == "assign"]
    assert any("return_value:return@asm_fraud_check" == e.source and e.target.endswith("::risk") for e in edges)


def test_variable_lineage_emits_call_arg_bind_and_asm_param_bridge():
    context = AnalysisContext(file_path=Path("bridge.cpp"))
    builder = VariableLineageBuilder()
    unit = CTranslationUnit(file_path=Path("bridge.cpp"), language="cpp")
    unit.assignments.append(CAssignment(
        target="checksum",
        target_kind="variable",
        sources=["raw_input"],
        line=66,
        function="process_buffer_pipeline",
        scope="local",
        call_function="processBuffer",
        call_asm_target="ASM_PROCBF",
        call_args=["raw_input", "output", "input_size"],
        expression="checksum = processBuffer(raw_input, output, input_size)",
    ))

    builder.process_c_family(unit, context)
    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    arg_bind_edges = [e for e in graph.edges if e.relation == "arg_bind"]
    assert any(
        e.source == "variable:process_buffer_pipeline::raw_input"
        and e.target == "call_arg:processBuffer#0"
        and e.line == 66
        and e.scope == "process_buffer_pipeline"
        for e in arg_bind_edges
    )
    assert any(
        e.source == "call_arg:processBuffer#0"
        and e.target == "memory:caller_param[0]"
        and e.callee == "ASM_PROCBF"
        for e in arg_bind_edges
    )


def test_variable_lineage_emits_arg_bind_for_standalone_call_expression():
    context = AnalysisContext(file_path=Path("bridge.cpp"))
    builder = VariableLineageBuilder()
    unit = CTranslationUnit(file_path=Path("bridge.cpp"), language="cpp")
    unit.calls.append(CCall(
        function="validateBuffer",
        line=80,
        enclosing_function="process_buffer_pipeline",
        asm_target="ASM_VALBUF",
        args=["output", "vlen", "valid_result"],
    ))

    builder.process_c_family(unit, context)
    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    arg_bind_edges = [e for e in graph.edges if e.relation == "arg_bind"]
    assert any(
        e.source == "variable:process_buffer_pipeline::output"
        and e.target == "call_arg:validateBuffer#0"
        and e.line == 80
        and e.scope == "process_buffer_pipeline"
        for e in arg_bind_edges
    )


def test_variable_lineage_classifies_numeric_call_args_as_literals():
    context = AnalysisContext(file_path=Path("bridge.cpp"))
    builder = VariableLineageBuilder()
    unit = CTranslationUnit(file_path=Path("bridge.cpp"), language="cpp")
    unit.calls.append(CCall(
        function="normalize_args",
        line=42,
        enclosing_function="run",
        args=["15", "0xFF", '"ROUNDTRP"'],
    ))

    builder.process_c_family(unit, context)
    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    arg_bind_edges = [e for e in graph.edges if e.relation == "arg_bind"]
    assert any(e.source == "literal:15" and e.target == "call_arg:normalize_args#0" for e in arg_bind_edges)
    assert any(e.source == "literal:0xFF" and e.target == "call_arg:normalize_args#1" for e in arg_bind_edges)
    assert any(e.source == 'literal:"ROUNDTRP"' and e.target == "call_arg:normalize_args#2" for e in arg_bind_edges)


def test_variable_lineage_emits_struct_field_arg_bind_for_address_handoff():
    context = AnalysisContext(file_path=Path("bridge.cpp"))
    builder = VariableLineageBuilder()
    unit = CTranslationUnit(file_path=Path("bridge.cpp"), language="cpp")
    unit.assignments.append(CAssignment(
        target="handoff.r4",
        target_kind="struct_field",
        sources=["work_block"],
        line=12,
        function="setup_and_call_asm",
        scope="local",
        target_base="handoff",
        target_field="r4",
        expression="handoff.r4 = reinterpret_cast<long>(work_block)",
    ))
    unit.calls.append(CCall(
        function="SETUP_BLOCK",
        line=88,
        enclosing_function="setup_and_call_asm",
        args=["handoff"],
        address_of_args=["handoff"],
    ))

    builder.process_c_family(unit, context)
    graph = context.get_metadata("variable_lineage")
    assert graph is not None

    arg_bind_edges = [e for e in graph.edges if e.relation == "arg_bind"]
    assert any(
        e.source == "struct_field:setup_and_call_asm::handoff.r4"
        and e.target == "call_arg:SETUP_BLOCK#0"
        and e.line == 88
        and e.scope == "setup_and_call_asm"
        for e in arg_bind_edges
    )

    call_arg_node = graph.nodes.get("call_arg:SETUP_BLOCK#0")
    assert call_arg_node is not None
    assert call_arg_node.metadata.get("arg_index") == 0
