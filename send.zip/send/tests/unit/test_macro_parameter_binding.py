import pytest
from macro_expander import MacroExpander
from models.macro_definition import MacroDefinition, MacroParameter
from pathlib import Path


@pytest.fixture
def chkrc_macro():
    """Sample CHKRC macro for testing"""
    return MacroDefinition(
        name="CHKRC",
        parameters=[
            MacroParameter("&LABEL", None, True),
            MacroParameter("&RC", "0", False),
            MacroParameter("&ERROR", "ERROR", False)
        ],
        body=["&LABEL   LTR   R15,R15", "         BNZ   &ERROR"],
        source_file=Path("MACROS.asm"),
        start_line=12,
        end_line=21,
        scope="global"
    )


def test_expander_creation():
    """Test creating macro expander"""
    expander = MacroExpander()
    assert expander is not None


def test_bind_parameters_keyword_style(chkrc_macro):
    """Test binding parameters with keyword style"""
    expander = MacroExpander()

    invocation = "CHKRC RC=4,ERROR=BADCARD"
    bindings = expander.bind_parameters(invocation, chkrc_macro)

    assert bindings["&RC"] == "4"
    assert bindings["&ERROR"] == "BADCARD"
    assert bindings["&LABEL"] == ""  # No label provided


def test_bind_parameters_with_label(chkrc_macro):
    """Test binding parameters with label"""
    expander = MacroExpander()

    invocation = "CHKVAL  CHKRC RC=0,ERROR=BADCARD"
    bindings = expander.bind_parameters(invocation, chkrc_macro)

    assert bindings["&LABEL"] == "CHKVAL"
    assert bindings["&RC"] == "0"
    assert bindings["&ERROR"] == "BADCARD"


def test_bind_parameters_with_defaults(chkrc_macro):
    """Test that default parameter values are used"""
    expander = MacroExpander()

    invocation = "CHKRC ERROR=BADCARD"  # RC not specified, should use default
    bindings = expander.bind_parameters(invocation, chkrc_macro)

    assert bindings["&RC"] == "0"  # Default value
    assert bindings["&ERROR"] == "BADCARD"


def test_bind_parameters_all_defaults(chkrc_macro):
    """Test using all default values"""
    expander = MacroExpander()

    invocation = "CHKRC"  # No parameters, use all defaults
    bindings = expander.bind_parameters(invocation, chkrc_macro)

    assert bindings["&RC"] == "0"
    assert bindings["&ERROR"] == "ERROR"
    assert bindings["&LABEL"] == ""


def test_bind_parameters_positional():
    """Test positional parameter binding"""
    macro = MacroDefinition(
        name="SETRC",
        parameters=[
            MacroParameter("&LABEL", None, True),
            MacroParameter("&RC", None, False)
        ],
        body=["&LABEL   LA    R15,&RC"],
        source_file=Path("MACROS.asm"),
        start_line=44,
        end_line=47,
        scope="global"
    )

    expander = MacroExpander()

    # Positional: SETRC 4
    invocation = "SETRC 4"
    bindings = expander.bind_parameters(invocation, macro)

    assert bindings["&RC"] == "4"
    assert bindings["&LABEL"] == ""


def test_bind_parameters_mixed_positional_keyword():
    """Test mixed positional and keyword parameters"""
    macro = MacroDefinition(
        name="TEST",
        parameters=[
            MacroParameter("&LABEL", None, True),
            MacroParameter("&P1", None, False),
            MacroParameter("&P2", "default", False)
        ],
        body=["NOP"],
        source_file=Path("test.asm"),
        start_line=1,
        end_line=3,
        scope="global"
    )

    expander = MacroExpander()

    # Mixed: TESTLAB  TEST value1,P2=value2
    invocation = "TESTLAB  TEST value1,P2=value2"
    bindings = expander.bind_parameters(invocation, macro)

    assert bindings["&LABEL"] == "TESTLAB"
    assert bindings["&P1"] == "value1"
    assert bindings["&P2"] == "value2"
