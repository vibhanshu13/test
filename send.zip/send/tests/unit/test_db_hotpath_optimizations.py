"""Tests for the backward-lineage DB hot-path optimizations
(docs/plans/2026-06-10-backward-lineage-query-db-hotpath-design.md).

Covers:
- ensure_planner_statistics: builds sqlite_stat1, idempotent, force-refresh.
- T12 canonical-name maps: parity with the original full-stream scan
  (first-match order, missing canonical, same-name short-circuit), for both
  DB-backed and file-backed GVLs.
- extract_tpf_regs_slots: DB prefix range scan parity with the streaming
  scan, including the P3-4 prefix-collision case.
"""
import json

import pytest

from backward_traversal.utils.cpp_lineage_utils import (
    extract_tpf_regs_slots,
    node_terminal_base_lower,
    node_name_base_lower,
)
from backward_traversal.utils.lazy_gvl import DbLazyGVL


# ── shared fixture: tiny index.db + blueprint dir ─────────────────────────────

CANONICAL_NODES = [
    # Matching node WITHOUT canonical_name comes first: the original scan
    # skips it and keeps looking (no break), so the maps must too.
    {"id": "variable:fa::g_sysLimit", "kind": "variable", "name": "g_sysLimit"},
    {"id": "variable:fa::g_sysLimit", "kind": "variable", "name": "g_sysLimit",
     "metadata": {"canonical_name": "SYS_LIMIT"}},
    # Renamed alias of the same canonical in another unit — first
    # canonical-bearing node in emission order wins the reverse map.
    {"id": "variable:fb::sysLimitCap", "kind": "variable", "name": "sysLimitCap",
     "metadata": {"canonical_name": "sys_limit"}},
    # Second node with the same canonical — must NOT displace sysLimitCap.
    {"id": "variable:fc::limitAlias", "kind": "variable", "name": "limitAlias",
     "metadata": {"canonical_name": "sys_limit"}},
    # Non-variable kind with canonical — original scan filters kind first.
    {"id": "struct_field:fa::s->cap", "kind": "struct_field", "name": "cap",
     "metadata": {"canonical_name": "sys_limit"}},
    # Unrelated canonical.
    {"id": "variable:fd::other", "kind": "variable", "name": "other",
     "metadata": {"canonical_name": "other_canon"}},
]

TPF_EDGES = [
    {"source": "struct_field:gl::regs.r7", "target": "register:arg@DW710000:R7",
     "relation": "assign", "file": "/src/a.cpp", "line": 10, "expression": "regs.r7"},
    {"source": "struct_field:gl::regs->r2", "target": "parameter:arg@DW710000:R2",
     "relation": "assign", "file": "/src/a.cpp", "line": 11, "expression": "regs->r2"},
    # P3-4: callee that is a PREFIX of the queried callee must not match
    # (and vice versa) — segment match, not substring.
    {"source": "struct_field:gl::regs.r3", "target": "register:arg@DW71:R3",
     "relation": "assign", "file": "/src/a.cpp", "line": 12, "expression": "regs.r3"},
    {"source": "struct_field:gl::regs.r4", "target": "register:arg@DW710000X:R4",
     "relation": "assign", "file": "/src/a.cpp", "line": 13, "expression": "regs.r4"},
    # Unrelated edge.
    {"source": "memory:X:A", "target": "memory:X:B",
     "relation": "assign", "file": "/src/b.cpp", "line": 1, "expression": "A"},
]


@pytest.fixture()
def hotpath_db(tmp_path, monkeypatch):
    from api.config import settings
    import api.index_db.engine as engine_mod

    monkeypatch.setattr(settings, "JOBS_BASE_DIR", tmp_path)
    monkeypatch.setattr(engine_mod, "_engines", {})

    job_id = "hotjob"
    from api.index_db.engine import get_engine
    from api.index_db.schema import gvl_nodes, gvl_edges

    engine = get_engine(job_id)
    with engine.begin() as conn:
        for n in CANONICAL_NODES:
            extra = {k: v for k, v in n.items() if k not in {"id", "kind", "name"}}
            meta = n.get("metadata") or {}
            conn.execute(gvl_nodes.insert().values(
                job_id=job_id,
                node_id=n["id"], kind=n["kind"], name=n["name"],
                extra_json=json.dumps(extra) if extra else None,
                terminal_base_lower=node_terminal_base_lower(n["id"]) or "",
                name_base_lower=node_name_base_lower(n["name"]) or "",
                asm_alias_lower=str(meta.get("asm_alias") or "").lower(),
            ))
        for e in TPF_EDGES:
            conn.execute(gvl_edges.insert().values(
                job_id=job_id,
                source=e["source"], target=e["target"],
                source_lower=e["source"].lower(), target_lower=e["target"].lower(),
                relation=e["relation"], file=e["file"], line=e["line"],
                expression=e["expression"],
                file_stem="a",
            ))

    db_path = str(tmp_path / job_id / "index.db")
    blueprint_dir = tmp_path / job_id / "output"
    blueprint_dir.mkdir(parents=True, exist_ok=True)
    # Stub C++ blueprints: empty JSON is enough — make_lazy_gvl discovers the
    # sibling index.db via the path hierarchy and serves the global GVL from it.
    for stem in ("fa", "fb"):
        (blueprint_dir / f"{stem}.cpp.json").write_text("{}", encoding="utf-8")

    yield db_path, job_id, blueprint_dir


# ── ensure_planner_statistics ─────────────────────────────────────────────────

def test_ensure_planner_statistics(hotpath_db):
    import sqlite3
    from api.index_db.engine import get_engine, ensure_planner_statistics

    db_path, job_id, _ = hotpath_db
    # get_engine already ran it once at creation (fresh DB → stats built).
    con = sqlite3.connect(db_path)
    try:
        assert con.execute(
            "SELECT name FROM sqlite_master WHERE name='sqlite_stat1'"
        ).fetchone() is not None
    finally:
        con.close()

    engine = get_engine(job_id)
    # Idempotent: a second call with stats present is a no-op (no exception).
    ensure_planner_statistics(engine)
    # Force refresh also succeeds.
    ensure_planner_statistics(engine, force=True)


# ── T12 canonical maps ────────────────────────────────────────────────────────

def _reference_canonical_resolve(nodes, dep_var):
    """The original full-stream T12 logic, kept as the semantic oracle."""
    dep_lower = dep_var.lower()
    src_canonical = None
    for node in nodes:
        if str(node.get("kind", "")).lower() != "variable":
            continue
        nid = str(node.get("id", "") or "").split("::")[-1].strip().lower()
        nname = str(node.get("name", "") or "").strip().lower()
        if nid != dep_lower and nname != dep_lower:
            continue
        cn = str((node.get("metadata") or {}).get("canonical_name") or "").strip().lower()
        if cn:
            src_canonical = cn
            break
    if not src_canonical:
        return None
    for node in nodes:
        if str(node.get("kind", "")).lower() != "variable":
            continue
        cn = str((node.get("metadata") or {}).get("canonical_name") or "").strip().lower()
        if cn != src_canonical:
            continue
        tgt_terminal = str(node.get("name", "") or "").strip().split("::")[-1].strip()
        return tgt_terminal if tgt_terminal.lower() != dep_lower else None
    return None


@pytest.mark.parametrize("dep_var", [
    "g_sysLimit",     # canonical found on 2nd node; first canonical match is itself → None
    "sysLimitCap",    # resolves via canonical, first-bearer is itself → None
    "limitAlias",     # same canonical, maps back to FIRST bearer sysLimitCap
    "other",          # canonical exists, sole bearer → None (same name)
    "missingVar",     # no node → None
])
def test_canonical_resolve_parity_db(hotpath_db, dep_var):
    from backward_traversal.utils.variable_name_resolver import VariableNameResolver

    _, _, blueprint_dir = hotpath_db
    resolver = VariableNameResolver.from_path("", blueprint_dir=blueprint_dir)
    expected = _reference_canonical_resolve(CANONICAL_NODES, dep_var)
    got = resolver._resolve_via_variable_canonical(dep_var, "fa", "fb")
    assert got == expected, f"{dep_var}: got={got!r} expected={expected!r}"


def test_canonical_resolve_db_does_not_stream_nodes(hotpath_db, monkeypatch):
    """The DB branch must use the indexed query, never a full node stream."""
    from backward_traversal.utils.variable_name_resolver import VariableNameResolver
    from backward_traversal.utils import lazy_gvl as lazy_mod

    _, _, blueprint_dir = hotpath_db

    def _boom(self):
        raise AssertionError("full gvl_nodes stream in canonical resolution")

    monkeypatch.setattr(lazy_mod._DbNodeIterable, "__iter__", _boom)
    resolver = VariableNameResolver.from_path("", blueprint_dir=blueprint_dir)
    got = resolver._resolve_via_variable_canonical("limitAlias", "fa", "fb")
    # First canonical bearer in emission order is g_sysLimit (node index 1).
    assert got == "g_sysLimit"


def test_canonical_maps_cached_across_calls(hotpath_db):
    from backward_traversal.utils.variable_name_resolver import VariableNameResolver

    _, _, blueprint_dir = hotpath_db
    resolver = VariableNameResolver.from_path("", blueprint_dir=blueprint_dir)
    resolver._resolve_via_variable_canonical("limitAlias", "fa", "fb")
    # Both blueprint paths and the shared db identity key point at one build.
    keys = set(resolver._canonical_maps_cache)
    db_keys = {k for k in keys if k.startswith("db:")}
    assert len(db_keys) == 1
    maps = {id(resolver._canonical_maps_cache[k]) for k in keys}
    assert len(maps) == 1, "all cache keys must share one maps object"


def test_canonical_resolve_parity_file_backed(tmp_path):
    """File-backed GVL (no index.db in the hierarchy) uses the stream branch."""
    from backward_traversal.utils.variable_name_resolver import VariableNameResolver

    msgpack = pytest.importorskip("msgpack")

    blueprint_dir = tmp_path / "output"
    blueprint_dir.mkdir(parents=True)
    for stem in ("fa", "fb"):
        (blueprint_dir / f"{stem}.cpp.json").write_text("{}", encoding="utf-8")
    # Production GVL files are msgpack (despite the .json name) — LazyGVL
    # detects the format from the first byte and streams via the .midx sidecar.
    (blueprint_dir / "global_variable_lineage.json").write_bytes(
        msgpack.packb({"nodes": CANONICAL_NODES, "edges": []})
    )

    resolver = VariableNameResolver.from_path("", blueprint_dir=blueprint_dir)
    for dep_var in ("g_sysLimit", "limitAlias", "other", "missingVar"):
        expected = _reference_canonical_resolve(CANONICAL_NODES, dep_var)
        got = resolver._resolve_via_variable_canonical(dep_var, "fa", "fb")
        assert got == expected, f"{dep_var}: got={got!r} expected={expected!r}"


# ── extract_tpf_regs_slots ────────────────────────────────────────────────────

def test_tpf_regs_slots_db_parity(hotpath_db):
    db_path, job_id, _ = hotpath_db
    streaming = extract_tpf_regs_slots({"edges": TPF_EDGES}, "DW710000")
    db_backed = extract_tpf_regs_slots(DbLazyGVL(db_path, job_id), "DW710000")
    assert db_backed == streaming
    assert set(db_backed) == {"R7", "R2"}  # prefix collisions DW71/DW710000X excluded


def test_tpf_regs_slots_db_parity_no_match(hotpath_db):
    db_path, job_id, _ = hotpath_db
    assert extract_tpf_regs_slots(DbLazyGVL(db_path, job_id), "NOSUCH") == {}
    assert extract_tpf_regs_slots({"edges": TPF_EDGES}, "NOSUCH") == {}
