import pytest
from passes.data_flow_tracker import DataFlowTracker
from tokenizer import ParsedLine
from models.provenance import StatementProvenance
from models.register_state import ValueType


def test_data_flow_tracker_load_literal():
    """Test tracking L instruction with literal"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # L R15,=V(DBREAD)
    line = ParsedLine(
        label=None,
        opcode="L",
        operands=["R15", "=V(DBREAD)"],
        comment=None,
        provenance=provenance
    )

    tracker.process_line(line, current_section="MAIN")

    # R15 should now hold a literal
    value = tracker.register_state.get_register("R15")
    assert value.value_type == ValueType.LITERAL
    assert value.literal == "=V(DBREAD)"


def test_data_flow_tracker_load_register():
    """Test tracking LR instruction (register copy)"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # First load a literal into R15
    line1 = ParsedLine(
        label=None,
        opcode="L",
        operands=["R15", "=V(DBREAD)"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line1, current_section="MAIN")

    # Then copy R15 to R1 via LR
    line2 = ParsedLine(
        label=None,
        opcode="LR",
        operands=["R1", "R15"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line2, current_section="MAIN")

    # R1 should now hold the same literal as R15
    value = tracker.register_state.get_register("R1")
    assert value.value_type == ValueType.LITERAL
    assert value.literal == "=V(DBREAD)"


def test_data_flow_tracker_load_address():
    """Test tracking LA instruction"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # LA R1,HELPER
    line = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R1", "HELPER"],
        comment=None,
        provenance=provenance
    )

    tracker.process_line(line, current_section="MAIN")

    # R1 should now hold a symbol address
    value = tracker.register_state.get_register("R1")
    assert value.value_type == ValueType.ADDRESS
    assert value.address == "HELPER"


def test_data_flow_tracker_unknown_instruction():
    """Test that unknown instructions don't crash tracker"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # AR R1,R2 (add register - we don't track this yet)
    line = ParsedLine(
        label=None,
        opcode="AR",
        operands=["R1", "R2"],
        comment=None,
        provenance=provenance
    )

    # Should not crash
    tracker.process_line(line, current_section="MAIN")

    # R1 should remain UNKNOWN
    value = tracker.register_state.get_register("R1")
    assert value.value_type == ValueType.UNKNOWN


def test_resolve_indirect_call():
    """Test resolving indirect call pattern"""
    from models.analysis_context import AnalysisContext
    from models.call_graph import CallGraph, CallType

    context = AnalysisContext()
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    # Create a call graph with an indirect call
    call_graph = CallGraph()
    call_graph.add_edge(
        source="MAIN",
        target=None,
        call_type=CallType.SUBROUTINE_CALL,
        instruction="BASR",
        file="test.asm",
        line=20,
        is_indirect=True,
        register="R15"
    )
    context.add_metadata("call_graph", call_graph)

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="L",
            operands=["R15", "=V(DBREAD)"],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="BASR",
            operands=["R14", "R15"],
            comment=None,
            provenance=provenance
        ),
    ]

    tracker.process(lines, context)

    # Verify indirect call was resolved
    resolved_calls = context.metadata.get("resolved_indirect_calls", [])
    assert len(resolved_calls) > 0
    assert resolved_calls[0]["register"] == "R15"
    assert resolved_calls[0]["target"] == "DBREAD"


def test_data_flow_tracker_store():
    """Test tracking ST (store) instruction"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # Load a value into R1
    line1 = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R1", "DATA"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line1, current_section="MAIN")

    # Store R1 to memory
    line2 = ParsedLine(
        label=None,
        opcode="ST",
        operands=["R1", "WORKAREA"],
        comment=None,
        provenance=provenance
    )

    # Should not crash
    tracker.process_line(line2, current_section="MAIN")

    # R1 should still have its value
    value = tracker.register_state.get_register("R1")
    assert value.value_type == ValueType.ADDRESS
    assert value.address == "DATA"


def test_data_flow_tracker_store_multiple():
    """Test tracking STM (store multiple) instruction"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # Load values into registers
    for reg_num in range(14, 16):
        line = ParsedLine(
            label=None,
            opcode="LA",
            operands=[f"R{reg_num}", "DATA"],
            comment=None,
            provenance=provenance
        )
        tracker.process_line(line, current_section="MAIN")

    # Store multiple registers
    line_stm = ParsedLine(
        label=None,
        opcode="STM",
        operands=["R14", "R15", "SAVEAREA"],
        comment=None,
        provenance=provenance
    )

    # Should not crash
    tracker.process_line(line_stm, current_section="MAIN")

    # Registers should still have their values
    assert tracker.register_state.get_register("R14").value_type == ValueType.ADDRESS
    assert tracker.register_state.get_register("R15").value_type == ValueType.ADDRESS


def test_data_flow_tracker_store_halfword():
    """Test tracking STH (store halfword) instruction"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # Load a value into R2
    line1 = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R2", "SYMBOL"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line1, current_section="MAIN")

    # Store halfword from R2
    line2 = ParsedLine(
        label=None,
        opcode="STH",
        operands=["R2", "BUFFER"],
        comment=None,
        provenance=provenance
    )

    # Should not crash
    tracker.process_line(line2, current_section="MAIN")

    # R2 should still have its value
    value = tracker.register_state.get_register("R2")
    assert value.value_type == ValueType.ADDRESS
    assert value.address == "SYMBOL"


def test_data_flow_tracker_mixed_load_and_store():
    """Test mixed load and store operations"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # LA R1,SOURCE
    line1 = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R1", "SOURCE"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line1, current_section="MAIN")

    # LR R2,R1 (copy R1 to R2)
    line2 = ParsedLine(
        label=None,
        opcode="LR",
        operands=["R2", "R1"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line2, current_section="MAIN")

    # ST R2,TARGET
    line3 = ParsedLine(
        label=None,
        opcode="ST",
        operands=["R2", "TARGET"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line3, current_section="MAIN")

    # Both R1 and R2 should have the same value
    r1_value = tracker.register_state.get_register("R1")
    r2_value = tracker.register_state.get_register("R2")

    assert r1_value.value_type == ValueType.ADDRESS
    assert r2_value.value_type == ValueType.ADDRESS
    assert r1_value.address == "SOURCE"
    assert r2_value.address == "SOURCE"


def test_data_flow_tracker_move_characters():
    """Test tracking MVC (move characters) instruction"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # MVC TARGET(10),SOURCE
    line = ParsedLine(
        label=None,
        opcode="MVC",
        operands=["TARGET(10)", "SOURCE"],
        comment=None,
        provenance=provenance
    )

    # Should not crash
    tracker.process_line(line, current_section="MAIN")

    # This is a memory-to-memory operation
    # Register state should not be affected (unless we track memory)


def test_data_flow_tracker_move_long():
    """Test tracking MVCL (move long) instruction"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # Load source address into R2
    line1 = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R2", "SOURCE"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line1, current_section="MAIN")

    # Load destination address into R0
    line2 = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R0", "DEST"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line2, current_section="MAIN")

    # MVCL R0,R2
    line3 = ParsedLine(
        label=None,
        opcode="MVCL",
        operands=["R0", "R2"],
        comment=None,
        provenance=provenance
    )

    # Should not crash
    tracker.process_line(line3, current_section="MAIN")

    # Registers should still have their addresses
    r0_value = tracker.register_state.get_register("R0")
    r2_value = tracker.register_state.get_register("R2")
    assert r0_value.value_type == ValueType.ADDRESS
    assert r2_value.value_type == ValueType.ADDRESS


def test_data_flow_tracker_move_inverse():
    """Test tracking MVCIN (move inverse) instruction"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # MVCIN DEST(8),SOURCE
    line = ParsedLine(
        label=None,
        opcode="MVCIN",
        operands=["DEST(8)", "SOURCE"],
        comment=None,
        provenance=provenance
    )

    # Should not crash
    tracker.process_line(line, current_section="MAIN")

    # This is a memory-to-memory operation
    # Register state should not be affected


def test_data_flow_tracker_complex_data_movement():
    """Test complex sequence with loads, stores, and moves"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # LA R3,BUFFER
    line1 = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R3", "BUFFER"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line1, current_section="MAIN")

    # MVC 0(10,R3),INDATA
    line2 = ParsedLine(
        label=None,
        opcode="MVC",
        operands=["0(10,R3)", "INDATA"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line2, current_section="MAIN")

    # ST R3,SAVEPTR
    line3 = ParsedLine(
        label=None,
        opcode="ST",
        operands=["R3", "SAVEPTR"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line3, current_section="MAIN")

    # R3 should still have BUFFER address
    r3_value = tracker.register_state.get_register("R3")
    assert r3_value.value_type == ValueType.ADDRESS
    assert r3_value.address == "BUFFER"


def test_data_flow_tracker_arithmetic_add():
    """Test tracking arithmetic add operations"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # Load a value into R1
    line1 = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R1", "VALUE"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line1, current_section="MAIN")

    # AR R1,R2 (add R2 to R1)
    line2 = ParsedLine(
        label=None,
        opcode="AR",
        operands=["R1", "R2"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line2, current_section="MAIN")

    # After arithmetic, R1 should be marked as UNKNOWN (computed value)
    r1_value = tracker.register_state.get_register("R1")
    assert r1_value.value_type == ValueType.UNKNOWN


def test_data_flow_tracker_arithmetic_subtract():
    """Test tracking arithmetic subtract operations"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # Load a value into R3
    line1 = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R3", "DATA"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line1, current_section="MAIN")

    # SR R3,R4 (subtract R4 from R3)
    line2 = ParsedLine(
        label=None,
        opcode="SR",
        operands=["R3", "R4"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line2, current_section="MAIN")

    # After arithmetic, R3 should be marked as UNKNOWN
    r3_value = tracker.register_state.get_register("R3")
    assert r3_value.value_type == ValueType.UNKNOWN


def test_data_flow_tracker_logical_and():
    """Test tracking logical AND operations"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # Load a value into R5
    line1 = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R5", "MASK"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line1, current_section="MAIN")

    # NR R5,R6 (AND R5 with R6)
    line2 = ParsedLine(
        label=None,
        opcode="NR",
        operands=["R5", "R6"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line2, current_section="MAIN")

    # After logical operation, R5 should be marked as UNKNOWN
    r5_value = tracker.register_state.get_register("R5")
    assert r5_value.value_type == ValueType.UNKNOWN


def test_data_flow_tracker_logical_or():
    """Test tracking logical OR operations"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # Load a value into R7
    line1 = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R7", "FLAGS"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line1, current_section="MAIN")

    # OR R7,R8 (OR R7 with R8)
    line2 = ParsedLine(
        label=None,
        opcode="OR",
        operands=["R7", "R8"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line2, current_section="MAIN")

    # After logical operation, R7 should be marked as UNKNOWN
    r7_value = tracker.register_state.get_register("R7")
    assert r7_value.value_type == ValueType.UNKNOWN


def test_data_flow_tracker_shift():
    """Test tracking shift operations"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # Load a value into R9
    line1 = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R9", "VALUE"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line1, current_section="MAIN")

    # SLA R9,4 (shift left arithmetic by 4 bits)
    line2 = ParsedLine(
        label=None,
        opcode="SLA",
        operands=["R9", "4"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line2, current_section="MAIN")

    # After shift, R9 should be marked as UNKNOWN
    r9_value = tracker.register_state.get_register("R9")
    assert r9_value.value_type == ValueType.UNKNOWN


def test_data_flow_tracker_complex_transformations():
    """Test complex sequence with multiple transformations"""
    tracker = DataFlowTracker()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    # LA R10,BASE
    line1 = ParsedLine(
        label=None,
        opcode="LA",
        operands=["R10", "BASE"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line1, current_section="MAIN")

    # AR R10,R11 (add offset)
    line2 = ParsedLine(
        label=None,
        opcode="AR",
        operands=["R10", "R11"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line2, current_section="MAIN")

    # NR R10,R12 (mask)
    line3 = ParsedLine(
        label=None,
        opcode="NR",
        operands=["R10", "R12"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line3, current_section="MAIN")

    # SLL R10,2 (shift left logical)
    line4 = ParsedLine(
        label=None,
        opcode="SLL",
        operands=["R10", "2"],
        comment=None,
        provenance=provenance
    )
    tracker.process_line(line4, current_section="MAIN")

    # After all transformations, R10 should be marked as UNKNOWN
    r10_value = tracker.register_state.get_register("R10")
    assert r10_value.value_type == ValueType.UNKNOWN
