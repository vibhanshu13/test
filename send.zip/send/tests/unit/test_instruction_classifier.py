import pytest
from instruction_classifier import InstructionClassifier, ControlFlowType


def test_classify_bal_instruction():
    """Test classifying BAL (Branch and Link)"""
    classifier = InstructionClassifier()

    result = classifier.classify("BAL")

    assert result == ControlFlowType.SUBROUTINE_CALL


def test_classify_balr_instruction():
    """Test classifying BALR (Branch and Link Register)"""
    classifier = InstructionClassifier()

    result = classifier.classify("BALR")

    assert result == ControlFlowType.SUBROUTINE_CALL


def test_classify_branch_instructions():
    """Test classifying branch instructions"""
    classifier = InstructionClassifier()

    assert classifier.classify("B") == ControlFlowType.BRANCH
    assert classifier.classify("BC") == ControlFlowType.BRANCH
    assert classifier.classify("BCR") == ControlFlowType.BRANCH
    assert classifier.classify("BZ") == ControlFlowType.BRANCH
    assert classifier.classify("BNZ") == ControlFlowType.BRANCH


def test_classify_mode_transition():
    """Test classifying mode transition instructions"""
    classifier = InstructionClassifier()

    assert classifier.classify("BASSM") == ControlFlowType.MODE_TRANSITION
    assert classifier.classify("BASM") == ControlFlowType.MODE_TRANSITION
    assert classifier.classify("BSM") == ControlFlowType.MODE_TRANSITION


def test_classify_execute():
    """Test classifying EX instruction"""
    classifier = InstructionClassifier()

    assert classifier.classify("EX") == ControlFlowType.EXECUTE


def test_classify_non_control_flow():
    """Test non-control-flow instructions return None"""
    classifier = InstructionClassifier()

    assert classifier.classify("L") is None
    assert classifier.classify("LA") is None
    assert classifier.classify("MVC") is None


def test_is_return_instruction():
    """Test identifying return patterns"""
    classifier = InstructionClassifier()

    # BR R14 is a return
    assert classifier.is_return("BR", ["R14"]) is True
    assert classifier.is_return("BR", ["14"]) is True

    # BR with other registers is not a return
    assert classifier.is_return("BR", ["R15"]) is False
    assert classifier.is_return("BR", ["1"]) is False


def test_is_indirect_call():
    """Test identifying indirect calls"""
    classifier = InstructionClassifier()

    # BALR R14,R15 is indirect (target in register)
    assert classifier.is_indirect("BALR", ["R14", "R15"]) is True

    # BASR R14,R15 is indirect
    assert classifier.is_indirect("BASR", ["R14", "R15"]) is True

    # BAL R14,TARGET is direct (has label)
    assert classifier.is_indirect("BAL", ["R14", "TARGET"]) is False
