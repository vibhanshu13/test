import pytest
from passes.symbol_resolver import SymbolResolverPass
from models.analysis_context import AnalysisContext
from models.provenance import StatementProvenance
from models.symbol import SymbolType
from tokenizer import ParsedLine


def test_symbol_resolver_basic():
    """Test basic symbol resolution"""
    context = AnalysisContext()
    resolver = SymbolResolverPass()

    provenance1 = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=1
    )

    provenance2 = StatementProvenance(
        statement_id="S002",
        original_file="test.asm",
        original_line=2
    )

    lines = [
        ParsedLine(
            label=None,
            opcode="ENTRY",
            operands=["MAIN"],
            comment=None,
            provenance=provenance1
        ),
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance2
        ),
    ]

    resolver.process(lines, context)

    # Verify symbol exists
    # Note: When both ENTRY and CSECT have same name, CSECT overwrites ENTRY
    # This is realistic - MAIN is both an entry point and a section
    main_sym = context.symbol_table.resolve("MAIN")
    assert main_sym is not None
    assert main_sym.name == "MAIN"
    # In this case, CSECT is added after ENTRY, so it wins
    assert main_sym.symbol_type == SymbolType.CSECT

    # Verify symbol is in global symbols table
    symbols = context.symbol_table.global_symbols
    assert "MAIN" in symbols


def test_symbol_resolver_with_sections():
    """Test symbol resolution with section tracking"""
    context = AnalysisContext()
    resolver = SymbolResolverPass()

    provenance1 = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    provenance2 = StatementProvenance(
        statement_id="S002",
        original_file="test.asm",
        original_line=20
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance1
        ),
        ParsedLine(
            label="MAXLEN",
            opcode="EQU",
            operands=["256"],
            comment=None,
            provenance=provenance2
        ),
    ]

    resolver.process(lines, context)

    # Verify EQU is scoped to MAIN section
    equ_sym = context.symbol_table.resolve("MAXLEN", context="MAIN")
    assert equ_sym is not None
    assert equ_sym.value == 256
    assert equ_sym.section == "MAIN"


def test_symbol_to_file_mapping():
    """Test symbol_to_file mapping is populated"""
    context = AnalysisContext()
    resolver = SymbolResolverPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="utils.asm",
        original_line=5
    )

    lines = [
        ParsedLine(
            label=None,
            opcode="ENTRY",
            operands=["HELPER"],
            comment=None,
            provenance=provenance
        ),
    ]

    resolver.process(lines, context)

    assert context.symbol_table.symbol_to_file["HELPER"] == "utils.asm"
