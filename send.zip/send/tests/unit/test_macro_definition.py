import pytest
from models.macro_definition import MacroDefinition, MacroParameter


def test_macro_parameter_creation():
    """Test basic macro parameter creation"""
    param = MacroParameter(
        name="&RC",
        default_value="0",
        is_label=False
    )

    assert param.name == "&RC"
    assert param.default_value == "0"
    assert param.is_label is False


def test_macro_parameter_label():
    """Test label parameter creation"""
    param = MacroParameter(
        name="&LABEL",
        default_value=None,
        is_label=True
    )

    assert param.name == "&LABEL"
    assert param.default_value is None
    assert param.is_label is True


def test_macro_definition_creation():
    """Test basic macro definition creation"""
    from pathlib import Path

    params = [
        MacroParameter("&LABEL", None, True),
        MacroParameter("&RC", "0", False),
        MacroParameter("&ERROR", "ERROR", False)
    ]

    macro = MacroDefinition(
        name="CHKRC",
        parameters=params,
        body=["LTR   R15,R15", "BNZ   &ERROR"],
        source_file=Path("MACROS.asm"),
        start_line=12,
        end_line=21,
        scope="global"
    )

    assert macro.name == "CHKRC"
    assert len(macro.parameters) == 3
    assert macro.scope == "global"
    assert macro.start_line == 12
    assert macro.end_line == 21


def test_macro_definition_to_dict():
    """Test serialization to dictionary"""
    from pathlib import Path

    params = [MacroParameter("&RC", "0", False)]
    macro = MacroDefinition(
        name="SETRC",
        parameters=params,
        body=["LA    R15,&RC"],
        source_file=Path("MACROS.asm"),
        start_line=44,
        end_line=47,
        scope="local"
    )

    result = macro.to_dict()

    assert result["name"] == "SETRC"
    assert result["scope"] == "local"
    assert "source_file" in result
    assert "parameters" in result
    assert len(result["parameters"]) == 1
