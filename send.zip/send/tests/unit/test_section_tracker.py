import pytest
from section_tracker import SectionTracker, Section


def test_enter_section():
    """Test entering a new section"""
    tracker = SectionTracker()

    tracker.enter_section("MAIN", "CSECT", 10, "main.asm")

    assert tracker.current_section == "MAIN"
    assert tracker.current_section_type == "CSECT"


def test_section_boundaries():
    """Test tracking section start and end"""
    tracker = SectionTracker()

    tracker.enter_section("MAIN", "CSECT", 10, "main.asm")
    tracker.exit_section(50)

    section = tracker.get_section("MAIN")
    assert section.name == "MAIN"
    assert section.section_type == "CSECT"
    assert section.start_line == 10
    assert section.end_line == 50
    assert section.file == "main.asm"


def test_nested_sections():
    """Test handling nested sections (DSECT inside CSECT)"""
    tracker = SectionTracker()

    tracker.enter_section("MAIN", "CSECT", 10, "main.asm")
    tracker.enter_section("DATA", "DSECT", 20, "main.asm")
    tracker.exit_section(30)

    assert tracker.current_section == "MAIN"
    assert tracker.get_section("DATA").end_line == 30


def test_get_all_sections():
    """Test retrieving all sections"""
    tracker = SectionTracker()

    tracker.enter_section("MAIN", "CSECT", 10, "main.asm")
    tracker.exit_section(30)
    tracker.enter_section("UTILS", "CSECT", 40, "utils.asm")
    tracker.exit_section(60)

    sections = tracker.get_all_sections()
    assert len(sections) == 2
    assert "MAIN" in [s.name for s in sections]
    assert "UTILS" in [s.name for s in sections]
