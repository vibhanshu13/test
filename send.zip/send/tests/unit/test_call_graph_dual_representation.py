from pathlib import Path
from passes.call_graph_builder import CallGraphBuilderPass
from models.analysis_context import AnalysisContext
from models.macro_expansion import ExpansionResult, ExpandedInstruction, MacroProvenance


def _context_with_macro_call():
    ctx = AnalysisContext(file_path=Path("test.asm"))

    instr1 = ExpandedInstruction(
        instruction="LTR   R15,R15",
        label=None,
        parameter_substitutions=[],
        provenance=MacroProvenance(
            invocation_file="test.asm",
            invocation_line=10,
            invocation_macro="CHKRC",
            definition_file="MACROS.asm",
            definition_line=12
        )
    )

    instr2 = ExpandedInstruction(
        instruction="BNZ   ERROR",
        label=None,
        parameter_substitutions=[],
        provenance=MacroProvenance(
            invocation_file="test.asm",
            invocation_line=10,
            invocation_macro="CHKRC",
            definition_file="MACROS.asm",
            definition_line=13
        )
    )

    expansion = ExpansionResult(
        expansion_id="expansion_1",
        invocation="CHKRC RC=0,ERROR=ERROR",
        invocation_file="test.asm",
        invocation_line=10,
        macro_name="CHKRC",
        definition_file="MACROS.asm",
        definition_line_start=12,
        definition_line_end=21,
        expansion_status="success",
        parameters={"&RC": "0", "&ERROR": "ERROR"},
        expanded_instructions=[instr1, instr2],
        error=None
    )

    ctx.macro_expansions = [expansion]
    return ctx


def test_build_collapsed_call_graph():
    ctx = _context_with_macro_call()
    builder = CallGraphBuilderPass()

    # No parsed lines; just ensure expanded graphs can be built
    builder.build_expanded_graphs(ctx)

    expansion = ctx.macro_expansions[0]
    assert hasattr(expansion, 'expanded_call_graph')


def test_expanded_call_graph_structure():
    ctx = _context_with_macro_call()
    builder = CallGraphBuilderPass()

    builder.build_expanded_graphs(ctx)

    expansion = ctx.macro_expansions[0]
    expanded_graph = expansion.expanded_call_graph

    assert expanded_graph is not None
    assert "nodes" in expanded_graph
    assert "edges" in expanded_graph


def test_json_output_includes_expanded_graphs():
    ctx = _context_with_macro_call()
    builder = CallGraphBuilderPass()

    builder.build_expanded_graphs(ctx)

    expansion = ctx.macro_expansions[0]
    expansion_dict = expansion.to_dict()

    assert "expanded_call_graph" in expansion_dict
    assert expansion_dict["expanded_call_graph"]["nodes"] is not None
