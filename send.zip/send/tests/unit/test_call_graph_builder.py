import pytest
from passes.call_graph_builder import CallGraphBuilderPass
from models.analysis_context import AnalysisContext
from models.provenance import StatementProvenance
from models.call_graph import CallType
from tokenizer import ParsedLine


def test_call_graph_builder_basic():
    """Test basic call detection"""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="BAL",
            operands=["R14", "HELPER"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)

    # Verify call graph exists
    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    # Verify edge was created
    assert len(call_graph.edges) == 1
    edge = call_graph.edges[0]
    assert edge.source == "MAIN"
    assert edge.target == "HELPER"
    assert edge.call_type == CallType.SUBROUTINE_CALL
    assert call_graph.nodes["MAIN"].kind == "control_section"
    assert call_graph.nodes["HELPER"].kind == "routine"


def test_call_graph_builder_indirect_call():
    """Test indirect call detection"""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="BASR",
            operands=["R14", "R15"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)

    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    # Verify indirect call was flagged
    indirect_calls = call_graph.get_indirect_calls()
    assert len(indirect_calls) == 1
    assert indirect_calls[0].is_indirect is True
    assert indirect_calls[0].register == "R15"


def test_call_graph_builder_return_detection():
    """Test return instruction detection"""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    lines = [
        ParsedLine(
            label="HELPER",
            opcode="DS",
            operands=["0H"],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="BR",
            operands=["R14"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)

    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    # Verify return edge was created
    return_edges = [e for e in call_graph.edges if e.call_type == CallType.RETURN]
    assert len(return_edges) == 1


def test_call_graph_builder_ztpf_macro():
    """Test z/TPF system macro detection"""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="ENTER",
            operands=["R11"],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="MALOC",
            operands=["R2", "256"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)

    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    # Verify macro invocations were tracked
    macro_edges = [e for e in call_graph.edges if e.call_type == CallType.MACRO_INVOCATION]
    assert len(macro_edges) == 2

    # Verify ENTER macro
    enter_edges = [e for e in macro_edges if e.target == "ENTER"]
    assert len(enter_edges) == 1
    assert enter_edges[0].source == "MAIN"
    assert call_graph.nodes["ENTER"].kind == "macro"

    # Verify MALOC macro
    maloc_edges = [e for e in macro_edges if e.target == "MALOC"]
    assert len(maloc_edges) == 1
    assert maloc_edges[0].source == "MAIN"


def test_call_graph_builder_macro_level_number_from_level_operand():
    """Macro invocation should capture LEVEL=... in edge metadata."""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="LEVTA",
            operands=["LEVEL=0", "NOTUSED=R8"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)
    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    levta_edges = [e for e in call_graph.edges if e.target == "LEVTA"]
    assert len(levta_edges) == 1
    assert levta_edges[0].call_type == CallType.MACRO_INVOCATION
    assert levta_edges[0].level_number == 0


def test_call_graph_builder_callcpp_bridges_to_function_call():
    """CALLCPP should create a function-call edge to C/C++ target symbol."""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=33
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="CALLCPP",
            operands=["ENTRY=CPP_AUTHZN"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)
    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    call_edges = [e for e in call_graph.edges if e.instruction == "CALLCPP"]
    assert len(call_edges) == 1
    assert call_edges[0].call_type == CallType.CALL
    assert call_edges[0].target == "CPP_AUTHZN"
    assert call_graph.nodes["CPP_AUTHZN"].kind == "function"
    assert call_graph.nodes["CPP_AUTHZN"].is_external is True


def test_call_graph_builder_macro_level_number_from_level_marked_value():
    """Macro invocation should capture LEVEL markers embedded in values."""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="ENTER",
            operands=["DATA=LEVEL9"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)
    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    enter_edges = [e for e in call_graph.edges if e.target == "ENTER"]
    assert len(enter_edges) == 1
    assert enter_edges[0].call_type == CallType.MACRO_INVOCATION
    assert enter_edges[0].level_number == 9


def test_call_graph_builder_macro_level_number_from_hex_d_level():
    """Macro invocation should parse D-level markers up to DF as hexadecimal."""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="GETCC",
            operands=["DF"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)
    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    edges = [e for e in call_graph.edges if e.target == "GETCC"]
    assert len(edges) == 1
    assert edges[0].level_number == 15


def test_call_graph_builder_ztpfdf_macro():
    """Test z/TPFDF database macro detection"""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    lines = [
        ParsedLine(
            label="DBREAD",
            opcode="DS",
            operands=["0H"],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="DBRED",
            operands=["FILE1", "KEY1"],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="DBWRT",
            operands=["FILE2", "DATA"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)

    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    # Verify macro invocations were tracked
    macro_edges = [e for e in call_graph.edges if e.call_type == CallType.MACRO_INVOCATION]
    assert len(macro_edges) == 2

    # Verify DBRED macro
    dbred_edges = [e for e in macro_edges if e.target == "DBRED"]
    assert len(dbred_edges) == 1

    # Verify DBWRT macro
    dbwrt_edges = [e for e in macro_edges if e.target == "DBWRT"]
    assert len(dbwrt_edges) == 1


def test_call_graph_builder_mixed_calls_and_macros():
    """Test mixed subroutine calls and macro invocations"""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="ENTER",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="BAL",
            operands=["R14", "HELPER"],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="DBRED",
            operands=["FILE1"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)

    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    # Verify all edges were tracked
    assert len(call_graph.edges) == 3

    # Verify types
    subroutine_edges = [e for e in call_graph.edges if e.call_type == CallType.SUBROUTINE_CALL]
    macro_edges = [e for e in call_graph.edges if e.call_type == CallType.MACRO_INVOCATION]

    assert len(subroutine_edges) == 1
    assert len(macro_edges) == 2
    assert subroutine_edges[0].target == "HELPER"


def test_call_graph_builder_external_c_function():
    """Test external C function detection"""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="BAL",
            operands=["R14", "sprintf"],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="BRAS",
            operands=["R14", "memcpy"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)

    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    # Verify external nodes were created
    assert "sprintf" in call_graph.nodes
    assert "memcpy" in call_graph.nodes

    # Verify they are marked as external
    assert call_graph.nodes["sprintf"].is_external is True
    assert call_graph.nodes["memcpy"].is_external is True

    # Verify edges were created
    assert len(call_graph.edges) == 2


def test_call_graph_builder_external_zos_service():
    """Test external z/OS service detection"""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="BAL",
            operands=["R14", "STORAGE"],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="BRAS",
            operands=["R14", "GETMAIN"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)

    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    # Verify external nodes were created
    assert "STORAGE" in call_graph.nodes
    assert "GETMAIN" in call_graph.nodes

    # Verify they are marked as external
    assert call_graph.nodes["STORAGE"].is_external is True
    assert call_graph.nodes["GETMAIN"].is_external is True


def test_call_graph_builder_mixed_local_and_external():
    """Test mixed local and external calls"""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="BAL",
            operands=["R14", "HELPER"],  # Local routine
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="BRAS",
            operands=["R14", "sprintf"],  # External C function
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="BAL",
            operands=["R14", "STORAGE"],  # External z/OS service
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)

    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    # Verify all nodes were created
    assert "HELPER" in call_graph.nodes
    assert "sprintf" in call_graph.nodes
    assert "STORAGE" in call_graph.nodes

    # Verify external marking
    assert call_graph.nodes["HELPER"].is_external is False  # Local
    assert call_graph.nodes["sprintf"].is_external is True  # External C function
    assert call_graph.nodes["STORAGE"].is_external is True  # External z/OS service

    # Verify edges
    assert len(call_graph.edges) == 3


def test_call_graph_builder_branch_target_uses_last_operand():
    """Branch forms like BCT should use symbolic target operand."""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=StatementProvenance(
                statement_id="S001",
                original_file="test.asm",
                original_line=10,
            ),
        ),
        ParsedLine(
            label=None,
            opcode="BCT",
            operands=["R5", "LOOPTOP"],
            comment=None,
            provenance=StatementProvenance(
                statement_id="S002",
                original_file="test.asm",
                original_line=11,
            ),
        ),
    ]

    builder.process(lines, context)
    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    branch_edges = [e for e in call_graph.edges if e.call_type == CallType.BRANCH]
    assert len(branch_edges) == 1
    assert branch_edges[0].target == "LOOPTOP"


def test_call_graph_builder_branch_register_target_skipped():
    """Register-only branches should not create symbolic routine edges."""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=StatementProvenance(
                statement_id="S001",
                original_file="test.asm",
                original_line=10,
            ),
        ),
        ParsedLine(
            label=None,
            opcode="BCR",
            operands=["15", "R11"],
            comment=None,
            provenance=StatementProvenance(
                statement_id="S002",
                original_file="test.asm",
                original_line=11,
            ),
        ),
    ]

    builder.process(lines, context)
    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    branch_edges = [e for e in call_graph.edges if e.call_type == CallType.BRANCH]
    assert len(branch_edges) == 0


def test_call_graph_builder_entnc_is_no_return_call():
    """ENTNC should be modeled as a no-return transfer edge."""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=10
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="ENTNC",
            operands=["FINALSEG"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)
    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    edges = [e for e in call_graph.edges if e.instruction == "ENTNC"]
    assert len(edges) == 1
    assert edges[0].target == "FINALSEG"
    assert edges[0].call_type == CallType.NO_RETURN_CALL


def test_call_graph_builder_creec_is_async_spawn():
    """CREEC should be modeled as an async spawn edge."""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=42
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="CREEC",
            operands=["GA71", "D0", "R"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)
    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    edges = [e for e in call_graph.edges if e.instruction == "CREEC"]
    assert len(edges) == 1
    assert edges[0].target == "GA71"
    assert edges[0].call_type == CallType.ASYNC_SPAWN
    assert edges[0].level_number == 0


@pytest.mark.parametrize("opcode", ["ATTAC", "ATTC"])
def test_call_graph_builder_attac_variants_are_async_spawn(opcode):
    """ATTAC/ATTC should be modeled as async spawn edges."""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=52
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode=opcode,
            operands=["ENTRY=CHILDSEG", "D4", "R7"],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)
    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    edges = [e for e in call_graph.edges if e.instruction == opcode]
    assert len(edges) == 1
    assert edges[0].target == "CHILDSEG"
    assert edges[0].call_type == CallType.ASYNC_SPAWN
    assert edges[0].level_number == 4


def test_call_graph_builder_backc_detected_as_return():
    """BACKC should be treated as a return boundary."""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=77
    )

    lines = [
        ParsedLine(
            label="FROM_CPP",
            opcode="DS",
            operands=["0H"],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode="BACKC",
            operands=[],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)
    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    return_edges = [e for e in call_graph.edges if e.call_type == CallType.RETURN]
    assert len(return_edges) == 1
    assert return_edges[0].instruction == "BACKC"


@pytest.mark.parametrize("opcode", ["EXIT", "EXITC", "RETURN", "RETRN"])
def test_call_graph_builder_exit_family_macros_are_returns(opcode):
    """EXIT-family macros should produce return edges."""
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    provenance = StatementProvenance(
        statement_id="S001",
        original_file="test.asm",
        original_line=88
    )

    lines = [
        ParsedLine(
            label="MAIN",
            opcode="CSECT",
            operands=[],
            comment=None,
            provenance=provenance
        ),
        ParsedLine(
            label=None,
            opcode=opcode,
            operands=[],
            comment=None,
            provenance=provenance
        ),
    ]

    builder.process(lines, context)
    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    return_edges = [e for e in call_graph.edges if e.call_type == CallType.RETURN and e.instruction == opcode]
    assert len(return_edges) == 1
    assert return_edges[0].target is None
