import pytest
from models.register_state import RegisterState, RegisterValue, ValueType


def test_register_state_creation():
    """Test creating register state"""
    state = RegisterState()

    # All registers should be unknown initially
    for i in range(16):
        value = state.get_register(f"R{i}")
        assert value.value_type == ValueType.UNKNOWN


def test_set_register_literal():
    """Test setting register to a literal value"""
    state = RegisterState()

    state.set_register("R15", RegisterValue(
        value_type=ValueType.LITERAL,
        literal="=V(DBREAD)"
    ))

    value = state.get_register("R15")
    assert value.value_type == ValueType.LITERAL
    assert value.literal == "=V(DBREAD)"


def test_set_register_symbol():
    """Test setting register to a symbol"""
    state = RegisterState()

    state.set_register("R1", RegisterValue(
        value_type=ValueType.SYMBOL,
        symbol="HELPER"
    ))

    value = state.get_register("R1")
    assert value.value_type == ValueType.SYMBOL
    assert value.symbol == "HELPER"


def test_copy_register():
    """Test copying value from one register to another"""
    state = RegisterState()

    state.set_register("R15", RegisterValue(
        value_type=ValueType.SYMBOL,
        symbol="TARGET"
    ))

    state.copy_register("R1", "R15")

    value = state.get_register("R1")
    assert value.value_type == ValueType.SYMBOL
    assert value.symbol == "TARGET"


def test_clear_register():
    """Test clearing a register"""
    state = RegisterState()

    state.set_register("R15", RegisterValue(
        value_type=ValueType.SYMBOL,
        symbol="TARGET"
    ))

    state.clear_register("R15")

    value = state.get_register("R15")
    assert value.value_type == ValueType.UNKNOWN


def test_register_aliases():
    """Test that numeric register names work"""
    state = RegisterState()

    state.set_register("15", RegisterValue(
        value_type=ValueType.SYMBOL,
        symbol="TARGET"
    ))

    # Should be retrievable as both R15 and 15
    value = state.get_register("R15")
    assert value.symbol == "TARGET"

    value = state.get_register("15")
    assert value.symbol == "TARGET"
