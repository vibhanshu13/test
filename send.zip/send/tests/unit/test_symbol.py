import pytest
from models.symbol import Symbol, SymbolType, SymbolTable
from models.provenance import StatementProvenance


def test_symbol_creation():
    """Test basic symbol creation"""
    prov = StatementProvenance(
        statement_id="stmt_00001",
        original_file="test.asm",
        original_line=10
    )

    sym = Symbol(
        name="SUBRTN1",
        symbol_type=SymbolType.ENTRY,
        file="test.asm",
        provenance=prov
    )

    assert sym.name == "SUBRTN1"
    assert sym.symbol_type == SymbolType.ENTRY
    assert sym.file == "test.asm"
    assert sym.value is None
    assert sym.section is None
    assert sym.is_duplicate is False


def test_symbol_with_value_and_section():
    """Test symbol with value and section"""
    prov = StatementProvenance(
        statement_id="stmt_00002",
        original_file="test.asm",
        original_line=20
    )

    sym = Symbol(
        name="OFFSET",
        symbol_type=SymbolType.EQU,
        file="test.asm",
        provenance=prov,
        value=100,
        section="DATASECT"
    )

    assert sym.value == 100
    assert sym.section == "DATASECT"


def test_symbol_to_dict():
    """Test symbol serialization"""
    prov = StatementProvenance(
        statement_id="stmt_00003",
        original_file="test.asm",
        original_line=30
    )

    sym = Symbol(
        name="LABEL1",
        symbol_type=SymbolType.LABEL,
        file="test.asm",
        provenance=prov
    )

    result = sym.to_dict()

    assert result["name"] == "LABEL1"
    assert result["type"] == "label"
    assert result["file"] == "test.asm"
    assert "provenance" in result


def test_symbol_table_add_global_symbol():
    """Test adding global symbols"""
    table = SymbolTable()
    prov = StatementProvenance(
        statement_id="stmt_00001",
        original_file="test.asm",
        original_line=10
    )

    sym = Symbol(
        name="GLOBAL1",
        symbol_type=SymbolType.ENTRY,
        file="test.asm",
        provenance=prov
    )

    table.add_symbol(sym)

    assert "GLOBAL1" in table.global_symbols
    assert table.symbol_to_file["GLOBAL1"] == "test.asm"


def test_symbol_table_add_section_symbol():
    """Test adding symbols to sections"""
    table = SymbolTable()
    prov = StatementProvenance(
        statement_id="stmt_00002",
        original_file="test.asm",
        original_line=20
    )

    sym = Symbol(
        name="LOCAL1",
        symbol_type=SymbolType.LABEL,
        file="test.asm",
        provenance=prov,
        section="MAINSECT"
    )

    table.add_symbol(sym, section="MAINSECT")

    assert "MAINSECT" in table.sections
    assert "LOCAL1" in table.sections["MAINSECT"]
    assert table.symbol_to_section["LOCAL1"] == "MAINSECT"
    assert table.symbol_to_file["LOCAL1"] == "test.asm"


def test_symbol_table_resolve_scoped():
    """Test symbol resolution with scoping"""
    table = SymbolTable()

    # Add global symbol
    global_prov = StatementProvenance("stmt_00001", "test.asm", 10)
    global_sym = Symbol("NAME", SymbolType.ENTRY, "test.asm", global_prov)
    table.add_symbol(global_sym)

    # Add local symbol in section with same name
    local_prov = StatementProvenance("stmt_00002", "test.asm", 20)
    local_sym = Symbol("NAME", SymbolType.LABEL, "test.asm", local_prov, section="SECT1")
    table.add_symbol(local_sym, section="SECT1")

    # Resolve without context - should find global
    result = table.resolve("NAME")
    assert result == global_sym

    # Resolve with section context - should find local
    result = table.resolve("NAME", context="SECT1")
    assert result == local_sym


def test_symbol_table_resolve_nonexistent():
    """Test resolving symbol that doesn't exist"""
    table = SymbolTable()

    result = table.resolve("NONEXISTENT")
    assert result is None
