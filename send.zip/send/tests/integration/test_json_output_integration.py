"""Integration test for JSON output."""
import json
from pathlib import Path
from file_reader import FileReader
from statement_id_generator import StatementIDGenerator
from passes.symbol_resolver import SymbolResolverPass
from passes.call_graph_builder import CallGraphBuilderPass
from passes.data_flow_tracker import DataFlowTracker
from passes.db_operation_extractor import DBOperationExtractorPass
from passes.file_dependency_builder import FileDependencyBuilderPass
from json_emitter import JSONEmitter
from models.analysis_context import AnalysisContext


def test_json_output_integration(tmp_path):
    """Test complete JSON output for complex program."""
    # Use existing complex_program.asm fixture
    fixtures_dir = Path(__file__).parent.parent / "fixtures"
    fixture_path = fixtures_dir / "complex_program.asm"

    # Read and parse
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen, search_paths=[str(fixtures_dir)])
    parsed_lines = list(reader.read_file(str(fixture_path)))

    # Run analysis passes
    context = AnalysisContext()

    symbol_pass = SymbolResolverPass()
    symbol_pass.process(parsed_lines, context)

    call_graph_pass = CallGraphBuilderPass()
    call_graph_pass.process(parsed_lines, context)

    data_flow_pass = DataFlowTracker()
    data_flow_pass.process(parsed_lines, context)

    db_pass = DBOperationExtractorPass()
    db_pass.process(parsed_lines, context)

    file_dep_pass = FileDependencyBuilderPass()
    file_dep_pass.process(context)

    # Emit JSON
    emitter = JSONEmitter()
    result = emitter.emit(context)

    # Verify top-level structure
    assert "metadata" in result
    assert "symbols" in result
    assert "call_graph" in result
    assert "db_operations" in result
    assert "file_dependencies" in result
    assert "macro_expansions" in result
    assert "macro_errors" in result
    assert "variable_lineage" in result

    # Verify can be JSON serialized
    json_str = emitter.emit_json(context)
    parsed = json.loads(json_str)
    assert parsed["metadata"]["version"] == "1.0"

    # Verify symbols
    assert len(result["symbols"]["global_symbols"]) > 0

    # Verify call graph
    assert len(result["call_graph"]["edges"]) > 0

    # Write to file
    output_file = tmp_path / "output.json"
    with open(output_file, 'w') as f:
        f.write(json_str)

    # Verify file is valid JSON
    with open(output_file, 'r') as f:
        reloaded = json.load(f)
        assert reloaded["metadata"]["version"] == "1.0"
