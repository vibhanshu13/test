"""Integration test for data flow tracking and indirect call resolution."""

import pytest
from pathlib import Path
from file_reader import FileReader
from statement_id_generator import StatementIDGenerator
from models.analysis_context import AnalysisContext
from passes.call_graph_builder import CallGraphBuilderPass
from passes.data_flow_tracker import DataFlowTracker


def test_data_flow_integration():
    """Test data flow tracking on complex program"""
    fixture_path = Path(__file__).parent.parent / "fixtures" / "complex_program.asm"
    fixtures_dir = fixture_path.parent

    # Setup
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen, search_paths=[str(fixtures_dir)])
    context = AnalysisContext()

    # Read file
    lines = list(reader.read_file(str(fixture_path)))

    # Build call graph first (Pass 3)
    call_graph_builder = CallGraphBuilderPass()
    call_graph_builder.process(lines, context)

    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    # Track data flow (Pass 4)
    data_flow_tracker = DataFlowTracker()
    data_flow_tracker.process(lines, context)

    # Verify data flow tracking occurred
    tracker = context.metadata.get("data_flow_tracker")
    assert tracker is not None

    print(f"\n✓ Data flow tracking complete")

    # Check for indirect call resolutions
    resolved_calls = context.metadata.get("resolved_indirect_calls", [])
    print(f"✓ Resolved {len(resolved_calls)} indirect calls")

    # Show resolved calls
    if resolved_calls:
        print("\n✓ Resolved indirect calls:")
        for call in resolved_calls[:5]:
            print(f"  {call['routine']} via {call['register']} -> {call['target']}")

    # Verify we resolved some indirect calls
    # The complex_program has patterns like L R15,=V(DBREAD) / BALR R14,R15
    assert len(resolved_calls) > 0

    print("\n✓ Data flow integration test successful!")
