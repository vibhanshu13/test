"""Integration test for DB operation extraction."""

import pytest
from pathlib import Path
from file_reader import FileReader
from statement_id_generator import StatementIDGenerator
from models.analysis_context import AnalysisContext
from passes.db_operation_extractor import DBOperationExtractorPass
from models.db_operation import DBOperationType


def test_db_operation_integration():
    """Test DB operation extraction on sample program"""
    fixture_path = Path(__file__).parent.parent / "fixtures" / "db_operations.asm"
    fixtures_dir = fixture_path.parent

    # Setup
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen, search_paths=[str(fixtures_dir)])
    context = AnalysisContext()

    # Read file
    lines = list(reader.read_file(str(fixture_path)))

    # Extract DB operations (Pass 5)
    extractor = DBOperationExtractorPass()
    extractor.process(lines, context)

    # Verify catalog was created
    catalog = context.metadata.get("db_operation_catalog")
    assert catalog is not None

    print(f"\n✓ Extracted {len(catalog.operations)} database operations")

    # Verify we found operations
    assert len(catalog.operations) > 0

    # Check operation types
    reads = catalog.get_operations_by_type(DBOperationType.READ)
    writes = catalog.get_operations_by_type(DBOperationType.WRITE)
    updates = catalog.get_operations_by_type(DBOperationType.UPDATE)
    deletes = catalog.get_operations_by_type(DBOperationType.DELETE)
    controls = catalog.get_operations_by_type(DBOperationType.CONTROL)

    print(f"✓ Reads: {len(reads)}")
    print(f"✓ Writes: {len(writes)}")
    print(f"✓ Updates: {len(updates)}")
    print(f"✓ Deletes: {len(deletes)}")
    print(f"✓ Controls: {len(controls)}")

    # Verify expected counts from fixture
    assert len(reads) == 2  # CUSTMAIN and ORDPROC
    assert len(writes) == 1  # ORDPROC
    assert len(updates) == 1  # CUSTMAIN
    assert len(deletes) == 1  # ORDPROC
    assert len(controls) == 2  # FILEINIT (DBOPN + FILEC)

    # Show sample operations
    print("\n✓ Sample operations:")
    for op in catalog.operations[:5]:
        print(f"  {op.calling_routine}: {op.macro_name} on {op.file_record_identifier}")

    # Verify operations by routine
    custmain_ops = catalog.get_operations_by_routine("CUSTMAIN")
    assert len(custmain_ops) == 2  # DBRED + DBUPD

    ordproc_ops = catalog.get_operations_by_routine("ORDPROC")
    assert len(ordproc_ops) == 3  # DBRED + DBWRT + DBDEL

    # Verify operations by file
    custfile_ops = catalog.get_operations_by_file_record("CUSTFILE")
    assert len(custfile_ops) == 3  # DBRED + DBUPD in CUSTMAIN, DBOPN in FILEINIT

    print("\n✓ DB operation integration test successful!")
