"""Integration tests for C/C++ line metadata."""

from pathlib import Path
from multi_file.c_family_analyzer import CFamilyAnalyzer


def test_c_analyzer_creates_line_metadata_index():
    """Test that C analyzer creates line metadata index."""
    analyzer = CFamilyAnalyzer("c")

    c_code = """
int main() {
    int x = 10;
    return 0;
}
"""

    result = analyzer.analyze(Path("test.c"), c_code)

    # Check that line_metadata_index was created
    assert result.analysis_context.line_metadata_index is not None

    # Should have recorded some lines
    all_lines = result.analysis_context.line_metadata_index.get_all()
    assert len(all_lines) > 0


def test_c_line_metadata_tracks_function():
    """Test that C metadata tracks function context."""
    analyzer = CFamilyAnalyzer("c")

    c_code = """
int main() {
    return 0;
}
"""

    result = analyzer.analyze(Path("test.c"), c_code)
    index = result.analysis_context.line_metadata_index

    # Find lines in main function
    lines = index.get_lines_in_function("main")
    assert len(lines) > 0

    # All should have enclosing_function = "main"
    for line in lines:
        assert line.codeblock.enclosing_function == "main"


def test_c_line_metadata_includes_calls():
    """Test that C metadata is enriched with call information."""
    analyzer = CFamilyAnalyzer("c")

    c_code = """
void helper() {}

int main() {
    helper();
    return 0;
}
"""

    result = analyzer.analyze(Path("test.c"), c_code)
    index = result.analysis_context.line_metadata_index

    # Find lines in main function
    main_lines = index.get_lines_in_function("main")

    # main should show call to helper
    assert len(main_lines) > 0, "main function should have lines"
    has_helper = any("helper" in m.calls.calls_functions for m in main_lines)
    assert has_helper, f"main should call helper. Calls found: {[m.calls.calls_functions for m in main_lines]}"
