import json
from pathlib import Path
import sys
import tempfile
from main import main as run_main


def test_end_to_end_authorization_fixture():
    fixture_dir = Path("tests/fixtures/authorization")

    with tempfile.TemporaryDirectory() as tmp_dir:
        output_dir = Path(tmp_dir) / "output"
        cache_dir = Path(tmp_dir) / "cache"

        sys.argv = [
            "main.py",
            str(fixture_dir),
            "-o", str(output_dir),
            "-c", str(cache_dir)
        ]

        try:
            run_main()
        except SystemExit as e:
            assert e.code == 0 or e.code is None

        actual_output = output_dir / "authorization" / "capabilities" / "CARDVAL.asm.json"
        assert actual_output.exists()

        actual = json.loads(actual_output.read_text())

        assert "macro_expansions" in actual
        assert len(actual["macro_expansions"]) > 0

        expansion_names = [e["macro_name"] for e in actual["macro_expansions"]]
        assert "CHKRC" in expansion_names
        assert "SETRC" in expansion_names

        for expansion in actual["macro_expansions"]:
            if expansion["expansion_status"] == "success":
                assert "expanded_code" in expansion
                assert len(expansion["expanded_code"]) > 0


def test_macro_not_found_error_handling():
    with tempfile.TemporaryDirectory() as tmp_dir:
        source_file = Path(tmp_dir) / "test.asm"
        source_file.write_text("""
PROGRAM  CSECT
         UNKNOWN_MACRO PARAM
         BR    R14
         END
""")

        output_dir = Path(tmp_dir) / "output"
        cache_dir = Path(tmp_dir) / "cache"

        sys.argv = [
            "main.py",
            str(source_file),
            "-o", str(output_dir),
            "-c", str(cache_dir)
        ]

        try:
            run_main()
        except SystemExit as e:
            assert e.code == 0 or e.code is None

        output_file = output_dir / "test.asm.json"
        assert output_file.exists()

        data = json.loads(output_file.read_text())

        assert "macro_errors" in data


def test_explicit_macro_lib_override():
    with tempfile.TemporaryDirectory() as tmp_dir:
        auto_macro = Path(tmp_dir) / "auto_macros.asm"
        auto_macro.write_text("""
         MACRO
         TEST
         LA    R1,1
         MEND
""")

        explicit_macro = Path(tmp_dir) / "explicit_macros.asm"
        explicit_macro.write_text("""
         MACRO
         TEST
         LA    R1,99
         MEND
""")

        source = Path(tmp_dir) / "test.asm"
        source.write_text("""
PROGRAM  CSECT
         TEST
         BR    R14
         END
""")

        output_dir = Path(tmp_dir) / "output"
        cache_dir = Path(tmp_dir) / "cache"

        sys.argv = [
            "main.py",
            str(source),
            "-o", str(output_dir),
            "-c", str(cache_dir),
            "--macro-lib", str(explicit_macro)
        ]

        try:
            run_main()
        except SystemExit as e:
            assert e.code == 0 or e.code is None

        output_file = output_dir / "test.asm.json"
        data = json.loads(output_file.read_text())

        test_expansions = [
            e for e in data.get("macro_expansions", [])
            if e["macro_name"] == "TEST"
        ]

        if test_expansions:
            expansion = test_expansions[0]
            expanded_instructions = [
                i["instruction"] for i in expansion["expanded_code"]
            ]
            assert any("99" in instr for instr in expanded_instructions)
