"""Integration test for complex assembly program parsing."""

import pytest
from pathlib import Path
from file_reader import FileReader
from statement_id_generator import StatementIDGenerator
from models.analysis_context import AnalysisContext
from symbol_parser import SymbolParser
from section_tracker import SectionTracker
from models.symbol import SymbolType


def test_complex_program_parsing():
    """Test parsing a complex, realistic assembly program"""
    fixture_path = Path(__file__).parent.parent / "fixtures" / "complex_program.asm"
    fixtures_dir = fixture_path.parent

    # Setup
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen, search_paths=[str(fixtures_dir)])
    context = AnalysisContext()
    parser = SymbolParser()
    section_tracker = SectionTracker()

    # Read and parse the entire program
    lines = list(reader.read_file(str(fixture_path)))

    print(f"\n✓ Read {len(lines)} total lines (including COPY expansions)")

    # Process all lines to extract symbols
    entry_symbols = []
    extrn_symbols = []
    wxtrn_symbols = []
    csect_symbols = []
    dsect_symbols = []
    equ_symbols = []

    for line in lines:
        # Track sections
        if line.opcode and line.opcode.upper() in ("CSECT", "DSECT", "RSECT"):
            if line.label:
                section_tracker.enter_section(
                    name=line.label,
                    section_type=line.opcode.upper(),
                    line=line.provenance.original_line,
                    file=line.provenance.original_file
                )

        # Parse symbols
        current_section = section_tracker.current_section
        symbols = parser.parse_line(line, current_section=current_section)

        for symbol in symbols:
            if symbol.symbol_type == SymbolType.ENTRY:
                entry_symbols.append(symbol)
            elif symbol.symbol_type == SymbolType.EXTRN:
                extrn_symbols.append(symbol)
            elif symbol.symbol_type == SymbolType.WXTRN:
                wxtrn_symbols.append(symbol)
            elif symbol.symbol_type == SymbolType.CSECT:
                csect_symbols.append(symbol)
            elif symbol.symbol_type == SymbolType.DSECT:
                dsect_symbols.append(symbol)
            # EQU symbols will be added when we implement Task 5

    # Verify ENTRY symbols
    print(f"\n✓ Found {len(entry_symbols)} ENTRY symbols:")
    for sym in entry_symbols:
        print(f"  - {sym.name}")

    assert len(entry_symbols) == 3
    entry_names = [s.name for s in entry_symbols]
    assert "CUSTMAIN" in entry_names
    assert "CUSTPROC" in entry_names
    assert "CUSTNEW" in entry_names

    # Verify EXTRN symbols
    print(f"\n✓ Found {len(extrn_symbols)} EXTRN symbols:")
    for sym in extrn_symbols:
        print(f"  - {sym.name}")

    assert len(extrn_symbols) == 5
    extrn_names = [s.name for s in extrn_symbols]
    assert "DBREAD" in extrn_names
    assert "DBWRT" in extrn_names
    assert "DBDEL" in extrn_names
    assert "GETMEM" in extrn_names
    assert "FREEMEM" in extrn_names

    # Verify WXTRN symbols
    print(f"\n✓ Found {len(wxtrn_symbols)} WXTRN symbols:")
    for sym in wxtrn_symbols:
        print(f"  - {sym.name}")

    assert len(wxtrn_symbols) == 1
    assert wxtrn_symbols[0].name == "VALIDATE"

    # Verify CSECT symbols
    print(f"\n✓ Found {len(csect_symbols)} CSECT sections:")
    for sym in csect_symbols:
        print(f"  - {sym.name}")

    assert len(csect_symbols) >= 1
    assert "CUSTMAIN" in [s.name for s in csect_symbols]

    # Verify DSECT symbols
    print(f"\n✓ Found {len(dsect_symbols)} DSECT sections:")
    for sym in dsect_symbols:
        print(f"  - {sym.name}")

    assert len(dsect_symbols) >= 2
    dsect_names = [s.name for s in dsect_symbols]
    assert "CUSTDATA" in dsect_names
    assert "WORKAREA" in dsect_names

    # Verify COPY expansion happened
    copy_expanded_lines = [line for line in lines if line.provenance.expanded_from_copy]
    print(f"\n✓ Found {len(copy_expanded_lines)} lines from COPY includes")

    # We should have lines from CONSTANTS and CUSTREC
    assert len(copy_expanded_lines) > 0

    copy_files = set()
    for line in copy_expanded_lines:
        copy_files.add(Path(line.provenance.original_file).name.lower())

    print(f"✓ COPY files expanded: {', '.join(sorted(copy_files))}")
    assert "constants.asm" in copy_files or "custrec.asm" in copy_files

    # Verify sections were tracked
    sections = section_tracker.get_all_sections()
    print(f"\n✓ Tracked {len(sections)} sections")
    for section in sections:
        print(f"  - {section.name} ({section.section_type}) in {Path(section.file).name}")

    print("\n✓ Complex program parsing successful!")
    print(f"  Total symbols found: {len(entry_symbols) + len(extrn_symbols) + len(wxtrn_symbols) + len(csect_symbols) + len(dsect_symbols)}")
    print(f"  Lines processed: {len(lines)}")
    print(f"  COPY expansions: {len(copy_expanded_lines)}")


def test_line_continuation_in_complex_program():
    """Test that line continuations are handled correctly"""
    fixture_path = Path(__file__).parent.parent / "fixtures" / "complex_program.asm"
    fixtures_dir = fixture_path.parent

    # Setup
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen, search_paths=[str(fixtures_dir)])

    # Read the program
    lines = list(reader.read_file(str(fixture_path)))

    # Find lines that should have been continued
    # The MVC instruction in the complex program has a continuation
    mvc_lines = [line for line in lines if line.opcode and "MVC" in line.opcode.upper()]

    # At least one MVC instruction should exist
    assert len(mvc_lines) > 0

    print(f"\n✓ Found {len(mvc_lines)} MVC instructions")
    print("✓ Line continuation handling verified")


def test_comment_handling():
    """Test that comments are properly handled"""
    fixture_path = Path(__file__).parent.parent / "fixtures" / "complex_program.asm"
    fixtures_dir = fixture_path.parent

    # Setup
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen, search_paths=[str(fixtures_dir)])

    # Read the program
    lines = list(reader.read_file(str(fixture_path)))

    # Count comment lines (lines starting with *)
    # Note: The tokenizer should handle these, but we verify they're processed

    # Count lines with comments
    lines_with_comments = [line for line in lines if line.comment]

    print(f"\n✓ Processed {len(lines)} total lines")
    print(f"✓ Found {len(lines_with_comments)} lines with comments")
    print("✓ Comment handling verified")


if __name__ == "__main__":
    # Run tests with verbose output
    test_complex_program_parsing()
    test_line_continuation_in_complex_program()
    test_comment_handling()
