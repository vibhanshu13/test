from pathlib import Path
from multi_file.mixed_orchestrator import MixedLanguageOrchestrator
from passes.c_family_parser import CFamilyParser


def test_mixed_language_cpp_call_resolution(tmp_path):
    asm_file = tmp_path / "mixed_cpp.asm"
    asm_file.write_text("""
         ENTRY ASM_FUNC
         EXTRN CPP_FUNC
ASM_FUNC DS    0H
         BR    R14
MAIN     CSECT
         BAL   R14,CPP_FUNC
         BR    R14
         END
""")

    cpp_file = tmp_path / "mixed.cpp"
    cpp_file.write_text("""
extern \"C\" void ASM_FUNC(void);

void CPP_FUNC() {
    int x = 1;
    int y = x + 3;
    ASM_FUNC();
}
""")

    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()

    orchestrator = MixedLanguageOrchestrator(
        cache_dir=cache_dir,
        search_paths=[tmp_path]
    )

    result = orchestrator.analyze_files([asm_file, cpp_file])

    # Always validate ASM symbols
    assert "ASM_FUNC" in result.global_registry.entries

    parser_available = CFamilyParser("cpp").available
    if not parser_available:
        return

    # If C++ parsing is available, CPP_FUNC should be linked
    assert "CPP_FUNC" in result.global_registry.entries
    assert "CPP_FUNC" not in result.unresolved_externals

    asm_result = [r for r in result.file_results if r.file_path == asm_file][0]
    cpp_result = [r for r in result.file_results if r.file_path == cpp_file][0]

    assert asm_result.call_graph.nodes["CPP_FUNC"].file is not None
    assert cpp_result.call_graph.nodes["ASM_FUNC"].file is not None


def test_mixed_language_cpp_return_lineage_bridge(tmp_path):
    asm_file = tmp_path / "bridge.asm"
    asm_file.write_text("""
         ENTRY ASM_FRAUD_CHECK
ASM_FRAUD_CHECK DS 0H
         BR    R14
         END
""")

    cpp_file = tmp_path / "bridge.cpp"
    cpp_file.write_text("""
extern "C" int ASM_FRAUD_CHECK(int);

int CPP_FUNC(int x) {
    int risk = ASM_FRAUD_CHECK(x);
    return risk;
}
""")

    cache_dir = tmp_path / "cache2"
    cache_dir.mkdir()
    orchestrator = MixedLanguageOrchestrator(cache_dir=cache_dir, search_paths=[tmp_path])
    result = orchestrator.analyze_files([asm_file, cpp_file])

    parser_available = CFamilyParser("cpp").available
    if not parser_available:
        return

    assert result.global_lineage is not None
    edges = [e for e in result.global_lineage.edges if e.relation == "assign"]
    assert any("return@ASM_FRAUD_CHECK" in e.source and "risk" in e.target for e in edges)
