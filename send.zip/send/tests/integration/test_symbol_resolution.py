"""Integration test for symbol resolution (Pass 2)."""

import pytest
from pathlib import Path
from file_reader import FileReader
from statement_id_generator import StatementIDGenerator
from models.analysis_context import AnalysisContext
from passes.symbol_resolver import SymbolResolverPass
from models.symbol import SymbolType


def test_symbol_resolution_integration():
    """Test complete symbol resolution workflow"""
    fixture_path = Path(__file__).parent.parent / "fixtures" / "program_with_symbols.asm"

    # Setup
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen, search_paths=[])
    context = AnalysisContext()
    resolver = SymbolResolverPass()

    # Read file
    lines = list(reader.read_file(str(fixture_path)))

    # Run symbol resolution pass
    resolver.process(lines, context)

    # Verify ENTRY symbols
    main_sym = context.symbol_table.resolve("MAIN")
    assert main_sym is not None
    # Note: MAIN appears as both ENTRY and CSECT, CSECT wins
    assert main_sym.symbol_type == SymbolType.CSECT

    helper_sym = context.symbol_table.resolve("HELPER")
    assert helper_sym is not None
    # HELPER appears as ENTRY - should be in global symbols

    # Verify EXTRN symbols
    dbread_sym = context.symbol_table.resolve("DBREAD")
    assert dbread_sym is not None
    assert dbread_sym.symbol_type == SymbolType.EXTRN

    dbwrite_sym = context.symbol_table.resolve("DBWRITE")
    assert dbwrite_sym is not None
    assert dbwrite_sym.symbol_type == SymbolType.EXTRN

    # Verify CSECT symbol
    csect_symbols = [s for s in context.symbol_table.global_symbols.values()
                     if s.symbol_type == SymbolType.CSECT]
    assert len(csect_symbols) == 1
    assert csect_symbols[0].name == "MAIN"

    # Verify EQU symbols (section-scoped)
    maxlen_sym = context.symbol_table.resolve("MAXLEN", context="MAIN")
    assert maxlen_sym is not None
    assert maxlen_sym.symbol_type == SymbolType.EQU
    assert maxlen_sym.value == 256

    r15_sym = context.symbol_table.resolve("R15", context="MAIN")
    assert r15_sym is not None
    assert r15_sym.value == 15

    # Verify mappings
    assert context.symbol_table.symbol_to_file["MAIN"] == str(fixture_path)
    assert context.symbol_table.symbol_to_file["DBREAD"] == str(fixture_path)

    # Verify section metadata
    sections = context.metadata.get("sections", [])
    assert len(sections) == 1
    assert sections[0].name == "MAIN"
    assert sections[0].section_type == "CSECT"

    print("\n✓ Symbol resolution successful")
    print(f"✓ Resolved {len(context.symbol_table.global_symbols)} global symbols")
    print(f"✓ Tracked {context.metadata['section_count']} sections")
