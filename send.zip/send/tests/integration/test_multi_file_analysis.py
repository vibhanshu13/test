"""Integration tests for multi-file analysis."""
from pathlib import Path
from multi_file.orchestrator import MultiFileOrchestrator


def test_orchestrator_analyzes_multiple_files(tmp_path):
    """Test orchestrator can analyze multiple files."""
    # Create test files
    file1 = tmp_path / "module1.asm"
    file1.write_text("""
         ENTRY MAIN
         EXTRN HELPER
MAIN     CSECT
         BAL   R14,HELPER
         END
""")

    file2 = tmp_path / "module2.asm"
    file2.write_text("""
         ENTRY HELPER
HELPER   CSECT
         BR    R14
         END
""")

    # Analyze
    orchestrator = MultiFileOrchestrator(
        cache_dir=tmp_path / ".cache",
        search_paths=[tmp_path]
    )

    result = orchestrator.analyze_files([file1, file2])

    assert len(result.file_results) == 2
    assert result.global_registry is not None
    assert "MAIN" in result.global_registry.entries
    assert "HELPER" in result.global_registry.entries


def test_orchestrator_resolves_cross_file_references(tmp_path):
    """Test orchestrator resolves EXTRN to ENTRY across files."""
    file1 = tmp_path / "caller.asm"
    file1.write_text("""
         ENTRY CALLER
         EXTRN CALLEE
CALLER   CSECT
         BAL   R14,CALLEE
         END
""")

    file2 = tmp_path / "callee.asm"
    file2.write_text("""
         ENTRY CALLEE
CALLEE   CSECT
         BR    R14
         END
""")

    orchestrator = MultiFileOrchestrator(
        cache_dir=tmp_path / ".cache",
        search_paths=[tmp_path]
    )

    result = orchestrator.analyze_files([file1, file2])

    # Check EXTRN CALLEE resolved to ENTRY CALLEE
    resolution = result.global_registry.resolve_extrn(
        result.file_results[0].analysis_context.symbol_table.all_symbols[1]
    )

    assert resolution.resolved is True
    assert len(resolution.targets) == 1
    assert resolution.targets[0].name == "CALLEE"


def test_orchestrator_uses_cache(tmp_path):
    """Test orchestrator uses cache for unchanged files."""
    file1 = tmp_path / "module.asm"
    file1.write_text("""
         ENTRY FUNC
FUNC     CSECT
         END
""")

    cache_dir = tmp_path / ".cache"
    orchestrator = MultiFileOrchestrator(
        cache_dir=cache_dir,
        search_paths=[tmp_path]
    )

    # First analysis
    result1 = orchestrator.analyze_files([file1])

    # Second analysis (should use cache)
    result2 = orchestrator.analyze_files([file1])

    assert len(result2.file_results) == 1
    assert result2.file_results[0].exports == ["FUNC"]


def test_orchestrator_links_call_graph_across_files(tmp_path):
    """Test call graph nodes are linked with file information across files."""
    file1 = tmp_path / "caller.asm"
    file1.write_text("""
         ENTRY CALLER
         EXTRN HELPER
CALLER   CSECT
         BRAS  R14,HELPER
         BR    R14
         END
""")

    file2 = tmp_path / "helper.asm"
    file2.write_text("""
         ENTRY HELPER
HELPER   CSECT
         BR    R14
         END
""")

    orchestrator = MultiFileOrchestrator(
        cache_dir=tmp_path / ".cache",
        search_paths=[tmp_path]
    )

    result = orchestrator.analyze_files([file1, file2])

    # Find the caller file result
    caller_result = next(r for r in result.file_results if r.file_path.name == "caller.asm")

    # Verify call graph exists
    assert caller_result.call_graph is not None

    # Check that HELPER node exists and has file information
    assert "HELPER" in caller_result.call_graph.nodes
    helper_node = caller_result.call_graph.nodes["HELPER"]

    # After linking, HELPER node should have file="helper.asm"
    assert helper_node.file is not None
    assert "helper.asm" in str(helper_node.file)
    assert helper_node.is_external is False


def test_orchestrator_marks_unresolved_externals_in_call_graph(tmp_path):
    """Test call graph marks unresolved EXTRN as external."""
    file1 = tmp_path / "caller.asm"
    file1.write_text("""
         ENTRY CALLER
         EXTRN DBREAD
CALLER   CSECT
         BRAS  R14,DBREAD
         BR    R14
         END
""")

    orchestrator = MultiFileOrchestrator(
        cache_dir=tmp_path / ".cache",
        search_paths=[tmp_path]
    )

    result = orchestrator.analyze_files([file1])

    # Find the caller file result
    caller_result = result.file_results[0]

    # Verify call graph exists
    assert caller_result.call_graph is not None

    # Check that DBREAD node exists and is marked external
    assert "DBREAD" in caller_result.call_graph.nodes
    dbread_node = caller_result.call_graph.nodes["DBREAD"]

    # After linking, DBREAD should be marked as external (unresolved)
    assert dbread_node.is_external is True
    # File should remain None since it's external
    assert dbread_node.file is None


def test_orchestrator_merges_data_flow_across_files(tmp_path):
    """Test data flow information is merged across files."""
    # File 1: Caller with indirect call to HELPER
    file1 = tmp_path / "caller.asm"
    file1.write_text("""
         ENTRY CALLER
         EXTRN HELPER
CALLER   CSECT
         L     R15,=V(HELPER)
         BALR  R14,R15
         BR    R14
         END
""")

    # File 2: HELPER definition
    file2 = tmp_path / "helper.asm"
    file2.write_text("""
         ENTRY HELPER
HELPER   CSECT
         BR    R14
         END
""")

    orchestrator = MultiFileOrchestrator(
        cache_dir=tmp_path / ".cache",
        search_paths=[tmp_path]
    )

    result = orchestrator.analyze_files([file1, file2])

    # Check that merged data flow exists
    merged_data_flow = result.file_results[0].analysis_context.get_metadata("merged_data_flow")
    assert merged_data_flow is not None

    # Verify structure
    assert "total_resolved_calls" in merged_data_flow
    assert "validated_calls" in merged_data_flow
    assert "all_calls" in merged_data_flow

    # If any indirect calls were resolved, they should be validated against global registry
    if merged_data_flow["total_resolved_calls"] > 0:
        # HELPER should be validated (it's an ENTRY in file2)
        validated = merged_data_flow["validated_calls"]
        assert validated >= 0  # At least not failing
