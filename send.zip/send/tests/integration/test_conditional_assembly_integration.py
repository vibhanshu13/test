"""Integration tests for conditional assembly processing in FileReader."""

import pytest
from pathlib import Path
from file_reader import FileReader
from statement_id_generator import StatementIDGenerator


def test_file_reader_processes_aif_directive(tmp_path):
    """Test that FileReader processes AIF directives correctly.

    This test verifies that:
    - FileReader can read files with conditional assembly directives
    - All directives (SETA, AIF, DC, ANOP, DC, END) are processed
    - Opcodes are present in the output (basic parsing works)

    Note: This test does NOT verify conditional execution logic (line skipping),
    only that directives are recognized and processed.
    """
    # Create test file with conditional assembly directives
    test_file = tmp_path / "test_aif.asm"
    test_file.write_text(
        "&VAR     SETA  1\n"
        "         AIF   (&VAR EQ 1).SKIP\n"
        "         DC    F'999'\n"
        ".SKIP    ANOP\n"
        "         DC    F'1'\n"
        "         END\n"
    )

    # Read file with FileReader
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen)

    lines = list(reader.read_file(str(test_file)))

    # Verify all lines were processed
    assert len(lines) == 6, f"Expected 6 lines, got {len(lines)}"

    # Verify opcodes are present (basic tokenization worked)
    opcodes = [line.opcode for line in lines if line.opcode]

    # Check that key opcodes are present
    assert "SETA" in opcodes, "SETA directive not found in output"
    assert "AIF" in opcodes, "AIF directive not found in output"
    assert "DC" in opcodes, "DC directive not found in output"
    assert "ANOP" in opcodes, "ANOP directive not found in output"
    assert "END" in opcodes, "END directive not found in output"

    # Verify we have the right number of DC directives
    dc_count = opcodes.count("DC")
    assert dc_count == 2, f"Expected 2 DC directives, got {dc_count}"


def test_file_reader_tracks_sequence_labels(tmp_path):
    """Test that FileReader tracks sequence labels and AGO references.

    This test verifies that:
    - FileReader recognizes ANOP directives with sequence labels
    - FileReader recognizes AGO directives with target labels
    - All directives are processed and opcodes are present

    Note: This test does NOT verify branch execution logic,
    only that labels and branches are recognized during processing.
    """
    # Create test file with sequence labels and AGO
    test_file = tmp_path / "test_ago.asm"
    test_file.write_text(
        ".START   ANOP\n"
        "         DC    F'1'\n"
        "         AGO   .START\n"
        "         END\n"
    )

    # Read file with FileReader
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen)

    lines = list(reader.read_file(str(test_file)))

    # Verify all lines were processed
    assert len(lines) == 4, f"Expected 4 lines, got {len(lines)}"

    # Verify opcodes are present
    opcodes = [line.opcode for line in lines if line.opcode]

    assert "ANOP" in opcodes, "ANOP directive not found in output"
    assert "DC" in opcodes, "DC directive not found in output"
    assert "AGO" in opcodes, "AGO directive not found in output"
    assert "END" in opcodes, "END directive not found in output"

    # Verify sequence label was recognized (check FileReader's conditional_state)
    # The sequence label should be tracked in conditional_state
    assert reader.conditional_state.has_sequence_label(".START"), \
        "Sequence label .START was not tracked by FileReader"

    # Verify the label points to the correct line (line 1 in this case)
    label_line = reader.conditional_state.get_sequence_label_line(".START")
    assert label_line == 1, f"Expected label at line 1, got line {label_line}"
