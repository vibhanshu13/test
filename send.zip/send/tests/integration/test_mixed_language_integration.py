from pathlib import Path
from multi_file.mixed_orchestrator import MixedLanguageOrchestrator
from passes.c_family_parser import CFamilyParser


def test_mixed_language_call_resolution(tmp_path):
    asm_file = tmp_path / "mixed.asm"
    asm_file.write_text("""
         ENTRY ASM_FUNC
         EXTRN C_FUNC
ASM_FUNC DS    0H
         BR    R14
MAIN     CSECT
         BAL   R14,C_FUNC
         BR    R14
         END
""")

    c_file = tmp_path / "mixed.c"
    c_file.write_text("""
extern void ASM_FUNC(void);

void C_FUNC(void) {
    int a = 1;
    int b = a + 2;
    ASM_FUNC();
}
""")

    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()

    orchestrator = MixedLanguageOrchestrator(
        cache_dir=cache_dir,
        search_paths=[tmp_path]
    )

    result = orchestrator.analyze_files([asm_file, c_file])

    # Always validate ASM symbols
    assert "ASM_FUNC" in result.global_registry.entries

    parser_available = CFamilyParser("c").available
    if not parser_available:
        return

    # If C parsing is available, C_FUNC should be linked
    assert "C_FUNC" in result.global_registry.entries
    assert "C_FUNC" not in result.unresolved_externals
    assert result.global_lineage is not None

    asm_result = [r for r in result.file_results if r.file_path == asm_file][0]
    c_result = [r for r in result.file_results if r.file_path == c_file][0]

    # Call graph nodes should resolve to files
    assert asm_result.call_graph.nodes["C_FUNC"].file is not None
    assert c_result.call_graph.nodes["ASM_FUNC"].file is not None
