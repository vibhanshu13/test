"""Integration test for COPY directive expansion."""

import pytest
from pathlib import Path
from file_reader import FileReader
from statement_id_generator import StatementIDGenerator
from models.analysis_context import AnalysisContext


def test_copy_expansion_integration():
    """Test complete COPY expansion workflow"""
    fixture_path = Path(__file__).parent.parent / "fixtures" / "main_with_copy.asm"
    fixtures_dir = fixture_path.parent

    # Setup
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen, search_paths=[str(fixtures_dir)])
    context = AnalysisContext()

    # Read file with COPY expansion
    lines = []
    tracked_includes = set()  # Track unique COPY relationships

    for parsed_line in reader.read_file(str(fixture_path)):
        lines.append(parsed_line)

        # Track COPY includes in context (would be done by preprocessor)
        if parsed_line.provenance.expanded_from_copy:
            # This line came from a COPY include
            # Track each unique COPY relationship only once
            include_pair = (
                parsed_line.provenance.expanded_from_copy,  # File containing COPY
                parsed_line.provenance.original_file         # File being included
            )

            if include_pair not in tracked_includes:
                tracked_includes.add(include_pair)
                context.add_copy_include(
                    including_file=parsed_line.provenance.expanded_from_copy,
                    included_file=parsed_line.provenance.original_file,
                    line_number=0  # Line number not available from expanded lines
                )

    # Verify expansion
    assert len(lines) >= 8  # Main + included content

    # Verify provenance tracking
    expanded_lines = [line for line in lines if line.provenance.expanded_from_copy]
    assert len(expanded_lines) > 0

    # Verify some lines are from included file
    included_lines = [
        line for line in lines
        if Path(line.provenance.original_file).name.lower() == "utils.asm"
    ]
    assert len(included_lines) > 0

    # Verify COPY tracking in context
    all_includes = context.get_all_copy_includes()
    assert len(all_includes) > 0

    print("\n✓ COPY expansion successful")
    print(f"✓ Expanded {len(lines)} total lines")
    print(f"✓ {len(expanded_lines)} lines from COPY includes")
    print(f"✓ Tracked {len(all_includes)} COPY relationships")
