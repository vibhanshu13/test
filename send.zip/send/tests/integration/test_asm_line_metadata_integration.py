"""Integration tests for ASM line metadata."""

from pathlib import Path
from multi_file.single_file_analyzer import SingleFileAnalyzer


def test_asm_analyzer_creates_line_metadata_index():
    """Test that ASM analyzer creates line metadata index."""
    analyzer = SingleFileAnalyzer(search_paths=[])

    asm_code = """
MAINSECT CSECT
INIT     DS    0H
         LA    R1,10
         BR    R14
"""

    result = analyzer.analyze(Path("test.asm"), asm_code)

    # Check that line_metadata_index was created
    assert result.analysis_context.line_metadata_index is not None

    # Should have recorded some lines
    all_lines = result.analysis_context.line_metadata_index.get_all()
    assert len(all_lines) > 0


def test_asm_line_metadata_tracks_section():
    """Test that ASM metadata tracks section context."""
    analyzer = SingleFileAnalyzer(search_paths=[])

    asm_code = """
MAINSECT CSECT
         LA    R1,10
"""

    result = analyzer.analyze(Path("test.asm"), asm_code)
    index = result.analysis_context.line_metadata_index

    # Find line with LA instruction
    lines = index.get_lines_in_section("MAINSECT")
    assert len(lines) > 0

    # Check that section is tracked
    la_line = [m for m in lines if m.line_number == 3]
    assert len(la_line) > 0
    assert la_line[0].codeblock.enclosing_section == "MAINSECT"


def test_asm_line_metadata_includes_calls():
    """Test that ASM metadata is enriched with call information."""
    analyzer = SingleFileAnalyzer(search_paths=[])

    asm_code = """
MAINSECT CSECT
INIT     STM   R14,R12,12(R13)
         BAL   R14,HELPER
         BR    R14
HELPER   STM   R14,R12,12(R13)
         BR    R14
"""

    result = analyzer.analyze(Path("test.asm"), asm_code)
    index = result.analysis_context.line_metadata_index

    # Find lines in MAINSECT section (CallGraph tracks calls at section level for ASM)
    mainsect_lines = [m for m in index.get_all()
                      if m.codeblock.enclosing_section == "MAINSECT"]

    # MAINSECT should exist and have lines
    assert len(mainsect_lines) > 0, "MAINSECT section should have lines"

    # Lines in MAINSECT should show call to HELPER (after enrichment)
    # Note: In ASM, CallGraph tracks calls at section level, so all lines
    # in the section will have the same call information
    has_helper = any("HELPER" in m.calls.calls_routines for m in mainsect_lines)
    assert has_helper, f"MAINSECT should call HELPER. Calls found: {[m.calls.calls_routines for m in mainsect_lines]}"


def test_asm_line_metadata_tracks_forward_branch_conditionals():
    """Lines between a conditional branch and its forward label should be marked conditional."""
    analyzer = SingleFileAnalyzer(search_paths=[])

    asm_code = """
MAINSECT CSECT
         LTR   R1,R1
         BNZ   SKIP
         LA    R2,10
SKIP     ANOP
         BR    R14
"""

    result = analyzer.analyze(Path("test.asm"), asm_code)
    index = result.analysis_context.line_metadata_index

    line_md = index.get("test.asm", 5)  # LA R2,10
    assert line_md is not None
    assert line_md.conditional.is_conditional is True
    assert line_md.conditional.depth >= 1
    assert any("BNZ" in expr for expr in line_md.conditional.active_conditions)


def test_asm_line_metadata_treats_equ_star_as_codeblock_boundary():
    """`LABEL EQU *` should start a new routine/codeblock anchor."""
    analyzer = SingleFileAnalyzer(search_paths=[])

    asm_code = """
MAINSECT CSECT
DA7_0012 EQU   *
         MVC   WK_RCE,ZEROS
DA_10003 EQU   *
         MVC   WK_RCE,ONES
"""

    result = analyzer.analyze(Path("test.asm"), asm_code)
    index = result.analysis_context.line_metadata_index

    first_mvc = index.get("test.asm", 4)
    second_mvc = index.get("test.asm", 6)

    assert first_mvc is not None
    assert second_mvc is not None
    assert first_mvc.codeblock.enclosing_routine == "DA7_0012"
    assert second_mvc.codeblock.enclosing_routine == "DA_10003"
