"""Integration test for foundation components."""

import pytest
from pathlib import Path
from tokenizer import Tokenizer
from statement_id_generator import StatementIDGenerator
from models.provenance import StatementProvenance
from models.symbol import Symbol, SymbolType
from models.analysis_context import AnalysisContext


def test_parse_simple_assembly_file():
    """Test parsing a simple assembly file using foundation components"""
    # Setup
    fixture_path = Path(__file__).parent.parent / "fixtures" / "simple.asm"
    tokenizer = Tokenizer()
    id_gen = StatementIDGenerator()
    context = AnalysisContext()

    # Read and parse file
    with open(fixture_path, 'r') as f:
        lines = f.readlines()

    parsed_lines = []
    for line_num, line in enumerate(lines, start=1):
        # Generate provenance
        prov = StatementProvenance(
            statement_id=id_gen.next_id(),
            original_file="simple.asm",
            original_line=line_num
        )

        # Tokenize
        parsed = tokenizer.tokenize_line(line.rstrip('\n'), prov)
        parsed_lines.append(parsed)

        # If it's an ENTRY directive, add to symbol table
        if parsed.opcode == "ENTRY" and parsed.operands:
            entry_name = parsed.operands[0]
            sym = Symbol(
                name=entry_name,
                symbol_type=SymbolType.ENTRY,
                file="simple.asm",
                provenance=prov
            )
            context.symbol_table.add_symbol(sym)

    # Verify parsing
    assert len(parsed_lines) == 11  # Number of lines in simple.asm

    # Verify comment line
    assert parsed_lines[0].comment == "Simple test assembly file"

    # Verify CSECT
    assert parsed_lines[1].label == "TESTSECT"
    assert parsed_lines[1].opcode == "CSECT"

    # Verify ENTRY in symbol table
    main_sym = context.symbol_table.resolve("MAIN")
    assert main_sym is not None
    assert main_sym.name == "MAIN"
    assert main_sym.symbol_type == SymbolType.ENTRY

    # Verify instruction parsing
    main_line = parsed_lines[3]
    assert main_line.label == "MAIN"
    assert main_line.opcode == "BAS"
    assert main_line.operands == ["R14", "SUBRTN1"]

    # Verify provenance tracking
    assert main_line.provenance.original_file == "simple.asm"
    assert main_line.provenance.original_line == 4

    print("\n✓ Successfully parsed simple.asm")
    print(f"✓ Found {len(parsed_lines)} lines")
    print(f"✓ Identified ENTRY symbol: {main_sym.name}")
