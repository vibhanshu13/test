"""Integration tests for line metadata JSON output."""

import json
from pathlib import Path
from multi_file.single_file_analyzer import SingleFileAnalyzer
from json_emitter import JSONEmitter


def test_json_output_includes_line_metadata():
    """Test that JSON output includes line_metadata section."""
    analyzer = SingleFileAnalyzer(search_paths=[])

    asm_code = """
MAINSECT CSECT
         LA    R1,10
"""

    result = analyzer.analyze(Path("test.asm"), asm_code)
    emitter = JSONEmitter()
    json_output = emitter.emit_json(result.analysis_context)
    data = json.loads(json_output)

    # Should have line_metadata section
    assert "line_metadata" in data
    assert isinstance(data["line_metadata"], dict)


def test_json_line_metadata_structure():
    """Test line metadata JSON structure."""
    analyzer = SingleFileAnalyzer(search_paths=[])

    asm_code = """
MAINSECT CSECT
         LA    R1,10
"""

    result = analyzer.analyze(Path("test.asm"), asm_code)
    emitter = JSONEmitter()
    json_output = emitter.emit_json(result.analysis_context)
    data = json.loads(json_output)

    line_metadata = data["line_metadata"]

    # Should have at least one line
    assert len(line_metadata) > 0

    # Check structure of first entry
    first_key = list(line_metadata.keys())[0]
    first_entry = line_metadata[first_key]

    assert "codeblock" in first_entry
    assert "conditional" in first_entry
    assert "calls" in first_entry

    # Check codeblock structure
    assert "enclosing_section" in first_entry["codeblock"]
    assert "in_executable_block" in first_entry["codeblock"]

    # Check conditional structure
    assert "is_conditional" in first_entry["conditional"]
    assert "depth" in first_entry["conditional"]


def test_json_line_metadata_complete_workflow():
    """Test complete workflow with conditionals and calls."""
    from multi_file.c_family_analyzer import CFamilyAnalyzer

    analyzer = CFamilyAnalyzer("c")

    c_code = """
void helper() {}

int main() {
    int x = 10;
    if (x > 0) {
        helper();
    }
    return 0;
}
"""

    result = analyzer.analyze(Path("test.c"), c_code)
    emitter = JSONEmitter()
    json_output = emitter.emit_json(result.analysis_context)
    data = json.loads(json_output)

    line_metadata = data["line_metadata"]

    # Find line with helper() call (should be conditional)
    conditional_lines = [
        entry for entry in line_metadata.values()
        if entry["conditional"]["is_conditional"]
    ]

    # Should have at least one conditional line
    assert len(conditional_lines) > 0

    # Check that function calls are present
    lines_with_calls = [
        entry for entry in line_metadata.values()
        if len(entry["calls"]["calls_functions"]) > 0
    ]

    # main should show calls to helper
    assert len(lines_with_calls) > 0
