"""Integration test for file dependency graph building."""

import pytest
from pathlib import Path
from file_reader import FileReader
from statement_id_generator import StatementIDGenerator
from models.analysis_context import AnalysisContext
from passes.symbol_resolver import SymbolResolverPass
from passes.file_dependency_builder import FileDependencyBuilderPass
from models.file_dependency import DependencyType


def test_file_dependency_integration():
    """Test file dependency graph on complex program"""
    fixture_path = Path(__file__).parent.parent / "fixtures" / "complex_program.asm"
    fixtures_dir = fixture_path.parent

    # Setup
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen, search_paths=[str(fixtures_dir)])
    context = AnalysisContext()

    # Read file and track COPY includes
    lines = []
    copy_tracking = {}  # Track which files include which

    for parsed_line in reader.read_file(str(fixture_path)):
        lines.append(parsed_line)

        # Track COPY includes in context
        if parsed_line.provenance.expanded_from_copy:
            # This line came from a COPY include
            including_file = parsed_line.provenance.expanded_from_copy
            included_file = parsed_line.provenance.original_file

            # Only add once per include relationship
            key = (including_file, included_file)
            if key not in copy_tracking:
                copy_tracking[key] = True
                context.add_copy_include(
                    including_file=including_file,
                    included_file=included_file,
                    line_number=0  # Line number not available from provenance
                )

    # Build symbol table (Pass 2)
    symbol_resolver = SymbolResolverPass()
    symbol_resolver.process(lines, context)

    # Build file dependency graph (Pass 6)
    dependency_builder = FileDependencyBuilderPass()
    dependency_builder.process(context)

    # Verify graph was created
    graph = context.metadata.get("file_dependency_graph")
    assert graph is not None

    print(f"\n✓ File dependency graph created")
    print(f"✓ Nodes: {len(graph.nodes)}")
    print(f"✓ Edges: {len(graph.edges)}")
    print(f"✓ Circular dependencies: {len(graph.circular_dependencies)}")

    # Show dependencies
    if len(graph.edges) > 0:
        print("\n✓ Dependencies found:")
        for edge in graph.edges[:5]:
            dep_types = [e.dependency_type.value for e in edge.evidence]
            print(f"  {edge.from_file} → {edge.to_file} ({', '.join(dep_types)})")

    # Show circular dependencies
    if len(graph.circular_dependencies) > 0:
        print("\n✓ Circular dependencies:")
        for cycle in graph.circular_dependencies:
            cycle_str = " → ".join(cycle.files)
            print(f"  {cycle_str} ({cycle.cycle_type})")

    print("\n✓ File dependency integration test successful!")
