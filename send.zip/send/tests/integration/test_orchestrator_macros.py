from pathlib import Path
from multi_file.orchestrator import MultiFileOrchestrator


def test_orchestrator_with_macros(tmp_path):
    macro_file = tmp_path / "MACROS.asm"
    macro_file.write_text("""
         MACRO
         SETRC &RC
         LA    R15,&RC
         BR    R14
         MEND
""")

    source_file = tmp_path / "program.asm"
    source_file.write_text("""
PROGRAM  CSECT
MAIN     DS    0H
         SETRC 0
         BR    R14
         END
""")

    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()

    orchestrator = MultiFileOrchestrator(
        cache_dir=cache_dir,
        search_paths=[tmp_path],
        macro_libs=[macro_file]
    )

    result = orchestrator.analyze_files([source_file])

    assert len(result.file_results) == 1
    file_result = result.file_results[0]

    assert hasattr(file_result.analysis_context, 'macro_expansions')
    assert len(file_result.analysis_context.macro_expansions) > 0


def test_orchestrator_auto_discover_macros(tmp_path):
    macros_dir = tmp_path / "macros"
    macros_dir.mkdir()
    (macros_dir / "MACROS.asm").write_text("""
         MACRO
         NOOP
         NOP
         MEND
""")

    source_file = tmp_path / "program.asm"
    source_file.write_text("""
PROGRAM  CSECT
         NOOP
         BR    R14
         END
""")

    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()

    orchestrator = MultiFileOrchestrator(
        cache_dir=cache_dir,
        search_paths=[tmp_path]
    )

    result = orchestrator.analyze_files([source_file])

    file_result = result.file_results[0]
    assert hasattr(file_result.analysis_context, 'macro_expansions')
