"""Integration test for call graph building."""

import pytest
from pathlib import Path
from file_reader import FileReader
from statement_id_generator import StatementIDGenerator
from models.analysis_context import AnalysisContext
from passes.call_graph_builder import CallGraphBuilderPass
from models.call_graph import CallType


def test_call_graph_integration():
    """Test building call graph from complex program"""
    fixture_path = Path(__file__).parent.parent / "fixtures" / "complex_program.asm"
    fixtures_dir = fixture_path.parent

    # Setup
    id_gen = StatementIDGenerator()
    reader = FileReader(id_gen=id_gen, search_paths=[str(fixtures_dir)])
    context = AnalysisContext()
    builder = CallGraphBuilderPass()

    # Read file
    lines = list(reader.read_file(str(fixture_path)))

    # Build call graph
    builder.process(lines, context)

    # Verify call graph was created
    call_graph = context.metadata.get("call_graph")
    assert call_graph is not None

    print(f"\n✓ Call graph created")
    print(f"✓ Found {len(call_graph.nodes)} nodes")
    print(f"✓ Found {len(call_graph.edges)} edges")

    # Verify we have nodes
    assert len(call_graph.nodes) > 0

    # Verify we have edges
    assert len(call_graph.edges) > 0

    # Check for specific call types
    call_edges = [e for e in call_graph.edges if e.call_type == CallType.SUBROUTINE_CALL]
    branch_edges = [e for e in call_graph.edges if e.call_type == CallType.BRANCH]
    return_edges = [e for e in call_graph.edges if e.call_type == CallType.RETURN]

    print(f"✓ Subroutine calls: {len(call_edges)}")
    print(f"✓ Branches: {len(branch_edges)}")
    print(f"✓ Returns: {len(return_edges)}")

    # Verify indirect calls are flagged
    indirect_calls = call_graph.get_indirect_calls()
    print(f"✓ Indirect calls flagged: {len(indirect_calls)}")

    # Show some example edges
    print("\n✓ Sample call graph edges:")
    for i, edge in enumerate(call_graph.edges[:5]):
        target_str = edge.target if edge.target else f"<indirect:{edge.register}>"
        print(f"  {edge.source} --[{edge.instruction}]--> {target_str}")

    print("\n✓ Call graph integration test successful!")
