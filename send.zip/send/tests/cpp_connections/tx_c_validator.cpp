// tx_c_validator.cpp — Validator module for C++ connection tests.
//
// Connection types demonstrated in this file
// ─────────────────────────────────────────────────────────────────────────────
// [Gap 1]  extern "C" void CZ77(TPF_regs*)           bare ASM module name, no asm()
// [Gap 1]  extern "C" void DW88(TPF_regs*)           bare ASM module name, no asm()
// [Gap 2]  callAuditLog   asm("AL99")                CALL_ALIAS kept; phantom CALL suppressed
// [Gap 2]  callStatusUpd  asm("ST11")                CALL_ALIAS kept; phantom CALL suppressed
// [Gap 3]  performExternalValidation()               cross-DLL call
// [Gap 3]  sendExternalNotification()                cross-DLL call
// [Gap 3]  writeAuditTrail()                         cross-DLL call (in callbackFromC)
// [Gap 4]  #include "cctestshared.hpp"               INCLUDE edge
// [Gap 4]  #include "cctestextdll.hpp"               INCLUDE edge
// [C++→C++] processorEntry()                        cross-file → tx_b_processor (closes triangle)
// [C++→C++] processorAudit()                        cross-file → tx_b_processor
// [Internal] validateData() — 3 overloads            same-file; must NOT produce external edges
// [Internal] validateCode()                          same-file
//
// Fix 1: Function-pointer resolution
//   sfp = sharedEntry; sfp(wa)  → resolved to sharedEntry → edge to tx_d_shared
// ─────────────────────────────────────────────────────────────────────────────

#include "cctestshared.hpp"
#include "cctestextdll.hpp"

// ── Gap 1: bare ASM module names ─────────────────────────────────────────────
extern "C" void CZ77(TPF_regs*);
extern "C" void DW88(TPF_regs*);

// ── Gap 2: CALL_ALIAS pattern ─────────────────────────────────────────────────
#ifdef __370__
#pragma export(validatorEntry(TestWorkArea*))
#pragma export(callbackFromC(int, TestWorkArea*))
#pragma map(callAuditLog,  "AL99")
#pragma map(callStatusUpd, "ST11")
extern "C" void callAuditLog(TPF_regs*);
extern "C" void callStatusUpd(TPF_regs*);
#else
extern "C" void callAuditLog(TPF_regs*)  asm("AL99");
extern "C" void callStatusUpd(TPF_regs*) asm("ST11");
#endif

// ── Cross-file forward declarations ──────────────────────────────────────────
// Both defined in tx_b_processor.cpp — completing the A→B→C→B/A triangle.
int  processorEntry(TestWorkArea* wa, int flags);
void processorAudit(TestWorkArea* wa, int auditCode);

// ── Fix 1: forward declaration for function-pointer test ─────────────────────
// sharedEntry is defined in tx_d_shared.cpp.
// We take its address via a typedef to demonstrate function-pointer resolution:
//   sfp = sharedEntry; sfp(wa)  → resolved to sharedEntry → tx_d_shared.
void sharedEntry(TestWorkArea* wa);

// ── Same-file internal overloads (should NOT produce external edges) ──────────
static int validateData(const char* data, int len);
static int validateData(TestWorkArea* wa);
static int validateData(int code);
static int validateCode(char status, int flags);

// ─────────────────────────────────────────────────────────────────────────────
//  Primary entry point
// ─────────────────────────────────────────────────────────────────────────────
void validatorEntry(TestWorkArea* wa)
{
    TPF_regs regs;

    // [Internal — overloaded] All defined in this file; must NOT produce external edges.
    int v1 = validateData(wa->code, 4);
    int v2 = validateData(wa);
    int v3 = validateData(wa->counter);
    int v4 = validateCode(wa->status, wa->errorCode);

    // [Gap 2] CALL_ALIAS edges.
    callAuditLog(&regs);
    callStatusUpd(&regs);

    // [Gap 1] Bare ASM module names.
    CZ77(&regs);
    DW88(&regs);

    // [Gap 3] External DLL call.
    int ok = performExternalValidation(wa->code, 4);

    if (!ok) {
        // [C++→C++] Closes the tx_a→tx_b→tx_c→tx_b triangle.
        processorAudit(wa, v1 + v2 + v3 + v4);
    }

    // [Gap 3] Second external DLL call.
    sendExternalNotification(ok, wa->code);

    // [C++→C++] Cross-file call to tx_b_processor.cpp.
    int rc = processorEntry(wa, TX_TASK_VALIDATE);
    wa->errorCode = rc;

    // Inline helper from cctestshared.hpp.
    int cs = computeChecksum(wa->code, 4);
    wa->flags = (char)cs;

    // [Fix 1] Function-pointer call resolved to sharedEntry in tx_d_shared.
    // The typedef and single-identifier initialiser let _iter_callsites() trace
    // sfp → sharedEntry, so the blueprint records "sharedEntry" (not "sfp") and
    // build() resolves sharedentry → tx_d_shared as an internal edge.
    typedef void (*SharedFn)(TestWorkArea*);
    SharedFn sfp = sharedEntry;
    sfp(wa);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Callback invoked BY tx_b_processor.cpp (creates bidirectional edges)
// ─────────────────────────────────────────────────────────────────────────────
void callbackFromC(int result, TestWorkArea* wa)
{
    TPF_regs regs;

    // [Gap 2] CALL_ALIAS.
    callStatusUpd(&regs);

    // [Gap 3] External DLL call from callback.
    sendExternalNotification(result, wa->code);

    // [Gap 3] Audit trail.
    writeAuditTrail("tx_c_cb", result, wa->code);

    // [C++→C++] tx_c calls back into tx_b (reverse leg of mutual pair).
    int rc = processorEntry(wa, TX_TASK_CALLBACK);
    wa->result[0] = (char)(rc & 0xFF);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Internal same-file helpers — must NOT appear as external cross-file edges
// ─────────────────────────────────────────────────────────────────────────────
static int validateData(const char* data, int len)
{
    return computeChecksum(data, len);
}

static int validateData(TestWorkArea* wa)
{
    return validateData(wa->code, 4);
}

static int validateData(int code)
{
    return code & 0xFF;
}

static int validateCode(char status, int flags)
{
    int cs = computeChecksum(&status, 1);
    return cs ^ flags;
}
