// cctestextdll.hpp — External DLL / cross-module function declarations.
//
// These functions are declared here but their implementations live in a
// separate DLL or service module for which NO blueprint exists in the
// analysis set.  Calls to these functions should therefore appear as
// *external* (unresolved) edges in the file call graph — this is the
// Gap-3 pattern: cross-DLL C++ business-logic calls.
//
// Deliberately chosen NOT to be in _CPP_STDLIB_NOISE so that the
// file_call_graph builder keeps them as external edges.
#ifndef cctestextdll_hpp
#define cctestextdll_hpp

// Validation service (external DLL — no blueprint)
extern int  performExternalValidation(const char* data, int len);

// Notification service (external DLL — no blueprint)
extern void sendExternalNotification(int code, const char* msg);

// Database query service (external DLL — no blueprint)
extern int  queryExternalDatabase(const char* key, void* outBuf);

// Ledger update service (external DLL — no blueprint)
extern void updateExternalLedger(int accountId, double amount);

// Audit log service (external DLL — no blueprint)
extern int  writeAuditTrail(const char* module, int code, const char* detail);

#endif // cctestextdll_hpp
