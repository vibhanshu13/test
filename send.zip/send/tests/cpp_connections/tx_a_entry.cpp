// tx_a_entry.cpp — Entry-point module for C++ connection tests.
//
// Connection types demonstrated in this file
// ─────────────────────────────────────────────────────────────────────────────
// [Gap 1]  extern "C" void TX10(TPF_regs*)           bare ASM module name, no asm()
// [Gap 1]  extern "C" void XY99(TPF_regs*)           bare ASM module name, no asm()
// [Gap 2]  callValidator  asm("VA22")                CALL_ALIAS kept; phantom CALL suppressed
// [Gap 2]  callProcessor  #pragma map("PR33")        #pragma map variant; CALL_ALIAS kept
// [Gap 3]  performExternalValidation()               cross-DLL call (from cctestextdll.hpp)
// [Gap 3]  writeAuditTrail()                         cross-DLL call (from helperFromB)
// [Gap 4]  #include "cctestshared.hpp"               INCLUDE edge
// [Gap 4]  #include "cctestextdll.hpp"               INCLUDE edge
// [C++→C++] processorEntry()                        cross-file call → tx_b_processor
// [C++→C++] validatorEntry()                        cross-file call → tx_c_validator
// [C++→C++] TxShared::sharedEntry()                 namespace-qualified → tx_d_shared
// [Header] computeChecksum()                        inline in cctestshared.hpp → cctestshared
// [Internal] entryHelper()                          same-file; must NOT appear as external edge
// [Mutual]   helperFromB()                          defined here; called BY tx_b_processor
//
// Fixed limitations (now captured):
//   - Namespace-qualified calls: TxShared::sharedEntry() → prefix stripped → resolves to tx_d_shared
//   - Inline header functions:   computeChecksum() → hpp.json loaded → resolves to cctestshared
//
// Remaining design limitations (not captured by design):
//   - Function-pointer calls: AsmFnPtr fp = TX10; fp(&regs)  → is_indirect=true, filtered
//   - Object-instance method: obj.method()                   → dot accessor, filtered
//   - Arrow method:           ptr->method()                  → arrow accessor, filtered
//   - Lambda variable calls:  auto f=[&](){...}; f()         → local var, not a link symbol
// ─────────────────────────────────────────────────────────────────────────────

#include "cctestshared.hpp"
#include "cctestextdll.hpp"

// ── Gap 1: extern "C" with bare ASM module names (no asm() qualifier) ──────
// These match ASM_MODULE_RE (4-6 uppercase chars) and must be kept as
// external CALL edges rather than being dropped.
extern "C" void TX10(TPF_regs*);
extern "C" void XY99(TPF_regs*);

// ── Gap 2: CALL_ALIAS pattern ───────────────────────────────────────────────
// IBM z/TPF xlC: #pragma map; Linux/GCC: asm() label.
// The corresponding CALL→callValidator / CALL→callProcessor phantom edges
// must be suppressed; only the CALL_ALIAS→VA22 / CALL_ALIAS→PR33 edges kept.
#ifdef __370__
#pragma export(entryPointA())
#pragma map(callValidator, "VA22")
#pragma map(callProcessor, "PR33")
extern "C" void callValidator(TPF_regs*);
extern "C" void callProcessor(TPF_regs*);
#else
extern "C" void callValidator(TPF_regs*) asm("VA22");
extern "C" void callProcessor(TPF_regs*) asm("PR33");
#endif

// ── Cross-file forward declarations ─────────────────────────────────────────
// processorEntry defined in tx_b_processor.cpp  → C++→C++ edge
// validatorEntry defined in tx_c_validator.cpp  → C++→C++ edge
int  processorEntry(TestWorkArea* wa, int flags);
void validatorEntry(TestWorkArea* wa);

// ── Namespace-qualified cross-file call (tests namespace prefix stripping) ──
// sharedEntry is defined in tx_d_shared.cpp.
// Calling it via TxShared::sharedEntry() exercises the namespace stripping fix:
// "TxShared::sharedEntry" → tail "sharedEntry" → resolves to tx_d_shared.
namespace TxShared {
    extern void sharedEntry(TestWorkArea* wa);
}

// ── Same-file internal forward declaration ───────────────────────────────────
void entryHelper(TestWorkArea* wa, TxTask task);

// ── Mutual: defined here, called BY tx_b_processor.cpp ───────────────────────
void helperFromB(TestWorkArea* wa, int resultCode);

// ─────────────────────────────────────────────────────────────────────────────
//  Entry point
// ─────────────────────────────────────────────────────────────────────────────
void entryPointA()
{
    TestWorkArea wa;
    memset(&wa, 0, sizeof(wa));
    wa.counter = 1;
    wa.status  = 'A';
    memcpy(wa.code, "TEST", 4);

    TPF_regs regs;

    // [Internal] Same-file call — must NOT appear as cross-file external edge.
    entryHelper(&wa, TX_TASK_VALIDATE);

    // [C++→C++] Cross-file call to processorEntry in tx_b_processor.cpp.
    int rc = processorEntry(&wa, 1);

    // [C++→C++] Cross-file call to validatorEntry in tx_c_validator.cpp.
    validatorEntry(&wa);

    // [Gap 2] CALL_ALIAS: callValidator is the C++ wrapper for ASM routine VA22.
    // The phantom CALL→callValidator must be suppressed; CALL_ALIAS→VA22 is kept.
    callValidator(&regs);

    // [Gap 2] CALL_ALIAS via #pragma map: callProcessor wraps ASM routine PR33.
    // Phantom CALL→callProcessor suppressed; CALL_ALIAS→PR33 kept.
    callProcessor(&regs);

    // [Gap 1] Bare ASM module names — no asm() qualifier.
    // These survive as external edges because they match ASM_MODULE_RE.
    TX10(&regs);
    if (rc != 0) {
        XY99(&regs);
    }

    // [Gap 3] Cross-DLL call: no blueprint for performExternalValidation.
    int chk = performExternalValidation(wa.code, 4);
    wa.errorCode = chk;

    // [Namespace] Namespace-qualified call to tx_d_shared.cpp.
    // The parser records the target as "TxShared::sharedEntry"; the build()
    // namespace-stripping fix resolves it to tx_d_shared as an internal edge.
    TxShared::sharedEntry(&wa);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Same-file internal helper (same stem → must be suppressed as external edge)
// ─────────────────────────────────────────────────────────────────────────────
void entryHelper(TestWorkArea* wa, TxTask task)
{
    // Uses inline function from cctestshared.hpp header.
    int cs = computeChecksum(wa->code, 4);
    wa->flags = (char)(cs & (int)task);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Callback invoked BY tx_b_processor.cpp (mutual C++↔C++ edge pair)
// ─────────────────────────────────────────────────────────────────────────────
void helperFromB(TestWorkArea* wa, int resultCode)
{
    TPF_regs regs;

    // [Gap 1] Bare ASM call from a non-entry-point function.
    XY99(&regs);

    // [Gap 3] External DLL call from callback.
    writeAuditTrail("tx_a", resultCode, wa->code);

    wa->result[0] = (char)(resultCode & 0xFF);
}
