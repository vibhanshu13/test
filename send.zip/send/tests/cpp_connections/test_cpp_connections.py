#!/usr/bin/env python3
"""
Test: C++ cross-file connection coverage.

Pipeline:
  1. Analyse tx_a_entry.cpp, tx_b_processor.cpp, tx_c_validator.cpp with main.py
  2. Build file_call_graph.json from the resulting blueprints
  3. Assert every expected connection is present; report known limitations

Run from the repo root:
  python3 tests/cpp_connections/test_cpp_connections.py
"""
import json
import subprocess
import sys
from pathlib import Path

# ── Paths ────────────────────────────────────────────────────────────────────
REPO_ROOT  = Path(__file__).parent.parent.parent.resolve()
TEST_DIR   = Path(__file__).parent.resolve()
OUT_DIR    = TEST_DIR / "output"
GRAPH_FILE = TEST_DIR / "test_call_graph.json"

CPP_SOURCES = [
    TEST_DIR / "tx_a_entry.cpp",
    TEST_DIR / "tx_b_processor.cpp",
    TEST_DIR / "tx_c_validator.cpp",
    TEST_DIR / "tx_d_shared.cpp",
]

# ── Expected connection catalogue ─────────────────────────────────────────────
# (from_stem, to_target, instruction, description)
# Targets for external edges match the uppercased form used in the graph.
# Targets for internal edges match the stem of the .cpp file.
# The edge_key() function lower-cases both sides before comparison.

EXPECTED = [
    # ── Gap 1: extern "C" bare ASM module names ─────────────────────────────
    # Must appear as external CALL edges because they match ASM_MODULE_RE.
    # Previously these were silently dropped — fixed by Gap 1 logic in build().
    ("tx_a_entry",    "TX10",  "CALL", "Gap 1 – tx_a bare ASM name TX10"),
    ("tx_a_entry",    "XY99",  "CALL", "Gap 1 – tx_a bare ASM name XY99"),
    ("tx_b_processor","BX44",  "CALL", "Gap 1 – tx_b bare ASM name BX44"),
    ("tx_b_processor","MN66",  "CALL", "Gap 1 – tx_b bare ASM name MN66"),
    ("tx_c_validator","CZ77",  "CALL", "Gap 1 – tx_c bare ASM name CZ77"),
    ("tx_c_validator","DW88",  "CALL", "Gap 1 – tx_c bare ASM name DW88"),

    # ── Gap 2: CALL_ALIAS edges (phantom CALL suppressed) ───────────────────
    # Only CALL_ALIAS should exist; CALL to the C++ wrapper name must be absent.
    ("tx_a_entry",    "VA22",  "CALL_ALIAS", "Gap 2 – tx_a CALL_ALIAS VA22 (callValidator)"),
    ("tx_a_entry",    "PR33",  "CALL_ALIAS", "Gap 2 – tx_a CALL_ALIAS PR33 (callProcessor)"),
    ("tx_b_processor","NG55",  "CALL_ALIAS", "Gap 2 – tx_b CALL_ALIAS NG55 (callNegUpdate)"),
    ("tx_b_processor","CS77",  "CALL_ALIAS", "Gap 2 – tx_b CALL_ALIAS CS77 (callCheckStatus)"),
    ("tx_c_validator","AL99",  "CALL_ALIAS", "Gap 2 – tx_c CALL_ALIAS AL99 (callAuditLog)"),
    ("tx_c_validator","ST11",  "CALL_ALIAS", "Gap 2 – tx_c CALL_ALIAS ST11 (callStatusUpd)"),

    # ── Gap 3: cross-DLL external calls (no blueprint) ──────────────────────
    # Unresolved CALL edges from C++ sources not in _CPP_STDLIB_NOISE.
    ("tx_a_entry",    "performExternalValidation", "CALL", "Gap 3 – tx_a external DLL call"),
    ("tx_a_entry",    "writeAuditTrail",           "CALL", "Gap 3 – tx_a writeAuditTrail"),
    ("tx_b_processor","queryExternalDatabase",     "CALL", "Gap 3 – tx_b DB query"),
    ("tx_b_processor","sendExternalNotification",  "CALL", "Gap 3 – tx_b notification"),
    ("tx_b_processor","updateExternalLedger",      "CALL", "Gap 3 – tx_b ledger update"),
    ("tx_b_processor","performExternalValidation", "CALL", "Gap 3 – tx_b validation (processorAudit)"),
    ("tx_b_processor","writeAuditTrail",           "CALL", "Gap 3 – tx_b writeAuditTrail"),
    ("tx_c_validator","performExternalValidation", "CALL", "Gap 3 – tx_c external validation"),
    ("tx_c_validator","sendExternalNotification",  "CALL", "Gap 3 – tx_c notification"),
    ("tx_c_validator","writeAuditTrail",           "CALL", "Gap 3 – tx_c writeAuditTrail"),

    # ── Gap 4: #include dependency edges ────────────────────────────────────
    # Every #include directive in each .cpp file must produce an INCLUDE edge.
    ("tx_a_entry",    "cctestshared.hpp", "INCLUDE", "Gap 4 – tx_a includes cctestshared"),
    ("tx_a_entry",    "cctestextdll.hpp", "INCLUDE", "Gap 4 – tx_a includes cctestextdll"),
    ("tx_b_processor","cctestshared.hpp", "INCLUDE", "Gap 4 – tx_b includes cctestshared"),
    ("tx_b_processor","cctestextdll.hpp", "INCLUDE", "Gap 4 – tx_b includes cctestextdll"),
    ("tx_c_validator","cctestshared.hpp", "INCLUDE", "Gap 4 – tx_c includes cctestshared"),
    ("tx_c_validator","cctestextdll.hpp", "INCLUDE", "Gap 4 – tx_c includes cctestextdll"),

    # ── C++→C++ cross-file internal edges ───────────────────────────────────
    # Target function defined in another .cpp in the analysis set.
    # The call graph deduplicates per (source_stem, target_stem) pair, so even
    # if multiple functions in file A call into file B, a single edge is emitted.
    ("tx_a_entry",    "tx_b_processor", "CALL", "C++→C++ tx_a → tx_b (processorEntry)"),
    ("tx_a_entry",    "tx_c_validator", "CALL", "C++→C++ tx_a → tx_c (validatorEntry)"),
    ("tx_b_processor","tx_c_validator", "CALL", "C++→C++ tx_b → tx_c (validatorEntry + callbackFromC, merged)"),
    ("tx_b_processor","tx_a_entry",     "CALL", "C++→C++ tx_b → tx_a (helperFromB – mutual/bidirectional)"),
    ("tx_c_validator","tx_b_processor", "CALL", "C++→C++ tx_c → tx_b (processorAudit + processorEntry, merged)"),

    # ── Fixed: namespace-qualified calls ────────────────────────────────────
    # TxShared::sharedEntry() in tx_a_entry.cpp — namespace prefix stripped,
    # then sharedEntry resolved via cpp_fn_to_stem → tx_d_shared.
    ("tx_a_entry",    "tx_d_shared",    "CALL", "Namespace – TxShared::sharedEntry resolves to tx_d_shared"),

    # ── Fixed: inline header-only function resolution ───────────────────────
    # computeChecksum defined in cctestshared.hpp; *.hpp.json loaded by
    # _build_cpp_lookup_maps → resolves as an internal edge to cctestshared.
    ("tx_a_entry",    "cctestshared",   "CALL", "Header – computeChecksum in tx_a resolves to cctestshared"),
    ("tx_c_validator","cctestshared",   "CALL", "Header – computeChecksum in tx_c resolves to cctestshared"),
    ("tx_d_shared",   "cctestshared",   "CALL", "Header – computeChecksum in tx_d resolves to cctestshared"),

    # ── Gap 4: INCLUDE edges for tx_d_shared ─────────────────────────────────
    ("tx_d_shared",   "cctestshared.hpp", "INCLUDE", "Gap 4 – tx_d includes cctestshared"),

    # ── Fix 1: Function-pointer resolution ───────────────────────────────────
    # tx_c_validator declares SharedFn sfp = sharedEntry; sfp(wa).
    # _iter_callsites() traces sfp → sharedEntry (single-identifier init), yields
    # "sharedEntry"; build() resolves sharedentry → tx_d_shared (internal edge).
    # This is the FIRST connection from tx_c_validator to tx_d_shared.
    ("tx_c_validator", "tx_d_shared", "CALL",
     "Fix1-FP – sfp resolved to sharedEntry (tx_d_shared)"),

    # ── Fix 2: Object method FQN resolution ──────────────────────────────────
    # tx_b_processor declares SharedHelper shHelper; shHelper.sharedEntry(&wa).
    # _iter_callsites() constructs FQN "SharedHelper::sharedEntry"; build() strips
    # namespace → "sharedentry" → tx_d_shared.
    # This is the FIRST connection from tx_b_processor to tx_d_shared.
    ("tx_b_processor", "tx_d_shared", "CALL",
     "Fix2-Method – SharedHelper::sharedEntry FQN resolved to tx_d_shared"),

    # ── Fix 4: Virtual dispatch via CHA ──────────────────────────────────────
    # tx_d_shared declares IEntryCallback* cb = &concreteCallback; cb->helperFromB(wa,0).
    # cb type = IEntryCallback; CHA subclass = ConcreteEntryCallback.
    # FQN "ConcreteEntryCallback::helperFromB" → strip NS → "helperfromb" → tx_a_entry.
    # This is the FIRST connection from tx_d_shared to tx_a_entry.
    ("tx_d_shared", "tx_a_entry", "CALL",
     "Fix4-CHA – ConcreteEntryCallback::helperFromB resolved to tx_a_entry"),
]

# ── Phantom CALL edges that MUST NOT exist (Gap 2 suppression) ───────────────
MUST_NOT_EXIST = [
    ("tx_a_entry",    "callValidator",  "CALL", "Gap 2 phantom – callValidator must be suppressed"),
    ("tx_a_entry",    "callProcessor",  "CALL", "Gap 2 phantom – callProcessor must be suppressed"),
    ("tx_b_processor","callNegUpdate",  "CALL", "Gap 2 phantom – callNegUpdate must be suppressed"),
    ("tx_b_processor","callCheckStatus","CALL", "Gap 2 phantom – callCheckStatus must be suppressed"),
    ("tx_c_validator","callAuditLog",   "CALL", "Gap 2 phantom – callAuditLog must be suppressed"),
    ("tx_c_validator","callStatusUpd",  "CALL", "Gap 2 phantom – callStatusUpd must be suppressed"),
    # Fix 3: Lambda variable call — must NOT appear as external edge.
    # tx_b_processor has: auto doLog = [&](){...}; doLog();
    # analyze() sets is_local_var=True on this edge; scan_blueprint_cpp() suppresses it.
    ("tx_b_processor","doLog",  "CALL", "Fix3-Lambda – doLog must be suppressed"),
    ("tx_b_processor","DOLOG",  "CALL", "Fix3-Lambda – DOLOG (uppercase) must be suppressed"),
]

# ── Internal same-file calls that must NOT appear as cross-file edges ─────────
INTERNAL_MUST_NOT_CROSS = [
    # entryHelper and helperFromB are defined in tx_a_entry; calling them from
    # within tx_a_entry must not produce a cross-file edge.
    ("tx_a_entry", "entryHelper",  "CALL", "Internal – tx_a/entryHelper must not be external"),
    # validateData / validateCode defined in tx_c_validator — same rule.
    ("tx_c_validator", "validateData", "CALL", "Internal – tx_c/validateData must not be external"),
    ("tx_c_validator", "validateCode", "CALL", "Internal – tx_c/validateCode must not be external"),
]

# ── Known limitations (NOT captured by design) ───────────────────────────────
# Previously-documented limitations that are now FIXED:
#   [FIXED] Namespace-qualified calls (NS::func()) — namespace prefix is now stripped
#           in build(); TxShared::sharedEntry → resolves to tx_d_shared.
#   [FIXED] Inline header-only functions — *.hpp.json blueprints are now loaded by
#           _build_cpp_lookup_maps; computeChecksum → resolves to cctestshared.
#   [FIXED] Function-pointer calls (simple direct-assignment case) — traced in
#           _iter_callsites() via fp_sources; sfp = sharedEntry; sfp(wa) → sharedEntry.
#   [FIXED] Object-instance method calls (obj.method()) — FQN constructed in
#           _iter_callsites(); SharedHelper::sharedEntry → resolves to tx_d_shared.
#   [FIXED] Pointer method calls (ptr->method()) via CHA — base type FQN + all
#           subclass FQNs emitted; ConcreteEntryCallback::helperFromB → tx_a_entry.
#   [FIXED] Lambda variable invocations — is_local_var=True flag added to edges so
#           scan_blueprint_cpp() suppresses the spurious external edge.
#
# Remaining design limitations:
KNOWN_LIMITATIONS = [
    "Function-pointer calls via re-assignment (sfp = fn1; sfp = fn2; sfp()) — only the "
    "declaration-time initialiser is traced; post-declaration re-assignments are not.",
    "Object method calls where the variable type cannot be inferred from declarations "
    "(e.g. auto-typed, template-dependent, or returned from a factory function).",
    "Virtual dispatch CHA across translation units — class_bases is per-file; subclasses "
    "defined in OTHER .cpp files are not visible to the calling file's CHA.",
    "Deeply indirect calls (fp = getPtr(); fp()) where the RHS is itself a call expression "
    "— only single-identifier initialisers are traced in fp_sources.",
]

# ── Expected 'informational' external edges (not failures) ───────────────────
# computeChecksum is now resolved as an INTERNAL edge to cctestshared, so
# the COMPUTECHECKSUM external node no longer appears in the graph.
# This section is kept to document what changed between the initial and fixed versions.
INFORMATIONAL = [
    # (empty — previously held COMPUTECHECKSUM external entries that are now fixed)
]


# ─────────────────────────────────────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────────────────────────────────────

def run(cmd, *, check=True):
    print("  $", " ".join(str(c) for c in cmd))
    result = subprocess.run(
        [str(c) for c in cmd],
        cwd=str(REPO_ROOT),
        check=False,
    )
    if check and result.returncode != 0:
        sys.exit(f"\nERROR: command exited with code {result.returncode}")
    return result


def edge_key(from_stem: str, to_target: str, instruction: str) -> tuple:
    return (from_stem.lower(), to_target.lower(), instruction.upper())


def build_edge_set(graph: dict) -> set:
    """Return set of (source, target, instruction) from the call graph JSON.

    The JSON format uses:
      edge.source       — source stem
      edge.target       — target stem or external name (uppercase)
      edge.instructions — list of instruction types (e.g. ["CALL"], ["INCLUDE"])
    """
    edges = set()
    for edge in graph.get("edges", []):
        src  = edge.get("source", "")
        tgt  = edge.get("target", "")
        for inst in (edge.get("instructions") or []):
            if src and tgt and inst:
                edges.add(edge_key(src, tgt, inst))
    return edges


def check_lists(edge_set: set, expected, must_not, internal_must_not):
    passed, failed, phantom_failed, internal_leaked = [], [], [], []

    for from_s, to_t, inst, desc in expected:
        k = edge_key(from_s, to_t, inst)
        (passed if k in edge_set else failed).append((desc, k))

    for from_s, to_t, inst, desc in must_not:
        k = edge_key(from_s, to_t, inst)
        if k in edge_set:
            phantom_failed.append((desc, k))

    for from_s, to_t, inst, desc in internal_must_not:
        k = edge_key(from_s, to_t, inst)
        if k in edge_set:
            internal_leaked.append((desc, k))

    return passed, failed, phantom_failed, internal_leaked


# ─────────────────────────────────────────────────────────────────────────────
#  Main
# ─────────────────────────────────────────────────────────────────────────────

def main():
    print("=" * 70)
    print("C++ Connection Coverage Test")
    print("=" * 70)

    # ── Step 1: Analysis pipeline ──────────────────────────────────────────
    print("\n[1/3] Running main.py (blueprint generation) …")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    run([sys.executable, REPO_ROOT / "main.py", *CPP_SOURCES, "-o", OUT_DIR])

    # ── Step 2: File call graph ────────────────────────────────────────────
    print("\n[2/3] Building file_call_graph.json …")
    run([
        sys.executable, REPO_ROOT / "file_call_graph.py",
        "--blueprint-dir", OUT_DIR,
        "--output", GRAPH_FILE,
    ])

    # ── Step 3: Verify ────────────────────────────────────────────────────
    print("\n[3/3] Verifying connections …")
    graph    = json.loads(GRAPH_FILE.read_text())
    edge_set = build_edge_set(graph)

    passed, failed, phantom_failed, internal_leaked = check_lists(
        edge_set, EXPECTED, MUST_NOT_EXIST, INTERNAL_MUST_NOT_CROSS
    )

    # ── Print results ─────────────────────────────────────────────────────
    print()
    print("=" * 70)
    ok = (len(failed) == 0 and len(phantom_failed) == 0 and len(internal_leaked) == 0)
    total_checks = len(EXPECTED) + len(MUST_NOT_EXIST) + len(INTERNAL_MUST_NOT_CROSS)
    total_pass   = len(passed) + (len(MUST_NOT_EXIST) - len(phantom_failed)) + (len(INTERNAL_MUST_NOT_CROSS) - len(internal_leaked))

    print(f"{'ALL PASS' if ok else 'FAILURES DETECTED'}  "
          f"({total_pass}/{total_checks} checks passed)")
    print()

    # ── Passing ──────────────────────────────────────────────────────────
    print("── Expected connections found " + "─" * 40)
    for desc, _ in passed:
        print(f"  PASS  {desc}")

    # ── Gap 2 phantom suppression ─────────────────────────────────────────
    print()
    print("── Gap 2 phantom suppression " + "─" * 41)
    for from_s, to_t, inst, desc in MUST_NOT_EXIST:
        k = edge_key(from_s, to_t, inst)
        status = "FAIL (PHANTOM PRESENT)" if k in edge_set else "PASS  suppressed"
        print(f"  {status}  {desc}")

    # ── Internal same-file edge suppression ───────────────────────────────
    print()
    print("── Internal same-file edge suppression " + "─" * 31)
    for from_s, to_t, inst, desc in INTERNAL_MUST_NOT_CROSS:
        k = edge_key(from_s, to_t, inst)
        status = "FAIL (LEAKED EXTERNAL)" if k in edge_set else "PASS  not leaked"
        print(f"  {status}  {desc}")

    # ── Failures (if any) ─────────────────────────────────────────────────
    if failed or phantom_failed or internal_leaked:
        print()
        print("── FAILURES " + "─" * 58)
        for desc, key in failed:
            print(f"  FAIL  missing: {desc}")
            print(f"        key:     {key}")
        for desc, key in phantom_failed:
            print(f"  FAIL  phantom: {desc}")
            print(f"        key:     {key}")
        for desc, key in internal_leaked:
            print(f"  FAIL  leaked:  {desc}")
            print(f"        key:     {key}")

    # ── Informational ─────────────────────────────────────────────────────
    print()
    print("── Informational edges (expected parser behaviour, not failures) " + "─" * 6)
    for from_s, to_t, inst, desc in INFORMATIONAL:
        k   = edge_key(from_s, to_t, inst)
        sym = "PRESENT" if k in edge_set else "absent"
        print(f"  {sym}  {desc}")

    # ── Known limitations ─────────────────────────────────────────────────
    print()
    print("── Known limitations (not captured by design) " + "─" * 24)
    for lim in KNOWN_LIMITATIONS:
        print(f"  NOTE  {lim}")

    # ── Full edge dump ────────────────────────────────────────────────────
    print()
    print("── Full call graph " + "─" * 51)
    for edge in sorted(graph.get("edges", []),
                       key=lambda e: (e.get("source",""), e.get("target",""))):
        src  = edge.get("source", "?")
        tgt  = edge.get("target", "?")
        inst = ",".join(edge.get("instructions", ["?"]))
        kind = "internal" if edge.get("is_internal") else "external"
        print(f"  {src} → {tgt}  [{inst}]  {kind}")

    print()
    print(f"Total: {len(graph.get('nodes',[]))} nodes, {len(graph.get('edges',[]))} edges")
    print("=" * 70)

    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
