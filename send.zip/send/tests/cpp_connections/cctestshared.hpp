// cctestshared.hpp — Shared types for C++ connection tests.
// Provides a minimal TPF_regs stand-in and shared work-area struct so that
// all test .cpp files parse without external TPF header dependencies.
#ifndef cctestshared_hpp
#define cctestshared_hpp

#include <string.h>
#include <stdlib.h>

// Minimal TPF register set (stand-in for <tpf/tpfregs.h>)
struct TPF_regs {
    long r0, r1, r2, r3, r4, r5, r6, r7;
    long r8, r9, r10, r11, r12, r13, r14, r15;
};

// Shared work-area struct used by all three test modules.
// Field comments mirror the WK_* naming convention used in real HLASM bridges.
struct TestWorkArea {
    int  counter;        // TEST_CNT
    char status;         // TEST_STS
    char code[4];        // TEST_CODE
    char result[8];      // TEST_RESULT
    int  errorCode;      // TEST_ERR
    char flags;          // TEST_FLAGS
};

// Simple inline checksum helper (lives in header — no separate blueprint).
// Used to exercise "INCLUDE edge to header with inline code" (Gap 4).
inline int computeChecksum(const char* data, int len) {
    int sum = 0;
    for (int i = 0; i < len; i++) sum += (unsigned char)data[i];
    return sum & 0xFF;
}

// Enum used across modules to pass task type
enum TxTask {
    TX_TASK_VALIDATE  = 1,
    TX_TASK_PROCESS   = 2,
    TX_TASK_AUDIT     = 3,
    TX_TASK_CALLBACK  = 4,
};

#endif // cctestshared_hpp
