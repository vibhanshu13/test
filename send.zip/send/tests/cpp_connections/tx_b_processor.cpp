// tx_b_processor.cpp — Processing module for C++ connection tests.
//
// Connection types demonstrated in this file
// ─────────────────────────────────────────────────────────────────────────────
// [Gap 1]  extern "C" void BX44(TPF_regs*)           bare ASM module name, no asm()
// [Gap 1]  extern "C" void MN66(TPF_regs*)           bare ASM module name, no asm()
// [Gap 2]  callNegUpdate   asm("NG55")               CALL_ALIAS kept; phantom CALL suppressed
// [Gap 2]  callCheckStatus asm("CS77")               CALL_ALIAS kept; phantom CALL suppressed
// [Gap 3]  queryExternalDatabase()                   cross-DLL call
// [Gap 3]  sendExternalNotification()                cross-DLL call
// [Gap 3]  updateExternalLedger()                    cross-DLL call
// [Gap 3]  performExternalValidation()               cross-DLL call (from processorAudit)
// [Gap 3]  writeAuditTrail()                         cross-DLL call
// [Gap 4]  #include "cctestshared.hpp"               INCLUDE edge
// [Gap 4]  #include "cctestextdll.hpp"               INCLUDE edge
// [C++→C++] validatorEntry()                        cross-file → tx_c_validator
// [C++→C++] callbackFromC()                         cross-file → tx_c_validator
// [Mutual]  helperFromB()                           calls back into tx_a_entry (bidirectional)
//
// Fix 2: Object method FQN resolution
//   SharedHelper shHelper; shHelper.sharedEntry(&wa)  → FQN SharedHelper::sharedEntry
//   → namespace strip → sharedentry → tx_d_shared (internal edge)
// Fix 3: Lambda suppression
//   auto doLog = [&](){...}; doLog()  → is_local_var=true → filtered (MUST_NOT_EXIST)
// ─────────────────────────────────────────────────────────────────────────────

#include "cctestshared.hpp"
#include "cctestextdll.hpp"

// ── Gap 1: bare ASM module names ─────────────────────────────────────────────
extern "C" void BX44(TPF_regs*);
extern "C" void MN66(TPF_regs*);

// ── Gap 2: CALL_ALIAS pattern ────────────────────────────────────────────────
#ifdef __370__
#pragma export(processorEntry(TestWorkArea*, int))
#pragma export(processorAudit(TestWorkArea*, int))
#pragma map(callNegUpdate,   "NG55")
#pragma map(callCheckStatus, "CS77")
extern "C" void callNegUpdate(TPF_regs*);
extern "C" void callCheckStatus(TPF_regs*);
#else
extern "C" void callNegUpdate(TPF_regs*)   asm("NG55");
extern "C" void callCheckStatus(TPF_regs*) asm("CS77");
#endif

// ── Cross-file forward declarations ──────────────────────────────────────────
void validatorEntry(TestWorkArea* wa);
void callbackFromC(int result, TestWorkArea* wa);

// ── Mutual: helperFromB defined in tx_a_entry.cpp ────────────────────────────
void helperFromB(TestWorkArea* wa, int resultCode);

// ── Fix 2: Struct whose method maps to a function in tx_d_shared ─────────────
// sharedEntry() is the function exported from tx_d_shared.cpp.
// By naming the method identically and calling it as shHelper.sharedEntry(),
// _iter_callsites() constructs FQN "SharedHelper::sharedEntry", which
// build() resolves via namespace stripping to tx_d_shared.
struct SharedHelper {
    void sharedEntry(TestWorkArea* wa);
};

// ─────────────────────────────────────────────────────────────────────────────
//  Primary entry point
// ─────────────────────────────────────────────────────────────────────────────
int processorEntry(TestWorkArea* wa, int flags)
{
    TPF_regs regs;
    int result = 0;

    // [Gap 3] Cross-DLL calls.
    result = queryExternalDatabase(wa->code, wa);
    sendExternalNotification(result, wa->code);

    // [Gap 2] CALL_ALIAS: phantom CALL→callNegUpdate suppressed; CALL_ALIAS→NG55 kept.
    callNegUpdate(&regs);

    // [Gap 2] CALL_ALIAS: phantom CALL→callCheckStatus suppressed; CALL_ALIAS→CS77 kept.
    callCheckStatus(&regs);

    // [Gap 1] Bare ASM module call.
    BX44(&regs);

    // [C++→C++] Cross-file call to tx_c_validator.cpp.
    validatorEntry(wa);

    // [C++→C++] Cross-file call to tx_c_validator.cpp (callback variant).
    callbackFromC(result, wa);

    // [Mutual] Call back into tx_a_entry.cpp.
    if (flags & 0x01) {
        helperFromB(wa, result);
    }

    // [Gap 3] Conditional cross-DLL call.
    if (result > 0) {
        updateExternalLedger(wa->counter, (double)result);
    }

    writeAuditTrail("tx_b", result, wa->code);

    // [Fix 2] Object method call resolved to tx_d_shared via FQN.
    // _iter_callsites() sees "shHelper.sharedEntry", looks up type of shHelper
    // (= "SharedHelper"), constructs FQN "SharedHelper::sharedEntry", and yields it.
    // build() strips the "SharedHelper::" prefix → looks up "sharedentry" in
    // cpp_fn_to_stem → resolves to tx_d_shared as an internal edge.
    SharedHelper shHelper;
    shHelper.sharedEntry(wa);

    // [Fix 3] Lambda variable call — MUST be suppressed (not appear as external edge).
    // The lambda's body (writeAuditTrail) is already captured via the direct call above.
    // doLog is a local variable; _iter_callsites() still yields it but analyze() sets
    // is_local_var=True on the edge so scan_blueprint_cpp() filters it out.
    auto doLog = [&]() { writeAuditTrail("log", 0, wa->code); };
    doLog();

    return result;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Secondary exported function
// ─────────────────────────────────────────────────────────────────────────────
void processorAudit(TestWorkArea* wa, int auditCode)
{
    TPF_regs regs;

    // [Gap 3] External DLL call from secondary function.
    performExternalValidation(wa->code, auditCode);

    // [Gap 1] From secondary (non-primary) function.
    MN66(&regs);

    // [Gap 1] BX44 called from both functions; deduplication ensures
    // the final call graph has one edge per unique (stem, target, instruction, line).
    BX44(&regs);

    wa->errorCode = auditCode;
}
