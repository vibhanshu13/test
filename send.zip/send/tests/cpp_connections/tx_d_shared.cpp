// tx_d_shared.cpp — Shared module exercising fixes for FP, FQN, CHA resolution.
//
// Connection types demonstrated in this file
// ─────────────────────────────────────────────────────────────────────────────
// [Header]   computeChecksum()              inline in cctestshared.hpp → cctestshared
// [Gap 4]    #include "cctestshared.hpp"   INCLUDE edge
// [Fix 4]    cb->helperFromB() (virtual)    CHA → helperFromB defined in tx_a_entry
//
// Symbols exported (called from elsewhere)
// ─────────────────────────────────────────────────────────────────────────────
//   sharedEntry(TestWorkArea*)   — called from
//                                    * tx_a_entry as  TxShared::sharedEntry  (namespace strip)
//                                    * tx_b_processor as SharedHelper::sharedEntry  (FQN strip)
//                                    * tx_c_validator as sfp = sharedEntry; sfp(wa)  (FP)
// ─────────────────────────────────────────────────────────────────────────────

#include "cctestshared.hpp"

// ── Cross-file forward declaration: helperFromB lives in tx_a_entry.cpp ─────
// Used as the override target for IEntryCallback::helperFromB.  Pure-cross-file
// CHA: when we do cb->helperFromB(...), the parser emits both base and
// derived FQNs (IEntryCallback::helperFromB, ConcreteEntryCallback::helperFromB);
// both strip to "helperfromb" and resolve to tx_a_entry.
void helperFromB(TestWorkArea* wa, int resultCode);

// ── Fix 4 (CHA): virtual dispatch base + concrete subclass ──────────────────
// IEntryCallback is the abstract base; ConcreteEntryCallback overrides
// helperFromB.  Calling helperFromB through a base pointer triggers cross-TU
// CHA in the parser to enumerate every subclass.
struct IEntryCallback {
    virtual ~IEntryCallback() {}
    virtual void helperFromB(TestWorkArea* wa, int resultCode) = 0;
};

struct ConcreteEntryCallback : public IEntryCallback {
    void helperFromB(TestWorkArea* wa, int resultCode) override {
        // Delegate to the free function defined in tx_a_entry.cpp.
        // This produces the visible C++→C++ edge tx_d_shared → tx_a_entry.
        ::helperFromB(wa, resultCode);
    }
};

// Instance used for the polymorphic call below.
static ConcreteEntryCallback concreteCallback;

// ─────────────────────────────────────────────────────────────────────────────
//  sharedEntry — the function every other module reaches through some pattern.
// ─────────────────────────────────────────────────────────────────────────────
void sharedEntry(TestWorkArea* wa)
{
    if (!wa) return;

    // [Header] Inline header function call.  Resolves to cctestshared.hpp via
    // *.hpp.json blueprint loading → internal edge to cctestshared.
    int sum = computeChecksum(wa->code, 4);
    wa->errorCode = sum;

    // [Fix 4] Polymorphic call through a base-class pointer.  CHA expands the
    // call to both IEntryCallback::helperFromB and
    // ConcreteEntryCallback::helperFromB.  Both strip to "helperfromb" and
    // resolve to tx_a_entry.cpp.
    IEntryCallback* cb = &concreteCallback;
    cb->helperFromB(wa, 0);
}
