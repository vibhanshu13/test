#!/usr/bin/env python3
"""
utility_llm_classifier.py — LLM layer for hybrid utility detection.

Extends utility_detector.py with semantic classification of the AMBIGUOUS zone
(files scoring 0.25–0.75 where deterministic signals cannot resolve the classification).

Two modes:
  global           — Classify all ambiguous files once; cache permanently.
  functionality    — Context-aware re-classification for files on a specific
                     call path, guided by a plain-English functionality description.

Architecture:
  1. EvidencePacketBuilder  → compact ~300-token summary per file (no raw code)
  2. AnthropicLLMClient     → batched API calls (20 files / call)
  3. FusionEngine           → blend det_score + LLM result with hard bounds
  4. ConsistencyChecker     → flag graph-inconsistent results for review

Usage:
    # One-time global classification of ambiguous files
    python3 utility_llm_classifier.py llm-classify \\
        --db utility_index.db --src temp/asm

    # Functionality-specific classification (called by filter --llm-context)
    python3 utility_llm_classifier.py llm-classify \\
        --db utility_index.db --src temp/asm \\
        --functionality "Global credit limit maintenance for GNA/HUB" \\
        --path-stems da78,xh80,xh85,xh93

    # Show audit trail for a file
    python3 utility_llm_classifier.py explain --stem da7gl --db utility_index.db

    # Human override
    python3 utility_llm_classifier.py override \\
        --stem da7gl --label UTILITY \\
        --reason "Confirmed pure DSECT" --db utility_index.db

    # Review inconsistency queue
    python3 utility_llm_classifier.py review-queue --db utility_index.db
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sqlite3
import sys
import textwrap
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

AMBIGUOUS_LOW  = 0.25   # below this: HARD_CRITICAL — no LLM needed
AMBIGUOUS_HIGH = 0.75   # above this: HARD_UTILITY  — no LLM needed

HARD_CRITICAL_SCORE_CEIL = 0.35   # LLM cannot raise hard-critical above FUNCTIONAL
HARD_UTILITY_SCORE_FLOOR = 0.60   # LLM cannot lower hard-utility below SHARED_INFRA

MIN_LLM_CONFIDENCE = 0.50         # below this: discard LLM result
DEFAULT_BATCH_SIZE = 20
DEFAULT_MODEL        = "claude-sonnet-4-5"
GEMINI_DEFAULT_MODEL = "gemini-2.5-flash"   # Gemini Flash 3 (stable)

LABEL_TO_SCORE = {"UTILITY": 1.0, "BRIDGE": 0.50, "CRITICAL": 0.0}

# ---------------------------------------------------------------------------
# Schema migration (adds LLM tables to existing utility_detector.py DB)
# ---------------------------------------------------------------------------

_MIGRATION_DDL = """
ALTER TABLE files ADD COLUMN fused_score  REAL DEFAULT -1.0;
ALTER TABLE files ADD COLUMN score_source TEXT DEFAULT 'deterministic';

CREATE TABLE IF NOT EXISTS llm_decisions (
    file_id          INTEGER NOT NULL REFERENCES files(id),
    content_hash     TEXT    NOT NULL,
    label            TEXT    NOT NULL,
    confidence       REAL    NOT NULL DEFAULT 0.0,
    reason           TEXT,
    fused_score      REAL    NOT NULL,
    score_source     TEXT    NOT NULL,
    mode             TEXT    NOT NULL DEFAULT 'global',
    functionality_id TEXT    NOT NULL DEFAULT '',
    model_id         TEXT,
    classified_at    TEXT,
    PRIMARY KEY (file_id, mode, functionality_id)
);

CREATE TABLE IF NOT EXISTS review_queue (
    file_id        INTEGER NOT NULL REFERENCES files(id),
    reason         TEXT    NOT NULL,
    det_score      REAL,
    llm_label      TEXT,
    llm_confidence REAL,
    queued_at      TEXT,
    resolved       INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS human_overrides (
    file_id  INTEGER NOT NULL REFERENCES files(id) UNIQUE,
    label    TEXT    NOT NULL,
    reason   TEXT,
    set_by   TEXT,
    set_at   TEXT
);
"""


def migrate_db(db_path: str) -> None:
    """Apply schema migration; ignore errors for already-existing columns/tables."""
    con = sqlite3.connect(db_path)
    for stmt in _MIGRATION_DDL.strip().split(";"):
        stmt = stmt.strip()
        if not stmt:
            continue
        try:
            con.execute(stmt)
        except sqlite3.OperationalError as e:
            if "duplicate column" in str(e).lower() or "already exists" in str(e).lower():
                pass  # idempotent
            else:
                raise
    con.commit()
    con.close()


# ---------------------------------------------------------------------------
# Content hashing
# ---------------------------------------------------------------------------

def _content_hash(path: Path) -> str:
    try:
        data = path.read_bytes()
        return hashlib.sha256(data).hexdigest()[:16]
    except OSError:
        return "error"


# ---------------------------------------------------------------------------
# Evidence packet builder
# ---------------------------------------------------------------------------

# Patterns that are "structural" — always informative as fingerprint lines
_STRUCT_PATTERNS = re.compile(
    r"^\s*(?:[A-Z#@$][A-Z0-9#@$_]*\s+)?"
    r"(?:DSECT|DS\s|DC\s|MACRO|MEND|BEGIN\s+NAME|struct\s|class\s|union\s|typedef\s|#pragma)",
    re.IGNORECASE,
)
_BUSINESS_OPCODE_RE = re.compile(
    r"^\s+(?:ENTRC|ENTNC|ENTDC|CREEC|AP\s|SP\s|MVC\s|LA\s|BCT\s|CLC\s|TM\s)",
    re.IGNORECASE,
)
_TITLE_RE = re.compile(r"^\*?\s*(?:TITLE|PROGRAM|PURPOSE|DESCRIPTION)\s*[:'\"]\s*(.+)", re.IGNORECASE)
_COMMENT_DESC_RE = re.compile(r"^\*\s{2,}([A-Z][A-Z /'\-]{8,60})$")

ROLE_THRESHOLDS = [
    (0.80, "PURE_UTILITY"),
    (0.60, "SHARED_INFRA"),
    (0.40, "BRIDGE"),
    (0.20, "FUNCTIONAL"),
    (0.00, "CRITICAL"),
]

def _role(score: float) -> str:
    for thr, label in ROLE_THRESHOLDS:
        if score >= thr:
            return label
    return "CRITICAL"


class EvidencePacketBuilder:
    """Builds compact evidence packets from file content + DB metrics."""

    def __init__(self, db_path: str, src_dir: Path):
        self.db_path = db_path
        self.src_dir = src_dir.resolve()
        self.con = sqlite3.connect(db_path)
        self.con.row_factory = sqlite3.Row

    def close(self):
        self.con.close()

    def _load_file_row(self, file_id: int) -> Optional[sqlite3.Row]:
        return self.con.execute(
            "SELECT f.*, m.in_degree, m.out_degree FROM files f "
            "JOIN metrics m ON m.file_id=f.id WHERE f.id=?", (file_id,)
        ).fetchone()

    def _get_caller_callee_info(self, file_id: int) -> Tuple[List[dict], List[dict]]:
        callers = self.con.execute("""
            SELECT f.stem, f.utility_score FROM edges e
            JOIN files f ON f.id = e.src_id
            WHERE e.dst_id = ? LIMIT 6
        """, (file_id,)).fetchall()
        callees = self.con.execute("""
            SELECT f.stem, f.utility_score FROM edges e
            JOIN files f ON f.id = e.dst_id
            WHERE e.src_id = ? LIMIT 6
        """, (file_id,)).fetchall()
        return (
            [{"stem": r["stem"], "role": _role(r["utility_score"] or 0.5)} for r in callers],
            [{"stem": r["stem"], "role": _role(r["utility_score"] or 0.5)} for r in callees],
        )

    def _extract_fingerprint_and_hint(self, path: Path) -> Tuple[List[str], str, List[str]]:
        """Returns (fingerprint_lines, purpose_hint, dominant_patterns)."""
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return [], "", []

        lines = text.splitlines()
        fingerprint: List[str] = []
        purpose_hint = ""
        pattern_counts: Dict[str, int] = {}

        struct_found = 0
        business_found = 0

        for raw in lines:
            stripped = raw.strip()
            if not stripped:
                continue

            # Extract purpose hint from title/description comments
            if not purpose_hint:
                m = _TITLE_RE.match(stripped)
                if not m:
                    m = _COMMENT_DESC_RE.match(stripped)
                if m:
                    purpose_hint = m.group(1).strip()[:80]

            # Skip pure comment lines and formatting directives for fingerprint
            if stripped.startswith("*") or stripped.upper() in ("EJECT", "SPACE", "SPACE 4", "SPACE 3"):
                continue

            # Tokenise to find dominant patterns
            tokens = stripped.split()
            if tokens:
                opcode_idx = 0 if raw[0] == " " else (1 if len(tokens) > 1 else 0)
                opcode = tokens[opcode_idx].upper().rstrip(",").split("(")[0]
                if len(opcode) >= 2:
                    pattern_counts[opcode] = pattern_counts.get(opcode, 0) + 1

            # Select fingerprint lines
            if _STRUCT_PATTERNS.match(raw) and struct_found < 5:
                fingerprint.append(stripped[:100])
                struct_found += 1
            elif _BUSINESS_OPCODE_RE.match(raw) and business_found < 3:
                fingerprint.append(stripped[:100])
                business_found += 1

            if len(fingerprint) >= 10:
                break

        # Top 5 patterns by frequency
        dominant = sorted(pattern_counts, key=lambda k: -pattern_counts[k])[:5]
        return fingerprint, purpose_hint, dominant

    def build(self, file_id: int) -> Optional[dict]:
        """Build evidence packet for one file. Returns None if file not found."""
        row = self._load_file_row(file_id)
        if row is None:
            return None

        det_score = row["utility_score"] if row["utility_score"] >= 0 else 0.5
        path = self.src_dir / row["path"]
        content_hash = _content_hash(path)

        fingerprint, purpose_hint, dominant = self._extract_fingerprint_and_hint(path)
        callers, callees = self._get_caller_callee_info(file_id)

        # Explain why the file is ambiguous
        signals = {
            "ext_score":     None,
            "content_score": None,
            "fan_in_score":  row["fan_in_score"] if "fan_in_score" in row.keys() else 0.0,
            "entry_score":   0.0 if row["has_begin_name"] else 0.75,
        }
        conflict_parts = []
        if row["ext"] in (".mac", ".hpp", ".h") and det_score < 0.65:
            conflict_parts.append(f"extension type ({row['ext']}) suggests utility but score is low")
        if row["in_degree"] > 3 and det_score < 0.50:
            conflict_parts.append(f"in_degree={row['in_degree']} (shared) but low utility score")
        if row["dsect_ratio"] > 0.3 and row["instruction_ratio"] > 0.3:
            conflict_parts.append("mixed: high data-definition ratio AND high instruction ratio")
        if not conflict_parts:
            conflict_parts.append(f"deterministic score {det_score:.2f} falls in ambiguous zone")

        return {
            "stem":               row["stem"],
            "ext":                row["ext"],
            "loc":                row["loc"],
            "content_hash":       content_hash,
            "deterministic_score": round(det_score, 3),
            "zone":               "AMBIGUOUS",
            "conflict_reason":    "; ".join(conflict_parts),
            "purpose_hint":       purpose_hint or "(none extracted)",
            "code_fingerprint":   fingerprint,
            "dominant_patterns":  dominant,
            "signal_breakdown": {
                "dsect_ratio":      round(row["dsect_ratio"],     3),
                "macro_def_ratio":  round(row["macro_def_ratio"], 3),
                "instruction_ratio":round(row["instruction_ratio"],3),
                "in_degree":        row["in_degree"],
                "out_degree":       row["out_degree"],
                "has_begin_name":   bool(row["has_begin_name"]),
                "entry_point_count":row["entry_point_count"],
            },
            "graph_context": {
                "callers": callers,
                "callees": callees,
            },
        }

    def build_batch(self, file_ids: List[int], batch_size: int = DEFAULT_BATCH_SIZE) -> List[List[dict]]:
        """Build and batch evidence packets. Uses graph-neighbourhood grouping."""
        packets = {}
        for fid in file_ids:
            p = self.build(fid)
            if p:
                packets[p["stem"]] = (fid, p)

        # Graph-neighbourhood grouping: pull caller/callee stems into same batch
        batches: List[List[dict]] = []
        assigned: set = set()

        for stem, (fid, pkt) in packets.items():
            if stem in assigned:
                continue
            batch = [pkt]
            assigned.add(stem)

            # Try to include graph neighbours in the same batch
            neighbours = (
                [c["stem"] for c in pkt["graph_context"]["callers"]] +
                [c["stem"] for c in pkt["graph_context"]["callees"]]
            )
            for nstem in neighbours:
                if nstem in packets and nstem not in assigned and len(batch) < batch_size:
                    batch.append(packets[nstem][1])
                    assigned.add(nstem)

            batches.append(batch)

        # Re-batch: merge small batches up to batch_size
        merged: List[List[dict]] = []
        current: List[dict] = []
        for batch in batches:
            if len(current) + len(batch) <= batch_size:
                current.extend(batch)
            else:
                if current:
                    merged.append(current)
                current = list(batch)
        if current:
            merged.append(current)

        return merged


# ---------------------------------------------------------------------------
# Shared LLM response parsing utilities (used by all backends)
# ---------------------------------------------------------------------------

def _parse_llm_response(text: str, expected_stems: List[str]) -> List[dict]:
    """Three-tier fallback parser for LLM JSON response."""
    # Tier 1: strict JSON parse
    try:
        data = json.loads(text)
        if isinstance(data, list):
            return _validate_llm_entries(data)
    except json.JSONDecodeError:
        pass

    # Tier 2: extract JSON array from mixed text
    m = re.search(r'\[\s*\{.*?\}\s*\]', text, re.DOTALL)
    if m:
        try:
            data = json.loads(m.group(0))
            if isinstance(data, list):
                return _validate_llm_entries(data)
        except json.JSONDecodeError:
            pass

    # Tier 3: field-by-field regex extraction
    results = []
    for stem_m in re.finditer(r'"stem"\s*:\s*"([^"]+)"', text):
        stem = stem_m.group(1)
        if stem not in expected_stems:
            continue
        label_m = re.search(
            rf'"stem"\s*:\s*"{re.escape(stem)}".*?"label"\s*:\s*"(UTILITY|CRITICAL|BRIDGE)"',
            text, re.DOTALL
        )
        if label_m:
            results.append({
                "stem": stem,
                "label": label_m.group(1),
                "confidence": 0.5,
                "reason": "extracted via fallback parser",
            })
    return results


def _validate_llm_entries(entries: List) -> List[dict]:
    valid = []
    for e in entries:
        if not isinstance(e, dict):
            continue
        stem = e.get("stem", "")
        label = e.get("label", "").upper()
        if label not in ("UTILITY", "CRITICAL", "BRIDGE"):
            label = "BRIDGE"
        conf = float(e.get("confidence", 0.5))
        reason = str(e.get("reason", ""))[:200]
        valid.append({"stem": stem, "label": label, "confidence": conf, "reason": reason})
    return valid


# ---------------------------------------------------------------------------
# LLM client (Anthropic)
# ---------------------------------------------------------------------------

_GLOBAL_PROMPT_TEMPLATE = """\
You are an expert in IBM HLASM / TPF (Transaction Processing Facility) mainframe \
codebases used in financial transaction processing systems.

TASK: Classify each file below as UTILITY or CRITICAL.

Definitions:
  UTILITY  = Shared data structure, macro template, DSECT layout, register save area,
             common workarea definition, platform helper. These files provide structure
             consumed by many modules but contain no unique business logic of their own.
  CRITICAL = Standalone business transaction program, unique processing module, or
             subroutine containing logic specific to one feature. Must be understood
             to understand the system's behaviour.

Each entry is a compact evidence packet (NOT the full file). It includes:
  - deterministic signals explaining why the file fell in the ambiguous zone
  - code_fingerprint: the most informative lines from the file
  - dominant_patterns: most frequent opcode/keyword patterns
  - graph_context: what calls this file and what it calls, with their roles

Evidence packets:
{EVIDENCE_PACKETS}

Respond with ONLY a valid JSON array. No prose, no markdown, no explanation outside JSON.
Each element must have exactly these keys:
  "stem"       : file stem (copy from evidence packet)
  "label"      : "UTILITY" or "CRITICAL" (use "BRIDGE" only if genuinely ambiguous)
  "confidence" : float 0.0-1.0 (your certainty)
  "reason"     : one concise sentence

Example:
[
  {{"stem": "da7gl",  "label": "UTILITY",  "confidence": 0.92, "reason": "Pure DSECT workarea; no executable logic."}},
  {{"stem": "xh93",   "label": "UTILITY",  "confidence": 0.71, "reason": "Shared leaf subroutine for error handling called by multiple programs."}}
]"""

_FUNCTIONALITY_PROMPT_TEMPLATE = """\
You are an expert in IBM HLASM / TPF mainframe codebases.

A developer is analysing the following functionality:
  "{FUNCTIONALITY}"

Entry point: {ENTRY_STEM}
{ENTRY_DESC}

The following files are on the call path from that entry point and were classified \
as ambiguous (BRIDGE) by the deterministic analyser. Determine which are:
  CRITICAL = contain logic SPECIFIC to "{FUNCTIONALITY}"; would need to be changed
             or deeply understood if this functionality were modified.
  UTILITY  = generic infrastructure on this path but not specific to this feature;
             identical logic would appear for any other functionality that uses it.

Files on path:
{EVIDENCE_PACKETS}

Call path context:
{PATH_SUMMARY}

Respond with ONLY a valid JSON array (no prose):
[{{"stem":"...","label":"CRITICAL"|"UTILITY"|"BRIDGE","confidence":0.0-1.0,"reason":"..."}}]"""


class AnthropicLLMClient:
    """Anthropic API client for batch classification."""

    def __init__(self, model: str = DEFAULT_MODEL, max_retries: int = 3):
        self.model = model
        self.max_retries = max_retries
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                import anthropic
                self._client = anthropic.Anthropic()
            except ImportError:
                print("ERROR: anthropic package not installed. Run: pip install anthropic", file=sys.stderr)
                sys.exit(1)
        return self._client

    def classify_batch(
        self,
        packets: List[dict],
        mode: str = "global",
        functionality: Optional[str] = None,
        entry_stem: Optional[str] = None,
        path_summary: Optional[str] = None,
    ) -> List[dict]:
        """Send one API call; return list of {stem, label, confidence, reason}."""
        packets_json = json.dumps(packets, indent=2)

        if mode == "functionality" and functionality:
            entry_desc = f"Purpose: {path_summary}" if path_summary else ""
            prompt = _FUNCTIONALITY_PROMPT_TEMPLATE.format(
                FUNCTIONALITY=functionality,
                ENTRY_STEM=entry_stem or "unknown",
                ENTRY_DESC=entry_desc,
                EVIDENCE_PACKETS=packets_json,
                PATH_SUMMARY=path_summary or "",
            )
        else:
            prompt = _GLOBAL_PROMPT_TEMPLATE.format(EVIDENCE_PACKETS=packets_json)

        client = self._get_client()
        for attempt in range(self.max_retries):
            try:
                response = client.messages.create(
                    model=self.model,
                    max_tokens=2048,
                    messages=[{"role": "user", "content": prompt}],
                )
                raw = response.content[0].text
                return self._parse_response(raw, [p["stem"] for p in packets])
            except Exception as e:
                if attempt < self.max_retries - 1:
                    wait = 2 ** attempt
                    print(f"  LLM error (attempt {attempt+1}): {e}. Retrying in {wait}s…")
                    time.sleep(wait)
                else:
                    print(f"  LLM failed after {self.max_retries} attempts: {e}")
                    return []

    def _parse_response(self, text: str, expected_stems: List[str]) -> List[dict]:
        return _parse_llm_response(text, expected_stems)

    def _validate_entries(self, entries: List) -> List[dict]:
        return _validate_llm_entries(entries)


# ---------------------------------------------------------------------------
# LLM client (Google Gemini)
# ---------------------------------------------------------------------------

class GeminiLLMClient:
    """Google Gemini API client for batch classification."""

    def __init__(self, model: str = GEMINI_DEFAULT_MODEL, api_key: str = "", max_retries: int = 3):
        self.model = model
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY", "")
        self.max_retries = max_retries
        self._model_obj = None

    def _get_client(self):
        if self._model_obj is None:
            try:
                from google import genai as _genai
                if not self.api_key:
                    print("ERROR: No Gemini API key. Set GEMINI_API_KEY env var or pass --api-key.",
                          file=sys.stderr)
                    sys.exit(1)
                self._model_obj = _genai.Client(api_key=self.api_key)
            except ImportError:
                print("ERROR: google-genai not installed. "
                      "Run: pip install google-genai", file=sys.stderr)
                sys.exit(1)
        return self._model_obj

    def classify_batch(
        self,
        packets: List[dict],
        mode: str = "global",
        functionality: Optional[str] = None,
        entry_stem: Optional[str] = None,
        path_summary: Optional[str] = None,
    ) -> List[dict]:
        """Send one API call; return list of {stem, label, confidence, reason}."""
        packets_json = json.dumps(packets, indent=2)

        if mode == "functionality" and functionality:
            entry_desc = f"Purpose: {path_summary}" if path_summary else ""
            prompt = _FUNCTIONALITY_PROMPT_TEMPLATE.format(
                FUNCTIONALITY=functionality,
                ENTRY_STEM=entry_stem or "unknown",
                ENTRY_DESC=entry_desc,
                EVIDENCE_PACKETS=packets_json,
                PATH_SUMMARY=path_summary or "",
            )
        else:
            prompt = _GLOBAL_PROMPT_TEMPLATE.format(EVIDENCE_PACKETS=packets_json)

        client = self._get_client()
        for attempt in range(self.max_retries):
            try:
                response = client.models.generate_content(
                    model=self.model, contents=prompt
                )
                raw = response.text
                return _parse_llm_response(raw, [p["stem"] for p in packets])
            except Exception as e:
                if attempt < self.max_retries - 1:
                    wait = 2 ** attempt
                    print(f"  LLM error (attempt {attempt+1}): {e}. Retrying in {wait}s…")
                    time.sleep(wait)
                else:
                    print(f"  LLM failed after {self.max_retries} attempts: {e}")
                    return []


# ---------------------------------------------------------------------------
# Score fusion engine
# ---------------------------------------------------------------------------

class FusionEngine:
    """Blends deterministic score with LLM classification using hard bounds."""

    @staticmethod
    def fuse(det_score: float, llm_label: str, llm_confidence: float) -> Tuple[float, str]:
        """Returns (fused_score, score_source)."""
        if llm_confidence < MIN_LLM_CONFIDENCE:
            return det_score, "llm_low"

        llm_score = LABEL_TO_SCORE.get(llm_label, 0.5)

        # Zone factor: how much weight the LLM gets
        if 0.35 <= det_score <= 0.65:
            zone_factor = 1.0      # deepest ambiguous — LLM has full weight
        else:
            zone_factor = 0.60     # near boundary — partial LLM weight

        weight_llm = llm_confidence * zone_factor
        weight_det = 1.0 - weight_llm

        fused = det_score * weight_det + llm_score * weight_llm

        # Hard bounds: preserve deterministic certainty at extremes
        if det_score > AMBIGUOUS_HIGH:
            fused = max(fused, HARD_UTILITY_SCORE_FLOOR)
        if det_score < AMBIGUOUS_LOW:
            fused = min(fused, HARD_CRITICAL_SCORE_CEIL)

        fused = round(min(1.0, max(0.0, fused)), 4)

        if llm_confidence >= 0.75:
            source = "llm_high"
        elif llm_confidence >= MIN_LLM_CONFIDENCE:
            source = "llm_blend"
        else:
            source = "llm_low"

        return fused, source


# ---------------------------------------------------------------------------
# Consistency checker
# ---------------------------------------------------------------------------

class ConsistencyChecker:
    """Flags LLM results that are inconsistent with graph neighbourhood."""

    def __init__(self, db_path: str):
        self.con = sqlite3.connect(db_path)
        self.con.row_factory = sqlite3.Row

    def close(self):
        self.con.close()

    def check(self, fid: int, llm_label: str, llm_confidence: float) -> Optional[str]:
        """Return reason string if inconsistent; None if OK."""
        # If LLM says UTILITY, but all callers are CRITICAL — suspicious
        callers = self.con.execute("""
            SELECT f.fused_score, f.utility_score
            FROM edges e JOIN files f ON f.id=e.src_id
            WHERE e.dst_id=? LIMIT 10
        """, (fid,)).fetchall()

        if callers and llm_label == "UTILITY":
            caller_scores = [
                r["fused_score"] if (r["fused_score"] or -1) >= 0 else r["utility_score"]
                for r in callers
            ]
            avg_caller_score = sum(caller_scores) / len(caller_scores)
            if avg_caller_score < 0.30:
                return (f"LLM says UTILITY but avg caller utility_score={avg_caller_score:.2f} "
                        f"(all callers are critical); may be wrong")

        # If LLM says CRITICAL, but in_degree > 5 and all callers are utility — suspicious
        if llm_label == "CRITICAL":
            row = self.con.execute(
                "SELECT m.in_degree FROM metrics m WHERE m.file_id=?", (fid,)
            ).fetchone()
            if row and row["in_degree"] > 5 and callers:
                caller_scores = [
                    r["fused_score"] if (r["fused_score"] or -1) >= 0 else r["utility_score"]
                    for r in callers
                ]
                avg_caller_score = sum(caller_scores) / len(caller_scores)
                if avg_caller_score > 0.60:
                    return (f"LLM says CRITICAL but in_degree={row['in_degree']} and "
                            f"avg caller score={avg_caller_score:.2f}; may be shared infrastructure")
        return None


# ---------------------------------------------------------------------------
# Main classifier orchestrator
# ---------------------------------------------------------------------------

class LLMClassifier:
    """Orchestrates evidence building, LLM calls, fusion, and DB writes."""

    def __init__(
        self,
        db_path: str,
        src_dir: Path,
        model: str = DEFAULT_MODEL,
        batch_size: int = DEFAULT_BATCH_SIZE,
        dry_run: bool = False,
        consensus: bool = False,
        backend: str = "anthropic",
        api_key: str = "",
    ):
        self.db_path = db_path
        self.src_dir = src_dir.resolve()
        self.batch_size = batch_size
        self.dry_run = dry_run
        self.consensus = consensus

        # Select LLM backend and resolve model name
        if backend == "gemini":
            self.model = model if model != DEFAULT_MODEL else GEMINI_DEFAULT_MODEL
            self.llm_client: object = GeminiLLMClient(model=self.model, api_key=api_key)
        else:
            self.model = model
            self.llm_client = AnthropicLLMClient(model=model)

        self.con = sqlite3.connect(db_path)
        self.con.row_factory = sqlite3.Row
        self.packet_builder = EvidencePacketBuilder(db_path, src_dir)
        self.fusion = FusionEngine()
        self.consistency = ConsistencyChecker(db_path)

    def close(self):
        self.con.close()
        self.packet_builder.close()
        self.consistency.close()

    # ------------------------------------------------------------------
    # Ambiguous file discovery
    # ------------------------------------------------------------------

    def _get_ambiguous_ids(
        self,
        path_stems: Optional[List[str]] = None,
    ) -> List[int]:
        """Return file IDs in ambiguous zone, optionally filtered to path_stems."""
        if path_stems:
            ph = ",".join("?" * len(path_stems))
            rows = self.con.execute(
                f"SELECT id, fused_score, utility_score FROM files "
                f"WHERE stem IN ({ph})",
                path_stems,
            ).fetchall()
        else:
            rows = self.con.execute(
                "SELECT id, fused_score, utility_score FROM files "
                "WHERE utility_score >= ? AND utility_score <= ?",
                (AMBIGUOUS_LOW, AMBIGUOUS_HIGH),
            ).fetchall()

        # Skip files already cached with valid LLM decision
        result = []
        for r in rows:
            fid = r["id"]
            file_path = self.src_dir / self.con.execute(
                "SELECT path FROM files WHERE id=?", (fid,)
            ).fetchone()["path"]
            current_hash = _content_hash(file_path)

            cached = self.con.execute(
                "SELECT content_hash FROM llm_decisions WHERE file_id=? AND mode='global'", (fid,)
            ).fetchone()

            if cached and cached["content_hash"] == current_hash:
                continue  # valid cache hit — skip
            result.append(fid)
        return result

    # ------------------------------------------------------------------
    # Global classification
    # ------------------------------------------------------------------

    def classify_global(self) -> None:
        print("  Discovering ambiguous files …", flush=True)
        file_ids = self._get_ambiguous_ids()
        print(f"  Found {len(file_ids)} files to classify ({DEFAULT_BATCH_SIZE} per LLM call)")

        if not file_ids:
            print("  All ambiguous files already cached. Nothing to do.")
            return

        if self.dry_run:
            print(f"  [dry-run] Would send {len(file_ids)} files in "
                  f"{len(file_ids) // self.batch_size + 1} LLM batches.")
            return

        batches = self.packet_builder.build_batch(file_ids, self.batch_size)
        print(f"  Built {len(batches)} batches")

        total_classified = 0
        total_flagged = 0

        for i, batch in enumerate(batches, 1):
            if i % 10 == 0 or i == 1:
                print(f"  Batch {i}/{len(batches)} ({total_classified} classified so far) …",
                      flush=True)

            results = self.llm_client.classify_batch(batch, mode="global")
            if not results:
                continue

            # Optional: dual-prompt consensus for boundary files
            if self.consensus:
                boundary = [
                    p for p in batch
                    if any(r["stem"] == p["stem"] and
                           abs(r.get("fused_score", p["deterministic_score"]) - 0.5) < 0.05
                           for r in results)
                ]
                if boundary:
                    results2 = self.llm_client.classify_batch(boundary, mode="global")
                    results = self._merge_consensus(results, results2)

            self._write_global_results(batch, results)
            total_classified += len(results)

        self._write_deterministic_scores_for_hard_zone()
        print(f"  Classified {total_classified} files; {total_flagged} flagged for review")

    def _merge_consensus(self, r1: List[dict], r2: List[dict]) -> List[dict]:
        """Keep result only when both prompts agree; flag disagreements."""
        r2_by_stem = {r["stem"]: r for r in r2}
        merged = []
        for entry in r1:
            stem = entry["stem"]
            if stem in r2_by_stem:
                other = r2_by_stem[stem]
                if entry["label"] == other["label"]:
                    # Agree: use average confidence
                    entry["confidence"] = (entry["confidence"] + other["confidence"]) / 2
                    merged.append(entry)
                else:
                    # Disagree: lower confidence, keep first
                    entry["confidence"] = min(entry["confidence"], 0.49)  # will be discarded by gate
                    merged.append(entry)
            else:
                merged.append(entry)
        return merged

    def _write_global_results(self, batch: List[dict], results: List[dict]) -> None:
        results_by_stem = {r["stem"]: r for r in results}
        ts = datetime.now(timezone.utc).isoformat()

        for pkt in batch:
            stem = pkt["stem"]
            det_score = pkt["deterministic_score"]
            content_hash = pkt["content_hash"]

            row = self.con.execute("SELECT id FROM files WHERE stem=?", (stem,)).fetchone()
            if not row:
                continue
            fid = row["id"]

            if stem in results_by_stem:
                r = results_by_stem[stem]
                fused, source = self.fusion.fuse(det_score, r["label"], r["confidence"])
                reason = r.get("reason", "")
                label = r["label"]
                confidence = r["confidence"]

                # Consistency check
                issue = self.consistency.check(fid, label, confidence)
                if issue:
                    self.con.execute("""
                        INSERT OR REPLACE INTO review_queue
                        (file_id, reason, det_score, llm_label, llm_confidence, queued_at, resolved)
                        VALUES (?,?,?,?,?,?,0)
                    """, (fid, issue, det_score, label, confidence, ts))
                    # Still apply the classification, but note the flag
            else:
                # LLM did not return a result for this file — keep deterministic
                fused = det_score
                source = "deterministic"
                label = ""
                confidence = 0.0
                reason = "LLM did not return result; using deterministic score"

            self.con.execute("""
                INSERT OR REPLACE INTO llm_decisions
                (file_id, content_hash, label, confidence, reason, fused_score,
                 score_source, mode, functionality_id, model_id, classified_at)
                VALUES (?,?,?,?,?,?,?,'global','',?,?)
            """, (fid, content_hash, label, confidence, reason, fused, source, self.model, ts))

            self.con.execute(
                "UPDATE files SET fused_score=?, score_source=? WHERE id=?",
                (fused, source, fid)
            )

        self.con.commit()

    def _write_deterministic_scores_for_hard_zone(self) -> None:
        """Ensure hard-utility and hard-critical files have fused_score = utility_score."""
        self.con.execute("""
            UPDATE files
            SET fused_score=utility_score, score_source='deterministic'
            WHERE (utility_score > ? OR utility_score < ?)
            AND (fused_score IS NULL OR fused_score < 0)
        """, (AMBIGUOUS_HIGH, AMBIGUOUS_LOW))
        self.con.commit()

    # ------------------------------------------------------------------
    # Functionality-context classification
    # ------------------------------------------------------------------

    def classify_functionality(
        self,
        path_stems: List[str],
        functionality: str,
        entry_stem: str,
    ) -> Dict[str, dict]:
        """Classify path files with functionality context. Returns {stem: result}."""
        # Only send BRIDGE/FUNCTIONAL files — hard zones are already resolved
        bridge_ids = []
        all_rows = {}
        for stem in path_stems:
            r = self.con.execute(
                "SELECT id, utility_score, fused_score FROM files WHERE stem=?", (stem,)
            ).fetchone()
            if r:
                score = r["fused_score"] if (r["fused_score"] or -1) >= 0 else r["utility_score"]
                all_rows[stem] = score
                if AMBIGUOUS_LOW <= (score or 0.5) <= AMBIGUOUS_HIGH:
                    bridge_ids.append(r["id"])

        if not bridge_ids or self.dry_run:
            if self.dry_run:
                print(f"  [dry-run] Would classify {len(bridge_ids)} BRIDGE files with context")
            return {}

        packets = [p for fid in bridge_ids if (p := self.packet_builder.build(fid)) is not None]
        if not packets:
            return {}

        path_summary = (
            f"Call path: {' → '.join(path_stems[:8])}"
            + (" → …" if len(path_stems) > 8 else "")
        )

        results = self.llm_client.classify_batch(
            packets,
            mode="functionality",
            functionality=functionality,
            entry_stem=entry_stem,
            path_summary=path_summary,
        )

        func_id = hashlib.sha256(functionality.encode()).hexdigest()[:12]
        ts = datetime.now(timezone.utc).isoformat()
        out: Dict[str, dict] = {}

        for pkt in packets:
            stem = pkt["stem"]
            det_score = pkt["deterministic_score"]
            content_hash = pkt["content_hash"]
            row = self.con.execute("SELECT id FROM files WHERE stem=?", (stem,)).fetchone()
            if not row:
                continue
            fid = row["id"]

            match = next((r for r in results if r["stem"] == stem), None)
            if match and match["confidence"] >= MIN_LLM_CONFIDENCE:
                fused, source = self.fusion.fuse(det_score, match["label"], match["confidence"])
                out[stem] = {
                    "label": match["label"],
                    "confidence": match["confidence"],
                    "reason": match.get("reason", ""),
                    "fused_score": fused,
                }
                self.con.execute("""
                    INSERT OR REPLACE INTO llm_decisions
                    (file_id, content_hash, label, confidence, reason, fused_score,
                     score_source, mode, functionality_id, model_id, classified_at)
                    VALUES (?,?,?,?,?,?,?,'functionality',?,?,?)
                """, (fid, content_hash, match["label"], match["confidence"],
                      match.get("reason", ""), fused, source, func_id, self.model, ts))

        self.con.commit()
        return out


# ---------------------------------------------------------------------------
# Audit / explain command
# ---------------------------------------------------------------------------

def explain_file(db_path: str, stem: str) -> None:
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row

    row = con.execute(
        "SELECT f.*, m.in_degree, m.out_degree FROM files f "
        "JOIN metrics m ON m.file_id=f.id WHERE f.stem=?", (stem,)
    ).fetchone()

    if not row:
        print(f"File '{stem}' not found in index.")
        con.close()
        return

    print(f"\n{'='*60}")
    print(f"  File: {row['stem']}{row['ext']}")
    print(f"  Path: {row['path']}")
    print(f"{'='*60}")
    print(f"\n  Deterministic score : {row['utility_score']:.4f}")
    print(f"  Fused score         : {row['fused_score']:.4f}" if row['fused_score'] >= 0 else "  Fused score         : not yet computed")
    print(f"  Score source        : {row['score_source']}")
    print(f"\n  Content signals:")
    print(f"    dsect_ratio         = {row['dsect_ratio']:.3f}")
    print(f"    macro_def_ratio     = {row['macro_def_ratio']:.3f}")
    print(f"    instruction_ratio   = {row['instruction_ratio']:.3f}")
    print(f"    has_begin_name      = {bool(row['has_begin_name'])}")
    print(f"    entry_point_count   = {row['entry_point_count']}")
    print(f"\n  Graph:")
    print(f"    in_degree  = {row['in_degree']}")
    print(f"    out_degree = {row['out_degree']}")

    # LLM decisions
    decisions = con.execute(
        "SELECT * FROM llm_decisions WHERE file_id=? ORDER BY classified_at DESC", (row["id"],)
    ).fetchall()
    if decisions:
        print(f"\n  LLM decisions ({len(decisions)}):")
        for d in decisions:
            print(f"    [{d['mode']:15}] label={d['label']:8}  conf={d['confidence']:.2f}  "
                  f"fused={d['fused_score']:.3f}  model={d['model_id']}")
            print(f"                     reason: {d['reason']}")
    else:
        print("\n  No LLM decisions recorded.")

    # Human override
    override = con.execute(
        "SELECT * FROM human_overrides WHERE file_id=?", (row["id"],)
    ).fetchone()
    if override:
        print(f"\n  HUMAN OVERRIDE: label={override['label']}")
        print(f"    reason : {override['reason']}")
        print(f"    set_by : {override['set_by']}  at {override['set_at']}")

    # Review queue
    flags = con.execute(
        "SELECT * FROM review_queue WHERE file_id=? AND resolved=0", (row["id"],)
    ).fetchall()
    if flags:
        print(f"\n  FLAGGED FOR REVIEW:")
        for f in flags:
            print(f"    {f['reason']}")

    con.close()


# ---------------------------------------------------------------------------
# Override command
# ---------------------------------------------------------------------------

def apply_override(db_path: str, stem: str, label: str, reason: str, set_by: str = "engineer") -> None:
    con = sqlite3.connect(db_path)
    row = con.execute("SELECT id, utility_score FROM files WHERE stem=?", (stem,)).fetchone()
    if not row:
        print(f"File '{stem}' not found.")
        con.close()
        return

    ts = datetime.now(timezone.utc).isoformat()
    fid = row[0]
    label_upper = label.upper()
    score = LABEL_TO_SCORE.get(label_upper, 0.5)

    con.execute("""
        INSERT OR REPLACE INTO human_overrides (file_id, label, reason, set_by, set_at)
        VALUES (?,?,?,?,?)
    """, (fid, label_upper, reason, set_by, ts))
    con.execute(
        "UPDATE files SET fused_score=?, score_source='human_override' WHERE id=?",
        (score, fid)
    )
    con.commit()
    con.close()
    print(f"Override applied: {stem} → {label_upper} (fused_score={score})")


# ---------------------------------------------------------------------------
# Review queue command
# ---------------------------------------------------------------------------

def show_review_queue(db_path: str) -> None:
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    rows = con.execute("""
        SELECT rq.*, f.stem, f.ext, f.utility_score, f.fused_score
        FROM review_queue rq JOIN files f ON f.id=rq.file_id
        WHERE rq.resolved=0
        ORDER BY rq.queued_at DESC
        LIMIT 50
    """).fetchall()
    con.close()

    if not rows:
        print("Review queue is empty.")
        return

    print(f"\n{'STEM':<22} {'EXT':<6} {'DET':>6} {'LLM_LABEL':<10} {'CONF':>5}  REASON")
    print("-" * 90)
    for r in rows:
        print(f"  {r['stem']:<20} {r['ext']:<6} {r['det_score']:>6.3f} {r['llm_label']:<10} "
              f"{r['llm_confidence']:>5.2f}  {r['reason'][:50]}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="utility_llm_classifier.py",
        description="LLM-based classification layer for utility_detector.py",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # llm-classify
    p = sub.add_parser("llm-classify", help="Classify ambiguous-zone files with LLM")
    p.add_argument("--db",            required=True,  help="SQLite DB from utility_detector.py build")
    p.add_argument("--src",           required=True,  help="Source directory (same as build --src)")
    p.add_argument("--model",         default=DEFAULT_MODEL)
    p.add_argument("--batch-size",    type=int, default=DEFAULT_BATCH_SIZE)
    p.add_argument("--functionality", help="Functionality description for context mode")
    p.add_argument("--path-stems",    help="Comma-separated stems on the call path (for context mode)")
    p.add_argument("--entry-stem",    help="Entry stem for context mode")
    p.add_argument("--dry-run",       action="store_true", help="Show what would be done; no API calls")
    p.add_argument("--consensus",     action="store_true", help="Dual-prompt for boundary files")
    p.add_argument("--llm-backend",   default="anthropic", choices=["anthropic", "gemini"],
                   help="LLM backend (default: anthropic)")
    p.add_argument("--api-key",       default="",
                   help="API key for the backend. For Gemini: overrides GEMINI_API_KEY env var.")

    # explain
    p2 = sub.add_parser("explain", help="Show full classification audit trail for a file")
    p2.add_argument("--stem", required=True)
    p2.add_argument("--db",   required=True)

    # override
    p3 = sub.add_parser("override", help="Manually pin a file's classification")
    p3.add_argument("--stem",   required=True)
    p3.add_argument("--label",  required=True, choices=["UTILITY", "CRITICAL", "BRIDGE"])
    p3.add_argument("--reason", required=True)
    p3.add_argument("--set-by", default="engineer")
    p3.add_argument("--db",     required=True)

    # review-queue
    p4 = sub.add_parser("review-queue", help="Show files flagged for human review")
    p4.add_argument("--db", required=True)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "explain":
        explain_file(args.db, args.stem)
        return

    if args.command == "override":
        migrate_db(args.db)
        apply_override(args.db, args.stem, args.label, args.reason, args.set_by)
        return

    if args.command == "review-queue":
        show_review_queue(args.db)
        return

    if args.command == "llm-classify":
        if not Path(args.db).exists():
            print(f"ERROR: DB not found: {args.db}. Run 'utility_detector.py build' first.")
            sys.exit(1)
        if not Path(args.src).exists():
            print(f"ERROR: Source directory not found: {args.src}")
            sys.exit(1)

        migrate_db(args.db)

        classifier = LLMClassifier(
            db_path=args.db,
            src_dir=Path(args.src),
            model=args.model,
            batch_size=args.batch_size,
            dry_run=args.dry_run,
            consensus=args.consensus,
            backend=args.llm_backend,
            api_key=args.api_key,
        )

        try:
            if args.functionality:
                path_stems = [s.strip() for s in (args.path_stems or "").split(",") if s.strip()]
                print(f"Functionality-context classification for: {args.functionality!r}")
                results = classifier.classify_functionality(
                    path_stems=path_stems,
                    functionality=args.functionality,
                    entry_stem=args.entry_stem or (path_stems[0] if path_stems else ""),
                )
                print(f"\nContext-aware results ({len(results)} files reclassified):")
                print(f"\n{'STEM':<22} {'LABEL':<10} {'CONF':>5}  REASON")
                print("-" * 70)
                for stem, r in results.items():
                    print(f"  {stem:<20} {r['label']:<10} {r['confidence']:>5.2f}  {r['reason'][:45]}")
            else:
                print(f"Global LLM classification → {args.db}")
                classifier.classify_global()
                print("Done.")
        finally:
            classifier.close()


if __name__ == "__main__":
    main()
