#!/usr/bin/env python3
"""Dev CLI: run the variable explainer on output from chunk_cli.py.

Usage (after running chunk_cli.py):

    python explain_cli.py /tmp/lg1osi_test

    # Explain only tuples 0–2:
    python explain_cli.py /tmp/lg1osi_test --max-tuples 3

    # Show the LLM prompt instead of calling the LLM:
    python explain_cli.py /tmp/lg1osi_test --dry-run

Requires: GEMINI_API_KEY env var (unless --dry-run).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def _load_tuple(output_dir: Path, variable: str, idx: int) -> dict | None:
    path = output_dir / f"{variable.upper()}_tuple_{idx}.json"
    if not path.exists():
        return None
    page = json.loads(path.read_text(encoding="utf-8"))
    return page.get("tuple")


def main() -> int:
    p = argparse.ArgumentParser(description="Explain variable tuples from chunk_cli.py output.")
    p.add_argument("output_dir", help="Directory produced by chunk_cli.py (contains *_tuple_*.json)")
    p.add_argument("--max-tuples", type=int, default=None,
                   help="Stop after this many tuples (default: all)")
    p.add_argument("--dry-run", action="store_true",
                   help="Print the LLM prompt only — do not call the API")
    args = p.parse_args()

    output_dir = Path(args.output_dir).resolve()
    if not output_dir.exists():
        print(f"ERROR: output_dir does not exist: {output_dir}", file=sys.stderr)
        return 1

    index_map_path = output_dir / "tuple_index_map.json"
    if not index_map_path.exists():
        print(f"ERROR: no tuple_index_map.json in {output_dir}", file=sys.stderr)
        print("Run chunk_cli.py first to generate the tuples.", file=sys.stderr)
        return 1

    index_map: list[dict] = json.loads(index_map_path.read_text(encoding="utf-8"))
    if not index_map:
        print("ERROR: tuple_index_map.json is empty.", file=sys.stderr)
        return 1

    # Derive variable and chain from first tuple
    first_page_path = output_dir / index_map[0]["file"]
    first_page = json.loads(first_page_path.read_text(encoding="utf-8"))
    variable      = first_page["root_variable"]
    selected_chain: list[str] = first_page.get("selected_chain") or []
    total_tuples  = len(index_map)

    if not args.dry_run:
        api_key = os.environ.get("GEMINI_API_KEY", "").strip()
        if not api_key:
            print("ERROR: GEMINI_API_KEY env var is not set. Use --dry-run to test without LLM.", file=sys.stderr)
            return 1
        # Inject into settings before importing api.config
        os.environ["GEMINI_API_KEY"] = api_key

    from llm.variable_explainer import (
        build_tuple_prompt,
        generate_synthesis,
        _extract_tuple_fact,
        _SYSTEM_PROMPT,
    )

    max_tuples = args.max_tuples if args.max_tuples is not None else total_tuples
    tuple_facts: dict[str, str] = {}
    explanations: dict[str, str] = {}
    session_path = output_dir / "explain_session.json"

    print(f"Variable      : {variable}")
    print(f"Chain         : {' → '.join(selected_chain)}")
    print(f"Total tuples  : {total_tuples}")
    print(f"Explaining     : {min(max_tuples, total_tuples)} tuple(s)")
    print()

    for idx in range(min(max_tuples, total_tuples)):
        entry = index_map[idx]
        tuple_data = _load_tuple(output_dir, variable, idx)
        if tuple_data is None:
            print(f"[{idx}] tuple file missing — stopping.")
            break

        phase     = entry.get("phase", "?")
        file_stem = entry.get("file_stem", "?")
        print(f"{'─'*70}")
        print(f"Tuple {idx}  |  file: {file_stem}  |  phase: {phase}")
        print(f"{'─'*70}")

        prompt = build_tuple_prompt(
            tuple_data=tuple_data,
            root_variable=variable,
            selected_chain=selected_chain,
            tuple_index=idx,
            total_tuples=total_tuples,
            tuple_facts=tuple_facts,
            prior_explanations=explanations,
        )

        if args.dry_run:
            print("--- PROMPT ---")
            print(prompt)
        else:
            from llm.caller import call_llm
            print("Calling LLM…", flush=True)
            explanation = call_llm(prompt, system_prompt=_SYSTEM_PROMPT)
            print(explanation)
            explanations[str(idx)] = explanation

        # Accumulate fact for next iteration
        tuple_facts[str(idx)] = _extract_tuple_fact(tuple_data, variable)

        # Persist session after every tuple so chat_cli.py can use it immediately
        if not args.dry_run:
            session_path.write_text(
                json.dumps({
                    "root_variable":  variable.upper(),
                    "selected_chain": selected_chain,
                    "tuple_facts":    tuple_facts,
                    "explanations":   explanations,
                }, indent=2),
                encoding="utf-8",
            )

        print()

    # Final synthesis pass — one extra LLM call summing up the full lineage
    if not args.dry_run and explanations:
        print(f"{'─'*70}")
        print("Generating final synthesis…")
        print(f"{'─'*70}")
        try:
            synthesis = generate_synthesis(
                root_variable=variable,
                selected_chain=selected_chain,
                explanations=explanations,
                tuple_facts=tuple_facts,
                index_map=index_map,
            )
            print(synthesis)
            session_path.write_text(
                json.dumps({
                    "root_variable":  variable.upper(),
                    "selected_chain": selected_chain,
                    "tuple_facts":    tuple_facts,
                    "explanations":   explanations,
                    "synthesis":      synthesis,
                }, indent=2),
                encoding="utf-8",
            )
        except Exception as e:
            print(f"Synthesis failed: {e}")
        print()

    if not args.dry_run and explanations:
        print(f"Explain session saved → {session_path}")
        print("Run chat_cli.py on this directory to ask follow-up questions.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
