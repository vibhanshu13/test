#!/usr/bin/env python3
"""Build per-file block graphs for a codebase (item #2 of the multi-level graph builder).

For every source file we emit a graph whose nodes are the file's blocks and whose
edges connect blocks within that file:

  * ASM / macro files (.asm, .mac, .s, .cpy, .copy)
        Blocks and subroutines are recovered with the full single-file pipeline
        (multi_file.SingleFileAnalyzer -> BlockExtractorPass). Edges come from each
        block's ``incoming_branches`` (BRANCH / FALLTHROUGH / SUBROUTINE_CALL).

  * C / C++ / header files (.cpp, .cc, .cxx, .c, .hpp, .h)
        The blueprint's function-level ``call_graph`` is the block graph: nodes are
        functions, edges are intra-file calls between them.

Inputs:
  --codebase-dir   directory of raw source files (e.g. temp/asm)
  --output-dir     parser-output root containing the per-file blueprints (e.g. temp/output_latest)

Example:
    python block_graph.py --codebase-dir temp/asm --output-dir temp/output_latest
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Dict, List

from blueprint_io import load_blueprint
from cluster_graph import _ASM_EXTS, _enumerate_source_files, _find_blueprint_dir


def _block_to_node(b: dict, kind: str) -> dict:
    return {
        "id": b.get("id"),
        "kind": kind,
        "start_line": b.get("start_line"),
        "end_line": b.get("end_line"),
    }


def _asm_block_graph(analyzer, codebase_dir: Path, path: Path) -> dict:
    """Run the single-file pipeline and build a block graph from incoming_branches."""
    content = path.read_text(errors="replace")
    result = analyzer.analyze(path, content)
    ba = result.analysis_context.get_metadata("block_analysis")
    nodes: List[dict] = []
    edges: List[dict] = []
    if ba is not None:
        node_ids = set()
        for b in ba.blocks:
            d = b.to_dict()
            nodes.append(_block_to_node(d, "block"))
            node_ids.add(d.get("id"))
        for s in ba.subroutines:
            d = s.to_dict()
            nodes.append(_block_to_node(d, "subroutine"))
            node_ids.add(d.get("id"))
        # Edges: source -> this block, as recorded on each block's incoming_branches.
        for b in list(ba.blocks) + list(ba.subroutines):
            d = b.to_dict()
            target = d.get("id")
            for inc in d.get("incoming_branches") or []:
                edges.append(
                    {"source": inc.get("source"), "target": target, "type": inc.get("type")}
                )
    return {"language": "asm", "nodes": nodes, "edges": edges,
            "node_count": len(nodes), "edge_count": len(edges)}


def _cpp_block_graph(blueprint_dir: Path, fname: str) -> dict:
    """Use the blueprint's function-level call_graph as the block graph."""
    nodes: List[dict] = []
    edges: List[dict] = []
    bp_path = blueprint_dir / f"{fname}.json"
    if bp_path.exists():
        try:
            bp = load_blueprint(bp_path, skip_global_lineage=True, keys={"call_graph"})
            cg = bp.get("call_graph") or {}
            cg_nodes = cg.get("nodes") or {}
            # call_graph.nodes is a {name: {...}} dict for C/C++.
            items = cg_nodes.items() if isinstance(cg_nodes, dict) else ((n.get("name"), n) for n in cg_nodes)
            for name, meta in items:
                nodes.append(
                    {
                        "id": name,
                        "kind": (meta or {}).get("kind", "function"),
                        "section": (meta or {}).get("section"),
                        "is_external": (meta or {}).get("is_external", False),
                    }
                )
            for e in cg.get("edges") or []:
                edges.append(
                    {
                        "source": e.get("source"),
                        "target": e.get("target"),
                        "type": e.get("call_type", "call"),
                        "is_indirect": e.get("is_indirect", False),
                    }
                )
        except Exception as exc:  # noqa: BLE001
            print(f"warning: could not read call_graph for {fname}: {exc}", file=sys.stderr)
    return {"language": "cpp", "nodes": nodes, "edges": edges,
            "node_count": len(nodes), "edge_count": len(edges)}


def build_block_graphs(codebase_dir: Path, output_dir: Path) -> dict:
    blueprint_dir = _find_blueprint_dir(output_dir)
    source_files = _enumerate_source_files(codebase_dir)
    if not source_files:
        raise SystemExit(f"error: no recognised source files found in {codebase_dir}")

    # Lazily create the ASM analyzer only if needed (heavy import + setup).
    analyzer = None
    files: Dict[str, dict] = {}
    for fname in source_files:
        ext = os.path.splitext(fname)[1]
        path = codebase_dir / fname
        if ext in _ASM_EXTS:
            if analyzer is None:
                from multi_file.single_file_analyzer import SingleFileAnalyzer

                analyzer = SingleFileAnalyzer([codebase_dir])
            try:
                files[fname] = _asm_block_graph(analyzer, codebase_dir, path)
            except Exception as exc:  # noqa: BLE001
                print(f"warning: ASM block extraction failed for {fname}: {exc}", file=sys.stderr)
                files[fname] = {"language": "asm", "nodes": [], "edges": [],
                                "node_count": 0, "edge_count": 0, "error": str(exc)}
        else:
            files[fname] = _cpp_block_graph(blueprint_dir, fname)

    total_nodes = sum(f["node_count"] for f in files.values())
    total_edges = sum(f["edge_count"] for f in files.values())
    return {
        "metadata": {
            "generator": "block_graph.py",
            "codebase_dir": str(codebase_dir),
            "blueprint_dir": str(blueprint_dir),
        },
        "files": files,
        "summary": {
            "file_count": len(files),
            "total_blocks": total_nodes,
            "total_edges": total_edges,
        },
    }


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="block_graph.py",
        description="Build per-file block graphs (blocks as nodes, intra-file edges).",
    )
    p.add_argument("--codebase-dir", required=True, metavar="DIR", help="Directory of raw source files")
    p.add_argument("--output-dir", required=True, metavar="DIR", help="Parser-output root with per-file blueprints")
    p.add_argument("--output", metavar="FILE", help="Write JSON to FILE (default: <output-dir>/block_graph.json)")
    return p


def main() -> int:
    args = build_arg_parser().parse_args()
    codebase_dir = Path(args.codebase_dir).resolve()
    output_dir = Path(args.output_dir).resolve()
    for d in (codebase_dir, output_dir):
        if not d.exists():
            print(f"error: directory not found: {d}", file=sys.stderr)
            return 1

    graph = build_block_graphs(codebase_dir, output_dir)
    out_path = Path(args.output) if args.output else output_dir / "block_graph.json"
    out_path.write_text(json.dumps(graph, indent=2), encoding="utf-8")
    s = graph["summary"]
    print(
        f"Wrote block graphs to: {out_path}\n"
        f"  files={s['file_count']} total_blocks={s['total_blocks']} total_edges={s['total_edges']}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
