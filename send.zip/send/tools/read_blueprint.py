import sys
import os
import json
import zstandard as zstd
import msgpack

CHUNK_SIZE = 64 * 1024  # 64 KB read size fed to the Unpacker


def stream_msgpack_zst(path, target_key=None):
    """
    Decompress and extract from a msgpack+zst blueprint file.

    Fix over the original
    ----------------------
    Original: ``msgpack.unpack(reader)`` fully decompresses and deserializes
    the entire blueprint into a Python dict before any key lookup.  A 1 GB
    compressed file (e.g. 5–10 GB decompressed) would OOM the process.

    Fixed: ``msgpack.Unpacker(file_like=zst_reader)`` feeds decompressed bytes
    on demand into the incremental parser.  When *target_key* is provided,
    ``read_map_header()`` + ``skip()`` iterate through key-value pairs and only
    deserialize the matched value — unmatched values are skipped in-place
    without becoming Python objects.

    Peak memory
    -----------
    - With target_key    : O(key strings) + O(matched value)
    - Without target_key : O(decompressed size)  — unavoidable for a full dump
    """
    if not os.path.exists(path):
        return f"Error: File {path} not found."

    try:
        with open(path, 'rb') as f:
            dctx = zstd.ZstdDecompressor()
            with dctx.stream_reader(f) as zst_reader:
                # Pass the decompressed stream directly to the incremental parser.
                # max_buffer_size=0 disables the cap so large individual values
                # (e.g. the 'definitions' dict) are not rejected.
                unpacker = msgpack.Unpacker(
                    file_like=zst_reader,
                    raw=False,
                    max_buffer_size=0,
                    read_size=CHUNK_SIZE,
                )

                if target_key is None:
                    # No key requested: load all data and truncate output so the
                    # LLM context window is not flooded.
                    data = unpacker.unpack()
                    full_json = json.dumps(data, indent=2)
                    if len(full_json) > 50000:
                        return (
                            full_json[:50000]
                            + "\n... [Output truncated. Use a specific key to see more] ..."
                        )
                    return full_json

                # Streaming key lookup via the msgpack map-header API.
                #
                # read_map_header() reads the count of pairs in the top-level
                # map without deserializing any value.  We then iterate:
                #   - unpack() the key  (always a short string — cheap)
                #   - if it matches: unpack() the value and return
                #   - otherwise:     skip() the value (no Python object created)
                n_pairs = unpacker.read_map_header()
                for _ in range(n_pairs):
                    key = unpacker.unpack()
                    if key == target_key:
                        value = unpacker.unpack()
                        return json.dumps({target_key: value}, indent=2)
                    # skip() avoids deserializing the value into a Python object.
                    # Falls back to next() on environments without the C extension.
                    if hasattr(unpacker, "skip"):
                        unpacker.skip()
                    else:
                        next(unpacker)  # pure-Python fallback (allocates the value)

                return f"Key '{target_key}' not found in decoded blueprint."

    except Exception as e:
        return f"Error processing blueprint {path}: {str(e)}"


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 tools/read_blueprint.py <path> [target_key]")
    else:
        key = sys.argv[2] if len(sys.argv) > 2 else None
        print(stream_msgpack_zst(sys.argv[1], key))
