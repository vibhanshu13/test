#!/usr/bin/env python3
"""Live validation for the chunked backward-lineage file-graph API.

This script talks to a running API server. It intentionally validates both:
  1. The existing chunked API contract remains unchanged.
  2. The new graph-only API returns the accumulated full_file_flow.

Example:
  python3 tools/validate_file_graph_api.py \
    --base-url http://localhost:8201 \
    --username testadmin_e2e \
    --password 'TestAdmin123!' \
    --kb-id <kb_uuid> \
    --variable WK_VAR \
    --chain-files root,mod
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from typing import Any, Dict, List, Optional

try:
    import requests
except ImportError:  # pragma: no cover - user-facing validation script
    print("ERROR: requests is not installed. Install API requirements first.", file=sys.stderr)
    raise SystemExit(2)

PASS = 0
FAIL = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS   {name}" + (f" -- {detail}" if detail else ""))
    else:
        FAIL += 1
        print(f"  FAIL   {name}" + (f" -- {detail}" if detail else ""))


def _json(resp: requests.Response) -> Any:
    try:
        return resp.json()
    except Exception:
        return {"raw": resp.text[:1000]}


class Client:
    def __init__(self, base_url: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.token: Optional[str] = None

    @property
    def headers(self) -> Dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def login(self, username: str, password: str) -> None:
        resp = requests.post(
            f"{self.base_url}/v1/auth/login",
            json={"username": username, "password": password},
            timeout=30,
        )
        body = _json(resp)
        check("login returns 200", resp.status_code == 200, detail=str(body))
        if resp.status_code != 200 or "access_token" not in body:
            raise RuntimeError(f"Login failed: HTTP {resp.status_code}: {body}")
        self.token = body["access_token"]

    def post(self, path: str, payload: Dict[str, Any], timeout: int = 30) -> requests.Response:
        return requests.post(f"{self.base_url}{path}", json=payload, headers=self.headers, timeout=timeout)

    def get(self, path: str, timeout: int = 30, authed: bool = True) -> requests.Response:
        headers = self.headers if authed else {"Content-Type": "application/json"}
        return requests.get(f"{self.base_url}{path}", headers=headers, timeout=timeout)


def poll_task(client: Client, task_id: str, timeout_s: int = 900) -> Dict[str, Any]:
    deadline = time.time() + timeout_s
    last_body: Dict[str, Any] = {}
    while time.time() < deadline:
        resp = client.get(f"/v1/tasks/{task_id}", timeout=20)
        body = _json(resp)
        if not isinstance(body, dict):
            body = {"body": body}
        last_body = body
        state = body.get("state")
        print(f"  task {task_id}: state={state} complete={body.get('is_complete')} progress={body.get('progress')}")
        if body.get("is_complete"):
            return body
        time.sleep(3)
    raise TimeoutError(f"Task {task_id} did not complete within {timeout_s}s. Last body: {last_body}")


def find_chunk_output(client: Client, kb_id: str, variable: str, tuple_index: int) -> str:
    expected_suffix = f"backward_lineage/{variable}_tuple_{tuple_index}.json"
    resp = client.get(f"/v1/knowledge-bases/{kb_id}/files", timeout=30)
    files = _json(resp)
    if resp.status_code != 200 or not isinstance(files, list):
        raise RuntimeError(f"Could not list KB files: HTTP {resp.status_code}: {files}")
    for entry in files:
        path = str(entry.get("path") or "")
        if path == expected_suffix:
            return path
    for entry in files:
        path = str(entry.get("path") or "")
        if path.endswith(f"/{variable}_tuple_{tuple_index}.json") or path.endswith(f"{variable}_tuple_{tuple_index}.json"):
            return path
    raise FileNotFoundError(f"Could not find chunk output {expected_suffix}; files={files[:10]}")


def download_json_file(client: Client, kb_id: str, file_path: str) -> Dict[str, Any]:
    resp = client.get(f"/v1/knowledge-bases/{kb_id}/files/{file_path}", timeout=60)
    body = _json(resp)
    check(f"download {file_path} returns 200", resp.status_code == 200, detail=str(body)[:300])
    if resp.status_code != 200 or not isinstance(body, dict):
        raise RuntimeError(f"Could not download JSON file {file_path}: HTTP {resp.status_code}: {body}")
    return body


def run(args: argparse.Namespace) -> int:
    client = Client(args.base_url)
    client.login(args.username, args.password)

    chain_files = [x.strip() for x in args.chain_files.split(",") if x.strip()]
    if len(chain_files) < 2:
        raise ValueError("--chain-files must contain at least two comma-separated stems")

    payload: Dict[str, Any] = {
        "variable_name": args.variable,
        "chain_files": chain_files,
        "start_tuple_index": args.start_tuple_index,
    }
    if args.asm_dir:
        payload["asm_dir"] = args.asm_dir
    if args.t8_max_scan is not None:
        payload["t8_max_scan"] = args.t8_max_scan

    print("\n" + "=" * 78)
    print("existing chunked API session creation / reuse")
    print("=" * 78)
    resp = client.post(f"/v1/knowledge-bases/{args.kb_id}/backward-lineage/chunks", payload, timeout=60)
    body = _json(resp)
    check("chunked API returns 202", resp.status_code == 202, detail=str(body)[:500])
    if resp.status_code != 202:
        print(
            "\nBLOCKER: existing chunked API did not accept the request. "
            "This may be the pre-existing dispatch bug mentioned in the plan, "
            "or a validation/data issue. The new graph endpoint cannot be live-validated "
            "until a chunked session exists.",
            file=sys.stderr,
        )
        return 2

    output_file: Optional[str] = None
    task_id = body.get("celery_task_id") if isinstance(body, dict) else None
    if task_id:
        task_body = poll_task(client, task_id, timeout_s=args.task_timeout)
        check("chunked task completed successfully", task_body.get("state") == "SUCCESS", detail=str(task_body)[:500])
        result = task_body.get("result") if isinstance(task_body.get("result"), dict) else {}
        output_file = result.get("output_file")
    if not output_file:
        output_file = find_chunk_output(client, args.kb_id, args.variable, args.start_tuple_index)

    chunk_page = download_json_file(client, args.kb_id, output_file)
    session_id = str(chunk_page.get("session_id") or "")
    check("chunk page includes session_id", bool(session_id), detail=str(chunk_page)[:500])
    check("existing chunk page has no top-level full_file_flow", "full_file_flow" not in chunk_page)
    check("existing chunk page has tuple", isinstance(chunk_page.get("tuple"), dict), detail=str(chunk_page)[:500])
    tuple_obj = chunk_page.get("tuple") or {}
    check("existing tuple.full_flow_edges remains present", "full_flow_edges" in tuple_obj, detail=str(tuple_obj)[:500])

    print("\n" + "=" * 78)
    print("new file-graph API")
    print("=" * 78)
    unauth = client.get(
        f"/v1/knowledge-bases/{args.kb_id}/backward-lineage/sessions/{session_id}/file-graph",
        authed=False,
        timeout=30,
    )
    check("file-graph API requires auth", unauth.status_code == 401, detail=str(_json(unauth)))

    invalid = client.get(
        f"/v1/knowledge-bases/{args.kb_id}/backward-lineage/sessions/NOT_HEX/file-graph",
        timeout=30,
    )
    check("invalid session id returns 422", invalid.status_code == 422, detail=str(_json(invalid)))

    missing = client.get(
        f"/v1/knowledge-bases/{args.kb_id}/backward-lineage/sessions/ffffffffffffffff/file-graph",
        timeout=30,
    )
    check("missing session returns 404", missing.status_code == 404, detail=str(_json(missing)))

    graph_resp = client.get(
        f"/v1/knowledge-bases/{args.kb_id}/backward-lineage/sessions/{session_id}/file-graph",
        timeout=60,
    )
    graph_body = _json(graph_resp)
    check("file-graph API returns 200", graph_resp.status_code == 200, detail=str(graph_body)[:500])
    if graph_resp.status_code == 200 and isinstance(graph_body, dict):
        check("file-graph echoes kb_id", graph_body.get("kb_id") == args.kb_id)
        check("file-graph echoes session_id", graph_body.get("session_id") == session_id)
        flow = graph_body.get("full_file_flow") or {}
        check("file-graph full_file_flow.nodes is list", isinstance(flow.get("nodes"), list), detail=str(flow)[:500])
        check("file-graph full_file_flow.edges is list", isinstance(flow.get("edges"), list), detail=str(flow)[:500])
        check("file-graph tuple_count is int", isinstance(graph_body.get("tuple_count"), int), detail=str(graph_body)[:500])

    print("\n" + "=" * 78)
    print(f"RESULT: PASS={PASS} FAIL={FAIL}")
    print("=" * 78)
    return 1 if FAIL else 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate the live file-graph API against a running server.")
    parser.add_argument("--base-url", default=os.getenv("BASE_URL", "http://localhost:8201"))
    parser.add_argument("--username", default=os.getenv("API_USERNAME", os.getenv("USERNAME", "testadmin_e2e")))
    parser.add_argument("--password", default=os.getenv("API_PASSWORD", os.getenv("PASSWORD", "TestAdmin123!")))
    parser.add_argument("--kb-id", default=os.getenv("KB_ID"), required=not bool(os.getenv("KB_ID")))
    parser.add_argument("--variable", default=os.getenv("VARIABLE_NAME"), required=not bool(os.getenv("VARIABLE_NAME")))
    parser.add_argument("--chain-files", default=os.getenv("CHAIN_FILES"), required=not bool(os.getenv("CHAIN_FILES")))
    parser.add_argument("--start-tuple-index", type=int, default=int(os.getenv("START_TUPLE_INDEX", "0")))
    parser.add_argument("--asm-dir", default=os.getenv("ASM_DIR"))
    parser.add_argument("--t8-max-scan", type=int, default=None)
    parser.add_argument("--task-timeout", type=int, default=int(os.getenv("TASK_TIMEOUT", "900")))
    return parser.parse_args()


if __name__ == "__main__":
    try:
        raise SystemExit(run(parse_args()))
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1)
