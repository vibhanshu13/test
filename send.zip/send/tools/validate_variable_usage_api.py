#!/usr/bin/env python3
"""
Validation script for POST /v1/knowledge-bases/{kb_id}/variable-usage.

Usage:
    KB_ID=<your-kb-id> AUTH_TOKEN=<jwt> python tools/validate_variable_usage_api.py

Optional env vars:
    API_BASE_URL  (default: http://localhost:8000)
    KB_ID         (required: a KB with a completed pipeline run)
    AUTH_TOKEN    (required: JWT bearer token)
    TIMEOUT       (default: 120 seconds per job poll)
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import msgpack
except ImportError:
    print("ERROR: msgpack not installed. Run: pip install msgpack")
    sys.exit(1)

try:
    import requests
except ImportError:
    print("ERROR: requests not installed. Run: pip install requests")
    sys.exit(1)

BASE_URL = os.environ.get("API_BASE_URL", "http://localhost:8000").rstrip("/")
KB_ID    = os.environ.get("KB_ID", "")
TOKEN    = os.environ.get("AUTH_TOKEN", "")
TIMEOUT  = int(os.environ.get("TIMEOUT", "120"))
HEADERS  = {"Authorization": f"Bearer {TOKEN}"} if TOKEN else {}

PASS = "PASS"
FAIL = "FAIL"
_results: List[str] = []


def _check(condition: bool, label: str) -> None:
    marker = PASS if condition else FAIL
    _results.append(f"  [{marker}] {label}")
    if not condition:
        print(f"  [FAIL] {label}")
    else:
        print(f"  [pass] {label}")


def submit(variable_name: str) -> Dict:
    url  = f"{BASE_URL}/v1/knowledge-bases/{KB_ID}/variable-usage"
    resp = requests.post(url, json={"variable_name": variable_name}, headers=HEADERS, timeout=30)
    resp.raise_for_status()
    return resp.json()


def poll_until_done(celery_task_id: str, poll_timeout: int = TIMEOUT) -> Dict:
    url   = f"{BASE_URL}/v1/tasks/{celery_task_id}"
    start = time.time()
    while True:
        resp = requests.get(url, headers=HEADERS, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        if data.get("is_complete"):
            return data
        elapsed = time.time() - start
        if elapsed > poll_timeout:
            raise TimeoutError(f"Task {celery_task_id} did not complete within {poll_timeout}s")
        time.sleep(2)


def get_job_status(job_id: str) -> Dict:
    url  = f"{BASE_URL}/v1/jobs/{job_id}"
    resp = requests.get(url, headers=HEADERS, timeout=10)
    resp.raise_for_status()
    return resp.json()


def get_job_results(job_id: str) -> Dict:
    url  = f"{BASE_URL}/v1/jobs/{job_id}/results"
    resp = requests.get(url, headers=HEADERS, timeout=10)
    resp.raise_for_status()
    return resp.json()



def download_msgpack_result(job_id: str, variable_name: str = "") -> Dict:
    """Download the shared variable_usage.msgpack and extract the specific variable's result."""
    results = get_job_results(job_id)
    files   = results.get("files", []) if isinstance(results, dict) else results

    target = next(
        (f for f in files if Path(f.get("path") or f.get("name", "")).name == "variable_usage.msgpack"),
        None,
    )
    if target is None:
        raise ValueError(f"variable_usage.msgpack not found in job {job_id} results: {files}")

    file_path = target.get("path") or target.get("name")
    url  = f"{BASE_URL}/v1/jobs/{job_id}/files/{file_path}"
    resp = requests.get(url, headers=HEADERS, timeout=30)
    resp.raise_for_status()

    cache = msgpack.unpackb(resp.content, raw=False, strict_map_key=False)

    if variable_name:
        var_upper = variable_name.strip().upper()
        result = cache.get(var_upper)
        if result is None:
            raise ValueError(f"Variable {var_upper!r} not found in cache for job {job_id}")
        return result

    return cache


# ---------------------------------------------------------------------------
# Schema validators
# ---------------------------------------------------------------------------

def validate_schema(result: Dict, var_name: str) -> None:
    _check("variable_name" in result, f"{var_name}: has variable_name")
    _check("found" in result, f"{var_name}: has found")
    _check("total_files" in result, f"{var_name}: has total_files")
    _check("total_locations" in result, f"{var_name}: has total_locations")
    _check("search_tiers_used" in result, f"{var_name}: has search_tiers_used")
    _check("files" in result, f"{var_name}: has files")
    _check("suggestions" in result, f"{var_name}: has suggestions")

    _check(
        result.get("total_files") == len(result.get("files", [])),
        f"{var_name}: total_files == len(files)",
    )
    _check(
        result.get("total_locations") == sum(f.get("total_locations", 0) for f in result.get("files", [])),
        f"{var_name}: total_locations == sum of file totals",
    )

    for f in result.get("files", []):
        fp = f.get("file_path", "")
        _check(
            f.get("total_locations") == len(f.get("locations", [])),
            f"{var_name}: {Path(fp).name} total_locations == len(locations)",
        )
        for loc in f.get("locations", []):
            line = loc.get("line", 0)
            _check(line >= 1, f"{var_name}: {Path(fp).name} L{line} >= 1")
            _check(
                loc.get("context") in ("definition", "reference", "modification"),
                f"{var_name}: {Path(fp).name} L{line} context is valid",
            )
            chunk = loc.get("code_chunk")
            if chunk:
                start = chunk.get("start_line", 0)
                end   = chunk.get("end_line", 0)
                lines = chunk.get("lines", [])
                _check(
                    len(lines) == end - start + 1,
                    f"{var_name}: {Path(fp).name} L{line} chunk length matches range",
                )
                hl = chunk.get("highlight_line", 0)
                _check(
                    start <= hl <= end,
                    f"{var_name}: {Path(fp).name} L{line} highlight_line in range",
                )


def validate_file_existence(result: Dict, var_name: str) -> None:
    for f in result.get("files", []):
        fp = f.get("file_path", "")
        exists = Path(fp).exists()
        _check(exists, f"{var_name}: {Path(fp).name} exists on disk")
        if exists:
            total_source_lines = len(Path(fp).read_text(errors="replace").splitlines())
            for loc in f.get("locations", []):
                line = loc.get("line", 0)
                _check(
                    1 <= line <= total_source_lines,
                    f"{var_name}: {Path(fp).name} L{line} within file bounds ({total_source_lines} lines)",
                )


def validate_code_chunks(result: Dict, var_name: str) -> None:
    for f in result.get("files", []):
        fp = f.get("file_path", "")
        for loc in f.get("locations", []):
            line  = loc.get("line", 0)
            chunk = loc.get("code_chunk")
            _check(
                chunk is not None,
                f"{var_name}: {Path(fp).name} L{line} has code_chunk",
            )
            if chunk:
                _check(
                    len(chunk.get("lines", [])) > 0,
                    f"{var_name}: {Path(fp).name} L{line} code_chunk non-empty",
                )


def validate_chunk_content(result: Dict, var_name: str) -> None:
    """At least one line in each chunk should contain the variable name (case-insensitive)."""
    needle = var_name.lower()
    for f in result.get("files", []):
        fp = f.get("file_path", "")
        for loc in f.get("locations", []):
            line  = loc.get("line", 0)
            chunk = loc.get("code_chunk")
            if not chunk:
                continue
            found_in_chunk = any(needle in ln.lower() for ln in chunk.get("lines", []))
            _check(
                found_in_chunk,
                f"{var_name}: {Path(fp).name} L{line} chunk contains '{var_name}'",
            )


def validate_cross_reference(result: Dict, var_name: str, kb_id: str) -> None:
    """Verify all file paths appear in the universe's all_locations for this variable."""
    kb_output = Path(os.environ.get("JOBS_BASE_DIR", str(Path(__file__).parents[1] / "jobs"))) / kb_id / "output"
    universe_path = kb_output / "asm_variable_universe.json"
    if not universe_path.exists():
        print(f"  [SKIP] cross-reference: universe not found at {universe_path}")
        return

    import json
    universe = json.loads(universe_path.read_text())
    var_upper = var_name.upper()
    entries   = universe.get("variables", {}).get(var_upper, [])

    universe_files: set = set()
    universe_lines: set = set()
    for entry in entries:
        for loc in entry.get("all_locations", []):
            universe_files.add(loc.get("file", ""))
            universe_lines.add((loc.get("file", ""), loc.get("line", 0)))

    for f in result.get("files", []):
        fp = f.get("file_path", "")
        _check(
            fp in universe_files,
            f"{var_name}: cross-ref: {Path(fp).name} in universe all_locations",
        )
        for loc in f.get("locations", []):
            line = loc.get("line", 0)
            _check(
                (fp, line) in universe_lines,
                f"{var_name}: cross-ref: {Path(fp).name} L{line} in universe lines",
            )


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------

def run_test(
    variable_name: str,
    expect_found: bool = True,
    expect_files: Optional[int] = None,
    expect_locations: Optional[int] = None,
    expect_tier: Optional[str] = None,
    do_chunk_content: bool = False,
    do_cross_reference: bool = False,
    do_file_existence: bool = True,
) -> None:
    print(f"\n{'='*60}")
    print(f"TEST: {variable_name!r}")
    print(f"{'='*60}")

    # 1. Submit
    print("  [submit] POST variable-usage ...")
    job_resp = submit(variable_name)
    job_id          = job_resp["job_id"]
    celery_task_id  = job_resp["celery_task_id"]
    print(f"  [submit] job_id={job_id}, celery_task_id={celery_task_id}")

    # Check initial job status
    initial_status = get_job_status(job_id)
    _check(
        initial_status.get("status") in ("pending", "running"),
        f"{variable_name}: initial job status is pending or running",
    )

    # 2. Poll
    print("  [poll] waiting for completion ...")
    task_result = poll_until_done(celery_task_id)
    _check(task_result.get("state") == "SUCCESS", f"{variable_name}: task state == SUCCESS")

    # 3. Final job status
    final_status = get_job_status(job_id)
    _check(final_status.get("status") == "success", f"{variable_name}: final job status == success")

    # 4. Result file listed
    results_listing = get_job_results(job_id)
    files_listed = results_listing.get("files", results_listing if isinstance(results_listing, list) else [])
    has_msgpack = any("_variable_usage.msgpack" in (f.get("name","") or f.get("path","")) for f in files_listed)
    _check(has_msgpack, f"{variable_name}: result file listed in /results")

    # 5. Download + decode msgpack
    print("  [download] fetching msgpack result ...")
    result = download_msgpack_result(job_id, variable_name)

    # 6. msgpack integrity
    _check(isinstance(result, dict), f"{variable_name}: decoded result is dict")
    for key in ("variable_name", "input_name", "found", "total_files", "total_locations", "search_tiers_used", "files", "suggestions"):
        _check(key in result, f"{variable_name}: result has key '{key}'")

    # 7. Normalization
    _check(
        result.get("variable_name") == variable_name.strip().upper(),
        f"{variable_name}: variable_name normalized to {variable_name.strip().upper()!r}",
    )
    _check(
        result.get("input_name") == variable_name.strip(),
        f"{variable_name}: input_name preserved as {variable_name.strip()!r}",
    )

    # 8. Found/not-found
    _check(result.get("found") == expect_found, f"{variable_name}: found == {expect_found}")

    if expect_found:
        # 9. Schema
        validate_schema(result, variable_name)

        # 10. Concrete counts
        if expect_files is not None:
            _check(result["total_files"] == expect_files, f"{variable_name}: total_files == {expect_files} (got {result['total_files']})")
        if expect_locations is not None:
            _check(result["total_locations"] == expect_locations, f"{variable_name}: total_locations == {expect_locations} (got {result['total_locations']})")

        # 11. Tier attribution
        if expect_tier:
            _check(expect_tier in result["search_tiers_used"], f"{variable_name}: '{expect_tier}' in search_tiers_used")

        # 12. File existence + line bounds
        if do_file_existence:
            validate_file_existence(result, variable_name)

        # 13. Code chunks non-empty
        validate_code_chunks(result, variable_name)

        # 14. Chunk content
        if do_chunk_content:
            validate_chunk_content(result, variable_name)

        # 15. Cross-reference against universe
        if do_cross_reference:
            validate_cross_reference(result, variable_name, KB_ID)

    else:
        # Not-found assertions
        _check(result["total_files"] == 0, f"{variable_name}: total_files == 0")
        _check(result["total_locations"] == 0, f"{variable_name}: total_locations == 0")
        _check(result["files"] == [], f"{variable_name}: files == []")
        _check(isinstance(result["suggestions"], list), f"{variable_name}: suggestions is list")


def run_case_normalization_test() -> None:
    """Submit lowercase 'pkdzero' — should be served from cache and match 'PKDZERO'."""
    print(f"\n{'='*60}")
    print("EDGE CASE: case normalization — submit 'pkdzero' (lowercase)")
    print(f"{'='*60}")
    job_resp = submit("pkdzero")
    task_result = poll_until_done(job_resp["celery_task_id"])
    _check(task_result.get("state") == "SUCCESS", "case norm: task SUCCESS")
    _check(task_result.get("result", {}).get("cached") is True, "case norm: served from cache")
    result = download_msgpack_result(job_resp["job_id"], "pkdzero")
    _check(result["variable_name"] == "PKDZERO", "case norm: variable_name == 'PKDZERO'")
    _check(result["found"] is True, "case norm: found == True")
    _check(result["total_files"] == 7, f"case norm: total_files == 7 (got {result['total_files']})")


def run_cpp_case_test() -> None:
    """Submit 'DA7GL' (uppercase) — should be served from cache (same key as 'da7gl')."""
    print(f"\n{'='*60}")
    print("EDGE CASE: C++ case-insensitive — submit 'DA7GL' (uppercase)")
    print(f"{'='*60}")
    job_resp = submit("DA7GL")
    task_result = poll_until_done(job_resp["celery_task_id"])
    _check(task_result.get("state") == "SUCCESS", "cpp_case: task SUCCESS")
    _check(task_result.get("result", {}).get("cached") is True, "cpp_case: served from cache")
    result = download_msgpack_result(job_resp["job_id"], "DA7GL")
    _check(result["found"] is True, "cpp_case: found == True")
    _check(result["total_files"] == 3, f"cpp_case: total_files == 3 (got {result['total_files']})")
    _check(result["total_locations"] == 65, f"cpp_case: total_locations == 65 (got {result['total_locations']})")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    if not KB_ID:
        print("ERROR: KB_ID env var is required.")
        sys.exit(1)
    if not TOKEN:
        print("WARNING: AUTH_TOKEN not set. Requests may fail if auth is enabled.")

    print(f"API: {BASE_URL}")
    print(f"KB:  {KB_ID}")
    print(f"Poll timeout: {TIMEOUT}s")

    # ---- Test 1: PKDZERO (7 files, 64 locations, universe tier) ----
    run_test(
        "PKDZERO",
        expect_found=True,
        expect_files=7,
        expect_locations=64,
        expect_tier="universe",
        do_chunk_content=True,
        do_cross_reference=True,
    )

    # ---- Test 2: LM1BID&A (macro param, universe tier, NOT in identity index) ----
    run_test(
        "LM1BID&A",
        expect_found=True,
        expect_tier="universe",
        do_chunk_content=True,
    )

    # ---- Test 3: A (multi-file, 7 files, 14 locations) ----
    run_test(
        "A",
        expect_found=True,
        expect_files=7,
        expect_locations=14,
        expect_tier="universe",
    )

    # ---- Test 4: da7gl (C++ + ASM via identity index: 3 files, 65 locs total) ----
    # 63 unique locs in dx740200.cpp + 1 in da76.asm + 1 in da78.asm (via identity/blueprint tiers)
    run_test(
        "da7gl",
        expect_found=True,
        expect_files=3,
        expect_locations=65,
        expect_tier="universe",
    )

    # ---- Test 5: non-existent variable ----
    run_test(
        "TOTALLY_NONEXISTENT_XYZ_VAR",
        expect_found=False,
        do_file_existence=False,
    )

    # ---- Edge cases ----
    run_case_normalization_test()   # pkdzero → cache hit for PKDZERO
    run_cpp_case_test()             # DA7GL → cache hit for da7gl result

    # ---- Summary ----
    total  = len(_results)
    passed = sum(1 for r in _results if PASS in r)
    failed = total - passed

    print(f"\n{'='*60}")
    print(f"SUMMARY: {passed}/{total} passed, {failed} failed")
    print(f"{'='*60}")
    if failed:
        print("\nFailed checks:")
        for r in _results:
            if FAIL in r:
                print(r)
        sys.exit(1)
    else:
        print("All checks passed.")


if __name__ == "__main__":
    main()
