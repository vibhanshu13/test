# `patch_process_file_graph.py` — Retrofitting Seed Paths for Old KBs

## The problem

The per-process seed JSONs that `api/tasks/process_seeds.py` materialises into
`<ws.output_dir>/processes/<process>/` carry file paths inside them — most
importantly:

- `file_graph.json`: `seed_file`, `files[]`, and every edge's `from_file` /
  `to_file`
- `headers.json`: each `headers_found[].resolved_path`

Historically those JSONs were built against a placeholder source directory
(e.g. `temp/asm/`) rather than the KB's actual source tree. When the seeds
were copied verbatim into a real KB's output, every path inside them still
pointed at `temp/asm/FOO.asm` instead of the KB's true location (e.g.
`datasource/<user>/asm_version_3/FOO.asm`). Downstream consumers that try to
open those paths from disk silently fail, and any UI that renders the seed
file or its headers shows the wrong (non-existent) location.

The live pipeline was fixed in commit `77ea728` ("fixed error in process
workflow"): `find_clusters_and_write` now rewrites the placeholder prefix to
the KB's real source path immediately after copying the seeds, using
`_patch_file_graph_paths` and `_patch_headers_paths`.

That fix only helps **new** KBs. KBs that were already processed before the
fix landed still have `temp/asm/...` paths sitting on disk inside their
`processes/<process>/file_graph.json` and `processes/<process>/headers.json`.
This tool retrofits the same rewrite onto those existing KBs **without
re-running the pipeline**.

---

## When to use it

Run this once per affected KB any time you see a KB whose
`output/processes/<process>/file_graph.json` has a `seed_file` starting with
something like `temp/asm/...` instead of `datasource/<user>/asm_version_X/...`.

If you've just processed a KB on a build that already contains `77ea728`, you
do **not** need this tool — the paths will already be correct.

---

## What it does

For the given `<job_id>` (== `kb_id`):

1. Locates `<ws.output_dir>/processes/` via `WorkspaceManager(job_id)`.
2. Resolves the KB's real source directory (see "Source path resolution"
   below).
3. Iterates every `processes/<process>/` subdirectory in sorted order, and
   for each one:
   - calls `_patch_file_graph_paths(file_graph.json, actual_source_path)`
   - calls `_patch_headers_paths(headers.json, actual_source_path)` if
     `headers.json` exists
4. Prints a per-process `PATCHED` / `already correct` line, with a
   `before → after` diff for the first changed field in each file.
5. Prints a final `Done. N patched, M skipped.` summary.

Both helpers are imported directly from `api.tasks.process_seeds`, so the
on-disk result is byte-for-byte identical to what a fresh pipeline run on a
post-fix build would produce.

### Path rewriting rules (inherited from `process_seeds.py`)

- The placeholder prefix is **inferred from the seed file itself**:
  `_detect_placeholder` reads `data["seed_file"]` (or, for headers, the first
  `headers_found[].resolved_path`) and takes its parent directory. So the
  tool doesn't hard-code `temp/asm` — it patches whatever placeholder is
  actually in the JSON.
- The replacement is `_rel_source(actual_source_path)`, which converts the
  absolute source path to one relative to `settings.JOBS_BASE_DIR.parent`
  (the project root) when possible. If the source path lives outside the
  project root, it's used as-is.
- Replacement is **prefix-anchored on `placeholder + "/"`**, so a string
  like `temp/asm_backup/x.asm` is not falsely matched by a `temp/asm`
  placeholder.
- If the inferred placeholder equals the replacement, the file is left
  untouched.

### What gets rewritten

| File | Field(s) rewritten |
|---|---|
| `file_graph.json` | `seed_file`, `files[]`, each `edges[].from_file`, each `edges[].to_file` |
| `headers.json`   | each `headers_found[].resolved_path` |

`macros.json` and the optional `metadata.json` / `predefined_questions.json`
are **not** touched — they don't contain source-relative paths.

---

## Source path resolution

The tool determines the KB's real source directory by, in order:

1. `--source-path /abs/or/rel/path` if provided on the command line.
2. Otherwise `_resolve_actual_source_path(ws)` from `process_seeds.py`,
   which:
   1. reads `ws.get_pipeline_options()["source_path"]` (pipeline options
      stored on the workspace), then
   2. falls back to `KnowledgeBase.source_path` in `users.db`
      (`SELECT source_path FROM knowledge_bases WHERE id = <job_id>`).

If neither lookup succeeds and no `--source-path` was passed, the tool
errors out with `ERROR: Could not auto-detect source path. Use
--source-path.` and exits non-zero — it will **not** guess.

---

## Usage

```bash
# Auto-detect the source path from pipeline options / users.db
python tools/patch_process_file_graph.py <job_id>

# Force a specific source path (useful if the KB row is missing/wrong)
python tools/patch_process_file_graph.py <job_id> --source-path datasource/alice/asm_version_3
```

`<job_id>` is the KB's UUID — the same value that appears as the directory
name under `jobs/<job_id>/`.

### Example

```
$ python tools/patch_process_file_graph.py 4f1c... 
Auto-detected source path: datasource/alice/asm_version_3
  [C400] PATCHED
    file_graph: temp/asm/C400MAIN.asm → datasource/alice/asm_version_3/C400MAIN.asm
    headers:    temp/asm/COMMON.copy  → datasource/alice/asm_version_3/COMMON.copy
  [plastic_authentication] already correct — no change

Done. 1 patched, 1 skipped.
```

Exit code is `0` on success (including when nothing needed patching), and
non-zero only if the `processes/` directory is missing or the source path
can't be resolved.

---

## Safety

- **Idempotent.** Re-running on a KB that's already correct is a no-op — the
  helpers compare placeholder vs. replacement and bail before writing.
- **Same-format writes.** Files are re-serialised with `json.dumps(data,
  indent=2)`, matching the pipeline's own write style. Diffs against a
  freshly-processed KB should be confined to the rewritten path values.
- **No DB writes.** The tool only reads from `users.db` (via
  `_resolve_actual_source_path`); it never modifies it.
- **No pipeline side-effects.** It does not enqueue jobs, touch Redis, or
  invalidate caches — it only rewrites JSON on disk under
  `jobs/<job_id>/output/processes/`.

If a `file_graph.json` is malformed JSON, `_patch_file_graph_paths` catches
the exception and leaves the file alone (the process is reported as
"already correct — no change" because nothing was written). Headers behave
the same way.

---

## Related

- `api/tasks/process_seeds.py` — the live pipeline fix; this tool is a
  thin retrofit wrapper around its private helpers
  (`_patch_file_graph_paths`, `_patch_headers_paths`,
  `_resolve_actual_source_path`).
- Commit `77ea728` — "fixed error in process workflow"; introduced both the
  pipeline fix and this tool.
