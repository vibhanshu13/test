#!/usr/bin/env python3
"""Inspect a blueprint .asm.json / .mac.json file and report section sizes.

Usage:
    python3 tools/inspect_blueprint.py <path/to/file.asm.json>

Outputs:
    - Per-section size breakdown (MB and %)
    - macro_expansions entry count + top 20 largest macros
    - line_metadata entry count vs source line count estimate
    - variable_lineage node/edge counts
    - blocks instruction count
"""
from __future__ import annotations

import sys
import json
import struct
from pathlib import Path
from typing import Any, Dict

# ---------------------------------------------------------------------------
# Minimal blueprint loader — works without the full repo on sys.path.
# Supports JSON, plain msgpack, and zstd/gzip-compressed msgpack.
# ---------------------------------------------------------------------------

_ZSTD_MAGIC = b"\x28\xb5\x2f\xfd"
_GZIP_MAGIC = b"\x1f\x8b"


def _decompress(raw: bytes) -> bytes:
    """Transparently decompress zstd or gzip data; return plain bytes otherwise."""
    if raw[:4] == _ZSTD_MAGIC:
        try:
            import zstandard
            dctx = zstandard.ZstdDecompressor()
            try:
                return dctx.decompress(raw)
            except zstandard.ZstdError:
                with dctx.stream_reader(raw) as r:
                    return r.read()
        except ImportError:
            raise RuntimeError(
                "Blueprint is zstd-compressed but zstandard is not installed.\n"
                "Run:  pip install zstandard"
            )
    if raw[:2] == _GZIP_MAGIC:
        import gzip
        return gzip.decompress(raw)
    return raw


def _load_msgpack(data: bytes) -> Any:
    """msgpack-decode plain (already decompressed) bytes."""
    try:
        import msgpack
        return msgpack.unpackb(data, raw=False, strict_map_key=False)
    except ImportError:
        raise RuntimeError(
            "msgpack package not installed.\n"
            "Run:  pip install msgpack\n"
            "or activate the project venv first."
        )


def load_blueprint(path: Path) -> Dict[str, Any]:
    """Load a blueprint file (JSON, msgpack, or zstd/gzip-compressed msgpack)."""
    raw = path.read_bytes()
    if not raw:
        raise ValueError(f"Empty file: {path}")
    data = _decompress(raw)      # no-op for uncompressed files
    if data[0] == 0x7B:          # ASCII '{' → JSON
        return json.loads(data.decode("utf-8", errors="replace"))
    return _load_msgpack(data)


def _size_of(value: Any) -> int:
    """Return msgpack-serialized byte size of a value."""
    try:
        import msgpack
        return len(msgpack.packb(value, use_bin_type=True))
    except ImportError:
        # Fallback: use JSON length as approximation
        return len(json.dumps(value, separators=(",", ":")))


# ---------------------------------------------------------------------------
# Report helpers
# ---------------------------------------------------------------------------

def _bar(ratio: float, width: int = 30) -> str:
    filled = int(ratio * width)
    return "█" * filled + "░" * (width - filled)


def section_sizes(d: Dict[str, Any], file_size: int) -> None:
    print("\n" + "=" * 72)
    print(f"{'SECTION':<35} {'SIZE':>10}   {'%':>4}  BAR")
    print("=" * 72)

    rows = []
    for k, v in d.items():
        sz = _size_of(v)
        rows.append((k, sz))

    rows.sort(key=lambda x: x[1], reverse=True)

    for k, sz in rows:
        pct = sz * 100 / file_size if file_size else 0
        bar = _bar(pct / 100)
        sz_mb = sz / 1024 / 1024
        print(f"  {k:<33} {sz_mb:>7.2f} MB   {pct:>4.1f}%  {bar}")

    print("=" * 72)


def macro_expansions_report(d: Dict[str, Any]) -> None:
    exps = d.get("macro_expansions")
    if not isinstance(exps, list):
        print("\n  macro_expansions: not present or not a list")
        return

    print(f"\n{'=' * 72}")
    print(f"MACRO EXPANSIONS  —  {len(exps)} total entries")
    print(f"{'=' * 72}")

    if not exps:
        print("  (empty)")
        return

    # Count expanded instructions per macro
    # Supports both old key ("expanded_instructions") and new key ("expanded_code")
    rows = []
    total_instr = 0
    for e in exps:
        name = e.get("macro_name") or e.get("name") or "?"
        instructions = e.get("expanded_code") or e.get("expanded_instructions") or []
        n = len(instructions)
        total_instr += n
        rows.append((name, n))

    rows.sort(key=lambda x: x[1], reverse=True)

    print(f"  Total expanded instructions stored: {total_instr:,}")
    avg = total_instr / len(exps) if exps else 0
    print(f"  Average per macro call:             {avg:.0f}")
    print()
    print(f"  {'MACRO NAME':<35} {'INSTR COUNT':>12}")
    print(f"  {'-'*35}  {'-'*12}")
    for name, n in rows[:20]:
        bar = _bar(n / rows[0][1] if rows[0][1] else 0, width=20)
        print(f"  {name:<35} {n:>12,}  {bar}")
    if len(rows) > 20:
        print(f"  ... and {len(rows) - 20} more macro entries")


def lineage_report(d: Dict[str, Any]) -> None:
    vl = d.get("variable_lineage") or {}
    nodes = vl.get("nodes") or []
    edges = vl.get("edges") or []

    print(f"\n{'=' * 72}")
    print("VARIABLE LINEAGE")
    print(f"{'=' * 72}")
    print(f"  Nodes : {len(nodes):,}")
    print(f"  Edges : {len(edges):,}")

    if edges:
        ops: Dict[str, int] = {}
        for e in edges:
            op = e.get("operation_type") or "unknown"
            ops[op] = ops.get(op, 0) + 1
        print(f"\n  Edge types:")
        for op, cnt in sorted(ops.items(), key=lambda x: x[1], reverse=True)[:15]:
            print(f"    {op:<35} {cnt:>8,}")


def line_metadata_report(d: Dict[str, Any]) -> None:
    lm = d.get("line_metadata") or {}
    print(f"\n{'=' * 72}")
    print("LINE METADATA")
    print(f"{'=' * 72}")
    print(f"  Entries : {len(lm):,}")

    if lm:
        try:
            line_nums = [int(k) for k in lm.keys()]
            print(f"  Line range : {min(line_nums)} – {max(line_nums)}")
            above_source = sum(1 for n in line_nums if n > 2000)
            print(f"  Lines > 2000 (likely macro-expanded): {above_source:,}")
        except (ValueError, TypeError):
            pass

        # Sample entry size
        sample_key = next(iter(lm))
        sample_sz = _size_of(lm[sample_key])
        print(f"  Avg entry size (sample): ~{sample_sz} bytes")
        print(f"  Estimated total: ~{len(lm) * sample_sz / 1024 / 1024:.1f} MB")


def blocks_report(d: Dict[str, Any]) -> None:
    blocks = d.get("blocks") or []
    total_flow = sum(
        len(b.get("flow") or (b.get("flow") or {}).get("l") or [])
        if isinstance(b.get("flow"), (list, dict)) else 0
        for b in blocks
        if isinstance(b, dict)
    )
    print(f"\n{'=' * 72}")
    print("BLOCKS")
    print(f"{'=' * 72}")
    print(f"  Block count             : {len(blocks):,}")
    print(f"  Total flow instructions : {total_flow:,}")


def summary(path: Path, file_size: int, d: Dict[str, Any]) -> None:
    print(f"\n{'=' * 72}")
    print("SUMMARY")
    print(f"{'=' * 72}")
    print(f"  File      : {path.name}")
    print(f"  File size : {file_size / 1024 / 1024:.2f} MB  ({file_size:,} bytes)")
    print(f"  Format    : {'JSON' if path.read_bytes()[0] == 0x7B else 'msgpack (binary)'}")
    print(f"  Sections  : {len(d)}")

    exps = d.get("macro_expansions") or []
    total_instr = sum(
        len(e.get("expanded_code") or e.get("expanded_instructions") or [])
        for e in exps
    )
    vl = d.get("variable_lineage") or {}
    lm = d.get("line_metadata") or {}

    print(f"  Macro expansions        : {len(exps):,} entries, {total_instr:,} expanded instructions")
    print(f"  Variable lineage edges  : {len(vl.get('edges') or []):,}")
    print(f"  Line metadata entries   : {len(lm):,}")
    print()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 1

    path = Path(sys.argv[1])
    if not path.exists():
        print(f"ERROR: file not found: {path}", file=sys.stderr)
        return 1

    print(f"\nLoading {path.name} ({path.stat().st_size / 1024 / 1024:.2f} MB) ...")
    try:
        d = load_blueprint(path)
    except RuntimeError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"ERROR loading blueprint: {e}", file=sys.stderr)
        return 1

    file_size = path.stat().st_size

    summary(path, file_size, d)
    section_sizes(d, file_size)
    macro_expansions_report(d)
    lineage_report(d)
    line_metadata_report(d)
    blocks_report(d)

    return 0


if __name__ == "__main__":
    sys.exit(main())
