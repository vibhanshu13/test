import sys
import os
import json

CHUNK_SIZE = 64 * 1024        # 64 KB read window fed to the index builder
SIDECAR_SUFFIX = ".jidx"

# Safety caps — prevent unbounded RAM consumption on malformed or adversarial input.
MAX_KEY_LEN   = 4 * 1024          # 4 KB max key name; abandon key_buf beyond this
MAX_VALUE_BYTES = 512 * 1024 * 1024  # 512 MB: refuse to load larger values into RAM


# ── Sidecar helpers ────────────────────────────────────────────────────────────

def _sidecar_path(file_path):
    return file_path + SIDECAR_SUFFIX


def _load_sidecar(file_path):
    """Return {key: [start_byte, end_byte]} or None if missing/stale/corrupt."""
    sp = _sidecar_path(file_path)
    try:
        if not os.path.exists(sp):
            return None
        if os.path.getmtime(sp) < os.path.getmtime(file_path):
            return None  # stale — source file was updated
        with open(sp, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def _save_sidecar(file_path, index):
    """Persist the offset index alongside the source file. Non-fatal on failure."""
    sp = _sidecar_path(file_path)
    try:
        with open(sp, 'w', encoding='utf-8') as f:
            json.dump(index, f)
    except Exception:
        pass  # read-only filesystem or permission error; fall back to linear scan next time


def _extract_at_offset(file_path, start, end):
    """Read raw bytes [start, end) from file and return as a decoded string.

    Raises ValueError if the value exceeds MAX_VALUE_BYTES (512 MB) to
    prevent a single call from consuming all available RAM.
    """
    size = end - start
    if size > MAX_VALUE_BYTES:
        raise ValueError(
            f"Value at offset [{start}, {end}) is {size / (1024**3):.2f} GB "
            f"which exceeds the {MAX_VALUE_BYTES // (1024**2)} MB safety limit. "
            "Narrow the query or increase MAX_VALUE_BYTES."
        )
    with open(file_path, 'rb') as f:
        f.seek(start)
        raw = f.read(size)
    return raw.decode('utf-8', errors='replace').strip()


# ── Full-index builder (single binary-mode pass) ───────────────────────────────

def _build_full_index(file_path):
    """
    Binary-mode single pass over a flat JSON object.

    Returns {key: [value_start_byte, value_end_byte]} for every top-level key.

    Design notes
    ------------
    - Opens in 'rb' mode so byte offsets are exact regardless of encoding or
      platform line-ending translation.
    - Non-ASCII bytes (≥ 128) are UTF-8 continuation bytes and cannot be JSON
      structural characters, so they are treated as opaque content.
    - No value content is held in RAM — only the [start, end) byte pair per key.
    - Peak memory: O(number_of_keys × avg_key_length) for key_buf + index dict.

    After the first call the caller saves a .jidx sidecar so that every
    subsequent lookup on any key is an O(1) seek instead of O(file_size).
    """
    # ── State constants ────────────────────────────────────────────────────────
    S_SCAN  = 0   # scanning for the next top-level key
    S_COLON = 1   # key collected; waiting for ':'
    S_VALUE = 2   # recording the byte range of the current value

    state       = S_SCAN
    in_str      = False
    esc         = False
    depth       = 0

    can_be_key  = False   # True iff the next '"' at depth 1 opens a key
    key_buf     = None    # list[str] while collecting a key name
    current_key = None    # the key whose value byte range we are recording

    is_complex  = None    # True=object/array; False=scalar; None=not started yet
    v_depth     = 0       # bracket depth inside a complex value
    value_start = 0       # byte offset of value's first byte

    index        = {}
    chunk_offset = 0      # cumulative byte offset at the start of the current chunk

    with open(file_path, 'rb') as f:
        while True:
            chunk = f.read(CHUNK_SIZE)
            if not chunk:
                break

            i = 0
            n = len(chunk)

            while i < n:
                b = chunk[i]
                # Non-ASCII bytes (b ≥ 128) are multi-byte UTF-8 continuation
                # bytes and cannot match any JSON structural character.
                c = chr(b) if b < 128 else '\x00'

                # ── Backslash escape inside a string ──────────────────────────
                if esc:
                    esc = False
                    if key_buf is not None:
                        key_buf.append(c)
                    i += 1
                    continue

                # ── Inside a string ───────────────────────────────────────────
                if in_str:
                    if c == '\\':
                        esc = True
                        if key_buf is not None:
                            key_buf.append(c)
                    elif c == '"':
                        in_str = False
                        if key_buf is not None:
                            current_key = ''.join(key_buf)
                            key_buf = None
                            if state == S_SCAN:
                                state = S_COLON
                    else:
                        if key_buf is not None:
                            key_buf.append(c)
                            # Safety: abandon pathologically long key names so
                            # key_buf never grows beyond MAX_KEY_LEN bytes.
                            if len(key_buf) > MAX_KEY_LEN:
                                key_buf = None  # treat as non-key string
                    i += 1
                    continue

                # ── Structural characters (outside any string) ─────────────────
                if state == S_SCAN:
                    if c == '"':
                        in_str = True
                        if depth == 1 and can_be_key:
                            key_buf = []
                            can_be_key = False
                    elif c in '{[':
                        depth += 1
                        if depth == 1:
                            can_be_key = True
                    elif c in '}]':
                        depth -= 1
                    elif c == ',' and depth == 1:
                        can_be_key = True
                    elif c == ':' and depth == 1:
                        can_be_key = False

                elif state == S_COLON:
                    if c == ':':
                        state      = S_VALUE
                        is_complex = None
                        v_depth    = 0
                    elif c == '"':
                        in_str = True  # defensive: stray string between key and ':'

                elif state == S_VALUE:
                    # Skip leading whitespace before the value's first character.
                    if is_complex is None:
                        if c in ' \t\n\r':
                            i += 1
                            continue
                        is_complex  = c in '{['
                        value_start = chunk_offset + i

                    if c == '"':
                        in_str = True
                    elif is_complex:
                        if c in '{[':
                            v_depth += 1
                        elif c in '}]':
                            v_depth -= 1
                            if v_depth == 0:
                                # Closing bracket of the top-level value — done.
                                value_end = chunk_offset + i + 1  # inclusive of '}'
                                if current_key is not None:
                                    index[current_key] = [value_start, value_end]
                                state       = S_SCAN
                                is_complex  = None
                                current_key = None
                    else:
                        # Scalar value: ends at the first unquoted delimiter.
                        if c in (',', '}', '\n', '\r', ']'):
                            value_end = chunk_offset + i  # delimiter is NOT part of value
                            if current_key is not None:
                                index[current_key] = [value_start, value_end]
                            state       = S_SCAN
                            is_complex  = None
                            current_key = None
                            # Apply the delimiter's S_SCAN semantics since we
                            # consumed it here and won't re-enter S_SCAN for it.
                            if c in '}]':
                                depth -= 1
                            elif c == ',' and depth == 1:
                                can_be_key = True

                i += 1

            chunk_offset += n

    # Edge case: scalar value reached EOF without a trailing delimiter.
    if state == S_VALUE and is_complex is not None and not is_complex:
        if current_key is not None:
            index[current_key] = [value_start, chunk_offset]

    return index


# ── Public API ────────────────────────────────────────────────────────────────

def surgical_json_extract(file_path, query_key):
    """
    Memory-efficient extraction of a single key from a large flat JSON object.

    Complexity
    ----------
    First call on a file  : O(file_size) — binary scan builds a sidecar index
                            (.jidx) recording the byte range of EVERY top-level
                            key.  All subsequent key lookups on the same file
                            are O(1) regardless of file size.
    Subsequent calls      : O(1) — loads sidecar (JSON dict, typically KB-sized),
                            seeks to recorded byte offset, reads only the matching
                            value bytes.
    Sidecar invalidation  : automatically regenerated when the source file's mtime
                            is newer than the sidecar's mtime.

    Correctness fixes over the original implementation
    ---------------------------------------------------
    1. String-aware state machine — brackets and delimiters inside JSON string
       values are ignored, so they cannot corrupt depth counting or trigger
       false-positive key matches.
    2. Structural key matching — the target key is recognised only at an actual
       object-key position (depth 1, after '{' or ','), never when the same text
       appears inside a value string.
    3. Binary-mode byte offsets — the index stores exact byte positions so seeks
       are correct for any UTF-8 content, including multi-byte characters.
    """
    if not os.path.exists(file_path):
        return f"Error: File {file_path} not found."

    try:
        # 1. Cache hit: O(1) seek directly to the value.
        sidecar = _load_sidecar(file_path)
        if sidecar is not None:
            if query_key in sidecar:
                start, end = sidecar[query_key]
                return _extract_at_offset(file_path, start, end)
            size_gb = os.path.getsize(file_path) / (1024 ** 3)
            return f"Key '{query_key}' not found in {file_path} ({size_gb:.2f} GB)"

        # 2. Cache miss: linear scan → build index for ALL keys → save sidecar.
        #    Subsequent queries on any key in this file become O(1).
        index = _build_full_index(file_path)
        _save_sidecar(file_path, index)

        if query_key in index:
            start, end = index[query_key]
            return _extract_at_offset(file_path, start, end)

        size_gb = os.path.getsize(file_path) / (1024 ** 3)
        return f"Key '{query_key}' not found in {file_path} ({size_gb:.2f} GB)"

    except Exception as e:
        return f"Error searching large JSON: {str(e)}"


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 tools/search_large_json.py <file_path> <query_key>")
    else:
        print(surgical_json_extract(sys.argv[1], sys.argv[2]))
