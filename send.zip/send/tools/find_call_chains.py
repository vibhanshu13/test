#!/usr/bin/env python3
"""Enumerate directed call chains that pass through a specific file node.

Input format is the JSON produced by `file_call_graph.py`.
Output is JSON only.

Usage:
    python3 tools/find_call_chains.py \
        --graph temp/output_latest/file_call_graph.json \
        --file da76

    python3 tools/find_call_chains.py \
        --graph temp/output_latest/file_call_graph.json \
        --file da76.asm \
        --max-depth 6 \
        --output temp/output_latest/da76_chains.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple


KNOWN_SOURCE_SUFFIXES = (
    ".asm.json",
    ".cpp.json",
    ".c.json",
    ".cc.json",
    ".cxx.json",
    ".h.json",
    ".hpp.json",
    ".hh.json",
    ".hxx.json",
    ".asm",
    ".cpp",
    ".c",
    ".cc",
    ".cxx",
    ".h",
    ".hpp",
    ".hh",
    ".hxx",
    ".json",
)


def _strip_known_suffixes(name: str) -> str:
    result = name.strip()
    lowered = result.lower()
    changed = True
    while changed:
        changed = False
        for suffix in KNOWN_SOURCE_SUFFIXES:
            if lowered.endswith(suffix):
                result = result[: -len(suffix)]
                lowered = result.lower()
                changed = True
                break
    return result


def _query_candidates(query: str) -> List[str]:
    raw = query.strip()
    basename = Path(raw).name
    stripped_raw = _strip_known_suffixes(raw)
    stripped_base = _strip_known_suffixes(basename)
    candidates = {
        raw,
        basename,
        stripped_raw,
        stripped_base,
        raw.lower(),
        basename.lower(),
        stripped_raw.lower(),
        stripped_base.lower(),
        raw.upper(),
        basename.upper(),
        stripped_raw.upper(),
        stripped_base.upper(),
    }
    return [candidate for candidate in candidates if candidate]


def _resolve_target(query: str, nodes: Set[str]) -> str:
    candidates = _query_candidates(query)
    node_by_lower: Dict[str, List[str]] = {}
    for node in nodes:
        node_by_lower.setdefault(node.lower(), []).append(node)

    for candidate in candidates:
        if candidate in nodes:
            return candidate

    for candidate in candidates:
        matches = node_by_lower.get(candidate.lower(), [])
        if len(matches) == 1:
            return matches[0]

    raise ValueError(
        f"Could not resolve target '{query}' to a unique graph node. "
        "Use an exact node id shown in graph['nodes'][*]['id']."
    )


def _dedup_call_sites(call_sites: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen: Set[Tuple[Any, ...]] = set()
    deduped: List[Dict[str, Any]] = []
    for site in call_sites:
        key = (
            site.get("source_file"),
            site.get("source_block"),
            site.get("line"),
            site.get("instruction"),
            site.get("call_type"),
            site.get("target_module"),
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(site)
    deduped.sort(
        key=lambda item: (
            str(item.get("source_file", "")),
            int(item.get("line", 0) or 0),
            str(item.get("instruction", "")),
            str(item.get("source_block", "")),
            str(item.get("target_module", "")),
        )
    )
    return deduped


def _build_graph_index(
    payload: Dict[str, Any]
) -> Tuple[
    Set[str],
    Dict[str, List[str]],
    Dict[str, List[str]],
    Dict[Tuple[str, str], Dict[str, Any]],
    int,
]:
    nodes: Set[str] = set()
    for node in payload.get("nodes", []):
        node_id = node.get("id")
        if node_id:
            nodes.add(node_id)

    edges_by_pair: Dict[Tuple[str, str], Dict[str, Any]] = {}
    adjacency_out: Dict[str, List[str]] = {}
    adjacency_in: Dict[str, List[str]] = {}

    raw_edges = payload.get("edges", [])
    for edge in raw_edges:
        source = edge.get("source")
        target = edge.get("target")
        if not source or not target:
            continue
        nodes.add(source)
        nodes.add(target)
        pair = (source, target)
        if pair not in edges_by_pair:
            edges_by_pair[pair] = {
                "source": source,
                "target": target,
                "is_internal": bool(edge.get("is_internal", False)),
                "instructions": list(edge.get("instructions") or []),
                "call_sites": list(edge.get("call_sites") or []),
            }
            adjacency_out.setdefault(source, []).append(target)
            adjacency_in.setdefault(target, []).append(source)
        else:
            current = edges_by_pair[pair]
            existing_instr = set(current.get("instructions", []))
            for instruction in edge.get("instructions", []):
                if instruction not in existing_instr:
                    current["instructions"].append(instruction)
                    existing_instr.add(instruction)
            current["call_sites"].extend(edge.get("call_sites") or [])

    for pair, edge in edges_by_pair.items():
        edge["call_sites"] = _dedup_call_sites(edge.get("call_sites", []))
        edge["instructions"] = sorted(set(edge.get("instructions", [])))

    for node in nodes:
        adjacency_out.setdefault(node, [])
        adjacency_in.setdefault(node, [])
        adjacency_out[node].sort()
        adjacency_in[node].sort()

    return nodes, adjacency_out, adjacency_in, edges_by_pair, len(raw_edges)


def _enumerate_paths(
    start: str,
    adjacency: Dict[str, List[str]],
    max_depth: Optional[int],
) -> Tuple[List[List[str]], int]:
    paths: List[List[str]] = []
    cycle_edges_skipped = 0

    def dfs(current: str, path: List[str], visited: Set[str]) -> None:
        nonlocal cycle_edges_skipped
        paths.append(path.copy())
        if max_depth is not None and (len(path) - 1) >= max_depth:
            return

        for next_node in adjacency.get(current, []):
            if next_node in visited:
                cycle_edges_skipped += 1
                continue
            path.append(next_node)
            visited.add(next_node)
            dfs(next_node, path, visited)
            visited.remove(next_node)
            path.pop()

    dfs(start, [start], {start})
    return paths, cycle_edges_skipped


def _build_hops(
    nodes: List[str], edges_by_pair: Dict[Tuple[str, str], Dict[str, Any]]
) -> List[Dict[str, Any]]:
    hops: List[Dict[str, Any]] = []
    for index in range(len(nodes) - 1):
        source = nodes[index]
        target = nodes[index + 1]
        edge = edges_by_pair[(source, target)]
        hops.append(
            {
                "position": index + 1,
                "source": source,
                "target": target,
                "instructions": edge.get("instructions", []),
                "call_site_count": len(edge.get("call_sites", [])),
                "call_sites": edge.get("call_sites", []),
            }
        )
    return hops


def find_chains(
    payload: Dict[str, Any],
    query_file: str,
    max_depth: Optional[int],
) -> Dict[str, Any]:
    nodes, adjacency_out, adjacency_in, edges_by_pair, raw_edge_count = _build_graph_index(payload)
    target = _resolve_target(query_file, nodes)

    incoming_paths_reversed, incoming_cycle_skips = _enumerate_paths(target, adjacency_in, max_depth)
    outgoing_paths, outgoing_cycle_skips = _enumerate_paths(target, adjacency_out, max_depth)

    prefixes = [list(reversed(path)) for path in incoming_paths_reversed]
    suffixes = outgoing_paths

    chains: List[Dict[str, Any]] = []
    seen_paths: Set[Tuple[str, ...]] = set()
    cross_path_cycle_skips = 0
    depth_limited_skips = 0

    for prefix in prefixes:
        for suffix in suffixes:
            combined = prefix + suffix[1:]
            combined_key = tuple(combined)

            if len(set(combined)) != len(combined):
                cross_path_cycle_skips += 1
                continue

            edge_count = len(combined) - 1
            if max_depth is not None and edge_count > max_depth:
                depth_limited_skips += 1
                continue

            if combined_key in seen_paths:
                continue
            seen_paths.add(combined_key)

            chains.append(
                {
                    "length_edges": edge_count,
                    "files": combined,
                    "hops": _build_hops(combined, edges_by_pair),
                }
            )

    chains.sort(key=lambda item: (item["length_edges"], item["files"]))
    for index, chain in enumerate(chains, start=1):
        chain["chain_id"] = index

    return {
        "query": {"input_file": query_file, "resolved_file": target, "max_depth": max_depth},
        "graph": {
            "node_count": len(nodes),
            "edge_count_raw": raw_edge_count,
            "edge_count_unique_pairs": len(edges_by_pair),
        },
        "stats": {
            "chain_count": len(chains),
            "cycle_edges_skipped": incoming_cycle_skips + outgoing_cycle_skips,
            "cross_path_cycle_skips": cross_path_cycle_skips,
            "depth_limited_skips": depth_limited_skips,
        },
        "chains": chains,
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Find all simple DFS call chains passing through a file node in a "
            "file_call_graph JSON."
        )
    )
    parser.add_argument(
        "--graph",
        required=True,
        metavar="FILE",
        help="Path to file_call_graph JSON (produced by file_call_graph.py).",
    )
    parser.add_argument(
        "--file",
        required=True,
        metavar="NAME",
        help="Target file node id (e.g. da76, da76.asm, DA76).",
    )
    parser.add_argument(
        "--max-depth",
        type=int,
        default=None,
        metavar="N",
        help=(
            "Maximum hop count per chain. Omit for infinity (all simple paths "
            "through the target)."
        ),
    )
    parser.add_argument(
        "--output",
        metavar="FILE",
        help="Write JSON result to FILE. If omitted, prints JSON to stdout.",
    )
    return parser.parse_args()


def main() -> int:
    args = _parse_args()

    if args.max_depth is not None and args.max_depth < 0:
        raise ValueError("--max-depth must be >= 0")

    graph_path = Path(args.graph)
    with graph_path.open(encoding="utf-8") as handle:
        payload = json.load(handle)

    result = find_chains(payload=payload, query_file=args.file, max_depth=args.max_depth)
    text = json.dumps(result, indent=2)

    if args.output:
        out_path = Path(args.output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(text + "\n", encoding="utf-8")
    else:
        print(text)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
