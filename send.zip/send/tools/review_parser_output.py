#!/usr/bin/env python3
"""Review parser output completeness for ASM and C/C++ JSON artifacts.

This validator complements tools/validate_blocks.py by checking whether key
sections (line metadata, call graph, block/DB flows, and variable lineage) cover
the expected source lines for a given source file.

Usage:
    python3 tools/review_parser_output.py [--append] <json_file_or_dir> [source_file_or_dir]

Examples:
    python3 tools/review_parser_output.py output/run/ENTRYDRV.asm.json tests/fixtures/ENTRYDRV.asm
    python3 tools/review_parser_output.py output/run/cpp/flow.cpp.json tests/fixtures/cpp/flow.cpp
    python3 tools/review_parser_output.py --append output/run/ tests/fixtures/
"""

from __future__ import annotations

import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set, Tuple

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from blueprint_io import iter_flow, load_blueprint, write_blueprint
from instruction_classifier import ControlFlowType, InstructionClassifier
from macro_classifier import MacroClassifier
from tokenizer import ParsedLine, Tokenizer
from models.provenance import StatementProvenance
from passes.c_family_parser import CFamilyParser
from tools.validate_blocks import validate as validate_blocks


REQUIRED_TOP_LEVEL_KEYS = (
    "metadata",
    "meta",
    "symbol_aliases",
    "symbols",
    "call_graph",
    "blocks",
    "subroutines",
    "db_operations",
    "file_dependencies",
    "macro_expansions",
    "macro_errors",
    "variable_lineage",
    "build_metadata",
    "line_metadata",
)


_BLOCK_SKIP_OPCODES: Set[str] = {
    "CSECT",
    "DSECT",
    "RSECT",
    "EQU",
    "DC",
    "DS",
    "USING",
    "DROP",
    "LTORG",
    "END",
    "MACRO",
    "MEND",
    "COPY",
    "ENTRY",
    "EXTRN",
    "WXTRN",
    "EJECT",
    "SPACE",
    "TITLE",
    "PUSH",
    "POP",
}

_INT_LITERAL_RE = re.compile(r"^[+-]?(?:0[xX][0-9A-Fa-f]+|\d+)(?:[uUlL]+)?$")
_REG_TOKEN_RE = re.compile(r"R(?:1[0-5]|[0-9])$", re.IGNORECASE)
_C_ACCESS_SPECIFIER_RE = re.compile(r"^(?:public|private|protected)\s*:\s*$")
_C_BRACE_ONLY_RE = re.compile(r"^[{}]+\s*;?\s*$")
# Valid HLASM opcode: 1–8 chars, letters/digits/@/$/#, no commas/equals/parens.
# Lines where the tokenizer emits an opcode that fails this check are
# continuation-line fragments misread as standalone instructions.
_VALID_ASM_OPCODE_RE = re.compile(r"^[A-Z@$#][A-Z0-9@$#]{0,7}$")

_ASM_EXTS = {".asm", ".mac", ".s", ".cpy", ".copy"}
_C_EXTS = {".c"}
_CPP_EXTS = {".cc", ".cpp", ".cxx", ".h", ".hpp", ".hh", ".hxx"}


@dataclass
class Metric:
    """Completeness metric."""

    name: str
    covered: int
    expected: int
    weight: float
    notes: List[str] = field(default_factory=list)

    @property
    def ratio(self) -> float:
        if self.expected <= 0:
            return 1.0
        return max(0.0, min(1.0, self.covered / self.expected))

    @property
    def points(self) -> float:
        return self.ratio * self.weight


PASS_THRESHOLD: float = 80.0
"""Weighted coverage score (0–100) at or above which a file is considered PASS."""


@dataclass
class ReviewResult:
    """Result of reviewing one JSON artifact."""

    filename: str
    score: float = 0.0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    metrics: List[Metric] = field(default_factory=list)
    line_audit_summary: Dict[str, object] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.score >= PASS_THRESHOLD


def _tokenize_source(asm_path: Path) -> Tuple[Dict[int, str], Dict[int, ParsedLine]]:
    tokenizer = Tokenizer()
    raw_lines: Dict[int, str] = {}
    parsed: Dict[int, ParsedLine] = {}
    with asm_path.open(encoding="utf-8", errors="replace") as fh:
        for line_num, raw in enumerate(fh, start=1):
            raw_lines[line_num] = raw.rstrip("\n")
            prov = StatementProvenance(
                statement_id=f"R{line_num}",
                original_file=str(asm_path),
                original_line=line_num,
            )
            parsed[line_num] = tokenizer.tokenize_line(raw.rstrip("\n"), prov)
    return raw_lines, parsed


def _detect_source_kind(source_path: Optional[Path]) -> str:
    if not source_path:
        return "unknown"
    suffix = source_path.suffix.lower()
    if suffix in _ASM_EXTS:
        return "asm"
    if suffix in _C_EXTS or suffix in _CPP_EXTS:
        return "c_family"
    return "unknown"


def _strip_c_comments_preserve_layout(text: str) -> str:
    def replace_block(match: re.Match[str]) -> str:
        chunk = match.group(0)
        return "".join("\n" if ch == "\n" else " " for ch in chunk)

    stripped = re.sub(r"/\*.*?\*/", replace_block, text, flags=re.DOTALL)
    stripped = re.sub(r"//[^\n]*", lambda m: " " * len(m.group(0)), stripped)
    return stripped


def _read_c_source_lines(source_path: Path) -> Tuple[Dict[int, str], Dict[int, str], str]:
    text = source_path.read_text(encoding="utf-8", errors="replace")
    cleaned = _strip_c_comments_preserve_layout(text)
    raw_lines = text.splitlines()
    clean_lines = cleaned.splitlines()

    raw_map: Dict[int, str] = {}
    clean_map: Dict[int, str] = {}
    max_len = max(len(raw_lines), len(clean_lines))
    for idx in range(max_len):
        line_no = idx + 1
        raw_map[line_no] = raw_lines[idx] if idx < len(raw_lines) else ""
        clean_map[line_no] = clean_lines[idx] if idx < len(clean_lines) else ""
    return raw_map, clean_map, text


def _c_line_exclusion_map(raw_lines: Dict[int, str], clean_lines: Dict[int, str]) -> Dict[int, Optional[str]]:
    reasons: Dict[int, Optional[str]] = {}
    in_preprocessor_continuation = False

    for line_no in sorted(raw_lines.keys()):
        raw = raw_lines[line_no]
        clean = clean_lines.get(line_no, "")
        raw_stripped = raw.strip()
        clean_stripped = clean.strip()

        reason: Optional[str] = None
        if raw_stripped == "":
            reason = "blank_line"
        elif in_preprocessor_continuation:
            reason = "preprocessor_line"
        elif clean_stripped == "":
            reason = "comment_line"
        elif clean_stripped.startswith("#"):
            reason = "preprocessor_line"
        elif _C_BRACE_ONLY_RE.fullmatch(clean_stripped):
            reason = "structural_brace_line"
        elif _C_ACCESS_SPECIFIER_RE.fullmatch(clean_stripped):
            reason = "access_specifier_line"

        reasons[line_no] = reason

        if in_preprocessor_continuation:
            in_preprocessor_continuation = raw.rstrip().endswith("\\")
        elif clean_stripped.startswith("#"):
            in_preprocessor_continuation = raw.rstrip().endswith("\\")
        else:
            in_preprocessor_continuation = False

    return reasons


def _is_register_like(token: str) -> bool:
    normalized = token.strip().upper()
    if _REG_TOKEN_RE.fullmatch(normalized):
        return True
    if normalized.isdigit():
        value = int(normalized)
        return 0 <= value <= 15
    return False


def _extract_branch_target_like(operands: List[str]) -> Optional[str]:
    if not operands:
        return None
    candidate = operands[-1].strip().rstrip(",")
    if not candidate:
        return None
    if _is_register_like(candidate):
        return None
    if "(" in candidate or ")" in candidate:
        return None
    if "=" in candidate:
        return None
    if _INT_LITERAL_RE.fullmatch(candidate):
        return None
    return candidate


def _parse_line_metadata(data: dict) -> Dict[int, dict]:
    entries = data.get("line_metadata", {})
    if not isinstance(entries, dict):
        return {}

    line_map: Dict[int, dict] = {}
    for key, value in entries.items():
        try:
            line_no = int(key)
        except (TypeError, ValueError):
            continue
        if isinstance(value, dict):
            line_map[line_no] = value
    return line_map


def _collect_block_flow_lines(data: dict) -> Set[int]:
    result: Set[int] = set()
    blocks = data.get("blocks", [])
    if not isinstance(blocks, list):
        return result
    for block in blocks:
        if not isinstance(block, dict):
            continue
        for item in iter_flow(block):
            if not isinstance(item, dict):
                continue
            line = item.get("line")
            if isinstance(line, int):
                result.add(line)
    return result


def _collect_call_lines(data: dict) -> Set[int]:
    result: Set[int] = set()
    call_graph = data.get("call_graph", {})
    if not isinstance(call_graph, dict):
        return result
    edges = call_graph.get("edges", [])
    if not isinstance(edges, list):
        return result
    for edge in edges:
        if not isinstance(edge, dict):
            continue
        line = edge.get("line")
        if isinstance(line, int):
            result.add(line)
    return result


def _collect_db_lines(data: dict) -> Set[int]:
    result: Set[int] = set()
    catalog = data.get("db_operations", {})
    if not isinstance(catalog, dict):
        return result
    operations = catalog.get("operations", [])
    if not isinstance(operations, list):
        return result
    for op in operations:
        if not isinstance(op, dict):
            continue
        line = op.get("source_line")
        if isinstance(line, int):
            result.add(line)
    return result


def _collect_lineage_lines(data: dict) -> Set[int]:
    result: Set[int] = set()
    lineage = data.get("variable_lineage", {})
    if not isinstance(lineage, dict):
        return result
    edges = lineage.get("edges", [])
    if not isinstance(edges, list):
        return result
    for edge in edges:
        if not isinstance(edge, dict):
            continue
        line = edge.get("line")
        if isinstance(line, int):
            result.add(line)
    return result


def _expected_block_lines(
    parsed_lines: Dict[int, ParsedLine],
    executable_lines: Optional[Set[int]] = None,
    macro_body_lines: Optional[Set[int]] = None,
) -> Set[int]:
    expected: Set[int] = set()
    for line_no, parsed in parsed_lines.items():
        if macro_body_lines and line_no in macro_body_lines:
            continue
        opcode = (parsed.opcode or "").upper()
        if not opcode:
            continue
        if executable_lines is not None and line_no not in executable_lines:
            continue
        if opcode in _BLOCK_SKIP_OPCODES:
            continue
        if opcode.startswith("&"):
            continue
        if "=" in opcode or opcode.endswith(",") or opcode.startswith("("):
            continue
        if opcode == "BR" and parsed.operands:
            if _is_register_like(parsed.operands[0]):
                continue
        expected.add(line_no)
    return expected


def _expected_call_lines(
    parsed_lines: Dict[int, ParsedLine],
    macro_body_lines: Optional[Set[int]] = None,
) -> Set[int]:
    classifier = InstructionClassifier()
    macro_classifier = MacroClassifier()
    expected: Set[int] = set()

    for line_no, parsed in parsed_lines.items():
        if macro_body_lines and line_no in macro_body_lines:
            continue
        opcode = (parsed.opcode or "").upper()
        if not opcode:
            continue
        if not _is_valid_asm_opcode(opcode):
            continue  # continuation-line fragment, not a real opcode

        if macro_classifier.is_macro(opcode):
            expected.add(line_no)
            continue

        flow_type = classifier.classify(opcode)
        if flow_type is None:
            continue

        operands = parsed.operands or []

        if flow_type == ControlFlowType.SUBROUTINE_CALL:
            if len(operands) >= 2:
                expected.add(line_no)
            continue
        if flow_type == ControlFlowType.MODE_TRANSITION:
            if len(operands) >= 2:
                expected.add(line_no)
            continue
        if flow_type == ControlFlowType.EXECUTE:
            if len(operands) >= 2:
                expected.add(line_no)
            continue
        if flow_type == ControlFlowType.BRANCH:
            if classifier.is_return(opcode, operands):
                expected.add(line_no)
                continue
            if _extract_branch_target_like(operands):
                expected.add(line_no)

    return expected


def _expected_db_lines(
    parsed_lines: Dict[int, ParsedLine],
    macro_body_lines: Optional[Set[int]] = None,
) -> Set[int]:
    macro_classifier = MacroClassifier()
    expected: Set[int] = set()
    for line_no, parsed in parsed_lines.items():
        if macro_body_lines and line_no in macro_body_lines:
            continue
        opcode = parsed.opcode
        if not opcode:
            continue
        if not _is_valid_asm_opcode(opcode):
            continue  # continuation-line fragment, not a real opcode
        if macro_classifier.is_db_macro(opcode):
            expected.add(line_no)
    return expected


def _expected_c_call_lines_from_unit(unit) -> Set[int]:
    expected: Set[int] = set()
    for call in unit.calls:
        if isinstance(call.line, int):
            expected.add(call.line)
    for assignment in unit.assignments:
        if assignment.call_function and isinstance(assignment.line, int):
            expected.add(assignment.line)
    return expected


def _expected_c_lineage_lines_from_unit(unit) -> Set[int]:
    expected: Set[int] = set()
    for assignment in unit.assignments:
        if isinstance(assignment.line, int):
            expected.add(assignment.line)
    for ret in unit.returns:
        if isinstance(ret.line, int):
            expected.add(ret.line)
    for call in unit.calls:
        # Lineage builder emits call-side edges primarily when arguments are
        # present (arg bindings / address-of side effects). Zero-argument
        # helper calls like `.end()` or `.c_str()` intentionally may not emit
        # lineage edges and should not be treated as coverage gaps.
        if isinstance(call.line, int) and (call.args or call.address_of_args):
            expected.add(call.line)
    return expected


def _parse_c_translation_unit(source_path: Path, source_text: str):
    language = "c" if source_path.suffix.lower() in _C_EXTS else "cpp"
    parser = CFamilyParser(language)
    return parser.parse(source_path, source_text, line_collector=None)


def _compute_macro_body_lines(parsed_lines: Dict[int, ParsedLine]) -> Set[int]:
    """Return line numbers that fall *inside* MACRO…MEND definition bodies.

    The MACRO and MEND directive lines themselves are NOT included — they are
    already excluded via ``_BLOCK_SKIP_OPCODES``.  Only the template lines
    between those directives are returned.  These lines are template code, not
    executable instructions, so they must not inflate expected-coverage counts.
    """
    body: Set[int] = set()
    in_macro = False
    for line_no in sorted(parsed_lines.keys()):
        opcode = (parsed_lines[line_no].opcode or "").upper()
        if opcode == "MACRO":
            in_macro = True
            continue  # MACRO directive itself is not a body line
        if opcode == "MEND":
            in_macro = False
            continue  # MEND directive itself is not a body line
        if in_macro:
            body.add(line_no)
    return body


def _is_valid_asm_opcode(opcode: str) -> bool:
    """Return True if *opcode* looks like a real HLASM operation mnemonic.

    Valid opcodes are 1–8 uppercase alphanumeric chars plus ``@``, ``$``, ``#``.
    Strings that contain commas, equals signs, or parentheses are continuation-line
    fragments that the tokenizer misidentified as opcodes (e.g. ``BEGIN,``,
    ``REG=R7,``, ``KEY1=(PKY=#CR21KA7)``).
    """
    return bool(_VALID_ASM_OPCODE_RE.match(opcode.upper()))


def _line_exclusion_reason(
    raw: str, parsed: ParsedLine, in_macro_body: bool = False
) -> Optional[str]:
    if in_macro_body:
        return "macro_body_line"
    stripped = raw.strip()
    if stripped == "":
        return "blank_line"
    if stripped.startswith("*") or raw.startswith(".*"):
        return "comment_line"
    if not parsed.opcode:
        return "no_opcode_content"
    opcode = parsed.opcode.upper()
    if not _is_valid_asm_opcode(opcode):
        return "continuation_line"
    if opcode in _BLOCK_SKIP_OPCODES:
        return "directive_or_declaration"
    return None


def _build_line_accounting(
    raw_lines: Dict[int, str],
    parsed_lines: Dict[int, ParsedLine],
    line_metadata_lines: Set[int],
    expected_block: Set[int],
    block_lines: Set[int],
    expected_call: Set[int],
    call_lines: Set[int],
    expected_db: Set[int],
    db_lines: Set[int],
    macro_body_lines: Optional[Set[int]] = None,
) -> Tuple[List[str], Dict[str, int], Dict[str, object]]:
    gaps: List[str] = []
    excluded_counts: Dict[str, int] = {}
    covered_lines = 0

    for line_no in sorted(raw_lines.keys()):
        raw = raw_lines[line_no]
        parsed = parsed_lines[line_no]
        in_macro_body = macro_body_lines is not None and line_no in macro_body_lines
        exclusion_reason = _line_exclusion_reason(raw, parsed, in_macro_body)
        missing_parts: List[str] = []

        # Deterministic requirement: non-excluded opcode lines must exist in line_metadata.
        if parsed.opcode and exclusion_reason is None and line_no not in line_metadata_lines:
            missing_parts.append("line_metadata")

        # Section-specific expected coverage.
        if line_no in expected_block and line_no not in block_lines:
            missing_parts.append("blocks.flow")
        if line_no in expected_call and line_no not in call_lines:
            missing_parts.append("call_graph.edges")
        if line_no in expected_db and line_no not in db_lines:
            missing_parts.append("db_operations")

        if missing_parts:
            snippet = raw.strip()[:80]
            gaps.append(
                f"line {line_no}: missing {', '.join(missing_parts)} | source='{snippet}'"
            )
            continue

        covered_lines += 1
        if exclusion_reason:
            excluded_counts[exclusion_reason] = excluded_counts.get(exclusion_reason, 0) + 1

    summary = {
        "total_lines": len(raw_lines),
        "covered_or_explained_lines": covered_lines,
        "gap_lines": len(gaps),
        "excluded_breakdown": excluded_counts,
    }
    return gaps, excluded_counts, summary


def _build_c_line_accounting(
    raw_lines: Dict[int, str],
    exclusion_map: Dict[int, Optional[str]],
    line_metadata_lines: Set[int],
    expected_call: Set[int],
    call_lines: Set[int],
    expected_lineage: Set[int],
    lineage_lines: Set[int],
) -> Tuple[List[str], Dict[str, int], Dict[str, object]]:
    gaps: List[str] = []
    excluded_counts: Dict[str, int] = {}
    covered_lines = 0

    for line_no in sorted(raw_lines.keys()):
        raw = raw_lines[line_no]
        exclusion_reason = exclusion_map.get(line_no)
        missing_parts: List[str] = []

        if exclusion_reason is None and line_no not in line_metadata_lines:
            missing_parts.append("line_metadata")
        if line_no in expected_call and line_no not in call_lines:
            missing_parts.append("call_graph.edges")
        if line_no in expected_lineage and line_no not in lineage_lines:
            missing_parts.append("variable_lineage.edges")

        if missing_parts:
            snippet = raw.strip()[:80]
            gaps.append(
                f"line {line_no}: missing {', '.join(missing_parts)} | source='{snippet}'"
            )
            continue

        covered_lines += 1
        if exclusion_reason:
            excluded_counts[exclusion_reason] = excluded_counts.get(exclusion_reason, 0) + 1

    summary = {
        "total_lines": len(raw_lines),
        "covered_or_explained_lines": covered_lines,
        "gap_lines": len(gaps),
        "excluded_breakdown": excluded_counts,
    }
    return gaps, excluded_counts, summary


def _expected_line_metadata_lines(
    raw_lines: Dict[int, str],
    parsed_lines: Dict[int, ParsedLine],
    macro_body_lines: Optional[Set[int]] = None,
) -> Set[int]:
    expected: Set[int] = set()
    for line_no, raw in raw_lines.items():
        in_macro_body = macro_body_lines is not None and line_no in macro_body_lines
        parsed = parsed_lines[line_no]
        if not parsed.opcode:
            continue
        if _line_exclusion_reason(raw, parsed, in_macro_body) is None:
            expected.add(line_no)
    return expected


def _expected_c_line_metadata_lines(
    raw_lines: Dict[int, str],
    exclusion_map: Dict[int, Optional[str]],
) -> Set[int]:
    expected: Set[int] = set()
    for line_no in raw_lines.keys():
        if exclusion_map.get(line_no) is None:
            expected.add(line_no)
    return expected


def _add_coverage_metric(
    result: ReviewResult,
    name: str,
    expected: Set[int],
    actual: Set[int],
    weight: float,
    severity: str = "warning",
) -> None:
    covered_set = expected & actual
    missing = sorted(expected - actual)
    metric = Metric(name=name, covered=len(covered_set), expected=len(expected), weight=weight)

    if missing:
        preview = ", ".join(str(x) for x in missing[:12])
        suffix = " ..." if len(missing) > 12 else ""
        message = (
            f"{name}: missing {len(missing)} line(s) from output coverage "
            f"(examples: {preview}{suffix})"
        )
        metric.notes.append(message)
        if severity == "error":
            result.errors.append(message)
        else:
            result.warnings.append(message)

    result.metrics.append(metric)


def _add_out_of_range_warnings(
    result: ReviewResult,
    source_line_numbers: Set[int],
    named_lines: List[Tuple[str, Set[int]]],
) -> None:
    for name, lines in named_lines:
        extras = sorted(lines - source_line_numbers)
        if extras:
            preview = ", ".join(str(x) for x in extras[:12])
            suffix = " ..." if len(extras) > 12 else ""
            result.warnings.append(
                f"{name}: contains {len(extras)} line(s) outside source file range "
                f"(examples: {preview}{suffix})"
            )


def _empty_line_summary() -> Dict[str, object]:
    return {
        "total_lines": 0,
        "covered_or_explained_lines": 0,
        "gap_lines": 0,
        "excluded_breakdown": {},
    }


def _run_asm_coverage(result: ReviewResult, data: dict, source_path: Path) -> None:
    raw_lines, parsed_lines = _tokenize_source(source_path)
    source_line_numbers = set(parsed_lines.keys())

    # Compute macro body lines once and share across all expected-coverage helpers.
    macro_body_lines = _compute_macro_body_lines(parsed_lines)

    expected_line_metadata = _expected_line_metadata_lines(
        raw_lines, parsed_lines, macro_body_lines
    )

    line_metadata_map = _parse_line_metadata(data)
    line_metadata_lines = set(line_metadata_map.keys())
    executable_lines = {
        ln
        for ln, entry in line_metadata_map.items()
        if isinstance(entry.get("codeblock"), dict)
        and entry["codeblock"].get("in_executable_block") is True
    }

    block_lines = _collect_block_flow_lines(data)
    call_lines = _collect_call_lines(data)
    db_lines = _collect_db_lines(data)
    lineage_lines = _collect_lineage_lines(data)

    _add_out_of_range_warnings(
        result,
        source_line_numbers,
        [
            ("line_metadata", line_metadata_lines),
            ("blocks.flow", block_lines),
            ("call_graph.edges", call_lines),
            ("db_operations", db_lines),
            ("variable_lineage.edges", lineage_lines),
        ],
    )

    _add_coverage_metric(
        result,
        name="line_metadata_coverage",
        expected=expected_line_metadata,
        actual=line_metadata_lines,
        weight=35.0,
        severity="error",
    )

    expected_block = _expected_block_lines(
        parsed_lines,
        executable_lines=executable_lines if line_metadata_map else None,
        macro_body_lines=macro_body_lines,
    )
    _add_coverage_metric(
        result,
        name="block_flow_coverage",
        expected=expected_block,
        actual=block_lines,
        weight=25.0,
        severity="error",
    )

    expected_call = _expected_call_lines(parsed_lines, macro_body_lines=macro_body_lines)
    _add_coverage_metric(
        result,
        name="call_graph_coverage",
        expected=expected_call,
        actual=call_lines,
        weight=20.0,
        severity="warning",
    )

    expected_db = _expected_db_lines(parsed_lines, macro_body_lines=macro_body_lines)
    _add_coverage_metric(
        result,
        name="db_operation_coverage",
        expected=expected_db,
        actual=db_lines,
        weight=10.0,
        severity="error",
    )

    line_gaps, _, line_summary = _build_line_accounting(
        raw_lines=raw_lines,
        parsed_lines=parsed_lines,
        line_metadata_lines=line_metadata_lines,
        expected_block=expected_block,
        block_lines=block_lines,
        expected_call=expected_call,
        call_lines=call_lines,
        expected_db=expected_db,
        db_lines=db_lines,
        macro_body_lines=macro_body_lines,
    )
    result.line_audit_summary = line_summary
    if line_gaps:
        preview = line_gaps[:15]
        result.warnings.extend(preview)
        if len(line_gaps) > len(preview):
            result.warnings.append(
                f"... {len(line_gaps) - len(preview)} more uncovered line(s) omitted."
            )

    _add_coverage_metric(
        result,
        name="variable_lineage_flow_overlap",
        expected=block_lines,
        actual=lineage_lines,
        weight=10.0,
        severity="warning",
    )


def _run_c_family_coverage(result: ReviewResult, data: dict, source_path: Path) -> None:
    raw_lines, clean_lines, source_text = _read_c_source_lines(source_path)
    exclusion_map = _c_line_exclusion_map(raw_lines, clean_lines)
    source_line_numbers = set(raw_lines.keys())
    unit = _parse_c_translation_unit(source_path, source_text)

    line_metadata_map = _parse_line_metadata(data)
    line_metadata_lines = set(line_metadata_map.keys())
    call_lines = _collect_call_lines(data)
    lineage_lines = _collect_lineage_lines(data)

    _add_out_of_range_warnings(
        result,
        source_line_numbers,
        [
            ("line_metadata", line_metadata_lines),
            ("call_graph.edges", call_lines),
            ("variable_lineage.edges", lineage_lines),
        ],
    )

    expected_line_metadata = _expected_c_line_metadata_lines(raw_lines, exclusion_map)
    expected_call = _expected_c_call_lines_from_unit(unit)
    expected_lineage = _expected_c_lineage_lines_from_unit(unit)

    _add_coverage_metric(
        result,
        name="line_metadata_coverage",
        expected=expected_line_metadata,
        actual=line_metadata_lines,
        weight=50.0,
        severity="error",
    )

    _add_coverage_metric(
        result,
        name="call_graph_coverage",
        expected=expected_call,
        actual=call_lines,
        weight=25.0,
        severity="warning",
    )

    _add_coverage_metric(
        result,
        name="variable_lineage_coverage",
        expected=expected_lineage,
        actual=lineage_lines,
        weight=25.0,
        severity="warning",
    )

    line_gaps, _, line_summary = _build_c_line_accounting(
        raw_lines=raw_lines,
        exclusion_map=exclusion_map,
        line_metadata_lines=line_metadata_lines,
        expected_call=expected_call,
        call_lines=call_lines,
        expected_lineage=expected_lineage,
        lineage_lines=lineage_lines,
    )
    result.line_audit_summary = line_summary
    if line_gaps:
        preview = line_gaps[:15]
        result.warnings.extend(preview)
        if len(line_gaps) > len(preview):
            result.warnings.append(
                f"... {len(line_gaps) - len(preview)} more uncovered line(s) omitted."
            )


def review(json_path: Path, source_path: Optional[Path]) -> ReviewResult:
    result = ReviewResult(filename=json_path.name)

    try:
        # skip_global_lineage=True: the reviewer checks per-file coverage and
        # has no need for the global variable lineage graph.  Loading it would
        # read a 5+ GB JSON file from disk and cache it in Python heap,
        # immediately triggering OOM in the emission worker.
        data = load_blueprint(json_path, skip_global_lineage=True)
    except Exception as exc:
        result.errors.append(f"Cannot parse blueprint: {exc}")
        return result

    missing_top = [k for k in REQUIRED_TOP_LEVEL_KEYS if k not in data]
    if missing_top:
        result.errors.append(f"Missing top-level key(s): {', '.join(missing_top)}")

    source_kind = _detect_source_kind(source_path)
    block_validation = validate_blocks(
        json_path,
        source_path if source_kind == "asm" else None,
    )
    result.errors.extend(block_validation.errors)
    result.warnings.extend(block_validation.warnings)

    if source_path and source_path.exists():
        if source_kind == "asm":
            _run_asm_coverage(result, data, source_path)
        elif source_kind == "c_family":
            _run_c_family_coverage(result, data, source_path)
        else:
            result.warnings.append(
                f"Unsupported source type for coverage review: {source_path.suffix or '<no-extension>'}"
            )
            result.line_audit_summary = _empty_line_summary()
    else:
        result.warnings.append("No source provided; source-coverage checks skipped.")
        result.line_audit_summary = _empty_line_summary()

    macro_errors = data.get("macro_errors", [])
    if isinstance(macro_errors, list) and macro_errors:
        result.warnings.append(f"macro_errors: {len(macro_errors)} error(s) present in output.")

    if result.metrics:
        earned = sum(m.points for m in result.metrics)
        total = sum(m.weight for m in result.metrics)
        result.score = 100.0 * (earned / total) if total else 100.0
    else:
        result.score = 100.0 if not result.errors else 0.0

    return result


def _coverage_payload(result: ReviewResult) -> Dict[str, object]:
    return {
        "ok": result.ok,
        "score": round(result.score, 2),
        "errors": result.errors,
        "warnings": result.warnings,
        "line_audit": result.line_audit_summary,
        "metrics": [
            {
                "name": metric.name,
                "covered": metric.covered,
                "expected": metric.expected,
                "ratio": round(metric.ratio, 6),
                "weight": metric.weight,
                "points": round(metric.points, 6),
            }
            for metric in result.metrics
        ],
    }


def _resolve_inputs(
    json_input: Path,
    source_input: Optional[Path],
) -> List[Tuple[Path, Optional[Path]]]:
    if json_input.is_dir():
        json_files = sorted(json_input.glob("**/*.json"))
    else:
        json_files = [json_input]

    resolved: List[Tuple[Path, Optional[Path]]] = []
    for json_file in json_files:
        source_path = None
        if source_input:
            if source_input.is_file():
                source_path = source_input
            elif source_input.is_dir():
                source_candidate = source_input / json_file.stem
                if source_candidate.exists():
                    source_path = source_candidate
        resolved.append((json_file, source_path))
    return resolved


def _append_coverage_to_json(
    targets: List[Tuple[Path, Optional[Path]]],
    results: List[ReviewResult],
) -> None:
    for (json_path, _), result in zip(targets, results):
        try:
            data = load_blueprint(json_path, skip_global_lineage=True)
            if not isinstance(data, dict):
                continue
            data["coverage_review"] = _coverage_payload(result)
            write_blueprint(json_path, data)
        except Exception:
            # Keep review reporting deterministic; append is best effort.
            continue


def _print_report(results: List[ReviewResult]) -> int:
    total_errors = sum(len(r.errors) for r in results)
    total_warnings = sum(len(r.warnings) for r in results)
    passed = sum(1 for r in results if r.ok)

    print("=" * 78)
    print(f"PARSER OUTPUT COMPLETENESS REVIEW ({len(results)} file(s))")
    print("=" * 78)

    for r in results:
        status = "PASS" if r.ok else "FAIL"
        print(f"\n[{status}] {r.filename} | score={r.score:.1f}%")

        for metric in r.metrics:
            print(
                f"  METRIC: {metric.name:30s} "
                f"{metric.covered:4d}/{metric.expected:<4d} "
                f"({metric.ratio * 100:5.1f}%)"
            )

        line_total = int(r.line_audit_summary.get("total_lines", 0))
        line_covered = int(r.line_audit_summary.get("covered_or_explained_lines", 0))
        line_gaps = int(r.line_audit_summary.get("gap_lines", 0))
        print(
            f"  LINE_AUDIT: covered/explained {line_covered}/{line_total} | "
            f"gaps={line_gaps}"
        )
        excluded_breakdown = r.line_audit_summary.get("excluded_breakdown", {})
        if isinstance(excluded_breakdown, dict) and excluded_breakdown:
            ordered = ", ".join(
                f"{k}={v}" for k, v in sorted(excluded_breakdown.items())
            )
            print(f"  EXCLUDED: {ordered}")

        if r.errors:
            for err in r.errors:
                print(f"  ERROR:   {err}")
        if r.warnings:
            for warn in r.warnings:
                print(f"  WARNING: {warn}")
        if r.ok and not r.warnings:
            print("  All checks passed.")

    print()
    print("=" * 78)
    print(
        f"SUMMARY: {len(results)} file(s) | {passed}/{len(results)} passed | "
        f"{total_errors} error(s) | {total_warnings} warning(s)"
    )
    print("=" * 78)

    return 0 if total_errors == 0 else 1


def main(argv: Optional[Iterable[str]] = None) -> int:
    raw_args = list(argv if argv is not None else sys.argv[1:])
    append_mode = False
    args: List[str] = []
    for arg in raw_args:
        if arg == "--append":
            append_mode = True
        else:
            args.append(arg)

    if not args:
        print(__doc__)
        return 1

    json_input = Path(args[0])
    source_input = Path(args[1]) if len(args) > 1 else None

    targets = _resolve_inputs(json_input, source_input)
    results = [review(json_path, source_path) for json_path, source_path in targets]
    if append_mode:
        _append_coverage_to_json(targets, results)
    return _print_report(results)


if __name__ == "__main__":
    sys.exit(main())
