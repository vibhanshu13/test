"""Regression guard for the variable-graph feature.

Confirms the change set is strictly additive:
  - git diff is limited to the planned files (no surprise edits)
  - the existing /v1/jobs/{id}/processes/{p}/lineage/chunks endpoint is still
    advertised in the OpenAPI schema with the same shape
  - the variable_graph route adds (not replaces) endpoints

Usage:
  python tools/regression_check.py [--base origin/main]
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Set

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

ALLOWLIST_PREFIXES = {
    # New files introduced by the variable-graph feature
    "backward_traversal/graph_extraction/__init__.py",
    "backward_traversal/graph_extraction/variable_graph_builder.py",
    "api/schemas/variable_graph.py",
    "api/tasks/variable_graph_task.py",
    "api/routes/variable_graph.py",
    "tests/test_variable_graph_builder.py",
    "tests/test_variable_graph_route.py",
    "tools/validator_auth.sh",
    "tools/validate_variable_graph.py",
    "tools/validate_variable_graph_live.sh",
    "tools/regression_check.py",
    "docs/APIs/process-variable-graph/",
    # Allowed minimal mods
    "api/app.py",
    "api/tasks/celery_app.py",  # one-line addition to the include[] list
}

EXISTING_ENDPOINTS_THAT_MUST_STAY = (
    "/v1/jobs/{job_id}/processes/{process_name}/lineage/chunks",
    "/v1/jobs/{job_id}/processes",
    "/v1/auth/register",
    "/v1/auth/login",
    "/v1/health",
)


def _git_changed(base: str) -> Set[str]:
    out = subprocess.check_output(
        ["git", "diff", "--name-only", f"{base}...HEAD"],
        cwd=PROJECT_ROOT,
    ).decode().splitlines()
    return {line.strip() for line in out if line.strip()}


def _check_allowlist(base: str) -> bool:
    try:
        files = _git_changed(base)
    except subprocess.CalledProcessError as exc:
        print(f"WARN: git diff failed ({exc}); skipping allowlist check")
        return True
    if not files:
        print("INFO: no files changed vs", base)
        return True

    print(f"INFO: {len(files)} files changed vs {base}")
    offenders = []
    for f in sorted(files):
        if any(f == p or f.startswith(p) for p in ALLOWLIST_PREFIXES):
            print(f"  ALLOW · {f}")
        else:
            offenders.append(f)
            print(f"  DENY  · {f}")
    if offenders:
        print(f"\nFAIL: {len(offenders)} file(s) outside the variable-graph allow-list")
        return False
    return True


def _check_existing_endpoints_present() -> bool:
    from api.app import app
    schema = app.openapi()
    paths = set((schema.get("paths") or {}).keys())
    missing = [p for p in EXISTING_ENDPOINTS_THAT_MUST_STAY if p not in paths]
    if missing:
        print(f"FAIL: existing endpoints disappeared: {missing}")
        return False
    print(f"OK: all {len(EXISTING_ENDPOINTS_THAT_MUST_STAY)} sentinel endpoints still present")
    return True


def _check_variable_graph_added() -> bool:
    from api.app import app
    schema = app.openapi()
    paths = (schema.get("paths") or {})
    target = "/v1/jobs/{job_id}/processes/{process_name}/variable-graph"
    if target not in paths:
        print(f"FAIL: {target} not in OpenAPI")
        return False
    methods = set((paths[target] or {}).keys())
    if not {"post", "get"} <= methods:
        print(f"FAIL: {target} missing methods (have: {methods})")
        return False
    print(f"OK: {target} present with POST+GET")
    return True


def _check_task_names_no_collision() -> bool:
    from api.tasks.celery_app import celery_app
    # Explicitly import task modules so their @celery_app.task decorators run.
    # In production these are loaded by the Celery worker bootstrap.
    import importlib
    for mod in (
        "api.tasks.variable_graph_task",
        "api.tasks.process_lineage_chunked_task",
        "api.tasks.kb_backward_lineage_chunked_task",
    ):
        try:
            importlib.import_module(mod)
        except Exception as exc:
            print(f"WARN: could not import {mod}: {exc}")
    names = set(celery_app.tasks.keys())
    if "asm.variable_graph" not in names:
        print("FAIL: asm.variable_graph task not registered")
        return False
    sentinels = {"asm.process_lineage_chunked", "asm.kb_backward_lineage_chunked"}
    missing = sentinels - names
    if missing:
        print(f"FAIL: existing tasks missing: {missing}")
        return False
    print(f"OK: variable_graph task registered + no existing task names removed")
    return True


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--base", default="origin/main", help="git ref to diff against")
    ap.add_argument("--skip-git", action="store_true")
    args = ap.parse_args()

    ok = True
    if not args.skip_git:
        ok = _check_allowlist(args.base) and ok
    ok = _check_existing_endpoints_present() and ok
    ok = _check_variable_graph_added() and ok
    ok = _check_task_names_no_collision() and ok

    if not ok:
        print("\nREGRESSION CHECK FAILED")
        return 1
    print("\nREGRESSION CHECK PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
