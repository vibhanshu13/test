#!/usr/bin/env python3
"""Patch temp/asm/ paths in process file_graph.json files for an existing KB.

Usage:
    python tools/patch_process_file_graph.py <job_id>
    python tools/patch_process_file_graph.py <job_id> --source-path /path/to/asm
"""

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parents[1]
sys.path.insert(0, str(PROJECT_ROOT))


def main() -> None:
    parser = argparse.ArgumentParser(description="Patch process file_graph.json paths for a KB.")
    parser.add_argument("job_id", help="KB / job ID to patch")
    parser.add_argument("--source-path", help="Override source path (auto-detected if omitted)")
    args = parser.parse_args()

    from api.tasks.process_seeds import _patch_file_graph_paths, _patch_headers_paths, _resolve_actual_source_path
    from api.storage.workspace import WorkspaceManager

    ws = WorkspaceManager(args.job_id)
    processes_dir = ws.output_dir / "processes"

    if not processes_dir.exists():
        print(f"ERROR: No processes directory found: {processes_dir}")
        sys.exit(1)

    if args.source_path:
        actual_source_path = args.source_path.rstrip("/")
        print(f"Using provided source path: {actual_source_path}")
    else:
        actual_source_path = _resolve_actual_source_path(ws)
        if not actual_source_path:
            print("ERROR: Could not auto-detect source path. Use --source-path.")
            sys.exit(1)
        print(f"Auto-detected source path: {actual_source_path}")

    patched = 0
    skipped = 0
    for process_dir in sorted(processes_dir.iterdir()):
        if not process_dir.is_dir():
            continue
        fg = process_dir / "file_graph.json"
        if not fg.exists():
            print(f"  [{process_dir.name}] SKIP — file_graph.json missing")
            skipped += 1
            continue

        import json

        fg_before = json.loads(fg.read_text(encoding="utf-8")).get("seed_file", "")
        _patch_file_graph_paths(fg, actual_source_path)
        fg_after = json.loads(fg.read_text(encoding="utf-8")).get("seed_file", "")

        hdr = process_dir / "headers.json"
        hdr_before = hdr_after = ""
        if hdr.exists():
            found = (json.loads(hdr.read_text(encoding="utf-8")).get("headers_found") or [])
            hdr_before = found[0].get("resolved_path", "") if found else ""
            _patch_headers_paths(hdr, actual_source_path)
            found = (json.loads(hdr.read_text(encoding="utf-8")).get("headers_found") or [])
            hdr_after = found[0].get("resolved_path", "") if found else ""

        changed = (fg_before != fg_after) or (hdr_before != hdr_after)
        if changed:
            print(f"  [{process_dir.name}] PATCHED")
            if fg_before != fg_after:
                print(f"    file_graph: {fg_before} → {fg_after}")
            if hdr_before != hdr_after:
                print(f"    headers:    {hdr_before} → {hdr_after}")
            patched += 1
        else:
            print(f"  [{process_dir.name}] already correct — no change")
            skipped += 1

    print(f"\nDone. {patched} patched, {skipped} skipped.")


if __name__ == "__main__":
    main()
