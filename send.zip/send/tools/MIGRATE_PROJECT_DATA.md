# `migrate_project_data.py` — Moving Projects Between Repo Checkouts

This tool moves ASM Modernizer projects (auth users, knowledge bases, the
processed `jobs/<uuid>/` artifacts, and the `datasource/` source trees
they point at) from one checkout of `asm-modernizer` to another.

It exists because three pieces of state must travel together for a project
to be accessible end-to-end:

| Piece | Where it lives | What breaks if missing |
|---|---|---|
| `users.db` (SQLite) | repo root | Login fails; project list is empty |
| `datasource/<user>/<asm_version_X>/` | repo root | Variable-lineage / source-file lookups silently no-op |
| `jobs/<uuid>/` | repo root | API returns "no output files" |
| Redis `job:<uuid>` + `jobs:by_time` ZSET | local Redis (DB 0) | API returns **404** when opening the project |

The script handles all four and rewrites the absolute paths in `users.db`
so the destination doesn't try to read from the source repo's filesystem.

---

## What gets copied

For each selected knowledge base (`kb_id` == `job_id` in this codebase):

1. **`users.db`** — copied wholesale to the destination. Any pre-existing
   `users.db` at the destination is backed up to `users.db.bak.<ts>`.
2. **`jobs/<kb_id>/`** — full subtree (`input/`, `output/`, `cache/`,
   `processes/`, `job.log`) copied to `<dst>/jobs/<kb_id>/`.
3. **`datasource/<user>/<asm_version_X>/`** — derived from the row's
   `source_path` column. Only copied when `source_path` lives under
   the source repo's `datasource/` tree (legacy rows with `/tmp/...`
   `source_path` values are left alone).
4. **Path rewrite** — every `knowledge_bases.source_path` value in the
   destination `users.db` that started with the source repo prefix is
   updated to point at the destination repo prefix.
5. **Orphan prune (optional)** — with `--prune-orphans`, any KB row
   whose data wasn't migrated is deleted from the destination `users.db`,
   along with its `knowledge_base_access` rows. `file_summaries` rows
   cascade automatically via `ON DELETE CASCADE`.
6. **Redis seed (optional)** — with `--seed-redis`, a synthesized
   `status=success` meta is written to the destination Redis for every
   migrated `kb_id`, plus an entry in the `jobs:by_time` ZSET. This is
   what `get_job_or_404` and the rest of the API rely on.

---

## Prerequisites

- Python 3.9+
- For `--seed-redis`: the `redis` Python package (`pip install redis`)
  and a reachable Redis on the destination host.
- The destination must be a clone/checkout of `asm-modernizer` (or at
  least have a `jobs/`, `datasource/`, and an existing or absent
  `users.db` at its root). The script does not run any app code, so the
  destination's Python deps don't have to be installed for the copy
  itself.

---

## Usage

### Dry run (recommended first)

```bash
python tools/migrate_project_data.py \
    --src /Users/me/Documents/asm-modernizer \
    --dst /Users/me/Documents/asm-modernizer-clone \
    --all \
    --dry-run
```

Prints exactly what would be copied, rewritten, and (if `--seed-redis`)
seeded, without touching anything.

### Migrate a specific project

```bash
python tools/migrate_project_data.py \
    --src /Users/me/Documents/asm-modernizer \
    --dst /Users/me/Documents/asm-modernizer-clone \
    --kb-id 07464797-8cc0-41c1-a52b-170eba03e111
```

Repeat `--kb-id <uuid>` for multiple. Datasource folders are auto-resolved
from each row's `source_path`.

### Migrate everything that has data on disk

```bash
python tools/migrate_project_data.py \
    --src ... --dst ... --all
```

Any KB row in `users.db` whose `jobs/<uuid>/` folder or `source_path`
doesn't exist is skipped with a reason printed to stdout.

### Full migration including Redis (destination becomes self-sufficient)

```bash
python tools/migrate_project_data.py \
    --src ... --dst ... --all \
    --prune-orphans \
    --seed-redis \
    --dst-redis-url redis://localhost:6379 \
    --dst-redis-db 0
```

This is the form you want when the destination is a fresh checkout with
no existing data: users.db is replaced, orphan rows are dropped, Redis is
populated. After this you can `uvicorn api.app:app` on the destination
and projects will be visible immediately.

---

## CLI reference

| Flag | Required | Default | Notes |
|---|---|---|---|
| `--src` | yes | — | Source repo root |
| `--dst` | yes | — | Destination repo root |
| `--kb-id <uuid>` | one of | — | Repeatable. Pick specific projects. |
| `--all` | one of | — | Migrate every KB whose data is on disk. |
| `--prune-orphans` | no | off | Delete destination KB rows whose data wasn't migrated. |
| `--seed-redis` | no | off | Write Redis meta + ZSET so the API serves the project. |
| `--dst-redis-url` | no | `redis://localhost:6379` | Destination Redis. |
| `--dst-redis-db` | no | `0` | Matches `REDIS_METADATA_DB`. |
| `--job-ttl-seconds` | no | `2592000` (30d) | TTL applied to seeded `job:<uuid>` keys. |
| `--dry-run` | no | off | Plan only, no copy / no DB changes. |

Either `--all` or at least one `--kb-id` is required.

---

## What the script does NOT touch

- **Celery broker / result backend** keys in Redis DB 0 — these are
  ephemeral, only relevant during an in-flight run. A finished project
  doesn't need them.
- **`cache/emission_manifest.json` paths inside job folders** — the agent
  treats this file as build output regenerated by `WorkspaceManager` at
  job runtime, so we don't rewrite it.
- **Output JSON file contents** — analysis outputs reference symbols by
  short name (not absolute path), so they remain valid after the move.
- **`.env`, `nginx/`, `docker-compose.yml`** — destination's own
  deployment config; copy these manually if you want identical infra.
- **Source `users.db`, `jobs/`, `datasource/`** — never modified. The
  script is a copy, not a move.

---

## Idempotency & re-runs

- Re-running the script on the same destination is safe: existing
  `jobs/<uuid>/` and `datasource/<…>` directories are left as-is
  ("exists, leaving as-is" log line). Use `rm -rf` if you want a clean
  re-copy.
- The destination `users.db` is overwritten on each run (after a
  timestamped backup), so the path-rewrite step is always against fresh
  rows.
- Re-seeding Redis simply overwrites the existing `job:<uuid>` keys and
  re-adds them to the ZSET. Safe to run repeatedly.

---

## Recovery / rollback

After a run you'll see at the destination:

- `users.db` — newly copied. If you need the previous version,
  `users.db.bak.<timestamp>` sits next to it.
- New folders under `jobs/` and `datasource/`. Remove them with
  `rm -rf <dst>/jobs/<uuid>` to undo a single project.
- Redis seed: `redis-cli -n 0 DEL job:<uuid>; ZREM jobs:by_time <uuid>`
  removes a single project's metadata.

---

## Verifying a migration

1. Start the destination API: `uvicorn api.app:app --port 8000`.
2. Log in with one of the users from the source `users.db`
   (passwords come along — they're hashed in the `users` table).
3. Hit `GET /v1/knowledge-bases` — the project should appear.
4. Hit `GET /v1/jobs/<uuid>` — should return the seeded `success`
   metadata (404 here means `--seed-redis` wasn't used or the wrong
   Redis was targeted).
5. Hit `GET /v1/knowledge-bases/<uuid>/files` — should list the output
   files copied under `jobs/<uuid>/output/`.

---

## Internals: why each step

| Step | Why it's necessary |
|---|---|
| Copy `users.db` | `knowledge_bases`, `users`, `knowledge_base_access`, and `file_summaries` are all keyed inside this single SQLite file. |
| Copy `jobs/<uuid>/` | `WorkspaceManager` resolves paths off `settings.JOBS_BASE_DIR` (which is `<repo>/jobs/` by construction in `api/config.py`), so the folder must literally exist under the destination repo. |
| Copy `datasource/<…>` | `KB.source_path` is read by `api/tasks/kb_backward_lineage_task.py` and friends; they `.exists()`-check it and silently skip if absent. |
| Rewrite `source_path` | The stored path is the **absolute** path of the source repo's datasource; the destination's filesystem doesn't have that path unless we copied a sibling at the same location. |
| Prune orphans | A KB row whose data wasn't copied is still listed in the UI and 404s on open. |
| Seed Redis | `get_job_or_404` reads `job:<uuid>` directly from Redis. Without it, every project page returns 404 even though the on-disk artifacts are present. |
