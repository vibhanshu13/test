#!/usr/bin/env python3
"""Generate variable_hop_index.json for the Pi explainability module.

Scans ASM source files for occurrences of named variables, recording the
correct line number, instruction mnemonic, and inline comment as the
description.  Eliminates the need to manually curate the hop index and
ensures line numbers are always consistent with the actual source files.

Usage
-----
    python3 tools/build_hop_index.py <asm_dir> <var1> [<var2> ...] [--output PATH]

Examples
--------
    python3 tools/build_hop_index.py temp/asm_7 INPDAT1 R4
    python3 tools/build_hop_index.py temp/asm_7 INPDAT1 --output output/variable_hop_index.json

Variable matching rules
-----------------------
- Ordinary variables (e.g. INPDAT1): matched as a whole word in the operand
  field — surrounded by non-alphanumeric characters (commas, spaces, parens).
- Registers (e.g. R4, R15): matched only as a *destination* register, i.e.
  the first operand of an instruction, to avoid noise from base/index register
  use (``L R5,WB1ACCTC(,R4)`` does NOT count as a R4 write).
- ENTRC targets (e.g. UA88): matched when the instruction is ``ENTRC`` and
  the operand starts with the given name, representing a cross-module call.

next_hop
--------
Within the same file, for each "write" occurrence of a variable the closest
following "read" occurrence is attached as ``next_hop``.  Cross-file hops
(e.g. ENTRC targets) are attached with line=1 pointing to the called module.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# ASM categories used to classify occurrences as writes or reads
# ---------------------------------------------------------------------------

_WRITE_OPS = frozenset({
    # Immediate stores / bit-sets
    "MVI", "MVC", "MVCL", "OI", "NI", "XI",
    # Register loads (destination is the register)
    "L", "LH", "LR", "LA", "LM", "LGHI", "LHI",
    # Store to memory
    "ST", "STH", "STM",
    # Arithmetic writes
    "AR", "AH", "SR", "SH", "MR", "DR",
    "A", "S", "M", "D",
    # Pack / unpack (destination)
    "PACK", "UNPK", "CVB", "CVD",
    # Move numeric / string
    "MVN", "MVZ",
    # Shift
    "SLL", "SRL", "SLA", "SRA", "SLDL", "SRDL",
    # Cross-module call (treats the target module context as "written")
    "ENTRC", "BALR", "BAL", "CALL",
})

_READ_OPS = frozenset({
    "TM", "CLI", "CLC", "CLM", "CL", "C", "CH",
    "BM", "BE", "BNE", "BNZ", "BZ", "BNM", "BP", "BNP",
    "BC", "BCR",
    "EX",
    "ICM",
})

# Trailing record-ID suffixes like "R003", "SES-R007" appended by some
# HLASM editors — strip them from comments used as ``details``.
_RECID_TRAILING_RE = re.compile(r'\s+(?:SES-)?[A-Z]?\d{3,}\s*$')
# Pattern that matches when the ENTIRE comment is a record ID (no other text).
_RECID_WHOLE_RE    = re.compile(r'^\s*(?:SES-)?[A-Z]?\d{3,}\s*$')

# Register name pattern: R0–R15
_REG_RE = re.compile(r'^R(?:1[0-5]|[0-9])$')

# Splits operand text into uppercase identifier tokens.
# Delimiters: anything that is NOT a letter, digit, @, #, $, or _.
_TOKEN_SPLIT_RE = re.compile(r'[^A-Z0-9@#$_]+')

# ---------------------------------------------------------------------------
# Line parser
# ---------------------------------------------------------------------------

def _parse_line(raw: str) -> Optional[Dict[str, str]]:
    """Parse one ASM source line.

    Returns a dict with keys ``label``, ``mnemonic``, ``operands``, ``comment``
    or ``None`` if the line is a comment, blank, or cannot be parsed.
    """
    # Comment lines start with * in column 1 (or after whitespace for DS/DC notes)
    stripped = raw.rstrip()
    if not stripped:
        return None
    if stripped.lstrip().startswith('*'):
        return None
    # Continuation columns (col 72+) — treat as unparseable for simplicity
    # (continuations are uncommon for the kinds of instructions we track)

    # Tokenise: optional label, then mnemonic, then operands, then comment.
    # IBM HLASM uses at least 2 spaces to separate operands from comment.
    # Pattern: <ws><MNEM><ws><OPERANDS><2+ws><COMMENT>
    #      or: <LABEL><ws><MNEM><ws><OPERANDS><2+ws><COMMENT>
    m = re.match(
        r'^(?P<label>[A-Z@#$][A-Z0-9@#$]*)?\s+'
        r'(?P<mnemonic>[A-Z][A-Z0-9]*)\s+'
        r'(?P<operands>[^\s].*?)'
        r'(?:\s{2,}(?P<comment>.+?))?\s*$',
        stripped,
    )
    if not m:
        return None

    comment = m.group('comment') or ''
    # Remove trailing record IDs.
    # If the entire comment is a record ID, return '' so the caller falls
    # back to the instruction expression as the details value.
    if _RECID_WHOLE_RE.match(comment):
        comment = ''
    else:
        comment = _RECID_TRAILING_RE.sub('', comment).strip()

    return {
        'label':    m.group('label') or '',
        'mnemonic': m.group('mnemonic'),
        'operands': m.group('operands').strip(),
        'comment':  comment,
    }


# ---------------------------------------------------------------------------
# Variable matching helpers
# ---------------------------------------------------------------------------

def _is_register(name: str) -> bool:
    return bool(_REG_RE.match(name.upper()))


def _first_operand(operands: str) -> str:
    """Return the first comma-separated operand token (upper-cased)."""
    return operands.split(',')[0].strip().upper()


def _classify_op(mnemonic: str) -> str:
    """Return 'write', 'read', or 'other'."""
    m = mnemonic.upper()
    if m in _WRITE_OPS:
        return 'write'
    if m in _READ_OPS:
        return 'read'
    return 'other'


def _operand_tokens(operands: str) -> frozenset:
    """Split operand text into a frozen set of uppercase identifier tokens.

    Uses a pre-compiled regex to split on any non-identifier character so
    this runs in O(len(operands)) regardless of how many variables are tracked.
    Returned as a frozenset for O(1) membership tests.
    """
    return frozenset(t for t in _TOKEN_SPLIT_RE.split(operands.upper()) if t)


# ---------------------------------------------------------------------------
# Per-file scan  (O(lines × tokens) not O(lines × variables × regex))
# ---------------------------------------------------------------------------

def _scan_file(
    asm_path: Path,
    variables: List[str],
) -> List[Dict[str, Any]]:
    """Scan one ASM source file, returning hop records for all tracked vars.

    Performance design
    ------------------
    Variables are pre-partitioned into three disjoint buckets:

    ``reg_set``     R0–R15 registers — matched only as the destination (first
                    operand) of an instruction, not as base/index in
                    displacement expressions such as ``FIELD(,R4)``.

    ``entrc_set``   Module names tracked via ENTRC calls.  Only tested when
                    the instruction is ENTRC.

    ``var_set``     All other (memory) variables.  The operand text is
                    tokenised *once* per line with a pre-compiled regex; the
                    resulting frozenset is intersected with ``var_set`` in a
                    single O(min(|var_set|, |tokens|)) operation.

    This makes per-line cost O(tokens) ≈ O(5–15) rather than
    O(variables × regex) ≈ O(1356 × re.search).
    """
    # ── Pre-partition variables (done once per file, not per line) ───────────
    reg_map:   Dict[str, str] = {}  # upper → original  for registers
    entrc_map: Dict[str, str] = {}  # upper → original  for ENTRC targets
    var_map:   Dict[str, str] = {}  # upper → original  for memory variables

    for v in variables:
        u = v.upper()
        if _is_register(v):
            reg_map[u] = v
        else:
            var_map[u] = v
            # Also track as potential ENTRC target (module names are uppercase symbols)
            entrc_map[u] = v

    reg_set   = frozenset(reg_map)
    entrc_set = frozenset(entrc_map)
    var_set   = frozenset(var_map)

    try:
        src_lines = asm_path.read_text(encoding='utf-8', errors='replace').splitlines()
    except Exception as exc:
        print(f'WARNING: Cannot read {asm_path}: {exc}', file=sys.stderr)
        return []

    records: List[Dict[str, Any]] = []
    file_str = str(asm_path)

    for lineno, raw in enumerate(src_lines, start=1):
        parsed = _parse_line(raw)
        if parsed is None:
            continue

        mnemonic  = parsed['mnemonic']
        operands  = parsed['operands']
        comment   = parsed['comment']
        op_class  = _classify_op(mnemonic)

        # ── ENTRC: cross-module call ─────────────────────────────────────────
        if mnemonic == 'ENTRC' and entrc_set:
            op_upper = operands.strip().upper()
            for eu in entrc_set:
                if op_upper.startswith(eu):
                    var = entrc_map[eu]
                    details = comment or f"Cross-module call to {operands.strip()}"
                    records.append({
                        'variable':   var,
                        'file':       file_str,
                        'line':       lineno,
                        'operation':  mnemonic,
                        'expression': f"{mnemonic} {operands}",
                        'details':    details,
                        '_op_class':  op_class,
                    })
            continue  # ENTRC operand is never a memory variable

        # ── Registers: destination-only match ───────────────────────────────
        if reg_set:
            first_op = _first_operand(operands)
            if first_op in reg_set:
                var = reg_map[first_op]
                details = comment or f"{mnemonic} {operands}"
                records.append({
                    'variable':   var,
                    'file':       file_str,
                    'line':       lineno,
                    'operation':  mnemonic,
                    'expression': f"{mnemonic} {operands}",
                    'details':    details,
                    '_op_class':  op_class,
                })

        # ── Memory variables: tokenise once, intersect ───────────────────────
        if var_set:
            tokens  = _operand_tokens(operands)
            matched = var_set & tokens          # O(min(|var_set|, |tokens|))
            if matched:
                details_base = comment or f"{mnemonic} {operands}"
                expr_base    = f"{mnemonic} {operands}"
                for mu in matched:
                    records.append({
                        'variable':   var_map[mu],
                        'file':       file_str,
                        'line':       lineno,
                        'operation':  mnemonic,
                        'expression': expr_base,
                        'details':    details_base,
                        '_op_class':  op_class,
                    })

    return records


# ---------------------------------------------------------------------------
# next_hop linker
# ---------------------------------------------------------------------------

def _attach_next_hops(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """For each 'write' record, attach the closest following 'read' as next_hop.

    Only within-file hops are linked here.  Cross-file hops (ENTRC targets)
    get a synthetic next_hop pointing to line 1 of the called module based on
    the ENTRC operand and any sibling .asm file with that stem.
    """
    # Group by (variable, file) preserving insertion order (already sorted by line)
    from collections import defaultdict
    by_var_file: Dict[Tuple[str, str], List[int]] = defaultdict(list)

    for i, rec in enumerate(records):
        key = (rec['variable'], rec['file'])
        by_var_file[key].append(i)

    for (var, file_), indices in by_var_file.items():
        write_indices = [i for i in indices if records[i]['_op_class'] == 'write']
        read_indices  = [i for i in indices if records[i]['_op_class'] == 'read']

        for wi in write_indices:
            write_line = records[wi]['line']
            # Nearest read that comes AFTER this write
            candidates = [i for i in read_indices if records[i]['line'] > write_line]
            if candidates:
                ri = min(candidates, key=lambda i: records[i]['line'])
                hop_rec = records[ri]
                records[wi]['next_hop'] = {
                    'variable':  hop_rec['variable'],
                    'file':      hop_rec['file'],
                    'line':      hop_rec['line'],
                    'operation': hop_rec['operation'],
                    'details':   hop_rec['details'],
                }

    return records


def _attach_entrc_hops(
    records: List[Dict[str, Any]],
    asm_dir: Path,
) -> List[Dict[str, Any]]:
    """Add cross-file next_hop for ENTRC instructions.

    Looks for a .asm file whose stem matches the ENTRC operand (case-
    insensitive) within *asm_dir* and attaches it as next_hop line 1.
    """
    asm_stems: Dict[str, Path] = {
        p.stem.lower(): p for p in asm_dir.rglob('*.asm')
    }

    for rec in records:
        if rec['operation'] != 'ENTRC':
            continue
        if 'next_hop' in rec:
            continue  # already linked

        # Operand is the module name (e.g. "UA88")
        module_name = rec['variable']  # variable name IS the module stem for ENTRC
        # Try the actual ENTRC operand from the details or record
        # The ENTRC operand was matched as the variable name prefix; use it directly
        stem = module_name.lower()
        if stem in asm_stems:
            target = asm_stems[stem]
            rec['next_hop'] = {
                'file':      str(target),
                'line':      1,
                'operation': 'ENTRY_POINT',
                'details':   f'Entry into {module_name} module',
            }

    return records


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_hop_index(
    asm_dir: Path,
    variables: List[str],
    output_path: Path,
) -> Path:
    """Scan ASM files under *asm_dir* for *variables* and write the hop index.

    Args:
        asm_dir:     Directory containing ``.asm`` source files (searched
                     recursively).
        variables:   List of variable / register / module names to track.
        output_path: Path for the output JSON file.

    Returns:
        *output_path* after writing.
    """
    asm_files = sorted(asm_dir.rglob('*.asm'))
    if not asm_files:
        print(f'WARNING: No .asm files found under {asm_dir}', file=sys.stderr)

    all_records: List[Dict[str, Any]] = []
    for asm_path in asm_files:
        all_records.extend(_scan_file(asm_path, variables))

    # Sort: by variable name, then file, then line number
    all_records.sort(key=lambda r: (r['variable'], r['file'], r['line']))

    # Link next_hops
    all_records = _attach_next_hops(all_records)
    all_records = _attach_entrc_hops(all_records, asm_dir)

    # Strip internal classification field before writing
    for rec in all_records:
        rec.pop('_op_class', None)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as fh:
        json.dump(all_records, fh, indent=2)

    print(
        f'Wrote {len(all_records)} hop records → {output_path} '
        f'({len(asm_files)} files scanned, {len(variables)} variables)',
        file=sys.stderr,
    )
    return output_path


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Generate variable_hop_index.json by scanning ASM source files.'
    )
    parser.add_argument(
        'asm_dir',
        help='Directory containing .asm source files (searched recursively).',
    )
    parser.add_argument(
        'variables',
        nargs='*',
        help=(
            'Variable / register / module names to track. '
            'Registers (R0–R15) are matched only as destination operands. '
            'ENTRC targets are matched by module name prefix.'
        ),
    )
    parser.add_argument(
        '--output',
        default='output/variable_hop_index.json',
        help='Output path (default: output/variable_hop_index.json).',
    )
    args = parser.parse_args()

    asm_dir = Path(args.asm_dir)
    if not asm_dir.is_dir():
        print(f'Error: {asm_dir} is not a directory.', file=sys.stderr)
        sys.exit(1)

    variables = [v.upper() for v in args.variables]
    if not variables:
        print('Error: provide at least one variable name.', file=sys.stderr)
        parser.print_usage(sys.stderr)
        sys.exit(1)

    build_hop_index(asm_dir, variables, Path(args.output))
