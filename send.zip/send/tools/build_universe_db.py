#!/usr/bin/env python3
"""Backfill script: build SQLite variable universe databases from existing JSON files.

New pipeline runs automatically write both the .json and .db files via
VariableUniverse.to_sqlite().  Use this script to backfill existing KB output
directories that only have the JSON files.

Usage:
    # Single KB output directory
    python tools/build_universe_db.py jobs/<kb_id>/output/

    # Multiple directories
    python tools/build_universe_db.py jobs/kb1/output/ jobs/kb2/output/

    # All KBs under the configured JOBS_BASE_DIR
    python tools/build_universe_db.py --all

    # Force-rebuild even if .db already exists
    python tools/build_universe_db.py --all --force
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from models.variable_universe import VariableUniverse

_UNIVERSE_FILES = [
    ("asm_variable_universe.json", "asm_variable_universe.db"),
    ("cpp_variable_universe.json", "cpp_variable_universe.db"),
]


def build_db_for_dir(output_dir: Path, force: bool = False) -> None:
    """Build SQLite DBs for all universe JSON files inside *output_dir*."""
    for json_name, db_name in _UNIVERSE_FILES:
        json_path = output_dir / json_name
        db_path   = output_dir / db_name

        if not json_path.exists():
            print(f"  SKIP  {json_name} (not found in {output_dir})")
            continue

        if db_path.exists() and not force:
            print(f"  SKIP  {db_name} (already exists — use --force to rebuild)")
            continue

        if db_path.exists() and force:
            db_path.unlink()

        size_mb = json_path.stat().st_size / (1024 * 1024)
        print(f"  BUILD {db_name} from {json_name} ({size_mb:.1f} MB) ...", end="", flush=True)
        t0 = time.monotonic()

        universe = VariableUniverse.from_json(json_path)
        universe.to_sqlite(db_path)

        elapsed = time.monotonic() - t0
        db_size_mb = db_path.stat().st_size / (1024 * 1024)
        print(f" done in {elapsed:.1f}s  ({db_size_mb:.1f} MB)")


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Build SQLite variable universe databases from existing JSON files.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    ap.add_argument(
        "output_dirs", nargs="*",
        help="One or more KB output directories to process.",
    )
    ap.add_argument(
        "--all", action="store_true",
        help="Process all KB output dirs under JOBS_BASE_DIR (from api.config.settings).",
    )
    ap.add_argument(
        "--force", action="store_true",
        help="Rebuild .db files even if they already exist.",
    )
    args = ap.parse_args()

    dirs: list[Path] = []

    if args.all:
        from api.config import settings
        base = settings.JOBS_BASE_DIR
        for kb_dir in sorted(base.iterdir()):
            out = kb_dir / "output"
            if out.is_dir():
                dirs.append(out)
        if not dirs:
            print(f"No KB output directories found under {base}")
            sys.exit(0)
    else:
        if not args.output_dirs:
            ap.print_help()
            sys.exit(1)
        dirs = [Path(d) for d in args.output_dirs]

    t_total = time.monotonic()
    for d in dirs:
        print(f"\n[{d}]")
        if not d.is_dir():
            print(f"  ERROR: directory not found")
            continue
        build_db_for_dir(d, force=args.force)

    print(f"\nTotal elapsed: {time.monotonic() - t_total:.1f}s")


if __name__ == "__main__":
    main()
