#!/usr/bin/env python3
"""
End-to-end validation for POST /v1/knowledge-bases/{kb_id}/variable-usage/batch.

Usage:
    KB_ID=<id> AUTH_TOKEN=<jwt> python tools/validate_variable_usage_batch_api.py

Optional env vars:
    API_BASE_URL  (default: http://localhost:8000)
    JOBS_BASE_DIR (default: ./jobs)
    TIMEOUT       (default: 600 seconds)
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import msgpack
except ImportError:
    print("ERROR: msgpack not installed.")
    sys.exit(1)

try:
    import requests
except ImportError:
    print("ERROR: requests not installed.")
    sys.exit(1)

BASE_URL      = os.environ.get("API_BASE_URL", "http://localhost:8000").rstrip("/")
KB_ID         = os.environ.get("KB_ID", "")
TOKEN         = os.environ.get("AUTH_TOKEN", "")
TIMEOUT       = int(os.environ.get("TIMEOUT", "600"))
JOBS_BASE_DIR = Path(os.environ.get("JOBS_BASE_DIR", str(Path(__file__).parents[1] / "jobs")))
HEADERS       = {"Authorization": f"Bearer {TOKEN}"} if TOKEN else {}

_results: List[str] = []
PASS, FAIL = "PASS", "FAIL"


def _check(condition: bool, label: str) -> None:
    marker = PASS if condition else FAIL
    _results.append(f"  [{marker}] {label}")
    print(f"  [{'pass' if condition else 'FAIL'}] {label}")


# ---------------------------------------------------------------------------
# API helpers
# ---------------------------------------------------------------------------

def submit_batch() -> Dict:
    url  = f"{BASE_URL}/v1/knowledge-bases/{KB_ID}/variable-usage/batch"
    resp = requests.post(url, headers=HEADERS, timeout=30)
    resp.raise_for_status()
    return resp.json()


def get_task(celery_task_id: str) -> Dict:
    url  = f"{BASE_URL}/v1/tasks/{celery_task_id}"
    resp = requests.get(url, headers=HEADERS, timeout=10)
    resp.raise_for_status()
    return resp.json()


def get_job_status(job_id: str) -> Dict:
    url  = f"{BASE_URL}/v1/jobs/{job_id}"
    resp = requests.get(url, headers=HEADERS, timeout=10)
    resp.raise_for_status()
    return resp.json()


def get_job_results(job_id: str) -> Dict:
    url  = f"{BASE_URL}/v1/jobs/{job_id}/results"
    resp = requests.get(url, headers=HEADERS, timeout=10)
    resp.raise_for_status()
    return resp.json()


def poll_with_progress(celery_task_id: str, poll_timeout: int = TIMEOUT) -> Dict:
    """Poll task until terminal state, printing progress counts."""
    start = time.time()
    prev_done = -1
    progress_snapshots: List[int] = []

    while True:
        data = get_task(celery_task_id)
        state = data.get("state", "")

        if state == "PROGRESS":
            prog = data.get("progress") or {}
            done  = prog.get("done", 0)
            total = prog.get("total", 0)
            if done != prev_done:
                print(f"    [progress] {done}/{total}")
                progress_snapshots.append(done)
                prev_done = done

        if data.get("is_complete"):
            print(f"    [done] final state={state}")
            data["_progress_snapshots"] = progress_snapshots
            return data

        elapsed = time.time() - start
        if elapsed > poll_timeout:
            raise TimeoutError(f"Task {celery_task_id} did not complete within {poll_timeout}s")
        time.sleep(1)


def download_cache() -> Dict:
    """Download variable_usage.msgpack directly from the KB's output directory."""
    cache_path = JOBS_BASE_DIR / KB_ID / "output" / "variable_usage.msgpack"
    if not cache_path.exists():
        raise FileNotFoundError(f"Cache file not found: {cache_path}")
    return msgpack.unpackb(cache_path.read_bytes(), raw=False, strict_map_key=False)


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

def validate_result_schema(result: Dict, var_name: str) -> None:
    for key in ("variable_name", "input_name", "found", "total_files",
                "total_locations", "search_tiers_used", "files", "suggestions"):
        _check(key in result, f"schema: {var_name} has key '{key}'")

    _check(
        result.get("total_files") == len(result.get("files", [])),
        f"schema: {var_name} total_files == len(files)",
    )
    _check(
        result.get("total_locations") == sum(f.get("total_locations", 0) for f in result.get("files", [])),
        f"schema: {var_name} total_locations == sum of file totals",
    )
    for f in result.get("files", []):
        fp = Path(f.get("file_path", "")).name
        _check(
            f.get("total_locations") == len(f.get("locations", [])),
            f"schema: {var_name}/{fp} total_locations == len(locations)",
        )
        for loc in f.get("locations", []):
            line  = loc.get("line", 0)
            ctx   = loc.get("context", "")
            chunk = loc.get("code_chunk")
            _check(line >= 1, f"schema: {var_name}/{fp} L{line} >= 1")
            _check(ctx in ("definition", "reference", "modification"),
                   f"schema: {var_name}/{fp} L{line} context valid")
            if chunk:
                start = chunk.get("start_line", 0)
                end   = chunk.get("end_line", 0)
                hl    = chunk.get("highlight_line", 0)
                lines = chunk.get("lines", [])
                _check(len(lines) == end - start + 1,
                       f"schema: {var_name}/{fp} L{line} chunk length matches range")
                _check(start <= hl <= end,
                       f"schema: {var_name}/{fp} L{line} highlight_line in range")


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_submission_and_lifecycle() -> Dict:
    print(f"\n{'='*60}")
    print("TEST 1: Submission and job lifecycle")
    print(f"{'='*60}")

    resp = requests.post(
        f"{BASE_URL}/v1/knowledge-bases/{KB_ID}/variable-usage/batch",
        headers=HEADERS, timeout=30,
    )
    _check(resp.status_code == 202, f"HTTP 202 (got {resp.status_code})")
    job_resp = resp.json()

    _check("job_id" in job_resp, "response has job_id")
    _check("celery_task_id" in job_resp, "response has celery_task_id")
    _check(job_resp.get("status") == "pending", "initial status == 'pending'")

    job_status = get_job_status(job_resp["job_id"])
    _check(job_status.get("status") in ("pending", "running"),
           f"job status is pending/running (got {job_status.get('status')})")

    return job_resp


def test_progress_and_completion(celery_task_id: str) -> Dict:
    print(f"\n{'='*60}")
    print("TEST 2-3: Progress tracking and final result")
    print(f"{'='*60}")

    task_result = poll_with_progress(celery_task_id)
    snapshots = task_result.pop("_progress_snapshots", [])

    # Test 3: final result (evaluated before Test 2 so we know if it was all-cached)
    _check(task_result.get("state") == "SUCCESS",
           f"final state == SUCCESS (got {task_result.get('state')})")
    raw = task_result.get("result") or {}
    total     = raw.get("total", 0)
    processed = raw.get("processed", 0)
    skipped   = raw.get("skipped", 0)
    errors    = raw.get("errors", 0)

    _check(total >= 3000, f"total >= 3000 (got {total})")
    _check(processed + skipped == total,
           f"processed ({processed}) + skipped ({skipped}) == total ({total})")
    _check(errors == 0, f"errors == 0 (got {errors})")
    _check(raw.get("kb_id") == KB_ID, f"kb_id matches")

    # Test 2: progress — when processed == 0 the task completes in milliseconds
    # so PROGRESS state is invisible to polling; that's expected and acceptable
    if processed == 0:
        _check(True, f"PROGRESS updates not required: all {total} vars already cached")
    else:
        _check(len(snapshots) >= 1, f"observed at least 1 PROGRESS update (got {len(snapshots)})")
        if len(snapshots) >= 2:
            _check(snapshots[-1] >= snapshots[0], "progress done count is non-decreasing")

    return task_result


def test_job_status_after_completion(job_id: str) -> None:
    print(f"\n{'='*60}")
    print("TEST 4: Job status and result files after completion")
    print(f"{'='*60}")

    status = get_job_status(job_id)
    _check(status.get("status") == "success",
           f"job status == 'success' (got {status.get('status')})")

    results = get_job_results(job_id)
    files = results.get("files", []) if isinstance(results, dict) else results
    has_summary = any("batch_summary" in (f.get("name","") or f.get("path","")) for f in files)
    _check(has_summary, "batch_summary.json listed in job results")


def test_cache_completeness(cache: Dict) -> None:
    print(f"\n{'='*60}")
    print("TEST 5: Cache completeness")
    print(f"{'='*60}")

    _check(len(cache) >= 3000, f"cache has >= 3000 entries (got {len(cache)})")
    for var in ("PKDZERO", "DA7GL", "LM1BID&A", "A"):
        _check(var in cache, f"'{var}' in cache")


def test_schema_spot_checks(cache: Dict) -> None:
    print(f"\n{'='*60}")
    print("TEST 6: Cached result schema spot-checks (PKDZERO, DA7GL, A)")
    print(f"{'='*60}")

    for var in ("PKDZERO", "DA7GL", "A"):
        result = cache.get(var)
        if result is None:
            _check(False, f"{var}: present in cache")
            continue
        validate_result_schema(result, var)


def test_concrete_counts(cache: Dict) -> None:
    print(f"\n{'='*60}")
    print("TEST 7: Concrete count assertions")
    print(f"{'='*60}")

    cases = [
        ("PKDZERO", 7, 64),
        ("DA7GL",   3, 65),
        ("A",       7, 14),
    ]
    for var, exp_files, exp_locs in cases:
        result = cache.get(var, {})
        _check(result.get("total_files") == exp_files,
               f"{var}: total_files == {exp_files} (got {result.get('total_files')})")
        _check(result.get("total_locations") == exp_locs,
               f"{var}: total_locations == {exp_locs} (got {result.get('total_locations')})")


def test_code_chunk_context_size(cache: Dict) -> None:
    print(f"\n{'='*60}")
    print("TEST 8: Code chunk context size (context_lines=5 → max span=10)")
    print(f"{'='*60}")

    result = cache.get("PKDZERO", {})
    violations = 0
    checked = 0
    for f in result.get("files", []):
        fp = f.get("file_path", "")
        try:
            total_lines = len(Path(fp).read_text(errors="replace").splitlines())
        except Exception:
            continue
        for loc in f.get("locations", []):
            chunk = loc.get("code_chunk")
            if not chunk:
                continue
            span = chunk["end_line"] - chunk["start_line"]
            # Only check interior lines (not file start/end where context is naturally trimmed)
            if chunk["start_line"] > 1 and chunk["end_line"] < total_lines:
                checked += 1
                if span > 10:
                    violations += 1

    _check(violations == 0, f"PKDZERO: all interior chunks have span <= 10 ({checked} checked, {violations} violations)")


def test_incremental_rerun() -> None:
    print(f"\n{'='*60}")
    print("TEST 9: Incremental re-run (everything already cached)")
    print(f"{'='*60}")

    start = time.time()
    job_resp = submit_batch()
    task_result = poll_with_progress(job_resp["celery_task_id"], poll_timeout=120)
    elapsed = time.time() - start

    task_result.pop("_progress_snapshots", None)
    raw = task_result.get("result") or {}
    _check(task_result.get("state") == "SUCCESS", "re-run: state == SUCCESS")
    _check(raw.get("processed", -1) == 0,
           f"re-run: processed == 0 (got {raw.get('processed')})")
    _check(raw.get("skipped", 0) >= 3000,
           f"re-run: skipped >= 3000 (got {raw.get('skipped')})")
    _check(elapsed < 60, f"re-run: completed in < 60s (took {elapsed:.1f}s)")


def test_individual_cache_hit() -> None:
    print(f"\n{'='*60}")
    print("TEST 10: Individual search is a cache hit after batch")
    print(f"{'='*60}")

    url  = f"{BASE_URL}/v1/knowledge-bases/{KB_ID}/variable-usage"
    resp = requests.post(url, json={"variable_name": "PKDZERO"}, headers=HEADERS, timeout=30)
    resp.raise_for_status()
    job_resp = resp.json()

    task_result = poll_with_progress(job_resp["celery_task_id"], poll_timeout=30)
    task_result.pop("_progress_snapshots", None)
    _check(task_result.get("state") == "SUCCESS", "individual: state == SUCCESS")
    raw = task_result.get("result") or {}
    _check(raw.get("cached") is True, f"individual: cached == True (got {raw.get('cached')})")


def test_not_found_variable_in_cache() -> None:
    print(f"\n{'='*60}")
    print("TEST 11: Not-found variable cached correctly")
    print(f"{'='*60}")

    var = "TOTALLY_NONEXISTENT_XYZ_VAR"

    # Trigger an individual search so the not-found result is written to cache
    url  = f"{BASE_URL}/v1/knowledge-bases/{KB_ID}/variable-usage"
    resp = requests.post(url, json={"variable_name": var}, headers=HEADERS, timeout=30)
    resp.raise_for_status()
    task_result = poll_with_progress(resp.json()["celery_task_id"], poll_timeout=30)
    task_result.pop("_progress_snapshots", None)
    _check(task_result.get("state") == "SUCCESS", f"{var}: individual search state == SUCCESS")

    cache = download_cache()
    _check(var in cache, f"'{var}' in cache")
    result = cache.get(var, {})
    _check(result.get("found") is False, f"{var}: found == False")
    _check(result.get("files") == [], f"{var}: files == []")
    _check(result.get("total_locations") == 0, f"{var}: total_locations == 0")
    _check(isinstance(result.get("suggestions"), list), f"{var}: suggestions is list")


def test_auth_checks() -> None:
    print(f"\n{'='*60}")
    print("TEST 12: Auth checks")
    print(f"{'='*60}")

    # No token
    resp = requests.post(
        f"{BASE_URL}/v1/knowledge-bases/{KB_ID}/variable-usage/batch",
        headers={}, timeout=10,
    )
    _check(resp.status_code in (401, 403),
           f"no token → 401/403 (got {resp.status_code})")

    # Wrong KB — UUID guaranteed not in DB
    resp = requests.post(
        f"{BASE_URL}/v1/knowledge-bases/ffffffff-ffff-ffff-ffff-ffffffffffff/variable-usage/batch",
        headers=HEADERS, timeout=10,
    )
    _check(resp.status_code == 404,
           f"invalid KB → 404 (got {resp.status_code})")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    if not KB_ID:
        print("ERROR: KB_ID env var is required.")
        sys.exit(1)
    if not TOKEN:
        print("WARNING: AUTH_TOKEN not set.")

    print(f"API: {BASE_URL}")
    print(f"KB:  {KB_ID}")
    print(f"Poll timeout: {TIMEOUT}s")

    # Test 12 first (doesn't affect state)
    test_auth_checks()

    # Test 1: submit
    job_resp = test_submission_and_lifecycle()
    job_id         = job_resp["job_id"]
    celery_task_id = job_resp["celery_task_id"]

    # Tests 2-3: progress + completion
    test_progress_and_completion(celery_task_id)

    # Test 4: job status files
    test_job_status_after_completion(job_id)

    # Load cache for remaining tests
    print("\n  [loading cache from disk...]")
    cache = download_cache()
    print(f"  [cache loaded: {len(cache)} entries]")

    # Tests 5-8: cache content
    test_cache_completeness(cache)
    test_schema_spot_checks(cache)
    test_concrete_counts(cache)
    test_code_chunk_context_size(cache)

    # Test 9: incremental re-run
    test_incremental_rerun()

    # Test 10: individual cache hit
    test_individual_cache_hit()

    # Test 11: not-found variable (triggers individual search then checks cache)
    test_not_found_variable_in_cache()

    # Summary
    total  = len(_results)
    passed = sum(1 for r in _results if PASS in r)
    failed = total - passed

    print(f"\n{'='*60}")
    print(f"SUMMARY: {passed}/{total} passed, {failed} failed")
    print(f"{'='*60}")
    if failed:
        print("\nFailed checks:")
        for r in _results:
            if FAIL in r:
                print(r)
        sys.exit(1)
    else:
        print("All checks passed.")


if __name__ == "__main__":
    main()
