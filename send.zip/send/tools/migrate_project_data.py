#!/usr/bin/env python3
"""Migrate ASM Modernizer project data (users.db + datasource/ + jobs/) between repos.

Copies the chosen knowledge bases and their on-disk artifacts from a SOURCE
checkout of asm-modernizer to a DESTINATION checkout. After the copy it
rewrites the absolute paths stored in `users.db.knowledge_bases.source_path`
so they point at the new repo location, and (optionally) repopulates the
destination's Redis metadata so the projects are visible end-to-end.

What the app needs after a move:
  1. users.db    -> auth users, knowledge_bases rows, access grants, file_summaries
  2. datasource/ -> the asm/cpp source tree pointed at by KB.source_path
  3. jobs/<uuid> -> per-project workspace (input/output/cache/processes)
  4. Redis       -> job:<uuid> JSON + jobs:by_time ZSET (required by
                    get_job_or_404 and many KB endpoints)

The script makes (3) and (1)'s path rewriting safe and re-runnable, and
optionally seeds Redis with a synthesized "success" meta per migrated job
so the API treats the project as a finished run.

Usage:
    # Dry run, migrating two projects
    python tools/migrate_project_data.py \
        --src  /Users/me/Documents/asm-modernizer \
        --dst  /Users/me/Documents/asm-modernizer-clone \
        --kb-id 07464797-8cc0-41c1-a52b-170eba03e111 \
        --kb-id a0168865-681a-43ac-9de3-1c7252d76105 \
        --dry-run

    # Real migration of every KB whose datasource + job folder exist on disk
    python tools/migrate_project_data.py --src ... --dst ... --all

    # Real migration + Redis seed (requires destination Redis reachable)
    python tools/migrate_project_data.py --src ... --dst ... --all \
        --seed-redis --dst-redis-url redis://localhost:6379 --dst-redis-db 0

The script has no dependency on the app code, so it can be run from any
Python 3.9+ interpreter that has `redis` available (only needed when
--seed-redis is passed).
"""
from __future__ import annotations

import argparse
import json
import shutil
import sqlite3
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

def _utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _log(msg: str) -> None:
    print(f"[migrate] {msg}", flush=True)


def _die(msg: str, code: int = 2) -> None:
    print(f"[migrate] ERROR: {msg}", file=sys.stderr, flush=True)
    sys.exit(code)


@dataclass
class KBRow:
    kb_id: str
    name: str
    created_by: str
    datasource_username: Optional[str]
    datasource_folder: Optional[str]
    source_path: str


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------

def load_kbs(db_path: Path) -> Dict[str, KBRow]:
    """Return every row in `knowledge_bases` keyed by id."""
    if not db_path.exists():
        _die(f"users.db not found at {db_path}")
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            "SELECT id, name, created_by, datasource_username, "
            "datasource_folder, source_path FROM knowledge_bases"
        ).fetchall()
    finally:
        conn.close()
    out: Dict[str, KBRow] = {}
    for r in rows:
        out[r["id"]] = KBRow(
            kb_id=r["id"],
            name=r["name"],
            created_by=r["created_by"],
            datasource_username=r["datasource_username"],
            datasource_folder=r["datasource_folder"],
            source_path=r["source_path"],
        )
    return out


def filter_migratable(
    kbs: Dict[str, KBRow],
    src_repo: Path,
    only_ids: Optional[List[str]] = None,
) -> Tuple[List[KBRow], List[str]]:
    """Return (kbs that have job+datasource on disk, reasons for skips)."""
    selected: List[KBRow] = []
    skips: List[str] = []
    src_jobs = src_repo / "jobs"

    for kb_id, kb in kbs.items():
        if only_ids and kb_id not in only_ids:
            continue

        job_dir = src_jobs / kb_id
        if not job_dir.is_dir():
            skips.append(f"{kb_id} ({kb.name}): missing jobs/{kb_id}/")
            continue

        ds_path = Path(kb.source_path)
        if not ds_path.is_dir():
            skips.append(
                f"{kb_id} ({kb.name}): source_path missing on disk: {ds_path}"
            )
            continue

        # Confirm the source_path lives under the source repo's datasource/
        # tree. If it doesn't, we can still copy job data but the rewrite
        # logic will refuse to touch it, so warn rather than skip.
        try:
            ds_path.resolve().relative_to((src_repo / "datasource").resolve())
        except ValueError:
            skips.append(
                f"{kb_id} ({kb.name}): source_path is outside "
                f"{src_repo / 'datasource'} — will copy job folder only, "
                "datasource left untouched"
            )
            # We still include it; copy_for_kb will skip the datasource copy.
        selected.append(kb)
    return selected, skips


# ---------------------------------------------------------------------------
# Copy
# ---------------------------------------------------------------------------

def copy_tree(src: Path, dst: Path, dry_run: bool) -> None:
    if not src.is_dir():
        _log(f"  skip (not a dir): {src}")
        return
    if dst.exists():
        _log(f"  exists, leaving as-is: {dst}")
        return
    _log(f"  copy {src} -> {dst}")
    if dry_run:
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(src, dst, symlinks=False)


def copy_users_db(src_db: Path, dst_db: Path, dry_run: bool) -> None:
    _log(f"users.db copy: {src_db} -> {dst_db}")
    if dry_run:
        return
    dst_db.parent.mkdir(parents=True, exist_ok=True)
    if dst_db.exists():
        backup = dst_db.with_suffix(dst_db.suffix + f".bak.{int(time.time())}")
        _log(f"  destination users.db exists; backing up to {backup.name}")
        shutil.copy2(dst_db, backup)
    shutil.copy2(src_db, dst_db)


def copy_for_kb(kb: KBRow, src_repo: Path, dst_repo: Path, dry_run: bool) -> None:
    src_job = src_repo / "jobs" / kb.kb_id
    dst_job = dst_repo / "jobs" / kb.kb_id
    copy_tree(src_job, dst_job, dry_run)

    src_ds_root = src_repo / "datasource"
    ds_abs = Path(kb.source_path).resolve()
    try:
        rel_under_datasource = ds_abs.relative_to(src_ds_root.resolve())
    except ValueError:
        _log(
            f"  source_path {ds_abs} not under {src_ds_root} — "
            "skipping datasource copy for this KB"
        )
        return
    dst_ds = dst_repo / "datasource" / rel_under_datasource
    copy_tree(ds_abs, dst_ds, dry_run)


# ---------------------------------------------------------------------------
# DB rewrite + pruning
# ---------------------------------------------------------------------------

def rewrite_paths_and_prune(
    dst_db: Path,
    src_repo: Path,
    dst_repo: Path,
    keep_kb_ids: Set[str],
    prune_orphans: bool,
    dry_run: bool,
) -> None:
    """Rewrite absolute paths in `knowledge_bases.source_path` and (optionally)
    delete rows whose data was not migrated."""
    _log(f"DB rewrite: {dst_db}")
    if dry_run:
        _log("  (dry-run) would rewrite source_path prefixes and prune rows")
        return

    src_prefix = str(src_repo.resolve())
    dst_prefix = str(dst_repo.resolve())
    conn = sqlite3.connect(str(dst_db))
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        cur = conn.cursor()
        # Rewrite path prefix for kept KBs only — leaves untouched any rows
        # whose source_path lives outside the source repo's tree (those are
        # the user's choice to manage manually).
        rows = cur.execute(
            "SELECT id, source_path FROM knowledge_bases"
        ).fetchall()
        rewrites = 0
        for kb_id, sp in rows:
            if kb_id not in keep_kb_ids:
                continue
            if sp and sp.startswith(src_prefix):
                new_sp = dst_prefix + sp[len(src_prefix):]
                cur.execute(
                    "UPDATE knowledge_bases SET source_path = ?, "
                    "updated_at = ? WHERE id = ?",
                    (new_sp, _utcnow_iso(), kb_id),
                )
                rewrites += 1
        _log(f"  rewrote source_path on {rewrites} row(s)")

        if prune_orphans:
            placeholders = ",".join("?" * len(keep_kb_ids)) or "''"
            params = list(keep_kb_ids) if keep_kb_ids else [""]
            # Delete dependent rows first (file_summaries cascades automatically
            # because of ON DELETE CASCADE, but knowledge_base_access does not).
            cur.execute(
                f"DELETE FROM knowledge_base_access "
                f"WHERE kb_id NOT IN ({placeholders})",
                params,
            )
            kb_access_deleted = cur.rowcount
            cur.execute(
                f"DELETE FROM knowledge_bases WHERE id NOT IN ({placeholders})",
                params,
            )
            kb_deleted = cur.rowcount
            _log(
                f"  pruned {kb_deleted} orphan knowledge_bases row(s) "
                f"and {kb_access_deleted} access grant(s)"
            )

        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Redis seed
# ---------------------------------------------------------------------------

def seed_redis(
    kb_rows: List[KBRow],
    dst_repo: Path,
    redis_url: str,
    redis_db: int,
    job_ttl_seconds: int,
    dry_run: bool,
) -> None:
    """Write a synthesized `job:<uuid>` meta + ZSET entry per migrated job
    so the API serves the project as a completed run."""
    if dry_run:
        _log(
            f"Redis seed (dry-run): would write {len(kb_rows)} job meta entries "
            f"to {redis_url} db={redis_db}"
        )
        return
    try:
        import redis as redis_lib  # type: ignore
    except ImportError:
        _die(
            "--seed-redis requires the 'redis' package. Install with: "
            "pip install redis"
        )

    client = redis_lib.Redis.from_url(
        redis_url, db=redis_db, decode_responses=True
    )
    try:
        client.ping()
    except Exception as exc:
        _die(f"could not reach destination Redis at {redis_url} db={redis_db}: {exc}")

    pipe = client.pipeline()
    now_iso = _utcnow_iso()
    score_base = time.time()
    written = 0
    for i, kb in enumerate(kb_rows):
        job_id = kb.kb_id
        workspace_path = str((dst_repo / "jobs" / job_id).resolve())

        meta = {
            "job_id": job_id,
            "operation": "kb_chain_summaries",
            "status": "success",
            "created_at": now_iso,
            "updated_at": now_iso,
            "celery_task_id": None,
            "workspace_path": workspace_path,
            "error": None,
            "result_files": _scan_output_files(dst_repo / "jobs" / job_id / "output"),
            "pipeline_options": {
                "source_path": str(Path(kb.source_path).resolve())
                if Path(kb.source_path).is_absolute()
                else str((dst_repo / kb.source_path).resolve()),
                "kb_id": job_id,
                "lineage_direction": "backward",
                "lineage_kind": "variable",
            },
            "step_progress": {"migrated": "success"},
        }
        pipe.set(f"job:{job_id}", json.dumps(meta), ex=job_ttl_seconds)
        # Stagger the score by index so list order is deterministic.
        pipe.zadd("jobs:by_time", {job_id: score_base - i})
        written += 1

    # Keep the ZSET alive past any single job's TTL (mirrors WorkspaceManager).
    pipe.expire("jobs:by_time", job_ttl_seconds * 10)
    pipe.execute()
    _log(f"  seeded {written} job:* meta entries in Redis")


def _scan_output_files(output_dir: Path) -> List[Dict[str, object]]:
    """Mirror WorkspaceManager.collect_output_files() so the seed meta
    advertises the same result_files the live app would compute."""
    if not output_dir.is_dir():
        return []
    out = []
    for p in sorted(output_dir.rglob("*")):
        if not p.is_file():
            continue
        try:
            rel = str(p.relative_to(output_dir))
        except ValueError:
            rel = p.name
        try:
            size = p.stat().st_size
        except OSError:
            size = 0
        out.append({"name": p.name, "path": rel, "size_bytes": size})
    return out


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Migrate ASM Modernizer projects (users.db + datasource/ + jobs/) "
            "from one repo checkout to another."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--src", required=True, type=Path,
        help="Source repo root (the checkout that currently holds the data).",
    )
    parser.add_argument(
        "--dst", required=True, type=Path,
        help="Destination repo root (a fresh checkout of asm-modernizer).",
    )
    parser.add_argument(
        "--kb-id", action="append", default=[],
        help="UUID of a KB to migrate. Repeat for multiple.",
    )
    parser.add_argument(
        "--all", action="store_true",
        help="Migrate every KB whose jobs/<uuid>/ and datasource exist on disk.",
    )
    parser.add_argument(
        "--prune-orphans", action="store_true",
        help=(
            "Delete rows from the destination users.db whose data was NOT "
            "migrated. Otherwise they're kept and will 404 when opened."
        ),
    )
    parser.add_argument(
        "--seed-redis", action="store_true",
        help=(
            "After copying, write a synthesized job:<uuid> meta + jobs:by_time "
            "ZSET entry to the destination Redis so the API can serve the "
            "project. Requires the 'redis' Python package."
        ),
    )
    parser.add_argument(
        "--dst-redis-url", default="redis://localhost:6379",
        help="Destination Redis URL (default: redis://localhost:6379).",
    )
    parser.add_argument(
        "--dst-redis-db", default=0, type=int,
        help="Destination Redis metadata DB number (default: 0).",
    )
    parser.add_argument(
        "--job-ttl-seconds", default=86400 * 30, type=int,
        help=(
            "TTL applied to seeded job:<uuid> meta entries (default: 30 days). "
            "Match settings.JOB_TTL_SECONDS if you want exact parity with a "
            "freshly-run job."
        ),
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Print what would happen without copying or modifying anything.",
    )
    args = parser.parse_args(argv)

    src_repo: Path = args.src.resolve()
    dst_repo: Path = args.dst.resolve()
    if not src_repo.is_dir():
        _die(f"--src is not a directory: {src_repo}")
    if not dst_repo.is_dir():
        _die(f"--dst is not a directory: {dst_repo}")
    if src_repo == dst_repo:
        _die("--src and --dst point at the same path")

    src_db = src_repo / "users.db"
    dst_db = dst_repo / "users.db"

    _log(f"source: {src_repo}")
    _log(f"dest:   {dst_repo}")

    # 1. Discover migratable KBs from the source DB.
    kbs = load_kbs(src_db)
    _log(f"found {len(kbs)} KB row(s) in source users.db")

    if not args.all and not args.kb_id:
        _die("either --all or one or more --kb-id <uuid> must be given")

    only_ids = args.kb_id if args.kb_id else None
    selected, skips = filter_migratable(kbs, src_repo, only_ids=only_ids)
    if not selected:
        _log("nothing migratable; aborting")
        for s in skips:
            _log(f"  skip: {s}")
        return 1
    _log(f"selected {len(selected)} KB(s) for migration:")
    for kb in selected:
        _log(f"  - {kb.kb_id}  {kb.name}  (by {kb.created_by})")
    for s in skips:
        _log(f"  skipped: {s}")

    # 2. Copy users.db (always — even pruned, it carries auth + KB rows).
    copy_users_db(src_db, dst_db, args.dry_run)

    # 3. Copy job folders + datasource subtrees.
    _log("copying job + datasource trees…")
    for kb in selected:
        _log(f"KB {kb.kb_id} ({kb.name}):")
        copy_for_kb(kb, src_repo, dst_repo, args.dry_run)

    # 4. Rewrite paths inside destination users.db; optionally prune orphans.
    rewrite_paths_and_prune(
        dst_db=dst_db,
        src_repo=src_repo,
        dst_repo=dst_repo,
        keep_kb_ids={kb.kb_id for kb in selected},
        prune_orphans=args.prune_orphans,
        dry_run=args.dry_run,
    )

    # 5. Optional Redis seeding so the API can find the jobs.
    if args.seed_redis:
        # Build KB list with rewritten source_path so the seeded pipeline_options
        # reflects the destination layout.
        rewritten = []
        src_prefix = str(src_repo)
        dst_prefix = str(dst_repo)
        for kb in selected:
            new_sp = (
                dst_prefix + kb.source_path[len(src_prefix):]
                if kb.source_path.startswith(src_prefix)
                else kb.source_path
            )
            rewritten.append(KBRow(
                kb_id=kb.kb_id,
                name=kb.name,
                created_by=kb.created_by,
                datasource_username=kb.datasource_username,
                datasource_folder=kb.datasource_folder,
                source_path=new_sp,
            ))
        seed_redis(
            kb_rows=rewritten,
            dst_repo=dst_repo,
            redis_url=args.dst_redis_url,
            redis_db=args.dst_redis_db,
            job_ttl_seconds=args.job_ttl_seconds,
            dry_run=args.dry_run,
        )
    else:
        _log(
            "Redis seed skipped (--seed-redis not set). "
            "Login + KB list will work, but opening a project may 404 until "
            "Redis is populated."
        )

    _log("done.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
