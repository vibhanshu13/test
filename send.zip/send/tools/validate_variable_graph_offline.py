"""Offline end-to-end validation of the variable_graph feature.

This bypasses the API and Celery layer (which require Redis state we are not
authorized to populate from a script) and instead runs the same machinery the
Celery task uses, directly against an existing job's pipeline output. It then
runs Tier 3 (structural) and Tier 4 (semantic cross-reference) validators
against the produced msgpack.

Use when:
  - You have a job with a completed pipeline (file_call_graph.json, processes/)
  - You have, or can build, a ChunkedBackwardSession against the process scope
  - You want to confirm the new code paths produce a valid graph end-to-end
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.processes.scope import (
    filter_tuple_to_scope,
    load_process_scope,
    materialize_filtered_graph,
    process_lineage_dir,
    session_file_for,
)
from api.tasks.variable_graph_task import (
    variable_graph_msgpack_path,
    write_variable_graph,
)
from api.tasks._task_utils import find_blueprint_dir
from backward_traversal.graph_extraction import build_variable_graph_from_tuples
from backward_traversal.runner.chunked_session import ChunkedBackwardSession


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--job-id", required=True)
    ap.add_argument("--process", required=True)
    ap.add_argument("--variable", required=True)
    ap.add_argument("--chain", required=True, help="comma-separated stems")
    ap.add_argument("--chain-hash", default="offline_run_0000", help="opaque tag for this run")
    ap.add_argument("--max-dep-vars", type=int, default=20)
    ap.add_argument("--max-dep-var-depth", type=int, default=2)
    ap.add_argument("--max-depth", type=int, default=8)
    ap.add_argument("--max-downstream-files", type=int, default=30)
    ap.add_argument("--jobs-base", default=str(PROJECT_ROOT / "jobs"))
    ap.add_argument("--existing-session-id", default=None,
                    help="Reuse an existing session.msgpack instead of building one")
    args = ap.parse_args()

    chain = [s.strip() for s in args.chain.split(",") if s.strip()]
    if len(chain) < 2:
        print("FAIL: chain must have ≥2 entries", file=sys.stderr)
        return 1

    jobs_base = Path(args.jobs_base)
    output_dir = jobs_base / args.job_id / "output"
    if not output_dir.is_dir():
        print(f"FAIL: output dir missing: {output_dir}", file=sys.stderr)
        return 1

    process_dir = output_dir / "processes" / args.process
    if not process_dir.is_dir():
        print(f"FAIL: process dir missing: {process_dir}", file=sys.stderr)
        return 1

    global_graph = output_dir / "file_call_graph.json"
    if not global_graph.is_file():
        print(f"FAIL: global call graph missing: {global_graph}", file=sys.stderr)
        return 1

    scope = load_process_scope(process_dir, args.process)
    if not scope.files:
        print(f"FAIL: process scope is empty", file=sys.stderr)
        return 1
    scope_stems = {Path(p).stem.lower() for p in scope.files}
    missing = [c for c in chain if c.lower() not in scope_stems]
    if missing:
        print(f"FAIL: chain files outside scope: {missing}", file=sys.stderr)
        return 1

    print(f"[Phase 1/5] scope OK ({len(scope_stems)} files); materializing filtered graph")
    graph_file = materialize_filtered_graph(output_dir, args.process, scope, global_graph)
    blueprint_dir = find_blueprint_dir(output_dir)
    if not blueprint_dir:
        print("FAIL: no blueprints found", file=sys.stderr)
        return 1

    asm_dir = output_dir.parent / "input"
    if not asm_dir.exists():
        asm_dir = None

    session_id = args.existing_session_id or args.chain_hash
    session_file = session_file_for(output_dir, args.process, session_id)
    session_directory = session_file.parent
    session_directory.mkdir(parents=True, exist_ok=True)

    options = {
        "max_depth": args.max_depth,
        "max_subroutine_depth": 2,
        "max_subroutine_nodes": 400,
        "max_trace_nodes": 5000,
        "max_dep_vars": args.max_dep_vars,
        "max_dep_var_depth": args.max_dep_var_depth,
        "max_downstream_depth": 2,
        "max_downstream_files": args.max_downstream_files,
        "t8_max_scan": 0,
    }

    print(f"[Phase 2/5] loading/creating session at {session_file}")
    session = ChunkedBackwardSession.load(args.job_id, session_id, session_file=session_file)
    if session is None:
        session = ChunkedBackwardSession.new(
            session_id=session_id,
            kb_id=args.job_id,
            variable=args.variable,
            selected_chain=chain,
            options=options,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            graph_file=graph_file,
        )
        print("  (created new session)")
    else:
        print(f"  (loaded existing session, tuples={len(session.tuple_index_map)}, complete={session.is_complete})")

    print(f"[Phase 3/5] driving session to completion")
    safety = 0
    while not session.is_complete and safety < 5000:
        target = len(session.tuple_index_map)
        session.process_until_tuple(target, session_directory)
        safety += 1
    session.save(args.job_id, session_id, session_file=session_file)
    print(f"  tuples={len(session.tuple_index_map)} complete={session.is_complete}")

    print(f"[Phase 4/5] assembling tuples + building graph")
    tuples: List[Dict[str, Any]] = []
    for i in range(len(session.tuple_index_map)):
        try:
            t = session.assemble_tuple(i, session_directory)
        except FileNotFoundError as exc:
            print(f"  skip tuple {i}: {exc}")
            continue
        if t is None:
            continue
        tuples.append(filter_tuple_to_scope(t, scope))

    graph = build_variable_graph_from_tuples(
        tuples,
        scope_files=list(scope.files),
        root_variable=args.variable,
        chain_files=chain,
        chain_hash=args.chain_hash,
        caps=options,
        warnings=session.warnings,
    )

    msgpack_path = write_variable_graph(
        output_dir, args.process, args.variable, args.chain_hash, graph
    )
    print(f"  wrote {msgpack_path}")
    print(f"  nodes={graph['node_count']} edges={graph['edge_count']} warnings={len(graph['warnings'])}")

    # ----------------- Tier 3 (structural) inline -----------------
    print("[Phase 5/5] running Tier 3 + Tier 4 inline")
    fails: List[str] = []

    def chk(ok: bool, msg: str) -> None:
        print(f"  {'PASS' if ok else 'FAIL'} · {msg}")
        if not ok:
            fails.append(msg)

    required = {"schema_version", "root_variable", "chain_files", "chain_hash",
                "caps", "computed_at", "node_count", "edge_count",
                "nodes", "edges", "warnings"}
    chk(required <= set(graph.keys()), "all required keys present")
    names = {n["name"] for n in graph["nodes"]}
    chk(args.variable.upper() in names, "root variable is a node")
    roots = [n for n in graph["nodes"] if n["is_root"]]
    chk(len(roots) == 1 and roots[0]["name"] == args.variable.upper(),
        "exactly one is_root node, equals root")

    dangling = [
        e for e in graph["edges"]
        if e["source"] not in names or e["target"] not in names
    ]
    chk(not dangling, f"no dangling edge refs (found {len(dangling)})")

    # Process-scope leak test
    scope_stems_lower = scope_stems
    leaks = []
    for n in graph["nodes"]:
        for loc in n.get("locations") or []:
            f = str(loc.get("file") or "").lower()
            if f and f not in scope_stems_lower:
                leaks.append(("node", n["name"], f))
    for e in graph["edges"]:
        for loc in e.get("locations") or []:
            f = str(loc.get("file") or "").lower()
            if f and f not in scope_stems_lower:
                leaks.append(("edge", f"{e['source']}->{e['target']}", f))
    chk(not leaks, f"no process-scope leaks (found {len(leaks)})")

    # ASM locations have positive line numbers
    asm_bad = []
    for e in graph["edges"]:
        for loc in e.get("locations") or []:
            inst = str(loc.get("instruction") or "").upper()
            if inst != "CPP" and int(loc.get("line") or 0) <= 0:
                asm_bad.append(loc)
    chk(not asm_bad, f"all ASM edge locations have positive line numbers (bad={len(asm_bad)})")

    # ----------------- Tier 4 (cross-ref) inline -----------------
    bl_dir = output_dir / "process_lineage" / args.process / "backward_lineage"
    canonical = set()
    if bl_dir.is_dir():
        for fp in bl_dir.glob(f"{args.variable}_tuple_*.json"):
            try:
                payload = json.loads(fp.read_text(encoding="utf-8"))
            except Exception:
                continue
            tup = payload.get("tuple") or {}
            owning = str(tup.get("variable") or "").upper()
            for node in tup.get("nodes") or []:
                for dv in node.get("dependent_variables") or []:
                    canonical.add((owning, str(dv).upper()))

    edges_set = {(e["source"], e["target"]) for e in graph["edges"]}
    if canonical:
        from backward_traversal.graph_extraction.variable_graph_builder import _is_noise  # noqa
        # Tier 4 semantic: the variable_graph must be a SUPERSET of every edge
        # derivable from previously-emitted chunked tuple JSONs. "Phantom" edges
        # (extras in the variable_graph) are legitimate — they come from tuples
        # that exist in the session but haven't been emitted as JSON yet. The
        # only invariant is "no missing edges" relative to the emitted tuples.
        missing = canonical - edges_set
        missing = {(s, t) for (s, t) in missing if not _is_noise(s) and not _is_noise(t) and s != t}
        extras = edges_set - canonical
        chk(len(missing) <= max(2, int(0.05 * max(1, len(canonical)))),
            f"no significant missing edges vs emitted tuple JSONs "
            f"(missing={len(missing)} canonical={len(canonical)})")
        if extras:
            # Confirm every extra edge has at least one location in scope (sanity)
            extra_owning_vars = {s for (s, _) in extras}
            session_vars = {entry["variable"].upper() for entry in session.tuple_index_map}
            unexplained = extra_owning_vars - session_vars
            chk(not unexplained,
                f"extra edges' source vars all map to session tuples "
                f"(extras={len(extras)} sources={sorted(extra_owning_vars)} "
                f"unexplained={sorted(unexplained)})")
    else:
        print("  INFO · no chunked tuple JSONs found for cross-ref; skipping Tier 4")

    if fails:
        print(f"\nFAILED · {len(fails)} check(s)")
        return 1
    print("\nOK · validation passed (Tier 3 + Tier 4)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
