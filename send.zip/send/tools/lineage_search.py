#!/usr/bin/env python3
"""Cross-file lineage search over JSON outputs."""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional

# Allow importing sibling tool without requiring package installation.
_TOOLS_DIR = os.path.dirname(os.path.abspath(__file__))
if _TOOLS_DIR not in sys.path:
    sys.path.insert(0, _TOOLS_DIR)
from search_large_json import surgical_json_extract as _json_extract

# Files larger than this threshold are streamed key-by-key via the sidecar
# index rather than loaded wholesale into RAM.
_SIZE_THRESHOLD = 10 * 1024 * 1024  # 10 MB


def _load_file_safe(path: Path) -> Optional[Dict]:
    """
    Load a per-file analysis JSON, with streaming extraction for large files.

    Files ≤ 10 MB  : standard json.loads — full object in RAM (fast, simple).
    Files  > 10 MB : surgical_json_extract for each key this tool needs.
                     On the first call a sidecar (.jidx) is built so that
                     the second pass of the two-pass scan hits an O(1) seek
                     rather than another O(file_size) read.
    """
    try:
        if path.stat().st_size <= _SIZE_THRESHOLD:
            return json.loads(path.read_text(encoding="utf-8", errors="replace"))
        # Large file: stream-extract only the keys used by this tool.
        result: Dict = {}
        for key in ("variable_lineage", "build_metadata"):
            raw = _json_extract(str(path), key)
            if raw and not raw.startswith(("Key '", "Error")):
                try:
                    result[key] = json.loads(raw)
                except json.JSONDecodeError:
                    pass
        return result if result else None
    except Exception:
        return None


def load_json_files(root: Path) -> List[Path]:
    if root.is_file() and root.suffix == ".json":
        return [root]
    return list(root.rglob("*.json"))


def match_node(node: Dict, name: str, kind: str) -> bool:
    return node.get("name") == name and node.get("kind") == kind


def search_lineage(data: Dict, name: str, kind: str) -> Dict[str, List[Dict]]:
    lineage = data.get("variable_lineage", {})
    nodes = lineage.get("nodes", [])
    edges = lineage.get("edges", [])

    matched_nodes = [n for n in nodes if match_node(n, name, kind)]
    if not matched_nodes:
        return {}

    node_ids = {n.get("id") for n in matched_nodes}

    matched_edges = []
    for edge in edges:
        if edge.get("source") in node_ids or edge.get("target") in node_ids:
            matched_edges.append(edge)

    values_from = []
    calculated_by = []
    used_at = []
    definitions = []

    for edge in matched_edges:
        if edge.get("relation") == "define" and edge.get("source") in node_ids and edge.get("target") in node_ids:
            definitions.append(edge)
        elif edge.get("relation") == "assign" and edge.get("target") in node_ids:
            values_from.append(edge)
        elif edge.get("relation") == "assign" and edge.get("source") in node_ids:
            calculated_by.append(edge)
        elif edge.get("relation") == "use" and edge.get("source") in node_ids:
            used_at.append(edge)

    return {
        "definitions": definitions,
        "values_from": values_from,
        "calculated_by": calculated_by,
        "used_at": used_at
    }


def is_makefile_metadata(build_metadata: Dict) -> bool:
    file_name = Path(build_metadata.get("file", "")).name
    return file_name in {"Makefile", "makefile", "GNUmakefile"} or file_name.endswith(".mak")


def merge_build_context(contexts: List[Dict]) -> Dict[str, List[str]]:
    merged = {
        "defines": set(),
        "include_dirs": set(),
        "lib_dirs": set(),
        "libs": set(),
        "outputs": set(),
        "shared_objects": set(),
        "source_files": set(),
        "external_variables": set(),
    }
    for ctx in contexts:
        for key in merged:
            merged[key].update(ctx.get(key, []))
    return {k: sorted(v) for k, v in merged.items() if v}


def find_build_context(
    file_path: Path,
    root_dir: Path,
    makefile_contexts: Dict[Path, List[Dict]]
) -> Optional[Dict]:
    try:
        rel_parent = file_path.relative_to(root_dir).parent
    except ValueError:
        return None

    candidate = rel_parent
    while True:
        if candidate in makefile_contexts:
            contexts = makefile_contexts[candidate]
            return {
                "context_dir": str(candidate),
                "makefiles": contexts,
                "merged": merge_build_context(contexts),
            }
        if candidate == Path(".") or candidate == candidate.parent:
            break
        candidate = candidate.parent
    return None


def main() -> None:
    parser = argparse.ArgumentParser(description="Search lineage across JSON outputs")
    parser.add_argument("root", help="Root directory or JSON file to search")
    parser.add_argument("--name", required=True, help="Variable/register/memory name")
    parser.add_argument("--kind", required=True, help="Kind: variable, register, memory, literal, use")
    parser.add_argument("--limit", type=int, default=50, help="Max edges to show per section per file")
    parser.add_argument("--scope", help="Filter to a specific scope (function/routine)")
    parser.add_argument("--format", choices=["text", "json"], default="text")
    parser.add_argument("--output-dir", default="output/lineage_search", help="Directory to save search results")

    args = parser.parse_args()
    root = Path(args.root)

    files = load_json_files(root)
    if not files:
        print("No JSON files found")
        return

    root_dir = root if root.is_dir() else root.parent
    makefile_contexts: Dict[Path, List[Dict]] = {}
    for path in files:
        data = _load_file_safe(path)
        if data is None:
            continue
        build_metadata = data.get("build_metadata") or {}
        if build_metadata and is_makefile_metadata(build_metadata):
            rel_parent = path.relative_to(root_dir).parent
            makefile_contexts.setdefault(rel_parent, []).append(build_metadata)

    total_hits = 0
    results = {}

    for path in files:
        data = _load_file_safe(path)
        if data is None:
            continue

        sections = search_lineage(data, args.name, args.kind)
        if not sections:
            continue

        total_hits += 1
        result_entry = sections
        build_context = find_build_context(path, root_dir, makefile_contexts)
        if build_context:
            result_entry = {
                **sections,
                "build_context": build_context,
            }
        results[str(path)] = result_entry

        if args.format == "text":
            print(f"\nFile: {path}")

            def print_section(title: str, items: List[Dict]):
                filtered = [e for e in items if not args.scope or e.get("scope") == args.scope]
                if not filtered:
                    return
                print(f"  {title}:")
                for edge in filtered[: args.limit]:
                    expr = edge.get("expression") or ""
                    scope = edge.get("scope")
                    sid = edge.get("statement_id")
                    print(
                        f"    - {edge.get('source')} -> {edge.get('target')} "
                        f"(line {edge.get('line')}, scope {scope}, stmt {sid}) {expr}"
                    )

            print_section("Definitions", sections["definitions"])
            print_section("Values From", sections["values_from"])
            print_section("Calculated By", sections["calculated_by"])
            print_section("Used At", sections["used_at"])
            if build_context and build_context.get("merged"):
                merged = build_context["merged"]
                print("  Build Context:")
                if merged.get("defines"):
                    print(f"    - defines: {', '.join(merged['defines'][: args.limit])}")
                if merged.get("include_dirs"):
                    print(f"    - include_dirs: {', '.join(merged['include_dirs'][: args.limit])}")
                if merged.get("libs"):
                    print(f"    - libs: {', '.join(merged['libs'][: args.limit])}")
                if merged.get("outputs"):
                    print(f"    - outputs: {', '.join(merged['outputs'][: args.limit])}")

    if args.format == "json":
        print(json.dumps(results, indent=2))

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = output_dir / f"search_{args.name}.json"
    output_file.write_text(json.dumps(results, indent=2))
    print(f"\nSaved: {output_file}")

    if total_hits == 0:
        print("No lineage matches found")


if __name__ == "__main__":
    main()
