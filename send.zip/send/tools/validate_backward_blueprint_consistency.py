#!/usr/bin/env python3
"""Validate blueprint consistency for backward-only traversal (non-failing)."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List

if __package__ in (None, ""):
    sys.path.append(str(Path(__file__).resolve().parents[1]))

from blueprint_io import load_blueprint

from backward_traversal.utils.blueprint_consistency import diagnose_blueprint_consistency


def _iter_blueprints(blueprint_dir: Path) -> List[Path]:
    return sorted(
        list(blueprint_dir.glob("*.asm.json")) +
        list(blueprint_dir.glob("*.mac.json"))
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate backward-only blueprint consistency")
    parser.add_argument(
        "--blueprint-dir",
        default="temp/output_latest/asm",
        help="Directory containing .asm.json/.mac.json blueprints",
    )
    parser.add_argument(
        "--output",
        help="Optional path to write JSON diagnostic report",
    )
    args = parser.parse_args()

    bp_dir = Path(args.blueprint_dir)
    if not bp_dir.exists():
        print(json.dumps({"error": f"Blueprint dir not found: {bp_dir}"}, indent=2))
        return 0

    report: Dict[str, Any] = {
        "blueprint_dir": str(bp_dir),
        "files": {},
        "aggregate": {
            "missing_bas_targets": 0,
            "missing_branch_targets": 0,
            "no_anchor_regions": 0,
            "files_with_warnings": 0,
            "total_files": 0,
        },
    }

    for bp in _iter_blueprints(bp_dir):
        payload = load_blueprint(bp)
        diag = diagnose_blueprint_consistency(payload)
        report["files"][bp.name] = diag
        report["aggregate"]["total_files"] += 1
        for key in ("missing_bas_targets", "missing_branch_targets", "no_anchor_regions"):
            report["aggregate"][key] += int(diag.get("summary", {}).get(key, 0))
        if diag.get("warnings"):
            report["aggregate"]["files_with_warnings"] += 1

    output = json.dumps(report, indent=2)
    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
        print(f"Wrote report to {args.output}")
    else:
        print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
