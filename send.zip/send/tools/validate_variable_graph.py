"""Tiered validation suite for the process-scoped variable connection graph API.

Tiers:
  0  Pre-flight (file layout, scope, Celery, auth-token sanity)
  3  Live structural — msgpack shape, edge/node refs, scope, hash recomputation
  4  Live semantic — cross-reference against chunked lineage tuple JSONs
  5  Live operational — orchestrated via tools/validate_variable_graph_live.sh
  6  Performance / resources

Exits non-zero on the first failure within a tier so the tool can be wired into CI.

Usage:
  python tools/validate_variable_graph.py --tier 0 --job-id X --process P \
       --chain "a,b,c" --variable WK_RRC --token $ADMIN_TOKEN
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


# ---------------------------------------------------------------------------
# Lightweight helpers (no external runtime deps beyond msgpack/requests)
# ---------------------------------------------------------------------------

class FailureCollector:
    def __init__(self) -> None:
        self.failures: List[str] = []

    def check(self, ok: bool, msg: str) -> bool:
        if ok:
            print(f"  PASS · {msg}")
        else:
            print(f"  FAIL · {msg}")
            self.failures.append(msg)
        return ok

    def add(self, msg: str) -> None:
        print(f"  FAIL · {msg}")
        self.failures.append(msg)

    def info(self, msg: str) -> None:
        print(f"  INFO · {msg}")


def _load_msgpack(path: Path) -> Optional[Any]:
    try:
        import msgpack
    except ImportError:
        print("ERROR: msgpack is required (pip install msgpack)", file=sys.stderr)
        sys.exit(2)
    if not path.exists():
        return None
    try:
        return msgpack.unpackb(path.read_bytes(), raw=False, strict_map_key=False)
    except Exception as exc:
        print(f"  FAIL · msgpack unpack: {exc}")
        return None


def _http_get_json(url: str, token: Optional[str]) -> Tuple[int, Any]:
    import urllib.request
    req = urllib.request.Request(url)
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = resp.read().decode("utf-8")
            return resp.status, json.loads(data) if data else None
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8")
            return exc.code, json.loads(body) if body else body
        except Exception:
            return exc.code, None


def _http_post_json(url: str, token: Optional[str], body: Dict[str, Any]) -> Tuple[int, Any]:
    import urllib.request
    payload = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=payload, method="POST")
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        try:
            return exc.code, json.loads(exc.read().decode("utf-8"))
        except Exception:
            return exc.code, None


# ---------------------------------------------------------------------------
# Path helpers — must match api/processes/scope.py + api/tasks/variable_graph_task
# ---------------------------------------------------------------------------

def job_output_dir(jobs_base: Path, job_id: str) -> Path:
    return jobs_base / job_id / "output"


def process_lineage_dir(job_id: str, jobs_base: Path, process_name: str) -> Path:
    return job_output_dir(jobs_base, job_id) / "process_lineage" / process_name


def variable_graph_msgpack(job_id: str, jobs_base: Path, process_name: str) -> Path:
    return process_lineage_dir(job_id, jobs_base, process_name) / "variable_graph.msgpack"


# ---------------------------------------------------------------------------
# Tier 0 — Pre-flight
# ---------------------------------------------------------------------------

def tier0(args, fc: FailureCollector) -> bool:
    print("== Tier 0: Pre-flight ==")
    jobs_base = Path(args.jobs_base or PROJECT_ROOT / "jobs")
    out = job_output_dir(jobs_base, args.job_id)
    fc.info(f"jobs_base={jobs_base}")
    fc.info(f"output_dir={out}")

    fc.check(out.exists(), f"output dir exists: {out}")
    fc.check((out / "file_call_graph.json").is_file(), "global file_call_graph.json present")
    fc.check(
        (out / "processes" / args.process / "file_graph.json").is_file(),
        f"processes/{args.process}/file_graph.json present",
    )

    chain = [s.strip() for s in args.chain.split(",") if s.strip()]
    fc.check(len(chain) >= 2, f"chain has ≥2 entries (got {len(chain)})")

    # Scope membership
    file_graph_path = out / "processes" / args.process / "file_graph.json"
    if file_graph_path.is_file():
        scope_files: Set[str] = set()
        try:
            data = json.loads(file_graph_path.read_text(encoding="utf-8"))
            for f in data.get("files") or []:
                if isinstance(f, dict):
                    raw = f.get("path") or f.get("file") or ""
                else:
                    raw = f
                stem = Path(str(raw)).stem
                if stem:
                    scope_files.add(stem.lower())
            for n in data.get("nodes") or []:
                nid = str(n.get("id") or "") if isinstance(n, dict) else str(n)
                if nid:
                    scope_files.add(nid.lower())
        except Exception as exc:
            fc.add(f"file_graph.json parse failed: {exc}")
        outside = [c for c in chain if c.lower() not in scope_files]
        if outside:
            fc.add(f"chain files outside process scope: {outside}")
        else:
            fc.info(f"chain files all in scope ({len(chain)})")

    # Token presence (for the live tiers)
    if args.token:
        fc.info("--token provided; live tiers can run")
    else:
        fc.info("no --token; tier 0 does not require auth, but tiers 3–5 do")

    return not fc.failures


# ---------------------------------------------------------------------------
# Tier 3 — Live structural validation
# ---------------------------------------------------------------------------

_VAR_NAME_RE = re.compile(r"^[A-Z@$_][A-Z0-9@$_]*$")


def _recompute_chain_hash(
    job_id: str,
    process_name: str,
    variable: str,
    chain_files: List[str],
    caps: Dict[str, Any],
    graph_mtime: float,
) -> str:
    raw = json.dumps(
        {
            "kb_id": job_id,
            "process": process_name,
            "variable": variable.upper(),
            "chain_files": list(chain_files),
            "options": {
                k: caps.get(k)
                for k in (
                    "max_depth", "max_subroutine_depth", "max_subroutine_nodes", "max_trace_nodes",
                    "max_dep_vars", "max_dep_var_depth", "max_downstream_depth", "max_downstream_files",
                    "t8_max_scan",
                )
            },
            "mtime": str(graph_mtime),
            "schema_version": 1,
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def tier3(args, fc: FailureCollector) -> bool:
    print("== Tier 3: Live structural ==")
    jobs_base = Path(args.jobs_base or PROJECT_ROOT / "jobs")
    out = job_output_dir(jobs_base, args.job_id)
    mp_path = variable_graph_msgpack(args.job_id, jobs_base, args.process)
    if not fc.check(mp_path.exists(), f"variable_graph.msgpack present at {mp_path}"):
        return False

    cache = _load_msgpack(mp_path)
    fc.check(isinstance(cache, dict), "msgpack top-level is dict")
    if not isinstance(cache, dict):
        return False

    root_up = args.variable.upper()
    var_entry = cache.get(root_up)
    fc.check(isinstance(var_entry, dict), f"top-level key '{root_up}' present and is dict")
    if not isinstance(var_entry, dict):
        return False

    chain_hash = args.chain_hash
    if chain_hash:
        graph = var_entry.get(chain_hash)
        fc.check(isinstance(graph, dict), f"chain_hash '{chain_hash}' present")
    else:
        # Pick the first entry deterministically
        if not var_entry:
            fc.add("no chain_hash entries under variable")
            return False
        chain_hash = sorted(var_entry.keys())[0]
        graph = var_entry[chain_hash]
        fc.info(f"using chain_hash={chain_hash}")

    if not isinstance(graph, dict):
        return False

    required = {
        "schema_version", "root_variable", "chain_files", "chain_hash",
        "caps", "computed_at", "node_count", "edge_count",
        "nodes", "edges", "warnings",
    }
    missing_keys = required - set(graph.keys())
    fc.check(not missing_keys, f"all required keys present (missing: {sorted(missing_keys)})")

    nodes = graph.get("nodes") or []
    edges = graph.get("edges") or []
    names = {n.get("name") for n in nodes}

    # Refs
    dangling: List[str] = []
    for e in edges:
        if e.get("source") not in names:
            dangling.append(f"source {e.get('source')} -> {e.get('target')}")
        if e.get("target") not in names:
            dangling.append(f"target {e.get('source')} -> {e.get('target')}")
    fc.check(not dangling, f"no dangling edge refs (found {len(dangling)})")

    # Root marking
    roots = [n for n in nodes if n.get("is_root")]
    fc.check(len(roots) == 1 and roots and roots[0].get("name") == root_up,
             "exactly one is_root node, equals root_variable")

    # Scope membership
    file_graph_path = out / "processes" / args.process / "file_graph.json"
    scope_lower: Set[str] = set()
    if file_graph_path.is_file():
        try:
            data = json.loads(file_graph_path.read_text(encoding="utf-8"))
            for f in data.get("files") or []:
                if isinstance(f, dict):
                    raw = f.get("path") or f.get("file") or ""
                else:
                    raw = f
                stem = Path(str(raw)).stem
                if stem:
                    scope_lower.add(stem.lower())
            for n in data.get("nodes") or []:
                nid = str(n.get("id") or "") if isinstance(n, dict) else str(n)
                if nid:
                    scope_lower.add(nid.lower())
        except Exception as exc:
            fc.add(f"scope parse error: {exc}")

    out_of_scope: List[str] = []
    for n in nodes:
        for loc in n.get("locations") or []:
            f = str(loc.get("file") or "").lower()
            if f and scope_lower and f not in scope_lower:
                out_of_scope.append(f"{n['name']}@{f}")
    for e in edges:
        for loc in e.get("locations") or []:
            f = str(loc.get("file") or "").lower()
            if f and scope_lower and f not in scope_lower:
                out_of_scope.append(f"{e['source']}->{e['target']}@{f}")
    fc.check(not out_of_scope, f"no out-of-scope locations (found {len(out_of_scope)})")

    # Line/instruction sanity
    bad_lines: List[str] = []
    for e in edges:
        for loc in e.get("locations") or []:
            if str(loc.get("instruction") or "").upper() == "CPP":
                continue
            ln = int(loc.get("line") or 0)
            if ln < 0:
                bad_lines.append(f"{e['source']}->{e['target']}@{ln}")
    fc.check(not bad_lines, f"no negative line numbers (found {len(bad_lines)})")

    # Variable-name allow-list
    bad_names = [n.get("name") for n in nodes if not _VAR_NAME_RE.match(str(n.get("name") or ""))]
    fc.check(not bad_names, f"all node names pass variable allow-list (bad: {bad_names[:5]})")

    # warnings shape
    warnings = graph.get("warnings") or []
    fc.check(
        isinstance(warnings, list) and all(isinstance(w, str) for w in warnings),
        "warnings is a list of strings",
    )

    # chain_hash recomputation (against the materialized filtered graph mtime).
    # Skip when the stored chain_hash looks like an opaque user tag
    # (e.g. from the offline validator), not a 16-hex hash.
    stored_hash = str(graph.get("chain_hash") or "")
    if re.fullmatch(r"[0-9a-f]{16}", stored_hash):
        chain_files = graph.get("chain_files") or []
        caps = graph.get("caps") or {}
        filtered_graph = out / "process_lineage" / args.process / "file_call_graph.json"
        if filtered_graph.is_file():
            recomputed = _recompute_chain_hash(
                args.job_id, args.process, args.variable, chain_files, caps,
                filtered_graph.stat().st_mtime,
            )
            fc.check(
                recomputed == stored_hash,
                f"chain_hash reproducible (stored={stored_hash} recomputed={recomputed})",
            )
    else:
        fc.info(f"chain_hash '{stored_hash}' looks like an opaque tag; skipping recompute")

    return not fc.failures


# ---------------------------------------------------------------------------
# Tier 4 — Live semantic / cross-reference validation
# ---------------------------------------------------------------------------

def tier4(args, fc: FailureCollector) -> bool:
    print("== Tier 4: Live semantic / cross-reference ==")
    jobs_base = Path(args.jobs_base or PROJECT_ROOT / "jobs")
    out = job_output_dir(jobs_base, args.job_id)
    mp_path = variable_graph_msgpack(args.job_id, jobs_base, args.process)

    cache = _load_msgpack(mp_path)
    if not isinstance(cache, dict):
        fc.add("cannot load variable_graph.msgpack")
        return False

    root_up = args.variable.upper()
    var_entry = cache.get(root_up) or {}
    chain_hash = args.chain_hash or (sorted(var_entry.keys())[0] if var_entry else None)
    if not chain_hash or chain_hash not in var_entry:
        fc.add("no chain_hash entry to validate")
        return False
    graph = var_entry[chain_hash]

    # Collect (source, target) edges
    edges_set: Set[Tuple[str, str]] = {
        (e["source"], e["target"]) for e in (graph.get("edges") or [])
    }
    if not edges_set:
        fc.info("graph has zero edges; semantic check trivially passes")
        return True

    # Walk chunked lineage tuple JSONs (canonical source of truth).
    bl_dir = out / "process_lineage" / args.process / "backward_lineage"
    if not bl_dir.is_dir():
        fc.info(f"no chunked lineage output at {bl_dir}; skipping cross-ref")
        return True

    canonical: Set[Tuple[str, str]] = set()
    asm_files: List[Path] = sorted(bl_dir.glob(f"{args.variable}_tuple_*.json"))
    if not asm_files:
        fc.info(f"no {args.variable}_tuple_*.json files; skipping cross-ref")
        return True

    for fp in asm_files:
        try:
            payload = json.loads(fp.read_text(encoding="utf-8"))
        except Exception as exc:
            fc.info(f"skip {fp.name}: {exc}")
            continue
        tup = payload.get("tuple") or {}
        owning = str(tup.get("variable") or "").upper()
        for node in tup.get("nodes") or []:
            for dv in node.get("dependent_variables") or []:
                dv_up = str(dv or "").upper()
                if not dv_up:
                    continue
                canonical.add((owning, dv_up))

    if not canonical:
        fc.info("could not derive canonical edges from chunked tuples; skipping")
        return True

    # Missing = canonical edge in scope not in our graph.
    # Phantom (extras in our graph) are legitimate — the variable_graph walks
    # the full session, while the canonical tuple JSONs only reflect those
    # tuples that have been emitted via the chunked endpoint. We therefore
    # only enforce: no missing edges relative to the emitted JSONs.
    missing = canonical - edges_set

    from backward_traversal.graph_extraction.variable_graph_builder import _is_noise  # type: ignore

    missing_filtered = {
        (s, t) for (s, t) in missing
        if not _is_noise(s) and not _is_noise(t) and s != t
    }

    fc.check(
        len(missing_filtered) <= max(2, int(0.05 * len(canonical))),
        f"no significant missing edges vs emitted tuple JSONs "
        f"(missing≈{len(missing_filtered)} / {len(canonical)})",
    )
    if missing_filtered:
        fc.info(f"sample missing edges: {list(missing_filtered)[:5]}")

    extras = edges_set - canonical
    if extras:
        fc.info(
            f"{len(extras)} extra edge(s) in variable_graph vs emitted tuples "
            "(expected: session contains tuples not yet emitted as JSON)"
        )

    return not fc.failures


# ---------------------------------------------------------------------------
# Tier 5 — Live operational (driven by the orchestrator shell script)
# ---------------------------------------------------------------------------

def tier5(args, fc: FailureCollector) -> bool:
    print("== Tier 5: Live operational ==")
    api = args.api_base or os.environ.get("API_BASE") or "http://localhost:8000"
    token = args.token or os.environ.get("ADMIN_TOKEN")
    if not token:
        fc.add("no auth token (--token or $ADMIN_TOKEN)")
        return False

    chain = [s.strip() for s in args.chain.split(",") if s.strip()]
    base = f"{api}/v1/jobs/{args.job_id}/processes/{args.process}/variable-graph"

    body = {
        "variable_name": args.variable,
        "chain_files": chain,
        "force": False,
    }
    code, resp = _http_post_json(base, token, body)
    fc.check(code in (200, 202), f"POST variable-graph returned {code}")
    if not resp:
        fc.add("empty POST response body")
        return False
    fc.info(f"POST response: {json.dumps(resp)[:200]}")

    chain_hash = (resp or {}).get("chain_hash")
    fc.check(bool(chain_hash), "POST returned chain_hash")

    # Re-POST → expect cache_hit
    code2, resp2 = _http_post_json(base, token, body)
    if (resp2 or {}).get("status") == "cached":
        fc.check(True, "re-POST hit cache")
    else:
        fc.info("re-POST did not hit cache (task may still be running)")

    # GET fetch (will 404 until the task completes; informational only)
    if chain_hash:
        code3, _ = _http_get_json(
            f"{base}?variable_name={args.variable}&chain_hash={chain_hash}", token
        )
        fc.info(f"GET .../variable-graph returned {code3} (may be 404 if task still running)")

    return not fc.failures


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--tier", action="append", type=int, choices=[0, 3, 4, 5, 6])
    ap.add_argument("--job-id", required=True)
    ap.add_argument("--process", required=True)
    ap.add_argument("--chain", default="", help="comma-separated chain stems")
    ap.add_argument("--variable", required=True)
    ap.add_argument("--chain-hash", default=None,
                    help="if omitted, the first chain_hash entry under variable is used")
    ap.add_argument("--api-base", default=None)
    ap.add_argument("--token", default=None)
    ap.add_argument("--jobs-base", default=None)
    args = ap.parse_args()

    tiers = sorted(set(args.tier or [0, 3, 4]))
    fc = FailureCollector()
    for t in tiers:
        if t == 0:
            tier0(args, fc)
        elif t == 3:
            tier3(args, fc)
        elif t == 4:
            tier4(args, fc)
        elif t == 5:
            tier5(args, fc)
        elif t == 6:
            print("== Tier 6 (perf) ==")
            print("  INFO · perf tier is a manual measurement; see tools/validate_variable_graph_live.sh")
        print()

    if fc.failures:
        print(f"FAILED · {len(fc.failures)} check(s)")
        for f in fc.failures:
            print(f"  - {f}")
        return 1
    print("OK · all checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
