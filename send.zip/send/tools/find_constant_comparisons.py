#!/usr/bin/env python3
"""Find every C/C++ condition where a variable is compared to a given constant.

Walks a tree-sitter AST and reports every comparison expression
(`==`, `!=`, `<`, `>`, `<=`, `>=`) where one operand evaluates to the
target constant and the other is anything else. Also reports `switch`
case labels whose value equals the constant.

Features
========
* Numeric literals in any base + suffixes:  5, 0x10, 0b101, 05, 0777, 5ULL
* Char literals matched against integer code points:  'A' == 65
* Parens, C-style casts, C++ named casts, and function-style casts (int(5))
* #define object-like macros that expand to integer expressions
* #define function-like macros, expanded at each call site
* enum constants (including auto-incremented values)
* const-int file-scope declarations
* Compile-time integer arithmetic on either operand
* sizeof(primitive) resolved per target model (LP64 default)
* Standard-library macro constants seeded: NULL, EOF, EXIT_SUCCESS, EXIT_FAILURE
* #include resolution: quote-includes relative to source, angle-includes via
  --include-dir; headers are scanned recursively for named constants
* #if / #ifdef / #ifndef branches: subtrees inside provably-inactive branches
  are skipped (so a comparison inside `#if 0 ... #endif` is not reported)
* Optional implicit truthiness matching via --include-truthy (k=0 only)

Usage:
    find_constant_comparisons.py [options] <file> <constant>
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

COMPARISON_OPS = {"==", "!=", "<", ">", "<=", ">="}

_CHAR_ESCAPE = {
    "n": 10, "t": 9, "r": 13, "0": 0, "\\": 92, "'": 39,
    '"': 34, "a": 7, "b": 8, "f": 12, "v": 11, "?": 63,
}

_CXX_CAST_NAMES = {"static_cast", "const_cast", "reinterpret_cast", "dynamic_cast"}

_PRIMITIVE_TYPE_NAMES = {
    "void", "bool", "char", "short", "int", "long", "float", "double",
    "signed", "unsigned", "size_t", "ssize_t", "ptrdiff_t",
    "int8_t", "int16_t", "int32_t", "int64_t",
    "uint8_t", "uint16_t", "uint32_t", "uint64_t",
}

_CONTEXT_NODES = {
    "if_statement": "if",
    "while_statement": "while",
    "for_statement": "for",
    "do_statement": "do_while",
    "conditional_expression": "ternary",
    "switch_statement": "switch",
    "return_statement": "return",
    "assignment_expression": "assign",
    "init_declarator": "assign",
}

_BUILTIN_INT_CONSTANTS: Dict[str, int] = {
    "NULL": 0,
    "EOF": -1,
    "EXIT_SUCCESS": 0,
    "EXIT_FAILURE": 1,
}

_TARGET_MODELS: Dict[str, Dict[str, int]] = {
    # primitive type name -> bytes
    "LP64": {  # Linux/macOS x86_64
        "bool": 1, "char": 1, "signed char": 1, "unsigned char": 1,
        "short": 2, "unsigned short": 2,
        "int": 4, "unsigned int": 4, "unsigned": 4,
        "long": 8, "unsigned long": 8,
        "long long": 8, "unsigned long long": 8,
        "float": 4, "double": 8, "long double": 16,
        "size_t": 8, "ssize_t": 8, "ptrdiff_t": 8,
        "int8_t": 1, "int16_t": 2, "int32_t": 4, "int64_t": 8,
        "uint8_t": 1, "uint16_t": 2, "uint32_t": 4, "uint64_t": 8,
    },
    "LLP64": {  # Windows x86_64
        "bool": 1, "char": 1, "signed char": 1, "unsigned char": 1,
        "short": 2, "unsigned short": 2,
        "int": 4, "unsigned int": 4, "unsigned": 4,
        "long": 4, "unsigned long": 4,
        "long long": 8, "unsigned long long": 8,
        "float": 4, "double": 8, "long double": 8,
        "size_t": 8, "ssize_t": 8, "ptrdiff_t": 8,
        "int8_t": 1, "int16_t": 2, "int32_t": 4, "int64_t": 8,
        "uint8_t": 1, "uint16_t": 2, "uint32_t": 4, "uint64_t": 8,
    },
    "ILP32": {  # 32-bit Linux/macOS
        "bool": 1, "char": 1, "signed char": 1, "unsigned char": 1,
        "short": 2, "unsigned short": 2,
        "int": 4, "unsigned int": 4, "unsigned": 4,
        "long": 4, "unsigned long": 4,
        "long long": 8, "unsigned long long": 8,
        "float": 4, "double": 8, "long double": 12,
        "size_t": 4, "ssize_t": 4, "ptrdiff_t": 4,
        "int8_t": 1, "int16_t": 2, "int32_t": 4, "int64_t": 8,
        "uint8_t": 1, "uint16_t": 2, "uint32_t": 4, "uint64_t": 8,
    },
}


# ---------------------------------------------------------------------------
# Literal parsing
# ---------------------------------------------------------------------------

def _strip_int_suffix(text: str) -> str:
    return re.sub(r"[uUlL]+$", "", text)


def _parse_int_literal(text: str) -> Optional[int]:
    t = _strip_int_suffix(text.strip()).replace("'", "")
    if not t:
        return None
    sign = 1
    if t[0] in "+-":
        if t[0] == "-":
            sign = -1
        t = t[1:]
    if not t:
        return None
    try:
        if len(t) >= 2 and t[0] == "0" and t[1] not in "xXbBoO" and t[1:].isdigit():
            return sign * int(t, 8)
        return sign * int(t, 0)
    except ValueError:
        return None


def _parse_char_literal(text: str) -> Optional[int]:
    t = text.strip()
    m = re.match(r"^(?:u8|[LuU])?'(.*)'$", t, re.DOTALL)
    if not m:
        return None
    body = m.group(1)
    if not body:
        return None
    if body[0] != "\\":
        return ord(body) if len(body) == 1 else None
    esc = body[1:]
    if esc in _CHAR_ESCAPE:
        return _CHAR_ESCAPE[esc]
    if esc.startswith("x"):
        try:
            return int(esc[1:], 16)
        except ValueError:
            return None
    if esc and all(c in "01234567" for c in esc):
        try:
            return int(esc, 8)
        except ValueError:
            return None
    return None


def parse_constant(k: str) -> Tuple[str, Any]:
    k = k.strip()
    if (k.startswith("'") and k.endswith("'")) or re.match(r"^(?:u8|[LuU])'", k):
        v = _parse_char_literal(k)
        if v is not None:
            return ("int", v)
    v = _parse_int_literal(k)
    if v is not None:
        return ("int", v)
    if re.match(r"^[A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*$", k):
        return ("symbol", k)
    raise ValueError(f"Cannot parse constant {k!r} — expected integer, char literal, or identifier")


# ---------------------------------------------------------------------------
# tree-sitter setup
# ---------------------------------------------------------------------------

def init_parser(language: str):
    from tree_sitter import Language, Parser
    lang_name = language.lower()
    if lang_name in ("cpp", "c++"):
        import tree_sitter_cpp as _ts
    elif lang_name == "c":
        import tree_sitter_c as _ts
    else:
        raise ValueError(f"Unsupported language: {language}")
    lang_obj = Language(_ts.language())
    try:
        return Parser(lang_obj)
    except TypeError:
        parser = Parser()
        if hasattr(parser, "set_language"):
            parser.set_language(lang_obj)
        else:
            parser.language = lang_obj
        return parser


def node_text(node, source: bytes) -> str:
    return source[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def walk(root):
    stack = [root]
    while stack:
        n = stack.pop()
        yield n
        for i in range(n.child_count - 1, -1, -1):
            stack.append(n.children[i])


def in_skipped_region(node, skip_ranges: List[Tuple[int, int]]) -> bool:
    if not skip_ranges:
        return False
    s = node.start_byte
    for a, b in skip_ranges:
        if a <= s < b:
            return True
    return False


# ---------------------------------------------------------------------------
# AST unwrap helpers (parens, casts, condition_clause)
# ---------------------------------------------------------------------------

def _unwrap_cxx_cast_call(node, source: bytes):
    if node.type != "call_expression":
        return None
    fn = node.child_by_field_name("function")
    args = node.child_by_field_name("arguments")
    if fn is None or args is None:
        return None
    if fn.type != "template_function":
        return None
    name_node = fn.child_by_field_name("name")
    if name_node is None:
        for c in fn.children:
            if c.type == "identifier":
                name_node = c
                break
    if name_node is None:
        return None
    if node_text(name_node, source) not in _CXX_CAST_NAMES:
        return None
    named_args = [c for c in args.children if c.is_named]
    if len(named_args) != 1:
        return None
    return named_args[0]


def _unwrap_function_style_cast(node, source: bytes):
    """Function-style cast: `int(5)`, `unsigned(x)`, `MyTypedef(v)` — descend."""
    if node.type != "call_expression":
        return None
    fn = node.child_by_field_name("function")
    args = node.child_by_field_name("arguments")
    if fn is None or args is None:
        return None
    if fn.type in ("primitive_type", "type_identifier", "sized_type_specifier"):
        pass
    elif fn.type == "identifier" and node_text(fn, source).strip() in _PRIMITIVE_TYPE_NAMES:
        pass
    else:
        return None
    named_args = [c for c in args.children if c.is_named]
    if len(named_args) != 1:
        return None
    return named_args[0]


def unwrap(node, source: bytes):
    seen = 0
    while node is not None and seen < 16:
        seen += 1
        if node.type in ("parenthesized_expression", "condition_clause"):
            inner = None
            for c in node.children:
                if c.is_named:
                    inner = c
                    break
            if inner is None:
                return node
            node = inner
            continue
        if node.type == "cast_expression":
            inner = node.child_by_field_name("value")
            if inner is None:
                named = [c for c in node.children if c.is_named]
                inner = named[-1] if named else None
            if inner is None:
                return node
            node = inner
            continue
        cxx_inner = _unwrap_cxx_cast_call(node, source)
        if cxx_inner is not None:
            node = cxx_inner
            continue
        fcast_inner = _unwrap_function_style_cast(node, source)
        if fcast_inner is not None:
            node = fcast_inner
            continue
        break
    return node


def get_binop_parts(node, source: bytes):
    left = node.child_by_field_name("left")
    right = node.child_by_field_name("right")
    op_node = node.child_by_field_name("operator")
    if left is not None and right is not None and op_node is not None:
        return left, node_text(op_node, source), right
    named = [c for c in node.children if c.is_named]
    ops = [c for c in node.children if not c.is_named]
    op_text = next((node_text(o, source) for o in ops if node_text(o, source)), None)
    if len(named) >= 2 and op_text:
        return named[0], op_text, named[-1]
    return None


# ---------------------------------------------------------------------------
# Compile-time integer evaluation
# ---------------------------------------------------------------------------

def _c_div(a: int, b: int) -> Optional[int]:
    if b == 0:
        return None
    q = abs(a) // abs(b)
    return q if (a >= 0) == (b >= 0) else -q


def _c_mod(a: int, b: int) -> Optional[int]:
    if b == 0:
        return None
    r = abs(a) % abs(b)
    return r if a >= 0 else -r


def _eval_sizeof(node, source: bytes, sizeof_table: Dict[str, int]) -> Optional[int]:
    type_desc = node.child_by_field_name("type")
    if type_desc is None:
        for c in node.children:
            if c.type == "type_descriptor":
                type_desc = c
                break
    if type_desc is None:
        return None
    tokens = []
    for c in type_desc.children:
        if c.type in ("primitive_type", "sized_type_specifier", "type_qualifier"):
            t = node_text(c, source).strip()
            if t in ("signed", "unsigned", "char", "short", "int", "long",
                     "float", "double", "bool"):
                tokens.append(t)
            elif t in _PRIMITIVE_TYPE_NAMES:
                tokens.append(t)
            else:
                tokens.append(t)
        elif c.type == "type_identifier":
            tokens.append(node_text(c, source).strip())
    if not tokens:
        return None
    key = " ".join(tokens)
    if key in sizeof_table:
        return sizeof_table[key]
    # Try without leading 'signed'/'unsigned'
    if len(tokens) > 1 and tokens[0] in ("signed", "unsigned"):
        alt = " ".join(tokens[1:])
        if alt in sizeof_table and tokens[0] == "unsigned":
            return sizeof_table.get(key, sizeof_table.get(alt))
        if alt in sizeof_table:
            return sizeof_table[alt]
    if len(tokens) == 1 and tokens[0] in sizeof_table:
        return sizeof_table[tokens[0]]
    return None


def _eval_const_int(node, source: bytes, named: Dict[str, int],
                    sizeof_table: Optional[Dict[str, int]] = None,
                    depth: int = 0) -> Optional[int]:
    if depth > 32 or node is None:
        return None
    node = unwrap(node, source)
    if node is None:
        return None
    t = node.type
    if t == "number_literal":
        return _parse_int_literal(node_text(node, source))
    if t == "char_literal":
        return _parse_char_literal(node_text(node, source))
    if t == "true":
        return 1
    if t == "false":
        return 0
    if t in ("null", "nullptr"):
        return 0
    if t == "identifier":
        return named.get(node_text(node, source))
    if t in ("qualified_identifier", "scoped_identifier"):
        key = re.sub(r"\s+", "", node_text(node, source))
        return named.get(key)
    if t == "sizeof_expression":
        if sizeof_table is None:
            return None
        return _eval_sizeof(node, source, sizeof_table)
    if t == "unary_expression":
        op_node = node.child_by_field_name("operator")
        operand = node.child_by_field_name("argument")
        if op_node is None or operand is None:
            named_ch = [c for c in node.children if c.is_named]
            unnamed_ch = [c for c in node.children if not c.is_named]
            if not named_ch or not unnamed_ch:
                return None
            op_node = unnamed_ch[0]
            operand = named_ch[-1]
        v = _eval_const_int(operand, source, named, sizeof_table, depth + 1)
        if v is None:
            return None
        op = node_text(op_node, source)
        if op == "-":  return -v
        if op == "+":  return v
        if op == "~":  return ~v
        if op == "!":  return 0 if v else 1
        return None
    if t == "binary_expression":
        parts = get_binop_parts(node, source)
        if parts is None:
            return None
        left, op, right = parts
        lv = _eval_const_int(left, source, named, sizeof_table, depth + 1)
        rv = _eval_const_int(right, source, named, sizeof_table, depth + 1)
        if lv is None or rv is None:
            return None
        try:
            if op == "+":  return lv + rv
            if op == "-":  return lv - rv
            if op == "*":  return lv * rv
            if op == "/":  return _c_div(lv, rv)
            if op == "%":  return _c_mod(lv, rv)
            if op == "<<": return lv << rv
            if op == ">>": return lv >> rv
            if op == "&":  return lv & rv
            if op == "|":  return lv | rv
            if op == "^":  return lv ^ rv
            if op == "&&": return 1 if (lv and rv) else 0
            if op == "||": return 1 if (lv or rv) else 0
            if op == "==": return 1 if lv == rv else 0
            if op == "!=": return 1 if lv != rv else 0
            if op == "<":  return 1 if lv < rv else 0
            if op == ">":  return 1 if lv > rv else 0
            if op == "<=": return 1 if lv <= rv else 0
            if op == ">=": return 1 if lv >= rv else 0
        except (ValueError, OverflowError):
            return None
    if t == "conditional_expression":
        cond = node.child_by_field_name("condition")
        cons = node.child_by_field_name("consequence")
        alt = node.child_by_field_name("alternative")
        if cond is None or cons is None or alt is None:
            return None
        cv = _eval_const_int(cond, source, named, sizeof_table, depth + 1)
        if cv is None:
            return None
        return _eval_const_int(cons if cv else alt, source, named, sizeof_table, depth + 1)
    return None


# ---------------------------------------------------------------------------
# Named-constant table (#define, enum, const int) — single-file pass
# ---------------------------------------------------------------------------

def _collect_named_constants_into(
    named: Dict[str, int],
    func_macros: Dict[str, Tuple[List[str], str]],
    root,
    source: bytes,
    parser,
    sizeof_table: Optional[Dict[str, int]],
):
    """Walk a single AST, mutating `named` (object-like macros, enums,
    const ints) and `func_macros` (function-like macros)."""

    def reparse_expression(text: str) -> Optional[int]:
        t = text.strip()
        while t.startswith("(") and t.endswith(")"):
            t = t[1:-1].strip()
        v = _parse_int_literal(t)
        if v is not None:
            return v
        wrapped = ("int __cfc_val__ = " + text + ";").encode("utf-8", errors="replace")
        try:
            tree = parser.parse(wrapped)
        except Exception:
            return None
        for n in walk(tree.root_node):
            if n.type == "init_declarator":
                v_node = n.child_by_field_name("value")
                if v_node is not None:
                    return _eval_const_int(v_node, wrapped, named, sizeof_table)
        return None

    for node in walk(root):
        if node.type == "preproc_def":
            name_node = node.child_by_field_name("name")
            value_node = node.child_by_field_name("value")
            if name_node is None or value_node is None:
                continue
            name = node_text(name_node, source).strip()
            val_text = node_text(value_node, source).strip()
            if not val_text:
                # Macro defined with no value — record as 1 for #ifdef purposes
                named.setdefault(name, 1)
                continue
            v = reparse_expression(val_text)
            if v is not None:
                named[name] = v
            else:
                # Unknown body — still record presence so #ifdef sees it as defined
                named.setdefault(name, 1)

        elif node.type == "preproc_function_def":
            name_node = node.child_by_field_name("name")
            params_node = node.child_by_field_name("parameters")
            value_node = node.child_by_field_name("value")
            if name_node is None or value_node is None:
                continue
            name = node_text(name_node, source).strip()
            params: List[str] = []
            if params_node is not None:
                for c in params_node.children:
                    if c.type == "identifier":
                        params.append(node_text(c, source).strip())
            body = node_text(value_node, source).strip()
            func_macros[name] = (params, body)
            named.setdefault(name, 1)

        elif node.type == "enumerator_list":
            counter: Optional[int] = 0
            for c in node.children:
                if c.type != "enumerator":
                    continue
                n = c.child_by_field_name("name")
                v_node = c.child_by_field_name("value")
                if n is None:
                    continue
                ename = node_text(n, source).strip()
                if v_node is not None:
                    v = _eval_const_int(v_node, source, named, sizeof_table)
                    if v is not None:
                        counter = v
                    else:
                        counter = None
                if counter is not None:
                    named[ename] = counter
                    counter += 1

        elif node.type == "declaration":
            has_const = any(
                c.type == "type_qualifier" and node_text(c, source).strip() == "const"
                for c in node.children
            )
            if not has_const:
                continue
            for c in node.children:
                if c.type != "init_declarator":
                    continue
                decl = c.child_by_field_name("declarator")
                val = c.child_by_field_name("value")
                if decl is None or val is None:
                    continue
                m = re.search(r"\b([A-Za-z_]\w*)\b", node_text(decl, source))
                if not m:
                    continue
                v = _eval_const_int(val, source, named, sizeof_table)
                if v is not None:
                    named[m.group(1)] = v


# ---------------------------------------------------------------------------
# Header following
# ---------------------------------------------------------------------------

_SYSTEM_HEADER_BLACKLIST = {
    "cstddef", "cstdio", "cstdlib", "cstring", "cmath", "ctime",
    "iostream", "fstream", "sstream", "iomanip", "string", "vector",
    "map", "set", "list", "deque", "queue", "stack", "array",
    "memory", "algorithm", "functional", "utility", "tuple",
    "stdexcept", "exception", "type_traits", "limits", "numeric",
    "stdio.h", "stdlib.h", "string.h", "math.h", "time.h",
    "stddef.h", "assert.h", "limits.h", "errno.h",
}


def _resolve_include(spec_text: str, is_system: bool,
                     source_dir: Path, include_dirs: List[Path]) -> Optional[Path]:
    name = spec_text.strip().strip('"<>')
    if not name:
        return None
    if not is_system:
        candidate = (source_dir / name).resolve()
        if candidate.exists():
            return candidate
    for d in include_dirs:
        candidate = (d / name).resolve()
        if candidate.exists():
            return candidate
    return None


def _gather_header_paths(
    root, source: bytes, source_dir: Path,
    include_dirs: List[Path],
) -> List[Tuple[Path, bool]]:
    """Return [(path, is_system), ...] for every #include in this file."""
    out: List[Tuple[Path, bool]] = []
    for n in walk(root):
        if n.type != "preproc_include":
            continue
        for c in n.children:
            if c.type == "system_lib_string":
                stem = node_text(c, source).strip().strip("<>")
                if stem in _SYSTEM_HEADER_BLACKLIST:
                    continue
                p = _resolve_include(stem, True, source_dir, include_dirs)
                if p is not None:
                    out.append((p, True))
                break
            if c.type == "string_literal":
                inner = None
                for cc in c.children:
                    if cc.type == "string_content":
                        inner = node_text(cc, source).strip()
                        break
                if inner is None:
                    inner = node_text(c, source).strip().strip('"')
                p = _resolve_include(inner, False, source_dir, include_dirs)
                if p is not None:
                    out.append((p, False))
                break
    return out


def _scan_headers_recursive(
    seed_paths: List[Tuple[Path, bool]],
    parser,
    include_dirs: List[Path],
    named: Dict[str, int],
    func_macros: Dict[str, Tuple[List[str], str]],
    sizeof_table: Optional[Dict[str, int]],
    max_depth: int = 5,
):
    queue: List[Tuple[Path, int]] = [(p, 0) for p, _ in seed_paths]
    seen: Set[Path] = set()
    while queue:
        path, depth = queue.pop(0)
        if path in seen or depth > max_depth:
            continue
        seen.add(path)
        try:
            src = path.read_bytes()
        except OSError:
            continue
        try:
            tree = parser.parse(src)
        except Exception:
            continue
        _collect_named_constants_into(
            named, func_macros, tree.root_node, src, parser, sizeof_table,
        )
        sub = _gather_header_paths(tree.root_node, src, path.parent, include_dirs)
        for p, _ in sub:
            if p not in seen:
                queue.append((p, depth + 1))


def _run_compiler_macro_dump(
    source_path: Path, language: str, include_dirs: List[Path],
    extra_defines: Optional[Dict[str, int]], compiler: str,
) -> Optional[bytes]:
    """Shell out to `<compiler> -dM -E` and return its stdout."""
    import shutil
    import subprocess
    if not shutil.which(compiler):
        return None
    args = [compiler, "-dM", "-E", "-x", "c++" if language in ("cpp", "c++") else "c"]
    for d in include_dirs:
        args.extend(["-I", str(d)])
    for name, value in (extra_defines or {}).items():
        args.extend(["-D", f"{name}={value}"])
    args.append(str(source_path))
    try:
        out = subprocess.run(args, capture_output=True, timeout=30)
    except (subprocess.TimeoutExpired, OSError):
        return None
    if out.returncode != 0:
        # Even on failure clang/gcc usually emit the macros we care about
        # on stdout; only bail if there's no useful output at all.
        if not out.stdout:
            return None
    return out.stdout


def _ingest_macro_dump(
    dump: bytes, parser,
    named: Dict[str, int],
    func_macros: Dict[str, Tuple[List[str], str]],
    sizeof_table: Optional[Dict[str, int]],
):
    """Parse a `-dM -E` macro dump and merge its definitions into the tables."""
    try:
        tree = parser.parse(dump)
    except Exception:
        return
    # Fixed-point iteration — chained macros like
    #   #define INT_MAX __INT_MAX__
    #   #define __INT_MAX__ 2147483647
    # may need multiple passes to fully resolve.
    for _ in range(4):
        before = (len(named), len(func_macros))
        _collect_named_constants_into(named, func_macros, tree.root_node, dump, parser, sizeof_table)
        if (len(named), len(func_macros)) == before:
            break


def build_named_constants(
    root, source: bytes, parser,
    *,
    sizeof_table: Optional[Dict[str, int]] = None,
    follow_headers: bool = True,
    source_path: Optional[Path] = None,
    include_dirs: Optional[List[Path]] = None,
    extra_defines: Optional[Dict[str, int]] = None,
    system_macros: bool = False,
    compiler: str = "cc",
    language: str = "cpp",
) -> Tuple[Dict[str, int], Dict[str, Tuple[List[str], str]]]:
    named: Dict[str, int] = dict(_BUILTIN_INT_CONSTANTS)
    if extra_defines:
        named.update(extra_defines)
    func_macros: Dict[str, Tuple[List[str], str]] = {}

    if system_macros and source_path is not None:
        dump = _run_compiler_macro_dump(
            source_path, language,
            list(include_dirs or []),
            extra_defines, compiler,
        )
        if dump:
            _ingest_macro_dump(dump, parser, named, func_macros, sizeof_table)

    if follow_headers:
        source_dir = (source_path.parent if source_path else Path.cwd()).resolve()
        dirs = list(include_dirs or []) + [source_dir]
        seed_paths = _gather_header_paths(root, source, source_dir, dirs)
        _scan_headers_recursive(seed_paths, parser, dirs, named, func_macros, sizeof_table)

    _collect_named_constants_into(named, func_macros, root, source, parser, sizeof_table)
    return named, func_macros


# ---------------------------------------------------------------------------
# Preprocessor branch pruning
# ---------------------------------------------------------------------------

def _eval_preproc_condition(cond_node, source: bytes,
                            named: Dict[str, int],
                            sizeof_table: Optional[Dict[str, int]]) -> Optional[int]:
    """Best-effort evaluation of a #if condition. Returns 0/1 or None if unknown."""
    if cond_node is None:
        return None
    text = node_text(cond_node, source).strip()
    # Handle defined(X) and defined X tokens
    text2 = re.sub(
        r"defined\s*\(?\s*([A-Za-z_]\w*)\s*\)?",
        lambda m: "1" if m.group(1) in named else "0",
        text,
    )
    if text2 != text:
        wrapped = ("int __cfc_cond__ = " + text2 + ";").encode("utf-8", errors="replace")
        try:
            import tree_sitter_cpp as _ts
            from tree_sitter import Language, Parser
            lang = Language(_ts.language())
            try:
                p = Parser(lang)
            except TypeError:
                p = Parser()
                p.set_language(lang) if hasattr(p, "set_language") else setattr(p, "language", lang)
            tree = p.parse(wrapped)
        except Exception:
            return None
        for n in walk(tree.root_node):
            if n.type == "init_declarator":
                v_node = n.child_by_field_name("value")
                if v_node is not None:
                    return _eval_const_int(v_node, wrapped, named, sizeof_table)
        return None
    return _eval_const_int(cond_node, source, named, sizeof_table)


def collect_skip_ranges(
    root, source: bytes,
    named: Dict[str, int],
    sizeof_table: Optional[Dict[str, int]],
) -> List[Tuple[int, int]]:
    """Subtree byte-ranges inside provably-inactive preprocessor branches."""
    skips: List[Tuple[int, int]] = []

    def alternative_node(node):
        for c in node.children:
            if c.type in ("preproc_else", "preproc_elif", "preproc_elifdef", "preproc_elifndef"):
                return c
        return None

    def skip_active_body_extent(node, alt):
        """Skip [first-non-header-child .. (alt or #endif)]."""
        body_start = None
        for c in node.children:
            if c.is_named and c.type not in (
                "preproc_else", "preproc_elif", "preproc_elifdef", "preproc_elifndef",
                "identifier", "number_literal", "binary_expression",
                "unary_expression", "call_expression", "preproc_defined",
            ):
                body_start = c.start_byte
                break
        if body_start is None:
            return
        end = alt.start_byte if alt is not None else node.end_byte
        if end > body_start:
            skips.append((body_start, end))

    def skip_alternative_extent(alt):
        skips.append((alt.start_byte, alt.end_byte))

    for node in walk(root):
        if node.type == "preproc_if":
            cond = node.child_by_field_name("condition")
            if cond is None:
                continue
            v = _eval_preproc_condition(cond, source, named, sizeof_table)
            if v is None:
                continue
            alt = alternative_node(node)
            if v == 0:
                skip_active_body_extent(node, alt)
            else:
                if alt is not None:
                    skip_alternative_extent(alt)

        elif node.type in ("preproc_ifdef", "preproc_ifndef"):
            # tree-sitter-cpp emits `preproc_ifdef` for both #ifdef and
            # #ifndef — we must inspect the leading directive token to tell
            # them apart.
            is_ifndef = False
            for c in node.children:
                if not c.is_named:
                    tok = node_text(c, source).strip()
                    if tok == "#ifndef":
                        is_ifndef = True
                    break
            name_node = node.child_by_field_name("name")
            if name_node is None:
                for c in node.children:
                    if c.type == "identifier":
                        name_node = c
                        break
            if name_node is None:
                continue
            name = node_text(name_node, source).strip()
            defined = name in named
            taken = (not defined) if is_ifndef else defined
            alt = alternative_node(node)
            if not taken:
                skip_active_body_extent(node, alt)
            else:
                if alt is not None:
                    skip_alternative_extent(alt)
    return skips


# ---------------------------------------------------------------------------
# Function-like macro expansion at call sites
# ---------------------------------------------------------------------------

def _split_macro_args(text: str) -> List[str]:
    args: List[str] = []
    depth = 0
    cur = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch in "([{":
            depth += 1
            cur.append(ch)
        elif ch in ")]}":
            depth -= 1
            cur.append(ch)
        elif ch == "," and depth == 0:
            args.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
        i += 1
    if cur:
        args.append("".join(cur).strip())
    return args


def expand_function_macro(call_node, source: bytes,
                          func_macros: Dict[str, Tuple[List[str], str]],
                          depth: int = 0) -> Optional[str]:
    if depth > 8:
        return None
    if call_node.type != "call_expression":
        return None
    fn = call_node.child_by_field_name("function")
    args_n = call_node.child_by_field_name("arguments")
    if fn is None or args_n is None or fn.type != "identifier":
        return None
    name = node_text(fn, source).strip()
    if name not in func_macros:
        return None
    params, body = func_macros[name]
    args_text = node_text(args_n, source).strip()
    if args_text.startswith("(") and args_text.endswith(")"):
        args_text = args_text[1:-1]
    args = _split_macro_args(args_text) if args_text else []
    if len(args) != len(params):
        return None
    expanded = body
    # Replace longest params first to avoid prefix collisions
    for param, arg in sorted(zip(params, args), key=lambda p: -len(p[0])):
        expanded = re.sub(rf"\b{re.escape(param)}\b", f"({arg})", expanded)
    return expanded


# ---------------------------------------------------------------------------
# Match utilities
# ---------------------------------------------------------------------------

def matches_constant(node, source: bytes, kind: str, target,
                     named: Dict[str, int],
                     sizeof_table: Optional[Dict[str, int]]) -> bool:
    n = unwrap(node, source)
    if n is None:
        return False
    if kind == "int":
        v = _eval_const_int(n, source, named, sizeof_table)
        return v is not None and v == target
    if n.type in ("true", "false", "null", "nullptr"):
        return node_text(n, source) == target
    if n.type == "identifier":
        return node_text(n, source) == target
    if n.type in ("qualified_identifier", "scoped_identifier"):
        return re.sub(r"\s+", "", node_text(n, source)) == re.sub(r"\s+", "", target)
    return False


def is_purely_constant_side(node, source: bytes,
                            named: Dict[str, int],
                            sizeof_table: Optional[Dict[str, int]]) -> bool:
    return _eval_const_int(node, source, named, sizeof_table) is not None


def find_context(node) -> str:
    p = node.parent
    while p is not None:
        if p.type in _CONTEXT_NODES:
            return _CONTEXT_NODES[p.type]
        if p.type == "function_definition":
            break
        p = p.parent
    return "expression"


def _case_value_node(node):
    v = node.child_by_field_name("value")
    if v is not None:
        return v
    for c in node.children:
        if c.is_named and c.type not in ("compound_statement", "case_statement", "labeled_statement"):
            return c
    return None


def _enclosing_switch_condition(node, source: bytes) -> str:
    sw = node.parent
    while sw and sw.type != "switch_statement":
        sw = sw.parent
    if sw is None:
        return ""
    cond = sw.child_by_field_name("condition")
    if cond is None:
        for c in sw.children:
            if c.type in ("parenthesized_expression", "condition_clause"):
                cond = c
                break
    return node_text(cond, source).strip() if cond is not None else ""


# ---------------------------------------------------------------------------
# Implicit truthiness walk
# ---------------------------------------------------------------------------

def _condition_of(node):
    if node.type in ("if_statement", "while_statement", "do_statement",
                     "conditional_expression", "for_statement"):
        return node.child_by_field_name("condition")
    return None


def _ctx_of(node):
    return _CONTEXT_NODES.get(node.type, "expression")


def find_truthy_matches(root, source: bytes,
                        named: Dict[str, int],
                        sizeof_table: Optional[Dict[str, int]],
                        skip_ranges: List[Tuple[int, int]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen_spans: Set = set()

    def emit(operand, ctx, negated: bool):
        span = (operand.start_byte, operand.end_byte, negated)
        if span in seen_spans:
            return
        seen_spans.add(span)
        op = "==" if negated else "!="
        text = node_text(operand, source).strip()
        out.append({
            "line": operand.start_point[0] + 1,
            "column": operand.start_point[1] + 1,
            "operator": op,
            "variable_side": text,
            "constant_side": "0",
            "expression": f"(implicit) {text} {op} 0",
            "context": ctx,
            "implicit": True,
        })

    def visit(expr, ctx, negated: bool = False):
        expr = unwrap(expr, source)
        if expr is None:
            return
        if expr.type == "binary_expression":
            parts = get_binop_parts(expr, source)
            if parts is not None:
                left, op, right = parts
                if op in ("&&", "||"):
                    visit(left, ctx, negated)
                    visit(right, ctx, negated)
                    return
                if op in COMPARISON_OPS:
                    return
        if expr.type == "unary_expression":
            op_node = expr.child_by_field_name("operator")
            operand = expr.child_by_field_name("argument")
            if op_node is not None and operand is not None and node_text(op_node, source) == "!":
                visit(operand, ctx, not negated)
                return
        if expr.type == "assignment_expression":
            return
        if is_purely_constant_side(expr, source, named, sizeof_table):
            return
        emit(expr, ctx, negated)

    for node in walk(root):
        if in_skipped_region(node, skip_ranges):
            continue
        cond = _condition_of(node)
        if cond is None:
            continue
        visit(cond, _ctx_of(node))
    return out


# ---------------------------------------------------------------------------
# Main match walk
# ---------------------------------------------------------------------------

def _emit_comparison(
    node, left, right, op_text, kind, target,
    source: bytes,
    named: Dict[str, int],
    sizeof_table: Optional[Dict[str, int]],
    line_override: Optional[int] = None,
    column_override: Optional[int] = None,
    source_kind: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    left_match = matches_constant(left, source, kind, target, named, sizeof_table)
    right_match = matches_constant(right, source, kind, target, named, sizeof_table)
    if not (left_match or right_match):
        return None
    if kind == "int":
        left_pure = is_purely_constant_side(left, source, named, sizeof_table)
        right_pure = is_purely_constant_side(right, source, named, sizeof_table)
        if left_match and right_match:
            const_node, var_node = left, right
        elif left_match and left_pure and not right_pure:
            const_node, var_node = left, right
        elif right_match and right_pure and not left_pure:
            const_node, var_node = right, left
        elif left_match and left_pure:
            const_node, var_node = left, right
        elif right_match and right_pure:
            const_node, var_node = right, left
        else:
            const_node = left if left_match else right
            var_node = right if left_match else left
    else:
        const_node = left if left_match else right
        var_node = right if left_match else left

    match: Dict[str, Any] = {
        "line": line_override if line_override is not None else node.start_point[0] + 1,
        "column": column_override if column_override is not None else node.start_point[1] + 1,
        "operator": op_text,
        "variable_side": node_text(var_node, source).strip(),
        "constant_side": node_text(const_node, source).strip(),
        "expression": node_text(node, source).strip(),
        "context": find_context(node),
    }
    if kind == "int":
        resolved = _eval_const_int(const_node, source, named, sizeof_table)
        if resolved is not None and match["constant_side"] != str(resolved):
            match["resolved_value"] = resolved
    if source_kind:
        match["match_source"] = source_kind
    return match


def find_matches(
    source: bytes,
    parser,
    kind: str,
    target,
    *,
    include_truthy: bool = False,
    follow_headers: bool = True,
    expand_function_macros_flag: bool = True,
    prune_preproc: bool = True,
    target_model: str = "LP64",
    source_path: Optional[Path] = None,
    include_dirs: Optional[List[Path]] = None,
    extra_defines: Optional[Dict[str, int]] = None,
    system_macros: bool = False,
    compiler: str = "cc",
    language: str = "cpp",
) -> List[Dict[str, Any]]:
    tree = parser.parse(source)
    root = tree.root_node
    sizeof_table = _TARGET_MODELS.get(target_model, _TARGET_MODELS["LP64"])

    named: Dict[str, int] = {}
    func_macros: Dict[str, Tuple[List[str], str]] = {}
    if kind == "int":
        named, func_macros = build_named_constants(
            root, source, parser,
            sizeof_table=sizeof_table,
            follow_headers=follow_headers,
            source_path=source_path,
            include_dirs=include_dirs,
            extra_defines=extra_defines,
            system_macros=system_macros,
            compiler=compiler,
            language=language,
        )
    else:
        named = dict(_BUILTIN_INT_CONSTANTS)
        if extra_defines:
            named.update(extra_defines)
        # we still need func_macros for expansion
        _, func_macros = build_named_constants(
            root, source, parser,
            sizeof_table=sizeof_table,
            follow_headers=follow_headers,
            source_path=source_path,
            include_dirs=include_dirs,
            extra_defines=extra_defines,
        )

    skip_ranges: List[Tuple[int, int]] = []
    if prune_preproc:
        skip_ranges = collect_skip_ranges(root, source, named, sizeof_table)

    matches: List[Dict[str, Any]] = []
    seen_spans: Set = set()

    for node in walk(root):
        if in_skipped_region(node, skip_ranges):
            continue

        if node.type == "binary_expression":
            parts = get_binop_parts(node, source)
            if parts is None:
                continue
            left, op_text, right = parts
            if op_text not in COMPARISON_OPS:
                continue
            span = (node.start_byte, node.end_byte)
            if span in seen_spans:
                continue
            seen_spans.add(span)
            m = _emit_comparison(node, left, right, op_text, kind, target,
                                 source, named, sizeof_table)
            if m is not None:
                matches.append(m)
            continue

        if node.type == "case_statement":
            value_node = _case_value_node(node)
            if value_node is None:
                continue
            if not matches_constant(value_node, source, kind, target, named, sizeof_table):
                continue
            cond_text = _enclosing_switch_condition(node, source)
            matches.append({
                "line": node.start_point[0] + 1,
                "column": node.start_point[1] + 1,
                "operator": "case",
                "variable_side": cond_text,
                "constant_side": node_text(value_node, source).strip(),
                "expression": f"case {node_text(value_node, source).strip()}:",
                "context": "switch_case",
            })
            continue

        if expand_function_macros_flag and node.type == "call_expression":
            expanded = expand_function_macro(node, source, func_macros)
            if expanded is None:
                continue
            wrapped = ("int __cfc_call__() { return (" + expanded + "); }").encode("utf-8", errors="replace")
            try:
                tree2 = parser.parse(wrapped)
            except Exception:
                continue
            for sub in walk(tree2.root_node):
                if sub.type != "binary_expression":
                    continue
                parts = get_binop_parts(sub, wrapped)
                if parts is None:
                    continue
                left, op_text, right = parts
                if op_text not in COMPARISON_OPS:
                    continue
                m = _emit_comparison(
                    sub, left, right, op_text, kind, target,
                    wrapped, named, sizeof_table,
                    line_override=node.start_point[0] + 1,
                    column_override=node.start_point[1] + 1,
                    source_kind="macro_expansion",
                )
                if m is not None:
                    m["expression"] = node_text(node, source).strip()
                    m["context"] = find_context(node)
                    matches.append(m)

    if include_truthy and kind == "int" and target == 0:
        matches.extend(find_truthy_matches(root, source, named, sizeof_table, skip_ranges))

    matches.sort(key=lambda m: (m["line"], m["column"]))
    return matches


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_define(spec: str) -> Tuple[str, int]:
    if "=" not in spec:
        return spec, 1
    name, value = spec.split("=", 1)
    v = _parse_int_literal(value)
    if v is None:
        raise ValueError(f"--define value not an integer: {spec}")
    return name.strip(), v


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("file", help="Path to the C/C++ source file")
    ap.add_argument("constant", help="The constant k to search for")
    ap.add_argument("--language", default="cpp", choices=["c", "cpp"])
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--include-truthy", action="store_true",
                    help="When k=0, also report implicit truthiness checks")
    ap.add_argument("--include-dir", "-I", action="append", default=[],
                    help="Header search directory (repeatable)")
    ap.add_argument("--define", "-D", action="append", default=[],
                    help="Predefine NAME=VALUE (or just NAME for value 1)")
    ap.add_argument("--target-model", default="LP64",
                    choices=list(_TARGET_MODELS.keys()),
                    help="Data model used to resolve sizeof(primitive)")
    ap.add_argument("--no-headers", action="store_true",
                    help="Do not follow #include directives into headers")
    ap.add_argument("--no-macro-expand", action="store_true",
                    help="Do not expand function-like macros at call sites")
    ap.add_argument("--no-preproc-prune", action="store_true",
                    help="Do not prune inactive #if/#ifdef branches")
    ap.add_argument("--system-macros", action="store_true",
                    help="Use `cc -dM -E` to ingest macros from system + project headers "
                         "(resolves INT_MAX, ERANGE, …)")
    ap.add_argument("--compiler", default="cc",
                    help="Compiler used for --system-macros (cc, clang, gcc, ...)")
    args = ap.parse_args(argv)

    if not os.path.isfile(args.file):
        print(f"error: file not found: {args.file}", file=sys.stderr)
        return 2

    try:
        kind, target = parse_constant(args.constant)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    parser = init_parser(args.language)
    source_path = Path(args.file).resolve()
    with open(args.file, "rb") as f:
        source = f.read()

    include_dirs = [Path(d).resolve() for d in args.include_dir]
    extra_defines: Dict[str, int] = {}
    for spec in args.define:
        try:
            name, val = _parse_define(spec)
        except ValueError as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        extra_defines[name] = val

    matches = find_matches(
        source, parser, kind, target,
        include_truthy=args.include_truthy,
        follow_headers=not args.no_headers,
        expand_function_macros_flag=not args.no_macro_expand,
        prune_preproc=not args.no_preproc_prune,
        target_model=args.target_model,
        source_path=source_path,
        include_dirs=include_dirs,
        extra_defines=extra_defines,
        system_macros=args.system_macros,
        compiler=args.compiler,
        language=args.language,
    )

    if args.json:
        print(json.dumps({
            "file": args.file,
            "constant": args.constant,
            "constant_kind": kind,
            "constant_value": target,
            "include_truthy": args.include_truthy,
            "follow_headers": not args.no_headers,
            "target_model": args.target_model,
            "match_count": len(matches),
            "matches": matches,
        }, indent=2))
        return 0

    print(
        f"# {args.file} — constant {args.constant} ({kind}={target}) — "
        f"{len(matches)} match(es)"
    )
    for m in matches:
        tag = ""
        if m.get("implicit"):
            tag = "[implicit] "
        elif m.get("match_source") == "macro_expansion":
            tag = "[macro] "
        rv = f"  -> {m['resolved_value']}" if "resolved_value" in m else ""
        print(
            f"  L{m['line']:>4}:{m['column']:<3} [{m['context']:<11}] "
            f"{tag}{m['variable_side']} {m['operator']} {m['constant_side']}{rv}"
        )
    return 0


if __name__ == "__main__":
    sys.exit(main())
