#!/usr/bin/env python3
"""
Validator for blocks/subroutines sections in parser JSON output.

Runs three tiers of checks:
  1. Schema      — required keys, correct types, no contradictory fields
  2. Consistency — internal JSON cross-references (branches, callers, ordering)
  3. Source      — line numbers and opcodes verified against the raw ASM file

Usage:
    python3 tools/validate_blocks.py <json_file> [<asm_source_file>]

    If the ASM source file is omitted, only schema + consistency checks run.
    If a directory is given, all .json files in it are validated.
"""

import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from blueprint_io import iter_flow, load_blueprint


# ---------------------------------------------------------------------------
# Tiny ASM line tokeniser (fixed-column, good enough for opcode extraction)
# ---------------------------------------------------------------------------

def _tokenise_asm_line(raw: str) -> Tuple[Optional[str], Optional[str], List[str]]:
    """Return (label, opcode, operands) for one raw ASM source line."""
    line = raw.rstrip("\n")

    # Full-line comments
    if not line or line[0] in ("*",):
        return None, None, []
    if line.startswith(".*"):
        return None, None, []

    # Determine label
    if line[0] in (" ", "\t"):
        label = None
        body = line.lstrip()
    else:
        parts = line.split(None, 1)
        label = parts[0]
        body = parts[1] if len(parts) > 1 else ""

    if not body:
        return label, None, []

    # Opcode is the first token of body
    op_parts = body.split(None, 1)
    opcode = op_parts[0]
    operand_str = op_parts[1].strip() if len(op_parts) > 1 else ""

    # Strip inline trailing comment: first run of >=2 spaces outside quotes/parens
    depth = 0
    in_quote = False
    quote_char = None
    i = 0
    end = len(operand_str)
    while i < end:
        ch = operand_str[i]
        if in_quote:
            if ch == quote_char:
                in_quote = False
        else:
            if ch in ("'", '"'):
                in_quote = True
                quote_char = ch
            elif ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif ch == " " and depth == 0:
                # Check for double-space
                if i + 1 < end and operand_str[i + 1] == " ":
                    end = i
                    break
        i += 1
    operand_str = operand_str[:end].strip()

    # Split operands on top-level commas
    operands: List[str] = []
    depth = 0
    in_quote = False
    quote_char = None
    start = 0
    for idx, ch in enumerate(operand_str):
        if in_quote:
            if ch == quote_char:
                in_quote = False
        else:
            if ch in ("'", '"'):
                in_quote = True
                quote_char = ch
            elif ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif ch == "," and depth == 0:
                operands.append(operand_str[start:idx].strip())
                start = idx + 1
    if operand_str[start:].strip():
        operands.append(operand_str[start:].strip())

    return label, opcode, operands


def build_source_map(asm_path: Path) -> Dict[int, Tuple[Optional[str], Optional[str], List[str]]]:
    """Read an ASM file and return {line_number: (label, opcode, operands)}."""
    src_map: Dict[int, Tuple[Optional[str], Optional[str], List[str]]] = {}
    with open(asm_path, encoding="utf-8", errors="replace") as fh:
        for lineno, raw in enumerate(fh, start=1):
            src_map[lineno] = _tokenise_asm_line(raw)
    return src_map


# ---------------------------------------------------------------------------
# Validation logic
# ---------------------------------------------------------------------------

class ValidationResult:
    def __init__(self, filename: str):
        self.filename = filename
        self.errors:   List[str] = []
        self.warnings: List[str] = []

    def err(self, msg: str):
        self.errors.append(msg)

    def warn(self, msg: str):
        self.warnings.append(msg)

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0


def validate(json_path: Path, asm_path: Optional[Path] = None) -> ValidationResult:
    result = ValidationResult(json_path.name)

    try:
        data = load_blueprint(json_path, skip_global_lineage=True)
    except Exception as e:
        result.err(f"Cannot parse JSON: {e}")
        return result

    blocks     = data.get("blocks", [])
    subroutines = data.get("subroutines", [])

    # -----------------------------------------------------------------------
    # Tier 1: Schema checks
    # -----------------------------------------------------------------------

    # Top-level keys
    for key in ("blocks", "subroutines", "meta"):
        if key not in data:
            result.err(f"Missing top-level key: '{key}'")

    all_ids = set()

    for b in blocks:
        bid = b.get("id", "<missing>")

        # Required keys
        for key in ("id", "flow", "incoming_branches"):
            if key not in b:
                result.err(f"Block '{bid}' missing key: '{key}'")

        # Types
        if not isinstance(b.get("id"), str) or not b.get("id"):
            result.err(f"Block has non-string or empty id: {b.get('id')}")
        if not isinstance(b.get("flow"), (list, dict)):
            result.err(f"Block '{bid}': flow is not a list")
        if not isinstance(b.get("incoming_branches"), list):
            result.err(f"Block '{bid}': incoming_branches is not a list")

        for ref in b.get("incoming_branches", []):
            if not isinstance(ref, dict) or not isinstance(ref.get("source"), str):
                result.err(f"Block '{bid}': incoming_branches contains invalid ref: {ref!r}")

        # Flow items
        for i, item in enumerate(iter_flow(b)):
            has_args   = "args" in item
            has_var    = "var" in item
            has_val    = "val" in item
            has_varval = has_var and has_val

            if "line" not in item:
                result.err(f"Block '{bid}' flow[{i}]: missing 'line'")
            if "inst" not in item:
                result.err(f"Block '{bid}' flow[{i}]: missing 'inst'")
            if not isinstance(item.get("inst"), str) or not item.get("inst", "").strip():
                result.err(f"Block '{bid}' flow[{i}]: 'inst' is empty or not a string")
            if not isinstance(item.get("line"), int):
                result.err(f"Block '{bid}' flow[{i}]: 'line' is not an int")
            if not has_args and not has_varval:
                result.err(f"Block '{bid}' flow[{i}] line {item.get('line')}: "
                            f"must have either 'args' or ('var' + 'val')")
            if has_args and has_varval:
                result.err(f"Block '{bid}' flow[{i}] line {item.get('line')}: "
                            f"has both 'args' AND 'var'/'val' — mutually exclusive")
            if has_var != has_val:
                result.err(f"Block '{bid}' flow[{i}] line {item.get('line')}: "
                            f"has 'var' without 'val' or vice versa")
            if has_args and not isinstance(item.get("args"), list):
                result.err(f"Block '{bid}' flow[{i}]: 'args' is not a list")

        all_ids.add(bid)

    for s in subroutines:
        sid = s.get("id", "<missing>")

        for key in ("id", "start_line", "end_line", "called_by"):
            if key not in s:
                result.err(f"Subroutine '{sid}' missing key: '{key}'")

        if not isinstance(s.get("id"), str) or not s.get("id"):
            result.err(f"Subroutine has non-string or empty id: {s.get('id')}")
        if not isinstance(s.get("start_line"), int):
            result.err(f"Subroutine '{sid}': start_line is not an int")
        if not isinstance(s.get("end_line"), int):
            result.err(f"Subroutine '{sid}': end_line is not an int")
        if isinstance(s.get("start_line"), int) and isinstance(s.get("end_line"), int):
            if s["start_line"] > s["end_line"]:
                result.err(f"Subroutine '{sid}': start_line ({s['start_line']}) "
                            f"> end_line ({s['end_line']})")
        if not isinstance(s.get("called_by"), list):
            result.err(f"Subroutine '{sid}': called_by is not a list")
        for ref in s.get("called_by", []):
            if not isinstance(ref, str):
                result.err(f"Subroutine '{sid}': called_by contains non-string: {ref!r}")

        all_ids.add(sid)

    # -----------------------------------------------------------------------
    # Tier 2: Consistency checks
    # -----------------------------------------------------------------------

    block_ids = {b.get("id") for b in blocks}
    sub_ids   = {s.get("id") for s in subroutines}

    # Duplicate IDs
    all_block_ids = [b.get("id") for b in blocks]
    for dup, cnt in Counter(all_block_ids).items():
        if cnt > 1:
            result.err(f"Duplicate block id: '{dup}' appears {cnt} times")

    all_sub_ids = [s.get("id") for s in subroutines]
    for dup, cnt in Counter(all_sub_ids).items():
        if cnt > 1:
            result.err(f"Duplicate subroutine id: '{dup}' appears {cnt} times")

    # incoming_branches references
    for b in blocks:
        for ref in b.get("incoming_branches", []):
            source = ref.get("source") if isinstance(ref, dict) else None
            if source not in all_ids:
                result.err(f"Block '{b['id']}': incoming_branch '{source}' "
                            f"is not a known block/subroutine id")

    # called_by references
    for s in subroutines:
        for ref in s.get("called_by", []):
            if ref not in all_ids:
                result.err(f"Subroutine '{s['id']}': called_by '{ref}' "
                            f"is not a known block/subroutine id")

    # Source ordering: blocks by first flow line, subroutines by start_line
    def _first_flow_line(b: dict) -> int:
        for entry in iter_flow(b):
            return entry.get("line", 0)
        return 0

    block_order = [_first_flow_line(b) for b in blocks if b.get("flow")]
    if block_order != sorted(block_order):
        result.warn("Blocks are not ordered by first source line")

    sub_order = [s.get("start_line", 0) for s in subroutines]
    if sub_order != sorted(sub_order):
        result.warn("Subroutines are not ordered by start_line")

    # No line number overlap between blocks
    line_to_block: Dict[int, str] = {}
    for b in blocks:
        for item in iter_flow(b):
            ln = item.get("line")
            if ln is None:
                continue
            if ln in line_to_block:
                result.err(f"Line {ln} appears in both block '{line_to_block[ln]}' "
                            f"and block '{b['id']}'")
            else:
                line_to_block[ln] = b["id"]

    # -----------------------------------------------------------------------
    # Tier 3: Source cross-checks (only when ASM file is provided)
    # -----------------------------------------------------------------------

    if asm_path and asm_path.exists():
        src_map = build_source_map(asm_path)
        max_line = max(src_map.keys())

        for b in blocks:
            bid = b.get("id", "?")
            for item in iter_flow(b):
                ln   = item.get("line")
                inst = item.get("inst", "")

                if ln is None:
                    continue

                # Line within file bounds
                if ln > max_line:
                    result.err(f"Block '{bid}': flow line {ln} exceeds "
                                f"file length ({max_line} lines)")
                    continue

                src_label, src_opcode, src_operands = src_map.get(ln, (None, None, []))

                # Source line must have an opcode
                if src_opcode is None:
                    result.err(f"Block '{bid}': flow line {ln} has no opcode "
                                f"in source (comment or blank?)")
                    continue

                # Opcode must match (case-insensitive)
                if src_opcode.upper() != inst.upper():
                    result.err(f"Block '{bid}': flow line {ln} opcode mismatch — "
                                f"JSON='{inst}' vs source='{src_opcode}'")

                # Operand count sanity (warn, not error — trailing comment text
                # can make counts differ)
                if "args" in item:
                    json_ops = item["args"]
                else:
                    json_ops = [item.get("var", ""), item.get("val", "")]

                if src_operands and json_ops:
                    if len(src_operands) != len(json_ops):
                        result.warn(
                            f"Block '{bid}' line {ln} '{inst}': operand count "
                            f"differs — JSON={len(json_ops)} source={len(src_operands)} "
                            f"(source operands may include trailing comment text)"
                        )

        for s in subroutines:
            sid  = s.get("id", "?")
            sl   = s.get("start_line", 0)
            el   = s.get("end_line", 0)

            if sl > max_line:
                result.err(f"Subroutine '{sid}': start_line {sl} exceeds "
                            f"file length ({max_line})")
            if el > max_line:
                result.err(f"Subroutine '{sid}': end_line {el} exceeds "
                            f"file length ({max_line})")

    elif asm_path:
        result.warn(f"ASM source file not found, skipping source checks: {asm_path}")

    return result


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run(json_input: Path, asm_dir: Optional[Path] = None):
    if json_input.is_dir():
        json_files = sorted(json_input.glob("**/*.json"))
    else:
        json_files = [json_input]

    total_errors   = 0
    total_warnings = 0
    results        = []

    for jf in json_files:
        # Try to find the matching ASM source
        asm_path = None
        if asm_dir:
            # strip .json → look for matching .asm
            stem = jf.stem  # e.g. "ENTRYDRV.asm"
            asm_path = asm_dir / stem
            if not asm_path.exists():
                asm_path = None

        r = validate(jf, asm_path)
        results.append(r)
        total_errors   += len(r.errors)
        total_warnings += len(r.warnings)

    # Print report
    print("=" * 70)
    print(f"BLOCK/SUBROUTINE VALIDATION REPORT  ({len(json_files)} file(s))")
    print("=" * 70)

    for r in results:
        status = "PASS" if r.ok else "FAIL"
        print(f"\n[{status}] {r.filename}")

        if r.errors:
            for e in r.errors:
                print(f"  ERROR:   {e}")
        if r.warnings:
            for w in r.warnings:
                print(f"  WARNING: {w}")

        if r.ok and not r.warnings:
            print("  All checks passed.")

    print()
    print("=" * 70)
    print(f"SUMMARY: {len(json_files)} file(s) | "
          f"{sum(1 for r in results if r.ok)}/{len(results)} passed | "
          f"{total_errors} error(s) | {total_warnings} warning(s)")
    print("=" * 70)

    return total_errors


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    json_input = Path(sys.argv[1])
    asm_dir    = Path(sys.argv[2]) if len(sys.argv) > 2 else None

    sys.exit(run(json_input, asm_dir))
