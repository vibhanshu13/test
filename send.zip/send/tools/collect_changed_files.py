#!/usr/bin/env python3
"""Collect files changed *after* a given commit and copy them into a share folder.

Given a base commit and a branch (or any ref), this finds every file that the
commits made *after* that base commit (the base commit itself is excluded) have
changed, and copies the branch-tip version of each into a fresh share folder
(preserving the repo-relative directory layout).

The share folder is deleted and recreated on every run.

Usage:
    python tools/collect_changed_files.py <base_commit> <branch> [options]

Examples:
    # Net changes between the base commit and the branch tip -> ./share
    python tools/collect_changed_files.py abc1234 dev_tabish_v2

    # Every file touched by any commit after the base (even if later reverted)
    python tools/collect_changed_files.py abc1234 dev_tabish_v2 --mode union

    # Custom destination
    python tools/collect_changed_files.py abc1234 dev_tabish_v2 --share-dir /tmp/to_send
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


def run_git(args: list[str], cwd: Path) -> str:
    """Run a git command and return stdout, raising a clear error on failure."""
    result = subprocess.run(
        ["git", *args],
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        sys.exit(f"git {' '.join(args)} failed:\n{result.stderr.strip()}")
    return result.stdout


def repo_root() -> Path:
    out = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True,
        text=True,
    )
    if out.returncode != 0:
        sys.exit("Not inside a git repository.")
    return Path(out.stdout.strip())


def resolve_ref(ref: str, root: Path) -> str:
    """Verify a ref/commit exists and return its full SHA."""
    out = subprocess.run(
        ["git", "rev-parse", "--verify", f"{ref}^{{commit}}"],
        cwd=root,
        capture_output=True,
        text=True,
    )
    if out.returncode != 0:
        sys.exit(f"Unknown commit or branch: {ref!r}")
    return out.stdout.strip()


def changed_files(base: str, branch: str, mode: str, root: Path) -> list[str]:
    """Return repo-relative paths changed after `base`, up to `branch` tip.

    mode="diff"  -> net difference between base and branch tip (default).
    mode="union" -> every file touched by any commit in (base, branch].
    """
    if mode == "diff":
        # Files that differ between base and branch tip. --diff-filter excludes
        # nothing here; deletion handling happens at copy time.
        out = run_git(
            ["diff", "--name-only", f"{base}..{branch}"],
            cwd=root,
        )
    else:  # union
        # Every path touched by any non-merge commit in the range. An empty
        # --pretty leaves only the file names from --name-only.
        out = run_git(
            ["log", "--no-merges", "--name-only", "--pretty=format:",
             f"{base}..{branch}"],
            cwd=root,
        )
    files = {line.strip() for line in out.splitlines() if line.strip()}
    return sorted(files)


def file_exists_at(ref: str, path: str, root: Path) -> bool:
    out = subprocess.run(
        ["git", "cat-file", "-e", f"{ref}:{path}"],
        cwd=root,
        capture_output=True,
    )
    return out.returncode == 0


def copy_from_ref(ref: str, path: str, dest_root: Path, root: Path) -> None:
    """Write the `ref` version of `path` into dest_root/path (binary-safe)."""
    blob = subprocess.run(
        ["git", "show", f"{ref}:{path}"],
        cwd=root,
        capture_output=True,
    )
    if blob.returncode != 0:
        raise RuntimeError(blob.stderr.decode(errors="replace").strip())
    dest = dest_root / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(blob.stdout)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Copy files changed after a commit into a fresh share folder.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("base_commit", help="Base commit hash (EXCLUDED).")
    parser.add_argument("branch", help="Branch or ref whose tip is the upper bound.")
    parser.add_argument(
        "--share-dir",
        default="share",
        help="Destination folder (relative to repo root unless absolute). "
             "Deleted and recreated each run. Default: share",
    )
    parser.add_argument(
        "--mode",
        choices=["diff", "union"],
        default="diff",
        help="diff = net changes vs branch tip (default); "
             "union = every file touched by any commit after base.",
    )
    args = parser.parse_args()

    root = repo_root()
    base_sha = resolve_ref(args.base_commit, root)
    branch_sha = resolve_ref(args.branch, root)

    files = changed_files(base_sha, branch_sha, args.mode, root)
    if not files:
        print(f"No files changed between {args.base_commit[:8]} and {args.branch}.")
        return

    share_dir = Path(args.share_dir)
    if not share_dir.is_absolute():
        share_dir = root / share_dir

    # Refuse to nuke something obviously wrong.
    if share_dir == root:
        sys.exit("Refusing to use the repo root as the share folder.")

    if share_dir.exists():
        print(f"Removing existing share folder: {share_dir}")
        shutil.rmtree(share_dir)
    share_dir.mkdir(parents=True)

    copied, skipped = [], []
    for path in files:
        if file_exists_at(branch_sha, path, root):
            copy_from_ref(branch_sha, path, share_dir, root)
            copied.append(path)
        else:
            # Deleted at branch tip — nothing to copy.
            skipped.append(path)

    print(f"\nBase commit (excluded): {base_sha[:8]}")
    print(f"Branch tip:             {branch_sha[:8]} ({args.branch})")
    print(f"Mode:                   {args.mode}")
    print(f"Share folder:           {share_dir}")
    print(f"\nCopied {len(copied)} file(s):")
    for p in copied:
        print(f"  + {p}")
    if skipped:
        print(f"\nSkipped {len(skipped)} deleted-at-tip file(s):")
        for p in skipped:
            print(f"  - {p}")


if __name__ == "__main__":
    main()
