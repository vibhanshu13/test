"""Macro definition models for z/TPF assembly macros."""

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


@dataclass
class MacroParameter:
    """Represents a macro parameter (e.g., &RC, &LABEL)."""

    name: str  # Parameter name including & prefix
    default_value: Optional[str]  # Default value if not provided
    is_label: bool  # True if this is the &LABEL parameter


@dataclass
class MacroDefinition:
    """Definition of an assembly macro with parameters and body."""

    name: str  # Macro name (e.g., "CHKRC")
    parameters: List[MacroParameter]  # List of parameters
    body: List[str]  # Raw lines between MACRO and MEND
    source_file: Path  # File where macro is defined
    start_line: int  # Starting line number in source
    end_line: int  # Ending line number in source
    scope: str  # "global" or "local"

    def to_dict(self) -> dict:
        """Serialize to dictionary for JSON output."""
        return {
            "name": self.name,
            "parameters": [
                {
                    "name": p.name,
                    "default_value": p.default_value,
                    "is_label": p.is_label
                }
                for p in self.parameters
            ],
            "source_file": str(self.source_file),
            "start_line": self.start_line,
            "end_line": self.end_line,
            "scope": self.scope
        }
