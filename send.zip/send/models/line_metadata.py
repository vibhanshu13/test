"""Line-level metadata for variable tracking."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass
class ConditionalContext:
    """Tracks conditional control flow at a specific point."""
    is_conditional: bool
    depth: int  # Nesting level (0 = not in conditional)
    active_conditions: List[str]  # Stack of condition expressions
    condition_types: List[str]  # Stack of types: "if", "while", "for", "BC", "AIF"


@dataclass
class CodeblockContext:
    """Tracks which codeblock (function/section) this line belongs to."""
    enclosing_function: Optional[str] = None  # For C/C++: "main", "calculate"
    enclosing_section: Optional[str] = None   # For ASM: "CSECT1", "DSECT2"
    enclosing_routine: Optional[str] = None   # For ASM: label of routine within section
    in_executable_block: bool = False         # True if inside function/section body


@dataclass
class CallContext:
    """Pre-computed call information for fast lookup."""
    calls_functions: List[str] = field(default_factory=list)   # C/C++ functions called
    calls_routines: List[str] = field(default_factory=list)    # ASM routines/labels called
    invokes_macros: List[str] = field(default_factory=list)    # Macro invocations


@dataclass
class LineMetadata:
    """Complete metadata for a single source line."""
    file: str
    line_number: int
    codeblock: CodeblockContext
    conditional: ConditionalContext
    calls: CallContext
    is_comment: bool = False  # Always False for tracked lines

    def to_dict(self) -> dict:
        """Serialize for JSON output.

        ``file`` and ``line`` are intentionally omitted: in a per-file blueprint
        ``file`` is the same for every entry (redundant), and ``line`` duplicates
        the dict key used by ``_emit_line_metadata``.  Consumers look up entries
        by key (line number string) and never access these fields from the value.

        Empty/default sub-structures are omitted to reduce payload size:
        - ``codeblock`` omitted when all fields are None/False.
        - ``conditional`` omitted when not inside a conditional block.
        - ``calls`` omitted when all call lists are empty.
        """
        result: dict = {}

        # codeblock — emit only when at least one field is non-trivial
        cb = self.codeblock
        if (
            cb.enclosing_function is not None
            or cb.enclosing_section is not None
            or cb.enclosing_routine is not None
            or cb.in_executable_block
        ):
            cb_dict: dict = {}
            if cb.enclosing_function is not None:
                cb_dict["enclosing_function"] = cb.enclosing_function
            if cb.enclosing_section is not None:
                cb_dict["enclosing_section"] = cb.enclosing_section
            if cb.enclosing_routine is not None:
                cb_dict["enclosing_routine"] = cb.enclosing_routine
            if cb.in_executable_block:
                cb_dict["in_executable_block"] = True
            result["codeblock"] = cb_dict

        # conditional — emit only when actually inside a conditional block
        cond = self.conditional
        if cond.is_conditional:
            cond_dict: dict = {"is_conditional": True}
            if cond.depth:
                cond_dict["depth"] = cond.depth
            if cond.active_conditions:
                cond_dict["active_conditions"] = cond.active_conditions
            if cond.condition_types:
                cond_dict["condition_types"] = cond.condition_types
            result["conditional"] = cond_dict

        # calls — emit only when something is actually called
        calls = self.calls
        if calls.calls_functions or calls.calls_routines or calls.invokes_macros:
            calls_dict: dict = {}
            if calls.calls_functions:
                calls_dict["calls_functions"] = calls.calls_functions
            if calls.calls_routines:
                calls_dict["calls_routines"] = calls.calls_routines
            if calls.invokes_macros:
                calls_dict["invokes_macros"] = calls.invokes_macros
            result["calls"] = calls_dict

        return result


class LineMetadataIndex:
    """Fast lookup index for line metadata."""

    def __init__(self):
        self._index: Dict[Tuple[str, int], LineMetadata] = {}

    def add(self, metadata: LineMetadata):
        """Add metadata for a line."""
        key = (metadata.file, metadata.line_number)
        self._index[key] = metadata

    def get(self, file: str, line: int) -> Optional[LineMetadata]:
        """O(1) lookup of metadata."""
        return self._index.get((file, line))

    def get_lines_in_function(self, function: str) -> List[LineMetadata]:
        """Get all lines within a function."""
        return [m for m in self._index.values()
                if m.codeblock.enclosing_function == function]

    def get_lines_in_section(self, section: str) -> List[LineMetadata]:
        """Get all lines within a section."""
        return [m for m in self._index.values()
                if m.codeblock.enclosing_section == section]

    def get_conditional_lines(self) -> List[LineMetadata]:
        """Get all lines inside conditionals."""
        return [m for m in self._index.values()
                if m.conditional.is_conditional]

    def get_all(self) -> List[LineMetadata]:
        """Get all tracked lines."""
        return list(self._index.values())
