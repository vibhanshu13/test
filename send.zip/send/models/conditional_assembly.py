"""Conditional assembly data models."""

from dataclasses import dataclass
from typing import Any, Optional, Dict, List


@dataclass
class SetSymbol:
    """Represents a SET symbol (SETA, SETB, SETC).

    SET symbols are assembler variables used in conditional assembly.
    - SETA: Arithmetic (integer)
    - SETB: Boolean (True/False)
    - SETC: Character (string)
    """
    name: str
    value: Any
    symbol_type: str  # "SETA", "SETB", "SETC"


class SetSymbolTable:
    """Table of SET symbols for conditional assembly.

    Tracks the state of SET symbols during preprocessing.
    """

    def __init__(self):
        self.symbols: Dict[str, SetSymbol] = {}

    def set(self, name: str, value: Any, symbol_type: str):
        """Set a symbol value.

        Args:
            name: Symbol name (e.g., "&VAR")
            value: Symbol value
            symbol_type: "SETA", "SETB", or "SETC"
        """
        self.symbols[name] = SetSymbol(
            name=name,
            value=value,
            symbol_type=symbol_type
        )

    def get(self, name: str) -> Optional[Any]:
        """Get a symbol value.

        Args:
            name: Symbol name

        Returns:
            Symbol value, or None if not found
        """
        symbol = self.symbols.get(name)
        return symbol.value if symbol else None

    def has(self, name: str) -> bool:
        """Check if symbol exists.

        Args:
            name: Symbol name

        Returns:
            True if symbol exists
        """
        return name in self.symbols

    def set_value(self, name: str, value: Any) -> None:
        """Set a symbol value (convenience method that infers type).

        Args:
            name: Symbol name (e.g., "&VAR")
            value: Symbol value (type will be inferred)
        """
        # Infer type from value
        if isinstance(value, bool):
            symbol_type = "SETB"
        elif isinstance(value, int):
            symbol_type = "SETA"
        else:
            symbol_type = "SETC"

        self.set(name, value, symbol_type)

    def get_value(self, name: str) -> Any:
        """Get a symbol value (returns 'UNKNOWN' for undefined symbols).

        Args:
            name: Symbol name

        Returns:
            Symbol value, or 'UNKNOWN' if not found
        """
        symbol = self.symbols.get(name)
        return symbol.value if symbol else "UNKNOWN"


@dataclass
class SequenceSymbol:
    """Represents a sequence symbol (label for AGO/AIF).

    Sequence symbols are labels used as targets for conditional branches.
    Example: .LOOP ANOP
    """
    name: str
    target_line: int


@dataclass
class AIFDirective:
    """Assembly IF directive - conditional branch."""
    condition: str  # e.g., "&VAR EQ 1"
    target: str     # Sequence symbol target (e.g., ".LABEL")
    source_line: int


@dataclass
class AGODirective:
    """Assembly GO TO directive - unconditional branch."""
    target: str  # Sequence symbol target
    source_line: int


@dataclass
class ANOPDirective:
    """Assembly NOP directive - sequence symbol label."""
    label: str  # Sequence symbol (e.g., ".START")
    source_line: int


class ConditionalAssemblyState:
    """Tracks state of conditional assembly during preprocessing."""

    def __init__(self):
        """Initialize conditional assembly state."""
        self.set_symbols: SetSymbolTable = SetSymbolTable()
        self.macro_params: Dict[str, str] = {}  # macro parameter name -> value
        self.sequence_labels: Dict[str, int] = {}  # label -> line number
        self.active_conditions: List[str] = []  # Stack of active conditions

    def define_sequence_label(self, label: str, line_number: int) -> None:
        """Define a sequence symbol label."""
        self.sequence_labels[label] = line_number

    def has_sequence_label(self, label: str) -> bool:
        """Check if sequence label is defined."""
        return label in self.sequence_labels

    def get_sequence_label_line(self, label: str) -> Optional[int]:
        """Get line number for sequence label."""
        return self.sequence_labels.get(label)

    def set_macro_param(self, name: str, value: str) -> None:
        """Set a macro parameter value.

        Args:
            name: Parameter name (e.g., "&PARM1")
            value: Parameter value
        """
        self.macro_params[name] = value

    def get_macro_param(self, name: str) -> Optional[str]:
        """Get a macro parameter value.

        Args:
            name: Parameter name

        Returns:
            Parameter value, or None if not defined
        """
        return self.macro_params.get(name)

    def has_macro_param(self, name: str) -> bool:
        """Check if macro parameter is defined.

        Args:
            name: Parameter name

        Returns:
            True if parameter is defined
        """
        return name in self.macro_params

    def clear_macro_params(self) -> None:
        """Clear all macro parameters.

        Called when exiting a macro expansion context.
        """
        self.macro_params.clear()
