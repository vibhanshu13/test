"""Symbol definitions for assembly code."""

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Optional
from models.provenance import StatementProvenance


class SymbolType(Enum):
    """Types of symbols in assembly code."""
    ENTRY = "entry"
    EXTRN = "extrn"
    WXTRN = "wxtrn"
    CSECT = "csect"
    DSECT = "dsect"
    RSECT = "rsect"
    EQU = "equ"
    LABEL = "label"
    DC = "dc"


@dataclass
class Symbol:
    """Represents a symbol in assembly code.

    Symbols can be entry points, external references, sections,
    equates, or labels. Each carries full provenance.
    """

    name: str
    symbol_type: SymbolType
    file: str
    provenance: StatementProvenance
    value: Optional[int] = None
    expression: Optional[str] = None
    section: Optional[str] = None
    asm_name: Optional[str] = None
    is_duplicate: bool = False
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> dict:
        """Serialize to dictionary for JSON output."""
        return {
            "name": self.name,
            "type": self.symbol_type.value,
            "file": self.file,
            "value": self.value,
            "expression": self.expression,
            "section": self.section,
            "asm_name": self.asm_name,
            "is_duplicate": self.is_duplicate,
            "metadata": self.metadata or {},
            "provenance": self.provenance.to_dict()
        }


class SymbolTable:
    """Multi-level symbol table with section scoping.

    Manages global symbols (ENTRY, EXTRN) and section-scoped symbols
    (labels within CSECT/DSECT). Provides scoped resolution.
    """

    def __init__(self):
        self.global_symbols: dict[str, Symbol] = {}
        self.sections: dict[str, dict[str, Symbol]] = {}
        self.symbol_to_file: dict[str, str] = {}
        self.symbol_to_section: dict[str, str] = {}
        self.section_to_file: dict[str, str] = {}
        # Track all symbol declarations (includes duplicates like EXTRN in multiple files)
        self.all_symbols: list[Symbol] = []

    def add_symbol(self, symbol: Symbol, section: Optional[str] = None):
        """Add symbol with proper scoping.

        Args:
            symbol: Symbol to add
            section: Section name if symbol is section-scoped
        """
        # Always track in all_symbols list (preserves all declarations)
        self.all_symbols.append(symbol)

        if section:
            # Add to section-scoped symbols
            if section not in self.sections:
                self.sections[section] = {}
            self.sections[section][symbol.name] = symbol
            self.symbol_to_section[symbol.name] = section
        else:
            # Add to global symbols
            self.global_symbols[symbol.name] = symbol
            if symbol.symbol_type in (SymbolType.CSECT, SymbolType.DSECT, SymbolType.RSECT):
                self.sections.setdefault(symbol.name, {})

        # Track file mapping
        self.symbol_to_file[symbol.name] = symbol.file

    def resolve(self, name: str, context: Optional[str] = None) -> Optional[Symbol]:
        """Resolve symbol with section context.

        Checks local section first (if context provided), then global.

        Args:
            name: Symbol name to resolve
            context: Section context for scoped lookup

        Returns:
            Symbol if found, None otherwise
        """
        # Check section-scoped first if context provided
        if context and context in self.sections:
            if name in self.sections[context]:
                return self.sections[context][name]

        # Fall back to global
        return self.global_symbols.get(name)

    def to_dict(self) -> dict:
        """Serialize symbol table to dictionary."""
        sections_payload = {
            section_name: {
                sym_name: sym.to_dict()
                for sym_name, sym in symbols.items()
            }
            for section_name, symbols in self.sections.items()
        }
        # Ensure section directives appear in sections even if no scoped symbols were captured.
        for symbol in self.all_symbols:
            if symbol.symbol_type in (SymbolType.CSECT, SymbolType.DSECT, SymbolType.RSECT):
                sections_payload.setdefault(symbol.name, {})

        return {
            "global_symbols": {
                name: symbol.to_dict()
                for name, symbol in self.global_symbols.items()
            },
            "sections": sections_payload
        }
