"""Block and subroutine data models for control flow analysis."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class FlowItem:
    """Represents a single instruction entry inside a block's flow list."""

    line: int
    inst: str
    # Either args (general) or var+val (MVC-type) will be set, never both.
    args: Optional[List[str]] = None
    var: Optional[str] = None
    val: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"line": self.line, "inst": self.inst}
        if self.var is not None:
            d["var"] = self.var
            d["val"] = self.val
        else:
            d["args"] = self.args if self.args is not None else []
        return d


@dataclass
class BranchRef:
    """Represents an incoming branch source for a block.

    edge_type is "BRANCH" for explicit control-flow edges and "FALLTHROUGH"
    for implicit sequential fall-through from the preceding block.
    """

    source: str
    edge_type: str = "BRANCH"

    def to_dict(self) -> Dict[str, str]:
        return {"source": self.source, "type": self.edge_type}


@dataclass
class BlockInfo:
    """Represents a named code block (non-subroutine labeled routine)."""

    id: str
    start_line: int
    end_line: int
    flow: List[FlowItem] = field(default_factory=list)
    incoming_branches: List[BranchRef] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        # Columnar flow: parallel arrays eliminate repeated key strings per entry
        lines: List[int] = []
        insts: List[str] = []
        args_col: List[Any] = []
        var_col: List[Any] = []
        val_col: List[Any] = []
        for item in self.flow:
            lines.append(item.line)
            insts.append(item.inst)
            if item.var is not None:
                args_col.append(None)
                var_col.append(item.var)
                val_col.append(item.val)
            else:
                args_col.append(item.args if item.args is not None else [])
                var_col.append(None)
                val_col.append(None)
        return {
            "id": self.id,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "flow": {"l": lines, "i": insts, "a": args_col, "v": var_col, "x": val_col},
            "incoming_branches": [ref.to_dict() for ref in self.incoming_branches],
        }


@dataclass
class SubroutineInfo:
    """Represents a subroutine (a routine reachable via SUBROUTINE_CALL edges)."""

    id: str
    start_line: int
    end_line: int
    called_by: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "called_by": self.called_by,
        }


@dataclass
class BlockAnalysisResult:
    """Top-level container stored in context metadata under key 'block_analysis'."""

    blocks: List[BlockInfo] = field(default_factory=list)
    subroutines: List[SubroutineInfo] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "blocks": [b.to_dict() for b in self.blocks],
            "subroutines": [s.to_dict() for s in self.subroutines],
        }
