"""Call graph data models for control flow analysis."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Set, Dict


class CallType(Enum):
    """Types of control flow transfers."""
    SUBROUTINE_CALL = "subroutine_call"        # BAL, BALR, BAS, BASR, BRAS, BRASL
    NO_RETURN_CALL = "no_return_call"          # ENTRC-like transfer with no return (e.g., ENTNC, ENTDC)
    ASYNC_SPAWN = "async_spawn"                # CREEC/CREMC — fire-and-forget new ECB/task spawn
    SYNC_SPAWN = "sync_spawn"                  # CRESC — synchronous spawn, caller suspends until entry completes
    CALL = "call"                              # C/C++ call expression
    MODE_TRANSITION = "mode_transition"        # BASSM, BASM, BSM
    BRANCH = "branch"                          # B*, BC, BCR
    RETURN = "return"                          # BR R14
    EXECUTE = "execute"                        # EX instruction
    MACRO_INVOCATION = "macro_invocation"      # z/TPF macros
    ISC_ROUTE = "isc_route"                    # SWISC — ISC-routed message to another segment


@dataclass
class CallEdge:
    """Represents a control flow edge in the call graph."""
    source: str
    target: Optional[str]  # None for indirect calls
    call_type: CallType
    instruction: str
    file: str
    line: int
    is_indirect: bool = False
    register: Optional[str] = None  # For indirect calls (e.g., BASR R14,R15)
    level_number: Optional[int] = None  # For get_level(LEVELx, ...)
    is_local_var: bool = False  # True when target is a local variable (lambda, unresolved fp)

    def to_dict(self) -> dict:
        """Serialize call edge to dictionary."""
        d = {
            "source": self.source,
            "target": self.target,
            "call_type": self.call_type.value,
            "instruction": self.instruction,
            "file": self.file,
            "line": self.line,
            "is_indirect": self.is_indirect,
            "register": self.register,
            "level_number": self.level_number,
        }
        if self.is_local_var:
            d["is_local_var"] = True
        return d


@dataclass
class CallGraphNode:
    """Represents a callable unit (routine, section, label)."""
    name: str
    section: Optional[str] = None
    file: Optional[str] = None
    is_external: bool = False
    kind: Optional[str] = None  # function, routine, control_section, global, macro

    def to_dict(self) -> dict:
        """Serialize call graph node to dictionary."""
        return {
            "name": self.name,
            "section": self.section,
            "file": self.file,
            "is_external": self.is_external,
            "kind": self.kind,
        }


class CallGraph:
    """Call graph for assembly program.

    Tracks control flow between routines via calls, branches, and returns.
    """

    def __init__(self):
        self.nodes: Dict[str, CallGraphNode] = {}
        self.edges: List[CallEdge] = []

    def add_node(self, name: str, section: Optional[str] = None,
                 file: Optional[str] = None, is_external: bool = False,
                 kind: Optional[str] = None, node_kind: Optional[str] = None):
        """Add a node to the call graph.

        Args:
            name: Node name (routine/label)
            section: Section containing this node
            file: Source file
            is_external: Whether this is an external reference
            kind: Semantic kind label (e.g., function/routine/control_section/macro)
            node_kind: Backward-compatible alias for `kind`
        """
        resolved_kind = kind or node_kind
        if name not in self.nodes:
            self.nodes[name] = CallGraphNode(
                name=name,
                section=section,
                file=file,
                is_external=is_external,
                kind=resolved_kind,
            )
        else:
            if is_external:
                self.nodes[name].is_external = True
            if resolved_kind and not self.nodes[name].kind:
                self.nodes[name].kind = resolved_kind

    def add_edge(self, source: str, target: Optional[str], call_type: CallType,
                 instruction: str, file: str, line: int, is_indirect: bool = False,
                 register: Optional[str] = None, level_number: Optional[int] = None,
                 is_local_var: bool = False):
        """Add an edge to the call graph.

        Args:
            source: Source routine/label
            target: Target routine/label (None for indirect)
            call_type: Type of control flow
            instruction: Assembly instruction
            file: Source file
            line: Line number
            is_indirect: Whether this is an indirect call
            register: Register for indirect calls
            level_number: z/TPF data level argument for get_level calls
            is_local_var: True when target is a local variable (lambda, unresolved fp)
        """
        # Ensure nodes exist
        self.add_node(source)
        if target:
            self.add_node(target)

        edge = CallEdge(
            source=source,
            target=target,
            call_type=call_type,
            instruction=instruction,
            file=file,
            line=line,
            is_indirect=is_indirect,
            register=register,
            level_number=level_number,
            is_local_var=is_local_var,
        )
        self.edges.append(edge)

    def get_callees(self, node: str) -> List[str]:
        """Get all callees of a node.

        Args:
            node: Node name

        Returns:
            List of callee names
        """
        callees = []
        for edge in self.edges:
            if edge.source == node and edge.target:
                callees.append(edge.target)
        return callees

    def get_callers(self, node: str) -> List[str]:
        """Get all callers of a node.

        Args:
            node: Node name

        Returns:
            List of caller names
        """
        callers = []
        for edge in self.edges:
            if edge.target == node:
                callers.append(edge.source)
        return callers

    def get_indirect_calls(self) -> List[CallEdge]:
        """Get all indirect calls flagged for data flow analysis.

        Returns:
            List of indirect call edges
        """
        return [edge for edge in self.edges if edge.is_indirect]

    def to_dict(self) -> dict:
        """Serialize call graph to dictionary."""
        return {
            "nodes": {
                name: node.to_dict()
                for name, node in self.nodes.items()
            },
            "edges": [edge.to_dict() for edge in self.edges]
        }
