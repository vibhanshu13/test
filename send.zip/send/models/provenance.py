"""Provenance tracking for assembly statements."""

from dataclasses import dataclass
from typing import Optional, List


@dataclass
class StatementProvenance:
    """Complete traceability for every analyzed statement.

    Tracks where a statement came from, including expansion history
    through COPY directives and macro expansions.
    """

    statement_id: str
    original_file: str
    original_line: int
    expanded_from_copy: Optional[str] = None
    macro_expansion_parent: Optional[str] = None
    section: Optional[str] = None
    routine: Optional[str] = None

    def get_full_trace(self) -> List[str]:
        """Return full expansion trace for debugging.

        Returns:
            List of strings describing the expansion chain.
            Example: ["module1.asm:42", "COPY utils.asm", "section=MAINSECT"]
        """
        trace = [f"{self.original_file}:{self.original_line}"]

        if self.expanded_from_copy:
            trace.append(f"COPY {self.expanded_from_copy}")

        if self.macro_expansion_parent:
            trace.append(f"macro parent={self.macro_expansion_parent}")

        if self.section:
            trace.append(f"section={self.section}")

        if self.routine:
            trace.append(f"routine={self.routine}")

        return trace

    def to_dict(self) -> dict:
        """Serialize to dictionary for JSON output."""
        return {
            "statement_id": self.statement_id,
            "original_file": self.original_file,
            "original_line": self.original_line,
            "expanded_from_copy": self.expanded_from_copy,
            "macro_expansion_parent": self.macro_expansion_parent,
            "section": self.section,
            "routine": self.routine
        }
