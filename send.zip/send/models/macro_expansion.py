"""Macro expansion result models."""

from dataclasses import dataclass
from typing import List, Optional, Dict, Any


@dataclass
class ParameterSubstitution:
    """Tracks where a parameter was substituted in an instruction."""

    param: str  # Parameter name (e.g., "&RC")
    value: str  # Substituted value (e.g., "4")
    position: str  # Position in instruction (e.g., "operand1", "operand2", "label")


@dataclass
class MacroProvenance:
    """Hierarchical provenance for macro expansions."""

    invocation_file: str
    invocation_line: int
    invocation_macro: str
    definition_file: str
    definition_line: int
    nested_expansion: Optional['MacroProvenance'] = None

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        result = {
            "invocation": {
                "file": self.invocation_file,
                "line": self.invocation_line,
                "macro": self.invocation_macro
            },
            "definition": {
                "file": self.definition_file,
                "line": self.definition_line
            }
        }

        if self.nested_expansion:
            result["nested_expansion"] = self.nested_expansion.to_dict()

        return result


@dataclass
class ExpandedInstruction:
    """Single instruction from macro expansion with provenance."""

    instruction: str
    label: Optional[str]
    parameter_substitutions: List[ParameterSubstitution]
    provenance: Optional[MacroProvenance]

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "instruction": self.instruction,
            "label": self.label,
            "parameter_substitutions": [
                {
                    "param": sub.param,
                    "value": sub.value,
                    "position": sub.position
                }
                for sub in self.parameter_substitutions
            ],
            "provenance": self.provenance.to_dict() if self.provenance else None
        }


@dataclass
class ExpansionError:
    """Error that occurred during macro expansion."""

    macro_name: str
    error_type: str  # "not_found", "invalid_param", "circular_call"
    message: str
    location_file: str
    location_line: int

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "macro_name": self.macro_name,
            "error_type": self.error_type,
            "message": self.message,
            "location": {
                "file": self.location_file,
                "line": self.location_line
            }
        }


@dataclass
class ExpansionResult:
    """Complete result of expanding a macro invocation."""

    expansion_id: str
    invocation: str
    invocation_file: str
    invocation_line: int
    macro_name: str
    definition_file: str
    definition_line_start: int
    definition_line_end: int
    expansion_status: str  # "success", "failed", "no_definition"
    parameters: Dict[str, str]
    expanded_instructions: List[ExpandedInstruction]
    error: Optional[ExpansionError]
    expanded_call_graph: Optional[Dict[str, Any]] = None

    def to_dict(self) -> dict:
        """Serialize to dictionary for JSON output.

        Per-instruction provenance is stored in compact form: only the
        definition line number within the macro body is emitted per
        instruction (as ``def_line``).  The shared invocation context
        (invocation_file, invocation_line, macro_name, definition_file) is
        already in the parent expansion header and is NOT repeated for every
        instruction — this avoids storing ~200 bytes × N for every macro call.

        Consumers that need the full provenance chain should read the header
        fields ``invocation_location`` and ``macro_definition_source`` together
        with the per-instruction ``def_line``.
        """
        compact_code = []
        for instr in self.expanded_instructions:
            entry: dict = {
                "instruction": instr.instruction,
            }
            if instr.label is not None:
                entry["label"] = instr.label
            if instr.parameter_substitutions:
                entry["parameter_substitutions"] = [
                    {"param": sub.param, "value": sub.value, "position": sub.position}
                    for sub in instr.parameter_substitutions
                ]
            # Only store the per-instruction unique piece: which line of the
            # macro body generated this instruction.  The shared invocation
            # context lives in the parent expansion header.
            if instr.provenance is not None:
                entry["def_line"] = instr.provenance.definition_line
                # For nested macro calls (macro calling another macro), store
                # the inner invocation compactly so the chain is not lost.
                if instr.provenance.nested_expansion is not None:
                    entry["nested_provenance"] = instr.provenance.nested_expansion.to_dict()
            compact_code.append(entry)

        result = {
            "id": self.expansion_id,
            "expansion_id": self.expansion_id,
            "invocation": self.invocation,
            "invocation_location": {
                "file": self.invocation_file,
                "line": self.invocation_line
            },
            "macro_name": self.macro_name,
            "macro_definition_source": {
                "file": self.definition_file,
                "line": self.definition_line_start,
                "line_end": self.definition_line_end
            },
            "expansion_status": self.expansion_status,
            "parameters": self.parameters,
            "expanded_code": compact_code,
            "error": self.error.to_dict() if self.error else None
        }

        if self.expanded_call_graph:
            result["expanded_call_graph"] = self.expanded_call_graph

        return result
