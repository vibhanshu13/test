"""Variable lineage graph models."""

from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass(slots=True)
class VariableNode:
    """Represents a variable, register, memory location, or usage point.

    Memory notes
    ────────────
    slots=True  — eliminates the per-instance __dict__, saving ~200 B/node.
    metadata=None — lazy: only allocates a dict when metadata is actually
                    written to this node (most nodes never carry metadata).
                    Callers must guard reads with ``node.metadata or {}``.
    """

    node_id: str
    name: str
    kind: str  # register, memory, variable, literal, use
    metadata: Optional[Dict[str, object]] = None

    def to_dict(self) -> dict:
        data = {
            "id": self.node_id,
            "name": self.name,
            "kind": self.kind,
        }
        if self.metadata:
            data["metadata"] = self.metadata
        return data


@dataclass(slots=True)
class VariableEdge:
    """Represents a relationship between variables (definition/assignment/use).

    Memory notes
    ────────────
    slots=True  — eliminates the per-instance __dict__.  Without slots a
                  @dataclass in Python 3.11 costs ~370 B/instance; with slots
                  it costs ~180 B/instance.  For 50 M edges on a 50 K-file
                  corpus this saves ~9 GB of heap.
    metadata=None — lazy: only allocates a dict when enum resolution or other
                    annotation actually needs to write to this edge.  Most edges
                    never carry metadata, so the default-factory dict that used
                    to be allocated per-edge wasted ~200 B × N_edges ≈ 10 GB at
                    50 M edges.  Callers must guard reads with
                    ``edge.metadata or {}`` and guard writes with::

                        if edge.metadata is None:
                            edge.metadata = {}
                        edge.metadata[key] = value
    """

    source: str
    target: str
    relation: str  # define, assign, use, alias
    file: str
    line: int
    expression: Optional[str] = None
    scope: Optional[str] = None
    statement_id: Optional[str] = None
    macro_expansion_parent: Optional[str] = None
    callee: Optional[str] = None
    level_number: Optional[int] = None

    # New fields for universe-aware tracking
    operation_type: Optional[str] = None  # move, compare, load, store, arithmetic, logical, initialize, call_arg
    initialization_method: Optional[str] = None  # macro, direct, parameter, computed, default
    conditional_context: Optional[List[str]] = None  # Active conditions affecting this variable
    transformation: Optional[str] = None  # Description of the operation
    metadata: Optional[Dict[str, object]] = None  # Open-ended annotations (e.g. Phase 5 enum resolution)

    # DSECT base register context — for cross-file variable identity (Phase 0)
    dsect: Optional[str] = None              # DSECT name the field belongs to, e.g. "LG1G1"
    base_reg: Optional[str] = None           # Base register used, e.g. "R5"
    ce_slot: Optional[str] = None            # ECB control register slot, e.g. "CE1CR5"
    field_offset: Optional[int] = None       # Byte offset of field within DSECT
    access_identity: Optional[str] = None    # Stable cross-file key: "CE1CR5:17"
    symbolic_identity: Optional[str] = None  # L2: DSECT:FIELD_NAME e.g. "LG1G1:LG1OSI"
    file_label: Optional[str] = None         # L4: filename:label e.g. "da76:WB1ACCTC"

    # Process-scoped lineage (Phase 2)
    process_context: Optional[List[Dict[str, str]]] = None
    # Each entry: {"discriminator": "LG1OSI", "constant": "LG#C400", "gate_type": "inclusive"}

    def to_dict(self) -> dict:
        # Only emit the required fields; all optional fields use conditional
        # assignment so null values are never stored (saves ~70 bytes/edge at
        # 10K+ edges before compression).
        data: dict = {
            "source": self.source,
            "target": self.target,
            "relation": self.relation,
            "file": self.file,
            "line": self.line,
        }
        if self.expression is not None:
            data["expression"] = self.expression
        if self.scope is not None:
            data["scope"] = self.scope
        if self.statement_id is not None:
            data["statement_id"] = self.statement_id
        if self.macro_expansion_parent is not None:
            data["macro_expansion_parent"] = self.macro_expansion_parent
        if self.callee is not None:
            data["callee"] = self.callee
        if self.level_number is not None:
            data["level_number"] = self.level_number
        # Add new fields if present
        if self.operation_type is not None:
            data["operation_type"] = self.operation_type
        if self.initialization_method is not None:
            data["initialization_method"] = self.initialization_method
        if self.conditional_context is not None:
            data["conditional_context"] = self.conditional_context
        if self.transformation is not None:
            data["transformation"] = self.transformation
        if self.metadata:
            data["metadata"] = dict(self.metadata)
        # DSECT base register context fields
        if self.dsect is not None:
            data["dsect"] = self.dsect
        if self.base_reg is not None:
            data["base_reg"] = self.base_reg
        if self.ce_slot is not None:
            data["ce_slot"] = self.ce_slot
        if self.field_offset is not None:
            data["field_offset"] = self.field_offset
        if self.access_identity is not None:
            data["access_identity"] = self.access_identity
        if self.symbolic_identity is not None:
            data["symbolic_identity"] = self.symbolic_identity
        if self.file_label is not None:
            data["file_label"] = self.file_label
        if self.process_context is not None:
            data["process_context"] = self.process_context
        return data


class VariableLineageGraph:
    """Directed graph of variable lineage."""

    def __init__(self):
        self.nodes: Dict[str, VariableNode] = {}
        self.edges: List[VariableEdge] = []

    def _ensure_node(self, name: str, kind: str, metadata: Optional[Dict[str, object]] = None) -> str:
        node_id = f"{kind}:{name}"
        if node_id not in self.nodes:
            self.nodes[node_id] = VariableNode(
                node_id=node_id,
                name=name,
                kind=kind,
                # Only allocate a dict when there is actual metadata to store.
                metadata=dict(metadata) if metadata else None,
            )
        elif metadata:
            node = self.nodes[node_id]
            if node.metadata is None:
                node.metadata = {}
            node.metadata.update(metadata)
        return node_id

    def annotate_node(self, name: str, kind: str, **metadata: object) -> str:
        """Attach metadata to a lineage node (creating it if needed)."""
        clean = {k: v for k, v in metadata.items() if v is not None}
        return self._ensure_node(name, kind, clean)

    def get_node_id(self, name: str, kind: str) -> Optional[str]:
        node_id = f"{kind}:{name}"
        return node_id if node_id in self.nodes else None

    def add_definition(self, name: str, kind: str, file: str, line: int,
                       expression: Optional[str] = None, scope: Optional[str] = None,
                       statement_id: Optional[str] = None, macro_expansion_parent: Optional[str] = None,
                       operation_type: Optional[str] = None, initialization_method: Optional[str] = None,
                       conditional_context: Optional[List[str]] = None, transformation: Optional[str] = None):
        target_id = self._ensure_node(name, kind)
        edge = VariableEdge(
            source=target_id,
            target=target_id,
            relation="define",
            file=file,
            line=line,
            expression=expression,
            scope=scope,
            statement_id=statement_id,
            macro_expansion_parent=macro_expansion_parent,
            operation_type=operation_type,
            initialization_method=initialization_method,
            conditional_context=conditional_context,
            transformation=transformation
        )
        self.edges.append(edge)

    def add_assignment(self, source_name: str, source_kind: str, target_name: str, target_kind: str,
                       file: str, line: int, expression: Optional[str] = None, scope: Optional[str] = None,
                       statement_id: Optional[str] = None, macro_expansion_parent: Optional[str] = None,
                       operation_type: Optional[str] = None, initialization_method: Optional[str] = None,
                       conditional_context: Optional[List[str]] = None, transformation: Optional[str] = None):
        source_id = self._ensure_node(source_name, source_kind)
        target_id = self._ensure_node(target_name, target_kind)
        self.edges.append(VariableEdge(
            source=source_id,
            target=target_id,
            relation="assign",
            file=file,
            line=line,
            expression=expression,
            scope=scope,
            statement_id=statement_id,
            macro_expansion_parent=macro_expansion_parent,
            operation_type=operation_type,
            initialization_method=initialization_method,
            conditional_context=conditional_context,
            transformation=transformation
        ))

    def add_usage(self, name: str, kind: str, file: str, line: int,
                  expression: Optional[str] = None, scope: Optional[str] = None,
                  statement_id: Optional[str] = None, macro_expansion_parent: Optional[str] = None,
                  operation_type: Optional[str] = None, initialization_method: Optional[str] = None,
                  conditional_context: Optional[List[str]] = None, transformation: Optional[str] = None):
        source_id = self._ensure_node(name, kind)
        use_node_id = self._ensure_node(f"use@{file}:{line}", "use")
        self.edges.append(VariableEdge(
            source=source_id,
            target=use_node_id,
            relation="use",
            file=file,
            line=line,
            expression=expression,
            scope=scope,
            statement_id=statement_id,
            macro_expansion_parent=macro_expansion_parent,
            operation_type=operation_type,
            initialization_method=initialization_method,
            conditional_context=conditional_context,
            transformation=transformation
        ))

    def add_alias(self, source_name: str, source_kind: str, target_name: str, target_kind: str,
                  file: str, line: int, expression: Optional[str] = None, scope: Optional[str] = None,
                  statement_id: Optional[str] = None, macro_expansion_parent: Optional[str] = None,
                  conditional_context: Optional[List[str]] = None):
        source_id = self._ensure_node(source_name, source_kind)
        target_id = self._ensure_node(target_name, target_kind)
        self.edges.append(VariableEdge(
            source=source_id,
            target=target_id,
            relation="alias",
            file=file,
            line=line,
            expression=expression,
            scope=scope,
            statement_id=statement_id,
            macro_expansion_parent=macro_expansion_parent,
            conditional_context=conditional_context,
        ))

    def add_arg_bind(self, source_name: str, source_kind: str, target_name: str, target_kind: str,
                     file: str, line: int, expression: Optional[str] = None, scope: Optional[str] = None,
                     statement_id: Optional[str] = None, macro_expansion_parent: Optional[str] = None,
                     callee: Optional[str] = None, conditional_context: Optional[List[str]] = None):
        source_id = self._ensure_node(source_name, source_kind)
        target_id = self._ensure_node(target_name, target_kind)
        self.edges.append(VariableEdge(
            source=source_id,
            target=target_id,
            relation="arg_bind",
            file=file,
            line=line,
            expression=expression,
            scope=scope,
            statement_id=statement_id,
            macro_expansion_parent=macro_expansion_parent,
            callee=callee,
            conditional_context=conditional_context,
        ))

    def add_bridge(self, source_name: str, source_kind: str, target_name: str, target_kind: str,
                   file: str, line: int, relation: str = "bridge",
                   expression: Optional[str] = None, scope: Optional[str] = None,
                   statement_id: Optional[str] = None, macro_expansion_parent: Optional[str] = None,
                   level_number: Optional[int] = None, conditional_context: Optional[List[str]] = None):
        """Add a generic bridge edge between two nodes for cross-domain stitching."""
        source_id = self._ensure_node(source_name, source_kind)
        target_id = self._ensure_node(target_name, target_kind)
        self.edges.append(VariableEdge(
            source=source_id,
            target=target_id,
            relation=relation,
            file=file,
            line=line,
            expression=expression,
            scope=scope,
            statement_id=statement_id,
            macro_expansion_parent=macro_expansion_parent,
            level_number=level_number,
            conditional_context=conditional_context,
        ))

    def to_dict(self) -> dict:
        return {
            "nodes": [node.to_dict() for node in self.nodes.values()],
            "edges": [edge.to_dict() for edge in self.edges]
        }

    def trace(self, name: str, kind: str, direction: str = "forward", max_depth: int = 5,
              scope: Optional[str] = None) -> List[VariableEdge]:
        """Trace lineage for a variable.

        Args:
            name: Variable name
            kind: Variable kind
            direction: "forward" or "backward"
            max_depth: Maximum traversal depth

        Returns:
            List of VariableEdge objects in traversal order
        """
        start_id = self.get_node_id(name, kind)
        if not start_id:
            return []

        visited = {start_id}
        frontier = [start_id]
        collected: List[VariableEdge] = []
        depth = 0

        while frontier and depth < max_depth:
            next_frontier = []
            for node_id in frontier:
                for edge in self.edges:
                    if scope and edge.scope and edge.scope != scope:
                        continue
                    if direction == "forward" and edge.source == node_id:
                        collected.append(edge)
                        if edge.target not in visited:
                            visited.add(edge.target)
                            next_frontier.append(edge.target)
                    elif direction == "backward" and edge.target == node_id:
                        collected.append(edge)
                        if edge.source not in visited:
                            visited.add(edge.source)
                            next_frontier.append(edge.source)
            frontier = next_frontier
            depth += 1

        return collected

    def to_dot(self) -> str:
        lines = ["digraph VariableLineage {"]
        for node in self.nodes.values():
            label = f"{node.kind}:{node.name}"
            lines.append(f'  "{node.node_id}" [label="{label}"];')
        for edge in self.edges:
            label = edge.relation
            if edge.scope:
                label = f"{label} ({edge.scope})"
            lines.append(f'  "{edge.source}" -> "{edge.target}" [label="{label}"];')
        lines.append("}")
        return "\n".join(lines)
