"""Variable universe models for tracking all variables across the codebase."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set
from pathlib import Path
import json


@dataclass
class VariableLocation:
    """Represents a location where a variable appears."""
    file: str
    line: int
    context: str  # definition, declaration, reference


@dataclass
class VariableEntry:
    """Represents a variable in the universe."""
    name: str
    kind: str  # ASM: memory, block_ref (control-block field), constant, external
               # C/C++: variable, parameter, member, global
    scope: str
    file: str
    line: int
    declaration_type: Optional[str] = None  # DS, DC, EQU for ASM; var, let, const for JS/TS
    data_type: Optional[str] = None
    storage_class: Optional[str] = None  # static, extern, auto, register
    initial_value: Optional[str] = None
    all_locations: List[VariableLocation] = field(default_factory=list)
    scope_chain: List[str] = field(default_factory=list)
    aliased_as: List[str] = field(default_factory=list)
    related_symbols: List[str] = field(default_factory=list)
    metadata: Dict[str, object] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "name": self.name,
            "kind": self.kind,
            "scope": self.scope,
            "file": self.file,
            "line": self.line,
            "declaration_type": self.declaration_type,
            "data_type": self.data_type,
            "storage_class": self.storage_class,
            "initial_value": self.initial_value,
            "all_locations": [
                {"file": loc.file, "line": loc.line, "context": loc.context}
                for loc in self.all_locations
            ],
            "scope_chain": self.scope_chain,
            "aliased_as": self.aliased_as,
            "related_symbols": self.related_symbols,
            "metadata": self.metadata
        }


class VariableUniverse:
    """Container for all variables in a language family (ASM or C/C++)."""

    def __init__(self):
        self.variables: Dict[str, List[VariableEntry]] = {}
        self.extern_symbols: Dict[str, VariableEntry] = {}
        self.macro_definitions: Dict[str, dict] = {}

    def add_variable(self, entry: VariableEntry):
        """Add a variable entry to the universe."""
        if entry.name not in self.variables:
            self.variables[entry.name] = []
        self.variables[entry.name].append(entry)

    def _append_location_if_missing(self, entry: VariableEntry, location: VariableLocation) -> None:
        for existing in entry.all_locations:
            if (
                existing.file == location.file
                and existing.line == location.line
                and existing.context == location.context
            ):
                return
        entry.all_locations.append(location)

    def add_extern_symbol(self, name: str, entry: VariableEntry):
        """Add an external symbol to the universe."""
        existing = self.extern_symbols.get(name)
        if existing is None:
            self.extern_symbols[name] = entry
            return

        for location in entry.all_locations:
            self._append_location_if_missing(existing, location)

        if existing.metadata is None:
            existing.metadata = {}
        declarations = existing.metadata.setdefault("declarations", [])
        declaration = {
            "file": entry.file,
            "line": entry.line,
            "declaration_type": entry.declaration_type,
        }
        if declaration not in declarations:
            declarations.append(declaration)

    def add_macro_definition(self, name: str, params: List[str], defined_in: str,
                            variables_introduced: List[str] = None):
        """Add a macro definition to the universe."""
        self.macro_definitions[name] = {
            "name": name,
            "parameters": params,
            "defined_in": defined_in,
            "variables_introduced": variables_introduced or []
        }

    def get_variable_names(self, include_predicate=None) -> Set[str]:
        """Get all unique variable names in this universe.

        Args:
            include_predicate: Optional callable receiving ``VariableEntry`` and
                returning True when that entry should contribute its name.
        """
        if include_predicate is None:
            return set(self.variables.keys())

        names: Set[str] = set()
        for name, entries in self.variables.items():
            if any(include_predicate(entry) for entry in entries):
                names.add(name)
        return names

    def get_variable_entries(self, name: str) -> List[VariableEntry]:
        """Get all entries for a variable name (may have multiple scopes)."""
        return self.variables.get(name, [])

    def find_variable_in_scope(self, name: str, scope: str) -> Optional[VariableEntry]:
        """Find a specific variable entry by name and scope."""
        entries = self.get_variable_entries(name)
        for entry in entries:
            if entry.scope == scope:
                return entry
        return entries[0] if entries else None

    def to_dict(self) -> dict:
        """Convert universe to dictionary for JSON serialization."""
        return {
            "variables": {
                name: [entry.to_dict() for entry in entries]
                for name, entries in self.variables.items()
            },
            "extern_symbols": {
                name: entry.to_dict()
                for name, entry in self.extern_symbols.items()
            },
            "macro_definitions": self.macro_definitions
        }

    def to_json(self, filepath: Path):
        """Write universe to JSON file."""
        filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, 'w') as f:
            json.dump(self.to_dict(), f, separators=(",", ":"))

    def to_sqlite(self, db_path: Path) -> None:
        """Write universe to a SQLite database for O(1) per-variable lookups.

        Schema:
            variables       — one row per VariableEntry; indexed on ``name``
            aliases         — index rows for ``aliased_as`` reverse lookup
            variable_names  — unique set of variable names (for bulk enumeration)
        """
        import sqlite3

        db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(db_path))
        try:
            cur = conn.cursor()
            cur.executescript("""
                PRAGMA journal_mode=WAL;
                PRAGMA synchronous=NORMAL;
                CREATE TABLE IF NOT EXISTS variables (
                    id               INTEGER PRIMARY KEY,
                    name             TEXT NOT NULL,
                    kind             TEXT,
                    scope            TEXT,
                    file             TEXT,
                    line             INTEGER,
                    declaration_type TEXT,
                    data_type        TEXT,
                    storage_class    TEXT,
                    initial_value    TEXT,
                    scope_chain      TEXT,
                    aliased_as       TEXT,
                    related_symbols  TEXT,
                    metadata         TEXT,
                    all_locations    TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_variables_name ON variables(name);
                CREATE TABLE IF NOT EXISTS aliases (
                    alias_upper TEXT NOT NULL,
                    var_id      INTEGER NOT NULL REFERENCES variables(id)
                );
                CREATE INDEX IF NOT EXISTS idx_aliases ON aliases(alias_upper);
                CREATE TABLE IF NOT EXISTS variable_names (
                    name TEXT PRIMARY KEY
                );
            """)

            def _insert(entry_dict: dict) -> None:
                cur.execute(
                    """INSERT INTO variables
                       (name, kind, scope, file, line, declaration_type,
                        data_type, storage_class, initial_value,
                        scope_chain, aliased_as, related_symbols,
                        metadata, all_locations)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        entry_dict["name"],
                        entry_dict.get("kind"),
                        entry_dict.get("scope"),
                        entry_dict.get("file"),
                        entry_dict.get("line"),
                        entry_dict.get("declaration_type"),
                        entry_dict.get("data_type"),
                        entry_dict.get("storage_class"),
                        entry_dict.get("initial_value"),
                        json.dumps(entry_dict.get("scope_chain") or [], separators=(",", ":")),
                        json.dumps(entry_dict.get("aliased_as") or [], separators=(",", ":")),
                        json.dumps(entry_dict.get("related_symbols") or [], separators=(",", ":")),
                        json.dumps(entry_dict.get("metadata") or {}, separators=(",", ":")),
                        json.dumps(entry_dict.get("all_locations") or [], separators=(",", ":")),
                    ),
                )
                row_id = cur.lastrowid
                for alias in (entry_dict.get("aliased_as") or []):
                    if alias:
                        cur.execute(
                            "INSERT INTO aliases (alias_upper, var_id) VALUES (?,?)",
                            (str(alias).upper(), row_id),
                        )

            for name, entries in self.variables.items():
                for entry in entries:
                    _insert(entry.to_dict())
                cur.execute(
                    "INSERT OR IGNORE INTO variable_names (name) VALUES (?)", (name,)
                )

            for name, entry in self.extern_symbols.items():
                _insert(entry.to_dict())
                cur.execute(
                    "INSERT OR IGNORE INTO variable_names (name) VALUES (?)", (name,)
                )

            conn.commit()
        finally:
            conn.close()

    def write_variable_names(self, filepath: Path, include_predicate=None):
        """Write simple variable names list to JSON file.

        Args:
            include_predicate: Optional callable receiving ``VariableEntry`` and
                returning True when that entry should be included in the names list.
        """
        filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, 'w') as f:
            json.dump({
                "variables": sorted(self.get_variable_names(include_predicate=include_predicate))
            }, f, separators=(",", ":"))

    @classmethod
    def from_json(cls, filepath: Path) -> 'VariableUniverse':
        """Load universe from JSON file."""
        with open(filepath, 'r') as f:
            data = json.load(f)

        universe = cls()

        # Load variables
        for name, entries in data.get("variables", {}).items():
            for entry_dict in entries:
                entry = VariableEntry(
                    name=entry_dict["name"],
                    kind=entry_dict["kind"],
                    scope=entry_dict["scope"],
                    file=entry_dict["file"],
                    line=entry_dict["line"],
                    declaration_type=entry_dict.get("declaration_type"),
                    data_type=entry_dict.get("data_type"),
                    storage_class=entry_dict.get("storage_class"),
                    initial_value=entry_dict.get("initial_value"),
                    all_locations=[
                        VariableLocation(loc["file"], loc["line"], loc["context"])
                        for loc in entry_dict.get("all_locations", [])
                    ],
                    scope_chain=entry_dict.get("scope_chain", []),
                    aliased_as=entry_dict.get("aliased_as", []),
                    related_symbols=entry_dict.get("related_symbols", []),
                    metadata=entry_dict.get("metadata", {})
                )
                universe.add_variable(entry)

        # Load extern symbols
        for name, entry_dict in data.get("extern_symbols", {}).items():
            entry = VariableEntry(
                name=entry_dict["name"],
                kind=entry_dict["kind"],
                scope=entry_dict["scope"],
                file=entry_dict["file"],
                line=entry_dict["line"],
                declaration_type=entry_dict.get("declaration_type"),
                data_type=entry_dict.get("data_type"),
                storage_class=entry_dict.get("storage_class"),
                initial_value=entry_dict.get("initial_value"),
                all_locations=[
                    VariableLocation(loc["file"], loc["line"], loc["context"])
                    for loc in entry_dict.get("all_locations", [])
                ],
                scope_chain=entry_dict.get("scope_chain", []),
                aliased_as=entry_dict.get("aliased_as", []),
                related_symbols=entry_dict.get("related_symbols", []),
                metadata=entry_dict.get("metadata", {})
            )
            universe.add_extern_symbol(name, entry)

        # Load macro definitions
        universe.macro_definitions = data.get("macro_definitions", {})

        return universe


def load_variable_names(filepath: Path) -> Set[str]:
    """Load variable names from JSON file."""
    if not filepath.exists():
        return set()

    with open(filepath, 'r') as f:
        data = json.load(f)
    return set(data.get("variables", []))
