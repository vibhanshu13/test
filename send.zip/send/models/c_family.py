"""C/C++ parsing models."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class CFunction:
    name: str
    start_line: int
    end_line: int


@dataclass
class CCall:
    function: str
    line: int
    enclosing_function: Optional[str]
    asm_target: Optional[str] = None
    call_is_indirect: bool = False
    args: List[str] = field(default_factory=list)
    address_of_args: List[str] = field(default_factory=list)
    conditional_context: Optional[List[str]] = None


@dataclass
class CAssignment:
    target: str
    target_kind: str
    sources: List[str]
    line: int
    expression: Optional[str] = None
    function: Optional[str] = None
    call_function: Optional[str] = None
    call_asm_target: Optional[str] = None
    call_is_indirect: bool = False
    scope: Optional[str] = None
    storage_class: Optional[str] = None
    pointer_depth: int = 0
    target_base: Optional[str] = None
    target_field: Optional[str] = None
    call_args: List[str] = field(default_factory=list)
    call_address_of_args: List[str] = field(default_factory=list)
    operation_type: Optional[str] = None
    conditional_context: Optional[List[str]] = None


@dataclass
class CReturn:
    function: Optional[str]
    line: int
    sources: List[str]
    expression: Optional[str] = None


@dataclass
class CDeclaration:
    name: str
    kind: str
    line: int
    function: Optional[str] = None
    scope: Optional[str] = None
    storage_class: Optional[str] = None
    declaration_type: Optional[str] = None
    data_type: Optional[str] = None
    initial_value: Optional[str] = None
    expression: Optional[str] = None
    initializer_sources: List[str] = field(default_factory=list)
    related_symbols: List[str] = field(default_factory=list)
    aliased_as: List[str] = field(default_factory=list)
    metadata: Dict[str, object] = field(default_factory=dict)


@dataclass
class CCondition:
    """A comparison-context site — the operands of ==/!=/</>/<=/>= in if/
    while/for/switch-case constructs. Phase 5b uses this to emit use-edges
    annotated with conditional_context, so enum identifiers appearing in
    `if (task == AddLimit)` show up in the lineage graph alongside their
    resolved literal values."""
    function: Optional[str]
    scope: Optional[str]
    line: int
    expression: str       # e.g. "task == AddLimit"
    operator: str         # "==", "!=", "<", ">", "<=", ">=", or "case"
    operands: List[str] = field(default_factory=list)


@dataclass
class CMacroDefinition:
    name: str
    line: int
    body: Optional[str] = None
    parameters: List[str] = field(default_factory=list)
    kind: str = "object"  # object, function
    file: Optional[str] = None


@dataclass
class CTranslationUnit:
    file_path: Path
    language: str
    functions: List[CFunction] = field(default_factory=list)
    calls: List[CCall] = field(default_factory=list)
    assignments: List[CAssignment] = field(default_factory=list)
    returns: List[CReturn] = field(default_factory=list)
    declarations: List[CDeclaration] = field(default_factory=list)
    symbol_aliases: Dict[str, str] = field(default_factory=dict)
    function_aliases: Dict[str, str] = field(default_factory=dict)
    type_aliases: Dict[str, str] = field(default_factory=dict)
    field_asm_aliases: Dict[str, str] = field(default_factory=dict)
    field_asm_alias_sources: Dict[str, str] = field(default_factory=dict)
    enum_values: Dict[str, Dict[str, str]] = field(default_factory=dict)
    conditions: List["CCondition"] = field(default_factory=list)
    globals_used: List[str] = field(default_factory=list)
    macro_definitions: List[CMacroDefinition] = field(default_factory=list)
    parse_errors: List[str] = field(default_factory=list)
    # Fix 4: class/struct name → list of base class names (for CHA virtual dispatch)
    class_bases: Dict[str, List[str]] = field(default_factory=dict)
    # union name → member field names (for may_alias: writing one member may
    # change reads of any other — consumed by the chainless lineage).
    union_members: Dict[str, List[str]] = field(default_factory=dict)
