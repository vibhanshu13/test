"""File dependency graph data models."""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Set


class DependencyType(Enum):
    """Types of file dependencies."""
    COPY_INCLUDE = "copy_include"      # COPY directive
    SYMBOL_REFERENCE = "symbol_ref"    # EXTRN → ENTRY
    CROSS_FILE_CALL = "call"          # Call to routine in another file
    EXTERNAL_LIBRARY = "external"      # OS library, missing file
    CPP_INCLUDE = "cpp_include"        # C++ #include directive


@dataclass
class DependencyEvidence:
    """Evidence for a file dependency."""
    dependency_type: DependencyType
    source_file: str
    source_line: int
    details: str  # Human-readable description

    def to_dict(self) -> dict:
        """Serialize dependency evidence to dictionary."""
        return {
            "dependency_type": self.dependency_type.value,
            "source_file": self.source_file,
            "source_line": self.source_line,
            "details": self.details
        }


@dataclass
class FileDependencyNode:
    """Represents a file in the dependency graph."""
    file_path: str
    is_external: bool = False  # True for OS libraries, missing files

    def to_dict(self) -> dict:
        """Serialize file dependency node to dictionary."""
        return {
            "file_path": self.file_path,
            "is_external": self.is_external
        }


@dataclass
class FileDependencyEdge:
    """Represents a dependency between two files."""
    from_file: str
    to_file: str
    evidence: List[DependencyEvidence] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Serialize file dependency edge to dictionary."""
        return {
            "from_file": self.from_file,
            "to_file": self.to_file,
            "evidence": [e.to_dict() for e in self.evidence]
        }


@dataclass
class CircularDependency:
    """Represents a circular dependency (cycle) in the graph."""
    files: List[str]  # List of files in cycle (first == last)
    cycle_type: str   # "simple" (2 files) or "complex" (3+ files)

    def to_dict(self) -> dict:
        """Serialize circular dependency to dictionary."""
        return {
            "files": self.files,
            "cycle_type": self.cycle_type
        }


class FileDependencyGraph:
    """File-level dependency graph.

    Tracks how assembly files depend on each other through:
    - COPY includes
    - Symbol references (EXTRN → ENTRY)
    - Cross-file calls
    - External libraries
    """

    def __init__(self):
        self.nodes: dict[str, FileDependencyNode] = {}
        self.edges: List[FileDependencyEdge] = []
        self.circular_dependencies: List[CircularDependency] = []

    def add_node(self, file_path: str, is_external: bool = False):
        """Add a file node to the graph.

        Args:
            file_path: Path to the file
            is_external: True if external library/missing file
        """
        if file_path not in self.nodes:
            self.nodes[file_path] = FileDependencyNode(
                file_path=file_path,
                is_external=is_external
            )

    def add_edge(self, from_file: str, to_file: str, evidence: DependencyEvidence):
        """Add a dependency edge to the graph.

        Args:
            from_file: Source file
            to_file: Target file
            evidence: Evidence for this dependency
        """
        # Ensure nodes exist
        self.add_node(from_file)
        self.add_node(to_file)

        # Find existing edge or create new one
        existing_edge = None
        for edge in self.edges:
            if edge.from_file == from_file and edge.to_file == to_file:
                existing_edge = edge
                break

        if existing_edge:
            # Add evidence to existing edge
            existing_edge.evidence.append(evidence)
        else:
            # Create new edge
            self.edges.append(FileDependencyEdge(
                from_file=from_file,
                to_file=to_file,
                evidence=[evidence]
            ))

    def get_dependencies(self, file_path: str) -> List[str]:
        """Get all files that a file depends on.

        Args:
            file_path: File to query

        Returns:
            List of files that file_path depends on
        """
        dependencies = []
        for edge in self.edges:
            if edge.from_file == file_path:
                dependencies.append(edge.to_file)
        return dependencies

    def get_dependents(self, file_path: str) -> List[str]:
        """Get all files that depend on a file.

        Args:
            file_path: File to query

        Returns:
            List of files that depend on file_path
        """
        dependents = []
        for edge in self.edges:
            if edge.to_file == file_path:
                dependents.append(edge.from_file)
        return dependents

    def to_dict(self) -> dict:
        """Serialize file dependency graph to dictionary."""
        return {
            "nodes": [node.to_dict() for node in self.nodes.values()],
            "edges": [edge.to_dict() for edge in self.edges],
            "circular_dependencies": [cycle.to_dict() for cycle in self.circular_dependencies]
        }
