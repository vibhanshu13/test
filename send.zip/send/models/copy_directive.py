"""COPY directive models for preprocessor."""

from dataclasses import dataclass
from typing import List, Optional
from models.provenance import StatementProvenance


@dataclass
class CopyDirective:
    """Represents a COPY directive in assembly source.

    COPY directives include external files into the current source.
    Example: COPY UTILS
    """
    target_file: str
    provenance: StatementProvenance


class CopyIncludeStack:
    """Tracks the stack of COPY includes to detect circular dependencies.

    Maintains the current include chain and prevents infinite recursion.
    """

    def __init__(self, max_depth: int = 10):
        """Initialize include stack.

        Args:
            max_depth: Maximum include depth allowed (default: 10)
        """
        self.stack: List[str] = []
        self.max_depth = max_depth

    def push(self, filename: str):
        """Push a file onto the include stack.

        Args:
            filename: File being included

        Raises:
            ValueError: If max depth exceeded or circular include detected
        """
        if len(self.stack) >= self.max_depth:
            raise ValueError(
                f"Maximum include depth ({self.max_depth}) exceeded. "
                f"Include chain: {' -> '.join(self.stack)}"
            )

        if self.is_circular(filename):
            raise ValueError(
                f"Circular include detected: {filename} "
                f"Include chain: {' -> '.join(self.stack)} -> {filename}"
            )

        self.stack.append(filename)

    def pop(self) -> str:
        """Pop the most recent file from the stack.

        Returns:
            The filename that was popped
        """
        return self.stack.pop()

    def current_file(self) -> str:
        """Get the current file (top of stack).

        Returns:
            Current filename, or empty string if stack is empty
        """
        return self.stack[-1] if self.stack else ""

    def depth(self) -> int:
        """Get current include depth.

        Returns:
            Number of files in the include stack
        """
        return len(self.stack)

    def is_circular(self, filename: str) -> bool:
        """Check if including this file would create a circular dependency.

        Args:
            filename: File to check

        Returns:
            True if filename is already in the stack
        """
        return filename in self.stack


def parse_copy_directive(parsed_line) -> Optional[CopyDirective]:
    """Parse a COPY directive from a parsed line.

    Args:
        parsed_line: ParsedLine from tokenizer

    Returns:
        CopyDirective if this is a COPY directive, None otherwise
    """
    if parsed_line.opcode != "COPY":
        return None

    if not parsed_line.operands:
        return None

    target_file = parsed_line.operands[0]

    return CopyDirective(
        target_file=target_file,
        provenance=parsed_line.provenance
    )
