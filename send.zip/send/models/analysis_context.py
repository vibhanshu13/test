"""Central analysis context shared across all passes."""

from dataclasses import dataclass
from typing import List, Tuple, Any, Dict, Optional, Set
from pathlib import Path
from models.symbol import SymbolTable


@dataclass
class Statement:
    """Represents a parsed assembly statement."""
    line_num: int
    label: str
    opcode: str
    operands: str


@dataclass
class CopyInclude:
    """Represents a COPY include relationship."""
    including_file: str
    included_file: str
    line_number: int


class AnalysisContext:
    """Shared context accessible by all analysis passes.

    Contains:
    - Symbol tables
    - Call graphs (will be added in later passes)
    - Data flow graphs (will be added in later passes)
    - Database operation catalog (will be added in later passes)
    - File dependency graph (will be added in later passes)
    - COPY relationships
    - Metadata
    """

    def __init__(self, file_path: Optional[Path] = None):
        self.file_path = file_path
        self.symbol_table = SymbolTable()
        self.copy_includes: List[CopyInclude] = []
        self.metadata: Dict[str, Any] = {}
        self.statements: List[Statement] = []

        # Variable universe storage
        self.variable_names: Dict[str, Set[str]] = {
            "asm": set(),
            "cpp": set()
        }

        # Line metadata index
        self.line_metadata_index: Optional['LineMetadataIndex'] = None

        # Placeholders for future passes
        # self.call_graph = None  # Pass 3
        # self.data_flow_graph = None  # Pass 4
        # self.db_operations = []  # Pass 5
        # self.file_dependency_graph = None  # Pass 6

    def add_copy_include(self, including_file: str, included_file: str, line_number: int):
        """Track a COPY directive relationship.

        Args:
            including_file: File containing the COPY directive
            included_file: File being included
            line_number: Line number where COPY appears
        """
        self.copy_includes.append(CopyInclude(
            including_file=including_file,
            included_file=included_file,
            line_number=line_number
        ))

    def add_metadata(self, key: str, value: Any):
        """Add metadata about the analysis.

        Args:
            key: Metadata key
            value: Metadata value
        """
        self.metadata[key] = value

    def get_metadata(self, key: str) -> Any:
        """Get metadata value by key.

        Args:
            key: Metadata key

        Returns:
            Metadata value or None if not found
        """
        return self.metadata.get(key)

    def get_all_copy_includes(self) -> List[CopyInclude]:
        """Get all COPY include relationships.

        Returns:
            List of CopyInclude objects
        """
        return self.copy_includes.copy()

    def get_includes_for_file(self, filename: str) -> List[str]:
        """Get all files included by a specific file.

        Args:
            filename: Source file to get includes for

        Returns:
            List of files included by this file
        """
        return [inc.included_file for inc in self.copy_includes if inc.including_file == filename]

    def set_variable_names(self, language: str, names: Set[str]):
        """Load variable names from universe for quick lookup.

        Args:
            language: Language family ("asm" or "cpp")
            names: Set of variable names
        """
        self.variable_names[language] = names

    def is_variable(self, name: str, language: str) -> bool:
        """Check if name is a known variable in the universe.

        Args:
            name: Variable name to check
            language: Language family ("asm" or "cpp")

        Returns:
            True if the name is a variable, False otherwise
        """
        return name in self.variable_names.get(language, set())

    def get_variable_names(self, language: str) -> Set[str]:
        """Get all variable names for a language family.

        Args:
            language: Language family ("asm" or "cpp")

        Returns:
            Set of variable names
        """
        return self.variable_names.get(language, set())

    def get_line_metadata(self, line: int) -> Optional['LineMetadata']:
        """Quick accessor for line metadata.

        Args:
            line: Line number to look up

        Returns:
            LineMetadata if found, None otherwise
        """
        if not self.line_metadata_index:
            return None
        return self.line_metadata_index.get(str(self.file_path), line)
