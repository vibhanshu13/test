"""Data models for assembly analysis."""

from models.provenance import StatementProvenance
from models.symbol import Symbol, SymbolType, SymbolTable
from models.analysis_context import AnalysisContext
from models.copy_directive import CopyDirective, CopyIncludeStack, parse_copy_directive
from models.conditional_assembly import (
    SetSymbol,
    SetSymbolTable,
    SequenceSymbol,
    AIFDirective,
    AGODirective,
    ANOPDirective,
    ConditionalAssemblyState
)
from models.call_graph import CallType, CallEdge, CallGraphNode, CallGraph
from models.register_state import RegisterState, RegisterValue, ValueType
from models.db_operation import DBOperationType, DBOperation, DBOperationCatalog
from models.file_dependency import (
    DependencyType,
    DependencyEvidence,
    FileDependencyNode,
    FileDependencyEdge,
    CircularDependency,
    FileDependencyGraph
)

__all__ = [
    'StatementProvenance',
    'Symbol',
    'SymbolType',
    'SymbolTable',
    'AnalysisContext',
    'CopyDirective',
    'CopyIncludeStack',
    'parse_copy_directive',
    'SetSymbol',
    'SetSymbolTable',
    'SequenceSymbol',
    'AIFDirective',
    'AGODirective',
    'ANOPDirective',
    'ConditionalAssemblyState',
    'CallType',
    'CallEdge',
    'CallGraphNode',
    'CallGraph',
    'RegisterState',
    'RegisterValue',
    'ValueType',
    'DBOperationType',
    'DBOperation',
    'DBOperationCatalog',
    'DependencyType',
    'DependencyEvidence',
    'FileDependencyNode',
    'FileDependencyEdge',
    'CircularDependency',
    'FileDependencyGraph',
]
