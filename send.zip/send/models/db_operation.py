"""Data models for database operations."""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional


class DBOperationType(Enum):
    """Types of database operations."""
    READ = "read"
    WRITE = "write"
    UPDATE = "update"
    DELETE = "delete"
    CONTROL = "control"  # FILEC, DBOPN, DBCLS
    UNKNOWN = "unknown"


@dataclass
class DBOperation:
    """Represents a database operation extracted from assembly code."""
    operation_type: DBOperationType
    macro_name: str
    calling_routine: str
    file_record_identifier: Optional[str]
    key_operands: List[str]
    access_mode: Optional[str]  # "sequential", "direct", "keyed"
    source_file: str
    source_line: int
    source_section: Optional[str]
    confidence: str  # "high", "medium", "low"

    def to_dict(self) -> dict:
        """Serialize DB operation to dictionary."""
        return {
            "operation_type": self.operation_type.value,
            "macro_name": self.macro_name,
            "calling_routine": self.calling_routine,
            "file_record_identifier": self.file_record_identifier,
            "key_operands": self.key_operands,
            "access_mode": self.access_mode,
            "source_file": self.source_file,
            "source_line": self.source_line,
            "source_section": self.source_section,
            "confidence": self.confidence
        }


class DBOperationCatalog:
    """Catalog of all database operations in the program."""

    def __init__(self):
        self.operations: List[DBOperation] = []

    def add_operation(self, operation: DBOperation):
        """Add a database operation to the catalog.

        Args:
            operation: DBOperation to add
        """
        self.operations.append(operation)

    def get_operations_by_type(self, operation_type: DBOperationType) -> List[DBOperation]:
        """Get all operations of a specific type.

        Args:
            operation_type: Type to filter by

        Returns:
            List of matching operations
        """
        return [op for op in self.operations if op.operation_type == operation_type]

    def get_operations_by_routine(self, routine: str) -> List[DBOperation]:
        """Get all operations from a specific routine.

        Args:
            routine: Routine name to filter by

        Returns:
            List of matching operations
        """
        return [op for op in self.operations if op.calling_routine == routine]

    def get_operations_by_file_record(self, file_record: str) -> List[DBOperation]:
        """Get all operations on a specific file/record.

        Args:
            file_record: File/record identifier to filter by

        Returns:
            List of matching operations
        """
        return [op for op in self.operations
                if op.file_record_identifier == file_record]

    def to_dict(self) -> dict:
        """Serialize DB operation catalog to dictionary."""
        return {
            "operations": [op.to_dict() for op in self.operations]
        }
