"""Register state tracking for data flow analysis."""

from dataclasses import dataclass
from enum import Enum
from typing import Optional, Dict


class ValueType(Enum):
    """Types of values that can be in a register."""
    UNKNOWN = "unknown"
    LITERAL = "literal"       # =V(symbol) or =A(address)
    SYMBOL = "symbol"         # Direct symbol reference
    CONSTANT = "constant"     # Numeric constant
    ADDRESS = "address"       # Memory address


@dataclass
class RegisterValue:
    """Value stored in a register."""
    value_type: ValueType = ValueType.UNKNOWN
    literal: Optional[str] = None     # For LITERAL type
    symbol: Optional[str] = None      # For SYMBOL type
    constant: Optional[int] = None    # For CONSTANT type
    address: Optional[str] = None     # For ADDRESS type


class RegisterState:
    """Tracks the state of all 16 general-purpose registers.

    Maintains what value each register holds at a given point in execution.
    """

    def __init__(self):
        self.registers: Dict[str, RegisterValue] = {}
        # Initialize all 16 registers as unknown
        for i in range(16):
            self.registers[f"R{i}"] = RegisterValue(value_type=ValueType.UNKNOWN)

    def _normalize_register(self, register: str) -> str:
        """Normalize register name (R15, 15 -> R15).

        Args:
            register: Register name

        Returns:
            Normalized register name
        """
        if not register:
            return "R0"

        reg_upper = register.upper()

        # If already starts with R, return as-is
        if reg_upper.startswith("R"):
            return reg_upper

        # If numeric, add R prefix
        if reg_upper.isdigit():
            return f"R{reg_upper}"

        return reg_upper

    def get_register(self, register: str) -> RegisterValue:
        """Get the value in a register.

        Args:
            register: Register name (R15 or 15)

        Returns:
            RegisterValue
        """
        reg_name = self._normalize_register(register)
        return self.registers.get(reg_name, RegisterValue(value_type=ValueType.UNKNOWN))

    def set_register(self, register: str, value: RegisterValue):
        """Set the value in a register.

        Args:
            register: Register name
            value: Value to store
        """
        reg_name = self._normalize_register(register)
        self.registers[reg_name] = value

    def copy_register(self, dest: str, source: str):
        """Copy value from one register to another.

        Args:
            dest: Destination register
            source: Source register
        """
        source_value = self.get_register(source)
        self.set_register(dest, source_value)

    def clear_register(self, register: str):
        """Clear a register (set to UNKNOWN).

        Args:
            register: Register name
        """
        self.set_register(register, RegisterValue(value_type=ValueType.UNKNOWN))

    def clear_all(self):
        """Clear all registers."""
        for i in range(16):
            self.registers[f"R{i}"] = RegisterValue(value_type=ValueType.UNKNOWN)
