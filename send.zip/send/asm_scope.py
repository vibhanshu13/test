"""Shared helpers for ASM scope/routine boundary handling."""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional, Tuple

from tokenizer import ParsedLine

if TYPE_CHECKING:
    from passes.asm_line_metadata_collector import ASMLineMetadataCollector


NON_ROUTINE_OPCODES = {
    "EQU", "DC", "DS", "ENTRY", "EXTRN", "WXTRN",
    "USING", "DROP", "LTORG", "END", "MACRO", "MEND",
}

SECTION_OPCODES = {"CSECT", "DSECT", "RSECT"}
IMPLICIT_SECTION_NAME = "$IS$"


@dataclass
class ScopeState:
    """Mutable scope state while walking parsed ASM lines."""

    current_section: Optional[str] = None
    current_routine: Optional[str] = None
    _last_was_equ_star: bool = False  # True while consecutive EQU * labels share an address


def is_real_scope_label(label: Optional[str]) -> bool:
    return bool(label) and not label.startswith("&")


def is_register_like_token(token: str) -> bool:
    normalized = token.strip().upper()
    if re.fullmatch(r"R(?:1[0-5]|[0-9])", normalized):
        return True
    if normalized.isdigit():
        value = int(normalized)
        return 0 <= value <= 15
    return False


def is_equ_current_location(opcode: str, operands: List[str]) -> bool:
    """True for label anchors like `LABEL EQU *`."""
    if (opcode or "").upper() != "EQU":
        return False
    if not operands:
        return False
    return operands[0].strip() == "*"


def is_conditional_opcode(opcode: str) -> bool:
    op = (opcode or "").upper()
    if op == "AIF":
        return True
    if not op.startswith("B"):
        return False
    if op in {"B", "BR", "AGO"}:
        return False
    if op in {"BAL", "BALR", "BAS", "BASR", "BRAS", "BRASL", "BASSM", "BASM", "BSM"}:
        return False
    return True


def extract_symbolic_target(opcode: str, operands: List[str]) -> Optional[str]:
    op = (opcode or "").upper()
    if not operands:
        return None

    if op == "AIF":
        raw = operands[0].strip()
        match = re.search(r"([.&][A-Za-z0-9_$@#]+)\s*$", raw)
        return match.group(1) if match else None

    candidate = operands[-1].strip().rstrip(",")
    if not candidate:
        return None
    if is_register_like_token(candidate):
        return None
    if "(" in candidate or ")" in candidate:
        return None
    if candidate.startswith("="):
        return None
    if re.fullmatch(r"[+-]?(?:0[xX][0-9A-Fa-f]+|\d+)", candidate):
        return None
    return candidate


def format_condition_expression(opcode: str, operands: List[str], target: str) -> str:
    op = (opcode or "").upper()
    if op == "AIF" and operands:
        raw = operands[0].strip()
        match = re.search(r"^(.*?)([.&][A-Za-z0-9_$@#]+)\s*$", raw)
        if match:
            return match.group(1).strip() or raw
        return raw
    return f"{op} -> {target}"


def apply_scope_transition(
    line: ParsedLine,
    state: ScopeState,
) -> Tuple[bool, bool]:
    """Update scope state for one line.

    Returns:
        Tuple[entered_section, entered_routine]
    """
    opcode = (line.opcode or "").upper()
    label = line.label

    entered_section = False
    entered_routine = False

    if opcode in SECTION_OPCODES and is_real_scope_label(label):
        state.current_section = label
        state.current_routine = label
        state._last_was_equ_star = False
        entered_section = True
        entered_routine = True
    elif is_real_scope_label(label) and is_equ_current_location(opcode, line.operands or []):
        if not state._last_was_equ_star:
            # First label at this address — adopt it as the enclosing routine.
            if state.current_section is None:
                # Some legacy ASM files omit explicit CSECT/START. Treat the
                # first discovered routine as belonging to an implicit
                # executable section so downstream block extraction can run.
                state.current_section = IMPLICIT_SECTION_NAME
                entered_section = True
            state.current_routine = label
            entered_routine = True
        # else: co-located alias (consecutive EQU * at same address) — keep the first label.
        state._last_was_equ_star = True
    elif is_real_scope_label(label) and opcode and opcode not in NON_ROUTINE_OPCODES:
        if state.current_section is None:
            state.current_section = IMPLICIT_SECTION_NAME
            entered_section = True
        state.current_routine = label
        state._last_was_equ_star = False
        entered_routine = True
    else:
        # Any other line (instruction, directive, unlabeled) breaks a co-located chain.
        state._last_was_equ_star = False

    return entered_section, entered_routine


def annotate_provenance_scope(
    parsed_lines: List[ParsedLine],
    line_collector: Optional["ASMLineMetadataCollector"] = None,
    file_path: Optional[Path] = None,
) -> None:
    """Best-effort routine/section scope annotation for assembly lines."""
    state = ScopeState()
    active_conditions: List[tuple[int, str, str]] = []
    # Track whether we are currently inside a MACRO...MEND definition body.
    # Lines inside a macro body are template code, not executable instructions,
    # and must not be recorded in line_metadata (the call site lines are the
    # ones that matter at analysis time).
    in_macro_body: bool = False

    label_to_line = {}
    for line in parsed_lines:
        if is_real_scope_label(line.label):
            label_to_line[line.label] = line.provenance.original_line

    for line in parsed_lines:
        opcode = (line.opcode or "").upper()
        line_number = line.provenance.original_line

        # Update MACRO body state BEFORE processing this line so the MACRO
        # directive itself is not treated as a body line.
        if opcode == "MACRO":
            in_macro_body = True
        elif opcode == "MEND":
            in_macro_body = False

        active_conditions = [c for c in active_conditions if line_number < c[0]]
        if line_collector:
            line_collector.set_conditions([(expr, ctype) for _, expr, ctype in active_conditions])

        entered_section, entered_routine = apply_scope_transition(line, state)
        if entered_section and line_collector and line.label:
            active_conditions.clear()
            line_collector.set_conditions([])
            line_collector.enter_section(line.label, line.provenance.original_line)
        elif entered_routine and line_collector and line.label:
            line_collector.enter_routine(line.label, line.provenance.original_line)

        line.provenance.section = state.current_section
        line.provenance.routine = state.current_routine

        # Skip line_metadata recording for MACRO body lines (template code).
        if line_collector and opcode and file_path and not in_macro_body:
            line_collector.record_line(str(file_path), line.provenance.original_line)

        if line_collector and opcode and is_conditional_opcode(opcode):
            target = extract_symbolic_target(opcode, line.operands or [])
            if target:
                target_line = label_to_line.get(target)
                if target_line and target_line > line_number:
                    expr = format_condition_expression(opcode, line.operands or [], target)
                    active_conditions.append((target_line, expr, opcode))
