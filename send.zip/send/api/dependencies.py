"""FastAPI dependency functions."""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import APIKeyHeader, HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from api.config import settings
from api.storage.workspace import WorkspaceManager

logger = logging.getLogger(__name__)

API_KEY_HEADER = APIKeyHeader(name="X-API-Key", auto_error=False)
_bearer = HTTPBearer(auto_error=False)


# ---------------------------------------------------------------------------
# API-key auth (existing, dev-mode bypass)
# ---------------------------------------------------------------------------

async def require_api_key(api_key: Optional[str] = Security(API_KEY_HEADER)) -> None:
    valid_keys = settings.API_KEYS
    if not valid_keys:
        return  # dev mode
    if not api_key or api_key not in valid_keys:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Invalid or missing API key.")


# ---------------------------------------------------------------------------
# JWT auth (user-aware)
# ---------------------------------------------------------------------------

def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Security(_bearer),
    db: Session = Depends(lambda: next(_get_db())),
):
    """Return the authenticated User or raise 401."""
    from api.auth import decode_access_token, get_user_by_username
    from api.db import get_db

    if not credentials:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated.")
    payload = decode_access_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token.")
    # Re-open DB inside the dependency — this function is called with Depends so
    # we need a proper DB session, not a generator stub.
    from api.db import SessionLocal
    db = SessionLocal()
    try:
        user = get_user_by_username(db, payload["sub"])
        if not user or not user.is_active:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found or inactive.")
        db.expunge(user)  # detach so caller can use without session
        return user
    finally:
        db.close()


def require_admin(
    credentials: Optional[HTTPAuthorizationCredentials] = Security(_bearer),
):
    """Return the authenticated User if admin, else raise 403."""
    from api.auth import decode_access_token, get_user_by_username
    from api.db import SessionLocal

    if not credentials:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated.")
    payload = decode_access_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token.")
    if payload.get("role") != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin access required.")

    db = SessionLocal()
    try:
        user = get_user_by_username(db, payload["sub"])
        if not user or not user.is_active:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found or inactive.")
        db.expunge(user)
        return user
    finally:
        db.close()


def _get_db():
    """Internal generator shim — not used directly."""
    from api.db import get_db
    yield from get_db()


# ---------------------------------------------------------------------------
# Job lookup
# ---------------------------------------------------------------------------

async def get_job_or_404(job_id: str) -> Dict[str, Any]:
    ws = WorkspaceManager(job_id)
    meta = ws.get_job_meta()
    if meta is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Job '{job_id}' not found.")
    return meta
