"""Pydantic schemas for the Setter Analysis API.

Setter Analysis = an LLM explanation layer over the *chainless* backward-traversal
engine.  For one variable we enumerate every setter site (``root``); for each root
we explain — step by step, following the algorithm — every condition that had to be
true to set the value at that site, walking all callers (and their callers, each
with its own call-conditions) plus the dependent variables and how they were set.

Two prose variants are generated (business / technical); the frontend renders four
UI modes (techLevel 0-3) on top of those two variants, masking references per level
exactly as the Investigation tab does.

Identity / cache: standalone per ``(kb_id, variable, root_id, mode)`` — no
conversations.  ``mode`` on the wire is one of the four UI ids
(business | business_plus | technical_guided | technical) and collapses to a
``business_mode`` bool (0/1 → business, 2/3 → technical) server-side.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

# Wire mode ids (the four UI modes). business_mode = id in the first two.
MODE_IDS = ("business", "business_plus", "technical_guided", "technical")


def is_business_mode(mode: Optional[str]) -> bool:
    """Collapse a 4-mode UI id (or legacy persona) to the binary prose variant."""
    return (mode or "business").lower() in ("business", "business_plus")


def prose_variant(mode: Optional[str]) -> str:
    """The cache/prose dimension: 'business' or 'technical'."""
    return "business" if is_business_mode(mode) else "technical"


# ---------------------------------------------------------------------------
# Status vocabulary (one place)
# ---------------------------------------------------------------------------
# none        — never analysed
# pending     — Celery task queued
# running     — structural traversal in progress
# active      — structural traversal complete (conditions/deps/callers known)
# explained   — all prose variants generated and cached
# failed      — see `error`
STATUS_NONE = "none"
STATUS_PENDING = "pending"
STATUS_RUNNING = "running"
STATUS_ACTIVE = "active"
STATUS_EXPLAINED = "explained"
STATUS_FAILED = "failed"
# Transient state returned by GET /analysis when the structure is ready but the
# requested prose variant is still being produced by the background job. The UI
# shows a "generating" panel (with progress/calls-remaining from /status) and
# re-fetches when ready — the request never blocks on inline generation.
STATUS_GENERATING = "generating"


# ---------------------------------------------------------------------------
# Discovery: setter list + shared variable definition
# ---------------------------------------------------------------------------

class VariableDefinition(BaseModel):
    """Shared, mode-resolved definition shown ABOVE the setter list (common to all setters)."""

    variable: str
    business_name: str = ""
    what_it_is: str = ""                 # business meaning (2-4 sentences), mode-resolved
    declaration_file: str = ""           # technical only (frontend masks for L0)
    declaration_line: int = 0
    data_type: str = ""
    role: str = ""                       # business | control | persistence | ...
    notes: str = ""


class SetterRootStatus(BaseModel):
    """One setter site + its analysis status."""

    root_id: str
    file_stem: str
    file_type: str = "asm"               # asm | cpp
    line: int = 0
    instruction: str = ""
    setter_expression: str = ""
    business_label: str = ""             # human label for this setter site (e.g. "Online-source switch")
    short_description: str = ""          # one-line: what value is written and where (LLM, batched)
    status: str = STATUS_NONE
    modes_ready: List[str] = Field(default_factory=list)   # subset of {"business","technical"}
    is_counterpart_root: bool = False
    counterpart_certainty: Optional[str] = None
    error: str = ""


class ComplexityDimension(BaseModel):
    """One headline complexity signal, shown instantly when a variable is entered.

    Computed cheaply from discovery (enumeration) — no traversal — so the user gets
    3-4 of these the moment they search.
    """

    key: str                             # setter_sites | files | languages | counterparts | ...
    label: str                           # "Setter sites"
    value: str                           # display value, e.g. "7" or "ASM + C++"
    level: str = "low"                   # low | medium | high  (drives colour)
    detail: str = ""                     # one-line explanation / tooltip


class SetterListResponse(BaseModel):
    """POST /setter-analysis/setters — discovery (cheap, no traversal)."""

    session_id: str
    variable: str
    language: str = "auto"
    variable_definition: VariableDefinition
    complexity: List[ComplexityDimension] = Field(default_factory=list)
    setter_roots: List[SetterRootStatus] = Field(default_factory=list)
    counterparts: List[Dict[str, Any]] = Field(default_factory=list)
    stats: Dict[str, Any] = Field(default_factory=dict)
    warnings: List[str] = Field(default_factory=list)
    # The per-setter one-liner descriptions are generated in the background and
    # cached; False means the UI should poll GET .../descriptions and fill them in.
    descriptions_ready: bool = False


class SetterListRequest(BaseModel):
    variable: str
    language: Optional[str] = Field(default=None, description="asm|cpp; auto-detect if omitted")
    mode: str = Field(default="business", description="one of MODE_IDS; drives variable_definition prose")


class SetterDescriptionsResponse(BaseModel):
    """GET /setter-analysis/descriptions — poll the background one-liner job."""

    variable: str
    mode: str
    status: str = STATUS_NONE          # none | pending | ready | failed
    ready: bool = False
    descriptions: Dict[str, str] = Field(default_factory=dict)   # {root_id: one-liner}
    error: str = ""


# ---------------------------------------------------------------------------
# Analyze (kick the Celery job) + status polling
# ---------------------------------------------------------------------------

class AnalyzeSetterRequest(BaseModel):
    variable: str
    session_id: str
    language: Optional[str] = None
    force: bool = False                  # re-run even if a fresh cache exists


class AnalyzeSetterResponse(BaseModel):
    root_id: str
    status: str                          # pending | running | active | explained
    task_id: str = ""
    cached: bool = False                 # true when a fresh result was already present


class SetterStatusResponse(BaseModel):
    root_id: str
    status: str
    structural_done: bool = False
    modes_ready: List[str] = Field(default_factory=list)
    progress: int = 0                    # 0-100 for the UI progress bar
    progress_label: str = ""             # e.g. "Tracing callers", "Explaining (business)"
    llm_calls_total: int = 0             # total planned LLM calls (both prose variants)
    llm_calls_done: int = 0              # LLM calls completed so far
    llm_calls_remaining: int = 0         # max(0, total - done) — shown in the UI
    error: str = ""


# ---------------------------------------------------------------------------
# The analysis itself: summary + step-by-step (one prose variant, mode-resolved)
# ---------------------------------------------------------------------------

class SetterConditionItem(BaseModel):
    """One condition that had to be true.  `check` is empty in business prose."""

    check: str = ""                      # verbatim guard (technical only)
    in_plain_terms: str = ""             # business meaning, naming the value tested
    decides: str = ""                    # what each outcome means
    file_stem: str = ""                  # where this condition lives (technical)
    line: int = 0
    occurrences: int = 1                 # how many raw guard sites shared this text


class ConditionGroup(BaseModel):
    """Conditions grouped by where they come from — the 'different subheadings' the user wants."""

    origin: str                          # setter_local | caller_call_condition | dependent_variable
    heading: str                         # subheading text (e.g. "Conditions inside the setter file")
    where: str = ""                      # file/routine locus (technical) or business locus
    conditions: List[SetterConditionItem] = Field(default_factory=list)


class SetterDepVar(BaseModel):
    name: str
    business_name: str = ""
    kind: str = ""                       # data_flow | conditional_guard | prior_value
    constraint: str = ""                 # e.g. "== C400" (technical)
    how_it_was_set: str = ""             # business prose on how this dep itself got its value
    why_it_matters: str = ""             # its influence on the root variable
    relevant: bool = True
    pruned_reason: str = ""              # set when relevant=False (sound value-pruning)
    occurrences: int = 1                 # how many raw dep sites shared this name


class SetterSummary(BaseModel):
    """End-to-end summary for ONE setter site (mode-resolved)."""

    variable_business_name: str = ""
    what_it_is: str = ""                 # restated meaning for this site
    what_its_set_to: str = ""            # the value(s) this setter writes + when
    conditions_overview: str = ""        # crisp prose: all conditions that had to be true
    condition_groups: List[ConditionGroup] = Field(default_factory=list)
    dependent_variables_story: str = ""  # how each dep var was set + its influence
    dependent_variables: List[SetterDepVar] = Field(default_factory=list)
    chain_narrative: str = ""            # the caller journey (entry point → this setter)
    full_story: str = ""                 # complete end-to-end account
    # Coverage totals — so the summary never reads "complete" when it isn't.
    total_conditions: int = 0            # distinct conditions across the whole walk
    total_dependent_variables: int = 0   # distinct dependent variables
    total_caller_files: int = 0          # distinct caller files reaching this setter
    total_caller_sites: int = 0          # raw caller edges/sites (path-exploded count)
    max_caller_depth: int = 0            # deepest caller hop


class SetterStepSource(BaseModel):
    """Code chunk for a step (technical modes only)."""

    file: str = ""
    file_type: str = "asm"
    start_line: int = 0
    end_line: int = 0
    code: str = ""
    highlight_lines: List[int] = Field(default_factory=list)


class SetterStep(BaseModel):
    """One step in the walkthrough, following the algorithm as it moves outward."""

    index: int
    total_steps: int
    kind: str                            # setter_site | caller_hop | dependent_variable
    headline: str = ""
    file_stem: str = ""
    file_type: str = "asm"
    variable_in_step: str = ""
    phase_label: str = ""                # e.g. "Setter site", "Caller", "Dependent variable"
    caller_depth: int = 0                # 0 = setter site itself; n = n hops up the caller tree
    parent_index: Optional[int] = None   # connection: the step this one feeds into (keeps the thread)
    why_we_are_here: str = ""            # the condition / reason we reached this place
    explanation: str = ""                # narrative for this step
    condition_groups: List[ConditionGroup] = Field(default_factory=list)
    dependent_variables: List[SetterDepVar] = Field(default_factory=list)
    source: Optional[SetterStepSource] = None
    warnings: List[str] = Field(default_factory=list)


class SetterAnalysisResponse(BaseModel):
    """GET /setter-analysis/setters/{root_id}/analysis — the full analysis for one mode."""

    root_id: str
    variable: str
    mode: str                            # the requested UI mode id (echoed back)
    prose_variant: str = "business"      # business | technical (what actually backs `mode`)
    status: str = STATUS_ACTIVE
    summary: Optional[SetterSummary] = None
    steps: List[SetterStep] = Field(default_factory=list)
    graph: Optional[Dict[str, Any]] = None     # optional caller/dep graph for the right-rail view
    warnings: List[str] = Field(default_factory=list)
    # Progressive/banded generation — partial content is served as bands finish.
    partial: bool = False                # True while more bands are still being rendered
    bands_done: int = 0                  # bands completed so far
    bands_total: int = 0                 # total bands for this analysis
    coverage: Optional[Dict[str, Any]] = None  # full totals from the scaffold
    # Alternative entry→setter paths: satisfying ANY ONE reaches the setter (OR
    # across paths; AND of the call-conditions within a path). Each item:
    # {files:[entry,…,setter], length:int, conditions:[{...}]}.
    paths: List[Dict[str, Any]] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Internal: the cached prose payload shape produced by the explainer.
# explain_setter_root(...) returns a dict that validates as ProsePayload.
# ---------------------------------------------------------------------------

class ProsePayload(BaseModel):
    """What the explainer produces and the task gzips into SetterAnalysisProse.payload_gz."""

    summary: SetterSummary
    steps: List[SetterStep] = Field(default_factory=list)
    graph: Optional[Dict[str, Any]] = None
    variable_definition: Optional[VariableDefinition] = None   # business/technical def for this variant
    # Progressive/banded generation metadata (written mid-generation too).
    partial: bool = False
    bands_done: int = 0
    bands_total: int = 0
    coverage: Optional[Dict[str, Any]] = None
    paths: List[Dict[str, Any]] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Conversations history — past setter analyses grouped by variable
# ---------------------------------------------------------------------------

class SetterHistoryRoot(BaseModel):
    """Lightweight summary of one setter root for the history panel."""
    root_id: str
    file_stem: str = ""
    file_type: str = "asm"
    line: int = 0
    status: str = STATUS_NONE
    updated_at: Optional[str] = None


class SetterConversationEntry(BaseModel):
    """One analysed variable, grouped across all its setter roots."""
    variable: str
    root_count: int = 0
    explained_count: int = 0
    pending_count: int = 0
    last_updated: str = ""
    roots: List[SetterHistoryRoot] = Field(default_factory=list)


class SetterConversationsResponse(BaseModel):
    conversations: List[SetterConversationEntry] = Field(default_factory=list)
