"""Schemas for auth endpoints."""

from __future__ import annotations

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field, field_validator


class UserRole(str, Enum):
    USER = "user"
    ADMIN = "admin"


class RegisterRequest(BaseModel):
    username: str = Field(
        examples=["alice", "bob_smith", "analyst-01"],
        description=(
            "Unique username. 3–64 characters. Allowed: letters, digits, underscores, hyphens. "
            "Examples: alice, bob_smith, analyst-01."
        ),
    )
    password: str = Field(
        examples=["MyStr0ngPass!"],
        description="Account password. Minimum 8 characters. Stored as a bcrypt hash.",
    )
    role: UserRole = Field(
        default=UserRole.USER,
        examples=["user", "admin"],
        description=(
            "Role to assign. "
            '"user" — can view knowledge bases they have been granted access to. '
            '"admin" — can run pipelines, manage users, and grant KB access. '
            "Only an existing admin can create another admin (except on first boot)."
        ),
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {"username": "alice", "password": "MyStr0ngPass!", "role": "user"}
            ]
        }
    }

    @field_validator("username")
    @classmethod
    def username_alphanumeric(cls, v: str) -> str:
        import re
        if not re.match(r"^[a-zA-Z0-9_\-]{3,64}$", v):
            raise ValueError(
                "Username must be 3–64 characters: letters, digits, underscores or hyphens only."
            )
        return v

    @field_validator("password")
    @classmethod
    def password_min_length(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters.")
        return v


class LoginRequest(BaseModel):
    username: str = Field(examples=["alice"], description="Username of the account.")
    password: str = Field(examples=["MyStr0ngPass!"], description="Plaintext password.")

    model_config = {
        "json_schema_extra": {
            "examples": [{"username": "alice", "password": "MyStr0ngPass!"}]
        }
    }


class TokenResponse(BaseModel):
    access_token: str = Field(
        description=(
            "JWT bearer token. Use in subsequent requests as: "
            "Authorization: Bearer <token>. Expires after the configured TTL (default 24 h)."
        ),
    )
    token_type: str = Field(default="bearer", description='Always "bearer".')
    username: str = Field(description="Username of the authenticated account.")
    role: str = Field(
        examples=["user", "admin"],
        description='Role of the authenticated account: "user" or "admin".',
    )


class UserResponse(BaseModel):
    id: int = Field(description="Auto-incremented internal user ID.")
    username: str = Field(description="Unique username.")
    role: str = Field(
        examples=["user", "admin"],
        description='Account role: "user" or "admin".',
    )
    is_active: bool = Field(
        description="False if the account has been deactivated by an admin.",
    )
    created_at: datetime = Field(description="UTC timestamp when the account was created.")

    model_config = {"from_attributes": True}


class UpdateRoleRequest(BaseModel):
    role: UserRole = Field(
        examples=["user", "admin"],
        description=(
            'New role to assign. '
            '"admin" — promotes to admin. '
            '"user" — downgrades to standard user. '
            "Takes effect on next login."
        ),
    )

    model_config = {
        "json_schema_extra": {
            "examples": [{"role": "admin"}]
        }
    }


class UserListResponse(BaseModel):
    users: list[UserResponse]
    total: int = Field(description="Total number of user accounts in the system.")
