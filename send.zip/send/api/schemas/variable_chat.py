"""Schemas for the variable chat endpoints.

Chat is scoped to one backward-lineage session. A chat session must be created
first (POST /{kb_id}/chat), then messages are sent one at a time
(POST /{kb_id}/chat/{chat_session_id}/message). The explain session linked to
the same backward_session_id provides the grounding context.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class ChatStartRequest(BaseModel):
    backward_session_id: str = Field(
        min_length=1,
        description=(
            "Backward-lineage session to anchor this chat. "
            "The linked explain session (if any) is used as grounding context."
        ),
    )


class ChatStartResponse(BaseModel):
    chat_session_id: str = Field(description="Unique ID for this chat session. Pass to /message.")
    backward_session_id: str
    root_variable: str = Field(description="Root variable being discussed (e.g. 'LG1OSI').")


class ChatMessageRequest(BaseModel):
    message: str = Field(min_length=1, description="User's question or follow-up message.")


class ChatReplyResponse(BaseModel):
    chat_session_id: str
    root_variable: str
    reply: str = Field(description="LLM-generated answer grounded in the lineage context.")
    turn_index: int = Field(
        description="0-based index of this exchange (number of user messages sent so far, including this one)."
    )
