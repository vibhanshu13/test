"""Schemas for the variable explanation endpoints.

Explanation is driven by an existing backward-lineage/chunks session.
Each call explains exactly one tuple (file_stem, variable_in_file, phase)
from that session — one step in the variable-file lineage chain.
Context accumulates across calls so that by the final tuple the user
has a complete picture of the variable's full lineage.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class ExplainVariableRequest(BaseModel):
    backward_session_id: str = Field(
        min_length=1,
        description=(
            "Session ID from a prior POST /{kb_id}/backward-lineage/chunks call. "
            "The backward session must have processed at least tuple 0 already."
        ),
    )
    start_tuple_index: int = Field(
        default=0,
        ge=0,
        description="Tuple index to begin from. 0 = first tuple (typically the setter file).",
    )


class ExplainNextRequest(BaseModel):
    backward_session_id: str = Field(min_length=1)
    current_tuple_index: int = Field(
        ge=0,
        description="The tuple index that was just explained. Next will be current_tuple_index + 1.",
    )


class ExplainLayerResponse(BaseModel):
    # Session linkage
    backward_session_id: str
    root_variable: str = Field(description="Root variable being traced (e.g. 'LG1OSI').")

    # Position in the lineage walk
    tuple_index: int = Field(description="0-based index of this tuple in the backward session.")
    next_tuple_index: int = Field(description="Pass this to /explain-variable/next.")
    total_tuples_known: int = Field(
        description=(
            "Number of tuples the backward session has processed so far. "
            "May grow if the session is not yet complete."
        )
    )
    is_session_complete: bool = Field(
        description="True when the backward-lineage session has finished all tuples."
    )

    # Variable-file identity for this layer
    file_stem: str = Field(description="Source file for this layer (e.g. 'da78').")
    file_type: str = Field(description="'asm' or 'cpp'.")
    variable_in_file: str = Field(
        description=(
            "Variable name as resolved in this file. "
            "May differ from root_variable due to C++ field aliases "
            "(e.g. root='LG1OSI', here='CasGLRec.onlineSrcInd')."
        )
    )
    phase: str = Field(
        description=(
            "Traversal phase: 'modifier' | 'upstream' | 'root_var_downstream' | "
            "'dep_var_chain' | 'dep_var_downstream' | 'cpp_dep_var_extended'."
        )
    )
    phase_label: str = Field(
        description="Human-readable label, e.g. 'Setter File', 'Upstream Caller', 'Dependent Variable'."
    )

    # Content
    tuple_summary: str = Field(
        description="Pre-analysed one-line summary produced by the backward traversal engine."
    )
    explanation: str = Field(
        description="LLM-generated plain-English explanation for this variable-file step."
    )

    # Termination
    is_complete: bool = Field(
        description="True when this is the last available tuple (no more Explain More steps)."
    )
