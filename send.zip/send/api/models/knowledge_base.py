"""KnowledgeBase, KnowledgeBaseAccess, and FileSummary ORM models."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from api.db import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class KnowledgeBase(Base):
    __tablename__ = "knowledge_bases"

    # UUID = job_id so the output dir at jobs/{id}/output/ resolves directly
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    created_by: Mapped[str] = mapped_column(String(64), nullable=False)  # admin username

    # Datasource reference (the uploaded codebase that was analysed)
    datasource_username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    datasource_folder: Mapped[str | None] = mapped_column(String(256), nullable=True)
    source_path: Mapped[str] = mapped_column(String(512), nullable=False)

    status: Mapped[str] = mapped_column(String(16), default="pending", nullable=False)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
    )

    access_grants: Mapped[list[KnowledgeBaseAccess]] = relationship(
        "KnowledgeBaseAccess", back_populates="kb", cascade="all, delete-orphan"
    )


class KnowledgeBaseAccess(Base):
    __tablename__ = "knowledge_base_access"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kb_id: Mapped[str] = mapped_column(String(36), ForeignKey("knowledge_bases.id"), nullable=False)
    username: Mapped[str] = mapped_column(String(64), nullable=False)  # user granted access
    granted_by: Mapped[str] = mapped_column(String(64), nullable=False)  # admin who granted

    granted_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False
    )

    kb: Mapped[KnowledgeBase] = relationship("KnowledgeBase", back_populates="access_grants")

    __table_args__ = (UniqueConstraint("kb_id", "username", name="uq_kb_user"),)


class FileSummary(Base):
    """Cached LLM-generated summary for a source file within a knowledge base.

    Cache key: (kb_id, file_path).
    A summary is considered stale when kb_updated_at < KnowledgeBase.updated_at,
    which happens automatically whenever the KB is re-indexed.
    """

    __tablename__ = "file_summaries"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kb_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("knowledge_bases.id", ondelete="CASCADE"), nullable=False
    )
    # Relative path as supplied by the caller, e.g. "src/asm/lu82.asm"
    file_path: Mapped[str] = mapped_column(Text, nullable=False)
    # The markdown summary text; empty string means generation is still pending
    summary: Mapped[str] = mapped_column(Text, nullable=False, default="")
    # Snapshot of KnowledgeBase.updated_at at generation time — used for staleness check
    kb_updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False
    )

    __table_args__ = (
        UniqueConstraint("kb_id", "file_path", name="uq_file_summary"),
        Index("ix_file_summaries_kb_id", "kb_id"),
    )
