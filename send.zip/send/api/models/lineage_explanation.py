"""SQLAlchemy models for lineage explanation DB cache.

Two tables:
- lineage_explanation_cache  — final synthesis + variable_table per (kb, chain, mode)
- lineage_step_cache         — per-step StepExplanation per (session, step, mode)

Both follow the FileSummary pattern: kb_id FK with CASCADE, kb_updated_at snapshot
for staleness detection, auto-created via Base.metadata.create_all (no Alembic).
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import DateTime, ForeignKey, Index, Integer, LargeBinary, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from api.db import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class LineageExplanationCache(Base):
    """Final synthesis + variable_table for one (kb, chain, mode) combination.

    payload_gz is pack_blob({synthesis: ..., variable_table: ...}).
    Staleness: if kb.updated_at > kb_updated_at, this row is a miss.
    """
    __tablename__ = "lineage_explanation_cache"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kb_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("knowledge_bases.id", ondelete="CASCADE"), nullable=False
    )
    root_variable: Mapped[str] = mapped_column(String(128), nullable=False)
    chain_hash: Mapped[str] = mapped_column(String(16), nullable=False)
    mode: Mapped[str] = mapped_column(String(16), nullable=False)  # "technical" | "business"
    backward_session_id: Mapped[str] = mapped_column(String(64), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="running")  # running|success|failed
    total_steps: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    job_id: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    payload_gz: Mapped[bytes] = mapped_column(LargeBinary, nullable=True)
    error: Mapped[str] = mapped_column(Text, nullable=True)
    kb_updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=_utcnow)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
    )

    __table_args__ = (
        UniqueConstraint("kb_id", "chain_hash", "root_variable", "mode", name="uq_lineage_explanation_cache"),
        Index("ix_lineage_explanation_cache_kb_var", "kb_id", "root_variable"),
    )


class LineageStepCache(Base):
    """Per-step StepExplanation for one (session, step_index, mode) combination.

    explanation_gz is pack_blob(step_explanation_dict).
    Keyed by backward_session_id so it survives KB re-runs as long as the session is stable.
    """
    __tablename__ = "lineage_step_cache"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kb_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("knowledge_bases.id", ondelete="CASCADE"), nullable=False
    )
    backward_session_id: Mapped[str] = mapped_column(String(64), nullable=False)
    root_variable: Mapped[str] = mapped_column(String(128), nullable=False)
    chain_hash: Mapped[str] = mapped_column(String(16), nullable=False)
    step_index: Mapped[int] = mapped_column(Integer, nullable=False)
    mode: Mapped[str] = mapped_column(String(16), nullable=False)  # "technical" | "business"
    explanation_gz: Mapped[bytes] = mapped_column(LargeBinary, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, nullable=False)

    __table_args__ = (
        UniqueConstraint("backward_session_id", "step_index", "mode", name="uq_lineage_step_cache"),
        Index("ix_lsc_lookup", "kb_id", "backward_session_id", "mode", "step_index"),
    )


