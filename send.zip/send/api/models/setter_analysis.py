"""SQLAlchemy models for the Setter Analysis DB cache.

Standalone per-project cache (NO conversations) for the chainless setter-analysis
feature.  Two tables, mirroring the FileSummary / LineageExplanationCache pattern
(kb_id FK CASCADE, kb_updated_at snapshot for staleness, auto-created via
Base.metadata.create_all — no Alembic):

- setter_analysis_structural — one row per (kb_id, variable, root_id): the
  language-agnostic traversal result (conditions, deps, caller tree) + lifecycle
  status.  Marking this row "active" is the fast "structural done" signal.
- setter_analysis_prose — one row per (kb_id, variable, root_id, prose_variant):
  the LLM summary + steps for that variant (business | technical).

Resumability: the chainless ``ChainlessBackwardSession`` checkpoints the traversal
itself (msgpack chunks); these rows record lifecycle + cache the explanation.  A
re-dispatch reloads the session (skips done traversal) and skips prose variants
that already have a success row.
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (
    DateTime,
    ForeignKey,
    Index,
    Integer,
    LargeBinary,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from api.db import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class SetterAnalysisStructural(Base):
    """Structural traversal result + lifecycle for one setter site.

    payload_gz is pack_blob(structural_tuple) — the assembled chainless tuple for
    this root (node, conditions, deps, callers tree, downstream) plus the
    deterministic reasoning scaffold.  Mode-independent.
    Staleness: if kb.updated_at > kb_updated_at, this row is a miss.
    """

    __tablename__ = "setter_analysis_structural"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kb_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("knowledge_bases.id", ondelete="CASCADE"), nullable=False
    )
    variable: Mapped[str] = mapped_column(String(128), nullable=False)
    root_id: Mapped[str] = mapped_column(String(256), nullable=False)
    session_id: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    file_stem: Mapped[str] = mapped_column(String(128), nullable=False, default="")
    file_type: Mapped[str] = mapped_column(String(8), nullable=False, default="asm")
    line: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    # none|pending|running|active|explained|failed  (see api.schemas.setter_analysis)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="pending")
    # 0-100 overall completion for the live UI progress bar; updated as the task advances.
    progress: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    progress_label: Mapped[str] = mapped_column(String(128), nullable=False, default="")
    # Backend-driven work counters: total planned LLM calls across both prose
    # variants and how many have completed — surfaced as "N LLM calls remaining".
    llm_calls_total: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    llm_calls_done: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    job_id: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    task_id: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    payload_gz: Mapped[bytes] = mapped_column(LargeBinary, nullable=True)
    error: Mapped[str] = mapped_column(Text, nullable=True)
    kb_updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=_utcnow)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
    )

    __table_args__ = (
        UniqueConstraint("kb_id", "variable", "root_id", name="uq_setter_analysis_structural"),
        Index("ix_setter_struct_kb_var", "kb_id", "variable"),
    )


class SetterAnalysisProse(Base):
    """LLM summary + steps for one (kb, variable, root, prose_variant).

    payload_gz is pack_blob(ProsePayload dict) — {summary, steps, graph,
    variable_definition}.  prose_variant ∈ {"business","technical"}; the four UI
    modes map onto these two server-side.
    """

    __tablename__ = "setter_analysis_prose"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kb_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("knowledge_bases.id", ondelete="CASCADE"), nullable=False
    )
    variable: Mapped[str] = mapped_column(String(128), nullable=False)
    root_id: Mapped[str] = mapped_column(String(256), nullable=False)
    prose_variant: Mapped[str] = mapped_column(String(16), nullable=False)  # business|technical
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="running")  # running|success|failed
    payload_gz: Mapped[bytes] = mapped_column(LargeBinary, nullable=True)
    error: Mapped[str] = mapped_column(Text, nullable=True)
    kb_updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=_utcnow)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
    )

    __table_args__ = (
        UniqueConstraint("kb_id", "variable", "root_id", "prose_variant", name="uq_setter_analysis_prose"),
        Index("ix_setter_prose_lookup", "kb_id", "variable", "root_id", "prose_variant"),
    )


class SetterDescriptionCache(Base):
    """Per-setter one-liner descriptions for one (kb, variable, prose_variant).

    Discovery is NON-BLOCKING: it returns the setter list instantly with
    deterministic labels and dispatches a background job to fill these LLM
    one-liners.  Cached here keyed STABLY by (kb, variable, prose_variant) — NOT
    on the chainless session id (which churns with the call-graph file mtime), so
    they are computed once and reused forever (until the KB changes).

    payload_gz is pack_blob({root_id: description}).
    """

    __tablename__ = "setter_description_cache"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kb_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("knowledge_bases.id", ondelete="CASCADE"), nullable=False
    )
    variable: Mapped[str] = mapped_column(String(128), nullable=False)
    prose_variant: Mapped[str] = mapped_column(String(16), nullable=False)  # business|technical
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="pending")  # pending|ready|failed
    payload_gz: Mapped[bytes] = mapped_column(LargeBinary, nullable=True)
    error: Mapped[str] = mapped_column(Text, nullable=True)
    kb_updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=_utcnow)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
    )

    __table_args__ = (
        UniqueConstraint("kb_id", "variable", "prose_variant", name="uq_setter_description_cache"),
        Index("ix_setter_desc_lookup", "kb_id", "variable", "prose_variant"),
    )


# ===========================================================================
# CHAINED setter analysis (chain-files backward lineage) — project-INDEPENDENT
# cache, keyed on (variable, chain_key) [+ mode for prose].  Every project is
# structurally identical, so the cache is reused across projects; invalidation
# is by ``schema_version`` (bump when the engine/prompt changes) rather than a
# per-KB FK snapshot.  Auto-created via Base.metadata.create_all.
# ===========================================================================

class ChainSetterStructural(Base):
    """Deterministic chain-scoped multi-setter result for one (variable, chain).

    payload_gz = pack_blob(analyze_chain_setters output): the reachable setters,
    each with its boolean rule, dependent variables (+their setters/conditions),
    variable graph and steps.  Mode-independent.
    """

    __tablename__ = "chain_setter_structural"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    variable: Mapped[str] = mapped_column(String(128), nullable=False)
    chain_key: Mapped[str] = mapped_column(String(64), nullable=False)   # hash(chain_files + entry_fn)
    chain_json: Mapped[str] = mapped_column(Text, nullable=True)         # display: chain files + entry
    schema_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="pending")  # pending|running|active|explained|failed
    progress: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    progress_label: Mapped[str] = mapped_column(String(128), nullable=False, default="")
    llm_calls_total: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    llm_calls_done: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    job_id: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    task_id: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    n_setters: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    payload_gz: Mapped[bytes] = mapped_column(LargeBinary, nullable=True)
    error: Mapped[str] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
    )

    __table_args__ = (
        UniqueConstraint("variable", "chain_key", name="uq_chain_setter_structural"),
        Index("ix_chain_struct_lookup", "variable", "chain_key"),
    )


class ChainSetterProse(Base):
    """Per-mode LLM prose for one (variable, chain_key, mode).

    payload_gz = pack_blob(ChainProsePayload): per-setter summary, boolean-rule
    phrasing, dep-var detail, step-by-step, + canonical business names.
    mode ∈ {business | business_refs | technical}.
    """

    __tablename__ = "chain_setter_prose"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    variable: Mapped[str] = mapped_column(String(128), nullable=False)
    chain_key: Mapped[str] = mapped_column(String(64), nullable=False)
    mode: Mapped[str] = mapped_column(String(20), nullable=False)   # business|business_refs|technical
    schema_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="running")  # running|success|failed
    payload_gz: Mapped[bytes] = mapped_column(LargeBinary, nullable=True)
    error: Mapped[str] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
    )

    __table_args__ = (
        UniqueConstraint("variable", "chain_key", "mode", name="uq_chain_setter_prose"),
        Index("ix_chain_prose_lookup", "variable", "chain_key", "mode"),
    )
