"""Shared helper to detect whether a name refers to a C++/ASM variable or function.

Used by both the lineage endpoints (to recognize wrong-kind input + redirect)
and the process cpp-call-chain endpoint (same logic, reverse direction).

Detection rules — fully deterministic, no name heuristics:
- ASM/MAC blueprint:
    variable → at least one SETTER for `name` (via scan_blueprint_for_setters)
    function → `name` appears as `id` in `.asm.json::subroutines[]`
- C++ blueprint:
    variable → find_cpp_seed_nodes returns ≥1 seed (via GVL)
    function → `name` is a key in `.cpp.json::call_graph.nodes`

Accepts an optional pre-loaded blueprint dict to avoid double I/O on the
caller side. (Necessary for the lineage routes which already load the
blueprint for the SETTER check.)
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Tuple

# Public return type
Kind = Literal["variable", "function", "both", "unknown"]


def _is_variable_in_asm(blueprint_path: Path, name: str) -> bool:
    """True if `name` has at least one SETTER in an ASM/MAC blueprint."""
    try:
        from find_variable_modifiers import scan_blueprint_for_setters
        hits, err = scan_blueprint_for_setters(blueprint_path, name)
        return bool(hits) and not err
    except Exception:
        return False


def _is_function_in_asm(blueprint_dict: Dict[str, Any], name: str) -> bool:
    """True if `name` matches a subroutine `id` in the ASM blueprint dict."""
    if not isinstance(blueprint_dict, dict):
        return False
    name_norm = str(name).strip().upper()
    for sub in (blueprint_dict.get("subroutines") or []):
        if not isinstance(sub, dict):
            continue
        if str(sub.get("id", "")).strip().upper() == name_norm:
            return True
    return False


def _is_variable_in_cpp(blueprint_dict: Dict[str, Any], name: str) -> bool:
    """True if `name` has GVL seed nodes in a C++ blueprint dict."""
    if not isinstance(blueprint_dict, dict):
        return False
    gvl = blueprint_dict.get("global_variable_lineage") or {}
    if not gvl:
        return False
    try:
        from backward_traversal.utils.cpp_lineage_utils import (
            extract_asm_field_aliases,
            find_cpp_seed_nodes,
        )
    except ImportError:
        return False
    aliases = extract_asm_field_aliases(blueprint_dict, name) if name else {}
    seeds = find_cpp_seed_nodes(gvl, name, aliases, {})
    return bool(seeds)


def _is_function_in_cpp(blueprint_dict: Dict[str, Any], name: str) -> bool:
    """True if `name` is a key in the C++ blueprint's call_graph.nodes."""
    if not isinstance(blueprint_dict, dict):
        return False
    cg = blueprint_dict.get("call_graph") or {}
    nodes = cg.get("nodes") if isinstance(cg, dict) else None
    if isinstance(nodes, dict):
        # Direct key match (case-sensitive — C++ is case-sensitive)
        if name in nodes:
            return True
        # Also try with kind="function" attribute as a robustness check
        for nid, ndata in nodes.items():
            if nid == name:
                return True
            if isinstance(ndata, dict) and ndata.get("name") == name and ndata.get("kind") == "function":
                return True
    elif isinstance(nodes, list):
        # Some blueprints use a list-of-dicts format
        for n in nodes:
            if isinstance(n, dict) and (n.get("name") == name or n.get("id") == name):
                if n.get("kind", "function") == "function":
                    return True
    return False


def _load_blueprint_safe(path: Path) -> Optional[Dict[str, Any]]:
    """Load a blueprint dict using the project loader (handles gzip).

    Returns None on any failure (file missing, decode error, etc.).
    """
    if not path.is_file():
        return None
    try:
        from backward_traversal.utils.blueprint_utils import load_json as _load
        result = _load(path)
        return result if isinstance(result, dict) else None
    except Exception:
        return None


def detect_name_kind(
    name: str,
    file_stem: str,
    blueprint_dir: Path,
    *,
    asm_blueprint: Optional[Dict[str, Any]] = None,
    cpp_blueprint: Optional[Dict[str, Any]] = None,
) -> Kind:
    """Return the kind of `name` in the blueprint for `file_stem`.

    Loads only the blueprints needed; if `asm_blueprint` or `cpp_blueprint` is
    provided (preloaded dict), uses them directly without re-reading.

    Parameters
    ----------
    name : the symbol to classify
    file_stem : file stem (without extension)
    blueprint_dir : directory containing the per-file blueprints
    asm_blueprint : optional preloaded ASM/MAC blueprint dict (avoids re-read)
    cpp_blueprint : optional preloaded C++ blueprint dict (avoids re-read)

    Returns
    -------
    "variable" | "function" | "both" | "unknown"
    """
    if not name or not file_stem:
        return "unknown"

    asm_bp_path = blueprint_dir / f"{file_stem}.asm.json"
    mac_bp_path = blueprint_dir / f"{file_stem}.mac.json"
    cpp_bp_path = blueprint_dir / f"{file_stem}.cpp.json"

    is_var = False
    is_func = False

    # --- ASM/MAC path ---
    asm_present = asm_bp_path.is_file() or mac_bp_path.is_file()
    if asm_present:
        # Variable check uses the file (scan_blueprint_for_setters operates on path)
        for p in (asm_bp_path, mac_bp_path):
            if p.is_file() and _is_variable_in_asm(p, name):
                is_var = True
                break
        # Function check uses the loaded dict
        if not is_func:
            if asm_blueprint is None:
                bp = _load_blueprint_safe(asm_bp_path) or _load_blueprint_safe(mac_bp_path)
            else:
                bp = asm_blueprint
            if bp is not None and _is_function_in_asm(bp, name):
                is_func = True

    # --- C++ path ---
    cpp_present = cpp_bp_path.is_file()
    if cpp_present and not (is_var and is_func):
        bp = cpp_blueprint if cpp_blueprint is not None else _load_blueprint_safe(cpp_bp_path)
        if bp is not None:
            if not is_var and _is_variable_in_cpp(bp, name):
                is_var = True
            if not is_func and _is_function_in_cpp(bp, name):
                is_func = True

    if is_var and is_func:
        return "both"
    if is_var:
        return "variable"
    if is_func:
        return "function"
    return "unknown"


def sample_names_in_file(
    file_stem: str,
    blueprint_dir: Path,
    *,
    limit: int = 5,
) -> Tuple[List[str], List[str]]:
    """Return (sample_variables, sample_functions) from the file's blueprints.

    Used to populate the "unknown name" 422 message. Returns empty lists when
    blueprints don't exist or contain no entries.
    """
    variables: List[str] = []
    functions: List[str] = []

    cpp_bp = blueprint_dir / f"{file_stem}.cpp.json"
    asm_bp = blueprint_dir / f"{file_stem}.asm.json"
    mac_bp = blueprint_dir / f"{file_stem}.mac.json"

    if cpp_bp.is_file():
        bp = _load_blueprint_safe(cpp_bp)
        if bp:
            cg = bp.get("call_graph") or {}
            nodes = cg.get("nodes") if isinstance(cg, dict) else None
            if isinstance(nodes, dict):
                functions.extend(list(nodes.keys())[:limit])
            elif isinstance(nodes, list):
                functions.extend([
                    str(n.get("name") or n.get("id"))
                    for n in nodes[:limit]
                    if isinstance(n, dict)
                ])
            gvl = bp.get("global_variable_lineage") or {}
            gvl_nodes = gvl.get("nodes") if gvl else None
            if gvl_nodes is not None:
                _cap = limit * 3
                _seen = 0
                for n in gvl_nodes:
                    if _seen >= _cap:
                        break
                    _seen += 1
                    if isinstance(n, dict):
                        nm = n.get("name") or n.get("id")
                        if nm and nm not in variables:
                            variables.append(str(nm))
                        if len(variables) >= limit:
                            break

    for asm_path in (asm_bp, mac_bp):
        if not asm_path.is_file():
            continue
        bp = _load_blueprint_safe(asm_path)
        if bp:
            for sub in (bp.get("subroutines") or [])[: limit * 2]:
                if isinstance(sub, dict):
                    sid = sub.get("id")
                    if sid and sid not in functions:
                        functions.append(str(sid))
                if len(functions) >= limit:
                    break
        if functions:
            break

    return variables[:limit], functions[:limit]


def build_wrong_kind_message(
    name: str,
    file_stem: str,
    detected_kind: str,
    expected_kind: str,
    target_endpoint_url: str,
    target_body_sample: Dict[str, Any],
    inapplicable_params: List[str],
) -> str:
    """Construct the consistent 422 detail for a wrong-kind input.

    The format is shared across all 5 endpoints so callers see the same
    structure regardless of which API they hit.
    """
    import json as _json
    body_str = _json.dumps(target_body_sample, indent=2)
    inapplicable = ", ".join(repr(p) for p in inapplicable_params) if inapplicable_params else "(none)"
    return (
        f"'{name}' in file '{file_stem}' is a C++ {detected_kind}, not a {expected_kind}. "
        f"The param sets and outputs are different — this isn't a transparent redirect. "
        f"To trace this {detected_kind}, call: POST {target_endpoint_url} "
        f"With body shape: {body_str} "
        f"Note: these source-endpoint params don't apply on the target: {inapplicable}."
    )


def build_unknown_kind_message(
    name: str,
    file_stem: str,
    blueprint_dir: Path,
) -> str:
    """Construct the consistent 422 detail for a name not found as either kind."""
    sample_vars, sample_funcs = sample_names_in_file(file_stem, blueprint_dir, limit=5)
    return (
        f"'{name}' not found in file '{file_stem}' as either a variable or a function. "
        f"Sample variables in this file: {sample_vars or '(none)'}. "
        f"Sample functions in this file: {sample_funcs or '(none)'}. "
        f"Check spelling/casing or pick a different file."
    )
