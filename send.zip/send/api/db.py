"""SQLAlchemy database setup."""

from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from api.config import settings

engine = create_engine(
    settings.DATABASE_URL,
    connect_args={"check_same_thread": False},  # needed for SQLite
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


def get_db():
    """FastAPI dependency that yields a DB session and closes it after the request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def create_tables() -> None:
    """Create all tables that don't exist yet (called on startup)."""
    from api.models.user import User  # noqa: F401
    from api.models.knowledge_base import KnowledgeBase, KnowledgeBaseAccess, FileSummary  # noqa: F401
    from api.models.lineage_explanation import LineageExplanationCache, LineageStepCache  # noqa: F401
    from api.models.setter_analysis import (  # noqa: F401
        SetterAnalysisStructural, SetterAnalysisProse, SetterDescriptionCache,
        ChainSetterStructural, ChainSetterProse,
    )
    Base.metadata.create_all(bind=engine)
