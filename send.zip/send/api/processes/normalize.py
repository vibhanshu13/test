"""Process name normalization for forgiving caller matching.

Examples (all match the directory `plastic_authentication`):
    "plastic_authentication"
    "Plastic Authentication"
    "PLASTIC-AUTHENTICATION"
    "plastic authentication"
    "plasticauthentication"

Examples (all match the directory `C400`):
    "C400", "c400", "C-400", "c 400", "c_400"
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Optional, Tuple

# Separators that are stripped during canonicalization (whitespace, underscore, dash).
_SEPARATOR_RE = re.compile(r"[\s_\-]+")


def canonical_form(name: str) -> str:
    """Return the canonical comparison form: lowercase, separators stripped.

    Examples:
      'C400'                    -> 'c400'
      'C-400'                   -> 'c400'
      'c 400'                   -> 'c400'
      'Plastic_Authentication'  -> 'plasticauthentication'
      'PLASTIC AUTHENTICATION'  -> 'plasticauthentication'
      ''                        -> ''
    """
    if not isinstance(name, str):
        return ""
    return _SEPARATOR_RE.sub("", name.lower().strip())


def normalize_process_name(name: str) -> Tuple[str, ...]:
    """Tokenize the name into a sorted token tuple.

    Tokens are also returned for backward-compat / inspection — but `canonical_form`
    is what's used for matching.
    """
    if not isinstance(name, str):
        return ()
    tokens = [t for t in _SEPARATOR_RE.split(name.lower().strip()) if t]
    return tuple(sorted(tokens))


def names_match(a: str, b: str) -> bool:
    """True if two process names refer to the same logical process.

    Match rule: canonical forms are equal (case-insensitive, separator-insensitive).
    Empty inputs never match anything.
    """
    ca = canonical_form(a)
    cb = canonical_form(b)
    return bool(ca) and ca == cb


def resolve_process_dir(processes_dir: Path, query: str) -> Optional[str]:
    """Return canonical directory name under `processes_dir` matching `query`, or None.

    Matching is canonical-form based — see `canonical_form` for the rule.
    Returns the actual on-disk directory name when found; `None` otherwise.
    """
    if not isinstance(processes_dir, Path) or not processes_dir.is_dir():
        return None
    target = canonical_form(query)
    if not target:
        return None
    for entry in processes_dir.iterdir():
        if entry.is_dir() and canonical_form(entry.name) == target:
            return entry.name
    return None
