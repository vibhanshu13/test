"""DFS chain enumeration restricted to a single process's edge set.

A "chain" is a simple path (no repeated nodes) of length >= 2 through the
process's call graph, starting from a root (a node with no incoming edges
inside the process).
"""

from __future__ import annotations

from collections import defaultdict
from typing import Dict, List, Sequence, Set, Tuple


def enumerate_chains(
    edges: Sequence[Tuple[str, str]],
    files: Sequence[str] = (),
    seed_file: str = "",
    max_depth: int = 50,
    max_chains: int = 5000,
) -> Tuple[List[List[str]], bool]:
    """Return (chains, truncated).

    chains: list of simple paths (each path is a list of file paths >= 2 long)
    truncated: True iff enumeration was cut off by max_chains

    Parameters
    ----------
    edges : sequence of (from_file, to_file)
    files : full file list (used only to detect isolated files; not starting points)
    seed_file : optional process entry-point used as a fallback root
    max_depth : maximum number of edges in any chain
    max_chains : safety cap on total chains returned
    """
    out_edges: Dict[str, List[str]] = defaultdict(list)
    in_count: Dict[str, int] = defaultdict(int)
    edge_nodes: Set[str] = set()

    for src, dst in edges:
        edge_nodes.add(src); edge_nodes.add(dst)
        out_edges[src].append(dst)
        in_count[dst] += 1

    # Sort outs deterministically so DFS produces stable output
    for k in out_edges:
        out_edges[k] = sorted(out_edges[k])

    roots = compute_roots(edges, seed_file=seed_file)
    chains: List[List[str]] = []
    truncated = False

    def _dfs(node: str, path: List[str], visited: Set[str]) -> None:
        nonlocal truncated
        if len(chains) >= max_chains:
            truncated = True
            return
        # Record path as a chain when length >= 2 (i.e. >= 1 hop)
        if len(path) >= 2:
            chains.append(list(path))
            if len(chains) >= max_chains:
                truncated = True
                return
        if len(path) - 1 >= max_depth:
            return
        for nxt in out_edges.get(node, []):
            if nxt in visited:
                continue
            visited.add(nxt)
            path.append(nxt)
            _dfs(nxt, path, visited)
            path.pop()
            visited.remove(nxt)

    for root in roots:
        if len(chains) >= max_chains:
            truncated = True
            break
        _dfs(root, [root], {root})

    # Stable sort by (length, lex order of files)
    chains.sort(key=lambda c: (len(c), c))
    return chains, truncated


def build_hops(chain: Sequence[str], edge_index: Dict[Tuple[str, str], dict]) -> List[dict]:
    """For a chain of file paths, build per-edge hop metadata."""
    hops = []
    for i in range(len(chain) - 1):
        meta = edge_index.get((chain[i], chain[i + 1]), {})
        hop = {
            "from": chain[i],
            "to": chain[i + 1],
            "from_function": meta.get("from_function"),
            "to_function": meta.get("to_function"),
            "edge_type": meta.get("edge_type"),
            "ambiguous": bool(meta.get("ambiguous", False)),
        }
        # Carry the indirect-call envelope opaquely from the edge metadata so
        # downstream consumers (UI, API responses) can mark the hop as indirect.
        if meta.get("indirection"):
            hop["indirection"] = dict(meta["indirection"])
        hops.append(hop)
    return hops


def compute_roots(
    edges: Sequence[Tuple[str, str]],
    files: Sequence[str] = (),
    seed_file: str = "",
) -> List[str]:
    """Return chain starting points using a 3-tier fallback strategy.

    Priority:
      1) Nodes in the edge set with indegree 0 (traditional roots)
      2) If none, fall back to [seed_file] if it appears in the edge set
      3) Otherwise, every node in the edge set (every file is a candidate start)

    Isolated files (in `files` but not in any edge) are NEVER considered roots
    because they cannot start any chain.
    """
    in_count: Dict[str, int] = defaultdict(int)
    edge_nodes: Set[str] = set()
    for src, dst in edges:
        edge_nodes.add(src); edge_nodes.add(dst)
        in_count[dst] += 1

    real_roots = sorted(n for n in edge_nodes if in_count[n] == 0)
    if real_roots:
        return real_roots
    if seed_file and seed_file in edge_nodes:
        return [seed_file]
    return sorted(edge_nodes)
