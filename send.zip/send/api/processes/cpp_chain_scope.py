"""Filter the cpp-call-chain function index to a process's scope.

The global cpp_function_index has shape:
  {
    "generated_at": float,
    "blueprint_count": int,
    "definitions": {func_name: [{file_stem, file_path, definition_line, kind, is_external}, ...]},
    "callers":     {func_name: [{caller_func, file_stem, file_path, call_line, call_type, instruction}, ...]},
  }

Filtering rules:
- Both `definitions[func]` and `callers[func]` are filtered to keep only entries
  with `file_stem` in scope.
- A function key with zero remaining entries (in BOTH dicts) is dropped.
- Metadata fields (`generated_at`, `blueprint_count`) are preserved with a hint that
  the index was process-filtered.

Persistence:
- A filtered index can be cached at `output/process_lineage/{process_name}/cpp_function_index.msgpack.zst`
  using the same format as the global index (msgpack + zstd).
- Reuses `cpp_call_chain.index_builder._write_index` / `_read_index` so the on-disk
  format is identical and bit-for-bit compatible.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Set


def filter_function_index(
    index: Dict[str, Any],
    scope_stems: Iterable[str],
) -> Dict[str, Any]:
    """Return a new index dict containing only entries whose file_stem is in scope.

    `scope_stems` should include both stems and basenames where applicable
    (e.g., for `.hpp` files the global index may use either form).
    """
    scope_set: Set[str] = {str(s) for s in scope_stems}

    src_defs: Dict[str, list] = index.get("definitions", {}) or {}
    src_callers: Dict[str, list] = index.get("callers", {}) or {}

    out_defs: Dict[str, list] = {}
    out_callers: Dict[str, list] = {}

    for func, entries in src_defs.items():
        kept = [e for e in (entries or []) if str(e.get("file_stem", "")) in scope_set]
        if kept:
            out_defs[func] = kept

    for func, entries in src_callers.items():
        kept = [e for e in (entries or []) if str(e.get("file_stem", "")) in scope_set]
        if kept:
            out_callers[func] = kept

    return {
        # Preserve generation metadata for caching/staleness checks
        "generated_at": index.get("generated_at", time.time()),
        "blueprint_count": index.get("blueprint_count", 0),
        "process_filter": True,  # marker so callers can tell this is filtered
        "process_scope_size": len(scope_set),
        "definitions": out_defs,
        "callers": out_callers,
    }


def process_index_cache_path(output_dir: Path, process_name: str) -> Path:
    """Return the on-disk path for the per-process filtered index."""
    return (
        output_dir
        / "process_lineage"
        / process_name
        / "cpp_function_index.msgpack.zst"
    )


def is_cache_valid(
    cache_path: Path,
    global_index_path: Path,
    process_seed_path: Path,
) -> bool:
    """Check whether a filtered-index cache file is still valid.

    Rule: cache mtime must be >= both the global index's mtime AND the process
    seed `file_graph.json`'s mtime. Either being newer invalidates the cache.
    """
    if not cache_path.is_file():
        return False
    cache_mtime = cache_path.stat().st_mtime
    try:
        global_mtime = global_index_path.stat().st_mtime
    except (FileNotFoundError, OSError):
        return False
    if cache_mtime < global_mtime:
        return False
    try:
        seed_mtime = process_seed_path.stat().st_mtime
    except (FileNotFoundError, OSError):
        # If seed is missing the scope is invalid anyway; treat as invalid cache
        return False
    if cache_mtime < seed_mtime:
        return False
    return True


def write_filtered_index(index: Dict[str, Any], cache_path: Path) -> None:
    """Persist a filtered index using the same msgpack+zstd format as the global one."""
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    # Reuse the existing project writer for byte-for-byte format compatibility.
    from cpp_call_chain.index_builder import _write_index  # noqa: WPS437 (intentional reuse)
    _write_index(index, cache_path)


def read_filtered_index(cache_path: Path) -> Dict[str, Any]:
    """Load a previously-cached filtered index."""
    from cpp_call_chain.index_builder import _read_index  # noqa: WPS437
    return _read_index(cache_path)


def load_or_build_filtered_index(
    *,
    global_index: Dict[str, Any],
    scope_stems: Iterable[str],
    output_dir: Path,
    process_name: str,
    global_index_path: Path,
    process_seed_path: Path,
    force_rebuild: bool = False,
) -> Dict[str, Any]:
    """High-level helper: return a filtered index, using the on-disk cache when valid.

    Order:
      1. If `force_rebuild` is False AND the cache is valid → read cache and return.
      2. Otherwise, filter the global index and write the result to cache atomically.
    """
    cache_path = process_index_cache_path(output_dir, process_name)
    if not force_rebuild and is_cache_valid(cache_path, global_index_path, process_seed_path):
        try:
            return read_filtered_index(cache_path)
        except Exception:
            # Corrupted cache — fall through and rebuild
            pass

    filtered = filter_function_index(global_index, scope_stems)
    try:
        write_filtered_index(filtered, cache_path)
    except Exception:
        # Cache write failure shouldn't block the request; we still return the in-memory result
        pass
    return filtered
