"""Process-scoped helpers: name normalization, scope resolution, chain enumeration."""
