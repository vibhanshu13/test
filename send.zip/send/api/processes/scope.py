"""Compute a process's analysis scope (files, edges, graph-id mapping)."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Set, Tuple


@dataclass(frozen=True)
class ProcessScope:
    """In-memory representation of a process's analysis scope."""
    process_name: str
    files: Tuple[str, ...]               # full paths from file_graph.files[]
    headers_resolved: Tuple[str, ...]    # resolved_path values from headers.json
    mac_files: Tuple[str, ...]           # .mac files referenced from macros.json
    edges: Tuple[Tuple[str, str], ...]   # (from_file, to_file) from file_graph.edges[]
    edge_meta: Tuple[dict, ...]          # original edge dicts (kept for hop metadata in chains)
    seed_file: str = ""
    seed_function: str = ""

    @property
    def all_files(self) -> List[str]:
        """Union of files + headers + macros, deduplicated, sorted."""
        return sorted(set(self.files) | set(self.headers_resolved) | set(self.mac_files))

    @property
    def graph_ids(self) -> Set[str]:
        """Possible graph node IDs (stem AND basename) for every scope file.

        Global file_call_graph.json uses bare stems for asm/cpp/mac and
        sometimes basenames for hpp; we accept both for robustness.
        """
        ids: Set[str] = set()
        for path in self.all_files:
            p = Path(path)
            ids.add(p.stem)
            ids.add(p.name)
        return ids

    @property
    def edge_pairs_stems(self) -> Set[Tuple[str, str]]:
        """Edges as (source_stem, target_stem) — used to gate global graph edges."""
        pairs: Set[Tuple[str, str]] = set()
        for src, dst in self.edges:
            sp = Path(src); dp = Path(dst)
            pairs.add((sp.stem, dp.stem))
            pairs.add((sp.name, dp.name))
            # Also pair where one side is stem and other is name (defensive)
            pairs.add((sp.stem, dp.name))
            pairs.add((sp.name, dp.stem))
        return pairs

    @property
    def edge_index(self) -> dict:
        """Map (from_file, to_file) → original edge dict (preserves hop metadata)."""
        idx = {}
        for meta in self.edge_meta:
            key = (meta.get("from_file", ""), meta.get("to_file", ""))
            idx[key] = meta
        return idx

    def file_in_scope(self, candidate: str) -> bool:
        """True if `candidate` (file path / stem / basename) is in scope."""
        if candidate in self.all_files:
            return True
        if candidate in self.graph_ids:
            return True
        # Also try by basename
        p = Path(candidate)
        return p.stem in self.graph_ids or p.name in self.graph_ids


def load_process_scope(process_dir: Path, process_name: str) -> ProcessScope:
    """Read the 3 seed JSONs and build a ProcessScope."""
    fg_path = process_dir / "file_graph.json"
    hdr_path = process_dir / "headers.json"
    mac_path = process_dir / "macros.json"

    for p in (fg_path, hdr_path, mac_path):
        if not p.is_file():
            raise FileNotFoundError(f"Process seed file missing: {p}")

    fg = json.loads(fg_path.read_text(encoding="utf-8"))
    hdr = json.loads(hdr_path.read_text(encoding="utf-8"))
    mac = json.loads(mac_path.read_text(encoding="utf-8"))

    headers_resolved = [
        e["resolved_path"]
        for e in hdr.get("headers_found", [])
        if e.get("resolved_path")
    ]
    mac_files: Set[str] = set()
    # macros.json::asm_files is a bookkeeping list — not really mac files
    # but include any .mac files referenced under results[*].mac_files[]
    for entry in mac.get("results", {}).values():
        if not isinstance(entry, dict):
            continue
        for m in entry.get("mac_files") or []:
            mac_files.add(m)

    edge_meta = [e for e in fg.get("edges", []) if "from_file" in e and "to_file" in e]
    edge_pairs = [(e["from_file"], e["to_file"]) for e in edge_meta]

    return ProcessScope(
        process_name=process_name,
        files=tuple(fg.get("files", [])),
        headers_resolved=tuple(headers_resolved),
        mac_files=tuple(sorted(mac_files)),
        edges=tuple(edge_pairs),
        edge_meta=tuple(edge_meta),
        seed_file=fg.get("seed_file", ""),
        seed_function=fg.get("seed_function", ""),
    )


def build_filtered_call_graph(global_graph: dict, scope: ProcessScope) -> dict:
    """Return a process-filtered copy of a global file_call_graph payload."""
    allowed_ids = scope.graph_ids
    nodes_in = [n for n in global_graph.get("nodes", []) if str(n.get("id", "")) in allowed_ids]
    allowed_node_ids = {str(n["id"]) for n in nodes_in}

    edges_in = []
    for e in global_graph.get("edges", []):
        src = str(e.get("source", ""))
        dst = str(e.get("target", ""))
        if src in allowed_node_ids and dst in allowed_node_ids:
            edges_in.append(e)

    return {
        "metadata": {
            **(global_graph.get("metadata") or {}),
            "process_filter": scope.process_name,
            "process_file_count": len(scope.files),
            "process_scope_files": scope.all_files,
        },
        "nodes": nodes_in,
        "edges": edges_in,
        "warnings": global_graph.get("warnings", []),
        "summary": {
            **(global_graph.get("summary") or {}),
            "filtered_to_process": scope.process_name,
        },
    }


def materialize_filtered_graph(
    output_dir: Path,
    process_name: str,
    scope: ProcessScope,
    global_graph_file: Path,
) -> Path:
    """Write process-scoped graph to output/process_lineage/{name}/file_call_graph.json.

    Idempotent: regenerates only if missing or older than the global file.
    """
    out_dir = output_dir / "process_lineage" / process_name
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "file_call_graph.json"

    if out_path.exists():
        try:
            if out_path.stat().st_mtime >= global_graph_file.stat().st_mtime:
                return out_path
        except FileNotFoundError:
            pass  # global file disappeared; fall through to error below

    if not global_graph_file.is_file():
        raise FileNotFoundError(f"Global call graph missing: {global_graph_file}")

    global_payload = json.loads(global_graph_file.read_text(encoding="utf-8"))
    filtered = build_filtered_call_graph(global_payload, scope)
    out_path.write_text(json.dumps(filtered, indent=2), encoding="utf-8")
    return out_path


def process_lineage_dir(output_dir: Path, process_name: str) -> Path:
    """Return the per-process lineage directory under a job's output."""
    return output_dir / "process_lineage" / process_name


def session_dir_for(output_dir: Path, process_name: str, session_id: str) -> Path:
    """Return the per-session storage dir under a process's lineage output."""
    return process_lineage_dir(output_dir, process_name) / "chunked" / session_id


def session_file_for(output_dir: Path, process_name: str, session_id: str) -> Path:
    """Return the session.msgpack file path."""
    return session_dir_for(output_dir, process_name, session_id) / "session.msgpack"


# ---------------------------------------------------------------------------
# Response filtering — enforce "scope doesn't go outside"
# ---------------------------------------------------------------------------

def _is_node_in_scope(node_id: str, scope: "ProcessScope") -> bool:
    """True if node_id (a file stem/basename) is in the process scope."""
    if not node_id:
        return False
    return node_id in scope.graph_ids


def filter_full_flow_to_scope(full_flow: dict, scope: "ProcessScope") -> dict:
    """Drop nodes and edges in `full_flow` that reference files outside the process scope.

    Used by the API 2 file-graph endpoint to enforce strict process containment.
    """
    nodes = [n for n in full_flow.get("nodes", []) if _is_node_in_scope(str(n.get("id", "")), scope)]
    keep_ids = {str(n["id"]) for n in nodes}
    edges = []
    for e in full_flow.get("edges", []):
        s = str(e.get("source", ""))
        t = str(e.get("target", ""))
        if s in keep_ids and t in keep_ids:
            edges.append(e)
    return {**full_flow, "nodes": nodes, "edges": edges}


def filter_tuple_to_scope(tuple_dict: dict, scope: "ProcessScope") -> dict:
    """Drop entries from a chunked lineage tuple that reference files outside scope.

    Specifically:
      - cross_file_calls_out: keep only calls whose target is in scope
      - full_flow_edges: keep only edges with both endpoints in scope
      - intra_tuple_edges: kept verbatim (block-level, file-internal)
      - nodes: kept verbatim (block-level; node IDs may contain function names
        that are not files)
    """
    if not isinstance(tuple_dict, dict):
        return tuple_dict

    out = dict(tuple_dict)

    # cross_file_calls_out
    cfcs = []
    for call in tuple_dict.get("cross_file_calls_out") or []:
        target = (call.get("target_file") or call.get("target_module")
                  or call.get("target") or "")
        # Match target by stem or basename
        if not target:
            continue
        if _is_node_in_scope(target, scope) or _is_node_in_scope(Path(target).stem, scope) \
                or _is_node_in_scope(Path(target).name, scope):
            cfcs.append(call)
    out["cross_file_calls_out"] = cfcs

    # full_flow_edges
    ffe = []
    for e in tuple_dict.get("full_flow_edges") or []:
        s = e.get("source"); t = e.get("target")
        if not s or not t:
            continue
        if _is_node_in_scope(s, scope) and _is_node_in_scope(t, scope):
            ffe.append(e)
    out["full_flow_edges"] = ffe

    return out
