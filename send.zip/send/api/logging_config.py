"""Shared logging configuration for API and Celery worker processes."""

from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
_configured = False


def configure_logging() -> None:
    """Wire root logger: RotatingFileHandler on /var/asm-logs/asm.log + StreamHandler.

    Idempotent — safe to call from both API lifespan and Celery worker_init signal.
    """
    global _configured
    if _configured:
        return
    _configured = True

    formatter = logging.Formatter(fmt=LOG_FORMAT, datefmt=LOG_DATE_FORMAT)
    root = logging.getLogger()

    # Replace any handlers added by basicConfig so we don't get duplicate output.
    for h in root.handlers[:]:
        root.removeHandler(h)

    # Console handler
    sh = logging.StreamHandler()
    sh.setFormatter(formatter)
    root.addHandler(sh)

    # Shared rotating file handler — written to a Docker named volume so both
    # the api container and the worker container see the same log stream.
    log_dir = Path("/var/asm-logs")
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        fh = logging.handlers.RotatingFileHandler(
            log_dir / "asm.log",
            maxBytes=50 * 1024 * 1024,  # 50 MB per file
            backupCount=5,
            encoding="utf-8",
        )
        fh.setFormatter(formatter)
        root.addHandler(fh)
    except OSError:
        # Volume not mounted (local dev without Docker); console-only is fine.
        pass

    root.setLevel(logging.INFO)
