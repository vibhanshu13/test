"""Application configuration using pydantic-settings."""

from __future__ import annotations

import math
import os
import subprocess
from pathlib import Path
from typing import List, Optional, Set

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


# ---------------------------------------------------------------------------
# System-probe helpers — module-level so they can be tested independently.
# All functions are defensive: they never raise; they return a safe fallback.
# ---------------------------------------------------------------------------

def _detect_total_ram_gb() -> float:
    """Return total system RAM in GB.

    Tries three methods in order:
    1. psutil.virtual_memory().total  — cross-platform, most accurate
    2. /proc/meminfo                  — Linux, no extra dependency
    3. sysctl hw.memsize              — macOS, no extra dependency
    Falls back to 8.0 GB if all three fail.
    """
    try:
        import psutil
        return psutil.virtual_memory().total / (1024 ** 3)
    except Exception:
        pass

    try:
        with open("/proc/meminfo") as fh:
            for line in fh:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1]) / (1024 ** 2)  # kB → GB
    except Exception:
        pass

    try:
        out = subprocess.check_output(["sysctl", "-n", "hw.memsize"], timeout=3)
        return int(out.strip()) / (1024 ** 3)
    except Exception:
        pass

    return 8.0  # conservative fallback


def _detect_cgroup_memory_limit_gb() -> float:
    """Return the container/cgroup memory limit in GB.

    Checks cgroup v2 first (``memory.max``), then cgroup v1
    (``memory/memory.limit_in_bytes``).  Returns ``float('inf')`` when no
    explicit limit is set (bare-metal or unlimited Docker run).
    """
    # cgroup v2 — /sys/fs/cgroup/memory.max
    try:
        val = Path("/sys/fs/cgroup/memory.max").read_text(encoding="ascii").strip()
        if val != "max":
            return int(val) / (1024 ** 3)
    except Exception:
        pass
    # cgroup v1 — /sys/fs/cgroup/memory/memory.limit_in_bytes
    try:
        val = int(
            Path("/sys/fs/cgroup/memory/memory.limit_in_bytes")
            .read_text(encoding="ascii")
            .strip()
        )
        # The kernel uses 2^63 - 4096 as a sentinel for "no limit".
        if val < (1 << 62):
            return val / (1024 ** 3)
    except Exception:
        pass
    return float("inf")  # no cgroup memory limit detected


def _detect_cgroup_cpu_count() -> float:
    """Return the effective CPU count allowed by cgroup CPU quota.

    Checks cgroup v2 (``cpu.max``) then cgroup v1
    (``cpu/cpu.cfs_quota_us`` + ``cpu/cpu.cfs_period_us``).
    Falls back to ``os.cpu_count()`` when no quota is set.
    """
    host_cpus = float(os.cpu_count() or 2)
    # cgroup v2 — /sys/fs/cgroup/cpu.max  (format: "quota period" or "max period")
    try:
        parts = Path("/sys/fs/cgroup/cpu.max").read_text(encoding="ascii").strip().split()
        if len(parts) == 2 and parts[0] != "max":
            quota, period = int(parts[0]), int(parts[1])
            if period > 0:
                return min(host_cpus, quota / period)
    except Exception:
        pass
    # cgroup v1 — /sys/fs/cgroup/cpu/cpu.cfs_quota_us (−1 means no limit)
    try:
        quota = int(
            Path("/sys/fs/cgroup/cpu/cpu.cfs_quota_us")
            .read_text(encoding="ascii")
            .strip()
        )
        period = int(
            Path("/sys/fs/cgroup/cpu/cpu.cfs_period_us")
            .read_text(encoding="ascii")
            .strip()
        )
        if quota > 0 and period > 0:
            return min(host_cpus, quota / period)
    except Exception:
        pass
    return host_cpus


def _detect_available_ram_gb() -> float:
    """Return currently available (free + reclaimable) RAM in GB.

    ``available`` accounts for kernel page-cache that can be released
    on demand — it is a better predictor of usable memory than
    ``free`` alone.  Falls back to 60 % of total RAM if undetectable.
    """
    try:
        import psutil
        return psutil.virtual_memory().available / (1024 ** 3)
    except Exception:
        pass
    # /proc/meminfo MemAvailable (Linux ≥ 3.14)
    try:
        with open("/proc/meminfo") as fh:
            for line in fh:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) / (1024 ** 2)  # kB → GB
    except Exception:
        pass
    return _detect_total_ram_gb() * 0.6  # conservative fallback


def _detect_cpu_load_factor() -> float:
    """Return the fraction of CPU capacity that is currently idle (0–1).

    A value of 1.0 means the system is fully idle; 0.0 means all cores
    are saturated.  Used to scale down worker counts when the host is
    already under heavy load from other processes.

    ``os.getloadavg()`` is not available on Windows; returns 1.0 there.
    """
    try:
        load_1min = os.getloadavg()[0]
        cpu_count = os.cpu_count() or 2
        busy_fraction = min(1.0, load_1min / cpu_count)
        return max(0.1, 1.0 - busy_fraction)
    except (AttributeError, OSError):
        return 1.0  # assume idle if getloadavg not available


def _detect_disk_free_gb(path: str = "/") -> float:
    """Return free disk space in GB for the filesystem containing *path*."""
    try:
        import psutil
        return psutil.disk_usage(path).free / (1024 ** 3)
    except Exception:
        pass
    try:
        import shutil
        return shutil.disk_usage(path).free / (1024 ** 3)
    except Exception:
        return float("inf")


def _auto_celery_concurrency(
    total_ram_gb: float,
    service_reserve_gb: float = 3.0,
    effective_cpu: float = 0.0,
) -> int:
    """Auto-size the number of Celery worker processes.

    Each Celery worker for a large-codebase pipeline run holds the full
    analysis context in memory — estimate ~6 GB worst-case.  We divide
    the 75 % RAM budget by that figure, then cap at half the effective
    CPU count so worker processes don't starve the OS scheduler.

        max_by_ram = floor((total_ram × 0.75 − service_reserve) / 6)
        max_by_cpu = max(1, effective_cpu // 2)
        CELERY_CONCURRENCY = max(1, min(max_by_ram, max_by_cpu))

    ``effective_cpu`` is the cgroup-constrained CPU count; defaults to
    ``os.cpu_count()`` when 0.
    """
    available_gb = max(0.0, total_ram_gb * 0.75 - service_reserve_gb)
    max_by_ram = max(1, math.floor(available_gb / 6.0))
    cpu = effective_cpu if effective_cpu > 0 else float(os.cpu_count() or 2)
    max_by_cpu = max(1, int(cpu) // 2)
    return max(1, min(max_by_ram, max_by_cpu))


def _auto_worker_max_memory_mb(
    total_ram_gb: float,
    celery_concurrency: int,
    service_reserve_gb: float = 3.0,
) -> int:
    """Compute the per-Celery-worker memory cap in MB.

    Divides the 75 % RAM budget equally among Celery workers.  Celery's
    ``worker_max_memory_per_child`` setting recycles a worker once it
    exceeds this threshold, preventing unbounded memory growth.

        per_worker_gb = (total_ram × 0.75 − service_reserve) / concurrency
        WORKER_MAX_MEMORY_MB = int(per_worker_gb × 1024)
    """
    available_gb = max(0.0, total_ram_gb * 0.75 - service_reserve_gb)
    per_worker_gb = available_gb / max(1, celery_concurrency)
    return max(512, int(per_worker_gb * 1024))  # floor at 512 MB


def _auto_analysis_workers(
    total_ram_gb: float,
    memory_budget_fraction: float,
    service_reserve_gb: float,
    batch_size: int,
    celery_concurrency: int = 1,
    effective_cpu: float = 0.0,
    cpu_load_factor: float = 1.0,
) -> int:
    """Compute ANALYSIS_WORKERS from the RAM budget and live system state.

    Divides the budget by *celery_concurrency* so that N Celery workers
    each spawning M analysis sub-processes collectively fit inside RAM.
    The result is further scaled by *cpu_load_factor* (0–1) to back off
    when the host is already under load from other processes:

        memory_budget     = total_ram × memory_budget_fraction
        worker_budget     = memory_budget − service_reserve_gb
        per_celery_budget = worker_budget / celery_concurrency
        memory_per_worker = (batch_size × 25 MB) + 100 MB overhead  (→ GB)
        max_by_memory     = floor(per_celery_budget / memory_per_worker)
        max_by_cpu        = floor((effective_cpu − 2) / celery_concurrency
                                  × cpu_load_factor)
        ANALYSIS_WORKERS  = max(1, min(max_by_memory, max_by_cpu))

    ``effective_cpu`` is the cgroup-constrained CPU count; defaults to
    ``os.cpu_count()`` when 0.  ``cpu_load_factor`` = 1.0 means fully idle.
    """
    memory_budget_gb = total_ram_gb * memory_budget_fraction
    worker_budget_gb = max(0.0, memory_budget_gb - service_reserve_gb)
    per_celery_budget_gb = worker_budget_gb / max(1, celery_concurrency)
    memory_per_worker_gb = (batch_size * 25 + 100) / 1024  # MB → GB
    if memory_per_worker_gb <= 0:
        return 1
    max_by_memory = math.floor(per_celery_budget_gb / memory_per_worker_gb)
    cpu = effective_cpu if effective_cpu > 0 else float(os.cpu_count() or 2)
    raw_cpu_workers = max(1.0, (cpu - 2.0) / max(1, celery_concurrency))
    max_by_cpu = max(1, math.floor(raw_cpu_workers * max(0.1, cpu_load_factor)))
    return max(1, min(max_by_memory, max_by_cpu))


def _auto_postproc_workers(effective_cpu: float = 0.0) -> int:
    """Compute the ThreadPoolExecutor size for post-processing steps 3–5.

    Steps 3 (call graph), 4 (modifier index), and 5 (identity index) run
    as exactly three independent I/O-bound tasks.  We always want at least
    2 threads and cap at 3 (one per task) since more threads add no value.
    On machines with very few CPUs, use 1 to avoid over-subscription.

        POSTPROC_WORKERS = max(1, min(3, floor(effective_cpu / 2)))
    """
    cpu = effective_cpu if effective_cpu > 0 else float(os.cpu_count() or 2)
    return max(1, min(3, int(cpu) // 2))


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    REDIS_URL: str = "redis://localhost:6379"

    # Computed defaults — overridable via env
    CELERY_BROKER_URL: str = ""
    CELERY_RESULT_BACKEND: str = ""

    REDIS_METADATA_DB: int = 0

    JOBS_BASE_DIR: Path = Path(__file__).parents[1] / "jobs"
    DATASOURCE_DIR: Path = Path(__file__).parents[1] / "datasource"
    PROCESS_SEEDS_DIR: Path = Path(__file__).parents[1] / "data" / "processes"
    DATABASE_URL: str = f"sqlite:///{Path(__file__).parents[1]}/users.db"

    # -- Pipeline Index Database --
    # Stores large pipeline outputs (GVL, universes, hop/identity/modifier indexes)
    # as queryable tables instead of loading multi-GB JSON files into RAM.
    #
    # Backend options:
    #   sqlite      (default) — one index.db per job at jobs/{job_id}/index.db
    #   postgresql  — shared database; requires INDEX_DB_URL
    #   mysql       — shared database; requires INDEX_DB_URL
    #
    # For non-sqlite backends set INDEX_DB_URL in .env, e.g.:
    #   INDEX_DB_URL=postgresql://user:pass@localhost/asm_index
    #
    # INDEX_DB_BATCH_SIZE controls how many rows are accumulated before each
    # DB commit during streaming ingestion.  Lower values reduce peak RAM at
    # the cost of more round-trips.  Default 500 ≈ < 1 MB per commit.
    INDEX_DB_BACKEND: str = "sqlite"
    INDEX_DB_URL: str = ""
    INDEX_DB_BATCH_SIZE: int = 500
    # When True, every route that has an index.db fast path will return an
    # empty response instead of falling back to the slow filesystem / JSON
    # path when the DB has no data.  Leave False (default) until
    # scripts/backfill_index_db.py has been run and verified on all
    # workspaces.  Flip to True in production once parity is confirmed.
    INDEX_DB_STRICT: bool = False

    # -- LLM (Gemini) --
    # Single model used for ALL LLM calls across the app.
    GEMINI_API_KEY: str = ""
    LLM_MODEL_NAME: str = "gemini-2.5-pro"
    LLM_MAX_TOKENS: int = 8192
    LLM_TEMPERATURE: float = 0.01
    # Maximum seconds to wait for a single LLM API call; 0 = no timeout.
    LLM_CALL_TIMEOUT: int = 120
    # How many times to retry a transient LLM error (timeout / rate-limit / 5xx)
    # before giving up.  Backoff doubles each attempt: 1 s, 2 s, 4 s, …
    LLM_MAX_RETRIES: int = 3
    # Process-wide cap on concurrent in-flight Gemini calls. Prevents request
    # paths (e.g. path-card generation) from fanning out to dozens of parallel
    # calls that saturate threads/connections and hang the server. Min 1.
    LLM_MAX_CONCURRENCY: int = 6

    # -- JWT (sensitive — set in .env) --
    JWT_SECRET_KEY: str = "change-me-in-production"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 1440  # 24 hours

    # Comma-separated list of API keys; empty means dev mode (no auth)
    API_KEYS_RAW: str = ""

    # Comma-separated allowed CORS origins; defaults to allow all (dev mode)
    CORS_ORIGINS_RAW: str = "*"

    @property
    def CORS_ORIGINS(self) -> List[str]:
        if self.CORS_ORIGINS_RAW.strip() == "*":
            return ["*"]
        return [o.strip() for o in self.CORS_ORIGINS_RAW.split(",") if o.strip()]

    JOB_TTL_SECONDS: int = 86400
    # 72 h hard limit — large codebases (10 M+ LOC, 22 K files) with
    # extend_modifier_sites=true can take many hours.
    # Override with TASK_TIME_LIMIT=<seconds> in .env for smaller deployments.
    TASK_TIME_LIMIT: int = 259200       # 72 h hard limit
    TASK_SOFT_TIME_LIMIT: int = 255600  # 71 h soft limit (graceful shutdown window)
    MAX_UPLOAD_SIZE_MB: int = 500
    CHAIN_SUMMARY_WORKERS: int = 4

    # -- Memory / resource guard --
    # Fraction of total RAM allowed for the analysis pipeline (default 60 %).
    MEMORY_BUDGET_FRACTION: float = 0.60
    # GB reserved for OS, Redis, nginx, and API workers before sizing analysis workers.
    SERVICE_RESERVE_GB: float = 3.0
    # Number of files per ProcessPoolExecutor batch (each batch ≈ 25 MB × batch_size).
    ANALYSIS_BATCH_SIZE: int = 20

    # Number of Celery worker processes.
    # 0 (default) = auto-sized: max(1, floor((RAM×0.75 − 3 GB) / 6 GB))
    # Each Celery worker can run one pipeline job at a time, so on a 16 GB
    # machine the formula yields 1; on a 32 GB machine it yields 3.
    CELERY_CONCURRENCY: int = 0

    # Memory cap per Celery worker (MB).  When a worker exceeds this limit
    # Celery recycles it, preventing unbounded RAM growth across long runs.
    # 0 (default) = auto-sized: (RAM×0.75 − 3 GB) / CELERY_CONCURRENCY.
    WORKER_MAX_MEMORY_MB: int = 0

    # Recycle each Celery worker after this many tasks to release accumulated
    # heap memory that Python's allocator doesn't return to the OS.
    WORKER_MAX_TASKS_PER_CHILD: int = 5

    # Per-file analysis timeout (seconds) inside batch workers.
    # A single pathological file will be skipped rather than hanging the batch.
    FILE_TIMEOUT_SECONDS: int = 300  # 5 minutes per file

    # Number of parallel analysis worker processes (ProcessPoolExecutor).
    # 0 (default) = auto-sized: divides RAM budget by CELERY_CONCURRENCY so
    # multiple Celery workers don't collectively over-book RAM.
    ANALYSIS_WORKERS: int = 0

    # Number of threads for post-processing steps 3–5 (call graph, modifier
    # index, identity index).  These three tasks are always independent and
    # I/O-bound; the pool runs exactly three tasks so values > 3 have no effect.
    # 0 (default) = auto-sized: max(1, min(3, effective_cpu // 2)).
    POSTPROC_WORKERS: int = 0

    @model_validator(mode="after")
    def _set_computed_defaults(self) -> "Settings":
        if not self.CELERY_BROKER_URL:
            self.CELERY_BROKER_URL = f"{self.REDIS_URL}/0"
        if not self.CELERY_RESULT_BACKEND:
            self.CELERY_RESULT_BACKEND = f"{self.REDIS_URL}/0"

        import warnings

        # ------------------------------------------------------------------
        # Phase 1: Probe the machine / container.
        # All helpers are defensive (never raise, return safe fallbacks).
        # ------------------------------------------------------------------
        host_ram_gb: float = _detect_total_ram_gb()
        cgroup_mem_gb: float = _detect_cgroup_memory_limit_gb()
        available_ram_gb: float = _detect_available_ram_gb()
        effective_cpu: float = _detect_cgroup_cpu_count()
        cpu_load_factor: float = _detect_cpu_load_factor()

        # Effective RAM = host RAM capped by any cgroup / Docker mem_limit.
        # This ensures workers size themselves to the container budget, not
        # the full physical host memory they cannot actually use.
        effective_ram_gb: float = (
            min(host_ram_gb, cgroup_mem_gb)
            if cgroup_mem_gb < 1e12
            else host_ram_gb
        )

        # If available RAM is significantly below effective RAM (other processes
        # are consuming memory), use the tighter bound so we don't over-allocate.
        # Add SERVICE_RESERVE_GB back so the formulas can subtract it cleanly.
        conservative_ram_gb: float = min(
            effective_ram_gb,
            max(effective_ram_gb * 0.5,
                available_ram_gb + self.SERVICE_RESERVE_GB),
        )

        # ------------------------------------------------------------------
        # Phase 2: Auto-size worker counts using probed values.
        # Each setting is only auto-sized when still at its default (0).
        # ------------------------------------------------------------------
        if not self.CELERY_CONCURRENCY:
            self.CELERY_CONCURRENCY = _auto_celery_concurrency(
                total_ram_gb=conservative_ram_gb,
                service_reserve_gb=self.SERVICE_RESERVE_GB,
                effective_cpu=effective_cpu,
            )

        if not self.WORKER_MAX_MEMORY_MB:
            self.WORKER_MAX_MEMORY_MB = _auto_worker_max_memory_mb(
                total_ram_gb=conservative_ram_gb,
                celery_concurrency=self.CELERY_CONCURRENCY,
                service_reserve_gb=self.SERVICE_RESERVE_GB,
            )

        if not self.ANALYSIS_WORKERS:
            self.ANALYSIS_WORKERS = _auto_analysis_workers(
                total_ram_gb=conservative_ram_gb,
                memory_budget_fraction=self.MEMORY_BUDGET_FRACTION,
                service_reserve_gb=self.SERVICE_RESERVE_GB,
                batch_size=self.ANALYSIS_BATCH_SIZE,
                celery_concurrency=self.CELERY_CONCURRENCY,
                effective_cpu=effective_cpu,
                cpu_load_factor=cpu_load_factor,
            )

        if not self.POSTPROC_WORKERS:
            self.POSTPROC_WORKERS = _auto_postproc_workers(effective_cpu)

        # ------------------------------------------------------------------
        # Phase 3: Safety clamps and sanity warnings.
        # ------------------------------------------------------------------

        # Clamp: if currently free RAM is very low, reduce analysis workers
        # to avoid OOM on the first batch.  This is a last-resort guard.
        _usable_free_gb = available_ram_gb - self.SERVICE_RESERVE_GB
        if _usable_free_gb < 2.0 and self.ANALYSIS_WORKERS > 1:
            _safe_workers = max(1, int(_usable_free_gb / 0.5))
            warnings.warn(
                f"[config] Available RAM is critically low "
                f"({available_ram_gb:.1f} GB free, {self.SERVICE_RESERVE_GB} GB reserved). "
                f"Reducing ANALYSIS_WORKERS {self.ANALYSIS_WORKERS} → {_safe_workers} "
                f"to prevent OOM.  Free more RAM or set ANALYSIS_WORKERS explicitly.",
                RuntimeWarning,
                stacklevel=2,
            )
            self.ANALYSIS_WORKERS = _safe_workers

        # Warn if overall committed memory exceeds 90 % of what is actually
        # available in this container/host.
        committed_gb = (
            self.CELERY_CONCURRENCY
            * (1 + self.ANALYSIS_WORKERS)
            * (self.ANALYSIS_BATCH_SIZE * 25 + 100)
            / 1024
        )
        ram_ceiling = min(effective_ram_gb, available_ram_gb)
        if committed_gb > ram_ceiling * 0.80:
            warnings.warn(
                f"[config] Memory over-commit risk: estimated peak usage "
                f"{committed_gb:.1f} GB exceeds 80 % of usable RAM "
                f"({ram_ceiling:.1f} GB, effective={effective_ram_gb:.1f} GB, "
                f"available={available_ram_gb:.1f} GB).  "
                f"Consider reducing CELERY_CONCURRENCY ({self.CELERY_CONCURRENCY}) "
                f"or ANALYSIS_WORKERS ({self.ANALYSIS_WORKERS}) in .env.",
                RuntimeWarning,
                stacklevel=2,
            )

        # Warn if disk space looks tight (blueprints for 10 K files ≈ 5–20 GB).
        try:
            _disk_free = _detect_disk_free_gb(str(self.JOBS_BASE_DIR))
            if _disk_free < 10.0:
                warnings.warn(
                    f"[config] Low disk space: {_disk_free:.1f} GB free on "
                    f"{self.JOBS_BASE_DIR}.  Large codebases may require 10–50 GB "
                    f"for blueprints and indexes.",
                    RuntimeWarning,
                    stacklevel=2,
                )
        except Exception:
            pass

        return self

    @property
    def API_KEYS(self) -> Set[str]:
        """Return the set of valid API keys parsed from the comma-separated env var."""
        if not self.API_KEYS_RAW:
            return set()
        return {k.strip() for k in self.API_KEYS_RAW.split(",") if k.strip()}


settings = Settings()


# ---------------------------------------------------------------------------
# Pre-run system profile — call print_system_profile() at the start of each
# pipeline run so the job log captures the full resource picture.
# ---------------------------------------------------------------------------

def get_system_profile() -> dict:
    """Return a snapshot of the host/container resource state and computed settings.

    Probes are repeated at call time so that the returned values reflect the
    actual situation at pipeline start (not at import time), which matters
    when the Celery worker has been running for a while.
    """
    host_ram_gb = _detect_total_ram_gb()
    cgroup_mem_gb = _detect_cgroup_memory_limit_gb()
    available_ram_gb = _detect_available_ram_gb()
    host_cpu = int(os.cpu_count() or 2)
    effective_cpu = _detect_cgroup_cpu_count()
    cpu_load_factor = _detect_cpu_load_factor()

    try:
        load_avg: Optional[float] = round(os.getloadavg()[0], 2)
    except (AttributeError, OSError):
        load_avg = None

    try:
        disk_free_gb: float = round(
            _detect_disk_free_gb(str(settings.JOBS_BASE_DIR)), 1
        )
    except Exception:
        disk_free_gb = float("inf")

    effective_ram_gb = (
        min(host_ram_gb, cgroup_mem_gb) if cgroup_mem_gb < 1e12 else host_ram_gb
    )

    return {
        # --- hardware / container ---
        "host_ram_gb": round(host_ram_gb, 1),
        "cgroup_mem_limit_gb": (
            round(cgroup_mem_gb, 1) if cgroup_mem_gb < 1e12 else "unlimited"
        ),
        "effective_ram_gb": round(effective_ram_gb, 1),
        "available_ram_gb": round(available_ram_gb, 1),
        "host_cpu_count": host_cpu,
        "effective_cpu_count": round(effective_cpu, 1),
        "cpu_load_avg_1min": load_avg,
        "cpu_idle_factor": round(cpu_load_factor, 2),
        "disk_free_gb": disk_free_gb,
        # --- computed worker settings ---
        "celery_concurrency": settings.CELERY_CONCURRENCY,
        "worker_max_memory_mb": settings.WORKER_MAX_MEMORY_MB,
        "worker_max_tasks_per_child": settings.WORKER_MAX_TASKS_PER_CHILD,
        "analysis_workers": settings.ANALYSIS_WORKERS,
        "analysis_batch_size": settings.ANALYSIS_BATCH_SIZE,
        "postproc_workers": settings.POSTPROC_WORKERS,
        "file_timeout_seconds": settings.FILE_TIMEOUT_SECONDS,
        "memory_budget_fraction": settings.MEMORY_BUDGET_FRACTION,
        "service_reserve_gb": settings.SERVICE_RESERVE_GB,
        "task_time_limit_h": round(settings.TASK_TIME_LIMIT / 3600, 1),
    }


def print_system_profile() -> None:
    """Print a structured pre-run resource banner to stdout.

    Call this once at the start of every pipeline run so operators can
    verify the computed worker counts match the host hardware.  The output
    lands in the job log file captured by ``redirect_output_to_log``.
    """
    p = get_system_profile()
    _SEP = "=" * 72

    lines = [
        "",
        _SEP,
        "  SYSTEM PROFILE  —  pre-run resource analysis",
        _SEP,
        f"  RAM",
        f"    host total   : {p['host_ram_gb']} GB",
        (
            f"    cgroup limit : {p['cgroup_mem_limit_gb']} GB  (container budget)"
            if p['cgroup_mem_limit_gb'] != 'unlimited'
            else f"    cgroup limit : unlimited  (bare-metal or unrestricted container)"
        ),
        f"    effective    : {p['effective_ram_gb']} GB  "
        f"(= min(host, cgroup))",
        f"    available now: {p['available_ram_gb']} GB  "
        f"(free + reclaimable; reflects current load)",
        "",
        f"  CPU",
        f"    host cores   : {p['host_cpu_count']}",
        f"    effective    : {p['effective_cpu_count']}  "
        f"(cgroup-constrained)",
        f"    load avg 1m  : {p['cpu_load_avg_1min']}",
        f"    idle factor  : {p['cpu_idle_factor']}  "
        f"(1.0 = fully idle, used to scale workers)",
        "",
        f"  DISK",
        (
            f"    free         : {p['disk_free_gb']} GB  ({settings.JOBS_BASE_DIR})"
            if p['disk_free_gb'] != float('inf')
            else f"    free         : (unable to probe)  ({settings.JOBS_BASE_DIR})"
        ),
        "",
        f"  COMPUTED WORKER PLAN",
        f"    celery workers       : {p['celery_concurrency']}  "
        f"(pipeline tasks in parallel)",
        f"    analysis workers     : {p['analysis_workers']}  "
        f"(ProcessPoolExecutor per celery worker)",
        f"    analysis batch size  : {p['analysis_batch_size']}  files/batch",
        f"    postproc workers     : {p['postproc_workers']}  "
        f"(call-graph + modifier + identity indexes)",
        f"    worker mem cap       : {p['worker_max_memory_mb']} MB/celery-worker",
        f"    recycle after        : {p['worker_max_tasks_per_child']} tasks",
        f"    file timeout         : {p['file_timeout_seconds']} s",
        f"    task hard limit      : {p['task_time_limit_h']} h",
        f"    memory budget        : {int(p['memory_budget_fraction']*100)}% of effective RAM"
        f"  −  {p['service_reserve_gb']} GB service reserve",
    ]

    # Inline warnings so they appear inside the banner and are hard to miss.
    warnings_found = False
    if p["available_ram_gb"] < 4.0:
        lines.append(
            f"\n  *** WARNING: available RAM is low ({p['available_ram_gb']} GB). "
            f"High OOM risk. ***"
        )
        warnings_found = True
    if isinstance(p["disk_free_gb"], float) and p["disk_free_gb"] < 10.0:
        lines.append(
            f"\n  *** WARNING: low disk space ({p['disk_free_gb']} GB free). "
            f"Blueprints for 10 K+ files may require 10–50 GB. ***"
        )
        warnings_found = True
    if isinstance(p["cpu_idle_factor"], float) and p["cpu_idle_factor"] < 0.3:
        lines.append(
            f"\n  *** WARNING: system is under heavy CPU load "
            f"(idle factor={p['cpu_idle_factor']}, load avg={p['cpu_load_avg_1min']}). "
            f"Analysis workers reduced accordingly. ***"
        )
        warnings_found = True
    if p["cgroup_mem_limit_gb"] != "unlimited":
        # Estimated peak usage
        est_peak = (
            p["celery_concurrency"]
            * (1 + p["analysis_workers"])
            * (p["analysis_batch_size"] * 25 + 100)
            / 1024
        )
        cgroup_limit = float(p["cgroup_mem_limit_gb"])
        if est_peak > cgroup_limit * 0.80:
            lines.append(
                f"\n  *** WARNING: estimated peak RAM {est_peak:.1f} GB exceeds 80% of "
                f"container limit {cgroup_limit:.1f} GB ({est_peak/cgroup_limit*100:.0f}%). "
                f"Consider increasing WORKER_MEM_LIMIT or reducing workers. ***"
            )
            warnings_found = True

    if not warnings_found:
        lines.append("\n  All resource checks passed.")

    lines.append(_SEP)
    lines.append("")
    print("\n".join(lines), flush=True)
