"""Celery task: business-user lineage explanation driven by chunked backward sessions.

Drives the explain_step / generate_synthesis pipeline over a ChunkedBackwardSession
and writes one StepExplanation JSON per step under:
  jobs/{kb_id}/output/lineage_explanation/{var}_explain_step_{idx}.json

For co-traversal: runs primary → counterpart → bridge sequentially.
No ProcessScope — chain-based KB sessions only.
"""
from __future__ import annotations

import json
import logging
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.config import settings
from api.storage.workspace import WorkspaceManager, get_metadata_client
from api.tasks._task_utils import redirect_output_to_log, job_log_handler
from api.tasks.celery_app import celery_app

logger = logging.getLogger(__name__)


@contextmanager
def _session_lock(session_id: str, timeout: int = 60) -> Generator[None, None, None]:
    client = get_metadata_client()
    lock_key = f"lineage_explain_lock:{session_id}"
    lock = client.lock(lock_key, timeout=timeout)
    acquired = lock.acquire(blocking=True, blocking_timeout=30)
    if not acquired:
        raise RuntimeError(f"Could not acquire explain session lock for {session_id}")
    try:
        yield
    finally:
        try:
            lock.release()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Single-variable explanation task
# ---------------------------------------------------------------------------

@celery_app.task(bind=True, name="asm.kb_lineage_explanation")
def run_kb_lineage_explanation(
    self, job_id: str, options: Dict[str, Any]
) -> Dict[str, Any]:
    """Drive a business-user step explanation for one backward-lineage session.

    options keys:
      kb_id, backward_session_id, root_variable, selected_chain,
      start_step_index, total_steps (optional hint)
    """
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run_single(ws, options)
            except SoftTimeLimitExceeded:
                msg = "Task exceeded soft time limit and was aborted."
                logger.error("Job %s: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s failed: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}


def _run_single(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    from backward_traversal.runner.chunked_session import (
        ChunkedBackwardSession,
        get_session_dir,
    )
    from llm.lineage_explainer import (
        create_explain_session,
        explain_step,
        generate_synthesis,
        get_graph_delta,
        load_explain_session,
    )
    from llm.lineage_reasoning import build_step_reasoning, render_step_mermaid

    job_id = ws.job_id
    t_start = time.monotonic()

    kb_id = str(options["kb_id"])
    backward_session_id = str(options["backward_session_id"])
    root_variable = str(options["root_variable"])
    selected_chain = list(options["selected_chain"])
    start_step_index = int(options.get("start_step_index", 0))

    logger.info(
        "[explain] job=%s kb=%s var=%s session=%s step=%d",
        job_id, kb_id, root_variable, backward_session_id, start_step_index,
    )

    # Phase 1 — Load the backward session and assemble the tuple
    session_dir = get_session_dir(kb_id, backward_session_id)
    back_session = ChunkedBackwardSession.load(kb_id, backward_session_id)
    if back_session is None:
        raise FileNotFoundError(
            f"Backward session {backward_session_id} not found for kb {kb_id}. "
            "Run the backward-lineage/chunks job first."
        )

    total_steps = len(back_session.tuple_index_map)
    if start_step_index >= total_steps and total_steps > 0:
        raise ValueError(
            f"step_index {start_step_index} >= total_steps {total_steps}"
        )

    tuple_data = back_session.assemble_tuple(start_step_index, session_dir)
    if tuple_data is None:
        # Tuple not yet computed — drive the session forward
        if not back_session.is_complete:
            back_session.process_until_tuple(start_step_index, session_dir)
            back_session.save(kb_id, backward_session_id)
            back_session = ChunkedBackwardSession.load(kb_id, backward_session_id)
        tuple_data = back_session.assemble_tuple(start_step_index, session_dir)

    if tuple_data is None:
        raise RuntimeError(f"Could not assemble tuple {start_step_index} for session {backward_session_id}")

    # Phase 2 — Load/create explain session
    with _session_lock(backward_session_id):
        exp_session = load_explain_session(kb_id, backward_session_id)
        if exp_session is None:
            exp_session = create_explain_session(
                kb_id=kb_id,
                backward_session_id=backward_session_id,
                root_variable=root_variable,
                selected_chain=selected_chain,
            )

    # Phase 3 — Generate the step explanation
    explanation = explain_step(
        kb_id=kb_id,
        backward_session_id=backward_session_id,
        session=exp_session,
        tuple_data=tuple_data,
        step_index=start_step_index,
        total_steps=total_steps,
        selected_chain=selected_chain,
    )

    # Build reasoning + mermaid for this step
    prior_facts = [exp_session.get("step_facts", {}).get(str(i), "") for i in range(start_step_index)]
    reasoning = build_step_reasoning(
        tuple_data=tuple_data,
        root_variable=root_variable,
        prior_facts=[f for f in prior_facts if f],
        step_index=start_step_index,
    )

    all_reasonings = [
        exp_session.get("step_reasonings", {}).get(str(i), {})
        for i in range(start_step_index + 1)
    ]
    mermaid = render_step_mermaid(all_reasonings, start_step_index, selected_chain)
    graph_delta = get_graph_delta(exp_session, start_step_index, all_reasonings, selected_chain)

    # Phase 4 — Synthesis (only on final step)
    next_step_index = start_step_index + 1
    is_last = next_step_index >= total_steps and back_session.is_complete
    synthesis = None
    if is_last:
        synthesis = generate_synthesis(kb_id, backward_session_id, exp_session)

    has_more = next_step_index < total_steps or not back_session.is_complete

    # Phase 5 — Write output page
    output_dir = ws.output_dir / "lineage_explanation"
    output_dir.mkdir(parents=True, exist_ok=True)

    import re
    safe_var = re.sub(r"[^A-Za-z0-9_]", "_", root_variable)
    output_file = output_dir / f"{safe_var}_explain_step_{start_step_index}.json"

    page = {
        "job_id":                job_id,
        "kb_id":                 kb_id,
        "backward_session_id":   backward_session_id,
        "root_variable":         root_variable,
        "selected_chain":        selected_chain,
        "step_index":            start_step_index,
        "next_step_index":       next_step_index,
        "total_steps":           total_steps,
        "has_more":              has_more,
        "is_session_complete":   back_session.is_complete,
        "file_stem":             tuple_data.get("file_stem", ""),
        "file_type":             tuple_data.get("file_type", "asm"),
        "variable_in_step":      tuple_data.get("variable", root_variable),
        "phase":                 tuple_data.get("phase", ""),
        "phase_badge":           reasoning.get("phase_badge", ""),
        "reasoning":             reasoning,
        "explanation":           explanation.model_dump(),
        "graph_delta":           graph_delta,
        "mermaid":               mermaid,
        "synthesis":             synthesis.model_dump() if synthesis else None,
        "warnings":              list(back_session.warnings or []),
    }

    output_file.write_text(json.dumps(page, indent=2), encoding="utf-8")

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)

    logger.info(
        "[explain] done — step=%d has_more=%s synthesis=%s elapsed=%.1fs",
        start_step_index, has_more, synthesis is not None, time.monotonic() - t_start,
    )

    return {
        "job_id":              job_id,
        "status":              "success",
        "backward_session_id": backward_session_id,
        "step_index":          start_step_index,
        "next_step_index":     next_step_index,
        "has_more":            has_more,
        "is_session_complete": back_session.is_complete,
        "output_file":         str(output_file.relative_to(ws.output_dir)),
    }


# ---------------------------------------------------------------------------
# Co-traversal explanation task
# ---------------------------------------------------------------------------

@celery_app.task(bind=True, name="asm.kb_lineage_explanation_cotrack")
def run_kb_lineage_explanation_cotrack(
    self, job_id: str, options: Dict[str, Any]
) -> Dict[str, Any]:
    """Drive sequential primary → counterpart → bridge explanation over a co-track session pair."""
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run_cotrack(ws, options)
            except SoftTimeLimitExceeded:
                msg = "Task exceeded soft time limit and was aborted."
                logger.error("Job %s cotrack explain: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s cotrack explain failed: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}


def _run_cotrack(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    from backward_traversal.runner.chunked_session import (
        ChunkedBackwardSession,
        get_session_dir,
    )
    from llm.lineage_explainer import (
        create_explain_session,
        explain_step,
        generate_bridge,
        generate_synthesis,
        get_graph_delta,
        load_explain_session,
    )
    from llm.lineage_reasoning import build_step_reasoning, render_step_mermaid

    job_id = ws.job_id
    t_start = time.monotonic()
    kb_id = str(options["kb_id"])

    primary_session_id = str(options["primary_session_id"])
    counterpart_session_id = str(options["counterpart_session_id"])
    primary_variable = str(options["primary_variable"])
    counterpart_variable = str(options["counterpart_variable"])
    primary_chain = list(options["primary_chain"])
    counterpart_chain = list(options["counterpart_chain"])
    section = str(options.get("section", "primary"))  # 'primary' | 'counterpart' | 'bridge'
    step_index = int(options.get("step_index", 0))

    link = dict(options.get("link") or {})

    def _explain_session_for(
        backward_session_id: str, variable: str, chain: List[str]
    ) -> Dict[str, Any]:
        back_session = ChunkedBackwardSession.load(kb_id, backward_session_id)
        if back_session is None:
            raise FileNotFoundError(f"Backward session {backward_session_id} not found")
        session_dir = get_session_dir(kb_id, backward_session_id)
        total = len(back_session.tuple_index_map)

        if step_index >= total and total > 0:
            raise ValueError(f"step_index {step_index} >= total {total}")

        tuple_data = back_session.assemble_tuple(step_index, session_dir)
        if tuple_data is None:
            if not back_session.is_complete:
                back_session.process_until_tuple(step_index, session_dir)
                back_session.save(kb_id, backward_session_id)
                back_session = ChunkedBackwardSession.load(kb_id, backward_session_id)
            tuple_data = back_session.assemble_tuple(step_index, session_dir)
        if tuple_data is None:
            raise RuntimeError(f"Could not assemble tuple {step_index}")

        with _session_lock(backward_session_id):
            exp_session = load_explain_session(kb_id, backward_session_id)
            if exp_session is None:
                exp_session = create_explain_session(kb_id, backward_session_id, variable, chain)

        return back_session, exp_session, tuple_data, session_dir, total

    output_dir = ws.output_dir / "lineage_explanation" / "cotrack"
    output_dir.mkdir(parents=True, exist_ok=True)

    result: Dict[str, Any] = {"job_id": job_id, "status": "success", "section": section}

    if section == "bridge":
        # Load both explain sessions for synthesis
        p_session = load_explain_session(kb_id, primary_session_id)
        c_session = load_explain_session(kb_id, counterpart_session_id)
        bridge = generate_bridge(
            primary_var=primary_variable,
            counterpart_var=counterpart_variable,
            primary_language=link.get("primary_language", "asm"),
            counterpart_language=link.get("counterpart_language", "cpp"),
            cc_header=link.get("cc_header"),
            certainty=link.get("certainty"),
            certainty_label=link.get("certainty_label"),
            mapping_via=link.get("mapping_via"),
            struct_name=link.get("struct_name"),
            primary_session=p_session,
            counterpart_session=c_session,
        )
        out_file = output_dir / "bridge.json"
        out_file.write_text(json.dumps(bridge.model_dump(), indent=2), encoding="utf-8")
        result["bridge"] = bridge.model_dump()
        result["output_file"] = str(out_file.relative_to(ws.output_dir))
    else:
        # primary or counterpart
        if section == "counterpart":
            bsid, variable, chain = counterpart_session_id, counterpart_variable, counterpart_chain
        else:
            bsid, variable, chain = primary_session_id, primary_variable, primary_chain

        back_session, exp_session, tuple_data, session_dir, total = _explain_session_for(bsid, variable, chain)

        explanation = explain_step(
            kb_id=kb_id,
            backward_session_id=bsid,
            session=exp_session,
            tuple_data=tuple_data,
            step_index=step_index,
            total_steps=total,
            selected_chain=chain,
        )

        prior_facts = [exp_session.get("step_facts", {}).get(str(i), "") for i in range(step_index)]
        reasoning = build_step_reasoning(tuple_data, variable, [f for f in prior_facts if f], step_index)
        all_reasonings = [exp_session.get("step_reasonings", {}).get(str(i), {}) for i in range(step_index + 1)]
        mermaid = render_step_mermaid(all_reasonings, step_index, chain)
        graph_delta = get_graph_delta(exp_session, step_index, all_reasonings, chain)

        next_step = step_index + 1
        is_last = next_step >= total and back_session.is_complete
        synthesis = None
        if is_last:
            synthesis = generate_synthesis(kb_id, bsid, exp_session)

        has_more = next_step < total or not back_session.is_complete
        import re
        safe_var = re.sub(r"[^A-Za-z0-9_]", "_", variable)
        out_file = output_dir / f"{section}_{safe_var}_step_{step_index}.json"

        page = {
            "job_id":              job_id,
            "kb_id":               kb_id,
            "section":             section,
            "backward_session_id": bsid,
            "root_variable":       variable,
            "selected_chain":      chain,
            "step_index":          step_index,
            "next_step_index":     next_step,
            "total_steps":         total,
            "has_more":            has_more,
            "explanation":         explanation.model_dump(),
            "reasoning":           reasoning,
            "graph_delta":         graph_delta,
            "mermaid":             mermaid,
            "synthesis":           synthesis.model_dump() if synthesis else None,
        }
        out_file.write_text(json.dumps(page, indent=2), encoding="utf-8")
        result.update({
            "backward_session_id": bsid,
            "step_index":          step_index,
            "next_step_index":     next_step,
            "has_more":            has_more,
            "output_file":         str(out_file.relative_to(ws.output_dir)),
        })

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)
    logger.info("[explain-cotrack] done — section=%s elapsed=%.1fs", section, time.monotonic() - t_start)
    return result


# ---------------------------------------------------------------------------
# Full-batch explanation task (all steps, both modes, rolling synthesis)
# ---------------------------------------------------------------------------

@celery_app.task(bind=True, name="asm.kb_lineage_batch")
def run_kb_lineage_batch(
    self, job_id: str, options: Dict[str, Any]
) -> Dict[str, Any]:
    """Drive full batch explanation: every step, both modes, rolling synthesis, DB persistence.

    options keys:
      kb_id, backward_session_id, root_variable, selected_chain,
      chain_hash, modes (list), roll_size (int)
    """
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run_batch(ws, options)
            except SoftTimeLimitExceeded:
                msg = "Task exceeded soft time limit and was aborted."
                logger.error("Job %s batch explain: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s batch explain failed: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}


def _run_batch(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    from backward_traversal.runner.chunked_session import (
        ChunkedBackwardSession,
        get_session_dir,
    )
    from llm.lineage_explainer import (
        build_variable_table,
        create_explain_session,
        explain_step,
        generate_synthesis_rolling,
        load_explain_session,
    )
    from api.db import SessionLocal
    from api.models.lineage_explanation import LineageExplanationCache, LineageStepCache
    from api.tasks._output_compression import pack_blob
    from sqlalchemy.dialects.sqlite import insert as sqlite_insert

    job_id = ws.job_id
    t_start = time.monotonic()

    kb_id = str(options["kb_id"])
    backward_session_id = str(options["backward_session_id"])
    root_variable = str(options["root_variable"])
    selected_chain = list(options["selected_chain"])
    ch = str(options["chain_hash"])
    modes: List[str] = list(options.get("modes") or ["technical", "business"])
    roll_size: int = int(options.get("roll_size") or 12)

    logger.info(
        "[batch] job=%s kb=%s var=%s session=%s modes=%s",
        job_id, kb_id, root_variable, backward_session_id, modes,
    )

    # --- Phase 1: drive backward traversal to completion ---
    session_dir = get_session_dir(kb_id, backward_session_id)
    back_session = ChunkedBackwardSession.load(kb_id, backward_session_id)
    if back_session is None:
        raise FileNotFoundError(
            f"Backward session {backward_session_id} not found for kb {kb_id}. "
            "Create it via POST /explain-lineage/batch (the route creates the session before dispatching)."
        )

    step_num = 0
    while not back_session.is_complete:
        back_session.process_until_tuple(step_num, session_dir)
        back_session.save(kb_id, backward_session_id)
        step_num = len(back_session.tuple_index_map)

    total_steps = len(back_session.tuple_index_map)
    logger.info("[batch] traversal complete: %d steps", total_steps)

    # --- Phase 2: load/create explain session ---
    with _session_lock(backward_session_id):
        exp_session = load_explain_session(kb_id, backward_session_id)
        if exp_session is None:
            exp_session = create_explain_session(
                kb_id=kb_id,
                backward_session_id=backward_session_id,
                root_variable=root_variable,
                selected_chain=selected_chain,
            )

    # Get KB updated_at for staleness tracking
    with SessionLocal() as db_sess:
        from api.models.knowledge_base import KnowledgeBase
        kb_row = db_sess.get(KnowledgeBase, kb_id)
        kb_updated_at = kb_row.updated_at if kb_row else None

    # --- Phase 3: explain every step for each mode ---
    for mode in modes:
        business_mode = (mode == "business")
        logger.info("[batch] explaining %d steps, mode=%s", total_steps, mode)

        with SessionLocal() as db_sess:
            for step_idx in range(total_steps):
                tuple_data = back_session.assemble_tuple(step_idx, session_dir)
                if tuple_data is None:
                    logger.warning("[batch] step %d: tuple_data is None, skipping", step_idx)
                    continue

                explanation = explain_step(
                    kb_id=kb_id,
                    backward_session_id=backward_session_id,
                    session=exp_session,
                    tuple_data=tuple_data,
                    step_index=step_idx,
                    total_steps=total_steps,
                    selected_chain=selected_chain,
                    business_mode=business_mode,
                )

                # Upsert into lineage_step_cache
                exp_blob = pack_blob(explanation.model_dump())
                stmt = (
                    sqlite_insert(LineageStepCache)
                    .values(
                        kb_id=kb_id,
                        backward_session_id=backward_session_id,
                        root_variable=root_variable,
                        chain_hash=ch,
                        step_index=step_idx,
                        mode=mode,
                        explanation_gz=exp_blob,
                    )
                    .on_conflict_do_update(
                        index_elements=["backward_session_id", "step_index", "mode"],
                        set_={"explanation_gz": exp_blob},
                    )
                )
                db_sess.execute(stmt)
                db_sess.commit()

                ws.set_status(
                    "running",
                    progress=f"{mode} step {step_idx + 1}/{total_steps}",
                )

        # --- Phase 4: rolling synthesis ---
        logger.info("[batch] synthesising mode=%s", mode)

        def _progress_cb(key: str, msg: str) -> None:
            ws.set_status("running", progress=f"{mode} {msg}")

        synthesis = generate_synthesis_rolling(
            kb_id=kb_id,
            backward_session_id=backward_session_id,
            session=exp_session,
            business_mode=business_mode,
            roll_size=roll_size,
            progress_cb=_progress_cb,
        )

        # --- Phase 5: variable table ---
        variable_table = build_variable_table(exp_session)

        # --- Phase 6: persist to lineage_explanation_cache ---
        payload_blob = pack_blob({
            "synthesis": synthesis.model_dump(),
            "variable_table": variable_table,
        })
        from datetime import datetime, timezone
        now_utc = datetime.now(timezone.utc)

        with SessionLocal() as db_sess:
            stmt = (
                sqlite_insert(LineageExplanationCache)
                .values(
                    kb_id=kb_id,
                    root_variable=root_variable,
                    chain_hash=ch,
                    mode=mode,
                    backward_session_id=backward_session_id,
                    status="success",
                    total_steps=total_steps,
                    job_id=job_id,
                    payload_gz=payload_blob,
                    error=None,
                    kb_updated_at=kb_updated_at or now_utc,
                    updated_at=now_utc,
                )
                .on_conflict_do_update(
                    index_elements=["kb_id", "chain_hash", "root_variable", "mode"],
                    set_={
                        "status": "success",
                        "payload_gz": payload_blob,
                        "total_steps": total_steps,
                        "job_id": job_id,
                        "error": None,
                        "kb_updated_at": kb_updated_at or now_utc,
                        "updated_at": now_utc,
                    },
                )
            )
            db_sess.execute(stmt)
            db_sess.commit()

        logger.info("[batch] mode=%s done", mode)

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)
    elapsed = time.monotonic() - t_start
    logger.info("[batch] complete — %d steps, %d modes, %.1fs", total_steps, len(modes), elapsed)

    return {
        "job_id":              job_id,
        "status":              "success",
        "backward_session_id": backward_session_id,
        "total_steps":         total_steps,
        "modes":               modes,
        "elapsed_s":           round(elapsed, 1),
    }
