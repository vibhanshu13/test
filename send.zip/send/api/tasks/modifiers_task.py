"""Celery task: find variable modifiers (find_variable_modifiers.py equivalent)."""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.tasks.celery_app import celery_app
from api.tasks._task_utils import redirect_output_to_log
from api.storage.workspace import WorkspaceManager

logger = logging.getLogger(__name__)


@celery_app.task(
    bind=True,
    name="asm.find_modifiers",
)
def run_find_modifiers(self, job_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    """
    Find every blueprint that modifies a variable via SETTER instructions,
    then retrieve the call chains through each modifying file.
    """
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        try:
            return _run_modifiers(ws, options)
        except SoftTimeLimitExceeded:
            error_msg = "Task exceeded soft time limit and was aborted."
            logger.error("Job %s: %s", job_id, error_msg)
            ws.set_status("failed", error=error_msg)
            return {"job_id": job_id, "status": "failed", "error": error_msg}
        except Exception as exc:
            error_msg = f"{type(exc).__name__}: {exc}"
            logger.exception("Job %s failed: %s", job_id, error_msg)
            ws.set_status("failed", error=error_msg)
            return {"job_id": job_id, "status": "failed", "error": error_msg}


def _run_modifiers(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    """Core find-modifiers logic."""
    from find_variable_modifiers import (
        scan_blueprint_for_setters,
        find_chains_through,
        _discover_graph_file,
        _discover_blueprint_dir,
    )

    variable: str = options["variable_name"]
    max_depth: Optional[int] = options.get("max_depth")
    no_chains: bool = bool(options.get("no_chains", False))

    input_dir = ws.input_dir
    output_dir = ws.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Resolve blueprint directory
    # ------------------------------------------------------------------
    blueprint_dir: Optional[Path] = None
    if options.get("blueprint_dir") and options["blueprint_dir"] != ".":
        candidate = Path(options["blueprint_dir"])
        if candidate.exists():
            blueprint_dir = candidate

    if blueprint_dir is None:
        asm_json_files = list(input_dir.rglob("*.asm.json"))
        if asm_json_files:
            blueprint_dir = asm_json_files[0].parent
        else:
            blueprint_dir = input_dir

    # ------------------------------------------------------------------
    # Load call graph (unless no_chains)
    # ------------------------------------------------------------------
    graph_payload: Optional[Dict[str, Any]] = None
    warnings: List[str] = []

    if not no_chains:
        graph_file: Optional[Path] = None
        if options.get("graph_file"):
            graph_file = Path(options["graph_file"])
        else:
            graph_file = _discover_graph_file(blueprint_dir)
            if graph_file is None:
                for p in input_dir.rglob("file_call_graph.json"):
                    graph_file = p
                    break

        if graph_file and graph_file.exists():
            try:
                graph_payload = json.loads(graph_file.read_text(encoding="utf-8"))
                print(f"[graph] {graph_file}", file=sys.stderr)
            except Exception as exc:
                msg = f"Could not load call graph: {exc}"
                warnings.append(msg)
                print(f"WARNING: {msg}", file=sys.stderr)
        else:
            msg = (
                "No file_call_graph.json found. "
                "Upload it with the blueprints or set graph_file in options."
            )
            warnings.append(msg)
            print(f"WARNING: {msg}", file=sys.stderr)

    print(f"[blueprints] {blueprint_dir}", file=sys.stderr)

    # ------------------------------------------------------------------
    # Scan blueprints for setter hits
    # ------------------------------------------------------------------
    blueprint_files = sorted(
        list(blueprint_dir.glob("*.asm.json"))
        + list(blueprint_dir.glob("*.mac.json"))
    )
    if not blueprint_files:
        raise FileNotFoundError(
            f"No .asm.json / .mac.json files found in {blueprint_dir}."
        )

    n_asm = sum(1 for f in blueprint_files if f.name.endswith(".asm.json"))
    n_mac = sum(1 for f in blueprint_files if f.name.endswith(".mac.json"))
    print(
        f"Scanning {len(blueprint_files)} blueprints ({n_asm} asm, {n_mac} mac) "
        f"for '{variable}'...",
        file=sys.stderr,
    )

    setter_hits: Dict[str, List[Dict[str, Any]]] = {}
    for bp_path in blueprint_files:
        hits, err = scan_blueprint_for_setters(bp_path, variable)
        if err:
            warnings.append(err)
            print(f"  WARNING: {err}", file=sys.stderr)
            continue
        if hits:
            stem = hits[0]["file_stem"]
            setter_hits[stem] = hits

    modifying_files = sorted(setter_hits.keys())
    graph_node_ids = (
        {n["id"] for n in graph_payload.get("nodes", [])} if graph_payload else set()
    )

    results: Dict[str, Any] = {}
    for stem in modifying_files:
        entry: Dict[str, Any] = {"setter_locations": setter_hits[stem]}

        if no_chains:
            entry["call_chains"] = None
        elif graph_payload is None:
            entry["call_chains"] = []
        elif stem not in graph_node_ids:
            msg = f"File '{stem}' not found in call graph; chain data unavailable."
            warnings.append(msg)
            entry["call_chains"] = []
            entry["call_chains_warning"] = msg
        else:
            max_depth_arg = int(max_depth) if max_depth is not None else None
            entry["call_chains"] = find_chains_through(
                graph_payload, stem, max_depth_arg
            )

        results[stem] = entry

    # ------------------------------------------------------------------
    # Write output
    # ------------------------------------------------------------------
    output: Dict[str, Any] = {
        "variable": variable,
        "scanned_files": len(blueprint_files),
        "modifying_files": modifying_files,
        "results": results,
        "warnings": warnings,
    }
    variable_modifiers_dir = output_dir / "variable_modifiers"
    variable_modifiers_dir.mkdir(parents=True, exist_ok=True)
    output_path = variable_modifiers_dir / f"{variable}_modifiers.json"
    output_path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(f"Wrote results to: {output_path}", file=sys.stderr)

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)

    return {
        "job_id": ws.job_id,
        "status": "success",
        "variable": variable,
        "modifying_files": len(modifying_files),
        "output_files": len(result_files),
    }
