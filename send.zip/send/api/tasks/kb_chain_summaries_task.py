"""Celery task: precompute reusable chain summaries for a KB call graph."""

from __future__ import annotations

import json
import logging
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.config import settings
from api.storage.workspace import WorkspaceManager
from api.tasks._task_utils import redirect_output_to_log, job_log_handler
from api.tasks.celery_app import celery_app

logger = logging.getLogger(__name__)


@celery_app.task(bind=True, name="asm.kb_chain_summaries")
def run_kb_chain_summaries(self, job_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    """Precompute call-chain summaries for jobs/{kb_id}/output/file_call_graph.json."""
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run(ws, options)
            except SoftTimeLimitExceeded:
                msg = "Task exceeded soft time limit and was aborted."
                logger.error("Job %s: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s failed: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}


def _stem_for_blueprint(path: Path) -> Optional[str]:
    suffixes = (".asm.json", ".mac.json", ".cpp.json", ".hpp.json")
    for suffix in suffixes:
        if path.name.endswith(suffix):
            return path.name[: -len(suffix)]
    return None


def _resolve_blueprint_dirs(kb_output: Path) -> List[Path]:
    from api.tasks._task_utils import find_blueprint_dir
    d = find_blueprint_dir(kb_output)
    return [d] if d is not None else []


def _collect_file_summaries(kb_output: Path, kb_id: Optional[str] = None) -> Dict[str, str]:
    """Return {stem: business_summary} for every blueprint in *kb_output*.

    When *kb_id* is provided, stems whose blueprints have no usable
    ``business_summary`` are filled in via
    :func:`api.tasks.file_summary_fallback.ensure_many_business_summaries` (an
    LLM call per missing file, parallelised). Stems that still cannot be
    generated (no source file, LLM error) are simply omitted from the result —
    same graceful-skip semantics as before.
    """
    from blueprint_io import load_blueprint

    summaries: Dict[str, str] = {}
    missing_stems: List[str] = []
    for base_dir in _resolve_blueprint_dirs(kb_output):
        for bp in sorted(base_dir.glob("*.json")):
            stem = _stem_for_blueprint(bp)
            if not stem or stem in summaries:
                continue
            try:
                payload = load_blueprint(bp, skip_global_lineage=True, keys={"business_summary"})
            except Exception:
                continue
            summary = payload.get("business_summary")
            if isinstance(summary, str) and summary.strip():
                summaries[stem] = summary.strip()
            else:
                missing_stems.append(stem)

    if missing_stems and kb_id:
        from api.tasks.file_summary_fallback import ensure_many_business_summaries
        filled = ensure_many_business_summaries(kb_id, missing_stems, max_workers=4)
        for stem, text in filled.items():
            if text and text.strip():
                summaries[stem] = text.strip()
    return summaries


def _build_root_chains(
    graph_payload: Dict[str, Any],
    max_depth: Optional[int],
) -> Tuple[List[str], List[Dict[str, Any]], Dict[str, str]]:
    node_types: Dict[str, str] = {}
    nodes: set[str] = set()
    indegree: Dict[str, int] = {}
    adjacency: Dict[str, List[str]] = {}
    edge_inst: Dict[Tuple[str, str], str] = {}

    # Per-pair indirection envelope, used to mark hops the LLM should flag as indirect.
    edge_indirection: Dict[Tuple[str, str], Dict[str, Any]] = {}

    for n in graph_payload.get("nodes", []):
        node_id = str(n.get("id", "")).strip()
        if not node_id:
            continue
        nodes.add(node_id)
        node_types[node_id] = str(n.get("type", "project"))
        indegree.setdefault(node_id, 0)
        adjacency.setdefault(node_id, [])

    for e in graph_payload.get("edges", []):
        src = str(e.get("source", "")).strip()
        tgt = str(e.get("target", "")).strip()
        if not src or not tgt:
            continue
        nodes.add(src)
        nodes.add(tgt)
        indegree.setdefault(src, 0)
        indegree[tgt] = indegree.get(tgt, 0) + 1
        adjacency.setdefault(src, [])
        adjacency.setdefault(tgt, [])

        pair = (src, tgt)
        if pair not in edge_inst:
            edge_inst[pair] = (e.get("instructions") or ["?"])[0]
            adjacency[src].append(tgt)

        # Capture indirection envelope on first sighting of the pair so
        # downstream chain summaries can flag the hop.
        if pair not in edge_indirection:
            from api.utils.indirection import extract_indirection
            env = extract_indirection(e)
            if env is None:
                for cs in (e.get("call_sites") or []):
                    if isinstance(cs, dict):
                        env = extract_indirection(cs)
                        if env is not None:
                            break
            if env is not None:
                edge_indirection[pair] = env

    for src in adjacency:
        adjacency[src] = sorted(set(adjacency[src]))

    roots = sorted([n for n in nodes if indegree.get(n, 0) == 0])
    seen: set[Tuple[str, ...]] = set()
    chains: List[Dict[str, Any]] = []

    def add_chain(files: List[str]) -> None:
        key = tuple(files)
        if key in seen:
            return
        seen.add(key)
        hops = []
        for i in range(len(files) - 1):
            pair = (files[i], files[i + 1])
            hop: Dict[str, Any] = {
                "from": files[i],
                "to": files[i + 1],
                "inst": edge_inst.get(pair, "?"),
            }
            env = edge_indirection.get(pair)
            if env:
                hop["indirection"] = dict(env)
            hops.append(hop)
        chains.append({"length": len(files) - 1, "files": list(files), "hops": hops})

    for root in roots:
        stack: List[Tuple[str, List[str], set[str]]] = [(root, [root], {root})]
        while stack:
            node, path, visited = stack.pop()
            max_hops_reached = max_depth is not None and (len(path) - 1) >= max_depth
            if max_hops_reached:
                continue
            for nxt in adjacency.get(node, []):
                if nxt in visited:
                    continue
                new_path = path + [nxt]
                add_chain(new_path)
                stack.append((nxt, new_path, visited | {nxt}))

    chains.sort(key=lambda c: (c["length"], c["files"]))
    return roots, chains, node_types


def _run(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    from llm.chain_explainer import (
        CHAIN_SUMMARY_CACHE_VERSION,
        get_cached_chain_summary,
        graph_fingerprint,
        load_chain_summaries_cache,
        save_chain_summaries_cache,
        set_cached_chain_summary,
        summarize_chain,
    )

    job_id = ws.job_id
    _task_start = time.monotonic()

    kb_id = str(options["kb_id"])
    kb_output = settings.JOBS_BASE_DIR / kb_id / "output"
    if not kb_output.exists():
        raise FileNotFoundError(f"KB output directory not found: {kb_output}")

    graph_file = kb_output / "file_call_graph.json"

    # Phase 1/4 — Load call graph and build root chains (DB-first, JSON fallback)
    logger.info("[Phase 1/4 START] Load call graph — job=%s kb=%s", job_id, kb_id)
    _t = time.monotonic()
    try:
        from api.index_db.readers import get_call_graph
        graph_payload = get_call_graph(
            kb_id,
            fallback_path=graph_file if graph_file.exists() else None,
        )
    except Exception as _exc:
        logger.debug("[index_db] get_call_graph failed, loading JSON: %s", _exc)
        if not graph_file.exists():
            raise FileNotFoundError(f"file_call_graph.json not found in KB output: {graph_file}")
        graph_payload = json.loads(graph_file.read_text(encoding="utf-8"))

    if not graph_payload.get("nodes") and not graph_payload.get("edges"):
        raise FileNotFoundError(
            f"No call graph data found for kb={kb_id}. "
            f"Re-run the pipeline or ensure {graph_file} exists."
        )
    if not isinstance(graph_payload.get("nodes", []), list) or not isinstance(graph_payload.get("edges", []), list):
        raise ValueError("Invalid call graph data: expected 'nodes' and 'edges' arrays.")

    force_refresh = bool(options.get("force_refresh", False))
    max_depth = options.get("max_depth")
    if max_depth is not None:
        max_depth = int(max_depth)
    max_workers_opt = options.get("max_workers")
    max_workers = int(max_workers_opt) if max_workers_opt is not None else int(settings.CHAIN_SUMMARY_WORKERS)
    max_workers = max(1, max_workers)

    roots, chains, node_types = _build_root_chains(graph_payload, max_depth=max_depth)
    logger.info(
        "[Phase 1/4 DONE] Call graph loaded — roots=%d chains=%d elapsed=%.1fs",
        len(roots), len(chains), time.monotonic() - _t,
    )
    print(f"Roots found: {len(roots)}")
    print(f"Chains found (length > 1): {len(chains)}")

    # Phase 2/4 — Collect file summaries
    logger.info("[Phase 2/4 START] Collect file summaries — job=%s", job_id)
    _t = time.monotonic()
    file_summaries = _collect_file_summaries(kb_output, kb_id=kb_id)
    logger.info(
        "[Phase 2/4 DONE] File summaries — count=%d elapsed=%.1fs",
        len(file_summaries), time.monotonic() - _t,
    )

    # Phase 2b/4 — Compute per-hop call conditions
    # For every unique (from, to) pair across the chain set, invoke
    # `get_call_conditions.compute_call_conditions` once. The same pair is
    # reused across all chains that contain it.
    logger.info("[Phase 2b/4 START] Compute hop conditions — job=%s", job_id)
    _t = time.monotonic()
    hop_conditions: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    blueprint_dirs = _resolve_blueprint_dirs(kb_output)
    if blueprint_dirs:
        from api.tasks._task_utils import compute_chain_hop_conditions
        from cross_file_bridge import _discover_asm_dir
        blueprint_dir = blueprint_dirs[0]
        asm_dir = _discover_asm_dir(blueprint_dir)
        hop_conditions = compute_chain_hop_conditions(chains, blueprint_dir, asm_dir)
    logger.info(
        "[Phase 2b/4 DONE] Hop conditions — pairs=%d elapsed=%.1fs",
        len(hop_conditions), time.monotonic() - _t,
    )

    # Phase 3/4 — Cache check
    logger.info("[Phase 3/4 START] Cache check — job=%s", job_id)
    _t = time.monotonic()
    cache = load_chain_summaries_cache(kb_id)
    current_fingerprint = graph_fingerprint(graph_payload)
    existing_fingerprint = str(cache.get("graph_fingerprint", ""))
    entries = cache.get("entries", {}) if isinstance(cache.get("entries"), dict) else {}

    if force_refresh or (existing_fingerprint and existing_fingerprint != current_fingerprint):
        print("Cache reset triggered (force_refresh or graph fingerprint mismatch).")
        entries = {}

    cache = {
        "version": CHAIN_SUMMARY_CACHE_VERSION,
        "graph_fingerprint": current_fingerprint,
        "entries": entries,
    }

    reused_count = 0
    pending: List[Dict[str, Any]] = []
    for chain in chains:
        cached = None if force_refresh else get_cached_chain_summary(cache, chain)
        if cached:
            reused_count += 1
        else:
            pending.append(chain)

    logger.info(
        "[Phase 3/4 DONE] Cache check — reused=%d pending=%d elapsed=%.1fs",
        reused_count, len(pending), time.monotonic() - _t,
    )

    generated_count = 0
    failures: List[Dict[str, Any]] = []

    # Phase 4/4 — LLM summarize
    logger.info(
        "[Phase 4/4 START] LLM summarize — job=%s pending=%d workers=%d",
        job_id, len(pending), max_workers,
    )
    _t = time.monotonic()
    print(f"Cache reused: {reused_count}, to generate: {len(pending)}, workers: {max_workers}")
    def _per_chain_hc(chain: Dict[str, Any]) -> Dict[Tuple[str, str], List[Dict[str, Any]]]:
        return {
            (h.get("from"), h.get("to")): hop_conditions.get((h.get("from"), h.get("to")), [])
            for h in (chain.get("hops") or [])
            if h.get("from") and h.get("to")
        }

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {
            pool.submit(
                summarize_chain, chain, file_summaries, node_types, _per_chain_hc(chain),
            ): chain
            for chain in pending
        }
        for fut in as_completed(futures):
            chain = futures[fut]
            try:
                summary = fut.result()
                set_cached_chain_summary(cache, chain, summary)
                generated_count += 1
            except Exception as exc:
                failures.append({"files": chain.get("files", []), "error": str(exc)})

    save_chain_summaries_cache(kb_id, cache)
    logger.info(
        "[Phase 4/4 DONE] LLM summarize — generated=%d failed=%d elapsed=%.1fs total_elapsed=%.1fs",
        generated_count, len(failures), time.monotonic() - _t, time.monotonic() - _task_start,
    )

    referenced_files = {f for chain in chains for f in (chain.get("files") or [])}
    external_missing_summary_count = sum(
        1
        for f in referenced_files
        if f not in file_summaries and (node_types.get(f, "").lower() == "external")
    )
    project_missing_summary_count = sum(
        1
        for f in referenced_files
        if f not in file_summaries and (node_types.get(f, "").lower() != "external")
    )

    report = {
        "kb_id": kb_id,
        "cache_version": CHAIN_SUMMARY_CACHE_VERSION,
        "graph_fingerprint": current_fingerprint,
        "roots_count": len(roots),
        "roots": roots,
        "chains_total": len(chains),
        "generated_count": generated_count,
        "reused_count": reused_count,
        "failed_count": len(failures),
        "external_missing_summary_count": external_missing_summary_count,
        "project_missing_summary_count": project_missing_summary_count,
        "hop_conditions_pairs": len(hop_conditions),
        "max_depth": max_depth,
        "max_workers": max_workers,
        "failures": failures,
    }

    report_path = ws.output_dir / "chain_summaries_report.json"
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"Wrote report: {report_path}")

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)

    return {
        "job_id": ws.job_id,
        "status": "success",
        "kb_id": kb_id,
        "operation": "kb_chain_summaries",
        "roots_count": len(roots),
        "chains_total": len(chains),
        "generated_count": generated_count,
        "reused_count": reused_count,
        "failed_count": len(failures),
        "output_files": len(result_files),
    }
