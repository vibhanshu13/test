"""Celery task: combined universe build + full analysis pipeline."""

from __future__ import annotations

import logging
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Set

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.config import settings, print_system_profile
from api.tasks.celery_app import celery_app
from api.tasks._task_utils import redirect_output_to_log, find_blueprint_dir, job_log_handler
from api.tasks.universe_task import _run_universe
from api.tasks.analysis_task import _run_analysis, _trim_heap, _current_rss_mb, _current_cgroup_usage_mb
from api.storage.workspace import WorkspaceManager

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Index-DB ingestion helpers
# Each helper runs AFTER the corresponding pipeline step writes its JSON file.
# Failures are non-fatal: a warning is logged and the pipeline continues.
# All streaming writes are bounded by settings.INDEX_DB_BATCH_SIZE (default
# 500 rows/commit) so peak RAM stays well below pipeline OOM thresholds.
#
# Important operational choice:
# We intentionally KEEP the emitted JSON artifacts on disk even after a
# successful DB ingest. Several routes and fallback paths still read them
# directly, and preserving them makes older API paths and validation scripts
# more robust at the cost of additional disk usage.
# ---------------------------------------------------------------------------

def _preserve_output_file(path: Path) -> None:
    """Log that a pipeline output file is intentionally retained after DB ingest."""
    if path.exists():
        logger.info("[cleanup] Preserving %s on disk after index DB ingest", path.name)
        print(f"  [cleanup] Preserving {path.name}", flush=True)


def _ingest_db_step1(ws: "WorkspaceManager") -> None:
    """Ingest universe JSON outputs into the index DB after Step 1.

    Keeps each pair of universe files on disk after a successful ingest so
    DB-first callers can still fall back to the JSON artifacts when needed.
    """
    try:
        from api.index_db.writers import ingest_universe
        bs = settings.INDEX_DB_BATCH_SIZE
        out = ws.output_dir
        for lang, universe_file, names_file in (
            ("asm", out / "asm_variable_universe.json", out / "asm_variable_names.json"),
            ("cpp", out / "cpp_variable_universe.json", out / "cpp_variable_names.json"),
        ):
            if universe_file.exists() or names_file.exists():
                print(f"  [index_db] Ingesting {lang} universe → index DB …", flush=True)
                ok = ingest_universe(ws.job_id, lang, universe_file, names_file, batch_size=bs)
                print(f"  [index_db] {lang} universe {'OK' if ok else 'WARN (see log)'}",
                      flush=True)
                if ok:
                    _preserve_output_file(universe_file)
                    _preserve_output_file(names_file)
    except Exception as exc:
        logger.warning("[index_db] step1 ingestion error (job=%s): %s", ws.job_id, exc)


def _ingest_db_step2(ws: "WorkspaceManager") -> None:
    """Ingest global_variable_lineage into the index DB after Step 2.

    Uses LazyGVL which streams one node/edge at a time — safe even for
    7.78 GB files.  Does NOT load the full GVL into RAM.

    Keeps the GVL file on disk after a successful ingest so fallback readers
    and validation/debug flows can still consume the original artifact.
    """
    try:
        from api.index_db.writers import ingest_gvl
        bs = settings.INDEX_DB_BATCH_SIZE
        # GVL may live in the blueprint sub-directory or directly in output_dir.
        blueprint_dir = find_blueprint_dir(ws.output_dir)
        candidates = [
            ws.output_dir / "global_variable_lineage.json",
        ]
        if blueprint_dir:
            candidates.insert(0, blueprint_dir / "global_variable_lineage.json")
            candidates.insert(0, blueprint_dir.parent / "global_variable_lineage.json")

        gvl_path = next((p for p in candidates if p.exists()), None)
        if gvl_path:
            print(f"  [index_db] Ingesting GVL ({gvl_path.stat().st_size // (1024**2)} MB) → index DB …",
                  flush=True)
            ok = ingest_gvl(ws.job_id, gvl_path, batch_size=bs)
            print(f"  [index_db] GVL {'OK' if ok else 'WARN (see log)'}", flush=True)
            if ok:
                _preserve_output_file(gvl_path)
        else:
            logger.warning("[index_db] global_variable_lineage not found for job=%s", ws.job_id)
    except Exception as exc:
        logger.warning("[index_db] step2 ingestion error (job=%s): %s", ws.job_id, exc)


def _ingest_db_step3(ws: "WorkspaceManager") -> None:
    """Ingest file_call_graph.json into the index DB after Step 3.

    Keeps the JSON file on disk after a successful ingest because several API
    and script paths still read the graph artifact directly.
    """
    try:
        from api.index_db.writers import ingest_call_graph
        graph_path = ws.output_dir / "file_call_graph.json"
        if graph_path.exists():
            print("  [index_db] Ingesting call graph → index DB …", flush=True)
            ok = ingest_call_graph(ws.job_id, graph_path, batch_size=settings.INDEX_DB_BATCH_SIZE)
            print(f"  [index_db] Call graph {'OK' if ok else 'WARN (see log)'}", flush=True)
            if ok:
                _preserve_output_file(graph_path)
    except Exception as exc:
        logger.warning("[index_db] step3 ingestion error (job=%s): %s", ws.job_id, exc)


def _ingest_db_step4(ws: "WorkspaceManager") -> None:
    """Ingest variable_modifier_index.json into the index DB after Step 4.

    Keeps the JSON file on disk after a successful ingest for compatibility
    with fallback readers and utility scripts.
    """
    try:
        from api.index_db.writers import ingest_modifier_index
        idx_path = ws.output_dir / "variable_modifier_index.json"
        if idx_path.exists():
            print("  [index_db] Ingesting modifier index → index DB …", flush=True)
            ok = ingest_modifier_index(ws.job_id, idx_path, batch_size=settings.INDEX_DB_BATCH_SIZE)
            print(f"  [index_db] Modifier index {'OK' if ok else 'WARN (see log)'}", flush=True)
            if ok:
                _preserve_output_file(idx_path)
    except Exception as exc:
        logger.warning("[index_db] step4 ingestion error (job=%s): %s", ws.job_id, exc)


def _ingest_db_step5(ws: "WorkspaceManager") -> None:
    """Ingest variable_identity_index.json into the index DB after Step 5.

    Keeps the JSON file on disk after a successful ingest so identity lookups
    can still fall back to the file when required.
    """
    try:
        from api.index_db.writers import ingest_identity_index
        idx_path = ws.output_dir / "variable_identity_index.json"
        if idx_path.exists():
            print("  [index_db] Ingesting identity index → index DB …", flush=True)
            ok = ingest_identity_index(ws.job_id, idx_path, batch_size=settings.INDEX_DB_BATCH_SIZE)
            print(f"  [index_db] Identity index {'OK' if ok else 'WARN (see log)'}", flush=True)
            if ok:
                _preserve_output_file(idx_path)
    except Exception as exc:
        logger.warning("[index_db] step5 ingestion error (job=%s): %s", ws.job_id, exc)


def _ingest_db_step6(ws: "WorkspaceManager") -> None:
    """Ingest variable_hop_index.json into the index DB after Step 6.

    Keeps the JSON file on disk after a successful ingest for compatibility
    with fallback readers and downstream utilities.
    """
    try:
        from api.index_db.writers import ingest_hop_index
        idx_path = ws.output_dir / "variable_hop_index.json"
        if idx_path.exists():
            sz_mb = idx_path.stat().st_size // (1024 ** 2)
            print(f"  [index_db] Ingesting hop index ({sz_mb} MB) → index DB …", flush=True)
            ok = ingest_hop_index(ws.job_id, idx_path, batch_size=settings.INDEX_DB_BATCH_SIZE)
            print(f"  [index_db] Hop index {'OK' if ok else 'WARN (see log)'}", flush=True)
            if ok:
                _preserve_output_file(idx_path)
    except Exception as exc:
        logger.warning("[index_db] step6 ingestion error (job=%s): %s", ws.job_id, exc)


def _ingest_db_reach_facts(ws: "WorkspaceManager") -> None:
    """Build block_reach_facts after Step 6 (Lineage Facts Index, Phase 2).

    Precomputes backward-CFG reachability per (file, block) so the
    backward-lineage dep-var BFS does packed-set lookups instead of repeated
    CFG walks.  Gated by ASM_BUILD_REACH_FACTS (default on); skips when the
    job already has rows unless ASM_REBUILD_REACH_FACTS=1.  Non-fatal: on any
    failure the BFS transparently falls back to live CFG walks.
    """
    try:
        if os.environ.get("ASM_BUILD_REACH_FACTS", "1").strip().lower() in (
            "0", "false", "no", "off",
        ):
            logger.info("[index_db] reach facts disabled via ASM_BUILD_REACH_FACTS")
            return
        from api.index_db.writers import ingest_block_reach_facts
        blueprint_dir = find_blueprint_dir(ws.output_dir)
        if blueprint_dir is None:
            logger.warning("[index_db] reach facts: no blueprint dir for job=%s", ws.job_id)
            return
        _rebuild = os.environ.get("ASM_REBUILD_REACH_FACTS", "0").strip().lower() in (
            "1", "true", "yes", "on",
        )
        print("  [index_db] Building block reachability facts → index DB …", flush=True)
        _t = time.monotonic()
        ok = ingest_block_reach_facts(
            ws.job_id,
            blueprint_dir,
            batch_size=settings.INDEX_DB_BATCH_SIZE,
            skip_if_exists=not _rebuild,
        )
        print(
            f"  [index_db] Reach facts {'OK' if ok else 'WARN (see log)'} "
            f"| elapsed={time.monotonic() - _t:.1f}s",
            flush=True,
        )
    except Exception as exc:
        logger.warning("[index_db] reach-facts ingestion error (job=%s): %s", ws.job_id, exc)


def _log_step_ram(label: str) -> None:
    """Log current RSS + cgroup memory usage at a pipeline step boundary."""
    rss_mb = _current_rss_mb()
    cgroup_mb = _current_cgroup_usage_mb()
    logger.info("[RAM] %s — RSS=%d MB  cgroup=%d MB", label, rss_mb, cgroup_mb)
    print(f"  [RAM] {label}: RSS={rss_mb} MB | cgroup={cgroup_mb} MB", flush=True)


# ---------------------------------------------------------------------------
# Pipeline step ordering & resume helpers
# ---------------------------------------------------------------------------

PIPELINE_STEP_ORDER = ["step1", "step2", "step2_5", "step3", "step4", "step5", "step6", "step7", "step8"]

# All accepted values for the resume_from_step option.
# Shared with api/schemas/pipeline.py for validation.
VALID_RESUME_VALUES: Set[str] = {
    # Step-level: skip all preceding steps
    "step1", "step2", "step2_5", "step3", "step4", "step5", "step6", "step7", "step8",
    # Phase-level within step2: step1 is always skipped; step2 re-runs and
    # internally decides which phases to skip based on the value passed.
    #   phase1/2/3  → re-run the full orchestrator (ignore any existing manifest)
    #   phase4_prep → use manifest if present; skip orchestrator + GVL write
    #   phase4      → use manifest if present; skip orchestrator + GVL write
    #   phase5      → use manifest if present; skip orchestrator, GVL, and
    #                  blueprint emission when all blueprints already exist
    "step2_phase1", "step2_phase2", "step2_phase3",
    "step2_phase4_prep", "step2_phase4", "step2_phase5",
}


def _get_skip_steps(resume_from: Optional[str]) -> Set[str]:
    """Return the set of pipeline step names to skip when resuming.

    Step-level resumes (step1–step6, step2_5) skip all steps that precede
    the named step in PIPELINE_STEP_ORDER.

    Phase-level resumes (step2_phase*) always skip step1 (universe is already
    built on disk).  Step2 re-runs in all cases, but _run_analysis internally
    decides which phases to execute based on the resume_from value passed via
    analysis_opts:
      - phase1/2/3    → re-run the full orchestrator (ignore any cached manifest)
      - phase4_prep   → use manifest to skip orchestrator + GVL write; re-run emission
      - phase4        → same as phase4_prep (manifest + ctx_cache already complete)
      - phase5        → use manifest; skip emission if all blueprints already exist
    """
    if not resume_from:
        return set()
    if resume_from not in VALID_RESUME_VALUES:
        logger.warning(
            "Unknown resume_from_step=%r — ignoring, pipeline will run from scratch. "
            "Valid values: %s", resume_from, sorted(VALID_RESUME_VALUES),
        )
        return set()
    if resume_from.startswith("step2_phase"):
        # All phase-level resumes skip only step1; step2 always re-runs and
        # _run_analysis handles the phase-level logic internally.
        return {"step1"}
    idx = PIPELINE_STEP_ORDER.index(resume_from)
    return set(PIPELINE_STEP_ORDER[:idx])


def _mark_step(ws: WorkspaceManager, step_name: str, status: str) -> None:
    """Write a step status to Redis, suppressing errors so they never kill the task."""
    try:
        ws.set_step_status(step_name, status)
    except Exception as exc:
        logger.warning("Could not mark step %s as %s: %s", step_name, status, exc)


# ---------------------------------------------------------------------------
# KB status helper (opens its own DB session — safe to call from a worker)
# ---------------------------------------------------------------------------

def _update_kb_status(kb_id: str, status: str, error: str | None = None) -> None:
    try:
        from api.db import SessionLocal
        from api.models.knowledge_base import KnowledgeBase
        db = SessionLocal()
        try:
            kb = db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).first()
            if kb:
                kb.status = status
                kb.updated_at = datetime.now(timezone.utc)
                if error:
                    kb.error = error
                db.commit()
        finally:
            db.close()
    except Exception as exc:
        logger.warning("Could not update KB status for %s: %s", kb_id, exc)


# ---------------------------------------------------------------------------
# Celery task
# ---------------------------------------------------------------------------

@celery_app.task(
    bind=True,
    name="asm.full_pipeline",
)
def run_full_pipeline(self, job_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    """
    Run universe building then full analysis in a single task — equivalent to:

        python3 universe_builder.py <src> --output <out> && \\
        python3 main.py <src> --load-universe --universe-dir <out> ...

    The job_id doubles as the knowledge base UUID. Output lands in
    jobs/{job_id}/output/ and is accessible through the KB endpoints.

    Pass ``options["resume_from_step"]`` to skip steps that already succeeded
    in a previous run of this job.
    """
    ws = WorkspaceManager(job_id)
    ws.set_status("running")
    _update_kb_status(job_id, "running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                result = _run_pipeline(ws, options)
                _update_kb_status(job_id, "success")
                return result
            except SoftTimeLimitExceeded:
                error_msg = "Task exceeded soft time limit and was aborted."
                logger.error("Job %s: %s", job_id, error_msg)
                ws.set_status("failed", error=error_msg)
                _update_kb_status(job_id, "failed", error=error_msg)
                return {"job_id": job_id, "status": "failed", "error": error_msg}
            except Exception as exc:
                error_msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s failed: %s", job_id, error_msg)
                ws.set_status("failed", error=error_msg)
                _update_kb_status(job_id, "failed", error=error_msg)
                return {"job_id": job_id, "status": "failed", "error": error_msg}


def _run_pipeline(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    """Build the universe then run full analysis, feeding universe output in."""

    source_path: str = options["source_path"]
    job_id = ws.job_id
    _pipeline_start = time.monotonic()
    _log_step_ram("Pipeline START")

    resume_from: Optional[str] = options.get("resume_from_step")
    skip_steps: Set[str] = _get_skip_steps(resume_from)

    if resume_from:
        logger.info(
            "[Pipeline RESUME] job=%s resume_from=%s skip=%s",
            job_id, resume_from, sorted(skip_steps),
        )
        print(f"=== Resuming pipeline from: {resume_from} (skipping: {sorted(skip_steps)}) ===")

    # Emit a full system-resource banner at the top of every job log so
    # operators can verify that worker counts match actual hardware and
    # identify resource-related failures after the fact.
    print_system_profile()

    # -----------------------------------------------------------------------
    # Step 1 — universe build
    # -----------------------------------------------------------------------
    universe_opts: Dict[str, Any] = {
        "source_path": source_path,
        "asm_only": options.get("asm_only", False),
        "cpp_only": options.get("cpp_only", False),
        "exclude": options.get("exclude", []),
    }

    if "step1" not in skip_steps:
        logger.info("[Step 1/7 START] Universe build — job=%s src=%s", job_id, source_path)
        print("=== Step 1/7: Building variable universe ===")
        print(f"  Input   : {source_path}")
        print("  Action  : scan all ASM and C++ source files and collect unique variable names.")
        print("  Output  : asm_variable_names.json + cpp_variable_names.json")
        print("  Purpose : name sets are passed to Step 2 to enrich cross-file variable", flush=True)
        print("            resolution and lineage tracing.", flush=True)
        _mark_step(ws, "step1", "running")
        _log_step_ram("Step 1 START")
        _t = time.monotonic()
        try:
            universe_result = _run_universe(ws, universe_opts, update_status=False)
        except Exception:
            _mark_step(ws, "step1", "failed")
            raise
        _mark_step(ws, "step1", "success")
        _step1_elapsed = time.monotonic() - _t
        _log_step_ram("Step 1 END")
        logger.info(
            "[Step 1/7 DONE] Universe build — asm_vars=%d cpp_vars=%d elapsed=%.1fs",
            universe_result.get("asm_variables", 0),
            universe_result.get("cpp_variables", 0),
            _step1_elapsed,
        )
        print(f"  [TIME] Step 1 elapsed: {_step1_elapsed:.1f}s", flush=True)
        print(
            f"Universe built: {universe_result.get('asm_variables', 0)} ASM vars, "
            f"{universe_result.get('cpp_variables', 0)} C++ vars"
        )
        # Ingest universe JSON into the index DB (streaming, O(batch_size) RAM).
        _ingest_db_step1(ws)
    else:
        logger.info("[Step 1/7 SKIP] Universe build — resume_from=%s", resume_from)
        print("=== Step 1/7: Skipped (universe already built) ===")

    # -----------------------------------------------------------------------
    # Heap trim between step1 and step2.
    #
    # After the UniverseBuilder frees its internal structures (11 K+ files'
    # worth of parsed line-contexts, VariableUniverse dicts, etc.), Python's
    # allocator holds those pages in its internal free-lists rather than
    # returning them to the OS.  Without an explicit malloc_trim() the RSS
    # stays near the step-1 peak (~1.6 GB for 14 K files) even though the
    # live data is only ~200–300 MB.
    #
    # Step 2 forks analysis workers via ProcessPoolExecutor('fork').  Each
    # forked child inherits the full parent address space.  Python's reference
    # counting touches object headers on every read, triggering copy-on-write
    # for those pages.  On a 7 GB container with 3 workers and a 1.6 GB
    # untrimmed heap: 3 × 1.6 GB = 4.8 GB just from fork overhead, leaving
    # < 2 GB for analysis work and accumulated results → SIGKILL.
    #
    # Trimming first reduces the fork baseline from ~1.6 GB to ~300 MB,
    # giving 3 × 300 MB = 0.9 GB fork overhead and ~6 GB room for analysis.
    # -----------------------------------------------------------------------
    import gc as _gc
    _gc.collect()
    _trim_heap("between step1 and step2 (pre-fork trim)")
    _log_step_ram("Post-step1 heap trim")

    # -----------------------------------------------------------------------
    # Step 2 — full analysis using the universe we just built
    # -----------------------------------------------------------------------
    analysis_opts: Dict[str, Any] = {
        "source_path": source_path,
        "search_paths": options.get("search_paths", []),
        "macro_libs": options.get("macro_libs", []),
        "no_coverage_review": options.get("no_coverage_review", False),
        "skip_business_summary": options.get("skip_business_summary", False),
        "exclude": options.get("exclude", []),
        "lineage_name": options.get("lineage_name"),
        "lineage_kind": options.get("lineage_kind", "variable"),
        "lineage_direction": options.get("lineage_direction", "backward"),
        "lineage_depth": options.get("lineage_depth", 10),
        "lineage_export": options.get("lineage_export", False),
        "load_universe": True,
        "universe_job_id": ws.job_id,
        # Passed through so _run_analysis can make phase-level decisions
        # (e.g. whether to honour an existing emission manifest).
        "resume_from": resume_from or "",
    }

    if "step2" not in skip_steps:
        logger.info("[Step 2/7 START] Full analysis — job=%s", job_id)
        print("=== Step 2/7: Running full analysis ===")
        print("  Action  : per-file parse → cross-file EXTRN/ENTRY linking → macro expansion")
        print("            → global variable lineage stitching → JSON blueprint emission.")
        print("  Output  : one .asm.json / .cpp.json blueprint per source file, plus")
        print("            global_variable_lineage.json for the stitched cross-file lineage.", flush=True)
        _mark_step(ws, "step2", "running")
        _log_step_ram("Step 2 START")
        _t = time.monotonic()
        try:
            analysis_result = _run_analysis(ws, analysis_opts, update_status=False)
        except Exception:
            _mark_step(ws, "step2", "failed")
            raise
        _mark_step(ws, "step2", "success")
        _step2_elapsed = time.monotonic() - _t
        _log_step_ram("Step 2 END")
        logger.info(
            "[Step 2/7 DONE] Full analysis — files_analyzed=%d elapsed=%.1fs",
            analysis_result.get("files_analyzed", 0),
            _step2_elapsed,
        )
        print(f"  [TIME] Step 2 elapsed: {_step2_elapsed:.1f}s", flush=True)
        # Stream global_variable_lineage into the index DB.
        # LazyGVL keeps peak RAM at O(1 item) — safe even for the 7.78 GB GVL.
        _ingest_db_step2(ws)
    else:
        logger.info("[Step 2/7 SKIP] Full analysis — resume_from=%s", resume_from)
        print("=== Step 2/7: Skipped (analysis already complete) ===")
        analysis_result = {"files_analyzed": 0, "output_files": 0}

    # Return all analysis heap memory to the OS before the post-processing
    # steps.  Blueprints for Steps 2.5-6 are loaded from disk (no in-memory
    # contexts), but the analysis task may have left glibc's heap fragmented
    # with freed pages.  Without this, Step 2.5's global-lineage load (+3.7 GB)
    # could push total RSS over the system limit on an 8 GB host.
    import gc
    gc.collect()
    _trim_heap("between analysis and post-processing steps")
    _log_step_ram("Post-step2 heap trim")

    # -----------------------------------------------------------------------
    # Step 2.5 — back-fill access_identity using cross-file DSECT layouts
    # -----------------------------------------------------------------------
    if "step2_5" not in skip_steps:
        logger.info("[Step 2.5/7 START] Cross-file access_identity enrichment — job=%s", job_id)
        print("=== Step 2.5/7: Enriching access_identity cross-file ===")
        print("  Action  : load DSECT field-offset layouts from all blueprint files.")
        print("            Back-fill access_identity (e.g. 'CE1CR5:17') on variable-lineage")
        print("            edges that were recorded with only a local label in Step 2.", flush=True)
        _mark_step(ws, "step2_5", "running")
        _log_step_ram("Step 2.5 START")
        _t = time.monotonic()
        try:
            _enrich_access_identity(ws)
        except Exception:
            _mark_step(ws, "step2_5", "failed")
            raise
        _mark_step(ws, "step2_5", "success")
        _step25_elapsed = time.monotonic() - _t
        _log_step_ram("Step 2.5 END")
        logger.info("[Step 2.5/7 DONE] Cross-file enrichment — elapsed=%.1fs", _step25_elapsed)
        print(f"  [TIME] Step 2.5 elapsed: {_step25_elapsed:.1f}s", flush=True)
    else:
        logger.info("[Step 2.5/7 SKIP] Cross-file enrichment — resume_from=%s", resume_from)
        print("=== Step 2.5/7: Skipped (enrichment already done) ===")

    # -----------------------------------------------------------------------
    # Steps 3, 4, 5 — run sequentially to avoid peak-RAM collision.
    # Each step decompresses full blueprints before key-pruning; running all
    # three concurrently triples peak memory, causing OOM when variable_lineage
    # is populated.  Sequential execution keeps only one step's working set
    # live at a time.
    # -----------------------------------------------------------------------
    # Mapping from step name to its post-build DB ingest function.
    # Steps 4 and 5 write directly to DB during build (no post-ingest needed).
    _step_db_ingest = {
        "step3": _ingest_db_step3,
    }

    _serial_steps = [
        ("step3", _build_call_graph,            {"ws": ws, "source_path": source_path}),
        ("step4", _build_modifier_index,         {"ws": ws}),
        ("step5", _build_variable_identity_index, {"ws": ws}),
    ]
    _step_labels = {
        "step3": "Step 3 (call graph)",
        "step4": "Step 4 (modifier index)",
        "step5": "Step 5 (identity index)",
    }

    steps_to_run = [(sn, fn, kw) for sn, fn, kw in _serial_steps if sn not in skip_steps]
    steps_skipped = [sn for sn, _, _ in _serial_steps if sn in skip_steps]

    for sn in steps_skipped:
        logger.info("[%s SKIP] resume_from=%s", _step_labels[sn], resume_from)
        print(f"=== {_step_labels[sn]}: Skipped ===")

    if steps_to_run:
        logger.info(
            "[Steps 3+4+5/7 START] Sequential index build — job=%s running=%s",
            job_id, [sn for sn, _, _ in steps_to_run],
        )
        print("=== Steps 3+4+5/7: Building indexes sequentially ===")
        print("  Step 3 — Call graph    : maps inter-file routine calls (who calls whom).")
        print("  Step 4 — Modifier idx  : maps each variable to the files that write/modify it.")
        print("  Step 5 — Identity idx  : assigns a canonical cross-file key to each unique variable.", flush=True)
        for sn, fn, kw in steps_to_run:
            label = _step_labels[sn]
            _mark_step(ws, sn, "running")
            _log_step_ram(f"{label} START")
            _t_step = time.monotonic()
            try:
                fn(**kw)
            except Exception:
                _mark_step(ws, sn, "failed")
                raise
            _mark_step(ws, sn, "success")
            _sn_elapsed = time.monotonic() - _t_step
            _log_step_ram(f"{label} END")
            logger.info("[%s DONE] elapsed=%.1fs", label, _sn_elapsed)
            print(f"  {label}: done | elapsed={_sn_elapsed:.1f}s", flush=True)
            # Ingest this step's output into the index DB (streaming, memory-safe).
            if sn in _step_db_ingest:
                _step_db_ingest[sn](ws)

    # -----------------------------------------------------------------------
    # Step 6 — variable hop index (requires identity index from Step 5)
    # -----------------------------------------------------------------------
    if "step6" not in skip_steps:
        logger.info("[Step 6/7 START] Variable hop index — job=%s", job_id)
        print("=== Step 6/7: Building variable hop index ===")
        print("  Action  : trace all multi-hop data-flow paths between variables across the codebase.")
        print("  Requires: variable_identity_index.json (Step 5) to key entries by canonical identity.", flush=True)
        _mark_step(ws, "step6", "running")
        _log_step_ram("Step 6 START")
        _t = time.monotonic()
        try:
            _build_variable_hop_index(ws)
        except Exception:
            _mark_step(ws, "step6", "failed")
            raise
        _mark_step(ws, "step6", "success")
        _step6_elapsed = time.monotonic() - _t
        _log_step_ram("Step 6 END")
        logger.info("[Step 6/7 DONE] Hop index — elapsed=%.1fs", _step6_elapsed)
        print(f"  [TIME] Step 6 elapsed: {_step6_elapsed:.1f}s", flush=True)
        # Hop index was written directly to DB during build — no post-ingest step.
    else:
        logger.info("[Step 6/7 SKIP] Hop index — resume_from=%s", resume_from)
        print("=== Step 6/7: Skipped (hop index already built) ===")

    # Lineage Facts Index, Phase 2 — block reachability facts.  Runs after
    # Step 6 regardless of resume point (idempotent: skips when the job
    # already has rows) so resumed jobs still get the facts build.
    _ingest_db_reach_facts(ws)

    # -----------------------------------------------------------------------
    # Step 7 — process seed materialization (stub for the cluster finder).
    # Copies pre-built C400 + plastic_authentication seed JSONs from
    # data/processes/ into output/processes/<process>/.
    # When the real clustering pass lands, only the body of
    # find_clusters_and_write changes — this orchestration block stays.
    # -----------------------------------------------------------------------
    if "step7" not in skip_steps:
        logger.info("[Step 7/7 START] Process seeds — job=%s", job_id)
        print("=== Step 7/7: Writing process seed outputs ===")
        print("  Action  : copy data/processes/<C400,plastic_authentication>/*.json")
        print("            into output/processes/<process>/.  Stub until cluster finder lands.", flush=True)
        _mark_step(ws, "step7", "running")
        _log_step_ram("Step 7 START")
        _t = time.monotonic()
        try:
            from api.tasks.process_seeds import find_clusters_and_write
            find_clusters_and_write(ws)
        except Exception:
            _mark_step(ws, "step7", "failed")
            raise
        _mark_step(ws, "step7", "success")
        _step7_elapsed = time.monotonic() - _t
        _log_step_ram("Step 7 END")
        logger.info("[Step 7/7 DONE] Process seeds — elapsed=%.1fs", _step7_elapsed)
        print(f"  [TIME] Step 7 elapsed: {_step7_elapsed:.1f}s", flush=True)
    else:
        logger.info("[Step 7/7 SKIP] Process seeds — resume_from=%s", resume_from)
        print("=== Step 7/7: Skipped ===")

    # All index.db writes are done — truncate the WAL (hundreds of MB after
    # GVL ingestion) and VACUUM if delete+reingest cycles left free pages.
    _t_compact = time.monotonic()
    try:
        from api.index_db.engine import compact_database
        compact_database(job_id)
        print(f"  [TIME] index.db compaction: {time.monotonic() - _t_compact:.1f}s", flush=True)
    except Exception as _compact_exc:
        logger.warning("[Pipeline] index.db compaction failed (non-fatal): %s", _compact_exc)

    # -----------------------------------------------------------------------
    # Early-exit hook — stop_after_step
    #
    # When ``options["stop_after_step"]`` is set to a step number (e.g. 7),
    # the pipeline marks itself as successful immediately after that step
    # completes without running any later steps.  This is useful for runs
    # where the LLM-heavy step 8 (chain summaries) is intentionally skipped
    # and all required output files are already written.
    # -----------------------------------------------------------------------
    _stop_after = options.get("stop_after_step")
    if _stop_after is not None:
        try:
            _stop_num = int(_stop_after)
        except (TypeError, ValueError):
            _stop_num = None
        if _stop_num is not None and _stop_num <= 7:
            result_files = ws.collect_output_files()
            ws.set_status("success", result_files=result_files)
            _total_elapsed = time.monotonic() - _pipeline_start
            _log_step_ram("Pipeline END (stop_after_step)")
            logger.info(
                "[Pipeline] stop_after_step=%s — all required files written; "
                "marking success. job=%s output_files=%d total_elapsed=%.1fs",
                _stop_num, job_id, len(result_files), _total_elapsed,
            )
            print(
                f"=== Pipeline complete: stopped after step {_stop_num} as requested. ==="
            )
            print(f"  [TIME] Total pipeline elapsed: {_total_elapsed:.1f}s", flush=True)
            return analysis_result

    # -----------------------------------------------------------------------
    # Step 8 — pre-compute chain summaries (LLM, non-critical)
    # Generates business-level summaries for all call chains and caches them
    # in chain_summaries.msgpack so keyword-file-flow can serve rich
    # summaries without an LLM call at request time.
    # Failure here is non-critical — the endpoint falls back gracefully.
    # -----------------------------------------------------------------------
    if "step8" not in skip_steps:
        logger.info("[Step 8/8 START] Chain summaries — job=%s", job_id)
        print("=== Step 8/8: Pre-computing chain summaries ===")
        print("  Action  : LLM-summarise every call chain in file_call_graph.json.")
        print("  Output  : output/chain_summaries.msgpack", flush=True)
        _mark_step(ws, "step8", "running")
        _log_step_ram("Step 8 START")
        _t = time.monotonic()
        try:
            from api.tasks.kb_chain_summaries_task import _run as _run_chain_summaries
            _run_chain_summaries(ws, {"kb_id": job_id})
            _mark_step(ws, "step8", "success")
        except Exception as _step8_exc:
            logger.warning("[Step 8/8 FAILED] Chain summaries — job=%s error=%s", job_id, _step8_exc)
            _mark_step(ws, "step8", "failed")
        _step8_elapsed = time.monotonic() - _t
        _log_step_ram("Step 8 END")
        logger.info("[Step 8/8 DONE] Chain summaries — elapsed=%.1fs", _step8_elapsed)
        print(f"  [TIME] Step 8 elapsed: {_step8_elapsed:.1f}s", flush=True)
    else:
        logger.info("[Step 8/8 SKIP] Chain summaries — resume_from=%s", resume_from)
        print("=== Step 8/8: Skipped (chain summaries already computed) ===")

    # Mark the full pipeline as complete only after all 8 steps finish
    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)

    _total_elapsed = time.monotonic() - _pipeline_start
    _log_step_ram("Pipeline END")
    logger.info(
        "[Pipeline COMPLETE] job=%s output_files=%d total_elapsed=%.1fs",
        job_id, len(result_files), _total_elapsed,
    )
    print(f"  [TIME] Total pipeline elapsed: {_total_elapsed:.1f}s", flush=True)

    return analysis_result


def _build_call_graph(ws: WorkspaceManager, source_path: str = "") -> None:
    """Build call-graph artifacts from parser output and write them to output_dir.

    Artifacts:
    - file_call_graph.json (file-to-file graph)
    - topological_sort/block_flow.json (within-file block/scope graph for ASM + C++)
    """
    from file_call_graph import CallGraphBuilder, format_json
    from call_graph.topological_block_flow import build_block_flow

    blueprint_dir = find_blueprint_dir(ws.output_dir)
    if blueprint_dir is None:
        print("No .asm.json blueprints found in output dir; skipping file_call_graph.json build.")
    else:
        asm_dir = Path(source_path) if source_path and Path(source_path).exists() else None

        builder = CallGraphBuilder(
            asm_dir=asm_dir,
            blueprint_dir=blueprint_dir,
            recursive=False,
        )
        graph = builder.build()

        if graph.warnings:
            for w in graph.warnings:
                print(f"call graph warning: {w}")

        output_path = ws.output_dir / "file_call_graph.json"
        output_path.write_text(format_json(graph, include_external=True), encoding="utf-8")
        print(f"Wrote call graph: {output_path} ({len(graph.all_stems)} files, {len(graph.internal_edges) + len(graph.external_edges)} edges)")

    # Build within-file block/scope flow for both ASM and C++ when parser JSONs exist.
    parser_json_dir: Optional[Path] = None
    for candidate in (ws.output_dir / "asm", ws.output_dir):
        if candidate.is_dir() and (
            next(candidate.glob("*.asm.json"), None) is not None
            or next(candidate.glob("*.cpp.json"), None) is not None
        ):
            parser_json_dir = candidate
            break
    if parser_json_dir is None:
        try:
            for subdir in sorted(ws.output_dir.iterdir()):
                if subdir.is_dir() and (
                    next(subdir.glob("*.asm.json"), None) is not None
                    or next(subdir.glob("*.cpp.json"), None) is not None
                ):
                    parser_json_dir = subdir
                    break
        except (OSError, PermissionError):
            pass

    if parser_json_dir is None:
        print("No .asm.json/.cpp.json parser outputs found; skipping block_flow.json build.")
        return

    topo_dir = ws.output_dir / "topological_sort"
    block_flow = build_block_flow(str(parser_json_dir), str(topo_dir))
    files_count = len(block_flow.get("files", [])) if isinstance(block_flow, dict) else 0
    print(f"Wrote block flow: {topo_dir / 'block_flow.json'} ({files_count} files)")


def _build_modifier_index(ws: WorkspaceManager) -> None:
    """Build modifier index from blueprint output, writing directly to index DB."""
    from build_modifier_index import build_index

    blueprint_dir = find_blueprint_dir(ws.output_dir)
    if blueprint_dir is None:
        print("No .asm.json blueprints found in output dir; skipping modifier index.")
        return

    output_path = ws.output_dir / "variable_modifier_index.json"
    build_index(blueprint_dir, output_path, job_id=ws.job_id)


def _build_variable_identity_index(ws: WorkspaceManager) -> None:
    """Build identity index from blueprint output, writing directly to index DB."""
    from build_variable_identity_index import build_index

    blueprint_dir = find_blueprint_dir(ws.output_dir)
    if blueprint_dir is None:
        print("No .asm.json blueprints found in output dir; skipping identity index.")
        return

    output_path = ws.output_dir / "variable_identity_index.json"
    build_index(blueprint_dir, output_path, job_id=ws.job_id)


def _build_variable_hop_index(ws: WorkspaceManager) -> None:
    """Build hop index from blueprint output, writing directly to index DB.

    Resolves canonical keys via the identity index already written to the DB
    by Step 5 (get_identity_by_name_bulk is DB-first).
    """
    from build_variable_hop_index import build_index

    blueprint_dir = find_blueprint_dir(ws.output_dir)
    if blueprint_dir is None:
        print("No .asm.json blueprints found in output dir; skipping hop index.")
        return

    identity_index_path = ws.output_dir / "variable_identity_index.json"
    output_path = ws.output_dir / "variable_hop_index.json"
    build_index(blueprint_dir, identity_index_path, output_path, job_id=ws.job_id)


def _enrich_access_identity(ws: WorkspaceManager) -> None:
    """Back-fill access_identity on variable-lineage edges using cross-file DSECT layouts."""
    from passes.cross_file_access_identity import enrich_access_identity

    blueprint_dir = find_blueprint_dir(ws.output_dir)
    if blueprint_dir is None:
        print("No .asm.json blueprints found; skipping access_identity enrichment.")
        return

    result = enrich_access_identity(blueprint_dir)
    print(
        f"access_identity enrichment: {result['edges_newly_enriched']} edges enriched "
        f"({result['enrichment_coverage_pct']}% of {result['edges_with_dsect']} DSECT edges), "
        f"{result['dsect_layouts_collected']} DSECT layouts loaded"
    )
