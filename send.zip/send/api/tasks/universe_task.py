"""Celery task: variable universe building (universe_builder.py equivalent)."""

from __future__ import annotations

import logging
import sys
import time
from pathlib import Path
from typing import Any, Dict

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.tasks.celery_app import celery_app
from api.tasks._task_utils import redirect_output_to_log, job_log_handler
from api.storage.workspace import WorkspaceManager

logger = logging.getLogger(__name__)


@celery_app.task(
    bind=True,
    name="asm.universe_build",
)
def run_universe_build(self, job_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build ASM and C/C++ variable universes from uploaded source files.

    Mirrors universe_builder.py programmatically — scans the job input
    directory, builds UniverseBuilder instances, and writes universe JSON
    files to the job output directory.
    """
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run_universe(ws, options)
            except SoftTimeLimitExceeded:
                error_msg = "Task exceeded soft time limit and was aborted."
                logger.error("Job %s: %s", job_id, error_msg)
                ws.set_status("failed", error=error_msg)
                return {"job_id": job_id, "status": "failed", "error": error_msg}
            except Exception as exc:
                error_msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s failed: %s", job_id, error_msg)
                ws.set_status("failed", error=error_msg)
                return {"job_id": job_id, "status": "failed", "error": error_msg}


def _run_universe(ws: WorkspaceManager, options: Dict[str, Any], update_status: bool = True) -> Dict[str, Any]:
    """Core universe building logic."""
    from universe_builder import UniverseBuilder, is_asm_file, is_cpp_file, find_source_files

    job_id = ws.job_id
    _task_start = time.monotonic()

    input_dir = Path(options["source_path"]) if options.get("source_path") else ws.input_dir
    output_dir = ws.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    asm_only: bool = options.get("asm_only", False)
    cpp_only: bool = options.get("cpp_only", False)
    exclude_patterns = options.get("exclude", [])

    # Phase 1/3 — Discover source files
    logger.info("[Phase 1/3 START] Source file discovery — job=%s input=%s", job_id, input_dir)
    _t = time.monotonic()
    source_files = find_source_files(
        [str(input_dir)],
        exclude_patterns=exclude_patterns,
        respect_gitignore=False,
        include_test_sources=False,
    )

    if not source_files:
        raise ValueError("No source files found in uploaded input.")

    # Apply asm_only / cpp_only filters
    if asm_only:
        source_files = [f for f in source_files if is_asm_file(f)]
    elif cpp_only:
        source_files = [f for f in source_files if is_cpp_file(f)]

    if not source_files:
        raise ValueError(
            "No source files remain after applying asm_only/cpp_only filter."
        )

    logger.info(
        "[Phase 1/3 DONE] Source file discovery — files=%d elapsed=%.1fs",
        len(source_files), time.monotonic() - _t,
    )
    print(f"Found {len(source_files)} source file(s).")

    # Phase 2/3 — Build variable universe
    logger.info("[Phase 2/3 START] Universe build — job=%s files=%d", job_id, len(source_files))
    _t = time.monotonic()
    builder = UniverseBuilder()
    builder.build(source_files)
    logger.info(
        "[Phase 2/3 DONE] Universe build — asm_vars=%d cpp_vars=%d elapsed=%.1fs",
        len(builder.asm_universe.get_variable_names()),
        len(builder.cpp_universe.get_variable_names()),
        time.monotonic() - _t,
    )

    # Phase 3/3 — Write output
    logger.info("[Phase 3/3 START] Write universe output — job=%s", job_id)
    _t = time.monotonic()
    builder.write_output(output_dir)
    result_files = ws.collect_output_files()
    if update_status:
        ws.set_status("success", result_files=result_files)
    logger.info(
        "[Phase 3/3 DONE] Universe complete — output_files=%d elapsed=%.1fs total_elapsed=%.1fs",
        len(result_files), time.monotonic() - _t, time.monotonic() - _task_start,
    )

    return {
        "job_id": ws.job_id,
        "status": "success",
        "asm_variables": len(builder.asm_universe.get_variable_names()),
        "cpp_variables": len(builder.cpp_universe.get_variable_names()),
        "output_files": len(result_files),
    }
