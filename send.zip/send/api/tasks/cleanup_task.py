"""Celery task: periodic cleanup of expired jobs."""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Dict

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.tasks.celery_app import celery_app
from api.storage.workspace import WorkspaceManager

logger = logging.getLogger(__name__)


@celery_app.task(name="asm.cleanup_expired")
def cleanup_expired_jobs() -> Dict[str, int]:
    """
    Remove all jobs whose creation timestamp is older than JOB_TTL_SECONDS.

    This task is triggered by the Celery beat scheduler every hour.
    Returns a dict with the count of deleted jobs.
    """
    logger.info("Running cleanup of expired jobs...")
    try:
        count = WorkspaceManager.cleanup_expired()
        logger.info("Cleanup complete: %d job(s) removed.", count)
        return {"deleted": count}
    except Exception as exc:
        logger.error("Cleanup task failed: %s", exc, exc_info=True)
        return {"deleted": 0, "error": str(exc)}
