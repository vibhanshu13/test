"""Process seed materialization — stub for the future cluster-finding pass.

Eventually a real method will analyse the call graph and cluster files into
named business processes (e.g. ``C400``, ``plastic_authentication``). Until
that exists, this module reads pre-built seed JSONs from ``PROCESS_SEEDS_DIR``
and copies them into the per-job output at::

    <ws.output_dir>/processes/<process>/{file_graph,headers,macros}.json

The public entry point is :func:`find_clusters_and_write`. Its signature and
output layout will not change when the real implementation lands — only the
body will be replaced.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Optional, Tuple

from api.config import settings
from api.storage.workspace import WorkspaceManager

PROCESSES: Tuple[str, ...] = ("C400", "plastic_authentication")
# Required seeds — pipeline fails if any are missing.
SHAPES: Tuple[str, ...] = ("file_graph.json", "headers.json", "macros.json")
# Optional companion files — copied if present, silently skipped if not.
# metadata.json drives the title/description/icon shown in the "+ New chat"
# picker. Process_seeds is a stub; this list is the right place for future
# optional artefacts (e.g. seed_summary.md) to slot in.
OPTIONAL_SHAPES: Tuple[str, ...] = ("metadata.json", "predefined_questions.json")


def _resolve_actual_source_path(ws: WorkspaceManager) -> Optional[str]:
    """Return the KB's actual source directory path, or None if not determinable."""
    try:
        opts = ws.get_pipeline_options() or {}
        src = opts.get("source_path")
        if src:
            return str(src).rstrip("/")
    except Exception:
        pass
    try:
        from api.db import SessionLocal
        from api.models.knowledge_base import KnowledgeBase
        db = SessionLocal()
        try:
            kb = db.query(KnowledgeBase).filter(KnowledgeBase.id == ws.job_id).first()
            if kb and kb.source_path:
                return str(kb.source_path).rstrip("/")
        finally:
            db.close()
    except Exception:
        pass
    return None


def _detect_placeholder(data: dict) -> Optional[str]:
    """Extract the placeholder dir prefix from a seed JSON (e.g. 'temp/asm')."""
    # file_graph.json uses seed_file; headers.json uses resolved_path entries
    seed_file = data.get("seed_file") or ""
    if not seed_file:
        for entry in data.get("headers_found") or []:
            seed_file = entry.get("resolved_path") or ""
            if seed_file:
                break
    if not seed_file or "/" not in seed_file:
        return None
    placeholder = str(Path(seed_file).parent)
    return placeholder if placeholder and placeholder != "." else None


def _rel_source(actual_source_path: str) -> str:
    """Convert actual_source_path to a path relative to the project root (if possible)."""
    project_root = settings.JOBS_BASE_DIR.parent
    try:
        return str(Path(actual_source_path).relative_to(project_root))
    except ValueError:
        return actual_source_path


def _patch_file_graph_paths(file_graph_path: Path, actual_source_path: str) -> None:
    """Replace the placeholder source prefix in file_graph.json with a relative path."""
    try:
        data = json.loads(file_graph_path.read_text(encoding="utf-8"))
    except Exception:
        return

    placeholder = _detect_placeholder(data)
    if not placeholder:
        return
    replacement = _rel_source(actual_source_path)
    if placeholder == replacement:
        return

    def _replace(val: str) -> str:
        if val.startswith(placeholder + "/"):
            return replacement + val[len(placeholder):]
        return val

    data["seed_file"] = _replace(data.get("seed_file", ""))
    data["files"] = [_replace(f) for f in (data.get("files") or [])]
    for edge in data.get("edges") or []:
        if "from_file" in edge:
            edge["from_file"] = _replace(edge["from_file"])
        if "to_file" in edge:
            edge["to_file"] = _replace(edge["to_file"])

    file_graph_path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _patch_headers_paths(headers_path: Path, actual_source_path: str) -> None:
    """Replace the placeholder source prefix in headers.json resolved_path fields."""
    try:
        data = json.loads(headers_path.read_text(encoding="utf-8"))
    except Exception:
        return

    placeholder = _detect_placeholder(data)
    if not placeholder:
        return
    replacement = _rel_source(actual_source_path)
    if placeholder == replacement:
        return

    def _replace(val: str) -> str:
        if val.startswith(placeholder + "/"):
            return replacement + val[len(placeholder):]
        return val

    for entry in data.get("headers_found") or []:
        if "resolved_path" in entry:
            entry["resolved_path"] = _replace(entry["resolved_path"])

    headers_path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def find_clusters_and_write(ws: WorkspaceManager) -> None:
    """Materialise the per-process seed JSONs into the job's output directory.

    Raises ``FileNotFoundError`` if any required source seed is missing.
    Optional shapes (e.g. metadata.json) are copied when present and silently
    skipped when absent — they should never block a pipeline run.
    """
    src_root: Path = settings.PROCESS_SEEDS_DIR
    dst_root: Path = ws.output_dir / "processes"
    dst_root.mkdir(parents=True, exist_ok=True)

    actual_source_path = _resolve_actual_source_path(ws)

    for process in PROCESSES:
        src_dir = src_root / process
        dst_dir = dst_root / process
        if not src_dir.is_dir():
            raise FileNotFoundError(
                f"process seed directory missing: {src_dir}. "
                f"Run `python data/processes/_generate_seeds.py` to (re)generate."
            )
        dst_dir.mkdir(parents=True, exist_ok=True)
        for name in SHAPES:
            src = src_dir / name
            if not src.is_file():
                raise FileNotFoundError(f"process seed file missing: {src}")
            shutil.copy2(src, dst_dir / name)
        # Rewrite seed file paths to use the KB's actual source directory.
        if actual_source_path:
            _patch_file_graph_paths(dst_dir / "file_graph.json", actual_source_path)
            _patch_headers_paths(dst_dir / "headers.json", actual_source_path)
        copied_optional = 0
        for name in OPTIONAL_SHAPES:
            src = src_dir / name
            if src.is_file():
                shutil.copy2(src, dst_dir / name)
                copied_optional += 1
        print(
            f"Wrote process seed: {dst_dir} "
            f"({len(SHAPES)} required + {copied_optional} optional files)"
        )
