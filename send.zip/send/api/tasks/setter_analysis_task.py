"""Celery task: build + explain ONE setter site (Setter Analysis).

Two phases over a resumable ``ChainlessBackwardSession``:

- Phase A (structural, fast): drive the chainless session to process exactly the
  requested root, pack the assembled structural tuple into the
  ``setter_analysis_structural`` row, and mark it ``active`` (the "structural
  done" signal the UI polls for).
- Phase B (eager prose): generate BOTH prose variants (business + technical) via
  ``explain_setter_root`` and cache each into ``setter_analysis_prose``; finally
  mark the structural row ``explained``.

Resumability: the chainless session checkpoints its own traversal (msgpack
chunks), and prose rows are per-variant — a fresh success row is skipped unless
``force`` is set, so a re-dispatch resumes cheaply.  DB progress writes are
throttled (only when the percentage advances by >= 2) to spare SQLite.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from api.tasks.celery_app import celery_app

logger = logging.getLogger(__name__)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _kb_updated_at(db, kb_id: str):
    try:
        from api.models.knowledge_base import KnowledgeBase
        kb = db.get(KnowledgeBase, kb_id)
        return kb.updated_at if kb else None
    except Exception:
        return None


def _get_or_create_structural(db, kb_id: str, variable: str, root_id: str):
    from api.models.setter_analysis import SetterAnalysisStructural
    row = (
        db.query(SetterAnalysisStructural)
        .filter_by(kb_id=kb_id, variable=variable, root_id=root_id)
        .one_or_none()
    )
    if row is None:
        row = SetterAnalysisStructural(
            kb_id=kb_id, variable=variable, root_id=root_id, status="pending"
        )
        db.add(row)
        db.flush()
    return row


def _get_or_create_prose(db, kb_id: str, variable: str, root_id: str, variant: str):
    from api.models.setter_analysis import SetterAnalysisProse
    row = (
        db.query(SetterAnalysisProse)
        .filter_by(kb_id=kb_id, variable=variable, root_id=root_id, prose_variant=variant)
        .one_or_none()
    )
    if row is None:
        row = SetterAnalysisProse(
            kb_id=kb_id, variable=variable, root_id=root_id, prose_variant=variant, status="running"
        )
        db.add(row)
        db.flush()
    return row


@celery_app.task(bind=True, name="asm.setter_analysis")
def run_setter_analysis(self, kb_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    """Trace + explain one setter site.

    options keys: session_id, root_id, variable, language (optional), force (bool).
    """
    from api.db import SessionLocal
    from api.tasks._output_compression import pack_blob
    from backward_traversal.runner.chainless_session import ChainlessBackwardSession
    from llm.setter_analysis_explainer import explain_setter_root_progressive, plan_llm_calls

    session_id = str(options["session_id"])
    root_id = str(options["root_id"])
    variable = str(options["variable"]).upper()
    force = bool(options.get("force", False))

    db = SessionLocal()
    try:
        kb_updated = _kb_updated_at(db, kb_id) or _utcnow()
        struct = _get_or_create_structural(db, kb_id, variable, root_id)

        # ---- Phase A: structural traversal (fast) ------------------------
        struct.session_id = session_id
        struct.status = "running"
        struct.progress = 5
        struct.progress_label = "Tracing setter & callers"
        struct.task_id = getattr(self.request, "id", "") or ""
        struct.error = None
        struct.kb_updated_at = kb_updated
        db.commit()

        sess = ChainlessBackwardSession.load(kb_id, session_id) if session_id else None
        if sess is None:
            # Session missing (cache cleared or stale session_id from frontend).
            # Self-heal: re-run discovery to recreate it, then use the fresh session.
            from api.tasks.chainless_lineage_task import _resolve_paths
            from api.routes.setter_analysis import _discover_session
            bpdir, graph, asm_dir, _out = _resolve_paths(kb_id)
            session_id, sess = _discover_session(kb_id, variable, None, bpdir, graph, asm_dir)
            struct.session_id = session_id
            db.commit()
        assembled = sess.process_root(root_id)
        structural = (assembled or {}).get("tuple", {}) or {}

        root_dict = sess._root_by_id(root_id) or {}
        struct.payload_gz = pack_blob(structural)
        struct.file_stem = str(root_dict.get("file_stem") or structural.get("node", {}).get("file_stem") or "")
        struct.file_type = str(root_dict.get("file_type") or structural.get("node", {}).get("file_type") or "asm")
        struct.line = int(root_dict.get("line") or structural.get("node", {}).get("line") or 0)
        struct.status = "active"
        struct.progress = 15
        struct.progress_label = "Conditions & callers mapped"
        db.commit()

        # ---- Phase B: eager prose, both variants -------------------------
        # Progress 0..15 is the structural phase; 15..100 is the LLM phase,
        # driven by ACTUAL LLM calls completed vs. total planned across BOTH
        # variants (business + technical).
        # Only the BUSINESS prose variant is LLM-generated. Technical mode renders
        # the structural tuple directly (no LLM) via build_structural_payload, and
        # business+references reuses the business prose with names overlaid.
        variants = [(True, "business")]
        per_variant = plan_llm_calls(structural, variable)
        total_calls = max(per_variant * len(variants), 2)  # guard against 0
        struct.llm_calls_total = total_calls
        struct.llm_calls_done = 0
        db.commit()

        completed_calls = {"n": 0}
        last_written = {"pct": -100}

        for business_mode, variant in variants:
            base_done = completed_calls["n"]
            prose = _get_or_create_prose(db, kb_id, variable, root_id, variant)
            # Resumable: skip a fresh success row unless force.
            if (
                not force
                and prose.status == "success"
                and prose.payload_gz
                and prose.kb_updated_at is not None
                and prose.kb_updated_at >= kb_updated
            ):
                logger.info("setter_analysis: %s/%s variant=%s already fresh — skip",
                            variable, root_id, variant)
                # Still advance progress so resumed runs report correctly.
                completed_calls["n"] += per_variant
                overall = min(99, 15 + round(completed_calls["n"] / total_calls * 85))
                struct.llm_calls_done = min(total_calls, completed_calls["n"])
                if overall - last_written["pct"] >= 2:
                    last_written["pct"] = overall
                    struct.progress = overall
                    struct.progress_label = f"Explaining ({variant}) — cached"
                db.commit()
                continue

            # RESUME: if this variant has a partial payload from a prior run that
            # was killed mid-generation (status 'running' with steps already
            # written), reuse those steps so we pick up from the last completed
            # band instead of restarting from step 0.
            resume_steps = None
            if prose.status == "running" and prose.payload_gz:
                try:
                    from api.tasks._output_compression import unpack_blob as _ub
                    prior = _ub(prose.payload_gz) or {}
                    resume_steps = prior.get("steps") or None
                    if resume_steps:
                        logger.info("setter_analysis: resuming %s/%s variant=%s from %d cached steps",
                                    variable, root_id, variant, len(resume_steps))
                except Exception:
                    resume_steps = None

            prose.status = "running"
            prose.error = None
            prose.kb_updated_at = kb_updated
            db.commit()

            struct.progress_label = f"Explaining ({variant})"
            db.commit()

            def _progress_cb(done: int, total: int, label: str,
                             _base_done=base_done, _last=last_written) -> None:
                global_done = _base_done + max(0, done)
                overall = min(99, 15 + round(global_done / total_calls * 85))
                if overall - _last["pct"] >= 2:
                    _last["pct"] = overall
                    try:
                        struct.progress = overall
                        struct.progress_label = f"Explaining ({variant}) — {label}"
                        struct.llm_calls_done = min(total_calls, global_done)
                        db.commit()
                    except Exception:
                        db.rollback()

            # Persist each partial band so the GET /analysis route can serve
            # readable content MID-generation. Runs on the MAIN thread (the
            # explainer guarantees on_band is never called off-thread).
            def _write_partial(partial_payload: Dict[str, Any], _prose=prose) -> None:
                try:
                    _prose.status = "running"
                    _prose.payload_gz = pack_blob(partial_payload)
                    _prose.kb_updated_at = kb_updated
                    db.commit()
                except Exception:
                    db.rollback()

            try:
                payload = explain_setter_root_progressive(
                    structural,
                    variable=variable,
                    root=root_dict,
                    business_mode=business_mode,
                    kb_id=kb_id,
                    on_band=_write_partial,
                    progress_cb=_progress_cb,
                    resume_steps=resume_steps,
                )
            except Exception as exc:
                logger.exception("setter_analysis prose (%s) failed", variant)
                prose.status = "failed"
                prose.error = str(exc)
                db.commit()
                raise

            prose.payload_gz = pack_blob(payload)
            prose.status = "success"
            prose.kb_updated_at = kb_updated
            completed_calls["n"] += per_variant
            struct.llm_calls_done = min(total_calls, completed_calls["n"])
            db.commit()

        # ---- Done --------------------------------------------------------
        struct.status = "explained"
        struct.progress = 100
        struct.progress_label = "Done"
        struct.llm_calls_done = struct.llm_calls_total
        db.commit()

        return {"status": "success", "kb_id": kb_id, "root_id": root_id, "variable": variable}

    except Exception as exc:
        logger.exception("setter_analysis task failed kb=%s root=%s var=%s", kb_id, root_id, variable)
        try:
            db.rollback()
            from api.models.setter_analysis import SetterAnalysisProse, SetterAnalysisStructural
            srow = (
                db.query(SetterAnalysisStructural)
                .filter_by(kb_id=kb_id, variable=variable, root_id=root_id)
                .one_or_none()
            )
            if srow is not None:
                srow.status = "failed"
                srow.error = str(exc)
            # Mark any in-flight prose row failed too.
            for prow in (
                db.query(SetterAnalysisProse)
                .filter_by(kb_id=kb_id, variable=variable, root_id=root_id, status="running")
                .all()
            ):
                prow.status = "failed"
                prow.error = str(exc)
            db.commit()
        except Exception:
            db.rollback()
        return {"status": "error", "error": str(exc), "kb_id": kb_id, "root_id": root_id, "variable": variable}
    finally:
        db.close()


@celery_app.task(bind=True, name="asm.setter_descriptions")
def run_setter_descriptions(self, kb_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    """Background: generate per-setter one-liner descriptions and DB-cache them.

    Runs OFF the discovery request path so "finding setters" never blocks on the
    ~30-40s batch LLM call.  Cached stably in ``SetterDescriptionCache`` per
    (kb, variable, prose_variant); discovery just reads that cache.

    options keys: variable, language (optional), business_mode (bool).
    """
    from api.db import SessionLocal
    from api.tasks._output_compression import pack_blob
    from api.models.setter_analysis import SetterDescriptionCache

    variable = str(options["variable"]).upper()
    language = options.get("language")
    business_mode = bool(options.get("business_mode", True))
    variant = "business" if business_mode else "technical"

    db = SessionLocal()
    try:
        kb_updated = _kb_updated_at(db, kb_id) or _utcnow()
        row = (
            db.query(SetterDescriptionCache)
            .filter_by(kb_id=kb_id, variable=variable, prose_variant=variant)
            .one_or_none()
        )
        if row is None:
            row = SetterDescriptionCache(kb_id=kb_id, variable=variable, prose_variant=variant)
            db.add(row)
        row.status = "pending"
        row.kb_updated_at = kb_updated
        row.error = None
        db.commit()

        # Re-discover the setter roots (cheap ~2s) — independent of any session id.
        from api.tasks.chainless_lineage_task import _resolve_paths
        from api.routes.setter_analysis import _discover_session, _generate_descriptions_llm, _sorted_roots
        bpdir, graph, asm_dir, _out = _resolve_paths(kb_id)
        _sid, sess = _discover_session(kb_id, variable, language, bpdir, graph, asm_dir)
        roots = _sorted_roots(list(sess._s.get("setter_roots", [])))

        descs = _generate_descriptions_llm(variable, roots, business_mode)

        row.payload_gz = pack_blob(descs)
        row.status = "ready"
        row.kb_updated_at = kb_updated
        db.commit()
        return {"status": "success", "kb_id": kb_id, "variable": variable,
                "variant": variant, "n": len(descs)}
    except Exception as exc:
        logger.exception("setter_descriptions task failed kb=%s var=%s", kb_id, variable)
        try:
            db.rollback()
            from api.models.setter_analysis import SetterDescriptionCache as _SDC
            r = (db.query(_SDC).filter_by(kb_id=kb_id, variable=variable, prose_variant=variant)
                 .one_or_none())
            if r is not None:
                r.status = "failed"
                r.error = str(exc)
                db.commit()
        except Exception:
            db.rollback()
        return {"status": "error", "error": str(exc), "kb_id": kb_id, "variable": variable}
    finally:
        db.close()
