"""Celery task: process-scoped variable connection graph.

Drives a `ChunkedBackwardSession` to completion (re-using the same machinery
as `process_lineage_chunked_task.py`), then walks every assembled tuple to
produce a flat `{nodes, edges}` graph and writes it to a per-process msgpack
file under exclusive file lock.

The new task is strictly additive: it never modifies an existing
`session.msgpack`, tuple JSON, or `file_call_graph.json` — it only reads them
and consumes the in-memory session state.
"""

from __future__ import annotations

import fcntl
import json
import logging
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.storage.workspace import WorkspaceManager
from api.tasks._task_utils import redirect_output_to_log, job_log_handler
from api.tasks.celery_app import celery_app
from api.processes.scope import (
    filter_tuple_to_scope,
    load_process_scope,
    materialize_filtered_graph,
    process_lineage_dir,
    session_file_for,
)
from backward_traversal.graph_extraction import build_variable_graph_from_tuples
from backward_traversal.enrichment.terminal_classifier import (
    classify_terminal_variables,
    extract_terminals_from_graph,
)

logger = logging.getLogger(__name__)

VARIABLE_GRAPH_FILENAME = "variable_graph.msgpack"

_OPTION_KEYS = (
    "max_depth", "max_subroutine_depth", "max_subroutine_nodes", "max_trace_nodes",
    "max_dep_vars", "max_dep_var_depth", "max_downstream_depth", "max_downstream_files",
    "t8_max_scan",
)


def variable_graph_msgpack_path(output_dir: Path, process_name: str) -> Path:
    return process_lineage_dir(output_dir, process_name) / VARIABLE_GRAPH_FILENAME


def read_variable_graph(
    output_dir: Path,
    process_name: str,
    root_variable: str,
    chain_hash: str,
) -> Optional[Dict[str, Any]]:
    """Look up a cached graph by (root_variable, chain_hash). Returns None if absent."""
    import msgpack
    path = variable_graph_msgpack_path(output_dir, process_name)
    if not path.exists():
        return None
    try:
        cache = msgpack.unpackb(path.read_bytes(), raw=False, strict_map_key=False)
    except Exception:
        return None
    if not isinstance(cache, dict):
        return None
    entry = cache.get(root_variable.upper()) or {}
    if not isinstance(entry, dict):
        return None
    graph = entry.get(chain_hash)
    if not isinstance(graph, dict):
        return None
    return graph


def write_variable_graph(
    output_dir: Path,
    process_name: str,
    root_variable: str,
    chain_hash: str,
    graph: Dict[str, Any],
) -> Path:
    """Merge a new (root_variable, chain_hash) entry into the per-process msgpack."""
    import msgpack
    path = variable_graph_msgpack_path(output_dir, process_name)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a+b") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        try:
            f.seek(0)
            content = f.read()
            cache: Dict[str, Any]
            if content:
                try:
                    cache = msgpack.unpackb(content, raw=False, strict_map_key=False)
                    if not isinstance(cache, dict):
                        cache = {}
                except Exception:
                    cache = {}
            else:
                cache = {}
            root_key = root_variable.upper()
            per_var = cache.get(root_key)
            if not isinstance(per_var, dict):
                per_var = {}
            per_var[chain_hash] = graph
            cache[root_key] = per_var
            payload = msgpack.packb(cache, use_bin_type=True)
            f.seek(0)
            f.truncate()
            f.write(payload)
        finally:
            fcntl.flock(f, fcntl.LOCK_UN)
    return path


@celery_app.task(bind=True, name="asm.variable_graph")
def run_variable_graph(self, job_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    """Build a process-scoped variable connection graph and persist it."""
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run(ws, options)
            except SoftTimeLimitExceeded:
                msg = "Variable graph task exceeded soft time limit and was aborted."
                logger.error("Job %s: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s variable-graph failed: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}


def _run(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    from backward_traversal.runner.chunked_session import ChunkedBackwardSession

    job_id = ws.job_id
    _task_start = time.monotonic()

    process_name = str(options["process_name"])
    session_id = str(options["session_id"])
    chain_hash = str(options["chain_hash"])
    variable = str(options["variable_name"])
    selected_chain: List[str] = list(options["chain_files"])

    logger.info(
        "[Variable Graph Phase 1/3] Resolve — job=%s process=%s var=%s session=%s",
        job_id, process_name, variable, session_id,
    )
    _t = time.monotonic()

    kb_output = ws.output_dir
    if not kb_output.exists():
        raise FileNotFoundError(f"Output directory not found: {kb_output}")

    process_dir = kb_output / "processes" / process_name
    if not process_dir.is_dir():
        raise FileNotFoundError(f"Process seed dir missing: {process_dir}")

    from api.tasks._task_utils import resolve_graph_file
    global_graph = resolve_graph_file(kb_output, job_id)

    scope = load_process_scope(process_dir, process_name)
    graph_file = materialize_filtered_graph(kb_output, process_name, scope, global_graph)

    asm_dir = _resolve_asm_dir(kb_output, options, ws)
    blueprint_dir = _resolve_blueprint_dir(kb_output)

    session_file = session_file_for(kb_output, process_name, session_id)
    session_directory = session_file.parent
    session_directory.mkdir(parents=True, exist_ok=True)
    logger.info(
        "[Variable Graph Phase 1/3 DONE] elapsed=%.1fs",
        time.monotonic() - _t,
    )

    logger.info(
        "[Variable Graph Phase 2/3] Driving session to completion — session=%s",
        session_id,
    )
    _t = time.monotonic()
    session = ChunkedBackwardSession.load(job_id, session_id, session_file=session_file)
    if session is None:
        session = ChunkedBackwardSession.new(
            session_id=session_id,
            kb_id=job_id,
            variable=variable,
            selected_chain=selected_chain,
            options={k: options.get(k) for k in _OPTION_KEYS},
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            graph_file=graph_file,
        )

    # Drive the session forward one tuple at a time until completion. We do not
    # touch the existing chunked output JSONs — only the in-memory state and
    # the per-tuple chunk files inside session_directory.
    safety_iters = 0
    safety_cap = 200_000  # absurdly high; only here to prevent infinite loops on bugs
    while not session.is_complete:
        target_index = len(session.tuple_index_map)
        session.process_until_tuple(target_index, session_directory)
        safety_iters += 1
        if safety_iters > safety_cap:
            session._s["warnings"].append(
                "variable_graph: safety iteration cap reached; aborting drive loop"
            )
            break

    session.save(job_id, session_id, session_file=session_file)
    logger.info(
        "[Variable Graph Phase 2/3 DONE] tuples=%d complete=%s elapsed=%.1fs",
        len(session.tuple_index_map), session.is_complete, time.monotonic() - _t,
    )

    logger.info(
        "[Variable Graph Phase 3/3] Assemble + extract graph — tuples=%d",
        len(session.tuple_index_map),
    )
    _t = time.monotonic()

    tuples: List[Dict[str, Any]] = []
    for idx in range(len(session.tuple_index_map)):
        try:
            tup = session.assemble_tuple(idx, session_directory)
        except FileNotFoundError as exc:
            logger.warning("variable_graph: tuple %d missing chunk file: %s", idx, exc)
            continue
        if tup is None:
            continue
        scoped = filter_tuple_to_scope(tup, scope)
        tuples.append(scoped)

    caps = {k: options.get(k) for k in _OPTION_KEYS}
    graph = build_variable_graph_from_tuples(
        tuples,
        scope_files=list(scope.files or ()),
        root_variable=variable,
        chain_files=selected_chain,
        chain_hash=chain_hash,
        caps=caps,
        warnings=session.warnings,
    )

    # Classify terminal (leaf) nodes — non-fatal if it fails
    try:
        leaf_vars = extract_terminals_from_graph(graph)
        if leaf_vars:
            tc = classify_terminal_variables(
                leaf_vars, blueprint_dir, asm_dir, graph_file, use_llm=False
            )
            if tc:
                terminal_roles_map = {rec["variable"]: rec for rec in tc}
                # Re-build graph with terminal_roles so leaf nodes are annotated
                graph = build_variable_graph_from_tuples(
                    tuples,
                    scope_files=list(scope.files or ()),
                    root_variable=variable,
                    chain_files=selected_chain,
                    chain_hash=chain_hash,
                    caps=caps,
                    warnings=session.warnings,
                    terminal_roles=terminal_roles_map,
                )
    except Exception as _tc_err:
        logger.warning("variable_graph: terminal classification failed (non-fatal): %s", _tc_err)

    msgpack_path = write_variable_graph(kb_output, process_name, variable, chain_hash, graph)

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)
    logger.info(
        "[Variable Graph Phase 3/3 DONE] nodes=%d edges=%d elapsed=%.1fs total=%.1fs",
        graph.get("node_count", 0), graph.get("edge_count", 0),
        time.monotonic() - _t, time.monotonic() - _task_start,
    )

    rel_output = msgpack_path.relative_to(ws.output_dir).as_posix()
    return {
        "job_id": job_id,
        "process": process_name,
        "status": "success",
        "root_variable": variable.upper(),
        "chain_hash": chain_hash,
        "session_id": session_id,
        "node_count": graph.get("node_count", 0),
        "edge_count": graph.get("edge_count", 0),
        "output_file": rel_output,
    }


def _resolve_blueprint_dir(kb_output: Path) -> Path:
    from api.tasks._task_utils import find_blueprint_dir
    d = find_blueprint_dir(kb_output)
    if d is None:
        raise FileNotFoundError(f"No .asm.json blueprint files found under {kb_output}")
    return d


def _resolve_asm_dir(kb_output: Path, options: Dict[str, Any], ws: WorkspaceManager) -> Optional[Path]:
    if options.get("asm_dir"):
        p = Path(str(options["asm_dir"]))
        if p.exists():
            return p
    try:
        pipeline_opts = ws.get_pipeline_options() or {}
        src = pipeline_opts.get("source_path")
        if src:
            p = Path(str(src))
            if p.exists():
                return p
    except Exception:
        pass
    return None
