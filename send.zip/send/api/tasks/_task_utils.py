"""Shared utilities used by all Celery task modules."""

from __future__ import annotations

import io
import logging
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional, Tuple

logger = logging.getLogger(__name__)


@contextmanager
def job_log_handler(log_path: Path, job_id: str = "") -> Generator[None, None, None]:
    """Attach a per-job FileHandler to root logger for the duration of a task.

    Writes structured ``logger.*`` lines (timestamp | level | module | message)
    to *log_path* in addition to the shared rotating file and the console.
    The handler is removed from the root logger in the finally block so it
    does not leak into subsequent tasks running in the same worker process.

    This is used together with ``redirect_output_to_log`` — both open the same
    *log_path* in append mode.  Linux O_APPEND writes are atomic for lines
    under 4096 bytes so there is no interleaving corruption.
    """
    from api.logging_config import LOG_FORMAT, LOG_DATE_FORMAT

    log_path.parent.mkdir(parents=True, exist_ok=True)
    handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")
    handler.setFormatter(logging.Formatter(fmt=LOG_FORMAT, datefmt=LOG_DATE_FORMAT))
    root = logging.getLogger()
    root.addHandler(handler)
    try:
        yield
    finally:
        root.removeHandler(handler)
        try:
            handler.close()
        except Exception:
            pass


def compute_chain_hop_conditions(
    chains: List[Dict[str, Any]],
    blueprint_dir: Path,
    asm_dir: Optional[Path] = None,
    max_depth: int = 10,
    max_total: int = 30,
) -> Dict[Tuple[str, str], List[Dict[str, Any]]]:
    """For every unique (from, to) pair across `chains`, invoke
    `compute_call_conditions` once and return a dict keyed by the pair.

    `chains[i]` is expected to have a `hops` list of dicts with `from` and
    `to` keys (the shape produced by `_build_root_chains` in
    `api/tasks/kb_chain_summaries_task.py`).

    A failure on any single pair is logged and stored as an empty list — one
    bad pair must not kill the precompute for the rest of the graph.
    """
    from get_call_conditions import compute_call_conditions  # local import: heavy module

    pairs: set[Tuple[str, str]] = set()
    for chain in chains or []:
        for hop in chain.get("hops") or []:
            frm = hop.get("from")
            to = hop.get("to")
            if frm and to:
                pairs.add((str(frm), str(to)))

    out: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    for frm, to in sorted(pairs):
        try:
            result = compute_call_conditions(
                caller_stem=frm,
                callee_stem=to,
                blueprint_dir=blueprint_dir,
                asm_dir=asm_dir,
                max_depth=max_depth,
                max_total=max_total,
            )
            out[(frm, to)] = result.get("call_sites") or []
        except Exception as exc:
            logger.warning(
                "compute_call_conditions failed for %s -> %s: %s", frm, to, exc,
            )
            out[(frm, to)] = []
    return out


def resolve_graph_file(kb_output: Path, kb_id: str) -> Path:
    """Return a valid path to file_call_graph.json for *kb_id*.

    The pipeline ingests file_call_graph.json into the index DB and then deletes
    the JSON file to save disk space.  When the file is absent, this function
    reconstructs it from the DB and writes it to ``kb_output/.file_call_graph_cache.json``
    so the caller can treat it as a regular file.

    Raises ``FileNotFoundError`` if the graph cannot be obtained from disk or DB.
    """
    import json as _json

    graph_file = kb_output / "file_call_graph.json"
    if graph_file.exists():
        return graph_file

    # File was deleted after DB ingestion — reconstruct from index DB.
    try:
        from api.index_db.readers import get_call_graph
        graph = get_call_graph(kb_id, fallback_path=graph_file)
    except Exception as exc:
        raise FileNotFoundError(
            f"file_call_graph.json not found and DB reconstruction failed: {exc}"
        ) from exc

    if not graph.get("nodes"):
        raise FileNotFoundError(
            f"file_call_graph.json not found in KB output and index DB has no call-graph "
            f"data for job {kb_id}: {graph_file}"
        )

    cache_file = kb_output / ".file_call_graph_cache.json"
    cache_file.write_text(_json.dumps(graph), encoding="utf-8")
    logger.info(
        "[resolve_graph_file] Reconstructed call graph from DB → %s (%d nodes, %d edges)",
        cache_file, len(graph.get("nodes", [])), len(graph.get("edges", [])),
    )
    return cache_file


def _has_blueprint(d: Path) -> bool:
    """True if *d* holds any blueprint — ASM (.asm.json/.mac.json) OR C++ (.cpp.json).

    A "blueprint dir" is language-agnostic: a C++-only project produces only
    .cpp.json, so matching .asm.json alone wrongly skipped the call graph,
    modifier/identity indexes, and the chainless bootstrap for pure-C++ KBs.
    """
    return any(next(d.glob(f"*{suf}"), None) for suf in (".asm.json", ".cpp.json", ".mac.json"))


def find_blueprint_dir(output_dir: Path) -> Optional[Path]:
    """Return the directory inside *output_dir* that holds blueprints.

    Recognises ASM (.asm.json/.mac.json) AND C++ (.cpp.json) blueprints.

    Search order (first match wins):
    1. output_dir/asm/  — explicit sub-directory (legacy named layout)
    2. output_dir/      — files extracted flat at the root
    3. Any immediate child directory of output_dir that contains blueprints
       (handles zip uploads where the archive contains a named folder, e.g.
       my_project.zip → asm_1400/ → da76.asm, so blueprints land in
       output_dir/asm_1400/*.asm.json instead of output_dir/*.asm.json)

    Returns None if no blueprints are found anywhere.
    """
    # Fast paths: named sub-directory and flat root layout
    for candidate in (output_dir / "asm", output_dir):
        if candidate.is_dir() and _has_blueprint(candidate):
            return candidate
    # Fallback: single-level subdirectory scan for zip-with-subfolder uploads
    try:
        for subdir in sorted(output_dir.iterdir()):
            if subdir.is_dir() and _has_blueprint(subdir):
                return subdir
    except (OSError, PermissionError):
        pass
    return None


@contextmanager
def redirect_output_to_log(log_path: Path) -> Generator[None, None, None]:
    """
    Context manager that tees both stdout and stderr to *log_path*.

    All print() calls and sys.stdout / sys.stderr writes made inside
    the ``with`` block are captured and written to the log file in
    addition to the normal streams so operators can inspect task output
    without attaching to the worker process.
    """
    log_path.parent.mkdir(parents=True, exist_ok=True)
    original_stdout = sys.stdout
    original_stderr = sys.stderr

    # Use unbuffered writes so the log is usable while the task runs.
    log_file = open(log_path, "a", encoding="utf-8", buffering=1)

    class _Tee(io.TextIOBase):
        def __init__(self, original, log):
            self._original = original
            self._log = log

        def write(self, text: str) -> int:
            self._original.write(text)
            try:
                self._log.write(text)
                # Explicit flush after every write so log output is visible in
                # real time even when the text does not end with a newline
                # (e.g. progress bars, partial lines).  buffering=1 only
                # flushes on newlines, leaving those writes invisible until
                # the next newline or file close.
                self._log.flush()
            except Exception:
                pass
            return len(text)

        def flush(self) -> None:
            self._original.flush()
            try:
                self._log.flush()
            except Exception:
                pass

        # Delegate isatty / fileno so libraries that check them don't crash.
        def isatty(self) -> bool:
            return False

    tee_out = _Tee(original_stdout, log_file)
    tee_err = _Tee(original_stderr, log_file)

    sys.stdout = tee_out  # type: ignore[assignment]
    sys.stderr = tee_err  # type: ignore[assignment]
    try:
        yield
    finally:
        sys.stdout = original_stdout
        sys.stderr = original_stderr
        try:
            log_file.close()
        except Exception:
            pass
