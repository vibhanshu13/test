"""Celery task: build a chainless value+condition lineage in the background.

Deep lineages are heavy (cross-file, cross-language, recursive), so they run as
a background job and the result is written to the job store; the API dispatches
this task and polls for completion (the synchronous endpoint stays for shallow,
bounded depth).  Reuses the existing `backward_traversal` components — no chain
path, no re-derivation.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, Optional

from api.tasks.celery_app import celery_app

logger = logging.getLogger(__name__)


def _slug(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(name))[:120] or "var"


def _resolve_paths(kb_id: str):
    """blueprint_dir / graph_file / asm_dir for a project (no request context)."""
    from api.config import settings
    from api.tasks._task_utils import find_blueprint_dir, resolve_graph_file

    out = settings.JOBS_BASE_DIR / kb_id / "output"
    bpdir = find_blueprint_dir(out) or out
    graph = resolve_graph_file(out, kb_id)
    asm_dir: Optional[Path] = None
    try:
        from api.storage.workspace import WorkspaceManager
        opts = WorkspaceManager(kb_id).get_pipeline_options() or {}
        sp = opts.get("source_path")
        if sp and Path(sp).exists():
            asm_dir = Path(sp)
    except Exception:
        pass
    return Path(bpdir), Path(graph), asm_dir, out


def _output_path(out_dir: Path, variable: str, options: Dict[str, Any]) -> Path:
    d = out_dir / "chainless_lineage"
    d.mkdir(parents=True, exist_ok=True)
    key = f"{_slug(variable)}_d{options.get('max_depth', 3)}_c{options.get('max_caller_depth', 2)}"
    return d / f"{key}.json"


def build_and_store(kb_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    """Pure worker body (callable directly in tests, or from the Celery task)."""
    from backward_traversal.runner.chainless_lineage_tree import (
        build_lineage, enrich_for_explainability, flatten_summary,
    )

    variable = options["variable"]
    bpdir, graph, asm_dir, out = _resolve_paths(kb_id)
    out_path = _output_path(out, variable, options)

    # Idempotent: a completed identical result is reused.
    if out_path.exists():
        try:
            cached = json.loads(out_path.read_text(encoding="utf-8"))
            return {"status": "success", "variable": variable, "cached": True,
                    "output": str(out_path), "summary": cached.get("summary", {})}
        except Exception:
            pass

    tree = build_lineage(
        variable, bpdir, graph, job_id=kb_id, asm_dir=asm_dir,
        max_depth=int(options.get("max_depth", 3)),
        max_caller_depth=int(options.get("max_caller_depth", 2)),
    )
    explain = enrich_for_explainability(tree, bpdir, graph, asm_dir=asm_dir, job_id=kb_id)
    summary = flatten_summary(tree)
    payload = {"variable": variable, "kb_id": kb_id, "options": options,
               "summary": summary, "lineage": explain}
    tmp = out_path.with_suffix(out_path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, default=str), encoding="utf-8")
    tmp.replace(out_path)   # atomic
    return {"status": "success", "variable": variable, "cached": False,
            "output": str(out_path), "summary": summary}


@celery_app.task(bind=True, name="asm.chainless_lineage")
def run_chainless_lineage(self, kb_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    try:
        return build_and_store(kb_id, options)
    except Exception as exc:  # pragma: no cover
        logger.exception("chainless_lineage task failed for kb=%s var=%s", kb_id, options.get("variable"))
        return {"status": "error", "error": str(exc), "variable": options.get("variable")}


@celery_app.task(bind=True, name="asm.keyword_file_flow")
def run_keyword_file_flow(self, kb_id: str, conv_id: str, variable: str) -> Dict[str, Any]:
    """Background Celery task for keyword-file-flow (CO-3).

    Computes the modifier chains for *variable* and writes the result back to
    the conversation msgpack.  The HTTP endpoint dispatches this task and polls
    via GET /keyword-file-flow/jobs/{task_id}.
    """
    try:
        from api.routes.conversations import _find_file_flows, _output_dir, _load_conv, _save_conv
        import uuid
        from datetime import datetime, timezone

        flows_raw, _modifier_index = _find_file_flows(kb_id, variable)
        now = datetime.now(timezone.utc).isoformat()

        # Write results back to the conversation.
        conv = _load_conv(kb_id, conv_id)
        if conv is None:
            return {"status": "error", "error": f"conversation {conv_id} not found"}

        flows_stored = sorted(
            [{"id": str(uuid.uuid4()), "chain": f["chain"], "modifier_file": f["modifier_file"]}
             for f in flows_raw],
            key=lambda f: len(f.get("chain") or []),
        )
        conv["keyword"] = variable
        conv["keyword_file_flows"] = flows_stored
        conv["updated_at"] = now
        _save_conv(kb_id, conv)

        return {
            "status": "success",
            "variable": variable,
            "conv_id": conv_id,
            "total_flows": len(flows_stored),
        }
    except Exception as exc:
        logger.exception("keyword_file_flow task failed kb=%s conv=%s var=%s", kb_id, conv_id, variable)
        return {"status": "error", "error": str(exc), "variable": variable}


@celery_app.task(bind=True, name="asm.chainless_forest")
def run_chainless_forest(self, kb_id: str, session_id: str, workers: int = 0) -> Dict[str, Any]:
    """Process every setter root in a chainless session, in parallel.

    Roots are independent — each is traced with its own visited sets so the
    ThreadPoolExecutor in process_all() can run them safely side-by-side.
    """
    try:
        from backward_traversal.runner.chainless_session import ChainlessBackwardSession
        sess = ChainlessBackwardSession.load(kb_id, session_id)
        if sess is None:
            return {"status": "error", "error": f"session {session_id} not found"}
        sess.process_all(workers=workers)
        return {
            "status": "success",
            "session_id": session_id,
            "is_complete": sess.is_complete,
            "total_tuples": sess.total_tuples,
        }
    except Exception as exc:
        logger.exception("chainless_forest task failed kb=%s session=%s", kb_id, session_id)
        return {"status": "error", "error": str(exc), "session_id": session_id}
