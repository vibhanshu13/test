"""Celery application factory and configuration."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

from celery import Celery
from celery.schedules import crontab
from celery.signals import (
    after_setup_logger,
    task_failure,
    task_revoked,
    worker_init,
    worker_process_init,
)

from api.config import settings

_log = logging.getLogger(__name__)

# Resolved project root — contains universe_builder.py, main.py, etc.
_PROJECT_ROOT = str(Path(__file__).parents[2].resolve())


def _ensure_project_root_on_path() -> None:
    """Insert the project root into sys.path if it isn't there already."""
    if _PROJECT_ROOT not in sys.path:
        sys.path.insert(0, _PROJECT_ROOT)


# Called in the main process (covers non-prefork pools and the beat scheduler)
_ensure_project_root_on_path()


# Called once in the main worker process (covers non-prefork pools and the
# beat scheduler).  Idempotent — safe to call multiple times.
@worker_init.connect
def _worker_init_logging(**_kwargs: object) -> None:
    from api.logging_config import configure_logging
    configure_logging()


# Called in EACH forked worker child process — guarantees the path survives
# Celery's prefork pool initialisation.
@worker_process_init.connect
def _worker_process_init_handler(**_kwargs: object) -> None:
    _ensure_project_root_on_path()
    from api.logging_config import configure_logging
    configure_logging()


# Celery overrides the root logger after worker_init / worker_process_init,
# stripping any handlers we added.  after_setup_root_logger fires AFTER Celery
# finishes its own logging setup, so we can safely add our RotatingFileHandler
# here without it being torn down again.
@after_setup_logger.connect
def _after_setup_root_logger(logger, **_kwargs: object) -> None:
    import logging.handlers
    from pathlib import Path
    from api.logging_config import LOG_FORMAT, LOG_DATE_FORMAT

    log_dir = Path("/var/asm-logs")
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / "asm.log"
        # Avoid adding a duplicate handler if this signal fires more than once.
        if any(
            isinstance(h, logging.handlers.RotatingFileHandler)
            and getattr(h, "baseFilename", None) == str(log_path)
            for h in logger.handlers
        ):
            return
        fh = logging.handlers.RotatingFileHandler(
            log_path, maxBytes=50 * 1024 * 1024, backupCount=5, encoding="utf-8",
        )
        fh.setFormatter(logging.Formatter(fmt=LOG_FORMAT, datefmt=LOG_DATE_FORMAT))
        logger.addHandler(fh)
    except OSError:
        pass

celery_app = Celery(
    "asm_modernizer",
    include=[
        "api.tasks.analysis_task",
        "api.tasks.universe_task",
        "api.tasks.lineage_task",
        "api.tasks.modifiers_task",
        "api.tasks.callgraph_task",
        "api.tasks.pipeline_task",
        "api.tasks.kb_modifiers_task",
        "api.tasks.kb_chain_summaries_task",
        "api.tasks.kb_file_summaries_task",
        "api.tasks.kb_backward_lineage_task",
        "api.tasks.kb_backward_lineage_chunked_task",
        "api.tasks.kb_backward_lineage_cotrack_task",
        "api.tasks.kb_lineage_explanation_task",
        "api.tasks.process_lineage_chunked_task",
        "api.tasks.variable_graph_task",
        "api.tasks.cleanup_task",
        "api.tasks.variable_usage_task",
        "api.tasks.variable_usage_batch_task",
        "api.tasks.chainless_lineage_task",
        "api.tasks.setter_analysis_task",
        "api.tasks.chain_setter_analysis_task",
    ],
)

celery_app.conf.update(
    broker_url=settings.CELERY_BROKER_URL,
    result_backend=settings.CELERY_RESULT_BACKEND,
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    task_track_started=True,
    result_expires=86400,
    task_time_limit=settings.TASK_TIME_LIMIT,
    task_soft_time_limit=settings.TASK_SOFT_TIME_LIMIT,

    # Recycle each worker process after this many tasks so that accumulated
    # heap memory (Python doesn't always return it to the OS) is released.
    worker_max_tasks_per_child=settings.WORKER_MAX_TASKS_PER_CHILD,

    # Hard memory cap per worker (KB).  Celery sends SIGTERM to a worker that
    # exceeds this limit and starts a fresh replacement, preventing OOM kills.
    worker_max_memory_per_child=settings.WORKER_MAX_MEMORY_MB * 1024,

    # Prevent workers from pre-fetching more than one task at a time.
    # Default is 4; for long-running, memory-heavy pipeline tasks this causes
    # a single worker to hold multiple 6+ GB jobs simultaneously, exhausting RAM.
    worker_prefetch_multiplier=1,

    # Route the quick, latency-sensitive Setter-Analysis description job to a
    # dedicated "quick" queue so it never waits behind the long (~6 min)
    # asm.setter_analysis jobs on the default queue.  Run a small worker with
    # `-Q quick` to service it.
    task_routes={
        "asm.setter_descriptions": {"queue": "quick"},
    },

    beat_schedule={
        "cleanup-expired-jobs": {
            "task": "asm.cleanup_expired",
            "schedule": crontab(minute=0),
        },
    },
    timezone="UTC",
)

_log.info(
    "[celery_app] Resource limits — concurrency: %d, max_memory_per_child: %d MB, "
    "max_tasks_per_child: %d, task_time_limit: %d s, analysis_workers: %d",
    settings.CELERY_CONCURRENCY,
    settings.WORKER_MAX_MEMORY_MB,
    settings.WORKER_MAX_TASKS_PER_CHILD,
    settings.TASK_TIME_LIMIT,
    settings.ANALYSIS_WORKERS,
)


# ---------------------------------------------------------------------------
# Celery signal handlers — auto-mark jobs failed on unexpected worker death
# ---------------------------------------------------------------------------

def _extract_job_id(args: tuple, kwargs: dict) -> str | None:
    """Extract job_id from task call signature (first positional arg or kwarg)."""
    if kwargs.get("job_id"):
        return kwargs["job_id"]
    if args:
        return str(args[0])
    return None


@task_failure.connect
def _on_task_failure(sender=None, task_id=None, exception=None,
                     args=None, kwargs=None, **kw) -> None:
    """Mark the job 'failed' in Redis when Celery reports an unhandled exception.

    This handles the case where a worker is killed by OOM (SIGKILL) or the
    hard time limit fires — the task exception handler in analysis_task.py
    never runs, so the job stays stuck in 'running' forever without this hook.
    """
    job_id = _extract_job_id(args or (), kwargs or {})
    if not job_id:
        return
    try:
        from api.storage.workspace import WorkspaceManager
        ws = WorkspaceManager(job_id)
        meta = ws.get_job_meta()
        if meta and meta.get("status") in ("running", "pending"):
            ws.set_status(
                "failed",
                error=f"{type(exception).__name__}: {exception}",
            )
            _log.error(
                "[celery signal] task_failure: job %s marked failed — %s: %s",
                job_id, type(exception).__name__, exception,
            )
    except Exception as exc:
        _log.error("[celery signal] task_failure handler error for job %s: %s", job_id, exc)


@task_revoked.connect
def _on_task_revoked(sender=None, request=None, terminated=None,
                     signum=None, expired=None, **kw) -> None:
    """Mark the job 'failed' when a task is revoked (timed out, manually cancelled).

    Celery sends SIGTERM to the worker when TASK_SOFT_TIME_LIMIT fires; if
    the worker doesn't exit quickly enough Celery sends SIGKILL and the
    task_failure signal does not fire.  This hook ensures both cases are covered.
    """
    if request is None:
        return
    args = getattr(request, "args", ()) or ()
    kwargs = getattr(request, "kwargs", {}) or {}
    job_id = _extract_job_id(args, kwargs)
    if not job_id:
        return
    try:
        from api.storage.workspace import WorkspaceManager
        ws = WorkspaceManager(job_id)
        meta = ws.get_job_meta()
        if meta and meta.get("status") in ("running", "pending"):
            reason = (
                "Task timed out (hard limit exceeded)"
                if expired
                else f"Task revoked (terminated={terminated}, signum={signum})"
            )
            ws.set_status("failed", error=reason)
            _log.warning(
                "[celery signal] task_revoked: job %s marked failed — %s",
                job_id, reason,
            )
    except Exception as exc:
        _log.error("[celery signal] task_revoked handler error for job %s: %s", job_id, exc)
