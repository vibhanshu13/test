"""Celery task: cross-file variable lineage tracing (trace_cross_file_lineage.py equivalent).

IMPORTANT: This task does NOT call input() — chain_index is always provided
as a parameter and passed directly to the tracing logic.
"""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.tasks.celery_app import celery_app
from api.tasks._task_utils import redirect_output_to_log
from api.storage.workspace import WorkspaceManager

logger = logging.getLogger(__name__)


@celery_app.task(
    bind=True,
    name="asm.cross_file_lineage",
)
def run_cross_file_lineage(self, job_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    """
    Trace cross-file variable lineage from uploaded blueprint files.

    Requires the job's input directory to contain pre-generated blueprint
    (.asm.json / .cpp.json) files and a file_call_graph.json.

    The chain is selected non-interactively using ``options["chain_index"]``.
    """
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        try:
            return _run_lineage(ws, options)
        except SoftTimeLimitExceeded:
            error_msg = "Task exceeded soft time limit and was aborted."
            logger.error("Job %s: %s", job_id, error_msg)
            ws.set_status("failed", error=error_msg)
            return {"job_id": job_id, "status": "failed", "error": error_msg}
        except Exception as exc:
            error_msg = f"{type(exc).__name__}: {exc}"
            logger.exception("Job %s failed: %s", job_id, error_msg)
            ws.set_status("failed", error=error_msg)
            return {"job_id": job_id, "status": "failed", "error": error_msg}


def _run_lineage(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    """Core lineage tracing logic — no interactive input()."""
    from find_variable_modifiers import scan_blueprint_for_setters, find_chains_through
    from trace_cross_file_lineage import (
        deduplicate_chains,
        _classify_edge,
        _trace_modifier_asm,
        _trace_asm_upstream,
        _trace_cpp_upstream,
        _trace_downstream_file,
        _extract_dep_var_contexts,
        _trace_dep_var_levels,
        _collect_register_dep_vars,
        _discover_graph_file,
    )
    from cross_file_bridge import _discover_blueprint_dir, _discover_asm_dir
    from trace_lineage import LineageTracer
    from forward_trace_lineage import ForwardLineageTracer
    from trace_cpp_function_lineage import (
        build_indexes,
        build_owner_index,
        discover_cpp_blueprints,
        discover_asm_stems,
    )
    from cross_file_bridge import find_cpp_to_cpp_callers, find_asm_to_cpp_callers

    variable: str = options["variable_name"]
    chain_index: int = int(options.get("chain_index", 0))
    max_depth: Optional[int] = options.get("max_depth")
    dep_depth: int = int(options.get("dep_depth", 2)) if options.get("dep_depth") is not None else 2

    input_dir = ws.input_dir
    output_dir = ws.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Resolve blueprint directory from input — the caller is expected to
    # upload either blueprint files directly into input/ or in a subdir.
    # We search for any .asm.json files to locate the blueprint directory.
    # ------------------------------------------------------------------
    blueprint_dir: Optional[Path] = None
    asm_json_files = list(input_dir.rglob("*.asm.json"))
    if asm_json_files:
        blueprint_dir = asm_json_files[0].parent
    else:
        blueprint_dir = input_dir

    asm_dir: Optional[Path] = None
    asm_files = list(input_dir.rglob("*.asm"))
    if asm_files:
        asm_dir = asm_files[0].parent

    # Prefer explicit overrides from options
    if options.get("blueprint_dir") and options["blueprint_dir"] != ".":
        candidate = Path(options["blueprint_dir"])
        if candidate.exists():
            blueprint_dir = candidate

    if options.get("graph_file"):
        graph_file_path: Optional[Path] = Path(options["graph_file"])
    else:
        graph_file_path = _discover_graph_file(blueprint_dir)
        if graph_file_path is None:
            # Fall back to looking inside the input directory
            for candidate_name in ["file_call_graph.json"]:
                for p in input_dir.rglob(candidate_name):
                    graph_file_path = p
                    break
                if graph_file_path:
                    break

    if graph_file_path is None or not graph_file_path.exists():
        raise FileNotFoundError(
            "Cannot find file_call_graph.json. "
            "Include it in the uploaded files or set graph_file in options."
        )

    graph_payload: Dict[str, Any] = json.loads(
        graph_file_path.read_text(encoding="utf-8")
    )
    file_type_map: Dict[str, str] = {
        n["id"]: n.get("type", "asm") for n in graph_payload.get("nodes", [])
    }
    edge_type_map: Dict = {
        (e["source"], e["target"]): (e.get("instructions") or ["?"])[0]
        for e in graph_payload.get("edges", [])
    }

    # ------------------------------------------------------------------
    # Discover modifier files
    # ------------------------------------------------------------------
    blueprint_files = sorted(
        list(blueprint_dir.glob("*.asm.json"))
        + list(blueprint_dir.glob("*.mac.json"))
    )
    if not blueprint_files:
        raise FileNotFoundError(
            f"No .asm.json / .mac.json files found in {blueprint_dir}. "
            "Upload blueprint files to the job input directory."
        )

    warnings: List[str] = []
    setter_hits: Dict[str, List[Dict[str, Any]]] = {}
    for bp_path in blueprint_files:
        hits, err = scan_blueprint_for_setters(bp_path, variable)
        if err:
            warnings.append(err)
        if hits:
            stem = hits[0]["file_stem"]
            setter_hits[stem] = hits

    if not setter_hits:
        raise ValueError(
            f"Variable '{variable}' not found as a SETTER target in any blueprint."
        )

    # ------------------------------------------------------------------
    # Build and deduplicate chains
    # ------------------------------------------------------------------
    graph_node_ids = {n["id"] for n in graph_payload.get("nodes", [])}
    all_chains: List[Dict[str, Any]] = []
    for stem in sorted(setter_hits.keys()):
        if stem not in graph_node_ids:
            warnings.append(f"Modifier '{stem}' not in call graph; skipping.")
            continue
        max_depth_arg = int(max_depth) if max_depth is not None else None
        raw_chains = find_chains_through(graph_payload, stem, max_depth_arg)
        deduped = deduplicate_chains(raw_chains)
        for c in deduped:
            c["modifier_file"] = stem
        all_chains.extend(deduped)

    if not all_chains:
        raise ValueError("No call chains found for any modifier file.")

    # Truncate to upstream + modifier, then re-deduplicate
    for c in all_chains:
        idx = c["files"].index(c["modifier_file"])
        c["files"] = c["files"][: idx + 1]
        c["length"] = len(c["files"]) - 1
    all_chains = deduplicate_chains(all_chains)

    if not all_chains:
        raise ValueError("No chains remain after upstream truncation.")

    if not (0 <= chain_index < len(all_chains)):
        raise ValueError(
            f"chain_index {chain_index} out of range (0–{len(all_chains) - 1})."
        )

    selected = all_chains[chain_index]
    chain_files: List[str] = selected["files"]
    modifier_stem: str = selected["modifier_file"]
    modifier_idx: int = chain_files.index(modifier_stem)

    print(f"Selected chain: {' -> '.join(chain_files)}", file=sys.stderr)
    print(f"Modifier: {modifier_stem}", file=sys.stderr)

    # ------------------------------------------------------------------
    # Prepare shared tracers
    # ------------------------------------------------------------------
    tracer = LineageTracer(
        asm_dir=asm_dir or blueprint_dir,
        blueprint_dir=blueprint_dir,
    )
    fwd_tracer = ForwardLineageTracer(
        asm_dir=asm_dir or blueprint_dir,
        blueprint_dir=blueprint_dir,
    )

    cpp_blueprints = discover_cpp_blueprints(blueprint_dir)
    function_defs, functions_by_file, all_cpp_edges, _ = build_indexes(cpp_blueprints)
    owner_index = build_owner_index(function_defs)
    known_asm_stems = discover_asm_stems(blueprint_dir)

    sections: Dict[str, Any] = {}

    # ------------------------------------------------------------------
    # Trace modifier
    # ------------------------------------------------------------------
    _modifier_result = _trace_modifier_asm(
        variable=variable,
        stem=modifier_stem,
        blueprint_dir=blueprint_dir,
        asm_dir=asm_dir,
        tracer=tracer,
        warnings=warnings,
        fwd_tracer=fwd_tracer,
    )
    _discovered_downstream: List[str] = _modifier_result.pop("_discovered_downstream", [])
    sections[modifier_stem] = _modifier_result

    # ------------------------------------------------------------------
    # Trace upstream callers
    # ------------------------------------------------------------------
    upstream_pairs = [
        (chain_files[i], chain_files[i + 1])
        for i in range(modifier_idx - 1, -1, -1)
    ]

    callee_entry_map: Dict[str, str] = {}
    for _caller, _callee in upstream_pairs:
        _c_type = file_type_map.get(_caller, "asm")
        _e_type = file_type_map.get(_callee, "asm")
        if _c_type == "cpp" and _e_type == "cpp":
            _pre = find_cpp_to_cpp_callers(_caller, _callee, blueprint_dir)
            if _pre:
                callee_entry_map[_callee] = _pre[0].get("callee_function") or ""
        elif _c_type == "asm" and _e_type == "cpp":
            _pre = find_asm_to_cpp_callers(_caller, _callee, blueprint_dir, asm_dir)
            if _pre:
                callee_entry_map[_callee] = _pre[0].get("cpp_function") or ""

    for caller, callee in upstream_pairs:
        edge_instr = edge_type_map.get((caller, callee), "?")
        caller_type = file_type_map.get(caller, "asm")
        callee_type = file_type_map.get(callee, "asm")

        if caller_type == "cpp":
            sections[caller] = _trace_cpp_upstream(
                caller=caller,
                callee=callee,
                callee_type=callee_type,
                blueprint_dir=blueprint_dir,
                asm_dir=asm_dir,
                edge_instruction=edge_instr,
                functions_by_file=functions_by_file,
                owner_index=owner_index,
                known_asm_stems=known_asm_stems,
                all_edges=all_cpp_edges,
                max_depth=max_depth,
                warnings=warnings,
                entry_function=callee_entry_map.get(caller),
            )
        elif caller_type == "asm":
            sections[caller] = _trace_asm_upstream(
                caller=caller,
                callee=callee,
                callee_type=callee_type,
                blueprint_dir=blueprint_dir,
                asm_dir=asm_dir,
                edge_instruction=edge_instr,
                tracer=tracer,
                warnings=warnings,
            )
        else:
            msg = f"Unknown caller type for '{caller}': {caller_type}"
            warnings.append(msg)
            sections[caller] = {"role": "upstream", "warnings": [msg]}

    # ------------------------------------------------------------------
    # Trace dynamically discovered downstream files
    # ------------------------------------------------------------------
    already_in = set(sections.keys())
    dynamic_downstream = [
        s for s in _discovered_downstream
        if s not in already_in and s != modifier_stem
    ]
    for stem in dynamic_downstream:
        sections[stem] = _trace_downstream_file(
            variable=variable,
            stem=stem,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            tracer=tracer,
            fwd_tracer=fwd_tracer,
            warnings=warnings,
            caller_stem=modifier_stem,
        )

    # ------------------------------------------------------------------
    # Dependent variable levels
    # ------------------------------------------------------------------
    dep_var_lineage: Dict[str, Any] = {}
    if dep_depth > 0:
        level1_contexts = _extract_dep_var_contexts(sections)
        dep_var_lineage = _trace_dep_var_levels(
            level1_contexts=level1_contexts,
            tracer=tracer,
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir,
            max_depth=dep_depth,
        )
        register_deps = _collect_register_dep_vars(chain_files, blueprint_dir, asm_dir)
        if register_deps:
            l1 = dep_var_lineage.setdefault("level_1", {})
            reg_entry = l1.setdefault("_register_deps", {"found_in": [], "trace": {}})
            reg_entry["found_in"].extend(register_deps)

    # ------------------------------------------------------------------
    # Write output
    # ------------------------------------------------------------------
    output_name: str = options.get("output_name") or f"{variable}_cross_lineage.json"
    if not output_name.endswith(".json"):
        output_name += ".json"

    final_output: Dict[str, Any] = {
        "variable": variable,
        "chain": {
            "index": chain_index,
            "files": chain_files,
            "modifier": modifier_stem,
        },
        "sections": sections,
        "dep_var_lineage": dep_var_lineage,
        "warnings": warnings,
    }

    output_path = output_dir / output_name
    output_path.write_text(json.dumps(final_output, indent=2), encoding="utf-8")
    print(f"Wrote lineage output to: {output_path}", file=sys.stderr)

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)

    return {
        "job_id": ws.job_id,
        "status": "success",
        "variable": variable,
        "chain_files": chain_files,
        "output_files": len(result_files),
        "warnings": len(warnings),
    }
