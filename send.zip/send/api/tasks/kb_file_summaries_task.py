"""Celery task: generate (or regenerate) per-file business summaries for a KB."""

from __future__ import annotations

import logging
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.config import settings
from api.storage.workspace import WorkspaceManager
from api.tasks._task_utils import redirect_output_to_log, job_log_handler
from api.tasks.celery_app import celery_app
from api.tasks.file_summary_fallback import (
    _collect_blueprints,
    _find_blueprint_dir,
    _resolve_source_roots,
    _summarize_one,
)

logger = logging.getLogger(__name__)


@celery_app.task(bind=True, name="asm.kb_file_summaries")
def run_kb_file_summaries(self, job_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    """Generate missing (or all) per-file business summaries for KB blueprints."""
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run(ws, options)
            except SoftTimeLimitExceeded:
                msg = "Task exceeded soft time limit and was aborted."
                logger.error("Job %s: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s failed: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}


def _run(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    job_id = ws.job_id
    _task_start = time.monotonic()

    kb_id: str = options["kb_id"]
    force: bool = bool(options.get("force_refresh", False))
    max_workers: int = max(1, int(options.get("max_workers") or settings.CHAIN_SUMMARY_WORKERS))
    source_path_hint: Optional[str] = options.get("source_path")

    kb_output = settings.JOBS_BASE_DIR / kb_id / "output"
    if not kb_output.exists():
        raise FileNotFoundError(f"KB output directory not found: {kb_output}")

    bp_dir = _find_blueprint_dir(kb_output)
    if bp_dir is None:
        raise FileNotFoundError(f"No blueprints found in KB output: {kb_output}")

    blueprints = _collect_blueprints(bp_dir)
    total = len(blueprints)
    logger.info("Job %s: found %d blueprints in %s", job_id, total, bp_dir)

    source_roots = _resolve_source_roots(kb_id, source_path_hint)
    logger.info("Job %s: source roots: %s", job_id, [str(r) for r in source_roots])
    print(f"Blueprints found: {total}, force_refresh={force}, workers={max_workers}")
    print(f"Source roots: {[str(r) for r in source_roots]}")

    generated: List[str] = []
    skipped: List[str] = []
    failures: List[Dict[str, str]] = []

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {
            pool.submit(_summarize_one, bp, source_roots, force, kb_id): bp
            for bp in blueprints
        }
        for fut in as_completed(futures):
            try:
                stem, summary, error = fut.result()
            except Exception as exc:
                failures.append({"file": str(futures[fut].name), "error": str(exc)})
                continue

            if error is not None:
                failures.append({"file": stem, "error": error})
            elif summary is not None:
                generated.append(stem)
                logger.debug("Job %s: summary generated for %s", job_id, stem)
            else:
                skipped.append(stem)

    elapsed = time.monotonic() - _task_start
    logger.info(
        "Job %s done — generated=%d skipped=%d failed=%d elapsed=%.1fs",
        job_id, len(generated), len(skipped), len(failures), elapsed,
    )
    print(f"Done: generated={len(generated)} skipped={len(skipped)} failed={len(failures)} elapsed={elapsed:.1f}s")

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)

    return {
        "job_id": job_id,
        "status": "success",
        "kb_id": kb_id,
        "operation": "kb_file_summaries",
        "total_blueprints": total,
        "generated_count": len(generated),
        "skipped_count": len(skipped),
        "failed_count": len(failures),
        "failures": failures,
        "elapsed_seconds": round(elapsed, 1),
    }
