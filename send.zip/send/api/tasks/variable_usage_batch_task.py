"""Celery task: batch pre-computation of variable usage for all KB variables."""

from __future__ import annotations

import json
import logging
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.config import settings
from api.storage.workspace import WorkspaceManager
from api.tasks._task_utils import redirect_output_to_log, job_log_handler
from api.tasks.celery_app import celery_app
from api.tasks.variable_usage_task import (
    _CONTEXT_LINES,
    _read_full_cache,
    _write_batch_cached,
)
from api.utils.variable_search import search_variable_usages

logger = logging.getLogger(__name__)

_BATCH_WRITE_SIZE = 50
_THREAD_WORKERS   = 8


def _all_variable_names(kb_id: str, output_dir: Path) -> List[str]:
    """Return sorted unique uppercased variable names from both ASM and C++ universes.

    Priority order:
    1. Index DB (universe_variable_names table) — primary path for all new KBs.
    2. Legacy per-language .db files — pre-index-DB KBs built before the migration.
    3. Full universe JSON files — last resort for very old KBs.
    """
    from api.index_db.readers import get_variable_names

    # Primary: index DB via readers — no multi-GB JSON load
    asm_names = get_variable_names(kb_id, "asm")
    cpp_names = get_variable_names(kb_id, "cpp")
    if asm_names or cpp_names:
        return sorted(asm_names | {n.upper() for n in cpp_names})

    # Secondary: legacy per-language .db files
    from api.utils.variable_search import _stream_variable_names_from_db
    asm_db = output_dir / "asm_variable_universe.db"
    if asm_db.exists():
        names: set = set(_stream_variable_names_from_db(asm_db))
        cpp_db = output_dir / "cpp_variable_universe.db"
        names.update(_stream_variable_names_from_db(cpp_db))
        return sorted(names)

    # Last resort: load full universe JSON files (very old KBs)
    asm_path = output_dir / "asm_variable_universe.json"
    if not asm_path.exists():
        return []
    asm = json.loads(asm_path.read_text(encoding="utf-8"))
    names = set(asm.get("variables", {}).keys())

    cpp_path = output_dir / "cpp_variable_universe.json"
    if cpp_path.exists():
        cpp = json.loads(cpp_path.read_text(encoding="utf-8"))
        names.update(k.upper() for k in cpp.get("variables", {}).keys())

    return sorted(names)


@celery_app.task(bind=True, name="asm.variable_usage_batch")
def run_variable_usage_batch(self, job_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run(self, ws, options)
            except SoftTimeLimitExceeded:
                msg = "Task exceeded soft time limit and was aborted."
                logger.error("Batch job %s: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Batch job %s failed: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}


def _run(task, ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    import time as _time
    job_id = ws.job_id
    _task_start = _time.monotonic()

    kb_id = str(options["kb_id"])

    output_dir = settings.JOBS_BASE_DIR / kb_id / "output"
    input_dir  = settings.JOBS_BASE_DIR / kb_id / "input"

    if not output_dir.exists():
        raise FileNotFoundError(f"KB output directory not found: {output_dir}")
    # For new KBs the large JSON files are deleted after DB ingestion; check
    # for index.db first. Only fall back to requiring the JSON files for old
    # KBs that pre-date the index-DB migration.
    index_db_path = settings.JOBS_BASE_DIR / kb_id / "index.db"
    if not index_db_path.exists():
        for required in ("asm_variable_universe.json", "variable_identity_index.json"):
            if not (output_dir / required).exists():
                raise ValueError(
                    f"Required index '{required}' not found in {output_dir}. "
                    "Re-run the pipeline or backfill the index DB."
                )

    # Phase 1/3 — Load variable list and check cache
    logger.info("[Phase 1/3 START] Load variable list + cache — job=%s kb=%s", job_id, kb_id)
    _t = _time.monotonic()
    all_vars    = _all_variable_names(kb_id, output_dir)
    existing    = _read_full_cache(kb_id)
    to_process  = [v for v in all_vars if v not in existing]
    total       = len(all_vars)
    done_count  = len(existing)
    error_count = 0

    logger.info(
        "[Phase 1/3 DONE] Variable list — total=%d cached=%d to_process=%d elapsed=%.1fs",
        total, done_count, len(to_process), _time.monotonic() - _t,
    )
    logger.info(
        "[Phase 2/3 START] Batch search — job=%s kb=%s to_process=%d workers=%d",
        job_id, kb_id, len(to_process), _THREAD_WORKERS,
    )

    task.update_state(
        state="PROGRESS",
        meta={"done": done_count, "total": total, "job_id": ws.job_id},
    )

    pending_batch: Dict[str, Any] = {}
    _t = _time.monotonic()
    _last_log = _t

    def _search(var_upper: str) -> tuple:
        result = search_variable_usages(
            variable_name=var_upper,
            output_dir=output_dir,
            input_dir=input_dir,
            context_lines=_CONTEXT_LINES,
        )
        return var_upper, result

    with ThreadPoolExecutor(max_workers=_THREAD_WORKERS) as executor:
        futures = {executor.submit(_search, v): v for v in to_process}
        for future in as_completed(futures):
            var = futures[future]
            try:
                _, result = future.result()
                pending_batch[var] = result
            except Exception as exc:
                logger.warning("Batch: variable %r failed: %s", var, exc)
                error_count += 1

            done_count += 1
            task.update_state(
                state="PROGRESS",
                meta={"done": done_count, "total": total, "job_id": ws.job_id},
            )

            # Log progress every 100 variables so large batches are traceable
            _now = _time.monotonic()
            if done_count % 100 == 0 or (_now - _last_log) >= 30:
                logger.info(
                    "[Phase 2/3 PROGRESS] Batch search — job=%s done=%d/%d errors=%d elapsed=%.1fs",
                    job_id, done_count, total, error_count, _now - _t,
                )
                _last_log = _now

            if len(pending_batch) >= _BATCH_WRITE_SIZE:
                _write_batch_cached(kb_id, pending_batch)
                pending_batch = {}

    if pending_batch:
        _write_batch_cached(kb_id, pending_batch)

    logger.info(
        "[Phase 2/3 DONE] Batch search — processed=%d errors=%d elapsed=%.1fs",
        len(to_process), error_count, _time.monotonic() - _t,
    )

    # Phase 3/3 — Write summary
    logger.info("[Phase 3/3 START] Write batch summary — job=%s", job_id)
    skipped_count = total - len(to_process)
    summary = {
        "kb_id":     kb_id,
        "total":     total,
        "processed": len(to_process),
        "skipped":   skipped_count,
        "errors":    error_count,
    }
    ws.output_dir.mkdir(parents=True, exist_ok=True)
    (ws.output_dir / "batch_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)

    logger.info(
        "[Phase 3/3 DONE] Batch complete — job=%s processed=%d skipped=%d errors=%d total_elapsed=%.1fs",
        job_id, len(to_process), skipped_count, error_count, _time.monotonic() - _task_start,
    )

    return {
        "job_id":    ws.job_id,
        "status":    "success",
        "kb_id":     kb_id,
        "total":     total,
        "processed": len(to_process),
        "skipped":   skipped_count,
        "errors":    error_count,
    }
