"""Shared helper: ensure a blueprint has a business_summary, generating + persisting one if missing.

Used by:
- api.tasks.kb_file_summaries_task  (batch Celery task)
- api.routes.knowledge_base         (GET /file-summaries)
- api.routes.conversations          (GET file summary, keyword-file-flow)
"""

from __future__ import annotations

import logging
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.config import settings

logger = logging.getLogger(__name__)

_BLUEPRINT_SUFFIXES = (".asm.json", ".mac.json", ".cpp.json", ".hpp.json")
_SOURCE_EXTENSIONS = (".asm", ".mac", ".cpp", ".hpp", ".cbl", ".cob", ".c", ".h")


def _stem_for_blueprint(path: Path) -> Optional[str]:
    for suffix in _BLUEPRINT_SUFFIXES:
        if path.name.endswith(suffix):
            return path.name[: -len(suffix)]
    return None


def _find_blueprint_dir(output_dir: Path) -> Optional[Path]:
    """Like _task_utils.find_blueprint_dir but also handles CPP-only KBs."""
    from api.tasks._task_utils import find_blueprint_dir
    result = find_blueprint_dir(output_dir)
    if result is not None:
        return result
    # find_blueprint_dir only probes for *.asm.json; also check cpp/mac/hpp-only KBs.
    for suffix in (".cpp.json", ".mac.json", ".hpp.json"):
        for candidate in (output_dir / "asm", output_dir):
            if candidate.is_dir() and next(candidate.glob(f"*{suffix}"), None):
                return candidate
        try:
            for subdir in sorted(output_dir.iterdir()):
                if subdir.is_dir() and next(subdir.glob(f"*{suffix}"), None):
                    return subdir
        except (OSError, PermissionError):
            pass
    return None


def _collect_blueprints(bp_dir: Path) -> List[Path]:
    paths: List[Path] = []
    for suffix in _BLUEPRINT_SUFFIXES:
        paths.extend(sorted(bp_dir.glob(f"*{suffix}")))
    return paths


def _needs_summary(bp: Dict[str, Any]) -> bool:
    val = bp.get("business_summary")
    return val is None or (isinstance(val, str) and not val.strip())


def _lookup_kb_source_path(kb_id: str) -> Optional[str]:
    """Read kb.source_path from the DB, returning None on any failure."""
    try:
        from api.db import SessionLocal
        from api.models.knowledge_base import KnowledgeBase
        db = SessionLocal()
        try:
            kb = db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).first()
            if kb and kb.source_path:
                return str(kb.source_path).rstrip("/")
        finally:
            db.close()
    except Exception as exc:
        logger.debug("kb source_path lookup failed for %s: %s", kb_id, exc)
    return None


def _resolve_source_roots(kb_id: str, source_path_hint: Optional[str] = None) -> List[Path]:
    """Return candidate source directories to search, in priority order.

    1. The explicit *source_path_hint* (used by the Celery task path).
    2. kb.source_path looked up from the DB (used by API-handler fallbacks where
       the hint isn't threaded through).
    3. jobs/{kb_id}/input/ (used when the KB was built from a zip upload).
    """
    roots: List[Path] = []
    if source_path_hint:
        p = Path(source_path_hint)
        if p.is_dir():
            roots.append(p)
    if not roots:
        db_path = _lookup_kb_source_path(kb_id)
        if db_path:
            p = Path(db_path)
            if p.is_dir():
                roots.append(p)
    input_dir = settings.JOBS_BASE_DIR / kb_id / "input"
    if input_dir.is_dir() and input_dir not in roots:
        roots.append(input_dir)
    return roots


def _find_source_file(stem: str, roots: List[Path]) -> Optional[Path]:
    """Search *roots* for a source file whose stem matches *stem*."""
    for root in roots:
        for ext in _SOURCE_EXTENSIONS:
            candidate = root / (stem + ext)
            if candidate.exists():
                return candidate
        for ext in _SOURCE_EXTENSIONS:
            matches = list(root.rglob(stem + ext))
            if matches:
                return matches[0]
    return None


def _find_blueprint_for_stem(bp_dir: Path, stem: str) -> Optional[Path]:
    for suffix in _BLUEPRINT_SUFFIXES:
        candidate = bp_dir / f"{stem}{suffix}"
        if candidate.exists():
            return candidate
    return None


def _summarize_one(
    bp_path: Path,
    source_roots: List[Path],
    force: bool,
    kb_id: Optional[str] = None,
) -> Tuple[str, Optional[str], Optional[str]]:
    """Return (stem, new_summary_or_None, error_or_None).

    Loads the blueprint, skips if a summary already exists (unless *force*),
    resolves the original source file, generates a summary, writes the
    blueprint back in-place, and persists to the FileSummary DB when
    *kb_id* is provided.
    """
    from blueprint_io import load_blueprint, write_blueprint
    from llm.summarizer import generate_business_summary

    stem = _stem_for_blueprint(bp_path)
    if stem is None:
        return ("?", None, "unrecognised blueprint suffix")

    try:
        bp_lite = load_blueprint(bp_path, skip_global_lineage=True, keys={"business_summary"})
    except Exception as exc:
        return (stem, None, f"load failed: {exc}")

    if not force and not _needs_summary(bp_lite):
        return (stem, None, None)

    # Full load only when generation is actually needed
    try:
        bp = load_blueprint(bp_path, skip_global_lineage=True)
    except Exception as exc:
        return (stem, None, f"load failed: {exc}")

    source_file = _find_source_file(stem, source_roots)
    if source_file is None:
        return (stem, None, "source file not found — cannot generate summary")

    try:
        summary = generate_business_summary(source_file)
    except Exception as exc:
        return (stem, None, f"LLM error: {exc}")

    bp["business_summary"] = summary
    try:
        write_blueprint(bp_path, bp)
    except Exception as exc:
        return (stem, None, f"write failed: {exc}")

    # Keep FileSummary DB in sync so GET /file-summaries fast path stays current.
    if kb_id:
        _db_save_summary(kb_id, stem, summary)

    return (stem, summary, None)


def _db_get_summary(kb_id: str, stem: str) -> Optional[str]:
    """Read a file summary from users.db — survives blueprint/job deletion."""
    try:
        from api.db import SessionLocal
        from api.models.knowledge_base import FileSummary
        db = SessionLocal()
        try:
            row = db.query(FileSummary).filter(
                FileSummary.kb_id == kb_id,
                FileSummary.file_path == stem,
            ).first()
            if row and row.summary:
                return row.summary.strip()
        finally:
            db.close()
    except Exception as exc:
        logger.debug("db_get_summary failed for %s/%s: %s", kb_id, stem, exc)
    return None


def _db_save_summary(kb_id: str, stem: str, summary: str) -> None:
    """Persist a file summary to users.db (upsert)."""
    try:
        from api.db import SessionLocal
        from api.models.knowledge_base import FileSummary
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        db = SessionLocal()
        try:
            row = db.query(FileSummary).filter(
                FileSummary.kb_id == kb_id,
                FileSummary.file_path == stem,
            ).first()
            if row:
                row.summary = summary
                row.kb_updated_at = now
            else:
                db.add(FileSummary(
                    kb_id=kb_id,
                    file_path=stem,
                    summary=summary,
                    kb_updated_at=now,
                    created_at=now,
                ))
            db.commit()
        finally:
            db.close()
    except Exception as exc:
        logger.debug("db_save_summary failed for %s/%s: %s", kb_id, stem, exc)


def ensure_file_business_summary(
    kb_id: str,
    stem: str,
    *,
    bp_dir: Optional[Path] = None,
    source_roots: Optional[List[Path]] = None,
) -> Optional[str]:
    """Return the business summary for *stem*, generating + persisting if missing.

    Read order: users.db → blueprint file → generate via LLM.
    Write order: blueprint file + users.db (both updated on generation).
    Never raises.
    """
    from blueprint_io import load_blueprint

    # 1. Check users.db first — fastest, survives blueprint deletion
    cached = _db_get_summary(kb_id, stem)
    if cached:
        return cached

    if bp_dir is None:
        kb_output = settings.JOBS_BASE_DIR / kb_id / "output"
        if not kb_output.exists():
            logger.warning("ensure_file_business_summary: kb output missing for %s", kb_id)
            return None
        bp_dir = _find_blueprint_dir(kb_output)
        if bp_dir is None:
            logger.warning("ensure_file_business_summary: no blueprint dir for kb=%s", kb_id)
            return None

    bp_path = _find_blueprint_for_stem(bp_dir, stem)
    if bp_path is None:
        logger.warning("ensure_file_business_summary: no blueprint for stem=%s in %s", stem, bp_dir)
        return None

    try:
        bp_lite = load_blueprint(bp_path, skip_global_lineage=True, keys={"business_summary"})
    except Exception as exc:
        logger.warning("ensure_file_business_summary: load failed for %s: %s", bp_path, exc)
        return None

    # 2. Check blueprint file
    if not _needs_summary(bp_lite):
        val = bp_lite.get("business_summary")
        if isinstance(val, str) and val.strip():
            _db_save_summary(kb_id, stem, val.strip())  # backfill DB
            return val.strip()

    if source_roots is None:
        source_roots = _resolve_source_roots(kb_id)
    if not source_roots:
        logger.warning("ensure_file_business_summary: no source roots for kb=%s", kb_id)
        return None

    # 3. Generate via LLM, persist to both blueprint and DB
    _, summary, err = _summarize_one(bp_path, source_roots, force=False)
    if err is not None:
        logger.warning(
            "ensure_file_business_summary: %s for stem=%s kb=%s", err, stem, kb_id
        )
        return None
    if summary is None:
        try:
            bp2 = load_blueprint(bp_path, skip_global_lineage=True, keys={"business_summary"})
            val = bp2.get("business_summary")
            summary = val.strip() if isinstance(val, str) and val.strip() else None
        except Exception:
            return None
    if summary:
        _db_save_summary(kb_id, stem, summary)
    return summary


def ensure_many_business_summaries(
    kb_id: str,
    stems: Iterable[str],
    *,
    max_workers: int = 4,
) -> Dict[str, Optional[str]]:
    """Parallelized fallback for bulk / flow callers.

    Resolves bp_dir and source_roots once, then runs `ensure_file_business_summary`
    for each stem with at most *max_workers* concurrent LLM calls. Returns a dict
    mapping every input stem to its summary (or None if unavailable). Note: actual
    Gemini concurrency is additionally bounded process-wide by the LLM semaphore,
    so *max_workers* is only an upper bound on threads, not on API pressure.
    Never raises.
    """
    stems_list = list(dict.fromkeys(stems))  # dedupe preserving order
    if not stems_list:
        return {}

    kb_output = settings.JOBS_BASE_DIR / kb_id / "output"
    if not kb_output.exists():
        logger.warning("ensure_many_business_summaries: kb output missing for %s", kb_id)
        return {s: None for s in stems_list}
    bp_dir = _find_blueprint_dir(kb_output)
    if bp_dir is None:
        logger.warning("ensure_many_business_summaries: no blueprint dir for kb=%s", kb_id)
        return {s: None for s in stems_list}

    source_roots = _resolve_source_roots(kb_id)

    results: Dict[str, Optional[str]] = {}
    if max_workers <= 1 or len(stems_list) == 1:
        for s in stems_list:
            results[s] = ensure_file_business_summary(
                kb_id, s, bp_dir=bp_dir, source_roots=source_roots
            )
        return results

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {
            pool.submit(
                ensure_file_business_summary,
                kb_id, s, bp_dir=bp_dir, source_roots=source_roots,
            ): s
            for s in stems_list
        }
        for fut in as_completed(futures):
            stem = futures[fut]
            try:
                results[stem] = fut.result()
            except Exception as exc:
                logger.warning("ensure_many_business_summaries: stem=%s raised %s", stem, exc)
                results[stem] = None
    return results
