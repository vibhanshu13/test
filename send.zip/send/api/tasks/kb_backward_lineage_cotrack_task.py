"""Celery task: bidirectional ASM<->CPP backward co-traversal against an existing KB."""

from __future__ import annotations

import json
import logging
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Generator, Optional

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.config import settings
from api.storage.workspace import WorkspaceManager, get_metadata_client
from api.tasks._task_utils import redirect_output_to_log, job_log_handler
from api.tasks.celery_app import celery_app
from api.processes.scope import ProcessScope, filter_tuple_to_scope

logger = logging.getLogger(__name__)


@contextmanager
def _session_lock(session_id: str, timeout: int = 60) -> Generator[None, None, None]:
    client = get_metadata_client()
    lock_key = f"chunked_lineage_lock:{session_id}"
    lock = client.lock(lock_key, timeout=timeout)
    acquired = lock.acquire(blocking=True, blocking_timeout=30)
    if not acquired:
        raise RuntimeError(f"Could not acquire session lock for {session_id}")
    try:
        yield
    finally:
        try:
            lock.release()
        except Exception:
            pass


@celery_app.task(bind=True, name="asm.kb_backward_lineage_cotrack")
def run_kb_backward_lineage_cotrack(
    self, job_id: str, options: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Drive a bidirectional backward co-traversal for a primary and a counterpart
    variable, each on their own chain, and emit a linked page payload.

    Session state is persisted under:
      jobs/{kb_id}/output/backward_lineage/chunked/{session_id}/session.msgpack

    Page JSON is written to:
      jobs/{kb_id}/output/backward_lineage/cotrack/{var}__{counterpart}_tuple_{idx}.json
    """
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run(ws, options)
            except SoftTimeLimitExceeded:
                msg = "Task exceeded soft time limit and was aborted."
                logger.error("Job %s: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s failed: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}


def _run(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    from backward_traversal.runner.chunked_session import (
        ChunkedBackwardSession,
        get_session_dir,
    )

    job_id = ws.job_id
    _task_start = time.monotonic()

    kb_id = str(options["kb_id"])
    start_tuple_index = int(options["start_tuple_index"])
    link_meta: Dict[str, Any] = dict(options.get("link") or {})

    primary_opts: Dict[str, Any] = dict(options["primary"])
    counterpart_opts: Dict[str, Any] = dict(options["counterpart"])

    primary_variable = str(primary_opts["variable_name"])
    primary_chain = list(primary_opts["chain_files"])
    primary_session_id = str(primary_opts["session_id"])

    counterpart_variable = str(counterpart_opts["variable_name"])
    counterpart_chain = list(counterpart_opts["chain_files"])
    counterpart_session_id = str(counterpart_opts["session_id"])

    logger.info(
        "[Phase 1/3 START] Resolve inputs — job=%s kb=%s primary=%s counterpart=%s start_tuple=%d",
        job_id, kb_id, primary_variable, counterpart_variable, start_tuple_index,
    )
    _t = time.monotonic()
    kb_output = settings.JOBS_BASE_DIR / kb_id / "output"
    if not kb_output.exists():
        raise FileNotFoundError(f"KB output directory not found: {kb_output}")

    blueprint_dir = _resolve_blueprint_dir(kb_output)
    from api.tasks._task_utils import resolve_graph_file
    graph_file = resolve_graph_file(kb_output, kb_id)
    asm_dir = _resolve_asm_dir(kb_output, options)

    # Session dirs
    primary_session_dir = get_session_dir(kb_id, primary_session_id)
    primary_session_dir.mkdir(parents=True, exist_ok=True)
    counterpart_session_dir = get_session_dir(kb_id, counterpart_session_id)
    counterpart_session_dir.mkdir(parents=True, exist_ok=True)

    logger.info("[Phase 1/3 DONE] Inputs resolved — elapsed=%.1fs", time.monotonic() - _t)

    # Phase 2/3 — Drive BOTH sessions forward to the requested tuple index
    logger.info(
        "[Phase 2/3 START] Session processing — primary_session=%s counterpart_session=%s tuple=%d",
        primary_session_id, counterpart_session_id, start_tuple_index,
    )
    _t = time.monotonic()

    primary_session = _advance_session(
        kb_id=kb_id,
        session_id=primary_session_id,
        variable=primary_variable,
        selected_chain=primary_chain,
        options=options,
        blueprint_dir=blueprint_dir,
        asm_dir=asm_dir,
        graph_file=graph_file,
        session_dir=primary_session_dir,
        start_tuple_index=start_tuple_index,
    )

    counterpart_session = _advance_session(
        kb_id=kb_id,
        session_id=counterpart_session_id,
        variable=counterpart_variable,
        selected_chain=counterpart_chain,
        options=options,
        blueprint_dir=blueprint_dir,
        asm_dir=asm_dir,
        graph_file=graph_file,
        session_dir=counterpart_session_dir,
        start_tuple_index=start_tuple_index,
    )

    logger.info("[Phase 2/3 DONE] Sessions advanced — elapsed=%.1fs", time.monotonic() - _t)

    # Phase 3/3 — Assemble tuples and write linked page
    logger.info("[Phase 3/3 START] Assemble tuples — job=%s tuple_index=%d", job_id, start_tuple_index)
    _t = time.monotonic()

    def _assemble(session: Any, session_dir: Path) -> Optional[Dict[str, Any]]:
        try:
            return session.assemble_tuple(start_tuple_index, session_dir)
        except Exception:
            return None

    primary_tuple = _assemble(primary_session, primary_session_dir)
    counterpart_tuple = _assemble(counterpart_session, counterpart_session_dir)

    # Filter each tuple to its own chain scope
    def _scoped(tpl: Optional[Dict[str, Any]], chain: list) -> Optional[Dict[str, Any]]:
        if tpl is None:
            return None
        scope = ProcessScope(
            process_name="<kb_chain>",
            files=tuple(chain),
            headers_resolved=(),
            mac_files=(),
            edges=(),
            edge_meta=(),
        )
        return filter_tuple_to_scope(tpl, scope)

    primary_tuple = _scoped(primary_tuple, primary_chain)
    counterpart_tuple = _scoped(counterpart_tuple, counterpart_chain)

    # Aggregate has_more / completed across both sessions
    p_map_len = len(primary_session.tuple_index_map)
    c_map_len = len(counterpart_session.tuple_index_map)
    next_tuple_index = start_tuple_index + 1
    p_has_more = not primary_session.is_complete or next_tuple_index < p_map_len
    c_has_more = not counterpart_session.is_complete or next_tuple_index < c_map_len
    has_more = p_has_more or c_has_more
    completed = primary_session.is_complete and counterpart_session.is_complete

    combined_warnings = list(primary_session.warnings or []) + list(counterpart_session.warnings or [])

    # Terminal classifications — only available when each side's session is complete
    primary_tc = None
    counterpart_tc = None
    try:
        if primary_session.is_complete:
            primary_tc = primary_session.get_finalized_full_flow().get("terminal_classifications")
    except Exception as _e:
        logger.debug("co-track: primary terminal classification failed: %s", _e)
    try:
        if counterpart_session.is_complete:
            counterpart_tc = counterpart_session.get_finalized_full_flow().get("terminal_classifications")
    except Exception as _e:
        logger.debug("co-track: counterpart terminal classification failed: %s", _e)

    page_data = {
        "job_id": job_id,
        "kb_id": kb_id,
        "co_track": True,
        "link": link_meta,
        "primary": {
            "root_variable": primary_variable,
            "selected_chain": primary_chain,
            "session_id": primary_session_id,
            "tuple_index": start_tuple_index,
            "next_tuple_index": next_tuple_index,
            "has_more": p_has_more,
            "completed": primary_session.is_complete,
            "tuple": primary_tuple,
            "skipped_empty_tuples": primary_session._s.get("empty_tuples") or [],
            "terminal_classifications": primary_tc,
        },
        "counterpart": {
            "root_variable": counterpart_variable,
            "selected_chain": counterpart_chain,
            "session_id": counterpart_session_id,
            "tuple_index": start_tuple_index,
            "next_tuple_index": next_tuple_index,
            "has_more": c_has_more,
            "completed": counterpart_session.is_complete,
            "tuple": counterpart_tuple,
            "skipped_empty_tuples": counterpart_session._s.get("empty_tuples") or [],
            "terminal_classifications": counterpart_tc,
        },
        "start_tuple_index": start_tuple_index,
        "next_tuple_index": next_tuple_index,
        "has_more": has_more,
        "completed": completed,
        "warnings": combined_warnings,
    }

    # Sanitise variable names for filename use (replace non-alphanumeric)
    def _safe(name: str) -> str:
        import re
        return re.sub(r"[^A-Za-z0-9_]", "_", name)

    output_dir = ws.output_dir / "backward_lineage" / "cotrack"
    output_dir.mkdir(parents=True, exist_ok=True)
    page_filename = (
        f"{_safe(primary_variable)}__{_safe(counterpart_variable)}_tuple_{start_tuple_index}.json"
    )
    output_path = output_dir / page_filename
    output_path.write_text(json.dumps(page_data, indent=2), encoding="utf-8")

    if options.get("compress_output", False):
        from api.tasks._output_compression import compress_outputs
        compress_outputs(output_dir)

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)

    logger.info(
        "[Phase 3/3 DONE] Co-traversal tuple assembled — has_more=%s elapsed=%.1fs total=%.1fs",
        has_more, time.monotonic() - _t, time.monotonic() - _task_start,
    )

    return {
        "job_id": ws.job_id,
        "status": "success",
        "primary_session_id": primary_session_id,
        "counterpart_session_id": counterpart_session_id,
        "start_tuple_index": start_tuple_index,
        "next_tuple_index": next_tuple_index,
        "has_more": has_more,
        "completed": completed,
        "output_file": str(output_path.relative_to(ws.output_dir)),
    }


def _advance_session(
    *,
    kb_id: str,
    session_id: str,
    variable: str,
    selected_chain: list,
    options: Dict[str, Any],
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    graph_file: Path,
    session_dir: Path,
    start_tuple_index: int,
) -> Any:
    """Load-or-create a ChunkedBackwardSession and drive it to start_tuple_index."""
    from backward_traversal.runner.chunked_session import ChunkedBackwardSession

    with _session_lock(session_id):
        session = ChunkedBackwardSession.load(kb_id, session_id)

        if session is None:
            if start_tuple_index != 0:
                raise ValueError(
                    f"No session found for session_id={session_id}; "
                    "must start with start_tuple_index=0"
                )
            session = ChunkedBackwardSession.new(
                session_id=session_id,
                kb_id=kb_id,
                variable=variable,
                selected_chain=selected_chain,
                options=options,
                blueprint_dir=blueprint_dir,
                asm_dir=asm_dir,
                graph_file=graph_file,
            )

        if not session.is_complete:
            session.process_until_tuple(start_tuple_index, session_dir)
            session.save(kb_id, session_id)

    # Re-load after lock release for read-only tuple assembly
    loaded = ChunkedBackwardSession.load(kb_id, session_id)
    if loaded is None:
        raise RuntimeError(f"Session {session_id} disappeared after save; state is inconsistent")
    return loaded


def _resolve_blueprint_dir(kb_output: Path) -> Path:
    from api.tasks._task_utils import find_blueprint_dir
    d = find_blueprint_dir(kb_output)
    if d is None:
        raise FileNotFoundError(f"No .asm.json blueprint files found under {kb_output}")
    return d


def _resolve_asm_dir(_kb_output: Path, options: Dict[str, Any]) -> Optional[Path]:
    if options.get("asm_dir"):
        p = Path(str(options["asm_dir"]))
        if p.exists():
            return p
    kb_id = options.get("kb_id")
    if kb_id:
        try:
            from api.db import SessionLocal
            from api.models.knowledge_base import KnowledgeBase
            db = SessionLocal()
            try:
                kb = db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).first()
                if kb and kb.source_path:
                    p = Path(kb.source_path)
                    if p.exists():
                        return p
            finally:
                db.close()
        except Exception:
            pass
    logger.warning(
        "KB co-track task: asm_dir could not be resolved for kb_id=%s.",
        options.get("kb_id", "unknown"),
    )
    return None
