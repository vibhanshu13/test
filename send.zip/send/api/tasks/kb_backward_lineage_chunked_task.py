"""Celery task: chunked backward lineage traversal against an existing KB output."""

from __future__ import annotations

import json
import logging
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Generator, Optional

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.config import settings
from api.storage.workspace import WorkspaceManager, get_metadata_client
from api.tasks._task_utils import redirect_output_to_log, job_log_handler
from api.tasks.celery_app import celery_app
from api.processes.scope import ProcessScope, filter_tuple_to_scope

logger = logging.getLogger(__name__)


@contextmanager
def _session_lock(session_id: str, timeout: int = 60) -> Generator[None, None, None]:
    client = get_metadata_client()
    lock_key = f"chunked_lineage_lock:{session_id}"
    lock = client.lock(lock_key, timeout=timeout)
    acquired = lock.acquire(blocking=True, blocking_timeout=30)
    if not acquired:
        raise RuntimeError(f"Could not acquire session lock for {session_id}")
    try:
        yield
    finally:
        try:
            lock.release()
        except Exception:
            pass


@celery_app.task(bind=True, name="asm.kb_backward_lineage_chunked")
def run_kb_backward_lineage_chunked(
    self, job_id: str, options: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Process a chunk of backward-only lineage and save incremental session state.

    Session state is persisted under:
      jobs/{kb_id}/output/backward_lineage/chunked/{session_id}/session.msgpack

    Page JSON is written to:
      jobs/{kb_id}/output/backward_lineage/{session_id}_{start}_{count}.json
    """
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run(ws, options)
            except SoftTimeLimitExceeded:
                msg = "Task exceeded soft time limit and was aborted."
                logger.error("Job %s: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s failed: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}


def _run(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    from backward_traversal.runner.chunked_session import (
        ChunkedBackwardSession,
        get_session_dir,
    )

    job_id = ws.job_id
    _task_start = time.monotonic()

    kb_id = str(options["kb_id"])
    session_id = str(options["session_id"])
    start_tuple_index = int(options["start_tuple_index"])
    variable = str(options["variable_name"])
    selected_chain = list(options["chain_files"])

    # Phase 1/3 — Resolve inputs
    logger.info(
        "[Phase 1/3 START] Resolve inputs — job=%s kb=%s session=%s variable=%s start_tuple=%d",
        job_id, kb_id, session_id, variable, start_tuple_index,
    )
    _t = time.monotonic()
    kb_output = settings.JOBS_BASE_DIR / kb_id / "output"
    if not kb_output.exists():
        raise FileNotFoundError(f"KB output directory not found: {kb_output}")

    blueprint_dir = _resolve_blueprint_dir(kb_output)
    from api.tasks._task_utils import resolve_graph_file
    graph_file = resolve_graph_file(kb_output, kb_id)
    asm_dir = _resolve_asm_dir(kb_output, options)

    session_directory = get_session_dir(kb_id, session_id)
    session_directory.mkdir(parents=True, exist_ok=True)
    logger.info("[Phase 1/3 DONE] Inputs resolved — elapsed=%.1fs", time.monotonic() - _t)

    # Phase 2/3 — Session lock + tuple processing
    logger.info(
        "[Phase 2/3 START] Session lock + tuple processing — job=%s session=%s start_tuple=%d",
        job_id, session_id, start_tuple_index,
    )
    _t = time.monotonic()
    with _session_lock(session_id):
        session = ChunkedBackwardSession.load(kb_id, session_id)

        if session is None:
            if start_tuple_index != 0:
                raise ValueError(
                    f"No session found for session_id={session_id}; must start with start_tuple_index=0"
                )
            session = ChunkedBackwardSession.new(
                session_id=session_id,
                kb_id=kb_id,
                variable=variable,
                selected_chain=selected_chain,
                options=options,
                blueprint_dir=blueprint_dir,
                asm_dir=asm_dir,
                graph_file=graph_file,
            )

        # Drive the session forward: if the tuple needs to be computed, process_until_tuple
        # indexes it; if it's already indexed, the drain loop in process_until_tuple
        # advances through remaining phase transitions to keep is_complete accurate.
        if not session.is_complete:
            session.process_until_tuple(start_tuple_index, session_directory)
            session.save(kb_id, session_id)

    logger.info(
        "[Phase 2/3 DONE] Tuple processed — tuples_indexed=%d is_complete=%s elapsed=%.1fs",
        len(session.tuple_index_map), session.is_complete, time.monotonic() - _t,
    )

    # Phase 3/3 — Assemble tuple + write output
    logger.info("[Phase 3/3 START] Assemble tuple — job=%s tuple_index=%d", job_id, start_tuple_index)
    _t = time.monotonic()
    # Re-load session after lock release for tuple assembly (read-only)
    session = ChunkedBackwardSession.load(kb_id, session_id)
    if session is None:
        raise RuntimeError("Session disappeared after save; state is inconsistent")

    tuple_dict = session.assemble_tuple(start_tuple_index, session_directory)
    if tuple_dict is None:
        raise RuntimeError(
            f"Tuple {start_tuple_index} not found after processing; "
            f"session has {len(session.tuple_index_map)} tuple(s) — traversal may be complete with fewer tuples."
        )

    # C6.2 fix: filter cross_file_calls_out and full_flow_edges to the requested
    # chain scope, mirroring what process_lineage_chunked_task does with process scope.
    chain_scope = ProcessScope(
        process_name="<kb_chain>",
        files=tuple(selected_chain),
        headers_resolved=(),
        mac_files=(),
        edges=(),
        edge_meta=(),
    )
    tuple_dict = filter_tuple_to_scope(tuple_dict, chain_scope)

    next_tuple_index = start_tuple_index + 1
    tuple_index_map_len = len(session.tuple_index_map)
    has_more = not session.is_complete or next_tuple_index < tuple_index_map_len

    page_data = {
        "job_id": job_id,   # C6.1 fix: align KB chunked schema with process chunked
        "kb_id": kb_id,
        "session_id": session_id,
        "root_variable": variable,
        "selected_chain": selected_chain,
        "start_tuple_index": start_tuple_index,
        "tuple_index": start_tuple_index,
        "next_tuple_index": next_tuple_index,
        "has_more": has_more,
        "completed": session.is_complete,
        "cache_hit": False,
        "skipped_empty_tuples": session._s.get("empty_tuples") or [],
        "tuple": tuple_dict,
        "warnings": session.warnings,
    }

    output_dir = ws.output_dir / "backward_lineage"
    output_dir.mkdir(parents=True, exist_ok=True)
    page_filename = f"{variable}_tuple_{start_tuple_index}.json"
    output_path = output_dir / page_filename
    output_path.write_text(json.dumps(page_data, indent=2), encoding="utf-8")
    # C6.5 fix: compress output page if requested.
    if options.get("compress_output", False):
        from api.tasks._output_compression import compress_outputs
        compress_outputs(output_dir)

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)
    logger.info(
        "[Phase 3/3 DONE] Tuple assembled — has_more=%s elapsed=%.1fs total_elapsed=%.1fs",
        has_more, time.monotonic() - _t, time.monotonic() - _task_start,
    )

    return {
        "job_id": ws.job_id,
        "status": "success",
        "session_id": session_id,
        "start_tuple_index": start_tuple_index,
        "tuple_index": start_tuple_index,
        "next_tuple_index": next_tuple_index,
        "has_more": has_more,
        "completed": session.is_complete,
        "output_file": str(output_path.relative_to(ws.output_dir)),
    }


def _resolve_blueprint_dir(kb_output: Path) -> Path:
    from api.tasks._task_utils import find_blueprint_dir
    d = find_blueprint_dir(kb_output)
    if d is None:
        raise FileNotFoundError(f"No .asm.json blueprint files found under {kb_output}")
    return d


def _resolve_asm_dir(kb_output: Path, options: Dict[str, Any]) -> Optional[Path]:
    if options.get("asm_dir"):
        p = Path(str(options["asm_dir"]))
        if p.exists():
            return p
    # Fall back to the source_path recorded in the KB database record — this is
    # the resolved absolute path supplied when the pipeline was originally run.
    kb_id = options.get("kb_id")
    if kb_id:
        try:
            from api.db import SessionLocal
            from api.models.knowledge_base import KnowledgeBase
            db = SessionLocal()
            try:
                kb = db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id).first()
                if kb and kb.source_path:
                    p = Path(kb.source_path)
                    if p.exists():
                        return p
            finally:
                db.close()
        except Exception:
            pass
    # C6.6 fix: warn so callers know raw source lines will be absent.
    logger.warning(
        "KB chunked task: asm_dir could not be resolved for kb_id=%s "
        "(no asm_dir option and KB source_path absent or inaccessible). "
        "Raw source lines will be None for all call sites.",
        options.get("kb_id", "unknown"),
    )
    return None
