"""Celery task: chunked backward lineage traversal scoped to a single process.

Mirrors api/tasks/kb_backward_lineage_chunked_task.py but:
  * graph_file points at the process-filtered call graph (materialized on-demand)
  * session.msgpack lives under jobs/{job_id}/output/process_lineage/{process_name}/chunked/{session_id}/
  * chunk JSON files land under jobs/{job_id}/output/process_lineage/{process_name}/backward_lineage/
  * session_id input is namespaced with process_name so two processes cannot collide
"""

from __future__ import annotations

import json
import logging
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Generator, Optional

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.config import settings
from api.storage.workspace import WorkspaceManager, get_metadata_client
from api.tasks._task_utils import redirect_output_to_log, job_log_handler
from api.tasks.celery_app import celery_app
from api.processes.scope import (
    filter_tuple_to_scope,
    load_process_scope,
    materialize_filtered_graph,
    process_lineage_dir,
    session_file_for,
)

logger = logging.getLogger(__name__)


@contextmanager
def _session_lock(session_id: str, timeout: int = 60) -> Generator[None, None, None]:
    client = get_metadata_client()
    lock_key = f"process_lineage_lock:{session_id}"
    lock = client.lock(lock_key, timeout=timeout)
    acquired = lock.acquire(blocking=True, blocking_timeout=30)
    if not acquired:
        raise RuntimeError(f"Could not acquire session lock for {session_id}")
    try:
        yield
    finally:
        try:
            lock.release()
        except Exception:
            pass


@celery_app.task(bind=True, name="asm.process_lineage_chunked")
def run_process_lineage_chunked(
    self, job_id: str, options: Dict[str, Any]
) -> Dict[str, Any]:
    """Process one chunk of backward-only lineage scoped to a process."""
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run(ws, options)
            except SoftTimeLimitExceeded:
                msg = "Task exceeded soft time limit and was aborted."
                logger.error("Job %s: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s failed: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}


def _run(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    from backward_traversal.runner.chunked_session import ChunkedBackwardSession

    job_id = ws.job_id
    _task_start = time.monotonic()

    process_name = str(options["process_name"])
    session_id = str(options["session_id"])
    start_tuple_index = int(options["start_tuple_index"])
    variable = str(options["variable_name"])
    selected_chain = list(options["chain_files"])

    logger.info(
        "[Process Lineage Phase 1/3] Resolve — job=%s process=%s session=%s var=%s start=%d",
        job_id, process_name, session_id, variable, start_tuple_index,
    )
    _t = time.monotonic()

    kb_output = ws.output_dir
    if not kb_output.exists():
        raise FileNotFoundError(f"Output directory not found: {kb_output}")

    process_dir = kb_output / "processes" / process_name
    if not process_dir.is_dir():
        raise FileNotFoundError(f"Process seed dir missing: {process_dir}")

    from api.tasks._task_utils import resolve_graph_file
    global_graph = resolve_graph_file(kb_output, job_id)

    scope = load_process_scope(process_dir, process_name)
    graph_file = materialize_filtered_graph(kb_output, process_name, scope, global_graph)

    asm_dir = _resolve_asm_dir(kb_output, options, ws)
    blueprint_dir = _resolve_blueprint_dir(kb_output)

    session_directory = process_lineage_dir(kb_output, process_name) / "chunked" / session_id
    session_directory.mkdir(parents=True, exist_ok=True)
    session_file = session_file_for(kb_output, process_name, session_id)
    logger.info("[Process Lineage Phase 1/3 DONE] elapsed=%.1fs", time.monotonic() - _t)

    # Phase 2/3 — Session lock + tuple processing
    logger.info("[Process Lineage Phase 2/3] Process tuple — session=%s start=%d", session_id, start_tuple_index)
    _t = time.monotonic()
    with _session_lock(session_id):
        session = ChunkedBackwardSession.load(job_id, session_id, session_file=session_file)

        if session is None:
            if start_tuple_index != 0:
                raise ValueError(
                    f"No session found for session_id={session_id}; must start with start_tuple_index=0"
                )
            session = ChunkedBackwardSession.new(
                session_id=session_id,
                kb_id=job_id,
                variable=variable,
                selected_chain=selected_chain,
                options=options,
                blueprint_dir=blueprint_dir,
                asm_dir=asm_dir,
                graph_file=graph_file,
            )

        if not session.is_complete:
            session.process_until_tuple(start_tuple_index, session_directory)
            session.save(job_id, session_id, session_file=session_file)

    logger.info(
        "[Process Lineage Phase 2/3 DONE] tuples=%d complete=%s elapsed=%.1fs",
        len(session.tuple_index_map), session.is_complete, time.monotonic() - _t,
    )

    # Phase 3/3 — Assemble tuple + write output
    logger.info("[Process Lineage Phase 3/3] Assemble tuple — index=%d", start_tuple_index)
    _t = time.monotonic()
    session = ChunkedBackwardSession.load(job_id, session_id, session_file=session_file)
    if session is None:
        raise RuntimeError("Session disappeared after save; state inconsistent")

    tuple_dict = session.assemble_tuple(start_tuple_index, session_directory)
    if tuple_dict is None:
        raise RuntimeError(
            f"Tuple {start_tuple_index} not found after processing; "
            f"session has {len(session.tuple_index_map)} tuple(s)."
        )
    # Enforce process scope: drop any out-of-scope cross-file refs / full-flow edges
    tuple_dict = filter_tuple_to_scope(tuple_dict, scope)

    next_tuple_index = start_tuple_index + 1
    tuple_index_map_len = len(session.tuple_index_map)
    has_more = not session.is_complete or next_tuple_index < tuple_index_map_len

    page_data = {
        "job_id": job_id,
        "process": process_name,
        "session_id": session_id,
        "root_variable": variable,
        "selected_chain": selected_chain,
        "start_tuple_index": start_tuple_index,
        "tuple_index": start_tuple_index,
        "next_tuple_index": next_tuple_index,
        "has_more": has_more,
        "completed": session.is_complete,
        "cache_hit": False,
        "skipped_empty_tuples": session._s.get("empty_tuples") or [],
        "tuple": tuple_dict,
        "warnings": session.warnings,
    }

    output_dir = process_lineage_dir(kb_output, process_name) / "backward_lineage"
    output_dir.mkdir(parents=True, exist_ok=True)
    # C6.3 fix: honour output_name when provided by the caller
    _oname = str(options.get("output_name") or "").strip()
    page_filename = _oname if _oname else f"{variable}_tuple_{start_tuple_index}.json"
    output_path = output_dir / page_filename
    output_path.write_text(json.dumps(page_data, indent=2), encoding="utf-8")

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)
    logger.info(
        "[Process Lineage Phase 3/3 DONE] has_more=%s elapsed=%.1fs total=%.1fs",
        has_more, time.monotonic() - _t, time.monotonic() - _task_start,
    )

    return {
        "job_id": job_id,
        "process": process_name,
        "status": "success",
        "session_id": session_id,
        "start_tuple_index": start_tuple_index,
        "tuple_index": start_tuple_index,
        "next_tuple_index": next_tuple_index,
        "has_more": has_more,
        "completed": session.is_complete,
        "output_file": str(output_path.relative_to(ws.output_dir)),
    }


def _resolve_blueprint_dir(kb_output: Path) -> Path:
    from api.tasks._task_utils import find_blueprint_dir
    d = find_blueprint_dir(kb_output)
    if d is None:
        raise FileNotFoundError(f"No .asm.json blueprint files found under {kb_output}")
    return d


def _resolve_asm_dir(kb_output: Path, options: Dict[str, Any], ws: WorkspaceManager) -> Optional[Path]:
    """Resolve the source-code directory for ASM files.

    Search order:
      1. explicit `asm_dir` in options
      2. `source_path` recorded in pipeline options (saved at job submission)
    """
    if options.get("asm_dir"):
        p = Path(str(options["asm_dir"]))
        if p.exists():
            return p
    # Fall back to job's stored pipeline options
    try:
        pipeline_opts = ws.get_pipeline_options() or {}
        src = pipeline_opts.get("source_path")
        if src:
            p = Path(str(src))
            if p.exists():
                return p
    except Exception:
        pass
    # C6.6 fix: warn so callers know raw source lines will be absent.
    logger.warning(
        "Process lineage task: asm_dir could not be resolved for job=%s "
        "(no asm_dir option and source_path absent from pipeline options). "
        "Raw source lines will be None for all call sites.",
        ws.job_id,
    )
    return None
