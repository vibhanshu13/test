"""Celery task: full assembly analysis pipeline (main.py equivalent)."""

from __future__ import annotations

import ctypes
import gc
import hashlib
import json
import logging
import os
import pickle
import shutil
import sys
import time
from concurrent.futures import (
    ThreadPoolExecutor,
    TimeoutError as _FuturesTimeoutError,
    as_completed,
    wait as _futures_wait,
    FIRST_COMPLETED as _FIRST_COMPLETED,
)
from pathlib import Path
from typing import Any, Dict, List, Optional

from celery.exceptions import SoftTimeLimitExceeded

# Ensure project root is importable from inside the worker process
PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.tasks.celery_app import celery_app
from api.tasks._task_utils import redirect_output_to_log, job_log_handler
from api.storage.workspace import WorkspaceManager
# from blueprint_io import load_blueprint, pack_blueprint

logger = logging.getLogger(__name__)


def _mark_analysis_phase(ws, phase_name: str, status: str) -> None:
    """Write a step2 sub-phase status to Redis, suppressing errors."""
    try:
        ws.set_step_status(phase_name, status)
    except Exception as exc:
        logger.warning("Could not mark phase %s as %s: %s", phase_name, status, exc)

# ---------------------------------------------------------------------------
# Memory helpers
# ---------------------------------------------------------------------------
_libc = None
_HAS_MALLOC_TRIM = False
for _libc_name in ("libc.so.6", "libc.so", "libSystem.B.dylib", "libc.dylib"):
    try:
        _candidate = ctypes.CDLL(_libc_name, use_errno=True)
        _candidate.malloc_trim.argtypes = [ctypes.c_size_t]
        _candidate.malloc_trim.restype = ctypes.c_int
        _libc = _candidate
        _HAS_MALLOC_TRIM = True
        break
    except Exception:
        continue

# mallopt(M_MMAP_THRESHOLD) lets us force large allocations to use anonymous
# mmap instead of brk.  mmap regions are returned to the OS immediately on
# free() via munmap — unlike sbrk-based pages that must wait for malloc_trim.
# This is the key fix for the post-GVL-write RSS fragmentation problem:
# after the ~3.7 GB GVL dict is deleted, all its mmap'd pages are released
# immediately, dropping RSS back to the baseline before the GVL was created.
_M_MMAP_THRESHOLD = -3   # glibc malloc.h constant
_HAS_MALLOPT = False
if _libc is not None:
    try:
        _libc.mallopt.argtypes = [ctypes.c_int, ctypes.c_int]
        _libc.mallopt.restype = ctypes.c_int
        _HAS_MALLOPT = True
    except Exception:
        pass


def _set_mmap_threshold(threshold_bytes: int) -> None:
    """Switch glibc's mmap allocation threshold.

    Allocations larger than *threshold_bytes* use anonymous mmap instead of
    brk.  Set to 65536 before creating a large temporary object so its pages
    are released immediately on del (via munmap).  Restore to 131072 (glibc
    default) afterward.  No-op on non-glibc platforms.
    """
    if _HAS_MALLOPT:
        _libc.mallopt(ctypes.c_int(_M_MMAP_THRESHOLD), ctypes.c_int(threshold_bytes))


def _current_rss_mb() -> int:
    """Return the CURRENT RSS in MB (reads /proc/self/status VmRSS on Linux).

    On Linux, resource.getrusage().ru_maxrss is the HIGH-WATERMARK (peak RSS),
    which never decreases.  Reading VmRSS from /proc/self/status gives the
    actual live RSS after malloc_trim has returned pages to the OS.
    Falls back to ru_maxrss on non-Linux platforms.
    """
    try:
        with open("/proc/self/status") as fh:
            for line in fh:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) // 1024  # kB → MB
    except Exception:
        pass
    import resource
    _ru = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    # ru_maxrss units differ by platform: KILOBYTES on Linux, BYTES on macOS.
    # Without the darwin correction the logs report MB values inflated 1024×
    # (e.g. "RSS=391584 MB" for an actual ~382 MB process).
    if sys.platform == "darwin":
        return _ru // (1024 * 1024)
    return _ru // 1024


def _current_cgroup_usage_mb() -> int:
    """Return the container's cgroup memory usage in MB, INCLUDING page cache.

    Docker's OOM killer uses cgroup memory.current (v2) or
    memory.usage_in_bytes (v1), which includes both anonymous (RSS) and
    file-backed (page cache) memory.  VmRSS from /proc/self/status excludes
    page cache, so using it underestimates actual cgroup pressure after heavy
    disk I/O (e.g. 22.5 GB of macro_exp/lineage pickle writes during Phase 4).

    This function is the correct one to use when computing available headroom
    against a Docker cgroup memory limit, because the OOM killer accounts for
    page cache in the same way.

    Falls back to VmRSS on non-Linux or when cgroup files are unavailable.
    """
    for path in (
        "/sys/fs/cgroup/memory.current",               # cgroup v2 (Docker ≥ 20.10)
        "/sys/fs/cgroup/memory/memory.usage_in_bytes", # cgroup v1
    ):
        try:
            val = int(open(path).read().strip())
            return val // (1024 * 1024)  # bytes → MB
        except Exception:
            continue
    return _current_rss_mb()


def _read_cgroup_memory_limit_mb() -> Optional[int]:
    """Return the container's cgroup memory limit in MB, or None if not applicable.

    Reads cgroups v2 (/sys/fs/cgroup/memory.max) first, then cgroups v1
    (/sys/fs/cgroup/memory/memory.limit_in_bytes).  Returns None when the
    limit is 'max' / near-infinite (bare-metal or unlimited container), so
    callers can fall back to /proc/meminfo.
    """
    _UNLIMITED = (1 << 62)  # cgroups v1 uses 2^63-4096 for unlimited
    for path in ("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes"):
        try:
            raw = open(path).read().strip()
            if raw == "max":
                return None
            val_mb = int(raw) // (1024 * 1024)
            if val_mb >= _UNLIMITED // (1024 * 1024):
                return None  # effectively unlimited
            return val_mb
        except Exception:
            continue
    return None


def _trim_heap(label: str = "") -> None:
    """Ask glibc to return freed pages to the OS and log current RSS + cgroup usage."""
    trimmed = 0
    if _HAS_MALLOC_TRIM:
        trimmed = _libc.malloc_trim(0)
    rss_mb = _current_rss_mb()
    cgroup_mb = _current_cgroup_usage_mb()
    trim_note = f" trim={'yes' if trimmed else 'no/noop'}" if _HAS_MALLOC_TRIM else " trim=unavailable"
    # Only show cgroup when it differs from VmRSS (i.e. page cache is non-trivial)
    cgroup_note = f" cgroup={cgroup_mb} MB" if cgroup_mb != rss_mb else ""
    print(f"[mem] VmRSS={rss_mb} MB{cgroup_note}{trim_note}{(' — ' + label) if label else ''}")


# ---------------------------------------------------------------------------
# Emission checkpoint helpers
#
# After all expensive orchestrator phases complete, every analysis_context is
# evicted to disk (one pickle per file, in cache_dir/ctx_cache/).  A JSON
# manifest records the file list and cache-directory paths.
#
# On a subsequent run of the SAME job (same job_id → same cache_dir), the
# manifest is detected and the orchestrator is skipped entirely.  Phase 4/6
# (blueprint emission) reloads each context from disk on demand, emits the
# blueprint, then frees the context immediately — so only one context at a
# time is in memory during emission.
#
# This makes emission fully resumable: already-written blueprint files are
# detected and skipped, so a SIGKILL or OOM during emission wastes at most
# the work done since the last successfully written file.
# ---------------------------------------------------------------------------

_EMIT_MANIFEST_NAME = "emission_manifest.json"
_CTX_CACHE_SUBDIR   = "ctx_cache"


def _ctx_cache_key(file_path: Path) -> str:
    """Stable filename for the pickled AnalysisContext of *file_path*."""
    return hashlib.md5(str(file_path).encode()).hexdigest() + "_ctx.pkl"


def _fadvise_dontneed(fd: int) -> None:
    """Tell the kernel the pages for *fd* are no longer needed.

    posix_fadvise(POSIX_FADV_DONTNEED) marks file pages as low-priority for
    the page cache reclaimer.  The kernel can evict them immediately or on the
    next memory-pressure event.  This is the primary defence against page-cache
    OOM: every pickle read/write during emission releases its page cache, so
    cgroup memory stays near Python's RSS instead of RSS + all_pickle_files.
    No-op on macOS / Windows (os.posix_fadvise not available).
    """
    try:
        os.posix_fadvise(fd, 0, 0, 4)  # 4 = POSIX_FADV_DONTNEED
    except Exception:
        pass


def _fadvise_path_dontneed(path) -> None:
    """Open *path* read-only and call POSIX_FADV_DONTNEED to evict its pages.

    Calling fadvise on the write fd (inside the ``with open("wb")`` block)
    targets dirty pages that the kernel may not evict immediately, especially
    on VirtioFS (Docker Desktop / macOS) where dirty-page reclaim hints are
    not always honoured.  Opening the file fresh after close guarantees the
    pages are clean (already flushed by the OS when the write fd was closed),
    so DONTNEED reliably drops them from the page cache.

    Also used after pickle reads: opening a fresh read-only fd and advising
    DONTNEED is more portable than advising on the still-open fd.
    """
    try:
        fd = os.open(str(path), os.O_RDONLY)
        try:
            os.posix_fadvise(fd, 0, 0, 4)  # POSIX_FADV_DONTNEED
        finally:
            os.close(fd)
    except Exception:
        pass


def _dump_context(ctx, ctx_dir: Path, file_path: Path) -> bool:
    """Pickle *ctx* to *ctx_dir* and immediately release page cache. Returns True on success."""
    try:
        dest = ctx_dir / _ctx_cache_key(file_path)
        with open(dest, "wb") as fh:
            pickle.dump(ctx, fh, protocol=pickle.HIGHEST_PROTOCOL)
            # Try fadvise while the fd is still open (works on ext4 / native Linux).
            _fadvise_dontneed(fh.fileno())
        # After close, dirty pages have been flushed — reopen read-only so
        # DONTNEED drops the now-clean pages.  More reliable on VirtioFS where
        # dirty-page hints on the write fd may be silently ignored.
        _fadvise_path_dontneed(dest)
        return True
    except Exception as exc:
        logger.warning("checkpoint: could not save context for %s: %s", file_path.name, exc)
        return False


def _load_context(ctx_dir: Path, file_path: Path):
    """Unpickle and return the AnalysisContext for *file_path*, then release page cache."""
    try:
        src = ctx_dir / _ctx_cache_key(file_path)
        if src.exists():
            with open(src, "rb") as fh:
                ctx = pickle.load(fh)
                # Drop page cache while fd is open (works on native Linux ext4).
                _fadvise_dontneed(fh.fileno())
            # Re-open read-only after close for more reliable eviction on VirtioFS.
            _fadvise_path_dontneed(src)
            return ctx
    except Exception as exc:
        logger.warning("checkpoint: could not load context for %s: %s", file_path.name, exc)
    return None


def _save_emission_checkpoint(
    file_results: list,
    cache_dir: Path,
    input_dir: Path,
    output_dir: Path,
    block_cache_dir: Optional[Path],
    lmi_cache_dir: Optional[Path],
    lineage_cache_dir: Optional[Path],
    macro_exp_cache_dir: Optional[Path],
    do_lineage: bool,
    skip_business_summary: bool,
    c_exts: set,
    cpp_exts: set,
    unit_cache_dir: Optional[Path] = None,
    sym_cache_dir: Optional[Path] = None,
    call_graph_cache_dir: Optional[Path] = None,
) -> Optional[Path]:
    """Evict every AnalysisContext to disk and write the emission manifest.

    After this call, every ``fr.analysis_context`` in *file_results* is set
    to None (freed from memory).  Phase 4/6 emission loads each context from
    *ctx_dir* on demand.

    Returns the ctx_cache_dir path, or None if the manifest could not be
    written (individual context saves that fail are only logged).
    """
    ctx_dir = cache_dir / _CTX_CACHE_SUBDIR
    ctx_dir.mkdir(parents=True, exist_ok=True)

    _saved = _failed = 0
    _t = time.monotonic()
    for fr in file_results:
        if fr.analysis_context is not None:
            if _dump_context(fr.analysis_context, ctx_dir, fr.file_path):
                fr.analysis_context = None  # release immediately after saving
                _saved += 1
            else:
                _failed += 1

    try:
        manifest = {
            "version": 1,
            "input_dir": str(input_dir),
            "output_dir": str(output_dir),
            "block_cache_dir": str(block_cache_dir) if block_cache_dir else None,
            "lmi_cache_dir": str(lmi_cache_dir) if lmi_cache_dir else None,
            "lineage_cache_dir": str(lineage_cache_dir) if lineage_cache_dir else None,
            "macro_exp_cache_dir": str(macro_exp_cache_dir) if macro_exp_cache_dir else None,
            "unit_cache_dir": str(unit_cache_dir) if unit_cache_dir else None,
            "sym_cache_dir": str(sym_cache_dir) if sym_cache_dir else None,
            "call_graph_cache_dir": str(call_graph_cache_dir) if call_graph_cache_dir else None,
            "ctx_cache_dir": str(ctx_dir),
            "do_lineage": do_lineage,
            "skip_business_summary": skip_business_summary,
            "file_paths": [str(fr.file_path) for fr in file_results],
            "c_exts": sorted(c_exts),
            "cpp_exts": sorted(cpp_exts),
        }
        _manifest_path = cache_dir / _EMIT_MANIFEST_NAME
        _manifest_data = json.dumps(manifest, indent=2)
        # Use an explicit open+fsync so the manifest is durably on disk even if
        # the process is SIGKILL'd immediately after.  Path.write_text() closes
        # the fd but does not fsync; on macOS VirtioFS the kernel may not flush
        # the write before the process is killed.
        with open(_manifest_path, "w") as _mfh:
            _mfh.write(_manifest_data)
            _mfh.flush()
            os.fsync(_mfh.fileno())
    except Exception as exc:
        logger.warning("checkpoint: could not write manifest: %s", exc)
        return ctx_dir  # contexts are on disk even if manifest failed

    logger.info(
        "Emission checkpoint saved: %d context(s) in %.1fs → %s (%d failed)",
        _saved, time.monotonic() - _t, ctx_dir, _failed,
    )
    print(
        f"[checkpoint] {_saved} context(s) evicted to disk in {time.monotonic() - _t:.1f}s — "
        f"Phase 4/6 is resumable. ({_failed} context(s) could not be saved)",
        flush=True,
    )
    return ctx_dir


def _load_emission_manifest(manifest_path: Path):
    """Load the emission manifest and return a (manifest_dict, ctx_dir) tuple.

    Returns None if the manifest is missing, unreadable, or its ctx_cache_dir
    does not exist on disk.
    """
    try:
        m = json.loads(manifest_path.read_text())
    except Exception as exc:
        logger.warning("checkpoint: could not read manifest %s: %s", manifest_path, exc)
        return None

    ctx_dir = Path(m["ctx_cache_dir"]) if m.get("ctx_cache_dir") else None
    if not ctx_dir or not ctx_dir.exists():
        logger.warning("checkpoint: ctx_cache_dir missing or gone: %s", ctx_dir)
        return None

    return m, ctx_dir


def _reload_evicted_metadata(
    context,
    file_path: Path,
    block_cache_dir,
    lmi_cache_dir,
    lineage_cache_dir=None,
    load_lineage: bool = False,
    macro_exp_cache_dir=None,
    unit_cache_dir=None,
    sym_cache_dir=None,
    call_graph_cache_dir=None,
) -> None:
    """Reload metadata that was evicted to disk during Phase 1 batch collection.

    block_analysis and line_metadata_index are always reloaded when their cache
    dirs are provided — they are needed by JSONEmitter for every blueprint.

    variable_lineage is only reloaded when *load_lineage=True* (i.e. the caller
    requested per-file lineage export), avoiding a 4–6 GB memory spike for the
    common case where lineage export is disabled.

    macro_expansions are reloaded when *macro_exp_cache_dir* is provided — full
    ExpansionResult objects were evicted per-file during Phase 4 to prevent
    1–3 GB per-file accumulation, and are restored here for JSON emission.

    call_graph is reloaded when *call_graph_cache_dir* is provided — ASM call
    graphs were evicted before Phase 5 stitching (not needed by stitcher) and
    are restored here so the blueprint contains real call_graph data.

    Uses the same deterministic MD5-based key that the orchestrators use, but
    avoids importing from those modules to prevent circular dependencies.
    """
    import hashlib, pickle as _pk

    def _load(cache_dir, suffix):
        try:
            key = hashlib.md5(str(file_path).encode()).hexdigest() + suffix
            src = cache_dir / key
            if src.exists():
                with open(src, "rb") as fh:
                    data = _pk.load(fh)
                    # Release page cache while fd is open (works on native Linux ext4).
                    _fadvise_dontneed(fh.fileno())
                # Re-open read-only after close — more reliable on VirtioFS where
                # fadvise on the read fd may be silently ignored.
                _fadvise_path_dontneed(src)
                return data
        except Exception:
            pass
        return None

    if block_cache_dir is not None:
        block = _load(block_cache_dir, "_block.pkl")
        if block is not None:
            context.add_metadata("block_analysis", block)

    if lmi_cache_dir is not None:
        lmi = _load(lmi_cache_dir, "_lmi.pkl")
        if lmi is not None:
            context.line_metadata_index = lmi

    if load_lineage and lineage_cache_dir is not None:
        if context.get_metadata("variable_lineage") is None:
            # Lineage key uses just ".pkl" (no extra prefix) in both orchestrators.
            lin = _load(lineage_cache_dir, ".pkl")
            if lin is not None:
                context.add_metadata("variable_lineage", lin)

    if macro_exp_cache_dir is not None:
        me = _load(macro_exp_cache_dir, "_me.pkl")
        if me is not None:
            context.macro_expansions = me

    if unit_cache_dir is not None:
        # Reload the full c_family_unit from disk for blueprint emission.
        # During stitching only a compact stub was loaded into the context
        # (to avoid the 10–20 GB bulk-reload spike).  json_emitter.py needs
        # the full object, so we restore it here — one unit at a time, freed
        # immediately after _emit_one_file finishes via analysis_context=None.
        unit = _load(unit_cache_dir, "_unit.pkl")
        if unit is not None:
            context.add_metadata("c_family_unit", unit)

    if sym_cache_dir is not None and context.symbol_table is None:
        # Restore the symbol_table that was saved to disk by GlobalLineageStitcher
        # before it freed the in-memory copy to reduce peak RSS during stitching.
        # json_emitter.py calls context.symbol_table.to_dict() for every blueprint.
        sym = _load(sym_cache_dir, "_sym.pkl")
        if sym is not None:
            context.symbol_table = sym

    if call_graph_cache_dir is not None and context.get_metadata("call_graph") is None:
        # Restore the call_graph that was serialised to disk before Phase 5
        # pre-stitch eviction.  ASM call_graphs are not needed by the stitcher
        # but ARE needed by json_emitter._emit_call_graph() for every blueprint.
        # Loading one graph per file keeps peak overhead to a single graph.
        cg = _load(call_graph_cache_dir, "_cg.pkl")
        if cg is not None:
            context.add_metadata("call_graph", cg)


def _emit_one_file(
    file_result,
    input_dir: Path,
    output_dir: Path,
    do_lineage: bool,
    reviewer,
    coverage_review_exts: set,
    skip_business_summary: bool = False,
    block_cache_dir: Optional[Path] = None,
    lmi_cache_dir: Optional[Path] = None,
    lineage_cache_dir: Optional[Path] = None,
    macro_exp_cache_dir: Optional[Path] = None,
    unit_cache_dir: Optional[Path] = None,
    sym_cache_dir: Optional[Path] = None,
    call_graph_cache_dir: Optional[Path] = None,
) -> tuple:
    """Emit a single file blueprint; safe to call from a ThreadPoolExecutor.

    JSONEmitter is stateless (no __init__, no mutable instance state), so a
    fresh instance per call is thread-safe with no locking needed.

    Returns (input_file_path, lineage_graph_or_None, list_of_log_lines).
    """
    from json_emitter import JSONEmitter
    from llm.summarizer import generate_business_summary

    emitter = JSONEmitter()
    log_lines = []

    # Reload metadata that was evicted to disk during Phase 1 batch collection
    # to keep peak RSS under the container memory limit.  These objects are
    # needed by JSONEmitter but not by any cross-file resolution phase.
    # lineage is always reloaded from lineage_cache (one file at a time) so that
    # per-file variable_lineage is present in every emitted blueprint.  The cache
    # was written during Phase 1/4 and holds all graphs on disk (~4–5 GB total);
    # loading one graph per file during serial emission adds only a single-file
    # peak (≤ 200 MB), not a bulk spike.
    _load_lineage_for_emit = lineage_cache_dir is not None
    _needs_reload = (
        block_cache_dir is not None
        or lmi_cache_dir is not None
        or _load_lineage_for_emit
        or macro_exp_cache_dir is not None
        or unit_cache_dir is not None
        or sym_cache_dir is not None
        or call_graph_cache_dir is not None
    )
    if _needs_reload:
        _reload_evicted_metadata(
            file_result.analysis_context,
            file_result.file_path,
            block_cache_dir,
            lmi_cache_dir,
            lineage_cache_dir=lineage_cache_dir,
            load_lineage=_load_lineage_for_emit,
            macro_exp_cache_dir=macro_exp_cache_dir,
            unit_cache_dir=unit_cache_dir,
            sym_cache_dir=sym_cache_dir,
            call_graph_cache_dir=call_graph_cache_dir,
        )

    json_dict = emitter.emit(file_result.analysis_context)

    # Free full macro_expansions immediately after emission — they are large
    # (1–3 MB per ASM file) and no longer needed once the blueprint is written.
    if macro_exp_cache_dir is not None and hasattr(file_result.analysis_context, "macro_expansions"):
        file_result.analysis_context.macro_expansions = []

    lineage_graph = None
    if do_lineage:
        _graph = file_result.analysis_context.get_metadata("variable_lineage")
        if _graph:
            lineage_graph = _graph

    # Release the context immediately — all blueprint data is now in json_dict.
    file_result.analysis_context = None

    input_file = file_result.file_path
    try:
        relative_path = input_file.relative_to(input_dir)
        output_file = output_dir / (str(relative_path) + ".json")
    except ValueError:
        output_file = output_dir / f"{input_file.name}.json"

    output_file.parent.mkdir(parents=True, exist_ok=True)

    if skip_business_summary:
        json_dict["business_summary"] = ""
    else:
        try:
            json_dict["business_summary"] = generate_business_summary(input_file)
            log_lines.append(f"  Summary generated for {input_file.name}")
        except Exception as exc:
            log_lines.append(
                f"Warning: Could not generate business summary for {input_file.name}: {exc}"
            )
            json_dict["business_summary"] = None

    # Write blueprint as seekable per-key zstd frames with a .bpidx sidecar.
    # write_blueprint() calls path.write_bytes() internally; after it returns
    # we advise the kernel to drop the written pages from the page cache.
    # This prevents blueprint page cache from accumulating (7+ GB for 15K
    # files on VirtioFS where write-fd fadvise hints are often ignored).
    from blueprint_io import write_blueprint as _write_blueprint
    _write_blueprint(output_file, json_dict)
    _fadvise_path_dontneed(output_file)
    log_lines.append(f"Wrote: {output_file}")

    # Free the blueprint dict BEFORE running the reviewer.  The reviewer calls
    # load_blueprint(output_file) internally, so holding json_dict in memory
    # simultaneously would double the per-file peak (blueprint dict × 2).
    # After the reviewer returns we re-read from disk to append coverage_review.
    json_dict = None

    if reviewer and input_file.suffix.lower() in coverage_review_exts:
        try:
            review_result = reviewer(output_file, input_file)
            # Re-read from disk (reviewer's internal copy is already freed).
            # skip_global_lineage=True: the GVL (global_variable_lineage.json)
            # can be 5+ GB for large corpora.  Loading it here would cache it in
            # Python heap for the entire emission phase, instantly triggering OOM.
            # Coverage-review data doesn't use the GVL at all.
            from blueprint_io import load_blueprint as _load_blueprint
            _bp = _load_blueprint(output_file, skip_global_lineage=True)
            _bp["coverage_review"] = {
                "ok": review_result.ok,
                "score": round(review_result.score, 2),
                "errors": review_result.errors,
                "warnings": review_result.warnings,
                "line_audit": review_result.line_audit_summary,
                "metrics": [
                    {
                        "name": m.name,
                        "covered": m.covered,
                        "expected": m.expected,
                        "ratio": round(m.ratio, 6),
                        "weight": m.weight,
                        "points": round(m.points, 6),
                    }
                    for m in review_result.metrics
                ],
            }
            _write_blueprint(output_file, _bp)
            _fadvise_path_dontneed(output_file)
            _bp = None
            status_str = "PASS" if review_result.ok else "FAIL"
            log_lines.append(f"  Coverage Review: {status_str} ({review_result.score:.1f}%)")
        except Exception as exc:
            log_lines.append(
                f"Warning: Coverage review failed for {input_file.name}: {exc}"
            )
    return (input_file, lineage_graph, log_lines)


def _stream_write_gvl(graph, path: Path) -> None:
    """Serialise a VariableLineageGraph to msgpack without materialising the
    full Python dict.

    Memory peak is O(1) per node/edge rather than O(N), eliminating the
    ~700 MB transient spike that occurs when graph.to_dict() builds 229K node
    dicts + 1.7M edge dicts simultaneously.

    When GlobalLineageStitcher has evicted Phase-2 edges to a temp msgpack
    file (indicated by ``graph._p2_edges_path`` being set), this function
    streams those edges directly from the file before writing the smaller
    Phase-3 new-edge list from memory.  The temp file is deleted after
    writing so disk space is reclaimed immediately.

    The on-disk format is byte-for-byte identical to:
        pack_blueprint({"nodes": [n.to_dict() for n in graph.nodes.values()],
                        "edges": [e.to_dict() for e in graph.edges]})
    """
    import os as _os
    import struct
    import msgpack as _mp

    packer = _mp.Packer(use_bin_type=True)

    def _array_header(n: int) -> bytes:
        # msgpack array16: 0xdc + 2-byte big-endian length (up to 65535)
        # msgpack array32: 0xdd + 4-byte big-endian length (up to 2^32−1)
        if n <= 0xFFFF:
            return b"\xdc" + struct.pack(">H", n)
        return b"\xdd" + struct.pack(">I", n)

    # Phase-2 edge eviction metadata (set by GlobalLineageStitcher when active).
    _p2_path: Optional[str] = getattr(graph, "_p2_edges_path", None)
    _p2_count: int = getattr(graph, "_p2_edge_count", 0)
    _total_edges = _p2_count + len(graph.edges)

    with open(path, "wb") as fh:
        # fixmap header: 0x80 | 2 = 0x82  (top-level map with 2 keys)
        fh.write(b"\x82")

        # --- nodes ---
        fh.write(packer.pack("nodes"))
        fh.write(_array_header(len(graph.nodes)))
        for node in graph.nodes.values():
            fh.write(packer.pack(node.to_dict()))

        # --- edges ---
        fh.write(packer.pack("edges"))
        fh.write(_array_header(_total_edges))

        # Stream Phase-2 edges from temp file (avoids loading 4+ GB back into RAM).
        if _p2_path and _os.path.exists(_p2_path):
            unpacker = _mp.Unpacker(raw=False)
            with open(_p2_path, "rb") as p2fh:
                while True:
                    chunk = p2fh.read(1 << 20)  # 1 MiB chunks
                    if not chunk:
                        break
                    unpacker.feed(chunk)
                    for edge_dict in unpacker:
                        fh.write(packer.pack(edge_dict))
            # Delete temp file after streaming to free disk space.
            try:
                _os.unlink(_p2_path)
                graph._p2_edges_path = None
            except Exception:
                pass

        # Write Phase-3 new edges (in-memory, typically much smaller).
        for edge in graph.edges:
            fh.write(packer.pack(edge.to_dict()))



@celery_app.task(
    bind=True,
    name="asm.full_analysis",
)
def run_full_analysis(self, job_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    """
    Execute the full multi-file assembly analysis pipeline.

    Mirrors main.py programmatically — discovers source files in the job
    input directory, runs the appropriate orchestrator, emits JSON output
    to the job output directory, and optionally exports variable lineage.
    """
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run_analysis(ws, options)
            except SoftTimeLimitExceeded:
                error_msg = "Task exceeded soft time limit and was aborted."
                logger.error("Job %s: %s", job_id, error_msg)
                ws.set_status("failed", error=error_msg)
                return {"job_id": job_id, "status": "failed", "error": error_msg}
            except Exception as exc:
                error_msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s failed: %s", job_id, error_msg)
                ws.set_status("failed", error=error_msg)
                return {"job_id": job_id, "status": "failed", "error": error_msg}


def _run_analysis(ws: WorkspaceManager, options: Dict[str, Any], update_status: bool = True) -> Dict[str, Any]:
    """Core analysis logic — called inside the log redirect context."""
    from source_discovery import filter_discovered_paths, merge_discovery_exclude_patterns
    from multi_file.orchestrator import MultiFileOrchestrator
    from multi_file.mixed_orchestrator import MixedLanguageOrchestrator
    from json_emitter import JSONEmitter

    job_id = ws.job_id
    _analysis_start = time.monotonic()

    input_dir = Path(options["source_path"]) if options.get("source_path") else ws.input_dir
    output_dir = ws.output_dir
    cache_dir = ws.cache_dir

    output_dir.mkdir(parents=True, exist_ok=True)
    cache_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Phase 1/6 — Discover source files inside the uploaded input directory
    # ------------------------------------------------------------------
    _mark_analysis_phase(ws, "step2_phase1", "running")
    logger.info("[Phase 1/6 START] Source file discovery — job=%s input=%s", job_id, input_dir)
    print("--- Phase 1/6: Source file discovery ---")
    print(f"  Scanning : {input_dir}")
    print("  Targets  : .asm .mac .s .cpy .copy  (ASM)  |  .c .cpp .cxx .h .hpp  (C/C++)")
    print("  Action   : recursive scan → apply exclusion filters → deduplicate resolved paths.", flush=True)
    _t = time.monotonic()
    asm_exts = {".asm", ".mac", ".s", ".cpy", ".copy"}
    c_exts = {".c"}
    cpp_exts = {".cc", ".cpp", ".cxx", ".hpp", ".h"}
    make_exts = {".mak"}
    make_names = {"Makefile", "makefile", "GNUmakefile"}
    all_exts = asm_exts | c_exts | cpp_exts | make_exts

    recursive_file_candidates: List[Any] = []
    recursive_dir_candidates: List[Any] = []

    root_dir = input_dir.resolve()
    for ext in all_exts:
        for source_file in input_dir.rglob(f"*{ext}"):
            if source_file.is_file() and not source_file.name.startswith("."):
                recursive_file_candidates.append((source_file.resolve(), root_dir))
    for name in make_names:
        for source_file in input_dir.rglob(name):
            if source_file.is_file() and not source_file.name.startswith("."):
                recursive_file_candidates.append((source_file.resolve(), root_dir))
    for subdir in root_dir.rglob("*"):
        # Skip hidden directories (.git, .idea, .venv, etc.) so IDE metadata
        # and version-control internals are never added to search paths.
        if subdir.is_dir() and not any(
            part.startswith(".") for part in subdir.relative_to(root_dir).parts
        ):
            recursive_dir_candidates.append((subdir.resolve(), root_dir))

    exclude_patterns: List[str] = options.get("exclude", [])
    effective_exclude = merge_discovery_exclude_patterns(
        exclude_patterns,
        include_test_sources=False,
    )

    recursive_files: List[Path] = []
    included_dirs: List[Path] = []

    if recursive_file_candidates:
        recursive_files, _ = filter_discovered_paths(
            recursive_file_candidates,
            exclude_patterns=effective_exclude,
            respect_gitignore=False,  # worker has no git context
        )
    if recursive_dir_candidates:
        included_dirs, _ = filter_discovered_paths(
            recursive_dir_candidates,
            exclude_patterns=effective_exclude,
            respect_gitignore=False,
        )

    seen: set = set()
    file_paths: List[Path] = []
    for p in recursive_files:
        if p not in seen:
            seen.add(p)
            file_paths.append(p)

    if not file_paths:
        raise ValueError("No source files found in uploaded input after applying discovery filters.")

    _mark_analysis_phase(ws, "step2_phase1", "success")
    logger.info(
        "[Phase 1/6 DONE] Source file discovery — files=%d elapsed=%.1fs",
        len(file_paths), time.monotonic() - _t,
    )

    # ------------------------------------------------------------------
    # Build search paths
    # ------------------------------------------------------------------
    auto_search_paths = {fp.parent.resolve() for fp in file_paths}
    for d in included_dirs:
        auto_search_paths.add(d.resolve())

    user_search_paths: List[Path] = [Path(p).resolve() for p in options.get("search_paths", [])]
    final_search_paths: List[Path] = list(user_search_paths)
    for ap in auto_search_paths:
        if ap not in final_search_paths:
            final_search_paths.append(ap)

    macro_libs: List[Path] = [Path(p).resolve() for p in options.get("macro_libs", [])] or None

    # ------------------------------------------------------------------
    # Optionally load variable universe from a prior universe job
    # ------------------------------------------------------------------
    universe_asm_names: set = set()
    universe_cpp_names: set = set()

    if options.get("load_universe") and options.get("universe_job_id"):
        universe_job_id: str = options["universe_job_id"]
        universe_ws = WorkspaceManager(universe_job_id)
        universe_output = universe_ws.output_dir
        asm_names_path = universe_output / "asm_variable_names.json"
        cpp_names_path = universe_output / "cpp_variable_names.json"

        try:
            from api.index_db.readers import get_variable_names as _get_var_names
            universe_asm_names = _get_var_names(
                universe_job_id, "asm",
                fallback_path=asm_names_path if asm_names_path.exists() else None,
            )
            if universe_asm_names:
                print(f"Loaded ASM universe: {len(universe_asm_names)} variables")
        except Exception as exc:
            print(f"Warning: Could not load ASM universe: {exc}")

        try:
            from api.index_db.readers import get_variable_names as _get_var_names
            universe_cpp_names = _get_var_names(
                universe_job_id, "cpp",
                fallback_path=cpp_names_path if cpp_names_path.exists() else None,
            )
            if universe_cpp_names:
                print(f"Loaded C++ universe: {len(universe_cpp_names)} variables")
        except Exception as exc:
            print(f"Warning: Could not load C++ universe: {exc}")

    # ------------------------------------------------------------------
    # Phase-aware emission checkpoint detection
    #
    # When a previous run saved an emission checkpoint (emission_manifest.json
    # + per-file ctx pickles), we can skip the expensive orchestrator entirely
    # and resume Phase 4/6 where it stopped.
    #
    # However, the manifest must only be used when the resume intent is to
    # continue from a late phase (phase4_prep, phase4, phase5).  If the
    # caller explicitly asks to re-run from an earlier phase (phase1, phase2,
    # or phase3), we IGNORE any cached manifest so the orchestrator reruns —
    # otherwise "resume from phase1" would silently skip all analysis and only
    # re-emit blueprints, which is never what the user intends.
    # ------------------------------------------------------------------
    resume_from: str = options.get("resume_from") or ""

    # Phases that are allowed to shortcut via the emission manifest.
    # Empty string covers the non-phase-level resume case (step3, step4, etc.)
    # where step2 is either skipped entirely or the manifest can be honoured.
    _manifest_phases = {"", "step2_phase4_prep", "step2_phase4", "step2_phase5"}
    _may_use_manifest = (
        not resume_from.startswith("step2_phase")   # step-level resume: always OK
        or resume_from in _manifest_phases           # late-phase resume: OK
        # early-phase resumes (phase1/2/3) fall through → _may_use_manifest = False
    )

    _manifest_path = cache_dir / _EMIT_MANIFEST_NAME
    _ctx_cache_dir: Optional[Path] = None
    _resuming_from_ckpt = False
    _ckpt_manifest: Optional[dict] = None
    _ckpt_load = _load_emission_manifest(_manifest_path) if _may_use_manifest else None
    if _ckpt_load is not None:
        _ckpt_manifest, _ctx_cache_dir = _ckpt_load
        _resuming_from_ckpt = True
        _n_ckpt = len(_ckpt_manifest.get("file_paths", []))
        logger.info(
            "Job %s: emission checkpoint found — skipping orchestrator, resuming Phase 4/6 "
            "for %d file(s) (resume_from=%r)",
            job_id, _n_ckpt, resume_from or "(none)",
        )
        print(
            f"\n=== [RESUME] Emission checkpoint detected ===\n"
            f"  Skipping orchestrator (all analysis phases already complete).\n"
            f"  Resuming Phase 4/6 blueprint emission for {_n_ckpt} file(s).\n"
            f"  Already-written blueprints will be detected and skipped automatically.",
            flush=True,
        )
    elif not _may_use_manifest and resume_from:
        logger.info(
            "Job %s: resume_from=%r — ignoring emission manifest (re-running orchestrator).",
            job_id, resume_from,
        )
        print(
            f"  [RESUME] resume_from={resume_from!r}: re-running full orchestrator "
            f"(emission manifest ignored).",
            flush=True,
        )

    # ------------------------------------------------------------------
    # Phase 2/6 — Choose and run orchestrator  (skipped when resuming)
    # ------------------------------------------------------------------
    if not _resuming_from_ckpt:
        has_c_family = any(p.suffix.lower() in (c_exts | cpp_exts) for p in file_paths)
        has_make = any(
            p.suffix.lower() in make_exts or p.name in make_names for p in file_paths
        )

        orch_type = "MixedLanguageOrchestrator" if (has_c_family or has_make) else "MultiFileOrchestrator"
        _mark_analysis_phase(ws, "step2_phase2", "running")
        logger.info(
            "[Phase 2/6 START] Orchestrator — job=%s type=%s files=%d",
            job_id, orch_type, len(file_paths),
        )
        _t = time.monotonic()

        if has_c_family or has_make:
            orchestrator = MixedLanguageOrchestrator(
                cache_dir=cache_dir,
                search_paths=final_search_paths,
                macro_libs=macro_libs,
                universe_asm_names=universe_asm_names if options.get("load_universe") else None,
                universe_cpp_names=universe_cpp_names if options.get("load_universe") else None,
            )
        else:
            orchestrator = MultiFileOrchestrator(
                cache_dir=cache_dir,
                search_paths=final_search_paths,
                macro_libs=macro_libs,
                universe_asm_names=universe_asm_names if options.get("load_universe") else None,
                universe_cpp_names=universe_cpp_names if options.get("load_universe") else None,
            )

        from api.config import settings
        print(f"--- Phase 2/6: Multi-file orchestration — {orch_type} ---")
        print(f"  Files    : {len(file_paths)} source file(s)")
        print(f"  Workers  : {settings.ANALYSIS_WORKERS} analysis worker(s), batch_size={settings.ANALYSIS_BATCH_SIZE}, file_timeout={settings.FILE_TIMEOUT_SECONDS}s")
        print("  Sub-phases inside orchestrator:")
        print("    1. Batch analysis  — parse each file for symbols, call-graph nodes, lineage edges")
        print("    2. Cross-file link — resolve EXTRN/ENTRY refs, link call-graph edges across files")
        print("    3. Macro collect   — auto-discover macro definitions from search paths")
        print("    4. Macro expand    — expand macros per-file, rebuild expanded call graphs")
        print("    5. Lineage stitch  — merge per-file lineage graphs into one global graph", flush=True)
        print(f"Analyzing {len(file_paths)} file(s) "
              f"({settings.ANALYSIS_WORKERS} worker(s), batch={settings.ANALYSIS_BATCH_SIZE}, "
              f"file_timeout={settings.FILE_TIMEOUT_SECONDS}s)...")
        result = orchestrator.analyze_files(
            file_paths,
            analysis_workers=settings.ANALYSIS_WORKERS,
            batch_size=settings.ANALYSIS_BATCH_SIZE,
            file_timeout=settings.FILE_TIMEOUT_SECONDS,
        )
        # Extract cache dirs for metadata evicted during Phase 1 collection.
        # Set by both MixedLanguageOrchestrator and (now) MultiFileOrchestrator.
        _block_cache_dir: Optional[Path] = getattr(result, "block_cache_dir", None)
        _lmi_cache_dir: Optional[Path] = getattr(result, "lmi_cache_dir", None)
        _lineage_cache_dir: Optional[Path] = getattr(result, "lineage_cache_dir", None)
        _macro_exp_cache_dir: Optional[Path] = getattr(result, "macro_exp_cache_dir", None)
        _unit_cache_dir: Optional[Path] = getattr(result, "unit_cache_dir", None)
        _sym_cache_dir: Optional[Path] = getattr(result, "sym_cache_dir", None)
        _call_graph_cache_dir: Optional[Path] = getattr(result, "call_graph_cache_dir", None)
        _mark_analysis_phase(ws, "step2_phase2", "success")
        logger.info(
            "[Phase 2/6 DONE] Per-file analysis — files=%d elapsed=%.1fs",
            len(result.file_results), time.monotonic() - _t,
        )
        # sym_compact_cache is only needed inside the orchestrator for Phase 2
        # cross-file resolution (_build_global_registry + _link_call_graphs).
        # Delete it now — after step2_phase2 is marked success — so that if the
        # process is killed and resumed, the resume path (step2_phase4*) doesn't
        # need it (it's not in the manifest) and an early-phase resume
        # (step2_phase2) re-runs the full orchestrator which recreates it.
        try:
            _symc_dir = cache_dir / "sym_compact_cache"
            if _symc_dir.exists():
                shutil.rmtree(_symc_dir, ignore_errors=True)
                logger.info("step2_phase2 cleanup: sym_compact_cache deleted — %s", _symc_dir)
        except Exception:
            pass
    else:
        # Restore cache dir paths from the manifest
        from api.config import settings
        _block_cache_dir   = Path(_ckpt_manifest["block_cache_dir"])   if _ckpt_manifest.get("block_cache_dir")   else None
        _lmi_cache_dir     = Path(_ckpt_manifest["lmi_cache_dir"])     if _ckpt_manifest.get("lmi_cache_dir")     else None
        _lineage_cache_dir = Path(_ckpt_manifest["lineage_cache_dir"]) if _ckpt_manifest.get("lineage_cache_dir") else None
        _macro_exp_cache_dir = Path(_ckpt_manifest["macro_exp_cache_dir"]) if _ckpt_manifest.get("macro_exp_cache_dir") else None
        _unit_cache_dir    = Path(_ckpt_manifest["unit_cache_dir"])    if _ckpt_manifest.get("unit_cache_dir")    else None
        _sym_cache_dir     = Path(_ckpt_manifest["sym_cache_dir"])     if _ckpt_manifest.get("sym_cache_dir")     else None
        _call_graph_cache_dir = Path(_ckpt_manifest["call_graph_cache_dir"]) if _ckpt_manifest.get("call_graph_cache_dir") else None
        result = None  # no in-memory result; everything comes from disk
        _mark_analysis_phase(ws, "step2_phase2", "success")

    # ------------------------------------------------------------------
    # JSON export setup (needed for both normal and resume paths)
    # ------------------------------------------------------------------
    emitter = JSONEmitter()
    reviewer = None
    if not options.get("no_coverage_review", False):
        try:
            from tools.review_parser_output import review as reviewer
        except Exception as exc:
            print(f"Warning: Could not load coverage reviewer ({exc}); skipping.")
            reviewer = None

    coverage_review_exts = asm_exts | c_exts | cpp_exts

    lineage_name: str = options.get("lineage_name", "")
    do_lineage = bool(options.get("lineage_export") and lineage_name)
    skip_business_summary: bool = bool(options.get("skip_business_summary", False))
    lineage_graphs: dict = {}

    # ------------------------------------------------------------------
    # Variable lineage tracing (optional, normal path only — needs live ctx)
    # ------------------------------------------------------------------
    if not _resuming_from_ckpt and lineage_name and result is not None:
        lineage_kind: str = options.get("lineage_kind", "variable")
        lineage_direction: str = options.get("lineage_direction", "backward")
        lineage_depth: int = int(options.get("lineage_depth", 10))

        for file_result in result.file_results:
            lineage_graph = file_result.analysis_context.get_metadata("variable_lineage")
            if not lineage_graph:
                continue
            trace_edges = lineage_graph.trace(
                lineage_name, lineage_kind, lineage_direction, lineage_depth, None,
            )
            file_result.analysis_context.add_metadata(
                "lineage_trace",
                [edge.to_dict() for edge in trace_edges],
            )

    # ------------------------------------------------------------------
    # Phase 3/6 — GVL streaming write  (skipped when resuming)
    # ------------------------------------------------------------------
    if not _resuming_from_ckpt and result is not None:
        # Write global_variable_lineage ONCE as a shared file.
        # We use _stream_write_gvl() which iterates node-by-node and
        # edge-by-edge to avoid the ~700 MB transient dict spike.
        _mark_analysis_phase(ws, "step2_phase3", "running")
        logger.info("[Phase 3/6 START] GVL streaming write — job=%s", job_id)
        print("--- Phase 3/6: Global variable lineage write ---")
        print("  Action  : serialising the global variable lineage graph → global_variable_lineage.json")
        print("  Method  : streaming node-by-node + edge-by-edge msgpack write (avoids ~700 MB dict spike).", flush=True)
        _t = time.monotonic()
        _trim_heap("before global lineage write")
        _gvl_nodes = 0
        _gvl_edges = 0
        if result.file_results:
            _first_ctx = result.file_results[0].analysis_context
            _graph_obj = _first_ctx.get_metadata("global_variable_lineage") if _first_ctx else None
            if _graph_obj is not None:
                _gvl_nodes = len(_graph_obj.nodes)
                _gvl_edges = (
                    getattr(_graph_obj, "_p2_edge_count", 0) + len(_graph_obj.edges)
                )
                _gvl_path = output_dir / "global_variable_lineage.json"
                _stream_write_gvl(_graph_obj, _gvl_path)
                # Release GVL file page cache immediately to reclaim cgroup headroom.
                try:
                    with open(_gvl_path, "rb") as _fh:
                        os.posix_fadvise(_fh.fileno(), 0, 0, 4)  # 4 = POSIX_FADV_DONTNEED
                except Exception:
                    pass
                print(f"Wrote global lineage: {_gvl_path} ({_gvl_nodes} nodes, {_gvl_edges} edges)")
            del _graph_obj
            _trim_heap("after global lineage streamed (no dict spike)")
        _mark_analysis_phase(ws, "step2_phase3", "success")
        logger.info(
            "[Phase 3/6 DONE] GVL write — nodes=%d edges=%d elapsed=%.1fs",
            _gvl_nodes, _gvl_edges, time.monotonic() - _t,
        )

        # Drop all shared references to the global lineage graph.
        for fr in result.file_results:
            if fr.analysis_context is not None:
                fr.analysis_context.metadata.pop("global_variable_lineage", None)
        if hasattr(result, "global_lineage"):
            result.global_lineage = None
        gc.collect()
        _trim_heap("after global lineage graph freed")

        # Sort: ASM/MAC first so their contexts free before large C++ contexts hit memory.
        _cpp_exts = c_exts | cpp_exts
        result.file_results.sort(
            key=lambda fr: (1 if fr.file_path.suffix.lower() in _cpp_exts else 0)
        )

        # ------------------------------------------------------------------
        # Emission checkpoint save
        # Evict every AnalysisContext to disk so that:
        #   1. Phase 4/6 loads each context on-demand (one at a time).
        #   2. If Phase 4/6 is interrupted, the next run detects this
        #      manifest and skips the entire orchestrator.
        # After eviction, all contexts are None in memory and each file's
        # data lives solely in the per-file cache dirs on disk.
        # ------------------------------------------------------------------
        _mark_analysis_phase(ws, "step2_phase4_prep", "running")
        print("--- Saving emission checkpoint (evicting contexts to disk) ---", flush=True)
        _ctx_cache_dir = _save_emission_checkpoint(
            result.file_results,
            cache_dir,
            input_dir,
            output_dir,
            _block_cache_dir,
            _lmi_cache_dir,
            _lineage_cache_dir,
            _macro_exp_cache_dir,
            do_lineage,
            skip_business_summary,
            c_exts,
            cpp_exts,
            unit_cache_dir=_unit_cache_dir,
            sym_cache_dir=_sym_cache_dir,
            call_graph_cache_dir=_call_graph_cache_dir,
        )
        gc.collect()
        _trim_heap("after context eviction to checkpoint (all contexts now on disk)")
        _mark_analysis_phase(ws, "step2_phase4_prep", "success")

        # Build the emission list from the now-evicted result, then free the
        # orchestrator result object.  result.global_registry (GlobalSymbolRegistry)
        # can hold 4–8 GB of cross-file symbol data for large corpora — keeping
        # it alive during Phase 4/6 leaves almost no headroom for emission and
        # can cause SIGKILL even though per-file context loading is only a few MB.
        # All data needed for emission (per-file contexts, block/lmi/macro caches)
        # is on disk; the global registry is no longer needed.
        _emit_file_results = result.file_results  # capture the list
        result.file_results = []                   # break result's reference to it
        if hasattr(result, "global_registry"):
            result.global_registry = None
        if hasattr(result, "unresolved_externals"):
            result.unresolved_externals = None
        del result                                 # allow MixedAnalysisResult to be GC'd
        gc.collect()
        _trim_heap("after orchestrator result freed (global_registry + registry freed)")
    else:
        # Resume path: reconstruct minimal file_result stubs from manifest
        from types import SimpleNamespace as _NS
        _cpp_exts_m = set(_ckpt_manifest.get("c_exts", [])) | set(_ckpt_manifest.get("cpp_exts", []))
        _emit_file_results = [
            _NS(file_path=Path(fp_str), analysis_context=None)
            for fp_str in _ckpt_manifest.get("file_paths", [])
        ]
        # Same sort order as the normal path (ASM first, C++ last)
        _emit_file_results.sort(
            key=lambda fr: (1 if fr.file_path.suffix.lower() in _cpp_exts_m else 0)
        )
        _mark_analysis_phase(ws, "step2_phase3", "success")
        _cpp_exts = _cpp_exts_m

    # ------------------------------------------------------------------
    # Phase 4/6 — Blueprint emission (memory-aware lazy loop)
    #
    # Design:
    #   • Files are emitted up to emission_workers concurrently.
    #   • Before submitting each new file the live cgroup memory ratio is
    #     checked.  When it exceeds _EMIT_MEM_HIGH_RATIO (85 %) no new file
    #     is submitted until at least one in-progress worker finishes and
    #     its context is freed.  The process is NEVER killed — it simply
    #     waits for headroom to open up.
    #   • Lazy loading: _emit_one_file reloads block_analysis,
    #     line_metadata_index, and macro_expansions from disk just before
    #     calling emitter.emit(), then sets analysis_context = None
    #     immediately after.  Files waiting in the queue hold NO context
    #     data in memory.
    #   • Hung tasks: if a future runs longer than _emit_timeout seconds
    #     it is logged and abandoned (thread pool eventually reclaims it).
    # ------------------------------------------------------------------
    # Pause new file submissions when cgroup usage exceeds this fraction.
    # 0.65 leaves 35 % headroom — more conservative than the old 0.80 to
    # account for concurrent genai.Client cycles, page cache accumulation,
    # and macro_exp/lmi reload spikes before the OOM killer can fire.
    _EMIT_MEM_HIGH_RATIO = 0.65
    _EMIT_POLL_SECS      = 2.0    # block-wait interval when memory is high

    def _cgroup_ratio() -> float:
        """Live cgroup usage / limit (0.0–1.0); 0.0 when unavailable."""
        try:
            _lim = _read_cgroup_memory_limit_mb()
            return (_current_cgroup_usage_mb() / _lim) if _lim else 0.0
        except Exception:
            return 0.0

    _emit_configured = max(1, settings.ANALYSIS_WORKERS)
    # Hard ceiling on emission parallelism.  Each worker concurrently holds
    # a loaded context + block/lmi/macro_exp/sym data + a json_dict.  For
    # large ASM corpora this can be 200–500 MB per worker; combined with
    # genai.Client cycle accumulation and VirtioFS page cache, allowing the
    # formula to pick 4–6 workers causes cgroup to reach the container limit.
    # Cap at 2 so at most 2 files are emitted simultaneously; the cgroup
    # memory-ratio guard (_EMIT_MEM_HIGH_RATIO) still dynamically throttles
    # to 1 worker when cgroup > 65 %.
    _EMIT_MAX_WORKERS = 2
    _mem_avail_mb = 0
    try:
        _cgroup_limit_mb = _read_cgroup_memory_limit_mb()
        if _cgroup_limit_mb is not None:
            # Use cgroup usage (includes page cache) not VmRSS: Docker's OOM
            # killer counts page cache against the limit.
            _cgroup_usage_mb = _current_cgroup_usage_mb()
            _mem_avail_mb = max(0, _cgroup_limit_mb - _cgroup_usage_mb)
        else:
            with open("/proc/meminfo") as _fh:
                _minfo = {line.split(":")[0]: int(line.split()[1]) for line in _fh}
            _mem_avail_mb = _minfo.get("MemAvailable", 0) // 1024  # kB → MB
        emission_workers = max(1, min(_emit_configured, _mem_avail_mb // 2000, _EMIT_MAX_WORKERS))
    except Exception:
        emission_workers = 1
    # Skip files whose blueprints already exist on disk (from a previous run).
    _already_emitted = 0
    _remaining_all: list = []
    for _fr in _emit_file_results:
        try:
            _rel = _fr.file_path.relative_to(input_dir)
            _expected_out = output_dir / (str(_rel) + ".json")
        except ValueError:
            _expected_out = output_dir / f"{_fr.file_path.name}.json"
        if _expected_out.exists():
            _fr.analysis_context = None  # free any in-memory context (likely None already)
            _already_emitted += 1
        else:
            _remaining_all.append(_fr)

    if _already_emitted:
        logger.info(
            "Phase 4/6: %d blueprint(s) already emitted (skipping), %d remaining.",
            _already_emitted, len(_remaining_all),
        )
        print(
            f"[Phase 4/6] Skipping {_already_emitted} already-emitted blueprint(s); "
            f"{len(_remaining_all)} remaining.",
            flush=True,
        )

    _mark_analysis_phase(ws, "step2_phase4", "running")
    logger.info(
        "[Phase 4/6 START] Blueprint emission — job=%s blueprints=%d threads=%d mem_avail_mb=%d",
        job_id, len(_emit_file_results), emission_workers, _mem_avail_mb,
    )
    print(f"--- Phase 4/6: Blueprint emission ({len(_emit_file_results)} file(s) total, "
          f"{len(_remaining_all)} to emit, {emission_workers} thread(s), "
          f"{_mem_avail_mb if _mem_avail_mb else '?'} MB avail) ---")
    print("  Action  : writing one msgpack blueprint per source file.")
    print("  Content : symbols, call graph, variable lineage, macro expansions,")
    print("            business summary (LLM), and coverage review score.")
    print("  Memory  : lazy-load context data per file; release immediately after write.")
    print(f"  Guard   : pause new submissions when cgroup > {_EMIT_MEM_HIGH_RATIO*100:.0f}%; "
          "wait for active tasks to free memory (no OOM-kill).", flush=True)
    _t = time.monotonic()
    # ── macOS balloon-driver settle wait ─────────────────────────────────────
    # During stitching, cgroup may have peaked at 80–90% of the container limit.
    # Docker Desktop (macOS) responds to high VM memory usage by inflating a
    # hypervisor balloon, reclaiming physical pages from the Linux guest.  Even
    # after Python frees the stitching objects (cgroup drops to ~55%), the balloon
    # stays inflated for tens of seconds.  If emission starts while the balloon is
    # still inflated, the Linux OOM killer fires on the very first file load
    # because the guest's physical memory budget is still squeezed.
    #
    # We wait here until cgroup has been stable below 50% for 15 consecutive
    # seconds (giving the balloon time to deflate), or 120 s max.
    _BALLOON_SAFE_RATIO   = 0.50
    _BALLOON_STABLE_SECS  = 15
    _BALLOON_MAX_SECS     = 120
    _b_lim = _read_cgroup_memory_limit_mb()
    if _b_lim:
        _b_start      = time.monotonic()
        _b_stable_at  = None
        while True:
            gc.collect()
            if _HAS_MALLOC_TRIM:
                _libc.malloc_trim(0)
            _b_ratio   = _current_cgroup_usage_mb() / _b_lim
            _b_elapsed = time.monotonic() - _b_start
            if _b_ratio < _BALLOON_SAFE_RATIO:
                if _b_stable_at is None:
                    _b_stable_at = time.monotonic()
                elif time.monotonic() - _b_stable_at >= _BALLOON_STABLE_SECS:
                    logger.info(
                        "balloon settle: cgroup %.1f%% stable for %.0fs — starting emission",
                        _b_ratio * 100, _BALLOON_STABLE_SECS,
                    )
                    break
            else:
                _b_stable_at = None  # ratio crept back up; reset stable timer
            if _b_elapsed >= _BALLOON_MAX_SECS:
                logger.warning(
                    "balloon settle: timed out after %.0fs at cgroup %.1f%% — proceeding anyway",
                    _b_elapsed, _b_ratio * 100,
                )
                break
            time.sleep(5)
    # ─────────────────────────────────────────────────────────────────────────
    _trim_heap("before emission (contexts on disk, loading lazily)")
    # Raise the glibc mmap threshold to 2 MB before emission.  The macro_exp
    # cache files can exceed 983 KB — above glibc's default 128 KB threshold —
    # which means each load/free cycle calls mmap()+munmap() and returns pages
    # directly to the kernel.  On Docker Desktop / macOS the hypervisor can
    # reclaim those pages under host memory pressure before the next allocation,
    # which triggers the Linux OOM killer even though cgroup usage appears low.
    # Setting the threshold to 2 MB keeps these allocations in the brk heap;
    # pages are reused across files rather than returned to the kernel per file.
    _set_mmap_threshold(2 * 1024 * 1024)  # 2 MB — covers all macro_exp files
    print(f"Emitting {len(_remaining_all)} blueprint(s) ({emission_workers} thread(s), "
          f"{_mem_avail_mb if _mem_avail_mb else '?'} MB avail)...")

    # Per-task timeout: LLM timeout + 60 s buffer; fallback 600 s.
    _emit_timeout = (float(settings.LLM_CALL_TIMEOUT) + 60.0) if settings.LLM_CALL_TIMEOUT > 0 else 600.0

    _remaining   = _remaining_all          # files not yet submitted
    _active: dict = {}                     # future → file_result
    _sub_time: dict = {}                   # future → submission time (hung-task detection)
    _processed   = _already_emitted        # count already-emitted as done
    _total        = len(_emit_file_results)

    with ThreadPoolExecutor(max_workers=emission_workers) as pool:
        while _remaining or _active:
            # ── 1. Drain completed (and timed-out) futures ───────────────────
            if _active:
                _done, _ = _futures_wait(
                    list(_active),
                    # Block up to _EMIT_POLL_SECS when more files are pending so
                    # we can re-check memory; block indefinitely when all files
                    # have been submitted and we just need the last few to finish.
                    timeout=_EMIT_POLL_SECS if _remaining else None,
                    return_when=_FIRST_COMPLETED,
                )

                # Detect hung tasks that have exceeded the per-file timeout.
                _now = time.monotonic()
                _stuck = [
                    f for f in _active
                    if f not in _done and _now - _sub_time.get(f, _now) > _emit_timeout
                ]
                for fut in _stuck:
                    fr = _active.pop(fut)
                    _sub_time.pop(fut, None)
                    logger.warning(
                        "Phase 4/6: emission timed out (>%.0fs) for %s, skipping.",
                        _emit_timeout, fr.file_path.name,
                    )
                    print(f"Warning: Blueprint emission timed out for {fr.file_path.name}, skipping.")
                    fr.analysis_context = None  # release lazily-loaded data
                    _processed += 1

                # Collect results from completed futures.
                for fut in _done:
                    fr = _active.pop(fut)
                    _sub_time.pop(fut, None)
                    try:
                        input_file, lineage_graph, log_lines = fut.result()
                    except Exception as exc:
                        input_file = fr.file_path
                        log_lines = [f"Warning: Blueprint emission failed for {input_file.name}: {exc}"]
                        lineage_graph = None
                    # Release lazily-loaded context data immediately — this is
                    # the key memory reclaim step; the next file is not loaded
                    # into memory until a slot is available AND memory allows.
                    fr.analysis_context = None
                    for line in log_lines:
                        print(line)
                    if do_lineage and lineage_graph is not None:
                        lineage_graphs[input_file] = lineage_graph
                    _processed += 1
                    # Run GC frequently to collect reference cycles from
                    # genai.Client, httpx, and json_dict objects before they
                    # accumulate into multi-GB heap pressure.  The old cadence
                    # of every 200 files allowed ~4 GB of cyclic garbage to
                    # build up with 6 workers and fast Gemini responses.
                    if _processed % 5 == 0:
                        gc.collect()
                        if _HAS_MALLOC_TRIM:
                            _libc.malloc_trim(0)
                    if _processed % 50 == 0:
                        _trim_heap(f"after emit {_processed}/{_total}")

            # ── 2. Submit new files (memory-aware) ───────────────────────────
            while _remaining and len(_active) < emission_workers:
                # Check memory only when there are active workers to wait for.
                # If _active is empty we MUST submit at least one file — there
                # is nothing in flight to wait for and no forward progress can
                # be made by waiting.
                if _active:
                    _ratio = _cgroup_ratio()
                    if _ratio > _EMIT_MEM_HIGH_RATIO:
                        # Actively free Python heap and glibc pages before waiting.
                        # This helps release any cyclic garbage and fragmented
                        # allocator pages that inflate cgroup usage independently
                        # of page cache (which fadvise already handles per-file).
                        gc.collect()
                        if _HAS_MALLOC_TRIM:
                            _libc.malloc_trim(0)
                        _ratio_after = _cgroup_ratio()
                        logger.warning(
                            "Phase 4/6: cgroup at %.1f%% → %.1f%% after GC "
                            "(threshold %.0f%%) — pausing submission, waiting for "
                            "%d active task(s) to free memory.",
                            _ratio * 100, _ratio_after * 100,
                            _EMIT_MEM_HIGH_RATIO * 100, len(_active),
                        )
                        print(
                            f"[{time.strftime('%H:%M:%S')}] Phase 4/6: MEM-WAIT "
                            f"({_ratio*100:.0f}% → {_ratio_after*100:.0f}% after GC, "
                            f"threshold {_EMIT_MEM_HIGH_RATIO*100:.0f}%) — "
                            f"waiting for {len(_active)} active task(s) to complete "
                            f"before loading next file ({_processed}/{_total} done).",
                            flush=True,
                        )
                        break  # stop submitting; outer loop drains _active first
                fr = _remaining.pop(0)
                # Lazy-load context from disk if it was evicted to the checkpoint.
                # This is the normal case after _save_emission_checkpoint evicts
                # all contexts, and also for the resume path where contexts are
                # never in memory.  Only one context is in memory per active worker.
                if fr.analysis_context is None and _ctx_cache_dir is not None:
                    fr.analysis_context = _load_context(_ctx_cache_dir, fr.file_path)
                    if fr.analysis_context is None:
                        logger.warning(
                            "Phase 4/6: context missing for %s (not in checkpoint), skipping.",
                            fr.file_path.name,
                        )
                        print(f"Warning: context missing for {fr.file_path.name}, skipping.")
                        _processed += 1
                        continue
                fut = pool.submit(
                    _emit_one_file,
                    fr, input_dir, output_dir, do_lineage, reviewer, coverage_review_exts,
                    skip_business_summary,
                    _block_cache_dir,
                    _lmi_cache_dir,
                    _lineage_cache_dir,
                    _macro_exp_cache_dir,
                    _unit_cache_dir,
                    _sym_cache_dir,
                    _call_graph_cache_dir,
                )
                _active[fut] = fr
                _sub_time[fut] = time.monotonic()

    gc.collect()
    _trim_heap("after emission (all contexts freed)")
    _mark_analysis_phase(ws, "step2_phase4", "success")
    logger.info(
        "[Phase 4/6 DONE] Blueprint emission — blueprints=%d elapsed=%.1fs",
        len(_emit_file_results), time.monotonic() - _t,
    )

    # ------------------------------------------------------------------
    # Post-emission cache cleanup — all per-file cache dirs are now fully
    # consumed.  Delete them to reclaim disk space (can be 10–40 GB for a
    # large corpus) and remove stale page-cache pressure before Phase 5/6.
    # ------------------------------------------------------------------
    _post_emit_cache_dirs = [
        _block_cache_dir,
        _lmi_cache_dir,
        _lineage_cache_dir,
        _macro_exp_cache_dir,
        _unit_cache_dir,
        _sym_cache_dir,
        _call_graph_cache_dir,
        # ctx_cache_dir holds serialised AnalysisContext objects used only
        # during emission.  step2_phase4 success guarantees all blueprints
        # are written, so contexts are no longer needed.
        _ctx_cache_dir,
    ]
    _deleted_dirs = 0
    for _cd in _post_emit_cache_dirs:
        if _cd is None:
            continue
        _cd = Path(_cd) if not isinstance(_cd, Path) else _cd
        try:
            if _cd.exists():
                shutil.rmtree(_cd, ignore_errors=True)
                _deleted_dirs += 1
        except Exception:
            pass
    if _deleted_dirs:
        logger.info(
            "Post-emission cleanup: deleted %d cache dir(s) — disk space reclaimed.",
            _deleted_dirs,
        )
        print(
            f"[{time.strftime('%H:%M:%S')}] Post-emission cleanup: {_deleted_dirs} cache "
            f"dir(s) deleted (block, lmi, lineage, macro_exp, unit, sym, call_graph, ctx).",
            flush=True,
        )

    # ------------------------------------------------------------------
    # Optional lineage export (uses pre-extracted graphs; contexts already freed)
    # ------------------------------------------------------------------
    if do_lineage and lineage_graphs:
        lineage_export_dir = output_dir / "lineage"
        lineage_export_dir.mkdir(parents=True, exist_ok=True)
        for file_path, graph in lineage_graphs.items():
            out_file = lineage_export_dir / f"{file_path.stem}.lineage.json"
            out_file.write_text(json.dumps(graph.to_dict(), indent=2))
            print(f"Wrote lineage: {out_file}")

    # ------------------------------------------------------------------
    # Phase 5/6 — Finalise
    # ------------------------------------------------------------------
    _mark_analysis_phase(ws, "step2_phase5", "running")
    logger.info("[Phase 5/6 START] Heap trim + finalize — job=%s", job_id)
    print("--- Phase 5/6: Finalise ---")
    print("  Collecting list of written blueprint files and marking Step 2 complete.", flush=True)
    _t = time.monotonic()
    result_files = ws.collect_output_files()
    if update_status:
        ws.set_status("success", result_files=result_files)
    _mark_analysis_phase(ws, "step2_phase5", "success")
    logger.info(
        "[Phase 5/6 DONE] Analysis complete — job=%s output_files=%d total_elapsed=%.1fs",
        job_id, len(result_files), time.monotonic() - _analysis_start,
    )

    return {
        "job_id": ws.job_id,
        "status": "success",
        "files_analyzed": len(_emit_file_results),
        "output_files": len(result_files),
    }
