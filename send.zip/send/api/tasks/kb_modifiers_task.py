"""Celery task: find variable modifiers against an existing KB output."""

from __future__ import annotations

import json
import logging
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.config import settings
from api.tasks.celery_app import celery_app
from api.tasks._task_utils import redirect_output_to_log, job_log_handler
from api.storage.workspace import WorkspaceManager

logger = logging.getLogger(__name__)


@celery_app.task(bind=True, name="asm.kb_find_modifiers")
def run_kb_find_modifiers(self, job_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    """
    Find every blueprint in a KB that modifies a variable via SETTER instructions,
    then return the call chains through each modifying file.

    Reads blueprints and file_call_graph.json directly from the KB output directory —
    no file upload needed.
    """
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run(ws, options)
            except SoftTimeLimitExceeded:
                msg = "Task exceeded soft time limit and was aborted."
                logger.error("Job %s: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s failed: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}


def _run(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    from find_variable_modifiers import (
        scan_blueprint_for_setters,
        scan_cpp_blueprint_for_setters,
        find_chains_through,
    )
    from filter_subset_chains import filter_subset_chains
    from build_modifier_index import INDEX_FILENAME
    from blueprint_io import load_blueprint
    from llm.chain_explainer import (
        explain_chain,
        get_cached_chain_summary,
        graph_fingerprint,
        load_chain_summaries_cache,
    )

    job_id = ws.job_id
    _task_start = time.monotonic()

    kb_id: str = options["kb_id"]
    variable: str = options["variable_name"]
    max_depth: Optional[int] = options.get("max_depth")
    no_chains: bool = bool(options.get("no_chains", False))
    do_filter: bool = bool(options.get("filter_subsets", True))

    kb_output = settings.JOBS_BASE_DIR / kb_id / "output"
    if not kb_output.exists():
        raise FileNotFoundError(f"KB output directory not found: {kb_output}")

    from api.tasks._task_utils import find_blueprint_dir

    # Phase 1/3 — Load modifier index and call graph
    logger.info(
        "[Phase 1/3 START] Load modifier index — job=%s kb=%s variable=%s",
        job_id, kb_id, variable,
    )
    _t = time.monotonic()
    blueprint_dir = find_blueprint_dir(kb_output)
    if blueprint_dir is None:
        raise FileNotFoundError(f"No .asm.json blueprint files found under {kb_output}")

    # Load call graph — DB-first, JSON fallback
    graph_payload: Optional[Dict[str, Any]] = None
    warnings: List[str] = []

    if not no_chains:
        graph_file = kb_output / "file_call_graph.json"
        try:
            from api.index_db.readers import get_call_graph_slim
            _gp = get_call_graph_slim(
                kb_id,
                fallback_path=graph_file if graph_file.exists() else None,
            )
            if _gp.get("nodes") or _gp.get("edges"):
                graph_payload = _gp
                print(f"[graph] kb={kb_id} ({len(graph_payload.get('nodes', []))} nodes, {len(graph_payload.get('edges', []))} edges)")
            else:
                msg = "file_call_graph.json not found in KB output. Re-run the pipeline to generate it."
                warnings.append(msg)
                print(f"WARNING: {msg}")
        except Exception as exc:
            msg = f"Could not load call graph: {exc}"
            warnings.append(msg)
            print(f"WARNING: {msg}")

    # ── Resolve which blueprint files to scan ────────────────────────────────
    # Fast path: use the pre-built index to find only the files that modify this
    # variable (O(1) lookup).  Fallback: scan every blueprint (O(N)).
    # Use single-variable DB lookup instead of loading the full modifier index.
    from api.index_db.readers import get_modifier_files as _get_modifier_files
    _idx_path = kb_output / INDEX_FILENAME
    candidate_stems = _get_modifier_files(kb_id, variable, fallback_path=_idx_path)
    # Index is "available" if the JSON file exists or the DB returned any results.
    _has_modifier_index = bool(candidate_stems) or _idx_path.exists()
    logger.info(
        "[Phase 1/3 DONE] Load modifier index — index_found=%s elapsed=%.1fs",
        _has_modifier_index, time.monotonic() - _t,
    )
    setter_hits: Dict[str, List[Dict[str, Any]]] = {}

    if _has_modifier_index:
        # candidate_stems already resolved via DB-first single-variable lookup
        files_to_scan: List[Path] = []
        for stem in candidate_stems:
            for suffix in (".asm.json", ".mac.json", ".cpp.json"):
                p = blueprint_dir / f"{stem}{suffix}"
                if p.exists():
                    files_to_scan.append(p)
        print(
            f"Index lookup: {len(candidate_stems)} candidate stem(s) → "
            f"scanning {len(files_to_scan)} file(s) for '{variable}'"
        )
    else:
        files_to_scan = sorted(
            list(blueprint_dir.glob("*.asm.json"))
            + list(blueprint_dir.glob("*.mac.json"))
            + list(blueprint_dir.glob("*.cpp.json"))
        )
        if not files_to_scan:
            raise FileNotFoundError(f"No blueprint files in {blueprint_dir}")
        n_asm = sum(1 for f in files_to_scan if f.name.endswith(".asm.json"))
        n_mac = sum(1 for f in files_to_scan if f.name.endswith(".mac.json"))
        n_cpp = sum(1 for f in files_to_scan if f.name.endswith(".cpp.json"))
        print(
            f"No modifier index found; scanning all {len(files_to_scan)} blueprints "
            f"({n_asm} asm, {n_mac} mac, {n_cpp} cpp) for '{variable}' (re-run pipeline to build index)"
        )

    # Phase 2/3 — Scan blueprints for setter instructions
    logger.info(
        "[Phase 2/3 START] Blueprint scan — job=%s files_to_scan=%d variable=%s",
        job_id, len(files_to_scan), variable,
    )
    _t = time.monotonic()
    # ── Scan the resolved file list ──────────────────────────────────────────
    for bp_path in files_to_scan:
        if bp_path.name.endswith(".cpp.json"):
            hits, err = scan_cpp_blueprint_for_setters(bp_path, variable)
        else:
            hits, err = scan_blueprint_for_setters(bp_path, variable)
        if err:
            warnings.append(err)
            print(f"  WARNING: {err}")
            continue
        if hits:
            setter_hits[hits[0]["file_stem"]] = hits

    modifying_files = sorted(setter_hits.keys())
    logger.info(
        "[Phase 2/3 DONE] Blueprint scan — files_scanned=%d modifying_files=%d elapsed=%.1fs",
        len(files_to_scan), len(modifying_files), time.monotonic() - _t,
    )
    print(f"Found {len(modifying_files)} modifying file(s): {', '.join(modifying_files) or 'none'}")

    # ── C++ fallback ─────────────────────────────────────────────────────────
    # If no ASM/MAC modifiers were found, the variable may be a C++ struct field.
    # Query the global GVL for assignment ("assign") edges whose target node IDs
    # end with the variable name — these edges carry the source file path and
    # line number of each write site.  Group by file stem to build setter_hits
    # entries that the chain-building logic below can consume unchanged.
    if not setter_hits:
        try:
            from backward_traversal.utils.lazy_gvl import make_lazy_gvl, find_gvl_path
            from backward_traversal.utils.cpp_lineage_utils import find_cpp_seed_nodes

            _any_cpp_bp = next(blueprint_dir.glob("*.cpp.json"), None)
            _gvl_path = find_gvl_path(_any_cpp_bp) if _any_cpp_bp else None
            if _gvl_path and _gvl_path.exists():
                _gvl = make_lazy_gvl({"_gvl_path": str(_gvl_path)})
                if _gvl:
                    # Find GVL seed node IDs that represent this C++ variable.
                    _seed_ids = set(find_cpp_seed_nodes(_gvl, variable, {}, {}))
                    if _seed_ids:
                        import os as _os
                        _cpp_hits: Dict[str, List[Dict[str, Any]]] = {}
                        for _e in (_gvl.get("edges") or []):
                            _tgt = str(_e.get("target") or "")
                            if _tgt not in _seed_ids:
                                continue
                            _rel = str(_e.get("relation") or "")
                            if _rel not in ("assign", "define"):
                                continue
                            _src_file = str(_e.get("file") or "")
                            if not _src_file:
                                continue
                            _stem = _os.path.splitext(_os.path.basename(_src_file))[0]
                            # Only include stems that have a .cpp.json blueprint
                            if not (blueprint_dir / f"{_stem}.cpp.json").exists():
                                continue
                            _hit = {
                                "file_stem": _stem,
                                "variable": variable,
                                "instruction": "assign",
                                "line": _e.get("line"),
                                "expression": str(_e.get("expression") or "").strip(),
                                "file": _src_file,
                                "source_node": str(_e.get("source") or ""),
                                "target_node": _tgt,
                            }
                            _cpp_hits.setdefault(_stem, []).append(_hit)
                        if _cpp_hits:
                            setter_hits.update(_cpp_hits)
                            modifying_files = sorted(setter_hits.keys())
                            print(
                                f"C++ GVL fallback found {len(_cpp_hits)} modifying C++ file(s): "
                                f"{', '.join(sorted(_cpp_hits))}"
                            )
                        else:
                            print(f"C++ GVL fallback: seed nodes found but no assign edges with a known blueprint file.")
                    else:
                        print(f"C++ GVL fallback: no seed nodes found for '{variable}' in GVL.")
        except Exception as _exc:
            _msg = f"C++ GVL fallback failed: {_exc}"
            warnings.append(_msg)
            print(f"WARNING: {_msg}")

    graph_node_ids = (
        {n["id"] for n in graph_payload.get("nodes", [])} if graph_payload else set()
    )

    results: Dict[str, Any] = {}
    for stem in modifying_files:
        entry: Dict[str, Any] = {"setter_locations": setter_hits[stem]}

        if no_chains:
            entry["call_chains"] = None
        elif graph_payload is None:
            entry["call_chains"] = []
        elif stem not in graph_node_ids:
            msg = f"File '{stem}' not found in call graph; chain data unavailable."
            warnings.append(msg)
            entry["call_chains"] = []
            entry["call_chains_warning"] = msg
        else:
            raw_chains = find_chains_through(
                graph_payload, stem,
                int(max_depth) if max_depth is not None else None,
            )
            # Truncate each chain so the setter (stem) is always the LAST file.
            # find_chains_through returns full paths [upstream → stem → downstream].
            # For modifier chains we only want the upstream portion: [upstream → stem].
            seen_keys: set = set()
            truncated: list = []
            for c in raw_chains:
                files = c["files"]
                if stem in files:
                    end_idx = files.index(stem)
                    t_files = files[: end_idx + 1]
                    key = tuple(t_files)
                    if key not in seen_keys:
                        seen_keys.add(key)
                        hops = c.get("hops", [])
                        truncated.append({
                            "length": len(t_files) - 1,
                            "files": t_files,
                            "hops": hops[:end_idx] if hops else [],
                        })
            raw_chains = truncated
            if do_filter and raw_chains:
                kept, removed = filter_subset_chains(raw_chains)
                entry["call_chains"] = [{"length": c["length"], "files": c["files"]} for c in kept]
                entry["filtered_subset_chains"] = removed
                print(f"  {stem}: {len(raw_chains)} chains → {len(kept)} kept after subset filter")
            else:
                entry["call_chains"] = raw_chains

        results[stem] = entry

    # ------------------------------------------------------------------
    # Chain explanations (LLM, cache-first via chain_explanations.msgpack)
    # ------------------------------------------------------------------

    # Collect file summaries for all files that appear in any chain
    all_stems: set = set(modifying_files)
    for entry in results.values():
        for chain in (entry.get("call_chains") or []):
            all_stems.update(chain.get("files", []))

    file_summaries: Dict[str, str] = {}
    summary_dirs = [blueprint_dir] if blueprint_dir is not None else []
    summary_suffixes = (".asm.json", ".mac.json", ".cpp.json", ".hpp.json")
    for fstem in all_stems:
        got_summary = False
        for base_dir in summary_dirs:
            for suffix in summary_suffixes:
                bp = base_dir / f"{fstem}{suffix}"
                if not bp.exists():
                    continue
                try:
                    d = load_blueprint(bp, skip_global_lineage=True, keys={"business_summary"})
                    s = d.get("business_summary")
                    if s and isinstance(s, str) and s.strip():
                        file_summaries[fstem] = s.strip()
                        got_summary = True
                except Exception:
                    pass
                if got_summary:
                    break
            if got_summary:
                break

    # For stems that exist in the KB but don't yet have a business_summary,
    # generate + persist one via the shared fallback. Stems without a source
    # file (or whose LLM call fails) are silently omitted as before.
    missing_stems = [s for s in all_stems if s not in file_summaries]
    if missing_stems:
        from api.tasks.file_summary_fallback import ensure_many_business_summaries
        filled = ensure_many_business_summaries(kb_id, missing_stems, max_workers=4)
        for stem, text in filled.items():
            if text and text.strip():
                file_summaries[stem] = text.strip()

    precomputed_cache = load_chain_summaries_cache(kb_id)
    cached_fp = str(precomputed_cache.get("graph_fingerprint", ""))
    current_fp = graph_fingerprint(graph_payload) if graph_payload else ""
    cache_usable = bool(cached_fp and current_fp and cached_fp == current_fp)
    if cache_usable:
        print("Using precomputed chain_summaries.msgpack cache for modifiers response.")
    elif cached_fp:
        print("Precomputed chain summaries cache fingerprint mismatch; falling back to legacy chain explainer.")

    # Pre-compute per-hop call conditions once for every unique (from, to)
    # pair across all chains we may need to explain. Only needed for the
    # legacy fallback path (explain_chain); cache hits already carry the
    # precomputed condition-aware summaries.
    from api.tasks._task_utils import compute_chain_hop_conditions
    from cross_file_bridge import _discover_asm_dir
    all_chains: List[Dict[str, Any]] = []
    for entry in results.values():
        all_chains.extend(entry.get("call_chains") or [])
    asm_dir = _discover_asm_dir(blueprint_dir) if blueprint_dir else None
    hop_conditions = (
        compute_chain_hop_conditions(all_chains, blueprint_dir, asm_dir)
        if blueprint_dir
        else {}
    )

    def _per_chain_hc(chain: Dict[str, Any]) -> Dict[Any, List[Dict[str, Any]]]:
        return {
            (h.get("from"), h.get("to")): hop_conditions.get((h.get("from"), h.get("to")), [])
            for h in (chain.get("hops") or [])
            if h.get("from") and h.get("to")
        }

    for stem, entry in results.items():
        for chain in (entry.get("call_chains") or []):
            if cache_usable:
                cached_summary = get_cached_chain_summary(precomputed_cache, chain)
                if cached_summary:
                    chain["chain_explanation"] = cached_summary
                    print(f"  Chain summary cache hit for {chain.get('files', [])}")
                    continue
            try:
                chain["chain_explanation"] = explain_chain(
                    variable=variable,
                    chain=chain,
                    setter_locations=entry["setter_locations"],
                    file_summaries=file_summaries,
                    kb_id=kb_id,
                    hop_conditions=_per_chain_hc(chain),
                )
                print(f"  Explanation ready for chain {chain.get('files', [])}")
            except Exception as exc:
                chain["chain_explanation"] = None
                print(f"Warning: chain explanation failed for {stem}: {exc}")

    # Phase 3/3 — Extract chains and write output
    logger.info("[Phase 3/3 START] Extract chains + write output — job=%s", job_id)
    _t = time.monotonic()

    output: Dict[str, Any] = {
        "variable": variable,
        "kb_id": kb_id,
        "scanned_files": len(files_to_scan),
        "index_used": _has_modifier_index,
        "modifying_files": modifying_files,
        "results": results,
        "warnings": warnings,
    }

    variable_modifiers_dir = ws.output_dir / "variable_modifiers"
    variable_modifiers_dir.mkdir(parents=True, exist_ok=True)
    output_path = variable_modifiers_dir / f"{variable}_modifiers.json"
    output_path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(f"Wrote results to: {output_path}")

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)

    _chains_total = sum(
        len(entry.get("call_chains") or []) for entry in results.values()
    )
    logger.info(
        "[Phase 3/3 DONE] Chains extracted — chains_total=%d elapsed=%.1fs total_elapsed=%.1fs",
        _chains_total, time.monotonic() - _t, time.monotonic() - _task_start,
    )

    return {
        "job_id": ws.job_id,
        "status": "success",
        "variable": variable,
        "modifying_files": len(modifying_files),
        "output_files": len(result_files),
    }
