"""Celery task: variable usage search against an existing KB output."""

from __future__ import annotations

import fcntl
import logging
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.config import settings
from api.storage.workspace import WorkspaceManager
from api.tasks._task_utils import redirect_output_to_log, job_log_handler
from api.tasks.celery_app import celery_app
from api.utils.variable_search import search_variable_usages

logger = logging.getLogger(__name__)

_CONTEXT_LINES  = 5
_CACHE_FILENAME = "variable_usage.msgpack"


def _cache_path(kb_id: str) -> Path:
    return settings.JOBS_BASE_DIR / kb_id / "output" / _CACHE_FILENAME


# ---------------------------------------------------------------------------
# Shared cache helpers (used by individual task and batch task)
# ---------------------------------------------------------------------------

def _read_full_cache(kb_id: str) -> Dict[str, Any]:
    """Return the entire cache dict for a KB. Empty dict if absent or corrupt."""
    path = _cache_path(kb_id)
    if not path.exists():
        return {}
    try:
        import msgpack
        return msgpack.unpackb(path.read_bytes(), raw=False, strict_map_key=False)
    except Exception:
        return {}


def _read_cached(kb_id: str, var_upper: str) -> Optional[Dict]:
    """Return cached result for a single variable, or None if not cached."""
    return _read_full_cache(kb_id).get(var_upper)


def _write_batch_cached(kb_id: str, batch: Dict[str, Any]) -> None:
    """Merge a {var_upper: result} batch into the shared cache file under an exclusive lock."""
    import msgpack
    path = _cache_path(kb_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a+b") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        try:
            f.seek(0)
            content = f.read()
            cache = msgpack.unpackb(content, raw=False, strict_map_key=False) if content else {}
            cache.update(batch)
            f.seek(0)
            f.truncate()
            f.write(msgpack.packb(cache, use_bin_type=True))
        finally:
            fcntl.flock(f, fcntl.LOCK_UN)


def _write_cached(kb_id: str, var_upper: str, result: Dict) -> None:
    _write_batch_cached(kb_id, {var_upper: result})


# ---------------------------------------------------------------------------
# Celery task
# ---------------------------------------------------------------------------

@celery_app.task(bind=True, name="asm.variable_usage")
def run_variable_usage(self, job_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        with job_log_handler(ws.log_file, job_id=job_id):
            try:
                return _run(ws, options)
            except SoftTimeLimitExceeded:
                msg = "Task exceeded soft time limit and was aborted."
                logger.error("Job %s: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}"
                logger.exception("Job %s failed: %s", job_id, msg)
                ws.set_status("failed", error=msg)
                return {"job_id": job_id, "status": "failed", "error": msg}


def _run(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    job_id        = ws.job_id
    kb_id         = str(options["kb_id"])
    variable_name = str(options["variable_name"])
    var_upper     = variable_name.strip().upper()

    _task_start = time.monotonic()
    logger.info(
        "[Phase 1/2 START] Variable usage search — job=%s kb=%s variable=%s",
        job_id, kb_id, var_upper,
    )

    output_dir = settings.JOBS_BASE_DIR / kb_id / "output"
    input_dir  = settings.JOBS_BASE_DIR / kb_id / "input"

    if not output_dir.exists():
        raise FileNotFoundError(f"KB output directory not found: {output_dir}")
    # Accept either the SQLite DB (new pipeline) or the JSON fallback (legacy).
    _index_db_path = output_dir.parent / "index.db"
    _task_required_pairs = [
        (output_dir / "asm_variable_universe.db", output_dir / "asm_variable_universe.json"),
        (_index_db_path, output_dir / "variable_identity_index.json"),
    ]
    for db_path, json_path in _task_required_pairs:
        if not db_path.exists() and not json_path.exists():
            raise ValueError(
                f"Required index '{json_path.name}' (or DB equivalent '{db_path.name}') "
                f"not found. Run the pipeline for this KB first."
            )

    # Phase 1/2 — Cache check
    _t = time.monotonic()
    cached = _read_cached(kb_id, var_upper)
    if cached is not None:
        logger.info(
            "[Phase 1/2 DONE] Cache HIT — variable=%s elapsed=%.2fs total_elapsed=%.2fs",
            var_upper, time.monotonic() - _t, time.monotonic() - _task_start,
        )
        result_files = ws.collect_output_files()
        ws.set_status("success", result_files=result_files)
        return {
            "job_id":          ws.job_id,
            "status":          "success",
            "kb_id":           kb_id,
            "variable_name":   cached["variable_name"],
            "input_name":      cached["input_name"],
            "found":           cached["found"],
            "total_files":     cached["total_files"],
            "total_locations": cached["total_locations"],
            "cached":          True,
        }

    logger.info(
        "[Phase 1/2 DONE] Cache MISS — variable=%s elapsed=%.2fs",
        var_upper, time.monotonic() - _t,
    )

    # Phase 2/2 — Full search
    logger.info(
        "[Phase 2/2 START] Blueprint search — job=%s variable=%s",
        job_id, var_upper,
    )
    _t = time.monotonic()
    result = search_variable_usages(
        variable_name=variable_name,
        output_dir=output_dir,
        input_dir=input_dir,
        context_lines=_CONTEXT_LINES,
    )
    logger.info(
        "[Phase 2/2 DONE] Blueprint search — variable=%s found=%s files=%d locations=%d elapsed=%.1fs total_elapsed=%.1fs",
        result["variable_name"], result["found"],
        result["total_files"], result["total_locations"],
        time.monotonic() - _t, time.monotonic() - _task_start,
    )

    _write_cached(kb_id, var_upper, result)

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)

    return {
        "job_id":          ws.job_id,
        "status":          "success",
        "kb_id":           kb_id,
        "variable_name":   result["variable_name"],
        "input_name":      result["input_name"],
        "found":           result["found"],
        "total_files":     result["total_files"],
        "total_locations": result["total_locations"],
        "cached":          False,
    }
