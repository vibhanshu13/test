"""Compact, chain-scoped backward-lineage facts builder.

This path is intentionally narrower than the legacy backward BFS:

- scope is bounded to the selected chain (plus optional direct callees)
- data comes from per-file blueprint artifacts via the seekable ``.bpidx`` format
- output focuses on setter facts, guards, and direct dependent variables

The result is designed for retrieval speed and low memory use on large corpora.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from backward_traversal.runner.chainless_lineage_tree import build_lineage, flatten_summary


def _slug(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.@#$-]+", "_", str(name or "").strip())[:120] or "variable"


def _node_key(node: Dict[str, Any]) -> str:
    return str(node.get("var") or "").strip().upper()


def _node_score(node: Optional[Dict[str, Any]]) -> Tuple[int, int, int, int]:
    if not node:
        return (-1, -1, -1, -1)
    setters = node.get("setters") or []
    return (
        0 if node.get("cycle") else 1,
        0 if node.get("truncated") else 1,
        len(setters),
        sum(len(s.get("conditions") or []) for s in setters),
    )


def _prefer_node(existing: Optional[Dict[str, Any]], candidate: Dict[str, Any]) -> Dict[str, Any]:
    if existing is None or _node_score(candidate) > _node_score(existing):
        return candidate
    return existing


def _build_location(setter: Dict[str, Any]) -> Dict[str, Any]:
    line = int(setter.get("line") or 0)
    return {
        "file": str(setter.get("source_file") or setter.get("file") or ""),
        "startLine": line,
        "endLine": line,
    }


def _iter_direct_dep_nodes(setter: Dict[str, Any]) -> Iterable[Tuple[Dict[str, Any], str]]:
    seen: Set[str] = set()
    for key, kind in (("condition_deps", "conditional_guard"), ("value_deps", "data_flow")):
        for node in setter.get(key) or []:
            name = str(node.get("var") or "").strip()
            name_key = name.upper()
            if not name or name_key in seen:
                continue
            seen.add(name_key)
            yield node, kind


def _compact_conditions(setter: Dict[str, Any]) -> List[Dict[str, Any]]:
    loc = _build_location(setter)
    out: List[Dict[str, Any]] = []
    for idx, cond in enumerate(setter.get("conditions") or [], start=1):
        raw = str(cond or "").strip()
        if not raw:
            continue
        out.append({
            "order": idx,
            "condition": raw,
            "relevantCodeChunk": raw,
            "location": dict(loc),
        })
    return out


def _compact_dep_refs(
    setter: Dict[str, Any],
    dep_details_path: Dict[str, str],
) -> List[Dict[str, Any]]:
    loc = _build_location(setter)
    out: List[Dict[str, Any]] = []
    for node, kind in _iter_direct_dep_nodes(setter):
        name = str(node.get("var") or "").strip()
        if not name:
            continue
        entry = {
            "name": name,
            "kind": kind,
            "foundAt": dict(loc),
        }
        detail_path = dep_details_path.get(name.upper())
        if detail_path:
            entry["detailsPath"] = detail_path
        out.append(entry)
    return out


def _setter_sort_key(setter: Dict[str, Any]) -> Tuple[str, int, str]:
    return (
        str(setter.get("source_file") or setter.get("file") or ""),
        int(setter.get("line") or 0),
        str(setter.get("value") or ""),
    )


def _build_setter_payloads(
    node: Dict[str, Any],
    dep_details_path: Dict[str, str],
) -> List[Dict[str, Any]]:
    setters = sorted(node.get("setters") or [], key=_setter_sort_key)
    seen: Set[Tuple[str, int, str, str]] = set()
    out: List[Dict[str, Any]] = []
    for setter in setters:
        dedupe_key = (
            str(setter.get("source_file") or setter.get("file") or ""),
            int(setter.get("line") or 0),
            str(setter.get("value") or ""),
            str(setter.get("code_chunk") or ""),
        )
        if dedupe_key in seen:
            continue
        seen.add(dedupe_key)
        out.append({
            "setterId": len(out) + 1,
            "value": str(setter.get("value") or ""),
            "setterCodeChunk": str(
                setter.get("code_chunk")
                or setter.get("value")
                or ""
            ),
            "location": _build_location(setter),
            "conditions": _compact_conditions(setter),
            "dependentVariables": _compact_dep_refs(setter, dep_details_path),
        })
    return out


def _append_unique_dependency(target: List[Dict[str, Any]], entry: Dict[str, Any]) -> None:
    key = (
        str(entry.get("variableName") or ""),
        str(((entry.get("foundAt") or {}).get("file")) or ""),
        int(((entry.get("foundAt") or {}).get("startLine")) or 0),
        str(entry.get("kind") or ""),
    )
    if not any(
        (
            str(item.get("variableName") or ""),
            str(((item.get("foundAt") or {}).get("file")) or ""),
            int(((item.get("foundAt") or {}).get("startLine")) or 0),
            str(item.get("kind") or ""),
        ) == key
        for item in target
    ):
        target.append(entry)


def _index_dependency_nodes(root: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    registry: Dict[str, Dict[str, Any]] = {}

    def walk(node: Dict[str, Any], stack: Set[str]) -> None:
        node_name = str(node.get("var") or "").strip()
        node_key = node_name.upper()
        if not node_name:
            return
        for setter in node.get("setters") or []:
            for child, kind in _iter_direct_dep_nodes(setter):
                child_name = str(child.get("var") or "").strip()
                child_key = child_name.upper()
                if not child_name:
                    continue
                bucket = registry.setdefault(child_key, {
                    "name": child_name,
                    "node": None,
                    "dependencies": [],
                })
                bucket["name"] = bucket.get("name") or child_name
                bucket["node"] = _prefer_node(bucket.get("node"), child)
                _append_unique_dependency(bucket["dependencies"], {
                    "variableName": node_name,
                    "kind": kind,
                    "foundAt": _build_location(setter),
                    "relevantCodeChunk": str(
                        setter.get("code_chunk")
                        or setter.get("value")
                        or ""
                    ),
                })
                if child_key not in stack:
                    walk(child, stack | {child_key})

    walk(root, {_node_key(root)})
    return registry


def _build_root_payload(
    root: Dict[str, Any],
    dep_details_path: Dict[str, str],
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "name": str(root.get("var") or ""),
        "setters": _build_setter_payloads(root, dep_details_path),
    }
    if root.get("truncated"):
        payload["truncated"] = True
    if root.get("cycle"):
        payload["cycle"] = True
    return payload


def _build_dependent_payload(
    node: Dict[str, Any],
    dependencies: List[Dict[str, Any]],
    dep_details_path: Dict[str, str],
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "name": str(node.get("var") or ""),
        "dependencies": sorted(
            dependencies,
            key=lambda item: (
                str(item.get("variableName") or ""),
                str(((item.get("foundAt") or {}).get("file")) or ""),
                int(((item.get("foundAt") or {}).get("startLine")) or 0),
            ),
        ),
        "setters": _build_setter_payloads(node, dep_details_path),
    }
    if not payload["setters"]:
        payload["terminal"] = True
    if node.get("truncated"):
        payload["truncated"] = True
    if node.get("cycle"):
        payload["cycle"] = True
    return payload


def _filter_root_setters(
    tree: Dict[str, Any],
    *,
    target_setters: Optional[List[Dict[str, Any]]],
    modifier_stem: str,
) -> None:
    if not target_setters:
        return
    wanted = []
    for setter in tree.get("setters") or []:
        for spec in target_setters:
            spec_line = int(spec.get("line") or 0)
            spec_file = str(spec.get("file") or modifier_stem or "").strip().lower()
            spec_routine = str(spec.get("routine") or "").strip().lower()
            if int(setter.get("line") or 0) != spec_line:
                continue
            if spec_file and str(setter.get("file") or "").strip().lower() != spec_file:
                continue
            if spec_routine and str(setter.get("function") or "").strip().lower() != spec_routine:
                continue
            wanted.append(setter)
            break
    tree["setters"] = wanted


def build_compact_backward_lineage(
    *,
    kb_id: str,
    variable: str,
    selected_chain: List[str],
    blueprint_dir: Path,
    graph_file: Path,
    asm_dir: Optional[Path],
    output_path: Path,
    sidecar_dir: Path,
    scope_stems: Set[str],
    max_dep_var_depth: int,
    target_setters: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Build a compact setter/dependency view for one root variable."""
    logic_depth = max(1, int(max_dep_var_depth) + 1)
    tree = build_lineage(
        variable,
        blueprint_dir,
        graph_file,
        job_id=kb_id,
        asm_dir=asm_dir,
        max_depth=logic_depth,
        max_caller_depth=0,
        _trace_callers=False,
        scope_stems=scope_stems,
    )
    _filter_root_setters(
        tree,
        target_setters=target_setters,
        modifier_stem=str(selected_chain[-1] if selected_chain else ""),
    )
    dep_registry = _index_dependency_nodes(tree)

    dep_dir = sidecar_dir / "dependent_variables"
    dep_dir.mkdir(parents=True, exist_ok=True)

    dep_details_path = {
        key: str(Path(sidecar_dir.name) / "dependent_variables" / f"{_slug(value['name'])}.json")
        for key, value in dep_registry.items()
    }

    root_payload = {
        "mode": "compact_logic",
        "kb_id": kb_id,
        "selected_chain": list(selected_chain),
        "scope_stems": sorted(scope_stems),
        "summary": flatten_summary(tree),
        "rootVariable": _build_root_payload(tree, dep_details_path),
        "dependentVariableFiles": [
            {"name": value["name"], "path": dep_details_path[key]}
            for key, value in sorted(dep_registry.items(), key=lambda item: item[1]["name"].upper())
        ],
    }

    output_path.write_text(json.dumps(root_payload, indent=2), encoding="utf-8")

    dep_files: List[Dict[str, str]] = []
    for key, value in sorted(dep_registry.items(), key=lambda item: item[1]["name"].upper()):
        dep_node = value.get("node") or {"var": value["name"], "setters": []}
        dep_payload = {
            "mode": "compact_logic",
            "kb_id": kb_id,
            "selected_chain": list(selected_chain),
            "dependentVariable": _build_dependent_payload(
                dep_node,
                value.get("dependencies") or [],
                dep_details_path,
            ),
        }
        dep_path = dep_dir / f"{_slug(value['name'])}.json"
        dep_path.write_text(json.dumps(dep_payload, indent=2), encoding="utf-8")
        dep_files.append({
            "name": value["name"],
            "path": str(dep_path),
        })

    manifest = {
        "mode": "compact_logic",
        "variable": variable,
        "selected_chain": list(selected_chain),
        "scope_stems": sorted(scope_stems),
        "root_file": str(output_path.name),
        "dependent_variable_count": len(dep_registry),
        "dependent_variable_files": [
            {
                "name": value["name"],
                "relative_path": dep_details_path[key],
            }
            for key, value in sorted(dep_registry.items(), key=lambda item: item[1]["name"].upper())
        ],
    }
    manifest_path = sidecar_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    return {
        "summary": root_payload["summary"],
        "output_path": str(output_path),
        "manifest_path": str(manifest_path),
        "dependent_variable_count": len(dep_registry),
        "dependent_variable_files": dep_files,
    }
