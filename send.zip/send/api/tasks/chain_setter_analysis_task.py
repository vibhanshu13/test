"""Celery task: chained multi-setter analysis (chain-files backward lineage).

Run-once, project-INDEPENDENT cache keyed on (variable, chain_key):
  Phase A (deterministic) — chain_setter_orchestrator.analyze_chain_setters
      → cache the structural payload, mark ``active``.
  Phase B (LLM prose)     — chain_setter_explainer.explain_chain_setters
      → cache the rendered (b/t) payload, mark ``explained``.

Reuses the chain-files engine in backward_traversal/ + the existing setter-
analysis cache helpers (pack_blob/unpack_blob).  Idempotent: a fresh cached row
(same schema_version) short-circuits.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from api.tasks.celery_app import celery_app
from api.tasks._output_compression import pack_blob, unpack_blob

logger = logging.getLogger(__name__)


def _resolve_paths(kb_id: str):
    from api.config import settings
    from api.tasks._task_utils import find_blueprint_dir, resolve_graph_file
    out = settings.JOBS_BASE_DIR / kb_id / "output"
    bpdir = find_blueprint_dir(out) or out
    graph = resolve_graph_file(out, kb_id)
    asm_dir: Optional[Path] = None
    try:
        from api.storage.workspace import WorkspaceManager
        opts = WorkspaceManager(kb_id).get_pipeline_options() or {}
        sp = opts.get("source_path")
        if sp and Path(sp).exists():
            asm_dir = Path(sp)
    except Exception:
        pass
    return Path(bpdir), Path(graph), asm_dir


def build_and_store(kb_id: str, variable: str, chain_files: List[str], entry_function: str,
                    entry_file: Optional[str] = None, force: bool = False,
                    max_setters: int = 0, max_dep_var_depth: int = 1,
                    max_depth: int = 4, max_routes: int = 20, max_caller_depth: int = 12,
                    force_llm: bool = False) -> Dict[str, Any]:
    """Pure worker body — Phase A (engine) + Phase B (prose).  Returns status dict.

    force_llm=True skips Phase A and re-runs only Phase B using the cached structural
    payload (status must be active or explained).  Useful to refresh prose after an LLM
    bug fix without re-running the expensive backward traversal.
    """
    from api.db import SessionLocal
    from api.models.setter_analysis import ChainSetterStructural, ChainSetterProse
    from api.schemas.chain_setter_analysis import (
        chain_key as _ck, SCHEMA_VERSION, STATUS_ACTIVE, STATUS_EXPLAINED, STATUS_FAILED,
    )
    from llm.chain_setter_explainer import explain_chain_setters

    ck = _ck(chain_files, entry_function)
    entry = entry_file or (chain_files[-1] if chain_files else "")
    prefix = list(chain_files[:-1])

    db = SessionLocal()
    try:
        struct = db.query(ChainSetterStructural).filter_by(variable=variable, chain_key=ck).first()

        # ── force_llm: skip Phase A, reuse cached structural payload ──────────
        if force_llm:
            if struct is None or not struct.payload_gz:
                return {"status": "error", "chain_key": ck,
                        "error": "force_llm requires a prior Phase A result (status=active or explained) — run without force_llm first."}
            structural = unpack_blob(struct.payload_gz) or {}
            struct.status = "running"; struct.schema_version = SCHEMA_VERSION
            struct.progress = 55; struct.progress_label = "Re-explaining (LLM only)…"
            db.commit()
            rendered = explain_chain_setters(structural)
            for mode in ("business", "business_refs", "technical"):
                row = db.query(ChainSetterProse).filter_by(variable=variable, chain_key=ck, mode=mode).first()
                if row is None:
                    row = ChainSetterProse(variable=variable, chain_key=ck, mode=mode,
                                           schema_version=SCHEMA_VERSION)
                    db.add(row)
                row.payload_gz = pack_blob(rendered); row.status = "success"; row.schema_version = SCHEMA_VERSION
            struct.status = STATUS_EXPLAINED; struct.progress = 100; struct.progress_label = "Done"
            db.commit()
            return {"status": "success", "chain_key": ck, "n_setters": structural.get("n_reachable", 0)}

        # ── normal flow: Phase A then Phase B ─────────────────────────────────
        if struct is None:
            struct = ChainSetterStructural(variable=variable, chain_key=ck,
                                           chain_json=json.dumps({"files": chain_files, "entry": entry_function}),
                                           schema_version=SCHEMA_VERSION, status="pending")
            db.add(struct)
            db.flush()
        # Short-circuit: already explained → return cached.
        if (not force and struct.status == STATUS_EXPLAINED
                and struct.schema_version == SCHEMA_VERSION and struct.payload_gz):
            db.commit()
            return {"status": "success", "chain_key": ck, "cached": True}
        # Short-circuit: already running/active → another task is doing the work; exit.
        if (not force and struct.status in ("running", STATUS_ACTIVE)
                and struct.schema_version == SCHEMA_VERSION):
            db.commit()
            return {"status": "skipped", "chain_key": ck, "reason": "already in progress"}
        struct.status = "running"; struct.schema_version = SCHEMA_VERSION
        struct.progress = 5; struct.progress_label = "Tracing setters along the chain…"
        db.commit()

        # ----- Phase A: deterministic engine -----
        from backward_traversal.chain_setter_orchestrator import analyze_chain_setters
        bpdir, graph, asm_dir = _resolve_paths(kb_id)
        structural = analyze_chain_setters(
            variable, chain_prefix=prefix, entry_file=entry, entry_function=entry_function,
            entry_type="cpp", blueprint_dir=bpdir, graph_file=graph, asm_dir=asm_dir, job_id=kb_id,
            max_setters=max_setters, max_dep_var_depth=max_dep_var_depth,
            max_depth=max_depth, max_routes=max_routes, max_caller_depth=max_caller_depth,
        )
        struct.payload_gz = pack_blob(structural)
        struct.n_setters = structural.get("n_reachable", 0)
        struct.status = STATUS_ACTIVE
        struct.progress = 55; struct.progress_label = "Setters traced; explaining…"
        db.commit()

        # ----- Phase B: LLM prose (one rendered payload; 3 modes render from b/t) -----
        rendered = explain_chain_setters(structural)
        for mode in ("business", "business_refs", "technical"):
            row = db.query(ChainSetterProse).filter_by(variable=variable, chain_key=ck, mode=mode).first()
            if row is None:
                row = ChainSetterProse(variable=variable, chain_key=ck, mode=mode,
                                       schema_version=SCHEMA_VERSION)
                db.add(row)
            row.payload_gz = pack_blob(rendered); row.status = "success"; row.schema_version = SCHEMA_VERSION
        struct.status = STATUS_EXPLAINED; struct.progress = 100; struct.progress_label = "Done"
        db.commit()
        return {"status": "success", "chain_key": ck, "n_setters": structural.get("n_reachable", 0)}
    except Exception as exc:
        logger.exception("chain_setter_analysis failed kb=%s var=%s", kb_id, variable)
        try:
            struct = db.query(ChainSetterStructural).filter_by(variable=variable, chain_key=ck).first()
            if struct:
                struct.status = STATUS_FAILED; struct.error = str(exc); db.commit()
        except Exception:
            db.rollback()
        return {"status": "error", "error": str(exc), "chain_key": ck}
    finally:
        db.close()


@celery_app.task(bind=True, name="asm.chain_setter_analysis")
def run_chain_setter_analysis(self, kb_id: str, variable: str, chain_files: List[str],
                              entry_function: str, entry_file: Optional[str] = None,
                              force: bool = False, max_setters: int = 0,
                              max_dep_var_depth: int = 1, max_depth: int = 4,
                              max_routes: int = 20, max_caller_depth: int = 12,
                              force_llm: bool = False) -> Dict[str, Any]:
    return build_and_store(kb_id, variable, chain_files, entry_function, entry_file, force,
                           max_setters, max_dep_var_depth, max_depth, max_routes, max_caller_depth,
                           force_llm)
