"""Utility: msgpack + gzip compression for backward-lineage output files.

Kept separate from the Celery task module so it can be unit-tested without
importing celery, redis, or any other server-side infrastructure.
"""

from __future__ import annotations

import gzip
import hashlib
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Blob helpers — msgpack + gzip for DB binary columns
# ---------------------------------------------------------------------------

def pack_blob(obj: Any) -> bytes:
    """Serialize obj to msgpack then gzip-compress it for storage in a LargeBinary column."""
    try:
        import msgpack  # type: ignore[import]
    except ImportError:
        raise RuntimeError("msgpack is required for pack_blob — install it with 'pip install msgpack'")
    return gzip.compress(msgpack.packb(obj, use_bin_type=True), compresslevel=6)


def unpack_blob(data: bytes) -> Any:
    """Decompress and deserialize a blob produced by pack_blob."""
    try:
        import msgpack  # type: ignore[import]
    except ImportError:
        raise RuntimeError("msgpack is required for unpack_blob — install it with 'pip install msgpack'")
    return msgpack.unpackb(gzip.decompress(data), raw=False)


def chain_hash(selected_chain: List[str]) -> str:
    """Return a 16-char hex digest that stably identifies a selected_chain."""
    return hashlib.sha256("→".join(selected_chain).encode()).hexdigest()[:16]


def compress_outputs(output_dir: Path) -> int:
    """msgpack-encode then gzip-compress every .json output file.

    Rules:
    - ``manifest.json`` is never compressed — it is the directory index and
      must remain plain JSON for fast inspection by downstream consumers.
    - Every other ``.json`` file is:
        1. Loaded and re-encoded with msgpack (binary, ~30 % smaller than JSON).
        2. Compressed with gzip level 6 (good ratio / speed trade-off).
        3. Written as ``<stem>.msgpack.gz`` beside the original.
        4. The original ``.json`` is deleted only after a successful write.
    - ``manifest.json`` is updated in-place so that ``root_var_file``,
      ``full_file_flow_file``, and every entry in ``dep_var_files`` point to
      the new ``*.msgpack.gz`` names.

    Returns the number of files that were compressed.
    """
    try:
        import msgpack  # type: ignore[import]
    except ImportError:
        logger.warning("compress_outputs: msgpack not installed — skipping compression")
        return 0

    manifest_path = output_dir / "manifest.json"
    manifest: Optional[Dict[str, Any]] = None
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as exc:
            logger.warning("compress_outputs: could not read manifest.json — %s", exc)

    # Maps bare filename OR output_dir-relative path → new name.
    # Both forms are stored so manifest patching works regardless of how
    # the field value is expressed in manifest.json.
    rename_map: Dict[str, str] = {}
    compressed_count = 0

    for json_path in sorted(output_dir.rglob("*.json")):
        if json_path.name == "manifest.json":
            continue  # index file — always leave as plain JSON

        try:
            size = json_path.stat().st_size
        except OSError:
            continue

        try:
            data = json.loads(json_path.read_text(encoding="utf-8"))
        except Exception as exc:
            logger.warning(
                "compress_outputs: skip %s — JSON read failed: %s",
                json_path.name, exc,
            )
            continue

        compressed_path = json_path.with_suffix(".msgpack.gz")
        try:
            packed = msgpack.packb(data, use_bin_type=True)
            with gzip.open(compressed_path, "wb", compresslevel=6) as gz:
                gz.write(packed)
        except Exception as exc:
            logger.warning(
                "compress_outputs: skip %s — write failed: %s",
                json_path.name, exc,
            )
            if compressed_path.exists() and not compressed_path.is_dir():
                compressed_path.unlink(missing_ok=True)
            continue

        # Delete original only after a verified successful write.
        json_path.unlink()
        compressed_count += 1

        compressed_size = compressed_path.stat().st_size
        reduction = max(0.0, (1 - compressed_size / size) * 100) if size else 0.0
        logger.info(
            "compress_outputs: %s → %s  (%.0f KB → %.0f KB, %.0f%% reduction)",
            json_path.name,
            compressed_path.name,
            size / 1024,
            compressed_size / 1024,
            reduction,
        )

        rel_old = str(json_path.relative_to(output_dir))
        rel_new = str(compressed_path.relative_to(output_dir))
        rename_map[json_path.name] = compressed_path.name
        rename_map[rel_old] = rel_new

    # Patch manifest.json so consumers can still resolve all file references.
    if manifest and rename_map:
        changed = False
        for key in ("root_var_file", "full_file_flow_file"):
            old_val = manifest.get(key)
            if old_val and old_val in rename_map:
                manifest[key] = rename_map[old_val]
                changed = True

        dep_var_files = manifest.get("dep_var_files")
        if isinstance(dep_var_files, list):
            new_list = [rename_map.get(f, f) for f in dep_var_files]
            if new_list != dep_var_files:
                manifest["dep_var_files"] = new_list
                changed = True

        if changed:
            manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    return compressed_count
