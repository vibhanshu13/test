"""Celery task: file-level call graph building (file_call_graph.py equivalent)."""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any, Dict, Optional

from celery.exceptions import SoftTimeLimitExceeded

PROJECT_ROOT = Path(__file__).parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from api.tasks.celery_app import celery_app
from api.tasks._task_utils import redirect_output_to_log
from api.storage.workspace import WorkspaceManager

logger = logging.getLogger(__name__)


@celery_app.task(
    bind=True,
    name="asm.file_call_graph",
)
def run_file_call_graph(self, job_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build a file-level call graph from uploaded blueprint and/or ASM files.

    Output is written as file_call_graph.json (or file_call_graph.dot) to the
    job output directory.
    """
    ws = WorkspaceManager(job_id)
    ws.set_status("running")

    with redirect_output_to_log(ws.log_file):
        try:
            return _run_callgraph(ws, options)
        except SoftTimeLimitExceeded:
            error_msg = "Task exceeded soft time limit and was aborted."
            logger.error("Job %s: %s", job_id, error_msg)
            ws.set_status("failed", error=error_msg)
            return {"job_id": job_id, "status": "failed", "error": error_msg}
        except Exception as exc:
            error_msg = f"{type(exc).__name__}: {exc}"
            logger.exception("Job %s failed: %s", job_id, error_msg)
            ws.set_status("failed", error=error_msg)
            return {"job_id": job_id, "status": "failed", "error": error_msg}


def _run_callgraph(ws: WorkspaceManager, options: Dict[str, Any]) -> Dict[str, Any]:
    """Core call-graph building logic."""
    from file_call_graph import CallGraphBuilder, format_json, format_dot

    input_dir = ws.input_dir
    output_dir = ws.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    output_format: str = options.get("output_format", "json")
    if output_format not in ("json", "dot"):
        raise ValueError(f"Invalid output_format '{output_format}'. Use 'json' or 'dot'.")

    # ------------------------------------------------------------------
    # Resolve blueprint_dir — prefer explicit option, then auto-discover
    # ------------------------------------------------------------------
    blueprint_dir: Optional[Path] = None
    if options.get("blueprint_dir") and options["blueprint_dir"] != ".":
        candidate = Path(options["blueprint_dir"])
        if candidate.exists():
            blueprint_dir = candidate

    if blueprint_dir is None:
        asm_json_files = list(input_dir.rglob("*.asm.json"))
        if asm_json_files:
            blueprint_dir = asm_json_files[0].parent

    # ------------------------------------------------------------------
    # Resolve asm_dir (optional; improves ENTNC/CREEC coverage)
    # ------------------------------------------------------------------
    asm_dir: Optional[Path] = None
    if options.get("asm_dir"):
        candidate = Path(options["asm_dir"])
        if candidate.exists():
            asm_dir = candidate

    if asm_dir is None:
        asm_files = list(input_dir.rglob("*.asm"))
        if asm_files:
            asm_dir = asm_files[0].parent

    if blueprint_dir is None and asm_dir is None:
        raise ValueError(
            "Cannot locate blueprint (.asm.json) or ASM (.asm) files in the "
            "uploaded input. At least one of blueprint_dir or asm_dir must be resolvable."
        )

    if blueprint_dir:
        print(f"[blueprint_dir] {blueprint_dir}", file=sys.stderr)
    if asm_dir:
        print(f"[asm_dir] {asm_dir}", file=sys.stderr)

    # ------------------------------------------------------------------
    # Build the graph
    # ------------------------------------------------------------------
    builder = CallGraphBuilder(
        asm_dir=asm_dir,
        blueprint_dir=blueprint_dir,
        recursive=False,
    )
    graph = builder.build()

    # Attach dir info for metadata output (mirrors CLI behaviour)
    graph.__dict__["_blueprint_dir"] = str(blueprint_dir) if blueprint_dir else ""
    graph.__dict__["_asm_dir"] = str(asm_dir) if asm_dir else ""

    if not graph.all_stems:
        raise ValueError(
            "No files were found. Check that blueprint (.asm.json) or ASM (.asm) "
            "files are present in the uploaded input."
        )

    if graph.warnings:
        for w in graph.warnings:
            print(f"warning: {w}", file=sys.stderr)

    # ------------------------------------------------------------------
    # Format and write output
    # ------------------------------------------------------------------
    if output_format == "dot":
        content = format_dot(graph, include_external=True)
        ext = "dot"
    else:
        content = format_json(graph, include_external=True)
        ext = "json"

    output_filename = f"file_call_graph.{ext}"
    output_path = output_dir / output_filename
    output_path.write_text(content, encoding="utf-8")
    print(f"Wrote {output_format} call graph to: {output_path}", file=sys.stderr)

    result_files = ws.collect_output_files()
    ws.set_status("success", result_files=result_files)

    return {
        "job_id": ws.job_id,
        "status": "success",
        "asm_files": len(graph.all_asm_stems),
        "cpp_files": len(graph.all_cpp_stems),
        "internal_edges": len(graph.internal_edges),
        "external_edges": len(graph.external_edges),
        "output_files": len(result_files),
    }
