"""Shared modifier-file pre-validation for the backward-lineage APIs.

Used by:
- POST /v1/knowledge-bases/{kb_id}/backward-lineage           (non-chunked)
- POST /v1/knowledge-bases/{kb_id}/backward-lineage/chunks    (chunked)
- POST /v1/jobs/{job_id}/processes/{name}/lineage/chunks      (process-filtered)

Supports both ASM and C++ modifier files:
- ASM/MAC: scan_blueprint_for_setters() on the `.asm.json` / `.mac.json` blueprint
- CPP: find_cpp_seed_nodes() against the `global_variable_lineage` in `.cpp.json` blueprint
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional, Tuple


class ModifierValidationError(Exception):
    """Raised when modifier file validation fails. The route should convert to 422."""

    def __init__(self, detail: str):
        super().__init__(detail)
        self.detail = detail


def validate_modifier_has_variable(
    modifier_stem: str,
    variable_name: str,
    blueprint_dir: Path,
) -> str:
    """Verify that the modifier file actually defines/touches `variable_name`.

    Searches blueprints in this order:
        {stem}.asm.json    (ASM source)
        {stem}.mac.json    (ASM macro library)
        {stem}.cpp.json    (C++ source — uses GVL seed nodes)

    Returns the modifier's file_type ("asm" | "cpp") on success.
    Raises ModifierValidationError if the modifier cannot be found, the variable
    cannot be located in it, or the blueprint is unreadable.
    """
    # Try ASM first (existing convention)
    asm_bp = blueprint_dir / f"{modifier_stem}.asm.json"
    mac_bp = blueprint_dir / f"{modifier_stem}.mac.json"
    cpp_bp = blueprint_dir / f"{modifier_stem}.cpp.json"

    asm_candidates = [p for p in (asm_bp, mac_bp) if p.exists()]
    cpp_present = cpp_bp.exists()

    if not asm_candidates and not cpp_present:
        raise ModifierValidationError(
            f"Modifier file '{modifier_stem}' is not present as "
            f"{modifier_stem}.asm.json, {modifier_stem}.mac.json, or "
            f"{modifier_stem}.cpp.json in {blueprint_dir}."
        )

    # --- ASM/MAC path ---
    if asm_candidates:
        from find_variable_modifiers import scan_blueprint_for_setters
        for bp in asm_candidates:
            hits, err = scan_blueprint_for_setters(bp, variable_name)
            if err:
                raise ModifierValidationError(
                    f"Failed to read modifier blueprint '{bp.name}': {err}"
                )
            if hits:
                return "asm"
        # No setters found in any ASM/MAC blueprint — fall through to C++ check
        # if a C++ blueprint also exists (mixed-language file).

    # --- C++ path ---
    if cpp_present:
        try:
            # Use the project blueprint loader — .cpp.json files may be gzip-compressed.
            # _load_json_cached injects "_gvl_job_id" when index.db is present, which
            # lets us take the fast DB path below without loading any GVL nodes.
            from backward_traversal.utils.blueprint_utils import load_json as _load_blueprint
            bp_data = _load_blueprint(cpp_bp)
        except Exception as exc:
            raise ModifierValidationError(
                f"Failed to read C++ modifier blueprint '{cpp_bp.name}': {exc}"
            )

        # ── Fast path: index DB available ────────────────────────────────────
        # _load_json_cached injects "_gvl_job_id" whenever index.db is found.
        # Use get_modifier_files() — two indexed SQL queries (variable_modifiers
        # tier-1, gvl_edges suffix-match tier-2) — instead of loading all 2.86M
        # GVL nodes into the uvicorn worker via find_cpp_seed_nodes(), which
        # OOM-kills the process on 22K-file / 10M-LOC codebases.
        job_id = bp_data.get("_gvl_job_id")
        if job_id:
            try:
                from api.index_db.readers import get_modifier_files
                modifier_files = get_modifier_files(job_id, variable_name)
            except Exception:
                modifier_files = []
            if modifier_stem.lower() in {m.lower() for m in modifier_files}:
                return "cpp"
            raise ModifierValidationError(
                f"Last chain file '{modifier_stem}' is a C++ file and does not "
                f"reference variable '{variable_name}' in its lineage graph "
                f"(no seed nodes in {cpp_bp.name})."
            )

        # ── Slow path: no index DB (file-backed / small codebase) ────────────
        # Fall back to the in-memory GVL node scan only when index.db is absent.
        from backward_traversal.utils.lazy_gvl import make_lazy_gvl
        gvl = make_lazy_gvl(bp_data, blueprint_path=cpp_bp)
        if not gvl:
            raise ModifierValidationError(
                f"C++ modifier '{modifier_stem}' has no global_variable_lineage; "
                f"cannot trace variable '{variable_name}'. Re-run the pipeline."
            )
        try:
            from backward_traversal.utils.cpp_lineage_utils import (
                extract_asm_field_aliases,
                find_cpp_seed_nodes,
            )
        except ImportError as exc:
            raise ModifierValidationError(
                f"C++ traversal helpers unavailable: {exc}"
            )
        aliases = extract_asm_field_aliases(bp_data, variable_name) if variable_name else {}
        seed_ids = find_cpp_seed_nodes(gvl, variable_name, aliases, {})
        if not seed_ids:
            raise ModifierValidationError(
                f"Last chain file '{modifier_stem}' is a C++ file and does not "
                f"reference variable '{variable_name}' in its lineage graph "
                f"(no seed nodes in {cpp_bp.name})."
            )
        return "cpp"

    # ASM candidates existed but had no setters
    raise ModifierValidationError(
        f"Last chain file '{modifier_stem}' does not contain a SETTER for "
        f"variable '{variable_name}'."
    )


# ---------------------------------------------------------------------------
# Wrapper: validate_variable_with_redirect
#
# Wraps validate_modifier_has_variable() with kind detection. When the variable
# is not found AND the name is actually a function in the same file, the raised
# ModifierValidationError carries a redirect-friendly message pointing at the
# target cpp-call-chain endpoint.
#
# CRITICAL: the original error phrase "does not contain a SETTER" is preserved
# as a substring of the new message for backward compatibility with existing
# test assertions.
# ---------------------------------------------------------------------------

def validate_variable_with_redirect(
    modifier_stem: str,
    variable_name: str,
    blueprint_dir: Path,
    *,
    target_endpoint_url: str,
    target_body_sample: Optional[dict] = None,
    inapplicable_params: Optional[list] = None,
) -> str:
    """Variant of validate_modifier_has_variable that emits a helpful redirect message.

    Behavior:
    - On success (variable found in modifier): returns "asm" or "cpp" (same as `validate_modifier_has_variable`).
    - On failure: calls `detect_name_kind`. If kind=="function", raises ModifierValidationError
      with a redirect-friendly message containing target_endpoint_url + body shape.
      If kind=="unknown", raises with the original error PLUS a hint that the name was
      also checked as a function and not found.

    The original `"does not contain a SETTER"` substring is preserved when applicable.
    """
    from api._lineage_kind_detection import (
        build_unknown_kind_message,
        build_wrong_kind_message,
        detect_name_kind,
    )

    # First, try the original validation
    try:
        return validate_modifier_has_variable(modifier_stem, variable_name, blueprint_dir)
    except ModifierValidationError as exc:
        original_detail = exc.detail

    # Variable not found — check if name is a function in this file
    kind = detect_name_kind(variable_name, modifier_stem, blueprint_dir)

    if kind == "function":
        # Build the helpful redirect message — preserve original substring
        sample = target_body_sample or {
            "method_name": variable_name,
            "file_name": modifier_stem,
            "direction": "forward",
            "max_depth": 5,
            "max_nodes": 10000,
        }
        inap = inapplicable_params or [
            "chain_files", "max_subroutine_depth", "max_subroutine_nodes",
            "max_trace_nodes", "max_dep_vars", "max_dep_var_depth",
            "max_downstream_depth", "max_downstream_files", "t8_max_scan",
            "start_tuple_index",
        ]
        redirect_msg = build_wrong_kind_message(
            name=variable_name,
            file_stem=modifier_stem,
            detected_kind="function",
            expected_kind="variable",
            target_endpoint_url=target_endpoint_url,
            target_body_sample=sample,
            inapplicable_params=inap,
        )
        # PRESERVE original substring for backward-compat with existing tests
        raise ModifierValidationError(f"{original_detail} {redirect_msg}")

    elif kind == "unknown":
        # Not a variable, not a function — add a hint about the negative function check
        sample_hint = build_unknown_kind_message(variable_name, modifier_stem, blueprint_dir)
        raise ModifierValidationError(f"{original_detail} Additional context: {sample_hint}")

    # kind == "both" — extremely rare; treat as variable success (re-run check might pass)
    # If we got here it's an internal inconsistency; surface the original error.
    raise ModifierValidationError(original_detail)
