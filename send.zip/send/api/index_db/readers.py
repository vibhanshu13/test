"""Query helpers for the pipeline index database.

All functions accept a ``job_id`` and return Python objects (dicts, lists,
sets) matching the shape that existing callers expect — so consumers can
switch from JSON file loading to DB queries with minimal code changes.

Each function tries the DB first and falls back to the JSON file on disk
when the DB table is empty or the query fails.  This ensures backwards
compatibility during a gradual migration.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ── helpers ────────────────────────────────────────────────────────────────────

def _is_strict() -> bool:
    """Return True when ``INDEX_DB_STRICT=true`` is set in config.

    When strict mode is active, all reader functions skip the JSON fallback
    and return an empty result instead of loading potentially large files.
    This is the gate that allows operators to permanently disable the slow
    filesystem path once ``scripts/backfill_index_db.py`` has run.
    """
    try:
        from api.config import settings
        return bool(settings.INDEX_DB_STRICT)
    except Exception:
        return False


def _get_engine(job_id: str):
    """Return the index engine, or None if unavailable."""
    try:
        from api.index_db.engine import get_engine
        return get_engine(job_id)
    except Exception as exc:
        logger.debug("[index_db] engine unavailable for job=%s: %s", job_id, exc)
        return None


_has_rows_cache: Dict[Tuple[str, str], bool] = {}

def _has_rows(engine, table, job_id: str) -> bool:
    """Return True when *table* has at least one row for *job_id*.

    Results are cached for the lifetime of the process — safe for read-only
    backward-lineage operations where these tables are never mutated.
    Uses ``LIMIT 1`` instead of ``COUNT(*)`` to avoid scanning 100K+ rows.
    """
    _ck = (table.name, job_id)
    if _ck in _has_rows_cache:
        return _has_rows_cache[_ck]
    try:
        from sqlalchemy import select
        with engine.connect() as conn:
            row = conn.execute(
                select(table.c.job_id).where(
                    table.c.job_id == job_id
                ).limit(1)
            ).fetchone()
            result = row is not None
            _has_rows_cache[_ck] = result
            return result
    except Exception:
        return False


# Hard cap for unfiltered full-scan calls to get_gvl_edges.
_GVL_UNFILTERED_LIMIT = 50_000

# ── GVL readers ────────────────────────────────────────────────────────────────

def get_gvl_edges(
    job_id: str,
    *,
    relation: Optional[str] = None,
    file: Optional[str] = None,
    source: Optional[str] = None,
    target: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Query ``gvl_edges`` with optional filters.

    Returns a list of edge dicts matching the shape used by existing callers::

        [{"source": "...", "target": "...", "relation": "...", "file": "...", ...}]

    **Always pass at least one filter** (``relation``, ``file``, ``source``, or
    ``target``).  Calling without any filter performs a full table scan and loads
    every GVL edge for the job into RAM (can be 10 000+ rows per job).
    """
    engine = _get_engine(job_id)
    if engine is None:
        return []

    if relation is None and file is None and source is None and target is None:
        if _is_strict():
            raise ValueError(
                f"get_gvl_edges called without any filter for job={job_id}. "
                "Pass at least one of: relation, file, source, target."
            )
        logger.warning(
            "[index_db] get_gvl_edges called without any filter for job=%s — "
            "full table scan, capped at %d rows.",
            job_id, _GVL_UNFILTERED_LIMIT,
        )

    try:
        from api.index_db.schema import gvl_edges
        from sqlalchemy import select

        stmt = select(
            gvl_edges.c.source,
            gvl_edges.c.target,
            gvl_edges.c.relation,
            gvl_edges.c.file,
            gvl_edges.c.line,
            gvl_edges.c.expression,
            gvl_edges.c.operation_type,
            gvl_edges.c.transformation,
            gvl_edges.c.symbolic_identity,
            gvl_edges.c.access_identity,
            gvl_edges.c.file_label,
            gvl_edges.c.field_offset,
            gvl_edges.c.dsect,
            gvl_edges.c.conditional_context,
        ).where(gvl_edges.c.job_id == job_id)
        if relation is not None:
            stmt = stmt.where(gvl_edges.c.relation == relation)
        if file is not None:
            stmt = stmt.where(gvl_edges.c.file == file)
        if source is not None:
            stmt = stmt.where(gvl_edges.c.source == source)
        if target is not None:
            stmt = stmt.where(gvl_edges.c.target == target)

        if relation is None and file is None and source is None and target is None:
            stmt = stmt.limit(_GVL_UNFILTERED_LIMIT)

        with engine.connect() as conn:
            rows = conn.execute(stmt).mappings().all()
        import json as _json

        def _decode_cc(v: Any) -> Any:
            if not v:
                return None
            if isinstance(v, (list, tuple)):
                return list(v)
            try:
                return _json.loads(v)
            except Exception:
                return None

        return [
            {
                "source": r["source"],
                "target": r["target"],
                "relation": r["relation"],
                "file": r["file"],
                "line": r["line"],
                "expression": r["expression"],
                "operation_type": r["operation_type"],
                "transformation": r["transformation"],
                "symbolic_identity": r["symbolic_identity"],
                "access_identity": r["access_identity"],
                "file_label": r["file_label"],
                "field_offset": r["field_offset"],
                "dsect": r["dsect"],
                "conditional_context": _decode_cc(r["conditional_context"]),
            }
            for r in rows
        ]
    except Exception as exc:
        logger.debug("[index_db] get_gvl_edges failed (job=%s): %s", job_id, exc)
        return []


def get_gvl_setter_edges(
    job_id: str,
    variable_name: str,
) -> Optional[List[Dict[str, Any]]]:
    """Return ``assign``/``define`` GVL edges whose target matches *variable_name*.

    Uses the same suffix-matching logic as ``get_modifier_files`` tier 2 but
    returns **full edge dicts** (source, target, relation, file, line, expression,
    …) instead of ``DISTINCT file`` stems.

    This replaces the pattern of loading ALL GVL edges via
    ``gvl.get("edges")`` (2.86 M rows on 22 K-file codebases) just to filter
    for the handful of assign/define edges relevant to one variable.

    Returns ``None`` when the DB is unavailable (caller should fall back to
    the legacy in-memory GVL scan).
    """
    engine = _get_engine(job_id)
    if engine is None:
        return None

    var_up = variable_name.upper()
    # Skip for very short names — too many false positives via suffix patterns.
    if len(var_up) < 3:
        return None

    try:
        from sqlalchemy import text as _text
        import json as _json

        def _decode_cc(v):
            if not v:
                return None
            if isinstance(v, (list, tuple)):
                return list(v)
            try:
                return _json.loads(v)
            except Exception:
                return None

        _SELECT_COLS = (
            "SELECT source, target, relation, file, line, expression, "
            "       operation_type, transformation, symbolic_identity, "
            "       access_identity, file_label, field_offset, dsect, "
            "       conditional_context "
            "FROM gvl_edges "
        )

        with engine.connect() as conn:
            # Fast path: use target_terminal index (O(log N) vs O(16.7M) scan).
            # target_terminal stores the uppercased terminal component after the
            # last separator (->  ::  .  :), matching what the LIKE patterns seek.
            _has_terminal = conn.execute(_text(
                "SELECT 1 FROM pragma_table_info('gvl_edges') "
                "WHERE name = 'target_terminal'"
            )).fetchone()

            if _has_terminal:
                si_clause = (
                    "  OR upper(symbolic_identity) LIKE :pat"
                    if len(var_up) >= 4 else ""
                )
                rows = conn.execute(_text(
                    _SELECT_COLS +
                    "WHERE job_id = :jid AND relation IN ('assign','define') "
                    "AND target NOT LIKE 'variable:/%' "
                    "AND ("
                    "  target_terminal = :var"
                    "  OR upper(target) = :var"
                    + si_clause +
                    ") "
                    "LIMIT 5000"
                ), {"jid": job_id, "var": var_up, "pat": f"%{var_up}%"}).fetchall()
            else:
                # Fallback: legacy LIKE queries (for DBs without target_terminal).
                si_clause = (
                    "  OR upper(symbolic_identity) LIKE :pat"
                    if len(var_up) >= 4 else ""
                )
                rows = conn.execute(_text(
                    _SELECT_COLS +
                    "WHERE job_id = :jid AND relation IN ('assign','define') "
                    "AND target NOT LIKE 'variable:/%' "
                    "AND ("
                    "  upper(target) = :var"
                    "  OR upper(target) LIKE '%.' || :var"
                    "  OR upper(target) LIKE '%->' || :var"
                    "  OR upper(target) LIKE '%::' || :var"
                    "  OR upper(target) LIKE '%:' || :var"
                    + si_clause +
                    ") "
                    "LIMIT 5000"
                ), {"jid": job_id, "var": var_up, "pat": f"%{var_up}%"}).fetchall()

        return [
            {
                "source": r[0],
                "target": r[1],
                "relation": r[2],
                "file": r[3],
                "line": r[4],
                "expression": r[5],
                "operation_type": r[6],
                "transformation": r[7],
                "symbolic_identity": r[8],
                "access_identity": r[9],
                "file_label": r[10],
                "field_offset": r[11],
                "dsect": r[12],
                "conditional_context": _decode_cc(r[13]),
            }
            for r in rows
        ]
    except Exception as exc:
        logger.debug("[index_db] get_gvl_setter_edges failed (job=%s): %s", job_id, exc)
        return None


# ── C++ seed key readers ──────────────────────────────────────────────────────

# REGNA region names (EB0USER–EB7USER) → ce1usa alias.
_REGNA_NAMES: frozenset = frozenset({
    "eb0user", "eb1user", "eb2user", "eb3user",
    "eb4user", "eb5user", "eb6user", "eb7user",
})


def get_cpp_seed_node_ids(
    job_id: str,
    variable: str,
    *,
    file_stem: Optional[str] = None,
) -> Optional[List[str]]:
    """Look up seed node IDs for *variable* via the gvl_nodes derived
    seed-lookup columns (terminal_base_lower / name_base_lower /
    asm_alias_lower).

    CONVERGENCE NOTE: this previously read the materialized ``cpp_seed_keys``
    / ``cpp_seed_file_keys`` tables.  Those froze the strategy logic into data
    at ingest time (a strategy fix required re-ingesting the GVL) and were
    never built for pre-existing jobs.  The derived-column engine
    (backward_traversal/utils/cpp_lineage_utils.find_cpp_seed_nodes_db) keeps
    the strategy predicates in code, is exact-parity tested against the
    streaming scan, and is auto-backfilled for old jobs on engine creation.
    The public contract here is unchanged:

    - returns ``None`` when the index is unavailable (caller falls back to
      the scan-based ``find_cpp_seed_nodes``)
    - returns a deduplicated node-id list otherwise (deterministic GVL
      emission order)
    - handles Strategies 1, 3, 5, 6 (REGNA), 7 (@MMU), 8 (ALASW)
    - when *file_stem* is given, narrows to seeds with setter edges in that
      file; a stem absent from the GVL (path-format mismatch) keeps all
      seeds rather than silently returning empty
    """
    engine = _get_engine(job_id)
    if engine is None:
        return None
    db_path = str(engine.url).replace("sqlite:///", "")
    if not db_path:
        return None

    from backward_traversal.utils.cpp_lineage_utils import (
        find_cpp_seed_nodes_db,
        db_setter_targets_for_stem,
    )

    results = find_cpp_seed_nodes_db(
        db_path, job_id, variable, include_fix16_fallback=False,
    )
    if results is None:
        return None  # derived columns unavailable — caller falls back

    if file_stem and results:
        _stem_lower = file_stem.strip().lower()
        scoped = db_setter_targets_for_stem(db_path, job_id, _stem_lower)
        if scoped is not None:
            targets, stem_seen = scoped
            if stem_seen:
                results = [nid for nid in results if nid in targets]
            # stem_seen=False → path-format mismatch, keep all results

    return results


def get_seed_file_stems(
    job_id: str,
    variable: str,
) -> Optional[List[str]]:
    """Return file stems that contain seed nodes for *variable*.

    Uses ``cpp_seed_keys`` to find candidate node_ids, then queries
    ``gvl_edges`` to find which files those nodes have assign/define/arg_bind
    edges in.  Returns ``None`` if the index is unavailable (caller should
    fall back to blueprint scanning).

    .. note:: Prefer ``get_cpp_seed_candidate_files()`` which queries the
       pre-materialized ``cpp_seed_file_keys`` table directly.
    """
    node_ids = get_cpp_seed_node_ids(job_id, variable)
    if node_ids is None:
        return None
    if not node_ids:
        return []

    engine = _get_engine(job_id)
    if engine is None:
        return None

    from api.index_db.schema import gvl_edges
    from sqlalchemy import select, or_

    try:
        with engine.connect() as conn:
            stmt = (
                select(gvl_edges.c.file_stem)
                .where(
                    gvl_edges.c.job_id == job_id,
                    gvl_edges.c.file_stem.isnot(None),
                    gvl_edges.c.relation.in_(["assign", "define", "arg_bind"]),
                    or_(
                        gvl_edges.c.target.in_(node_ids),
                        gvl_edges.c.source.in_(node_ids),
                    ),
                )
                .distinct()
            )
            rows = conn.execute(stmt).fetchall()
            return [r[0] for r in rows if r[0]]
    except Exception as exc:
        logger.debug("[index_db] get_seed_file_stems failed (job=%s): %s", job_id, exc)
        return None


_stem_exists_cache: Dict[Tuple[str, str], bool] = {}  # (job_id, stem) → bool

def filter_seeds_by_file_stem(
    job_id: str,
    seed_ids: List[str],
    file_stem: str,
) -> Optional[Tuple[Set[str], bool]]:
    """Filter seed node_ids to those with setter edges in *file_stem*.

    Returns ``(filtered_set, stem_seen)`` where *filtered_set* is the subset
    of *seed_ids* that have an assign/define/arg_bind edge in *file_stem*,
    and *stem_seen* indicates whether the stem appears in any GVL edge.

    Returns ``None`` when the DB is unavailable (caller should fall back to
    the legacy in-memory GVL scan).

    Uses the ``ix_gvl_edges_job_file_stem`` index for O(log N) lookup.
    """
    engine = _get_engine(job_id)
    if engine is None:
        return None

    stem_lower = file_stem.strip().lower() if file_stem else None
    if not stem_lower or not seed_ids:
        return None

    try:
        from sqlalchemy import text as _text

        # Check if stem exists in DB at all (path-format mismatch guard).
        # Cached: only one DB hit per (job_id, stem) per process.
        _se_key = (job_id, stem_lower)
        if _se_key in _stem_exists_cache:
            if not _stem_exists_cache[_se_key]:
                return (set(), False)
        else:
            with engine.connect() as conn:
                _se_row = conn.execute(_text(
                    "SELECT 1 FROM gvl_edges "
                    "WHERE job_id = :jid AND file_stem = :stem LIMIT 1"
                ), {"jid": job_id, "stem": stem_lower}).fetchone()
                _stem_exists_cache[_se_key] = _se_row is not None
                if not _se_row:
                    return (set(), False)

        with engine.connect() as conn:

            # Filter seeds to those with setter edges in this file.
            # Batch seed_ids into chunks to avoid SQLite variable limit.
            matched: Set[str] = set()
            chunk_size = 500
            for i in range(0, len(seed_ids), chunk_size):
                chunk = seed_ids[i:i + chunk_size]
                placeholders = ", ".join(f":s{j}" for j in range(len(chunk)))
                params = {"jid": job_id, "stem": stem_lower}
                params.update({f"s{j}": s for j, s in enumerate(chunk)})
                rows = conn.execute(_text(
                    "SELECT DISTINCT target FROM gvl_edges "
                    "WHERE job_id = :jid AND file_stem = :stem "
                    "  AND relation IN ('assign', 'define', 'arg_bind') "
                    f"  AND target IN ({placeholders})"
                ), params).fetchall()
                matched.update(r[0] for r in rows)
            return (matched, True)
    except Exception as exc:
        logger.debug("[index_db] filter_seeds_by_file_stem failed: %s", exc)
        return None


def get_cpp_seed_node_ids_bulk(
    job_id: str,
    variables: List[str],
) -> Optional[Dict[str, List[str]]]:
    """Bulk variant of :func:`get_cpp_seed_node_ids` (global, unfiltered).

    CONVERGENCE NOTE: previously a chunked IN-clause query over the
    materialized ``cpp_seed_keys`` table (whose bulk consumer in the runner
    is disabled).  Now a per-variable loop over the derived-column engine —
    indexed lookups, a few ms each.  Contract unchanged: {var_lower:
    [node_ids]} omitting empty, or ``None`` when the index is unavailable.
    """
    out: Dict[str, List[str]] = {}
    for var in variables:
        seeds = get_cpp_seed_node_ids(job_id, var)
        if seeds is None:
            return None
        if seeds:
            out[str(var).strip().lower()] = seeds
    return out


def get_cpp_seed_candidate_files(
    job_id: str,
    variable: str,
) -> Optional[List[str]]:
    """Return file stems containing seed nodes for *variable*.

    CONVERGENCE NOTE: previously read the materialized ``cpp_seed_file_keys``
    table; now delegates to ``get_seed_file_stems`` which resolves seeds via
    the derived-column engine and joins ``gvl_edges`` (indexed on
    (job_id, relation, file_stem)).  Contract unchanged: ``None`` when the
    index is unavailable, else a (possibly empty) list of lowercase stems.
    """
    return get_seed_file_stems(job_id, variable)


def get_cpp_seed_candidate_files_bulk(
    job_id: str,
    variables: List[str],
) -> Optional[Dict[str, List[str]]]:
    """Bulk variant of :func:`get_cpp_seed_candidate_files`.

    Returns {var_lower: [stems]} for variables that have candidate files,
    or ``None`` when the index is unavailable.  Per-variable lookups are
    indexed (a few ms each), so a loop is adequate for the BFS dep-var
    counts involved (≤ max_dep_vars).
    """
    out: Dict[str, List[str]] = {}
    for var in variables:
        stems = get_cpp_seed_candidate_files(job_id, var)
        if stems is None:
            return None  # index unavailable — caller falls back wholesale
        if stems:
            out[str(var).strip().lower()] = stems
    return out


def get_modifier_files(
    job_id: str,
    variable_name: str,
    *,
    fallback_path: Optional[Path] = None,
) -> List[str]:
    """Return the list of file stems that modify *variable_name*.

    Falls back to loading *fallback_path* (variable_modifier_index.json) when
    the DB has no rows for this job.
    """
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import variable_modifiers
            from sqlalchemy import select

            with engine.connect() as conn:
                rows = conn.execute(
                    select(variable_modifiers.c.file_stem).where(
                        (variable_modifiers.c.job_id == job_id)
                        & (variable_modifiers.c.variable_name == variable_name.upper())
                    )
                ).fetchall()
            if rows:
                return [r[0] for r in rows]
        except Exception as exc:
            logger.debug("[index_db] get_modifier_files DB failed: %s", exc)

    # Secondary fallback: query gvl_edges directly for assign/define edges
    # targeting this variable. Covers cases where variable_modifiers was built
    # with numeric IDs or was not populated (pipeline bug on some KB versions).
    #
    # Terminal-name matching: gvl_edges targets are qualified names like
    # "variable:func::field" or "struct_field:s->field". A raw LIKE '%VAR%'
    # produces false positives (e.g. searching MSGTYPE also matches isoMsgType).
    # Instead we match the terminal segment — the part after the last '.', '->'
    # '::' or ':' separator — using suffix patterns so only exact field-name
    # matches are returned.  symbolic_identity stays as a loose LIKE since its
    # format is less predictable.
    #
    # File-type filter: restrict to .asm and .cpp source files only.
    # This mirrors build_modifier_index.py which only processes .asm.json /
    # .mac.json and .cpp.json blueprints.  It excludes synthetic GVL nodes
    # (file='<global>') and header-only files (.hpp/.h) that have GVL edges
    # but no corresponding blueprint — preventing false-positive stem returns.
    if engine is not None:
        try:
            import os as _os
            with engine.connect() as conn:
                from sqlalchemy import text as _text
                var_up = variable_name.upper()
                # Skip tier 2 entirely for very short names (≤2 chars):
                # register names (R0-R15), single digits, etc. produce massive
                # false positives via the suffix patterns (e.g. LIKE '%:R0'
                # matches register:R0 across all files).  These noise entries
                # are already covered by tier 1, so early-exit is safe.
                if len(var_up) < 3:
                    return []
                # Include symbolic_identity fallback only for names long enough
                # that a substring match is selective (three-char names like
                # "R15" are borderline; four chars give acceptable precision).
                si_clause = (
                    "  OR upper(symbolic_identity) LIKE :pat"
                    if len(var_up) >= 4 else ""
                )
                # Check if target_terminal column exists for fast path.
                _has_terminal = conn.execute(_text(
                    "SELECT 1 FROM pragma_table_info('gvl_edges') "
                    "WHERE name = 'target_terminal'"
                )).fetchone()

                if _has_terminal:
                    # Fast path: indexed equality on target_terminal.
                    rows = conn.execute(_text(
                        "SELECT DISTINCT file FROM gvl_edges "
                        "WHERE job_id = :jid AND relation IN ('assign','define') "
                        "AND (file LIKE '%.asm' OR file LIKE '%.cpp') "
                        "AND target NOT LIKE 'variable:/%' "
                        "AND ("
                        "  target_terminal = :var"
                        "  OR upper(target) = :var"
                        + si_clause +
                        ") "
                        "LIMIT 1000"
                    ), {"jid": job_id, "var": var_up, "pat": f"%{var_up}%"}).fetchall()
                else:
                    # Legacy LIKE fallback for DBs without target_terminal.
                    rows = conn.execute(_text(
                        "SELECT DISTINCT file FROM gvl_edges "
                        "WHERE job_id = :jid AND relation IN ('assign','define') "
                        "AND (file LIKE '%.asm' OR file LIKE '%.cpp') "
                        "AND target NOT LIKE 'variable:/%' "
                        "AND ("
                        "  upper(target) = :var"
                        "  OR upper(target) LIKE '%.' || :var"
                        "  OR upper(target) LIKE '%->' || :var"
                        "  OR upper(target) LIKE '%::' || :var"
                        "  OR upper(target) LIKE '%:' || :var"
                        + si_clause +
                        ") "
                        "LIMIT 1000"
                    ), {"jid": job_id, "var": var_up, "pat": f"%{var_up}%"}).fetchall()
            stems = []
            seen = set()
            for (fpath,) in rows:
                if not fpath:
                    continue
                # Lowercase to match build_modifier_index.py's _stem() behaviour
                # (preserves file-path case from gvl_edges; tier 1 always lower).
                stem = _os.path.splitext(_os.path.basename(fpath))[0].lower()
                if stem and stem not in seen:
                    seen.add(stem)
                    stems.append(stem)
            if stems:
                logger.debug("[index_db] get_modifier_files gvl_edges fallback: %s -> %s", variable_name, stems)
                return stems
        except Exception as exc:
            logger.debug("[index_db] get_modifier_files gvl_edges fallback failed: %s", exc)

    # Strict gate — skip JSON fallback when DB is the authoritative source.
    if _is_strict():
        return []
    # Fallback: load JSON
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            return data.get("index", {}).get(variable_name.upper(), [])
        except Exception:
            pass
    return []


def get_modifier_index(
    job_id: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Dict[str, List[str]]:
    """Return the full modifier index as ``{variable_name: [file_stems]}``.

    .. deprecated::
        **Do not call this function in request-handling paths.**
        It performs a full table scan (``SELECT … WHERE job_id=?`` with no
        variable filter) and loads every modifier row for the job into RAM,
        which can cause OOM when the table has tens of thousands of rows.

        Use ``get_modifier_files(job_id, variable_name)`` for single-variable
        lookups — it issues ``WHERE job_id=? AND variable_name=?`` and returns
        only the rows needed.

        This function is retained only for offline batch scripts that
        genuinely need the full index at once.

    Falls back to JSON when the DB has no rows.
    """
    if _is_strict():
        raise RuntimeError(
            "get_modifier_index is disabled (INDEX_DB_STRICT=true). "
            "Use get_modifier_files(job_id, variable_name) for per-variable lookups."
        )
    logger.warning(
        "[index_db] get_modifier_index called for job=%s — full table scan. "
        "Use get_modifier_files() for per-variable lookups to avoid OOM.",
        job_id,
    )
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import variable_modifiers
            from sqlalchemy import select

            with engine.connect() as conn:
                rows = conn.execute(
                    select(
                        variable_modifiers.c.variable_name,
                        variable_modifiers.c.file_stem,
                    ).where(variable_modifiers.c.job_id == job_id)
                ).fetchall()

            if rows:
                result: Dict[str, List[str]] = {}
                for var_name, file_stem in rows:
                    result.setdefault(var_name, []).append(file_stem)
                return result
        except Exception as exc:
            logger.debug("[index_db] get_modifier_index DB failed: %s", exc)

    # Strict gate — skip JSON fallback when DB is the authoritative source.
    if _is_strict():
        return {}
    # Fallback: load JSON
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            return data.get("index") or {}
        except Exception:
            pass
    return {}


# ── identity index readers ─────────────────────────────────────────────────────

def get_canonical_key(
    job_id: str,
    name: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Optional[str]:
    """Return the canonical key for *name*, or None if not found."""
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import variable_by_name
            from sqlalchemy import select

            with engine.connect() as conn:
                row = conn.execute(
                    select(variable_by_name.c.canonical_key).where(
                        (variable_by_name.c.job_id == job_id)
                        & (variable_by_name.c.name == name.upper())
                    )
                ).fetchone()
            if row:
                return row[0]
        except Exception as exc:
            logger.debug("[index_db] get_canonical_key DB failed: %s", exc)

    # Strict gate — skip the 96 MB JSON load when DB is authoritative.
    if _is_strict():
        return None
    # Fallback: load JSON (96 MB — only use when DB is unavailable)
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            return data.get("by_name", {}).get(name.upper())
        except Exception:
            pass
    return None


def get_identity_entry(
    job_id: str,
    canonical_key: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Optional[Dict[str, Any]]:
    """Return the identity entry dict for *canonical_key*.

    Matches the shape of ``by_identity[canonical_key]`` in the JSON file::

        {
          "names": [...],
          "access_identity": "...",
          "symbolic_identity": "...",
          "dsect": "...",
          "field_offset": ...,
          "file_label": "...",
          "files": {"stem": "node_id", ...}
        }
    """
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import variable_by_identity
            from sqlalchemy import select

            with engine.connect() as conn:
                row = conn.execute(
                    select(
                        variable_by_identity.c.names_json,
                        variable_by_identity.c.access_identity,
                        variable_by_identity.c.symbolic_identity,
                        variable_by_identity.c.dsect,
                        variable_by_identity.c.field_offset,
                        variable_by_identity.c.file_label,
                        variable_by_identity.c.files_json,
                    ).where(
                        (variable_by_identity.c.job_id == job_id)
                        & (variable_by_identity.c.canonical_key == canonical_key)
                    )
                ).mappings().fetchone()

            if row:
                return {
                    "names": json.loads(row["names_json"] or "[]"),
                    "access_identity": row["access_identity"],
                    "symbolic_identity": row["symbolic_identity"],
                    "dsect": row["dsect"],
                    "field_offset": row["field_offset"],
                    "file_label": row["file_label"],
                    "files": json.loads(row["files_json"] or "{}"),
                }
        except Exception as exc:
            logger.debug("[index_db] get_identity_entry DB failed: %s", exc)

    # Strict gate — skip JSON fallback when DB is authoritative.
    if _is_strict():
        return None
    # Fallback: load JSON
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            return data.get("by_identity", {}).get(canonical_key)
        except Exception:
            pass
    return None


def get_variable_file_node_id(
    job_id: str,
    canonical_key: str,
    file_stem: str,
) -> Optional[str]:
    """O(1) indexed lookup: ``(canonical_key, file_stem)`` → ``node_id``.

    Uses the denormalized ``variable_identity_files`` table for a single
    indexed SELECT instead of ``get_identity_entry()`` + ``json.loads()``.

    Falls back to ``get_identity_entry()`` when the table is unavailable
    or empty (old DBs that haven't been re-materialized yet).
    """
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from sqlalchemy import text as _text
            with engine.connect() as conn:
                row = conn.execute(_text(
                    "SELECT node_id FROM variable_identity_files "
                    "WHERE job_id = :jid AND canonical_key = :ck AND file_stem = :stem "
                    "LIMIT 1"
                ), {"jid": job_id, "ck": canonical_key, "stem": file_stem}).fetchone()
                if row:
                    return row[0]
                # Check if table has any data at all — if not, fall through
                has_data = conn.execute(_text(
                    "SELECT 1 FROM variable_identity_files WHERE job_id = :jid LIMIT 1"
                ), {"jid": job_id}).fetchone()
                if has_data:
                    return None  # table populated, stem genuinely absent
        except Exception:
            pass  # table doesn't exist or other issue — fall through

    # Fallback: full get_identity_entry + JSON parse
    entry = get_identity_entry(job_id, canonical_key)
    if entry:
        return (entry.get("files") or {}).get(file_stem)
    return None


def get_identity_by_name_bulk(
    job_id: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Dict[str, str]:
    """Return the full ``{name: canonical_key}`` mapping.

    Prefer using ``get_canonical_key`` for single lookups.  This function is
    for callers that load the entire index (e.g. build_variable_hop_index).
    Falls back to JSON when the DB has no rows.
    """
    logger.warning(
        "[index_db] get_identity_by_name_bulk called for job=%s — full table scan. "
        "Use get_canonical_key() for single-variable lookups.",
        job_id,
    )
    if _is_strict():
        raise RuntimeError(
            "get_identity_by_name_bulk is disabled (INDEX_DB_STRICT=true). "
            "Use get_canonical_key(job_id, name) for per-variable lookups."
        )
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import variable_by_name
            from sqlalchemy import select

            with engine.connect() as conn:
                rows = conn.execute(
                    select(
                        variable_by_name.c.name,
                        variable_by_name.c.canonical_key,
                    ).where(variable_by_name.c.job_id == job_id)
                ).fetchall()
            if rows:
                return {r[0]: r[1] for r in rows}
        except Exception as exc:
            logger.debug("[index_db] get_identity_by_name_bulk DB failed: %s", exc)

    # Strict gate — skip JSON fallback when DB is authoritative.
    if _is_strict():
        return {}
    # Fallback: load JSON
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            return data.get("by_name") or {}
        except Exception:
            pass
    return {}


# ── hop index readers ──────────────────────────────────────────────────────────

def get_hops_for_variable(
    job_id: str,
    canonical_key: str,
    *,
    file_stem: Optional[str] = None,
    fallback_path: Optional[Path] = None,
) -> Dict[str, List[Dict[str, Any]]]:
    """Return hop entries for *canonical_key*, optionally filtered to one file.

    Returns ``{file_stem: [hop_dict, ...]}`` matching the JSON index shape.
    """
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import variable_hops
            from sqlalchemy import select

            stmt = select(
                variable_hops.c.file_stem,
                variable_hops.c.line,
                variable_hops.c.expression,
                variable_hops.c.operation_type,
                variable_hops.c.transformation,
                variable_hops.c.relation,
                variable_hops.c.node_id,
                variable_hops.c.variable_name,
            ).where(
                (variable_hops.c.job_id == job_id)
                & (variable_hops.c.canonical_key == canonical_key)
            )
            if file_stem is not None:
                stmt = stmt.where(variable_hops.c.file_stem == file_stem)
            else:
                # Safety cap: unfiltered hop queries can return hundreds of
                # thousands of rows on large codebases. 50 K covers all
                # practical use cases (graph traversal stops much earlier).
                stmt = stmt.limit(50_000)

            with engine.connect() as conn:
                rows = conn.execute(stmt).mappings().all()

            result: Dict[str, List[Dict]] = {}
            for r in rows:
                hop = {
                    "line": r["line"],
                    "expression": r["expression"],
                    "operation_type": r["operation_type"],
                    "transformation": r["transformation"],
                    "relation": r["relation"],
                    "node_id": r["node_id"],
                    "variable_name": r["variable_name"],
                }
                result.setdefault(r["file_stem"], []).append(hop)
            if result:
                return result
        except Exception as exc:
            logger.debug("[index_db] get_hops_for_variable DB failed: %s", exc)

    # Strict gate — skip the 433 MB JSON load when DB is authoritative.
    if _is_strict():
        return {}
    # Fallback: load JSON (avoid loading 433 MB if possible)
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            entry = data.get(canonical_key) or {}
            if file_stem:
                return {file_stem: entry.get(file_stem) or []}
            return entry
        except Exception:
            pass
    return {}


def get_hop_seed_node_ids(
    job_id: str,
    canonical_key: str,
    file_stem: str,
) -> Optional[List[str]]:
    """Return seed node_ids from ``variable_hops`` for *(canonical_key, file_stem)*.

    Extracts node_ids where ``relation='target'`` (data flows **to** the node
    = potential setter sites).  Uses the ``ix_var_hops_job_key_file`` index
    for an O(log N) lookup.

    Returns ``None`` when the table is unavailable (caller should fall back).
    Returns empty list when no hops exist for this (canonical_key, file_stem).
    """
    engine = _get_engine(job_id)
    if engine is None:
        return None

    try:
        from sqlalchemy import text as _text
        with engine.connect() as conn:
            rows = conn.execute(_text(
                "SELECT DISTINCT node_id FROM variable_hops "
                "WHERE job_id = :jid AND canonical_key = :ck "
                "  AND file_stem = :stem AND relation = 'target'"
            ), {"jid": job_id, "ck": canonical_key, "stem": file_stem}).fetchall()
            return [r[0] for r in rows if r[0]]
    except Exception as exc:
        logger.debug("[index_db] get_hop_seed_node_ids failed: %s", exc)
        return None


# ── call graph readers ─────────────────────────────────────────────────────────

def get_call_graph(
    job_id: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """Return call graph as ``{"nodes": [...], "edges": [...]}`` from the DB.

    Falls back to loading the JSON file when the DB has no data.
    """
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import call_graph_nodes, call_graph_edges
            from sqlalchemy import select

            if _has_rows(engine, call_graph_nodes, job_id):
                with engine.connect() as conn:
                    node_rows = conn.execute(
                        select(
                            call_graph_nodes.c.stem,
                            call_graph_nodes.c.node_type,
                            call_graph_nodes.c.file,
                        ).where(call_graph_nodes.c.job_id == job_id)
                    ).mappings().all()
                    edge_rows = conn.execute(
                        select(
                            call_graph_edges.c.source,
                            call_graph_edges.c.target,
                            call_graph_edges.c.is_internal,
                            call_graph_edges.c.instructions_json,
                            call_graph_edges.c.call_sites_json,
                        ).where(call_graph_edges.c.job_id == job_id)
                    ).mappings().all()

                nodes = [
                    {"id": r["stem"], "type": r["node_type"], "file": r["file"]}
                    for r in node_rows
                ]
                edges = [
                    {
                        "source": r["source"],
                        "target": r["target"],
                        "is_internal": bool(r["is_internal"]),
                        "instructions": json.loads(r["instructions_json"] or "[]"),
                        "call_sites": json.loads(r["call_sites_json"] or "[]"),
                    }
                    for r in edge_rows
                ]
                return {"nodes": nodes, "edges": edges}
        except Exception as exc:
            logger.debug("[index_db] get_call_graph DB failed: %s", exc)

    # Strict gate — skip JSON fallback when DB is authoritative.
    if _is_strict():
        return {"nodes": [], "edges": []}
    # Fallback: load JSON
    if fallback_path and fallback_path.exists():
        try:
            return json.loads(fallback_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"nodes": [], "edges": []}


# ── targeted call graph readers (memory-efficient alternatives) ────────────────

def get_call_graph_node_ids(
    job_id: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Set[str]:
    """Return just the set of node stem IDs — avoids loading full graph."""
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import call_graph_nodes
            from sqlalchemy import select

            if _has_rows(engine, call_graph_nodes, job_id):
                with engine.connect() as conn:
                    rows = conn.execute(
                        select(call_graph_nodes.c.stem).where(
                            call_graph_nodes.c.job_id == job_id
                        )
                    ).fetchall()
                return {r[0] for r in rows}
        except Exception as exc:
            logger.debug("[index_db] get_call_graph_node_ids DB failed (job=%s): %s", job_id, exc)

    if _is_strict():
        return set()
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            return {str(n.get("id") or "") for n in data.get("nodes", [])}
        except Exception:
            pass
    return set()


def get_call_graph_node_types(
    job_id: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Dict[str, str]:
    """Return ``{stem: node_type}`` mapping — avoids loading full graph."""
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import call_graph_nodes
            from sqlalchemy import select

            if _has_rows(engine, call_graph_nodes, job_id):
                with engine.connect() as conn:
                    rows = conn.execute(
                        select(call_graph_nodes.c.stem, call_graph_nodes.c.node_type).where(
                            call_graph_nodes.c.job_id == job_id
                        )
                    ).fetchall()
                return {r[0]: (r[1] or "asm") for r in rows}
        except Exception as exc:
            logger.debug("[index_db] get_call_graph_node_types DB failed (job=%s): %s", job_id, exc)

    if _is_strict():
        return {}
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            return {
                str(n.get("id") or ""): str(n.get("type") or "asm")
                for n in data.get("nodes", [])
            }
        except Exception:
            pass
    return {}


def get_call_graph_edge_pairs(
    job_id: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Set[Tuple[str, str]]:
    """Return set of ``(source, target)`` tuples — no instructions or call_sites loaded."""
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import call_graph_nodes, call_graph_edges
            from sqlalchemy import select

            if _has_rows(engine, call_graph_nodes, job_id):
                with engine.connect() as conn:
                    rows = conn.execute(
                        select(call_graph_edges.c.source, call_graph_edges.c.target).where(
                            call_graph_edges.c.job_id == job_id
                        )
                    ).fetchall()
                return {(r[0], r[1]) for r in rows}
        except Exception as exc:
            logger.debug("[index_db] get_call_graph_edge_pairs DB failed (job=%s): %s", job_id, exc)

    if _is_strict():
        return set()
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            return {
                (str(e.get("source", "")), str(e.get("target", "")))
                for e in data.get("edges", [])
            }
        except Exception:
            pass
    return set()


def get_call_graph_adjacency(
    job_id: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Tuple[Dict[str, List[Tuple[str, str]]], Dict[str, List[str]]]:
    """Return ``(forward, reverse)`` adjacency maps — omits call_sites to save RAM.

    ``forward``  = ``{source: [(target, instruction)]}``
    ``reverse``  = ``{target: [source, ...]}``
    """
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import call_graph_nodes, call_graph_edges
            from sqlalchemy import select

            if _has_rows(engine, call_graph_nodes, job_id):
                with engine.connect() as conn:
                    rows = conn.execute(
                        select(
                            call_graph_edges.c.source,
                            call_graph_edges.c.target,
                            call_graph_edges.c.instructions_json,
                        ).where(call_graph_edges.c.job_id == job_id)
                    ).fetchall()

                forward: Dict[str, List[Tuple[str, str]]] = {}
                reverse: Dict[str, List[str]] = {}
                for src, tgt, instr_json in rows:
                    try:
                        instr_list = json.loads(instr_json or "[]")
                    except Exception:
                        instr_list = []
                    inst = str(instr_list[0]) if instr_list else "?"
                    forward.setdefault(src, []).append((tgt, inst))
                    if src not in reverse.setdefault(tgt, []):
                        reverse[tgt].append(src)
                return forward, reverse
        except Exception as exc:
            logger.debug("[index_db] get_call_graph_adjacency DB failed (job=%s): %s", job_id, exc)

    if _is_strict():
        return {}, {}
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            fwd: Dict[str, List[Tuple[str, str]]] = {}
            rev: Dict[str, List[str]] = {}
            for edge in data.get("edges", []):
                src = str(edge.get("source") or "")
                tgt = str(edge.get("target") or "")
                inst = str((edge.get("instructions") or ["?"])[0])
                fwd.setdefault(src, []).append((tgt, inst))
                if src not in rev.setdefault(tgt, []):
                    rev[tgt].append(src)
            return fwd, rev
        except Exception:
            pass
    return {}, {}


def get_call_graph_edge_type_map(
    job_id: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Dict[Tuple[str, str], str]:
    """Return ``{(source, target): instruction}`` — queries only instructions_json, not call_sites."""
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import call_graph_nodes, call_graph_edges
            from sqlalchemy import select

            if _has_rows(engine, call_graph_nodes, job_id):
                with engine.connect() as conn:
                    rows = conn.execute(
                        select(
                            call_graph_edges.c.source,
                            call_graph_edges.c.target,
                            call_graph_edges.c.instructions_json,
                        ).where(call_graph_edges.c.job_id == job_id)
                    ).fetchall()

                result: Dict[Tuple[str, str], str] = {}
                for src, tgt, instr_json in rows:
                    if not src or not tgt:
                        continue
                    try:
                        instr_list = json.loads(instr_json or "[]")
                    except Exception:
                        instr_list = []
                    result[(src, tgt)] = str(instr_list[0]) if instr_list else "?"
                return result
        except Exception as exc:
            logger.debug("[index_db] get_call_graph_edge_type_map DB failed (job=%s): %s", job_id, exc)

    if _is_strict():
        return {}
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            out: Dict[Tuple[str, str], str] = {}
            for e in data.get("edges", []):
                src = str(e.get("source") or "").strip()
                tgt = str(e.get("target") or "").strip()
                if not src or not tgt:
                    continue
                out[(src, tgt)] = str((e.get("instructions") or ["?"])[0])
            return out
        except Exception:
            pass
    return {}


def get_call_graph_edge_lines_map(
    job_id: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Dict[Tuple[str, str], Set[int]]:
    """Return ``{(source, target): {line_numbers}}`` from call_sites.line — discards other call_site fields."""
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import call_graph_nodes, call_graph_edges
            from sqlalchemy import select

            if _has_rows(engine, call_graph_nodes, job_id):
                with engine.connect() as conn:
                    rows = conn.execute(
                        select(
                            call_graph_edges.c.source,
                            call_graph_edges.c.target,
                            call_graph_edges.c.call_sites_json,
                        ).where(call_graph_edges.c.job_id == job_id)
                    ).fetchall()

                result: Dict[Tuple[str, str], Set[int]] = {}
                for src, tgt, cs_json in rows:
                    if not src or not tgt:
                        continue
                    try:
                        cs_list = json.loads(cs_json or "[]")
                    except Exception:
                        cs_list = []
                    lines: Set[int] = set()
                    for cs in cs_list:
                        ln = cs.get("line") if isinstance(cs, dict) else None
                        if isinstance(ln, int) and ln > 0:
                            lines.add(ln)
                    if lines:
                        result[(src, tgt)] = lines
                return result
        except Exception as exc:
            logger.debug("[index_db] get_call_graph_edge_lines_map DB failed (job=%s): %s", job_id, exc)

    if _is_strict():
        return {}
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            out: Dict[Tuple[str, str], Set[int]] = {}
            for e in data.get("edges", []):
                src = str(e.get("source") or "").strip()
                tgt = str(e.get("target") or "").strip()
                if not src or not tgt:
                    continue
                lines: Set[int] = set()
                for cs in e.get("call_sites") or []:
                    ln = cs.get("line")
                    if isinstance(ln, int) and ln > 0:
                        lines.add(ln)
                if lines:
                    out[(src, tgt)] = lines
            return out
        except Exception:
            pass
    return {}


def get_call_graph_slim(
    job_id: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """Return a minimal ``{"nodes": [...], "edges": [...]}`` dict — omits call_sites from edges.

    Use this when callers only need adjacency/instruction data (e.g. ``find_chains_through``).
    The returned edges contain ``source``, ``target``, and ``instructions`` but NOT ``call_sites``.
    """
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import call_graph_nodes, call_graph_edges
            from sqlalchemy import select

            if _has_rows(engine, call_graph_nodes, job_id):
                with engine.connect() as conn:
                    node_rows = conn.execute(
                        select(call_graph_nodes.c.stem, call_graph_nodes.c.node_type).where(
                            call_graph_nodes.c.job_id == job_id
                        )
                    ).fetchall()
                    edge_rows = conn.execute(
                        select(
                            call_graph_edges.c.source,
                            call_graph_edges.c.target,
                            call_graph_edges.c.instructions_json,
                        ).where(call_graph_edges.c.job_id == job_id)
                    ).fetchall()

                nodes = [{"id": r[0], "type": r[1] or "asm"} for r in node_rows]
                edges = []
                for src, tgt, instr_json in edge_rows:
                    try:
                        instructions = json.loads(instr_json or "[]")
                    except Exception:
                        instructions = []
                    edges.append({"source": src, "target": tgt, "instructions": instructions})
                return {"nodes": nodes, "edges": edges}
        except Exception as exc:
            logger.debug("[index_db] get_call_graph_slim DB failed (job=%s): %s", job_id, exc)

    if _is_strict():
        return {"nodes": [], "edges": []}
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            # Strip call_sites from edges to reduce memory
            slim_edges = [
                {
                    "source": e.get("source", ""),
                    "target": e.get("target", ""),
                    "instructions": e.get("instructions") or [],
                }
                for e in data.get("edges", [])
            ]
            slim_nodes = [{"id": n.get("id", ""), "type": n.get("type", "asm")} for n in data.get("nodes", [])]
            return {"nodes": slim_nodes, "edges": slim_edges}
        except Exception:
            pass
    return {"nodes": [], "edges": []}


# ── streaming index builder ───────────────────────────────────────────────────

def build_call_graph_indexes(
    job_id: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Optional[Dict[str, Any]]:
    """Build all chain-setter-analysis index maps in ONE streaming pass.

    Returns a dict with six index structures::

        file_type_map   {stem: type, stem_lower: type}
        node_type       {stem: "asm"|"cpp"}
        reverse_adj     {TARGET_UPPER: [(source, instruction), ...]}
        edge_type_map   {(source, target): instruction}
        edge_lines_map  {(source, target): {line_numbers}}
        forward_adj     {source_lower: {target_lower, ...}}

    Returns ``None`` when the DB is unavailable **and** the JSON fallback file
    does not exist — the caller should fall back to loading graph_payload the
    legacy way.

    The key optimization: ``call_sites_json`` is parsed per-row to extract
    ``target_module`` and ``line`` numbers, then the parsed call-site dicts are
    immediately discarded.  Only the lightweight index structures are kept in
    memory — the 200–400 MB ``callsite_map`` is NOT materialised here (use
    ``get_call_graph_callsites_for_edge`` for lazy per-edge lookups instead).
    """
    # ── helpers ────────────────────────────────────────────────────────────
    file_type_map: Dict[str, str] = {}
    node_type: Dict[str, str] = {}
    reverse_adj: Dict[str, List[Tuple[str, str]]] = {}
    edge_type_map: Dict[Tuple[str, str], str] = {}
    edge_lines_map: Dict[Tuple[str, str], Set[int]] = {}
    forward_adj: Dict[str, set] = {}

    def _add_reverse(key: str, src: str, instr: str) -> None:
        k = str(key or "").upper().strip()
        if not k or not src:
            return
        reverse_adj.setdefault(k, []).append((src, instr))

    def _process_nodes(nodes) -> None:
        for n in nodes:
            nid = str(n.get("id") or n.get("stem") or "").strip()
            nt = str(n.get("type") or n.get("node_type") or "asm").lower()
            if not nid:
                continue
            if nt in ("asm", "cpp"):
                node_type[nid] = nt
            file_type_map[nid] = nt
            file_type_map[nid.lower()] = nt

    def _process_edge(src: str, tgt: str, instr: str,
                      call_sites: List[Dict[str, Any]]) -> None:
        # edge_type_map
        edge_type_map[(src, tgt)] = instr

        # reverse_adj — primary target + call-site target_modules
        _add_reverse(tgt, src, instr)
        for cs in call_sites:
            tm = cs.get("target_module", "")
            if tm:
                _add_reverse(tm, src, str(cs.get("instruction") or instr))

        # edge_lines_map
        lines: Set[int] = set()
        for cs in call_sites:
            ln = cs.get("line")
            if isinstance(ln, int) and ln > 0:
                lines.add(ln)
        if lines:
            edge_lines_map[(src, tgt)] = lines

        # forward_adj
        src_l = src.lower()
        forward_adj.setdefault(src_l, set()).add(tgt.lower())
        for cs in call_sites:
            tm = (cs.get("target_module") or "").lower()
            if tm:
                forward_adj.setdefault(src_l, set()).add(tm)

    # ── DB path ────────────────────────────────────────────────────────────
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import call_graph_edges, call_graph_nodes
            from sqlalchemy import select

            if _has_rows(engine, call_graph_nodes, job_id):
                with engine.connect() as conn:
                    # 1) Nodes — lightweight
                    for row in conn.execute(
                        select(
                            call_graph_nodes.c.stem,
                            call_graph_nodes.c.node_type,
                        ).where(call_graph_nodes.c.job_id == job_id)
                    ):
                        _process_nodes([{"id": row[0], "type": row[1]}])

                    # 2) Edges — stream and build indexes
                    for row in conn.execute(
                        select(
                            call_graph_edges.c.source,
                            call_graph_edges.c.target,
                            call_graph_edges.c.instructions_json,
                            call_graph_edges.c.call_sites_json,
                        ).where(call_graph_edges.c.job_id == job_id)
                    ):
                        src = str(row[0] or "").strip()
                        tgt = str(row[1] or "").strip()
                        if not src or not tgt:
                            continue
                        try:
                            instrs = json.loads(row[2] or "[]")
                        except Exception:
                            instrs = []
                        instr = str(instrs[0]) if instrs else "?"
                        try:
                            call_sites = json.loads(row[3] or "[]")
                        except Exception:
                            call_sites = []
                        _process_edge(src, tgt, instr, call_sites)

                return {
                    "file_type_map": file_type_map,
                    "node_type": node_type,
                    "reverse_adj": reverse_adj,
                    "edge_type_map": edge_type_map,
                    "edge_lines_map": edge_lines_map,
                    "forward_adj": forward_adj,
                }
        except Exception as exc:
            logger.debug("[index_db] build_call_graph_indexes DB failed: %s", exc)

    # ── JSON fallback ──────────────────────────────────────────────────────
    if _is_strict():
        return None

    fp = fallback_path
    if fp and fp.exists():
        try:
            data = json.loads(fp.read_text(encoding="utf-8"))
        except Exception:
            return None

        _process_nodes(data.get("nodes") or [])

        for e in (data.get("edges") or []):
            src = str(e.get("source") or "").strip()
            tgt = str(e.get("target") or "").strip()
            if not src or not tgt:
                continue
            instrs = e.get("instructions") or []
            instr = str(instrs[0]) if instrs else str(e.get("instruction") or "?")
            call_sites = e.get("call_sites") or []
            _process_edge(src, tgt, instr, call_sites)

        # Let the raw JSON dict be GC'd immediately.
        del data

        return {
            "file_type_map": file_type_map,
            "node_type": node_type,
            "reverse_adj": reverse_adj,
            "edge_type_map": edge_type_map,
            "edge_lines_map": edge_lines_map,
            "forward_adj": forward_adj,
        }

    return None


def get_call_graph_callsites_for_edge(
    job_id: str,
    source: str,
    target: str,
    *,
    fallback_path: Optional[Path] = None,
) -> List[Dict[str, Any]]:
    """Return call-site dicts for a specific ``(source, target)`` edge.

    Uses the ``ix_cg_edges_job_src`` index for an O(log N) lookup — designed
    for lazy per-edge loading rather than pre-loading all 50K+ edges.
    """
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import call_graph_edges
            from sqlalchemy import select

            with engine.connect() as conn:
                rows = conn.execute(
                    select(call_graph_edges.c.call_sites_json).where(
                        (call_graph_edges.c.job_id == job_id)
                        & (call_graph_edges.c.source == source)
                        & (call_graph_edges.c.target == target)
                    )
                ).fetchall()
            if rows:
                # Take the last row (matches dict-overwrite behavior of
                # _edge_callsite_map when there are duplicate edges).
                try:
                    return json.loads(rows[-1][0] or "[]")
                except Exception:
                    return []
            return []
        except Exception as exc:
            logger.debug(
                "[index_db] get_call_graph_callsites_for_edge failed: %s", exc
            )

    # JSON fallback
    if _is_strict():
        return []
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            for e in data.get("edges") or []:
                if (str(e.get("source") or "").strip() == source
                        and str(e.get("target") or "").strip() == target):
                    return list(e.get("call_sites") or [])
        except Exception:
            pass
    return []


# ── universe readers ───────────────────────────────────────────────────────────

def get_variable_names(
    job_id: str,
    lang: str,
    *,
    fallback_path: Optional[Path] = None,
) -> Set[str]:
    """Return the set of known variable names for *lang* (``"asm"`` or ``"cpp"``).

    Falls back to loading the flat names JSON file.
    """
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import universe_variables, universe_variable_names
            from sqlalchemy import select

            with engine.connect() as conn:
                # Primary: use universe_variables (covering index on job_id, lang, name).
                rows = conn.execute(
                    select(universe_variables.c.name).where(
                        (universe_variables.c.job_id == job_id)
                        & (universe_variables.c.lang == lang)
                    ).distinct()
                ).fetchall()
                if rows:
                    return {r[0] for r in rows}

                # Fallback: older DBs may only have universe_variable_names populated.
                rows = conn.execute(
                    select(universe_variable_names.c.name).where(
                        (universe_variable_names.c.job_id == job_id)
                        & (universe_variable_names.c.lang == lang)
                    )
                ).fetchall()
                if rows:
                    return {r[0] for r in rows}
        except Exception as exc:
            logger.debug("[index_db] get_variable_names DB failed: %s", exc)

    # Strict gate — skip JSON fallback when DB is authoritative.
    if _is_strict():
        return set()
    # Fallback: load JSON
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            return set(data.get("variables") or [])
        except Exception:
            pass
    return set()


# ── Call-graph chain validation helpers ─────────────────────────────────────
# (restored from 9442ebc — dropped when readers.py was taken wholesale from
# dev_tabish_scalability_v2 during the merge; api/routes/knowledge_base.py
# imports these for chain_files edge validation.)


def get_call_graph_node_count(
    job_id: str,
    *,
    fallback_path: Optional[Path] = None,
) -> int:
    """Return the number of call-graph nodes for *job_id*."""
    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import call_graph_nodes
            from sqlalchemy import select, func

            with engine.connect() as conn:
                count = conn.execute(
                    select(func.count()).select_from(call_graph_nodes).where(
                        call_graph_nodes.c.job_id == job_id
                    )
                ).scalar()
            return int(count or 0)
        except Exception as exc:
            logger.debug("[index_db] get_call_graph_node_count DB failed (job=%s): %s", job_id, exc)

    if _is_strict():
        return 0
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            return len(data.get("nodes", []) or [])
        except Exception:
            pass
    return 0


def get_call_graph_existing_node_ids(
    job_id: str,
    stems: List[str],
    *,
    fallback_path: Optional[Path] = None,
) -> Set[str]:
    """Return the subset of *stems* that exist in the call graph."""
    wanted = [str(s or "").strip() for s in stems if str(s or "").strip()]
    if not wanted:
        return set()

    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import call_graph_nodes
            from sqlalchemy import select

            with engine.connect() as conn:
                rows = conn.execute(
                    select(call_graph_nodes.c.stem).where(
                        (call_graph_nodes.c.job_id == job_id)
                        & (call_graph_nodes.c.stem.in_(wanted))
                    )
                ).fetchall()
            return {str(r[0] or "") for r in rows if str(r[0] or "")}
        except Exception as exc:
            logger.debug(
                "[index_db] get_call_graph_existing_node_ids DB failed (job=%s): %s",
                job_id, exc,
            )

    if _is_strict():
        return set()
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            present = {str(n.get("id") or "") for n in data.get("nodes", [])}
            return {stem for stem in wanted if stem in present}
        except Exception:
            pass
    return set()


def get_call_graph_outgoing_targets(
    job_id: str,
    source: str,
    *,
    fallback_path: Optional[Path] = None,
) -> List[str]:
    """Return distinct outgoing target stems for one call-graph source node."""
    source = str(source or "").strip()
    if not source:
        return []

    engine = _get_engine(job_id)
    if engine is not None:
        try:
            from api.index_db.schema import call_graph_edges
            from sqlalchemy import select

            with engine.connect() as conn:
                rows = conn.execute(
                    select(call_graph_edges.c.target).where(
                        (call_graph_edges.c.job_id == job_id)
                        & (call_graph_edges.c.source == source)
                    )
                ).fetchall()

            seen: Set[str] = set()
            targets: List[str] = []
            for row in rows:
                tgt = str(row[0] or "").strip()
                if tgt and tgt not in seen:
                    seen.add(tgt)
                    targets.append(tgt)
            return targets
        except Exception as exc:
            logger.debug(
                "[index_db] get_call_graph_outgoing_targets DB failed (job=%s, source=%s): %s",
                job_id, source, exc,
            )

    if _is_strict():
        return []
    if fallback_path and fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            seen: Set[str] = set()
            targets: List[str] = []
            for edge in data.get("edges", []) or []:
                if str(edge.get("source") or "").strip() != source:
                    continue
                tgt = str(edge.get("target") or "").strip()
                if tgt and tgt not in seen:
                    seen.add(tgt)
                    targets.append(tgt)
            return targets
        except Exception:
            pass
    return []
