"""Pipeline index database package.

Provides memory-safe storage and retrieval for large pipeline output files:
  - global_variable_lineage.json  (7.78 GB)
  - cpp_variable_universe.json    (2.03 GB)
  - asm_variable_universe.json    (866 MB)
  - variable_hop_index.json       (433 MB)
  - variable_identity_index.json  (96 MB)
  - file_call_graph.json          (41 MB)
  - variable_modifier_index.json  (3.4 MB)
  - asm/cpp_variable_names.json   (small)

Backend is configurable via .env:
  INDEX_DB_BACKEND = sqlite        # default — one .db file per job
  INDEX_DB_BACKEND = postgresql    # shared DB, requires INDEX_DB_URL
  INDEX_DB_URL     = postgresql://user:pass@host/dbname
  INDEX_DB_BATCH_SIZE = 500        # rows per commit (controls peak RAM)
"""
from api.index_db.engine import get_engine, dispose_engine, job_id_from_path
from api.index_db.writers import (
    ingest_gvl,
    ingest_universe,
    ingest_modifier_index,
    ingest_identity_index,
    ingest_hop_index,
    ingest_call_graph,
)

__all__ = [
    "get_engine",
    "dispose_engine",
    "job_id_from_path",
    "ingest_gvl",
    "ingest_universe",
    "ingest_modifier_index",
    "ingest_identity_index",
    "ingest_hop_index",
    "ingest_call_graph",
]
