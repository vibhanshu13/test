"""Streaming pipeline index writers — memory-safe ingestion of large JSON files.

Design constraints
------------------
Every writer in this module is required to keep peak RAM consumption at
O(batch_size × avg_row_size), regardless of the source file size.  Files
can range from 3 MB (modifier index) to 7.78 GB (global variable lineage).

Techniques used
---------------
- **LazyGVL** (backward_traversal/utils/lazy_gvl.py): yields one node/edge
  at a time from global_variable_lineage.json (or .msgpack).  Handles both
  JSON and msgpack formats transparently.
- **ijson**: event-driven streaming JSON parser; ``ijson.items`` and
  ``ijson.kvitems`` yield one item/pair at a time from large arrays/objects.
- **Batch commit**: rows are accumulated in a Python list and flushed to the
  database every ``batch_size`` rows.  Default batch size is controlled by
  ``settings.INDEX_DB_BATCH_SIZE`` (default 500).
- **Two-pass GVL**: nodes and edges are ingested in separate file passes so
  only one section is live in memory at a time.

Error handling
--------------
All public functions are wrapped so that a DB write failure does not abort
the pipeline — a warning is logged and the function returns ``False``.  The
JSON file on disk remains the authoritative output; the DB is a secondary,
queryable index.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

# Known GVL edge fields extracted into indexed columns.
# Any field not in this set is preserved verbatim in extra_json (future-proof).
_GVL_EDGE_KNOWN = {
    "source", "target", "relation", "file", "line",
    "expression", "operation_type", "transformation",
    "symbolic_identity", "access_identity", "file_label",
    "field_offset", "dsect",
}

# CONVERGENCE NOTE: the materialized cpp_seed_keys/cpp_seed_file_keys
# ingestion (seed-key normalizer + strategy-priority constants) was removed.
# Seed lookup now runs on the gvl_nodes derived columns (terminal_base_lower /
# name_base_lower / asm_alias_lower, populated in Pass 1 below) via
# backward_traversal/utils/cpp_lineage_utils.find_cpp_seed_nodes_db — strategy
# logic stays in code and auto-backfills for pre-existing jobs.


def _extract_terminal(target: Optional[str]) -> Optional[str]:
    """Extract the terminal component of a GVL target/source identifier.

    Splits on ``->``, ``::``, ``.``, ``:`` (in that order) and returns the
    rightmost component, uppercased.  Used for indexed equality lookups that
    replace the leading-wildcard LIKE patterns in ``get_gvl_setter_edges``.

    Examples::

        "struct_field:fn::da7gl->cmSystem" → "CMSYSTEM"
        "memory:LG1G1:LG1OSI"             → "LG1OSI"
        "variable:/global/myVar"           → "MYVAR"
    """
    if not target:
        return None
    for sep in ['->', '::', '.', ':']:
        if sep in target:
            terminal = target.rsplit(sep, 1)[-1].strip().upper()
            return terminal or None
    return target.strip().upper() or None


def _derive_file_stem(file_value: Any) -> Optional[str]:
    """Return a normalized lower-case stem from a GVL ``file`` field."""
    raw = str(file_value or "").strip()
    if not raw or raw == "<global>":
        return None
    tail = raw.rsplit("/", 1)[-1].rsplit("\\", 1)[-1].strip()
    if not tail:
        return None
    stem = tail.rsplit(".", 1)[0].strip().lower()
    return stem or None

def _batch_insert(conn, table, rows: List[Dict[str, Any]]) -> None:
    """Bulk-insert *rows* into *table* using a single executemany call."""
    if rows:
        conn.execute(table.insert(), rows)


def _flush(conn, table, batch: List[Dict[str, Any]], batch_size: int) -> List:
    """Insert *batch* when it reaches *batch_size*; return new empty batch."""
    if len(batch) >= batch_size:
        _batch_insert(conn, table, batch)
        return []
    return batch


def _clear_job(engine, *tables, job_id: str) -> None:
    """Delete all rows for *job_id* from the given tables (reset before re-ingest)."""
    with engine.begin() as conn:
        for tbl in tables:
            conn.execute(tbl.delete().where(tbl.c.job_id == job_id))


# ── Seed-file materialization (standalone, no GVL file needed) ────────────────

def ingest_gvl(job_id: str, gvl_path: Path, batch_size: int = 5000) -> bool:
    """Stream global_variable_lineage into ``gvl_nodes`` and ``gvl_edges`` tables.

    Uses ``LazyGVL`` which handles both JSON and msgpack formats and keeps
    peak RAM at O(1 item).  Nodes and edges are ingested in separate passes.

    Args:
        job_id:     Pipeline job identifier.
        gvl_path:   Path to global_variable_lineage.json (or .msgpack).
        batch_size: Rows accumulated before each DB commit.

    Returns:
        True on success, False if the file is missing or an error occurs.
    """
    if not gvl_path or not gvl_path.exists():
        logger.warning("[index_db] GVL file not found: %s — skipping.", gvl_path)
        return False

    try:
        from api.index_db.engine import get_engine
        from api.index_db.schema import gvl_nodes, gvl_edges
        from backward_traversal.utils.lazy_gvl import LazyGVL

        engine = get_engine(job_id)
        _clear_job(engine, gvl_nodes, gvl_edges, job_id=job_id)

        gvl = LazyGVL(gvl_path)
        if not gvl:
            logger.warning("[index_db] GVL is empty or unreadable: %s", gvl_path)
            return False

        # ── Pass 1: nodes + derived seed columns + seed keys (Strategies 1, 5) ─
        from backward_traversal.utils.cpp_lineage_utils import (
            node_terminal_base_lower,
            node_name_base_lower,
        )
        node_count = 0
        with engine.begin() as conn:
            batch: List[Dict] = []
            for node in (gvl.get("nodes") or []):
                known_fields = {"id", "kind", "name"}
                extra = {k: v for k, v in node.items() if k not in known_fields}
                _nid = str(node.get("id") or "")
                _nname = str(node.get("name") or "")
                _meta = node.get("metadata") or {}
                _alias = str(_meta.get("asm_alias") or "").strip().lower()
                batch.append({
                    "job_id": job_id,
                    "node_id": _nid,
                    "kind": str(node.get("kind") or "")[:64] or None,
                    "name": _nname or None,
                    "extra_json": json.dumps(extra, separators=(",", ":")) if extra else None,
                    # Derived seed-lookup columns ('' sentinel = derived-but-empty,
                    # matching the engine backfill so rows are never re-scanned).
                    "terminal_base_lower": node_terminal_base_lower(_nid) or "",
                    "name_base_lower": node_name_base_lower(_nname) or "",
                    "asm_alias_lower": _alias,
                })
                node_count += 1
                batch = _flush(conn, gvl_nodes, batch, batch_size)


            _batch_insert(conn, gvl_nodes, batch)

        logger.info("[index_db] GVL nodes ingested: %d rows (job=%s)",
                    node_count, job_id)

        # ── Pass 2: edges (+ derived file_stem / target_terminal) ─────────────
        edge_count = 0
        with engine.begin() as conn:
            batch = []
            for edge in (gvl.get("edges") or []):
                _src = str(edge.get("source") or "") or None
                _tgt = str(edge.get("target") or "") or None
                _file_val = str(edge.get("file") or "") or None
                batch.append({
                    "job_id": job_id,
                    "source": _src,
                    "target": _tgt,
                    "source_lower": _src.lower() if _src else None,
                    "target_lower": _tgt.lower() if _tgt else None,
                    "relation": str(edge.get("relation") or "")[:64] or None,
                    "file": _file_val,
                    # lowercase stem (matches _derive_file_stem + query paths)
                    "file_stem": _derive_file_stem(_file_val),
                    "target_terminal": _extract_terminal(_tgt),
                    "line": edge.get("line"),
                    "expression": str(edge.get("expression") or "") or None,
                    "operation_type": str(edge.get("operation_type") or "")[:128] or None,
                    "transformation": str(edge.get("transformation") or "") or None,
                    "symbolic_identity": str(edge.get("symbolic_identity") or "") or None,
                    "access_identity": str(edge.get("access_identity") or "") or None,
                    "file_label": str(edge.get("file_label") or "") or None,
                    "field_offset": edge.get("field_offset"),
                    "dsect": str(edge.get("dsect") or "") or None,
                    "conditional_context": (
                        json.dumps(edge["conditional_context"], separators=(",", ":"))
                        if edge.get("conditional_context") else None
                    ),
                })
                edge_count += 1
                batch = _flush(conn, gvl_edges, batch, batch_size)

            _batch_insert(conn, gvl_edges, batch)

        logger.info("[index_db] GVL edges ingested: %d rows (job=%s)", edge_count, job_id)

        # Refresh planner statistics: the table contents just changed wholesale,
        # so pre-ingest stats (or none) would mislead index selection for every
        # backward-lineage query against this job.
        from api.index_db.engine import ensure_planner_statistics
        ensure_planner_statistics(engine, force=True)

        return True

    except Exception as exc:
        logger.warning(
            "[index_db] GVL ingestion failed (job=%s): %s — pipeline continues.",
            job_id, exc, exc_info=True,
        )
        return False


# ── Variable Universes ─────────────────────────────────────────────────────────

def ingest_universe(
    job_id: str,
    lang: str,
    universe_path: Optional[Path],
    names_path: Optional[Path],
    batch_size: int = 500,
) -> bool:
    """Stream a variable universe JSON into ``universe_variables`` and
    ``universe_variable_names`` tables.

    Uses ``ijson.kvitems`` to yield one variable-name entry at a time so peak
    RAM stays at O(one_variable_entry_list) ≪ 2 GB.

    Args:
        job_id:        Pipeline job identifier.
        lang:          Language tag — ``"asm"`` or ``"cpp"``.
        universe_path: Path to asm/cpp_variable_universe.json (can be None).
        names_path:    Path to asm/cpp_variable_names.json   (can be None).
        batch_size:    Rows per DB commit.

    Returns:
        True on success, False on any error.
    """
    try:
        import ijson
    except ImportError:
        logger.warning(
            "[index_db] ijson not installed — universe ingestion skipped. "
            "Install with: pip install ijson"
        )
        return False

    try:
        from api.index_db.engine import get_engine
        from api.index_db.schema import universe_variables

        engine = get_engine(job_id)
        # Clear only this lang's rows so we can resume individual lang passes.
        with engine.begin() as conn:
            conn.execute(
                universe_variables.delete().where(
                    (universe_variables.c.job_id == job_id)
                    & (universe_variables.c.lang == lang)
                )
            )

        # NOTE: universe_variable_names ingestion removed — variable names are
        # now read from universe_variables via a covering index
        # (ix_universe_vars_job_lang_name).  The table definition is kept in
        # schema.py for backward compat with older databases.

        # ── universe variables (large — stream with ijson) ─────────────────────
        var_count = 0
        if universe_path and universe_path.exists():
            with engine.begin() as conn:
                batch: List[Dict] = []

                # ijson.kvitems(f, "variables") yields (name, [entries]) one at a time.
                # Peak RAM = size of one variable's entry list (usually 1-5 small dicts).
                with open(universe_path, "rb") as f:
                    for _name, entries in ijson.kvitems(f, "variables"):
                        for entry in (entries or []):
                            batch.append(_entry_to_row(job_id, lang, entry))
                            var_count += 1
                            batch = _flush(conn, universe_variables, batch, batch_size)

                # extern_symbols section
                with open(universe_path, "rb") as f:
                    for _name, entry in ijson.kvitems(f, "extern_symbols"):
                        if entry:
                            batch.append(_entry_to_row(job_id, lang, entry))
                            var_count += 1
                            batch = _flush(conn, universe_variables, batch, batch_size)

                _batch_insert(conn, universe_variables, batch)

            logger.info(
                "[index_db] %s universe variables ingested: %d rows (job=%s)",
                lang, var_count, job_id,
            )

        return True

    except Exception as exc:
        logger.warning(
            "[index_db] Universe ingestion failed lang=%s (job=%s): %s — pipeline continues.",
            lang, job_id, exc, exc_info=True,
        )
        return False


def _entry_to_row(job_id: str, lang: str, entry: Dict[str, Any]) -> Dict[str, Any]:
    """Convert a VariableEntry dict to a universe_variables table row."""
    return {
        "job_id": job_id,
        "lang": lang,
        "name": str(entry.get("name") or ""),
        "kind": str(entry.get("kind") or "")[:64] or None,
        "scope": str(entry.get("scope") or "") or None,
        "file": str(entry.get("file") or "") or None,
        "line": entry.get("line"),
        "declaration_type": str(entry.get("declaration_type") or "")[:64] or None,
        "data_type": str(entry.get("data_type") or "") or None,
        "storage_class": str(entry.get("storage_class") or "")[:64] or None,
        "initial_value": str(entry.get("initial_value") or "") or None,
        "scope_chain": json.dumps(entry.get("scope_chain") or [], separators=(",", ":")),
        "aliased_as": json.dumps(entry.get("aliased_as") or [], separators=(",", ":")),
        "related_symbols": json.dumps(entry.get("related_symbols") or [], separators=(",", ":")),
        "all_locations": json.dumps(entry.get("all_locations") or [], separators=(",", ":")),
        "metadata_json": json.dumps(entry.get("metadata") or {}, separators=(",", ":")),
    }


# ── Variable Modifier Index ────────────────────────────────────────────────────

def ingest_modifier_index(
    job_id: str, index_path: Path, batch_size: int = 500
) -> bool:
    """Load variable_modifier_index.json and insert into ``variable_modifiers``.

    The modifier index is small (3.4 MB) so it is safe to load entirely,
    then batch-insert rows.

    Returns True on success, False on error.
    """
    if not index_path or not index_path.exists():
        logger.warning("[index_db] Modifier index not found: %s", index_path)
        return False

    try:
        from api.index_db.engine import get_engine
        from api.index_db.schema import variable_modifiers

        data = json.loads(index_path.read_text(encoding="utf-8"))
        index: Dict[str, List[str]] = data.get("index") or {}

        engine = get_engine(job_id)
        _clear_job(engine, variable_modifiers, job_id=job_id)

        row_count = 0
        with engine.begin() as conn:
            batch: List[Dict] = []
            for var_name, stems in index.items():
                for stem in stems:
                    batch.append({
                        "job_id": job_id,
                        "variable_name": str(var_name),
                        "file_stem": str(stem),
                    })
                    row_count += 1
                    batch = _flush(conn, variable_modifiers, batch, batch_size)
            _batch_insert(conn, variable_modifiers, batch)

        logger.info(
            "[index_db] Modifier index ingested: %d rows (job=%s)", row_count, job_id
        )
        return True

    except Exception as exc:
        logger.warning(
            "[index_db] Modifier index ingestion failed (job=%s): %s — pipeline continues.",
            job_id, exc, exc_info=True,
        )
        return False


# ── Variable Identity Index ────────────────────────────────────────────────────

def ingest_identity_index(
    job_id: str, index_path: Path, batch_size: int = 500
) -> bool:
    """Stream variable_identity_index.json into ``variable_by_name`` and
    ``variable_by_identity`` tables using ijson to avoid loading 96 MB at once.

    Returns True on success, False on error.
    """
    if not index_path or not index_path.exists():
        logger.warning("[index_db] Identity index not found: %s", index_path)
        return False

    try:
        import ijson
    except ImportError:
        logger.warning("[index_db] ijson not installed — identity index ingestion skipped.")
        return False

    try:
        from api.index_db.engine import get_engine
        from api.index_db.schema import (
            variable_by_name, variable_by_identity, variable_identity_files,
        )

        engine = get_engine(job_id)
        _clear_job(engine, variable_by_name, variable_by_identity,
                   variable_identity_files, job_id=job_id)

        # ── Pass 1: by_name (name → canonical_key mapping) ────────────────────
        name_count = 0
        with engine.begin() as conn:
            batch: List[Dict] = []
            with open(index_path, "rb") as f:
                for name, canonical_key in ijson.kvitems(f, "by_name"):
                    batch.append({
                        "job_id": job_id,
                        "name": str(name),
                        "canonical_key": str(canonical_key),
                    })
                    name_count += 1
                    batch = _flush(conn, variable_by_name, batch, batch_size)
            _batch_insert(conn, variable_by_name, batch)

        logger.info(
            "[index_db] Identity by_name ingested: %d rows (job=%s)", name_count, job_id
        )

        # ── Pass 2: by_identity (canonical_key → metadata) ────────────────────
        # Each value is a small dict; ijson.kvitems yields one at a time.
        # Also writes denormalized variable_identity_files rows from files_json.
        identity_count = 0
        vf_count = 0
        with engine.begin() as conn:
            batch = []
            vf_batch: List[Dict] = []
            with open(index_path, "rb") as f:
                for canonical_key, entry in ijson.kvitems(f, "by_identity"):
                    if not isinstance(entry, dict):
                        continue
                    fo = entry.get("field_offset")
                    files = entry.get("files") or {}
                    batch.append({
                        "job_id": job_id,
                        "canonical_key": str(canonical_key),
                        "names_json": json.dumps(
                            entry.get("names") or [], separators=(",", ":")
                        ),
                        "access_identity": str(entry.get("access_identity") or "") or None,
                        "symbolic_identity": str(entry.get("symbolic_identity") or "") or None,
                        "dsect": str(entry.get("dsect") or "") or None,
                        "field_offset": int(fo) if fo is not None else None,
                        "file_label": str(entry.get("file_label") or "") or None,
                        "files_json": json.dumps(
                            files, separators=(",", ":")
                        ),
                    })
                    identity_count += 1
                    batch = _flush(conn, variable_by_identity, batch, batch_size)
                    # Dual-write: denormalize files_json into variable_identity_files
                    for _vf_stem, _vf_nid in files.items():
                        if _vf_stem and _vf_nid:
                            vf_batch.append({
                                "job_id": job_id,
                                "canonical_key": str(canonical_key),
                                "file_stem": str(_vf_stem),
                                "node_id": str(_vf_nid),
                            })
                            vf_count += 1
                            vf_batch = _flush(conn, variable_identity_files, vf_batch, batch_size)
            _batch_insert(conn, variable_by_identity, batch)
            _batch_insert(conn, variable_identity_files, vf_batch)

        logger.info(
            "[index_db] Identity by_identity ingested: %d rows, "
            "identity_files: %d rows (job=%s)",
            identity_count, vf_count, job_id,
        )
        return True

    except Exception as exc:
        logger.warning(
            "[index_db] Identity index ingestion failed (job=%s): %s — pipeline continues.",
            job_id, exc, exc_info=True,
        )
        return False


# ── Variable Hop Index ─────────────────────────────────────────────────────────

def ingest_hop_index(
    job_id: str, index_path: Path, batch_size: int = 500
) -> bool:
    """Stream variable_hop_index.json into ``variable_hops`` table.

    The hop index JSON is structured as::

        {"_meta": {...}, "CanonicalKey1": {"stem1": [hops], "stem2": [...]}, ...}

    ``ijson.kvitems(f, "")`` yields one top-level ``(key, value)`` pair at a
    time.  For canonical keys the value is a ``{stem: [hops]}`` dict; peak RAM
    per iteration is bounded by the data for one canonical key (typically < 1 MB).

    Returns True on success, False on error.
    """
    if not index_path or not index_path.exists():
        logger.warning("[index_db] Hop index not found: %s", index_path)
        return False

    try:
        import ijson
    except ImportError:
        logger.warning("[index_db] ijson not installed — hop index ingestion skipped.")
        return False

    try:
        from api.index_db.engine import get_engine
        from api.index_db.schema import variable_hops

        engine = get_engine(job_id)
        _clear_job(engine, variable_hops, job_id=job_id)

        total_rows = 0
        with engine.begin() as conn:
            batch: List[Dict] = []
            with open(index_path, "rb") as f:
                for canonical_key, by_file in ijson.kvitems(f, ""):
                    # Skip metadata section.
                    if canonical_key == "_meta" or not isinstance(by_file, dict):
                        continue
                    for file_stem, hops in by_file.items():
                        for hop in (hops or []):
                            if not isinstance(hop, dict):
                                continue
                            batch.append({
                                "job_id": job_id,
                                "canonical_key": str(canonical_key),
                                "file_stem": str(file_stem),
                                "line": hop.get("line"),
                                "expression": str(hop.get("expression") or "") or None,
                                "operation_type": str(hop.get("operation_type") or "")[:128] or None,
                                "transformation": str(hop.get("transformation") or "") or None,
                                "relation": str(hop.get("relation") or "")[:16] or None,
                                "node_id": str(hop.get("node_id") or "") or None,
                                "variable_name": str(hop.get("variable_name") or "") or None,
                            })
                            total_rows += 1
                            batch = _flush(conn, variable_hops, batch, batch_size)
            _batch_insert(conn, variable_hops, batch)

        logger.info(
            "[index_db] Hop index ingested: %d rows (job=%s)", total_rows, job_id
        )
        return True

    except Exception as exc:
        logger.warning(
            "[index_db] Hop index ingestion failed (job=%s): %s — pipeline continues.",
            job_id, exc, exc_info=True,
        )
        return False


# ── Direct-to-DB ingest helpers (bypass JSON intermediary) ────────────────────

def ingest_modifier_index_from_dict(
    job_id: str, data: Dict[str, Any], batch_size: int = 500
) -> bool:
    """Insert modifier index data into ``variable_modifiers`` directly from a dict.

    Equivalent to ``ingest_modifier_index`` but avoids writing and re-reading
    the JSON intermediary file.  *data* must have the structure produced by
    ``build_modifier_index.build_index()``:
    ``{"_meta": {...}, "index": {variable_upper: [stem, ...], ...}}``.

    Returns True on success, False on error.
    """
    try:
        from api.index_db.engine import get_engine
        from api.index_db.schema import variable_modifiers

        index: Dict[str, List[str]] = data.get("index") or {}

        engine = get_engine(job_id)
        _clear_job(engine, variable_modifiers, job_id=job_id)

        row_count = 0
        with engine.begin() as conn:
            batch: List[Dict] = []
            for var_name, stems in index.items():
                for stem in stems:
                    batch.append({
                        "job_id": job_id,
                        "variable_name": str(var_name),
                        "file_stem": str(stem),
                    })
                    row_count += 1
                    batch = _flush(conn, variable_modifiers, batch, batch_size)
            _batch_insert(conn, variable_modifiers, batch)

        logger.info(
            "[index_db] Modifier index ingested (from dict): %d rows (job=%s)", row_count, job_id
        )
        return True

    except Exception as exc:
        logger.warning(
            "[index_db] Modifier index ingestion failed (job=%s): %s — pipeline continues.",
            job_id, exc, exc_info=True,
        )
        return False


def ingest_identity_index_from_dict(
    job_id: str, data: Dict[str, Any], batch_size: int = 500
) -> bool:
    """Insert identity index data into ``variable_by_name`` and
    ``variable_by_identity`` directly from a dict.

    Equivalent to ``ingest_identity_index`` but avoids writing and re-reading
    the 96 MB JSON intermediary file.  *data* must have the structure produced
    by ``build_variable_identity_index.build_index()``:
    ``{"_meta": {...}, "by_name": {name: canonical_key, ...},
       "by_identity": {canonical_key: {...}, ...}}``.

    Returns True on success, False on error.
    """
    try:
        from api.index_db.engine import get_engine
        from api.index_db.schema import variable_by_name, variable_by_identity

        engine = get_engine(job_id)
        _clear_job(engine, variable_by_name, variable_by_identity, job_id=job_id)

        # ── Pass 1: by_name ────────────────────────────────────────────────────
        name_count = 0
        with engine.begin() as conn:
            batch: List[Dict] = []
            for name, canonical_key in (data.get("by_name") or {}).items():
                batch.append({
                    "job_id": job_id,
                    "name": str(name),
                    "canonical_key": str(canonical_key),
                })
                name_count += 1
                batch = _flush(conn, variable_by_name, batch, batch_size)
            _batch_insert(conn, variable_by_name, batch)

        logger.info(
            "[index_db] Identity by_name ingested (from dict): %d rows (job=%s)", name_count, job_id
        )

        # ── Pass 2: by_identity ────────────────────────────────────────────────
        identity_count = 0
        with engine.begin() as conn:
            batch = []
            for canonical_key, entry in (data.get("by_identity") or {}).items():
                if not isinstance(entry, dict):
                    continue
                fo = entry.get("field_offset")
                batch.append({
                    "job_id": job_id,
                    "canonical_key": str(canonical_key),
                    "names_json": json.dumps(
                        entry.get("names") or [], separators=(",", ":")
                    ),
                    "access_identity": str(entry.get("access_identity") or "") or None,
                    "symbolic_identity": str(entry.get("symbolic_identity") or "") or None,
                    "dsect": str(entry.get("dsect") or "") or None,
                    "field_offset": int(fo) if fo is not None else None,
                    "file_label": str(entry.get("file_label") or "") or None,
                    "files_json": json.dumps(
                        entry.get("files") or {}, separators=(",", ":")
                    ),
                })
                identity_count += 1
                batch = _flush(conn, variable_by_identity, batch, batch_size)
            _batch_insert(conn, variable_by_identity, batch)

        logger.info(
            "[index_db] Identity by_identity ingested (from dict): %d rows (job=%s)",
            identity_count, job_id,
        )
        return True

    except Exception as exc:
        logger.warning(
            "[index_db] Identity index ingestion failed (job=%s): %s — pipeline continues.",
            job_id, exc, exc_info=True,
        )
        return False


def ingest_hop_index_from_buckets(
    job_id: str,
    tmpdir_path: Path,
    n_buckets: int,
    batch_size: int = 500,
) -> bool:
    """Stream hop index bucket JSONL files directly into ``variable_hops``.

    Called by ``build_variable_hop_index.build_index()`` when *job_id* is
    provided, bypassing the 433 MB JSON intermediary file entirely.

    Each bucket file ``b000.jsonl``..``b{n_buckets-1:03d}.jsonl`` contains
    one JSON array per line: ``[canonical_key, file_stem, hop_dict]``.

    Returns True on success, False on error.
    """
    try:
        from api.index_db.engine import get_engine
        from api.index_db.schema import variable_hops

        engine = get_engine(job_id)
        _clear_job(engine, variable_hops, job_id=job_id)

        total_rows = 0
        with engine.begin() as conn:
            batch: List[Dict] = []
            for bidx in range(n_buckets):
                bucket_path = tmpdir_path / f"b{bidx:03d}.jsonl"
                if not bucket_path.exists():
                    continue
                with open(bucket_path, "r", encoding="utf-8") as bfh:
                    for raw in bfh:
                        raw = raw.strip()
                        if not raw:
                            continue
                        try:
                            canonical_key, file_stem, hop = json.loads(raw)
                        except (ValueError, json.JSONDecodeError):
                            continue
                        if not isinstance(hop, dict):
                            continue
                        batch.append({
                            "job_id": job_id,
                            "canonical_key": str(canonical_key),
                            "file_stem": str(file_stem),
                            "line": hop.get("line"),
                            "expression": str(hop.get("expression") or "") or None,
                            "operation_type": str(hop.get("operation_type") or "")[:128] or None,
                            "transformation": str(hop.get("transformation") or "") or None,
                            "relation": str(hop.get("relation") or "")[:16] or None,
                            "node_id": str(hop.get("node_id") or "") or None,
                            "variable_name": str(hop.get("variable_name") or "") or None,
                        })
                        total_rows += 1
                        batch = _flush(conn, variable_hops, batch, batch_size)
            _batch_insert(conn, variable_hops, batch)

        logger.info(
            "[index_db] Hop index ingested (from buckets): %d rows (job=%s)", total_rows, job_id
        )
        return True

    except Exception as exc:
        logger.warning(
            "[index_db] Hop index ingestion failed (job=%s): %s — pipeline continues.",
            job_id, exc, exc_info=True,
        )
        return False


# ── File Call Graph ────────────────────────────────────────────────────────────

def ingest_call_graph(
    job_id: str, graph_path: Path, batch_size: int = 500
) -> bool:
    """Load file_call_graph.json and insert into ``call_graph_nodes`` and
    ``call_graph_edges`` tables.

    The call graph is 41 MB — small enough to load with json.load, then
    batch-insert nodes and edges separately.

    Returns True on success, False on error.
    """
    if not graph_path or not graph_path.exists():
        logger.warning("[index_db] Call graph not found: %s", graph_path)
        return False

    try:
        from api.index_db.engine import get_engine
        from api.index_db.schema import call_graph_nodes, call_graph_edges

        engine = get_engine(job_id)
        _clear_job(engine, call_graph_nodes, call_graph_edges, job_id=job_id)

        data = json.loads(graph_path.read_text(encoding="utf-8"))
        nodes: List[Dict] = data.get("nodes") or []
        edges: List[Dict] = data.get("edges") or []

        # ── nodes ──────────────────────────────────────────────────────────────
        with engine.begin() as conn:
            batch: List[Dict] = []
            for node in nodes:
                batch.append({
                    "job_id": job_id,
                    "stem": str(node.get("id") or ""),
                    "node_type": str(node.get("type") or "")[:16] or None,
                    "file": str(node.get("file") or "") or None,
                })
                batch = _flush(conn, call_graph_nodes, batch, batch_size)
            _batch_insert(conn, call_graph_nodes, batch)

        # ── edges ──────────────────────────────────────────────────────────────
        with engine.begin() as conn:
            batch = []
            for edge in edges:
                batch.append({
                    "job_id": job_id,
                    "source": str(edge.get("source") or ""),
                    "target": str(edge.get("target") or ""),
                    "is_internal": 1 if edge.get("is_internal") else 0,
                    "instructions_json": json.dumps(
                        edge.get("instructions") or [], separators=(",", ":")
                    ),
                    "call_sites_json": json.dumps(
                        edge.get("call_sites") or [], separators=(",", ":")
                    ),
                })
                batch = _flush(conn, call_graph_edges, batch, batch_size)
            _batch_insert(conn, call_graph_edges, batch)

        logger.info(
            "[index_db] Call graph ingested: %d nodes, %d edges (job=%s)",
            len(nodes), len(edges), job_id,
        )
        return True

    except Exception as exc:
        logger.warning(
            "[index_db] Call graph ingestion failed (job=%s): %s — pipeline continues.",
            job_id, exc, exc_info=True,
        )
        return False


def ingest_block_reach_facts(
    job_id: str,
    blueprint_dir: Path,
    batch_size: int = 500,
    max_blocks_per_file: int = 500,
    skip_if_exists: bool = True,
) -> bool:
    """Materialize backward-CFG reachability per (file, block) into the index DB.

    Lineage Facts Index, Phase 2 (docs/plans/2026-06-07-backward-lineage-
    facts-index-design.md): ``backward_reachable_blocks`` is a pure function
    of the blueprint, but the backward-lineage dep-var BFS recomputes it per
    dep_var.  This runs the walk once per (file, block) at build time so the
    BFS becomes a packed-set lookup (backward_traversal/utils/reach_facts.py).

    Streaming + RAM-bounded: one blueprint live at a time; rows flushed every
    *batch_size*; the blueprint frame cache is cleared periodically.  Files
    with more than *max_blocks_per_file* blocks are skipped (design doc risk
    note) — the query side transparently falls back to live compute for them.

    Args:
        job_id:              Pipeline job identifier.
        blueprint_dir:       Directory containing *.asm.json / *.mac.json.
        batch_size:          Rows accumulated before each executemany flush.
        max_blocks_per_file: Skip oversized files (rows would be ~O(blocks²)).
        skip_if_exists:      Return early when the job already has facts rows
                             (resume-friendly; pass False to force a rebuild).

    Returns:
        True on success (or skip), False on error.
    """
    try:
        from sqlalchemy import select, func as sa_func

        from api.index_db.engine import get_engine
        from api.index_db.schema import block_reach_facts
        from backward_traversal.tracing.asm_backward_tracer import (
            backward_reachable_blocks,
        )
        from backward_traversal.utils.blueprint_utils import (
            clear_blueprint_cache,
            load_json,
        )
        from backward_traversal.utils.reach_facts import (
            blueprint_stem,
            pack_reachable,
        )

        engine = get_engine(job_id)

        if skip_if_exists:
            with engine.connect() as conn:
                existing = conn.execute(
                    select(sa_func.count())
                    .select_from(block_reach_facts)
                    .where(block_reach_facts.c.job_id == job_id)
                ).scalar() or 0
            if existing:
                logger.info(
                    "[index_db] block_reach_facts already populated for job=%s "
                    "(%d rows) — skipping build.", job_id, existing,
                )
                return True

        _clear_job(engine, block_reach_facts, job_id=job_id)

        bp_paths = sorted(Path(blueprint_dir).glob("*.asm.json")) + sorted(
            Path(blueprint_dir).glob("*.mac.json")
        )
        n_rows = 0
        n_files = 0
        n_oversized = 0
        with engine.begin() as conn:
            batch: List[Dict] = []
            for i, bp_path in enumerate(bp_paths):
                try:
                    bp = load_json(bp_path, keys={"blocks", "call_graph"})
                except Exception as exc:
                    logger.debug(
                        "[index_db] reach-facts: unreadable blueprint %s: %s",
                        bp_path.name, exc,
                    )
                    continue
                block_ids = [
                    str(b.get("id") or "")
                    for b in (bp.get("blocks") or [])
                    if b.get("id")
                ]
                if not block_ids:
                    continue
                if len(block_ids) > max_blocks_per_file:
                    n_oversized += 1
                    logger.info(
                        "[index_db] reach-facts: %s has %d blocks "
                        "(> cap %d) — skipped, query side will fall back.",
                        bp_path.name, len(block_ids), max_blocks_per_file,
                    )
                    continue
                stem = blueprint_stem(bp_path)
                for bid in block_ids:
                    # Same parameters the dep-var BFS uses (reach_facts.py
                    # only serves the uncapped expand_subroutine_callers walk).
                    reach = backward_reachable_blocks(
                        bp, bid,
                        expand_subroutine_callers=True,
                        bp_path=str(bp_path),
                    )
                    batch.append({
                        "job_id": job_id,
                        "file_stem": stem,
                        "anchor_block": bid,
                        "before_line": 0,
                        "reachable_packed": pack_reachable(reach),
                    })
                    n_rows += 1
                    batch = _flush(conn, block_reach_facts, batch, batch_size)
                n_files += 1
                if (i + 1) % 200 == 0:
                    clear_blueprint_cache()  # bound RAM across thousands of files
            _batch_insert(conn, block_reach_facts, batch)
        clear_blueprint_cache()

        logger.info(
            "[index_db] block_reach_facts ingested: %d rows across %d file(s), "
            "%d oversized skipped (job=%s)",
            n_rows, n_files, n_oversized, job_id,
        )
        return True

    except Exception as exc:
        logger.warning(
            "[index_db] block_reach_facts ingestion failed (job=%s): %s — "
            "pipeline continues (BFS falls back to live CFG walks).",
            job_id, exc, exc_info=True,
        )
        return False
