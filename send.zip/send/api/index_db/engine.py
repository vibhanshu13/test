"""Per-job index database engine factory.

Lifecycle
---------
- ``get_engine(job_id)``  — creates (or returns cached) engine for one job.
  For SQLite this produces a per-job ``.db`` file; all tables are created on
  first access.  For PostgreSQL the shared database is used with ``job_id``
  columns partitioning rows.
- ``dispose_engine(job_id)``  — closes all pooled connections (call after
  ingestion completes to free file handles / network sockets).

Backend selection (.env)
------------------------
  INDEX_DB_BACKEND = sqlite        # default
  INDEX_DB_BACKEND = postgresql
  INDEX_DB_URL     = postgresql://user:pass@host/dbname
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from threading import Lock
from typing import Dict, Optional

from sqlalchemy import create_engine, event, select, text
from sqlalchemy.engine import Engine

logger = logging.getLogger(__name__)

_engines: Dict[str, Engine] = {}
_lock = Lock()


def _derive_file_stem(file_value: Optional[str]) -> Optional[str]:
    """Return a normalized lower-case stem from a GVL ``file`` field."""
    raw = str(file_value or "").strip()
    if not raw or raw == "<global>":
        return None
    tail = raw.rsplit("/", 1)[-1].rsplit("\\", 1)[-1].strip()
    if not tail:
        return None
    stem = tail.rsplit(".", 1)[0]
    stem = stem.strip().lower()
    return stem or None


def _apply_sqlite_pragmas(engine: Engine) -> None:
    """Register a connect-event that sets performance/safety PRAGMAs on each
    new SQLite connection.  Must be called immediately after engine creation
    (before any connections are opened).
    """
    @event.listens_for(engine, "connect")
    def _set_pragmas(dbapi_connection, _connection_record):
        cursor = dbapi_connection.cursor()
        # Write-Ahead Log: readers never block writers and vice-versa.
        cursor.execute("PRAGMA journal_mode=WAL")
        # NORMAL: flush on checkpoints, not after every commit → ~5× faster writes.
        cursor.execute("PRAGMA synchronous=NORMAL")
        # 256 MB page cache: avoids working-set misses on databases that
        # exceed a few GB (e.g. 18 GB index.db with ~3 M gvl_edges rows).
        cursor.execute("PRAGMA cache_size=-262144")
        # Use disk for temp tables so that large INSERT...SELECT DISTINCT
        # (cpp_seed_file_keys materialization) doesn't OOM on 20-50 M rows.
        cursor.execute("PRAGMA temp_store=FILE")
        # Larger page size reduces B-tree depth for long TEXT keys.
        cursor.execute("PRAGMA page_size=8192")
        # 2 GB memory-mapped I/O window: reduces syscall overhead on large
        # sequential reads.  For an 18 GB DB this maps ~11 %; the OS page
        # cache transparently handles eviction.
        cursor.execute("PRAGMA mmap_size=2147483648")
        # Wait up to 30 s for a write lock before raising "database is locked".
        # On large DBs, writes (backfills, ingestion) hold locks longer and
        # concurrent API reads need more time to wait.
        cursor.execute("PRAGMA busy_timeout=30000")
        cursor.close()


def _apply_sqlite_column_migrations(engine: Engine) -> None:
    """Add columns that exist in the current schema but are absent from an
    older SQLite database (``ALTER TABLE … ADD COLUMN`` is idempotent here
    because we check ``PRAGMA table_info`` first).

    ``metadata.create_all()`` only creates *missing tables*; it does not add
    new columns to existing tables.  This function bridges that gap for SQLite
    so pipelines built before a column was added continue to work.
    """
    # Map table_name → list of (column_name, sqlite_type) to add if missing.
    _ADDITIVE_COLUMNS: Dict[str, list] = {
        "gvl_edges": [
            ("conditional_context", "TEXT"),
            ("source_lower", "TEXT"),
            ("target_lower", "TEXT"),
            ("file_stem", "TEXT"),
            ("target_terminal", "TEXT"),
        ],
        # DB-backed seed finding for the backward-lineage dep-var BFS
        # (tier-2 fast path on corpora whose GVL exceeds the in-RAM
        # projection caps).  Derived, indexed, exact-match columns:
        #   terminal_base_lower — last identifier component of node_id with
        #                         trailing digit-only components stripped
        #                         (covers ::X / :X / ->X / .X suffix matching
        #                         and the [N] array base form, P26)
        #   name_base_lower     — lower(name) with a trailing [N] stripped
        #   asm_alias_lower     — lower(metadata.asm_alias) (Strategy 1)
        "gvl_nodes": [
            ("terminal_base_lower", "TEXT"),
            ("name_base_lower", "TEXT"),
            ("asm_alias_lower", "TEXT"),
        ],
    }

    with engine.begin() as conn:
        for table_name, columns in _ADDITIVE_COLUMNS.items():
            rows = conn.execute(text(f"PRAGMA table_info({table_name})")).fetchall()
            existing = {row[1] for row in rows}  # index 1 = column name
            for col_name, col_type in columns:
                if col_name not in existing:
                    conn.execute(
                        text(f"ALTER TABLE {table_name} ADD COLUMN {col_name} {col_type}")
                    )
                    logger.info(
                        "[index_db] migrated %s: added column %s %s",
                        table_name, col_name, col_type,
                    )


def _backfill_gvl_derived_columns(engine: Engine) -> None:
    """Populate derived gvl_edges columns for rows that predate them.

    Runs once per engine creation.  Rows ingested after the schema change already
    have these columns set, so only NULL rows are updated.  Indexes are created
    with ``IF NOT EXISTS`` so the call is fully idempotent.
    """
    with engine.begin() as conn:
        rows = conn.execute(text("PRAGMA table_info(gvl_edges)")).fetchall()
        existing = {row[1] for row in rows}
        required = {"source_lower", "target_lower", "file_stem"}
        if not required.issubset(existing):
            return  # columns not yet added; create_all will handle it

        # Count rows that need backfill so we can log progress.
        need_src = conn.execute(text(
            "SELECT COUNT(*) FROM gvl_edges "
            "WHERE source_lower IS NULL AND source IS NOT NULL"
        )).scalar() or 0
        need_tgt = conn.execute(text(
            "SELECT COUNT(*) FROM gvl_edges "
            "WHERE target_lower IS NULL AND target IS NOT NULL"
        )).scalar() or 0

        if need_src + need_tgt == 0:
            # Nothing to backfill — just ensure indexes exist.
            conn.execute(text(
                "CREATE INDEX IF NOT EXISTS ix_gvl_edges_job_src_lower "
                "ON gvl_edges(job_id, source_lower)"
            ))
            conn.execute(text(
                "CREATE INDEX IF NOT EXISTS ix_gvl_edges_job_tgt_lower "
                "ON gvl_edges(job_id, target_lower)"
            ))
            return

        logger.info(
            "[index_db] backfilling source_lower/target_lower "
            "(%d + %d rows) …",
            need_src, need_tgt,
        )

        # Backfill only NULL rows (pre-existing data from before this migration)
        if need_src:
            logger.info("[index_db] backfilling source_lower for %d rows …", need_src)
        result_src = conn.execute(text(
            "UPDATE gvl_edges SET source_lower = LOWER(source) "
            "WHERE source_lower IS NULL AND source IS NOT NULL"
        ))
        if need_src:
            logger.info("[index_db] source_lower done (%d rows updated)", result_src.rowcount or 0)

        if need_tgt:
            logger.info("[index_db] backfilling target_lower for %d rows …", need_tgt)
        result_tgt = conn.execute(text(
            "UPDATE gvl_edges SET target_lower = LOWER(target) "
            "WHERE target_lower IS NULL AND target IS NOT NULL"
        ))
        if need_tgt:
            logger.info("[index_db] target_lower done (%d rows updated)", result_tgt.rowcount or 0)

        backfilled = (result_src.rowcount or 0) + (result_tgt.rowcount or 0)
        if backfilled:
            logger.info(
                "[index_db] backfilled source_lower/target_lower for %d rows",
                backfilled,
            )

        # Create indexes if they don't already exist
        logger.info("[index_db] creating source_lower/target_lower indexes …")
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_gvl_edges_job_src_lower "
            "ON gvl_edges(job_id, source_lower)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_gvl_edges_job_tgt_lower "
            "ON gvl_edges(job_id, target_lower)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_gvl_edges_job_rel_file_stem "
            "ON gvl_edges(job_id, relation, file_stem)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_gvl_edges_job_rel_file_stem_line "
            "ON gvl_edges(job_id, relation, file_stem, line)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_gvl_edges_job_rel "
            "ON gvl_edges(job_id, relation)"
        ))
        logger.info("[index_db] source_lower/target_lower indexes ready")


def _backfill_file_stem(engine: Engine) -> None:
    """Populate file_stem for gvl_edges rows that predate this column.

    Registers ``Path.stem`` as a SQLite UDF (``path_stem``) and runs a bulk
    ``UPDATE … SET file_stem = path_stem(file)`` in chunks of 500 K rows.
    Each chunk is committed independently so the WAL stays bounded and
    progress is logged.

    Previous implementation fetched rows into Python one-by-one (SELECT →
    Path().stem → UPDATE per row) which took 5+ hours on 16 M rows.  The UDF
    approach lets SQLite iterate internally — ~100× faster.
    """
    import sqlite3 as _sqlite3

    # ── 1. Quick check via SQLAlchemy: is backfill needed? ──
    with engine.connect() as conn:
        info_rows = conn.execute(text("PRAGMA table_info(gvl_edges)")).fetchall()
        existing = {row[1] for row in info_rows}
        if "file_stem" not in existing:
            return

        need = conn.execute(text(
            "SELECT COUNT(*) FROM gvl_edges WHERE file_stem IS NULL AND file IS NOT NULL"
        )).scalar()
        if not need:
            return

    logger.info("[index_db] backfilling file_stem for %d gvl_edges rows …", need)

    # ── 2. Open a raw sqlite3 connection with the path_stem UDF ──
    # Extract DB file path from the engine URL (sqlite:///path/to/db).
    db_path = str(engine.url).replace("sqlite:///", "")
    con = _sqlite3.connect(db_path)
    # Carry over the same PRAGMAs so writes are fast.
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("PRAGMA cache_size=-262144")
    con.execute("PRAGMA busy_timeout=30000")

    def _path_stem(f):
        """UDF: lowercased ``Path(f).stem`` (matches _derive_file_stem and the
        lowercase stems our writers store / query paths compare)."""
        if not f:
            return None
        try:
            return Path(f).stem.lower()
        except Exception:
            return str(f).lower()

    con.create_function("path_stem", 1, _path_stem)

    # ── 3. Chunked UPDATE with intermediate COMMITs + progress logs ──
    batch_size = 500_000
    done = 0
    while done < need:
        cur = con.execute(
            "UPDATE gvl_edges SET file_stem = path_stem(file) "
            "WHERE rowid IN ("
            "  SELECT rowid FROM gvl_edges "
            "  WHERE file_stem IS NULL AND file IS NOT NULL "
            "  LIMIT ?"
            ")",
            (batch_size,),
        )
        chunk = cur.rowcount
        con.commit()
        done += chunk
        logger.info(
            "[index_db] backfill file_stem progress: %d / %d (%.1f%%)",
            done, need, done * 100.0 / need,
        )
        if chunk == 0:
            break

    # ── 4. Create index and clean up ──
    con.execute(
        "CREATE INDEX IF NOT EXISTS ix_gvl_edges_job_file_stem "
        "ON gvl_edges(job_id, file_stem)"
    )
    con.commit()
    con.close()

    logger.info("[index_db] backfilled file_stem for %d rows", need)

    # (cpp_seed_file_keys materialization removed — readers.py does runtime
    # JOIN via get_seed_file_stems / filter_seeds_by_file_stem instead)


def _backfill_target_terminal(engine: Engine) -> None:
    """Populate ``target_terminal`` for gvl_edges rows that predate this column.

    Extracts the terminal component from the ``target`` field (after the last
    ``->``, ``::``, ``.``, or ``:`` separator), uppercased.  Uses a SQLite UDF
    and chunked UPDATEs (same pattern as ``_backfill_file_stem``).

    The ``ix_gvl_edges_job_tgt_term`` index replaces the leading-wildcard LIKE
    queries in ``get_gvl_setter_edges`` (O(16.7M) table scan → O(log N) lookup).
    """
    import sqlite3 as _sqlite3

    with engine.connect() as conn:
        info_rows = conn.execute(text("PRAGMA table_info(gvl_edges)")).fetchall()
        existing = {row[1] for row in info_rows}
        if "target_terminal" not in existing:
            return

        need = conn.execute(text(
            "SELECT COUNT(*) FROM gvl_edges "
            "WHERE target_terminal IS NULL AND target IS NOT NULL"
        )).scalar()
        if not need:
            return

    logger.info("[index_db] backfilling target_terminal for %d gvl_edges rows …", need)

    db_path = str(engine.url).replace("sqlite:///", "")
    con = _sqlite3.connect(db_path)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("PRAGMA cache_size=-262144")
    con.execute("PRAGMA busy_timeout=30000")

    def _extract_terminal_udf(target):
        if not target:
            return None
        for sep in ['->', '::', '.', ':']:
            if sep in target:
                terminal = target.rsplit(sep, 1)[-1].strip().upper()
                return terminal or None
        return target.strip().upper() or None

    con.create_function("extract_terminal", 1, _extract_terminal_udf)

    batch_size = 500_000
    done = 0
    while done < need:
        cur = con.execute(
            "UPDATE gvl_edges SET target_terminal = extract_terminal(target) "
            "WHERE rowid IN ("
            "  SELECT rowid FROM gvl_edges "
            "  WHERE target_terminal IS NULL AND target IS NOT NULL "
            "  LIMIT ?"
            ")",
            (batch_size,),
        )
        chunk = cur.rowcount
        con.commit()
        done += chunk
        logger.info(
            "[index_db] backfill target_terminal progress: %d / %d (%.1f%%)",
            done, need, done * 100.0 / need,
        )
        if chunk == 0:
            break

    con.execute(
        "CREATE INDEX IF NOT EXISTS ix_gvl_edges_job_tgt_term "
        "ON gvl_edges(job_id, target_terminal)"
    )
    con.commit()
    con.close()

    logger.info("[index_db] backfilled target_terminal for %d rows", need)


def _rematerialize_identity_files(engine: Engine) -> None:
    """Expand ``variable_by_identity.files_json`` into ``variable_identity_files``.

    Each ``files_json`` value is a JSON object ``{stem: node_id}``.  This
    function unpacks every entry into a separate row for indexed lookups,
    replacing ``json.loads()`` at query time with an O(1) indexed SELECT.

    Pattern: precondition
    checks, skip when already populated, batch INSERT.
    """
    try:
        with engine.connect() as conn:
            has_identity = conn.execute(text(
                "SELECT COUNT(*) FROM variable_by_identity LIMIT 1"
            )).scalar() or 0
            if not has_identity:
                return  # nothing to materialize from

            has_files = conn.execute(text(
                "SELECT COUNT(*) FROM variable_identity_files LIMIT 1"
            )).scalar() or 0
            if has_files:
                return  # already populated — skip
    except Exception:
        return  # table doesn't exist yet or other issue

    logger.info("[index_db] materializing variable_identity_files from files_json …")

    try:
        import json as _json

        with engine.connect() as conn:
            rows = conn.execute(text(
                "SELECT job_id, canonical_key, files_json "
                "FROM variable_by_identity "
                "WHERE files_json IS NOT NULL AND files_json != '{}'"
            )).fetchall()

        batch: list = []
        batch_size = 5000
        count = 0

        with engine.begin() as conn:
            for job_id_val, canonical_key_val, files_json_str in rows:
                try:
                    files_dict = _json.loads(files_json_str or "{}")
                except Exception:
                    continue
                for file_stem, node_id in files_dict.items():
                    if file_stem and node_id:
                        batch.append({
                            "job_id": job_id_val,
                            "canonical_key": canonical_key_val,
                            "file_stem": str(file_stem),
                            "node_id": str(node_id),
                        })
                        count += 1
                        if len(batch) >= batch_size:
                            conn.execute(text(
                                "INSERT INTO variable_identity_files "
                                "(job_id, canonical_key, file_stem, node_id) "
                                "VALUES (:job_id, :canonical_key, :file_stem, :node_id)"
                            ), batch)
                            batch = []
            if batch:
                conn.execute(text(
                    "INSERT INTO variable_identity_files "
                    "(job_id, canonical_key, file_stem, node_id) "
                    "VALUES (:job_id, :canonical_key, :file_stem, :node_id)"
                ), batch)

        logger.info(
            "[index_db] variable_identity_files materialized: %d rows", count,
        )
    except Exception as exc:
        logger.warning(
            "[index_db] variable_identity_files materialization failed: %s",
            exc, exc_info=True,
        )


def _ensure_covering_indexes(engine: Engine) -> None:
    """Create covering indexes that were added after the initial schema.

    Called once per engine.  ``CREATE INDEX IF NOT EXISTS`` is idempotent.
    """
    with engine.begin() as conn:
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_universe_vars_job_lang_name "
            "ON universe_variables(job_id, lang, name)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_var_hops_job_node "
            "ON variable_hops(job_id, node_id)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_var_hops_job_file_var "
            "ON variable_hops(job_id, file_stem, variable_name)"
        ))


def _backfill_gvl_node_seed_columns(engine: Engine) -> None:
    """Populate derived gvl_nodes seed-lookup columns for rows that predate them.

    Backfills terminal_base_lower / name_base_lower / asm_alias_lower in
    batches (never the full table in RAM) and creates their indexes.  These
    columns power the DB-backed seed finding used by the backward-lineage
    dep-var BFS on corpora whose GVL exceeds the in-RAM projection caps.
    Idempotent: only NULL terminal_base_lower rows are scanned, and a sentinel
    '' is written when no terminal can be derived so rows are not re-scanned.
    """
    from backward_traversal.utils.cpp_lineage_utils import (
        node_terminal_base_lower,
        node_name_base_lower,
    )

    with engine.begin() as conn:
        rows = conn.execute(text("PRAGMA table_info(gvl_nodes)")).fetchall()
        existing = {row[1] for row in rows}
        required = {"terminal_base_lower", "name_base_lower", "asm_alias_lower"}
        if not required.issubset(existing):
            return  # columns not yet added

        result = conn.execution_options(stream_results=True).execute(text(
            "SELECT id, node_id, name, extra_json FROM gvl_nodes "
            "WHERE terminal_base_lower IS NULL"
        ))
        updates = []
        backfilled = 0
        while True:
            chunk = result.fetchmany(5000)
            if not chunk:
                break
            for row in chunk:
                node_id = row[1] or ""
                name = row[2] or ""
                alias = None
                if row[3]:
                    try:
                        extra = json.loads(row[3])
                        meta = extra.get("metadata") if isinstance(extra, dict) else None
                        if isinstance(meta, dict):
                            alias = meta.get("asm_alias")
                        if alias is None and isinstance(extra, dict):
                            alias = extra.get("asm_alias")
                    except Exception:
                        alias = None
                updates.append({
                    "id": row[0],
                    # '' sentinel (not NULL) so already-scanned rows are skipped
                    "tbl": node_terminal_base_lower(node_id) or "",
                    "nbl": node_name_base_lower(name) or "",
                    "aal": str(alias).strip().lower() if alias else "",
                })
            if updates:
                conn.execute(
                    text(
                        "UPDATE gvl_nodes SET terminal_base_lower = :tbl, "
                        "name_base_lower = :nbl, asm_alias_lower = :aal "
                        "WHERE id = :id"
                    ),
                    updates,
                )
                backfilled += len(updates)
                updates = []
        if backfilled:
            logger.info(
                "[index_db] backfilled seed-lookup columns for %d gvl_nodes rows",
                backfilled,
            )

        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_gvl_nodes_job_terminal "
            "ON gvl_nodes(job_id, terminal_base_lower)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_gvl_nodes_job_name_base "
            "ON gvl_nodes(job_id, name_base_lower)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_gvl_nodes_job_alias "
            "ON gvl_nodes(job_id, asm_alias_lower)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_gvl_nodes_job_kind "
            "ON gvl_nodes(job_id, kind)"
        ))


def ensure_planner_statistics(engine: Engine, *, force: bool = False) -> None:
    """Run a bounded ANALYZE when the database has no planner statistics.

    Without ``sqlite_stat1`` the query planner has no row-distribution data
    and falls back to schema-order heuristics — measured to pick a full
    ``(job_id, file_stem)`` index walk over a MULTI-INDEX OR for the
    seed-stem lookup (50 ms vs 0.5 ms per call at 177 K edges, growing
    linearly with corpus size).  ``analysis_limit`` bounds the one-time cost
    on multi-million-row tables (sampled statistics are sufficient for
    index selection).

    ``force=True`` re-analyzes even when statistics exist — used after bulk
    ingestion, where stats describing the pre-ingest table mislead the
    planner just as badly as no stats at all.
    """
    try:
        with engine.begin() as conn:
            if not force:
                row = conn.execute(text(
                    "SELECT 1 FROM sqlite_master "
                    "WHERE type='table' AND name='sqlite_stat1'"
                )).fetchone()
                if row is not None and conn.execute(
                    text("SELECT 1 FROM sqlite_stat1 LIMIT 1")
                ).fetchone() is not None:
                    return
            conn.execute(text("PRAGMA analysis_limit=4000"))
            conn.execute(text("ANALYZE"))
        logger.info("[index_db] ANALYZE completed (planner statistics %s)",
                    "refreshed" if force else "built")
    except Exception as exc:
        logger.debug("[index_db] ANALYZE skipped: %s", exc)


def compact_database(job_id: str) -> None:
    """Checkpoint the WAL and reclaim free pages after bulk ingestion.

    A freshly built job leaves two kinds of disk bloat behind:
    - the WAL file (hundreds of MB after GVL ingestion) — reclaimed by
      ``wal_checkpoint(TRUNCATE)``;
    - free pages inside index.db from ``_clear_job`` delete+reingest cycles —
      reclaimed by ``VACUUM``, which is only run when the freelist is
      meaningful (> 2% of pages) since it rewrites the whole file and needs
      transient disk for a copy.

    Call after the last index.db write of the pipeline (Step 7).  Safe to
    skip on failure — bloat is a disk cost, not a correctness issue.
    """
    try:
        engine = get_engine(job_id)
        from api.config import settings
        db_path = Path(settings.JOBS_BASE_DIR) / job_id / "index.db"
        wal_path = Path(str(db_path) + "-wal")
        before_db = db_path.stat().st_size if db_path.exists() else 0
        before_wal = wal_path.stat().st_size if wal_path.exists() else 0

        with engine.connect() as conn:
            conn = conn.execution_options(isolation_level="AUTOCOMMIT")
            conn.execute(text("PRAGMA wal_checkpoint(TRUNCATE)"))
            freelist = conn.execute(text("PRAGMA freelist_count")).fetchone()[0]
            pages = conn.execute(text("PRAGMA page_count")).fetchone()[0]
            if pages and freelist / pages > 0.02:
                conn.execute(text("VACUUM"))
                conn.execute(text("PRAGMA wal_checkpoint(TRUNCATE)"))

        after_db = db_path.stat().st_size if db_path.exists() else 0
        after_wal = wal_path.stat().st_size if wal_path.exists() else 0
        logger.info(
            "[index_db] compacted job=%s: db %.0f→%.0f MB, wal %.0f→%.0f MB"
            " (freelist %d/%d pages)",
            job_id, before_db / 1e6, after_db / 1e6,
            before_wal / 1e6, after_wal / 1e6, freelist, pages,
        )
    except Exception as exc:
        logger.warning("[index_db] compaction skipped (job=%s): %s", job_id, exc)


def _ensure_schema_version(engine: Engine) -> None:
    """Insert the initial version row and warn if schema is behind.

    Called once per engine, right after ``metadata.create_all()``.
    - If the ``schema_version`` table is empty, insert version=1.
    - If the stored version is *less than* ``CURRENT_SCHEMA_VERSION`` log a
      warning; automatic migrations are not implemented yet — run the
      appropriate migration script manually.
    - If the stored version is *greater than* ``CURRENT_SCHEMA_VERSION`` the
      code is older than the database; warn and continue (safe for reads).
    """
    from api.index_db.schema import schema_version, CURRENT_SCHEMA_VERSION
    from datetime import datetime, timezone

    with engine.begin() as conn:
        row = conn.execute(select(schema_version)).mappings().fetchone()
        if row is None:
            conn.execute(
                schema_version.insert().values(
                    id=1,
                    version=CURRENT_SCHEMA_VERSION,
                    applied_at=datetime.now(timezone.utc).isoformat(),
                )
            )
            logger.debug(
                "[index_db] schema_version initialised at v%d", CURRENT_SCHEMA_VERSION
            )
        else:
            stored = row["version"]
            if stored < CURRENT_SCHEMA_VERSION:
                logger.warning(
                    "[index_db] schema is at v%d but code expects v%d — "
                    "run the migration script to upgrade.",
                    stored,
                    CURRENT_SCHEMA_VERSION,
                )
            elif stored > CURRENT_SCHEMA_VERSION:
                logger.warning(
                    "[index_db] schema is at v%d but code only knows v%d — "
                    "this binary may be older than the database.",
                    stored,
                    CURRENT_SCHEMA_VERSION,
                )


def get_engine(job_id: str) -> Engine:
    """Return the SQLAlchemy engine for *job_id*'s index database.

    Creates the engine and all schema tables on first call.  Subsequent calls
    return the cached engine without touching the database.

    Thread-safe: a single lock guards the ``_engines`` dict so only one
    engine per job is ever created even under concurrent pipeline workers.
    """
    # Fast path — no lock needed once the engine exists.
    if job_id in _engines:
        return _engines[job_id]

    with _lock:
        # Re-check after acquiring lock (another thread may have created it).
        if job_id in _engines:
            return _engines[job_id]

        # Lazy import to avoid circular dependency at module load time.
        from api.config import settings

        backend = settings.INDEX_DB_BACKEND.lower()

        if backend == "sqlite":
            db_path = Path(settings.JOBS_BASE_DIR) / job_id / "index.db"
            db_path.parent.mkdir(parents=True, exist_ok=True)
            engine = create_engine(
                f"sqlite:///{db_path}",
                # SQLite is single-writer; allow multiple threads to share the
                # same connection object without raising "check_same_thread".
                connect_args={"check_same_thread": False},
                # Restrict to one connection so WAL mode is effective and the
                # file is not held open by idle overflow connections.
                pool_size=1,
                max_overflow=2,
                pool_timeout=120,
            )
            _apply_sqlite_pragmas(engine)
            logger.info(
                "[index_db] SQLite engine created: %s (job=%s)", db_path, job_id
            )
        else:
            # PostgreSQL / MySQL / other — caller must configure INDEX_DB_URL.
            index_url = settings.INDEX_DB_URL
            if not index_url:
                raise RuntimeError(
                    f"INDEX_DB_URL must be set in .env when "
                    f"INDEX_DB_BACKEND={backend!r}. "
                    f"Example: INDEX_DB_URL=postgresql://user:pass@host/dbname"
                )
            engine = create_engine(
                index_url,
                # Verify connections before use (catches stale sockets).
                pool_pre_ping=True,
                pool_size=5,
                max_overflow=10,
            )
            logger.info(
                "[index_db] %s engine created for job=%s", backend, job_id
            )

        # Create all tables that do not yet exist (idempotent).
        from api.index_db.schema import metadata
        metadata.create_all(engine)
        # Add any columns that exist in the current schema but are absent from
        # older SQLite databases (no-op for PostgreSQL / fresh SQLite files).
        if backend == "sqlite":
            _apply_sqlite_column_migrations(engine)
            _backfill_gvl_derived_columns(engine)
            _backfill_file_stem(engine)
            _backfill_target_terminal(engine)
            _ensure_covering_indexes(engine)
            _rematerialize_identity_files(engine)
            _backfill_gvl_node_seed_columns(engine)
            ensure_planner_statistics(engine)
        _ensure_schema_version(engine)

        _engines[job_id] = engine
        return engine


def job_id_from_path(path: Path) -> Optional[str]:
    """Derive job_id from any path inside ``jobs/{job_id}/...``.

    Returns the first path component relative to ``JOBS_BASE_DIR``, or
    ``None`` when the path is not under that directory or when the config
    is unavailable (e.g. in standalone scripts without a .env file).
    """
    try:
        from api.config import settings
        jobs_base = Path(settings.JOBS_BASE_DIR).resolve()
        rel = Path(path).resolve().relative_to(jobs_base)
        parts = rel.parts
        return parts[0] if parts else None
    except Exception:
        return None


def dispose_engine(job_id: str) -> None:
    """Dispose the engine for *job_id*, closing all pooled connections.

    Call this once after ingestion for a job is fully complete to release
    file handles (SQLite) or network sockets (PostgreSQL).  The engine can
    be recreated by calling ``get_engine`` again if needed.
    """
    with _lock:
        engine = _engines.pop(job_id, None)
    if engine is not None:
        engine.dispose()
        logger.debug("[index_db] engine disposed for job=%s", job_id)
