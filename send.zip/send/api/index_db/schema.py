"""SQLAlchemy Core table definitions for the pipeline index database.

Uses SQLAlchemy Core (MetaData + Table) rather than ORM so that bulk
INSERTs go through executemany without the ORM object-creation overhead.
Every table carries a ``job_id`` column so SQLite (per-job file) and
PostgreSQL (shared database) can use the same schema unchanged.
"""
from __future__ import annotations

from sqlalchemy import (
    Column,
    Index,
    Integer,
    LargeBinary,
    MetaData,
    String,
    Table,
    Text,
)

metadata = MetaData()

# ---------------------------------------------------------------------------
# Schema versioning
#
# Bump CURRENT_SCHEMA_VERSION whenever a table definition changes in a
# **breaking** way (column renamed/removed, type changed).  Purely additive
# changes (new column with a default, new table) do NOT need a bump because
# ``metadata.create_all()`` is idempotent.
#
# Migration rules:
#   - Each integer version maps to a function in engine._MIGRATIONS dict.
#   - Migrations run in order from (stored_version + 1) up to CURRENT_SCHEMA_VERSION.
#   - The version row is updated inside the same transaction as the migration.
# ---------------------------------------------------------------------------

CURRENT_SCHEMA_VERSION: int = 1

schema_version = Table(
    "schema_version",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("version", Integer, nullable=False),
    Column("applied_at", Text),   # ISO-8601 timestamp of last successful migration
)

# ── Global Variable Lineage ────────────────────────────────────────────────────
# Source: global_variable_lineage.json  (up to 7.78 GB)

gvl_nodes = Table(
    "gvl_nodes",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("job_id", String(128), nullable=False),
    # node_id  e.g. "memory:WB1ACCTC" or "memory:LG1G1:LG1OSI"
    Column("node_id", Text, nullable=False),
    Column("kind", String(64)),   # memory, parameter, struct_field, variable, …
    Column("name", Text),         # leaf name when present
    # All original fields not otherwise indexed (JSON string for forward-compat)
    Column("extra_json", Text),
    # Derived seed-lookup columns (DB-backed dep-var seed finding; see
    # backward_traversal/utils/cpp_lineage_utils.py helpers + engine backfill):
    Column("terminal_base_lower", Text),  # last id component, [N]-stripped
    Column("name_base_lower", Text),      # lower(name), trailing [N] stripped
    Column("asm_alias_lower", Text),      # lower(metadata.asm_alias)
    Index("ix_gvl_nodes_job_node", "job_id", "node_id"),
    Index("ix_gvl_nodes_job_terminal", "job_id", "terminal_base_lower"),
    Index("ix_gvl_nodes_job_name_base", "job_id", "name_base_lower"),
    Index("ix_gvl_nodes_job_alias", "job_id", "asm_alias_lower"),
    Index("ix_gvl_nodes_job_kind", "job_id", "kind"),
)

gvl_edges = Table(
    "gvl_edges",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("job_id", String(128), nullable=False),
    Column("source", Text),
    Column("target", Text),
    Column("source_lower", Text),           # pre-lowered for indexed LIKE queries
    Column("target_lower", Text),           # pre-lowered for indexed LIKE queries
    Column("relation", String(64)),         # assign, define, use, …
    Column("file", Text),                   # source file path or stem
    Column("file_stem", Text),              # normalized basename stem for exact scope filters
    Column("line", Integer),
    Column("expression", Text),
    Column("operation_type", String(128)),
    Column("transformation", Text),
    Column("symbolic_identity", Text),      # e.g. "LG1G1:LG1OSI"
    Column("access_identity", Text),        # e.g. "CE1CR5:17"
    Column("file_label", Text),             # e.g. "da76:WB1ACCTC"
    Column("field_offset", Integer),
    Column("dsect", Text),
    Column("conditional_context", Text),       # JSON list of condition dicts
    Column("target_terminal", Text),              # terminal component of target (after last . -> :: :), uppercased
    Index("ix_gvl_edges_job_src", "job_id", "source"),
    Index("ix_gvl_edges_job_tgt", "job_id", "target"),
    Index("ix_gvl_edges_job_src_lower", "job_id", "source_lower"),
    Index("ix_gvl_edges_job_tgt_lower", "job_id", "target_lower"),
    Index("ix_gvl_edges_job_rel", "job_id", "relation"),
    Index("ix_gvl_edges_job_file", "job_id", "file"),
    # Merge union: HEAD's relation-scoped stem indexes + tabish's stem/terminal indexes
    Index("ix_gvl_edges_job_rel_file_stem", "job_id", "relation", "file_stem"),
    Index("ix_gvl_edges_job_rel_file_stem_line", "job_id", "relation", "file_stem", "line"),
    Index("ix_gvl_edges_job_file_stem", "job_id", "file_stem"),
    Index("ix_gvl_edges_job_tgt_term", "job_id", "target_terminal"),
)

# ── Variable Universes ─────────────────────────────────────────────────────────
# Sources: asm_variable_universe.json (866 MB), cpp_variable_universe.json (2 GB)

universe_variables = Table(
    "universe_variables",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("job_id", String(128), nullable=False),
    Column("lang", String(8), nullable=False),   # "asm" | "cpp"
    Column("name", Text, nullable=False),
    Column("kind", String(64)),
    Column("scope", Text),
    Column("file", Text),
    Column("line", Integer),
    Column("declaration_type", String(64)),
    Column("data_type", Text),
    Column("storage_class", String(64)),
    Column("initial_value", Text),
    Column("scope_chain", Text),      # JSON array
    Column("aliased_as", Text),       # JSON array of alias names
    Column("related_symbols", Text),  # JSON array
    Column("all_locations", Text),    # JSON array of {file,line,context}
    Column("metadata_json", Text),    # JSON object (arbitrary extra fields)
    Index("ix_universe_vars_job_name", "job_id", "name"),
    Index("ix_universe_vars_job_lang", "job_id", "lang"),
    Index("ix_universe_vars_job_file", "job_id", "file"),
    Index("ix_universe_vars_job_lang_name", "job_id", "lang", "name"),
)

# Sources: asm_variable_names.json, cpp_variable_names.json  (small flat name sets)
universe_variable_names = Table(
    "universe_variable_names",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("job_id", String(128), nullable=False),
    Column("lang", String(8), nullable=False),   # "asm" | "cpp"
    Column("name", Text, nullable=False),
    Index("ix_universe_names_job_lang", "job_id", "lang"),
    Index("ix_universe_names_uniq", "job_id", "lang", "name", unique=True),
)

# ── Variable Modifier Index ────────────────────────────────────────────────────
# Source: variable_modifier_index.json  (3.4 MB)

variable_modifiers = Table(
    "variable_modifiers",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("job_id", String(128), nullable=False),
    Column("variable_name", Text, nullable=False),
    Column("file_stem", Text, nullable=False),
    Index("ix_var_modifiers_job_var", "job_id", "variable_name"),
)

# ── Variable Identity Index ────────────────────────────────────────────────────
# Source: variable_identity_index.json  (96 MB)

variable_by_name = Table(
    "variable_by_name",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("job_id", String(128), nullable=False),
    Column("name", Text, nullable=False),            # variable name (uppercase)
    Column("canonical_key", Text, nullable=False),   # e.g. "CE1CR5:17"
    Index("ix_var_by_name_job_name", "job_id", "name", unique=True),
)

variable_by_identity = Table(
    "variable_by_identity",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("job_id", String(128), nullable=False),
    Column("canonical_key", Text, nullable=False),
    Column("names_json", Text),          # JSON array of known names
    Column("access_identity", Text),
    Column("symbolic_identity", Text),
    Column("dsect", Text),
    Column("field_offset", Integer),
    Column("file_label", Text),
    Column("files_json", Text),          # JSON object: {stem: node_id}
    Index("ix_var_identity_job_key", "job_id", "canonical_key", unique=True),
    Index("ix_var_identity_access", "job_id", "access_identity"),
)

# Denormalized from variable_by_identity.files_json.  Each row is one
# {file_stem → node_id} pair extracted from the JSON object, enabling
# indexed lookups without json.loads() and reverse (file → identity) queries.
variable_identity_files = Table(
    "variable_identity_files",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("job_id", String(128), nullable=False),
    Column("canonical_key", Text, nullable=False),
    Column("file_stem", Text, nullable=False),
    Column("node_id", Text, nullable=False),
    Index("ix_var_id_files_job_key_stem", "job_id", "canonical_key", "file_stem"),
    Index("ix_var_id_files_job_stem", "job_id", "file_stem"),
)

# ── Variable Hop Index ─────────────────────────────────────────────────────────
# Source: variable_hop_index.json  (433 MB)

variable_hops = Table(
    "variable_hops",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("job_id", String(128), nullable=False),
    Column("canonical_key", Text, nullable=False),
    Column("file_stem", Text, nullable=False),
    Column("line", Integer),
    Column("expression", Text),
    Column("operation_type", String(128)),
    Column("transformation", Text),
    Column("relation", String(16)),       # "source" | "target"
    Column("node_id", Text),
    Column("variable_name", Text),
    Index("ix_var_hops_job_key", "job_id", "canonical_key"),
    Index("ix_var_hops_job_key_file", "job_id", "canonical_key", "file_stem"),
    Index("ix_var_hops_job_node", "job_id", "node_id"),
    Index("ix_var_hops_job_file_var", "job_id", "file_stem", "variable_name"),
)

# ── File Call Graph ────────────────────────────────────────────────────────────
# Source: file_call_graph.json  (41 MB)

call_graph_nodes = Table(
    "call_graph_nodes",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("job_id", String(128), nullable=False),
    Column("stem", Text, nullable=False),
    Column("node_type", String(16)),   # "asm" | "cpp" | "header" | "external"
    Column("file", Text),
    Index("ix_cg_nodes_job_stem", "job_id", "stem", unique=True),
)

call_graph_edges = Table(
    "call_graph_edges",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("job_id", String(128), nullable=False),
    Column("source", Text, nullable=False),
    Column("target", Text, nullable=False),
    Column("is_internal", Integer),       # 1 = internal, 0 = external
    Column("instructions_json", Text),    # JSON array of opcode strings
    Column("call_sites_json", Text),      # JSON array of call-site dicts
    Index("ix_cg_edges_job_src", "job_id", "source"),
    Index("ix_cg_edges_job_tgt", "job_id", "target"),
)

# ── Block Reachability Facts ───────────────────────────────────────────────────
# Lineage Facts Index, Phase 2 (docs/plans/2026-06-07-backward-lineage-facts-
# index-design.md): precomputed backward-CFG reachability per (file, anchor
# block), built once per job after parsing.  The backward-lineage dep-var BFS
# reads these instead of re-running backward_reachable_blocks per dep_var.
# reachable_packed holds gzip(json([block_id, ...])); rows are only written
# for the uncapped walk (before_line=0, expand_subroutine_callers=True) —
# capped walks fall back to live compute.  Pack/unpack helpers live in
# backward_traversal/utils/reach_facts.py (shared with the query side).

block_reach_facts = Table(
    "block_reach_facts",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("job_id", String(128), nullable=False),
    Column("file_stem", Text, nullable=False),     # blueprint stem, lowercase
    Column("anchor_block", Text, nullable=False),
    Column("before_line", Integer, nullable=False, server_default="0"),
    Column("reachable_packed", LargeBinary),       # gzip(json(sorted block ids))
    Index(
        "ix_brf_job_stem_anchor",
        "job_id", "file_stem", "anchor_block", "before_line",
    ),
)

# CONVERGENCE NOTE: the cpp_seed_keys / cpp_seed_file_keys tables were removed.
# Seed lookup runs on the gvl_nodes derived columns (terminal_base_lower /
# name_base_lower / asm_alias_lower) via cpp_lineage_utils.find_cpp_seed_nodes_db
# — strategy logic stays in code (no re-ingest needed for a strategy fix) and
# auto-backfills for pre-existing jobs.  DBs created while the tables existed
# may still contain them as orphans; they are ignored.
