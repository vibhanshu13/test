"""
3-tier variable usage search against KB parser outputs.

Tier 1: asm_variable_universe.db / cpp_variable_universe.db  (SQLite — preferred)
        Falls back to .json if .db not yet built for this KB.
Tier 2: variable_identity_index.json                          (supplementary — 28% coverage)
Tier 3: per-file .asm.json blueprints                         (fallback for identity-only vars)
"""

from __future__ import annotations

import difflib
import json
import logging
import sqlite3
import threading
import re
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level SQLite connection cache  (per-worker-process lifetime)
# ---------------------------------------------------------------------------
# Each open SQLite connection holds a tiny amount of RAM (~100 KB).
# Cap at 4 open connections (2 KBs × 2 DBs each) to avoid fd leaks.
_CONN_CACHE_MAX = 4
_conn_cache: OrderedDict = OrderedDict()   # db_path_str → sqlite3.Connection
_conn_lock = threading.Lock()

# ---------------------------------------------------------------------------
# Legacy full-file JSON cache (used as fallback when .db not yet present).
# Cap at 2 active KBs (6 keys: 3 per KB) to bound peak RSS.
# ---------------------------------------------------------------------------
_DATA_CACHE_MAX = 6
_data_cache: OrderedDict = OrderedDict()

_blueprint_lru: OrderedDict = OrderedDict()
_BLUEPRINT_CACHE_MAX = 32

# Priority for deduplication when the same (file, line) appears with multiple contexts
_CONTEXT_PRIORITY = {"definition": 0, "modification": 1, "reference": 2}

# Blueprint edge relation → UsageContext value
_RELATION_TO_CONTEXT: Dict[str, str] = {
    "define":    "definition",
    "assign":    "modification",
    "use":       "reference",
    "alias":     "reference",
    "arg_bind":  "reference",
}


# ---------------------------------------------------------------------------
# SQLite helpers
# ---------------------------------------------------------------------------

def _get_universe_conn(db_path: Path) -> Optional[sqlite3.Connection]:
    """Return a cached SQLite connection for *db_path*, opening it if needed.

    Returns None when the database file does not exist.
    Thread-safe via ``_conn_lock``.
    """
    key = str(db_path)
    with _conn_lock:
        if key in _conn_cache:
            _conn_cache.move_to_end(key)
            return _conn_cache[key]

        if not db_path.exists():
            return None

        conn = sqlite3.connect(str(db_path), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        _conn_cache[key] = conn
        _conn_cache.move_to_end(key)
        while len(_conn_cache) > _CONN_CACHE_MAX:
            _, old_conn = _conn_cache.popitem(last=False)
            try:
                old_conn.close()
            except Exception:
                pass
        return conn


def _row_to_entry(row: sqlite3.Row) -> Dict:
    """Convert a SQLite row into the dict shape expected by the search logic."""
    entry = dict(row)
    for col in ("scope_chain", "aliased_as", "related_symbols", "metadata", "all_locations"):
        raw = entry.get(col)
        if raw:
            try:
                entry[col] = json.loads(raw)
            except Exception:
                entry[col] = [] if col != "metadata" else {}
        else:
            entry[col] = [] if col != "metadata" else {}
    return entry


def _lookup_variable(db_path: Path, name: str) -> List[Dict]:
    """Return all variable entries for *name* from the SQLite universe DB."""
    conn = _get_universe_conn(db_path)
    if conn is None:
        return []
    try:
        rows = conn.execute(
            "SELECT * FROM variables WHERE name = ?", (name,)
        ).fetchall()
        return [_row_to_entry(r) for r in rows]
    except Exception as exc:
        logger.warning("SQLite lookup failed for %r in %s: %s", name, db_path, exc)
        return []


def _lookup_variable_case_insensitive(db_path: Path, name: str) -> List[Dict]:
    """Case-insensitive lookup — used for CPP universe where casing may differ."""
    conn = _get_universe_conn(db_path)
    if conn is None:
        return []
    try:
        # Try indexed exact-match lookups first (avoids full-table UPPER() scan).
        for candidate in dict.fromkeys([name, name.upper(), name.lower()]):
            rows = conn.execute(
                "SELECT * FROM variables WHERE name = ?", (candidate,)
            ).fetchall()
            if rows:
                return [_row_to_entry(r) for r in rows]
        # Last resort: full case-insensitive scan.
        rows = conn.execute(
            "SELECT * FROM variables WHERE UPPER(name) = UPPER(?)", (name,)
        ).fetchall()
        return [_row_to_entry(r) for r in rows]
    except Exception as exc:
        logger.warning("SQLite CI lookup failed for %r in %s: %s", name, db_path, exc)
        return []


def _all_variable_names_from_db(db_path: Path, limit: int = 0) -> List[str]:
    """Return variable names from the SQLite universe DB.

    Args:
        limit: Maximum rows to fetch.  ``0`` (default) fetches all rows.
                Pass ``limit=5000`` for suggestion paths that only need a
                representative sample for ``difflib.get_close_matches``.
    """
    conn = _get_universe_conn(db_path)
    if conn is None:
        return []
    try:
        if limit > 0:
            rows = conn.execute(
                "SELECT name FROM variable_names LIMIT ?", (limit,)
            ).fetchall()
        else:
            rows = conn.execute("SELECT name FROM variable_names").fetchall()
        return [r[0] for r in rows]
    except Exception as exc:
        logger.warning("SQLite names query failed for %s: %s", db_path, exc)
        return []


def _stream_variable_names_from_db(db_path: Path, chunk_size: int = 5000):
    """Yield all variable names from the SQLite DB in pages.

    Avoids loading the entire table into a Python list at once, which can
    be 200K–500K rows at 22K-file scale.
    """
    conn = _get_universe_conn(db_path)
    if conn is None:
        return
    offset = 0
    while True:
        try:
            rows = conn.execute(
                "SELECT name FROM variable_names LIMIT ? OFFSET ?",
                (chunk_size, offset),
            ).fetchall()
        except Exception as exc:
            logger.warning("SQLite streaming names query failed for %s: %s", db_path, exc)
            return
        if not rows:
            break
        yield from (r[0] for r in rows)
        offset += chunk_size


# ---------------------------------------------------------------------------
# Legacy JSON data loaders  (fallback when .db not present)
# ---------------------------------------------------------------------------

def load_universe(output_dir: Path) -> Tuple[Dict, Dict]:
    """Load ASM and CPP variable universes from JSON. Results are cached per output_dir."""
    key_asm = f"{output_dir}::asm_universe"
    key_cpp = f"{output_dir}::cpp_universe"

    if key_asm not in _data_cache:
        asm_path = output_dir / "asm_variable_universe.json"
        if not asm_path.exists():
            raise FileNotFoundError(f"asm_variable_universe.json not found in {output_dir}")
        _data_cache[key_asm] = json.loads(asm_path.read_text(encoding="utf-8"))
        _data_cache.move_to_end(key_asm)
        while len(_data_cache) > _DATA_CACHE_MAX:
            _data_cache.popitem(last=False)
    else:
        _data_cache.move_to_end(key_asm)

    if key_cpp not in _data_cache:
        cpp_path = output_dir / "cpp_variable_universe.json"
        if cpp_path.exists():
            _data_cache[key_cpp] = json.loads(cpp_path.read_text(encoding="utf-8"))
        else:
            _data_cache[key_cpp] = {"variables": {}}
        _data_cache.move_to_end(key_cpp)
        while len(_data_cache) > _DATA_CACHE_MAX:
            _data_cache.popitem(last=False)
    else:
        _data_cache.move_to_end(key_cpp)

    return _data_cache[key_asm], _data_cache[key_cpp]


def load_identity_index(output_dir: Path) -> Dict:
    """Load variable_identity_index — DB-first, JSON fallback.

    Returns ``{"by_name": {name: canonical_key}, "by_identity": {}}``.
    When populated from DB, ``by_identity`` is left empty; callers that need a
    single identity entry should use ``get_identity_entry(job_id, canonical_key)``
    directly (see ``search_variable``).
    """
    key = f"{output_dir}::identity_index"
    if key not in _data_cache:
        path = output_dir / "variable_identity_index.json"
        loaded = False
        if path.exists():
            try:
                _data_cache[key] = json.loads(path.read_text(encoding="utf-8"))
                loaded = True
            except Exception:
                pass
        if not loaded:
            # JSON missing (new KB with DB-only indexes) — load from DB.
            try:
                job_id = output_dir.parent.name
                from api.index_db.readers import get_identity_by_name_bulk
                by_name = get_identity_by_name_bulk(job_id)
                # by_identity left empty; per-item lookups use get_identity_entry.
                _data_cache[key] = {"by_name": by_name, "by_identity": {}}
            except Exception:
                _data_cache[key] = {"by_name": {}, "by_identity": {}}
        _data_cache.move_to_end(key)
        while len(_data_cache) > _DATA_CACHE_MAX:
            _data_cache.popitem(last=False)
    else:
        _data_cache.move_to_end(key)
    return _data_cache[key]


# ---------------------------------------------------------------------------
# Blueprint helpers
# ---------------------------------------------------------------------------

def _resolve_blueprint_dir(output_dir: Path) -> Path:
    """Return output_dir/asm/ if it has blueprints, otherwise output_dir."""
    candidate = output_dir / "asm"
    if candidate.exists() and list(candidate.glob("*.asm.json")):
        return candidate
    return output_dir


def _get_cached_blueprint(stem: str, blueprint_dir: Path) -> Optional[Dict]:
    """LRU-load a per-file blueprint (tries .asm.json, .mac.json, .cpp.json).
    Blueprint files are msgpack-encoded; falls back to JSON for older files."""
    cache_key = f"{blueprint_dir}::{stem}"
    if cache_key in _blueprint_lru:
        _blueprint_lru.move_to_end(cache_key)
        return _blueprint_lru[cache_key]

    data = None
    for suffix in (".asm.json", ".mac.json", ".cpp.json", ".hpp.json"):
        candidate = blueprint_dir / f"{stem}{suffix}"
        if candidate.exists():
            try:
                import msgpack as _msgpack
                data = _msgpack.unpackb(candidate.read_bytes(), raw=False, strict_map_key=False)
            except Exception:
                try:
                    data = json.loads(candidate.read_text(encoding="utf-8"))
                except Exception:
                    logger.warning("Failed to load blueprint %s", candidate)
            break

    _blueprint_lru[cache_key] = data
    _blueprint_lru.move_to_end(cache_key)
    if len(_blueprint_lru) > _BLUEPRINT_CACHE_MAX:
        _blueprint_lru.popitem(last=False)
    return data


# ---------------------------------------------------------------------------
# Code chunk extraction
# ---------------------------------------------------------------------------

def _read_code_chunk(
    file_path: str,
    line_no: int,
    input_dir: Path,
    context_lines: int,
) -> Optional[Dict]:
    """
    Read ±context_lines lines around line_no from file_path.
    Falls back to input_dir / basename if the absolute path is not reachable.
    Returns a dict matching CodeChunk or None if the file cannot be read.
    """
    path = Path(file_path)
    if not path.exists():
        fallback = input_dir / path.name
        if fallback.exists():
            path = fallback
        else:
            return None

    try:
        raw_lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return None

    total = len(raw_lines)
    if not (1 <= line_no <= total):
        return None

    start = max(1, line_no - context_lines)
    end   = min(total, line_no + context_lines)

    return {
        "start_line":     start,
        "end_line":       end,
        "lines":          raw_lines[start - 1 : end],
        "highlight_line": line_no,
    }


# ---------------------------------------------------------------------------
# Stem extraction
# ---------------------------------------------------------------------------

def _stem_from_path(file_path: str) -> str:
    """
    'xh80.asm' → 'xh80', 'da7gl.mac' → 'da7gl', 'dx740200.cpp' → 'dx740200'.
    Strips the first extension only (pathlib .stem behaviour).
    """
    return Path(file_path).stem


# ---------------------------------------------------------------------------
# Main search
# ---------------------------------------------------------------------------

def search_variable_usages(
    variable_name: str,
    output_dir: Path,
    input_dir: Path,
    context_lines: int = 10,
) -> Dict[str, Any]:
    """
    Search for all usages of a variable across parser outputs.

    Returns a dict matching VariableUsageResult.
    """
    var_original  = variable_name.strip()
    var_upper     = var_original.upper()
    tiers_used: Set[str] = set()

    asm_db = output_dir / "asm_variable_universe.db"
    cpp_db = output_dir / "cpp_variable_universe.db"
    use_db = asm_db.exists()

    identity_index = load_identity_index(output_dir)
    by_name        = identity_index.get("by_name", {})
    by_identity    = identity_index.get("by_identity", {})

    # key: (file_path, line_no)
    # value: (context_str, scope_or_None, tier_str)
    # Priority on collision: definition > modification > reference; Tier 1 beats Tier 3
    deduped: Dict[Tuple[str, int], Tuple[str, Optional[str], str]] = {}

    def _upsert(file_path: str, line_no: int, context_str: str,
                scope: Optional[str], tier: str) -> None:
        key = (file_path, line_no)
        existing = deduped.get(key)
        if existing is None:
            deduped[key] = (context_str, scope, tier)
            return
        ex_ctx, ex_scope, ex_tier = existing
        if _CONTEXT_PRIORITY.get(context_str, 99) < _CONTEXT_PRIORITY.get(ex_ctx, 99):
            deduped[key] = (context_str, scope or ex_scope, tier)
        elif _CONTEXT_PRIORITY.get(context_str, 99) == _CONTEXT_PRIORITY.get(ex_ctx, 99):
            if tier == "universe" and ex_tier != "universe":
                deduped[key] = (context_str, scope or ex_scope, tier)

    # ------------------------------------------------------------------
    # Tier 1 — Universe lookups (SQLite preferred, JSON fallback)
    # ------------------------------------------------------------------
    if use_db:
        # ASM: universe stores names in UPPER already
        asm_entries = _lookup_variable(asm_db, var_upper)

        # CPP: try exact upper, then original case, then case-insensitive scan
        cpp_entries = _lookup_variable(cpp_db, var_upper)
        if not cpp_entries and var_original != var_upper:
            cpp_entries = _lookup_variable(cpp_db, var_original)
        if not cpp_entries:
            cpp_entries = _lookup_variable_case_insensitive(cpp_db, var_upper)
    else:
        # Fallback: full JSON load (legacy path)
        asm_universe, cpp_universe = load_universe(output_dir)
        asm_vars = asm_universe.get("variables", {})
        cpp_vars = cpp_universe.get("variables", {})

        asm_entries = asm_vars.get(var_upper, [])

        cpp_entries = []
        if var_upper in cpp_vars:
            cpp_entries = cpp_vars[var_upper]
        elif var_original in cpp_vars:
            cpp_entries = cpp_vars[var_original]
        else:
            lower_target = var_upper.lower()
            for cpp_key, entries in cpp_vars.items():
                if cpp_key.lower() == lower_target:
                    cpp_entries = entries
                    break

    for entry in asm_entries:
        scope = entry.get("scope")
        for loc in entry.get("all_locations", []):
            fp   = loc.get("file") or entry.get("file", "")
            line = loc.get("line", 0)
            ctx  = loc.get("context", "reference")
            if fp and line:
                _upsert(fp, line, ctx, scope, "universe")
    if asm_entries:
        tiers_used.add("universe")

    for entry in cpp_entries:
        scope = entry.get("scope")
        for loc in entry.get("all_locations", []):
            fp   = loc.get("file") or entry.get("file", "")
            line = loc.get("line", 0)
            ctx  = loc.get("context", "reference")
            if fp and line:
                _upsert(fp, line, ctx, scope, "universe")
    if cpp_entries:
        tiers_used.add("universe")

    # ------------------------------------------------------------------
    # Tier 2 — Identity Index (supplementary: canonical name + identity info)
    # ------------------------------------------------------------------
    canonical_key  = by_name.get(var_upper)
    identity_entry = by_identity.get(canonical_key) if canonical_key else None
    if identity_entry is None and canonical_key and not by_identity:
        # by_identity is empty — DB path: fetch the entry directly.
        try:
            job_id = output_dir.parent.name
            from api.index_db.readers import get_identity_entry
            identity_entry = get_identity_entry(job_id, canonical_key)
        except Exception:
            pass
    identity_info: Optional[Dict] = None

    if identity_entry:
        tiers_used.add("identity_index")
        identity_info = {
            "canonical_key":     canonical_key,
            "dsect":             identity_entry.get("dsect"),
            "symbolic_identity": identity_entry.get("symbolic_identity"),
            "access_identity":   identity_entry.get("access_identity"),
            "files_in_index":    list(identity_entry.get("files", {}).keys()),
        }

    # ------------------------------------------------------------------
    # Tier 3 — Per-file blueprints (fallback for identity-indexed vars
    #          whose files are not yet covered by Tier 1)
    # ------------------------------------------------------------------
    if identity_entry:
        covered_stems = {_stem_from_path(fp) for fp, _ in deduped}
        blueprint_dir = _resolve_blueprint_dir(output_dir)

        for stem in identity_entry.get("files", {}):
            if stem in covered_stems:
                continue
            bp = _get_cached_blueprint(stem, blueprint_dir)
            if bp is None:
                continue

            vl    = bp.get("variable_lineage") or {}
            edges = vl.get("edges") or []
            for edge in edges:
                src_leaf = (edge.get("source") or "").split(":")[-1].upper()
                tgt_leaf = (edge.get("target") or "").split(":")[-1].upper()
                if src_leaf != var_upper and tgt_leaf != var_upper:
                    continue
                fp   = edge.get("file", "")
                line = edge.get("line", 0)
                rel  = edge.get("relation", "use")
                ctx  = _RELATION_TO_CONTEXT.get(rel, "reference")
                scope = edge.get("scope")
                if fp and line:
                    _upsert(fp, line, ctx, scope, "blueprint")
                    tiers_used.add("blueprint")

    # ------------------------------------------------------------------
    # Group by file and sort by line number
    # ------------------------------------------------------------------
    by_file: Dict[str, List[Tuple[int, str, Optional[str], str]]] = {}
    for (fp, line), (ctx, scope, tier) in deduped.items():
        by_file.setdefault(fp, []).append((line, ctx, scope, tier))
    for fp in by_file:
        by_file[fp].sort(key=lambda t: t[0])

    # ------------------------------------------------------------------
    # Build FileUsage list with code chunks
    # ------------------------------------------------------------------
    files: List[Dict] = []
    for fp, locs in sorted(by_file.items()):
        usage_locations: List[Dict] = []
        for line, ctx, scope, tier in locs:
            chunk = _read_code_chunk(fp, line, input_dir, context_lines)
            usage_locations.append({
                "line":        line,
                "context":     ctx,
                "scope":       scope,
                "source_tier": tier,
                "code_chunk":  chunk,
            })
        files.append({
            "file_path":       fp,
            "file_stem":       _stem_from_path(fp),
            "locations":       usage_locations,
            "total_locations": len(usage_locations),
        })

    total_files     = len(files)
    total_locations = sum(f["total_locations"] for f in files)
    found           = total_locations > 0

    # ------------------------------------------------------------------
    # Suggestions when not found
    # ------------------------------------------------------------------
    suggestions: List[str] = []
    if not found:
        if use_db:
            asm_names = _all_variable_names_from_db(asm_db, limit=5000)
            cpp_names = _all_variable_names_from_db(cpp_db, limit=5000)
            all_names = asm_names + cpp_names + list(by_name.keys())
        else:
            asm_universe, cpp_universe = load_universe(output_dir)
            all_names = (
                list(asm_universe.get("variables", {}).keys())
                + list(cpp_universe.get("variables", {}).keys())
                + list(by_name.keys())
            )
        upper_names = [n.upper() for n in all_names]
        raw_matches = difflib.get_close_matches(var_upper, upper_names, n=5, cutoff=0.6)
        seen: Set[str] = set()
        name_map = {n.upper(): n for n in reversed(all_names)}
        for m in raw_matches:
            orig = name_map.get(m, m)
            if orig not in seen:
                suggestions.append(orig)
                seen.add(orig)

    return {
        "variable_name":     var_upper,
        "input_name":        var_original,
        "found":             found,
        "total_files":       total_files,
        "total_locations":   total_locations,
        "search_tiers_used": sorted(tiers_used),
        "identity":          identity_info,
        "files":             files,
        "suggestions":       suggestions,
    }
