"""Shared helpers for the indirect-call metadata envelope.

Every edge or response node that survives transit between layers carries an
opaque ``indirection`` dict containing whatever indirect-call annotations
the producer emitted.  Consumers preserve this dict verbatim and only the
rendering layer (UI / Pi / explainability) inspects individual keys.

When a future "Phase 2" gap closure adds a new field (e.g. ``over_approximation``
or ``binding_site``), the only place that needs to change is :data:`INDIRECTION_FIELDS`
below — every walker / transform site that uses :func:`merge_indirection`
will pick it up automatically.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

# Known indirect-call annotation keys.  Add Phase 2 fields here.
INDIRECTION_FIELDS: tuple = (
    "is_indirect",
    "indirect_via",
    "is_virtual_dispatch",
    "cha_base_class",
    # Phase 2 placeholders (uncomment when producers emit them):
    # "over_approximation",
    # "binding_site",
    # "confidence",
    # "resolution_chain",
)

# Producer-side field names that map onto canonical envelope keys.
# Blueprint edges from the ASM pipeline store the register name in ``register``;
# the canonical envelope name is ``indirect_via``.  Keep this map small —
# producers should prefer canonical names where possible.
_PRODUCER_ALIASES: Dict[str, str] = {
    "register": "indirect_via",
}


def _coerce_aliased(src: Dict[str, Any]) -> Dict[str, Any]:
    """Return a view of *src* with producer-side aliases mapped to canonical names.

    Does not mutate *src*.  Aliases only fill the canonical slot if it is
    not already set on *src* — explicit canonical values win.
    """
    if not _PRODUCER_ALIASES:
        return src
    out: Dict[str, Any] = {}
    for alias, canonical in _PRODUCER_ALIASES.items():
        if alias in src and canonical not in src:
            out[canonical] = src[alias]
    if not out:
        return src
    merged = dict(src)
    merged.update(out)
    return merged


def extract_indirection(edge_or_node: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Pull the indirection envelope off a raw edge / node dict.

    Returns ``None`` for direct calls (no indirection signal present).
    Only fields with non-default-truthy values are kept, so the envelope
    stays compact on the wire.
    """
    if not edge_or_node:
        return None

    src = _coerce_aliased(edge_or_node)

    # Already-enveloped input: pass through verbatim if it looks like one.
    nested = src.get("indirection")
    if isinstance(nested, dict) and nested:
        return {k: v for k, v in nested.items() if v not in (None, "", False)}

    blob: Dict[str, Any] = {}
    for key in INDIRECTION_FIELDS:
        if key not in src:
            continue
        val = src[key]
        # Drop default/empty values to keep payload lean
        if val in (None, "", False):
            continue
        blob[key] = val

    # Only return a blob if at least one positive indirection signal is set
    if not blob:
        return None
    if not (blob.get("is_indirect") or blob.get("is_virtual_dispatch")):
        # Keys present but no actual indirection signal — treat as direct
        return None
    return blob


def merge_indirection(into: Dict[str, Any], src: Optional[Dict[str, Any]]) -> None:
    """Carry the envelope from *src* onto *into* in place.

    No-op when *src* has no indirection signal.  When called, ``into["indirection"]``
    is set to the extracted blob (a fresh dict, not a reference).
    """
    blob = extract_indirection(src)
    if blob is not None:
        into["indirection"] = dict(blob)


def envelope_from_fields(
    *,
    is_indirect: bool = False,
    indirect_via: Optional[str] = None,
    is_virtual_dispatch: bool = False,
    cha_base_class: Optional[str] = None,
    **extra: Any,
) -> Optional[Dict[str, Any]]:
    """Build an envelope blob from named fields.  Returns None for direct calls.

    Useful for producer / traversal code that already has the values as
    separate variables.  Extra kwargs land in the blob too, so Phase 2
    fields can be passed by name without changing this signature.
    """
    candidate: Dict[str, Any] = {
        "is_indirect": is_indirect,
        "indirect_via": indirect_via,
        "is_virtual_dispatch": is_virtual_dispatch,
        "cha_base_class": cha_base_class,
        **extra,
    }
    return extract_indirection(candidate)


__all__ = (
    "INDIRECTION_FIELDS",
    "extract_indirection",
    "merge_indirection",
    "envelope_from_fields",
)
