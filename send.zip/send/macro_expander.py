"""Macro expander for z/TPF assembly macros."""

import re
from typing import Dict, List, Optional, TYPE_CHECKING
from models.macro_definition import MacroDefinition
from models.macro_expansion import (
    ExpansionResult, ExpandedInstruction, ExpansionError,
    MacroProvenance, ParameterSubstitution
)
from conditional_evaluator import ConditionalEvaluator

if TYPE_CHECKING:
    from macro_library import MacroLibrary


class MacroExpander:
    """Expands macro invocations with parameter substitution.

    Handles both positional and keyword-style parameters,
    default values, and label parameters.
    """

    def __init__(self, macro_library: Optional['MacroLibrary'] = None):
        """Initialize the macro expander.

        Args:
            macro_library: Optional macro library for recursive expansion
        """
        # Pattern to parse invocation: "[LABEL]  MACRONAME args"
        # This will capture everything in groups, we'll sort out label vs name later
        self.invocation_pattern = re.compile(
            r'^(\w+)?\s*(\w+)?\s*(.*?)$'
        )

        # Pattern to parse keyword parameters: PARM=VALUE (exclude = from value)
        self.keyword_param_pattern = re.compile(r'(\w+)=([^,=]+)')

        # Conditional assembly patterns
        self.aif_pattern = re.compile(r'^\s*AIF\s+(.+)\.(\w+)', re.IGNORECASE)
        self.ago_pattern = re.compile(r'^\s*AGO\s+\.(\w+)', re.IGNORECASE)
        self.anop_pattern = re.compile(r'^\.(\w+)\s+ANOP', re.IGNORECASE)

        # Conditional evaluator
        self.evaluator = ConditionalEvaluator()

        # Macro library for recursive expansion
        self.macro_library = macro_library

        # Expansion counter for unique IDs
        self._expansion_counter = 0

        # Expansion stack for circular detection
        self._expansion_stack: List[str] = []

        # Max recursion depth
        self.max_depth = 50

    def bind_parameters(
        self,
        invocation: str,
        definition: MacroDefinition
    ) -> Dict[str, str]:
        """Bind invocation arguments to macro parameters.

        Handles:
        - Positional parameters
        - Keyword parameters (PARM=VALUE)
        - Default values
        - Label parameter

        Args:
            invocation: Macro invocation string (e.g., "LABEL  CHKRC RC=4,ERROR=BAD")
            definition: Macro definition with parameter list

        Returns:
            Dictionary mapping parameter names to values
        """
        # Parse the invocation
        # We need to identify if there's a label by checking if the macro name appears
        # The format is: [LABEL] MACRONAME [args]
        # We'll search for the macro name and everything before it is the label

        # Strip and look for the macro name
        invocation_stripped = invocation.strip()

        # Try to find the macro name in the invocation
        # The macro name should be a whole word
        macro_name_pattern = r'\b' + re.escape(definition.name) + r'\b'
        macro_match = re.search(macro_name_pattern, invocation_stripped)

        if not macro_match:
            # Can't find macro name, return defaults
            return self._get_default_bindings(definition)

        # Everything before the macro name is the label
        label_part = invocation_stripped[:macro_match.start()].strip()
        label = label_part if label_part else None

        # Everything after the macro name is the arguments
        args_str = invocation_stripped[macro_match.end():].strip()

        # Start with default bindings
        bindings = self._get_default_bindings(definition)

        # Bind label if provided
        label_param = self._get_label_parameter(definition)
        if label_param:
            bindings[label_param.name] = label if label else ""

        # Parse arguments
        if not args_str:
            return bindings  # No arguments, use defaults

        # Check if keyword or positional
        keyword_matches = list(self.keyword_param_pattern.finditer(args_str))

        if keyword_matches:
            # Keyword style: PARM=VALUE,PARM2=VALUE2
            self._bind_keyword_params(keyword_matches, bindings, definition)

            # Also handle any positional params before first keyword
            first_keyword_pos = keyword_matches[0].start()
            if first_keyword_pos > 0:
                positional_str = args_str[:first_keyword_pos].strip().rstrip(',')
                if positional_str:
                    self._bind_positional_params(positional_str, bindings, definition)
        else:
            # Pure positional style
            self._bind_positional_params(args_str, bindings, definition)

        return bindings

    def _get_default_bindings(self, definition: MacroDefinition) -> Dict[str, str]:
        """Get default parameter bindings from definition.

        Args:
            definition: Macro definition

        Returns:
            Dictionary with default values for all parameters
        """
        bindings = {}
        for param in definition.parameters:
            bindings[param.name] = param.default_value if param.default_value else ""
        return bindings

    def _get_label_parameter(self, definition: MacroDefinition):
        """Get the label parameter from definition, if any.

        Args:
            definition: Macro definition

        Returns:
            MacroParameter that is_label=True, or None
        """
        for param in definition.parameters:
            if param.is_label:
                return param
        return None

    def _bind_keyword_params(
        self,
        matches,
        bindings: Dict[str, str],
        definition: MacroDefinition
    ):
        """Bind keyword-style parameters.

        Args:
            matches: Regex matches for PARM=VALUE patterns
            bindings: Dictionary to update with bindings
            definition: Macro definition
        """
        for match in matches:
            param_name = match.group(1)
            param_value = match.group(2).strip()

            # Find matching parameter in definition (add & prefix)
            full_param_name = f"&{param_name}"

            if full_param_name in bindings:
                bindings[full_param_name] = param_value

    def _bind_positional_params(
        self,
        args_str: str,
        bindings: Dict[str, str],
        definition: MacroDefinition
    ):
        """Bind positional parameters.

        Args:
            args_str: Comma-separated positional arguments
            bindings: Dictionary to update with bindings
            definition: Macro definition
        """
        # Split by comma
        args = [arg.strip() for arg in args_str.split(',') if arg.strip()]

        # Get non-label parameters
        non_label_params = [p for p in definition.parameters if not p.is_label]

        # Bind positional arguments
        for i, arg in enumerate(args):
            if i < len(non_label_params):
                param = non_label_params[i]
                bindings[param.name] = arg

    def expand(
        self,
        invocation: str,
        definition: MacroDefinition,
        invocation_file: str = "unknown.asm",
        invocation_line: int = 0
    ) -> ExpansionResult:
        """Expand a macro invocation with full conditional assembly processing.

        Args:
            invocation: Macro invocation string
            definition: Macro definition
            invocation_file: File where macro is invoked
            invocation_line: Line number of invocation

        Returns:
            ExpansionResult with expanded instructions
        """
        self._expansion_counter += 1
        expansion_id = f"expansion_{self._expansion_counter}"

        # Bind parameters
        bindings = self.bind_parameters(invocation, definition)

        # Check for circular call at top level
        if definition.name in self._expansion_stack:
            return ExpansionResult(
                expansion_id=expansion_id,
                invocation=invocation,
                invocation_file=invocation_file,
                invocation_line=invocation_line,
                macro_name=definition.name,
                definition_file=str(definition.source_file),
                definition_line_start=definition.start_line,
                definition_line_end=definition.end_line,
                expansion_status="failed",
                parameters=bindings,
                expanded_instructions=[],
                error=ExpansionError(
                    macro_name=definition.name,
                    error_type="circular_call",
                    message=f"Circular macro call detected: {definition.name}",
                    location_file=invocation_file,
                    location_line=invocation_line
                )
            )

        # Check max depth
        if len(self._expansion_stack) >= self.max_depth:
            return ExpansionResult(
                expansion_id=expansion_id,
                invocation=invocation,
                invocation_file=invocation_file,
                invocation_line=invocation_line,
                macro_name=definition.name,
                definition_file=str(definition.source_file),
                definition_line_start=definition.start_line,
                definition_line_end=definition.end_line,
                expansion_status="failed",
                parameters=bindings,
                expanded_instructions=[],
                error=ExpansionError(
                    macro_name=definition.name,
                    error_type="max_depth",
                    message=f"Maximum macro expansion depth ({self.max_depth}) exceeded",
                    location_file=invocation_file,
                    location_line=invocation_line
                )
            )

        # Add to expansion stack
        self._expansion_stack.append(definition.name)

        # Process conditional assembly
        try:
            expanded_lines = self._process_conditional_assembly(
                definition.body,
                bindings
            )

            # Perform text substitution
            instructions = self._substitute_parameters_to_instructions(
                expanded_lines,
                bindings,
                definition,
                invocation_file,
                invocation_line
            )

            return ExpansionResult(
                expansion_id=expansion_id,
                invocation=invocation,
                invocation_file=invocation_file,
                invocation_line=invocation_line,
                macro_name=definition.name,
                definition_file=str(definition.source_file),
                definition_line_start=definition.start_line,
                definition_line_end=definition.end_line,
                expansion_status="success",
                parameters=bindings,
                expanded_instructions=instructions,
                error=None
            )
        except Exception as e:
            # Determine error type based on exception message
            error_msg = str(e)
            if "circular" in error_msg.lower():
                error_type = "circular_call"
            elif "depth" in error_msg.lower():
                error_type = "max_depth"
            else:
                error_type = "expansion_error"

            return ExpansionResult(
                expansion_id=expansion_id,
                invocation=invocation,
                invocation_file=invocation_file,
                invocation_line=invocation_line,
                macro_name=definition.name,
                definition_file=str(definition.source_file),
                definition_line_start=definition.start_line,
                definition_line_end=definition.end_line,
                expansion_status="failed",
                parameters=bindings,
                expanded_instructions=[],
                error=ExpansionError(
                    macro_name=definition.name,
                    error_type=error_type,
                    message=error_msg,
                    location_file=invocation_file,
                    location_line=invocation_line
                )
            )
        finally:
            # Remove from expansion stack
            if self._expansion_stack and self._expansion_stack[-1] == definition.name:
                self._expansion_stack.pop()

    def _process_conditional_assembly(
        self,
        body: List[str],
        bindings: Dict[str, str]
    ) -> List[str]:
        """Process conditional assembly directives in macro body.

        Args:
            body: Macro body lines
            bindings: Parameter bindings

        Returns:
            List of executed lines (conditional branches resolved)
        """
        # First pass: find all sequence symbols (.LABEL locations)
        sequence_symbols = {}
        for i, line in enumerate(body):
            anop_match = self.anop_pattern.match(line)
            if anop_match:
                label = anop_match.group(1)
                sequence_symbols[label.upper()] = i

        # Second pass: execute with conditional branching
        result = []
        i = 0
        _MAX_ITERATIONS = 100_000
        _iter_count = 0

        while i < len(body):
            _iter_count += 1
            if _iter_count > _MAX_ITERATIONS:
                raise RuntimeError(
                    f"Macro body exceeded {_MAX_ITERATIONS} iterations — "
                    "possible infinite AGO loop"
                )
            line = body[i]

            # Check for AIF (conditional branch)
            aif_match = self.aif_pattern.match(line)
            if aif_match:
                condition = aif_match.group(1)
                target = aif_match.group(2).upper()

                # Evaluate condition
                if self.evaluator.evaluate_with_params(condition, bindings):
                    # Branch to target
                    if target in sequence_symbols:
                        i = sequence_symbols[target]
                        continue
                # Condition false, continue to next line
                i += 1
                continue

            # Check for AGO (unconditional branch)
            ago_match = self.ago_pattern.match(line)
            if ago_match:
                target = ago_match.group(1).upper()
                if target in sequence_symbols:
                    i = sequence_symbols[target]
                    continue
                i += 1
                continue

            # Check for ANOP (just a label, skip it)
            if self.anop_pattern.match(line):
                i += 1
                continue

            # Regular instruction - add to result
            result.append(line)
            i += 1

        return result

    def _substitute_parameters_to_instructions(
        self,
        lines: List[str],
        bindings: Dict[str, str],
        definition: MacroDefinition,
        invocation_file: str,
        invocation_line: int
    ) -> List[ExpandedInstruction]:
        """Substitute parameter values and recursively expand nested macros.

        Args:
            lines: Instruction lines after conditional processing
            bindings: Parameter bindings
            definition: Macro definition (for provenance)
            invocation_file: Invocation file (for provenance)
            invocation_line: Invocation line (for provenance)

        Returns:
            List of ExpandedInstruction objects with substitutions
        """
        result = []

        # Pattern to find parameter references
        param_pattern = re.compile(r'&\w+')

        # Pattern to detect macro invocations (word at start of instruction)
        macro_invocation_pattern = re.compile(r'^\s*(\w+)\s*(.*)$')

        # PERF: loop invariants hoisted out of the per-line loop.
        # - label_param depends only on the definition, not the line.
        # - One alternation regex replaces the sequential per-binding
        #   .replace() scan (O(bindings × line_length) per line).  Longest
        #   name first so &PARAM1 is never clobbered by a shorter &PARAM
        #   prefix (the old sequential replace depended on dict order here).
        label_param = self._get_label_parameter(definition)
        binding_pattern = None
        if bindings:
            binding_pattern = re.compile("|".join(
                re.escape(name)
                for name in sorted(bindings, key=len, reverse=True)
            ))

        for line_idx, line in enumerate(lines):
            # Extract label if present
            label = None
            instruction_text = line

            # Check if line starts with &LABEL parameter
            if label_param and line.strip().startswith(label_param.name):
                label_value = bindings.get(label_param.name, "")
                if label_value:
                    label = label_value
                instruction_text = line.replace(label_param.name, "", 1).lstrip()

            # Perform parameter substitutions
            substitutions = []
            for match in param_pattern.finditer(line):
                param_name = match.group(0)
                if param_name in bindings:
                    substitutions.append(ParameterSubstitution(
                        param=param_name,
                        value=bindings[param_name],
                        position=f"offset_{match.start()}"
                    ))

            substituted_text = instruction_text
            if binding_pattern is not None:
                substituted_text = binding_pattern.sub(
                    lambda m: bindings[m.group(0)], substituted_text
                )

            # Check if this is a macro invocation
            if self.macro_library:
                macro_match = macro_invocation_pattern.match(substituted_text)
                if macro_match:
                    potential_macro = macro_match.group(1)

                    # Check if it's a defined macro
                    nested_definition = self.macro_library.get_macro(potential_macro)
                    if nested_definition:
                        # Recursively expand
                        nested_result = self._expand_nested(
                            substituted_text,
                            nested_definition,
                            invocation_file,
                            invocation_line,
                            definition
                        )

                        if nested_result:
                            # Add nested expanded instructions
                            result.extend(nested_result)
                            continue

            # Create provenance
            provenance = MacroProvenance(
                invocation_file=invocation_file,
                invocation_line=invocation_line,
                invocation_macro=definition.name,
                definition_file=str(definition.source_file),
                definition_line=definition.start_line + line_idx,
                nested_expansion=None
            )

            result.append(ExpandedInstruction(
                instruction=substituted_text.strip(),
                label=label,
                parameter_substitutions=substitutions,
                provenance=provenance
            ))

        return result

    def _expand_nested(
        self,
        invocation: str,
        definition: MacroDefinition,
        parent_file: str,
        parent_line: int,
        parent_definition: MacroDefinition
    ) -> Optional[List[ExpandedInstruction]]:
        """Recursively expand a nested macro invocation.

        Args:
            invocation: Nested macro invocation
            definition: Nested macro definition
            parent_file: Parent invocation file
            parent_line: Parent invocation line
            parent_definition: Parent macro definition

        Returns:
            List of ExpandedInstruction objects, or None on error

        Raises:
            ValueError: If circular call or max depth detected
        """
        # Expand nested macro (expand() handles stack management)
        nested_result = self.expand(
            invocation,
            definition,
            parent_file,
            parent_line
        )

        if nested_result.expansion_status != "success":
            # Check if it's a critical error that should propagate
            if nested_result.error and nested_result.error.error_type in ["circular_call", "max_depth"]:
                raise ValueError(nested_result.error.message)
            # Otherwise, return None and let the instruction pass through unexpanded
            return None

        # Update provenance to show nesting
        for instr in nested_result.expanded_instructions:
            if instr.provenance:
                # Wrap in parent provenance
                parent_prov = MacroProvenance(
                    invocation_file=parent_file,
                    invocation_line=parent_line,
                    invocation_macro=parent_definition.name,
                    definition_file=str(parent_definition.source_file),
                    definition_line=parent_definition.start_line,
                    nested_expansion=instr.provenance
                )
                instr.provenance = parent_prov

        return nested_result.expanded_instructions

    def _substitute_parameters(
        self,
        line: str,
        bindings: Dict[str, str]
    ) -> str:
        """Substitute parameters in a line.

        Args:
            line: Line with parameter references
            bindings: Parameter bindings

        Returns:
            Line with parameters substituted
        """
        result = line
        for param_name, param_value in bindings.items():
            result = result.replace(param_name, param_value)
        return result
