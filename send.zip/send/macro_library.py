"""Macro library registry for storing and retrieving macro definitions."""

from typing import Dict, Iterable, Optional, List
from models.macro_definition import MacroDefinition


class MacroLibrary:
    """Registry of macro definitions accessible by name.

    Provides case-insensitive lookup and override capability for
    user-defined and system macros.
    """

    def __init__(self):
        """Initialize empty macro library."""
        self._macros: Dict[str, MacroDefinition] = {}

    def add_macro(self, macro: MacroDefinition, override: bool = False) -> None:
        """Add a macro definition to the library.

        Args:
            macro: Macro definition to add
            override: If True, replace existing macro with same name

        Raises:
            ValueError: If macro already exists and override=False
        """
        key = macro.name.upper()

        if key in self._macros and not override:
            raise ValueError(
                f"Macro '{macro.name}' already exists. "
                "Use override=True to replace it."
            )

        self._macros[key] = macro

    def get_macro(self, name: str) -> Optional[MacroDefinition]:
        """Retrieve a macro definition by name (case-insensitive).

        Args:
            name: Macro name to look up

        Returns:
            MacroDefinition if found, None otherwise
        """
        return self._macros.get(name.upper())

    def has_macro(self, name: str) -> bool:
        """Check if a macro exists in the library.

        Args:
            name: Macro name to check

        Returns:
            True if macro exists, False otherwise
        """
        return name.upper() in self._macros

    @property
    def macros(self) -> Dict[str, MacroDefinition]:
        """Read-only view of the macro registry keyed by upper-cased name.

        Prefer ``get_macro()``, ``has_macro()``, or ``get_all_macros()`` for
        normal access.  This property exists so callers that need the total
        count or want to iterate can use ``lib.macros`` without relying on the
        private ``_macros`` attribute (which caused the AttributeError in
        ``mixed_orchestrator.py`` logging lines — Issue 8).
        """
        return self._macros

    @property
    def count(self) -> int:
        """Total number of macro definitions in this library."""
        return len(self._macros)

    def get_macro_count(self) -> int:
        """Get the total number of macros in the library.

        Returns:
            Count of macros
        """
        return len(self._macros)

    def get_all_macros(self) -> List[MacroDefinition]:
        """Get all macro definitions in the library.

        Returns:
            List of all MacroDefinition objects
        """
        return list(self._macros.values())


class PerFileOverrideView:
    """Lightweight per-file view of a shared MacroLibrary with inline overrides.

    Wraps an immutable base MacroLibrary and adds a small dict of per-file
    inline macros (MACRO...MEND blocks defined inside the source file itself).
    All lookups check the inline dict first, then fall through to the base.

    No copy of the base library is made — lookup delegation is O(1).
    This replaces _clone_macro_library() in the orchestrators, eliminating
    one full library clone (potentially ~500 MacroDefinition objects) per
    ASM file analyzed.

    Thread/process safety: each file analysis creates its own view instance.
    The base library is read-only after creation; inline macros are local
    to this view and never shared.
    """

    def __init__(
        self,
        base: MacroLibrary,
        inline_macros: Optional[Iterable[MacroDefinition]] = None,
    ) -> None:
        self._base = base
        self._inline: Dict[str, MacroDefinition] = {}
        for macro in (inline_macros or []):
            self._inline[macro.name.upper()] = macro

    def has_macro(self, name: str) -> bool:
        key = name.upper()
        return key in self._inline or self._base.has_macro(name)

    def get_macro(self, name: str) -> Optional[MacroDefinition]:
        key = name.upper()
        if key in self._inline:
            return self._inline[key]
        return self._base.get_macro(name)

    def add_macro(self, macro: MacroDefinition, override: bool = False) -> None:
        """Add an inline macro to this view (does not touch the base library)."""
        key = macro.name.upper()
        if key in self._inline and not override:
            raise ValueError(
                f"Macro '{macro.name}' already exists in this view. "
                "Use override=True to replace it."
            )
        self._inline[key] = macro

    def get_all_macros(self) -> List[MacroDefinition]:
        """Return all macros: inline overrides take precedence over base."""
        merged: Dict[str, MacroDefinition] = dict(self._base._macros)
        merged.update(self._inline)
        return list(merged.values())

    def get_macro_count(self) -> int:
        return len(set(self._base._macros.keys()) | set(self._inline.keys()))
