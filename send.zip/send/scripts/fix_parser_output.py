#!/usr/bin/env python3
"""Fix else-branch conditional_context polarity in blueprint files and index.db.

Merges:
  scripts/backfill_conditional_context.py  — patches gvl_edges in index.db
  fix_else_branch_conditions.py            — patches *.cpp.json blueprint files

The C++ parser previously emitted the positive if-condition for assignments
inside else-branches instead of NOT(condition).  Both the on-disk blueprint
files and the SQLite DB are affected.

Both targets are fixed in a single pass: each C++ source file is parsed once
with the fixed CFamilyAnalyzer + JSONEmitter, and the corrected
conditional_context is applied to both the blueprint file and the DB in the
same invocation.  Re-running the script is a no-op (rows/edges already at the
correct value are left unchanged).

Usage
-----
# Fix one job (both blueprint files + index.db):
python scripts/fix_parser_output.py --job-id <id>

# Fix every job under JOBS_BASE_DIR:
python scripts/fix_parser_output.py --all

# Standalone (supply paths explicitly; --db is optional):
python scripts/fix_parser_output.py \\
    --blueprint-dir /var/asm-jobs/<id>/output \\
    --source-dir    /var/asm-source/asm \\
    [--db /var/asm-jobs/<id>/index.db  --db-job-id <id>]

Common options
--------------
--dry-run           report changes; write nothing
--no-backup         skip the index.db backup copy
--file STEM         process only this file stem (e.g. dw780000)
--path-map OLD=NEW  remap a stored source-path prefix to a local one
--jobs-dir PATH     override JOBS_BASE_DIR from api.config.settings
-v / --verbose      log each changed edge (old vs new conditions)
"""
from __future__ import annotations

import argparse
import gzip
import json
import logging
import shutil
import sqlite3
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    import msgpack
except ImportError:
    msgpack = None  # gzip+msgpack blueprints require it; plain-JSON works without

# ---------------------------------------------------------------------------
# Bootstrap — put repo root on sys.path so parser imports resolve whether
# run from the repo root or the scripts/ directory.
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(message)s",
    level=logging.INFO,
    stream=sys.stdout,
)
logger = logging.getLogger("fix_parser_output")

_CXX_EXTS = (".cpp", ".cc", ".cxx", ".c++", ".cp", ".hpp", ".hh", ".hxx", ".h++")
_MISSING = object()  # sentinel: key not present in recomputed map


# ---------------------------------------------------------------------------
# Normalisation helpers
# ---------------------------------------------------------------------------

def _norm_expr(expr: Optional[str]) -> str:
    """Collapse all whitespace (including newlines) to single spaces.

    Stored expressions keep their source line breaks; normalising both sides
    makes the edge-to-edge match robust to formatting differences.
    """
    return " ".join((expr or "").split())


def _cc_json(cc) -> Optional[str]:
    """Serialise conditional_context as compact JSON, or NULL when empty."""
    if not cc:
        return None
    return json.dumps(cc, separators=(",", ":"))


# ---------------------------------------------------------------------------
# Single parse → two lookup maps
# ---------------------------------------------------------------------------

def _reparse_file(
    path: Path,
) -> Optional[Tuple[Dict[Tuple, Optional[str]], Dict[Tuple, List]]]:
    """Parse one C++ source file with the fixed CFamilyAnalyzer.

    Returns ``(db_map, bp_map)`` where:

    * ``db_map``:  ``{(line, target, relation, norm_expr) -> cc_json}``
      used to patch ``gvl_edges.conditional_context`` in index.db.
    * ``bp_map``:  ``{(scope, line) -> [conditions]}``
      used to patch ``conditional_context`` in ``.cpp.json`` blueprints.

    Returns ``None`` on import or parse failure (the file is left untouched).
    Ambiguous tuples (same key, two different conditions) are silently dropped
    so we never patch a row we cannot resolve unambiguously.
    """
    try:
        from multi_file.c_family_analyzer import CFamilyAnalyzer
        from json_emitter import JSONEmitter
    except Exception as exc:
        logger.error("C++ analyzer/emitter unavailable: %s", exc)
        return None

    try:
        text = path.read_text(errors="replace")
    except Exception as exc:
        logger.warning("    cannot read %s: %s", path, exc)
        return None

    _prev = logging.root.manager.disable
    logging.disable(logging.WARNING)
    try:
        res = CFamilyAnalyzer("cpp").analyze(path, text)
        emitted = JSONEmitter().emit(res.analysis_context)
    except Exception as exc:
        logging.disable(_prev)
        logger.warning("    parse failed for %s: %s", path, exc)
        return None
    logging.disable(_prev)

    edges = ((emitted or {}).get("variable_lineage") or {}).get("edges") or []

    db_map: Dict[Tuple, Optional[str]] = {}
    db_conflicts: set = set()
    bp_map: Dict[Tuple, List] = {}
    bp_conflicts: set = set()

    for e in edges:
        line = e.get("line")
        if line is None:
            continue

        # ── DB key: matches gvl_edges row uniquely ─────────────────────────
        db_key = (
            int(line),
            e.get("target") or "",
            e.get("relation") or "",
            _norm_expr(e.get("expression")),
        )
        ccj = _cc_json(e.get("conditional_context"))
        if db_key in db_map and db_map[db_key] != ccj:
            db_conflicts.add(db_key)
        else:
            db_map[db_key] = ccj

        # ── Blueprint key: scope + line (matches blueprint edge fields) ─────
        # JSONEmitter output is the blueprint format, so edges carry both the
        # precise (target, relation, expression) fields used for DB matching
        # and the (scope, line) pair used for blueprint matching.
        # VariableEdge.scope is set by the lineage builder as:
        #   assignment.function or "(global)"
        # so it equals the enclosing function name (never a scope qualifier).
        scope = str(e.get("scope") or "")
        bp_key = (scope, int(line))
        cc_list = list(e.get("conditional_context") or [])
        if bp_key in bp_map and bp_map[bp_key] != cc_list:
            bp_conflicts.add(bp_key)
        else:
            bp_map[bp_key] = cc_list

    for k in db_conflicts:
        db_map.pop(k, None)
    for k in bp_conflicts:
        bp_map.pop(k, None)

    if db_conflicts or bp_conflicts:
        logger.debug(
            "    %s: dropped %d ambiguous db key(s), %d bp key(s)",
            path.name, len(db_conflicts), len(bp_conflicts),
        )

    return db_map, bp_map


# ---------------------------------------------------------------------------
# Blueprint I/O  (gzip+msgpack · gzip+JSON · plain JSON)
# ---------------------------------------------------------------------------

def _detect_format(path: Path) -> str:
    raw = path.read_bytes()
    if raw[:2] == b"\x1f\x8b":
        dec = gzip.decompress(raw)
        return "gzip_msgpack" if dec[:1] not in (b"{", b"[") else "gzip_json"
    return "plain_json"


def _load_blueprint(path: Path):
    raw = path.read_bytes()
    if raw[:2] == b"\x1f\x8b":
        dec = gzip.decompress(raw)
        if dec[:1] not in (b"{", b"[") and msgpack is not None:
            return msgpack.unpackb(dec, raw=False)
        return json.loads(dec.decode("utf-8", errors="replace"))
    return json.loads(raw.decode("utf-8", errors="replace"))


def _save_blueprint(path: Path, data, fmt: str) -> None:
    if fmt == "gzip_msgpack":
        assert msgpack is not None
        with gzip.open(path, "wb") as fh:
            fh.write(msgpack.packb(data, use_bin_type=True))
    elif fmt == "gzip_json":
        with gzip.open(path, "wt", encoding="utf-8") as fh:
            json.dump(data, fh)
    else:
        path.write_text(json.dumps(data), encoding="utf-8")


# ---------------------------------------------------------------------------
# Blueprint patch
# ---------------------------------------------------------------------------

def _patch_blueprint(
    bp_path: Path,
    bp_map: Dict[Tuple, List],
    stem: str,
    dry_run: bool,
    verbose: bool,
) -> int:
    """Load, patch, and optionally write a blueprint file.

    Returns the number of edges changed (0 = already correct or file absent).
    Only edges that already carry conditions are touched — we never add new
    conditional_context entries, only correct existing ones.
    """
    try:
        fmt = _detect_format(bp_path)
        bp = _load_blueprint(bp_path)
    except Exception as exc:
        logger.error("[%s] cannot load blueprint: %s", stem, exc)
        return 0

    edges = (bp.get("variable_lineage") or {}).get("edges") or []
    if not edges:
        return 0

    changed = 0
    for edge in edges:
        rel = str(edge.get("relation") or "").lower()
        if rel not in ("assign", "define"):
            continue
        old_conds = edge.get("conditional_context")
        if not old_conds:
            continue  # nothing stored — nothing to fix

        scope = str(edge.get("scope") or "")
        line = int(edge.get("line") or 0)
        new_conds = bp_map.get((scope, line))
        if new_conds is None:
            # Retry with bare function name (strip Class:: qualifier)
            new_conds = bp_map.get((scope.split("::")[-1], line))
        if new_conds is None or new_conds == old_conds:
            continue

        if verbose:
            logger.debug(
                "  [%s] bp line %d scope=%s\n    OLD %s\n    NEW %s",
                stem, line, scope, old_conds, new_conds,
            )
        edge["conditional_context"] = list(new_conds)
        changed += 1

    if changed == 0:
        logger.debug("[%s] blueprint already correct", stem)
        return 0

    if dry_run:
        logger.info("[%s] blueprint: %d edge(s) would change (dry run)", stem, changed)
        return changed

    try:
        _save_blueprint(bp_path, bp, fmt)
        logger.info("[%s] blueprint: %d edge(s) updated", stem, changed)
        return changed
    except Exception as exc:
        logger.error("[%s] cannot write blueprint: %s", stem, exc)
        return 0  # write failed — do not report as success


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

def _plan_db_updates(
    conn: sqlite3.Connection,
    job_id: str,
    stored_f: str,
    db_map: Dict[Tuple, Optional[str]],
) -> List[Tuple[Optional[str], int]]:
    """Return (new_cc_json, row_id) pairs for DB rows whose condition changes."""
    rows = conn.execute(
        "SELECT id, line, target, relation, expression, conditional_context "
        "FROM gvl_edges WHERE job_id=? AND file=?",
        (job_id, stored_f),
    ).fetchall()
    pending = []
    for row in rows:
        key = (
            int(row["line"]) if row["line"] is not None else None,
            row["target"] or "",
            row["relation"] or "",
            _norm_expr(row["expression"]),
        )
        new_cc = db_map.get(key, _MISSING)
        if new_cc is _MISSING or new_cc == row["conditional_context"]:
            continue
        pending.append((new_cc, row["id"]))
    return pending


def _commit_db(
    conn: sqlite3.Connection,
    db_path: Path,
    pending: List[Tuple[Optional[str], int]],
    job_id: str,
    backup: bool,
    dry_run: bool,
) -> bool:
    """Write all pending DB updates in a single transaction."""
    if dry_run:
        logger.info("[%s] DRY RUN — no DB changes written (%d row(s))", job_id, len(pending))
        return True
    if not pending:
        logger.info("[%s] DB already up to date", job_id)
        return True
    if backup:
        ts = time.strftime("%Y%m%d-%H%M%S")
        bak = db_path.with_suffix(f".db.bak-fixparser-{ts}")
        shutil.copy2(db_path, bak)
        logger.info("[%s] backed up index.db → %s", job_id, bak.name)
    try:
        conn.executemany(
            "UPDATE gvl_edges SET conditional_context=? WHERE id=?",
            pending,
        )
        conn.commit()
        logger.info("[%s] DB: updated %d row(s)", job_id, len(pending))
        return True
    except Exception as exc:
        conn.rollback()
        logger.error("[%s] DB UPDATE failed, rolled back: %s", job_id, exc)
        return False


# ---------------------------------------------------------------------------
# Per-file worker  (parse once → blueprint + DB)
# ---------------------------------------------------------------------------

def _process_file(
    stem: str,
    source_path: Path,
    bp_path: Optional[Path],
    conn: Optional[sqlite3.Connection],
    job_id: Optional[str],
    stored_f: Optional[str],
    dry_run: bool,
    verbose: bool,
) -> Tuple[int, List[Tuple]]:
    """Parse once; apply blueprint patch and compute DB pending list.

    Returns ``(bp_changed_count, db_pending_list)``.
    """
    maps = _reparse_file(source_path)
    if maps is None:
        return 0, []
    db_map, bp_map = maps

    bp_changed = 0
    if bp_path and bp_path.exists():
        bp_changed = _patch_blueprint(bp_path, bp_map, stem, dry_run, verbose)

    db_pending: List[Tuple] = []
    if conn is not None and job_id and stored_f:
        db_pending = _plan_db_updates(conn, job_id, stored_f, db_map)
        if db_pending:
            logger.info(
                "[%s]   %s: %d DB row(s) to update",
                job_id, stem, len(db_pending),
            )

    return bp_changed, db_pending


# ---------------------------------------------------------------------------
# Blueprint dir auto-detection
# ---------------------------------------------------------------------------

def _find_bp_dir(out_dir: Path) -> Optional[Path]:
    """Return the sub-directory of out_dir that contains *.cpp.json files."""
    for candidate in (out_dir / "asm", out_dir):
        if candidate.is_dir() and any(candidate.glob("*.cpp.json")):
            return candidate
    return out_dir if out_dir.is_dir() else None


# ---------------------------------------------------------------------------
# Job-level orchestration
# ---------------------------------------------------------------------------

def fix_job(
    job_id: str,
    jobs_base: Path,
    dry_run: bool,
    backup: bool,
    path_map: Optional[Dict[str, str]],
    file_filter: Optional[str],
    verbose: bool,
) -> bool:
    """Fix both blueprint files and index.db for one job. Returns True on success."""
    db_path = jobs_base / job_id / "index.db"
    if not db_path.exists():
        logger.warning("[%s] index.db not found — skipping", job_id)
        return False

    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row

    try:
        stored_files = [
            r[0] for r in conn.execute(
                "SELECT DISTINCT file FROM gvl_edges "
                "WHERE job_id=? AND file IS NOT NULL",
                (job_id,),
            ).fetchall()
        ]
    except sqlite3.OperationalError as exc:
        logger.error("[%s] cannot read gvl_edges: %s", job_id, exc)
        conn.close()
        return False

    def _resolve(stored: str) -> Optional[Path]:
        p = Path(stored)
        if p.exists():
            return p
        if path_map:
            for old, new in path_map.items():
                if stored.startswith(old):
                    c = Path(new + stored[len(old):])
                    if c.exists():
                        return c
        return None

    cxx_stored = [f for f in stored_files if Path(f).suffix.lower() in _CXX_EXTS]
    if file_filter:
        cxx_stored = [f for f in cxx_stored if Path(f).stem == file_filter]

    present = [(f, _resolve(f)) for f in cxx_stored if _resolve(f) is not None]
    missing = [f for f in cxx_stored if _resolve(f) is None]

    logger.info(
        "[%s] %d C++ file(s) — %d on disk, %d missing",
        job_id, len(cxx_stored), len(present), len(missing),
    )
    for m in missing:
        logger.warning("[%s]   source missing (skipped): %s", job_id, m)

    if not present:
        logger.info("[%s] nothing to do", job_id)
        conn.close()
        return True

    out_dir = jobs_base / job_id / "output"
    bp_dir = _find_bp_dir(out_dir)
    if bp_dir:
        logger.info("[%s] blueprint dir: %s", job_id, bp_dir)
    else:
        logger.info("[%s] no blueprint dir found — DB-only patching", job_id)

    all_db_pending: List[Tuple] = []

    for stored_f, local_f in present:
        stem = Path(stored_f).stem
        bp_path = (bp_dir / f"{stem}.cpp.json") if bp_dir else None
        _, db_pending = _process_file(
            stem, local_f, bp_path, conn, job_id, stored_f, dry_run, verbose,
        )
        all_db_pending.extend(db_pending)

    logger.info("[%s] total DB rows to update: %d", job_id, len(all_db_pending))
    ok = _commit_db(conn, db_path, all_db_pending, job_id, backup, dry_run)
    conn.close()
    return ok


# ---------------------------------------------------------------------------
# Standalone mode  (explicit --blueprint-dir + --source-dir)
# ---------------------------------------------------------------------------

def fix_standalone(
    bp_dir: Path,
    src_dir: Path,
    db_path: Optional[Path],
    job_id: Optional[str],
    dry_run: bool,
    backup: bool,
    file_filter: Optional[str],
    verbose: bool,
) -> bool:
    """Fix blueprints (and optionally index.db) without a job directory structure.

    DB patching in standalone mode uses the source path as the stored file path.
    For reliable DB matching, prefer --job-id mode which reads stored paths from
    the DB directly.
    """
    blueprints = sorted(bp_dir.glob("*.cpp.json"))
    if file_filter:
        blueprints = [p for p in blueprints if p.stem.startswith(file_filter)]
    if not blueprints:
        logger.error("No matching *.cpp.json files in %s", bp_dir)
        return False

    conn: Optional[sqlite3.Connection] = None
    if db_path:
        if db_path.exists() and job_id:
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
        else:
            if not db_path.exists():
                logger.warning("--db not found: %s (DB patching skipped)", db_path)
            if not job_id:
                logger.warning("--db-job-id not supplied (DB patching skipped)")

    all_db_pending: List[Tuple] = []
    ok = True
    skipped = 0

    for bp_path in blueprints:
        stem = bp_path.name.replace(".cpp.json", "")
        src_path = src_dir / f"{stem}.cpp"
        if not src_path.exists():
            logger.warning("[%s] source not found in %s — skipping", stem, src_dir)
            skipped += 1
            continue

        stored_f = str(src_path) if (conn and job_id) else None
        bp_changed, db_pending = _process_file(
            stem, src_path, bp_path, conn, job_id, stored_f, dry_run, verbose,
        )
        all_db_pending.extend(db_pending)

    if skipped:
        logger.info("skipped %d file(s) with missing source", skipped)

    if conn and job_id:
        logger.info("total DB rows to update: %d", len(all_db_pending))
        ok = _commit_db(conn, db_path, all_db_pending, job_id, backup, dry_run) and ok
        conn.close()

    return ok


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument(
        "--job-id", metavar="ID",
        help="Fix blueprints + index.db for one job.",
    )
    mode.add_argument(
        "--all", action="store_true",
        help="Fix every job under JOBS_BASE_DIR.",
    )
    mode.add_argument(
        "--blueprint-dir", metavar="PATH",
        help="Standalone: directory containing *.cpp.json blueprint files.",
    )

    p.add_argument(
        "--source-dir", metavar="PATH",
        help="C++ source directory (required with --blueprint-dir).",
    )
    p.add_argument(
        "--db", metavar="PATH",
        help=(
            "index.db path (optional with --blueprint-dir; enables DB "
            "patching in standalone mode)."
        ),
    )
    p.add_argument(
        "--db-job-id", metavar="ID",
        help="job_id value stored in gvl_edges (used with --blueprint-dir --db).",
    )
    p.add_argument(
        "--jobs-dir", metavar="PATH",
        help="Override JOBS_BASE_DIR from api.config.settings.",
    )
    p.add_argument(
        "--path-map", metavar="OLD=NEW", action="append", default=[],
        help=(
            "Remap a stored source-path prefix to a local one.  "
            "Use when the DB was created on a different machine.  "
            "Repeat for multiple mappings."
        ),
    )
    p.add_argument(
        "--file", metavar="STEM",
        help="Process only this file stem (e.g. dw780000).",
    )
    p.add_argument(
        "--dry-run", action="store_true",
        help="Report changes; write nothing.",
    )
    p.add_argument(
        "--no-backup", action="store_true",
        help="Skip the index.db backup copy before writing.",
    )
    p.add_argument(
        "-v", "--verbose", action="store_true",
        help="Log each changed edge (old vs new conditions).",
    )
    return p.parse_args(argv)


def main(argv=None) -> int:
    args = _parse_args(argv)
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Parse --path-map OLD=NEW pairs into a dict
    path_map: Dict[str, str] = {}
    for mapping in args.path_map:
        if "=" not in mapping:
            logger.error("--path-map must be OLD=NEW, got: %r", mapping)
            return 1
        old, _, new = mapping.partition("=")
        path_map[old] = new

    # ── Standalone mode ────────────────────────────────────────────────────
    if args.blueprint_dir:
        if not args.source_dir:
            logger.error("--source-dir is required with --blueprint-dir")
            return 1
        bp_dir = Path(args.blueprint_dir)
        src_dir = Path(args.source_dir)
        if not bp_dir.is_dir():
            logger.error("--blueprint-dir not found: %s", bp_dir)
            return 1
        if not src_dir.is_dir():
            logger.error("--source-dir not found: %s", src_dir)
            return 1
        ok = fix_standalone(
            bp_dir, src_dir,
            db_path=Path(args.db) if args.db else None,
            job_id=args.db_job_id,
            dry_run=args.dry_run,
            backup=not args.no_backup,
            file_filter=args.file,
            verbose=args.verbose,
        )
        return 0 if ok else 1

    # ── Job-id / --all mode ────────────────────────────────────────────────
    if args.jobs_dir:
        jobs_base = Path(args.jobs_dir)
    else:
        try:
            from api.config import settings
            jobs_base = Path(settings.JOBS_BASE_DIR)
        except Exception as exc:
            logger.error("Cannot load api.config.settings: %s", exc)
            logger.error("Pass --jobs-dir or ensure .env is present.")
            return 1

    if not jobs_base.exists():
        logger.error("JOBS_BASE_DIR does not exist: %s", jobs_base)
        return 1

    if args.job_id:
        job_ids = [args.job_id]
    else:
        job_ids = sorted(
            d.name for d in jobs_base.iterdir()
            if d.is_dir() and (d / "index.db").exists()
        )
        if not job_ids:
            logger.warning("No job with index.db found under %s", jobs_base)
            return 0
        logger.info("Found %d job(s) with an index.db", len(job_ids))

    ok_count = fail_count = 0
    for jid in job_ids:
        if fix_job(
            jid, jobs_base,
            dry_run=args.dry_run,
            backup=not args.no_backup,
            path_map=path_map or None,
            file_filter=args.file,
            verbose=args.verbose,
        ):
            ok_count += 1
        else:
            fail_count += 1

    logger.info(
        "Done: %d/%d job(s) OK%s",
        ok_count, ok_count + fail_count,
        " (dry run)" if args.dry_run else "",
    )
    return 0 if fail_count == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
