#!/usr/bin/env python3
"""Backfill the index DB for existing pipeline job workspaces.

Reads pipeline output JSON files that already exist on disk and populates
(or re-populates) the per-job ``index.db`` SQLite database for each job.

This script must be run once after upgrading to the DB-first reader pattern
on any environment that has pre-existing job workspaces from before the
index DB was introduced.  Once it completes successfully you can set
``INDEX_DB_STRICT=true`` in ``.env`` to permanently disable the slow
JSON-fallback code paths.

Usage examples
--------------
# Backfill a single job
python scripts/backfill_index_db.py --job-id 2e3db3d9-db34-459e-bbd5-525c686307a7

# Backfill all jobs under JOBS_BASE_DIR
python scripts/backfill_index_db.py --all

# Dry run — show what would be done, make no DB changes
python scripts/backfill_index_db.py --all --dry-run

# Backfill only specific index types for one job
python scripts/backfill_index_db.py --job-id <id> --steps modifier,identity,hops,callgraph,universe,gvl
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path
from typing import List, Optional, Set

# ---------------------------------------------------------------------------
# Bootstrap — ensure the repo root is on sys.path so api.* imports work
# whether the script is run from the repo root or the scripts/ directory.
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(message)s",
    level=logging.INFO,
    stream=sys.stdout,
)
logger = logging.getLogger("backfill_index_db")


# ---------------------------------------------------------------------------
# Step constants
# ---------------------------------------------------------------------------

ALL_STEPS: List[str] = ["universe", "gvl", "callgraph", "modifier", "identity", "hops"]


# ---------------------------------------------------------------------------
# Per-job backfill
# ---------------------------------------------------------------------------

def _find_gvl_path(output_dir: Path) -> Optional[Path]:
    """Locate global_variable_lineage.json under output_dir.

    The file may live directly in output_dir or inside a blueprint
    sub-directory (e.g. output_dir/<stem>/global_variable_lineage.json).
    """
    direct = output_dir / "global_variable_lineage.json"
    if direct.exists():
        return direct

    # Search one level of sub-directories (blueprint folders)
    for sub in sorted(output_dir.iterdir()):
        if sub.is_dir():
            candidate = sub / "global_variable_lineage.json"
            if candidate.exists():
                return candidate
            # Also check one level up from blueprint dir
            candidate2 = sub.parent / "global_variable_lineage.json"
            if candidate2.exists():
                return candidate2

    return None


def backfill_job(
    job_id: str,
    jobs_base: Path,
    steps: Set[str],
    batch_size: int,
    dry_run: bool,
) -> bool:
    """Backfill index DB for a single job.  Returns True if all requested
    steps succeeded (or were skipped because the source file was absent).
    """
    output_dir = jobs_base / job_id / "output"
    if not output_dir.exists():
        logger.warning("[%s] output directory not found: %s — skipping", job_id, output_dir)
        return False

    logger.info("[%s] starting backfill (dry_run=%s, steps=%s)", job_id, dry_run, sorted(steps))

    if dry_run:
        _dry_run_report(job_id, output_dir, steps)
        return True

    from api.index_db.writers import (
        ingest_universe,
        ingest_gvl,
        ingest_call_graph,
        ingest_modifier_index,
        ingest_identity_index,
        ingest_hop_index,
    )

    all_ok = True

    # ── universe (asm + cpp) ───────────────────────────────────────────────
    if "universe" in steps:
        for lang in ("asm", "cpp"):
            universe_path = output_dir / f"{lang}_variable_universe.json"
            names_path = output_dir / f"{lang}_variable_names.json"
            if universe_path.exists() or names_path.exists():
                logger.info("[%s] ingesting %s universe …", job_id, lang)
                ok = ingest_universe(job_id, lang, universe_path, names_path, batch_size=batch_size)
                if ok:
                    logger.info("[%s] %s universe OK", job_id, lang)
                else:
                    logger.warning("[%s] %s universe FAILED", job_id, lang)
                    all_ok = False
            else:
                logger.debug("[%s] %s universe files not found — skipped", job_id, lang)

    # ── GVL ───────────────────────────────────────────────────────────────
    if "gvl" in steps:
        gvl_path = _find_gvl_path(output_dir)
        if gvl_path:
            sz_mb = gvl_path.stat().st_size // (1024 ** 2)
            logger.info("[%s] ingesting GVL (%d MB) from %s …", job_id, sz_mb, gvl_path)
            ok = ingest_gvl(job_id, gvl_path, batch_size=batch_size)
            if ok:
                logger.info("[%s] GVL OK", job_id)
            else:
                logger.warning("[%s] GVL FAILED", job_id)
                all_ok = False
        else:
            logger.debug("[%s] global_variable_lineage.json not found — skipped", job_id)

    # ── call graph ────────────────────────────────────────────────────────
    if "callgraph" in steps:
        graph_path = output_dir / "file_call_graph.json"
        if graph_path.exists():
            logger.info("[%s] ingesting call graph …", job_id)
            ok = ingest_call_graph(job_id, graph_path, batch_size=batch_size)
            if ok:
                logger.info("[%s] call graph OK", job_id)
            else:
                logger.warning("[%s] call graph FAILED", job_id)
                all_ok = False
        else:
            logger.debug("[%s] file_call_graph.json not found — skipped", job_id)

    # ── modifier index ────────────────────────────────────────────────────
    if "modifier" in steps:
        idx_path = output_dir / "variable_modifier_index.json"
        if idx_path.exists():
            logger.info("[%s] ingesting modifier index …", job_id)
            ok = ingest_modifier_index(job_id, idx_path, batch_size=batch_size)
            if ok:
                logger.info("[%s] modifier index OK", job_id)
            else:
                logger.warning("[%s] modifier index FAILED", job_id)
                all_ok = False
        else:
            logger.debug("[%s] variable_modifier_index.json not found — skipped", job_id)

    # ── identity index ────────────────────────────────────────────────────
    if "identity" in steps:
        idx_path = output_dir / "variable_identity_index.json"
        if idx_path.exists():
            logger.info("[%s] ingesting identity index …", job_id)
            ok = ingest_identity_index(job_id, idx_path, batch_size=batch_size)
            if ok:
                logger.info("[%s] identity index OK", job_id)
            else:
                logger.warning("[%s] identity index FAILED", job_id)
                all_ok = False
        else:
            logger.debug("[%s] variable_identity_index.json not found — skipped", job_id)

    # ── hop index ─────────────────────────────────────────────────────────
    if "hops" in steps:
        idx_path = output_dir / "variable_hop_index.json"
        if idx_path.exists():
            sz_mb = idx_path.stat().st_size // (1024 ** 2)
            logger.info("[%s] ingesting hop index (%d MB) …", job_id, sz_mb)
            ok = ingest_hop_index(job_id, idx_path, batch_size=batch_size)
            if ok:
                logger.info("[%s] hop index OK", job_id)
            else:
                logger.warning("[%s] hop index FAILED", job_id)
                all_ok = False
        else:
            logger.debug("[%s] variable_hop_index.json not found — skipped", job_id)

    status = "DONE" if all_ok else "DONE WITH ERRORS"
    logger.info("[%s] backfill %s", job_id, status)
    return all_ok


def _dry_run_report(job_id: str, output_dir: Path, steps: Set[str]) -> None:
    """Print what files would be ingested without touching the DB."""
    checks = {
        "universe": [
            output_dir / "asm_variable_universe.json",
            output_dir / "asm_variable_names.json",
            output_dir / "cpp_variable_universe.json",
            output_dir / "cpp_variable_names.json",
        ],
        "gvl": [_find_gvl_path(output_dir) or output_dir / "global_variable_lineage.json"],
        "callgraph": [output_dir / "file_call_graph.json"],
        "modifier": [output_dir / "variable_modifier_index.json"],
        "identity": [output_dir / "variable_identity_index.json"],
        "hops": [output_dir / "variable_hop_index.json"],
    }
    for step, paths in checks.items():
        if step not in steps:
            continue
        for p in paths:
            if p and p.exists():
                sz = p.stat().st_size
                print(f"  [DRY-RUN] [{job_id}] would ingest {step}: {p} ({sz:,} bytes)")
            else:
                print(f"  [DRY-RUN] [{job_id}] {step}: {p} — NOT FOUND (skip)")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def _parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Backfill the index DB for existing pipeline workspaces.",
    )
    target = p.add_mutually_exclusive_group(required=True)
    target.add_argument(
        "--job-id",
        metavar="JOB_ID",
        help="Backfill a single job by its ID.",
    )
    target.add_argument(
        "--all",
        action="store_true",
        help="Backfill every job found under JOBS_BASE_DIR.",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Print what would be done without writing to the DB.",
    )
    p.add_argument(
        "--steps",
        metavar="STEPS",
        default=",".join(ALL_STEPS),
        help=(
            f"Comma-separated list of ingestion steps to run "
            f"(default: all). Choices: {', '.join(ALL_STEPS)}"
        ),
    )
    p.add_argument(
        "--batch-size",
        type=int,
        default=500,
        metavar="N",
        help="Rows per DB commit (default: 500).",
    )
    p.add_argument(
        "--jobs-dir",
        metavar="PATH",
        help="Override JOBS_BASE_DIR from settings.",
    )
    p.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable DEBUG-level logging.",
    )
    return p.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = _parse_args(argv)

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Validate requested steps
    requested_steps: Set[str] = set()
    for s in args.steps.split(","):
        s = s.strip().lower()
        if s not in ALL_STEPS:
            logger.error("Unknown step %r. Valid choices: %s", s, ", ".join(ALL_STEPS))
            return 1
        requested_steps.add(s)

    # Resolve jobs base directory
    if args.jobs_dir:
        jobs_base = Path(args.jobs_dir)
    else:
        try:
            from api.config import settings
            jobs_base = Path(settings.JOBS_BASE_DIR)
        except Exception as exc:
            logger.error("Cannot load api.config.settings: %s", exc)
            logger.error("Set JOBS_BASE_DIR via --jobs-dir or ensure .env is present.")
            return 1

    if not jobs_base.exists():
        logger.error("JOBS_BASE_DIR does not exist: %s", jobs_base)
        return 1

    # Collect job IDs
    if args.job_id:
        job_ids = [args.job_id]
    else:
        # --all: every sub-directory of jobs_base is a potential job
        job_ids = sorted(
            d.name for d in jobs_base.iterdir()
            if d.is_dir() and (d / "output").exists()
        )
        if not job_ids:
            logger.warning("No job workspaces found under %s", jobs_base)
            return 0
        logger.info("Found %d job workspace(s) to backfill", len(job_ids))

    # Run
    success_count = 0
    fail_count = 0
    for job_id in job_ids:
        ok = backfill_job(
            job_id=job_id,
            jobs_base=jobs_base,
            steps=requested_steps,
            batch_size=args.batch_size,
            dry_run=args.dry_run,
        )
        if ok:
            success_count += 1
        else:
            fail_count += 1

    total = success_count + fail_count
    logger.info(
        "Backfill complete: %d/%d jobs succeeded%s",
        success_count,
        total,
        " (dry run — no DB changes made)" if args.dry_run else "",
    )
    return 0 if fail_count == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
