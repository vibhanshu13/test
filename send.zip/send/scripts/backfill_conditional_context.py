#!/usr/bin/env python3
"""Backfill corrected ``conditional_context`` into an existing job's index.db.

Why this exists
---------------
``conditional_context`` (the enclosing if/else/loop guard chain stored on every
C++ lineage edge) is produced purely by the C++ parser's tree-sitter walk — it
does NOT depend on the call-graph build or GVL stitching.  A parser bug made
assignments inside an ``else`` branch inherit the enclosing ``if`` condition
*un-negated* (a polarity flip: a setter that fires under ``NOT(cond)`` was
recorded as firing under ``cond``).  The fix lives in
``passes/c_family_parser.py``.

Regenerating blueprints (call-graph + GVL stitch + ingest) is expensive and, for
some KBs, not possible.  But the edge condition is a *per-file, parse-only*
property, and both the data (``gvl_edges.conditional_context`` in
``jobs/<id>/index.db``) and the C++ source files are still on disk.  So this
script re-parses just the C++ source with the FIXED parser and patches the
``conditional_context`` column in place — no blueprint regen, fixing every
variable/edge in the KB at once.

Matching is edge-to-edge by ``(line, target, relation, normalised expression)``:
only the condition logic changed in the parser, so every other edge field
reproduces identically and each stored row maps 1:1 to its re-parsed
counterpart.  Rows whose recomputed condition is unchanged are skipped, so the
script is idempotent (re-running it is a no-op).

Usage
-----
# Dry run on one KB — report what would change, touch nothing
python scripts/backfill_conditional_context.py --job-id c68d392b-... --dry-run

# Apply to one KB (backs up index.db first)
python scripts/backfill_conditional_context.py --job-id c68d392b-...

# Apply to every KB under JOBS_BASE_DIR
python scripts/backfill_conditional_context.py --all

# Apply without taking a backup copy
python scripts/backfill_conditional_context.py --job-id <id> --no-backup
"""

from __future__ import annotations

import argparse
import json
import logging
import shutil
import sqlite3
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Bootstrap — put repo root on sys.path so the parser imports resolve whether
# run from the repo root or the scripts/ directory.
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(message)s",
    level=logging.INFO,
    stream=sys.stdout,
)
logger = logging.getLogger("backfill_conditional_context")

# C++ source extensions we re-parse (the parser bug is C++-only).
_CXX_EXTS = (".cpp", ".cc", ".cxx", ".c++", ".cp", ".hpp", ".hh", ".hxx", ".h++")

# Sentinel so we can distinguish "no recomputed value for this key" from
# "recomputed value is None".
_MISSING = object()


def _norm_expr(expr: Optional[str]) -> str:
    """Collapse all whitespace runs to single spaces (newlines included).

    Stored expressions keep their source line breaks (``x =\\n   Foo::bar``);
    normalising both sides makes the edge-to-edge match robust to formatting
    without affecting the row we actually UPDATE (we update by primary key).
    """
    return " ".join((expr or "").split())


def _cc_json(cc) -> Optional[str]:
    """Serialise a conditional_context list exactly as the index-db writer does
    (``api/index_db/writers.py``): compact JSON, or NULL when empty/false."""
    if not cc:
        return None
    return json.dumps(cc, separators=(",", ":"))


def _reparse_file(path: Path) -> Optional[Dict[Tuple, Optional[str]]]:
    """Re-parse one C++ source file with the FIXED parser and return a map
    ``(line, target, relation, norm_expr) -> conditional_context_json``.

    Returns None if the analyzer/emitter is unavailable or the parse fails.
    """
    try:
        from multi_file.c_family_analyzer import CFamilyAnalyzer
        from json_emitter import JSONEmitter
    except Exception as exc:  # pragma: no cover - repo layout guard
        logger.error("C++ analyzer/emitter unavailable: %s", exc)
        return None

    try:
        text = path.read_text(errors="replace")
    except Exception as exc:
        logger.warning("    cannot read %s: %s", path, exc)
        return None

    _prev = logging.root.manager.disable
    logging.disable(logging.WARNING)
    try:
        res = CFamilyAnalyzer("cpp").analyze(path, text)
        emitted = JSONEmitter().emit(res.analysis_context)
    except Exception as exc:
        logging.disable(_prev)
        logger.warning("    parse failed for %s: %s", path, exc)
        return None
    logging.disable(_prev)

    edges = ((emitted or {}).get("variable_lineage") or {}).get("edges") or []
    out: Dict[Tuple, Optional[str]] = {}
    conflicts = set()
    for e in edges:
        line = e.get("line")
        if line is None:
            continue
        key = (
            int(line),
            e.get("target") or "",
            e.get("relation") or "",
            _norm_expr(e.get("expression")),
        )
        ccj = _cc_json(e.get("conditional_context"))
        if key in out and out[key] != ccj:
            conflicts.add(key)  # same tuple, two different conditions — ambiguous
        else:
            out[key] = ccj
    for k in conflicts:
        out.pop(k, None)  # never patch an ambiguous tuple
    if conflicts:
        logger.debug("    %d ambiguous tuple(s) skipped in %s", len(conflicts), path.name)
    return out


def backfill_job(
    job_id: str,
    jobs_base: Path,
    dry_run: bool,
    backup: bool,
    path_map: Optional[Dict[str, str]] = None,
) -> bool:
    """Re-parse C++ sources for one job and patch index.db. Returns True on
    success (including the no-op case).

    ``path_map`` remaps stored absolute paths to local ones when the DB was
    created on a different machine.  Keys are path prefixes stored in the DB;
    values are the corresponding local prefixes.  Example::

        {"\/home\/ci\/project": "\/Users\/alice\/project"}

    The script tries each mapping in order and uses the first one that makes
    the file exist.  If no mapping matches and the stored path itself does not
    exist, the file is left untouched (same behaviour as before).
    """
    db_path = jobs_base / job_id / "index.db"
    if not db_path.exists():
        logger.warning("[%s] index.db not found at %s — skipping", job_id, db_path)
        return False

    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    try:
        # Distinct C++ source files this job has edges for.
        stored_files = [
            r[0] for r in conn.execute(
                "SELECT DISTINCT file FROM gvl_edges WHERE job_id=? AND file IS NOT NULL",
                (job_id,),
            ).fetchall()
        ]
    except sqlite3.OperationalError as exc:
        logger.error("[%s] cannot read gvl_edges: %s", job_id, exc)
        conn.close()
        return False

    def _resolve(stored: str) -> Optional[Path]:
        """Return a Path that exists on this machine, or None."""
        p = Path(stored)
        if p.exists():
            return p
        if path_map:
            for old_prefix, new_prefix in path_map.items():
                if stored.startswith(old_prefix):
                    candidate = Path(new_prefix + stored[len(old_prefix):])
                    if candidate.exists():
                        return candidate
        return None

    cxx_stored = [f for f in stored_files if Path(f).suffix.lower() in _CXX_EXTS]
    # (stored_path, local_path) pairs
    present = [(f, _resolve(f)) for f in cxx_stored if _resolve(f) is not None]
    missing = [f for f in cxx_stored if _resolve(f) is None]

    logger.info(
        "[%s] %d C++ file(s) referenced; %d present on disk, %d missing",
        job_id, len(cxx_stored), len(present), len(missing),
    )
    for m in missing:
        logger.warning("[%s]   source missing (left untouched): %s", job_id, m)

    if not present:
        logger.info("[%s] nothing to do", job_id)
        conn.close()
        return True

    # Plan all updates first (so a dry run is exact and the write is one txn).
    pending: List[Tuple[Optional[str], int]] = []   # (new_cc_json, row_id)
    examined = matched = changed = 0
    per_file_changed: Dict[str, int] = {}

    for stored_f, local_f in present:
        recomputed = _reparse_file(local_f)
        if recomputed is None:
            logger.warning("[%s]   skip (parse unavailable): %s", job_id, local_f)
            continue
        # Query by the STORED path (what's in the DB), not the local one.
        rows = conn.execute(
            "SELECT id, line, target, relation, expression, conditional_context "
            "FROM gvl_edges WHERE job_id=? AND file=?",
            (job_id, stored_f),
        ).fetchall()
        fchanged = 0
        for row in rows:
            examined += 1
            key = (
                int(row["line"]) if row["line"] is not None else None,
                row["target"] or "",
                row["relation"] or "",
                _norm_expr(row["expression"]),
            )
            new_cc = recomputed.get(key, _MISSING)
            if new_cc is _MISSING:
                continue
            matched += 1
            if new_cc != row["conditional_context"]:
                pending.append((new_cc, row["id"]))
                fchanged += 1
        if fchanged:
            per_file_changed[Path(stored_f).name] = fchanged
            changed += fchanged

    logger.info(
        "[%s] examined=%d matched=%d will_change=%d across %d file(s)",
        job_id, examined, matched, changed, len(per_file_changed),
    )
    for f, n in sorted(per_file_changed.items(), key=lambda kv: -kv[1]):
        logger.info("[%s]   %5d  %s", job_id, n, Path(f).name)

    if dry_run:
        logger.info("[%s] DRY RUN — no changes written", job_id)
        conn.close()
        return True

    if not pending:
        logger.info("[%s] already up to date — no rows changed", job_id)
        conn.close()
        return True

    if backup:
        ts = time.strftime("%Y%m%d-%H%M%S")
        bak = db_path.with_suffix(f".db.bak-condctx-{ts}")
        shutil.copy2(db_path, bak)
        logger.info("[%s] backed up index.db -> %s", job_id, bak.name)

    try:
        conn.executemany(
            "UPDATE gvl_edges SET conditional_context=? WHERE id=?",
            pending,
        )
        conn.commit()
    except Exception as exc:
        conn.rollback()
        conn.close()
        logger.error("[%s] UPDATE failed, rolled back: %s", job_id, exc)
        return False

    logger.info("[%s] DONE — updated %d row(s)", job_id, len(pending))
    conn.close()

    # Invalidate stale LLM cache in users.db: any setter_analysis_structural /
    # prose rows for this job were generated from the old (buggy) conditions and
    # will now be re-generated on the next request.  Also bump the KB's
    # updated_at so the freshness check invalidates rows created before this run.
    _invalidate_setter_cache(job_id)
    return True


def _invalidate_setter_cache(job_id: str) -> None:
    """Delete stale setter-analysis cache rows and bump KB updated_at in users.db."""
    try:
        from api.config import settings
        users_db = Path(settings.JOBS_BASE_DIR).parent / "users.db"
        if not users_db.exists():
            # Try a sibling of jobs_base
            users_db = Path(__file__).resolve().parents[1] / "users.db"
        if not users_db.exists():
            logger.debug("[%s] users.db not found — skipping cache invalidation", job_id)
            return
        import sqlite3 as _sq
        uc = _sq.connect(str(users_db))
        n1 = uc.execute(
            "DELETE FROM setter_analysis_structural WHERE kb_id=?", (job_id,)
        ).rowcount
        n2 = uc.execute(
            "DELETE FROM setter_analysis_prose WHERE kb_id=?", (job_id,)
        ).rowcount
        uc.execute(
            "UPDATE knowledge_bases SET updated_at=datetime('now') WHERE id=?",
            (job_id,),
        )
        uc.commit()
        uc.close()
        logger.info(
            "[%s] cache invalidated: %d structural + %d prose rows deleted; KB updated_at bumped",
            job_id, n1, n2,
        )
    except Exception as exc:
        logger.warning("[%s] cache invalidation skipped: %s", job_id, exc)


def _parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Backfill corrected conditional_context into index.db by re-parsing C++ source.",
    )
    target = p.add_mutually_exclusive_group(required=True)
    target.add_argument("--job-id", metavar="JOB_ID", help="Patch a single job by ID.")
    target.add_argument("--all", action="store_true", help="Patch every job under JOBS_BASE_DIR.")
    p.add_argument("--dry-run", action="store_true", help="Report changes; write nothing.")
    p.add_argument("--no-backup", action="store_true", help="Do not copy index.db before writing.")
    p.add_argument("--jobs-dir", metavar="PATH", help="Override JOBS_BASE_DIR from settings.")
    p.add_argument(
        "--path-map",
        metavar="OLD=NEW",
        action="append",
        default=[],
        help=(
            "Remap a stored path prefix to a local one.  Use when the DB was "
            "created on a different machine.  Repeat for multiple mappings.  "
            "Example: --path-map /home/ci/project=/Users/alice/project"
        ),
    )
    p.add_argument("-v", "--verbose", action="store_true", help="DEBUG-level logging.")
    return p.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = _parse_args(argv)
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    if args.jobs_dir:
        jobs_base = Path(args.jobs_dir)
    else:
        try:
            from api.config import settings
            jobs_base = Path(settings.JOBS_BASE_DIR)
        except Exception as exc:
            logger.error("Cannot load api.config.settings: %s", exc)
            logger.error("Pass --jobs-dir or ensure .env is present.")
            return 1

    if not jobs_base.exists():
        logger.error("JOBS_BASE_DIR does not exist: %s", jobs_base)
        return 1

    if args.job_id:
        job_ids = [args.job_id]
    else:
        job_ids = sorted(
            d.name for d in jobs_base.iterdir()
            if d.is_dir() and (d / "index.db").exists()
        )
        if not job_ids:
            logger.warning("No job index.db found under %s", jobs_base)
            return 0
        logger.info("Found %d job(s) with an index.db", len(job_ids))

    # Parse --path-map OLD=NEW pairs into a dict.
    path_map: Dict[str, str] = {}
    for mapping in args.path_map:
        if "=" not in mapping:
            logger.error("--path-map must be OLD=NEW, got: %r", mapping)
            return 1
        old, _, new = mapping.partition("=")
        path_map[old] = new
    if path_map:
        logger.info("Path remappings: %s", path_map)

    ok_count = fail_count = 0
    for job_id in job_ids:
        if backfill_job(job_id, jobs_base, args.dry_run,
                        backup=not args.no_backup, path_map=path_map or None):
            ok_count += 1
        else:
            fail_count += 1

    logger.info(
        "Backfill complete: %d/%d job(s) OK%s",
        ok_count, ok_count + fail_count,
        " (dry run — no DB changes)" if args.dry_run else "",
    )
    return 0 if fail_count == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
