#!/usr/bin/env python3
"""Generate a shareable lineage-explanation HTML for a variable + file chain.

This is the "give a variable name and a file chain, get the HTML" entry point.
It drives the SAME engine the /explain-lineage/run API uses (ChunkedBackwardSession
+ lineage_explainer), but in-process — no Celery worker, no HTTP, no auth needed —
then renders the self-contained HTML via build_lineage_html.

Usage:
  python scripts/generate_lineage_html.py --kb <KB_ID> --var LG1OSI \
      --chain lu82,da76,da78 --out LG1OSI_explanation.html [--counterpart]

If --chain is omitted, the best chain found by the variable-chain finder is used.
If --counterpart is set, the cross-language counterpart variable is resolved and a
second HTML is generated next to the first (…_counterpart.html).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

PROJ = Path(__file__).resolve().parents[1]
if str(PROJ) not in sys.path:
    sys.path.insert(0, str(PROJ))

from api.config import settings  # noqa: E402

sys.path.insert(0, str(PROJ / "scripts"))
from build_lineage_html import build_html  # noqa: E402


MAX_STEPS = 60  # hard safety cap on tuples explained per variable


# ---------------------------------------------------------------------------
# Path resolution (mirrors api.routes.knowledge_base helpers, no DB needed)
# ---------------------------------------------------------------------------
def resolve_paths(kb_id: str) -> Dict[str, Any]:
    out = settings.JOBS_BASE_DIR / kb_id / "output"
    if not out.exists():
        raise SystemExit(f"KB output dir not found: {out}")
    bp = None
    for cand in (out / "asm", out):
        if cand.exists() and (next(cand.glob("*.asm.json"), None) or next(cand.glob("*.cpp.json"), None)):
            bp = cand
            break
    if bp is None:
        raise SystemExit(f"No blueprint files under {out}")
    graph = out / "file_call_graph.json"
    if not graph.exists():
        raise SystemExit("file_call_graph.json missing for this KB")
    return {"out": out, "blueprint_dir": bp, "graph_file": graph}


def best_chain_for(kb_id: str, variable: str, paths: Dict[str, Any]) -> Optional[List[str]]:
    from find_variable_modifiers import scan_blueprint_for_setters, find_chains_through
    bp = paths["blueprint_dir"]
    graph_payload = json.loads(paths["graph_file"].read_text())
    v = variable.upper()
    mods: List[str] = []
    for b in list(bp.glob("*.asm.json")) + list(bp.glob("*.mac.json")):
        try:
            hits, _ = scan_blueprint_for_setters(b, v)
        except Exception:
            hits = []
        if hits:
            stem = hits[0].get("file_stem") or b.name.split(".")[0]
            if stem not in mods:
                mods.append(stem)
    if not mods:
        return None
    best: Optional[List[str]] = None
    for stem in mods:
        try:
            chains = find_chains_through(graph_payload, stem, max_depth=8, upstream_only=True)
        except Exception:
            chains = []
        for ch in chains:
            files = ch.get("files") or []
            if len(files) >= 2 and (best is None or len(files) > len(best)):
                best = files
    return best or [mods[0]]


# ---------------------------------------------------------------------------
# Run the full explanation for one variable + chain, return the HTML payload
# ---------------------------------------------------------------------------
def run_variable(kb_id: str, variable: str, chain: List[str], paths: Dict[str, Any],
                 asm_dir: Optional[Path]) -> Dict[str, Any]:
    from backward_traversal.runner.chunked_session import (
        ChunkedBackwardSession, compute_session_id, get_session_dir,
    )
    from llm.lineage_explainer import (
        create_explain_session, explain_step, generate_synthesis,
        load_explain_session, build_variable_table,
    )
    from llm.lineage_reasoning import build_step_reasoning, _build_variable_graph_delta

    graph_file = paths["graph_file"]
    blueprint_dir = paths["blueprint_dir"]
    graph_mtime = graph_file.stat().st_mtime
    session_id = compute_session_id(
        kb_id=kb_id, variable=variable, chain_files=chain, options={},
        graph_file_mtime=graph_mtime,
    )
    session_dir = get_session_dir(kb_id, session_id)
    session_dir.mkdir(parents=True, exist_ok=True)

    back = ChunkedBackwardSession.load(kb_id, session_id)
    if back is None:
        back = ChunkedBackwardSession.new(
            session_id=session_id, kb_id=kb_id, variable=variable,
            selected_chain=chain, options={}, blueprint_dir=blueprint_dir,
            asm_dir=asm_dir, graph_file=graph_file,
        )

    exp_session = load_explain_session(kb_id, session_id) or create_explain_session(
        kb_id, session_id, variable, chain
    )

    steps: List[Dict[str, Any]] = []
    step_idx = 0
    while step_idx < MAX_STEPS:
        if not back.is_complete:
            back.process_until_tuple(step_idx, session_dir)
            back.save(kb_id, session_id)
            back = ChunkedBackwardSession.load(kb_id, session_id)
        total = len(back.tuple_index_map)
        if step_idx >= total:
            break
        tuple_data = back.assemble_tuple(step_idx, session_dir)
        if tuple_data is None:
            break

        cached = (exp_session.get("step_explanations") or {}).get(str(step_idx))
        if cached is None:
            print(f"  [{variable}] explaining step {step_idx+1}/{total} "
                  f"({tuple_data.get('file_stem')} / {tuple_data.get('phase')})", flush=True)
            explanation = explain_step(
                kb_id=kb_id, backward_session_id=session_id, session=exp_session,
                tuple_data=tuple_data, step_index=step_idx, total_steps=total,
                selected_chain=chain,
            )
            cached = explanation.model_dump()
            exp_session = load_explain_session(kb_id, session_id) or exp_session
        else:
            print(f"  [{variable}] step {step_idx+1}/{total} cached", flush=True)

        prior_facts = [(exp_session.get("step_facts") or {}).get(str(i), "") for i in range(step_idx)]
        reasoning = build_step_reasoning(tuple_data, variable, [f for f in prior_facts if f], step_idx)
        steps.append({
            "explanation": cached,
            "phase":       tuple_data.get("phase", ""),
            "phase_badge": reasoning.get("phase_badge", ""),
            "file_stem":   tuple_data.get("file_stem", ""),
            "file_type":   tuple_data.get("file_type", "asm"),
            "variable":    tuple_data.get("variable", variable),
        })

        step_idx += 1
        if step_idx >= total and back.is_complete:
            break

    # synthesis + table + final variable graph
    exp_session = load_explain_session(kb_id, session_id) or exp_session
    # Force a fresh synthesis: a cached one may predate the chain_stages /
    # chain_narrative fields. Step explanations are kept (schema unchanged).
    exp_session["synthesis"] = None
    print(f"  [{variable}] generating synthesis…", flush=True)
    synthesis = generate_synthesis(kb_id, session_id, exp_session).model_dump()
    exp_session = load_explain_session(kb_id, session_id) or exp_session
    variable_table = build_variable_table(exp_session)

    reasonings_map = exp_session.get("step_reasonings") or {}
    n = max((int(k) for k in reasonings_map), default=-1) + 1
    all_reasonings = [reasonings_map.get(str(i), {}) for i in range(n)]
    graph = _build_variable_graph_delta(all_reasonings, n - 1, variable) if n else {"nodes": [], "edges": [], "root_var": variable.upper()}

    return {
        "root_variable":  variable.upper(),
        "selected_chain": chain,
        "steps":          steps,
        "synthesis":      synthesis,
        "variable_table": variable_table,
        "graph":          graph,
    }


def resolve_counterpart_target(kb_id: str, variable: str, chain: List[str], paths: Dict[str, Any]):
    """Return (counterpart_variable, counterpart_chain) or None."""
    from backward_traversal.utils.counterpart_resolver import resolve_counterpart
    from backward_traversal.utils.blueprint_utils import resolve_file_type
    from find_variable_modifiers import find_chains_through

    graph_file = paths["graph_file"]
    bp = paths["blueprint_dir"]
    graph_payload = json.loads(graph_file.read_text())
    ftype_map = {str(nd.get("id") or ""): str(nd.get("type") or "asm") for nd in graph_payload.get("nodes", [])}
    home = chain[-1]
    lang = resolve_file_type(home, bp, ftype_map)
    if lang == "unknown":
        lang = "asm"
    try:
        cands = resolve_counterpart(variable, lang, bp, graph_file, home)
    except Exception as e:
        print(f"  counterpart resolve error: {e}", flush=True)
        return None
    if not cands:
        return None
    c = cands[0]
    print(f"  counterpart: {c.counterpart_name} ({c.counterpart_language}) home={c.home_stem} "
          f"certainty={c.certainty_label}", flush=True)
    # build a chain ending at the counterpart home file
    cp_chain: List[str] = [c.home_stem]
    try:
        chains = find_chains_through(graph_payload, c.home_stem, max_depth=8, upstream_only=True)
        chains = [ch.get("files") for ch in chains if len(ch.get("files") or []) >= 2]
        if chains:
            cp_chain = max(chains, key=len)
    except Exception:
        pass
    return (c.counterpart_name, cp_chain)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--kb", required=True)
    ap.add_argument("--var", required=True)
    ap.add_argument("--chain", default="", help="comma-separated file stems; omit to auto-pick")
    ap.add_argument("--out", required=True)
    ap.add_argument("--counterpart", action="store_true")
    args = ap.parse_args()

    paths = resolve_paths(args.kb)
    asm_dir = PROJ / "temp" / "asm"
    asm_dir = asm_dir if asm_dir.exists() else None

    chain = [c.strip() for c in args.chain.split(",") if c.strip()] if args.chain else None
    if not chain:
        chain = best_chain_for(args.kb, args.var, paths)
        if not chain:
            raise SystemExit(f"No setter / chain found for {args.var} in KB {args.kb}")
        print(f"Auto-selected chain for {args.var}: {' -> '.join(chain)}", flush=True)

    print(f"=== Generating lineage HTML for {args.var} on {' -> '.join(chain)} ===", flush=True)
    payload = run_variable(args.kb, args.var, chain, paths, asm_dir)
    Path(args.out).write_text(build_html(payload), encoding="utf-8")
    payload_json = Path(args.out).with_suffix(".payload.json")
    payload_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"Wrote {args.out}  ({len(payload['steps'])} steps)", flush=True)

    if args.counterpart:
        tgt = resolve_counterpart_target(args.kb, args.var, chain, paths)
        if not tgt:
            print("No cross-language counterpart found — skipping counterpart HTML.", flush=True)
            return
        cp_var, cp_chain = tgt
        cp_out = str(Path(args.out).with_suffix("")) + "_counterpart.html"
        print(f"=== Generating counterpart HTML for {cp_var} on {' -> '.join(cp_chain)} ===", flush=True)
        try:
            cp_payload = run_variable(args.kb, cp_var, cp_chain, paths, asm_dir)
            Path(cp_out).write_text(build_html(cp_payload), encoding="utf-8")
            print(f"Wrote {cp_out}  ({len(cp_payload['steps'])} steps)", flush=True)
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"Counterpart generation failed: {e}", flush=True)


if __name__ == "__main__":
    main()
