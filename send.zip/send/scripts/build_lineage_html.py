"""Generate a single self-contained, shareable HTML page for a lineage explanation.

Reads the payload JSON (extracted from an explain session) and bakes every value
into one static .html file — no server, no JS dependencies, openable anywhere.
"""
from __future__ import annotations

import html
import json
import re
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# Statement-anchor index — lets inline code in prose link to the matching entry
# in the per-step "Source statements" list (requirement: clicking `OI LG1OSI,…`
# jumps to where that statement is shown in the source-statements section).
# ---------------------------------------------------------------------------
# compact key (no spaces, uppercase) -> anchor id
_STMT_ANCHORS: dict[str, str] = {}


def _stmt_key(text: str) -> str:
    """Normalise a statement to a match key: uppercase, strip a trailing inline
    comment, drop all whitespace.  `OI  LG1OSI, LG#C400  COMMENT` -> `OI LG1OSI,LG#C400` key."""
    t = (text or "").strip().upper()
    # take the instruction + operands: opcode then first comma-joined operand run
    m = re.match(r"^([A-Z#@$]+)\s+([^\s].*?)(?:\s{2,}.*)?$", t)
    if m:
        t = f"{m.group(1)} {m.group(2)}"
    return re.sub(r"\s+", "", t)


def register_statement_anchor(statement: str, anchor_id: str) -> None:
    key = _stmt_key(statement)
    if key and key not in _STMT_ANCHORS:
        _STMT_ANCHORS[key] = anchor_id


# ---------------------------------------------------------------------------
# Minimal Markdown → HTML (bold, inline code, paragraphs, bullet lists)
# ---------------------------------------------------------------------------
def _render_code_span(inner_raw: str) -> str:
    """Render an inline `code` span, linking it to a source statement if known."""
    inner = html.escape(inner_raw)
    anchor = _STMT_ANCHORS.get(_stmt_key(inner_raw))
    if anchor:
        return (f'<a class="stmt-link" href="#{anchor}" '
                f'title="Show this statement in the source-statements list">'
                f'<code>{inner}</code></a>')
    return f'<code>{inner}</code>'


def md_inline(text: str) -> str:
    text = html.escape(text)
    # inline code (unescape the captured group, then re-render via _render_code_span)
    text = re.sub(r"`([^`]+)`", lambda m: _render_code_span(html.unescape(m.group(1))), text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", text)
    return text


def md(text: str) -> str:
    if not text:
        return ""
    blocks = re.split(r"\n\s*\n", text.strip())
    out = []
    for b in blocks:
        b = b.strip()
        if not b:
            continue
        lines = b.split("\n")
        bullet_re = re.compile(r"^\s*[-•*]\s+")
        if all(bullet_re.match(ln) for ln in lines):
            items = "".join("<li>" + md_inline(bullet_re.sub("", ln)) + "</li>" for ln in lines)
            out.append(f"<ul>{items}</ul>")
        else:
            out.append(f"<p>{md_inline(b)}</p>")
    return "\n".join(out)


# ---------------------------------------------------------------------------
# SVG variable-dependency graph (layered, top-down)
# ---------------------------------------------------------------------------
def build_graph_svg(graph: dict) -> str:
    nodes = {n["id"]: n for n in graph.get("nodes", [])}
    edges = graph.get("edges", [])
    root = graph.get("root_var", "")

    children_of: dict[str, list[str]] = {}
    parents_of: dict[str, list[str]] = {}
    for e in edges:
        children_of.setdefault(e["source"], []).append(e["target"])
        parents_of.setdefault(e["target"], []).append(e["source"])

    # Layering: row0 = root; row1 = direct children of root;
    # row2 = children of row1 nodes that are NOT themselves direct children of root.
    row1 = [t for t in children_of.get(root, [])]
    row1_set = set(row1)
    row2: list[str] = []
    for parent in row1:
        for c in children_of.get(parent, []):
            if c not in row1_set and c != root and c not in row2:
                row2.append(c)

    NW, NH = 158, 56
    GAPX, GAPY = 26, 96
    pad = 30

    def row_width(n):
        return n * NW + (n - 1) * GAPX if n else 0

    total_w = max(row_width(len(row1)), row_width(len(row2)), NW) + pad * 2
    pos: dict[str, tuple[float, float]] = {}

    # root centered
    pos[root] = ((total_w - NW) / 2, pad)
    # row1
    start1 = (total_w - row_width(len(row1))) / 2
    y1 = pad + NH + GAPY
    for i, nid in enumerate(row1):
        pos[nid] = (start1 + i * (NW + GAPX), y1)
    # row2 (place under their parent where possible, else spread)
    y2 = y1 + NH + GAPY
    start2 = (total_w - row_width(len(row2))) / 2
    for i, nid in enumerate(row2):
        parent = next((p for p in parents_of.get(nid, []) if p in pos), None)
        if parent and len(children_of.get(parent, [])) <= 3:
            px = pos[parent][0] + (i - (len(row2) - 1) / 2) * (NW + GAPX)
            pos[nid] = (max(pad, min(px, total_w - NW - pad)), y2)
        else:
            pos[nid] = (start2 + i * (NW + GAPX), y2)

    total_h = (y2 if row2 else y1) + NH + pad

    def color(n):
        kind = n.get("kind", "")
        if n.get("is_root"):
            return ("#312e81", "#a5b4fc", "#6366f1")   # indigo
        if n.get("has_setter"):
            return ("#3b0764", "#d8b4fe", "#a855f7")   # violet
        return ("#1f2937", "#cbd5e1", "#475569")       # slate (guard/input)

    svg = [f'<svg viewBox="0 0 {total_w} {total_h}" width="100%" preserveAspectRatio="xMidYMin meet" xmlns="http://www.w3.org/2000/svg" font-family="Inter, system-ui, sans-serif">']
    # edges first
    for e in edges:
        s, t = e["source"], e["target"]
        if s not in pos or t not in pos:
            continue
        sx, sy = pos[s][0] + NW / 2, pos[s][1] + NH
        tx, ty = pos[t][0] + NW / 2, pos[t][1]
        midy = (sy + ty) / 2
        has_setter = e.get("has_setter")
        stroke = "#8b5cf6" if has_setter else "#3f3f46"
        svg.append(
            f'<path d="M {sx} {sy} C {sx} {midy}, {tx} {midy}, {tx} {ty}" '
            f'fill="none" stroke="{stroke}" stroke-width="1.5" opacity="0.7"/>'
        )
    # nodes
    for nid, (x, y) in pos.items():
        n = nodes[nid]
        fill, txt, border = color(n)
        badge = "ROOT" if n.get("is_root") else ("SETTER" if n.get("has_setter") else (n.get("badge") or "GUARD"))
        svg.append(
            f'<g transform="translate({x},{y})">'
            f'<rect width="{NW}" height="{NH}" rx="12" fill="{fill}" stroke="{border}" stroke-width="1.5"/>'
            f'<text x="12" y="24" fill="{txt}" font-size="13" font-weight="700" font-family="ui-monospace, monospace">{html.escape(nid)}</text>'
            f'<text x="12" y="42" fill="#94a3b8" font-size="9" letter-spacing="0.5">{html.escape(badge)}</text>'
            f'</g>'
        )
    svg.append("</svg>")
    return "\n".join(svg)


# ---------------------------------------------------------------------------
# HTML assembly
# ---------------------------------------------------------------------------
def build_html(p: dict) -> str:
    root = p["root_variable"]
    chain = p.get("selected_chain") or []
    syn = p.get("synthesis") or {}
    biz = syn.get("variable_business_name", "")
    chain_str = " &rarr; ".join(html.escape(c) for c in chain)

    # --- Pre-pass: assign a stable anchor id to every source statement so prose
    # references can link to them (requirement 2). Must run BEFORE any prose is
    # rendered via md()/md_inline().
    _STMT_ANCHORS.clear()
    _ac = 0
    for st in p["steps"]:
        for s in (st.get("explanation") or {}).get("statements") or []:
            _ac += 1
            anchor = f"stmt-{_ac}"
            s["_anchor"] = anchor
            register_statement_anchor(s.get("statement", ""), anchor)

    PHASE_COLORS = {
        "SETTER FILE": "#6366f1", "UPSTREAM CALLER": "#0ea5e9",
        "DOWNSTREAM CONSUMER": "#10b981", "DEPENDENT VARIABLE": "#a855f7",
    }

    # --- step cards ---
    steps_html = []
    for st in p["steps"]:
        e = st["explanation"]
        badge = st.get("phase_badge", st.get("phase", ""))
        bc = PHASE_COLORS.get(badge, "#52525b")
        is_dep = st["phase"].startswith("dep_var")
        ctx = ""
        if is_dep:
            ctx = f'Dependent variable of {html.escape(root)} &middot; found in {html.escape(st["file_stem"])}'

        # statements
        stmts = ""
        if e.get("statements"):
            rows = ""
            for s in e["statements"]:
                om = f'<div class="op">{html.escape(s.get("opcode_meaning",""))}</div>' if s.get("opcode_meaning") else ""
                anchor = s.get("_anchor", "")
                ln = s.get("line")
                ln_str = f'<span class="ln">line {ln}</span>' if ln else ""
                rows += (
                    f'<li id="{anchor}"><code class="stmt">{html.escape(s.get("statement",""))}</code>{ln_str}'
                    f'{om}<div class="means">{html.escape(s.get("means",""))}</div></li>'
                )
            stmts = f'<details><summary>Source statements ({len(e["statements"])})</summary><ul class="stmts">{rows}</ul></details>'

        # conditions
        conds = ""
        if e.get("conditions"):
            rows = ""
            for c in e["conditions"]:
                dec = f'<div class="decides">&rarr; {html.escape(c.get("decides",""))}</div>' if c.get("decides") else ""
                rows += (
                    f'<li><code class="stmt">{html.escape(c.get("check",""))}</code>'
                    f'<div class="means">{html.escape(c.get("in_plain_terms",""))}</div>{dec}</li>'
                )
            conds = f'<details><summary>Conditions to reach the setter ({len(e["conditions"])})</summary><ul class="conds">{rows}</ul></details>'

        # dep vars
        dvs = ""
        if e.get("dependent_variables"):
            rows = ""
            for dv in e["dependent_variables"]:
                bn = f' <span class="bn">{html.escape(dv.get("business_name",""))}</span>' if dv.get("business_name") else ""
                rows += f'<li><code>{html.escape(dv.get("name",""))}</code>{bn}<div class="means">{html.escape(dv.get("why_it_was_traced",""))}</div></li>'
            dvs = f'<details><summary>Dependent variables ({len(e["dependent_variables"])})</summary><ul class="dvs">{rows}</ul></details>'

        steps_html.append(f'''
        <div class="card step">
          <div class="step-head">
            <span class="badge" style="--bc:{bc}">{html.escape(badge)}</span>
            <code class="file">{html.escape(st["file_stem"])}</code>
            {'<span class="cpp">C++</span>' if st.get("file_type")=="cpp" else ''}
          </div>
          <div class="step-title"><code>{html.escape(st["variable"])}</code>{f' <span class="bn">{html.escape(e.get("variable_business_name",""))}</span>' if e.get("variable_business_name") else ''}</div>
          {f'<div class="ctx">{ctx}</div>' if ctx else ''}
          <p class="headline">{md_inline(e.get("headline",""))}</p>
          <div class="narrative">{md(e.get("narrative",""))}</div>
          <div class="details">{stmts}{conds}{dvs}</div>
        </div>''')

    # --- synthesis ---
    syn_sections = [
        ("What it is", syn.get("what_it_is","")),
        ("How it is set", syn.get("how_it_is_set","")),
        ("What had to be true", syn.get("what_had_to_be_true","")),
        ("How its dependent variables were set", syn.get("dependent_variables_story","")),
    ]
    syn_html = "".join(
        f'<div class="syn-sec"><h4>{html.escape(lbl)}</h4>{md(txt)}</div>'
        for lbl, txt in syn_sections if txt
    )
    full_story = f'<div class="full-story"><h4>The full story, end to end</h4>{md(syn.get("full_story",""))}</div>' if syn.get("full_story") else ""

    # --- rules ---
    rules_html = ""
    for grp in syn.get("setting_rule_groups", []):
        items = ""
        for i, r in enumerate(grp.get("rules", [])):
            deps = "".join(f'<code class="dep">{html.escape(d)}</code>' for d in (r.get("depends_on") or []))
            ev = f'<code class="ev">{html.escape((r.get("evidence","") or "").replace("`",""))}</code>' if r.get("evidence") else ""
            items += (
                f'<li><span class="num">{i+1}</span><div><div class="rule">{html.escape(r.get("rule",""))}</div>'
                f'<div class="rule-meta">{deps}{ev}</div></div></li>'
            )
        gname = f' <span class="bn">{html.escape(grp.get("business_name",""))}</span>' if grp.get("business_name") else ""
        rules_html += (
            f'<div class="rule-group"><h4>Rules for setting <code>{html.escape(grp.get("variable",""))}</code>{gname} '
            f'<span class="count">({len(grp.get("rules",[]))})</span></h4><ol class="rules">{items}</ol></div>'
        )

    # --- table ---
    table_rows = "".join(
        f'<tr><td><code>{html.escape(r["variable"])}</code></td>'
        f'<td>{html.escape(r.get("business_name","") or "—")}</td>'
        f'<td>{html.escape(r["role"])}</td>'
        f'<td>{html.escape(r["how_set"])}</td></tr>'
        for r in p.get("variable_table", [])
    )

    graph_svg = build_graph_svg(p["graph"])

    # --- Chain stages (requirement 1): English stage names per chain file ------
    stages = syn.get("chain_stages") or []
    chain_narr = syn.get("chain_narrative", "")
    if stages:
        pills = ""
        for i, s in enumerate(stages):
            wh = f'<div class="stage-what">{md_inline(s.get("what_happens",""))}</div>' if s.get("what_happens") else ""
            pills += (
                f'<div class="stage">'
                f'<div class="stage-no">Stage {i+1}</div>'
                f'<div class="stage-title">{html.escape(s.get("stage_title",""))}</div>'
                f'<code class="stage-file">{html.escape(s.get("file",""))}</code>'
                f'{wh}</div>'
            )
            if i < len(stages) - 1:
                pills += '<div class="stage-arrow">&rarr;</div>'
        narr_html = f'<p class="chain-narr">{md_inline(chain_narr)}</p>' if chain_narr else ""
        chain_block = f'<div class="stages">{pills}</div>{narr_html}'
    else:
        chain_block = f'<div class="sub">Call chain: {chain_str}</div>'

    return f'''<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>{html.escape(root)} — Variable Lineage Explanation</title>
<style>
:root {{ color-scheme: dark; }}
* {{ box-sizing: border-box; }}
body {{ margin:0; background:#0a0a0a; color:#e5e5e5;
  font-family: Inter, -apple-system, system-ui, sans-serif; line-height:1.6; }}
.wrap {{ max-width: 960px; margin: 0 auto; padding: 40px 24px 80px; }}
code {{ font-family: ui-monospace, "SF Mono", Menlo, monospace; font-size: 0.9em;
  background: rgba(99,102,241,0.12); color:#a5b4fc; padding: 1px 5px; border-radius: 4px; }}
strong {{ color:#fff; font-weight:600; }}
h1 {{ font-size: 28px; margin:0 0 4px; background:linear-gradient(90deg,#fff,#a5b4fc);
  -webkit-background-clip:text; background-clip:text; color:transparent; }}
h2 {{ font-size: 13px; text-transform:uppercase; letter-spacing:2px; color:#6366f1;
  margin: 48px 0 16px; font-weight:700; }}
h4 {{ font-size: 12px; text-transform:uppercase; letter-spacing:1px; color:#818cf8;
  margin: 0 0 6px; }}
.sub {{ color:#737373; font-family: ui-monospace, monospace; font-size:13px; margin-bottom:4px; }}
.hero {{ border-bottom:1px solid #262626; padding-bottom:24px; margin-bottom:8px; }}
.hero .biz {{ color:#a5b4fc; font-size:15px; }}
.card {{ background:#171717; border:1px solid #262626; border-radius:16px;
  padding:20px; margin-bottom:16px; }}
.step-head {{ display:flex; align-items:center; gap:8px; margin-bottom:8px; flex-wrap:wrap; }}
.badge {{ font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:1px;
  padding:2px 9px; border-radius:999px; color:var(--bc);
  background:color-mix(in srgb, var(--bc) 18%, transparent);
  border:1px solid color-mix(in srgb, var(--bc) 35%, transparent); }}
.file {{ font-size:12px; color:#a3a3a3; background:none; }}
.cpp {{ font-size:10px; color:#fbbf24; border:1px solid rgba(251,191,36,0.3); border-radius:4px; padding:1px 5px; }}
.step-title {{ font-size:16px; font-weight:600; color:#fff; }}
.step-title .bn {{ color:#a5b4fc; font-weight:400; margin-left:6px; }}
.ctx {{ font-size:12px; color:#737373; margin-top:2px; }}
.headline {{ font-size:15px; font-weight:600; color:#fff; margin:14px 0 10px; }}
.narrative p {{ margin: 0 0 12px; color:#d4d4d4; }}
.narrative ul {{ color:#d4d4d4; }}
.details {{ margin-top:10px; }}
details {{ border-top:1px solid #262626; padding:8px 0 0; margin-top:8px; }}
summary {{ cursor:pointer; font-size:11px; text-transform:uppercase; letter-spacing:1px;
  color:#737373; user-select:none; }}
summary:hover {{ color:#a3a3a3; }}
ul.stmts, ul.conds, ul.dvs {{ list-style:none; padding:0; margin:10px 0 0; }}
ul.stmts li, ul.conds li, ul.dvs li {{ background:#0f0f0f; border:1px solid #262626;
  border-radius:8px; padding:8px 12px; margin-bottom:6px; }}
.stmt {{ display:block; color:#e5e5e5; background:#1f2937; margin-bottom:4px; }}
.op {{ font-size:11px; color:#737373; font-style:italic; margin-bottom:2px; }}
.means {{ font-size:13px; color:#a3a3a3; }}
.decides {{ font-size:12px; color:#737373; margin-top:3px; }}
.bn {{ color:#a5b4fc; font-size:12px; }}
.conds li {{ background:rgba(139,92,246,0.06); border-color:rgba(139,92,246,0.2); }}
/* synthesis */
.summary-card {{ background:linear-gradient(135deg, rgba(49,46,129,0.4), rgba(59,7,100,0.3));
  border:1px solid rgba(99,102,241,0.4); border-radius:16px; padding:24px; }}
.syn-sec {{ margin-bottom:18px; }}
.syn-sec p {{ color:#d4d4d4; margin:0 0 10px; }}
.full-story {{ background:rgba(99,102,241,0.1); border:1px solid rgba(99,102,241,0.2);
  border-radius:12px; padding:16px; margin-top:8px; }}
.full-story p {{ color:#e5e5e5; }}
/* rules */
.rule-group {{ margin-top:22px; }}
.rule-group h4 code {{ font-size:13px; }}
.count {{ color:#525252; }}
ol.rules {{ list-style:none; padding:0; margin:10px 0 0; counter-reset:r; }}
ol.rules li {{ display:flex; gap:12px; background:#0f0f0f; border:1px solid #262626;
  border-radius:10px; padding:10px 12px; margin-bottom:8px; }}
.num {{ flex:none; width:22px; height:22px; border-radius:999px; background:rgba(99,102,241,0.25);
  color:#a5b4fc; font-size:11px; font-weight:700; display:flex; align-items:center;
  justify-content:center; margin-top:1px; }}
.rule {{ color:#e5e5e5; font-size:14px; }}
.rule-meta {{ margin-top:5px; display:flex; gap:6px; flex-wrap:wrap; align-items:center; }}
.dep {{ font-size:10px; }}
.ev {{ font-size:10px; color:#737373; background:none; }}
/* table */
table {{ width:100%; border-collapse:collapse; font-size:13px; margin-top:10px;
  border:1px solid #262626; border-radius:10px; overflow:hidden; }}
thead {{ background:#171717; }}
th {{ text-align:left; padding:10px 12px; font-size:10px; text-transform:uppercase;
  letter-spacing:1px; color:#737373; }}
td {{ padding:10px 12px; border-top:1px solid #1f1f1f; color:#a3a3a3; vertical-align:top; }}
td code {{ color:#a5b4fc; font-weight:600; }}
/* graph */
.graph {{ background:#0f0f0f; border:1px solid #262626; border-radius:16px; padding:16px;
  overflow-x:auto; }}
.legend {{ display:flex; gap:16px; flex-wrap:wrap; margin-top:12px; font-size:11px; color:#737373; }}
.legend span {{ display:inline-flex; align-items:center; gap:6px; }}
.dot {{ width:10px; height:10px; border-radius:3px; display:inline-block; }}
.foot {{ margin-top:60px; padding-top:20px; border-top:1px solid #262626;
  font-size:11px; color:#525252; text-align:center; }}
/* chain stages */
.stages {{ display:flex; flex-wrap:wrap; align-items:stretch; gap:8px; margin:14px 0 10px; }}
.stage {{ flex:1 1 150px; min-width:140px; background:#171717; border:1px solid #262626;
  border-radius:12px; padding:10px 12px; }}
.stage-no {{ font-size:9px; text-transform:uppercase; letter-spacing:1.5px; color:#6366f1; font-weight:700; }}
.stage-title {{ font-size:13px; color:#fff; font-weight:600; margin:2px 0 4px; }}
.stage-file {{ font-size:11px; }}
.stage-what {{ font-size:11px; color:#a3a3a3; margin-top:6px; line-height:1.45; }}
.stage-arrow {{ display:flex; align-items:center; color:#3f3f46; font-size:18px; }}
.chain-narr {{ color:#d4d4d4; font-size:14px; margin:6px 0 0; }}
/* statement links + jump-to highlight */
a.stmt-link {{ text-decoration:none; }}
a.stmt-link code {{ border-bottom:1px dashed rgba(165,180,252,0.5); cursor:pointer; }}
a.stmt-link:hover code {{ background:rgba(99,102,241,0.28); border-bottom-color:#a5b4fc; }}
ul.stmts li:target {{ outline:2px solid #6366f1; outline-offset:1px;
  background:rgba(99,102,241,0.16); animation:flash 1.4s ease-out; }}
.ln {{ font-size:10px; color:#52525b; margin-left:8px; }}
@keyframes flash {{ from {{ background:rgba(99,102,241,0.45); }} to {{ background:rgba(99,102,241,0.16); }} }}
</style></head>
<body><div class="wrap">

  <div class="hero">
    <div class="sub">Variable Data-Lineage Explanation</div>
    <h1>{html.escape(root)}{f' &mdash; <span class="biz">{html.escape(biz)}</span>' if biz else ''}</h1>
    <div class="sub" style="margin-top:6px">How the request flows to where this value is set:</div>
    {chain_block}
  </div>

  <h2>Variable Dependency Graph</h2>
  <div class="graph">
    {graph_svg}
    <div class="legend">
      <span><i class="dot" style="background:#6366f1"></i> Root variable</span>
      <span><i class="dot" style="background:#a855f7"></i> Dependent (own setter found)</span>
      <span><i class="dot" style="background:#475569"></i> Guard / input value</span>
    </div>
  </div>

  <h2>Step-by-Step Explanation</h2>
  {"".join(steps_html)}

  <h2>Complete Summary</h2>
  <div class="summary-card">
    {syn_html}
    {full_story}
  </div>

  <h2>Rules for Setting</h2>
  {rules_html}

  <h2>Variable Summary</h2>
  <table>
    <thead><tr><th>Variable</th><th>Business name</th><th>Role</th><th>How it gets its value</th></tr></thead>
    <tbody>{table_rows}</tbody>
  </table>

  <div class="foot">
    Generated by the ASM Lineage Explainer &middot; analysis is deterministic; narratives by Gemini 2.5 Pro.
  </div>
</div>
<script>
// When a statement link is followed, open the collapsed "Source statements"
// section that contains the target and scroll it into view.
(function () {{
  function reveal(hash) {{
    if (!hash) return;
    var el = document.getElementById(hash.slice(1));
    if (!el) return;
    var d = el.closest('details');
    if (d && !d.open) d.open = true;
    el.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
  }}
  document.addEventListener('click', function (e) {{
    var a = e.target.closest('a.stmt-link');
    if (a) {{ setTimeout(function () {{ reveal(a.getAttribute('href')); }}, 0); }}
  }});
  if (location.hash) setTimeout(function () {{ reveal(location.hash); }}, 60);
}})();
</script>
</body></html>'''


if __name__ == "__main__":
    payload_path = sys.argv[1] if len(sys.argv) > 1 else "/tmp/lg1osi_payload.json"
    out_path = sys.argv[2] if len(sys.argv) > 2 else "LG1OSI_explanation.html"
    payload = json.loads(Path(payload_path).read_text())
    Path(out_path).write_text(build_html(payload), encoding="utf-8")
    print(f"Wrote {out_path}")
