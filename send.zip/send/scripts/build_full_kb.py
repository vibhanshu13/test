#!/usr/bin/env python3
"""Build a COMPLETE knowledge base from a source folder, in-process.

Runs the same first three pipeline steps the Celery pipeline runs — universe
build, full analysis (blueprint emission), and the file call graph — but
directly, with no Celery worker and no Redis dependency. These three steps
produce everything the backward-lineage + counterpart engine needs:
  - one *.asm.json / *.mac.json / *.cpp.json blueprint per source file
  - file_call_graph.json

The later pipeline steps (modifier/identity/hop indexes, LLM file & chain
summaries) are intentionally skipped — they are not used by lineage tracing.

Usage:
  python scripts/build_full_kb.py --src temp/asm [--job <uuid>]
Prints the resulting KB/job id (also the on-disk jobs/<id>/output dir).
"""
from __future__ import annotations

import argparse
import sys
import time
import uuid
from pathlib import Path

PROJ = Path(__file__).resolve().parents[1]
if str(PROJ) not in sys.path:
    sys.path.insert(0, str(PROJ))

from api.config import settings  # noqa: E402
from api.storage.workspace import WorkspaceManager  # noqa: E402
from api.tasks.universe_task import _run_universe  # noqa: E402
from api.tasks.analysis_task import _run_analysis  # noqa: E402
from api.tasks.pipeline_task import _build_call_graph  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True, help="source folder (e.g. temp/asm)")
    ap.add_argument("--job", default="", help="job/KB id (default: random uuid)")
    args = ap.parse_args()

    src = Path(args.src).resolve()
    if not src.exists():
        raise SystemExit(f"source folder not found: {src}")

    job_id = args.job or str(uuid.uuid4())
    ws = WorkspaceManager(job_id)
    for d in (ws.input_dir, ws.output_dir, ws.cache_dir):
        d.mkdir(parents=True, exist_ok=True)

    print(f"=== Building complete KB ===", flush=True)
    print(f"  job/kb id : {job_id}", flush=True)
    print(f"  source    : {src}", flush=True)
    print(f"  output    : {ws.output_dir}", flush=True)

    src_str = str(src)

    # --- Step 1: universe build ------------------------------------------------
    t = time.monotonic()
    print("\n[1/3] Universe build…", flush=True)
    u = _run_universe(ws, {"source_path": src_str, "exclude": []}, update_status=False)
    print(f"  universe: asm_vars={u.get('asm_variables')} cpp_vars={u.get('cpp_variables')} "
          f"({time.monotonic()-t:.1f}s)", flush=True)

    # --- Step 2: full analysis (blueprint emission) ---------------------------
    t = time.monotonic()
    print("\n[2/3] Full analysis (blueprint emission)…", flush=True)
    a = _run_analysis(ws, {
        "source_path":          src_str,
        "search_paths":         [src_str],
        "macro_libs":           [],
        "no_coverage_review":   True,
        "skip_business_summary": True,
        "exclude":              [],
        "load_universe":        True,
        "universe_job_id":      job_id,
        "resume_from":          "",
    }, update_status=False)
    print(f"  analysis: files_analyzed={a.get('files_analyzed')} ({time.monotonic()-t:.1f}s)", flush=True)

    # --- Step 3: file call graph ----------------------------------------------
    t = time.monotonic()
    print("\n[3/3] File call graph…", flush=True)
    _build_call_graph(ws, src_str)
    print(f"  call graph done ({time.monotonic()-t:.1f}s)", flush=True)

    # --- verify ----------------------------------------------------------------
    out = ws.output_dir
    bp = out / "asm" if (out / "asm").exists() and next((out / "asm").glob("*.asm.json"), None) else out
    n_asm = len(list(bp.glob("*.asm.json")))
    n_mac = len(list(bp.glob("*.mac.json")))
    n_cpp = len(list(bp.glob("*.cpp.json")))
    print(f"\n=== DONE — blueprints: asm={n_asm} mac={n_mac} cpp={n_cpp} | "
          f"graph={'yes' if (out/'file_call_graph.json').exists() else 'NO'} ===", flush=True)
    print(f"KB_ID={job_id}", flush=True)


if __name__ == "__main__":
    main()
