#!/usr/bin/env python3
"""Build ``.loff`` byte-offset sidecars for source files.

The backward-lineage engine reads individual source lines via
``blueprint_utils.fetch_raw_line``.  When a ``<file>.loff`` sidecar exists next
to a source file, that function seeks to the requested line in **O(1) memory**
instead of loading the whole file — important on memory-constrained servers and
for very large generated files.

This script is:
  * **incremental** — skips files whose sidecar is already up to date (unless
    ``--force``);
  * **additive** — it only ever *creates* ``<file>.loff`` next to each source
    file; it never reads, writes, or deletes the source or any pipeline artifact;
  * **safe to re-run** — idempotent.

It does NOT require re-running the pipeline.  Point it at the source tree, e.g.
the container's ``/var/asm-jobs/{kb_id}/input/asm`` or the local
``outputs/codebase/asm``.

Sidecar layout (must stay in sync with ``blueprint_utils._loff_lookup``):
    6-byte magic ``LOFF1\\n`` then little-endian uint64 offsets, where
    ``offsets[i]`` is the byte offset at which line ``i+1`` begins.

Usage:
    python scripts/build_line_offset_index.py <source_dir> \\
        [--ext .asm .cpp .cob .c .h] [--force] [--quiet]
"""
from __future__ import annotations

import argparse
import os
import struct
import sys
from pathlib import Path

MAGIC = b"LOFF1\n"
LOFF_SUFFIX = ".loff"
DEFAULT_EXTS = [".asm", ".cpp", ".c", ".h", ".cob", ".cbl"]


def build_offsets(data: bytes) -> list:
    """Return byte offsets where each line begins, one per ``str.splitlines()`` line.

    Must match ``splitlines()`` exactly so the seek path is byte-identical to the
    original ``fetch_raw_line``:
      * an empty file has zero lines (returns ``[]``);
      * a trailing final newline does NOT create a phantom empty last line, so the
        offset just past it is not recorded.
    """
    if not data:
        return []
    offsets = [0]
    start = 0
    n = len(data)
    while True:
        nl = data.find(b"\n", start)
        if nl == -1:
            break
        nxt = nl + 1
        if nxt < n:                 # skip the phantom offset after a trailing '\n'
            offsets.append(nxt)
        start = nxt
    return offsets


def write_sidecar(src: Path, offsets: list) -> None:
    loff = Path(str(src) + LOFF_SUFFIX)
    tmp = Path(str(loff) + ".tmp")
    with open(tmp, "wb") as fh:
        fh.write(MAGIC)
        fh.write(struct.pack("<%dQ" % len(offsets), *offsets))
    os.replace(tmp, loff)  # atomic — never leaves a half-written sidecar


def is_up_to_date(src: Path) -> bool:
    loff = Path(str(src) + LOFF_SUFFIX)
    if not loff.exists():
        return False
    try:
        return loff.stat().st_mtime >= src.stat().st_mtime
    except OSError:
        return False


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Build .loff offset sidecars for source files.")
    ap.add_argument("source_dir", type=Path, help="Directory tree of source files to index.")
    ap.add_argument("--ext", nargs="+", default=DEFAULT_EXTS,
                    help="Source file extensions to index (default: %(default)s).")
    ap.add_argument("--force", action="store_true", help="Rebuild even if the sidecar is current.")
    ap.add_argument("--quiet", action="store_true", help="Only print the final summary.")
    args = ap.parse_args(argv)

    if not args.source_dir.is_dir():
        print(f"error: not a directory: {args.source_dir}", file=sys.stderr)
        return 2

    exts = {e.lower() if e.startswith(".") else "." + e.lower() for e in args.ext}
    built = skipped = failed = 0
    for src in sorted(args.source_dir.rglob("*")):
        if not src.is_file() or src.suffix.lower() not in exts:
            continue
        if src.name.endswith(LOFF_SUFFIX):
            continue
        if not args.force and is_up_to_date(src):
            skipped += 1
            continue
        try:
            data = src.read_bytes()
            write_sidecar(src, build_offsets(data))
            built += 1
            if not args.quiet:
                print(f"[loff] {src}  ({len(data)} bytes)")
        except Exception as exc:  # never abort the whole run for one bad file
            failed += 1
            print(f"[loff] FAILED {src}: {exc}", file=sys.stderr)

    print(f"\nDone. built={built} skipped(up-to-date)={skipped} failed={failed}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
