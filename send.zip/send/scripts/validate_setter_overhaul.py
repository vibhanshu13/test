#!/usr/bin/env python3
"""Corpus regression for the SETTER_INST overhaul (audit SETTER_INST_COMPLETE.md).

Runs the REAL chain-finding scanner (find_variable_modifiers.scan_blueprint_for_setters)
and the REAL backward pipeline (backward_traversal.cli / run_backward_only) against
populated corpus blueprints, asserting:

  1. Newly-covered opcodes (STMG/ASI/STCKF/STCMH/…) now produce setter sites that the
     pre-overhaul set silently missed.
  2. Removed opcodes (L/LH/LR/IC/ICM/CVB/TRT/API/SPI/AH/AR/…) produce NO false setter
     sites for their (register/inverted) destinations.
  3. prior_value_required annotation flows through to setter sites for read-modify-write
     opcodes (ASI/NI/AP/…).

Usage:
    python scripts/validate_setter_overhaul.py [KB_OUTPUT_DIR]

KB_OUTPUT_DIR must contain populated <stem>.asm.json blueprints + file_call_graph.json.
Default: jobs/0f402440-824c-4f03-97de-38d20fb48f06/output
"""
import sys
from pathlib import Path

# Ensure the repo root (not scripts/) is first on sys.path so the local
# blueprint_io.py wins over any site-packages package of the same name.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from blueprint_io import iter_flow, load_blueprint
from find_variable_modifiers import scan_blueprint_for_setters
from trace_lineage import normalize_token

DEFAULT_KB = "jobs/0f402440-824c-4f03-97de-38d20fb48f06/output"

# (file stem, destination var, opcode, source line) — audit-named corpus hits that
# were SILENTLY MISSED before the overhaul (opcode absent from SETTER_INST).
NEWLY_COVERED = [
    ("ae48", "CALLER_REGS", "STMG", 521),
    ("nb81", "REGSAVE",     "STMG", 408),
    ("nb81", "@MMUERR",     "ASI",  669),
    ("da78", "WK_DBL",      "STCKF", 2085),
    ("xh72", "CR21GLCI15",  "STCMH", 1130),
]

# Opcodes removed from SETTER_INST — must never produce a setter site.
REMOVED = {"L", "LH", "LR", "IC", "ICM", "CVB", "TRT", "AH", "AHI", "AR",
           "API", "SPI", "LA", "LG", "LGR", "SLL", "SRL", "SRA"}
_REMOVED_DEST_IDX = {"ICM": 2, "LH": 1, "L": 1, "LG": 1}


def main(kb: Path) -> int:
    failures = 0

    print("== 1. newly-covered setters now detected ==")
    for stem, var, op, line in NEWLY_COVERED:
        p = kb / f"{stem}.asm.json"
        if not p.exists():
            print(f"  [skip] {stem} blueprint missing in {kb}")
            continue
        hits, err = scan_blueprint_for_setters(p, var)
        m = [h for h in hits if str(h.get("inst", "")).upper() == op]
        ok = bool(m)
        failures += (not ok)
        print(f"  [{'PASS' if ok else 'FAIL'}] {stem}:{line} {op} {var:14} "
              f"-> {len(m)} {op} setter(s)" + ("" if ok else f"  err={err}"))

    print("\n== 2. removed opcodes produce no false setter sites ==")
    stems = sorted({s for s, *_ in NEWLY_COVERED} |
                   {"xh80", "xh81", "lu82", "da76"})
    leaks = 0
    occurrences = 0
    for stem in stems:
        p = kb / f"{stem}.asm.json"
        if not p.exists():
            continue
        bp = load_blueprint(p, skip_global_lineage=True, keys={"meta", "blocks"})
        for b in bp.get("blocks", []) or []:
            for e in iter_flow(b):
                inst = str(e.get("inst", "")).upper()
                if inst not in REMOVED:
                    continue
                args = e.get("args") or []
                didx = _REMOVED_DEST_IDX.get(inst, 0)
                dest = normalize_token(str(args[didx])) if len(args) > didx else ""
                if not dest or dest.startswith("R"):
                    continue
                occurrences += 1
                ln = int(e.get("line") or 0)
                hits, _ = scan_blueprint_for_setters(p, dest)
                if any(int(h.get("line") or 0) == ln and
                       str(h.get("inst", "")).upper() == inst for h in hits):
                    leaks += 1
                    print(f"  LEAK {stem}:{ln} {inst} {dest}")
    print(f"  [{'PASS' if leaks == 0 else 'FAIL'}] {occurrences} removed-opcode "
          f"occurrences with named dest -> {leaks} false setter sites (expect 0)")
    failures += (leaks != 0)

    print("\n== RESULT ==")
    print("ALL CORPUS CHECKS PASSED" if failures == 0 else f"{failures} CHECK GROUP(S) FAILED")
    return 1 if failures else 0


if __name__ == "__main__":
    kb = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(DEFAULT_KB)
    if not (kb / "file_call_graph.json").exists():
        print(f"WARNING: {kb} has no file_call_graph.json; pick a populated jobs/<id>/output dir")
    raise SystemExit(main(kb))
