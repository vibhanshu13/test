#!/usr/bin/env python3
"""KB-4 migration: add ``target_upper`` indexed column to ``gvl_edges``.

Run once per deployment after upgrading the codebase to the version that
uses ``target_upper`` for fast case-insensitive GVL edge lookups.

Usage::

    python scripts/migrate_kb4_target_upper.py [--jobs-dir /path/to/jobs]

If ``--jobs-dir`` is omitted the path from ``api.config.settings.JOBS_BASE_DIR``
is used.  Exits 0 on success, 1 if any ``index.db`` migration fails.

What the script does for each ``index.db``:
  1. Checks whether ``target_upper`` column already exists → skip if so.
  2. ``ALTER TABLE gvl_edges ADD COLUMN target_upper TEXT``
  3. ``UPDATE gvl_edges SET target_upper = UPPER(target)``
  4. ``CREATE INDEX IF NOT EXISTS ix_gvl_edges_job_tgt_upper
         ON gvl_edges (job_id, target_upper)``
  5. ``ANALYZE gvl_edges``    — refresh SQLite query-planner stats

No parser re-run is required.  The migration is idempotent (safe to re-run).
"""

from __future__ import annotations

import argparse
import sqlite3
import sys
from pathlib import Path


def _column_exists(conn: sqlite3.Connection, table: str, column: str) -> bool:
    cursor = conn.execute(f"PRAGMA table_info({table})")
    return any(row[1] == column for row in cursor.fetchall())


def migrate_db(db_path: Path) -> bool:
    """Apply KB-4 migration to a single index.db. Returns True on success."""
    try:
        conn = sqlite3.connect(str(db_path), timeout=60)
        conn.execute("PRAGMA journal_mode=WAL")
        try:
            if _column_exists(conn, "gvl_edges", "target_upper"):
                print(f"  [skip]    {db_path} — target_upper already present")
                return True

            print(f"  [migrate] {db_path}")

            with conn:
                conn.execute(
                    "ALTER TABLE gvl_edges ADD COLUMN target_upper TEXT"
                )
            print(f"            column added")

            with conn:
                conn.execute(
                    "UPDATE gvl_edges SET target_upper = UPPER(target)"
                )
            rows = conn.execute(
                "SELECT COUNT(*) FROM gvl_edges WHERE target_upper IS NOT NULL"
            ).fetchone()[0]
            print(f"            {rows:,} rows backfilled")

            with conn:
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS ix_gvl_edges_job_tgt_upper "
                    "ON gvl_edges (job_id, target_upper)"
                )
            print(f"            index created")

            with conn:
                conn.execute("ANALYZE gvl_edges")
            print(f"            stats refreshed")

            return True
        finally:
            conn.close()
    except Exception as exc:
        print(f"  [ERROR]   {db_path}: {exc}", file=sys.stderr)
        return False


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--jobs-dir", metavar="PATH",
        help="Root jobs directory (default: api.config.settings.JOBS_BASE_DIR)",
    )
    args = parser.parse_args()

    if args.jobs_dir:
        jobs_base = Path(args.jobs_dir)
    else:
        try:
            from api.config import settings
            jobs_base = Path(settings.JOBS_BASE_DIR)
        except Exception as exc:
            print(f"Cannot import api.config.settings: {exc}\n"
                  "Pass --jobs-dir explicitly.", file=sys.stderr)
            return 1

    if not jobs_base.is_dir():
        print(f"Jobs directory not found: {jobs_base}", file=sys.stderr)
        return 1

    db_files = sorted(jobs_base.glob("*/index.db"))
    if not db_files:
        print(f"No index.db files found under {jobs_base}")
        return 0

    print(f"Found {len(db_files)} index.db file(s) under {jobs_base}\n")

    ok = True
    for db_path in db_files:
        if not migrate_db(db_path):
            ok = False

    print()
    if ok:
        print("KB-4 migration complete — all databases updated successfully.")
    else:
        print("KB-4 migration finished WITH ERRORS — check stderr above.",
              file=sys.stderr)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
