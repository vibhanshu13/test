#!/usr/bin/env python3
"""Hand-authored backward-lineage session for LWRPODYNAMICCIDMATCHRESPONSEIND.

The real backward_traversal trace is broken for this variable (it produced
no setter tuple and unrelated dep vars). This script writes a CORRECT,
hand-traced session for the chain:

        aa71 (entry, ASM)  ->  dw730000 (DW73 pipeline, C++)  ->  dw710000 (setter, C++)

It encodes the actual setter, the precise conditions that gate it, and the
dependent variables found while walking backward — in the minimal shape the
explanation pipeline (llm/lineage_reasoning.build_step_reasoning +
llm/lineage_explainer.explain_step) consumes, so it can be rendered on the UI
with full detail (steps, conditions, dependent-variable graph, summary).

Data the pipeline actually reads (everything else is ignored, so we omit it):
  tuple (chunk_N.json):
    { variable, phase, metadata: { bp_path, asm_file, anchor_blocks,
        scope_label, summary, phase_metadata, intra_tuple_edges,
        cross_file_calls_out }, nodes: [ ... ] }
  node:
    { id, code, relevant_code_lines: [ {line, role, inst, detail} ],
      dependent_variables: [ NAME, ... ] }
  phase_metadata (per tuple): { scope_label, setter_sites?, dep_var?,
      depth?, origin_chain? }

Run:  python3 scripts/build_mock_lwrpo_session.py [kb_id]
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import msgpack  # noqa: E402

from backward_traversal.runner.chunked_session import (  # noqa: E402
    compute_session_id,
    get_session_dir,
    PHASE_COMPLETE,
)
from api.routes.conversations import _DEFAULT_OPTIONS, _output_dir  # noqa: E402

ROOT_VAR = "LWRPODYNAMICCIDMATCHRESPONSEIND"
CHAIN = ["aa71", "dw730000", "dw710000"]   # entry -> ... -> setter
DEFAULT_KB = "c68d392b-19be-407a-97a6-34acca2f1071"  # 2june_V3

# A condition is modelled as a CONDITION_CHECK line immediately followed by a
# BRANCH line, so build_step_reasoning pairs them into "check -> decides".
def cond(line, detail, inst="if", branch_inst="skip",
         branch_detail="skips the assignment when the check fails",
         role="CONDITION_CHECK", branch_role="BRANCH"):
    return [
        {"line": line,     "role": role,        "inst": inst,        "detail": detail},
        {"line": line + 0.5, "role": branch_role, "inst": branch_inst, "detail": branch_detail},
    ]


# ---------------------------------------------------------------------------
# STEP 0 — dw710000.cpp  (THE SETTER, phase=modifier)
# Full internal call hierarchy that gates the setter (hand-traced & confirmed
# against source). All gates are CONTROL dependencies (if/switch on a value),
# never x = y + z data dependencies — so we track the variable CHECKED at each
# gate, not arithmetic operands:
#
#   callPlasticAuthenticationComponentInterface()  [switch transactionCode]
#     -> performPaAuthACharge()                     [switch tableCollectedIndicator: default]
#       -> performPaAuthAChargeCidValidation()      [exitIndicator==Off; not balance-transfer]
#         -> processACreditTransaction()            [linkSource gates] -> SETTER
# ---------------------------------------------------------------------------
STEP_DW710000 = {
    "file_stem": "dw710000",
    "file_type": "cpp",
    "variable": ROOT_VAR,
    "phase": "modifier",
    "summary": (
        "The Plastic Authentication component sets the Dynamic CID Match Response "
        "Indicator. A credit-request transaction is routed through "
        "callPlasticAuthenticationComponentInterface -> performPaAuthACharge -> "
        "performPaAuthAChargeCidValidation -> processACreditTransaction. For an "
        "Express-Pay / wallet-token transaction whose stored dynamic-4CSC result "
        "equals '00', the indicator is marked 'match found'."
    ),
    "anchor_blocks": ["processACreditTransaction"],
    "scope_label": "anchor_based",
    "phase_metadata": {
        "scope_label": "anchor_based",
        "setter_sites": [{
            "line": 1007,
            "raw_line": ("plasticAuth.process.various.lwrpoDynamicCidMatchResponseInd = "
                         "Dynamic4cscMatchIndicators::Dynamic4cscMatchFound;"),
            "instruction": "=",
            "call_type": "setter_site",
            "routine": "processACreditTransaction",
        }],
    },
    "nodes": [
        {
            "id": "callPlasticAuthenticationComponentInterface",
            "code": "switch(lwrCommon.process.links.transactionCode) { case CreditRequest: performPaAuthACharge(...); ... }",
            "relevant_code_lines": cond(
                367,
                "lwrCommon.process.links.transactionCode is one of CreditRequest, "
                "WorkedFromReferralQue, ForceEntryToRefer or ForceEntryToAA  — the "
                "transaction is a credit-authorization request routed into the "
                "Authorize-a-Charge path (performPaAuthACharge)",
            ),
            "dependent_variables": ["TRANSACTIONCODE"],
        },
        {
            "id": "performPaAuthACharge",
            "code": "switch(plasticAuth.process.various.tableCollectedIndicator) { ... default: performPaAuthAChargeCidValidation(...); }",
            "relevant_code_lines": cond(
                572,
                "plasticAuth.process.various.tableCollectedIndicator is none of "
                "NotCollected, Atm or TablesCollected (the switch default)  — CID "
                "validation has not run yet, so performPaAuthAChargeCidValidation is called",
            ),
            "dependent_variables": ["TABLECOLLECTEDINDICATOR"],
        },
        {
            "id": "performPaAuthAChargeCidValidation",
            "code": ("if(plasticAuth.process.various.exitIndicator == Pa::Off) { "
                     "if(!((gnaBalXferInd & 0x08) || (gnaBalXferInd & 0x10) || "
                     "(specialRoutingMember & 0x10))) { processACreditTransaction(...); } }"),
            "relevant_code_lines": (
                cond(627, "plasticAuth.process.various.exitIndicator == Pa::Off  — no earlier step flagged an error or early exit")
                + cond(640, "NOT(gnaBalXferInd & 0x08) AND NOT(gnaBalXferInd & 0x10) AND "
                            "NOT(specialRoutingMember & 0x10)  — the transaction is not a "
                            "balance transfer and is not specially routed")
            ),
            "dependent_variables": ["EXITINDICATOR", "GNABALXFERIND", "SPECIALROUTINGMEMBER"],
        },
        {
            "id": "processACreditTransaction",
            "code": (
                "if((workArea = getLwrwrAddresses()) != 0) { ... linkSourceArea = ...; }\n"
                "if(linkSourceArea != 0) {\n"
                "    if(linkSourceArea->lstknpoa == 'Y') {\n"
                "        if(memcmp(linkSourceArea->ls4cscres,\"00\",2)==0) {\n"
                "            plasticAuth.process.various.lwrpoDynamicCidMatchResponseInd = "
                "Dynamic4cscMatchIndicators::Dynamic4cscMatchFound;\n"
                "        }\n"
                "    }\n"
                "}"
            ),
            "relevant_code_lines": (
                cond(983, "(workArea = getLwrwrAddresses()) != 0 AND linkSourceArea != 0  — the LWR work area and link-source area were located on the ECB heap")
                + cond(992, "linkSourceArea->lstknpoa == 'Y'  — the transaction is an Express-Pay wallet-token (token POA) transaction")
                + cond(1005, "memcmp(linkSourceArea->ls4cscres, \"00\", 2) == 0  — the stored dynamic-4CSC result equals '00' (a match)")
                + [{
                    "line": 1007, "role": "SETTER_STEP", "inst": "=",
                    "detail": ("lwrpoDynamicCidMatchResponseInd = Dynamic4cscMatchFound  "
                               "— record that the dynamic CID 4CSC matched"),
                }]
            ),
            "dependent_variables": ["LSTKNPOA", "LS4CSCRES"],
        },
    ],
    "cross_file_calls_out": [],
}

# ---------------------------------------------------------------------------
# STEP 1 — dw730000.cpp  (DW73 Inquiry Pipeline, phase=upstream)
# DW73 is entered from aa71. When the Carver engine and CID-inquiry processing
# are active and the carver setup calls succeed and every work-area pointer is
# populated, it calls callPlasticAuthenticationComponentInterface(), which
# drives into the plastic-authentication component (dw710000).
# ---------------------------------------------------------------------------
STEP_DW730000 = {
    "file_stem": "dw730000",
    "file_type": "cpp",
    "variable": ROOT_VAR,
    "phase": "upstream",
    "summary": (
        "DW73 is the CAS Inquiry Pipeline. When the Carver engine and CID-inquiry "
        "processing are both active, it performs three Carver setup calls and, if "
        "all required work-area pointers are present, hands the transaction to the "
        "Plastic Authentication component where the response indicator is set."
    ),
    "anchor_blocks": ["DW73"],
    "scope_label": "anchor_based",
    "phase_metadata": {"scope_label": "anchor_based"},
    "nodes": [{
        "id": "DW73",
        "code": (
            "if ((casVision1->carverActive == 1) && (casVision1->cidInquiryActive == 1)) {\n"
            "    callCoreCarver(&registers); if (registers.r1 <= 0) return -1;   // init\n"
            "    callCoreCarver(&registers); if (registers.r1 <= 0) return -1;   // GET_CCR_ADDR\n"
            "    callCoreCarver(&registers); if (registers.r1 <= 0) return -1;   // GET_SPEC_ADDR\n"
            "    if (addresses->plasticAuthOnlyArea && addresses->commonWorkArea &&\n"
            "        addresses->isoArea && addresses->bcis && addresses->ccr)\n"
            "        callPlasticAuthenticationComponentInterface(...);\n"
            "}"
        ),
        "relevant_code_lines": (
            cond(57, "casVision1->carverActive == 1  — the Carver pipeline engine is active")
            + cond(58, "casVision1->cidInquiryActive == 1  — CID-inquiry processing is enabled")
            + cond(63, "callCoreCarver setup calls each return r1 > 0  — Carver init, CCR-address and spec-address lookups all succeed",
                   inst="if", branch_detail="returns -1 if any setup call fails")
            + cond(93, "plasticAuthOnlyArea, commonWorkArea, isoArea, bcis and ccr are all non-null  — every required work area is present")
            + [{
                "line": 106, "role": "CALL_SITE", "inst": "call",
                "detail": "callPlasticAuthenticationComponentInterface(...)  — enter the Plastic Authentication component (dw710000)",
            }]
        ),
        "dependent_variables": ["CARVERACTIVE", "CIDINQUIRYACTIVE"],
    }],
    "cross_file_calls_out": [{
        "source_block": "DW73", "target_file": "dw710000",
        "instruction": "call", "call_type": "subroutine_call", "line": 106,
    }],
}

# ---------------------------------------------------------------------------
# STEP 2 — aa71.asm  (entry, phase=upstream)
# Routine AA710A5B: when the CID-inquiry global is on and the transaction is an
# 8001 CID-inquiry transaction, it enters the inquiry pipeline (ENTRC DW73).
# ---------------------------------------------------------------------------
STEP_AA71 = {
    "file_stem": "aa71",
    "file_type": "asm",
    "variable": ROOT_VAR,
    "phase": "upstream",
    "summary": (
        "AA71 is the credit-authorization entry program. In routine AA710A5B it "
        "checks the CID-inquiry control flag and the transaction-status flag and, "
        "for an 8001 CID-inquiry transaction, enters the inquiry pipeline (DW73)."
    ),
    "anchor_blocks": ["AA710A5B"],
    "scope_label": "anchor_based",
    "phase_metadata": {"scope_label": "anchor_based"},
    "nodes": [{
        "id": "AA710A5B",
        "code": (
            "         TM    @CASVIS1,X'01'      IS CID INQUIRY ACTIVE?\n"
            "         JNO   AA71_AN70           NO - OLD CID INQUIRY PROCESS\n"
            "         TM    L7DSTS,X'40'        8001 CID INQUIRY TXN?\n"
            "         JNO   AA71_AN70           NO - DONT CALL INQUIRY PIPELINE\n"
            "         ENTRC DW73                ENTER THE INQUIRY PIPELINE"
        ),
        "relevant_code_lines": [
            {"line": 2008, "role": "TEST_MASK",       "inst": "TM",    "detail": "@CASVIS1,X'01'"},
            {"line": 2010, "role": "BRANCH",          "inst": "JNO",   "detail": "AA71_AN70 (skip pipeline if CID inquiry not active)"},
            {"line": 2012, "role": "TEST_MASK",       "inst": "TM",    "detail": "L7DSTS,X'40'"},
            {"line": 2014, "role": "BRANCH",          "inst": "JNO",   "detail": "AA71_AN70 (skip pipeline if not an 8001 CID-inquiry txn)"},
            # General guard: the transaction must not have been diverted by an
            # earlier bypass (fraud-SE, franchise card, non-auth reroute, errors)
            # before control reaches AA710A5B.
            {"line": 2015, "role": "CONDITION_CHECK", "inst": "guard",
             "detail": "no earlier bypass taken (not fraud-SE, not franchise, not a non-auth reroute, no prior errors)"},
            {"line": 2016, "role": "CROSS_FILE_CALL", "inst": "ENTRC", "detail": "DW73 — enter the inquiry pipeline"},
        ],
        "dependent_variables": ["@CASVIS1", "L7DSTS"],
    }],
    "cross_file_calls_out": [{
        "source_block": "AA710A5B", "target_file": "dw730000",
        "instruction": "ENTRC", "call_type": "subroutine_call", "line": 2016,
    }],
}

# ---------------------------------------------------------------------------
# Dependent-variable backward traces (phase=dep_var_chain).
# Each gating variable, walked backward. Within these three files none of them
# has a setter (their values arrive from the inbound transaction, the upstream
# dynamic-CID pipeline, or global configuration), so each resolves to a
# terminal input. We still record where it is read so the UI can show its role.
# ---------------------------------------------------------------------------
def dep_step(name, *, use_file, use_type, use_routine, use_line, use_detail,
             summary, origin_chain, setter=None, conditions=None,
             l2_deps=None):
    """One dependent-variable backward trace (phase=dep_var_chain).

    use_*    : the ANCHOR — where this dep var was found/read in the chain.
    setter   : None  -> TERMINAL (no reaching setter in the 3-file scope; input/global)
               dict  -> in-tree reaching setter:
                 {file, ftype, routine, line, statement, dep_type}
                 (the setter file is pulled into the lineage via the call-graph
                  connection; conditions[] are the gates above the setter; l2_deps[]
                  are the dep-var-of-dep-var names introduced by the setter.)
    conditions: list of {line, detail} gating the setter (control deps).
    l2_deps  : list of second-level dependent variable names (graph nodes).
    """
    l2_deps = l2_deps or []
    if setter is None:
        # Terminal: show only where it is read, mark it an input/global.
        return {
            "file_stem": use_file, "file_type": use_type, "variable": name,
            "phase": "dep_var_chain", "summary": summary,
            "anchor_blocks": [use_routine], "scope_label": "collection_based",
            "phase_metadata": {"scope_label": "collection_based", "dep_var": name,
                               "depth": 0, "origin_chain": origin_chain},
            "nodes": [{
                "id": use_routine, "code": use_detail,
                "relevant_code_lines": [
                    {"line": use_line, "role": "CONDITION_CHECK", "inst": "read", "detail": use_detail},
                ],
                "dependent_variables": [],
            }],
            "cross_file_calls_out": [],
        }

    # In-tree reaching setter — the dep var IS set within the connected files.
    rcl = []
    for c in (conditions or []):
        rcl += cond(c["line"], c["detail"])
    rcl.append({
        "line": setter["line"], "role": "SETTER_STEP", "inst": setter.get("inst", "="),
        "detail": setter["statement"],
    })
    return {
        "file_stem": setter["file"], "file_type": setter["ftype"], "variable": name,
        "phase": "dep_var_chain", "summary": summary,
        "anchor_blocks": [setter["routine"]], "scope_label": "anchor_based",
        "phase_metadata": {
            "scope_label": "anchor_based", "dep_var": name, "depth": 0,
            "origin_chain": origin_chain,
            "setter_sites": [{
                "line": setter["line"], "raw_line": setter["statement"],
                "instruction": setter.get("inst", "="), "call_type": "setter_site",
                "routine": setter["routine"],
            }],
        },
        "nodes": [{
            "id": setter["routine"], "code": setter["statement"],
            "relevant_code_lines": rcl,
            "dependent_variables": l2_deps,
        }],
        "cross_file_calls_out": [],
    }


# --- L1 dep vars with REAL reaching setters (pull in dw710100) ---------------
STEP_TRANSACTIONCODE = dep_step(
    "TRANSACTIONCODE",
    use_file="dw710000", use_type="cpp", use_routine="callPlasticAuthenticationComponentInterface",
    use_line=367, use_detail="switch(lwrCommon.process.links.transactionCode)",
    origin_chain=["dw710000", "dw710100"],
    summary=("The CAS transaction code. It is copied unconditionally from the inbound "
             "credit-input message (BCIS) into the LwrCommon work area by the prologue, "
             "then read to route credit-request transactions into the Authorize-a-Charge "
             "path. Its underlying value is a terminal inbound input (BCIS field L7DTNC)."),
    setter={"file": "dw710100", "ftype": "cpp", "routine": "movePaCommonFields", "line": 456,
            "statement": "lwrCommon.process.links.transactionCode = (CasTransactionCode::Type) bcis.transactionCode;"},
    l2_deps=["BCIS.TRANSACTIONCODE"],   # L7DTNC — terminal inbound
)

STEP_GNABALXFERIND = dep_step(
    "GNABALXFERIND",
    use_file="dw710000", use_type="cpp", use_routine="performPaAuthAChargeCidValidation",
    use_line=640, use_detail="!((lwrCommon.process.links.gnaBalXferInd & 0x08) || (... & 0x10) || (specialRoutingMember & 0x10))",
    origin_chain=["dw710000", "dw710100"],
    summary=("The GNA balance-transfer indicator. Copied from the inbound BCIS into the "
             "LwrCommon work area by the prologue; its fraud/enlist/globstar flag bits are "
             "OR-ed on upstream in aa71. Read here to skip CID validation for balance-transfer "
             "transactions. Base value is a terminal inbound input (BCIS field L7DGIND)."),
    setter={"file": "dw710100", "ftype": "cpp", "routine": "movePaCommonFields", "line": 458,
            "statement": "lwrCommon.process.links.gnaBalXferInd = bcis.optimaWrkArea.gnaBalXferInd;"},
    l2_deps=["L7DGIND"],   # flag-OR'd in aa71; base terminal inbound
)

STEP_SPECIALROUTINGMEMBER = dep_step(
    "SPECIALROUTINGMEMBER",
    use_file="dw710000", use_type="cpp", use_routine="performPaAuthAChargeCidValidation",
    use_line=642, use_detail="(lwrCommon.specialRoutingMember & 0x10)",
    origin_chain=["dw710000", "dw710100"],
    summary=("The special-routing member indicator. Copied (memcpy) from the inbound BCIS into "
             "the LwrCommon work area by the prologue; read here to skip CID validation for "
             "specially-routed transactions. It is read-only everywhere in scope — a terminal "
             "inbound input (BCIS field L7DBRN)."),
    setter={"file": "dw710100", "ftype": "cpp", "routine": "movePaCommonFields", "line": 460,
            "statement": "memcpy(&lwrCommon.specialRoutingMember, &bcis.specialRoutingMember, sizeof(char));"},
    l2_deps=["L7DBRN"],   # terminal inbound
)

STEP_EXITINDICATOR = dep_step(
    "EXITINDICATOR",
    use_file="dw710000", use_type="cpp", use_routine="performPaAuthAChargeCidValidation",
    use_line=627, use_detail="if(plasticAuth.process.various.exitIndicator == Pa::Off)",
    origin_chain=["dw710000"],
    summary=("The early-exit indicator. editInputMessageErrors sets it ON when the ECB return "
             "code is not 'credit approved'; otherwise it stays at its cleared 'off' state. "
             "Read here to skip CID validation when an earlier edit/error flagged the message. "
             "Depends on the ECB return code (terminal pipeline value)."),
    setter={"file": "dw710000", "ftype": "cpp", "routine": "editInputMessageErrors", "line": 900,
            "statement": "plasticAuth.process.various.exitIndicator = Pa::On;"},
    conditions=[{"line": 878,
                 "detail": "ecbOverlay->returnCode != L7lReturnCode::CreditApproved  — the transaction was not already approved (an edit/error occurred)"}],
    l2_deps=["RETURNCODE"],   # L7L7L ECB field — terminal external
)

# --- L1 dep vars that are TERMINAL within the 3-file scope --------------------
STEP_TABLECOLLECTED = dep_step(
    "TABLECOLLECTEDINDICATOR",
    use_file="dw710000", use_type="cpp", use_routine="performPaAuthACharge",
    use_line=572, use_detail="switch(plasticAuth.process.various.tableCollectedIndicator)  — default case routes to CID validation",
    origin_chain=["dw710000"],
    summary=("The table-collected state of the plastic-auth work area. It reaches this switch "
             "in its cleared (uninitialised) work-area state, which is none of NotCollected/Atm/"
             "TablesCollected, so the default case runs CID validation. No business setter "
             "writes it before this point — it is a work-area initialisation value."),
    setter=None,
)

STEP_LSTKNPOA = dep_step(
    "LSTKNPOA",
    use_file="dw710000", use_type="cpp", use_routine="processACreditTransaction",
    use_line=992, use_detail="if(linkSourceArea->lstknpoa == 'Y')",
    origin_chain=["dw710000"],
    summary=("The LinkSource token point-of-acceptance flag. When 'Y' the transaction is an "
             "Express-Pay wallet-token transaction. It is populated into the shared LinkSource "
             "work area by an external LinkSource-build module (not present in this codebase) "
             "before plastic authentication runs — a terminal input."),
    setter=None,
)

STEP_LS4CSCRES = dep_step(
    "LS4CSCRES",
    use_file="dw710000", use_type="cpp", use_routine="processACreditTransaction",
    use_line=1005, use_detail="if(memcmp(linkSourceArea->ls4cscres,\"00\",2)==0)",
    origin_chain=["dw710000"],
    summary=("The stored dynamic-4CSC result on the LinkSource work area. '00' means the dynamic "
             "CID 4CSC matched. It is populated by the external LinkSource-build / dynamic-CID "
             "pipeline (not present in this codebase) before this read — a terminal input."),
    setter=None,
)

STEP_CIDINQUIRYACTIVE = dep_step(
    "CIDINQUIRYACTIVE",
    use_file="dw730000", use_type="cpp", use_routine="DW73",
    use_line=58, use_detail="casVision1->cidInquiryActive == 1  (CasVision1 overlays glob(_casvis1) == the @CASVIS1 global)",
    origin_chain=["dw730000"],
    summary=("A CAS Vision configuration flag (a field of CasVision1, which overlays the same "
             "global storage as the ASM @CASVIS1 byte). Indicates CID-inquiry processing is "
             "enabled. Set by system configuration, read-only in scope — a terminal system global."),
    setter=None,
)

STEP_CASVIS1 = dep_step(
    "@CASVIS1",
    use_file="aa71", use_type="asm", use_routine="AA710A5B",
    use_line=2008, use_detail="TM @CASVIS1,X'01'  — is CID inquiry globally active?",
    origin_chain=["aa71"],
    summary=("The CAS Vision global control byte (Global Area 3). Bit X'01' = CID inquiry active. "
             "Read-only across the codebase (only TM tests); set by a system config/init module "
             "not present here — a terminal system global. Same storage the C++ side reads as "
             "casVision1->carverActive / cidInquiryActive."),
    setter=None,
)

STEP_L7DSTS = dep_step(
    "L7DSTS",
    use_file="aa71", use_type="asm", use_routine="AA710A5B",
    use_line=2012, use_detail="TM L7DSTS,X'40'  — is this an 8001 CID-inquiry transaction?",
    origin_chain=["aa71"],
    summary=("The L7D transaction-status byte. Bit X'40' marks an 8001 CID-inquiry transaction. "
             "Read-only in scope (only TM tests); set by upstream inbound-message routing that "
             "classifies the incoming transaction — a terminal inbound status input."),
    setter=None,
)

STEPS = [
    STEP_DW710000,            # 0  setter file
    STEP_DW730000,            # 1  upstream pipeline (DW73)
    STEP_AA71,                # 2  entry
    # L1 dep vars WITH reaching setters (dw710100 pulled in via the call edge):
    STEP_TRANSACTIONCODE,     # 3
    STEP_GNABALXFERIND,       # 4
    STEP_SPECIALROUTINGMEMBER,# 5
    STEP_EXITINDICATOR,       # 6
    # L1 dep vars that are terminal within scope:
    STEP_TABLECOLLECTED,      # 7
    STEP_LSTKNPOA,            # 8
    STEP_LS4CSCRES,           # 9
    STEP_CIDINQUIRYACTIVE,    # 10
    STEP_CASVIS1,             # 11
    STEP_L7DSTS,              # 12
]


def build_chunk(step: dict) -> dict:
    """Serialize one step into the chunk JSON shape assemble_tuple expects."""
    return {
        "variable": step["variable"],
        "phase": step["phase"],
        "metadata": {
            "bp_path": None,
            "asm_file": None,
            "anchor_blocks": step.get("anchor_blocks") or [],
            "scope_label": step.get("scope_label") or "",
            "summary": step.get("summary") or "",
            "phase_metadata": step.get("phase_metadata") or {},
            "intra_tuple_edges": [],
            "cross_file_calls_out": step.get("cross_file_calls_out") or [],
        },
        "nodes": step["nodes"],
    }


def main():
    kb_id = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_KB

    gf = _output_dir(kb_id) / "file_call_graph.json"
    graph_mtime = gf.stat().st_mtime if gf.exists() else 0.0
    options = {**_DEFAULT_OPTIONS, "kb_id": kb_id}
    session_id = compute_session_id(kb_id, ROOT_VAR, CHAIN, options, graph_mtime)

    session_dir = get_session_dir(kb_id, session_id)
    session_dir.mkdir(parents=True, exist_ok=True)

    # Remove any stale chunks from the broken run
    for old in session_dir.glob("chunk_*.json"):
        old.unlink()

    tuple_index_map = []
    for i, step in enumerate(STEPS):
        chunk_file = f"chunk_{i}.json"
        chunk = build_chunk(step)
        (session_dir / chunk_file).write_text(json.dumps(chunk, indent=2), encoding="utf-8")
        tuple_index_map.append({
            "file_stem": step["file_stem"],
            "file_type": step["file_type"],
            "variable": step["variable"],
            "phase": step["phase"],
            "node_count": len(step["nodes"]),
            "chunk_file": chunk_file,
        })

    state = {
        "session_id": session_id,
        "kb_id": kb_id,
        "root_variable": ROOT_VAR,
        "selected_chain": CHAIN,
        "blueprint_dir": "",
        "asm_dir": None,
        "options": {k: options.get(k) for k in options},
        "phase": PHASE_COMPLETE,          # mark complete so the API never re-runs the broken trace
        "tuple_index_map": tuple_index_map,
        "empty_tuples": [],
        "work_queue": [],
        "file_meta": {},
        "dep_var_collection_map": {s["variable"]: [] for s in STEPS if s["phase"] == "dep_var_chain"},
        "visited_dep_vars": [s["variable"] for s in STEPS if s["phase"] == "dep_var_chain"],
        "rv_visited_downstream": [],
        "full_flow_serial": {},           # empty -> no full_flow_edges (optional context)
        "file_type_map": {s["file_stem"]: s["file_type"] for s in STEPS},
        "edge_type_serial": {},
        "edge_lines_serial": {},
        "selected_chain_set": sorted(CHAIN),
        "warnings": [],
        "graph_fingerprint": "mock",
        "identity_index_path": "",
    }
    (session_dir / "session.msgpack").write_bytes(msgpack.packb(state, use_bin_type=True))

    # Drop the stale explain session so it regenerates from these corrected tuples.
    exp = _output_dir(kb_id) / "lineage_explain_sessions" / f"{session_id}.msgpack"
    if exp.exists():
        exp.unlink()

    print(f"kb_id        : {kb_id}")
    print(f"session_id   : {session_id}")
    print(f"session_dir  : {session_dir}")
    print(f"tuples       : {len(tuple_index_map)}")
    for i, t in enumerate(tuple_index_map):
        print(f"  [{i}] {t['file_stem']:9s} {t['file_type']:3s} {t['phase']:14s} var={t['variable']}")
    print("stale explain session removed:", exp)


if __name__ == "__main__":
    main()
