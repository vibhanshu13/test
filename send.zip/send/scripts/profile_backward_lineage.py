#!/usr/bin/env python3
"""Replay a backward-lineage request in-process, optionally under cProfile.

Bypasses the API/Celery layers and calls run_backward_only() with the same
prebuilt DB indexes the task uses, so wall-clock and profiles reflect the
real query path.  Output goes to a throwaway directory — diff it against a
prior run to prove behavioral parity after a perf change.

Usage:
    .venv/bin/python scripts/profile_backward_lineage.py \
        --kb d074a8a8-a1fb-499d-8a52-1071c5f2a510 \
        --variable lwrpoDynamicCidMatchResponseInd \
        --chain aa71,dw730000,dw710000 \
        --out /tmp/bw_replay [--profile /tmp/bw.prof] [--asm-dir PATH]
"""
import argparse
import cProfile
import pstats
import shutil
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--kb", required=True, help="knowledge-base / job id under jobs/")
    ap.add_argument("--variable", required=True)
    ap.add_argument("--chain", required=True, help="comma-separated chain stems")
    ap.add_argument("--out", default="/tmp/bw_replay")
    ap.add_argument("--profile", default=None, help="write cProfile stats here")
    ap.add_argument("--asm-dir", default=None)
    ap.add_argument("--max-dep-vars", type=int, default=20)
    args = ap.parse_args()

    kb_output = REPO / "jobs" / args.kb / "output"
    blueprint_dir = kb_output / "asm"
    out_dir = Path(args.out)
    if out_dir.exists():
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True)
    output_path = out_dir / f"{args.variable}_backward_lineage.json"
    asm_dir = Path(args.asm_dir) if args.asm_dir else None

    from backward_traversal.runner.backward_only_runner import run_backward_only
    from api.tasks._task_utils import resolve_graph_file

    graph_file = resolve_graph_file(kb_output, args.kb)

    prebuilt = {}
    try:
        from api.index_db.readers import (
            build_call_graph_indexes,
            get_call_graph_callsites_for_edge,
        )
        from api.tasks.kb_backward_lineage_task import _LazyCallsiteMap
        idx = build_call_graph_indexes(args.kb, fallback_path=graph_file)
        if idx is not None:
            prebuilt = {
                "prebuilt_file_type_map": idx["file_type_map"],
                "prebuilt_edge_type_map": idx["edge_type_map"],
                "prebuilt_edge_lines_map": idx["edge_lines_map"],
                "prebuilt_callsite_map": _LazyCallsiteMap(
                    args.kb, get_call_graph_callsites_for_edge
                ),
                "graph_payload": {},
            }
            print(f"using streaming DB indexes (file_type={len(idx['file_type_map'])})")
    except Exception as e:
        print(f"streaming indexes unavailable: {e}")

    def _run() -> None:
        rc = run_backward_only(
            variable=args.variable,
            selected_chain=[s.strip() for s in args.chain.split(",") if s.strip()],
            blueprint_dir=blueprint_dir,
            asm_dir=asm_dir if asm_dir and asm_dir.exists() else None,
            graph_file=graph_file,
            output_path=output_path,
            max_depth=8,
            max_subroutine_depth=2,
            max_subroutine_nodes=400,
            max_trace_nodes=5000,
            max_dep_vars=args.max_dep_vars,
            max_dep_var_depth=2,
            max_downstream_depth=2,
            max_downstream_files=30,
            extend_modifier_sites=False,
            target_setters=None,
            **prebuilt,
        )
        print(f"rc={rc}")

    profiler = cProfile.Profile() if args.profile else None
    t0 = time.monotonic()
    if profiler:
        profiler.enable()
    try:
        _run()
    finally:
        if profiler:
            profiler.disable()
        # Same cleanup as the celery task so connections don't leak between runs.
        for cleanup in (
            "backward_traversal.utils.reach_facts:close_reach_facts_reader",
            "backward_traversal.utils.cpp_lineage_utils:close_db_seed_state",
            "backward_traversal.runner.backward_only_runner:clear_gvl_projection_cache",
        ):
            mod_name, fn_name = cleanup.split(":")
            try:
                import importlib
                getattr(importlib.import_module(mod_name), fn_name)()
            except Exception:
                pass
    print(f"wall: {time.monotonic() - t0:.2f}s")
    if profiler:
        profiler.dump_stats(args.profile)
        stats = pstats.Stats(args.profile)
        stats.sort_stats("cumulative")
        print("\n=== top 40 by cumulative ===")
        stats.print_stats(40)


if __name__ == "__main__":
    main()
