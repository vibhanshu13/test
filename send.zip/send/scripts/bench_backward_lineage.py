#!/usr/bin/env python3
"""Benchmark the /backward-lineage API across payload combinations.

Host-run (not shipped in the image). Hits localhost:8201, submits each combo,
polls the celery task to completion, records wall-clock latency.

Usage:
    python scripts/bench_backward_lineage.py <mode_label> <out.json>
    # e.g. python scripts/bench_backward_lineage.py OFF /tmp/bench_off.json
           python scripts/bench_backward_lineage.py ON  /tmp/bench_on.json
"""
import json
import sys
import time
import urllib.request
import urllib.error

BASE = "http://localhost:8201"
TOK = open("/tmp/asm_tok.txt").read().strip()
KB = open("/tmp/asm_kb.txt").read().strip()
ASM_DIR = f"/var/asm-jobs/{KB}/input/asm"

VAR = "lwrpoDynamicCidMatchResponseInd"
CHAIN = ["aa71", "dw730000", "dw710000", "dw780000"]

BASE_PAYLOAD = dict(
    variable_name=VAR, chain_files=CHAIN, asm_dir=ASM_DIR,
    max_depth=8, max_subroutine_depth=2, max_subroutine_nodes=400,
    max_trace_nodes=5000, max_dep_vars=50, max_dep_var_depth=4,
    max_downstream_depth=2, max_downstream_files=30, extend_modifier_sites=False,
)

# One-factor sweeps around the baseline + a heavy combo.
COMBOS = [
    ("baseline",        {}),
    ("max_depth=4",     {"max_depth": 4}),
    ("max_depth=16",    {"max_depth": 16}),
    ("max_subdepth=1",  {"max_subroutine_depth": 1}),
    ("max_subdepth=4",  {"max_subroutine_depth": 4}),
    ("max_subnodes=200",  {"max_subroutine_nodes": 200}),
    ("max_subnodes=1000", {"max_subroutine_nodes": 1000}),
    ("max_dep_vars=10",   {"max_dep_vars": 10}),
    ("max_dep_vars=100",  {"max_dep_vars": 100}),
    ("max_dep_var_depth=2", {"max_dep_var_depth": 2}),
    ("max_dep_var_depth=8", {"max_dep_var_depth": 8}),
    ("extend_modifier=ON",  {"extend_modifier_sites": True}),
    ("HEAVY(all-max)", {"max_depth": 20, "max_subroutine_depth": 6,
                        "max_subroutine_nodes": 1000, "max_dep_vars": 100,
                        "max_dep_var_depth": 8, "max_downstream_depth": 4,
                        "max_downstream_files": 100, "extend_modifier_sites": True}),
]

TERMINAL = {"SUCCESS", "FAILURE", "REVOKED", "success", "failed", "error", "completed"}


def _req(method, path, body=None):
    url = BASE + path
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(url, data=data, method=method)
    r.add_header("Authorization", f"Bearer {TOK}")
    r.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(r, timeout=600) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")


def run_combo(name, override):
    payload = {**BASE_PAYLOAD, **override}
    payload["output_name"] = f"bench_{name.replace('(', '_').replace(')', '').replace('=', '_').replace(' ', '').replace('-', '_').replace(',', '_')}.json"
    t0 = time.time()
    code, resp = _req("POST", f"/v1/knowledge-bases/{KB}/backward-lineage", payload)
    if code not in (200, 202):
        return {"combo": name, "submit_code": code, "error": resp, "seconds": None, "state": "SUBMIT_FAIL"}
    tid = resp.get("celery_task_id") or resp.get("task_id")
    state = "UNKNOWN"
    while True:
        time.sleep(0.5)
        c2, st = _req("GET", f"/v1/tasks/{tid}")
        state = str(st.get("status") or st.get("state") or "")
        if state in TERMINAL:
            break
        if time.time() - t0 > 600:
            state = "TIMEOUT"
            break
    dt = time.time() - t0
    return {"combo": name, "submit_code": code, "seconds": round(dt, 3),
            "state": state, "task_id": tid}


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "RUN"
    out = sys.argv[2] if len(sys.argv) > 2 else f"/tmp/bench_{mode}.json"
    print(f"=== mode={mode}  KB={KB} ===")
    print(f"{'combo':24} {'seconds':>9}  state")
    results = []
    for name, override in COMBOS:
        r = run_combo(name, override)
        results.append(r)
        secs = f"{r['seconds']:.3f}" if r["seconds"] is not None else "  --  "
        print(f"{name:24} {secs:>9}  {r['state']}")
        if r["state"] in ("SUBMIT_FAIL",):
            print(f"    >>> {json.dumps(r['error'])[:300]}")
    json.dump({"mode": mode, "kb": KB, "results": results}, open(out, "w"), indent=2)
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
