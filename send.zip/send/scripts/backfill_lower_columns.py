#!/usr/bin/env python3
"""Backfill source_lower / target_lower columns on existing gvl_edges tables.

This script adds the pre-lowercased columns and indexes that the optimised
backward-lineage queries require.  It is safe to run multiple times — every
operation is idempotent (ALTER TABLE … ADD COLUMN checks PRAGMA table_info,
UPDATE … WHERE … IS NULL skips already-populated rows, CREATE INDEX IF NOT
EXISTS is a no-op when the index exists).

Usage examples
--------------
# Backfill a single job
python scripts/backfill_lower_columns.py --job-id 2e3db3d9-db34-459e-bbd5-525c686307a7

# Backfill all jobs under JOBS_BASE_DIR
python scripts/backfill_lower_columns.py --all

# Dry run — show what would be done, make no DB changes
python scripts/backfill_lower_columns.py --all --dry-run

# Point to a custom jobs directory
python scripts/backfill_lower_columns.py --all --jobs-dir /var/asm-jobs

# Run inside Docker
docker exec asm-modernizer-worker-1 python scripts/backfill_lower_columns.py --all
"""

from __future__ import annotations

import argparse
import logging
import sqlite3
import sys
import time
from pathlib import Path
from typing import List, Optional

# ---------------------------------------------------------------------------
# Bootstrap — ensure the repo root is on sys.path so api.* imports work
# whether the script is run from the repo root or the scripts/ directory.
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(message)s",
    level=logging.INFO,
    stream=sys.stdout,
)
logger = logging.getLogger("backfill_lower_columns")


# ---------------------------------------------------------------------------
# Core migration logic
# ---------------------------------------------------------------------------

def _get_existing_columns(con: sqlite3.Connection, table: str) -> set:
    """Return a set of column names for *table*."""
    rows = con.execute(f"PRAGMA table_info({table})").fetchall()
    return {row[1] for row in rows}


def migrate_job(db_path: Path, dry_run: bool = False) -> dict:
    """Run the source_lower/target_lower migration on a single index.db.

    Returns a dict with migration stats:
        columns_added   – number of ALTER TABLE columns added (0, 1, or 2)
        rows_backfilled – number of rows updated
        indexes_created – number of indexes created (0, 1, or 2)
        skipped         – True if gvl_edges table does not exist
    """
    stats = {
        "columns_added": 0,
        "rows_backfilled": 0,
        "indexes_created": 0,
        "skipped": False,
    }

    con = sqlite3.connect(str(db_path), timeout=30)
    try:
        # Apply performance PRAGMAs for the migration
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=NORMAL")
        con.execute("PRAGMA cache_size=-65536")      # 64 MB
        con.execute("PRAGMA temp_store=MEMORY")
        con.execute("PRAGMA mmap_size=268435456")     # 256 MB
        con.execute("PRAGMA busy_timeout=10000")      # 10 s for large DBs

        # Check gvl_edges table exists
        tables = {
            row[0]
            for row in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        if "gvl_edges" not in tables:
            logger.info("  gvl_edges table not found — skipping")
            stats["skipped"] = True
            return stats

        existing = _get_existing_columns(con, "gvl_edges")

        # ── Step 1: Add columns if missing ─────────────────────────────
        for col in ("source_lower", "target_lower"):
            if col not in existing:
                if dry_run:
                    logger.info("  [DRY-RUN] would ADD COLUMN %s TEXT", col)
                else:
                    con.execute(f"ALTER TABLE gvl_edges ADD COLUMN {col} TEXT")
                    logger.info("  added column %s", col)
                stats["columns_added"] += 1

        if dry_run:
            # Count how many rows need backfill
            total = con.execute("SELECT COUNT(*) FROM gvl_edges").fetchone()[0]
            if "source_lower" in existing:
                null_src = con.execute(
                    "SELECT COUNT(*) FROM gvl_edges "
                    "WHERE source_lower IS NULL AND source IS NOT NULL"
                ).fetchone()[0]
            else:
                null_src = total
            if "target_lower" in existing:
                null_tgt = con.execute(
                    "SELECT COUNT(*) FROM gvl_edges "
                    "WHERE target_lower IS NULL AND target IS NOT NULL"
                ).fetchone()[0]
            else:
                null_tgt = total
            logger.info(
                "  [DRY-RUN] would backfill %d source_lower + %d target_lower rows (of %d total)",
                null_src, null_tgt, total,
            )
            stats["rows_backfilled"] = null_src + null_tgt
            stats["indexes_created"] = 2
            return stats

        # ── Step 2: Backfill NULL rows ──────────────────────────────────
        t0 = time.monotonic()

        result_src = con.execute(
            "UPDATE gvl_edges SET source_lower = LOWER(source) "
            "WHERE source_lower IS NULL AND source IS NOT NULL"
        )
        result_tgt = con.execute(
            "UPDATE gvl_edges SET target_lower = LOWER(target) "
            "WHERE target_lower IS NULL AND target IS NOT NULL"
        )
        con.commit()

        backfilled = (result_src.rowcount or 0) + (result_tgt.rowcount or 0)
        stats["rows_backfilled"] = backfilled
        elapsed = time.monotonic() - t0

        if backfilled:
            logger.info(
                "  backfilled %d rows in %.1fs (source_lower=%d, target_lower=%d)",
                backfilled, elapsed, result_src.rowcount or 0, result_tgt.rowcount or 0,
            )
        else:
            logger.info("  all rows already populated — nothing to backfill")

        # ── Step 3: Create indexes ──────────────────────────────────────
        t1 = time.monotonic()

        con.execute(
            "CREATE INDEX IF NOT EXISTS ix_gvl_edges_job_src_lower "
            "ON gvl_edges(job_id, source_lower)"
        )
        con.execute(
            "CREATE INDEX IF NOT EXISTS ix_gvl_edges_job_tgt_lower "
            "ON gvl_edges(job_id, target_lower)"
        )
        con.commit()

        idx_elapsed = time.monotonic() - t1
        stats["indexes_created"] = 2
        logger.info("  indexes ensured in %.1fs", idx_elapsed)

        # ── Step 4: Verify ──────────────────────────────────────────────
        plan = con.execute(
            "EXPLAIN QUERY PLAN "
            "SELECT * FROM gvl_edges WHERE job_id = 'x' AND source_lower LIKE '%test%'"
        ).fetchall()
        uses_index = any("SEARCH" in str(row) for row in plan)
        if uses_index:
            logger.info("  ✓ query plan uses index (SEARCH)")
        else:
            logger.warning("  ✗ query plan still does SCAN — check index creation")

        return stats
    finally:
        con.close()


# ---------------------------------------------------------------------------
# Job discovery
# ---------------------------------------------------------------------------

def _find_index_dbs(jobs_base: Path) -> List[tuple]:
    """Return list of (job_id, db_path) for all jobs with an index.db."""
    results = []
    if not jobs_base.exists():
        return results
    for d in sorted(jobs_base.iterdir()):
        if d.is_dir():
            db = d / "index.db"
            if db.exists():
                results.append((d.name, db))
    return results


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def _parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description=(
            "Backfill source_lower/target_lower columns on existing "
            "gvl_edges tables for indexed LIKE queries."
        ),
    )
    target = p.add_mutually_exclusive_group(required=True)
    target.add_argument(
        "--job-id",
        metavar="JOB_ID",
        help="Backfill a single job by its ID.",
    )
    target.add_argument(
        "--all",
        action="store_true",
        help="Backfill every job found under JOBS_BASE_DIR.",
    )
    target.add_argument(
        "--db-path",
        metavar="PATH",
        help="Backfill a specific index.db file directly.",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Print what would be done without writing to the DB.",
    )
    p.add_argument(
        "--jobs-dir",
        metavar="PATH",
        help="Override JOBS_BASE_DIR from settings.",
    )
    p.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable DEBUG-level logging.",
    )
    return p.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = _parse_args(argv)

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # ── Resolve targets ────────────────────────────────────────────────
    if args.db_path:
        db_path = Path(args.db_path)
        if not db_path.exists():
            logger.error("File not found: %s", db_path)
            return 1
        targets = [("(direct)", db_path)]
    else:
        # Resolve jobs base directory
        if args.jobs_dir:
            jobs_base = Path(args.jobs_dir)
        else:
            try:
                from api.config import settings
                jobs_base = Path(settings.JOBS_BASE_DIR)
            except Exception as exc:
                logger.error("Cannot load api.config.settings: %s", exc)
                logger.error("Set JOBS_BASE_DIR via --jobs-dir or ensure .env is present.")
                return 1

        if not jobs_base.exists():
            logger.error("JOBS_BASE_DIR does not exist: %s", jobs_base)
            return 1

        if args.job_id:
            db = jobs_base / args.job_id / "index.db"
            if not db.exists():
                logger.error("index.db not found for job %s at %s", args.job_id, db)
                return 1
            targets = [(args.job_id, db)]
        else:
            targets = _find_index_dbs(jobs_base)
            if not targets:
                logger.warning("No index.db files found under %s", jobs_base)
                return 0
            logger.info("Found %d job database(s) to migrate", len(targets))

    # ── Run migration ──────────────────────────────────────────────────
    total_backfilled = 0
    total_columns = 0
    success = 0
    failed = 0

    t_start = time.monotonic()

    for job_id, db_path in targets:
        sz_mb = db_path.stat().st_size / (1024 ** 2)
        logger.info("[%s] migrating %s (%.1f MB)", job_id, db_path, sz_mb)
        try:
            stats = migrate_job(db_path, dry_run=args.dry_run)
            if not stats["skipped"]:
                total_backfilled += stats["rows_backfilled"]
                total_columns += stats["columns_added"]
                success += 1
            else:
                success += 1  # skip is not a failure
        except Exception:
            logger.exception("[%s] migration FAILED", job_id)
            failed += 1

    elapsed = time.monotonic() - t_start

    # ── Summary ────────────────────────────────────────────────────────
    total = success + failed
    logger.info("─" * 60)
    logger.info(
        "Migration complete in %.1fs: %d/%d jobs OK, %d columns added, %d rows backfilled%s",
        elapsed, success, total, total_columns, total_backfilled,
        " (dry run)" if args.dry_run else "",
    )
    if failed:
        logger.error("%d job(s) failed — check logs above", failed)
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
