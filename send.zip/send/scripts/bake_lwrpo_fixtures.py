#!/usr/bin/env python3
"""Transform the captured live API responses (scripts/_lwrpo_capture/*.json) into a
self-contained frontend fixtures module so the lwrpoDynamicCidMatchResponseInd
investigation works fully OFFLINE (REACT_APP_USE_MOCKS=true) — portable across
laptops, independent of any backend session id.

Emits: Zenflow_Frontend/src/api/mocks/lwrpoFixtures.js
Run:   python3 scripts/bake_lwrpo_fixtures.py
"""
from __future__ import annotations
import json
from pathlib import Path

CAP = Path(__file__).resolve().parent / "_lwrpo_capture"
OUT = Path("/Users/prathamgupta/Documents/Zenflow_Frontend/src/api/mocks/lwrpoFixtures.js")

CONV_ID = "demo-conv-lwrpo"
FLOW_ID = "demo-flow-lwrpo-aa71-dw730000-dw710000"


import re as _re

# Correct LLM hallucinations of UNVERIFIED concrete values. The setter assigns a
# named enum (Dynamic4cscMatchIndicators::Dynamic4cscMatchFound), NOT the literal
# '1'; exitIndicator/returnCode gates compare enums (Pa::Off / CreditApproved),
# not verified numerics. These regex replacements restore source-faithful wording.
_SANITIZE = [
    (_re.compile(r"to a value of '1'", _re.I),
     "to the value Dynamic4cscMatchFound (its 'dynamic 4CSC match found' indicator value)"),
    (_re.compile(r"to '1'(?=[\s,.\)])", _re.I), "to Dynamic4cscMatchFound"),
    (_re.compile(r"a value of '1'", _re.I), "the value Dynamic4cscMatchFound"),
    (_re.compile(r"value of '1'", _re.I), "value Dynamic4cscMatchFound"),
    (_re.compile(r"having a value of 0", _re.I), "being in its cleared 'off' state (Pa::Off)"),
    (_re.compile(r"a value of 0 indicates success", _re.I),
     "the success state (the prior step completed without error)"),
    # Pin obscure ASM-alias names to source-faithful forms (verified by ROLE, not
    # by guessing the acronym). The LLM used several inconsistent guesses for each.
    (_re.compile(r"System Visibility Indicator 1", _re.I), "CAS Vision Global Control Byte"),
    (_re.compile(r"Transaction Data Field GIND|Digital Wallet Indicator|Data Group Indicator", _re.I),
     "inbound GNA Balance-Transfer Indicator"),
    (_re.compile(r"Branch Indicator", _re.I), "Inbound Special-Routing Flag"),
    # Name-consistency: collapse every prose variant to the ONE canonical name.
    (_re.compile(r"Dynamic Customer Id Match Response Indicator", _re.I), "Dynamic CID Match Response Indicator"),
    (_re.compile(r"Last Token Source Indicator", _re.I), "Express-Pay Wallet Token Indicator"),
    (_re.compile(r"Express Pay Wallet Token Indicator", _re.I), "Express-Pay Wallet Token Indicator"),
    (_re.compile(r"Customer ID Inquiry Active Indicator", _re.I), "CID Inquiry Active Indicator"),
    (_re.compile(r"Dynamic Result Storage", _re.I), "Dynamic 4CSC (Card Security Code) Result"),
    (_re.compile(r"Dynamic 4CSC Result field", _re.I), "Dynamic 4CSC (Card Security Code) Result"),
    (_re.compile(r"the stored dynamic 4CSC result", _re.I), "the Dynamic 4CSC (Card Security Code) Result"),
    # code-anchored fixes
    (_re.compile(r"GNA Balance-Transfer Indicator \(L7DGIND\)", _re.I), "Inbound GNA Balance-Transfer Indicator (L7DGIND)"),
    (_re.compile(r"Special Routing Member \(SPECIALROUTINGMEMBER\)", _re.I), "Special Routing Member Indicator (SPECIALROUTINGMEMBER)"),
    (_re.compile(r"Special-Routing flag \(L7DBRN\)", _re.I), "Inbound Special-Routing Flag (L7DBRN)"),
    (_re.compile(r"Transactioncode \(BCIS\.TRANSACTIONCODE\)", _re.I), "Inbound Transaction Code (BCIS.TRANSACTIONCODE)"),
    (_re.compile(r"Transactioncode \(TRANSACTIONCODE\)", _re.I), "Transaction Code (TRANSACTIONCODE)"),
    # NOTE: do NOT add a bare \bTransactioncode\b rule — case-insensitively it
    # corrupts the node IDENTIFIER "TRANSACTIONCODE" into "Transaction Code".
    # Display variants are handled by the canonical business-name map instead.
    # Fix the wallet-token gate wrongly stated as an EXCLUSION (it is REQUIRED) and
    # the "digital wallet" mislabel, wherever they remain (rules, dep-var 'why').
    (_re.compile(r"The transaction must not originate from a digital wallet using a token\.?", _re.I),
     "The transaction must be an Express-Pay wallet-token transaction (Express-Pay Wallet Token Indicator, LSTKNPOA = 'Y')."),
    (_re.compile(r"It is checked to see if the transaction is from a digital wallet, which follows a different processing path\.?", _re.I),
     "It must be 'Y' — an Express-Pay wallet-token transaction — for the indicator to be set."),
    (_re.compile(r"from a digital wallet using a token", _re.I), "an Express-Pay wallet-token transaction"),
    (_re.compile(r"is from a digital wallet", _re.I), "is an Express-Pay wallet-token transaction"),
    # Strip technical struct-path prefixes from code names (e.g.
    # PLASTICAUTH.PROCESS.VARIOUS.EXITINDICATOR -> EXITINDICATOR) in captured text.
    (_re.compile(r"PLASTICAUTH\.PROCESS\.VARIOUS\.", _re.I), ""),
    (_re.compile(r"LWRCOMMON\.PROCESS\.LINKS\.", _re.I), ""),
    (_re.compile(r"\(EXITINDICATOR\) to be 0\b", _re.I), "(EXITINDICATOR) to be in its cleared 'off' state"),
]


# Per-variable content overrides — replace LLM narrative that drifted from the
# verified source semantics. LS4CSCRES is the dynamic 4-digit Card Security Code
# (4CSC) result on the LinkSource area; the setter requires it to equal "00"
# (a successful dynamic-CID 4CSC match) — it is NOT a "credit score" and the
# "00" is a match code, not an empty/zero area.
_VAR_OVERRIDES = {
    "LS4CSCRES": {
        "business_name": "Dynamic 4CSC (Card Security Code) Result",
        "headline": "The system checks the stored dynamic 4-digit Card Security Code (4CSC) result to confirm a successful match.",
        "explanation": (
            "Within the credit-transaction processing program, the system reads the "
            "stored dynamic 4CSC (4-digit Card Security Code) result from the LinkSource "
            "work area.\n\n"
            "*   This value is the Dynamic 4CSC (Card Security Code) Result (LS4CSCRES).\n"
            "*   **The setter requires this result to equal '00', which signals that the "
            "dynamic Customer ID 4CSC matched successfully.**\n"
            "*   Its value is produced upstream by the dynamic-CID / LinkSource pipeline "
            "and only read here — within this chain it is a terminal input."
        ),
        "condition": "Does the stored dynamic 4CSC result (LS4CSCRES) equal '00' (a successful match)?",
        "decides": "If it equals '00' the dynamic CID 4CSC matched and the response indicator can be set; otherwise the indicator is not set.",
        "why": ("The stored dynamic 4CSC (Card Security Code) result. It must equal '00' "
                "(a successful match) for the Dynamic CID Match Response Indicator to be set. "
                "It is a terminal input populated upstream by the dynamic-CID / LinkSource pipeline."),
        "description": ("The stored dynamic 4CSC (4-digit Card Security Code) result on the "
                        "LinkSource work area. '00' means the dynamic CID 4CSC matched. It is a "
                        "terminal input — populated upstream, only read in this chain."),
    },
}


# Concrete, source-faithful "SET TO" text for each setter node. The captured
# set_to_short fell back to the step headline (a purpose description), not the
# actual assigned value — these replace it with what the variable is really set to.
_SETTER_SET_TO = {
    "LWRPODYNAMICCIDMATCHRESPONSEIND":
        ("Set to the value 'Dynamic 4CSC Match Found' (Dynamic4cscMatchFound) — marking that the "
         "dynamic Customer ID 4-digit security code matched — in routine processACreditTransaction, "
         "once all the conditions below are satisfied."),
    "TRANSACTIONCODE":
        ("Set by copying the transaction code from the incoming credit-request message (BCIS field, "
         "ASM alias L7DTNC) into the working area, in routine movePaCommonFields — before the routing decision."),
    "GNABALXFERIND":
        ("Set by copying the balance-transfer flags from the incoming credit-request message "
         "(BCIS field, ASM alias L7DGIND) into the working area, in routine movePaCommonFields."),
    "SPECIALROUTINGMEMBER":
        ("Set by copying the special-routing flag from the incoming credit-request message "
         "(BCIS field, ASM alias L7DBRN) into the working area, in routine movePaCommonFields."),
    "EXITINDICATOR":
        ("Set to 'on' (Pa::On) by routine editInputMessageErrors when the transaction's return code is "
         "not 'credit approved' (an earlier edit/error occurred); otherwise it stays in its cleared 'off' state."),
}


# ONE canonical business name per variable (point 1: a variable has a single name
# everywhere — summary, steps, graph nodes). Source-faithful, by verified role.
_CANON = {
    "LWRPODYNAMICCIDMATCHRESPONSEIND": "Dynamic CID Match Response Indicator",
    "TRANSACTIONCODE": "Transaction Code",
    "BCIS.TRANSACTIONCODE": "Inbound Transaction Code",
    "GNABALXFERIND": "Balance Transfer Indicator",
    "L7DGIND": "Inbound GNA Balance-Transfer Indicator",
    "SPECIALROUTINGMEMBER": "Special Routing Member Indicator",
    "L7DBRN": "Inbound Special-Routing Flag",
    "EXITINDICATOR": "Exit Indicator",
    "RETURNCODE": "Return Code",
    "TABLECOLLECTEDINDICATOR": "Table Collected Indicator",
    "LSTKNPOA": "Express-Pay Wallet Token Indicator",
    "LS4CSCRES": "Dynamic 4CSC (Card Security Code) Result",
    "CARVERACTIVE": "Carver Active Indicator",
    "CIDINQUIRYACTIVE": "CID Inquiry Active Indicator",
    "@CASVIS1": "CAS Vision Global Control Byte",
    "L7DSTS": "Transaction Status",
}

# Deterministic, source-faithful summary (replaces LLM prose that mis-stated
# semantics — e.g. wrongly listing the wallet-token gate as an EXCLUSION and
# mislabeling L7DGIND as a "digital wallet" field). Uses canonical names only.
_SUMMARY_OVERRIDE = {
    "what_it_is": (
        "The Dynamic CID Match Response Indicator (LWRPODYNAMICCIDMATCHRESPONSEIND) records the "
        "outcome of the dynamic Customer ID 4-digit card security code (4CSC) check for an "
        "Express-Pay / wallet-token credit transaction. When set to 'Dynamic4cscMatchFound' it "
        "means the transaction's dynamic 4CSC matched the stored value — confirming the card "
        "security check for that transaction, used downstream for authorization and fraud handling."
    ),
    "how_it_is_set": (
        "The indicator is set in the Plastic Authentication component (routine "
        "processACreditTransaction in dw710000), reached via the chain "
        "aa71 → dw730000 (DW73 inquiry pipeline) → dw710000.\n\n"
        "*   It is set to the value Dynamic4cscMatchFound (its 'dynamic 4CSC match found' value).\n"
        "*   This happens only for an Express-Pay / wallet-token transaction whose stored "
        "dynamic 4CSC result equals '00' (a match)."
    ),
    "what_had_to_be_true": (
        "*   CID inquiry must be globally active — CAS Vision Global Control Byte (@CASVIS1), bit X'01'.\n"
        "*   The request must be an 8001 CID-inquiry transaction — Transaction Status (L7DSTS), bit X'40'.\n"
        "*   The Carver validation engine must be active — Carver Active Indicator (CARVERACTIVE).\n"
        "*   CID-inquiry processing must be enabled — CID Inquiry Active Indicator (CIDINQUIRYACTIVE).\n"
        "*   The transaction must be a credit-authorization request — Transaction Code "
        "(TRANSACTIONCODE) is CreditRequest, WorkedFromReferralQue, ForceEntryToRefer or ForceEntryToAA.\n"
        "*   CID validation must not have already run — Table Collected Indicator "
        "(TABLECOLLECTEDINDICATOR) is in its default (uncollected) state.\n"
        "*   No earlier error / early-exit — Exit Indicator "
        "(EXITINDICATOR) is in its cleared 'off' state (Pa::Off).\n"
        "*   The transaction must NOT be a balance transfer — Balance Transfer Indicator (GNABALXFERIND).\n"
        "*   The transaction must NOT be specially routed — Special Routing Member Indicator (SPECIALROUTINGMEMBER).\n"
        "*   The transaction MUST be an Express-Pay wallet-token transaction — Express-Pay Wallet "
        "Token Indicator (LSTKNPOA) equals 'Y'.\n"
        "*   The stored dynamic 4CSC result MUST equal '00' (a match) — Dynamic 4CSC "
        "(Card Security Code) Result (LS4CSCRES)."
    ),
    "dependent_variables_story": (
        "*   **CAS Vision Global Control Byte (@CASVIS1):** system-wide configuration global; "
        "set by system configuration, read-only here (terminal input).\n"
        "*   **Transaction Status (L7DSTS):** inbound transaction-status byte; set by upstream "
        "message routing (terminal input).\n"
        "*   **Carver Active Indicator (CARVERACTIVE) / CID Inquiry Active Indicator (CIDINQUIRYACTIVE):** "
        "fields of the CAS Vision global (same storage as @CASVIS1); system configuration (terminal).\n"
        "*   **Transaction Code (TRANSACTIONCODE):** copied from the Inbound Transaction Code "
        "(BCIS.transactionCode, ASM alias L7DTNC) in routine movePaCommonFields (dw710100); the "
        "inbound value originates outside this chain.\n"
        "*   **Table Collected Indicator (TABLECOLLECTEDINDICATOR):** reaches this point in its "
        "cleared work-area state (no in-scope business setter).\n"
        "*   **Exit Indicator (EXITINDICATOR):** set 'on' by routine editInputMessageErrors when "
        "the Return Code is not 'credit approved'; otherwise stays 'off'.\n"
        "*   **Return Code (RETURNCODE):** the ECB return/result code; set by the surrounding "
        "pipeline outside this chain (terminal).\n"
        "*   **Balance Transfer Indicator (GNABALXFERIND):** copied from the Inbound GNA "
        "Balance-Transfer Indicator (BCIS, ASM alias L7DGIND) in movePaCommonFields.\n"
        "*   **Special Routing Member Indicator (SPECIALROUTINGMEMBER):** copied from the Inbound "
        "Special-Routing Flag (BCIS, ASM alias L7DBRN) in movePaCommonFields.\n"
        "*   **Express-Pay Wallet Token Indicator (LSTKNPOA)** and **Dynamic 4CSC (Card Security "
        "Code) Result (LS4CSCRES):** fields of the LinkSource work area, populated upstream by the "
        "dynamic-CID / LinkSource builder (outside this chain — terminal inputs)."
    ),
    "chain_narrative": (
        "The transaction flows aa71 → dw730000 (DW73 inquiry pipeline) → dw710000 "
        "(Plastic Authentication), where the indicator is set."
    ),
    "full_story": (
        "The system sets the Dynamic CID Match Response Indicator (LWRPODYNAMICCIDMATCHRESPONSEIND) "
        "to record that an Express-Pay / wallet-token transaction's dynamic 4-digit card security "
        "code (4CSC) matched.\n\n"
        "*   Processing starts in the entry program (aa71): it confirms CID inquiry is globally "
        "active (CAS Vision Global Control Byte, @CASVIS1) and that this is an 8001 CID-inquiry "
        "transaction (Transaction Status, L7DSTS), then enters the inquiry pipeline (DW73).\n"
        "*   In the inquiry pipeline (dw730000 / DW73): it confirms the Carver engine and "
        "CID-inquiry processing are active (Carver Active Indicator, CID Inquiry Active Indicator) "
        "and the required work areas are present, then calls Plastic Authentication (dw710000).\n"
        "*   In Plastic Authentication (dw710000): it confirms the transaction is a credit-"
        "authorization request (Transaction Code), that CID validation has not already run (Table "
        "Collected Indicator), and that there is no prior error (Exit Indicator). It then excludes "
        "balance-transfer transactions (Balance Transfer Indicator) and specially-routed "
        "transactions (Special Routing Member Indicator).\n"
        "*   For an Express-Pay wallet-token transaction (Express-Pay Wallet Token Indicator, "
        "LSTKNPOA = 'Y') it reads the stored dynamic 4CSC result (Dynamic 4CSC (Card Security Code) "
        "Result, LS4CSCRES). If that result equals '00' the dynamic 4CSC matched, and the program "
        "sets the indicator to Dynamic4cscMatchFound — recording the successful 4CSC match."
    ),
}


def _dedupe_self(var, deps):
    """Drop a dep-var entry that just repeats its own variable name."""
    return [d for d in (deps or []) if (d.get("name") or "").upper() != (var or "").upper()]


def _apply_overrides(steps, gvars):
    # Fix "SET TO" text + remove self-references on every setter node.
    for var, txt in _SETTER_SET_TO.items():
        if var in gvars and gvars[var].get("set_to_short"):
            gvars[var]["set_to"] = txt
            gvars[var]["set_to_short"] = txt
    for var, d in gvars.items():
        d["dependent_variables"] = _dedupe_self(var, d.get("dependent_variables"))
    for st in steps:
        st["dependent_variables"] = _dedupe_self(st.get("variable_in_step"), st.get("dependent_variables"))

    for st in steps:
        ov = _VAR_OVERRIDES.get((st.get("variable_in_step") or "").upper())
        if not ov:
            continue
        st["headline"] = ov["headline"]
        st["explanation"] = ov["explanation"]
        st["conditions"] = [{"check": "", "in_plain_terms": ov["condition"], "decides": ov["decides"]}]
        st["dependent_variables"] = [{
            "name": st.get("variable_in_step"),
            "business_name": ov["business_name"],
            "why_it_was_traced": ov["why"],
        }]
    for var, ov in _VAR_OVERRIDES.items():
        if var in gvars:
            gvars[var]["business_name"] = ov["business_name"]
            gvars[var]["description"] = ov["description"]

    # Enforce ONE canonical business name per variable, everywhere.
    for var, name in _CANON.items():
        if var in gvars:
            gvars[var]["business_name"] = name
        for d in (gvars.get(var, {}).get("dependent_variables") or []):
            nm = (d.get("name") or "").upper()
            if nm in _CANON:
                d["business_name"] = _CANON[nm]
    for st in steps:
        sv = (st.get("variable_in_step") or "").upper()
        if sv in _CANON:
            st["variable_business_name"] = _CANON[sv]
        for d in (st.get("dependent_variables") or []):
            nm = (d.get("name") or "").upper()
            if nm in _CANON:
                d["business_name"] = _CANON[nm]

    # Correct inverted conditions, then rebuild the "Conditions to reach the
    # setter" markdown from the clean conditions (drop raw scaffold text).
    for st in steps:
        key = (st.get("file_stem") or "", (st.get("variable_in_step") or "").upper())
        if key in _STEP_COND_OVERRIDE:
            st["conditions"] = [dict(c) for c in _STEP_COND_OVERRIDE[key]]
        st["setter_conditions"] = _clean_setter_conditions(st)
    return steps, gvars


# Correct conditions for the aa71 entry step (LLM had the branch logic INVERTED:
# bit-on actually means "active → continue", not "not active → skip").
_STEP_COND_OVERRIDE = {
    ("aa71", "LWRPODYNAMICCIDMATCHRESPONSEIND"): [
        {"in_plain_terms": "CID inquiry must be globally active — the CAS Vision Global Control Byte (@CASVIS1) has bit X'01' on.",
         "decides": "If it is on, processing continues into the inquiry pipeline; if off, the pipeline is skipped."},
        {"in_plain_terms": "The request must be an 8001 CID-inquiry transaction — the Transaction Status (L7DSTS) has bit X'40' on.",
         "decides": "If it is on, the inquiry pipeline is entered; if off, it is skipped."},
        {"in_plain_terms": "No earlier bypass was taken — not a fraud-SE case, not a franchise card, not a non-auth reroute, and no prior errors.",
         "decides": "If any bypass applies, the inquiry pipeline is not entered."},
    ],
}


def _clean_setter_conditions(step):
    """Rebuild the 'Conditions to reach the setter' markdown from the CLEAN
    business-language conditions, so no raw scaffold text (TM/X'..'/checks `..`)
    leaks into the UI."""
    conds = step.get("conditions") or []
    if not conds:
        return ""
    fstem = step.get("file_stem", "")
    ftype = step.get("file_type", "asm")
    out = [f"#### Conditions to reach the setter in `{fstem}.{ftype}`", ""]
    for c in conds:
        t = (c.get("in_plain_terms") or c.get("check") or "").strip()
        if not t:
            continue
        d = (c.get("decides") or "").strip()
        out.append(f"- **{t}**" + (f" — {d}" if d else ""))
    return "\n".join(out)


# Accurate terminal-role per variable (badge on graph nodes). Inbound message /
# LinkSource work-area fields = input; system globals & work-area control = system.
_ROLE = {
    "TRANSACTIONCODE": "input", "BCIS.TRANSACTIONCODE": "input",
    "GNABALXFERIND": "input", "L7DGIND": "input",
    "SPECIALROUTINGMEMBER": "input", "L7DBRN": "input",
    "L7DSTS": "input", "LSTKNPOA": "input", "LS4CSCRES": "input",
    "@CASVIS1": "system", "CARVERACTIVE": "system", "CIDINQUIRYACTIVE": "system",
    "TABLECOLLECTEDINDICATOR": "system", "EXITINDICATOR": "system", "RETURNCODE": "system",
}


def _apply_graph(summary):
    """Set accurate terminal_role badges on the variable-lineage nodes (and keep
    node IDs as canonical codes)."""
    vl = summary.get("variable_lineage") or {}
    for n in (vl.get("nodes") or []):
        nid = (n.get("id") or "").upper()
        if n.get("type") == "root":
            continue
        if nid in _ROLE:
            n["terminal_role"] = _ROLE[nid]
    return summary


def _apply_summary(summary):
    """Replace LLM summary sections with the deterministic, source-faithful text;
    canonicalize variable_summary business names."""
    for k, v in _SUMMARY_OVERRIDE.items():
        summary[k] = v
    # also fold the new full_story into `explanation` if the UI reads that field
    if "explanation" in summary:
        summary["explanation"] = _SUMMARY_OVERRIDE["full_story"]
    for row in (summary.get("variable_summary") or []):
        nm = (row.get("variable") or "").upper()
        if nm in _CANON:
            row["business_name"] = _CANON[nm]
    return summary


def _sanitize(obj):
    """Recursively apply hallucination fixes to every string in a JSON structure."""
    if isinstance(obj, str):
        out = obj
        for pat, repl in _SANITIZE:
            out = pat.sub(repl, out)
        return out
    if isinstance(obj, list):
        return [_sanitize(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _sanitize(v) for k, v in obj.items()}
    return obj


def main():
    kff = json.loads((CAP / "keyword_file_flows.json").read_text())
    summary = _sanitize(json.loads((CAP / "summary.json").read_text()))
    steps = _sanitize(json.loads((CAP / "steps.json").read_text()))
    gvars = _sanitize(json.loads((CAP / "graph_variables.json").read_text()))
    meta = json.loads((CAP / "meta.json").read_text())
    steps, gvars = _apply_overrides(steps, gvars)
    summary = _apply_summary(summary)
    summary = _apply_graph(summary)

    # Keep ONLY the target flow (aa71 -> dw730000 -> dw710000) so the demo UI
    # offers exactly one selectable path and traversal is limited to it.
    real_flow_id = meta["flow_id"]
    all_flows = kff.get("keyword_file_flows", [])
    target = [f for f in all_flows
              if (f.get("id") or f.get("keyword_file_flow_id")) == real_flow_id]
    if not target:
        raise SystemExit(f"target flow {real_flow_id} not found in captured KFF")
    tf = target[0]
    tf["id"] = FLOW_ID
    tf["keyword_file_flow_id"] = FLOW_ID
    kff["keyword_file_flows"] = [tf]
    # Recompute the overview counters so the UI header matches the single flow.
    kff["total"] = 1
    kff["has_more"] = False
    kff["direct_flows"] = 1 if len(tf.get("chain") or []) <= 1 else 0
    chain_stems = [(c.get("file") if isinstance(c, dict) else c) for c in (tf.get("chain") or [])]
    kff["file_count"] = len({str(s).replace(".asm", "").replace(".cpp", "") for s in chain_stems})

    # Upper-case the graph-variable detail keys (adapter looks up by UPPERCASE name).
    gvars_upper = {str(k).upper(): v for k, v in gvars.items()}

    # Edge "Code conditions" (per call-edge guard chain) — hand-authored from the
    # verified lineage (see docs/LWRPO_lineage_review.md). Keyed "caller|callee".
    edge_conditions = {
        "aa71|dw730000": {
            "caller": "aa71", "callee": "dw730000", "pattern": "ASM->CPP",
            "call_sites": [{
                "call_line": 2016, "call_instruction": "ENTRC",
                "conditions": [
                    {"condition": "@CASVIS1 & X'01' ON  (CID inquiry globally active)", "line_no": 2008, "opcode": "TM"},
                    {"condition": "L7DSTS & X'40' ON  (8001 CID-inquiry transaction)", "line_no": 2012, "opcode": "TM"},
                ],
            }],
        },
        "dw730000|dw710000": {
            "caller": "dw730000", "callee": "dw710000", "pattern": "CPP->CPP",
            "call_sites": [{
                "call_line": 106, "call_instruction": "callPlasticAuthenticationComponentInterface",
                "conditions": [
                    {"condition": "casVision1->carverActive == 1", "line_no": 57, "opcode": "if"},
                    {"condition": "casVision1->cidInquiryActive == 1", "line_no": 58, "opcode": "if"},
                    {"condition": "callCoreCarver() returns registers.r1 > 0  (init, CCR-addr, spec-addr setup all succeed)", "line_no": 63, "opcode": "if"},
                    {"condition": "addresses->plasticAuthOnlyArea != 0 && commonWorkArea != 0 && isoArea != 0 && bcis != 0 && ccr != 0", "line_no": 93, "opcode": "if"},
                ],
            }],
        },
    }
    edge_prose = {
        "aa71|dw730000": ("IF\n  CID Inquiry is globally active (@CASVIS1 bit X'01' on)\n"
                          "  AND this is an 8001 CID-inquiry transaction (L7DSTS bit X'40' on)\n"
                          "THEN aa71 enters the inquiry pipeline (ENTRC DW73)."),
        "dw730000|dw710000": ("IF\n  the Carver engine is active (carverActive == 1)\n"
                              "  AND CID inquiry processing is enabled (cidInquiryActive == 1)\n"
                              "  AND the three Carver setup calls succeed\n"
                              "  AND all required work-area pointers are present\n"
                              "THEN dw730000 hands the transaction to dw710000 (Plastic Authentication)."),
    }

    js = f"""// AUTO-GENERATED by scripts/bake_lwrpo_fixtures.py — do not edit by hand.
// Offline demo fixtures for lwrpoDynamicCidMatchResponseInd on the path
// aa71 -> dw730000 -> dw710000. Captured from the live backend (grounded in the
// hand-traced lineage in scripts/build_mock_lwrpo_session.py) and frozen here so
// the UI works fully offline (REACT_APP_USE_MOCKS=true), portable across machines.

export const DEMO_LWRPO_CONV_ID = {json.dumps(CONV_ID)};
export const DEMO_LWRPO_FLOW_ID = {json.dumps(FLOW_ID)};
export const DEMO_LWRPO_VARIABLE = {json.dumps(meta["variable"])};
export const DEMO_LWRPO_KEYWORD = {json.dumps(meta["variable"].upper())};
export const DEMO_LWRPO_CHAIN = {json.dumps(meta["chain"])};

export const LWRPO_KFF = {json.dumps(kff, indent=2)};

export const LWRPO_SUMMARY = {json.dumps(summary, indent=2)};

export const LWRPO_STEPS = {json.dumps(steps, indent=2)};

export const LWRPO_GRAPH_VARIABLE_DETAILS = {json.dumps(gvars_upper, indent=2)};

export const LWRPO_EDGE_CONDITIONS = {json.dumps(edge_conditions, indent=2)};

export const LWRPO_EDGE_PROSE = {json.dumps(edge_prose, indent=2)};
"""
    OUT.write_text(js)
    print("wrote", OUT)
    print(f"  flows : {len(kff.get('keyword_file_flows', []))}  (target flow id -> {FLOW_ID})")
    print(f"  steps : {len(steps)}")
    print(f"  graph-var details : {len(gvars_upper)}")
    print(f"  conv  : {CONV_ID}")


if __name__ == "__main__":
    main()
