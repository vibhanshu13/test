#!/usr/bin/env python3
"""Generate .bpidx sidecar files for existing legacy-format blueprints.

Background
----------
``write_blueprint()`` in ``blueprint_io.py`` writes blueprints as seekable
per-key zstd frames with a companion ``.bpidx`` index.  When a ``.bpidx``
exists, ``load_blueprint()`` returns a ``LazyBlueprint`` proxy that loads each
top-level key (``blocks``, ``call_graph``, ``variable_lineage``, …) only on
first access instead of decompressing the full 12–15 MB file.

Blueprints generated **before** this format was introduced are stored as
legacy monolithic compressed files with no ``.bpidx``.  This script converts
them in-place: it reads the legacy file, rewrites it as seekable frames, and
writes the ``.bpidx`` sidecar.  The conversion is idempotent — files that
already have a ``.bpidx`` are skipped.

Usage
-----
# Dry run — report what would change, write nothing:
python scripts/generate_bpidx.py --blueprint-dir jobs/<id>/output/asm --dry-run

# Convert one blueprint directory (all *.asm.json / *.cpp.json / *.mac.json):
python scripts/generate_bpidx.py --blueprint-dir jobs/<id>/output/asm

# Convert every blueprint directory under JOBS_BASE_DIR:
python scripts/generate_bpidx.py --all-jobs

# Limit to a specific job:
python scripts/generate_bpidx.py --job-id c68d392b-...

# Override the jobs base directory (defaults to api.config.settings.JOBS_BASE_DIR):
python scripts/generate_bpidx.py --all-jobs --jobs-dir /var/asm-jobs
"""
from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path
from typing import List, Optional

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(message)s",
    level=logging.INFO,
    stream=sys.stdout,
)
logger = logging.getLogger("generate_bpidx")

# Blueprint file extensions to convert.
_BP_EXTS = ("*.asm.json", "*.cpp.json", "*.mac.json")

# Keys that are injected at read-time and must NOT be written to disk.
_INJECTED_KEYS = frozenset(
    {"_gvl_path", "_gvl_db_path", "_gvl_job_id", "global_variable_lineage"}
)


def _convert_file(bp_path: Path, dry_run: bool) -> Optional[tuple]:
    """Convert one blueprint from legacy to seekable format.

    Returns ``(before_bytes, after_bytes)`` on success, ``None`` on skip/error.
    """
    sidecar = Path(str(bp_path) + ".bpidx")
    if sidecar.exists():
        logger.debug("  skip (already has .bpidx): %s", bp_path.name)
        return None

    before_bytes = bp_path.stat().st_size

    try:
        from blueprint_io import load_blueprint, write_blueprint
    except ImportError as exc:
        logger.error("  cannot import blueprint_io: %s", exc)
        return None

    # Load clean data (skip_global_lineage=True → no LazyGVL injected).
    try:
        bp = load_blueprint(bp_path, skip_global_lineage=True)
    except Exception as exc:
        logger.warning("  load failed for %s: %s", bp_path.name, exc)
        return None

    # Strip any keys that must not land on disk.
    for k in list(bp.keys()):
        if k in _INJECTED_KEYS:
            del bp[k]

    if dry_run:
        key_count = len(bp)
        logger.info("  [dry-run] would convert %s (%d KB, %d keys)",
                    bp_path.name, before_bytes // 1024, key_count)
        return (before_bytes, before_bytes)  # no write; return original size twice

    try:
        write_blueprint(bp_path, bp)
    except Exception as exc:
        logger.error("  write failed for %s: %s", bp_path.name, exc)
        return None

    after_bytes = bp_path.stat().st_size
    return (before_bytes, after_bytes)


def convert_directory(
    blueprint_dir: Path,
    dry_run: bool = False,
    verbose: bool = False,
) -> dict:
    """Convert all legacy blueprints in *blueprint_dir*.

    Returns a summary dict with keys: converted, skipped, errors,
    before_total_mb, after_total_mb.
    """
    if not blueprint_dir.is_dir():
        logger.error("Not a directory: %s", blueprint_dir)
        return {"converted": 0, "skipped": 0, "errors": 0,
                "before_total_mb": 0.0, "after_total_mb": 0.0}

    blueprints: List[Path] = []
    for ext in _BP_EXTS:
        blueprints.extend(blueprint_dir.glob(ext))
    blueprints.sort()

    if not blueprints:
        logger.info("No blueprint files found in %s", blueprint_dir)
        return {"converted": 0, "skipped": 0, "errors": 0,
                "before_total_mb": 0.0, "after_total_mb": 0.0}

    logger.info(
        "Found %d blueprint file(s) in %s%s",
        len(blueprints), blueprint_dir,
        " [DRY RUN]" if dry_run else "",
    )

    converted = skipped = errors = 0
    before_total = after_total = 0

    t0 = time.monotonic()
    for i, bp_path in enumerate(blueprints, 1):
        if verbose or i % 100 == 0:
            elapsed = time.monotonic() - t0
            logger.info("  [%d/%d] %s (%.1fs elapsed)",
                        i, len(blueprints), bp_path.name, elapsed)

        result = _convert_file(bp_path, dry_run=dry_run)
        if result is None:
            sidecar = Path(str(bp_path) + ".bpidx")
            if sidecar.exists():
                skipped += 1
            else:
                errors += 1
        else:
            before_b, after_b = result
            before_total += before_b
            after_total += after_b
            converted += 1
            if verbose and not dry_run:
                logger.info(
                    "  converted %s: %d KB → %d KB",
                    bp_path.name, before_b // 1024, after_b // 1024,
                )

    elapsed = time.monotonic() - t0
    before_mb = before_total / (1024 * 1024)
    after_mb = after_total / (1024 * 1024)

    logger.info(
        "%s %d file(s) in %.1fs  |  before %.1f MB → after %.1f MB  |  "
        "skipped %d  errors %d",
        "Would convert" if dry_run else "Converted",
        converted, elapsed, before_mb, after_mb, skipped, errors,
    )

    return {
        "converted": converted,
        "skipped": skipped,
        "errors": errors,
        "before_total_mb": before_mb,
        "after_total_mb": after_mb,
    }


def _job_blueprint_dirs(job_dir: Path) -> List[Path]:
    """Return the likely blueprint subdirectories for a job."""
    candidates = [
        job_dir / "output" / "asm",
        job_dir / "output",
    ]
    return [p for p in candidates if p.is_dir()]


def _parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Generate .bpidx sidecars for legacy blueprint files.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    target = p.add_mutually_exclusive_group(required=True)
    target.add_argument(
        "--blueprint-dir", metavar="DIR",
        help="Convert all blueprints in this directory.",
    )
    target.add_argument(
        "--job-id", metavar="JOB_ID",
        help="Convert blueprints for a single job (looks up JOBS_BASE_DIR).",
    )
    target.add_argument(
        "--all-jobs", action="store_true",
        help="Convert blueprints for every job under JOBS_BASE_DIR.",
    )
    p.add_argument(
        "--jobs-dir", metavar="PATH",
        help="Override JOBS_BASE_DIR from api.config.settings.",
    )
    p.add_argument(
        "--dry-run", action="store_true",
        help="Report what would change but do not write anything.",
    )
    p.add_argument(
        "-v", "--verbose", action="store_true",
        help="Log each converted file.",
    )
    return p.parse_args(argv)


def main(argv=None) -> int:
    args = _parse_args(argv)
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Verify required libraries are available.
    try:
        import zstandard  # noqa: F401
        import msgpack    # noqa: F401
    except ImportError as exc:
        logger.error(
            "Required library missing: %s\n"
            "Install with: pip install zstandard msgpack",
            exc,
        )
        return 1

    # ── Single directory mode ──────────────────────────────────────────────
    if args.blueprint_dir:
        result = convert_directory(
            Path(args.blueprint_dir),
            dry_run=args.dry_run,
            verbose=args.verbose,
        )
        return 0 if result["errors"] == 0 else 1

    # ── Job-based modes (require JOBS_BASE_DIR) ───────────────────────────
    if args.jobs_dir:
        jobs_base = Path(args.jobs_dir)
    else:
        try:
            from api.config import settings
            jobs_base = Path(settings.JOBS_BASE_DIR)
        except Exception as exc:
            logger.error(
                "Cannot load api.config.settings: %s\n"
                "Pass --jobs-dir or ensure .env is present.",
                exc,
            )
            return 1

    if not jobs_base.exists():
        logger.error("JOBS_BASE_DIR does not exist: %s", jobs_base)
        return 1

    if args.job_id:
        job_ids = [args.job_id]
    else:
        job_ids = sorted(
            d.name for d in jobs_base.iterdir()
            if d.is_dir()
        )
        if not job_ids:
            logger.warning("No job directories found under %s", jobs_base)
            return 0
        logger.info("Found %d job directory/ies", len(job_ids))

    total_converted = total_errors = 0
    for job_id in job_ids:
        job_dir = jobs_base / job_id
        bp_dirs = _job_blueprint_dirs(job_dir)
        if not bp_dirs:
            logger.debug("[%s] no blueprint subdirectories found", job_id)
            continue
        for bp_dir in bp_dirs:
            logger.info("[%s] processing %s", job_id, bp_dir)
            result = convert_directory(bp_dir, dry_run=args.dry_run, verbose=args.verbose)
            total_converted += result["converted"]
            total_errors += result["errors"]

    logger.info(
        "Done — %d file(s) %s, %d error(s)",
        total_converted,
        "would be converted" if args.dry_run else "converted",
        total_errors,
    )
    return 0 if total_errors == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
