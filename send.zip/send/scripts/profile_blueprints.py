#!/usr/bin/env python3
"""Profile per-file blueprints to characterize a corpus.

Walks a directory of *.asm.json / *.cpp.json / *.mac.json / *.hpp.json
blueprints and prints aggregate stats (median/p95/p99/max) for the
metrics that drive the backward-lineage-facts design:
    - blocks per file, flow entries per block
    - variable_lineage nodes/edges per file
    - setter-site count per file (relation in {assign, define, set, write})
    - dep-var fan-out per setter site (distinct sources)
    - call-graph nodes/edges per file
    - file_call_graph.json / global_variable_lineage.json sizes if found

Resumable: writes one JSON line per processed blueprint to a tmp file.
Re-run with the same --resume-file to skip already-done files.

Usage:
    python3 profile_blueprints.py <blueprint_dir> [--workers N] [--report report.txt]

Stdlib-only, safe to run on a production env (read-only).
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

BLUEPRINT_SUFFIXES = (".asm.json", ".cpp.json", ".mac.json", ".hpp.json")
SETTER_RELATIONS = {"assign", "define", "set", "write", "store"}


def percentile(sorted_vals, pct):
    if not sorted_vals:
        return 0
    idx = min(len(sorted_vals) - 1, int(len(sorted_vals) * pct))
    return sorted_vals[idx]


def profile_one(path_str):
    path = Path(path_str)
    try:
        size = path.stat().st_size
        with path.open("r", encoding="utf-8", errors="replace") as f:
            bp = json.load(f)
    except Exception as e:
        return {"path": path_str, "error": repr(e)[:300], "size_bytes": -1}

    blocks = bp.get("blocks") or []
    n_blocks = len(blocks)
    flow_lens = [len(b.get("flow") or []) for b in blocks]
    total_flow = sum(flow_lens)
    max_flow = max(flow_lens) if flow_lens else 0
    cfg_in_edges = sum(len(b.get("incoming_branches") or []) for b in blocks)

    vl = bp.get("variable_lineage") or {}
    vl_nodes = vl.get("nodes") or []
    vl_edges = vl.get("edges") or []

    rel_counter = Counter()
    setter_sources = defaultdict(set)
    for e in vl_edges:
        rel = (e.get("relation") or "?").lower()
        rel_counter[rel] += 1
        if rel in SETTER_RELATIONS:
            key = (e.get("target") or "", e.get("line"))
            src = e.get("source")
            if src:
                setter_sources[key].add(src)

    n_setters = len(setter_sources)
    fanouts = [len(s) for s in setter_sources.values()]
    fanout_max = max(fanouts) if fanouts else 0
    fanout_mean = (sum(fanouts) / len(fanouts)) if fanouts else 0
    fanout_p95 = percentile(sorted(fanouts), 0.95)

    cg = bp.get("call_graph") or {}
    cg_nodes = cg.get("nodes") or []
    cg_edges = cg.get("edges") or []

    subs = bp.get("subroutines") or []

    name = path.name
    file_type = "asm" if name.endswith(".asm.json") or name.endswith(".mac.json") else "cpp"

    return {
        "path": path_str,
        "name": name,
        "file_type": file_type,
        "size_bytes": size,
        "n_blocks": n_blocks,
        "total_flow_entries": total_flow,
        "max_flow_per_block": max_flow,
        "cfg_incoming_edges": cfg_in_edges,
        "n_vl_nodes": len(vl_nodes),
        "n_vl_edges": len(vl_edges),
        "rel_counts": dict(rel_counter),
        "n_setter_sites": n_setters,
        "setter_fanout_max": fanout_max,
        "setter_fanout_mean": round(fanout_mean, 2),
        "setter_fanout_p95": fanout_p95,
        "n_subroutines": len(subs),
        "n_cg_nodes": len(cg_nodes),
        "n_cg_edges": len(cg_edges),
    }


def find_job_files(bp_dir: Path):
    info = {}
    candidates = ["global_variable_lineage.json", "file_call_graph.json"]
    search_roots = [bp_dir, bp_dir.parent, bp_dir.parent.parent]
    for name in candidates:
        found = None
        for root in search_roots:
            try:
                for p in root.rglob(name):
                    found = p
                    break
            except Exception:
                continue
            if found:
                break
        if not found:
            info[name] = {"status": "not_found"}
            continue
        try:
            size = found.stat().st_size
        except Exception:
            info[name] = {"status": "stat_failed"}
            continue
        entry = {"path": str(found), "size_bytes": size}
        size_mb = size / (1024 * 1024)
        if size_mb < 500:
            try:
                with found.open("r", encoding="utf-8", errors="replace") as f:
                    d = json.load(f)
                if isinstance(d, dict):
                    if isinstance(d.get("nodes"), list):
                        entry["n_nodes"] = len(d["nodes"])
                    if isinstance(d.get("edges"), list):
                        entry["n_edges"] = len(d["edges"])
                    if isinstance(d.get("files"), (list, dict)):
                        entry["n_files"] = len(d["files"])
            except Exception as e:
                entry["load_error"] = repr(e)[:200]
        else:
            entry["note"] = f"skipped full load (size {size_mb:.0f} MB)"
        info[name] = entry
    return info


def discover_blueprints(bp_dir: Path):
    out = []
    for p in bp_dir.rglob("*.json"):
        n = p.name
        if not n.endswith(BLUEPRINT_SUFFIXES):
            continue
        out.append(str(p))
    return out


def stats_line(label, getter, rows):
    vals = []
    for r in rows:
        v = getter(r)
        if v is not None:
            vals.append(v)
    if not vals:
        return f"  {label:28s}  n=0"
    vals.sort()
    n = len(vals)
    return (
        f"  {label:28s}  n={n:5d}"
        f"  min={vals[0]:>8.0f}"
        f"  med={vals[n // 2]:>8.0f}"
        f"  mean={sum(vals) / n:>10.1f}"
        f"  p95={percentile(vals, 0.95):>8.0f}"
        f"  p99={percentile(vals, 0.99):>8.0f}"
        f"  max={vals[-1]:>10.0f}"
    )


def aggregate(rows, job_info, bp_dir, total_discovered, elapsed):
    by_type = defaultdict(list)
    for r in rows:
        if "error" in r:
            continue
        by_type[r.get("file_type", "unknown")].append(r)

    rel_totals = Counter()
    for r in rows:
        for k, v in (r.get("rel_counts") or {}).items():
            rel_totals[k] += v

    out = []
    out.append("=" * 100)
    out.append(f"Blueprint corpus profile")
    out.append("=" * 100)
    out.append(f"Directory      : {bp_dir}")
    out.append(f"Discovered     : {total_discovered} blueprints")
    out.append(f"Profiled OK    : {sum(len(v) for v in by_type.values())}")
    out.append(f"Errors         : {sum(1 for r in rows if 'error' in r)}")
    out.append(f"Elapsed (this run): {elapsed:.1f}s")
    out.append("")

    for typ in sorted(by_type.keys()):
        group = by_type[typ]
        out.append(f"--- {typ.upper()} ({len(group)} files) ---")
        out.append(stats_line("size_bytes",          lambda r: r["size_bytes"], group))
        out.append(stats_line("n_blocks",            lambda r: r["n_blocks"], group))
        out.append(stats_line("total_flow_entries",  lambda r: r["total_flow_entries"], group))
        out.append(stats_line("max_flow_per_block",  lambda r: r["max_flow_per_block"], group))
        out.append(stats_line("cfg_incoming_edges",  lambda r: r["cfg_incoming_edges"], group))
        out.append(stats_line("n_vl_nodes",          lambda r: r["n_vl_nodes"], group))
        out.append(stats_line("n_vl_edges",          lambda r: r["n_vl_edges"], group))
        out.append(stats_line("n_setter_sites",      lambda r: r["n_setter_sites"], group))
        out.append(stats_line("setter_fanout_max",   lambda r: r["setter_fanout_max"], group))
        out.append(stats_line("setter_fanout_mean",  lambda r: r["setter_fanout_mean"], group))
        out.append(stats_line("setter_fanout_p95",   lambda r: r["setter_fanout_p95"], group))
        out.append(stats_line("n_subroutines",       lambda r: r["n_subroutines"], group))
        out.append(stats_line("n_cg_nodes",          lambda r: r["n_cg_nodes"], group))
        out.append(stats_line("n_cg_edges",          lambda r: r["n_cg_edges"], group))
        total_setters = sum(r["n_setter_sites"] for r in group)
        total_vl_edges = sum(r["n_vl_edges"] for r in group)
        total_blocks = sum(r["n_blocks"] for r in group)
        total_size_mb = sum(r["size_bytes"] for r in group) / (1024 * 1024)
        out.append(f"  TOTALS                       setters={total_setters}  vl_edges={total_vl_edges}  blocks={total_blocks}  on_disk={total_size_mb:.0f} MB")
        out.append("")

    out.append("--- variable_lineage relation totals (all files) ---")
    for rel, cnt in rel_totals.most_common(30):
        out.append(f"  {rel:30s}  {cnt}")
    out.append("")

    out.append("--- job-level files ---")
    for name, info in job_info.items():
        out.append(f"  {name}: {json.dumps(info)}")
    out.append("")

    sample_errors = [r for r in rows if "error" in r][:5]
    if sample_errors:
        out.append("--- sample errors (first 5) ---")
        for r in sample_errors:
            out.append(f"  {r['path']}: {r.get('error', '')}")
        out.append("")

    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("blueprint_dir", help="Directory containing per-file blueprints (recursive scan)")
    ap.add_argument("--workers", type=int, default=4, help="Parallel processes (default 4)")
    ap.add_argument("--resume-file", default="profile_blueprints.jsonl",
                    help="Per-file JSONL for resume/cache (default ./profile_blueprints.jsonl)")
    ap.add_argument("--report", default=None, help="Save aggregate report to this path (also prints to stdout)")
    ap.add_argument("--limit", type=int, default=0, help="Stop after profiling N new files (0=all)")
    args = ap.parse_args()

    bp_dir = Path(args.blueprint_dir).resolve()
    if not bp_dir.is_dir():
        print(f"ERROR: not a directory: {bp_dir}", file=sys.stderr)
        sys.exit(2)

    resume_path = Path(args.resume_file)
    done_paths = set()
    if resume_path.exists():
        with resume_path.open("r", encoding="utf-8") as f:
            for line in f:
                try:
                    d = json.loads(line)
                    p = d.get("path")
                    if p:
                        done_paths.add(p)
                except Exception:
                    pass
        print(f"[resume] {len(done_paths)} entries already in {resume_path}", file=sys.stderr)

    print(f"[scan] walking {bp_dir} ...", file=sys.stderr)
    t_scan = time.monotonic()
    all_paths = discover_blueprints(bp_dir)
    print(f"[scan] discovered {len(all_paths)} blueprint files in {time.monotonic() - t_scan:.1f}s", file=sys.stderr)

    todo = [p for p in all_paths if p not in done_paths]
    if args.limit > 0:
        todo = todo[: args.limit]
    print(f"[scan] {len(todo)} new files to profile ({len(done_paths)} cached)", file=sys.stderr)

    print(f"[scan] checking job-level files (global_variable_lineage.json, file_call_graph.json) ...", file=sys.stderr)
    job_info = find_job_files(bp_dir)
    for k, v in job_info.items():
        print(f"  {k}: {v}", file=sys.stderr)

    t0 = time.monotonic()
    progress_every = max(50, len(todo) // 40) if todo else 1
    with resume_path.open("a", encoding="utf-8") as out:
        if todo:
            with ProcessPoolExecutor(max_workers=args.workers) as ex:
                futures = {ex.submit(profile_one, p): p for p in todo}
                completed = 0
                for fut in as_completed(futures):
                    try:
                        res = fut.result()
                    except Exception as e:
                        res = {"path": futures[fut], "error": repr(e)[:300], "size_bytes": -1}
                    out.write(json.dumps(res) + "\n")
                    out.flush()
                    completed += 1
                    if completed % progress_every == 0 or completed == len(todo):
                        el = time.monotonic() - t0
                        rate = completed / el if el > 0 else 0
                        eta = (len(todo) - completed) / rate if rate > 0 else 0
                        print(f"[progress] {completed}/{len(todo)} ({rate:.1f} files/s, ETA {eta:.0f}s)", file=sys.stderr)

    print(f"[aggregate] loading {resume_path} ...", file=sys.stderr)
    rows = []
    with resume_path.open("r", encoding="utf-8") as f:
        for line in f:
            try:
                rows.append(json.loads(line))
            except Exception:
                pass

    elapsed = time.monotonic() - t0
    report = aggregate(rows, job_info, bp_dir, len(all_paths), elapsed)
    print(report)
    if args.report:
        Path(args.report).write_text(report)
        print(f"[saved] report → {args.report}", file=sys.stderr)


if __name__ == "__main__":
    main()
