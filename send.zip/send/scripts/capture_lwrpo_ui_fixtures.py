#!/usr/bin/env python3
"""Capture the live investigation-API responses for lwrpoDynamicCidMatchResponseInd
on the path aa71 -> dw730000 -> dw710000, so they can be baked into the frontend
demo fixtures (offline / portable, independent of any backend session id).

Prereqs: backend up on :8000, the mock session already written by
scripts/build_mock_lwrpo_session.py (so the explanation pipeline reads accurate data).

Output: scripts/_lwrpo_capture/*.json  (raw API responses)
Run:    python3 scripts/capture_lwrpo_ui_fixtures.py
"""
from __future__ import annotations
import json, sys, time
from pathlib import Path
import urllib.request

BASE = "http://localhost:8000"
KB = "c68d392b-19be-407a-97a6-34acca2f1071"
VAR = "lwrpoDynamicCidMatchResponseInd"
CHAIN_KEY = ["aa71", "dw730000", "dw710000"]   # the flow we want
USER, PW = "admin2", "12345678"
OUT = Path(__file__).resolve().parent / "_lwrpo_capture"


def _req(method, path, token=None, body=None, timeout=900):
    url = BASE + path
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def main():
    OUT.mkdir(exist_ok=True)
    tok = _req("POST", "/v1/auth/login", body={"username": USER, "password": PW})["access_token"]
    print("logged in")

    conv = _req("POST", f"/v1/knowledge-bases/{KB}/conversations", tok, {"persona": "business"})
    conv_id = conv["conv_id"]
    print("conv:", conv_id)

    # keyword-file-flow
    kff = _req("POST", f"/v1/knowledge-bases/{KB}/conversations/{conv_id}/keyword-file-flow?limit=50&offset=0",
               tok, {"variable": VAR, "persona": "business"})
    (OUT / "keyword_file_flows.json").write_text(json.dumps(kff, indent=2))
    flows = kff.get("keyword_file_flows", [])
    print(f"kff: {len(flows)} flows")

    # find the aa71->dw730000->dw710000 flow
    def chain_stems(f):
        ch = f.get("chain") or []
        out = []
        for c in ch:
            s = c.get("file") if isinstance(c, dict) else c
            out.append(str(s).replace(".asm", "").replace(".cpp", ""))
        return out
    target = None
    for f in flows:
        if chain_stems(f) == CHAIN_KEY:
            target = f
            break
    if not target:
        print("ERROR: target flow not found. Available chains:")
        for f in flows:
            print("  ", chain_stems(f))
        sys.exit(1)
    flow_id = target.get("id") or target.get("keyword_file_flow_id")
    print("flow_id:", flow_id, "chain:", chain_stems(target))

    # summary
    print("generating summary (drives all step explanations via LLM — may take a few minutes)...")
    t0 = time.time()
    summary = _req("POST", f"/v1/knowledge-bases/{KB}/conversations/{conv_id}/flows/{flow_id}/summary",
                   tok, {"flow_id": flow_id, "persona": "business"})
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print(f"summary done in {time.time()-t0:.0f}s")

    total = None
    # steps
    steps = []
    idx = 0
    while True:
        st = _req("GET", f"/v1/knowledge-bases/{KB}/conversations/{conv_id}/flows/{flow_id}/steps/{idx}?persona=business", tok)
        steps.append(st)
        total = st.get("total_steps") or total
        print(f"  step {idx}: {st.get('file_stem')} {st.get('variable_in_step')}")
        if not st.get("has_next"):
            break
        idx += 1
        if total and idx >= total:
            break
    (OUT / "steps.json").write_text(json.dumps(steps, indent=2))
    print(f"steps: {len(steps)}")

    # graph-variable details for every node in the lineage graph
    lineage = summary.get("variable_lineage") or {}
    node_ids = [n.get("id") for n in (lineage.get("nodes") or []) if n.get("id")]
    gv = {}
    for nid in node_ids:
        try:
            import urllib.parse
            enc = urllib.parse.quote(nid, safe="")
            d = _req("GET", f"/v1/knowledge-bases/{KB}/conversations/{conv_id}/graph-variables/{enc}?persona=business", tok)
            gv[nid] = d
            print(f"  graph-var {nid}: set_to={'Y' if d.get('set_to_short') else '-'}")
        except Exception as e:
            print(f"  graph-var {nid}: ERROR {e}")
    (OUT / "graph_variables.json").write_text(json.dumps(gv, indent=2))

    meta = {"kb": KB, "variable": VAR, "conv_id": conv_id, "flow_id": flow_id,
            "chain": CHAIN_KEY, "total_steps": total, "node_ids": node_ids}
    (OUT / "meta.json").write_text(json.dumps(meta, indent=2))
    print("\nCAPTURED ->", OUT)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
