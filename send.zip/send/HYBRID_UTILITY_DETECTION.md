# Hybrid Utility Detection — Pipeline-Integrated Approach
## 100% Confidence on Utility Files, Critical Files, and Functionality Clusters

> **Design target:** Given a codebase parsed by `/pipeline`, produce:
> 1. A **deterministic** label (UTILITY / CRITICAL) with 100% confidence for every file
>    that falls into an unambiguous zone — no LLM involved, no probability.
> 2. A **functionality cluster** — the exact set of files related to a queried feature —
>    with complete, reproducible coverage at sub-second query time.
> 3. A **scalable** implementation that handles 10M lines / 50K+ files with constant RAM.

---

## Table of Contents

1. [Why the Previous Approach Needed Updating](#1-why-the-previous-approach-needed-updating)
2. [Architecture Overview](#2-architecture-overview)
3. [Layer 0 — Pipeline Output Ingestion](#3-layer-0--pipeline-output-ingestion)
4. [Layer 1 — Hard Classification (100% Confidence)](#4-layer-1--hard-classification-100-confidence)
5. [Layer 2 — Hybrid Classification (Ambiguous Zone)](#5-layer-2--hybrid-classification-ambiguous-zone)
6. [Layer 3 — Functionality Cluster Builder](#6-layer-3--functionality-cluster-builder)
7. [Layer 4 — File Cluster API](#7-layer-4--file-cluster-api)
8. [Database Schema](#8-database-schema)
9. [Scalability Model](#9-scalability-model)
10. [Confidence Guarantees and Failure Modes](#10-confidence-guarantees-and-failure-modes)
11. [CLI Reference](#11-cli-reference)
12. [End-to-End Example](#12-end-to-end-example)

---

## 1. Why the Previous Approach Needed Updating

### Gaps in the previous design

| Gap | Previous behaviour | New requirement |
|-----|--------------------|-----------------|
| **Source of truth** | Re-scanned raw `.asm`/`.cpp` files with simple regexes | Use pipeline-parsed blueprints (vastly richer) |
| **Confidence ceiling** | ~71.5% files reached hard zones; 28.5% needed LLM | Hard rules cover >90% deterministically from blueprints |
| **Functionality query** | BFS on call graph only | BFS + variable co-modification + semantic cluster |
| **File clusters** | Not a first-class concept | Explicit cluster entity with confidence tags per member |
| **100% confidence claim** | Only for extreme score zones (>0.75 / <0.25) | Full hard-rule tier with documented proof for each rule |
| **Pipeline integration** | Pipeline outputs not used at all | All 7 pipeline outputs consumed as primary data source |
| **HSM file support** | Not addressed | `.hsm` files treated as first-class alongside `.asm`, `.cpp`, `.mac` |

### What the `/pipeline` produces that we can exploit

```
Step 1  →  asm_variable_universe.json, cpp_variable_universe.json
            asm_variable_names.json, cpp_variable_names.json
Step 2  →  <stem>.asm.json blueprints (one per file)
            <stem>.cpp.json blueprints (one per file)
            global_variable_lineage.json
Step 3  →  file_call_graph.json  (nodes + directed edges)
Step 4  →  variable_modifier_index.json  (var → [files that write it])
Step 5  →  variable_identity_index.json  (canonical var identities)
Step 6  →  variable_hop_index.json       (cross-file hop chains)
Step 7  →  output/processes/<name>/      (seed clusters, stub)
```

Each blueprint is a structured parse of one source file — it contains exact opcode
lists, DSECT section boundaries, entry point declarations, cross-file call targets,
and line-level variable writes. This is far richer than any regex scan of raw source.

---

## 2. Architecture Overview

```
╔══════════════════════════════════════════════════════════════════════════════╗
║  /pipeline API  (one-time or incremental run)                                ║
║  ─────────────────────────────────────────────────────────────────────────── ║
║  Blueprints  │  file_call_graph.json  │  variable_modifier_index.json        ║
║  variable_identity_index.json  │  variable_hop_index.json                    ║
╚══════════════════════════════════════════════════════════════════════════════╝
                    │  consumed once by
                    ▼
╔══════════════════════════════════════════════════════════════════════════════╗
║  LAYER 0 — PIPELINE INGESTION  (one-time, ~60s for 50K files)               ║
║  • Read blueprints → extract opcode stats, entry points, DSECT boundaries   ║
║  • Import file_call_graph.json → edges table in SQLite                       ║
║  • Import variable_modifier_index.json → var_modifiers table                 ║
║  • Build per-file feature vector (30+ signals vs. 5 before)                  ║
╚══════════════════════════════════════════════════════════════════════════════╝
                    │
                    ▼
╔══════════════════════════════════════════════════════════════════════════════╗
║  LAYER 1 — HARD CLASSIFICATION  (~90% of files, deterministic)               ║
║                                                                              ║
║  Apply deterministic rules derived from blueprint facts.                     ║
║  Rules are one-directional: once a rule fires, the file is classified        ║
║  and never sent to LLM.                                                      ║
║  Priority: HARD_CRITICAL checked first, then HARD_UTILITY.                  ║
║                                                                              ║
║  HARD_CRITICAL  (≈25–35% of files)  — checked first                         ║
║  HARD_UTILITY   (≈55–65% of files)  — checked second                        ║
║  AMBIGUOUS      (≈5–15% of files)   → Layer 2                                ║
╚══════════════════════════════════════════════════════════════════════════════╝
                    │  AMBIGUOUS files only
                    ▼
╔══════════════════════════════════════════════════════════════════════════════╗
║  LAYER 2 — HYBRID CLASSIFICATION  (ambiguous files, LLM-assisted)           ║
║  • Build evidence packets from blueprint data (richer than before)           ║
║  • LLM resolves ambiguity with confidence score                               ║
║  • Hard bounds prevent LLM from overriding hard-rule neighbours              ║
║  • Results cached by content hash; re-used on incremental re-index           ║
╚══════════════════════════════════════════════════════════════════════════════╝
                    │
                    ▼
╔══════════════════════════════════════════════════════════════════════════════╗
║  LAYER 3 — FUNCTIONALITY CLUSTER BUILDER  (query-time, ~0.1s)               ║
║                                                                              ║
║  Given: entry point stem + optional natural-language description             ║
║                                                                              ║
║  Pass A — Call Graph BFS   (file_call_graph.json edges)                     ║
║           → 100% complete for statically resolvable calls                   ║
║                                                                              ║
║  Pass B — Variable Co-modification  (variable_modifier_index.json)          ║
║           → files that share variable writes with the BFS cluster            ║
║           → catches data-coupling not visible in call edges                  ║
║                                                                              ║
║  Pass C — Semantic Keyword Match  (blueprint title/comment headers)         ║
║           → files that discuss the same functional area                      ║
║           → optional, adds confidence tag SEMANTIC rather than STRUCTURAL   ║
║                                                                              ║
║  Output: FileCluster  — ordered list of (file, confidence_tag, depth)       ║
╚══════════════════════════════════════════════════════════════════════════════╝
                    │
                    ▼
╔══════════════════════════════════════════════════════════════════════════════╗
║  LAYER 4 — FILE CLUSTER API  (sub-second query)                             ║
║  GET /cluster?entry=da78&functionality=...                                   ║
║  Returns: sorted file list with role, confidence_tag, cluster_reason         ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

---

## 3. Layer 0 — Pipeline Output Ingestion

### 3.1 What to read and why

| Pipeline output | What it provides | How we use it |
|----------------|-----------------|---------------|
| `<stem>.asm.json` blueprint | Per-file opcode counts, DSECT sections, entry points, call targets, variable writes | Primary feature vector for ASM |
| `<stem>.hsm.json` blueprint | Same structure as `.asm.json` — HLASM source files parsed identically; `extension` field = `.hsm` | Primary feature vector for HSM |
| `<stem>.mac.json` blueprint | Macro definitions, DSECT blocks, conditional assembly directives (AIF/AGO); `instruction_count` typically 0 | Primary feature vector for MAC |
| `<stem>.cpp.json` blueprint | Function defs, `#pragma` exports, `extern "C"` bridges, include deps | Primary feature vector for C++ |
| `file_call_graph.json` | `{nodes: [{id, type, file}], edges: [{source, target, is_internal, instructions, call_sites: [{call_type, instruction, line, ...}]}]}` — file-to-file call graph. Note: `call_type` is inside each `call_site`, not at the edge top level | Edges table; fan-in/fan-out; BFS |
| `variable_modifier_index.json` | `{_meta: {built_at, blueprints_scanned, unique_variables}, index: {var_name: [stem1, stem2, ...]}}` — mapping lives under `"index"` key, not at root | Variable co-modification clusters |
| `variable_identity_index.json` | Canonical variable identities across files | Deduplication for shared variables |
| `variable_hop_index.json` | Multi-hop variable lineage paths | Extended cluster discovery |
| `global_variable_lineage.json` | Cross-file variable flow chains | Identifies shared data pathways |

### 3.2 Blueprint feature extraction

From each blueprint, extract the following into the SQLite `file_features` table.

> **Blueprint structure note:** Pipeline blueprints are **pure parse outputs** — they store
> structured code artifacts (`symbols`, `blocks`, `dsect_layouts`, `call_graph`,
> `variable_lineage`, `coverage_review`), not pre-computed metric summaries. There is no
> top-level `metrics` key. All metric values (instruction_count, ds_equ_line_count, etc.)
> **must be computed here during ingestion** from the blueprint's parse sections.
> The helper functions below show the derivation from verified field paths.
>
> **Identity fields are NOT in the blueprint.** `build_metadata` is always `{}`.
> `meta` only contains `{"aliases": [], "base_registers": []}`.
> `stem` and `ext` must be derived from the blueprint filename
> (`xh93.asm.json` → stem=`xh93`, ext=`.asm`). `loc` comes from
> `coverage_review.line_audit.total_lines`.
>
> **`has_begin_name` requires raw source.** `asm_entry_point_map` is always `{}`
> for `.asm`/`.hsm` files in the current pipeline version. The only reliable detection
> for standalone programs is a `BEGIN NAME=` regex scan of the raw source file.
> Always pass `source_path` when ingesting `.asm`/`.hsm` blueprints — without it
> Rule C1 will never fire and standalone programs will fall to the ambiguous zone.

All four file types (`.asm`, `.hsm`, `.mac`, `.cpp`) are extracted with the same field
names. `.hsm` blueprints follow the identical structure as `.asm.json`. `.mac` blueprints
produce `has_begin_name=False` and `has_extern_c=False` (macro files cannot declare
standalone entries). `.cpp` blueprints have `dsect_layouts={}` and `dsect_field_count=0`.
Missing fields default to 0/False. The ingestion function signature takes both
`blueprint_path` (for identity) and `source_path` (for `has_begin_name` fallback).

```python
# ── Blueprint metric helpers ───────────────────────────────────────────────
# All field paths verified against actual pipeline blueprint output.
# Key structural facts (confirmed from xh93.asm.json, da78.asm.json, da7gl.mac.json):
#   bp["blocks"]             — LIST of {id, start_line, end_line, flow, incoming_branches}
#   bp["blocks"][n]["flow"]  — {"l":[], "i":[], "a":[], "v":[], "x":[]}  (i = mnemonic list)
#   bp["call_graph"]         — {"nodes": {name: {...}}, "edges": [{source, target, call_type, ...}]}
#   bp["variable_lineage"]   — {"nodes": [{id,name,kind,metadata}], "edges": [{source,target,relation,...}]}
#   bp["symbols"]            — {"global_symbols": {name: {type,...}}, "sections": {}}
#   bp["asm_entry_point_map"]— always {} for .asm/.hsm; {fn_name: asm_name} for .cpp only
#   bp["meta"]               — {"aliases": [], "base_registers": []}  (NO stem/extension/loc)
#   bp["build_metadata"]     — always {}
#   bp["coverage_review"]    — {"line_audit": {"total_lines": int,
#                               "excluded_breakdown": {"blank_line": int, "comment_line": int}}}
#                               (verified from xh93.asm.json; used by _line_counts and features["loc"])
#   bp["dsect_layouts"]      — {layout_name: {field_name: {"offset": int, "length": int}}}
#                               (verified from da7gl.mac.json; {} for .asm/.cpp; used by
#                               _compute_dsect_field_count — note: no line_count field exists)

import re
from pathlib import Path

# Cross-file call types that indicate real inter-module dependencies
_CROSS_FILE_CALL_TYPES = frozenset({
    "subroutine_call", "no_return_call", "async_spawn", "isc_route", "call_alias",
})

# Executable opcodes that indicate real business logic (not pure data/structure)
_BUSINESS_OPCODES = frozenset({
    "ENTRC", "ENTNC", "ENTDC", "CREEC", "CREMC", "SWISC",
    "MVC", "MVI", "MVN", "MVO", "MVZ", "MVCL",
    "AP", "SP", "MP", "DP", "ZAP", "CP", "CVB", "CVD",
    "L", "ST", "LA", "LR", "STM", "LM",
    "BCT", "BC", "BAS", "BASR", "BALR", "BAL",
    "CLC", "CLI", "CLR", "C", "CH",
    "TM", "OC", "XC", "NC", "OI", "XI", "NI",
    "PACK", "UNPK", "ED", "EDMK",
})

# variable_lineage edge relation values that indicate a variable is written
_WRITE_RELATIONS = frozenset({"store", "assign", "define"})

# Matches "BEGIN NAME=" in HLASM source (case-insensitive)
_BEGIN_NAME_RE = re.compile(r"\bBEGIN\s+NAME\s*=", re.IGNORECASE)

# Extension → language tag (used by Pass A cross-language BFS and `language` column)
_EXT_TO_LANG: dict[str, str] = {
    ".asm": "asm", ".hsm": "asm",
    ".mac": "mac", ".copy": "mac", ".cpy": "mac",
    ".cpp": "cpp", ".hpp": "cpp", ".h": "cpp",
}


def _ext_to_language(ext: str) -> str:
    """Map file extension to language tag stored in files.language column."""
    return _EXT_TO_LANG.get(ext.lower(), "asm")


def _stem_and_ext(blueprint_path: str, bp: dict) -> tuple[str, str]:
    """Derive (stem, ext) from the blueprint filename.
    blueprint_path "xh93.asm.json" → ("xh93", ".asm")
    Falls back to scanning line_metadata file entries if path not given.
    """
    if blueprint_path:
        name = Path(blueprint_path).name
        if name.endswith(".json"):
            src = Path(name[:-5])          # strip .json → "xh93.asm"
            return src.stem, src.suffix.lower()
    # Fallback: any file path seen in line_metadata
    for entry in bp.get("line_metadata", {}).values():
        p = Path(entry.get("file", ""))
        if p.suffix:
            return p.stem, p.suffix.lower()
    return "unknown", ".asm"


def _line_counts(bp: dict) -> tuple[int, float]:
    """Return (total_non_blank_lines, comment_ratio) from coverage_review.line_audit."""
    audit   = bp.get("coverage_review", {}).get("line_audit", {})
    total   = audit.get("total_lines", 1)
    blank   = audit.get("excluded_breakdown", {}).get("blank_line", 0)
    comment = audit.get("excluded_breakdown", {}).get("comment_line", 0)
    non_blank = max(1, total - blank)          # floor at 1 to avoid div/0
    return non_blank, comment / non_blank


def _compute_instruction_lines(bp: dict) -> int:
    """Count business-logic instruction mnemonics across all blocks.
    blocks is a LIST; each block has flow["i"] — a list of mnemonic strings.
    Only counts opcodes in _BUSINESS_OPCODES to exclude pure structural ops.
    """
    count = 0
    for block in bp.get("blocks", []):         # LIST, not dict — no .values()
        for mnemonic in block.get("flow", {}).get("i", []):
            if mnemonic.upper() in _BUSINESS_OPCODES:
                count += 1
    return count


def _compute_ds_equ_lines(bp: dict) -> int:
    """Count DS/EQU/DC data-definition symbols.
    Path: symbols["global_symbols"] — NOT symbols directly.
    Symbol type values confirmed: 'ds', 'equ', 'dc'.
    """
    return sum(
        1 for sym in bp.get("symbols", {}).get("global_symbols", {}).values()
        if sym.get("type") in ("ds", "equ", "dc")
    )


def _compute_dsect_field_count(bp: dict) -> int:
    """Count total DSECT field entries across all DSECT layouts.
    dsect_layouts structure: {layout_name: {field_name: {"offset": int, "length": int}}}
    Each nested dict is a field definition — there is NO line_count field.
    Returns number of field entries (a proxy for DSECT data complexity).
    Note: dsect_layouts is {} for .asm/.cpp; populated for .mac only.
    """
    return sum(
        len(fields)
        for fields in bp.get("dsect_layouts", {}).values()
    )


def _compute_macro_def_lines(bp: dict) -> int:
    """Count MACRO/MEND boundary symbols.
    Path: symbols["global_symbols"] — NOT symbols directly.
    """
    return sum(
        1 for sym in bp.get("symbols", {}).get("global_symbols", {}).values()
        if sym.get("type") in ("macro", "mend")
    )


def _has_begin_name(bp: dict, source_path: str = None) -> bool:
    """True if this is a standalone HLASM program (declares BEGIN NAME=).

    PIPELINE LIMITATION: asm_entry_point_map is ALWAYS {} for .asm/.hsm files.
    meta does NOT contain has_begin_name. Raw source scan via source_path is the
    ONLY reliable detection method for standalone programs in .asm/.hsm files.

    Priority:
      1. meta["has_begin_name"] flag — only set by future pipeline versions.
      2. asm_entry_point_map type check — only works for .cpp blueprints.
      3. Raw source scan for BEGIN NAME= — required for .asm/.hsm (ALWAYS provide
         source_path when ingesting .asm/.hsm or Rule C1 will never fire).
    """
    if bp.get("meta", {}).get("has_begin_name", False):
        return True
    for ep in bp.get("asm_entry_point_map", {}).values():
        if isinstance(ep, dict) and ep.get("type") in ("start", "begin", "entry"):
            return True
    if source_path:
        try:
            with open(source_path, encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    if _BEGIN_NAME_RE.search(line):
                        return True
        except OSError:
            pass
    return False


def _entry_point_count(bp: dict) -> int:
    """Count declared entry points in this file (not outgoing ENTRC calls).
    For CPP:     asm_entry_point_map is populated with #pragma map / export entries.
    For ASM/HSM: asm_entry_point_map is always {} — returns 0 (utility-leaning safe default).
    IMPORTANT: ENTRC is an *outgoing* call instruction in HLASM — it is a
    caller-side opcode, not an entry declaration. Do not count ENTRC
    call-sites here; those are captured by _outgoing_call_count below.
    """
    return len(bp.get("asm_entry_point_map", {}))


def _outgoing_call_count(bp: dict) -> int:
    """Count cross-file outgoing calls from call_graph.edges.
    call_graph has no 'callees' key — iterate edges filtered by call_type.
    Only counts edge types that cross file boundaries (_CROSS_FILE_CALL_TYPES).
    """
    return sum(
        1 for edge in bp.get("call_graph", {}).get("edges", [])
        if edge.get("call_type") in _CROSS_FILE_CALL_TYPES
    )


def _variable_writes(bp: dict) -> list:
    """Return list of memory variable names written by this file.
    variable_lineage has no 'written_variables' key — filter edges by relation.
    Only edges with relation in _WRITE_RELATIONS where target is 'memory:varname'.
    """
    written: set[str] = set()
    for edge in bp.get("variable_lineage", {}).get("edges", []):
        if edge.get("relation") in _WRITE_RELATIONS:
            target = edge.get("target", "")
            if ":" in target:
                kind, name = target.split(":", 1)
                if kind == "memory":
                    written.add(name)
    return list(written)


def _compute_purpose_hint(bp: dict, source_path: str = None, ext: str = ".asm") -> str:
    """Construct a purpose_hint string for Pass C semantic search.
    Blueprints do not persist raw comment text, so this requires raw source scanning.
    Returns "" if source_path is None or unreadable — Pass C simply produces no
    candidates for that file, which is safe (empty hint ≠ error).

    - .asm/.hsm: first contiguous '* ' comment block (up to 5 lines) at file top,
                 + first CSECT label found, + TITLE statement text if present.
    - .mac/.copy/.cpy: macro name (from symbols.global_symbols, type='macro')
                       + first '* ' comment block (up to 5 lines).
    - .cpp/.hpp/.h: first Doxygen/block comment (/** ... */ or /* ... */) above
                    the first function or class declaration.

    Result is uppercased and truncated at 256 characters for FTS5/embedding efficiency.
    """
    if not source_path:
        return ""
    ext_lower = ext.lower()
    try:
        with open(source_path, encoding="utf-8", errors="replace") as fh:
            lines = [ln.rstrip() for ln in fh]
    except OSError:
        return ""

    if ext_lower in (".asm", ".hsm"):
        comment_words: list[str] = []
        csect_label = ""
        title_text = ""
        for ln in lines[:60]:
            s = ln.strip()
            if s.startswith("*"):
                comment_words.append(s.lstrip("* ").strip())
                if len(comment_words) >= 5:
                    break
            elif "CSECT" in s.upper() and not csect_label:
                parts = s.split()
                if parts:
                    csect_label = parts[0]
            elif s.upper().lstrip().startswith("TITLE"):
                title_text = s.strip()[5:].strip().strip("'")
        tokens = [t for t in [" ".join(comment_words), csect_label, title_text] if t]
        return " ".join(tokens).upper()[:256]

    elif ext_lower in (".mac", ".copy", ".cpy"):
        macro_name = next(
            (name for name, sym in bp.get("symbols", {})
                                     .get("global_symbols", {}).items()
             if sym.get("type") == "macro"),
            "",
        )
        comment_words = []
        for ln in lines[:30]:
            s = ln.strip()
            if s.startswith("*"):
                comment_words.append(s.lstrip("* ").strip())
                if len(comment_words) >= 5:
                    break
        tokens = [t for t in [macro_name, " ".join(comment_words)] if t]
        return " ".join(tokens).upper()[:256]

    elif ext_lower in (".cpp", ".hpp", ".h"):
        in_block = False
        comment_lines: list[str] = []
        for ln in lines[:80]:
            s = ln.strip()
            if not in_block and (s.startswith("/**") or s.startswith("/*")):
                in_block = True
                comment_lines.append(s.lstrip("/*").strip())
            elif in_block:
                if "*/" in s:
                    comment_lines.append(s.replace("*/", "").lstrip("* ").strip())
                    break
                comment_lines.append(s.lstrip("* ").strip())
        return " ".join(w for ln in comment_lines for w in ln.split())[:256]

    return ""


# ── Main feature extraction ────────────────────────────────────────────────
# Requires: blueprint_path (str, e.g. "xh93.asm.json") for identity
#           source_path    (str, full path to raw source file) for has_begin_name
#                          and purpose_hint; pass None only for .cpp blueprints
#                          where asm_entry_point_map IS populated.
stem, ext           = _stem_and_ext(blueprint_path, bp)
total_non_blank, _ = _line_counts(bp)    # second value (comment_ratio) not stored
instruction_count   = _compute_instruction_lines(bp)
ds_equ_count        = _compute_ds_equ_lines(bp)
dsect_field_count   = _compute_dsect_field_count(bp)
macro_def_count     = _compute_macro_def_lines(bp)

features = {
    # Identity — derived from blueprint filename (NOT from bp["meta"])
    "stem":              stem,
    "ext":               ext,   # .asm / .hsm / .mac / .cpp / .hpp / .h / .copy / .cpy
    "loc":               bp.get("coverage_review", {}).get("line_audit", {}).get("total_lines", 0),

    # Entry point signals (HARD rules fire on these)
    "has_begin_name":    _has_begin_name(bp, source_path=source_path),
    "entry_point_count": _entry_point_count(bp),   # declared entries, NOT outgoing ENTRC calls
    "has_extern_c":      len(bp.get("extern_c_bridges", [])) > 0,  # CPP only
    # UNVERIFIED FIELD: "extern_c_bridges" has not been confirmed against actual .cpp
    # blueprints (only .asm/.mac blueprints were verified). If this key does not exist
    # in the pipeline's .cpp blueprint output, has_extern_c will always be False, and
    # Rule U2 will classify ALL instruction-free .h/.hpp files as HARD_UTILITY — including
    # genuine extern "C" bridge headers. Verify by inspecting a .cpp.json blueprint and
    # replace "extern_c_bridges" with the actual key name before production use.

    # Content signals (computed from blueprint parse sections, not a metrics dict)
    "dsect_field_count": dsect_field_count,         # total DSECT field entries (.mac only; {} for .asm/.cpp)
    "ds_equ_line_count": ds_equ_count,              # pure data-definition lines
    "instruction_count": instruction_count,          # business-logic CPU opcodes
    "macro_def_count":   macro_def_count,
    "non_blank_lines":   total_non_blank,            # matches schema column; floored at 1

    # Call graph signals (from call_graph.edges, NOT call_graph.callees)
    "call_out_count":    _outgoing_call_count(bp),
    "is_leaf":           _outgoing_call_count(bp) == 0,

    # Variable write signals (from variable_lineage.edges filtered by relation)
    "unique_vars_written": len(_variable_writes(bp)),

    # Language tag (used by Pass A cross-language traversal)
    "language":          _ext_to_language(ext),
    # _ext_to_language: {'.asm': 'asm', '.hsm': 'asm', '.mac': 'mac',
    #                    '.cpp': 'cpp', '.hpp': 'cpp', '.h': 'cpp',
    #                    '.copy': 'mac', '.cpy': 'mac'}

    # Semantic search hint (Pass C) — constructed from raw source comments/headers.
    # Empty string if source_path is None; Pass C produces no candidates for that file.
    "purpose_hint":      _compute_purpose_hint(bp, source_path=source_path, ext=ext),
}
```

### 3.3 Fan-in from `file_call_graph.json`

Fan-in cannot be computed from a single blueprint (it requires the caller's perspective).
Import it from `file_call_graph.json` which has all edges:

```python
# ── Actual file_call_graph.json structure ─────────────────────────────────
# Node:  {"id": "da76", "type": "asm", "file": "da76.asm"}
#        Fields: id (stem), type (language tag), file (relative path)
#
# Edge:  {"source": "da76", "target": "A171", "is_internal": false,
#          "instructions": ["ENTRC"],
#          "call_sites": [{"source_block": "L7D7D",
#                          "target_module": "A171",
#                          "instruction": "ENTRC",
#                          "call_type": "subroutine_call",   ← edge_type lives here
#                          "line": 361, "source_file": "da76.asm"}]}
#        Fields: source/target (NOT src/dst), call_type nested inside call_sites[].
#
# Language tag → file extension (inverse of _ext_to_language in Section 3.2)
# Used when importing file_call_graph.json nodes, which carry type not extension.
_LANG_TO_EXT: dict[str, str] = {"asm": ".asm", "hsm": ".hsm", "mac": ".mac", "cpp": ".cpp"}

def _lang_to_ext(lang: str) -> str:
    """Map file_call_graph.json node["type"] to file extension."""
    return _LANG_TO_EXT.get(lang.lower(), ".asm")

# Import nodes and edges
for node in graph["nodes"]:
    # node["type"] is language tag ("asm", "cpp", "mac") — map to file extension
    upsert into files(stem=node["id"],
                      ext=_lang_to_ext(node["type"]),   # e.g. "asm" → ".asm"
                      path=node["file"])

for edge in graph["edges"]:
    # edge["source"] / edge["target"] — not "src" / "dst"
    src_stem  = edge["source"]
    dst_stem  = edge["target"]
    # edge_type: take from first call_site; default "unknown" when call_sites is empty
    edge_type = (edge["call_sites"][0]["call_type"]
                 if edge.get("call_sites") else "unknown")
    insert into edges(src_stem, dst_stem, edge_type)

# Compute total in-degree (fan-in, all languages)
UPDATE files SET in_degree = (
    SELECT COUNT(*) FROM edges WHERE dst_stem = files.stem
);

# Compute in_degree_from_cpp separately (used by Rule C2)
# Note: node["type"] == "cpp" maps to ext '.cpp' via _lang_to_ext above.
UPDATE files SET in_degree_from_cpp = (
    SELECT COUNT(*) FROM edges e
    JOIN files f2 ON f2.stem = e.src_stem
    WHERE e.dst_stem = files.stem AND f2.ext = '.cpp'
);

# Compute out_degree (number of distinct files this file calls)
UPDATE files SET out_degree = (
    SELECT COUNT(*) FROM edges WHERE src_stem = files.stem
);

-- Compute fan_in_score — run AFTER both blueprints (entry_point_count) and
-- edges (in_degree) are ingested. Requires SQLite 3.25+ for PERCENT_RANK().
-- Uses a temp table to avoid CTEs-in-UPDATE compatibility issues (SQLite 3.35+).
-- PERCENT_RANK() gives fraction of files with strictly lower in_degree (0.0–1.0).
CREATE TEMP TABLE _fan_in_ranks AS
    SELECT stem,
           PERCENT_RANK() OVER (ORDER BY in_degree) AS pct_rank
    FROM   files;

UPDATE files
SET    fan_in_score = (
    SELECT r.pct_rank *
           CASE WHEN files.entry_point_count = 0 THEN 0.6
                ELSE 0.1
           END
    FROM   _fan_in_ranks r
    WHERE  r.stem = files.stem
);
DROP TABLE _fan_in_ranks;
-- Result: high-fan-in files with no entry point get higher fan_in_score (utility signal)
--         high-fan-in files with entry points get lower fan_in_score (capped at 0.1×pct)
```

### 3.4 Variable co-modification map

From `variable_modifier_index.json`:

```python
# Actual variable_modifier_index.json structure:
# {
#   "_meta": {"built_at": "...", "blueprints_scanned": N, "unique_variables": N},
#   "index": {
#     "var_name": ["stem1", "stem2", ...],   ← mapping lives under "index", not at root
#     ...
#   }
# }
# IMPORTANT: iterate modifier_index["index"], NOT modifier_index directly.
# Iterating the root yields "_meta" and "index" as keys — not variable names.
for var_name, modifiers in modifier_index["index"].items():
    for stem in modifiers:
        insert into var_modifiers(stem, var_name)

# Index for cluster queries
CREATE INDEX IF NOT EXISTS idx_vm_var  ON var_modifiers(var_name);
CREATE INDEX IF NOT EXISTS idx_vm_stem ON var_modifiers(stem);
```

---

## 4. Layer 1 — Hard Classification (100% Confidence)

### 4.1 What "100% confidence" means here

A rule produces a **100% confident** classification when:
- It is derived purely from facts in the blueprint (not probabilistic scores)
- The rule's logic directly corresponds to the semantic definition of UTILITY or CRITICAL
- Counterexamples have never been observed in the corpus and are architecturally impossible

The rules below satisfy all three criteria. Files that match any HARD rule are
classified immediately and **never sent to the LLM**.

> **Important caveat:** "100% confidence" is conditional on the accuracy of the pipeline's
> blueprint parser. A parser error for a single file (e.g., misclassifying an EQU-like macro
> expansion as an instruction) causes that file to fall back to the `utility_score` path rather
> than applying a HARD rule. The HARD rules are not themselves probabilistic; the parser output
> they consume is. Every classification records `score_source` so parser-caused fallbacks are
> auditable.

### 4.2 HARD_UTILITY rules (100% certain)

A file is unconditionally UTILITY if it matches **any** of the following:

```
SQL column note: rule pseudocode uses `non_blank_lines` — the actual schema column name
  (Section 8). This maps to `total_non_blank` in Section 4.5 notation. Always reference
  `non_blank_lines` when writing rule SQL (e.g., `CAST(ds_equ_line_count AS REAL) / MAX(1, non_blank_lines)`).

RULE U1 — Pure DSECT / data layout file
  IF ext IN ('.mac', '.hsm', '.h', '.copy', '.cpy')
  AND ds_equ_line_count / non_blank_lines > 0.80
  AND instruction_count == 0
  AND entry_point_count == 0
  THEN → HARD_UTILITY
  Reason: The file contains nothing but field/data definitions. It cannot execute
          and cannot implement business logic. Examples: da7gl.mac, cr21ae.mac
  Note: .hsm files that are pure DSECT layouts (ds_equ_ratio > 0.80, no instructions)
        are utility by the same argument as .mac DSECT files.

RULE U2 — C++ / C data-structure header
  IF ext IN ('.hpp', '.h')
  AND has_extern_c == False
  AND instruction_count == 0
  THEN → HARD_UTILITY
  Reason: A header with no extern "C" bridge and no executable code is a pure
          type/layout definition. Examples: ccda7gl.hpp, cclg1g1.hpp
  Note: .h files that DO have extern "C" bridges are not utility — they fall through
        to the scoring path. U1 catches the subset of .h files that are pure DSECTs
        (ds_equ_ratio > 0.80). U2 catches the broader set of logic-free .h/.hpp files.

RULE U4 — Zero-logic macro / HSM template file
  IF ext IN ('.mac', '.hsm')
  AND instruction_count == 0
  AND has_begin_name == False
  THEN → HARD_UTILITY
  Reason: Macro and HSM template files with no CPU instructions and no standalone
          entry declaration are utility infrastructure by role. Conditional assembly
          directives (AIF, AGO, ANOP) are processed at assembly time and never execute
          at runtime — they are not business logic. The file generates code in other
          files rather than executing itself.
  Note: .hsm files with has_begin_name == True are excluded here and caught by C1.

RULE U1_ASM — Pure DSECT / data layout in an .asm file
  IF ext == '.asm'
  AND ds_equ_line_count / non_blank_lines > 0.80
  AND instruction_count == 0
  AND has_begin_name == False
  AND entry_point_count == 0
  THEN → HARD_UTILITY
  Reason: Some HLASM codebases store shared workarea DSECT definitions in plain
          .asm files rather than .mac or .copy files. Rule U1 does not cover .asm
          extensions; this rule fills that gap. A .asm file with no instructions,
          no entry declaration, and >80% DS/EQU content has no executable role.
  Note: The .asm extension prior (ext_score=0.30, critical-leaning) would otherwise
        push these files toward the ambiguous zone — this hard rule prevents that.

RULE U5 — Copy book / include-only file
  IF ext IN ('.mac', '.hsm', '.copy', '.cpy', '.h', '.hpp')
  AND call_out_count == 0
  AND has_begin_name == False
  AND entry_point_count == 0
  AND in_degree > 0
  THEN → HARD_UTILITY
  Reason: A file that is only ever included/copied by others, makes no outgoing calls,
          and declares no entry point is a pure copybook or data layout regardless of
          extension. The in_degree > 0 check confirms it is actually used (not dead code).
```

### 4.3 HARD_CRITICAL rules (100% certain)

A file is unconditionally CRITICAL if it matches **any** of the following:

```
RULE C1 — Standalone business program
  IF has_begin_name == True
  THEN → HARD_CRITICAL
  Applies to: .asm, .hsm  (CPP files use #pragma map, not BEGIN NAME=)
  Reason: BEGIN NAME= in HLASM declares the module as a standalone executable
          program. These are, by definition, business logic units regardless of
          how many callers invoke them. A program called by multiple drivers is
          still CRITICAL.
          Examples: da76.asm, da78.asm, xh71.asm
  Coverage note: _has_begin_name() (Section 3.2) detects BEGIN NAME= via raw
          source scan. It does NOT detect standalone labelled CSECT programs (e.g.,
          `DA76 CSECT`) that lack BEGIN NAME= — those are surfaced only if the pipeline
          parser explicitly populates asm_entry_point_map, which it currently does not
          for .asm/.hsm files. Standalone CSECTs without BEGIN NAME= will miss C1;
          C3/C4 will catch most single-caller cases, but multi-caller standalone CSECTs
          may land in the ambiguous zone. Run `explain --stem X` on known standalone
          programs to verify detection and add human overrides for any missed entries.

RULE C2 — C++ bridge program (entry-dense, not called by other CPP files)
  IF ext == '.cpp'
  AND entry_point_count >= 3       (≥3 #pragma map / #pragma export)
  AND in_degree_from_cpp == 0      (not called by any other .cpp file)
  THEN → HARD_CRITICAL
  Reason: A C++ file that declares multiple ASM-facing entry points and is not
          called by any other C++ file is a top-level ASM bridge program. ASM
          callers are captured in in_degree (total), but what matters for this
          rule is that no other CPP file orchestrates it — it is a root program.
  Threshold note: The threshold of 3 is calibrated to the reference codebase where
          CPP bridge programs consistently export ≥3 entry points. CPP utility
          wrappers (helpers, adapters) typically export 0–2. If the target codebase
          has bridge programs with only 2 exports, lower this to 2 and document the
          change. Files with entry_point_count==1 or ==2 fall through to scoring.
  Note: in_degree_from_cpp is computed separately from total in_degree:
          UPDATE files SET in_degree_from_cpp = (
              SELECT COUNT(*) FROM edges e
              JOIN files f2 ON f2.stem = e.src_stem
              WHERE e.dst_stem = files.stem AND f2.ext = '.cpp'
          )
  Examples: dx710000.cpp, dx740200.cpp

RULE C3 — Instruction-dense ASM/HSM subroutine with single caller
  IF ext IN ('.asm', '.hsm')
  AND instruction_count / non_blank_lines > 0.50
  AND has_begin_name == False      (BEGIN NAME= files already handled by C1)
  AND in_degree == 1               (called by exactly one program — private logic)
  AND entry_point_count == 0
  THEN → HARD_CRITICAL
  Reason: >50% real CPU instructions in a single-caller subroutine with no shared
          entry point is private business logic for that one caller.
  Note: .mac and .hsm template files are excluded by the ext guard. C3 fires only
        for .asm and .hsm files with genuine instruction content.

RULE C4 — Instruction-dense subroutine with outgoing calls and single caller
  IF ext IN ('.asm', '.hsm', '.cpp')   (explicitly excludes .mac, .h, .hpp, .copy, .cpy)
  AND in_degree == 1
  AND is_leaf == False             (has outgoing calls — it orchestrates further logic)
  AND instruction_count / non_blank_lines > 0.40
  AND has_begin_name == False      (avoids double-classification with C1)
  AND entry_point_count == 0       (avoids double-classification with C2)
  THEN → HARD_CRITICAL
  Reason: A single-caller module that both contains substantial instruction logic and
          calls other modules is a private business orchestrator — not utility infrastructure.
  Note: The ext guard explicitly prevents .mac files from matching C4 even if they
        have in_degree==1 and outgoing macro invocations. Macro files are utility
        by role regardless of instruction density.
  Relationship to C3: C3 catches instruction-dense leaf subroutines (is_leaf possible);
        C4 catches instruction-dense non-leaf subroutines. Together they cover the full
        single-caller private logic space. C3 fires first (stricter threshold 0.50);
        C4 catches files C3 misses (threshold 0.40, requires is_leaf==False).
```

### 4.4 Classification priority and ambiguous zone

Rules are applied in this order:

```
1. Check all HARD_CRITICAL rules → if any fires → HARD_CRITICAL (done)
2. Check all HARD_UTILITY rules  → if any fires → HARD_UTILITY  (done)
3. Compute utility_score (5-signal weighted formula, see 4.5)
4. If score > 0.70 → SOFT_UTILITY  (send to LLM for confirmation)
5. If score < 0.30 → SOFT_CRITICAL (send to LLM for confirmation)
6. Otherwise      → AMBIGUOUS      (send to LLM for resolution)
```

**Why HARD_CRITICAL before HARD_UTILITY:** A file that satisfies a CRITICAL rule
(e.g., has BEGIN NAME=) must never be overridden by a UTILITY rule. CRITICAL rules
encode stronger semantic certainty about a file's executable role. Reversing this
priority would, for example, allow a high fan-in UTILITY rule to shadow a BEGIN NAME=
declaration — which is architecturally impossible to justify.

The AMBIGUOUS zone is estimated at ~5–15% of files based on the reference codebase
(28K ASM/CPP/MAC files). This figure is **not guaranteed** — codebases with a higher
proportion of mixed-content HSM files or dual-role subroutines may see 15–25%.
The hard-rule tiers have been validated on the reference corpus; the AMBIGUOUS
percentage should be measured on each new codebase and documented.

> **Note — Former Rule U3 (high fan-in) removed as a HARD rule:**
> High fan-in alone does not imply UTILITY. A central business dispatcher called by
> 200 programs has no entry point of its own and no BEGIN NAME=, yet it is definitionally
> CRITICAL. High fan-in is now a weighted signal inside `fan_in_score` (Section 4.5),
> pushing high-fan-in files toward SOFT_UTILITY for LLM confirmation rather than
> stamping them HARD_UTILITY with no review.

### 4.5 Signal formula update (for ambiguous zone scoring)

The 5-signal formula is retained but signals are now sourced from blueprint data.
`fan_in_score` now carries the role previously assigned to the removed HARD Rule U3 —
high fan-in pushes toward SOFT_UTILITY where the LLM can confirm or deny, rather than
being a hard gate.

```
utility_score = clamp(
    ext_score          × 0.30   (extension prior — strongest single signal)
  + content_score      × 0.25   (blueprint data; more reliable than raw-scan)
  + fan_in_score       × 0.25   (from file_call_graph.json in_degree, percentile)
  + entry_score        × 0.10   (from blueprint asm_entry_point_map)
  + name_score         × 0.10
, 0.0, 1.0)                     # ← clamp entire sum to [0,1]

─────────────────────────────────────────────────────────────────
ext_score  (prior probability of utility based on file extension)
─────────────────────────────────────────────────────────────────
  .copy / .cpy   → 0.92   (copybooks — almost always pure data)
  .mac           → 0.85   (macros — utility infrastructure by role)
  .h             → 0.80   (C headers — predominantly layout)
  .hpp           → 0.75   (C++ headers — layout unless extern "C")
  .hsm           → 0.35   (HLASM source — leans critical; executable)
  .asm           → 0.30   (assembly source — leans critical; executable)
  .cpp           → 0.40   (C++ source — slightly critical-leaning)
  default        → 0.50   (unknown extension — neutral prior)

─────────────────────────────────────────────────────────────────
content_score  (instruction vs. data layout composition)
─────────────────────────────────────────────────────────────────
  raw = ds_equ_ratio × 1.0
      + macro_def_ratio × 0.5
      - instruction_ratio × 0.8

  content_score = clamp(raw, 0.0, 1.0)    # ← must clamp; raw can exceed 1.0

  where ds_equ_ratio      = ds_equ_line_count / total_non_blank
        macro_def_ratio   = macro_def_count   / total_non_blank
        instruction_ratio = instruction_count / total_non_blank
        total_non_blank   ≥ 1 (floored at ingestion time; see Section 3.2)
  SQL column mapping: total_non_blank = non_blank_lines column in files table.
  In SQL: CAST(ds_equ_line_count AS REAL) / MAX(1, non_blank_lines)

  Example overflow without clamp: ds_equ_ratio=0.80, macro_def_ratio=0.60
    raw = 0.80 + 0.30 = 1.10 → clamped to 1.0 ✓

─────────────────────────────────────────────────────────────────
fan_in_score  (shared infrastructure signal via call graph)
─────────────────────────────────────────────────────────────────
  fan_in_percentile = PERCENT_RANK() OVER (ORDER BY in_degree)
  fan_in_score      = fan_in_percentile × 0.6    # if entry_point_count == 0
                    | fan_in_percentile × 0.1    # if entry_point_count > 0

  Max contribution to utility_score: 0.6 × 0.25 = 0.15
  Rationale: High fan-in with no entry point is a utility indicator. The LLM
             confirmation at score > 0.70 resolves the critical shared-dispatcher
             case that fan-in alone cannot distinguish.

─────────────────────────────────────────────────────────────────
entry_score  (entry point declarations push toward critical)
─────────────────────────────────────────────────────────────────
  entry_score = 0.0  if entry_point_count > 0   (has declared entry → critical signal)
              | 0.75 if entry_point_count == 0  (no declared entry → utility-leaning)
  Note: entry_score is inverted — higher value = more utility-like.
        A file with no entry point is more likely utility (shared subroutine or layout).
        A file with declared entry points is more likely critical (standalone program).
        Max contribution when entry_point_count==0: 0.75 × 0.10 = 0.075.

  PIPELINE LIMITATION — .asm/.hsm files: asm_entry_point_map is always {} for
  .asm/.hsm blueprints in the current pipeline version, so entry_point_count is
  always 0 for these file types. entry_score therefore contributes a fixed 0.075
  to utility_score for every .asm/.hsm file in the ambiguous zone regardless of
  its actual role — it provides no discrimination between file types for the most
  common extensions. This is a safe, utility-leaning default. The entry_score
  signal becomes informative for .asm/.hsm only after the pipeline parser is
  updated to populate asm_entry_point_map. For .cpp files, asm_entry_point_map
  IS populated (via #pragma map / #pragma export), so entry_score works correctly.

─────────────────────────────────────────────────────────────────
name_score  (file naming conventions as a soft utility prior)
─────────────────────────────────────────────────────────────────
  Pattern matching against the file stem (case-insensitive).

  IMPORTANT: these patterns are calibrated to the reference codebase's naming
  conventions. Different HLASM systems use different conventions (e.g., all
  8-char module names, purely numeric load module IDs, language-prefixed names).
  Review and extend these patterns per target codebase before first use.
  name_score is always soft (weight 0.10) — a mismatch does not break HARD rules.

  UTILITY-leaning patterns (score → 0.80):
    stem contains: GL, COMM, COPY, WORK, WRK, DSECT, DFHE, LAYOUT,
                   UTIL, LIB, COMMON, HDR, INCL, INCLUDE, CONST, DEF

  CRITICAL-leaning patterns (score → 0.20):
    stem matches: ^[a-z]{2}\d{2}         (2-letter prefix + 2+ digits: da78, xh80)
    stem matches: ^\d{4,}                 (all-numeric: 710000, 740200)
    stem contains: MAIN, ENTRY, PROC, BATCH, JOB, PGMR

  Default (no pattern match): 0.50
```

### 4.6 Computing utility_score — SQL implementation

The five signals are computed and stored as individual columns in the `files` table,
then combined into `utility_score`. Run **after** `fan_in_score` has been populated
(Section 3.3) and **before** Layer 2 LLM classification.

> **Note:** SQLite has no native `CLAMP()` function. Use `MIN(1.0, MAX(0.0, ...))`.
> The `name_score` ILIKE patterns require SQLite built with ICU, or use `LOWER(stem) LIKE`.

```sql
-- ── Signal 1: ext_score ──────────────────────────────────────────────────
UPDATE files SET ext_score = CASE ext
    WHEN '.copy' THEN 0.92  WHEN '.cpy'  THEN 0.92
    WHEN '.mac'  THEN 0.85
    WHEN '.h'    THEN 0.80
    WHEN '.hpp'  THEN 0.75
    WHEN '.hsm'  THEN 0.35
    WHEN '.asm'  THEN 0.30
    WHEN '.cpp'  THEN 0.40
    ELSE 0.50
END;

-- ── Signal 2: content_score ──────────────────────────────────────────────
-- ds_equ_ratio + macro_def_ratio - instruction_ratio, clamped to [0,1]
UPDATE files SET content_score = MIN(1.0, MAX(0.0,
    CAST(ds_equ_line_count  AS REAL) / MAX(1, non_blank_lines) * 1.0
  + CAST(macro_def_count    AS REAL) / MAX(1, non_blank_lines) * 0.5
  - CAST(instruction_count  AS REAL) / MAX(1, non_blank_lines) * 0.8
));

-- ── Signal 3: fan_in_score — already populated (see Section 3.3) ─────────

-- ── Signal 4: entry_score ────────────────────────────────────────────────
-- Inverted: no declared entries → utility-leaning (0.75); entries present → 0.0
UPDATE files SET entry_score = CASE
    WHEN entry_point_count > 0 THEN 0.0
    ELSE 0.75
END;

-- ── Signal 5: name_score ─────────────────────────────────────────────────
-- Calibrated to reference codebase naming conventions (see Section 4.5).
-- Adjust LIKE patterns per target codebase before first use.
UPDATE files SET name_score = CASE
    WHEN LOWER(stem) LIKE '%gl%'      OR LOWER(stem) LIKE '%comm%'
      OR LOWER(stem) LIKE '%work%'    OR LOWER(stem) LIKE '%wrk%'
      OR LOWER(stem) LIKE '%dsect%'   OR LOWER(stem) LIKE '%layout%'
      OR LOWER(stem) LIKE '%util%'    OR LOWER(stem) LIKE '%lib%'
      OR LOWER(stem) LIKE '%common%'  OR LOWER(stem) LIKE '%hdr%'
      OR LOWER(stem) LIKE '%incl%'    OR LOWER(stem) LIKE '%const%'
      OR LOWER(stem) LIKE '%def%'     OR LOWER(stem) LIKE '%dfhe%'
        THEN 0.80
    WHEN LOWER(stem) LIKE '%main%'    OR LOWER(stem) LIKE '%entry%'
      OR LOWER(stem) LIKE '%proc%'    OR LOWER(stem) LIKE '%batch%'
      OR LOWER(stem) LIKE '%job%'     OR LOWER(stem) LIKE '%pgmr%'
        THEN 0.20
    WHEN stem GLOB '[a-zA-Z][a-zA-Z][0-9][0-9]*'   -- 2-letter prefix + 2+ digits
        THEN 0.20
    WHEN stem GLOB '[0-9][0-9][0-9][0-9]*'          -- all-numeric 4+ digit load module
        THEN 0.20
    ELSE 0.50
END;

-- ── Final utility_score: weighted sum, clamped to [0, 1] ─────────────────
-- Run LAST, after all five signals are populated.
UPDATE files SET utility_score = MIN(1.0, MAX(0.0,
    ext_score     * 0.30
  + content_score * 0.25
  + fan_in_score  * 0.25
  + entry_score   * 0.10
  + name_score    * 0.10
))
WHERE hard_rule IS NULL;   -- skip files already classified by hard rules
```

---

## 5. Layer 2 — Hybrid Classification (Ambiguous Zone)

The LLM layer is structurally identical to the previous design but with two improvements:

### 5.1 Richer evidence packets

Packets now include blueprint-derived fields not available from raw-source scanning:

```json
{
  "stem": "xh93",
  "ext": ".asm",   // also valid: ".hsm", ".cpp", ".mac"
  "loc": 412,
  "hard_rule_fired": null,
  "utility_score": 0.435,
  "zone": "AMBIGUOUS",
  "blueprint_signals": {
    "has_begin_name": false,
    "entry_points": [],
    "instruction_ratio": 0.149,
    "ds_equ_ratio": 0.389,
    "unique_vars_written": 14,
    "outgoing_calls": ["xh94"],
    "incoming_calls": ["xh85", "xh88"]
  },
  "purpose_hint": "PROCESS RELATIONSHIP ACCOUNT PROFILE",
  "code_fingerprint": [
    "XH93     CSECT",
    "         USING *,R12",
    "         GETCC REG=R1",
    "XH9_INIT DS    0H",
    "         STM   R14,R7,S41REG14",
    "         ENTRC XH94  UPDATE CM PROFILE DATABASE"
  ],
  "caller_roles": ["FUNCTIONAL", "FUNCTIONAL"],
  "callee_roles": []
}
```

### 5.2 Reduced batch count

With ~5–15% ambiguous files (vs. 28.5%), the LLM call count for 50K files drops from
~700 batches to **~175–375 batches**. First-run LLM cost: ~$0.20–$0.45.

### 5.3 Retained safeguards

All previous safeguards remain in force:
- Hard bounds: LLM cannot move a file from HARD_UTILITY to CRITICAL or vice versa
- Confidence gate: LLM results with confidence < 0.50 are discarded
- Consistency check: callers CRITICAL + callees UTILITY → flag for review
- Stability gate: >15% role changes between runs → block + warn
- Dual-prompt consensus: optional `--consensus` flag for boundary files
- Human override: `score_source = "human_override"`, survives re-index
- Full audit trail: every classification is traceable

---

## 6. Layer 3 — Functionality Cluster Builder

This layer answers the query:
> *"Which files are related to functionality X, and with what confidence?"*

### 6.1 Three-pass algorithm

**Input:** `entry_stem` (e.g., `da78`) + optional `description` text

---

**Pass A — Call Graph BFS** (structural coupling, STRUCTURAL confidence)

> **Scope of coverage:** Pass A is **100% complete for statically resolvable calls** —
> every edge present in `file_call_graph.json` is followed. It cannot cover calls made
> via register-loaded addresses (e.g., `BALR R14,R15` after `LA R15,=V(TARGET)`),
> dispatch tables, or self-modifying code — these are invisible to static analysis.
> In typical HLASM batch codebases, dynamic dispatch accounts for ~5–15% of call edges.
> Pass B (variable co-modification) partially compensates by catching data-coupled files
> that share state with the cluster even when the call edge is invisible.

> **Cross-language traversal:** Pass A follows **all edge types regardless of language**.
> `file_call_graph.json` contains ASM→CPP, CPP→ASM, ASM→HSM, MAC invocation, and
> same-language edges. The BFS does not filter by `edge_type` or language — it traverses
> every edge from every node in the frontier. A cluster starting from an ASM entry point
> will naturally include CPP bridge files (ASM→CPP edges) and their callees (CPP→ASM
> edges), and HSM modules at any depth. Language of each file is recorded in the `language`
> column and shown in the cluster output.

> **Multi-entry clusters:** When a functionality spans multiple co-entry points (e.g.,
> `da76` and `da78` both implement credit limit maintenance), pass a comma-separated
> list to `entries`. The BFS seeds all entry points simultaneously — files reachable from
> any seed are included, and files that lie on paths between seeds are naturally captured.
> API parameter: `entries=da76,da78` (see Section 7.1).

Implementation uses a single SQLite recursive CTE (`UNION`, not `UNION ALL`, to prevent
infinite loops on cyclic call graphs):

```sql
-- Step 1: create and populate the seeds temp table from the API entry parameter(s).
-- For single entry:  INSERT INTO seeds VALUES (:entry_stem)
-- For multi-entry:   INSERT INTO seeds SELECT value FROM json_each(:entries_json)
-- The seeds table is dropped after the query completes.
CREATE TEMP TABLE seeds (stem TEXT PRIMARY KEY);
INSERT INTO seeds VALUES (:entry_stem);   -- or multiple rows for multi-entry clusters

-- Step 2: Forward BFS — all files reachable from any seed up to :max_depth hops.
-- UNION (not UNION ALL) deduplicates by (stem, depth) — breaks all call graph cycles.
WITH RECURSIVE reachable(stem, depth) AS (
    -- Seed: all entry points simultaneously
    SELECT stem, 0 FROM seeds

    UNION   -- ← UNION not UNION ALL; prevents revisiting stems already reached

    -- Expand one hop
    SELECT e.dst_stem,
           r.depth + 1
    FROM   edges e
    JOIN   reachable r ON e.src_stem = r.stem
    WHERE  r.depth < :max_depth    -- max_depth default: 10 (see Section 7.1)
)
SELECT r.stem,
       MIN(r.depth)    AS depth,
       f.ext,
       f.language,
       f.role
FROM   reachable r
JOIN   files f ON f.stem = r.stem
GROUP  BY r.stem;
```

To capture the `via_stem` (parent) for each reachable file, run a second query
joining `reachable` back to `edges` after the CTE resolves — this avoids carrying
unbounded lineage data inside the recursive term.

For the optional backward pass (`--include-callers`), reverse src/dst.
**Note: run this BEFORE dropping the seeds table** — both passes share the same
`seeds` temp table and it must remain alive until all passes for this query complete.

```sql
WITH RECURSIVE callers(stem, depth) AS (
    SELECT stem, 0 FROM seeds    -- seeds still alive; created in Step 1 above
    UNION
    SELECT e.src_stem, c.depth + 1
    FROM   edges e
    JOIN   callers c ON e.dst_stem = c.stem
    WHERE  c.depth < :max_depth
)
SELECT stem, MIN(depth) AS depth FROM callers GROUP BY stem;

-- Drop seeds only after ALL passes (forward + optional backward) have completed.
DROP TABLE seeds;   -- re-created fresh for each cluster query
```

All files in Pass A have **STRUCTURAL** confidence — they are reachable via explicit,
statically resolved call edges. `UNION` deduplication ensures cycles terminate at the
first visit. The CTE executes as a single SQL round-trip, avoiding O(depth) Python
iterations and SQLite's 999-variable binding limit.

---

**Pass B — Variable Co-modification** (data coupling, HIGH confidence)

Files that are not on the call path but share variable writes with the cluster.

> **Noise control is critical here.** A threshold of 2 shared variables will flood
> clusters with false positives in large codebases: global workareas like `WK_RET`,
> `WK_RC`, or system fields (DFHEISTG, DFHEIBLK in CICS) are written by hundreds of
> programs that have no functional relationship. The implementation below uses three
> mitigations: a raised absolute threshold, a relative-density filter, and a
> pre-built exclusion list for known high-frequency global fields.

```python
# --- Build exclusion list once at index time ---
# Variables written by more than HIGH_FREQ_THRESHOLD files are "global noise"
# and excluded from Pass B matching entirely.
HIGH_FREQ_THRESHOLD = max(10, total_files * 0.02)   # top 2% most-shared vars

INSERT OR REPLACE INTO excluded_vars (var_name, writer_count, excluded_at)
    SELECT var_name,
           COUNT(DISTINCT stem)  AS writer_count,
           datetime('now')
    FROM   var_modifiers
    GROUP  BY var_name
    HAVING COUNT(DISTINCT stem) > :HIGH_FREQ_THRESHOLD
-- writer_count is NOT NULL in the schema — all three columns must be provided

# --- Pass B query at cluster time ---
cluster_stems = set(visited.keys())

cluster_vars = SQL:
    SELECT DISTINCT vm.var_name
    FROM   var_modifiers vm
    WHERE  vm.stem IN (cluster_stems)
    AND    vm.var_name NOT IN (SELECT var_name FROM excluded_vars)

# Qualify by:
#   (a) absolute count  >= COMOD_ABS_THRESHOLD  (default: 5 shared variables)
#   (b) density ratio   >= COMOD_RATIO_THRESHOLD (default: shared_vars / file_total_vars >= 0.10)
#       — prevents a 500-var file from qualifying on 5 coincidental hits
co_modifiers = SQL:
    SELECT vm.stem,
           COUNT(DISTINCT vm.var_name)                              AS shared_vars,
           COUNT(DISTINCT vm.var_name) * 1.0 / f.unique_vars_written AS density
    FROM   var_modifiers vm
    JOIN   files f ON f.stem = vm.stem
    WHERE  vm.var_name IN (cluster_vars)
    AND    vm.stem NOT IN (cluster_stems)
    GROUP  BY vm.stem
    HAVING shared_vars >= :COMOD_ABS_THRESHOLD      -- default 5
    AND    density     >= :COMOD_RATIO_THRESHOLD     -- default 0.10
    ORDER  BY shared_vars DESC

for stem, shared_count, density in co_modifiers:
    visited[stem] = {
        "depth": -1,
        "confidence": "DATA_COUPLED",
        "reason": f"shares {shared_count} variable writes with cluster (density={density:.0%})",
        "shared_vars": [...]
    }
```

Pass B catches files that are **data-coupled** but not call-coupled — a common pattern
in HLASM where one program writes a workarea field that another program reads, without
an explicit ENTRC between them.

Confidence tag: **DATA_COUPLED** — high confidence but not 100% (shared variable
may be coincidental even after filtering). User can inspect `shared_vars` to verify.
The `excluded_vars` table **must be rebuilt** whenever `variable_modifier_index.json`
is re-imported (incremental or full). Writer counts change when files are added or
removed, shifting which variables cross the exclusion threshold. See Section 9.3 for
the incremental re-index sequence.

---

**Pass C — Semantic Match** (optional, blueprint headers)

When `description` is provided, match it against blueprint purpose hints.

> **`purpose_hint` definition:** For each file type, `purpose_hint` is constructed
> by the pipeline blueprint parser from the most descriptive available source:
> - `.asm` / `.hsm`: concatenation of (1) the first `* ` comment block at file top,
>   (2) the CSECT label, and (3) any TITLE statement, uppercased and whitespace-normalised.
>   Example: `"GLOBAL CREDIT LIMIT MAINTENANCE DA78 TITLE: GNA/HUB SYSTEM"`
> - `.mac`: the macro name + first comment block of the macro definition.
>   Example: `"DA7GL MACRO WORKAREA DSECT FOR CREDIT LIMIT FIELDS"`
> - `.cpp` / `.hpp` / `.h`: the first Doxygen/block comment (`/** ... */` or `/* ... */`)
>   above the first function or class definition.
>   Example: `"DX710000 CPP BRIDGE ENTRY POINTS FOR CREDIT LIMIT MODULE"`
> If none of these sources are present, `purpose_hint` is `""` (empty string). Files
> with empty `purpose_hint` produce no FTS5/embedding candidates — they simply do not
> appear in Pass C results, which is correct (unknown purpose → no semantic match).

> **Limitations of keyword-only matching:** A plain bag-of-words overlap is unreliable
> for functionality search. "MAINTENANCE" matches both "credit limit MAINTENANCE" and
> "FILE MAINTENANCE ROUTINE." TF-IDF weighting reduces common-word noise but still
> misses synonyms.
>
> **Preferred implementation:** Pre-compute embeddings for each file's blueprint header
> at index time (stored as binary blobs in SQLite via the `sqlite-vec` extension). At
> query time, embed the description with the same model and run a cosine similarity scan.
> This is a single SQL query, adds ~30ms at query time, and survives vocabulary mismatches.
>
> **Fallback:** If embeddings are not available (no embedding model configured), use
> FTS5 full-text search with BM25 ranking as described below. Results will have more
> false positives; the SEMANTIC confidence tag signals this to the caller.

```python
# --- Preferred: embedding-based (sqlite-vec) ---
if embedding_model_available:
    query_vec = embed(description)   # float32[384] or similar
    candidates = SQL:
        SELECT stem,
               vec_distance_cosine(hint_embedding, :query_vec) AS dist
        FROM   file_hints_vec
        WHERE  stem NOT IN (cluster_stems)
        ORDER  BY dist ASC
        LIMIT  50
    threshold = 0.35   # cosine distance; lower = more similar

# --- Fallback: FTS5 BM25 keyword search ---
else:
    candidates = SQL:
        SELECT stem, bm25(file_hints) AS rank
        FROM   file_hints
        WHERE  file_hints MATCH :fts_query    # description tokenized
        AND    stem NOT IN (cluster_stems)
        ORDER  BY rank ASC
        LIMIT  50
    threshold = None   # BM25 rank is relative; take top-N only

for stem, score in candidates:
    if score <= threshold (embedding) or top-N (FTS5):
        visited[stem] = {
            "depth": -2,
            "confidence": "SEMANTIC",
            "reason": f"blueprint header matches description (score={score:.3f})",
            "match_method": "embedding" if embedding_model_available else "fts5_bm25"
        }
```

Pass C is **intentionally broad** — it adds files that may be relevant but are not
provably connected. Confidence tag: **SEMANTIC** — lower certainty, shown separately
in the API response for user review. Always inspect SEMANTIC members before acting on them.

### 6.2 Role enumeration

Every file in a cluster carries a `role` value drawn from this fixed set:

| Role | Source | Meaning |
|------|--------|---------|
| `HARD_CRITICAL` | Layer 1 hard rule (C1–C4) | Deterministically classified as critical business logic |
| `HARD_UTILITY` | Layer 1 hard rule (U1–U5) | Deterministically classified as utility / infrastructure |
| `SOFT_CRITICAL` | Layer 2 LLM (score < 0.30) | LLM-confirmed critical; no hard rule fired |
| `SOFT_UTILITY` | Layer 2 LLM (score > 0.70) | LLM-confirmed utility; no hard rule fired |
| `FUNCTIONAL` | Layer 2 LLM (AMBIGUOUS resolved) | File resolved as business-logic subroutine; not standalone but not pure infrastructure |
| `BRIDGE` | Layer 2 LLM (AMBIGUOUS resolved) | File crosses a language or architectural boundary (e.g., ASM↔CPP adapter); called by multiple different-language callers |
| `AMBIGUOUS` | Layer 2 (LLM confidence < 0.50) | LLM could not resolve; queued for human review |
| `HUMAN_OVERRIDE` | `human_overrides` table | Human-set label; survives all re-index passes |

`FUNCTIONAL` and `BRIDGE` are assigned by the LLM during the AMBIGUOUS resolution
pass (Layer 2), not by hard rules. The LLM prompt offers these as additional labels
beyond UTILITY/CRITICAL to capture nuanced roles; they are stored in `llm_decisions.label`.

### 6.3 Cluster output structure

```json
{
  "entry": "da78",
  "description": "Global credit limit maintenance for GNA/HUB system",
  "cluster_size": 18,
  "files": [
    {
      "stem": "da78",
      "ext": ".asm",
      "role": "HARD_CRITICAL",
      "depth": 0,
      "direction": "seed",
      "confidence_tag": "STRUCTURAL",
      "reason": "entry point",
      "in_degree": 1,
      "out_degree": 1
    },
    {
      "stem": "xh80",
      "role": "FUNCTIONAL",
      "depth": 1,
      "direction": "callee",
      "confidence_tag": "STRUCTURAL",
      "reason": "called by da78 via subroutine_call"
    },
    {
      "stem": "xh93",
      "role": "BRIDGE",
      "depth": 3,
      "direction": "callee",
      "confidence_tag": "STRUCTURAL",
      "reason": "called by xh85 via subroutine_call"
    },
    {
      "stem": "da7gl",
      "role": "HARD_UTILITY",
      "depth": -1,
      "direction": "data_coupled",
      "confidence_tag": "DATA_COUPLED",
      "reason": "shares 7 variable writes with cluster (WK_CNT, WK_RFD, ...)",
      "shared_vars": ["WK_CNT", "WK_RFD", "WK_CMO", "WK_RRC"]
    }
  ],
  "confidence_summary": {
    "STRUCTURAL": 14,
    "DATA_COUPLED": 3,
    "SEMANTIC": 1
  }
}
```

### 6.4 Filtering and sorting

The cluster can be filtered and sorted for different use cases:

```bash
# Only files the user must understand (STRUCTURAL + CRITICAL or FUNCTIONAL role)
GET /cluster?entry=da78&min_confidence=STRUCTURAL&max_role=FUNCTIONAL

# Full cluster including data-coupled (for data-flow analysis)
GET /cluster?entry=da78&include=STRUCTURAL,DATA_COUPLED

# Only the call chain, no data coupling, max 4 hops deep
GET /cluster?entry=da78&include=STRUCTURAL&max_depth=4
```

Default sort order:
1. Seed file first
2. STRUCTURAL before DATA_COUPLED before SEMANTIC
3. Within same confidence tag: CRITICAL / HARD_CRITICAL first, then by depth ascending

---

## 7. Layer 4 — File Cluster API

### 7.1 API endpoint

```
GET /cluster?entry=<stem>&description=<text>&include=<tags>&max_depth=<n>
```

| Parameter | Default | Meaning |
|-----------|---------|---------|
| `entry` | — | Single file stem (e.g., `da78`). Use `entries` for multi-entry clusters. |
| `entries` | — | Comma-separated list of entry stems (e.g., `da76,da78`). BFS seeds all simultaneously. Mutually exclusive with `entry`. |
| `description` | none | Natural-language functionality description (enables Pass C) |
| `include` | `STRUCTURAL,DATA_COUPLED` | Which confidence tags to include |
| `max_depth` | `10` | Maximum BFS hops from entry/entries. Use `0` for unlimited (caution: may return entire codebase for highly connected entry points). |
| `include_callers` | false | Also traverse backward (who calls the entry?) |
| `role_filter` | none | Return only files with this role (e.g., `CRITICAL,FUNCTIONAL`) |
| `lang_filter` | none | Return only files of a given language (e.g., `asm`, `cpp`, `mac`) |
| `format` | `json` | Output format: `json`, `csv`, `table` |

> **`max_depth` default is 10, not unlimited.** An unlimited BFS on a highly connected
> entry point will traverse the entire codebase (every file is reachable within a few
> hops in a tightly coupled HLASM system). The default of 10 covers the vast majority
> of real business logic chains while protecting against accidental full-graph traversals.
> Use `max_depth=0` to explicitly request unlimited depth.

### 7.2 Response time targets

| Codebase size | Pass A BFS | Pass B var lookup | Pass C semantic | Total |
|--------------|-----------|-----------------|----------------|-------|
| 50K files, 10K cluster | ~0.05s | ~0.03s | ~0.02s | **~0.1s** |
| 500K files, 50K cluster | ~0.3s | ~0.1s | ~0.05s | **~0.45s** |

All three passes run against pre-built SQLite indexes. No file I/O at query time.

### 7.3 Pre-built indexes for sub-second queries

These indexes are part of the full schema (Section 8) and listed here for reference.
All use `IF NOT EXISTS` to be idempotent — running Section 8 after this section
will not produce "already exists" errors.

```sql
-- Edges index (call graph BFS)
CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(src_stem);
CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(dst_stem);

-- Variable co-modification index (Pass B)
CREATE INDEX IF NOT EXISTS idx_vm_var  ON var_modifiers(var_name);
CREATE INDEX IF NOT EXISTS idx_vm_stem ON var_modifiers(stem);

-- Blueprint purpose hints (Pass C semantic match)
CREATE INDEX IF NOT EXISTS idx_purpose ON files(purpose_hint);
-- FTS5 virtual table for full-text search (Pass C fallback; stem UNINDEXED = not searched)
CREATE VIRTUAL TABLE IF NOT EXISTS file_hints USING fts5(stem UNINDEXED, hint_text);
```

---

## 8. Database Schema

Full SQLite schema for the hybrid system:

```sql
-- Core file registry
CREATE TABLE files (
    stem                TEXT PRIMARY KEY,
    path                TEXT,
    ext                 TEXT,
    language            TEXT,    -- 'asm' | 'mac' | 'cpp' | (from _ext_to_language)
    loc                 INTEGER,
    non_blank_lines     INTEGER,

    -- Blueprint signals
    has_begin_name      INTEGER DEFAULT 0,
    entry_point_count   INTEGER DEFAULT 0,
    has_extern_c        INTEGER DEFAULT 0,
    dsect_field_count   INTEGER DEFAULT 0,   -- total DSECT field entries (.mac only; dsect_layouts is {} for .asm/.cpp)
    ds_equ_line_count   INTEGER DEFAULT 0,
    instruction_count   INTEGER DEFAULT 0,
    macro_def_count     INTEGER DEFAULT 0,
    unique_vars_written INTEGER DEFAULT 0,
    call_out_count      INTEGER DEFAULT 0,
    is_leaf             INTEGER DEFAULT 0,
    purpose_hint        TEXT,    -- see _compute_purpose_hint() in Section 3.2

    -- Graph signals (populated after edge import)
    in_degree           INTEGER DEFAULT 0,   -- total callers (all languages)
    in_degree_from_cpp  INTEGER DEFAULT 0,   -- callers whose ext = '.cpp' (used by Rule C2)
    out_degree          INTEGER DEFAULT 0,
    fan_in_score        REAL    DEFAULT 0.0,

    -- Scoring signals (computed by Section 4.6 SQL; -1.0 = not yet computed)
    ext_score           REAL    DEFAULT -1.0,
    content_score       REAL    DEFAULT -1.0,
    entry_score         REAL    DEFAULT -1.0,
    name_score          REAL    DEFAULT -1.0,

    -- Classification results
    -- role values: HARD_UTILITY | HARD_CRITICAL | SOFT_UTILITY | SOFT_CRITICAL |
    --              FUNCTIONAL | BRIDGE | AMBIGUOUS | HUMAN_OVERRIDE
    hard_rule           TEXT,                -- NULL or 'U1'..'U5' / 'C1'..'C4'
    utility_score       REAL    DEFAULT -1.0,
    role                TEXT,
    fused_score         REAL    DEFAULT -1.0,
    score_source        TEXT    DEFAULT 'pending',
    -- score_source values: 'hard_rule' | 'llm' | 'score_fallback' | 'human_override'

    -- Timestamps
    indexed_at          TEXT,
    classified_at       TEXT
);

-- File-to-file call graph
CREATE TABLE edges (
    src_stem    TEXT    NOT NULL,
    dst_stem    TEXT    NOT NULL,
    edge_type   TEXT,   -- subroutine_call / no_return_call / include / call_alias / etc.
    PRIMARY KEY (src_stem, dst_stem, edge_type)
);
CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(src_stem);
CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(dst_stem);

-- Variable co-modification map
CREATE TABLE var_modifiers (
    stem        TEXT    NOT NULL,
    var_name    TEXT    NOT NULL,
    PRIMARY KEY (stem, var_name)
);
CREATE INDEX IF NOT EXISTS idx_vm_var  ON var_modifiers(var_name);
CREATE INDEX IF NOT EXISTS idx_vm_stem ON var_modifiers(stem);

-- LLM classification decisions (Layer 2)
-- label values: UTILITY | CRITICAL | FUNCTIONAL | BRIDGE
CREATE TABLE llm_decisions (
    stem                TEXT    NOT NULL,
    content_hash        TEXT    NOT NULL,
    label               TEXT    NOT NULL,
    confidence          REAL    NOT NULL,
    reason              TEXT,
    fused_score         REAL    NOT NULL,
    score_source        TEXT    NOT NULL,
    mode                TEXT    NOT NULL DEFAULT 'global',
    functionality_id    TEXT    NOT NULL DEFAULT '',  -- '' for global; NOT NULL avoids NULL PK issues
    model_id            TEXT,
    classified_at       TEXT,
    PRIMARY KEY (stem, mode, functionality_id)        -- no COALESCE needed; '' is the default
);

-- Cached functionality clusters (avoid recomputing same query)
-- Invalidation: delete rows where ingest_generation < current generation (see below).
CREATE TABLE cluster_cache (
    entry_stems         TEXT    NOT NULL,       -- comma-separated (supports multi-entry)
    functionality_hash  TEXT    NOT NULL,       -- SHA256 of description
    include_flags       TEXT    NOT NULL,
    max_depth           INTEGER NOT NULL DEFAULT 10,
    ingest_generation   INTEGER NOT NULL,       -- incremented on every ingest; stale if <current
    result_json         TEXT    NOT NULL,       -- serialized cluster
    cached_at           TEXT,
    PRIMARY KEY (entry_stems, functionality_hash, include_flags, max_depth)
);

-- Ingest generation counter and global file count.
-- Both rows required: HIGH_FREQ_THRESHOLD in Pass B reads 'total_files'.
-- If 'total_files' is absent the HAVING clause in excluded_vars build evaluates
-- NULL > threshold = NULL (false) — nothing gets excluded, polluting Pass B.
CREATE TABLE ingest_meta (
    key     TEXT PRIMARY KEY,
    value   TEXT
);
INSERT INTO ingest_meta VALUES ('generation',   '0');
INSERT INTO ingest_meta VALUES ('total_files',  '0');  -- updated at end of every ingest
-- At query time: DELETE FROM cluster_cache WHERE ingest_generation < (SELECT value FROM ingest_meta WHERE key='generation')
-- At ingest time: UPDATE ingest_meta SET value = CAST(CAST(value AS INTEGER)+1 AS TEXT) WHERE key='generation'
-- After blueprint import: UPDATE ingest_meta SET value=(SELECT COUNT(*) FROM files) WHERE key='total_files'

-- Human overrides
CREATE TABLE human_overrides (
    stem        TEXT    PRIMARY KEY,
    label       TEXT    NOT NULL,
    reason      TEXT,
    set_by      TEXT,
    set_at      TEXT
);

-- Review queue for consistency-check failures
CREATE TABLE review_queue (
    stem            TEXT    NOT NULL,
    reason          TEXT    NOT NULL,
    det_score       REAL,
    llm_label       TEXT,
    llm_confidence  REAL,
    queued_at       TEXT,
    resolved        INTEGER DEFAULT 0
);

-- FTS5 table for semantic keyword search (Pass C fallback)
CREATE VIRTUAL TABLE file_hints USING fts5(stem UNINDEXED, hint_text);

-- High-frequency variable exclusion list (Pass B noise control)
-- Populated at index time: variables written by > HIGH_FREQ_THRESHOLD files
CREATE TABLE excluded_vars (
    var_name    TEXT PRIMARY KEY,
    writer_count INTEGER NOT NULL,    -- how many files write this var
    excluded_at  TEXT
);

-- Embedding vectors for Pass C semantic search (preferred over FTS5)
-- Requires sqlite-vec extension; column stores float32[] as blob
-- If sqlite-vec is unavailable, this table is unused and FTS5 is the fallback
CREATE TABLE file_hints_vec (
    stem            TEXT PRIMARY KEY,
    hint_embedding  BLOB,             -- vec_f32(384) or model-specific dimension
    model_id        TEXT,             -- embedding model name for invalidation
    embedded_at     TEXT
);
```

---

## 9. Scalability Model

### 9.1 Index build from pipeline outputs

> **Memory note on large JSON files:** `file_call_graph.json` and
> `variable_modifier_index.json` can be very large (the 28K-file reference codebase
> produces a 173 MB `file_call_graph.json`). Python's `json.loads()` on a 173 MB file
> creates 3–5× object overhead (~520–860 MB peak RAM). **Both files must be parsed with
> a streaming JSON parser** (`ijson` library) to keep peak RAM below the targets below.
> Streaming parses one object at a time and immediately inserts it into SQLite, so the
> full payload is never held in memory simultaneously.

| Phase | 50K files | 500K files | Peak RAM |
|-------|-----------|------------|---------|
| Blueprint ingestion (streaming, 1 file at a time) | ~60s | ~10 min | ~80 MB |
| file_call_graph.json import (streaming via `ijson`) | ~15s | ~90s | ~120 MB |
| variable_modifier_index.json import (streaming via `ijson`) | ~20s | ~150s | ~120 MB |
| Hard rule classification (pure SQL) | ~2s | ~15s | ~20 MB |
| Score computation (pure SQL) | ~2s | ~10s | ~20 MB |
| FTS5 / vec index build | ~5s | ~60s | ~50 MB |
| **Total first-run index** | **~105s** | **~17 min** | **~120 MB peak** |

After index build: all queries run against SQLite. Peak RAM at query time < 30 MB.

The system is usable on a machine with **512 MB RAM** at 50K files. At 500K files,
512 MB remains sufficient because streaming import keeps peak RAM at ~120 MB. A
full `json.loads()` approach would require 3–5 GB at this scale and is disallowed.

### 9.2 Query performance (sub-second at any scale)

The BFS, variable lookup, and semantic match all execute as indexed SQL queries.
Cluster size (not codebase size) determines query time:

| Cluster size | Pass A BFS | Pass B var | Pass C FTS | Total |
|-------------|-----------|-----------|-----------|-------|
| 50 files | 0.01s | 0.005s | 0.005s | **0.02s** |
| 500 files | 0.05s | 0.02s | 0.01s | **0.08s** |
| 5,000 files | 0.2s | 0.08s | 0.03s | **0.31s** |

### 9.3 Incremental re-index after pipeline re-run

When `/pipeline` runs incrementally (only changed files re-parsed):

1. **Increment generation counter** (invalidates all cluster cache entries immediately):
   `UPDATE ingest_meta SET value = CAST(CAST(value AS INTEGER)+1 AS TEXT) WHERE key='generation'`

2. **Blueprint ingestion**: upsert rows for changed stems only (`INSERT OR REPLACE INTO files`)

3. **Call graph**: if `file_call_graph.json` changed, delete + re-import edges table (~15s);
   then recompute graph metrics for all files using the UPDATE statements from Section 3.3:
   ```sql
   UPDATE files SET in_degree = (SELECT COUNT(*) FROM edges WHERE dst_stem = files.stem);
   UPDATE files SET in_degree_from_cpp = (
       SELECT COUNT(*) FROM edges e JOIN files f2 ON f2.stem = e.src_stem
       WHERE e.dst_stem = files.stem AND f2.ext = '.cpp');
   UPDATE files SET out_degree = (SELECT COUNT(*) FROM edges WHERE src_stem = files.stem);
   ```
   Then **recompute `fan_in_score`** (it depends on `in_degree` via PERCENT_RANK):
   ```sql
   CREATE TEMP TABLE _fan_in_ranks AS
       SELECT stem, PERCENT_RANK() OVER (ORDER BY in_degree) AS pct_rank FROM files;
   UPDATE files SET fan_in_score = (
       SELECT r.pct_rank * CASE WHEN files.entry_point_count = 0 THEN 0.6 ELSE 0.1 END
       FROM _fan_in_ranks r WHERE r.stem = files.stem);
   DROP TABLE _fan_in_ranks;
   ```
   Then **recompute `utility_score`** for AMBIGUOUS files (Section 4.6 SQL, ~2s SQL).

4. **Variable modifier**: if `variable_modifier_index.json` changed, delete + re-import
   var_modifiers table (~20s); then **rebuild `excluded_vars`** immediately (~2s SQL):
   ```sql
   -- Update total_files FIRST — excluded_vars threshold (× 0.02) must use the current
   -- file count. If new files were added in step 2 and total_files is stale, the
   -- threshold would be too low and too many variables would be excluded from Pass B.
   UPDATE ingest_meta SET value=(SELECT COUNT(*) FROM files) WHERE key='total_files';

   DELETE FROM excluded_vars;
   INSERT INTO excluded_vars
       SELECT var_name, COUNT(DISTINCT stem), datetime('now')
       FROM var_modifiers
       GROUP BY var_name
       HAVING COUNT(DISTINCT stem) > (SELECT CAST(value AS REAL) * 0.02
                                      FROM ingest_meta WHERE key='total_files');
   ```

5. **Re-classify changed files**: apply hard rules (C1–C4, U1–U5) → re-queue for LLM if
   moved to AMBIGUOUS; unchanged files retain their `fused_score` from `llm_decisions`

6. **Purge stale cluster cache**:
   ```sql
   DELETE FROM cluster_cache
   WHERE ingest_generation < (SELECT CAST(value AS INTEGER) FROM ingest_meta WHERE key='generation');
   ```

Typical commit (10–50 changed files): **~45s** incremental re-index (dominated by
streaming JSON re-import of call graph and variable modifier files if they changed).

### 9.4 var_modifiers scalability at 50K+ files

At 50K files × 1,000 average variables per file, `var_modifiers` reaches ~50M rows.
The Pass B query uses `WHERE var_name IN (cluster_vars)` where `cluster_vars` may be
thousands of values. At this scale, SQLite's B-tree index (`idx_vm_var`) handles the
query efficiently, but the `IN` clause size matters:

- **Batch the IN clause**: if `len(cluster_vars) > 500`, split into batches of 500 and
  UNION the results. SQLite's query planner degrades with very large `IN` lists.
- **Use a temp table for large clusters**: for clusters > 200 files, insert `cluster_vars`
  into a temporary table and JOIN instead of using `IN`:
  ```sql
  CREATE TEMP TABLE _cv(var_name TEXT PRIMARY KEY);
  INSERT INTO _cv SELECT DISTINCT var_name FROM var_modifiers
      WHERE stem IN (SELECT stem FROM _cluster_stems)
      AND var_name NOT IN (SELECT var_name FROM excluded_vars);
  SELECT vm.stem, COUNT(*) AS shared_vars ...
  FROM var_modifiers vm JOIN _cv ON vm.var_name = _cv.var_name ...
  ```
- **At 500K files / 500M rows**: SQLite reaches practical limits. Consider migrating
  `var_modifiers` and `edges` to DuckDB (columnar, faster analytical scans) while
  keeping the classification tables in SQLite for transactional safety.

### 9.5 Blueprint ingestion ordering

Ingestion phases must run in this order — each phase depends on the prior one:

1. **Create schema** — all tables and indexes (Section 8)
2. **Ingest all blueprints** → populate `files` table (all columns including `purpose_hint`)
3. **Set total_files** → `UPDATE ingest_meta SET value=(SELECT COUNT(*) FROM files) WHERE key='total_files'`
   — required before `excluded_vars` build; a NULL value silently disables Pass B noise filtering
4. **Import `file_call_graph.json`** (streaming via `ijson`) → populate `edges`;
   recompute `in_degree`, `in_degree_from_cpp`, `out_degree` for all files
5. **Import `variable_modifier_index.json`** (streaming via `ijson`) → populate `var_modifiers`;
   immediately rebuild `excluded_vars` (see Section 9.3 step 4)
6. **Run hard classification** (`classify-hard`) — pure SQL; no file I/O
7. **Run LLM classification** (`classify-llm`) — AMBIGUOUS files only
8. **Build FTS5 / embeddings** (`build-embeddings`) — populate `file_hints` and `file_hints_vec`:
   ```sql
   -- FTS5: populate from purpose_hint column (already in files table from step 2)
   -- Only insert files with a non-empty purpose_hint; empty hints produce no Pass C hits.
   DELETE FROM file_hints;
   INSERT INTO file_hints (stem, hint_text)
       SELECT stem, purpose_hint
       FROM   files
       WHERE  purpose_hint IS NOT NULL AND purpose_hint != '';

   -- Embedding vectors: populated by utility_detector.py build-embeddings command
   -- which iterates files.purpose_hint, calls the embedding model, and inserts:
   --   INSERT INTO file_hints_vec (stem, hint_embedding, model_id, embedded_at)
   --   VALUES (stem, <float32_blob>, model_name, datetime('now'))
   -- Skip file_hints_vec if no embedding model is configured; Pass C falls back to FTS5.
   ```

Phases 4 and 5 can run concurrently (they write to separate tables). All other
phases are sequential.

### 9.6 Memory architecture

No file content is ever held in RAM at query time:
- All signals are in SQLite rows
- Blueprint data is accessed only during ingestion (then discarded)
- BFS operates via a single recursive CTE (no Python-level graph in RAM)
- Variable index lookups are SQL queries (O(1) per variable name with index)

The system remains usable on a machine with **512 MB RAM** even at 500K files,
provided the index build phase uses streaming JSON parsing (see Section 9.1) and
the `var_modifiers` IN-clause batching strategy (see Section 9.4) is applied.

---

## 10. Confidence Guarantees and Failure Modes

### 10.1 The 100% confidence guarantee — what it covers

| Claim | Guarantee | Conditions / Caveats |
|-------|-----------|----------------------|
| HARD_UTILITY files (U1/U1_ASM/U2/U4/U5) are not critical | 100%* | Rules fire only on zero instruction_count + no entry declaration — no executable logic by construction. *Conditional on blueprint parser correctly computing instruction_count from `blocks`. |
| HARD_CRITICAL files (C1 — BEGIN NAME=) are not utility | 100%* | HLASM spec: BEGIN NAME= declares a standalone executable entry. *Conditional on `_has_begin_name()` detecting all standalone entry forms, including labelled CSECT. |
| HARD_CRITICAL files (C3/C4 — single-caller, instruction-dense) are not utility | ~95%* | Single caller at index time is used as a proxy for "private logic". A file that temporarily has 1 caller but is architecturally shared infrastructure will be misclassified until a second caller appears (at which point it falls out of C3/C4 on the next re-index). *Use human overrides for confirmed shared subroutines caught by C3/C4. |
| STRUCTURAL cluster files are reachable from entry | 100% of statically resolvable calls | BFS via recursive CTE on deterministic call graph. Dynamic dispatch (BALR), ISC routing (`isc_route` edges), and async spawns (`async_spawn` edges) are not covered — these can represent a significant fraction of control flow in ISC-heavy codebases, potentially 20–40% of total edges. |
| DATA_COUPLED files share writes with cluster | ~90% after filtering | Confirmed by `var_modifiers` index after `excluded_vars` exclusion and density ratio (≥10%) filtering. Residual ~10% false positives from coincidental variable sharing in large shared workareas. |
| SEMANTIC cluster members match the functionality | ~70–85% (embedding) / ~60–70% (FTS5) | Embedding cosine similarity or BM25 on blueprint headers. Reliability drops sharply when `purpose_hint` is empty or terse (common in legacy HLASM). Always review SEMANTIC members before acting. |

### 10.2 What can still be wrong

| Failure mode | Confidence tier affected | Mitigation |
|-------------|--------------------------|-----------|
| Blueprint parse error in one file | HARD rules for that file | File falls to utility_score path; LLM resolves. `score_source = "score_fallback"` is auditable. |
| HSM file with no `.hsm.json` blueprint | All layers for that file | File appears in `file_call_graph.json` edges but has no feature row — inserted as `role=AMBIGUOUS, score_source=no_blueprint`; queued for human review. |
| `.asm` pure DSECT file not caught by U1 | Layer 1 for that file | Rule U1_ASM (Section 4.2) covers this case. Confirm `instruction_count==0` is extracted correctly from `blocks` for the file in question. |
| Labelled CSECT program not detected by C1 | Layer 1 HARD_CRITICAL | `_has_begin_name()` has a fallback through `asm_entry_point_map`. If both miss the program, it falls to C3/C4 or ambiguous. Run `explain --stem X` to verify; apply human override if needed. |
| `entry_point_count` miscounts outgoing ENTRC as entries | C2 rule, entry_score | `_entry_point_count()` reads `asm_entry_point_map` (declared entries), not call sites. Validate that the pipeline does not insert outgoing ENTRC targets into `asm_entry_point_map`. |
| `total_files` key absent from `ingest_meta` | Pass B excluded_vars | Schema now initializes `total_files='0'` (Section 8). Confirmed: `HAVING COUNT(*) > NULL` silently excludes nothing, flooding Pass B. |
| Dynamic dispatch (register-based BALR) | STRUCTURAL cluster completeness | Pass B DATA_COUPLED partially compensates via data-sharing. Document cluster as "statically complete." |
| ISC routing / async spawn edges (`isc_route`, `async_spawn`) | STRUCTURAL cluster completeness | These edges appear in `file_call_graph.json` with their own edge_type values. Pass A BFS follows them (no edge_type filter), so they are included if the pipeline resolves them statically. Unresolved dynamic ISC targets remain gaps. |
| Static call that macro-expands to a call | STRUCTURAL cluster | Macro-generated calls may be absent from call graph. Same mitigation as dynamic dispatch. |
| File renamed without content change | LLM cache only | Content hash in `llm_decisions` invalidated; hard rules re-apply on next ingest (content-independent). |
| AMBIGUOUS zone file misclassified by LLM | SOFT_ zone only | HARD_CRITICAL priority in classification order prevents LLM from overriding HARD_ zones. |
| High-frequency global variable floods Pass B | DATA_COUPLED tag | `excluded_vars` table removes variables written by >2% of files. Density ratio filter (≥10%) eliminates weak hits. |
| `purpose_hint` absent or terse in blueprint | SEMANTIC tier only | SEMANTIC tier is always advisory; FTS5/embedding gracefully returns no results for empty hints. |
| Cluster cache stale after re-index | All cluster queries | `ingest_generation` counter incremented on every ingest; stale cache rows purged at end of re-index. |
| /pipeline produces stale outputs | All layers | Ingestion timestamp checked; warn if blueprint `indexed_at` is older than source file mtime. |

### 10.3 The foolproof guarantee (revised)

The system guarantees:
1. **No HARD_UTILITY file will ever appear as CRITICAL** — hard ceiling enforced in SQL; HARD_CRITICAL rules evaluated first so they cannot be shadowed by UTILITY rules
2. **No HARD_CRITICAL file (C1–C4) will ever appear as PURE_UTILITY** — HARD_CRITICAL rules have priority over all UTILITY rules
3. **No statically resolvable STRUCTURAL cluster member will be missing** — recursive CTE BFS is complete over the ingested call graph; dynamic dispatch and unresolved ISC routing gaps are documented per-cluster
4. **Every classification is auditable** — `explain --stem X` shows which rule fired, the exact signal values, and `score_source`
5. **Human overrides survive re-index** — stored separately in `human_overrides`, applied as the final step after all rule and LLM passes
6. **High-frequency global variables do not pollute Pass B** — `excluded_vars` table is built with an initialised `total_files` counter and maintained on every incremental ingest

Known hard limits (not covered by the guarantees above):
- `.asm` files with labelled CSECT entries that the pipeline parser does not surface in `asm_entry_point_map` will miss C1; C3/C4 will catch most of them, but not all (e.g., multi-caller standalone CSECTs).
- C3/C4 classify files based on caller count at index time; a file with temporarily one caller that is architecturally shared infrastructure will be HARD_CRITICAL until a second caller is indexed. Use the review queue and human overrides to correct these.

The system can produce **false positives** (files appearing in DATA_COUPLED or SEMANTIC
tiers that are not truly related — they are labelled with their confidence tag and the
user knows to verify). It can produce **false negatives for dynamic-dispatch calls**
(files reachable only via runtime-resolved addresses will not appear in the STRUCTURAL
tier). It cannot produce false negatives for statically resolvable STRUCTURAL members.

---

## 11. CLI Reference

### Index build (run after `/pipeline` completes)

```bash
# Ingest pipeline outputs into utility index (streaming JSON parse — no full-load)
python3 utility_detector.py ingest \
    --pipeline-output jobs/<job_id>/output/ \
    --db utility_index.db

# Build excluded_vars table (high-frequency global variable noise filter for Pass B)
python3 utility_detector.py build-exclusions \
    --db utility_index.db \
    [--threshold 0.02]    # exclude vars written by > 2% of files (default)

# Build hard classifications from blueprints (pure SQL; HARD_CRITICAL first, then HARD_UTILITY)
python3 utility_detector.py classify-hard \
    --db utility_index.db

# (Optional) Build embedding vectors for Pass C semantic search
python3 utility_detector.py build-embeddings \
    --db utility_index.db \
    --model all-MiniLM-L6-v2   # or any sentence-transformers model
    # Falls back to FTS5 if this step is skipped

# Classify ambiguous files with LLM (Layer 2)
python3 utility_detector.py classify-llm \
    --db utility_index.db \
    --model claude-sonnet-4-6 \
    --batch-size 20 \
    [--consensus]     # dual-prompt for boundary files
    [--dry-run]       # show what would be sent; no LLM calls
```

### Query

```bash
# Global utility ranking
python3 utility_detector.py analyze --db utility_index.db

# Get functionality cluster — single entry
python3 utility_detector.py cluster \
    --entry da78 \
    --db utility_index.db \
    [--description "Global credit limit maintenance for GNA/HUB"] \
    [--include STRUCTURAL,DATA_COUPLED,SEMANTIC] \
    [--max-depth 10] \
    [--include-callers] \
    [--role-filter CRITICAL,FUNCTIONAL] \
    [--lang-filter asm,hsm,cpp] \
    [--output da78_cluster.json]

# Get functionality cluster — multiple co-entry points (da76 + da78 together)
python3 utility_detector.py cluster \
    --entries da76,da78 \
    --db utility_index.db \
    --description "Global credit limit maintenance for GNA/HUB" \
    --output credit_limit_cluster.json

# Explain a file's classification
python3 utility_detector.py explain --stem da7gl --db utility_index.db

# Human override
python3 utility_detector.py override \
    --stem da7gl --label UTILITY \
    --reason "Confirmed: pure DSECT workarea" \
    --db utility_index.db

# Show files pending human review
python3 utility_detector.py review-queue --db utility_index.db
```

### Incremental update after pipeline re-run

```bash
# Re-ingest only changed pipeline outputs (upserts by stem)
python3 utility_detector.py ingest \
    --pipeline-output jobs/<new_job_id>/output/ \
    --db utility_index.db \
    --incremental

# Re-classify only changed files (hard rules + LLM for newly-ambiguous)
python3 utility_detector.py classify-hard --db utility_index.db --changed-only
python3 utility_detector.py classify-llm  --db utility_index.db --changed-only
```

---

## 12. End-to-End Example

**Scenario:** Engineer asks: *"Which files are critical for global credit limit maintenance?"*

**Step 1 — Index already built** (one-time after `/pipeline`):
```
Files indexed: 30,874
HARD_UTILITY:  19,208 (62.2%)  — rules U1-U5 fired
HARD_CRITICAL:  8,842 (28.6%)  — rules C1-C4 fired
SOFT_UTILITY:     612  (2.0%)  — score > 0.70, LLM confirmed
SOFT_CRITICAL:    421  (1.4%)  — score < 0.30, LLM confirmed
AMBIGUOUS:      1,791  (5.8%)  — LLM resolved from 441 batches → ~88 batches
```

**Step 2 — Cluster query:**
```bash
python3 utility_detector.py cluster \
    --entry da78 \
    --description "Global credit limit maintenance for GNA/HUB" \
    --db utility_index.db \
    --include-callers
```

**Output:**
```
Cluster for: da78  ("Global credit limit maintenance for GNA/HUB")
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STRUCTURAL (14 files — 100% confidence):
  ★ da78    .asm  HARD_CRITICAL  depth=0  seed
    lu82    .asm  HARD_CRITICAL  depth=2  caller   ← entry trigger
    da76    .asm  HARD_CRITICAL  depth=1  caller
    xh80    .asm  HARD_CRITICAL  depth=1  callee   ← central dispatcher
    xh71    .asm  HARD_CRITICAL  depth=2  callee
    xh81    .asm  HARD_CRITICAL  depth=2  callee
    xh85    .asm  HARD_CRITICAL  depth=2  callee
    xh72    .asm  HARD_CRITICAL  depth=3  callee
    xh83    .asm  HARD_CRITICAL  depth=3  callee
    xh82    .asm  HARD_CRITICAL  depth=4  callee
    xh87    .asm  HARD_CRITICAL  depth=4  callee
    xh88    .asm  HARD_CRITICAL  depth=5  callee
    xh96    .asm  HARD_CRITICAL  depth=6  callee
    xh93    .asm  FUNCTIONAL     depth=3  callee   ← shared, BRIDGE resolved

DATA_COUPLED (3 files — ~90% confidence after exclusion/density filtering):
    da7gl   .mac  HARD_UTILITY   depth=-1  shares 7 vars (WK_CNT, WK_RFD...)   density=41%
    wb1wb   .mac  HARD_UTILITY   depth=-1  shares 4 vars (WB1PTMST, WB1SW1...) density=22%
    lg1lg1  .mac  HARD_UTILITY   depth=-1  shares 3 vars (LG1OSI, LG1G1TYP...) density=18%

SEMANTIC (1 file — ~75% confidence, review recommended):
    xh90    .asm  HARD_CRITICAL  depth=-2  blueprint: "GLOBAL LIMITS A7 LREC"

Query time: 0.087s
```

**Interpretation:**
- 14 STRUCTURAL files: provably part of the functionality (call graph)
- 3 DATA_COUPLED files: workarea/DSECT files that share data with the cluster — utilities
  but must be known to understand the data flow
- 1 SEMANTIC file: blueprint header mentions "GLOBAL LIMITS" — likely relevant, inspect manually
- All `.mac` / DSECT files (da7gl, wb1wb, lg1lg1) are correctly classified HARD_UTILITY
  even though they appear in the cluster — the engineer knows they are infrastructure, not logic

Total query time: **87ms** for a 30K-file codebase.

