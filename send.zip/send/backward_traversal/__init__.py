"""Backward-only traversal isolated package."""
