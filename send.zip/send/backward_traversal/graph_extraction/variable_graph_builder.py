"""Build a variable-connection graph from completed backward-traversal tuples.

Given the list of tuples produced by `ChunkedBackwardSession.assemble_tuple()`
(after the session has been driven to completion), extract a compact graph
where:

  * Nodes are variable names (root + every dep_var discovered)
  * Edges go FROM the variable being traced in a tuple TO each dep_var
    found while tracing it (backward semantics: target feeds into source)
  * Each node and edge carries a list of `locations` (file, block_id, line,
    instruction, role) so the user can navigate to the source.

The builder is **pure**: it does not touch disk, blueprints, or the network.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

SCHEMA_VERSION = 1

_NOISE_PREFIXES = ("LEVEL:", "MEMORY:", "ALLOC@", "RETURN@", "BRIDGE_BACK_TO_ASM:")


def _normalize_var(name: Any) -> str:
    return str(name or "").strip().upper()


def _is_noise(name_upper: str) -> bool:
    if not name_upper:
        return True
    # GAP-I: indirect_call@ nodes are meaningful dispatch annotations emitted
    # by the backward tracer when BR/BCR register-indirect branches are
    # encountered.  They must survive the "@" filter so the variable graph
    # can surface them as dep_var annotation nodes.
    if name_upper.startswith("INDIRECT_CALL@"):
        return False
    if "@" in name_upper:
        return True
    for prefix in _NOISE_PREFIXES:
        if name_upper.startswith(prefix):
            return True
    return False


def _norm_stem(stem: Any) -> str:
    """Lower-case stem. Accepts paths like 'temp/asm/xh88.asm' as well as bare stems."""
    s = str(stem or "").strip()
    if not s:
        return ""
    # If it looks like a path or has an extension, take the file stem.
    if "/" in s or "\\" in s or "." in s:
        s = Path(s).stem
    return s.lower()


def _location_key(loc: Dict[str, Any]) -> Tuple:
    return (
        str(loc.get("file") or ""),
        str(loc.get("block_id") or ""),
        int(loc.get("line") or 0),
        str(loc.get("instruction") or ""),
        str(loc.get("role") or ""),
    )


def _add_location_unique(loc_list: List[Dict[str, Any]], seen: Set[Tuple], loc: Dict[str, Any]) -> None:
    key = _location_key(loc)
    if key in seen:
        return
    seen.add(key)
    loc_list.append(loc)


def _pick_primary_rcl(rcl: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    """Pick the most informative entry from relevant_code_lines (lowest line, has inst)."""
    best: Optional[Dict[str, Any]] = None
    for item in rcl or []:
        line = int(item.get("line") or 0)
        if line <= 0:
            continue
        if best is None or int(best.get("line") or 0) > line:
            best = item
    return best or {}


def build_variable_graph_from_tuples(
    tuples: List[Dict[str, Any]],
    scope_files: Iterable[str],
    *,
    root_variable: str,
    chain_files: List[str],
    chain_hash: str,
    caps: Dict[str, Any],
    warnings: Optional[List[str]] = None,
    terminal_roles: Optional[Dict[str, Dict[str, Any]]] = None,
    step_reasons: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """Walk completed traversal tuples and produce a `{nodes, edges}` graph.

    Arguments:
        tuples: list of dicts as returned by `ChunkedBackwardSession.assemble_tuple`.
        scope_files: collection of file stems considered in-scope. Locations
            whose `file` is outside this set are dropped (defense in depth —
            `filter_tuple_to_scope` should already have done this upstream).
        root_variable: the variable the user originally asked about.
        chain_files / chain_hash / caps: passed through into the result.
        warnings: optional list of upstream warnings to merge into the output
            (deduplicated, order-preserving).
        terminal_roles: optional dict mapping upper var_name → classification record
            (as returned by classify_terminal_variables). When provided, leaf nodes
            are annotated with terminal_role / terminal_role_confidence /
            terminal_role_evidence / declared_in.
        step_reasons: optional dict mapping file_stem → one-line reason (from the
            lineage_reasoning scaffold) so each node carries a `reason` field for
            the frontend step-by-step reveal.
    """
    scope_lower: Set[str] = {_norm_stem(s) for s in (scope_files or []) if s}
    root_up = _normalize_var(root_variable)
    step_reasons_norm: Dict[str, str] = {
        _norm_stem(k): str(v) for k, v in (step_reasons or {}).items() if k
    }

    nodes: Dict[str, Dict[str, Any]] = {}
    node_loc_seen: Dict[str, Set[Tuple]] = {}
    node_step_order: Dict[str, int] = {}  # var_name → first tuple index it appears
    edges: Dict[Tuple[str, str], Dict[str, Any]] = {}
    edge_loc_seen: Dict[Tuple[str, str], Set[Tuple]] = {}
    edge_step_order: Dict[Tuple[str, str], int] = {}

    def _ensure_node(name_upper: str, *, is_root: bool = False) -> Dict[str, Any]:
        node = nodes.get(name_upper)
        if node is None:
            node = {"name": name_upper, "is_root": False, "locations": []}
            nodes[name_upper] = node
            node_loc_seen[name_upper] = set()
        if is_root:
            node["is_root"] = True
        return node

    def _record_node_location(node_name: str, loc: Dict[str, Any]) -> None:
        if _norm_stem(loc.get("file")) not in scope_lower:
            return
        if not loc.get("file") or not loc.get("block_id"):
            return
        _add_location_unique(nodes[node_name]["locations"], node_loc_seen[node_name], loc)

    def _record_edge(source: str, target: str, loc: Dict[str, Any]) -> None:
        if _norm_stem(loc.get("file")) not in scope_lower:
            return
        if source == target:
            return  # ignore self-loops; they're never informative for this graph
        key = (source, target)
        edge = edges.get(key)
        if edge is None:
            edge = {"source": source, "target": target, "locations": []}
            edges[key] = edge
            edge_loc_seen[key] = set()
        if loc.get("file") and loc.get("block_id"):
            _add_location_unique(edge["locations"], edge_loc_seen[key], loc)

    # Always seed the root node so it appears even if no setter sites exist.
    _ensure_node(root_up, is_root=True)

    for tup_idx, tup in enumerate(tuples or []):
        owning_var = _normalize_var(tup.get("variable"))
        if not owning_var or _is_noise(owning_var):
            continue
        file_stem = _norm_stem(tup.get("file_stem"))
        if not file_stem:
            continue
        if file_stem not in scope_lower:
            # Defense in depth — the upstream filter_tuple_to_scope should have
            # dropped these, but if anything slips through we ignore it.
            continue

        file_type = str(tup.get("file_type") or "asm").lower()
        owning_node = _ensure_node(owning_var, is_root=(owning_var == root_up))
        if owning_var not in node_step_order:
            node_step_order[owning_var] = tup_idx

        # --- ASM path: per-block call_graph nodes with dependent_variables -----
        if file_type != "cpp":
            for node in tup.get("nodes") or []:
                block_id = str(node.get("id") or "")
                if not block_id:
                    continue
                primary = _pick_primary_rcl(node.get("relevant_code_lines") or [])
                base_loc = {
                    "file": file_stem,
                    "block_id": block_id,
                    "line": int(primary.get("line") or 0),
                    "instruction": str(primary.get("inst") or "").upper(),
                    "role": str(primary.get("role") or ""),
                }
                _record_node_location(owning_var, base_loc)

                for dv in node.get("dependent_variables") or []:
                    dv_up = _normalize_var(dv)
                    if not dv_up or _is_noise(dv_up):
                        continue
                    if dv_up == owning_var:
                        continue
                    _ensure_node(dv_up)
                    if dv_up not in node_step_order:
                        node_step_order[dv_up] = tup_idx
                    edge_key = (owning_var, dv_up)
                    if edge_key not in edge_step_order:
                        edge_step_order[edge_key] = tup_idx
                    edge_loc = {
                        "file": file_stem,
                        "block_id": block_id,
                        "line": int(primary.get("line") or 0),
                        "instruction": str(primary.get("inst") or "").upper(),
                    }
                    _record_edge(owning_var, dv_up, edge_loc)
            continue

        # --- C++ path: dep_vars come from the lineage_trace in phase_metadata --
        phase_meta = tup.get("phase_metadata") or {}
        cpp_trace = phase_meta.get("lineage_trace") or phase_meta.get("cpp_lineage_trace") or {}

        # Record an owning-var location per enclosing function we see in nodes.
        for node in tup.get("nodes") or []:
            enc = str(node.get("id") or "")
            if not enc:
                continue
            _record_node_location(
                owning_var,
                {
                    "file": file_stem,
                    "block_id": enc,
                    "line": 0,
                    "instruction": "CPP",
                    "role": "cpp_function",
                },
            )

        # Edge for every dep_var the C++ tracer surfaced for this owning_var.
        dep_vars_seen: List[str] = []
        for dv in cpp_trace.get("dep_vars") or []:
            dv_str = str(dv or "").strip()
            if not dv_str:
                continue
            if dv_str.startswith("bridge_back_to_asm:"):
                continue
            dv_up = _normalize_var(dv_str)
            if not dv_up or _is_noise(dv_up):
                continue
            if dv_up == owning_var:
                continue
            dep_vars_seen.append(dv_up)

        if not dep_vars_seen:
            continue

        # If we have at least one enc_fn node, anchor edge locations there.
        # Otherwise, fall back to a file-only location (block_id="<file>").
        anchor_blocks = [
            str(n.get("id") or "")
            for n in (tup.get("nodes") or [])
            if n.get("id")
        ] or [file_stem]

        for dv_up in dep_vars_seen:
            _ensure_node(dv_up)
            if dv_up not in node_step_order:
                node_step_order[dv_up] = tup_idx
            edge_key = (owning_var, dv_up)
            if edge_key not in edge_step_order:
                edge_step_order[edge_key] = tup_idx
            for enc in anchor_blocks:
                _record_edge(
                    owning_var,
                    dv_up,
                    {
                        "file": file_stem,
                        "block_id": enc,
                        "line": 0,
                        "instruction": "CPP",
                    },
                )

    sorted_nodes = sorted(
        nodes.values(),
        key=lambda n: (not n["is_root"], n["name"]),
    )
    for n in sorted_nodes:
        n["locations"] = sorted(n["locations"], key=_location_key)
        name = n.get("name", "")
        n["step_order"] = node_step_order.get(name, 0)
        # Attach reason from step_reasons if available (keyed by file stem, best effort)
        n["reason"] = ""

    sorted_edges = sorted(
        edges.values(),
        key=lambda e: (e["source"], e["target"]),
    )
    for e in sorted_edges:
        e["locations"] = sorted(e["locations"], key=_location_key)
        key = (e["source"], e["target"])
        e["step_order"] = edge_step_order.get(key, 0)
        e["reason"] = ""

    deduped_warnings: List[str] = []
    if warnings:
        seen_w: Set[str] = set()
        for w in warnings:
            s = str(w or "")
            if s and s not in seen_w:
                seen_w.add(s)
                deduped_warnings.append(s)

    # Annotate leaf nodes and collect terminal_classifications list.
    # A leaf is a node that never appears as an edge source (nothing flows from it).
    terminal_roles_norm: Dict[str, Dict[str, Any]] = {}
    if terminal_roles:
        terminal_roles_norm = {
            str(k or "").upper(): v
            for k, v in terminal_roles.items()
        }

    source_names: Set[str] = {e["source"] for e in sorted_edges}
    terminal_classifications_list: List[Dict[str, Any]] = []

    for n in sorted_nodes:
        name = str(n.get("name") or "")
        if name in source_names or n.get("is_root"):
            continue  # not a leaf
        rec = terminal_roles_norm.get(name)
        if rec:
            n["terminal_role"] = rec.get("role")
            n["terminal_role_confidence"] = rec.get("confidence")
            n["terminal_role_evidence"] = rec.get("evidence")
            n["declared_in"] = rec.get("declared_in")
            terminal_classifications_list.append(rec)

    return {
        "schema_version": SCHEMA_VERSION,
        "root_variable": root_up,
        "chain_files": list(chain_files or []),
        "chain_hash": str(chain_hash or ""),
        "caps": dict(caps or {}),
        "computed_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "node_count": len(sorted_nodes),
        "edge_count": len(sorted_edges),
        "nodes": sorted_nodes,
        "edges": sorted_edges,
        "warnings": deduped_warnings,
        "terminal_classifications": terminal_classifications_list,
    }
