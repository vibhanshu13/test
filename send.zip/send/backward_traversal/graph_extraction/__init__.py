"""Variable-graph extraction over assembled backward-traversal tuples."""

from backward_traversal.graph_extraction.variable_graph_builder import (
    SCHEMA_VERSION,
    build_variable_graph_from_tuples,
)

__all__ = ["SCHEMA_VERSION", "build_variable_graph_from_tuples"]
