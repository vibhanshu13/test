"""Cross-file bridge helpers for backward-only mode."""
