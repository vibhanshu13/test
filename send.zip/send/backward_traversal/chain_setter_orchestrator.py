"""Chain-scoped multi-setter orchestrator (engine glue — NO LLM, NO DB).

Given a FIXED file chain (e.g. aa71 → dw730000 → dw710000, entry function
``callPlasticAuthenticationComponentInterface``) and a variable, this:

  1. finds EVERY setter of the variable           (find_setter_locations)
  2. keeps only those REACHABLE from the chain     (route_finder.find_routes:
     parent = chain entry function, child = setter function)
  3. for each reachable setter, enumerates the FLOWS (chains) from the chain
     entry to the setter — there can be several
  4. builds the boolean rule for the setter:
         OR over flows of  AND( setter-local guards , per-hop call-edge guards )
     reusing ``compute_call_conditions`` (cross-file AND/OR already built in) for
     each hop and the setter's own ``conditional_context`` for the local guards.

Everything is deterministic; the LLM layer (separate module) only PHRASES the
leaves per mode.  Reuses the chain-files backward lineage primitives — NOT the
chainless setter_analysis path.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Boolean rule model  (op = "AND" | "OR"; leaves carry condition text + refs)
# ---------------------------------------------------------------------------

def _leaf(text: str, *, line: Optional[int] = None, opcode: str = "", file: str = "") -> Dict[str, Any]:
    return {"kind": "cond", "text": text, "line": line, "opcode": opcode, "file": file}

def _grp(op: str, items: List[Dict[str, Any]], label: str = "") -> Dict[str, Any]:
    return {"op": op, "label": label, "items": items}


# ---------------------------------------------------------------------------
# Per-hop call-edge conditions  (reuses compute_call_conditions: cross-file AND/OR)
# ---------------------------------------------------------------------------

def _edge_conditions(caller: str, callee: str, blueprint_dir: Path,
                     asm_dir: Optional[Path]) -> List[Dict[str, Any]]:
    """Conditions in ``caller`` that gate the call into ``callee`` — as rule leaves.

    ``compute_call_conditions`` already AND's intra-function guards and OR's
    across multiple call sites / predecessors / BAS callers, so each returned
    condition string is a ready leaf (it may itself contain ' AND '/' OR ')."""
    try:
        from get_call_conditions import compute_call_conditions
    except Exception as exc:  # pragma: no cover
        logger.debug("compute_call_conditions unavailable: %s", exc)
        return []
    try:
        # max_depth=0 → INTRA-function/block guards only.  The chain is fixed, so
        # we do NOT want compute_call_conditions to re-walk every caller (its
        # inter-procedural recursion explodes into huge redundant OR(caller)
        # trees).  We AND the per-hop intra guards along the known chain ourselves.
        res = compute_call_conditions(caller, callee, blueprint_dir, asm_dir, max_depth=0)
    except Exception as exc:
        logger.debug("edge conditions %s->%s failed: %s", caller, callee, exc)
        return []
    leaves: List[Dict[str, Any]] = []
    seen = set()
    for site in res.get("call_sites", []):
        for c in site.get("conditions", []):
            txt = str(c.get("condition") or "").strip()
            if not txt or txt in seen:
                continue
            seen.add(txt)
            leaves.append(_leaf(txt, line=c.get("line_no"), opcode=str(c.get("opcode") or ""),
                                file=caller))
    return leaves


# ---------------------------------------------------------------------------
# Setter-local guards  (the if/switch/guard chain at the setter line)
# ---------------------------------------------------------------------------

def _setter_local_conditions(setter_file: str, setter_line: int, function: str,
                             file_type: str, blueprint_dir: Path,
                             asm_dir: Optional[Path]) -> List[Dict[str, Any]]:
    """The guards at the setter site itself (NOT a cross-file call — the setter's
    own enclosing if/switch/guard chain).  Reuses the same condition extractor
    used for call sites, evaluated at the setter line."""
    src = None
    if asm_dir:
        ext = ".cpp" if file_type == "cpp" else ".asm"
        cand = Path(asm_dir) / f"{setter_file}{ext}"
        if cand.exists():
            src = cand
    if src is None:
        return []
    try:
        if file_type == "cpp":
            from get_call_conditions import _cpp_intra_function_conditions
            raw = _cpp_intra_function_conditions(src, int(setter_line))
        else:
            from get_call_conditions import _asm_call_site_conditions
            from blueprint_io import load_blueprint
            bp = load_blueprint(blueprint_dir / f"{setter_file}.asm.json")
            raw = _asm_call_site_conditions(bp, int(setter_line))
    except Exception as exc:
        logger.debug("setter-local conds failed %s:%s: %s", setter_file, setter_line, exc)
        return []
    out, seen = [], set()
    for c in raw:
        txt = str(c.get("condition") or "").strip()
        if txt and txt not in seen:
            seen.add(txt)
            out.append(_leaf(txt, line=c.get("line_no"), opcode=str(c.get("opcode") or ""),
                             file=setter_file))
    return out


# ---------------------------------------------------------------------------
# One reachable setter → its flows + boolean rule
# ---------------------------------------------------------------------------

@dataclass
class FlowResult:
    files: List[str]
    hops: List[Dict[str, Any]]                 # route_finder hops (for step-by-step)
    edge_conditions: List[Dict[str, Any]] = field(default_factory=list)

@dataclass
class SetterResult:
    file: str
    function: str
    line: int
    file_type: str
    value: str
    flows: List[FlowResult] = field(default_factory=list)
    setter_local: List[Dict[str, Any]] = field(default_factory=list)
    rule: Dict[str, Any] = field(default_factory=dict)
    lineage: Dict[str, Any] = field(default_factory=dict)
    reachable: bool = True


def _build_rule(setter_local: List[Dict[str, Any]],
                flows: List[FlowResult]) -> Dict[str, Any]:
    """OR over flows of AND(setter-local, hop guards…)."""
    flow_clauses: List[Dict[str, Any]] = []
    for fl in flows:
        items = list(fl.edge_conditions)
        if items:
            flow_clauses.append(_grp("AND", items,
                                     label="reached via " + " → ".join(fl.files)))
    top_items: List[Dict[str, Any]] = list(setter_local)
    if len(flow_clauses) == 1:
        top_items.extend(flow_clauses[0]["items"])
    elif len(flow_clauses) > 1:
        top_items.append(_grp("OR", flow_clauses, label="AND reached via any one of these flows"))
    return _grp("AND", top_items, label="ALL of the following must hold")


# ---------------------------------------------------------------------------
# Lazy callsite map — per-edge DB queries on demand
# ---------------------------------------------------------------------------

class _LazyCallsiteMap:
    """Dict-like wrapper that loads call-site dicts per (source, target) edge
    on first access via the index DB.

    A typical chain has 2–5 files → 2–8 edge lookups total — trivial DB cost
    compared to preloading the full 200–400 MB callsite dict for all 50K+ edges.
    """

    __slots__ = ("_job_id", "_cache")

    def __init__(self, job_id: str) -> None:
        self._job_id = job_id
        self._cache: Dict[Tuple[str, str], list] = {}

    def get(self, key, default=None):  # type: ignore[override]
        if key not in self._cache:
            from api.index_db.readers import get_call_graph_callsites_for_edge
            src, tgt = key
            self._cache[key] = get_call_graph_callsites_for_edge(
                self._job_id, src, tgt,
            )
        result = self._cache[key]
        return result if result else default


# ---------------------------------------------------------------------------
# Core analysis
# ---------------------------------------------------------------------------

def analyze_chain_setters(
    variable: str,
    *,
    chain_prefix: List[str],
    entry_file: str,
    entry_function: str,
    entry_type: str = "cpp",
    blueprint_dir: Path,
    graph_file: Path,
    asm_dir: Optional[Path] = None,
    job_id: Optional[str] = None,
    max_setters: int = 0,
    max_dep_var_depth: int = 1,
    max_depth: int = 4,
    max_routes: int = 20,
    max_caller_depth: int = 12,
) -> Dict[str, Any]:
    """Return the chain-scoped multi-setter structural result (no LLM)."""
    from backward_traversal.setter_locations import find_setter_locations
    from backward_traversal.route_finder import Endpoint, find_routes

    blueprint_dir = Path(blueprint_dir)
    graph_file = Path(graph_file)

    # ── PERF: DB-backed streaming index path (22K-file optimisation) ───────
    # Build all index structures via ONE streaming pass over the DB rows
    # instead of loading the 100–300 MB file_call_graph.json into a 400–1200 MB
    # Python dict.  Peak RAM: ~240 MB (indexes only) vs ~1.1 GB (legacy).
    _db_indexes = None
    if job_id:
        try:
            from api.index_db.readers import build_call_graph_indexes
            _db_indexes = build_call_graph_indexes(
                job_id, fallback_path=graph_file)
        except Exception:
            logger.debug("build_call_graph_indexes failed; falling back to "
                         "monolithic graph_payload", exc_info=True)

    if _db_indexes is not None:
        # Fast path: all indexes from DB — graph_payload never materialised.
        graph_payload: Dict[str, Any] = {}  # empty sentinel — never read
        reverse_adj = _db_indexes["reverse_adj"]
        node_type = _db_indexes["node_type"]
        _forward_adj = _db_indexes["forward_adj"]
        prebuilt_index_maps: Dict[str, Any] = {
            "file_type_map": _db_indexes["file_type_map"],
            "edge_type_map": _db_indexes["edge_type_map"],
            "edge_lines_map": _db_indexes["edge_lines_map"],
            "callsite_map": _LazyCallsiteMap(job_id),
        }
    else:
        # Legacy path: load the full graph_payload and build indexes from it.
        from backward_traversal.runner.chainless_runner import _load_graph_payload
        from backward_traversal.runner.chainless_caller_walker import build_reverse_adjacency

        graph_payload = _load_graph_payload(graph_file, job_id)
        reverse_adj, node_type = build_reverse_adjacency(graph_payload)
        _forward_adj = None  # signal _forward_reachable_files to build from graph_payload

        from backward_traversal.runner.backward_only_runner import (
            _edge_type_map, _edge_lines_map, _edge_callsite_map,
        )
        _file_type_map: Dict[str, str] = {}
        for _n in graph_payload.get("nodes", []):
            _nid = str(_n.get("id") or "")
            _t = str(_n.get("type") or "asm")
            _file_type_map[_nid] = _t
            _file_type_map[_nid.lower()] = _t
        prebuilt_index_maps = {
            "file_type_map": _file_type_map,
            "edge_type_map": _edge_type_map(graph_payload),
            "edge_lines_map": _edge_lines_map(graph_payload),
            "callsite_map": _edge_callsite_map(graph_payload),
        }

    # PERF: shared blueprint caches — reused across all setters so the same
    # blueprint is never re-read from disk.  _pfl_cache holds per-file C++
    # lineage dicts; reach_cache holds intra-file forward-adjacency results.
    # Both are plain dicts; thread-safe for simple get/set under the GIL.
    _pfl_cache: Dict[str, Any] = {}
    reach_cache: Dict[str, Any] = {}

    loc = find_setter_locations(variable, blueprint_dir=blueprint_dir, graph_file=graph_file,
                                asm_dir=asm_dir, job_id=job_id)
    all_setters = (
        [{**s, "file_type": "cpp"} for s in loc.get("cpp_setters", [])]
        + [{**s, "file_type": "asm", "function": None} for s in loc.get("asm_setters", [])]
    )

    # PERF: cheap forward file-reachability from the entry file, computed ONCE.
    # A setter whose file isn't even forward-reachable from the chain entry can be
    # skipped WITHOUT the expensive per-setter find_routes() backward walk.
    fwd_reach = _forward_reachable_files(entry_file, graph_file, job_id,
                                         graph_payload=graph_payload,
                                         forward_adj=_forward_adj)

    parent = Endpoint(entry_file, entry_type, entry_function)

    # cheap prefilter — skip setters whose file isn't forward-reachable.
    candidates: List[Dict[str, Any]] = []
    skipped_unreachable = 0
    for s in all_setters:
        if fwd_reach and s["file"].lower() not in fwd_reach:
            skipped_unreachable += 1
        else:
            candidates.append(s)

    # Cap candidates to avoid submitting more work than needed.
    if max_setters:
        candidates = candidates[:max_setters * 3]   # overshoot: some may be unreachable

    # ── per-setter worker (thread-safe: shared dicts are read-safe under GIL,
    # writes to plain dicts are atomic for simple key assignment) ──────────
    def _process_one_setter(s: Dict[str, Any]) -> Optional[SetterResult]:
        child = Endpoint(s["file"], s["file_type"], s.get("function"))
        rf = find_routes(parent, child, blueprint_dir=blueprint_dir, graph_file=graph_file,
                         asm_dir=asm_dir, job_id=job_id, max_routes=max_routes,
                         max_caller_depth=max_caller_depth,
                         graph_payload=graph_payload, reverse_adj=reverse_adj,
                         node_type=node_type,
                         _pfl_cache=_pfl_cache, reach_cache=reach_cache)
        if not rf.get("reachable"):
            return None

        sr = SetterResult(file=s["file"], function=s.get("function") or "", line=s["line"],
                          file_type=s["file_type"], value=str(s.get("expression") or ""))

        lineage_detail = None
        for route in (rf.get("routes") or [{"files": [entry_file, s["file"]], "hops": []}]):
            rfiles = route.get("files") or [entry_file, s["file"]]
            full = _dedup_seq(list(chain_prefix) + rfiles)
            pay = run_chain_lineage(variable, full, blueprint_dir, graph_file, asm_dir,
                            max_depth=max_depth, max_dep_var_depth=max_dep_var_depth,
                            graph_payload=graph_payload,
                            prebuilt_index_maps=prebuilt_index_maps,
                            _tmp_base=_tmp_base, _tmp_counter=_tmp_counter)
            if lineage_detail is None:
                lineage_detail = pay
                sr.value = pay.get("setter_value") or sr.value
                sr.setter_local = [_leaf(c) for c in pay.get("setter_local_conditions", [])]
            sr.flows.append(FlowResult(
                files=full, hops=route.get("hops") or [],
                edge_conditions=_dedup_leaves([_leaf(c) for c in pay.get("chain_conditions", [])])))

        sr.flows = _dedup_flows(sr.flows)
        sr.rule = _build_rule(sr.setter_local, sr.flows)
        sr.lineage = lineage_detail or {}
        return sr

    # ── parallel execution ────────────────────────────────────────────────
    import itertools, tempfile
    from concurrent.futures import ThreadPoolExecutor, as_completed

    results: List[SetterResult] = []
    _WORKERS = min(4, len(candidates)) if candidates else 1

    # PERF: one shared temp directory for all run_chain_lineage calls —
    # avoids 1000+ mkdtemp/rmtree cycles on a 500-setter analysis.
    _tmp_base = Path(tempfile.mkdtemp(prefix="chainsetter_"))
    _tmp_counter = itertools.count()

    try:
        with ThreadPoolExecutor(max_workers=_WORKERS) as pool:
            future_to_setter = {pool.submit(_process_one_setter, s): s for s in candidates}
            for fut in as_completed(future_to_setter):
                try:
                    sr = fut.result()
                except Exception:
                    logger.debug("setter processing failed for %s", future_to_setter[fut].get("file"), exc_info=True)
                    sr = None
                if sr is None:
                    skipped_unreachable += 1
                    continue
                results.append(sr)
                if max_setters and len(results) >= max_setters:
                    # Cancel remaining futures to avoid wasted work.
                    for pending in future_to_setter:
                        pending.cancel()
                    break
    finally:
        import shutil
        shutil.rmtree(_tmp_base, ignore_errors=True)

    return {
        "variable": variable,
        "chain_prefix": chain_prefix,
        "entry": {"file": entry_file, "function": entry_function},
        "n_setters_total": len(all_setters),
        "n_reachable": len(results),
        "n_unreachable": skipped_unreachable,
        "setters": [_setter_to_dict(r) for r in results],
    }


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def run_chain_lineage(
    variable: str, full_chain: List[str], blueprint_dir: Path, graph_file: Path,
    asm_dir: Optional[Path], *, max_depth: int = 4, max_dep_var_depth: int = 1,
    max_downstream_depth: int = 0,
    graph_payload: Optional[Dict[str, Any]] = None,
    prebuilt_index_maps: Optional[Dict[str, Any]] = None,
    _tmp_base: Optional[Path] = None,
    _tmp_counter: Optional[Any] = None,
) -> Dict[str, Any]:
    """Run the chain-files backward lineage over ``full_chain`` and return a
    trimmed structural payload: setter site, setter-local guards, dependent
    variables (each with its own setter + conditions, one level), the variable
    graph, and the per-file step results.  Pure reuse of ``run_backward_only``.

    Depth is bounded for speed: we need the setter + its conditions + one level of
    dep-var setters/conditions + the chain steps — not a deep recursive forest.

    Pass pre-loaded ``graph_payload`` to avoid redundant I/O.
    Pass ``prebuilt_index_maps`` (file_type_map, edge_type_map, edge_lines_map,
    callsite_map) to avoid each thread rebuilding ~220 MB of index data.

    Pass ``_tmp_base`` / ``_tmp_counter`` from the orchestrator to reuse a
    shared temp directory instead of creating one per invocation.
    """
    import json as _json
    from backward_traversal.runner.backward_only_runner import run_backward_only

    owns_tmp = _tmp_base is None
    if owns_tmp:
        import tempfile
        tmp = Path(tempfile.mkdtemp(prefix="chainsetter_"))
    else:
        n = next(_tmp_counter) if _tmp_counter is not None else id(full_chain)
        tmp = _tmp_base / str(n)
        tmp.mkdir(exist_ok=True)

    idx = prebuilt_index_maps or {}
    try:
        run_backward_only(variable.upper(), list(full_chain), Path(blueprint_dir), asm_dir,
                          Path(graph_file), tmp, max_depth=max_depth,
                          max_dep_var_depth=max_dep_var_depth,
                          max_downstream_depth=max_downstream_depth,
                          graph_payload=graph_payload,
                          prebuilt_file_type_map=idx.get("file_type_map"),
                          prebuilt_edge_type_map=idx.get("edge_type_map"),
                          prebuilt_edge_lines_map=idx.get("edge_lines_map"),
                          prebuilt_callsite_map=idx.get("callsite_map"))
        rv = _json.loads((tmp / "root_var.json").read_text()) if (tmp / "root_var.json").exists() else {}
        mod = rv.get("modifier_file") or (full_chain[-1] if full_chain else "")
        files = rv.get("files") or {}
        fr = files.get(mod) or files.get(str(mod).lower()) or {}
        modr = (fr.get("modifier") or {}) if isinstance(fr, dict) else {}
        setter_sites = modr.get("setter_sites") or []
        ss0 = setter_sites[0] if setter_sites else {}

        # Setter-local guards = the setter site's own conditional_context (clean).
        setter_local = [str(c) for c in (ss0.get("conditional_context") or [])]
        # Chain conditions = the call-chain guards along the fixed chain.
        chain_conds: List[str] = []
        for cc in (modr.get("call_chain_conditions") or []):
            chain_conds.extend(str(c) for c in (cc.get("conditions") or []))
        # Supplement ASM-source edge guards (run_backward_only misses some ASM
        # cross-file guards, e.g. the TM @CASVIS1/L7DSTS tests before an ENTRC);
        # compute_call_conditions(max_depth=0) supplies them, intra-block only.
        try:
            from get_call_conditions import compute_call_conditions
            for a, b in zip(full_chain, full_chain[1:]):
                if not (Path(blueprint_dir) / f"{a}.asm.json").exists():
                    continue
                res = compute_call_conditions(a, b, Path(blueprint_dir), asm_dir, max_depth=0)
                for site in res.get("call_sites", []):
                    for c in site.get("conditions", []):
                        t = str(c.get("condition") or "").strip()
                        if t:
                            chain_conds.append(t)
        except Exception:
            pass
        chain_conds = list(dict.fromkeys(chain_conds))   # dedup, keep order

        # Dependent variables = the actually-traced dep-var files (authoritative),
        # each with its own setter + conditions found anywhere it was traced.
        dep_vars: List[Dict[str, Any]] = []
        ddir = tmp / "dep_vars"
        if ddir.exists():
            for f in sorted(ddir.glob("*.json")):
                dep_vars.append(_parse_dep_var_file(_json.loads(f.read_text())))

        # Variable lineage graph: root → dep vars → (their sub-deps).  Built from
        # the dep tree (NOT the file-flow graph).
        graph = _build_var_graph(variable, dep_vars)

        steps = []
        for stem in full_chain:
            f2 = files.get(stem) or files.get(stem.lower()) or {}
            steps.append({"file": stem, "role": "modifier" if stem == mod else "upstream",
                          "file_type": f2.get("file_type")})

        value = ""
        expr = str(ss0.get("expression") or "")
        if "=" in expr:
            value = expr.split("=", 1)[1].strip().replace("\n", " ")
        return {
            "setter_value": value,
            "setter_local_conditions": setter_local,
            "chain_conditions": chain_conds,
            "dep_vars": dep_vars,
            "graph": graph,
            "steps": steps,
        }
    finally:
        if owns_tmp:
            import shutil
            shutil.rmtree(tmp, ignore_errors=True)


def _parse_dep_var_file(dd: Dict[str, Any]) -> Dict[str, Any]:
    """A traced dep-var → {name, setter, conditions, sub_deps, terminal}.

    Searches all three result buckets (chain / downstream / extended) for the
    dep-var's own modifier (its setter is often outside the main chain, e.g. a
    field copied in movePaCommonFields)."""
    name = dd.get("dep_var") or ""
    setter = None
    conditions: List[str] = []
    sub_deps: List[str] = []
    for bucket in ("chain_file_results", "downstream_file_results", "extended_file_results"):
        results = dd.get(bucket)
        if not isinstance(results, dict):
            continue
        for fstem, fres in results.items():
            m = (fres or {}).get("modifier") or {}
            ss = m.get("setter_sites") or []
            if ss and setter is None:
                setter = {"file": _stem_name(ss[0].get("file")), "line": ss[0].get("line"),
                          "routine": ss[0].get("routine"),
                          "value": _rhs(ss[0].get("expression"))}
                conditions = [str(c) for c in (ss[0].get("conditional_context") or [])]
            tr = m.get("cpp_lineage_trace") or {}
            for sd in (tr.get("dep_vars") or []):
                if isinstance(sd, str) and sd != name and sd not in sub_deps:
                    sub_deps.append(sd)
    return {"name": name, "setter": setter, "conditions": conditions,
            "sub_deps": sub_deps[:8], "terminal": setter is None}


def _rhs(expr: Optional[str]) -> str:
    e = str(expr or "")
    return e.split("=", 1)[1].strip().replace("\n", " ") if "=" in e else ""


def _forward_reachable_files(entry_file: str, graph_file: Path,
                             job_id: Optional[str],
                             graph_payload: Optional[Dict[str, Any]] = None,
                             forward_adj: Optional[Dict[str, set]] = None) -> set:
    """Lower-cased set of files forward-reachable from ``entry_file`` over the
    call graph (entry included).  Empty set ⇒ couldn't compute ⇒ no prefilter.

    Pass pre-built ``forward_adj`` (from ``build_call_graph_indexes``) to skip
    building it from ``graph_payload``.  Pass pre-loaded ``graph_payload`` to
    avoid redundant I/O."""
    from collections import deque

    fwd = forward_adj
    if fwd is None:
        # Legacy path: build forward adjacency from graph_payload
        if graph_payload is None:
            try:
                from backward_traversal.runner.chainless_runner import _load_graph_payload
                graph_payload = _load_graph_payload(Path(graph_file), job_id)
            except Exception:
                return set()
        fwd = {}
        for e in (graph_payload.get("edges") or []):
            src = str(e.get("source") or "").lower()
            tgt = str(e.get("target") or "").lower()
            if src and tgt:
                fwd.setdefault(src, set()).add(tgt)
            for cs in (e.get("call_sites") or []):
                tm = str(cs.get("target_module") or "").lower()
                if src and tm:
                    fwd.setdefault(src, set()).add(tm)
    if not fwd:
        return set()
    start = entry_file.lower()
    seen = {start}
    q = deque([start])
    while q:
        cur = q.popleft()
        for nxt in fwd.get(cur, ()):
            if nxt not in seen:
                seen.add(nxt)
                q.append(nxt)
    return seen


def _build_var_graph(root: str, dep_vars: List[Dict[str, Any]]) -> Dict[str, Any]:
    """root → dep vars → inferred sub-deps.

    Sub-deps are inferred two ways:
    1. Explicitly listed in dep_var["sub_deps"] (from cpp_lineage_trace).
    2. A dep-var X appears in the conditions of dep-var Y → X is a sub-dep of Y.
       This recovers relationships like EXITINDICATOR→RETURNCODE where the setter
       condition of EXITINDICATOR mentions returnCode.
    """
    import re as _re

    # Build a lookup: any dep-var name (upper) → dep-var record.
    dv_upper = {dv["name"].upper(): dv["name"] for dv in dep_vars}

    nodes = [{"id": root, "role": "root"}]
    edges: List[List[str]] = []
    seen = {root}

    # Pass 1: collect all sub-dep assignments.
    sub_dep_of: Dict[str, str] = {}   # child → first parent that claims it
    for dv in dep_vars:
        nm = dv["name"]
        sub: set = set(dv.get("sub_deps", []))
        for cond in dv.get("conditions", []):
            for tok in _re.findall(r"[A-Z_@][A-Z0-9_.]{3,}", str(cond).upper()):
                canonical = dv_upper.get(tok)
                if canonical and canonical != nm:
                    sub.add(canonical)
        for sd in sorted(sub)[:6]:
            if sd not in sub_dep_of:
                sub_dep_of[sd] = nm

    # Pass 2: build graph — only add root→X when X is NOT already someone's sub-dep.
    for dv in dep_vars:
        nm = dv["name"]
        is_claimed_subdep = nm in sub_dep_of
        if nm not in seen:
            seen.add(nm)
            nodes.append({"id": nm, "role": "input" if dv["terminal"] else "system"})
        if not is_claimed_subdep:
            edges.append([root, nm])   # top-level dep only

    # Pass 3: add sub-dep edges.
    for sd, parent in sub_dep_of.items():
        if sd not in seen:
            seen.add(sd)
            sd_dv = next((d for d in dep_vars if d["name"] == sd), None)
            role = "input" if (sd_dv is None or sd_dv.get("terminal", True)) else "system"
            nodes.append({"id": sd, "role": role})
        edges.append([parent, sd])

    return {"root": root, "nodes": nodes, "edges": edges}


def _stem_name(p: Optional[str]) -> str:
    if not p:
        return ""
    n = Path(str(p)).name
    for s in (".cpp", ".asm", ".mac"):
        if n.lower().endswith(s):
            return n[: -len(s)]
    return n


def _dedup_seq(seq: List[str]) -> List[str]:
    out, seen = [], set()
    for x in seq:
        if x not in seen:
            seen.add(x); out.append(x)
    return out

def _dedup_flows(flows: List["FlowResult"]) -> List["FlowResult"]:
    """Collapse flows with the same file sequence AND the same condition set."""
    out, seen = [], set()
    for f in flows:
        sig = (tuple(f.files), tuple(sorted(l.get("text", "") for l in f.edge_conditions)))
        if sig in seen:
            continue
        seen.add(sig)
        out.append(f)
    return out

def _dedup_leaves(leaves: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out, seen = [], set()
    for l in leaves:
        k = l.get("text")
        if k and k not in seen:
            seen.add(k); out.append(l)
    return out

def _setter_to_dict(r: SetterResult) -> Dict[str, Any]:
    return {
        "file": r.file, "function": r.function, "line": r.line, "file_type": r.file_type,
        "value": r.value, "reachable": r.reachable,
        "n_flows": len(r.flows),
        "flows": [{"files": f.files, "n_conditions": len(f.edge_conditions),
                   "edge_conditions": f.edge_conditions, "hops": f.hops} for f in r.flows],
        "setter_local": r.setter_local,
        "rule": r.rule,
        "dep_vars": r.lineage.get("dep_vars", []),
        "variable_graph": r.lineage.get("graph", {}),
        "steps": r.lineage.get("steps", []),
    }
