"""Glossary-driven special-case dependency / setter-semantics rules.

This module is the single source of truth for instruction-level setter semantics
that go beyond plain SETTER_INST membership: self-operand no-ops, identity
immediates, zero-literal no-ops, prior-value read-modify-write dependencies, and
operand suppression.  Both the backward tracer (asm_backward_tracer.py) and the
setter-site emitters (backward_only_runner.py) call `classify_setter` so the two
pipelines cannot drift.  Cited against IBM z/Architecture PoO SA22-7832-12.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Sequence

from backward_traversal.utils.token_utils import normalize_token
from backward_traversal.glossary.instructions import (
    DEST_ARG_INDEX_BY_INST,
    SETTER_INST,
    SRC_ARG_SUPPRESS_BY_INST,
)

# Store-under-mask instructions whose args[1] is the byte-select mask.  A zero mask
# writes no bytes (PoO §7-212/213) — not a setter site.
_STORE_UNDER_MASK = {"STCM", "STCMH", "STCMY"}


# Evaluation order matters: the matcher returns the FIRST match.  Zero-test
# patterns (OC/NC FIELD,FIELD followed by BZ/BNZ) MUST precede their noop
# counterparts (OC/NC FIELD,FIELD with no CC-branch), since all four require
# normalized-equal args and the following CC-branch is the only discriminator.
SPECIAL_DEPENDENCY_PATTERNS: List[Dict[str, Any]] = [
    # EXISTING — must remain FIRST.
    {
        "name": "oc_self_zero_test",
        "inst": "OC",
        # BZ/BNZ: classic form; JZ/JNZ: z/Architecture 64-bit synonyms (PoO §7-181).
        # Both mean "branch on condition-code zero/non-zero" set by the OC.
        "next_insts": {"BZ", "BNZ", "JZ", "JNZ"},
        "dep_arg_indexes": (0,),
        "require_normalized_args_equal": True,
        "role": "CONDITION_CHECK",
    },
    # OC FIELD,FIELD without BZ/BNZ — value unchanged (b|b=b, PoO §7-181).
    {
        "name": "oc_self_noop",
        "inst": "OC",
        "next_insts": set(),
        "dep_arg_indexes": (),
        "require_normalized_args_equal": True,
        "role": "SKIP_SETTER_SITE",
        "skip_setter_site": True,
        "suppress_dep_vars": True,
    },
    # NC FIELD,FIELD followed by BZ/BNZ — zero-test idiom (PoO §7-25).
    # b&b=b so the stored value is unchanged, but CC is set to zero when the
    # result is all-zero bits.  FIELD is therefore a dep_var.  Must precede
    # nc_self_noop (same require_normalized_args_equal guard, BZ/BNZ is the
    # only discriminator).
    {
        "name": "nc_self_zero_test",
        "inst": "NC",
        "next_insts": {"BZ", "BNZ", "JZ", "JNZ"},
        "dep_arg_indexes": (0,),
        "require_normalized_args_equal": True,
        "role": "CONDITION_CHECK",
    },
    # NC FIELD,FIELD without BZ/BNZ — value unchanged (b&b=b, PoO §7-25).
    {
        "name": "nc_self_noop",
        "inst": "NC",
        "next_insts": set(),
        "dep_arg_indexes": (),
        "require_normalized_args_equal": True,
        "role": "SKIP_SETTER_SITE",
        "skip_setter_site": True,
        "suppress_dep_vars": True,
    },
    # ZAP FIELD,FIELD — sign normalization only; digits unchanged (PoO §8-13).
    {
        "name": "zap_self_sign_norm",
        "inst": "ZAP",
        "next_insts": set(),
        "dep_arg_indexes": (),
        "require_normalized_args_equal": True,
        "require_raw_args_equal": True,
        "role": "SKIP_SETTER_SITE",
        "skip_setter_site": True,
        "suppress_dep_vars": True,
    },
    # SP FIELD,FIELD — FIELD−FIELD=0; no external dep (PoO §8-13).
    {
        "name": "sp_self_zero",
        "inst": "SP",
        "next_insts": set(),
        "dep_arg_indexes": (),
        "require_normalized_args_equal": True,
        "role": "SETTER_NO_DEPS",
        "suppress_dep_vars": True,
        "skip_setter_site": False,
    },
    # XC FIELD,FIELD — FIELD XOR FIELD = 0 (PoO §7-142); value becomes zero, prior value
    # is NOT a dependency (result is constant 0 regardless of FIELD's content).  Must
    # precede _RMW_PRIOR_VALUE which would otherwise annotate prior_value_required=True
    # for all XC.  Distinct-source XC FIELD1,FIELD2 reaches _RMW_PRIOR_VALUE correctly.
    {
        "name": "xc_self_zero",
        "inst": "XC",
        "next_insts": set(),
        "dep_arg_indexes": (),
        "require_normalized_args_equal": True,
        "role": "SETTER_NO_DEPS",
        "suppress_dep_vars": True,
        "skip_setter_site": False,
    },
    # AP FIELD,FIELD — doubles value; prior value IS the dep (PoO §8-6).
    {
        "name": "ap_self_double",
        "inst": "AP",
        "next_insts": set(),
        "dep_arg_indexes": (0,),
        "require_normalized_args_equal": True,
        "role": "SETTER_PRIOR_VALUE",
        "suppress_dep_vars": False,
        "prior_value_required": True,
    },
    # MVC FIELD,FIELD (exact raw identity) — no-op copy (PoO §7-163).
    {
        "name": "mvc_self_nop",
        "inst": "MVC",
        "next_insts": set(),
        "dep_arg_indexes": (),
        "require_normalized_args_equal": True,
        "require_raw_args_equal": True,
        "role": "SKIP_SETTER_SITE",
        "skip_setter_site": True,
        "suppress_dep_vars": True,
    },
    # MVC FIELD+1(n),FIELD — propagation idiom; FIELD[0] is dep (PoO §7-163 note 2).
    {
        "name": "mvc_propagation",
        "inst": "MVC",
        "next_insts": set(),
        "dep_arg_indexes": (1,),
        "require_normalized_args_equal": True,
        "require_raw_args_differ": True,
        "role": "SETTER_PRIOR_VALUE",
        "suppress_dep_vars": False,
        "prior_value_required": True,
    },
    # UNPK FIELD(L1),FIELD(L2) — same base symbol but different lengths.
    # Source bytes extend beyond dest → real data dependency on FIELD's prior
    # value that normalize_token cannot distinguish (PoO §8-15).
    # dep_vars_from_args must bypass skip_var for the source operand.
    {
        "name": "unpk_length_differ",
        "inst": "UNPK",
        "next_insts": set(),
        "dep_arg_indexes": (1,),
        "require_normalized_args_equal": True,
        "require_raw_args_differ": True,
        "role": "SETTER_PRIOR_VALUE",
        "suppress_dep_vars": False,
        "prior_value_required": True,
    },
    {
        "name": "unpka_length_differ",
        "inst": "UNPKA",
        "next_insts": set(),
        "dep_arg_indexes": (1,),
        "require_normalized_args_equal": True,
        "require_raw_args_differ": True,
        "role": "SETTER_PRIOR_VALUE",
        "suppress_dep_vars": False,
        "prior_value_required": True,
    },
    {
        "name": "unpku_length_differ",
        "inst": "UNPKU",
        "next_insts": set(),
        "dep_arg_indexes": (1,),
        "require_normalized_args_equal": True,
        "require_raw_args_differ": True,
        "role": "SETTER_PRIOR_VALUE",
        "suppress_dep_vars": False,
        "prior_value_required": True,
    },
    # MP FIELD,FIELD — guaranteed specification exception (PoO §8-11).
    {
        "name": "mp_self_specex",
        "inst": "MP",
        "next_insts": set(),
        "dep_arg_indexes": (),
        "require_normalized_args_equal": True,
        "role": "WARN_AND_SKIP",
        "skip_setter_site": True,
        "suppress_dep_vars": True,
        "warn_message": "MP FIELD,FIELD: specification exception guaranteed per PoO §8-11 (L2 must be less than L1); skipping setter site",
    },
    # DP FIELD,FIELD — guaranteed specification exception (PoO §8-7).
    {
        "name": "dp_self_specex",
        "inst": "DP",
        "next_insts": set(),
        "dep_arg_indexes": (),
        "require_normalized_args_equal": True,
        "role": "WARN_AND_SKIP",
        "skip_setter_site": True,
        "suppress_dep_vars": True,
        "warn_message": "DP FIELD,FIELD: specification exception guaranteed per PoO §8-7 (L2 must be less than L1); skipping setter site",
    },
    # MVCIN FIELD,FIELD — result unpredictable when operands overlap (PoO §7-164).
    {
        "name": "mvcin_self_unpredictable",
        "inst": "MVCIN",
        "next_insts": set(),
        "dep_arg_indexes": (),
        "require_normalized_args_equal": True,
        "role": "WARN_AND_SKIP",
        "skip_setter_site": True,
        "suppress_dep_vars": True,
        "warn_message": "MVCIN FIELD,FIELD: result unpredictable when operands overlap by more than one byte (PoO §7-164); skipping setter site",
    },
    # TR — args[1] is a 256-byte translate table; NOT a data source (PoO §7-225).
    # D1 bytes are the source indices into the table; D1's prior value is the data
    # input for ALL TR forms (self-translate and distinct-source).
    # The self-translate override in classify_setter additionally cancels the table
    # suppression (args[1] == args[0]) for TR FIELD,FIELD.
    # (Suppression also enforced statically via SRC_ARG_SUPPRESS_BY_INST.)
    {
        "name": "tr_suppress_table",
        "inst": "TR",
        "next_insts": set(),
        "dep_arg_indexes": (),
        "require_normalized_args_equal": False,
        "role": "SETTER_STEP",
        "suppress_src_indexes": [1],
        "suppress_dep_vars": False,
        "prior_value_required": True,
    },
    # ── CC-setting decimal arithmetic followed by CC-consuming branch ──────
    # AP/SP/ZAP/MP/DP set CC (PoO §8-3/8-14/8-17/8-9/8-6).
    # When immediately followed by a branch on CC the arithmetic result is
    # a CONDITION_CHECK dependency, not just a setter step.
    # NOTE: The SRP CC-branch pattern MUST come before srp_suppress_nondest
    # because the latter has next_insts=set() (always matches).  First-match
    # semantics require the more specific next_insts-constrained pattern first.
    {
        "name": "srp_cc_branch",
        "inst": "SRP",
        "next_insts": {"BZ", "BNZ", "JZ", "JNZ", "BH", "BNH", "BM", "BNM",
                       "BO", "BNO", "BP", "BNP"},
        "dep_arg_indexes": (0,),
        "require_normalized_args_equal": False,
        "role": "CONDITION_CHECK",
    },
    # SRP — args[1]=shift count, args[2]=rounding digit; both functional (PoO §8-12).
    {
        "name": "srp_suppress_nondest",
        "inst": "SRP",
        "next_insts": set(),
        "dep_arg_indexes": (),
        "require_normalized_args_equal": False,
        "role": "SETTER_STEP",
        "suppress_src_indexes": [1, 2],
        "suppress_dep_vars": False,
        "prior_value_required": True,
    },
    {
        "name": "ap_cc_branch",
        "inst": "AP",
        "next_insts": {"BZ", "BNZ", "JZ", "JNZ", "BH", "BNH", "BM", "BNM",
                       "BO", "BNO", "BP", "BNP"},
        "dep_arg_indexes": (0, 1),
        "require_normalized_args_equal": False,
        "role": "CONDITION_CHECK",
    },
    {
        "name": "sp_cc_branch",
        "inst": "SP",
        "next_insts": {"BZ", "BNZ", "JZ", "JNZ", "BH", "BNH", "BM", "BNM",
                       "BO", "BNO", "BP", "BNP"},
        "dep_arg_indexes": (0, 1),
        "require_normalized_args_equal": False,
        "role": "CONDITION_CHECK",
    },
    {
        "name": "zap_cc_branch",
        "inst": "ZAP",
        "next_insts": {"BZ", "BNZ", "JZ", "JNZ", "BH", "BNH", "BM", "BNM",
                       "BO", "BNO", "BP", "BNP"},
        "dep_arg_indexes": (0, 1),
        "require_normalized_args_equal": False,
        "role": "CONDITION_CHECK",
    },
    {
        "name": "mp_cc_branch",
        "inst": "MP",
        "next_insts": {"BZ", "BNZ", "JZ", "JNZ", "BH", "BNH", "BM", "BNM",
                       "BO", "BNO", "BP", "BNP"},
        "dep_arg_indexes": (0, 1),
        "require_normalized_args_equal": False,
        "role": "CONDITION_CHECK",
    },
    {
        "name": "dp_cc_branch",
        "inst": "DP",
        "next_insts": {"BZ", "BNZ", "JZ", "JNZ", "BH", "BNH", "BM", "BNM",
                       "BO", "BNO", "BP", "BNP"},
        "dep_arg_indexes": (0, 1),
        "require_normalized_args_equal": False,
        "role": "CONDITION_CHECK",
    },
]

# Union of all non-empty next_insts sets from SPECIAL_DEPENDENCY_PATTERNS.
# Used by _collect_special_case_dep_vars in asm_backward_tracer.py to detect
# cross-block CC-sensitive branch followers without hardcoding the set separately.
# Adding a new zero-test pattern with novel branch mnemonics automatically updates
# this set — no manual sync required.
PATTERN_NEXT_INSTS: frozenset = frozenset(
    mnemonic
    for pat in SPECIAL_DEPENDENCY_PATTERNS
    for mnemonic in (pat.get("next_insts") or set())
)


# Instructions whose write is a read-modify-write: the prior value of the
# destination field is itself a dependency.
#   NI/OI/XI/NIY/OIY/XIY  PoO §7-25/180/142 — D1_new = D1_old OP I2
#   NC/OC/XC               PoO §7-25/181/142 — D1_new = D1_old OP D2 (SS form);
#                          self-op patterns (nc/oc_self_*, xc_self_zero) fire first
#                          so only the distinct-source (non-self) form reaches here.
#   MVN                    PoO §7-169 — numeric (low) nibbles of D2 → D1;
#                          zone (high) nibbles of D1 unchanged → D1 prior is a dep.
#   MVZ                    PoO §7-170 — zone (high) nibbles of D2 → D1;
#                          numeric (low) nibbles of D1 unchanged → D1 prior is a dep.
#   MVO                    PoO §7-176 — sign nibble (low 4 bits of rightmost byte)
#                          of D1 is always preserved in ALL MVO forms, not self-only.
#                          (Previously in _SELF_PRIOR_VALUE for self-op only; moved
#                          here so distinct-source MVO is also annotated correctly.)
#   ED/EDMK                PoO §7-85/86 — D1 is the edit-mask template, consumed
#                          before being overwritten with the formatted result.
#   STCM/STCMH/STCMY       PoO §7-212/213 — only mask-selected bytes of D1 are
#                          written; unselected bytes are unchanged → D1 prior is a
#                          dep for any non-zero mask.  Zero-mask is already skipped
#                          by _STORE_UNDER_MASK before this check is reached.
#   ASI/AGSI/ALSI/ALGSI   PoO §7-21 — D1 += I2 (storage increment)
#   AP/SP                  PoO §8-6/§8-13 — AP FIELD,SRC: result=FIELD+SRC;
#                          SP FIELD,SRC: result=FIELD-SRC; prior FIELD IS a dep.
#                          (CRITICAL — §3a rows "AP FIELD,SRC" and "SP FIELD,SRC")
#                          Note: AP/SP self-op patterns fire first and return early,
#                          so this only annotates the distinct-source form.
_RMW_PRIOR_VALUE = {
    "NI", "OI", "XI", "NIY", "OIY", "XIY",
    "NC", "OC", "XC",
    "MVN", "MVZ", "MVO",
    "ED", "EDMK",
    "STCM", "STCMH", "STCMY",
    "ASI", "AGSI", "ALSI", "ALGSI",
    "AP", "SP",
}

# Instructions whose self-operand form (normalized args equal) is a genuine setter
# whose prior value matters and must NOT be treated as a value-preserving no-op.
#   PACK self  PoO §7-182 note 2 — in-place pack; distinct-source PACK fully
#              overwrites D1, so only the self-op form needs this flag.
# (MVO moved to _RMW_PRIOR_VALUE — sign nibble preserved in ALL forms, not self-only.
#  TR  handled by tr_suppress_table pattern — prior_value_required set there for
#      all TR regardless of whether operands are equal.)
_SELF_PRIOR_VALUE = {"PACK"}


def _is_identity_immediate(inst: str, args: Sequence[str]) -> bool:
    """NI/NIY FIELD,X'FF' / OI/OIY/XI/XIY FIELD,X'00' — value unchanged (PoO §7-25/180/142)."""
    if len(args) < 2:
        return False
    imm = str(args[1]).strip().upper().replace(" ", "")
    if inst in ("NI", "NIY"):
        return bool(re.fullmatch(r"X'F+'", imm))          # AND with all-ones = identity
    if inst in ("OI", "OIY", "XI", "XIY"):
        return bool(re.fullmatch(r"X'0+'", imm))          # OR/XOR with zero = identity
    return False


def _is_zero_literal_operand(arg: str) -> bool:
    """True for literals that resolve to zero: =P'0', =F'0', =H'0', =XL4'00…', 0."""
    a = str(arg).strip().upper().replace(" ", "")
    if a == "0":
        return True
    # =P'[+-]0', =F'0', =H'0', =C'0'? (decimal/binary zero packed/fixed literals)
    if re.fullmatch(r"=[PFH]'[+-]?0+'", a):
        return True
    # =X'0+' / =XL<n>'0+' (all-zero hex literal)
    if re.fullmatch(r"=X[L]?\d*'0+'", a):
        return True
    return False


def _mask_is_zero(arg: str) -> bool:
    """True if a store-under-mask M3 operand resolves to 0 (no bytes written)."""
    a = str(arg).strip().upper().replace(" ", "")
    if a in ("0", "0000"):
        return True
    if re.fullmatch(r"B'0+'", a):
        return True
    if re.fullmatch(r"X'0+'", a):
        return True
    return False


def dest_has_nonzero_displacement(raw_dest: str) -> bool:
    """True for SYMBOL+N destinations with N != 0 (write targets SYMBOL+N, not SYMBOL).

    Audit §3c: normalize_token strips the '+N' suffix so SYMBOL+N would falsely match
    a setter site for SYMBOL.  The '(len)' range-write form is NOT matched here (it
    uses parentheses, handled separately by _range_write_covers_target).
    """
    m = re.match(r"^([A-Z@$_][A-Z0-9@$_]*)\+(\d+)", str(raw_dest).strip().upper())
    return bool(m) and int(m.group(2)) != 0


def _is_zero_literal_skip(inst: str, args: Sequence[str]) -> bool:
    """AP/SP FIELD,=P'0' (add/subtract zero) or XC FIELD,=XL..'0+' — value unchanged."""
    if len(args) < 2:
        return False
    if inst in ("AP", "SP"):
        return _is_zero_literal_operand(args[1])
    if inst == "XC":
        a = str(args[1]).strip().upper().replace(" ", "")
        return bool(re.fullmatch(r"=X[L]?\d*'0+'", a))
    return False


def _match_pattern(inst: str, args: List[str], next_inst: str) -> Optional[Dict[str, Any]]:
    """Core pattern matcher over raw args + the following instruction mnemonic."""
    inst = (inst or "").upper()
    next_inst = (next_inst or "").upper()
    norm_args = [normalize_token(a) for a in args]

    for pattern in SPECIAL_DEPENDENCY_PATTERNS:
        if inst != str(pattern.get("inst") or "").upper():
            continue
        next_insts = {str(op).upper() for op in (pattern.get("next_insts") or set())}
        if next_insts and next_inst not in next_insts:
            continue
        if pattern.get("require_normalized_args_equal"):
            if len(norm_args) < 2 or not norm_args[0] or norm_args[0] != norm_args[1]:
                continue
        if pattern.get("require_raw_args_equal"):
            if len(args) < 2 or args[0] != args[1]:
                continue
        if pattern.get("require_raw_args_differ"):
            if len(args) < 2 or args[0] == args[1]:
                continue
        return pattern
    return None


def match_special_dependency_pattern(
    flow_entries: Sequence[Dict[str, Any]],
    entry_index: int,
    *,
    next_inst_override: str = "",
) -> Optional[Dict[str, Any]]:
    """Return the first matching glossary-driven dependency pattern.

    next_inst_override (GAP-009): when the current entry is the last one in its
    basic block, the caller can supply the first instruction of the unique CFG
    successor block here.  This allows cross-block pairs like OC VAR,VAR (end of
    block 1) + BZ TARGET (start of block 2) to be detected even though the two
    instructions do not share the same flow_entries list.
    """
    if entry_index < 0 or entry_index >= len(flow_entries):
        return None

    entry = flow_entries[entry_index] or {}
    inst = str(entry.get("inst") or "").upper()

    if next_inst_override:
        next_inst = str(next_inst_override).upper()
    elif entry_index + 1 < len(flow_entries):
        next_inst = str((flow_entries[entry_index + 1] or {}).get("inst") or "").upper()
    else:
        next_inst = ""

    args = [str(a) for a in (entry.get("args") or [])]
    return _match_pattern(inst, args, next_inst)


def classify_setter(
    inst: str,
    raw_args: Sequence[str],
    *,
    next_inst: str = "",
) -> Dict[str, Any]:
    """Return the semantic verdict for a (possible) setter instruction.

    Verdict fields:
      record_site           — False => do not record this as a setter site at all
      skip_setter_site      — same as `not record_site` (explicit alias)
      suppress_dep_vars      — record the site but harvest no source dep_vars
      suppress_src_indexes   — frozenset of args[] indexes to drop from dep harvest
      prior_value_required   — annotate: prior value of dest is itself a dependency
      warn                   — optional warning message (spec exception / unpredictable)
      role                   — special role override ("CONDITION_CHECK") or None
      dep_arg_indexes        — specific args[] to emit as deps (prior-value patterns)
      pattern                — matched pattern name, or None
    """
    inst = (inst or "").upper()
    args = [str(a) for a in (raw_args or [])]
    verdict: Dict[str, Any] = {
        "record_site": True,
        "skip_setter_site": False,
        "suppress_dep_vars": False,
        "suppress_src_indexes": SRC_ARG_SUPPRESS_BY_INST.get(inst, frozenset()),
        "prior_value_required": False,
        "warn": None,
        "role": None,
        "dep_arg_indexes": (),
        "pattern": None,
    }

    pat = _match_pattern(inst, args, (next_inst or "").upper())
    if pat:
        verdict["pattern"] = pat.get("name")
        verdict["role"] = pat.get("role")
        verdict["dep_arg_indexes"] = tuple(pat.get("dep_arg_indexes") or ())
        if pat.get("skip_setter_site"):
            verdict["skip_setter_site"] = True
            verdict["record_site"] = False
        if pat.get("suppress_dep_vars"):
            verdict["suppress_dep_vars"] = True
        extra = pat.get("suppress_src_indexes")
        if extra:
            verdict["suppress_src_indexes"] = (
                verdict["suppress_src_indexes"] | frozenset(extra)
            )
        if pat.get("prior_value_required"):
            verdict["prior_value_required"] = True
        if pat.get("warn_message"):
            verdict["warn"] = pat["warn_message"]
        # TR self-translate (PoO §7-225, §3d LOW): when the translate table IS the
        # field itself (TR FIELD,FIELD), do NOT suppress args[1] — it is the data
        # source; cancel the static suppression and annotate prior_value instead.
        if pat.get("name") == "tr_suppress_table" and len(args) >= 2:
            n0, n1 = normalize_token(args[0]), normalize_token(args[1])
            if n0 and n0 == n1:
                verdict["suppress_src_indexes"] = frozenset()
                verdict["prior_value_required"] = True
        return verdict

    # The remaining detectors are setter-specific.  classify_setter is called for
    # every flow entry (including triggers/branches), so a non-setter instruction
    # with a SYMBOL+N operand (e.g. CLC FIELD+4,X) must NOT be skipped here.
    if inst not in SETTER_INST:
        return verdict

    # Non-pattern skip detectors.
    if _is_identity_immediate(inst, args) or _is_zero_literal_skip(inst, args):
        verdict["skip_setter_site"] = True
        verdict["record_site"] = False
        return verdict

    # Store-under-mask with a zero mask writes nothing (PoO §7-212/213).
    if inst in _STORE_UNDER_MASK and len(args) >= 2 and _mask_is_zero(args[1]):
        verdict["skip_setter_site"] = True
        verdict["record_site"] = False
        return verdict

    # SYMBOL+N destination (nonzero displacement): the write targets SYMBOL+N, not
    # SYMBOL — not a setter site for the normalized symbol (PoO §3c).
    _dest_idx = DEST_ARG_INDEX_BY_INST.get(inst, 0)
    if _dest_idx < len(args) and dest_has_nonzero_displacement(args[_dest_idx]):
        verdict["skip_setter_site"] = True
        verdict["record_site"] = False
        verdict["warn"] = (
            f"{inst} {args[_dest_idx]}: write targets a nonzero displacement, "
            f"not the base symbol; skipping setter site"
        )
        return verdict

    # Prior-value (read-modify-write) annotations.
    if inst in _RMW_PRIOR_VALUE:
        verdict["prior_value_required"] = True
    elif inst in ("MP", "DP"):
        # multiplicand / dividend prior value is also a dep (PoO §8-11, §8-7).
        verdict["prior_value_required"] = True
    elif inst in _SELF_PRIOR_VALUE and len(args) >= 2:
        n0, n1 = normalize_token(args[0]), normalize_token(args[1])
        if n0 and n0 == n1:
            verdict["prior_value_required"] = True

    return verdict
