"""Instruction glossary for backward-only mode."""
