"""Data models for the chainless (whole-codebase) backward lineage tracer."""
