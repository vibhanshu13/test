"""Data models for the chainless, whole-codebase backward lineage tracer.

Unlike the chain-based path (which is anchored on a caller-supplied
``selected_chain``), the chainless engine takes only a variable name and
discovers **every** setter site across the codebase.  Each setter site is an
independent ``SetterRoot``; the union of all roots' backward traces forms a
**forest** that is materialised as a **DAG with interned nodes** — every trace
node carries a stable ``node_key`` (content hash) so subtrees shared between
roots are stored exactly once.

Design principles:
- Pure dataclasses, JSON/msgpack-serialisable via ``dataclasses.asdict``.
- No traversal logic here — these only describe the inputs/outputs that the
  enumerator, walkers, dep-resolver and runner produce and consume.
- Soundness markers (``relevant``, ``pruned_reason``, ``gvl_limit``,
  ``indirection``) ride along on the data so the consumer/UI can hide
  provably-irrelevant or unresolvable branches **without anything being lost**.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Literal, Optional

# ---------------------------------------------------------------------------
# Enumerations (kept as Literals — no runtime cost, clear at call sites)
# ---------------------------------------------------------------------------

FileType = Literal["asm", "cpp"]
# Language of an analysis request; "mixed" when a variable exists in both.
Language = Literal["asm", "cpp", "mixed"]
# Dependency-edge kind — the x=y+2 (data_flow) vs if(y==2)x=2 (conditional_guard)
# vs read-modify-write (prior_value) distinction.
DepKind = Literal["data_flow", "conditional_guard", "prior_value"]
# Phase a tuple/exploration-step belongs to (forest membership is via root_id).
Phase = Literal["setter_root", "caller", "dep_var"]


# ---------------------------------------------------------------------------
# Setter roots (the independent entry points of the forest)
# ---------------------------------------------------------------------------

@dataclass
class SetterRoot:
    """One place where the requested variable is set, anywhere in the codebase.

    ``root_id`` is a stable, content-derived identifier so the same site always
    maps to the same id across runs / endpoints (used for per-root API routing,
    dedup, and forest membership tagging on tuples).
    """

    root_id: str                         # stable: f"{stem}:{type}:{block_or_seed}:{line}:{instr}"
    file_stem: str
    file_type: FileType
    variable: str                        # the (possibly counterpart-translated) var at this root
    origin_variable: str                 # the variable as originally requested (provenance)
    line: int = 0
    instruction: str = ""                # ASM mnemonic, or "assign"/"define" for C++
    block_id: Optional[str] = None       # ASM block / routine id
    seed_id: Optional[str] = None        # C++ GVL seed node id
    setter_expression: Optional[str] = None
    constant_source: bool = False        # source operand is a compile-time literal
    prior_value_required: bool = False   # read-modify-write: prior value is itself a dep
    role: Optional[str] = None           # classify_setter verdict.role (e.g. CONDITION_CHECK)
    is_declaration: bool = False         # a `define` (declaration/copybook) site, not a value write
    # Counterpart provenance (when discovered via cross-language expansion)
    is_counterpart_root: bool = False
    counterpart_of: Optional[str] = None
    counterpart_certainty: Optional[str] = None   # "high" | "medium" | "low"
    # ASM specifics carried through from _find_scoped_setter_sites
    flipc_alias_of: Optional[str] = None
    hardware_source: Optional[str] = None
    warnings: List[str] = field(default_factory=list)

    @staticmethod
    def make_root_id(
        file_stem: str,
        file_type: str,
        anchor: str,
        line: int,
        instruction: str,
    ) -> str:
        """Build the canonical, stable root id for a setter site."""
        return f"{file_stem}:{file_type}:{anchor}:{line}:{instruction}".upper()


# ---------------------------------------------------------------------------
# Dependency variables (with kind + sound value-pruning markers)
# ---------------------------------------------------------------------------

@dataclass
class Constraint:
    """A guard constraint on a conditional_guard dependency (e.g. ``y == 2``).

    ``raw`` is always preserved verbatim (the source guard string) so nothing is
    lost even when operator/constant cannot be parsed.
    """

    raw: str
    operator: Optional[str] = None       # "==","!=","<",">","TM/BZ", ... best-effort
    constant: Optional[str] = None        # literal RHS if parseable (e.g. "2", "X'10'")


@dataclass
class DepVar:
    """A dependent variable discovered while backward-tracing a setter.

    ``relevant`` implements the **sound** value-pruning: a conditional_guard dep
    whose setter provably assigns a constant that contradicts the guard
    constraint is flagged ``relevant=False`` with a ``pruned_reason`` — but it is
    **never deleted**, so a consumer can hide provably-irrelevant branches while
    the full data remains available.
    """

    name: str
    kind: DepKind = "data_flow"
    constraint: Optional[Constraint] = None
    relevant: bool = True
    pruned_reason: Optional[str] = None
    discovered_in_stem: str = ""
    discovered_at_line: int = 0
    depth: int = 0                       # dep-var BFS depth from its root
    root_id: str = ""                    # which SetterRoot this dep belongs to
    # Resolved values of this dep at its collection points (across callers/calls)
    values: List[Dict[str, Any]] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Caller / downstream topology nodes
# ---------------------------------------------------------------------------

@dataclass
class Indirection:
    """Indirect-call envelope — surfaced, never silently dropped."""

    is_indirect: bool = False
    indirect_via: Optional[str] = None   # e.g. "R5"
    unresolved: bool = False             # register-indirect / XCTL / computed target
    is_virtual_dispatch: bool = False
    cha_base_class: Optional[str] = None


@dataclass
class CallerNode:
    """A verified caller of a callee (same-file or cross-file), recursive.

    Children reference shared interned nodes by key (``child_keys``) so a caller
    reached from two roots is stored once.
    """

    stem: str
    file_type: FileType
    callee_stem: str
    edge_kind: str                       # "asm->asm" | "asm->cpp" | "cpp->asm" | "cpp->cpp"
    depth: int = 0
    cycle: bool = False
    call_sites: List[Dict[str, Any]] = field(default_factory=list)  # verified sites
    child_keys: List[str] = field(default_factory=list)             # node_keys of caller children
    indirection: Optional[Indirection] = None


# ---------------------------------------------------------------------------
# Interned trace nodes (the DAG) + per-root index + forest output
# ---------------------------------------------------------------------------

@dataclass
class TraceNode:
    """A content-addressed trace node in the global interned table.

    ``node_key`` is a hash of the node's identity (file/block-or-seed/variable/
    role/line); identical work-units computed from different roots collapse to a
    single node so shared subtrees are stored once.
    """

    node_key: str
    file_stem: str
    file_type: FileType
    variable: str
    line: int = 0
    instruction: str = ""
    role: Optional[str] = None
    relevant_lines: List[Dict[str, Any]] = field(default_factory=list)
    # Guard conditions under which this setter fires (each: file/line/scope/expression).
    conditions: List[Dict[str, Any]] = field(default_factory=list)
    dep_keys: List[str] = field(default_factory=list)     # node_keys of dependent-var nodes
    edge_keys: List[str] = field(default_factory=list)    # outgoing interned edge ids
    # Visible markers — present means "we could not statically resolve this", not
    # "there is nothing here".  Never implies a silent omission.
    gvl_limit: Optional[str] = None      # "virtual" | "fnptr" | "template" | "union" | "ptr_arith" | "macro" | "exception"
    static_analysis_limit: Optional[str] = None  # "EX" | "self_modifying" | "register_indirect" | ...
    warnings: List[str] = field(default_factory=list)

    @staticmethod
    def make_node_key(
        file_stem: str,
        file_type: str,
        anchor: str,
        variable: str,
        role: str = "",
        line: int = 0,
    ) -> str:
        """Stable content hash for node interning / cross-root sharing."""
        raw = "|".join(
            (
                str(file_stem).lower(),
                str(file_type).lower(),
                str(anchor).upper(),
                str(variable).upper(),
                str(role or "").upper(),
                str(line),
            )
        )
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


@dataclass
class ForestRootEntry:
    """One root's slot in the forest — thin indices into the interned tables."""

    root: SetterRoot
    trace_node_keys: List[str] = field(default_factory=list)
    caller_keys: List[str] = field(default_factory=list)
    downstream_keys: List[str] = field(default_factory=list)
    dep_var_keys: List[str] = field(default_factory=list)
    # All guard conditions gating this setter root's writes.
    conditions: List[Dict[str, Any]] = field(default_factory=list)
    truncated: bool = False
    warnings: List[str] = field(default_factory=list)


@dataclass
class CounterpartInfo:
    """A cross-language counterpart surfaced for the requested variable."""

    counterpart_name: str
    language: FileType
    home_stem: str = ""
    certainty_label: str = ""            # "high" | "medium" | "low"
    cc_header: str = ""
    mapping_via: str = ""


@dataclass
class ForestOutput:
    """The full chainless result for one variable — a DAG, not a tree.

    ``nodes``/``edges`` are the deduped interned tables; everything else
    references them by key.  Sync API responses may re-inline nodes for
    convenience, but the on-disk store stays deduped.
    """

    variable: str
    language: Language
    options: Dict[str, Any] = field(default_factory=dict)
    truncated: bool = False
    warnings: List[str] = field(default_factory=list)
    counterparts: List[CounterpartInfo] = field(default_factory=list)
    setter_roots: List[SetterRoot] = field(default_factory=list)
    forest: List[ForestRootEntry] = field(default_factory=list)
    # Interned tables (the DAG): node_key -> TraceNode / DepVar; edge_id -> edge dict.
    nodes: Dict[str, TraceNode] = field(default_factory=dict)
    dep_vars: Dict[str, DepVar] = field(default_factory=dict)
    edges: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    stats: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Serialise to plain dicts (JSON/msgpack-ready)."""
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), separators=(",", ":"), sort_keys=True)
