"""KB-wide declaration index for terminal variable lookup.

Scans all *.mac.json, *.hpp.json, *.asm.json blueprints in blueprint_dir and builds
a map from normalised variable name → DeclSite, allowing any terminal variable to be
located in its declaring macro or header file.

Design principles:
- Line numbers and declaration text are reliable: validated against raw source
  (blueprint variable_lineage define-edges land exactly on the declaration line).
- Comments are only in raw source, so read_declaration_context() fetches them from
  the original file — gracefully returns empty strings when the source isn't present.
- Module-level cache (blueprint_dir, graph_file) mirrors counterpart_resolver pattern.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class DeclSite:
    var_name: str           # normalised upper name (e.g. "WK_CNT")
    home_stem: str          # blueprint stem (e.g. "da7gl")
    file_path: str          # path to the raw source file (may be empty if absent)
    file_type: str          # "asm" (for .mac/.asm) | "cpp" (for .hpp/.cpp)
    line: int               # 1-based declaration line
    expression: str         # raw declaration text ("DS H" / "unsigned short noOfLimits;")
    storage_type: str       # storage type parsed from expression ("H", "CL4", "F", …)
    length: int             # byte length from dsect_layouts (0 = unknown)
    dsect_struct: str       # parent DSECT/struct name (e.g. "DA7GL&A")
    symbol_type: str        # "dsect" | "dc" | "equ" | "csect" | "" (from global_symbols)
    is_dsect_member: bool   # True if this field is inside a DSECT/struct layout
    cc_alias: str           # cross-language counterpart name (filled at lookup time)
    cc_certainty: str       # "high" | "medium" | "low" | ""
    source_file_present: bool  # whether the raw source file exists on disk
    lookup_via_counterpart: bool = False  # True when found only via counterpart fallback


# Module-level cache: (blueprint_dir_str, graph_file_str) -> index dict
_INDEX_CACHE: Dict[Tuple[str, str], Dict[str, List[DeclSite]]] = {}


def invalidate_index_cache() -> None:
    _INDEX_CACHE.clear()


# ---------------------------------------------------------------------------
# Name normalisation
# ---------------------------------------------------------------------------

_MACRO_SUFFIX_RE = re.compile(r"&\w+")
_NODE_PREFIX_RE = re.compile(r"^(member|memory|use|literal|function):", re.IGNORECASE)
_POINTER_RE = re.compile(r"^->")


def _normalise_var_name(raw: str) -> str:
    """Return normalised upper-case name, stripping prefixes / macro suffixes."""
    name = str(raw or "").strip()
    name = _NODE_PREFIX_RE.sub("", name)
    name = _POINTER_RE.sub("", name)
    name = _MACRO_SUFFIX_RE.sub("", name)
    name = re.sub(r"::", "__", name)  # C++ qualified separator
    return name.strip().upper()


# ---------------------------------------------------------------------------
# Storage-type extraction
# ---------------------------------------------------------------------------

_ASM_DS_TYPE_RE = re.compile(
    r"\bDS\s+(\d*[XCFLPBHDA]\w*)",
    re.IGNORECASE,
)
_ASM_DC_TYPE_RE = re.compile(
    r"\bDC\s+(\d*[XCFLPBHDA]\w*)",
    re.IGNORECASE,
)
_CPP_TYPE_RE = re.compile(
    r"^\s*([\w<>,\s]+?)\s+\w+\s*(?:\[.*?\])?\s*;",
)


def _extract_storage_type(expression: str, file_type: str) -> str:
    expr = str(expression or "")
    if file_type == "asm":
        m = _ASM_DS_TYPE_RE.search(expr) or _ASM_DC_TYPE_RE.search(expr)
        if m:
            return m.group(1).upper()
        parts = expr.split()
        # Handle bare "DS H" (name stripped in define-edge expression)
        if len(parts) >= 2 and parts[0].upper() in ("DS", "DC", "EQU"):
            return parts[1].upper()
        return ""
    else:
        m = _CPP_TYPE_RE.match(expr)
        if m:
            return m.group(1).strip()
        return ""


# ---------------------------------------------------------------------------
# Symbol type from global_symbols
# ---------------------------------------------------------------------------


def _get_symbol_type(bp: Dict[str, Any], var_upper: str) -> str:
    syms = (bp.get("symbols") or {})
    gs = syms.get("global_symbols") or {}
    if not isinstance(gs, dict):
        return ""
    entry = gs.get(var_upper) or gs.get(var_upper.lower())
    if entry and isinstance(entry, dict):
        return str(entry.get("type") or "").lower()
    return ""


# ---------------------------------------------------------------------------
# Source file path extraction from blueprint metadata
# ---------------------------------------------------------------------------


def _source_path_from_bp(bp: Dict[str, Any]) -> str:
    """Return the raw source file path recorded in the blueprint, or ''."""
    # variable_lineage define-edges carry the original file
    vl = bp.get("variable_lineage") or {}
    for edge in (vl.get("edges") or []):
        if edge.get("relation") == "define":
            fp = edge.get("file") or ""
            if fp:
                return fp
    # Fall back to metadata
    meta = bp.get("meta") or bp.get("metadata") or {}
    return str(meta.get("source_file") or meta.get("file") or "")


# ---------------------------------------------------------------------------
# Index builder
# ---------------------------------------------------------------------------


def build_declaration_index(
    blueprint_dir: Path,
    graph_file: Optional[Path] = None,
) -> Dict[str, List[DeclSite]]:
    """Return cached KB-wide map: normalised_var_upper → [DeclSite].

    Scans *.mac.json, *.hpp.json, *.asm.json in blueprint_dir.
    The graph_file is used only as a cache key; pass None if unavailable.
    """
    key = (str(blueprint_dir), str(graph_file or ""))
    if key in _INDEX_CACHE:
        return _INDEX_CACHE[key]

    index: Dict[str, List[DeclSite]] = {}
    bp_dir = Path(blueprint_dir)

    patterns = ["*.mac.json", "*.hpp.json", "*.asm.json"]
    for pattern in patterns:
        for bp_path in sorted(bp_dir.glob(pattern)):
            _index_one_blueprint(bp_path, index)

    _INDEX_CACHE[key] = index
    logger.debug(
        "Declaration index built: %d unique names from %s",
        len(index),
        blueprint_dir,
    )
    return index


def _index_one_blueprint(
    bp_path: Path,
    index: Dict[str, List[DeclSite]],
) -> None:
    stem = bp_path.name
    # Strip extensions: .mac.json → mac; .hpp.json → hpp; .asm.json → asm
    for ext in (".mac.json", ".hpp.json", ".asm.json", ".cpp.json"):
        if stem.endswith(ext):
            stem = stem[: -len(ext)]
            break

    try:
        from blueprint_io import load_blueprint

        bp = load_blueprint(
            bp_path,
            skip_global_lineage=True,
            keys={"dsect_layouts", "meta", "metadata", "symbols", "variable_lineage"},
        )
    except Exception as e:
        logger.debug("Declaration index: cannot load %s: %s", bp_path, e)
        return

    name = bp_path.name.lower()
    file_type = "cpp" if (".hpp." in name or ".cpp." in name) else "asm"

    # Raw source file path
    raw_source = _source_path_from_bp(bp)
    source_present = bool(raw_source and Path(raw_source).exists())

    # DSECT / struct layout info: field_upper -> {struct, length}
    dsect_info: Dict[str, Dict[str, Any]] = {}
    for struct_name, fields in (bp.get("dsect_layouts") or {}).items():
        if not isinstance(fields, dict):
            continue
        for field_name, info in fields.items():
            norm = _normalise_var_name(field_name)
            if not norm:
                continue
            dsect_info[norm] = {
                "struct": str(struct_name),
                "length": int((info or {}).get("length") or 0),
            }

    # Symbol types from global_symbols (for DC/EQU detection)
    gs = (bp.get("symbols") or {}).get("global_symbols") or {}
    sym_types: Dict[str, str] = {}
    if isinstance(gs, dict):
        for sname, smeta in gs.items():
            norm = _normalise_var_name(sname)
            if norm:
                sym_types[norm] = str((smeta or {}).get("type") or "").lower()

    # Process define-edges from variable_lineage
    vl = bp.get("variable_lineage") or {}
    for edge in (vl.get("edges") or []):
        if str(edge.get("relation") or "") != "define":
            continue
        raw_id = str(edge.get("source") or "")
        norm = _normalise_var_name(raw_id)
        if not norm:
            continue

        line = int(edge.get("line") or 0)
        expression = str(edge.get("expression") or "")
        storage = _extract_storage_type(expression, file_type)
        ds_data = dsect_info.get(norm, {})
        sym_type = sym_types.get(norm, "")

        site = DeclSite(
            var_name=norm,
            home_stem=stem,
            file_path=raw_source,
            file_type=file_type,
            line=line,
            expression=expression,
            storage_type=storage,
            length=ds_data.get("length", 0),
            dsect_struct=ds_data.get("struct", ""),
            symbol_type=sym_type,
            is_dsect_member=bool(ds_data),
            cc_alias="",
            cc_certainty="",
            source_file_present=source_present,
        )
        index.setdefault(norm, []).append(site)

    # Also index names from dsect_layouts that may not have a define-edge
    for norm, ds_data in dsect_info.items():
        if norm in index and any(s.home_stem == stem for s in index[norm]):
            continue  # already indexed via define-edge
        site = DeclSite(
            var_name=norm,
            home_stem=stem,
            file_path=raw_source,
            file_type=file_type,
            line=0,
            expression="",
            storage_type="",
            length=ds_data.get("length", 0),
            dsect_struct=ds_data.get("struct", ""),
            symbol_type=sym_types.get(norm, ""),
            is_dsect_member=True,
            cc_alias="",
            cc_certainty="",
            source_file_present=source_present,
        )
        index.setdefault(norm, []).append(site)


# ---------------------------------------------------------------------------
# Lookup
# ---------------------------------------------------------------------------


def lookup(
    var: str,
    language: str,
    blueprint_dir: Path,
    graph_file: Optional[Path] = None,
    home_hint: Optional[str] = None,
) -> Optional[DeclSite]:
    """Return the best DeclSite for *var*, or None if not found.

    Preference order:
    1. Exact match with source_file_present=True, is_dsect_member=True
    2. Exact match with source_file_present=True
    3. Exact match (source absent)
    4. Counterpart cross-language lookup (ASM variable in HPP index, or vice-versa)
    """
    norm = _normalise_var_name(var)
    if not norm:
        return None

    index = build_declaration_index(blueprint_dir, graph_file)
    candidates = index.get(norm, [])

    # Prefer home_hint stem if provided
    if home_hint and candidates:
        hint_lower = str(home_hint).lower()
        preferred = [s for s in candidates if s.home_stem.lower() == hint_lower]
        if preferred:
            candidates = preferred

    best = _pick_best(candidates)
    if best is not None:
        _fill_cc_alias(best, var, language, blueprint_dir, graph_file)
        return best

    # No direct hit: try counterpart (e.g. CPP field name → ASM declaration)
    try:
        from backward_traversal.utils.counterpart_resolver import resolve_counterpart
        if graph_file and graph_file.exists():
            counterparts = resolve_counterpart(
                var, language, blueprint_dir, graph_file, home_stem=home_hint
            )
            for cp in counterparts:
                cp_norm = _normalise_var_name(cp.counterpart_name)
                cp_candidates = index.get(cp_norm, [])
                if cp_candidates:
                    site = _pick_best(cp_candidates)
                    if site is not None:
                        site = _copy_with_alias(site, cp.counterpart_name, cp.certainty_label)
                        return site
    except Exception as e:
        logger.debug("Declaration lookup counterpart fallback failed for %s: %s", var, e)

    return None


def _pick_best(candidates: List[DeclSite]) -> Optional[DeclSite]:
    if not candidates:
        return None

    def _score(s: DeclSite) -> int:
        return (
            (2 if s.source_file_present else 0)
            + (1 if s.is_dsect_member else 0)
            + (1 if s.line > 0 else 0)
        )

    return max(candidates, key=_score)


def _fill_cc_alias(
    site: DeclSite,
    original_var: str,
    language: str,
    blueprint_dir: Path,
    graph_file: Optional[Path],
) -> None:
    """Attempt to fill site.cc_alias / cc_certainty from counterpart_resolver."""
    if site.cc_alias:
        return
    try:
        from backward_traversal.utils.counterpart_resolver import resolve_counterpart
        if not graph_file or not graph_file.exists():
            return
        counterparts = resolve_counterpart(
            original_var, language, blueprint_dir, graph_file, home_stem=site.home_stem
        )
        if counterparts:
            cp = counterparts[0]
            site.cc_alias = cp.counterpart_name
            site.cc_certainty = cp.certainty_label
    except Exception:
        pass


def _copy_with_alias(site: DeclSite, alias: str, certainty: str) -> DeclSite:
    import copy
    s = copy.copy(site)
    s.cc_alias = alias
    s.cc_certainty = certainty
    s.lookup_via_counterpart = True
    return s


# ---------------------------------------------------------------------------
# Declaration context reader (comment extraction from raw source)
# ---------------------------------------------------------------------------

_INLINE_COMMENT_RE = re.compile(r"//\s*(.*)")
_ASM_INLINE_RE = re.compile(
    r"^\S[\w@#$&]*\s+(?:DS|DC|EQU)\s+\S+\s{2,}(.*)",
    re.IGNORECASE,
)


def read_declaration_context(
    decl_site: DeclSite,
    asm_dir: Optional[Path] = None,
) -> Dict[str, str]:
    """Read declaration line + surrounding comments from raw source.

    Returns dict with keys: decl_line, inline_comment, block_comment.
    Returns empty strings gracefully when source is absent or unreadable.
    """
    empty = {"decl_line": "", "inline_comment": "", "block_comment": ""}

    if not decl_site.file_path or not decl_site.line:
        return empty

    source_path = Path(decl_site.file_path)

    # Try asm_dir override (for local temp/ subset)
    if not source_path.exists() and asm_dir:
        alt = Path(asm_dir) / source_path.name
        if alt.exists():
            source_path = alt

    if not source_path.exists():
        return empty

    try:
        lines = source_path.read_text(errors="replace").splitlines()
    except Exception:
        return empty

    ln = decl_site.line - 1  # 0-based
    if not (0 <= ln < len(lines)):
        return empty

    decl_line = lines[ln]

    if decl_site.file_type == "asm":
        return _asm_context(lines, ln, decl_line)
    else:
        return _cpp_context(lines, ln, decl_line)


def _asm_context(lines: List[str], ln: int, decl_line: str) -> Dict[str, str]:
    # Inline: text after the operand (NAME DS TYPE  <COMMENT>)
    inline = ""
    m = _ASM_INLINE_RE.match(decl_line)
    if m:
        inline = m.group(1).strip()
    else:
        # Fallback: split on 2+ spaces, take tail after 3rd token
        parts = decl_line.split()
        if len(parts) >= 4:
            # Reconstruct from 4th word onward
            idx = decl_line.index(parts[3]) if parts[3] in decl_line else -1
            if idx >= 0:
                inline = decl_line[idx:].strip()

    # Block comment: contiguous * lines immediately above
    block_parts: List[str] = []
    for i in range(ln - 1, max(-1, ln - 8), -1):
        stripped = lines[i].lstrip()
        if stripped.startswith("*"):
            block_parts.insert(0, stripped.lstrip("* ").strip())
        else:
            break

    return {
        "decl_line": decl_line.strip(),
        "inline_comment": inline,
        "block_comment": " ".join(block_parts),
    }


def _cpp_context(lines: List[str], ln: int, decl_line: str) -> Dict[str, str]:
    # Inline: text after // on the declaration line
    inline = ""
    m = _INLINE_COMMENT_RE.search(decl_line)
    if m:
        inline = m.group(1).strip()

    # Block comment: contiguous // lines immediately below
    block_parts: List[str] = []
    for i in range(ln + 1, min(len(lines), ln + 8)):
        stripped = lines[i].strip()
        if stripped.startswith("//"):
            block_parts.append(stripped.lstrip("/ ").strip())
        else:
            break

    return {
        "decl_line": decl_line.strip(),
        "inline_comment": inline,
        "block_comment": " ".join(block_parts),
    }
