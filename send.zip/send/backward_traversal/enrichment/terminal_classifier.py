"""Classify terminal variables from a backward traversal trace.

A "terminal variable" is a dep_var that the backward trace could not set — no setter
instruction was found in any file in scope.  Their role (why they are terminal) can be
determined by looking up their declaration in the relevant macro / header blueprint:

  - input          : a data leaf passed into the program from outside
  - db_record_field: a field in a DSECT/struct mapped to a physical DB record
  - constant_literal: a DC/EQU constant or literal value
  - system         : z/TPF system infrastructure (ECB registers, level blocks, etc.)

Strategy: deterministic rules on structural blueprint signals first; LLM fallback only
for ambiguous low-confidence cases (confidence < LLM_THRESHOLD).  Every result carries
method + evidence so callers can audit reliability.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from backward_traversal.enrichment.declaration_index import (
    DeclSite,
    lookup,
    read_declaration_context,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Role constants
# ---------------------------------------------------------------------------

ROLE_INPUT = "input"
ROLE_DB = "db_record_field"
ROLE_CONST = "constant_literal"
ROLE_SYSTEM = "system"

LLM_CONFIDENCE_THRESHOLD = 0.82

# ---------------------------------------------------------------------------
# Heuristic signals
# ---------------------------------------------------------------------------

_SYSTEM_PREFIXES = (
    "CE1CR",
    "LEVEL:",
    "MEMORY:CE1CR",
    "MEMORY:LEVEL:",
)
# C++ GVL kinds that map directly to roles
_CPP_KIND_ROLE: Dict[str, str] = {
    "literal": ROLE_CONST,
    "system_terminal": ROLE_SYSTEM,
    "memory": ROLE_SYSTEM,
    "function": ROLE_SYSTEM,  # function-pointer reference, not a data variable
    "use": ROLE_INPUT,
}
_CONST_SYMBOL_TYPES = frozenset({"dc", "equ", "literal", "constant"})
_DB_COMMENT_KEYWORDS = frozenset(
    {"RECORD", "LREC", "KEY", "FILE", "DATABASE", "DB", "TABLE", "SEGMENT", "ECB"}
)
_INPUT_COMMENT_KEYWORDS = frozenset(
    {"INPUT", "PARM", "PARAMETER", "PASSED", "FROM", "GIVEN", "PROVIDED", "CALLER"}
)


# ---------------------------------------------------------------------------
# Deterministic classifier
# ---------------------------------------------------------------------------


def _deterministic_role(
    var_name: str,
    decl_site: Optional[DeclSite],
    context: Dict[str, str],
    cpp_kind: Optional[str] = None,
) -> Tuple[str, float, str]:
    """Return (role, confidence, evidence).

    Runs structural checks in priority order; returns on first match.
    """
    var_up = str(var_name or "").upper()
    inline = str(context.get("inline_comment") or "")
    block = str(context.get("block_comment") or "")
    decl_expr = str((decl_site.expression if decl_site else None) or "")
    comment_upper = (inline + " " + block).upper()

    # 0. CR-prefix rule: any variable starting with "CR" is a DB record field
    if var_up.startswith("CR"):
        return (ROLE_DB, 0.90, "name starts with CR (database record field prefix)")

    # 1. System terminals
    if any(var_up.startswith(p.upper()) for p in _SYSTEM_PREFIXES):
        return (ROLE_SYSTEM, 0.95, f"name matches z/TPF system prefix")
    if cpp_kind and cpp_kind in ("system_terminal", "memory", "function"):
        return (ROLE_SYSTEM, 0.95, f"C++ terminal kind={cpp_kind}")

    # 2. Constant / literal
    if cpp_kind == "literal":
        return (ROLE_CONST, 0.92, f"C++ terminal kind=literal")
    # # prefix always means HLASM constant/flag — check before declaration lookup
    if var_up.startswith("#"):
        return (ROLE_CONST, 0.85, "name starts with # (HLASM constant/flag marker)")
    if decl_site:
        if decl_site.symbol_type in _CONST_SYMBOL_TYPES:
            return (
                ROLE_CONST,
                0.92,
                f"symbol_type={decl_site.symbol_type}; decl={decl_expr[:60]}",
            )
        expr_head = decl_expr.upper().lstrip()[:4]
        if expr_head in ("EQU ", "EQU\t", "DC  ", "DC\t"):
            return (ROLE_CONST, 0.88, f"declaration is {decl_expr[:40]}")

    # 3. DB record field — DSECT membership is the primary signal
    if decl_site and decl_site.is_dsect_member:
        confidence = 0.72
        evidence_parts = [f"DSECT member of '{decl_site.dsect_struct}'"]

        if decl_site.cc_certainty == "high":
            confidence = 0.92
            evidence_parts.append(f"high-certainty cc-alias → {decl_site.cc_alias}")
        elif decl_site.cc_certainty == "medium":
            confidence = 0.82
            evidence_parts.append(f"medium-certainty cc-alias → {decl_site.cc_alias}")

        if any(kw in comment_upper for kw in _DB_COMMENT_KEYWORDS):
            confidence = max(confidence, 0.80)
            evidence_parts.append("comment includes db/record keywords")

        if decl_site.line > 0:
            evidence_parts.append(
                f"declared in {decl_site.home_stem}:{decl_site.line}"
                + (f" ({decl_expr[:50]})" if decl_expr else "")
            )
        return (ROLE_DB, confidence, "; ".join(evidence_parts))

    # 4. Input — only when strong positive evidence; otherwise default to system
    confidence = 0.45
    evidence_parts = ["no setter found in trace (leaf variable)"]
    role = ROLE_SYSTEM  # conservative default: unresolved variables are system internals

    if decl_site:
        evidence_parts.append(
            f"declared in {decl_site.home_stem}:{decl_site.line}"
            + (f" ({decl_expr[:50]})" if decl_expr else "")
        )
    else:
        evidence_parts.append("declaration not found in KB blueprints")

    if any(kw in comment_upper for kw in _INPUT_COMMENT_KEYWORDS):
        confidence = 0.72
        role = ROLE_INPUT
        evidence_parts.append("comment includes input keywords")

    if decl_site and decl_site.cc_certainty in ("high", "medium"):
        confidence = max(confidence, 0.60)
        evidence_parts.append(f"cc-alias: {decl_site.cc_alias}")

    if cpp_kind == "use":
        confidence = max(confidence, 0.60)
        role = ROLE_INPUT
        evidence_parts.append("C++ terminal kind=use (unresolved reference)")

    return (role, confidence, "; ".join(evidence_parts))


# ---------------------------------------------------------------------------
# LLM fallback (lazy import so deterministic-only still works)
# ---------------------------------------------------------------------------

_LLM_AVAILABLE: Optional[bool] = None


def _try_llm_role(
    var_name: str,
    decl_site: Optional[DeclSite],
    context: Dict[str, str],
    det_role: str,
    det_conf: float,
    det_evidence: str,
) -> Tuple[str, float, str, str]:
    """Call LLM for ambiguous cases. Returns (role, confidence, evidence, method)."""
    global _LLM_AVAILABLE

    if _LLM_AVAILABLE is False:
        return (det_role, det_conf, det_evidence, "deterministic_low_conf")

    try:
        from pydantic import BaseModel
        from typing import Literal  # noqa: F401 (used in model below)

        from process_analysis.backend.llm import call_llm_model  # lazy import

        class _TerminalRoleLLM(BaseModel):
            role: str  # "input" | "db_record_field" | "constant_literal" | "system"
            confidence: float
            rationale: str

        decl_info = ""
        if decl_site:
            decl_info = (
                f"File: {decl_site.home_stem} (line {decl_site.line})\n"
                f"Declaration: {decl_site.expression}\n"
                f"Storage type: {decl_site.storage_type}\n"
                f"DSECT member: {decl_site.is_dsect_member}"
                + (f" of {decl_site.dsect_struct}" if decl_site.dsect_struct else "")
                + "\n"
            )
            if decl_site.cc_alias:
                decl_info += f"Cross-language alias: {decl_site.cc_alias} ({decl_site.cc_certainty})\n"

        comment_info = ""
        if context.get("inline_comment") or context.get("block_comment"):
            comment_info = (
                f"Inline comment: {context.get('inline_comment','')}\n"
                f"Block comment: {context.get('block_comment','')}\n"
            )

        prompt = f"""You are classifying a terminal variable in a mainframe HLASM/C++ codebase.
A "terminal variable" is one that the backward data-lineage trace could not find a setter for —
it is a leaf in the data flow graph.

Variable name: {var_name}

{decl_info}{comment_info}
Deterministic guess: role={det_role}, confidence={det_conf:.2f}

Classify the variable into exactly ONE of these roles:
- "input": data passed into the program from outside (caller-provided, external API, read from input buffer)
- "db_record_field": a field in a DSECT/struct that maps to a physical database or file record
- "constant_literal": a DC/EQU constant, literal value, or configuration flag
- "system": z/TPF system infrastructure (ECB registers, level blocks, system fields)

Return JSON: {{"role": "...", "confidence": 0.0-1.0, "rationale": "one sentence"}}"""

        result = call_llm_model(prompt, _TerminalRoleLLM)
        role = str(result.role or det_role).strip().lower()
        if role not in (ROLE_INPUT, ROLE_DB, ROLE_CONST, ROLE_SYSTEM):
            role = det_role
        conf = max(0.0, min(1.0, float(result.confidence or det_conf)))
        evidence = f"LLM: {result.rationale}; deterministic: {det_evidence}"
        _LLM_AVAILABLE = True
        return (role, conf, evidence, "llm")

    except Exception as e:
        logger.debug("LLM classification unavailable for %s: %s", var_name, e)
        _LLM_AVAILABLE = False
        return (det_role, det_conf, det_evidence, "deterministic_low_conf")


# ---------------------------------------------------------------------------
# Per-variable classification
# ---------------------------------------------------------------------------


def _classify_one(
    var_name: str,
    language: Optional[str],
    home_hint: Optional[str],
    cpp_kind: Optional[str],
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    graph_file: Optional[Path],
    use_llm: bool,
) -> Dict[str, Any]:
    """Classify a single terminal variable. Never raises; returns a safe dict."""
    lang = str(language or "asm").lower()

    decl_site = None
    context: Dict[str, str] = {"decl_line": "", "inline_comment": "", "block_comment": ""}
    try:
        decl_site = lookup(var_name, lang, blueprint_dir, graph_file, home_hint)
        if decl_site:
            context = read_declaration_context(decl_site, asm_dir)
    except Exception as e:
        logger.debug("Declaration lookup failed for %s: %s", var_name, e)

    det_role, det_conf, det_evidence = _deterministic_role(
        var_name, decl_site, context, cpp_kind
    )

    role, confidence, evidence, method = det_role, det_conf, det_evidence, "deterministic"

    if use_llm and det_conf < LLM_CONFIDENCE_THRESHOLD:
        role, confidence, evidence, method = _try_llm_role(
            var_name, decl_site, context, det_role, det_conf, det_evidence
        )

    declared_in = ""
    if decl_site:
        declared_in = f"{decl_site.home_stem}:{decl_site.line}" if decl_site.line else decl_site.home_stem

    certainty_of_location = (
        "counterpart_derived" if (decl_site and decl_site.lookup_via_counterpart) else
        "direct" if decl_site else
        "none"
    )

    return {
        "variable": var_name.upper(),
        "role": role,
        "confidence": round(confidence, 3),
        "method": method,
        "declared_in": declared_in,
        "declaration": context.get("decl_line") or (decl_site.expression if decl_site else ""),
        "comment": " | ".join(filter(None, [
            context.get("inline_comment"), context.get("block_comment")
        ])),
        "evidence": evidence,
        "certainty_of_location": certainty_of_location,
    }


# ---------------------------------------------------------------------------
# Extract terminal variables from backward-traversal output
# ---------------------------------------------------------------------------


def extract_terminals_from_output(output: Dict[str, Any]) -> List[Tuple[str, str, None, None]]:
    """Return (var, language, home_hint=None, cpp_kind=None) tuples for terminal dep_vars.

    A dep_var is terminal if ALL its chain_file_results and downstream_file_results have
    empty setter_sites (the backward trace found no setter instruction for it).
    """
    terminals: List[Tuple[str, str, None, None]] = []
    dvt = output.get("dep_var_traces") or {}
    for dv, traces in dvt.items():
        if not isinstance(traces, dict):
            continue
        cfr = traces.get("chain_file_results") or {}
        dfr = traces.get("downstream_file_results") or {}
        all_results = {**cfr, **dfr}

        if not all_results:
            # Discovered but never traced (hit depth/var limit) — treat as terminal
            terminals.append((str(dv), "asm", None, None))
            continue

        has_setter = any(
            len(fr.get("setter_sites") or []) > 0
            for fr in all_results.values()
            if isinstance(fr, dict)
        )
        if not has_setter:
            file_types = {
                str(fr.get("file_type") or "asm")
                for fr in all_results.values()
                if isinstance(fr, dict) and fr.get("file_type")
            }
            lang = "cpp" if "cpp" in file_types else "asm"
            terminals.append((str(dv), lang, None, None))

    return terminals


def extract_terminals_from_partitioned_dir(
    dep_vars_dir: Path,
) -> List[Tuple[str, str, None, None]]:
    """Scan a partitioned dep_vars/ directory and return terminal dep_vars.

    Each file was written by _DepVarWriter with an embedded ``dep_var`` key
    (added during this feature).  Falls back to the filename stem for files
    written by older code.

    A dep_var is terminal if ALL its chain/downstream file results have empty
    setter_sites — i.e. the backward trace never found a setter for it.
    """
    terminals: List[Tuple[str, str, None, None]] = []
    dep_vars_dir = Path(dep_vars_dir)
    if not dep_vars_dir.is_dir():
        return terminals

    for fpath in sorted(dep_vars_dir.glob("*.json")):
        try:
            data = json.loads(fpath.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue

        var_name = data.get("dep_var") or fpath.stem
        cfr = data.get("chain_file_results") or {}
        dfr = data.get("downstream_file_results") or {}
        all_results = {**cfr, **dfr}

        if not all_results:
            terminals.append((var_name, "asm", None, None))
            continue

        has_setter = any(
            len(fr.get("setter_sites") or []) > 0
            for fr in all_results.values()
            if isinstance(fr, dict)
        )
        if not has_setter:
            file_types = {
                str(fr.get("file_type") or "asm")
                for fr in all_results.values()
                if isinstance(fr, dict) and fr.get("file_type")
            }
            lang = "cpp" if "cpp" in file_types else "asm"
            terminals.append((var_name, lang, None, None))

    return terminals


def extract_terminals_from_graph(graph: Dict[str, Any]) -> List[Tuple[str, None, None, None]]:
    """Return (var, language=None, home_hint=None, cpp_kind=None) for graph leaf nodes.

    Leaves are nodes that appear in `nodes` but NOT as `source` in any edge.
    The root variable is excluded (it may legitimately have no incoming edges).
    """
    root = str(graph.get("root_variable") or "").upper()
    sources = {str(e.get("source") or "") for e in (graph.get("edges") or [])}
    leaves = [
        (str(n.get("name") or ""), None, None, None)
        for n in (graph.get("nodes") or [])
        if str(n.get("name") or "") not in sources
        and str(n.get("name") or "") != root
    ]
    return leaves


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def classify_terminal_variables(
    terminal_vars: Iterable[Tuple[str, Any, Any, Any]],
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    graph_file: Optional[Path],
    *,
    use_llm: bool = True,
) -> List[Dict[str, Any]]:
    """Classify a collection of terminal variables.

    Args:
        terminal_vars: iterable of (var_name, language, home_hint, cpp_kind).
                       language: "asm" | "cpp" | None.
                       home_hint: optional stem hint (e.g. "da7gl") to narrow lookup.
                       cpp_kind: the C++ GVL node kind (e.g. "literal", "use") or None.
        blueprint_dir: directory containing *.mac.json, *.hpp.json, etc.
        asm_dir: directory with raw source files (for comment reading).
        graph_file: path to file_call_graph.json (used for counterpart resolution).
        use_llm: whether to invoke the LLM for low-confidence cases.

    Returns:
        List of classification dicts, one per input variable.
    """
    results: List[Dict[str, Any]] = []
    for item in terminal_vars:
        var_name = str(item[0] or "").strip()
        language = item[1] if len(item) > 1 else None
        home_hint = item[2] if len(item) > 2 else None
        cpp_kind = item[3] if len(item) > 3 else None

        if not var_name:
            continue
        try:
            rec = _classify_one(
                var_name, language, home_hint, cpp_kind,
                blueprint_dir, asm_dir, graph_file, use_llm,
            )
            results.append(rec)
        except Exception as e:
            logger.warning("classify_terminal_variables: error on %s: %s", var_name, e)
            results.append({
                "variable": var_name.upper(),
                "role": ROLE_SYSTEM,
                "confidence": 0.0,
                "method": "error",
                "declared_in": "",
                "declaration": "",
                "comment": "",
                "evidence": f"classification error: {e}",
                "certainty_of_location": "none",
            })

    return results
