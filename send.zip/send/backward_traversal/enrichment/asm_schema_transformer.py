"""Transform backward-lineage on-disk JSON output to the unified target schema.

This module is called as a post-processing step *after* enrichment
(``_enrich_dep_var_output``) completes.  It reads the enriched dep_var and
root_var files, transforms both ASM and CPP results to a common target schema,
and overwrites the files in-place.

Target schema (root variable)::

    {
      "rootVariable": {
        "name": "VAR_NAME",
        "setters": [{
          "setterId": 1,
          "value": "SOURCE_OPERAND",
          "setterCodeChunk": "         MVC TARGET,SOURCE",
          "location": {"file": "aa71", "startLine": 123, "endLine": 123},
          "conditions": [{"order": 1, "condition": "...", "relevantCodeChunk": "...", "location": {...}}],
          "dependentVariables": [{"name": "CHILD_VAR", "foundAt": {"file": "aa71", "startLine": 0, "endLine": 0}}]
        }]
      }
    }

Target schema (dep var)::

    {
      "dependentVariable": {
        "name": "DEP_VAR_NAME",
        "dependencies": [{"variableName": "PARENT", "foundAt": {...}, "relevantCodeChunk": ""}],
        "setters": [...]
      }
    }
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

# ── Condition / branch role sets (mirrors asm_backward_tracer._inst_to_role) ──

_CONDITION_ROLES: frozenset = frozenset({
    "COMPARE", "COMPARE_IMMEDIATE", "TEST_MASK", "COMPARE_PACKED",
    "TEST_REGISTER", "COMPARE_REGISTERS", "COMPARE_HALFWORD",
    "COMPARE_LOGICAL", "COMPARE_LOGICAL_REGISTERS", "CONDITION_CHECK",
})

_BRANCH_ROLES: frozenset = frozenset({
    "BRANCH", "BRANCH_EQUAL", "BRANCH_NOT_EQUAL", "BRANCH_ZERO",
    "BRANCH_NOT_ZERO", "BRANCH_HIGH", "BRANCH_NOT_HIGH",
    "BRANCH_MINUS", "BRANCH_NOT_MINUS", "BRANCH_STEP",
    "BRANCH_OVERFLOW", "BRANCH_NO_OVERFLOW", "BRANCH_PLUS",
    "BRANCH_NOT_PLUS",
})

_ALL_COND_BRANCH_ROLES: frozenset = _CONDITION_ROLES | _BRANCH_ROLES


# ─────────────────────────────────────────────────────────────────────────────
# Public entry point
# ─────────────────────────────────────────────────────────────────────────────

def transform_asm_output_dir(
    output_dir: Path,
    root_var_name: str,
) -> None:
    """Transform all backward-lineage files in *output_dir* to target schema.

    - ``root_var.json`` is overwritten in-place (both ASM and CPP modifiers).
    - Each ``dep_vars/*.json`` is overwritten in-place.
    """
    root_var_path = output_dir / "root_var.json"
    dep_vars_dir = output_dir / "dep_vars"

    if not root_var_path.exists():
        return

    root_var_data = json.loads(root_var_path.read_text(encoding="utf-8"))

    modifier_stem = root_var_data.get("modifier_file") or ""
    files_meta = root_var_data.get("files") or {}
    modifier_info = files_meta.get(modifier_stem) or {}
    modifier_is_cpp = modifier_info.get("file_type") == "cpp"

    if modifier_is_cpp:
        # ── Transform CPP root_var.json ──────────────────────────────────
        transformed_root = _transform_cpp_root_var(root_var_data)
        root_var_path.write_text(
            json.dumps(transformed_root, indent=2), encoding="utf-8"
        )
        logger.debug("[schema_transformer] root_var.json transformed (CPP)")
    else:
        # ── Transform ASM root_var.json ──────────────────────────────────
        transformed_root = _transform_root_var(root_var_data)
        root_var_path.write_text(
            json.dumps(transformed_root, indent=2), encoding="utf-8"
        )
        logger.debug("[schema_transformer] root_var.json transformed (ASM)")

    # ── Transform each dep_var file ──────────────────────────────────────
    if dep_vars_dir.exists():
        for fpath in sorted(dep_vars_dir.glob("*.json")):
            try:
                dv_data = json.loads(fpath.read_text(encoding="utf-8"))
                transformed = _transform_dep_var(dv_data, root_var_name)
                if transformed is None:
                    # Already in target schema or no content to transform.
                    continue
                fpath.write_text(
                    json.dumps(transformed, indent=2), encoding="utf-8"
                )
            except Exception as exc:
                logger.debug(
                    "[schema_transformer] failed to transform %s: %s",
                    fpath.name, exc,
                )


# ─────────────────────────────────────────────────────────────────────────────
# Root variable transformer
# ─────────────────────────────────────────────────────────────────────────────

def _transform_root_var(root_var_data: Dict[str, Any]) -> Dict[str, Any]:
    """Transform root_var.json to ``{ rootVariable: { name, setters } }``."""
    root_name = root_var_data.get("root_variable") or ""
    modifier_stem = root_var_data.get("modifier_file") or ""
    files_meta = root_var_data.get("files") or {}

    modifier_payload = (files_meta.get(modifier_stem) or {}).get("modifier") or {}
    setter_sites = modifier_payload.get("setter_sites") or []
    traces = modifier_payload.get("setter_site_traces") or []

    setters = _build_setters_from_sites_and_traces(setter_sites, traces, modifier_stem)

    return {
        "rootVariable": {
            "name": root_name,
            "setters": setters,
        },
        # Preserve metadata the API layer or downstream readers may need.
        "traversal_mode": root_var_data.get("traversal_mode"),
        "selected_chain": root_var_data.get("selected_chain"),
        "modifier_file": modifier_stem,
        "warnings": root_var_data.get("warnings") or [],
        "truncated": root_var_data.get("truncated", False),
        "truncation_detail": root_var_data.get("truncation_detail") or {},
        "root_setter_found": root_var_data.get("root_setter_found", False),
        "root_var_downstream_traces": root_var_data.get("root_var_downstream_traces") or {},
    }


# ─────────────────────────────────────────────────────────────────────────────
# CPP Root variable transformer
# ─────────────────────────────────────────────────────────────────────────────

def _transform_cpp_root_var(root_var_data: Dict[str, Any]) -> Dict[str, Any]:
    """Transform a CPP root_var.json to the same target schema as ASM.

    CPP setter_sites have fields: ``line``, ``routine``, ``file``, ``expression``,
    ``conditional_context``.  CPP setter_site_traces have: ``guard_conditions``,
    ``dep_vars``, ``edges``, ``nodes``.
    """
    root_name = root_var_data.get("root_variable") or ""
    modifier_stem = root_var_data.get("modifier_file") or ""
    files_meta = root_var_data.get("files") or {}

    modifier_payload = (files_meta.get(modifier_stem) or {}).get("modifier") or {}
    setter_sites = modifier_payload.get("setter_sites") or []
    traces = modifier_payload.get("setter_site_traces") or []

    setters = _build_cpp_setters(setter_sites, traces, modifier_stem)

    return {
        "rootVariable": {
            "name": root_name,
            "setters": setters,
        },
        "traversal_mode": root_var_data.get("traversal_mode"),
        "selected_chain": root_var_data.get("selected_chain"),
        "modifier_file": modifier_stem,
        "warnings": root_var_data.get("warnings") or [],
        "truncated": root_var_data.get("truncated", False),
        "truncation_detail": root_var_data.get("truncation_detail") or {},
        "root_setter_found": root_var_data.get("root_setter_found", False),
        "root_var_downstream_traces": root_var_data.get("root_var_downstream_traces") or {},
    }


def _build_cpp_setters(
    setter_sites: List[Dict[str, Any]],
    traces: List[Dict[str, Any]],
    file_stem: str,
    start_id: int = 0,
) -> List[Dict[str, Any]]:
    """Build target-schema ``setters[]`` from CPP setter_sites and traces."""
    setters: List[Dict[str, Any]] = []
    for i, site in enumerate(setter_sites):
        trace = traces[i] if i < len(traces) else {}
        entry = _build_cpp_setter(start_id + i, site, trace, file_stem)
        setters.append(entry)
    return setters


def _build_cpp_setter(
    idx: int,
    site: Dict[str, Any],
    trace: Dict[str, Any],
    file_stem: str,
) -> Dict[str, Any]:
    """Build a single setter entry from CPP data.

    CPP sites use ``expression`` (not ``setter_expression``), ``file`` (full path),
    and ``conditional_context`` (list of strings).  Traces use ``guard_conditions``
    and flat ``dep_vars`` list.
    """
    conditions = _extract_cpp_conditions(site, trace, file_stem)
    dep_vars = _extract_cpp_dep_vars(trace, file_stem)

    # CPP ``file`` is a full path — extract stem for consistency.
    raw_file = str(site.get("file") or "")
    site_file_stem = Path(raw_file).stem if raw_file else file_stem

    return {
        "setterId": idx + 1,
        "value": site.get("expression") or "",
        "setterCodeChunk": site.get("expression") or "",
        "location": {
            "file": site_file_stem,
            "startLine": site.get("line") or 0,
            "endLine": site.get("line") or 0,
        },
        "conditions": conditions,
        "dependentVariables": dep_vars,
    }


def _extract_cpp_conditions(
    site: Dict[str, Any],
    trace: Dict[str, Any],
    file_stem: str,
) -> List[Dict[str, Any]]:
    """Extract conditions from CPP site's conditional_context and trace guard_conditions."""
    conditions: List[Dict[str, Any]] = []
    seen: Set[str] = set()
    order = 0

    # 1) Site-level conditional_context (direct prerequisites for this setter)
    for cc in (site.get("conditional_context") or []):
        cc_str = str(cc)
        if cc_str in seen:
            continue
        seen.add(cc_str)
        order += 1
        conditions.append({
            "order": order,
            "condition": cc_str,
            "relevantCodeChunk": cc_str,
            "location": {
                "file": file_stem,
                "startLine": site.get("line") or 0,
                "endLine": site.get("line") or 0,
            },
        })

    # 2) Trace-level guard_conditions (broader control flow guards)
    for gc in (trace.get("guard_conditions") or []):
        expr = str(gc.get("expression") or "")
        if not expr or expr in seen:
            continue
        seen.add(expr)
        order += 1
        gc_file = str(gc.get("file") or "")
        gc_file_stem = Path(gc_file).stem if gc_file else file_stem
        conditions.append({
            "order": order,
            "condition": expr,
            "relevantCodeChunk": expr,
            "location": {
                "file": gc_file_stem,
                "startLine": gc.get("line") or 0,
                "endLine": gc.get("line") or 0,
            },
        })

    return conditions


def _extract_cpp_dep_vars(
    trace: Dict[str, Any],
    file_stem: str,
) -> List[Dict[str, Any]]:
    """Extract dependent variables from a CPP trace's flat dep_vars list."""
    dep_vars: List[Dict[str, Any]] = []
    seen: Set[str] = set()

    for dv in (trace.get("dep_vars") or []):
        dv_str = str(dv)
        if dv_str in seen:
            continue
        seen.add(dv_str)
        dep_vars.append({
            "name": dv_str,
            "foundAt": {"file": file_stem, "startLine": 0, "endLine": 0},
        })

    return dep_vars


# ─────────────────────────────────────────────────────────────────────────────
# Dep-var transformer
# ─────────────────────────────────────────────────────────────────────────────

def _transform_dep_var(
    dep_var_data: Dict[str, Any],
    root_var_name: str,
) -> Optional[Dict[str, Any]]:
    """Transform a single dep_var JSON to ``{ dependentVariable: { name, dependencies, setters } }``.

    Returns ``None`` when the dep_var is already in target schema (has
    ``dependentVariable`` key) or has no file results to transform.
    """
    # Skip if already transformed (has dependentVariable key).
    if "dependentVariable" in dep_var_data:
        return None

    dv_name = dep_var_data.get("dep_var") or ""

    # ── Collect setters from all file results (ASM + CPP) ────────────────
    setters: List[Dict[str, Any]] = []
    setter_id = 0
    has_results = False

    for bucket_key in ("chain_file_results", "downstream_file_results"):
        results = dep_var_data.get(bucket_key) or {}
        for file_stem, file_result in results.items():
            is_cpp = file_result.get("file_type") == "cpp"
            sites = file_result.get("setter_sites") or []
            traces = file_result.get("setter_site_traces") or []

            if not sites:
                continue

            has_results = True
            if is_cpp:
                file_setters = _build_cpp_setters(
                    sites, traces, file_stem, start_id=setter_id,
                )
            else:
                file_setters = _build_setters_from_sites_and_traces(
                    sites, traces, file_stem, start_id=setter_id,
                )
            setter_id += len(file_setters)
            setters.extend(file_setters)

    # If no file results with setter_sites were found, still transform the
    # structure — the dep_var may legitimately have zero setters.

    # ── Build dependencies from parent tracking ──────────────────────────
    parent_vars = dep_var_data.get("_parent_vars") or []
    depth = dep_var_data.get("depth", 0)
    if not parent_vars and depth == 0 and root_var_name:
        parent_vars = [root_var_name]

    dependencies = []
    for pv in parent_vars:
        dependencies.append({
            "variableName": pv,
            "foundAt": {"file": "", "startLine": 0, "endLine": 0},
            "relevantCodeChunk": "",
        })

    result: Dict[str, Any] = {
        "dependentVariable": {
            "name": dv_name,
            "dependencies": dependencies,
            "setters": setters,
        },
        # Preserve enrichment metadata.
        "classification": dep_var_data.get("classification"),
        "setter_locations": dep_var_data.get("setter_locations"),
        "scope_files_checked": dep_var_data.get("scope_files_checked"),
        "depth": depth,
        "truncated": dep_var_data.get("truncated", False),
    }
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Shared helpers
# ─────────────────────────────────────────────────────────────────────────────

def _build_setters_from_sites_and_traces(
    setter_sites: List[Dict[str, Any]],
    traces: List[Dict[str, Any]],
    file_stem: str,
    start_id: int = 0,
) -> List[Dict[str, Any]]:
    """Build target-schema ``setters[]`` from paired setter_sites and traces.

    setter_sites[i] and traces[i] are 1:1 (confirmed in backward_only_runner.py
    ``_build_dep_var_file_result``, lines 2114-2126).  When the traces list is
    shorter (e.g. extended files where traces are empty), missing traces are
    treated as empty.
    """
    setters: List[Dict[str, Any]] = []
    for i, site in enumerate(setter_sites):
        trace = traces[i] if i < len(traces) else {}
        entry = _build_setter(start_id + i, site, trace, file_stem)
        setters.append(entry)
    return setters


def _build_setter(
    idx: int,
    site: Dict[str, Any],
    trace: Dict[str, Any],
    file_stem: str,
) -> Dict[str, Any]:
    """Build a single setter entry in target schema format."""
    conditions = _extract_conditions(trace, file_stem)
    dep_vars = _extract_dependent_variables(trace, file_stem)

    return {
        "setterId": idx + 1,
        "value": site.get("setter_expression") or "",
        "setterCodeChunk": site.get("raw_line") or "",
        "location": {
            "file": file_stem,
            "startLine": site.get("line") or 0,
            "endLine": site.get("line") or 0,
        },
        "conditions": conditions,
        "dependentVariables": dep_vars,
    }


def _extract_conditions(
    trace: Dict[str, Any],
    file_stem: str,
) -> List[Dict[str, Any]]:
    """Extract ordered conditions from a trace's call_graph nodes.

    Walks ``trace.call_graph.nodes[].relevant_code_lines[]`` and collects
    entries whose role is a test/compare or branch instruction.
    """
    conditions: List[Dict[str, Any]] = []
    order = 0
    call_graph = trace.get("call_graph") or {}
    for node in (call_graph.get("nodes") or []):
        for rl in (node.get("relevant_code_lines") or []):
            role = rl.get("role") or ""
            if role not in _ALL_COND_BRANCH_ROLES:
                continue
            order += 1
            detail = rl.get("detail") or ""
            conditions.append({
                "order": order,
                "condition": detail,
                "relevantCodeChunk": detail,
                "location": {
                    "file": file_stem,
                    "startLine": rl.get("line") or 0,
                    "endLine": rl.get("line") or 0,
                },
            })
    return conditions


def _extract_dependent_variables(
    trace: Dict[str, Any],
    file_stem: str,
) -> List[Dict[str, Any]]:
    """Extract dependent variables with ``foundAt`` locations from a trace.

    Merges node-level ``dependent_variables`` (which carry block context) with
    the flat ``trace.dep_vars`` list.  Deduplicates by name.
    """
    dep_vars: List[Dict[str, Any]] = []
    seen: Set[str] = set()

    call_graph = trace.get("call_graph") or {}
    for node in (call_graph.get("nodes") or []):
        for dv in (node.get("dependent_variables") or []):
            dv_upper = str(dv).upper()
            if dv_upper in seen:
                continue
            seen.add(dv_upper)
            # Try to find a line where this dep_var appears in the node.
            line = 0
            for rl in (node.get("relevant_code_lines") or []):
                detail_str = str(rl.get("detail") or "")
                if dv_upper in detail_str.upper():
                    line = rl.get("line") or 0
                    break
            dep_vars.append({
                "name": dv,
                "foundAt": {
                    "file": file_stem,
                    "startLine": line,
                    "endLine": line,
                },
            })

    # Also include flat dep_vars from the trace that may not appear in nodes.
    for dv in (trace.get("dep_vars") or []):
        dv_upper = str(dv).upper()
        if dv_upper not in seen:
            seen.add(dv_upper)
            dep_vars.append({
                "name": dv,
                "foundAt": {"file": file_stem, "startLine": 0, "endLine": 0},
            })

    return dep_vars
