"""Terminal variable enrichment — declaration lookup and role classification."""
