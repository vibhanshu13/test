"""Setter-location finder — where is a variable set?

Given a variable name, list every place it is **set** (written), across the
whole codebase:

* **ASM variable**  → ``(file, line)`` list  (with the setter instruction).
* **C++ variable**  → ``(file, function, line)`` list.

Primary use is the **C++** case.

Reuse over reinvention
----------------------
The hard part — deciding what counts as a "setter" — is already solved by
``chainless_setter_enumerator.enumerate_setter_roots``:

* **ASM**: a per-file scan via ``_find_scoped_setter_sites`` driven by the
  glossary (``SETTER_INST`` + ``classify_setter`` and its edge cases — implicit
  setters like GETCC/DETAC, read-modify-write, FLIPC aliases, hardware sources).
* **C++**: the global GVL ``assign`` / ``define`` edges into the variable's seed
  nodes, attributed to the file they occur in.

This module calls that enumerator (the same engine the Setter Analysis feature
uses, with the de-dup / declaration / collapse fixes), then **reshapes** each
setter root into the requested ``(file, line)`` / ``(file, function, line)``
shape — resolving the C++ enclosing function from the GVL ``scope`` of the
assignment edge.  Declarations (copybook ``define`` with no real write) are kept
separate, not listed as setters.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from backward_traversal.runner import chainless_reachability as RCH


def _function_by_nearest_scope(bp: Dict[str, Any], line: int) -> str:
    """Resolve the enclosing function of an unscoped line by the nearest
    PRECEDING well-scoped edge.

    Last-resort for an assignment the parser left scoped to ``(global)`` (e.g. a
    write inside a switch/case).  C++ function bodies are contiguous, so the
    function of the largest well-scoped edge line ``<= line`` is the enclosing
    one.  (Symbol start-lines are unreliable here — they include prototypes
    declared far from the definition.)
    """
    best_fn, best_line = "", -1
    for e in ((bp.get("variable_lineage") or {}).get("edges") or []):
        sc = str(e.get("scope") or "")
        if not sc or sc == "(global)" or "/" in sc or "\\" in sc:
            continue
        ln = e.get("line")
        if ln and best_line < int(ln) <= int(line or 0):
            best_line, best_fn = int(ln), sc
    return best_fn


def _cpp_function_at(stem: str, line: int, variable: str, blueprint_dir: Path) -> str:
    """The C++ function that contains the assignment at ``line``.

    1. the GVL assign/define edge's ``scope`` (what the parser recorded);
    2. the scoped GVL node id on that line;
    3. fallback — the function whose well-scoped edge-line span contains the
       line (covers assignments the parser left scoped to ``(global)``).
    """
    bp = RCH._load_bp(stem, "cpp", Path(blueprint_dir))
    if not bp:
        return ""
    var_l = str(variable).lower()
    for e in ((bp.get("variable_lineage") or {}).get("edges") or []):
        if e.get("line") != line:
            continue
        if str(e.get("relation") or "").lower() not in ("assign", "define"):
            continue
        if var_l not in str(e.get("target") or "").lower():
            continue
        sc = str(e.get("scope") or "")
        if sc and sc != "(global)":
            return sc
    fn = RCH._enclosing_function(bp, int(line or 0), str(variable))
    if fn:
        return fn
    # 3) nearest preceding well-scoped edge (covers parser (global) misses).
    return _function_by_nearest_scope(bp, int(line or 0))


def find_setter_locations(
    variable: str,
    *,
    blueprint_dir: Path,
    graph_file: Path,
    asm_dir: Optional[Path] = None,
    job_id: Optional[str] = None,
    language: Optional[str] = None,
    include_declarations: bool = False,
) -> Dict[str, Any]:
    """List every place ``variable`` is set.

    Returns::

        {
          "variable": str,
          "language": "asm" | "cpp" | "mixed",
          "asm_setters":  [{"file", "line", "instruction", "expression"}],
          "cpp_setters":  [{"file", "function", "line", "expression"}],
          "declarations": [{"file", "function", "line", "file_type"}],   # if any
          "warnings": [...],
          "stats": {...},
        }
    """
    from backward_traversal.runner.chainless_setter_enumerator import enumerate_setter_roots

    blueprint_dir = Path(blueprint_dir)
    roots, _counterparts, warns = enumerate_setter_roots(
        variable, language, blueprint_dir, Path(graph_file), asm_dir,
        job_id=job_id, expand_counterparts=False,
    )

    asm_setters: List[Dict[str, Any]] = []
    cpp_setters: List[Dict[str, Any]] = []
    declarations: List[Dict[str, Any]] = []
    seen_asm: set = set()
    seen_cpp: set = set()

    for r in roots:
        if getattr(r, "is_declaration", False):
            fn = (_cpp_function_at(r.file_stem, r.line, variable, blueprint_dir)
                  if r.file_type == "cpp" else "")
            declarations.append({
                "file": r.file_stem, "function": fn or None,
                "line": r.line, "file_type": r.file_type,
            })
            continue
        if r.file_type == "asm":
            key = (r.file_stem, r.line, r.instruction)
            if key in seen_asm:
                continue
            seen_asm.add(key)
            asm_setters.append({
                "file": r.file_stem, "line": r.line,
                "instruction": r.instruction,
                "expression": r.setter_expression or None,
            })
        else:
            fn = _cpp_function_at(r.file_stem, r.line, variable, blueprint_dir)
            key = (r.file_stem, fn, r.line)
            if key in seen_cpp:
                continue
            seen_cpp.add(key)
            cpp_setters.append({
                "file": r.file_stem, "function": fn or None, "line": r.line,
                "expression": r.setter_expression or None,
            })

    asm_setters.sort(key=lambda s: (s["file"], s["line"]))
    cpp_setters.sort(key=lambda s: (s["file"], s["line"]))

    lang = ("mixed" if (asm_setters and cpp_setters)
            else ("asm" if asm_setters else "cpp"))

    out: Dict[str, Any] = {
        "variable": variable,
        "language": lang,
        "asm_setters": asm_setters,
        "cpp_setters": cpp_setters,
        "warnings": warns,
        "stats": {
            "asm_setter_count": len(asm_setters),
            "cpp_setter_count": len(cpp_setters),
            "declaration_count": len(declarations),
            "files": sorted({s["file"] for s in asm_setters} | {s["file"] for s in cpp_setters}),
        },
    }
    if include_declarations or declarations:
        out["declarations"] = declarations
    return out
