"""Backward BFS over a global_variable_lineage graph (C++ side).

Mirrors the shape of trace_asm_call_site_backward but operates on the
pre-built lineage graph stored in cpp.json blueprints rather than raw ASM
source + blueprint CFG.  Used when the backward chain crosses into a C++
upstream file.
"""

from __future__ import annotations

import os
import re
from collections import deque
from typing import Any, Dict, List, Optional, Set, Tuple

DEFAULT_CPP_MAX_DEPTH = 6
DEFAULT_CPP_MAX_NODES = 300

# Kinds treated as condition-source variables when extracting guard conditions.
_COND_SOURCE_KINDS: Set[str] = {"variable", "struct_field", "array_element"}

# Maximum GVL file size (bytes) for which the BFS reverse-index is built.
# Building the full reverse-index for a 3–4 GB GVL allocates 10–15 GB of
# Python objects and OOMs the process.  When the GVL exceeds this limit the
# BFS is skipped and a warning is emitted.  Override via env var:
#   ASM_GVL_BFS_MAX_MB=2048 python3 -m backward_traversal.cli ...
_GVL_BFS_MAX_BYTES: int = int(os.environ.get("ASM_GVL_BFS_MAX_MB", "512")) * 1024 * 1024

# Edge relations we follow backward (data-flow edges only).
_FOLLOW_RELATIONS: Set[str] = {"assign", "define", "arg_bind"}

# Relations that represent same-memory-location cross-context links.
# Followed with a depth penalty (+2) to limit chain length.  (FIX 12, FIX 14)
_BRIDGE_RELATIONS: Set[str] = {"ecb_bridge", "ce1cr_level_bridge"}

# Relations that represent name aliasing — same variable, different name.
# Followed at depth +0; NOT added to dep_vars.  (FIX 13)
_ALIAS_RELATIONS: Set[str] = {"alias"}

# Kinds treated as terminals — we record them but don't expand.
# NOTE: "memory" was previously listed here but has been removed.  Pointer
# dereference writes (*ptr = val) in C++ produce assign edges whose TARGET is
# a memory: node (e.g. memory:fn::ptr).  Treating memory: as terminal caused
# the BFS to stop at the seed without ever traversing those assign edges, so
# setter_sites like `*casGlosOutputMessage = outputMessage1` were silently
# dropped.  z/TPF system infrastructure memory: nodes (CE1CR*, level:*) are
# handled by _is_system_terminal() / _SYSTEM_TERMINAL_PREFIXES, and
# cross-layer stitch edges are filtered by _SKIP_STITCH_RE / _should_follow_edge.
_TERMINAL_KINDS: Set[str] = {"literal", "function", "use"}

# Kinds that represent ASM-side data; we surface these as bridge dep_vars.
_REGISTER_KINDS: Set[str] = {"register"}

# global_lineage_stitch expression prefixes we skip when walking backward
# (they are cross-layer stitching edges, not intra-C++ data flow).
# Compiled regex replaces 5 sequential .startswith() checks with a single match.
_SKIP_STITCH_RE = re.compile(
    r"^global_lineage_stitch:"
    r"(?:tpf_regs_register_bridge|return_unify|ecb_mapping|glob_globals|asm_alias)"
)

# z/TPF system infrastructure node prefixes — reached but never expanded.
# (FIX 14)
_SYSTEM_TERMINAL_PREFIXES = (
    "memory:CE1CR",   # z/TPF ECB register fields (CE1CR0–CE1CR9)
    "memory:level:",  # Abstract level block identifiers
)

_REG_RE = re.compile(r"\bR(\d+)\b", re.IGNORECASE)
_SRC_EXT_RE = re.compile(r"\.(?:cpp|cc|cxx|hpp|hh|hxx|c|h)$", re.IGNORECASE)


def _safe_str(v: Any) -> str:
    return str(v or "")


def _scope_from_node_id(node_id: str) -> str:
    """Extract enclosing function name from a GVL node ID like 'kind:fn::name'.

    Returns '' for file-scope globals (path contains '/' or ends with a source
    extension) so those aren't mistakenly treated as function names.
    """
    if "::" not in node_id:
        return ""
    after_kind = node_id.split(":", 1)[-1] if ":" in node_id else node_id
    fn = after_kind.split("::")[0]
    if "/" in fn or "\\" in fn or _SRC_EXT_RE.search(fn):
        return ""
    return fn


def _file_from_node_id(node_id: str) -> str:
    """Extract a file path embedded in a GVL node ID like 'kind:/path/to/file.cpp::name'.

    Returns the full path string when present, '' otherwise.
    """
    if "::" not in node_id:
        return ""
    after_kind = node_id.split(":", 1)[-1] if ":" in node_id else node_id
    segment = after_kind.split("::")[0]
    if "/" in segment or "\\" in segment or _SRC_EXT_RE.search(segment):
        return segment
    return ""


def _is_system_terminal(node_id: str) -> bool:
    """True for z/TPF system infrastructure nodes (allocation addresses, not data).

    These are reached during traversal but never expanded — they represent the
    address of a system-allocated block, not a data value.  (FIX 14)
    """
    return any(node_id.startswith(p) for p in _SYSTEM_TERMINAL_PREFIXES)


def _build_reverse_index(
    gvl: Any,
) -> Any:
    """Build target_id → [edge, ...] index over all lineage edges.

    When *gvl* is a DB-backed GVL (``DbLazyGVL`` or ``IndexDbGVL``), returns a
    ``_DbReverseIndex`` that queries the DB per-target using the
    ``ix_gvl_edges_job_tgt`` index.  Peak RAM is O(BFS frontier) rather than
    O(all edges), which avoids the 80 GB allocation that building a full
    in-memory dict would require for large codebases.

    For file-backed GVL the original full in-memory dict is built.
    """
    if hasattr(gvl, "make_reverse_index"):
        return gvl.make_reverse_index()
    idx: Dict[str, List[Dict[str, Any]]] = {}
    for e in (gvl.get("edges") or []):
        tgt = _safe_str(e.get("target")).strip()
        if tgt:
            idx.setdefault(tgt, []).append(e)
    return idx


def _build_node_lookup(gvl: Any) -> Any:
    """Build node_id → node dict lookup for the GVL.

    When *gvl* is a DB-backed GVL (``DbLazyGVL`` or ``IndexDbGVL``), returns a
    ``_DbNodeLookup`` that queries the DB per-node-id using the
    ``ix_gvl_nodes_job_node`` index.  Peak RAM is O(BFS visited nodes) rather
    than O(all nodes), which avoids the 250 MB – 1.1 GB allocation that
    building a full in-memory dict would require for large codebases.

    For file-backed GVL the original full in-memory dict is built.
    """
    if hasattr(gvl, "make_node_lookup"):
        return gvl.make_node_lookup()
    return {_safe_str(n.get("id")).strip(): n for n in (gvl.get("nodes") or []) if n.get("id")}


def _should_follow_edge(e: Dict[str, Any]) -> bool:
    """Decide whether to follow an incoming edge during backward BFS."""
    rel = _safe_str(e.get("relation")).lower()
    # Bridge and alias relations are always followable (no stitch-expr filter needed)
    if rel in _BRIDGE_RELATIONS or rel in _ALIAS_RELATIONS:
        return True
    if rel not in _FOLLOW_RELATIONS:
        return False
    # Single compiled regex replaces 5 sequential .startswith() checks.
    # Allow cpp_field_to_asm in the SOURCE direction so we can see the
    # reverse alias (C++ field ← ASM-aliased field).
    expr = _safe_str(e.get("expression"))
    return not bool(_SKIP_STITCH_RE.match(expr))


def _extract_bridge_reg(node: Dict[str, Any]) -> Optional[str]:
    """If node is a register, return its name (e.g. 'R7'); else None."""
    kind = _safe_str(node.get("kind")).lower()
    if kind not in _REGISTER_KINDS:
        return None
    name = _safe_str(node.get("name") or node.get("id"))
    m = _REG_RE.search(name)
    if not m:
        return None
    num = int(m.group(1))
    return f"R{num}" if num <= 15 else None


def _extract_guard_conditions(
    per_file_lineage: Dict[str, Any],
    variable_name: str,
    existing_dep_var_names: Set[str],
) -> Tuple[List[Dict[str, Any]], List[str]]:
    """Scan per-file variable_lineage for _cond use edges that guard assignments to variable_name.

    Steps:
      1. Find assign/define edges whose target ends with `.variable_name` or `::variable_name` →
         collect their function scopes.
      2. Find `_cond` use edges in those same scopes (plus `(global)` scope, which arises
         when tree_sitter was unavailable and scope detection degraded to file-level).
      3. Return (guard_conditions, extra_dep_var_names) so callers can surface the conditions
         and add any newly discovered conditioning variables to dep_vars.

    Returns an empty pair when per_file_lineage is absent or no assignment sites are found.
    """
    if not per_file_lineage or not variable_name:
        return [], []

    edges = per_file_lineage.get("edges") or []
    var_lower = variable_name.lower()

    # ── Step 1: collect function scopes that assign the variable ────────────────
    assignment_scopes: Set[str] = set()
    has_global_scope_assign = False
    max_setter_line_per_scope: Dict[str, int] = {}
    for e in edges:
        rel = _safe_str(e.get("relation")).lower()
        if rel not in ("assign", "define"):
            continue
        tgt = _safe_str(e.get("target")).lower()
        # Target ends with .varname, ::varname or :varname
        if not (
            tgt.endswith(f".{var_lower}")
            or tgt.endswith(f"::{var_lower}")
            or tgt.endswith(f":{var_lower}")
        ):
            continue
        scope = _safe_str(e.get("scope") or "(global)")
        ln = int(e.get("line") or 0)
        if scope == "(global)":
            has_global_scope_assign = True
            if ln:
                max_setter_line_per_scope["(global)"] = max(
                    max_setter_line_per_scope.get("(global)", 0), ln
                )
        else:
            assignment_scopes.add(scope)
            if ln:
                max_setter_line_per_scope[scope] = max(
                    max_setter_line_per_scope.get(scope, 0), ln
                )

    if not assignment_scopes and not has_global_scope_assign:
        return [], []

    # ── Step 2: collect _cond use edges in matching scopes ──────────────────────
    guard_conditions: List[Dict[str, Any]] = []
    seen_cond_keys: Set[str] = set()
    extra_dep_var_names: List[str] = []
    seen_extra: Set[str] = set()

    for e in edges:
        if _safe_str(e.get("relation")).lower() != "use":
            continue
        stmt_id = _safe_str(e.get("statement_id"))
        if "_cond" not in stmt_id:
            continue

        scope = _safe_str(e.get("scope") or "(global)")
        # Include when: scope is one of the assignment scopes, OR scope is (global)
        # (covers tree_sitter_unavailable files where all conditions degrade to global scope,
        # and also file-level guards in well-parsed files).
        if scope not in assignment_scopes and scope != "(global)":
            continue

        # Skip conditions at or after the last setter line in this scope — those
        # are post-assignment guards that belong to code executed after the variable
        # was already set and should not be treated as guards for this setter.
        ln = int(e.get("line") or 0)
        max_sl = max_setter_line_per_scope.get(scope, 0)
        if ln and max_sl and ln >= max_sl:
            continue

        cond_key = f"{e.get('line')}:{stmt_id}"
        if cond_key in seen_cond_keys:
            continue
        seen_cond_keys.add(cond_key)

        cond_ctx = e.get("conditional_context") or []
        if isinstance(cond_ctx, str):
            cond_ctx = [cond_ctx]

        guard_conditions.append({
            "file": _safe_str(e.get("file")),
            "line": e.get("line"),
            "scope": scope,
            "expression": _safe_str(e.get("expression")),
            "conditional_context": cond_ctx,
        })

        # Extract conditioning variable name from source field
        src = _safe_str(e.get("source"))
        # Source format: "variable:scope::name" or "struct_field:scope::path.to.field"
        if not src:
            continue
        colon_idx = src.find(":")
        raw = src[colon_idx + 1:] if colon_idx >= 0 else src
        if "::" in raw:
            raw = raw.split("::")[-1]
        if "." in raw:
            raw = raw.split(".")[-1]
        if "->" in raw:
            raw = raw.split("->")[-1]
        raw = raw.strip()
        if (
            raw
            and raw.lower() != var_lower
            and raw not in existing_dep_var_names
            and raw not in seen_extra
        ):
            seen_extra.add(raw)
            extra_dep_var_names.append(raw)

    return guard_conditions, extra_dep_var_names


def trace_cpp_variable_backward(
    seed_id: str,
    gvl: Dict[str, Any],
    max_depth: int = DEFAULT_CPP_MAX_DEPTH,
    max_nodes: int = DEFAULT_CPP_MAX_NODES,
    max_alias_hops: int = 20,
    _reverse_idx: Optional[Dict[str, List[Dict[str, Any]]]] = None,  # FIX 4
    _node_lookup: Optional[Dict[str, Dict[str, Any]]] = None,         # FIX 4
    _seed_ids: Optional[Set[str]] = None,                             # P3-5: full seed set for consistent dep_var exclusion
    before_line: int = 0,                                             # scope: only follow edges at lines < before_line
    per_file_lineage: Optional[Dict[str, Any]] = None,               # GC: per-file lineage for guard condition extraction
    variable_name: str = "",                                          # GC: bare variable name for guard condition extraction
) -> Dict[str, Any]:
    """BFS backward over global_variable_lineage starting from seed_id.

    Returns a dict compatible with the ASM tracer call_graph shape so the
    runner can include it uniformly in upstream payload:
        {
          "nodes": [{"id":..,"kind":..,"name":..,"metadata":..,"relevant_edges":[...]}, ...],
          "edges": [{"source":..,"target":..,"relation":..,"line":..,"expression":..}, ...],
          "dep_vars": [...],          # free C++ variables referenced in upstream assignments
          "bridge_registers": [...],  # ASM registers encountered as terminals
          "truncated": bool,          # True when max_nodes or max_depth cap was hit (FIX 8)
          "warnings": [...],
        }

    Parameters
    ----------
    max_alias_hops:
        Secondary cap on alias-edge traversal.  Alias edges cost 0 depth, so
        a long typedef/cast chain can exhaust the node budget before any
        assign/define edge is reached.  Once this limit is hit, further alias
        expansion is skipped; assign/define/bridge edges are unaffected.  (FIX 13)
    _reverse_idx / _node_lookup:
        Pre-built indices shared across seeds in multi-seed calls.  When
        supplied, index construction is skipped (O(E) saving per seed).  (FIX 4)
    """
    if not seed_id or not gvl:
        return {
            "nodes": [], "edges": [], "dep_vars": [], "bridge_registers": [],
            "guard_conditions": [], "truncated": False, "warnings": [],
        }

    # FIX 4: reuse pre-built indices when supplied by the multi-seed caller
    reverse_idx = _reverse_idx if _reverse_idx is not None else _build_reverse_index(gvl)
    node_lookup = _node_lookup if _node_lookup is not None else _build_node_lookup(gvl)

    # P3-5: use the full seeds set (when provided by multi-seed caller) so that
    # all seed nodes are excluded from dep_vars, not just this trace's own seed.
    # Without this, seed A appears as a dep_var in seed B's trace but not its own.
    _excl_seeds: Set[str] = _seed_ids if _seed_ids is not None else {seed_id}

    visited: Set[str] = set()
    queue: deque = deque()
    queue.append((seed_id, 0, 0))  # (node_id, depth, alias_hops_on_path)

    result_nodes: List[Dict[str, Any]] = []
    result_edges: List[Dict[str, Any]] = []
    seen_edge_keys: Set[Tuple[str, str, str, Any]] = set()  # FIX 6: O(1) dedup (incl. line)
    dep_vars: List[str] = []
    bridge_regs: List[str] = []
    seen_dep_vars: Set[str] = set()
    seen_bridge_regs: Set[str] = set()
    warnings: List[str] = []
    truncated: bool = False           # FIX 8

    # Opt J: batch-prefetch support — every _PREFETCH_INTERVAL visited nodes,
    # peek at the next ≤_PREFETCH_BATCH unvisited queue items and prefetch
    # their edges in a single SQL query instead of per-node round-trips.
    _PREFETCH_INTERVAL = 20
    _PREFETCH_BATCH = 50
    _prefetch_counter = 0
    _has_prefetch = hasattr(reverse_idx, "prefetch")

    while queue:
        cur_id, depth, alias_hops_on_path = queue.popleft()
        if cur_id in visited:
            continue
        visited.add(cur_id)

        # Opt J: periodic frontier prefetch
        _prefetch_counter += 1
        if _has_prefetch and _prefetch_counter % _PREFETCH_INTERVAL == 0:
            _pf_targets = []
            for _pf_item in queue:
                if _pf_item[0] not in visited:
                    _pf_targets.append(_pf_item[0])
                if len(_pf_targets) >= _PREFETCH_BATCH:
                    break
            if _pf_targets:
                reverse_idx.prefetch(_pf_targets)

        # FIX 14: z/TPF system infrastructure — record as terminal, do not expand
        if _is_system_terminal(cur_id):
            result_nodes.append({
                "id": cur_id,
                "kind": "system_terminal",
                "name": cur_id.split(":")[-1],
                "metadata": {},
                "relevant_edges": [],
            })
            continue

        # Resolve node early so we can gate on kind before appending (FIX 15)
        node = node_lookup.get(cur_id) or {
            "id": cur_id,
            "kind": "unknown",
            "name": cur_id.split(":")[-1] if ":" in cur_id else cur_id,
        }
        kind = _safe_str(node.get("kind")).lower()

        # FIX 15: clobbered nodes have no data-flow source — skip entirely.
        # No record, no expansion, no budget consumed.  417 per large file.
        if kind == "clobbered":
            continue

        # Collect relevant incoming edges for this node (for the output)
        incoming_edges = reverse_idx.get(cur_id) or []
        # Filter followable edges ONCE — reused for both output metadata and
        # BFS expansion (avoids calling _should_follow_edge twice per edge).
        followable = [e for e in incoming_edges if _should_follow_edge(e)]

        relevant_edges = [
            {
                "source": _safe_str(e.get("source")),
                "relation": _safe_str(e.get("relation")),
                "line": e.get("line"),
                "expression": _safe_str(e.get("expression")),  # P3-2: full expr; truncate at serialization
                "file": _safe_str(e.get("file")),
            }
            for e in followable
        ]

        result_nodes.append({
            "id": cur_id,
            "kind": kind,
            "name": _safe_str(node.get("name") or cur_id),
            "metadata": node.get("metadata") or {},
            "relevant_edges": relevant_edges,
        })

        # FIX-new-10: cap check immediately after append so that register and
        # terminal nodes (which use `continue` below) cannot bypass the limit
        # and silently push result_nodes beyond max_nodes.
        if len(result_nodes) >= max_nodes:
            warnings.append(
                f"cpp_backward_tracer: max_nodes={max_nodes} reached at depth {depth}"
            )
            truncated = True
            break

        # Register terminal — surfaces as bridge back to ASM in both
        # bridge_registers and dep_vars so downstream can pivot back.
        reg = _extract_bridge_reg(node)
        if reg:
            if reg not in seen_bridge_regs:
                seen_bridge_regs.add(reg)
                bridge_regs.append(reg)
            bridge_dv = f"bridge_back_to_asm:{reg}"
            if bridge_dv not in seen_dep_vars:
                seen_dep_vars.add(bridge_dv)
                dep_vars.append(bridge_dv)
            continue  # do not expand registers

        # Other terminals — record but don't expand
        if kind in _TERMINAL_KINDS:
            continue

        # FIX 8: depth cap — set truncated flag on hit
        if depth >= max_depth:
            warnings.append(
                f"cpp_backward_tracer: max_depth={max_depth} reached for {cur_id}"
            )
            truncated = True
            continue

        # Expand via already-filtered followable edges
        for e in followable:
            # before_line: skip edges that represent assignments at or after the
            # caller's call-site line — those don't precede the variable use.
            # Alias and bridge edges carry no meaningful line; always follow them.
            rel_for_line = _safe_str(e.get("relation")).lower()
            if before_line and rel_for_line not in _ALIAS_RELATIONS and rel_for_line not in _BRIDGE_RELATIONS:
                edge_line = e.get("line") or 0
                if edge_line and edge_line >= before_line:
                    continue
            src = _safe_str(e.get("source")).strip()
            if not src:
                continue
            # Self-referential define edge (src == current node) — e.g. an
            # initialization `maintenanceResponseMessage = 0` that the GVL
            # represents as define(self→self).  We record it as a setter edge
            # (so _extract_cpp_setter_sites can surface the line as a
            # setter_site) but do NOT queue it for expansion.
            if src == cur_id:
                rel_sr = _safe_str(e.get("relation")).lower()
                _file_sr = _safe_str(e.get("file"))
                if not _file_sr:
                    _file_sr = _file_from_node_id(src) or _file_from_node_id(cur_id)
                _scope_sr = _safe_str(e.get("scope")) or _scope_from_node_id(src)
                edge_key_sr: Tuple[str, str, str, Any] = (src, cur_id, rel_sr, e.get("line"))
                if edge_key_sr not in seen_edge_keys:
                    seen_edge_keys.add(edge_key_sr)
                    _edge_sr: Dict[str, Any] = {
                        "source": src,
                        "target": cur_id,
                        "relation": rel_sr,
                        "line": e.get("line"),
                        "expression": _safe_str(e.get("expression")),
                        "file": _file_sr,
                        "scope": _scope_sr,
                    }
                    _cond_sr = e.get("conditional_context")
                    if _cond_sr:
                        _edge_sr["conditional_context"] = _cond_sr
                    result_edges.append(_edge_sr)
                continue  # do not expand — source is the current (already visited) node
            if src in visited:
                continue

            rel = _safe_str(e.get("relation")).lower()
            is_bridge = rel in _BRIDGE_RELATIONS
            is_alias = rel in _ALIAS_RELATIONS

            # FIX 6: O(1) set-based edge dedup keyed on (source, target, relation, line).
            # Line is part of the key: the same field assigned from the same source
            # at two different code lines (e.g. softCardValue at 1002 AND 1033) are
            # distinct setter statements and both must be recorded.
            edge_key: Tuple[str, str, str, Any] = (src, cur_id, rel, e.get("line"))
            if edge_key not in seen_edge_keys:
                seen_edge_keys.add(edge_key)
                # File attribution: use the edge's own file field; when absent,
                # infer from the source node ID (e.g. variable:/path/f.cpp::name).
                _file = _safe_str(e.get("file"))
                if not _file:
                    _file = _file_from_node_id(src) or _file_from_node_id(cur_id)
                # Scope: use GVL edge scope when present; derive from source node ID.
                _scope = _safe_str(e.get("scope")) or _scope_from_node_id(src) or _scope_from_node_id(cur_id)
                _edge_dict: Dict[str, Any] = {
                    "source": src,
                    "target": cur_id,
                    "relation": rel,
                    "line": e.get("line"),
                    "expression": _safe_str(e.get("expression")),  # P3-2: full expr
                    "file": _file,
                    "scope": _scope,
                }
                _cond_ctx = e.get("conditional_context")
                if _cond_ctx:
                    _edge_dict["conditional_context"] = _cond_ctx
                result_edges.append(_edge_dict)

            # Collect dep_vars: only for non-bridge, non-alias, non-seed sources.
            # Bridge = same variable in another function context (not a new dependency).
            # Alias  = same variable under a different name  (not a new dependency).
            # P3-5: exclude ALL seeds (not just this trace's seed) so that seed A
            # is not collected as a dep_var when tracing from seed B.
            if not is_bridge and not is_alias and src not in _excl_seeds:
                src_node = node_lookup.get(src)
                src_kind = _safe_str((src_node or {}).get("kind")).lower()
                if src_kind in ("variable", "struct_field", "array_element", "memory"):
                    # FIX 11: normalize raw GVL node IDs to terminal name component.
                    # When a node has no name field, src is a structured ID like
                    # "struct_field:fn::ptr->fieldName" — extract the terminal part.
                    raw_name = _safe_str((src_node or {}).get("name"))
                    if not raw_name:
                        src_id_str = _safe_str(src)
                        parts = re.split(r"::", src_id_str)
                        last_part = parts[-1].strip()
                        # Strip any remaining "kind:" prefix from the last part
                        if ":" in last_part:
                            last_part = last_part.split(":")[-1].strip()
                        raw_name = last_part or src_id_str
                    # Normalize path prefixes that C++ GVL embeds in the name field.
                    # Names like "fn::obj->field", "fn::struct.nested.field" must be
                    # reduced to their terminal component so downstream seed-finding
                    # and noise-filtering work on a plain identifier.
                    # 1. Strip function-scope prefix (e.g. "fn::rest" → "rest")
                    if "::" in raw_name:
                        raw_name = raw_name.split("::")[-1].strip()
                    # 2. Strip pointer-dereference chain (e.g. "da7gl->reply->code" → "code")
                    if "->" in raw_name:
                        raw_name = raw_name.split("->")[-1].strip()
                    # 3. Strip dot-notation struct access for struct_field only.
                    #    Memory node names (e.g. "EB&N3.USER") use dots for ECB
                    #    field names and must not be split.
                    if src_kind == "struct_field" and "." in raw_name:
                        raw_name = raw_name.split(".")[-1].strip()
                    src_name = raw_name
                    if src_name and src_name not in seen_dep_vars:
                        seen_dep_vars.add(src_name)
                        dep_vars.append(src_name)

            # FIX 13 (revised): per-path alias hop cap — each BFS branch gets its
            # own independent budget so a long typedef chain on one path does not
            # exhaust the budget for unrelated data-flow branches.
            if is_alias:
                if alias_hops_on_path >= max_alias_hops:
                    continue  # this path's alias budget exhausted; skip edge
                next_alias_hops = alias_hops_on_path + 1
            else:
                next_alias_hops = alias_hops_on_path

            # Depth cost: alias=+0 (structural), bridge=+2 (cross-function penalty),
            # all others=+1
            next_depth = depth + (0 if is_alias else 2 if is_bridge else 1)
            queue.append((src, next_depth, next_alias_hops))

    # GC: extract guard conditions from per-file lineage if provided.
    # extra_dep_vars (guard condition variables) are stored in both dep_vars (for
    # backward compat consumers) AND in _gc_dep_vars (so _scope_cpp_trace_to_file
    # can re-merge them after it recomputes dep_vars from setter edges only).
    guard_conditions: List[Dict[str, Any]] = []
    gc_dep_vars: List[str] = []
    if per_file_lineage and variable_name:
        guard_conditions, extra_dep_vars = _extract_guard_conditions(
            per_file_lineage, variable_name, set(dep_vars),
        )
        for ev in extra_dep_vars:
            gc_dep_vars.append(ev)
            if ev not in seen_dep_vars:
                seen_dep_vars.add(ev)
                dep_vars.append(ev)

    return {
        "nodes": result_nodes,
        "edges": result_edges,
        "dep_vars": dep_vars,
        "_gc_dep_vars": gc_dep_vars,    # preserved through _scope_cpp_trace_to_file
        "bridge_registers": bridge_regs,
        "guard_conditions": guard_conditions,
        "truncated": truncated,   # FIX 8
        "warnings": warnings,
    }


def trace_cpp_variable_backward_multi(
    seed_ids: List[str],
    gvl: Dict[str, Any],
    max_depth: int = DEFAULT_CPP_MAX_DEPTH,
    max_nodes: int = DEFAULT_CPP_MAX_NODES,
    before_line: int = 0,   # scope: only follow edges whose line < before_line (0 = no limit)
    per_file_lineage: Optional[Dict[str, Any]] = None,  # GC: per-file lineage for guard condition extraction
    variable_name: str = "",                            # GC: bare variable name
    _reverse_idx: Any = None,   # pre-built reverse index — avoids O(E) rebuild per call
    _node_lookup: Any = None,   # pre-built node lookup  — avoids O(N) rebuild per call
) -> Dict[str, Any]:
    """Run trace_cpp_variable_backward for multiple seed IDs and merge results.

    Deduplicates nodes and edges across all seeds so the merged output is a
    clean graph.

    FIX 4: builds reverse_idx and node_lookup once, shared across all seeds.
    FIX 7: enforces a shared max_nodes budget across all seeds — merged output
           never exceeds max_nodes total regardless of seed count.
    FIX 6: O(1) set-based edge dedup on the merged edge list.
    FIX 8: propagates truncated flag from any per-seed trace.
    """
    if not seed_ids or not gvl:
        return {
            "seeds": seed_ids, "nodes": [], "edges": [], "dep_vars": [],
            "_gc_dep_vars": [], "bridge_registers": [], "guard_conditions": [],
            "per_seed_traces": {}, "truncated": False, "warnings": [],
        }

    # GVL size guard: building a full reverse-index over a 3–4 GB GVL creates
    # 10–15 GB of Python objects and OOMs the process.  When the GVL exceeds
    # the configurable cap, we try three fallback strategies before skipping:
    #   1. Caller-provided pre-built indices (_reverse_idx/_node_lookup)
    #   2. DB-backed lazy indices via gvl.make_reverse_index() (IndexDbGVL)
    #   3. Skip BFS and return truncated result (last resort)
    # Guard conditions are always extracted from per_file_lineage (small, in-memory).
    _gvl_size = getattr(gvl, "file_size_bytes", 0)
    if not _gvl_size and isinstance(gvl, dict):
        _gvl_size = gvl.get("file_size_bytes", 0)
    _gvl_is_large = _gvl_size > _GVL_BFS_MAX_BYTES

    if _gvl_is_large:
        _limit_mb = _GVL_BFS_MAX_BYTES // (1024 * 1024)
        _actual_mb = _gvl_size // (1024 * 1024)
        _has_prebuilt = _reverse_idx is not None and _node_lookup is not None
        _has_db_backed = hasattr(gvl, "make_reverse_index")

        if _has_prebuilt:
            import logging as _logging
            _logging.getLogger(__name__).info(
                "[cpp_backward_tracer] GVL is %d MB (limit %d MB) — "
                "using caller-provided indices (DB-backed/lazy)",
                _actual_mb, _limit_mb,
            )
        elif _has_db_backed:
            import logging as _logging
            _logging.getLogger(__name__).info(
                "[cpp_backward_tracer] GVL is %d MB (limit %d MB) — "
                "using DB-backed lazy reverse index",
                _actual_mb, _limit_mb,
            )
        else:
            # No lazy fallback available — skip BFS to prevent OOM.
            _warn = (
                f"[cpp_backward_tracer] GVL is {_actual_mb} MB, which exceeds the "
                f"{_limit_mb} MB BFS limit.  C++ backward BFS skipped to prevent OOM.  "
                f"Set ASM_GVL_BFS_MAX_MB={_actual_mb + 512} to raise the limit, or "
                f"ensure index.db is available for DB-backed lazy traversal."
            )
            gc_list: List[Dict[str, Any]] = []
            gc_dep_vars_oom: List[str] = []
            if per_file_lineage and variable_name:
                gc_list, gc_dep_vars_oom = _extract_guard_conditions(per_file_lineage, variable_name, set())
            return {
                "seeds": seed_ids, "nodes": [], "edges": [],
                "dep_vars": list(gc_dep_vars_oom), "_gc_dep_vars": gc_dep_vars_oom,
                "bridge_registers": [], "guard_conditions": gc_list, "per_seed_traces": {},
                "truncated": True, "warnings": [_warn],
            }

    # FIX 4: build indices once — O(E) instead of O(N × E)
    # Accept pre-built indices from caller to avoid per-call rebuild when
    # the same GVL is queried for multiple dep_vars in the Pass2 BFS loop.
    # For large GVLs, _build_reverse_index/node_lookup will return DB-backed
    # lazy indices (via make_reverse_index/make_node_lookup) when available.
    reverse_idx = _reverse_idx if _reverse_idx is not None else _build_reverse_index(gvl)
    node_lookup = _node_lookup if _node_lookup is not None else _build_node_lookup(gvl)

    merged_nodes: Dict[str, Dict[str, Any]] = {}
    merged_edges: List[Dict[str, Any]] = []
    seen_merged_edge_keys: Set[Tuple[str, str, str, Any]] = set()  # FIX 6 (incl. line)
    all_dep_vars: List[str] = []
    all_bridge_regs: List[str] = []
    all_warnings: List[str] = []
    seen_dep_vars: Set[str] = set()
    seen_bridge_regs: Set[str] = set()
    per_seed: Dict[str, Dict[str, Any]] = {}

    # FIX 7: shared budget — total merged output never exceeds max_nodes
    remaining = max_nodes

    for seed in seed_ids:
        if remaining <= 0:
            all_warnings.append(
                f"multi-seed: global max_nodes={max_nodes} budget exhausted; "
                f"seeds not processed: {seed_ids[seed_ids.index(seed):]}"
            )
            break

        # FIX-new-P2-4: per-seed cap must account for nodes already merged from
        # previous seeds.  If we pass only `remaining` (= max_nodes - unique_new_so_far),
        # the per-seed trace counts ALL its own nodes (including duplicates of already-
        # merged ones) against its local cap, so later seeds with high overlap are
        # truncated far too early.  Adding len(merged_nodes) gives the per-seed trace
        # room to visit already-seen nodes without exhausting its budget — while the
        # shared `remaining` counter still enforces the global unique-node cap.
        # NEW-D: cap per_seed_cap at max_nodes so that a seed with zero overlap
        # cannot add more than max_nodes unique new nodes to merged output.
        # Without the min(), N seeds each with 0% overlap could produce N×max_nodes
        # merged nodes, defeating the hard cap that FIX-7 was meant to enforce.
        per_seed_cap = min(remaining + len(merged_nodes), max_nodes)
        result = trace_cpp_variable_backward(
            seed_id=seed,
            gvl=gvl,
            max_depth=max_depth,
            max_nodes=per_seed_cap,      # FIX-new-P2-4 + NEW-D: overlap-adjusted, hard-capped
            _reverse_idx=reverse_idx,    # FIX 4: reuse pre-built index
            _node_lookup=node_lookup,    # FIX 4: reuse pre-built lookup
            _seed_ids=set(seed_ids),     # P3-5: exclude all seeds from dep_vars consistently
            before_line=before_line,     # scope: skip edges at or after call-site line
            per_file_lineage=per_file_lineage,  # GC: guard condition extraction
            variable_name=variable_name,        # GC: bare variable name
        )
        per_seed[seed] = result

        # FIX 7: count only NEW nodes when decrementing the shared budget
        for n in result["nodes"]:
            nid = n["id"]
            if nid not in merged_nodes:
                merged_nodes[nid] = n
                remaining -= 1

        # FIX 6: O(1) set-based dedup on merged edge list (line included so that
        # the same (src,tgt,rel) at different lines are kept as distinct setters)
        for e in result["edges"]:
            ekey: Tuple[str, str, str, Any] = (
                e.get("source", ""), e.get("target", ""), e.get("relation", ""), e.get("line")
            )
            if ekey not in seen_merged_edge_keys:
                seen_merged_edge_keys.add(ekey)
                merged_edges.append(e)

        for dv in result["dep_vars"]:
            if dv not in seen_dep_vars:
                seen_dep_vars.add(dv)
                all_dep_vars.append(dv)

        for br in result["bridge_registers"]:
            if br not in seen_bridge_regs:
                seen_bridge_regs.add(br)
                all_bridge_regs.append(br)

        all_warnings.extend(result["warnings"])

    # GC: merge guard_conditions and _gc_dep_vars across per-seed results
    merged_guard_conditions: List[Dict[str, Any]] = []
    seen_gc_keys: Set[str] = set()
    merged_gc_dep_vars: List[str] = []
    seen_gc_dv: Set[str] = set()
    for r in per_seed.values():
        for gc in (r.get("guard_conditions") or []):
            gc_key = f"{gc.get('line')}:{gc.get('scope')}:{gc.get('expression')}"
            if gc_key not in seen_gc_keys:
                seen_gc_keys.add(gc_key)
                merged_guard_conditions.append(gc)
        for gcdv in (r.get("_gc_dep_vars") or []):
            if gcdv not in seen_gc_dv:
                seen_gc_dv.add(gcdv)
                merged_gc_dep_vars.append(gcdv)

    return {
        "seeds": seed_ids,
        "nodes": list(merged_nodes.values()),
        "edges": merged_edges,
        "dep_vars": all_dep_vars,
        "_gc_dep_vars": merged_gc_dep_vars,
        "bridge_registers": all_bridge_regs,
        "guard_conditions": merged_guard_conditions,
        "per_seed_traces": per_seed,
        "truncated": any(r.get("truncated") for r in per_seed.values()),  # FIX 8
        "warnings": all_warnings,
    }
