"""CLI for the chainless, whole-codebase backward lineage tracer.

    python -m backward_traversal.cli_chainless VAR \
        --blueprint-dir jobs/<kb>/output/asm \
        --graph jobs/<kb>/output/file_call_graph.json \
        [--job-id <kb>] [--asm-dir ...] [--language asm|cpp] \
        [--no-counterparts] [--max-* N] [--output out.json] [--summary-only]

Every ``--max-*`` of 0 means unlimited.  A separate CLI from ``cli.py`` — the
existing chain-based CLI is untouched.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="backward_traversal.cli_chainless")
    p.add_argument("variable")
    p.add_argument("--blueprint-dir", required=True, type=Path)
    p.add_argument("--graph", required=True, type=Path)
    p.add_argument("--asm-dir", type=Path, default=None)
    p.add_argument("--job-id", default=None, help="project/kb id (enables index.db reads)")
    p.add_argument("--language", choices=["asm", "cpp"], default=None)
    p.add_argument("--no-counterparts", action="store_true")
    p.add_argument("--summary-only", action="store_true",
                   help="enumerate setter roots only; skip traversal")
    p.add_argument("--lineage", action="store_true",
                   help="emit the value+relevant-condition lineage tree (what value "
                        "under what conditions, recursively through dependent variables)")
    p.add_argument("--max-lineage-depth", type=int, default=2,
                   help="recursion depth for --lineage (0 = unlimited)")
    p.add_argument("--max-setter-roots", type=int, default=0)
    p.add_argument("--max-files", type=int, default=0)
    p.add_argument("--max-caller-depth", type=int, default=0)
    p.add_argument("--max-dep-var-depth", type=int, default=0)
    p.add_argument("--max-downstream-depth", type=int, default=0)
    p.add_argument("--max-nodes", type=int, default=0)
    p.add_argument("--max-depth", type=int, default=0)
    p.add_argument("--output", type=Path, default=None)
    return p


def main(argv=None) -> int:
    args = build_arg_parser().parse_args(argv)

    if args.lineage:
        from backward_traversal.runner.chainless_lineage_tree import (
            build_lineage, enrich_for_explainability,
        )
        tree = build_lineage(
            args.variable, args.blueprint_dir, args.graph,
            job_id=args.job_id, asm_dir=args.asm_dir, max_depth=args.max_lineage_depth,
        )
        # Explainability-ready structure (value/value_kind, structured conditions,
        # dependent_variables with kind+why+recursive lineage, caller conditions,
        # terminal classification).
        payload = enrich_for_explainability(
            tree, args.blueprint_dir, args.graph, asm_dir=args.asm_dir, job_id=args.job_id)
    elif args.summary_only:
        from backward_traversal.runner.chainless_setter_enumerator import enumerate_setter_roots
        roots, counterparts, warns = enumerate_setter_roots(
            args.variable, args.language, args.blueprint_dir, args.graph, args.asm_dir,
            job_id=args.job_id, expand_counterparts=not args.no_counterparts,
            max_setter_roots=args.max_setter_roots, max_files=args.max_files,
        )
        payload = {
            "variable": args.variable,
            "setter_roots": [asdict(r) for r in roots],
            "counterparts": [asdict(c) for c in counterparts],
            "warnings": warns,
            "stats": {"n_roots": len(roots), "n_files": len({r.file_stem for r in roots})},
        }
    else:
        from backward_traversal.runner.chainless_runner import run_chainless_backward
        res = run_chainless_backward(
            args.variable, language=args.language,
            blueprint_dir=args.blueprint_dir, graph_file=args.graph, asm_dir=args.asm_dir,
            job_id=args.job_id, expand_counterparts=not args.no_counterparts,
            max_caller_depth=args.max_caller_depth, max_dep_var_depth=args.max_dep_var_depth,
            max_downstream_depth=args.max_downstream_depth, max_nodes=args.max_nodes,
            max_files=args.max_files, max_setter_roots=args.max_setter_roots,
            max_depth=args.max_depth,
        )
        payload = res.to_dict()

    text = json.dumps(payload, separators=(",", ":"), default=str)
    if args.output:
        args.output.write_text(text, encoding="utf-8")
        print(f"wrote {len(text)} bytes to {args.output}", file=sys.stderr)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
