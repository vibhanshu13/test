# Backward Traversal — Algorithm & Usage Reference

Traces where a variable gets **set** by walking backward through a chain of HLASM (and optionally C++) files, then recursively traces where each discovered dependent variable gets set.

---

## Quick Start

```bash
python -m backward_traversal.cli LG1OSI \
  --chain-files lu82,dx750000,dx710000,dx730000,dx740200,da78 \
  --blueprint-dir temp/output_latest/asm \
  --asm-dir temp/asm \
  --graph temp/output_latest/file_call_graph.json \
  --output LG1OSI_backward.json
```

## Companion Process Graph Inputs

If you are pairing backward traversal with process-aware routing analysis, the process utilities now emit target-level blocking output:
- `process/process_guarded_file_calls.json`
- `process/process_truncated_file_graph.json`

In that model, blocking is applied per edge (`source -> blocked_target`) rather than stopping an entire source file.

### All Parameters

| Parameter | Required | Default | Description |
|---|---|---|---|
| `variable` | yes | — | Root variable to trace (e.g. `LG1OSI`) |
| `--chain-files` | yes | — | Comma-separated file chain; **last file is the modifier** (the one that sets the variable) |
| `--blueprint-dir` | no | auto-discovered | Directory containing `.asm.json` / `.cpp.json` blueprint files |
| `--asm-dir` | no | auto-discovered | Directory containing `.asm` / `.cpp` source files |
| `--graph` | no | auto-discovered | Path to `file_call_graph.json` |
| `--max-depth` | no | `8` | Max CFG backward predecessor depth per call-site trace |
| `--max-subroutine-depth` | no | `2` | Max nested BAS/BAL subroutine expansion depth |
| `--max-subroutine-nodes` | no | `400` | Max relevant lines captured per subroutine expansion |
| `--max-trace-nodes` | no | `5000` | Max total relevant lines across a full call-site trace including all nested expansions |
| `--max-dep-vars` | no | `20` | Max total dep_vars traced across all BFS levels |
| `--max-dep-var-depth` | no | `2` | Max dep_var recursion depth (0 = Pass 1 dep_vars, 1 = their deps, …) |
| `--max-downstream-depth` | no | `2` | Max downstream file BFS depth per dep_var |
| `--max-downstream-files` | no | `30` | Max downstream files visited per dep_var |
| `--output` | no | `<variable>_cross_lineage_backward_only.json` | Output JSON path |

Auto-discovery order for `--blueprint-dir`: `temp/output_latest/asm` → `output/asm` → `temp/parser_run`.

---

## Two-Pass Architecture

### Pass 1 — Primary Trace

Traces where the **root variable** `R` gets set, working backward through the call chain.

```
[chain file N-1 upstream] → ... → [chain file 1 upstream] → [modifier file — sets R]
```

**Modifier file** (last in chain):
1. Scan all blocks for instructions in `SETTER_INST` whose LHS token matches `R`.
2. For each setter site, call `trace_asm_call_site_backward(R, ...)` starting at that block.

**Upstream files** (all files before modifier, processed right-to-left):
1. Find call sites from file `i` to file `i+1` using `find_asm_callers` (or `find_asm_to_cpp_callers` / `find_cpp_callers` for C++ boundaries).
2. For each call site, call `trace_asm_call_site_backward(R, ...)` starting at that block.

C++ upstream files record function call sites but do not do ASM backward tracing.

Output per file: `setter_sites` / `call_sites`, `setter_site_traces` / `call_site_traces`, merged `call_graph`, `subroutine_summary`.

---

### Pass 2 — Dependent Variable Tracing

After Pass 1, every traced node has a `dependent_variables` list — operands that appear in the same condition/trigger instructions as `R`. Pass 2 traces where **each** of those variables gets set, and then recurses into their dependent variables.
Quoted self-defining literal operands (for example `C'Y'`, `C' '`, `X'FF'`) are rejected at raw-operand filtering and are not emitted as dependent variables.

#### Step 2-A: Build Initial Collection Map

Walk all Pass 1 trace results (including nested `subroutine_expansions`). For every node that has `dependent_variables`, record which blocks in which chain file each dep_var was found:

```
dep_var_collection_map["WK_RRC"]["da78"] = {"DA780000", "DA7_1400"}
dep_var_collection_map["HUBTXN"]["da78"] = {"DA7_1000"}
```

#### Step 2-B: BFS Over Dep Vars

```
visited_dep_vars = { R.upper() }     ← root variable pre-added, never re-traced
dv_queue = [(dv, depth=0) for dv in sorted(dep_var_collection_map)]

while dv_queue:
    Di, dv_depth = dequeue

    if Di in visited_dep_vars → skip
    if total dep_vars traced >= MAX_DEP_VARS → warn + break
    if dv_depth >= MAX_DEP_VAR_DEPTH → warn + skip

    visited_dep_vars.add(Di)

    ── CHAIN FILE LOOP ──
    For each ASM chain file F (C++ chain files are skipped):
        Load blueprint
        collection_blocks = dep_var_collection_map[Di][F]   (may be empty)

        if collection_blocks non-empty → COLLECTION_BASED scope
            scope = ∪ backward_reachable_blocks(b) for b in collection_blocks

        elif anchor_blocks non-empty → ANCHOR_BASED scope
            scope = ∪ backward_reachable_blocks(b) for b in anchor_blocks
            (anchor_blocks = setter/call site blocks from Pass 1)

        else → FULL_FILE scope (fallback, emits warning)
            scope = all blocks in file

        collect ENTRC subroutine_call targets from scope → downstream queue
        trace Di setters within scope → chain_file_results[F]

    ── DOWNSTREAM FILE BFS ──
    For each ENTRC target file not in the chain:
        scope = full file (all blocks)
        trace Di setters → downstream_file_results[stem]
        collect further ENTRC targets for next depth level

    ── COLLECT CHILD DEP VARS ──
    Gather dep_vars from Di's own trace nodes → enqueue at dv_depth + 1
```

---

## Core Tracing Function: `trace_asm_call_site_backward`

Used identically for:
- Modifier setter sites (Pass 1)
- Upstream call sites (Pass 1)
- Dep var setter sites (Pass 2, both chain and downstream files)

**Algorithm:**

```
Start at call_site block (start_block), depth=0

BFS backward via cfg_incoming:
    1. Record call-site line itself as CALL_SITE role
    2. For each flow entry in block (lines BEFORE call_site line in start_block,
       all lines in predecessor blocks):
         - TRIGGER_INST (CLC, CLI, TM, ...) → CONDITION_CHECK role, collect dep_vars
         - BRANCH_INST  (B, BE, BZ, ...)    → BRANCH_STEP role
         - SUBROUTINE_INST (BAS, BAL)        → SUBROUTINE_CALL role → expand recursively
         - CROSS_FILE_INST (ENTRC, ...)      → CROSS_FILE_CALL role
         - SETTER_INST (MVC, ST, LA, ...)    → collect dep_vars from operands
    3. Follow cfg_incoming BRANCH + FALLTHROUGH edges → enqueue predecessors at depth+1
    4. Stop at max_depth

For each BAS/BAL encountered → _trace_subroutine_expansion (recursive, up to max_subroutine_depth)
```

**Dep var collection rules** (applied to SETTER_INST and TRIGGER_INST operands):
- Skip if starts with `=` (literal)
- Skip if register in parentheses (e.g. `0(R5)`)
- Skip if token is a known register (`R0`–`R15`)
- Skip if token contains `'` (character literal) or `#`
- Skip if token is pure digits
- Skip if token doesn't match `^[A-Z@$_][A-Z0-9@$_]*$`
- Skip if token equals the current variable being traced (`skip_var`)
- Skip if token is in constant_symbols (DC/EQU labels from blueprint or source scan)

---

## Scope Computation: `backward_reachable_blocks`

Determines which blocks to search for dep_var setter sites. Used in Pass 2 chain file loop.

**Hybrid BFS (single pass, no mode separation):**

```
queue = [(start_block, mode="backward")]
reachable = {}

for each (cur, mode):
    reachable.add(cur)

    ── ALWAYS (both modes): expand BAS/BAL ──
    For each BAS/BAL in cur's flow:
        resolve target via resolve_subroutine_target (4-level fallback)
        if resolved and not visited → enqueue (resolved_label, "forward")

    ── IF backward mode ──
    Follow cfg_incoming BRANCH + FALLTHROUGH predecessors → enqueue (src, "backward")

    ── IF forward mode ──
    Follow cfg_outgoing BRANCH + FALLTHROUGH successors → enqueue (nxt, "forward")
```

Subroutine expansion is **fully recursive** — nested BAS/BAL inside subroutine bodies are expanded too, because BAS/BAL scanning runs unconditionally for every visited block.

---

## CFG Construction: `_build_cfg_maps`

Three-source merge for accurate intra-file control flow:

1. **Parser incoming_branches** — branch metadata already in the blueprint
2. **Flow-derived branches** — scan each block's flow for BRANCH_INST targets, add missing edges
3. **Conservative fallthrough** — if two adjacent blocks (by line number) have a gap ≤ 12 lines and the first doesn't end with an unconditional branch/return, add a FALLTHROUGH edge

---

## Subroutine Resolution: `resolve_subroutine_target`

4-level fallback when a BAS/BAL target label is encountered:

1. Exact match in blueprint `subroutines` array by `id`
2. Normalized match in blueprint `subroutines` array (uppercase, strip special chars)
3. Exact match as block `id` in `blocks`
4. Normalized match as block `id`

`extract_subroutine_target` picks the target from BAS/BAL args: prefers the rightmost non-register argument, falls back to the `detail` string.

---

## Downstream File Discovery

From within each chain file's scope, ENTRC edges with `call_type == "subroutine_call"` are collected. Edges with `call_type == "macro_invocation"` (unresolved ENTRC) are filtered out.

Non-returning cross-file calls are **never** followed as downstream files:

| Instruction | Reason skipped |
|---|---|
| `ENTNC` | Non-returning |
| `ENTDC` | Non-returning |
| `CREEC` | Non-returning |
| `CREMC` | Non-returning |
| `SWISC` | Non-returning |

Downstream files are searched with **full-file scope** (all blocks). They can themselves have ENTRC targets that are followed recursively up to `MAX_DOWNSTREAM_DEPTH`.

---

## Guardrails

| CLI Flag | Default | Scope |
|---|---|---|
| `--max-dep-vars` | 20 | Total dep_vars traced across all BFS levels; warns + stops if hit |
| `--max-dep-var-depth` | 2 | Dep_var recursion depth (0 = Pass 1 dep_vars, 1 = their deps, …) |
| `--max-downstream-depth` | 2 | File BFS depth per dep_var |
| `--max-downstream-files` | 30 | Total downstream files per dep_var; warns + stops if hit |
| `--max-depth` | 8 | CFG backward predecessor depth in `trace_asm_call_site_backward` |
| `--max-subroutine-depth` | 2 | BAS/BAL nesting depth in subroutine expansion |
| `--max-subroutine-nodes` | 400 | Relevant lines per subroutine expansion |
| `--max-trace-nodes` | 5000 | Relevant lines per full call-site trace (global cap across all nesting) |

**Cycle prevention:**
- `visited_dep_vars` — root variable pre-added; each dep_var processed at most once regardless of depth
- `visited_downstream` — per-dep_var; each downstream file visited at most once per dep_var BFS
- `cycle_keys` — inside `_trace_subroutine_expansion`; prevents re-entering the same `(file, subroutine, call_line, scope_path)` tuple

---

## Output Structure

```json
{
  "traversal_mode": "backward_only",
  "root_variable": "LG1OSI",
  "selected_chain": ["lu82", "dx750000", "dx710000", "dx730000", "dx740200", "da78"],
  "modifier_file": "da78",
  "warnings": ["..."],

  "files": {
    "da78": {
      "file_type": "asm",
      "modifier": {
        "role": "modifier",
        "file_type": "asm",
        "setter_sites": [
          {"routine": "DA780000", "line": 811, "instruction": "MVC",
           "call_type": "setter_site", "raw_line": "MVC LG1OSI,WKRRC"}
        ],
        "setter_site_traces": [ { "call_site": {...}, "call_graph": {...}, "subroutine_expansions": [...], "warnings": [] } ],
        "call_graph": { "nodes": [...], "edges": [...] },
        "subroutine_summary": {"count": 3, "unresolved": 0, "capped": 0},
        "warnings": []
      }
    },
    "dx740200": {
      "file_type": "asm",
      "upstream": {
        "role": "upstream",
        "file_type": "asm",
        "edge_type": "ENTRC",
        "call_sites": [ {"routine": "DX7_0100", "line": 200, "instruction": "ENTRC", ...} ],
        "call_site_traces": [...],
        "call_graph": {...},
        "subroutine_summary": {...}
      }
    }
  },

  "dep_var_traces": {
    "WK_RRC": {
      "depth": 0,
      "chain_file_results": {
        "da78": {
          "scope": "collection_based",
          "setter_sites": [...],
          "setter_site_traces": [...],
          "call_graph": {...},
          "subroutine_summary": {...},
          "warnings": []
        },
        "lu82": {
          "scope": "anchor_based",
          "setter_sites": [],
          "setter_site_traces": [],
          "call_graph": {"nodes": [], "edges": []},
          "subroutine_summary": {"count": 0, "unresolved": 0, "capped": 0},
          "warnings": []
        }
      },
      "downstream_file_results": {
        "xh80": {
          "scope": "full_file",
          "setter_sites": [...],
          "setter_site_traces": [...],
          "call_graph": {...},
          "subroutine_summary": {...},
          "warnings": []
        }
      }
    },
    "SOME_VAR": {
      "depth": 1,
      "chain_file_results": { ... },
      "downstream_file_results": {}
    }
  }
}
```

### Scope Labels

| Label | Meaning |
|---|---|
| `collection_based` | Dep_var was found in this file's Pass 1 traces; scope = backward reachable from those exact blocks |
| `anchor_based` | Dep_var not found in this file's Pass 1 traces; scope = backward reachable from Pass 1 setter/call-site blocks |
| `full_file` | Used for all downstream files, and as fallback when anchor_blocks is empty |

### call_graph Node Fields

Each node in a `call_graph`:

```json
{
  "id": "DA780000",
  "code": "... raw source lines for this block ...",
  "relevant_code_lines": [
    {"line": 800, "inst": "CLI", "role": "COMPARE_IMMEDIATE", "detail": "WK_FLAG,X'FF'"},
    {"line": 811, "inst": "MVC", "role": "CALL_SITE", "detail": "MVC LG1OSI,WKRRC"}
  ],
  "dependent_variables": ["WK_RRC"]
}
```

---

## File Map

```
backward_traversal/
├── cli.py                              ← Entry point (argparse)
├── runner/
│   └── backward_only_runner.py         ← run_backward_only(), Pass 1 + Pass 2
├── tracing/
│   └── asm_backward_tracer.py          ← trace_asm_call_site_backward(),
│                                          backward_reachable_blocks(),
│                                          _build_cfg_maps(), merge_call_graphs()
├── bridge/
│   └── cross_file_bridge_backward.py   ← find_asm_callers(), find_cpp_callers(), etc.
├── utils/
│   ├── blueprint_utils.py              ← load_json(), resolve_asm_blueprint(),
│   │                                      fetch_raw_line(), collect_constant_symbols()
│   ├── token_utils.py                  ← dep_vars_from_args(), is_dep_var_candidate()
│   ├── subroutine_resolution.py        ← resolve_subroutine_target(),
│   │                                      extract_subroutine_target()
│   ├── cpp_source_utils.py             ← build_func_source_index()
│   └── blueprint_consistency.py        ← diagnose_blueprint_consistency()
└── glossary/
    └── instructions.py                 ← SETTER_INST, TRIGGER_INST, BRANCH_INST,
                                           SUBROUTINE_INST, CROSS_FILE_INST, RETURN_OPCODES
```

---

## Known Limitations

- **C++ chain files**: Call sites are found and recorded but no ASM backward trace is run. C++ downstream files are skipped (no `.asm.json` blueprint).
- **Register-chained values**: If the variable flows through a register (e.g. `LR R5,R3` → `ST R5,WK_RRC`), the register `R5` is filtered out as a dep_var; the chain through registers is not followed.
- **Non-returning cross-file calls**: ENTNC/ENTDC/CREEC/CREMC/SWISC targets are never followed as downstream files.
- **C++ dep_var filtering**: Dep_vars discovered inside C++ upstream nodes are not collected or traced (C++ files are skipped in the chain file loop).
