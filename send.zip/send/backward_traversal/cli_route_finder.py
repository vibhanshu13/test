"""CLI for the forward route finder (parent → child call routes).

    python -m backward_traversal.cli_route_finder \
        --blueprint-dir jobs/<kb>/output/asm \
        --graph jobs/<kb>/output/file_call_graph.json \
        --parent-file dw780000 --parent-type cpp --parent-function someFn \
        --child-file  dw710000 --child-type  cpp --child-function processACreditTransaction \
        [--asm-dir ...] [--job-id <kb>] [--max-caller-depth 0] [--max-routes 200] \
        [--output out.json]

Answers: is there a route parent → child, and if so lists every route (file hops
annotated with calling function + guard conditions).  Mainly for cpp → cpp.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="backward_traversal.cli_route_finder")
    p.add_argument("--blueprint-dir", required=True, type=Path)
    p.add_argument("--graph", required=True, type=Path)
    p.add_argument("--asm-dir", type=Path, default=None)
    p.add_argument("--job-id", default=None, help="project/kb id (enables index.db reads)")

    p.add_argument("--parent-file", required=True)
    p.add_argument("--parent-type", choices=["cpp", "asm"], default="cpp")
    p.add_argument("--parent-function", default=None)

    p.add_argument("--child-file", required=True)
    p.add_argument("--child-type", choices=["cpp", "asm"], default="cpp")
    p.add_argument("--child-function", default=None)

    p.add_argument("--max-caller-depth", type=int, default=0, help="0 = unlimited")
    p.add_argument("--max-routes", type=int, default=200, help="0 = unlimited")
    p.add_argument("--output", type=Path, default=None)
    p.add_argument("--summary", action="store_true",
                   help="print only reachable + route_count + the route files")
    return p


def main(argv=None) -> int:
    args = build_arg_parser().parse_args(argv)
    from backward_traversal.route_finder import Endpoint, find_routes

    result = find_routes(
        Endpoint(args.parent_file, args.parent_type, args.parent_function),
        Endpoint(args.child_file, args.child_type, args.child_function),
        blueprint_dir=args.blueprint_dir, graph_file=args.graph,
        asm_dir=args.asm_dir, job_id=args.job_id,
        max_caller_depth=args.max_caller_depth,
        max_routes=(args.max_routes or 0),
    )

    if args.summary:
        print(f"reachable: {result['reachable']}  routes: {result['route_count']}"
              f"{' (capped)' if result.get('routes_capped') else ''}")
        for i, r in enumerate(result["routes"], 1):
            print(f"  [{i}] " + " -> ".join(r["files"]))
        if result.get("unverified"):
            print(f"  unverified caller candidates: {', '.join(result['unverified'])}")
        return 0

    text = json.dumps(result, separators=(",", ":"), default=str)
    if args.output:
        args.output.write_text(text, encoding="utf-8")
        print(f"wrote {len(text)} bytes to {args.output}", file=sys.stderr)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
