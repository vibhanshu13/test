"""GAP A — codebase-wide setter enumeration for the chainless tracer.

Given just a variable name, find EVERY setter site across all blueprints, each
as an independent ``SetterRoot``.  No ``selected_chain``.

Candidate-file selection is the key optimization: when a project ``job_id`` is
available we ask the ``variable_modifier_index`` (``get_modifier_files``) which
files set the variable, and scan only those — instead of globbing every
blueprint.  We fall back to a full glob when the index is unavailable.

ASM setters reuse ``_find_scoped_setter_sites`` (all-blocks scope); C++ setters
come from ``find_cpp_seed_nodes`` + the assign/define edges into those seeds.
Works on-disk OR DB-backed (blueprints via the compressed loader, GVL via the
``IndexDbGVL`` fallback inside ``make_lazy_gvl``).  Counterpart expansion is one
hop only, to keep the root set bounded.
"""

from __future__ import annotations

import logging
import time
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from backward_traversal.models.chainless_models import CounterpartInfo, SetterRoot
from backward_traversal.utils.blueprint_utils import (
    load_json,
    resolve_asm_blueprint,
    resolve_cpp_blueprint,
)

logger = logging.getLogger(__name__)

_CPP_SETTER_RELATIONS = {"assign", "define"}


# ---------------------------------------------------------------------------
# Candidate-file selection
# ---------------------------------------------------------------------------

def _candidate_stems_from_index(job_id: str, variable: str, graph_file: Path) -> List[str]:
    """Ask the variable_modifier_index which files set the variable (cheap)."""
    try:
        from api.index_db.readers import get_modifier_files
        fallback = graph_file.parent / "variable_modifier_index.json"
        stems = get_modifier_files(
            job_id, variable, fallback_path=fallback if fallback.exists() else None
        )
        return [str(s) for s in (stems or [])]
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("modifier-index lookup failed (%s); will glob", exc)
        return []


@lru_cache(maxsize=8)
def _all_stems_by_glob(blueprint_dir: Path) -> Dict[str, str]:
    """Map stem -> file_type by globbing the blueprint dir (fallback path).

    Result is cached per directory — the glob is expensive (~1 000+ files) and
    the same blueprint_dir is queried for every condition variable inside
    ``_build_dep_vars``, so caching avoids thousands of redundant filesystem
    scans during a single forest job.
    """
    out: Dict[str, str] = {}
    for p in blueprint_dir.glob("*.asm.json"):
        out.setdefault(p.name[: -len(".asm.json")], "asm")
    for p in blueprint_dir.glob("*.mac.json"):
        out.setdefault(p.name[: -len(".mac.json")], "asm")
    for p in blueprint_dir.glob("*.cpp.json"):
        out.setdefault(p.name[: -len(".cpp.json")], "cpp")
    return out


# ---------------------------------------------------------------------------
# Per-file setter discovery
# ---------------------------------------------------------------------------

def _asm_roots_in_file(
    variable: str, origin: str, stem: str, blueprint_dir: Path, asm_dir: Optional[Path]
) -> List[SetterRoot]:
    bp_path = resolve_asm_blueprint(stem, blueprint_dir)
    if not bp_path:
        return []
    try:
        bp = load_json(bp_path)
    except Exception:
        return []
    all_blocks: Set[str] = {str(b.get("id") or "") for b in (bp.get("blocks") or []) if b.get("id")}
    if not all_blocks:
        return []
    try:
        from backward_traversal.runner.backward_only_runner import _find_scoped_setter_sites
        from backward_traversal.utils.blueprint_utils import collect_constant_symbols
    except Exception:  # pragma: no cover
        return []
    asm_file = (asm_dir / f"{stem}.asm") if asm_dir else Path(f"{stem}.asm")
    try:
        consts = collect_constant_symbols(bp, asm_file)
    except Exception:
        consts = set()
    try:
        sites, _warn = _find_scoped_setter_sites(
            variable, bp, asm_file, all_blocks, asm_dir, constant_symbols=consts
        )
    except Exception as exc:
        logger.debug("asm setter scan failed for %s: %s", stem, exc)
        return []
    roots: List[SetterRoot] = []
    for s in sites:
        block_id = str(s.get("routine") or "")
        line = int(s.get("line") or 0)
        instr = str(s.get("instruction") or "")
        roots.append(
            SetterRoot(
                root_id=SetterRoot.make_root_id(stem, "asm", block_id, line, instr),
                file_stem=stem,
                file_type="asm",
                variable=variable,
                origin_variable=origin,
                line=line,
                instruction=instr,
                block_id=block_id,
                setter_expression=s.get("setter_expression"),
                constant_source=bool(s.get("constant_source")),
                prior_value_required=bool(s.get("prior_value_required")),
                role=s.get("call_type"),
                flipc_alias_of=s.get("flipc_alias_of"),
                hardware_source=s.get("hardware_source"),
            )
        )
    return roots


def _stem_from_edge_file(file_field: str) -> str:
    """Derive a blueprint stem from a GVL edge's ``file`` path/basename.

    Handles ASM-aliased fields whose edge ``file`` is e.g. ``DA78.ASM`` — strip
    ``.asm``/``.mac`` too (and lower-case, the ASM stem convention) so it matches
    the per-file ASM pass's stem (``da78``) and dedups correctly (ISSUE-4a)."""
    name = Path(str(file_field or "")).name
    for suf in (".cpp", ".hpp", ".cc", ".cxx", ".c", ".h"):
        if name.lower().endswith(suf):
            return name[: -len(suf)]
    for suf in (".asm", ".mac"):
        if name.lower().endswith(suf):
            return name[: -len(suf)].lower()
    return name


def _is_asm_edge_file(file_field: str) -> bool:
    """True if a GVL edge's ``file`` is an ASM/mac source (owned by the ASM pass)."""
    return Path(str(file_field or "")).name.lower().endswith((".asm", ".mac"))


def _collapse_same_site_roots(roots: List[SetterRoot]) -> List[SetterRoot]:
    """Collapse the multiple GVL variants of one physical setter into a single
    canonical root.

    The C++ GVL emits, for ONE source-line write, up to four edges —
    ``{assign, define} × {scoped seed ``FN::a.b.field``, unscoped seed
    ``a.b.field``}`` — all at the same ``(file, line)``.  They describe the SAME
    setter, so we keep one row per ``(file_stem, line)``: the real value-write
    (``assign`` / an ASM instruction) when present, else a declaration
    (``define``).  Distinct lines stay distinct; ``line == 0`` placeholder/
    declaration rows for one file collapse to one.  Order is preserved by first
    appearance so the list stays stable."""
    order: List[Tuple[str, int]] = []
    groups: dict = {}
    for r in roots:
        key = (str(r.file_stem).lower(), int(r.line or 0))
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(r)

    def _rank(r: SetterRoot) -> tuple:
        # non-declaration first; non-`define` instruction first; then stable id.
        return (r.is_declaration, str(r.instruction).lower() == "define", r.root_id)

    out: List[SetterRoot] = []
    for key in order:
        out.append(sorted(groups[key], key=_rank)[0])
    return out


def _cpp_roots_global(
    variable: str,
    origin: str,
    blueprint_dir: Path,
    candidate_stems: Optional[Set[str]],
    *,
    job_id: Optional[str] = None,
) -> List[SetterRoot]:
    """C++ setters from the GLOBAL GVL, attributed by each edge's own file.

    The C++ ``global_variable_lineage`` is a single graph shared across all
    blueprints, so we load it ONCE (any cpp blueprint carries the path) and
    attribute each assign/define edge to the file it actually occurs in — never
    duplicating one global edge across files.  When ``candidate_stems`` is given
    (from the modifier index) we keep only edges in those files; otherwise we
    keep all (glob fallback).

    When ``job_id`` is available, a DB fast path queries ``gvl_edges`` for
    assign/define edges matching the variable via indexed suffix lookups —
    avoiding the 2.86 M-row full-GVL materialisation that OOM-kills workers
    on 22 K-file codebases.
    """
    # ── DB fast path ──────────────────────────────────────────────────────
    if job_id:
        db_roots = _cpp_roots_from_db(variable, origin, candidate_stems, job_id)
        if db_roots is not None:
            return db_roots

    # ── Legacy path: full GVL scan ────────────────────────────────────────
    # Pick any available cpp blueprint as the GVL handle.
    handle = None
    for p in sorted(blueprint_dir.glob("*.cpp.json")):
        handle = p
        break
    if handle is None:
        return []
    try:
        from backward_traversal.utils.cpp_lineage_utils import (
            extract_asm_field_aliases,
            find_cpp_seed_nodes,
        )
        from backward_traversal.utils.lazy_gvl import make_lazy_gvl
    except Exception:  # pragma: no cover
        return []
    try:
        bp = load_json(handle)
        gvl = make_lazy_gvl(bp, handle)
    except Exception:
        return []
    aliases = extract_asm_field_aliases(bp, variable) if variable else {}
    seeds = set(find_cpp_seed_nodes(gvl, variable, aliases, {}) or [])
    if not seeds:
        return []

    return _roots_from_edges(
        (gvl.get("edges") or []), seeds, variable, origin, candidate_stems,
    )


def _cpp_roots_from_db(
    variable: str,
    origin: str,
    candidate_stems: Optional[Set[str]],
    job_id: str,
) -> Optional[List[SetterRoot]]:
    """DB-backed setter root discovery.  Returns ``None`` on DB failure
    (caller falls back to the legacy full-GVL scan)."""
    try:
        from api.index_db.readers import get_gvl_setter_edges
    except Exception:
        return None

    edges = get_gvl_setter_edges(job_id, variable)
    if edges is None:
        return None  # DB unavailable — fall back to legacy path

    # The DB query already filtered to assign/define edges whose target
    # matches the variable via suffix matching — no need for seed discovery.
    # We derive seed IDs directly from the edge targets.
    seed_ids = {str(e.get("target") or "") for e in edges}
    seed_ids.discard("")

    return _roots_from_edges(edges, seed_ids, variable, origin, candidate_stems)


def _roots_from_edges(
    edges,
    seeds: Set[str],
    variable: str,
    origin: str,
    candidate_stems: Optional[Set[str]],
) -> List[SetterRoot]:
    """Build ``SetterRoot`` objects from GVL edges targeting ``seeds``.

    Shared by both the DB fast path and the legacy full-GVL path.
    """
    roots: List[SetterRoot] = []
    seen: Set[str] = set()
    attributed_any = False
    for e in edges:
        rel = str(e.get("relation") or "").lower()
        if rel not in _CPP_SETTER_RELATIONS:
            continue
        tgt = str(e.get("target") or "")
        if tgt not in seeds:
            continue
        efile = e.get("file", "")
        # ISSUE-4b: an ASM-aliased field's edge file is the ASM source (e.g.
        # DA78.ASM) — the per-file ASM pass already owns that setter, so don't
        # re-emit it from the global C++ GVL (it would duplicate the card).
        if _is_asm_edge_file(efile):
            continue
        stem = _stem_from_edge_file(efile)
        # ISSUE-5a: drop chainless `<global>`/placeholder rows from the ATTRIBUTED
        # path (no real file behind them to backward-trace — the GVL emits file
        # ``<global>`` for cross-TU/unattributed edges).  The `not attributed_any`
        # fallback below still guarantees the variable is never invisible.
        if not stem or stem.startswith("<"):
            continue
        line = int(e.get("line") or 0)
        rid = SetterRoot.make_root_id(stem, "cpp", tgt, line, rel)
        if rid in seen:
            continue
        seen.add(rid)
        attributed_any = True
        roots.append(
            SetterRoot(
                root_id=rid,
                file_stem=stem,
                file_type="cpp",
                variable=variable,
                origin_variable=origin,
                line=line,
                instruction=rel,
                seed_id=tgt,
                setter_expression=str(e.get("expression") or "") or None,
                # ISSUE-5b: a `define` edge is a declaration (copybook), not a
                # value-writing setter — flag it so the UI can relabel / exclude.
                is_declaration=(rel == "define"),
            )
        )
    # Declaration-only seeds (no incoming assign/define) — represent once each so
    # the variable is never invisible.
    if not attributed_any:
        for sid in sorted(seeds):
            rid = SetterRoot.make_root_id("<global>", "cpp", sid, 0, "define")
            roots.append(
                SetterRoot(
                    root_id=rid, file_stem="<global>", file_type="cpp",
                    variable=variable, origin_variable=origin,
                    instruction="define", seed_id=sid, is_declaration=True,
                )
            )
    return roots


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def enumerate_setter_roots(
    variable: str,
    language: Optional[str],
    blueprint_dir: Path,
    graph_file: Path,
    asm_dir: Optional[Path] = None,
    *,
    job_id: Optional[str] = None,
    expand_counterparts: bool = True,
    max_setter_roots: int = 0,
    max_files: int = 0,
    _origin: Optional[str] = None,
) -> Tuple[List[SetterRoot], List[CounterpartInfo], List[str]]:
    """Enumerate all setter roots for ``variable`` across the codebase.

    Returns ``(roots, counterparts, warnings)``.  ``language`` may be None
    (auto-detect; "mixed" when found in both).  Caps of 0/None mean unlimited.
    """
    blueprint_dir = Path(blueprint_dir)
    graph_file = Path(graph_file)
    origin = _origin or variable
    warnings: List[str] = []
    _t0 = time.monotonic()
    logger.info("[ENUMERATE] Starting — var=%s", variable)

    # 1) candidate file set
    # Defer the expensive glob (3 patterns × 22 K files) until we know the DB
    # index cannot supply the candidate set.  When the index succeeds, per-stem
    # type resolution below (resolve_asm/cpp_blueprint) handles the few stems
    # returned — much cheaper than globbing the entire blueprint directory.
    candidates: List[Tuple[str, Optional[str]]] = []  # (stem, file_type|None)
    if job_id:
        idx_stems = _candidate_stems_from_index(job_id, variable, graph_file)
        if idx_stems:
            for s in idx_stems:
                candidates.append((s, None))
    if not candidates:
        if job_id:
            warnings.append("modifier_index_empty: globbing all blueprints instead")
        glob_map = _all_stems_by_glob(blueprint_dir)
        candidates = [(s, t) for s, t in glob_map.items()]

    if max_files and max_files > 0:
        candidates = candidates[:max_files]

    # Resolve each candidate's available file types (a stem may have both).
    lang_norm = (language or "").lower().strip() or None
    asm_stems: List[str] = []
    cpp_stems: Set[str] = set()
    index_scoped = bool(job_id) and not any(
        w.startswith("modifier_index_empty") for w in warnings
    )
    for stem, ftype in candidates:
        types = [ftype] if ftype in ("asm", "cpp") else []
        if not types:
            if resolve_asm_blueprint(stem, blueprint_dir):
                types.append("asm")
            if resolve_cpp_blueprint(stem, blueprint_dir):
                types.append("cpp")
        for t in types:
            if t == "asm":
                asm_stems.append(stem)
            else:
                cpp_stems.add(stem)

    logger.info("[ENUMERATE] Candidates — %d ASM stems, %d C++ stems — %.1fs",
                len(asm_stems), len(cpp_stems), time.monotonic() - _t0)

    roots: List[SetterRoot] = []
    seen_ids: Set[str] = set()
    asm_seen = cpp_seen = False

    def _add(rs: List[SetterRoot], is_asm: bool) -> None:
        nonlocal asm_seen, cpp_seen
        for r in rs:
            if r.root_id in seen_ids:
                continue
            seen_ids.add(r.root_id)
            roots.append(r)
            if is_asm:
                asm_seen = True
            else:
                cpp_seen = True

    # 2a) ASM — per-file (self-contained blueprints).
    if lang_norm in (None, "asm"):
        for stem in asm_stems:
            _add(_asm_roots_in_file(variable, origin, stem, blueprint_dir, asm_dir), True)

    if lang_norm in (None, "asm"):
        logger.info("[ENUMERATE] ASM scan — %d roots — %.1fs",
                    sum(1 for r in roots if r.file_type == "asm"),
                    time.monotonic() - _t0)

    # 2b) C++ — the GVL is GLOBAL: scan once, attribute by edge file.
    if lang_norm in (None, "cpp"):
        # When the modifier index gave us a candidate set, scope to those files;
        # otherwise (full glob) keep all attributed files.
        scope_stems: Optional[Set[str]] = cpp_stems if (index_scoped and cpp_stems) else None
        _add(_cpp_roots_global(variable, origin, blueprint_dir, scope_stems, job_id=job_id), False)

    # Collapse the GVL's per-setter variants — {assign, define} × {scoped,
    # unscoped seed} all describe ONE physical setter at a (file, line).  Keep one
    # canonical root per site (the real value-write over a declaration), so the
    # setter list reflects real setters, not graph-encoding artifacts.
    roots[:] = _collapse_same_site_roots(roots)
    # If any real (non-declaration) setter exists, drop all declaration-only rows.
    # A copybook `define` only adds information when it is the ONLY evidence of
    # the variable — once a real setter exists, the declaration is noise.
    if any(not r.is_declaration for r in roots):
        roots[:] = [r for r in roots if not r.is_declaration]
    # Apply the cap to the REAL (collapsed) count, not the inflated one.
    if max_setter_roots and len(roots) > max_setter_roots:
        roots[:] = roots[:max_setter_roots]
        warnings.append(f"max_setter_roots={max_setter_roots} reached; truncated")

    logger.info("[ENUMERATE] After collapse/cap — %d roots — %.1fs",
                len(roots), time.monotonic() - _t0)

    detected_lang = "mixed" if (asm_seen and cpp_seen) else ("asm" if asm_seen else "cpp")

    # 3) one-hop counterpart expansion
    counterparts: List[CounterpartInfo] = []
    if expand_counterparts and roots:
        seed_lang = lang_norm or detected_lang
        # resolve_counterpart needs a single language; for mixed, try both.
        langs_to_resolve = ["asm", "cpp"] if seed_lang == "mixed" else [seed_lang]
        try:
            from backward_traversal.utils.counterpart_resolver import resolve_counterpart
            for lg in langs_to_resolve:
                for cand in resolve_counterpart(variable, lg, blueprint_dir, graph_file):
                    counterparts.append(
                        CounterpartInfo(
                            counterpart_name=cand.counterpart_name,
                            language=cand.counterpart_language,
                            home_stem=cand.home_stem,
                            certainty_label=cand.certainty_label,
                            cc_header=cand.cc_header,
                            mapping_via=cand.mapping_via,
                        )
                    )
                    # Enumerate the counterpart's own setters (one hop only).
                    cp_roots, _cp, cp_warn = enumerate_setter_roots(
                        cand.counterpart_name,
                        cand.counterpart_language,
                        blueprint_dir,
                        graph_file,
                        asm_dir,
                        job_id=job_id,
                        expand_counterparts=False,
                        max_setter_roots=max_setter_roots,
                        max_files=max_files,
                        _origin=origin,
                    )
                    for r in cp_roots:
                        if r.root_id in seen_ids:
                            continue
                        r.is_counterpart_root = True
                        r.counterpart_of = variable
                        r.counterpart_certainty = cand.certainty_label
                        seen_ids.add(r.root_id)
                        roots.append(r)
                    warnings.extend(cp_warn)
        except Exception as exc:
            logger.debug("counterpart expansion failed: %s", exc)

    logger.info("[ENUMERATE] Done — %d roots, %d counterparts — %.1fs",
                len(roots), len(counterparts), time.monotonic() - _t0)
    return roots, counterparts, warnings
