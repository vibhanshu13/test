"""
cotraversal_runner.py

Bidirectional ASM<->CPP co-traversal orchestrator.

Runs run_backward_only twice — once for the primary variable on its chain,
once for the cross-language counterpart on its own chain — then writes a
cotraversal.json link artifact joining the two lineages.

The core runner (run_backward_only) is called as a library function, unchanged.
"""
from __future__ import annotations

import json
import logging
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def run_cotraversal(
    variable: str,
    language: str,
    selected_chain: List[str],
    counterpart_chain: List[str],
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    graph_file: Path,
    output_path: Path,
    counterpart_name: Optional[str] = None,
    *,
    max_depth: int = 8,
    max_subroutine_depth: int = 2,
    max_subroutine_nodes: int = 400,
    max_trace_nodes: int = 5000,
    max_dep_vars: int = 20,
    max_dep_var_depth: int = 2,
    max_downstream_depth: int = 2,
    max_downstream_files: int = 30,
    t8_max_scan: int = 0,
    partitioned_output: bool = True,
) -> int:
    """Run a full backward co-traversal for two cross-language variables.

    Parameters
    ----------
    variable:
        Primary variable to trace.
    language:
        Language of the primary variable ("asm" | "cpp").
    selected_chain:
        Ordered chain for the primary variable (upstream...modifier).
    counterpart_chain:
        Ordered chain for the counterpart variable (user-selected, NOT derived).
    blueprint_dir:
        Directory containing *.asm.json / *.cpp.json blueprints.
    asm_dir:
        Optional directory containing source files.
    graph_file:
        Path to file_call_graph.json.
    output_path:
        Root output directory for this co-traversal.  Will contain:
          primary/        — run_backward_only tree for the primary variable
          counterpart/    — run_backward_only tree for the counterpart variable
          cotraversal.json — link artifact
    counterpart_name:
        Explicit counterpart variable name override.  When None, resolved
        automatically via resolve_counterpart.

    Returns
    -------
    0 on success (both runs completed), nonzero on failure.
    """
    from backward_traversal.runner.backward_only_runner import run_backward_only
    from backward_traversal.utils.counterpart_resolver import (
        CounterpartCandidate,
        resolve_counterpart,
    )

    root_var = str(variable or "").strip()
    if not root_var:
        print("ERROR: variable must not be empty.", file=sys.stderr)
        return 1

    if len(selected_chain) < 2:
        print("ERROR: selected_chain must have at least two file stems.", file=sys.stderr)
        return 1

    if len(counterpart_chain) < 2:
        print("ERROR: counterpart_chain must have at least two file stems.", file=sys.stderr)
        return 1

    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    warnings: List[str] = []

    # ── Resolve counterpart ──────────────────────────────────────────────────
    best_candidate: Optional[CounterpartCandidate] = None
    alternates: List[Dict[str, Any]] = []

    if counterpart_name:
        # Caller supplied an explicit name; still resolve for metadata
        cands = resolve_counterpart(
            variable=root_var,
            language=language,
            blueprint_dir=blueprint_dir,
            graph_file=graph_file,
            home_stem=selected_chain[-1],
        )
        # Find the supplied name among candidates (or synthesize minimal metadata)
        for c in cands:
            if c.counterpart_name.upper() == counterpart_name.upper() or (
                c.cpp_field and c.cpp_field.lower() == counterpart_name.lower()
            ):
                best_candidate = c
                break
        if best_candidate is None:
            # Not in the resolved list; build a minimal stub so link is populated
            counterpart_language = "cpp" if language == "asm" else "asm"
            best_candidate = CounterpartCandidate(
                counterpart_name=counterpart_name,
                counterpart_language=counterpart_language,
                home_stem=counterpart_chain[-1],
                cc_header="",
                cpp_field=counterpart_name if counterpart_language == "cpp" else None,
                mapping_via="explicit_override",
                certainty=0.0,
                certainty_label="low",
                confidence_strategy="explicit_override",
            )
            warnings.append(
                f"Counterpart '{counterpart_name}' was explicitly supplied but not found "
                "in the cc-header alias index; link metadata may be incomplete."
            )
        alternates = [asdict(c) for c in cands if c is not best_candidate]
    else:
        cands = resolve_counterpart(
            variable=root_var,
            language=language,
            blueprint_dir=blueprint_dir,
            graph_file=graph_file,
            home_stem=selected_chain[-1],
        )
        if not cands:
            warnings.append(
                f"No cross-language counterpart found for '{root_var}' ({language}). "
                "Running primary traversal only; counterpart will be null in the output."
            )
        else:
            best_candidate = cands[0]
            if len(cands) > 1:
                # Warn when top two candidates are tied on certainty
                if cands[0].certainty_label == cands[1].certainty_label:
                    warnings.append(
                        f"Multiple counterpart candidates tied at certainty='{cands[0].certainty_label}'; "
                        f"using '{cands[0].counterpart_name}' (first by home_stem). "
                        f"Alternates: {[c.counterpart_name for c in cands[1:3]]}."
                    )
            alternates = [asdict(c) for c in cands[1:]]

    # ── Shared tuning kwargs ─────────────────────────────────────────────────
    common_kwargs: Dict[str, Any] = dict(
        blueprint_dir=blueprint_dir,
        asm_dir=asm_dir,
        graph_file=graph_file,
        max_depth=max_depth,
        max_subroutine_depth=max_subroutine_depth,
        max_subroutine_nodes=max_subroutine_nodes,
        max_trace_nodes=max_trace_nodes,
        max_dep_vars=max_dep_vars,
        max_dep_var_depth=max_dep_var_depth,
        max_downstream_depth=max_downstream_depth,
        max_downstream_files=max_downstream_files,
        t8_max_scan=t8_max_scan,
        partitioned_output=partitioned_output,
    )

    # ── Primary traversal ────────────────────────────────────────────────────
    primary_dir = output_path / "primary"
    primary_dir.mkdir(parents=True, exist_ok=True)
    logger.info(
        "co-traversal: running primary — variable=%s chain=%s output=%s",
        root_var, selected_chain, primary_dir,
    )
    rc_primary = run_backward_only(
        variable=root_var,
        selected_chain=selected_chain,
        output_path=primary_dir,
        **common_kwargs,
    )
    if rc_primary != 0:
        logger.error("co-traversal: primary run failed (rc=%d)", rc_primary)
        _write_cotraversal_json(
            output_path=output_path,
            primary_var=root_var,
            primary_language=language,
            primary_chain=selected_chain,
            primary_partitioned=partitioned_output,
            counterpart_candidate=best_candidate,
            counterpart_chain=counterpart_chain,
            counterpart_partitioned=partitioned_output,
            alternates=alternates,
            warnings=warnings + [f"Primary traversal failed with rc={rc_primary}."],
            counterpart_ran=False,
            terminal_classifications={},
        )
        return rc_primary

    # ── Counterpart traversal ────────────────────────────────────────────────
    rc_counterpart = 0
    if best_candidate is not None:
        counterpart_dir = output_path / "counterpart"
        counterpart_dir.mkdir(parents=True, exist_ok=True)
        logger.info(
            "co-traversal: running counterpart — variable=%s chain=%s output=%s",
            best_candidate.counterpart_name, counterpart_chain, counterpart_dir,
        )
        rc_counterpart = run_backward_only(
            variable=best_candidate.counterpart_name,
            selected_chain=counterpart_chain,
            output_path=counterpart_dir,
            **common_kwargs,
        )
        if rc_counterpart != 0:
            warnings.append(
                f"Counterpart traversal for '{best_candidate.counterpart_name}' failed "
                f"with rc={rc_counterpart}."
            )

    # ── Terminal classification ───────────────────────────────────────────────
    terminal_classifications: Dict[str, Any] = {}
    try:
        from backward_traversal.enrichment.terminal_classifier import (
            classify_terminal_variables,
            extract_terminals_from_partitioned_dir,
        )
        for side, side_dir, side_lang in [
            ("primary", primary_dir, language),
            ("counterpart",
             output_path / "counterpart" if best_candidate is not None and rc_counterpart == 0 else None,
             "cpp" if language == "asm" else "asm"),
        ]:
            if side_dir is None or not (side_dir / "dep_vars").is_dir():
                continue
            side_terminals = extract_terminals_from_partitioned_dir(side_dir / "dep_vars")
            if side_terminals:
                side_classes = classify_terminal_variables(
                    side_terminals, blueprint_dir, asm_dir, graph_file, use_llm=False
                )
                if side_classes:
                    terminal_classifications[side] = side_classes
    except Exception as _tc_err:
        logger.warning("co-traversal: terminal classification failed (non-fatal): %s", _tc_err)

    # ── Write link artifact ──────────────────────────────────────────────────
    _write_cotraversal_json(
        output_path=output_path,
        primary_var=root_var,
        primary_language=language,
        primary_chain=selected_chain,
        primary_partitioned=partitioned_output,
        counterpart_candidate=best_candidate,
        counterpart_chain=counterpart_chain,
        counterpart_partitioned=partitioned_output,
        alternates=alternates,
        warnings=warnings,
        counterpart_ran=(best_candidate is not None and rc_counterpart == 0),
        terminal_classifications=terminal_classifications,
    )

    return 0 if rc_counterpart == 0 else rc_counterpart


def _write_cotraversal_json(
    output_path: Path,
    primary_var: str,
    primary_language: str,
    primary_chain: List[str],
    primary_partitioned: bool,
    counterpart_candidate: Optional[Any],
    counterpart_chain: List[str],
    counterpart_partitioned: bool,
    alternates: List[Dict[str, Any]],
    warnings: List[str],
    counterpart_ran: bool,
    terminal_classifications: Optional[Dict[str, Any]] = None,
) -> None:
    """Write cotraversal.json at the output root."""

    primary_block: Dict[str, Any] = {
        "variable": primary_var,
        "language": primary_language,
        "selected_chain": primary_chain,
        "output_dir": "primary",
    }
    if primary_partitioned:
        primary_block["manifest"] = "primary/manifest.json"
    else:
        primary_block["output_file"] = "primary.json"

    if counterpart_candidate is not None:
        c = counterpart_candidate
        counterpart_block: Any = {
            "variable": c.counterpart_name,
            "language": c.counterpart_language,
            "selected_chain": counterpart_chain,
            "output_dir": "counterpart",
        }
        if counterpart_partitioned:
            counterpart_block["manifest"] = "counterpart/manifest.json"
        else:
            counterpart_block["output_file"] = "counterpart.json"
        counterpart_block["ran"] = counterpart_ran

        # Derive struct name from qualified cpp_field
        struct_name: Optional[str] = None
        if c.cpp_field and "." in c.cpp_field:
            struct_name = c.cpp_field.split(".")[0]

        link_block: Dict[str, Any] = {
            "primary_var": primary_var,
            "primary_language": primary_language,
            "counterpart_var": c.counterpart_name,
            "counterpart_language": c.counterpart_language,
            "cc_header": c.cc_header,
            "struct_name": struct_name,
            "home_stem": c.home_stem,
            "certainty": c.certainty,
            "certainty_label": c.certainty_label,
            "confidence_strategy": c.confidence_strategy,
            "mapping_via": c.mapping_via,
            "bidirectional": True,
            "alternates": alternates,
        }
    else:
        counterpart_block = None
        link_block = {
            "primary_var": primary_var,
            "primary_language": primary_language,
            "counterpart_var": None,
            "counterpart_language": None,
            "certainty": 0.0,
            "certainty_label": "none",
            "bidirectional": False,
            "alternates": [],
        }

    doc = {
        "traversal_mode": "backward_cotraversal",
        "primary": primary_block,
        "counterpart": counterpart_block,
        "link": link_block,
        "warnings": warnings,
        "terminal_classifications": terminal_classifications or {},
    }

    artifact = output_path / "cotraversal.json"
    artifact.write_text(json.dumps(doc, indent=2), encoding="utf-8")
    logger.info("co-traversal: wrote link artifact %s", artifact)


# ---------------------------------------------------------------------------
# Namespace dispatcher (for CLI)
# ---------------------------------------------------------------------------

def run_cotraversal_from_namespace(args: Any) -> int:
    """Entry point from argparse namespace (CLI --cotraverse path)."""
    from backward_traversal.utils.blueprint_utils import (
        discover_blueprint_dir,
        discover_asm_dir,
        discover_graph_file,
    )
    from backward_traversal.runner.backward_only_runner import (
        DEFAULT_MAX_DEP_VARS,
        DEFAULT_MAX_DEP_VAR_DEPTH,
        DEFAULT_MAX_DOWNSTREAM_DEPTH,
        DEFAULT_MAX_DOWNSTREAM_FILES,
        DEFAULT_MAX_SUBROUTINE_DEPTH,
        DEFAULT_MAX_SUBROUTINE_NODES,
        DEFAULT_MAX_TRACE_NODES,
    )

    variable = str(args.variable)
    selected_chain = [p.strip() for p in str(args.chain_files or "").split(",") if p.strip()]
    counterpart_chain = [p.strip() for p in str(args.counterpart_chain or "").split(",") if p.strip()]

    if not selected_chain:
        print("ERROR: --chain-files is required for --cotraverse.", file=sys.stderr)
        return 1
    if not counterpart_chain:
        print("ERROR: --counterpart-chain is required for --cotraverse.", file=sys.stderr)
        return 1

    output_path = Path(args.output) if args.output else Path(f"{variable}_cotraversal")

    if args.blueprint_dir:
        blueprint_dir = Path(args.blueprint_dir)
        if not blueprint_dir.exists():
            print(f"ERROR: Blueprint dir not found: {blueprint_dir}", file=sys.stderr)
            return 1
    else:
        blueprint_dir = discover_blueprint_dir()
        if blueprint_dir is None:
            print("ERROR: Could not discover blueprint directory. Pass --blueprint-dir.", file=sys.stderr)
            return 1

    asm_dir = Path(args.asm_dir) if args.asm_dir else discover_asm_dir(blueprint_dir)
    graph_file = Path(args.graph) if args.graph else discover_graph_file(blueprint_dir)

    if graph_file is None or not graph_file.exists():
        print("ERROR: Cannot find file_call_graph.json. Pass --graph.", file=sys.stderr)
        return 1

    language = str(getattr(args, "counterpart_language", "") or "asm").lower()
    counterpart_name = getattr(args, "counterpart_var", None) or None

    print(f"[co-traversal blueprints] {blueprint_dir}", file=sys.stderr)
    if asm_dir:
        print(f"[co-traversal asm-source] {asm_dir}", file=sys.stderr)
    print(f"[co-traversal call graph] {graph_file}", file=sys.stderr)
    print(f"[co-traversal primary]    {variable} on {selected_chain}", file=sys.stderr)
    print(f"[co-traversal counterpart] (lang={language}) on {counterpart_chain}", file=sys.stderr)

    return run_cotraversal(
        variable=variable,
        language=language,
        selected_chain=selected_chain,
        counterpart_chain=counterpart_chain,
        blueprint_dir=blueprint_dir,
        asm_dir=asm_dir,
        graph_file=graph_file,
        output_path=output_path,
        counterpart_name=counterpart_name,
        max_depth=int(args.max_depth) if args.max_depth is not None else 8,
        max_subroutine_depth=int(getattr(args, "max_subroutine_depth", DEFAULT_MAX_SUBROUTINE_DEPTH)),
        max_subroutine_nodes=int(getattr(args, "max_subroutine_nodes", DEFAULT_MAX_SUBROUTINE_NODES)),
        max_trace_nodes=int(getattr(args, "max_trace_nodes", DEFAULT_MAX_TRACE_NODES)),
        max_dep_vars=int(getattr(args, "max_dep_vars", DEFAULT_MAX_DEP_VARS)),
        max_dep_var_depth=int(getattr(args, "max_dep_var_depth", DEFAULT_MAX_DEP_VAR_DEPTH)),
        max_downstream_depth=int(getattr(args, "max_downstream_depth", DEFAULT_MAX_DOWNSTREAM_DEPTH)),
        max_downstream_files=int(getattr(args, "max_downstream_files", DEFAULT_MAX_DOWNSTREAM_FILES)),
        t8_max_scan=int(getattr(args, "t8_max_scan", 0)),
        partitioned_output=True,
    )
