"""CHA / over-approximation resolver for hard C++ constructs.

For constructs that are NOT exactly resolvable by any static analyzer — virtual
dispatch, function pointers, union/pointer-arith aliasing — the sound answer is
**over-approximation**: include ALL candidates so a setter is never missed, and
flag them.  This module turns the metadata the parser emits (Step 5b) into
candidate seeds; when that metadata is absent it returns nothing plus a
``gvl_limit`` marker so the limitation is visible (never a silent omission).

Consumes (all optional, populated by the C++ parser GVL-completeness work):
- ``class_bases`` (blueprint/GVL): {class: [base, ...]} for class-hierarchy walk.
- address-taken function table: {signature: [func, ...]} for function pointers.
- ``may_alias`` edges (relation == "may_alias"): union members + pointer→base.
- ``exception_path`` guard tags on conditional_context (handled by dep-resolver).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Set, Tuple


def _node_lookup_by_name(gvl: Dict[str, Any], name: str) -> List[str]:
    needle = str(name or "").lower()
    out: List[str] = []
    for n in (gvl.get("nodes") or []):
        nm = str(n.get("name") or "").lower()
        nid = str(n.get("id") or "")
        if nm == needle or nid.lower().endswith(f"::{needle}"):
            out.append(nid or nm)
    return out


def cha_candidate_seeds(
    bp_or_gvl: Dict[str, Any],
    base_method: str,
    gvl: Optional[Dict[str, Any]] = None,
) -> Tuple[List[str], Optional[str]]:
    """All override implementations of ``base_method`` across the class hierarchy.

    Returns ``(candidate_seed_ids, gvl_limit_marker)``.  Over-approximates (every
    override) so no setter is missed; flags ``gvl_limit:virtual`` when no class
    hierarchy is available.
    """
    class_bases = bp_or_gvl.get("class_bases") or {}
    if not class_bases:
        return [], "virtual"
    g = gvl if gvl is not None else bp_or_gvl
    # Walk the full hierarchy (bases + derived) reachable from any class.
    classes: Set[str] = set(class_bases.keys())
    for bases in class_bases.values():
        classes.update(bases or [])
    seeds: List[str] = []
    seen: Set[str] = set()
    method = str(base_method or "").split("::")[-1]
    for cls in sorted(classes):
        for sid in _node_lookup_by_name(g, f"{cls}::{method}") or _node_lookup_by_name(g, method):
            if sid not in seen:
                seen.add(sid)
                seeds.append(sid)
    return seeds, (None if seeds else "virtual")


def fnptr_candidate_seeds(
    bp_or_gvl: Dict[str, Any],
    signature: str,
    gvl: Optional[Dict[str, Any]] = None,
) -> Tuple[List[str], Optional[str]]:
    """All address-taken functions matching ``signature`` (over-approx)."""
    table = bp_or_gvl.get("address_taken_functions") or {}
    if not table:
        return [], "fnptr"
    g = gvl if gvl is not None else bp_or_gvl
    funcs = table.get(signature) or table.get("*") or []
    seeds: List[str] = []
    seen: Set[str] = set()
    for fn in funcs:
        for sid in _node_lookup_by_name(g, fn):
            if sid not in seen:
                seen.add(sid)
                seeds.append(sid)
    return seeds, (None if seeds else "fnptr")


def union_may_alias_siblings(
    bp_or_gvl: Dict[str, Any], field_name: str
) -> Tuple[List[str], Optional[str]]:
    """Sibling members of any union ``field_name`` belongs to (over-approx).

    Reads the parser's ``union_members`` map ({union: [member, ...]}, emitted by
    the GVL-completeness work).  Writing one member may change reads of any
    other, so the siblings are alternate value-sources of ``field_name`` —
    following them is the sound (never-miss) behaviour.  Matching is on the
    terminal field name so qualified members (``U.a`` / ``U::a``) still match.

    Returns ``(sibling_terminals, gvl_limit_marker)``; marker ``"union"`` when
    the map is absent, so the limitation is surfaced rather than silently
    dropped.  A no-op (``[]``, ``"union"``) until a C++ re-ingest populates the
    map.
    """
    um = bp_or_gvl.get("union_members") or {}
    if not um:
        return [], "union"

    def _term(m: str) -> str:
        return str(m or "").split(".")[-1].split("::")[-1].strip()

    needle = _term(field_name)
    out: List[str] = []
    seen: Set[str] = set()
    for members in um.values():
        terms = [_term(m) for m in (members or [])]
        if needle in terms:
            for t in terms:
                if t and t != needle and t not in seen:
                    seen.add(t)
                    out.append(t)
    return out, (None if out else "union")


def follow_may_alias(gvl: Dict[str, Any], node_id: str) -> List[str]:
    """Node ids that may-alias ``node_id`` (union members, pointer→base).

    Reads ``relation == "may_alias"`` edges (emitted by parser Step 5b).  Empty
    when none present — the caller attaches a ``gvl_limit`` marker in that case.
    """
    nid = str(node_id or "")
    out: List[str] = []
    for e in (gvl.get("edges") or []):
        if str(e.get("relation") or "").lower() != "may_alias":
            continue
        s, t = str(e.get("source") or ""), str(e.get("target") or "")
        if nid in (s, t):
            other = t if nid == s else s
            if other and other != nid:
                out.append(other)
    return out
