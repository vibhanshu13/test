"""Dependency-kind classification + sound value-pruning for the chainless tracer.

Implements the ``x = y + 2`` (data_flow) vs ``if (y == 2) x = 2``
(conditional_guard) vs read-modify-write (prior_value) distinction, and the
**sound** value-pruning: a guard dependency whose setter provably assigns a
constant that contradicts the guard constraint is flagged ``relevant=False``
(with a reason) — but **never deleted**, so nothing is lost.

Only sound, 100%-accurate marking is done here:
- kind is derived deterministically from ``classify_setter`` (role /
  prior_value_required) + condition extraction.
- the literal guard constraint (operator + constant) is captured.
- contradiction marking fires ONLY when a setter provably assigns a constant
  that cannot satisfy the constraint; computed/non-constant setters are kept
  (conservative).  No path-feasibility / symbolic reasoning is attempted.

Pure functions — no I/O, no traversal.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from backward_traversal.models.chainless_models import Constraint, DepVar

# ---------------------------------------------------------------------------
# Kind classification
# ---------------------------------------------------------------------------


def classify_dep_kind(
    verdict_role: Optional[str],
    prior_value_required: bool,
    guarded_by_condition: bool,
) -> str:
    """Return the DepKind for a dependency.

    Precedence: prior_value (read-modify-write) > conditional_guard > data_flow.
    A dep is a conditional_guard when ``classify_setter`` tagged the site
    ``CONDITION_CHECK`` OR the dep var appears in a guard condition gating the
    setter.
    """
    if prior_value_required:
        return "prior_value"
    role = str(verdict_role or "").upper()
    if role == "CONDITION_CHECK" or guarded_by_condition:
        return "conditional_guard"
    return "data_flow"


# ---------------------------------------------------------------------------
# Constraint extraction (ASM + C++)
# ---------------------------------------------------------------------------

# ASM TRIGGER + BRANCH idiom, e.g. "TM @CCIBIND,X'10' / BZ DA7_9100"
#                                  "CLC FIELD,=C'A' / BE LABEL"
#                                  "CP CNT,=P'2' / BNE LABEL"
_ASM_GUARD_RE = re.compile(
    r"^\s*(?P<trig>[A-Z]{2,6})\s+(?P<args>[^/]+?)\s*/\s*(?P<branch>[A-Z]{1,6})\b",
    re.IGNORECASE,
)
# A literal operand: =X'..', =P'..', =C'..', =H'..', =F'..', X'..', or bare digits.
_ASM_LITERAL_RE = re.compile(
    r"=?[XPCHF]'([^']*)'|=?(?P<dec>\d+)\b", re.IGNORECASE
)

# C++ comparison, e.g. "x == 2", "flag != 0", "n < 10", "(b == 2)"
# rhs allows a trailing ')' so parenthesised guards (from short-circuit
# decomposition) parse; the ')' is stripped from the captured constant.
_CPP_CMP_RE = re.compile(
    r".*?(?P<op>==|!=|<=|>=|<|>)\s*(?P<rhs>[A-Za-z0-9_'\".\-]+)\)?\s*$"
)

# Map an ASM branch mnemonic to the comparison sense it represents (best-effort).
# We keep it conservative: the operator is reported for the *test*, the branch
# only tells us the taken/not-taken sense which we record in `raw`.
_ASM_EQ_BRANCHES = {"BE", "BZ", "JE", "JZ"}
_ASM_NE_BRANCHES = {"BNE", "BNZ", "JNE", "JNZ"}


def _first_asm_literal(args: str) -> Optional[str]:
    for m in _ASM_LITERAL_RE.finditer(args or ""):
        val = m.group(1)
        if val is None:
            val = m.group("dec")
        if val is not None and val != "":
            return val
    return None


def extract_constraint(condition_str: str) -> Constraint:
    """Parse a guard string into a Constraint, always preserving the raw text.

    Handles ASM ``TRIG args / BRANCH`` idioms and C++ ``lhs OP rhs`` forms.
    operator/constant are best-effort; ``raw`` is never empty so nothing is lost.
    """
    raw = str(condition_str or "").strip()
    operator: Optional[str] = None
    constant: Optional[str] = None

    m = _ASM_GUARD_RE.match(raw)
    if m:
        branch = m.group("branch").upper()
        constant = _first_asm_literal(m.group("args"))
        if branch in _ASM_EQ_BRANCHES:
            operator = "=="
        elif branch in _ASM_NE_BRANCHES:
            operator = "!="
        else:
            operator = f"{m.group('trig').upper()}/{branch}"
        return Constraint(raw=raw, operator=operator, constant=constant)

    c = _CPP_CMP_RE.match(raw)
    if c:
        operator = c.group("op")
        rhs = c.group("rhs").strip().strip("'\"")
        constant = rhs if rhs else None
        return Constraint(raw=raw, operator=operator, constant=constant)

    return Constraint(raw=raw, operator=None, constant=None)


# ---------------------------------------------------------------------------
# Sound value-pruning (constant-contradiction marking)
# ---------------------------------------------------------------------------


def _norm_const(v: Optional[str]) -> Optional[str]:
    if v is None:
        return None
    s = str(v).strip().strip("'\"").upper()
    # Strip a leading ASM literal type prefix if it slipped through (X/P/C/H/F).
    return s or None


def _provably_contradicts(assigned: str, operator: str, constant: str) -> bool:
    """True ONLY when we can prove the assigned constant cannot satisfy op/const.

    Conservative: returns False whenever either side is non-comparable, so we
    never prune on uncertainty.
    """
    a = _norm_const(assigned)
    k = _norm_const(constant)
    if a is None or k is None:
        return False
    op = (operator or "").strip()
    # Equality / inequality work on string-normalised literals.
    if op == "==":
        return a != k
    if op == "!=":
        return a == k
    # Numeric relations only when both parse as ints.
    try:
        ai, ki = int(a, 0), int(k, 0)
    except (ValueError, TypeError):
        return False
    if op == "<":
        return not (ai < ki)
    if op == ">":
        return not (ai > ki)
    if op == "<=":
        return not (ai <= ki)
    if op == ">=":
        return not (ai >= ki)
    return False


def mark_relevance(dep: DepVar, dep_setter_sites: List[Dict[str, Any]]) -> DepVar:
    """Flag a conditional_guard dep as irrelevant ONLY when provably contradicted.

    For each setter site of ``dep`` that provably assigns a constant which
    cannot satisfy ``dep.constraint``, mark ``relevant=False`` with a reason.
    A setter that is computed / non-constant keeps the dep relevant
    (conservative).  The dep is **never removed**.
    """
    if dep.kind != "conditional_guard" or dep.constraint is None:
        return dep
    op = dep.constraint.operator
    k = dep.constraint.constant
    if not op or k is None or not dep_setter_sites:
        return dep

    any_possible = False
    contradicting: List[str] = []
    for site in dep_setter_sites:
        is_const = bool(site.get("constant_source"))
        assigned = site.get("constant_value") or site.get("setter_expression") or ""
        if is_const and assigned and _provably_contradicts(str(assigned), op, str(k)):
            contradicting.append(str(assigned))
        else:
            # Either non-constant (cannot decide → possible) or constant that
            # satisfies the constraint.
            any_possible = True

    if contradicting and not any_possible:
        dep.relevant = False
        dep.pruned_reason = (
            f"all setters assign constant(s) {sorted(set(contradicting))} "
            f"contradicting guard {op}{k}"
        )
    return dep
