"""Runner entrypoints for backward-only traversal mode."""
