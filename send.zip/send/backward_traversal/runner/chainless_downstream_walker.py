"""GAP B2 (your point 14) — descend into relevant downstream callees.

While backward-tracing a variable we must also descend into methods/subroutines
CALLED within the trace that participate in setting it — not just climb to
callers.

- ASM intra-file BAS/BAL already descend via ``trace_asm_call_site_backward``
  subroutine expansion.  Here we add cross-file ASM callees (ENTRC/EXSR): find
  cross-file calls within the variable's scope and continue tracing there.
- C++ callee descent: the ``global_variable_lineage`` is a single graph whose
  ``assign``/``arg_bind``/return edges already cross function and file
  boundaries, so a setter inside a C++ callee is reachable in the global trace.
  We collect the files actually reached (each edge's ``file``) so the forest
  records the callee descent explicitly (closes DOWN-4 visibility).

Bounded + cycle-safe; shares the global visited set with the caller walk.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


def downstream_files_from_cpp_trace(trace: Dict[str, Any]) -> Set[str]:
    """Files reached by a C++ global-GVL trace (callee descent made explicit)."""
    files: Set[str] = set()
    for e in (trace.get("edges") or []):
        f = e.get("file")
        if f:
            from backward_traversal.runner.chainless_setter_enumerator import _stem_from_edge_file
            stem = _stem_from_edge_file(str(f))
            if stem:
                files.add(stem)
    return files


def walk_downstream_asm(
    variable: str,
    stem: str,
    scope_blocks: Set[str],
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    *,
    max_downstream_depth: int = 0,
    visited: Optional[Set[Tuple[str, str]]] = None,
    depth: int = 0,
) -> List[Dict[str, Any]]:
    """Follow cross-file ASM calls within scope and re-trace the variable there.

    Returns a list of ``{callee_stem, dep_vars, warnings, depth}`` records.
    Bounded by ``max_downstream_depth`` (0 = unlimited); cycle-safe.
    """
    if visited is None:
        visited = set()
    if max_downstream_depth and depth >= max_downstream_depth:
        return []
    try:
        from backward_traversal.runner.backward_only_runner import (
            _collect_scoped_cross_file_calls,
            _is_followable_cross_file_call,
        )
        from backward_traversal.utils.blueprint_utils import load_json, resolve_asm_blueprint
    except Exception:  # pragma: no cover
        return []
    bp_path = resolve_asm_blueprint(stem, blueprint_dir)
    if not bp_path:
        return []
    try:
        bp = load_json(bp_path)
    except Exception:
        return []
    asm_file = (asm_dir / f"{stem}.asm") if asm_dir else None
    try:
        cross = _collect_scoped_cross_file_calls(bp, scope_blocks, asm_file, asm_dir)
    except Exception as exc:
        logger.debug("downstream scan failed for %s: %s", stem, exc)
        return []
    out: List[Dict[str, Any]] = []
    for cf in cross:
        try:
            if not _is_followable_cross_file_call(cf):
                continue
        except Exception:
            pass
        callee = str(cf.get("target_file") or cf.get("target") or "").strip()
        if not callee:
            continue
        pair = (stem.upper(), callee.upper())
        if pair in visited:
            continue
        visited.add(pair)
        out.append({"caller_stem": stem, "callee_stem": callee, "depth": depth + 1,
                    "instruction": cf.get("instruction")})
        # Recurse downstream from the callee.
        callee_bp = resolve_asm_blueprint(callee, blueprint_dir)
        if callee_bp:
            try:
                cbp = load_json(callee_bp)
                callee_blocks = {str(b.get("id") or "") for b in (cbp.get("blocks") or []) if b.get("id")}
            except Exception:
                callee_blocks = set()
            out.extend(
                walk_downstream_asm(
                    variable, callee, callee_blocks, blueprint_dir, asm_dir,
                    max_downstream_depth=max_downstream_depth, visited=visited, depth=depth + 1,
                )
            )
    return out
