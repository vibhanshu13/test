"""Upfront backward-path planner for the dep_var BFS loop.

Bulk-prefetches ALL GVL edges and nodes for the selected-chain's
reachability cone in two SQL queries, then provides in-memory
``get(target)`` / ``get(node_id)`` lookups that are drop-in
replacements for ``_DbReverseIndex`` / ``_DbNodeLookup``.

Typical memory: 10-15 chain stems × 3K-10K edges each = 50K-150K
edges × ~500 bytes ≈ 25-75 MB — well within the 4-8 GB budget.

For large codebases (22K+ files) where cone stems contain 200K+
edges, the planner skips bulk prefetch and falls back to lazy
DB-backed indices to avoid 500 MB+ memory allocation.

Usage (in backward_only_runner.py, before the BFS loop)::

    plan = BackwardPathPlan(job_id, db_path, cone_stems)
    rev_idx = plan.make_reverse_index()
    node_lk = plan.make_node_lookup()
    # Use rev_idx / node_lk in place of _shared_db_rev / _shared_db_nl
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
from collections import OrderedDict
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

# Maximum number of GVL edges to bulk-prefetch into memory.
# Above this threshold the planner skips bulk prefetch and falls back to
# lazy DB-backed indices (_DbReverseIndex / _DbNodeLookup).
# Default 200 K edges × ~500 bytes ≈ 100 MB.  Override via env var.
_MAX_PREFETCH_EDGES: int = int(os.environ.get("ASM_MAX_PREFETCH_EDGES", "200000"))


# ── edge/node column helpers (mirrors lazy_gvl._EDGE_COLS_BASE) ──────────────

_EDGE_COLS = (
    "source, target, relation, file, line, expression, "
    "operation_type, transformation, symbolic_identity, "
    "access_identity, file_label, field_offset, dsect"
)

_NODE_COLS = "node_id, kind, name, extra_json"


def _parse_cc(raw: Any) -> Any:
    """Parse a ``conditional_context`` JSON string from the DB."""
    if not raw:
        return None
    if isinstance(raw, (list, tuple)):
        return list(raw)
    try:
        return json.loads(raw)
    except Exception:
        return None


# ── In-memory reverse index ──────────────────────────────────────────────────


class _PlanReverseIndex:
    """In-memory reverse index pre-loaded from the reachability cone.

    Implements the same ``get(target, default)`` interface as
    ``_DbReverseIndex``.  Lookups for targets within the cone are O(1)
    dict reads.  Targets outside the cone fall through to an optional
    ``_DbReverseIndex`` fallback for correctness.
    """

    __slots__ = ("_index", "_fallback", "_hit", "_miss")

    def __init__(
        self,
        index: Dict[str, List[Dict[str, Any]]],
        fallback: Any = None,
    ) -> None:
        self._index = index
        self._fallback = fallback
        self._hit = 0
        self._miss = 0

    def get(self, target: str, default: Any = None) -> Any:
        if target in self._index:
            self._hit += 1
            result = self._index[target]
            return result if result else default
        self._miss += 1
        if self._fallback is not None:
            return self._fallback.get(target, default)
        return default

    def prefetch(self, targets: list) -> None:
        """Delegate uncached targets to the fallback's prefetch (if available).

        Targets already in the in-memory index are no-ops.  Targets outside
        the cone are forwarded to the DB-backed fallback for batch loading.
        """
        if self._fallback is None or not hasattr(self._fallback, "prefetch"):
            return
        uncached = [t for t in targets if t not in self._index]
        if uncached:
            self._fallback.prefetch(uncached)

    @property
    def stats(self) -> Dict[str, int]:
        return {"hit": self._hit, "miss": self._miss}

    def close(self) -> None:
        """Compatibility with _DbReverseIndex.close()."""
        if self._fallback is not None and hasattr(self._fallback, "close"):
            self._fallback.close()


class _PlanNodeLookup:
    """In-memory node lookup pre-loaded from the reachability cone.

    Implements the same ``get(node_id, default)`` interface as
    ``_DbNodeLookup``.
    """

    __slots__ = ("_nodes", "_fallback")

    def __init__(
        self,
        nodes: Dict[str, Dict[str, Any]],
        fallback: Any = None,
    ) -> None:
        self._nodes = nodes
        self._fallback = fallback

    def get(self, node_id: str, default: Any = None) -> Any:
        node = self._nodes.get(node_id)
        if node is not None:
            return node
        if self._fallback is not None:
            return self._fallback.get(node_id, default)
        return default

    def close(self) -> None:
        """Compatibility with _DbNodeLookup.close()."""
        if self._fallback is not None and hasattr(self._fallback, "close"):
            self._fallback.close()


# ── BackwardPathPlan ─────────────────────────────────────────────────────────


class BackwardPathPlan:
    """Upfront planner that bulk-prefetches GVL data for selected-chain stems.

    Two bulk SQL queries replace thousands of per-target round-trips:

    1. Edges query: ``SELECT … FROM gvl_edges WHERE job_id=? AND file_stem IN (…)``
       → builds ``target → [edges]`` reverse index.

    2. Nodes query: ``SELECT … FROM gvl_nodes WHERE job_id=? AND node_id IN (…)``
       → builds ``node_id → node`` lookup for all nodes referenced by edges.

    The resulting in-memory indexes are passed to the BFS loop via
    ``make_reverse_index()`` / ``make_node_lookup()``.
    """

    def __init__(
        self,
        job_id: str,
        db_path: str,
        cone_stems: Set[str],
        *,
        fallback_rev: Any = None,
        fallback_nl: Any = None,
    ) -> None:
        self._job_id = job_id
        self._db_path = db_path
        self._cone_stems = {s.lower().strip() for s in cone_stems if s}
        self._fallback_rev = fallback_rev
        self._fallback_nl = fallback_nl

        self._edges_by_target: Dict[str, List[Dict[str, Any]]] = {}
        self._nodes: Dict[str, Dict[str, Any]] = {}
        self._edge_count = 0
        self._skipped_prefetch = False

        self._prefetch()

    # ── bulk prefetch ────────────────────────────────────────────────────

    def _prefetch(self) -> None:
        if not self._cone_stems:
            return

        con: Optional[sqlite3.Connection] = None
        try:
            con = sqlite3.connect(self._db_path, check_same_thread=False)
            con.row_factory = sqlite3.Row
            # Performance PRAGMAs for bulk read
            con.execute("PRAGMA journal_mode=WAL")
            con.execute("PRAGMA synchronous=NORMAL")
            con.execute("PRAGMA cache_size=-131072")  # 128 MB page cache
            con.execute("PRAGMA temp_store=MEMORY")
            con.execute("PRAGMA mmap_size=536870912")  # 512 MB mmap

            # ── Row-count guard: estimate edge count before bulk load ──
            # For large codebases (22K+ files), cone stems may contain 200K+
            # edges.  Skip bulk prefetch to avoid 500 MB+ allocation.
            est_count = self._estimate_edge_count(con)
            if est_count > _MAX_PREFETCH_EDGES:
                est_mb = est_count * 500 // (1024 * 1024)
                logger.info(
                    "[PathPlan] cone has ~%d edges (~%d MB) — exceeds "
                    "prefetch limit (%d).  Using lazy DB-backed indices.",
                    est_count, est_mb, _MAX_PREFETCH_EDGES,
                )
                self._skipped_prefetch = True
                return

            # Detect conditional_context column
            cols = {r[1] for r in con.execute("PRAGMA table_info(gvl_edges)")}
            has_cc = "conditional_context" in cols

            self._fetch_edges(con, has_cc)
            self._fetch_nodes(con)

            logger.info(
                "[PathPlan] prefetched %d edges (%d targets) + %d nodes "
                "for %d cone stems",
                self._edge_count,
                len(self._edges_by_target),
                len(self._nodes),
                len(self._cone_stems),
            )
        except Exception as exc:
            logger.warning("[PathPlan] prefetch failed: %s", exc)
        finally:
            if con is not None:
                try:
                    con.close()
                except Exception:
                    pass

    def _estimate_edge_count(self, con: sqlite3.Connection) -> int:
        """Estimate how many GVL edges the cone stems contain.

        Uses a chunked COUNT query (same grouping as _fetch_edges) to
        determine whether bulk prefetch is safe.  The count query is
        fast because it reads the ``ix_gvl_edges_file_stem`` index
        without decoding row data.
        """
        stems = list(self._cone_stems)
        total = 0
        chunk_size = 50
        for i in range(0, len(stems), chunk_size):
            chunk = stems[i : i + chunk_size]
            placeholders = ", ".join("?" for _ in chunk)
            sql = (
                f"SELECT COUNT(*) FROM gvl_edges "
                f"WHERE job_id = ? AND file_stem IN ({placeholders})"
            )
            params = [self._job_id] + chunk
            row = con.execute(sql, params).fetchone()
            total += row[0] if row else 0
        return total

    def _fetch_edges(self, con: sqlite3.Connection, has_cc: bool) -> None:
        """Bulk-fetch all edges whose file_stem is in the cone."""
        stems = list(self._cone_stems)
        select = f"SELECT {_EDGE_COLS}"
        if has_cc:
            select += ", conditional_context"

        # Chunk stems in groups of 50 (SQLite variable limit is 999)
        chunk_size = 50
        for i in range(0, len(stems), chunk_size):
            chunk = stems[i : i + chunk_size]
            placeholders = ", ".join("?" for _ in chunk)
            sql = (
                f"{select} FROM gvl_edges "
                f"WHERE job_id = ? AND file_stem IN ({placeholders})"
            )
            params = [self._job_id] + chunk
            for row in con.execute(sql, params):
                edge: Dict[str, Any] = {
                    k: row[k] for k in row.keys() if row[k] is not None
                }
                if has_cc and "conditional_context" in edge:
                    parsed = _parse_cc(edge["conditional_context"])
                    if parsed is not None:
                        edge["conditional_context"] = parsed
                    else:
                        edge.pop("conditional_context", None)
                target = edge.get("target", "")
                if target:
                    self._edges_by_target.setdefault(target, []).append(edge)
                self._edge_count += 1

    def _fetch_nodes(self, con: sqlite3.Connection) -> None:
        """Bulk-fetch all nodes referenced by prefetched edges."""
        # Collect all node_ids from edges (sources and targets)
        all_ids: Set[str] = set()
        for target, edges in self._edges_by_target.items():
            all_ids.add(target)
            for e in edges:
                src = e.get("source")
                if src:
                    all_ids.add(src)

        if not all_ids:
            return

        id_list = list(all_ids)
        chunk_size = 500
        for i in range(0, len(id_list), chunk_size):
            chunk = id_list[i : i + chunk_size]
            placeholders = ", ".join("?" for _ in chunk)
            sql = (
                f"SELECT {_NODE_COLS} FROM gvl_nodes "
                f"WHERE job_id = ? AND node_id IN ({placeholders})"
            )
            params = [self._job_id] + chunk
            for row in con.execute(sql, params):
                node: Dict[str, Any] = {
                    "id": row["node_id"],
                    "kind": row["kind"],
                    "name": row["name"],
                }
                extra = row["extra_json"]
                if extra:
                    try:
                        node.update(json.loads(extra))
                    except Exception:
                        pass
                self._nodes[row["node_id"]] = node

    # ── public API ───────────────────────────────────────────────────────

    def make_reverse_index(self):
        """Return a reverse index (drop-in for _DbReverseIndex).

        When bulk prefetch was skipped (edge count exceeded threshold),
        returns the fallback DB-backed index directly instead of wrapping
        an empty in-memory dict.
        """
        if self._skipped_prefetch and self._fallback_rev is not None:
            return self._fallback_rev
        return _PlanReverseIndex(self._edges_by_target, self._fallback_rev)

    def make_node_lookup(self):
        """Return a node lookup (drop-in for _DbNodeLookup).

        When bulk prefetch was skipped, returns the fallback DB-backed
        lookup directly.
        """
        if self._skipped_prefetch and self._fallback_nl is not None:
            return self._fallback_nl
        return _PlanNodeLookup(self._nodes, self._fallback_nl)

    @property
    def edge_count(self) -> int:
        return self._edge_count

    @property
    def node_count(self) -> int:
        return len(self._nodes)

    @property
    def cone_stem_count(self) -> int:
        return len(self._cone_stems)
