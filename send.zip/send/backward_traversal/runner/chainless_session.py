"""GAP E + checkpoint/resume — resumable, paginated chainless session.

Mirrors ``ChunkedBackwardSession`` (new class, no chain assumptions).  The
forest of independent setter roots is processed one **tuple** at a time; a tuple
is one setter root's exploration (its trace + deps + callers + downstream),
tagged with ``root_id`` so the forest membership is explicit and per-root
pagination is a filtered view over the same chunks.

Resumability: the msgpack ``work_queue`` + ``tuple_index_map`` ARE the
checkpoint — ``load`` + ``process_until_tuple`` continue exactly where they
stopped.  Saves are **atomic** (temp-write + ``os.replace``) and happen after
each work unit, so a mid-run kill loses at most one tuple and never leaves a
half-written session.  Idempotent: re-processing a completed root is a no-op.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import time
from collections import deque
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import msgpack

logger = logging.getLogger(__name__)

PHASE_ENUMERATE = "enumerate"
PHASE_TRACE_ROOTS = "trace_roots"
PHASE_COMPLETE = "complete"

# KB-8: cap visited_downstream to prevent unbounded RAM growth when a session
# processes hundreds of roots each contributing many downstream file pairs.
# 10 K entries × ~60 bytes/entry ≈ 600 KB — negligible vs. the chunk data.
_MAX_VISITED_DOWNSTREAM = 10_000

_OPTION_KEYS = [
    "expand_counterparts", "max_caller_depth", "max_dep_var_depth",
    "max_downstream_depth", "max_nodes", "max_files", "max_setter_roots", "max_depth",
]


def compute_chainless_session_id(
    kb_id: str, variable: str, language: Optional[str],
    options: Dict[str, Any], graph_file_mtime: float,
) -> str:
    """Stable session id — hashes (kb, variable, language, options, fingerprint). NO chain."""
    key_options = {k: options.get(k) for k in _OPTION_KEYS}
    raw = json.dumps(
        {
            "kb_id": kb_id,
            "variable": variable.upper(),
            "language": (language or "auto"),
            "options": key_options,
            "mtime": str(graph_file_mtime),
            "schema_version": 1,
            "kind": "chainless",
        },
        sort_keys=True, separators=(",", ":"),
    )
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def get_chainless_session_dir(kb_id: str, session_id: str) -> Path:
    from api.config import settings
    return (
        settings.JOBS_BASE_DIR / kb_id / "output"
        / "backward_lineage" / "chainless" / session_id
    )


def get_chainless_session_file(kb_id: str, session_id: str) -> Path:
    return get_chainless_session_dir(kb_id, session_id) / "session.msgpack"


class ChainlessBackwardSession:
    """Resumable per-tuple driver for the chainless forest."""

    def __init__(self, state: Dict[str, Any]) -> None:
        self._s = state

    # -- identity ----------------------------------------------------------
    @property
    def session_id(self) -> str:
        return self._s["session_id"]

    @property
    def phase(self) -> str:
        return self._s.get("phase", PHASE_ENUMERATE)

    @property
    def is_complete(self) -> bool:
        return self.phase == PHASE_COMPLETE

    @property
    def total_tuples(self) -> int:
        return len(self._s.get("tuple_index_map", []))

    # -- construction ------------------------------------------------------
    @classmethod
    def new(
        cls, *, session_id: str, kb_id: str, variable: str, language: Optional[str],
        blueprint_dir: Path, graph_file: Path, asm_dir: Optional[Path],
        job_id: Optional[str], options: Dict[str, Any], graph_fingerprint: str = "",
    ) -> "ChainlessBackwardSession":
        state = {
            "session_id": session_id,
            "kb_id": kb_id,
            "job_id": job_id,
            "root_variable": variable,
            "language": language,
            "blueprint_dir": str(blueprint_dir),
            "graph_file": str(graph_file),
            "asm_dir": str(asm_dir) if asm_dir else None,
            "options": {k: options.get(k) for k in _OPTION_KEYS},
            "phase": PHASE_ENUMERATE,
            "setter_roots": [],
            "counterparts": [],
            "work_queue": [],          # list of ["root", root_id]
            "tuple_index_map": [],     # [{chunk_file, root_id, file_stem, file_type, variable, phase}]
            "visited_callers": [],     # serialised "caller|callee" pairs
            "visited_downstream": [],
            "warnings": [],
            "graph_fingerprint": graph_fingerprint,
        }
        return cls(state)

    @classmethod
    def load(cls, kb_id: str, session_id: str, *, session_file: Optional[Path] = None):
        path = session_file or get_chainless_session_file(kb_id, session_id)
        if not path.exists():
            return None
        try:
            raw = msgpack.unpackb(path.read_bytes(), raw=False)
            return cls(raw) if isinstance(raw, dict) else None
        except Exception:
            return None

    def save(self, kb_id: str, session_id: str, *, session_file: Optional[Path] = None) -> None:
        """Atomic save: temp-write + os.replace (never a half-written session)."""
        path = session_file or get_chainless_session_file(kb_id, session_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
        tmp.write_bytes(msgpack.packb(self._s, use_bin_type=True))
        os.replace(tmp, path)   # atomic on POSIX

    # -- runtime (rebuilt on demand, not persisted) ------------------------
    def _runtime(self):
        from backward_traversal.runner.chainless_runner import load_runtime
        roots = self._s.get("setter_roots", [])
        need_cpp = any(r.get("file_type") == "cpp" for r in roots) or not roots
        return load_runtime(
            Path(self._s["blueprint_dir"]), Path(self._s["graph_file"]),
            self._s.get("job_id"), need_cpp,
        )

    def _caps(self) -> Dict[str, int]:
        o = self._s.get("options", {})
        return {
            "max_nodes": o.get("max_nodes") or 0,
            "max_depth": o.get("max_depth") or 0,
            "max_caller_depth": o.get("max_caller_depth") or 0,
            "max_downstream_depth": o.get("max_downstream_depth") or 0,
            "max_dep_setter_scan": 200,
        }

    # -- phase 1: enumeration ---------------------------------------------
    def _ensure_enumerated(self) -> None:
        if self._s["phase"] != PHASE_ENUMERATE:
            return
        logger.info("[SESSION] Enumeration phase — var=%s — start",
                    self._s.get("root_variable", "?"))
        _t0 = time.monotonic()
        from dataclasses import asdict
        from backward_traversal.runner.chainless_setter_enumerator import enumerate_setter_roots
        o = self._s.get("options", {})
        roots, counterparts, warns = enumerate_setter_roots(
            self._s["root_variable"], self._s.get("language"),
            Path(self._s["blueprint_dir"]), Path(self._s["graph_file"]),
            Path(self._s["asm_dir"]) if self._s.get("asm_dir") else None,
            job_id=self._s.get("job_id"),
            expand_counterparts=bool(o.get("expand_counterparts", True)),
            max_setter_roots=o.get("max_setter_roots") or 0,
            max_files=o.get("max_files") or 0,
        )
        self._s["setter_roots"] = [asdict(r) for r in roots]
        self._s["counterparts"] = [asdict(c) for c in counterparts]
        self._s["warnings"].extend(warns)
        self._s["work_queue"] = [["root", r.root_id] for r in roots]
        self._s["phase"] = PHASE_TRACE_ROOTS
        logger.info("[SESSION] Enumeration phase — %d roots found — %.1fs",
                    len(roots), time.monotonic() - _t0)
        if not self._s["work_queue"]:
            self._s["phase"] = PHASE_COMPLETE

    def _root_by_id(self, root_id: str) -> Optional[Dict[str, Any]]:
        for r in self._s.get("setter_roots", []):
            if r.get("root_id") == root_id:
                return r
        return None

    def _process_one_root(self, root_id: str, runtime) -> None:
        # Idempotent: skip if this root already produced a tuple.
        if any(t.get("root_id") == root_id for t in self._s["tuple_index_map"]):
            return
        from backward_traversal.models.chainless_models import SetterRoot
        from backward_traversal.runner.chainless_runner import process_single_root
        rd = self._root_by_id(root_id)
        if rd is None:
            return
        _rt0 = time.monotonic()
        _root_label = f"{rd.get('file_stem', '?')}:{rd.get('variable', '?')}"
        logger.info("[SESSION] Root %s — start", _root_label)
        reverse_adj, node_type, gvl = runtime
        root = SetterRoot(**{k: v for k, v in rd.items() if k in SetterRoot.__dataclass_fields__})
        vd: Set[Tuple[str, str]] = {tuple(p.split("|", 1)) for p in self._s.get("visited_downstream", []) if "|" in p}
        result = process_single_root(
            root, blueprint_dir=Path(self._s["blueprint_dir"]),
            graph_file=Path(self._s["graph_file"]),
            asm_dir=Path(self._s["asm_dir"]) if self._s.get("asm_dir") else None,
            job_id=self._s.get("job_id"), gvl=gvl, reverse_adj=reverse_adj,
            node_type=node_type, caps=self._caps(), visited_callers=set(), visited_downstream=vd,
        )
        # KB-8: cap serialised visited_downstream to prevent the session file from
        # growing without bound across many roots (500 roots × N pairs each).
        # Sort before truncating so the surviving entries are deterministic
        # regardless of Python's hash-randomised set iteration order.
        serialised = sorted(f"{a}|{b}" for (a, b) in vd)
        if len(serialised) > _MAX_VISITED_DOWNSTREAM:
            serialised = serialised[-_MAX_VISITED_DOWNSTREAM:]
        self._s["visited_downstream"] = serialised
        logger.info("[SESSION] Root %s — done — %.1fs", _root_label, time.monotonic() - _rt0)
        idx = len(self._s["tuple_index_map"])
        chunk_file = f"chunk_{idx}.msgpack"
        self._write_chunk(chunk_file, result)
        self._s["tuple_index_map"].append({
            "chunk_file": chunk_file, "root_id": root_id,
            "file_stem": root.file_stem, "file_type": root.file_type,
            "variable": root.variable, "phase": "setter_root",
        })

    def _write_chunk(self, chunk_file: str, payload: Dict[str, Any]) -> None:
        d = get_chainless_session_dir(self._s["kb_id"], self._s["session_id"])
        d.mkdir(parents=True, exist_ok=True)
        (d / chunk_file).write_bytes(msgpack.packb(payload, use_bin_type=True))

    def assemble_tuple(self, tuple_index: int) -> Optional[Dict[str, Any]]:
        tim = self._s.get("tuple_index_map", [])
        if tuple_index < 0 or tuple_index >= len(tim):
            return None
        meta = tim[tuple_index]
        d = get_chainless_session_dir(self._s["kb_id"], self._s["session_id"])
        try:
            payload = msgpack.unpackb((d / meta["chunk_file"]).read_bytes(), raw=False)
        except Exception:
            payload = {}
        out = dict(meta)
        out["tuple"] = payload
        return out

    # -- driving -----------------------------------------------------------
    def process_until_tuple(self, target_index: int, *, save_each: bool = True) -> None:
        """Drive the forest until ``tuple_index_map`` covers ``target_index``."""
        self._ensure_enumerated()
        if save_each:
            self.save(self._s["kb_id"], self._s["session_id"])
        runtime = None
        # Use a deque for O(1) popleft; convert back to list only on save.
        _q = deque(self._s["work_queue"])
        while len(self._s["tuple_index_map"]) <= target_index and _q:
            self._s["work_queue"] = list(_q)  # keep in sync before each save
            if runtime is None:
                runtime = self._runtime()
            item = _q.popleft()
            if item and item[0] == "root":
                self._process_one_root(item[1], runtime)
            self._s["work_queue"] = list(_q)  # reflect consumed item before save
            if save_each:
                self.save(self._s["kb_id"], self._s["session_id"])   # atomic, per unit
        self._s["work_queue"] = list(_q)  # final sync (may be empty after loop)
        if not _q:
            self._s["phase"] = PHASE_COMPLETE
            if save_each:
                self.save(self._s["kb_id"], self._s["session_id"])

    def process_all(self, *, save_each: bool = True, workers: int = 0) -> None:
        """Drive all roots to completion.

        When ``workers`` > 1 (or 0 = auto-detect cpu_count//2, min 1), roots are
        processed in parallel — each root is independent so the shared runtime
        (reverse_adj / node_type / gvl) is read-only and safe to share across
        threads.  Per-root results are collected and written to the session in
        deterministic order after all futures complete.  Falls back to the
        sequential path when only one worker is available.
        """
        self._ensure_enumerated()
        _pa_t0 = time.monotonic()
        pending = [i[1] for i in self._s.get("work_queue", []) if i and i[0] == "root"]
        # Skip roots already processed (idempotent)
        done_ids = {t.get("root_id") for t in self._s.get("tuple_index_map", [])}
        pending = [rid for rid in pending if rid not in done_ids]
        if not pending:
            self._s["phase"] = PHASE_COMPLETE
            if save_each:
                self.save(self._s["kb_id"], self._s["session_id"])
            return

        import os
        from concurrent.futures import ThreadPoolExecutor, as_completed
        from backward_traversal.models.chainless_models import SetterRoot
        from backward_traversal.runner.chainless_runner import process_single_root

        n_workers = workers if workers > 0 else max(1, (os.cpu_count() or 2) // 2)
        logger.info("[SESSION] Processing phase — %d roots (%d workers)",
                    len(pending), n_workers)
        if n_workers <= 1 or len(pending) == 1:
            self.process_until_tuple(1 << 30, save_each=save_each)
            return

        runtime = self._runtime()
        reverse_adj, node_type, gvl = runtime
        blueprint_dir = Path(self._s["blueprint_dir"])
        graph_file = Path(self._s["graph_file"])
        asm_dir = Path(self._s["asm_dir"]) if self._s.get("asm_dir") else None
        caps = self._caps()
        kb_id = self._s["kb_id"]
        session_id = self._s["session_id"]

        def _run_one(root_id: str) -> Tuple[str, Dict[str, Any]]:
            rd = self._root_by_id(root_id)
            if rd is None:
                return root_id, {}
            root = SetterRoot(**{k: v for k, v in rd.items()
                                 if k in SetterRoot.__dataclass_fields__})
            result = process_single_root(
                root, blueprint_dir=blueprint_dir, graph_file=graph_file,
                asm_dir=asm_dir, job_id=kb_id, gvl=gvl,
                reverse_adj=reverse_adj, node_type=node_type, caps=caps,
                # Each root gets its own visited sets — no cross-root dedup
                # needed for parallel execution (roots are independent).
                visited_callers=set(), visited_downstream=set(),
            )
            return root_id, result

        results: Dict[str, Dict[str, Any]] = {}
        with ThreadPoolExecutor(max_workers=n_workers) as pool:
            futures = {pool.submit(_run_one, rid): rid for rid in pending}
            for fut in as_completed(futures):
                try:
                    rid, result = fut.result()
                    results[rid] = result
                except Exception as exc:
                    rid = futures[fut]
                    logger.warning("process_all_parallel: root %s failed: %s", rid, exc)
                    results[rid] = {}

        # Write chunks in the original pending order for determinism
        for root_id in pending:
            result = results.get(root_id, {})
            if not result:
                continue
            rd = self._root_by_id(root_id)
            if rd is None:
                continue
            idx = len(self._s["tuple_index_map"])
            chunk_file = f"chunk_{idx}.msgpack"
            self._write_chunk(chunk_file, result)
            self._s["tuple_index_map"].append({
                "chunk_file": chunk_file, "root_id": root_id,
                "file_stem": rd.get("file_stem", ""), "file_type": rd.get("file_type", "asm"),
                "variable": rd.get("variable", ""), "phase": "setter_root",
            })

        # Clear processed roots from work_queue
        done_now = set(pending)
        self._s["work_queue"] = [
            i for i in self._s["work_queue"]
            if not (i and i[0] == "root" and i[1] in done_now)
        ]
        if not self._s["work_queue"]:
            self._s["phase"] = PHASE_COMPLETE
        logger.info("[SESSION] Processing complete — %d/%d roots — %.1fs",
                    len(self._s.get("tuple_index_map", [])), len(pending),
                    time.monotonic() - _pa_t0)
        if save_each:
            self.save(kb_id, session_id)

    def process_root(self, root_id: str, *, save_each: bool = True) -> Optional[Dict[str, Any]]:
        """Process exactly one root (per-setter API) and return its tuple."""
        self._ensure_enumerated()
        runtime = self._runtime()
        self._process_one_root(root_id, runtime)
        if root_id in [i[1] for i in self._s["work_queue"] if i and i[0] == "root"]:
            self._s["work_queue"] = [i for i in self._s["work_queue"]
                                     if not (i and i[0] == "root" and i[1] == root_id)]
        if not self._s["work_queue"]:
            self._s["phase"] = PHASE_COMPLETE
        if save_each:
            self.save(self._s["kb_id"], self._s["session_id"])
        for i, t in enumerate(self._s["tuple_index_map"]):
            if t.get("root_id") == root_id:
                return self.assemble_tuple(i)
        return None
