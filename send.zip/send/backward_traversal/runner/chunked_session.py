"""Chunked backward lineage session state machine.

Manages incremental backward traversal across multiple API calls.
Session state is persisted as msgpack on disk under the KB output directory.
"""

from __future__ import annotations

import hashlib
import json
import logging
from collections import deque
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

import msgpack

from backward_traversal.runner.backward_only_runner import (
    _aggregate_dep_var_collection_blocks,
    _add_full_flow_edge,
    _build_asm_upstream_payload,
    _build_child_dep_var_map,
    _build_cpp_upstream_payload,
    _build_dep_var_cpp_result,
    _build_dep_var_file_result,
    _build_modifier_asm_payload,
    _build_modifier_cpp_payload,
    _clear_cross_file_call_cache,
    _collect_scoped_cross_file_calls,
    _dep_var_origin_chain,
    _edge_lines_map,
    _edge_type_map,
    _ensure_full_flow_node,
    _finalize_full_flow_collector,
    _forward_reachable_from,
    _is_followable_cross_file_call,
    _is_returning_cross_file_call,
    _new_full_flow_collector,
    _norm_file_id,
    _path_to_chain_file,
    DEFAULT_MAX_DEP_VARS,
    DEFAULT_MAX_DEP_VAR_DEPTH,
    DEFAULT_MAX_DOWNSTREAM_DEPTH,
    DEFAULT_MAX_DOWNSTREAM_FILES,
)
from backward_traversal.utils.cpp_lineage_utils import (
    build_chain_neighbor_set,
    find_cpp_files_for_dep_var,
)
from backward_traversal.tracing.asm_backward_tracer import (
    DEFAULT_MAX_SUBROUTINE_DEPTH,
    DEFAULT_MAX_SUBROUTINE_NODES,
    DEFAULT_MAX_TRACE_NODES,
    backward_reachable_blocks,
)
from backward_traversal.utils.blueprint_utils import (
    clear_blueprint_cache,
    clear_constant_symbols_cache,
    load_json,
    resolve_asm_blueprint,
    resolve_cpp_blueprint,
    resolve_file_type,
    resolve_source_file,
)

from backward_traversal.utils.variable_name_resolver import VariableNameResolver

PHASE_PASS1 = "PASS1"
PHASE_PASS1B = "PASS1B"
PHASE_PASS2B = "PASS2B"
PHASE_COMPLETE = "COMPLETE"

_OPTION_KEYS = [
    "max_depth", "max_subroutine_depth", "max_subroutine_nodes",
    "max_trace_nodes", "max_dep_vars", "max_dep_var_depth",
    "max_downstream_depth", "max_downstream_files",
    "t8_max_scan",   # T8/FIX18: 0 = disabled (default); >0 = cross-chain C++ dep_var search
]


def compute_session_id(
    kb_id: str,
    variable: str,
    chain_files: List[str],
    options: Dict[str, Any],
    graph_file_mtime: float,
) -> str:
    """Stable SHA256-16 session ID for (kb_id, variable, chain_files, options, kb_fingerprint)."""
    key_options = {k: options.get(k) for k in _OPTION_KEYS}
    raw = json.dumps(
        {
            "kb_id": kb_id,
            "variable": variable.upper(),
            "chain_files": sorted(chain_files),
            "options": key_options,
            "mtime": str(graph_file_mtime),
            "schema_version": 2,
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def get_session_dir(kb_id: str, session_id: str) -> Path:
    from api.config import settings
    return (
        settings.JOBS_BASE_DIR
        / kb_id / "output" / "backward_lineage" / "chunked" / session_id
    )


def get_session_file(kb_id: str, session_id: str) -> Path:
    return get_session_dir(kb_id, session_id) / "session.msgpack"


# ---------------------------------------------------------------------------
# Full-flow collector serialization (sets / tuple-keys → msgpack-safe)
# ---------------------------------------------------------------------------

def _ff_to_serial(ff: Dict[str, Any]) -> Dict[str, Any]:
    sn: Dict[str, Any] = {}
    for nid, n in ff.get("nodes", {}).items():
        sn[nid] = {
            "id": n["id"],
            "file_type": n["file_type"],
            "scope_variables": sorted(n.get("scope_variables") or set()),
            "in_selected_chain": bool(n.get("in_selected_chain")),
            "roles": sorted(n.get("roles") or set()),
        }
    se: Dict[str, Any] = {}
    for (src, tgt), e in ff.get("edges", {}).items():
        ser = {
            "source": e["source"],
            "target": e["target"],
            "instructions": sorted(e.get("instructions") or set()),
            "scope_variables": sorted(e.get("scope_variables") or set()),
            "discovered_from": sorted(e.get("discovered_from") or set()),
            "source_blocks": sorted(e.get("source_blocks") or set()),
            "lines": sorted(
                int(l) for l in (e.get("lines") or set())
                if isinstance(l, int) and l > 0
            ),
        }
        # Persist the indirect-call envelope opaquely so future Phase 2 fields
        # survive serialization without code changes here.
        if e.get("indirection"):
            ser["indirection"] = dict(e["indirection"])
        se[f"{src}|{tgt}"] = ser
    return {"nodes": sn, "edges": se}


def _ff_from_serial(data: Dict[str, Any]) -> Dict[str, Any]:
    nodes: Dict[str, Any] = {}
    for nid, n in (data.get("nodes") or {}).items():
        nodes[nid] = {
            "id": n["id"],
            "file_type": n["file_type"],
            "scope_variables": set(n.get("scope_variables") or []),
            "in_selected_chain": bool(n.get("in_selected_chain")),
            "roles": set(n.get("roles") or []),
        }
    edges: Dict[Tuple[str, str], Any] = {}
    for key, e in (data.get("edges") or {}).items():
        src, tgt = key.split("|", 1)
        rec = {
            "source": e["source"],
            "target": e["target"],
            "instructions": set(e.get("instructions") or []),
            "scope_variables": set(e.get("scope_variables") or []),
            "discovered_from": set(e.get("discovered_from") or []),
            "source_blocks": set(e.get("source_blocks") or []),
            "lines": set(e.get("lines") or []),
        }
        if e.get("indirection"):
            rec["indirection"] = dict(e["indirection"])
        edges[(src, tgt)] = rec
    return {"nodes": nodes, "edges": edges}


class ChunkedBackwardSession:
    """State machine for incremental backward lineage traversal."""

    def __init__(self, state: Dict[str, Any]) -> None:
        self._s = state
        self._var_resolver: Optional[VariableNameResolver] = None
        # T9: transient (not persisted) — rebuilt lazily on first T8 trigger per session object.
        self._t8_neighbor_set: Optional[Set[str]] = None
        self._t8_neighbor_set_built: bool = False

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def session_id(self) -> str:
        return self._s["session_id"]

    @property
    def is_complete(self) -> bool:
        return self._s["phase"] == PHASE_COMPLETE

    @property
    def tuple_index_map(self) -> List[Dict[str, Any]]:
        return self._s.get("tuple_index_map") or []

    @property
    def warnings(self) -> List[str]:
        return list(dict.fromkeys(self._s.get("warnings") or []))

    @property
    def _bp_dir(self) -> Path:
        return Path(self._s["blueprint_dir"])

    @property
    def _asm_dir(self) -> Optional[Path]:
        d = self._s.get("asm_dir")
        return Path(d) if d else None

    @property
    def _options(self) -> Dict[str, Any]:
        return self._s.get("options") or {}

    @property
    def _root_variable(self) -> str:
        return self._s["root_variable"]

    @property
    def _selected_chain(self) -> List[str]:
        return self._s["selected_chain"]

    @property
    def _resolver(self) -> VariableNameResolver:
        """Lazily instantiated resolver, cached per session object."""
        if self._var_resolver is None:
            self._var_resolver = VariableNameResolver.from_path(
                self._s.get("identity_index_path") or "",
                blueprint_dir=self._bp_dir,   # T6: enables C++ alias resolution
            )
        return self._var_resolver

    # ------------------------------------------------------------------
    # Creation / persistence
    # ------------------------------------------------------------------

    @classmethod
    def new(
        cls,
        session_id: str,
        kb_id: str,
        variable: str,
        selected_chain: List[str],
        options: Dict[str, Any],
        blueprint_dir: Path,
        asm_dir: Optional[Path],
        graph_file: Path,
    ) -> "ChunkedBackwardSession":
        # Targeted DB reads — avoids loading the full 41 MB call graph JSON.
        # Each function queries only the columns it needs; call_sites_json is
        # only loaded for edge_lines_map (line numbers) and discarded immediately.
        from api.index_db.readers import (
            get_call_graph_node_types,
            get_call_graph_edge_type_map,
            get_call_graph_edge_lines_map,
        )
        _fb = graph_file if graph_file.exists() else None
        file_type_map: Dict[str, str] = get_call_graph_node_types(kb_id, fallback_path=_fb)
        etm_raw = get_call_graph_edge_type_map(kb_id, fallback_path=_fb)
        elm_raw = get_call_graph_edge_lines_map(kb_id, fallback_path=_fb)

        edge_type_serial = {f"{s}|{t}": v for (s, t), v in etm_raw.items()}
        edge_lines_serial = {f"{s}|{t}": sorted(v) for (s, t), v in elm_raw.items()}

        modifier_stem = selected_chain[-1]
        root_var = variable.upper()
        selected_chain_set = {_norm_file_id(s) for s in selected_chain}

        ff = _new_full_flow_collector()
        for stem in selected_chain:
            roles = ["selected_chain"]
            if _norm_file_id(stem) == _norm_file_id(modifier_stem):
                roles.append("modifier")
            _ensure_full_flow_node(
                ff, stem,
                blueprint_dir=blueprint_dir,
                file_type_map=file_type_map,
                selected_chain_set=selected_chain_set,
                roles=roles,
                scope_var=root_var,
            )

        for i in range(len(selected_chain) - 1):
            caller = selected_chain[i]
            callee = selected_chain[i + 1]
            edge_instr = etm_raw.get((caller, callee), "?")
            chain_lines = elm_raw.get((caller, callee), set())
            for cln in chain_lines or {None}:
                _add_full_flow_edge(
                    ff,
                    source=caller,
                    target=callee,
                    blueprint_dir=blueprint_dir,
                    file_type_map=file_type_map,
                    selected_chain_set=selected_chain_set,
                    scope_var=root_var,
                    instruction=edge_instr,
                    discovered_from="chain_upstream",
                    source_block=None,
                    line_no=cln,
                )

        # Build work queue: modifier first, then upstream pairs in reverse chain order
        _resolver_new = VariableNameResolver(blueprint_dir)
        work_queue: List[List[Any]] = [["modifier_file", modifier_stem]]
        upstream_pairs = [
            (selected_chain[i], selected_chain[i + 1])
            for i in range(len(selected_chain) - 2, -1, -1)
        ]
        for caller, callee in upstream_pairs:
            edge_instr = etm_raw.get((caller, callee), "?")
            caller_type = resolve_file_type(caller, blueprint_dir, file_type_map)
            callee_type = resolve_file_type(callee, blueprint_dir, file_type_map)
            _origin_chain = _path_to_chain_file(callee, selected_chain)
            caller_var = _resolver_new.resolve(variable, caller, source_stem=callee) or root_var
            work_queue.append([
                "upstream_file", caller, callee, edge_instr,
                caller_type, callee_type, caller_var,
            ])

        # Lightweight fingerprint from sorted node IDs + edge pairs — avoids
        # serialising the entire graph payload into RAM just for hashing.
        fp = hashlib.sha256(
            json.dumps(
                {
                    "nodes": sorted(file_type_map.keys()),
                    "edges": sorted((s, t) for s, t in etm_raw.keys()),
                },
                sort_keys=True,
                separators=(",", ":"),
            ).encode()
        ).hexdigest()

        state: Dict[str, Any] = {
            "session_id": session_id,
            "kb_id": kb_id,
            "root_variable": root_var,
            "selected_chain": selected_chain,
            "blueprint_dir": str(blueprint_dir),
            "asm_dir": str(asm_dir) if asm_dir else None,
            "options": {k: options.get(k) for k in _OPTION_KEYS},
            "phase": PHASE_PASS1,
            "tuple_index_map": [],
            "empty_tuples": [],
            "work_queue": work_queue,
            "file_meta": {},
            "dep_var_collection_map": {},
            "visited_dep_vars": [],
            "rv_visited_downstream": [],
            "full_flow_serial": _ff_to_serial(ff),
            "file_type_map": file_type_map,
            "edge_type_serial": edge_type_serial,
            "edge_lines_serial": edge_lines_serial,
            "selected_chain_set": sorted(selected_chain_set),
            "warnings": [],
            "graph_fingerprint": fp,
            "identity_index_path": _resolver_new.index_path or "",
        }
        return cls(state)

    @classmethod
    def load(
        cls,
        kb_id: str,
        session_id: str,
        *,
        session_file: Optional[Path] = None,
    ) -> Optional["ChunkedBackwardSession"]:
        path = session_file if session_file is not None else get_session_file(kb_id, session_id)
        if not path.exists():
            return None
        try:
            raw = msgpack.unpackb(path.read_bytes(), raw=False)
            if not isinstance(raw, dict):
                return None
            return cls(raw)
        except Exception:
            return None

    def save(
        self,
        kb_id: str,
        session_id: str,
        *,
        session_file: Optional[Path] = None,
    ) -> None:
        path = session_file if session_file is not None else get_session_file(kb_id, session_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(msgpack.packb(self._s, use_bin_type=True))
        # CO-5: write a lightweight sidecar so _backward_session_meta can read
        # the 4 key fields without unpacking the full (potentially multi-MB) msgpack.
        try:
            import os
            meta_path = path.with_name("session_meta.json")
            meta = {
                "is_complete": self.is_complete,
                "total_tuples": len(self.tuple_index_map),
                "selected_chain": self._selected_chain,
                "root_variable": self._root_variable,
            }
            tmp = meta_path.with_suffix(".tmp." + str(os.getpid()))
            tmp.write_text(json.dumps(meta, separators=(",", ":")), encoding="utf-8")
            os.replace(tmp, meta_path)
        except Exception:
            pass  # sidecar is advisory; never fail the main save

    @classmethod
    def load_meta(
        cls,
        kb_id: str,
        session_id: str,
        *,
        session_file: Optional[Path] = None,
    ) -> Optional[Dict[str, Any]]:
        """Return lightweight session metadata without deserialising the full msgpack.

        Reads ``session_meta.json`` sidecar written by :meth:`save`.  Falls back
        to loading the full session when the sidecar is absent (e.g. old sessions).
        """
        path = session_file if session_file is not None else get_session_file(kb_id, session_id)
        meta_path = path.with_name("session_meta.json")
        if meta_path.exists():
            try:
                return json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception:
                pass
        # Fallback: full load
        sess = cls.load(kb_id, session_id, session_file=session_file)
        if sess is None:
            return None
        return {
            "is_complete": sess.is_complete,
            "total_tuples": len(sess.tuple_index_map),
            "selected_chain": sess._selected_chain,
            "root_variable": sess._root_variable,
        }

    # ------------------------------------------------------------------
    # Main processing loop
    # ------------------------------------------------------------------

    def process_until_tuple(self, target_tuple_index: int, session_dir: Path) -> None:
        """Process work items until tuple_index_map has an entry at target_tuple_index, or COMPLETE.

        Uses a deque for O(1) popleft instead of list.pop(0) which is O(N).
        _dispatch_item and _try_transition both append to self._s["work_queue"]; we
        flush those appends into the deque after each call so the deque stays authoritative.
        """
        # Drain existing work_queue into a deque; dispatch/transition will append to
        # self._s["work_queue"] (set to []) and we extend the deque from there.
        _q: deque = deque(self._s["work_queue"])
        self._s["work_queue"] = []

        while not self.is_complete and len(self._s["tuple_index_map"]) <= target_tuple_index:
            if not _q:
                self._try_transition(session_dir)
                _q.extend(self._s["work_queue"])
                self._s["work_queue"] = []
                if not _q and not self.is_complete:
                    self._s["phase"] = PHASE_COMPLETE
                    break
            if not _q:
                break
            self._dispatch_item(_q.popleft(), session_dir)
            # Pick up any items appended by _dispatch_item
            _q.extend(self._s["work_queue"])
            self._s["work_queue"] = []

        # After the target tuple is indexed (or the session completed above), drain
        # through all remaining phase transitions so that is_complete is accurate.
        # We stop only when a NEW non-empty tuple beyond the target is found — that
        # means has_more is genuinely True and the next caller needs a separate task.
        # We must NOT break on transitions mid-drain; keep looping through _try_transition
        # until the work_queue refills with real items or the session completes.
        target_len = len(self._s["tuple_index_map"])
        while not self.is_complete:
            if not _q:
                self._try_transition(session_dir)
                _q.extend(self._s["work_queue"])
                self._s["work_queue"] = []
                if not _q and not self.is_complete:
                    self._s["phase"] = PHASE_COMPLETE
                    break
            if not _q:
                break
            self._dispatch_item(_q.popleft(), session_dir)
            _q.extend(self._s["work_queue"])
            self._s["work_queue"] = []
            if len(self._s["tuple_index_map"]) > target_len:
                # A non-empty tuple BEYOND the original target was indexed; has_more=True.
                break

        self._s["work_queue"] = list(_q)  # final sync — remaining items stay in session
        clear_blueprint_cache()
        clear_constant_symbols_cache()
        _clear_cross_file_call_cache()

    def _try_transition(self, session_dir: Path) -> None:
        phase = self._s["phase"]
        if phase == PHASE_PASS1:
            self._transition_pass1_to_pass1b()
        elif phase == PHASE_PASS1B:
            self._transition_pass1b_to_pass2b()
        elif phase == PHASE_PASS2B:
            self._s["phase"] = PHASE_COMPLETE

    def _transition_pass1_to_pass1b(self) -> None:
        blueprint_dir = self._bp_dir
        asm_dir = self._asm_dir
        root_var = self._root_variable
        selected_chain = self._selected_chain
        file_type_map = self._s["file_type_map"]
        selected_chain_set = set(self._s.get("selected_chain_set") or [])
        exclude_stems = {s.lower() for s in selected_chain}

        ff = _ff_from_serial(self._s["full_flow_serial"])
        seen_targets: Set[str] = set(self._s.get("rv_visited_downstream") or [])

        for stem in selected_chain:
            meta = self._s["file_meta"].get(stem)
            if not meta:
                continue
            bp_path_str = meta.get("bp_path")
            asm_file_str = meta.get("asm_file")
            if not bp_path_str or not asm_file_str:
                continue
            bp_path = Path(bp_path_str)
            if not bp_path.exists():
                continue

            bp_data = load_json(bp_path)
            anchor_blocks: Set[str] = set(meta.get("anchor_blocks") or [])
            if anchor_blocks:
                rv_scope: Set[str] = set()
                for b in anchor_blocks:
                    rv_scope.update(backward_reachable_blocks(
                        bp_data, b,
                        expand_subroutine_callers=True,
                        bp_path=bp_path_str,
                    ))
            else:
                rv_scope = {str(b["id"]) for b in bp_data.get("blocks", [])}

            rv_cross = _collect_scoped_cross_file_calls(
                bp_data, rv_scope, Path(asm_file_str), asm_dir, bp_path=bp_path
            )
            rv_returning = [cf for cf in rv_cross if _is_followable_cross_file_call(cf)]

            for cf in rv_returning:
                _add_full_flow_edge(
                    ff,
                    source=stem,
                    target=str(cf.get("target_file") or ""),
                    blueprint_dir=blueprint_dir,
                    file_type_map=file_type_map,
                    selected_chain_set=selected_chain_set,
                    scope_var=root_var,
                    instruction=str(cf.get("instruction") or ""),
                    discovered_from="root_var_scope",
                    source_block=str(cf.get("source_block") or ""),
                    line_no=cf.get("line"),
                )
                target = cf["target_file"]
                if target and target not in exclude_stems and target not in seen_targets:
                    seen_targets.add(target)
                    _stem_path = _path_to_chain_file(stem, selected_chain)
                    self._s["work_queue"].append([
                        "root_var_downstream", target, 0, stem, root_var, _stem_path,
                    ])

        self._s["full_flow_serial"] = _ff_to_serial(ff)
        self._s["phase"] = PHASE_PASS1B

    def _transition_pass1b_to_pass2b(self) -> None:
        dep_var_collection_map = self._s["dep_var_collection_map"]
        visited = set(self._s["visited_dep_vars"])
        for dv in sorted(dep_var_collection_map):
            if dv not in visited:
                self._s["work_queue"].append(["dep_var", dv, 0])
        self._s["phase"] = PHASE_PASS2B

    # ------------------------------------------------------------------
    # Item dispatch
    # ------------------------------------------------------------------

    def _dispatch_item(self, item: List[Any], session_dir: Path) -> None:
        item_type = item[0]
        if item_type == "modifier_file":
            self._process_modifier_file(item[1], session_dir)
        elif item_type == "upstream_file":
            self._process_upstream_file(
                item[1], item[2], item[3], item[4], item[5], item[6], session_dir
            )
        elif item_type == "root_var_downstream":
            self._process_root_var_downstream(
                item[1], item[2], item[3], item[4], item[5], session_dir
            )
        elif item_type == "dep_var":
            self._process_dep_var(item[1], item[2], session_dir)

    # ------------------------------------------------------------------
    # Node output helpers
    # ------------------------------------------------------------------

    def _write_chunk(
        self,
        session_dir: Path,
        nodes: List[Dict[str, Any]],
        variable: str,
        phase: str,
        metadata: Dict[str, Any],
    ) -> str:
        chunk_idx = len(self._s["tuple_index_map"])
        chunk_filename = f"chunk_{chunk_idx}.json"
        chunk_path = session_dir / chunk_filename
        chunk_path.write_text(
            json.dumps({"variable": variable, "phase": phase, "metadata": metadata, "nodes": nodes}),
            encoding="utf-8",
        )
        return chunk_filename

    def _append_nodes(
        self,
        call_graph: Dict[str, Any],
        file_stem: str,
        file_type: str,
        variable: str,
        phase: str,
        session_dir: Path,
        tuple_metadata: Optional[Dict[str, Any]] = None,
    ) -> int:
        nodes = list(call_graph.get("nodes") or [])
        if not nodes:
            reason = (tuple_metadata or {}).get("empty_reason", "no_nodes")
            self._s["empty_tuples"].append({
                "file_stem": file_stem,
                "variable": variable,
                "phase": phase,
                "reason": reason,
            })
            return 0
        meta = tuple_metadata or {}
        chunk_filename = self._write_chunk(session_dir, nodes, variable, phase, meta)
        self._s["tuple_index_map"].append({
            "chunk_file": chunk_filename,
            "file_stem": file_stem,
            "file_type": file_type,
            "variable": variable,
            "phase": phase,
            "node_count": len(nodes),
        })
        return len(nodes)

    def _update_dep_var_map(self, file_stem: str, trace_results: List[Dict[str, Any]]) -> None:
        per_file_dvs = _aggregate_dep_var_collection_blocks(trace_results)
        dvcm = self._s["dep_var_collection_map"]
        for dv, blocks in per_file_dvs.items():
            existing = dvcm.setdefault(dv, {})
            if file_stem in existing:
                existing[file_stem] = sorted(set(existing[file_stem]) | blocks)
            else:
                existing[file_stem] = sorted(blocks)

    def _update_dep_var_map_cpp(self, file_stem: str, cpp_trace: Dict[str, Any]) -> None:
        """Feed C++ dep_vars from a cpp_lineage_trace into dep_var_collection_map.  (T2)

        bridge_back_to_asm:* entries are routed to the nearest adjacent ASM stem
        in selected_chain (GAP B — mirrors backward_only_runner.py lines 1707-1724).
        Regular dep_vars use an empty list (no specific block IDs) because T3
        searches the full GVL.
        """
        dvcm = self._s["dep_var_collection_map"]
        selected_chain: List[str] = self._s.get("selected_chain") or []
        file_type_map: Dict[str, str] = self._s.get("file_type_map") or {}
        stem_idx = selected_chain.index(file_stem) if file_stem in selected_chain else -1

        for dv in (cpp_trace.get("dep_vars") or []):
            dv_str = str(dv or "").strip()
            if not dv_str:
                continue
            if dv_str.startswith("bridge_back_to_asm:"):
                # C2.3 fix: GAP B — route bridge register to nearest ASM stem.
                # Search forward (toward downstream) then backward (toward modifier).
                reg = dv_str.split(":", 1)[-1].upper()
                next_asm: Optional[str] = None
                for candidate in (selected_chain[stem_idx + 1:] if stem_idx >= 0 else []):
                    if resolve_file_type(candidate, self._bp_dir, file_type_map) == "asm":
                        next_asm = candidate
                        break
                if not next_asm:
                    for candidate in reversed(selected_chain[:stem_idx] if stem_idx > 0 else []):
                        if resolve_file_type(candidate, self._bp_dir, file_type_map) == "asm":
                            next_asm = candidate
                            break
                if next_asm:
                    dvcm.setdefault(reg, {}).setdefault(next_asm, [])
                else:
                    logger.warning(
                        "GAP B: bridge_back_to_asm:%s from C++ stem '%s' — no adjacent "
                        "ASM stem found in chain %s; register dep_var dropped.",
                        reg, file_stem, selected_chain,
                    )
            else:
                dv_up = dv_str.upper()
                if file_stem not in dvcm.get(dv_up, {}):
                    dvcm.setdefault(dv_up, {})[file_stem] = []

    # ------------------------------------------------------------------
    # PASS1 processors
    # ------------------------------------------------------------------

    def _process_modifier_file(self, modifier_stem: str, session_dir: Path) -> None:
        opts = self._options
        file_type_map = self._s.get("file_type_map") or {}
        modifier_type = resolve_file_type(modifier_stem, self._bp_dir, file_type_map)

        if modifier_type == "cpp":
            # T1: C++ modifier — trace backward in GVL
            payload = _build_modifier_cpp_payload(
                variable=self._root_variable,
                modifier_stem=modifier_stem,
                blueprint_dir=self._bp_dir,
                asm_dir=self._asm_dir,
            )
        else:
            payload = _build_modifier_asm_payload(
                variable=self._root_variable,
                modifier_stem=modifier_stem,
                blueprint_dir=self._bp_dir,
                asm_dir=self._asm_dir,
                max_depth=(int(opts["max_depth"]) if opts.get("max_depth") is not None else 8),
                max_subroutine_depth=(int(opts["max_subroutine_depth"]) if opts.get("max_subroutine_depth") is not None else DEFAULT_MAX_SUBROUTINE_DEPTH),
                max_subroutine_nodes=(int(opts["max_subroutine_nodes"]) if opts.get("max_subroutine_nodes") is not None else DEFAULT_MAX_SUBROUTINE_NODES),
                max_trace_nodes=(int(opts["max_trace_nodes"]) if opts.get("max_trace_nodes") is not None else DEFAULT_MAX_TRACE_NODES),
            )
        if payload.get("warnings"):
            self._s["warnings"].extend(payload["warnings"])

        anchor_blocks = [
            str(s.get("routine") or "")
            for s in (payload.get("setter_sites") or [])
            if s.get("routine")
        ]
        _abl_mod: Dict[str, int] = {}
        for _s in (payload.get("setter_sites") or payload.get("call_sites") or []):
            _k = str(_s.get("routine") or _s.get("function") or "")
            _l = int(_s.get("line") or 0)
            if _k and _l > 0:
                _abl_mod[_k] = min(_abl_mod.get(_k, _l), _l)

        meta_entry: Dict[str, Any] = {
            "anchor_blocks": anchor_blocks,
            "anchor_before_lines": _abl_mod,
            "file_type": modifier_type,
        }

        if modifier_type == "cpp":
            # T2: store C++ blueprint path and dep_vars for Pass 2
            cpp_bp_p = resolve_cpp_blueprint(modifier_stem, self._bp_dir)
            meta_entry["bp_path"] = None
            meta_entry["asm_file"] = None
            meta_entry["cpp_bp_path"] = str(cpp_bp_p) if cpp_bp_p else None
            meta_entry["cpp_lineage_trace"] = payload.get("cpp_lineage_trace") or {}
            # Feed C++ dep_vars into dep_var_collection_map
            self._update_dep_var_map_cpp(modifier_stem, payload.get("cpp_lineage_trace") or {})
        else:
            bp = resolve_asm_blueprint(modifier_stem, self._bp_dir)
            asm_file = resolve_source_file(modifier_stem, "asm", self._bp_dir, self._asm_dir)
            meta_entry["bp_path"] = str(bp) if bp else None
            meta_entry["asm_file"] = str(asm_file) if asm_file else None
            self._update_dep_var_map(modifier_stem, payload.get("setter_site_traces") or [])

        self._s["file_meta"][modifier_stem] = meta_entry

        # Build cross_file_calls_out (ASM only)
        cross_file_calls_out: List[Dict[str, Any]] = []
        if modifier_type != "cpp":
            _bp_p = Path(meta_entry["bp_path"]) if meta_entry.get("bp_path") else None
            _asm_f = Path(meta_entry["asm_file"]) if meta_entry.get("asm_file") else None
            if _bp_p and _bp_p.exists() and _asm_f:
                _bp_data = load_json(_bp_p)
                _scope: Set[str] = set()
                _bp_path_str = str(_bp_p)
                for _b in anchor_blocks:
                    _scope.update(backward_reachable_blocks(
                        _bp_data, _b,
                        expand_subroutine_callers=True,
                        bp_path=_bp_path_str,
                    ))
                if not _scope:
                    _scope = {str(b["id"]) for b in _bp_data.get("blocks", [])}
                cross_file_calls_out = _collect_scoped_cross_file_calls(
                    _bp_data, _scope, _asm_f, self._asm_dir, bp_path=_bp_p
                )

        if modifier_type == "cpp":
            phase_meta: Dict[str, Any] = {
                "asm_field_aliases": payload.get("asm_field_aliases") or {},
                "cpp_lineage_trace": payload.get("cpp_lineage_trace") or {},
            }
        else:
            phase_meta = {
                "setter_sites": payload.get("setter_sites") or [],
                "setter_site_traces": payload.get("setter_site_traces") or [],
                "subroutine_summary": payload.get("subroutine_summary"),
            }

        setter_count = len(payload.get("setter_sites") or [])
        _tuple_meta: Dict[str, Any] = {
            "bp_path": meta_entry.get("bp_path"),
            "asm_file": meta_entry.get("asm_file"),
            "anchor_blocks": anchor_blocks,
            "scope_label": None,
            "summary": (
                f"Modifier file {modifier_stem} — "
                f"{setter_count} setter site(s) for {self._root_variable}"
            ),
            "phase_metadata": phase_meta,
            "intra_tuple_edges": (payload.get("call_graph") or {}).get("edges") or [],
            "cross_file_calls_out": cross_file_calls_out,
        }

        # C++ payloads: use the enriched call_graph (function-level nodes with
        # relevant_code_lines + conditions) built by _build_cpp_cg_nodes.
        # Fall back to cpp_lineage_trace nodes only when call_graph is empty
        # (e.g. older sessions or blueprint-not-found paths).
        if modifier_type == "cpp":
            enriched_cg = payload.get("call_graph") or {}
            enriched_nodes = enriched_cg.get("nodes") or []
            if enriched_nodes:
                effective_call_graph = enriched_cg
            else:
                cpp_tr = payload.get("cpp_lineage_trace") or {}
                effective_call_graph = {
                    "nodes": cpp_tr.get("nodes") or [],
                    "edges": cpp_tr.get("edges") or [],
                }
        else:
            effective_call_graph = payload.get("call_graph") or {}

        self._append_nodes(
            effective_call_graph,
            modifier_stem, modifier_type,
            self._root_variable, "modifier",
            session_dir,
            tuple_metadata=_tuple_meta,
        )

    def _process_upstream_file(
        self,
        caller: str,
        callee: str,
        edge_instr: str,
        caller_type: str,
        callee_type: str,
        caller_var: str,
        session_dir: Path,
    ) -> None:
        opts = self._options
        if caller_type == "cpp":
            payload = _build_cpp_upstream_payload(
                caller=caller,
                callee=callee,
                callee_type=callee_type,
                edge_instruction=edge_instr,
                blueprint_dir=self._bp_dir,
                asm_dir=self._asm_dir,
                variable=caller_var,
            )
        else:
            payload = _build_asm_upstream_payload(
                variable=caller_var,
                caller=caller,
                callee=callee,
                callee_type=callee_type,
                edge_instruction=edge_instr,
                blueprint_dir=self._bp_dir,
                asm_dir=self._asm_dir,
                max_depth=(int(opts["max_depth"]) if opts.get("max_depth") is not None else 8),
                max_subroutine_depth=(int(opts["max_subroutine_depth"]) if opts.get("max_subroutine_depth") is not None else DEFAULT_MAX_SUBROUTINE_DEPTH),
                max_subroutine_nodes=(int(opts["max_subroutine_nodes"]) if opts.get("max_subroutine_nodes") is not None else DEFAULT_MAX_SUBROUTINE_NODES),
                max_trace_nodes=(int(opts["max_trace_nodes"]) if opts.get("max_trace_nodes") is not None else DEFAULT_MAX_TRACE_NODES),
            )
        if payload.get("warnings"):
            self._s["warnings"].extend(payload["warnings"])

        anchor_blocks = [
            str(s.get("routine") or s.get("function") or "")
            for s in (payload.get("call_sites") or [])
            if s.get("routine") or s.get("function")
        ]
        _abl_up: Dict[str, int] = {}
        for _s in (payload.get("setter_sites") or payload.get("call_sites") or []):
            _k = str(_s.get("routine") or _s.get("function") or "")
            _l = int(_s.get("line") or 0)
            if _k and _l > 0:
                _abl_up[_k] = min(_abl_up.get(_k, _l), _l)

        meta_entry: Dict[str, Any] = {
            "anchor_blocks": anchor_blocks,
            "anchor_before_lines": _abl_up,
            "file_type": caller_type,
        }

        if caller_type == "cpp":
            # T2: store C++ blueprint path and dep_vars for Pass 2
            cpp_bp_p = resolve_cpp_blueprint(caller, self._bp_dir)
            meta_entry["bp_path"] = None
            meta_entry["asm_file"] = None
            meta_entry["cpp_bp_path"] = str(cpp_bp_p) if cpp_bp_p else None
            meta_entry["cpp_lineage_trace"] = payload.get("cpp_lineage_trace") or {}
            self._update_dep_var_map_cpp(caller, payload.get("cpp_lineage_trace") or {})
        else:
            bp = resolve_asm_blueprint(caller, self._bp_dir)
            asm_file = resolve_source_file(caller, "asm", self._bp_dir, self._asm_dir)
            meta_entry["bp_path"] = str(bp) if bp else None
            meta_entry["asm_file"] = str(asm_file) if asm_file else None
            trace_results = payload.get("call_site_traces") or payload.get("setter_site_traces") or []
            self._update_dep_var_map(caller, trace_results)

        self._s["file_meta"][caller] = meta_entry

        # Build cross_file_calls_out (ASM callers only)
        cross_file_calls_out_up: List[Dict[str, Any]] = []
        if caller_type != "cpp":
            _bp_p_up = Path(meta_entry["bp_path"]) if meta_entry.get("bp_path") else None
            _asm_f_up = Path(meta_entry["asm_file"]) if meta_entry.get("asm_file") else None
            if _bp_p_up and _bp_p_up.exists() and _asm_f_up:
                _bp_data_up = load_json(_bp_p_up)
                _scope_up: Set[str] = set()
                _bp_path_str_up = str(_bp_p_up)
                for _b_up in anchor_blocks:
                    _scope_up.update(backward_reachable_blocks(
                        _bp_data_up, _b_up,
                        expand_subroutine_callers=True,
                        bp_path=_bp_path_str_up,
                    ))
                if not _scope_up:
                    _scope_up = {str(b["id"]) for b in _bp_data_up.get("blocks", [])}
                cross_file_calls_out_up = _collect_scoped_cross_file_calls(
                    _bp_data_up, _scope_up, _asm_f_up, self._asm_dir, bp_path=_bp_p_up
                )

        if caller_type == "cpp":
            if callee_type == "cpp":
                _up_phase_meta: Dict[str, Any] = {
                    "caller": caller, "callee": callee,
                    "caller_var": caller_var, "edge_instruction": edge_instr,
                    "caller_type": caller_type, "callee_type": callee_type,
                    "call_pairs": payload.get("call_pairs") or [],
                }
            else:
                _up_phase_meta = {
                    "caller": caller, "callee": callee,
                    "caller_var": caller_var, "edge_instruction": edge_instr,
                    "caller_type": caller_type, "callee_type": callee_type,
                    "call_sites": payload.get("call_sites") or [],
                    "asm_field_aliases": payload.get("asm_field_aliases") or {},
                    "tpf_regs_slots": payload.get("tpf_regs_slots") or {},
                }
                if payload.get("cpp_lineage_trace"):
                    _up_phase_meta["cpp_lineage_trace"] = payload["cpp_lineage_trace"]
        else:
            _up_phase_meta = {
                "caller": caller, "callee": callee,
                "caller_var": caller_var, "edge_instruction": edge_instr,
                "caller_type": caller_type, "callee_type": callee_type,
                "call_sites": payload.get("call_sites") or [],
                "call_site_traces": payload.get("call_site_traces") or [],
                "subroutine_summary": payload.get("subroutine_summary"),
            }

        _up_tuple_meta: Dict[str, Any] = {
            "bp_path": meta_entry.get("bp_path"),
            "asm_file": meta_entry.get("asm_file"),
            "anchor_blocks": anchor_blocks,
            "scope_label": None,
            "summary": (
                f"Upstream {'C++' if caller_type == 'cpp' else 'ASM'} caller "
                f"{caller} → {callee} for {caller_var}"
            ),
            "phase_metadata": _up_phase_meta,
            "intra_tuple_edges": (payload.get("call_graph") or {}).get("edges") or [],
            "cross_file_calls_out": cross_file_calls_out_up,
        }

        self._append_nodes(
            payload.get("call_graph") or {},
            caller, caller_type,
            caller_var, "upstream",
            session_dir,
            tuple_metadata=_up_tuple_meta,
        )

    # ------------------------------------------------------------------
    # PASS1B processor
    # ------------------------------------------------------------------

    def _process_root_var_downstream(
        self,
        ds_stem: str,
        ds_depth: int,
        source_stem: str,
        source_var: str,
        path_to_source: List[str],
        session_dir: Path,
    ) -> None:
        opts = self._options
        max_downstream_depth = (int(opts["max_downstream_depth"]) if opts.get("max_downstream_depth") is not None else DEFAULT_MAX_DOWNSTREAM_DEPTH)
        max_downstream_files = (int(opts["max_downstream_files"]) if opts.get("max_downstream_files") is not None else DEFAULT_MAX_DOWNSTREAM_FILES)
        rv_visited: Set[str] = set(self._s["rv_visited_downstream"])
        exclude_stems = {s.lower() for s in self._selected_chain}

        if ds_stem in rv_visited or ds_stem in exclude_stems:
            return
        if len(rv_visited) >= max_downstream_files:
            self._s["warnings"].append(
                f"root_var downstream: max_downstream_files={max_downstream_files} cap reached"
            )
            return
        if ds_depth >= max_downstream_depth:
            self._s["rv_visited_downstream"].append(ds_stem)
            self._s["warnings"].append(f"root_var downstream: depth cap for {ds_stem}")
            return

        bp_ds = resolve_asm_blueprint(ds_stem, self._bp_dir)
        asm_ds = resolve_source_file(ds_stem, "asm", self._bp_dir, self._asm_dir)
        if not bp_ds or not asm_ds:
            return

        self._s["rv_visited_downstream"].append(ds_stem)
        rv_visited.add(ds_stem)
        bp_data_ds = load_json(bp_ds)
        all_blocks: Set[str] = {str(b["id"]) for b in bp_data_ds.get("blocks", [])}

        ds_cross = _collect_scoped_cross_file_calls(
            bp_data_ds, all_blocks, asm_ds, self._asm_dir, bp_path=bp_ds
        )
        ds_returning = [cf for cf in ds_cross if _is_followable_cross_file_call(cf)]

        ff = _ff_from_serial(self._s["full_flow_serial"])
        file_type_map = self._s["file_type_map"]
        selected_chain_set = set(self._s["selected_chain_set"])
        for cf in ds_returning:
            _add_full_flow_edge(
                ff,
                source=ds_stem,
                target=str(cf.get("target_file") or ""),
                blueprint_dir=self._bp_dir,
                file_type_map=file_type_map,
                selected_chain_set=selected_chain_set,
                scope_var=self._root_variable,
                instruction=str(cf.get("instruction") or ""),
                discovered_from="root_var_downstream_scope",
                source_block=str(cf.get("source_block") or ""),
                line_no=cf.get("line"),
            )
        self._s["full_flow_serial"] = _ff_to_serial(ff)

        ds_root_var = self._resolver.resolve(source_var, ds_stem, source_stem=source_stem) or source_var

        result = _build_dep_var_file_result(
            ds_root_var, bp_data_ds, bp_ds, asm_ds, all_blocks, "full_file",
            self._asm_dir,
            (int(opts["max_depth"]) if opts.get("max_depth") is not None else 8),
            (int(opts["max_subroutine_depth"]) if opts.get("max_subroutine_depth") is not None else DEFAULT_MAX_SUBROUTINE_DEPTH),
            (int(opts["max_subroutine_nodes"]) if opts.get("max_subroutine_nodes") is not None else DEFAULT_MAX_SUBROUTINE_NODES),
            (int(opts["max_trace_nodes"]) if opts.get("max_trace_nodes") is not None else DEFAULT_MAX_TRACE_NODES),
        )
        if result.get("warnings"):
            self._s["warnings"].extend(result["warnings"])

        self._update_dep_var_map(ds_stem, result.get("setter_site_traces") or [])

        _rv_anchor_blocks = [
            str(s.get("routine") or "")
            for s in (result.get("setter_sites") or [])
            if s.get("routine")
        ]
        _rv_tuple_meta: Dict[str, Any] = {
            "bp_path": str(bp_ds),
            "asm_file": str(asm_ds),
            "anchor_blocks": _rv_anchor_blocks,
            "scope_label": "full_file",
            "summary": (
                f"Root var downstream {ds_stem} for {ds_root_var} (depth {ds_depth})"
            ),
            "phase_metadata": {
                "source_stem": source_stem,
                "source_var": source_var,
                "ds_root_var": ds_root_var,
                "depth": ds_depth,
                "path_to_source": list(path_to_source),
                "scope_label": "full_file",
                "setter_sites": result.get("setter_sites") or [],
                "setter_site_traces": result.get("setter_site_traces") or [],
                "subroutine_summary": result.get("subroutine_summary"),
            },
            "intra_tuple_edges": (result.get("call_graph") or {}).get("edges") or [],
            "cross_file_calls_out": list(ds_cross),
        }

        self._append_nodes(
            result.get("call_graph") or {},
            ds_stem, "asm",
            ds_root_var, "root_var_downstream",
            session_dir,
            tuple_metadata=_rv_tuple_meta,
        )

        # Enqueue further downstream, deduplicating via rv_visited
        ds_exclude = exclude_stems | rv_visited
        for cf in ds_returning:
            target = cf["target_file"]
            if target and target not in ds_exclude:
                ds_exclude.add(target)
                self._s["work_queue"].append([
                    "root_var_downstream", target, ds_depth + 1,
                    ds_stem, ds_root_var, path_to_source + [ds_stem],
                ])

    # ------------------------------------------------------------------
    # PASS2B processor
    # ------------------------------------------------------------------

    def _process_dep_var(self, dep_var: str, depth: int, session_dir: Path) -> None:
        opts = self._options
        max_dep_vars = (int(opts["max_dep_vars"]) if opts.get("max_dep_vars") is not None else DEFAULT_MAX_DEP_VARS)
        max_dep_var_depth = (int(opts["max_dep_var_depth"]) if opts.get("max_dep_var_depth") is not None else DEFAULT_MAX_DEP_VAR_DEPTH)
        max_downstream_depth = (int(opts["max_downstream_depth"]) if opts.get("max_downstream_depth") is not None else DEFAULT_MAX_DOWNSTREAM_DEPTH)
        max_downstream_files = (int(opts["max_downstream_files"]) if opts.get("max_downstream_files") is not None else DEFAULT_MAX_DOWNSTREAM_FILES)

        visited_dv: Set[str] = set(self._s["visited_dep_vars"])
        if dep_var in visited_dv:
            return
        if len(visited_dv) >= max_dep_vars:
            self._s["warnings"].append(
                f"max_dep_vars={max_dep_vars} cap reached; remaining dep_vars skipped"
            )
            return
        if depth >= max_dep_var_depth:
            self._s["warnings"].append(
                f"dep_var {dep_var} skipped — max_dep_var_depth={max_dep_var_depth} reached"
            )
            return

        self._s["visited_dep_vars"].append(dep_var)
        visited_dv.add(dep_var)

        selected_chain = self._selected_chain
        dep_var_collection_map = self._s["dep_var_collection_map"]
        exclude_stems = {s.lower() for s in selected_chain}
        ff = _ff_from_serial(self._s["full_flow_serial"])
        file_type_map = self._s["file_type_map"]
        selected_chain_set = set(self._s["selected_chain_set"])

        # Reconstruct sets-based view for dep_var_origin_chain
        dvcm_sets: Dict[str, Dict[str, Set[str]]] = {
            dv: {s: set(blks) for s, blks in mapping.items()}
            for dv, mapping in dep_var_collection_map.items()
        }

        chain_file_results: Dict[str, Any] = {}
        downstream_targets: Dict[str, Tuple[str, str]] = {}

        for stem in selected_chain:
            meta = self._s["file_meta"].get(stem)
            if not meta:
                continue

            # T3 / GAP A: C++ branch — replaces the blanket "not bp_path" skip
            if meta.get("file_type") == "cpp":
                cpp_bp_str = meta.get("cpp_bp_path")
                if not cpp_bp_str:
                    continue
                cpp_bp_p = Path(cpp_bp_str)
                if not cpp_bp_p.exists():
                    continue
                cpp_bp = load_json(cpp_bp_p)
                from backward_traversal.utils.lazy_gvl import make_lazy_gvl as _mkgvl
                cpp_gvl = _mkgvl(cpp_bp)
                # GAP-032 / FIX 19: find the immediately preceding stem for name
                # translation.  Earlier code only looked at C++ predecessors, which
                # misses the ASM→C++ call-chain boundary where the dep_var name may
                # need arg_bind / struct-canonical resolution.  Use the nearest
                # predecessor of any file type, matching the runner's behaviour.
                _stem_idx = selected_chain.index(stem) if stem in selected_chain else -1
                _source_stem: Optional[str] = (
                    selected_chain[_stem_idx - 1] if _stem_idx > 0 else None
                )
                cpp_result = _build_dep_var_cpp_result(
                    dep_var,
                    cpp_gvl,
                    resolver=self._resolver,
                    stem=stem,
                    source_stem=_source_stem,
                )
                if cpp_result.get("warnings"):
                    self._s["warnings"].extend(cpp_result["warnings"])
                chain_file_results[stem] = cpp_result
                _cpp_dv_tuple_meta: Dict[str, Any] = {
                    "bp_path": None,
                    "asm_file": None,
                    "anchor_blocks": [],
                    "scope_label": None,
                    "summary": f"C++ dep var {dep_var} in chain file {stem}",
                    "phase_metadata": {
                        "dep_var": dep_var,
                        "file_type": "cpp",
                        "lineage_trace": cpp_result.get("lineage_trace"),
                        "depth": depth,
                    },
                    "intra_tuple_edges": (cpp_result.get("call_graph") or {}).get("edges") or [],
                    "cross_file_calls_out": [],
                }
                self._append_nodes(
                    cpp_result.get("call_graph") or {},
                    stem, "cpp",
                    dep_var, "dep_var_chain",
                    session_dir,
                    tuple_metadata=_cpp_dv_tuple_meta,
                )

                # T8: when chain C++ file has no seeds and T8 is enabled, search
                # nearby C++ files outside the selected chain.  Triggered at most
                # once per dep_var per _process_dep_var call.
                _t8_max_scan = int((self._options.get("t8_max_scan") or 0))
                if not cpp_result.get("lineage_trace") and _t8_max_scan > 0:
                    # T9: build neighbor_set once per session object (cached transient).
                    if not self._t8_neighbor_set_built:
                        self._t8_neighbor_set_built = True
                        _cg_for_t9 = self._bp_dir / "file_call_graph.json"
                        self._t8_neighbor_set = build_chain_neighbor_set(
                            selected_chain, _cg_for_t9
                        )
                    _ext_stems = find_cpp_files_for_dep_var(
                        dep_var, self._bp_dir, file_type_map,
                        max_scan=_t8_max_scan,
                        neighbor_set=self._t8_neighbor_set,
                    )
                    for _ext_stem in _ext_stems:
                        if _ext_stem in chain_file_results:
                            continue
                        _ext_bp_path = resolve_cpp_blueprint(_ext_stem, self._bp_dir)
                        if not _ext_bp_path:
                            continue
                        try:
                            _ext_bp = load_json(Path(_ext_bp_path))
                        except Exception:
                            continue
                        from backward_traversal.utils.lazy_gvl import make_lazy_gvl as _mkgvl2
                        _ext_gvl = _mkgvl2(_ext_bp)
                        _ext_result = _build_dep_var_cpp_result(
                            dep_var, _ext_gvl,
                            resolver=self._resolver, stem=_ext_stem, source_stem=stem,
                        )
                        if _ext_result.get("lineage_trace"):
                            if _ext_result.get("warnings"):
                                self._s["warnings"].extend(_ext_result["warnings"])
                            _ext_tuple_meta: Dict[str, Any] = {
                                "bp_path": None,
                                "asm_file": None,
                                "anchor_blocks": [],
                                "scope_label": None,
                                "summary": (
                                    f"C++ dep var extended {dep_var} "
                                    f"in cross-chain file {_ext_stem}"
                                ),
                                "phase_metadata": {
                                    "dep_var": dep_var,
                                    "file_type": "cpp",
                                    "lineage_trace": _ext_result.get("lineage_trace"),
                                    "depth": depth,
                                },
                                "intra_tuple_edges": (
                                    _ext_result.get("call_graph") or {}
                                ).get("edges") or [],
                                "cross_file_calls_out": [],
                            }
                            self._append_nodes(
                                _ext_result.get("call_graph") or {},
                                _ext_stem, "cpp",
                                dep_var, "cpp_dep_var_extended",
                                session_dir,
                                tuple_metadata=_ext_tuple_meta,
                            )

                continue  # skip ASM path below

            # Existing ASM path — guard now explicit after C++ was routed above  (GAP A)
            bp_path_str = meta.get("bp_path")
            asm_file_str = meta.get("asm_file")
            if not bp_path_str or not asm_file_str:
                continue
            bp_path = Path(bp_path_str)
            if not bp_path.exists():
                continue

            bp_data = load_json(bp_path)
            collection_blocks: Set[str] = set(
                dep_var_collection_map.get(dep_var, {}).get(stem) or []
            )
            anchor_blocks: Set[str] = set(meta.get("anchor_blocks") or [])
            anchor_before_lines = meta.get("anchor_before_lines") or {}
            scope_line_caps: Dict[str, int] = {}

            _p2_bp_path = str(bp_path) if bp_path else None
            if collection_blocks:
                scope_blocks: Set[str] = set()
                # GAP-020: use only collection_blocks as the scope seed.
                # Unioning with anchor_blocks (root-var anchors) pollutes the
                # dep_var scope with irrelevant predecessor paths from the root
                # variable's collection sites, producing spurious setter matches.
                for b in collection_blocks:
                    before_line = anchor_before_lines.get(b, 0) or 0
                    scope_blocks.update(backward_reachable_blocks(
                        bp_data, b,
                        before_line=before_line,    # NEW
                        expand_subroutine_callers=True,
                        bp_path=_p2_bp_path,
                    ))
                    if before_line:
                        scope_line_caps[b] = before_line   # NEW
                scope_label = "collection_based"
            elif anchor_blocks:
                scope_blocks = set()
                for b in anchor_blocks:
                    before_line = anchor_before_lines.get(b, 0) or 0
                    scope_blocks.update(backward_reachable_blocks(
                        bp_data, b,
                        before_line=before_line,    # NEW
                        expand_subroutine_callers=True,
                        bp_path=_p2_bp_path,
                    ))
                    if before_line:
                        scope_line_caps[b] = before_line   # NEW
                scope_label = "anchor_based"
            else:
                scope_blocks = {str(b["id"]) for b in bp_data.get("blocks", [])}
                scope_label = "full_file"
                self._s["warnings"].append(
                    f"dep_var {dep_var} in {stem}: no anchor_blocks found — using full_file scope"
                )

            scoped_cross = _collect_scoped_cross_file_calls(
                bp_data, scope_blocks, Path(asm_file_str), self._asm_dir, bp_path=bp_path
            )
            returning_cross = [cf for cf in scoped_cross if _is_followable_cross_file_call(cf)]
            for cf in returning_cross:
                _add_full_flow_edge(
                    ff,
                    source=stem,
                    target=str(cf.get("target_file") or ""),
                    blueprint_dir=self._bp_dir,
                    file_type_map=file_type_map,
                    selected_chain_set=selected_chain_set,
                    scope_var=dep_var,
                    instruction=str(cf.get("instruction") or ""),
                    discovered_from="dep_var_scope",
                    source_block=str(cf.get("source_block") or ""),
                    line_no=cf.get("line"),
                )
                tgt = cf["target_file"]
                if tgt and tgt not in exclude_stems and tgt not in downstream_targets:
                    downstream_targets[tgt] = (stem, dep_var)

            _di_chain = _dep_var_origin_chain(dep_var, stem, selected_chain, dvcm_sets)
            _chain_stem_idx = selected_chain.index(stem) if stem in selected_chain else -1
            _prev_chain_stem: Optional[str] = selected_chain[_chain_stem_idx - 1] if _chain_stem_idx > 0 else None
            chain_Di = (self._resolver.resolve(dep_var, stem, source_stem=_prev_chain_stem) if not collection_blocks else None) or dep_var

            result = _build_dep_var_file_result(
                chain_Di, bp_data, bp_path, Path(asm_file_str), scope_blocks, scope_label,
                self._asm_dir,
                (int(opts["max_depth"]) if opts.get("max_depth") is not None else 8),
                (int(opts["max_subroutine_depth"]) if opts.get("max_subroutine_depth") is not None else DEFAULT_MAX_SUBROUTINE_DEPTH),
                (int(opts["max_subroutine_nodes"]) if opts.get("max_subroutine_nodes") is not None else DEFAULT_MAX_SUBROUTINE_NODES),
                (int(opts["max_trace_nodes"]) if opts.get("max_trace_nodes") is not None else DEFAULT_MAX_TRACE_NODES),
                scope_line_caps=scope_line_caps,  # NEW
            )
            if result.get("warnings"):
                self._s["warnings"].extend(result["warnings"])
            chain_file_results[stem] = result
            _asm_dv_tuple_meta: Dict[str, Any] = {
                "bp_path": str(bp_path),
                "asm_file": asm_file_str,
                "anchor_blocks": sorted(anchor_blocks),
                "scope_label": scope_label,
                "summary": f"Dep var {chain_Di} in chain file {stem} (depth {depth})",
                "phase_metadata": {
                    "dep_var": dep_var,
                    "dep_var_resolved": chain_Di,
                    "origin_chain": _di_chain,
                    "collection_blocks": sorted(collection_blocks),
                    "scope_label": scope_label,
                    "depth": depth,
                    "setter_sites": result.get("setter_sites") or [],
                    "setter_site_traces": result.get("setter_site_traces") or [],
                    "subroutine_summary": result.get("subroutine_summary"),
                },
                "intra_tuple_edges": (result.get("call_graph") or {}).get("edges") or [],
                "cross_file_calls_out": list(scoped_cross),
            }
            self._append_nodes(
                result.get("call_graph") or {},
                stem, "asm",
                chain_Di, "dep_var_chain",
                session_dir,
                tuple_metadata=_asm_dv_tuple_meta,
            )

        # Downstream BFS for this dep_var
        downstream_file_results: Dict[str, Any] = {}
        visited_downstream: Set[str] = set()
        ds_queue: deque = deque(
            (s, 0, src_stem, src_var, _path_to_chain_file(src_stem, selected_chain))
            for s, (src_stem, src_var) in sorted(downstream_targets.items())
        )

        while ds_queue:
            ds_stem, ds_depth, ds_source_stem, ds_source_var, path_to_source = ds_queue.popleft()
            if ds_stem in visited_downstream or ds_stem in exclude_stems:
                continue
            if len(visited_downstream) >= max_downstream_files:
                self._s["warnings"].append(
                    f"dep_var {dep_var}: max_downstream_files={max_downstream_files} cap reached"
                )
                break
            if ds_depth >= max_downstream_depth:
                visited_downstream.add(ds_stem)
                self._s["warnings"].append(f"dep_var {dep_var}: downstream depth cap for {ds_stem}")
                continue

            bp_ds = resolve_asm_blueprint(ds_stem, self._bp_dir)
            asm_ds = resolve_source_file(ds_stem, "asm", self._bp_dir, self._asm_dir)
            if not bp_ds or not asm_ds:
                continue

            visited_downstream.add(ds_stem)
            bp_data_ds = load_json(bp_ds)
            all_blocks_ds: Set[str] = {str(b["id"]) for b in bp_data_ds.get("blocks", [])}

            # GAP-028: when collection_blocks are already known for this dep_var in
            # this downstream file (from a prior BFS pass), use them as scope seeds
            # instead of full-file scope.  Using all_blocks produces scope explosion
            # proportional to file size; collection_blocks anchors the trace to
            # the blocks that actually write or use the dep_var.
            _ds_p2_bp_path = str(bp_ds)
            _ds_coll_blocks = dep_var_collection_map.get(dep_var, {}).get(ds_stem, set())
            if _ds_coll_blocks:
                _ds_scope_blocks: Set[str] = set()
                for _b in _ds_coll_blocks:
                    _ds_scope_blocks.update(backward_reachable_blocks(
                        bp_data_ds, _b,
                        expand_subroutine_callers=True,
                        bp_path=_ds_p2_bp_path,
                    ))
                _ds_scope_label = "collection_based"
            else:
                # No collection blocks known — restrict to the downstream CSECT's
                # forward-reachable blocks.  Falls back to all_blocks when the
                # entry block is absent from the blueprint.
                _ds_fwd = _forward_reachable_from(_ds_p2_bp_path, {ds_stem.upper()})
                if _ds_fwd is not None:
                    _ds_scope_blocks = _ds_fwd
                    _ds_scope_label = "csect_scoped"
                else:
                    _ds_scope_blocks = all_blocks_ds
                    _ds_scope_label = "full_file"

            # Cross-file call detection always uses full scope so we don't miss
            # downstream call edges that are outside the narrowed scope.
            ds_cross = _collect_scoped_cross_file_calls(
                bp_data_ds, all_blocks_ds, asm_ds, self._asm_dir, bp_path=bp_ds
            )
            ds_returning = [cf for cf in ds_cross if _is_followable_cross_file_call(cf)]
            for cf in ds_returning:
                _add_full_flow_edge(
                    ff,
                    source=ds_stem,
                    target=str(cf.get("target_file") or ""),
                    blueprint_dir=self._bp_dir,
                    file_type_map=file_type_map,
                    selected_chain_set=selected_chain_set,
                    scope_var=dep_var,
                    instruction=str(cf.get("instruction") or ""),
                    discovered_from="dep_var_downstream_scope",
                    source_block=str(cf.get("source_block") or ""),
                    line_no=cf.get("line"),
                )

            ds_Di = self._resolver.resolve(ds_source_var, ds_stem, source_stem=ds_source_stem) or ds_source_var

            ds_result = _build_dep_var_file_result(
                ds_Di, bp_data_ds, bp_ds, asm_ds, _ds_scope_blocks, _ds_scope_label,
                self._asm_dir,
                (int(opts["max_depth"]) if opts.get("max_depth") is not None else 8),
                (int(opts["max_subroutine_depth"]) if opts.get("max_subroutine_depth") is not None else DEFAULT_MAX_SUBROUTINE_DEPTH),
                (int(opts["max_subroutine_nodes"]) if opts.get("max_subroutine_nodes") is not None else DEFAULT_MAX_SUBROUTINE_NODES),
                (int(opts["max_trace_nodes"]) if opts.get("max_trace_nodes") is not None else DEFAULT_MAX_TRACE_NODES),
            )
            if ds_result.get("warnings"):
                self._s["warnings"].extend(ds_result["warnings"])
            downstream_file_results[ds_stem] = ds_result
            _ds_anchor_blocks = [
                str(s.get("routine") or "")
                for s in (ds_result.get("setter_sites") or [])
                if s.get("routine")
            ]
            _ds_tuple_meta: Dict[str, Any] = {
                "bp_path": str(bp_ds),
                "asm_file": str(asm_ds),
                "anchor_blocks": _ds_anchor_blocks,
                "scope_label": _ds_scope_label,
                "summary": f"Dep var downstream {ds_stem} for {dep_var} (depth {ds_depth})",
                "phase_metadata": {
                    "dep_var": dep_var,
                    "dep_var_resolved": ds_Di,
                    "source_stem": ds_source_stem,
                    "source_var": ds_source_var,
                    "depth": ds_depth,
                    "path_to_source": list(path_to_source),
                    "scope_label": _ds_scope_label,
                    "setter_sites": ds_result.get("setter_sites") or [],
                    "setter_site_traces": ds_result.get("setter_site_traces") or [],
                    "subroutine_summary": ds_result.get("subroutine_summary"),
                },
                "intra_tuple_edges": (ds_result.get("call_graph") or {}).get("edges") or [],
                "cross_file_calls_out": list(ds_cross),
            }
            self._append_nodes(
                ds_result.get("call_graph") or {},
                ds_stem, "asm",
                ds_Di, "dep_var_downstream",
                session_dir,
                tuple_metadata=_ds_tuple_meta,
            )

            ds_exclude = exclude_stems | visited_downstream
            for s in sorted({
                cf["target_file"]
                for cf in ds_returning
                if cf["target_file"] and cf["target_file"] not in ds_exclude
            }):
                ds_queue.append((s, ds_depth + 1, ds_stem, ds_Di, path_to_source + [ds_stem]))

        self._s["full_flow_serial"] = _ff_to_serial(ff)

        # Feed next-level dep_vars into BFS
        child_map = _build_child_dep_var_map(chain_file_results, downstream_file_results)
        dvcm = self._s["dep_var_collection_map"]
        # FIX 20: build set of dep_vars already queued to prevent duplicate entries
        _queued_dvs: Set[str] = {
            item[1] for item in self._s.get("work_queue", [])
            if isinstance(item, list) and len(item) > 1 and item[0] == "dep_var"
        }
        for new_dv, file_blocks in child_map.items():
            existing = dvcm.setdefault(new_dv, {})
            for fstem, blocks in file_blocks.items():
                if fstem in existing:
                    existing[fstem] = sorted(set(existing[fstem]) | blocks)
                else:
                    existing[fstem] = sorted(blocks)
            if new_dv not in visited_dv and new_dv not in _queued_dvs:  # FIX 20
                _queued_dvs.add(new_dv)
                self._s["work_queue"].append(["dep_var", new_dv, depth + 1])

    # ------------------------------------------------------------------
    # Tuple assembly
    # ------------------------------------------------------------------

    def assemble_tuple(
        self,
        tuple_index: int,
        session_dir: Path,
    ) -> Optional[Dict[str, Any]]:
        """Return the full tuple dict for tuple_index, or None if out of range."""
        tim = self._s.get("tuple_index_map") or []
        if tuple_index >= len(tim):
            return None
        entry = tim[tuple_index]

        chunk_path = session_dir / entry["chunk_file"]
        if not chunk_path.exists():
            # compress_outputs() may have compressed chunk_N.json → chunk_N.msgpack.gz
            # (e.g. when /backward-lineage/scoped runs in the same output directory).
            gz_path = chunk_path.with_suffix(".msgpack.gz")
            if gz_path.exists():
                import gzip as _gzip
                import msgpack as _msgpack  # type: ignore[import]
                with _gzip.open(gz_path, "rb") as _fh:
                    chunk_data = _msgpack.unpackb(_fh.read(), raw=False)
            else:
                raise FileNotFoundError(
                    f"Chunk file '{entry['chunk_file']}' missing from session dir; "
                    f"restart with start_tuple_index=0"
                )
        else:
            chunk_data = json.loads(chunk_path.read_text(encoding="utf-8"))

        # Deserialize full_flow_edges for this file from accumulated session state
        file_stem = entry["file_stem"]
        ff_data = _ff_from_serial(self._s.get("full_flow_serial") or {})
        full_flow_edges = [
            {
                "source": e["source"],
                "target": e["target"],
                "instructions": sorted(e.get("instructions") or []),
                "scope_variables": sorted(e.get("scope_variables") or []),
                "discovered_from": sorted(e.get("discovered_from") or []),
                "source_blocks": sorted(e.get("source_blocks") or []),
                "lines": sorted(int(l) for l in (e.get("lines") or []) if l),
            }
            for (src, tgt), e in ff_data.get("edges", {}).items()
            if src == file_stem or tgt == file_stem
        ]

        metadata = chunk_data.get("metadata") or {}
        return {
            "file_stem": file_stem,
            "file_type": entry["file_type"],
            "variable": entry["variable"],
            "phase": entry["phase"],
            "bp_path": metadata.get("bp_path"),
            "asm_file": metadata.get("asm_file"),
            "anchor_blocks": metadata.get("anchor_blocks") or [],
            "scope_label": metadata.get("scope_label"),
            "summary": metadata.get("summary") or "",
            "phase_metadata": metadata.get("phase_metadata") or {},
            "intra_tuple_edges": metadata.get("intra_tuple_edges") or [],
            "cross_file_calls_out": metadata.get("cross_file_calls_out") or [],
            "full_flow_edges": full_flow_edges,
            "node_count": entry["node_count"],
            "nodes": chunk_data.get("nodes") or [],
        }

    def get_finalized_full_flow(self) -> Dict[str, Any]:
        ff = _ff_from_serial(self._s["full_flow_serial"])
        result = _finalize_full_flow_collector(ff)

        # Embed terminal_classifications inside the full_file_flow dict so the
        # typed BackwardLineageFileGraphResponse (full_file_flow: Dict[str,Any])
        # passes it through to clients without a schema change.
        try:
            from backward_traversal.enrichment.terminal_classifier import (
                classify_terminal_variables,
            )
            dvcm = self._s.get("dep_var_collection_map") or {}
            all_dep_vars = [(dv, "asm", None, None) for dv in sorted(dvcm.keys())]
            if all_dep_vars:
                bp_dir = Path(str(self._s.get("blueprint_dir") or ""))
                asm_dir_str = self._s.get("asm_dir")
                asm_dir = Path(asm_dir_str) if asm_dir_str else None
                from backward_traversal.utils.blueprint_utils import discover_graph_file
                gf = discover_graph_file(bp_dir)
                if bp_dir.exists() and gf:
                    tc = classify_terminal_variables(
                        all_dep_vars, bp_dir, asm_dir, gf, use_llm=False
                    )
                    if tc:
                        result["terminal_classifications"] = tc
        except Exception as _e:
            logger.debug("get_finalized_full_flow terminal classification failed: %s", _e)

        return result
