"""Function-level reachability for the chainless caller walk.

A file-level caller edge (file *X* calls file *F*) only means the setter in *F*
is reachable from *X* if *X*'s call lands in a function of *F* that can
transitively reach the setter's **enclosing function** through *F*'s intra-file
call graph.  Without this check the caller list includes files that enter *F*
through an unrelated entry point and never execute the setter (e.g. a caller
that reaches ``processAPostAuthorization`` when the setter lives in
``processACreditTransaction``).

This module supplies the pieces the caller walk needs to prune those paths:

* ``setter_anchor_functions`` — the set of functions in the setter's file that
  transitively reach the setter's enclosing function (the valid entry set).
* ``child_anchor_functions`` — same, one hop up: the functions in a caller file
  that reach the call sites which were kept on the path down.
* ``filter_sites_by_reach`` — keep only call sites whose **target function** is
  in the anchor set.

Soundness rules (we only prune what we can *prove* unreachable):

* Filtering applies only when the callee file is **C++** (an ASM module is
  reached at a single entry, so the file-level edge is already function-level).
* If a call site's target function cannot be resolved (e.g. an ASM target, a
  register-indirect call), the site is **kept and flagged** ``reach_unverified``
  — never silently dropped.
* If a callee file has **no intra-file call graph**, reachability cannot be
  computed, so no filtering happens (``None`` anchor).

All reads are of the blueprint ``call_graph`` (function→function edges) and the
``variable_lineage`` edges; blueprints come through the LRU-cached
``load_json``.
"""

from __future__ import annotations

from collections import defaultdict, deque
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple


# ---------------------------------------------------------------------------
# Blueprint access + intra-file function graph
# ---------------------------------------------------------------------------

# Path-resolution miss cache: remembers stems that have NO blueprint on disk
# so we don't stat the filesystem repeatedly for the same missing file.
# Only stores None sentinels (no data), so RAM is negligible even at 22K stems.
# Thread-safe under the GIL for simple set membership checks.
_bp_miss: Set[str] = set()


def _load_bp(stem: str, file_type: str, blueprint_dir: Path) -> Optional[Dict[str, Any]]:
    """Load a blueprint, delegating to the bounded LRU in blueprint_utils.load_json.

    Path resolution (resolve_cpp_blueprint / resolve_asm_blueprint) is cached
    negatively in ``_bp_miss`` so stems with no blueprint on disk don't cause
    repeated filesystem probes.  Actual blueprint data lives ONLY in the
    ``load_json`` LRU cache (~68 slots, 1 GB budget) — never duplicated here.
    """
    miss_key = f"{stem}|{file_type}|{blueprint_dir}"
    if miss_key in _bp_miss:
        return None
    try:
        from backward_traversal.utils.blueprint_utils import (
            load_json, resolve_asm_blueprint, resolve_cpp_blueprint,
        )
    except Exception:  # pragma: no cover
        _bp_miss.add(miss_key)
        return None
    p = (
        resolve_cpp_blueprint(stem, blueprint_dir)
        if file_type == "cpp"
        else resolve_asm_blueprint(stem, blueprint_dir)
    )
    if not p:
        _bp_miss.add(miss_key)
        return None
    try:
        return load_json(p)
    except Exception:
        _bp_miss.add(miss_key)
        return None


def clear_bp_cache() -> None:
    """Clear the path-resolution miss cache (e.g. between test runs)."""
    _bp_miss.clear()


def _function_names(bp: Dict[str, Any]) -> Set[str]:
    """UPPER set of real function names in a blueprint's call graph."""
    cg = bp.get("call_graph") or {}
    nodes = cg.get("nodes")
    out: Set[str] = set()
    if isinstance(nodes, dict):
        out = {str(k).upper() for k in nodes.keys() if k}
    elif isinstance(nodes, (list, tuple)):
        for n in nodes:
            if isinstance(n, str) and n:
                out.add(n.upper())
            elif isinstance(n, dict):
                nm = n.get("id") or n.get("name")
                if nm:
                    out.add(str(nm).upper())
    return out


def _intrafile_rev_adj(bp: Dict[str, Any]) -> Dict[str, Set[str]]:
    """Reverse adjacency over the file's own call graph: callee→{callers}, UPPER."""
    rev: Dict[str, Set[str]] = defaultdict(set)
    for e in ((bp.get("call_graph") or {}).get("edges") or []):
        s = str(e.get("source") or "")
        t = str(e.get("target") or "").upper()
        if s and t and s.upper() != t:
            rev[t].add(s.upper())
    return rev


def _reverse_reachable(rev: Dict[str, Set[str]], targets: Sequence[str]) -> Set[str]:
    """All functions that transitively reach any target (targets included)."""
    seen: Set[str] = {str(t).upper() for t in targets if t}
    q: deque = deque(seen)
    while q:
        cur = q.popleft()
        for caller in rev.get(cur, ()):
            if caller not in seen:
                seen.add(caller)
                q.append(caller)
    return seen


def _intrafile_fwd_adj(bp: Dict[str, Any]) -> Dict[str, Set[str]]:
    """Forward adjacency over the file's own call graph: caller→{callees}, UPPER."""
    fwd: Dict[str, Set[str]] = defaultdict(set)
    for e in ((bp.get("call_graph") or {}).get("edges") or []):
        s = str(e.get("source") or "").upper()
        t = str(e.get("target") or "").upper()
        if s and t and s != t:
            fwd[s].add(t)
    return fwd


def function_reaches(
    stem: str, file_type: str, from_fn: str, to_fn: str,
    blueprint_dir: Path, cache: Optional[Dict[str, Any]] = None,
) -> bool:
    """Does ``from_fn`` transitively call ``to_fn`` within one file?

    Conservative: returns True when either function is unknown/empty or when the
    file has no intra-file call graph (we don't over-constrain on missing data),
    and for ASM (a module is one entry, so intra-file function granularity does
    not apply).  Forward adjacency is cached per stem.
    """
    if not from_fn or not to_fn:
        return True
    a, b = from_fn.upper(), to_fn.upper()
    if a == b:
        return True
    if file_type != "cpp":
        return True  # ASM module ≈ single entry
    cache = cache if cache is not None else {}
    key = f"fwd::{stem}"
    fwd = cache.get(key)
    if fwd is None:
        bp = _load_bp(stem, "cpp", Path(blueprint_dir))
        fwd = _intrafile_fwd_adj(bp) if bp else {}
        cache[key] = fwd
    if not fwd:
        return True  # no call graph to prove non-reachability
    seen = {a}
    q: deque = deque([a])
    while q:
        cur = q.popleft()
        for nxt in fwd.get(cur, ()):
            if nxt == b:
                return True
            if nxt not in seen:
                seen.add(nxt)
                q.append(nxt)
    return False


def reaches_function_set(stem: str, function: str, blueprint_dir: Path) -> Optional[Set[str]]:
    """Functions in ``stem`` that transitively reach ``function`` (reverse).

    Reused as the walk anchor when the target is a specific C++ function.
    ``None`` when uncomputable (no call graph / function unresolved)."""
    bp = _load_bp(stem, "cpp", Path(blueprint_dir))
    if not bp:
        return None
    rev = _intrafile_rev_adj(bp)
    if not rev or not function:
        return None
    return _reverse_reachable(rev, [function])


# ---------------------------------------------------------------------------
# Enclosing function of a setter site
# ---------------------------------------------------------------------------

def _enclosing_function(bp: Dict[str, Any], line: int, variable: str) -> str:
    """The function that contains the setter at ``line``.

    GVL node ids encode scope as ``<kind>:<function>::<path>``.  We take the
    scoped node ids on the setter line whose ``<function>`` is a real call-graph
    function (this rejects enum/type scopes like ``Dynamic4cscMatchIndicators``),
    preferring the one whose node mentions the setter variable.
    """
    fn_names = _function_names(bp)
    var_l = str(variable or "").lower()
    fallback = ""
    for e in ((bp.get("variable_lineage") or {}).get("edges") or []):
        if e.get("line") != line:
            continue
        for nid in (str(e.get("source") or ""), str(e.get("target") or "")):
            if "::" not in nid:
                continue
            fn = nid.split(":", 1)[-1].split("::")[0]
            if not fn or "/" in fn or "\\" in fn:
                continue
            if fn.upper() in fn_names:
                if var_l and var_l in nid.lower():
                    return fn          # best: a real function whose node holds the var
                fallback = fallback or fn
    return fallback


# ---------------------------------------------------------------------------
# Public API used by the caller walk
# ---------------------------------------------------------------------------

def setter_anchor_functions(root, blueprint_dir: Path) -> Optional[Set[str]]:
    """Functions in the setter's file that reach its enclosing function.

    Returns ``None`` (⇒ no filtering) when the file is ASM, has no intra-file
    call graph, or the enclosing function can't be resolved.
    """
    if getattr(root, "file_type", "") != "cpp":
        return None  # ASM module ≈ single entry; file-level edge is function-level
    bp = _load_bp(root.file_stem, "cpp", Path(blueprint_dir))
    if not bp:
        return None
    rev = _intrafile_rev_adj(bp)
    if not rev:
        return None
    fn = _enclosing_function(bp, int(getattr(root, "line", 0) or 0), getattr(root, "variable", ""))
    if not fn:
        return None
    return _reverse_reachable(rev, [fn])


def child_anchor_functions(
    source_stem: str, source_type: str, kept_sites: List[Dict[str, Any]],
    blueprint_dir: Path,
) -> Optional[Set[str]]:
    """Anchor set for the *caller* file, one hop up.

    The functions in ``source_stem`` that reach the call sites kept on the way
    down (their ``caller_function``).  ``None`` ⇒ next hop is not filtered.
    """
    if source_type != "cpp":
        return None  # an ASM caller file is entered at a single point
    bp = _load_bp(source_stem, "cpp", Path(blueprint_dir))
    if not bp:
        return None
    rev = _intrafile_rev_adj(bp)
    if not rev:
        return None
    caller_fns = {site_caller_fn(s) for s in kept_sites}
    caller_fns.discard("")
    if not caller_fns:
        return None
    return _reverse_reachable(rev, list(caller_fns))


def site_target_fn(site: Dict[str, Any]) -> Optional[str]:
    """The function a call site targets in the callee file, or None if unknown.

    ``callee_function`` (cpp→cpp) / ``cpp_function`` (asm→cpp) name the target
    C++ function.  ASM targets (``target_entry_point`` only) return None — an ASM
    callee is reached at its single entry, so it is not function-filtered.
    """
    v = site.get("callee_function") or site.get("cpp_function")
    return str(v) if v else None


def site_caller_fn(site: Dict[str, Any]) -> str:
    """The function in the caller file that makes the call."""
    return str(
        site.get("caller_function")
        or site.get("function")
        or site.get("routine")
        or ""
    )


def filter_sites_by_reach(
    sites: List[Dict[str, Any]], anchor_fns: Set[str],
) -> Tuple[List[Dict[str, Any]], int]:
    """Keep call sites whose target function reaches the setter.

    A site whose target function is unresolved is kept and flagged
    ``reach_unverified`` (sound: we only drop provably-unreachable targets).
    Returns ``(kept_sites, n_pruned)``.
    """
    au = {str(a).upper() for a in anchor_fns}
    kept: List[Dict[str, Any]] = []
    pruned = 0
    for s in sites:
        tgt = site_target_fn(s)
        if tgt is None:
            s.setdefault("reach_unverified", True)
            kept.append(s)
        elif tgt.upper() in au:
            kept.append(s)
        else:
            pruned += 1
    return kept, pruned
