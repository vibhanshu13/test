"""Scope correctness for the chainless tracer.

The chainless enumerator scans a whole file for setter sites of a variable.
A naive "all blocks" scope risks two unsound outcomes the chain path avoided:

1. **Cross-CSECT leakage** — a file with several entry points / CSECTs would
   match setter sites in an unrelated CSECT.  We bound to the CSECT(s) actually
   containing the anchor blocks, reusing the verified
   ``_csect_forward_reachable`` from ``backward_only_runner``.

2. **DSECT field-name collision** — the same bare field name (e.g. ``COUNT``)
   declared in two unrelated DSECTs.  In ASM the operand text is just the field
   name (resolved at assembly time via ``USING``), so we cannot always pick the
   right DSECT statically.  Rather than silently conflate them, we **detect the
   collision and surface a warning**, keeping both (sound — nothing dropped).
   For C++ the GVL node id carries the enclosing struct, so the collision is
   resolved exactly by the caller via node-id matching.

Also provides ``resolve_or_flag_boundary`` so a cross-file name that fails to
translate surfaces a ``boundary_identity_lost`` warning instead of silently
falling back to the original name.

Pure helpers over already-loaded blueprint dicts — no traversal logic here.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


def _all_block_ids(bp_data: Dict[str, Any]) -> Set[str]:
    return {str(b.get("id") or "") for b in (bp_data.get("blocks") or []) if b.get("id")}


def csect_scoped_blocks(
    bp_path_str: str,
    anchor_blocks: Set[str],
    bp_data: Dict[str, Any],
) -> Tuple[Set[str], List[str]]:
    """Bound a setter search to the CSECT(s) containing ``anchor_blocks``.

    Returns ``(scope_blocks, warnings)``.  Falls back to all blocks with a
    ``scope_ambiguous`` warning when the CFG/CSECT cannot be determined — never
    silently over-matches without flagging.
    """
    warnings: List[str] = []
    all_blocks = _all_block_ids(bp_data)
    if not anchor_blocks:
        return all_blocks, warnings
    try:
        # Lazy import: backward_only_runner is a large module; import on demand
        # and reuse its verified CSECT helper rather than reimplementing it.
        from backward_traversal.runner.backward_only_runner import _csect_forward_reachable
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("csect_scoped_blocks: import failed (%s); using all blocks", exc)
        warnings.append("scope_ambiguous: CSECT helper unavailable; scanned whole file")
        return all_blocks, warnings

    scoped = _csect_forward_reachable(bp_path_str, set(anchor_blocks), all_blocks)
    if not scoped or scoped == all_blocks:
        # _csect_forward_reachable falls back to all_blocks when the CFG can't be
        # loaded; flag that the scope could not be narrowed.
        if scoped == all_blocks and all_blocks:
            warnings.append(
                "scope_ambiguous: could not bound to a CSECT; scanned whole file"
            )
        return all_blocks, warnings
    return scoped, warnings


def dsects_containing_field(bp_data: Dict[str, Any], field: str) -> List[str]:
    """Return the DSECT/struct names whose layout declares ``field`` (upper)."""
    layouts = bp_data.get("dsect_layouts") or {}
    if not isinstance(layouts, dict):
        return []
    needle = str(field or "").upper()
    out: List[str] = []
    for struct_name, members in layouts.items():
        if not isinstance(members, dict):
            continue
        member_names = {str(m).upper() for m in members.keys()}
        if needle in member_names:
            out.append(str(struct_name))
    return out


def dsect_collision_warning(bp_data: Dict[str, Any], field: str) -> Optional[str]:
    """If ``field`` is declared in >1 DSECT, return a warning string, else None.

    The setter sites for the colliding name are kept (sound), but the consumer
    is told the field name is ambiguous across DSECTs so it can disambiguate by
    USING context or surface the ambiguity.
    """
    structs = dsects_containing_field(bp_data, field)
    if len(structs) > 1:
        return f"dsect_collision: '{field}' declared in {sorted(structs)}; setter scope not DSECT-narrowed"
    return None


def cpp_node_in_struct(node_id: str, struct_name: str) -> bool:
    """Whether a C++ GVL node id belongs to ``struct_name`` (exact-ish match).

    C++ node ids carry the enclosing struct/type (e.g.
    ``struct_field:fn::CasGLRec.onlineSrcInd`` or ``...->ce1alasw``), so DSECT
    collision is resolvable for C++ by matching the struct component.
    """
    nid = str(node_id or "").lower()
    s = str(struct_name or "").lower()
    if not s:
        return True
    return f"{s}." in nid or f"{s}::" in nid or f"{s}->" in nid


def resolve_or_flag_boundary(
    resolver: Any,
    variable: str,
    target_stem: str,
    source_stem: Optional[str] = None,
) -> Tuple[str, List[str]]:
    """Translate ``variable`` across a file boundary, surfacing identity loss.

    Returns ``(resolved_name, warnings)``.  When the resolver yields nothing we
    fall back to the original name BUT emit a ``boundary_identity_lost`` warning
    so the silent-fallback gap is visible (closes the identity-loss gap).
    """
    warnings: List[str] = []
    if resolver is None:
        return variable, warnings
    try:
        resolved = resolver.resolve(variable, target_stem, source_stem=source_stem)
    except TypeError:
        # Older resolver signatures without source_stem
        try:
            resolved = resolver.resolve(variable, target_stem)
        except Exception:
            resolved = None
    except Exception:
        resolved = None
    if not resolved:
        warnings.append(
            f"boundary_identity_lost: '{variable}' did not translate into '{target_stem}'"
            f"{f' from {source_stem}' if source_stem else ''}; reusing original name"
        )
        return variable, warnings
    return resolved, warnings
