"""GAP C — the chainless runner: variable in, forest out.

Orchestrates: enumerate all setter roots → for each root INDEPENDENTLY backward-
trace + classify dependent variables (kind + sound value-pruning) + recursively
discover callers + descend into downstream callees → assemble the interned-node
forest (a DAG, shared subtrees collapse by ``node_key``).

Every cap is unlimited-capable (0/None = unlimited).  Pure read of blueprints /
GVL / call-graph (DB-backed when JSONs are deleted); no mutation of shared code.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from backward_traversal.models.chainless_models import (
    CounterpartInfo,
    DepVar,
    ForestOutput,
    ForestRootEntry,
    SetterRoot,
    TraceNode,
)
from backward_traversal.runner import chainless_dep_resolver as DR
from backward_traversal.runner.chainless_caller_walker import (
    build_reverse_adjacency,
    walk_callers,
)
from backward_traversal.runner.chainless_downstream_walker import (
    downstream_files_from_cpp_trace,
    walk_downstream_asm,
)
from backward_traversal.runner.chainless_setter_enumerator import enumerate_setter_roots

logger = logging.getLogger(__name__)


class Budget:
    """Cap helper; 0/None means unlimited."""

    def __init__(self, cap: Optional[int]):
        self.cap = cap or 0
        self.count = 0

    def hit(self) -> bool:
        return bool(self.cap) and self.count >= self.cap

    def inc(self) -> None:
        self.count += 1


def _load_graph_payload(graph_file: Path, job_id: Optional[str]) -> Dict[str, Any]:
    """Load the file call graph; reconstruct from index.db when the JSON is gone."""
    graph_file = Path(graph_file)
    if graph_file.exists():
        try:
            from backward_traversal.utils.blueprint_utils import load_json
            return load_json(graph_file)
        except Exception:
            pass
    if job_id:
        try:
            from api.index_db.readers import get_call_graph
            return get_call_graph(job_id, fallback_path=graph_file if graph_file.exists() else None)
        except Exception as exc:
            logger.debug("graph reconstruction failed: %s", exc)
    return {"nodes": [], "edges": []}


def _global_gvl(blueprint_dir: Path):
    """Load the global C++ GVL once (any cpp blueprint carries the path)."""
    blueprint_dir = Path(blueprint_dir)
    # Fast path: locate index.db without reading any blueprint (O(1) vs O(N) glob).
    try:
        from backward_traversal.utils.lazy_gvl import find_index_db, DbLazyGVL
        db_info = find_index_db(blueprint_dir / "_placeholder")
        if db_info:
            db_path, job_id = db_info
            inst = DbLazyGVL(db_path, job_id)
            if inst:
                return inst
    except Exception:
        pass
    # Slow fallback: load ONE blueprint to discover the GVL path.
    # next() stops at the first OS entry — no O(N) materialisation.
    p = next(blueprint_dir.glob("*.cpp.json"), None)
    if p is not None:
        try:
            from backward_traversal.utils.blueprint_utils import load_json
            from backward_traversal.utils.lazy_gvl import make_lazy_gvl
            return make_lazy_gvl(load_json(p), p)
        except Exception:
            pass
    return None


def _per_file_lineage(stem: str, blueprint_dir: Path, cache: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Per-file ``variable_lineage`` for a stem (cached) — needed for C++ guard
    condition extraction (the global GVL alone does not carry guard `_cond` edges
    in a per-scope form)."""
    if stem in cache:
        return cache[stem]
    pfl = None
    try:
        from backward_traversal.utils.blueprint_utils import load_json, resolve_cpp_blueprint
        bp_path = resolve_cpp_blueprint(stem, blueprint_dir)
        if bp_path:
            pfl = (load_json(bp_path) or {}).get("variable_lineage")
    except Exception:
        pfl = None
    cache[stem] = pfl
    return pfl


def _trace_root(
    root: SetterRoot, blueprint_dir: Path, asm_dir: Optional[Path], gvl, caps: Dict[str, int],
    memo: Optional[Dict[str, Any]] = None, stats: Optional[Dict[str, int]] = None,
    pfl_cache: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Backward-trace one root; returns the tracer dict (nodes/edges/dep_vars/...).

    When ``memo`` is provided, identical trace work-units (same file_type +
    seed/block + variable) are computed once and reused across roots — so a path
    is never traversed twice within an analysis.
    """
    key = None
    if memo is not None:
        key = f"{root.file_type}|{root.seed_id or root.block_id}|{root.variable.upper()}"
        if key in memo:
            if stats is not None:
                stats["trace_reuse"] = stats.get("trace_reuse", 0) + 1
            return memo[key]
    result = _trace_root_compute(root, blueprint_dir, asm_dir, gvl, caps, pfl_cache=pfl_cache)
    if stats is not None:
        stats["trace_compute"] = stats.get("trace_compute", 0) + 1
    if memo is not None and key is not None:
        memo[key] = result
    return result


def _asm_guard_conditions(
    root: SetterRoot, blueprint_dir: Path, asm_dir: Optional[Path],
) -> List[Dict[str, Any]]:
    """Setter-local guard conditions for an ASM setter (TRIGGER/BRANCH pairs
    before the setter line in its routine), with the TRIGGER operand variables
    pre-extracted.  Reuses the same functions the chain path used — fully generic,
    no variable-specific logic.  Returns structured guards so ``_build_dep_vars``
    derives ``conditional_guard`` deps from the real operands (not the branch
    label that a C++-oriented LHS parse would wrongly pick)."""
    try:
        from backward_traversal.runner.backward_only_runner import (
            _extract_block_conditions_before_line,
        )
        from backward_traversal.utils.blueprint_utils import (
            collect_constant_symbols, load_json, resolve_asm_blueprint,
        )
        from backward_traversal.utils.token_utils import dep_vars_from_args
    except Exception:  # pragma: no cover
        return []
    bp_path = resolve_asm_blueprint(root.file_stem, blueprint_dir)
    if not bp_path:
        return []
    try:
        bp = load_json(bp_path)
    except Exception:
        return []
    asm_file = (asm_dir / f"{root.file_stem}.asm") if asm_dir else bp_path
    try:
        consts = collect_constant_symbols(bp, asm_file)
    except Exception:
        consts = set()
    try:
        conds = _extract_block_conditions_before_line(
            bp, str(root.block_id or ""), int(root.line or 0), str(bp_path))
    except Exception:
        return []
    out: List[Dict[str, Any]] = []
    for c in dict.fromkeys(conds):
        cvars: List[str] = []
        trig = str(c).split("/")[0]            # the TRIGGER half (e.g. "CLC WK_RRC,ZEROS")
        parts = trig.split(None, 1)
        if len(parts) == 2:
            args = [a.strip() for a in parts[1].split(",")]
            cvars = dep_vars_from_args(args, skip_var=root.variable, constant_symbols=consts)
        out.append({
            "expression": str(c), "line": int(root.line or 0),
            "condition_vars": sorted({v for v in cvars if v.upper() != root.variable.upper()}),
        })
    return out


def _collect_intrafile_routing_conditions(
    file_stem: str, variable: str, blueprint_dir: Path, pfl_cache: Dict[str, Any],
    max_depth: int = 10,
) -> List[Dict[str, Any]]:
    """Collect conditions from same-file callers of the setter function.

    For a setter buried N levels deep (e.g. processACreditTransaction called by
    performPaAuthAChargeCidValidation called by performPaAuthACharge …), this
    walks the intra-file call chain upward and collects the conditions at every
    call site.  Uses _conditions_at (which now returns ALL pre-call guards, not
    just the nearest), so guard-clause style early-returns are captured too.
    """
    try:
        from backward_traversal.utils.blueprint_utils import load_json, resolve_cpp_blueprint
        from backward_traversal.runner.chainless_lineage_tree import (
            _conditions_at, _load_pfl, _reconstruct_switch_conditions,
        )
    except Exception:
        return []

    bp_path = resolve_cpp_blueprint(file_stem, blueprint_dir)
    if not bp_path:
        return []
    try:
        bp = load_json(bp_path)
    except Exception:
        return []

    # Find the function(s) that directly contain the assignment.
    entry = _load_pfl(file_stem, blueprint_dir, pfl_cache)
    if not entry:
        return []
    lineage = (entry.get("lineage") or {})
    var_lower = variable.lower()
    setter_scopes: set = set()
    for e in (lineage.get("edges") or []):
        rel = str(e.get("relation") or "").lower()
        if rel not in ("assign", "define"):
            continue
        tgt = str(e.get("target") or "").lower()
        if not (tgt.endswith(f".{var_lower}") or tgt.endswith(f"::{var_lower}")
                or tgt.endswith(f":{var_lower}")):
            continue
        scope = str(e.get("scope") or "")
        if scope and scope != "(global)":
            setter_scopes.add(scope)

    if not setter_scopes:
        return []

    # Build intra-file reverse call map: CALLEE_UPPER -> [(caller_fn, call_line), …]
    callers_of: Dict[str, List[tuple]] = {}
    for e in ((bp.get("call_graph") or {}).get("edges") or []):
        tgt_fn = str(e.get("target") or "")
        src_fn = str(e.get("source") or "")
        ln = int(e.get("line") or 0)
        if tgt_fn and src_fn and tgt_fn.upper() != src_fn.upper():
            callers_of.setdefault(tgt_fn.upper(), []).append((src_fn, ln))

    result: List[Dict[str, Any]] = []
    seen_exprs: set = set()
    visited_fns: set = set()

    def _walk(fn: str, depth: int) -> None:
        if depth >= max_depth or fn.upper() in visited_fns:
            return
        visited_fns.add(fn.upper())
        for caller_fn, call_line in callers_of.get(fn.upper(), []):
            if not call_line:
                continue
            conds = _conditions_at(file_stem, caller_fn, call_line, blueprint_dir, pfl_cache)
            conds = _reconstruct_switch_conditions(conds, entry, caller_fn, call_line)
            for c in conds:
                cs = str(c)
                if cs and cs not in seen_exprs:
                    seen_exprs.add(cs)
                    result.append({
                        "file": str(bp_path),
                        "line": call_line,
                        "scope": caller_fn,
                        "expression": cs,
                        "conditional_context": [cs],
                        "intrafile_chain": True,
                    })
            _walk(caller_fn, depth + 1)

    for scope in setter_scopes:
        _walk(scope, 0)

    return result


def _trace_root_compute(
    root: SetterRoot, blueprint_dir: Path, asm_dir: Optional[Path], gvl, caps: Dict[str, int],
    pfl_cache: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Uncached backward trace of one root."""
    if root.file_type == "cpp":
        if gvl is None or not root.seed_id:
            return {"nodes": [], "edges": [], "dep_vars": [], "guard_conditions": [], "warnings": []}
        try:
            from backward_traversal.tracing.cpp_backward_tracer import trace_cpp_variable_backward
            # Per-file lineage is REQUIRED for guard-condition extraction — the
            # setter's conditions (e.g. `if (expressPay != On) x = ...`) come from
            # the per-file `_cond` edges, not the global assign/define graph.
            _pfl_cache = pfl_cache if pfl_cache is not None else {}
            pfl = _per_file_lineage(root.file_stem, blueprint_dir, _pfl_cache)
            result = trace_cpp_variable_backward(
                root.seed_id, gvl,
                max_depth=caps.get("max_depth") or 1_000_000,
                max_nodes=caps.get("max_nodes") or 1_000_000,
                per_file_lineage=pfl,
                variable_name=root.variable,
            )
            # Append conditions from same-file callers of the setter function
            # (e.g. the switch/if chain inside callPlasticAuth → performPaAuthACharge
            # → performPaAuthAChargeCidValidation that routes to the setter).
            # Use a dedicated cache: _per_file_lineage stores raw lineage dicts
            # while _load_pfl (used inside) stores {"lineage":…,"bp":…} — different
            # shapes, so they must not share the same cache dict.
            chain_conds = _collect_intrafile_routing_conditions(
                root.file_stem, root.variable, blueprint_dir, {},
            )
            if chain_conds:
                result["guard_conditions"] = list(result.get("guard_conditions") or []) + chain_conds
            return result
        except Exception as exc:
            logger.debug("cpp trace failed for %s: %s", root.root_id, exc)
            return {"nodes": [], "edges": [], "dep_vars": [], "guard_conditions": [], "warnings": [str(exc)]}
    # ASM
    try:
        from backward_traversal.tracing.asm_backward_tracer import trace_asm_call_site_backward
        from backward_traversal.utils.blueprint_utils import resolve_asm_blueprint
        bp_path = resolve_asm_blueprint(root.file_stem, blueprint_dir)
        if not bp_path:
            return {"call_graph": {"nodes": [], "edges": []}, "dep_vars": [], "warnings": []}
        asm_file = (asm_dir / f"{root.file_stem}.asm") if asm_dir else bp_path
        call_site = {
            "routine": root.block_id, "line": root.line, "instruction": root.instruction,
            "raw_line": root.setter_expression or "", "constant_source": root.constant_source,
        }
        res = trace_asm_call_site_backward(
            root.variable, bp_path, asm_file, call_site,
            max_depth=caps.get("max_depth") or 8,
            max_trace_nodes_per_site=caps.get("max_nodes") or 5000,
        )
        # Normalise to the nodes/edges/dep_vars shape.
        cg = res.get("call_graph") or {}
        return {
            "nodes": cg.get("nodes", []), "edges": cg.get("edges", []),
            "dep_vars": res.get("dep_vars", []),
            # Setter-local TRIGGER/BRANCH guards (parity with the C++ _cond path);
            # carries the pre-extracted operand vars so dep-derivation is correct.
            "guard_conditions": _asm_guard_conditions(root, blueprint_dir, asm_dir),
            "subroutine_expansions": res.get("subroutine_expansions", []),
            "warnings": res.get("warnings", []),
        }
    except Exception as exc:
        logger.debug("asm trace failed for %s: %s", root.root_id, exc)
        return {"call_graph": {}, "nodes": [], "edges": [], "dep_vars": [], "warnings": [str(exc)]}


_GUARD_OP_RE = __import__("re").compile(r"(==|!=|<=|>=|<|>)")


def _guard_lhs_var(cond: str) -> str:
    """Extract the guarded variable (LHS token) from a condition expression."""
    text = str(cond or "").strip()
    parts = _GUARD_OP_RE.split(text, maxsplit=1)
    lhs = parts[0].strip() if parts else text
    # Take the trailing member-access component as the variable name.
    lhs = lhs.strip().strip("()").strip()
    if not lhs:
        return ""
    return lhs.split()[-1] if " " in lhs else lhs


def _build_dep_vars(
    trace: Dict[str, Any], root: SetterRoot,
    blueprint_dir: Path, graph_file: Path, asm_dir: Optional[Path], job_id: Optional[str],
    caps: Dict[str, int],
) -> List[DepVar]:
    """Build dep vars: condition-variables → conditional_guard (with constraint +
    sound value-pruning); data-flow operands → data_flow."""
    out: List[DepVar] = []
    seen: set = set()

    # 1) Condition variables — the "specific value" dependencies (if (y==2) x=...).
    for g in (trace.get("guard_conditions") or []):
        explicit_vars = None
        if isinstance(g, dict):
            conds = g.get("conditional_context") or ([g.get("expression")] if g.get("expression") else [])
            gline = int(g.get("line") or 0)
            explicit_vars = g.get("condition_vars")  # ASM: pre-extracted operands
        else:
            conds, gline = [str(g)], 0
        for cond in conds:
            if not cond:
                continue
            constraint = DR.extract_constraint(str(cond))
            # Guarded variable(s): explicit ASM operands (correct for TRIGGER/BRANCH
            # guards), else parse the C++ ``x == y`` LHS.
            lhs_vars = list(explicit_vars) if explicit_vars else (
                [_guard_lhs_var(str(cond))] if _guard_lhs_var(str(cond)) else [])
            for lhs in lhs_vars:
                if not lhs:
                    continue
                key = (lhs.upper(), "conditional_guard", constraint.raw)
                if key in seen:
                    continue
                seen.add(key)
                dep = DepVar(
                    name=lhs, kind="conditional_guard", constraint=constraint,
                    discovered_in_stem=root.file_stem, discovered_at_line=gline, root_id=root.root_id,
                )
                # Sound value-pruning when a constant constraint is present (bounded).
                scan = caps.get("max_dep_setter_scan") or 0
                if constraint.constant and scan:
                    try:
                        dep_roots, _c, _w = enumerate_setter_roots(
                            lhs, None, blueprint_dir, graph_file, asm_dir,
                            job_id=job_id, expand_counterparts=False, max_setter_roots=scan,
                        )
                        sites = [{"constant_source": r.constant_source,
                                  "constant_value": r.setter_expression,
                                  "setter_expression": r.setter_expression} for r in dep_roots]
                        DR.mark_relevance(dep, sites)
                    except Exception:
                        pass
                out.append(dep)

    # 2) Data-flow operands from the trace.
    for name in (trace.get("dep_vars") or []):
        nm = str(name)
        key = (nm.upper(), "data_flow", None)
        if key in seen:
            continue
        seen.add(key)
        out.append(DepVar(
            name=nm, kind=DR.classify_dep_kind(root.role, root.prior_value_required, False),
            discovered_in_stem=root.file_stem, discovered_at_line=root.line, root_id=root.root_id,
        ))
    return out


def process_single_root(
    root: SetterRoot,
    *,
    blueprint_dir: Path,
    graph_file: Path,
    asm_dir: Optional[Path],
    job_id: Optional[str],
    gvl,
    reverse_adj: Dict[str, List],
    node_type: Dict[str, str],
    caps: Dict[str, int],
    visited_callers: Optional[Set[Tuple[str, str]]] = None,
    visited_downstream: Optional[Set[Tuple[str, str]]] = None,
    memo: Optional[Dict[str, Any]] = None,
    stats: Optional[Dict[str, int]] = None,
    pfl_cache: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Trace ONE setter root independently. Returns a plain-dict result.

    Shared by the synchronous runner and the resumable session so the per-root
    work is defined exactly once (a root is the forest's unit of independence).
    """
    if visited_callers is None:
        visited_callers = set()
    if visited_downstream is None:
        visited_downstream = set()
    blueprint_dir = Path(blueprint_dir)

    trace = _trace_root(root, blueprint_dir, asm_dir, gvl, caps, memo=memo, stats=stats,
                        pfl_cache=pfl_cache)
    conditions = list(trace.get("guard_conditions") or [])
    anchor = root.seed_id or root.block_id or root.variable
    nk = TraceNode.make_node_key(root.file_stem, root.file_type, anchor, root.variable,
                                 root.role or root.instruction, root.line)
    deps = _build_dep_vars(trace, root, blueprint_dir, graph_file, asm_dir, job_id, caps)
    from backward_traversal.runner.chainless_reachability import setter_anchor_functions
    anchor_fns = setter_anchor_functions(root, blueprint_dir)
    callers = walk_callers(
        root.file_stem, root.file_type, blueprint_dir, asm_dir, reverse_adj, node_type,
        max_caller_depth=caps.get("max_caller_depth") or 0,
        max_nodes=caps.get("max_nodes") or 0, visited=visited_callers,
        anchor_fns=anchor_fns,
    )
    if root.file_type == "cpp":
        downstream = sorted(downstream_files_from_cpp_trace(trace))
    else:
        ds = walk_downstream_asm(
            root.variable, root.file_stem, {root.block_id} if root.block_id else set(),
            blueprint_dir, asm_dir,
            max_downstream_depth=caps.get("max_downstream_depth") or 0, visited=visited_downstream,
        )
        downstream = sorted({d["callee_stem"] for d in ds})

    from dataclasses import asdict
    return {
        "root_id": root.root_id,
        "node_key": nk,
        "node": {
            "node_key": nk, "file_stem": root.file_stem, "file_type": root.file_type,
            "variable": root.variable, "line": root.line, "instruction": root.instruction,
            "role": root.role, "relevant_lines": [{"count": len(trace.get("nodes") or [])}],
            # Carry the EXACT value this site writes (e.g. the C++ assign RHS, the
            # ASM operand) so the explanation describes only THIS site's value —
            # not every value the field can take across other setter sites.
            "setter_expression": root.setter_expression,
            "conditions": conditions,
            "warnings": list(trace.get("warnings") or []),
        },
        "conditions": conditions,
        "deps": [asdict(d) for d in deps],
        "caller_keys": [f"{c.stem}->{c.callee_stem}" for c in callers if c.call_sites],
        "callers": [asdict(c) for c in callers],
        "downstream": downstream,
        "truncated": bool(trace.get("truncated")),
        "warnings": list(trace.get("warnings") or []),
    }


def load_runtime(blueprint_dir: Path, graph_file: Path, job_id: Optional[str], need_cpp: bool):
    """Build the shared runtime: graph reverse-adjacency + (optional) global GVL."""
    graph_payload = _load_graph_payload(Path(graph_file), job_id)
    reverse_adj, node_type = build_reverse_adjacency(graph_payload)
    gvl = _global_gvl(Path(blueprint_dir)) if need_cpp else None
    return reverse_adj, node_type, gvl


# ---------------------------------------------------------------------------
# Picklable worker for ProcessPoolExecutor (must be module-level)
# ---------------------------------------------------------------------------

def _forest_worker(args: Dict[str, Any]) -> Dict[str, Any]:
    """Process one setter root inside a worker process.

    Receives everything it needs as plain picklable values (strings/dicts).
    Each worker process loads its own lightweight runtime (reverse-adjacency
    from the call-graph JSON, lazy IndexDbGVL reader backed by SQLite) so no
    large objects are transferred across the process boundary.

    The GVL is intentionally NOT pre-loaded in the parent — ``IndexDbGVL``
    opens a fresh SQLite connection per process; SQLite's WAL mode allows
    unlimited concurrent readers safely.
    """
    import logging
    logging.disable(logging.WARNING)
    try:
        from pathlib import Path
        from backward_traversal.models.chainless_models import SetterRoot
        from backward_traversal.runner.chainless_runner import (
            process_single_root, load_runtime,
        )

        root_dict = args["root_dict"]
        blueprint_dir = Path(args["blueprint_dir"])
        graph_file = Path(args["graph_file"])
        asm_dir = Path(args["asm_dir"]) if args.get("asm_dir") else None
        job_id = args.get("job_id")
        caps = args["caps"]
        need_cpp = args.get("need_cpp", True)

        reverse_adj, node_type, gvl = load_runtime(
            blueprint_dir, graph_file, job_id, need_cpp,
        )
        root = SetterRoot(**{
            k: v for k, v in root_dict.items()
            if k in SetterRoot.__dataclass_fields__
        })
        result = process_single_root(
            root,
            blueprint_dir=blueprint_dir,
            graph_file=graph_file,
            asm_dir=asm_dir,
            job_id=job_id,
            gvl=gvl,
            reverse_adj=reverse_adj,
            node_type=node_type,
            caps=caps,
        )
        return {"root_id": root.root_id, "ok": True, "result": result}
    except Exception as exc:
        return {"root_id": args.get("root_dict", {}).get("root_id", "?"),
                "ok": False, "error": str(exc)}


def run_chainless_backward(
    variable: str,
    *,
    language: Optional[str] = None,
    blueprint_dir: Path,
    graph_file: Path,
    asm_dir: Optional[Path] = None,
    job_id: Optional[str] = None,
    expand_counterparts: bool = True,
    max_caller_depth: int = 0,
    max_dep_var_depth: int = 0,
    max_downstream_depth: int = 0,
    max_nodes: int = 0,
    max_files: int = 0,
    max_setter_roots: int = 0,
    max_depth: int = 0,
    max_dep_setter_scan: int = 200,
    use_memo: bool = True,
) -> ForestOutput:
    """Run the full chainless backward lineage for ``variable``; return the forest."""
    blueprint_dir = Path(blueprint_dir)
    graph_file = Path(graph_file)
    caps = {
        "max_nodes": max_nodes, "max_depth": max_depth,
        "max_caller_depth": max_caller_depth, "max_downstream_depth": max_downstream_depth,
        "max_dep_setter_scan": max_dep_setter_scan,
    }
    memo: Optional[Dict[str, Any]] = {} if use_memo else None
    memo_stats: Dict[str, int] = {}
    pfl_cache: Dict[str, Any] = {}

    roots, counterparts, warns = enumerate_setter_roots(
        variable, language, blueprint_dir, graph_file, asm_dir,
        job_id=job_id, expand_counterparts=expand_counterparts,
        max_setter_roots=max_setter_roots, max_files=max_files,
    )

    graph_payload = _load_graph_payload(graph_file, job_id)
    reverse_adj, node_type = build_reverse_adjacency(graph_payload)
    gvl = _global_gvl(blueprint_dir) if any(r.file_type == "cpp" for r in roots) else None

    out = ForestOutput(
        variable=variable,
        language=(language or ("mixed" if {r.file_type for r in roots} == {"asm", "cpp"}
                               else (next(iter({r.file_type for r in roots}), "cpp")))),
        options={
            "expand_counterparts": expand_counterparts,
            "caps": {k: v for k, v in dict(
                max_caller_depth=max_caller_depth, max_dep_var_depth=max_dep_var_depth,
                max_downstream_depth=max_downstream_depth, max_nodes=max_nodes,
                max_files=max_files, max_setter_roots=max_setter_roots, max_depth=max_depth,
            ).items()},
        },
        warnings=list(warns),
        counterparts=counterparts,
        setter_roots=roots,
    )
    node_budget = Budget(max_nodes)
    caps_hit: Set[str] = set()
    visited_downstream: Set[Tuple[str, str]] = set()

    for root in roots:
        trace = _trace_root(root, blueprint_dir, asm_dir, gvl, caps, memo=memo, stats=memo_stats,
                            pfl_cache=pfl_cache)
        conditions = list(trace.get("guard_conditions") or [])
        if trace.get("truncated"):
            caps_hit.add("max_nodes")

        # Interned trace node for this root.
        anchor = root.seed_id or root.block_id or root.variable
        nk = TraceNode.make_node_key(root.file_stem, root.file_type, anchor, root.variable,
                                     root.role or root.instruction, root.line)
        tnode = out.nodes.get(nk)
        if tnode is None:
            tnode = TraceNode(
                node_key=nk, file_stem=root.file_stem, file_type=root.file_type,
                variable=root.variable, line=root.line, instruction=root.instruction,
                role=root.role,
                relevant_lines=[{"count": len(trace.get("nodes") or [])}],
                conditions=conditions,
                warnings=list(trace.get("warnings") or []),
            )
            out.nodes[nk] = tnode
        node_budget.inc()

        # Dependent variables (kind + sound value-pruning).
        deps = _build_dep_vars(trace, root, blueprint_dir, graph_file, asm_dir, job_id, caps)
        for d in deps:
            out.dep_vars.setdefault(f"{d.root_id}:{d.name}", d)

        # Caller walk — each root gets a fresh visited set so the full caller
        # chain is captured independently (shared visited caused later roots to
        # see earlier-walked edges as cycles with no call_sites).
        from backward_traversal.runner.chainless_reachability import setter_anchor_functions
        callers = walk_callers(
            root.file_stem, root.file_type, blueprint_dir, asm_dir, reverse_adj, node_type,
            max_caller_depth=max_caller_depth, max_nodes=max_nodes, visited=set(),
            anchor_fns=setter_anchor_functions(root, blueprint_dir),
        )
        # Downstream callee descent.
        downstream_stems: List[str] = []
        if root.file_type == "cpp":
            downstream_stems = sorted(downstream_files_from_cpp_trace(trace))
        else:
            ds = walk_downstream_asm(
                root.variable, root.file_stem,
                {root.block_id} if root.block_id else set(),
                blueprint_dir, asm_dir,
                max_downstream_depth=max_downstream_depth, visited=visited_downstream,
            )
            downstream_stems = sorted({d["callee_stem"] for d in ds})

        out.forest.append(
            ForestRootEntry(
                root=root,
                trace_node_keys=[nk],
                caller_keys=[f"{c.stem}->{c.callee_stem}" for c in callers if c.call_sites],
                downstream_keys=downstream_stems,
                dep_var_keys=[f"{d.root_id}:{d.name}" for d in deps],
                conditions=conditions,
                truncated=bool(trace.get("truncated")),
                warnings=list(trace.get("warnings") or []),
            )
        )

    out.truncated = bool(caps_hit)
    out.stats = {
        "n_roots": len(roots),
        "n_counterparts": len(counterparts),
        "n_nodes": len(out.nodes),
        "n_dep_vars": len(out.dep_vars),
        "n_files": len({r.file_stem for r in roots}),
        "caps_hit": sorted(caps_hit),
        "memo": dict(memo_stats),
    }
    return out
