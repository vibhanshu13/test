"""Subroutine target normalization + resolution helpers for backward-only mode."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

from backward_traversal.glossary.instructions import RETURN_OPCODES
from backward_traversal.utils.token_utils import looks_like_register_token, normalize_token

try:
    from blueprint_io import iter_flow
except ImportError:
    import sys as _sys
    import os as _os
    _sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.dirname(__file__))))
    from blueprint_io import iter_flow


_SYMBOL_RE = re.compile(r"[A-Z@$_#][A-Z0-9@$_#]*")

# Matches HLASM literal address constants: =A(SYM), =V(SYM), =R(SYM), =Y(SYM), =S(SYM).
# Must be checked BEFORE split("(") which would otherwise reduce "=A(MYSUB)" to "=A"
# and return the single-letter token "A" instead of the real target "MYSUB" (GAP-008).
_LITERAL_ADDR_RE = re.compile(r"^=[AVRYS]\(([A-Z@$_#][A-Z0-9@$_#]*)\)$")


def _extract_symbol_token(text: str) -> str:
    raw = str(text or "").strip().upper()
    if not raw:
        return ""

    # Keep the first comma segment, then first whitespace token.
    raw = raw.split(",")[0].strip()
    raw = raw.split()[0].strip() if raw else ""
    if not raw:
        return ""

    # GAP-008: detect literal address constants (=A(SYM), =V(SYM), …) before the
    # split("(") step.  Without this, "=A(MYSUB)" is truncated to "=A" → "A" and
    # resolve_subroutine_target returns "unresolved" for the real target MYSUB.
    m_lit = _LITERAL_ADDR_RE.match(raw)
    if m_lit:
        return m_lit.group(1)

    # Strip indirect/addressing wrappers while preserving the symbol core.
    raw = raw.split("(")[0].strip()
    raw = raw.lstrip("=*&").rstrip(").,;:")
    if not raw:
        return ""

    m = _SYMBOL_RE.search(raw)
    return m.group(0) if m else ""


def normalize_subroutine_target(target: str) -> str:
    """Normalize a raw BAS/BAL target to a clean symbol token."""
    return _extract_symbol_token(target)


def extract_subroutine_target(args: Iterable[Any], detail: str = "") -> str:
    """Extract the subroutine target from BAS/BAL args/detail.

    Preference:
    1) rightmost non-register argument
    2) first non-register argument
    3) first normalized token from detail string
    """
    tokens = [str(a) for a in (args or []) if str(a).strip()]
    normalized = [normalize_subroutine_target(t) for t in tokens]
    normalized = [t for t in normalized if t]

    for tok in reversed(normalized):
        if not looks_like_register_token(tok):
            return tok

    for tok in normalized:
        if not looks_like_register_token(tok):
            return tok

    for part in re.split(r"[\s,]+", str(detail or "").upper()):
        tok = normalize_subroutine_target(part)
        if tok and not looks_like_register_token(tok):
            return tok
    return ""


def _extract_opcode_from_source_line(line: str) -> str:
    text = str(line or "").rstrip("\n")
    if not text:
        return ""
    lstrip = text.lstrip()
    if not lstrip or lstrip.startswith("*"):
        return ""

    # Fixed-format ASM often carries opcode in columns 16-23.
    if len(text) >= 23:
        col = text[15:23].strip().upper()
        if col and _SYMBOL_RE.fullmatch(col):
            return col

    # Fallback tokenization.
    parts = lstrip.split()
    if not parts:
        return ""
    if len(parts) >= 2 and _SYMBOL_RE.fullmatch(parts[1].upper()):
        return parts[1].upper()
    first = parts[0].upper()
    return first if _SYMBOL_RE.fullmatch(first) else ""


def _return_anchor_lines_from_source(
    asm_file: Optional[Path],
    start_line: int,
    end_line: int,
    return_opcodes: Sequence[str],
) -> List[int]:
    if asm_file is None or not asm_file.exists():
        return []
    try:
        lines = asm_file.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []

    start = max(1, int(start_line or 1))
    end = min(len(lines), int(end_line or 0))
    if end < start:
        return []

    ret_set = {str(op).upper() for op in return_opcodes}
    anchors: List[int] = []
    for ln in range(start, end + 1):
        op = _extract_opcode_from_source_line(lines[ln - 1])
        if op and op in ret_set:
            anchors.append(ln)
    return anchors


def resolve_subroutine_target(
    blueprint_data: Dict[str, Any],
    target_label: str,
    asm_file: Optional[Path] = None,
) -> Dict[str, Any]:
    """Resolve a BAS/BAL target against subroutines then blocks.

    Resolution order:
    1) exact subroutine id
    2) normalized subroutine id
    3) exact block id fallback
    4) normalized block id fallback
    """
    requested = str(target_label or "").strip().upper()
    normalized = normalize_subroutine_target(requested)
    if not requested and not normalized:
        return {
            "requested_target": requested,
            "normalized_target": normalized,
            "resolved_label": None,
            "start_line": None,
            "end_line": None,
            "return_anchor_lines": [],
            "resolution_confidence": "unresolved",
            "warnings": ["Missing subroutine target label."],
        }

    subs = list(blueprint_data.get("subroutines", []) or [])
    blocks = list(blueprint_data.get("blocks", []) or [])
    block_map = {str(b.get("id") or "").upper(): b for b in blocks}

    sub_exact: Dict[str, Dict[str, Any]] = {}
    sub_norm: Dict[str, Dict[str, Any]] = {}
    for sub in subs:
        sid = str(sub.get("id") or "").strip().upper()
        if not sid:
            continue
        sub_exact[sid] = sub
        ns = normalize_subroutine_target(sid)
        if ns and ns not in sub_norm:
            sub_norm[ns] = sub

    confidence = "unresolved"
    resolved_label: Optional[str] = None
    sub_meta: Optional[Dict[str, Any]] = None
    block_meta: Optional[Dict[str, Any]] = None

    if requested and requested in sub_exact:
        sub_meta = sub_exact[requested]
        resolved_label = str(sub_meta.get("id") or requested)
        confidence = "exact_subroutine"
    elif normalized and normalized in sub_norm:
        sub_meta = sub_norm[normalized]
        resolved_label = str(sub_meta.get("id") or normalized)
        confidence = "normalized_subroutine"
    elif requested and requested in block_map:
        block_meta = block_map[requested]
        resolved_label = str(block_meta.get("id") or requested)
        confidence = "block_fallback"
    elif normalized and normalized in block_map:
        block_meta = block_map[normalized]
        resolved_label = str(block_meta.get("id") or normalized)
        confidence = "normalized_block_fallback"

    if not resolved_label:
        return {
            "requested_target": requested,
            "normalized_target": normalized,
            "resolved_label": None,
            "start_line": None,
            "end_line": None,
            "return_anchor_lines": [],
            "resolution_confidence": "unresolved",
            "warnings": [f"Unresolved subroutine target '{requested or normalized}'."],
        }

    flow_lines: List[int] = []
    resolved_block = block_map.get(str(resolved_label).upper())
    if resolved_block:
        flow_lines = sorted(
            int(f.get("line"))
            for f in iter_flow(resolved_block)
            if f.get("line") is not None
        )

    if sub_meta:
        start_line = int(sub_meta.get("start_line") or (min(flow_lines) if flow_lines else 0) or 0)
        end_line = int(sub_meta.get("end_line") or (max(flow_lines) if flow_lines else 0) or start_line or 0)
    else:
        if flow_lines:
            start_line = min(flow_lines)
            end_line = max(flow_lines)
        else:
            start_line = 0
            end_line = 0

    if end_line < start_line:
        start_line, end_line = end_line, start_line

    anchors: List[int] = []
    if start_line > 0 and end_line >= start_line:
        anchors.extend(_return_anchor_lines_from_source(asm_file, start_line, end_line, list(RETURN_OPCODES)))
        if flow_lines:
            anchors.append(max(flow_lines))
        if end_line:
            anchors.append(end_line)

    anchors = sorted({ln for ln in anchors if start_line <= ln <= end_line})
    if not anchors and end_line:
        anchors = [end_line]

    return {
        "requested_target": requested,
        "normalized_target": normalized,
        "resolved_label": resolved_label,
        "start_line": start_line if start_line > 0 else None,
        "end_line": end_line if end_line > 0 else None,
        "return_anchor_lines": anchors,
        "resolution_confidence": confidence,
        "warnings": [],
    }


def normalize_symbol_name(name: str) -> str:
    """Normalize symbol names for deterministic comparison/dedup."""
    return normalize_token(str(name or "")).upper()

