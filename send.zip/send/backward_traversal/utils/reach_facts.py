"""Precomputed backward-CFG reachability facts (``block_reach_facts``).

Implements the query side of the Lineage Facts Index
(docs/plans/2026-06-07-backward-lineage-facts-index-design.md, Phase 2):
``backward_reachable_blocks`` is a pure function of (file, anchor block) for
a fixed blueprint, so the result is materialized once per job into
``index.db`` and the dep-var BFS reads it back instead of re-walking the CFG
per dep_var.

Shared between the index-DB writer (api/index_db/writers.py — pack helpers,
stem derivation) and the runner-side accessor (``lookup_reach_facts``).  This
module deliberately uses raw sqlite3 (read-only) rather than importing
api.index_db so backward_traversal stays decoupled from the API package —
the same approach as lazy_gvl's IndexDbGVL.

Storage format: one row per (job_id, file_stem, anchor_block, before_line=0)
holding gzip-compressed JSON of the sorted reachable block-id list, computed
with ``expand_subroutine_callers=True`` (the only form the dep-var BFS uses).
Walks with a non-zero ``before_line`` cap are not materialized — the accessor
returns None for those and the caller falls back to the live CFG walk.

RAM: the accessor holds one read-only sqlite connection per DB path and
returns small sets of block-id strings; nothing scales with codebase size.
"""
from __future__ import annotations

import gzip
import json
import logging
import os
import sqlite3
import threading
from pathlib import Path
from typing import Dict, Optional, Set, Tuple

logger = logging.getLogger(__name__)

_USE_REACH_FACTS_ENV = "ASM_USE_REACH_FACTS"  # set to 0/false to disable reads


def blueprint_stem(bp_path: Path) -> str:
    """Stem used to key facts rows: ``xh72.asm.json`` → ``xh72`` (lowercase).

    Must stay in sync between the writer (which keys rows by blueprint file)
    and the accessor (which derives the key from the bp_path it is given).
    """
    name = Path(bp_path).name
    return name.split(".", 1)[0].strip().lower()


def pack_reachable(reachable: Set[str]) -> bytes:
    """Pack a reachable block-id set for the ``reachable_packed`` column."""
    return gzip.compress(json.dumps(sorted(reachable)).encode("utf-8"))


def unpack_reachable(blob: bytes) -> Set[str]:
    """Inverse of :func:`pack_reachable`."""
    return set(json.loads(gzip.decompress(blob).decode("utf-8")))


def _reads_enabled() -> bool:
    return os.environ.get(_USE_REACH_FACTS_ENV, "1").strip().lower() not in (
        "0", "false", "no", "off",
    )


class _ReachFactsReader:
    """Process-wide reader: one cached read-only connection per index.db.

    Availability (table exists and has rows for the job) is probed once per
    (db_path, job_id) and cached, so jobs without facts pay one cheap query
    and then always fall back to the live CFG walk without touching the DB.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._conns: Dict[str, sqlite3.Connection] = {}
        self._available: Dict[Tuple[str, str], bool] = {}

    def _conn_for(self, db_path: str) -> Optional[sqlite3.Connection]:
        conn = self._conns.get(db_path)
        if conn is not None:
            return conn
        try:
            conn = sqlite3.connect(
                f"file:{db_path}?mode=ro", uri=True, check_same_thread=False
            )
            conn.execute("PRAGMA busy_timeout=5000")
        except Exception as exc:
            logger.debug("[reach_facts] cannot open %s read-only: %s", db_path, exc)
            return None
        self._conns[db_path] = conn
        return conn

    def _job_has_facts(self, conn: sqlite3.Connection, db_path: str, job_id: str) -> bool:
        key = (db_path, job_id)
        cached = self._available.get(key)
        if cached is not None:
            return cached
        try:
            row = conn.execute(
                "SELECT 1 FROM block_reach_facts WHERE job_id = ? LIMIT 1",
                (job_id,),
            ).fetchone()
            ok = row is not None
        except sqlite3.Error:
            ok = False  # table absent (job predates the facts index)
        self._available[key] = ok
        return ok

    def lookup(
        self, bp_path: str, anchor_block: str, before_line: int = 0
    ) -> Optional[Set[str]]:
        """Return the precomputed reachable set, or None to fall back.

        None means "no fact available" (disabled, capped walk, no DB, job not
        ingested, or row missing e.g. oversized file skipped at build time).
        """
        if not bp_path or before_line:
            return None  # only the uncapped walk is materialized
        if not _reads_enabled():
            return None
        from backward_traversal.utils.lazy_gvl import find_gvl_db_path
        found = find_gvl_db_path(Path(bp_path))
        if found is None:
            return None
        db_path, job_id = str(found[0]), str(found[1])
        with self._lock:
            conn = self._conn_for(db_path)
            if conn is None or not self._job_has_facts(conn, db_path, job_id):
                return None
            try:
                row = conn.execute(
                    "SELECT reachable_packed FROM block_reach_facts "
                    "WHERE job_id = ? AND file_stem = ? AND anchor_block = ? "
                    "AND before_line = ? LIMIT 1",
                    (job_id, blueprint_stem(Path(bp_path)), str(anchor_block), 0),
                ).fetchone()
            except sqlite3.Error as exc:
                logger.debug("[reach_facts] query failed on %s: %s", db_path, exc)
                return None
        if row is None or row[0] is None:
            return None
        try:
            return unpack_reachable(row[0])
        except Exception as exc:
            logger.debug("[reach_facts] unpack failed (%s/%s): %s", job_id, anchor_block, exc)
            return None

    def close(self) -> None:
        with self._lock:
            for conn in self._conns.values():
                try:
                    conn.close()
                except Exception:
                    pass
            self._conns.clear()
            self._available.clear()


_reader = _ReachFactsReader()


def lookup_reach_facts(
    bp_path: str, anchor_block: str, before_line: int = 0
) -> Optional[Set[str]]:
    """Module-level accessor used by the dep-var BFS (see _reach_cached)."""
    return _reader.lookup(bp_path, anchor_block, before_line)


def close_reach_facts_reader() -> None:
    """Close cached read-only connections (e.g. at end of a Celery task)."""
    _reader.close()
