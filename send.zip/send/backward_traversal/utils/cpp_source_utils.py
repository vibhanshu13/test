"""C++ source extraction helpers for backward-only mode."""

from __future__ import annotations

import functools
from pathlib import Path
from typing import Any, Dict, List, Optional


def _extract_one_function(lines: List[str], start_line: int) -> str:
    depth = 0
    in_block_comment = False
    result: List[str] = []
    found_open = False

    for raw in lines[start_line - 1 :]:
        result.append(raw.rstrip())
        i = 0
        while i < len(raw):
            if in_block_comment:
                if raw[i : i + 2] == "*/":
                    in_block_comment = False
                    i += 2
                else:
                    i += 1
                continue
            if raw[i : i + 2] == "//":
                break
            if raw[i : i + 2] == "/*":
                in_block_comment = True
                i += 2
                continue
            if raw[i] == '"':
                i += 1
                while i < len(raw):
                    if raw[i] == "\\":
                        i += 2
                        continue
                    if raw[i] == '"':
                        i += 1
                        break
                    i += 1
                continue
            # FIX-new-8: handle single-quoted char literals ('{'  '}' etc.)
            # Without this, a brace inside a char literal corrupts depth tracking.
            if raw[i] == "'":
                i += 1
                while i < len(raw):
                    if raw[i] == "\\":
                        i += 2
                        continue
                    if raw[i] == "'":
                        i += 1
                        break
                    i += 1
                continue
            if raw[i] == "{":
                depth += 1
                found_open = True
            elif raw[i] == "}":
                depth -= 1
            i += 1
        if found_open and depth == 0:
            break

    return "\n".join(result)


@functools.lru_cache(maxsize=32)
def build_func_source_index(blueprint_dir: Path, asm_dir: Optional[Path], stem: str) -> Dict[str, str]:
    bp = blueprint_dir / f"{stem}.cpp.json"
    if not bp.exists():
        return {}

    try:
        from blueprint_io import load_blueprint as _io_load
        payload = _io_load(bp, skip_global_lineage=True)
    except Exception:
        return {}

    lm = payload.get("line_metadata", {})
    if not lm:
        return {}

    func_starts: Dict[str, int] = {}
    for line_key, meta in lm.items():
        enc_func = (meta.get("codeblock") or {}).get("enclosing_function")
        if not enc_func:
            continue
        ln = int(line_key)
        if enc_func not in func_starts or ln < func_starts[enc_func]:
            func_starts[enc_func] = ln

    if not func_starts:
        return {}

    cpp_source: Optional[Path] = None
    candidates: List[Path] = []
    if asm_dir:
        candidates.append(asm_dir / f"{stem}.cpp")
    candidates += [
        blueprint_dir.parent.parent / "asm" / f"{stem}.cpp",
        blueprint_dir.parent / "asm" / f"{stem}.cpp",
        blueprint_dir / f"{stem}.cpp",
    ]
    for c in candidates:
        if c.exists():
            cpp_source = c
            break
    if cpp_source is None:
        return {}

    try:
        source_lines = cpp_source.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return {}

    # NEW-F: probe backward from each func_start to find the actual function
    # signature.  line_metadata covers only executable lines; the return type,
    # function name, and parameter list may be several lines above the first
    # executable line.  Walk backward, stopping at a lone "}" line (the end of
    # the previous function body) or after _SIGNATURE_LOOKBACK lines.
    _SIGNATURE_LOOKBACK = 10
    index: Dict[str, str] = {}
    for func_name, first_exec_line in func_starts.items():
        if first_exec_line < 1 or first_exec_line > len(source_lines):
            continue
        sig_start = first_exec_line
        for back in range(first_exec_line - 1, max(0, first_exec_line - _SIGNATURE_LOOKBACK - 1), -1):
            if back < 1:
                break
            raw = source_lines[back - 1].lstrip()
            if raw.startswith("}"):
                break  # end of the previous function — stop here
            sig_start = back
        index[func_name] = _extract_one_function(source_lines, sig_start)
    return index
