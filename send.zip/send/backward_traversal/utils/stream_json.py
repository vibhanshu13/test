"""Streaming JSON array iterator for arbitrarily large flat JSON files.

Usage
-----
    from backward_traversal.utils.stream_json import stream_json_array

    for item in stream_json_array("/path/to/big.json", "edges"):
        process(item)   # only ONE item in RAM at a time

Memory model
------------
- Builds a lightweight sidecar index (.jidx) alongside the source file on the
  first call so that every subsequent call can seek directly to the array's
  opening '[' in O(1) time.
- Each item is decoded with json.JSONDecoder.raw_decode() from a sliding 256 KB
  window.  Peak RAM is O(one_item_size), never O(array_size).
- If the optional `ijson` library is installed it is preferred over the fallback
  (avoids the manual sliding-window logic and handles all edge-cases robustly).

Sidecar format
--------------
The sidecar (``<file>.jidx``) is a JSON dict mapping top-level key names to
``[start_byte, end_byte]`` ranges (binary mode).  It is invalidated and rebuilt
automatically when the source file is newer than the sidecar.
"""
from __future__ import annotations

import codecs
import json
import os
import sys
from pathlib import Path
from typing import Any, Generator, Optional, Tuple

# ── sidecar helpers (duplicated from tools/search_large_json.py to avoid
#    a fragile cross-package import; kept in sync manually) ──────────────────

SIDECAR_SUFFIX = ".jidx"
_CHUNK = 256 * 1024        # 256 KB I/O window
_SIDECAR_CHUNK = 64 * 1024  # 64 KB chunk for full-index builder
_MAX_KEY_LEN = 4 * 1024    # 4 KB safety cap on key name length


def _sidecar_path(fp: str) -> str:
    return fp + SIDECAR_SUFFIX


def _load_sidecar(fp: str) -> Optional[dict]:
    sp = _sidecar_path(fp)
    try:
        if not os.path.exists(sp):
            return None
        if os.path.getmtime(sp) < os.path.getmtime(fp):
            return None  # stale
        with open(sp, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _save_sidecar(fp: str, index: dict) -> None:
    sp = _sidecar_path(fp)
    try:
        with open(sp, "w", encoding="utf-8") as f:
            json.dump(index, f)
    except Exception:
        pass


def _build_index(fp: str) -> dict:
    """Single binary-mode pass — builds {key: [start_byte, end_byte]} for every
    top-level key.  Identical to the implementation in tools/search_large_json.py."""
    S_SCAN, S_COLON, S_VALUE = 0, 1, 2
    state = S_SCAN
    in_str = esc = False
    depth = 0
    can_be_key = False
    key_buf = None
    current_key = None
    is_complex = None
    v_depth = 0
    value_start = 0
    index: dict = {}
    chunk_offset = 0

    with open(fp, "rb") as f:
        while True:
            chunk = f.read(_SIDECAR_CHUNK)
            if not chunk:
                break
            i, n = 0, len(chunk)
            while i < n:
                b = chunk[i]
                c = chr(b) if b < 128 else "\x00"
                if esc:
                    esc = False
                    if key_buf is not None:
                        key_buf.append(c)
                    i += 1
                    continue
                if in_str:
                    if c == "\\":
                        esc = True
                        if key_buf is not None:
                            key_buf.append(c)
                    elif c == '"':
                        in_str = False
                        if key_buf is not None:
                            current_key = "".join(key_buf)
                            key_buf = None
                            if state == S_SCAN:
                                state = S_COLON
                    else:
                        if key_buf is not None:
                            key_buf.append(c)
                            if len(key_buf) > _MAX_KEY_LEN:
                                key_buf = None
                    i += 1
                    continue
                if state == S_SCAN:
                    if c == '"':
                        in_str = True
                        if depth == 1 and can_be_key:
                            key_buf = []
                            can_be_key = False
                    elif c in "{[":
                        depth += 1
                        if depth == 1:
                            can_be_key = True
                    elif c in "}]":
                        depth -= 1
                    elif c == "," and depth == 1:
                        can_be_key = True
                    elif c == ":" and depth == 1:
                        can_be_key = False
                elif state == S_COLON:
                    if c == ":":
                        state = S_VALUE
                        is_complex = None
                        v_depth = 0
                    elif c == '"':
                        in_str = True
                elif state == S_VALUE:
                    if is_complex is None:
                        if c in " \t\n\r":
                            i += 1
                            continue
                        is_complex = c in "{["
                        value_start = chunk_offset + i
                    if c == '"':
                        in_str = True
                    elif is_complex:
                        if c in "{[":
                            v_depth += 1
                        elif c in "}]":
                            v_depth -= 1
                            if v_depth == 0:
                                value_end = chunk_offset + i + 1
                                if current_key is not None:
                                    index[current_key] = [value_start, value_end]
                                state = S_SCAN
                                is_complex = None
                                current_key = None
                    else:
                        if c in (",", "}", "\n", "\r", "]"):
                            value_end = chunk_offset + i
                            if current_key is not None:
                                index[current_key] = [value_start, value_end]
                            state = S_SCAN
                            is_complex = None
                            current_key = None
                            if c in "}]":
                                depth -= 1
                            elif c == "," and depth == 1:
                                can_be_key = True
                i += 1
            chunk_offset += n

    if state == S_VALUE and is_complex is not None and not is_complex:
        if current_key is not None:
            index[current_key] = [value_start, chunk_offset]
    return index


def _get_array_offset(file_path: str, key: str) -> Optional[Tuple[int, int]]:
    """Return (start_byte, end_byte) of the named top-level array. None if absent."""
    if not os.path.exists(file_path):
        return None
    sidecar = _load_sidecar(file_path)
    if sidecar is None:
        sidecar = _build_index(file_path)
        _save_sidecar(file_path, sidecar)
    entry = sidecar.get(key)
    if entry is None:
        return None
    return int(entry[0]), int(entry[1])


# ── public API ────────────────────────────────────────────────────────────────

def stream_json_array(file_path: str, key: str) -> Generator[Any, None, None]:
    """Yield items from the JSON array at *key* in *file_path* without loading
    the full array into memory.

    Algorithm
    ---------
    1. Look up (or build) the sidecar offset index for *file_path*.
    2. Seek the file pointer directly to the ``[`` that opens the array.
    3. Decode items one at a time:
       - **ijson** (preferred): streaming C-extension parser; zero extra RAM.
       - **Fallback**: ``json.JSONDecoder.raw_decode`` with a 256 KB sliding
         window and an incremental UTF-8 codec that correctly handles multi-byte
         characters at chunk boundaries.

    If *key* is not found in the file the generator yields nothing (no error).
    """
    if not os.path.exists(file_path):
        return

    offsets = _get_array_offset(file_path, key)
    if offsets is None:
        return
    start, end = offsets

    # ── preferred: ijson ─────────────────────────────────────────────────────
    try:
        import ijson as _ijson  # type: ignore[import]
        with open(file_path, "rb") as f:
            f.seek(start)
            # Positioned at '['; parse as a standalone top-level array.
            for item in _ijson.items(f, "item"):
                yield item
        return
    except ImportError:
        pass

    # ── fallback: raw_decode sliding window ───────────────────────────────────
    decoder = json.JSONDecoder()
    inc_dec = codecs.getincrementaldecoder("utf-8")("replace")

    with open(file_path, "rb") as f:
        f.seek(start)
        str_buf = ""

        def _refill() -> bool:
            """Read up to _CHUNK more bytes into str_buf. Returns True if data
            was appended, False when we have reached *end* or EOF."""
            nonlocal str_buf
            remaining = end - f.tell()
            if remaining <= 0:
                tail = inc_dec.decode(b"", final=True)
                str_buf += tail
                return False
            to_read = min(_CHUNK, remaining)
            raw = f.read(to_read)
            if not raw:
                tail = inc_dec.decode(b"", final=True)
                str_buf += tail
                return False
            is_final = f.tell() >= end
            str_buf += inc_dec.decode(raw, final=is_final)
            return True

        # Initial fill
        _refill()

        # Skip the opening '[' and any leading whitespace
        i = 0
        while i < len(str_buf) and str_buf[i] in "[ \t\n\r":
            i += 1
        str_buf = str_buf[i:]

        at_eof = False
        while True:
            # Top up the sliding window so we always have at least _CHUNK chars
            if not at_eof and len(str_buf) < _CHUNK:
                if not _refill():
                    at_eof = True

            # Skip separators (commas, whitespace) between items
            i = 0
            while i < len(str_buf) and str_buf[i] in ", \t\n\r":
                i += 1
            str_buf = str_buf[i:]

            if not str_buf:
                if at_eof:
                    break
                continue

            if str_buf[0] == "]":
                break  # end of array

            # Attempt to decode one item from the head of the buffer
            while True:
                try:
                    obj, consumed = decoder.raw_decode(str_buf)
                    str_buf = str_buf[consumed:]
                    yield obj
                    break
                except json.JSONDecodeError:
                    if at_eof:
                        return   # truncated / malformed; give up
                    if not _refill():
                        at_eof = True
