"""Non-failing blueprint consistency diagnostics for backward-only traversal."""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Set, Tuple


_TARGET_RE = re.compile(r"[A-Za-z@$_#][A-Za-z0-9@$_#]*")


def _normalize_target(raw: str) -> Optional[str]:
    text = str(raw or "").strip()
    if not text:
        return None
    text = re.sub(r"/\*.*?\*/", "", text)
    text = re.sub(r"//.*", "", text).strip()
    if not text:
        return None

    if "=" in text:
        _, text = text.split("=", 1)
        text = text.strip()
    if not text:
        return None

    text = text.split(",")[0].split()[0].strip()
    text = text.split("(")[0].strip()
    text = text.lstrip("=*&").rstrip(").,;:")
    if not text:
        return None

    m = _TARGET_RE.search(text)
    if not m:
        return None
    token = m.group(0)
    if re.fullmatch(r"R(?:1[0-5]|[0-9])", token.upper()):
        return None
    if re.fullmatch(r"[+-]?(?:0[xX][0-9A-Fa-f]+|\d+)", token):
        return None
    return token


def _build_outgoing_cfg(blocks: List[Dict[str, Any]]) -> Dict[str, Set[str]]:
    block_ids = {str(b.get("id") or "").strip() for b in blocks if str(b.get("id") or "").strip()}
    outgoing: Dict[str, Set[str]] = {bid: set() for bid in block_ids}
    for block in blocks:
        tgt = str(block.get("id") or "").strip()
        if not tgt:
            continue
        for inc in (block.get("incoming_branches") or []):
            src = str(inc.get("source") or "").strip()
            et = str(inc.get("type") or "BRANCH").upper()
            if not src or src not in block_ids:
                continue
            if et not in {"BRANCH", "FALLTHROUGH"}:
                continue
            outgoing.setdefault(src, set()).add(tgt)
    return outgoing


def _cfg_region(outgoing: Dict[str, Set[str]], entry: str) -> Set[str]:
    seen: Set[str] = set()
    queue: List[str] = [entry]
    while queue:
        cur = queue.pop(0)
        if cur in seen:
            continue
        seen.add(cur)
        for nxt in sorted(outgoing.get(cur, set())):
            if nxt not in seen:
                queue.append(nxt)
    return seen


def diagnose_blueprint_consistency(bp_data: Dict[str, Any]) -> Dict[str, Any]:
    """Return non-failing diagnostics relevant to backward-only subroutine traversal."""
    blocks = list(bp_data.get("blocks", []) or [])
    block_ids = {str(b.get("id") or "").strip() for b in blocks if str(b.get("id") or "").strip()}
    outgoing = _build_outgoing_cfg(blocks)
    edges = list((bp_data.get("call_graph", {}) or {}).get("edges", []) or [])

    return_sources = {
        str(e.get("source") or "").strip()
        for e in edges
        if str(e.get("call_type") or "").lower() == "return" and str(e.get("source") or "").strip()
    }

    missing_bas_targets: List[Tuple[str, str, int]] = []
    missing_branch_targets: List[Tuple[str, str, int]] = []
    no_anchor_regions: List[str] = []
    seen_bas_targets: Set[str] = set()

    for e in edges:
        inst = str(e.get("instruction") or "").upper()
        source = str(e.get("source") or "").strip()
        line_no = int(e.get("line") or 0)
        target_raw = str(e.get("target") or "")
        target = _normalize_target(target_raw)

        if inst in {"BAS", "BAL"}:
            if not target or target not in block_ids:
                missing_bas_targets.append((source, target_raw, line_no))
                continue
            if target in seen_bas_targets:
                continue
            seen_bas_targets.add(target)
            region = _cfg_region(outgoing, target)
            anchors = [b for b in region if b in return_sources]
            if not anchors:
                sinks = [b for b in region if not [n for n in outgoing.get(b, set()) if n in region]]
                if not sinks:
                    no_anchor_regions.append(target)

        if str(e.get("call_type") or "").lower() == "branch":
            if not target:
                continue
            if target not in block_ids:
                missing_branch_targets.append((source, target_raw, line_no))

    warnings: List[str] = []
    if missing_bas_targets:
        warnings.append(f"missing_bas_targets={len(missing_bas_targets)}")
    if missing_branch_targets:
        warnings.append(f"missing_branch_targets={len(missing_branch_targets)}")
    if no_anchor_regions:
        warnings.append(f"no_anchor_regions={len(no_anchor_regions)}")

    return {
        "summary": {
            "missing_bas_targets": len(missing_bas_targets),
            "missing_branch_targets": len(missing_branch_targets),
            "no_anchor_regions": len(no_anchor_regions),
        },
        "samples": {
            "missing_bas_targets": [
                {"source": s, "target_raw": t, "line": l}
                for (s, t, l) in missing_bas_targets[:10]
            ],
            "missing_branch_targets": [
                {"source": s, "target_raw": t, "line": l}
                for (s, t, l) in missing_branch_targets[:10]
            ],
            "no_anchor_regions": sorted(no_anchor_regions)[:10],
        },
        "warnings": warnings,
    }

