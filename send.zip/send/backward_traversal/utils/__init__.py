"""Shared utility helpers for backward-only traversal."""
