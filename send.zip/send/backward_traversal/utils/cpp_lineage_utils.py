"""Utilities for extracting C++ lineage bridge data from cpp.json blueprints.

Consumed by the backward-only runner when the traversal chain crosses into a
C++ upstream file.  No side effects — pure helpers over the blueprint dicts
that are already in memory.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple


# ── helpers ─────────────────────────────────────────────────────────────────

def _safe_str(v: Any) -> str:
    return str(v or "")


_REG_RE = re.compile(r"\bR(\d+)\b", re.IGNORECASE)


def _extract_reg_num(text: str) -> Optional[str]:
    """Return the first register number (e.g. 'R7') found in text, or None."""
    m = _REG_RE.search(text)
    if not m:
        return None
    num = int(m.group(1))
    if num > 15:
        return None
    return f"R{num}"


def _field_components(text: str) -> List[str]:
    """Normalize a field path into lowercase identifier components."""
    return [part.lower() for part in re.split(r"[^A-Za-z0-9$_@]+", _safe_str(text)) if part]


def node_terminal_base_lower(node_id: str) -> Optional[str]:
    """Derived gvl_nodes.terminal_base_lower: last identifier component of the
    node id with trailing digit-only components (array indexes, P26) stripped.

    By construction this equals the variable name for every id-suffix form the
    seed strategies test (``::X``, ``:X``, ``->X``, ``.X``, exact id, and the
    ``[N]``-stripped base forms), because X is always a plain identifier.  Used
    as an indexed exact-match CANDIDATE key; callers re-verify candidates with
    the exact strategy predicates, so over-matching here is harmless.
    """
    comps = _field_components(node_id)
    while comps and comps[-1].isdigit():
        comps.pop()
    return comps[-1] if comps else None


def node_name_base_lower(name: str) -> Optional[str]:
    """Derived gvl_nodes.name_base_lower: lower(name) with a trailing ``[N]``
    array suffix stripped (matches the strategies' ``name.split("[")[0]``)."""
    s = _safe_str(name).strip().lower()
    if not s:
        return None
    return s.split("[", 1)[0] or None


# ── public API ───────────────────────────────────────────────────────────────

def reverse_field_alias_map(bp: Dict[str, Any]) -> Dict[str, List[str]]:
    """Invert field_asm_aliases: ASM_NAME → [StructName.fieldName, ...].

    bp is the raw parsed cpp.json blueprint dict.
    """
    rev: Dict[str, List[str]] = {}
    for cpp_field, asm_name in (bp.get("field_asm_aliases") or {}).items():
        key = _safe_str(asm_name).upper()
        if key:
            rev.setdefault(key, []).append(str(cpp_field))
    return rev


def extract_asm_field_aliases(
    bp: Dict[str, Any],
    variable: str,
    transitive_vars: Iterable[str] = (),
) -> Dict[str, List[str]]:
    """Return the reverse-alias mapping filtered to the variables we care about.

    Returns: { "WK_CMO": ["Da7gl.cmSystem", ...], "LG1OSI": [...], ... }
    Only ASM names that match variable or any entry in transitive_vars are kept.
    """
    wanted: Set[str] = {_safe_str(variable).upper()}
    for v in transitive_vars:
        s = _safe_str(v).strip().upper()
        if s:
            wanted.add(s)

    rev = reverse_field_alias_map(bp)
    return {k: v for k, v in rev.items() if k in wanted}


def extract_tpf_regs_slots(
    gvl: Dict[str, Any],
    callee: str,
) -> Dict[str, Dict[str, Any]]:
    """Scan global_variable_lineage edges for TPF_regs passthrough at the given callee.

    Looks for edges of the form:
        struct_field:*::regs.rN  →  register:arg@<CALLEE>:RN    rel=assign
        struct_field:*::regs->rN →  parameter:arg@<CALLEE>:RN   rel=assign

    Returns:
        {
          "R7": {
            "cpp_sources": ["struct_field:globalLimitsUpdate::regs.r7", ...],
            "call_sites":  [{"file": "...", "line": 76, "expression": "..."}, ...]
          },
          ...
        }
    """
    if not callee or not gvl:
        return {}

    callee_upper = _safe_str(callee).upper()
    slots: Dict[str, Dict[str, Any]] = {}

    # PERF: DB-backed GVLs serve the two documented target forms
    # (register:arg@CALLEE:RN / parameter:arg@CALLEE:RN) via an indexed
    # prefix range scan instead of streaming every edge row.  The exact
    # segment predicate below still runs on the returned rows.
    _prefix_query = getattr(gvl, "query_edges_target_prefix", None)
    if callable(_prefix_query):
        _callee_lower = _safe_str(callee).lower()
        edges_iter = _prefix_query([
            f"register:arg@{_callee_lower}:",
            f"parameter:arg@{_callee_lower}:",
        ])
    else:
        edges_iter = gvl.get("edges") or []

    for e in edges_iter:
        target = _safe_str(e.get("target"))
        # Match: "register:arg@<CALLEE>:R<N>" or "parameter:arg@<CALLEE>:R<N>"
        # P3-4: use exact segment match instead of substring to avoid false positives
        # when callee_upper is a prefix of another callee name.
        # Target format is "TYPE:ARG@CALLEE:REG" — split and check segment [1] exactly.
        target_parts = target.upper().split(":")
        if len(target_parts) < 3 or target_parts[1] != f"ARG@{callee_upper}":
            continue

        # Extract register number from the last segment (e.g. "R7")
        reg = _extract_reg_num(target_parts[-1])
        if reg is None:
            continue

        entry = slots.setdefault(reg, {"cpp_sources": [], "call_sites": []})

        source = _safe_str(e.get("source"))
        if source and source not in entry["cpp_sources"]:
            entry["cpp_sources"].append(source)

        line = e.get("line")
        if line is not None:
            cs = {
                "file": _safe_str(e.get("file")),
                "line": int(line),
                "expression": _safe_str(e.get("expression")),  # P3-2: full expr; truncate at serialization
            }
            if cs not in entry["call_sites"]:
                entry["call_sites"].append(cs)

    return slots


# P41: REGNA macro region names → CE1USA canonical ECB field.
# REGNA declares EB0USER–EB7USER as 64-byte sub-regions of the CE1USA area.
# When an ASM variable is an EBnUSER region name, the corresponding C++ node
# accesses ecbptr()->ce1usa (possibly with a byte offset).  Strategy 6 maps
# these ASM region names so they reach the correct C++ seed node.
_REGNA_REGION_NAMES: frozenset = frozenset({
    "EB0USER", "EB1USER", "EB2USER", "EB3USER",
    "EB4USER", "EB5USER", "EB6USER", "EB7USER",
})
_REGNA_CE1USA_ALIAS: str = "ce1usa"

# P29: ALASW application-level switch/work area → CE1ALASW ECB pointer field.
# ASM code establishes ALASW addressability via "USING ALASW,Rx" and accesses
# fields directly by their DSECT names (e.g. ALAFLAG1, ALAFLAG2).
# C++ accesses the same bytes via ecbptr()->ce1alasw->alaflag1.  Strategy 5
# handles most ALASW fields via ->fieldname suffix matching.  Strategy 8 is a
# fallback for the ECB pointer itself ("CE1ALASW") and for ALASW-named DSECTs
# when the only GVL node is the struct-level ce1alasw pointer node.
_ALASW_ECB_POINTER: str = "ce1alasw"
_ALASW_DSECT_NAMES: frozenset = frozenset({"ALASW", "CE1ALASW"})


def find_cpp_seed_nodes(
    gvl: Dict[str, Any],
    variable: str,
    asm_field_aliases: Dict[str, List[str]],
    tpf_regs_slots: Dict[str, Dict[str, Any]],
    *,
    file_stem: Optional[str] = None,
    skip_scan_fallback: bool = False,
) -> List[str]:
    """Return global_variable_lineage node IDs that are C++ entry points for variable.

    Eight discovery strategies (combined, deduplicated):

    1. Nodes whose metadata.asm_alias == variable (scoped and unscoped).
    2. Nodes whose id/name suffix matches a field path surfaced via
       asm_field_aliases (e.g. Da7gl.cmSystem → *::da7gl->cmSystem).
       P26: trailing digit-only components (array index suffixes like [3] → "3")
       are stripped before suffix comparison so array element nodes match.
    3. Source of a global_lineage_stitch:cpp_field_to_asm edge that points at
       the ASM memory node for variable.  Uses exact suffix match (FIX 9):
       the target's terminal component must equal var_upper, not merely contain
       it — prevents false-positive seeds for short names like "R7" matching
       "R7G" or "R7_STORE".
    4. cpp_sources from tpf_regs_slots — C++ struct_field nodes that write
       the register slot used by the callee.
    5. Direct name / ID match for normalized dep_var names (FIX 11, FIX 21):
       matches nodes by exact name equality or id suffix (::name, :name, ->name).
       The ->name form finds struct fields regardless of the pointer variable
       prefix, so "cmSystem" matches both "da7gl->cmSystem" and "record->cmSystem".
       P26: also checks base form with [N] array notation stripped.
    6. P41 — REGNA region names (EB0USER–EB7USER) → ce1usa alias lookup.
       REGNA declares named 64-byte sub-regions within CE1USA.  ASM code uses
       region names while C++ accesses ecbptr()->ce1usa directly (with offsets).
       When variable is an EBnUSER name, search for nodes matching "ce1usa" so
       that the C++ GVL backward trace starts at the correct ECB field node.
    7. P28 — @MMU-prefixed GLOBZ global storage variables.  Strips leading "@"
       and matches GVL nodes by the stripped name (C++ uses tpfglbl.mmufoo).
    8. P29 — ALASW application-level work area ECB pointer.  When the variable
       is "ALASW" or "CE1ALASW" (the struct-level DSECT name rather than an
       individual field), search for GVL nodes matching "ce1alasw" so that the
       backward trace reaches the ECB pointer field node.
    """
    # ── DB-backed fast path ────────────────────────────────────────────────
    # When the cpp_seed_keys index exists, use it instead of scanning the
    # full GVL.  Only applicable when asm_field_aliases and tpf_regs_slots
    # are empty (the dep_var path always passes {} for both — Strategies 2
    # and 4 are never triggered).
    if not asm_field_aliases and not tpf_regs_slots:
        try:
            from api.index_db.readers import get_cpp_seed_node_ids
            _job_id = getattr(gvl, "_job_id", None)
            if _job_id:
                db_seeds = get_cpp_seed_node_ids(
                    _job_id, variable, file_stem=file_stem,
                )
                if db_seeds is not None:  # None = index unavailable
                    if db_seeds:
                        return db_seeds  # Non-empty — use DB result
                    # DB returned [] — fall through to scan-based fallback.
                    # The DB index may not cover every variable (short names,
                    # edge cases, stale index).  Let Strategies 1-8 try.
                    #
                    # Opt C: When skip_scan_fallback=True (dep_var path), return
                    # empty immediately.  For the dep_var path, Strategies 2 & 4
                    # are disabled (empty asm_field_aliases/tpf_regs_slots) and
                    # Strategies 1, 3, 5, 6, 7, 8 are fully indexed in the DB.
                    # The scan can never find seeds the DB missed.
                    if skip_scan_fallback:
                        import logging as _logging
                        _logging.getLogger(__name__).debug(
                            "find_cpp_seed_nodes: DB returned 0 seeds for '%s'%s "
                            "(skip_scan_fallback=True — returning empty)",
                            _safe_str(variable).upper(),
                            f" in file_stem={file_stem}" if file_stem else "",
                        )
                        return []
                    import logging as _logging
                    _logging.getLogger(__name__).debug(
                        "find_cpp_seed_nodes: DB index returned 0 seeds for '%s'%s, "
                        "falling through to scan",
                        _safe_str(variable).upper(),
                        f" in file_stem={file_stem}" if file_stem else "",
                    )
        except Exception:
            pass  # fall through to scan

    # ── Original scan-based logic (fallback) ───────────────────────────────
    var_upper = _safe_str(variable).upper()
    var_lower = var_upper.lower()
    seeds: List[str] = []
    seen: Set[str] = set()

    def _add(nid: str) -> None:
        s = _safe_str(nid).strip()
        if s and s not in seen:
            seen.add(s)
            seeds.append(s)

    # Pre-compute alias_paths for Strategy 2 (avoids recomputing inside loop).
    alias_paths = [
        _field_components(field_path)
        for field_paths in asm_field_aliases.values()
        for field_path in field_paths
        if _field_components(field_path)
    ]

    # GAP-034 skip kinds for Strategy 5.
    # "parameter" was previously skipped here, but parameters are valid seeds:
    #   - Output parameters (*ptr written inside the callee) have assign edges
    #     in their defining file — _filter_seeds_to_file keeps them correctly.
    #   - Input parameters have no assign edges in the modifier file, so
    #     _filter_seeds_to_file drops them (stem_seen_anywhere guard), and
    #     _scope_cpp_trace_to_file removes any stray cross-file setter edges.
    # Keeping parameter seeds enables cross-file traversal where the variable
    # is a function parameter of the called (modifier) file.
    _STRATEGY5_SKIP_KINDS: Set[str] = {"call_arg", "return_value", "register"}

    # ── Single pass over nodes (Strategies 1, 2, 5) ──────────────────────────
    # Previously three separate loops; merged into one so that streaming
    # LazyGVL iterables only cause a single disk pass over the "nodes" section.
    for n in (gvl.get("nodes") or []):
        meta = n.get("metadata") or {}
        nid = _safe_str(n.get("id"))
        name = _safe_str(n.get("name"))
        nid_str = nid or name

        # Strategy 1: metadata.asm_alias
        alias = _safe_str(meta.get("asm_alias")).upper()
        if alias == var_upper:
            _add(nid_str)
            continue  # no need to check other strategies for this node

        # Strategy 2: field alias suffix match
        # P26: also try with trailing digit-only components stripped so that C++ array
        # node IDs like "cyclicallimitsbyse[3]" (→ parts ["cyclicallimitsbyse","3"])
        # match the alias path ["cyclicallimitsbyse"] derived from asm_field_aliases.
        if alias_paths:
            id_parts = _field_components(nid)
            name_parts = _field_components(name)
            # Strip trailing digit-only components (array index suffixes from [N] notation)
            id_parts_nodigit = id_parts[:]
            while id_parts_nodigit and id_parts_nodigit[-1].isdigit():
                id_parts_nodigit = id_parts_nodigit[:-1]
            name_parts_nodigit = name_parts[:]
            while name_parts_nodigit and name_parts_nodigit[-1].isdigit():
                name_parts_nodigit = name_parts_nodigit[:-1]
            matched = False
            for alias_parts in alias_paths:
                alen = len(alias_parts)
                if ((len(id_parts) >= alen and id_parts[-alen:] == alias_parts)
                        or (len(name_parts) >= alen and name_parts[-alen:] == alias_parts)
                        or (len(id_parts_nodigit) >= alen and id_parts_nodigit[-alen:] == alias_parts)
                        or (len(name_parts_nodigit) >= alen and name_parts_nodigit[-alen:] == alias_parts)):
                    _add(nid_str)
                    matched = True
                    break
            if matched:
                continue

        # Strategy 5 (FIX 11 + FIX 21): direct name or normalized ID match.
        # GAP-034: skip transient-node kinds.
        # P26: also strip array index notation [N] from nid/nname before comparison
        # so that GVL nodes like "lg1cycl[3]" match the ASM variable "LG1CYCL".
        n_kind = _safe_str(meta.get("kind") or n.get("kind") or "").lower()
        if n_kind and n_kind in _STRATEGY5_SKIP_KINDS:
            continue
        nname = name.lower()
        nid_lower = nid.lower()
        # Base forms with array index notation stripped (P26)
        nid_base = nid_lower.split("[")[0]
        nname_base = nname.split("[")[0]
        if (nname == var_lower
                or nname_base == var_lower
                or nid_lower == var_lower
                or nid_base == var_lower
                or nid_lower.endswith(f"::{var_lower}")
                or nid_base.endswith(f"::{var_lower}")
                or nid_lower.endswith(f":{var_lower}")
                or nid_base.endswith(f":{var_lower}")
                # GAP-012: raised ->name threshold from 4 → 6 chars.
                or (len(var_lower) >= 6 and nid_lower.endswith(f"->{var_lower}"))
                or (len(var_lower) >= 6 and nid_base.endswith(f"->{var_lower}"))
                # Dot-notation struct field paths (e.g. plasticAuth.process.transactionInds.softCardValue).
                # C++ struct member access via '.' produces node IDs ending with .fieldname rather than
                # ::fieldname or ->fieldname.  Apply the same ≥6 char guard to limit false positives.
                or (len(var_lower) >= 6 and nid_lower.endswith(f".{var_lower}"))
                or (len(var_lower) >= 6 and nid_base.endswith(f".{var_lower}"))):
            _add(nid_str)

    # Strategy 3: cpp_field_to_asm stitching edges → source is the C++ node.
    # FIX 9: exact suffix match on target terminal component.
    # Single pass over edges (iterable may be a streaming LazyGVL).
    for e in (gvl.get("edges") or []):
        expr = _safe_str(e.get("expression"))
        if "cpp_field_to_asm" not in expr:
            continue
        tgt_raw = _safe_str(e.get("target"))
        tgt_terminal = tgt_raw.split(":")[-1].upper()
        if tgt_terminal != var_upper:
            continue
        _add(_safe_str(e.get("source")))

    # Strategy 4: TPF_regs cpp_sources (no GVL access — pre-computed dict)
    for slot_data in tpf_regs_slots.values():
        for src in (slot_data.get("cpp_sources") or []):
            _add(str(src))

    # Strategy 6 (P41): REGNA region name → CE1USA node lookup.
    # EB0USER–EB7USER are REGNA-declared 64-byte sub-regions of the CE1USA ECB
    # field.  C++ accesses the same bytes via ecbptr()->ce1usa (possibly with a
    # byte offset), so the GVL node will carry the name "ce1usa", not "eb0user".
    # When Strategies 1-5 found nothing and the variable is an EBnUSER name,
    # fall back to searching for the ce1usa node so the backward trace has a
    # starting point in the C++ GVL.
    if not seeds and var_upper in _REGNA_REGION_NAMES:
        for n in (gvl.get("nodes") or []):
            nid = _safe_str(n.get("id")).lower()
            nname = _safe_str(n.get("name")).lower()
            if (nname == _REGNA_CE1USA_ALIAS
                    or nid == _REGNA_CE1USA_ALIAS
                    or nid.endswith(f"::{_REGNA_CE1USA_ALIAS}")
                    or nid.endswith(f":{_REGNA_CE1USA_ALIAS}")
                    or nid.endswith(f"->{_REGNA_CE1USA_ALIAS}")):
                sid = _safe_str(n.get("id") or n.get("name") or "").strip()
                if sid:
                    _add(sid)

    # Strategy 7 (P28): @MMU-prefixed global storage variables (GLOBZ / TPFGLB).
    # GLOBZ declares a base register over the z/TPF global storage area; DSECT symbols
    # within the COPY TPFGLB source have names beginning with "@MMU" (e.g. @MMUFOO).
    # In C++ the same field is accessed as tpfglbl.mmufoo (without the "@" prefix).
    # Strategy 5 won't match because the GVL node name is "mmufoo" while the ASM
    # variable is "@MMUFOO".  When Strategies 1-6 all fail and the name starts with "@",
    # try matching GVL nodes by the name with the leading "@" stripped (length ≥ 4 to
    # avoid spurious matches on very short tokens like "@X").
    if not seeds and var_upper.startswith("@"):
        stripped_lower = var_lower.lstrip("@")
        if len(stripped_lower) >= 4:
            for n in (gvl.get("nodes") or []):
                nid = _safe_str(n.get("id")).lower()
                nname = _safe_str(n.get("name")).lower()
                if (nname == stripped_lower
                        or nid == stripped_lower
                        or nid.endswith(f"::{stripped_lower}")
                        or nid.endswith(f":{stripped_lower}")
                        or nid.endswith(f"->{stripped_lower}")):
                    sid = _safe_str(n.get("id") or n.get("name") or "").strip()
                    if sid:
                        _add(sid)

    # Strategy 8 (P29): ALASW DSECT/struct name → ce1alasw ECB pointer node.
    # When the variable is "ALASW" or "CE1ALASW" (the DSECT name itself, not an
    # individual field within it), Strategies 1–7 typically find no seed because the
    # GVL has a node for the ECB pointer field "ce1alasw" rather than for the struct
    # type "Alasw".  Fall back to searching for ce1alasw nodes so the backward trace
    # reaches the ECB pointer field from which all ALASW field accesses originate.
    if not seeds and var_upper in _ALASW_DSECT_NAMES:
        for n in (gvl.get("nodes") or []):
            nid = _safe_str(n.get("id")).lower()
            nname = _safe_str(n.get("name")).lower()
            if (nname == _ALASW_ECB_POINTER
                    or nid == _ALASW_ECB_POINTER
                    or nid.endswith(f"::{_ALASW_ECB_POINTER}")
                    or nid.endswith(f":{_ALASW_ECB_POINTER}")
                    or nid.endswith(f"->{_ALASW_ECB_POINTER}")):
                sid = _safe_str(n.get("id") or n.get("name") or "").strip()
                if sid:
                    _add(sid)

    # C2.1 fix: warn when all strategies fail so the empty trace is not silent.
    if not seeds:
        import logging as _logging
        _logging.getLogger(__name__).warning(
            "find_cpp_seed_nodes: no seed nodes found for '%s' after all 8 strategies — "
            "C++ backward BFS will be empty. Verify that the GVL contains nodes with "
            "asm_alias, cpp_field_to_asm edges, or a direct name/id match for this variable.",
            var_upper,
        )
    return seeds


# ── DB-backed seed finding (tier-2 fast path) ────────────────────────────────
# On corpora whose GVL exceeds the in-RAM projection caps, streaming the whole
# node section per variable is the dominant cost of the dep-var BFS.  When the
# GVL lives in index.db with the derived seed-lookup columns
# (terminal_base_lower / name_base_lower / asm_alias_lower — see
# node_terminal_base_lower above), seed finding becomes a handful of indexed
# exact-match queries returning a small CANDIDATE superset, which is then
# re-verified with the SAME predicates the streaming strategies use — so the
# result (including ordering, which follows row id = GVL emission order) is
# identical to find_cpp_seed_nodes for the dep-var case (empty
# asm_field_aliases / tpf_regs_slots, i.e. Strategies 2 and 4 inactive).

import json as _json
import os as _os
import sqlite3 as _sqlite3
import threading as _threading

_DB_SEED_LOCK = _threading.Lock()


def _db_seed_enabled() -> bool:
    """Kill-switch: ASM_USE_DB_SEED_INDEX=0 disables the DB tier entirely
    (callers fall back to the projection/streaming paths).  Read per call so
    tests and operators can toggle it without restarting the process."""
    return _os.environ.get(
        "ASM_USE_DB_SEED_INDEX", "1"
    ).strip().lower() not in ("0", "false", "no", "off")
# (db_path, job_id) → {"conn": ro-connection|None, "ready": bool,
#                      "stitch": [(rowid, source, target_terminal_upper)]|None}
_DB_SEED_STATE: Dict[Tuple[str, str], Dict[str, Any]] = {}


def _db_seed_state(db_path: str, job_id: str) -> Optional[Dict[str, Any]]:
    if not _db_seed_enabled():
        return None
    key = (str(db_path), str(job_id))
    st = _DB_SEED_STATE.get(key)
    if st is not None:
        return st if st.get("ready") else None
    st = {"conn": None, "ready": False, "stitch": None}
    _DB_SEED_STATE[key] = st
    try:
        conn = _sqlite3.connect(
            f"file:{db_path}?mode=ro", uri=True, check_same_thread=False
        )
        conn.execute("PRAGMA busy_timeout=5000")
        cols = {r[1] for r in conn.execute("PRAGMA table_info(gvl_nodes)").fetchall()}
        if not {"terminal_base_lower", "name_base_lower", "asm_alias_lower"} <= cols:
            conn.close()
            return None
        edge_cols = {r[1] for r in conn.execute("PRAGMA table_info(gvl_edges)").fetchall()}
        if "file_stem" not in edge_cols:
            conn.close()
            return None
        row = conn.execute(
            "SELECT 1 FROM gvl_nodes WHERE job_id = ? "
            "AND terminal_base_lower IS NOT NULL LIMIT 1",
            (job_id,),
        ).fetchone()
        if row is None:
            conn.close()
            return None  # job not ingested/backfilled with derived columns
        st["conn"] = conn
        st["ready"] = True
        return st
    except Exception:
        return None


def _db_seed_candidates(
    st: Dict[str, Any], job_id: str, token_lower: str
) -> List[Tuple[int, str, str, str, str]]:
    """Indexed candidate rows for one name token, ordered by row id
    (= GVL emission order).  Returns (rowid, node_id, name, kind, extra_json).

    Queries each derived column with both the raw token and the token's own
    terminal-base form: variables containing characters outside the component
    charset (e.g. ``#LTBKLN`` — ``#`` is a splitter) store their LAST component
    in terminal_base_lower, so the raw token alone would miss them.  The union
    stays a superset; callers re-verify with exact predicates.
    """
    conn = st["conn"]
    tokens = {token_lower}
    _tb = node_terminal_base_lower(token_lower)
    if _tb:
        tokens.add(_tb)
    rows: Dict[int, Tuple[int, str, str, str, str]] = {}
    for tok in tokens:
        for col in ("terminal_base_lower", "name_base_lower", "asm_alias_lower"):
            cur = conn.execute(
                f"SELECT id, node_id, name, kind, extra_json FROM gvl_nodes "
                f"WHERE job_id = ? AND {col} = ?",
                (job_id, tok),
            )
            for r in cur.fetchall():
                rows[r[0]] = r
    return [rows[k] for k in sorted(rows)]


def _candidate_meta(extra_json: Optional[str]) -> Dict[str, Any]:
    if not extra_json:
        return {}
    try:
        extra = _json.loads(extra_json)
        meta = extra.get("metadata") if isinstance(extra, dict) else None
        if isinstance(meta, dict):
            return meta
        return extra if isinstance(extra, dict) else {}
    except Exception:
        return {}


def _matches_strategy5(nid_lower: str, nname_lower: str, var_lower: str) -> bool:
    """Exact Strategy-5 predicate (mirrors the streaming loop, incl. P26/GAP-012)."""
    nid_base = nid_lower.split("[")[0]
    nname_base = nname_lower.split("[")[0]
    return (nname_lower == var_lower
            or nname_base == var_lower
            or nid_lower == var_lower
            or nid_base == var_lower
            or nid_lower.endswith(f"::{var_lower}")
            or nid_base.endswith(f"::{var_lower}")
            or nid_lower.endswith(f":{var_lower}")
            or nid_base.endswith(f":{var_lower}")
            or (len(var_lower) >= 6 and nid_lower.endswith(f"->{var_lower}"))
            or (len(var_lower) >= 6 and nid_base.endswith(f"->{var_lower}"))
            or (len(var_lower) >= 6 and nid_lower.endswith(f".{var_lower}"))
            or (len(var_lower) >= 6 and nid_base.endswith(f".{var_lower}")))


def _matches_simple_suffix(nid_lower: str, nname_lower: str, token: str) -> bool:
    """Exact Strategy-6/7/8 predicate (equality or ::/:/-> suffix)."""
    return (nname_lower == token
            or nid_lower == token
            or nid_lower.endswith(f"::{token}")
            or nid_lower.endswith(f":{token}")
            or nid_lower.endswith(f"->{token}"))


def _matches_fix16_fallback(nid_lower: str, nname_lower: str, dep_lower: str) -> bool:
    """Exact FIX 16 fallback predicate from _build_dep_var_cpp_result."""
    return (nid_lower.endswith(f"::{dep_lower}")
            or (len(dep_lower) >= 4 and nid_lower.endswith(f"->{dep_lower}"))
            or nname_lower == dep_lower)


_DB_STRATEGY5_SKIP_KINDS: Set[str] = {"call_arg", "return_value", "register"}


def find_cpp_seed_nodes_db(
    db_path: str,
    job_id: str,
    variable: str,
    include_fix16_fallback: bool = True,
) -> Optional[List[str]]:
    """DB-backed equivalent of find_cpp_seed_nodes for the dep-var case
    (Strategies 1, 3, 5, 6, 7, 8 — callers pass empty aliases/tpf slots) plus,
    when *include_fix16_fallback*, the runner's FIX 16 fallback scan.

    Returns None when the DB/derived columns are unavailable — the caller
    falls back to the streaming/projection path.  Returns a (possibly empty)
    list otherwise, in the same order the streaming scan would produce.
    """
    var_upper = _safe_str(variable).upper()
    var_lower = var_upper.lower()
    if not var_lower:
        return []

    with _DB_SEED_LOCK:
        st = _db_seed_state(str(db_path), str(job_id))
        if st is None:
            return None

        seeds: List[str] = []
        seen: Set[str] = set()

        def _add(nid: str) -> None:
            s = _safe_str(nid).strip()
            if s and s not in seen:
                seen.add(s)
                seeds.append(s)

        # ── Strategies 1 + 5 (single candidate pass, row-id order) ────────
        cands = _db_seed_candidates(st, job_id, var_lower)
        for _rowid, nid_raw, name_raw, kind_raw, extra_json in cands:
            nid = _safe_str(nid_raw)
            name = _safe_str(name_raw)
            nid_str = nid or name
            meta = _candidate_meta(extra_json)
            alias = _safe_str(meta.get("asm_alias")).upper()
            if alias == var_upper:           # Strategy 1
                _add(nid_str)
                continue
            n_kind = _safe_str(meta.get("kind") or kind_raw or "").lower()
            if n_kind and n_kind in _DB_STRATEGY5_SKIP_KINDS:
                continue
            if _matches_strategy5(nid.lower(), name.lower(), var_lower):
                _add(nid_str)

        # ── Strategy 3: cpp_field_to_asm stitch edges (cached per job) ────
        if st["stitch"] is None:
            stitch: List[Tuple[str, str]] = []
            try:
                cur = st["conn"].execute(
                    "SELECT source, target FROM gvl_edges "
                    "WHERE job_id = ? AND expression LIKE '%cpp_field_to_asm%' "
                    "ORDER BY id",
                    (job_id,),
                )
                for src, tgt in cur.fetchall():
                    stitch.append((
                        _safe_str(src),
                        _safe_str(tgt).split(":")[-1].upper(),
                    ))
            except Exception:
                stitch = []
            st["stitch"] = stitch
        for src, tgt_terminal in st["stitch"]:
            if tgt_terminal == var_upper:
                _add(src)

        # ── Strategies 6 / 7 / 8 (only when nothing found, like streaming) ─
        def _suffix_pass(token: str) -> None:
            for _rowid, nid_raw, name_raw, _kind_raw, _ej in _db_seed_candidates(
                st, job_id, token
            ):
                nid_l = _safe_str(nid_raw).lower()
                name_l = _safe_str(name_raw).lower()
                if _matches_simple_suffix(nid_l, name_l, token):
                    sid = _safe_str(nid_raw or name_raw).strip()
                    if sid:
                        _add(sid)

        if not seeds and var_upper in _REGNA_REGION_NAMES:
            _suffix_pass(_REGNA_CE1USA_ALIAS)
        if not seeds and var_upper.startswith("@"):
            stripped_lower = var_lower.lstrip("@")
            if len(stripped_lower) >= 4:
                _suffix_pass(stripped_lower)
        if not seeds and var_upper in _ALASW_DSECT_NAMES:
            _suffix_pass(_ALASW_ECB_POINTER)

        # ── FIX 16 fallback (runner semantics: only when still empty) ─────
        if not seeds and include_fix16_fallback:
            for _rowid, nid_raw, name_raw, _kind_raw, _ej in cands:
                nid_l = _safe_str(nid_raw).lower()
                name_l = _safe_str(name_raw).lower()
                if _matches_fix16_fallback(nid_l, name_l, var_lower):
                    sid = _safe_str(nid_raw or name_raw).strip()
                    if sid:
                        _add(sid)

        return seeds


def db_setter_targets_for_stem(
    db_path: str, job_id: str, stem_lower: str
) -> Optional[Tuple[Set[str], bool]]:
    """DB-backed equivalent of the _filter_seeds_to_file edge scan for one stem.

    Returns ``(setter_edge_targets_in_stem, stem_seen_anywhere)`` via the
    ``(job_id, relation, file_stem)`` index, or None when the DB/columns are
    unavailable (caller falls back to projection/streaming).  Results are
    cached per (db, job, stem) — a chain has a handful of stems, each holding
    only that file's setter targets (small).
    """
    with _DB_SEED_LOCK:
        st = _db_seed_state(str(db_path), str(job_id))
        if st is None:
            return None
        cache: Dict[str, Tuple[Set[str], bool]] = st.setdefault("stem_targets", {})
        hit = cache.get(stem_lower)
        if hit is not None:
            return hit
        try:
            cur = st["conn"].execute(
                "SELECT DISTINCT target FROM gvl_edges "
                "WHERE job_id = ? AND relation IN ('assign', 'define', 'arg_bind') "
                "AND file_stem = ?",
                (job_id, stem_lower),
            )
            rows = cur.fetchall()
        except Exception:
            return None
        seen = bool(rows)
        targets = {
            str(r[0]).strip() for r in rows if r[0] and str(r[0]).strip()
        }
        cache[stem_lower] = (targets, seen)
        return targets, seen


def db_seed_index_ready(db_path: str, job_id: str) -> bool:
    """True when the derived-column seed index is queryable for this job
    (columns exist, rows backfilled).  Cheap: probes once per (db, job) and
    caches the answer (same state as lookup paths)."""
    with _DB_SEED_LOCK:
        return _db_seed_state(str(db_path), str(job_id)) is not None


def close_db_seed_state() -> None:
    """Close cached read-only seed-lookup connections (end-of-task hygiene)."""
    with _DB_SEED_LOCK:
        for st in _DB_SEED_STATE.values():
            conn = st.get("conn")
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
        _DB_SEED_STATE.clear()



def build_chain_neighbor_set(
    selected_chain: List[str],
    call_graph_path: Path,
    max_hops: int = 2,
) -> Set[str]:
    """Return all file stems reachable within *max_hops* of any stem in
    *selected_chain* via the ``file_call_graph``.

    Used by T9 to bound the T8 candidate scan to files that are actually nearby
    in the call graph, limiting I/O to O(30) typical neighbours instead of
    O(N_cpp_files) at a 10K-file codebase.

    The graph is treated as **undirected** for reachability — a stem is included
    whether it calls a chain file or is called by one.

    Fallback: if *call_graph_path* does not exist or cannot be read, returns
    ``set(selected_chain)`` (no filtering beyond the chain itself).  This is
    safe — T8 then operates only on chain files, which already have blueprints
    loaded.

    Memory: streams the "edges" array from ``file_call_graph.json`` one item at
    a time via ``stream_json_array`` so that the full 100–200 MB file is never
    held in RAM as a Python dict.
    """
    if not call_graph_path or not call_graph_path.exists():
        return set(selected_chain)

    # Build adjacency index: stem → {neighbour stems} (undirected).
    # Stream edges rather than loading the whole file (can be 100–200 MB).
    adjacency: Dict[str, Set[str]] = {}
    try:
        from backward_traversal.utils.stream_json import stream_json_array
        for edge in stream_json_array(str(call_graph_path), "edges"):
            src = str(edge.get("source", "") or "").strip()
            tgt = str(edge.get("target", "") or "").strip()
            if src and tgt:
                adjacency.setdefault(src, set()).add(tgt)
                adjacency.setdefault(tgt, set()).add(src)
    except Exception:
        return set(selected_chain)   # fallback: no graph-distance filtering

    # Multi-source BFS: seed from all chain stems simultaneously
    visited: Set[str] = set(selected_chain)
    frontier: Set[str] = set(selected_chain)
    for _ in range(max_hops):
        next_frontier: Set[str] = set()
        for stem in frontier:
            for neighbour in adjacency.get(stem, set()):
                if neighbour not in visited:
                    visited.add(neighbour)
                    next_frontier.add(neighbour)
        frontier = next_frontier
        if not frontier:
            break

    return visited


def find_cpp_files_for_dep_var(
    dep_var: str,
    blueprint_dir: Path,
    file_type_map: Dict[str, str],
    max_scan: int = 0,
    neighbor_set: Optional[Set[str]] = None,
) -> List[str]:
    """Scan C++ blueprints outside the selected chain for *dep_var* seeds.

    Returns a list of file stems whose GVL contains at least one seed node for
    *dep_var* (Strategy 1–5 via ``find_cpp_seed_nodes``).

    **PRODUCTION WARNING:** ``max_scan > 0`` without ``neighbor_set`` filtering
    causes O(max_dep_vars × max_scan) blueprint reads per call.  At 10K+ files
    with ``max_scan=50``: ~27GB disk I/O — do **not** enable without T9.
    Use ``build_chain_neighbor_set()`` to build *neighbor_set* before the dep_var
    BFS loop and pass it here.

    Parameters
    ----------
    dep_var:
        Normalized C++ field name (FIX 11/21 stripped).
    blueprint_dir:
        Directory containing ``*.cpp.json`` blueprints.
    file_type_map:
        ``{stem: "cpp" | "asm"}`` mapping from the call graph payload.
    max_scan:
        Maximum number of C++ blueprints to inspect.  Default **0** (disabled).
        FIX 18: do not raise above 0 without either (a) a small codebase (≤500
        C++ files) or (b) *neighbor_set* built via ``build_chain_neighbor_set()``.
    neighbor_set:
        When provided (T9), only candidates inside this set are scanned.
        Limits inspection to ≤ ``max_hops``-hop neighbours of the selected chain
        — typically 5–30 files — regardless of *max_scan*.
    """
    if max_scan <= 0:
        return []

    # ── DB fast path: skip blueprint loading entirely ──────────────────────
    try:
        from api.index_db.readers import get_cpp_seed_candidate_files
        from api.index_db.engine import job_id_from_path
        _job_id = job_id_from_path(blueprint_dir)
        if _job_id:
            db_stems = get_cpp_seed_candidate_files(
                _job_id, dep_var,
                neighbor_set=neighbor_set,
                limit=max_scan,
            )
            if db_stems is not None:  # None = index unavailable
                cpp_set = {s for s, t in file_type_map.items() if t == "cpp"}
                db_stems = [s for s in db_stems if s in cpp_set]
                return db_stems
    except Exception:
        pass  # fall through to scan

    # ── Original blueprint-scanning logic (fallback) ───────────────────────
    from backward_traversal.utils.blueprint_utils import load_json, resolve_cpp_blueprint

    candidates = [s for s, t in file_type_map.items() if t == "cpp"]
    if neighbor_set is not None:
        candidates = [s for s in candidates if s in neighbor_set]
    candidates = sorted(candidates)[:max_scan]

    found: List[str] = []
    # Local cache: same (gvl instance, dep_var) pair scanned at most once.
    _local_seed_cache: Dict[tuple, list] = {}
    for stem in candidates:
        bp_path = resolve_cpp_blueprint(stem, blueprint_dir)
        if not bp_path:
            continue
        try:
            bp = load_json(bp_path)   # hits FIX 5 LRU cache
        except Exception:
            continue
        from backward_traversal.utils.lazy_gvl import make_lazy_gvl
        gvl = make_lazy_gvl(bp, bp_path)
        _ck = (id(gvl), dep_var.lower())
        if _ck in _local_seed_cache:
            seeds = _local_seed_cache[_ck]
        else:
            seeds = find_cpp_seed_nodes(gvl, dep_var, {}, {})
            _local_seed_cache[_ck] = seeds
        if seeds:
            found.append(stem)

    return found
