"""Variable-name resolution via the pre-built variable_identity_index.json."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, ClassVar, Dict, List, Optional, Tuple

# Blueprint utils imported lazily inside methods to avoid circular imports.
# resolve_cpp_blueprint and load_json are imported on first use.

# ── module constants ─────────────────────────────────────────────────────────

_CPP_ALIAS_CACHE_MAX = 128   # per-instance C++ alias map cache ceiling (T6)
_ARG_BIND_CACHE_MAX  = 256   # per-instance arg_bind / struct-canonical cache (T10/T11)

# PERF: TOTAL item budget per projected GVL (arg_bind edges + parameter +
# struct_field nodes).  Beyond this the resolver keeps the original streaming
# scans so RAM stays bounded on enormous GVLs.  Projected items hold original
# node dicts (~0.5-1 KB each) → default 300K keeps one projection under
# ~300 MB; in practice a run touches ONE global GVL.
_RESOLVER_PROJ_CAP = int(os.environ.get("ASM_RESOLVER_PROJ_CAP", "300000"))


# ── module-level helpers ─────────────────────────────────────────────────────

def _parse_arg_bind_target(target_str: str) -> Tuple[Optional[str], Optional[int]]:
    """Parse ``call_arg:funcName#N`` into ``(funcName, N)`` or ``(None, None)``.

    arg_bind edges in the GVL use ``call_arg:funcName#argIndex`` as the target.
    N is the 0-based argument position.
    Returns ``(None, None)`` if the string does not match the expected format.
    """
    if not target_str.startswith("call_arg:"):
        return None, None
    rest = target_str[len("call_arg:"):]
    if "#" not in rest:
        return None, None
    func_name, _, idx_str = rest.rpartition("#")
    try:
        return func_name, int(idx_str)
    except (ValueError, TypeError):
        return None, None


class VariableNameResolver:
    """Resolve what a variable is called inside a target file using the identity index.

    The index is loaded once per process (class-level cache keyed by absolute path).

    T6: C++ fallback via ``field_asm_aliases`` in the target C++ blueprint.
        Case A — ASM name  → C++ field name (reverse lookup).
        Case B — C++ field → ASM name       (forward lookup).

    T10: Case C — pure C++→C++ rename via ``arg_bind`` parameter binding.
        Uses ``arg_bind`` edges in the source GVL to find which argument position
        the dep_var occupies, then finds the parameter name at that position in
        the target GVL.

    T11: Case D — struct field canonical matching via ``(enclosing_type, field_name)``.
        Uses ``metadata.enclosing_type`` already emitted by the parser on all
        ``struct_field``-kind GVL nodes to match fields across files even when the
        pointer variable name or field name differs.
    """

    _cache: ClassVar[Dict[str, Optional[Dict]]] = {}
    _INDEX_CACHE_MAX: ClassVar[int] = 16  # max unique index files held in-memory

    def __init__(self, blueprint_dir: Path) -> None:
        self._path: Optional[Path] = self._find_index_path(blueprint_dir)
        self._job_id: Optional[str] = (
            self._derive_job_id(self._path)
            or self._derive_job_id(blueprint_dir)  # fallback: derive from blueprint_dir when index file was deleted after DB ingest
        )
        self._index: Optional[Dict] = None
        self._index_loaded: bool = False
        self._blueprint_dir: Optional[Path] = blueprint_dir          # T6
        self._cpp_alias_cache: Dict[str, Dict] = {}                   # T6
        self._arg_bind_cache: Dict[Tuple[str, str, str], Optional[str]] = {}  # T10 Case C
        self._struct_canonical_cache: Dict[Tuple[str, str, str], Optional[str]] = {}  # T11 Case D (FIX-new-4)
        # PERF: per-GVL-instance projections (arg_bind edges, parameter nodes,
        # struct_field nodes) — see _gvl_projection.  Holds the gvl instance so
        # id() keys cannot be recycled; lives only as long as this resolver.
        self._gvl_proj_cache: Dict[int, Tuple[Any, Optional[Dict[str, Any]]]] = {}
        # PERF: canonical_name maps for T12 (_resolve_via_variable_canonical),
        # keyed by GVL identity — see _get_canonical_maps.  Bounded by the
        # number of canonical-bearing variable nodes (KBs).
        self._canonical_maps_cache: Dict[str, Tuple[Dict[str, str], Dict[str, str]]] = {}

    @classmethod
    def from_path(
        cls,
        path_str: str,
        blueprint_dir: Optional[Path] = None,
    ) -> "VariableNameResolver":
        """Reconstruct from a stored path string (e.g., from session msgpack state).

        ``blueprint_dir`` is optional; pass it so Cases A/B/C/D can function.
        """
        inst: "VariableNameResolver" = object.__new__(cls)
        inst._path = Path(path_str) if path_str else None
        inst._job_id = cls._derive_job_id(inst._path)
        inst._index = None
        inst._index_loaded = False
        inst._blueprint_dir = blueprint_dir                           # T6
        inst._cpp_alias_cache = {}                                    # T6
        inst._arg_bind_cache = {}                                     # T10 Case C
        inst._struct_canonical_cache = {}                             # T11 Case D (FIX-new-4)
        inst._gvl_proj_cache = {}                                     # PERF projections
        inst._canonical_maps_cache = {}                               # T12 canonical maps
        return inst

    # ------------------------------------------------------------------
    # PERF — per-GVL projections for Cases C/D
    # ------------------------------------------------------------------

    def _gvl_projection(self, gvl: Any) -> Optional[Dict[str, Any]]:
        """One streaming pass per GVL instance extracting only what Cases C/D
        scan for: arg_bind edges, parameter nodes (grouped by enclosing
        function), and struct_field nodes.

        Cases C/D previously re-streamed the ENTIRE GVL (DB fetchone +
        json.loads per row for DB-backed GVLs) on every cache-miss resolve —
        profiled as the top cost of the dep-var BFS after seed scanning.  GVL
        instances are process-cached (lazy_gvl._LAZY_GVL_CACHE), so this
        projection is built once per run in practice.

        Returns None (→ callers keep the original streaming scans) when the
        projected subsets exceed _RESOLVER_PROJ_CAP nodes.
        """
        key = id(gvl)
        hit = self._gvl_proj_cache.get(key)
        if hit is not None:
            return hit[1]

        # Tier 1 (scale): build the projection from indexed DB queries when the
        # GVL is DB-backed — no full-GVL pass at all.  May return a projection
        # whose "struct_fields" is None (over budget): Case D then streams
        # while Case C stays fast.
        proj = self._build_projection_from_db(gvl)
        if proj is not None:
            self._gvl_proj_cache[key] = (gvl, proj)
            return proj

        proj = None
        try:
            count = 0
            over_cap = False
            arg_edges: List[Tuple[str, str]] = []
            for e in (gvl.get("edges") or []):
                if str(e.get("relation", "")).lower() != "arg_bind":
                    continue
                count += 1
                if count > _RESOLVER_PROJ_CAP:
                    over_cap = True
                    break
                arg_edges.append(
                    (str(e.get("source", "")).lower(), str(e.get("target", "")))
                )
            params_by_fn: Dict[str, List[Dict[str, Any]]] = {}
            struct_fields: List[Dict[str, Any]] = []
            if not over_cap:
                for n in (gvl.get("nodes") or []):
                    kind = str(n.get("kind", "")).lower()
                    if kind == "parameter":
                        meta = n.get("metadata") or {}
                        fn = str(meta.get("enclosing_function") or "").lower()
                        params_by_fn.setdefault(fn, []).append(n)
                        count += 1
                    elif kind == "struct_field":
                        struct_fields.append(n)
                        count += 1
                    if count > _RESOLVER_PROJ_CAP:
                        over_cap = True
                        break
            if not over_cap:
                proj = {
                    "arg_edges": arg_edges,
                    "params_by_fn": params_by_fn,
                    "struct_fields": struct_fields,
                }
        except Exception:
            proj = None

        self._gvl_proj_cache[key] = (gvl, proj)
        return proj

    @staticmethod
    def _node_row_to_dict(nid: Any, name: Any, kind: Any, extra_json: Any) -> Dict[str, Any]:
        meta: Dict[str, Any] = {}
        if extra_json:
            try:
                extra = json.loads(extra_json)
                m = extra.get("metadata") if isinstance(extra, dict) else None
                if isinstance(m, dict):
                    meta = m
            except Exception:
                meta = {}
        return {"id": nid, "name": name, "kind": kind, "metadata": meta}

    def _build_projection_from_db(self, gvl: Any) -> Optional[Dict[str, Any]]:
        """Build the Cases C/D projection from indexed index.db queries.

        Uses ``(job_id, relation)`` for arg_bind edges and ``(job_id, kind)``
        for parameter/struct_field nodes — row order (ORDER BY id) matches GVL
        emission order, so resolution results are identical to streaming.
        Returns None when the GVL is not DB-backed or the queries fail; may
        return a projection with ``struct_fields=None`` when only that subset
        exceeds the budget (Case D streams; Case C stays fast).
        """
        db = getattr(gvl, "_db_path", None)
        job = getattr(gvl, "_job_id", None)
        if not db or not job:
            return None
        import sqlite3 as _sq
        try:
            conn = _sq.connect(f"file:{db}?mode=ro", uri=True, check_same_thread=False)
            conn.execute("PRAGMA busy_timeout=5000")
        except Exception:
            return None
        try:
            count = 0
            arg_edges: List[Tuple[str, str]] = []
            for src, tgt in conn.execute(
                "SELECT source, target FROM gvl_edges "
                "WHERE job_id = ? AND relation = 'arg_bind' ORDER BY id",
                (str(job),),
            ).fetchall():
                count += 1
                if count > _RESOLVER_PROJ_CAP:
                    return None  # arg_bind alone over budget — stream instead
                arg_edges.append((str(src or "").lower(), str(tgt or "")))

            params_by_fn: Dict[str, List[Dict[str, Any]]] = {}
            for nid, name, kind, ej in conn.execute(
                "SELECT node_id, name, kind, extra_json FROM gvl_nodes "
                "WHERE job_id = ? AND kind = 'parameter' ORDER BY id",
                (str(job),),
            ).fetchall():
                count += 1
                if count > _RESOLVER_PROJ_CAP:
                    return None
                node = self._node_row_to_dict(nid, name, kind, ej)
                fn = str(node["metadata"].get("enclosing_function") or "").lower()
                params_by_fn.setdefault(fn, []).append(node)

            struct_fields: Optional[List[Dict[str, Any]]] = []
            for nid, name, kind, ej in conn.execute(
                "SELECT node_id, name, kind, extra_json FROM gvl_nodes "
                "WHERE job_id = ? AND kind = 'struct_field' ORDER BY id",
                (str(job),),
            ).fetchall():
                count += 1
                if count > _RESOLVER_PROJ_CAP:
                    # Only the struct_field subset is over budget: keep Case C
                    # fast, let Case D fall back to streaming.
                    struct_fields = None
                    break
                struct_fields.append(self._node_row_to_dict(nid, name, kind, ej))

            return {
                "arg_edges": arg_edges,
                "params_by_fn": params_by_fn,
                "struct_fields": struct_fields,
            }
        except Exception:
            return None
        finally:
            try:
                conn.close()
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def resolve(
        self,
        variable: str,
        target_stem: str,
        source_stem: Optional[str] = None,   # T10/T11: caller file stem
    ) -> Optional[str]:
        """Return the leaf name of *variable* in *target_stem*, or None if unknown.

        Resolution order:
        1. ASM identity index lookup (existing behaviour).
        2. Case A — ASM name → C++ field name via ``field_asm_aliases`` reverse
           lookup in the *target* C++ blueprint (T6).
        3. Case B — C++ field → ASM name via ``field_asm_aliases`` forward lookup
           in the *target* C++ blueprint (T6).
        4. Case C — pure C++→C++ rename via ``arg_bind`` parameter binding (T10);
           only runs when ``source_stem`` is provided.
        5. Case D — struct field canonical matching via
           ``(enclosing_type, field_name)`` (T11); only runs when ``source_stem``
           is provided and Case C found nothing.

        ``source_stem=None`` leaves all existing call-sites unchanged — Cases C
        and D are never reached, so behaviour is identical to before T10/T11.
        """
        # ── ASM index lookup — DB-first, JSON fallback ────────────────────
        # DB path: indexed lookup via variable_identity_files (no JSON parsing).
        if self._job_id:
            try:
                from api.index_db.readers import get_canonical_key, get_variable_file_node_id
                _ck = get_canonical_key(self._job_id, variable.upper())
                if _ck:
                    _node_id = get_variable_file_node_id(
                        self._job_id, _ck, target_stem,
                    )
                    if _node_id:
                        return _node_id.split(":")[-1] if ":" in _node_id else _node_id
            except Exception:
                pass  # fall through to JSON index

        index = self._get_index()
        if index:
            canonical_key = (index.get("by_name") or {}).get(variable.upper())
            if canonical_key:
                entry = (index.get("by_identity") or {}).get(canonical_key) or {}
                node_id = (entry.get("files") or {}).get(target_stem)
                if node_id:
                    return node_id.split(":")[-1] if ":" in node_id else node_id

        # ── Case A (T6): ASM name → C++ field name ────────────────────────
        alias_map = self._get_cpp_alias_map(target_stem)
        if alias_map:
            cpp_fields = alias_map.get(str(variable).upper())
            if cpp_fields:
                return cpp_fields[0]

        # ── Case B (T6): C++ field → ASM name ────────────────────────────
        if self._blueprint_dir:
            try:
                from backward_traversal.utils.blueprint_utils import (
                    load_json,
                    resolve_cpp_blueprint,
                )
                bp_path = resolve_cpp_blueprint(target_stem, self._blueprint_dir)
                if bp_path:
                    bp = load_json(bp_path)
                    asm_name = (bp.get("field_asm_aliases") or {}).get(variable)
                    if asm_name:
                        return str(asm_name)
            except Exception:
                pass

        # ── Cases C + D only run when we have a source_stem ───────────────
        if source_stem and source_stem != target_stem:
            # Case C (T10): arg_bind parameter binding
            result = self._resolve_via_arg_bind(variable, source_stem, target_stem)
            if result is not None:
                return result

            # Case D (T11): struct canonical matching via (enclosing_type, field_name)
            result = self._resolve_via_struct_canonical(variable, source_stem, target_stem)
            if result is not None:
                return result

            # Case D-ext (T12): file-scope variable canonical matching via
            # metadata.canonical_name (only present when parser >= T12 commit).
            result = self._resolve_via_variable_canonical(variable, source_stem, target_stem)
            if result is not None:
                return result

        return None

    @property
    def index_path(self) -> Optional[str]:
        """Absolute path string of the index file, or None if not found."""
        return str(self._path.resolve()) if self._path else None

    # ------------------------------------------------------------------
    # T6 — C++ alias-map cache
    # ------------------------------------------------------------------

    def _get_cpp_alias_map(self, stem: str) -> Dict[str, List[str]]:
        """Return ``{ASM_NAME_UPPER: [cpp_field, ...]}`` for the given C++ stem.

        Result is cached with FIFO eviction at ``_CPP_ALIAS_CACHE_MAX`` entries.
        """
        if stem in self._cpp_alias_cache:
            return self._cpp_alias_cache[stem]
        if not self._blueprint_dir:
            return {}
        try:
            from backward_traversal.utils.blueprint_utils import (
                load_json,
                resolve_cpp_blueprint,
            )
            bp_path = resolve_cpp_blueprint(stem, self._blueprint_dir)
            if not bp_path:
                self._cpp_alias_cache[stem] = {}
                return {}
            bp = load_json(bp_path)
        except Exception:
            self._cpp_alias_cache[stem] = {}
            return {}

        alias_map: Dict[str, List[str]] = {}
        for cpp_field, asm_name in (bp.get("field_asm_aliases") or {}).items():
            key = str(asm_name).upper()
            if key:
                alias_map.setdefault(key, []).append(str(cpp_field))

        if len(self._cpp_alias_cache) >= _CPP_ALIAS_CACHE_MAX:
            self._cpp_alias_cache.pop(next(iter(self._cpp_alias_cache)))
        self._cpp_alias_cache[stem] = alias_map
        return alias_map

    # ------------------------------------------------------------------
    # T10 — arg_bind parameter binding (Case C)
    # ------------------------------------------------------------------

    def _resolve_via_arg_bind(
        self,
        dep_var: str,
        source_stem: str,
        target_stem: str,
    ) -> Optional[str]:
        """Case C: pure C++→C++ rename via ``arg_bind`` edges.

        Looks for ``arg_bind`` edges in ``source_stem``'s GVL where the source
        node ends with ``::dep_var``, extracts the callee function name and
        argument index from the ``call_arg:funcName#N`` target, then finds the
        N-th parameter of that function in ``target_stem``'s GVL.

        Result is cached in ``_arg_bind_cache`` (shared with T11 Case D).
        Returns ``None`` on any exception or when no match is found.
        """
        cache_key = (dep_var, source_stem, target_stem)
        if cache_key in self._arg_bind_cache:
            return self._arg_bind_cache[cache_key]

        result = self._resolve_via_arg_bind_uncached(dep_var, source_stem, target_stem)

        if len(self._arg_bind_cache) >= _ARG_BIND_CACHE_MAX:
            self._arg_bind_cache.pop(next(iter(self._arg_bind_cache)))
        self._arg_bind_cache[cache_key] = result
        return result

    def _resolve_via_arg_bind_uncached(
        self,
        dep_var: str,
        source_stem: str,
        target_stem: str,
    ) -> Optional[str]:
        if not self._blueprint_dir:
            return None
        try:
            from backward_traversal.utils.blueprint_utils import (
                load_json,
                resolve_cpp_blueprint,
            )
            src_bp_path = resolve_cpp_blueprint(source_stem, self._blueprint_dir)
            if not src_bp_path:
                return None
            from backward_traversal.utils.lazy_gvl import make_lazy_gvl as _mkgvl
            src_gvl = _mkgvl(load_json(src_bp_path), blueprint_path=src_bp_path)

            tgt_bp_path = resolve_cpp_blueprint(target_stem, self._blueprint_dir)
            if not tgt_bp_path:
                return None
            tgt_gvl = _mkgvl(load_json(tgt_bp_path), blueprint_path=tgt_bp_path)
        except Exception:
            return None

        dep_var_lower = dep_var.lower()

        # PERF: iterate the pre-projected arg_bind edges / parameter nodes when
        # available — avoids re-streaming the whole GVL per resolve call.
        _src_proj = self._gvl_projection(src_gvl)
        _tgt_proj = self._gvl_projection(tgt_gvl)
        if _src_proj is not None:
            _arg_edge_iter = iter(_src_proj["arg_edges"])
        else:
            _arg_edge_iter = (
                (str(e.get("source", "")).lower(), str(e.get("target", "")))
                for e in (src_gvl.get("edges") or [])
                if str(e.get("relation", "")).lower() == "arg_bind"
            )

        for src_node, tgt_raw in _arg_edge_iter:
            # Match node ids ending with ::dep_var, :dep_var, or ->dep_var.
            # NEW-C: the "->" form is needed for struct-field dep_vars whose GVL
            # node ID ends with "->fieldName" (e.g. "struct_field:fn::ptr->cmSystem").
            # Without it, Case C returns None for every struct-field dep_var.
            # ISSUE-7: apply the same len>=4 guard used in Strategy 5 and the
            # fallback to the "->" suffix check — prevents matching every struct
            # field named "id", "cnt", etc. when dep_var is a short name.
            if not (src_node.endswith(f"::{dep_var_lower}")
                    or src_node.endswith(f":{dep_var_lower}")
                    or (len(dep_var_lower) >= 4 and src_node.endswith(f"->{dep_var_lower}"))):
                continue

            callee_fn, arg_idx = _parse_arg_bind_target(tgt_raw)
            if callee_fn is None or arg_idx is None:
                continue

            # Find the arg_idx-th parameter of callee_fn in target GVL.
            # Parameter nodes use id = "parameter:funcName::paramName" and carry
            # metadata.enclosing_function.  They should be sorted by
            # metadata.parameter_position (0-based) when that field is present so
            # that the N-th entry reliably corresponds to argument position N
            # regardless of the order the GVL builder emitted them (GAP-013).
            callee_fn_lower = callee_fn.lower()
            if _tgt_proj is not None:
                params = list(_tgt_proj["params_by_fn"].get(callee_fn_lower, []))
            else:
                params = [
                    n for n in (tgt_gvl.get("nodes") or [])
                    if str(n.get("kind", "")).lower() == "parameter"
                    and str((n.get("metadata") or {}).get("enclosing_function") or "").lower()
                       == callee_fn_lower
                ]
            # GAP-013: sort by parameter_position when the metadata is present.
            # Fall back to iteration order only when none of the nodes carry the
            # field (older parser output without parameter_position metadata).
            if any(
                (n.get("metadata") or {}).get("parameter_position") is not None
                for n in params
            ):
                params = sorted(
                    params,
                    key=lambda n: int(
                        (n.get("metadata") or {}).get("parameter_position", 99999)
                    ),
                )
            if 0 <= arg_idx < len(params):
                param_node = params[arg_idx]
                # name may be "funcName::paramName" — take the last segment
                param_name = str(param_node.get("name") or "")
                if "::" in param_name:
                    param_name = param_name.split("::")[-1]
                elif ":" in param_name:
                    param_name = param_name.split(":")[-1]
                return param_name or None

        return None

    # ------------------------------------------------------------------
    # T11 — struct canonical matching (Case D)
    # ------------------------------------------------------------------

    def _resolve_via_struct_canonical(
        self,
        dep_var: str,
        source_stem: str,
        target_stem: str,
    ) -> Optional[str]:
        """Case D: struct field canonical matching via ``(enclosing_type, field_name)``.

        Uses ``metadata.enclosing_type`` (already present on all ``struct_field``
        GVL nodes) as the canonical key to match the same field across files even
        when the pointer variable name differs.

        Returns the terminal field name in the target file if the field name is
        *different* there; returns ``None`` when the names already match (Strategy 5
        in ``find_cpp_seed_nodes`` handles the same-name case without help from
        the resolver).

        FIX-new-4: uses its own ``_struct_canonical_cache`` instead of sharing
        ``_arg_bind_cache`` with Case C.  Previously, a Case C miss cached ``None``
        under the same key, causing Case D to return ``None`` immediately without
        running its own lookup.
        """
        cache_key = (dep_var, source_stem, target_stem)
        if cache_key in self._struct_canonical_cache:
            return self._struct_canonical_cache[cache_key]

        result = self._resolve_via_struct_canonical_uncached(dep_var, source_stem, target_stem)

        if len(self._struct_canonical_cache) >= _ARG_BIND_CACHE_MAX:
            self._struct_canonical_cache.pop(next(iter(self._struct_canonical_cache)))
        self._struct_canonical_cache[cache_key] = result
        return result

    def _resolve_via_struct_canonical_uncached(
        self,
        dep_var: str,
        source_stem: str,
        target_stem: str,
    ) -> Optional[str]:
        if not self._blueprint_dir:
            return None
        try:
            from backward_traversal.utils.blueprint_utils import (
                load_json,
                resolve_cpp_blueprint,
            )
            src_bp_path = resolve_cpp_blueprint(source_stem, self._blueprint_dir)
            tgt_bp_path = resolve_cpp_blueprint(target_stem, self._blueprint_dir)
            if not src_bp_path or not tgt_bp_path:
                return None
            from backward_traversal.utils.lazy_gvl import make_lazy_gvl as _mkgvl
            src_gvl = _mkgvl(load_json(src_bp_path), blueprint_path=src_bp_path)
            tgt_gvl = _mkgvl(load_json(tgt_bp_path), blueprint_path=tgt_bp_path)
        except Exception:
            return None

        dep_lower = dep_var.lower()

        # PERF: iterate the pre-projected struct_field subset when available —
        # avoids re-streaming the whole GVL node section per resolve call.
        _src_proj = self._gvl_projection(src_gvl)
        _tgt_proj = self._gvl_projection(tgt_gvl)

        def _struct_nodes(gvl_obj: Any, proj: Optional[Dict[str, Any]]):
            # proj["struct_fields"] may be None (DB-built projection whose
            # struct subset exceeded the budget) — stream in that case.
            if proj is not None and proj.get("struct_fields") is not None:
                return proj["struct_fields"]
            return (
                n for n in (gvl_obj.get("nodes") or [])
                if str(n.get("kind", "")).lower() == "struct_field"
            )

        # Step 1 — find enclosing_type for dep_var in source GVL
        src_etype: Optional[str] = None
        for node in _struct_nodes(src_gvl, _src_proj):
            nid   = str(node.get("id", ""))
            fname = nid.split("->")[-1].split("::")[-1].strip().lower()
            nname = str(node.get("name") or "").strip().lower()
            if fname == dep_lower or nname == dep_lower:
                meta = node.get("metadata") or {}
                etype = str(meta.get("enclosing_type") or "").strip().lower()
                if etype:
                    src_etype = etype
                    break

        if not src_etype:
            return None   # not a struct field or no type info — Case D cannot help

        # Collect ALL field names for this struct type in the source GVL.
        # NEW-ISSUE-1 fix: needed in Step 2 to distinguish genuinely renamed fields
        # from fields that are unchanged (different from dep_lower but still present
        # in the source struct).  Without this set, iterating target fields with
        # etype==src_etype would collect ALL non-dep_lower fields as candidates —
        # making every multi-field struct return None due to the ambiguity guard.
        src_field_names: Set[str] = set()
        for node in _struct_nodes(src_gvl, _src_proj):
            meta = node.get("metadata") or {}
            if str(meta.get("enclosing_type") or "").strip().lower() != src_etype:
                continue
            nid = str(node.get("id", ""))
            fn = nid.split("->")[-1].split("::")[-1].strip().lower()
            if not fn:
                fn = str(node.get("name") or "").strip().lower()
            if fn:
                src_field_names.add(fn)

        # Step 2 — build canonical map for target GVL and look up the match
        # Inline _build_struct_canonical_map to avoid import of cpp_lineage_utils here
        tgt_map: Dict[Tuple[str, str], List[str]] = {}
        for node in _struct_nodes(tgt_gvl, _tgt_proj):
            meta  = node.get("metadata") or {}
            etype = str(meta.get("enclosing_type") or "").strip().lower()
            if not etype:
                continue
            nid   = str(node.get("id", ""))
            fname = nid.split("->")[-1].split("::")[-1].strip().lower()
            if not fname:
                fname = str(node.get("name") or "").strip().lower()
            if fname:
                tgt_map.setdefault((etype, fname), []).append(nid)

        # NEW-BUG-2: tgt_map keys are (etype, TARGET_fname).  Looking up
        # (src_etype, dep_lower) treats the SOURCE field name as if it were the
        # TARGET field name — which is exactly wrong when the field was renamed.
        # Fix: try the exact key first (same-name case); if absent, collect only
        # target fields that are absent from the source struct (i.e. genuine renames).
        # Return None when the result is ambiguous (multiple renamed fields).
        exact_matches = tgt_map.get((src_etype, dep_lower))
        if exact_matches:
            # Same field name in target; Strategy 5 already handles this.
            return None

        # Collect target fields of this struct type that:
        #   (a) differ from dep_lower, AND
        #   (b) are NOT present in the source struct's field set (so are genuinely
        #       new or renamed, not just other unchanged fields of the same struct).
        # NEW-ISSUE-1 fix: filtering by src_field_names prevents unchanged sibling
        # fields from polluting renamed_candidates in multi-field structs.
        renamed_candidates: List[str] = []
        for (etype, fname), nids in tgt_map.items():
            if etype != src_etype or fname == dep_lower:
                continue
            if fname in src_field_names:
                continue  # field exists in source too — not a rename
            for nid in nids:
                tgt_f = nid.split("->")[-1].split("::")[-1].strip()
                if not tgt_f:
                    tgt_f = fname
                if tgt_f.lower() != dep_lower:
                    renamed_candidates.append(tgt_f)

        # Only resolve when the match is unambiguous.
        return renamed_candidates[0] if len(renamed_candidates) == 1 else None

    def _resolve_via_variable_canonical(
        self,
        dep_var: str,
        source_stem: str,
        target_stem: str,
    ) -> Optional[str]:
        """T12 extension of Case D — resolve file-scope variable renames via
        ``metadata.canonical_name``.

        This covers the rare case where two C++ translation units share the same
        linker-level global variable but use different local names
        (e.g. ``g_systemLimit`` in fileA vs ``systemLimitCap`` in fileB declared
        with ``extern``).

        Resolution steps:
        1. Scan *source_stem*'s GVL for a ``variable``-kind node whose name/id
           terminal matches *dep_var* and has ``metadata.canonical_name``.
        2. Scan *target_stem*'s GVL for a ``variable``-kind node with the same
           ``metadata.canonical_name``.
        3. Return the target node's terminal name when it differs from *dep_var*;
           return ``None`` when names already match (Strategy 5 handles that).

        Returns ``None`` on any exception or when ``canonical_name`` is absent
        (e.g. local variables, parser older than T12 commit).
        """
        if not self._blueprint_dir:
            return None
        try:
            from backward_traversal.utils.blueprint_utils import resolve_cpp_blueprint
            src_bp_path = resolve_cpp_blueprint(source_stem, self._blueprint_dir)
            tgt_bp_path = resolve_cpp_blueprint(target_stem, self._blueprint_dir)
            if not src_bp_path or not tgt_bp_path:
                return None
            src_maps = self._get_canonical_maps(src_bp_path)
            tgt_maps = self._get_canonical_maps(tgt_bp_path)
        except Exception:
            return None
        if src_maps is None or tgt_maps is None:
            return None

        dep_lower = dep_var.lower()

        # Step 1 — find canonical_name for dep_var in source GVL
        src_canonical = src_maps[0].get(dep_lower)
        if not src_canonical:
            return None   # node absent or parser pre-T12 — Case D extension cannot help

        # Step 2 — find matching variable node in target GVL
        tgt_terminal = tgt_maps[1].get(src_canonical)
        if not tgt_terminal:
            return None
        return tgt_terminal if tgt_terminal.lower() != dep_lower else None

    def _get_canonical_maps(
        self,
        bp_path: Path,
    ) -> Optional[Tuple[Dict[str, str], Dict[str, str]]]:
        """Return ``(name_or_terminal_lower → canonical, canonical → first
        terminal name)`` for the GVL behind *bp_path*, building it once.

        Only ``variable``-kind nodes carrying ``metadata.canonical_name`` can
        participate in either direction of the T12 lookup, so the maps hold
        just those nodes (first match in GVL emission order wins, preserving
        the original scan semantics).

        DB-backed GVLs (blueprint loaded with ``skip_global_lineage`` falls
        back to the index.db global GVL) are served by one indexed query on
        ``(job_id, kind)`` with an ``extra_json LIKE`` pre-filter — the exact
        predicate is re-verified in Python on the few returned rows — instead
        of streaming the full ``gvl_nodes`` table twice per resolve call.
        """
        from backward_traversal.utils.blueprint_utils import load_json
        from backward_traversal.utils.lazy_gvl import make_lazy_gvl as _mkgvl

        path_key = str(bp_path)
        cached = self._canonical_maps_cache.get(path_key)
        if cached is not None:
            return cached

        gvl = _mkgvl(load_json(bp_path), blueprint_path=bp_path)
        db_path = getattr(gvl, "_db_path", None)
        gvl_job = getattr(gvl, "_job_id", None)
        # Several blueprint paths can resolve to the same DB-backed global GVL —
        # share one map build across them via a second-level identity key.
        db_key = f"db:{db_path}:{gvl_job}" if db_path and gvl_job else None
        if db_key is not None:
            cached = self._canonical_maps_cache.get(db_key)
            if cached is not None:
                self._canonical_maps_cache[path_key] = cached
                return cached

        name_to_canonical: Dict[str, str] = {}
        canonical_to_terminal: Dict[str, str] = {}

        def _add(node_id: str, node_name: str, canonical: str) -> None:
            nid = node_id.split("::")[-1].strip().lower()
            nname = node_name.strip().lower()
            if nid:
                name_to_canonical.setdefault(nid, canonical)
            if nname:
                name_to_canonical.setdefault(nname, canonical)
            terminal = node_name.strip().split("::")[-1].strip()
            canonical_to_terminal.setdefault(canonical, terminal)

        if db_path and gvl_job:
            import sqlite3
            con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
            try:
                rows = con.execute(
                    "SELECT node_id, name, extra_json FROM gvl_nodes "
                    "WHERE job_id=? AND kind='variable' "
                    "AND extra_json LIKE '%canonical_name%' ORDER BY id",
                    (gvl_job,),
                ).fetchall()
            finally:
                con.close()
            for node_id, name, extra in rows:
                try:
                    meta = (json.loads(extra) or {}).get("metadata") or {}
                except Exception:
                    continue
                cn = str(meta.get("canonical_name") or "").strip().lower()
                if cn:
                    _add(str(node_id or ""), str(name or ""), cn)
        else:
            for node in (gvl.get("nodes") or []):
                if str(node.get("kind", "")).lower() != "variable":
                    continue
                meta = node.get("metadata") or {}
                cn = str(meta.get("canonical_name") or "").strip().lower()
                if cn:
                    _add(str(node.get("id", "") or ""), str(node.get("name", "") or ""), cn)

        maps = (name_to_canonical, canonical_to_terminal)
        self._canonical_maps_cache[path_key] = maps
        if db_key is not None:
            self._canonical_maps_cache[db_key] = maps
        return maps

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _get_index(self) -> Optional[Dict]:
        if not self._index_loaded:
            self._index_loaded = True
            if self._path is not None:
                key = str(self._path.resolve())
                if key not in VariableNameResolver._cache:
                    # Evict oldest entry when cache is at capacity (FIFO)
                    if len(VariableNameResolver._cache) >= VariableNameResolver._INDEX_CACHE_MAX:
                        VariableNameResolver._cache.pop(next(iter(VariableNameResolver._cache)))
                    try:
                        VariableNameResolver._cache[key] = json.loads(
                            self._path.read_text(encoding="utf-8")
                        )
                    except Exception:
                        VariableNameResolver._cache[key] = None
                self._index = VariableNameResolver._cache[key]
            else:
                # Only warn when neither the JSON file nor the index DB is available.
                # After a successful pipeline run the JSON file is deleted once it has
                # been ingested into the index DB — so _path=None + _job_id=<valid> is
                # the normal state.  The DB path in resolve() handles lookups fine.
                if not self._job_id:
                    import logging as _logging
                    _logging.getLogger(__name__).warning(
                        "VariableNameResolver: variable_identity_index.json not found "
                        "(blueprint_dir=%s). Cross-file name translation will fall back "
                        "to the original variable name for every lookup. Re-run the "
                        "pipeline or verify that blueprint_dir is set correctly.",
                        getattr(self, "_blueprint_dir", "<unknown>"),
                    )
        return self._index

    @staticmethod
    def _find_index_path(blueprint_dir: Path) -> Optional[Path]:
        for candidate in (
            blueprint_dir.parent / "variable_identity_index.json",
            blueprint_dir / "variable_identity_index.json",
        ):
            if candidate.exists():
                return candidate
        return None

    @staticmethod
    def _derive_job_id(path: Optional[Path]) -> Optional[str]:
        """Derive job_id from the identity index path (inside jobs/{job_id}/...)."""
        if path is None:
            return None
        try:
            from api.index_db.engine import job_id_from_path
            return job_id_from_path(path)
        except Exception:
            return None
