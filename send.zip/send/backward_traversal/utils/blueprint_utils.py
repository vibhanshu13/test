"""Filesystem and blueprint helpers for backward-only mode."""

from __future__ import annotations

import json
import os
import re
import threading
import time
from collections import OrderedDict, namedtuple
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from backward_traversal.glossary.instructions import HLASM_BUILTIN_SYMBOLS

try:
    from blueprint_io import iter_flow
except ImportError:
    import sys as _sys
    import os as _os
    _sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.dirname(__file__))))
    from blueprint_io import iter_flow


def discover_blueprint_dir() -> Optional[Path]:
    cwd = Path.cwd()
    for candidate in [
        cwd / "temp" / "output_latest" / "asm",
        cwd / "output" / "asm",
        cwd / "temp" / "parser_run",
    ]:
        if candidate.exists() and (list(candidate.glob("*.cpp.json")) or list(candidate.glob("*.asm.json"))):
            return candidate
    return None


def discover_asm_dir(blueprint_dir: Path) -> Optional[Path]:
    for candidate in [
        blueprint_dir.parent.parent / "asm",
        blueprint_dir.parent / "asm",
        blueprint_dir,
    ]:
        if candidate.exists() and (list(candidate.glob("*.asm")) or list(candidate.glob("*.cpp"))):
            return candidate
    return None


def discover_graph_file(blueprint_dir: Optional[Path]) -> Optional[Path]:
    candidates: List[Path] = []
    if blueprint_dir:
        candidates += [
            blueprint_dir / "file_call_graph.json",
            blueprint_dir.parent / "file_call_graph.json",
        ]
    cwd = Path.cwd()
    candidates += [
        cwd / "temp" / "output_latest" / "file_call_graph.json",
        cwd / "output" / "file_call_graph.json",
        cwd / "file_call_graph.json",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def _read_text_with_retry(
    path: Path,
    *,
    encoding: str = "utf-8",
    errors: Optional[str] = None,
    attempts: int = 5,
    sleep_seconds: float = 0.2,
) -> str:
    """Read file text with retry for transient filesystem timeouts."""
    last_exc: Optional[Exception] = None
    for i in range(max(1, attempts)):
        try:
            if errors is None:
                return path.read_text(encoding=encoding)
            return path.read_text(encoding=encoding, errors=errors)
        except (TimeoutError, OSError) as exc:
            last_exc = exc
            if i >= attempts - 1:
                break
            time.sleep(sleep_seconds * (i + 1))
    if last_exc is not None:
        raise last_exc
    raise RuntimeError(f"Failed to read file: {path}")


_BP_CACHE_SIZE_ENV = "ASM_BP_CACHE_SIZE"
_BP_CACHE_RAM_MB_ENV = "ASM_BP_CACHE_RAM_MB"
_BP_ESTIMATED_SIZE_MB = 15  # estimated decoded size per blueprint (msgpack format)


def _normalize_blueprint_keys(
    keys: Optional[Set[str]],
) -> Optional[Tuple[str, ...]]:
    """Return a stable cache key for an optional blueprint key filter."""
    if keys is None:
        return None
    return tuple(sorted(str(k) for k in keys if str(k)))


def _compute_cache_maxsize() -> int:
    """Compute LRU cache maxsize from environment.

    Priority:
    1. ``ASM_BP_CACHE_SIZE`` — explicit slot count (backwards compatible).
    2. ``ASM_BP_CACHE_RAM_MB`` — RAM budget in MB; slots = budget // 15 MB.
    3. Default 1 GB budget → ~68 slots (safe for 22K-file codebases).

    With the default 1024-slot cache each Celery worker can pin up to
    1024 × 15 MB = 15 GB.  Switching to budget-based sizing keeps
    worst-case cache RAM at a configurable ceiling (default 1 GB).
    """
    if _BP_CACHE_SIZE_ENV in os.environ:
        return max(1, int(os.environ[_BP_CACHE_SIZE_ENV]))
    budget_mb = int(os.environ.get(_BP_CACHE_RAM_MB_ENV, "1024"))
    return max(8, budget_mb // _BP_ESTIMATED_SIZE_MB)


_CacheInfo = namedtuple("CacheInfo", ["hits", "misses", "maxsize", "currsize"])


class _BlueprintFrameCache:
    """Path-keyed blueprint frame cache (replaces the (path, key_filter) lru_cache).

    The previous cache keyed entries on ``(path, key_filter)``, so the SAME
    blueprint requested with ``keys={"call_graph"}`` and
    ``keys={"blocks","call_graph"}`` occupied two LRU slots holding duplicated
    frames — halving effective capacity and amplifying eviction thrash in the
    dep-var BFS.  This cache keys on path and *accumulates* frames per entry:
    a request only reads from disk the frames not already cached for that path.

    RAM: strictly lower than before for the same slot budget (no duplicated
    frames).  Returned dicts are fresh shallow copies per call (frame values
    shared by reference), so top-level mutation by callers cannot corrupt the
    cache.

    PERF-001 (carried over): ``skip_global_lineage=True`` on every read — on
    large codebases global_variable_lineage.json can be 3–4 GB; loading it as
    a Python dict allocates 10–15 GB and OOMs containers.  The GVL file path
    is exposed at ``bp["_gvl_path"]`` for LazyGVL consumers instead.
    """

    def __init__(self, maxsize: int) -> None:
        self.maxsize = maxsize
        self._lock = threading.Lock()
        # path_str -> {"frames": {...}, "full": bool, "absent": set, "meta": dict|None}
        self._entries: "OrderedDict[str, Dict[str, Any]]" = OrderedDict()
        self._hits = 0
        self._misses = 0

    @staticmethod
    def _load_frames(
        path: Path, requested: Optional[Set[str]]
    ) -> Tuple[Dict[str, Any], bool]:
        """Read frames from disk.  Returns ``(frames, is_full)``.

        ``is_full`` is True when the returned dict is the complete blueprint:
        either the caller asked for everything, or the legacy non-seekable
        fallback parsed the whole file anyway — in which case we keep all of
        what we already paid to parse.
        """
        try:
            from blueprint_io import load_blueprint
            bp = load_blueprint(path, skip_global_lineage=True, keys=requested)
            return bp, requested is None
        except ImportError:
            bp = json.loads(_read_text_with_retry(path, encoding="utf-8"))
            return bp, True  # full parse — cache everything we decoded

    @staticmethod
    def _compute_meta(path: Path, frames: Dict[str, Any]) -> Dict[str, Any]:
        """GVL pointers for lazy consumers (LazyGVL / make_lazy_gvl).

        Computed once per path and overlaid on every returned dict — same
        contract as the old loader's ``_gvl_path`` injection."""
        if "_gvl_path" in frames or "_gvl_db_path" in frames:
            return {}
        from backward_traversal.utils.lazy_gvl import find_gvl_path, find_gvl_db_path
        _gp = find_gvl_path(path)
        if _gp is not None:
            return {"_gvl_path": str(_gp)}
        # GVL file missing — fall back to index.db if available.
        _db_result = find_gvl_db_path(path)
        if _db_result is not None:
            _db_path, _job_id = _db_result
            return {"_gvl_db_path": str(_db_path), "_gvl_job_id": _job_id}
        return {}

    def get(
        self, path_str: str, key_filter: Optional[Tuple[str, ...]]
    ) -> Dict[str, Any]:
        requested: Optional[Set[str]] = (
            set(key_filter) if key_filter is not None else None
        )
        with self._lock:
            entry = self._entries.get(path_str)
            if entry is not None:
                self._entries.move_to_end(path_str)
            else:
                entry = {"frames": {}, "full": False, "absent": set(), "meta": None}
                self._entries[path_str] = entry

            # Which frames still need reading from disk?
            if entry["full"]:
                missing: Optional[Set[str]] = set()
            elif requested is None:
                missing = None  # full load required
            else:
                missing = {
                    k for k in requested
                    if k not in entry["frames"] and k not in entry["absent"]
                }

            if missing is None or missing:
                self._misses += 1
                frames, is_full = self._load_frames(Path(path_str), missing)
                if is_full:
                    frames.update(entry["frames"])  # cached frames win (identical content)
                    entry["frames"] = frames
                    entry["full"] = True
                    entry["absent"] = set()
                else:
                    entry["frames"].update(frames)
                    # Requested keys absent from the file: remember them so we
                    # don't re-read the file for them on every call.
                    entry["absent"].update(k for k in missing if k not in frames)
            else:
                self._hits += 1

            if entry["meta"] is None:
                entry["meta"] = self._compute_meta(Path(path_str), entry["frames"])

            if requested is None:
                out = dict(entry["frames"])
            else:
                out = {k: entry["frames"][k] for k in requested if k in entry["frames"]}
            out.update(entry["meta"])

            # Evict least-recently-used paths beyond the slot budget.
            while len(self._entries) > self.maxsize:
                self._entries.popitem(last=False)

            return out

    def info(self) -> _CacheInfo:
        with self._lock:
            return _CacheInfo(self._hits, self._misses, self.maxsize, len(self._entries))

    def clear(self) -> None:
        with self._lock:
            self._entries.clear()


_bp_frame_cache = _BlueprintFrameCache(_compute_cache_maxsize())


def load_json(
    path: Path,
    *,
    keys: Optional[Set[str]] = None,
) -> Dict[str, Any]:
    """Load a JSON blueprint, caching frames by absolute path.

    When *keys* is provided and the blueprint was written in the seekable
    per-key frame format, only those top-level frames are read from disk.
    Repeated calls for the same path with different key filters share ONE
    cache entry — additional calls only read the frames not yet cached.
    Blueprints are read-only during a run, so the cache is never stale.
    """
    return _bp_frame_cache.get(str(path), _normalize_blueprint_keys(keys))


def get_blueprint_cache_info() -> Optional[object]:
    """Return the cache statistics for the blueprint loader (GAP-011).

    Callers can inspect ``.hits``, ``.misses``, ``.currsize``, and ``.maxsize``
    to detect cache pressure and emit an operational warning.  Returns ``None``
    when the cache is unavailable (should not happen in normal operation).
    """
    try:
        return _bp_frame_cache.info()
    except Exception:
        return None


def clear_blueprint_cache() -> None:
    """Clear the blueprint frame cache to release memory between phases.

    Call this after Pass 1a (extend_modifier_sites scan) completes so that
    blueprints loaded only for the lightweight setter-site scan are evicted
    before Pass 1b / Pass 2. This clears every cached frame for every path,
    including partial-key loads via ``load_json(..., keys=...)``.
    """
    try:
        _bp_frame_cache.clear()
    except Exception:
        pass


def clear_constant_symbols_cache() -> None:
    """Clear the constant-symbols cache to release memory between BFS batches.

    The ``_constant_symbols_cache`` dict grows unbounded as files are scanned.
    Clearing it between batches keeps peak RAM proportional to batch size
    rather than total visited files.
    """
    _constant_symbols_cache.clear()


@lru_cache(maxsize=2048)
def resolve_asm_blueprint(stem: str, blueprint_dir: Path) -> Optional[Path]:
    stem = str(stem).strip()
    for p in [
        blueprint_dir / f"{stem}.asm.json",
        blueprint_dir / f"{stem.lower()}.asm.json",
        blueprint_dir / f"{stem}.mac.json",
        blueprint_dir / f"{stem.lower()}.mac.json",
    ]:
        if p.exists():
            return p
    return None


@lru_cache(maxsize=2048)
def resolve_cpp_blueprint(stem: str, blueprint_dir: Path) -> Optional[Path]:
    stem = str(stem).strip()
    for p in [blueprint_dir / f"{stem}.cpp.json", blueprint_dir / f"{stem.lower()}.cpp.json"]:
        if p.exists():
            return p
    return None


def resolve_file_type(stem: str, blueprint_dir: Path, file_type_map: Dict[str, str]) -> str:
    stem_norm = str(stem).strip()
    stem_lower = stem_norm.lower()
    t = file_type_map.get(stem_norm) or file_type_map.get(stem_lower) or file_type_map.get(stem_norm.upper())
    if t in {"asm", "cpp"}:
        return t
    if resolve_asm_blueprint(stem_norm, blueprint_dir):
        return "asm"
    if resolve_cpp_blueprint(stem_norm, blueprint_dir):
        return "cpp"
    return "unknown"


@lru_cache(maxsize=2048)
def resolve_source_file(stem: str, file_type: str, blueprint_dir: Path, asm_dir: Optional[Path]) -> Optional[Path]:
    ext = "asm" if file_type == "asm" else "cpp"
    candidates: List[Path] = []
    if asm_dir:
        candidates.append(asm_dir / f"{stem}.{ext}")
    candidates += [
        blueprint_dir.parent.parent / "asm" / f"{stem}.{ext}",
        blueprint_dir.parent / "asm" / f"{stem}.{ext}",
        blueprint_dir / f"{stem}.{ext}",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


# ── Raw source line access (caching + optional on-disk offset index) ──────────
# PERF: fetch_raw_line was previously an UNCACHED full-file read + splitlines on
# *every* call.  It has 17 call sites, many inside per-setter / per-block loops
# that run D×F times across the dep_var BFS → cost was O(call_sites × filesize).
# Two memory-safe layers fix this without risking a small (16 GB) box:
#   1. _read_lines_cached — a *bounded* LRU that splits each file once and shares
#      the immutable result across all callers (default path; byte-identical to
#      the old splitlines() behaviour, so accuracy is unchanged).
#   2. _loff_lookup — an OPTIONAL on-disk byte-offset sidecar "<file>.loff" that
#      lets us seek to one line in O(1) memory, so huge generated files are never
#      held in RAM.  Sidecars are opt-in: build them with
#      scripts/build_line_offset_index.py.  When absent, layer 1 is used.
_LINE_CACHE_SIZE = int(os.environ.get("ASM_LINE_CACHE_SIZE", "512"))
_LOFF_SUFFIX = ".loff"
_LOFF_MAGIC = b"LOFF1\n"


@lru_cache(maxsize=_LINE_CACHE_SIZE)
def _read_lines_cached(path_str: str) -> tuple:
    """Read+split a source file once; cached by absolute path (bounded LRU).

    Returns an immutable tuple of physical lines (``str.splitlines()`` semantics,
    matching the previous fetch_raw_line behaviour exactly).  Source files are
    read-only during a backward run, so the cache is never stale.  Bounded by
    ``ASM_LINE_CACHE_SIZE`` (default 512 slots) to cap RAM on small servers.
    """
    text = _read_text_with_retry(Path(path_str), encoding="utf-8", errors="replace")
    return tuple(text.splitlines())


def clear_line_cache() -> None:
    """Evict the raw-line cache (call between BFS batches to bound peak RAM)."""
    try:
        _read_lines_cached.cache_clear()
    except Exception:
        pass


def get_line_cache_info() -> Optional[object]:
    """Return the raw-line LRU stats object (``.hits``/`.misses`/`.currsize`)."""
    try:
        return _read_lines_cached.cache_info()
    except Exception:
        return None


def _loff_lookup(src_path: Path, line_no: int) -> Optional[str]:
    """Read a single 1-based line via the on-disk offset sidecar, O(1) memory.

    Sidecar layout: ``_LOFF_MAGIC`` then little-endian uint64 offsets, where
    ``offsets[i]`` is the byte offset at which line ``i+1`` begins.  Returns
    ``None`` when no sidecar exists, the magic mismatches, or the line is out of
    range — callers then fall back to the bounded line cache.
    """
    if line_no < 1:
        return None
    loff = Path(str(src_path) + _LOFF_SUFFIX)
    if not loff.exists():
        return None
    try:
        import struct
        with open(loff, "rb") as fh:
            if fh.read(len(_LOFF_MAGIC)) != _LOFF_MAGIC:
                return None
            fh.seek(len(_LOFF_MAGIC) + (line_no - 1) * 8)
            buf = fh.read(16)  # offsets[line_no-1] and offsets[line_no]
        if len(buf) < 8:
            return None
        start = struct.unpack_from("<Q", buf, 0)[0]
        end = struct.unpack_from("<Q", buf, 8)[0] if len(buf) >= 16 else None
        with open(src_path, "rb") as sf:
            sf.seek(start)
            raw = sf.read((end - start) if end is not None else 1 << 20)
        return raw.split(b"\n", 1)[0].decode("utf-8", errors="replace").rstrip()
    except Exception:
        return None


def fetch_raw_line(file_field: str, line_no: int, asm_dir: Optional[Path]) -> Optional[str]:
    candidates: List[Path] = [Path(file_field)]
    if asm_dir:
        candidates.append(asm_dir / Path(file_field).name)

    for path in candidates:
        if not path.exists():
            continue
        # Layer 2: O(1)-memory seek via offset sidecar when one was built.
        via_loff = _loff_lookup(path, line_no)
        if via_loff is not None:
            return via_loff
        # Layer 1: bounded, shared line cache (default; identical to old behaviour).
        try:
            lines = _read_lines_cached(str(path))
            if 1 <= line_no <= len(lines):
                return lines[line_no - 1].rstrip()
        except Exception:
            continue
    return None


def resolve_ex_target(bp_data: Dict[str, Any], label: str) -> Optional[Dict[str, Any]]:
    """Resolve an EX/EXRL target label to its first flow entry.

    EX R3,MYMVC executes the instruction at label MYMVC.  The label is
    typically a standalone block whose single flow entry is the target
    instruction (e.g. MVC DEST,SRC).  Returns the first flow entry dict
    of the matching block, or None if the label cannot be resolved.
    """
    if not label:
        return None
    label_upper = str(label).strip().upper()
    for block in bp_data.get("blocks") or []:
        block_id = str(block.get("id") or "").strip().upper()
        if block_id == label_upper:
            entries = list(iter_flow(block))
            if entries:
                return entries[0]
    return None


def build_asm_block_source_index(blueprint_data: Dict[str, Any], asm_file: Optional[Path]) -> Dict[str, str]:
    if not asm_file or not asm_file.exists():
        return {}
    try:
        src_lines = _read_text_with_retry(asm_file, encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return {}

    index: Dict[str, str] = {}
    for block in blueprint_data.get("blocks", []):
        block_id = block.get("id")
        if not block_id:
            continue
        lines_in_flow = [e.get("line") for e in iter_flow(block) if e.get("line")]
        if not lines_in_flow:
            continue
        start = min(lines_in_flow)
        end = max(lines_in_flow)
        index[block_id] = "\n".join(src_lines[start - 1 : end])
    return index


def extract_single_block_source(
    bp_data: Dict[str, Any],
    asm_file: Optional[Path],
    block_id: str,
    _source_cache: Optional[Dict[str, List[str]]] = None,
) -> Optional[str]:
    """Extract source text for a single ASM block by *block_id*.

    Unlike ``build_asm_block_source_index`` which iterates every block in the
    blueprint, this function locates only the requested block — faster when the
    caller needs just one or two blocks from a large file.

    *_source_cache* is an optional ``{str(asm_file): [lines]}`` dict.  When
    provided the file is read at most once and the cached lines are reused for
    subsequent calls with different *block_id* values in the same file.
    """
    if not asm_file or not asm_file.exists():
        return None
    cache_key = str(asm_file)
    if _source_cache is not None and cache_key in _source_cache:
        src_lines = _source_cache[cache_key]
    else:
        try:
            src_lines = _read_text_with_retry(
                asm_file, encoding="utf-8", errors="replace"
            ).splitlines()
        except Exception:
            return None
        if _source_cache is not None:
            _source_cache[cache_key] = src_lines

    block_id_upper = str(block_id).strip().upper()
    for block in bp_data.get("blocks", []):
        bid = str(block.get("id") or "").strip().upper()
        if bid != block_id_upper:
            continue
        lines_in_flow = [e.get("line") for e in iter_flow(block) if e.get("line")]
        if not lines_in_flow:
            return None
        start = min(lines_in_flow)
        end = max(lines_in_flow)
        return "\n".join(src_lines[start - 1 : end])
    return None


_CONST_LABEL_RE = re.compile(r"^\s*([A-Za-z@$_#][A-Za-z0-9@$_#]*)\s+(DC|EQU)\b", re.IGNORECASE)

# PERF-OPT-4: cache constant symbols by (blueprint_path, asm_file_path) to avoid
# redundant source-file reads and regex scans when the same file is traced for
# multiple dep_vars.  Bounded to 256 entries to prevent unbounded memory growth
# on 22K-file codebases where 100K+ unique (bp, asm) pairs are possible.
from collections import OrderedDict as _OrderedDict
_constant_symbols_cache: _OrderedDict = _OrderedDict()
_CONSTANT_CACHE_MAX = 256


def collect_constant_symbols(
    blueprint_data: Dict[str, Any],
    asm_file: Optional[Path] = None,
    *,
    bp_path: Optional[Path] = None,
) -> Set[str]:
    """Collect constant-like symbols for dep-var filtering.

    Priority:
    1) Symbol table entries marked as constant-like (`dc`, `equ`, etc.)
    2) Fallback source scan for labeled `DC` / `EQU`

    HLASM assembler-defined built-in symbols (SPACE, LOW, HIGH, …) are always
    included so they never leak as dep_vars regardless of the source file.

    When *bp_path* is provided the result is cached by
    ``(bp_path, asm_file)`` so repeated calls for different dep_vars
    in the same file are free.
    """
    if bp_path is not None:
        _cache_key = (str(bp_path), str(asm_file) if asm_file else None)
        cached = _constant_symbols_cache.get(_cache_key)
        if cached is not None:
            _constant_symbols_cache.move_to_end(_cache_key)  # LRU refresh
            return cached

    out: Set[str] = set(HLASM_BUILTIN_SYMBOLS)

    symbols = (blueprint_data.get("symbols") or {})
    constant_types = {"dc", "equ", "literal", "constant"}

    def _is_constant_type(stype: str) -> bool:
        return stype in constant_types or stype.startswith("dc")

    global_symbols = symbols.get("global_symbols") or {}
    if isinstance(global_symbols, dict):
        for name, meta in global_symbols.items():
            if not name:
                continue
            m = meta or {}
            stype = str(m.get("type") or "").strip().lower()
            if _is_constant_type(stype):
                out.add(str(name).upper())

    local_symbols = symbols.get("local_symbols") or {}
    if isinstance(local_symbols, dict):
        for name, meta in local_symbols.items():
            if not name:
                continue
            m = meta or {}
            stype = str(m.get("type") or "").strip().lower()
            if _is_constant_type(stype):
                out.add(str(name).upper())

    if asm_file is not None and asm_file.exists():
        try:
            lines = _read_text_with_retry(asm_file, encoding="utf-8", errors="replace").splitlines()
        except Exception:
            lines = []

        for raw in lines:
            line = str(raw or "")
            if not line.strip():
                continue
            if line.lstrip().startswith("*"):
                continue
            m = _CONST_LABEL_RE.match(line)
            if not m:
                continue
            label = str(m.group(1) or "").upper()
            if label:
                out.add(label)

    if bp_path is not None:
        _constant_symbols_cache[_cache_key] = out
        # Evict oldest entries to bound memory on large codebases.
        while len(_constant_symbols_cache) > _CONSTANT_CACHE_MAX:
            _constant_symbols_cache.popitem(last=False)
    return out
