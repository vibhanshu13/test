"""CLI for the setter-location finder — where is a variable set?

    python -m backward_traversal.cli_setter_locations VAR \
        --blueprint-dir jobs/<kb>/output/asm \
        --graph jobs/<kb>/output/file_call_graph.json \
        [--asm-dir ...] [--job-id <kb>] [--language asm|cpp] \
        [--declarations] [--summary] [--output out.json]

ASM variable → (file, line) list.  C++ variable → (file, function, line) list.
Setter detection (glossary SETTER_INST + edge cases for ASM, GVL assign/define
for C++) is reused from the chainless setter enumerator.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="backward_traversal.cli_setter_locations")
    p.add_argument("variable")
    p.add_argument("--blueprint-dir", required=True, type=Path)
    p.add_argument("--graph", required=True, type=Path)
    p.add_argument("--asm-dir", type=Path, default=None)
    p.add_argument("--job-id", default=None, help="project/kb id (enables index.db reads)")
    p.add_argument("--language", choices=["asm", "cpp"], default=None,
                   help="force language; auto-detected if omitted")
    p.add_argument("--declarations", action="store_true",
                   help="also include copybook/declaration sites (not value writes)")
    p.add_argument("--summary", action="store_true", help="human-readable list")
    p.add_argument("--output", type=Path, default=None)
    return p


def main(argv=None) -> int:
    args = build_arg_parser().parse_args(argv)
    from backward_traversal.setter_locations import find_setter_locations

    res = find_setter_locations(
        args.variable, blueprint_dir=args.blueprint_dir, graph_file=args.graph,
        asm_dir=args.asm_dir, job_id=args.job_id, language=args.language,
        include_declarations=args.declarations,
    )

    if args.summary:
        print(f"{args.variable}  [{res['language']}]  "
              f"asm={res['stats']['asm_setter_count']}  cpp={res['stats']['cpp_setter_count']}")
        for s in res["asm_setters"]:
            print(f"  ASM  {s['file']}:{s['line']}  ({s['instruction']})")
        for s in res["cpp_setters"]:
            fn = s["function"] or "<file-scope>"
            print(f"  CPP  {s['file']}::{fn}:{s['line']}")
        if args.declarations and res.get("declarations"):
            for d in res["declarations"]:
                print(f"  decl {d['file']}:{d['line']} [{d['file_type']}]")
        return 0

    text = json.dumps(res, separators=(",", ":"), default=str)
    if args.output:
        args.output.write_text(text, encoding="utf-8")
        print(f"wrote {len(text)} bytes to {args.output}", file=sys.stderr)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
