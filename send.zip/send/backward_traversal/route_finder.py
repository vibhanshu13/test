"""Forward route finder — is there a call route parent → child, and which ones?

Given a **parent** (a C++ function in a file, or an ASM file) and a **child**
(a C++ function in a file, or an ASM file), this answers:

    1. Is there a call route  parent → … → child ?
    2. If yes, enumerate every route (file hops, each annotated with the calling
       function and the guard condition under which the call fires).

Primary use is **cpp → cpp** at function granularity, but all four directions
(cpp→cpp, cpp→asm, asm→cpp, asm→asm) are covered because the work is delegated
to the four mature cross-language *caller* bridges via ``walk_callers``.

Design — reuse over reinvention
-------------------------------
Rather than build a second (forward) set of cross-language bridges, this walks
the **callers of the child** with the existing ``walk_callers`` (the four
``cross_file_bridge_backward`` bridges + indirection handling + per-call-site
guard conditions), which already resolves each cross-file call at function
granularity (``caller_function`` / ``callee_function`` / ``cpp_function``).  The
caller forest is naturally restricted to files that reach the child, so the
parent appears in it **iff a route exists**.  We then:

* build a **verified** forward adjacency (caller→callee) from those call sites,
* enumerate simple routes parent → child, enforcing **function continuity** at
  every hop via the intra-file call graph (``chainless_reachability``):
  the function entered in a file must transitively reach the function that makes
  the next call.

Soundness mirrors the rest of the chainless engine: only **verified** call
edges form routes; cycle/indirection candidates are surfaced separately
(``unverified``), never woven into a confident route.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from backward_traversal.runner import chainless_reachability as RCH


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@dataclass
class Endpoint:
    """A route endpoint: a C++ function in a file, or an ASM file.

    ``function`` is the C++ function name (recommended for cpp; routes are then
    function-accurate).  For ASM leave it ``None`` — an ASM module is reached at
    a single entry, so the file IS the granularity.
    """
    file_stem: str
    file_type: str = "cpp"               # "cpp" | "asm"
    function: Optional[str] = None

    def norm(self) -> "Endpoint":
        return Endpoint(
            file_stem=str(self.file_stem).strip(),
            file_type=(self.file_type or "cpp").lower(),
            function=(self.function or None),
        )


# ---------------------------------------------------------------------------
# Forward adjacency over the verified caller forest
# ---------------------------------------------------------------------------

def _build_forward_edges(
    caller_nodes: List[Dict[str, Any]],
) -> Tuple[Dict[str, List[Dict[str, Any]]], List[str]]:
    """From the child's caller forest, build verified forward edges.

    Returns ``(fwd, unverified)`` where ``fwd[caller_stem]`` is a list of edge
    dicts ``{callee, caller_fn, callee_fn, line, conditions}`` and ``unverified``
    is the list of caller files the bridge could not confirm (surfaced, not
    woven into routes).
    """
    fwd: Dict[str, List[Dict[str, Any]]] = {}
    unverified: Set[str] = set()
    verified_callees: Set[str] = set()
    for c in caller_nodes:
        if not isinstance(c, dict):
            continue
        caller = str(c.get("stem") or "")
        callee = str(c.get("callee_stem") or "")
        if not caller or not callee:
            continue
        sites = c.get("call_sites") or []
        if not sites:
            if not c.get("cycle"):
                unverified.add(caller)
            continue
        verified_callees.add(callee)
        for s in sites:
            if not isinstance(s, dict):
                continue
            fwd.setdefault(caller, []).append({
                "callee": callee,
                "caller_fn": RCH.site_caller_fn(s),
                "callee_fn": RCH.site_target_fn(s) or "",
                "line": s.get("line"),
                "conditions": list(s.get("conditions") or []),
            })
    return fwd, sorted(unverified - verified_callees)


# ---------------------------------------------------------------------------
# Route enumeration  (parent → child, function-continuous)
# ---------------------------------------------------------------------------

def _enumerate_routes(
    parent: Endpoint, child: Endpoint,
    fwd: Dict[str, List[Dict[str, Any]]],
    blueprint_dir: Path, *, max_routes: int, max_len: int,
    reach_cache: Optional[Dict[str, Any]] = None,
) -> Tuple[List[Dict[str, Any]], bool]:
    """DFS parent → child over the verified forward edges with function
    continuity.  Returns ``(routes, capped)``."""
    routes: List[Dict[str, Any]] = []
    capped = False
    if reach_cache is None:
        reach_cache = {}

    def enters_ok(stem: str, ftype: str, entered_fn: str, exit_fn: str) -> bool:
        # The function entered in `stem` must reach the function that calls out.
        return RCH.function_reaches(stem, ftype, entered_fn, exit_fn, blueprint_dir, reach_cache)

    def dfs(stem: str, ftype: str, entered_fn: str, trail: List[Dict[str, Any]],
            visiting: Set[str]) -> None:
        nonlocal capped
        if capped:
            return
        if stem == child.file_stem:
            # We are in the child file; the entered function must reach the
            # target child function (no-op for ASM / unspecified child fn).
            if enters_ok(stem, ftype, entered_fn, child.function or ""):
                routes.append({"hops": list(trail),
                               "files": [trail[0]["from_file"]] + [h["to_file"] for h in trail]
                               if trail else [stem],
                               "length": len(trail)})
                if max_routes and len(routes) >= max_routes:
                    capped = True
            return
        if len(trail) >= max_len:
            return
        for e in fwd.get(stem, ()):
            callee = e["callee"]
            if callee in visiting:
                continue                          # simple paths only
            # In `stem`, the function we entered at must reach the function that
            # makes THIS call (e["caller_fn"]).
            if not enters_ok(stem, ftype, entered_fn, e["caller_fn"]):
                continue
            callee_type = "cpp" if RCH._load_bp(callee, "cpp", blueprint_dir) else "asm"
            hop = {
                "from_file": stem, "from_function": e["caller_fn"],
                "to_file": callee, "to_function": e["callee_fn"],
                "line": e["line"], "conditions": e["conditions"],
            }
            visiting.add(callee)
            dfs(callee, callee_type, e["callee_fn"], trail + [hop], visiting)
            visiting.discard(callee)
            if capped:
                return

    dfs(parent.file_stem, parent.file_type, parent.function or "", [], {parent.file_stem})
    routes.sort(key=lambda r: (r["length"], [h["to_file"] for h in r["hops"]]))
    return routes, capped


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def find_routes(
    parent: Endpoint,
    child: Endpoint,
    *,
    blueprint_dir: Path,
    graph_file: Path,
    asm_dir: Optional[Path] = None,
    job_id: Optional[str] = None,
    max_caller_depth: int = 0,
    max_routes: int = 200,
    max_len: int = 16,
    graph_payload: Optional[Dict[str, Any]] = None,
    reverse_adj: Optional[Dict[str, Any]] = None,
    node_type: Optional[Dict[str, str]] = None,
    _pfl_cache: Optional[Dict[str, Any]] = None,
    reach_cache: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Find every call route ``parent → child``.

    Returns ``{reachable, route_count, routes, unverified, stats}``.  Each route
    is ``{files: [...], hops: [{from_file, from_function, to_file, to_function,
    line, conditions}], length}``.

    Pass pre-loaded ``graph_payload``, ``reverse_adj`` and ``node_type`` to avoid
    redundant I/O when calling find_routes in a loop (e.g. per-setter).

    Pass ``_pfl_cache`` / ``reach_cache`` to share blueprint caches across calls.
    """
    from backward_traversal.runner.chainless_runner import _load_graph_payload
    from backward_traversal.runner.chainless_caller_walker import (
        build_reverse_adjacency, walk_callers,
    )

    parent = parent.norm()
    child = child.norm()
    blueprint_dir = Path(blueprint_dir)

    # Same-file route: pure intra-file function reachability (no cross-file walk).
    if parent.file_stem == child.file_stem:
        ok = RCH.function_reaches(parent.file_stem, parent.file_type,
                                  parent.function or "", child.function or "",
                                  blueprint_dir, {})
        route = ([{"hops": [], "files": [parent.file_stem], "length": 0,
                   "intra_file": True}] if ok else [])
        return {
            "reachable": ok, "route_count": len(route), "routes": route,
            "unverified": [],
            "stats": {"mode": "intra_file", "parent": asdict(parent), "child": asdict(child)},
        }

    if reverse_adj is None or node_type is None:
        if graph_payload is None:
            graph_payload = _load_graph_payload(Path(graph_file), job_id)
        reverse_adj, node_type = build_reverse_adjacency(graph_payload)

    # Restrict the walk to functions that actually reach the child function.
    anchor = (RCH.reaches_function_set(child.file_stem, child.function, blueprint_dir)
              if (child.file_type == "cpp" and child.function) else None)

    caller_objs = walk_callers(
        child.file_stem, child.file_type, blueprint_dir, asm_dir, reverse_adj, node_type,
        max_caller_depth=max_caller_depth, max_nodes=0, visited=set(), anchor_fns=anchor,
        _pfl_cache=_pfl_cache,
    )
    caller_nodes = [asdict(c) for c in caller_objs]

    fwd, unverified = _build_forward_edges(caller_nodes)
    routes, capped = _enumerate_routes(
        parent, child, fwd, blueprint_dir, max_routes=max_routes, max_len=max_len,
        reach_cache=reach_cache,
    )

    return {
        "reachable": bool(routes),
        "route_count": len(routes),
        "routes": routes,
        "routes_capped": capped,
        "unverified": unverified,
        "stats": {
            "mode": "cross_file",
            "parent": asdict(parent),
            "child": asdict(child),
            "caller_forest_size": len(caller_nodes),
            "verified_caller_files": len(fwd),
            "child_anchor_functions": sorted(anchor) if anchor else None,
        },
    }
