#!/usr/bin/env python3
"""CLI for isolated backward-only traversal."""

from __future__ import annotations

import argparse
import sys

if __package__ in (None, ""):
    from pathlib import Path

    sys.path.append(str(Path(__file__).resolve().parents[1]))
    from backward_traversal.runner.backward_only_runner import (
        DEFAULT_MAX_DEP_VARS,
        DEFAULT_MAX_DEP_VAR_DEPTH,
        DEFAULT_MAX_DOWNSTREAM_DEPTH,
        DEFAULT_MAX_DOWNSTREAM_FILES,
        run_backward_only_from_namespace,
    )
    from backward_traversal.runner.cotraversal_runner import run_cotraversal_from_namespace
else:
    from backward_traversal.runner.backward_only_runner import (
        DEFAULT_MAX_DEP_VARS,
        DEFAULT_MAX_DEP_VAR_DEPTH,
        DEFAULT_MAX_DOWNSTREAM_DEPTH,
        DEFAULT_MAX_DOWNSTREAM_FILES,
        run_backward_only_from_namespace,
    )
    from backward_traversal.runner.cotraversal_runner import run_cotraversal_from_namespace


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Backward-only cross-file traversal (isolated stack)")
    p.add_argument("variable", help="Root variable (e.g. LG1OSI)")
    p.add_argument("--chain-files", required=True, help="Comma-separated chain; last file must be modifier")
    p.add_argument("--blueprint-dir", metavar="DIR", help="Directory containing .asm.json/.cpp.json files")
    p.add_argument("--asm-dir", metavar="DIR", help="Directory containing .asm/.cpp source files")
    p.add_argument("--graph", metavar="FILE", help="Path to file_call_graph.json")
    p.add_argument("--max-depth", metavar="N", type=int, default=8, help="ASM backward predecessor depth")
    p.add_argument("--max-subroutine-depth", metavar="N", type=int, default=2,
                   help="Max nested subroutine expansion depth (default: 2)")
    p.add_argument("--max-subroutine-nodes", metavar="N", type=int, default=400,
                   help="Max relevant lines per subroutine expansion (default: 400)")
    p.add_argument("--max-trace-nodes", metavar="N", type=int, default=5000,
                   help="Max relevant lines per call-site trace including nested expansions (default: 5000)")
    p.add_argument("--max-dep-vars", metavar="N", type=int, default=DEFAULT_MAX_DEP_VARS,
                   help=f"Max total dep_vars traced across all BFS levels (default: {DEFAULT_MAX_DEP_VARS})")
    p.add_argument("--max-dep-var-depth", metavar="N", type=int, default=DEFAULT_MAX_DEP_VAR_DEPTH,
                   help=f"Max dep_var recursion depth: 0=Pass1 dep_vars, 1=their deps, … (default: {DEFAULT_MAX_DEP_VAR_DEPTH})")
    p.add_argument("--max-downstream-depth", metavar="N", type=int, default=DEFAULT_MAX_DOWNSTREAM_DEPTH,
                   help=f"Max downstream file BFS depth per dep_var (default: {DEFAULT_MAX_DOWNSTREAM_DEPTH})")
    p.add_argument("--max-downstream-files", metavar="N", type=int, default=DEFAULT_MAX_DOWNSTREAM_FILES,
                   help=f"Max downstream files visited per dep_var (default: {DEFAULT_MAX_DOWNSTREAM_FILES})")
    p.add_argument("--output", metavar="FILE", help="Output JSON path")

    # Co-traversal flags (--cotraverse enables bidirectional ASM<->CPP tracking)
    p.add_argument(
        "--cotraverse",
        action="store_true",
        default=False,
        help=(
            "Enable bidirectional co-traversal. When set, --counterpart-chain is required. "
            "The primary variable is traced on --chain-files and its cross-language "
            "counterpart is traced on --counterpart-chain. Output goes to a directory "
            "containing primary/, counterpart/, and cotraversal.json."
        ),
    )
    p.add_argument(
        "--counterpart-chain",
        metavar="STEMS",
        default=None,
        help="Comma-separated chain for the counterpart variable (required with --cotraverse)",
    )
    p.add_argument(
        "--counterpart-var",
        metavar="VAR",
        default=None,
        help="Explicit counterpart variable name override (optional; auto-resolved when omitted)",
    )
    p.add_argument(
        "--counterpart-language",
        metavar="LANG",
        default="asm",
        choices=["asm", "cpp"],
        help="Language of the PRIMARY variable (asm or cpp, default: asm)",
    )
    return p


def main() -> int:
    parser = build_arg_parser()
    args = parser.parse_args()
    if args.cotraverse:
        return run_cotraversal_from_namespace(args)
    return run_backward_only_from_namespace(args)


if __name__ == "__main__":
    sys.exit(main())
