# Utility Detection & Critical File Filtering — Approach Document

## Table of Contents

1. [Problem Statement](#1-problem-statement)
2. [Key Definitions](#2-key-definitions)
3. [Methodology Overview](#3-methodology-overview)
4. [Signal Taxonomy](#4-signal-taxonomy)
5. [Utility Score Formula](#5-utility-score-formula)
6. [Role Classification](#6-role-classification)
7. [Memory Architecture for Large Codebases](#7-memory-architecture-for-large-codebases)
8. [Critical Path Filtering Algorithm](#8-critical-path-filtering-algorithm)
9. [Implementation: `utility_detector.py`](#9-implementation-utility_detectorpy)
10. [Usage Examples](#10-usage-examples)
11. [Benchmark Results](#11-benchmark-results)
12. [Worked Example — Small Codebase](#12-worked-example--small-codebase)
13. [Design Decisions & Trade-offs](#13-design-decisions--trade-offs)
14. [Extending the System](#14-extending-the-system)

---

## 1. Problem Statement

A large ASM/CPP codebase (10M+ lines, 50K+ files) contains two fundamentally different kinds of files:

- **Utility files** — Shared infrastructure that is used by many modules but does not implement unique business logic. Examples: macro template files (`.mac`), data-structure headers (`.hpp`), common DSECT definition files.
- **Critical files** — Files that implement a specific, unique piece of business functionality. These are the files that must be understood, analysed, or modernised when working on a given feature.

**The core question this system answers:**

> *"Given a functionality (entry point), which files are truly critical to that functionality, and which are just shared plumbing I can ignore for now?"*

**Constraints:**
- The system must handle codebases with 50K+ files and 10M+ lines of code.
- It must not exhaust RAM — loading even a fraction of such a codebase at once can exceed available memory.
- Results must be available in sub-second query time after a one-time index build.

---

## 2. Key Definitions

| Term | Definition |
|------|-----------|
| **Utility file** | A file whose primary purpose is to provide shared data structures, macro templates, or platform infrastructure consumed by many other files. Utility files have high _fan-in_ (many callers) and low unique business logic density. |
| **Critical file** | A file that implements business logic unique to a specific feature or transaction flow. Critical files tend to be standalone programs (with explicit entry points) and are called by few other files. |
| **Fan-in** | The number of distinct files that call or include a given file. High fan-in is the primary graph-level indicator of a utility. |
| **Fan-out** | The number of distinct files that a given file calls or includes. |
| **Utility score** | A number in `[0.0, 1.0]` where `0.0` = purely critical and `1.0` = purely utility. |
| **Critical path** | The set of files reachable from a given entry point via call/include edges, filtered and ranked by their criticality to that specific functionality. |
| **Entry point** | The starting file or module for a given functionality — the top-level program that implements the feature being analysed. |

---

## 3. Methodology Overview

The approach runs in two independent phases:

```
┌─────────────────────────────────────────────────────────┐
│  PHASE 1 — INDEX BUILD  (one-time, ~30s for 30K files)  │
│                                                         │
│  Source Files                                           │
│  (ASM/CPP/MAC/HPP)  ──[stream one at a time]──▶         │
│                                                         │
│  Content Analysis          Call Edge Extraction         │
│  • DSECT/DS density        • ENTRC / ENTNC / ENTDC      │
│  • Macro def ratio         • CREEC / CREMC / SWISC      │
│  • Business opcode ratio   • CALL_ALIAS (#pragma map)   │
│  • Entry point count       • #include dependencies      │
│  • BEGIN NAME= presence                                 │
│           │                        │                    │
│           └──────────┬─────────────┘                    │
│                      ▼                                  │
│              SQLite Database                            │
│              (files + edges + metrics tables)           │
│              ~5 MB for 30K files                        │
└──────────────────────────────────────────────────────────┘
                        │
                        │  (one-time computation)
                        ▼
┌─────────────────────────────────────────────────────────┐
│  SCORE COMPUTATION                                      │
│                                                         │
│  For each file: compute utility_score from              │
│  5 weighted signals (see §4–5)                          │
│  Stored back into the SQLite DB                         │
└──────────────────────────────────────────────────────────┘
                        │
                        │  (any number of times, ~0.1s each)
                        ▼
┌─────────────────────────────────────────────────────────┐
│  PHASE 2 — QUERY                                        │
│                                                         │
│  filter --entry da78                                    │
│          │                                              │
│          ▼                                              │
│  Streaming BFS on DB adjacency list                     │
│  (only frontier nodes in RAM at any time)               │
│          │                                              │
│          ▼                                              │
│  Ranked list: each reachable file scored by             │
│  criticality, role, depth, direction                    │
└──────────────────────────────────────────────────────────┘
```

---

## 4. Signal Taxonomy

Five independent signals are computed for each file and combined into the utility score.

### Signal 1 — Extension Type (`ext_score`)

File extension is the strongest single signal because each extension class has a well-defined purpose in this codebase.

| Extension | Score | Rationale |
|-----------|-------|-----------|
| `.mac` | 1.00 | Pure macro template / DSECT definition files. Always utility. |
| `.hpp` | 0.85 | C++ data-structure headers. Almost always utility. |
| `.h` | 0.80 | C headers. Mostly utility. |
| `.asm` | 0.30 | Uncertain: could be a standalone program or a data-heavy module. Content score differentiates. |
| `.cpp` | 0.05 | C++ implementation files. Almost always contain unique business logic. |

### Signal 2 — Content Density (`content_score`)

Measures the fraction of non-blank, non-comment lines that are _data definitions_ rather than _business instructions_.

**For ASM / MAC files:**
- Count lines matching `DSECT`, `DS `, `DC `, `EQU `, `ORG `, `EXTRN `, `PUBLIC ` → data definition lines
- Count lines matching `MACRO`, `MEND`, `AIF`, `AGO`, `SETB`, `GBLC`, etc. → macro definition lines
- Count lines whose opcode is a business instruction (`MVC`, `AP`, `ENTRC`, `BCT`, etc.) → instruction lines

```
content_score(ASM) = min(1.0, dsect_ratio + macro_ratio × 0.5) − instruction_ratio × 0.8
```

High `dsect_ratio` + low `instruction_ratio` → high content score (utility).
High `instruction_ratio` (lots of real CPU instructions) → penalises the score.

**For HPP files:**
```
content_score(HPP) = struct_density + include_density
```
`struct_density` = fraction of lines that are `struct/class/union/typedef/enum` declarations or field definitions.

**For CPP files:**
```
content_score(CPP) = max(0, include_ratio − function_def_ratio × 2.0)
```
A header-heavy CPP with few function bodies gets a modest content score. A CPP file full of function bodies gets penalised.

### Signal 3 — Fan-in Rank (`fan_in_score`)

Files that are called or included by many others are shared infrastructure, regardless of their content. This signal is **percentile-normalised** across the entire codebase:

```
fan_in_score(file) = in_degree(file) / max_in_degree(codebase)
```

This ensures the signal is always in `[0, 1]` and naturally adapts to the scale of the codebase. The file with the highest fan-in gets score `1.0`; files with zero callers get `0.0`.

> **Why normalise?** A file with `in_degree=10` is highly shared in a 30-file codebase but average in a 30K-file codebase. Percentile normalisation makes the signal codebase-relative.

### Signal 4 — Entry Point Count (`entry_score`)

A standalone business program declares itself as an entry point. Utility files have no entry points because they are never invoked directly — they are always called by someone else.

| Condition | Score |
|-----------|-------|
| Has `BEGIN NAME=` (ASM standalone program) | 0.00 — clearly a business program, not utility |
| Has `#pragma export` / `#pragma map` (C++ bridge) | partial penalty |
| Zero entry points | 0.75 — could be utility |

### Signal 5 — Name Pattern (`name_score`)

Naming conventions in this codebase encode purpose. Known patterns:

| Pattern | Score | Example | Meaning |
|---------|-------|---------|---------|
| `*gl` suffix | 0.85 | `da7gl`, `lm1gl` | Global data layout file |
| `cc*.hpp` | 0.95 | `ccda7gl.hpp`, `cclg1g1.hpp` | C++ wrapper for data layout |
| `[a-z]{2}\d{2}[a-z]{2}` (`.mac`) | 0.70 | `cr21ae`, `wb1wb` | Database record definition |
| All others | 0.20 | `dx710000`, `da78` | Default — no name-based utility signal |

---

## 5. Utility Score Formula

```
utility_score = (
    ext_score     × 0.30  +
    content_score × 0.25  +
    fan_in_score  × 0.25  +
    entry_score   × 0.10  +
    name_score    × 0.10
)
```

**Weight rationale:**

| Signal | Weight | Reason |
|--------|--------|--------|
| `ext_score` | 30% | Extension is the strongest single signal; `.mac` and `.hpp` are almost always utility |
| `content_score` | 25% | Data-heavy files vs instruction-heavy files is a reliable differentiator |
| `fan_in_score` | 25% | Being called by many modules is a definitive utility signal |
| `entry_score` | 10% | Presence of an entry point confirms business program status |
| `name_score` | 10% | Naming convention is useful but not always consistent |

The score is clamped to `[0.0, 1.0]`.

---

## 6. Role Classification

The continuous utility score is bucketed into five human-readable roles:

| Score Range | Role | What It Means |
|-------------|------|---------------|
| `0.80 – 1.00` | `PURE_UTILITY` | Macro templates, platform-only helpers. Never needs business analysis. |
| `0.60 – 0.80` | `SHARED_INFRA` | Heavily reused data layout headers and common modules. Required at runtime but not business-logic owners. |
| `0.40 – 0.60` | `BRIDGE` | Mixed files: DSECT definitions + some logic. Shared pattern that multiple programs depend on. |
| `0.20 – 0.40` | `FUNCTIONAL` | Business-logic modules with some shared use. Important for functionality analysis. |
| `0.00 – 0.20` | `CRITICAL` | Unique business logic, few or no callers. Must be analysed for any functionality they participate in. |

---

## 7. Memory Architecture for Large Codebases

### Why a SQLite-backed approach

Loading a call graph for 50K files entirely into RAM would require approximately:
- 50K nodes × 200 bytes (metadata) ≈ 10 MB
- 500K edges × 64 bytes ≈ 32 MB
- Python object overhead × 3–5× ≈ **150–200 MB**

This is manageable today, but at 10M lines / 500K+ files with hundreds of thousands of edges it becomes untenable. The SQLite approach brings this down to a fixed ~17 MB for any codebase size.

### Index design

```sql
-- One row per source file
CREATE TABLE files (
    id                  INTEGER PRIMARY KEY,
    stem                TEXT    UNIQUE,      -- "da78"
    path                TEXT,                -- "temp/asm/da78.asm"
    ext                 TEXT,                -- ".asm"
    loc                 INTEGER,             -- lines of code
    non_blank_lines     INTEGER,
    has_begin_name      INTEGER,             -- 0/1
    entry_point_count   INTEGER,
    dsect_ratio         REAL,                -- content signal
    macro_def_ratio     REAL,                -- content signal
    instruction_ratio   REAL,                -- content signal
    utility_score       REAL                 -- final computed score
);

-- One row per directed call/include edge
CREATE TABLE edges (
    src_id    INTEGER,   -- calling file
    dst_id    INTEGER,   -- called file
    call_type TEXT,      -- subroutine_call / no_return_call / async_spawn / include / …
    PRIMARY KEY (src_id, dst_id, call_type)
);
CREATE INDEX idx_edges_src ON edges(src_id);   -- fast forward BFS
CREATE INDEX idx_edges_dst ON edges(dst_id);   -- fast backward BFS

-- Computed degree metrics
CREATE TABLE metrics (
    file_id      INTEGER PRIMARY KEY,
    in_degree    INTEGER,
    out_degree   INTEGER,
    fan_in_score REAL      -- percentile-normalised
);
```

**DB size:** ~5.6 MB for 30,874 files with 23,144 edges.

### Streaming index build

Files are scanned **one at a time**. No file content is ever held in RAM after its metrics are extracted:

```
for each file in os.walk(src_dir):
    metrics = analyse_file(file)          # reads + discards file content
    insert metrics into DB
    append outgoing_edges to pending list

flush pending_edges to DB in batches of 5000
compute degree metrics (pure SQL UPDATEs)
compute utility scores (pure SQL SELECTs + UPDATEs)
```

Peak RAM during build ≈ 50 MB (Python interpreter overhead + one file buffer at a time).

### Streaming BFS for critical path analysis

The BFS frontier never exceeds `_BFS_BATCH = 500` nodes per SQL query:

```python
visited = {seed_id: depth_0}
frontier = [seed_id]

while frontier:
    # Query only the current frontier's neighbours
    next_frontier = SQL: SELECT dst_id FROM edges WHERE src_id IN (batch)
    add new nodes to visited
    frontier = next_frontier
```

Peak RAM during BFS ≈ O(frontier size) — practically a few hundred KB.

---

## 8. Critical Path Filtering Algorithm

### Step 1 — Seed resolution

The entry point can be specified as:
- **Exact stem:** `da78` → matches `da78.asm`
- **Prefix match:** `dx71` → matches `dx710000.cpp`
- **Keyword search:** `global limits` → matches any stem containing both tokens
- **Path substring:** `temp/asm/da78.asm`

Multiple seeds are supported (e.g., a CPP file and its main ASM backend).

### Step 2 — Forward BFS (callee chain)

Starting from the seed(s), expand all transitively reachable callees. Call types followed: `subroutine_call`, `no_return_call`, `async_spawn`, `isc_route`, `call_alias`, `include`.

This answers: _"What does this functionality call?"_

### Step 3 — Backward BFS (caller chain, optional)

Starting from the seed(s), expand all callers. This answers: _"What other code triggers this functionality?"_

Enabled with `--include-callers`. Useful for understanding the full execution context.

### Step 4 — Scoring reachable files

For each file in the reachable set:

```
criticality_score = 1.0 - utility_score
```

This is intentionally simple: a file's importance to _this specific functionality_ is the inverse of how utility-like it is globally. Files that are heavily shared infrastructure are, by definition, not specifically important to any one functionality.

### Step 5 — Output

Results are sorted:
1. Seed file(s) first (★ marked)
2. Then by `criticality_score` descending
3. Then by `depth` ascending (closer to entry point comes first among equal scores)

Each result includes:
- `stem`, `path`, `ext` — file identity
- `utility_score`, `criticality_score` — numeric scores
- `role` — human-readable classification
- `depth` — BFS hops from entry point
- `direction` — `seed`, `callee`, or `caller`
- `in_degree`, `out_degree` — graph connectivity

---

## 9. Implementation: `utility_detector.py`

The implementation is a single self-contained Python script with no dependencies beyond the Python standard library.

### Key classes

| Class | Purpose | Memory |
|-------|---------|--------|
| `IndexBuilder` | Scans source files, writes SQLite index | O(1) — one file at a time |
| `ContentAnalyzer` (functions) | Extracts metrics from a single file | O(file size) |
| `EdgeExtractor` (inside analyser) | Extracts call edges from a single file | O(edges per file) |
| `CriticalPathAnalyzer` | BFS over SQLite adjacency list | O(frontier) |
| `analyze_all` (function) | Global utility ranking via SQL | O(result page) |

### Content analysers per file type

**`_analyse_asm(lines)`** — for `.asm` and `.mac` files:
- Tokenises each line using HLASM column conventions (blank col 1 = no label → first token is opcode; label in col 1 → second token is opcode)
- Classifies lines as: comment, data definition, macro definition, or business instruction
- Extracts outgoing call edges for `ENTRC`, `ENTNC`, `ENTDC`, `CREEC`, `CREMC`, `SWISC`, `FUNCTION`
- Detects `BEGIN NAME=` for entry point identification

**`_analyse_cpp(lines)`** — for `.cpp` files:
- Extracts `#pragma map(func, "MODULE")` → `call_alias` edges to ASM targets
- Extracts `extern "C" void MODULE(TPF_regs*)` → bridge declarations
- Extracts `#include <header.hpp>` → include dependency edges
- Counts `#pragma export` / `#pragma map` for entry point scoring

**`_analyse_hpp(lines)`** — for `.hpp` and `.h` files:
- Counts `struct`, `class`, `union`, `typedef`, `enum` declarations
- Counts field definition lines (indented with type + semicolon)
- Extracts include edges

---

## 10. Usage Examples

### One-time index build

```bash
# Small codebase
python3 utility_detector.py build --src temp/asm --db utility_index.db

# Large codebase (30K files, ~32 seconds)
python3 utility_detector.py build --src temp/asm_28000 --db utility_large.db
```

### View global utility ranking

```bash
# All files, sorted from most utility to most critical
python3 utility_detector.py analyze --db utility_index.db

# Top 20 most critical files
python3 utility_detector.py analyze --db utility_index.db --role CRITICAL --top 20

# Export full ranking to JSON
python3 utility_detector.py analyze --db utility_index.db --output ranking.json
```

### Filter critical files for a functionality

```bash
# By exact stem
python3 utility_detector.py filter --entry da78 --db utility_index.db

# Include upstream callers (full context)
python3 utility_detector.py filter --entry da78 --db utility_index.db --include-callers

# By partial name match
python3 utility_detector.py filter --entry dx71 --db utility_index.db

# By keyword (finds files whose stem contains all tokens)
python3 utility_detector.py filter --entry "global limits" --db utility_index.db

# Limit BFS depth (only look 3 hops deep)
python3 utility_detector.py filter --entry da78 --db utility_index.db --max-depth 3

# Export full result to JSON for downstream processing
python3 utility_detector.py filter --entry da78 --db utility_index.db --output da78_critical.json
```

### JSON output structure

```json
{
  "entry": "da78",
  "seeds": ["da78"],
  "total_reachable": 15,
  "role_summary": {
    "FUNCTIONAL": 13,
    "CRITICAL": 1,
    "BRIDGE": 1
  },
  "files": [
    {
      "stem": "da78",
      "path": "temp/asm/da78.asm",
      "ext": ".asm",
      "loc": 2151,
      "utility_score": 0.235,
      "criticality_score": 0.765,
      "role": "FUNCTIONAL",
      "depth": 0,
      "direction": "seed",
      "in_degree": 1,
      "out_degree": 1,
      "has_entry_point": true
    },
    ...
  ]
}
```

---

## 11. Benchmark Results

Tests run on the `temp/asm_28000` codebase (30,874 files, mixed ASM/CPP/MAC/HPP).

### Index build

| Metric | Value |
|--------|-------|
| Total files | 30,874 |
| Files skipped (unreadable) | 0 |
| Call edges inserted | 23,144 |
| Build time | **32 seconds** |
| DB file size | **5.6 MB** |
| Peak RAM (build phase) | **~50 MB** |
| Peak RAM (query phase) | **17.3 MB** |

### Role distribution (large codebase)

| Role | Count | % |
|------|-------|---|
| PURE_UTILITY | 0 | 0.0% |
| SHARED_INFRA | 2,200 | 7.1% |
| BRIDGE | 6,606 | 21.4% |
| FUNCTIONAL | 12 | 0.0% |
| CRITICAL | 22,056 | 71.4% |

> **Note:** The large codebase is a matrix of duplicated variants (`_cp1`, `_cp2`, `_dup` suffixes). In a real production codebase, the `SHARED_INFRA` and `BRIDGE` proportions would be higher because the `.hpp`/`.mac` files would have much higher fan-in from the unique variants pointing to shared originals.

### Filter query performance

| Entry point | Reachable files | Query time |
|-------------|-----------------|------------|
| `ae48` | 3 | 0.07s |
| `da78` (large DB) | 2,214 | **0.125s** |
| `dx740200` | 3 | 0.06s |

---

## 12. Worked Example — Small Codebase

The `temp/asm` codebase contains 28 files. Here is the complete scored output:

| Stem | Ext | Role | Util Score | In | Out | Reasoning |
|------|-----|------|------------|----|-----|-----------|
| `ccda7gl` | `.hpp` | SHARED_INFRA | 0.751 | 1 | 0 | High ext_score (0.85) + high struct density (78%) + name pattern `cc*gl` |
| `cclg1g1` | `.hpp` | SHARED_INFRA | 0.735 | 1 | 0 | Same pattern; 374 LOC of field definitions |
| `hubgl` | `.mac` | BRIDGE | 0.518 | 0 | 0 | High ext_score (1.0) but low fan-in in this small sample |
| `lg1lg1` | `.mac` | BRIDGE | 0.516 | 0 | 0 | Pure DSECT definition, 2535 lines of field definitions |
| `cr21ae` | `.mac` | BRIDGE | 0.515 | 0 | 0 | Database record definition macro |
| `lm1m1` | `.mac` | BRIDGE | 0.512 | 0 | 0 | CAS generic database workblock DSECT |
| `da7gl` | `.mac` | BRIDGE | 0.497 | 0 | 0 | Global limits workarea DSECT |
| `wb1wb` | `.mac` | BRIDGE | 0.492 | 0 | 0 | File maintenance workarea macro |
| `xh93` | `.asm` | BRIDGE | 0.435 | 2 | 0 | ASM leaf called by 2 files; high data density (14.9%) |
| `xh71`–`xh96` | `.asm` | FUNCTIONAL | 0.310 | 1 | varies | ASM programs; high instruction ratio (43–66%) |
| `da76`, `da78`, `xh90` | `.asm` | FUNCTIONAL | 0.235 | 1 | 1 | Programs with `BEGIN NAME=`; entry point penalty applies |
| `lu82` | `.asm` | CRITICAL | 0.185 | 0 | 1 | No entry point, no callers, extremely high instruction ratio (85.9%) |
| `dx750000` | `.cpp` | CRITICAL | 0.166 | 0 | 0 | CPP with minimal includes |
| `xh890000` | `.cpp` | CRITICAL | 0.123 | 0 | 0 | CPP implementation |
| `dx730000` | `.cpp` | CRITICAL | 0.086 | 0 | 0 | CPP with 2 entry points |
| `dx710000` | `.cpp` | CRITICAL | 0.043 | 0 | 0 | CPP with 12 `#pragma` declarations (dense entry-point file) |
| `dx740200` | `.cpp` | CRITICAL | 0.041 | 0 | 2 | CPP that includes 2 headers; most critical in codebase |

### Critical path for `da78` (Global Limits Processor)

Running `filter --entry da78 --include-callers`:

```
★ da78     .asm  FUNCTIONAL   crit=0.765  depth=0   seed
  lu82     .asm  CRITICAL     crit=0.815  depth=2   caller  ← top-level trigger
  da76     .asm  FUNCTIONAL   crit=0.765  depth=1   caller
  xh90     .asm  FUNCTIONAL   crit=0.765  depth=2   callee
  xh80     .asm  FUNCTIONAL   crit=0.690  depth=1   callee  ← central dispatcher
  xh71     .asm  FUNCTIONAL   crit=0.690  depth=2   callee
  xh81     .asm  FUNCTIONAL   crit=0.690  depth=2   callee
  xh85     .asm  FUNCTIONAL   crit=0.690  depth=2   callee
  xh72     .asm  FUNCTIONAL   crit=0.690  depth=3   callee
  xh83     .asm  FUNCTIONAL   crit=0.690  depth=3   callee
  xh82     .asm  FUNCTIONAL   crit=0.690  depth=4   callee
  xh87     .asm  FUNCTIONAL   crit=0.690  depth=4   callee
  xh88     .asm  FUNCTIONAL   crit=0.690  depth=5   callee
  xh96     .asm  FUNCTIONAL   crit=0.690  depth=6   callee
  xh93     .asm  BRIDGE       crit=0.565  depth=3   callee  ← shared by xh85 and xh88
```

**Interpretation:**
- `lu82` (depth=2 via caller chain) is the entry trigger — it calls `da76` which calls `da78`
- `xh80` is the central dispatcher at depth=1 — it fans out to 4 sub-modules
- `xh93` is classified as BRIDGE (score 0.435) because it is called by two different files (`xh85` and `xh88`), showing some sharing
- All `.mac` and `.hpp` files are correctly **absent** from this list — they are shared infrastructure not reachable via call edges, and even if included, their scores would mark them as non-critical

---

## 13. Design Decisions & Trade-offs

### Macro invocations are not tracked as call edges

In HLASM, macros are invoked inline (e.g., `LM1M1 REG=R2`), not via `ENTRC`-style call instructions. The macro invocation is a compile-time expansion, not a runtime call. Therefore:
- `.mac` files do **not** appear as callees in the runtime call graph
- Their utility classification relies entirely on `ext_score`, `content_score`, and `name_score`
- This is the correct behaviour: macro files are build-time utilities, not runtime call targets

### Fan-in uses in-codebase callers only

The fan-in score counts only callers within the indexed directory. External callers (from modules not in `--src`) are not counted. This means:
- In a partial codebase scan, fan-in may be underestimated
- The recommended approach is to index the full codebase once, then filter by entry point

### Duplicate files (`_cp1`, `_dup` suffix) in `asm_28000`

The large test codebase contains many files with `_cp1`, `_cp2`, `_dup` suffixes (permutation testing matrix). These are treated as independent files. In a production deployment, you may want to de-duplicate by canonical stem before building the index. The tool handles them correctly as-is — duplicates cluster together in the utility rankings.

### Why not use betweenness centrality?

Betweenness centrality (fraction of shortest paths passing through a node) is the textbook measure of "hub" files. However:
- Computing exact betweenness is O(V × E) — infeasible for 50K files
- Approximation requires O(k × E) with hundreds of BFS runs
- **Fan-in percentile rank** captures the same intuition (files used by many modules) at O(E) cost and is sufficient for this classification task

---

## 14. Extending the System

### Adding COPY/macro-invocation edges

To track which ASM files use which `.mac` files at build time, add a regex pass for lines like `LM1M1 REG=R2`, `HUBGL REG=R3`, etc., and insert them as `macro_use` typed edges. This would increase `.mac` file fan-in scores and push them from BRIDGE into SHARED_INFRA.

### Integrating with existing blueprints

The project already has `file_call_graph.py` which produces a richer call graph from JSON blueprints. The SQLite index can be pre-populated from those blueprints instead of (or in addition to) raw source scanning, by adapting the `IndexBuilder.build()` method to consume `call_graph.json` output.

### Confidence-weighted scores

Currently all signals are weighted equally within their category. If you have domain knowledge that certain name patterns are unreliable, the weights in the formula can be adjusted per file type:

```python
# Example: reduce name_score weight for .asm files (names less consistent)
if ext == ".asm":
    weights = (0.30, 0.30, 0.30, 0.10, 0.00)  # drop name_score for ASM
```

### Cluster-aware filtering

To filter within an existing cluster (e.g., from a prior analysis pipeline), pass the cluster's file list as seeds and use `--max-depth 0` to score only those files without BFS expansion:

```bash
python3 utility_detector.py filter --entry cluster_entry --db utility_index.db --max-depth 0
```

### Incremental re-indexing

When only a subset of files change, use the `ON CONFLICT ... DO UPDATE` upsert in `IndexBuilder` — re-run `build` on the full directory. Only changed files will update their rows (SQLite detects unchanged content via the `stem` primary key). Edge recomputation is fast (pure SQL).
