#!/usr/bin/env python3
"""
filter_subset_chains.py

Post-filter for find_variable_modifiers.py output.
Removes call chains whose file list is a contiguous subsequence of any longer chain.

Example: if [da76, da78, xh80] exists, then [da76, da78] and [da78, xh80]
are both removed as redundant subsets.

Usage:
  python filter_subset_chains.py <modifiers_json> [--output FILE]
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple


def filter_subset_chains(
    chains: List[Dict[str, Any]],
) -> Tuple[List[Dict[str, Any]], List[List[str]]]:
    """Remove chains whose file list is a contiguous sub-sequence of a longer chain.

    Algorithm — rolling-window hash set, O(N·L²) time / O(N·L²) space:

    1. Assign each unique stem a stable integer ID (avoids repeated string hashing).
    2. Sort chains longest-first.  Process them in that order: when we inspect a
       chain of length k, the ``windows`` set already contains every contiguous
       sub-window (length 1 … k-1) from all chains that are strictly longer.
    3. A chain is *dominated* iff its full ID-tuple is already in ``windows``.
    4. After the dominance check, add all strict sub-windows of the current chain
       to ``windows`` so shorter chains processed later can match against it.

    Because dominated chains are checked against windows built only from *longer*
    chains, same-length chains never dominate each other — matching the semantics
    of the original ``is_subchain`` (which required ``len(shorter) < len(longer)``).

    Complexity vs. the naive approach:
      Naive:   O(N² · L²)  — every pair × sliding-window scan
      New:     O(N · L²)   — N chains × up to L² window insertions each
    For N=1 000 chains of average length L=10, that is ~100× fewer operations.
    """
    if len(chains) <= 1:
        return list(chains), []

    # Map each stem to a stable integer so tuple hashing is fast and uniform.
    stem_id: Dict[str, int] = {}
    for chain in chains:
        for stem in chain["files"]:
            if stem not in stem_id:
                stem_id[stem] = len(stem_id)

    # Process longest chains first; build windows incrementally.
    order = sorted(range(len(chains)), key=lambda i: -len(chains[i]["files"]))

    windows: Set[Tuple[int, ...]] = set()
    dominated: Set[int] = set()

    for orig_i in order:
        ids = tuple(stem_id[s] for s in chains[orig_i]["files"])
        n = len(ids)

        # Dominated if this chain's full tuple was added as a sub-window of a
        # strictly longer chain processed earlier.
        if ids in windows:
            dominated.add(orig_i)

        # Register all strict sub-windows so shorter chains can be checked later.
        for w in range(1, n):
            for start in range(n - w + 1):
                windows.add(ids[start : start + w])

    kept = [c for i, c in enumerate(chains) if i not in dominated]
    removed = [chains[i]["files"] for i in dominated]
    return kept, removed


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Remove subset call chains from a find_variable_modifiers.py output file. "
            "A chain is removed if its file list appears as a contiguous run inside a longer chain."
        )
    )
    parser.add_argument("input", help="Path to modifiers JSON (e.g. LG1OSI_modifiers.json)")
    parser.add_argument(
        "--output",
        metavar="FILE",
        help="Output path (default: <stem>_filtered.json next to input)",
    )
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"ERROR: File not found: {input_path}", file=sys.stderr)
        return 1

    if args.output:
        output_path = Path(args.output)
    else:
        output_path = input_path.parent / (input_path.stem + "_filtered.json")

    data: Dict[str, Any] = json.loads(input_path.read_text(encoding="utf-8"))

    grand_before = 0
    grand_after = 0

    for file_stem, entry in data.get("results", {}).items():
        chains: Optional[List[Dict[str, Any]]] = entry.get("call_chains")
        if chains is None:
            print(f"  {file_stem}: call_chains=null — skipped", file=sys.stderr)
            continue

        before = len(chains)
        kept, removed = filter_subset_chains(chains)
        after = len(kept)
        grand_before += before
        grand_after += after

        entry["call_chains"] = [{"length": c["length"], "files": c["files"]} for c in kept]
        entry["filtered_subset_chains"] = removed  # kept for audit

        print(
            f"  {file_stem}: {before} chains → {after} kept, {before - after} removed",
            file=sys.stderr,
        )
        if removed:
            for r in removed:
                print(f"    - removed: {' → '.join(r)}", file=sys.stderr)

    data["filter_note"] = (
        "Subset chains removed by filter_subset_chains.py. "
        "Removed entries preserved under 'filtered_subset_chains' per file."
    )

    output_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    print(f"\nTotal: {grand_before} → {grand_after} chains kept", file=sys.stderr)
    print(f"Wrote: {output_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
