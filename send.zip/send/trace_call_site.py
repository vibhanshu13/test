#!/usr/bin/env python3
"""
trace_call_site.py

Given two ASM files, finds every call site in the caller that dispatches to the
callee, then backward-traces each call site to surface the guard conditions
(trigger comparisons, branches, dependent variables) that route execution to it.

Usage:
  python trace_call_site.py <caller_stem> <callee_stem> [options]

Options:
  --blueprint-dir DIR   Directory containing .asm.json blueprint files
  --asm-dir DIR         Directory containing .asm source files
  --output FILE         Output JSON path (default: <caller>_to_<callee>_lineage.json)

Example:
  python trace_call_site.py lu82 da76
  python trace_call_site.py da76 da78
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from cross_file_bridge import find_asm_callers, _discover_blueprint_dir, _discover_asm_dir
from trace_lineage import LineageTracer


def _run(
    caller_stem: str,
    callee_stem: str,
    blueprint_dir: Path,
    asm_dir: Optional[Path],
    output_path: Path,
) -> int:
    # ── 1. Find call sites ───────────────────────────────────────────────────
    call_sites = find_asm_callers(caller_stem, callee_stem, blueprint_dir, asm_dir)

    if not call_sites:
        print(
            f"No calls from '{caller_stem}' to '{callee_stem}' found in blueprints.",
            file=sys.stderr,
        )
        result: Dict[str, Any] = {
            "caller": caller_stem,
            "callee": callee_stem,
            "call_sites": [],
        }
        output_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(f"Wrote results to: {output_path}", file=sys.stderr)
        return 0

    print(
        f"Found {len(call_sites)} call site(s) from '{caller_stem}' to '{callee_stem}'.",
        file=sys.stderr,
    )

    # ── 2. Resolve caller's source + blueprint ───────────────────────────────
    caller_asm: Optional[Path] = None
    if asm_dir:
        candidate = asm_dir / f"{caller_stem}.asm"
        if candidate.exists():
            caller_asm = candidate

    if caller_asm is None:
        # Fallback: look for the absolute path stored in the first call site's
        # raw_line source field isn't available, so try common locations.
        for search_dir in [
            blueprint_dir.parent.parent / "asm",
            blueprint_dir.parent / "asm",
            blueprint_dir,
        ]:
            candidate = search_dir / f"{caller_stem}.asm"
            if candidate.exists():
                caller_asm = candidate
                break

    if caller_asm is None:
        print(
            f"ERROR: Could not find '{caller_stem}.asm'. "
            "Pass --asm-dir to specify the source directory.",
            file=sys.stderr,
        )
        return 1

    caller_blueprint = blueprint_dir / f"{caller_stem}.asm.json"
    if not caller_blueprint.exists():
        print(f"ERROR: Blueprint not found: {caller_blueprint}", file=sys.stderr)
        return 1

    print(f"[caller asm]       {caller_asm}", file=sys.stderr)
    print(f"[caller blueprint] {caller_blueprint}", file=sys.stderr)

    # ── 3. Backward-trace each call site ────────────────────────────────────
    tracer = LineageTracer(
        asm_dir=asm_dir or caller_asm.parent,
        blueprint_dir=blueprint_dir,
    )

    enriched_sites: List[Dict[str, Any]] = []

    for cs in call_sites:
        routine = cs.get("routine") or ""
        line = cs.get("line") or 0
        instruction = cs.get("instruction") or ""
        call_type = cs.get("call_type") or ""
        raw_line = cs.get("raw_line") or ""

        print(
            f"  Tracing call site: routine={routine}, line={line}, inst={instruction}",
            file=sys.stderr,
        )

        trace = tracer.trace_from_call_site(
            source_asm_file=caller_asm,
            blueprint_file=caller_blueprint,
            call_block_id=routine,
            call_line=line,
            call_instruction=instruction,
            call_detail=raw_line.strip() if raw_line else f"{instruction} {callee_stem.upper()}",
        )

        enriched_sites.append({
            "routine": routine,
            "line": line,
            "instruction": instruction,
            "call_type": call_type,
            "raw_line": raw_line,
            "guard_conditions": [
                e for e in trace.lineage_chain
                if e.get("role") != "CALL_SITE"
            ],
            "dependent_vars": trace.dependent_vars,
            "dependent_files": trace.dependent_files,
            "warnings": trace.data_quality_warnings,
        })

    # ── 4. Write output ──────────────────────────────────────────────────────
    result = {
        "caller": caller_stem,
        "callee": callee_stem,
        "call_sites": enriched_sites,
    }
    output_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"Wrote results to: {output_path}", file=sys.stderr)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Backward-trace each call site from caller to callee to find "
            "guard conditions (triggers, branches, dependent variables)."
        )
    )
    parser.add_argument("caller_stem", help="Calling ASM file stem (e.g. lu82)")
    parser.add_argument("callee_stem", help="Called ASM file stem (e.g. da76)")
    parser.add_argument("--blueprint-dir", metavar="DIR",
                        help="Directory containing .asm.json blueprint files")
    parser.add_argument("--asm-dir", metavar="DIR",
                        help="Directory containing .asm source files")
    parser.add_argument("--output", metavar="FILE",
                        help="Output JSON path (default: <caller>_to_<callee>_lineage.json)")
    args = parser.parse_args()

    output_path = (
        Path(args.output) if args.output
        else Path(f"{args.caller_stem}_to_{args.callee_stem}_lineage.json")
    )

    # ── Resolve blueprint directory ──────────────────────────────────────────
    if args.blueprint_dir:
        blueprint_dir = Path(args.blueprint_dir)
        if not blueprint_dir.exists():
            print(f"ERROR: Blueprint dir not found: {blueprint_dir}", file=sys.stderr)
            return 1
    else:
        blueprint_dir = _discover_blueprint_dir()
        if blueprint_dir is None:
            print(
                "ERROR: Could not discover blueprint directory. "
                "Pass --blueprint-dir explicitly.",
                file=sys.stderr,
            )
            return 1

    print(f"[blueprints] {blueprint_dir}", file=sys.stderr)

    # ── Resolve ASM source directory ─────────────────────────────────────────
    if args.asm_dir:
        asm_dir: Optional[Path] = Path(args.asm_dir)
    else:
        asm_dir = _discover_asm_dir(blueprint_dir)
        if asm_dir:
            print(f"[asm-source] {asm_dir}", file=sys.stderr)

    return _run(
        caller_stem=args.caller_stem,
        callee_stem=args.callee_stem,
        blueprint_dir=blueprint_dir,
        asm_dir=asm_dir,
        output_path=output_path,
    )


if __name__ == "__main__":
    sys.exit(main())
